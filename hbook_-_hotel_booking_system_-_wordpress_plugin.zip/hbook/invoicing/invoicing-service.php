<?php
abstract class HbInvoicingService {

	public $id = '';
	public $name = '';
	public $locale = '';
	public $version = '1.0';
	public $hbdb;
	public $utils;

	public function get_strings_section() {
		return array();
	}

	public function get_strings_value() {
		return array();
	}

	public function init_options() {
		$admin_fields = $this->admin_fields();
		foreach ( $admin_fields['options'] as $option_id => $option_info ) {
			if ( get_option( $option_id ) === false ) {
				if ( isset( $option_info['default'] ) ) {
					add_option( $option_id, $option_info['default'] );
				}
			}
		}
	}

	public function insert_plugin_strings() {
		global $wpdb;
		$strings = $this->get_strings_value();
		foreach	( $strings as $string_id => $string_value ) {
			if ( ! $this->utils->get_string( $string_id ) ) {
				$query = "INSERT INTO {$this->hbdb->strings_table} ( id, locale, value ) VALUES ( '$string_id', 'en_US', '$string_value' )";
				$wpdb->query( $query );
			}
		}
	}

	public function add_plugin_strings( $hb_strings ) {
		$plugin_strings = $this->get_strings_section();
		if ( $plugin_strings ) {
			$hb_strings[ $this->id . '_strings' ] = $plugin_strings;
		}
		return $hb_strings;
	}

	public function admin_fields() {
		return array();
	}

	public function admin_js_scripts() {
		return array();
	}

	public function js_scripts() {
		return array();
	}

	public function js_data() {
		return array();
	}

	public function css_styles() {
		return array();
	}

	public function check_required_form_fields() {
		$missing_required_customer_fields = array();
		delete_option( 'hb_einvoicing_missing_required_fields' );
		$required_fields = $this->get_invoicing_required_form_fields();
		$customer_fields_ids = $this->hbdb->get_required_customer_form_fields_ids();
		foreach	( $required_fields as $field_id => $field_data ) {
			if ( ! in_array( $field_id, $customer_fields_ids ) ) {
				$missing_required_customer_fields[] = $field_id;
			}
		}
		if ( $missing_required_customer_fields ){
			update_option( 'hb_einvoicing_missing_required_fields', json_encode( $missing_required_customer_fields ) );
		}

		return( $missing_required_customer_fields );
	}

	public function insert_plugin_required_form_fields() {
		global $wpdb;
		$fields = $this->hbdb->get_details_form_fields();
		$result = $wpdb->get_results(
			"
			SELECT MAX( order_num )
			FROM {$this->hbdb->fields_table}
			"
		, ARRAY_A );
		if ( ! $result ) {
			$order_num = 1;
		} else {
			$order_num = $result[0]['MAX( order_num )'] + 1;
		}
		$required_fields = $this->get_invoicing_required_form_fields();
		foreach	( $required_fields as $field_id => $field_info ) {
			$key = array_search( $field_id, array_column( $fields, 'id' ) );
			if ( false === $key ) {
				$has_choices = 0;
				if ( $field_info['type'] == 'radio' ) {
					$has_choices = 1;
				}
				$field_data = array(
					'id' => $field_id ,
					'name' => $field_info['name'],
					'standard' => 0,
					'displayed' => 0,
					'required' => 0,
					'admin_only' => 0,
					'type' => $field_info['type'],
					'has_choices' => $has_choices,
					'order_num' => $order_num,
					'data_about' => 'customer',
					'column_width' => 'full',
				);
				$wpdb->insert( $this->hbdb->fields_table, $field_data );
				$order_num++;
				if ( $has_choices ) {
					foreach( $field_info['choices'] as $choice_name ) {
						$choice_data = array(
							'name' =>$choice_name,
							'field_id' => $field_id
						);
						$wpdb->insert( $this->hbdb->fields_choices_table, $choice_data );
					}
				}
			}
		}
	}

	public function get_invoicing_required_form_fields() {
		return array();
	}

	public function get_invoice_subject( $resa_info, $customer_info, $subject_text ) {
		$hb_strings = $this->utils->get_strings();

		$number_of_nights = $this->utils->get_number_of_nights( $resa_info['check_in'], $resa_info['check_out'] );
		if ( get_option( 'hb_charge_per_day' ) == 'yes' ) {
			$number_of_nights++;
		}
		if ( $number_of_nights > 1 ) {
			$subject_text = str_replace( '%nights_txt', $hb_strings['external_payment_txt_several_nights'], $subject_text );
			$subject_text = str_replace( '%nb_nights', $number_of_nights, $subject_text );
		} else {
			$subject_text = str_replace( '%nights_txt', $hb_strings['external_payment_txt_one_night'], $subject_text );
		}
		$subject_text = str_replace( '%check_in_date', $this->utils->format_date( $resa_info['check_in'] ), $subject_text );
		$subject_text = str_replace( '%check_out_date', $this->utils->format_date( $resa_info['check_out'] ), $subject_text );
		if ( $resa_info['adults'] > 1 ) {
			$subject_text = str_replace( '%adults_txt', $hb_strings['external_payment_txt_several_adults'], $subject_text );
			$subject_text = str_replace( '%nb_adults', $resa_info['adults'], $subject_text );
		} else if ( get_option( 'hb_display_adults_field' ) != 'no' ) {
			$subject_text = str_replace( '%adults_txt', $hb_strings['external_payment_txt_one_adult'], $subject_text );
		} else {
			$subject_text = str_replace( '%adults_txt', '', $subject_text );
		}
		if ( $resa_info['children'] > 0 ) {
			if ( $resa_info['children'] > 1 ) {
				$subject_text = str_replace( '%children_txt', $hb_strings['external_payment_txt_several_children'], $subject_text );
				$subject_text = str_replace( '%nb_children', $resa_info['children'], $subject_text );
			} else {
				$subject_text = str_replace( '%children_txt', $hb_strings['external_payment_txt_one_child'], $subject_text );
			}
		} else {
			$subject_text = str_replace( '%children_txt', '', $subject_text );
		}
		if ( $resa_info['alphanum_id'] ) {
			$subject_text = str_replace( '%alphanum_id', $resa_info['alphanum_id'], $subject_text );
		} else {
			$subject_text = str_replace( '%alphanum_id', '', $subject_text );
		}

		return $subject_text;
	}

	public function create_proforma_invoice( $resa_id, $is_multiple_resa, $origin ) {
		return array();
	}

	public function create_final_invoice_from_proforma( $resa_id, $is_multiple_resa ) {
		return array();
	}

	public function hb_http_api_curl_ssl_version( $handle ) {
		curl_setopt( $handle, CURLOPT_SSLVERSION, 6 );
	}

	public function hb_http_api_curl_timeout( $handle ) {
		curl_setopt( $handle, CURLOPT_TIMEOUT, 0 );
	}

	public function hb_remote_post( $url, $post_args ) {
		$post_args = array_merge( $post_args, array( 'httpversion' => '1.1' ) );
		if ( get_option( 'hb_curl_set_ssl_version' ) == 'yes' ) {
			add_action( 'http_api_curl', array( $this, 'hb_http_api_curl_ssl_version' ) );
		}
		if ( get_option( 'hb_curl_set_timeout' ) == 'yes' ) {
			add_action( 'http_api_curl', array( $this, 'hb_http_api_curl_timeout' ) );
		}
		$response = wp_remote_post( $url, $post_args );
		if ( get_option( 'hb_curl_set_ssl_version' ) == 'yes' ) {
			remove_action( 'http_api_curl', array( $this, 'hb_http_api_curl_ssl_version' ) );
		}
		if ( get_option( 'hb_curl_set_timeout' ) == 'yes' ) {
			remove_action( 'http_api_curl', array( $this, 'hb_http_api_curl_timeout' ) );
		}
		return $response;
	}

	public function hb_remote_request( $url, $args ) {
		$args = array_merge( $args, array( 'httpversion' => '1.1' ) );
		if ( get_option( 'hb_curl_set_ssl_version' ) == 'yes' ) {
			add_action( 'http_api_curl', array( $this, 'hb_http_api_curl_ssl_version' ) );
		}
		if ( get_option( 'hb_curl_set_timeout' ) == 'yes' ) {
			add_action( 'http_api_curl', array( $this, 'hb_http_api_curl_timeout' ) );
		}
		$response = wp_remote_request( $url, $args );
		if ( get_option( 'hb_curl_set_ssl_version' ) == 'yes' ) {
			remove_action( 'http_api_curl', array( $this, 'hb_http_api_curl_ssl_version' ) );
		}
		if ( get_option( 'hb_curl_set_timeout' ) == 'yes' ) {
			remove_action( 'http_api_curl', array( $this, 'hb_http_api_curl_timeout' ) );
		}
		return $response;
	}
}