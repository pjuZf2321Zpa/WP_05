'use strict';

function hb_date_str_2_obj( str_date ) {
	if ( str_date ) {
		var array_date = str_date.split( '-' );
		return new Date( array_date[0], array_date[1] - 1, array_date[2] );
	} else {
		return false;
	}
}

function hb_date_obj_2_str( obj_date ) {
	if ( obj_date ) {
		var y = obj_date.getFullYear(),
			m = obj_date.getMonth() + 1,
			d = obj_date.getDate();
		m = m + '';
		d = d + '';
		if ( m.length == 1 ) {
			m = '0' + m;
		}
		if ( d.length == 1 ) {
			d = '0' + d;
		}
		return y + '-' + m + '-' + d;
	} else {
		return false;
	}
}

function hb_format_date() {
	jQuery( '.hb-format-date' ).each( function() {
		var str_date = jQuery( this ).html();
		if ( str_date.indexOf( '-' ) > -1 ) {
			var date = hb_date_str_2_obj( str_date );
			jQuery( this ).html( jQuery.datepick.formatDate( hb_date_format, date ) ).removeClass( 'hb-format-date' );
		}
	});
}

function hb_get_season_id( date ) {
	var seasons = hb_booking_form_data.seasons,
		nb_day,
		copied_date = new Date( date.valueOf() );

	copied_date.setHours( 0, 0, 0, 0 );

	nb_day = date.getDay();
	if ( nb_day == 0 ) {
		nb_day = 6;
	} else {
		nb_day = nb_day - 1;
	}
	nb_day += '';

	var priorities = ['high', '', 'low'];
	for ( var i = 0; i < 3; i++ ) {
		for ( var j = 0; j < seasons.length; j++ ) {
			var start = hb_date_str_2_obj( seasons[ j ]['start_date'] );
			var end = hb_date_str_2_obj( seasons[ j ]['end_date'] );
			start.setHours( 0, 0, 0, 0 );
			end.setHours( 0, 0, 0, 0 );
			if (
				( seasons[ j ]['priority'] == priorities[ i ] ) &&
				( copied_date >= start ) &&
				( copied_date <= end ) &&
				( seasons[ j ]['days'].indexOf( nb_day ) != -1 )
			) {
				return seasons[ j ]['season_id'];
			}
		}
	}
	return false;
}

function hb_resize_forms() {
	jQuery( '.hb-booking-search-form' ).each( function() {
		var body_class = '';
		if ( jQuery( this ).attr( 'id' ) != '' ) {
			body_class = 'hb-' + jQuery( this ).attr('id') + '-is-vertical';
		}
		if ( jQuery( this ).width() < hb_booking_form_data.horizontal_form_min_width ) {
			jQuery( this ).addClass( 'hb-vertical-search-form' );
			jQuery( this ).removeClass( 'hb-horizontal-search-form' );
			jQuery( 'body' ).addClass( body_class );
		} else {
			jQuery( this ).removeClass( 'hb-vertical-search-form' );
			jQuery( this ).addClass( 'hb-horizontal-search-form' );
			jQuery( 'body' ).removeClass( body_class );
		}
		if ( jQuery( this ).width() < 400 ) {
			jQuery( this ).addClass( 'hb-narrow-search-form' );
		} else {
			jQuery( this ).removeClass( 'hb-narrow-search-form' );
		}
	});
	jQuery( '.hb-booking-details-form' ).each( function() {
		if ( jQuery( this ).width() < hb_booking_form_data.details_form_stack_width ) {
			jQuery( this ).addClass( 'hb-details-form-stacked' );
		} else {
			jQuery( this ).removeClass( 'hb-details-form-stacked' );
		}
	});
}