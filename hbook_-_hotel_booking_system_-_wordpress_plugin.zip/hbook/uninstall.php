<?php

if ( ! defined( 'ABSPATH' ) && ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit();
}

if ( get_option( 'hb_uninstall_delete_all' ) == 'yes' ) {
	require_once plugin_dir_path( __FILE__ ) . 'database-actions/database-actions.php';
	$hbdb = new HbDataBaseActions();
	require_once plugin_dir_path( __FILE__ ) . 'utils/utils.php';
	$utils = new HbUtils( $hbdb, null );
	require_once plugin_dir_path( __FILE__ ) . 'payment/payment-gateway.php';
	require_once plugin_dir_path( __FILE__ ) . 'payment/paypal/paypal.php';
	require_once plugin_dir_path( __FILE__ ) . 'payment/stripe/stripe.php';
	new HbPayPal( $hbdb, null, $utils );
	new HbStripe( $hbdb, null, $utils );

	require_once plugin_dir_path( __FILE__ ) . 'utils/options-utils.php';
	$settings = new HbOptionsUtils( $hbdb, $utils );
	$settings->delete_options();

	delete_option( 'hbook_version' );
	delete_option( 'hbook_previous_version' );
	delete_option( 'hbook_installing' );

	$accom = $hbdb->get_all_accom_ids( true );
	foreach ( $accom as $accom_id ) {
		wp_delete_post( $accom_id, true );
	}
	$hbdb->delete_plugin_tables();
}