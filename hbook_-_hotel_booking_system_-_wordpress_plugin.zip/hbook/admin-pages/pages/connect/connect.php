 <?php
class HbAdminPageConnect extends HbAdminPage {

	public function __construct( $page_id, $hbdb, $utils, $options_utils ) {
		$this->data = array(
			'hb_text' => array()
		);
		parent::__construct( $page_id, $hbdb, $utils, $options_utils );
	}

	public function display() {
	?>

	<div class="wrap">

		<h1><?php esc_html_e( 'HBook Connect', 'hbook-admin' ); ?></h1>

		<hr/>
		<p>
			<a href="<?php echo( esc_html( $this->resources_url['site_url'] ) ); ?>registration/connect/plugin" target="_blank" class="button-primary"><?php esc_html_e( 'Download HBook Connect', 'hbook-admin' ); ?></a>
		</p>
		<br/>
		<h2><?php esc_html_e( 'Maestrel as Google Connectivity Partner', 'hbook-admin' ); ?></h2>
		<p>
			<?php echo( sprintf( esc_html__( 'Maestrel is in the process of becoming a Connectivity Partner for %s and %s.', 'hbook-admin' ), '<b>Google Hotels</b>',  '<b>Google Vacation Rentals</b>' ) ); ?>
		</p>
		<h3><?php esc_html_e( 'What is a Connectivity Partner?', 'hbook-admin' ); ?></h3>
		<p>
			<?php echo( sprintf( esc_html__( 'You need to use a Connectivity Partner to be able to appear on %s and %s with direct booking links to your website.', 'hbook-admin' ), '<b>Google Maps</b>',  '<b>Google Search</b>' ) ); ?>
		</p>
		<p>
			<?php echo( sprintf( esc_html__( 'Here are some advantages of being connected with %s and %s.', 'hbook-admin' ), '<b>Google Hotels</b>',  '<b>Google Vacation Rentals</b>' ) ); ?>
		</p>
		<ul>
			<li>&bullet; <?php esc_html_e( 'Be visible on Google Maps and Google Search', 'hbook-admin' ); ?></li>
			<li>&bullet; <?php esc_html_e( 'Connect automatically your rates and availability with Google', 'hbook-admin' ); ?></li>
			<li>&bullet; <?php esc_html_e( 'Add free booking links to get more direct bookings', 'hbook-admin' ); ?></li>
			<li>&bullet; <?php esc_html_e( 'Highlight on Google what your property offers', 'hbook-admin' ); ?></li>
		</ul>
 		<p>
			<?php esc_html_e( 'For detailed information, please consult the resources listed below.', 'hbook-admin' ); ?>
		</p>
		<h3><?php esc_html_e( 'Register your website and download HBook Connect plugin', 'hbook-admin' ); ?></h3>
		<p>
			<?php echo( sprintf( esc_html__( 'To make the connection between HBook on your website and Maestrel, as Connectivity Partner, you will need to install %s plugin.', 'hbook-admin' ), '<b>HBook Connect</b>' ) ); ?>
			<br/>
			<?php esc_html_e( 'This plugin is available for free from our website. The set up is straightforward and you can refer to the documentation below.', 'hbook-admin' ); ?>
		</p>
		<h3><?php esc_html_e( 'Resources', 'hbook-admin' ); ?></h3>
		<ul>
			<a href="<?php echo( esc_html( $this->resources_url['site_url'] ) ); ?>pricing/#connect-prices" target="_blank"><?php esc_html_e( 'Check Connect Prices', 'hbook-admin' ); ?></a>
			<br/>
			<a href="<?php echo( esc_html( $this->resources_url['doc_url'] ) ); ?>connect/general-information" target="_blank"><?php esc_html_e( 'General information', 'hbook-admin' ); ?></a>
			<br/>
			<a href="<?php echo( esc_html( $this->resources_url['doc_url'] ) ); ?>connect/prior-requirements" target="_blank"><?php esc_html_e( 'Prior requirements', 'hbook-admin' ); ?></a>
 			<br/>
			<a href="<?php echo( esc_html( $this->resources_url['doc_url'] ) ); ?>connect/" target="_blank"><?php esc_html_e( 'Maestrel Connect documentation', 'hbook-admin' ); ?></a>
			<br/>
			<a href="<?php echo( esc_html( $this->resources_url['doc_url'] ) ); ?>connect/hbook-connect-settings" target="_blank"><?php esc_html_e( 'HBook Connect settings', 'hbook-admin' ); ?></a>
		</ul>
	</div><!-- end .wrap -->

	<?php
	}
}