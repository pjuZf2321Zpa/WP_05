<?php
class HbAdminPagePayment extends HbAdminPage {

	public function __construct( $page_id, $hbdb, $utils, $options_utils ) {
		$payment_gateway_ids = array();
		foreach ( $utils->get_payment_gateways() as $payment_gateway ) {
			$payment_gateway_ids[] = $payment_gateway->id;
		}
		$this->data = array(
			'hb_text' => array(
				'deposit_not_valid' => esc_html__( 'The deposit is not valid. Enter a number only.', 'hbook-admin' ),
				'security_bond_not_valid' => esc_html__( 'The security bond is not valid. Enter a number only.', 'hbook-admin' ),
				'deposit_percentage' => esc_html__( 'Deposit percentage', 'hbook-admin' ),
			),
			'hb_payment_gateways' => $payment_gateway_ids,
		);
		parent::__construct( $page_id, $hbdb, $utils, $options_utils );
	}

	public function display() {
	?>

	<div class="wrap">

		<?php $this->display_preparing_section(); ?>

		<form id="hb-settings-form">

			<?php
			if ( get_option( 'hb_admin_fixed_title' ) != 'no' ) {
				$this->display_title_save_section( esc_html__( 'Payment', 'hbook-admin' ), esc_html__( 'All Payment settings have been saved.', 'hbook-admin' ) );
			} else {
			?>
			<h1><?php esc_html_e( 'Payment', 'hbook-admin' ); ?></h1>
			<?php
			}

			$gateway_options = array();
			$gateway_activate_section = array(
				'label' => esc_html__( 'Active payment gateways', 'hbook-admin' ),
				'desc' => sprintf( esc_html__( 'Stripe and PayPal gateways are included. We have developed add-ons to integrate other payment gateways for HBook: %s view available payment gateways %s.', 'hbook-admin' ), '<a href="https://maestrel.com/payment-gateways" target="_blank">', '</a>' ),
				'options' => array()
			);
			foreach ( $this->utils->get_payment_gateways() as $gateway ) {
				if ( ( 'paypal' != $gateway->id ) && ( 'stripe' != $gateway->id ) ) {
					if ( 'yes' != get_option( 'hb_' . $gateway->id . '_valid_purchase_code' ) ) {
						continue;
					}
				}
				$option_id = 'hb_' . $gateway->id .'_active';
				if ( ! get_option( $option_id ) ) {
					update_option( $option_id, 'no' );
				}
				$gateway_activate_section['options'][ $option_id ] = array(
					'label' => sprintf( esc_html__( 'Activate %s', 'hbook-admin' ), esc_html( $gateway->name ) ),
					'type' => 'radio',
					'choice' => array(
						'yes' => esc_html__( 'Yes', 'hbook-admin' ),
						'no' => esc_html__( 'No', 'hbook-admin' ),
					),
					'wrapper-class' => 'hb-payment-gateway-active'
				);
				if ( $gateway->admin_fields() ) {
					$gateway_options[ $gateway->id ] = $gateway->admin_fields();
				}
				foreach ( $gateway->admin_js_scripts() as $js_script ) {
					wp_enqueue_script( $js_script['id'], $js_script['url'], array( 'jquery' ), $js_script['version'], true );
				}
			}

			$payment_setting_sections = $this->options_utils->get_payment_settings();
			$payment_link_section = array( 'payment_link' => $payment_setting_sections['payment_link'] );
			unset( $payment_setting_sections['payment_link'] );

			$payment_setting_sections = array_merge(
				$payment_setting_sections,
				array( 'gateway_activate' => $gateway_activate_section ),
				$gateway_options,
				$payment_link_section,
			);

			foreach ( $payment_setting_sections as $section_id => $section ) {
				$section_class = 'hb-payment-section-' . $section_id;
				if ( $section_id == 'payment_link' ) {
					$section_class .= ' hb-payment-section-stripe';
				}
				?>

				<div class="<?php echo( esc_attr( $section_class ) ); ?>">

				<?php
				$this->options_utils->display_section_title( 'payment', $section_id, $section['label'] );
				if ( isset( $section['desc'] ) && $section['desc'] ) {
					$this->options_utils->display_section_desc( $section['desc'] );
				}
				foreach ( $section['options'] as $id => $option ) {
					if ( $id == 'hb_payment_link_page_id' ) {
						$option['choice'] = $this->get_main_language_pages();
					}
					$function_to_call = 'display_' . $option['type'] . '_option';
					$this->options_utils->$function_to_call( $id, $option );
				}
				if ( get_option( 'hb_admin_fixed_title' ) == 'no' ) {
					$this->options_utils->display_save_options_section( esc_html__( 'All Payment settings have been saved.', 'hbook-admin' ) );
				}
				?>

				</div>

				<?php
			}
			wp_nonce_field( 'hb_nonce_update_db', 'hb_nonce_update_db' );
			?>

			<input type="hidden" name="action" value="hb_update_payment_settings" />
			<input id="hb-nonce" type="hidden" name="nonce" value="" />

		</form>

	</div>
	<?php
	}

	private function get_main_language_pages() {
		$pages = get_pages();
		if ( function_exists( 'pll_get_post' ) ) {
			$default_lang = pll_default_language( 'locale' );
		} else if ( function_exists( 'icl_object_id' ) ) {
			global $sitepress;
			$default_lang = $sitepress->get_locale( $sitepress->get_default_language() );
		}
		$returned_pages = array( 0 => '' );
		foreach ( $pages as $p ) {
			if ( function_exists( 'pll_get_post' ) ) {
				if ( pll_get_post_language( $p->ID, 'locale' ) == $default_lang ) {
					$returned_pages[ $p->ID ] = $p->post_title;
				}
			} else if ( function_exists( 'icl_object_id' ) ) {
				$wpml_post_info = wpml_get_language_information( null, $p->ID );
				if ( is_wp_error( $wpml_post_info ) ) {
					$wpml_post_info = wpml_get_language_information( $p->ID );
				}
				if ( $wpml_post_info['locale'] == $default_lang ) {
					$returned_pages[ $p->ID ] = $p->post_title;
				}
			} else {
				$returned_pages[ $p->ID ] = $p->post_title;
			}
		}
		return $returned_pages;
	}
}