jQuery( document ).ready( function( $ ) {
	'use strict';

	function toggle_notification_option() {
		if ( $( 'input[name="hb_ical_record_sync_errors"]:checked' ).val() == 'yes' ) {
			$( '.hb-ical-notification-option' ).slideDown();
		} else {
			$( '.hb-ical-notification-option' ).slideUp();
		}
	}
	toggle_notification_option();

	function toggle_prices_update_option() {
		if ( $( 'input[name="hb_ical_resa_disable_price_update"]:checked' ).val() == 'yes' ) {
			$( '.hb-ical-resa-included-fees' ).slideUp();
		} else {
			$( '.hb-ical-resa-included-fees' ).slideDown();
		}
	}
	toggle_prices_update_option();


	function toggle_import_blocked_dates_option() {
		if ( $( 'input[name="hb_ical_import_only_resa"]:checked' ).val() == 'yes' ) {
			$( '.hb-ical-import-window-settings' ).slideUp();
		} else {
			$( '.hb-ical-import-window-settings' ).slideDown();
		}
	}
	toggle_import_blocked_dates_option();

	function toggle_export_blocked_dates_option() {
		if ( $( 'input[name="hb_ical_export_blocked_dates"]:checked' ).val() == 'yes' ) {
			$( '.hb-ical-export-preparation-time' ).slideDown();
		} else {
			$( '.hb-ical-export-preparation-time' ).slideUp();
		}
	}
	toggle_export_blocked_dates_option();

	$( '.hb-ical-import-only-resa' ).on( 'change', function() {
		toggle_import_blocked_dates_option();
	});

	$( '.hb-ical-export-blocked-dates' ).on( 'change', function() {
		toggle_export_blocked_dates_option();
	});

	$( '.hb-ical-record-sync-errors' ).on( 'change', function() {
		toggle_notification_option();
	});

	$( '.hb-ical-resa-disable-price-update' ).on( 'change', function() {
		toggle_prices_update_option();
	});

	$( '.ical-export-url-show' ).on( 'click', function() {
		$( this ).parents( 'tr' ).find( '.ical-export-url-value' ).slideDown();
		$( this ).parents( 'tr' ).find( '.ical-export-url-hide' ).show();
		$( this ).hide();
		return false;
	});

	$( '.ical-export-url-hide' ).on( 'click', function() {
		$( this ).parents( 'tr' ).find( '.ical-export-url-value' ).slideUp();
		$( this ).parents( 'tr' ).find( '.ical-export-url-show' ).show();
		$( this ).hide();
		return false;
	});

	$( '.all-icals-export-url' ).on( 'click', function() {
		$( '.all-icals-export-url-value' ).slideToggle();
		return false;
	});

	$( '.ical-upload' ).on( 'click', function() {
		$( this ).parents( 'td' ).find( '.import-ical-form' ).slideToggle();
		return false;
	});

	$( '.ical-upload-cancel' ).on( 'click', function() {
		$( this ).parents( 'tr' ).find( 'td .import-ical-form' ).slideUp();
	});

	$( '.ical-synchro' ).on( 'click', function() {
		if ( $( this ).parents( 'td' ).find( '.add-calendar' ).is( ':visible' ) ) {
			$( this ).parents( 'td' ).find( '.import-url-form' ).slideUp();
			return false;
		}
		$( this ).parents( 'td' ).find( '.hb-external-calendar-text' ).hide();
		$( this ).parents( 'td' ).find( '.hb-add-external-calendar-text' ).show();
		$( this ).parents( 'td' ).find( '.save-changes' ).hide();
		$( this ).parents( 'td' ).find( '.add-calendar' ).show();
		$( this ).parents( 'td' ).find( '.hb-import-calendar-name' ).val( '' );
		$( this ).parents( 'td' ).find( '.hb-import-calendar-url' ).val( '' );
		$( this ).parents( 'td' ).find( '.import-url-form' ).slideDown();
		$( this ).parents( 'td' ).find( '.ical-url-form-action' ).val( 'new-calendar' );
		return false;
	});

	$( '.ical-url-cancel' ).on( 'click', function() {
		$( this ).parents( 'tr' ).find( 'td .import-url-form' ).slideUp();
	});

	$( '.ical-synchro-delete' ).on( 'click', function() {
		if ( confirm( hb_text.confirm_delete ) ) {
			$( this ).parents( 'form' ).submit();
		};
		return false;
	});

	$( '.ical-synchro-edit' ).on( 'click', function() {
		if ( $( this ).parents( 'tr' ).find( '.save-changes' ).is( ':visible' ) ) {
			$( this ).parents( 'tr' ).find( '.import-url-form' ).slideUp();
			return false;
		}
		$( this ).parents( 'tr' ).find( '.hb-external-calendar-text' ).hide();
		$( this ).parents( 'tr' ).find( '.hb-edit-external-calendar-text' ).show();
		$( this ).parents( 'tr' ).find( 'td .add-calendar' ).hide();
		$( this ).parents( 'tr' ).find( 'td .save-changes' ).show();
		$( this ).parents( 'tr' ).find( 'td .import-url-form' ).slideDown();
		$( this ).parents( 'tr' ).find( 'td .ical-url-form-action' ).val( 'edit-calendar' );
		var calendarName = $( this ).parent().find( '.ical-synchro-calendar-name' ).html();
		$( this ).parents( 'tr' ).find( 'td .hb-import-calendar-name' ).val( calendarName );
		var calendarUrl = $( this ).parent().find( '.ical-calendar-url' ).val();
		$( this ).parents( 'tr' ).find( 'td .hb-import-calendar-url' ).val( calendarUrl );
		$( this ).parents( 'tr' ).find( 'td .edit-calendar-url' ).val( calendarUrl );
		var calendarId = $( this ).parent().find( '.ical-calendar-id' ).val();
		$( this ).parents( 'tr' ).find( 'td .edit-calendar-id' ).val( calendarId );
		return false;
	});

	$( '#hb-preparing' ).hide();
	$( '.hb-page-hidden-on-preparing' ).fadeIn();
	$( window ).scroll();
});