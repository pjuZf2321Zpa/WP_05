jQuery( document ).ready( function( $ ) {
	'use strict';

	hide_show_invoicing_service_options();

	$( '.hb-invoicing-service-active input' ).on( 'change', function() {
		hide_show_invoicing_service_options();
	});

	function hide_show_invoicing_service_options() {
		for ( var i = 0; i < hb_invoicing_services.length; i++ ) {
			if ( $( 'input[name=hb_' + hb_invoicing_services[i] + '_active]:checked' ).val() == 'yes' ) {
				$( '.hb-invoicing-section-' + hb_invoicing_services[i] ).slideDown();
			} else {
				$( '.hb-invoicing-section-' + hb_invoicing_services[i] ).slideUp();
			}
		}
	}

	setTimeout( function() {
		$( '#hb-preparing' ).hide();
		$( '#hb-settings-form' ).fadeIn();
		$( window ).scroll();
	}, 400 );
});