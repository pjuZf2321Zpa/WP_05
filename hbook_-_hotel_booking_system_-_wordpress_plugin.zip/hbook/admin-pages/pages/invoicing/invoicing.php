<?php
class HbAdminPageInvoicing extends HbAdminPage {

	public function __construct( $page_id, $hbdb, $utils, $options_utils ) {
		$invoicing_services_ids = array();
		foreach ( $utils->get_invoicing_services() as $invoicing_service ) {
			$invoicing_service_ids[] = $invoicing_service->id;
		}
		$this->data = array(
			'hb_text' => array(),
			'hb_invoicing_services' => $invoicing_service_ids,
		);
		parent::__construct( $page_id, $hbdb, $utils, $options_utils );
	}

	public function display() { ?>

	<div class="wrap">

		<?php $this->display_preparing_section();

		foreach ( $this->utils->get_invoicing_services() as $service ) {
			$missing_required_fields_ids = $service->check_required_form_fields();
			if ( $missing_required_fields_ids ) {
				$missing_fields = implode( ', ', $missing_required_fields_ids );
			?>
				<div class="hb-einvoincing-missing-fields-msg hb-notice hb-warning-msg">
					<p>
					<?php
					printf(
						esc_html__( 'The following fields are required for the e-invoices: %s. In %sHBook > Details form%s, please make sure you have set these fields as required and displayed.', 'hbook-admin' ),
						$missing_fields,
						'<b>',
						'</b>'
					);
					?>
					</p>
				</div>
		<?php
			}
		}
		?>

		<form id="hb-settings-form">

			<?php
			if ( get_option( 'hb_admin_fixed_title' ) != 'no' ) {
				$this->display_title_save_section( esc_html__( 'E-invoicing', 'hbook-admin' ), esc_html__( 'All E-invoicing settings have been saved.', 'hbook-admin' ) );
			} else {
			?>
			<h1><?php esc_html_e( 'E-invoicing', 'hbook-admin' ); ?></h1>
			<?php
			}

			$service_options = array();
			$service_activate_section = array(
				'label' => esc_html__( 'Activate e-invoicing services', 'hbook-admin' ),
				'options' => array()
			);
			foreach ( $this->utils->get_invoicing_services() as $service ) {
				$option_id = 'hb_' . $service->id .'_active';
				if ( ! get_option( $option_id ) ) {
					update_option( $option_id, 'no' );
				}

				$service_activate_section['options'][ $option_id ] = array(
					'label' => sprintf( esc_html__( 'Activate %s', 'hbook-admin' ), esc_html( $service->name ) ),
					'type' => 'radio',
					'choice' => array(
						'yes' => esc_html__( 'Yes', 'hbook-admin' ),
						'no' => esc_html__( 'No', 'hbook-admin' ),
					),
					'wrapper-class' => 'hb-invoicing-service-active'
				);

				if ( $service->admin_fields() ) {
					$service_options[ $service->id ] = $service->admin_fields();
				}

				foreach ( $service->admin_js_scripts() as $js_script ) {
					wp_enqueue_script( $js_script['id'], $js_script['url'], array( 'jquery' ), $js_script['version'], true );
				}

			}

			$invoicing_setting_sections = array_merge(
				array( 'service_activate' => $service_activate_section ),
				$service_options,
			);

			foreach ( $invoicing_setting_sections as $section_id => $section ) {
				$section_class = 'hb-invoicing-section-' . $section_id;
				?>

				<div class="<?php echo( esc_attr( $section_class ) ); ?>">

				<?php
				$this->options_utils->display_section_title( 'invoicing', $section_id, $section['label'] );
				if ( isset( $section['desc'] ) && $section['desc'] ) {
					$this->options_utils->display_section_desc( $section['desc'] );
				}
				foreach ( $section['options'] as $id => $option ) {
					$function_to_call = 'display_' . $option['type'] . '_option';
					$this->options_utils->$function_to_call( $id, $option );
				}
				if ( get_option( 'hb_admin_fixed_title' ) == 'no' ) {
					$this->options_utils->display_save_options_section( esc_html__( 'All e-invoicing settings have been saved.', 'hbook-admin' ) );
				}
				?>

				</div>

				<?php
			}
			wp_nonce_field( 'hb_nonce_update_db', 'hb_nonce_update_db' );
			?>

			<input type="hidden" name="action" value="hb_update_invoicing_settings" />
			<input id="hb-nonce" type="hidden" name="nonce" value="" />

		</form>

	</div>
	<?php
	}
}