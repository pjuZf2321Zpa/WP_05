jQuery( document ).ready( function( $ ) {
	'use strict';

	var page_is_ready = false;

	var adminbar_height = 0;
	if ( $( '#wpadminbar' ).length ) {
		adminbar_height = $( '#wpadminbar' ).height();
	}

	var title_section_height = 0;
	if ( $( '#hb-title-save-section' ).is( ':visible' ) ) {
		title_section_height = $( '#hb-title-save-section' ).height();
	}

	$( '#hb-sections-list-fixed' ).css( 'display', 'block' );
	$( '#hb-sections-list-fixed' ).css( 'width', 'auto' );
	var section_list_width = $( '#hb-sections-list-fixed' ).width();
	section_list_width += 20;
	$( '#hb-sections-list-fixed' ).width( section_list_width );
	$( '#hb-sections-list-fixed' ).css( 'display', 'none' );

	$( window ).on( 'scroll', function() {
		if ( $( '#hb-title-save-section' ).is( ':visible' ) ) {
			title_section_height = $( '#hb-title-save-section' ).height();
		}
		sections_list_update();
	}).scroll();

	$( window ).on( 'resize', hb_debouncer( function () {
		adminbar_height = 0;
		if ( $( '#wpadminbar' ).length && ( $( '#wpadminbar' ).css( 'position' ) == 'fixed' ) ) {
			adminbar_height = $( '#wpadminbar' ).height();
		}
		sections_list_update();
	}));

	function sections_list_update() {
		if (
			( $( window ).scrollTop() + adminbar_height + title_section_height > $( '#hb-misc-sections' ).offset().top ) &&
			( $( window ).width() > 650 ) &&
			page_is_ready
		) {
			$( '#hb-sections-list-fixed' ).show();
			$( '#hb-sections-list-fixed' ).css( 'top', adminbar_height + title_section_height + 'px' );
			var current_section = '';
			$( '.hb-misc-section-link' ).each( function() {
				var section_pos = $( $( this ).attr( 'href' ) ).offset().top;
				if ( $( window ).scrollTop() + adminbar_height + title_section_height > section_pos - 20 ) {
					current_section = $( this ).attr( 'href' );
				}
			});
			$( '.hb-current-misc-section' ).removeClass( 'hb-current-misc-section' );
			$( '#hb-sections-list-fixed a[href="' + current_section + '"]' ).addClass( 'hb-current-misc-section' );
		} else {
			$( '#hb-sections-list-fixed' ).hide();
		}
	}

	$( '.hb-misc-section-link' ).on( 'click', function() {
		$( this ).blur();
		let target_section_pos = $( $( this ).attr( 'href' ) ).offset().top;
		let top = target_section_pos - adminbar_height - title_section_height - 10;
		$( 'html, body' ).animate({ scrollTop: top });
		window.location.hash = $( this ).attr( 'href' );
		return false;
	});

	$( 'select[name="hb_resa_page_default_filter"]' ).on( 'change', function() {
		resa_page_default_filter();
	});

	resa_page_default_filter();

	function resa_page_default_filter() {
		$( '.hb-resa-page-default-filter-option' ).slideUp();
		var new_filter_val = $( 'select[name="hb_resa_page_default_filter"]' ).val();
		switch ( new_filter_val ) {
			case 'check_in_date':
			case 'check_out_date':
			case 'check_in_out_date':
			case 'active_resa_date':
				$( '.hb-resa-page-default-filter-' + new_filter_val.replace( '_date', '' ).replaceAll( '_', '-' ) + '-from' ).slideDown();
				$( '.hb-resa-page-default-filter-' + new_filter_val.replace( '_date', '' ).replaceAll( '_', '-' ) + '-to' ).slideDown();
				break;
			case 'accom':
			case 'status':
				$( '.hb-resa-page-default-filter-' + new_filter_val ).slideDown();
				break;
		}
		$( '.hb-toggle-default-filters').addClass( 'hb-view-all-active' );
	}

	$( '.hb-toggle-default-filters-link' ).on( 'click', function() {
		if ( $( '.hb-toggle-default-filters').hasClass( 'hb-view-all-active' ) ) {
			$( '.hb-resa-page-default-filter-option' ).slideDown();
			$( '.hb-toggle-default-filters').removeClass( 'hb-view-all-active' );
		} else {
			resa_page_default_filter();
		}
		return false;
	});

	$( 'input[name="hb_multiple_accom_booking"]' ).on( 'change', function() {
		multiple_accom_booking();
	});

	multiple_accom_booking();

	function multiple_accom_booking() {
		if ( $( 'input[name="hb_multiple_accom_booking"]:checked' ).val() == 'enabled' ) {
			$( '.hb-multiple-accom-booking-options-wrapper' ).slideDown();
		} else {
			$( '.hb-multiple-accom-booking-options-wrapper' ).slideUp();
			$( '#hb_multiple_accom_booking_front_end_disabled' ).prop( 'checked', true );
		}
	}

	$( 'input[name="hb_multiple_accom_booking_suggest_occupancy"]' ).on( 'change', function() {
		suggest_occupancy_type();
	});

	suggest_occupancy_type();

	function suggest_occupancy_type() {
		if ( $( 'input[name="hb_multiple_accom_booking_suggest_occupancy"]:checked' ).val() == 'normal' ) {
			$( '.hb-multiple-accom-booking-avoid-singleton' ).slideDown();
		} else {
			$( '.hb-multiple-accom-booking-avoid-singleton' ).slideUp();
		}
	}

	$( 'input[name="hb_specific_admin_date_settings"]' ).on( 'change', function() {
		specific_admin_date_settings();
	});

	specific_admin_date_settings();

	function specific_admin_date_settings() {
		if ( $( 'input[name="hb_specific_admin_date_settings"]:checked' ).val() == 'yes' ) {
			$( '.hb-specific-admin-date-settings' ).slideDown();
		} else {
			$( '.hb-specific-admin-date-settings' ).slideUp();
		}
	}

	$( '#hb-create-accom-var' ).on( 'click', function() {
		$( this ).blur();
		var var_name = $( '#hb-accom-var-name' ).val();
		if ( ! var_name ) {
			alert( hb_text.insert_var_name );
			$( '#hb-accom-var-name' ).focus();
			return false;
		}
		var regexp = /^[a-z0-9_\-]+$/i;
		if ( ! regexp.test( var_name ) ) {
			alert( hb_text.invalid_var_name );
			return false;
		}
		var vars_list_json = $( '#hb-accom-custom-vars' ).val();
		var vars_list = JSON.parse( vars_list_json );
		if ( vars_list.indexOf( var_name ) > -1 ) {
			alert( hb_text.accom_var_already_exists );
			return false;
		}
		vars_list.push( var_name );
		$( '#hb-accom-custom-vars' ).val( JSON.stringify( vars_list ) );
		var var_mark_up = $( '.hb-accom-template-var' ).html();
		var_mark_up = var_mark_up.replaceAll( '@template', var_name );
		$( '#hb-accom-vars-list' ).append( var_mark_up );
		$( '#hb-accom-var-name' ).val( '' );
		return false;
	});

	$( '#hb-accom-vars-list' ).on( 'click', '.hb-delete-accom-var', function() {
		var var_to_delete = $( this ).parents( '.hb-accom-var' ).data( 'accom-var-name' );
		if ( confirm( hb_text.confirm_delete_accom_var.replace( '%s', var_to_delete ) ) ) {
			$( this ).parents( '.hb-accom-var' ).remove();
			var vars_list_json = $( '#hb-accom-custom-vars' ).val();
			var vars_list = JSON.parse( vars_list_json );
			vars_list = vars_list.filter( var_name => var_name != var_to_delete );
			$( '#hb-accom-custom-vars' ).val( JSON.stringify( vars_list ) );
			hb_form_saved = false;
		}
		return false;
	});

	$( '.hb-import-settings-button' ).on( 'click', function() {
		$( this ).blur();
		$( '.hb-import-settings-wrapper' ).slideToggle();
		return false;
	});

	$( '#hb-import-settings-launch' ).on( 'click', function() {
		$( '#hb-import-settings-launch' ).blur();
		if ( $( '#hb-import-settings-launch' ).hasClass( 'disabled' ) ) {
			return false;
		}
		$( '.hb-import-settings-error' ).hide();
		if ( $( '#hb-import-settings-file' ).val() == '' ) {
			alert( hb_text.choose_file );
			return false;
		}
		var confirm_text = hb_text.import_confirm_text_overwrite_resa;
		if ( $( '#hb-excluded-imported-setting-resa' ).is( ':checked' ) ) {
			confirm_text = hb_text.import_confirm_text;
		}
		if ( ! confirm( confirm_text ) ) {
			return false;
		}

		$( '.hb-import-existing-posts-error' ).hide();
		var file_data = $('#hb-import-settings-file').prop('files')[0];
		var form_data = new FormData();
		form_data.append( 'action', 'hb_import_settings' );
		form_data.append( 'nonce', $( '#hb_nonce_update_db' ).val() );
		form_data.append( 'hb_import_settings_file', file_data );
		if ( $( '#hb-import-settings-modify-id' ).is( ':checked' ) ) {
			form_data.append( 'hb_import_settings_modify_id', 'yes' );
		}
		$( '.hb-excluded-import-setting' ).each( function() {
			if ( $( this ).is( ':checked' ) ) {
				form_data.append( 'hb_excluded_import_export_settings_' + $( this ).data( 'excluded-setting-name' ), 'yes' );
			}
		});
		$( '.hb-import-settings-waiting-msg' ).slideDown();
		$( '#hb-import-settings-launch' ).addClass( 'disabled' );
		$.ajax({
			type: 'POST',
			timeout: hb_ajax_settings.timeout,
			url: ajaxurl,
			data: form_data,
			processData: false,
			contentType: false,
			success: function( ajax_return ) {
				try {
					var response = JSON.parse( ajax_return );
				} catch ( e ) {
					$( '#hb-import-settings-launch' ).removeClass( 'disabled' );
					$( '.hb-import-settings-waiting-msg' ).hide();
					$( '.hb-import-settings-error' ).html( hb_text['import_file_error'] + '. <br/>' + ajax_return ).slideDown();
					return false;
				}
				if ( response.status == 'import_file_error') {
					$( '#hb-import-settings-launch' ).removeClass( 'disabled' );
					$( '.hb-import-settings-waiting-msg' ).hide();
					$( '.hb-import-settings-error' ).html( hb_text['import_file_error'] + ' (' + response.error_msg + ').' ).slideDown();
					return false;
				}
				if ( response.status == 'existing_posts' ) {
					$( '#hb-import-settings-launch' ).removeClass( 'disabled' );
					$( '.hb-import-settings-waiting-msg' ).hide();
					var existing_posts_markup = '';
					for ( var post_id in response.existing_posts ) {
						existing_posts_markup += '<li>';
						existing_posts_markup += response.existing_posts[ post_id ].title;
						existing_posts_markup += ' (ID: ';
						existing_posts_markup += post_id;
						existing_posts_markup += ') - (';
						existing_posts_markup += response.existing_posts[ post_id ].name;
						existing_posts_markup += ' / ';
						existing_posts_markup += response.existing_posts[ post_id ].type;
						existing_posts_markup += ')';
						existing_posts_markup += '</li>';
					}
					$( '.hb-import-existing-posts-list' ).html( existing_posts_markup );
					$( '.hb-import-existing-posts-error' ).slideDown();
					return false;
				}
				window.location.href = document.URL.split( '#' )[0];
			},
			error: function( jqXHR, textStatus, errorThrown ) {
				$( '.hb-import-settings-waiting-msg' ).slideUp();
				$( '#hb-import-settings-launch' ).removeClass( 'disabled' );
				console.log( jqXHR );
				alert( textStatus + ' (' + errorThrown + ')' )
			}
		});
		return false;
	});

	$( '.hb-export-settings-button' ).on( 'click', function() {
		$( this ).blur();
		$( '#hb-import-export-action' ).val( 'export-settings' );
		$( '#hb-settings-form' ).submit();
		$( '#hb-import-export-action' ).val( '' );
		return false;
	});

	$( '.hb-toggle-export-excluded-settings-choose' ).on( 'click', function() {
		$( '.hb-excluded-exported-settings-list' ).slideToggle();
		return false;
	});

	$( '.hb-toggle-import-excluded-settings-choose' ).on( 'click', function() {
		$( '.hb-excluded-imported-settings-list' ).slideToggle();
		return false;
	});

	$( '.hb-import-excluded-settings-select-all' ).on( 'click', function() {
		$( this ).hide();
		$( '.hb-import-excluded-settings-unselect-all' ).show();
		$( '.hb-excluded-import-setting' ).prop( 'checked', true );
		return false;
	});

	$( '.hb-import-excluded-settings-unselect-all' ).on( 'click', function() {
		$( this ).hide();
		$( '.hb-import-excluded-settings-select-all' ).show();
		$( '.hb-excluded-import-setting' ).prop( 'checked', false );
		return false;
	});

	$( '.hb-export-excluded-settings-select-all' ).on( 'click', function() {
		$( this ).hide();
		$( '.hb-export-excluded-settings-unselect-all' ).show();
		$( '.hb-excluded-export-setting' ).prop( 'checked', true );
		return false;
	});

	$( '.hb-export-excluded-settings-unselect-all' ).on( 'click', function() {
		$( this ).hide();
		$( '.hb-export-excluded-settings-select-all' ).show();
		$( '.hb-excluded-export-setting' ).prop( 'checked', false );
		return false;
	});

	$( '.hb-reset-hbook' ).on( 'click', function() {
		$( '.hb-reset-hbook' ).blur();
		var $reset_div_wrapper = $( this ).closest('div');
		var reset_type = $reset_div_wrapper.attr('id');
		if ( confirm( hb_text[ reset_type + '_confirm_text' ] ) ) {
			$reset_div_wrapper.find( '.hb-reset-ajaxing' ).show();
			$.ajax({
				url: ajaxurl,
				type: 'POST',
				data: {
					'action': 'hb_reset',
					'reset_type': reset_type,
					'nonce': $( '#hb_nonce_update_db' ).val()
				},
				timeout: hb_ajax_settings.timeout,
				success: function( ajax_return ) {
					if ( ajax_return.trim() == 'reset_done' ) {
						if ( reset_type == 'hb-reset-all' ) {
							window.location.href = document.URL.split( '#' )[0];
							return false;
						}
						$reset_div_wrapper.find( '.hb-reset-ajaxing' ).hide();
						$reset_div_wrapper.find( '.hb-reset-success-msg' ).fadeIn( function() {
							setTimeout( function() {
								$reset_div_wrapper.find( '.hb-reset-success-msg' ).fadeOut();
							}, 4000 );
						});
					} else {
						$reset_div_wrapper.find( '.hb-reset-ajaxing' ).hide();
						alert( ajax_return );
					}
				},
				error: function( jqXHR, textStatus, errorThrown ) {
					$reset_div_wrapper.find( 'hb-reset-ajaxing' ).hide();
					alert( textStatus + ' (' + errorThrown + ')' )
				}
			});
		}
		return false;
	});

	setTimeout( function() {
		$( '#hb-preparing' ).hide();
		$( '#hb-settings-form' ).fadeIn( function() {
			let hash = window.location.hash;
			if ( hash ) {
				let target_section_pos = $( hash ).offset().top;
				let top = target_section_pos - adminbar_height - title_section_height - 10;
				$( 'html, body' ).animate({ scrollTop: top });
			}
		});
		page_is_ready = true;
		$( window ).scroll();
	}, 400 );
});