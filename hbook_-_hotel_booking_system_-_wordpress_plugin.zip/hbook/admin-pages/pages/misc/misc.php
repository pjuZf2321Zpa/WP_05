<?php
class HbAdminPageMisc extends HbAdminPage {

	private $date_formats;
	private $langs;

	public function __construct( $page_id, $hbdb, $utils, $options_utils ) {
		$this->data = array(
			'hb_text' => array(
				'date_not_valid' => esc_html__( 'The date is not valid (use a yyyy-mm-dd format).', 'hbook-admin' ),
				'insert_var_name' => esc_html__( 'Enter a variable name.', 'hbook-admin' ),
				'invalid_var_name' => esc_html__( 'The variable name is invalid. Use only characters, numbers, dashes or underscores.', 'hbook-admin' ),
				'accom_var_already_exists' => esc_html__( 'This variable already exists.', 'hbook-admin' ),
				'confirm_delete_accom_var' => esc_html__( 'Delete custom accommodation variable [%s]?', 'hbook-admin' ),
				'choose_file' => esc_html__( 'Choose a file to import.', 'hbook-admin' ),
				'import_file_error' => esc_html__( 'Could not import file', 'hbook-admin' ),
				'import_confirm_text' => esc_html__( 'Importing a setting file will overwrite current HBook settings (including Accommodation Posts). Do you want to continue?', 'hbook-admin' ),
				'import_confirm_text_overwrite_resa' => esc_html__( 'Importing a setting file will overwrite current HBook settings (including Accommodation Posts and Reservations). Do you want to continue?', 'hbook-admin' ),
				'hb-reset-all_confirm_text' => esc_html__( 'This action will reset all settings and delete permanently all accommodation posts, customers, reservations, and blocked dates. Reservations and customers numbering will be reset. Do you wish to continue?', 'hbook-admin' ),
				'hb-delete-customers-reservations-blocked-accom_confirm_text' => esc_html__( 'This action will delete permanently all customers, reservations, and blocked dates. Reservations and customers numbering will be reset. Do you wish to continue?', 'hbook-admin' ),
				'hb-delete-reservations-blocked-accom_confirm_text' => esc_html__( 'This action will delete permanently all reservations and blocked dates. Reservations numbering will be reset. Do you wish to continue?', 'hbook-admin' ),
				'hb-delete-external-resa_confirm_text' => esc_html__( 'This action will delete permanently all reservations that have been imported into HBook via the iCal synchronization. Do you wish to continue?', 'hbook-admin' ),
				'hb-delete-cancelled-resa_confirm_text' => esc_html__( 'This action will delete permanently all reservations that have the status "Cancelled". Do you wish to continue?', 'hbook-admin' ),
				'hb-delete-past-resa_confirm_text' => esc_html__( 'This action will delete permanently all past reservations. Do you wish to continue?', 'hbook-admin' ),
				'hb-delete-past-blocked-accom_confirm_text' => esc_html__( 'This action will delete permanently all past block dates. Do you wish to continue?', 'hbook-admin' ),
			)
		);
		$this->date_formats = array(
			'mm/dd/yyyy',
			'dd/mm/yyyy',
			'dd.mm.yyyy',
			'dd-mm-yyyy',
			'yyyy/mm/dd',
			'dd-mm-yyyy',
			'dd.mm.yyyy',
			'yyyy-mm-dd',
		);
		$this->langs = $utils->get_langs();
		parent::__construct( $page_id, $hbdb, $utils, $options_utils );
	}

	public function display() {
		$misc_settings = $this->options_utils->get_misc_settings();
	?>

	<div class="wrap">

		<div id="hb-sections-list-fixed">
			<ul>
				<?php foreach ( $misc_settings as $section_id => $section ) { ?>
					<li><a class="hb-misc-section-link" href="<?php echo( esc_url( '#hb_misc_' .  $section_id ) ); ?>"><?php echo( esc_html( $section['label'] ) ); ?></a></li>
				<?php } ?>
			</ul>
		</div>

		<?php $this->display_preparing_section(); ?>

		<form id="hb-settings-form" method="POST">

			<?php
			if ( get_option( 'hb_admin_fixed_title' ) != 'no' ) {
				$this->display_title_save_section( esc_html__( 'Miscellaneous', 'hbook-admin' ), esc_html__( 'Settings have been saved.', 'hbook-admin' ) );
			} else {
			?>
			<h1><?php esc_html_e( 'Miscellaneous', 'hbook-admin' ); ?></h1>
			<?php
			}
			?>

			<hr/>

			<?php
			if ( get_option( 'hb_settings_reset' ) == 'yes' ) {
				?>
				<div class="hb-reset-success">
					<p><?php esc_html_e( 'All settings have been reset.', 'hbook-admin' ); ?></p>
				</div>
				<?php
				delete_option( 'hb_settings_reset' );
			}

			if ( get_option( 'hb_settings_imported' ) == 'yes' ) {
				?>
				<div class="hb-import-success">
					<p><?php esc_html_e( 'HBook settings have been imported.', 'hbook-admin' ); ?></p>
					<?php
					$existing_posts = get_option( 'hb_importer_existing_posts' );
					if ( $existing_posts ) {
						?>
						<p>
							<?php
							if ( count( $existing_posts ) > 1 ) {
								esc_html_e( 'Please take note that the following Accommodation Posts have new IDs:', 'hbook-admin' );
							} else {
								esc_html_e( 'Please take note that the following Accommodation Post has a new ID:', 'hbook-admin' );
							}
							?>
							<ul class="hb-import-existing-posts-list">
							<?php foreach ( $existing_posts as $existing_post_id => $existing_post ) { ?>
								<li>
									<?php echo( esc_html( $existing_post['targeted_accom_name'] ) ); ?>
									<?php echo( ' (ID: ' . $existing_post_id . ' => ' . $existing_post['new_id'] . ')' ); ?>
								</li>
							<?php } ?>
							</ul>
							<?php esc_html_e( 'You may have to update HBook shortcodes accordingly.', 'hbook-admin' ); ?>
						</p>
					<?php } ?>
				</div>
				<?php
				delete_option( 'hb_settings_imported' );
			}
			?>

			<div id="hb-sections-list">
				<ul>
					<?php foreach ( $misc_settings as $section_id => $section ) { ?>
						<li><a class="hb-misc-section-link" href="<?php echo( esc_url( '#hb_misc_' .  $section_id ) ); ?>"><?php echo( esc_html( $section['label'] ) ); ?></a></li>
					<?php } ?>
				</ul>
			</div>

			<div id="hb-misc-sections">

			<?php
			foreach ( $misc_settings as $section_id => $section ) {
				$this->options_utils->display_section_title( 'misc', $section_id, $section['label'] );
				foreach ( $section['options'] as $id => $option ) {
					if ( $id == 'hb_front_end_date_settings' ) {
						$this->display_date_format_settings();
					} else if ( $id == 'hb_accom_custom_vars' ) {
						$this->display_accom_vars_settings();
					} else if ( $id == 'hb_import_export_settings' ) {
						$this->display_import_export_settings();
					} else if ( $id == 'hb_reset_settings' ) {
						$this->display_reset_settings();
					} else if ( $id == 'hb_specific_admin_date_settings' ) {
						$this->display_admin_date_settings();
					} else if ( ( $id != 'hb_admin_date_settings_date_format' ) && ( $id != 'hb_admin_date_settings_first_day' ) ) {
						$function_to_call = 'display_' . $option['type'] . '_option';
						$this->options_utils->$function_to_call( $id, $option );
					}
					if ( $id == 'hb_multiple_accom_booking' ) {
						echo( '<div class="hb-multiple-accom-booking-options-wrapper">' );
					} else if ( $id == 'hb_multiple_accom_booking_suggestions' ) {
						echo( '</div><!-- end .hb-multiple-accom-booking-options-wrapper -->' );
					}
					if ( $id == 'hb_resa_page_default_filter' ) {
					?>
						<div class="hb-toggle-default-filters hb-view-all-active">
							<small class="hb-toggle-default-filters-link hb-view-filters-default-values">
								<a href="#"><?php esc_html_e( 'View all filters default values', 'hbook-admin' ); ?></a>
							</small>
							<small class="hb-toggle-default-filters-link hb-hide-filters-default-values">
								<a href="#"><?php esc_html_e( 'Hide filters default values', 'hbook-admin' ); ?></a>
							</small>
						</div>
					<?php
					}
				}
				if ( get_option( 'hb_admin_fixed_title' ) == 'no' ) {
					$this->options_utils->display_save_options_section( esc_html__( 'All Miscellaneous settings have been saved.', 'hbook-admin' ) );
				}
			}
			?>

			</div><!-- end #hb-misc-sections -->

			<input type="hidden" name="action" value="hb_update_misc_settings" />
			<input id="hb-nonce" type="hidden" name="nonce" value="" />

			<?php wp_nonce_field( 'hb_nonce_update_db', 'hb_nonce_update_db' ); ?>

		</form>
	</div>

	<?php
	}

	private function display_date_format_settings() {
		$saved_settings = json_decode( get_option( 'hb_front_end_date_settings' ), true );
		require_once $this->utils->plugin_directory . '/utils/date-localization.php';
		$date_locale_info = new HbDateLocalization();
		$days = $date_locale_info->locale[ $this->utils->get_hb_known_locale() ]['day_names'];

		foreach ( $this->langs as $locale => $lang_name ) {
			$hb_known_locale = $this->utils->get_hb_known_locale( $locale );
			$default_first_day = $date_locale_info->locale[ $hb_known_locale ]['first_day'];
			if ( isset( $saved_settings[ $locale ]['first_day'] ) ) {
				$current_first_day = $saved_settings[ $locale ]['first_day'];
			} else {
				$current_first_day = $default_first_day;
			}

			$default_format = $date_locale_info->locale[ $hb_known_locale ]['date_format'];
			if ( isset( $saved_settings[ $locale ]['date_format'] ) ) {
				$current_format = $saved_settings[ $locale ]['date_format'];
			} else {
				$current_format = $default_format;
			}
			$days_select_options = '';
			foreach ( $days as $i => $day ) {
				if ( $i == $current_first_day ) {
					$selected = ' selected';
				} else {
					$selected = '';
				}
				$days_select_options .= '<option value="' . $i . '"' . $selected . '>' . $day . '</option>';
			}
			$format_select_options = '';
			foreach ( $this->date_formats as $format ) {
				if ( $format == $current_format ) {
					$selected = ' selected';
				} else {
					$selected = '';
				}
				$format_select_options .= '<option' . $selected . '>' . $format . '</option>';
			}

			if ( sizeof( $this->langs ) > 1 ) {
			?>
				<h4><u><?php echo( esc_html( $lang_name ) ); ?></u> <small>(<?php echo( esc_html( $locale ) ); ?>)</small></h4>
				<small>
				<?php
				printf(
					esc_html__( 'Usual setting: first day is %s and date format is %s', 'hbook-admin' ),
					'<b>' . esc_html( $days[ $default_first_day ] ) . '</b>',
					'<b>' . esc_html( $default_format ) . '</b>'
				);
				?>
				</small>
			<?php
			}
			?>

			<div class="hb-lang-settings" data-locale="<?php echo( esc_attr( $locale ) ); ?>">

				<p>
					<label><?php esc_html_e( 'First day of the week', 'hbook-admin' ); ?></label><br/>
					<select class="hb-first-day">
						<?php
						echo( wp_kses(
							$days_select_options,
							array( 'option' => array( 'value' => array(), 'selected' => array() ) )
						) );
						?>
					</select>
				</p>

				<p>
					<label><?php esc_html_e( 'Date format', 'hbook-admin' ); ?></label><br/>
					<select class="hb-date-format">
						<?php
						echo( wp_kses(
							$format_select_options,
							array( 'option' => array( 'value' => array(), 'selected' => array() ) )
						) );
						?>
					</select>
				</p>

			</div>

			<?php
		}
		?>

		<input type="hidden" id="hb_front_end_date_settings" name="hb_front_end_date_settings" value="" />

		<?php
	}

	private function display_admin_date_settings() {
		require_once $this->utils->plugin_directory . '/utils/date-localization.php';
		$date_locale_info = new HbDateLocalization();
		$days = $date_locale_info->locale[ $this->utils->get_hb_known_locale( get_user_locale() ) ]['day_names'];
		$days_select_options = '';
		foreach ( $days as $i => $day ) {
			if ( $i == get_option( 'hb_admin_date_settings_first_day' ) ) {
				$selected = ' selected';
			} else {
				$selected = '';
			}
			$days_select_options .= '<option value="' . $i . '"' . $selected . '>' . $day . '</option>';
		}
		$format_select_options = '';
		foreach ( $this->date_formats as $format ) {
			if ( $format == get_option( 'hb_admin_date_settings_date_format' ) ) {
				$selected = ' selected';
			} else {
				$selected = '';
			}
			$format_select_options .= '<option' . $selected . '>' . $format . '</option>';
		}
		?>

		<p>
			<label <?php if ( sizeof( $this->langs ) > 1 ) { echo( 'class="hb-date-settings-underlined-label"' ); } ?>>
				<?php esc_html_e( 'Set specific dates settings for admin', 'hbook-admin' ); ?>
			</label>
			<br>
			<input
				type="radio"
				id="hb_specific_admin_date_settings_yes"
				name="hb_specific_admin_date_settings"
				value="yes"
				<?php if ( get_option( 'hb_specific_admin_date_settings' ) == 'yes' ) { echo('checked'); } ?>
			/>
			<label for="hb_specific_admin_date_settings_yes"><?php esc_html_e( 'Yes', 'hbook-admin' ); ?></label>&nbsp;&nbsp;
			<input
				type="radio"
				id="hb_specific_admin_date_settings_no"
				name="hb_specific_admin_date_settings"
				value="no"
				<?php if ( get_option( 'hb_specific_admin_date_settings' ) == 'no' ) { echo('checked'); } ?>
			/>
			<label for="hb_specific_admin_date_settings_no"><?php esc_html_e( 'No', 'hbook-admin' ); ?></label>
		</p>

		<div class="hb-specific-admin-date-settings">
			<p>
				<label><?php esc_html_e( 'First day of the week for admin', 'hbook-admin' ); ?></label><br/>
				<select name="hb_admin_date_settings_first_day" class="hb-first-day">
					<?php
					echo( wp_kses(
						$days_select_options,
						array( 'option' => array( 'value' => array(), 'selected' => array() ) )
					) );
					?>
				</select>
			</p>

			<p>
				<label><?php esc_html_e( 'Date format for admin', 'hbook-admin' ); ?></label><br/>
				<select name="hb_admin_date_settings_date_format" class="hb-date-format">
					<?php
					echo( wp_kses(
						$format_select_options,
						array( 'option' => array( 'value' => array(), 'selected' => array() ) )
					) );
					?>
				</select>
			</p>
		</div>

		<p style="line-height: 0.7">&nbsp;</p>

		<?php
	}

	private function display_accom_vars_settings() {
		$accom_vars_json = get_option( 'hb_accom_custom_vars', '[]' );
		$accom_vars = json_decode( $accom_vars_json, true );
		$accom_vars[] = '@template';
		?>
		<label><?php esc_html_e( 'Accommodation custom variables', 'hbook-admin' ); ?></label><br/>
		<small><?php esc_html_e( 'You can create variables that may be used in Email templates, Documents templates, and iCal exports.', 'hbook-admin' ); ?></small>
		<p>
		<div id="hb-accom-vars-list">
			<?php
			foreach ( $accom_vars as $accom_var ) {
				if ( $accom_var == '@template' ) {
				?>
				<p class="hb-accom-template-var">
				<?php
				}
				?>
				<span class="hb-accom-var" data-accom-var-name="<?php echo( esc_attr( $accom_var ) ); ?>">
					<span><?php echo( esc_html( $accom_var ) ); ?></span>
					<a href="#" class="hb-delete-accom-var dashicons dashicons-dismiss" title="<?php esc_attr_e( 'Delete custom variable', 'hbook-admin' ); ?>"></a>
				</span>
				<?php
				if ( $accom_var == '@template' ) {
				?>
				</p>
				<?php
				}
			}
			?>
		</div>
		<p>
			<label for="hb-accom-var-name"><?php esc_html_e( 'Variable name', 'hbook-admin' ); ?></label><br/>
			<input id="hb-accom-var-name" type="text" />
		</p>
		<p id="hb-create-accom-var-wrapper">
			<a id="hb-create-accom-var" href="#" class="button-primary"><?php esc_html_e( 'Create variable', 'hbook-admin' ); ?></a>
		</p>
		<input id="hb-accom-custom-vars" name="hb_accom_custom_vars" type="hidden" value="<?php echo( esc_attr( $accom_vars_json ) ); ?>" />
		<?php
	}

	private function display_reset_settings() {
		$reset_options = array(
			'hb-reset-all' => array(
				'button_label' => esc_html__( 'Reset HBook', 'hbook-admin' ),
			),
			'hb-delete-customers-reservations-blocked-accom' => array(
				'button_label' => esc_html__( 'Delete customers, reservations, and blocked dates', 'hbook-admin' ),
				'success_msg' => esc_html__( 'Customers, reservations, and blocked dates have been deleted.', 'hbook-admin' ),
			),
			'hb-delete-reservations-blocked-accom' => array(
				'button_label' => esc_html__( 'Delete reservations and blocked dates', 'hbook-admin' ),
				'success_msg' => esc_html__( 'Blocked dates and reservations have been deleted.', 'hbook-admin' ),
			),
			'hb-delete-external-resa' => array(
				'button_label' => esc_html__( 'Delete only reservations imported from external calendars', 'hbook-admin' ),
				'success_msg' => esc_html__( 'Reservations imported from external calendars have been deleted.', 'hbook-admin' ),
			),
			'hb-delete-cancelled-resa' => array(
				'button_label' => esc_html__( 'Delete only reservations with status "Cancelled"', 'hbook-admin' ),
				'success_msg' => esc_html__( 'Reservations with status "Cancelled" have been deleted.', 'hbook-admin' ),
			),
			'hb-delete-past-resa' => array(
				'button_label' => esc_html__( 'Delete only past reservations', 'hbook-admin' ),
				'success_msg' => esc_html__( 'Past reservations have been deleted.', 'hbook-admin' ),
			),
			'hb-delete-past-blocked-accom' => array(
				'button_label' => esc_html__( 'Delete only past blocked dates', 'hbook-admin' ),
				'success_msg' => esc_html__( 'Past blocked dates have been deleted.', 'hbook-admin' ),
			),
		);
		?>
		<small><?php esc_html_e( 'None of the actions below can be rolled back. Reservations, blocked dates or/and customers will be deleted permanently.', 'hbook-admin' ); ?></small>
		<div class="hb-reset-settings-wrapper">
			<?php
			foreach ( $reset_options as $id => $text ) {
				if ( ( $id == 'hb-reset-all' ) && ( get_option( 'hbook_status' ) != 'dev' ) && ( get_option( 'hb_show_reset_all' ) != 'yes' ) ) {
					continue;
				}
			?>
			<div id="<?php echo( esc_attr( $id ) ); ?>">
				<p>
					<a href="#" class="hb-reset-hbook button"><?php echo( esc_html( $text['button_label'] ) ); ?></a>
					<span class="hb-reset-ajaxing">
						<span class="spinner"></span>
						<?php
						if ( $id == 'hb-reset-all' ) {
							esc_html_e( 'Resetting HBook...', 'hbook-admin' );
						} else {
							esc_html_e( 'Deleting...', 'hbook-admin' );
						}
						?>
					</span>
				</p>
				<?php if ( $id != 'hb-reset-all' ) { ?>
				<p class="hb-reset-success-msg"><?php echo( esc_html( $text['success_msg'] ) ); ?></p>
				<?php } ?>
			</div>
			<?php
			}
			?>
		</div>

	<?php
	}

	private function display_import_export_settings() {
		$excluded_settings = array(
			'resa' => esc_html__( 'Reservations / Customers ', 'hbook-admin' ),
			'accom_blocked' => esc_html__( 'Blocked accommodation', 'hbook-admin' ),
			'forms' => esc_html__( 'Forms settings', 'hbook-admin' ),
			'payment' => esc_html__( 'Payment settings', 'hbook-admin' ),
			'ical' => esc_html__( 'iCal', 'hbook-admin' ),
			'emails' => esc_html__( 'Emails / Documents templates', 'hbook-admin' ),
			'appearance' => esc_html__( 'Appearance', 'hbook-admin' ),
			'text' => esc_html__( 'Text / Translations', 'hbook-admin' ),
			'misc' => esc_html__( 'Miscellaneous settings', 'hbook-admin' ),
		);
		?>

		<div class="hb-import-export-settings-wrapper">
			<p>
				<a href="#" class="hb-import-settings-button button"><?php esc_html_e( 'Import', 'hbook-admin' ); ?></a>
			</p>
			<div class="hb-import-settings-wrapper">
				<p>
					<input id="hb-import-settings-file" class="hb-not-setting" type="file" name="hb-import-settings-file" />
				</p>
				<p class="hb-import-settings-waiting-msg">
					<span class="spinner"></span>
					<?php esc_html_e( 'Importing settings may take several minutes. Please do not refresh or exit this page before completion.', 'hbook-admin' ); ?>
				</p>
				<div class="hb-import-settings-error"></div>
				<div class="hb-import-existing-posts-error">
					<div class="hb-import-existing-posts-error-msg">
						<p>
							<b><?php esc_html_e( 'Settings could not be imported.', 'hbook-admin' ); ?></b>
						</p>
						<p>
							<?php esc_html_e( 'The following posts/pages/attachments prevented HBook from importing the settings:', 'hbook-admin' ); ?>
							<ul class="hb-import-existing-posts-list"></ul>
							<?php esc_html_e( 'You can either delete these posts/pages/attachments (which is the recommanded method) or start importing again with the "Modify Accommodation Post ID" option activated.', 'hbook-admin' ); ?>
						</p>
					</div>
					<p>
						<input type="checkbox" id="hb-import-settings-modify-id" name="hb-import-settings-modify-id" class="hb-not-setting" />
						<label for="hb-import-settings-modify-id"><?php esc_html_e( 'Modify Accommodation Post ID when importing (you may have to update HBook shortcodes accordingly).', 'hbook-admin' ); ?></label>
					</p>
				</div>
				<p>
					<a id="hb-import-settings-launch" href="#" class="button-primary"><?php esc_html_e( 'Import settings file', 'hbook-admin' ); ?></a>
				</p>
				<p>
					<small class="hb-toggle-import-excluded-settings-choose">
						<a href="#"><?php esc_html_e( 'Exclude settings from being imported', 'hbook-admin' ); ?></a>
					</small>
				</p>
				<div class="hb-excluded-imported-settings-list">
					<?php foreach ( $excluded_settings as $excluded_setting_id => $excluded_setting_label ) { ?>
						<input
							id="<?php echo( esc_attr( 'hb-excluded-imported-setting-' . $excluded_setting_id ) ); ?>"
							class="hb-excluded-import-export-setting hb-excluded-import-setting hb-not-setting"
							data-excluded-setting-name="<?php echo( esc_attr( $excluded_setting_id ) ); ?>"
							type="checkbox"
						/>
						<label for="<?php echo( esc_attr( 'hb-excluded-imported-setting-' . $excluded_setting_id ) ); ?>"><?php echo( esc_html( $excluded_setting_label ) ); ?></label>
						<br/>
					<?php } ?>
					<p>
						<small class="hb-import-excluded-settings-select-all">
							<a href="#"><?php esc_html_e( 'Select all', 'hbook-admin' ); ?></a>
						</small>
						<small class="hb-import-excluded-settings-unselect-all">
							<a href="#"><?php esc_html_e( 'Unselect all', 'hbook-admin' ); ?></a>
						</small>
					</p>
				</div>
			</div>
			<p>
				<a href="#" class="hb-export-settings-button button-primary"><?php esc_html_e( 'Export settings file', 'hbook-admin' ); ?></a>
			</p>
			<p>
				<small class="hb-toggle-export-excluded-settings-choose">
					<a href="#"><?php esc_html_e( 'Exclude settings from being exported', 'hbook-admin' ); ?></a>
				</small>
			</p>
			<div class="hb-excluded-exported-settings-list">
				<?php foreach ( $excluded_settings as $excluded_setting_id => $excluded_setting_label ) { ?>
					<input
						id="<?php echo( esc_attr( 'hb-excluded-setting-' . $excluded_setting_id ) ); ?>"
						class="hb-excluded-import-export-setting hb-excluded-export-setting hb-not-setting"
						name="<?php echo( esc_attr( 'hb_excluded_import_export_settings_' . $excluded_setting_id ) ); ?>"
						type="checkbox"
					/>
					<label for="<?php echo( esc_attr( 'hb-excluded-setting-' . $excluded_setting_id ) ); ?>"><?php echo( esc_html( $excluded_setting_label ) ); ?></label>
					<br/>
				<?php } ?>
				<p>
					<small class="hb-export-excluded-settings-select-all">
						<a href="#"><?php esc_html_e( 'Select all', 'hbook-admin' ); ?></a>
					</small>
					<small class="hb-export-excluded-settings-unselect-all">
						<a href="#"><?php esc_html_e( 'Unselect all', 'hbook-admin' ); ?></a>
					</small>
				</p>
			</div>
			<input type="hidden" id="hb-import-export-action" name="hb-import-export-action" value="" />
			<?php wp_nonce_field( 'hb_export', 'hb_export' ); ?>
		</div>

	<?php
	}
}