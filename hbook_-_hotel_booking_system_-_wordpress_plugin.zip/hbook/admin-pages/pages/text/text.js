jQuery( document ).ready( function( $ ) {
	'use strict';

	$( '#hb-import-file-form' ).on( 'submit', function() {
		$( '#hb-import-lang-submit' ).blur();
		if ( $( '#hb-import-lang-code' ).val() == '' ) {
			alert( hb_text.select_language );
			return false;
		}
		if ( $( '#hb-import-lang-file' ).val() == '' ) {
			alert( hb_text.choose_file );
			return false;
		}
	});

	$( '.hb-export-lang-file' ).on( 'click', function() {
		$( this ).blur();
		$( '#hb-locale-export' ).val( $( this ).data( 'locale' ) );
		$( '#hb-export-lang-form' ).submit();
		return false;
	});

	$( '#hb-untranslated-strings' ).prop( 'checked', false );
	$( '#hb-untranslated-strings' ).change( function() {
		if ( this.checked ) {
			$( '.hb-translated-string' ).slideUp();
			$( '.hb-translated-section' ).slideUp();
		} else {
			$( '.hb-translated-string' ).slideDown();
			$( '.hb-translated-section' ).slideDown();
		}
	} );

	var save_msg_timeout;
	var form_submitting = false;
	var saving_error;

	$( '#hb-front-end-strings-form' ).on( 'submit', function() {
		saving_error = false;
		$( '.hb-strings-section-submit-button' ).blur();
		if ( form_submitting ) {
			return false;
		}
		form_submitting = true;
		$( '.hb-saved' ).hide();
		$( '.hb-strings-section-submit-button' ).prop( 'disabled', true );
		$( '.hb-ajaxing' ).css( 'display', 'inline' );
		$( '#hb-action' ).val( 'hb_update_strings' );
		$( '#hb-nonce' ).val( $( '#hb_nonce_update_db' ).val() );
		save_lang( hb_locales[ 0 ] );
		return false;
	});

	function save_lang( locale ) {
		$.ajax({
			data: $( '#hb-action, #hb-nonce, #hb-front-end-strings-form .hb-string-in-' + locale ).serialize(),
			url: ajaxurl,
			type: 'POST',
			timeout: hb_ajax_settings.timeout,
			success: function( ajax_return ) {
				if ( ajax_return.trim() != 'strings_saved' ) {
					console.log( ajax_return );
					saving_error = true;
				}
				if ( hb_locales.indexOf( locale ) == hb_locales.length - 1 ) {
					form_submitting = false;
					$( '.hb-strings-section-submit-button' ).prop( 'disabled', false );
					$( '.hb-ajaxing' ).css( 'display', 'none' );
					if ( saving_error ) {
						alert( hb_text.saving_error );
					} else {
						form_saved = true;
						$( '.hb-saved' ).show();
						clearTimeout( save_msg_timeout );
						save_msg_timeout = setTimeout( function() {
							$( '.hb-saved' ).fadeOut();
						}, 4000 );
					}
				} else {
					save_lang( hb_locales[ hb_locales.indexOf( locale ) + 1 ] );
				}
			},
			error: function( jqXHR, textStatus, errorThrown ) {
				form_submitting = false;
				$( '#hb-strings-section-submit-button' ).prop( 'disabled', false );
				$( '.hb-ajaxing' ).css( 'display', 'none' );
				alert( 'Connection error: ' + errorThrown );
			}
		});
	}

	var form_saved = true;

	$( '#hb-front-end-strings-form input').on( 'change', function() {
		form_saved = false;
	});

	window.onbeforeunload = function() {
		if ( ! form_saved ) {
			return hb_text.unsaved_warning;
		}
	}

	var adminbar_height = 0;
	if ( $( '#wpadminbar' ).length && ( $( '#wpadminbar' ).css( 'position' ) == 'fixed' ) ) {
		adminbar_height = $( '#wpadminbar' ).height();
	}
	var title_section_height = 0;
	if ( $( '#hb-strings-title-section-fixed' ).is( ':visible' ) ) {
		title_section_height = $( '#hb-strings-title-section-fixed' ).height();
	}

	$( window ).on( 'scroll', function() {
		if ( $( '#hb-strings-title-section-fixed' ).is( ':visible' ) ) {
			title_section_height = $( '#hb-strings-title-section-fixed' ).height();
		}
		strings_title_section_update();
		text_sections_list_update();
	}).scroll();

	$( window ).on( 'resize', hb_debouncer( function () {
		adminbar_height = 0;
		if ( $( '#wpadminbar' ).length && ( $( '#wpadminbar' ).css( 'position' ) == 'fixed' ) ) {
			adminbar_height = $( '#wpadminbar' ).height();
		}
		if ( $( '#hb-strings-title-section-fixed' ).is( ':visible' ) ) {
			title_section_height = $( '#hb-strings-title-section-fixed' ).height();
		}
		strings_title_section_update();
		text_sections_list_update();
	}));

	function strings_title_section_update() {
		if ( $( window ).scrollTop() + adminbar_height > $( '#hb-front-end-strings-form' ).offset().top ) {
			var admin_menu_width = 0;
			if ( $( '#adminmenuwrap' ).is( ':visible' ) ) {
				admin_menu_width = $( '#adminmenuwrap' ).width();
			}
			$( '#hb-strings-title-section-fixed' ).show();
			$( '#hb-strings-title-section-fixed' ).css( 'top', adminbar_height + 'px' );
			$( '#hb-strings-title-section-fixed' ).css( 'left', admin_menu_width + 'px' );
		} else {
			$( '#hb-strings-title-section-fixed' ).hide();
		}
		if (
			( $( window ).scrollTop() + adminbar_height + title_section_height > $( '.hb-strings-section' ).first().offset().top ) &&
			( $( window ).width() > 650 )
		) {
			$( '#hb-text-sections-list-fixed' ).show();
			$( '#hb-text-sections-list-fixed' ).css( 'top', adminbar_height + title_section_height + 'px' );
		} else {
			$( '#hb-text-sections-list-fixed' ).hide();
		}
	}

	function text_sections_list_update() {
		var current_section = '';
		$( '.hb-text-section-link' ).each( function() {
			var section_pos = $( $( this ).attr( 'href' ) ).offset().top;
			if ( $( window ).scrollTop() + adminbar_height + title_section_height > section_pos - 20 ) {
				current_section = $( this ).attr( 'href' );
			}
		});
		$( '.hb-current-text-section' ).removeClass( 'hb-current-text-section' );
		$( 'a[href="' + current_section + '"]' ).addClass( 'hb-current-text-section' );
	}

	$( '.hb-text-section-link' ).on( 'click', function() {
		$( this ).blur();
		let target_section_pos = $( $( this ).attr( 'href' ) ).offset().top;
		let top = target_section_pos - adminbar_height - title_section_height - 10;
		$( 'html, body' ).animate({ scrollTop: top });
		return false;
	});
} );