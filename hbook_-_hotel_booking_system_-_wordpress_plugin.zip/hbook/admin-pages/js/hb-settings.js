'use strict';

function hb_section_toggle( section_name ) {
	var section_id = '#hb-' + section_name,
		section_toggle_id = section_id + '-toggle';
	jQuery( section_toggle_id ).on( 'click', function() {
		if ( ( section_name == 'admin-add-resa' ) && ( ! jQuery( section_id ).is( ':visible' ) ) ) {
			jQuery( section_id ).show();
			hb_resize_forms();
			jQuery( section_id ).hide();
		}
		jQuery( section_id ).slideToggle( function() {
			if ( jQuery( this ).is( ':visible' ) ) {
				jQuery( section_toggle_id + ' .dashicons-arrow-up' ).css( 'display', 'inline-block' );
				jQuery( section_toggle_id + ' .dashicons-arrow-down' ).hide();
			} else {
				jQuery( section_toggle_id + ' .dashicons-arrow-down' ).css( 'display', 'inline-block' );
				jQuery( section_toggle_id + ' .dashicons-arrow-up' ).hide();
			}
		});
		return false;
	});
}

function hb_decode_entities( str ) {
	if ( ! str ) {
		return '';
	}
	var textarea = document.createElement( 'textarea' );
	textarea.innerHTML = str;
	return textarea.value;
}

function hb_debouncer( func ) {
	var timeoutID,
		timeout = 50;
	return function () {
		var scope = this,
			args = arguments;
		clearTimeout( timeoutID );
		timeoutID = setTimeout( function () {
			func.apply( scope, Array.prototype.slice.call( args ) );
		}, timeout );
	}
}