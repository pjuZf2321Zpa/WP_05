<?php

/**
 * Render WhatsApp/share buttons for the block cart using current cart + targeting rules.
 *
 * @return string
 */
function fma_oow_render_cart_block_button_html() {
	if ( ! class_exists( 'WooCommerce' ) ) {
		return '';
	}

	global $woocommerce;
	if ( ! isset( $woocommerce->cart ) || ! is_object( $woocommerce->cart ) ) {
		return '';
	}

	$fma_oow_selected_icon = get_option('fma_oow_icons', '0');
	$fma_oow_def_icon_chk = get_option('fma_oow_def_icon_chk', 'off');
	if ('off' == $fma_oow_def_icon_chk) {
		// this function will generate css for icons
		fma_oow_icons_css();
	}
	$fma_oow_enable_only_for_customer = get_option('fma_oow_enable_only_for_customers');
	if ('yes' == $fma_oow_enable_only_for_customer) {
		if (true != is_user_logged_in()) {
			return '';
		}
	}
	global $woocommerce;
	$fma_find_the_device = fma_order_on_whatsapp_find_device();
	$fma_oow_where_to_open_whatsapp = fma_oow_open_whatsapp_in_which_tab(); // where to open whatsapp
	$fma_order_on_whatsapp_number = get_option('fma_order_on_whatsapp_whatsapp_number', true);
	$fma_order_on_whatsapp_items = $woocommerce->cart->get_cart();
	if (!fma_oow_cart_has_targeted_products($fma_order_on_whatsapp_items)) {
		return '';
	}
	$fma_oow_show_share_btn_or_not = fma_oow_show_share_btn_or_not();
	$fma_order_on_whatsapp_total_expense = $woocommerce->cart->get_cart_contents_total();
	$fma_oow_share_btn_bg_color = get_option('fma_oow_share_btn_bg_color');
	$fma_oow_share_btn_text_color = get_option('fma_oow_share_btn_text_color');
	$fma_oow_share_btn_txt = WpmlHelper::translate((string) get_option('fma_oow_share_btn_txt'), 'saved_fma_oow_share_btn_txt');
	$fma_oow_msg_when_whatsap_opens = WpmlHelper::translate((string) get_option('fma_oow_msg_when_whatsap_opens'), 'saved_fma_oow_msg_when_whatsap_opens');
	$fma_oow_share_msg_when_whatsap_opens = WpmlHelper::translate((string) get_option('fma_oow_share_msg_when_whatsap_opens'), 'saved_fma_oow_share_msg_when_whatsap_opens');
	$fma_oow_mbl_or_dsktp = fma_order_on_whatsapp_find_device(); // find the browser
	// BG color for share button
	if (empty($fma_oow_share_btn_bg_color)) {
		$fma_oow_share_btn_bg_color = '#25d366';
	}
	// text color for share button
	if (empty($fma_oow_share_btn_text_color)) {
		$fma_oow_share_btn_text_color = '#ffff';
	}
	$fma_order_on_whatsapp_show_on_cart_page = get_option('fma_order_on_whatsapp_show_on_cart_page', true);
	$fma_order_on_whatsapp_share_show_btn_on_cart_page = get_option('fma_order_on_whatsapp_share_show_btn_on_cart_page', true);
	$fma_order_on_whatsapp_cart_btn_bg_color = get_option('fma_order_on_whatsapp_cart_btn_bg_color_hash');
	$fma_order_on_whatsapp_cart_btn_text_color_hash = get_option('fma_order_on_whatsapp_cart_btn_text_color_hash');
	if (empty($fma_order_on_whatsapp_cart_btn_bg_color)) {
		$fma_order_on_whatsapp_cart_btn_bg_color = '#25d366';
	}
	if (empty($fma_order_on_whatsapp_cart_btn_text_color_hash)) {
		$fma_order_on_whatsapp_cart_btn_text_color_hash = '#ffff';
	}
	$whatsapp_btn_border_clr_hash = get_option('whatsapp_btn_border_clr_hash');
	$whatsapp_btn_border_clr_width = get_option('whatsapp_btn_border_clr_width');
	if (empty($whatsapp_btn_border_clr_hash)) {
		$whatsapp_btn_border_clr_hash = '#25d366';
	}
	if (empty($whatsapp_btn_border_clr_width)) {
		$whatsapp_btn_border_clr_width = 0;
	}
	$share_btn_border_clr_hash = get_option('share_btn_border_clr_hash');
	$share_btn_border_clr_width = get_option('share_btn_border_clr_width');
	if (empty($share_btn_border_clr_hash)) {
		$share_btn_border_clr_hash = '#25d366';
	}
	if (empty($share_btn_border_clr_width)) {
		$share_btn_border_clr_width = 0;
	}

	$fma_oow_cart_share_url = fma_oow_build_cart_share_url(
		$fma_order_on_whatsapp_items,
		$fma_order_on_whatsapp_total_expense,
		$fma_order_on_whatsapp_number,
		$fma_oow_share_msg_when_whatsap_opens
	);

	ob_start();
	include FMA_OOW_PLUGIN_DIR . 'front-end/views/fma-oow-cart-block-whatsApp-and-share-button.php';
	return ob_get_clean();
}
