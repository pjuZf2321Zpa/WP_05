<?php
/**
 * WPML string translation for hardcoded plugin strings in arrays/variables.
 */
class WpmlHelper {


	public function __construct() {
	}


	/**
	 * Whether WordPress translation APIs are safe to use (after_setup_theme).
	 *
	 * @return bool
	 */
	private static function is_translation_ready() {
		return did_action( 'after_setup_theme' ) || doing_action( 'after_setup_theme' );
	}

	/**
	 * Check whether WPML String Translation is available.
	 *
	 * @return bool
	 */
	public static function is_wpml_active() {
		return defined( 'ICL_SITEPRESS_VERSION' )
			|| function_exists( 'wpml_register_single_string' )
			|| function_exists( 'icl_register_string' );
	}

	/**
	 * Backward-compatible alias.
	 *
	 * @return bool
	 */
	public static function is_wcml_active() {
		return self::is_wpml_active();
	}

	/**
	 * Translated settings section label for the admin UI.
	 *
	 * @param string $section Section key.
	 * @return string
	 */
	public static function get_settings_section_label( $section ) {
		$labels = array(
			'general_settings'    => __( 'General Settings', 'customized-thank-you-pages' ),
			'payments_methods'    => __( 'Payment Methods', 'customized-thank-you-pages' ),
			'table_customization' => __( 'Table Customization', 'customized-thank-you-pages' ),
			'shortcodes'          => __( 'Shortcodes', 'customized-thank-you-pages' ),
		);

		$label = $labels[ $section ] ?? ucwords( str_replace( '_', ' ', (string) $section ) );

		return self::wpml_translate_string( $label, 'settings_section_' . $section );
	}

	/**
	 * Whether a saved setting value should be registered/translated with WPML.
	 *
	 * @param string       $field_key Field identifier.
	 * @param array        $field_def Field schema.
	 * @param string|mixed $value     Saved value.
	 * @return bool
	 */
	public static function should_register_saved_value( $field_key, $field_def, $value ) {
		if ( ! is_string( $value ) || '' === trim( $value ) ) {
			return false;
		}

		if ( self::is_non_translatable_value( $value ) || is_numeric( $value ) ) {
			return false;
		}

		if ( self::is_color_field( $field_key, $field_def ) || self::is_number_field( $field_key, $field_def ) ) {
			return false;
		}

		if ( self::is_url_input_field( $field_key ) || self::is_payment_gateway_label_field( $field_key ) ) {
			return false;
		}

		if ( isset( $field_def['type'] ) && in_array( $field_def['type'], array( 'checkbox', 'select', 'color', 'number', 'text-readonly' ), true ) ) {
			return false;
		}

		if ( preg_match( '/^[\[\{]/', $value ) || preg_match( '/^\[.+\]$/', $value ) ) {
			return false;
		}

		$slug_values = array(
			'custom_wordpress_page',
			'external_url',
			'product_page',
			'category_page',
			'Custom_WordPress_Page',
			'External_URL',
			'product',
			'category',
			'default',
			'same_as_parent',
			'on',
			'off',
			'Lighter',
			'Normal',
			'Bold',
			'Bolder',
		);

		if ( in_array( $value, $slug_values, true ) ) {
			return false;
		}

		return isset( $field_def['type'] ) && 'text' === $field_def['type'];
	}

	/**
	 * Register admin-saved text settings with WPML on backend save only.
	 *
	 * @param array  $data    Saved section data (value-key format).
	 * @param array  $schema  Default field schema.
	 * @param string $prefix  Key prefix.
	 * @return void
	 */
	public static function register_saved_settings_values( $data, $schema, $prefix = '' ) {
		if ( ! is_array( $data ) || ! is_array( $schema ) ) {
			return;
		}

		foreach ( $schema as $field_key => $field_def ) {
			if ( ! is_array( $field_def ) || ! array_key_exists( $field_key, $data ) ) {
				continue;
			}

			$full_key = '' !== $prefix ? $prefix . '_' . $field_key : (string) $field_key;
			$incoming = $data[ $field_key ];

			if ( isset( $field_def['type'] ) || array_key_exists( 'value', $field_def ) ) {
				$value = is_array( $incoming ) && array_key_exists( 'value', $incoming )
					? $incoming['value']
					: $incoming;

				if ( is_string( $value ) && self::should_register_saved_value( $field_key, $field_def, $value ) ) {
					self::register_string( $value, 'saved_' . $full_key );
				}
				continue;
			}

			if ( is_array( $incoming ) ) {
				self::register_saved_settings_values( $incoming, $field_def, $full_key );
			}
		}
	}

	/**
	 * Whether a value is a URL — never register or translate via WPML.
	 *
	 * @param string $string Value to check.
	 * @return bool
	 */
	public static function is_url_value( $string ) {
		$string = trim( (string) $string );
		if ( '' === $string ) {
			return false;
		}
		if ( filter_var( $string, FILTER_VALIDATE_URL ) ) {
			return true;
		}
		if ( preg_match( '/^(https?:\/\/|\/\/)/i', $string ) ) {
			return true;
		}
		return (bool) preg_match( '/^[a-z0-9][a-z0-9.-]*\.[a-z]{2,}(\/[^\s]*)?$/i', $string );
	}

	/**
	 * Whether a value is a color (hex/rgba) — never register or translate via WPML.
	 *
	 * @param string $string Value to check.
	 * @return bool
	 */
	public static function is_color_value( $string ) {
		$string = trim( (string) $string );
		if ( '' === $string ) {
			return false;
		}
		if ( preg_match( '/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/', $string ) ) {
			return true;
		}
		return (bool) preg_match( '/^rgba?\(/i', $string );
	}

	/**
	 * Whether a settings field is a color picker (labels/values excluded from WPML).
	 *
	 * @param string $field_key Field identifier.
	 * @param array  $field     Field config.
	 * @return bool
	 */
	public static function is_color_field( $field_key, $field = array() ) {
		if ( isset( $field['type'] ) && 'color' === $field['type'] ) {
			return true;
		}
		$field_key = (string) $field_key;
		return (bool) preg_match( '/(^|_)color(s)?($|_)/i', $field_key )
			|| (bool) preg_match( '/(^|_)colour(s)?($|_)/i', $field_key );
	}

	/**
	 * Whether a value is numeric (sizes, priority, counts) — never register or translate via WPML.
	 *
	 * @param string $string Value to check.
	 * @return bool
	 */
	public static function is_numeric_value( $string ) {
		$string = trim( (string) $string );
		if ( '' === $string ) {
			return false;
		}
		if ( is_numeric( $string ) ) {
			return true;
		}
		return (bool) preg_match( '/^\d+(\.\d+)?(px|em|rem|%)?$/i', $string );
	}

	/**
	 * Values that must never pass through WPML (colors, numbers).
	 *
	 * @param string $string Value to check.
	 * @return bool
	 */
	public static function is_non_translatable_value( $string ) {
		return self::is_color_value( $string ) || self::is_numeric_value( $string ) || self::is_url_value( $string );
	}

	/**
	 * Whether a field stores numeric input (font size, priority, border width, etc.).
	 *
	 * @param string $field_key Field identifier.
	 * @param array  $field     Field config.
	 * @return bool
	 */
	public static function is_number_field( $field_key, $field = array() ) {
		if ( isset( $field['type'] ) && 'number' === $field['type'] ) {
			return true;
		}
		$field_key = (string) $field_key;
		return (bool) preg_match( '/(^|_)(priority|font_size|border_radius|border_width|select_priority)($|_)/i', $field_key );
	}

	/**
	 * Payment gateway section label (gateway title from WooCommerce — not a plugin string).
	 *
	 * @param string $field_key Field identifier.
	 * @return bool
	 */
	public static function is_payment_gateway_label_field( $field_key ) {
		return (bool) preg_match( '/_custom_page_url$/', (string) $field_key );
	}

	/**
	 * Select options populated from posts/terms (product, category, page names).
	 *
	 * @param string $field_key Field identifier.
	 * @param array  $field     Field config.
	 * @return bool
	 */
	public static function has_dynamic_options( $field_key, $field = array() ) {
		if ( ! isset( $field['options'] ) || ! is_array( $field['options'] ) ) {
			return false;
		}
		foreach ( array_keys( $field['options'] ) as $option_key ) {
			if ( is_numeric( $option_key ) ) {
				return true;
			}
		}
		$field_key = (string) $field_key;
		$patterns  = array(
			'_select_product',
			'custom_product',
			'_select_category',
			'custom_category',
			'_custom_pages',
			'custom_page',
			'wordpress_page',
		);
		foreach ( $patterns as $pattern ) {
			if ( false !== strpos( $field_key, $pattern ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * External URL text inputs (saved values and example URLs are not WPML strings).
	 *
	 * @param string $field_key Field identifier.
	 * @return bool
	 */
	public static function is_url_input_field( $field_key ) {
		$field_key = (string) $field_key;
		return 'set_global_custom_URl' === $field_key
			|| false !== strpos( $field_key, 'external_url' )
			|| false !== strpos( $field_key, 'custom_URl' );
	}

	/**
	 * Field description HTML: translated text plus a literal URL example (never WPML).
	 *
	 * @param array $field Field config.
	 * @return string
	 */
	public static function get_field_description_html( $field ) {
		$desc = $field['description'] ?? $field['desc'] ?? '';
		$has_content = '' !== $desc
			|| ! empty( $field['description_url_example'] )
			|| ! empty( $field['description_placeholders_example'] )
			|| ! empty( $field['description_link'] );
		if ( ! $has_content ) {
			return '';
		}

		$html = esc_html( $desc );
		if ( ! empty( $field['description_placeholders_example'] ) && is_string( $field['description_placeholders_example'] ) ) {
			$html .= ' <code>' . esc_html( $field['description_placeholders_example'] ) . '</code>';
		}
		if ( ! empty( $field['description_after_placeholders'] ) && is_string( $field['description_after_placeholders'] ) ) {
			$html .= esc_html( $field['description_after_placeholders'] );
		}
		if ( ! empty( $field['description_url_example'] ) && is_string( $field['description_url_example'] ) ) {
			$html .= ' <code>' . esc_html( $field['description_url_example'] ) . '</code>';
		}
		if ( ! empty( $field['description_url_suffix'] ) && is_string( $field['description_url_suffix'] ) ) {
			$html .= esc_html( $field['description_url_suffix'] );
		}
		if ( ! empty( $field['description_link'] ) && is_array( $field['description_link'] ) ) {
			$link_label = $field['description_link']['label'] ?? '';
			$link_href  = $field['description_link']['href'] ?? '';
			if ( '' !== $link_label && is_string( $link_label ) ) {
				$html .= ' <a href="' . esc_attr( $link_href ) . '" target="_blank">' . esc_html( $link_label ) . '</a>';
			}
		}
		return $html;
	}

	/**
	 * WPML-translate description link label only (href and placeholders stay literal).
	 *
	 * @param array  $field     Field config (by reference).
	 * @param string $field_key Field identifier.
	 * @return void
	 */
	public static function translate_description_link_label( &$field, $field_key ) {
		if ( empty( $field['description_link']['label'] ) || ! is_string( $field['description_link']['label'] ) ) {
			return;
		}
		$field['description_link']['label'] = self::wpml_translate_string(
			$field['description_link']['label'],
			$field_key . '_description_link'
		);
	}

	/**
	 * Tooltip text with optional literal {{key}} example (not passed through WPML).
	 *
	 * @param array $field Field config.
	 * @return string
	 */
	public static function get_field_tooltip_text( $field ) {
		$tooltip = $field['tooltip'] ?? '';
		if ( '' === $tooltip && empty( $field['tooltip_placeholder_example'] ) ) {
			return '';
		}
		$text = $tooltip;
		if ( ! empty( $field['tooltip_placeholder_example'] ) && is_string( $field['tooltip_placeholder_example'] ) ) {
			$text = trim( $text . ' ' . $field['tooltip_placeholder_example'] );
		}
		return $text;
	}

	/**
	 * Whether a select option label should skip WPML (entity names, numeric keys).
	 *
	 * @param string       $field_key    Field identifier.
	 * @param string|int   $option_key   Option key.
	 * @param string       $option_label Option label.
	 * @param array        $field        Field config.
	 * @return bool
	 */
	public static function should_skip_option_wpml( $field_key, $option_key, $option_label, $field = array() ) {
		if ( self::has_dynamic_options( $field_key, $field ) ) {
			return true;
		}
		if ( is_numeric( $option_key ) ) {
			return true;
		}
		if ( is_string( $option_label ) && self::is_non_translatable_value( $option_label ) ) {
			return true;
		}
		return false;
	}

	/**
	 * Build a unique WPML string identifier from value and field key.
	 *
	 * @param string $string    Original string.
	 * @param string $field_key Unique field identifier.
	 * @return string
	 */
	private static function build_identifier( $string, $field_key ) {
		$identifier        = str_replace( ' ', '_', (string) $string );
		$key_identifier    = str_replace( ' ', '_', (string) $field_key );
		return $key_identifier . $identifier;
	}

	/**
	 * Register a string with WPML (call when saving admin-entered values).
	 *
	 * @param string $string    Original string.
	 * @param string $field_key Unique field identifier.
	 * @return void
	 */
	public static function register_string( $string, $field_key = '' ) {
		if ( ! self::is_wpml_active() || empty( $string ) || ! is_string( $string ) || self::is_non_translatable_value( $string ) ) {
			return;
		}

		/**
		 * Registers a single translatable string in WPML String Translation.
		 *
		 * @since 1.0.0
		 */
		do_action(
			'wpml_register_single_string',
			'order-on-whatsapp',
			self::build_identifier( $string, $field_key ),
			$string
		);
	}

	/**
	 * Translate a previously registered string (call when outputting saved values).
	 *
	 * @param string $string    Original string.
	 * @param string $field_key Unique field identifier.
	 * @return string
	 */
	public static function translate_string( $string, $field_key = '' ) {
		if ( ! self::is_translation_ready() || ! self::is_wpml_active() || empty( $string ) || ! is_string( $string ) || self::is_non_translatable_value( $string ) ) {
			return $string;
		}

		/**
		 * Returns the WPML translation for a registered single string.
		 *
		 * @since 1.0.0
		 */
		return apply_filters(
			'wpml_translate_single_string',
			$string,
			'order-on-whatsapp',
			self::build_identifier( $string, $field_key )
		);
	}

	/**
	 * Apply WPML to hardcoded strings in a settings/field config tree.
	 *
	 * @param array  $data   Settings array (passed by reference).
	 * @param string $prefix Key prefix for nested fields.
	 * @return void
	 */
	public static function translate_settings_fields( &$data, $prefix = '' ) {
		if ( ! is_array( $data ) ) {
			return;
		}

		foreach ( $data as $key => &$item ) {
			$field_key = '' !== $prefix ? $prefix . '_' . $key : (string) $key;

			if ( ! is_array( $item ) ) {
				continue;
			}

			$is_field = isset( $item['type'] ) || isset( $item['value'] );
			if ( $is_field && self::is_color_field( $field_key, $item ) ) {
				continue;
			}

			if ( isset( $item['label'] ) && is_string( $item['label'] ) && ! self::is_payment_gateway_label_field( $field_key ) ) {
				$item['label'] = self::wpml_translate_string( $item['label'], $field_key );
			}
			if ( ! empty( $item['tooltip'] ) && is_string( $item['tooltip'] ) ) {
				$item['tooltip'] = self::wpml_translate_string( $item['tooltip'], $field_key . '_tooltip' );
			}
			$desc = $item['description'] ?? $item['desc'] ?? null;
			if ( ! empty( $desc ) && is_string( $desc ) && ! self::is_payment_gateway_label_field( $field_key ) ) {
				$translated = self::wpml_translate_string( $desc, $field_key . '_description' );
				if ( isset( $item['description'] ) ) {
					$item['description'] = $translated;
				}
				if ( isset( $item['desc'] ) ) {
					$item['desc'] = $translated;
				}
			}
			self::translate_description_link_label( $item, $field_key );
			if ( isset( $item['options'] ) && is_array( $item['options'] ) ) {
				foreach ( $item['options'] as $option_key => $option_label ) {
					if ( is_string( $option_label ) && ! self::should_skip_option_wpml( $field_key, $option_key, $option_label, $item ) ) {
						$item['options'][ $option_key ] = self::wpml_translate_string(
							$option_label,
							$field_key . '_option_' . $option_key
						);
					}
				}
			}

			if ( ! $is_field ) {
				self::translate_settings_fields( $item, $field_key );
			}
		}
	}

	/**
	 * Register and translate a hardcoded string (for values stored in arrays/variables).
	 *
	 * @param string $string    Output of __().
	 * @param string $field_key Unique field identifier.
	 * @return string
	 */
	public static function wpml_translate_string( $string, $field_key = '' ) {
		self::register_string( $string, $field_key );
		return self::translate_string( $string, $field_key );
	}

	/**
	 * Alias for wpml_translate_string().
	 *
	 * @param string $string    Output of __().
	 * @param string $field_key Unique field identifier.
	 * @return string
	 */
	public static function translate( $string, $field_key = '' ) {
		return self::wpml_translate_string( $string, $field_key );
	}
}
