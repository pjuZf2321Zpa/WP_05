<?php
/**
 * Parses WhatsApp order message templates with placeholders.
 *
 * @package Order_On_WhatsApp_For_WooCommerce
 */

if (! defined('ABSPATH')) {
	exit;
}

/**
 * WhatsApp order message template parser.
 */
class FMA_OOW_WhatsApp_Template_Parser {

	/**
	 * Parse template string for a WooCommerce order.
	 *
	 * @param string   $template Raw template with {placeholders}.
	 * @param WC_Order $order    Order object.
	 * @return string
	 */
	public static function parse( $template, $order ) {
		if (! is_string($template) || '' === $template) {
			return '';
		}
		if (! $order instanceof WC_Order) {
			return '';
		}

		$placeholders = self::get_placeholders($order);
		/**
		 * Filters the list of available placeholders for the WhatsApp order message template.
		 *
		 * Allows developers to modify, add, or remove placeholders used in the WhatsApp template parser.
		 *
		 * @since 1.3.5
		 *
		 * @param array    $placeholders Array of available placeholder values (keys lowercased).
		 * @param WC_Order $order        The WooCommerce order object.
		 * @return array Modified array of placeholders.
		 */
		$placeholders = apply_filters('oow_whatsapp_template_placeholders', $placeholders, $order);

		return (string) preg_replace_callback(
			'/\{([^}]+)\}/',
			function ( $matches ) use ( $placeholders, $order ) {
				$key = isset($matches[1]) ? trim($matches[1]) : '';
				if ('' === $key) {
					return '';
				}
				$lk = strtolower($key);
				if (isset($placeholders[ $lk ])) {
					return self::stringify_placeholder_value($placeholders[ $lk ]);
				}
				return self::resolve_custom_meta($order, $key);
			},
			$template
		);
	}

	/**
	 * Default placeholder values (keys lowercased).
	 *
	 * @param WC_Order $order Order.
	 * @return array<string, string>
	 */
	protected static function get_placeholders( $order ) {
		$currency_symbol = html_entity_decode(get_woocommerce_currency_symbol(), ENT_QUOTES, 'UTF-8');
		$labels          = function_exists('fmaGetAllLabelsForWhatsAppMessage') ? fmaGetAllLabelsForWhatsAppMessage() : array();

		$pay_url    = $order->get_checkout_payment_url();
		$view_url   = $order->get_view_order_url();
		$prefilled  = WpmlHelper::translate((string) get_option('fma_oow_msg_when_whatsap_opens', ''), 'saved_fma_oow_msg_when_whatsap_opens');

		$map = array(
			'order_id'            => (string) $order->get_id(),
			'order_number'        => (string) $order->get_order_number(),
			'order_total'         => self::format_plain_price($order->get_total()),
			'order_currency'      => (string) $order->get_currency(),
			'payment_method'      => (string) $order->get_payment_method_title(),
			'shipping_method'     => (string) $order->get_shipping_method(),
			'customer_note'       => (string) $order->get_customer_note(),
		);

		$map['billing_first_name']   = (string) $order->get_billing_first_name();
		$map['billing_last_name']    = (string) $order->get_billing_last_name();
		$map['billing_company']      = (string) $order->get_billing_company();
		$map['billing_phone']        = (string) $order->get_billing_phone();
		$map['billing_email']        = (string) $order->get_billing_email();
		$map['billing_address_1']    = (string) $order->get_billing_address_1();
		$map['billing_address_2']    = (string) $order->get_billing_address_2();
		$map['billing_city']         = (string) $order->get_billing_city();
		$map['billing_state']        = (string) self::format_state($order->get_billing_country(), $order->get_billing_state());
		$map['billing_postcode']     = (string) $order->get_billing_postcode();
		$map['billing_country']      = (string) self::country_label($order->get_billing_country());

		$map['shipping_first_name']  = (string) $order->get_shipping_first_name();
		$map['shipping_last_name']   = (string) $order->get_shipping_last_name();
		$map['shipping_company']     = (string) $order->get_shipping_company();
		$map['shipping_phone']       = (string) $order->get_shipping_phone();
		$map['shipping_address_1']   = (string) $order->get_shipping_address_1();
		$map['shipping_address_2']   = (string) $order->get_shipping_address_2();
		$map['shipping_city']        = (string) $order->get_shipping_city();
		$map['shipping_state']       = (string) self::format_state($order->get_shipping_country(), $order->get_shipping_state());
		$map['shipping_postcode']    = (string) $order->get_shipping_postcode();
		$map['shipping_country']     = (string) self::country_label($order->get_shipping_country());

		$map['site_name']            = (string) get_bloginfo('name');
		$map['site_url']             = (string) home_url('/');

		$map['view_order_url']       = (string) $view_url;
		$map['checkout_payment_url'] = (string) $pay_url;
		$map['pay_now_url']          = (string) $pay_url;

		$map['prefilled_message']    = $prefilled;
		$map['order_date']           = $order->get_date_created() ? gmdate('Y/m/d', $order->get_date_created()->getTimestamp()) : '';

		$map['order_items']          = self::get_order_items_block($order, $currency_symbol, $labels);

		return $map;
	}

	/**
	 * Stringify placeholder value.
	 * 
	 * @param mixed $value Scalar or stringable.
	 * @return string
	 */
	protected static function stringify_placeholder_value( $value ) {
		if (is_array($value) || is_object($value)) {
			return '';
		}
		if (null === $value) {
			return '';
		}
		return wp_strip_all_tags((string) $value, true);
	}

	/**
	 * Format plain price.
	 * 
	 * @param string|float $amount Amount.
	 * @return string
	 */
	protected static function format_plain_price( $amount ) {
		if (! function_exists('wc_price')) {
			return (string) $amount;
		}
		return html_entity_decode(wp_strip_all_tags(wc_price($amount)), ENT_QUOTES, 'UTF-8');
	}

	/**
	 * Format state.
	 * 
	 * @param string $cc Country code.
	 * @param string $st State code.
	 * @return string
	 */
	protected static function format_state( $cc, $st ) {
		if ('' === (string) $st) {
			return '';
		}
		$label = WC()->countries->get_states($cc);
		if (is_array($label) && isset($label[ $st ])) {
			return (string) $label[ $st ];
		}
		return (string) $st;
	}

	/**
	 * Get country label.
	 * 
	 * @param string $code Country code.
	 * @return string
	 */
	protected static function country_label( $code ) {
		if ('' === (string) $code) {
			return '';
		}
		$list = WC()->countries->get_countries();
		return isset($list[ $code ]) ? (string) $list[ $code ] : (string) $code;
	}

	/**
	 * Get order items block.
	 *
	 * @param WC_Order $order           Order.
	 * @param string   $currency_symbol Symbol.
	 * @param array    $labels          Label map from fmaGetAllLabelsForWhatsAppMessage().
	 * @return string
	 */
	protected static function get_order_items_block( $order, $currency_symbol, $labels ) {
		$lines        = array();
		$title_l      = isset($labels['fmaProductTitleLabel']) ? $labels['fmaProductTitleLabel'] : __('Product Title:', 'order-on-whatsapp');
		$price_l      = isset($labels['fmaPriceLabel']) ? $labels['fmaPriceLabel'] : __('Price:', 'order-on-whatsapp');
		$qty_l        = isset($labels['fmaQuantityLabel']) ? $labels['fmaQuantityLabel'] : __('Quantity:', 'order-on-whatsapp');
		$link_l       = isset($labels['fmaLinkLabel']) ? $labels['fmaLinkLabel'] : __('Link:', 'order-on-whatsapp');

		foreach ($order->get_items() as $item_data) {
			if (! is_a($item_data, 'WC_Order_Item_Product')) {
				continue;
			}
			$product = $item_data->get_product();
			if (! $product) {
				continue;
			}
			$lines[] = '*' . str_replace('&', '', $title_l) . '* ' . str_replace('&', '', $product->get_name());
			$lines[] = '*' . $price_l . '* ' . $currency_symbol . $product->get_price();
			$lines[] = '*' . $qty_l . '* ' . $item_data->get_quantity();
			$lines[] = '*' . $link_l . '* ' . str_replace('&', '', $product->get_permalink());
		}
		return implode("\n", $lines);
	}

	/**
	 * Resolve custom meta.
	 *
	 * @param WC_Order $order   Order.
	 * @param string   $meta_key Meta key (as inside braces).
	 * @return string
	 */
	protected static function resolve_custom_meta( $order, $meta_key ) {
		if (! self::is_safe_meta_key($meta_key)) {
			return '';
		}
		$raw = $order->get_meta($meta_key, true);
		if (is_array($raw) || is_object($raw)) {
			return '';
		}
		if ('' === $raw || null === $raw) {
			return '';
		}
		return self::stringify_placeholder_value($raw);
	}

	/**
	 * Check if meta key is safe.
	 * 
	 * @param string $key Meta key.
	 * @return bool
	 */
	protected static function is_safe_meta_key( $key ) {
		if (strlen($key) > 191) {
			return false;
		}
		return (bool) preg_match('/^[a-zA-Z0-9_-]+$/', $key);
	}
}
