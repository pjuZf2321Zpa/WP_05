<!-- WooCommerce Setting HTML -->

<input type="hidden" value="my_sub_menu_whatsapp" id='fma_order_on_whatsapp_to_hide_save_chngs_btn'>
<div id="snackbar">
	<?php echo esc_html__('Whatsapp Order Changes Saved.', 'order-on-whatsapp'); ?>
</div>

<!-- the tabs -->
<ul class="subsubsub">

	<li><a class="current" id='fma_oow_settings_tab_btn' href="#">
			<?php echo esc_html__('Settings', 'order-on-whatsapp'); ?>
		</a>|</li>
	<li><a id='fma_oow_share_tab_btn' href="#">
			<?php echo esc_html__('Share button', 'order-on-whatsapp'); ?>
		</a>|</li>
	<li><a id='fma_oow_hide_show_tab_btn' href="#">
			<?php echo esc_html__('Hide/Show button', 'order-on-whatsapp'); ?>
		</a>|</li>

	<!-- added by saqib  -->
	<li><a id='fma_oow_notifications_settings_tab_btn' href="#">
			<?php echo esc_html__('Notification settings', 'order-on-whatsapp'); ?>
		</a>|</li>
	<!-- added by saqib ends  -->

	<!-- display settings  -->
	<li><a id='fma_oow_display_settings_tab_btn' href="#">
			<?php echo esc_html__('Display settings', 'order-on-whatsapp'); ?>
		</a>|</li>
	<li><a id='fma_oow_message_template_tab_btn' href="#">
			<?php echo esc_html__('Message template', 'order-on-whatsapp'); ?>
		</a></li>


</ul>
<!-- GENERAL SETTINGS TAB  -->
<table class="table-mastersettings table-outer form-table tbl fma_oow_setting_main_tbl" cellpadding="0" cellspacing="0"
	id='whatsapp_settings_tbl'>
	<tbody>
		<tr>
			<th class="fma_sec_heading">
				<h2>
					<?php echo esc_html__('General settings', 'order-on-whatsapp'); ?>
				</h2>
			</th>
		</tr>
		<tr>
			<th scope="row">
				<label for="fma_order_on_whatsapp_whatsapp_number">
					<?php echo esc_html__('WhatsApp number', 'order-on-whatsapp'); ?>
				</label>
			</th>
			<td>
				<span class="tip">
					<?php echo wc_help_tip(esc_html__('Enter the number on which you have created your WhatsApp account.', 'order-on-whatsapp')); ?>
				</span>
				<label>
					<input type="text" pattern="/^-?\d+\.?\d*$/" class='fma_oow_all_inputs' required="required"
						onKeyPress="if(this.value.length==15) return false;" id="fma_order_on_whatsapp_whatsapp_number"
						value="<?php echo esc_attr($fma_order_on_whatsapp_number); ?>" placeholder="+92123456789">
					<p class="description">
						<?php echo esc_html__('Enter WhatsApp number in International format without any spaces', 'order-on-whatsapp'); ?>
					</p>
				</label>
			</td>
		</tr>

		<tr>
			<th><label for="fma_oow_all_payment_gateways">
					<?php echo esc_html__('Allow for all payments method', 'order-on-whatsapp'); ?>
				</label></th>
			<td>
				&nbsp;&nbsp;
				<input type="checkbox" <?php echo checked(esc_attr(sanitize_text_field($fma_oow_all_payment_gateways)), 'on'); ?> id='fma_oow_all_payment_gateways'>
				<p class="description inline">
					<?php echo esc_html__('If this is checked, The WhatsApp option will appear on all  payments methods, By default cash on delivery method is allowed', 'order-on-whatsapp'); ?>
				</p>
			</td>
		</tr>
		<tr>
			<th><label for="fma_oow_inline_whatsapp_share_buttons">
					<?php echo esc_html__('Display WhatsApp and Share buttons inline', 'order-on-whatsapp'); ?>
				</label></th>
			<td>
				&nbsp;&nbsp;
				<input type="checkbox" <?php echo checked(esc_attr(sanitize_text_field($fma_oow_inline_whatsapp_share_buttons)), 'on'); ?> id='fma_oow_inline_whatsapp_share_buttons'>
				<p class="description inline">
					<?php echo esc_html__('When enabled, WhatsApp and Share buttons appear side by side on shop, product, and cart pages. When disabled, buttons are stacked vertically.', 'order-on-whatsapp'); ?>
				</p>
			</td>
		</tr>
		<!-- applied to all products -->
		<tr>
			<th><label for="fma_oow_apply_on_all_products">
					<?php echo esc_html__('Apply to all products', 'order-on-whatsapp'); ?>
				</label></th>
			<td>
				&nbsp;&nbsp;
				<input type="checkbox" <?php echo esc_attr($fma_oow_all_products_checkbox); ?>
					id='fma_oow_apply_on_all_products'>
				<p class="description inline">
					<?php echo esc_html__('If this is checked, The WhatsApp button will appear on all  store products', 'order-on-whatsapp'); ?>
				</p>
			</td>
		</tr>
		<tr>
			<th scope="row">
				<label for="fma_oow_either_cats_or_prds">
					<?php echo esc_html__('Applied to', 'order-on-whatsapp'); ?>
				</label>
			</th>
			<td>
				<span class="tip">
					<?php echo wc_help_tip(esc_html__('Select either Products or Categories.', 'order-on-whatsapp')); ?>
				</span>
				<select class='fma_oow_all_inputs' name="fma_order_on_whatsapp_products_list"
					id="fma_oow_either_cats_or_prds" id='fma_oow_eiter_prods_or_cats'>
					<option value="fma_order_on_whatsapp_products_list" <?php echo esc_attr($fma_order_on_whatsapp_check_products_list); ?>><?php echo esc_html__('Products', 'order-on-whatsapp'); ?></option>
					<option value="categories" <?php echo esc_html($fma_order_on_whatsapp_check_categories_list); ?>>
						<?php echo esc_html__('Categories', 'order-on-whatsapp'); ?></option>
				</select>
			</td>
		</tr>
		<tr id='fma_oow_prods_row' style="display: <?php echo esc_attr($fma_oow_prods_row_display); ?>;">
			<th>
				<label for="fma_order_on_whatsapp_example_whatsapp_products_list">
					<?php echo esc_html__('Applied to products', 'order-on-whatsapp'); ?>
				</label>
			</th>
			<td>
				<span class="tip">
					<?php echo wc_help_tip(esc_html__('Select those products on which you want to apply this module.', 'order-on-whatsapp')); ?>
				</span>
				<select class="fma_oow_all_inputs" id="fma_order_on_whatsapp_example_whatsapp_products_list" multiple="multiple">
					<?php
					if ( is_array( $fma_order_on_whatsapp_selected_products_list ) ) {
						foreach ( $fma_order_on_whatsapp_selected_products_list as $pro_id ) {
							$pro_id = absint( $pro_id );
							if ( ! $pro_id ) {
								continue;
							}
							$pro_title = get_the_title( $pro_id );
							if ( '' === $pro_title ) {
								continue;
							}
							?>
							<option value="<?php echo esc_attr( $pro_id ); ?>" selected="selected">
								<?php echo esc_html( $pro_title ); ?>
							</option>
							<?php
						}
					}
					?>
				</select>
				<p class="description">
					<?php echo esc_html__('If applied to all products is checked, this won\'t be applied.', 'order-on-whatsapp'); ?>
				</p>
			</td>

		</tr>
		<tr id='fma_oow_cats_row' style="display: <?php echo esc_attr($fma_oow_cats_row_display); ?>">
			<th>
				<label for="fma_order_on_whatsapp_categories_list">
					<?php echo esc_html__('Applied to categories', 'order-on-whatsapp'); ?>
				</label>
			</th>
			<td>
				<span class="tip">
					<?php 
					echo wc_help_tip(esc_html__('Select those categories for which you want to apply this module.', 'order-on-whatsapp')); // phpcs:ignore 
					?>
				</span>
				<select class='fma_oow_all_inputs' id='fma_order_on_whatsapp_categories_list' multiple="multiple">
					<?php
					if (is_array($fma_order_on_whatsapp_selected_categories)) {
						foreach ($fma_order_on_whatsapp_selected_categories as $cat_name) {
							$cat_name = sanitize_text_field($cat_name);
							if ('' === $cat_name) {
								continue;
							}
							?>
							<option value="<?php echo esc_attr($cat_name); ?>" selected="selected">
								<?php echo esc_html($cat_name); ?>
							</option>
							<?php
						}
					}
					?>
				</select>
				<p class="description">
					<?php echo esc_html__('If applied to all categories is checked, this won\'t be applied.', 'order-on-whatsapp'); ?>
				</p>
			</td>
		</tr>
		<tr valign="top">
			<th scope="row">
				<label for="fma_order_on_whatsapp_whatsapp_button_text">
					<?php echo esc_html__('Button text', 'order-on-whatsapp'); ?>
				</label>
			</th>
			<td>
				<span class="tip">
					<?php 
					echo wc_help_tip(esc_html__('Enter the button text.', 'order-on-whatsapp')); // phpcs:ignore 
					?>
				</span>
				<input type="text" class='fma_oow_all_inputs' name="" id="fma_order_on_whatsapp_whatsapp_button_text"
					value="<?php echo esc_attr($fma_order_on_whatsapp_button_text); ?>" placeholder="<?php echo esc_attr__('Enter Button Text', 'order-on-whatsapp'); ?>">
				<p class="description">
					<?php echo esc_html__('Default "Buy On WhatsApp"', 'order-on-whatsapp'); ?>
				</p>
			</td>
		</tr>


		<tr>
			<th><label for="fma_oow_def_icon_chk">
					<?php echo esc_html__('Use default icon', 'order-on-whatsapp'); ?>
				</label></th>
			<td>
				&nbsp;&nbsp;
				<input type="checkbox" <?php checked(esc_attr($fma_oow_def_icon_chk), 'on', true); ?>
					id="fma_oow_def_icon_chk" name="fma_oow_def_icon_chk" value='on'>
				<p class="description inline">
					<?php echo esc_html__('If this is checked, Then default icon will be displayed', 'order-on-whatsapp'); ?>
				</p>
			</td>
		</tr>
		<!--  -->
		<tr class="" style="display: none !important;">
			<th>
				<labe for="fma_oow_show_icon_only" l>
					<?php echo esc_html__('Display icon instead of button', 'order-on-whatsapp'); ?>
					</label>
			</th>
			<td>
				&nbsp;&nbsp;
				<input type="checkbox" <?php checked(esc_attr($fma_oow_show_icon_only), 'on', true); ?>
					id="fma_oow_show_icon_only" name="fma_oow_show_icon_only" value='on'>
				<p class="description inline">
					<?php echo esc_html__('If this is checked, Only whatsapp icon will be shown instead of icon', 'order-on-whatsapp'); ?>
				</p>
			</td>
		</tr>
		<tr class="fma_oow_icon_settings">
			<th>
				<label>
					<?php echo esc_html__('Choose icon', 'order-on-whatsapp'); ?>
				</label>
			</th>
			<td class="forminp forminp-number">
				<span class="woocommerce-help-tip"
					data-tip="<?php echo esc_html__('This icon will show in button.', 'order-on-whatsapp'); ?>"></span>
				<?php
				foreach ($fma_oow_icons_urls as $ind => $img) {

					?>

					<span>
						<label for="<?php echo esc_attr($ind); ?>">
							<img src="<?php echo esc_url($img); ?>" class="fma_oow_icons" alt=""
								style="width:50px;height:50px;">
						</label>
						<input type="radio" name="fma_oow_icons" id="<?php echo esc_attr($ind); ?>" value="<?php echo esc_attr($ind); ?>" <?php echo checked(esc_attr($fma_oow_selected_icon), $ind); ?>>
					</span>
					<?php

				}

				?>

			</td>
		</tr>
		<tr class="fma_oow_icon_settings">

			<th>
				<label for="fma_icon_clr">
					<?php echo esc_html__('Icon color', 'order-on-whatsapp'); ?>
				</label>
			</th>
			<td>
				<span class="tip">
					<?php 
					echo wc_help_tip(esc_html__('This color will be applied to the icon.', 'order-on-whatsapp')); // phpcs:ignore 
					?>
				</span>&nbsp;&nbsp;
				<input type="text" id='fma_icon_clr' value='<?php echo esc_attr($fma_icon_clr); ?>' class='jscolor'>
				<p class="description">
					<?php echo esc_html__('Default value is "#000000"', 'order-on-whatsapp'); ?>
				</p>
			</td>

		</tr>
		<tr class="fma_oow_icon_settings">
			<th>
				<label for="fma_icon_size">
					<?php echo esc_html__('Icon size', 'order-on-whatsapp'); ?>
				</label>
			</th>
			<td>
				<span class="tip">
					<?php 
					echo wc_help_tip(esc_html__('Enter icon size.', 'order-on-whatsapp')); // phpcs:ignore 
					?>
				</span>&nbsp;&nbsp;
				<input type="number" id='fma_icon_size' value='<?php echo esc_attr($fma_icon_size); ?>'>
				<p class="description">
					<?php echo esc_html__('enter size in unmber', 'order-on-whatsapp'); ?>
				</p>
			</td>

		</tr>
		<tr>
			<th><label for="fma_oow_where_to_place_whatsp_btn">
					<?php echo esc_html__('Place buttons', 'order-on-whatsapp'); ?>
				</label></th>
			<td>
				<span class="tip">
					<?php 
					echo wc_help_tip(esc_html__('Where do you want the place the WhatsApp button.', 'order-on-whatsapp')); // phpcs:ignore 
					?>
				</span>&nbsp;&nbsp;
				<select name="fma_oow_where_to_place_whatsp_btn" id="fma_oow_where_to_place_whatsp_btn">
					<option value="fma_oow_before_add_to_cart" <?php echo selected(esc_attr(sanitize_text_field($fma_oow_where_to_place_whatsp_btn)), 'fma_oow_before_add_to_cart', false); ?>>
						<?php echo esc_html__('Before add to cart', 'order-on-whatsapp'); ?>
					</option>
					<option value="fma_oow_after_add_to_cart" <?php echo selected(esc_attr(sanitize_text_field($fma_oow_where_to_place_whatsp_btn)), 'fma_oow_after_add_to_cart', false); ?>>
						<?php echo esc_html__('After add to cart', 'order-on-whatsapp'); ?>
					</option>
				</select>
				<p class="description">
					<?php echo esc_html__('Default is before Add to cart', 'order-on-whatsapp'); ?>
				</p>
			</td>
		</tr>

		<tr>
			<th><label for="fma_oow_where_to_open_whatsapp">
					<?php echo esc_html__('Open whatsapp in', 'order-on-whatsapp'); ?>
				</label></th>
			<td>
				<span class="tip">
					<?php 
					echo wc_help_tip(esc_html__('Where do you want the WhatsApp to open.', 'order-on-whatsapp')); // phpcs:ignore 
					?>
				</span>&nbsp;&nbsp;
				<select name="fma_oow_where_to_open_whatsapp" id="fma_oow_where_to_open_whatsapp">
					<option value="oow_in_new_tab" <?php echo selected(esc_attr(sanitize_text_field($fma_oow_open_whatsapp_in_which_tab)), 'oow_in_new_tab', false); ?>>
						<?php echo esc_html__('New tab', 'order-on-whatsapp'); ?>
					</option>
					<option value="oow_in_same_tab" <?php echo selected(esc_attr(sanitize_text_field($fma_oow_open_whatsapp_in_which_tab)), 'oow_in_same_tab', false); ?>>
						<?php echo esc_html__('Same tab', 'order-on-whatsapp'); ?>
					</option>
				</select>
				<p class="description">
					<?php echo esc_html__('Default is Same Tab, Setting to New tab may create issues as some mobile devices don\'t allow to open link in new tab', 'order-on-whatsapp'); ?>
				</p>
			</td>
		</tr>
		<!-- customize message when WhatsApp opens -->
		<tr>
			<th><label for="fma_oow_msg_when_whatsap_opens">
					<?php echo esc_html__('Prefilled whatsApp message', 'order-on-whatsapp'); ?>
				</label></th>
			<td>
				<span class="tip">
					<?php 
					echo wc_help_tip(esc_html__('Customize autofilled message when the WhatsApp application opens.', 'order-on-whatsapp')); // phpcs:ignore 
					?>
				</span>&nbsp;&nbsp;
				<textarea name="" placeholder="<?php echo esc_attr__('Message which you want to show when WhatsApp opens...', 'order-on-whatsapp'); ?>"
					id="fma_oow_msg_when_whatsap_opens" cols="30"
					rows="5"><?php echo esc_textarea(sanitize_text_field($fma_oow_msg_when_whatsap_opens)); ?></textarea>
			</td>
		</tr>

		<tr>
			<th><label for="fma_oow_create_order">
					<?php echo esc_html__('Create order in wooCommerce', 'order-on-whatsapp'); ?>
				</label></th>
			<td>
				&nbsp;&nbsp;
				<input type="checkbox" value="yes" id='fma_oow_create_order' <?php echo esc_html($fma_oow_create_order_in_woocommerce_checkbox); ?>>
				<p class="description inline">
					<?php echo esc_html__('Order will be created in woocommerce after place order on whatsApp is clicked', 'order-on-whatsapp'); ?>
				</p>
			</td>
		</tr>

		<tr>
			<th><label for="oow_order_status">
					<?php echo esc_html__('Select order status', 'order-on-whatsapp'); ?>
				</label></th>
			<td>
				<span class="tip">
					<?php 
					echo wc_help_tip(esc_html__('This will be the initial status of Order', 'order-on-whatsapp')); // phpcs:ignore 
					?>
				</span>&nbsp;&nbsp;
				<select id="oow_order_status">
					<?php
					foreach (wc_get_order_statuses() as $key => $value) {
						if ($oow_order_status == $key) {
							$selected = 'Selected';
						} else {
							$selected = '';
						}
						?>
						<option <?php echo esc_attr($selected); ?>
							value="<?php echo esc_attr($key); ?>">
							<?php echo esc_html($value); ?>
						</option>
						<?php
					}
					?>
				</select>
			</td>
		</tr>
		<tr>
			<th><label for="fma_oow_show_for_customer_only">
					<?php echo esc_html__('Enable whatsapp button for logged in users only', 'order-on-whatsapp'); ?>
				</label></th>
			<td>
				&nbsp;&nbsp;
				<input type="checkbox" value="yes" id='fma_oow_show_for_customer_only' <?php echo esc_attr($fma_oow_enable_only_for_customer_checkbox); ?>>
				<p class="description inline">
					<?php echo esc_html__('Only logged in user will see whatsapp button', 'order-on-whatsapp'); ?>
				</p>
			</td>
		</tr>

		<tr>
			<th><label for="fma_oow_send_pay_now_link">
					<?php echo esc_html__('Send pay now link on whatsapp', 'order-on-whatsapp'); ?>
				</label></th>
			<td>
				&nbsp;&nbsp;
				<input type="checkbox" value="yes" id='fma_oow_send_pay_now_link' <?php echo esc_attr($fma_oow_send_pay_now_link_checkbox); ?>>
				<p class="description inline">
					<?php echo esc_html__('If checked, will send pay now link to customer on whatsapp in case the order status is pending payment.', 'order-on-whatsapp'); ?>
				</p>
			</td>
		</tr>

		<!-- ///////////// WHATSAPP CONTACT NUMBERS ///////////////// -->
		<style type="text/css">
			.fma_oow_add_button {
				background-color: #1864bb;
				border: 1px solid #071b33;
				padding: 5px;
				margin: 5px 0px;
				color: #fff;
				border-radius: 5px;
				cursor: pointer;
				transition: all 0.3s;
				font-weight: normal;
			}

			.fma_oow_add_button:hover {
				background-color: #0c3461;
				transition: all 0.3s;
			}

			.fma_oow_input_fields_item {
				margin: 10px auto;
			}

			.fma_oow_remove_button {
				background-color: #ccc;
				border-radius: 5px;
				padding: 5px 8px;
				cursor: pointer;
				color: #937e7e;
				border: 1px solid #c1a5a5;
				transition: all 0.3s;
			}

			.fma_oow_remove_button:hover {
				background-color: #b3b3b3;
				transition: all 0.3s;
			}

			.fma_oow_fields_table td {
				padding: 5px 0px;
				border: 1px solid #ccc;
				text-align: center;
			}

			.fma_oow_fields_table tr:not(:first-child):nth-child(even) {
				background-color: #e6e6e6 !important;
			}

			.fma_oow_fields_table tr:not(:first-child):hover {
				background-color: white !important;
				box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
			}
		</style>

		<tr>
			<th>
				<label for="fma_oow_enable_multiple_branches">
					<?php echo esc_html__('Add multiple WhatsApp numbers', 'order-on-whatsapp'); ?>
				</label>
			</th>
			<td>
				<input type="checkbox" id="fma_oow_enable_multiple_branches" name="fma_oow_enable_multiple_branches" value="1"
					<?php
					$option = get_option('fma_oow_enable_multiple_whatsapp_num');
					if (false !== $option ) {
						checked($option, 'yes');
					} elseif (isset($multiple_whatsapp_numbers_exists) && 0 < $multiple_whatsapp_numbers_exists) {
						echo 'checked';
					}
					?>
					 />
				<p class="description inline">
					<?php echo esc_html__('Enable this option to add multiple WhatsApp contact numbers. These numbers will appear in a dropdown on the checkout page.', 'order-on-whatsapp'); ?>
				</p>

			</td>
		</tr>

		<tr style="display: none;" class="fma_oow_whatsapp_numbers_row">
			<th>
				<label for="fma_oow_whatsapp_contact_input_label">
					<?php echo esc_html__('Enter label for whatsapp contact number input.', 'order-on-whatsapp'); ?>
				</label>
				<span class="woocommerce-help-tip"
					data-tip="<?php echo esc_html__('Enter label for whatsapp contact number input.', 'order-on-whatsapp'); ?>"></span>
			</th>
			<td>
				<input type="text" id="fma_oow_whatsapp_contact_input_label"
					class="fma_oow_whatsapp_contact_input_label" name="fma_oow_whatsapp_contact_input_label"
					value="<?php echo esc_attr($fma_oow_whatsapp_contact_input_label); ?>"
					placeholder="<?php echo esc_attr__('Enter label for whatsapp contact input', 'order-on-whatsapp'); ?>" />
			</td>
		</tr>




		<tr style="display: none;" class="fma_oow_whatsapp_numbers_row">
			<th>
				<label for="fma_oow_whatsapp_first_number">
					<?php echo esc_html__('Enter 1st whatsapp number', 'order-on-whatsapp'); ?>
				</label>
				<span class="woocommerce-help-tip"
					data-tip="<?php echo esc_html__('Whatsapp contact numbers.', 'order-on-whatsapp'); ?>"></span>
				<button type="button" class="fma_oow_add_button fma_oow_whatsapp_add_another">
					<?php echo esc_html__('Add another', 'order-on-whatsapp'); ?>
				</button>
			</th>
			<td>
				<span class="fma_oow_help_text">
					<strong>
						<?php echo esc_html__('Contact Number: ', 'order-on-whatsapp'); ?>
					</strong>
					<?php echo esc_html__('Enter your contact number in international format.', 'order-on-whatsapp'); ?>
				</span><br />
				<table class="table-mastersettings table-outer fma_oow_fields_table fma_oow_whatsapp_number_wrapper"
					cellpadding="0" cellspacing="0">
					<tr>
						<th>
							<?php echo esc_html__('Name', 'order-on-whatsapp'); ?>
						</th>
						<th>
							<?php echo esc_html__('Contact number', 'order-on-whatsapp'); ?>
						</th>
						<th>
							<?php echo esc_html__('Status', 'order-on-whatsapp'); ?>
						</th>
						<th>
							<?php echo esc_html__('Actions', 'order-on-whatsapp'); ?>
						</th>
					</tr>

					<tr class="fma_oow_input_fields_item">
						<td>
							<input type="text" id="fma_oow_whatsapp_name" class="fma_oow_whatsapp_name"
								name="fma_oow_whatsapp_name[]" value="<?php echo esc_attr($fma_oow_whatsapp_name); ?>"
								placeholder="<?php echo esc_attr__('Enter Name', 'order-on-whatsapp'); ?>" />
						</td>
						<td>
							<input type="text" id="fma_oow_whatsapp_number" class="fma_oow_whatsapp_number"
								name="fma_oow_whatsapp_number[]"
								value="<?php echo esc_attr($fma_oow_whatsapp_number); ?>"
								placeholder="<?php echo esc_attr__('Enter 1st Whatsapp Number', 'order-on-whatsapp'); ?>" />
						</td>
						<td>
							<select id="fma_oow_whatsapp_status" class="fma_oow_whatsapp_status"
								name="fma_oow_whatsapp_status[]">
								<option value="1" <?php selected($fma_oow_whatsapp_status, 1); ?>>
									<?php echo esc_html__('Active', 'order-on-whatsapp'); ?>
								</option>
								<option value="0" <?php selected($fma_oow_whatsapp_status, 0); ?>>
									<?php echo esc_html__('InActive', 'order-on-whatsapp'); ?>
								</option>
							</select>
						</td>
						<td></td>
					</tr>

					<?php
					if (isset($fma_oow_whatsapp_contact_numbers['fma_oow_whatsapp_contacts'])) {
						foreach ($fma_oow_whatsapp_contact_numbers['fma_oow_whatsapp_contacts'] as $index => $contact) {
							if (0 == $index) {
								continue;
							}
							?>

							<tr class="fma_oow_input_fields_item">
								<td>
									<input type="text" id="fma_oow_whatsapp_name" class="fma_oow_whatsapp_name"
										name="fma_oow_whatsapp_name[]"
										value="<?php echo esc_attr($contact['fma_oow_whatsapp_name']); ?>"
										placeholder="<?php echo esc_attr__('Enter name', 'order-on-whatsapp'); ?>" />
								</td>
								<td>
									<input type="text" id="fma_oow_whatsapp_number" class="fma_oow_whatsapp_number"
										name="fma_oow_whatsapp_number[]"
										value="<?php echo esc_attr($contact['fma_oow_whatsapp_number']); ?>"
										placeholder="<?php echo esc_attr__('Enter 1st whatsapp number', 'order-on-whatsapp'); ?>" />
								</td>
								<td>
									<select id="fma_oow_whatsapp_status" class="fma_oow_whatsapp_status"
										name="fma_oow_whatsapp_status[]">
										<option value="1" <?php selected($contact['fma_oow_whatsapp_status'], 1); ?>>
											<?php echo esc_html__('Active', 'order-on-whatsapp'); ?>
										</option>
										<option value="0" <?php selected($contact['fma_oow_whatsapp_status'], 0); ?>>
											<?php echo esc_html__('InActive', 'order-on-whatsapp'); ?>
										</option>
									</select>
								</td>
								<td>
									<button type="button" class="fma_oow_remove_button fma_oow_remove_contact_button">X</button>
								</td>
							</tr>
							<?php
						}
					}
					?>

				</table>


			</td>
		</tr>


		<!-- ///////////// WHATSAPP CONTACT NUMBERS //////////////////////// -->


	</tbody>
</table>
<!-- SHARE TAB -->
<table class="table-mastersettings table-outer form-table tbl fma_share_btn_tbl" cellpadding="0" cellspacing="0"
	id='whatsapp_settings_tbl' style="display: none;">
	<tbody>
		<tr>
			<th class="fma_sec_heading">
				<h2>
					<?php echo esc_html__('Share button settings', 'order-on-whatsapp'); ?>
				</h2>
			</th>
		</tr>
		<!-- show share buton -->
		<tr class="share_btn_content">
			<th><label for="fma_oow_share_btn">
					<?php echo esc_html__('Enable share button', 'order-on-whatsapp'); ?>
				</label></th>
			<td>
				<span class="tip">
					<?php 
					echo wc_help_tip(esc_html__('Do you want to display share button?', 'order-on-whatsapp')); // phpcs:ignore 
					?>
				</span>&nbsp;&nbsp;
				<select name="fma_oow_share_btn" id="fma_oow_share_btn">
					<option value="yes" <?php echo selected(esc_attr(sanitize_text_field($fma_oow_share_btn)), 'yes', false); ?>>
						<?php echo esc_html__('Yes', 'order-on-whatsapp'); ?>
					</option>
					<option value="no" <?php echo selected(esc_attr(sanitize_text_field($fma_oow_share_btn)), 'no', false); ?>>
						<?php echo esc_html__('No', 'order-on-whatsapp'); ?>
					</option>
				</select>
				<p class="description">
					<?php echo esc_html__('Default is "Yes", You can control the visibility options in the "Hide/Show Button" tab.', 'order-on-whatsapp'); ?>
				</p>
			</td>
		</tr>
		<!-- share button text -->
		<tr class="share_btn_content">
			<th><label for="fma_oow_share_btn_txt">
					<?php echo esc_html__('Share button text', 'order-on-whatsapp'); ?>
				</label></th>
			<td>
				<span class="tip">
					<?php 
					echo wc_help_tip(esc_html__('Set the text of share button', 'order-on-whatsapp')); // phpcs:ignore 
					?>
				</span>&nbsp;&nbsp;
				<input type="text" value="<?php echo esc_html($fma_oow_share_btn_txt); ?>"
					placeholder="<?php echo esc_attr__('Share button text here...', 'order-on-whatsapp'); ?>" id='fma_oow_share_btn_txt'>
				<p class="description">
					<?php echo esc_html__('Default is "Share"', 'order-on-whatsapp'); ?>
				</p>
			</td>
		</tr>


		<tr>
			<th><label for="fma_oow_share_msg_when_whatsap_opens">
					<?php echo esc_html__('Prefilled share message', 'order-on-whatsapp'); ?>
				</label></th>
			<td>
				<span class="tip">
					<?php 
					echo wc_help_tip(esc_html__('Customize autofilled message when the WhatsApp application opens.', 'order-on-whatsapp')); // phpcs:ignore 
					?>
				</span>&nbsp;&nbsp;
				<textarea name="" placeholder="<?php echo esc_attr__('Message which you want to show when WhatsApp opens...', 'order-on-whatsapp'); ?>"
					id="fma_oow_share_msg_when_whatsap_opens" cols="30"
					rows="5"><?php echo esc_textarea(sanitize_text_field($fma_oow_share_msg_when_whatsap_opens)); ?></textarea>
			</td>
		</tr>
		<!-- end of share settings -->
	</tbody>
</table>

<!-- ///////////////// HIDE/SOW TAB /////////////////// -->
<table class="table-mastersettings table-outer form-table tbl fma_hide_show_tbl_" cellpadding="0" cellspacing="0"
	id='whatsapp_settings_tbl' style="display: none;">
	<tbody>
		<tr>
			<th class="fma_sec_heading">
				<h2>
					<?php echo esc_html__('Hide/Show settings', 'order-on-whatsapp'); ?>
				</h2>
			</th>
		</tr>

		<!-- whatsapp button settings  -->
		<tr class='fma_oow_hide_show_content'>
			<th>
				<label for="fma_order_on_whatsapp_show_whatsapp_btn_on_shop_page">
					<?php echo esc_html__('Show whatsapp button on shop page', 'order-on-whatsapp'); ?>
				</label>
			</th>

			<td>
				&nbsp;&nbsp;
				<input type="checkbox" id='fma_order_on_whatsapp_show_whatsapp_btn_on_shop_page' <?php echo esc_attr($fma_order_on_whatsapp_shop_page_checkbox_select_orNot); ?> name="">
				<p class="description inline">
					<?php echo esc_html__('If this is checked, WhatsApp button will be shown at shop page', 'order-on-whatsapp'); ?>
				</p>

			</td>
		</tr>
		<tr class='fma_oow_hide_show_content'>
			<th>
				<label for="fma_order_on_whatsapp_show_whatsapp_btn_on_single_product_page">
					<?php echo esc_html__('Show whatsapp button on single product page', 'order-on-whatsapp'); ?>
				</label>
			</th>
			<td>
				&nbsp;&nbsp;
				<input type="checkbox" id='fma_order_on_whatsapp_show_whatsapp_btn_on_single_product_page' <?php echo esc_attr($fma_order_on_whatsapp_show_on_single_product_selectOrNot); ?> name="">
				<p class="description inline">
					<?php echo esc_html__('If this is checked, whatsapp button will be shown at single product page', 'order-on-whatsapp'); ?>
				</p>

			</td>
		</tr>
		<tr class='fma_oow_hide_show_content'>
			<th>
				<label for="fma_order_on_whatsapp_show_whatsapp_btn_on_cart_page">
					<?php echo esc_html__('Show whatsapp button on cart page', 'order-on-whatsapp'); ?>
				</label>
			</th>
			<td>
				&nbsp;&nbsp;
				<input type="checkbox" id='fma_order_on_whatsapp_show_whatsapp_btn_on_cart_page' <?php echo esc_attr($fma_order_on_whatsapp_show_on_cart_page_selectOrNot); ?> name="">
				<p class="description inline">
					<?php echo esc_html__('If this is checked, whatsapp button will be shown at cart page', 'order-on-whatsapp'); ?>
				</p>

			</td>
		</tr>
		<!-- whatsapp button settings  -->

		<!-- share button settings  -->
		<tr class='fma_oow_hide_show_content'>
			<th>
				<label for="fma_order_on_whatsapp_share_show_btn_on_shop_page">
					<?php echo esc_html__('Show share button on shop page', 'order-on-whatsapp'); ?>
				</label>
			</th>

			<td>
				&nbsp;&nbsp;
				<input type="checkbox" id='fma_order_on_whatsapp_share_show_btn_on_shop_page' <?php echo esc_attr($fma_order_on_whatsapp_share_shop_page_checkbox_select_orNot); ?> name="">
				<p class="description inline">
					<?php echo esc_html__('If this is checked, whatsApp share button will be shown at shop page', 'order-on-whatsapp'); ?>
				</p>

			</td>
		</tr>
		<tr class='fma_oow_hide_show_content'>
			<th>
				<label for="fma_order_on_whatsapp_share_show_btn_on_single_product_page">
					<?php echo esc_html__('Show share button on single product page', 'order-on-whatsapp'); ?>
				</label>
			</th>
			<td>
				&nbsp;&nbsp;
				<input type="checkbox" id='fma_order_on_whatsapp_share_show_btn_on_single_product_page' <?php echo esc_attr($fma_order_on_whatsapp_share_show_on_single_product_selectOrNot); ?> name="">
				<p class="description inline">
					<?php echo esc_html__('If this is checked, whatsapp share button will be shown at single product page', 'order-on-whatsapp'); ?>
				</p>

			</td>
		</tr>
		<tr class='fma_oow_hide_show_content'>
			<th>
				<label for="fma_order_on_whatsapp_share_show_btn_on_cart_page">
					<?php echo esc_html__('Show share button on cart page', 'order-on-whatsapp'); ?>
				</label>
			</th>
			<td>
				&nbsp;&nbsp;
				<input type="checkbox" id='fma_order_on_whatsapp_share_show_btn_on_cart_page' <?php echo esc_attr($fma_order_on_whatsapp_share_show_on_cart_page_selectOrNot); ?> name="">
				<p class="description inline">
					<?php echo esc_html__('If this is checked, whatsapp button will be shown at cart page', 'order-on-whatsapp'); ?>
				</p>

			</td>
		</tr>
		<!-- share button settings ends  -->


		<!-- in update -->

		<tr class='fma_oow_hide_show_content'>
			<th><label for="fma_order_on_whatsapp_hide_add_to_cart_button_shop_page">
					<?php echo esc_html__('Hide cart button on shop page', 'order-on-whatsapp'); ?>
				</label></th>
			<td>
				&nbsp;&nbsp;
				<input type="checkbox" id='fma_order_on_whatsapp_hide_add_to_cart_button_shop_page' <?php echo esc_html($fma_order_on_whatsapp_hide_add_to_cart_btn_on_shop_page); ?>>
				<p class="description inline">
					<?php echo esc_html__('If this is checked, add to cart button will be hide at shop page', 'order-on-whatsapp'); ?>
				</p>

			</td>

		</tr>

		<!-- hide cart button on product pa -->
		<tr class='fma_oow_hide_show_content'>
			<th><label for="fma_order_on_whatsapp_hide_add_to_cart_button_product_page">
					<?php echo esc_html__('Hide cart button on product page', 'order-on-whatsapp'); ?>
				</label></th>
			<td>
				&nbsp;&nbsp;
				<input type="checkbox" id='fma_order_on_whatsapp_hide_add_to_cart_button_product_page' <?php echo esc_html($fma_order_on_whatsapp_hide_add_to_cart_btn_on_product_page); ?>>
				<p class="description inline">
					<?php echo esc_html__('If this is checked, add to cart button will be hide at product page', 'order-on-whatsapp'); ?>
				</p>

			</td>
		</tr>

		<tr class='fma_oow_hide_show_content'>
			<th><label for="fma_order_on_whatsa_button_on_desktop">
					<?php echo esc_html__('Hide whatsapp btn on desktop', 'order-on-whatsapp'); ?>
				</label></th>
			<td>
				&nbsp;&nbsp;
				<input type="checkbox" id='fma_order_on_whatsa_button_on_desktop' <?php echo esc_attr($fma_order_on_whatsapp_hide_whatsapp_btn_on_desktop); ?>>
				<p class="description inline">
					<?php echo esc_html__('If this is checked ,WhatsApp button will be hidden for desktop user at shop page ', 'order-on-whatsapp'); ?>
				</p>
			</td>
		</tr>


	</tbody>
</table>

<!-- Notification Settings -->
<table class="table-mastersettings table-outer form-table tbl fma_notifications_settings_tbl_" cellpadding="0"
	cellspacing="0" id='whatsapp_settings_tbl' style="display: none;">
	<tbody>
		<tr>
			<th class="fma_sec_heading">
				<h2>
					<?php echo esc_html__('Notification settings', 'order-on-whatsapp'); ?>
				</h2>
			</th>
		</tr>

		<!-- whatsapp button settings  -->
		<tr class='fma_oow_hide_show_content'>
			<th>
				<label for="fme_oow_enable_notifications">
					<?php echo esc_html__('Enable notifications', 'order-on-whatsapp'); ?>
				</label>
			</th>

			<td>
				&nbsp;&nbsp;
				<input type="checkbox" id='fme_oow_enable_notifications' <?php checked($fme_oow_enable_notifications, '1'); ?> name="fme_oow_enable_notifications">
				<p class="description inline">
					<?php echo esc_html__('If this is checked, notifications will be enabled.', 'order-on-whatsapp'); ?>
				</p>
			</td>
		</tr>

		<!-- whatsapp button settings  -->
		<tr class='fma_oow_hide_show_content'>
			<th>
				<label for="fme_oow_enable_notification_logs">
					<?php echo esc_html__('Enable notification logs', 'order-on-whatsapp'); ?>
				</label>
			</th>

			<td>
				&nbsp;&nbsp;
				<input type="checkbox" id='fme_oow_enable_notification_logs' <?php checked($fme_oow_enable_notification_logs, '1'); ?> name="fme_oow_enable_notification_logs">
				<p class="description inline">
					<?php echo esc_html__('If this is checked, notifications logs will be enabled and logs will store for each notification sent.', 'order-on-whatsapp'); ?>
				</p>
			</td>
		</tr>

		<!-- whatsapp user approval settings  -->
		<tr class='fma_oow_hide_show_content'>
			<th>
				<label for="fme_oow_enable_user_whatsapp_approval">
					<?php echo esc_html__('Enable whatsApp notification agreement checkbox', 'order-on-whatsapp'); ?>
				</label>
			</th>

			<td>
				&nbsp;&nbsp;
				<input type="checkbox" id='fme_oow_enable_user_whatsapp_approval' <?php checked($fme_oow_enable_user_whatsapp_approval, '1'); ?>
					name="fme_oow_enable_user_whatsapp_approval">
				<p class="description inline">
					<?php echo esc_html__('If this is checked, a checkbox will display on checkout page and ask for user approval if he/she wants to receive whatsapp notifications.', 'order-on-whatsapp'); ?><br />
					<?php echo esc_html__('If not checked, notification is sent to every user who places order.', 'order-on-whatsapp'); ?>
				</p>
			</td>
		</tr>

		<tr style="display: <?php echo 0 == $fme_oow_enable_user_whatsapp_approval ? 'none' : 'table-row'; ?>;"
			id="fme_oow_enable_user_whatsapp_approval_label_row">
			<th scope="row">
				<label for="fme_oow_enable_user_whatsapp_approval_label">
					<?php echo esc_html__('Agreement checkbox label', 'order-on-whatsapp'); ?>
				</label>
			</th>
			<td>
				<span class="tip">
					<?php 
					echo wc_help_tip(esc_html__('Whatsapp notification agreement checkbox label.', 'order-on-whatsapp')); // phpcs:ignore 
					?>
				</span>&nbsp;&nbsp;
				<label>
					<input type="text" class='fma_oow_all_inputs' name="fme_oow_enable_user_whatsapp_approval_label"
						required="required" id="fme_oow_enable_user_whatsapp_approval_label"
						value="<?php echo esc_html($fme_oow_enable_user_whatsapp_approval_label); ?>"
						placeholder="<?php echo esc_attr__('WhatsApp notification agreement checkbox label', 'order-on-whatsapp'); ?>">
				</label>
			</td>
		</tr>



		<tr>
			<th class="fma_sec_heading">
				<h3>
					<?php echo esc_html__('Facebook Whatsapp Api Credentials', 'order-on-whatsapp'); ?>
				</h3>
			</th>
		</tr>

		<tr>
			<th scope="row">
				<label for="fme_oow_fb_app_id">
					<?php echo esc_html__('Facebook app id', 'order-on-whatsapp'); ?>
				</label>
			</th>
			<td>
				<span class="tip">
					<?php 
					echo wc_help_tip(esc_html__('Enter your facebook app id.', 'order-on-whatsapp')); // phpcs:ignore 
					?>
				</span>&nbsp;&nbsp;
				<label>
					<input type="text" class='fma_oow_all_inputs' name="fme_oow_fb_app_id" required="required"
						id="fme_oow_fb_app_id" value="<?php echo esc_attr($fme_oow_fb_app_id); ?>"
						placeholder="<?php echo esc_attr__('Facebook app id', 'order-on-whatsapp'); ?>">

				</label>
			</td>
		</tr>

		<tr>
			<th scope="row">
				<label for="fme_oow_fb_access_token">
					<?php echo esc_html__('Access token', 'order-on-whatsapp'); ?>
				</label>
			</th>
			<td>
				<span class="tip">
					<?php 
					echo wc_help_tip(esc_html__('Enter your whatsapp access token.', 'order-on-whatsapp')); // phpcs:ignore 
					?>
				</span>&nbsp;&nbsp;
				<label>
					<input type="text" class='fma_oow_all_inputs' name="fme_oow_fb_access_token" required="required"
						id="fme_oow_fb_access_token" value="<?php echo esc_attr($fme_oow_fb_access_token); ?>"
						placeholder="<?php echo esc_attr__('Access token', 'order-on-whatsapp'); ?>">

				</label>
			</td>
		</tr>

		<tr>
			<th scope="row">
				<label for="fme_oow_fb_phone_number_id">
					<?php echo esc_html__('Phone number id', 'order-on-whatsapp'); ?>
				</label>
			</th>
			<td>
				<span class="tip">
					<?php 
					echo wc_help_tip(esc_html__('Enter your phone number id.', 'order-on-whatsapp')); // phpcs:ignore 
					?>
				</span>&nbsp;&nbsp;
				<label>
					<input type="text" class='fma_oow_all_inputs' name="fme_oow_fb_phone_number_id" required="required"
						id="fme_oow_fb_phone_number_id" value="<?php echo esc_attr($fme_oow_fb_phone_number_id); ?>"
						placeholder="<?php echo esc_attr__('Phone number id', 'order-on-whatsapp'); ?>">

				</label>
			</td>
		</tr>

		<tr>
			<th scope="row">
				<label for="fme_oow_fb_whatsapp_business_account_id">
					<?php echo esc_html__('Whatsapp business account id', 'order-on-whatsapp'); ?>
				</label>
			</th>
			<td>
				<span class="tip">
					<?php 
					echo wc_help_tip(esc_html__('Enter your whatsapp business account id.', 'order-on-whatsapp')); // phpcs:ignore 
					?>
				</span>&nbsp;&nbsp;
				<label>
					<input type="text" class='fma_oow_all_inputs' name="fme_oow_fb_whatsapp_business_account_id"
						required="required" id="fme_oow_fb_whatsapp_business_account_id"
						value="<?php echo esc_attr($fme_oow_fb_whatsapp_business_account_id); ?>"
						placeholder="<?php echo esc_attr__('Whatsapp business account id', 'order-on-whatsapp'); ?>">
				</label>
			</td>
		</tr>

		<tr>
			<th scope="row">
				<label>
					<?php echo esc_html__('Message Templates', 'order-on-whatsapp'); ?>
				</label>
			</th>
			<td>
				<!-- table is loaded via ajax request  -->
				<div class="fme_oow_notification_templates_table"></div>
			</td>
		</tr>

	</tbody>
</table>
<!-- Notification Settings Ends  -->
<!-- Display Settings -->

<table class="table-mastersettings table-outer form-table tbl fma_display_settings_tbl_" cellpadding="0"
	cellspacing="0" id='whatsapp_settings_tbl' style="display: none;">
	<tbody>
		<!----- Whatsapp btn display settings ------>
		<tr>
			<th class="fma_sec_heading" colspan="2">
				<h2 style="margin-top: 20px; border-bottom: 1px solid #ccc; padding-bottom: 5px;">
					<?php echo esc_html__('WhatsApp Button Display Settings', 'order-on-whatsapp'); ?>
				</h2>
				<p style="font-style: italic; color: #666;">
					<?php echo esc_html__('Configure how the main WhatsApp button appears on your shop, product, and cart pages.', 'order-on-whatsapp'); ?>
				</p>
			</th>
		</tr>

		<tr valign="top">
			<th scope="row">
				<label for="fma_oow_whatsapp_button_padding_top">
					<?php echo esc_html__('Button padding', 'order-on-whatsapp'); ?>
				</label>
			</th>
			<td>
				<span class="tip">
					<?php 
					echo wc_help_tip(esc_html__('Enter the button padding.', 'order-on-whatsapp')); // phpcs:ignore 
					?>
				</span>
				<input type="number" class='fma_oow_all_inputs' name="" id="fma_oow_whatsapp_button_padding_top"
					value="<?php echo esc_attr($fma_oow_whatsapp_button_padding_top); ?>" placeholder="<?php echo esc_attr__('Top', 'order-on-whatsapp'); ?>"
					style="width:98px;">
				<input type="number" class='fma_oow_all_inputs' name="" id="fma_oow_whatsapp_button_padding_bottom"
					value="<?php echo esc_attr($fma_oow_whatsapp_button_padding_bottom); ?>" placeholder="<?php echo esc_attr__('Bottom', 'order-on-whatsapp'); ?>"
					style="width:98px;">
				<input type="number" class='fma_oow_all_inputs' name="" id="fma_oow_whatsapp_button_padding_left"
					value="<?php echo esc_attr($fma_oow_whatsapp_button_padding_left); ?>" placeholder="<?php echo esc_attr__('Left', 'order-on-whatsapp'); ?>"
					style="width:98px;">
				<input type="number" class='fma_oow_all_inputs' name="" id="fma_oow_whatsapp_button_padding_right"
					value="<?php echo esc_attr($fma_oow_whatsapp_button_padding_right); ?>" placeholder="<?php echo esc_attr__('Right', 'order-on-whatsapp'); ?>"
					style="width:98px;">
				<p class="description">
					<?php echo esc_html__('Padding will be applied to button by using px unit.', 'order-on-whatsapp'); ?>
				</p>
			</td>
		</tr>

		<tr valign="top">
			<th scope="row">
				<label for="fma_oow_whatsapp_button_border_radius_top">
					<?php echo esc_html__('Button border radius', 'order-on-whatsapp'); ?>
				</label>
			</th>
			<td>
				<span class="tip">
					<?php 
					echo wc_help_tip(esc_html__('Enter the button border radius.', 'order-on-whatsapp')); // phpcs:ignore 
					?>
				</span>
				<input type="number" class='fma_oow_all_inputs' name="" id="fma_oow_whatsapp_button_border_radius_top"
					value="<?php echo esc_attr($fma_oow_whatsapp_button_border_radius_top); ?>" placeholder="<?php echo esc_attr__('Top Left', 'order-on-whatsapp'); ?>"
					style="width:120px;">
				<input type="number" class='fma_oow_all_inputs' name=""
					id="fma_oow_whatsapp_button_border_radius_bottom"
					value="<?php echo esc_attr($fma_oow_whatsapp_button_border_radius_bottom); ?>"
					placeholder="<?php echo esc_attr__('Top Right', 'order-on-whatsapp'); ?>" style="width:120px;">
				<input type="number" class='fma_oow_all_inputs' name="" id="fma_oow_whatsapp_button_border_radius_left"
					value="<?php echo esc_attr($fma_oow_whatsapp_button_border_radius_left); ?>"
					placeholder="<?php echo esc_attr__('Bottom Left', 'order-on-whatsapp'); ?>" style="width:120px;">
				<input type="number" class='fma_oow_all_inputs' name="" id="fma_oow_whatsapp_button_border_radius_right"
					value="<?php echo esc_attr($fma_oow_whatsapp_button_border_radius_right); ?>"
					placeholder="<?php echo esc_attr__('Bottom Right', 'order-on-whatsapp'); ?>" style="width:120px;">
				<p class="description">
					<?php echo esc_html__('Border radius will be applied to button by using px unit.', 'order-on-whatsapp'); ?>
				</p>
			</td>
		</tr>

		<!-- customize cart button -->
		<tr>
			<th><label for="fma_order_on_whatsapp_cart_btn_bg_color">
					<?php echo esc_html__('WhatsApp button bg color', 'order-on-whatsapp'); ?>
				</label></th>
			<td>
				<span class="tip">
					<?php 
					echo wc_help_tip(esc_html__('Add to cart button background color.', 'order-on-whatsapp')); // phpcs:ignore 
					?>
				</span>&nbsp;&nbsp;
				<input type="text" id='fma_order_on_whatsapp_cart_btn_bg_color'
					value='<?php echo esc_attr($fma_order_on_whatsapp_cart_btn_bg_color); ?>' class='jscolor'>
				<p class="description">
					<?php echo esc_html__('Default value is "25D366"', 'order-on-whatsapp'); ?>
				</p>
			</td>
		</tr>

		<tr>
			<th><label for="fma_order_on_whatsapp_cart_btn_text_color">
					<?php echo esc_html__('WhatsApp button text color', 'order-on-whatsapp'); ?>
				</label></th>
			<td>
				<span class="tip">
					<?php 
					echo wc_help_tip(esc_html__('Add to cart button text color.', 'order-on-whatsapp')); // phpcs:ignore 
					?>
				</span>&nbsp;&nbsp;
				<input type="text" id='fma_order_on_whatsapp_cart_btn_text_color'
					value='<?php echo esc_attr($fma_order_on_whatsapp_cart_btn_text_color_hash); ?>' class='jscolor'>
				<p class="description">
					<?php echo esc_html__('Default Color is "FFFFFF"', 'order-on-whatsapp'); ?>
				</p>
			</td>
		</tr>

		<tr>
			<th><label for="fma_order_on_whatsapp_btn_border_clr">
					<?php echo esc_html__('WhatsApp button border color', 'order-on-whatsapp'); ?>
				</label></th>
			<td>
				<span class="tip">
					<?php 
					echo wc_help_tip(esc_html__('This color will be applied to the border of WhatsApp button.', 'order-on-whatsapp')); // phpcs:ignore 
					?>
				</span>&nbsp;&nbsp;
				<input type="text" id='fma_order_on_whatsapp_btn_border_clr'
					value='<?php echo esc_attr($whatsapp_btn_border_clr_hash); ?>' class='jscolor'>
				<p class="description">
					<?php echo esc_html__('Default value is "25D366"', 'order-on-whatsapp'); ?>
				</p>
			</td>
		</tr>

		<tr>
			<th><label for="fma_order_on_whatsapp_btn_border_width">
					<?php echo esc_html__('WhatsApp button border width', 'order-on-whatsapp'); ?>
				</label></th>
			<td>
				<span class="tip">
					<?php 
					echo wc_help_tip(esc_html__('Border Width of WhatsApp Button.', 'order-on-whatsapp')); // phpcs:ignore 
					?>
				</span>&nbsp;&nbsp;
				<input type="Number" min="1" id='fma_order_on_whatsapp_btn_border_width'
					value='<?php echo esc_attr($whatsapp_btn_border_clr_width); ?>'>
				<p class="description">
					<?php echo esc_html__('The Width will be measured in "px"', 'order-on-whatsapp'); ?>
				</p>

			</td>
		</tr>
		<tr>
			<th><label for="fma_oow_shop_whatsapp_btn_width">
					<?php echo esc_html__('WhatsApp button width (Shop)', 'order-on-whatsapp'); ?>
				</label></th>
			<td>
				<span class="tip">
					<?php 
					echo wc_help_tip(esc_html__('Border Width of WhatsApp Button.', 'order-on-whatsapp')); // phpcs:ignore 
					?>
				</span>&nbsp;&nbsp;
				<input type="Number" min="1" id='fma_oow_shop_whatsapp_btn_width'
					value='<?php echo esc_attr($fma_oow_shop_whatsapp_btn_width); ?>'>
				<p class="description">
					<?php echo esc_html__('The Width will be measured in "px"', 'order-on-whatsapp'); ?>
				</p>

			</td>
		</tr>
		<tr>
			<th><label for="fma_oow_prd_whatsapp_btn_width">
					<?php echo esc_html__('WhatsApp button width (Product)', 'order-on-whatsapp'); ?>
				</label></th>
			<td>
				<span class="tip">
					<?php 
					echo wc_help_tip(esc_html__('Border Width of WhatsApp Button.', 'order-on-whatsapp')); // phpcs:ignore 
					?>
				</span>&nbsp;&nbsp;
				<input type="Number" min="1" id='fma_oow_prd_whatsapp_btn_width'
					value='<?php echo esc_attr($fma_oow_prd_whatsapp_btn_width); ?>'>
				<p class="description">
					<?php echo esc_html__('The Width will be measured in "px"', 'order-on-whatsapp'); ?>
				</p>

			</td>
		</tr>
		<tr>
			<th><label for="fma_oow_cart_whatsapp_btn_width">
					<?php echo esc_html__('WhatsApp button width (cart)', 'order-on-whatsapp'); ?>
				</label></th>
			<td>
				<span class="tip">
					<?php 
					echo wc_help_tip(esc_html__('Border Width of WhatsApp Button.', 'order-on-whatsapp')); // phpcs:ignore 
					?>
				</span>&nbsp;&nbsp;
				<input type="Number" min="1" id='fma_oow_cart_whatsapp_btn_width'
					value='<?php echo esc_attr($fma_oow_cart_whatsapp_btn_width); ?>'>
				<p class="description">
					<?php echo esc_html__('The Width will be measured in "px"', 'order-on-whatsapp'); ?>
				</p>

			</td>
		</tr>
		<!---- Whatsapp btn display settings ends ----->



		<!---- Share btn display settings  ----->


		<tr>
			<th class="fma_sec_heading" colspan="2">
				<h2 style="margin-top: 40px; border-bottom: 1px solid #ccc; padding-bottom: 5px;">
					<?php echo esc_html__('WhatsApp Share Button Display Settings', 'order-on-whatsapp'); ?>
				</h2>
				<p style="font-style: italic; color: #666;">
					<?php echo esc_html__('Customize the appearance of the WhatsApp Share button displayed for sharing products or pages.', 'order-on-whatsapp'); ?>
				</p>
			</th>
		</tr>
		<tr valign="top">
			<th scope="row">
				<label for="fma_oow_share_button_padding_top">
					<?php echo esc_html__('Button padding', 'order-on-whatsapp'); ?>
				</label>
			</th>
			<td>
				<span class="tip">
					<?php 
					echo wc_help_tip(esc_html__('Enter the button padding.', 'order-on-whatsapp')); // phpcs:ignore 
					?>
				</span>&nbsp;&nbsp;
				<input type="number" class='fma_oow_all_inputs' name="" id="fma_oow_share_button_padding_top"
					value="<?php echo esc_attr($fma_oow_share_button_padding_top); ?>" placeholder="<?php echo esc_attr__('Top', 'order-on-whatsapp'); ?>"
					style="width:98px;">
				<input type="number" class='fma_oow_all_inputs' name="" id="fma_oow_share_button_padding_bottom"
					value="<?php echo esc_attr($fma_oow_share_button_padding_bottom); ?>" placeholder="<?php echo esc_attr__('Bottom', 'order-on-whatsapp'); ?>"
					style="width:98px;">
				<input type="number" class='fma_oow_all_inputs' name="" id="fma_oow_share_button_padding_left"
					value="<?php echo esc_attr($fma_oow_share_button_padding_left); ?>" placeholder="<?php echo esc_attr__('Left', 'order-on-whatsapp'); ?>"
					style="width:98px;">
				<input type="number" class='fma_oow_all_inputs' name="" id="fma_oow_share_button_padding_right"
					value="<?php echo esc_attr($fma_oow_share_button_padding_right); ?>" placeholder="<?php echo esc_attr__('Right', 'order-on-whatsapp'); ?>"
					style="width:98px;">
				<p class="description">
					<?php echo esc_html__('Padding will be applied to button by using px unit.', 'order-on-whatsapp'); ?>
				</p>
			</td>
		</tr>

		<tr valign="top">
			<th scope="row">
				<label for="fma_oow_share_button_border_radius_top">
					<?php echo esc_html__('Button border radius', 'order-on-whatsapp'); ?>
				</label>
			</th>
			<td>
				<span class="tip">
					<?php 
					echo wc_help_tip(esc_html__('Enter the button border radius.', 'order-on-whatsapp')); // phpcs:ignore 
					?>
				</span>&nbsp;&nbsp;
				<input type="number" class='fma_oow_all_inputs' name="" id="fma_oow_share_button_border_radius_top"
					value="<?php echo esc_attr($fma_oow_share_button_border_radius_top); ?>" placeholder="<?php echo esc_attr__('Top Left', 'order-on-whatsapp'); ?>"
					style="width:120px;">
				<input type="number" class='fma_oow_all_inputs' name="" id="fma_oow_share_button_border_radius_bottom"
					value="<?php echo esc_attr($fma_oow_share_button_border_radius_bottom); ?>" placeholder="<?php echo esc_attr__('Top Right', 'order-on-whatsapp'); ?>"
					style="width:120px;">
				<input type="number" class='fma_oow_all_inputs' name="" id="fma_oow_share_button_border_radius_left"
					value="<?php echo esc_attr($fma_oow_share_button_border_radius_left); ?>" placeholder="<?php echo esc_attr__('Bottom Left', 'order-on-whatsapp'); ?>"
					style="width:120px;">
				<input type="number" class='fma_oow_all_inputs' name="" id="fma_oow_share_button_border_radius_right"
					value="<?php echo esc_attr($fma_oow_share_button_border_radius_right); ?>"
					placeholder="<?php echo esc_attr__('Bottom Right', 'order-on-whatsapp'); ?>" style="width:120px;">
				<p class="description">
					<?php echo esc_html__('Border radius will be applied to button by using px unit.', 'order-on-whatsapp'); ?>
				</p>
			</td>
		</tr>


		<!-- share button bg color -->
		<tr class="share_btn_content">
			<th><label for="fma_oow_share_btn_bg_color">
					<?php echo esc_html__('Share button bg color', 'order-on-whatsapp'); ?>
				</label></th>
			<td>
				<span class="tip">
					<?php 
					echo wc_help_tip(esc_html__('Set the BG color of share button', 'order-on-whatsapp')); // phpcs:ignore 
					?>
				</span>&nbsp;&nbsp;
				<input type="text" value="<?php echo esc_attr($fma_oow_share_btn_bg_color); ?>" class="jscolor"
					placeholder="<?php echo esc_attr__('Button BG color', 'order-on-whatsapp'); ?>" id='fma_oow_share_btn_bg_color'>
				<p class="description">
					<?php echo esc_html__('Default is "25D366"', 'order-on-whatsapp'); ?>
				</p>
			</td>
		</tr>

		<!-- share button text color -->
		<tr class="share_btn_content">
			<th><label for="fma_oow_share_btn_text_color">
					<?php echo esc_html__('Share button text color', 'order-on-whatsapp'); ?>
				</label></th>
			<td>
				<span class="tip">
					<?php 
					echo wc_help_tip(esc_html__('Set the text color of share button', 'order-on-whatsapp')); // phpcs:ignore 
					?>
				</span>&nbsp;&nbsp;
				<input type="text" value="<?php echo esc_attr($fma_oow_share_btn_text_color); ?>" class="jscolor"
					placeholder="<?php echo esc_attr__('Button text color', 'order-on-whatsapp'); ?>" id='fma_oow_share_btn_text_color'>
				<p class="description">
					<?php echo esc_html__('Default is "FFFFFF"', 'order-on-whatsapp'); ?>
				</p>
			</td>
		</tr>
		<tr>
			<th><label for="fma_share_btn_border_clr">
					<?php echo esc_html__('Share button border color', 'order-on-whatsapp'); ?>
				</label></th>
			<td>
				<span class="tip">
					<?php 
					echo wc_help_tip(esc_html__('This color will be applied to the border of Share button.', 'order-on-whatsapp')); // phpcs:ignore 
					?>
				</span>&nbsp;&nbsp;
				<input type="text" id='fma_share_btn_border_clr'
					value='<?php echo esc_html($share_btn_border_clr_hash); ?>' class='jscolor'>
				<p class="description">
					<?php echo esc_html__('Default value is "25D366"', 'order-on-whatsapp'); ?>
				</p>
			</td>
		</tr>

		<tr>
			<th><label for="fma_share_btn_border_width">
					<?php echo esc_html__('Share button border width', 'order-on-whatsapp'); ?>
				</label></th>
			<td>
				<span class="tip">
					<?php 
					echo wc_help_tip(esc_html__('Border Width of Share Button.', 'order-on-whatsapp')); // phpcs:ignore 
					?>
				</span>&nbsp;&nbsp;
				<input type="Number" min="1" id='fma_share_btn_border_width'
					value='<?php echo esc_attr($share_btn_border_clr_width); ?>'>
				<p class="description">
					<?php echo esc_html__('The Width will be measured in "px"', 'order-on-whatsapp'); ?>
				</p>

			</td>
		</tr>
		<tr>
			<th><label for="fma_oow_shop_share_btn_width">
					<?php echo esc_html__('Share button width (Shop)', 'order-on-whatsapp'); ?>
				</label></th>
			<td>
				<span class="tip">
					<?php 
					echo wc_help_tip(esc_html__('Width of Share Button on shop page.', 'order-on-whatsapp')); // phpcs:ignore 
					?>
				</span>&nbsp;&nbsp;
				<input type="Number" min="1" id='fma_oow_shop_share_btn_width'
					value='<?php echo esc_attr($fma_oow_shop_share_btn_width); ?>'>
				<p class="description">
					<?php echo esc_html__('The Width will be measured in "px"', 'order-on-whatsapp'); ?>
				</p>

			</td>
		</tr>
		<tr>
			<th><label for="fma_oow_prd_share_btn_width">
					<?php echo esc_html__('Share button width (Product)', 'order-on-whatsapp'); ?>
				</label></th>
			<td>
				<span class="tip">
					<?php 
					echo wc_help_tip(esc_html__('Width of Share Button on product page.', 'order-on-whatsapp')); // phpcs:ignore 
					?>
				</span>&nbsp;&nbsp;
				<input type="Number" min="1" id='fma_oow_prd_share_btn_width'
					value='<?php echo esc_attr($fma_oow_prd_share_btn_width); ?>'>
				<p class="description">
					<?php echo esc_html__('The Width will be measured in "px"', 'order-on-whatsapp'); ?>
				</p>

			</td>
		</tr>
		<tr>
			<th><label for="fma_oow_cart_share_btn_width">
					<?php echo esc_html__('Share button width (cart)', 'order-on-whatsapp'); ?>
				</label></th>
			<td>
				<span class="tip">
					<?php 
					echo wc_help_tip(esc_html__('Width of Share Button on cart page.', 'order-on-whatsapp')); // phpcs:ignore 
					?>
				</span>&nbsp;&nbsp;
				<input type="Number" min="1" id='fma_oow_cart_share_btn_width'
					value='<?php echo esc_attr($fma_oow_cart_share_btn_width); ?>'>
				<p class="description">
					<?php echo esc_html__('The Width will be measured in "px"', 'order-on-whatsapp'); ?>
				</p>

			</td>
		</tr>
		<!---- Share btn display settings ends ----->
	</tbody>
</table>
<!-- Display Settings Ends -->

<table class="table-mastersettings table-outer form-table tbl fma_message_template_tbl_" cellpadding="0"
	cellspacing="0" id="whatsapp_message_template_tbl" style="display: none;">
	<tbody>
		<tr>
			<th class="fma_sec_heading" colspan="2">
				<h2>
					<?php echo esc_html__('Message template settings', 'order-on-whatsapp'); ?>
				</h2>
				<p class="description" style="margin-top:0;">
					<?php echo esc_html__('Optional: customize the message sent after checkout when customers are redirected to WhatsApp. Leave empty to keep the original message format.', 'order-on-whatsapp'); ?>
				</p>
			</th>
		</tr>
		<tr valign="top">
			<th scope="row">
				<label for="fma_oow_whatsapp_order_message_template">
					<?php echo esc_html__('Order message template', 'order-on-whatsapp'); ?>
				</label>
			</th>
			<td>
				<span class="tip">
					<?php echo wc_help_tip(esc_html__('Use placeholders in braces. Unrecognized brace tokens are read as order meta keys (e.g. tracking fields).', 'order-on-whatsapp')); ?>
				</span>
				<textarea class="large-text" rows="14" id="fma_oow_whatsapp_order_message_template" cols="50"><?php echo esc_textarea($fma_oow_whatsapp_order_message_template); ?></textarea>
				<p class="description"><strong><?php echo esc_html__('Built-in placeholders', 'order-on-whatsapp'); ?></strong></p>
				<p class="description" style="font-size:12px;line-height:1.6;">
					<?php echo esc_html('{order_id}, {order_number}, {order_total}, {order_currency}, {payment_method}, {shipping_method}, {customer_note}, {order_date}'); ?><br />
					<?php echo esc_html('{billing_first_name}, {billing_last_name}, {billing_company}, {billing_phone}, {billing_email}, {billing_address_1}, {billing_address_2}, {billing_city}, {billing_state}, {billing_postcode}, {billing_country}'); ?><br />
					<?php echo esc_html('{shipping_first_name}, {shipping_last_name}, {shipping_company}, {shipping_phone}, {shipping_address_1}, {shipping_address_2}, {shipping_city}, {shipping_state}, {shipping_postcode}, {shipping_country}'); ?><br />
					<?php echo esc_html('{site_name}, {site_url}, {view_order_url}, {checkout_payment_url}, {pay_now_url}, {prefilled_message}, {order_items}'); ?>
				</p>
				<p class="description"><strong><?php echo esc_html__('Order meta (dynamic)', 'order-on-whatsapp'); ?></strong></p>
				<p class="description" style="font-size:12px;">
					<?php echo esc_html__('Use any order meta key:', 'order-on-whatsapp'); ?>
					<code>{_tracking_number}</code>, <code>{delivery_date}</code>
				</p>
				<p class="description" style="font-size:12px;">
					<?php echo esc_html__('Built-in names take priority over meta keys. If “Send pay now link” is enabled and the payment URL is not already in the message, it will be appended automatically.', 'order-on-whatsapp'); ?>
				</p>
			</td>
		</tr>
	</tbody>
</table>

<!-- /////////////////////////////////// ADDED BY SAQIB /////////////////////////// -->

<tr>
	<td><input type="button" name="" id='fma_order_on_whatsapp_whatsapp_save_changes_btn'
			value="<?php echo esc_html__('Save Changes', 'order-on-whatsapp'); ?>" class="button button-primary"></td>
</tr>