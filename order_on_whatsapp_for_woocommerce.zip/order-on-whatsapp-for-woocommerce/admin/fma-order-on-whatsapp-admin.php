<?php
use Automattic\WooCommerce\Utilities\OrderUtil;
// Actions
add_filter('woocommerce_screen_ids', 'fmaOrderOnWhatsappSetWcScreenIdsWhatsappContact'); // back end/admin

add_filter('woocommerce_settings_tabs_array', 'fma_order_on_whatsapp_filter_woocommerce_settings_tabs_array', 50); //admin
add_action('woocommerce_settings_my_sub_menu_whatsapp', 'fmaOrderOnWhatsappSettings'); //admin
add_action('admin_enqueue_scripts', 'fma_order_on_whatsapp_admin_enqueue_scripts');
add_action('admin_enqueue_scripts', 'fma_order_on_whatsapp_admin_orders_enqueue_scripts');

// when save changes  clicked ajax, at backend side
add_action('wp_ajax_when_save_changes_whatsapp_btn_clicked', 'fma_order_on_whatsapp_save_changes_clicked');
add_action('wp_ajax_fme_get_product_applied_array', ( 'fmeGetAjaxProductsArray' ));
add_action('wp_ajax_fme_get_category_applied_array', 'fmeGetAjaxCategoriesArray');
add_action('wp_ajax_fme_order_on_whatsapp_review_notice_dismissed', 'fme_order_on_whatsapp_review_notice_dismissed');


// Add custom column header to admin order list
if (class_exists(OrderUtil::class) && OrderUtil::custom_orders_table_usage_is_enabled()) {
	// HPOS usage is enabled.
	add_filter('manage_woocommerce_page_wc-orders_columns', 'fma_add_custom_order_column', 20, 1);
	add_action('manage_woocommerce_page_wc-orders_custom_column', 'fma_custom_order_column_content', 20, 2);
} else {
	// Traditional CPT-based orders are in use.
	add_filter('manage_edit-shop_order_columns', 'fma_add_custom_order_column', 20, 1);
	add_action('manage_shop_order_posts_custom_column', 'fma_custom_order_column_content', 20, 2);
}

/**
 * Add custom order column
 *
 * @param array $columns
 * @return array
 */
function fma_add_custom_order_column( $columns ) {
	$fma_new_columns = array();
	foreach ($columns as $key => $column) {
		$fma_new_columns[$key] = $column;
		if ('order_status' == $key) {
			$fma_new_columns['order_through'] = __('Whatsapp Order', 'order-on-whatsapp');
		}
	}
	return $fma_new_columns;
}

function fme_order_on_whatsapp_review_notice_dismissed() {  

	check_ajax_referer('admin_ajax_nonce', 'nonce');

	if ( ! current_user_can('manage_woocommerce') ) {
		wp_send_json_error(array( 'message' => 'Unauthorized' ), 403);
	}

	$user_id = get_current_user_id();
	if ( $user_id ) {
		update_user_meta( $user_id, 'fme_order_on_whatsapp_review_notice_dismissed', 'yes' );
	}
	wp_send_json_success();
}
/**
 * Display data for custom order column
 *
 * @param array $columns
 * @param object $order
 * @return string
 */
function fma_custom_order_column_content( $column, $order ) {
	if ('order_through' == $column) {
		$order = wc_get_order($order);
		$whatsapp_order = $order->get_meta('fme_oow_order', true);
		if ('norder' == $whatsapp_order || '' == $whatsapp_order) {
			echo '<span class="fma-oow-order-through-cell"></span>';
		} else {
			$whatsapp_icon = plugin_dir_url(__FILE__) . 'icons/wp_icon2.png';
			echo '<span class="fma-oow-order-through-cell"><img class="fma-oow-order-through-icon" src="' . esc_url($whatsapp_icon) . '" alt="" width="32" height="32"></span>';
		}
	}
}

/**
 * Enqueue admin assets only on the Order On WhatsApp settings tab.
 *
 * @param string $hook Current admin screen hook suffix.
 * @return void
 */
function fma_order_on_whatsapp_admin_enqueue_scripts( $hook ) {
	if ('woocommerce_page_wc-settings' !== $hook) {
		return;
	}
	if (!isset($_GET['tab']) || 'my_sub_menu_whatsapp' !== $_GET['tab']) {
		return;
	}

	wp_enqueue_script('jquery');
	wp_enqueue_script('jquery-form');

	wp_enqueue_style('fma_order_on_whatsapp_contact', FMA_OOW_PLUGIN_URL . 'assets/css/fma-order-on-whatsapp.css', array(), FMA_OOW_VERSION);
	wp_enqueue_style('fma_order_on_whatsapp_font_awesome', FMA_OOW_PLUGIN_URL . 'assets/css/fontawesome.min.css', array(), FMA_OOW_VERSION);
	wp_enqueue_style('fma_order_on_whatsapp_style', FMA_OOW_PLUGIN_URL . 'assets/css/select2.min.css', array(), FMA_OOW_VERSION);
	wp_enqueue_style(
		'fma_oow_admin_settings',
		FMA_OOW_PLUGIN_URL . 'assets/css/fma-order-on-whatsapp-admin.css',
		array( 'fma_order_on_whatsapp_contact' ),
		FMA_OOW_VERSION
	);

	wp_enqueue_script('fma_order_on_whatsapp_select2Lib', FMA_OOW_PLUGIN_URL . 'assets/js/select2.min.js', array( 'jquery' ), FMA_OOW_VERSION, true);
	wp_enqueue_script('fma_order_on_whatsapp_my_script_for_whatsapp_contact', FMA_OOW_PLUGIN_URL . 'assets/js/fma-order-on-whatsapp.js', array( 'jquery', 'fma_order_on_whatsapp_select2Lib' ), FMA_OOW_VERSION, true);
	wp_enqueue_script('fma_order_on_whatsapp_admin', FMA_OOW_PLUGIN_URL . 'assets/js/fma-order-on-whatsapp-admin.js', array( 'jquery' ), FMA_OOW_VERSION, true);
	wp_enqueue_script('fma_order_on_whatsapp_js_color_file', plugin_dir_url(__FILE__) . 'jscolor.js', array(), FMA_OOW_VERSION, true);

	$ewcpm_data = array(
		'admin_url' => admin_url('admin-ajax.php'),
		'admin_ajax_nonce' => wp_create_nonce('admin_ajax_nonce'),
		'enter_name' => WpmlHelper::translate(__('Enter name', 'order-on-whatsapp'), 'enter_name'),
		'enter_1st_whatsapp_number' => WpmlHelper::translate(__('Enter 1st whatsapp number', 'order-on-whatsapp'), 'enter_1st_whatsapp_number'),
		'active' => WpmlHelper::translate(__('Active', 'order-on-whatsapp'), 'active'),
		'inactive' => WpmlHelper::translate(__('InActive', 'order-on-whatsapp'), 'inactive'),
		'fma_order_on_whatsapp_payment_method_whatsapp' => WpmlHelper::translate(__('Cash On Delivery', 'order-on-whatsapp'), 'fma_order_on_whatsapp_payment_method_whatsapp'),
		'fma_order_on_whatsapp_name_text' => WpmlHelper::translate(__('Name:', 'order-on-whatsapp'), 'fma_order_on_whatsapp_name_text'),
		'fma_order_on_whatsapp_company_name_text' => WpmlHelper::translate(__('Company Name:', 'order-on-whatsapp'), 'fma_order_on_whatsapp_company_name_text'),
		'fma_order_on_whatsapp_country_text' => WpmlHelper::translate(__('Country:', 'order-on-whatsapp'), 'fma_order_on_whatsapp_country_text'),
		'fma_order_on_whatsapp_street_address_text' => WpmlHelper::translate(__('Street Address:', 'order-on-whatsapp'), 'fma_order_on_whatsapp_street_address_text'),
		'fma_order_on_whatsapp_town_or_city_text' => WpmlHelper::translate(__('Town/City:', 'order-on-whatsapp'), 'fma_order_on_whatsapp_town_or_city_text'),
		'fma_order_on_whatsapp_state_or_country_text' => WpmlHelper::translate(__('State/Country:', 'order-on-whatsapp'), 'fma_order_on_whatsapp_state_or_country_text'),
		'fma_order_on_whatsapp_post_code_or_zip_text' => WpmlHelper::translate(__('Postcode/ZIP:', 'order-on-whatsapp'), 'fma_order_on_whatsapp_post_code_or_zip_text'),
		'fma_order_on_whatsapp_phone_text' => WpmlHelper::translate(__('Phone:', 'order-on-whatsapp'), 'fma_order_on_whatsapp_phone_text'),
		'fma_order_on_whatsapp_quantity_text' => WpmlHelper::translate(__('Quantity:', 'order-on-whatsapp'), 'fma_order_on_whatsapp_quantity_text'),
		'fma_order_on_whatsapp_products_details_text' => WpmlHelper::translate(__('Product Details', 'order-on-whatsapp'), 'fma_order_on_whatsapp_products_details_text'),
		'fma_order_on_whatsapp_user_details_text' => WpmlHelper::translate(__('User Details', 'order-on-whatsapp'), 'fma_order_on_whatsapp_user_details_text'),
		'fma_order_on_whatsapp_date_text' => WpmlHelper::translate(__('Date: ', 'order-on-whatsapp'), 'fma_order_on_whatsapp_date_text'),
		'fma_order_on_whatsapp_user_email' => WpmlHelper::translate(__('Email: ', 'order-on-whatsapp'), 'fma_order_on_whatsapp_user_email'),
		'fma_order_on_whatsapp_total_expense' => WpmlHelper::translate(__('Total: ', 'order-on-whatsapp'), 'fma_order_on_whatsapp_total_expense'),
		'fma_order_on_whatsapp_products_list_placeholder' => WpmlHelper::translate(__('Select a Product', 'order-on-whatsapp'), 'fma_order_on_whatsapp_products_list_placeholder'),
		'fma_order_on_whatsapp_categories_list_placeholder' => WpmlHelper::translate(__('Select a Category', 'order-on-whatsapp'), 'fma_order_on_whatsapp_categories_list_placeholder'),
	);
	wp_localize_script('fma_order_on_whatsapp_my_script_for_whatsapp_contact', 'ewcpm_php_vars', $ewcpm_data);
	wp_localize_script('fma_order_on_whatsapp_admin', 'ewcpm_php_vars', $ewcpm_data);
	wp_localize_script('fma_order_on_whatsapp_my_script_for_whatsapp_contact', 'ajax_url_add_pq', array( 'ajax_url_add_pq_data' => admin_url('admin-ajax.php') ));
	wp_localize_script('fma_order_on_whatsapp_admin', 'ajax_url_add_pq', array( 'ajax_url_add_pq_data' => admin_url('admin-ajax.php') ));
}

/**
 * Enqueue admin styles on WooCommerce order list screens.
 *
 * @param string $hook Current admin screen hook suffix.
 * @return void
 */
function fma_order_on_whatsapp_admin_orders_enqueue_scripts( $hook ) {
	if ('woocommerce_page_wc-orders' === $hook) {
		wp_enqueue_style(
			'fma_oow_admin_orders',
			FMA_OOW_PLUGIN_URL . 'assets/css/fma-order-on-whatsapp-admin.css',
			array(),
			FMA_OOW_VERSION
		);
		return;
	}

	if ('edit.php' !== $hook) {
		return;
	}

	$screen = function_exists('get_current_screen') ? get_current_screen() : null;
	if (!$screen || 'shop_order' !== $screen->post_type) {
		return;
	}

	wp_enqueue_style(
		'fma_oow_admin_orders',
		FMA_OOW_PLUGIN_URL . 'assets/css/fma-order-on-whatsapp-admin.css',
		array(),
		FMA_OOW_VERSION
	);
}

/**
 * Added submenu setting in WooCommerce order on WhatsApp setting tab
 *
 * @return void
 */
function fmaOrderOnWhatsappSettings() {

	$fma_order_on_whatsapp_selected_categories = get_option('fma_order_on_whatsapp_categories_list');

	if (empty ($fma_order_on_whatsapp_selected_categories) || '' == $fma_order_on_whatsapp_selected_categories) {
		$fma_order_on_whatsapp_selected_categories = array();
	}
	$fma_order_on_whatsapp_check_products_list = '';
	$fma_order_on_whatsapp_check_categories_list = '';
	$fma_order_on_whatsapp_make_products_list_required = false;
	$fma_order_on_whatsapp_make_categories_list_required = false;

	$fma_oow_apply_on_all_products = get_option('fma_oow_apply_on_all_products');

	$fma_oow_all_products_checkbox = '';
	if ('yes' == $fma_oow_apply_on_all_products) {
		$fma_oow_all_products_checkbox = 'checked';
	}

	$fma_oow_prods_row_display = '';
	$fma_oow_cats_row_display = '';
	$newone = '';
	$newonecat = '';
	if ('checked' == $fma_oow_all_products_checkbox) {
		$fma_oow_cats_row_display = 'none';
		$fma_oow_prods_row_display = 'none';
	} else {
		$fma_order_on_whatsapp_either_products_or_cats = get_option('fma_order_on_whatsapp_either_products_or_cats', true);
		if ('fma_order_on_whatsapp_products_list' == $fma_order_on_whatsapp_either_products_or_cats) {
	
			$fma_order_on_whatsapp_check_products_list = 'selected';
			$newone = 'checked';
			$fma_oow_cats_row_display = 'none';
			$fma_order_on_whatsapp_make_products_list_required = true;
	
		} else if ('categories' == $fma_order_on_whatsapp_either_products_or_cats) {
			$fma_order_on_whatsapp_check_categories_list = 'selected';
			$newonecat = 'selected';
			$fma_oow_prods_row_display = 'none';
			$fma_order_on_whatsapp_make_categories_list_required = true;
		}
	}
	$fma_order_on_whatsapp_selected_products_list = get_option('fma_order_on_whatsapp_products_list', true);
	$fma_order_on_whatsapp_button_text = WpmlHelper::translate( (string) get_option('fma_order_on_whatsapp_button_text', true), 'saved_fma_order_on_whatsapp_button_text' );
	$fma_order_on_whatsapp_number = get_option('fma_order_on_whatsapp_whatsapp_number', true);
	// show on different pages options
	$fma_order_on_whatsapp_show_on_shop_page = get_option('fma_order_on_whatsapp_show_on_shop_page', true);
	$fma_order_on_whatsapp_show_on_cart_page = get_option('fma_order_on_whatsapp_show_on_cart_page', true);
	$fma_order_on_whatsapp_show_on_checkout_page = get_option('fma_order_on_whatsapp_show_on_checkout_page', true);
	$fma_order_on_whatsapp_show_on_single_product = get_option('fma_order_on_whatsapp_show_on_single_product', true);
	$fma_order_on_whatsapp_share_show_on_shop_page = get_option('fma_order_on_whatsapp_share_show_btn_on_shop_page', true);
	$fma_order_on_whatsapp_share_show_on_cart_page = get_option('fma_order_on_whatsapp_share_show_btn_on_cart_page', true);
	$fma_order_on_whatsapp_share_show_on_checkout_page = get_option('fma_order_on_whatsapp_share_show_on_checkout_page', true);
	$fma_order_on_whatsapp_share_show_on_single_product = get_option('fma_order_on_whatsapp_share_show_btn_on_single_product', true);
	// new features
	$fma_oow_open_whatsapp_in_which_tab = get_option('fma_oow_open_whatsapp_in_which_tab');
	$fma_oow_where_to_place_whatsp_btn = get_option('fma_oow_where_to_place_whatsp_btn');
	$fma_oow_share_btn = get_option('fma_oow_share_btn');
	$fma_oow_share_btn_txt = WpmlHelper::translate( (string) get_option('fma_oow_share_btn_txt'), 'saved_fma_oow_share_btn_txt' );
	$fma_oow_share_btn_bg_color = get_option('fma_oow_share_btn_bg_color');
	$fma_oow_share_btn_text_color = get_option('fma_oow_share_btn_text_color');
	// whatsapp button padding
	$fma_oow_whatsapp_button_padding = maybe_unserialize(get_option('fma_oow_whatsapp_button_padding'));
	$fma_oow_whatsapp_button_padding_top = isset ($fma_oow_whatsapp_button_padding['top']) ? esc_html($fma_oow_whatsapp_button_padding['top']) : '';
	$fma_oow_whatsapp_button_padding_bottom = isset ($fma_oow_whatsapp_button_padding['bottom']) ? esc_html($fma_oow_whatsapp_button_padding['bottom']) : '';
	$fma_oow_whatsapp_button_padding_left = isset ($fma_oow_whatsapp_button_padding['left']) ? esc_html($fma_oow_whatsapp_button_padding['left']) : '';
	$fma_oow_whatsapp_button_padding_right = isset ($fma_oow_whatsapp_button_padding['right']) ? esc_html($fma_oow_whatsapp_button_padding['right']) : '';
	// whatsapp button border radius
	$fma_oow_whatsapp_button_border_radius = maybe_unserialize(get_option('fma_oow_whatsapp_button_border_radius'));
	$fma_oow_whatsapp_button_border_radius_top = isset ($fma_oow_whatsapp_button_border_radius['top']) ? esc_html($fma_oow_whatsapp_button_border_radius['top']) : '';
	$fma_oow_whatsapp_button_border_radius_bottom = isset ($fma_oow_whatsapp_button_border_radius['bottom']) ? esc_html($fma_oow_whatsapp_button_border_radius['bottom']) : '';
	$fma_oow_whatsapp_button_border_radius_left = isset ($fma_oow_whatsapp_button_border_radius['left']) ? esc_html($fma_oow_whatsapp_button_border_radius['left']) : '';
	$fma_oow_whatsapp_button_border_radius_right = isset ($fma_oow_whatsapp_button_border_radius['right']) ? esc_html($fma_oow_whatsapp_button_border_radius['right']) : '';
	// share button padding
	$fma_oow_share_button_padding = maybe_unserialize(get_option('fma_oow_share_button_padding'));
	$fma_oow_share_button_padding_top = isset ($fma_oow_share_button_padding['top']) ? esc_html($fma_oow_share_button_padding['top']) : '';
	$fma_oow_share_button_padding_bottom = isset ($fma_oow_share_button_padding['bottom']) ? esc_html($fma_oow_share_button_padding['bottom']) : '';
	$fma_oow_share_button_padding_left = isset ($fma_oow_share_button_padding['left']) ? esc_html($fma_oow_share_button_padding['left']) : '';
	$fma_oow_share_button_padding_right = isset ($fma_oow_share_button_padding['right']) ? esc_html($fma_oow_share_button_padding['right']) : '';
	// share button border radius
	$fma_oow_share_button_border_radius = maybe_unserialize(get_option('fma_oow_share_button_border_radius'));
	$fma_oow_share_button_border_radius_top = isset ($fma_oow_share_button_border_radius['top']) ? esc_html($fma_oow_share_button_border_radius['top']) : '';
	$fma_oow_share_button_border_radius_bottom = isset ($fma_oow_share_button_border_radius['bottom']) ? esc_html($fma_oow_share_button_border_radius['bottom']) : '';
	$fma_oow_share_button_border_radius_left = isset ($fma_oow_share_button_border_radius['left']) ? esc_html($fma_oow_share_button_border_radius['left']) : '';
	$fma_oow_share_button_border_radius_right = isset ($fma_oow_share_button_border_radius['right']) ? esc_html($fma_oow_share_button_border_radius['right']) : '';
	// whatsapp contact input label
	$fma_oow_whatsapp_contact_input_label = maybe_unserialize(get_option('fma_oow_whatsapp_contact_input_label', ''));
	$fma_oow_whatsapp_contact_input_label = isset ($fma_oow_whatsapp_contact_input_label) && '' != $fma_oow_whatsapp_contact_input_label ? $fma_oow_whatsapp_contact_input_label : 'Select Branch';
	$fma_oow_whatsapp_contact_input_label = WpmlHelper::translate( (string) $fma_oow_whatsapp_contact_input_label, 'saved_fma_oow_whatsapp_contact_input_label' );
	$whatsapp_btn_border_clr_hash = get_option('whatsapp_btn_border_clr_hash');
	$whatsapp_btn_border_clr_width = get_option('whatsapp_btn_border_clr_width');
	$fma_oow_shop_whatsapp_btn_width = get_option('fma_oow_shop_whatsapp_btn_width', '');
	$fma_oow_prd_whatsapp_btn_width = get_option('fma_oow_prd_whatsapp_btn_width', '');
	$fma_oow_cart_whatsapp_btn_width = get_option('fma_oow_cart_whatsapp_btn_width', '');
	$fma_oow_selected_icon = get_option('fma_oow_icons', '1');
	$fma_oow_def_icon_chk = get_option('fma_oow_def_icon_chk', 'on');
	$fma_oow_show_icon_only = get_option('fma_oow_show_icon_only', 'off');
	$fma_icon_clr = get_option('fma_icon_clr', '#ffffff');
	$fma_icon_size = get_option('fma_icon_size', '50');
	$share_btn_border_clr_hash = get_option('share_btn_border_clr_hash');
	$share_btn_border_clr_width = get_option('share_btn_border_clr_width');
	$fma_oow_shop_share_btn_width = get_option('fma_oow_shop_share_btn_width', '');
	$fma_oow_prd_share_btn_width = get_option('fma_oow_prd_share_btn_width', '');
	$fma_oow_cart_share_btn_width = get_option('fma_oow_cart_share_btn_width', '');
	$fma_oow_msg_when_whatsap_opens = WpmlHelper::translate( (string) get_option('fma_oow_msg_when_whatsap_opens'), 'saved_fma_oow_msg_when_whatsap_opens' );
	$fma_oow_share_msg_when_whatsap_opens = WpmlHelper::translate( (string) get_option('fma_oow_share_msg_when_whatsap_opens'), 'saved_fma_oow_share_msg_when_whatsap_opens' );
	$fma_oow_whatsapp_order_message_template = WpmlHelper::translate( (string) get_option('fma_oow_whatsapp_order_message_template', ''), 'saved_fma_oow_whatsapp_order_message_template' );
	$fma_order_on_whatsapp_hide_add_to_cart_button_shop_page = get_option('fma_order_on_whatsapp_hide_add_to_cart_button_shop_page');
	$fma_order_on_whatsapp_hide_add_to_cart_button_shop_page = get_option('fma_order_on_whatsapp_hide_add_to_cart_button_shop_page');
	$fma_order_on_whatsapp_hide_add_to_cart_button_product_page = get_option('fma_order_on_whatsapp_hide_add_to_cart_button_product_page');
	$fma_order_on_whatsa_button_on_desktop = get_option('fma_order_on_whatsa_button_on_desktop');
	$fma_order_on_whatsapp_cart_btn_bg_color = get_option('fma_order_on_whatsapp_cart_btn_bg_color_hash');
	$fma_order_on_whatsapp_cart_btn_text_color_hash = get_option('fma_order_on_whatsapp_cart_btn_text_color_hash');

	$fma_oow_whatsapp_contact_numbers = maybe_unserialize(get_option('fma_oow_whatsapp_contact_numbers', array()));
	$multiple_whatsapp_numbers_exists = isset($fma_oow_whatsapp_contact_numbers['fma_oow_whatsapp_contacts']) ? count($fma_oow_whatsapp_contact_numbers['fma_oow_whatsapp_contacts']) : 0;
	if (isset($fma_oow_whatsapp_contact_numbers['fma_oow_whatsapp_contacts']) && is_array($fma_oow_whatsapp_contact_numbers['fma_oow_whatsapp_contacts'])) {
		foreach ($fma_oow_whatsapp_contact_numbers['fma_oow_whatsapp_contacts'] as $contact_index => &$contact_row) {
			if (!empty($contact_row['fma_oow_whatsapp_name'])) {
				$contact_row['fma_oow_whatsapp_name'] = WpmlHelper::translate((string) $contact_row['fma_oow_whatsapp_name'], 'saved_fma_oow_whatsapp_name_' . $contact_index);
			}
		}
		unset($contact_row);
	}
	$fma_oow_whatsapp_name = isset ($fma_oow_whatsapp_contact_numbers['fma_oow_whatsapp_contacts'][0]['fma_oow_whatsapp_name']) ? $fma_oow_whatsapp_contact_numbers['fma_oow_whatsapp_contacts'][0]['fma_oow_whatsapp_name'] : '';
	$fma_oow_whatsapp_number = isset ($fma_oow_whatsapp_contact_numbers['fma_oow_whatsapp_contacts'][0]['fma_oow_whatsapp_number']) ? $fma_oow_whatsapp_contact_numbers['fma_oow_whatsapp_contacts'][0]['fma_oow_whatsapp_number'] : '';
	$fma_oow_whatsapp_status = isset ($fma_oow_whatsapp_contact_numbers['fma_oow_whatsapp_contacts'][0]['fma_oow_whatsapp_status']) ? $fma_oow_whatsapp_contact_numbers['fma_oow_whatsapp_contacts'][0]['fma_oow_whatsapp_status'] : '';

	// BG color for WhatsApp button
	if (empty ($fma_order_on_whatsapp_cart_btn_bg_color)) {
		$fma_order_on_whatsapp_cart_btn_bg_color = '#25d366';
	}
	if (empty ($whatsapp_btn_border_clr_hash)) {
		$whatsapp_btn_border_clr_hash = '#25d366';
	}
	if (empty ($whatsapp_btn_border_clr_width)) {
		$whatsapp_btn_border_clr_width = 0;
	}
	if (empty ($share_btn_border_clr_hash)) {
		$share_btn_border_clr_hash = '#25d366';
	}
	if (empty ($share_btn_border_clr_width)) {
		$share_btn_border_clr_width = 0;
	}
	if (empty ($fma_order_on_whatsapp_cart_btn_text_color_hash)) {
		$fma_order_on_whatsapp_cart_btn_text_color_hash = '#ffff';
	}
	// BG color for share button
	if (empty ($fma_oow_share_btn_bg_color)) {
		$fma_oow_share_btn_bg_color = '#25d366';
	}
	// text color for share button
	if (empty ($fma_oow_share_btn_text_color)) {
		$fma_oow_share_btn_text_color = '#ffff';
	}
	$fma_order_on_whatsapp_shop_page_checkbox_select_orNot = '';
	$fma_order_on_whatsapp_show_on_cart_page_selectOrNot = '';
	$fma_order_on_whatsapp_show_on_checkout_page_selectOrNot = '';
	$fma_order_on_whatsapp_show_on_single_product_selectOrNot = '';
	$fma_order_on_whatsapp_show_on_single_product_selectOrNot = false;
	$fma_order_on_whatsapp_share_shop_page_checkbox_select_orNot = '';
	$fma_order_on_whatsapp_share_show_on_cart_page_selectOrNot = '';
	$fma_order_on_whatsapp_share_show_on_checkout_page_selectOrNot = '';
	$fma_order_on_whatsapp_share_show_on_single_product_selectOrNot = '';
	$fma_order_on_whatsapp_share_show_on_single_product_selectOrNot = false;
	$fma_order_on_whatsapp_hide_add_to_cart_btn_on_shop_page = '';
	$fma_order_on_whatsapp_hide_add_to_cart_btn_on_product_page = '';
	$fma_order_on_whatsapp_hide_whatsapp_btn_on_desktop = '';
	$fma_oow_whatsapp_functionality_checkout_pg_checkbox = '';
	$fma_oow_create_order_in_woocommerce = get_option('fma_oow_create_order_in_woocommerce');
	$fma_oow_create_order_in_woocommerce_checkbox = '';
	$fma_oow_enable_only_for_customer = get_option('fma_oow_enable_only_for_customers');
	$fma_oow_send_pay_now_link = get_option('fma_oow_send_pay_now_link');
	$fma_oow_enable_only_for_customer_checkbox = '';
	$fma_oow_send_pay_now_link_checkbox = '';
	if ('yes' === $fma_oow_enable_only_for_customer) {
		$fma_oow_enable_only_for_customer_checkbox = 'checked';
	}
	if ('yes' == $fma_oow_send_pay_now_link) {
		$fma_oow_send_pay_now_link_checkbox = 'checked';
	}
	if ('yes' === $fma_oow_create_order_in_woocommerce) {
		$fma_oow_create_order_in_woocommerce_checkbox = 'checked';
	}
	if ('yes' === $fma_order_on_whatsapp_show_on_shop_page) {
		$fma_order_on_whatsapp_shop_page_checkbox_select_orNot = 'checked';
	}
	if ('yes' === $fma_order_on_whatsapp_show_on_cart_page) {
		$fma_order_on_whatsapp_show_on_cart_page_selectOrNot = 'checked';
	}
	if ('yes' === $fma_order_on_whatsapp_show_on_checkout_page) {
		$fma_order_on_whatsapp_show_on_checkout_page_selectOrNot = 'checked';
		$fma_order_on_whatsapp_my_bool = true;
	}
	if ('yes' === $fma_order_on_whatsapp_show_on_single_product) {
		$fma_order_on_whatsapp_show_on_single_product_selectOrNot = 'checked';
	}
	/////////////////////////// SHARE BUTTON //////////////////////////
	if ('yes' === $fma_order_on_whatsapp_share_show_on_shop_page) {
		$fma_order_on_whatsapp_share_shop_page_checkbox_select_orNot = 'checked';
	}
	if ('yes' === $fma_order_on_whatsapp_share_show_on_cart_page) {
		$fma_order_on_whatsapp_share_show_on_cart_page_selectOrNot = 'checked';
	}
	if ('yes' === $fma_order_on_whatsapp_share_show_on_checkout_page) {
		$fma_order_on_whatsapp_share_show_on_checkout_page_selectOrNot = 'checked';
		$fma_order_on_whatsapp_share_my_bool = true;
	}
	if ('yes' === $fma_order_on_whatsapp_share_show_on_single_product) {
		$fma_order_on_whatsapp_share_show_on_single_product_selectOrNot = 'checked';
	}
	/////////////////////////// SHARE BUTTON //////////////////////////
	if ('yes' == $fma_order_on_whatsapp_hide_add_to_cart_button_shop_page) {
		$fma_order_on_whatsapp_hide_add_to_cart_btn_on_shop_page = 'checked';
	}
	if ('yes' == $fma_order_on_whatsapp_hide_add_to_cart_button_product_page) {
		$fma_order_on_whatsapp_hide_add_to_cart_btn_on_product_page = 'checked';
	}
	if ('yes' == $fma_order_on_whatsa_button_on_desktop) {
		$fma_order_on_whatsapp_hide_whatsapp_btn_on_desktop = 'checked';
	}
	$oow_order_status = get_option('oow_order_status');
	$fma_oow_all_payment_gateways = get_option('fma_oow_all_payment_gateways');
	$fma_oow_inline_whatsapp_share_buttons = get_option('fma_oow_inline_whatsapp_share_buttons', 'no');
	// hide the checkout option
	$fma_oow_hide_the_checkout_page_whatsapp_functionality = '';
	if ('yes' == $fma_order_on_whatsapp_hide_add_to_cart_button_shop_page && 'yes' == $fma_order_on_whatsapp_hide_add_to_cart_button_product_page) {
		$fma_oow_hide_the_checkout_page_whatsapp_functionality = 'none';
	}
	$fma_oow_icons_urls = array( FMA_OOW_PLUGIN_URL . 'admin/icons/icon1.png', FMA_OOW_PLUGIN_URL . 'admin/icons/icon2.png', FMA_OOW_PLUGIN_URL . 'admin/icons/icon3.png', FMA_OOW_PLUGIN_URL . 'admin/icons/icon4.png' );

	/////////////// ADDED BY SAQIB ///////////////////
	$fme_oow_notification_settings = get_option('fme_oow_notification_settings');
	$fme_oow_enable_notifications = isset ($fme_oow_notification_settings['fme_oow_enable_notifications']) && '' != $fme_oow_notification_settings['fme_oow_enable_notifications'] ? esc_html($fme_oow_notification_settings['fme_oow_enable_notifications']) : '0';
	$fme_oow_enable_notification_logs = isset ($fme_oow_notification_settings['fme_oow_enable_notification_logs']) && '' != $fme_oow_notification_settings['fme_oow_enable_notification_logs'] ? esc_html($fme_oow_notification_settings['fme_oow_enable_notification_logs']) : '0';
	$fme_oow_enable_user_whatsapp_approval = isset ($fme_oow_notification_settings['fme_oow_enable_user_whatsapp_approval']) && '' != $fme_oow_notification_settings['fme_oow_enable_user_whatsapp_approval'] ? esc_html($fme_oow_notification_settings['fme_oow_enable_user_whatsapp_approval']) : '0';
	$fme_oow_enable_user_whatsapp_approval_label = isset ($fme_oow_notification_settings['fme_oow_enable_user_whatsapp_approval_label']) && '' != $fme_oow_notification_settings['fme_oow_enable_user_whatsapp_approval_label'] ? esc_html($fme_oow_notification_settings['fme_oow_enable_user_whatsapp_approval_label']) : esc_html__('Receive Order Notifications via WhatsApp', 'order-on-whatsapp');
	$fme_oow_enable_user_whatsapp_approval_label = WpmlHelper::translate( (string) $fme_oow_enable_user_whatsapp_approval_label, 'saved_fme_oow_enable_user_whatsapp_approval_label' );

	// facebook api settings for whatsapp
	$fme_oow_fb_app_id = isset ($fme_oow_notification_settings['fme_oow_fb_app_id']) && '' != $fme_oow_notification_settings['fme_oow_fb_app_id'] ? esc_html($fme_oow_notification_settings['fme_oow_fb_app_id']) : '';
	$fme_oow_fb_access_token = isset ($fme_oow_notification_settings['fme_oow_fb_access_token']) && '' != $fme_oow_notification_settings['fme_oow_fb_access_token'] ? esc_html($fme_oow_notification_settings['fme_oow_fb_access_token']) : '';
	$fme_oow_fb_phone_number_id = isset ($fme_oow_notification_settings['fme_oow_fb_phone_number_id']) && '' != $fme_oow_notification_settings['fme_oow_fb_phone_number_id'] ? esc_html($fme_oow_notification_settings['fme_oow_fb_phone_number_id']) : '';
	$fme_oow_fb_whatsapp_business_account_id = isset ($fme_oow_notification_settings['fme_oow_fb_whatsapp_business_account_id']) && '' != $fme_oow_notification_settings['fme_oow_fb_whatsapp_business_account_id'] ? esc_html($fme_oow_notification_settings['fme_oow_fb_whatsapp_business_account_id']) : '';

	$notifications = FME_OOW_Notification::getInstance();

	// -------------Added BY Muhammad Manahal ------------
	// include setting HTML file
	include 'views/fma-order-on-whatsapp-setting-html.php'; 
}

/**
 * Function responsible for updating and validating the whatsapp settings
 *
 * @param $_POST $request
 * @return void
 */
function fma_oow_update_whatsapp_settings( $request ) {

	$fma_oow_whatsapp_contact_numbers = array();
	// get contact names, numbers and status
	$fma_oow_whatsapp_names = isset ($request['fma_oow_whatsapp_name']) ? $request['fma_oow_whatsapp_name'] : array( '' );
	$fma_oow_whatsapp_numbers = isset ($request['fma_oow_whatsapp_number']) ? $request['fma_oow_whatsapp_number'] : array( '' );
	$fma_oow_whatsapp_statuses = isset ($request['fma_oow_whatsapp_status']) ? $request['fma_oow_whatsapp_status'] : array( '' );

	// merge arrays together
	$fma_oow_whatsapp_rows = array();
	foreach ($fma_oow_whatsapp_names as $index => $name) {
		$fma_oow_whatsapp_rows[] = array(
			'fma_oow_whatsapp_name' => sanitize_text_field($name),
			'fma_oow_whatsapp_number' => sanitize_text_field($fma_oow_whatsapp_numbers[$index]),
			'fma_oow_whatsapp_status' => sanitize_text_field($fma_oow_whatsapp_statuses[$index]),
		);
	}
	$fma_oow_whatsapp_contact_numbers['fma_oow_whatsapp_contacts'] = $fma_oow_whatsapp_rows;
	update_option('fma_oow_whatsapp_contact_numbers', maybe_serialize($fma_oow_whatsapp_contact_numbers));
}

/**
 * Register admin-saved translatable strings with WPML on settings save.
 *
 * @param array $request Sanitized request data.
 * @return void
 */
function fma_oow_wpml_register_saved_strings_on_save( $request ) {
	$saved_strings = array(
		'fma_order_on_whatsapp_button_text' => isset($request['fma_order_on_whatsapp_whatsapp_button_text']) ? sanitize_text_field(wp_unslash($request['fma_order_on_whatsapp_whatsapp_button_text'])) : '',
		'fma_oow_share_btn_txt' => isset($request['fma_oow_share_btn_txt']) ? sanitize_text_field(wp_unslash($request['fma_oow_share_btn_txt'])) : '',
		'fma_oow_whatsapp_contact_input_label' => isset($request['fma_oow_whatsapp_contact_input_label']) ? sanitize_text_field(wp_unslash($request['fma_oow_whatsapp_contact_input_label'])) : '',
		'fma_oow_msg_when_whatsap_opens' => isset($request['fma_oow_msg_when_whatsap_opens']) ? sanitize_text_field(wp_unslash($request['fma_oow_msg_when_whatsap_opens'])) : '',
		'fma_oow_share_msg_when_whatsap_opens' => isset($request['fma_oow_share_msg_when_whatsap_opens']) ? sanitize_text_field(wp_unslash($request['fma_oow_share_msg_when_whatsap_opens'])) : '',
		'fme_oow_enable_user_whatsapp_approval_label' => isset($request['fme_oow_enable_user_whatsapp_approval_label']) ? sanitize_text_field(wp_unslash($request['fme_oow_enable_user_whatsapp_approval_label'])) : '',
	);

	foreach ($saved_strings as $option_key => $value) {
		if (is_string($value) && '' !== trim($value)) {
			WpmlHelper::register_string($value, 'saved_' . $option_key);
		}
	}

	if (isset($request['fma_oow_whatsapp_order_message_template'])) {
		$template = sanitize_textarea_field(wp_unslash($request['fma_oow_whatsapp_order_message_template']));
		if ('' !== trim($template)) {
			WpmlHelper::register_string($template, 'saved_fma_oow_whatsapp_order_message_template');
		}
	}

	if (isset($request['fma_oow_whatsapp_name']) && is_array($request['fma_oow_whatsapp_name'])) {
		foreach ($request['fma_oow_whatsapp_name'] as $index => $name) {
			$name = sanitize_text_field(wp_unslash($name));
			if ('' !== trim($name)) {
				WpmlHelper::register_string($name, 'saved_fma_oow_whatsapp_name_' . $index);
			}
		}
	}
}

/**
 * Added WooCommerce setting tab
 *
 * @param array $tabs
 * @return array
 */
function fma_order_on_whatsapp_filter_woocommerce_settings_tabs_array( $tabs ) {
	$tabs['my_sub_menu_whatsapp'] = WpmlHelper::translate(__('Order On WhatsApp', 'order-on-whatsapp'), 'settings_tab_order_on_whatsapp');
	return $tabs;
}

/**
 * Save WooCommerce settings
 *
 * @return void
 */
function fma_order_on_whatsapp_save_changes_clicked() {

	check_ajax_referer('admin_ajax_nonce', 'security');
	if (!current_user_can('manage_woocommerce')) {
		wp_die();
	}
	if (isset ($_REQUEST['fma_oow_all_payment_gateways'])) {

		$fma_oow_all_payment_gateways = sanitize_text_field($_REQUEST['fma_oow_all_payment_gateways']);
	}
	if (isset($_REQUEST['fma_oow_inline_whatsapp_share_buttons'])) {
		$fma_oow_inline_whatsapp_share_buttons = sanitize_text_field($_REQUEST['fma_oow_inline_whatsapp_share_buttons']);
	} else {
		$fma_oow_inline_whatsapp_share_buttons = 'no';
	}

	//////////////////////////////////////////////////////////////// SAVE WHATSAPP NUMBERS //////////////////////////////////////////////////////////////////

	// label for whatsapp contact input
	if (isset ($_REQUEST['fma_oow_whatsapp_contact_input_label']) && '' != $_REQUEST['fma_oow_whatsapp_contact_input_label']) {
		$fma_oow_whatsapp_contact_input_label = sanitize_text_field($_REQUEST['fma_oow_whatsapp_contact_input_label']);

		update_option('fma_oow_whatsapp_contact_input_label', $fma_oow_whatsapp_contact_input_label);
	}

	// check if whatsapp contacts are present
	if (isset ($_POST['fma_oow_whatsapp_name'])) {
		fma_oow_update_whatsapp_settings(map_deep($_POST, 'sanitize_text_field'));
	}

	////////////////////////// SAVE WHATSAPP NUMBERS /////////////////////////
	// this is an array, to sanitizze use array map
	if (isset ($_REQUEST['fma_order_on_whatsapp_products_list'])) {

		if (count($_REQUEST['fma_order_on_whatsapp_products_list']) == 1) {

			$fma_order_on_whatsapp_products_list = array_map('sanitize_text_field', wp_unslash($_REQUEST['fma_order_on_whatsapp_products_list']));
		} else {
			$fma_order_on_whatsapp_products_list = array_map('sanitize_text_field', wp_unslash($_REQUEST['fma_order_on_whatsapp_products_list']));
		}
	}
	// this is also an array, use array map
	if (isset ($_REQUEST['fma_order_on_whatsapp_categories_list'])) {

		if (count($_REQUEST['fma_order_on_whatsapp_categories_list']) == 1) {
			$fma_order_on_whatsapp_categories_list = sanitize_text_field($_REQUEST['fma_order_on_whatsapp_categories_list']);
			$fma_order_on_whatsapp_categories_list = array_map('sanitize_text_field', wp_unslash($_REQUEST['fma_order_on_whatsapp_categories_list']));
		} else {
			$fma_order_on_whatsapp_categories_list = array_map('sanitize_text_field', wp_unslash($_REQUEST['fma_order_on_whatsapp_categories_list']));
		}

	}
	// checkbox for, either products or categories
	if (isset ($_REQUEST['fma_order_on_whatsapp_either_products_or_cats'])) {
		$fma_order_on_whatsapp_either_products_or_cats = sanitize_text_field($_REQUEST['fma_order_on_whatsapp_either_products_or_cats']);
	}

	if (isset ($_REQUEST['fma_order_on_whatsapp_whatsapp_button_text'])) {
		$fma_order_on_whatsapp_whatsapp_button_text = sanitize_text_field($_REQUEST['fma_order_on_whatsapp_whatsapp_button_text']);
	}

	if (isset ($_REQUEST['fma_order_on_whatsapp_whatsapp_number'])) {
		$fma_order_on_whatsapp_number = sanitize_text_field($_REQUEST['fma_order_on_whatsapp_whatsapp_number']);
	}
	// show WhatsApp button variables

	if (isset ($_REQUEST['fma_order_on_whatsapp_show_whatsapp_btn_on_shop_page'])) {
		$fma_order_on_whatsapp_show_whatsapp_btn_on_shop_page = sanitize_text_field($_REQUEST['fma_order_on_whatsapp_show_whatsapp_btn_on_shop_page']);
	}
	if (isset ($_REQUEST['show_whatsapp_btn_on_checkout_page'])) {
		$fma_order_on_whatsapp_show_whatsapp_btn_on_checkout_page = sanitize_text_field($_REQUEST['show_whatsapp_btn_on_checkout_page']);
	}
	if (isset ($_REQUEST['fma_order_on_whatsapp_show_on_cart_page'])) {
		$fma_order_on_whatsapp_show_on_cart_page = sanitize_text_field($_REQUEST['fma_order_on_whatsapp_show_on_cart_page']);
	}
	if (isset ($_REQUEST['fma_order_on_whatsapp_show_whatsapp_btn_on_single_product_page'])) {
		$fma_order_on_whatsapp_show_whatsapp_btn_on_single_product_page = sanitize_text_field($_REQUEST['fma_order_on_whatsapp_show_whatsapp_btn_on_single_product_page']);
	}

	// share button
	if (isset ($_REQUEST['fma_order_on_whatsapp_share_show_btn_on_shop_page'])) {
		$fma_order_on_whatsapp_share_show_btn_on_shop_page = sanitize_text_field($_REQUEST['fma_order_on_whatsapp_share_show_btn_on_shop_page']);
	}
	if (isset ($_REQUEST['show_whatsapp_btn_on_checkout_page'])) {
		$fma_order_on_whatsapp_share_show_btn_on_checkout_page = sanitize_text_field($_REQUEST['show_whatsapp_btn_on_checkout_page']);
	}
	if (isset ($_REQUEST['fma_order_on_whatsapp_share_show_btn_on_cart_page'])) {
		$fma_order_on_whatsapp_share_show_btn_on_cart_page = sanitize_text_field($_REQUEST['fma_order_on_whatsapp_share_show_btn_on_cart_page']);
	}
	if (isset ($_REQUEST['fma_order_on_whatsapp_share_show_btn_on_single_product_page'])) {
		$fma_order_on_whatsapp_share_show_btn_on_single_product_page = sanitize_text_field($_REQUEST['fma_order_on_whatsapp_share_show_btn_on_single_product_page']);
	}

	if (isset ($_REQUEST['fma_order_on_whatsapp_hide_add_to_cart_button_shop_page'])) {
		$fma_order_on_whatsapp_hide_add_to_cart_button_shop_page = sanitize_text_field($_REQUEST['fma_order_on_whatsapp_hide_add_to_cart_button_shop_page']);
	}

	if (isset ($_REQUEST['fma_order_on_whatsapp_hide_add_to_cart_button_product_page'])) {
		$fma_order_on_whatsapp_hide_add_to_cart_button_product_page = sanitize_text_field($_REQUEST['fma_order_on_whatsapp_hide_add_to_cart_button_product_page']);
	}

	// apply on all products

	if (isset ($_REQUEST['fma_oow_apply_on_all_products'])) {
		$fma_oow_apply_on_all_products = sanitize_text_field($_REQUEST['fma_oow_apply_on_all_products']);
	}

	// WhatsApp functionality checkout page

	if (isset ($_REQUEST['fma_order_on_whatsapp_show_whatsapp_functionality_on_checkout_pg'])) {
		$fma_order_on_whatsapp_show_whatsapp_functionality_on_checkout_pg = sanitize_text_field($_REQUEST['fma_order_on_whatsapp_show_whatsapp_functionality_on_checkout_pg']);
	}
	// hide desktop button for desktop users

	if (isset ($_REQUEST['fma_order_on_whatsa_button_on_desktop'])) {
		$fma_order_on_whatsa_button_on_desktop = sanitize_text_field($_REQUEST['fma_order_on_whatsa_button_on_desktop']);
	}

	// WhatsApp button background-color
	if (isset ($_REQUEST['fma_order_on_whatsapp_cart_btn_bg_color_hash'])) {
		$fma_order_on_whatsapp_cart_btn_bg_color_hash = sanitize_text_field($_REQUEST['fma_order_on_whatsapp_cart_btn_bg_color_hash']);
	}

	if (isset ($_REQUEST['whatsapp_btn_border_clr_hash'])) {
		$whatsapp_btn_border_clr_hash = sanitize_text_field($_REQUEST['whatsapp_btn_border_clr_hash']);
	}

	if (isset ($_REQUEST['whatsapp_btn_border_clr_width'])) {
		$whatsapp_btn_border_clr_width = sanitize_text_field($_REQUEST['whatsapp_btn_border_clr_width']);
	}

	if (isset ($_REQUEST['fma_oow_icons'])) {
		$fma_oow_icons = sanitize_text_field($_REQUEST['fma_oow_icons']);
	}

	if (isset ($_REQUEST['fma_oow_def_icon_chk'])) {
		$fma_oow_def_icon_chk = sanitize_text_field($_REQUEST['fma_oow_def_icon_chk']);
	}

	if (isset ($_REQUEST['fma_oow_show_icon_only'])) {
		$fma_oow_show_icon_only = sanitize_text_field($_REQUEST['fma_oow_show_icon_only']);
	}

	if (isset ($_REQUEST['fma_icon_clr'])) {
		$fma_icon_clr = sanitize_text_field($_REQUEST['fma_icon_clr']);
	}

	if (isset ($_REQUEST['fma_icon_size'])) {
		$fma_icon_size = sanitize_text_field($_REQUEST['fma_icon_size']);
	}

	if (isset ($_REQUEST['share_btn_border_clr_hash'])) {
		$share_btn_border_clr_hash = sanitize_text_field($_REQUEST['share_btn_border_clr_hash']);
	}

	if (isset ($_REQUEST['share_btn_border_clr_width'])) {
		$share_btn_border_clr_width = sanitize_text_field($_REQUEST['share_btn_border_clr_width']);
	}

	if (isset ($_REQUEST['fma_oow_shop_whatsapp_btn_width'])) {
		$fma_oow_shop_whatsapp_btn_width = sanitize_text_field($_REQUEST['fma_oow_shop_whatsapp_btn_width']);
	}

	if (isset ($_REQUEST['fma_oow_prd_whatsapp_btn_width'])) {
		$fma_oow_prd_whatsapp_btn_width = sanitize_text_field($_REQUEST['fma_oow_prd_whatsapp_btn_width']);
	}

	if (isset ($_REQUEST['fma_oow_cart_whatsapp_btn_width'])) {
		$fma_oow_cart_whatsapp_btn_width = sanitize_text_field($_REQUEST['fma_oow_cart_whatsapp_btn_width']);
	}

	if (isset ($_REQUEST['fma_oow_shop_share_btn_width'])) {
		$fma_oow_shop_share_btn_width = sanitize_text_field($_REQUEST['fma_oow_shop_share_btn_width']);
	}

	if (isset ($_REQUEST['fma_oow_prd_share_btn_width'])) {
		$fma_oow_prd_share_btn_width = sanitize_text_field($_REQUEST['fma_oow_prd_share_btn_width']);
	}

	if (isset ($_REQUEST['fma_oow_cart_share_btn_width'])) {
		$fma_oow_cart_share_btn_width = sanitize_text_field($_REQUEST['fma_oow_cart_share_btn_width']);
	}

	// WhatsApp button text color
	if (isset ($_REQUEST['fma_order_on_whatsapp_cart_btn_text_color_hash'])) {
		$fma_order_on_whatsapp_cart_btn_text_color_hash = sanitize_text_field($_REQUEST['fma_order_on_whatsapp_cart_btn_text_color_hash']);
	}

	// where to open WhatsApp chat
	if (isset ($_REQUEST['fma_oow_where_to_open_whatsapp'])) {
		$fma_oow_where_to_open_whatsapp = sanitize_text_field($_REQUEST['fma_oow_where_to_open_whatsapp']);
	}

	// where to add the button
	if (isset ($_REQUEST['fma_oow_where_to_place_whatsp_btn'])) {
		$fma_oow_where_to_place_whatsp_btn = sanitize_text_field($_REQUEST['fma_oow_where_to_place_whatsp_btn']);
	}
	// show share button
	if (isset ($_REQUEST['fma_oow_share_btn'])) {
		$fma_oow_share_btn = sanitize_text_field($_REQUEST['fma_oow_share_btn']);
	}
	// share button text
	if (isset ($_REQUEST['fma_oow_share_btn_txt'])) {
		$fma_oow_share_btn_txt = sanitize_text_field($_REQUEST['fma_oow_share_btn_txt']);
	}

	// whatsapp button padding
	$fma_oow_whatsapp_button_padding_top = isset ($_REQUEST['fma_oow_whatsapp_button_padding_top']) ? sanitize_text_field($_REQUEST['fma_oow_whatsapp_button_padding_top']) : '';
	$fma_oow_whatsapp_button_padding_bottom = isset ($_REQUEST['fma_oow_whatsapp_button_padding_bottom']) ? sanitize_text_field($_REQUEST['fma_oow_whatsapp_button_padding_bottom']) : '';
	$fma_oow_whatsapp_button_padding_left = isset ($_REQUEST['fma_oow_whatsapp_button_padding_left']) ? sanitize_text_field($_REQUEST['fma_oow_whatsapp_button_padding_left']) : '';
	$fma_oow_whatsapp_button_padding_right = isset ($_REQUEST['fma_oow_whatsapp_button_padding_right']) ? sanitize_text_field($_REQUEST['fma_oow_whatsapp_button_padding_right']) : '';

	// whatsapp button border radius
	$fma_oow_whatsapp_button_border_radius_top = isset ($_REQUEST['fma_oow_whatsapp_button_border_radius_top']) ? sanitize_text_field($_REQUEST['fma_oow_whatsapp_button_border_radius_top']) : '';
	$fma_oow_whatsapp_button_border_radius_bottom = isset ($_REQUEST['fma_oow_whatsapp_button_border_radius_bottom']) ? sanitize_text_field($_REQUEST['fma_oow_whatsapp_button_border_radius_bottom']) : '';
	$fma_oow_whatsapp_button_border_radius_left = isset ($_REQUEST['fma_oow_whatsapp_button_border_radius_left']) ? sanitize_text_field($_REQUEST['fma_oow_whatsapp_button_border_radius_left']) : '';
	$fma_oow_whatsapp_button_border_radius_right = isset ($_REQUEST['fma_oow_whatsapp_button_border_radius_right']) ? sanitize_text_field($_REQUEST['fma_oow_whatsapp_button_border_radius_right']) : '';

	// padding
	$fma_oow_whatsapp_button_padding = array(
		'top' => $fma_oow_whatsapp_button_padding_top,
		'bottom' => $fma_oow_whatsapp_button_padding_bottom,
		'left' => $fma_oow_whatsapp_button_padding_left,
		'right' => $fma_oow_whatsapp_button_padding_right,
	);
	// radius
	$fma_oow_whatsapp_button_border_radius = array(
		'top' => $fma_oow_whatsapp_button_border_radius_top,
		'bottom' => $fma_oow_whatsapp_button_border_radius_bottom,
		'left' => $fma_oow_whatsapp_button_border_radius_left,
		'right' => $fma_oow_whatsapp_button_border_radius_right,
	);

	update_option('fma_oow_whatsapp_button_padding', maybe_serialize($fma_oow_whatsapp_button_padding));
	update_option('fma_oow_whatsapp_button_border_radius', maybe_serialize($fma_oow_whatsapp_button_border_radius));

	// share button padding
	$fma_oow_share_button_padding_top = isset ($_REQUEST['fma_oow_share_button_padding_top']) ? sanitize_text_field($_REQUEST['fma_oow_share_button_padding_top']) : '';
	$fma_oow_share_button_padding_bottom = isset ($_REQUEST['fma_oow_share_button_padding_bottom']) ? sanitize_text_field($_REQUEST['fma_oow_share_button_padding_bottom']) : '';
	$fma_oow_share_button_padding_left = isset ($_REQUEST['fma_oow_share_button_padding_left']) ? sanitize_text_field($_REQUEST['fma_oow_share_button_padding_left']) : '';
	$fma_oow_share_button_padding_right = isset ($_REQUEST['fma_oow_share_button_padding_right']) ? sanitize_text_field($_REQUEST['fma_oow_share_button_padding_right']) : '';

	// share button border radius
	$fma_oow_share_button_border_radius_top = isset ($_REQUEST['fma_oow_share_button_border_radius_top']) ? sanitize_text_field($_REQUEST['fma_oow_share_button_border_radius_top']) : '';
	$fma_oow_share_button_border_radius_bottom = isset ($_REQUEST['fma_oow_share_button_border_radius_bottom']) ? sanitize_text_field($_REQUEST['fma_oow_share_button_border_radius_bottom']) : '';
	$fma_oow_share_button_border_radius_left = isset ($_REQUEST['fma_oow_share_button_border_radius_left']) ? sanitize_text_field($_REQUEST['fma_oow_share_button_border_radius_left']) : '';
	$fma_oow_share_button_border_radius_right = isset ($_REQUEST['fma_oow_share_button_border_radius_right']) ? sanitize_text_field($_REQUEST['fma_oow_share_button_border_radius_right']) : '';

	// padding
	$fma_oow_share_button_padding = array(
		'top' => $fma_oow_share_button_padding_top,
		'bottom' => $fma_oow_share_button_padding_bottom,
		'left' => $fma_oow_share_button_padding_left,
		'right' => $fma_oow_share_button_padding_right,
	);
	// radius
	$fma_oow_share_button_border_radius = array(
		'top' => $fma_oow_share_button_border_radius_top,
		'bottom' => $fma_oow_share_button_border_radius_bottom,
		'left' => $fma_oow_share_button_border_radius_left,
		'right' => $fma_oow_share_button_border_radius_right,
	);

	update_option('fma_oow_share_button_padding', maybe_serialize($fma_oow_share_button_padding));
	update_option('fma_oow_share_button_border_radius', maybe_serialize($fma_oow_share_button_border_radius));

	// share button bg color
	if (isset ($_REQUEST['fma_oow_share_btn_bg_color'])) {
		$fma_oow_share_btn_bg_color = sanitize_text_field($_REQUEST['fma_oow_share_btn_bg_color']);
	}
	// share button text color
	if (isset ($_REQUEST['fma_oow_share_btn_text_color'])) {
		$fma_oow_share_btn_text_color = sanitize_text_field($_REQUEST['fma_oow_share_btn_text_color']);
	}
	// customized text
	if (isset ($_REQUEST['fma_oow_msg_when_whatsap_opens'])) {
		$fma_oow_msg_when_whatsap_opens = sanitize_text_field($_REQUEST['fma_oow_msg_when_whatsap_opens']);
	}

	if (isset ($_REQUEST['fma_oow_share_msg_when_whatsap_opens'])) {
		$fma_oow_share_msg_when_whatsap_opens = sanitize_text_field($_REQUEST['fma_oow_share_msg_when_whatsap_opens']);
	}

	if (isset ($_REQUEST['fma_oow_create_order'])) {
		$fma_oow_create_order_in_woocommerce = sanitize_text_field($_REQUEST['fma_oow_create_order']);
	}

	if (isset ($_REQUEST['oow_order_status'])) {
		$oow_order_status = sanitize_text_field($_REQUEST['oow_order_status']);
	}

	if (isset ($_REQUEST['fma_oow_show_for_customer_only'])) {
		$fma_oow_show_for_customer_only = sanitize_text_field($_REQUEST['fma_oow_show_for_customer_only']);
	}

	if (isset ($_REQUEST['fma_oow_send_pay_now_link'])) {
		$fma_oow_send_pay_now_link = sanitize_text_field($_REQUEST['fma_oow_send_pay_now_link']);
	}

	if (isset ($_REQUEST['fma_oow_enable_multiple_branches'])) {
		$fma_oow_enable_multiple_branches = sanitize_text_field($_REQUEST['fma_oow_enable_multiple_branches']);
	}

	update_option('fma_oow_create_order_in_woocommerce', $fma_oow_create_order_in_woocommerce);
	update_option('oow_order_status', $oow_order_status);
	update_option('fma_oow_enable_only_for_customers', $fma_oow_show_for_customer_only);
	update_option('fma_oow_send_pay_now_link', $fma_oow_send_pay_now_link);
	update_option('fma_order_on_whatsapp_products_list', $fma_order_on_whatsapp_products_list);
	update_option('fma_order_on_whatsapp_categories_list', $fma_order_on_whatsapp_categories_list);
	update_option('fma_order_on_whatsapp_either_products_or_cats', $fma_order_on_whatsapp_either_products_or_cats);
	update_option('fma_order_on_whatsapp_button_text', $fma_order_on_whatsapp_whatsapp_button_text);
	update_option('fma_order_on_whatsapp_whatsapp_number', $fma_order_on_whatsapp_number);

	update_option('fma_order_on_whatsapp_show_on_shop_page', $fma_order_on_whatsapp_show_whatsapp_btn_on_shop_page);
	update_option('fma_order_on_whatsapp_show_on_checkout_page', $fma_order_on_whatsapp_show_whatsapp_btn_on_checkout_page);
	update_option('fma_order_on_whatsapp_show_on_cart_page', $fma_order_on_whatsapp_show_on_cart_page);
	update_option('fma_order_on_whatsapp_show_on_single_product', $fma_order_on_whatsapp_show_whatsapp_btn_on_single_product_page);

	update_option('fma_order_on_whatsapp_share_show_btn_on_shop_page', $fma_order_on_whatsapp_share_show_btn_on_shop_page);
	update_option('fma_order_on_whatsapp_share_show_btn_on_checkout_page', $fma_order_on_whatsapp_share_show_btn_on_checkout_page);
	update_option('fma_order_on_whatsapp_share_show_btn_on_cart_page', $fma_order_on_whatsapp_share_show_btn_on_cart_page);
	update_option('fma_order_on_whatsapp_share_show_btn_on_single_product', $fma_order_on_whatsapp_share_show_btn_on_single_product_page);

	update_option('fma_order_on_whatsapp_hide_add_to_cart_button_shop_page', $fma_order_on_whatsapp_hide_add_to_cart_button_shop_page);
	update_option('fma_order_on_whatsapp_hide_add_to_cart_button_product_page', $fma_order_on_whatsapp_hide_add_to_cart_button_product_page);

	update_option('fma_order_on_whatsa_button_on_desktop', $fma_order_on_whatsa_button_on_desktop);
	update_option('whatsapp_btn_border_clr_hash', $whatsapp_btn_border_clr_hash);
	update_option('whatsapp_btn_border_clr_width', $whatsapp_btn_border_clr_width);
	update_option('fma_oow_shop_whatsapp_btn_width', $fma_oow_shop_whatsapp_btn_width);
	update_option('fma_oow_prd_whatsapp_btn_width', $fma_oow_prd_whatsapp_btn_width);
	update_option('fma_oow_cart_whatsapp_btn_width', $fma_oow_cart_whatsapp_btn_width);

	update_option('fma_oow_def_icon_chk', $fma_oow_def_icon_chk);
	update_option('fma_oow_show_icon_only', $fma_oow_show_icon_only);

	update_option('fma_oow_icons', $fma_oow_icons);
	update_option('fma_icon_clr', $fma_icon_clr);
	update_option('fma_icon_size', $fma_icon_size);

	update_option('share_btn_border_clr_hash', $share_btn_border_clr_hash);
	update_option('share_btn_border_clr_width', $share_btn_border_clr_width);
	update_option('fma_oow_shop_share_btn_width', isset($fma_oow_shop_share_btn_width) ? $fma_oow_shop_share_btn_width : '');
	update_option('fma_oow_prd_share_btn_width', isset($fma_oow_prd_share_btn_width) ? $fma_oow_prd_share_btn_width : '');
	update_option('fma_oow_cart_share_btn_width', isset($fma_oow_cart_share_btn_width) ? $fma_oow_cart_share_btn_width : '');

	update_option('fma_order_on_whatsapp_cart_btn_bg_color_hash', $fma_order_on_whatsapp_cart_btn_bg_color_hash);

	update_option('fma_order_on_whatsapp_cart_btn_text_color_hash', $fma_order_on_whatsapp_cart_btn_text_color_hash);
	update_option('fma_oow_apply_on_all_products', $fma_oow_apply_on_all_products);
	update_option('fma_oow_open_whatsapp_in_which_tab', $fma_oow_where_to_open_whatsapp);
	update_option('fma_oow_where_to_place_whatsp_btn', $fma_oow_where_to_place_whatsp_btn);
	update_option('fma_oow_share_btn', $fma_oow_share_btn);
	update_option('fma_oow_share_btn_txt', $fma_oow_share_btn_txt);
	update_option('fma_oow_share_btn_bg_color', $fma_oow_share_btn_bg_color);
	update_option('fma_oow_share_btn_text_color', $fma_oow_share_btn_text_color);
	update_option('fma_oow_msg_when_whatsap_opens', $fma_oow_msg_when_whatsap_opens);

	update_option('fma_oow_share_msg_when_whatsap_opens', $fma_oow_share_msg_when_whatsap_opens);
	update_option('fma_oow_all_payment_gateways', $fma_oow_all_payment_gateways);
	update_option('fma_oow_inline_whatsapp_share_buttons', $fma_oow_inline_whatsapp_share_buttons);


	/////////////////////////////////// ADDED BY SAQIB //////////////////////////////////
	// save twilio settings
	$fme_oow_enable_notifications = isset ($_REQUEST['fme_oow_enable_notifications']) && '' != $_REQUEST['fme_oow_enable_notifications'] ? sanitize_text_field($_REQUEST['fme_oow_enable_notifications']) : '0';
	$fme_oow_enable_notification_logs = isset ($_REQUEST['fme_oow_enable_notification_logs']) && '' != $_REQUEST['fme_oow_enable_notification_logs'] ? sanitize_text_field($_REQUEST['fme_oow_enable_notification_logs']) : '0';
	$fme_oow_enable_user_whatsapp_approval = isset ($_REQUEST['fme_oow_enable_user_whatsapp_approval']) && '' != $_REQUEST['fme_oow_enable_user_whatsapp_approval'] ? sanitize_text_field($_REQUEST['fme_oow_enable_user_whatsapp_approval']) : '0';
	$fme_oow_enable_user_whatsapp_approval_label = isset ($_REQUEST['fme_oow_enable_user_whatsapp_approval_label']) && '' != $_REQUEST['fme_oow_enable_user_whatsapp_approval_label'] ? sanitize_text_field($_REQUEST['fme_oow_enable_user_whatsapp_approval_label']) : esc_html__('Receive Order Notifications via WhatsApp');

	$fme_oow_fb_app_id = isset ($_REQUEST['fme_oow_fb_app_id']) && '' != $_REQUEST['fme_oow_fb_app_id'] ? sanitize_text_field($_REQUEST['fme_oow_fb_app_id']) : '';
	$fme_oow_fb_access_token = isset ($_REQUEST['fme_oow_fb_access_token']) && '' != $_REQUEST['fme_oow_fb_access_token'] ? sanitize_text_field($_REQUEST['fme_oow_fb_access_token']) : '';
	$fme_oow_fb_phone_number_id = isset ($_REQUEST['fme_oow_fb_phone_number_id']) && '' != $_REQUEST['fme_oow_fb_phone_number_id'] ? sanitize_text_field($_REQUEST['fme_oow_fb_phone_number_id']) : '';
	$fme_oow_fb_whatsapp_business_account_id = isset ($_REQUEST['fme_oow_fb_whatsapp_business_account_id']) && '' != $_REQUEST['fme_oow_fb_whatsapp_business_account_id'] ? sanitize_text_field($_REQUEST['fme_oow_fb_whatsapp_business_account_id']) : '';


	$fme_oow_notification_settings = array(
		'fme_oow_enable_notifications' => $fme_oow_enable_notifications,
		'fme_oow_enable_notification_logs' => $fme_oow_enable_notification_logs,
		'fme_oow_enable_user_whatsapp_approval' => $fme_oow_enable_user_whatsapp_approval,
		'fme_oow_enable_user_whatsapp_approval_label' => $fme_oow_enable_user_whatsapp_approval_label,
		'fme_oow_fb_app_id' => $fme_oow_fb_app_id,
		'fme_oow_fb_access_token' => $fme_oow_fb_access_token,
		'fme_oow_fb_phone_number_id' => $fme_oow_fb_phone_number_id,
		'fme_oow_fb_whatsapp_business_account_id' => $fme_oow_fb_whatsapp_business_account_id,
	);
	update_option('fma_oow_enable_multiple_whatsapp_num', $fma_oow_enable_multiple_branches);

	update_option('fme_oow_notification_settings', $fme_oow_notification_settings);
	/////////////////////////////////// ADDED BY SAQIB //////////////////////////////////

	if (isset($_REQUEST['fma_oow_whatsapp_order_message_template'])) {
		update_option(
			'fma_oow_whatsapp_order_message_template',
			sanitize_textarea_field(wp_unslash($_REQUEST['fma_oow_whatsapp_order_message_template']))
		);
	}

	fma_oow_wpml_register_saved_strings_on_save(wp_unslash($_REQUEST));

	wp_die();
}

/**
 * Get ajax based products
 *
 * @return array
 */
function fmeGetAjaxProductsArray() {
	check_ajax_referer('admin_ajax_nonce', 'security');
	if (!current_user_can('manage_woocommerce')) {
		wp_send_json_error(array( 'message' => 'Unauthorized' ), 403);
	}

	global $wpdb;
	$json = array();

	$serch_term = isset ($_REQUEST['term']) ? sanitize_text_field(wp_unslash($_REQUEST['term'])) : '';
	if (!$serch_term) {
		echo wp_json_encode($json);
		wp_die();
	} else {
		$search_like = '%' . $wpdb->esc_like($serch_term) . '%';
		$result      = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT product.ID, product.post_title, product.post_type
				FROM ' . $wpdb->posts . ' AS product
				LEFT JOIN ' . $wpdb->posts . " AS parent_product ON product.post_parent = parent_product.ID
				WHERE (
					(product.post_title LIKE %s AND product.post_type = 'product' AND product.post_status = 'publish')
					OR (
						(product.post_title LIKE %s OR parent_product.post_title LIKE %s)
						AND product.post_type = 'product_variation'
						AND product.post_status IN ('publish', 'private')
						AND parent_product.post_type = 'product'
						AND parent_product.post_status = 'publish'
					)
				)
				ORDER BY CASE WHEN product.post_type = 'product' THEN product.post_title ELSE parent_product.post_title END ASC
				LIMIT 250",
				$search_like,
				$search_like,
				$search_like
			)
		);
		foreach ($result as $row) {
			$product = function_exists('wc_get_product') ? wc_get_product($row->ID) : false;
			$text    = $product ? $product->get_name() : $row->post_title;

			if ($product && $product->is_type('variation') && function_exists('wc_get_formatted_variation')) {
				$variation_name = wc_get_formatted_variation($product, true, false, true);
				if ('' !== $variation_name) {
					$text = $product->get_title() . ' - ' . $variation_name;
				}
			}

			$json[] = array( 'id' => $row->ID, 'text' => $text );
		}
	}
	echo wp_json_encode($json);
	wp_die();
}

/**
 * Get ajax based product categories (search by name; stored values are category names).
 *
 * @return void
 */
function fmeGetAjaxCategoriesArray() {
	check_ajax_referer('admin_ajax_nonce', 'security');
	if (!current_user_can('manage_woocommerce')) {
		wp_send_json_error(array( 'message' => 'Unauthorized' ), 403);
	}

	$json = array();

	$search_term = isset($_REQUEST['term']) ? sanitize_text_field(wp_unslash($_REQUEST['term'])) : '';
	if ('' === $search_term) {
		echo wp_json_encode($json);
		wp_die();
	}

	$terms = get_terms(
		array(
			'taxonomy'   => 'product_cat',
			'hide_empty' => false,
			'search'     => $search_term,
			'number'     => 250,
		)
	);

	if (!is_wp_error($terms) && !empty($terms)) {
		foreach ($terms as $term) {
			$json[] = array(
				'id'   => $term->name,
				'text' => $term->name,
			);
		}
	}

	echo wp_json_encode($json);
	wp_die();
}

//////////////// WHATSAPP CONTACT NUMBERS ////////////////////////

add_action('woocommerce_admin_order_data_after_billing_address', 'fma_oow_show_whatsapp_branch_contact_number', 999, 1);

/**
 * Added branch number in admin order details
 *
 * @param object $order
 * @return string
 */
function fma_oow_show_whatsapp_branch_contact_number( $order ) {
	$branch_number = $order->get_meta('fma_oow_whatsapp_contact_number');

	if (!empty ($branch_number)) {
		echo '<p><strong>' . esc_html__('Branch Whatsapp Number', 'order-on-whatsapp') . ':</strong><br/> ' . esc_html($branch_number) . '</p>';
	}
}

///////////////// WHATSAPP CONTACT NUMBERS /////////////////////
