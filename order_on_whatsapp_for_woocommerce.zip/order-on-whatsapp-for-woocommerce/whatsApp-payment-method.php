<?php
// var_dump('simple whatsapp payment');

if (!class_exists('WC_Payment_Gateway')) {
	return;
}

class WC_Gateway_WhatsApp_Payment extends WC_Payment_Gateway {


	// Define class properties
	public $id;
	public $icon;
	public $has_fields;
	public $method_title;
	public $method_description;
	public $instructions;
	public $title;
	public $description;

	public function __construct() {
		$this->id = 'whatsapp_payment';
		$this->icon = FMA_OOW_PLUGIN_URL . '/assets/icons/wp_icon.png';
		$this->has_fields = false;
		$this->method_title = __('WhatsApp Order', 'order-on-whatsapp');
		$this->method_description = __('Place Order via WhatsApp.', 'order-on-whatsapp');
		// Load the settings
		$this->init_form_fields();
		$this->init_settings();
		// Define user settings
		$this->title = $this->get_option('title');
		$this->description = $this->get_option('description');
		$this->instructions = $this->get_option('instructions');
		// Actions
		add_action('woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ));
		add_action('woocommerce_thankyou_' . $this->id, array( $this, 'thankyou_page' ));
	}

	public function init_form_fields() {
		$this->form_fields = array(
			'enabled' => array(
				'title' => __('Enable/Disable', 'order-on-whatsapp'),
				'type' => 'checkbox',
				'label' => __('Enable WhatsApp Order', 'order-on-whatsapp'),
				'default' => 'yes',
			),
			'title' => array(
				'title' => __('Title', 'order-on-whatsapp'),
				'type' => 'text',
				'description' => __('This controls the title which the user sees during checkout.', 'order-on-whatsapp'),
				'default' => __('WhatsApp Order', 'order-on-whatsapp'),
				'desc_tip' => true,
			),
			'description' => array(
				'title' => __('Description', 'order-on-whatsapp'),
				'type' => 'textarea',
				'description' => __('Payment method description that the customer will see on your checkout.', 'order-on-whatsapp'),
				'default' => __('Place Order via WhatsApp.', 'order-on-whatsapp'),
			),
			'instructions' => array(
				'title' => __('Instructions', 'order-on-whatsapp'),
				'type' => 'textarea',
				'description' => __('Instructions that will be added to the thank you page.', 'order-on-whatsapp'),
				'default' => __('Pay via WhatsApp Payment.', 'order-on-whatsapp'),
			),
		);
	}

	public function admin_options() {
		$whatsapp_number = get_option( 'fma_order_on_whatsapp_whatsapp_number' );
		if ( empty( $whatsapp_number ) ) {
			$settings_url = admin_url( 'admin.php?page=wc-settings&tab=my_sub_menu_whatsapp' );
			echo wp_kses_post(
				'<div class="notice notice-warning inline"><p>'
				. sprintf(
					/* translators: %s: link to WhatsApp settings page */
					__( '<strong>WhatsApp number is not configured.</strong> This payment gateway will not appear on the frontend until a WhatsApp number is set. <a href="%s">Configure it here &rarr;</a>', 'order-on-whatsapp' ),
					esc_url( $settings_url )
				)
				. '</p></div>'
			);
		}
		parent::admin_options();
	}

	public function is_available() {
		if ( empty( get_option( 'fma_order_on_whatsapp_whatsapp_number' ) ) ) {
			return false;
		}
		return parent::is_available();
	}

	public function process_payment( $order_id ) {
		$order = wc_get_order($order_id);
		if (!$order) {
			return array(
				'result'   => 'failure',
				'redirect' => '',
			);
		}

		$oow_order_status = get_option('oow_order_status');
		if (empty($oow_order_status) || !array_key_exists($oow_order_status, wc_get_order_statuses())) {
			$oow_order_status = 'wc-processing';
		}

		$order->update_status($oow_order_status, '', true);
		$order->update_meta_data('fme_oow_order', 'worder');
		$order->save();
		// Empty cart
		WC()->cart->empty_cart();

		// Return thankyou redirect
		return array(
			'result' => 'success',
			'redirect' => $this->get_return_url($order),
		);
	}
	public function thankyou_page() {
		if ($this->instructions) {
			echo filter_var(wpautop($this->instructions));
		}
	}
}
