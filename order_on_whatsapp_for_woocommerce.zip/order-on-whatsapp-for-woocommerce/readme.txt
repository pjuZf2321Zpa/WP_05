=== Order On WhatsApp for WooCommerce ===
Contributors: fmeaddons
Tags: woocommerce, whatsapp, order on whatsapp, whatsapp checkout, whatsapp notifications
Requires at least: 5.0
Tested up to: 7.0
Requires PHP: 7.4
Stable tag: 1.3.8
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Requires Plugins: woocommerce
WC requires at least: 4.0.0
WC tested up to: 10.9.4

Let customers order products directly through WhatsApp. Add Buy on WhatsApp buttons, share products, and send order notifications via WhatsApp Cloud API.

== Description ==

**Order On WhatsApp for WooCommerce** lets shoppers place orders and contact your store through WhatsApp. Show a Buy on WhatsApp button on shop, product, cart, and checkout pages, share products, and optionally create WooCommerce orders from WhatsApp checkouts.

= Ordering via WhatsApp =

* Buy on WhatsApp button on shop, single product, cart, and checkout pages
* Optional Share button to share products on WhatsApp
* Custom button text, colors, borders, icons, and placement
* Open WhatsApp in the same tab or a new tab
* Pre-filled message templates with product and order details
* Create a WooCommerce order when a customer orders via WhatsApp
* WhatsApp Order payment method (classic checkout and Checkout block)
* Checkout popup or checkbox for Order on WhatsApp vs Order on Web

= Display & Targeting =

* Show or hide buttons per page (shop, product, cart, checkout)
* Apply to all products, selected products, or selected categories
* Restrict WhatsApp buttons to logged-in customers only
* Multiple WhatsApp numbers / branches with checkout selection
* Inline WhatsApp and Share buttons option
* Configurable post-checkout WhatsApp message template

= Notifications (WhatsApp Cloud API) =

* Send order confirmation and order status messages via Meta WhatsApp Cloud API
* Customer opt-in at checkout for WhatsApp notifications
* Optional notification logs in the admin

= Compatibility =

* **HPOS compatible** — Declares compatibility with WooCommerce High-Performance Order Storage
* **Cart & Checkout blocks** — WhatsApp buttons and WhatsApp Order payment method
* **WPML ready** — String translation support for labels and messages
* Theme-friendly CSS for popular themes and page builders
* Translation-ready (`order-on-whatsapp` text domain) with multiple languages included

== Installation ==

1. Upload the plugin folder to `/wp-content/plugins/` or install via the WordPress Plugins screen.
2. Activate the plugin through the **Plugins** menu in WordPress.
3. Ensure **WooCommerce** is installed and active (required).
4. Go to **WooCommerce → Settings → Order On WhatsApp** to configure buttons, display, messages, and notifications.
5. Optionally enable **WhatsApp Order** under **WooCommerce → Settings → Payments**.

== Frequently Asked Questions ==

= Does this plugin require WooCommerce? =

Yes. WooCommerce must be installed and active.

= Where do I configure WhatsApp settings? =

Go to **WooCommerce → Settings → Order On WhatsApp**. Use the Display & Design and Message template tabs for layout and post-checkout messages.

= Can customers order without leaving WhatsApp? =

Customers click Buy on WhatsApp (or choose WhatsApp Order at checkout). WhatsApp opens with a pre-filled message so they can confirm the order with your store number.

= Can I create WooCommerce orders from WhatsApp checkouts? =

Yes. Enable the option to create a WooCommerce order when a customer places an order via WhatsApp.

= Can I use multiple WhatsApp numbers? =

Yes. Enable multiple numbers or branches and let customers select one at checkout.

= Do I need WhatsApp Cloud API for basic ordering? =

No. Buy on WhatsApp and share buttons work with your WhatsApp number. Cloud API is only needed for automated order confirmation and status notifications.

= Does the plugin support WooCommerce HPOS? =

Yes. The plugin declares compatibility with WooCommerce custom order tables (HPOS).

= Does the plugin support Cart and Checkout blocks? =

Yes. WhatsApp / Share buttons work on the Cart block, and WhatsApp Order is available as a payment method on the Checkout block.

== Changelog ==

= 1.3.8 =
* Dev: Fix qit Code Compatibility issues.

= 1.3.7 =
* Dev: Fix qit Code Compatibility issues.

= 1.3.6 =
* New: Inline WhatsApp/Share buttons option.
* Fix: WhatsApp popup checkout works for guests and logged-in customers.
* Fix: Localized CDN scripts.
* Update: Theme compatibility.
* Update: Verified compatibility with the latest WordPress and WooCommerce.

= 1.3.5 =
* New: Order message template tab with a configurable post-checkout WhatsApp message.

= 1.3.4 =
* Fix: Added validation and permission checks to improve AJAX request security.

= 1.3.3 =
* New: Plugin documentation link.
* Dev: Verified compatibility with the latest WordPress and WooCommerce.

= 1.3.2 =
* Added Display & Design Settings sub-tab.
* Added option to enable multiple WhatsApp numbers or branches.
* Frontend validation for multiple numbers/branches.
* Minor bug fixes.

= 1.3.1 =
* Compatibility updated for the latest WooCommerce and WordPress versions.

= 1.3.0 =
* Added compatibility with WooCommerce Cart and Checkout blocks.
* Added WhatsApp Payment method support for the Checkout block.
* Added Order on WhatsApp and Share button to the Cart block.

= 1.2.8 =
* Added option to place an order via WhatsApp as a payment method.
* Added checkbox for Order on WhatsApp instead of radio buttons.
* Improved WhatsApp message layout.

= 1.2.6 =
* Integrated WhatsApp Cloud API for order notifications.
* Minor bug fixes.

= 1.2.1 =
* Made compatible with WooCommerce HPOS.

= 1.0.0 =
* Initial release.

== Upgrade Notice ==

= 1.3.8 =
Fix qit Code Compatibility issues.
