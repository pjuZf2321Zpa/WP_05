<?php

/**
 * Generate WhatsApp and Share button HTML for shop page
 * 
 * @param $add_to_cart_html
 * @param $product
 * @param $args
 * @return $whatsAppAndShareButton
 */
function fmaOowWhatsAppAndShareButtonGetHtml( $add_to_cart_html = '', $product = '', $args = '' ) {
	// include 'fma-order-on-whatsapp-find-device.php'; // this file contains the function to find the device
	$fma_oow_selected_icon = get_option('fma_oow_icons', '0');
	$fma_oow_def_icon_chk = get_option('fma_oow_def_icon_chk', 'off');
	if ('off' == $fma_oow_def_icon_chk) {
		// this function will generate css for icons
		fma_oow_icons_css();
	}
	$fma_oow_enable_only_for_customer = get_option('fma_oow_enable_only_for_customers');
	if ('yes' == $fma_oow_enable_only_for_customer) {
		if (true != is_user_logged_in()) {
			return;
		}
	}
	?>
	<?php
	$fma_order_on_whatsapp_show_on_shop_page_or_not = get_option('fma_order_on_whatsapp_show_on_shop_page', true);
	$fma_order_on_whatsapp_share_show_btn_on_shop_page_or_not = get_option('fma_order_on_whatsapp_share_show_btn_on_shop_page', true);

	$fma_order_on_whatsapp_number = get_option('fma_order_on_whatsapp_whatsapp_number', true);
	$fma_order_on_whatsapp_products_list = (array) get_option('fma_order_on_whatsapp_products_list');
	$fma_order_on_whatsapp_either_products_or_cats = get_option('fma_order_on_whatsapp_either_products_or_cats', true);
	$fma_order_on_whatsapp_categories_list = get_option('fma_order_on_whatsapp_categories_list', true);

	$fma_order_on_whatsapp_cart_btn_bg_color = get_option('fma_order_on_whatsapp_cart_btn_bg_color_hash');
	$fma_order_on_whatsapp_cart_btn_text_color_hash = get_option('fma_order_on_whatsapp_cart_btn_text_color_hash');
	$fma_oow_apply_on_all_products = get_option('fma_oow_apply_on_all_products');
	$fma_oow_share_btn_txt = WpmlHelper::translate((string) get_option('fma_oow_share_btn_txt'), 'saved_fma_oow_share_btn_txt');
	$fma_oow_share_btn_bg_color = get_option('fma_oow_share_btn_bg_color');
	$fma_oow_share_btn_text_color = get_option('fma_oow_share_btn_text_color');
	$fma_oow_msg_when_whatsap_opens = WpmlHelper::translate((string) get_option('fma_oow_msg_when_whatsap_opens'), 'saved_fma_oow_msg_when_whatsap_opens');
	$fma_oow_share_msg_when_whatsap_opens = WpmlHelper::translate((string) get_option('fma_oow_share_msg_when_whatsap_opens'), 'saved_fma_oow_share_msg_when_whatsap_opens');

	$fma_order_on_whatsa_button_on_desktop_shop_page = get_option('fma_order_on_whatsa_button_on_desktop');
	$fma_order_on_whatsapp_hide_on_desktop_shop_page = '';

	$fma_oow_where_to_open_whatsapp = fma_oow_open_whatsapp_in_which_tab(); // where to open whatsapp
	$fma_oow_the_device = fma_order_on_whatsapp_find_device();
	$fma_oow_show_share_btn_or_not = fma_oow_show_share_btn_or_not();
	if (empty($fma_order_on_whatsapp_cart_btn_bg_color)) {
		$fma_order_on_whatsapp_cart_btn_bg_color = '#25d366';
	}
	if (empty($fma_order_on_whatsapp_cart_btn_text_color_hash)) {
		$fma_order_on_whatsapp_cart_btn_text_color_hash = '#ffff';
	}
	// BG color for share button
	if (empty($fma_oow_share_btn_bg_color)) {
		$fma_oow_share_btn_bg_color = '#25d366';
	}
	// text color for share button
	if (empty($fma_oow_share_btn_text_color)) {
		$fma_oow_share_btn_text_color = '#ffff';
	}
	$whatsapp_btn_border_clr_hash = get_option('whatsapp_btn_border_clr_hash');
	$whatsapp_btn_border_clr_width = get_option('whatsapp_btn_border_clr_width');
	if (empty($whatsapp_btn_border_clr_hash)) {
		$whatsapp_btn_border_clr_hash = '#25d366';
	}
	if (empty($whatsapp_btn_border_clr_width)) {
		$whatsapp_btn_border_clr_width = 0;
	}
	$share_btn_border_clr_hash = get_option('share_btn_border_clr_hash');
	$share_btn_border_clr_width = get_option('share_btn_border_clr_width');
	if (empty($share_btn_border_clr_hash)) {
		$share_btn_border_clr_hash = '#25d366';
	}
	if (empty($share_btn_border_clr_width)) {
		$share_btn_border_clr_width = 0;
	}
	if (!$product) {
		global $product;
	}
	$theme = wp_get_theme();
	$fma_order_on_whatsapp_button_text = WpmlHelper::translate((string) get_option('fma_order_on_whatsapp_button_text', true), 'saved_fma_order_on_whatsapp_button_text');
	$fma_order_on_whatsapp_product_title_on_shop_page = $product->get_title();
	$fma_order_on_whatsapp_price_on_shop_page = get_woocommerce_currency_symbol() . $product->get_price();
	$fma_order_on_whatsapp_link_on_shop_page = $product->get_permalink();
	$fma_order_on_whatsapp_current_title = $product->get_title();
	$fma_order_on_whatsapp_terms = get_the_terms($product->get_id(), 'product_cat'); // categories list
	$fma_order_on_whatsapp_current_category = '';
	if (isset($fma_order_on_whatsapp_terms[0]->name)) {
		$fma_order_on_whatsapp_current_category = $fma_order_on_whatsapp_terms[0]->name;
	}
	// find the user browser
	if ('api' == $fma_oow_the_device) {
		// mobile
		$fma_oow_mbl_or_dsktp = 'api';
	} else {
		// desktop
		$fma_oow_mbl_or_dsktp = 'web';
		if (!empty($fma_order_on_whatsa_button_on_desktop_shop_page) && 'yes' == $fma_order_on_whatsa_button_on_desktop_shop_page) {
			$fma_order_on_whatsapp_hide_on_desktop_shop_page = 'display:none !important';
		}
	}
	$fma_oow_shop_product_share_url = fma_oow_build_product_share_url(
		$fma_order_on_whatsapp_number,
		$fma_oow_share_msg_when_whatsap_opens,
		$fma_order_on_whatsapp_product_title_on_shop_page,
		$fma_order_on_whatsapp_link_on_shop_page,
		$product->get_price(),
		1
	);
	$whatsAppAndShareButton = '';
	if ('yes' == $fma_oow_apply_on_all_products) {
		?>
		<?php if ( $product->get_type() == 'simple' && $product->get_stock_status() != 'outofstock' ) { ?>
			<!-- whatsapp button  -->
			<?php 
			if ('yes' === $fma_order_on_whatsapp_show_on_shop_page_or_not) {
				 $whatsAppAndShareButton = "<a style='" . esc_attr(fma_oow_get_whatsapp_button_inline_style('shop', $fma_order_on_whatsapp_hide_on_desktop_shop_page)) . "'
					class='button fma_order_on_whatsapp_btn_on_shop_page' type='button'> <span class='fma_oow_icon'> " . 
					filter_var( fma_oow_get_icon_url($fma_oow_selected_icon) )
					. "</span><span class='fma_oow_btn_shop_pg'>" .
						esc_html($fma_order_on_whatsapp_button_text) . 
					'</span></a>';
			}
			// <!-- whatsapp button ends  -->
			$whatsAppAndShareButton .= "<input type='hidden' class='product_id_whatsapp' value='" . esc_attr(get_the_ID()) . "'>" . fma_oow_share_buttons_br_tag();
			// <!-- share button -->
			if ('yes' == $fma_oow_show_share_btn_or_not && 'yes' == $fma_order_on_whatsapp_share_show_btn_on_shop_page_or_not) {
				$whatsAppAndShareButton .= "<a class='fma_oow_share_btn fma_oow_share_btn_shop_pg'
					style='" . esc_attr(fma_oow_get_share_button_inline_style('shop')) . "'
					target='" . esc_attr($fma_oow_where_to_open_whatsapp) . "' 
					href='" . fma_oow_esc_whatsapp_send_url($fma_oow_shop_product_share_url) . "'><span
						class='fma_oow_btn_shop_pg'>" .
						 esc_html(sanitize_text_field($fma_oow_share_btn_txt)) .
					'</span></a>';
			}
			//  <!-- share button ends  -->
		} elseif ( $product->get_type() == 'variable' ) {

			// <!-- whatsapp button  -->
			if ('yes' === $fma_order_on_whatsapp_show_on_shop_page_or_not) {
				$whatsAppAndShareButton .= "<a href='" . esc_url($product->get_permalink(), 'order-on-whatsapp') . "'
					style='" . esc_attr(fma_oow_get_whatsapp_button_inline_style('shop', $fma_order_on_whatsapp_hide_on_desktop_shop_page)) . "'
					class='button fma_order_on_whatsapp_btn_on_shop_page whatsapp_link_variable' type='button'> <span
						class='fma_oow_icon'>" .
						filter_var(fma_oow_get_icon_url($fma_oow_selected_icon)) . "
					</span><span class='fma_oow_btn_shop_pg'>"
						. esc_html($fma_order_on_whatsapp_button_text) . 
					'</span></a> ' . fma_oow_share_buttons_br_tag();
			}
			// <!-- whatsapp button ends  -->
			// <!-- share button -->
			if ('yes' == $fma_oow_show_share_btn_or_not && 'yes' == $fma_order_on_whatsapp_share_show_btn_on_shop_page_or_not) {
				$whatsAppAndShareButton .= "<a class='fma_oow_share_btn fma_oow_share_btn_shop_pg'
					style='" . esc_attr(fma_oow_get_share_button_inline_style('shop')) . "'
					target='" . esc_attr($fma_oow_where_to_open_whatsapp) . "'
					href='" . fma_oow_esc_whatsapp_send_url($fma_oow_shop_product_share_url) . "'><span class='fma_oow_btn_shop_pg'>" .
						 esc_html(sanitize_text_field($fma_oow_share_btn_txt)) .
					'</span></a>';
			}
			// <!-- share button ends  -->

		}
		// return "before btn" . $add_to_cart_html . "<br>" . "after btn";
	} else if ($product->get_type() == 'simple' && $product->get_stock_status() != 'outofstock') {
		$whatsAppAndShareButton = '';
		if ('fma_order_on_whatsapp_products_list' == $fma_order_on_whatsapp_either_products_or_cats) {
			if (!empty($fma_order_on_whatsapp_number) && is_array($fma_order_on_whatsapp_products_list) && in_array(get_the_ID(), $fma_order_on_whatsapp_products_list)) {

				// <!-- whatsapp button  -->
				if ('yes' === $fma_order_on_whatsapp_show_on_shop_page_or_not) { 
					$whatsAppAndShareButton .= "<a style='" . esc_attr(fma_oow_get_whatsapp_button_inline_style('shop', $fma_order_on_whatsapp_hide_on_desktop_shop_page)) . "'
					class='button fma_order_on_whatsapp_btn_on_shop_page' type='button'> <span class='fma_oow_icon'> " . 
						filter_var( fma_oow_get_icon_url($fma_oow_selected_icon) )
					. "</span><span class='fma_oow_btn_shop_pg'>" .
						esc_html($fma_order_on_whatsapp_button_text) . '
					</span></a>';
				}
				//  <!-- whatsapp button ends  -->

				$whatsAppAndShareButton .= "<input type='hidden' value='" . esc_attr(get_the_ID()) . "'>" . fma_oow_share_buttons_br_tag();

				// <!-- share button -->
				if ('yes' == $fma_oow_show_share_btn_or_not && 'yes' == $fma_order_on_whatsapp_share_show_btn_on_shop_page_or_not) {
					$whatsAppAndShareButton .= "<a class='fma_oow_share_btn fma_oow_share_btn_shop_pg'
					style='" . esc_attr(fma_oow_get_share_button_inline_style('shop')) . "'
					target='" . esc_attr($fma_oow_where_to_open_whatsapp) . "'
					href='" . fma_oow_esc_whatsapp_send_url($fma_oow_shop_product_share_url) . "'><span
						class='fma_oow_btn_shop_pg'>" .
						 esc_html(sanitize_text_field($fma_oow_share_btn_txt)) .
					'</span></a>';
				}
				// <!-- share button ends  -->

				// <!-- there are no products -->
			}
		} elseif ('categories' == $fma_order_on_whatsapp_either_products_or_cats) {
			?>
			<?php 
			if (!empty($fma_order_on_whatsapp_categories_list) && is_array($fma_order_on_whatsapp_categories_list) && fmaOowCheckProductOrCategoryPresentInList($fma_order_on_whatsapp_either_products_or_cats, $product->get_id(), $fma_order_on_whatsapp_categories_list)) {
				// <!-- whatsapp button  -->
				if ('yes' === $fma_order_on_whatsapp_show_on_shop_page_or_not) {
					$whatsAppAndShareButton .= "<a style='" . esc_attr(fma_oow_get_whatsapp_button_inline_style('shop', $fma_order_on_whatsapp_hide_on_desktop_shop_page)) . "'
					class='button fma_order_on_whatsapp_btn_on_shop_page' type='button'> <span class='fma_oow_icon'> " . 
						filter_var( fma_oow_get_icon_url($fma_oow_selected_icon) )
					. "</span><span class='fma_oow_btn_shop_pg'>" .
						esc_html($fma_order_on_whatsapp_button_text) . '
					</span></a>';
					
					$whatsAppAndShareButton .= "<input type='hidden' class='product_id_whatsapp' value='" . esc_attr(get_the_ID()) . "'>" . fma_oow_share_buttons_br_tag();
				}
				// <!-- whatsapp button ends  -->
				// <!-- share button -->
				if ('yes' == $fma_oow_show_share_btn_or_not && 'yes' == $fma_order_on_whatsapp_share_show_btn_on_shop_page_or_not) {
					$whatsAppAndShareButton .= "<a class='fma_oow_share_btn fma_oow_share_btn_shop_pg'
					style='" . esc_attr(fma_oow_get_share_button_inline_style('shop')) . "'
					target='" . esc_attr($fma_oow_where_to_open_whatsapp) . "'
					href='" . fma_oow_esc_whatsapp_send_url($fma_oow_shop_product_share_url) . "'><span
						class='fma_oow_btn_shop_pg'>" .
						 esc_html(sanitize_text_field($fma_oow_share_btn_txt)) .
					'</span></a>';
				}
				// <!-- share button ends -->
			}
		}
	} elseif ($product->get_type() == 'variable' || $product->get_type() == 'grouped') {
		$whatsAppAndShareButton = '';
		if ('fma_order_on_whatsapp_products_list' == $fma_order_on_whatsapp_either_products_or_cats) {
			?>
			<?php 
			if (!empty($fma_order_on_whatsapp_number) && is_array($fma_order_on_whatsapp_products_list) && in_array(get_the_ID(), $fma_order_on_whatsapp_products_list)) {

				// <!-- whatsapp button  -->
				if ('yes' === $fma_order_on_whatsapp_show_on_shop_page_or_not) {
					$whatsAppAndShareButton .= "<a style='" . esc_attr(fma_oow_get_whatsapp_button_inline_style('shop', $fma_order_on_whatsapp_hide_on_desktop_shop_page)) . "'
						target='" . esc_attr($fma_oow_where_to_open_whatsapp) . "'
						class='button fma_order_on_whatsapp_btn_on_shop_page' type='button'
						href='" . esc_url(get_permalink(get_the_id())) . "'><span class='fma_oow_icon'>" .
						 filter_var(fma_oow_get_icon_url($fma_oow_selected_icon)) . "
						</span><span class='fma_oow_btn_shop_pg'>" .
						 esc_html($fma_order_on_whatsapp_button_text) .
						'</span></a>' . fma_oow_share_buttons_br_tag();
				}
				// <!-- whatsapp button ends  -->

				// <!-- share button -->
				if ('yes' == $fma_oow_show_share_btn_or_not && 'yes' == $fma_order_on_whatsapp_share_show_btn_on_shop_page_or_not) {
					$whatsAppAndShareButton .= "<a class='fma_oow_share_btn fma_oow_share_btn_shop_pg'
						style='" . esc_attr(fma_oow_get_share_button_inline_style('shop')) . "'
						target='" . esc_attr($fma_oow_where_to_open_whatsapp) . "'
						href='" . fma_oow_esc_whatsapp_send_url($fma_oow_shop_product_share_url) . "'><span class='fma_oow_btn_shop_pg'>" .
						   esc_html(sanitize_text_field($fma_oow_share_btn_txt)) .
					   '</span></a>';
				}
				// <!-- share button ends  -->

			}
		} elseif ('categories' == $fma_order_on_whatsapp_either_products_or_cats) {

			?>

			<?php 
			if (!empty($fma_order_on_whatsapp_categories_list) && is_array($fma_order_on_whatsapp_categories_list) && fmaOowCheckProductOrCategoryPresentInList($fma_order_on_whatsapp_either_products_or_cats, $product->get_id(), $fma_order_on_whatsapp_categories_list)) {
				// <!-- whatsapp button  -->
				if ('yes' === $fma_order_on_whatsapp_show_on_shop_page_or_not) {
					$whatsAppAndShareButton .= "<a style='" . esc_attr(fma_oow_get_whatsapp_button_inline_style('shop', $fma_order_on_whatsapp_hide_on_desktop_shop_page)) . "' 
						target='" . esc_attr($fma_oow_where_to_open_whatsapp) . "'
						class='button fma_order_on_whatsapp_btn_on_shop_page whatsapp_link_variable' type='button'
						href='" . esc_url(get_permalink(get_the_id())) . "'><span class='fma_oow_icon'>" .
							filter_var(fma_oow_get_icon_url($fma_oow_selected_icon)) .
					   "</span><span class='fma_oow_btn_shop_pg'>" .
						   esc_html($fma_order_on_whatsapp_button_text) . 
					   '</span></a>' . fma_oow_share_buttons_br_tag();
				}
				// <!-- whatsapp button ends  -->

				// <!-- share button -->
				if ('yes' == $fma_oow_show_share_btn_or_not && 'yes' == $fma_order_on_whatsapp_share_show_btn_on_shop_page_or_not) {
					$whatsAppAndShareButton .= "<a class='fma_oow_share_btn fma_oow_share_btn_shop_pg'
						style='" . esc_attr(fma_oow_get_share_button_inline_style('shop')) . "'
						target='" . esc_attr($fma_oow_where_to_open_whatsapp) . "'
						href='" . fma_oow_esc_whatsapp_send_url($fma_oow_shop_product_share_url) . "'><span class='fma_oow_btn_shop_pg'>" .
							esc_html(sanitize_text_field($fma_oow_share_btn_txt)) . 
						'</span></a>';
				}
				// <!-- share button ends  -->
			}
		}
	}

	$whatsAppAndShareButton .= "<input type='hidden' data-theme ='" . esc_attr($theme->name) . "'> " . fma_oow_share_buttons_br_tag();
	if (!empty(trim($whatsAppAndShareButton))) {
		$whatsAppAndShareButton = "<div class='fma_oow_btns fma_oow_btns_shop_pg'>" . $whatsAppAndShareButton . '</div>';
		fma_oow_mark_checkout_popup_buttons_rendered();
	}
	return $whatsAppAndShareButton;
}

/**
 * Strip non-digits from a WhatsApp phone number for URL use.
 *
 * @param string $phone Phone number.
 * @return string
 */
function fma_oow_format_whatsapp_phone_for_url( $phone ) {
	return preg_replace('/\D+/', '', (string) $phone);
}

/**
 * WhatsApp send host segment (api for mobile, web for desktop).
 *
 * @return string
 */
function fma_oow_get_whatsapp_send_host() {
	return ( 'api' === fma_order_on_whatsapp_find_device() ) ? 'api' : 'web';
}

/**
 * Plain-text currency symbol for WhatsApp share messages.
 *
 * @return string
 */
function fma_oow_get_share_currency_symbol() {
	return html_entity_decode(get_woocommerce_currency_symbol(), ENT_QUOTES, 'UTF-8');
}

/**
 * Format a unit price and quantity line for share messages (e.g. Rs100*2=Rs200).
 *
 * @param float|string $unit_price Unit price.
 * @param int          $quantity   Item quantity.
 * @return string
 */
function fma_oow_format_share_price_line( $unit_price, $quantity = 1 ) {
	$symbol = fma_oow_get_share_currency_symbol();
	$qty = max(1, (int) $quantity);
	$unit = wc_format_decimal((float) $unit_price);
	$line_total = wc_format_decimal((float) $unit_price * $qty);

	return $symbol . $unit . '*' . $qty . '=' . $symbol . $line_total;
}

/**
 * Build a WhatsApp send URL that opens the store number with a prefilled message.
 *
 * @param string $phone Store WhatsApp number.
 * @param string $text  Message body.
 * @return string
 */
function fma_oow_encode_whatsapp_message_for_url( $text ) {
	$text = str_replace( array( "\r\n", "\r" ), "\n", (string) $text );
	$lines = explode( "\n", $text );

	return implode( '%0a', array_map( 'rawurlencode', $lines ) );
}

/**
 * Build a WhatsApp send URL that opens the store number with a prefilled message.
 *
 * @param string $phone Store WhatsApp number.
 * @param string $text  Message body.
 * @return string
 */
function fma_oow_build_whatsapp_send_url( $phone, $text ) {
	$phone_digits = fma_oow_format_whatsapp_phone_for_url($phone);
	if ('' === $phone_digits) {
		return '#';
	}

	return 'https://' . fma_oow_get_whatsapp_send_host() . '.whatsapp.com/send?phone=' . rawurlencode($phone_digits) . '&text=' . fma_oow_encode_whatsapp_message_for_url($text);
}

/**
 * Build a WhatsApp app deep-link URL for mobile (opens the app directly).
 *
 * @param string $phone Store WhatsApp number.
 * @param string $text  Message body.
 * @return string
 */
function fma_oow_build_whatsapp_app_send_url( $phone, $text ) {
	$phone_digits = fma_oow_format_whatsapp_phone_for_url($phone);
	if ('' === $phone_digits) {
		return '#';
	}

	return 'whatsapp://send?phone=' . $phone_digits . '&text=' . fma_oow_encode_whatsapp_message_for_url($text);
}

/**
 * Escape a WhatsApp send URL for HTML href while preserving %0a line breaks.
 * esc_url() strips encoded newlines, which breaks prefilled share messages.
 *
 * @param string $url WhatsApp send URL from fma_oow_build_whatsapp_send_url().
 * @return string
 */
function fma_oow_esc_whatsapp_send_url( $url ) {
	$url = (string) $url;

	if ('' === $url || '#' === $url) {
		return esc_attr($url);
	}

	if (! preg_match('#^https://(api|web)\.whatsapp\.com/send\?#i', $url)) {
		return '#';
	}

	return esc_attr($url);
}

/**
 * Line break between WhatsApp and Share buttons (omitted when inline layout is on).
 *
 * @return string
 */
function fma_oow_share_buttons_br_tag() {
	if (function_exists('fma_oow_is_inline_buttons_enabled') && fma_oow_is_inline_buttons_enabled()) {
		return '';
	}

	return '<br />';
}

/**
 * Build a simple share message with bold labels and line breaks.
 *
 * @param string   $intro_msg Opening line.
 * @param array    $products  Product rows with title, price, quantity, link keys.
 * @param float|string|null $total Cart total; omit for single-product share.
 * @return string
 */
function fma_oow_build_simple_share_message( $intro_msg, $products, $total = null ) {
	$nl = "\n";
	$text = '*' . trim($intro_msg) . '*' . $nl;

	foreach ($products as $product_item) {
		$title = isset($product_item['title']) ? $product_item['title'] : '';
		$price = isset($product_item['price']) ? $product_item['price'] : 0;
		$quantity = isset($product_item['quantity']) ? max(1, (int) $product_item['quantity']) : 1;
		$link = isset($product_item['link']) ? $product_item['link'] : '';

		$text .= '*Product:* ' . $title . $nl;
		$text .= '*Quantity:* ' . $quantity . $nl;
		$text .= '*Product Link:* ' . $link . $nl;
		$text .= '*Price:* ' . fma_oow_format_share_price_line($price, $quantity) . $nl;
	}

	if (null !== $total) {
		$symbol = fma_oow_get_share_currency_symbol();
		$text .= '*Total Bill:* ' . $symbol . wc_format_decimal((float) $total);
	}

	return $text;
}

/**
 * Build a product share message and WhatsApp send URL.
 *
 * @param string       $phone      Store WhatsApp number.
 * @param string       $intro_msg  Opening line.
 * @param string       $title      Product title.
 * @param string       $link       Product permalink.
 * @param float|string $unit_price Unit price.
 * @param int          $quantity   Item quantity.
 * @return string
 */
function fma_oow_build_product_share_url( $phone, $intro_msg, $title, $link, $unit_price, $quantity = 1 ) {
	$qty = max(1, (int) $quantity);
	$products = array(
		array(
			'title'    => $title,
			'price'    => $unit_price,
			'quantity' => $qty,
			'link'     => $link,
		),
	);
	$text = fma_oow_build_simple_share_message($intro_msg, $products);

	return fma_oow_build_whatsapp_send_url($phone, $text);
}

/**
 * Build a cart share message and WhatsApp send URL.
 *
 * @param array  $items        Cart items.
 * @param string $total        Cart total.
 * @param string $phone        Store WhatsApp number.
 * @param string $intro_msg    Opening line.
 * @return string
 */
function fma_oow_build_cart_share_url( $items, $total, $phone, $intro_msg ) {
	$products = array();

	foreach ($items as $item) {
		$products[] = array(
			'title'    => $item['data']->get_title(),
			'price'    => $item['data']->get_price(),
			'quantity' => $item['quantity'],
			'link'     => get_permalink($item['data']->get_id()),
		);
	}

	$text = fma_oow_build_simple_share_message($intro_msg, $products, $total);

	return fma_oow_build_whatsapp_send_url($phone, $text);
}

/**
 * Check whether a cart item matches the selected product/category targeting.
 *
 * @param array $cart_item WooCommerce cart item.
 * @return bool
 */
function fma_oow_cart_item_matches_product_targeting( $cart_item ) {
	if (!is_array($cart_item)) {
		return false;
	}

	$product_id   = isset($cart_item['product_id']) ? absint($cart_item['product_id']) : 0;
	$variation_id = isset($cart_item['variation_id']) ? absint($cart_item['variation_id']) : 0;

	if (!$product_id && isset($cart_item['data']) && is_object($cart_item['data']) && method_exists($cart_item['data'], 'get_id')) {
		$product_id = absint($cart_item['data']->get_id());
	}

	$fmaOowEitherProductsOrCats = get_option('fma_order_on_whatsapp_either_products_or_cats', true);
	if ('fma_order_on_whatsapp_products_list' === $fmaOowEitherProductsOrCats) {
		$selected_products = get_option('fma_order_on_whatsapp_products_list');
		if (!is_array($selected_products) || empty($selected_products)) {
			return false;
		}

		return in_array($product_id, $selected_products) || ( $variation_id && in_array($variation_id, $selected_products) );
	}

	if ('categories' === $fmaOowEitherProductsOrCats) {
		$selected_categories = get_option('fma_order_on_whatsapp_categories_list');
		if (!is_array($selected_categories) || empty($selected_categories) || !$product_id) {
			return false;
		}

		return 1 == fmaOowCheckProductOrCategoryPresentInList($fmaOowEitherProductsOrCats, $product_id, $selected_categories);
	}

	return false;
}

/**
 * Check whether cart buttons should render for the current product/category targeting.
 *
 * @param array $cart_items WooCommerce cart items.
 * @return bool
 */
function fma_oow_cart_has_targeted_products( $cart_items ) {
	if (empty($cart_items) || !is_array($cart_items)) {
		return false;
	}

	if ('yes' === get_option('fma_oow_apply_on_all_products', 'no')) {
		return true;
	}

	foreach ($cart_items as $cart_item) {
		if (fma_oow_cart_item_matches_product_targeting($cart_item)) {
			return true;
		}
	}

	return false;
}

/**
 * Check product or category present in selected products or categories list
 * 
 * @param $fmaOowEitherProductsOrCats
 * @param $fmaProductId
 * @param $fmaOowProductOrCategoryList
 * @return 0 or 1
 */
function fmaOowCheckProductOrCategoryPresentInList( $fmaOowEitherProductsOrCats, $fmaProductId, $fmaOowProductOrCategoryList ) {
	if ('fma_order_on_whatsapp_products_list' == $fmaOowEitherProductsOrCats) {
		if (is_array($fmaOowProductOrCategoryList) && in_array($fmaProductId, $fmaOowProductOrCategoryList)) {
			return 1;
		} else {
			return 0;
		}
	} elseif ( 'categories' == $fmaOowEitherProductsOrCats) {
		$fmaOowTerms = get_the_terms($fmaProductId, 'product_cat'); // categories list
		if (is_array($fmaOowTerms) && !empty($fmaOowTerms)) {
			foreach ($fmaOowTerms as $fmaSingleCategory) {
				if (is_array($fmaOowProductOrCategoryList) && in_array($fmaSingleCategory->name, $fmaOowProductOrCategoryList)) {
					return 1;
				}

				$fmaOowAncestorIds = get_ancestors($fmaSingleCategory->term_id, 'product_cat');
				foreach ($fmaOowAncestorIds as $fmaOowAncestorId) {
					$fmaOowAncestor = get_term($fmaOowAncestorId, 'product_cat');
					if (!is_wp_error($fmaOowAncestor) && is_array($fmaOowProductOrCategoryList) && in_array($fmaOowAncestor->name, $fmaOowProductOrCategoryList)) {
						return 1;
					}
				}
			}
			return 0;
		} else {
			return 0;
		}
	}
}

/**
 * Check product to show or hide add to cart button
 * 
 * @param $product
 * @return $fmaOowCheckProductOrCategoryPresentInList
 */
function fmaOowCheckToShowOrHideAddToCartBtn( $product ) {

	$fmaOowEitherProductsOrCats = get_option('fma_order_on_whatsapp_either_products_or_cats', true);
	$fma_order_on_whatsapp_selected_products_list = get_option('fma_order_on_whatsapp_products_list');
	$fma_order_on_whatsapp_categories_list = get_option('fma_order_on_whatsapp_categories_list');
	$fmaOowHideAddToCartButShopOrProduct = 'no';
	if (is_shop()) {
		$fmaOowHideAddToCartButShopOrProduct = get_option('fma_order_on_whatsapp_hide_add_to_cart_button_shop_page');
	} elseif ( is_product() ) {
		$fmaOowHideAddToCartButShopOrProduct = get_option('fma_order_on_whatsapp_hide_add_to_cart_button_product_page');
	} else {
		$fmaOowHideAddToCartButShopOrProduct = get_option('fma_order_on_whatsapp_hide_add_to_cart_button_shop_page');
	}
	$fmaOowCheckProductOrCategoryPresentInList = 0;
	if ( 'yes' == $fmaOowHideAddToCartButShopOrProduct) {
		if ('fma_order_on_whatsapp_products_list' == $fmaOowEitherProductsOrCats && !empty($fma_order_on_whatsapp_selected_products_list)) {
			$fmaOowCheckProductOrCategoryPresentInList = fmaOowCheckProductOrCategoryPresentInList($fmaOowEitherProductsOrCats, $product->get_id(), $fma_order_on_whatsapp_selected_products_list);
			return $fmaOowCheckProductOrCategoryPresentInList;
		} elseif ('categories' == $fmaOowEitherProductsOrCats && !empty($fma_order_on_whatsapp_categories_list)) {
			$fmaOowCheckProductOrCategoryPresentInList = fmaOowCheckProductOrCategoryPresentInList($fmaOowEitherProductsOrCats, $product->get_id(), $fma_order_on_whatsapp_categories_list);
			return $fmaOowCheckProductOrCategoryPresentInList;
		}
	} else {
		return $fmaOowCheckProductOrCategoryPresentInList;
	}
}

/**
 * Generate WhatsApp and Share button HTML for product page
 * 
 * @param $add_to_cart_html
 * @param $product
 * @param $args
 * @return $whatsAppAndShareButton
 */
function fmaOowWhatsAppAndShareButtonGetHtmlForProductPage() {
	$fma_oow_selected_icon = get_option('fma_oow_icons', '0');
	$fma_oow_def_icon_chk = get_option('fma_oow_def_icon_chk', 'off');

	if ('off' == $fma_oow_def_icon_chk) {
		// this function will generate css for icons
		fma_oow_icons_css();
	}
	$fma_oow_enable_only_for_customer = get_option('fma_oow_enable_only_for_customers');
	if ('yes' == $fma_oow_enable_only_for_customer) {
		if (true != is_user_logged_in()) {
			return;
		}
	}
	// For Simple Product
	global $product;
	$product = wc_get_product(get_the_ID());
	$fma_order_on_whatsapp_product_name = $product->get_title();
	$fma_order_on_whatsapp_product_price = get_woocommerce_currency_symbol();
	$fma_order_on_whatsapp_product_price .= $product->get_price();
	$fma_order_on_whatsapp_product_type = $product->get_type();
	$fma_order_on_whatsapp_product_link = get_permalink();
	$fma_order_on_whatsapp_button_text = WpmlHelper::translate((string) get_option('fma_order_on_whatsapp_button_text', true), 'saved_fma_order_on_whatsapp_button_text');
	$fma_order_on_whatsapp_terms = get_the_terms($product->get_id(), 'product_cat'); // categories list
	$fma_order_on_whatsapp_current_category = '';
	if (! empty($fma_order_on_whatsapp_terms) && ! is_wp_error($fma_order_on_whatsapp_terms)) {
		$fma_order_on_whatsapp_current_category = $fma_order_on_whatsapp_terms[0]->name;
	}
	// get whatsapp number, if it is set
	// get products list to check either this product is set from backend or not
	// if both the conditions above are set, then only show the button otherwise not
	$fma_order_on_whatsapp_number = get_option('fma_order_on_whatsapp_whatsapp_number', true);
	$fma_order_on_whatsapp_products_list = (array) get_option('fma_order_on_whatsapp_products_list', true);
	$fma_order_on_whatsapp_categories_list = get_option('fma_order_on_whatsapp_categories_list', true);
	$fma_order_on_whatsapp_either_products_or_cats = get_option('fma_order_on_whatsapp_either_products_or_cats', true);
	$fma_order_on_whatsapp_show_on_single_product_page_or_not = get_option('fma_order_on_whatsapp_show_on_single_product', true);
	$fma_order_on_whatsa_button_on_desktop = get_option('fma_order_on_whatsa_button_on_desktop');
	$fma_order_on_whatsapp_cart_btn_bg_color = get_option('fma_order_on_whatsapp_cart_btn_bg_color_hash');
	$whatsapp_btn_border_clr_hash = get_option('whatsapp_btn_border_clr_hash');
	$whatsapp_btn_border_clr_width = get_option('whatsapp_btn_border_clr_width');
	$share_btn_border_clr_hash = get_option('share_btn_border_clr_hash');
	$share_btn_border_clr_width = get_option('share_btn_border_clr_width');

	if (empty($share_btn_border_clr_hash)) {
		$share_btn_border_clr_hash = '#25d366';
	}

	if (empty($share_btn_border_clr_width)) {
		$share_btn_border_clr_width = 0;
	}
	$fma_order_on_whatsapp_cart_btn_text_color_hash = get_option('fma_order_on_whatsapp_cart_btn_text_color_hash');
	$fma_oow_apply_on_all_products = get_option('fma_oow_apply_on_all_products');
	$fma_order_on_whatsapp_show_on_shop_page = get_option('fma_order_on_whatsapp_show_on_single_product');
	$fma_order_on_whatsapp_share_show_btn_on_single_product = get_option('fma_order_on_whatsapp_share_show_btn_on_single_product');
	$fma_oow_share_btn_bg_color = get_option('fma_oow_share_btn_bg_color');
	$fma_oow_share_btn_text_color = get_option('fma_oow_share_btn_text_color');
	$fma_oow_msg_when_whatsap_opens = WpmlHelper::translate((string) get_option('fma_oow_msg_when_whatsap_opens'), 'saved_fma_oow_msg_when_whatsap_opens');
	$fma_oow_share_msg_when_whatsap_opens = WpmlHelper::translate((string) get_option('fma_oow_share_msg_when_whatsap_opens'), 'saved_fma_oow_share_msg_when_whatsap_opens');
	$fma_oow_share_btn_txt = WpmlHelper::translate((string) get_option('fma_oow_share_btn_txt'), 'saved_fma_oow_share_btn_txt');
	$fma_oow_product_share_url = fma_oow_build_product_share_url(
		$fma_order_on_whatsapp_number,
		$fma_oow_share_msg_when_whatsap_opens,
		$fma_order_on_whatsapp_product_name,
		$fma_order_on_whatsapp_product_link,
		$product->get_price(),
		1
	);
	$fma_oow_selected_variation_ids = array();
	if ('variable' == $fma_order_on_whatsapp_product_type && is_array($fma_order_on_whatsapp_products_list)) {
		foreach ($fma_order_on_whatsapp_products_list as $fma_oow_selected_product_id) {
			$fma_oow_selected_product_id = absint($fma_oow_selected_product_id);
			if (!$fma_oow_selected_product_id || get_the_ID() === $fma_oow_selected_product_id) {
				continue;
			}

			$fma_oow_selected_product = wc_get_product($fma_oow_selected_product_id);
			if ($fma_oow_selected_product && $fma_oow_selected_product->is_type('variation') && get_the_ID() === $fma_oow_selected_product->get_parent_id()) {
				$fma_oow_selected_variation_ids[] = $fma_oow_selected_product_id;
			}
		}
	}
	// show share btn on product page or not
	$fma_oow_show_share_btn_or_not = fma_oow_show_share_btn_or_not();
	$fma_order_on_whatsapp_hide_on_desktop = '';
	$whatsapp_btn_border_clr_hash = get_option('whatsapp_btn_border_clr_hash');
	$whatsapp_btn_border_clr_width = get_option('whatsapp_btn_border_clr_width');
	if (empty($whatsapp_btn_border_clr_hash)) {
		$whatsapp_btn_border_clr_hash = '#25d366';
	}
	if (empty($whatsapp_btn_border_clr_width)) {
		$whatsapp_btn_border_clr_width = 0;
	}
	$share_btn_border_clr_hash = get_option('share_btn_border_clr_hash');
	$share_btn_border_clr_width = get_option('share_btn_border_clr_width');
	if (empty($share_btn_border_clr_hash)) {
		$share_btn_border_clr_hash = '#25d366';
	}
	if (empty($share_btn_border_clr_width)) {
		$share_btn_border_clr_width = 0;
	}
	if (empty($fma_order_on_whatsapp_cart_btn_bg_color)) {
		$fma_order_on_whatsapp_cart_btn_bg_color = '#25d366';
	}
	if (empty($fma_order_on_whatsapp_cart_btn_text_color_hash)) {
		$fma_order_on_whatsapp_cart_btn_text_color_hash = '#ffff';
	}
	// BG color for share button
	if (empty($fma_oow_share_btn_bg_color)) {
		$fma_oow_share_btn_bg_color = '#25d366';
	}
	// text color for share button
	if (empty($fma_oow_share_btn_text_color)) {
		$fma_oow_share_btn_text_color = '#ffff';
	}
	$whatsAppAndShareButtonProdPage = '';
		$whatsAppAndShareButtonProdPage = "<input type='hidden' value='" . esc_attr(fma_oow_get_share_currency_symbol()) . "'
		id='fma_oow_get_currency_symbol'>";

	// include 'fma-order-on-whatsapp-find-device.php'; // this file contains the function to find the device
	$fma_find_the_device = fma_order_on_whatsapp_find_device(); // call the function
	$fma_oow_where_to_open_whatsapp = fma_oow_open_whatsapp_in_which_tab(); // where to open whatsapp
	// find the user browser
	if ('api' == $fma_find_the_device) {
		// mobile
		$fma_oow_mbl_or_dsktp = 'api';
	} else {
		// desktop
		$fma_oow_mbl_or_dsktp = 'web';
		if (!empty($fma_order_on_whatsa_button_on_desktop) && 'yes' == $fma_order_on_whatsa_button_on_desktop) {
			$fma_order_on_whatsapp_hide_on_desktop = 'none !important';
		}
	}
	// <!-- apply for all products -->
	if ('yes' == $fma_oow_apply_on_all_products) {
		$fma_order_on_whatsapp_number = get_option('fma_order_on_whatsapp_whatsapp_number', true);
		// <!-- whatsapp number -->
		$whatsAppAndShareButtonProdPage .= "<input type='hidden' id='whatsapp_number_variable_product'
			value='" . esc_attr($fma_order_on_whatsapp_number) . "'>
		<span id='hidden_quantity' style='display: none;'>";
			// <!-- onclick attach quantity here -->
			$whatsAppAndShareButtonProdPage .= "<input type='hidden' id='product_id_whatsapp' value='" . esc_attr(get_the_ID()) . "'>
			<input type='hidden' id='product_price_whatsapp_simple' value='" . esc_attr($product->get_price()) . "'>
			<input type='hidden' id='fma_order_on_whatsapp_whatsapp_number'
				value='" . esc_attr($fma_order_on_whatsapp_number) . "'>
		</span>";
		// <!-- for simple -->
		if ('simple' == $fma_order_on_whatsapp_product_type) {
			$fma_oow_show_product_whatsapp_btn = ( 'yes' == $fma_order_on_whatsapp_show_on_shop_page );
			$fma_oow_show_product_share_btn    = ( 'yes' == $fma_oow_show_share_btn_or_not && 'yes' == $fma_order_on_whatsapp_share_show_btn_on_single_product );
			if ( $fma_oow_show_product_whatsapp_btn || $fma_oow_show_product_share_btn ) {
				$whatsAppAndShareButtonProdPage .= "<div class='fma_oow_btns fma_oow_btns_product_pg'>";
			}
			// <!-- whatsapp button  -->
			if ( $fma_oow_show_product_whatsapp_btn ) {
				$whatsAppAndShareButtonProdPage .= "<a class='whatsapp_link_variable button unset-style'>
					<div class='call-icon wal whatsapp_contact'
						style='" . esc_attr(fma_oow_get_whatsapp_button_inline_style('product')) . "'>
						<span class='fma_oow_icon'>" . 
							filter_var(fma_oow_get_icon_url($fma_oow_selected_icon)) . 
						"</span>
						<span id='fma_order_on_whatsapp_span'>" . 
							esc_html($fma_order_on_whatsapp_button_text) . 
						'</span>
					</div>
				</a>';
			}
			// <!-- share button -->
			if ( $fma_oow_show_product_share_btn ) {
				$whatsAppAndShareButtonProdPage .= fma_oow_share_buttons_br_tag() . "
				<style type='text/css' media='screen'>
					.fma_oow_share_btn:before {
						color:" . 
						 esc_attr($fma_oow_share_btn_text_color) . ';
					}
				</style>';
				$whatsAppAndShareButtonProdPage .= "<a class='fma_oow_share_btn fma_oow_share_btn_product_pg'
					style='" . esc_attr(fma_oow_get_share_button_inline_style('product')) . "'
					target='" . esc_attr($fma_oow_where_to_open_whatsapp) . "'
					href='" . fma_oow_esc_whatsapp_send_url($fma_oow_product_share_url) . "'><span
						class='fma_oow_btn_shop_pg'>" .
						 esc_html(sanitize_text_field($fma_oow_share_btn_txt)) . 
					'</span></a>';
			}
			if ( $fma_oow_show_product_whatsapp_btn || $fma_oow_show_product_share_btn ) {
				$whatsAppAndShareButtonProdPage .= '</div>';
			}
			// <!-- share button ends  -->
		} elseif ('variable' == $fma_order_on_whatsapp_product_type) {
			$fma_oow_show_product_whatsapp_btn = ( 'yes' == $fma_order_on_whatsapp_show_on_shop_page );
			$fma_oow_show_product_share_btn    = ( 'yes' == $fma_oow_show_share_btn_or_not && 'yes' == $fma_order_on_whatsapp_share_show_btn_on_single_product );
			if ( $fma_oow_show_product_whatsapp_btn || $fma_oow_show_product_share_btn ) {
				$whatsAppAndShareButtonProdPage .= "<div class='fma_oow_btns fma_oow_btns_product_pg'>";
			}
			// <!-- whatsapp button  -->
			if ( $fma_oow_show_product_whatsapp_btn ) {
				$whatsAppAndShareButtonProdPage .= "<button target='" . esc_attr($fma_oow_where_to_open_whatsapp) . ";'
					style='display: " . esc_attr($fma_order_on_whatsapp_hide_on_desktop) . ";'
					class='button unset-style btn-stickycall whatsapp_link whatsapp_link_variable' id=''>
					<div class='call-icon wal  whatsapp_contact'
						style='" . esc_attr(fma_oow_get_whatsapp_button_inline_style('product')) . "'>
						<span class='fma_oow_icon'>" . 
							filter_var(fma_oow_get_icon_url($fma_oow_selected_icon)) . 
						"</span>
						<span id='fma_order_on_whatsapp_span_variable'>" .
							esc_html($fma_order_on_whatsapp_button_text) . 
						'</span>
					</div>
				</button>';
			}
			// <!-- share button -->
			if ( $fma_oow_show_product_share_btn ) {
				$whatsAppAndShareButtonProdPage .= "<input type='hidden' id='fma_oow_share_msg_when_whatsap_opens'
					value='" . esc_attr(sanitize_text_field($fma_oow_share_msg_when_whatsap_opens)) . "'>
				" . fma_oow_share_buttons_br_tag() . "
				<a class=' fma_oow_share_btn fma_oow_share_btn_product_pg'
					style='" . esc_attr(fma_oow_get_share_button_inline_style('product')) . "'
					target='" . esc_attr($fma_oow_where_to_open_whatsapp) . "'
					href='" . fma_oow_esc_whatsapp_send_url($fma_oow_product_share_url) . "'><span
						class='fma_oow_btn_shop_pg'>" . 
						 esc_html(sanitize_text_field($fma_oow_share_btn_txt)) .
					'</span></a>';
			}
			if ( $fma_oow_show_product_whatsapp_btn || $fma_oow_show_product_share_btn ) {
				$whatsAppAndShareButtonProdPage .= '</div>';
			}
		}
	} elseif ('simple' == $fma_order_on_whatsapp_product_type) {
		global $product; 
		$whatsAppAndShareButtonProdPage .= "<span id='hidden_quantity'>";
			// <!-- onclick attach quantity here -->
			$whatsAppAndShareButtonProdPage .= "<input type='hidden' id='product_id_whatsapp' value='" . esc_attr(get_the_ID()) . "'>
			<input type='hidden' id='product_price_whatsapp_simple' value='" . esc_attr($product->get_price()) . "'>
			<input type='hidden' id='fma_order_on_whatsapp_whatsapp_number'
				value='" . esc_attr($fma_order_on_whatsapp_number) . "'>
		</span>";
		// <!-- if the products list radio is checked, or by default , then show button on products based -->

		if ('fma_order_on_whatsapp_products_list' == $fma_order_on_whatsapp_either_products_or_cats) { //Default is fma_order_on_whatsapp_products_list
			$fma_order_on_whatsapp_quantity_text = 'Quantity: ';
			// don't show the button until there is not button and products list
			if (!empty($fma_order_on_whatsapp_number) && is_array($fma_order_on_whatsapp_products_list) && in_array(get_the_ID(), $fma_order_on_whatsapp_products_list)) {
				$whatsAppAndShareButtonProdPage .= "<div class='fma_oow_btns fma_oow_btns_product_pg'>";

				   // <!-- whatsapp button -->
				if ('yes' === $fma_order_on_whatsapp_show_on_single_product_page_or_not) {
					$whatsAppAndShareButtonProdPage .= "<a style='display: " . esc_attr($fma_order_on_whatsapp_hide_on_desktop) . "'
							class='btn-stickycall whatsapp_link whatsapp_link_variable'>
							<div class='call-icon wal whatsapp_contact'
								style='" . esc_attr(fma_oow_get_whatsapp_button_inline_style('product')) . ";'>
								<span class='fma_oow_icon'>" .
							  filter_var(fma_oow_get_icon_url($fma_oow_selected_icon)) .
						  "</span>
								<span id='fma_order_on_whatsapp_span'>" .
							  esc_html($fma_order_on_whatsapp_button_text) .
						  '</span>
							</div>
						</a>';
				}
				   // <!-- share button -->
				if ('yes' == $fma_oow_show_share_btn_or_not && 'yes' == $fma_order_on_whatsapp_share_show_btn_on_single_product) {
					$whatsAppAndShareButtonProdPage .= fma_oow_share_buttons_br_tag() . "
						<a class=' fma_oow_share_btn fma_oow_share_btn_product_pg'
							style='" . esc_attr(fma_oow_get_share_button_inline_style('product')) . "'
							target='" . esc_attr($fma_oow_where_to_open_whatsapp) . "'
							href='" . fma_oow_esc_whatsapp_send_url($fma_oow_product_share_url) . "'><span
								class='fma_oow_btn_shop_pg'>" .
						   esc_html(sanitize_text_field($fma_oow_share_btn_txt)) .
					   '</span></a>';
				}
				   // <!-- share button ends  -->
				$whatsAppAndShareButtonProdPage .= '</div>';
			}
		} else if ('categories' == $fma_order_on_whatsapp_either_products_or_cats) {
			if (! empty($fma_order_on_whatsapp_categories_list) && is_array($fma_order_on_whatsapp_categories_list) && fmaOowCheckProductOrCategoryPresentInList($fma_order_on_whatsapp_either_products_or_cats, get_the_ID(), $fma_order_on_whatsapp_categories_list)) {
				$fma_oow_show_product_whatsapp_btn = ( 'yes' === $fma_order_on_whatsapp_show_on_single_product_page_or_not );
				$fma_oow_show_product_share_btn    = ( 'yes' == $fma_oow_show_share_btn_or_not && 'yes' == $fma_order_on_whatsapp_share_show_btn_on_single_product );
				if ( $fma_oow_show_product_whatsapp_btn || $fma_oow_show_product_share_btn ) {
					$whatsAppAndShareButtonProdPage .= "<div class='fma_oow_btns fma_oow_btns_product_pg'>";
				}
				if ( $fma_oow_show_product_whatsapp_btn ) {
						// <!-- whatsapp button  -->
						$whatsAppAndShareButtonProdPage .= "<a style='display: " . esc_attr($fma_order_on_whatsapp_hide_on_desktop) . ";'
							class=' btn-stickycall whatsapp_link whatsapp_link_variable'>
							<div class='call-icon wal  whatsapp_contact'
								style='" . esc_attr(fma_oow_get_whatsapp_button_inline_style('product')) . "'>
								<span class='fma_oow_icon'>" .
								 filter_var(fma_oow_get_icon_url($fma_oow_selected_icon)) . 
								"</span>
								<span id='fma_order_on_whatsapp_span'>" .
								 esc_html($fma_order_on_whatsapp_button_text) . 
								'</span>
							</div>
						</a>';
				}
				// <!-- share button -->
				if ( $fma_oow_show_product_share_btn ) {
						$whatsAppAndShareButtonProdPage .= fma_oow_share_buttons_br_tag() . "
						<a class='fma_oow_share_btn fma_oow_share_btn_product_pg'
							style='" . esc_attr(fma_oow_get_share_button_inline_style('product')) . "'
							target='" . esc_attr($fma_oow_where_to_open_whatsapp) . "'
							href='" . fma_oow_esc_whatsapp_send_url($fma_oow_product_share_url) . "'><span
								class='fma_oow_btn_shop_pg'>" .
							 esc_html(sanitize_text_field($fma_oow_share_btn_txt)) . 
							'</span></a>';
				}
				if ( $fma_oow_show_product_whatsapp_btn || $fma_oow_show_product_share_btn ) {
					$whatsAppAndShareButtonProdPage .= '</div>';
				}
			}
		}
		// <!-- For Variable Product -->
	} elseif ('variable' == $fma_order_on_whatsapp_product_type || 'grouped' == $fma_order_on_whatsapp_product_type) {
		$fma_order_on_whatsapp_number = get_option('fma_order_on_whatsapp_whatsapp_number', true);

		$whatsAppAndShareButtonProdPage .= "<input type='hidden' id='whatsapp_number_variable_product'
			value='" . esc_attr($fma_order_on_whatsapp_number) . "'>";

		// find the user browser
		if ('api' == $fma_find_the_device) {
			// mobile
			$fma_oow_mbl_or_dsktp = 'api';
		} else {
			// desktop
			$fma_oow_mbl_or_dsktp = 'web';
			if (!empty($fma_order_on_whatsa_button_on_desktop) && 'yes' == $fma_order_on_whatsa_button_on_desktop) {
				$fma_order_on_whatsapp_hide_on_desktop = 'none !important';
			}
		}

		if ('fma_order_on_whatsapp_products_list' == $fma_order_on_whatsapp_either_products_or_cats) { //Default is fma_order_on_whatsapp_products_list
			// <!-- don't show the button until there is not button and products list -->
			if (!empty($fma_order_on_whatsapp_products_list)) {
				$fma_oow_parent_product_selected = is_array($fma_order_on_whatsapp_products_list) && in_array(get_the_ID(), $fma_order_on_whatsapp_products_list);
				$fma_oow_has_selected_variations = !empty($fma_oow_selected_variation_ids);

				if (!empty($fma_order_on_whatsapp_number) && is_array($fma_order_on_whatsapp_products_list) && ( $fma_oow_parent_product_selected || $fma_oow_has_selected_variations )) {
					$fma_oow_show_product_whatsapp_btn = ( 'yes' === $fma_order_on_whatsapp_show_on_single_product_page_or_not );
					$fma_oow_show_product_share_btn    = ( 'yes' == $fma_oow_show_share_btn_or_not && 'yes' == $fma_order_on_whatsapp_share_show_btn_on_single_product );
					if ( $fma_oow_show_product_whatsapp_btn || $fma_oow_show_product_share_btn ) {
						$fma_oow_variation_wrapper_data  = $fma_oow_has_selected_variations ? " data-fma-oow-selected-variation-ids='" . esc_attr(implode(',', $fma_oow_selected_variation_ids)) . "' data-fma-oow-parent-product-selected='" . esc_attr($fma_oow_parent_product_selected ? '1' : '0') . "'" : '';
						$fma_oow_variation_wrapper_style = $fma_oow_parent_product_selected ? '' : " style='display:none;'";
						$whatsAppAndShareButtonProdPage .= "<div class='fma_oow_btns fma_oow_btns_product_pg'" . $fma_oow_variation_wrapper_data . $fma_oow_variation_wrapper_style . '>';
					}

					if ( $fma_oow_show_product_whatsapp_btn ) {
						// <!-- whatsapp button  -->
						$whatsAppAndShareButtonProdPage .= "<button	class='button unset-style btn-stickycall whatsapp_link whatsapp_link_variable' data-quantity='1'>
							<div class='call-icon wal  whatsapp_contact'
								style='" . esc_attr(fma_oow_get_whatsapp_button_inline_style('product', 'display:' . $fma_order_on_whatsapp_hide_on_desktop)) . "'>
								<span class='fma_oow_icon'>" .
									 filter_var(fma_oow_get_icon_url($fma_oow_selected_icon)) . 
								"</span>
								<span id='fma_order_on_whatsapp_span_variable'>" . 
									esc_html($fma_order_on_whatsapp_button_text) . 
								'</span>
							</div>
						</button>';
					}
					// <!-- share button -->
					if ( $fma_oow_show_product_share_btn ) {
						$whatsAppAndShareButtonProdPage .= fma_oow_share_buttons_br_tag() . "
						<input type='hidden' id='fma_oow_share_msg_when_whatsap_opens'
					value='" . esc_attr(sanitize_text_field($fma_oow_share_msg_when_whatsap_opens)) . "'>
						<a class=' fma_oow_share_btn fma_oow_share_btn_product_pg'
							style='" . esc_attr(fma_oow_get_share_button_inline_style('product')) . "'
							target='" . esc_html($fma_oow_where_to_open_whatsapp) . "'
							href='" . fma_oow_esc_whatsapp_send_url($fma_oow_product_share_url) . "'><span
								class='fma_oow_btn_shop_pg'>" . 
								 esc_html(sanitize_text_field($fma_oow_share_btn_txt)) . 
							'</span></a>';
					}
					if ( $fma_oow_show_product_whatsapp_btn || $fma_oow_show_product_share_btn ) {
						$whatsAppAndShareButtonProdPage .= '</div>';
					}
				}
			}
		} else if ('categories' == $fma_order_on_whatsapp_either_products_or_cats) {
			if (! empty($fma_order_on_whatsapp_categories_list) && is_array($fma_order_on_whatsapp_categories_list) && fmaOowCheckProductOrCategoryPresentInList($fma_order_on_whatsapp_either_products_or_cats, get_the_ID(), $fma_order_on_whatsapp_categories_list)) {
				$fma_oow_show_product_whatsapp_btn = ( 'yes' === $fma_order_on_whatsapp_show_on_single_product_page_or_not );
				$fma_oow_show_product_share_btn    = ( 'yes' == $fma_oow_show_share_btn_or_not && 'yes' == $fma_order_on_whatsapp_share_show_btn_on_single_product );
				if ( $fma_oow_show_product_whatsapp_btn || $fma_oow_show_product_share_btn ) {
					$whatsAppAndShareButtonProdPage .= "<div class='fma_oow_btns fma_oow_btns_product_pg'>";
				}
				if ( $fma_oow_show_product_whatsapp_btn ) {
						// <!-- whatsapp button  -->
						$whatsAppAndShareButtonProdPage .= "<button class='unset-style btn-stickycall whatsapp_link whatsapp_link_variable'>
							<div class='call-icon wal  whatsapp_contact' style='" . esc_attr(fma_oow_get_whatsapp_button_inline_style('product', 'display:' . $fma_order_on_whatsapp_hide_on_desktop)) . "'>
								<span class='fma_oow_icon'>" .
								 filter_var(fma_oow_get_icon_url($fma_oow_selected_icon)) .
								"</span>
								<span id='fma_order_on_whatsapp_span_variable'>" .
								  esc_html($fma_order_on_whatsapp_button_text) . 
								'</span>
							</div>
						</button>';
				}
				// <!-- share button -->
				if ( $fma_oow_show_product_share_btn ) {
						$whatsAppAndShareButtonProdPage .= fma_oow_share_buttons_br_tag() . "
						<input type='hidden' id='fma_oow_share_msg_when_whatsap_opens'
					value='" . esc_attr(sanitize_text_field($fma_oow_share_msg_when_whatsap_opens)) . "'>
						<a class='fma_oow_share_btn fma_oow_share_btn_product_pg'
							style='" . esc_attr(fma_oow_get_share_button_inline_style('product')) . "'
							target='" . esc_attr($fma_oow_where_to_open_whatsapp) . "'
							href='" . fma_oow_esc_whatsapp_send_url($fma_oow_product_share_url) . "'><span
								class='fma_oow_btn_shop_pg'>" . 
							 esc_html(sanitize_text_field($fma_oow_share_btn_txt)) . 
							'</span></a>';
				}
				if ( $fma_oow_show_product_whatsapp_btn || $fma_oow_show_product_share_btn ) {
					$whatsAppAndShareButtonProdPage .= '</div>';
				}
			}
		}
	}

	return $whatsAppAndShareButtonProdPage;
}