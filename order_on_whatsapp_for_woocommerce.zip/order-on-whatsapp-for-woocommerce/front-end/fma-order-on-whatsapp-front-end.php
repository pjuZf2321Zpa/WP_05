<?php
// include the function
include 'fma-order-on-whatsapp-find-device.php'; // this file contains the function to find the device
include 'fma-get-icons.php';
include 'fme-oow-notifications.php';
$fma_oow_icons_urls = array( FMA_OOW_PLUGIN_URL . 'admin/icons/icon1.svg', FMA_OOW_PLUGIN_URL . 'admin/icons/icon2.svg', FMA_OOW_PLUGIN_URL . 'admin/icons/icon3.svg', FMA_OOW_PLUGIN_URL . 'admin/icons/icon4.svg' );
// file where button's html function exist
include 'fma-oow-whatsApp-and-share-button.php';
$theme = wp_get_theme(); // gets the current theme
add_action('wp_footer', 'fmaChecCartPage');
add_action('elementor/frontend/after_enqueue_styles', 'fmeEnqueueCustomElementorStyles');

/**
 * Whether the current single product passes plugin product/category targeting.
 *
 * @return int 1 when targeted, 0 otherwise.
 */
function fma_oow_get_product_targeting_flag() {
	static $flag = null;
	if (null !== $flag) {
		return $flag;
	}
	$flag = 0;
	$fma_oow_apply_on_all_products = get_option('fma_oow_apply_on_all_products') ?? 'no';
	if ('yes' == $fma_oow_apply_on_all_products) {
		$flag = 1;
		return $flag;
	}
	$fmaOowEitherProductsOrCats = get_option('fma_order_on_whatsapp_either_products_or_cats', true);
	$fma_order_on_whatsapp_selected_products_list = get_option('fma_order_on_whatsapp_products_list');
	$fma_order_on_whatsapp_categories_list = get_option('fma_order_on_whatsapp_categories_list');
	if ('fma_order_on_whatsapp_products_list' == $fmaOowEitherProductsOrCats && !empty($fma_order_on_whatsapp_selected_products_list)) {
		$flag = fmaOowCheckProductOrCategoryPresentInList($fmaOowEitherProductsOrCats, get_the_ID(), $fma_order_on_whatsapp_selected_products_list);
		if (0 == $flag && fma_oow_current_product_has_selected_variations($fma_order_on_whatsapp_selected_products_list)) {
			$flag = 1;
		}
	} elseif ('categories' == $fmaOowEitherProductsOrCats && !empty($fma_order_on_whatsapp_categories_list)) {
		$flag = fmaOowCheckProductOrCategoryPresentInList($fmaOowEitherProductsOrCats, get_the_ID(), $fma_order_on_whatsapp_categories_list);
	}
	return $flag;
}

/**
 * Whether the current product has saved variation IDs in the product targeting list.
 *
 * @param array $selected_products Saved product/variation IDs.
 * @return bool
 */
function fma_oow_current_product_has_selected_variations( $selected_products ) {
	if (!is_product() || !is_array($selected_products)) {
		return false;
	}

	$product = wc_get_product(get_the_ID());
	if (!$product || !$product->is_type('variable')) {
		return false;
	}

	foreach ($selected_products as $selected_product_id) {
		$selected_product_id = absint($selected_product_id);
		if (!$selected_product_id || get_the_ID() === $selected_product_id) {
			continue;
		}

		$selected_product = wc_get_product($selected_product_id);
		if ($selected_product && $selected_product->is_type('variation') && get_the_ID() === $selected_product->get_parent_id()) {
			return true;
		}
	}

	return false;
}

/**
 * Shop archives may render WhatsApp buttons when targeting lists or apply-all is configured.
 *
 * @return bool
 */
function fma_oow_shop_archive_may_show_buttons() {
	$fma_order_on_whatsapp_show_on_shop_page = get_option('fma_order_on_whatsapp_show_on_shop_page', true);
	if ('yes' !== $fma_order_on_whatsapp_show_on_shop_page) {
		return false;
	}
	if ('yes' === get_option('fma_oow_apply_on_all_products', 'no')) {
		return true;
	}
	$fmaOowEitherProductsOrCats = get_option('fma_order_on_whatsapp_either_products_or_cats', true);
	if ('fma_order_on_whatsapp_products_list' === $fmaOowEitherProductsOrCats) {
		$list = get_option('fma_order_on_whatsapp_products_list');
		return !empty($list);
	}
	if ('categories' === $fmaOowEitherProductsOrCats) {
		$list = get_option('fma_order_on_whatsapp_categories_list');
		return !empty($list);
	}
	return false;
}

/**
 * Whether the current page is built with Elementor.
 *
 * @return bool
 */
function fma_oow_is_elementor_context_page() {
	$post_id = get_the_ID();
	return is_elementor_page($post_id) || is_elementor_post($post_id) || contains_elementor_content($post_id);
}

/**
 * Whether the current page content includes the WhatsApp shortcode.
 *
 * @return bool
 */
function fma_oow_current_page_has_whatsapp_shortcode() {
	$post = get_post();
	return ( $post && has_shortcode($post->post_content, 'fma_whatapp_button') );
}

/**
 * Whether frontend JS/CSS should load on the current request.
 *
 * @return bool
 */
function fma_oow_should_enqueue_frontend_assets() {
	if (is_cart() || is_checkout()) {
		return true;
	}
	if (function_exists('has_block') && has_block('woocommerce/cart')) {
		return true;
	}
	if (is_product()) {
		return 1 == fma_oow_get_product_targeting_flag();
	}
	if (is_shop() || is_product_category() || is_product_tag() || is_product_taxonomy()) {
		return fma_oow_shop_archive_may_show_buttons();
	}
	if (is_front_page() && fma_oow_is_elementor_context_page() && fma_oow_shop_archive_may_show_buttons()) {
		return true;
	}
	if (fma_oow_current_page_has_whatsapp_shortcode()) {
		return true;
	}
	return false;
}

/**
 * Track whether WhatsApp button wrappers were output during this request.
 *
 * @param bool|null $mark When true, record that buttons were rendered.
 * @return bool
 */
function fma_oow_checkout_popup_buttons_rendered_state( $mark = false ) {
	static $rendered = false;
	if ($mark) {
		$rendered = true;
	}
	return $rendered;
}

/**
 * Record that at least one WhatsApp button wrapper was output during this request.
 *
 * @return void
 */
function fma_oow_mark_checkout_popup_buttons_rendered() {
	fma_oow_checkout_popup_buttons_rendered_state(true);
}

/**
 * Whether any WhatsApp button wrapper was output during this request.
 *
 * @return bool
 */
function fma_oow_checkout_popup_buttons_were_rendered() {
	return fma_oow_checkout_popup_buttons_rendered_state();
}

/**
 * Whether the current request is a WooCommerce shop archive.
 *
 * @return bool
 */
function fma_oow_is_shop_archive_context() {
	return is_shop() || is_product_category() || is_product_tag() || is_product_taxonomy();
}

/**
 * Whether the checkout popup shell should be preloaded in the footer.
 *
 * @return bool
 */
function fma_oow_should_preload_checkout_popup() {
	if (is_checkout() || is_cart()) {
		return false;
	}
	if (is_product() && 1 == fma_oow_get_product_targeting_flag()) {
		return true;
	}
	if (fma_oow_is_shop_archive_context() && fma_oow_checkout_popup_buttons_were_rendered()) {
		return true;
	}
	if (is_front_page() && fma_oow_is_elementor_context_page() && fma_oow_checkout_popup_buttons_were_rendered()) {
		return true;
	}
	if (fma_oow_current_page_has_whatsapp_shortcode()) {
		return true;
	}
	return false;
}

/**
 * Added checkout popup in footer
 *
 * @return void
 */
function fmaChecCartPage() {
	if (!fma_oow_should_preload_checkout_popup()) {
		return;
	}
	include 'views/fma-oow-checkout-popup-html.php';
}

add_action('wp_enqueue_scripts', 'fma_order_on_whatsapp_load_my_files_whatsapp_admin', 99); // to load files
add_action('wp_enqueue_scripts', 'fma_oow_finalize_block_cart_checkout_scripts', 101);
add_action('init', 'fma_oow_register_button_inline_styles');
add_filter('body_class', 'fma_oow_add_inline_buttons_body_class');
add_filter('body_class', 'fma_oow_add_hide_atc_product_body_class');
add_action('wp_head', 'custom_icons_css', 999);
// this hook is must
// woocommerce_before_add_to_cart_quantity // for before add to cart
add_action(fmaWhereToPlaceWhatsAppBtnsOnProductPage(), 'fmawhatsappButtonProductPage'); // front-end
add_action('woocommerce_cart_collaterals', 'fmaWhatsappButtonOnCrtPage'); // front end
// add_action( 'woocommerce_proceed_to_checkout', 'fmaWhatsappButtonOnCrtPage', 999 );
add_action('woocommerce_review_order_before_submit', 'fma_order_on_whatsapp_whatsapp_button_on_checkout_page'); //front end
if (true === $theme->is_block_theme()) {
	// whatsapp and share button on shop page for block themes
	add_filter('woocommerce_loop_add_to_cart_link', 'fmaOowWhatsAppButtonOnBlockShopPage', 10, 3);
	// add_filter('woocommerce_loop_add_to_cart_link','fma_oow_add_to_cart_btn');
} else {
	// to make whatsapp button after add to cart, change the priority to 99 , on shop page
	add_action('woocommerce_after_shop_loop_item', 'fma_order_on_whatsapp_whatsapp_button_on_shop_page', fma_oow_where_to_place_btns_on_shop_page()); // front end
}
add_action('wp', 'fma_oow_register_loop_add_to_cart_removals');
add_action('woocommerce_shop_loop_item_title', 'fma_order_on_whatsapp_remove_add_to_cart_button_from_shop_page');
add_action('woocommerce_before_add_to_cart_button', 'fma_order_on_whatsapp_remove_add_to_cart_button_from_product_page', 9);
add_action('woocommerce_before_add_to_cart_button', 'fma_oow_remove_add_to_cart_btn_product_page_when_all_products_selected', 9);
add_action('woocommerce_shop_loop_item_title', 'fma_oow_remove_add_to_cart_shop_page_when_all_products_selected');
add_action('woocommerce_checkout_update_order_meta', 'fme_oow_update_order_meta');
add_action('woocommerce_thankyou', 'fme_redirect_to_whatsapp', 10, 1);
add_action('wp_ajax_when_place_order_clicked', 'fma_order_on_whatsapp_when_place_order_clicked');
add_action('wp_ajax_nopriv_when_place_order_clicked', 'fma_order_on_whatsapp_when_place_order_clicked');
add_action('wp_ajax_show_checkout_popup', 'show_checkout_popup');
add_action('wp_ajax_nopriv_show_checkout_popup', 'show_checkout_popup');
// End of Actions

/**
 * Show checkout popup on WhatsApp button click
 *
 * @return array
 */
function show_checkout_popup() {
	check_ajax_referer('front_ajax_nonce', 'security');
	$fma_prdt_id = 0;
	$fma_varition_id = 0;
	$fma_prdt_qty = 1;

	if (isset($_REQUEST['product_id'])) {
		$fma_prdt_id = sanitize_text_field($_REQUEST['product_id']);
	}
	if (isset($_REQUEST['variation_id'])) {
		$fma_varition_id = sanitize_text_field($_REQUEST['variation_id']);
	}
	if (isset($_REQUEST['qunatity'])) {
		$fma_prdt_qty = sanitize_text_field($_REQUEST['qunatity']);
	}
	/////////////////////////////// ADDED BY SAQIB ///////////////////////////////
	if (0 == $fma_prdt_id && 0 < $fma_varition_id) {
		$product = wc_get_product($fma_varition_id);
		$fma_prdt_id = $product->get_parent_id();
	}
	/////////////////////////////// ADDED BY SAQIB ///////////////////////////////
	WC()->cart->add_to_cart($fma_prdt_id, $fma_prdt_qty, $fma_varition_id);

	wp_send_json(fma_oow_build_checkout_popup_ajax_data());
}

/**
 * Set Priority to display button on shop page
 *
 * @return int
 */
function fma_oow_where_to_place_btns_on_shop_page() {
	$fma_oow_priority_value = '';
	$fma_oow_where_to_place_whatsp_btn = get_option('fma_oow_where_to_place_whatsp_btn');
	if ('fma_oow_after_add_to_cart' == $fma_oow_where_to_place_whatsp_btn) {
		$fma_oow_priority_value = 99;
	}
	return $fma_oow_priority_value;
}

/**
 * Place the buttons BEFORE or AFTER add to cart on PRODUCT page
 *
 * @return string
 */
function fmaWhereToPlaceWhatsAppBtnsOnProductPage() {
	$fma_oow_hook_name = 'woocommerce_after_add_to_cart_form';
	$fma_oow_where_to_place_whatsp_btn = get_option('fma_oow_where_to_place_whatsp_btn');
	if ('fma_oow_before_add_to_cart' == $fma_oow_where_to_place_whatsp_btn) {
		$fma_oow_hook_name = 'woocommerce_before_add_to_cart_form';
	}
	return $fma_oow_hook_name;
}

/**
 * Show share button or not
 *
 * @return string
 */
function fma_oow_show_share_btn_or_not() {
	$fma_oow_share_btn = get_option('fma_oow_share_btn');
	return $fma_oow_share_btn;
}

/**
 * Set tab target (blank or same)
 *
 * @return string
 */
function fma_oow_open_whatsapp_in_which_tab() {
	$fma_oow_open_whatsapp_in_which_tab = get_option('fma_oow_open_whatsapp_in_which_tab', 'oow_in_new_tab');
	if ('oow_in_new_tab' == $fma_oow_open_whatsapp_in_which_tab) {
		$fma_oow_new_or_same_tab = '_blank'; // open in new tab
	} elseif ('oow_in_same_tab' == $fma_oow_open_whatsapp_in_which_tab) {
		$fma_oow_new_or_same_tab = ''; // open in same tab
	}
	return $fma_oow_new_or_same_tab;
}

/**
 * Build padding CSS from a serialized admin option.
 *
 * @param string $option_name Option key.
 * @param array  $defaults    Default px values keyed by top/right/bottom/left.
 * @return string
 */
function fma_oow_build_padding_style( $option_name, $defaults = array() ) {
	$defaults = wp_parse_args(
		$defaults,
		array(
			'top'    => '5',
			'bottom' => '5',
			'left'   => '8',
			'right'  => '8',
		)
	);
	$padding  = maybe_unserialize(get_option($option_name));
	if (!is_array($padding)) {
		$padding = array();
	}

	$parts = array();
	foreach (array( 'top', 'right', 'bottom', 'left' ) as $side) {
		$value   = ( isset($padding[ $side ]) && '' !== $padding[ $side ] ) ? absint($padding[ $side ]) : absint($defaults[ $side ]);
		$parts[] = 'padding-' . $side . ':' . $value . 'px !important';
	}

	return implode(';', $parts);
}

/**
 * Build border-radius CSS from a serialized admin option.
 *
 * @param string $option_name Option key.
 * @return string
 */
function fma_oow_build_border_radius_style( $option_name ) {
	$radius = maybe_unserialize(get_option($option_name));
	if (!is_array($radius)) {
		return '';
	}

	$map = array(
		'top'    => 'border-top-left-radius',
		'bottom' => 'border-top-right-radius',
		'left'   => 'border-bottom-left-radius',
		'right'  => 'border-bottom-right-radius',
	);

	$parts = array();
	foreach ($map as $key => $property) {
		if (isset($radius[ $key ]) && '' !== $radius[ $key ]) {
			$parts[] = $property . ':' . absint($radius[ $key ]) . 'px !important';
		}
	}

	return implode(';', $parts);
}

/**
 * Return complete inline style for WhatsApp buttons (shop, product, or cart).
 *
 * @param string $context Page context: shop, product, or cart.
 * @param string $extra   Additional CSS declarations (e.g. display:none).
 * @return string
 */
function fma_oow_get_whatsapp_button_inline_style( $context = 'shop', $extra = '' ) {
	$context = in_array($context, array( 'shop', 'product', 'cart' ), true) ? $context : 'shop';

	$bg_color      = get_option('fma_order_on_whatsapp_cart_btn_bg_color_hash');
	$text_color    = get_option('fma_order_on_whatsapp_cart_btn_text_color_hash');
	$border_color  = get_option('whatsapp_btn_border_clr_hash');
	$border_width  = get_option('whatsapp_btn_border_clr_width');

	if (empty($bg_color)) {
		$bg_color = '#25d366';
	}
	if (empty($text_color)) {
		$text_color = '#ffff';
	}
	if (empty($border_color)) {
		$border_color = '#25d366';
	}
	if ('' === $border_width || null === $border_width) {
		$border_width = 0;
	}
	$border_width = absint($border_width);

	$width_option = '';
	if ('shop' === $context) {
		$width_option = get_option('fma_oow_shop_whatsapp_btn_width', '');
	} elseif ('product' === $context) {
		$width_option = get_option('fma_oow_prd_whatsapp_btn_width', '');
	} else {
		$width_option = get_option('fma_oow_cart_whatsapp_btn_width', '');
	}

	$parts = array(
		'display:inline-flex !important',
		'align-items:center',
		'justify-content:center',
		'box-sizing:border-box',
		'text-decoration:none !important',
		'cursor:pointer',
		'border:' . $border_width . 'px solid ' . $border_color . ' !important',
		'background-color:' . $bg_color . ' !important',
		'color:' . $text_color . ' !important',
		fma_oow_build_padding_style('fma_oow_whatsapp_button_padding'),
		fma_oow_build_border_radius_style('fma_oow_whatsapp_button_border_radius'),
		rtrim(fma_oow_build_button_width_css($width_option), ';'),
		'max-width:100% !important',
	);

	if ('' !== trim((string) $extra)) {
		$parts[] = trim((string) $extra, '; ');
	}

	return implode(';', array_filter($parts));
}

/**
 * Return complete inline style for Share buttons.
 *
 * @param string $context Page context: shop, product, or cart.
 * @param string $extra   Additional CSS declarations.
 * @return string
 */
function fma_oow_get_share_button_inline_style( $context = 'shop', $extra = '' ) {
	$context = in_array($context, array( 'shop', 'product', 'cart' ), true) ? $context : 'shop';

	$bg_color     = get_option('fma_oow_share_btn_bg_color');
	$text_color   = get_option('fma_oow_share_btn_text_color');
	$border_color = get_option('share_btn_border_clr_hash');
	$border_width = get_option('share_btn_border_clr_width');

	if (empty($bg_color)) {
		$bg_color = '#25d366';
	}
	if (empty($text_color)) {
		$text_color = '#ffff';
	}
	if (empty($border_color)) {
		$border_color = '#25d366';
	}
	if ('' === $border_width || null === $border_width) {
		$border_width = 0;
	}
	$border_width = absint($border_width);

	$width_option = '';
	if ('shop' === $context) {
		$width_option = get_option('fma_oow_shop_share_btn_width', '');
	} elseif ('product' === $context) {
		$width_option = get_option('fma_oow_prd_share_btn_width', '');
	} else {
		$width_option = get_option('fma_oow_cart_share_btn_width', '');
	}

	$parts = array(
		'display:inline-flex !important',
		'align-items:center',
		'justify-content:center',
		'box-sizing:border-box',
		'text-decoration:none !important',
		'cursor:pointer',
		'border:' . $border_width . 'px solid ' . $border_color . ' !important',
		'background-color:' . $bg_color . ' !important',
		'color:' . $text_color . ' !important',
		fma_oow_build_padding_style('fma_oow_share_button_padding'),
		fma_oow_build_border_radius_style('fma_oow_share_button_border_radius'),
		rtrim(fma_oow_build_button_width_css($width_option), ';'),
		'max-width:100% !important',
	);

	if ('' !== trim((string) $extra)) {
		$parts[] = trim((string) $extra, '; ');
	}

	return implode(';', array_filter($parts));
}

/**
 * Whether WhatsApp and Share buttons should display inline (side by side).
 *
 * @return bool
 */
function fma_oow_is_inline_buttons_enabled() {
	return 'on' === get_option('fma_oow_inline_whatsapp_share_buttons', 'no');
}

/**
 * Add body class when inline WhatsApp/Share buttons are enabled.
 *
 * @param array $classes Body classes.
 * @return array
 */
function fma_oow_add_inline_buttons_body_class( $classes ) {
	if (fma_oow_is_inline_buttons_enabled()) {
		$classes[] = 'fma-oow-buttons-inline';
	}
	return $classes;
}

/**
 * Add body class when product-page add-to-cart should be hidden (Woodmart CSS/JS gating).
 *
 * @param array $classes Body classes.
 * @return array
 */
function fma_oow_add_hide_atc_product_body_class( $classes ) {
	if (!is_product() || 'yes' !== get_option('fma_order_on_whatsapp_hide_add_to_cart_button_product_page')) {
		return $classes;
	}
	if ('yes' === get_option('fma_oow_apply_on_all_products')) {
		$classes[] = 'fma-oow-hide-atc-product';
		return $classes;
	}
	$fmaOowEitherProductsOrCats = get_option('fma_order_on_whatsapp_either_products_or_cats', true);
	$fma_order_on_whatsapp_selected_products_list = get_option('fma_order_on_whatsapp_products_list');
	$fma_order_on_whatsapp_categories_list = get_option('fma_order_on_whatsapp_categories_list');
	$fmaOowCheckProductOrCategoryPresentInList = 0;
	if ('fma_order_on_whatsapp_products_list' == $fmaOowEitherProductsOrCats && !empty($fma_order_on_whatsapp_selected_products_list)) {
		$fmaOowCheckProductOrCategoryPresentInList = fmaOowCheckProductOrCategoryPresentInList($fmaOowEitherProductsOrCats, get_the_ID(), $fma_order_on_whatsapp_selected_products_list);
	} elseif ('categories' == $fmaOowEitherProductsOrCats && !empty($fma_order_on_whatsapp_categories_list)) {
		$fmaOowCheckProductOrCategoryPresentInList = fmaOowCheckProductOrCategoryPresentInList($fmaOowEitherProductsOrCats, get_the_ID(), $fma_order_on_whatsapp_categories_list);
	}
	if (1 == $fmaOowCheckProductOrCategoryPresentInList) {
		$classes[] = 'fma-oow-hide-atc-product';
	}
	return $classes;
}

/**
 * Register storefront button padding/radius inline styles on wp_head (once on init).
 *
 * @return void
 */
function fma_oow_register_button_inline_styles() {
	if (is_admin()) {
		return;
	}
	add_action('wp_head', 'fma_oow_output_button_inline_styles', 998);
}

/**
 * Output dynamic button padding and border-radius CSS in the document head.
 *
 * @return void
 */
function fma_oow_output_button_inline_styles() {
	$fma_oow_whatsapp_button_padding = maybe_unserialize(get_option('fma_oow_whatsapp_button_padding'));
	$fma_oow_whatsapp_button_padding_top = isset($fma_oow_whatsapp_button_padding['top']) && '' != $fma_oow_whatsapp_button_padding['top'] ? esc_html('padding-top:' . $fma_oow_whatsapp_button_padding['top'] . 'px !important;') : 'padding-top: 5px !important;';
	$fma_oow_whatsapp_button_padding_bottom = isset($fma_oow_whatsapp_button_padding['bottom']) && '' != $fma_oow_whatsapp_button_padding['bottom'] ? esc_html('padding-bottom:' . $fma_oow_whatsapp_button_padding['bottom'] . 'px !important;') : 'padding-bottom: 5px !important;';
	$fma_oow_whatsapp_button_padding_left = isset($fma_oow_whatsapp_button_padding['left']) && '' != $fma_oow_whatsapp_button_padding['left'] ? esc_html('padding-left:' . $fma_oow_whatsapp_button_padding['left'] . 'px !important;') : 'padding-left: 8px !important;';
	$fma_oow_whatsapp_button_padding_right = isset($fma_oow_whatsapp_button_padding['right']) && '' != $fma_oow_whatsapp_button_padding['right'] ? esc_html('padding-right:' . $fma_oow_whatsapp_button_padding['right'] . 'px !important;') : 'padding-right: 8px !important;';

	$fma_oow_whatsapp_button_border_radius = maybe_unserialize(get_option('fma_oow_whatsapp_button_border_radius'));
	$fma_oow_whatsapp_button_border_radius_top = isset($fma_oow_whatsapp_button_border_radius['top']) ? esc_html('border-top-left-radius:' . $fma_oow_whatsapp_button_border_radius['top'] . 'px !important;') : '';
	$fma_oow_whatsapp_button_border_radius_bottom = isset($fma_oow_whatsapp_button_border_radius['bottom']) ? esc_html('border-top-right-radius:' . $fma_oow_whatsapp_button_border_radius['bottom'] . 'px !important;') : '';
	$fma_oow_whatsapp_button_border_radius_left = isset($fma_oow_whatsapp_button_border_radius['left']) ? esc_html('border-bottom-left-radius:' . $fma_oow_whatsapp_button_border_radius['left'] . 'px !important;') : '';
	$fma_oow_whatsapp_button_border_radius_right = isset($fma_oow_whatsapp_button_border_radius['right']) ? esc_html('border-bottom-right-radius:' . $fma_oow_whatsapp_button_border_radius['right'] . 'px !important;') : '';

	$fma_oow_share_button_padding = maybe_unserialize(get_option('fma_oow_share_button_padding'));
	$fma_oow_share_button_padding_top = isset($fma_oow_share_button_padding['top']) && '' != $fma_oow_share_button_padding['top'] ? esc_html('padding-top:' . $fma_oow_share_button_padding['top'] . 'px !important;') : 'padding-top: 5px !important;';
	$fma_oow_share_button_padding_bottom = isset($fma_oow_share_button_padding['bottom']) && '' != $fma_oow_share_button_padding['bottom'] ? esc_html('padding-bottom:' . $fma_oow_share_button_padding['bottom'] . 'px !important;') : 'padding-bottom: 5px !important;';
	$fma_oow_share_button_padding_left = isset($fma_oow_share_button_padding['left']) && '' != $fma_oow_share_button_padding['left'] ? esc_html('padding-left:' . $fma_oow_share_button_padding['left'] . 'px !important;') : 'padding-left: 8px !important;';
	$fma_oow_share_button_padding_right = isset($fma_oow_share_button_padding['right']) && '' != $fma_oow_share_button_padding['right'] ? esc_html('padding-right:' . $fma_oow_share_button_padding['right'] . 'px !important;') : 'padding-right: 8px !important;';

	$fma_oow_share_button_border_radius = maybe_unserialize(get_option('fma_oow_share_button_border_radius'));
	$fma_oow_share_button_border_radius_top = isset($fma_oow_share_button_border_radius['top']) ? esc_html('border-top-left-radius:' . $fma_oow_share_button_border_radius['top'] . 'px !important;') : '';
	$fma_oow_share_button_border_radius_bottom = isset($fma_oow_share_button_border_radius['bottom']) ? esc_html('border-top-right-radius:' . $fma_oow_share_button_border_radius['bottom'] . 'px !important;') : '';
	$fma_oow_share_button_border_radius_left = isset($fma_oow_share_button_border_radius['left']) ? esc_html('border-bottom-left-radius:' . $fma_oow_share_button_border_radius['left'] . 'px !important;') : '';
	$fma_oow_share_button_border_radius_right = isset($fma_oow_share_button_border_radius['right']) ? esc_html('border-bottom-right-radius:' . $fma_oow_share_button_border_radius['right'] . 'px !important;') : '';

	$fma_oow_shop_whatsapp_btn_width = get_option('fma_oow_shop_whatsapp_btn_width', '');
	$fma_oow_prd_whatsapp_btn_width = get_option('fma_oow_prd_whatsapp_btn_width', '');
	$fma_oow_cart_whatsapp_btn_width = get_option('fma_oow_cart_whatsapp_btn_width', '');

	$fma_oow_shop_whatsapp_btn_width = fma_oow_build_button_width_css($fma_oow_shop_whatsapp_btn_width);
	$fma_oow_prd_whatsapp_btn_width = fma_oow_build_button_width_css($fma_oow_prd_whatsapp_btn_width);
	$fma_oow_cart_whatsapp_btn_width = fma_oow_build_button_width_css($fma_oow_cart_whatsapp_btn_width);

	$fma_oow_shop_share_btn_width = get_option('fma_oow_shop_share_btn_width', '');
	$fma_oow_prd_share_btn_width = get_option('fma_oow_prd_share_btn_width', '');
	$fma_oow_cart_share_btn_width = get_option('fma_oow_cart_share_btn_width', '');

	$fma_oow_shop_share_btn_width = fma_oow_build_button_width_css($fma_oow_shop_share_btn_width);
	$fma_oow_prd_share_btn_width = fma_oow_build_button_width_css($fma_oow_prd_share_btn_width);
	$fma_oow_cart_share_btn_width = fma_oow_build_button_width_css($fma_oow_cart_share_btn_width);

	include 'views/fma-oow-internal-share-button-css.php';
}

/**
 * Build width CSS for storefront buttons; defaults to content width when unset.
 *
 * @param mixed $width_option Saved width in pixels.
 * @return string
 */
function fma_oow_build_button_width_css( $width_option ) {
	$width = absint($width_option);
	if ($width > 0) {
		return 'width:' . $width . 'px !important;';
	}

	return 'width:auto !important;max-width:100% !important;';
}

/**
 * Enqueue WooCommerce classic checkout scripts for the popup modal.
 *
 * Wc-checkout binds to form.checkout on page load; the popup shell form must exist
 * In the DOM before that script runs (see fma-oow-checkout-popup-html.php).
 *
 * @return void
 */
function fma_oow_enqueue_popup_checkout_scripts() {
	if (!function_exists('WC')) {
		return;
	}

	add_filter('woocommerce_is_checkout', '__return_true');

	wp_enqueue_style('select2');
	wp_enqueue_script('selectWoo');
	wp_enqueue_script('wc-country-select');
	wp_enqueue_script('wc-address-i18n');
	wp_enqueue_script('wc-checkout');

	if (WC()->payment_gateways()) {
		foreach (WC()->payment_gateways()->payment_gateways() as $gateway) {
			if (is_callable(array( $gateway, 'payment_scripts' ))) {
				$gateway->payment_scripts();
			}
		}
	}

	remove_filter('woocommerce_is_checkout', '__return_true');
}

/**
 * Ensure block cart popup script loads after wc-checkout and main plugin JS.
 *
 * @return void
 */
function fma_oow_finalize_block_cart_checkout_scripts() {
	if (is_admin() || !function_exists('has_block') || !has_block('woocommerce/cart')) {
		return;
	}

	if (!wp_script_is('fme_wa_front_wc_blocks_js', 'registered')) {
		return;
	}

	fma_oow_enqueue_popup_checkout_scripts();

	$wp_scripts = wp_scripts();
	$handle = 'fme_wa_front_wc_blocks_js';
	$extra_deps = array( 'wc-checkout', 'fma_order_on_whatsapp_my_script_for_whatsapp_contact' );

	foreach ($extra_deps as $dep) {
		if (
			wp_script_is($dep, 'registered')
			&& !in_array($dep, $wp_scripts->registered[ $handle ]->deps, true)
		) {
			$wp_scripts->registered[ $handle ]->deps[] = $dep;
		}
	}

	wp_enqueue_script('fme_wa_front_wc_blocks_js');
}

/**
 * Include CSS and JS files
 *
 * @return void
 */
function fma_order_on_whatsapp_load_my_files_whatsapp_admin() {
	if (is_admin()) {
		return;
	}
	if (!fma_oow_should_enqueue_frontend_assets()) {
		return;
	}

	wp_enqueue_script('jquery');
	wp_enqueue_script('jquery-form');
	fma_oow_enqueue_popup_checkout_scripts();
	wp_enqueue_style('fma_order_on_whatsapp_contact', FMA_OOW_PLUGIN_URL . 'assets/css/fma-order-on-whatsapp.css', array(), FMA_OOW_VERSION);
	wp_enqueue_style('fma_order_on_whatsapp_font_awesome', FMA_OOW_PLUGIN_URL . 'assets/css/fontawesome.min.css', array(), FMA_OOW_VERSION);

	$fma_oow_script_deps = array( 'jquery' );
	if (wp_script_is('wc-checkout', 'registered')) {
		$fma_oow_script_deps[] = 'wc-checkout';
	}

	wp_enqueue_script('fma_order_on_whatsapp_my_script_for_whatsapp_contact', FMA_OOW_PLUGIN_URL . 'assets/js/fma-order-on-whatsapp.js', $fma_oow_script_deps, FMA_OOW_VERSION, true);

	$theme = wp_get_theme();
	$fma_oow_whatsapp_open_target = fma_oow_open_whatsapp_in_which_tab();
	$ewcpm_data = array(
		'admin_url' => admin_url('admin-ajax.php'),
		'front_ajax_nonce' => wp_create_nonce('front_ajax_nonce'),
		'theme_name' => $theme->name,
		'is_block_theme' => $theme->is_block_theme() ? '1' : '',
		'uses_block_checkout' => fma_oow_store_uses_block_checkout() ? '1' : '',
		'enter_name' => WpmlHelper::translate(__('Enter name', 'order-on-whatsapp'), 'enter_name'),
		'enter_1st_whatsapp_number' => WpmlHelper::translate(__('Enter 1st whatsapp number', 'order-on-whatsapp'), 'enter_1st_whatsapp_number'),
		'active' => WpmlHelper::translate(__('Active', 'order-on-whatsapp'), 'active'),
		'inactive' => WpmlHelper::translate(__('InActive', 'order-on-whatsapp'), 'inactive'),
		'fma_order_on_whatsapp_payment_method_whatsapp' => WpmlHelper::translate(__('Cash On Delivery', 'order-on-whatsapp'), 'fma_order_on_whatsapp_payment_method_whatsapp'),
		'fma_order_on_whatsapp_name_text' => WpmlHelper::translate(__('Name:', 'order-on-whatsapp'), 'fma_order_on_whatsapp_name_text'),
		'fma_order_on_whatsapp_company_name_text' => WpmlHelper::translate(__('Company Name:', 'order-on-whatsapp'), 'fma_order_on_whatsapp_company_name_text'),
		'fma_order_on_whatsapp_country_text' => WpmlHelper::translate(__('Country:', 'order-on-whatsapp'), 'fma_order_on_whatsapp_country_text'),
		'fma_order_on_whatsapp_street_address_text' => WpmlHelper::translate(__('Street Address:', 'order-on-whatsapp'), 'fma_order_on_whatsapp_street_address_text'),
		'fma_order_on_whatsapp_town_or_city_text' => WpmlHelper::translate(__('Town/City:', 'order-on-whatsapp'), 'fma_order_on_whatsapp_town_or_city_text'),
		'fma_order_on_whatsapp_state_or_country_text' => WpmlHelper::translate(__('State/Country:', 'order-on-whatsapp'), 'fma_order_on_whatsapp_state_or_country_text'),
		'fma_order_on_whatsapp_post_code_or_zip_text' => WpmlHelper::translate(__('Postcode/ZIP:', 'order-on-whatsapp'), 'fma_order_on_whatsapp_post_code_or_zip_text'),
		'fma_order_on_whatsapp_phone_text' => WpmlHelper::translate(__('Phone:', 'order-on-whatsapp'), 'fma_order_on_whatsapp_phone_text'),
		'fma_order_on_whatsapp_quantity_text' => WpmlHelper::translate(__('Quantity:', 'order-on-whatsapp'), 'fma_order_on_whatsapp_quantity_text'),
		'fma_order_on_whatsapp_products_details_text' => WpmlHelper::translate(__('Product Details', 'order-on-whatsapp'), 'fma_order_on_whatsapp_products_details_text'),
		'fma_order_on_whatsapp_user_details_text' => WpmlHelper::translate(__('Customer Billing Details', 'order-on-whatsapp'), 'fma_order_on_whatsapp_user_details_text'),
		'fma_order_on_whatsapp_order_details_text' => WpmlHelper::translate(__('Order Details', 'order-on-whatsapp'), 'fma_order_on_whatsapp_order_details_text'),
		'fma_order_on_whatsapp_date_text' => WpmlHelper::translate(__('Date:', 'order-on-whatsapp'), 'fma_order_on_whatsapp_date_text'),
		'fma_order_on_whatsapp_user_email' => WpmlHelper::translate(__('Email:', 'order-on-whatsapp'), 'fma_order_on_whatsapp_user_email'),
		'fma_order_on_whatsapp_total_expense' => WpmlHelper::translate(__('Total:', 'order-on-whatsapp'), 'fma_order_on_whatsapp_total_expense'),
		'fma_order_on_whatsapp_order_no_text' => WpmlHelper::translate(__('Order no:', 'order-on-whatsapp'), 'fma_order_on_whatsapp_order_no_text'),
		'fma_order_on_whatsapp_product_title_text' => WpmlHelper::translate(__('Product Title:', 'order-on-whatsapp'), 'fma_order_on_whatsapp_product_title_text'),
		'fma_order_on_whatsapp_price_text' => WpmlHelper::translate(__('Price:', 'order-on-whatsapp'), 'fma_order_on_whatsapp_price_text'),
		'fma_order_on_whatsapp_link_text' => WpmlHelper::translate(__('Link:', 'order-on-whatsapp'), 'fma_order_on_whatsapp_link_text'),
		'fma_order_on_whatsapp_pay_now_text' => WpmlHelper::translate(__('Pay now', 'order-on-whatsapp'), 'fma_order_on_whatsapp_pay_now_text'),
		'fma_order_on_whatsapp_payment_method_label' => WpmlHelper::translate(__('Payment method:', 'order-on-whatsapp'), 'fma_order_on_whatsapp_payment_method_label'),
		'fma_order_on_whatsapp_product_link_text' => WpmlHelper::translate(__('Product Link:', 'order-on-whatsapp'), 'fma_order_on_whatsapp_product_link_text'),
		'fma_ow_shipping_user_details_text' => WpmlHelper::translate(__('Customer Shipping Details', 'order-on-whatsapp'), 'fma_ow_shipping_user_details_text'),
		'fma_oow_share_payment_method_label' => WpmlHelper::translate(__('WhatsApp Order', 'order-on-whatsapp'), 'fma_oow_share_payment_method_label'),
		'checkout_url' => wc_get_checkout_url(),
		'popup_close_label' => WpmlHelper::translate(__('close', 'order-on-whatsapp'), 'popup_close_label'),
		'whatsapp_open_target' => '_blank' === $fma_oow_whatsapp_open_target ? '_blank' : '_self',
	);
	wp_localize_script('fma_order_on_whatsapp_my_script_for_whatsapp_contact', 'ewcpm_php_vars', $ewcpm_data);
	wp_localize_script('fma_order_on_whatsapp_my_script_for_whatsapp_contact', 'fma_payments_methods_chk', array(
		'alloud_or_not' => get_option('fma_oow_all_payment_gateways'),
	));
	fma_oow_activate_themes_specific_css();
}

/**
 * Whether the active theme is Twenty Twenty-Three.
 *
 * @return bool
 */
function fma_oow_is_twenty_twenty_three_theme() {
	$theme = wp_get_theme();

	return in_array($theme->get_stylesheet(), array( 'twentytwentythree' ), true)
		|| in_array($theme->get_template(), array( 'twentytwentythree' ), true)
		|| 'Twenty Twenty-Three' === $theme->name
		|| 'Twenty Twenty-Three' === $theme->parent_theme;
}

/**
 * Specific themes CSS
 *
 * @return void
 */
function fma_oow_activate_themes_specific_css() {
	$theme = wp_get_theme();

	if ('Avada' == $theme->name || 'Avada' == $theme->parent_theme) {
		wp_enqueue_style('fma_oow_style_css_avada', FMA_OOW_PLUGIN_URL . 'assets/css/fma-order-on-whatsapp-avada.css', array(), FMA_OOW_VERSION);
	} elseif ('The Retailer' == $theme->name || 'The Retailer' == $theme->parent_theme) {
		wp_enqueue_style('fma_oow_style_css_retailer', FMA_OOW_PLUGIN_URL . 'assets/css/fma-order-on-whatsapp-retailer.css', array(), FMA_OOW_VERSION);
	} elseif ('Astra' == $theme->name || 'Astra' == $theme->parent_theme) {
		wp_enqueue_style('fma_oow_style_css_astra', FMA_OOW_PLUGIN_URL . 'assets/css/fma-order-on-whatsapp-astra.css', array(), FMA_OOW_VERSION);
	} elseif ('Betheme' == $theme->name || 'Betheme' == $theme->parent_theme) {
		wp_enqueue_style('fma_oow_style_css_betheme', FMA_OOW_PLUGIN_URL . 'assets/css/fma-order-on-whatsapp-betheme.css', array(), FMA_OOW_VERSION);
	} elseif ('Divi' == $theme->name || 'Divi' == $theme->parent_theme) {
		wp_enqueue_style('fma_oow_style_css_divi', FMA_OOW_PLUGIN_URL . 'assets/css/fma-order-on-whatsapp-divi.css', array(), FMA_OOW_VERSION);
	} elseif ('Flatsome' == $theme->name || 'Flatsome' == $theme->parent_theme) {
		wp_enqueue_style('fma_oow_style_css_flatsome', FMA_OOW_PLUGIN_URL . 'assets/css/fma-order-on-whatsapp-flatsome.css', array(), FMA_OOW_VERSION);
	} elseif ('Porto' == $theme->name || 'Porto' == $theme->parent_theme) {
		wp_enqueue_style('fma_oow_style_css_porto', FMA_OOW_PLUGIN_URL . 'assets/css/fma-order-on-whatsapp-porto.css', array(), FMA_OOW_VERSION);
	} elseif ('Woodmart' == $theme->name || 'Woodmart' == $theme->parent_theme) {
		wp_enqueue_style('fma_oow_style_css_woodmart', FMA_OOW_PLUGIN_URL . 'assets/css/fma-order-on-whatsapp-woodmart.css', array(), FMA_OOW_VERSION);
	} elseif ('Hello Elementor' == $theme->name || 'Hello Elementor' == $theme->parent_theme) {
		wp_enqueue_style('fma_oow_style_css_hello_elementor', FMA_OOW_PLUGIN_URL . 'assets/css/fma-order-on-whatsapp-hello-elementor.css', array(), FMA_OOW_VERSION);
	} elseif (fma_oow_is_twenty_twenty_three_theme()) {
		wp_enqueue_style('fma_oow_style_css_block_themes', FMA_OOW_PLUGIN_URL . 'assets/css/fma-order-on-whatsapp-block-themes.css', array(), FMA_OOW_VERSION);
		wp_enqueue_style('fma_oow_style_css_twentytwentythree', FMA_OOW_PLUGIN_URL . 'assets/css/fma-order-on-whatsapp-twentytwentythree.css', array( 'fma_oow_style_css_block_themes' ), FMA_OOW_VERSION);
	} elseif (true === $theme->is_block_theme()) {
		wp_enqueue_style('fma_oow_style_css_block_themes', FMA_OOW_PLUGIN_URL . 'assets/css/fma-order-on-whatsapp-block-themes.css', array(), FMA_OOW_VERSION);
	}
}

/**
 * Added custom icons CSS
 *
 * @return void
 */
function custom_icons_css() {
	$fma_oow_def_icon_chk = get_option('fma_oow_def_icon_chk', 'off');
	$fma_oow_show_icon_only = get_option('fma_oow_show_icon_only', 'off');
	// #-------------Added BY Muhammad Manahal -----------#
	// include custom icon css for WhatsApp And Share Buttons
	include 'views/fma-oow-custom-icon-css.php';
}

/**
 * Register loop add-to-cart removal filter once (themes using woocommerce_loop_add_to_cart_link).
 *
 * @return void
 */
function fma_oow_register_loop_add_to_cart_removals() {
	static $registered = false;
	if ($registered) {
		return;
	}
	if ('yes' !== get_option('fma_order_on_whatsapp_hide_add_to_cart_button_shop_page')) {
		return;
	}
	add_filter('woocommerce_loop_add_to_cart_link', 'fmaOowRemoveAddToCartButtonFromShopPage', 20, 3);
	$registered = true;
}

/**
 * Themes that replace loop add-to-cart via woocommerce_loop_add_to_cart_link filter.
 *
 * @return bool
 */
function fma_oow_theme_uses_loop_add_to_cart_link_filter() {
	$theme = wp_get_theme();
	$filter_themes = array( 'Astra', 'Avada', 'Woodmart', 'Flatsome', 'Divi', 'Porto', 'Betheme' );
	foreach ($filter_themes as $theme_name) {
		if ($theme_name === $theme->name || $theme_name === $theme->parent_theme) {
			return true;
		}
	}
	return true === $theme->is_block_theme();
}

/**
 * Remove add to cart button for all products (shop page)
 *
 * @return void
 */
function fma_oow_remove_add_to_cart_shop_page_when_all_products_selected() {
	return;
}

/**
 * Remove add to cart button for all products (product page)
 *
 * @return void
 */
function fma_oow_remove_add_to_cart_btn_product_page_when_all_products_selected() {
	if (is_product()) {
		if (get_option('fma_oow_apply_on_all_products') == 'yes') {
			$fma_oow_product_page_when_all_products_selected = get_option('fma_order_on_whatsapp_hide_add_to_cart_button_product_page');
			?>
			<input type="hidden" id='fma_oow_hiden_field_for_product_page_when_all_products_chkd'
				value="<?php echo esc_html($fma_oow_product_page_when_all_products_selected); ?>">
			<?php
		}
	}
}

/**
 * Function to update order meta
 *
 * @since  1.2.3
 * @param int id
 * @return void
 */
function fme_oow_update_order_meta( $order_id ) {
	$order = wc_get_order($order_id);
	if (!$order) {
		return;
	}

	$order_payment_method = $order->get_payment_method();

	if ('whatsapp_payment' === $order_payment_method) {
		$order->update_meta_data('fme_oow_order', 'worder');
	} elseif (isset($_REQUEST['order'])) {
		$order->update_meta_data('fme_oow_order', sanitize_text_field($_REQUEST['order']));
	} else {
		$order->update_meta_data('fme_oow_order', 'norder');
	}
	if (isset($_REQUEST['fma_oow_whatsapp_contact_number'])) {
		$order->update_meta_data('fma_oow_whatsapp_contact_number', sanitize_text_field($_REQUEST['fma_oow_whatsapp_contact_number']));
	}
	$order->save();
}

/**
 * Build default WhatsApp order message (legacy layout) as plain text.
 *
 * @param WC_Order $order Order.
 * @return string
 */
function fme_oow_build_legacy_whatsapp_order_message( $order ) {
	if (! $order instanceof WC_Order) {
		return '';
	}
	$currency_symbol = html_entity_decode(get_woocommerce_currency_symbol(), ENT_QUOTES, 'UTF-8');
	$fmamMsgWhenWhatsapOpens = WpmlHelper::translate((string) get_option('fma_oow_msg_when_whatsap_opens'), 'saved_fma_oow_msg_when_whatsap_opens');

	$billing_first_name = $order->get_billing_first_name();
	$billing_last_name = $order->get_billing_last_name();
	$billing_company = $order->get_billing_company();
	$billing_email = $order->get_billing_email();
	$billing_country = $order->get_billing_country();
	$billing_address_1 = $order->get_billing_address_1();
	$billing_address_2 = $order->get_billing_address_2();
	$billing_city = $order->get_billing_city();
	$billing_state = $order->get_billing_state();
	$billing_postcode = $order->get_billing_postcode();
	$billing_phone = $order->get_billing_phone();

	$shipping_first_name = $order->get_shipping_first_name();
	$shipping_last_name = $order->get_shipping_last_name();
	$shipping_company = $order->get_shipping_company();
	$shipping_country = $order->get_shipping_country();
	$shipping_address_1 = $order->get_shipping_address_1();
	$shipping_address_2 = $order->get_shipping_address_2();
	$shipping_city = $order->get_shipping_city();
	$shipping_state = $order->get_shipping_state();
	$shipping_postcode = $order->get_shipping_postcode();

	$view_order_url = $order->get_view_order_url();
	$fmaPaymentMethodLabel = $order->get_payment_method_title();
	$fmaWhatsAppLabels = fmaGetAllLabelsForWhatsAppMessage();

	$fma_order_id = '*' . $fmaWhatsAppLabels['fmaOrderNoLabel'] . '* ' . $order->get_id();
	$fma_order_on_whatsapp_name_text = str_replace('&', '', '*' . $fmaWhatsAppLabels['fmaNameLabel'] . '* ' . $billing_first_name . ' ' . $billing_last_name);
	$fma_order_on_whatsapp_company_name_text = str_replace('&', '', '*' . $fmaWhatsAppLabels['fmaCompanyNameLabel'] . '* ' . $billing_company);
	$fma_order_on_whatsapp_country_text = str_replace('&', '', '*' . $fmaWhatsAppLabels['fmaCountryLabel'] . '* ' . $billing_country);
	$fma_order_on_whatsapp_street_address_text = str_replace('&', '', '*' . $fmaWhatsAppLabels['fmaStreetAddressLabel'] . '* ' . $billing_address_1 . ' ' . $billing_address_2);
	$fma_order_on_whatsapp_town_or_city_text = str_replace('&', '', '*' . $fmaWhatsAppLabels['fmaTowOrCityLabel'] . '* ' . $billing_city);
	$fma_order_on_whatsapp_state_or_country_text = str_replace('&', '', '*' . $fmaWhatsAppLabels['fmaStateOrCountryLabel'] . '* ' . $billing_state);
	$fma_order_on_whatsapp_post_code_or_zip_text = str_replace('&', '', '*' . $fmaWhatsAppLabels['fmaPostCodeOrZipLabel'] . '* ' . $billing_postcode);
	$fma_order_on_whatsapp_phone_text = str_replace('&', '', '*' . $fmaWhatsAppLabels['fmaPhoneLabel'] . '* ' . $billing_phone);

	$fma_ow_shipping_name_text = str_replace('&', '', '*' . $fmaWhatsAppLabels['fmaNameLabel'] . '* ' . $shipping_first_name . ' ' . $shipping_last_name);
	$fma_ow_shipping_company_name_text = str_replace('&', '', '*' . $fmaWhatsAppLabels['fmaCompanyNameLabel'] . '* ' . $shipping_company);
	$fma_ow_shipping_country_name_text = str_replace('&', '', '*' . $fmaWhatsAppLabels['fmaCountryLabel'] . '* ' . $shipping_country);
	$fma_ow_shipping_street_address_text = str_replace('&', '', '*' . $fmaWhatsAppLabels['fmaStreetAddressLabel'] . '* ' . $shipping_address_1 . ' ' . $shipping_address_2);
	$fma_ow_shipping_city_name_text = str_replace('&', '', '*' . $fmaWhatsAppLabels['fmaTowOrCityLabel'] . '* ' . $shipping_city);
	$fma_ow_shipping_state_or_country_text = str_replace('&', '', '*' . $fmaWhatsAppLabels['fmaStateOrCountryLabel'] . '* ' . $shipping_state);
	$fma_ow_shipping_post_code_or_zip_text = str_replace('&', '', '*' . $fmaWhatsAppLabels['fmaPostCodeOrZipLabel'] . '* ' . $shipping_postcode);
	$fma_ow_shipping_phone_text = str_replace('&', '', '*' . $fmaWhatsAppLabels['fmaPhoneLabel'] . '* ' . $billing_phone);
	$fma_ow_shipping_user_email = '*' . $fmaWhatsAppLabels['fmaUserEmailLabel'] . '* ' . $billing_email;

	$fmaLineSeparator = '==============';
	$created_ts = $order->get_date_created() ? $order->get_date_created()->getTimestamp() : false;
	$fma_order_on_whatsapp_date_text = '*' . $fmaWhatsAppLabels['fmaDateLabel'] . '* ' . ( $created_ts ? gmdate('Y/m/d', $created_ts) : '' );
	$fma_order_on_whatsapp_user_email = '*' . $fmaWhatsAppLabels['fmaUserEmailLabel'] . '* ' . $billing_email;
	$fma_order_on_whatsapp_total_expense = '*' . $fmaWhatsAppLabels['fmaTotalExpenseLabel'] . '* ' . $currency_symbol . $order->get_total();
	$fma_oow_view_order_link = '*' . $fmaWhatsAppLabels['fmaViewOrderLabel'] . '* ' . $view_order_url;
	$fmaPaymentMethod = '*' . $fmaWhatsAppLabels['fmaPaymentMethod'] . '* ' . $fmaPaymentMethodLabel;

	$fma_order_on_whatsapp_links = '';
	$item_blocks = array();
	foreach ($order->get_items() as $item_id => $item_data) {
		$product = $item_data->get_product();
		if (! $product) {
			continue;
		}
		$item_blocks[] = '*' . $fmaWhatsAppLabels['fmaProductTitleLabel'] . '* ' . str_replace('&', '', $product->get_name()) . "\n" .
			'*' . $fmaWhatsAppLabels['fmaPriceLabel'] . '* ' . $currency_symbol . $product->get_price() . "\n" .
			'*' . $fmaWhatsAppLabels['fmaQuantityLabel'] . '* ' . $item_data->get_quantity() . "\n" .
			'*' . $fmaWhatsAppLabels['fmaLinkLabel'] . '* ' . str_replace('&', '', $product->get_permalink());
	}
	$fma_order_on_whatsapp_links = implode("\n\n", $item_blocks);

	$message = '*' . $fmamMsgWhenWhatsapOpens . '*' .
		"\n" . $fmaLineSeparator . '*' . $fmaWhatsAppLabels['fmaOrderDetailsLabel'] . '* ' . $fmaLineSeparator .
		"\n" . $fma_order_id .
		"\n" . $fma_order_on_whatsapp_date_text .
		"\n" . $fma_order_on_whatsapp_total_expense .
		"\n" . $fmaPaymentMethod .
		"\n" . $fma_oow_view_order_link .
		"\n" . $fmaLineSeparator . '*' . $fmaWhatsAppLabels['fmaProductsDetailsLabel'] . '* ' . $fmaLineSeparator .
		"\n" . $fma_order_on_whatsapp_links .
		"\n" . $fmaLineSeparator . '*' . $fmaWhatsAppLabels['fmaUserDetailsLabel'] . '* ' . $fmaLineSeparator .
		"\n" . $fma_order_on_whatsapp_name_text .
		"\n" . $fma_order_on_whatsapp_company_name_text .
		"\n" . $fma_order_on_whatsapp_country_text .
		"\n" . $fma_order_on_whatsapp_street_address_text .
		"\n" . $fma_order_on_whatsapp_town_or_city_text .
		"\n" . $fma_order_on_whatsapp_state_or_country_text .
		"\n" . $fma_order_on_whatsapp_post_code_or_zip_text .
		"\n" . $fma_order_on_whatsapp_phone_text .
		"\n" . $fma_order_on_whatsapp_user_email . "\n" .
		"\n" . $fmaLineSeparator . '*' . $fmaWhatsAppLabels['fmaUserShippingDetailsLabel'] . '* ' . $fmaLineSeparator .
		"\n" . $fma_ow_shipping_name_text .
		"\n" . $fma_ow_shipping_company_name_text .
		"\n" . $fma_ow_shipping_country_name_text .
		"\n" . $fma_ow_shipping_street_address_text .
		"\n" . $fma_ow_shipping_city_name_text .
		"\n" . $fma_ow_shipping_state_or_country_text .
		"\n" . $fma_ow_shipping_post_code_or_zip_text .
		"\n" . $fma_ow_shipping_phone_text .
		"\n" . $fma_ow_shipping_user_email .
		"\n";

	$fma_oow_send_pay_now_link = get_option('fma_oow_send_pay_now_link');
	if ('yes' == $fma_oow_send_pay_now_link) {
		$message .= $fmaLineSeparator . ' *' . $fmaWhatsAppLabels['fmaPayNowLabel'] . '* ' . $fmaLineSeparator . "\n*" . $fmaWhatsAppLabels['fmaLinkLabel'] . '* ' . $order->get_checkout_payment_url();
	}

	return $message;
}

/**
 * Function to redirect user to whatsapp
 *
 * @since  1.2.3
 * @param int id
 * @return void
 */
function fme_redirect_to_whatsapp( $order_id ) {
	$order = wc_get_order($order_id);
	if (! $order) {
		return;
	}
	$order_by_whatsapp = $order->get_meta('fme_oow_order', true);
	if (( 'norder' == $order_by_whatsapp && 'whatsapp_payment' != $order->get_payment_method() ) || 'cod' == $order->get_payment_method() || ( '' == $order_by_whatsapp && 'whatsapp_payment' != $order->get_payment_method() )) {
		// if COD payment method selected then the order will be placed via js
		return;
	}

	$fma_oow_branch_number = $order->get_meta('fma_oow_whatsapp_contact_number', true);
	$fma_order_on_whatsapp_number = isset($fma_oow_branch_number) && '' != $fma_oow_branch_number ? $fma_oow_branch_number : get_option('fma_order_on_whatsapp_whatsapp_number', true);

	$fma_oow_the_device = fma_order_on_whatsapp_find_device();

	$template_option = WpmlHelper::translate((string) get_option('fma_oow_whatsapp_order_message_template', ''), 'saved_fma_oow_whatsapp_order_message_template');
	if (is_string($template_option) && '' !== trim($template_option)) {
		$message = FMA_OOW_WhatsApp_Template_Parser::parse($template_option, $order);
		$fma_oow_send_pay_now_link = get_option('fma_oow_send_pay_now_link');
		if ('yes' === $fma_oow_send_pay_now_link && false === strpos($message, $order->get_checkout_payment_url())) {
			$fmaWhatsAppLabels = fmaGetAllLabelsForWhatsAppMessage();
			$fmaLineSeparator = '==============';
			$message .= "\n" . $fmaLineSeparator . ' *' . $fmaWhatsAppLabels['fmaPayNowLabel'] . '* ' . $fmaLineSeparator . "\n*" . $fmaWhatsAppLabels['fmaLinkLabel'] . '* ' . $order->get_checkout_payment_url();
		}
	} else {
		$message = fme_oow_build_legacy_whatsapp_order_message($order);
	}
	/**
	 * Filter the WhatsApp message before redirect.
	 *
	 * Allows developers to customize or modify the WhatsApp message that is sent to the user.
	 *
	 * @since 1.2.3
	 * @param string   $message The WhatsApp message content.
	 * @param WC_Order $order   The WooCommerce order object.
	 */
	$message = apply_filters('oow_whatsapp_template_message', $message, $order);

	$is_mobile = ( 'api' === $fma_oow_the_device );
	if ($is_mobile) {
		$whatsapp_url = fma_oow_build_whatsapp_app_send_url($fma_order_on_whatsapp_number, $message);
	} else {
		$whatsapp_url = fma_oow_build_whatsapp_send_url($fma_order_on_whatsapp_number, $message);
	}

	$open_new_tab = fma_oow_open_whatsapp_in_which_tab();
	$open_new_tab = '_blank' == ( $open_new_tab ) ? $open_new_tab : '_self';

	?>

	<script>
		var whatsapp_url = <?php echo wp_json_encode($whatsapp_url); // nosemgrep ?>;
		var open_new_tab = "<?php echo esc_html($open_new_tab); ?>";
		var is_mobile_redirect = <?php echo $is_mobile ? 'true' : 'false'; ?>;
		function fmaOowRedirectToWhatsApp() {
			if (is_mobile_redirect) {
				var whatsappLink = document.createElement("a");
				whatsappLink.href = whatsapp_url;
				whatsappLink.style.display = "none";
				document.body.appendChild(whatsappLink);
				whatsappLink.click();
				document.body.removeChild(whatsappLink);
			} else if ('_blank' == open_new_tab) {
				window.open(whatsapp_url, open_new_tab);
			} else {
				location.href = whatsapp_url;
			}
		}
		if (is_mobile_redirect) {
			setTimeout(fmaOowRedirectToWhatsApp, 1500);
		} else {
			fmaOowRedirectToWhatsApp();
		}
	</script>
	<?php
}

/**
 * WhatsApp message labels
 * 
 * @return array
 */
function fmaGetAllLabelsForWhatsAppMessage() {
	$fmaNameLabel = WpmlHelper::translate(__('Name:', 'order-on-whatsapp'), 'fmaNameLabel');
	$fmaCompanyNameLabel = WpmlHelper::translate(__('Company Name:', 'order-on-whatsapp'), 'fmaCompanyNameLabel');
	$fmaCountryLabel = WpmlHelper::translate(__('Country:', 'order-on-whatsapp'), 'fmaCountryLabel');
	$fmaStreetAddressLabel = WpmlHelper::translate(__('Street Address:', 'order-on-whatsapp'), 'fmaStreetAddressLabel');
	$fmaTowOrCityLabel = WpmlHelper::translate(__('Town/City:', 'order-on-whatsapp'), 'fmaTowOrCityLabel');
	$fmaStateOrCountryLabel = WpmlHelper::translate(__('State/Country:', 'order-on-whatsapp'), 'fmaStateOrCountryLabel');
	$fmaPostCodeOrZipLabel = WpmlHelper::translate(__('Postcode/ZIP:', 'order-on-whatsapp'), 'fmaPostCodeOrZipLabel');
	$fmaPhoneLabel = WpmlHelper::translate(__('Phone:', 'order-on-whatsapp'), 'fmaPhoneLabel');
	$fmaQuantityLabel = WpmlHelper::translate(__('Quantity:', 'order-on-whatsapp'), 'fmaQuantityLabel');
	$fmaProductsDetailsLabel = WpmlHelper::translate(__('Product Details', 'order-on-whatsapp'), 'fmaProductsDetailsLabel');
	$fmaUserDetailsLabel = WpmlHelper::translate(__('Customer Billing Details', 'order-on-whatsapp'), 'fmaUserDetailsLabel');
	$fmaOrderDetailsLabel = WpmlHelper::translate(__('Order Details', 'order-on-whatsapp'), 'fmaOrderDetailsLabel');
	$fmaDateLabel = WpmlHelper::translate(__('Date:', 'order-on-whatsapp'), 'fmaDateLabel');
	$fmaUserEmailLabel = WpmlHelper::translate(__('Email:', 'order-on-whatsapp'), 'fmaUserEmailLabel');
	$fmaTotalExpenseLabel = WpmlHelper::translate(__('Total:', 'order-on-whatsapp'), 'fmaTotalExpenseLabel');
	$fmaOrderNoLabel = WpmlHelper::translate(__('Order no:', 'order-on-whatsapp'), 'fmaOrderNoLabel');
	$fmaProductTitleLabel = WpmlHelper::translate(__('Product Title:', 'order-on-whatsapp'), 'fmaProductTitleLabel');
	$fmaPriceLabel = WpmlHelper::translate(__('Price:', 'order-on-whatsapp'), 'fmaPriceLabel');
	$fmaLinkLabel = WpmlHelper::translate(__('Link:', 'order-on-whatsapp'), 'fmaLinkLabel');
	$fmaPayNowLabel = WpmlHelper::translate(__('Pay now', 'order-on-whatsapp'), 'fmaPayNowLabel');
	$fmaProductLinkLabel = WpmlHelper::translate(__('Product Link:', 'order-on-whatsapp'), 'fmaProductLinkLabel');
	$fmaViewOrderLabel = WpmlHelper::translate(__('View order:', 'order-on-whatsapp'), 'fmaViewOrderLabel');
	$fmaPaymentMethod = WpmlHelper::translate(__('Payment method:', 'order-on-whatsapp'), 'fmaPaymentMethod');

	// Shipping Address
	$fmaUserShippingDetailsLabel = WpmlHelper::translate(__('Customer Shipping Details', 'order-on-whatsapp'), 'fmaUserShippingDetailsLabel');

	$fmaWhatsAppMessageLabels = array(
		'fmaNameLabel' => $fmaNameLabel,
		'fmaCompanyNameLabel' => $fmaCompanyNameLabel,
		'fmaCountryLabel' => $fmaCountryLabel,
		'fmaStreetAddressLabel' => $fmaStreetAddressLabel,
		'fmaTowOrCityLabel' => $fmaTowOrCityLabel,
		'fmaStateOrCountryLabel' => $fmaStateOrCountryLabel,
		'fmaPostCodeOrZipLabel' => $fmaPostCodeOrZipLabel,
		'fmaPhoneLabel' => $fmaPhoneLabel,
		'fmaQuantityLabel' => $fmaQuantityLabel,
		'fmaProductsDetailsLabel' => $fmaProductsDetailsLabel,
		'fmaUserDetailsLabel' => $fmaUserDetailsLabel,
		'fmaOrderDetailsLabel' => $fmaOrderDetailsLabel,
		'fmaDateLabel' => $fmaDateLabel,
		'fmaUserEmailLabel' => $fmaUserEmailLabel,
		'fmaTotalExpenseLabel' => $fmaTotalExpenseLabel,
		'fmaOrderNoLabel' => $fmaOrderNoLabel,
		'fmaProductTitleLabel' => $fmaProductTitleLabel,
		'fmaPriceLabel' => $fmaPriceLabel,
		'fmaLinkLabel' => $fmaLinkLabel,
		'fmaPayNowLabel' => $fmaPayNowLabel,
		'fmaProductLinkLabel' => $fmaProductLinkLabel,
		'fmaViewOrderLabel' => $fmaViewOrderLabel,
		'fmaPaymentMethod' => $fmaPaymentMethod,
		'fmaUserShippingDetailsLabel' => $fmaUserShippingDetailsLabel,
	);
	return $fmaWhatsAppMessageLabels;
}

/**
 * Function responsible for generating  css for custom icons
 *
 * @since 1.2.4
 * @return void
 *
 **/
function fma_oow_icons_css() {
	$fma_icon_clr = get_option('fma_icon_clr', '#ffffff');
	$fma_icon_size = get_option('fma_icon_size', '20');
	$fma_icon_size = max(16, min(32, absint($fma_icon_size)));
	ob_start();
	// #-------------Added BY Muhammad Manahal -----------#
	// include icon css for WhatsApp And Share Buttons
	include 'views/fma-oow-icon-css.php';
	$icons_css = ob_get_clean();
	echo filter_var($icons_css);
}

// whatsApp link Single Product page
define('PRODUCT_TEXT', 'Product:'); // a constant text used before product name
function fmawhatsappButtonProductPage() {
	$whatsAppAndShareButtonForProductPage  = fmaOowWhatsAppAndShareButtonGetHtmlForProductPage();
	echo filter_var($whatsAppAndShareButtonForProductPage);
}

/**
 * Added WhatsApp buttons on cart page
 *
 * @return void
 */
function fmaWhatsappButtonOnCrtPage() {
	$fma_oow_selected_icon = get_option('fma_oow_icons', '0');
	$fma_oow_def_icon_chk = get_option('fma_oow_def_icon_chk', 'off');
	if ('off' == $fma_oow_def_icon_chk) {
		// this function will generate css for icons
		fma_oow_icons_css();
	}
	if (defined('WOOCOMMERCE_CHECKOUT')) {
		include plugin_dir_path(__FILE__) . 'cart-temp.php'; // include all front end stuff
	}
	$fma_oow_enable_only_for_customer = get_option('fma_oow_enable_only_for_customers');
	if ('yes' == $fma_oow_enable_only_for_customer) {
		if (true != is_user_logged_in()) {
			return;
		}
	}
	global $woocommerce;
	$fma_find_the_device = fma_order_on_whatsapp_find_device();
	$fma_oow_where_to_open_whatsapp = fma_oow_open_whatsapp_in_which_tab(); // where to open whatsapp
	$fma_order_on_whatsapp_number = get_option('fma_order_on_whatsapp_whatsapp_number', true);
	$fma_order_on_whatsapp_items = $woocommerce->cart->get_cart();
	if (!fma_oow_cart_has_targeted_products($fma_order_on_whatsapp_items)) {
		return;
	}
	// #-------------Added BY Muhammad Manahal ------------#
	// include Checkout popup HTML
	include 'views/fma-oow-checkout-popup-html.php';

	$fma_oow_show_share_btn_or_not = fma_oow_show_share_btn_or_not();
	$fma_order_on_whatsapp_total_expense = $woocommerce->cart->get_cart_contents_total();
	$fma_oow_share_btn_bg_color = get_option('fma_oow_share_btn_bg_color');
	$fma_oow_share_btn_text_color = get_option('fma_oow_share_btn_text_color');
	$fma_oow_share_btn_txt = WpmlHelper::translate((string) get_option('fma_oow_share_btn_txt'), 'saved_fma_oow_share_btn_txt');
	$fma_oow_msg_when_whatsap_opens = WpmlHelper::translate((string) get_option('fma_oow_msg_when_whatsap_opens'), 'saved_fma_oow_msg_when_whatsap_opens');
	$fma_oow_share_msg_when_whatsap_opens = WpmlHelper::translate((string) get_option('fma_oow_share_msg_when_whatsap_opens'), 'saved_fma_oow_share_msg_when_whatsap_opens');
	$fma_oow_mbl_or_dsktp = fma_order_on_whatsapp_find_device(); // find the browser
	// BG color for share button
	if (empty($fma_oow_share_btn_bg_color)) {
		$fma_oow_share_btn_bg_color = '#25d366';
	}
	// text color for share button
	if (empty($fma_oow_share_btn_text_color)) {
		$fma_oow_share_btn_text_color = '#ffff';
	}
	$fma_order_on_whatsapp_show_on_cart_page = get_option('fma_order_on_whatsapp_show_on_cart_page', true);
	$fma_order_on_whatsapp_share_show_btn_on_cart_page = get_option('fma_order_on_whatsapp_share_show_btn_on_cart_page', true);
	$fma_order_on_whatsapp_cart_btn_bg_color = get_option('fma_order_on_whatsapp_cart_btn_bg_color_hash');
	$fma_order_on_whatsapp_cart_btn_text_color_hash = get_option('fma_order_on_whatsapp_cart_btn_text_color_hash');
	if (empty($fma_order_on_whatsapp_cart_btn_bg_color)) {
		$fma_order_on_whatsapp_cart_btn_bg_color = '#25d366';
	}
	if (empty($fma_order_on_whatsapp_cart_btn_text_color_hash)) {
		$fma_order_on_whatsapp_cart_btn_text_color_hash = '#ffff';
	}
	$whatsapp_btn_border_clr_hash = get_option('whatsapp_btn_border_clr_hash');
	$whatsapp_btn_border_clr_width = get_option('whatsapp_btn_border_clr_width');
	if (empty($whatsapp_btn_border_clr_hash)) {
		$whatsapp_btn_border_clr_hash = '#25d366';
	}
	if (empty($whatsapp_btn_border_clr_width)) {
		$whatsapp_btn_border_clr_width = 0;
	}
	$share_btn_border_clr_hash = get_option('share_btn_border_clr_hash');
	$share_btn_border_clr_width = get_option('share_btn_border_clr_width');
	if (empty($share_btn_border_clr_hash)) {
		$share_btn_border_clr_hash = '#25d366';
	}
	if (empty($share_btn_border_clr_width)) {
		$share_btn_border_clr_width = 0;
	}
	$fma_oow_cart_share_url = fma_oow_build_cart_share_url(
		$fma_order_on_whatsapp_items,
		$fma_order_on_whatsapp_total_expense,
		$fma_order_on_whatsapp_number,
		$fma_oow_share_msg_when_whatsap_opens
	);
	// #-------------Added BY Muhammad Manahal ------------#
	// include Checkout popup HTML
	include 'views/fma-oow-cart-whatsApp-and-share-button.php';
}

/**
 * Added WhatsApp buttons on checkout page
 *
 * @return void
 */
function fma_order_on_whatsapp_whatsapp_button_on_checkout_page() {
	global $woocommerce;
	$fma_order_on_whatsapp_items = $woocommerce->cart->get_cart();
	$fma_order_on_whatsapp_number = get_option('fma_order_on_whatsapp_whatsapp_number', true);
	$fma_oow_msg_when_whatsap_opens = WpmlHelper::translate((string) get_option('fma_oow_msg_when_whatsap_opens'), 'saved_fma_oow_msg_when_whatsap_opens');
	$all_payment_gateways_chk = get_option('fma_oow_all_payment_gateways');
	$selected_payment_method_id = WC()->session->get('chosen_payment_method');
	$fma_oow_the_device = fma_order_on_whatsapp_find_device();
	$fmaOowDisplayCheckBox = 'none';

	if (( 'cod' == $selected_payment_method_id &&  'on' == $all_payment_gateways_chk ) || 
		 ( 'cod' == $selected_payment_method_id &&  'on' != $all_payment_gateways_chk ) || 
		 ( 'whatsapp_payment' != $selected_payment_method_id &&  'on' == $all_payment_gateways_chk ) ) {
		$fmaOowDisplayCheckBox = 'block';
	}

	// #-------------Added BY Muhammad Manahal ------------#
	// include Checkout order on WhatsApp checkbox HTML
	include 'views/fma-oow-checkout-checkbox-html.php';
}
//  Button on Shop Page
add_shortcode('fma_whatapp_button', 'fma_order_on_whatsapp_whatsapp_button_on_shop_page');

/**
 * Added WhatsApp buttons short-code
 *
 * @return void
 */
function fma_order_on_whatsapp_whatsapp_button_on_shop_page() {
	// this function is defined in fma-oow-whatsApp-and-share-button.php
	$whatsAppAndShareButton = fmaOowWhatsAppAndShareButtonGetHtml();
	echo filter_var($whatsAppAndShareButton);
}

/**
 * Add WhatsApp and Share Button on block theme shop page
 * 
 * @param $add_to_cart_html
 * @param $product
 * @param $args
 * @return $add_to_cart_html , $whatsAppAndShareButton
 */
function fmaOowWhatsAppButtonOnBlockShopPage( $add_to_cart_html, $product, $args ) {
	$whatsAppAndShareButton = fmaOowWhatsAppAndShareButtonGetHtml($add_to_cart_html, $product, $args);
	$fma_oow_where_to_place_whatsp_btn = get_option('fma_oow_where_to_place_whatsp_btn');
	$fmaOowCheckToShowOrHideAddToCartBtn = fmaOowCheckToShowOrHideAddToCartBtn($product);
	if (is_shop() || is_product_category() || is_product_tag() || is_product_taxonomy()) {
		if ('fma_oow_after_add_to_cart' == $fma_oow_where_to_place_whatsp_btn) {
			// echo $fmaOowCheckToShowOrHideAddToCartBtn;
			if (1 == $fmaOowCheckToShowOrHideAddToCartBtn) {
				return $whatsAppAndShareButton;
			} else {
				return $add_to_cart_html . $whatsAppAndShareButton;
			}
		} elseif (1 == $fmaOowCheckToShowOrHideAddToCartBtn) {
			return $whatsAppAndShareButton;
		} else {
			return $whatsAppAndShareButton . $add_to_cart_html;
		}
	}

	return $add_to_cart_html;
}

/**
 * Remove add to cart button on shop page
 *
 * @return void
 */
function fma_order_on_whatsapp_remove_add_to_cart_button_from_shop_page() {
	return;
}

/**
 * Remove add to cart button from shop page (block themes)
 * 
 * @param $html
 * @param $product
 * @param $args
 * @return $html(of add to cart button)
 */
function fmaOowRemoveAddToCartButtonFromShopPage( $html, $product, $args ) {
	$theme = wp_get_theme(); // gets the current theme
	$fmaOowApplyOnAllProducts = get_option('fma_oow_apply_on_all_products');
	$fmaOowHideAddToCartButShopPage = get_option('fma_order_on_whatsapp_hide_add_to_cart_button_shop_page');
	$fmaOowCheckToShowOrHideAddToCartBtn = fmaOowCheckToShowOrHideAddToCartBtn($product);
	if ('yes' !== $fmaOowHideAddToCartButShopPage || !fma_oow_is_shop_archive_context()) {
		return $html;
	}

	if ('yes' != $fmaOowApplyOnAllProducts && 1 != $fmaOowCheckToShowOrHideAddToCartBtn) {
		return $html;
	}

	if (true === $theme->is_block_theme()) {
		return fmaOowWhatsAppAndShareButtonGetHtml($html, $product, $args);
	}

	return '';
}

/**
 * Remove add to cart button from product page
 *
 * @return void
 */
function fma_order_on_whatsapp_remove_add_to_cart_button_from_product_page() {
	if (is_product()) {
		$fma_order_on_whatsapp_hide_add_to_cart_button_product_page = get_option('fma_order_on_whatsapp_hide_add_to_cart_button_product_page');
		$fmaOowEitherProductsOrCats = get_option('fma_order_on_whatsapp_either_products_or_cats', true);
		$fma_order_on_whatsapp_selected_products_list = get_option('fma_order_on_whatsapp_products_list');
		$fma_order_on_whatsapp_categories_list = get_option('fma_order_on_whatsapp_categories_list');
		$fmaOowCheckProductOrCategoryPresentInList = 0;
		if ('fma_order_on_whatsapp_products_list' == $fmaOowEitherProductsOrCats && !empty($fma_order_on_whatsapp_selected_products_list)) {
			$fmaOowCheckProductOrCategoryPresentInList = fmaOowCheckProductOrCategoryPresentInList($fmaOowEitherProductsOrCats, get_the_ID(), $fma_order_on_whatsapp_selected_products_list);
		} elseif ('categories' == $fmaOowEitherProductsOrCats && !empty($fma_order_on_whatsapp_categories_list)) {
			$fmaOowCheckProductOrCategoryPresentInList = fmaOowCheckProductOrCategoryPresentInList($fmaOowEitherProductsOrCats, get_the_ID(), $fma_order_on_whatsapp_categories_list);
		}
		if (1 == $fmaOowCheckProductOrCategoryPresentInList) {
			?>
			<input type="hidden" value="<?php echo esc_attr($fma_order_on_whatsapp_hide_add_to_cart_button_product_page); ?>" id="fma_order_on_whatsapp_btn_product_page">
			<?php
		}
	}
}

/**
 * When place order button is clicked
 *
 * @return void
 */
function fma_order_on_whatsapp_when_place_order_clicked() {
	check_ajax_referer('front_ajax_nonce', 'security');
	$customer_id = CURRENT_USER_ID;
	// global $woocommerce;
	$fma_order_on_whatsapp_items = WC()->cart->get_cart();
	$fma_order_on_whatsapp_cart_details = array();
	$i = 0;

	foreach ($fma_order_on_whatsapp_items as $item) {
		$variations = $item['variation'];
		$fma_order_on_whatsapp_cart_details[$i]['Product_Title'] = $item['data']->get_title();
		if (is_array($variations)) {
			foreach ($variations as $key => $value) {
				$fma_order_on_whatsapp_cart_details[$i]['Product_Title'] .= ' ' . $value;
			}
		}
		$fma_order_on_whatsapp_cart_details[$i]['Product_Quantity'] = $item['quantity'];
		$fma_order_on_whatsapp_cart_details[$i]['Product_Price'] = $item['data']->get_price();
		$fma_order_on_whatsapp_cart_details[$i]['Product_Id'] = $item['data']->get_id();
		$fma_order_on_whatsapp_cart_details[$i]['Product_Link'] = get_permalink($item['data']->get_id());
		$i++;
	}
	$view_order_url = '';
	$fmaPaymentMethodLabel = '';
	$new_order = null;
	$create_order_in_wc = ( 'yes' === get_option('fma_oow_create_order_in_woocommerce') );

	if (isset($_REQUEST['fmaOowCashOnDilvery'])) {
		$fmaOowCashOnDilvery = sanitize_text_field($_REQUEST['fmaOowCashOnDilvery']);
	} else {
		$fmaOowCashOnDilvery = 'cod';
	}

	$payment_gateways = WC()->payment_gateways->payment_gateways();
	if (isset($payment_gateways[ $fmaOowCashOnDilvery ])) {
		$fmaPaymentMethodLabel = $payment_gateways[ $fmaOowCashOnDilvery ]->get_title();
	}

	if ($create_order_in_wc) {
		$stock_check = WC()->cart->check_cart_item_stock();
		if (is_wp_error($stock_check)) {
			wp_send_json_error(array(
				'message' => $stock_check->get_error_message(),
			));
			wp_die();
		}
		$new_order = wc_create_order();
		foreach ($fma_order_on_whatsapp_items as $cart_item_key => $values) {
			$item_id = $new_order->add_product(
				$values['data'],
				$values['quantity'],
				array(
					'variation' => $values['variation'],
					'totals' => array(
						'subtotal' => $values['line_subtotal'],
						'subtotal_tax' => $values['line_subtotal_tax'],
						'total' => $values['line_total'],
						'tax' => $values['line_tax'],
						'tax_data' => $values['line_tax_data'], // Since 2.2
					),
				)
			);
		}
		$billing_info = array();
		if (isset($_REQUEST['billing_first_name'])) {
			$billing_info['first_name'] = sanitize_text_field($_REQUEST['billing_first_name']);
		}
		if (isset($_REQUEST['billing_last_name'])) {
			$billing_info['last_name'] = sanitize_text_field($_REQUEST['billing_last_name']);
		}
		if (isset($_REQUEST['billing_company'])) {
			$billing_info['company'] = sanitize_text_field($_REQUEST['billing_company']);
		}
		if (isset($_REQUEST['billing_email'])) {
			$billing_info['email'] = sanitize_text_field($_REQUEST['billing_email']);
		}
		if (isset($_REQUEST['billing_phone'])) {
			$billing_info['phone'] = sanitize_text_field($_REQUEST['billing_phone']);
		}
		if (isset($_REQUEST['billing_address_1'])) {
			$billing_info['address_1'] = sanitize_text_field($_REQUEST['billing_address_1']);
		}
		if (isset($_REQUEST['billing_address_2'])) {
			$billing_info['address_2'] = sanitize_text_field($_REQUEST['billing_address_2']);
		}
		if (isset($_REQUEST['billing_city'])) {
			$billing_info['city'] = sanitize_text_field($_REQUEST['billing_city']);
		}
		if (isset($_REQUEST['billing_postcode'])) {
			$billing_info['postcode'] = sanitize_text_field($_REQUEST['billing_postcode']);
		}
		if (isset($_REQUEST['billing_country'])) {
			$billing_info['country'] = sanitize_text_field($_REQUEST['billing_country']);
		}
		if (isset($_REQUEST['billing_state'])) {
			$billing_info['state'] = sanitize_text_field($_REQUEST['billing_state']);
		}
		$fma_oow_shipping = '';
		if (isset($_REQUEST['fma_oow_shipping'])) {
			$fma_oow_shipping = sanitize_text_field($_REQUEST['fma_oow_shipping']);
		}

		// Shipping Details
		$shipping_info = array();
		$different_shipping_address = sanitize_text_field($_REQUEST['different_shipping_address'] ?? '');
		$shipping_first_name = sanitize_text_field($_REQUEST['shipping_first_name'] ?? '');
		$shipping_last_name = sanitize_text_field($_REQUEST['shipping_last_name'] ?? '');
		$shipping_company = sanitize_text_field($_REQUEST['shipping_company'] ?? '');
		$shipping_country = sanitize_text_field($_REQUEST['shipping_country'] ?? '');
		$shipping_address_1 = sanitize_text_field($_REQUEST['shipping_address_1'] ?? '');
		$shipping_address_2 = sanitize_text_field($_REQUEST['shipping_address_2'] ?? '');
		$shipping_city = sanitize_text_field($_REQUEST['shipping_city'] ?? '');
		$shipping_state = sanitize_text_field($_REQUEST['shipping_state'] ?? '');
		$shipping_postcode = sanitize_text_field($_REQUEST['shipping_postcode'] ?? '');     
		
		$shipping_info['first_name'] = $shipping_first_name;
		$shipping_info['last_name'] = $shipping_last_name;
		$shipping_info['company'] = $shipping_company;
		$shipping_info['email'] = sanitize_text_field($_REQUEST['billing_email'] ?? '');
		$shipping_info['phone'] = sanitize_text_field($_REQUEST['billing_phone'] ?? '');
		$shipping_info['address_1'] = $shipping_address_1;
		$shipping_info['address_2'] = $shipping_address_2;
		$shipping_info['city'] = $shipping_city;
		$shipping_info['state'] = $shipping_state;
		$shipping_info['postcode'] = $shipping_postcode;
		$shipping_info['country'] = $shipping_country;

		//  whatsapp order
		if (isset($_REQUEST['wcheck_val'])) {
			$fma_order_on_whatsapp_option = sanitize_text_field($_REQUEST['wcheck_val']);
		} else {
			$fma_order_on_whatsapp_option = 'norder';
		}
		$new_order->set_address($billing_info, 'billing');
		if ('yes' == $different_shipping_address) {
			$new_order->set_address($shipping_info, 'shipping');
		} else {
			$new_order->set_address($billing_info, 'shipping');
		}
		$new_order->set_total(WC()->cart->total);
		// Get a new instance of the WC_Order_Item_Shipping Object
		$item = new WC_Order_Item_Shipping();
		$method_key_id = str_replace(':', '_', $fma_oow_shipping); // Formating
		$option_name = 'woocommerce_' . $method_key_id . '_settings'; // Get the complete option slug
		$settings = get_option($option_name, array());
		$shipping_name = is_array($settings) && isset($settings['title']) ? $settings['title'] : __('Shipping', 'order-on-whatsapp');

		$item->set_method_id($fma_oow_shipping); // set an existing Shipping method rate ID
		if ('Free shipping' == $shipping_name) {
			$item->set_method_title('Free shipping'); // set an existing Shipping method rate ID
		} else {
			$item->set_method_title(wc_price(WC()->cart->shipping_total) . ' via ' . $shipping_name); // set an existing Shipping method rate ID
		}
		$item->set_total(WC()->cart->shipping_total); // (optional)
		$new_order->add_item($item);
		$new_order->set_cart_hash(WC()->cart->get_cart_hash());
		$new_order->set_payment_method($payment_gateways[ $fmaOowCashOnDilvery ]);
		$new_order->set_customer_id($customer_id);
		$new_order->update_meta_data('_customer_user', $customer_id);
		$new_order->update_meta_data('fme_oow_order', $fma_order_on_whatsapp_option);
		/////////////////// WHATSAPP CONTACT NUMBERS ////////////////////
		if (isset($_REQUEST['fma_oow_whatsapp_contact_number'])) {
			$new_order->update_meta_data('fma_oow_whatsapp_contact_number', sanitize_text_field($_REQUEST['fma_oow_whatsapp_contact_number']));
		}
		////////////////////// WHATSAPP CONTACT NUMBERS ////////////////////////
		$fme_oow_notification_settings = get_option('fme_oow_notification_settings', array());
		if (isset($fme_oow_notification_settings['fme_oow_enable_user_whatsapp_approval']) && '1' == $fme_oow_notification_settings['fme_oow_enable_user_whatsapp_approval']) {
			$fme_oow_enable_user_whatsapp_approval_value = isset($_REQUEST['fme_oow_enable_user_whatsapp_approval']) ? 'yes' : 'no';
			$new_order->update_meta_data('fme_oow_enable_user_whatsapp_approval', $fme_oow_enable_user_whatsapp_approval_value);
		}
		$oow_order_status = get_option('oow_order_status');
		$new_order->update_status($oow_order_status, '', true);
		wc_reduce_stock_levels($new_order->get_id());
		$new_order->calculate_totals();
		$fma_order_on_whatsapp_cart_details[0]['recived_url'] = $new_order->get_checkout_order_received_url();
		// view order url 
		$view_order_url = $new_order->get_view_order_url();
		$fma_order_on_whatsapp_cart_details[0]['order_id'] = $new_order->get_id();
		$fmaPaymentMethodLabel = $new_order->get_payment_method_title();
	}

	if (! isset($fma_order_on_whatsapp_cart_details[0])) {
		$fma_order_on_whatsapp_cart_details[0] = array();
	}

	$fma_oow_send_pay_now_link = get_option('fma_oow_send_pay_now_link');
	if ('yes' === $fma_oow_send_pay_now_link && $create_order_in_wc && ! empty($new_order)) {
		$fma_order_on_whatsapp_cart_details[0]['fma_oow_pay_now_link'] = $new_order->get_checkout_payment_url();
	} else {
		$fma_order_on_whatsapp_cart_details[0]['fma_oow_pay_now_link'] = '';
	}

	if ($create_order_in_wc && ! empty($view_order_url)) {
		$fma_order_on_whatsapp_cart_details[0]['fma_oow_view_order_link'] = '*View order:* ' . $view_order_url;
	} else {
		$fma_order_on_whatsapp_cart_details[0]['fma_oow_view_order_link'] = '';
	}

	$fma_order_on_whatsapp_cart_details[0]['fma_payment_method'] = '*Payment Method:* ' . $fmaPaymentMethodLabel;

	WC()->cart->empty_cart();
	echo wp_json_encode($fma_order_on_whatsapp_cart_details);
	wp_die();
}

add_filter('woocommerce_form_field', 'fmaCheckoutFieldsInLabelError', 10, 4);
/**
 * Added required fields error label
 * 
 * @param  string $field
 * @param  int $key
 * @param  array $args
 * @param  string $value
 * @return string
 */
function fmaCheckoutFieldsInLabelError( $field, $key, $args, $value ) {
	if (strpos($field, '</span>') !== false && $args['required']) {
		$error = '<span class="error" style="display:none">';
		/* translators:%s Label for the field */
		$error .= sprintf(__('%s is a required field.', 'woocommerce'), $key);
		$error .= '</span>';
		$field = substr_replace($field, $error, strpos($field, '</span>'), 0);
	}
	return $field;
}

////////////////// WHATSAPP CONTACT NUMBERS //////////////////////////
add_action('woocommerce_before_order_notes', 'fme_oow_whatsapp_contact_input');

/**
 * Display whatsapp contact numbers on checkout page
 * 
 * @param  array $fields
 * @return void
 */
// function fme_oow_whatsapp_contact_input( $fields ) {
//  $fma_oow_whatsapp_contact_numbers_settings = maybe_unserialize(get_option('fma_oow_whatsapp_contact_numbers', array()));

//  $fma_oow_whatsapp_contact_input_label = maybe_unserialize(get_option('fma_oow_whatsapp_contact_input_label', ''));
//  $fma_oow_whatsapp_contact_input_label = isset($fma_oow_whatsapp_contact_input_label) && '' != $fma_oow_whatsapp_contact_input_label ? $fma_oow_whatsapp_contact_input_label : 'Select Branch';

//  $fma_oow_whatsapp_contact_numbers = isset($fma_oow_whatsapp_contact_numbers_settings['fma_oow_whatsapp_contacts']) ? $fma_oow_whatsapp_contact_numbers_settings['fma_oow_whatsapp_contacts'] : array();

//  // active numbers
//  $fma_oow_number_status = 1;
//  $items = array_values($fma_oow_whatsapp_contact_numbers);
//  $active_contacts = array_filter($items, function ( $elem ) use ( $fma_oow_number_status ) {
//      return $elem['fma_oow_whatsapp_status'] == $fma_oow_number_status;
//  });

//  if (count($fma_oow_whatsapp_contact_numbers) > 0 && count($active_contacts) > 0) {
//      // #-------------Added BY Muhammad Manahal ------------#
//      // include WhatsApp Branch number HTML on Checkout
//      include 'views/fma-oow-branch-number-checkout-html.php';
//  }
// }
function fme_oow_whatsapp_contact_input( $fields ) {
	$fma_oow_whatsapp_contact_numbers_settings = maybe_unserialize(get_option('fma_oow_whatsapp_contact_numbers', array()));

	$fma_oow_whatsapp_contact_input_label = maybe_unserialize(get_option('fma_oow_whatsapp_contact_input_label', ''));
	$fma_oow_whatsapp_contact_input_label = isset($fma_oow_whatsapp_contact_input_label) && '' != $fma_oow_whatsapp_contact_input_label ? $fma_oow_whatsapp_contact_input_label : 'Select Branch';
	$fma_oow_whatsapp_contact_input_label = WpmlHelper::translate((string) $fma_oow_whatsapp_contact_input_label, 'saved_fma_oow_whatsapp_contact_input_label');
	$fma_oow_whatsapp_contact_numbers = isset($fma_oow_whatsapp_contact_numbers_settings['fma_oow_whatsapp_contacts']) ? $fma_oow_whatsapp_contact_numbers_settings['fma_oow_whatsapp_contacts'] : array();
	$fma_oow_enable_multiple_whatsapp_num = get_option('fma_oow_enable_multiple_whatsapp_num', 'yes'); //by default yes to make compatible with older version

	if (is_array($fma_oow_whatsapp_contact_numbers)) {
		foreach ($fma_oow_whatsapp_contact_numbers as $contact_index => &$contact_row) {
			if (!empty($contact_row['fma_oow_whatsapp_name'])) {
				$contact_row['fma_oow_whatsapp_name'] = WpmlHelper::translate((string) $contact_row['fma_oow_whatsapp_name'], 'saved_fma_oow_whatsapp_name_' . $contact_index);
			}
		}
		unset($contact_row);
	}

	// active numbers
	$fma_oow_number_status = 1;
	$items = array_values($fma_oow_whatsapp_contact_numbers);
	$active_contacts = array_filter($items, function ( $elem ) use ( $fma_oow_number_status ) {
		return $elem['fma_oow_whatsapp_status'] == $fma_oow_number_status;
	});
	if ('yes' === $fma_oow_enable_multiple_whatsapp_num) {
		if (count($fma_oow_whatsapp_contact_numbers) > 0 && count($active_contacts) > 0) {
			// Check if $active_contacts has at least one valid (non-empty) contact
			$has_valid_contact = false;
			foreach ($active_contacts as $contact) {
				$name   = isset($contact['fma_oow_whatsapp_name']) ? trim($contact['fma_oow_whatsapp_name']) : '';
				$number = isset($contact['fma_oow_whatsapp_number']) ? trim($contact['fma_oow_whatsapp_number']) : '';

				if (!empty($name) && !empty($number)) {
					$has_valid_contact = true;
					break;
				}
			}
			if ($has_valid_contact) {
				// Include only when there’s at least one valid contact
				include 'views/fma-oow-branch-number-checkout-html.php';
			}
		}
	}

	// if (count($fma_oow_whatsapp_contact_numbers) > 0 && count($active_contacts) > 0) {
	//  // #-------------Added BY Muhammad Manahal ------------#
	//  // include WhatsApp Branch number HTML on Checkout
	//  include 'views/fma-oow-branch-number-checkout-html.php';
	// }
}

// ///////////////////////////  ADDED BY MUHAMMAD MANAHAL  /////////////////////////////////
/**
 * Added style for elementor builder
 * 
 * @return void
 */
function fmeEnqueueCustomElementorStyles() {
	if (is_plugin_active('elementor/elementor.php')) {
		// Enqueue your custom style
		wp_enqueue_style('fma_oow_style_css_elementor', plugins_url('assets/css/fma-order-on-whatsapp-elementor.css', __DIR__), false, FMA_OOW_VERSION);
	}
}

/**
 * Check this is elememtor page
 * 
 * @return void
 */
function is_elementor_page( $post_id ) {
	// Check if the _elementor_edit_mode meta key is set
	return get_post_meta($post_id, '_elementor_edit_mode', true) === 'builder';
}

/**
 * Check this is elememtor page
 * 
 * @return void
 */
function contains_elementor_content( $post_id ) {
	$post = get_post($post_id);
	if ($post) {
		$content = $post->post_content;
		// Check for Elementor shortcodes in the content
		return has_shortcode($content, 'elementor');
	}
	return false;
}

/**
 * Check this is elememtor page
 * 
 * @return void
 */
function is_elementor_post( $post_id ) {
	// Check if the _elementor_data meta key exists
	return get_post_meta($post_id, '_elementor_data', true) !== '';
}

add_filter('woocommerce_available_payment_gateways', 'fmaRemoveWhatsAppPaymentGateways');
/**
 * Remove WhatsApp order payment gateway from pay now page
 * 
 * @return void
 */
function fmaRemoveWhatsAppPaymentGateways( $fmaAvailableGateways ) {
	if ( is_checkout() && isset($_GET['pay_for_order']) && 'true' == $_GET['pay_for_order'] ) {
		$fmaGatewaysToHide = array( 'whatsapp_payment' );

		foreach ($fmaGatewaysToHide as $gatewayId) {
			if (isset($fmaAvailableGateways[$gatewayId])) {
				unset($fmaAvailableGateways[$gatewayId]);
			}
		}
	}
	return $fmaAvailableGateways;
}
// ///////////////////////////  ADDED BY MUHAMMAD MANAHAL  /////////////////////////////////
?>