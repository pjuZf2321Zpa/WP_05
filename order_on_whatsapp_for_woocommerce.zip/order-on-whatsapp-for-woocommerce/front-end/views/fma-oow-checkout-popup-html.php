<!-- Checkout popup HTML  -->
<div class="fme_oc_popup" style="display:none;" role="dialog" aria-modal="true" aria-hidden="true" aria-label="<?php echo esc_attr(WpmlHelper::translate(__('Checkout', 'order-on-whatsapp'), 'checkout_popup_aria_label')); ?>">
	<div class="popup_inner ">
		<i class="fa fa-times fa-2x fma_oow_close_icon"></i>
		<p>
			<div class="woocommerce fma-oow-popup-checkout-mount">
				<form name="checkout" method="post" class="checkout woocommerce-checkout fma-oow-checkout-popup-shell" action="<?php echo esc_url( wc_get_checkout_url() ); ?>" enctype="multipart/form-data" style="display:none;" aria-label="<?php echo esc_attr(WpmlHelper::translate(__('Checkout', 'order-on-whatsapp'), 'checkout_popup_form_aria_label')); ?>"></form>
			</div>
		</p>
		<p class="fme_buttons">
		<div class="fme_close_btn"><button class="button"><?php echo esc_html(WpmlHelper::translate(__('close', 'order-on-whatsapp'), 'popup_close_label')); ?></button></div>
		</p>
	</div>
</div>
