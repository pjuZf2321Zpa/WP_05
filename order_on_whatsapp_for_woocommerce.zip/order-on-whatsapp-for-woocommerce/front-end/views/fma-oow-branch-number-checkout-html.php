<!-- check out page WhatsApp branches HTML
<div style="display:block; margin: 30px auto;">
	<label for="fma_owow_whatsapp_contact_number">
		<?php echo esc_html($fma_oow_whatsapp_contact_input_label); ?>
	</label>
	<select name="fma_oow_whatsapp_contact_number" id="fma_oow_whatsapp_contact_number"
		class="fma_oow_whatsapp_contact_number" style="display:block; width:100%;">
		<option value=''>
			<?php echo esc_html($fma_oow_whatsapp_contact_input_label); ?>
		</option>
		<?php
		if (is_array($active_contacts) && !empty($active_contacts)) {
			foreach ($active_contacts as $index => $contact) {
				?>
					<option value='<?php echo esc_attr($contact['fma_oow_whatsapp_number']); ?>'>
						<?php echo esc_attr($contact['fma_oow_whatsapp_name']); ?>
					</option>
				<?php 
			}
		}
		?>
	</select>
</div> -->

<!-- check out page WhatsApp branches HTML -->
<div style="display:block; margin: 30px auto;">
	<label for="fma_owow_whatsapp_contact_number">
		<?php echo esc_html($fma_oow_whatsapp_contact_input_label); ?>
	</label>

	<select name="fma_oow_whatsapp_contact_number" id="fma_oow_whatsapp_contact_number"
		class="fma_oow_whatsapp_contact_number" style="display:block; width:100%;">
		
		<option value=''>
			<?php echo esc_html($fma_oow_whatsapp_contact_input_label); ?>
		</option>

		<?php
		if (is_array($active_contacts) && !empty($active_contacts)) {
			foreach ($active_contacts as $contact) {
				$name   = isset($contact['fma_oow_whatsapp_name']) ? trim($contact['fma_oow_whatsapp_name']) : '';
				$number = isset($contact['fma_oow_whatsapp_number']) ? trim($contact['fma_oow_whatsapp_number']) : '';
				//  Skip if name or number are empty
				if (empty($name) || empty($number)) {
					continue;
				}
				?>
				<option value='<?php echo esc_attr($number); ?>'>
					<?php echo esc_html($name); ?>
				</option>
				<?php
			}
		}
		?>
	</select>
</div>