<?php
if ('on' == $fma_oow_def_icon_chk) {
	?>
	<style type="text/css">
		.fma_oow_icon {
			display: none !important;
		}

		.whatsapp_contact:before,
		.fma_order_on_whatsapp_btn_on_shop_page:before,
		.fmav_order_on_whatsapp_btn_on_shop_page:before,
		.whatsapp_contact_cart_page:before,
		.fma_oow_share_btn:before,
		.whatsapp_share_cart_page:before {
			font-size: 22px !important;
			line-height: 1;
			top: 0 !important;
		}
	</style>
	<?php

} elseif ('on' == $fma_oow_show_icon_only) {
	?>
	<style type="text/css">
		.fma_oow_btn_shop_pg,
		#fma_order_on_whatsapp_span,
		#fma_order_on_whatsapp_cart_page {
			display: none !important;
		}
		.fma_order_on_whatsapp_btn_on_shop_page,
		.fmav_order_on_whatsapp_btn_on_shop_page,
		.whatsapp_contact {
			background-color: transparent !important;
		}
		.fma_oow_icon {
			top: 0;
			display: inline-flex;
			align-items: center;
			justify-content: center;
		}
	</style>
	<?php
}