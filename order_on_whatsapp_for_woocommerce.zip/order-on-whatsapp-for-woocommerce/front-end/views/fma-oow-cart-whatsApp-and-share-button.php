<input type="hidden" value="<?php echo esc_attr(fma_oow_get_share_currency_symbol()); ?>" id='fma_oow_get_currency_symbol'>
<div class="cart_wp_share_btn fma_oow_cart_btns">

	<?php if ('yes' === $fma_order_on_whatsapp_show_on_cart_page) { ?>

		<!-- get button text here -->
		<?php $fma_order_on_whatsapp_button_text = WpmlHelper::translate((string) get_option('fma_order_on_whatsapp_button_text', true), 'saved_fma_order_on_whatsapp_button_text'); ?>
		<input type="hidden" id='cart_url' value="<?php echo esc_html(wc_get_cart_url()); ?>">
		<!-- whatsapp button -->
		<a class="button unset-style" id='whatsapp_link_cart_page' style="outline:none;">
			<div class="call-icon wal whatsapp_contact_cart_page"
				style="<?php echo esc_attr(fma_oow_get_whatsapp_button_inline_style('cart')); ?>">
				<span class="fma_oow_icon">
					<?php echo filter_var(fma_oow_get_icon_url($fma_oow_selected_icon)); ?>
				</span>
				<span id='fma_order_on_whatsapp_cart_page'>
					<?php echo esc_html($fma_order_on_whatsapp_button_text); ?>
				</span>
			</div>
		</a> <!-- whatsapp share button -->

		<?php 
	}

		// <!-- whatsapp share button -->
	if ('yes' == $fma_oow_show_share_btn_or_not) {
		if ('yes' == $fma_order_on_whatsapp_share_show_btn_on_cart_page) { 
			?>
			<a target="<?php echo esc_html($fma_oow_where_to_open_whatsapp); ?>" class="fma_oow_share_btn fma_oow_whatsap_share_btn whatsapp_share_cart_page" style="<?php echo esc_attr(fma_oow_get_share_button_inline_style('cart')); ?>" href="<?php echo esc_url(fma_oow_esc_whatsapp_send_url($fma_oow_cart_share_url)); ?>">
				<span id='fma_order_on_whatsapp_cart_page'>
					<?php echo esc_html($fma_oow_share_btn_txt); ?>
				</span>
			</a>
			<?php 
		}
	}
	?>
</div>
