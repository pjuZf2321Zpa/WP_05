<style type="text/css">
	.fma_oow_icon svg {
		fill:
			<?php echo '#' . esc_html(( $fma_icon_clr )); ?>
		;
		width:
			<?php echo esc_html(sanitize_text_field($fma_icon_size)) . 'px'; ?>
			!important;
		height:
			<?php echo esc_html(sanitize_text_field($fma_icon_size)) . 'px'; ?>
			!important;
		display: block;
		flex-shrink: 0;
	}

	.fma_oow_share_btn:before,
	.whatsapp_share_cart_page:before {
		font-size:
			<?php echo esc_html(sanitize_text_field($fma_icon_size)) . 'px'; ?>
			!important;
		line-height: 1;
	}

	.whatsapp_contact:before {
		content: "" !important;
	}

	.fma_order_on_whatsapp_btn_on_shop_page:before,
	.fmav_order_on_whatsapp_btn_on_shop_page:before {
		content: "" !important;
	}

	.whatsapp_contact_cart_page:before {
		content: "" !important;
	}
</style>