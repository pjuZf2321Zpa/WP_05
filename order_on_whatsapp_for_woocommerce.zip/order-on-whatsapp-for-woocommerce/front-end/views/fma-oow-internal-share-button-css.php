<style type="text/css">
	.fma_oow_share_btn,
	.fma_oow_share_btn_shop_pg,
	.fma_oow_share_btn_product_pg,
	.whatsapp_share_cart_page,
	.fma_oow_whatsap_share_btn {
		display: inline-flex !important;
		align-items: center;
		justify-content: center;
		box-sizing: border-box;
		text-decoration: none !important;
		<?php echo esc_html($fma_oow_share_button_padding_top); ?>
		<?php echo esc_html($fma_oow_share_button_padding_bottom); ?>
		<?php echo esc_html($fma_oow_share_button_padding_left); ?>
		<?php echo esc_html($fma_oow_share_button_padding_right); ?>
		<?php echo esc_html($fma_oow_share_button_border_radius_top); ?>
		<?php echo esc_html($fma_oow_share_button_border_radius_bottom); ?>
		<?php echo esc_html($fma_oow_share_button_border_radius_left); ?>
		<?php echo esc_html($fma_oow_share_button_border_radius_right); ?>
	}

	.fma_oow_share_btn_shop_pg {
		<?php echo esc_html($fma_oow_shop_share_btn_width); ?>
	}

	.fma_oow_share_btn_product_pg {
		<?php echo esc_html($fma_oow_prd_share_btn_width); ?>
	}

	.whatsapp_share_cart_page,
	.fma_oow_whatsap_share_btn {
		<?php echo esc_html($fma_oow_cart_share_btn_width); ?>
	}

	.fma_order_on_whatsapp_btn_on_shop_page,
	.whatsapp_contact,
	.whatsapp_contact_cart_page {
		display: inline-flex !important;
		align-items: center;
		justify-content: center;
		box-sizing: border-box;
		text-decoration: none !important;
		<?php echo esc_html($fma_oow_whatsapp_button_padding_top); ?>
		<?php echo esc_html($fma_oow_whatsapp_button_padding_bottom); ?>
		<?php echo esc_html($fma_oow_whatsapp_button_padding_left); ?>
		<?php echo esc_html($fma_oow_whatsapp_button_padding_right); ?>
		<?php echo esc_html($fma_oow_whatsapp_button_border_radius_top); ?>
		<?php echo esc_html($fma_oow_whatsapp_button_border_radius_bottom); ?>
		<?php echo esc_html($fma_oow_whatsapp_button_border_radius_left); ?>
		<?php echo esc_html($fma_oow_whatsapp_button_border_radius_right); ?>
	}

	.fma_order_on_whatsapp_btn_on_shop_page {
		<?php echo esc_html($fma_oow_shop_whatsapp_btn_width); ?>
	}

	.whatsapp_contact {
		<?php echo esc_html($fma_oow_prd_whatsapp_btn_width); ?>
	}

	.whatsapp_contact_cart_page {
		<?php echo esc_html($fma_oow_cart_whatsapp_btn_width); ?>
	}
</style>
