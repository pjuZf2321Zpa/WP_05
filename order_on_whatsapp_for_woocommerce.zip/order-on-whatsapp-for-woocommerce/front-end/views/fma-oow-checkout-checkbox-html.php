<div class="fma_options" style="display:<?php echo esc_attr($fmaOowDisplayCheckBox); ?>">
	<!-- order on whatsapp -->
	<label for="worder">
		<input type="checkbox" name="order" id="worder" value="worder">
		<?php echo esc_html(WpmlHelper::translate(__('Receive Order on WhatsApp', 'order-on-whatsapp'), 'checkout_receive_order_on_whatsapp')); ?>
	</label>
</div>
<input type="hidden" value="<?php echo esc_html($fma_oow_the_device); ?>" id='fma_oow_the_device_on_checkout'>
<input type="hidden" value="<?php echo esc_html($fma_oow_msg_when_whatsap_opens); ?>"
id='fma_oow_msg_when_whatsap_opens'>
<input type="hidden" value="<?php echo esc_html(get_woocommerce_currency_symbol()); ?>"
id='fma_oow_get_currency_symbol'>
<input type="hidden" value="<?php echo esc_html($woocommerce->cart->total); ?>"
id='fma_order_on_whatsapp_total_expense'>
<input type="hidden" value="<?php echo esc_html($fma_order_on_whatsapp_number); ?>" id='whatsapp_number_checkout_page'>