<?php


if (!class_exists('FME_OOW_Notification')) {


	class FME_OOW_Notification {
	



		private static $instance;


		/** Facebook API Credentails */
		private $fme_oow_fb_app_id;
		private $fme_oow_fb_access_token;
		private $fme_oow_fb_phone_number_id;
		private $fme_oow_fb_whatsapp_business_account_id;

		/** Check for storing if sending notification is enabled */
		private $fme_oow_enable_notifications;

		/** Check if logs are enabled then store logs */
		private $fme_oow_enable_notification_logs;


		/** Store information, if any credentials like SID, Auth Token or Whatsapp number is missing then will be false */
		private $fme_oow_valid_connection = false;

		/** Get user agreement checkbox */
		public $fme_oow_enable_user_whatsapp_approval;
		public $fme_oow_enable_user_whatsapp_approval_label;


		public function __construct() {

			// validate and initialize settings
			$this->fmeOowValidateSettings();

			// when order is placed
			add_action('woocommerce_thankyou', array( $this, 'fmeOowSendOrderPlacedNotification' ), 10, 1);


			// when order status is changed send notification
			add_action('woocommerce_order_status_changed', array( $this, 'fmeOowSendOrderStatusChangedNotification' ), 10, 4);


			// handle ajax request for creating/updating template
			add_action('wp_ajax_fmeOowCreateUpdateMessageTemplate', array( $this, 'fmeOowCreateUpdateMessageTemplate' ));


			// handle ajax request for loading notifications table
			add_action('wp_ajax_fmeOowLoadAjaxNotificationTable', array( $this, 'fmeOowLoadAjaxNotificationTable' ));


			// check if we have a checkbox enabled for getting user agreement
			if (1 == $this->fme_oow_enable_user_whatsapp_approval && 1 == $this->fme_oow_enable_notifications) {
				add_action('woocommerce_before_order_notes', array( $this, 'fmeOowInsertAgreementCheckbox' ));

				// Save custom checkbox field value to order meta
				add_action('woocommerce_checkout_create_order', array( $this, 'fmeOowSaveCheckboxFieldValue' ));
			}

			// Custom billing phone field only when notifications are enabled with valid FB credentials.
			if (1 == $this->fme_oow_enable_notifications && true === $this->fme_oow_valid_connection) {
				add_filter('woocommerce_checkout_fields', array( $this, 'fma_oow_add_custom_billing_field' ));
				add_action('woocommerce_checkout_create_order', array( $this, 'fma_save_custom_billing_phone_fields' ));
			}
		}



		/**
		 * Function to remove default billing_phone field
		 */
		public function fma_oow_add_custom_billing_field( $fields ) {
			/**
			 * Filter the phone field setting for the checkout page
			 * 
			 * @param string $phone_field_setting the phone field setting
			 * @return string the phone field setting
			 * @since 1.3.7
			 */
			$phone_field_setting = apply_filters('woocommerce_checkout_phone_field', 'required');

			if ('hidden' === $phone_field_setting) {
				return $fields;
			}

			$is_required = true;
			if ('optional' === $phone_field_setting) {
				$is_required = false;
			} elseif (isset($fields['billing']['billing_phone']['required'])) {
				$is_required = (bool) $fields['billing']['billing_phone']['required'];
			}

			unset($fields['billing']['billing_phone']);

			$fieldName = 'billing_phone';
			$fields['billing'][$fieldName] = array(
				'label' => WpmlHelper::translate(__('Phone', 'order-on-whatsapp'), 'notification_billing_phone_label'),
				'placeholder' => esc_html('+921234567899'),
				'required' => $is_required,
				'class' => array( $fieldName . '_field', 'fma_oow_billing_phone' ),
				'clear' => false,
				'id' => $fieldName,
				'type' => 'tel',
			);
			return $fields;
		}

		/**
		 * Function to add custom billing fields to order
		 */
		public function fma_save_custom_billing_phone_fields( $order ) {
			$fma_oow_billing_phone = isset($_REQUEST['billing_phone']) ? sanitize_text_field($_REQUEST['billing_phone']) : '';
			$order->set_billing_phone($fma_oow_billing_phone);
		}

		/**
		 * Function to insert checkbox to checkout page for getting user approval for receiving whatsapp notifications
		 */
		public function fmeOowInsertAgreementCheckbox( $checkout ) {

			echo '<div id="fme_oow_enable_user_whatsapp_approval"><label for="fme_oow_enable_user_whatsapp_approval">' . esc_html($this->fme_oow_enable_user_whatsapp_approval_label) . '</label>';

			woocommerce_form_field('fme_oow_enable_user_whatsapp_approval', array(
				'type'          => 'checkbox',
				'class'         => array( 'form-row-wide' ),
				'label'         => WpmlHelper::translate(__('Yes', 'order-on-whatsapp'), 'notification_approval_yes'),
			), $checkout->get_value('fme_oow_enable_user_whatsapp_approval'));

			echo '</div>';
		}


		/**
		 * Function to save the custom checkout checkbox value to order meta
		 * 
		 * @param object $order order object
		 * 
		 */
		public function fmeOowSaveCheckboxFieldValue( $order ) {
			$fme_oow_enable_user_whatsapp_approval_value = isset($_REQUEST['fme_oow_enable_user_whatsapp_approval']) ? 'yes' : 'no';
			$order->update_meta_data('fme_oow_enable_user_whatsapp_approval', $fme_oow_enable_user_whatsapp_approval_value);
		}


		/**
		 * Get instance of the FMA_OOW_Notification
		 * 
		 * @return object instance of FMA_OOW_Notification
		 */
		public static function getInstance() {
			if (!isset(self::$instance)) {
				self::$instance = new self();
			}
			return self::$instance;
		}

		/**
		 * Function responsible to validate and initialize settings
		 */
		private function fmeOowValidateSettings() {

			$fme_oow_notification_settings = get_option('fme_oow_notification_settings');

			// twilio settings
			$this->fme_oow_enable_notifications = isset($fme_oow_notification_settings['fme_oow_enable_notifications']) && '' != $fme_oow_notification_settings['fme_oow_enable_notifications'] ? esc_html($fme_oow_notification_settings['fme_oow_enable_notifications']) : '0';
			$this->fme_oow_enable_notification_logs = isset($fme_oow_notification_settings['fme_oow_enable_notification_logs']) && '' != $fme_oow_notification_settings['fme_oow_enable_notification_logs'] ? esc_html($fme_oow_notification_settings['fme_oow_enable_notification_logs']) : '0';
			$this->fme_oow_enable_user_whatsapp_approval = isset($fme_oow_notification_settings['fme_oow_enable_user_whatsapp_approval']) && '' != $fme_oow_notification_settings['fme_oow_enable_user_whatsapp_approval'] ? esc_html($fme_oow_notification_settings['fme_oow_enable_user_whatsapp_approval']) : '0';
			$this->fme_oow_enable_user_whatsapp_approval_label = isset($fme_oow_notification_settings['fme_oow_enable_user_whatsapp_approval_label']) && '' != $fme_oow_notification_settings['fme_oow_enable_user_whatsapp_approval_label'] ? esc_html($fme_oow_notification_settings['fme_oow_enable_user_whatsapp_approval_label']) : esc_html__('Receive Order Notifications via WhatsApp', 'order-on-whatsapp');
			$this->fme_oow_enable_user_whatsapp_approval_label = WpmlHelper::translate((string) $this->fme_oow_enable_user_whatsapp_approval_label, 'saved_fme_oow_enable_user_whatsapp_approval_label');

			$this->fme_oow_fb_app_id = isset($fme_oow_notification_settings['fme_oow_fb_app_id']) && '' != $fme_oow_notification_settings['fme_oow_fb_app_id'] ? esc_html($fme_oow_notification_settings['fme_oow_fb_app_id']) : '';
			$this->fme_oow_fb_access_token = isset($fme_oow_notification_settings['fme_oow_fb_access_token']) && '' != $fme_oow_notification_settings['fme_oow_fb_access_token'] ? esc_html($fme_oow_notification_settings['fme_oow_fb_access_token']) : '';
			$this->fme_oow_fb_phone_number_id = isset($fme_oow_notification_settings['fme_oow_fb_phone_number_id']) && '' != $fme_oow_notification_settings['fme_oow_fb_phone_number_id'] ? esc_html($fme_oow_notification_settings['fme_oow_fb_phone_number_id']) : '';
			$this->fme_oow_fb_whatsapp_business_account_id = isset($fme_oow_notification_settings['fme_oow_fb_whatsapp_business_account_id']) && '' != $fme_oow_notification_settings['fme_oow_fb_whatsapp_business_account_id'] ? esc_html($fme_oow_notification_settings['fme_oow_fb_whatsapp_business_account_id']) : '';



			// check if any of the information is missing make the $fme_oow_valid_connection false
			if ('' == $this->fme_oow_fb_app_id || '' == $this->fme_oow_fb_access_token || '' == $this->fme_oow_fb_phone_number_id || '' == $this->fme_oow_fb_whatsapp_business_account_id) {
				$this->fme_oow_valid_connection = false;
			} else {
				$this->fme_oow_valid_connection = true;
			}
		}



		/**
		 * Function responsible for sending order confirmation notification when order is placed
		 * 
		 * @param int $order_id
		 */
		public function fmeOowSendOrderPlacedNotification( $order_id ) {

			// if notifications are not enabled
			if (1 != $this->fme_oow_enable_notifications) {
				return false;
			}

			if (true != $this->fme_oow_valid_connection) {
				return false;
			}


			$template_name = get_option('fme_oow_order_confirmation_name_text');
			$template_language = get_option('fme_oow_order_confirmation_language');


			$order = wc_get_order($order_id);
			$recipient_number = $order->get_billing_phone();
			$customer_name = $order->get_billing_first_name() . ' ' . $order->get_billing_last_name();


			// should we send notification?
			if (!$this->fmeOowShouldNotify($order) || $order->meta_exists('fme_oow_confirmation_sent')) {
				return false;
				exit;
			}

			// add a check to order meta that can identify that the order confirmation is already sent
			$order->update_meta_data('fme_oow_confirmation_sent', 1);
			$order->save();

			$url = 'https://graph.facebook.com/v19.0/' . $this->fme_oow_fb_phone_number_id . '/messages';

			// Data to be sent
			$data = array(
				'messaging_product' => 'whatsapp',
				'to' => $recipient_number,
				'type' => 'template',
				'template' => array(
					'name' => $template_name,
					'language' => array(
						'code' => $template_language,
					),
					'components' => array(
						array(
							'type' => 'body',
							'parameters' => array(
								array( 'type' => 'text', 'text' => $customer_name ),
								array( 'type' => 'text', 'text' => $order_id ),
							),
						),
					),
				),
			);

			// Convert data to JSON format
			$json_data = json_encode($data);

			// Initialize cURL
			$ch = curl_init($url);

			// Set cURL options
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $json_data);
			curl_setopt(
				$ch,
				CURLOPT_HTTPHEADER,
				array(
					'Authorization: Bearer ' . $this->fme_oow_fb_access_token,
					'Content-Type: application/json',
				)
			);

			// Execute cURL request
			$response = curl_exec($ch);

			// insert notification log
			$m = $this->fmeOowInsertNotificationLog('Order Confirmation', $json_data, $response, 'notification_sent', $recipient_number);

			$s = false;
			// Check for errors
			if (curl_error($ch)) {
				$error = 'Error: ' . curl_error($ch);
				$s = false;
			} else {
				// Output response
				$success = 'Response: ' . $response;
				$s = true;
			}
		}

		/**
		 * Function to send order status change notification when status is changed
		 * 
		 * @param int $order_id id of the order
		 * @param string $old_status old status of order
		 * @param string $new_status new status of order
		 * @param object $order order object
		 */
		public function fmeOowSendOrderStatusChangedNotification( $order_id, $old_status, $new_status, $order ) {

			// if notifications not enabled
			if (1 != $this->fme_oow_enable_notifications) {
				return false;
			}

			// Check if the order status has changed
			if ($old_status !== $new_status) {


				if (true != $this->fme_oow_valid_connection) {
					return false;
				}


				$template_name = get_option('fme_oow_order_status_name_text');
				$template_language = get_option('fme_oow_order_status_language');

				$order = wc_get_order($order_id);
				$recipient_number = $order->get_billing_phone();
				$customer_name = $order->get_billing_first_name() . ' ' . $order->get_billing_last_name();


				// should we send notification?
				if (!$this->fmeOowShouldNotify($order)) {
					return false;
					exit;
				}


				$url = 'https://graph.facebook.com/v19.0/' . $this->fme_oow_fb_phone_number_id . '/messages';

				// Data to be sent
				$data = array(
					'messaging_product' => 'whatsapp',
					'to' => $recipient_number,
					'type' => 'template',
					'template' => array(
						'name' => $template_name,
						'language' => array(
							'code' => $template_language,
						),
						'components' => array(
							array(
								'type' => 'body',
								'parameters' => array(
									array( 'type' => 'text', 'text' => $customer_name ),
									array( 'type' => 'text', 'text' => $order_id ),
									array( 'type' => 'text', 'text' => $old_status ),
									array( 'type' => 'text', 'text' => $new_status ),
								),
							),
						),
					),
				);

				// Convert data to JSON format
				$json_data = json_encode($data);

				// Initialize cURL
				$ch = curl_init($url);

				// Set cURL options
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
				curl_setopt($ch, CURLOPT_POST, true);
				curl_setopt($ch, CURLOPT_POSTFIELDS, $json_data);
				curl_setopt(
					$ch,
					CURLOPT_HTTPHEADER,
					array(
						'Authorization: Bearer ' . $this->fme_oow_fb_access_token,
						'Content-Type: application/json',
					)
				);

				// Execute cURL request
				$response = curl_exec($ch);

				// insert notification log
				$m = $this->fmeOowInsertNotificationLog('Order Status Update', $json_data, $response, 'notification_sent', $recipient_number);

				$s = false;
				// Check for errors
				if (curl_error($ch)) {
					$error = 'Error: ' . curl_error($ch);
					$s = false;
				} else {
					// Output response
					$success = 'Response: ' . $response;
					$s = true;
				}
			}
		}


		/**
		 * Function to get message templates from facebook whatsapp api
		 * 
		 * @return array array of message templates
		 */
		public function fmeOowGetMessageTemplates() {

			// Set the URL
			$url = 'https://graph.facebook.com/v19.0/' . $this->fme_oow_fb_whatsapp_business_account_id . '/message_templates';


			// Set headers
			$headers = array(
				'Authorization: Bearer ' . $this->fme_oow_fb_access_token,
			);

			// Initialize cURL session
			$curl = curl_init();

			// Set cURL options
			curl_setopt_array(
				$curl,
				array(
					CURLOPT_URL => $url,
					CURLOPT_RETURNTRANSFER => true,
					CURLOPT_HTTPHEADER => $headers,
				)
			);

			// Execute cURL request
			$response = curl_exec($curl);

			// Check for errors
			if (curl_errno($curl)) {
				$error = 'Error: ' . curl_error($curl);
				return array();
			} else {
				return json_decode($response, true);
			}

			return array();
		}



		/**
		 * Function to create a message template using fb api
		 */

		public function fmeOowCreateUpdateMessageTemplate() {
			check_ajax_referer('admin_ajax_nonce', 'security');
			if (!current_user_can('manage_woocommerce')) {
				wp_send_json_error(array( 'message' => 'Unauthorized' ), 403);
			}

			// get data from request

			$message_template_id = isset($_REQUEST['message_template_id']) ? sanitize_text_field($_REQUEST['message_template_id']) : '';
			$message_template_name = isset($_REQUEST['message_template_name']) ? sanitize_text_field($_REQUEST['message_template_name']) : '';
			$message_template_action = isset($_REQUEST['message_template_action']) ? sanitize_text_field($_REQUEST['message_template_action']) : '';
			$message_template_text = isset($_REQUEST['message_template_text']) ? sanitize_text_field($_REQUEST['message_template_text']) : '';
			$message_template_name_text = isset($_REQUEST['message_template_name_text']) ? sanitize_text_field($_REQUEST['message_template_name_text']) : '';
			$message_template_language = isset($_REQUEST['message_template_language']) && '' != $_REQUEST['message_template_language'] ? sanitize_text_field($_REQUEST['message_template_language']) : 'en_US';


			$status = 'success';
			$message = 'Success.';



			// if template action is delete then delete the template by calling delete function
			if ('delete' == $message_template_action) {

				$d = $this->fmeOowDeleteMessageTemplate($message_template_name_text);

				if ($d) {
					$status = 'success';
					$message = esc_html__('Message template deleted successfully.');

					if ('order_status' == $message_template_name) {
						update_option('fme_oow_order_status_name_text', '');
						update_option('fme_oow_order_status_language', '');
					}
					if ('order_confirmation' == $message_template_name) {
						update_option('fme_oow_order_confirmation_name_text', '');
						update_option('fme_oow_order_confirmation_language', '');
					}
				} else {
					$status = 'error';
					$message = esc_html__('Something went wrong, please check Notification logs for more details in Woocommerce > Notification Logs.');
				}

				echo json_encode(array( 'status' => $status, 'message' => $message ));
				exit;
			}


			if ('order_status' == $message_template_name && ( false == strpos($message_template_text, '{{1}}') || false == strpos($message_template_text, '{{2}}') || false == strpos($message_template_text, '{{3}}') || false == strpos($message_template_text, '{{4}}') )) {
				$status = 'error';
				$message = 'order_status data must contain {{1}}, {{2}}, {{3}} and {{4}}';
			}

			if ('order_confirmation' == $message_template_name && ( false == strpos($message_template_text, '{{1}}') || false == strpos($message_template_text, '{{2}}') )) {
				$status = 'error';
				$message = 'order_confirmation data must contain {{1}} and {{2}}';
			}

			if ('order_status' != $message_template_name && 'order_confirmation' != $message_template_name) {
				$status = 'error';
				$message = 'Message template name is invalid!';
			}

			// check if we have error status then stop and exit;
			if ('error' == $status) {
				echo json_encode(array( 'status' => 'error', 'message' => $message ));
				exit;
			}

			$body_text = array();

			if ('order_status' == $message_template_name) {
				$body_text = array( 'Brad', '3344', 'pending', 'processing' );
				$message_template_name = '' == $message_template_name_text ? 'order_status' : sanitize_text_field($message_template_name_text);

				update_option('fme_oow_order_status_name_text', $message_template_name);
				update_option('fme_oow_order_status_language', $message_template_language);
			} elseif ('order_confirmation' == $message_template_name) {
				$body_text = array( 'Brad', '3344' );
				$message_template_name = '' == $message_template_name_text ? 'order_confirmation' : sanitize_text_field($message_template_name_text);

				update_option('fme_oow_order_confirmation_name_text', $message_template_name);
				update_option('fme_oow_order_confirmation_language', $message_template_language);
			}




			// Set the URL
			$url = 'https://graph.facebook.com/v19.0/' . $this->fme_oow_fb_whatsapp_business_account_id . '/message_templates';

			// Set the request data
			$data = array(
				'name' => $message_template_name,
				'language' => $message_template_language,
				'category' => 'UTILITY',
				'components' => array(
					array(
						'type' => 'BODY',
						'text' => $message_template_text,
						'example' => array(
							'body_text' => array(
								$body_text,
							),
						),
					),
				),
			);

			// Set headers
			$headers = array(
				'Content-Type: application/json',
				'Authorization: Bearer ' . $this->fme_oow_fb_access_token,
			);

			// Initialize cURL session
			$curl = curl_init();

			// Set cURL options
			curl_setopt_array(
				$curl,
				array(
					CURLOPT_URL => $url,
					CURLOPT_RETURNTRANSFER => true,
					CURLOPT_HTTPHEADER => $headers,
					CURLOPT_POST => true,
					CURLOPT_POSTFIELDS => json_encode($data),
				)
			);

			// Execute cURL request
			$response = curl_exec($curl);

			// insert notification log
			$log = $this->fmeOowInsertNotificationLog('Create Template', json_encode($data), maybe_serialize($response), 'create_template', '');


			// Check for errors
			if (curl_errno($curl)) {
				$status = 'error';
				$message = 'Error: ' . curl_error($curl);
			} else {
				$status = 'success';
				// Print 
				$response = json_decode($response, true);
				if (isset($response['error'])) {
					$status = 'error';
					$message = esc_html__('Something went wront. please check notification logs for details in Woocommerce > Notification Logs');
				} elseif (isset($response['id'])) {
					$status = 'success';
					$message = esc_html__('Message template successfully created with id: ') . $response['id'] . esc_html__(' and is currently ') . $response['status'];
				} else {
					$message = $response;
				}
			}

			echo json_encode(array( 'status' => $status, 'message' => $message ));

			die;
		}


		/**
		 * Function to send delete request for template to facebook
		 * 
		 * @param string $message_template_name name of the message template to be deleted
		 * 
		 * @return bool true if successful, false otherwise
		 */
		private function fmeOowDeleteMessageTemplate( $message_template_name ) {

			// Set the URL
			$url = 'https://graph.facebook.com/v19.0/' . $this->fme_oow_fb_whatsapp_business_account_id . '/message_templates';

			// Set the request data
			$data = array(
				'name' => $message_template_name,
			);

			// Set headers
			$headers = array(
				'Authorization: Bearer ' . $this->fme_oow_fb_access_token,
			);

			// Initialize cURL session
			$curl = curl_init();

			// Set cURL options
			curl_setopt_array(
				$curl,
				array(
					CURLOPT_URL => $url . '?' . http_build_query($data),
					CURLOPT_RETURNTRANSFER => true,
					CURLOPT_CUSTOMREQUEST => 'DELETE',
					CURLOPT_HTTPHEADER => $headers,
				)
			);

			// Execute cURL request
			$response = curl_exec($curl);

			// insert notification log
			$log = $this->fmeOowInsertNotificationLog('Delete Template', json_encode($data), maybe_serialize($response), 'delete_template', '');


			// Check for errors
			if (curl_errno($curl)) {
				$status = 'error';
				$message = 'Error: ' . curl_error($curl);
				return false;
			} else {
				// Print response
				$response = json_decode($response, true);
				if (isset($response['success']) && true == $response['success']) {
					return true;
				}
			}

			return false;
		}

		/**
		 * Function to store logs in custom post type fme_notification_log
		 */
		private function fmeOowInsertNotificationLog( $notification, $request_data, $api_response, $log_type = 'notification_sent', $customer_whatsapp = '' ) {

			if ( 1 != $this->fme_oow_enable_notification_logs ) {
				return false;
			}

			$args = array(
				'post_title' => $notification,
				'post_content' => $api_response,
				'post_type' => 'fme_notification_log',
				'post_status' => 'publish',
				'meta_input' => array(
					'fme_oow_log_type' => $log_type,
					'fme_oow_to_user' => $customer_whatsapp,
					'fme_oow_request_data' => $request_data,
				),
			);

			$id = wp_insert_post($args);

			return $id;
		}



		/**
		 * Function to draw the notifications table
		 * 
		 * 
		 */
		public function fmeOowDrawNotificationsTable() {


			$fme_message_templates = $this->fmeOowGetMessageTemplates();

			if (isset($fme_message_templates['error']) && '' != $fme_message_templates['error']) {
				return esc_html__('Please setup valid credentials to view/create/delete message templates.');
			} else {

				// Check if "order_status" exists
				$order_status_exists = false;
				$os_index = null;
				$order_confirmation_exists = false;
				$oc_index = null;


				// get template names
				$order_status_name_text = get_option('fme_oow_order_status_name_text');
				$order_confirmation_name_text = get_option('fme_oow_order_confirmation_name_text');

				$order_status_name_text = '' == $order_status_name_text ? 'order_status' : esc_html($order_status_name_text);
				$order_confirmation_name_text = '' == $order_confirmation_name_text ? 'order_confirmation' : esc_html($order_confirmation_name_text);


				if (isset($fme_message_templates['data'])) {
					foreach ($fme_message_templates['data'] as $key => $item) {

						if ($item['name'] == $order_status_name_text) {
							$order_status_exists = true;
							$os_index = $key;
						}

						if ($item['name'] == $order_confirmation_name_text) {
							$order_confirmation_exists = true;
							$oc_index = $key;
						}
					}
				}



				// order_status template
				$order_status_id = $order_status_exists ? $fme_message_templates['data'][$os_index]['id'] : esc_html__('Not Created!', 'order-on-whatsapp');
				$order_status_name = $order_status_exists ? $fme_message_templates['data'][$os_index]['name'] : esc_html__('order_status', 'order-on-whatsapp');
				$order_status_status = $order_status_exists ? $fme_message_templates['data'][$os_index]['status'] : esc_html__('Not Created!', 'order-on-whatsapp');
				$order_status_category = $order_status_exists ? $fme_message_templates['data'][$os_index]['category'] : esc_html__('Not Created!', 'order-on-whatsapp');
				$order_status_language = $order_status_exists ? $fme_message_templates['data'][$os_index]['language'] : 'en_US';

				$order_status_data = $order_status_exists ? $fme_message_templates['data'][$os_index]['components'][0]['text'] : 'Hi {{1}}! Regarding your order with having order id #{{2}}, we have an update for you, order status is now changed from {{3}} to {{4}}.';



				// order_confirmation template
				$order_confirmation_id = $order_confirmation_exists ? $fme_message_templates['data'][$oc_index]['id'] : esc_html__('Not Created!', 'order-on-whatsapp');
				$order_confirmation_name = $order_confirmation_exists ? $fme_message_templates['data'][$oc_index]['name'] : esc_html__('order_confirmation', 'order-on-whatsapp');
				$order_confirmation_status = $order_confirmation_exists ? $fme_message_templates['data'][$oc_index]['status'] : esc_html__('Not Created!', 'order-on-whatsapp');
				$order_confirmation_category = $order_confirmation_exists ? $fme_message_templates['data'][$oc_index]['category'] : esc_html__('Not Created!', 'order-on-whatsapp');
				$order_confirmation_language = $order_confirmation_exists ? $fme_message_templates['data'][$oc_index]['language'] : 'en_US';

				$order_confirmation_data = $order_confirmation_exists ? $fme_message_templates['data'][$oc_index]['components'][0]['text'] : 'Hi {{1}}! Thank you for placing your order. We have received your order #{{2}}, you will receive your order updates as we process it.';



				// if the order_status_name_text is empty then assign the default names to these variables
				$order_status_name_text = '' == $order_status_name_text ? $order_status_name : $order_status_name_text;
				$order_confirmation_name_text = '' == $order_confirmation_name_text ? $order_confirmation_name : $order_confirmation_name_text;


				// statuses array for facebook
				$statuses_array = array( 'APPROVED', 'PENDING', 'REJECTED' );


				// supported languages for message templates
				$message_template_supported_languages = array(
					'Afrikaans' => 'af',
					'Albanian' => 'sq',
					'Arabic' => 'ar',
					'Azerbaijani' => 'az',
					'Bengali' => 'bn',
					'Bulgarian' => 'bg',
					'Catalan' => 'ca',
					'Chinese (CHN)' => 'zh_CN',
					'Chinese (HKG)' => 'zh_HK',
					'Chinese (TAI)' => 'zh_TW',
					'Croatian' => 'hr',
					'Czech' => 'cs',
					'Danish' => 'da',
					'Dutch' => 'nl',
					'English' => 'en',
					'English (UK)' => 'en_GB',
					'English (US)' => 'en_US',
					'Estonian' => 'et',
					'Filipino' => 'fil',
					'Finnish' => 'fi',
					'French' => 'fr',
					'Georgian' => 'ka',
					'German' => 'de',
					'Greek' => 'el',
					'Gujarati' => 'gu',
					'Hausa' => 'ha',
					'Hebrew' => 'he',
					'Hindi' => 'hi',
					'Hungarian' => 'hu',
					'Indonesian' => 'id',
					'Irish' => 'ga',
					'Italian' => 'it',
					'Japanese' => 'ja',
					'Kannada' => 'kn',
					'Kazakh' => 'kk',
					'Kinyarwanda' => 'rw_RW',
					'Korean' => 'ko',
					'Kyrgyz (Kyrgyzstan)' => 'ky_KG',
					'Lao' => 'lo',
					'Latvian' => 'lv',
					'Lithuanian' => 'lt',
					'Macedonian' => 'mk',
					'Malay' => 'ms',
					'Malayalam' => 'ml',
					'Marathi' => 'mr',
					'Norwegian' => 'nb',
					'Persian' => 'fa',
					'Polish' => 'pl',
					'Portuguese (BR)' => 'pt_BR',
					'Portuguese (POR)' => 'pt_PT',
					'Punjabi' => 'pa',
					'Romanian' => 'ro',
					'Russian' => 'ru',
					'Serbian' => 'sr',
					'Slovak' => 'sk',
					'Slovenian' => 'sl',
					'Spanish' => 'es',
					'Spanish (ARG)' => 'es_AR',
					'Spanish (SPA)' => 'es_ES',
					'Spanish (MEX)' => 'es_MX',
					'Swahili' => 'sw',
					'Swedish' => 'sv',
					'Tamil' => 'ta',
					'Telugu' => 'te',
					'Thai' => 'th',
					'Turkish' => 'tr',
					'Ukrainian' => 'uk',
					'Urdu' => 'ur',
					'Uzbek' => 'uz',
					'Vietnamese' => 'vi',
					'Zulu' => 'zu',
				);


				ob_start();
				?>

				<table class="wp-list-table widefat striped" style="width: 100%;">
					<thead>
						<tr>
							<th style="padding-left: 10px;">
								<?php echo esc_html__('ID', 'order-on-whatsapp'); ?>
							</th>
							<th style="padding-left: 10px;">
								<?php echo esc_html__('Name', 'order-on-whatsapp'); ?>
							</th>
							<th style="padding-left: 10px;">
								<?php echo esc_html__('Data', 'order-on-whatsapp'); ?>
							</th>
							<th style="padding-left: 10px;">
								<?php echo esc_html__('Category', 'order-on-whatsapp'); ?>
							</th>
							<th style="padding-left: 10px;">
								<?php echo esc_html__('Language', 'order-on-whatsapp'); ?>
							</th>
							<th style="padding-left: 10px;">
								<?php echo esc_html__('Status', 'order-on-whatsapp'); ?>
							</th>
							<th style="padding-left: 10px;">
								<?php echo esc_html__('Action', 'order-on-whatsapp'); ?>
							</th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td>
								<?php echo esc_html($order_status_id); ?>
							</td>
							<td>
								<div>
									<input type="text" name="fme_oow_order_status_name_text" id="fme_oow_order_status_name_text"
										value="<?php echo esc_attr($order_status_name_text); ?>">
								</div>
							</td>
							<td>
								<textarea name="fme_oow_order_status_data" id="fme_oow_order_status_data" rows="5"
									style="display: block; width: 350px;"><?php echo esc_html($order_status_data); ?></textarea>
								{{1}} = <?php echo esc_html__('Customer Name', 'order-on-whatsapp'); ?>, {{2}} = <?php echo esc_html__('Order ID', 'order-on-whatsapp'); ?>, {{3}} = <?php echo esc_html__('Old Status', 'order-on-whatsapp'); ?>, {{4}} = <?php echo esc_html__('New Status', 'order-on-whatsapp'); ?>
							</td>
							<td>
								<?php echo esc_html($order_status_category); ?>
							</td>
							<td>
								<select name="fme_oow_order_status_language" id="fme_oow_order_status_language">
									<?php foreach ($message_template_supported_languages as $language => $code) : ?>
										<option value="<?php echo esc_attr($code); ?>" <?php selected($order_status_language, $code); ?>><?php echo esc_html($language); ?></option>
									<?php endforeach; ?>
								</select>
							</td>
							<td>
								<?php
								if (in_array($order_status_status, $statuses_array)) {
									?>
									<span class="fme_oow_template_status fme_oow_template_status_<?php echo esc_attr(strtolower($order_status_status)); ?>"><?php echo esc_html($order_status_status); ?></span>
								<?php } else { ?>
									<span class="fme_oow_template_status fme_oow_template_status_not_created"><?php echo esc_html($order_status_status); ?></span>
								<?php } ?>
							</td>
							<td>
								<?php
								if (!$order_status_exists) {
									$fme_oow_update_btn_text = esc_html__('Create Template', 'order-on-whatsapp');
									$fme_oow_template_action = 'create';
									$fme_oow_status_template_id = '';
								} else {
									$fme_oow_update_btn_text = esc_html__('Delete Template', 'order-on-whatsapp');
									$fme_oow_template_action = 'delete';
									$fme_oow_status_template_id = $order_status_id;
								}

								?>
								<button type="button" class="button button-primary" id="fme_oow_order_message_template_btn"
									data-template-id="<?php echo esc_attr($fme_oow_status_template_id); ?>" data-template="order_status"
									data-action="<?php echo esc_html($fme_oow_template_action); ?>">
									<?php echo esc_html($fme_oow_update_btn_text); ?>
								</button>
							</td>
						</tr>
						<tr>
							<td>
								<?php echo esc_html($order_confirmation_id); ?>
							</td>
							<td>
								<div>
									<input type="text" name="fme_oow_order_confirmation_name_text"
										id="fme_oow_order_confirmation_name_text" value="<?php echo esc_attr($order_confirmation_name_text); ?>">
								</div>
							</td>
							<td>
								<textarea name="fme_oow_order_confirmation_data" id="fme_oow_order_confirmation_data" rows="5"
									style="display: block; width: 350px;"><?php echo esc_html($order_confirmation_data); ?></textarea>
								<div>
									{{1}} = <?php echo esc_html__('Customer Name', 'order-on-whatsapp'); ?>, {{2}} = <?php echo esc_html__('Order ID', 'order-on-whatsapp'); ?>
								</div>
							</td>
							<td>
								<?php echo esc_html($order_confirmation_category); ?>
							</td>
							<td>
								<select name="fme_oow_order_confirmation_language" id="fme_oow_order_confirmation_language">
									<?php foreach ($message_template_supported_languages as $language => $code) : ?>
										<option value="<?php echo esc_attr($code); ?>" <?php selected($order_confirmation_language, $code); ?>><?php echo esc_html($language); ?></option>
									<?php endforeach; ?>
								</select>
							</td>
							<td>
								<?php
								if (in_array($order_confirmation_status, $statuses_array)) {
									?>
									<span class="fme_oow_template_status fme_oow_template_status_<?php echo esc_attr(strtolower($order_confirmation_status)); ?>"><?php echo esc_html($order_confirmation_status); ?></span>
								<?php } else { ?>
									<span class="fme_oow_template_status fme_oow_template_status_not_created"><?php echo esc_html($order_confirmation_status); ?></span>
								<?php } ?>
							</td>
							<td>
								<?php
								if (!$order_confirmation_exists) {
									$fme_oow_update_btn_text_oc = esc_html__('Create Template', 'order-on-whatsapp');
									$fme_oow_template_action_oc = 'create';
									$fme_oow_status_template_id_oc = '';
								} else {
									$fme_oow_update_btn_text_oc = esc_html__('Delete Template', 'order-on-whatsapp');
									$fme_oow_template_action_oc = 'delete';
									$fme_oow_status_template_id_oc = $order_confirmation_id;
								}

								?>
								<button type="button" class="button button-primary" id="fme_oow_order_message_template_btn"
									data-template-id="<?php echo esc_attr($fme_oow_status_template_id_oc); ?>"
									data-template="order_confirmation"
									data-action="<?php echo esc_html($fme_oow_template_action_oc); ?>">
									<?php echo esc_html($fme_oow_update_btn_text_oc); ?>
								</button>
							</td>
						</tr>
					</tbody>
				</table>
				<?php
			}

			return ob_get_clean();
		}



		/**
		 * Function to handle ajax request to load notifications table
		 * 
		 */
		public function fmeOowLoadAjaxNotificationTable() {
			check_ajax_referer('admin_ajax_nonce', 'security');
			if (!current_user_can('manage_woocommerce')) {
				wp_send_json_error(array( 'message' => 'Unauthorized' ), 403);
			}

			echo wp_kses_post($this->fmeOowDrawNotificationsTable()); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- admin-only HTML from escaped template parts.
			exit;
		}


		/**
		 * Function to check if notification is to be sent
		 * 
		 * @param object $order the object of order
		 * 
		 * @return boolean true if notification is to be sent, false otherwise
		 */
		private function fmeOowShouldNotify( $order ) {
			if ('1' == $this->fme_oow_enable_user_whatsapp_approval) {
				return 'yes' === $order->get_meta('fme_oow_enable_user_whatsapp_approval', true);
			}
			return true;
		}
	}


	// get the instance of the object
	$notification = FME_OOW_Notification::getInstance();
}
