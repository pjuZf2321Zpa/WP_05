<?php

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

if (!class_exists('\Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType')) {
	return;
}

require_once FMA_OOW_PLUGIN_DIR . 'whatsApp-payment-method-block-functions.php';

final class WC_Gateway_WhatsApp_Block_Support extends AbstractPaymentMethodType {


	protected $name = 'whatsapp_payment';
	private $gateway;

	public function initialize() {
		$this->gateway = new WC_Gateway_WhatsApp_Payment();
	}

	public function is_active() {
		if ( empty( get_option( 'fma_order_on_whatsapp_whatsapp_number' ) ) ) {
			return false;
		}
		return 'yes' === $this->gateway->get_option('enabled', 'yes');
	}

	public function get_payment_method_script_handles() {
		wp_register_script(
			'fma-whatsapp-block-gateway',
			FMA_OOW_PLUGIN_URL . 'assets/js/whatsApp-payments-block.js',
			array(
				'wc-blocks-registry',
				'wc-settings',
				'wp-element',
				'wp-i18n',
				'wp-html-entities',
			),
			FMA_OOW_VERSION,
			true
		);

		wp_set_script_translations('fma-whatsapp-block-gateway', 'order-on-whatsapp', FMA_OOW_PLUGIN_DIR . 'languages/');
		if (has_block('woocommerce/cart')) {

			$current_user = wp_get_current_user();
			$current_user_roles = $current_user->roles;
			$fma_order_on_whatsapp_show_on_cart_page = get_option('fma_order_on_whatsapp_show_on_cart_page', true);
			$fma_order_on_whatsapp_share_show_btn_on_cart_page = get_option('fma_order_on_whatsapp_share_show_btn_on_cart_page', true);

			if (function_exists('fma_oow_enqueue_popup_checkout_scripts')) {
				fma_oow_enqueue_popup_checkout_scripts();
			}

			$fme_wa_block_script_deps = array( 'jquery', 'woocommerce' );
			if (wp_script_is('wc-checkout', 'registered')) {
				$fme_wa_block_script_deps[] = 'wc-checkout';
			}
			if (wp_script_is('fma_order_on_whatsapp_my_script_for_whatsapp_contact', 'registered')) {
				$fme_wa_block_script_deps[] = 'fma_order_on_whatsapp_my_script_for_whatsapp_contact';
			}

			// wc blocks compatibility
			wp_enqueue_script('fme_wa_front_wc_blocks_js', FMA_OOW_PLUGIN_URL . 'assets/js/fme_wa_wc_blocks.js', $fme_wa_block_script_deps, FMA_OOW_VERSION, true);

			$theme = wp_get_theme();
			wp_localize_script('fme_wa_front_wc_blocks_js', 'fme_efw_blocks_settings', array(
				'admin_url' => admin_url('admin-ajax.php'),
				'front_ajax_nonce' => wp_create_nonce('admin_ajax_nonce'),
				'fme_enable_whatApp_btn' => $fma_order_on_whatsapp_show_on_cart_page,
				'fme_enable_share_btn' => $fma_order_on_whatsapp_share_show_btn_on_cart_page,
				'rendered_button' => fma_oow_render_cart_block_button_html(),
				'theme_name' => $theme->name,
				'is_block_theme' => $theme->is_block_theme() ? '1' : '',
				'uses_block_checkout' => fma_oow_store_uses_block_checkout() ? '1' : '',
			));
		} else {
			// Localize additional data for JS
			wp_localize_script('fma-whatsapp-block-gateway', 'FMA_WhatsApp_Data', array(
				'whatsappPaymentLabel' => __('WhatsApp Order', 'order-on-whatsapp'),
				'whatsappPaymentDescription' => __('Place Order via WhatsApp.', 'order-on-whatsapp'),
			));
		}
		return array( 'fma-whatsapp-block-gateway' );
	}

	public function get_payment_method_data() {
		return array(
			'id'          => $this->gateway->id,
			'title'       => $this->gateway->title,
			'description' => $this->gateway->description,
			'supports'    => $this->gateway->supports,
		);
	}

	/**
	 * Added WhatsApp buttons on cart page
	 *
	 * @return string
	 */
	public function fmaWhatsappButtonOnCartBlockPage() {
		return fma_oow_render_cart_block_button_html();
	}
}
