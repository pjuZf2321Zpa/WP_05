jQuery(document).ready(function () {
    const enableWhatsAppBtn = fme_efw_blocks_settings?.fme_enable_whatApp_btn === 'yes';
    const enableShareBtn = fme_efw_blocks_settings?.fme_enable_share_btn === 'yes';
    let cachedButtonHtml = fme_efw_blocks_settings?.rendered_button || '';
    let refreshButtonTimer = null;
    let refreshButtonRequest = null;

    function fmaOowGetModalFocusableElements($popup) {
        return $popup
            .find('.popup_inner')
            .find('a[href], button:not([disabled]), textarea:not([disabled]), input:not([disabled]):not([type="hidden"]), select:not([disabled]), [tabindex]:not([tabindex="-1"])')
            .filter(':visible');
    }

    function fmaOowTrapModalFocus(e) {
        var $popup = jQuery('.fme_oc_popup:visible');
        if (!$popup.length) {
            return;
        }

        var $focusable = fmaOowGetModalFocusableElements($popup);
        if (!$focusable.length) {
            return;
        }

        var first = $focusable.first()[0];
        var last = $focusable.last()[0];

        if (e.shiftKey && document.activeElement === first) {
            e.preventDefault();
            last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
            e.preventDefault();
            first.focus();
        }
    }

    var fmaOowModalPreviouslyFocused = null;

    function fmaOowOpenModal() {
        var $popup = jQuery('.fme_oc_popup');
        fmaOowModalPreviouslyFocused = document.activeElement;
        $popup.attr({ 'aria-hidden': 'false', 'aria-modal': 'true' }).fadeIn();
        jQuery('body').addClass('fma-oow-modal-open');

        var $focusable = fmaOowGetModalFocusableElements($popup);
        if ($focusable.length) {
            $focusable.first().focus();
        } else {
            $popup.find('.popup_inner').attr('tabindex', '-1').focus();
        }

        jQuery(document).on('keydown.fmaOowModalTrap', function (e) {
            if (e.key === 'Tab') {
                fmaOowTrapModalFocus(e);
            }
        });
    }

    function fmaOowCloseModal() {
        jQuery(document).off('keydown.fmaOowModalTrap');
        var $popup = jQuery('.fme_oc_popup');
        $popup.attr('aria-hidden', 'true').fadeOut();
        jQuery('body').removeClass('fma-oow-modal-open');

        if (fmaOowModalPreviouslyFocused && typeof fmaOowModalPreviouslyFocused.focus === 'function') {
            fmaOowModalPreviouslyFocused.focus();
        }
        fmaOowModalPreviouslyFocused = null;
    }

    function fmaOowApplyBlockThemeCheckoutClasses() {
        if (fme_efw_blocks_settings.is_block_theme) {
            jQuery('.fma_oow_billing_phone, .fma_oow_whatsapp_contact_number, .country_to_state, #billing_state')
                .addClass('input-text');
            jQuery('.popup_inner .fme_close_btn .button')
                .addClass('wp-element-button');
        }
    }

    jQuery(document).on("click", ".fme_close_btn, .fma_oow_close_icon", function (e) {
        e.preventDefault();
        fmaOowCloseModal();
    });

    jQuery(document).on("click", ".fme_oc_popup", function (e) {
        if (jQuery(e.target).is(".fme_oc_popup")) {
            fmaOowCloseModal();
        }
    });

    jQuery(document).on("keydown.fmaOowModal", function (e) {
        if (e.key === "Escape" && jQuery(".fme_oc_popup:visible").length) {
            fmaOowCloseModal();
        }
    });

    // Ensure required WC Block data is available
    if (window.wc && window.wp?.data && window.wc.wcBlocksData) {
        const { subscribe } = window.wp.data;
        const cartStoreKey = window.wc.wcBlocksData.CART_STORE_KEY;

        /**
         * Return WhatsApp button HTML (refreshed from server after cart changes).
         */
        function getWhatsAppButtonHtml() {
            return cachedButtonHtml;
        }

        /**
         * Fetch button HTML from server so product/category targeting matches current cart.
         */
        function refreshWhatsAppButtonHtml(callback) {
            clearTimeout(refreshButtonTimer);

            refreshButtonTimer = setTimeout(function () {
                if (refreshButtonRequest && typeof refreshButtonRequest.abort === 'function') {
                    refreshButtonRequest.abort();
                }

                refreshButtonRequest = jQuery.ajax({
                    url: fme_efw_blocks_settings.admin_url,
                    type: 'POST',
                    data: {
                        action: 'fma_oow_get_cart_block_button_html',
                        security: fme_efw_blocks_settings.front_ajax_nonce,
                    },
                    success: function (response) {
                        if (response && response.success && response.data) {
                            cachedButtonHtml = response.data.button_html || '';
                        } else {
                            cachedButtonHtml = '';
                        }

                        if (typeof callback === 'function') {
                            callback();
                        }
                    },
                    error: function () {
                        if (typeof callback === 'function') {
                            callback();
                        }
                    },
                    complete: function () {
                        refreshButtonRequest = null;
                    }
                });
            }, 300);
        }

        /**
         * Inject WhatsApp/Share buttons after cart line items.
         */
        function injectInquiryButton() {
            if (!enableWhatsAppBtn && !enableShareBtn) {
                return;
            }

            const buttonHtml = getWhatsAppButtonHtml();

            if (!buttonHtml) {
                jQuery('tr.fme-whatsapp-row').remove();
                return;
            }

            const $tbody = jQuery('.wp-block-woocommerce-cart-line-items-block tbody').first();

            if (!$tbody.length) {
                return;
            }

            let $btn = jQuery('.fme-whatsApp-button');

            if ($btn.length === 0) {
                $tbody.append(
                    `<tr class="fme-whatsapp-row"><td colspan="100%">
                        <div class="fme-whatsApp-button"></div>
                    </td></tr>`
                );
                $btn = jQuery('.fme-whatsApp-button');
            }

            $btn.html(buttonHtml).css('display', 'flex');
        }

        /**
         * On cart store change, re-fetch button HTML then inject.
         */
        function onCartChange() {
            refreshWhatsAppButtonHtml(injectInquiryButton);
        }

        subscribe(onCartChange, cartStoreKey);

        if (enableWhatsAppBtn || enableShareBtn) {
            injectInquiryButton();
        }

        /**
         * Click Event for WhatsApp button
         */
        jQuery(document).on('click', '.cart_block_order_on_WP', function (e) {
            e.preventDefault();
            onClickWhatsAppCartBlockBtn();
        });

        /**
         * Quantity buttons (refresh or re-render if needed)
         */
        jQuery(document).on('click', '.wc-block-components-quantity-selector__button--minus, .wc-block-components-quantity-selector__button--plus', function () {
            setTimeout(() => {
                location.reload();
            }, 2100); // Wait for cart update
        });

        /**
         * WhatsApp button click handler with AJAX popup
         */
        function onClickWhatsAppCartBlockBtn() {
            jQuery.ajax({
                url: fme_efw_blocks_settings.admin_url,
                type: "POST",
                data: {
                    action: "show_checkout_block_popup",
                    security: fme_efw_blocks_settings.front_ajax_nonce,
                },
                beforeSend: function () {
                    jQuery('.cart_block_order_on_WP').addClass("fma-loading");
                },
                success: function (result) {
                    if (typeof window.fmaOowOpenPopupCheckout === "function") {
                        window.fmaOowOpenPopupCheckout(result, jQuery('.cart_block_order_on_WP'));
                        return;
                    }

                    jQuery('.cart_block_order_on_WP').removeClass("fma-loading");

                    if (result.checkout_page && typeof window.fmaOowInjectCheckoutIntoPopup === "function") {
                        window.fmaOowInjectCheckoutIntoPopup(result.checkout_page);
                    } else if (result.checkout_page) {
                        if (jQuery(".popup_inner").children(".woocommerce").length === 0) {
                            jQuery(".popup_inner").prepend('<div class="woocommerce fma-oow-popup-checkout-mount"><form name="checkout" method="post" class="checkout woocommerce-checkout fma-oow-checkout-popup-shell" enctype="multipart/form-data"></form></div>');
                        }
                        jQuery(".popup_inner .fma-oow-popup-checkout-mount").html(result.checkout_page);
                    }

                    if (result.fragments) {
                        jQuery.each(result.fragments, function (key, value) {
                            jQuery(key).replaceWith(value);
                        });
                    }

                    if (typeof window.fmaOowInitPopupCheckout === "function") {
                        window.fmaOowInitPopupCheckout();
                    }

                    fmaOowOpenModal();
                    fmaOowApplyBlockThemeCheckoutClasses();
                },
                error: function (err) {
                    jQuery('.cart_block_order_on_WP').removeClass("fma-loading");
                    fmaOowCloseModal();
                    console.error("WhatsApp Popup Error", err);
                }
            });
        }
    }
});
