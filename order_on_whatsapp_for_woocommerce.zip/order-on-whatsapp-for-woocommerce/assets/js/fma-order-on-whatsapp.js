jQuery(document).ready(function () {
  var enter_name = ewcpm_php_vars.enter_name;
  var enter_1st_whatsapp_number = ewcpm_php_vars.enter_1st_whatsapp_number;
  var active = ewcpm_php_vars.active;
  var inactive = ewcpm_php_vars.inactive;
  var fma_order_on_whatsapp_payment_method_whatsapp = ewcpm_php_vars.fma_order_on_whatsapp_payment_method_whatsapp;
  
  function fmaOowGetWhatsAppOpenTarget() {
    if (
      typeof ewcpm_php_vars !== "undefined" &&
      ewcpm_php_vars &&
      ewcpm_php_vars.whatsapp_open_target === "_blank"
    ) {
      return "_blank";
    }

    return "_self";
  }

  function fmaOowOpenWhatsAppUrl(url) {
    var openTarget = fmaOowGetWhatsAppOpenTarget();
    if (openTarget === "_blank") {
      var whatsappLink = document.createElement("a");
      whatsappLink.href = url;
      whatsappLink.target = "_blank";
      whatsappLink.rel = "noopener noreferrer";
      document.body.appendChild(whatsappLink);
      whatsappLink.click();
      document.body.removeChild(whatsappLink);
      return openTarget;
    }

    location.href = url;
    return openTarget;
  }

  function getAllowedPaymentsMethods() {
    if (
      typeof fma_payments_methods_chk !== "undefined" &&
      fma_payments_methods_chk &&
      typeof fma_payments_methods_chk.alloud_or_not !== "undefined"
    ) {
      return fma_payments_methods_chk.alloud_or_not;
    }

    return "";
  }

  function fmaOowGetActiveCheckoutForm(context) {
    var $context = context ? jQuery(context) : jQuery();
    var $form = jQuery();

    if ($context.length) {
      $form = $context.closest("form.checkout");
      if (!$form.length && $context.is("form.checkout")) {
        $form = $context;
      }
      if (!$form.length) {
        $form = $context.find("form.checkout").first();
      }
    }

    if (!$form.length) {
      $form = jQuery(".fme_oc_popup:visible form.checkout").first();
    }
    if (!$form.length) {
      $form = jQuery("form.checkout:visible").first();
    }
    if (!$form.length) {
      $form = jQuery("form.checkout").first();
    }

    return $form;
  }

  function fmaOowFindCheckoutElement($form, selector) {
    if ($form && $form.length) {
      return $form.find(selector);
    }

    return jQuery(selector);
  }

  function fmaOowGetCheckoutValue($form, selector, fallback) {
    var value = fmaOowFindCheckoutElement($form, selector).first().val();
    if (typeof value === "undefined" || value === null) {
      return fallback;
    }

    return value;
  }

  function shouldShowWhatsAppOrderOption(context) {
    var $form = fmaOowGetActiveCheckoutForm(context);
    var allowed_payments_methods = getAllowedPaymentsMethods();

    if (allowed_payments_methods != "on") {
      return fmaOowFindCheckoutElement($form, '#payment_method_cod, input[name="payment_method"][value="cod"]').is(":checked");
    }

    return !fmaOowFindCheckoutElement($form, '#payment_method_whatsapp_payment, input[name="payment_method"][value="whatsapp_payment"]').is(":checked");
  }

  function toggleWhatsAppOrderOption(context) {
    var $form = fmaOowGetActiveCheckoutForm(context);
    var shouldShow = shouldShowWhatsAppOrderOption($form);
    var $options = fmaOowFindCheckoutElement($form, ".fma_options");

    if (shouldShow) {
      $options.show();
    } else {
      $options.hide();
    }
  }

  var fmaOowModalPreviouslyFocused = null;

  function fmaOowGetModalFocusableElements($popup) {
    return $popup
      .find(".popup_inner")
      .find(
        'a[href], button:not([disabled]), textarea:not([disabled]), input:not([disabled]):not([type="hidden"]), select:not([disabled]), [tabindex]:not([tabindex="-1"])'
      )
      .filter(":visible");
  }

  function fmaOowTrapModalFocus(e) {
    var $popup = jQuery(".fme_oc_popup:visible");
    if (!$popup.length) {
      return;
    }

    var $focusable = fmaOowGetModalFocusableElements($popup);
    if (!$focusable.length) {
      return;
    }

    var first = $focusable.first()[0];
    var last = $focusable.last()[0];

    if (e.shiftKey && document.activeElement === first) {
      e.preventDefault();
      last.focus();
    } else if (!e.shiftKey && document.activeElement === last) {
      e.preventDefault();
      first.focus();
    }
  }

  function fmaOowOpenModal() {
    var $popup = jQuery(".fme_oc_popup");
    fmaOowModalPreviouslyFocused = document.activeElement;
    $popup.attr({ "aria-hidden": "false", "aria-modal": "true" }).show();
    jQuery("body").addClass("fma-oow-modal-open");

    var $focusable = fmaOowGetModalFocusableElements($popup);
    if ($focusable.length) {
      $focusable.first().focus();
    } else {
      $popup.find(".popup_inner").attr("tabindex", "-1").focus();
    }

    jQuery(document).on("keydown.fmaOowModalTrap", function (e) {
      if (e.key === "Tab") {
        fmaOowTrapModalFocus(e);
      }
    });
  }

  function fmaOowCloseModal() {
    jQuery(document).off("keydown.fmaOowModalTrap");
    var $popup = jQuery(".fme_oc_popup");
    $popup.attr("aria-hidden", "true").hide();
    jQuery("body").removeClass("fma-oow-modal-open");
    fmaOowPopupSelect2Fixed = false;

    if (
      fmaOowModalPreviouslyFocused &&
      typeof fmaOowModalPreviouslyFocused.focus === "function"
    ) {
      fmaOowModalPreviouslyFocused.focus();
    }
    fmaOowModalPreviouslyFocused = null;
  }

  var fmaOowPopupSelect2Fixed = false;

  function fmaOowFixPopupCountrySelect2(force) {
    if (!force && fmaOowPopupSelect2Fixed) {
      return;
    }

    var $form = jQuery(".fme_oc_popup form.checkout");
    if (!$form.length || typeof jQuery.fn.select2 === "undefined") {
      return;
    }

    var didFix = false;
    ["#billing_country", "#shipping_country"].forEach(function (countrySel) {
      var $country = $form.find(countrySel);
      if (!$country.length || !$country.hasClass("select2-hidden-accessible")) {
        return;
      }

      didFix = true;
      jQuery(document.body).trigger("update_checkout");
      try {
        $country.select2("destroy");
      } catch (e) {}

      var stateSel = countrySel.replace("country", "state");
      var $state = $form.find(stateSel);
      if ($state.length && $state.hasClass("select2-hidden-accessible")) {
        try {
          $state.select2("destroy");
        } catch (e) {}
      }
      jQuery(document.body).trigger("update_checkout");
    });

    if (didFix) {
      fmaOowPopupSelect2Fixed = true;
    }
  }

  function fmaOowEnsurePopupShell() {
    if (jQuery(".fme_oc_popup").length || !jQuery(".fma_oow_btns").length) {
      return;
    }

    var checkoutUrl = ewcpm_php_vars.checkout_url || "";
    var closeLabel = ewcpm_php_vars.popup_close_label || "close";

    jQuery("body").append(
      '<div class="fme_oc_popup" style="display:none;" role="dialog" aria-modal="true" aria-hidden="true">' +
        '<div class="popup_inner">' +
        '<i class="fa fa-times fa-2x fma_oow_close_icon"></i>' +
        '<p><div class="woocommerce fma-oow-popup-checkout-mount">' +
        '<form name="checkout" method="post" class="checkout woocommerce-checkout fma-oow-checkout-popup-shell" action="' +
        checkoutUrl +
        '" enctype="multipart/form-data" style="display:none;"></form>' +
        "</div></p>" +
        '<p class="fme_buttons"><div class="fme_close_btn"><button class="button">' +
        closeLabel +
        "</button></div></p>" +
        "</div></div>"
    );

    if (typeof wc_checkout_params !== "undefined") {
      jQuery(document.body).trigger("init_checkout");
    }
  }

  var fmaOowEnsurePopupShellTimer;
  function fmaOowSchedulePopupShellCheck() {
    clearTimeout(fmaOowEnsurePopupShellTimer);
    fmaOowEnsurePopupShellTimer = setTimeout(fmaOowEnsurePopupShell, 100);
  }

  function fmaOowApplyBlockThemeCheckoutClasses() {
    if (ewcpm_php_vars.is_block_theme) {
      jQuery('.fma_oow_billing_phone, .fma_oow_whatsapp_contact_number, .country_to_state, #billing_state').addClass('input-text');
      jQuery('.popup_inner .fme_close_btn .button').addClass('wp-element-button');
    }
  }

  function fmaOowInjectCheckoutIntoPopup(checkoutPage) {
    if (!checkoutPage) {
      return;
    }

    var $mount = jQuery(".fme_oc_popup .fma-oow-popup-checkout-mount");
    if (!$mount.length) {
      if (jQuery(".popup_inner").children(".woocommerce").length === 0) {
        jQuery(".popup_inner").prepend(
          '<div class="woocommerce fma-oow-popup-checkout-mount"><form name="checkout" method="post" class="checkout woocommerce-checkout fma-oow-checkout-popup-shell" enctype="multipart/form-data"></form></div>'
        );
      }
      $mount = jQuery(".popup_inner .woocommerce").first();
    }

    var $parsed = jQuery("<div>").append(
      jQuery.parseHTML(checkoutPage, document, true)
    );
    var $incomingForm = $parsed.find("form.checkout").first();
    var $shellForm = $mount.find("form.checkout.fma-oow-checkout-popup-shell");

    if ($shellForm.length && $incomingForm.length) {
      $shellForm.html($incomingForm.html());
      if ($incomingForm.attr("action")) {
        $shellForm.attr("action", $incomingForm.attr("action"));
      }
      $shellForm.show();
    } else if ($incomingForm.length) {
      $mount.html($incomingForm.prop("outerHTML"));
    } else {
      $mount.html($parsed.html());
    }
  }

  /**
   * Classic cart already uses wc-cart for coupons. Loading wc-checkout for the
   * WhatsApp popup also binds `.woocommerce-remove-coupon`, which strips cart
   * notices. Detach only that checkout selector (cart uses `a.woocommerce-remove-coupon`).
   */
  function fmaOowIsClassicCartPage() {
    return (
      jQuery("body").hasClass("woocommerce-cart") &&
      !jQuery("body").hasClass("woocommerce-checkout")
    );
  }

  function fmaOowDetachCheckoutCouponHandlersOnCart() {
    if (!fmaOowIsClassicCartPage()) {
      return;
    }
    jQuery(document.body).off("click", ".woocommerce-remove-coupon");
    jQuery(document.body).off("keydown", ".woocommerce-remove-coupon");
  }

  /**
   * Re-bind coupon remove for the WhatsApp checkout popup only (cart page).
   */
  function fmaOowBindPopupCheckoutCouponRemove() {
    jQuery(document.body)
      .off("click.fmaOowPopupCoupon", ".fme_oc_popup .woocommerce-remove-coupon")
      .off("keydown.fmaOowPopupCoupon", ".fme_oc_popup .woocommerce-remove-coupon")
      .on("click.fmaOowPopupCoupon", ".fme_oc_popup .woocommerce-remove-coupon", function (e) {
        e.preventDefault();
        if (typeof wc_checkout_params === "undefined") {
          return;
        }

        var $link = jQuery(this);
        var coupon = $link.data("coupon");
        var $container = $link.closest(".woocommerce-checkout-review-order");

        $container.addClass("processing").block({
          message: null,
          overlayCSS: { background: "#fff", opacity: 0.6 },
        });

        jQuery.ajax({
          type: "POST",
          url: wc_checkout_params.wc_ajax_url
            .toString()
            .replace("%%endpoint%%", "remove_coupon"),
          data: {
            security: wc_checkout_params.remove_coupon_nonce,
            coupon: coupon,
          },
          dataType: "html",
          success: function (code) {
            jQuery(".fme_oc_popup .woocommerce-error, .fme_oc_popup .woocommerce-message").remove();
            $container.removeClass("processing").unblock();
            if (code) {
              jQuery(".fme_oc_popup form.checkout").before(code);
              jQuery(document.body).trigger("removed_coupon_in_checkout", [coupon]);
              jQuery(document.body).trigger("update_checkout", {
                update_shipping_method: false,
              });
            }
          },
          error: function () {
            $container.removeClass("processing").unblock();
          },
        });
      })
      .on("keydown.fmaOowPopupCoupon", ".fme_oc_popup .woocommerce-remove-coupon", function (e) {
        if (e.key === " ") {
          e.preventDefault();
          jQuery(this).trigger("click");
        }
      });
  }

  function fmaOowInitPopupCheckout() {
    if (typeof wc_checkout_params === "undefined") {
      return;
    }

    var $form = jQuery(".fme_oc_popup form.checkout");
    if (!$form.length) {
      return;
    }

    $form.attr("novalidate", "novalidate");

    var $shipToDifferent = $form.find("#ship-to-different-address input");
    if ($shipToDifferent.length) {
      $shipToDifferent.trigger("change");
    }

    jQuery(document.body).trigger("init_checkout");

    var $paymentMethods = $form.find('input[name="payment_method"]');
    if ($paymentMethods.length > 1) {
      var checkedPaymentMethod = $paymentMethods.filter(":checked").eq(0).prop("id");
      if (checkedPaymentMethod) {
        $form
          .find('div.payment_box:not(".' + checkedPaymentMethod + '")')
          .filter(":visible")
          .hide();
      }
    }

    if ($paymentMethods.filter(":checked").length) {
      $paymentMethods.filter(":checked").eq(0).trigger("click");
    } else {
      $paymentMethods.eq(0).prop("checked", true).trigger("click");
    }

    fmaOowBindCheckoutPlaceOrderSync();
    if (fmaOowIsClassicCartPage()) {
      fmaOowDetachCheckoutCouponHandlersOnCart();
      fmaOowBindPopupCheckoutCouponRemove();
    }
    toggleWhatsAppOrderOption($form);
    fmaOowApplyBlockThemeCheckoutClasses();
  }

  function fmaOowOpenPopupCheckout(result, button) {
    if (result.checkout_page) {
      fmaOowInjectCheckoutIntoPopup(result.checkout_page);
    }

    if (result.fragments) {
      jQuery.each(result.fragments, function (key, value) {
        jQuery(key).replaceWith(value);
      });
    }

    fmaOowInitPopupCheckout();
    fmaOowFixPopupCountrySelect2(true);
    fmaOowOpenModal();

    if (button && button.length) {
      button.removeClass("fma-loading");
    }
  }

  window.fmaOowInjectCheckoutIntoPopup = fmaOowInjectCheckoutIntoPopup;
  window.fmaOowInitPopupCheckout = fmaOowInitPopupCheckout;
  window.fmaOowOpenPopupCheckout = fmaOowOpenPopupCheckout;

  jQuery(document).on("click", ".fme_close_btn, .fma_oow_close_icon", function (e) {
    e.preventDefault();
    fmaOowCloseModal();
  });

  jQuery(document).on("click", ".fme_oc_popup", function (e) {
    if (jQuery(e.target).is(".fme_oc_popup")) {
      fmaOowCloseModal();
    }
  });

  jQuery(document).on("keydown.fmaOowModal", function (e) {
    if (e.key === "Escape" && jQuery(".fme_oc_popup:visible").length) {
      fmaOowCloseModal();
    }
  });
  
  /**
   * Check and hide/disable WhatsApp payment method if no valid number configured
   */
  function checkAndUpdateWhatsAppPaymentAvailability() {
    var whatsAppRadio = jQuery('#payment_method_whatsapp_payment');
    var whatsAppLabel = whatsAppRadio.closest('li');
    
    if (whatsAppLabel.length) {
      // Backend already handles this by filtering unavailable gateways,
      // but we add frontend logic for better UX
      if (whatsAppRadio.length && whatsAppRadio.closest('ul').length) {
        // If the radio button is not available on the page, it means backend already filtered it
        if (whatsAppRadio.closest('ul').find('[name="payment_method"]').length > 0 && 
            !jQuery('[value="whatsapp_payment"]').length) {
          // WhatsApp payment method is not available - already handled by backend
        }
      }
    }
  }
  
  // Run check on page load
  checkAndUpdateWhatsAppPaymentAvailability();
  toggleWhatsAppOrderOption();
  
  // Run check when checkout updates
  jQuery(document).on('updated_checkout', function() {
    checkAndUpdateWhatsAppPaymentAvailability();
    toggleWhatsAppOrderOption(this);
    if (jQuery(".fme_oc_popup:visible").length) {
      fmaOowFixPopupCountrySelect2();
    }
  });

  jQuery(document).on("change", 'form.checkout input[name^="payment_method"]', function () {
    toggleWhatsAppOrderOption(this);
  });

  function fmaOowSyncCheckoutOrderField() {
    var $form = fmaOowGetActiveCheckoutForm(this);
    var $worder = fmaOowFindCheckoutElement($form, "#worder");
    if (!$form.length || !$worder.length) {
      return;
    }
    if (fmaOowFindCheckoutElement($form, '#payment_method_whatsapp_payment, input[name="payment_method"][value="whatsapp_payment"]').is(":checked")) {
      $form.find("input.fma-oow-order-field-sync").remove();
      return;
    }
    $form.find("input.fma-oow-order-field-sync").remove();
    var orderValue = $worder.is(":checked") ? "worder" : "norder";
    $form.append(
      '<input type="hidden" class="fma-oow-order-field-sync" name="order" value="' +
        orderValue +
        '">'
    );
  }

  function fmaOowBindCheckoutPlaceOrderSync() {
    jQuery("form.checkout")
      .off("checkout_place_order.fmaOow")
      .on("checkout_place_order.fmaOow", fmaOowSyncCheckoutOrderField);
  }

  function fmaOowCleanupPopupCheckoutForm($form) {
    if (!$form || !$form.length) {
      $form = jQuery(".fme_oc_popup form.checkout");
    }
    if (!$form.length) {
      return;
    }
    $form.removeClass("processing").unblock();
    $form.find("#place_order").removeClass("fma-loading");
  }

  jQuery(document.body).on("checkout_place_order_success.fmaOowPopup", function (e, result) {
    if (!jQuery(".fme_oc_popup:visible").length) {
      return;
    }
    fmaOowCleanupPopupCheckoutForm(jQuery(".fme_oc_popup form.checkout"));
    fmaOowCloseModal();

    if (!result || !result.redirect) {
      return;
    }

    var redirectUrl =
      -1 === result.redirect.indexOf("https://") ||
      -1 === result.redirect.indexOf("http://")
        ? result.redirect
        : decodeURI(result.redirect);

    window.location.replace(redirectUrl);
    return false;
  });

  jQuery(document.body).on("checkout_error.fmaOowPopup", function () {
    if (jQuery(".fme_oc_popup:visible").length) {
      fmaOowCleanupPopupCheckoutForm(jQuery(".fme_oc_popup form.checkout"));
    }
  });

  window.addEventListener("pageshow", function () {
    var $form = jQuery(".fme_oc_popup form.checkout");
    if ($form.hasClass("processing")) {
      fmaOowCleanupPopupCheckoutForm($form);
      fmaOowCloseModal();
    } else if (!jQuery(".fme_oc_popup:visible").length) {
      fmaOowCleanupPopupCheckoutForm();
    }
  });

  fmaOowBindCheckoutPlaceOrderSync();
  jQuery(document.body).on("init_checkout", fmaOowBindCheckoutPlaceOrderSync);

  var fma_order_on_whatsapp_name_text = ewcpm_php_vars.fma_order_on_whatsapp_name_text;
  var fma_order_on_whatsapp_company_name_text = ewcpm_php_vars.fma_order_on_whatsapp_company_name_text;
  var fma_order_on_whatsapp_country_text = ewcpm_php_vars.fma_order_on_whatsapp_country_text;
  var fma_order_on_whatsapp_street_address_text = ewcpm_php_vars.fma_order_on_whatsapp_street_address_text;
  var fma_order_on_whatsapp_town_or_city_text = ewcpm_php_vars.fma_order_on_whatsapp_town_or_city_text;
  var fma_order_on_whatsapp_state_or_country_text = ewcpm_php_vars.fma_order_on_whatsapp_state_or_country_text;
  var fma_order_on_whatsapp_post_code_or_zip_text = ewcpm_php_vars.fma_order_on_whatsapp_post_code_or_zip_text;
  var fma_order_on_whatsapp_phone_text = ewcpm_php_vars.fma_order_on_whatsapp_phone_text;
  var fma_order_on_whatsapp_quantity_text = ewcpm_php_vars.fma_order_on_whatsapp_quantity_text;
  var fma_order_on_whatsapp_products_details_text = ewcpm_php_vars.fma_order_on_whatsapp_products_details_text;
  var fma_order_on_whatsapp_user_details_text = ewcpm_php_vars.fma_order_on_whatsapp_user_details_text;
  var fma_order_on_whatsapp_order_details_text = ewcpm_php_vars.fma_order_on_whatsapp_order_details_text;
  var fma_order_on_whatsapp_date_text = ewcpm_php_vars.fma_order_on_whatsapp_date_text;
  var fma_order_on_whatsapp_user_email = ewcpm_php_vars.fma_order_on_whatsapp_user_email;
  var fma_order_on_whatsapp_total_expense = ewcpm_php_vars.fma_order_on_whatsapp_total_expense;
  var fma_order_on_whatsapp_products_list_placeholder = ewcpm_php_vars.fma_order_on_whatsapp_products_list_placeholder;
  var fma_order_on_whatsapp_categories_list_placeholder = ewcpm_php_vars.fma_order_on_whatsapp_categories_list_placeholder;
  var fma_order_on_whatsapp_order_no_text = ewcpm_php_vars.fma_order_on_whatsapp_order_no_text;
  var fma_order_on_whatsapp_product_title_text = ewcpm_php_vars.fma_order_on_whatsapp_product_title_text;
  var fma_order_on_whatsapp_price_text = ewcpm_php_vars.fma_order_on_whatsapp_price_text;
  var fma_order_on_whatsapp_link_text = ewcpm_php_vars.fma_order_on_whatsapp_link_text;
  var fma_order_on_whatsapp_pay_now_text = ewcpm_php_vars.fma_order_on_whatsapp_pay_now_text;
  var fma_order_on_whatsapp_product_link_text = ewcpm_php_vars.fma_order_on_whatsapp_product_link_text;
  var fma_ow_shipping_user_details_text = ewcpm_php_vars.fma_ow_shipping_user_details_text;

  jQuery(document).on('click', '.fme-order-on-whatsapp-dismiss-review-notice', function (e) {
    e.preventDefault();



    jQuery.post(
      ewcpm_php_vars.admin_url,
      {
        action: 'fme_order_on_whatsapp_review_notice_dismissed',
        nonce : ewcpm_php_vars.admin_ajax_nonce,
      },
      function () {
        jQuery('.fme-order-on-whatsapp-review-notice').fadeOut();
      }
    );
  });





  jQuery("#fma_oow_def_icon_chk").change(function () {
    if (jQuery("#fma_oow_def_icon_chk").is(":checked")) {
      jQuery(".fma_oow_icon_settings").hide();
    } else {
      jQuery(".fma_oow_icon_settings").show();
    }
  });
  jQuery("#fma_oow_def_icon_chk").change();
  var mut = new MutationObserver(function (mutations, mut) {
    var button = mutations[0].target;
    if (jQuery(button).hasClass("disabled")) {
      jQuery(".whatsapp_link_variable").attr("disabled", true);
    } else {
      jQuery(".whatsapp_link_variable").attr("disabled", false);
    }
  });

  fmaOowEnsurePopupShell();
  if (typeof MutationObserver !== "undefined" && document.body) {
    new MutationObserver(function () {
      fmaOowSchedulePopupShellCheck();
    }).observe(document.body, { childList: true, subtree: true });
  }

  jQuery(".fma_oow_close_icon").click(function () {
    jQuery(".fme_close_btn").click();
  });

  if (jQuery(".single_add_to_cart_button").length > 0) {
    mut.observe(document.querySelector(".single_add_to_cart_button"), {
      attributes: true,
    });
  }

  jQuery("#fma_oow_apply_on_all_products").on("change", function () {
    var selected_type = jQuery("#fma_oow_either_cats_or_prds").val();
    if (jQuery(this).is(":checked")) {
      jQuery(this).parent().parent().next().hide();
      if ("fma_order_on_whatsapp_products_list" == selected_type) {
        jQuery(this).parent().parent().next().next().hide();
      } else {
        jQuery(this).parent().parent().next().next().next().hide();
      }
    } else {
      jQuery(this).parent().parent().next().show();
      if ("fma_order_on_whatsapp_products_list" == selected_type) {
        jQuery(this).parent().parent().next().next().show();
      } else {
        jQuery(this).parent().parent().next().next().next().show();
      }
    }
  });

  if (jQuery("#fma_oow_apply_on_all_products").is(":checked")) {
    jQuery("#fma_oow_apply_on_all_products").parent().parent().next().hide();
    jQuery("#fma_oow_apply_on_all_products")
      .parent()
      .parent()
      .next()
      .next()
      .hide();
  }

  jQuery("form.checkout").on(
    "change",
    'input[name^="payment_method"]',
    function () {
      toggleWhatsAppOrderOption(this);
    }
  );

  jQuery(".whatsapp_link_variable").on("click", function () {
    "use strict";
    // e.preventDefault();
    var allowed_payments_methods = getAllowedPaymentsMethods();
    var button = jQuery(this);
    button.addClass("fma-loading");

    var product_id = jQuery("#product_id_whatsapp").val();
    var quantity = jQuery('[name="quantity"]').val() || "1";
    jQuery.ajax({
      url: ewcpm_php_vars.admin_url,
      type: "POST",
      data: {
        action: "show_checkout_popup",
        product_id,
        variation_id: jQuery('[name="variation_id"]').val(),
        security: ewcpm_php_vars.front_ajax_nonce,
        qunatity: quantity,
      },
      success: function (result) {
        fmaOowOpenPopupCheckout(result, button);
      },
      error: function (err) {
        button.removeClass("fma-loading");
        fmaOowCloseModal();
      },
    });
  });

  // Delegated: works after block theme / AJAX pagination injects new products.
jQuery('body').on("click", ".fma_order_on_whatsapp_btn_on_shop_page", function (e) {
    // e.preventDefault();
    var allowed_payments_methods = getAllowedPaymentsMethods();
    var button = jQuery(this);
    button.addClass("fma-loading");
    ("use strict");
    //var product_id = button.data("product-id");
    var product_id = jQuery(this).next().val();

    jQuery.ajax({
      url: ewcpm_php_vars.admin_url,
      type: "POST",
      data: {
        action: "show_checkout_popup",
        security: ewcpm_php_vars.front_ajax_nonce,
        product_id,
      },
      success: function (result) {
        fmaOowOpenPopupCheckout(result, button);
      },
      error: function (err) {
        button.removeClass("fma-loading");
        fmaOowCloseModal();
      },
    });
  });

  jQuery("#whatsapp_link_cart_page").on("click", function (e) {
    // e.preventDefault();
    var allowed_payments_methods = getAllowedPaymentsMethods();
    ("use strict");
    var button = jQuery(this);
    button.addClass("fma-loading");
    jQuery.ajax({
      url: ewcpm_php_vars.admin_url,
      type: "POST",
      data: {
        action: "show_checkout_popup",
        security: ewcpm_php_vars.front_ajax_nonce,
      },
      success: function (result) {
        fmaOowOpenPopupCheckout(result, button);
      },
      error: function (err) {
        button.removeClass("fma-loading");
        fmaOowCloseModal();
      },
    });
  });

  //////////////////////////////////////////////////////////////// WHATSAPP CONTACT NUMBERS //////////////////////////////////////////
  // Whatsapp buttons
  FMA_OOW_Add_Whatsapp_Button = ".fma_oow_whatsapp_add_another";
  FMA_OOW_Remove_Contact_Button = ".fma_oow_remove_contact_button";

  // whatsapp contact numbers
  FMA_OOW_Whatapp_Number_Container = ".fma_oow_whatsapp_number_wrapper";
  FMA_OOW_Enquiry_Form_Fields_Container =
    ".fma_oow_enquiry_form_fields_wrapper";

  // set on click event for add whatsapp contact number
  jQuery(document).on("click", FMA_OOW_Add_Whatsapp_Button, (e) => {
    addAnotherWhatsappNumber();
  });

  // remove contact button
  jQuery(document).on("click", FMA_OOW_Remove_Contact_Button, (e) => {
    jQuery(e.target).parent().parent().remove();
  });

  // function responsible for adding another field to whatsapp contacts
  function addAnotherWhatsappNumber() {
    var html = `
													<tr class="fma_oow_input_fields_item">
														<td>
															<input type="text" id="fma_oow_whatsapp_name" class="fma_oow_whatsapp_name" name="fma_oow_whatsapp_name[]" placeholder="${enter_name}"/>
														</td>
														<td>
															<input type="text" id="fma_oow_whatsapp_number" class="fma_oow_whatsapp_number" name="fma_oow_whatsapp_number[]" placeholder="${enter_1st_whatsapp_number}"/>
														</td>
														<td>
															<select id="fma_oow_whatsapp_status" class="fma_oow_whatsapp_status" name="fma_oow_whatsapp_status[]">
																<option value="1">${active}</option>
																<option value="0">${inactive}</option>
															</select>
														</td>
														<td>
															<button type="button" class="fma_oow_remove_button fma_oow_remove_contact_button">X</button>
														</td>
													</tr>
												`;

    jQuery(FMA_OOW_Whatapp_Number_Container).append(html);
  }

  //////////////////////////////////////////////////////////////// WHATSAPP CONTACT NUMBERS //////////////////////////////////////////

  if (typeof jQuery.fn.select2 !== 'undefined' && jQuery("#fma_order_on_whatsapp_categories_list").length) {
    jQuery("#fma_order_on_whatsapp_categories_list").select2({
      placeholder: fma_order_on_whatsapp_categories_list_placeholder,
      ajax: {
        url: ewcpm_php_vars.admin_url,
        dataType: "json",
        delay: 250,
        data: function (params) {
          return {
            action: "fme_get_category_applied_array",
            term: params.term,
            security: ewcpm_php_vars.admin_ajax_nonce,
          };
        },
        processResults: function (response) {
          return {
            results: response,
          };
        },
        cache: true,
      },
      minimumInputLength: 1,
    });
  }
  // Back end dashboard form save changes for whatsapp settings
  jQuery(document).on(
    "click",
    "#fma_order_on_whatsapp_whatsapp_save_changes_btn",
    function () {
      "use strict";
      if (jQuery("#fma_oow_enable_multiple_branches").is(":checked")) {
        var fma_oow_enable_multiple_branches = "yes";
      } else {
        var fma_oow_enable_multiple_branches = "no";
      }



      var fma_order_on_whatsapp_whatsapp_number = jQuery(
        "#fma_order_on_whatsapp_whatsapp_number"
      ).val();

      if (fma_order_on_whatsapp_whatsapp_number == "") {
        return;
      }

      var oow_order_status = jQuery("#oow_order_status").val();
      var fma_oow_all_payment_gateways =
        jQuery("#fma_oow_all_payment_gateways:checked").val() || "off";
      var fma_oow_inline_whatsapp_share_buttons =
        jQuery("#fma_oow_inline_whatsapp_share_buttons:checked").val() || "off";
      var fma_order_on_whatsapp_whatsapp_button_text = jQuery(
        "#fma_order_on_whatsapp_whatsapp_button_text"
      ).val();
      var fma_order_on_whatsapp_products_list = jQuery(
        "#fma_order_on_whatsapp_example_whatsapp_products_list"
      ).val();
      var fma_order_on_whatsapp_categories_list = jQuery(
        "#fma_order_on_whatsapp_categories_list"
      ).val();
      var fma_oow_where_to_open_whatsapp = jQuery(
        "#fma_oow_where_to_open_whatsapp"
      ).val();
      var fma_oow_where_to_place_whatsp_btn = jQuery(
        "#fma_oow_where_to_place_whatsp_btn"
      ).val();
      var fma_oow_share_btn = jQuery("#fma_oow_share_btn").val();
      var fma_oow_share_btn_txt = jQuery("#fma_oow_share_btn_txt").val();
      var fma_oow_share_btn_bg_color = jQuery(
        "#fma_oow_share_btn_bg_color"
      ).val();
      var fma_oow_share_btn_text_color = jQuery(
        "#fma_oow_share_btn_text_color"
      ).val();
      var whatsapp_btn_border_clr = jQuery(
        "#fma_order_on_whatsapp_btn_border_clr"
      ).val();
      var whatsapp_btn_border_clr_width = jQuery(
        "#fma_order_on_whatsapp_btn_border_width"
      ).val();
      var fma_oow_shop_whatsapp_btn_width = jQuery(
        "#fma_oow_shop_whatsapp_btn_width"
      ).val();
      var fma_oow_prd_whatsapp_btn_width = jQuery(
        "#fma_oow_prd_whatsapp_btn_width"
      ).val();
      var fma_oow_cart_whatsapp_btn_width = jQuery(
        "#fma_oow_cart_whatsapp_btn_width"
      ).val();
      var fma_oow_def_icon_chk =
        jQuery('input[name="fma_oow_def_icon_chk"]:checked').val() || "off";
      var fma_oow_show_icon_only =
        jQuery('input[name="fma_oow_show_icon_only"]:checked').val() || "off";
      var fma_oow_icons = jQuery('input[name="fma_oow_icons"]:checked').val();
      var fma_icon_clr = jQuery("#fma_icon_clr").val();
      var fma_icon_size = jQuery("#fma_icon_size").val();

      var share_btn_border_clr = jQuery("#fma_share_btn_border_clr").val();
      var share_btn_border_clr_width = jQuery(
        "#fma_share_btn_border_width"
      ).val();
      var fma_oow_shop_share_btn_width = jQuery(
        "#fma_oow_shop_share_btn_width"
      ).val();
      var fma_oow_prd_share_btn_width = jQuery(
        "#fma_oow_prd_share_btn_width"
      ).val();
      var fma_oow_cart_share_btn_width = jQuery(
        "#fma_oow_cart_share_btn_width"
      ).val();

      var fma_oow_msg_when_whatsap_opens = jQuery(
        "#fma_oow_msg_when_whatsap_opens"
      ).val();
      var fma_oow_whatsapp_order_message_template = jQuery(
        "#fma_oow_whatsapp_order_message_template"
      ).val() || "";
      var fma_oow_share_msg_when_whatsap_opens = jQuery(
        "#fma_oow_share_msg_when_whatsap_opens"
      ).val();
      var fma_oow_share_btn_bg_color = "#" + fma_oow_share_btn_bg_color;
      var fma_oow_share_btn_text_color = "#" + fma_oow_share_btn_text_color;
      var fma_order_on_whatsapp_either_products_or_cats = jQuery(
        "#fma_oow_either_cats_or_prds"
      ).val();
      var fma_order_on_whatsapp_cart_btn_bg_color = jQuery(
        "#fma_order_on_whatsapp_cart_btn_bg_color"
      ).val();
      var fma_order_on_whatsapp_cart_btn_text_color = jQuery(
        "#fma_order_on_whatsapp_cart_btn_text_color"
      ).val();

      var whatsapp_btn_border_clr_hash = "#" + whatsapp_btn_border_clr;
      var share_btn_border_clr_hash = "#" + share_btn_border_clr;
      var fma_order_on_whatsapp_cart_btn_bg_color_hash =
        "#" + fma_order_on_whatsapp_cart_btn_bg_color;
      var fma_order_on_whatsapp_cart_btn_text_color_hash =
        "#" + fma_order_on_whatsapp_cart_btn_text_color;
      var fma_order_on_whatsapp_show_whatsapp_btn_on_shop_page = jQuery(
        "#fma_order_on_whatsapp_show_whatsapp_btn_on_shop_page"
      ).is(":checked");

      //////////////////////////////////////////////////////////////// WHATSAPP CONTACT NUMBERS //////////////////////////////////////////////////////////////////

      var fma_oow_whatsapp_name = [];
      jQuery(".fma_oow_whatsapp_name").each(function () {
        fma_oow_whatsapp_name.push(jQuery(this).val());
      });

      var fma_oow_whatsapp_number = [];
      jQuery(".fma_oow_whatsapp_number").each(function () {
        fma_oow_whatsapp_number.push(jQuery(this).val());
      });
      var fma_oow_whatsapp_status = [];
      jQuery(".fma_oow_whatsapp_status").each(function () {
        fma_oow_whatsapp_status.push(jQuery(this).val());
      });

      //////////////////////////////////////////////////////////////// WHATSAPP CONTACT NUMBERS //////////////////////////////////////////////////////////////////

      var fma_oow_whatsapp_contact_input_label = jQuery(
        "#fma_oow_whatsapp_contact_input_label"
      ).val();

      //////////////////////////////////////////////////////////////// PADDING AND BORDER RADIUS //////////////////////////////////////////////////////////////////
      var fma_oow_whatsapp_button_padding_top = jQuery(
        "#fma_oow_whatsapp_button_padding_top"
      ).val();
      var fma_oow_whatsapp_button_padding_bottom = jQuery(
        "#fma_oow_whatsapp_button_padding_bottom"
      ).val();
      var fma_oow_whatsapp_button_padding_left = jQuery(
        "#fma_oow_whatsapp_button_padding_left"
      ).val();
      var fma_oow_whatsapp_button_padding_right = jQuery(
        "#fma_oow_whatsapp_button_padding_right"
      ).val();

      var fma_oow_whatsapp_button_border_radius_top = jQuery(
        "#fma_oow_whatsapp_button_border_radius_top"
      ).val();
      var fma_oow_whatsapp_button_border_radius_bottom = jQuery(
        "#fma_oow_whatsapp_button_border_radius_bottom"
      ).val();
      var fma_oow_whatsapp_button_border_radius_left = jQuery(
        "#fma_oow_whatsapp_button_border_radius_left"
      ).val();
      var fma_oow_whatsapp_button_border_radius_right = jQuery(
        "#fma_oow_whatsapp_button_border_radius_right"
      ).val();

      var fma_oow_share_button_padding_top = jQuery(
        "#fma_oow_share_button_padding_top"
      ).val();
      var fma_oow_share_button_padding_bottom = jQuery(
        "#fma_oow_share_button_padding_bottom"
      ).val();
      var fma_oow_share_button_padding_left = jQuery(
        "#fma_oow_share_button_padding_left"
      ).val();
      var fma_oow_share_button_padding_right = jQuery(
        "#fma_oow_share_button_padding_right"
      ).val();

      var fma_oow_share_button_border_radius_top = jQuery(
        "#fma_oow_share_button_border_radius_top"
      ).val();
      var fma_oow_share_button_border_radius_bottom = jQuery(
        "#fma_oow_share_button_border_radius_bottom"
      ).val();
      var fma_oow_share_button_border_radius_left = jQuery(
        "#fma_oow_share_button_border_radius_left"
      ).val();
      var fma_oow_share_button_border_radius_right = jQuery(
        "#fma_oow_share_button_border_radius_right"
      ).val();

      //////////////////////////////////////////////////////////////// PADDING AND BORDER RADIUS //////////////////////////////////////////////////////////////////

      /////////////////////////////////////////////////////////////////////////////////////////////////////////
      // whatsapp button checks

      if (
        jQuery("#fma_order_on_whatsapp_show_whatsapp_btn_on_shop_page").is(
          ":checked"
        )
      ) {
        var fma_order_on_whatsapp_show_whatsapp_btn_on_shop_page = "yes"; // show variable for shop page
      } else {
        fma_order_on_whatsapp_show_whatsapp_btn_on_shop_page = "no";
      }

      if (
        jQuery("#fma_order_on_whatsapp_show_whatsapp_btn_on_cart_page").is(
          ":checked"
        )
      ) {
        var fma_order_on_whatsapp_show_on_cart_page = "yes"; // show variable for cart page
      } else {
        fma_order_on_whatsapp_show_on_cart_page = "no";
      }

      if (
        jQuery(
          "#fma_order_on_whatsapp_show_whatsapp_btn_on_single_product_page"
        ).is(":checked")
      ) {
        var fma_order_on_whatsapp_show_whatsapp_btn_on_single_product_page =
          "yes"; // show variable for cart page
      } else {
        fma_order_on_whatsapp_show_whatsapp_btn_on_single_product_page = "no";
      }

      // in updates
      // checkout page functionality
      if (
        jQuery(
          "#fma_order_on_whatsapp_show_whatsapp_functionality_on_checkout_pg"
        ).is(":checked")
      ) {
        var fma_order_on_whatsapp_show_whatsapp_functionality_on_checkout_pg =
          "yes";
      } else {
        var fma_order_on_whatsapp_show_whatsapp_functionality_on_checkout_pg =
          "no";
      }

      // whatsapp button checks ends

      // share button checks
      if (
        jQuery("#fma_order_on_whatsapp_share_show_btn_on_shop_page").is(
          ":checked"
        )
      ) {
        var fma_order_on_whatsapp_share_show_btn_on_shop_page = "yes"; // show variable for shop page
      } else {
        fma_order_on_whatsapp_share_show_btn_on_shop_page = "no";
      }

      if (
        jQuery("#fma_order_on_whatsapp_share_show_btn_on_cart_page").is(
          ":checked"
        )
      ) {
        var fma_order_on_whatsapp_share_show_btn_on_cart_page = "yes"; // show variable for cart page
      } else {
        fma_order_on_whatsapp_share_show_btn_on_cart_page = "no";
      }

      if (
        jQuery(
          "#fma_order_on_whatsapp_share_show_btn_on_single_product_page"
        ).is(":checked")
      ) {
        var fma_order_on_whatsapp_share_show_btn_on_single_product_page = "yes"; // show variable for cart page
      } else {
        fma_order_on_whatsapp_share_show_btn_on_single_product_page = "no";
      }

      // in updates
      // checkout page functionality
      if (
        jQuery(
          "#fma_order_on_whatsapp_share_show_whatsapp_functionality_on_checkout_pg"
        ).is(":checked")
      ) {
        var fma_order_on_whatsapp_share_show_whatsapp_functionality_on_checkout_pg =
          "yes";
      } else {
        var fma_order_on_whatsapp_share_show_whatsapp_functionality_on_checkout_pg =
          "no";
      }

      // share button checks ends
      /////////////////////////////////////////////////////////////////////////////////////////////////////////

      if (jQuery("#fma_oow_apply_on_all_products").is(":checked")) {
        var fma_oow_apply_on_all_products = "yes";
      } else {
        var fma_oow_apply_on_all_products = "no";
      }

      if (
        jQuery("#fma_order_on_whatsapp_hide_add_to_cart_button_shop_page").is(
          ":checked"
        )
      ) {
        var fma_order_on_whatsapp_hide_add_to_cart_button_shop_page = "yes";
      } else {
        var fma_order_on_whatsapp_hide_add_to_cart_button_shop_page = "no";
      }

      if (
        jQuery(
          "#fma_order_on_whatsapp_hide_add_to_cart_button_product_page"
        ).is(":checked")
      ) {
        var fma_order_on_whatsapp_hide_add_to_cart_button_product_page = "yes";
      } else {
        var fma_order_on_whatsapp_hide_add_to_cart_button_product_page = "no";
      }

      if (jQuery("#fma_order_on_whatsa_button_on_desktop").is(":checked")) {
        var fma_order_on_whatsa_button_on_desktop = "yes";
      } else {
        var fma_order_on_whatsa_button_on_desktop = "no";
      }

      if (jQuery("#fma_oow_create_order").is(":checked")) {
        var fma_oow_create_order = "yes";
      } else {
        var fma_oow_create_order = "no";
      }

      if (jQuery("#fma_oow_show_for_customer_only").is(":checked")) {
        var fma_oow_show_for_customer_only = "yes";
      } else {
        var fma_oow_show_for_customer_only = "no";
      }

      if (jQuery("#fma_oow_send_pay_now_link").is(":checked")) {
        var fma_oow_send_pay_now_link = "yes";
      } else {
        var fma_oow_send_pay_now_link = "no";
      }


      ///////////////////////////// ADDED BY SAQIB //////////////////////////////

      var fme_oow_enable_notifications = jQuery("#fme_oow_enable_notifications").prop("checked") == true ? 1 : 0;
      var fme_oow_enable_notification_logs = jQuery("#fme_oow_enable_notification_logs").prop("checked") == true ? 1 : 0;
      var fme_oow_enable_user_whatsapp_approval = jQuery("#fme_oow_enable_user_whatsapp_approval").prop("checked") == true ? 1 : 0;
      var fme_oow_enable_user_whatsapp_approval_label = jQuery("#fme_oow_enable_user_whatsapp_approval_label").val();

      // fb credentials 
      var fme_oow_fb_app_id = jQuery("#fme_oow_fb_app_id").val();
      var fme_oow_fb_access_token = jQuery("#fme_oow_fb_access_token").val();
      var fme_oow_fb_phone_number_id = jQuery("#fme_oow_fb_phone_number_id").val();
      var fme_oow_fb_whatsapp_business_account_id = jQuery("#fme_oow_fb_whatsapp_business_account_id").val();

      ///////////////////////////// ADDED BY SAQIB //////////////////////////////

      var x = document.getElementById("snackbar");
      var ajaxurl = ewcpm_php_vars.admin_url;
      jQuery.ajax({
        url: ajaxurl,
        type: "post",
        data: {
          dataType: "json",
          action: "when_save_changes_whatsapp_btn_clicked",
          fma_oow_all_payment_gateways: fma_oow_all_payment_gateways,
          fma_oow_inline_whatsapp_share_buttons: fma_oow_inline_whatsapp_share_buttons,
          fma_order_on_whatsapp_products_list:
            fma_order_on_whatsapp_products_list,
          fma_order_on_whatsapp_categories_list:
            fma_order_on_whatsapp_categories_list,
          fma_order_on_whatsapp_whatsapp_button_text:
            fma_order_on_whatsapp_whatsapp_button_text,
          fma_order_on_whatsapp_whatsapp_number:
            fma_order_on_whatsapp_whatsapp_number,
          fma_order_on_whatsapp_either_products_or_cats:
            fma_order_on_whatsapp_either_products_or_cats,

          fma_order_on_whatsapp_show_whatsapp_btn_on_shop_page:
            fma_order_on_whatsapp_show_whatsapp_btn_on_shop_page,
          fma_order_on_whatsapp_show_on_cart_page:
            fma_order_on_whatsapp_show_on_cart_page,
          fma_order_on_whatsapp_show_whatsapp_btn_on_single_product_page:
            fma_order_on_whatsapp_show_whatsapp_btn_on_single_product_page,

          fma_order_on_whatsapp_share_show_btn_on_shop_page:
            fma_order_on_whatsapp_share_show_btn_on_shop_page,
          fma_order_on_whatsapp_share_show_btn_on_cart_page:
            fma_order_on_whatsapp_share_show_btn_on_cart_page,
          fma_order_on_whatsapp_share_show_btn_on_single_product_page:
            fma_order_on_whatsapp_share_show_btn_on_single_product_page,

          fma_order_on_whatsapp_hide_add_to_cart_button_shop_page:
            fma_order_on_whatsapp_hide_add_to_cart_button_shop_page,
          fma_order_on_whatsapp_hide_add_to_cart_button_product_page:
            fma_order_on_whatsapp_hide_add_to_cart_button_product_page,
          fma_order_on_whatsa_button_on_desktop:
            fma_order_on_whatsa_button_on_desktop,
          fma_order_on_whatsapp_cart_btn_bg_color_hash:
            fma_order_on_whatsapp_cart_btn_bg_color_hash,
          whatsapp_btn_border_clr_hash: whatsapp_btn_border_clr_hash,
          whatsapp_btn_border_clr_width: whatsapp_btn_border_clr_width,
          fma_oow_shop_whatsapp_btn_width: fma_oow_shop_whatsapp_btn_width,
          fma_oow_prd_whatsapp_btn_width: fma_oow_prd_whatsapp_btn_width,
          fma_oow_cart_whatsapp_btn_width: fma_oow_cart_whatsapp_btn_width,
          fma_oow_def_icon_chk: fma_oow_def_icon_chk,
          fma_oow_show_icon_only: fma_oow_show_icon_only,
          fma_oow_icons: fma_oow_icons,
          fma_icon_clr: fma_icon_clr,
          fma_icon_size: fma_icon_size,

          share_btn_border_clr_hash: share_btn_border_clr_hash,
          share_btn_border_clr_width: share_btn_border_clr_width,
          fma_oow_shop_share_btn_width: fma_oow_shop_share_btn_width,
          fma_oow_prd_share_btn_width: fma_oow_prd_share_btn_width,
          fma_oow_cart_share_btn_width: fma_oow_cart_share_btn_width,

          fma_order_on_whatsapp_cart_btn_text_color_hash:
            fma_order_on_whatsapp_cart_btn_text_color_hash,
          fma_oow_apply_on_all_products: fma_oow_apply_on_all_products,
          fma_order_on_whatsapp_show_whatsapp_functionality_on_checkout_pg:
            fma_order_on_whatsapp_show_whatsapp_functionality_on_checkout_pg,
          fma_oow_where_to_open_whatsapp: fma_oow_where_to_open_whatsapp,
          fma_oow_where_to_place_whatsp_btn: fma_oow_where_to_place_whatsp_btn,
          fma_oow_share_btn: fma_oow_share_btn,
          fma_oow_share_btn_txt: fma_oow_share_btn_txt,
          fma_oow_share_btn_bg_color: fma_oow_share_btn_bg_color,
          fma_oow_share_btn_text_color: fma_oow_share_btn_text_color,
          fma_oow_msg_when_whatsap_opens: fma_oow_msg_when_whatsap_opens,
          fma_oow_whatsapp_order_message_template:
            fma_oow_whatsapp_order_message_template,
          fma_oow_share_msg_when_whatsap_opens:
            fma_oow_share_msg_when_whatsap_opens,
          fma_oow_create_order: fma_oow_create_order,
          oow_order_status: oow_order_status,
          fma_oow_show_for_customer_only: fma_oow_show_for_customer_only,
          fma_oow_send_pay_now_link: fma_oow_send_pay_now_link,
          fma_oow_whatsapp_name: fma_oow_whatsapp_name,
          fma_oow_whatsapp_number: fma_oow_whatsapp_number,
          fma_oow_whatsapp_status: fma_oow_whatsapp_status,
          fma_oow_whatsapp_button_padding_top:
            fma_oow_whatsapp_button_padding_top,
          fma_oow_whatsapp_button_padding_bottom:
            fma_oow_whatsapp_button_padding_bottom,
          fma_oow_whatsapp_button_padding_left:
            fma_oow_whatsapp_button_padding_left,
          fma_oow_whatsapp_button_padding_right:
            fma_oow_whatsapp_button_padding_right,
          fma_oow_whatsapp_button_border_radius_top:
            fma_oow_whatsapp_button_border_radius_top,
          fma_oow_whatsapp_button_border_radius_bottom:
            fma_oow_whatsapp_button_border_radius_bottom,
          fma_oow_whatsapp_button_border_radius_left:
            fma_oow_whatsapp_button_border_radius_left,
          fma_oow_whatsapp_button_border_radius_right:
            fma_oow_whatsapp_button_border_radius_right,
          fma_oow_share_button_padding_top: fma_oow_share_button_padding_top,
          fma_oow_share_button_padding_bottom:
            fma_oow_share_button_padding_bottom,
          fma_oow_share_button_padding_left: fma_oow_share_button_padding_left,
          fma_oow_share_button_padding_right:
            fma_oow_share_button_padding_right,
          fma_oow_share_button_border_radius_top:
            fma_oow_share_button_border_radius_top,
          fma_oow_share_button_border_radius_bottom:
            fma_oow_share_button_border_radius_bottom,
          fma_oow_share_button_border_radius_left:
            fma_oow_share_button_border_radius_left,
          fma_oow_share_button_border_radius_right:
            fma_oow_share_button_border_radius_right,
          fma_oow_whatsapp_contact_input_label:
            fma_oow_whatsapp_contact_input_label,

          ///////////////// ADDED BY SAQIB //////////////////
          fme_oow_enable_notifications: fme_oow_enable_notifications,
          fme_oow_enable_notification_logs: fme_oow_enable_notification_logs,
          fme_oow_enable_user_whatsapp_approval: fme_oow_enable_user_whatsapp_approval,
          fme_oow_enable_user_whatsapp_approval_label: fme_oow_enable_user_whatsapp_approval_label,
          fme_oow_fb_app_id: fme_oow_fb_app_id,
          fme_oow_fb_access_token: fme_oow_fb_access_token,
          fme_oow_fb_phone_number_id: fme_oow_fb_phone_number_id,
          fme_oow_fb_whatsapp_business_account_id: fme_oow_fb_whatsapp_business_account_id,
          ///////////////// ADDED BY SAQIB //////////////////
          fma_oow_enable_multiple_branches: fma_oow_enable_multiple_branches,

          security: ewcpm_php_vars.admin_ajax_nonce,
        },
        success: function (result) {
          window.onbeforeunload = null;
          x.className = "show";
          setTimeout(function () {
            x.className = x.className.replace("show", "");
          }, 3000);
        },
        error: function (status, xhr) {
          x.innerHTML = "Error!!";
          x.className = "show";
          setTimeout(function () {
            x.className = x.className.replace("show", "");
          }, 3000);
        },
      });
    }
  ); // end of jquery when the save changes button clicked under woo

  // first check if the user wants to pay on via Cash on delivery and WhatsApp
  // if so, only then go and redirect tow whatsapp
  // don't chagne the following id, it is the default id on Checkout page
  // console.log(jQuery('#payment_method_cod').is(':checked'));   
  // if this is true, only then redirect to whatsapp
  // order details
  //  when place order is clicked, do the following
  var ajaxurl = ewcpm_php_vars.admin_url;
  jQuery("body").on("click", "#place_order", function (e) {
    var allowed_payments_methods = getAllowedPaymentsMethods();
    var button = jQuery(this);
    var $checkoutForm = fmaOowGetActiveCheckoutForm(button);
    var fmaOowCashOnDilvery = fmaOowFindCheckoutElement($checkoutForm, 'input[name="payment_method"]:checked').attr("value");
    if ("cod" != fmaOowCashOnDilvery || "whatsapp_payment" == fmaOowCashOnDilvery) {
      /* from version 1.2.3 all payment methods will be handled by thankyou page hook except cod
        Only cod will be handled through this js function
      */
      return;
    }
    ("use strict");
    var billing_fields = fmaOowFindCheckoutElement($checkoutForm, ".woocommerce-input-wrapper");
    var error = false;
    var notice_wrappers = fmaOowFindCheckoutElement($checkoutForm, ".woocommerce-notices-wrapper");
    var notice_wrapper = notice_wrappers.eq(1);
    if (!notice_wrapper.length) {
      notice_wrapper = notice_wrappers.first();
    }
    // return;
    notice_wrapper.text("");
    notice_wrapper.append('<ul class="woocommerce-error" role="alert"></ul>');
    notice_wrapper.find(".woocommerce-error").text("");
    for (let i = 0; i < billing_fields.length; i++) {
      var $fieldWrapper = jQuery(billing_fields[i]).parent();
      if ($fieldWrapper.is(":visible")) {
        var is_required = $fieldWrapper.find(".input-text").attr("aria-required");
        var error_msg = $fieldWrapper.find('.required_field .error').text();
        if (
          $fieldWrapper.parent().find(".error").length > 0 &&
          $fieldWrapper.find(".input-text").val() == "" && 'true' == is_required
        ) {
          notice_wrapper.find(".woocommerce-error").append(
            `<li>${error_msg}</li>`
          );
          error = true;
        }
      }
    }
    if (true == error) {
      if (jQuery(".popup_inner").length > 0) {
        jQuery(".popup_inner").animate({ scrollTop: 0 }, "slow");
        button.removeClass("fma-loading");
        return false;
      }
      jQuery("html, body").animate({ scrollTop: 0 }, "slow");
      button.removeClass("fma-loading");
      return false;
    }
    var d = new Date();
    var fma_order_on_whatsapp_strDate =
      d.getFullYear() + "/" + (d.getMonth() + 1) + "/" + d.getDate();

    var fma_order_on_whatsapp_total_bill = fmaOowGetCheckoutValue($checkoutForm, "#fma_order_on_whatsapp_total_expense", ""); // total bill of the user

    // line separators
    var fma_order_on_whatsapp_line_separator = "==============";
    var fma_order_pay_now_link = "";
    var fma_order_view_link = "";
    var fmaPaymentMethod = "";
    // var fmaOowCashOnDilvery = jQuery('input[name="payment_method"]:checked').attr('value');
    var whatsapp_number_checkout_page = fmaOowGetCheckoutValue($checkoutForm, "#whatsapp_number_checkout_page", "");

    // user details, on click of the place order, get them
    // DON'T change the id's of these, they are default inputs of checkout page, any omittion will cause error.

    var billing_first_name = fmaOowGetCheckoutValue($checkoutForm, "#billing_first_name, [name='billing_first_name']", "");
    var billing_last_name = fmaOowGetCheckoutValue($checkoutForm, "#billing_last_name, [name='billing_last_name']", "");
    var billing_company = fmaOowGetCheckoutValue($checkoutForm, "#billing_company, [name='billing_company']", "");
    var billing_email = fmaOowGetCheckoutValue($checkoutForm, "#billing_email, [name='billing_email']", "");
    var billing_country = fmaOowGetCheckoutValue($checkoutForm, "#billing_country, [name='billing_country']", "");
    var billing_address_1 = fmaOowGetCheckoutValue($checkoutForm, "#billing_address_1, [name='billing_address_1']", "");
    var billing_address_2 = fmaOowGetCheckoutValue($checkoutForm, "#billing_address_2, [name='billing_address_2']", "");
    var billing_city = fmaOowGetCheckoutValue($checkoutForm, "#billing_city, [name='billing_city']", "");
    var billing_state = fmaOowGetCheckoutValue($checkoutForm, "#billing_state, [name='billing_state']", "");
    var billing_postcode = fmaOowGetCheckoutValue($checkoutForm, "#billing_postcode, [name='billing_postcode']", "");
    var billing_phone = fmaOowGetCheckoutValue($checkoutForm, "#billing_phone, [name='billing_phone']", "");

    var fma_oow_billing_email = fmaOowGetCheckoutValue($checkoutForm, "#billing_email, [name='billing_email']", "");
    var fma_oow_currency = fmaOowGetCheckoutValue($checkoutForm, "#fma_oow_get_currency_symbol", "");
    var fma_oow_shipping = fmaOowGetCheckoutValue($checkoutForm, ".shipping_method:checked, input[name^='shipping_method']:checked", "");
    var fma_oow_whatsapp_contact_number = fmaOowGetCheckoutValue($checkoutForm, "#fma_oow_whatsapp_contact_number, [name='fma_oow_whatsapp_contact_number']", "");

    var different_shipping_address = "no";
    if (fmaOowFindCheckoutElement($checkoutForm, "#ship-to-different-address-checkbox, [name='ship_to_different_address']").is(':checked')) {
      different_shipping_address = "yes";
      var shipping_first_name = fmaOowGetCheckoutValue($checkoutForm, "#shipping_first_name, [name='shipping_first_name']", "");
      var shipping_last_name = fmaOowGetCheckoutValue($checkoutForm, "#shipping_last_name, [name='shipping_last_name']", "");
      var shipping_company = fmaOowGetCheckoutValue($checkoutForm, "#shipping_company, [name='shipping_company']", "");
      var shipping_country = fmaOowGetCheckoutValue($checkoutForm, "#shipping_country, [name='shipping_country']", "");
      var shipping_address_1 = fmaOowGetCheckoutValue($checkoutForm, "#shipping_address_1, [name='shipping_address_1']", "");
      var shipping_address_2 = fmaOowGetCheckoutValue($checkoutForm, "#shipping_address_2, [name='shipping_address_2']", "");
      var shipping_city = fmaOowGetCheckoutValue($checkoutForm, "#shipping_city, [name='shipping_city']", "");
      var shipping_state = fmaOowGetCheckoutValue($checkoutForm, "#shipping_state, [name='shipping_state']", "");
      var shipping_postcode = fmaOowGetCheckoutValue($checkoutForm, "#shipping_postcode, [name='shipping_postcode']", "");
      var shipping_email = billing_email ?? '';
      var shipping_phone = billing_phone ?? '';
    } else {
      var shipping_first_name = billing_first_name;
      var shipping_last_name = billing_last_name;
      var shipping_company = billing_company;
      var shipping_country = billing_country
      var shipping_address_1 = billing_address_1;
      var shipping_address_2 = billing_address_2;
      var shipping_city = billing_city;
      var shipping_state = billing_state;
      var shipping_postcode = billing_postcode;
      var shipping_email = billing_email;
      var shipping_phone = billing_phone;

    }

    // if it is enabled from backend only then show the promt of whatsapp
    if (fmaOowCashOnDilvery == "cod" || allowed_payments_methods == "on") {
      // var fma_order_on_whatsapp_yesOrNo = confirm('Do you want to continue Order Via WhatsApp ?');
      var fma_oow_the_device = fmaOowGetCheckoutValue($checkoutForm, "#fma_oow_the_device_on_checkout", "");
      var $worder = fmaOowFindCheckoutElement($checkoutForm, "#worder");
      var $fmaOptions = fmaOowFindCheckoutElement($checkoutForm, ".fma_options");
      var wcheck = $worder.is(":checked");
      var fma_order_on_whatsapp_total_bill = fmaOowGetCheckoutValue($checkoutForm, "#fma_order_on_whatsapp_total_expense", "");
      var radio_btn_exist = $fmaOptions.length;
      if (wcheck) {
        var wcheck_val = $worder.val();
        e.preventDefault();
        button.addClass("fma-loading");
        jQuery.ajax({
          url: ajaxurl,
          type: "post",
          data: {
            dataType: "json",
            billing_phone,
            billing_email,
            billing_company,
            billing_city,
            billing_first_name,
            billing_postcode,
            billing_address_1,
            billing_last_name,
            billing_country,
            billing_address_2,
            billing_state,
            fma_oow_shipping,
            different_shipping_address,
            shipping_first_name,
            shipping_last_name,
            shipping_company,
            shipping_country,
            shipping_address_1,
            shipping_address_2,
            shipping_city,
            shipping_state,
            shipping_postcode,
            fmaOowCashOnDilvery,
            fma_oow_whatsapp_contact_number,
            wcheck_val,
            security: ewcpm_php_vars.front_ajax_nonce,
            action: "when_place_order_clicked",
          },
          success: function (result) {
            var fma_order_on_whatsapp_new_result = jQuery.parseJSON(result);
            var order_id = "";
            if (
              typeof fma_order_on_whatsapp_new_result[0]["order_id"] !=
              "undefined"
            ) {
              order_id =
                "*" + fma_order_on_whatsapp_order_no_text + "* " + fma_order_on_whatsapp_new_result[0]["order_id"];
              // order_id+=fma_order_on_whatsapp_new_result[0]['order_id'];
            }
            if (
              fma_order_on_whatsapp_new_result[0]["fma_oow_pay_now_link"] != "" &&
              "undefined" != typeof fma_order_on_whatsapp_new_result[0]["fma_oow_pay_now_link"]
            ) {
              fma_order_pay_now_link += fma_order_on_whatsapp_line_separator + ' *' +
                fma_order_on_whatsapp_pay_now_text + '* ' +
                fma_order_on_whatsapp_line_separator + "%0a" +
                "*" + fma_order_on_whatsapp_link_text + "* " + fma_order_on_whatsapp_new_result[0]["fma_oow_pay_now_link"] + "%0a";
            } else {
              fma_order_pay_now_link = "";
            }
            // view order link
            if (
              fma_order_on_whatsapp_new_result[0]["fma_oow_view_order_link"] != "" &&
              "undefined" != typeof fma_order_on_whatsapp_new_result[0]["fma_oow_view_order_link"]
            ) {
              fma_order_view_link += fma_order_on_whatsapp_new_result[0]["fma_oow_view_order_link"] + "%0a";
            } else {
              fma_order_view_link = "";
            }
            // payment gateway
            if (
              fma_order_on_whatsapp_new_result[0]["fma_payment_method"] != "" &&
              "undefined" != typeof fma_order_on_whatsapp_new_result[0]["fma_payment_method"]
            ) {
              fmaPaymentMethod += fma_order_on_whatsapp_new_result[0]["fma_payment_method"];
            } else {
              fmaPaymentMethod = "";
            }
            var fma_order_on_whatsapp_links_is = "";
            var fma_oow_currency = fmaOowGetCheckoutValue($checkoutForm, "#fma_oow_get_currency_symbol", "");
            var fma_oow_msg_when_whatsap_opens = fmaOowGetCheckoutValue($checkoutForm, "#fma_oow_msg_when_whatsap_opens", "");
            fma_oow_msg_when_whatsap_opens = '*' + fma_oow_msg_when_whatsap_opens + '*';

            var fma_order_on_whatsapp_products_arr = [];
            var i = 0;
            jQuery.each(
              fma_order_on_whatsapp_new_result,
              function (key, value) {
                // get the cart details that is there in the cart

                if ("api" == fma_oow_the_device) {
                  // If We are on mobile, replace/remove the # character which breaks the message
                  value["Product_Title"] = value["Product_Title"].replace(
                    "#",
                    "--"
                  );
                }
                value["Product_Title"] = value["Product_Title"].replace(
                  "&",
                  "and"
                );
                fma_order_on_whatsapp_links_is +=
                  "*" + fma_order_on_whatsapp_product_title_text + "*  *" + value["Product_Title"] + "* %0a";
                fma_order_on_whatsapp_links_is +=
                  "*" + fma_order_on_whatsapp_price_text + "* " + fma_oow_currency + value["Product_Price"] + "%0a";
                fma_order_on_whatsapp_links_is +=
                  "*" + fma_order_on_whatsapp_quantity_text + "* " + value["Product_Quantity"] + "%0a";
                var link = value["Product_Link"];
                fma_order_on_whatsapp_links_is += "*" + fma_order_on_whatsapp_link_text + "*  " + link + "%0a";

              }
            );

            if (
              fma_oow_whatsapp_contact_number !== "" &&
              typeof fma_oow_whatsapp_contact_number !== "undefined"
            ) {
              fma_oow_whatsapp_contact_number_new =
                fma_oow_whatsapp_contact_number;
            } else {
              fma_oow_whatsapp_contact_number_new =
                whatsapp_number_checkout_page;
            }

            var codMessage =
              fma_oow_msg_when_whatsap_opens +
              "%0a" +
              fma_order_on_whatsapp_line_separator + ' *' +
              fma_order_on_whatsapp_order_details_text + "* " +
              fma_order_on_whatsapp_line_separator +
              "%0a" +
              order_id +
              "%0a*" +
              fma_order_on_whatsapp_date_text + "* " +
              fma_order_on_whatsapp_strDate +
              "%0a*" +
              fma_order_on_whatsapp_total_expense + '* ' +
              fma_oow_currency +
              fma_order_on_whatsapp_total_bill +
              "%0a" +
              fmaPaymentMethod +
              "%0a" +
              fma_order_view_link +
              "%0a" +
              fma_order_on_whatsapp_line_separator + ' *' +
              fma_order_on_whatsapp_products_details_text + '* ' +
              fma_order_on_whatsapp_line_separator +
              "%0a" +
              fma_order_on_whatsapp_links_is +
              "%0a" +
              fma_order_on_whatsapp_line_separator + ' *' +
              fma_order_on_whatsapp_user_details_text + '* ' +
              fma_order_on_whatsapp_line_separator +
              "%0a*" +
              fma_order_on_whatsapp_name_text + '* ' +
              billing_first_name +
              " " +
              billing_last_name +
              "%0a*" +
              fma_order_on_whatsapp_company_name_text + '* ' +
              billing_company +
              "%0a*" +
              fma_order_on_whatsapp_country_text + '* ' +
              billing_country +
              "%0a*" +
              fma_order_on_whatsapp_street_address_text + '* ' +
              billing_address_1 +
              " " +
              billing_address_2 +
              "%0a*" +
              fma_order_on_whatsapp_town_or_city_text + '* ' +
              billing_city +
              "%0a*" +
              fma_order_on_whatsapp_state_or_country_text + '* ' +
              billing_state +
              "%0a*" +
              fma_order_on_whatsapp_post_code_or_zip_text + '* ' +
              billing_postcode +
              "%0a*" +
              fma_order_on_whatsapp_phone_text + '* ' +
              billing_phone +
              "%0a*" +
              fma_order_on_whatsapp_user_email + '* ' +
              billing_email +
              "%0a %0a" +
              fma_order_on_whatsapp_line_separator + ' *' +
              fma_ow_shipping_user_details_text + '* ' +
              fma_order_on_whatsapp_line_separator +
              "%0a*" +
              fma_order_on_whatsapp_name_text + '* ' +
              shipping_first_name +
              " " +
              shipping_last_name +
              "%0a*" +
              fma_order_on_whatsapp_company_name_text + '* ' +
              shipping_company +
              "%0a*" +
              fma_order_on_whatsapp_country_text + '* ' +
              shipping_country +
              "%0a*" +
              fma_order_on_whatsapp_street_address_text + '* ' +
              shipping_address_1 +
              " " +
              shipping_address_2 +
              "%0a*" +
              fma_order_on_whatsapp_town_or_city_text + '* ' +
              shipping_city +
              "%0a*" +
              fma_order_on_whatsapp_state_or_country_text + '* ' +
              shipping_state +
              "%0a*" +
              fma_order_on_whatsapp_post_code_or_zip_text + '* ' +
              shipping_postcode +
              "%0a*" +
              fma_order_on_whatsapp_phone_text + '* ' +
              shipping_phone +
              "%0a*" +
              fma_order_on_whatsapp_user_email + '* ' +
              shipping_email +
              "%0a" +
              fma_order_pay_now_link;

            var url =
              "https://" +
              fma_oow_the_device +
              ".whatsapp.com/send?phone=" +
              fmaOowNormalizeWhatsAppPhoneNumber(fma_oow_whatsapp_contact_number_new) +
              "&text=" +
              fmaOowEncodeWhatsAppMessageForUrl(fmaOowNormalizeWhatsAppMessageLineBreaks(codMessage));

            button.removeClass('fma-loading');
            var openedTarget = fmaOowOpenWhatsAppUrl(url);
            if (openedTarget !== "_blank") {
              return false;
            }
            var isSafari =
              navigator.vendor &&
              navigator.vendor.indexOf("Apple") > -1 &&
              navigator.userAgent &&
              navigator.userAgent.indexOf("CriOS") == -1 &&
              navigator.userAgent.indexOf("FxiOS") == -1;

            if (isSafari) {
              location.href = url;
              // console.log("Yes it is safari");
            } else {
              // console.log("No it is not safari");
              location.reload();
            }
            return false;
          },
          complete: function () {
            button.removeClass("fma-loading");
          },
        }); // end of ajax request to get current cart
        return false;
      }
    }
  }); // end of the click of place-order button


  function Device_Type() {
    var Return_Device;
    if (
      /(up.browser|up.link|mmp|symbian|smartphone|midp|wap|phone|android|iemobile|w3c|acs\-|alav|alca|amoi|audi|avan|benq|bird|blac|blaz|brew|cell|cldc|cmd\-|dang|doco|eric|hipt|inno|ipaq|java|jigs|kddi|keji|leno|lg\-c|lg\-d|lg\-g|lge\-|maui|maxo|midp|mits|mmef|mobi|mot\-|moto|mwbp|nec\-|newt|noki|palm|pana|pant|phil|play|port|prox|qwap|sage|sams|sany|sch\-|sec\-|send|seri|sgh\-|shar|sie\-|siem|smal|smar|sony|sph\-|symb|t\-mo|teli|tim\-|tosh|tsm\-|upg1|upsi|vk\-v|voda|wap\-|wapa|wapi|wapp|wapr|webc|winw|winw|xda|xda\-) /i.test(
        navigator.userAgent
      )
    ) {
      if (
        /(tablet|ipad|playbook)|(android(?!.*(mobi|opera mini)))/i.test(
          navigator.userAgent
        )
      ) {
        Return_Device = "Tablet";
      } else {
        Return_Device = "Mobile";
      }
    } else if (
      /(tablet|ipad|playbook)|(android(?!.*(mobi|opera mini)))/i.test(
        navigator.userAgent
      )
    ) {
      Return_Device = "Tablet";
    } else {
      Return_Device = "Desktop";
    }

    return Return_Device;
  }

  // for variable product
  var fma_order_on_whatsapp_selects = jQuery(".variations select");

  var fma_order_on_whatsapp_selects_arr = [];
  jQuery.each(fma_order_on_whatsapp_selects, function (key, value) {
    fma_order_on_whatsapp_selects_arr.push(value.id);
  });
  var fma_order_on_whatsapp_lastElement =
    fma_order_on_whatsapp_selects_arr.slice(-1)[0];

  var fma_order_on_whatsapp_my_val = "";

  var product_title = jQuery(".product_title").html();
  // var product_title = jQuery('#fma_oow_product_title').val();
  var price_text = fma_order_on_whatsapp_price_text;
  var fma_order_on_whatsapp_product_link = window.location.href;

  var i = 0;
  var fma_order_on_whatsapp_aUrl = "";
  var fma_oow_currency = jQuery("#fma_oow_get_currency_symbol").val();

  function fmaOowEncodeWhatsAppMessageForUrl(text) {
    return String(text || "")
      .replace(/\r\n/g, "\n")
      .replace(/\r/g, "\n")
      .split("\n")
      .map(function (line) {
        return encodeURIComponent(line);
      })
      .join("%0a");
  }

  function fmaOowNormalizeWhatsAppMessageLineBreaks(text) {
    return String(text || "").replace(/%0a/gi, "\n");
  }

  function fmaOowNormalizeWhatsAppPhoneNumber(phone) {
    return String(phone || "").replace(/\D+/g, "");
  }

  function fmaOowBuildProductShareMessage(introMsg, productTitle, productLink, unitPrice, quantity) {
    var symbol = jQuery("#fma_oow_get_currency_symbol").val() || "";
    var unit = parseFloat(unitPrice);
    if (isNaN(unit)) {
      unit = 0;
    }
    var qty = parseInt(quantity, 10);
    if (isNaN(qty) || qty < 1) {
      qty = 1;
    }
    var lineTotal = unit * qty;
    var unitStr = unit % 1 === 0 ? String(unit) : unit.toFixed(2);
    var totalStr = lineTotal % 1 === 0 ? String(lineTotal) : lineTotal.toFixed(2);
    var priceLine = symbol + unitStr + "*" + qty + "=" + symbol + totalStr;
    var nl = "\n";

    return (
      "*" + String(introMsg || "").trim() + "*" +
      nl + "*Product:* " + productTitle +
      nl + "*Quantity:* " + qty +
      nl + "*Product Link:* " + productLink +
      nl + "*Price:* " + priceLine
    );
  }

  function fmaOowBuildProductShareUrl(phone, introMsg, productTitle, productLink, unitPrice, quantity) {
    var host = Device_Type() === "Mobile" ? "api" : "web";
    var shareText = fmaOowBuildProductShareMessage(
      introMsg,
      productTitle,
      productLink,
      unitPrice,
      quantity
    );

    return (
      "https://" +
      host +
      ".whatsapp.com/send?phone=" +
      fmaOowNormalizeWhatsAppPhoneNumber(phone) +
      "&text=" +
      fmaOowEncodeWhatsAppMessageForUrl(shareText)
    );
  }

  function fmaOowToggleSelectedVariationButtons(variationId) {
    var currentVariationId = String(variationId || "");

    jQuery(".fma_oow_btns_product_pg[data-fma-oow-selected-variation-ids]").each(function () {
      var buttons = jQuery(this);
      var parentProductSelected = buttons.attr("data-fma-oow-parent-product-selected") === "1";
      var selectedVariationIds = String(buttons.attr("data-fma-oow-selected-variation-ids") || "").split(",");

      if (parentProductSelected || selectedVariationIds.indexOf(currentVariationId) !== -1) {
        buttons.show();
      } else {
        buttons.hide();
      }
    });
  }

  jQuery(".single_variation_wrap").on("hide_variation", function () {
    fmaOowToggleSelectedVariationButtons("");
  });

  jQuery(".single_variation_wrap").on(
    "show_variation",
    function (event, variation) {
      fmaOowToggleSelectedVariationButtons(variation.variation_id);
      fma_order_on_whatsapp_whatsapp_variation_price = variation.display_price;
      var fma_main_product_link = window.location.href + "?";

      var attributes = variation.attributes;

      for (let item in attributes) {
        fma_main_product_link += `${item}=${attributes[item]}%26`;
      }

      fma_order_on_whatsapp_product_link = fma_main_product_link;
      var whatsapp_number_variable_product = jQuery(
        "#whatsapp_number_variable_product"
      ).attr("value");
      var fma_order_on_whatsapp_whatsapp_number = jQuery(
        "#fma_order_on_whatsapp_whatsapp_number"
      ).attr("value");

      //alert(whatsapp_number_variable_product);
      jQuery.each(fma_order_on_whatsapp_selects_arr, function (key, value) {
        jQuery("#" + value).each(function () {
          if (
            key < fma_order_on_whatsapp_selects_arr.length - 1 ||
            fma_order_on_whatsapp_selects_arr.length == 1
          ) {
            fma_order_on_whatsapp_my_val = jQuery(this).val() + " ";
          } else {
            fma_order_on_whatsapp_my_val += jQuery(this).val() + " ";
          }
          // fire ajax request from here, and get the relevant variation price
          // fma_order_on_whatsapp_my_val += fma_order_on_whatsapp_my_val;

          var fma_oow_linkApiOrweb = Device_Type();
          if (fma_oow_linkApiOrweb == "Mobile") {
            var fma_oow_either_mobile_or_web = "api";
          } else {
            var fma_oow_either_mobile_or_web = "web";
          }
          //var fma_order_on_whatsapp_mainUrl = jQuery('.whatsapp_link_variable').attr('href', 'https://'+fma_oow_either_mobile_or_web+'.whatsapp.com/send?phone='+whatsapp_number_variable_product+'&text=Product:'+product_title+' '+fma_order_on_whatsapp_my_val+'%0a'+fma_order_on_whatsapp_product_link_text+fma_order_on_whatsapp_product_link+'%0a'+price_text+fma_oow_currency+fma_order_on_whatsapp_whatsapp_variation_price+'%0a'+fma_order_on_whatsapp_quantity_text+1);

          var fma_order_on_whatsapp_aUrl =
            "https://" +
            fma_oow_either_mobile_or_web +
            ".whatsapp.com/send?phone=" +
            fma_order_on_whatsapp_whatsapp_number +
            "&text=*Product:* " +
            product_title +
            " " +
            fma_order_on_whatsapp_my_val +
            "%0a*" +
            fma_order_on_whatsapp_product_link_text + "* " +
            fma_order_on_whatsapp_product_link +
            "%0a*" +
            price_text + "* " +
            fma_order_on_whatsapp_whatsapp_variation_price;
          var share_msg = jQuery("#fma_oow_share_msg_when_whatsap_opens").val();
          var fma_oow_store_whatsapp_phone = (
            jQuery("#fma_order_on_whatsapp_whatsapp_number").val() ||
            jQuery("#whatsapp_number_variable_product").val() ||
            ""
          ).replace(/\D+/g, "");
          var fma_oow_share_product_title =
            product_title + " " + fma_order_on_whatsapp_my_val;
          var fma_oow_share_url_quantity = fmaOowBuildProductShareUrl(
            fma_oow_store_whatsapp_phone,
            share_msg,
            fma_oow_share_product_title,
            fma_order_on_whatsapp_product_link,
            fma_order_on_whatsapp_whatsapp_variation_price,
            1
          );
          jQuery(".fma_oow_share_btn_product_pg").attr(
            "href",
            fma_oow_share_url_quantity
          );

          jQuery(document).on(
            "change keyup",
            ".quantity .input-text",
            function () {
              jQuery(".whatsapp_link_variable").attr(
                "href",
                fma_order_on_whatsapp_aUrl +
                "%0a*Quantity:* " +
                jQuery(this).val() +
                "*" +
                fma_order_on_whatsapp_whatsapp_variation_price +
                "=" +
                fma_oow_currency +
                jQuery(this).val() *
                fma_order_on_whatsapp_whatsapp_variation_price
              );

              jQuery(".fma_oow_share_btn_product_pg").attr(
                "href",
                fmaOowBuildProductShareUrl(
                  fma_oow_store_whatsapp_phone,
                  share_msg,
                  fma_oow_share_product_title,
                  fma_order_on_whatsapp_product_link,
                  fma_order_on_whatsapp_whatsapp_variation_price,
                  jQuery(this).val()
                )
              );
            }
          );
        });
      });
    }
  ); // end of when bothe select boxes are selected and the add to cart button becomes active

  jQuery(document).on("change keyup", ".quantity .input-text", function () {
    "use strict";
    var fma_oow_currency = jQuery("#fma_oow_get_currency_symbol").val();

    var fma_order_on_whatsapp_find_device_type = Device_Type(); // function to detect type of device
    if (fma_order_on_whatsapp_find_device_type == "Mobile") {
      var fma_oow_link_api_or_web = "api";
    } else {
      var fma_oow_link_api_or_web = "web";
    }
    var fma_order_on_whatsapp_current_qty_simple_product = jQuery(this).val(); //qty
    var fma_order_on_whatsapp_product_title_simple_product =
      jQuery(".product_title").html(); //product name
    var fma_order_on_whatsapp_product_price_simple_product = jQuery(
      "#product_price_whatsapp_simple"
    ).attr("value");
    var fma_order_on_whatsapp_product_link = window.location.href;
    var fma_order_on_whatsapp_whatsapp_number = jQuery(
      "#fma_order_on_whatsapp_whatsapp_number"
    ).attr("value");
    var share_msg = jQuery("#fma_oow_share_msg_when_whatsap_opens").val() || "";
    var fma_oow_store_whatsapp_phone = String(
      jQuery("#fma_order_on_whatsapp_whatsapp_number").val() ||
      fma_order_on_whatsapp_whatsapp_number ||
      ""
    ).replace(/\D+/g, "");

    jQuery(".whatsapp_link_simple").attr(
      "href",
      "https://" +
      fma_oow_link_api_or_web +
      ".whatsapp.com/send?phone=" +
      fma_order_on_whatsapp_whatsapp_number +
      "&text=*Product:* " +
      fma_order_on_whatsapp_product_title_simple_product +
      "%0a*" +
      price_text + "* " +
      fma_order_on_whatsapp_product_price_simple_product +
      "%0a" +
      fma_oow_currency + " *" +
      fma_order_on_whatsapp_product_link_text + "* " +
      fma_order_on_whatsapp_product_link +
      "%0a*" +
      fma_order_on_whatsapp_quantity_text + "* " +
      jQuery(this).val() +
      "*" +
      fma_oow_currency +
      fma_order_on_whatsapp_product_price_simple_product +
      "=" +
      fma_oow_currency +
      jQuery(this).val() * fma_order_on_whatsapp_product_price_simple_product
    );

    if (jQuery(".fma_oow_share_btn_product_pg").length) {
      jQuery(".fma_oow_share_btn_product_pg").attr(
        "href",
        fmaOowBuildProductShareUrl(
          fma_oow_store_whatsapp_phone,
          share_msg,
          fma_order_on_whatsapp_product_title_simple_product,
          fma_order_on_whatsapp_product_link,
          fma_order_on_whatsapp_product_price_simple_product,
          fma_order_on_whatsapp_current_qty_simple_product
        )
      );
    }
  }); // end of on onchange single product quantity

  jQuery("#fma_oow_either_cats_or_prds").change(function () {
    if (jQuery(this).val() == "fma_order_on_whatsapp_products_list") {
      jQuery("#fma_oow_prods_row").show();
      jQuery("#fma_oow_cats_row").hide();
    } else if (jQuery(this).val() == "categories") {
      jQuery("#fma_oow_prods_row").hide();
      jQuery("#fma_oow_cats_row").show();
    }
  });

  // when the cart page quantity changes
  // .product-quantity
  jQuery(".shop_table .woocommerce-cart-form__cart-item ").each(function () {
    "use strict";
    jQuery(this).each(function () {
      // console.log(jQuery('.product-quantity input').val());
    });
  });

  if (
    jQuery("#fma_order_on_whatsapp_to_hide_save_chngs_btn").val() ==
    "my_sub_menu_whatsapp"
  ) {
    // console.log(jQuery('#fma_order_on_whatsapp_to_hide_save_chngs_btn').val());
    jQuery(".submit .woocommerce-save-button").hide();
  } else {
    jQuery(".submit .woocommerce-save-button").show();
  }

  // wc-checkout (loaded for WhatsApp popup) must not own cart coupon remove.
  fmaOowDetachCheckoutCouponHandlersOnCart();
  jQuery(document.body).on(
    "updated_cart_totals updated_wc_div",
    fmaOowDetachCheckoutCouponHandlersOnCart
  );

  // hide the add to cart button on product page (incl. Woodmart buy-now / sticky bar)
  function fmaOowShouldHideProductPageAtc() {
    var productPageHide = jQuery("#fma_order_on_whatsapp_btn_product_page").attr("value");
    var allProductsHide = jQuery(
      "#fma_oow_hiden_field_for_product_page_when_all_products_chkd"
    ).attr("value");
    return productPageHide === "yes" || allProductsHide === "yes";
  }

  function fmaOowIsPluginWhatsAppButton($el) {
    return $el.hasClass("btn-stickycall") || $el.hasClass("whatsapp_link");
  }

  function fmaOowHideProductPageAtcButtons() {
    if (!fmaOowShouldHideProductPageAtc()) {
      return;
    }
    jQuery(".single_add_to_cart_button").each(function () {
      if (!fmaOowIsPluginWhatsAppButton(jQuery(this))) {
        jQuery(this).hide();
      }
    });
    var woodmartSelectors = [
      "form.cart .wd-buy-now-btn",
      ".entry-summary .wd-buy-now-btn",
      ".entry-summary .wd-add-btn .add_to_cart_button",
      "form.cart .wd-add-btn .add_to_cart_button",
      ".wd-sticky-btn-cart .single_add_to_cart_button",
      ".wd-sticky-btn-cart .wd-sticky-add-to-cart",
      ".wd-sticky-btn-cart .wd-buy-now-btn",
    ];
    jQuery(woodmartSelectors.join(", ")).each(function () {
      if (!fmaOowIsPluginWhatsAppButton(jQuery(this))) {
        jQuery(this).hide();
      }
    });
  }

  if (fmaOowShouldHideProductPageAtc()) {
    fmaOowHideProductPageAtcButtons();
    if (typeof MutationObserver !== "undefined" && jQuery("body").hasClass("fma-oow-hide-atc-product")) {
      var fmaOowHideAtcTimer = null;
      var fmaOowHideAtcObserver = new MutationObserver(function () {
        if (!fmaOowShouldHideProductPageAtc()) {
          return;
        }
        if (fmaOowHideAtcTimer) {
          clearTimeout(fmaOowHideAtcTimer);
        }
        fmaOowHideAtcTimer = setTimeout(fmaOowHideProductPageAtcButtons, 50);
      });
      fmaOowHideAtcObserver.observe(document.body, { childList: true, subtree: true });
    }
  }

  // when click on show share button settings
  jQuery("#fma_oow_share_btn_admin").on("click", function () {
    "use strict";
    jQuery(".share_btn_content").fadeToggle("slow");
    var fma_oow_show_or_hide = jQuery(this).val();
    if (fma_oow_show_or_hide === "Hide" || fma_oow_show_or_hide == "hide") {
      jQuery(this).val("Show");
      jQuery(".fma_share_btn_tbl").css("background", "blanchedalmond");
      setTimeout(function () {
        jQuery(".fma_share_btn_tbl").css("background", "white");
      }, 500);
    } else {
      jQuery(this).val("Hide");
      jQuery(".fma_share_btn_tbl").css("background", "blanchedalmond");
      setTimeout(function () {
        jQuery(".fma_share_btn_tbl").css("background", "white");
      }, 500);
    }
  });

  // tab click jquery settings
  jQuery("#fma_oow_settings_tab_btn").on("click", function () {
    jQuery(".fma_oow_setting_main_tbl").show();
    jQuery(this).addClass("current");
    jQuery("#fma_oow_share_tab_btn").removeClass("current");
    jQuery("#fma_oow_hide_show_tab_btn").removeClass("current");
    jQuery("#fma_oow_notifications_settings_tab_btn").removeClass("current");
    jQuery("#fma_oow_display_settings_tab_btn").removeClass("current");
    jQuery("#fma_oow_message_template_tab_btn").removeClass("current");
    jQuery(".fma_share_btn_tbl").hide();
    jQuery(".fma_hide_show_tbl_").hide();
    jQuery(".fma_notifications_settings_tbl_").hide();
    jQuery(".fma_display_settings_tbl_").hide();
    jQuery(".fma_message_template_tbl_").hide();
  });
  jQuery("#fma_oow_share_tab_btn").on("click", function () {
    jQuery(".fma_share_btn_tbl").show();
    jQuery(this).addClass("current");
    jQuery("#fma_oow_settings_tab_btn").removeClass("current");
    jQuery("#fma_oow_hide_show_tab_btn").removeClass("current");
    jQuery("#fma_oow_notifications_settings_tab_btn").removeClass("current");
    jQuery("#fma_oow_display_settings_tab_btn").removeClass("current");
    jQuery("#fma_oow_message_template_tab_btn").removeClass("current");
    jQuery(".fma_oow_setting_main_tbl").hide();
    jQuery(".fma_hide_show_tbl_").hide();
    jQuery(".fma_notifications_settings_tbl_").hide();
    jQuery(".fma_display_settings_tbl_").hide();
    jQuery(".fma_message_template_tbl_").hide();
  });
  jQuery("#fma_oow_hide_show_tab_btn").on("click", function () {
    jQuery(".fma_hide_show_tbl_").show();
    jQuery(this).addClass("current");
    jQuery("#fma_oow_settings_tab_btn").removeClass("current");
    jQuery("#fma_oow_share_tab_btn").removeClass("current");
    jQuery("#fma_oow_notifications_settings_tab_btn").removeClass("current");
    jQuery("#fma_oow_display_settings_tab_btn").removeClass("current");
    jQuery("#fma_oow_message_template_tab_btn").removeClass("current");
    jQuery(".fma_oow_setting_main_tbl").hide();
    jQuery(".fma_share_btn_tbl").hide();
    jQuery(".fma_notifications_settings_tbl_").hide();
    jQuery(".fma_display_settings_tbl_").hide();
    jQuery(".fma_message_template_tbl_").hide();
  });
  jQuery("#fma_oow_notifications_settings_tab_btn").on("click", function () {
    jQuery(".fma_notifications_settings_tbl_").show();
    jQuery(this).addClass("current");
    jQuery("#fma_oow_settings_tab_btn").removeClass("current");
    jQuery("#fma_oow_share_tab_btn").removeClass("current");
    jQuery("#fma_oow_hide_show_tab_btn").removeClass("current");
    jQuery("#fma_oow_display_settings_tab_btn").removeClass("current");
    jQuery("#fma_oow_message_template_tab_btn").removeClass("current");
    jQuery(".fma_oow_setting_main_tbl").hide();
    jQuery(".fma_share_btn_tbl").hide();
    jQuery(".fma_hide_show_tbl_").hide();
    jQuery(".fma_display_settings_tbl_").hide();
    jQuery(".fma_message_template_tbl_").hide();
  });

  jQuery("#fma_oow_display_settings_tab_btn").on("click", function () {
    jQuery(".fma_display_settings_tbl_").show();
    jQuery(this).addClass("current");
    jQuery("#fma_oow_settings_tab_btn").removeClass("current");
    jQuery("#fma_oow_share_tab_btn").removeClass("current");
    jQuery("#fma_oow_hide_show_tab_btn").removeClass("current");
    jQuery("#fma_oow_notifications_settings_tab_btn").removeClass("current");
    jQuery("#fma_oow_message_template_tab_btn").removeClass("current");
    jQuery(".fma_oow_setting_main_tbl").hide();
    jQuery(".fma_share_btn_tbl").hide();
    jQuery(".fma_hide_show_tbl_").hide();
    jQuery(".fma_notifications_settings_tbl_").hide();
    jQuery(".fma_message_template_tbl_").hide();
  });

  jQuery("#fma_oow_message_template_tab_btn").on("click", function () {
    jQuery(".fma_message_template_tbl_").show();
    jQuery(this).addClass("current");
    jQuery("#fma_oow_settings_tab_btn").removeClass("current");
    jQuery("#fma_oow_share_tab_btn").removeClass("current");
    jQuery("#fma_oow_hide_show_tab_btn").removeClass("current");
    jQuery("#fma_oow_notifications_settings_tab_btn").removeClass("current");
    jQuery("#fma_oow_display_settings_tab_btn").removeClass("current");
    jQuery(".fma_oow_setting_main_tbl").hide();
    jQuery(".fma_share_btn_tbl").hide();
    jQuery(".fma_hide_show_tbl_").hide();
    jQuery(".fma_notifications_settings_tbl_").hide();
    jQuery(".fma_display_settings_tbl_").hide();
  });
  ////////////////////////////////////////////////////////////////////////////////////

  if (typeof jQuery.fn.select2 !== 'undefined' && jQuery("#fma_order_on_whatsapp_example_whatsapp_products_list").length) {
    jQuery("#fma_order_on_whatsapp_example_whatsapp_products_list").select2({
      placeholder: fma_order_on_whatsapp_products_list_placeholder,
      ajax: {
        url: ewcpm_php_vars.admin_url,
        dataType: "json",
        delay: 250,
        data: function (params) {
          return {
            action: "fme_get_product_applied_array",
            term: params.term,
            security: ewcpm_php_vars.admin_ajax_nonce,
          };
        },
        processResults: function (response) {
          return {
            results: response,
          };
        },
        cache: true,
      },
      minimumInputLength: 1,
    });
  }

  /////////////////// ADDED BY M.Manahal //////////////////////
  var themeName = ewcpm_php_vars.theme_name || '';
  var blockTheme = ewcpm_php_vars.is_block_theme || '';

  if ('The Retailer' == themeName) {
    jQuery('.fma_order_on_whatsapp_btn_on_shop_page').removeClass('button');
  } else if ('Betheme' == themeName) {
    jQuery('.fma_order_on_whatsapp_btn_on_shop_page').parent().removeClass('hide-button').css("display", "inline-grid");
  } else if ('Divi' == themeName) {
    jQuery('.fma_order_on_whatsapp_btn_on_shop_page').removeClass('button').css("cursor", "pointer");
  }
  if (blockTheme) {
    jQuery('.fma_oow_billing_phone, .fma_oow_whatsapp_contact_number, #billing_state, #billing_country').addClass('input-text');
    jQuery('.popup_inner .fme_close_btn .button').addClass('wp-element-button');
  }

  /////////////////// ADDED BY M.Manahal //////////////////////
}); // end of document .ready()