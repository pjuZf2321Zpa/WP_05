jQuery(document).ready(function(){
  
  //////////////////////////////// ADDED BY SAQIB ////////////////////////////////////////

  jQuery(document).on('click', '#fme_oow_order_message_template_btn', function(){
    
    var message_template_id = jQuery(this).data('template-id');
    var message_template_name = jQuery(this).data('template');
    var message_template_action = jQuery(this).data('action');

    var message_template_text = "";
    var message_template_name_text = "";
    var message_template_language = "en_US";

    if(message_template_name == "order_status"){
      message_template_text = jQuery("#fme_oow_order_status_data").val();
      message_template_name_text = jQuery("#fme_oow_order_status_name_text").val();
      message_template_language = jQuery("#fme_oow_order_status_language").val();
    }else if (message_template_name == "order_confirmation"){
      message_template_text = jQuery("#fme_oow_order_confirmation_data").val();
      message_template_name_text = jQuery("#fme_oow_order_confirmation_name_text").val();
      message_template_language = jQuery("#fme_oow_order_confirmation_language").val();
    }


    var data = new FormData();
    data.append('action', 'fmeOowCreateUpdateMessageTemplate');
    data.append('security', ewcpm_php_vars.admin_ajax_nonce);
    data.append('message_template_id', message_template_id);
    data.append('message_template_name', message_template_name);
    data.append('message_template_action', message_template_action);
    data.append('message_template_text', message_template_text);
    data.append('message_template_name_text', message_template_name_text);
    data.append('message_template_language', message_template_language);

    var btn_text = jQuery(this).text();
    jQuery(this).text("Processing...").attr("Disabled", true);

    jQuery.ajax({
      url: ewcpm_php_vars.admin_url,
      type: 'POST',
      data: data,
      cahce: false,
      processData: false,
      contentType: false
    }).then(res => {
      var res = jQuery.parseJSON(res);

      // reload notifications template table
      fmeOowLoadNotificationsTable();

      if(res.status == "success"){
        alert(res.message);
      }else if(res.status == "error"){
        alert(res.message);
      }
      jQuery(this).text(btn_text).attr("disabled", false);
    }).catch(err => {
      console.log(err);
      jQuery(this).text(btn_text).attr("disabled", false);
    });

  });

  jQuery(document).on('input', '#fme_oow_order_status_name_text, #fme_oow_order_confirmation_name_text', function() {
      var inputValue = jQuery(this).val();
      var regex = /^[a-z_]+$/; // Regular expression to allow lowercase letters (a-z) and underscore (_)

      // Remove characters not matching the regex
      var filteredValue = inputValue.replace(/[^a-z_]/g, '');

      // Trim the value to ensure it doesn't exceed 512 characters
      if (filteredValue.length > 512) {
          filteredValue = filteredValue.substr(0, 512);
      }

      // Update the input field with the filtered value
      jQuery(this).val(filteredValue);
  });


  /**
   * Function to load notifications table
   * 
   */
  function fmeOowLoadNotificationsTable(){

    jQuery.ajax({
      url: ewcpm_php_vars.admin_url,
      data: {
        action: 'fmeOowLoadAjaxNotificationTable',
        security: ewcpm_php_vars.admin_ajax_nonce,
      },
      method: 'POST',
      cache: false,
    }).then(res => {
      jQuery('.fme_oow_notification_templates_table').html(res);
    }).catch(err => {
      console.log(err);
    });

  }

  fmeOowLoadNotificationsTable();


  jQuery(document).on('change', "#fme_oow_enable_user_whatsapp_approval", function(){

    var checked = this.checked;

    if(checked){
      jQuery("#fme_oow_enable_user_whatsapp_approval_label_row").css({'display':'table-row'});
    }else{
      jQuery("#fme_oow_enable_user_whatsapp_approval_label_row").css({'display':'none'});
    }

  });

  //////////////////////////////// ADDED BY SAQIB ////////////////////////////////////////


});
jQuery(document).ready(function ($) {
	const checkbox = $('#fma_oow_enable_multiple_branches');
	const whatsappRow = $('.fma_oow_whatsapp_numbers_row');

	function toggleWhatsappRow() {
		if (checkbox.is(':checked')) {
			whatsappRow.show();
		} else {
			whatsappRow.hide();
		}
	}

	// Initialize on page load
	toggleWhatsappRow();

	// Toggle on change
	checkbox.on('change', toggleWhatsappRow);
});