const { registerPaymentMethod } = window.wc.wcBlocksRegistry;
const { createElement } = window.wp.element;
const { __ } = window.wp.i18n;
const { decodeEntities } = window.wp.htmlEntities;

const WhatsAppSettings = window.wc.wcSettings.getSetting('whatsapp_payment_data', {});

const Label = decodeEntities(WhatsAppSettings.title) || FMA_WhatsApp_Data.whatsappPaymentLabel;

const WhatsAppContent = (props) => {
    const { eventRegistration } = props;

    return createElement('div', null,
        decodeEntities(WhatsAppSettings.description || FMA_WhatsApp_Data.whatsappPaymentDescription)
    );
};

registerPaymentMethod({
    name: 'whatsapp_payment',
    label: Label,
    ariaLabel: Label,
    content: createElement(WhatsAppContent, null),
    edit: createElement(WhatsAppContent, null),
    canMakePayment: () => {
        const isBlock = document.querySelector('.wp-block-woocommerce-checkout');
        if (!isBlock) {
            return false;
        }
        return true;
    },
    supports: {
        features: WhatsAppSettings.supports || ['products'],
        showSavedCards: false,
        showSaveOption: false,
    }
});


