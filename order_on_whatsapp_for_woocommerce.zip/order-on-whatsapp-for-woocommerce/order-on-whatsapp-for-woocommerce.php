<?php
/**
 * Plugin Name:       Order On WhatsApp for woocommerce
 * Description:       Contact directly with your customers through WhatsApp. Now you can handle your orders through your WhatsApp.
 * Version:           1.3.8
 * Author:            Fme Addons
 * Author URI:        https://woocommerce.com/vendor/fmeaddons/
 * License:           GPL v2 or later
 * Text Domain:       order-on-whatsapp
 * Domain Path: /languages
 * Requires Plugins: woocommerce
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * WC requires at least: 4.0.0
 * WC tested up to: 10.9.4
 * Requires PHP: 7.4.0
 * Requires at least: 5.2
 * Tested up to: 7.0.2
 * Woo: 6399867:51f53d27fced2191dbd98c503d0e47b5

 */

// All Actions
add_action('init', 'fmaOrderOnWhatsappForTextDomain'); // for text domain
// add setting link under plugin name
// add_filter( 'plugin_action_links_order-on-whatsapp-for-woocommerce/order-on-whatsapp-for-woocommerce.php', 'fma_oow_settings_link_under_plugin_name', 10, 2);
// End of actions

if (! function_exists('is_plugin_active')) {
	include_once ABSPATH . 'wp-admin/includes/plugin.php';
}


/**
 * Check if WooCommerce is active
 * if wooCommerce is not active ext Tabs module will not work.
 **/

if (!is_plugin_active('woocommerce/woocommerce.php')) {
	add_action('admin_notices', 'fmeOOWAdminNotice');
}


if (isset($_GET['page']) &&  'wc-settings' == $_GET['page']  && isset($_GET['tab']) && 'my_sub_menu_whatsapp' ==  $_GET['tab']) {
	add_action('admin_notices', 'show_review_notice');
}

function show_review_notice() {

	// Check if plugin was activated 31 days ago.
	$activation_time = get_option('fme_order_on_whatsapp_plugin_activation_time');
	if (empty($activation_time)) {
		return;
	}
	$days_since_activation = ( time() - (int) $activation_time ) / DAY_IN_SECONDS;

	if ($days_since_activation < 3) {
		return;
	}
	$user_id   = get_current_user_id();
	$dismissed = get_user_meta($user_id, 'fme_order_on_whatsapp_review_notice_dismissed', true);

	if ('yes' === $dismissed) {
		return;
	}
	?>
		<div class="notice notice-info is-dismissible fme-order-on-whatsapp-review-notice">
			<p>
				<?php
				$notice_text = sprintf(
					/* translators: %s: Plugin name */
					__(
						'Like %s? Please leave us a <a href="https://woocommerce.com/products/order-on-whatsapp-for-woocommerce/?review=true" target="_blank" class="rating-link">★★★★★</a> rating. Thank you!',
						'order-on-whatsapp'
					),
					'<strong>Order On WhatsApp for WooCommerce</strong>'
				);

				echo wp_kses_post($notice_text);
				?>
				&nbsp;|&nbsp;
				<a href="#" class="fme-order-on-whatsapp-dismiss-review-notice">
					<?php echo esc_html__('Don’t show again', 'order-on-whatsapp'); ?>
				</a>
			</p>
		</div>
	<?php
}


/**
 * Check WooCommerce is installed and active
 *
 * This function will check that woocommerce is installed and active .
 * and returns true or false
 *
 * @return true or false
 */
function fmeOOWAdminNotice() {
	// Deactivate the plugin
	deactivate_plugins(__FILE__);
	$allowedTags = array(
		'a' => array(
			'class' => array(),
			'href'  => array(),
			'rel'   => array(),
			'title' => array(),
			'style' => array(),
		),
		'abbr' => array(
			'title' => array(),
		),
		'b' => array(),
		'blockquote' => array(
			'cite'  => array(),
		),
		'cite' => array(
			'title' => array(),
		),
		'code' => array(),
		'del' => array(
			'datetime' => array(),
			'title' => array(),
		),
		'dd' => array(),
		'div' => array(
			'class' => array(),
			'title' => array(),
			'style' => array(),
		),
		'dl' => array(),
		'dt' => array(),
		'em' => array(),
		'h1' => array(),
		'h2' => array(),
		'h3' => array(),
		'h4' => array(),
		'h5' => array(),
		'h6' => array(),
		'i' => array(),
		'img' => array(
			'alt'    => array(),
			'class'  => array(),
			'height' => array(),
			'src'    => array(),
			'width'  => array(),
		),
		'li' => array(
			'class' => array(),
		),
		'ol' => array(
			'class' => array(),
		),
		'p' => array(
			'class' => array(),
		),
		'q' => array(
			'cite' => array(),
			'title' => array(),
		),
		'span' => array(
			'class' => array(),
			'title' => array(),
			'style' => array(),
		),
		'strike' => array(),
		'strong' => array(),
		'ul' => array(
			'class' => array(),
		),
	);
	$wooextmmMessage = "<div id='message' class='error'>
	<p><strong> " . __('WooCommerce Plugin is inactive.', 'order-on-whatsapp') . '</strong>' . __(' The ', 'order-on-whatsapp') . "<a href='http://wordpress.org/extend/plugins/woocommerce/'>" . __('WooCommerce plugin', 'order-on-whatsapp') . '</a>' . __(' must be active for this plugin to work. Please install &amp; activate WooCommerce »', 'order-on-whatsapp') . '</p></div>';

	echo wp_kses($wooextmmMessage, $allowedTags);
	die;
}

if (!defined('FMA_OOW_PLUGIN_DIR')) {
	define('FMA_OOW_PLUGIN_DIR', plugin_dir_path(__FILE__));
}
if (!defined('FMA_OOW_PLUGIN_URL')) {
	define('FMA_OOW_PLUGIN_URL', plugin_dir_url(__FILE__));
}
if (!defined('FMA_OOW_VERSION')) {
	$fma_oow_plugin_data = get_file_data(
		__FILE__,
		array(
			'Version' => 'Version',
		),
		'plugin'
	);
	define('FMA_OOW_VERSION', ! empty($fma_oow_plugin_data['Version']) ? $fma_oow_plugin_data['Version'] : '1.0.0');
}

require_once FMA_OOW_PLUGIN_DIR . 'includes/class-fma-oow-whatsapp-template-parser.php';
if (!class_exists('WpmlHelper')) {
	require_once FMA_OOW_PLUGIN_DIR . 'includes/WpmlHelper.php';
}

// function fma_oow_settings_link_under_plugin_name( $links, $file ) {
//      $settings_link = '<a href=admin.php?page=wc-settings&tab=my_sub_menu_whatsapp>' . __( 'Settings', 'order-on-whatsapp' ) . '</a>';
//      array_unshift( $links, $settings_link );
//  return $links;
// }
function fmaOrderOnWhatsappSetWcScreenIdsWhatsappContact( $screen ) {
	$screen[] = 'woocommerce_page_my_sub_menu_whatsapp';
	return $screen;
}

function fmaOrderOnWhatsappForTextDomain() {
	define('CURRENT_USER_ID', get_current_user_id());

	include plugin_dir_path(__FILE__) . 'admin/fma-order-on-whatsapp-admin.php'; // include all admin stuff
	include plugin_dir_path(__FILE__) . 'front-end/fma-order-on-whatsapp-front-end.php'; // include all front end stuff

	load_plugin_textdomain('order-on-whatsapp', false, dirname(plugin_basename(__FILE__)) . '/languages/');
}

/**
 * Update default settigs on plugin activation
 *
 * @return void
 */
function fmaOrderOnWhatsappActivationRedirect() {



	$latest_plugin_version = get_latest_plugin__version();
	if (!empty($latest_plugin_version) && 0 != $latest_plugin_version) {
		update_option('fma_oow_version', $latest_plugin_version);
	}
	if (false == get_option('fma_order_on_whatsapp_button_text')) {
		//Setting tab
		update_option('fma_order_on_whatsapp_button_text', 'Buy On WhatsApp');
		update_option('fma_order_on_whatsapp_either_products_or_cats', 'fma_order_on_whatsapp_products_list');
		update_option('fma_oow_apply_on_all_products', 'yes');
		update_option('fma_oow_where_to_place_whatsp_btn', 'fma_oow_before_add_to_cart');
		update_option('fma_oow_open_whatsapp_in_which_tab', 'oow_in_same_tab');
		update_option('fma_oow_share_msg_when_whatsap_opens', 'I would like to buy this product');
		update_option('fma_oow_create_order_in_woocommerce', 'yes');
		update_option('fma_oow_get_order_status_messages', 'yes');
		update_option('fma_oow_enable_only_for_customers', 'no');
		//Share tab
		update_option('fma_oow_share_btn', 'yes');
		update_option('fma_oow_share_btn_txt', 'Share');
		update_option('fma_oow_msg_when_whatsap_opens', 'I would like to buy this product');
		// Hide/Show button tab
		update_option('fma_order_on_whatsapp_show_on_shop_page', 'yes');
		update_option('fma_order_on_whatsapp_show_on_checkout_page', 'yes');
		update_option('fma_order_on_whatsapp_show_on_cart_page', 'yes');
		update_option('fma_order_on_whatsapp_show_on_single_product', 'yes');
		update_option('fma_order_on_whatsapp_show_whatsapp_functionality_on_checkout_pg', 'yes');
	}
	// added in v1.1.8
	if (false == get_option('fma_oow_all_payment_gateways')) {
		update_option('fma_oow_all_payment_gateways', 'on');
	}
}

/**
 * Add missing options on version upgrade without overwriting merchant settings.
 *
 * @return void
 */
function fma_oow_migrate_missing_options() {
	$default_options = array(
		'fma_order_on_whatsapp_button_text' => 'Buy On WhatsApp',
		'fma_order_on_whatsapp_either_products_or_cats' => 'fma_order_on_whatsapp_products_list',
		'fma_oow_apply_on_all_products' => 'yes',
		'fma_oow_where_to_place_whatsp_btn' => 'fma_oow_before_add_to_cart',
		'fma_oow_open_whatsapp_in_which_tab' => 'oow_in_same_tab',
		'fma_oow_share_msg_when_whatsap_opens' => 'I would like to buy this product',
		'fma_oow_create_order_in_woocommerce' => 'yes',
		'fma_oow_get_order_status_messages' => 'yes',
		'fma_oow_enable_only_for_customers' => 'no',
		'fma_oow_share_btn' => 'yes',
		'fma_oow_share_btn_txt' => 'Share',
		'fma_oow_msg_when_whatsap_opens' => 'I would like to buy this product',
		'fma_order_on_whatsapp_show_on_shop_page' => 'yes',
		'fma_order_on_whatsapp_show_on_checkout_page' => 'yes',
		'fma_order_on_whatsapp_show_on_cart_page' => 'yes',
		'fma_order_on_whatsapp_show_on_single_product' => 'yes',
		'fma_order_on_whatsapp_show_whatsapp_functionality_on_checkout_pg' => 'yes',
		'fma_oow_all_payment_gateways' => 'on',
		'fma_oow_inline_whatsapp_share_buttons' => 'no',
	);

	foreach ($default_options as $option_key => $option_value) {
		if (false === get_option($option_key)) {
			add_option($option_key, $option_value);
		}
	}

	$latest_plugin_version = get_latest_plugin__version();
	if (!empty($latest_plugin_version) && 0 != $latest_plugin_version) {
		update_option('fma_oow_version', $latest_plugin_version);
	}
}
// add_action( 'activated_plugin', 'fmaOrderOnWhatsappActivationRedirect' );


register_activation_hook(__FILE__, 'fmaOrderOnWhatsappActivationRedirect');
register_activation_hook(__FILE__, 'plugin_set_activation_time');
add_action('upgrader_process_complete', 'plugin_set_activation_time');
add_action('admin_init', 'fmaUpdateVersion');




function plugin_set_activation_time() {
	if (! get_option('fme_order_on_whatsapp_plugin_activation_time')) {
		update_option('fme_order_on_whatsapp_plugin_activation_time', time());
	}
}

/**
 * Update default settigs on version update
 *
 * @return void
 */
function fmaUpdateVersion() {

	$current_plugin_version = get_option('fma_oow_version');
	if (empty($current_plugin_version)) {
		fmaOrderOnWhatsappActivationRedirect();
		return;
	}

	$latest_plugin_version = get_latest_plugin__version();
	if (0 != $latest_plugin_version && $current_plugin_version != $latest_plugin_version) {
		fma_oow_migrate_missing_options();
	}
}

add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'fmeOrderOnWhatsappSettingsLink');



add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'fma_oow_settings_link');

if (isset($_GET['page']) &&  'wc-settings' == $_GET['page']  && isset($_GET['tab']) && 'my_sub_menu_whatsapp' ==  $_GET['tab']) {
	add_action('admin_notices', 'fma_oow_show_notice_status');
}

/**
 * Function to add custom columns in plugin action links (i.e. Activate or Delete)
 * 
 * @return array of links
 */
function fma_oow_settings_link( $links ) {
	$settings_link = '<a href="' . esc_url(admin_url('admin.php?page=wc-settings&tab=my_sub_menu_whatsapp')) . '">Settings</a>';
	array_unshift($links, $settings_link);
	return $links;
}


function fma_oow_show_notice_status() {
	?>
	<div class="notice notice-warning is-dismissible">
		<p>
			<?php
			echo esc_html__('Having technical issues? Submit a', 'order-on-whatsapp') . ' <a href="https://woocommerce.com/my-account/contact-support/?select=order-on-whatsapp-for-woocommerce#contact-us" target="_blank">' . esc_html__('support ticket', 'order-on-whatsapp') . '</a> ' . esc_html__('now, and our developers will get back to you as quickly as possible.', 'order-on-whatsapp');
			?>
		</p>
	</div>
	<?php
}


/**
 * Added custom actions links
 *
 * @param array $links
 * @return array
 */
function fmeOrderOnWhatsappSettingsLink( $links ) {
	$links[] = '<a href="https://woocommerce.com/my-account/contact-support/?select=order-on-whatsapp-for-woocommerce#contact-us" target="_blank">' . esc_html__('Support', 'order-on-whatsapp') . '</a>';
	$links[] = '<a href="https://woo.com/feature-requests/order-on-whatsapp-for-woocommerce/" target="_blank">' . esc_html__('Request a feature', 'order-on-whatsapp') . '</a>';
	$links[] = '<a href="https://woo.com/document/order-on-whatsapp-for-woocommerce/" target="_blank">' . esc_html__('Documentation', 'order-on-whatsapp') . '</a>';
	return $links;
}
function get_latest_plugin__version() {
	return defined('FMA_OOW_VERSION') ? FMA_OOW_VERSION : '0';
}



//////////////////////////////// ADDED BY SAQIB ////////////////////////////////////
// create post type for logs
add_action('init', 'fme_oow_notification_logs_post_type');

// add menu item to woocommerce menu for notification logs
// add_action( 'admin_menu', 'fmeAddSubmenuPage' );

/**
 * Function to create custom post type for enquiry form posts
 *
 * @return void
 */
function fme_oow_notification_logs_post_type() {
	register_post_type(
		'fme_notification_log',
		array(
			'labels'      => array(
				'name'          => __('Notification Logs', 'order-on-whatsapp'),
				'singular_name' => __('Notification Log', 'order-on-whatsapp'),
			),
			'public'      => false,
			'show_ui'     => true,
			'show_in_menu' => 'woocommerce',
			'has_archive' => true,
			'supports'    => array( 'title', 'editor', 'custom-fields' ),
			'capability_type' => 'post',
			'capabilities' => array(
				'create_posts' => false,
			),
			'map_meta_cap' => true,
		)
	);
}


/**
 * Added submenu for woocommerce
 * 
 * @return void
 */
function fmeAddSubmenuPage() {
	$count = isset(wp_count_posts('fme_notification_log')->new) ? wp_count_posts('fme_notification_log')->new : 0;
	if (0 < $count) {
		$count = "<span class='awaiting-mod update-plugins count-$count'><span class='processing-count'>$count</span></span>";
	} else {
		$count = '';
	}
	add_submenu_page('woocommerce', 'Notification Logs' . $count, 'Notification Logs' . $count, 'manage_options', 'edit.php?post_type=fme_notification_log', null, null);
}

// add columns to fme_efw_post table in admin
add_filter('manage_fme_notification_log_posts_columns', 'add_columns_to_fme_notification_log_table');
// add values to columns added of fme_notification_log
add_filter('manage_fme_notification_log_posts_custom_column', 'add_columns_values_to_fme_notification_log_table', 10, 2);
// make custom columns sortable
add_filter('manage_edit-fme_notification_log_sortable_columns', 'make_fme_notification_log_columns_sortable');

/**
 * Function to add columns to table in admin
 * 
 * @param array $column
 * @return array
 */

function add_columns_to_fme_notification_log_table( $columns ) {

	unset($columns['date']);
	unset($columns['title']);

	$columns['id'] = __('ID', 'order-on-whatsapp');
	$columns['mtitle'] = __('Notification', 'order-on-whatsapp');
	$columns['fme_oow_log_type'] = __('Log Type', 'order-on-whatsapp');
	$columns['fme_oow_to_user'] = __('Customer Whatsapp', 'order-on-whatsapp');
	$columns['fme_oow_request_data'] = __('Request', 'order-on-whatsapp');
	$columns['fme_api_response'] = __('API Response', 'order-on-whatsapp');
	$columns['date'] = __('Date', 'order-on-whatsapp');
	return $columns;
}


/**
 * Function to add values to custom columns added to custom post type order-cancellation table
 * 
 * @param string $column
 * @param int $post_id
 * @return string
 */

function add_columns_values_to_fme_notification_log_table( $column, $post_id ) {

	global $wpdb;
	switch ($column) {
		case 'id':
			echo esc_html($post_id);
			break;
		case 'mtitle':
			echo esc_html(get_the_title($post_id));
			break;

		case 'fme_oow_log_type':
			echo esc_html(get_post_meta($post_id, 'fme_oow_log_type', true));
			break;

		case 'fme_oow_to_user':
			echo esc_html(get_post_meta($post_id, 'fme_oow_to_user', true));
			break;

		case 'fme_oow_request_data':
			echo esc_html(get_post_meta($post_id, 'fme_oow_request_data', true));
			break;

		case 'fme_api_response':
			echo esc_html(get_the_content());
			break;
	}
}


/**
 * Make Columns sortable for our order cancellation table
 * 
 * @param array $columns
 * @return array
 */
function make_fme_notification_log_columns_sortable( $columns ) {
	$columns['id'] = 'id';
	return $columns;
}


// ########################  WhatsApp Payment Gateway   ###################################

// For Block Checkout paymennt method
// Initialize blocks compatibility
add_action('before_woocommerce_init', 'whatsapp_blocks_compatibility');
function whatsapp_blocks_compatibility() {
	if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, true);
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('cart_checkout_blocks', __FILE__, true);
	}

	if (class_exists(\Automattic\WooCommerce\Blocks\Package::class)) {
		\Automattic\WooCommerce\Blocks\Package::container()->get(\Automattic\WooCommerce\Blocks\Assets\AssetDataRegistry::class)->add('fme_custom_data', true);
	}
}

/**
 * Added WhatsApp Payment Gateway
 * 
 * @param array $gateways
 * @return array 
 */
add_filter('woocommerce_payment_gateways', 'fmaAddWhatsappPaymentGateway');

function fmaAddWhatsappPaymentGateway( $gateways ) {
	$gateways[] = 'WC_Gateway_WhatsApp_Payment';
	return $gateways;
}


add_action('plugins_loaded', 'fmaInitCustomPaymentGateway');
/**
 * Add WhatsApp payment gateway class and data
 * 
 * @return void
 */
function fmaInitCustomPaymentGateway() {
	include FMA_OOW_PLUGIN_DIR . 'whatsApp-payment-method.php';
	include FMA_OOW_PLUGIN_DIR . 'whatsApp-payment-method-block.php';
}
// ########################  WhatsApp Payment Gateway   ###################################







// ##################### whatApp payment end

// Register block integration
add_action('woocommerce_blocks_loaded', 'fma_register_whatsapp_block_support');
function fma_register_whatsapp_block_support() {
	if (!class_exists('\Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType')) {
		return;
	}

	add_filter('woocommerce_blocks_payment_method_type_registration', function ( $payment_method_registry ) {
		$payment_method_registry->register(new WC_Gateway_WhatsApp_Block_Support());
		return $payment_method_registry;
	});
}

/**
 * Whether the store checkout page uses the WooCommerce Checkout block.
 *
 * @return bool
 */
function fma_oow_store_uses_block_checkout() {
	if (!function_exists('wc_get_page_id')) {
		return false;
	}

	$checkout_page_id = wc_get_page_id('checkout');
	if ($checkout_page_id <= 0) {
		return false;
	}

	if (function_exists('has_block') && has_block('woocommerce/checkout', $checkout_page_id)) {
		return true;
	}

	if (class_exists('WC_Blocks_Utils')) {
		return WC_Blocks_Utils::has_block_in_page($checkout_page_id, 'woocommerce/checkout');
	}

	return false;
}

/**
 * Set up WooCommerce checkout context for popup rendering.
 *
 * @return void
 */
function fma_oow_setup_popup_checkout_context() {
	if (!defined('WOOCOMMERCE_CHECKOUT')) {
		define('WOOCOMMERCE_CHECKOUT', true);
	}

	if (function_exists('wc')) {
		WC()->frontend_includes();
	}

	if (class_exists('WC_Frontend_Scripts')) {
		WC_Frontend_Scripts::load_scripts();
	}
}

/**
 * Render classic checkout form for block-checkout stores (AJAX / controlled context).
 *
 * @return string
 */
function fma_oow_render_classic_checkout_for_popup() {
	if (!function_exists('WC') || !WC()->cart) {
		return '';
	}

	fma_oow_setup_popup_checkout_context();

	$set_checkout = function () {
		return true;
	};
	add_filter('woocommerce_is_checkout', $set_checkout);

	ob_start();

	echo '<div class="woocommerce">';

	/**
	 * Action to display cart notices before the checkout form
	 * 
	 * @since 1.3.7
	 */
	do_action('woocommerce_before_checkout_form_cart_notices');

	if (WC()->cart->is_empty()) {
		echo '</div>';
		remove_filter('woocommerce_is_checkout', $set_checkout);
		return ob_get_clean();
	}

	/**
	 * Action to check cart items before the checkout form
	 * 
	 * @since 1.3.7
	 */
	do_action('woocommerce_check_cart_items');
	WC()->cart->calculate_totals();

	$checkout = WC()->checkout();

	if (wc_notice_count('error') > 0) {
		wc_get_template('checkout/cart-errors.php', array( 'checkout' => $checkout ));
		wc_clear_notices();
	} else {
		wc_get_template('checkout/form-checkout.php', array( 'checkout' => $checkout ));
	}

	echo '</div>';

	/**
	 * Remove the filter to set the checkout page
	 * 
	 * @since 1.3.7
	 */
	remove_filter('woocommerce_is_checkout', $set_checkout);

	return ob_get_clean();
}

/**
 * Render checkout markup for popup (classic shortcode or classic template on block stores).
 *
 * @return string
 */
function fma_oow_render_popup_checkout_html() {
	if (fma_oow_store_uses_block_checkout()) {
		return fma_oow_render_classic_checkout_for_popup();
	}

	if (!defined('WOOCOMMERCE_CHECKOUT')) {
		define('WOOCOMMERCE_CHECKOUT', true);
	}

	return do_shortcode('[woocommerce_checkout]');
}

/**
 * Build AJAX response payload for checkout popup handlers.
 *
 * @return array
 */
function fma_oow_build_checkout_popup_ajax_data() {
	$checkout_page_data = fma_oow_render_popup_checkout_html();

	ob_start();
	woocommerce_mini_cart();
	$mini_cart = ob_get_clean();

	
	return array(
		/**
		 * Filter the cart fragments
		 * 
		 * @since 1.3.7
		 */
		'fragments' => apply_filters(
			'woocommerce_add_to_cart_fragments',
			array(
				'div.widget_shopping_cart_content' => '<div class="widget_shopping_cart_content">' . $mini_cart . '</div>',
			)
		),
		'checkout_page' => $checkout_page_data,
	);
}

add_action('wp_ajax_show_checkout_block_popup', 'whastsAppshow_checkout_popup');
add_action('wp_ajax_nopriv_show_checkout_block_popup', 'whastsAppshow_checkout_popup');
/**
 * Show checkout popup on WhatsApp button click
 *
 * @return array
 */
function whastsAppshow_checkout_popup() {
	$nonce = isset($_POST['security']) ? sanitize_text_field(wp_unslash($_POST['security'])) : '';
	if (!wp_verify_nonce($nonce, 'admin_ajax_nonce')) {
		wp_send_json_error(array( 'message' => __('Nonce verification failed', 'order-on-whatsapp') ));
		wp_die();
	}
	$fma_prdt_id = 0;
	$fma_varition_id = 0;
	$fma_prdt_qty = 1;

	if (isset($_REQUEST['product_id'])) {
		$fma_prdt_id = sanitize_text_field($_REQUEST['product_id']);
	}
	if (isset($_REQUEST['variation_id'])) {
		$fma_varition_id = sanitize_text_field($_REQUEST['variation_id']);
	}
	if (isset($_REQUEST['qunatity'])) {
		$fma_prdt_qty = sanitize_text_field($_REQUEST['qunatity']);
	}
	/////////////////////////////// ADDED BY SAQIB ///////////////////////////////
	if (0 == $fma_prdt_id && 0 < $fma_varition_id) {
		$product = wc_get_product($fma_varition_id);
		$fma_prdt_id = $product->get_parent_id();
	}
	/////////////////////////////// ADDED BY SAQIB ///////////////////////////////
	WC()->cart->add_to_cart($fma_prdt_id, $fma_prdt_qty, $fma_varition_id);

	wp_send_json(fma_oow_build_checkout_popup_ajax_data());
}

add_action('wp_ajax_fma_oow_get_cart_block_button_html', 'fma_oow_ajax_get_cart_block_button_html');
add_action('wp_ajax_nopriv_fma_oow_get_cart_block_button_html', 'fma_oow_ajax_get_cart_block_button_html');
/**
 * Return cart block WhatsApp button HTML for the current cart (product/category targeting applied).
 *
 * @return void
 */
function fma_oow_ajax_get_cart_block_button_html() {
	$nonce = isset($_POST['security']) ? sanitize_text_field(wp_unslash($_POST['security'])) : '';
	if (!wp_verify_nonce($nonce, 'admin_ajax_nonce')) {
		wp_send_json_error(array( 'message' => __('Nonce verification failed', 'order-on-whatsapp') ));
	}

	if (function_exists('wc_load_cart')) {
		wc_load_cart();
	}

	$button_html = '';
	if (function_exists('fma_oow_render_cart_block_button_html')) {
		$button_html = fma_oow_render_cart_block_button_html();
	}

	wp_send_json_success(
		array(
			'button_html' => $button_html,
		)
	);
}

/**
 * Load checkout popup html for cart block
 * 
 * @return void
 */
add_action('wp_footer', 'fma_oow_load_checkout_popup_html');
function fma_oow_load_checkout_popup_html() {
	if (has_block('woocommerce/cart')) {
		include FMA_OOW_PLUGIN_DIR . 'front-end/views/fma-oow-checkout-popup-html.php';
	}
}
