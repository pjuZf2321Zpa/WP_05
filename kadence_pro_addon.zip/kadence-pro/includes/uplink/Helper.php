<?php

namespace KadenceWP\KadencePro\Uplink;

class Helper {
	/**
	 * @var string Helper data
	 */
	const DATA = '7fae5de142a2368d4217ab14844958fec6e5de94';

}