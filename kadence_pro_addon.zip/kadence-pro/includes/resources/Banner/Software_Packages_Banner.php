<?php declare( strict_types=1 );

namespace KadenceWP\KadencePro\Banner;

use DateTimeImmutable;
use DateTimeZone;
use KadenceWP\KadencePro\Nexcess\Banners\Banner;
use KadenceWP\KadencePro\Nexcess\Banners\BannerFields;
use KadenceWP\KadencePro\Nexcess\Banners\Registry;

/**
 * The Nexcess software packages banner.
 *
 * @since 1.2.6
 */
final class Software_Packages_Banner {

	/**
	 * Shared by every Nexcess plugin that shows this banner, so dismissing it in one dismisses it in all.
	 */
	public const ID = 'nexcess-software-packages-2026-10-14';

	/**
	 * When the banner starts showing, in New York time.
	 */
	private const START = '2026-10-14 12:00:00';

	/**
	 * Who sees the banner, and where.
	 *
	 * @var Audience
	 */
	private Audience $audience;

	/**
	 * @param Audience $audience Who sees the banner, and where.
	 */
	public function __construct( Audience $audience ) {
		$this->audience = $audience;
	}

	/**
	 * Registers the banner.
	 *
	 * @since 1.2.6
	 *
	 * @return void
	 */
	public function register(): void {
		$fields          = new BannerFields();
		$fields->heading = __( 'Changes are coming to your plan at your next renewal.', 'kadence-pro' );
		$fields->body    = __( 'Watch your inbox for details.', 'kadence-pro' );

		// phpcs:disable WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- Named by the stellarwp/banners library.
		$fields->ctaLabel     = __( 'Learn more', 'kadence-pro' );
		$fields->ctaUrl       = 'https://explore.nexcess.com/software-packages';
		$fields->dismissLabel = __( 'Dismiss this banner', 'kadence-pro' );
		// phpcs:enable WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase

		$package_url = KTP_URL . 'vendor/vendor-prefixed/stellarwp/banners/';
		$start       = new DateTimeImmutable( self::START, new DateTimeZone( 'America/New_York' ) );

		( new Registry() )->register( new Banner( self::ID, '1.0.0', $fields, $package_url, $start, null ) );
	}

	/**
	 * Renders the banner, when the audience allows it.
	 *
	 * @since 1.2.6
	 *
	 * @return void
	 */
	public function render(): void {
		$registry = new Registry();

		if ( ! $registry->has( self::ID ) ) {
			return;
		}

		$registry->get( self::ID )->render( [ $this->audience, 'should_display' ] );
	}
}
