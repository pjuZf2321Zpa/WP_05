<?php declare( strict_types=1 );

namespace KadenceWP\KadencePro\Banner;

use KadenceWP\KadencePro\LiquidWeb\Harbor\Admin\Feature_Manager_Page;
use WP_Screen;

use function KadenceWP\KadencePro\StellarWP\Uplink\allows_multisite_license;
use function KadenceWP\KadencePro\StellarWP\Uplink\get_resource;

/**
 * Decides whether the Nexcess software packages banner shows on the current screen.
 *
 * @since 1.2.6
 */
final class Audience {

	/**
	 * The Uplink slug Kadence Pro stores its kadencewp.com license status under.
	 */
	private const LICENSE_SLUG = 'kadence-theme-pro';

	/**
	 * Screens Kadence Pro's license and settings live on: the Kadence theme dashboard, and the
	 * Elements and Maintenance Mode lists.
	 */
	private const SCREENS = [ 'appearance_page_kadence', 'edit-kadence_element', 'edit-kadence_adv_page' ];

	/**
	 * Whether the banner shows on the current screen.
	 *
	 * @since 1.2.6
	 *
	 * @return bool
	 */
	public function should_display(): bool {
		$screen = get_current_screen();

		if ( ! $screen instanceof WP_Screen ) {
			return false;
		}

		$screens = array_merge( self::SCREENS, [ 'settings_page_' . Feature_Manager_Page::PAGE_SLUG ] );

		return in_array( $screen->id, $screens, true ) && $this->has_active_plan();
	}

	/**
	 * Whether a Nexcess license for Kadence, or a kadencewp.com license for Kadence Pro, is active,
	 * from stored state only.
	 *
	 * @since 1.2.6
	 *
	 * @return bool
	 */
	private function has_active_plan(): bool {
		if ( lw_harbor_is_product_license_active( 'kadence' ) ) {
			return true;
		}

		$resource = get_resource( self::LICENSE_SLUG );

		if ( ! $resource ) {
			return false;
		}

		// Read the stored status directly, since Uplink validates remotely when it's missing.
		$option = $resource->get_license_object()->get_key_status_option_name();
		$status = allows_multisite_license( $resource ) ? get_site_option( $option ) : get_option( $option );

		return 'valid' === $status;
	}
}
