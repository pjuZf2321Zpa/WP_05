<?php declare( strict_types=1 );

namespace KadenceWP\KadencePro\Banner;

/**
 * Shows the Nexcess software packages banner on Kadence Pro admin pages.
 *
 * @since 1.2.6
 */
final class Banner_Provider {

	/**
	 * @since 1.2.6
	 *
	 * @return void
	 */
	public function register(): void {
		$banner = new Software_Packages_Banner( new Audience() );

		add_action( 'init', [ $banner, 'register' ] );
		add_action( 'admin_notices', [ $banner, 'render' ] );
	}
}
