<?php
/*
	Copyright (C) 2015-26 CERBER TECH INC., https://wpcerber.com

    Licensed under the GNU GPL.

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

*/

/*

*========================================================================*
|                                                                        |
|	       ATTENTION!  Do not change or edit this file!                  |
|                                                                        |
*========================================================================*

*/

if ( ! defined( 'WPINC' ) ) { exit; }

require_once( cerber_plugin_dir() . '/cerber-maintenance.php' );

add_action( 'plugins_loaded', function () {
	if ( ! $key = cerber_get_get( 'cerber_magic_key', '[\d\w\-_]+' ) ) {
		return;
	}
	if ( ! $data = cerber_get_set( '_the_key_' . $key ) ) {
		cerber_404_page();
	}

	@ini_set( 'display_errors', 0 );
	cerber_delete_set( '_the_key_' . $key );
	cerber_load_admin_code();
	crb_admin_download_file( $data['query']['type'], $data['query'] );
	cerber_404_page();
}, 0 );

/**
 * A single inbound remote management request sent by the main Cerber.Hub website
 * to this managed website.
 *
 * The request arrives as one JSON encoded POST field whose name is derived per
 * website by nexus_get_fields(). The constructor decodes that payload and exposes
 * it as public properties.
 *
 * If the payload is missing or JSON decoding fails, the constructor sets the error
 * property and returns early. Callers must check the error property before reading
 * anything else.
 *
 * The object is request scoped and read only. Obtain it through nexus_request_data()
 * rather than constructing it, since the parsed request is shared for the request.
 *
 * The transport authenticity of the request is established separately by
 * nexus_is_valid_request(), not by this class.
 */
class CRB_Nexus_Request {
	public $page;
	public $tab;
	public $base;
	public $is_post;
	public $seal;
	public $type;
	public $get_params = array(); // Unsanitized, as is
	public $payload;
	public $action;
	public $screen;
	public $at_site;
	public $locale;
	public $error;

	final function __construct() {

		$fields = nexus_get_fields();
		if ( ! $payload = cerber_get_post( $fields[1] ) ) {
			$this->error = new WP_Error( 'nexus_format_error', 'Invalid request: main website request malformed' );
			return;
		}
		$request = json_decode( stripslashes( $payload ), true );
		if ( JSON_ERROR_NONE != json_last_error() ) {
			$this->error = new WP_Error( 'json_error', 'Unable to parse JSON: ' . json_last_error_msg() );
			return;
		}

		array_walk_recursive( $request, function ( &$e ) {
			$e = str_replace( array( '<br/>' ), "\n", $e ); // restore new lines after json_decode
		} );

		$this->seal       = $request['seal'];
		$this->base       = rtrim( $request['base'], '/' ) . '/';
		$this->get_params = $request['params'];
		$this->payload    = $request['payload'];
		$this->type       = $request['payload']['type'];
		$this->page       = preg_replace( '/[^\w\-]/i', '', crb_array_get( $request, 'page' ) );
		$this->tab        = preg_replace( '/[^\w\-]/i', '', crb_array_get( $request, 'tab' ) );
		$this->at_site    = crb_array_get( $request, 'at_site' );
		$this->screen     = crb_array_get( $request, 'screen' );
		$this->is_post    = ! empty( $request['is_post'] );
		$this->locale = crb_array_get( $request, 'master_locale', '' );

		CRB_Globals::set_assets_url( $request['assets'] );

		if ( $this->type == 'ajax' ) {
			if ( ! $this->action = crb_array_get( $request['params'], 'action' ) ) {
				$this->action = $this->get_post_fields( 'action' );
			}
			$this->action = preg_replace( '/[^\w\-]/i', '', (string) $this->action );
		}
	}

	/**
	 * @param integer|string $key
	 * @param mixed $default
	 * @param $pattern string REGEX pattern for value validation, UTF is not supported
	 *
	 * @return mixed
	 */
	final function get_post_fields( $key = null, $default = false, $pattern = ''  ) {
		if ( ! empty( $this->payload['data']['post'] ) ) {
			if ( $key ) {
				return crb_array_get_validated( $this->payload['data']['post'], $key, $default, $pattern );
			}

			return $this->payload['data']['post'];
		}
		if ( $key ) {
			return false;
		}

		return array();
	}
}

/**
 * @return CRB_Nexus_Request
 */
function nexus_request_data() {
	static $nexus_request;
	if ( ! is_object( $nexus_request ) ) {
		$nexus_request = new CRB_Nexus_Request();
	}

	return $nexus_request;
}

/**
 * Process request from the main Cerber.Hub website
 *
 * @return void
 */
function nexus_client_process() {

	if ( ! nexus_is_valid_request() ) {
		return;
	}

	nexus_diag_log( '=== NEXUS CLIENT STARTED ' . CERBER_VER . ' ===' );
	cerber_update_set( 'processing_master_request', 1, 0, false, time() + 120 );

	@ini_set( 'display_errors', 0 );
	@ignore_user_abort( true );
	crb_try_raise_php_limits();

	cerber_load_wp_constants();

	nexus_diag_log( 'Parsing request...' );

	$cerber_hub = nexus_request_data();

	if ( crb_is_wp_error( $cerber_hub->error ) ) {
		nexus_diag_log( 'ERROR: ' . $cerber_hub->error->get_error_message() );

		exit;
	}

	nexus_diag_log( 'Request is OK, preparing WordPress environment...' );

	require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
	require_once( ABSPATH . 'wp-admin/includes/template.php' );
	require_once( ABSPATH . WPINC . '/pluggable.php' );
	require_once( ABSPATH . WPINC . '/vars.php' );

	cerber_load_admin_code();
	crb_load_localization();

	nexus_diag_log( 'Now generating the response...' );

	$response = nexus_prepare_response();

	if ( crb_is_wp_error( $response ) ) {
		$m = __( 'ERROR:', 'wp-cerber' ) . ' ' . $response->get_error_message();
		nexus_diag_log( $m );
		$error    = array( $response->get_error_code(), $response->get_error_message() );
		$response = array( 'error' => $error );
	}

	nexus_diag_log( 'Sending the response to the main website...' );

	$result = nexus_net_send_responce( $response );

	if ( crb_is_wp_error( $result ) ) {
		nexus_diag_log( __( 'ERROR:', 'wp-cerber' ) . ' ' . $result->get_error_message() );
	}

	cerber_delete_set( 'processing_master_request' );
	nexus_diag_log( '=== NEXUS CLIENT FINISHED ' . CERBER_VER . ' ===' );

	exit;
}

/**
 * Avoid simultaneous requests from the master(s)
 *
 * @return bool
 *
 */
function nexus_is_processing() {
	return ( cerber_get_set( 'processing_master_request' ) ) ? true : false;
}

/**
 * Renders a plugin admin page to be displayed on the main Cerber.Hub website.
 *
 * Settings forms on the page are generated by the internal form engine
 * (CRB_Settings_Renderer via cerber_show_settings_form()); no WordPress
 * Settings API registration is involved.
 *
 * @param string $page Plugin admin page ID requested by the main website
 * @param string $tab Tab ID on the admin page, empty for the default tab
 *
 * @return string The rendered page HTML
 */
function nexus_render_admin_page( $page, $tab ) {
	ob_start();
	cerber_render_admin_page( $page, $tab );    // Render whole html

	return ob_get_clean();
}

function nexus_parse_request() {
	$fields = nexus_get_fields();
	if ( ! $payload = cerber_get_post( $fields[1] ) ) {
		return new WP_Error( 'nexus_format_error', 'Invalid request: master request malformed' );
	}
	$request = json_decode( stripslashes( $payload ), true );
	if ( JSON_ERROR_NONE != json_last_error() ) {
		return new WP_Error( 'json_error', 'Unable to parse JSON: ' . json_last_error_msg() );
	}

	return $request;
}

function nexus_prepare_response() {

	$nexus_request = nexus_request_data();

	nexus_diag_log( 'Type: ' . $nexus_request->type );

	if ( ! nexus_is_granted() ) {
		return new WP_Error( 'not_allowed', 'Operation is not allowed in this context' );
	}

	$result = '';

	switch ( $nexus_request->type ) {
		case 'get_page':
			CRB_Addons::load_active();

			return array(
				'html' => nexus_render_admin_page( $nexus_request->page, $nexus_request->tab ),
				//'o'    => get_option( 'gmt_offset' ),
				//'z'    => get_option( 'timezone_string' ),
			);
			break;
		case 'submit':
			CRB_Addons::load_active();

			if ( $nexus_request->get_post_fields( CRB_SETTINGS_SCREEN_ID_FIELD ) ) { // Plugin settings form
				return nexus_process_settings_form( $nexus_request->get_post_fields() );
			}
			else {
				return crb_process_admin_request( $nexus_request->is_post );
			}
			// A new way: processing + follow up rendering in a single request
			//return nexus_render_admin_page( $nexus_request->page, $nexus_request->tab );
			break;
		case 'manage':
			return crb_process_admin_request( $nexus_request->is_post );
			break;
		case 'hello':
			//case 'checkup':
			return array( 'numbers' => nexus_get_numbers() );
			break;
		case 'ping':
			return array( 'pong' );
			break;
		case 'sw_upgrade':
			$result             = nexus_sw_upgrade();
			$result ['numbers'] = nexus_get_numbers();
			if ( ! $result['updates'] ) {
				//nexus_diag_log( 'No updates are available' );
			}
			break;
		case 'ajax':
			if ( ! crb_admin_allowed_ajax( $nexus_request->action ) ) {
				return new WP_Error( 'unknown_ajax', 'The action ' . $nexus_request->action . ' is not supported' );
			}
			global $nexus_doing_ajax;
			$nexus_doing_ajax = true;
			ob_start();
			do_action( 'wp_ajax_' . $nexus_request->action );
			$nexus_doing_ajax = false;
			nexus_diag_log( 'AJAX ' . $nexus_request->action . ' completed' );

			return ob_get_clean();
			break;
		default:
			return new WP_Error( 'unknown_request', 'This type of request is not supported' );
			break;
	}

	return $result;
}

function nexus_sw_upgrade() {
	$ret = array( 'updates' => 0, 'completed' => 1, 'results' => array() );

	if ( nexus_is_processing() ) {
		$ret['completed'] = 0;
		$ret['wait']      = cerber_get_remote_ip();

		return $ret;
	}

	$list = crb_array_get( nexus_request_data()->payload, 'list' );
	switch ( nexus_request_data()->payload['sw_type'] ) {
		case 'plugins':
			if ( empty( $list ) ) {
				// Upgrade all
				$to_update = array();
				$active  = get_option( 'active_plugins' );

				if ( ! $plugins = get_site_transient( 'update_plugins' ) ) {
					wp_update_plugins();
					$plugins = get_site_transient( 'update_plugins' );
				}

				if ( isset( $plugins->response ) ) {
					$to_update = array_intersect( $active, array_keys( $plugins->response ) );
				}

				nexus_diag_log( 'Total active plugins to update: ' . count( $to_update ) );

				if ( $done = cerber_get_set( 'plugins_done' ) ) { // Upgraded in the current bulk operation
					$to_do = array_diff( $to_update, $done );
				}
				else {
					$done  = array();
					$to_do = $to_update;
				}

				if ( ! empty( $to_do ) ) {
					$run_now = array_shift( $to_do );
					$done[]  = $run_now;
					$list    = array( $run_now );
				}

				if ( ! empty( $to_do ) ) {
					$ret['completed'] = 0; // Something left
					cerber_update_set( 'plugins_done', $done, 0, true, time() + 300 * count( $to_do ) );
				}
				else {
					cerber_delete_set( 'plugins_done' );
				}
			}

			if ( ! empty( $list ) && is_array( $list ) ) {
				foreach ( $list as $obj ) {
					$ret['results'][ $obj ] = cerber_update_plugin( $obj );
				}
			}

			break;
	}

	nexus_diag_log( cerber_flat_results( $ret['results'] ) );

	return $ret;
}

/**
 * Processes a plugin settings form submitted on the main Cerber.Hub website
 * and forwarded to this managed website.
 *
 * Verifies the plugin form nonce that was generated while this website
 * rendered the form (see cerber_nonce_field()) and validates the submitted
 * settings screen ID against the known settings screens, then saves the
 * settings through the standard internal pipeline cerber_process_settings_form().
 * The request itself has already been authenticated by the Nexus transport.
 *
 * @param array<string,string|array> $form_fields Settings form fields sent by the main website
 *
 * @return string|WP_Error Empty string on success, WP_Error otherwise
 */
function nexus_process_settings_form( array $form_fields ) {
	$settings_screen_id = (string) crb_array_get( $form_fields, CRB_SETTINGS_SCREEN_ID_FIELD, '' );

	if ( ! wp_verify_nonce( (string) crb_array_get( $form_fields, 'cerber_nonce', '' ), 'control' ) ) {
		return new WP_Error( 'nonce_failed', 'Nonce verification failed' );
	}

	// Entry-point validation: the submitted ID must identify a known settings screen

	if ( ! CRB_Settings_Registry::is_known_screen( $settings_screen_id ) ) {
		return new WP_Error( 'unknown_settings_screen', 'Unknown settings screen: ' . $settings_screen_id );
	}

	nexus_diag_log( 'Updating settings for the screen ' . $settings_screen_id );

	if ( ! cerber_process_settings_form() ) {
		return new WP_Error( 'not_processed', 'The settings form has not been processed: ' . $settings_screen_id );
	}

	return '';
}

/**
 * Sends response to the main website.
 *
 * @param string|array $payload
 *
 * @return bool|WP_Error
 */
function nexus_net_send_responce( $payload ) {
	$ret = true;
	$status = '';

	if ( is_array( $payload ) ) {
		$p = json_encode( $payload, JSON_UNESCAPED_UNICODE );
	}
	elseif ( is_scalar( $payload ) ) {
		$p = (string) $payload;
	}
	else {
		$p = '';
		$ret = new WP_Error( 'wrong_type', 'Unsupported payload format' );
	}

	$processing = microtime( true ) - cerber_request_time();

	$role = nexus_get_role_data();

	$hash = hash( 'sha512', $role['slave']['nx_echo'] . sha1( $p ) );

	$response = json_encode( array(
		'payload' => $payload,
		'extra'   => array(
			'versions' => array( CERBER_VER, cerber_get_wp_version(), PHP_MAJOR_VERSION, PHP_MINOR_VERSION, PHP_RELEASE_VERSION, PHP_OS, lab_lab( 2 ) )
		),
		'echo'    => $hash,
		'p_time'  => $processing,
		'scheme'  => 2 // 8.0.5
	), JSON_UNESCAPED_UNICODE );

	if ( JSON_ERROR_NONE != json_last_error() ) {
		$response = 'Unable to encode response payload. JSON encoding error.';
		$status = $response;

		$ret = new WP_Error( 'json_error', 'Unable to encode JSON: ' . json_last_error_msg() );
	}

	// Send response to the main website

	header( "X-Client-Status: " . $status );
	echo $response;

	return $ret;
}

function nexus_is_granted( $type = null ) {

	$acs = crb_get_settings( 'slave_access' );
	$lab = lab_lab();

	if ( $acs >= 8 ) {
		return false;
	}

	if ( $acs == 2 ) {
		if ( $lab ) {
			return true;
		}
	}

	// RO mode

	if ( ! $type ) {
		$type = nexus_request_data()->type;
	}

	if ( in_array( $type, array( 'get_page', 'hello', 'ping', 'sw_upgrade' ) ) ) {
		return true;
	}

	if ( $type == 'submit' ) {
		if ( crb_get_post_fields( 'cerber_license' ) ) {
			return true;
		}
		return false;
	}

	if ( $type == 'ajax' ) {
		$action = nexus_request_data()->action;
		if ( ! crb_admin_allowed_ajax( $action ) ) {
			return false;
		}
		if ( in_array( $action, array( 'cerber_scan_control', 'cerber_view_file' ) ) ) {
			return true;
		}
		if ( $action == 'cerber_ajax' && ! crb_get_request_field( 'acl_delete' ) ) {
			return true;
		}
	}

	return false;
}

function nexus_get_numbers() {
	$numbers = array();
	$active_plugins = get_option( 'active_plugins' );

	// see wp_get_update_data();
	$updates  = array( 'plugins' => 0, 'themes' => 0, 'wp' => 0, 'translations' => 0 );

	$pl_updates = get_site_transient( 'update_plugins' );
	if ( ! $pl_updates || ( $pl_updates->last_checked < ( time() - 7200 ) ) ) {
		delete_site_transient( 'update_plugins' );
		wp_update_plugins();
		$pl_updates = get_site_transient( 'update_plugins' );
	}

	if ( ! empty( $pl_updates->response ) ) {
		$updates['plugins'] = count( array_intersect( $active_plugins, array_keys( $pl_updates->response ) ) );
	}

	include_once( ABSPATH . 'wp-admin/includes/update.php' );
	if ( function_exists( 'get_core_updates' ) ) {
		$wp = get_core_updates( array( 'dismissed' => false ) );
		if ( ! empty( $wp ) ) {
			$updates['wp'] = 1;
		}
	}

	$scan = array();
	if ( ( $last_scan = cerber_get_scan() ) && $last_scan['finished'] ) {
		$scan['finished'] = $last_scan['finished'];
		$scan['numbers']  = $last_scan['numbers'];
	}

	$numbers['updates'] = $updates;
	$numbers['scan']    = $scan;

	// New

	$list = array();
	if ( ! empty( $pl_updates->response ) ) {
		$list = array_map( function ( $e ) {
			//$ret = (array) $e;
			$ret = array_map( function ( $e ) {
				return ( is_object( $e ) ) ? (array) $e : $e;
			}, (array) $e );

			return $ret;
		}, $pl_updates->response );
	}

	$numbers['pl_updates'] = $list;
	$numbers['active']     = $active_plugins;
	$numbers['plugins']    = get_plugins();
	$numbers['themes']     = crb_get_themes();
	$numbers['gmt']        = get_option( 'gmt_offset' );
	$numbers['tz']         = get_option( 'timezone_string' );

	return $numbers;
}

// We have to use our own "user id"
add_filter( 'nonce_user_logged_out', function ( $uid, $action ) {
	if ( ! nexus_is_valid_request() ) {
		return $uid;
	}

	return PHP_INT_MAX;

}, 10, 2 );
