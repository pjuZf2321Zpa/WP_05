<?php
/**
 * Plugin Name:           AutomatorWP - SliceWP
 * Plugin URI:            https://automatorwp.com/add-ons/slicewp/
 * Description:           Connect AutomatorWP with SliceWP.
 * Version:               1.0.2
 * Author:                AutomatorWP
 * Author URI:            https://automatorwp.com/
 * Text Domain:           automatorwp-slicewp
 * Domain Path:           /languages/
 * Requires at least:     4.4
 * Tested up to:          6.1
 * License:               GNU AGPL v3.0 (http://www.gnu.org/licenses/agpl.txt)
 *
 * @package               AutomatorWP\SliceWP
 * @author                AutomatorWP
 * @copyright             Copyright (c) AutomatorWP
 */

final class AutomatorWP_SliceWP {

    /**
     * @var         AutomatorWP_SliceWP $instance The one true AutomatorWP_SliceWP
     * @since       1.0.0
     */
    private static $instance;

    /**
     * Get active instance
     *
     * @access      public
     * @since       1.0.0
     * @return      AutomatorWP_SliceWP self::$instance The one true AutomatorWP_SliceWP
     */
    public static function instance() {
        if( !self::$instance ) {
            self::$instance = new AutomatorWP_SliceWP();
            self::$instance->constants();
            self::$instance->includes();
            self::$instance->hooks();            
        }

        return self::$instance;
    }

    /**
     * Setup plugin constants
     *
     * @access      private
     * @since       1.0.0
     * @return      void
     */
    private function constants() {
        // Plugin version
        define( 'AUTOMATORWP_SLICEWP_VER', '1.0.2' );

        // Plugin file
        define( 'AUTOMATORWP_SLICEWP_FILE', __FILE__ );

        // Plugin path
        define( 'AUTOMATORWP_SLICEWP_DIR', plugin_dir_path( __FILE__ ) );

        // Plugin URL
        define( 'AUTOMATORWP_SLICEWP_URL', plugin_dir_url( __FILE__ ) );
    }

    /**
     * Include plugin files
     *
     * @access      private
     * @since       1.0.0
     * @return      void
     */
    private function includes() {

        if( $this->meets_requirements() ) {

            // Includes
            require_once AUTOMATORWP_SLICEWP_DIR . 'includes/functions.php';
            require_once AUTOMATORWP_SLICEWP_DIR . 'includes/tags.php';

            // Triggers
            require_once AUTOMATORWP_SLICEWP_DIR . 'includes/triggers/become-affiliate.php';
            require_once AUTOMATORWP_SLICEWP_DIR . 'includes/triggers/earn-commission.php';
            require_once AUTOMATORWP_SLICEWP_DIR . 'includes/triggers/commission.php';

            // Actions
            require_once AUTOMATORWP_SLICEWP_DIR . 'includes/actions/add-commission.php';
            require_once AUTOMATORWP_SLICEWP_DIR . 'includes/actions/add-commission-to-affiliate.php';

        }
    }

    /**
     * Setup plugin hooks
     *
     * @access      private
     * @since       1.0.0
     * @return      void
     */
    private function hooks() {

        add_action( 'automatorwp_init', array( $this, 'register_integration' ) );
        
        // Setup our activation and deactivation hooks
        register_activation_hook( __FILE__, array( $this, 'activate' ) );
        register_deactivation_hook( __FILE__, array( $this, 'deactivate' ) );
        

        
    }

    /**
     * Registers this integration
     *
     * @since 1.0.0
     */
    function register_integration() {

        automatorwp_register_integration( 'slicewp', array(
            'label' => 'SliceWP',
            'icon'  => AUTOMATORWP_SLICEWP_URL . 'assets/slicewp.svg',
        ) );

    }

    /**
     * Activation hook for the plugin.
     *
     * @since  1.0.0
     */
    function activate() {

        if( $this->meets_requirements() ) {

        }

    }

    /**
     * Deactivation hook for the plugin.
     *
     * @since  1.0.0
     */
    function deactivate() {

    }

    /**
     * Check if there are all plugin requirements
     *
     * @since  1.0.0
     *
     * @return bool True if installation meets all requirements
     */
    private function meets_requirements() {

        if ( ! class_exists( 'AutomatorWP' ) ) {
            return false;
        }

        if ( ! class_exists( 'SliceWP' ) ) {
            return false;
        }

        return true;

    }

}

/**
 * The main function responsible for returning the one true AutomatorWP_SliceWP instance to functions everywhere
 *
 * @since       1.0.0
 * @return      \AutomatorWP_SliceWP The one true AutomatorWP_SliceWP
 */
function AutomatorWP_SliceWP() {
    return AutomatorWP_SliceWP::instance();
}
add_action( 'plugins_loaded', 'AutomatorWP_SliceWP' );
