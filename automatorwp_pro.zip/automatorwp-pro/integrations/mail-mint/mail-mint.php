<?php
/**
 * Plugin Name:           AutomatorWP - Mail Mint
 * Plugin URI:            https://automatorwp.com/add-ons/mail-mint/
 * Description:           Connect AutomatorWP with Mail Mint
 * Version:               1.0.0
 * Author:                AutomatorWP
 * Author URI:            https://automatorwp.com/
 * Text Domain:           automatorwp-mail-mint
 * Domain Path:           /languages/
 * Requires at least:     4.4
 * Tested up to:          7.0
 * Requires PHP:          7.4
 * License:               GNU AGPL v3.0 (http://www.gnu.org/licenses/agpl.txt)
 *
 * @package               AutomatorWP\Mail_Mint
 * @author                AutomatorWP
 * @copyright             Copyright (c) AutomatorWP
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

final class AutomatorWP_Mail_Mint {
    /**
     * @var         AutomatorWP_Mail_Mint $instance The one true AutomatorWP_Mail_Mint
     * @since       1.0.0
     */
    private static $instance;

    /**
     * Get active instance
     *
     * @access      public
     * @since       1.0.0
     * @return      AutomatorWP_Mail_Mint self::$instance
     */
    public static function instance() {
        if ( ! self::$instance ) {
            self::$instance = new AutomatorWP_Mail_Mint();
            self::$instance->constants();
            self::$instance->includes();
            self::$instance->hooks();        }

        return self::$instance;
    }

    /**
     * Setup plugin constants
     *
     * @access      private
     * @since       1.0.0
     * @return      void
     */
    private function constants() {
        // Plugin version
        define( 'AUTOMATORWP_MAIL_MINT_VER',  '1.0.0' );

        // Plugin file
        define( 'AUTOMATORWP_MAIL_MINT_FILE', __FILE__ );

        // Plugin path
        define( 'AUTOMATORWP_MAIL_MINT_DIR',  plugin_dir_path( __FILE__ ) );

        // Plugin URL
        define( 'AUTOMATORWP_MAIL_MINT_URL',  plugin_dir_url( __FILE__ ) );
    }

    /**
     * Include plugin files
     *
     * @access      private
     * @since       1.0.0
     * @return      void
     */
    private function includes() {

        if ( $this->meets_requirements() ) {
         
            // Functions
            require_once AUTOMATORWP_MAIL_MINT_DIR . 'includes/admin.php';
            require_once AUTOMATORWP_MAIL_MINT_DIR . 'includes/functions.php';
            require_once AUTOMATORWP_MAIL_MINT_DIR . 'includes/ajax-functions.php';
            require_once AUTOMATORWP_MAIL_MINT_DIR . 'includes/tags.php';

            // Triggers
            require_once AUTOMATORWP_MAIL_MINT_DIR . 'includes/triggers/user-contact-added.php';
            require_once AUTOMATORWP_MAIL_MINT_DIR . 'includes/triggers/contact-unsubscribed.php';
            require_once AUTOMATORWP_MAIL_MINT_DIR . 'includes/triggers/tag-added.php';
            require_once AUTOMATORWP_MAIL_MINT_DIR . 'includes/triggers/tag-removed.php';
            require_once AUTOMATORWP_MAIL_MINT_DIR . 'includes/triggers/list-added.php';
            require_once AUTOMATORWP_MAIL_MINT_DIR . 'includes/triggers/list-removed.php';
            require_once AUTOMATORWP_MAIL_MINT_DIR . 'includes/triggers/submit-form.php';
            require_once AUTOMATORWP_MAIL_MINT_DIR . 'includes/triggers/anonymous-contact-added.php';
            require_once AUTOMATORWP_MAIL_MINT_DIR . 'includes/triggers/anonymous-contact-unsubscribed.php';
            require_once AUTOMATORWP_MAIL_MINT_DIR . 'includes/triggers/anonymous-submit-form.php';

            // Actions
            require_once AUTOMATORWP_MAIL_MINT_DIR . 'includes/actions/create-user-contact.php';
            require_once AUTOMATORWP_MAIL_MINT_DIR . 'includes/actions/create-contact.php';
            require_once AUTOMATORWP_MAIL_MINT_DIR . 'includes/actions/delete-user-contact.php';
            require_once AUTOMATORWP_MAIL_MINT_DIR . 'includes/actions/delete-contact.php';
            require_once AUTOMATORWP_MAIL_MINT_DIR . 'includes/actions/user-add-list.php';
            require_once AUTOMATORWP_MAIL_MINT_DIR . 'includes/actions/user-remove-list.php';
            require_once AUTOMATORWP_MAIL_MINT_DIR . 'includes/actions/user-add-tag.php';
            require_once AUTOMATORWP_MAIL_MINT_DIR . 'includes/actions/user-remove-tag.php';
            require_once AUTOMATORWP_MAIL_MINT_DIR . 'includes/actions/contact-add-list.php';
            require_once AUTOMATORWP_MAIL_MINT_DIR . 'includes/actions/contact-add-tag.php';
            require_once AUTOMATORWP_MAIL_MINT_DIR . 'includes/actions/contact-remove-list.php';
            require_once AUTOMATORWP_MAIL_MINT_DIR . 'includes/actions/contact-remove-tag.php';
            require_once AUTOMATORWP_MAIL_MINT_DIR . 'includes/actions/contact-change-status.php';
            require_once AUTOMATORWP_MAIL_MINT_DIR . 'includes/actions/user-change-status.php';

        }
    }

    /**
     * Setup plugin hooks
     *
     * @access      private
     * @since       1.0.0
     * @return      void
     */
    private function hooks() {

        add_action( 'automatorwp_init', array( $this, 'register_integration' ) );
        
        // Setup our activation and deactivation hooks
        register_activation_hook( __FILE__, array( $this, 'activate' ) );
        register_deactivation_hook( __FILE__, array( $this, 'deactivate' ) );
        

        
    }

    /**
     * Registers this integration with AutomatorWP
     *
     * @since 1.0.0
     */
    public function register_integration() {

        automatorwp_register_integration( 'mail_mint', array(
            'label' => 'Mail Mint',
            'icon'  => AUTOMATORWP_MAIL_MINT_URL . 'assets/mail-mint.svg',
        ) );

    }

    /**
     * Activation hook for the plugin.
     *
     * @since  1.0.0
     */
    function activate() {

        if( $this->meets_requirements() ) {

        }

    }

    /**
     * Deactivation hook for the plugin.
     *
     * @since  1.0.0
     */
    function deactivate() {

    }

    /**
     * Show admin notice when a required plugin is not active.
     *
     * @since 1.0.0
     */
    public function admin_notices() {

        if ( ! $this->meets_requirements() && ! defined( 'AUTOMATORWP_ADMIN_NOTICES' ) ) : ?>

            <div id="message" class="notice notice-error is-dismissible">
                <p>
                    <?php printf(
                        __( 'AutomatorWP - Mail Mint requires %s and %s in order to work. Please install and activate them.', 'automatorwp-pro' ),
                        '<a href="https://wordpress.org/plugins/automatorwp/" target="_blank">AutomatorWP</a>',
                        '<a href="https://wordpress.org/plugins/mail-mint/" target="_blank">Mail Mint</a>'
                    ); ?>
                </p>
            </div>

            <?php define( 'AUTOMATORWP_ADMIN_NOTICES', true ); ?>

        <?php endif;

    }

    /**
     * Check if all plugin requirements are met
     *
     * @since 1.0.0
     *
     * @return bool
     */
    private function meets_requirements() {

        if ( ! class_exists( 'AutomatorWP' ) ) {
            return false;
        }

        if ( ! defined( 'MRM_VERSION' ) ) {
            return false;
        }

        return true;

    }

}
/**
 * The main function responsible for returning the one true AutomatorWP_Mail_Mint instance
 *
 * @since       1.0.0
 * @return      AutomatorWP_Mail_Mint
 */
function AutomatorWP_Mail_Mint() {
    return AutomatorWP_Mail_Mint::instance();
}
add_action( 'plugins_loaded', 'AutomatorWP_Mail_Mint' );
