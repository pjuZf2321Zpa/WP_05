<?php
/**
 * Functions
 *
 * @package     AutomatorWP\Integrations\Mail_Mint\Functions
 * @author      AutomatorWP <contact@automatorwp.com>
 * @since       1.0.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Options callback for select2 fields assigned to lists
 *
 * @since 1.0.0
 * 
 * @param stdClass $field
 *
 * @return array
 */
function automatorwp_mail_mint_options_cb_list( $field ) {

    // Setup vars
    $value = $field->escaped_value;
    $none_value = 'any';
    $none_label = __( 'any list', 'automatorwp-pro' );
    $options = automatorwp_options_cb_none_option( $field, $none_value, $none_label );
    
    if( ! empty( $value ) ) {
        if( ! is_array( $value ) ) {
            $value = array( $value );
        }
    
        foreach( $value as $list_id ) {

            // Skip option none
            if( $list_id === $none_value ) {
                continue;
            }

            $options[$list_id] = automatorwp_mail_mint_get_list_name( $list_id );
        }
    }

    return $options;

}

/**
 * Get all Mail Mint lists
 *
 * @since 1.0.0
 *
 * @return array
 */
function automatorwp_mail_mint_get_lists() {

    $lists = array();

    // Bail if class does not exist
    if( ! class_exists ( 'Mint\MRM\DataBase\Models\ContactGroupModel' ) )
        return;

    //Type: lists or tags
    $all_lists = Mint\MRM\DataBase\Models\ContactGroupModel::get_all_lists_or_tags( 'lists' );

    foreach ( $all_lists as $list ) {
        $lists[] = array(
            'id'    => $list['id'],
            'name'  => $list['title'],
        );
    }

    return $lists;

}

/**
* Get the list name
*
* @since 1.0.0
* 
* @param string $list_id
*
* @return array
*/
function automatorwp_mail_mint_get_list_name( $list_id ) {

    // Empty title if no ID provided
    if( absint( $list_id ) === 0 ) {
        return '';
    }

    // Bail if class does not exist
    if( ! class_exists ( 'Mint\MRM\DataBase\Models\ContactGroupModel' ) || ! class_exists ( 'MRM\Common\MrmCommon' ) )
            return;
        
    $all_lists = Mint\MRM\DataBase\Models\ContactGroupModel::get_all_lists_or_tags( 'lists' );

    $list = MRM\Common\MrmCommon::search_for_id( $list_id, $all_lists );

    return $list['title'];

}

/**
 * Options callback for select2 fields assigned to tags
 *
 * @since 1.0.0
 * 
 * @param stdClass $field
 *
 * @return array
 */
function automatorwp_mail_mint_options_cb_tag( $field ) {

    // Setup vars
    $value = $field->escaped_value;
    $none_value = 'any';
    $none_label = __( 'any tag', 'automatorwp-pro' );
    $options = automatorwp_options_cb_none_option( $field, $none_value, $none_label );
    
    if( ! empty( $value ) ) {
        if( ! is_array( $value ) ) {
            $value = array( $value );
        }
    
        foreach( $value as $tag_id ) {

            // Skip option none
            if( $tag_id === $none_value ) {
                continue;
            }

            $options[$tag_id] = automatorwp_mail_mint_get_tag_name( $tag_id );
        }
    }

    return $options;

}

/**
 * Get all Mail Mint tags
 *
 * @since 1.0.0
 *
 * @return array
 */
function automatorwp_mail_mint_get_tags() {

    $tags = array();

    // Bail if class does not exist
    if( ! class_exists ( 'Mint\MRM\DataBase\Models\ContactGroupModel' ) )
        return;

    //Type: lists or tags
    $all_tags = Mint\MRM\DataBase\Models\ContactGroupModel::get_all_lists_or_tags( 'tags' );

    foreach ( $all_tags as $tag ) {
        $tags[] = array(
            'id'    => $tag['id'],
            'name'  => $tag['title'],
        );
    }

    return $tags;

}

/**
* Get the tag name
*
* @since 1.0.0
* 
* @param string $list_id
*
* @return array
*/
function automatorwp_mail_mint_get_tag_name( $tag_id ) {

    // Empty title if no ID provided
    if( absint( $tag_id ) === 0 ) {
        return '';
    }

    // Bail if class does not exist
    if( ! class_exists ( 'Mint\MRM\DataBase\Models\ContactGroupModel' ) || ! class_exists ( 'MRM\Common\MrmCommon' ) )
            return;

    $all_tags = Mint\MRM\DataBase\Models\ContactGroupModel::get_all_lists_or_tags( 'tags' );

    $tag = MRM\Common\MrmCommon::search_for_id( $tag_id, $all_tags );

    return $tag['title'];

}


/**
 * Options callback for select2 fields assigned to forms
 *
 * @since 1.0.0
 * 
 * @param stdClass $field
 *
 * @return array
 */
function automatorwp_mail_mint_options_cb_form( $field ) {

    // Setup vars
    $value = $field->escaped_value;
    $none_value = 'any';
    $none_label = __( 'any form', 'automatorwp-pro' );
    $options = automatorwp_options_cb_none_option( $field, $none_value, $none_label );
    
    if( ! empty( $value ) ) {
        if( ! is_array( $value ) ) {
            $value = array( $value );
        }
    
        foreach( $value as $form_id ) {

            // Skip option none
            if( $form_id === $none_value ) {
                continue;
            }

            $options[$form_id] = automatorwp_mail_mint_get_form_name( $form_id );
        }
    }

    return $options;

}

/**
 * Get all Mail Mint forms
 *
 * @since 1.0.0
 *
 * @return array
 */
function automatorwp_mail_mint_get_forms() {
    
    $forms = array();

    // Bail if class does not exist
    if( ! class_exists ( 'Mint\MRM\DataBase\Models\FormModel' ) )
        return '';

    $all_forms = Mint\MRM\DataBase\Models\FormModel::get_all( 'id', 'asc', 'published' );

    foreach ( $all_forms['data'] as $form ) {
        $forms[] = array(
            'id'    => $form['id'],
            'name'  => $form['title'],
        );
    }

    return $forms;

}

/**
* Get the form name
*
* @since 1.0.0
* 
* @param string $form_id
*
* @return array
*/
function automatorwp_mail_mint_get_form_name( $form_id ) {

    // Empty title if no ID provided
    if( absint( $form_id ) === 0 ) {
        return '';
    }

    // Bail if class does not exist
    if( ! class_exists ( 'Mint\MRM\DataBase\Models\FormModel' ) )
        return '';

    $form = Mint\MRM\DataBase\Models\FormModel::get( $form_id );

    return $form['title'];

}
