<?php
/**
 * Submit Form
 *
 * @package     AutomatorWP\Integrations\Mail_Mint\Triggers\Submit_Form
 * @author      AutomatorWP <contact@automatorwp.com>, Ruben Garcia <rubengcdev@gmail.com>
 * @since       1.0.0
 */
// Exit if accessed directly
if( !defined( 'ABSPATH' ) ) exit;

class AutomatorWP_Mail_Mint_Submit_Form extends AutomatorWP_Integration_Trigger {

    public $integration = 'mail_mint';
    public $trigger = 'mail_mint_submit_form';

    /**
     * Register the trigger
     *
     * @since 1.0.0
     */
    public function register() {

        automatorwp_register_trigger( $this->trigger, array(
            'integration'       => $this->integration,
            'label'             => __( 'User submits a form', 'automatorwp-pro' ),
            'select_option'     => __( 'User submits <strong>a form</strong>', 'automatorwp-pro' ),
            /* translators: %1$s: Form. %2$s: Number of times. */
            'edit_label'        => sprintf( __( 'User submits %1$s %2$s time(s)', 'automatorwp-pro' ), '{form}', '{times}' ),
            /* translators: %1$s: Form. */
            'log_label'         => sprintf( __( 'User submits %1$s', 'automatorwp-pro' ), '{form}' ),
            'action'            => 'mailmint_after_form_submit',
            'function'          => array( $this, 'listener' ),
            'priority'          => 10,
            'accepted_args'     => 3,
            'options'           => array(
                'form' => automatorwp_utilities_ajax_selector_option( array(
                    'field'             => 'form',
                    'name'              => __( 'Form:', 'automatorwp-pro' ),
                    'option_none_value' => 'any',
                    'option_none_label' => __( 'any form', 'automatorwp-pro' ),
                    'action_cb'         => 'automatorwp_mail_mint_get_forms',
                    'options_cb'        => 'automatorwp_mail_mint_options_cb_form',
                    
                ) ),
                'times' => automatorwp_utilities_times_option(),
            ),
            'tags' => array_merge(
                automatorwp_mail_mint_contact_tags(),
                automatorwp_utilities_times_tag()
            )
        ) );

    }

    /**
     * Trigger listener
     *
     * @since 1.0.0
     *
     * @param int    $form_id    The ID of the submitted form.
	 * @param int    $contact_id The ID of the contact associated with the form submission.
	 * @param object $contact    The contact object containing information about the submitted form.
     */
    public function listener( $form_id, $contact_id, $contact ) {
            
        $user_id = get_current_user_id();

        // Login is required
        if ( $user_id === 0 ) {
            return;
        }

        // Trigger submit form event
        automatorwp_trigger_event( array(
            'trigger'       => $this->trigger,
            'user_id'       => $user_id,
            'form_id'       => $form_id,
            'contact_id'    => $contact_id,
        ) );

    }

    /**
     * User deserves check
     *
     * @since 1.0.0
     *
     * @param bool      $deserves_trigger   True if user deserves trigger, false otherwise
     * @param stdClass  $trigger            The trigger object
     * @param int       $user_id            The user ID
     * @param array     $event              Event information
     * @param array     $trigger_options    The trigger's stored options
     * @param stdClass  $automation         The trigger's automation object
     *
     * @return bool                          True if user deserves trigger, false otherwise
     */
    public function user_deserves_trigger( $deserves_trigger, $trigger, $user_id, $event, $trigger_options, $automation ) {

        // Don't deserve if post is not received
        if( ! isset( $event['form_id'] ) ) {
            return false;
        }

        // Bail if post doesn't match with the trigger option
        if( $trigger_options['form'] !== 'any' && absint( $event['form_id'] ) !== absint( $trigger_options['form'] ) ) {
            return false;
        }

        return $deserves_trigger;

    }

    /**
     * Register the required hooks
     *
     * @since 1.0.0
     */
    public function hooks() {

        // Log meta data
        add_filter( 'automatorwp_user_completed_trigger_log_meta', array( $this, 'log_meta' ), 10, 6 );

        parent::hooks();
    }

    /**
     * Trigger custom log meta
     *
     * @since 1.0.0
     *
     * @param array     $log_meta           Log meta data
     * @param stdClass  $trigger            The trigger object
     * @param int       $user_id            The user ID
     * @param array     $event              Event information
     * @param array     $trigger_options    The trigger's stored options
     * @param stdClass  $automation         The trigger's automation object
     *
     * @return array
     */
    function log_meta( $log_meta, $trigger, $user_id, $event, $trigger_options, $automation ) {

        // Bail if action type don't match this action
        if( $trigger->type !== $this->trigger ) {
            return $log_meta;
        }

        $log_meta['form_id'] = ( isset( $event['form_id'] ) ? $event['form_id'] : '' );
        $log_meta['contact_id'] = ( isset( $event['contact_id'] ) ? $event['contact_id'] : '' );

        return $log_meta;

    }
}

new AutomatorWP_Mail_Mint_Submit_Form();