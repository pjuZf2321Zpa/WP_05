<?php
/**
 * Anonymous Contact Unsubscribed
 *
 * @package     AutomatorWP\Integrations\Mail_Mint\Triggers\Anonymous_Contact_Unsubscribed
 * @author      AutomatorWP <contact@automatorwp.com>
 * @since       1.0.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

class AutomatorWP_Mail_Mint_Anonymous_Contact_Unsubscribed extends AutomatorWP_Integration_Trigger
{
    public $integration = 'mail_mint';
    public $trigger     = 'mail_mint_anonymous_contact_unsubscribed';

    /**
     * Register the trigger
     *
     * @since 1.0.0
     */
    public function register() {

        automatorwp_register_trigger( $this->trigger, array(
            'integration'   => $this->integration,
            'anonymous'     => true,
            'label'         => __( 'Guest status changes to unsubscribed', 'automatorwp-pro' ),
            'select_option' => __( 'Guest status changes to <strong>unsubscribed</strong>', 'automatorwp-pro' ),
            /* translators: %1$s: Number of times. */
            'edit_label'    => sprintf( __( 'Guest status changes to unsubscribed %1$s time(s)', 'automatorwp-pro' ), '{times}' ),
            'log_label'     => __( 'Guest status changes to unsubscribed', 'automatorwp-pro' ),
            'action'        => 'mint_subscriber_status_to_unsubscribed',
            'function'      => array( $this, 'listener' ),
            'priority'      => 10,
            'accepted_args' => 2,
            'options'       => array(
                'times' => automatorwp_utilities_times_option(),
            ),
            'tags' => array_merge(
                automatorwp_mail_mint_contact_tags(),
                automatorwp_utilities_times_tag()
            ),
        ) );
    }

    /**
     * Trigger listener
     *
     * @since 1.0.0
     *
     * @param int    $contact_id
     * @param string $old_status
     */
    public function listener( $contact_id, $old_status ) {
    
        if( ! class_exists ( 'Mint\MRM\DataBase\Models\ContactModel' ) )
            return;

        // Get contact email
        $contact_email = Mint\MRM\DataBase\Models\ContactModel::get_email_by_id( $contact_id );

        // Bail if not contact email
        if ( ! $contact_email )
            return;

        if ( $old_status !== 'unsubscribed' )
            return;

        // Trigger the user added to contacts
        automatorwp_trigger_event( array(
            'trigger'   => $this->trigger,
            'contact_id' => $contact_id,
        ) );
    }

    /**
     * Register the required hooks
     *
     * @since 1.0.0
     */
    public function hooks() {

        // Log meta data
        add_filter( 'automatorwp_anonymous_completed_trigger_log_meta', array( $this, 'log_meta' ), 10, 5 );

        parent::hooks();
    }

    /**
     * Trigger custom log meta
     *
     * @since 1.0.0
     *
     * @param array     $log_meta           Log meta data
     * @param stdClass  $trigger            The trigger object
     * @param array     $event              Event information
     * @param array     $trigger_options    The trigger's stored options
     * @param stdClass  $automation         The trigger's automation object
     *
     * @return array
     */
    function log_meta( $log_meta, $trigger, $event, $trigger_options, $automation ) {

        // Bail if action type don't match this action
        if( $trigger->type !== $this->trigger ) {
            return $log_meta;
        }

        $log_meta['contact_id'] = ( isset( $event['contact_id'] ) ? $event['contact_id'] : '' );

        return $log_meta;

    }

}

new AutomatorWP_Mail_Mint_Anonymous_Contact_Unsubscribed();
