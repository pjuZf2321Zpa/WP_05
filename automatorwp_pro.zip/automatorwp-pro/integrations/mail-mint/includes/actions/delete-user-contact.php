<?php
/**
 * Delete User Contact
 *
 * @package     AutomatorWP\Integrations\Mail_Mint\Actions\Delete_User_Contact
 * @author      AutomatorWP <contact@automatorwp.com>, Ruben Garcia <rubengcdev@gmail.com>
 * @since       1.0.0
 */
// Exit if accessed directly

if( !defined( 'ABSPATH' ) ) exit;

class AutomatorWP_Mail_Mint_Delete_User_Contact extends AutomatorWP_Integration_Action {

    public $integration = 'mail_mint';
    public $action = 'mail_mint_delete_user_contact';
    public $result = '';

    /**
     * Register the trigger
     *
     * @since 1.0.0
     */
    public function register() {

        automatorwp_register_action( $this->action, array(
            'integration'       => $this->integration,
            'label'             => __( 'Delete user from Mail Mint', 'automatorwp-pro' ),
            'select_option'     => __( 'Delete <strong>user</strong> from Mail Mint', 'automatorwp-pro' ),
            'edit_label'        => __( 'Delete user from Mail Mint', 'automatorwp-pro' ),
            'log_label'         => __( 'Delete user from Mail Mint', 'automatorwp-pro' ),
            'options'           => array(
                // No options    
            ),
        ) );

    }

    /**
     * Action execution function
     *
     * @since 1.0.0
     *
     * @param stdClass  $action             The action object
     * @param int       $user_id            The user ID
     * @param array     $action_options     The action's stored options (with tags already passed)
     * @param stdClass  $automation         The action's automation object
     */
    public function execute( $action, $user_id, $action_options, $automation ) {

        $user = get_user_by( 'id', $user_id );
       
        if( ! class_exists ( 'Mint\MRM\DataBase\Models\ContactModel' ) )
            return;

        // Get contact ID
        $contact_id = Mint\MRM\DataBase\Models\ContactModel::get_id_by_email( $user->user_email );

        // Bail if contact ID
        if ( ! $contact_id ){
            $this->result = __( 'User is not added in Mail Mint.', 'automatorwp-pro' );
            return;
        }

		$response =  Mint\MRM\DataBase\Models\ContactModel::destroy( $contact_id );
		
        if ( $response ){
            $this->result = __( 'User deleted from Mail Mint', 'automatorwp-pro' );
        } else {
            $this->result = __( 'Could not delete user from Mail Mint', 'automatorwp-pro' );
        }
        
    }

    /**
     * Register required hooks
     *
     * @since 1.0.0
     */
    public function hooks() {

        // Log meta data
        add_filter( 'automatorwp_user_completed_action_log_meta', array( $this, 'log_meta' ), 10, 5 );

        // Log fields
        add_filter( 'automatorwp_log_fields', array( $this, 'log_fields' ), 10, 5 );

        parent::hooks();

    }

    /**
     * Action custom log meta
     *
     * @since 1.0.0
     *
     * @param array     $log_meta           Log meta data
     * @param stdClass  $action             The action object
     * @param int       $user_id            The user ID
     * @param array     $action_options     The action's stored options (with tags already passed)
     * @param stdClass  $automation         The action's automation object
     *
     * @return array
     */
    public function log_meta( $log_meta, $action, $user_id, $action_options, $automation ) {

        // Bail if action type don't match this action
        if( $action->type !== $this->action ) {
            return $log_meta;
        }

        // Store the action's result
        $log_meta['result'] = $this->result;

        return $log_meta;
    }

    /**
     * Action custom log fields
     *
     * @since 1.0.0
     *
     * @param array     $log_fields The log fields
     * @param stdClass  $log        The log object
     * @param stdClass  $object     The trigger/action/automation object attached to the log
     *
     * @return array
     */
    public function log_fields( $log_fields, $log, $object ) {

        // Bail if log is not assigned to an action
        if( $log->type !== 'action' ) {
            return $log_fields;
        }

        // Bail if action type don't match this action
        if( $object->type !== $this->action ) {
            return $log_fields;
        }

        $log_fields['result'] = array(
            'name' => __( 'Result:', 'automatorwp-pro' ),
            'type' => 'text',
        );

        return $log_fields;
    }

}

new AutomatorWP_Mail_Mint_Delete_User_Contact();