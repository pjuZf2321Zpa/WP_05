<?php
/**
 * Change User Status
 *
 * @package     AutomatorWP\Integrations\Mail_Mint\Actions\Change_User_Status
 * @author      AutomatorWP <contact@automatorwp.com>
 * @since       1.0.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

class AutomatorWP_Mail_Mint_Change_User_Status extends AutomatorWP_Integration_Action
{
    public $integration = 'mail_mint';
    public $action      = 'mail_mint_change_user_status';
    public $result      = '';

    /**
     * Register the action
     *
     * @since 1.0.0
     */
    public function register()
    {
        automatorwp_register_action( $this->action, array(
            'integration'   => $this->integration,
            'label'         => __( 'Set user\'s status to a status', 'automatorwp-pro' ),
            'select_option' => __( 'Set user\'s <strong>status</strong> to a status', 'automatorwp-pro' ),
            /* translators: %1$s: Status. */
            'edit_label'    => sprintf( __( 'Set user\'s status to %1$s', 'automatorwp-pro' ), '{status}' ),
            /* translators: %1$s: Status. */
            'log_label'     => sprintf( __( 'Set user\'s status to %1$s', 'automatorwp-pro' ), '{status}' ),
            'options'       => array(
                'status' => array(
                    'from'    => 'mm_status',
                    'default' => __( 'status', 'automatorwp-pro' ),
                    'fields'  => array(
                        'email' => array(
                            'name' => __( 'User Email:', 'automatorwp-pro' ),
                            'desc' => __( 'The email of the user to add to Mail Mint. By default, Email of user who completes this automation.', 'automatorwp-pro' ),
                            'type' => 'text',
                            'default' => ''
                        ),
                        'mm_status' => array(
                            'name'    => __( 'Status:', 'automatorwp-pro' ),
                            'type'    => 'select',
                            'options' => array(
                                'subscribed'   => __( 'Subscribed',   'automatorwp-pro' ),
                                'unsubscribed' => __( 'Unsubscribed', 'automatorwp-pro' ),
                                'pending'      => __( 'Pending',      'automatorwp-pro' ),
                                'complained'   => __( 'Complained',   'automatorwp-pro' ),
                                'bounced'      => __( 'Bounced',      'automatorwp-pro' ),
                                'inactive'     => __( 'Inactive',     'automatorwp-pro' ),
                            ),
                            'default' => 'pending',
                        ),
                    ),
                ),
            ),
        ) );
    }

    /**
     * Action execution function
     *
     * @since 1.0.0
     *
     * @param stdClass $action         The action object
     * @param int      $user_id        The user ID
     * @param array    $action_options The action's stored options (with tags already parsed)
     * @param stdClass $automation     The action's automation object
     */
    public function execute( $action, $user_id, $action_options, $automation ) {
        
        // Shorthand
        $status = $action_options['mm_status'];
        $user_email = $action_options['email'];

        if ( empty( $user_email ) ) {
            $user = get_user_by( 'id', $user_id );
        } else {
            $user = get_user_by( 'email', $user_email );

            if ( empty( $user ) ) {
                $this->result = __( 'User is not registered', 'automatorwp-pro' );
                return;
            }
        }
       
        if( ! class_exists ( 'Mint\MRM\DataBase\Models\ContactModel' ) )
            return;

        // Get contact ID
        $contact_id = Mint\MRM\DataBase\Models\ContactModel::get_id_by_email( $user->user_email );

        // Bail if contact ID
        if ( ! $contact_id ){
            $this->result = __( 'Contact is not added in Mail Mint.', 'automatorwp-pro' );
            return;
        }

        // Update status
		Mint\MRM\DataBase\Models\ContactModel::update_subscription_status( $contact_id, $status );
		
        $this->result = __( 'Contact status updated', 'automatorwp-pro' );
        
    }

    /**
     * Register required hooks
     *
     * @since 1.0.0
     */
    public function hooks() {

        // Log meta data
        add_filter( 'automatorwp_user_completed_action_log_meta', array( $this, 'log_meta' ), 10, 5 );

        // Log fields
        add_filter( 'automatorwp_log_fields', array( $this, 'log_fields' ), 10, 5 );

        parent::hooks();

    }

    /**
     * Action custom log meta
     *
     * @since 1.0.0
     *
     * @param array     $log_meta           Log meta data
     * @param stdClass  $action             The action object
     * @param int       $user_id            The user ID
     * @param array     $action_options     The action's stored options (with tags already passed)
     * @param stdClass  $automation         The action's automation object
     *
     * @return array
     */
    public function log_meta( $log_meta, $action, $user_id, $action_options, $automation ) {

        // Bail if action type don't match this action
        if( $action->type !== $this->action ) {
            return $log_meta;
        }

        // Store the action's result
        $log_meta['result'] = $this->result;

        return $log_meta;
    }

    /**
     * Action custom log fields
     *
     * @since 1.0.0
     *
     * @param array     $log_fields The log fields
     * @param stdClass  $log        The log object
     * @param stdClass  $object     The trigger/action/automation object attached to the log
     *
     * @return array
     */
    public function log_fields( $log_fields, $log, $object ) {

        // Bail if log is not assigned to an action
        if( $log->type !== 'action' ) {
            return $log_fields;
        }

        // Bail if action type don't match this action
        if( $object->type !== $this->action ) {
            return $log_fields;
        }

        $log_fields['result'] = array(
            'name' => __( 'Result:', 'automatorwp-pro' ),
            'type' => 'text',
        );

        return $log_fields;
    }
}

new AutomatorWP_Mail_Mint_Change_User_Status();
