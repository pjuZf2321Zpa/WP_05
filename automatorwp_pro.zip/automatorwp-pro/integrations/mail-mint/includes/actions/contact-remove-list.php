<?php
/**
 * Contact Remove List
 *
 * @package     AutomatorWP\Integrations\Mail_Mint\Actions\Contact_Remove_List
 * @author      AutomatorWP <contact@automatorwp.com>
 * @since       1.0.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

class AutomatorWP_Mail_Mint_Contact_Remove_List extends AutomatorWP_Integration_Action
{
    public $integration = 'mail_mint';
    public $action      = 'mail_mint_contact_remove_list';
    public $result      = '';

    /**
     * Register the action
     *
     * @since 1.0.0
     */
    public function register() {
        automatorwp_register_action( $this->action, array(
            'integration'   => $this->integration,
            'label'         => __( 'Remove contact from a list', 'automatorwp-pro' ),
            'select_option' => __( 'Remove contact from a <strong>list</strong>', 'automatorwp-pro' ),
            /* translators: %1$s: Contact. %2$s: List */
            'edit_label'    => sprintf( __( 'Remove %1$s from %2$s', 'automatorwp-pro' ), '{contact}', '{list}' ),
            /* translators: %1$s: Contact. %2$s: List */
            'log_label'     => sprintf( __( 'Remove %1$s from %2$s', 'automatorwp-pro' ), '{contact}', '{list}' ),
            'options'           => array(
                'list' => automatorwp_utilities_ajax_selector_option( array(
                    'field'             => 'list',
                    'option_default'    => __( 'List', 'automatorwp-pro' ),
                    'name'              => __( 'List:', 'automatorwp-pro' ),
                    'option_none'       => false,
                    'action_cb'         => 'automatorwp_mail_mint_get_lists',
                    'options_cb'        => 'automatorwp_mail_mint_options_cb_list',
                    'placeholder'       => __( 'Select a list', 'automatorwp-pro' ),
                    'default'           => ''
                ) ),
                'contact' => array(
                    'from' => 'email',
                    'default' => __( 'contact', 'automatorwp-pro' ),
                    'fields' => array(
                        'email' => array(
                            'name' => __( 'Contact Email:', 'automatorwp-pro' ),
                            'desc' => __( 'The contact email address.', 'automatorwp-pro' ),
                            'type' => 'text',
                            'required'  => true,
                            'default' => ''
                        ),
                     ) )
            ),
        ) );
    }

    /**
     * Action execution function
     *
     * @since 1.0.0
     *
     * @param stdClass $action         The action object
     * @param int      $user_id        The user ID
     * @param array    $action_options The action's stored options (with tags already parsed)
     * @param stdClass $automation     The action's automation object
     */
    public function execute( $action, $user_id, $action_options, $automation ) {

        // Shorthand
        $list = $action_options['list'];
        $email_contact = $action_options['email'];

        // Bail if no list selected
        if ( empty( $list ) ) {
            $this->result = __( 'Select a list to remove the user.', 'automatorwp-pro' );
            return;
        }

        if( ! class_exists ( 'Mint\MRM\DataBase\Models\ContactModel' ) || 
            ! class_exists ( 'Mint\MRM\DataBase\Models\ContactGroupPivotModel' ) )
            return;

        // Get contact ID
        $contact_id = Mint\MRM\DataBase\Models\ContactModel::get_id_by_email( $email_contact );

        // Bail if not contact ID
        if ( ! $contact_id ){
            $this->result = __( 'Email is not a contact in Mail Mint.', 'automatorwp-pro' );
            return;
        }

        $response = Mint\MRM\DataBase\Models\ContactGroupPivotModel::delete_groups_to_contact( $contact_id, array( $list ));

        if ( $response ) {
            $this->result = sprintf( __( '%1$s removed from list.', 'automatorwp-pro' ), $email_contact );
        } else {
            $this->result = sprintf( __( '%1$s could not be removed because is not on the list.', 'automatorwp-pro' ), $email_contact );
        }

        
    }

    /**
     * Register required hooks
     *
     * @since 1.0.0
     */
    public function hooks() {

        // Log meta data
        add_filter( 'automatorwp_user_completed_action_log_meta', array( $this, 'log_meta' ), 10, 5 );

        // Log fields
        add_filter( 'automatorwp_log_fields', array( $this, 'log_fields' ), 10, 5 );

        parent::hooks();

    }

    /**
     * Action custom log meta
     *
     * @since 1.0.0
     *
     * @param array     $log_meta           Log meta data
     * @param stdClass  $action             The action object
     * @param int       $user_id            The user ID
     * @param array     $action_options     The action's stored options (with tags already passed)
     * @param stdClass  $automation         The action's automation object
     *
     * @return array
     */
    public function log_meta( $log_meta, $action, $user_id, $action_options, $automation ) {

        // Bail if action type don't match this action
        if( $action->type !== $this->action ) {
            return $log_meta;
        }

        // Store the action's result
        $log_meta['result'] = $this->result;

        return $log_meta;
    }

    /**
     * Action custom log fields
     *
     * @since 1.0.0
     *
     * @param array     $log_fields The log fields
     * @param stdClass  $log        The log object
     * @param stdClass  $object     The trigger/action/automation object attached to the log
     *
     * @return array
     */
    public function log_fields( $log_fields, $log, $object ) {

        // Bail if log is not assigned to an action
        if( $log->type !== 'action' ) {
            return $log_fields;
        }

        // Bail if action type don't match this action
        if( $object->type !== $this->action ) {
            return $log_fields;
        }

        $log_fields['result'] = array(
            'name' => __( 'Result:', 'automatorwp-pro' ),
            'type' => 'text',
        );

        return $log_fields;
    }
}

new AutomatorWP_Mail_Mint_Contact_Remove_List();
