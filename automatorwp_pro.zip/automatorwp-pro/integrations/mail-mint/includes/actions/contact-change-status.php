<?php
/**
 * Change Contact Status
 *
 * @package     AutomatorWP\Integrations\Mail_Mint\Actions\Change_Contact_Status
 * @author      AutomatorWP <contact@automatorwp.com>
 * @since       1.0.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

class AutomatorWP_Mail_Mint_Change_Contact_Status extends AutomatorWP_Integration_Action
{
    public $integration = 'mail_mint';
    public $action      = 'mail_mint_change_contact_status';
    public $result      = '';

    /**
     * Register the action
     *
     * @since 1.0.0
     */
    public function register()
    {
        automatorwp_register_action( $this->action, array(
            'integration'   => $this->integration,
            'label'         => __( 'Set contact\'s status to a status', 'automatorwp-pro' ),
            'select_option' => __( 'Set contact\'s <strong>status</strong> to a status', 'automatorwp-pro' ),
            /* translators: %1$s: Status. */
            'edit_label'    => sprintf( __( 'Set contact\'s status to %1$s', 'automatorwp-pro' ), '{status}' ),
            /* translators: %1$s: Status. */
            'log_label'     => sprintf( __( 'Set contact\'s status to %1$s', 'automatorwp-pro' ), '{status}' ),
            'options'       => array(
                'status' => array(
                    'from'    => 'mm_status',
                    'default' => __( 'status', 'automatorwp-pro' ),
                    'fields'  => array(
                        'email' => array(
                            'name'    => __( 'Email:', 'automatorwp-pro' ),
                            'desc'    => __( 'The contact email address.', 'automatorwp-pro' ),
                            'type'    => 'text',
                            'required' => true,
                            'default' => '',
                        ),
                        'mm_status' => array(
                            'name'    => __( 'Status:', 'automatorwp-pro' ),
                            'type'    => 'select',
                            'options' => array(
                                'subscribed'   => __( 'Subscribed',   'automatorwp-pro' ),
                                'unsubscribed' => __( 'Unsubscribed', 'automatorwp-pro' ),
                                'pending'      => __( 'Pending',      'automatorwp-pro' ),
                                'complained'   => __( 'Complained',   'automatorwp-pro' ),
                                'bounced'      => __( 'Bounced',      'automatorwp-pro' ),
                                'inactive'     => __( 'Inactive',     'automatorwp-pro' ),
                            ),
                            'default' => 'pending',
                        ),
                    ),
                ),
            ),
        ) );
    }

    /**
     * Action execution function
     *
     * @since 1.0.0
     *
     * @param stdClass $action         The action object
     * @param int      $user_id        The user ID
     * @param array    $action_options The action's stored options (with tags already parsed)
     * @param stdClass $automation     The action's automation object
     */
    public function execute( $action, $user_id, $action_options, $automation ) {
        
        // Shorthand
        $contact_email = $action_options['email'];
        $status = $action_options['mm_status'];

        // Bail if not contact email
        if ( empty( $contact_email ) ){
            $this->result = __( 'Contact email field cannot be empty.', 'automatorwp-pro' );
            return;
        }
       
        if( ! class_exists ( 'Mint\MRM\DataBase\Models\ContactModel' ) ||
            ! class_exists ( 'Mint\MRM\DataStores\ContactData' ) )
            return;

        // Get contact ID
        $contact_id = Mint\MRM\DataBase\Models\ContactModel::get_id_by_email( $contact_email );

        // Bail if contact ID
        if ( ! $contact_id ){
            $this->result = __( 'Contact is not added in Mail Mint.', 'automatorwp-pro' );
            return;
        }

        
        // Update status
		Mint\MRM\DataBase\Models\ContactModel::update_subscription_status( $contact_id, $status );
		
        $this->result = __( 'Contact status updated', 'automatorwp-pro' );
        
    }

    /**
     * Register required hooks
     *
     * @since 1.0.0
     */
    public function hooks() {

        // Log meta data
        add_filter( 'automatorwp_user_completed_action_log_meta', array( $this, 'log_meta' ), 10, 5 );

        // Log fields
        add_filter( 'automatorwp_log_fields', array( $this, 'log_fields' ), 10, 5 );

        parent::hooks();

    }

    /**
     * Action custom log meta
     *
     * @since 1.0.0
     *
     * @param array     $log_meta           Log meta data
     * @param stdClass  $action             The action object
     * @param int       $user_id            The user ID
     * @param array     $action_options     The action's stored options (with tags already passed)
     * @param stdClass  $automation         The action's automation object
     *
     * @return array
     */
    public function log_meta( $log_meta, $action, $user_id, $action_options, $automation ) {

        // Bail if action type don't match this action
        if( $action->type !== $this->action ) {
            return $log_meta;
        }

        // Store the action's result
        $log_meta['result'] = $this->result;

        return $log_meta;
    }

    /**
     * Action custom log fields
     *
     * @since 1.0.0
     *
     * @param array     $log_fields The log fields
     * @param stdClass  $log        The log object
     * @param stdClass  $object     The trigger/action/automation object attached to the log
     *
     * @return array
     */
    public function log_fields( $log_fields, $log, $object ) {

        // Bail if log is not assigned to an action
        if( $log->type !== 'action' ) {
            return $log_fields;
        }

        // Bail if action type don't match this action
        if( $object->type !== $this->action ) {
            return $log_fields;
        }

        $log_fields['result'] = array(
            'name' => __( 'Result:', 'automatorwp-pro' ),
            'type' => 'text',
        );

        return $log_fields;
    }
}

new AutomatorWP_Mail_Mint_Change_Contact_Status();
