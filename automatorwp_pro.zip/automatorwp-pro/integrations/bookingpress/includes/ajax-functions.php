<?php
/**
 * Ajax Functions
 *
 * @package     AutomatorWP\Integrations\BookingPress\Ajax_Functions
 * @author      AutomatorWP <contact@automatorwp.com>, Ruben Garcia <rubengcdev@gmail.com>
 * @since       1.0.0
 */
// Exit if accessed directly
if( !defined( 'ABSPATH' ) ) exit;

/**
 * Ajax function for selecting services
 *
 * @since 1.0.0
 */
function automatorwp_bookingpress_ajax_get_services() {
    // Security check, forces to die if not security passed
    check_ajax_referer( 'automatorwp_admin', 'nonce' );
    
    global $wpdb;

    // Pull back the search string
    $search = isset( $_REQUEST['q'] ) ? $wpdb->esc_like( $_REQUEST['q'] ) : '';

    $services = automatorwp_bookingpress_get_services();

    $results = array();

    // Parse service results to match select2 results
    foreach ( $services as $service ) {

        if( ! empty( $search ) ) {
            if( strpos( strtolower( $service['name'] ), strtolower( $search ) ) === false ) {
                continue;
            }
        }
        
        $results[] = array(
            'id' => $service['id'],
            'text' => $service['name']
        );
    }

    // Prepend option none
    $results = automatorwp_ajax_parse_extra_options( $results );

    // Return our results
    wp_send_json_success( $results );
    die;

}
add_action( 'wp_ajax_automatorwp_bookingpress_get_services', 'automatorwp_bookingpress_ajax_get_services' );