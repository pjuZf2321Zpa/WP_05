<?php
/**
 * Functions
 *
 * @package     AutomatorWP\Integrations\BookingPress\Functions
 * @author      AutomatorWP <contact@automatorwp.com>, Ruben Garcia <rubengcdev@gmail.com>
 * @since       1.0.0
 */
// Exit if accessed directly
if( !defined( 'ABSPATH' ) ) exit;

/**
 * Get the related WordPress user ID from a BookingPress customer ID.
 *
 * @since 1.0.0
 *
 * @param int $customer_id BookingPress customer ID.
 *
 * @return int WordPress user ID or 0 when there is no linked account.
 */
function automatorwp_bookingpress_get_wp_user_id_from_customer_id( $customer_id ) {

    global $wpdb;

    $customer_id = absint( $customer_id );

    if( empty( $customer_id ) ) {
        return 0;
    }

    $customer_table = $wpdb->prefix . 'bookingpress_customers';
    $wp_user_id = $wpdb->get_var(
        $wpdb->prepare(
            "SELECT bookingpress_wpuser_id FROM {$customer_table} WHERE bookingpress_customer_id = %d",
            $customer_id
        )
    );

    return absint( $wp_user_id );

}

/**
 * Get services from BookingPress
 *
 * @since 1.0.0
 * 
 * @param stdClass $field
 *
 * @return array
 */
function automatorwp_bookingpress_options_cb_service( $field ) {

    // Setup vars
    $value = $field->escaped_value;
    $none_value = 'any';
    $none_label = __( 'any service', 'automatorwp-pro' );
    $options = automatorwp_options_cb_none_option( $field, $none_value, $none_label );
    
    if( ! empty( $value ) ) {
        if( ! is_array( $value ) ) {
            $value = array( $value );
        }

        foreach( $value as $service_id ) {

            // Skip option none
            if( $service_id === $none_value ) {
                continue;
            }
            
            $options[$service_id] = automatorwp_bookingpress_get_service_name( $service_id );
        }
    }

    return $options;

}

/**
 * Get BookingPress services
 *
 * @since 1.0.0
 *
 * @return array|false
 */
function automatorwp_bookingpress_get_services() {

    global $wpdb;
    $services = array();

    $results = $wpdb->get_results( "SELECT bookingpress_service_id, bookingpress_service_name FROM {$wpdb->prefix}bookingpress_services" );

    foreach ( $results as $service ){   

        $services[] = array(
            'id'    => $service->bookingpress_service_id,
            'name'  => $service->bookingpress_service_name,
        );         

    }

    return $services;

}

/**
 * Get BookingPress service name
 *
 * @since 1.0.0
 *
 * @param int    $service_id         ID service
 * 
 */
function automatorwp_bookingpress_get_service_name( $service_id ) {

    global $wpdb;

    // Empty if no ID provided
    if( absint( $service_id ) === 0 ) {
        return '';
    }

    $service_name = $wpdb->get_var( "SELECT bookingpress_service_name FROM {$wpdb->prefix}bookingpress_services WHERE bookingpress_service_id = {$service_id}" );
    
    return $service_name;

}

/**
 * Get Service by appointment ID
 *
 * @since 1.0.0
 *
 * @param int    $appointment_id         ID appointment
 * 
 */
function automatorwp_bookingpress_get_service_by_appointment_id( $appointment_id ) {

    global $wpdb;

    // Empty if no ID provided
    if( absint( $appointment_id ) === 0 ) {
        return '';
    }

    $service_id = $wpdb->get_var( "SELECT bookingpress_service_id FROM {$wpdb->prefix}bookingpress_appointment_bookings WHERE bookingpress_appointment_booking_id = {$appointment_id}" );
    
    return $service_id;

}

/**
 * Get Customer by appointment ID
 *
 * @since 1.0.0
 *
 * @param int    $appointment_id         ID appointment
 * 
 */
function automatorwp_bookingpress_get_customer_by_appointment_id( $appointment_id ) {

    global $wpdb;

    // Empty if no ID provided
    if( absint( $appointment_id ) === 0 ) {
        return '';
    }

    $customer_id = $wpdb->get_var( "SELECT bookingpress_customer_id FROM {$wpdb->prefix}bookingpress_appointment_bookings WHERE bookingpress_appointment_booking_id = {$appointment_id}" );
    
    return $customer_id;

}

/**
 * Get BookingPress customer data
 *
 * @since 1.0.0
 *
 * @return array|false
 */
function automatorwp_bookingpress_get_customer_data( $customer_id ) {

    global $wpdb;

    // Empty if no ID provided
    if( absint( $customer_id ) === 0 ) {
        return '';
    }
    
    $customer = $wpdb->get_row( "SELECT * FROM {$wpdb->prefix}bookingpress_customers WHERE bookingpress_customer_id = {$customer_id}" );

    return $customer;

}