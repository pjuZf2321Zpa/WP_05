<?php
/**
 * Set Status Appointment
 *
 * @package     AutomatorWP\Integrations\BookingPress\Actions\Set_Status_Appointment
 * @author      AutomatorWP <contact@automatorwp.com>, Ruben Garcia <rubengcdev@gmail.com>
 * @since       1.0.0
 */
// Exit if accessed directly
if( !defined( 'ABSPATH' ) ) exit;

class AutomatorWP_BookingPress_Set_Status_Appointment extends AutomatorWP_Integration_Action {

    public $integration = 'bookingpress';
    public $action = 'bookingpress_set_status_appointment';

    /**
     * Register the action
     *
     * @since 1.0.0
     */
    public function register() {

        automatorwp_register_action( $this->action, array(
            'integration'   => $this->integration,
            'label'         => __( 'Set status to an appointment', 'automatorwp-pro' ),
            'select_option' => __( 'Set <strong>status</strong> to an appointment', 'automatorwp-pro' ),
            /* translators: %1$s: Status. %2$s: Appointment */
            'edit_label'        => sprintf( __( 'Set %1$s status to %2$s', 'automatorwp-pro' ), '{status}', '{appointment}' ),
            /* translators: %1$s: Status. %2$s: Appointment */
            'log_label'         => sprintf( __( 'Set %1$s status to %2$s', 'automatorwp-pro' ), '{status}', '{appointment}' ),
            'options'       => array(
                'appointment' => array(
                    'from'    => 'appointment',
                    'default' => __( 'appointment', 'automatorwp-pro' ),
                    'fields'  => array(
                        'appointment' => array(
                            'name'    => __( 'Appointment ID:', 'automatorwp-pro' ),
                            'type'    => 'text',
                            'default' => ''
                        ),
                    ),
                ),
                'status' => array(
                    'from'    => 'status',
                    'default' => __( 'status', 'automatorwp-pro' ),
                    'fields'  => array(
                        'status' => array(
                            'name'    => __( 'Status:', 'automatorwp-pro' ),
                            'type'    => 'select',
                            'options' => array(
                                '1' => __( 'Approved', 'automatorwp-pro' ),
                                '2' => __( 'Pending', 'automatorwp-pro' ),
                                '3' => __( 'Cancelled', 'automatorwp-pro' ),
                                '4' => __( 'Rejected', 'automatorwp-pro' ),
                            ),
                            'default' => '2'
                        ),
                    ),
                ),
            ),
        ) );

    }

    /**
     * Action execution function
     *
     * @since 1.0.0
     *
     * @param stdClass  $action
     * @param int       $user_id
     * @param array     $action_options
     * @param stdClass  $automation
     */
    public function execute( $action, $user_id, $action_options, $automation ) {

        global $wpdb;

        $appointment_id = $action_options['appointment'];
        $status = $action_options['status'];

        $this->result = '';

        if( empty( $appointment_id ) ) {
            $this->result = __('Appointment ID cannot be empty', 'automatorwp-pro' );
            return;
        }

        $table_name = $wpdb->prefix . 'bookingpress_appointment_bookings';

        $updated = $wpdb->update(
            $table_name,
            array( 'bookingpress_appointment_status' => $status ),
            array( 'bookingpress_appointment_booking_id' => $appointment_id )
        );

        if( $updated !== false ) {
            $this->result = __( 'Appointment updated successfully.', 'automatorwp-pro' );
        } else {
            $this->result = __( 'The appointment could not be updated.', 'automatorwp-pro' );
        }

    }

    /**
     * Register required hooks
     *
     * @since 1.0.0
     */
    public function hooks() {

        add_filter( 'automatorwp_user_completed_action_log_meta', array( $this, 'log_meta' ), 10, 5 );
        add_filter( 'automatorwp_log_fields', array( $this, 'log_fields' ), 10, 5 );

        parent::hooks();

    }

    /**
     * Action custom log meta
     *
     * @since 1.0.0
     *
     * @param array     $log_meta
     * @param stdClass  $action
     * @param int       $user_id
     * @param array     $action_options
     * @param stdClass  $automation
     *
     * @return array
     */
    public function log_meta( $log_meta, $action, $user_id, $action_options, $automation ) {

        if( $action->type !== $this->action ) {
            return $log_meta;
        }

        $log_meta['result'] = $this->result;

        return $log_meta;

    }

    /**
     * Action custom log fields
     *
     * @since 1.0.0
     *
     * @param array     $log_fields
     * @param stdClass  $log
     * @param stdClass  $object
     *
     * @return array
     */
    public function log_fields( $log_fields, $log, $object ) {

        if( $log->type !== 'action' ) {
            return $log_fields;
        }

        if( $object->type !== $this->action ) {
            return $log_fields;
        }

        $log_fields['result'] = array(
            'name' => __( 'Result:', 'automatorwp-pro' ),
            'type' => 'text',
        );

        return $log_fields;

    }

}

new AutomatorWP_BookingPress_Set_Status_Appointment();