<?php

/**
 * Anonymous New Appointment
 *
 * @package     AutomatorWP\Integrations\BookingPress\Triggers\Anonymous_New_Appointment
 * @since       1.0.0
 */

// Exit if accessed directly
if (!defined('ABSPATH')) exit;

class AutomatorWP_BookingPress_Anonymous_New_Appointment extends AutomatorWP_Integration_Trigger
{

    public $integration = 'bookingpress';
    public $trigger = 'bookingpress_anonymous_new_appointment';

    /**
     * Register the trigger
     *
     * @since 1.0.0
     */
    public function register() {

        automatorwp_register_trigger($this->trigger, array(
            'integration'   => $this->integration,
            'anonymous'     => true,
            'label'         => __( 'Guest books an appointment for a service', 'automatorwp-pro' ),
            'select_option' => __( 'Guest <strong>books</strong> an appointment for a service', 'automatorwp-pro' ),
            /* translators: %1$s: Service title. %2$s: Number of times. */
            'edit_label'    => sprintf( __( 'Guest books an appointment for %1$s %2$s time(s)', 'automatorwp-pro' ), '{service}', '{times}'),
            /* translators: %1$s: Service title. */
            'log_label'     => sprintf( __( 'Guest books an appointment for %1$s', 'automatorwp-pro' ), '{service}' ),
            'action'        => 'bookingpress_after_insert_appointment',
            'function'      => array($this, 'listener'),
            'priority'      => 10,
            'accepted_args' => 1,
            'options'           => array(
                'service' => automatorwp_utilities_ajax_selector_option( array(
                    'field'             => 'service',
                    'name'              => __( 'Service:', 'automatorwp-pro' ),
                    'option_none_value' => 'any',
                    'option_none_label' => __( 'any service', 'automatorwp-pro' ),
                    'action_cb'         => 'automatorwp_bookingpress_get_services',
                    'options_cb'        => 'automatorwp_bookingpress_options_cb_service',
                    'default'           => 'any'
                ) ),
                'times' => automatorwp_utilities_times_option(),
            ),
            'tags' => array_merge(
                automatorwp_bookingpress_get_customer_tags(),
                automatorwp_utilities_times_tag()
            )
        ));
    }

    /**
     * Trigger listener
     *
     * @since 1.0.0
     *
     * @param int $appointment_id
     */
    public function listener( $appointment_id ) {

        $customer_id = automatorwp_bookingpress_get_customer_by_appointment_id( $appointment_id );
        $service_id = automatorwp_bookingpress_get_service_by_appointment_id( $appointment_id );

        $user_id = get_current_user_id( );

        // Bail if user is logged
        if ($user_id !== 0){
            return;
        }

        automatorwp_trigger_event(array(
            'trigger'           => $this->trigger,
            'appointment_id'    => $appointment_id,
            'service_id'        => $service_id,
            'customer_id'       => $customer_id,
        ));
    }

    /**
     * User deserves check
     *
     * @since 1.0.0
     *
     * @param bool      $deserves_trigger   True if user deserves trigger, false otherwise
     * @param stdClass  $trigger            The trigger object
     * @param array     $event              Event information
     * @param array     $trigger_options    The trigger's stored options
     * @param stdClass  $automation         The trigger's automation object
     *
     * @return bool                          True if user deserves trigger, false otherwise
     */


     public function anonymous_deserves_trigger( $deserves_trigger, $trigger, $event, $trigger_options, $automation ) {

        // Don't deserve if post is not received
        if( ! isset( $event['service_id'] ) ) {
            return false;
        }

        // Don't deserve if post doesn't match with the trigger option
        if( $trigger_options['service'] !== 'any' &&  absint( $trigger_options['service'] ) !== absint( $event['service_id'] ) ) {
            return false;
        }

        return $deserves_trigger;

    }

    /**
     * Register the required hooks
     *
     * @since 1.0.0
     */
    public function hooks() {

        // Log meta data
        add_filter( 'automatorwp_anonymous_completed_trigger_log_meta', array( $this, 'log_meta' ), 10, 5 );

        parent::hooks();
    }

    /**
     * Trigger custom log meta
     *
     * @since 1.0.0
     *
     * @param array     $log_meta           Log meta data
     * @param stdClass  $trigger            The trigger object
     * @param array     $event              Event information
     * @param array     $trigger_options    The trigger's stored options
     * @param stdClass  $automation         The trigger's automation object
     *
     * @return array
     */
    function log_meta( $log_meta, $trigger, $event, $trigger_options, $automation ) {

        // Bail if action type don't match this action
        if( $trigger->type !== $this->trigger ) {
            return $log_meta;
        }

        $log_meta['service_id'] = ( isset( $event['service_id'] ) ? $event['service_id'] : '' );
        $log_meta['customer_id'] = ( isset( $event['customer_id'] ) ? $event['customer_id'] : '' );

        return $log_meta;

    }
}

new AutomatorWP_BookingPress_Anonymous_New_Appointment();
