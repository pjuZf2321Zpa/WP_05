<?php

/**
 * Appointment Approved
 *
 * @package     AutomatorWP\Integrations\BookingPress\Triggers\Appointment_Approved
 * @since       1.0.0
 */

// Exit if accessed directly
if (!defined('ABSPATH')) exit;

class AutomatorWP_BookingPress_Appointment_Approved extends AutomatorWP_Integration_Trigger
{

    public $integration = 'bookingpress';
    public $trigger = 'bookingpress_appointment_approved';

    /**
     * Register the trigger
     *
     * @since 1.0.0
     */
    public function register() {

        automatorwp_register_trigger($this->trigger, array(
            'integration'   => $this->integration,
            'label'         => __( 'User appointment is approved for a service', 'automatorwp-pro' ),
            'select_option' => __( 'User appointment is <strong>approved</strong> for a service', 'automatorwp-pro' ),
            /* translators: %1$s: Service title. %2$s: Number of times. */
            'edit_label'    => sprintf( __( 'User appointment is approved for %1$s %2$s time(s)', 'automatorwp-pro' ), '{service}', '{times}'),
            /* translators: %1$s: Service title. */
            'log_label'     => sprintf( __( 'User appointment is approved for %1$s', 'automatorwp-pro' ), '{service}' ),
            'action'        => 'bookingpress_after_change_appointment_status',
            'function'      => array($this, 'listener'),
            'priority'      => 10,
            'accepted_args' => 2,
            'options'           => array(
                'service' => automatorwp_utilities_ajax_selector_option( array(
                    'field'             => 'service',
                    'name'              => __( 'Service:', 'automatorwp-pro' ),
                    'option_none_value' => 'any',
                    'option_none_label' => __( 'any service', 'automatorwp-pro' ),
                    'action_cb'         => 'automatorwp_bookingpress_get_services',
                    'options_cb'        => 'automatorwp_bookingpress_options_cb_service',
                    'default'           => 'any'
                ) ),
                'times' => automatorwp_utilities_times_option(),
            ),
            'tags' => array_merge(
                automatorwp_bookingpress_get_customer_tags(),
                automatorwp_utilities_times_tag()
            )
        ));
    }

    /**
     * Trigger listener
     *
     * @since 1.0.0
     *
     * @param int $appointment_id
     * @param string $appointment_status
     */
    public function listener( $appointment_id, $appointment_status ) {

        // BookingPress status 1 means approved
        if ( $appointment_status !== '1' ) {
            return;
        }

        $customer_id = automatorwp_bookingpress_get_customer_by_appointment_id( $appointment_id );
        $user_id = automatorwp_bookingpress_get_wp_user_id_from_customer_id( $customer_id );

        // Bail if not user ID
        if ( empty( $user_id ) ) {
            return;
        }

        $service_id = automatorwp_bookingpress_get_service_by_appointment_id( $appointment_id );

        automatorwp_trigger_event(array(
            'trigger'           => $this->trigger,
            'user_id'           => $user_id,
            'appointment_id'    => $appointment_id,
            'service_id'        => $service_id,
            'customer_id'       => $customer_id,
        ));
    }

    /**
     * User deserves check
     *
     * @since 1.0.0
     *
     * @param bool      $deserves_trigger   True if user deserves trigger, false otherwise
     * @param stdClass  $trigger            The trigger object
     * @param int       $user_id            The user ID
     * @param array     $event              Event information
     * @param array     $trigger_options    The trigger's stored options
     * @param stdClass  $automation         The trigger's automation object
     *
     * @return bool                          True if user deserves trigger, false otherwise
     */


     public function user_deserves_trigger( $deserves_trigger, $trigger, $user_id, $event, $trigger_options, $automation ) {

        // Don't deserve if post is not received
        if( ! isset( $event['service_id'] ) ) {
            return false;
        }

        // Don't deserve if post doesn't match with the trigger option
        if( $trigger_options['service'] !== 'any' &&  absint( $trigger_options['service'] ) !== absint( $event['service_id'] ) ) {
            return false;
        }

        return $deserves_trigger;

    }

    /**
     * Register the required hooks
     *
     * @since 1.0.0
     */
    public function hooks() {

        // Log meta data
        add_filter( 'automatorwp_user_completed_trigger_log_meta', array( $this, 'log_meta' ), 10, 6 );

        parent::hooks();
    }

    /**
     * Trigger custom log meta
     *
     * @since 1.0.0
     *
     * @param array     $log_meta           Log meta data
     * @param stdClass  $trigger            The trigger object
     * @param int       $user_id            The user ID
     * @param array     $event              Event information
     * @param array     $trigger_options    The trigger's stored options
     * @param stdClass  $automation         The trigger's automation object
     *
     * @return array
     */
    function log_meta( $log_meta, $trigger, $user_id, $event, $trigger_options, $automation ) {

        // Bail if action type don't match this action
        if( $trigger->type !== $this->trigger ) {
            return $log_meta;
        }

        $log_meta['service_id'] = ( isset( $event['service_id'] ) ? $event['service_id'] : '' );
        $log_meta['customer_id'] = ( isset( $event['customer_id'] ) ? $event['customer_id'] : '' );

        return $log_meta;

    }
}

new AutomatorWP_BookingPress_Appointment_Approved();
