<?php
/**
 * Plugin Name:           AutomatorWP - BookingPress
 * Plugin URI:            https://automatorwp.com/add-ons/bookingpress/
 * Description:           Connect AutomatorWP with BookingPress.
 * Version:               1.0.0
 * Author:                AutomatorWP
 * Author URI:            https://automatorwp.com/
 * Text Domain:           automatorwp-bookingpress
 * Domain Path:           /languages/
 * Requires at least:     4.4
 * Tested up to:          7.0
 * License:               GNU AGPL v3.0 (http://www.gnu.org/licenses/agpl.txt)
 *
 * @package               AutomatorWP\BookingPress
 * @author                AutomatorWP
 * @copyright             Copyright (c) AutomatorWP
 */

final class AutomatorWP_BookingPress {

    /**
     * @var         AutomatorWP_BookingPress $instance The one true AutomatorWP_BookingPress
     * @since       1.0.0
     */
    private static $instance;

    /**
     * Get active instance
     *
     * @access      public
     * @since       1.0.0
     * @return      AutomatorWP_BookingPress self::$instance The one true AutomatorWP_BookingPress
     */
    public static function instance() {
        if( !self::$instance ) {
            self::$instance = new AutomatorWP_BookingPress();
            self::$instance->constants();
            self::$instance->includes();
            self::$instance->hooks();        }

        return self::$instance;
    }

    /**
     * Setup plugin constants
     *
     * @access      private
     * @since       1.0.0
     * @return      void
     */
    private function constants() {

        define( 'AUTOMATORWP_BOOKINGPRESS_VER', '1.0.0' );
        define( 'AUTOMATORWP_BOOKINGPRESS_FILE', __FILE__ );
        define( 'AUTOMATORWP_BOOKINGPRESS_DIR', plugin_dir_path( __FILE__ ) );
        define( 'AUTOMATORWP_BOOKINGPRESS_URL', plugin_dir_url( __FILE__ ) );

    }

    /**
     * Include plugin files
     *
     * @access      private
     * @since       1.0.0
     * @return      void
     */
    private function includes() {

        if( $this->meets_requirements() ) {

            require_once AUTOMATORWP_BOOKINGPRESS_DIR . 'includes/functions.php';
            require_once AUTOMATORWP_BOOKINGPRESS_DIR . 'includes/ajax-functions.php';
            require_once AUTOMATORWP_BOOKINGPRESS_DIR . 'includes/tags.php';
            

            // Triggers
            require_once AUTOMATORWP_BOOKINGPRESS_DIR . 'includes/triggers/new-appointment.php';
            require_once AUTOMATORWP_BOOKINGPRESS_DIR . 'includes/triggers/appointment-approved.php';
            require_once AUTOMATORWP_BOOKINGPRESS_DIR . 'includes/triggers/appointment-pending.php';
            require_once AUTOMATORWP_BOOKINGPRESS_DIR . 'includes/triggers/appointment-canceled.php';
            require_once AUTOMATORWP_BOOKINGPRESS_DIR . 'includes/triggers/appointment-rejected.php';
            require_once AUTOMATORWP_BOOKINGPRESS_DIR . 'includes/triggers/new-customer.php';
            require_once AUTOMATORWP_BOOKINGPRESS_DIR . 'includes/triggers/anonymous-new-customer.php';
            require_once AUTOMATORWP_BOOKINGPRESS_DIR . 'includes/triggers/anonymous-new-appointment.php';

            //Actions
            require_once AUTOMATORWP_BOOKINGPRESS_DIR . 'includes/actions/set-status-appointment.php';

        }

    }

    /**
     * Setup plugin hooks
     *
     * @access      private
     * @since       1.0.0
     * @return      void
     */
    private function hooks() {

        add_action( 'automatorwp_init', array( $this, 'register_integration' ) );        
        

    }

    /**
     * Registers this integration
     *
     * @since 1.0.0
     */
    function register_integration() {

        automatorwp_register_integration( 'bookingpress', array(
            'label' => 'BookingPress',
            'icon'  => AUTOMATORWP_BOOKINGPRESS_URL . 'assets/bookingpress.svg',
        ) );

    }

    /**
     * Check if there are all plugin requirements
     *
     * @since  1.0.0
     *
     * @return bool True if installation meets all requirements
     */
    private function meets_requirements() {

        if ( ! class_exists( 'AutomatorWP' ) ) {
            return false;
        }

        if ( ! class_exists( 'BookingPress' ) ) {
            return false;
        }

        return true;

    }

}

/**
 * The main function responsible for returning the one true AutomatorWP_BookingPress instance
 *
 * @since       1.0.0
 * @return      \AutomatorWP_BookingPress The one true AutomatorWP_BookingPress
 */
function AutomatorWP_BookingPress() {
    return AutomatorWP_BookingPress::instance();
}
add_action( 'plugins_loaded', 'AutomatorWP_BookingPress' );
