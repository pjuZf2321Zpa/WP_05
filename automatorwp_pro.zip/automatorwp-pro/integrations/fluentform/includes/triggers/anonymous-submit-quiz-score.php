<?php
/**
 * Anonymous Submit Quiz Score
 *
 * @package     AutomatorWP\Integrations\FluentForm\Triggers\Anonymous_Submit_Quiz_Score
 * @author      AutomatorWP <contact@automatorwp.com>, Ruben Garcia <rubengcdev@gmail.com>
 * @since       1.0.0
 */
// Exit if accessed directly
if( !defined( 'ABSPATH' ) ) exit;

class AutomatorWP_FluentForm_Anonymous_Submit_Quiz_Score extends AutomatorWP_Integration_Trigger {

    public $integration = 'fluentform';
    public $trigger = 'fluentform_anonymous_submit_quiz_score';

    /**
     * Register the trigger
     *
     * @since 1.0.0
     */
    public function register() {

        automatorwp_register_trigger( $this->trigger, array(
            'integration'       => $this->integration,
            'anonymous'         => true,
            'label'             => __( 'Guest completes a quiz with a grade score greater than, less than or equal to a specific score', 'automatorwp-pro' ),
            'select_option'     => __( 'Guest completes a quiz with a grade score <strong>greater than, less than or equal</strong> to a specific score', 'automatorwp-pro' ),
            /* translators: %1$s: Post title. %2$s: Condition. %3$s: Score. %4$s: Number of times. */
            'edit_label'        => sprintf( __( 'Guest completes %1$s with a grade score %2$s %3$s %4$s time(s)', 'automatorwp-learndash' ), '{post}', '{condition}', '{score}', '{times}' ),
            /* translators: %1$s: Post title. %2$s: Condition. %3$s: Score. */
            'log_label'         => sprintf( __( 'Guest completes %1$s with a grade score %2$s %3$s', 'automatorwp-learndash' ), '{post}', '{condition}', '{score}' ),
            'action'            => 'fluentform/before_submission_confirmation',
            'function'          => array( $this, 'listener' ),
            'priority'          => 10,
            'accepted_args'     => 3,
            'options'           => array(
                'post' => automatorwp_utilities_ajax_selector_option( array(
                    'field'             => 'post',
                    'name'              => __( 'Quiz:', 'automatorwp-pro' ),
                    'option_none_value' => 'any',
                    'option_none_label' => __( 'any quiz', 'automatorwp-pro' ),
                    'action_cb'         => 'automatorwp_fluentform_get_quizzes',
                    'options_cb'        => 'automatorwp_fluentform_options_cb_quiz',
                    'default'           => 'any'
                ) ),
                'condition' => automatorwp_utilities_condition_option(),
                'score' => array(
                    'from' => 'score',
                    'fields' => array(
                        'score' => array(
                            'name' => __( 'Score:', 'automatorwp-learndash' ),
                            'desc' => __( 'The grade score required.', 'automatorwp-learndash' ),
                            'type' => 'text',
                            'attributes' => array(
                                'type' => 'number',
                                'min' => '0',
                            ),
                            'default' => 0
                        )
                    )
                ),
                'times' => automatorwp_utilities_times_option(),
            ),
            'tags' => array_merge(
                array(
                    'form_field:FIELD_NAME' => array(
                        'label'     => __( 'Form field value', 'automatorwp-pro' ),
                        'type'      => 'text',
                        'preview'   => __( 'Form field value, replace "FIELD_NAME" by the field name', 'automatorwp-pro' ),
                    ),
                ),
                automatorwp_utilities_times_tag()
            )
        ) );

    }

    /**
     * Trigger listener
     *
     * @since 1.0.0
     *
     * @param int $submission_id
     * @param array $form_data
     * @param \FluentForm\App\Modules\Form\Form $form
     */
    public function listener( $submission_id, $form_data, $form ) {
    
        $form_id = $form->id;
        $user_id = get_current_user_id();

        // Login is not required
        if ( $user_id !== 0 ) {
            return;
        }

        $score = AutomatorWP_FluentForm_Quiz_Score::$score;
        
        $form_fields = automatorwp_fluentform_get_form_fields_values( $form_data );

        // Trigger submit form event
        automatorwp_trigger_event( array(
            'trigger'       => $this->trigger,
            'form_id'       => $form_id,
            'form_fields'   => $form_fields,
            'score'         => $score,
        ) );

    }

    /**
     * Anonymous deserves check
     *
     * @since 1.0.0
     *
     * @param bool      $deserves_trigger   True if anonymous deserves trigger, false otherwise
     * @param stdClass  $trigger            The trigger object
     * @param array     $event              Event information
     * @param array     $trigger_options    The trigger's stored options
     * @param stdClass  $automation         The trigger's automation object
     *
     * @return bool                         True if anonymous deserves trigger, false otherwise
     */
    public function anonymous_deserves_trigger( $deserves_trigger, $trigger, $event, $trigger_options, $automation ) {

        // Don't deserve if post is not received
        if( ! isset( $event['form_id'] ) && ! isset( $event['score'] ) ) {
            return false;
        }

        // Bail if post doesn't match with the trigger option
        if( $trigger_options['post'] !== 'any' && absint( $event['form_id'] ) !== absint( $trigger_options['post'] ) ) {
            return false;
        }

        $score = (float) $event['score'];
        $required_score =  (float) $trigger_options['score'];
        
        // Don't deserve if order total doesn't match with the trigger option
        if( ! automatorwp_number_condition_matches( $score, $required_score, $trigger_options['condition'] ) ) {
            return false;
        }

        return $deserves_trigger;

    }

    /**
     * Register the required hooks
     *
     * @since 1.0.0
     */
    public function hooks() {

        // Log meta data
        add_filter( 'automatorwp_anonymous_completed_trigger_log_meta', array( $this, 'log_meta' ), 10, 5 );

        // Log fields
        add_filter( 'automatorwp_log_fields', array( $this, 'log_fields' ), 10, 5 );

        parent::hooks();
    }

    /**
     * Trigger custom log meta
     *
     * @since 1.0.0
     *
     * @param array     $log_meta           Log meta data
     * @param stdClass  $trigger            The trigger object
     * @param array     $event              Event information
     * @param array     $trigger_options    The trigger's stored options
     * @param stdClass  $automation         The trigger's automation object
     *
     * @return array
     */
    function log_meta( $log_meta, $trigger, $event, $trigger_options, $automation ) {

        // Bail if action type don't match this action
        if( $trigger->type !== $this->trigger ) {
            return $log_meta;
        }

        $log_meta['form_fields'] = ( isset( $event['form_fields'] ) ? $event['form_fields'] : array() );

        return $log_meta;

    }

    /**
     * Action custom log fields
     *
     * @since 1.0.0
     *
     * @param array     $log_fields The log fields
     * @param stdClass  $log        The log object
     * @param stdClass  $object     The trigger/action/automation object attached to the log
     *
     * @return array
     */
    public function log_fields( $log_fields, $log, $object ) {

        // Bail if log is not assigned to an trigger
        if( $log->type !== 'trigger' ) {
            return $log_fields;
        }

        // Bail if trigger type don't match this trigger
        if( $object->type !== $this->trigger ) {
            return $log_fields;
        }

        $log_fields['form_fields'] = array(
            'name' => __( 'Fields Submitted', 'automatorwp-pro' ),
            'desc' => __( 'Information about the fields values sent on this form submission.', 'automatorwp-pro' ),
            'type' => 'text',
        );

        return $log_fields;

    }

}

new AutomatorWP_FluentForm_Anonymous_Submit_Quiz_Score();