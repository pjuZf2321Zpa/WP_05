<?php
/**
 * Plugin Name:           AutomatorWP - WP Fluent Forms
 * Plugin URI:            https://automatorwp.com/add-ons/fluentform/
 * Description:           Connect AutomatorWP with WP Fluent Forms.
 * Version:               1.1.2
 * Author:                AutomatorWP
 * Author URI:            https://automatorwp.com/
 * Text Domain:           automatorwp-fluentform
 * Domain Path:           /languages/
 * Requires at least:     4.4
 * Tested up to:          6.9
 * License:               GNU AGPL v3.0 (http://www.gnu.org/licenses/agpl.txt)
 *
 * @package               AutomatorWP\FluentForm
 * @author                AutomatorWP
 * @copyright             Copyright (c) AutomatorWP
 */

final class AutomatorWP_FluentForm {

    /**
     * @var         AutomatorWP_FluentForm $instance The one true AutomatorWP_FluentForm
     * @since       1.0.0
     */
    private static $instance;

    /**
     * Get active instance
     *
     * @access      public
     * @since       1.0.0
     * @return      AutomatorWP_FluentForm self::$instance The one true AutomatorWP_FluentForm
     */
    public static function instance() {
        if( !self::$instance ) {
            self::$instance = new AutomatorWP_FluentForm();
            self::$instance->constants();
            self::$instance->includes();
            self::$instance->hooks();            
        }

        return self::$instance;
    }

    /**
     * Setup plugin constants
     *
     * @access      private
     * @since       1.0.0
     * @return      void
     */
    private function constants() {
        // Plugin version
        define( 'AUTOMATORWP_FLUENTFORM_VER', '1.1.2' );

        // Plugin file
        define( 'AUTOMATORWP_FLUENTFORM_FILE', __FILE__ );

        // Plugin path
        define( 'AUTOMATORWP_FLUENTFORM_DIR', plugin_dir_path( __FILE__ ) );

        // Plugin URL
        define( 'AUTOMATORWP_FLUENTFORM_URL', plugin_dir_url( __FILE__ ) );
    }

    /**
     * Include plugin files
     *
     * @access      private
     * @since       1.0.0
     * @return      void
     */
    private function includes() {

        if( $this->meets_requirements() ) {

            // Includes
            require_once AUTOMATORWP_FLUENTFORM_DIR . 'includes/ajax-functions.php';
            require_once AUTOMATORWP_FLUENTFORM_DIR . 'includes/functions.php';

            // Triggers
            require_once AUTOMATORWP_FLUENTFORM_DIR . 'includes/triggers/submit-form.php';
            require_once AUTOMATORWP_FLUENTFORM_DIR . 'includes/triggers/submit-field-value.php';
            
            // Anonymous Triggers
            require_once AUTOMATORWP_FLUENTFORM_DIR . 'includes/triggers/anonymous-submit-form.php';
            require_once AUTOMATORWP_FLUENTFORM_DIR . 'includes/triggers/anonymous-submit-field-value.php';
            
            // Quiz Triggers
            if ( class_exists( '\FluentFormPro\classes\Quiz\QuizController' ) ) {

                $settings = get_option('fluentform_global_modules_status');

                if ( isset( $settings['quiz_addon'] ) && $settings['quiz_addon'] === 'yes' ) {
                    
                    require_once AUTOMATORWP_FLUENTFORM_DIR . 'includes/triggers/submit-quiz.php';
                    require_once AUTOMATORWP_FLUENTFORM_DIR . 'includes/triggers/submit-quiz-score.php';
                    require_once AUTOMATORWP_FLUENTFORM_DIR . 'includes/triggers/anonymous-submit-quiz.php';
                    require_once AUTOMATORWP_FLUENTFORM_DIR . 'includes/triggers/anonymous-submit-quiz-score.php';
                    
                }
                
            }

        }
    }

    /**
     * Setup plugin hooks
     *
     * @access      private
     * @since       1.0.0
     * @return      void
     */
    private function hooks() {

        add_action( 'automatorwp_init', array( $this, 'register_integration' ) );
        
        

        
    }

    /**
     * Registers this integration
     *
     * @since 1.0.0
     */
    function register_integration() {

        automatorwp_register_integration( 'fluentform', array(
            'label' => 'WP Fluent Forms',
            'icon'  => AUTOMATORWP_FLUENTFORM_URL . 'assets/fluentform.svg',
        ) );

    }

    /**
     * Check if there are all plugin requirements
     *
     * @since  1.0.0
     *
     * @return bool True if installation meets all requirements
     */
    private function meets_requirements() {

        if ( ! class_exists( 'AutomatorWP' ) ) {
            return false;
        }

        if ( ! defined( 'FLUENTFORM' ) ) {
            return false;
        }

        return true;

    }

}

/**
 * The main function responsible for returning the one true AutomatorWP_FluentForm instance to functions everywhere
 *
 * @since       1.0.0
 * @return      \AutomatorWP_FluentForm The one true AutomatorWP_FluentForm
 */
function AutomatorWP_FluentForm() {
    return AutomatorWP_FluentForm::instance();
}
add_action( 'plugins_loaded', 'AutomatorWP_FluentForm' );
