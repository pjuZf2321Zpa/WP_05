<?php
/**
 * Ajax Functions
 *
 * @package     AutomatorWP\Digimember\Ajax_Functions
 * @since       1.0.0
 */
// Exit if accessed directly
if( !defined( 'ABSPATH' ) ) exit;

/**
 * Ajax function for selecting products
 *
 * @since 1.0.0
 */
function automatorwp_digimember_ajax_get_products() {
    // Security check, forces to die if not security passed
    check_ajax_referer( 'automatorwp_admin', 'nonce' );

    global $wpdb;

    // Pull back the search string
    $search = isset( $_REQUEST['q'] ) ? $wpdb->esc_like( $_REQUEST['q'] ) : '';

    // Get the products
    $results = $wpdb->get_results( $wpdb->prepare(
        "SELECT p.id AS id, p.name AS text
        FROM {$wpdb->prefix}digimember_product AS p
        WHERE p.name LIKE %s",
        "%%{$search}%%"
    ) );

    // Prepend option none
    $results = automatorwp_ajax_get_ajax_results_option_none( $results );

    // Return our results
    wp_send_json_success( $results );
    die;

}
add_action( 'wp_ajax_automatorwp_digimember_get_products', 'automatorwp_digimember_ajax_get_products' );

/**
 * Ajax function for selecting membership products
 *
 * @since 1.0.0
 */
function automatorwp_digimember_ajax_get_membership_products() {
    // Security check, forces to die if not security passed
    check_ajax_referer( 'automatorwp_admin', 'nonce' );

    global $wpdb;

    // Pull back the search string
    $search = isset( $_REQUEST['q'] ) ? $wpdb->esc_like( $_REQUEST['q'] ) : '';

    // Get the products
    $results = $wpdb->get_results( $wpdb->prepare(
        "SELECT p.id AS id, p.name AS text
        FROM {$wpdb->prefix}digimember_product AS p
        WHERE p.name LIKE %s
        AND p.type = 'membership'",
        "%%{$search}%%"
    ) );

    // Prepend option none
    $results = automatorwp_ajax_get_ajax_results_option_none( $results );

    // Return our results
    wp_send_json_success( $results );
    die;

}
add_action( 'wp_ajax_automatorwp_digimember_get_membership_products', 'automatorwp_digimember_ajax_get_membership_products' );

/**
 * Ajax function for selecting download products
 *
 * @since 1.0.0
 */
function automatorwp_digimember_ajax_get_download_products() {
    // Security check, forces to die if not security passed
    check_ajax_referer( 'automatorwp_admin', 'nonce' );

    global $wpdb;

    // Pull back the search string
    $search = isset( $_REQUEST['q'] ) ? $wpdb->esc_like( $_REQUEST['q'] ) : '';

    // Get the products
    $results = $wpdb->get_results( $wpdb->prepare(
        "SELECT p.id AS id, p.name AS text
        FROM {$wpdb->prefix}digimember_product AS p
        WHERE p.name LIKE %s
        AND p.type = 'download'",
        "%%{$search}%%"
    ) );

    // Prepend option none
    $results = automatorwp_ajax_get_ajax_results_option_none( $results );

    // Return our results
    wp_send_json_success( $results );
    die;

}
add_action( 'wp_ajax_automatorwp_digimember_get_download_products', 'automatorwp_digimember_ajax_get_download_products' );