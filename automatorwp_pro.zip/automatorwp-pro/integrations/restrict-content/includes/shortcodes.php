<?php
/**
 * Shortcodes
 *
 * @package     AutomatorWP\Restrict_Content\Shortcodes
 * @since       1.0.0
 */
// Exit if accessed directly
if( !defined( 'ABSPATH' ) ) exit;

require_once AUTOMATORWP_RESTRICT_CONTENT_DIR . 'includes/shortcodes/automatorwp_restrict_content.php';