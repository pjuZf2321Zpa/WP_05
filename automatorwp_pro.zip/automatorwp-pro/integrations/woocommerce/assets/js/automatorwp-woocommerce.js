(function ( $ ) {

    // Change the variable product/subscription
    $('body').on('change', '.automatorwp-ajax-selector select[data-action="automatorwp_woocommerce_get_variable_products"], '
        + '.automatorwp-ajax-selector select[data-action="automatorwp_woocommerce_get_variable_subscriptions"]', function(e) {
        var item = $(this).closest('.automatorwp-automation-item');
        var row = $(this).closest('.cmb-row');
        var variation_row = item.find('.cmb-row.cmb2-id-variation');
        var variation_target_row = item.find('.cmb-row.cmb2-id-variation-target');

        // Bail if next field is not a term selector
        if( variation_row === undefined ) {
            return;
        }

        var product_id = $(this).val();
        //var first_change = row.hasClass('is-option-change');

        if( product_id !== 'any' && product_id !== '' ) {
            var variation_selector = variation_row.find('select.select2-hidden-accessible');

            // Remove Select2 element
            variation_selector.next('.select2').remove();

            // Update the event ID
            variation_selector.data( 'product-id', product_id );

            // Reset the selector
            variation_selector.removeAttr('data-select2-id');

            // Init it again
            automatorwp_ajax_selector( variation_selector );

            if ( variation_target_row.length !== 0 ) {
                var variation_selector = variation_target_row.find('select.select2-hidden-accessible');

                // Remove Select2 element
                variation_selector.next('.select2').remove();

                // Update the event ID
                variation_selector.data( 'product-id', product_id );

                // Reset the selector
                variation_selector.removeAttr('data-select2-id');

                // Init it again
                automatorwp_ajax_selector( variation_selector );
            }
        }

        row.removeClass('is-option-change');
    });

    // Append custom data to the ajax selector
    $('body').on('automatorwp_ajax_selector_data', '.automatorwp-ajax-selector select[data-action="automatorwp_woocommerce_get_product_variations"]', function(e, data, element) {
        data.product_id = element.data('product-id');
    });

    // On click on an option, check if form contains the product or variation selector
    $('body').on('click', '.automatorwp-automation-item[class*="automatorwp-trigger-woocommerce"] .automatorwp-automation-item-label > .automatorwp-option', function(e) {

        var item = $(this).closest('.automatorwp-automation-item');
        var option = $(this).data('option');
        var option_form = item.find('.automatorwp-option-form-container[data-option="' + option + '"]');

        // If is a product/subscription option, force change to its select
        var product_selector = option_form.find('.automatorwp-ajax-selector select[data-action="automatorwp_woocommerce_get_variable_products"], '
            + '.automatorwp-ajax-selector select[data-action="automatorwp_woocommerce_get_variable_subscriptions"]');

        if( product_selector !== undefined ) {
            product_selector.closest('.automatorwp-ajax-selector').addClass('is-option-change');
            product_selector.trigger('change');
        }

        // If is a variation option, force change to the product select
        var variation_selector = option_form.find('.automatorwp-ajax-selector select[data-action="automatorwp_woocommerce_get_product_variations"]');

        if( variation_selector !== undefined ) {
            var product_row = item.find('.cmb-row.cmb2-id-product');
            product_row.addClass('is-option-change');
            product_row.find('select').trigger('change');
        }

    });

    // Body loaded to displya or not the shipping fields
    $('body').ready(function() {
        var $selector = $('.automatorwp-action-woocommerce-create-order .cmb2-id-billing-shipping-info input');
        
        $selector.each(function() {
            automatorwp_woocommerce_shipping_fields($(this), false);
        });
    });

    $('body').on('click', '.automatorwp-action-woocommerce-create-order', function(e) {
        setTimeout(function() {
            $('.automatorwp-action-woocommerce-create-order .cmb2-id-billing-shipping-info input').each(function() {
                automatorwp_woocommerce_shipping_fields($(this), false);
            });
        }, 100); 
    });

    // On change
    $('body').on('change', '.automatorwp-action-woocommerce-create-order .cmb2-id-billing-shipping-info input', function(e) {
        automatorwp_woocommerce_shipping_fields($(this), true);
    });

    // Show or hide shipping fields
    function automatorwp_woocommerce_shipping_fields($checkbox, display) {
        var $metabox = $checkbox.closest('.cmb2-metabox');
        var fields = $metabox.find(
            '.cmb2-id-shipping-country,' +
            '.cmb2-id-shipping-country-custom,' +
            '.cmb2-id-shipping-email,' +
            '.cmb2-id-shipping-first-name,' +
            '.cmb2-id-shipping-last-name,' +
            '.cmb2-id-shipping-address-1,' +
            '.cmb2-id-shipping-address-2,' +
            '.cmb2-id-shipping-city,' +
            '.cmb2-id-shipping-state,' +
            '.cmb2-id-shipping-postcode,' +
            '.cmb2-id-shipping-phone'
        );

        if( $checkbox.is(':checked') ) {
            if (display) {
                fields.slideUp('fast');
            } else {
                fields.hide();
            }
        } else {
            if (display) {
                fields.slideDown('fast');
            } else {
                fields.show();
            }
        } 
    }

    $('body').on('select2:select', '.cmb2-id-products select', function (e) {
        var data = e.params.data;

        var $this = $(this);
        var $group = $this.closest('.cmb-field-list');
        var $price_input = $group.find('input[data-option="products[unit_price]"]');
        var $quantity_input = $group.find('input[data-option="products[quantity]"]');
        var $total_input = $group.find('input[data-option="products[total_price]"]');

        $price_input.val( data.price );
        var total = $price_input.val() * $quantity_input.val();

        $total_input.val( total.toFixed(2) );

        automatorwp_woocommerce_calculate_total();
        
    });

    $('body').on('change keyup', '.cmb2-id-products input', function (e) {
        var $this = $(this);
        var $group = $this.closest('.cmb-field-list');
        
        var $price_input = $group.find('input[data-option="products[unit_price]"]');
        var $quantity_input = $group.find('input[data-option="products[quantity]"]');
        var $total_input = $group.find('input[data-option="products[total_price]"]');
        
        var total = $price_input.val() * $quantity_input.val();

        $total_input.val( total.toFixed(2) );

        automatorwp_woocommerce_calculate_total();

    });

    $('body').on('change keyup', 'input[data-option="tax"]', function (e) {
        automatorwp_woocommerce_calculate_total();
    });

    $('body').on('change keyup', 'input[data-option="discount"]', function (e) {       
        automatorwp_woocommerce_calculate_total();
    });

    $('body').on('change', 'input[data-option="discount_type"]', function (e) {
        automatorwp_woocommerce_calculate_total();
    });

    // To add subtotal, tax, discount and total
    function automatorwp_woocommerce_calculate_total() {
        var subtotal = 0;
        var coupon_discount_total = 0;

        $('input[data-option="products[total_price]"]').each(function() {
            var value_input = parseFloat($(this).val()) || 0;
            subtotal += value_input;
        });

        // Get the coupon data
        $('input[data-option="coupon_discount[coupon_amount]"]').each(function() {
            var coupon_value_input = parseFloat($(this).val()) || 0;
            
            // Get the coupon type slug
            var $group = $(this).closest('.cmb-field-list');
            var coupon_type_slug = $group.find('input[data-option="coupon_discount[coupon_type_slug]"]').val();

            if (coupon_type_slug === 'percent') {
                var percent_value = subtotal * (coupon_value_input / 100);
                coupon_discount_total += percent_value;
            } else {
                coupon_discount_total += coupon_value_input;
            }
        });

        var currencySymbol = $('.automatorwp-woocommerce-summary-order .automatorwp-woocommerce-currency').first().text();
        var taxInputVal = $('input[data-option="tax"]').val();
        var discountInputVal = $('input[data-option="discount"]').val();
        
        var totalFinal = subtotal;

        // Taxes
        if (!taxInputVal || taxInputVal.trim() === "") {
            $('.automatorwp-woocommerce-tax').text("Taxes will be calculated after the action is executed.");
            $('.automatorwp-woocommerce-currency-tax').text("");
        } else {    
            var percentage_tax = parseFloat(taxInputVal) / 100; 
            var tax = subtotal * percentage_tax;
            totalFinal += tax; 

            $('.automatorwp-woocommerce-currency-tax').text(currencySymbol);
            $('.automatorwp-woocommerce-tax').text(tax.toFixed(2));
        }

        // Manual discount
        var discount = 0; 
        if (discountInputVal && discountInputVal.trim() !== "") {
            rawDiscount = parseFloat(discountInputVal);
            
            var discountType = $('input[data-option="discount_type"]:checked').val(); 

            if (discountType === 'percentage') {
                discount = subtotal * (rawDiscount / 100);
            } else {
                discount = rawDiscount;
            }

            totalFinal -= discount;
        }
        $('.automatorwp-woocommerce-discount').text(discount.toFixed(2));

        // Add coupon discount
        if (coupon_discount_total <= 0) {
            $('.automatorwp-woocommerce-coupon-discount').text("0.00");
        } else {
            totalFinal -= coupon_discount_total; 
            $('.automatorwp-woocommerce-coupon-discount').text(coupon_discount_total.toFixed(2));
        }

        $('.automatorwp-woocommerce-subtotal').text(subtotal.toFixed(2));
        $('.automatorwp-woocommerce-total').text(totalFinal.toFixed(2));
    }

    // Coupon data
    $('body').on('select2:select', '.cmb2-id-coupon-discount select', function (e) {
        var data = e.params.data;

        var $this = $(this);
        var $group = $this.closest('.cmb-field-list');
        var $coupon_amount_input = $group.find('input[data-option="coupon_discount[coupon_amount]"]');
        var $coupon_type_input = $group.find('input[data-option="coupon_discount[coupon_type]"]');
        var $coupon_type_slug_input = $group.find('input[data-option="coupon_discount[coupon_type_slug]"]');
        

        $coupon_amount_input.val( data.coupon_amount );
        $coupon_type_input.val( data.coupon_type );
        $coupon_type_slug_input.val( data.coupon_type_slug );

        automatorwp_woocommerce_calculate_total();
        
    });

    automatorwp_woocommerce_calculate_total();

})( jQuery );