<?php
/**
 * Ajax Functions
 *
 * @package     AutomatorWP\Integrations\WooCommerce\Ajax_Functions
 * @author      AutomatorWP <contact@automatorwp.com>, Ruben Garcia <rubengcdev@gmail.com>
 * @since       1.0.0
 */
// Exit if accessed directly
if( !defined( 'ABSPATH' ) ) exit;

/**
 * Ajax function for selecting variable products
 *
 * @since 1.0.0
 */
function automatorwp_woocommerce_ajax_get_variable_products() {
    // Security check, forces to die if not security passed
    check_ajax_referer( 'automatorwp_admin', 'nonce' );

    global $wpdb;

    // Pull back the search string
    $search = isset( $_REQUEST['q'] ) ? sanitize_text_field( $_REQUEST['q'] ) : '';
    $page = isset( $_REQUEST['page'] ) ? absint( $_REQUEST['page'] ) : 1;

    // Get the results
    $results = $wpdb->get_results( $wpdb->prepare(
        "SELECT p.ID AS id, p.post_title AS text
         FROM {$wpdb->posts} AS p
         LEFT JOIN {$wpdb->term_relationships} as tr ON ( p.ID = tr.object_id )
         WHERE tr.term_taxonomy_id IN ( SELECT term_id FROM {$wpdb->terms} WHERE slug IN ('variable') )
			AND p.post_type = 'product'
			AND p.post_status = 'publish'
			AND p.post_title LIKE %s
         ORDER BY p.post_title ASC",
        "%%{$search}%%"
    ) );

    // Parse extra options
    $results = automatorwp_ajax_parse_extra_options( $results );

    // Return our results
    wp_send_json_success( $results );
    die;

}
add_action( 'wp_ajax_automatorwp_woocommerce_get_variable_products', 'automatorwp_woocommerce_ajax_get_variable_products' );

/**
 * Ajax function for selecting variable products
 *
 * @since 1.0.0
 */
function automatorwp_woocommerce_ajax_get_variable_subscriptions() {
    // Security check, forces to die if not security passed
    check_ajax_referer( 'automatorwp_admin', 'nonce' );

    global $wpdb;

    // Pull back the search string
    $search = isset( $_REQUEST['q'] ) ? sanitize_text_field( $_REQUEST['q'] ) : '';
    $page = isset( $_REQUEST['page'] ) ? absint( $_REQUEST['page'] ) : 1;

    // Get the results
    $results = $wpdb->get_results( $wpdb->prepare(
        "SELECT p.ID AS id, p.post_title AS text
         FROM {$wpdb->posts} AS p
         LEFT JOIN {$wpdb->term_relationships} as tr ON ( p.ID = tr.object_id )
         WHERE tr.term_taxonomy_id IN ( SELECT term_id FROM {$wpdb->terms} WHERE slug IN ('variable','subscription','variable-subscription') )
			AND p.post_type = 'product'
			AND p.post_status = 'publish'
			AND p.post_title LIKE %s
         ORDER BY p.post_title ASC",
        "%%{$search}%%"
    ) );

    // Parse extra options
    $results = automatorwp_ajax_parse_extra_options( $results );

    // Return our results
    wp_send_json_success( $results );
    die;

}
add_action( 'wp_ajax_automatorwp_woocommerce_get_variable_subscriptions', 'automatorwp_woocommerce_ajax_get_variable_subscriptions' );

/**
 * Ajax function for selecting product variations
 *
 * @since 1.0.0
 */
function automatorwp_woocommerce_ajax_get_product_variations() {
    // Security check, forces to die if not security passed
    check_ajax_referer( 'automatorwp_admin', 'nonce' );

    $results = array();

    // Pull back the search string
    $search = isset( $_REQUEST['q'] ) ? sanitize_text_field( $_REQUEST['q'] ) : '';
    $page = isset( $_REQUEST['page'] ) ? absint( $_REQUEST['page'] ) : 1;
    $product_id = isset( $_REQUEST['product_id'] ) ? absint( $_REQUEST['product_id'] ) : 0;
   
    // Bail if not event ID provided
    if( $product_id === 0 ) {
        wp_send_json_success( array(
            array(
                'id' => 'any',
                'text' => __( 'Please, choose a variable product first.', 'automatorwp-pro' )
            )
        ) );
        die;
    }

    $product = wc_get_product( $product_id );
	$variations = $product->get_available_variations();

    // Bail if event does not have tickets
    if ( empty( $variations ) ) {
        wp_send_json_success( array(
            array(
                'id' => 'any',
                'text' => __( 'No variations found for this product.', 'automatorwp-pro' )
            )
        ) );
        die;
    }

    foreach ( $variations as $variation ) {
		
		$attributes = array();
		
		foreach( $variation['attributes'] as $attribute ) {
            if( ! empty( $attribute ) ) {
                $attributes[] = $attribute;
            }
        }
		
        $results[] = array(
            'id' => $variation['variation_id'],
            'text'  => implode( ', ', $attributes ),
        );
    }

    // Parse extra options
    $results = automatorwp_ajax_parse_extra_options( $results );

    // Return our results
    wp_send_json_success( $results );
    die;

}
add_action( 'wp_ajax_automatorwp_woocommerce_get_product_variations', 'automatorwp_woocommerce_ajax_get_product_variations' );

/**
 * Ajax function for selecting countries
 *
 * @since 1.0.0
 */
function automatorwp_woocommerce_ajax_get_countries() {
    // Security check, forces to die if not security passed
    check_ajax_referer( 'automatorwp_admin', 'nonce' );
    
    global $wpdb;

    // Pull back the search string
    $search = isset( $_REQUEST['q'] ) ? $wpdb->esc_like( $_REQUEST['q'] ) : '';

    $countries = automatorwp_woocommerce_get_countries();
    
    $results = array();

    // Parse country results to match select2 results
    foreach ( $countries as $code => $name ) {

        if( ! empty( $search ) ) {
            // Allow search by country code and name
            if( strpos( strtolower( $code ), strtolower( $search ) ) === false
            && strpos( strtolower( $name ), strtolower( $search ) ) === false ) {
                continue;
            }
        }
        
        $results[] = array(
            'id' => $code,
            'text' => $name
        );
    }

    // Prepend option none
    $results = automatorwp_ajax_parse_extra_options( $results );

    // Return our results
    wp_send_json_success( $results );
    die;

}
add_action( 'wp_ajax_automatorwp_woocommerce_get_countries', 'automatorwp_woocommerce_ajax_get_countries' );

/**
 * Ajax function for selecting products
 *
 * @since 1.0.0
 */
function automatorwp_woocommerce_ajax_get_products() {
    // Security check, forces to die if not security passed
    check_ajax_referer( 'automatorwp_admin', 'nonce' );
    
    global $wpdb;

    // Pull back the search string
    $search = isset( $_REQUEST['q'] ) ? $wpdb->esc_like( $_REQUEST['q'] ) : '';

    $products = automatorwp_woocommerce_get_products( );
        
    $results = array();

    // Parse product results to match select2 results
    foreach ( $products as $product ) {

        if( ! empty( $search ) ) {
            if( strpos( strtolower( $product['name'] ), strtolower( $search ) ) === false ) {
                continue;
            }
        }

        $product_price = wc_get_product( $product['id'] )->get_price();
        
        $results[] = array(
            'id' => $product['id'],
            'text' => $product['name'],
            'price' => $product_price,
        );
    }

    // Prepend option none
    $results = automatorwp_ajax_parse_extra_options( $results );
    
    // Return our results
    wp_send_json_success( $results );
    die;

}
add_action( 'wp_ajax_automatorwp_woocommerce_get_products', 'automatorwp_woocommerce_ajax_get_products' );

/**
 * Ajax function for selecting coupons
 *
 * @since 1.0.0
 */
function automatorwp_woocommerce_ajax_get_coupons() {
    // Security check, forces to die if not security passed
    check_ajax_referer( 'automatorwp_admin', 'nonce' );
    
    global $wpdb;

    // Pull back the search string
    $search = isset( $_REQUEST['q'] ) ? $wpdb->esc_like( $_REQUEST['q'] ) : '';

    $coupons = automatorwp_woocommerce_get_coupons( );
        
    $results = array();


    // Parse product results to match select2 results
    foreach ( $coupons as $coupon ) {

        if( ! empty( $search ) ) {
            if( strpos( strtolower( $coupon['name'] ), strtolower( $search ) ) === false ) {
                continue;
            }
        }

        $coupon_obj = new WC_Coupon( $coupon['id'] );
        
        $amount = $coupon_obj->get_amount();
        
        $type_slug = $coupon_obj->get_discount_type();
        $coupon_types = wc_get_coupon_types();
        $coupon_type = isset( $coupon_types[ $type_slug ] ) ? $coupon_types[ $type_slug ] : $type_slug;
        
        $results[] = array(
            'id' => $coupon['id'],
            'text' => $coupon['name'],
            'coupon_amount' => $amount,
            'coupon_type' => $coupon_type,
            'coupon_type_slug' => $type_slug,
        );
    }

    // Prepend option none
    $results = automatorwp_ajax_parse_extra_options( $results );
    
    // Return our results
    wp_send_json_success( $results );
    die;

}
add_action( 'wp_ajax_automatorwp_woocommerce_get_coupons', 'automatorwp_woocommerce_ajax_get_coupons' );