<?php
/**
 * Add Order Note
 *
 * @package     AutomatorWP\Integrations\WooCommerce\Actions\Add_Order_Note
 * @author      AutomatorWP <contact@automatorwp.com>
 * @since       1.0.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

class AutomatorWP_WooCommerce_Add_Order_Note extends AutomatorWP_Integration_Action {

    public $integration = 'woocommerce';
    public $action = 'woocommerce_add_order_note';

    /**
     * Register the action
     *
     * @since 1.0.0
     */
    public function register() {

        automatorwp_register_action( $this->action, array(
            'integration'   => $this->integration,
            'label'         => __( 'Add a note to an order', 'automatorwp-pro' ),
            'select_option' => __( 'Add a note to <strong>order</strong>', 'automatorwp-pro' ),
            /* translators: %1$s: Order. */
            'edit_label'    => sprintf( __( 'Add a note to %1$s', 'automatorwp-pro' ), '{post}' ),
            /* translators: %1$s: Order. */
            'log_label'     => sprintf( __( 'Added a note to %1$s', 'automatorwp-pro' ), '{post}' ),
            'options'       => array(
                'post' => array(
                    'default' => __( 'an order', 'automatorwp-pro' ),
                    'from'    => 'order_id',
                    'fields'  => array(
                        'order_id' => array(
                            'name'        => __( 'Order ID:', 'automatorwp-pro' ),
                            'desc'        => __( 'The order ID.', 'automatorwp-pro' ),
                            'type'        => 'text',
                            'required'    => true,
                        ),
                        'note_type' => array(
                            'name'        => __( 'Note type:', 'automatorwp-pro' ),
                            'type'        => 'select',
                            'options'   => array(
                                'private' => __( 'Private Note', 'automatorwp-pro' ),
                                'customer' => __( 'Note to customer', 'automatorwp-pro' ),
                            ),
                            'required'    => true,
                        ),
                        'note' => array(
                            'name'        => __( 'Order Note:', 'automatorwp-pro' ),
                            'type'        => 'textarea',
                            'default'     => '',
                            'desc'        => __( 'The text that will be added as an order note.', 'automatorwp-pro' ),
                            'required'    => true,
                        ),

                    ),
                ),

            ),
        ) );

    }

    /**
     * Action execution function
     *
     * @since 1.0.0
     *
     * @param stdClass  $action         The action object
     * @param int       $user_id        The user ID
     * @param array     $action_options The action's stored options (with tags already passed)
     * @param stdClass  $automation     The action's automation object
     */
    public function execute( $action, $user_id, $action_options, $automation ) {

        // Shorthand
        $order_id = absint( $action_options['order_id'] );
        $order_note = sanitize_text_field( $action_options['note'] );
        $note_type = sanitize_text_field( $action_options['note_type'] );

        // Bail if empty order id
        if ( empty( $order_id ) ){
            $this->result = __( 'Order ID cannot be empty', 'gamipress-woocommerce' );
            return;
        }

        if ( empty( $order_note ) ){
            $this->result = __( 'Order note cannot be empty', 'gamipress-woocommerce' );
            return;
        }

        // Get the order
        $order = wc_get_order( $order_id );

        if ( ! $order instanceof WC_Order ) {
            $this->result = sprintf( __( 'The order with ID %d could not be found', 'gamipress-woocommerce' ), $order_id );
            return;
        }

        // Note type
        $is_customer_note = (int) ( $note_type === 'customer' );

        // Add the note
        $order->add_order_note( $order_note, $is_customer_note );
        $this->result = sprintf( __( 'The note was added to order %d', 'gamipress-woocommerce' ), $order_id );
    }

    /**
     * Register required hooks
     *
     * @since 1.0.0
     */
    public function hooks() {

        // Log meta data
        add_filter( 'automatorwp_user_completed_action_log_meta', array( $this, 'log_meta' ), 10, 5 );

        // Log fields
        add_filter( 'automatorwp_log_fields', array( $this, 'log_fields' ), 10, 5 );

        parent::hooks();
    }

    /**
     * Action custom log meta
     *
     * @since 1.0.0
     *
     * @param array     $log_meta           Log meta data
     * @param stdClass  $action             The action object
     * @param int       $user_id            The user ID
     * @param array     $action_options     The action's stored options (with tags already passed)
     * @param stdClass  $automation         The action's automation object
     *
     * @return array
     */
    public function log_meta( $log_meta, $action, $user_id, $action_options, $automation ) {

        // Bail if action type don't match this action
        if( $action->type !== $this->action ) {
            return $log_meta;
        }

        // Store result
        $log_meta['result'] = $this->result;

        return $log_meta;
    }

    /**
     * Action custom log fields
     *
     * @since 1.0.0
     *
     * @param array     $log_fields The log fields
     * @param stdClass  $log        The log object
     * @param stdClass  $object     The trigger/action/automation object attached to the log
     *
     * @return array
     */
    public function log_fields( $log_fields, $log, $object ) {

        // Bail if log is not assigned to an action
        if( $log->type !== 'action' ) {
            return $log_fields;
        }

        // Bail if action type don't match this action
        if( $object->type !== $this->action ) {
            return $log_fields;
        }

        $log_fields['result'] = array(
            'name' => __( 'Result:', 'automatorwp-pro' ),
            'type' => 'text',
        );

        return $log_fields;
    }

}

new AutomatorWP_WooCommerce_Add_Order_Note();
