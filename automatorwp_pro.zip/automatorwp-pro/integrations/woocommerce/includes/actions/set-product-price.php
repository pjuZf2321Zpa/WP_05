<?php
/**
 * Set Product Price
 *
 * @package     AutomatorWP\Integrations\WooCommerce\Actions\Set_Product_Price
 * @author      AutomatorWP <contact@automatorwp.com>
 * @since       1.0.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

class AutomatorWP_WooCommerce_Set_Product_Price extends AutomatorWP_Integration_Action {

    public $integration = 'woocommerce';
    public $action = 'woocommerce_set_product_price';

    /**
     * Register the action
     *
     * @since 1.0.0
     */
    public function register() {

        automatorwp_register_action( $this->action, array(
            'integration'   => $this->integration,
            'label'         => __( 'Set price for a product', 'automatorwp-pro' ),
            'select_option' => __( 'Set <strong>price</strong> for a product', 'automatorwp-pro' ),
            /* translators: %1$s: Product title. */
            'edit_label'    => sprintf( __( 'Set price for %1$s', 'automatorwp-pro' ), '{post}' ),
            /* translators: %1$s: Product title. */
            'log_label'     => sprintf( __( 'Set price for %1$s', 'automatorwp-pro' ), '{post}' ),
            'options'       => array(
                'post' => array(
                    'from' => 'post_id',
                    'fields' => array(
                        'post_id' => automatorwp_utilities_post_field( array(
                            'name' => __( 'Product:', 'automatorwp-pro' ),
                            'option_none_label' => __( 'any product', 'automatorwp-pro' ),
                            'post_type' => 'product'
                        ) ),
                        'price' => array(
                            'name'        => __( 'Price:', 'automatorwp-pro' ),
                            'desc'        => __( 'The product price.', 'automatorwp-pro' ),
                            'type'        => 'text',
                            'required'    => true,
                                'attributes' => array(
                                    'type' => 'number',
                                    'step' => 0.01,
                                    'min' => 0,
                                ),
                        ),
                    )
                ),
                
            ),
        ) );

    }

    /**
     * Action execution function
     *
     * @since 1.0.0
     *
     * @param stdClass  $action         The action object
     * @param int       $user_id        The user ID
     * @param array     $action_options The action's stored options (with tags already passed)
     * @param stdClass  $automation     The action's automation object
     */
    public function execute( $action, $user_id, $action_options, $automation ) {

        // Shorthand
        $product_id = absint( $action_options['post_id'] );
        $price = floatval( $action_options['price'] );

        if ( empty( $product_id ) ){
            $this->result = __( 'Product cannot be empty', 'gamipress-woocommerce' );
            return;
        }

        // Bail if empty order id
        if ( empty( $price ) ){
            $this->result = __( 'New product price cannot be empty', 'gamipress-woocommerce' );
            return;
        }

        // Get the product
        $product = wc_get_product ( $product_id );

        if ( ! $product instanceof WC_Product ) {
            $this->result = sprintf( __( 'The product with ID %d could not be found', 'gamipress-woocommerce' ), $product_id );
            return;
        }

        $product->set_price( $price );
		$product->set_regular_price( $price );
		$product->save();

        $this->result = sprintf( __( 'The product %s was updated with the new price %f', 'gamipress-woocommerce' ), $product->get_title(), $price );
    }

    /**
     * Register required hooks
     *
     * @since 1.0.0
     */
    public function hooks() {

        // Log meta data
        add_filter( 'automatorwp_user_completed_action_log_meta', array( $this, 'log_meta' ), 10, 5 );

        // Log fields
        add_filter( 'automatorwp_log_fields', array( $this, 'log_fields' ), 10, 5 );

        parent::hooks();
    }

    /**
     * Action custom log meta
     *
     * @since 1.0.0
     *
     * @param array     $log_meta           Log meta data
     * @param stdClass  $action             The action object
     * @param int       $user_id            The user ID
     * @param array     $action_options     The action's stored options (with tags already passed)
     * @param stdClass  $automation         The action's automation object
     *
     * @return array
     */
    public function log_meta( $log_meta, $action, $user_id, $action_options, $automation ) {

        // Bail if action type don't match this action
        if( $action->type !== $this->action ) {
            return $log_meta;
        }

        // Store result
        $log_meta['result'] = $this->result;

        return $log_meta;
    }

    /**
     * Action custom log fields
     *
     * @since 1.0.0
     *
     * @param array     $log_fields The log fields
     * @param stdClass  $log        The log object
     * @param stdClass  $object     The trigger/action/automation object attached to the log
     *
     * @return array
     */
    public function log_fields( $log_fields, $log, $object ) {

        // Bail if log is not assigned to an action
        if( $log->type !== 'action' ) {
            return $log_fields;
        }

        // Bail if action type don't match this action
        if( $object->type !== $this->action ) {
            return $log_fields;
        }

        $log_fields['result'] = array(
            'name' => __( 'Result:', 'automatorwp-pro' ),
            'type' => 'text',
        );

        return $log_fields;
    }

}

new AutomatorWP_WooCommerce_Set_Product_Price();
