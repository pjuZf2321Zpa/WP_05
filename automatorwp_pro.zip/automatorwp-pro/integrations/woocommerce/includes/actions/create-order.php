<?php
/**
 * Create Order Action
 *
 * @package     AutomatorWP\Integrations\WooCommerce\Actions\Create_Order
 * @since       1.0.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

class AutomatorWP_WooCommerce_Create_Order extends AutomatorWP_Integration_Action {

    public $integration = 'woocommerce';
    public $action = 'woocommerce_create_order';

    /**
     * Register the action
     *
     * @since 1.0.0
     */
    public function register() {

        // Get dynamic options
        //$statuses        = automatorwp_wc_create_order_get_statuses();
        //$payment_methods = automatorwp_wc_create_order_get_payment_methods();

        automatorwp_register_action( $this->action, array(
            'integration'       => $this->integration,
            'label'             => __( 'Create a new order', 'automatorwp-pro' ),
            'select_option'     => __( 'Create a new <strong>order</strong>', 'automatorwp-pro' ),
            /* translators: %1$s: Order. */
            'edit_label'        => sprintf( __( 'Create a new %1$s', 'automatorwp-pro' ), '{order}' ),
            'log_label'         => __( 'Create a new order', 'automatorwp-pro' ),
            'options'           => array(
                // --- CUSTOMER ---
                'order' => array(
                    'default' => __( 'order', 'automatorwp-pro' ),
                    'fields' => array(
                        'products' => array(
                            'name' => __( 'Products:', 'automatorwp-pro' ),
                            'type' => 'group',
                            'classes' => 'automatorwp-fields-table automatorwp-fields-table-col-1',
                            'options'     => array(
                                'add_button'        => __( 'Add product', 'automatorwp-pro' ),
                                'remove_button'     => '<span class="dashicons dashicons-no-alt"></span>',
                                ),
                            'fields' => array(
                                'product' => automatorwp_utilities_ajax_selector_field( array(
                                    'field'             => 'Product',
                                    'name'              => __( 'Product:', 'automatorwp-pro' ),
                                    'option_default'    => __( 'Select a Product', 'automatorwp-pro' ),
                                    'action_cb'         => 'automatorwp_woocommerce_get_products',
                                    'options_cb'        => 'automatorwp_woocommerce_options_cb_product',
                                    'default'           => ''
                                ) ),
                                'quantity' => array(
                                    'name' => __( 'Quantity:', 'automatorwp-pro' ),
                                    'type' => 'text',
                                    'attributes' => array(
                                        'type' => 'number',
                                        'min'  => '1',
                                    ),
                                    'placeholder' => '1',
                                    'default' => '1',
                                ),
                                'unit_price' => array(
                                    'name' => __( 'Unit Price:', 'automatorwp-pro' ),
                                    'type' => 'text',
                                    'default' => '',
                                    'attributes' => array(
                                        'readonly' => 'readonly',
                                    ),
                                ),
                                'total_price' => array(
                                    'name' => __( 'Total Price:', 'automatorwp-pro' ),
                                    'type' => 'text',
                                    'attributes' => array(
                                        'type' => 'number',
                                            'step' => '0.01',
                                            'min'  => '0',
                                        ),
                                    'default' => ''
                                ),
                            ),
                        ),
                        // Coupon discount
                        'coupon_discount' => array(
                            'name' => __( 'Coupons:', 'automatorwp-pro' ),
                            'type' => 'group',
                            'classes' => 'automatorwp-fields-table automatorwp-fields-table-col-1',
                            'options'     => array(
                                'add_button'        => __( 'Add coupon', 'automatorwp-pro' ),
                                'remove_button'     => '<span class="dashicons dashicons-no-alt"></span>',
                                ),
                            'fields' => array(
                                'coupon_discount' => automatorwp_utilities_ajax_selector_field( array(
                                    'field'             => 'Coupon',
                                    'name'              => __( 'Coupon:', 'automatorwp-pro' ),
                                    'option_default'    => __( 'Select a coupon', 'automatorwp-pro' ),
                                    'action_cb'         => 'automatorwp_woocommerce_get_coupons',
                                    'options_cb'        => 'automatorwp_woocommerce_options_cb_coupon',
                                    'default'           => ''
                                ) ),
                                'coupon_amount' => array(
                                    'name' => __( 'Amount:', 'automatorwp-pro' ),
                                    'type' => 'text',
                                    'classes' => 'automatorwp-woocommerce-hide-coupon-fields',
                                    'default' => ''
                                ),
                                'coupon_type' => array(
                                    'name' => __( 'Type:', 'automatorwp-pro' ),
                                    'type' => 'text',
                                    'classes' => 'automatorwp-woocommerce-hide-coupon-fields',
                                    'default' => ''
                                ),
                                'coupon_type_slug' => array(
                                    'name' => __( 'Type Slug:', 'automatorwp-pro' ),
                                    'type' => 'text',
                                    'classes' => 'automatorwp-woocommerce-hide-coupon-fields',
                                    'default' => ''
                                ),
                            ),
                        ),
                        'discount' => array(
                            'name' => __( 'Discount:', 'automatorwp-pro' ),
                            'desc' => __( 'Add the amount to be deducted to the total order.', 'automatorwp-pro' ),
                            'type' => 'text',
                            'attributes' => array(
                                'type' => 'number',
                                    'step' => '0.01',
                                    'min'  => '0',
                                ),
                            'classes' => 'automatorwp-col-6',
                            'default' => ''
                        ),
                        'discount_type' => array(
                            'name' => __('Discount type', 'automatorwp-pro' ),
                            'type' => 'radio',
                            'options' => array(
                                'fixed' => __( 'Fixed', 'automatorwp-pro' ),
                                'percentage' => __( 'Percentage', 'automatorwp-pro' ),
                            ),
                            'classes' => 'automatorwp-col-6',
                            'after_row' => 'automatorwp_cmb2_div_clear_cb',
                            'default' => 'fixed',
                        ),
                        'order_summary' => array(
                            'name' => __( 'Order Summary', 'automatorwp-pro' ),
                            'type' => 'title',
                        ),
                        'order_total' => array(
                            'name' => __( 'Order Total:', 'automatorwp-pro' ),
                            'type' => 'text',
                            'render_row_cb' => 'automatorwp_woocommerce_order_total_display_cb',
                        ),
                        'order_status' => array(
                            'name'          => __( 'Order status:', 'automatorwp-pro' ),
                            'type'          => 'select',
                            'options_cb'    => 'wc_get_order_statuses',
                            'default'       => 'wc-pending'
                        ),
                        'order_datetime' => array(
                            'name' => __( 'Date and time:', 'automatorwp-pro' ),
                            'desc' => __( 'Leave empty to get the current date and time.', 'automatorwp-pro' ),
                            'type' => 'text_datetime_timestamp',
                            'date_format' =>  automatorwp_get_date_format( array( 'Y-m-d', 'm/d/Y' ) ),
                            'time_format' =>  automatorwp_get_time_format(),
                        ),
                        'payment_method' => array(
                            'name' => __( 'Payment method:', 'automatorwp-pro' ),
                            'type' => 'select',
                            'options_cb' => 'automatorwp_woocommerce_get_payment_methods',
                            'default'   => 'bacs',
                        ),
                        'order_note' => array(
                            'name' => __( 'Order note:', 'automatorwp-pro' ),
                            'type' => 'text',
                        ),
                        // Billing address
                        'billing_title' => array(
                            'name' => __( 'Billing Address', 'automatorwp-pro' ),
                            'type' => 'title',
                        ),
                        'billing_email' => array(
                            'name' => __( 'Billing email:', 'automatorwp-pro' ),
                            'type' => 'text',
                            'default' => '',
                        ),
                        'billing_first_name' => array(
                            'name' => __( 'Billing first name:', 'automatorwp-pro' ),
                            'type' => 'text',
                            'classes' => 'automatorwp-col-6',
                            'default' => '',
                        ),
                        'billing_last_name' => array(
                            'name' => __( 'Billing last name:', 'automatorwp-pro' ),
                            'classes' => 'automatorwp-col-6',
                            'after_row' => 'automatorwp_cmb2_div_clear_cb',
                            'type' => 'text', 'default' => '',
                        ),
                        'billing_country' => automatorwp_utilities_ajax_selector_field( array(
                            'field'             => 'billing_country',
                            'name'              => __( 'Billing country:', 'automatorwp-pro' ),
                            'option_default'    => __( 'Select a country', 'automatorwp-pro' ),
                            'option_custom'         => true,
                            'option_custom_desc'    => __( 'Country code', 'automatorwp-pro' ),
                            'action_cb'         => 'automatorwp_woocommerce_get_countries',
                            'options_cb'        => 'automatorwp_woocommerce_options_cb_country',
                            'default'           => ''
                        ) ),
                        'billing_country_custom' => automatorwp_utilities_custom_field( array(
                            'option_custom_desc'    => __( 'Country code', 'automatorwp-pro' ),
                        ) ),
                        'billing_address_1' => array(
                            'name' => __( 'Billing address 1:', 'automatorwp-pro' ),
                            'type' => 'text',
                            'classes' => 'automatorwp-col-6',
                            'default' => '',
                        ),
                        'billing_address_2' => array(
                            'name' => __( 'Billing address 2:', 'automatorwp-pro' ),
                            'type' => 'text',
                            'classes' => 'automatorwp-col-6',
                            'after_row' => 'automatorwp_cmb2_div_clear_cb',
                            'default' => '',
                        ),
                        'billing_city' => array(
                            'name' => __( 'Billing city:', 'automatorwp-pro' ),
                            'type' => 'text',
                            'classes' => 'automatorwp-col-6',
                            'default' => '',
                        ),
                        'billing_state' => array(
                            'name' => __( 'Billing state/province:', 'automatorwp-pro' ),
                            'type' => 'text',
                            'classes' => 'automatorwp-col-6',
                            'after_row' => 'automatorwp_cmb2_div_clear_cb',
                            'default' => '',
                        ),
                        'billing_postcode' => array(
                            'name' => __( 'Billing postcode:', 'automatorwp-pro' ),
                            'type' => 'text',
                            'classes' => 'automatorwp-col-6',
                            'default' => '',
                        ),
                        'billing_phone' => array(
                            'name' => __( 'Billing phone:', 'automatorwp-pro' ),
                            'type' => 'text',
                            'classes' => 'automatorwp-col-6',
                            'after_row' => 'automatorwp_cmb2_div_clear_cb',
                            'default' => '',
                        ),
                        'billing_shipping_info' => array(
                            'name' => __( 'Use same address for shipping:', 'automatorwp-pro' ),
                            'type' => 'checkbox',
                            'classes' => 'cmb2-switch',
                            'default' => true,
                        ),
                        // Shipping address
                        'shipping_title' => array(
                            'name' => __( 'Shipping Address', 'automatorwp-pro' ),
                            'type' => 'title',
                        ),
                        'shipping_email' => array(
                            'name' => __( 'Shipping email:', 'automatorwp-pro' ),
                            'type' => 'text',
                            'default' => '',
                        ),
                        'shipping_first_name' => array(
                            'name' => __( 'Shipping first name:', 'automatorwp-pro' ),
                            'type' => 'text',
                            'classes' => 'automatorwp-col-6',
                            'default' => '',
                        ),
                        'shipping_last_name' => array(
                            'name' => __( 'Shipping last name:', 'automatorwp-pro' ),
                            'type' => 'text',
                            'classes' => 'automatorwp-col-6',
                            'after_row' => 'automatorwp_cmb2_div_clear_cb',
                            'default' => '',
                        ),
                        'shipping_country' => automatorwp_utilities_ajax_selector_field( array(
                            'field'             => 'shipping_country',
                            'name'              => __( 'Shipping country:', 'automatorwp-pro' ),
                            'option_default'    => __( 'Select a country', 'automatorwp-pro' ),
                            'option_custom'         => true,
                            'option_custom_desc'    => __( 'Country code', 'automatorwp-pro' ),
                            'action_cb'         => 'automatorwp_woocommerce_get_countries',
                            'options_cb'        => 'automatorwp_woocommerce_options_cb_country',
                            'default'           => ''
                        ) ),
                        'shipping_country_custom' => automatorwp_utilities_custom_field( array(
                            'option_custom_desc'    => __( 'Country code', 'automatorwp-pro' ),
                        ) ),
                        'shipping_address_1' => array(
                            'name' => __( 'Shipping address 1:', 'automatorwp-pro' ),
                            'type' => 'text',
                            'classes' => 'automatorwp-col-6',
                            'default' => '',
                        ),
                        'shipping_address_2' => array(
                            'name' => __( 'Shipping address 2:', 'automatorwp-pro' ),
                            'type' => 'text',
                            'classes' => 'automatorwp-col-6',
                            'after_row' => 'automatorwp_cmb2_div_clear_cb',
                            'default' => '',
                        ),
                        'shipping_city' => array(
                            'name' => __( 'Shipping city:', 'automatorwp-pro' ),
                            'type' => 'text',
                            'classes' => 'automatorwp-col-6',
                            'default' => '',
                        ),
                        'shipping_state' => array(
                            'name' => __( 'Shipping state/province:', 'automatorwp-pro' ),
                            'type' => 'text',
                            'classes' => 'automatorwp-col-6',
                            'after_row' => 'automatorwp_cmb2_div_clear_cb',
                            'default' => '',
                        ),
                        'shipping_postcode' => array(
                            'name' => __( 'Shipping postcode:', 'automatorwp-pro' ),
                            'type' => 'text',
                            'classes' => 'automatorwp-col-6',
                            'default' => '',
                        ),
                        'shipping_phone' => array(
                            'name' => __( 'Shipping phone:', 'automatorwp-pro' ),
                            'type' => 'text',
                            'classes' => 'automatorwp-col-6',
                            'after_row' => 'automatorwp_cmb2_div_clear_cb',
                            'default' => '',
                        ),
                        'shipping_method' => array(
                            'name' => __( 'Shipping method:', 'automatorwp-pro' ),
                            'type' => 'select',
                            'classes' => 'automatorwp-col-6',
                            'options_cb' => 'automatorwp_woocommerce_get_shipping_methods', 
                        ),
                        'shipping_cost' => array(
                            'name' => __( 'Shipping cost:', 'automatorwp-pro' ),
                            'desc' => __( 'Leave empty to use the default value set for the shipping method.', 'automatorwp-pro' ),
                            'type' => 'text',
                            'classes' => 'automatorwp-col-6',
                            'after_row' => 'automatorwp_cmb2_div_clear_cb',
                            'default' => '',
                        ),
                    ),
                ),
            ),
        ) );
    }

    /**
     * Action execution function
     *
     * @since 1.0.0
     *
     * @param stdClass  $action         The action object
     * @param int       $user_id        The user ID
     * @param array     $action_options The action's stored options (with tags already passed)
     * @param stdClass  $automation     The action's automation object
     */
    public function execute( $action, $user_id, $action_options, $automation ) {

        // Shorthand billing
        $billing_email = $action_options['billing_email'];
        $billing_first_name = $action_options['billing_first_name'];
		$billing_last_name = $action_options['billing_last_name'];
		$billing_address_1 = $action_options['billing_address_1'];
		$billing_address_2 = $action_options['billing_address_2'];
		$billing_postcode = $action_options['billing_postcode'];
		$billing_city = $action_options['billing_city'];
		$billing_state = $action_options['billing_state'];
		$billing_country = $action_options['billing_country'];
        $billing_phone = $action_options['billing_phone'];
		
        // Shorthand shipping
		$shipping_email = $action_options['shipping_email'];
        $shipping_first_name = $action_options['shipping_first_name'];
        $shipping_last_name = $action_options['shipping_last_name'];
		$shipping_address_1 = $action_options['shipping_address_1'];
		$shipping_address_2 = $action_options['shipping_address_2'];
		$shipping_postcode = $action_options['shipping_postcode'];
		$shipping_city = $action_options['shipping_city'];
		$shipping_state = $action_options['shipping_state'];
		$shipping_country = $action_options['shipping_country'];
        $shipping_phone = $action_options['shipping_phone'];

        // Extra fields
        $payment_method = $action_options['payment_method'];
        $shipping_method = $action_options['shipping_method'];
		$shipping_cost = $action_options['shipping_cost'];
		$order_note = $action_options['order_note'];

        // Get product fields
        $products = $action_options['products'];
        $order_status = $action_options['order_status'];
        $billing_shipping_info = (bool) $action_options['billing_shipping_info'];
        $order_datetime = $action_options['order_datetime'];

        // Discount
        $discount = $action_options['discount'];
        $discount_type = $action_options['discount_type'];
        $coupon_discounts = $action_options['coupon_discount'];
        
        // Billing address
        $billing_address = array(
			'first_name' => $billing_first_name,
			'last_name'  => $billing_last_name,
			'email'      => $billing_email,
			'phone'      => $billing_phone,
			'address_1'  => $billing_address_1,
			'address_2'  => $billing_address_2,
			'city'       => $billing_city,
			'state'      => $billing_state,
			'postcode'   => $billing_postcode,
			'country'    => $billing_country,
		);

        // Shipping address
		$shipping_address = array(
			'first_name' => $shipping_first_name,
			'last_name'  => $shipping_last_name,
			'email'      => $shipping_email,
			'phone'      => $shipping_phone,
			'address_1'  => $shipping_address_1,
			'address_2'  => $shipping_address_2,
			'city'       => $shipping_city,
			'state'      => $shipping_state,
			'postcode'   => $shipping_postcode,
			'country'    => $shipping_country,
		);

        // Get customer
        $customer = get_user_by( 'email', $billing_email );

        // Create the order.
		$order = wc_create_order( array( 'customer_id' => $customer->ID ) );

        // Add note to order
        if ( ! empty( $order_note ) )
		    $order->add_order_note( $order_note );

        // Add products to order
        if ( is_array( $products ) ) {

            foreach( $products as $product ) {

                $product_id = $product['product'];
                $quantity = $product['quantity'];
                $unit_price = $product['unit_price'];

                $wc_product = wc_get_product( $product_id );
        
                if ( $wc_product instanceof WC_Product ) {
					$order->add_product( $wc_product, $quantity );
				}
            }
        }

        // Set order billing address
        $order->set_address( $billing_address, 'billing' );

        // Check to use same billing address for shipping
        if ( $billing_shipping_info ) {
            $order->set_address( $billing_address, 'shipping' );
        } else{
            $order->set_address( $shipping_address, 'shipping' );
        }

        $order->set_payment_method( $payment_method );

        // Update status order
        $order->update_status( $order_status );

        // Assign shipping method.
		$item = new WC_Order_Item_Shipping();

        if ( $shipping_method !== 'free_shipping' ){
            // Add shipping method
            $method = WC_Shipping_Zones::get_shipping_method( $shipping_method );

            // If shipping cost is empty get cost from selected method
            if ( empty( $shipping_cost ) ) {
                $shipping_cost = $method->get_option( 'cost' );
            }

            $item->set_method_title( $method->get_title() );
            $item->set_method_id( $method->id );
            $item->set_total( $shipping_cost );
            
            $order->add_item( $item );
            
        }

        // Add discount code
        if ( is_array( $coupon_discounts ) ) {

            foreach ( $coupon_discounts as $coupon ) {
                $coupon_obj = new WC_Coupon( $coupon['coupon_discount'] );
                $order->apply_coupon( $coupon_obj->get_code() );
            }
            
        }

        // Add discount
        if ( ! empty( $discount ) ) {

            $fee = new WC_Order_Item_Fee();
            
            if ( $discount_type === 'fixed' ) {

                $fee->set_name( __('Discount', 'automatorwp-pro' ) );
            
            } else {

                $subtotal = $order->get_subtotal();
                $percentage = $discount;
                $discount = $subtotal * ( $discount / 100 );
                $fee->set_name( sprintf( __('Discount %d%%', 'automatorwp-pro' ), $percentage ) );
                
            }
            
            $fee->set_amount( $discount * -1 );
            $fee->set_total( $discount * -1 );
            $order->add_item( $fee );
            
        }

        // Set the order date
        if ( !empty( $order_datetime ) ) {
        
            $date = date( 'Y-m-d H:i:s', $order_datetime );
            $order_id = $order->get_id();
            
            wp_update_post( array(
                'ID'            => $order_id,
                'post_date'     => $date,
                'post_date_gmt' => get_gmt_from_date( $date ),
            ) );
        }

        // Calculate total
        $order->calculate_totals( false );
        
    }
        

    /**
     * Register the required hooks
     *
     * @since 1.0.0
     */
    public function hooks() {

        add_filter( 'automatorwp_user_completed_action_log_meta', array( $this, 'log_meta' ), 10, 5 );
        add_filter( 'automatorwp_log_fields', array( $this, 'log_fields' ), 10, 5 );

        parent::hooks();
    }

    /**
     * Action custom log meta
     *
     * @since 1.0.0
     */
    public function log_meta( $log_meta, $action, $user_id, $action_options, $automation ) {

        if ( $action->type !== $this->action ) {
            return $log_meta;
        }

        return $log_meta;
    }

    /**
     * Action custom log fields
     *
     * @since 1.0.0
     */
    public function log_fields( $log_fields, $log, $object ) {

        if ( $log->type !== 'action' ) {
            return $log_fields;
        }

        if ( $object->type !== $this->action ) {
            return $log_fields;
        }


        return $log_fields;
    }

}

new AutomatorWP_WooCommerce_Create_Order();
