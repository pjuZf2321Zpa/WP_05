<?php
/**
 * Add Product Order
 *
 * @package     AutomatorWP\Integrations\WooCommerce\Actions\Add_Product_Order
 * @author      AutomatorWP <contact@automatorwp.com>
 * @since       1.0.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

class AutomatorWP_WooCommerce_Add_Product_Order extends AutomatorWP_Integration_Action {

    public $integration = 'woocommerce';
    public $action = 'woocommerce_add_product_order';

    /**
     * Register the action
     *
     * @since 1.0.0
     */
    public function register() {

        automatorwp_register_action( $this->action, array(
            'integration'   => $this->integration,
            'label'         => __( 'Add a product to an order', 'automatorwp-pro' ),
            'select_option' => __( 'Add a product to <strong>order</strong>', 'automatorwp-pro' ),
            /* translators: %1$s: Product title. %2$s: Order. */
            'edit_label'    => sprintf( __( 'Add a %1$s to %2$s', 'automatorwp-pro' ), '{post}', '{order}' ),
            /* translators: %1$s: Product title. %2$s: Order. */
            'log_label'     => sprintf( __( 'Added a %1$s to %2$s', 'automatorwp-pro' ), '{post}', '{order}' ),
            'options'       => array(
                'post' => array(
                    'default' => __( 'product', 'automatorwp-pro' ),
                    'from'    => 'post_id',
                    'fields'  => array(
                        'post_id' => automatorwp_utilities_post_field( array(
                            'name' => __( 'Product:', 'automatorwp-pro' ),
                            'option_none_label' => __( 'any product', 'automatorwp-pro' ),
                            'post_type' => 'product'
                        ) ),
                        'quantity' => array(
                            'name'        => __( 'Quantity:', 'automatorwp-pro' ),
                            'desc'        => __( 'The product quantity.', 'automatorwp-pro' ),
                            'type'        => 'text',
                            'required'    => true,
                            'attributes' => array(
                                'type' => 'number',
                                'step' => '1',
                                'min'  => '1',
                            ),
                            'default' => 1,
                        ),
                    ),
                ),
                'order' => array(
                    'default' => __( 'an order', 'automatorwp-pro' ),
                    'from'    => 'order_id',
                    'fields'  => array(
                        'order_id' => array(
                            'name'        => __( 'Order ID:', 'automatorwp-pro' ),
                            'desc'        => __( 'The order ID.', 'automatorwp-pro' ),
                            'type'        => 'text',
                            'required'    => true,
                        ),
                    ),
                ),

            ),
        ) );

    }

    /**
     * Action execution function
     *
     * @since 1.0.0
     *
     * @param stdClass  $action         The action object
     * @param int       $user_id        The user ID
     * @param array     $action_options The action's stored options (with tags already passed)
     * @param stdClass  $automation     The action's automation object
     */
    public function execute( $action, $user_id, $action_options, $automation ) {

        // Shorthand
        $order_id = absint( $action_options['order_id'] );
        $product_id = absint( $action_options['post_id'] );
        $quantity = absint( $action_options['quantity'] );

        // Bail if empty order id
        if ( empty( $order_id ) ){
            $this->result = __( 'Order ID cannot be empty', 'gamipress-woocommerce' );
            return;
        }

        if ( empty( $product_id ) ){
            $this->result = __( 'Product cannot be empty', 'gamipress-woocommerce' );
            return;
        }

        // Get the order
        $order = wc_get_order( $order_id );

        if ( ! $order instanceof WC_Order ) {
            $this->result = sprintf( __( 'The order with ID %d could not be found', 'gamipress-woocommerce' ), $order_id );
            return;
        }

        // Get the product
        $product = wc_get_product ( $product_id );

        if ( ! $product instanceof WC_Product ) {
            $this->result = sprintf( __( 'The product with ID %d could not be found', 'gamipress-woocommerce' ), $product_id );
            return;
        }

        // Get the product status
        $product_status = $product->get_status();

        // Bail if product is not published
        if ( $product_status !== 'publish' ){
            $this->result = sprintf( __( 'The product %s is not published', 'gamipress-woocommerce' ), $product->get_title() );
        }

        // Add product to order
        $order->add_product( $product, $quantity );

        $this->result = sprintf( __( 'The product %s was added to order %d', 'gamipress-woocommerce' ), $product->get_title(), $order_id );
    }

    /**
     * Register required hooks
     *
     * @since 1.0.0
     */
    public function hooks() {

        // Log meta data
        add_filter( 'automatorwp_user_completed_action_log_meta', array( $this, 'log_meta' ), 10, 5 );

        // Log fields
        add_filter( 'automatorwp_log_fields', array( $this, 'log_fields' ), 10, 5 );

        parent::hooks();
    }

    /**
     * Action custom log meta
     *
     * @since 1.0.0
     *
     * @param array     $log_meta           Log meta data
     * @param stdClass  $action             The action object
     * @param int       $user_id            The user ID
     * @param array     $action_options     The action's stored options (with tags already passed)
     * @param stdClass  $automation         The action's automation object
     *
     * @return array
     */
    public function log_meta( $log_meta, $action, $user_id, $action_options, $automation ) {

        // Bail if action type don't match this action
        if( $action->type !== $this->action ) {
            return $log_meta;
        }

        // Store result
        $log_meta['result'] = $this->result;

        return $log_meta;
    }

    /**
     * Action custom log fields
     *
     * @since 1.0.0
     *
     * @param array     $log_fields The log fields
     * @param stdClass  $log        The log object
     * @param stdClass  $object     The trigger/action/automation object attached to the log
     *
     * @return array
     */
    public function log_fields( $log_fields, $log, $object ) {

        // Bail if log is not assigned to an action
        if( $log->type !== 'action' ) {
            return $log_fields;
        }

        // Bail if action type don't match this action
        if( $object->type !== $this->action ) {
            return $log_fields;
        }

        $log_fields['result'] = array(
            'name' => __( 'Result:', 'automatorwp-pro' ),
            'type' => 'text',
        );

        return $log_fields;
    }

}

new AutomatorWP_WooCommerce_Add_Product_Order();
