<?php
/**
 * Get Order Details
 *
 * @package     AutomatorWP\Integrations\WooCommerce\Actions\Get_Order_details
 * @author      AutomatorWP <contact@automatorwp.com>
 * @since       1.0.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

class AutomatorWP_WooCommerce_Get_Order_Details extends AutomatorWP_Integration_Action {

    public $integration = 'woocommerce';
    public $action = 'woocommerce_get_oder_details';

    /**
     * Register the action
     *
     * @since 1.0.0
     */
    public function register() {

        automatorwp_register_action( $this->action, array(
            'integration'   => $this->integration,
            'label'         => __( 'Get details from order', 'automatorwp-pro' ),
            'select_option' => __( 'Get details from <strong>order</strong>', 'automatorwp-pro' ),
            /* translators: %1$s: Order. */
            'edit_label'    => sprintf( __( 'Get details from %1$s order', 'automatorwp-pro' ), '{post}' ),
            /* translators: %1$s: Order. */
            'log_label'     => sprintf( __( 'Get details from %1$s order', 'automatorwp-pro' ), '{post}' ),
            'options'       => array(
                'post' => array(
                    'default' => __( 'an order', 'automatorwp-pro' ),
                    'from'    => 'order_id',
                    'fields'  => array(
                        'order_id' => array(
                            'name'        => __( 'Order ID:', 'automatorwp-pro' ),
                            'desc'        => __( 'The order ID.', 'automatorwp-pro' ),
                            'type'        => 'text',
                            'required'    => true,
                        ),

                    ),
                ),

            ),
            'tags' => automatorwp_woocommerce_order_tags(),
        ) );

    }

    /**
     * Action execution function
     *
     * @since 1.0.0
     *
     * @param stdClass  $action         The action object
     * @param int       $user_id        The user ID
     * @param array     $action_options The action's stored options (with tags already passed)
     * @param stdClass  $automation     The action's automation object
     */
    public function execute( $action, $user_id, $action_options, $automation ) {

        // Shorthand
        $order_id = absint( $action_options['order_id'] );

        // Bail if empty order id
        if ( empty( $order_id ) ){
            $this->result = __( 'Order ID cannot be empty', 'gamipress-woocommerce' );
            return;
        }

        // Get the order
        $order = wc_get_order( $order_id );

        if ( ! $order instanceof WC_Order ) {
            $this->result = sprintf( __( 'The order with ID %d could not be found', 'gamipress-woocommerce' ), $order_id );
            return;
        }

        $this->order = $order;
        $this->order_id = $order_id;
        $this->result = sprintf( __( 'Details from order %d', 'gamipress-woocommerce' ), $order_id );
    }

    /**
     * Register required hooks
     *
     * @since 1.0.0
     */
    public function hooks() {

        // Log meta data
        add_filter( 'automatorwp_user_completed_action_log_meta', array( $this, 'log_meta' ), 10, 5 );

        // Log fields
        add_filter( 'automatorwp_log_fields', array( $this, 'log_fields' ), 10, 5 );

        parent::hooks();
    }

    /**
     * Action custom log meta
     *
     * @since 1.0.0
     *
     * @param array     $log_meta           Log meta data
     * @param stdClass  $action             The action object
     * @param int       $user_id            The user ID
     * @param array     $action_options     The action's stored options (with tags already passed)
     * @param stdClass  $automation         The action's automation object
     *
     * @return array
     */
    public function log_meta( $log_meta, $action, $user_id, $action_options, $automation ) {

        // Bail if action type don't match this action
        if( $action->type !== $this->action ) {
            return $log_meta;
        }

        // Store result
        $log_meta['result'] = $this->result;
        $log_meta['order_id'] = isset( $this->order_id ) ? $this->order_id : 0;

        $log_meta = automatorwp_woocommerce_action_get_order_fields( $this->order, $log_meta );

        return $log_meta;
    }

    /**
     * Action custom log fields
     *
     * @since 1.0.0
     *
     * @param array     $log_fields The log fields
     * @param stdClass  $log        The log object
     * @param stdClass  $object     The trigger/action/automation object attached to the log
     *
     * @return array
     */
    public function log_fields( $log_fields, $log, $object ) {
    
        // Bail if log is not assigned to an action
        if( $log->type !== 'action' ) {
            return $log_fields;
        }

        // Bail if action type don't match this action
        if( $object->type !== $this->action ) {
            return $log_fields;
        }

        $log_fields['result'] = array(
            'name' => __( 'Result:', 'automatorwp-pro' ),
            'type' => 'text',
        );

        $order_fields = automatorwp_woocommerce_order_tags();

        foreach( $order_fields as $order_field_name => $order_field_value ) {
        
            $order_label = $order_field_value['label'];
            $log_fields[$order_field_name] = array(
                'name' => sprintf( __( '%s:', 'automatorwp-pro' ), $order_label ),
                'type' => 'text',
            );
        }

        return $log_fields;
    }

}

new AutomatorWP_WooCommerce_Get_Order_Details();
