<?php
/**
 * Functions
 *
 * @package     AutomatorWP\Integrations\WooCommerce\Functions
 * @author      AutomatorWP <contact@automatorwp.com>, Ruben Garcia <rubengcdev@gmail.com>
 * @since       1.0.0
 */
// Exit if accessed directly
if( !defined( 'ABSPATH' ) ) exit;

/**
 * Helper function to get the address fields
 *
 * @since 1.0.0
 *
 * @return array
 */
function automatorwp_woocommerce_get_address_fields() {

    return array(
        'first_name',
        'last_name',
        'company',
        'address_1',
        'address_2',
        'city',
        'postcode',
        'country',
        'state',
        'phone',
        'email',
    );

}

/**
 * Helper function to get an address field label
 *
 * @since 1.0.0
 *
 * @param string $field
 *
 * @return string
 */
function automatorwp_woocommerce_get_address_field_label( $field ) {

    $labels = array(
        'first_name' => __( 'First name', 'automatorwp-pro' ),
        'last_name' => __( 'Last name', 'automatorwp-pro' ),
        'company' => __( 'Company', 'automatorwp-pro' ),
        'address_1' => __( 'Address line 1', 'automatorwp-pro' ),
        'address_2' => __( 'Address line 2', 'automatorwp-pro' ),
        'city' => __( 'City', 'automatorwp-pro' ),
        'postcode' => __( 'Postcode / ZIP', 'automatorwp-pro' ),
        'country' => __( 'Country / Region', 'automatorwp-pro' ),
        'state' => __( 'State / County', 'automatorwp-pro' ),
        'phone' => __( 'Phone', 'automatorwp-pro' ),
        'email' => __( 'Email', 'automatorwp-pro' ),
    );

    return isset( $labels[$field] ) ? $labels[$field] : '';

}

/**
 * Helper function to get an address field preview
 *
 * @since 1.0.0
 *
 * @param string $field
 *
 * @return string
 */
function automatorwp_woocommerce_get_address_field_preview( $field ) {

    $previews = array(
        'first_name' => __( 'AutomatorWP', 'automatorwp-pro' ),
        'last_name' => __( 'Plugin', 'automatorwp-pro' ),
        'company' => __( 'AutomatorWP Ltd.', 'automatorwp-pro' ),
        'address_1' => __( 'False Street, 123', 'automatorwp-pro' ),
        'address_2' => __( 'First floor, door 2', 'automatorwp-pro' ),
        'city' => __( 'Brooklyn', 'automatorwp-pro' ),
        'postcode' => __( '12345', 'automatorwp-pro' ),
        'country' => __( 'United States', 'automatorwp-pro' ),
        'state' => __( 'New York', 'automatorwp-pro' ),
        'phone' => __( '202-555-1234', 'automatorwp-pro' ),
        'email' => __( 'contact@automatorwp.com', 'automatorwp-pro' ),
    );

    return isset( $previews[$field] ) ? $previews[$field] : '';

}

/**
 * Helper function to compare order statuses
 *
 * @since 1.0.0
 *
 * @param string $status
 * @param string $required_status
 *
 * @return string
 */
function automatorwp_woocommerce_order_status_matches( $status, $required_status ) {

    $status = 'wc-' === substr( $status, 0, 3 ) ? substr( $status, 3 ) : $status;
    $required_status = 'wc-' === substr( $required_status, 0, 3 ) ? substr( $required_status, 3 ) : $required_status;

    // Bail if status doesn't match with the trigger option
    if( $required_status !== 'any' && $status !== $required_status ) {
        return false;
    }

    return true;

}

/**
 * Options callback for select2 fields assigned to variations
 *
 * @since 1.0.0
 *
 * @param stdClass $field
 *
 * @return array
 */
function automatorwp_woocommerce_options_cb_variations( $field ) {

    // Setup vars
    $value = $field->escaped_value;
    $none_value = 'any';
    $none_label = __( 'any variation', 'automatorwp' );
    $options = automatorwp_options_cb_none_option( $field, $none_value, $none_label );

    if( ! empty( $value ) ) {
        if( ! is_array( $value ) ) {
            $value = array( $value );
        }

        foreach( $value as $variation_id ) {

            // Skip option none
            if( $variation_id === $none_value ) {
                continue;
            }

            $options[$variation_id] = automatorwp_woocommerce_get_variation_title( $variation_id );
        }
    }

    return $options;

}

/**
 * Get the variation title
 *
 * @since 1.0.0
 *
 * @param int $variation_id
 *
 * @return string|null
 */
function automatorwp_woocommerce_get_variation_title( $variation_id ) {

    // Empty title if no ID provided
    if( absint( $variation_id ) === 0 ) {
        return '';
    }

    $variation = wc_get_product( $variation_id );
    
    $attributes = $variation->get_attributes();

    return implode( ', ', array_values( $attributes ) );

}

/**
 * Get the variation title
 *
 * @since 1.0.0
 * 
 * @param object $order
 * @param array $log_meta
 *
 * @return string|null
 */
function automatorwp_woocommerce_action_get_order_fields( $order, $log_meta ) {

    $order_fields = automatorwp_woocommerce_order_tags();

    foreach( $order_fields as $order_field_name => $order_field_value ) {
        
        $function_name = str_replace( 'woocommerce_order_', '', $order_field_name );

        // Dynamically, call to a order function to retrieve the tag value
        if( method_exists( $order, 'get_' . $function_name ) ) {
            $log_meta[$order_field_name] = call_user_func( array( $order, 'get_' . $function_name ) );
        }

        // Format values for some tags
        switch( $order_field_name ) {
            case 'woocommerce_order_status':
                $log_meta[$order_field_name] = wc_get_order_status_name( $log_meta[$order_field_name] );
                break;
            case 'woocommerce_order_number':
                $log_meta[$order_field_name] = $order->get_order_number();
                break;
            case 'woocommerce_order_date_created':
            case 'woocommerce_order_date_paid':
                $log_meta[$order_field_name] = ( $log_meta[$order_field_name] ? $log_meta[$order_field_name]->format( 'Y-m-d H:i:s' ) : '' );
                break;
            case 'woocommerce_order_coupon_codes':
                $log_meta[$order_field_name] = implode( ', ', $log_meta[$order_field_name] );
                break;
            case 'woocommerce_order_currency_symbol':
                $log_meta[$order_field_name] = get_woocommerce_currency_symbol( $order->get_currency() );
                break;
            case 'woocommerce_order_billing_country':
            case 'woocommerce_order_shipping_country':
                $log_meta[$order_field_name] = ( isset( WC()->countries->countries[$log_meta[$order_field_name]] ) ) ? WC()->countries->countries[$log_meta[$order_field_name]] : $log_meta[$order_field_name];
                break;
            case 'woocommerce_order_billing_state':
            case 'woocommerce_order_shipping_state':
                // For the state, is required the country
                if( $log_meta[$order_field_name] === 'woocommerce_order_billing_state' ) {
                    $country = $order->get_billing_country();
                } else {
                    $country = $order->get_shipping_country();
                }

                $log_meta[$order_field_name] = ( isset( WC()->countries->states[$country][$log_meta[$order_field_name]] ) ) ? WC()->countries->states[$country][$log_meta[$order_field_name]] : $log_meta[$order_field_name];
                break;
            }
        }

    return $log_meta;

}

/**
 * Get payment methods
 *
 * @since 1.0.0
 * 
 */
function automatorwp_woocommerce_get_payment_methods() {

    $gateways = array();

    $payment_methods = WC()->payment_gateways->payment_gateways();
    
    foreach( $payment_methods as $key => $method ) {

        if ( $method->enabled === 'yes' )
            $gateways[$key] = $method->title;

    }

    return $gateways;
    
}

/**
 * Get shipping methods
 *
 * @since 1.0.0
 * 
 */
function automatorwp_woocommerce_get_shipping_methods() {

    $shipping_methods = array( 'free_shipping' => __( 'Free shipping', 'automatorwp_woocommerce' ) );

    // Bail if class is not available.
	if ( ! class_exists( '\WC_Shipping_Zones' ) ) {
		return array();
	}

	$delivery_zones = WC_Shipping_Zones::get_zones();
	

	if ( ! empty( $delivery_zones ) ) {

        foreach ( $delivery_zones as $zone ) {
            $zone_name = $zone['zone_name'];
            
            foreach ($zone['shipping_methods'] as $method) {
                
                if (  $method->enabled !== 'yes' )
					continue;

                $shipping_methods[$method->instance_id] = $zone_name . ' - ' . $method->method_title;
            }
        }
    }

    return $shipping_methods;
    
}

/**
 * Get the full list of countries codes.
 *
 * @since 1.0.0
 *
 * @return array code => name
 */
function automatorwp_woocommerce_get_countries() {

    return WC()->countries->countries;

}

/**
 * Get countries
 *
 * @since 1.0.0
 * 
 * @param stdClass $field
 *
 * @return array
 */
function automatorwp_woocommerce_options_cb_country( $field ) {

    // Setup vars
    $value = $field->escaped_value;
    $none_value = 'any';
    $none_label = __( 'any country', 'automatorwp-pro' );
    $options = automatorwp_options_cb_none_option( $field, $none_value, $none_label );
    $countries = automatorwp_woocommerce_get_countries();
    
    if( ! empty( $value ) ) {
        if( ! is_array( $value ) ) {
            $value = array( $value );
        }

        foreach( $value as $code ) {

            // Skip option none
            if( $code === $none_value ) {
                continue;
            }
            
            $options[$code] = ( isset( $countries[$code] ) ? $countries[$code] : '' );
        }
    }

    return $options;

}

/**
 * Get products
 *
 * @since 1.0.0
 * 
 * @param stdClass $field
 *
 * @return array
 */
function automatorwp_woocommerce_options_cb_product( $field ) {

    // Setup vars
    $value = $field->escaped_value;
    $none_value = 'any';
    $none_label = __( 'any download', 'automatorwp-pro' );
    $options = automatorwp_options_cb_none_option( $field, $none_value, $none_label );
    
    if( ! empty( $value ) ) {
        if( ! is_array( $value ) ) {
            $value = array( $value );
        }

        foreach( $value as $download_id ) {

            // Skip option none
            if( $download_id === $none_value ) {
                continue;
            }
            
            $options[$download_id] = automatorwp_woocommerce_get_product_name( $download_id );
        }
    }

    return $options;

}

/**
 * Get Products
 *
 * @since 1.0.0
 *
 * @return array|false
 */
function automatorwp_woocommerce_get_products() {

    $products = array();

    $all_products = wc_get_products( array(
        'limit' => -1,
        'status' => 'publish',
    ) );

    foreach ( $all_products as $product ) {
        
        if ( $product->is_type( 'variable' ) ) {

            foreach ( $product->get_children() as $variation_id ) {

                $variation = wc_get_product( $variation_id );

                $products[] = array(
                    'id'    => $variation_id,
                    'name'  => $variation->get_name(),
                );
            }

        } else {

            $products[] = array(
                'id'    => $product->get_id(),
                'name'  => $product->get_name(),
            );

        }
    }
 
    return $products;

}

/**
 * Get Product name
 *
 * @since 1.0.0
 *
 * @param int    $product_id         Product ID
 * 
 */
function automatorwp_woocommerce_get_product_name( $product_id ) {

    // Bail if not product ID
    if ( absint( $product_id ) === 0 )
        return '';

    $product = wc_get_product( $product_id );

    return $product->get_name();

}

/**
 * Get coupons
 *
 * @since 1.0.0
 * 
 * @param stdClass $field
 *
 * @return array
 */
function automatorwp_woocommerce_options_cb_coupon( $field ) {

    // Setup vars
    $value = $field->escaped_value;
    $none_value = 'any';
    $none_label = __( 'any coupon', 'automatorwp-pro' );
    $options = automatorwp_options_cb_none_option( $field, $none_value, $none_label );
    
    if( ! empty( $value ) ) {
        if( ! is_array( $value ) ) {
            $value = array( $value );
        }

        foreach( $value as $coupon_id ) {

            // Skip option none
            if( $coupon_id === $none_value ) {
                continue;
            }
            
            $options[$coupon_id] = automatorwp_woocommerce_get_coupon_name( $coupon_id );
        }
    }

    return $options;

}

/**
 * Get coupons
 *
 * @since 1.0.0
 *
 * @return array|false
 */
function automatorwp_woocommerce_get_coupons() {

    $coupons = array();

    $args = array(
        'post_type'   => 'shop_coupon',
        'numberposts' => -1,
        'post_status' => 'publish',
    );

    $results = get_posts( $args );

    foreach ( $results as $coupon ){   

         $coupons[] = array(
                'id'    => $coupon->ID,
                'name'  => $coupon->post_title,
            );
        }
 
    return $coupons;

}

/**
 * Get coupon name
 *
 * @since 1.0.0
 *
 * @param int    $coupon_id         Coupon ID
 * 
 */
function automatorwp_woocommerce_get_coupon_name( $coupon_id ) {

    // Bail if not coupon
    if ( absint( $coupon_id ) === 0 )
        return '';

    $coupon = new WC_Coupon( $coupon_id );
    return $coupon->get_code();

}

/**
 * Display callback for the total order
 *
 * @since  1.0.0
 *
 */
function automatorwp_woocommerce_order_total_display_cb() {

	$currency = get_woocommerce_currency_symbol();

    ?>

    <div class="cmb-row cmb-type-custom table-layout" data-fieldtype="custom">
        <div class="cmb-td" style="padding: 0;">
            <ul style="list-style: none; margin: 0; padding: 0;">
                
                <li class="automatorwp-woocommerce-summary-order">
                    <strong><?php _e( 'Subtotal:', 'automatorwp-pro' ); ?></strong>
                    <div>
                        <span class="automatorwp-woocommerce-currency"><?php echo $currency ?></span>
                        <span class="automatorwp-woocommerce-subtotal">0.00</span>
                    </div>
                </li>
                
                <li class="automatorwp-woocommerce-summary-order">
                    <strong><?php _e( 'Tax:', 'automatorwp-pro' ); ?></strong>
                    <div>
                        <span class="automatorwp-woocommerce-currency-tax"><?php echo $currency ?></span>
                        <span class="automatorwp-woocommerce-tax">0.00</span>
                    </div>
                </li>

                <li class="automatorwp-woocommerce-summary-order">
                    <strong><?php _e( 'Coupon discount:', 'automatorwp-pro' ); ?></strong>
                    <div>
                        <span class="automatorwp-woocommerce-currency"><?php echo $currency ?></span>
                        <span class="automatorwp-woocommerce-coupon-discount">0.00</span>
                    </div>
                </li>

                <li class="automatorwp-woocommerce-summary-order">
                    <strong><?php _e( 'Discount:', 'automatorwp-pro' ); ?></strong>
                    <div>
                        <span class="automatorwp-woocommerce-currency"><?php echo $currency ?></span>
                        <span class="automatorwp-woocommerce-discount">0.00</span>
                    </div>
                </li>
                
                <li class="automatorwp-woocommerce-summary-order">
                    <strong><?php _e( 'Total:', 'automatorwp-pro' ); ?></strong>
                    <div>
                        <span class="automatorwp-woocommerce-currency"><?php echo $currency ?></span>
                        <strong class="automatorwp-woocommerce-total">0.00</strong>
                    </div>
                </li>
                
            </ul>
        </div>
    </div>
    <?php
}