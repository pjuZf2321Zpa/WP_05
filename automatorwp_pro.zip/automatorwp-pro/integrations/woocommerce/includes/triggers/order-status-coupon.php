<?php
/**
 * Order Status Coupon
 *
 * @package     AutomatorWP\Integrations\WooCommerce\Triggers\Order_Status_Coupon
 * @author      AutomatorWP <contact@automatorwp.com>, Ruben Garcia <rubengcdev@gmail.com>
 * @since       1.0.0
 */
// Exit if accessed directly
if( !defined( 'ABSPATH' ) ) exit;

class AutomatorWP_WooCommerce_Order_Status_Coupon extends AutomatorWP_Integration_Trigger {

    public $integration = 'woocommerce';
    public $trigger = 'woocommerce_order_status_coupon';

    /**
     * Register the trigger
     *
     * @since 1.0.0
     */
    public function register() {

        automatorwp_register_trigger( $this->trigger, array(
            'integration'       => $this->integration,
            'label'             => __( 'User\'s order with a coupon code changes its status', 'automatorwp-pro' ),
            'select_option'     => __( 'User\'s order with <strong>a coupon code</strong> changes its <strong>status</strong>', 'automatorwp-pro' ),
            /* translators: %1$s: Post title. %2$s: Order status. %3$s: Number of times. */
            'edit_label'        => sprintf( __( 'User\'s order with %1$s changes its status to %2$s %3$s time(s)', 'automatorwp-pro' ), '{post}', '{status}', '{times}' ),
            /* translators: %1$s: Post title. %2$s: Order status. */
            'log_label'         => sprintf( __( 'User\'s order with %1$s changes its status to %2$s', 'automatorwp-pro' ), '{post}', '{status}' ),
            'action'            => 'woocommerce_order_status_changed',
            'function'          => array( $this, 'listener' ),
            'priority'          => 10,
            'accepted_args'     => 4,
            'options'           => array(
                'post' => automatorwp_utilities_post_option( array(
                    'name' => __( 'Coupon:', 'automatorwp-pro' ),
                    'option_none_label' => __( 'any coupon', 'automatorwp-pro' ),
                    'post_type' => 'shop_coupon'
                ) ),
                'status' => array(
                    'from' => 'status',
                    'fields' => array(
                        'status' => array(
                            'name' => __( 'Status:', 'automatorwp-pro' ),
                            'type' => 'select',
                            'options_cb' => 'wc_get_order_statuses',
                            'default' => 'wc-pending'
                        ),
                    )
                ),
                'times' => automatorwp_utilities_times_option(),
            ),
            'tags' => array_merge(
                automatorwp_woocommerce_order_tags(),
                automatorwp_utilities_times_tag()
            )
        ) );

    }

    /**
     * Trigger listener
     *
     * @since 1.0.0
     *
     * @param int $order_id The order ID
     * @param string $status_from
     * @param string $status_to
     * @param WC_Order $order Order object
     */
    public function listener( $order_id, $status_from, $status_to, $order ) {

        // Bail if status hasn't been changed
        if( $status_from === $status_to ) {
            return;
        }

        // Bail if not a valid order
        if( ! $order ) {
            return;
        }

        $user_id = $order->get_user_id();

        //Bail if not user
        if ( $user_id === 0 ){
            return;
        }

        // Several coupons can be used
        $coupon_ids = array();

        foreach ( $order->get_items('coupon') as $coupon_item ) {
            $code = $coupon_item->get_code();
            $coupon = new WC_Coupon( $code );
            $coupon_id = $coupon->get_id();
            $coupon_ids[] = absint( $coupon_id );
        }

        // Bail if no coupons used
        if ( empty( $coupon_ids ) ) {
            return;
        }

        // Trigger the product purchase
        automatorwp_trigger_event( array(
            'trigger'       => $this->trigger,
            'user_id'       => $user_id,
            'order_id'      => $order_id,
            'status'        => $status_to,
            'coupon_ids'    => $coupon_ids,
        ) );

    }

    /**
     * User deserves check
     *
     * @since 1.0.0
     *
     * @param bool      $deserves_trigger   True if user deserves trigger, false otherwise
     * @param stdClass  $trigger            The trigger object
     * @param int       $user_id            The user ID
     * @param array     $event              Event information
     * @param array     $trigger_options    The trigger's stored options
     * @param stdClass  $automation         The trigger's automation object
     *
     * @return bool                          True if user deserves trigger, false otherwise
     */
    public function user_deserves_trigger( $deserves_trigger, $trigger, $user_id, $event, $trigger_options, $automation ) {

        // Don't deserve if status and post ID are not received
        if( ! isset( $event['status'] ) && ! isset( $event['coupon_ids'] ) ) {
            return false;
        }

        // Don't deserve if coupon doesn't match with the trigger option
        if( $trigger_options['post'] !== 'any' && ! in_array( absint( $trigger_options['post'] ), $event['coupon_ids'] ) ) {
            return false;
        }

        // Don't deserve if status doesn't matches with the trigger option
        if( ! automatorwp_woocommerce_order_status_matches( $event['status'], $trigger_options['status'] ) ) {
            return false;
        }

        return $deserves_trigger;

    }

    /**
     * Register the required hooks
     *
     * @since 1.0.0
     */
    public function hooks() {

        // Log meta data
        add_filter( 'automatorwp_user_completed_trigger_log_meta', array( $this, 'log_meta' ), 10, 6 );

        parent::hooks();
    }

    /**
     * Trigger custom log meta
     *
     * @since 1.0.0
     *
     * @param array     $log_meta           Log meta data
     * @param stdClass  $trigger            The trigger object
     * @param int       $user_id            The user ID
     * @param array     $event              Event information
     * @param array     $trigger_options    The trigger's stored options
     * @param stdClass  $automation         The trigger's automation object
     *
     * @return array
     */
    function log_meta( $log_meta, $trigger, $user_id, $event, $trigger_options, $automation ) {

        // Bail if action type don't match this action
        if( $trigger->type !== $this->trigger ) {
            return $log_meta;
        }

        $log_meta['order_id'] = ( isset( $event['order_id'] ) ? $event['order_id'] : 0 );

        return $log_meta;

    }

}

new AutomatorWP_WooCommerce_Order_Status_Coupon();