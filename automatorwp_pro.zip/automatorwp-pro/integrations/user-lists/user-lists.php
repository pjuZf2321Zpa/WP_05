<?php
/**
 * Plugin Name:           AutomatorWP - User Lists
 * Plugin URI:            https://automatorwp.com/add-ons/user-lists/
 * Description:           Manage your own user lists through AutomatorWP.
 * Version:               1.0.2
 * Author:                AutomatorWP
 * Author URI:            https://automatorwp.com/
 * Text Domain:           automatorwp-user-lists
 * Domain Path:           /languages/
 * Requires at least:     4.4
 * Tested up to:          7.1
 * License:               GNU AGPL v3.0 (http://www.gnu.org/licenses/agpl.txt)
 *
 * @package               AutomatorWP\User Lists
 * @author                AutomatorWP
 * @copyright             Copyright (c) AutomatorWP
 */

final class AutomatorWP_User_Lists {

    /**
     * @var         AutomatorWP_User_Lists $instance The one true AutomatorWP_User_Lists
     * @since       1.0.0
     */
    private static $instance;

    /**
     * Get active instance
     *
     * @access      public
     * @since       1.0.0
     * @return      AutomatorWP_User_Lists self::$instance The one true AutomatorWP_User_Lists
     */
    public static function instance() {
        if( !self::$instance ) {
            self::$instance = new AutomatorWP_User_Lists();
            self::$instance->constants();
            self::$instance->includes();
            self::$instance->hooks();        }

        return self::$instance;
    }

    /**
     * Setup plugin constants
     *
     * @access      private
     * @since       1.0.0
     * @return      void
     */
    private function constants() {
        // Plugin version
        define( 'AUTOMATORWP_USER_LISTS_VER', '1.0.2' );

        // Plugin file
        define( 'AUTOMATORWP_USER_LISTS_FILE', __FILE__ );

        // Plugin path
        define( 'AUTOMATORWP_USER_LISTS_DIR', plugin_dir_path( __FILE__ ) );

        // Plugin URL
        define( 'AUTOMATORWP_USER_LISTS_URL', plugin_dir_url( __FILE__ ) );
    }

    /**
     * Include plugin files
     *
     * @access      private
     * @since       1.0.0
     * @return      void
     */
    private function includes() {

        if( $this->meets_requirements() ) {

            // Includes
            require_once AUTOMATORWP_USER_LISTS_DIR . 'includes/ajax-functions.php';
            require_once AUTOMATORWP_USER_LISTS_DIR . 'includes/custom-tables.php';
            require_once AUTOMATORWP_USER_LISTS_DIR . 'includes/filters.php';
            require_once AUTOMATORWP_USER_LISTS_DIR . 'includes/functions.php';
            require_once AUTOMATORWP_USER_LISTS_DIR . 'includes/user-lists.php';
            require_once AUTOMATORWP_USER_LISTS_DIR . 'includes/scripts.php';
            require_once AUTOMATORWP_USER_LISTS_DIR . 'includes/tags.php';
            require_once AUTOMATORWP_USER_LISTS_DIR . 'includes/users.php';

            // Triggers
            require_once AUTOMATORWP_USER_LISTS_DIR . 'includes/triggers/all-users-list.php';
            require_once AUTOMATORWP_USER_LISTS_DIR . 'includes/triggers/list-added.php';
            require_once AUTOMATORWP_USER_LISTS_DIR . 'includes/triggers/list-removed.php';

            // Actions
            require_once AUTOMATORWP_USER_LISTS_DIR . 'includes/actions/add-user-list.php';
            require_once AUTOMATORWP_USER_LISTS_DIR . 'includes/actions/remove-user-list.php';

            // Filters
            require_once AUTOMATORWP_USER_LISTS_DIR . 'includes/filters/user-is-added-list.php';
            require_once AUTOMATORWP_USER_LISTS_DIR . 'includes/filters/user-is-not-added-list.php';

        }
    }

    /**
     * Setup plugin hooks
     *
     * @access      private
     * @since       1.0.0
     * @return      void
     */
    private function hooks() {

        add_action( 'automatorwp_init', array( $this, 'register_integration' ) );
        
        // Setup our activation and deactivation hooks
        register_activation_hook( __FILE__, array( $this, 'activate' ) );
        register_deactivation_hook( __FILE__, array( $this, 'deactivate' ) );
        

        
    }

    /**
     * Register this integration
     *
     * @access      private
     * @since       1.0.0
     * @return      void
     */
    public function register_integration() {

        // Register the integration
        automatorwp_register_integration( 'user_lists', array(
            'label' => 'User Lists',
            'icon'  => AUTOMATORWP_USER_LISTS_URL . 'assets/img/user-lists.svg',
        ) );

        // Automations
        require_once AUTOMATORWP_USER_LISTS_DIR . 'includes/automations/all-users-list.php';

    }

    /**
     * Activation hook for the plugin.
     *
     * @since  1.0.0
     */
    function activate() {

        if( $this->meets_requirements() ) {

        }

    }

    /**
     * Deactivation hook for the plugin.
     *
     * @since  1.0.0
     */
    function deactivate() {

    }

    /**
     * Check if there are all plugin requirements
     *
     * @since  1.0.0
     *
     * @return bool True if installation meets all requirements
     */
    private function meets_requirements() {

        if ( ! class_exists( 'AutomatorWP' ) ) {
            return false;
        }

        return true;

    }

}

/**
 * The main function responsible for returning the one true AutomatorWP_User_Lists instance to functions everywhere
 *
 * @since       1.0.0
 * @return      \AutomatorWP_User_Lists The one true AutomatorWP_User_Lists
 */
function AutomatorWP_User_Lists() {
    return AutomatorWP_User_Lists::instance();
}
add_action( 'plugins_loaded', 'AutomatorWP_User_Lists' );
