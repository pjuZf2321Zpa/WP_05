<?php
/**
 * Trigger: Purchase Total 
 *
 * @package     AutomatorWP\SureCart\Triggers\Purchase_Total
 * @since       1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class AutomatorWP_SureCart_Purchase_Total extends AutomatorWP_Integration_Trigger {

    public $integration = 'surecart';
    public $trigger     = 'surecart_purchase_total_final_v5'; 

    /**
     * Register the trigger
     */
    public function register() {

        automatorwp_register_trigger( $this->trigger, array(
            'integration'   => $this->integration,
            'label'         => __( 'User completes a purchase with a total greater than, less than or equal to an amount', 'automatorwp-pro' ),
            'select_option' => __( 'User completes a purchase with a total greater than, less than or equal to <strong>an amount</strong>', 'automatorwp-pro' ),
            /* translators: %1$s: Amount. */
            'edit_label'    => sprintf( __( 'User completes a purchase with a total %1$s %2$s %3$s time(s)', 'automatorwp-pro' ), '{condition}', '{amount}', '{times}' ),
            'log_label'     => sprintf( __( 'User completes a purchase with a total %1$s %2$s', 'automatorwp-pro' ), '{condition}', '{amount}' ),
            'action'            => 'surecart/checkout_confirmed',
            'function'          => array( $this, 'listener' ),
            'priority'          => 10,
            'accepted_args'     => 2,
            'options'           => array(
                'condition' => automatorwp_utilities_condition_option(),
                'amount' => array(
                    'from' => 'amount',
                    'fields' => array(
                        'amount' => array(
                            'name' => __( 'Amount:', 'automatorwp-pro' ),
                            'desc' => __( 'The order total required. Support decimals.', 'automatorwp-pro' ),
                            'type' => 'text',
                            'attributes' => array(
                                'type' => 'number',
                                'min' => '0',
                            ),
                            'default' => 0
                        )
                    )
                ),
                'times' => automatorwp_utilities_times_option(),
            ),
        ) );
    }

    /**
     * Trigger listener
     *
     * @since 1.0.0
     *
     * @param array     $purchase
     * 
     */
    public function listener( $checkout, $request ) {
       
        $user_id = get_current_user_id();

        // Bail if user is not logged
        if ($user_id === 0) {
            return;
        }

        $order_total = $checkout->getConvertedTotalAmountAttribute();
        
        // Trigger user product purchased
        automatorwp_trigger_event( array(
            'trigger'       => $this->trigger,
            'user_id'       => $user_id,
            'order_total'   => $order_total,
        ) );
    }

    /**
     * User deserves check
     *
     * @since 1.0.0
     *
     * @param bool      $deserves_trigger   True if user deserves trigger, false otherwise
     * @param stdClass  $trigger            The trigger object
     * @param int       $user_id            The user ID
     * @param array     $event              Event information
     * @param array     $trigger_options    The trigger's stored options
     * @param stdClass  $automation         The trigger's automation object
     *
     * @return bool                          True if user deserves trigger, false otherwise
     */
    public function user_deserves_trigger( $deserves_trigger, $trigger, $user_id, $event, $trigger_options, $automation ) {

        // Don't deserve if order total is not received
        if( ! isset( $event['order_total'] ) ) {
            return false;
        }

        $total = (float) $event['order_total'];
        $required_total =  (float) $trigger_options['amount'];

        // Don't deserve if order total doesn't match with the trigger option
        if( ! automatorwp_number_condition_matches( $total, $required_total, $trigger_options['condition'] ) ) {
            return false;
        }

        return $deserves_trigger;

    }
}

new AutomatorWP_SureCart_Purchase_Total();