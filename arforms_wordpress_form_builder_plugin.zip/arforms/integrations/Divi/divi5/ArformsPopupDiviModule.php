<?php
/**
 * ARForms Popup Divi 5 Module.
 *
 * @package ARForms\PopupDivi
 */

namespace ARForms\PopupDivi;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;

class ArformsPopupDiviModule implements DependencyInterface {

	public function __construct() {
		add_action( 'divi_visual_builder_assets_before_enqueue_scripts', [ $this, 'enqueue_visual_builder_assets' ] );
	}

	/**
	 * Helper to get attribute value (handles D5 responsive objects)
	 */
	private static function get_attr_value($attrs, $name, $default = '') {
		if ( !isset($attrs[$name]) ) return $default;
		$attr = $attrs[$name];
		if ( is_array($attr) ) {
			if ( isset($attr['desktop']['value']) ) return $attr['desktop']['value'];
			if ( isset($attr['value']) ) return $attr['value'];
			$first = reset($attr);
			return (is_array($first) && isset($first['value'])) ? $first['value'] : $first;
		}
		return $attr;
	}

	/**
	 * Render callback for the module (frontend output).
	 *
	 * @param array $attrs
	 * @param string $content
	 * @param object $block
	 * @param array $elements
	 * @return string
	 */
	public static function render_callback($attrs, $content, $block, $elements) {
		$form_id = self::get_attr_value($attrs, 'form_popup_id', '0');
		
		if ( 'Not found' === $form_id || empty($form_id) ) {
			$form_id = '0';
		}

		if ( is_string($form_id) && strpos($form_id, 'form_') === 0 ) {
			$form_id = str_replace('form_', '', $form_id);
		}
		
		if ( empty( $form_id ) || '0' === $form_id ) {
			return '<p>' . esc_html__( 'Please select a form.', 'ARForms' ) . '</p>';
		}

		$arf_trigger_type = self::get_attr_value($attrs, 'arf_trigger_type', 'onclick');
		$arf_click_type = self::get_attr_value($attrs, 'arf_click_type', 'link');
		$arf_scroll_percentage = self::get_attr_value($attrs, 'arf_scroll_percentage', '10');
		$arf_time_interval = self::get_attr_value($attrs, 'arf_time_interval', '0');
		$arf_caption = self::get_attr_value($attrs, 'arf_caption', 'Click here to open Form');
		$arf_background_overlay = self::get_attr_value($attrs, 'arf_background_overlay', '0.6');
		$arf_overlay_color = self::get_attr_value($attrs, 'arf_overlay_color', '#D3D3D3');
		$arf_show_close_button = self::get_attr_value($attrs, 'arf_show_close_button', 'on');
		$arf_image_url = self::get_attr_value($attrs, 'arf_image_url', '');
		$arf_image_height = self::get_attr_value($attrs, 'arf_image_height', 'auto');
		$arf_image_width = self::get_attr_value($attrs, 'arf_image_width', 'auto');
		$arf_size_height = self::get_attr_value($attrs, 'arf_size_height', 'auto');
		$arf_size_width = self::get_attr_value($attrs, 'arf_size_width', '800');
		$arf_background_color = self::get_attr_value($attrs, 'arf_background_color', '#000000');
		$arf_text_color = self::get_attr_value($attrs, 'arf_text_color', '#FFFFFF');
		$arf_show_full_screen_popup = self::get_attr_value($attrs, 'arf_show_full_screen_popup', 'off');
		$arf_animation = self::get_attr_value($attrs, 'arf_animation', 'no_animation');
		$arf_link_position = self::get_attr_value($attrs, 'arf_link_position', 'top');
		$arf_button_angle = self::get_attr_value($attrs, 'arf_button_angle', '0');
		$arf_hide_popup_loggedinuser = self::get_attr_value($attrs, 'arf_hide_popup_loggedinuser', 'off');
		$arf_hide_popup_on_mobile = self::get_attr_value($attrs, 'arf_hide_popup_on_mobile', 'off');
		$arf_inactive_minute = self::get_attr_value($attrs, 'arf_inactive_minute', '1');
		$arf_link_class = self::get_attr_value($attrs, 'arf_link_class', '');

		$yes_no_attrs = [
			'arf_show_close_button',
			'arf_show_full_screen_popup',
			'arf_hide_popup_loggedinuser',
			'arf_hide_popup_on_mobile'
		];
		foreach ($yes_no_attrs as $key) {
			$$key = ($$key === 'on') ? 'yes' : 'no';
		}

		$form_shortcode = "";

		switch ($arf_trigger_type) {
			case 'onclick':
				if ($arf_click_type == 'link') {
					$form_shortcode = " [ARForms_popup id=" . $form_id . " desc='" . $arf_caption . "' type='" . $arf_click_type . "' width='" . $arf_size_width . "' modaleffect='" . $arf_animation . "'  is_fullscreen='" . $arf_show_full_screen_popup . "' overlay='" . $arf_background_overlay . "' is_close_link='" . $arf_show_close_button . "' modal_bgcolor='" . $arf_overlay_color . "' arf_hide_popup_loggedinuser='" . $arf_hide_popup_loggedinuser . "' hide_popup_on_mobile='" . $arf_hide_popup_on_mobile . "' ]";
				} else if ($arf_click_type == 'button') {
					$form_shortcode = " [ARForms_popup id=" . $form_id . " desc='" . $arf_caption . "' type='" . $arf_click_type . "' width='" . $arf_size_width . "' modaleffect='" . $arf_animation . "' is_fullscreen='" . $arf_show_full_screen_popup . "' overlay='" . $arf_background_overlay . "' is_close_link='" . $arf_show_close_button . "' bgcolor='" . $arf_background_color . "' txtcolor='" . $arf_text_color . "' modal_bgcolor='" . $arf_overlay_color . "' hide_popup_for_loggedin_user='" . $arf_hide_popup_loggedinuser . "' hide_popup_on_mobile='" . $arf_hide_popup_on_mobile . "' ]";
				} else if ($arf_click_type == 'image') {
					$form_shortcode = " [ARForms_popup id=" . $form_id . " desc='" . $arf_caption . "' type='" . $arf_click_type . "' width='" . $arf_size_width . "' modaleffect='" . $arf_animation . "' is_fullscreen='" . $arf_show_full_screen_popup . "' overlay='" . $arf_background_overlay . "' is_close_link='" . $arf_show_close_button . "' arf_img_url='" . $arf_image_url . "' arf_img_height='" . $arf_image_height . "' arf_img_width='" . $arf_image_width . "' bgcolor='" . $arf_background_color . "' txtcolor='" . $arf_text_color . "' modal_bgcolor='" . $arf_overlay_color . "' hide_popup_for_loggedin_user='" . $arf_hide_popup_loggedinuser . "' hide_popup_on_mobile='" . $arf_hide_popup_on_mobile . "' ]";
				} else if ($arf_click_type == 'sticky') {
					$form_shortcode = " [ARForms_popup id=" . $form_id . " desc='" . $arf_caption . "' type='" . $arf_click_type . "' position='" . $arf_link_position . "' height='" . $arf_size_height . "' width='" . $arf_size_width . "' bgcolor='" . $arf_background_color . "' txtcolor='" . $arf_text_color . "' hide_popup_for_loggedin_user='" . $arf_hide_popup_loggedinuser . "' hide_popup_on_mobile='" . $arf_hide_popup_on_mobile . "' ]";
				} else if ($arf_click_type == 'fly') {
					$form_shortcode = " [ARForms_popup id=" . $form_id . " desc='" . $arf_caption . "' type='" . $arf_click_type . "' position='" . $arf_link_position . "' height='" . $arf_size_height . "' width='" . $arf_size_width . "' angle='" . $arf_button_angle . "' bgcolor='" . $arf_background_color . "' txtcolor='" . $arf_text_color . "' hide_popup_for_loggedin_user='" . $arf_hide_popup_loggedinuser . "' hide_popup_on_mobile='" . $arf_hide_popup_on_mobile . "' ]";
				}
				break;
			case 'onload':
				$form_shortcode = " [ARForms_popup id=" . $form_id . " type='" . $arf_trigger_type . "' width='" . $arf_size_width . "' modaleffect='" . $arf_animation . "' is_fullscreen='" . $arf_show_full_screen_popup . "' overlay='" . $arf_background_overlay . "' is_close_link='" . $arf_show_close_button . "' modal_bgcolor='" . $arf_overlay_color . "' hide_popup_for_loggedin_user='" . $arf_hide_popup_loggedinuser . "' hide_popup_on_mobile='" . $arf_hide_popup_on_mobile . "' ]";
				break;
			case 'scroll':
				$form_shortcode = " [ARForms_popup id=" . $form_id . " type='" . $arf_trigger_type . "' width='" . $arf_size_width . "' modaleffect='" . $arf_animation . "' is_fullscreen='" . $arf_show_close_button . "' on_scroll='" . $arf_scroll_percentage . "' overlay='" . $arf_background_overlay . "' is_close_link='" . $arf_show_close_button . "' modal_bgcolor='" . $arf_overlay_color . "' hide_popup_for_loggedin_user='" . $arf_hide_popup_loggedinuser . "' hide_popup_on_mobile='" . $arf_hide_popup_on_mobile . "' ]";
				break;
			case 'timer':
				$form_shortcode = " [ARForms_popup id=" . $form_id . " on_delay='" . $arf_time_interval . "' type='" . $arf_trigger_type . "' width='" . $arf_size_width . "' modaleffect='" . $arf_animation . "' is_fullscreen='" . $arf_show_full_screen_popup . "' overlay='" . $arf_background_overlay . "' is_close_link='" . $arf_show_close_button . "' bgcolor='" . $arf_background_color . "' txtcolor='" . $arf_text_color . "' modal_bgcolor='" . $arf_overlay_color . "' hide_popup_for_loggedin_user='" . $arf_hide_popup_loggedinuser . "' hide_popup_on_mobile='" . $arf_hide_popup_on_mobile . "' ]";
				break;
			case 'on_exit':
				$form_shortcode = " [ARForms_popup id=" . $form_id . " type='" . $arf_trigger_type . "' width='" . $arf_size_width . "' modaleffect='" . $arf_animation . "' is_fullscreen='" . $arf_show_full_screen_popup . "' is_close_link='" . $arf_show_close_button . "' modal_bgcolor='" . $arf_overlay_color . "' hide_popup_for_loggedin_user='" . $arf_hide_popup_loggedinuser . "' hide_popup_on_mobile='" . $arf_hide_popup_on_mobile . "' ]";
				break;
			case 'on_idle':
				$form_shortcode = " [ARForms_popup id=" . $form_id . " type='" . $arf_trigger_type . "' width='" . $arf_size_width . "' modaleffect='" . $arf_animation . "' is_fullscreen='" . $arf_show_full_screen_popup . "' inactive_min='" . $arf_inactive_minute . "' overlay='" . $arf_background_overlay . "' is_close_link='" . $arf_show_close_button . "' bgcolor='" . $arf_background_color . "' txtcolor='" . $arf_text_color . "' modal_bgcolor='" . $arf_overlay_color . "' hide_popup_for_loggedin_user='" . $arf_hide_popup_loggedinuser . "' hide_popup_on_mobile='" . $arf_hide_popup_on_mobile . "' ]";
				break;
		}

		// Append class attribute for link, button, and image
		if ( !empty($arf_link_class) && $arf_trigger_type == 'onclick' && in_array($arf_click_type, array('link', 'button', 'image')) ) {
			if ( strpos($form_shortcode, ' ]') !== false ) {
				$form_shortcode = str_replace(' ]', " class='" . esc_attr($arf_link_class) . "' ]", $form_shortcode);
			} else {
				$form_shortcode = str_replace(']', " class='" . esc_attr($arf_link_class) . "' ]", $form_shortcode);
			}
		}
		// error_log('ARForms Divi 5 Module: Form shortcode: ' . $form_shortcode);
		return do_shortcode($form_shortcode);
	}

	/**
	 * Registers the block type via Divi 5's ModuleRegistration API.
	 */
	public function load() {
		// error_log('ARForms Divi 5 Module: Loading module');
		static $loaded = false;
		if ( $loaded ) {
			return;
		}
		$loaded = true;

		$module_json_folder_path = wp_normalize_path( dirname( __FILE__ ) . '/visual-builder' );
		
		$module_json_file = $module_json_folder_path . '/module.json';

		$register_callback = function() use ( $module_json_folder_path ) {
			if ( class_exists( 'ET\Builder\Packages\ModuleLibrary\ModuleRegistration' ) ) {
				// error_log('ARForms Divi 5 Module: Registering module via PHP');
				ModuleRegistration::register_module(
					$module_json_folder_path,
					[
						'render_callback' => [ '\ARForms\PopupDivi\ArformsPopupDiviModule', 'render_callback' ],
					]
				);
			}
		};

		if ( did_action( 'init' ) ) {
			$register_callback();
		} else {
			add_action( 'init', $register_callback );
		}
	}

	/**
	 * Enqueue the bundled JS for the Divi 5 Visual Builder.
	 */
	public function enqueue_visual_builder_assets() {
		$script_src = plugins_url( 'integrations/Divi/divi5/visual-builder/arforms-popup-divi5.js', FORMPATH . '/arforms.php' );
		if ( class_exists( 'ET\Builder\VisualBuilder\Assets\PackageBuildManager' ) ) {
			\ET\Builder\VisualBuilder\Assets\PackageBuildManager::register_package_build(
				[
					'name'    => 'arforms-popup-divi5-visual-builder',
					'version' => '1.0.1',
					'script'  => [
						'src'                => $script_src,
						'deps'               => [
							'divi-module-library',
							'divi-vendor-wp-hooks',
							'react',
							'jquery-core',
							'divi-rest',
							'wp-hooks',
						],
						'enqueue_top_window' => false,
						'enqueue_app_window' => true,
					],
				]
			);
		}

		$forms_list = self::get_forms_list();
		wp_localize_script( 'jquery-core', 'arforms_popup_divi5_data', [
			'arforms_popup_ajax_url'   => admin_url( 'admin-ajax.php' ),
			'nonce'     => wp_create_nonce( 'arflite_wp_nonce' ),
			'arforms_forms_list' => (object) $forms_list,
		] );
	}

	/**
	 * Get the list of ARForms dropdown.
	 *
	 * @return array
	 */
	public static function get_forms_list() {
		global $wpdb, $MdlDb;
		$forms = [];

		$table_name = $MdlDb->forms;
		
		$results = $wpdb->get_results( "SELECT * FROM {$table_name} WHERE is_template = 0 AND (status is NULL OR status = '' OR status = 'published') AND arf_is_lite_form = 0 ORDER BY id DESC" );
		
		$forms['0'] = esc_html__( 'Please select a form', 'ARForms' );

		if ( $results ) {
			foreach ( $results as $form ) {
				$forms['form_' . $form->id] = (string) $form->name . ' (id: ' . $form->id . ')';
			}
		}

		return $forms;
	}
}
