/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
      /******/
    };
    /******/
  })();
/******/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for (var key in definition) {
/******/ 				if (__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
          /******/
        }
        /******/
      }
      /******/
    };
    /******/
  })();
/******/
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
    /******/
  })();
  /******/
  /************************************************************************/

  ;// external ["vendor","wp","hooks"]
  const external_vendor_wp_hooks_namespaceObject = vendor.wp.hooks;
  ;// external ["vendor","React"]
  const external_vendor_React_namespaceObject = vendor.React;
  var external_vendor_React_default = /*#__PURE__*/__webpack_require__.n(external_vendor_React_namespaceObject);
  ;// ./src/modules/arforms-popup-module/edit.jsx

  var ArformsPopupDiviEdit = function (props) {
    var _diviModule = window.divi && window.divi.module || {};
    var _diviModuleUtils = window.divi && window.divi.moduleUtils || {};
    var ModuleContainer = _diviModule.ModuleContainer;
    var getAttrByMode = _diviModuleUtils.getAttrByMode;
    var attrs = props.attrs;
    console.log("Attrs:" + JSON.stringify(attrs));
    var elements = props.elements;
    var id = props.id;
    var name = props.name;
    var statePreview = (0, external_vendor_React_namespaceObject.useState)('');
    var preview = statePreview[0];
    var setPreview = statePreview[1];
    var stateLoading = (0, external_vendor_React_namespaceObject.useState)(false);
    var isLoading = stateLoading[0];
    var setIsLoading = stateLoading[1];
    var formId = getAttrByMode(attrs && attrs.form_popup_id) || '0';
    if (typeof formId === 'string' && formId.indexOf('form_') === 0) {
      formId = formId.replace('form_', '');
    }
    (0, external_vendor_React_namespaceObject.useEffect)(function () {
      if (formId && formId !== '0') {
        setIsLoading(true);
        var formData = new URLSearchParams();
        formData.append('action', 'arforms_popup_divi_preview');
        formData.append('form_popup_id', formId);
        var moduleData = window.arforms_popup_divi5_data || {};
        var nonce = moduleData.nonce || '';
        formData.append('_wpnonce_arfnonce', nonce);
        var ajaxUrl = moduleData.arforms_popup_ajax_url || window.ajaxurl;
        fetch(ajaxUrl, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
          },
          body: formData.toString()
        }).then(function (response) {
          return response.json();
        }).then(function (res) {
          if (res.success) {
            setPreview(res.data);
          } else {
            setPreview('<p>Error loading preview</p>');
          }
          setIsLoading(false);
        }).catch(function (error) {
          setPreview('<p>Error loading form preview.</p>');
          setIsLoading(false);
        });
      } else {
        setPreview('');
      }
    }, [formId]);
    if (!ModuleContainer) {
      return /*#__PURE__*/external_vendor_React_default().createElement('div', null, 'Divi Module Container not found.');
    }
    return /*#__PURE__*/external_vendor_React_default().createElement(ModuleContainer, {
      attrs: attrs,
      elements: elements,
      id: id,
      name: name
    }, /*#__PURE__*/external_vendor_React_default().createElement('div', {
      className: 'et_pb_module_inner'
    }, !formId || formId === '0' ? /*#__PURE__*/external_vendor_React_default().createElement('div', {
      style: {
        padding: '20px',
        border: '1px dashed #ccc',
        textAlign: 'center'
      }
    }, 'Please select a form from the module settings.') : isLoading ? /*#__PURE__*/external_vendor_React_default().createElement('div', {
      style: {
        padding: '20px',
        textAlign: 'center'
      }
    }, 'Loading form preview...') : /*#__PURE__*/external_vendor_React_default().createElement('div', {
      className: 'arforms-popup-divi-form-preview',
      dangerouslySetInnerHTML: {
        __html: preview
      }
    })));
  };
  ;// ./src/modules/arforms-popup-module/module.json
  const module_namespaceObject = /*#__PURE__*/JSON.parse('{"name":"arforms/arformspopupdivi","d4Shortcode":"arforms_divi_popup","title":"ARForms Popup","titles":"ARForms Popup","category":"module","moduleIcon":"arforms-popup-icon","priority":11,"attributes":{"form_popup_id":{"type":"object","default":{"desktop":{"value":"0"}}},"arf_trigger_type":{"type":"object","default":{"desktop":{"value":"onclick"}}},"arf_click_type":{"type":"object","default":{"desktop":{"value":"link"}}},"arf_caption":{"type":"object","default":{"desktop":{"value":"Click here to open Form"}}},"arf_background_overlay":{"type":"object","default":{"desktop":{"value":"0.6"}}},"arf_overlay_color":{"type":"object","default":{"desktop":{"value":"#D3D3D3"}}},"arf_show_close_button":{"type":"object","default":{"desktop":{"value":"on"}}},"arf_image_url":{"type":"object","default":{"desktop":{"value":"0"}}},"arf_image_height":{"type":"object","default":{"desktop":{"value":"auto"}}},"arf_image_width":{"type":"object","default":{"desktop":{"value":"auto"}}},"arf_size_height":{"type":"object","default":{"desktop":{"value":"auto"}}},"arf_size_width":{"type":"object","default":{"desktop":{"value":"800"}}},"arf_background_color":{"type":"object","default":{"desktop":{"value":"#000000"}}},"arf_text_color":{"type":"object","default":{"desktop":{"value":"#FFFFFF"}}},"arf_show_full_screen_popup":{"type":"object","default":{"desktop":{"value":"off"}}},"arf_animation":{"type":"object","default":{"desktop":{"value":"no_animation"}}},"arf_link_position":{"type":"object","default":{"desktop":{"value":"top"}}},"arf_button_angle":{"type":"object","default":{"desktop":{"value":"0"}}},"arf_hide_popup_loggedinuser":{"type":"object","default":{"desktop":{"value":"off"}}},"arf_hide_popup_on_mobile":{"type":"object","default":{"desktop":{"value":"off"}}},"arf_inactive_minute":{"type":"object","default":{"desktop":{"value":"1"}}},"arf_scroll_percentage":{"type":"object","default":{"desktop":{"value":"10"}}},"arf_time_interval":{"type":"object","default":{"desktop":{"value":"0"}}},"arf_link_class":{"type":"object","default":{"desktop":{"value":""}}}}}');
  ;// ./src/modules/arforms-popup-module/settings-content.jsx


  /**
   * Content Settings panel for the ARForms Popup Module.
   */
  var SettingsContent = function (props) {
    var _diviFieldLib = window.divi && window.divi.fieldLibrary || {};
    var _diviModal = window.divi && window.divi.modal || {};
    var _diviModule = window.divi && window.divi.module || {};
    var _diviModuleUtils = window.divi && window.divi.moduleUtils || {};
    var getAttrByMode = _diviModuleUtils.getAttrByMode;
    var Select = _diviFieldLib.Select || SelectContainer;
    var Input = _diviFieldLib.Input || _diviFieldLib.Text;
    var Toggle = _diviFieldLib.Toggle || _diviFieldLib.YesNoButton;
    var ColorPicker = _diviFieldLib.ColorPicker;
    var GroupContainer = _diviModal.GroupContainer;
    var FieldContainer = _diviModule.FieldContainer;
    var _d5Data = window.arforms_popup_divi5_data || {};
    var formsData = _d5Data.arforms_forms_list || {};
    var options = {};
    if (formsData) {
      Object.keys(formsData).forEach(function (key) {
        options[key] = {
          label: String(formsData[key])
        };
      });
    }
    const triggerOptions = {
      onclick: {
        label: 'On Click'
      },
      onload: {
        label: 'On Page Load'
      },
      scroll: {
        label: 'On Page Scroll'
      },
      timer: {
        label: 'On Timer (Scheduled)'
      },
      on_exit: {
        label: 'On Exit (Exit Intent)'
      },
      on_idle: {
        label: 'On Idle'
      }
    };
    const clickTypeOptions = {
      link: {
        label: 'Link'
      },
      button: {
        label: 'Button'
      },
      image: {
        label: 'Image'
      },
      sticky: {
        label: 'Sticky'
      },
      fly: {
        label: 'Fly (Sidebar)'
      }
    };
    const overlayOptions = {
      '0': {
        label: '0 (None)'
      },
      '0.1': {
        label: '10%'
      },
      '0.2': {
        label: '20%'
      },
      '0.3': {
        label: '30%'
      },
      '0.4': {
        label: '40%'
      },
      '0.5': {
        label: '50%'
      },
      '0.6': {
        label: '60%'
      },
      '0.7': {
        label: '70%'
      },
      '0.8': {
        label: '80%'
      },
      '0.9': {
        label: '90%'
      },
      '1': {
        label: '100%'
      }
    };
    const animationOptions = {
      no_animation: {
        label: 'No Animation'
      },
      fade_in: {
        label: 'Fade-In'
      },
      slide_in_top: {
        label: 'Slide In Top'
      },
      slide_in_bottom: {
        label: 'Slide In Bottom'
      },
      slide_in_right: {
        label: 'Slide In Right'
      },
      slide_in_left: {
        label: 'Slide In Left'
      },
      zoom_in: {
        label: 'Zoom In'
      }
    };
    const linkPositionOptions = {
      top: {
        label: 'Top'
      },
      bottom: {
        label: 'Bottom'
      },
      left: {
        label: 'Left'
      },
      right: {
        label: 'Right'
      }
    };
    const buttonAngleOptions = {
      '0': {
        label: '0'
      },
      '90': {
        label: '90'
      },
      '-90': {
        label: '-90'
      }
    };
    var children = [];
    if (GroupContainer && FieldContainer) {
      var triggerType = getAttrByMode(props.attrs && props.attrs.arf_trigger_type) || 'onclick';
      var clickType = getAttrByMode(props.attrs && props.attrs.arf_click_type) || 'link';
      children.push(/*#__PURE__*/external_vendor_React_default().createElement(GroupContainer, {
        id: 'mainContent',
        title: 'Content',
        key: 'mainContent'
      },
        /*#__PURE__*/
        // Form Selection
        external_vendor_React_default().createElement(FieldContainer, {
          attrName: 'form_popup_id',
          label: 'Select Form'
        }, /*#__PURE__*/external_vendor_React_default().createElement(Select, {
          attrName: 'form_popup_id',
          options: options
        })),
        /*#__PURE__*/
        // Trigger Type
        external_vendor_React_default().createElement(FieldContainer, {
          attrName: 'arf_trigger_type',
          label: 'Modal Trigger Type'
        }, /*#__PURE__*/external_vendor_React_default().createElement(Select, {
          attrName: 'arf_trigger_type',
          options: triggerOptions
        })),
        // Click Type (Conditional)
        triggerType === 'onclick' && /*#__PURE__*/external_vendor_React_default().createElement(FieldContainer, {
          attrName: 'arf_click_type',
          label: 'Click Type'
        }, /*#__PURE__*/external_vendor_React_default().createElement(Select, {
          attrName: 'arf_click_type',
          options: clickTypeOptions
        })),
        // Caption
        triggerType === 'onclick' && ['link', 'button', 'sticky', 'fly'].includes(clickType) && /*#__PURE__*/external_vendor_React_default().createElement(FieldContainer, {
          attrName: 'arf_caption',
          label: 'Caption'
        }, /*#__PURE__*/external_vendor_React_default().createElement(Input, {
          attrName: 'arf_caption'
        })),
        // Custom Class
        triggerType === 'onclick' && ['link', 'button', 'image'].includes(clickType) && /*#__PURE__*/external_vendor_React_default().createElement(FieldContainer, {
          attrName: 'arf_link_class',
          label: 'Custom Class'
        }, /*#__PURE__*/external_vendor_React_default().createElement(Input, {
          attrName: 'arf_link_class'
        })),
        // Scroll %
        triggerType === 'scroll' && /*#__PURE__*/external_vendor_React_default().createElement(FieldContainer, {
          attrName: 'arf_scroll_percentage',
          label: 'Scroll Percentage'
        }, /*#__PURE__*/external_vendor_React_default().createElement(Input, {
          attrName: 'arf_scroll_percentage'
        })),
        // Timer Interval
        triggerType === 'timer' && /*#__PURE__*/external_vendor_React_default().createElement(FieldContainer, {
          attrName: 'arf_time_interval',
          label: 'Time Interval (ms)'
        }, /*#__PURE__*/external_vendor_React_default().createElement(Input, {
          attrName: 'arf_time_interval'
        })),
        // Background Overlay
        ['onclick', 'onload', 'scroll', 'timer', 'on_exit', 'on_idle'].includes(triggerType) && /*#__PURE__*/external_vendor_React_default().createElement(FieldContainer, {
          attrName: 'arf_background_overlay',
          label: 'Background Overlay'
        }, /*#__PURE__*/external_vendor_React_default().createElement(Select, {
          attrName: 'arf_background_overlay',
          options: overlayOptions
        })),
        // Overlay Color
        ['onclick', 'onload', 'scroll', 'timer', 'on_exit', 'on_idle'].includes(triggerType) && /*#__PURE__*/external_vendor_React_default().createElement(FieldContainer, {
          attrName: 'arf_overlay_color',
          label: 'Overlay Color'
        }, /*#__PURE__*/external_vendor_React_default().createElement(Input, {
          attrName: 'arf_overlay_color'
        })),
        /*#__PURE__*/
        // Close Button
        external_vendor_React_default().createElement(FieldContainer, {
          attrName: 'arf_show_close_button',
          label: 'Show Close Button'
        }, /*#__PURE__*/external_vendor_React_default().createElement(Toggle, {
          attrName: 'arf_show_close_button'
        })),
        // Image Settings
        triggerType === 'onclick' && clickType === 'image' && [/*#__PURE__*/external_vendor_React_default().createElement(FieldContainer, {
          key: 'img_url',
          attrName: 'arf_image_url',
          label: 'Image URL'
        }, /*#__PURE__*/external_vendor_React_default().createElement(Input, {
          attrName: 'arf_image_url'
        })), /*#__PURE__*/external_vendor_React_default().createElement(FieldContainer, {
          key: 'img_h',
          attrName: 'arf_image_height',
          label: 'Image Height'
        }, /*#__PURE__*/external_vendor_React_default().createElement(Input, {
          attrName: 'arf_image_height'
        })), /*#__PURE__*/external_vendor_React_default().createElement(FieldContainer, {
          key: 'img_w',
          attrName: 'arf_image_width',
          label: 'Image Width'
        }, /*#__PURE__*/external_vendor_React_default().createElement(Input, {
          attrName: 'arf_image_width'
        }))],
        /*#__PURE__*/
        // Popup Size
        external_vendor_React_default().createElement(FieldContainer, {
          attrName: 'arf_size_width',
          label: 'Popup Width'
        }, /*#__PURE__*/external_vendor_React_default().createElement(Input, {
          attrName: 'arf_size_width'
        })), ['image', 'sticky'].includes(clickType) && /*#__PURE__*/external_vendor_React_default().createElement(FieldContainer, {
          attrName: 'arf_size_height',
          label: 'Popup Height'
        }, /*#__PURE__*/external_vendor_React_default().createElement(Input, {
          attrName: 'arf_size_height'
        })),
        // Colors
        ['button', 'sticky', 'fly'].includes(clickType) && [/*#__PURE__*/external_vendor_React_default().createElement(FieldContainer, {
          key: 'bg_color',
          attrName: 'arf_background_color',
          label: 'Background Color'
        }, /*#__PURE__*/external_vendor_React_default().createElement(Input, {
          attrName: 'arf_background_color'
        })), /*#__PURE__*/external_vendor_React_default().createElement(FieldContainer, {
          key: 'txt_color',
          attrName: 'arf_text_color',
          label: 'Text Color'
        }, /*#__PURE__*/external_vendor_React_default().createElement(Input, {
          attrName: 'arf_text_color'
        }))],
        /*#__PURE__*/
        // Full Screen
        external_vendor_React_default().createElement(FieldContainer, {
          attrName: 'arf_show_full_screen_popup',
          label: 'Show Full Screen'
        }, /*#__PURE__*/external_vendor_React_default().createElement(Toggle, {
          attrName: 'arf_show_full_screen_popup'
        })),
        /*#__PURE__*/
        // Animation
        external_vendor_React_default().createElement(FieldContainer, {
          attrName: 'arf_animation',
          label: 'Animation Effect'
        }, /*#__PURE__*/external_vendor_React_default().createElement(Select, {
          attrName: 'arf_animation',
          options: animationOptions
        })),
        // Link Position
        ['fly', 'sticky'].includes(clickType) && /*#__PURE__*/external_vendor_React_default().createElement(FieldContainer, {
          attrName: 'arf_link_position',
          label: 'Link Position'
        }, /*#__PURE__*/external_vendor_React_default().createElement(Select, {
          attrName: 'arf_link_position',
          options: linkPositionOptions
        })),
        // Button Angle
        clickType === 'fly' && /*#__PURE__*/external_vendor_React_default().createElement(FieldContainer, {
          attrName: 'arf_button_angle',
          label: 'Button Angle'
        }, /*#__PURE__*/external_vendor_React_default().createElement(Select, {
          attrName: 'arf_button_angle',
          options: buttonAngleOptions
        })),
        /*#__PURE__*/
        // Hiding options
        external_vendor_React_default().createElement(FieldContainer, {
          attrName: 'arf_hide_popup_loggedinuser',
          label: 'Hide for Logged In User'
        }, /*#__PURE__*/external_vendor_React_default().createElement(Toggle, {
          attrName: 'arf_hide_popup_loggedinuser'
        })), /*#__PURE__*/external_vendor_React_default().createElement(FieldContainer, {
          attrName: 'arf_hide_popup_on_mobile',
          label: 'Hide on Mobile'
        }, /*#__PURE__*/external_vendor_React_default().createElement(Toggle, {
          attrName: 'arf_hide_popup_on_mobile'
        })),
        // Idle time
        triggerType === 'on_idle' && /*#__PURE__*/external_vendor_React_default().createElement(FieldContainer, {
          attrName: 'arf_inactive_minute',
          label: 'Idle Minutes'
        }, /*#__PURE__*/external_vendor_React_default().createElement(Input, {
          attrName: 'arf_inactive_minute'
        }))));
    }
    return /*#__PURE__*/external_vendor_React_default().createElement((external_vendor_React_default()).Fragment, null, children);
  };
  ;// ./src/modules/arforms-popup-module/icon.jsx

  const ArformsIcon = () => /*#__PURE__*/external_vendor_React_default().createElement("svg", {
    width: "56",
    height: "38",
    viewBox: "0 0 56 38",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, /*#__PURE__*/external_vendor_React_default().createElement("path", {
    d: "M55.0126 1.82382L46.7549 29.2255C46.4016 30.2931 46.7107 30.8269 47.5939 30.8269C48.6979 30.8269 50.111 29.9373 51.789 28.1134C51.9215 27.98 52.0098 27.9355 52.1423 27.9355C52.5397 27.9355 52.9813 28.1579 53.467 28.6472C53.9528 29.1366 54.1735 29.5369 54.1735 29.8928C54.1735 30.0262 54.1294 30.0707 54.0852 30.1597C49.8018 35.2308 45.6951 37.8108 41.765 37.8108C39.6454 37.8108 38.5856 36.5653 38.5856 34.0742C38.5856 32.3838 39.1596 30.2931 40.3519 27.8021L39.8662 27.5352C37.5699 30.4266 35.0087 32.8732 32.1384 34.8304C29.3122 36.8322 26.9277 37.8108 25.0289 37.8108C22.9976 37.8108 21.4078 37.0546 20.2156 35.4977C19.0233 33.9852 18.4492 32.0725 18.4492 29.8038C18.4492 24.1544 20.8779 18.1937 25.6912 11.877C30.8578 5.0711 36.3776 1.69037 42.2066 1.69037C43.9287 1.69037 45.386 2.1352 46.5783 2.98038L47.4173 0.934149C47.6381 0.311383 48.4771 0 49.846 0C51.0383 0 52.1864 0.177933 53.3787 0.578283C54.571 1.02312 55.1009 1.42347 55.0126 1.82382ZM45.2093 7.16181C44.3703 5.8718 43.0014 5.20455 41.1026 5.20455C37.4374 5.20455 34.1255 8.45183 31.1669 14.9464C28.7382 20.3733 27.5459 24.8662 27.5459 28.4248C27.5459 29.3145 27.7225 30.1597 28.0758 30.9159C28.4291 31.6721 28.9148 32.0725 29.4447 32.0725C31.4319 32.0725 33.8606 30.1152 36.775 26.2007C39.6895 22.2861 41.8091 18.1492 43.1781 13.7453L45.2093 7.16181Z",
    fill: "#496BDE"
  }), /*#__PURE__*/external_vendor_React_default().createElement("path", {
    d: "M0 16.9435C0.30911 16.1873 0.618221 15.9648 1.45723 15.9648C2.51704 15.9648 3.57685 15.9648 4.63665 15.9648C5.43151 15.9648 5.91726 16.4542 5.91726 17.2549C5.91726 18.4114 5.91726 19.568 5.91726 20.7246C5.91726 21.4363 5.43151 21.9701 4.72497 21.9701C3.57685 21.9701 2.42872 21.9701 1.2806 21.9701C0.618221 21.9701 0.264952 21.6142 0.0441588 21.0359C1.67794e-07 19.7014 0 18.3225 0 16.9435Z",
    fill: "#496BDE"
  }), /*#__PURE__*/external_vendor_React_default().createElement("path", {
    d: "M4.89044 4.62315C5.4645 4.71211 5.90609 5.20143 5.90609 5.77971C5.90609 6.98076 5.90609 8.2263 5.90609 9.42735C5.90609 10.0946 5.37618 10.5839 4.75796 10.5839C3.56568 10.5839 2.3734 10.5839 1.22527 10.5839C0.739528 10.5839 0.386259 10.317 0.165466 9.87218C0.121307 9.78321 0.121307 9.69425 0.0771484 9.64976C0.0771484 8.27078 0.0771484 6.8918 0.0771484 5.51281C0.121307 5.20143 0.253783 4.97901 0.518735 4.7566C0.695369 4.57866 0.960321 4.53418 1.18111 4.53418C2.32924 4.53418 3.52152 4.53418 4.66965 4.53418C4.71381 4.62315 4.80212 4.62315 4.89044 4.62315Z",
    fill: "#496BDE"
  }), /*#__PURE__*/external_vendor_React_default().createElement("path", {
    d: "M0 28.2877C0.0883173 28.2432 0.044159 28.1542 0.0883176 28.0652C0.309111 27.6204 0.618221 27.3535 1.14812 27.3535C2.34041 27.3535 3.57685 27.3535 4.76913 27.3535C5.38735 27.3535 5.8731 27.8873 5.8731 28.5101C5.8731 29.7556 5.8731 30.9567 5.8731 32.2022C5.8731 32.825 5.34319 33.3588 4.72497 33.3588C3.53269 33.3588 2.34041 33.3588 1.14812 33.3588C0.66238 33.3588 0.309111 33.0919 0.0883176 32.647C0.044159 32.5581 0.0441586 32.4691 0 32.4246C0 31.0456 0 29.6666 0 28.2877Z",
    fill: "#496BDE"
  }), /*#__PURE__*/external_vendor_React_default().createElement("path", {
    d: "M9.23244 4.62988C9.40908 4.62988 9.54155 4.62988 9.71819 4.62988C14.664 4.62988 19.6097 4.62988 24.5555 4.62988C24.6438 4.62988 24.7321 4.62988 24.8204 4.62988C25.3503 4.71885 25.6594 5.03023 25.7919 5.51955C25.8361 5.653 25.7919 5.69748 25.7036 5.78645C24.0697 7.16543 22.6567 8.72234 21.4202 10.4572C21.3319 10.5906 21.2436 10.6351 21.1111 10.6351C17.2252 10.6351 13.3392 10.6351 9.40908 10.6351C8.7467 10.6351 8.2168 10.1458 8.2168 9.47856C8.2168 8.23303 8.2168 7.03198 8.2168 5.78645C8.26096 5.20817 8.65838 4.76333 9.23244 4.62988Z",
    fill: "#496BDE"
  }), /*#__PURE__*/external_vendor_React_default().createElement("path", {
    d: "M17.7539 16.0186C17.224 16.9972 16.7382 17.9758 16.385 18.9545C16.0317 19.8886 15.7226 20.8227 15.3693 21.7569C15.281 21.9348 15.2368 22.0238 15.016 22.0238C13.2055 22.0238 11.4392 22.0238 9.62868 22.0238C8.87799 22.0238 8.25977 21.5345 8.25977 20.6448C8.30392 19.5327 8.25977 18.4207 8.25977 17.3086C8.25977 16.5079 8.74551 16.0186 9.54037 16.0186C12.1899 16.0186 14.7952 16.0186 17.4448 16.0186C17.5331 16.0186 17.6214 16.0186 17.7539 16.0186Z",
    fill: "#496BDE"
  }), /*#__PURE__*/external_vendor_React_default().createElement("path", {
    d: "M11.8808 33.3588C11.0859 33.3588 10.2911 33.3588 9.49621 33.3588C8.74551 33.3588 8.25977 32.8694 8.25977 32.1132C8.25977 30.9122 8.25977 29.7556 8.25977 28.5546C8.25977 27.8428 8.74551 27.3535 9.49621 27.3535C10.9534 27.3535 12.4548 27.3535 13.9121 27.3535C14.0887 27.3535 14.177 27.398 14.1329 27.6204C14.0004 29.1773 14.0887 30.7342 14.3978 32.2467C14.442 32.5581 14.5303 32.825 14.6186 33.1363C14.6628 33.3143 14.6628 33.4032 14.442 33.3588C13.5588 33.3588 12.7198 33.3588 11.8808 33.3588Z",
    fill: "#496BDE"
  }));
  ;// ./src/modules/arforms-popup-module/index.js




  const arformsPopupModuleMetadata = module_namespaceObject;
  const arformsPopupModule = {
    renderers: {
      edit: ArformsPopupDiviEdit
    },
    settings: {
      content: SettingsContent
    },
    icon: ArformsIcon
  };
  ;


  const performArformsPopupRegistration = () => {
    const _diviLib = window.divi && window.divi.moduleLibrary || {};
    const registerModule = _diviLib.registerModule || window.divi && window.divi.registerModule;
    if (registerModule && typeof registerModule === 'function') {
      try {
        registerModule(arformsPopupModuleMetadata, arformsPopupModule);
        return true;
      } catch (e) {
        console.error('ARForms Popup Divi 5: [ERROR] Registration failed:', e);
      }
    }
    return false;
  };


  if (!performArformsPopupRegistration()) {

    (0, external_vendor_wp_hooks_namespaceObject.addAction)('divi.moduleLibrary.registerModuleLibraryStore.after', 'arforms-popup-divi5', function () {
      performArformsPopupRegistration();
    });
  }
  ;
})()
  ;