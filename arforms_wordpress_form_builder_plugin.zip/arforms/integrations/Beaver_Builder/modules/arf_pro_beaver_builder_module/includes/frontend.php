<div>
    <?php

     $form_id =!empty( $settings->arf_forms_list ) ? $settings->arf_forms_list : '';  
     $arf_trigger_type =!empty( $settings->arf_trigger_type ) ? $settings->arf_trigger_type : 'onclick';  
     $arf_click_type =!empty( $settings->arf_click_type ) ? $settings->arf_click_type : 'link';  
     $arf_scroll_percentage =!empty( $settings->arf_scroll_percentage ) ? $settings->arf_scroll_percentage : '10';  
     $arf_time_interval =!empty( $settings->arf_time_interval ) ? $settings->arf_time_interval : '0';  
     $arf_caption =!empty( $settings->arf_caption ) ? $settings->arf_caption : 'Click here to open Form';  
     $arf_background_overlay =!empty( $settings->arf_background_overlay ) ? $settings->arf_background_overlay : '0.6';  
     $arf_overlay_color =!empty( $settings->arf_overlay_color ) ? $settings->arf_overlay_color : '#333333'; 
     $arf_show_close_button =!empty( $settings->arf_show_close_button ) ? $settings->arf_show_close_button : 'yes';  
     $arf_image_url =!empty( $settings->arf_image_url ) ? $settings->arf_image_url : '';  
     $arf_image_height =!empty( $settings->arf_image_height ) ? $settings->arf_image_height : 'auto';  
     $arf_image_width =!empty( $settings->arf_image_width ) ? $settings->arf_image_width : 'auto';  
     $arf_size_height =!empty( $settings->arf_size_height ) ? $settings->arf_size_height : 'auto';  
     $arf_size_width =!empty( $settings->arf_size_width ) ? $settings->arf_size_width : '800';  
     $arf_background_color =!empty( $settings->arf_background_color ) ? '#'.$settings->arf_background_color : '#333333';    
     $arf_text_color =!empty( $settings->arf_text_color ) ? '#'.$settings->arf_text_color : '#333333';  
     $arf_show_full_screen_popup =!empty( $settings->arf_show_full_screen_popup ) ? $settings->arf_show_full_screen_popup : 'no';  
     $arf_animation =!empty( $settings->arf_animation ) ? $settings->arf_animation : 'no_animation';  
     $arf_link_position =!empty( $settings->arf_link_position ) ? $settings->arf_link_position : 'top'; 
     $arf_button_angle =!empty( $settings->arf_button_angle ) ? $settings->arf_button_angle : '0';   
     $arf_hide_popup_loggedinuser =!empty( $settings->arf_hide_popup_loggedinuser ) ? $settings->arf_hide_popup_loggedinuser : 'no'; 
     $arf_inactive_minute =!empty( $settings->arf_inactive_minute ) ? $settings->arf_inactive_minute : '1'; 
     
     $arf_hide_popup_on_mobile = !empty( $settings->arf_hide_popup_on_mobile ) ? $settings->arf_hide_popup_on_mobile : 'no';
     $arf_link_class = !empty( $settings->arf_link_class ) ? $settings->arf_link_class : '';

     $form_shortcode="";
     

        switch($arf_trigger_type){
            case 'onclick':
                if( $arf_click_type == 'link' ){
                    $form_shortcode= " [ARForms_popup id=" . $form_id . " desc='" . $arf_caption . "' type='" . $arf_click_type . "' width='" . $arf_size_width . "' modaleffect='".$arf_animation."'  is_fullscreen='".$arf_show_full_screen_popup."' overlay='" . $arf_background_overlay . "' is_close_link='" . $arf_show_close_button . "' modal_bgcolor='" . $arf_overlay_color . "' hide_popup_for_loggedin_user='" .$arf_hide_popup_loggedinuser. "' hide_popup_on_mobile='" . $arf_hide_popup_on_mobile . "' ]";
                } else if( $arf_click_type == 'button' ){
                    $form_shortcode=" [ARForms_popup id=" . $form_id . " desc='" . $arf_caption . "' type='" . $arf_click_type . "' width='" . $arf_size_width . "' modaleffect='".$arf_animation."' is_fullscreen='".$arf_show_full_screen_popup."' overlay='" . $arf_background_overlay . "' is_close_link='" . $arf_show_close_button . "' bgcolor='" . $arf_background_color . "' txtcolor='" . $arf_text_color . "' modal_bgcolor='" . $arf_overlay_color . "' hide_popup_for_loggedin_user='" .$arf_hide_popup_loggedinuser. "' hide_popup_on_mobile='" . $arf_hide_popup_on_mobile . "' ]";
                }
                else if( $arf_click_type == 'image' ){
                    $form_shortcode= " [ARForms_popup id=" . $form_id . " desc='" . $arf_caption . "' type='" . $arf_click_type . "' width='" . $arf_size_width . "' modaleffect='".$arf_animation."' is_fullscreen='".$arf_show_full_screen_popup."' overlay='" . $arf_background_overlay . "' is_close_link='" . $arf_show_close_button . "' arf_img_url='" . $arf_image_url . "' arf_img_height='" . $arf_image_height . "' arf_img_width='" . $arf_image_width . "' bgcolor='" . $arf_background_color . "' txtcolor='" . $arf_text_color . "' modal_bgcolor='" . $arf_overlay_color . "' hide_popup_for_loggedin_user='" .$arf_hide_popup_loggedinuser. "' hide_popup_on_mobile='" . $arf_hide_popup_on_mobile . "' ]"; 
                }
                else if( $arf_click_type == 'sticky' ){
                    $form_shortcode= " [ARForms_popup id=" . $form_id . " desc='" . $arf_caption . "' type='" . $arf_click_type . "' position='" . $arf_link_position . "' height='" . $arf_size_height . "' width='" . $arf_size_width . "' bgcolor='" . $arf_background_color . "' txtcolor='" . $arf_text_color . "' hide_popup_for_loggedin_user='" .$arf_hide_popup_loggedinuser. "' hide_popup_on_mobile='" . $arf_hide_popup_on_mobile . "' ]";
                }
                else if( $arf_click_type == 'fly' ){
                    $form_shortcode= " [ARForms_popup id=" . $form_id . " desc='" . $arf_caption . "' type='" . $arf_click_type . "' position='" . $arf_link_position . "' height='" . $arf_size_height . "' width='" . $arf_size_width . "' angle='" . $arf_button_angle . "' bgcolor='" . $arf_background_color . "' txtcolor='" . $arf_text_color . "' hide_popup_for_loggedin_user='" .$arf_hide_popup_loggedinuser. "' hide_popup_on_mobile='" . $arf_hide_popup_on_mobile . "' ]";
                }
            break;
            case 'onload':
                $form_shortcode=" [ARForms_popup id=" . $form_id . " type='" . $arf_trigger_type . "' width='" . $arf_size_width . "' modaleffect='".$arf_animation."' is_fullscreen='".$arf_show_full_screen_popup."' overlay='" . $arf_background_overlay . "' is_close_link='" . $arf_show_close_button . "' modal_bgcolor='" . $arf_overlay_color . "' hide_popup_for_loggedin_user='" .$arf_hide_popup_loggedinuser. "' hide_popup_on_mobile='" . $arf_hide_popup_on_mobile . "' ]";
            break;
            case 'scroll':
                $form_shortcode=" [ARForms_popup id=" . $form_id . " type='" . $arf_trigger_type . "' width='" . $arf_size_width . "' modaleffect='".$arf_animation."' is_fullscreen='".$arf_show_full_screen_popup."' on_scroll='" . $arf_scroll_percentage . "' overlay='" . $arf_background_overlay . "' is_close_link='" . $arf_show_close_button . "' modal_bgcolor='" . $arf_overlay_color . "' hide_popup_for_loggedin_user='" .$arf_hide_popup_loggedinuser. "' hide_popup_on_mobile='" . $arf_hide_popup_on_mobile . "' ]";
            break;
            case 'timer':
                $form_shortcode=" [ARForms_popup id=" . $form_id . " on_delay='" . $arf_time_interval . "' type='" . $arf_trigger_type . "' width='" . $arf_size_width . "' modaleffect='".$arf_animation."' is_fullscreen='".$arf_show_full_screen_popup."' overlay='" . $arf_background_overlay . "' is_close_link='" . $arf_show_close_button . "' bgcolor='" . $arf_background_color . "' txtcolor='" . $arf_text_color . "' modal_bgcolor='" . $arf_overlay_color . "' hide_popup_for_loggedin_user='" .$arf_hide_popup_loggedinuser. "' hide_popup_on_mobile='" . $arf_hide_popup_on_mobile . "' ]";
            break;
            case 'on_exit':
                $form_shortcode=" [ARForms_popup id=" . $form_id . " type='" . $arf_trigger_type . "' width='" . $arf_size_width . "' modaleffect='".$arf_animation."' is_fullscreen='".$arf_show_full_screen_popup."' is_close_link='" . $arf_show_close_button . "' modal_bgcolor='" . $arf_overlay_color . "' hide_popup_for_loggedin_user='" .$arf_hide_popup_loggedinuser. "' hide_popup_on_mobile='" . $arf_hide_popup_on_mobile . "' ]";
            break;
            case 'on_idle':
                $form_shortcode=" [ARForms_popup id=" . $form_id . " type='" . $arf_trigger_type . "' width='" . $arf_size_width . "' modaleffect='".$arf_animation."' is_fullscreen='".$arf_show_full_screen_popup."' inactive_min='".$arf_inactive_minute."' overlay='" . $arf_background_overlay . "' is_close_link='" . $arf_show_close_button . "' bgcolor='" . $arf_background_color . "' txtcolor='" . $arf_text_color . "' modal_bgcolor='" . $arf_overlay_color . "' hide_popup_for_loggedin_user='" .$arf_hide_popup_loggedinuser. "' hide_popup_on_mobile='" . $arf_hide_popup_on_mobile . "' ]";
            break;
        }

        // Append class attribute for link, button, and image popup triggers
        if( !empty($arf_link_class) && $arf_trigger_type == 'onclick' && in_array($arf_click_type, array('link', 'button', 'image')) ){
            if ( strpos($form_shortcode, ' ]') !== false ) {
                $form_shortcode = str_replace(' ]', " class='".esc_attr($arf_link_class)."' ]", $form_shortcode);
            } else {
                $form_shortcode = str_replace(']', " class='".esc_attr($arf_link_class)."' ]", $form_shortcode);
            }
        }

        echo do_shortcode($form_shortcode);

    ?>
</div>