<?php

require_once FORMPATH .'/core/classes/class.arforms_pro_debug_log.php';

require_once FORMPATH .'/core/classes/class.arforms_pro_settings.php';
require_once FORMPATH .'/core/classes/class.arforms_pro_block_widget.php';

require_once FORMPATH .'/core/classes/class.arforms_pro_beaver_builder.php';
require_once FORMPATH .'/core/classes/class.arforms_popup_divi_module.php';

require_once FORMPATH .'/core/classes/class.arforms_pro_import_export.php';
require_once FORMPATH .'/core/classes/class.arforms_pro_fusion_builder.php';

require_once FORMPATH .'/core/classes/class.arforms_custom_db.php';


require_once(HELPERS_PATH . '/armainhelper.php');


global $armainhelper;
$armainhelper = new armainhelper();

require_once(MODELS_PATH . '/arinstallermodel.php');
require_once(MODELS_PATH . '/arfieldmodel.php');
require_once(MODELS_PATH . '/arformmodel.php');
require_once(MODELS_PATH . '/arrecordmodel.php');
require_once(MODELS_PATH . '/arrecordmeta.php');

global $MdlDb;
global $arffield;
global $arfform;
global $db_record;
global $arfrecordmeta;

global $arfsettings;
global $style_settings;
global $arsettingmodel;

$MdlDb = new arinstallermodel();
$arffield = new arfieldmodel();
$arfform = new arformmodel();
$db_record = new arrecordmodel();
$arfrecordmeta = new arrecordmeta();
$arsettingmodel = new arsettingmodel();

require_once(CONTROLLERS_PATH . '/maincontroller.php');
require_once(CONTROLLERS_PATH . '/arformcontroller.php');
require_once(CONTROLLERS_PATH . '/spamfiltercontroller.php');
require_once(CONTROLLERS_PATH . '/arelementcontroller.php');

global $maincontroller;
global $arformcontroller;
global $spam_filter_controller;
global $arelementcontroller;

$maincontroller = new maincontroller();
$arformcontroller = new arformcontroller();
$spam_filter_controller = new spamfiltercontroller();
$arelementcontroller= new arelementcontroller();

require_once(HELPERS_PATH . '/arrecordhelper.php');
require_once(HELPERS_PATH . '/arformhelper.php');
require_once(MODELS_PATH . '/arnotifymodel.php');

global $arnotifymodel;
$arnotifymodel = new arnotifymodel();

require_once(CONTROLLERS_PATH . "/arrecordcontroller.php");
require_once(CONTROLLERS_PATH . "/arfieldcontroller.php");
require_once(CONTROLLERS_PATH . "/arsettingcontroller.php");
require_once(CONTROLLERS_PATH . "/arsamplecontroller.php");

global $arrecordcontroller;
global $arfieldcontroller;
global $arsettingcontroller;
global $arsamplecontroller;

$arrecordcontroller = new arrecordcontroller();
$arfieldcontroller = new arfieldcontroller();
$arsettingcontroller = new arsettingcontroller();
$arsamplecontroller = new arsamplecontroller();

require_once(HELPERS_PATH . "/arfieldhelper.php");
global $arfieldhelper;
global $arrecordhelper;
global $arformhelper;
$arfieldhelper = new arfieldhelper();
$arrecordhelper = new arrecordhelper();
$arformhelper = new arformhelper();

require_once( CONTROLLERS_PATH . '/arfilecontroller.php' );

global $arfmigratecontroller;
require_once(CONTROLLERS_PATH . "/arfmigratecontroller.php");

$arfmigratecontroller = new arfmigratecontroller();