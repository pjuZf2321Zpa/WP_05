<?php

class arsettingcontroller {

    function __construct() {

        global $pagenow;

        add_action('wp_ajax_delete_aweber', array($this, 'delete_aweber'));

        add_action('wp_ajax_refresh_aweber', array($this, 'refresh_aweber'));

        add_action('wp_ajax_verify_autores', array($this, 'verify_autores'));

        add_action('wp_ajax_delete_autores', array($this, 'delete_autores'));

        add_action('wp_ajax_arf_cc_initiate_oauth', array($this, 'arf_cc_initiate_oauth'));
        add_action('wp_ajax_arf_cc_oauth_callback', array($this, 'arf_cc_oauth_callback'));

        add_action('wp_ajax_arfverifypurchasecode', array($this, 'arfreqact'));

        add_action('wp_ajax_arfdeactivatelicense', array($this, 'arfreqlicdeact'));

        add_action('wp_ajax_arf_install_plugin', array($this, 'arf_install_plugin'));
        add_action('wp_ajax_arf_activate_plugin', array($this, 'arf_activate_plugin'));
        add_action('wp_ajax_arf_deactivate_plugin',array($this, 'arf_deactivate_plugin'));

        add_filter('plugins_api_args', array($this, 'arf_plugin_api_args'), 100000, 2);
        add_filter('plugins_api', array($this, 'arf_plugin_api'), 100000, 3);
        add_filter('plugins_api_result', array($this, 'arf_plugins_api_result'), 100000, 3);
        add_filter('upgrader_package_options', array($this, 'arf_upgrader_package_options'), 100000);
    	add_filter('arf_trim_values',array($this,'arf_array_map'),10,1);

        add_action('activated_plugin',array($this,'arf_is_addon_activated'),10,2 );

        add_action('arf_add_mailchimp_subscriber',array($this,'arf_add_mailchimp_subscriber_callback'),10,5);

        add_action('arf_remove_backup_data', array( $this,'arf_remove_backup_data_callback') );

        add_action( 'wp', array( $this, 'arf_aweber_configuration' ) );


        if( isset( $pagenow ) && ( 'upload.php' == $pagenow || 'admin-ajax.php' == $pagenow ) ){

            add_action( 'pre_get_posts', array( $this, 'arf_refresh_arforms_files_for_media' ) );

            add_filter( 'wp_get_attachment_url', array( $this, 'arf_regenerate_attached_urls' ), 10, 2 );
        }

        add_action( 'arf_addon_page_retrieve_notice', array( $this, 'arf_retrieve_addon_page_notice' ) );

    }

    function arf_retrieve_addon_page_notice(){

        $getNoticeData = get_transient( 'arforms_addon_page_notice' );

        if( false == $getNoticeData ){
            $notice_url = 'https://www.arformsplugin.com/addonlist/arforms_addon_notices.php';

            $getNotice = wp_remote_get(
                $notice_url,
                array(
                    'timeout' => 5000
                )
            );

            if( !is_wp_error( $getNotice ) ){
                $notice_data = wp_remote_retrieve_body( $getNotice );

                set_transient( 'arforms_addon_page_notice', base64_encode( $notice_data ), DAY_IN_SECONDS );

                echo wp_kses_post( $notice_data );
            }
        } else {
            echo wp_kses_post( base64_decode( $getNoticeData ) );
        }

    }

    function arf_regenerate_attached_urls( $url, $attachment_id ){

        global $wpdb, $MdlDb;

        $is_arf_image = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `" . $MdlDb->entry_metas . "` WHERE entry_value = %d OR entry_value LIKE '%|".$attachment_id."%' OR entry_value LIKE '%".$attachment_id."|%' ", $attachment_id ) ); //phpcs:ignore

        if( !empty( $is_arf_image->id ) ){

            $post_meta_data = get_post_meta($attachment_id);

            $attached_file = get_attached_file( $attachment_id );

            $image_array_link = $post_meta_data["_wp_attached_file"][0];

            if( !preg_match( "/wp\-content\/uploads/", $image_array_link ) ){
                $upload_dir = wp_upload_dir();

                $upload_dir_dir = $upload_dir['basedir'];
                $upload_dir_url = $upload_dir['baseurl'];

                if( file_exists( $upload_dir_dir . '/' . $image_array_link ) ){
                    $image_array_link = $upload_dir_url . '/' . $image_array_link;
                }
            }

            if( preg_match( '/http/', $image_array_link ) ){
                $image_array_link = str_replace('thumbs/', '', $image_array_link);
            } else {
                $image_array_link = get_home_url() . "/" . str_replace('thumbs/', '', $image_array_link);
            }

            return $image_array_link;

        } else {
            return $url;
        }
    }

    function arf_refresh_arforms_files_for_media( $query ){

        if( ( isset( $_POST['action'] ) && $_POST['action'] == 'query-attachments' ) || ( isset($_GET['mode'] ) && 'list' == $_GET['mode'] ) ){
            global $arfsettings;
            if( isset($arfsettings->arfdisplayfilesinwpmedia) && ($arfsettings->arfdisplayfilesinwpmedia < 1) ){

                $meta_query = $query->get( 'meta_query' );

                if( !is_array( $meta_query ) ){
                    $meta_query = array();
                }

                $meta_query[] = array(
                    array(
                        'key'  => 'arf_uploaded_file',
                        'value' => 'arforms',
                        'compare' => 'NOT EXISTS'
                    )
                );

                $query->set( 'meta_query', $meta_query );
            }
        }
    }

    function arf_send_test_gmail(){

        global $arnotifymodel;

        $from_to = (isset($_POST['from_to'])) && !empty($_POST['from_to']) ? $_POST['from_to'] : '';
        $send_to = (isset($_POST['send_to'])) && !empty($_POST['send_to']) ? $_POST['send_to'] : '';
        $subject = (isset($_POST['subject']) && !empty($_POST['subject'])) ? $_POST['subject'] : addslashes(esc_html__('GMAIL Test E-Mail', 'ARForms'));
        $message = (isset($_POST['message']) && !empty($_POST['message'])) ? $_POST['message'] : '';
        $reply_to_name = (isset($_POST['reply_to_name']) && !empty($_POST['reply_to_name'])) ? $_POST['reply_to_name'] : '';

        if (empty($send_to) || empty($from_to) || empty($message) || empty($subject)) {
            return;
        }

        echo $arnotifymodel->send_notification_email_user($send_to, $subject, $message, $from_to, $reply_to_name, '', array(), true, true, true, true);

        die();

    }

    function arfreqlicdeact() {
        global $arformcontroller;

        if ( ! current_user_can( 'arfchangesettings' ) ) {
            $response_data['status'] = 'error';
            $response_data['message'] = esc_html__( 'Sorry, you do not have permission to perform this action.', 'ARForms' );
            echo json_encode( $response_data );
            die;
        }

        if ( empty( $_POST['_wpnonce'] ) || ( isset( $_POST['_wpnonce'] ) && '' != $_POST['_wpnonce'] && ! wp_verify_nonce( sanitize_text_field( $_POST['_wpnonce'] ), 'arf_wp_nonce' ) ) ) {
			$response_data['status'] = 'error';
            $response_data['message'] = esc_html__( 'Sorry, your request cannot be processed due to security reason.','ARForms' );
            echo json_encode($response_data);
            die;
		}

        $plugres = $arformcontroller->arfdeactivatelicense();

        if (isset($plugres) && $plugres != "") {
            echo $plugres;
            exit;
        } else {
            echo "Received Blank Response From Server While License Deactivation";
            exit;
        }
        exit;
    }

    function arfreqlicdeactuninst() {
        global $arformcontroller;
        $plugres = $arformcontroller->arfdeactivatelicense();

        return;
    }

    function arfreqact() {
        global $arformcontroller;

        if ( ! current_user_can( 'arfchangesettings' ) ) {
            $response_data['status'] = 'error';
            $response_data['message'] = esc_html__( 'Sorry, you do not have permission to perform this action.', 'ARForms' );
            echo json_encode( $response_data );
            die;
        }

        if ( empty( $_POST['_wpnonce'] ) || ( isset( $_POST['_wpnonce'] ) && '' != $_POST['_wpnonce'] && ! wp_verify_nonce( sanitize_text_field( $_POST['_wpnonce'] ), 'arf_wp_nonce' ) ) ) {
            $response_data['status'] = 'error';
            $response_data['message'] = esc_html__( 'Sorry, your request cannot be processed due to security reason.','ARForms' );
            echo json_encode($response_data);
            die;
		}

        $plugres = $arformcontroller->arfverifypurchasecode();

        if (isset($plugres) && $plugres != "") {
            $responsetext = $plugres;

            if ($responsetext == "License Activated Successfully.") {
                echo "VERIFIED";
                exit;
            } else {
                echo $plugres;
                exit;
            }
        } else {
            echo "Received Blank Response From Server While License Activation";
            exit;
        }
    }

    function generateplugincode() {
        $siteinfo = array();

        global $arnotifymodel, $arfform;

        $siteinfo[] = $arnotifymodel->sitename();
        $siteinfo[] = $arfform->sitedesc();
        $siteinfo[] = home_url();
        $siteinfo[] = get_bloginfo('admin_email');
        $siteinfo[] = $_SERVER['SERVER_ADDR'];

        $newstr = implode("^", $siteinfo);
        $postval = base64_encode($newstr);

        return $postval;
    }

    function route() {

        global $arsettingcontroller;
        if (isset($_REQUEST['page']) && $_REQUEST['page'] == 'ARForms-import-export') {
            return $arsettingcontroller->import_export_form();
        } else if (isset($_REQUEST['page']) && $_REQUEST['page'] == 'ARForms-addons') {

            if (file_exists(VIEWS_PATH . '/addon_lists.php')) {
                include( VIEWS_PATH . '/addon_lists.php' );
            }
        } else if (isset($_REQUEST['page']) && $_REQUEST['page'] == 'ARForms-license') {

            if (file_exists(VIEWS_PATH . '/license_activation.php')) {
                include( VIEWS_PATH . '/license_activation.php' );
            }
        } else if (isset($_REQUEST['page']) && $_REQUEST['page'] == 'ARForms-popups'){
            if(file_exists(VIEWS_PATH . '/arf_forms_popup.php')){
                include(VIEWS_PATH . '/arf_forms_popup.php');
            }
        } else {
            $action = isset($_REQUEST['arfaction']) ? 'arfaction' : 'action';


            global $armainhelper, $arsettingcontroller;

            $cur_tab = isset($_REQUEST['arfcurrenttab']) ? $_REQUEST['arfcurrenttab'] : '';

            $action = $armainhelper->get_param($action);


            if ($action == 'process-form')
                return $arsettingcontroller->process_form($cur_tab);
            else
                return $arsettingcontroller->display_form();
        }
    }

    function getdeactlicurl() {
        $deactlicurl = "https://www.reputeinfosystems.com/tf/plugins/arforms/verify/deactivelicwc.php";

        return $deactlicurl;
    }
	
	function getdeactlicurl_wssl() {
        $deactlicurl = "https://www.reputeinfosystems.com/tf/plugins/arforms/verify/deactivelicwc.php";

        return $deactlicurl;
    }

    function display_form() {


        global $arfsettings, $arfajaxurl, $wpdb, $arfform, $armainhelper, $MdlDb;


        $arfroles = $armainhelper->frm_capabilities();





        $uploads = wp_upload_dir();


        $target_path = $uploads['basedir'] . "/arforms/css";


        $sections = apply_filters('arfaddsettingssection', array());



        if (get_option('arf_ar_type') == '') {

            $arr = array(
                'aweber_type' => arf_sanitize_value(1, 'integer'),
                'mailchimp_type' => arf_sanitize_value(1, 'integer'),
                'getresponse_type' => arf_sanitize_value(1, 'integer'),
                'icontact_type' => arf_sanitize_value(1, 'integer'),
                'constant_type' => arf_sanitize_value(1, 'integer'),
            );

            $arr_new = $arr;

            update_option('arf_ar_type', $arr_new);
            
        }


        if (get_option('arforms_current_tab') == '') {

            update_option('arforms_current_tab', arf_sanitize_value('general_settings'));
        }


        //require(VIEWS_PATH . '/settings_form.php');
        require ARFLITE_VIEWS_PATH . '/arflite_settings_form.php';
    }

    function addons_page() {
        global $arsettingcontroller;
        ?><script type="application/javascript" data-cfasync="false">jQuery('#arfsaveformloader').show();</script> <?php
        
        global $arfversion, $MdlDb, $arnotifymodel, $arfform, $arfrecordmeta;
        $bloginformation = array();
        $str = $MdlDb->get_rand_alphanumeric(10);

        if (is_multisite())
            $multisiteenv = "Multi Site";
        else
            $multisiteenv = "Single Site";

        $addon_listing = 1;

        $bloginformation[] = $arnotifymodel->sitename();
        $bloginformation[] = $arfform->sitedesc();
        $bloginformation[] = home_url();
        $bloginformation[] = get_bloginfo('admin_email');
        $bloginformation[] = $arfrecordmeta->wpversioninfo();
        $bloginformation[] = $arfrecordmeta->getlanguage();
        $bloginformation[] = $arfversion;
        $bloginformation[] = $_SERVER['REMOTE_ADDR'];
        $bloginformation[] = $str;
        $bloginformation[] = $multisiteenv;
        $bloginformation[] = $addon_listing;

        $valstring = implode("||", $bloginformation);
        $encodedval = base64_encode($valstring);

    	$urltopost = 'https://www.arformsplugin.com/addonlist/addon_list_new_3.0.php';

        $raw_response = wp_remote_post($urltopost, array(
            'method' => 'POST',
            'timeout' => 45,
            'redirection' => 5,
            'httpversion' => '1.0',
            'blocking' => true,
            'headers' => array(),
            'body' => array('wpversion' => $encodedval, 'user_agent' => $_SERVER['HTTP_USER_AGENT']),
            'cookies' => array()
                )
        );

        if (is_wp_error($raw_response) || $raw_response['response']['code'] != 200) {
            echo "<div class='error_message' style='margin-top:100px; padding:20px;'>" . addslashes(esc_html__("Add-On listing is currently unavailable. Please try again later.", "ARForms")) . "</div>";
        } else {
            $arforms_body_res = base64_decode( $raw_response['body'] );
            if ( ! empty( $arforms_body_res ) ) {
                $arforms_body_res = json_decode( $arforms_body_res, true );                        
                $arforms_addon_list_css = '';

                foreach ( $arforms_body_res as $arforms_body_key => $arforms_body_data_arr ) {
                    foreach ( $arforms_body_data_arr as $arforms_body_data_key => $arforms_body_val ) {

                        $arforms_horizontal_postion = isset($arforms_body_val['addon_icon_horizontal_position'])  ? $arforms_body_val['addon_icon_horizontal_position'] : 0;
                        $addon_icon_vertical_position = isset($arforms_body_val['addon_icon_vertical_position'])  ? $arforms_body_val['addon_icon_vertical_position'] : 0;
                        $addon_icon_slug = isset($arforms_body_val['arf_class'])  ? $arforms_body_val['arf_class'] : '';

                        $arforms_addon_list_css .= '
                            .addon_image.'.$addon_icon_slug.'{
                                background-position: '.$arforms_horizontal_postion.' '.$addon_icon_vertical_position.';
                            }';   
                            
                                
                    }
                }
                
                $arforms_addon_list_css .= '.addon_image{
                    background: url("https://www.arformsplugin.com/addonlist/arf-addons-sprite.webp?ver='.current_time('timestamp').'") 0 0 no-repeat;
                }';

                echo "<style rel='text/stylesheet' id='arf_addon_style'>".$arforms_addon_list_css."</style>";
            }
            echo $arsettingcontroller->arf_display_addons($raw_response['body']);
        }
        ?><script type="application/javascript" data-cfasync="false">jQuery('#arfsaveformloader').hide();</script><?php
    }

    function arf_display_addons($arf_addons = '') {
        
        require(ARFLITE_VIEWS_PATH . '/arflite_view_addons.php');

    }

    function CheckpluginStatus($mypluginsarray, $pluginname, $attr, $purchase_addon, $plugin_type,$install_url) {

        foreach ($mypluginsarray as $pluginarr) {
            $response = "";
            if ($pluginname == $pluginarr[$attr]) {
                if ($pluginarr['is_active'] == 1) {
                    $response = "ACTIVE";
                    $actionurl = $pluginarr["deactivation_url"];
                    $active_action_url = $pluginarr["deactivation_url"];
                    break;
                } else {
                    $response = "NOT ACTIVE";
                    $actionurl = $pluginarr["activation_url"];
                    $active_action_url = $pluginarr["activation_url"];
                    break;
                }
            } else {
                if ($plugin_type == "free") {
                    $response = "NOT INSTALLED FREE";
                    $actionurl = $install_url;
                } else if ($plugin_type == "paid") {
                    $response = "NOT INSTALLED PAID";
                    $actionurl = $install_url;
                }
            }
        }

        global $arformcontroller,$arformsplugin;
        $setvaltolic = $arformcontroller->$arformsplugin();
        $active_plugin_text = esc_html__('Active','ARForms');

        if( $setvaltolic != 1 ){
            $active_plugin_text = esc_html__('Activate License','ARForms');
            $active_action_url = admin_url('admin.php?page=ARForms-license');
        }

        $myicon = "";
        $divclassname = "";
        if ($response == "NOT INSTALLED FREE") {
            $myicon = '<button class="addon_button no_icon" data-action="free_addon_install" data-plugin="' . $pluginname . '" href="javascript:void(0);"><span class="addon_processing_div addon_processing_tick">'.esc_html__('Installed','ARForms').'</span><span class="get_it_a">'.esc_html__('Install','ARForms').'</span><span class="arf_addon_loader"><svg class="arf_circular" viewBox="0 0 60 60"><circle class="path" cx="25px" cy="23px" r="18" fill="none" stroke-width="4" stroke-miterlimit="7"></circle></svg></span></button>';
        } else if ($response == "NOT INSTALLED PAID") {
            $myicon = '<button class="addon_button" onClick="window.open(\'' . $actionurl . '\',\'_blank\')"><span>'.esc_html__('Get It','ARForms').'</span></button>';
        } else if ($response == "ACTIVE") {
            $myicon = '<button class="addon_button no_icon" data-action="deactivate" data-plugin="' . $pluginname . '" href="javascript:void(0);" data-isvalid="'.$setvaltolic.'" data-href=' . $actionurl . '><span class="addon_processing_div addon_processing_tick_deactivation">'.esc_html__('Deactivated','ARForms').'</span><span class="get_it_a">'.esc_html__('Deactivate','ARForms').'</span><span class="arf_addon_loader"><svg class="arf_circular" viewBox="0 0 60 60"><circle class="path" cx="25px" cy="23px" r="18" fill="none" stroke-width="4" stroke-miterlimit="7"></circle></svg></span></button>';
        } else if ($response == "NOT ACTIVE") {
            $myicon = '<button class="addon_button no_icon" data-action="activate" data-plugin="' . $pluginname . '" href="javascript:void(0);" data-isvalid="'.$setvaltolic.'" data-href=' . $active_action_url . '><span class="addon_processing_div addon_processing_tick">'.esc_html__('Activated','ARForms').'</span><span class="get_it_a">'.$active_plugin_text.'</span><span class="arf_addon_loader"><svg class="arf_circular" viewBox="0 0 60 60"><circle class="path" cx="25px" cy="23px" r="18" fill="none" stroke-width="4" stroke-miterlimit="7"></circle></svg></span></button>';
        }
        return $myicon;
    }

    function import_export_form() {
        
        require ARFLITE_VIEWS_PATH . '/arforms_import_export_form.php';
    }

    function process_form($cur_tab = '') {


        global $arfsettings, $arfajaxurl, $wpdb, $MdlDb;


        $errors = array();


        if ($cur_tab == 'autoresponder_settings') {

            
            if (isset($_REQUEST['mailchimp_type']) && $_REQUEST['mailchimp_type'] == 1) {
                $arf_mailchimp_api = isset($_REQUEST['mailchimp_api']) ? $_REQUEST['mailchimp_api'] : '';
                $arf_mailchimp_listid = isset($_REQUEST['mailchimp_listid']) ? $_REQUEST['mailchimp_listid'] : '';
                $wpdb->update($MdlDb->autoresponder, array('responder_api_key' => $arf_mailchimp_api, 'responder_list' => $arf_mailchimp_listid), array('responder_id' => '1'));
            } else {
                $arf_mailchimp_webform = isset($_REQUEST['mailchimp_web_form']) ? $_REQUEST['mailchimp_web_form'] : '';
                $wpdb->update($MdlDb->autoresponder, array('responder_web_form' => $arf_mailchimp_webform), array('responder_id' => '1'));
            }

            if (isset($_REQUEST['aweber_type']) && $_REQUEST['aweber_type'] == 1) {
                $arf_aweber_api = !empty( $_REQUEST['aweber_oauth_code'] ) ? $_REQUEST['aweber_oauth_code'] : '';
                $awe_responder_list = isset($_REQUEST['responder_list']) ? $_REQUEST['responder_list'] : '';
                $wpdb->update($MdlDb->autoresponder, array( 'responder_api_key' => $arf_aweber_api, 'responder_list' => $awe_responder_list), array('responder_id' => '3'));
            } else {
                $arf_aweber_webform = isset($_REQUEST['aweber_web_form']) ? $_REQUEST['aweber_web_form'] : '';
                $wpdb->update($MdlDb->autoresponder, array('responder_web_form' => $arf_aweber_webform), array('responder_id' => '3'));
            }

            if (isset($_REQUEST['getresponse_type']) && $_REQUEST['getresponse_type'] == 1) {
                $arf_getresponse_api = isset($_REQUEST['getresponse_api']) ? $_REQUEST['getresponse_api'] : '';
                $arf_getresponse_list_id = isset($_REQUEST['getresponse_listid']) ? $_REQUEST['getresponse_listid'] : '';
                $wpdb->update($MdlDb->autoresponder, array('responder_api_key' => $arf_getresponse_api, 'responder_list_id' => $arf_getresponse_list_id), array('responder_id' => '4'));
            } else {
                $arf_getresponse_webform = isset($_REQUEST['getresponse_web_form']) ? $_REQUEST['getresponse_web_form'] : '';
                $wpdb->update($MdlDb->autoresponder, array('responder_web_form' => $arf_getresponse_webform), array('responder_id' => '4'));
            }

            if (isset($_REQUEST['icontact_type']) && $_REQUEST['icontact_type'] == 1) {
                $arf_icontact_api = isset($_REQUEST['icontact_api']) ? $_REQUEST['icontact_api'] : '';
                $arf_icontact_username = isset($_REQUEST['icontact_username']) ? $_REQUEST['icontact_username'] : "";
                $arf_icontact_password = isset($_REQUEST['icontact_password']) ? $_REQUEST['icontact_password'] : '';
                $arf_icontact_listname = isset($_REQUEST['icontact_listname']) ? $_REQUEST['icontact_listname'] : '';

                $wpdb->update($MdlDb->autoresponder, array('responder_api_key' => $arf_icontact_api, 'responder_username' => $arf_icontact_username, 'responder_password' => $arf_icontact_password, 'responder_list' => $arf_icontact_listname), array('responder_id' => '8'));
            } else {
                $arf_icontact_webform = isset($_REQUEST['icontact_web_form']) ? $_REQUEST['icontact_web_form'] : '';
                $wpdb->update($MdlDb->autoresponder, array('responder_web_form' => $arf_icontact_webform), array('responder_id' => '8'));
            }


            if (isset($_REQUEST['constant_type']) && $_REQUEST['constant_type'] == 1) {
                            $arf_cc_client_id     = isset($_REQUEST['constant_client_id'])     ? sanitize_text_field($_REQUEST['constant_client_id'])     : '';
                            $arf_cc_client_secret = isset($_REQUEST['constant_client_secret'])  ? sanitize_text_field($_REQUEST['constant_client_secret'])  : '';
                            $arf_responder_list_id = isset($_REQUEST['constant_listname'])      ? sanitize_text_field($_REQUEST['constant_listname'])      : '';

                $wpdb->update($MdlDb->autoresponder, array('responder_api_key'  => $arf_cc_client_id, 'responder_password' => $arf_cc_client_secret, 'responder_list'     => $arf_responder_list_id), array('responder_id' => '9'));
            } else {
                $arf_responder_webform = isset($_REQUEST['constant_web_form']) ? $_REQUEST['constant_web_form'] : '';
                $wpdb->update($MdlDb->autoresponder, array('responder_web_form' => $arf_responder_webform), array('responder_id' => '9'));
            }


            do_action('arf_autoresponder_out_side_email_marketing_tools_update', $_REQUEST);




            $arr = array(
                'aweber_type' => arf_sanitize_value($_REQUEST['aweber_type'], 'integer'),
                'mailchimp_type' => arf_sanitize_value($_REQUEST['mailchimp_type'], 'integer'),
                'getresponse_type' => arf_sanitize_value($_REQUEST['getresponse_type'], 'integer'),
                'icontact_type' => arf_sanitize_value($_REQUEST['icontact_type'], 'integer'),
                'constant_type' => arf_sanitize_value($_REQUEST['constant_type'], 'integer'),
            );

            $arr_new = $arr;


            update_option('arf_ar_type', $arr_new);


            $autores_type = $arr;
        }


        if ($cur_tab == 'general_settings') {

            $arfsettings->update($_POST, $cur_tab);

            $autores_type = get_option('arf_ar_type');
        }

        $autoresponder_all_data_query = $wpdb->get_results("SELECT * FROM " . $MdlDb->autoresponder); //phpcs:ignore
        $mailchimp_data = $autoresponder_all_data_query[0];
        $aweber_data = $autoresponder_all_data_query[2];
        $getresponse_data = $autoresponder_all_data_query[3];
        $icontact_data = $autoresponder_all_data_query[7];
        $constant_data = $autoresponder_all_data_query[8];
        if ($cur_tab != '') {

            update_option('arforms_current_tab', $cur_tab);
        }

        if (empty($errors)) {


            $arfsettings->store($cur_tab);

            $message_notRquireFeild = '';

            if ($cur_tab == 'general_settings') {
                $message = addslashes(esc_html__('General setting saved successfully.', 'ARForms'));
            } elseif ($cur_tab == 'autoresponder_settings') {
                $message = addslashes(esc_html__('Email Marketing Tools setting saved successfully.', 'ARForms'));
            } else {
                $message = addslashes(esc_html__('Settings Saved.', 'ARForms'));
            }

            if (isset($web_form_msg) and $web_form_msg != '')
                $web_form_msg_default = esc_html__('You have made below required fields which may not supported by system.', 'ARForms').'<br>';

            $web_form_msg = ( (isset($web_form_msg_default)) ? $web_form_msg_default : '') . ( (isset($web_form_msg)) ? $web_form_msg : '');

            @$message_notRquireFeild .= $web_form_msg;
        }

        global $armainhelper;
        $arfroles = $armainhelper->frm_capabilities();


        $sections = apply_filters('arfaddsettingssection', array());
        //require(VIEWS_PATH . '/settings_form.php');
        require ARFLITE_VIEWS_PATH . '/arflite_settings_form.php';
    }

    function head() {

        global $armainhelper, $arfversion;

        $customcss = ARFSCRIPTURL . '&amp;controller=settings';

        wp_register_style('custom-css', $customcss, array(), $arfversion);
        $armainhelper->load_styles(array('custom-css'));
        ?>
        <?php
        require(VIEWS_PATH . '/head.php');
    }

    function delete_aweber($atts) {

        global $wpdb, $MdlDb;

        if ( empty( $_POST['arf_validation_nonce'] ) || (isset( $_POST['arf_validation_nonce'] ) && '' != $_POST['arf_validation_nonce'] && ! wp_verify_nonce( sanitize_text_field( $_POST['arf_validation_nonce'] ), 'arf_wp_nonce' )) ) {
            $response_data['status'] = 'error';
            $response_data['message'] = esc_html__( 'Sorry, your request cannot be processed due to security reason.','ARForms' );
            echo json_encode($response_data);
            die;
		}

        if( !current_user_can('arfchangesettings') ){
            $response_data['status'] = 'error';
            $response_data['message'] = esc_html__( 'Sorry, you do not have permission to perform this action.','ARForms' );
            echo json_encode($response_data);
            die;
        }

        $wpdb->update($MdlDb->autoresponder, array('responder_api_key' => '', 'responder_list_id' => '', 'responder_list' => '', 'is_verify' => '0'), array('responder_id' => 3));


        die();
    }

    function arf_aweber_refresh_token( $list_data ){

        $refreshToken = $list_data['refreshToken'];
        $accessToken = $list_data['accessToken'];

        $internal_token = wp_generate_password( 32, false );
        set_transient( 'arf_awb_refresh_' . $internal_token, 1, 60 );

        $post_url = get_home_url().'?arf_page=arfawb_config';

        $refresh_token = wp_remote_post(
            $post_url,
            array(
                'method' => 'POST',
                'timeout' => 45,
                'redirection' => 5,
                'httpversion' => '1.0',
                'blocking' => true,
                'headers' => array(),
                'body' => array(
                    'refresh_code' => true,
                    'refreshToken' => $refreshToken,
                    'accessToken' => $accessToken,
                    'internal_token' => $internal_token,
                ),
                'cookies' => array()
            )
        );

        $updated_list_data  = json_decode($refresh_token['body'],true);

        return $updated_list_data;

    }

    function refresh_aweber($atts) {
        global $wpdb, $arfsiteurl, $MdlDb, $arfform, $maincontroller,$arf_debug_log_id;

        if ( empty( $_POST['arf_validation_nonce'] ) || (isset( $_POST['arf_validation_nonce'] ) && '' != $_POST['arf_validation_nonce'] && ! wp_verify_nonce( sanitize_text_field( $_POST['arf_validation_nonce'] ), 'arf_wp_nonce' )) ) {
            $response_data['status'] = 'error';
            $response_data['message'] = esc_html__( 'Sorry, your request cannot be processed due to security reason.','ARForms' );
            echo json_encode($response_data);
            die;
		}

        if( !current_user_can('arfchangesettings') ){
            $response_data['status'] = 'error';
            $response_data['message'] = esc_html__( 'Sorry, you do not have permission to perform this action.','ARForms' );
            echo json_encode($response_data);
            die;
        }

        $res = $arfform->arf_select_db_data( true, '', $MdlDb->autoresponder, '*', 'WHERE responder_id= %d', array(3));

        $res = $res[0];

        $list_data = arf_pro_maybe_unserialize($res->list_data);

        
        if( $list_data['expires_in'] < time() ){
            $list_data = $this->arf_aweber_refresh_token( $list_data );
        }

        $acc_id = $list_data['acc_id'];

        

        $acc_headers = [
            'User-Agent' => 'AWeber-PHP-code-sample/1.0',
            'Accept' => 'application/json',
            'Authorization' => 'Bearer ' . $list_data['accessToken'],
        ];

        $lists_url = "https://api.aweber.com/1.0/accounts/".$acc_id."/lists";

        $lists_response = wp_remote_get( $lists_url,
            array(
                'method' => 'GET', 
                'headers' => $acc_headers,
                'timeout' => 5000
            )
        );


        $lists_response = json_decode($lists_response['body']);
        $lists_entries = $lists_response->entries;

        $listname = '';
        $listid = '';
        $first_list_id = '';
        $x = 0;
        foreach ($lists_entries as $offset => $list) {
            if( 0 == $x ){
                $first_list_id = $list->id;
            }
            $listname .= $list->name . "|";

            $listid .= $list->id . "|";
            $x++;
        }
        $listingdetails = "";
        if ($listname != "" && $listid != "") {

            $listingdetails = $listname . "-|-" . $listid;
        }

        
        $res = $wpdb->update($MdlDb->autoresponder, array('responder_list_id' => $listingdetails, 'responder_list' => $first_list_id), array('responder_id' => '3'));
        
        ?>
        <div class="sltstandard" style="float:none; display:inline;">
            

                <?php
                $aweber_lists = explode("-|-", $listingdetails);
                $aweber_lists_name = explode("|", $aweber_lists[0]);
                $aweber_lists_id = explode("|", $aweber_lists[1]);

                $i = 0;
                $selected_list_id = '';
                $selected_list_label = '';

                $aweber_responder_list_option = array();

                foreach ($aweber_lists_name as $aweber_lists_name1) {

                    if ($aweber_lists_id[$i] != "") {
                        
                        if ( 0 == $i ) {
                            $selected_list_id = $aweber_lists_id[$i];
                            $selected_list_label = $aweber_lists_name1;
                        }

                        $aweber_responder_list_option[$aweber_lists_id[$i]] = $aweber_lists_name1;

                    } 
                    $i++;
                }

                echo $maincontroller->arf_selectpicker_dom( 'responder_list', 'aweber_listid', '', 'width:400px;', $selected_list_id, array(), $aweber_responder_list_option, false, array(), false, array(), false, array(), true );
            ?>
        </div>
        <?php
        echo '<span id="aweber_refresh" class="frm_refresh_li">'.esc_html__('Refreshed','ARForms').'</span>';
        $arf_success_msg=array(	
			'success' => 'true',
			'message'     =>  esc_html('Aweber Authorization Successfully.','ARForms'),
		);
		
		do_action('arforms_debug_log_entry','aweber_debug_log', 'Aweber Authorization sent response', 'arforms_aweber_data', $arf_success_msg, $arf_debug_log_id);
        die();
    }
 

    function verify_autores($atts) {

        global $wpdb, $MdlDb,$maincontroller,$arf_debug_log_id;

        if ( empty( $_POST['arf_validation_nonce'] ) || (isset( $_POST['arf_validation_nonce'] ) && '' != $_POST['arf_validation_nonce'] && ! wp_verify_nonce( sanitize_text_field( $_POST['arf_validation_nonce'] ), 'arf_wp_nonce' )) ) {
            $response_data['status'] = 'error';
            $response_data['message'] = esc_html__( 'Sorry, your request cannot be processed due to security reason.','ARForms' );
            echo json_encode($response_data);
            die;
		}

        if( !current_user_can('arfchangesettings') ){
            $response_data['status'] = 'error';
            $response_data['message'] = esc_html__( 'Sorry, you do not have permission to perform this action.','ARForms' );
            echo json_encode($response_data);
            die;
        }


        $name = isset($_POST['id']) ? $_POST['id'] : '';

        $api_key = isset($_POST['api_key']) ? $_POST['api_key'] : '';

        $api_secret = isset($_POST['api_secret']) ? $_POST['api_secret'] : '';

        $user = isset($_POST['user']) ? $_POST['user'] :'';

        $pass = isset($_POST['pass']) ? $_POST['pass'] : '';

        $refresh_li = isset($_POST['refresh_li']) ? $_POST['refresh_li'] : '';


        if ($name == 'mailchimp' ){
            global $arf_mcapi_version;
            
            $dataCenter = substr($api_key,strpos($api_key,'-')+1);

            $mailchimp_url = 'https://'.$dataCenter.'.api.mailchimp.com/'.$arf_mcapi_version.'/lists?count=500';
    
            $response = wp_remote_get($mailchimp_url,array(
                'timeout' => '5000',
                'headers' => array(
                    'Authorization' => 'Bearer '. $api_key
                )
            ));

            if( is_wp_error($response) ){
                $errors = $response->get_error_code(); 
                $errors_msg = $response->get_error_message();                
                echo $errors_msg;
                
                $arf_error_msg = array(
                    'success'       => 'false',
                    'message'       =>  $errors_msg,
                );
    
                do_action('arforms_debug_log_entry','mailchimp_debug_log', 'Mailchimp Authorization sent response', 'arforms_mailchimp_data', $arf_error_msg, $arf_debug_log_id);

            } else {

                $mailchimp_list = json_decode($response['body'],true);
                if( empty( $mailchimp_list['lists']) ){
                    $errors_msg = $mailchimp_list['title'] .' - '. $mailchimp_list['detail'];
                    $arf_error_msg = array(
                        'success'       => 'false',
                        'message'       =>  $errors_msg,
                    );

                    if( !empty( $mailchimp_list['status'] )){
                        $arf_error_msg['status'] = $mailchimp_list['status'];
                    }
        
                    do_action('arforms_debug_log_entry','mailchimp_debug_log', 'Mailchimp Authorization sent response', 'arforms_mailchimp_data', $arf_error_msg, $arf_debug_log_id);

                    echo $mailchimp_list['title'];
                    die;
                }
                $list_str = array();

                echo '<div class="sltstandard" style="float:none; display:inline;">';
                $responder_list_option = array();
                $selected_list_label = '';
                $selected_list_id = '';
                $ls = 0;
                foreach ($mailchimp_list['lists'] as $key => $list) {
                    if ($key == 0) {
                        $selected_list_id = $list['id'];
                        $selected_list_label = $list['name'];
                    }
                    $list_str[$ls]['id'] = $list['id'];
                    $list_str[$ls]['name'] = $list['name'];

                    $responder_list_option[$list['id']] = $list['name'];
                    $ls++;
                }

                $wpdb->update(
                    $MdlDb->autoresponder,
                    array(
                        'responder_api_key' => $api_key,
                        'is_verify' => 1,
                        'responder_list_id' => json_encode($list_str)
                    ),
                    array(
                        'responder_id' => 1
                    )
                );

                echo $maincontroller->arf_selectpicker_dom( 'mailchimp_listid', 'mailchimp_listid', '', 'width:400px;', $selected_list_id, array(), $responder_list_option, false, array(), false, array(), false, array(), true );

                echo '</div>';

            if ($refresh_li == 1)
                echo '<span id="mailchimp_refresh" class="frm_refresh_li">'.esc_html__('Refreshed','ARForms').'</span>';
                $arf_success_msg=array(	
                    'success' => 'true',
                    'message'     =>  esc_html('Mailchimp Authorization Successfully','ARForms'),
                );
    
                do_action('arforms_debug_log_entry','mailchimp_debug_log', 'Mailchimp Authorization sent response', 'arforms_mailchimp_data', $arf_success_msg, $arf_debug_log_id);
            }
           
        }


        if ($name == 'getresponse') {
            $camp = $this->arf_get_getresponse_campaign($api_key);
           
            if (isset($camp) && is_array($camp) && count($camp) > 0) {
               
                $camp_ser = maybe_serialize($camp);

                $res = $wpdb->update($MdlDb->autoresponder, array('responder_api_key' => $api_key, 'is_verify' => 1, 'list_data' => $camp_ser), array('responder_id' => 4));

                echo '<div class="sltstandard" style="float:none; display:inline;">';
                $responder_list_option = array();
                $selected_list_label = '';
                $selected_list_id = '';
                foreach ($camp as $list) {
                    $selected_list_id = $list['id'];
                    $selected_list_label = $list['name'];

                    $responder_list_option[$list['id']] = $list['name'];
                }

                echo $maincontroller->arf_selectpicker_dom( 'getresponse_listid', 'getresponse_listid', '', 'width:400px;', $selected_list_id, array(), $responder_list_option, false, array(), false, array(), false, array(), true );

                echo '</div>';
                if ($refresh_li == 1){
                    echo '<span id="getresponse_refresh" class="frm_refresh_li">'.esc_html__('Refreshed','ARForms').'</span>';
                    $arf_success_msg=array(	
                        'success' => 'true',
                        'message'     =>  $camp
                    );
        
                    do_action('arforms_debug_log_entry','getresponse_debug_log', 'GetResponse Authorization sent response', 'arforms_getresponse_data', $arf_success_msg, $arf_debug_log_id);
                }
                
            }else{
                echo $camp;
            }
        }


        if ($name == 'icontact') {

            require_once(AUTORESPONDER_PATH . 'icontact/lib/iContactApi.php');

            iContactApi::getInstance()->setConfig(array(
                'appId' => $api_key,
                'apiPassword' => $pass,
                'apiUsername' => $user
            ));

            $oiContact = iContactApi::getInstance();
            try {
                $lists = $oiContact->getLists();
                
                if (is_array($lists) && count($lists) > 0) {

                    $lists_ser = maybe_serialize($lists);

                    $res = $wpdb->update($MdlDb->autoresponder, array('responder_api_key' => $api_key, 'responder_username' => $user, 'responder_password' => $pass, 'is_verify' => 1, 'responder_list_id' => $lists_ser), array('responder_id' => 8));

                    echo '<div class="sltstandard" style="float:none; display:inline;">';
                    $responder_list_option = array();
                    $selected_list_label = '';
                    $selected_list_id = '';
                    foreach ($lists as $key => $list) {
                        if ($key == 0) {
                            $selected_list_id = $list->listId;
                            $selected_list_label = $list->name;
                        }

                        $responder_list_option[$list->listId] = $list->name;
                    }

                    echo $maincontroller->arf_selectpicker_dom( 'icontact_listname', 'icontact_listname', '', 'width:400px;', $selected_list_id, array(), $responder_list_option, false, array(), false, array(), false, array(), true );
                    echo '</div>';


                    if ($refresh_li == 1) {
                        echo '<span id="icontact_refresh" class="frm_refresh_li">'.esc_html__('Refreshed','ARForms').'</span>';

                        $arf_success_msg=array(	
                            'success' => 'true',
                            'message'     =>  esc_html("Icontact Authorization Successfully","ARForms"),
                        );
            
                        do_action('arforms_debug_log_entry','icontact_debug_log', 'Icontact Authorization sent response',   'arforms_icontact_data', $arf_success_msg, $arf_debug_log_id);
                    }
                } else {
                    $arf_error_msg = array(
                        'success' => 'false',
                        'message' => esc_html__('No lists found or API error. Check credentials.', 'ARForms')
                    );
                    do_action('arforms_debug_log_entry', 'icontact_debug_log', 'No lists or API error', 'arforms_icontact_data', $arf_error_msg, $arf_debug_log_id);
                }
            } catch (Exception $oException) {
                $arf_error_msg=array(	
                    'success' => 'false',
                    'message'     => $oException
                );
    
                do_action('arforms_debug_log_entry','icontact_debug_log', 'Icontact Authorization sent response', 'arforms_icontact_data', $arf_error_msg, $arf_debug_log_id);
                $oiContact->getErrors();
                $oiContact->getLastRequest(); 
                $oiContact->getLastResponse();
            }
        }


        if ($name == 'constant') {
                        try {
                            require_once(AUTORESPONDER_PATH . 'constant_contact/ConstantContactV3.php');

                            $cc_db_row   = $wpdb->get_row("SELECT * FROM {$MdlDb->autoresponder} WHERE responder_id = 9");
                            $cc_client_id     = isset($cc_db_row->responder_api_key)  ? $cc_db_row->responder_api_key  : '';
                            $cc_client_secret = isset($cc_db_row->responder_password) ? $cc_db_row->responder_password : '';

                            if (empty($cc_client_id) || empty($cc_client_secret)) {
                                echo esc_html__('Please save Client ID and Client Secret first, then connect via OAuth2.', 'ARForms');
                                die();
                            }

                            $access_token = $this->arf_cc_get_valid_access_token($cc_db_row, $cc_client_id, $cc_client_secret);

                            if (empty($access_token)) {
                                echo esc_html__('Not connected. Please click "Connect to Constant Contact" to authorise.', 'ARForms');
                                $arf_error_msg = array('success' => 'false', 'message' => 'No access token available');
                                do_action('arforms_debug_log_entry', 'constant_contact_debug_log', 'Constant Contact - No access token', 'arforms_constant_contact_data', $arf_error_msg, $arf_debug_log_id);
                                die();
                            }

                            $redirect_uri = admin_url('admin-ajax.php') . '?action=arf_cc_oauth_callback';
                            $ccV3 = new ConstantContactV3($cc_client_id, $cc_client_secret, $redirect_uri);
                            $lists_response = $ccV3->getLists($access_token);

                            $lists_new = isset($lists_response['lists']) ? $lists_response['lists'] : array();

                            if (is_array($lists_new) && count($lists_new) > 0) {

                                $i = 0;
                                $new_arr = array();
                                $is_exist = '';
                                foreach ($lists_new as $list) {
                                    $list_id   = isset($list['list_id'])   ? $list['list_id']   : '';
                                    $list_name = isset($list['name'])       ? $list['name']       : '';
                                    $new_arr[$i]['id']   = arf_sanitize_value($list_id);
                                    $new_arr[$i]['name'] = arf_sanitize_value($list_name);
                                    $i++;
                                    $is_exist = ($is_exist == '') ? $list_id : $is_exist . ',' . $list_id;
                                }

                                if ($is_exist != '') {
                                    $lists_ser = maybe_serialize($new_arr);
                                    $wpdb->update(
                                        $MdlDb->autoresponder,
                                        array('is_verify' => 1, 'list_data' => $lists_ser),
                                        array('responder_id' => 9)
                                    );

                                    echo '<div class="sltstandard" style="float:none; display:inline;">';
                                    $responder_list_option = array();
                                    $selected_list_label = '';
                                    $selected_list_id = '';
                                    $listid = 0;
                                    foreach ($lists_new as $list) {
                                        $list_id   = isset($list['list_id']) ? $list['list_id'] : '';
                                        $list_name = isset($list['name'])    ? $list['name']    : '';
                                        if ($listid == 0) {
                                            $selected_list_id    = $list_id;
                                            $selected_list_label = $list_name;
                                        }
                                        $responder_list_option[$list_id] = $list_name;
                                        $listid++;
                                    }

                        echo $maincontroller->arf_selectpicker_dom( 'constant_listname', 'constant_listname', '', 'width:400px;', $selected_list_id, array(), $responder_list_option, false, array(), false, array(), false, array(), true );
                        echo '</div>';

                                    if ($refresh_li == 1) {
                                        echo '<span id="constant_refresh" class="frm_refresh_li">' . esc_html__('Refreshed', 'ARForms') . '</span>';
                                    }

                                    $arf_success_msg = array(
                                        'success' => 'true',
                                        'message' => esc_html('Constant Contact Authorization Successful', 'ARForms'),
                                    );
                                    do_action('arforms_debug_log_entry', 'constant_contact_debug_log', 'Constant contact Authorization sent response', 'arforms_constant_contact_data', $arf_success_msg, $arf_debug_log_id);

                                } else {
                                    $arf_error_msg = array('success' => 'false', 'message' => esc_html('Something Went Wrong With Authorization.', 'ARForms'));
                                    do_action('arforms_debug_log_entry', 'constant_contact_debug_log', 'Constant contact Authorization sent response', 'arforms_constant_contact_data', $arf_error_msg, $arf_debug_log_id);
                                }

                            } else {
                                echo esc_html__('No lists found in your Constant Contact account.', 'ARForms');
                            }

                        } catch (Throwable $e) {
                            $error_message = $e->getMessage();
                            $arf_error_msg = array('success' => 'false', 'message' => $error_message);
                            do_action('arforms_debug_log_entry', 'constant_contact_debug_log', 'Constant Contact V3 Verification Failed', 'arforms_constant_contact_data', $arf_error_msg, $arf_debug_log_id);
                            echo esc_html__('Authentication Failed. Please reconnect to Constant Contact.', 'ARForms');
                        }
                    }

        if( 'aweber' == $name ){
            $authorization_code = !empty( $_POST['api_key'] ) ? $_POST['api_key'] : '';

            if( !empty( $authorization_code ) ){
                $aweber_lists = $this->arf_aweber_authorize_app( $authorization_code );

                if( is_array( $aweber_lists ) && count( $aweber_lists ) > 0 ){
                    $list_html = '<div class="sltstandard" style="float:none; display:inline;">';
                    
                        $aweber_lists_name = explode("|", $aweber_lists[0]);
                        $aweber_lists_id = explode("|", $aweber_lists[1]);

                        $i = 0;
                        $selected_list_id = '';
                        $selected_list_label = '';

                        $aweber_responder_list_option = "";

                        foreach ($aweber_lists_name as $aweber_lists_name1) {

                            if ($aweber_lists_id[$i] != "") {
                                
                                if ( 0 == $i ) {
                                    $selected_list_id = $aweber_lists_id[$i];
                                    $selected_list_label = $aweber_lists_name1;
                                }

                                $aweber_responder_list_option .= '<li class="arf_selectbox_option" data-label="'.$aweber_lists_name1.'" data-value="'.$aweber_lists_id[$i].'" value="'.$aweber_lists_id[$i].'">'.$aweber_lists_name1.'</li>';

                            } 
                            $i++;
                        }

                        $list_html .= '<input name="responder_list" id="aweber_listid" value="'.$selected_list_id.'" type="hidden" class="frm-dropdown frm-pages-dropdown">';
                        $list_html .= '<dl class="arf_selectbox" data-name="aweber_listid" data-id="aweber_listid" style="width: 400px;">';
                            $list_html .= '<dt>';
                                $list_html .= '<span>'.$selected_list_label.'</span>';
                                $list_html .= '<svg viewBox="0 0 2000 1000" width="15px" height="15px">';
                                    $list_html .= '<g fill="#000">';
                                        $list_html .= '<path d="M1024 320q0 -26 -19 -45t-45 -19h-896q-26 0 -45 19t-19 45t19 45l448 448q19 19 45 19t45 -19l448 -448q19 -19 19 -45z"></path>';
                                    $list_html .= '</g>';
                                $list_html .= '</svg>';
                            $list_html .= '</dt>';
                            $list_html .= '<dd>';
                                $list_html .= '<ul class="field_dropdown_menu field_dropdown_list_menu" style="display: none;" data-id="aweber_listid">';
                                    $list_html .= $aweber_responder_list_option;
                                $list_html .= '</ul>';
                            $list_html .= '</dd>';
                            $list_html .= '<span id="aweber_loader2"><div class="arf_imageloader"></div></span>';
                        $list_html .= '</dl>';

                    $list_html .= '</div>';

                    echo $list_html;
                } else {
                    echo $aweber_lists;
                }
            } else {
                echo esc_html__('Authorization Code should not be empty', 'ARForms');
            }
        }

        die();
    }

    function arf_aweber_authorize_app( $authorization_code ){
        
        global $arf_debug_log_id;

        $internal_token = wp_generate_password( 32, false );
        set_transient( 'arf_awb_verify_' . $internal_token, 1, 60 );

        $post_url = get_home_url().'?arf_page=arfawb_config';

        $verify_code = wp_remote_post(
            $post_url,
            array(
                'method' => 'POST',
                'timeout' => 45,
                'redirection' => 5,
                'httpversion' => '1.0',
                'blocking' => true,
                'headers' => array(),
                'body' => array(
                    'verify_code' => 'true',
                    'authorization_code' => $authorization_code,
                    'internal_token' => $internal_token,
                ),
                'cookies' => array()
            )
        );

        if( is_wp_error( $verify_code ) ){
            
            $arf_error_msg=array(	
                'success' => 'false',
                'message'     =>  esc_html__( 'Something went wrong while verifying Authorization', 'ARForms'),
            );
    
            do_action('arforms_debug_log_entry','aweber_debug_log', 'Aweber Authorization sent response', 'arforms_aweber_data', $arf_error_msg, $arf_debug_log_id);

            return esc_html__( 'Something went wrong while verifying Authorization', 'ARForms');

        } else {
            $response = json_decode( $verify_code['body'], true );

            if( !empty( $response['aweber_lists']) ){
                $aweber_lists = $response['aweber_lists'];
                $arf_success_msg=array(	
                    'success' => 'true',
                    'message'     =>  esc_html('Aweber Authorization Successfully.','ARForms'),
                );
        
                do_action('arforms_debug_log_entry','aweber_debug_log', 'Aweber Authorization sent response', 'arforms_aweber_data', $arf_success_msg, $arf_debug_log_id);
            } else {
                $aweber_lists = $response['error_msg'];
                $arf_error_msg=array(	
                    'success' => 'false',
                    'message'     =>  esc_html('Invalid Code. Please re-authorize the Aweber and try again.','ARForms'),
                );
    
                do_action('arforms_debug_log_entry','aweber_debug_log', 'Aweber Authorization sent response', 'arforms_aweber_data', $arf_error_msg, $arf_debug_log_id);

            }
            return $aweber_lists;
        }


    }
    function arf_get_getresponse_campaign($api_key= ''){
        global $arf_debug_log_id;
        $arf_getresponse_campaign = array();
        if (!empty($api_key)) {
            $arf_getresponse_url = "https://api.getresponse.com/v3/campaigns";
            $arf_args = array(               
                'headers' => array(
                    'Content-Type' => 'application/json',
                    'X-Auth-Token' => 'api-key '.$api_key,
                ),
                'timeout' => 5000

            );
            $arf_getresponse_res = wp_remote_get( $arf_getresponse_url, $arf_args );
            if(is_wp_error($arf_getresponse_res) ){  
                
                $errors = $arf_getresponse_res->get_error_message(); 

                $arf_error_msg=array(	
                    'success' => 'false',
                    'message'     =>  $errors
                );
    
                do_action('arforms_debug_log_entry','getresponse_debug_log', 'GetResponse Authorization sent response', 'arforms_getresponse_data', $arf_error_msg, $arf_debug_log_id);

                return;
            }else{

                $getresponse_data = json_decode($arf_getresponse_res['body']);            

                if( 200 != $arf_getresponse_res['response']['code']){
                    $error_getresponse = json_decode($arf_getresponse_res['body']);                
                    $actual_error_msg = $error_getresponse->message; 
                    $arf_error_msg=array(	
                        'success' => 'false',
                        'message'     =>  $actual_error_msg
                    );
        
                    do_action('arforms_debug_log_entry','getresponse_debug_log', 'GetResponse Authorization sent response', 'arforms_getresponse_data', $arf_error_msg, $arf_debug_log_id);
                    return $actual_error_msg;  
                }else{
                    if (count($getresponse_data) > 0 ) {
                    $i = 0;
                        foreach ($getresponse_data as $campaign_list) {
                            if(!empty($campaign_list->campaignId)){
                                $arf_getresponse_campaign[$i]['id'] = $campaign_list->campaignId;
                                $arf_getresponse_campaign[$i]['name'] = $campaign_list->name;
                            }
                            $i++;
                        }
                        $arf_success_msg=array(	
                            'success' => 'true',
                            'message'     =>  esc_html('Getresponse Authorization Successfully.','ARForms'),
                        );
            
                        do_action('arforms_debug_log_entry','getresponse_debug_log', 'GetResponse Authorization sent response', 'arforms_getresponse_data', $arf_success_msg, $arf_debug_log_id);
                    }
                }
            }

            
        }
        return $arf_getresponse_campaign;
    }

    function delete_autores($atts) {

        global $wpdb, $MdlDb;

        if ( empty( $_POST['arf_validation_nonce'] ) || (isset( $_POST['arf_validation_nonce'] ) && '' != $_POST['arf_validation_nonce'] && ! wp_verify_nonce( sanitize_text_field( $_POST['arf_validation_nonce'] ), 'arf_wp_nonce' )) ) {
            $response_data['status'] = 'error';
            $response_data['message'] = esc_html__( 'Sorry, your request cannot be processed due to security reason.','ARForms' );
            echo json_encode($response_data);
            die;
		}

        if( !current_user_can('arfchangesettings') ){
            $response_data['status'] = 'error';
            $response_data['message'] = esc_html__( 'Sorry, you do not have permission to perform this action.','ARForms' );
            echo json_encode($response_data);
            die;
        }

        $id = $_POST['id'];

        if ($id == 'mailchimp') {

            $wpdb->update($MdlDb->autoresponder, array('responder_api_key' => '', 'responder_list_id' => '', 'responder_list' => '', 'is_verify' => 0), array('responder_id' => 1));
        }

        if ($id == 'getresponse') {

            $wpdb->update($MdlDb->autoresponder, array('responder_api_key' => '', 'responder_list_id' => '', 'responder_list' => '', 'list_data' => '', 'is_verify' => 0), array('responder_id' => 4));
        }

        if ($id == 'icontact') {

            $wpdb->update($MdlDb->autoresponder, array('responder_api_key' => '', 'responder_list_id' => '', 'responder_list' => '', 'is_verify' => 0, 'responder_username' => '', 'responder_password' => ''), array('responder_id' => 8));
        }

                    if ($id == 'constant') {
                        $wpdb->update(
                            $MdlDb->autoresponder,
                            array(
                                'responder_api_key'  => '',
                                'responder_password' => '',
                                'responder_list_id'  => '',
                                'responder_list'     => '',
                                'list_data'          => '',
                                'is_verify'          => 0
                            ),
                            array('responder_id' => 9)
                        );
                    }

        die();
    }

    function hex2rgb($hex) {
        $hex = str_replace("#", "", $hex);

        if (strlen($hex) == 3) {
            $r = hexdec(substr($hex, 0, 1) . substr($hex, 0, 1));
            $g = hexdec(substr($hex, 1, 1) . substr($hex, 1, 1));
            $b = hexdec(substr($hex, 2, 1) . substr($hex, 2, 1));
        } else {
            $r = hexdec(substr($hex, 0, 2));
            $g = hexdec(substr($hex, 2, 2));
            $b = hexdec(substr($hex, 4, 2));
        }
        $rgb = array($r, $g, $b);

        return implode(",", $rgb);
    }

    function rgba2rgb($rgb,$alpha){

        $r = 1 * $rgb[0] + $alpha * $rgb[0];
        $g = 1 * $rgb[1] + $alpha * $rgb[1];
        $b = 1 * $rgb[2] + $alpha * $rgb[2];

        return array( $r,$g,$b );

    }
    
    function isColorDark($color) {
        $colors = explode(',',$this->hex2rgb($color));
        $r = $colors[0];
        $g = $colors[1];
        $b = $colors[2];
        $darkness = round((1 - (0.299 * $r + 0.587 * $g + 0.114 * $b) / 255),2);
        if ($darkness < 0.5) {
            return false; // It's a light color
        } else {
            return true; // It's a dark color
        }
    }

    function arf_is_addon_activated($plugin,$network_activation){

        $setvaltolic = 0;
        global $arformcontroller,$arformsplugin,$maincontroller;
        $setvaltolic = $arformcontroller->$arformsplugin();
        if( $setvaltolic != 0 ){
            return;
        }

        $urltopost = 'https://www.arformsplugin.com/addonlist/arf_addon_api_details.php';

        $raw_response = wp_remote_post($urltopost,
            array(
                'method' => 'POST',
                'timeout' => 45,
                'redirection' => 5,
                'httpversion' => '1.0',
                'blocking' => true,
                'headers' => array(),
                'body' => array(),
                'cookies' => array()
            )
        );

        if (is_wp_error($raw_response) || $raw_response['response']['code'] != 200) {
            return;
        } else {
            $arf_addons = json_decode($raw_response['body'],true);
            $arforms_addons = array();
            if( is_array($arf_addons) && count($arf_addons) > 0 ){
                foreach( $arf_addons as $arf_addon){
                    $arforms_addons[$arf_addon['plugin_installer']] = $arf_addon['arf_plugin_full_name'];
                }
            }
            
            if( is_array($arforms_addons) && count($arforms_addons) > 0 && array_key_exists($plugin, $arforms_addons) && $setvaltolic == 0 ){
                
                deactivate_plugins($plugin, TRUE);
                header('Location: ' . network_admin_url('plugins.php?deactivate=true&arf_license_deactivate=true&arf_addon=' . $arforms_addons[$plugin]));
                die;
            }
        }
    }

    function arf_install_plugin(  $pluginslug = "" , $flag = false ) {

        if ( empty( $_POST['_wpnonce'] ) || ( isset( $_POST['_wpnonce'] ) && '' != $_POST['_wpnonce'] && ! wp_verify_nonce( sanitize_text_field( $_POST['_wpnonce'] ), 'arf_wp_nonce' ) ) ) {
            echo json_encode(array('error' => 'false', 'msg' => addslashes(esc_html__('Sorry, your request cannot be processed due to security reason.', 'ARForms'))));
            die;
        }

        if( !empty($_POST['slug'] )){
            $plugin_slug_var = $_POST['slug'];
        } else {
            $plugin_slug_var = $pluginslug;
        }

        

        if (empty($plugin_slug_var)) {
            wp_send_json_error(array(
                'slug' => '',
                'errorCode' => 'no_plugin_specified',
                'errorMessage' => addslashes(esc_html__('No plugin specified.', 'ARForms')),
            ));
        }

        $plugin = $plugin_slug_var;
        $plugin = plugin_basename(trim($plugin));
        $plugin_slug = explode("/", $plugin);
        $plugin_slug = $plugin_slug[0];

       if(!str_contains($plugin_slug , 'arforms'))
       {
            echo json_encode(array('error' => 'false', 'msg' => addslashes(esc_html__('You cannot install this Plugin as your are not using ARForms', 'ARForms'))));
            die;
       }

        $status = array(
            'install' => 'plugin',
            'slug' => sanitize_key(wp_unslash($plugin_slug)),
        );

        if (!current_user_can('install_plugins')) {
            $status['errorMessage'] = addslashes(esc_html__('Sorry, you are not allowed to install plugins on this site.', 'ARForms'));
            if( $flag != true) {
                wp_send_json_error($status);
            }
        }

        if (file_exists(ABSPATH . 'wp-admin/includes/class-wp-upgrader.php')) {
            include_once( ABSPATH . 'wp-admin/includes/class-wp-upgrader.php' );
        }

        if (file_exists(ABSPATH . 'wp-admin/includes/plugin-install.php')){
            include_once( ABSPATH . 'wp-admin/includes/plugin-install.php' );
        }

        $api = plugins_api('plugin_information', array(
            'slug' => sanitize_key(wp_unslash($plugin_slug)),
            'fields' => array(
                'sections' => false,
            ),
        ));

        if (is_wp_error($api)) {
            $status['errorMessage'] = $api->get_error_message();
            if( $flag != true ){
                wp_send_json_error($status);
            }
        }

        $status['pluginName'] = $api->name;

        $skin = new WP_Ajax_Upgrader_Skin();
        $upgrader = new Plugin_Upgrader($skin);


        $result = $upgrader->install($api->download_link);

        if (defined('WP_DEBUG') && WP_DEBUG) {
            $status['debug'] = $skin->get_upgrade_messages();
        }

        if (is_wp_error($result)) {
            $status['errorCode'] = $result->get_error_code();
            $status['errorMessage'] = $result->get_error_message();
            if( $flag != true ){
                wp_send_json_error($status);
            }
        } elseif (is_wp_error($skin->result)) {
            $status['errorCode'] = $skin->result->get_error_code();
            $status['errorMessage'] = $skin->result->get_error_message();
            if( $flag != true ){
                wp_send_json_error($status);
            }
        } elseif ($skin->get_errors()->get_error_code()) {
            $status['errorMessage'] = $skin->get_error_messages();
            if( $flag != true ){
                wp_send_json_error($status);
            }
        } elseif (is_null($result)) {
            global $wp_filesystem;

            $status['errorCode'] = 'unable_to_connect_to_filesystem';
            $status['errorMessage'] = addslashes(esc_html__('Unable to connect to the filesystem. Please confirm your credentials.', 'ARForms'));

            if ($wp_filesystem instanceof WP_Filesystem_Base && is_wp_error($wp_filesystem->errors) && $wp_filesystem->errors->get_error_code()) {
                $status['errorMessage'] = esc_html($wp_filesystem->errors->get_error_message());
            }

            if( $flag != true ){
                wp_send_json_error($status);
            }
        }

        $install_status = $this->arf_install_plugin_install_status($api);

        if (current_user_can('activate_plugins') && is_plugin_inactive($install_status['file'])) {
            $status['activateUrl'] = add_query_arg(array(
                '_wpnonce' => wp_create_nonce('activate-plugin_' . $install_status['file']),
                'action' => 'activate',
                'plugin' => $install_status['file'],
                    ), network_admin_url('plugins.php'));
        }

        if (is_multisite() && current_user_can('manage_network_plugins')) {
            $status['activateUrl'] = add_query_arg(array('networkwide' => 1), $status['activateUrl']);
        }
        $status['pluginFile'] = $install_status['file'];

        if( $flag != true ){
            wp_send_json_success($status);
        }

        if( true == $flag ){
            $this->arf_activate_plugin( $pluginslug, true );
        }
    }

    function arf_activate_plugin( $pluginslug = "", $flag = false ) {

        if ( empty( $_POST['_wpnonce'] ) || ( isset( $_POST['_wpnonce'] ) && '' != $_POST['_wpnonce'] && ! wp_verify_nonce( sanitize_text_field( $_POST['_wpnonce'] ), 'arf_wp_nonce' ) ) ) {
            echo json_encode(array('error' => 'false', 'msg' => addslashes(esc_html__('Sorry, your request cannot be processed due to security reason.', 'ARForms'))));
            die;
        }

        if( !current_user_can ('activate_plugins') ){
            echo json_encode(
                array(
                    'error' => 'false',
                    'msg' => addslashes( esc_html__( 'Sorry! you do not have permission to activate the add-on', 'ARForms') )
                )
            );
            die;
        }

        if( !empty($_POST['slug'])){
            $plugin_slug = $_POST['slug'];
        } else {
            $plugin_slug = $pluginslug;
        }

         
        
        if (empty($plugin_slug)) {
            wp_send_json_error(array(
                'slug' => '',
                'errorCode' => 'no_plugin_specified',
                'errorMessage' => addslashes(esc_html__('No plugin specified.', 'ARForms')),
            ));
        }

        $plugin = $plugin_slug;
        $plugin = plugin_basename(trim($plugin));
        $plugin_slug_check = explode("/", $plugin);
        $plugin_slug_check = $plugin_slug_check[0];

       if(!str_contains($plugin_slug_check , 'arforms'))
       {
            echo json_encode(array('error' => 'false', 'msg' => addslashes(esc_html__('You cannot install this Plugin as your are not using ARForms', 'ARForms'))));
            die;
       }

        $plugin = $plugin_slug;
        $plugin = plugin_basename(trim($plugin));
        $network_wide = false;
        $silent = false;
        $redirect = '';
        if (is_multisite() && ( $network_wide || is_network_only_plugin($plugin) )) {
            $network_wide = true;
            $current = get_site_option('active_sitewide_plugins', array());
            $_GET['networkwide'] = 1; // Back compat for plugins looking for this value.
        } else {
            $current = get_option('active_plugins', array());
        }

        $valid = validate_plugin($plugin);
        if (is_wp_error($valid))
            return $valid;

        if (( $network_wide && !isset($current[$plugin]) ) || (!$network_wide && !in_array($plugin, $current) )) {
            if (!empty($redirect))
                wp_redirect(add_query_arg('_error_nonce', wp_create_nonce('plugin-activation-error_' . $plugin), $redirect)); // we'll override this later if the plugin can be included without fatal error
            ob_start();
            wp_register_plugin_realpath(WP_PLUGIN_DIR . '/' . $plugin);
            $_wp_plugin_file = $plugin;
            include_once( WP_PLUGIN_DIR . '/' . $plugin );
            $plugin = $_wp_plugin_file; // Avoid stomping of the $plugin variable in a plugin.

            if (!$silent) {
                do_action('activate_plugin', $plugin, $network_wide);
                do_action('activate_' . $plugin, $network_wide);
            }

            if ($network_wide) {
                $current = get_site_option('active_sitewide_plugins', array());
                $current[$plugin] = time();
                update_site_option('active_sitewide_plugins', $current);
            } else {
                $current = get_option('active_plugins', array());
                $current[] = $plugin;
                sort($current);
                update_option('active_plugins', $current);
            }

            if (!$silent) {
                do_action('activated_plugin', $plugin, $network_wide);
            }
            $response = array();
            if( $flag != true ){
                if (ob_get_length() > 0) {
                    $response = array(
                        'type' => 'error'
                    );
                        echo json_encode($response);
                        die();
                } else {
                    $response = array(
                        'type' => 'success'
                    );
                        echo json_encode($response);
                        die();
                }
            }
        }
        if( $flag != true ){
            die();
        }
    }

    function arf_deactivate_plugin() { 
        
        if ( empty( $_POST['_wpnonce'] ) || ( isset( $_POST['_wpnonce'] ) && '' != $_POST['_wpnonce'] && ! wp_verify_nonce( sanitize_text_field( $_POST['_wpnonce'] ), 'arf_wp_nonce' ) ) ) {

            echo json_encode(array('error' => 'false', 'msg' => addslashes(esc_html__('Sorry, your request cannot be processed due to security reason.', 'ARForms'))));
            die;
        }

        if( !current_user_can ('activate_plugins') ){
            echo json_encode(
                array(
                    'error' => 'false',
                    'msg' => addslashes( esc_html__( 'Sorry! you do not have permission to deactivate the add-on', 'ARForms') )
                )
            );
            die;
        }

        if( !empty($_POST['slug'] )){
            $plugin_slug_var = $_POST['slug'];
        }

        if (empty($plugin_slug_var)) {
            wp_send_json_error(array(
                'slug' => '',
                'errorCode' => 'no_plugin_specified',
                'errorMessage' => addslashes(esc_html__('No plugin specified.', 'ARForms')),
            ));
        }

        $plugin = $plugin_slug_var;
        $plugin = plugin_basename(trim($plugin));
        $plugin_slug = explode("/", $plugin);
        $plugin_slug = $plugin_slug[0];

       if(!str_contains($plugin_slug , 'arforms'))
       {
            echo json_encode(array('error' => 'false', 'msg' => addslashes(esc_html__('You cannot install this Plugin as your are not using ARForms', 'ARForms'))));
            die;
       }


        $plugin = $_POST['slug'];
        $silent = false;
        $network_wide = false;
        if (is_multisite())
            $network_current = get_site_option('active_sitewide_plugins', array());
        $current = get_option('active_plugins', array());
        $do_blog = $do_network = false;


        $plugin = plugin_basename(trim($plugin));


        $network_deactivating = false !== $network_wide && is_plugin_active_for_network($plugin);

        if (!$silent) {
            do_action('deactivate_plugin', $plugin, $network_deactivating);
        }

        if (false != $network_wide) {
            if (is_plugin_active_for_network($plugin)) {
                $do_network = true;
                unset($network_current[$plugin]);
            } elseif ($network_wide) {
                
            }
        }

        if (true != $network_wide) {
            $key = array_search($plugin, $current);
            if (false !== $key) {
                $do_blog = true;
                unset($current[$key]);
            }
        }

        if (!$silent) {
            do_action('deactivate_' . $plugin, $network_deactivating);
            do_action('deactivated_plugin', $plugin, $network_deactivating);
        }


        if ($do_blog)
            update_option('active_plugins', $current);
        if ($do_network)
            update_site_option('active_sitewide_plugins', $network_current);

        if ( empty( $_POST['_wpnonce'] ) || ( isset( $_POST['_wpnonce'] ) && '' != $_POST['_wpnonce'] && ! wp_verify_nonce( sanitize_text_field( $_POST['_wpnonce'] ), 'arf_wp_nonce' ) ) ) {
    
            echo json_encode(array('status'=>'error' , 'message' => addslashes(esc_html__( 'Sorry, your request cannot be processed due to security reason.','ARForms' )))); 
            die;
    
        }
    

        global $arformcontroller,$arformsplugin;
        $setvaltolic = $arformcontroller->$arformsplugin();

        $response = array(
            'type' => 'success'
        );
        if( $setvaltolic != 1){
            $response['url'] = admin_url('admin.php?page=ARForms-license');
        }
        echo json_encode($response);
        die();
    }

    function arf_install_plugin_install_status($api, $loop = false) {
        // This function is called recursively, $loop prevents further loops.
        if (is_array($api))
            $api = (object) $api;

        // Default to a "new" plugin
        $status = 'install';
        $url = false;
        $update_file = false;
        $version = '';

        /*
         * Check to see if this plugin is known to be installed,
         * and has an update awaiting it.
         */
        $update_plugins = get_site_transient('update_plugins');
        if (isset($update_plugins->response)) {
            foreach ((array) $update_plugins->response as $file => $plugin) {
                if ($plugin->slug === $api->slug) {
                    $status = 'update_available';
                    $update_file = $file;
                    $version = $plugin->new_version;
                    if (current_user_can('update_plugins'))
                        $url = wp_nonce_url(self_admin_url('update.php?action=upgrade-plugin&plugin=' . $update_file), 'upgrade-plugin_' . $update_file);
                    break;
                }
            }
        }

        if ('install' == $status) {
            if (is_dir(WP_PLUGIN_DIR . '/' . $api->slug)) {
                $installed_plugin = get_plugins('/' . $api->slug);
                if (empty($installed_plugin)) {
                    if (current_user_can('install_plugins'))
                        $url = wp_nonce_url(self_admin_url('update.php?action=install-plugin&plugin=' . $api->slug), 'install-plugin_' . $api->slug);
                } else {
                    $key = array_keys($installed_plugin);
                    $key = reset($key); //Use the first plugin regardless of the name, Could have issues for multiple-plugins in one directory if they share different version numbers
                    $update_file = $api->slug . '/' . $key;
                    if (version_compare($api->version, $installed_plugin[$key]['Version'], '=')) {
                        $status = 'latest_installed';
                    } elseif (version_compare($api->version, $installed_plugin[$key]['Version'], '<')) {
                        $status = 'newer_installed';
                        $version = $installed_plugin[$key]['Version'];
                    } else {
                        //If the above update check failed, Then that probably means that the update checker has out-of-date information, force a refresh
                        if (!$loop) {
                            delete_site_transient('update_plugins');
                            wp_update_plugins();
                            return $this->arf_install_plugin_install_status($api, true);
                        }
                    }
                }
            } else {
                // "install" & no directory with that slug
                if (current_user_can('install_plugins'))
                    $url = wp_nonce_url(self_admin_url('update.php?action=install-plugin&plugin=' . $api->slug), 'install-plugin_' . $api->slug);
            }
        }
        if (isset($_GET['from']))
            $url .= '&amp;from=' . urlencode(wp_unslash($_GET['from']));

        $file = $update_file;
        return compact('status', 'url', 'version', 'file');
    }

    function arf_upgrader_package_options($options) {
        $options['is_multi'] = false;
        return $options;
    }

    function arf_plugin_api_args($args, $action) {
        return $args;
    }

    function arf_plugin_api($res, $action, $args) {
        $arforms_addons = get_transient( 'arf_addon_installation_page_data' );

        $arforms_new_addons = $this->arf_retrieve_new_addons_func();

        if( isset( $arforms_addons) && !empty( $arforms_addons) ) {
            $obj = array();
            foreach ($arforms_addons as $slug => $arforms_addon) {
                foreach( $arforms_addon as $slugv2 => $arf_addon ){
                    if (isset($slugv2) && isset($args->slug)) {
                        if ($slugv2 != $args->slug) {
                            continue;
                        } else {
                            $obj['name'] = $arf_addon['full_name'];
                            $obj['slug'] = $slugv2;
                            $obj['version'] = $arf_addon['plugin_version'];
                            $obj['download_link'] = $arf_addon['install_url'];
                            return (object) $obj;
                        }
                    } else {
                        continue;
                    }
                }
            }
        }

        if( isset( $arforms_new_addons ) && !empty( $arforms_new_addons ) ){
            $obj = array();
            foreach( $arforms_new_addons as $slug => $arforms_addon ){
                foreach( $arforms_addon as $slugv2 => $arf_addon ){
                    if (isset($slugv2) && isset($args->slug)) {
                        if ($slugv2 != $args->slug) {
                            continue;
                        } else {
                            $obj['name'] = $arf_addon['full_name'];
                            $obj['slug'] = $slugv2;
                            $obj['version'] = $arf_addon['plugin_version'];
                            $obj['download_link'] = $arf_addon['install_url'];
                            return (object) $obj;
                        }
                    } else {
                        continue;
                    }
                }
            }
        }        

        return $res;
    }

    function arf_retrieve_new_addons_func(){

        global $arfversion, $MdlDb, $arnotifymodel, $arfform, $arfrecordmeta;
        $bloginformation = array();
        $str = $MdlDb->get_rand_alphanumeric(10);

        $addon_lists = array();

        if (is_multisite())
            $multisiteenv = "Multi Site";
        else
            $multisiteenv = "Single Site";

        $addon_listing = 1;

        $bloginformation[] = $arnotifymodel->sitename();
        $bloginformation[] = $arfform->sitedesc();
        $bloginformation[] = home_url();
        $bloginformation[] = get_bloginfo('admin_email');
        $bloginformation[] = $arfrecordmeta->wpversioninfo();
        $bloginformation[] = $arfrecordmeta->getlanguage();
        $bloginformation[] = $arfversion;
        $bloginformation[] = $_SERVER['REMOTE_ADDR'];
        $bloginformation[] = $str;
        $bloginformation[] = $multisiteenv;
        $bloginformation[] = $addon_listing;

        $arf_pcode = "";

        $get_purchased_info = get_option('arfSortInfo');
        $sortorderval = base64_decode($get_purchased_info);
        $ordering = explode("^", $sortorderval);
        if(is_array($ordering)) {
            $arf_pcode = (isset($ordering[0]) && $ordering[0]!= "") ? $ordering[0] : "";
        }

        $urltopost = 'https://www.arformsplugin.com/arforms_new_addons/arf_install_plugins.php';

        $valstring = implode("||", $bloginformation);
        $encodedval = base64_encode($valstring);

        $raw_response = wp_remote_post(
            $urltopost,
            array(
                'method' => 'POST',
                'timeout' => 4500,
                'redirection' => 5,
                'httpversion' => '1.0',
                'blocking' => true,
                'headers' => array(),
                'body' => array(
                    'wpversion' => $encodedval,
                    'user_agent' => $_SERVER['HTTP_USER_AGENT'],
                    'arf_pcode' => $arf_pcode
                ),
                'cookies' => array()
            )
        );

        $raw_response_data = base64_decode( $raw_response['body'] );
        
        if( !is_array( $raw_response_data ) && preg_match( '/empty_pcode|invalid_pcode/', $raw_response_data ) ){

        } else {
            $addon_lists = json_decode( $raw_response_data, true );
        }

        return $addon_lists;
    }

    function arf_plugins_api_result($res, $action, $args) {
        return $res;
    }

    function arf_generate_color_tone($hex, $steps) {

        $steps = max(-255, min(255, $steps));

        $hex = str_replace('#', '', $hex);

        if ($hex != '' && strlen($hex) < 6) {
            $hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
        }

        $color_parts = str_split($hex, 2);
        $return = '#';

        $acsteps = str_replace(array('+', '-'), array('', ''), $steps);

        if (strlen($acsteps) > 2)
            $lum = $steps / 1000;
        else
            $lum = $steps / 100;

        foreach ($color_parts as $color) {
            $color = hexdec($color);
            $color = round(max(0, min(255, $color + ($color * $lum))));
            $return .= str_pad(dechex($color), 2, '0', STR_PAD_LEFT);
        }

        return $return;
    }
    
    function arf_array_map($input = array()) {
        if (empty($input)) {
            return $input;
        }
	
        return is_array($input) ? array_map(array($this, __FUNCTION__), $input) : trim($input);
    }

    function arf_remove_directory($directory){
        if( $directory == '' ){
            return false;
        }

        if( is_dir($directory) )
            $dir_handle = opendir($directory);

        if( !isset($dir_handle) )
            return false;

        while( $file = readdir($dir_handle) ){
            if( $file != "." && $file != ".." ){
                if( !is_dir($directory.'/'.$file) ){
                    if( false == @unlink($directory.'/'.$file) ){
                        @chmod($directory.'/'.$file,0777);
                        @unlink($directory.'/'.$file);
                    }
                } else {
                    $this->arf_remove_directory($directory.'/'.$file);
                }
            }
        }
        closedir($dir_handle);
        WP_Filesystem();
        global $wp_filesystem;
        $wp_filesystem->rmdir($directory);
        return true;
    }

    function arf_add_mailchimp_subscriber_callback($mailchimp_arr,$fname,$lname,$email,$fid){
        if( '' == $email ){
            return esc_html__('No email address provided','ARForms');
        }

        if(!preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*$/i", $email)) {
            return esc_html__("Email address is invalid","ARForms");
        }

        global $wpdb,$MdlDb,$arf_mcapi_version;

        $res = $wpdb->get_results( $wpdb->prepare("SELECT * FROM ".$MdlDb->autoresponder." WHERE responder_id=%d",1),'ARRAY_A'); //phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Reason: $MdlDb->autoresponder is table name defined globally. False Positive alarm
        $res = $res[0];
        $responder_api_key = $res['responder_api_key'];

        $data = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM ".$MdlDb->ar." WHERE frm_id = %d", $fid), 'ARRAY_A' ); //phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Reason: $MdlDb->ar is table name defined globally. False Positive alarm
        $arr_mailchimp  = arf_pro_maybe_unserialize( $data[0]['mailchimp'] );
        $responder_list_id = isset($arr_mailchimp['type_val'])?$arr_mailchimp['type_val']:'';
        $double_opt_in = isset($arr_mailchimp['double_optin']) ? $arr_mailchimp['double_optin'] : 0;

        $status = 'subscribed';
        if( 1 == $double_opt_in  ){
            $status = 'pending';
        }

        $merge_fields = array(
            'FNAME' => isset( $fname ) ? $fname : '',
            'LNAME' => isset( $lname ) ? $lname : ''
        );

        $merge_fields = apply_filters('arf_mailchimp_additional_fields_from_outside',$merge_fields,$fid,$arr_mailchimp);

        $update_existing = apply_filters('arf_is_update_mailchimp_subscriber',false,$fid);
            
        $arf_mcapi_dc = substr($responder_api_key,strpos($responder_api_key,'-')+1);

        $post_fields = array(
            'email_address' => $email,
            'status' => $status,
            'merge_fields' => $merge_fields,
        );

        $post_fields = apply_filters('arf_mailchimp_tag_fields_from_outside',$post_fields );


        if( true == $update_existing ){
            $arf_mcapi_member = md5(strtolower($email));
            $arf_mcapi_url = 'https://'.$arf_mcapi_dc.'.api.mailchimp.com/'.$arf_mcapi_version.'/lists/'.$responder_list_id.'/members/'.$arf_mcapi_member;

            $arguments = array(
                'timeout' => '5000',
                'method' => 'PUT',
                'headers' => array(
                    'Content-Type' => 'application/json',
                    'Authorization' => 'Bearer '. $responder_api_key
                ),
                'body' => json_encode($post_fields)
            );

            $arf_mc_subscriber = wp_remote_request($arf_mcapi_url,$arguments);

        } else {

            $arguments = array(
                'timeout' => '5000',
                'headers' => array(
                    'Content-Type' => 'application/json',
                    'Authorization' => 'Bearer ' . $responder_api_key 
                ),
                'body' => json_encode($post_fields),
            );
           
            $arf_mc_api_url = 'https://'.$arf_mcapi_dc.'.api.mailchimp.com/'.$arf_mcapi_version.'/lists/'.$responder_list_id.'/members';
           
            $arf_mc_subscriber = wp_remote_post($arf_mc_api_url,$arguments);

            if( is_wp_error($arf_mc_subscriber) ){
                global $arf_debug_log_id;

                $errors = $arf_mc_subscriber->get_error_code(); 
                $errors_msg = $arf_mc_subscriber->get_error_message();                
                echo $errors_msg;
              
                
                $arf_error_msg=array(	
                    'success' => 'false',
                    'message'     =>  $errors_msg,
                );
    
                do_action('arforms_debug_log_entry','mailchimp_debug_log', 'Mailchimp Authorization sent response from frontend', 'arforms_mailchimp_data', $arf_error_msg, $arf_debug_log_id);
            }
            else{
  
                $mailchimp_list = json_decode($arf_mc_subscriber['body'],true);
                if( ( $mailchimp_list['status'] == 400 ) ){
                    $errors_msg = $mailchimp_list['title'];
                    $arf_error_msg = array(
                        'success'       => 'false',
                        'message'       =>  $errors_msg,
                    );

                    if( !empty( $mailchimp_list['status'] )){
                        $arf_error_msg['status'] = $mailchimp_list['status'];
                    }
        
                    do_action('arforms_debug_log_entry','mailchimp_debug_log', 'Mailchimp Authorization sent response', 'arforms_mailchimp_data', $arf_error_msg, $arf_debug_log_id);
                }else{
                    $arf_success_msg=array(	
                        'success' => 'true',
                        'message'     =>  esc_html('Subscriber added to Mailchimp','ARForms'),
                    );
        
                    do_action('arforms_debug_log_entry','mailchimp_debug_log', 'Mailchimp Authorization sent response from frontend', 'arforms_mailchimp_data', $arf_success_msg, $arf_debug_log_id);
                }
            }
        }

    }

    function arf_remove_backup_data_callback(){
        global $wpdb;

        $wpdb->query( $wpdb->prepare( "DROP TABLE IF EXISTS `".$wpdb->prefix."arf_forms_backup`" ) );
        $wpdb->query( $wpdb->prepare( "DROP TABLE IF EXISTS `".$wpdb->prefix."arf_fields_backup`" ) );

        $wp_upload_dir = wp_upload_dir();
        $backup_dir = $wp_upload_dir['basedir'].'/arforms/maincss_backup';
        if( is_dir($backup_dir) ){
            arf_rmdir( $backup_dir );
        }
    }

    function arf_aweber_configuration(){
        if( !empty( $_REQUEST['arf_page'] ) && 'arfawb_config' == $_REQUEST['arf_page'] ){
            if( empty( $_POST['verify_code'] ) && empty( $_POST['refresh_code'] ) ){
                if( ! is_user_logged_in() || ! current_user_can( 'arfchangesettings' ) || empty( $_GET['_wpnonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ), 'arf_aweber_auth_action' ) ){
                    wp_die( esc_html__( 'Sorry, you do not have permission to access this page.', 'ARForms' ), 403 );
                }
            } else if( !empty( $_POST['verify_code'] ) ){
                $token = !empty( $_POST['internal_token'] ) ? sanitize_text_field( $_POST['internal_token'] ) : '';
                if( empty( $token ) || ! get_transient( 'arf_awb_verify_' . $token ) ){
                    wp_die( esc_html__( 'Unauthorized access.', 'ARForms' ), 403 );
                }
            } else if( !empty( $_POST['refresh_code'] ) ){
                $token = !empty( $_POST['internal_token'] ) ? sanitize_text_field( $_POST['internal_token'] ) : '';
                if( empty( $token ) || ! get_transient( 'arf_awb_refresh_' . $token ) ){
                    wp_die( esc_html__( 'Unauthorized access.', 'ARForms' ), 403 );
                }
            } else {
                wp_die( esc_html__( 'Unauthorized access.', 'ARForms' ), 403 );
            }

            require_once AUTORESPONDER_PATH . '/aweber/configuration.php';
            die;
        }
    }


    function arf_cc_initiate_oauth()
    {
        global $MdlDb, $wpdb;

        if (empty($_POST['arf_validation_nonce']) || !wp_verify_nonce(sanitize_text_field($_POST['arf_validation_nonce']), 'arf_wp_nonce')) {
            wp_send_json_error(array('message' => esc_html__('Security check failed.', 'ARForms')));
            die;
        }
        if (!current_user_can('arfchangesettings')) {
            wp_send_json_error(array('message' => esc_html__('Permission denied.', 'ARForms')));
            die;
        }

        require_once(AUTORESPONDER_PATH . 'constant_contact/ConstantContactV3.php');

        $client_id     = isset($_POST['client_id'])     ? sanitize_text_field($_POST['client_id'])     : '';
        $client_secret = isset($_POST['client_secret']) ? sanitize_text_field($_POST['client_secret']) : '';

        if (empty($client_id) || empty($client_secret)) {
            wp_send_json_error(array('message' => esc_html__('Please enter Client ID and Client Secret first.', 'ARForms')));
            die;
        }

        $wpdb->update(
            $MdlDb->autoresponder,
            array(
                'responder_api_key'  => $client_id,
                'responder_password' => $client_secret,
            ),
            array('responder_id' => 9)
        );

        $state = wp_generate_password(24, false);
        set_transient('arf_cc_oauth_state', $state, 600); // 10-minute

        $redirect_uri = admin_url('admin-ajax.php') . '?action=arf_cc_oauth_callback';
        $ccV3 = new ConstantContactV3($client_id, $client_secret, $redirect_uri);
        $auth_url = $ccV3->getAuthorizationUrl($state);

        wp_send_json_success(array('auth_url' => $auth_url));
        die;
    }


    function arf_cc_oauth_callback()
    {
        global $MdlDb, $wpdb;

        $code  = isset($_GET['code'])  ? sanitize_text_field($_GET['code'])  : '';
        $state = isset($_GET['state']) ? sanitize_text_field($_GET['state']) : '';

        $saved_state = get_transient('arf_cc_oauth_state');
        if (empty($code) || $state !== $saved_state) {
            ?><!DOCTYPE html><html><body>
                <p style="color:red;font-family:sans-serif;">
                    <?php echo esc_html__('Authorization failed: invalid state or missing code.', 'ARForms'); ?>
                </p>
                <script>if(window.opener){window.opener.postMessage({arf_cc_result:'error',message:'State mismatch'},'*');}window.close();</script>
                </body></html><?php
                die;
        }
        delete_transient('arf_cc_oauth_state');

        $cc_db_row     = $wpdb->get_row("SELECT * FROM {$MdlDb->autoresponder} WHERE responder_id = 9");
        $client_id     = isset($cc_db_row->responder_api_key)  ? $cc_db_row->responder_api_key  : '';
        $client_secret = isset($cc_db_row->responder_password) ? $cc_db_row->responder_password : '';

        if (empty($client_id) || empty($client_secret)) {
            ?><!DOCTYPE html><html><body>
            <p style="color:red;font-family:sans-serif;">
                <?php echo esc_html__('Client ID or Secret not found. Please save them first.', 'ARForms'); ?>
            </p>
            <script>if(window.opener){window.opener.postMessage({arf_cc_result:'error',message:'No credentials'},'*');}window.close();</script>
            </body></html><?php
            die;
        }

        require_once(AUTORESPONDER_PATH . 'constant_contact/ConstantContactV3.php');
        $redirect_uri = admin_url('admin-ajax.php') . '?action=arf_cc_oauth_callback';
        $ccV3 = new ConstantContactV3($client_id, $client_secret, $redirect_uri);
        $token_data = $ccV3->getAccessToken($code);

        if (is_wp_error($token_data) || empty($token_data['access_token'])) {
            $err = is_wp_error($token_data) ? $token_data->get_error_message() : json_encode($token_data);
            ?><!DOCTYPE html><html><body>
            <p style="color:red;font-family:sans-serif;"><?php echo esc_html__('Token exchange failed: ', 'ARForms') . esc_html($err); ?></p>
            <script>if(window.opener){window.opener.postMessage({arf_cc_result:'error',message:<?php echo json_encode($err); ?>},'*');}window.close();</script>
            </body></html><?php
            die;
        }

        $token_store = array(
            'access_token'  => $token_data['access_token'],
            'refresh_token' => isset($token_data['refresh_token']) ? $token_data['refresh_token'] : '',
            'expires_at'    => time() + (isset($token_data['expires_in']) ? (int)$token_data['expires_in'] : 28800),
        );

        $wpdb->update(
            $MdlDb->autoresponder,
            array(
                'responder_list_id' => maybe_serialize($token_store),
                'is_verify'         => 0, 
            ),
            array('responder_id' => 9)
        );

        ?><!DOCTYPE html><html><body>
        <p style="color:green;font-family:sans-serif;"><?php echo esc_html__('Connected to Constant Contact successfully! This window will close.', 'ARForms'); ?></p>
        <script>
            if (window.opener) {
                window.opener.postMessage({arf_cc_result: 'success', message: 'Connected'}, '*');
            }
            setTimeout(function(){ window.close(); }, 1500);
        </script>
        </body></html><?php
        die;
    }


    function arf_cc_get_valid_access_token($cc_db_row, $client_id, $client_secret)
    {
        global $MdlDb, $wpdb;

        $token_store = arf_pro_maybe_unserialize(isset($cc_db_row->responder_list_id) ? $cc_db_row->responder_list_id : '');

        if (empty($token_store) || !is_array($token_store) || empty($token_store['access_token'])) {
            return '';
        }

        // Check if the access token has expired (with 60-second buffer)
        if (isset($token_store['expires_at']) && time() > ($token_store['expires_at'] - 60)) {

            require_once(AUTORESPONDER_PATH . 'constant_contact/ConstantContactV3.php');
            $redirect_uri = admin_url('admin-ajax.php') . '?action=arf_cc_oauth_callback';
            $ccV3 = new ConstantContactV3($client_id, $client_secret, $redirect_uri);
            $new_tokens = $ccV3->refreshAccessToken($token_store['refresh_token']);

            if (is_wp_error($new_tokens) || empty($new_tokens['access_token'])) {
                return '';
            }

            $token_store = array(
                'access_token'  => $new_tokens['access_token'],
                'refresh_token' => isset($new_tokens['refresh_token']) ? $new_tokens['refresh_token'] : $token_store['refresh_token'],
                'expires_at'    => time() + (isset($new_tokens['expires_in']) ? (int)$new_tokens['expires_in'] : 28800),
            );

            $wpdb->update(
                $MdlDb->autoresponder,
                array('responder_list_id' => maybe_serialize($token_store)),
                array('responder_id' => 9)
            );
        }

        return $token_store['access_token'];
    }

}

function object2array($object) {
    return @json_decode(@json_encode($object), 1);
}
?>