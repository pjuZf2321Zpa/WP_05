<?php
/**
 * Constant Contact V3 API Client for ARForms
 * 
 * This class handles OAuth2 authentication and V3 API requests.
 */

if (!class_exists('ConstantContactV3')) {

    class ConstantContactV3 {

        private $client_id;
        private $client_secret;
        private $redirect_uri;
        private $base_url = 'https://api.cc.email/v3';
        private $auth_url = 'https://authz.constantcontact.com/oauth2/default/v1/authorize';
        private $token_url = 'https://authz.constantcontact.com/oauth2/default/v1/token';

        public function __construct($client_id = '', $client_secret = '', $redirect_uri = '') {
            $this->client_id = $client_id;
            $this->client_secret = $client_secret;
            $this->redirect_uri = $redirect_uri;
        }

        /**
         * Get Authorization URL
         */
        public function getAuthorizationUrl($state) {
            $params = array(
                'client_id'     => $this->client_id,
                'redirect_uri'  => $this->redirect_uri,
                'response_type' => 'code',
                'scope'         => 'contact_data campaign_data offline_access',
                'state'         => $state
            );
            return add_query_arg($params, $this->auth_url);
        }

        /**
         * Exchange Authorization Code for Access Token
         */
        public function getAccessToken($code) {
            $auth_header = 'Basic ' . base64_encode($this->client_id . ':' . $this->client_secret);
            
            $url = add_query_arg(array(
                'code'          => $code,
                'redirect_uri'  => $this->redirect_uri,
                'grant_type'    => 'authorization_code'
            ), $this->token_url);

            $args = array(
                'method'      => 'POST',
                'headers'     => array(
                    'Authorization' => $auth_header,
                    'Content-Type'  => 'application/x-www-form-urlencoded',
                    'Accept'        => 'application/json'
                ),
                'timeout'     => 45,
                'blocking'    => true
            );

            $response = wp_remote_post($url, $args);

            if (is_wp_error($response)) {
                return $response;
            }

            $body = json_decode(wp_remote_retrieve_body($response), true);
            return $body;
        }

        /**
         * Refresh Access Token
         */
        public function refreshAccessToken($refresh_token) {
            $auth_header = 'Basic ' . base64_encode($this->client_id . ':' . $this->client_secret);
            
            $url = add_query_arg(array(
                'refresh_token' => $refresh_token,
                'grant_type'    => 'refresh_token'
            ), $this->token_url);

            $args = array(
                'method'      => 'POST',
                'headers'     => array(
                    'Authorization' => $auth_header,
                    'Content-Type'  => 'application/x-www-form-urlencoded',
                    'Accept'        => 'application/json'
                ),
                'timeout'     => 45,
                'blocking'    => true
            );

            $response = wp_remote_post($url, $args);

            if (is_wp_error($response)) {
                error_log('ConstantContactV3 Error: ' . $response->get_error_message());
                return $response;
            }

            $body = json_decode(wp_remote_retrieve_body($response), true);
            return $body;
        }

        /**
         * Get Lists
         */
        public function getLists($access_token) {
            $url = $this->base_url . '/contact_lists?limit=50';
            
            $args = array(
                'headers' => array(
                    'Authorization' => 'Bearer ' . $access_token,
                    'Accept'        => 'application/json'
                ),
                'timeout' => 45
            );

            $response = wp_remote_get($url, $args);

            if (is_wp_error($response)) {
                return $response;
            }

            return json_decode(wp_remote_retrieve_body($response), true);
        }

        /**
         * Create or Update Contact (Sign up form endpoint)
         */
        public function addOrUpdateContact($access_token, $contact_data) {
            $url = $this->base_url . '/contacts/sign_up_form';

            $args = array(
                'method'  => 'POST',
                'headers' => array(
                    'Authorization' => 'Bearer ' . $access_token,
                    'Content-Type'  => 'application/json',
                    'Accept'        => 'application/json'
                ),
                'body'    => json_encode($contact_data),
                'timeout' => 45
            );

            $response = wp_remote_post($url, $args);

            if (is_wp_error($response)) {
                return $response;
            }

            return json_decode(wp_remote_retrieve_body($response), true);
        }
    }
}
