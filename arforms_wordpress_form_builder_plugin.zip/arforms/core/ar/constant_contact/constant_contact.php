<?php
global $wpdb, $email, $name, $MdlDb, $fid;

require_once(dirname(__FILE__) . '/addOrUpdateContact.php');
?>