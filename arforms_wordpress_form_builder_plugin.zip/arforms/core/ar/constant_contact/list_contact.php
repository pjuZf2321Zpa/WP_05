<?php

require_once(dirname(__FILE__) . '/ConstantContactV3.php');

global $MdlDb, $wpdb;

$cc_db_row = $wpdb->get_row("SELECT * FROM {$MdlDb->autoresponder} WHERE responder_id = 9");

$cc_client_id     = isset($cc_db_row->responder_api_key)  ? stripslashes($cc_db_row->responder_api_key)  : '';
$cc_client_secret = isset($cc_db_row->responder_password) ? stripslashes($cc_db_row->responder_password) : '';

$token_store = arf_pro_maybe_unserialize(isset($cc_db_row->responder_list_id) ? $cc_db_row->responder_list_id : '');

$redirect_uri = admin_url('admin-ajax.php') . '?action=arf_cc_oauth_callback';
$ccV3 = new ConstantContactV3($cc_client_id, $cc_client_secret, $redirect_uri);

// Auto-refresh token if expired
$access_token = '';
if (is_array($token_store) && !empty($token_store['access_token'])) {
    if (isset($token_store['expires_at']) && time() > ($token_store['expires_at'] - 60)) {
        $new_tokens = $ccV3->refreshAccessToken($token_store['refresh_token']);
        if (!is_wp_error($new_tokens) && !empty($new_tokens['access_token'])) {
            $token_store = array(
                'access_token'  => $new_tokens['access_token'],
                'refresh_token' => isset($new_tokens['refresh_token']) ? $new_tokens['refresh_token'] : $token_store['refresh_token'],
                'expires_at'    => time() + (isset($new_tokens['expires_in']) ? (int)$new_tokens['expires_in'] : 28800),
            );
            $wpdb->update(
                $MdlDb->autoresponder,
                array('responder_list_id' => maybe_serialize($token_store)),
                array('responder_id' => 9)
            );
        }
    }
    $access_token = $token_store['access_token'];
}

if (empty($access_token)) {
    return;
}

$lists_response = $ccV3->getLists($access_token);

$lists = array();
if (isset($lists_response['lists']) && is_array($lists_response['lists'])) {
    foreach ($lists_response['lists'] as $list_item) {
        $obj = new stdClass();
        $obj->id   = isset($list_item['list_id']) ? $list_item['list_id'] : '';
        $obj->name = isset($list_item['name'])    ? $list_item['name']    : '';
        $obj->status        = 'ACTIVE';
        $obj->contact_count = 0;
        $lists[] = $obj;
    }
}

?>