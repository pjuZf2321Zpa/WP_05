<?php

require_once(dirname(__FILE__) . '/ConstantContactV3.php');

global $MdlDb, $wpdb;

$res = $wpdb->get_results(
    $wpdb->prepare(
        "SELECT * FROM " . $MdlDb->autoresponder . " WHERE responder_id=%d",
        9
    )
);
$res = $res[0]; // phpcs:ignore

$cc_client_id     = isset($res->responder_api_key)  ? stripslashes($res->responder_api_key)  : '';
$cc_client_secret = isset($res->responder_password) ? stripslashes($res->responder_password) : '';

$token_store = arf_pro_maybe_unserialize(isset($res->responder_list_id) ? $res->responder_list_id : '');

$redirect_uri = admin_url('admin-ajax.php') . '?action=arf_cc_oauth_callback';
$ccV3 = new ConstantContactV3($cc_client_id, $cc_client_secret, $redirect_uri);

// Auto-refresh token if expired
$access_token = '';
if (is_array($token_store) && !empty($token_store['access_token'])) {
    if (isset($token_store['expires_at']) && time() > ($token_store['expires_at'] - 60)) {
        $new_tokens = $ccV3->refreshAccessToken($token_store['refresh_token']);
        if (!is_wp_error($new_tokens) && !empty($new_tokens['access_token'])) {
            $token_store = array(
                'access_token'  => $new_tokens['access_token'],
                'refresh_token' => isset($new_tokens['refresh_token']) ? $new_tokens['refresh_token'] : $token_store['refresh_token'],
                'expires_at'    => time() + (isset($new_tokens['expires_in']) ? (int)$new_tokens['expires_in'] : 28800),
            );
            $wpdb->update(
                $MdlDb->autoresponder,
                array('responder_list_id' => maybe_serialize($token_store)),
                array('responder_id' => 9)
            );
        } else {
            error_log('ARForms CC V3 addOrUpdateContact: Token refresh failed: ' . print_r($new_tokens, true));
        }
    }
    $access_token = $token_store['access_token'];
}

if (empty($access_token)) {
    return;
}

$data = $wpdb->get_results(
    $wpdb->prepare(
        "SELECT * FROM " . $MdlDb->ar . " WHERE frm_id = %d",
        $fid
    ),
    'ARRAY_A'
); // phpcs:ignore

$arr_constant_contact = arf_pro_maybe_unserialize($data[0]['constant_contact']);
$list_id1 = isset($arr_constant_contact['type_val']) ? stripslashes($arr_constant_contact['type_val']) : '';

if ($list_id1 != '') {
    if (isset($email) && strlen($email) > 1) {
        try {
            global $arf_debug_log_id;

            $contact_payload = array(
                'email_address'    => $email,
                'first_name'       => isset($fname) ? $fname : '',
                'last_name'        => isset($lname) ? $lname : '',
                'list_memberships' => array($list_id1),
            );

            $result = $ccV3->addOrUpdateContact($access_token, $contact_payload);

            if (isset($result['contact_id'])) {
                $arf_success_msg = array(
                    'success' => 'true',
                    'message' => esc_html('Constant Contact: Contact added successfully.', 'ARForms'),
                );
                do_action('arforms_debug_log_entry', 'constant_contact_debug_log', 'Constant contact Authorization sent response from frontend', 'arforms_constant_contact_data', $arf_success_msg, $arf_debug_log_id);
            } else {
                $error_detail = isset($result['error_message']) ? $result['error_message'] : json_encode($result);
                $arf_error_msg = array(
                    'success' => 'false',
                    'message' => $error_detail,
                );
                do_action('arforms_debug_log_entry', 'constant_contact_debug_log', 'Constant contact response from frontend', 'arforms_constant_contact_data', $arf_error_msg, $arf_debug_log_id);
            }

        } catch (Throwable $ex) {
            $arf_error_msg = array(
                'success' => 'false',
                'message' => $ex->getMessage(),
            );
            do_action('arforms_debug_log_entry', 'constant_contact_debug_log', 'Constant contact exception from frontend', 'arforms_constant_contact_data', $arf_error_msg, $arf_debug_log_id);
        }
    }
}
?>