<?php
	global $MdlDb;
        
	$res = $wpdb->get_results($wpdb->prepare("SELECT * FROM ". $MdlDb->autoresponder ." WHERE responder_id=%d",3));$res = $res[0]; //phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Reason: $MdlDb->autoresponder is table name defined globally. False Positive alarm 
	
	$data = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM ".$MdlDb->ar." WHERE frm_id = %d", $fid), 'ARRAY_A' ); //phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Reason: $MdlDb->ar is table name defined globally. False Positive alarm 
			
   	$arr_aweber 	= isset($data[0]['aweber'])?arf_pro_maybe_unserialize($data[0]['aweber']):array();
	
	$responder_api_key = stripslashes( stripslashes_deep( $arr_aweber['type_val'] ) );
	
	$formdata = str_replace('"',"'",$responder_api_key);

	$formdata_hiddn = explode("type='hidden'",$formdata);
	$count_formdata_hiddn = count($formdata_hiddn);
	
	$fields = array();
	for($i=1;$i<count($formdata_hiddn);$i++)
	{
		$findhiddn_name = strpos($formdata_hiddn[$i],"/>");
		$formdata_h=trim(substr($formdata_hiddn[$i],0,$findhiddn_name));
		
		$formdata_h_name = explode("name='",$formdata_h);
		$formdata_h_name_f = strpos($formdata_h_name[1],"'");
		$formdata_h_name_f1 = substr($formdata_h_name[1], 0, $formdata_h_name_f);
		
		$formdata_h_value = explode("value='",$formdata_h);
		$formdata_h_value_f = strpos($formdata_h_value[1],"'");
		$formdata_h_value_f1 = substr($formdata_h_value[1], 0, $formdata_h_value_f);

		$fields[$formdata_h_name_f1] = $formdata_h_value_f1;
		
	}
		
	$fields["email"] = $email;
	
	foreach( $fields as $f ){
		$found = preg_match_all( '/\(awf_(.*?)\)/',$f,$patt);
		if( $found > 0 ){
			
			$fields["name (awf_first)"] = $fname;
			$fields["name (awf_last)"] = $lname;
		}
	}
	
	if( !isset( $fields["name (awf_first)"] ) ){
		$fields["name"] = $fname.' '.$lname;
	}
	
	$get_urlexp = explode("action='",$formdata);
	$get_url_pos = strpos($get_urlexp[1],"'");		
	
	$url = substr($get_urlexp[1],0,$get_url_pos);	
		
	$response = wp_remote_post(
		$url,
		array(
			'method' => 'POST',
			'timeout' => 45,
			'redirection' => 5,
			'httpversion' => '1.0',
			'blocking' => true,
			'headers' => array(),
			'body' => $fields,
			'cookies' => array()
		)
	);

?>