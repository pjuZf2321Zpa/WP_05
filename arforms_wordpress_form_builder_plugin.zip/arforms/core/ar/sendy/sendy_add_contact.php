<?php
global $email, $fname, $lname, $wpdb, $fid, $MdlDb ;
$res = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM ".$MdlDb->autoresponder." WHERE responder_id=%d",10)); //phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Reason: $MdlDb->autoresponder is table name defined globally. False Positive alarm 
$res = $res[0];
$responder_api_key = $res->responder_api_key;
$responder_api_url = $res->sendy_url;
$data = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM ".$MdlDb->ar." WHERE frm_id = %d", $fid), 'ARRAY_A' ); //phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Reason: $MdlDb->ar is table name defined globally. False Positive alarm 
$arr_sendy 	= arf_pro_maybe_unserialize( $data[0]['sendy'] );
$responder_list_id = isset($arr_sendy['type_val']) ? $arr_sendy['type_val'] : '';
if($responder_list_id !=''){
	$sendy_url = esc_url_raw( rtrim( $responder_api_url, '/' ) . '/subscribe' );
	if ( ! empty( $sendy_url ) && wp_http_validate_url( $sendy_url ) ) {
		$response = wp_safe_remote_post(
			$sendy_url,
			array(
				'method'  => 'POST',
				'timeout' => 45,
				'body'    => array(
					'name'    => $fname . ' ' . $lname,
					'email'   => $email,
					'list'    => $responder_list_id,
					'boolean' => 'true',
				),
			)
		);
		$result = ! is_wp_error( $response ) ? wp_remote_retrieve_body( $response ) : '';
	}
}
?>