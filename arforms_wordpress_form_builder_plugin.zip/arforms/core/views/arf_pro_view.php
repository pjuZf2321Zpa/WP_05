<?php
global $wpdb, $MdlDb, $armainhelper, $arformhelper, $arrecordhelper, $arrecordcontroller, $arfversion, $arfieldhelper, $arfsettings, $maincontroller, $arformsmain, $db_record, $arffield, $arfform, $arfpagesize, $arfpagesize2;
$arf_edit_select_array = array();

$arfdecimal_separator = $arfsettings->decimal_separator;

$wp_format_date = get_option( 'date_format' );

if ( $wp_format_date == 'F j, Y' ) {
	$date_format_new  = 'MMMM D, YYYY';
	$date_format_new1 = 'MMMM D, YYYY';
	$start_date_new   = 'January 01, 1970';
	$end_date_new     = 'December 31, 2050';
} elseif ( $wp_format_date == 'Y-m-d' ) {
	$date_format_new  = 'YYYY-MM-DD';
	$date_format_new1 = 'YYYY-MM-DD';
	$start_date_new   = '1970-1-1';
	$end_date_new     = '2050-12-1';
} elseif ( $wp_format_date == 'm/d/Y' ) {
	$date_format_new  = 'MM/DD/YYYY';
	$date_format_new1 = 'MM-DD-YYYY';
	$start_date_new   = '01/01/1970';
	$end_date_new     = '12/31/2050';
} elseif ( $wp_format_date == 'd/m/Y' ) {
	$date_format_new  = 'DD/MM/YYYY';
	$date_format_new1 = 'DD-MM-YYYY';
	$start_date_new   = '01/01/1970';
	$end_date_new     = '31/12/2050';
} elseif ( $wp_format_date == 'Y/m/d' ) {
	$date_format_new  = 'DD/MM/YYYY';
	$date_format_new1 = 'DD-MM-YYYY';
	$start_date_new   = '01/01/1970';
	$end_date_new     = '31/12/2050';
} else {
	$date_format_new  = 'MM/DD/YYYY';
	$date_format_new1 = 'MM-DD-YYYY';
	$start_date_new   = '01/01/1970';
	$end_date_new     = '12/31/2050';
}

$form_obj = new stdClass();
$form_obj->id = -1;

$params2 = $arrecordcontroller->get_params2($form_obj);

if( isset( $params2['incomplete_form'] ) && $params2['incomplete_form'] ){
    $form2 = $arfform->getOne( $params2['incomplete_form'] );
} else {
    $form2 = (isset($form_select[0])) ? $form_select[0] : 0;
}

if( $form2 ){
    $params2['incomplete_form'] = $form2->id;
    $arfcurrentform2 = $form2;
    $where_clause2 = " it.form_id=$form2->id";
} else {
    $where_clause2 = "";
}

$page_params2 = "&action=0&arfaction=0&form=";

$page_params2 .= ($form2) ? $form2->id : 0;

if (!empty($_REQUEST['s'])){
    $page_params2 .= '&s=' . urlencode($_REQUEST['s']);
}

if (!empty($_REQUEST['search'])){
    $page_params2 .= '&search=' . urlencode($_REQUEST['search']);
}

if (!empty($_REQUEST['fid'])){
    $page_params2 .= '&fid=' . $_REQUEST['fid'];
}

$item_vars2 = $arrecordcontroller->get_sort_vars($params2, $where_clause2);

$page_params2 .= !empty($page_params_ov) ? $page_parmas_ov : $item_vars2['page_params'];

$form_cols_order2 = array();
$arffieldorder2 = array();
$arfinnerfieldorder2 = array();
$form_inner_col_order2 = array();
$form_css2 = array();
$record_where2 = '';
if( $form2 ){
    
    $form_cols_temp2 = array();
    $form_cols2 = $arffield->getAll("fi.type not in ('divider', 'captcha', 'break', 'imagecontrol') and fi.form_id=" . (int) $form2->id, ' ORDER BY id');

    $cache_obj = wp_cache_get('arf_form_options_with_css_'.$form2->id);
    if($cache_obj == false){
        $form_options2 = $wpdb->get_row($wpdb->prepare("SELECT `form_css`,`options` FROM `" . $MdlDb->forms . "` WHERE `id` = %d", (int) $form2->id)); //phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Reason: $MdlDb->forms is table name defined globally. False Positive alarm
            
        wp_cache_set('arf_form_options_with_css_'.$form2->id, $form_options2);
    }else{
        $form_options2 = $cache_obj;
    }
    if(isset($form_options2->form_css) && $form_options2->form_css != ''){
        $form_css2 = arf_pro_maybe_unserialize($form_options2->form_css);
    }

    if(isset($form_options2->options) && $form_options2->options != ''){

        $form_options2 = arf_pro_maybe_unserialize($form_options2->options);

        if(isset($form_options2['arf_field_order']) && $form_options2['arf_field_order'] != ''){
            $form_cols_order2 = json_decode($form_options2['arf_field_order'], true);
            asort($form_cols_order2);
            $arffieldorder2 = $form_cols_order2;
        }

        if( isset( $form_options2['arf_inner_field_order'] ) && $form_options2['arf_inner_field_order'] != '' ){
            $form_inner_col_order2 = json_decode( $form_options2['arf_inner_field_order'], true );
            $arfinnerfieldorder2 = $form_inner_col_order2;
        }
    }

    foreach ($form_cols_order2 as $fieldkey2 => $fieldorder2) {
        foreach ($form_cols2 as $frmoptkey2 => $frmoptarr2) {
            $inside_repeater = ( isset( $frmoptarr2->field_options['parent_field_type'] ) && 'arf_repeater' == $frmoptarr2->field_options['parent_field_type'] ) ? true : false;

            $inside_html = ( isset( $frmoptarr2->field_options['enable_total'] ) && '0' == $frmoptarr2->field_options['enable_total'] ) ? true : false;
                
            if($frmoptarr2->id == $fieldkey2){
                if( $frmoptarr2->type != 'section' && $frmoptarr2->type != 'arf_accordion'){
                    $form_cols_temp2[] = $frmoptarr2;
                } else {
                    if( isset( $arfinnerfieldorder2[$frmoptarr2->id] ) ){
                        foreach( $arfinnerfieldorder2[$frmoptarr2->id] as $inner_field_order2 ){
                            $exploded_data2 = explode('|',$inner_field_order2);
                            $inner_field_id2 = (int)$exploded_data2[0];
                            foreach( $form_cols2 as $ifrmoptkey2 => $ifrmoptarr2 ){
                                if( $ifrmoptarr2->id == $inner_field_id2 ){
                                    $form_cols_temp2[] = $ifrmoptarr2;
                                    unset($form_cols2[$ifrmoptkey2]);
                                }
                            }
                        }
                    }
                }
                unset($form_cols2[$frmoptkey2]);
            } else {
                if( $inside_repeater ){
                    if( isset( $frmoptarr2->field_options['parent_field_type'] )  && $frmoptarr2->field_options['parent_field_type'] == 'arf_repeater' ){
                        unset( $form_cols2[$frmoptkey2] );
                    }
                }
                    if( $inside_html ){
                        unset( $form_cols2[$frmoptkey2] );
                }
            }
        }
    }

    $form_cols2 = array_values( $form_cols2 );

    if(count($form_cols_temp2) > 0) {
        if(count($form_cols2) > 0) {
            $form_cols_other2 = $form_cols2;
            $form_cols2 = array_merge($form_cols_temp2,$form_cols_other2);
        } else {
            $form_cols2 = $form_cols_temp2;
        }
    }

    $record_where2 = ($item_vars2['where_clause'] == " it.form_id=$form2->id") ? $form2->id : $item_vars2['where_clause'];

}

if( isset($_REQUEST['incomplete_form']) && $_REQUEST['incomplete_form'] == '-1' || ( !isset($_REQUEST['incomplete_form']) || empty( $_REQUEST['incomplete_form'] ) ) ){
    $form_cols2 = array();
    $items2 = array();
} else {
    $current_page2 = !empty($current_page_ov) ? $current_page_ov : $params2['paged'];
    $sort_str2 = $item_vars2['sort_str'];
    $sdir_str2 = $item_vars2['sdir_str'];
    $search_str2 = $item_vars2['search_str'];
    $fid2 = $item_vars2['fid'];
    $record_count2 = $db_record->getRecordCount($record_where2,true);
    $page_count2 = $db_record->getPageCount($arfpagesize2, $record_count2,true);
    $items2 = $db_record->getPage('', '', $item_vars2['where_clause'], $item_vars2['order_by'], '', $arffieldorder2, true);       
    $page_last_record2 = $armainhelper->getLastRecordNum($record_count2, $current_page2, $arfpagesize2);
    $page_first_record2 = $armainhelper->getFirstRecordNum($record_count2, $current_page2, $arfpagesize2);
}

$exclude_file_types_sorting = array('file','password','checkbox','arf_multiselect','image','signature', 'arf_matrix');
$_GET['incomplete_form'] = isset( $_GET['incomplete_form'] ) ? intval( $_GET['incomplete_form'] ) : -1;
$form_id2 = intval( $_GET['incomplete_form'] );
$exclude_from_sorting2 = array(0);
$actions = array(
    '-1' => addslashes( esc_html__( 'Bulk Actions', 'ARForms' ) ),
    'bulk_delete' => addslashes(esc_html__('Delete', 'ARForms'))
);


if( current_user_can('arfchangesettings') ){
    $actions['bulk_csv'] = addslashes(esc_html__('Export to CSV', 'ARForms'));
}

$actions = apply_filters( 'arf_entries_change_actions', $actions );

$inc_actions = array( '-1' => addslashes( esc_html__( 'Bulk Actions', 'ARForms' ) ),
                      'bulk_delete' => addslashes(esc_html__('Delete', 'ARForms')));
if( current_user_can('arfchangesettings') ){
    $inc_actions['bulk_csv'] = addslashes(esc_html__('Export to CSV', 'ARForms'));
    $inc_actions['move_to_entry'] = addslashes( esc_html__('Move to Entries', 'ARForms'));
}

$inc_actions = apply_filters( 'arf_incomplete_entries_change_actions', $inc_actions );

$tabview = ( isset( $_GET['tabview'] ) && ! empty( $_GET['tabview'] ) ) ? sanitize_text_field( $_GET['tabview'] ) : '';

if( isset($form2->id) && $form2->id == '-1' ){
    $form_cols2 = array();
    $items2 = array();
}

if( isset( $form2->id) && ('-1' != $form2->id || '' != $form2->id ) ){
    $form_cols2 = apply_filters('arfpredisplayformcolsincompleteentries', $form_cols2, $form2->id);
    $items2 = apply_filters('arfpredisplaycolsitemsincompleteenteries', $items2, $form2->id);

    $action_no2 = 0;

    $default_hide2 = array(
        '1' => 'ID',
    );

    if (count($form_cols2) > 0) {

        for ($i2 = 2; 1 + count($form_cols2) >= $i2; $i2++) {
            $j2 = $i2 - 2;
            if( '' == trim( $form_cols2[$j2]->name ) ){
                $form_cols2[$j2]->name = 'field_id:' . $form_cols2[$j2]->id;
            }
            $default_hide2[$i2] = $armainhelper->truncate($form_cols2[$j2]->name, 40);
            if( in_array( $form_cols2[$j2]->type, $exclude_file_types_sorting ) ){
                array_push($exclude_from_sorting2, $i2);
            }
        }
        $default_hide2[$i2] = 'Entry Key';
        $default_hide2[$i2 + 1] = 'Entry creation date';
        $default_hide2[$i2 + 2] = 'Browser Name';
        $default_hide2[$i2 + 3] = 'IP Address';
        $default_hide2[$i2 + 4] = 'Country';
        $default_hide2[$i2 + 5] = 'Page URL';
        array_push($exclude_from_sorting2, ($i2+5));
        $default_hide2[$i2 + 6] = 'Referrer URL';
        array_push($exclude_from_sorting2, ($i2+6));
        $default_hide2[$i2 + 7] = 'Action';
        array_push($exclude_from_sorting2, ($i2+7));
        $action_no2 = $i2 + 7;
    } else {
        $default_hide2['2'] = 'Entry Key';
        $default_hide2['3'] = 'Entry creation date';
        $default_hide2['4'] = 'Browser Name';
        $default_hide2['5'] = 'IP Address';
        $default_hide2['6'] = 'Country';
        $default_hide2['7'] = 'Page URL';
        array_push($exclude_from_sorting2, 7);
        $default_hide2['8'] = 'Referrer URL';
        array_push($exclude_from_sorting2, 8);
        $default_hide2['9'] = 'Action';
        array_push($exclude_from_sorting2, 9);
        $action_no2 = 9;
    }
    global $wpdb, $MdlDb;

    $page_params2 = "&action=0&arfaction=0&form=";

    $page_params2 .= ($form2) ? $form2->id : 0;

    if (!empty($_REQUEST['fid'])) {
        $page_params2 .= '&fid=' . $_REQUEST['fid'];
    }

    $item_vars2 = $arrecordcontroller->get_sort_vars($params2, $where_clause2);

    $page_params2 .= !empty($page_params_ov) ? $page_params_ov : $item_vars2['page_params'];

    if ($form2) {
        
    } else {
        $form_cols2 = array();
        $record_where2 = $item_vars2['where_clause'];
    }

    $columns_list_res2 = $wpdb->get_results( $wpdb->prepare( 'SELECT partial_grid_column_list FROM ' . $MdlDb->forms . ' WHERE id = %d', $form2->id ), ARRAY_A ); //phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Reason: $MdlDb->forms is table name defined globally. False Positive alarm

    $columns_list_res2 = $columns_list_res2[0];

    $columns_list2 = (!empty($columns_list_res2['partial_grid_column_list'])) ? arf_pro_maybe_unserialize($columns_list_res2['partial_grid_column_list']) : array();
    $is_colmn_array2 = is_array($columns_list2);

    $exclude2 = '';

    $exclude_array2 = array();
    if (count($columns_list2) > 0 and $columns_list2 != '') {

        foreach ($columns_list2 as $keys => $column2) {
            $exclude_no2 = 0;
            foreach ($default_hide2 as $key => $val) {

                if ($column2 == $val) {
                    if ($exclude_array2 == "") {
                        $exclude_array2[] = $key;
                    } else {
                        if (!in_array($key, $exclude_array2)) {
                            $exclude_array2[] = $key;
                            $exclude_no2++;
                        }
                    }
                }
            }
        }
    }

    $ipcolumn2 = ($action_no2 - 4);
    $page_url_column2 = ($action_no2 - 2);
    $referrer_url_column2 = ($action_no2 - 1);

    if ($exclude_array2 == "" and ! $is_colmn_array2) {
        $exclude_array2 = array($ipcolumn2, $page_url_column2, $referrer_url_column2);
    } else if (is_array($exclude_array2) and ! $is_colmn_array2) {
        if (!in_array($ipcolumn2, $exclude_array2)) {
            array_push($exclude_array2, $ipcolumn2);
        }
        if (!in_array($page_url_column2, $exclude_array2)) {
            array_push($exclude_array2, $page_url_column2);
        }
        if (!in_array($referrer_url_column2, $exclude_array2)) {
            array_push($exclude_array2, $referrer_url_column2);
        }
    }
} else {
    $action_no2 = 9;
    $exclude_array2 = array(5,7,8);
}

if (isset($exclude_array2) and $exclude_array2 != "") {
    $exclude2 = implode(",", $exclude_array2);
}
?> 
<input type="hidden" id="arforms_wp_nonce" value="<?php echo esc_attr(wp_create_nonce( 'arforms_wp_nonce' )); ?>" />
<?php

wp_enqueue_script('jquery');
wp_enqueue_script('jquery-ui-core');
wp_enqueue_style('bootstrap-editable-css', ARFURL . '/bootstrap/css/bootstrap-editable.css', array(), $arfversion);
wp_enqueue_script('bootstrap-editable-js', ARFURL . '/bootstrap/js/bootstrap-editable.js', array(), $arfversion);

    if( current_user_can('arfviewreports') ){ ?>
    <div id="analytics" style="padding-top: 50px;display:none;">
            <?php echo str_replace('{arf_id}','arf_graph_changes_loader',ARF_LOADER_ICON); ?>
            <table border="0" align="middle" class="arftalbespacing">
            <tr>
                <?php $form_id = isset($form_id) ? $form_id : ''; ?>
                <td align="left">
                    <div class="lblnotetitle arfselectformtitle"><?php echo addslashes(esc_html__('Select form', 'ARForms')); ?> :</div>
                    <div class="sltstandard" id="arfsltstandard_arfredirecttolist3" style="<?php echo (is_rtl()) ? 'float:right;' : 'float:left;';?>width:348px;"><?php $arformhelper->forms_dropdown('arfredirecttolist3', $form_id, addslashes(esc_html__('All Forms', 'ARForms')), false, ' change_graph_new( "monthly" , "1" ) '); ?></div></td>
                
                <?php
                if (is_rtl()) {
                    $analytic_time_label = 'float:right;';
                } else {
                    $analytic_time_label = 'float:left;';
                }
                ?>
                <td align="left"><div class="sltstandard" style=" <?php echo $analytic_time_label; ?>">
                        <div style=" <?php echo $analytic_time_label; ?>margin:0px 5px;">

                            <button id="daily_unselected" onclick="javascript:change_graph_new('daily');" class="btn_sld_daily"><?php echo addslashes(esc_html__('Daily', 'ARForms')); ?></button>
                            <button id="daily_selected" onclick="javascript:change_graph_new('daily');" class="btn_sld_daily_selected"><?php echo addslashes(esc_html__('Daily', 'ARForms')); ?></button>
                        </div>

                        <div style=" <?php echo $analytic_time_label; ?>margin:0px 5px;">

                            <button id="monthly_unselected" onclick="javascript:change_graph_new('monthly');" class="btn_sld_monthly"><?php echo addslashes(esc_html__('Monthly', 'ARForms')); ?></button>
                            <button id="monthly_selected" onclick="javascript:change_graph_new('monthly');" class="btn_sld_monthly_selected"><?php echo addslashes(esc_html__('Monthly', 'ARForms')); ?></button>
                        </div>
                        <div style=" <?php echo $analytic_time_label; ?>margin:0px 5px;">
                            <button id="yearly_unselected" onclick="javascript:change_graph_new('yearly');" class="btn_sld_yearly"><?php echo addslashes(esc_html__('Yearly', 'ARForms')); ?></button>
                            <button id="yearly_selected" onclick="javascript:change_graph_new('yearly');" class="btn_sld_yearly_selected"><?php echo addslashes(esc_html__('Yearly', 'ARForms')); ?></button>
                        </div>                                            
                        <input type="hidden" value="monthly" name="arfgraphval" id="arfgraphval" />
                    </div></td>
                <td align="left" style="<?php echo (is_rtl()) ? 'float:left;' : 'float:right;';?>">                                        
                    <div class="arfgraphtype" id="arfgraphtype_div_bar" onclick="change_graph_type('bar')"> 
                        <input type="radio" id="arfgraphtype_bar" value="bar" name="arfgraphtype">
                        <span class="arfgraphtype_span">
                            <svg width="30px" height="30px">
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M22.232,26.339V14.245h4.003v12.094H22.232z M15.237,7.345h4.003v18.994h-4.003 V7.345z M8.243,0.239h4.003v26.099H8.243V0.239z M1.248,10.159h4.004v16.128H1.248V10.159z"/>
                            </svg>
                        </span>
                        
                    </div>
                    <div class="arfgraphtype selected" id="arfgraphtype_div_line" onclick="change_graph_type('line')">
                        <input type="radio"  value="line" id="arfgraphtype_line" name="arfgraphtype" checked>
                        <span class="arfgraphtype_span">
                            <svg width="35px" height="35px">
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M26.835,8.673c-0.141,0-0.273-0.028-0.41-0.042l-3.493,8.709 c0.715,0.639,1.173,1.558,1.173,2.592c0,1.928-1.563,3.49-3.49,3.49s-3.49-1.563-3.49-3.49c0-0.395,0.08-0.768,0.201-1.122 l-5.351-7.229c-0.41,0.211-0.868,0.342-1.361,0.342c-0.074,0-0.143-0.017-0.215-0.022l-4.211,8.532 c0.258,0.442,0.417,0.949,0.417,1.498c0,1.652-1.339,2.991-2.991,2.991s-2.991-1.339-2.991-2.991s1.339-2.991,2.991-2.991 c0.35,0,0.68,0.071,0.992,0.182l3.957-8.021C7.986,10.557,7.621,9.79,7.621,8.933c0-1.652,1.34-2.992,2.992-2.992 s2.991,1.339,2.991,2.992c0,0.447-0.104,0.868-0.281,1.25l5.142,7.021c0.594-0.469,1.334-0.76,2.149-0.76 c0.218,0,0.429,0.026,0.636,0.064L24.6,8.01c-1.146-0.737-1.91-2.018-1.91-3.482c0-2.289,1.856-4.145,4.146-4.145 s4.146,1.856,4.146,4.145C30.98,6.817,29.124,8.673,26.835,8.673z"/>
                            </svg>
                        </span>
                    </div>
                    <div class="arfgraphtype" id="arfgraphtype_div_countries" onclick="change_graph_type('countries')">
                        <input type="radio" value="countries" id="arfgraphtype_countries" name="arfgraphtype">
                        <span class="arfgraphtype_span">
                            <svg width="30px" height="30px">
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M17.155,25.972l0.236-0.858l2.226-1.485l0.584-1.591l1.539-0.714l1.457-2.785 l-2.254-1.326l-1.166-1.326l-0.69-0.08l-1.377-0.372l-1.189-0.188l-1.039,0.292l-0.637-0.714l-0.638-0.186l0.054-0.954l-0.77,0.025 l-0.438,0.504l-0.251-1.061l1.006-0.478l1.036,0.478h0.555l0.202-0.822l1.55-1.857l2.15-1.086l1.244,0.159l0.113-0.608 l-1.543-1.565l-0.584-1.166h-0.85l-0.531-0.311L16.01,5.729l-0.238,1.355l-1.381-0.266L14.287,5.97l1.06-0.24l0.35-1.52 l1.052,0.433l-0.026,0.646l0.802,0.334l0.535,0.158l0.658-0.344l-0.585-0.688l-1.195-1.166l0.028-0.559l1.221,0.239l1.034,0.927 l0.318,0.823l0.239,0.771l1.646,1.483l0.422,0.135l0.584-0.933l2.068-0.184l0.388-0.123c1.386,2.062,2.194,4.546,2.194,7.215 C27.079,19.49,22.844,24.602,17.155,25.972z M17.893,1.534l-0.9,0.601l-0.637,0.704l-2.317,0.217l-0.954-0.157L12.43,3.927 l-1.908,0.105L9.327,3.688L8.264,4.27L5.96,4.591L4.114,5.125H4.107c2.377-2.88,5.977-4.715,10.003-4.715 c1.977,0,3.843,0.457,5.521,1.246l-0.465,0.07L17.893,1.534z M12.083,1.806l-0.765,0.243l-0.585-0.243 c-0.019,0.154-0.85,0.689-0.85,0.689l0.85,0.497l1.768-0.464L12.083,1.806z M15.983,0.97l-1.325,0.729l-0.761,0.474l0.529,0.343 l1.175-0.118l1.232-0.937L15.983,0.97z M3.653,7.851H5.11l2.163-0.386l1.363,2.214v2.07l1.859,2.521h0.315v-0.89l0.716,1.498 l2.157,0.483l0.974,0.977l0.866,0.26l-0.866,1.807l0.945,1.751c0,0,0.593,2.014,0.595,2.095c0,0.079-0.595,2.413-0.595,2.413 l0.135,1.571c-0.535,0.065-1.076,0.112-1.628,0.112c-7.163,0-12.97-5.807-12.97-12.968c0-2.387,0.655-4.615,1.781-6.536 l0.933-0.216L2.918,7.37L3.653,7.851z"/>
                            </svg>
                        </span>
                    </div>                                      
                </td>
            </tr>
        </table>
        <style type="text/css">
            .jqplot-xaxis { font-weight:bold; }
            .jqplot-yaxis { font-weight:bold; }
            .jqplot-highlighter { background-color:#333333; opacity:.70; filter:Alpha(Opacity=70); color:#FFFFFF; }
            .jqplot-highlighter .tooltip_title {font-weight:bold; color:#FFFFFF; width:50px; font-size:12px; }
            .jqplot-highlighter .tooltip_title1 {font-weight:bold; color:#FFFFFF; width:60px; font-size:12px; }
        </style>
        <div id="chart_div">
            <div id="daily" style="padding:15px;">
                <label class="lbltitle">Daily chart</label><br />

                <div id="chart2" style="width:100%;height:300px;margin-top: 30px;margin-left: 6px;" ></div>

            </div>

            <div id="monthly" style="padding:15px; display:none;">
                <label class="lbltitle">Month chart</label><br />

                <div id="chart1" style="width:100%;height:300px;margin-top: 30px;margin-left: 6px;" ></div>

            </div>

            <div id="weekly" style="padding:15px; display:none;"} ?>">
                <label class="lbltitle">Weekly chart</label><br />

                <div id="chart3" style="width:100%;height:300px;margin-top: 30px;margin-left: 6px;" ></div>

            </div>

            <div id="yearly" style="padding:15px; display:none;">
                <label class="lbltitle">Yearly chart</label><br />

                <div id="chart4" style="width:100%;height:300px;margin-top: 30px;margin-left: 6px;" ></div>

            </div>
            <span class="lbltitle next_chart">Previous</span> <span class="lbltitle next_chart">Next</span>
            <br /><br />


        </div>
    </div>
    <?php } if( current_user_can('arfviewincompleteentries') ){ ?>
    <div id="form_incomplete_entries" class="frm_incomplete_entries_page" style="padding-top: 50px; display:none;">
    <input type="hidden" id="data_array_size" value="<?php echo count( $items2 ); ?>" />
    <input type="hidden" id="form_id" value="<?php echo $form_id2; ?>" />
    <input type="hidden" id="date_format_new" value="<?php echo $date_format_new; ?>" />
    <input type="hidden" id="locale" value="<?php echo isset( $options['locale'] ) ? $options['locale'] : ''; ?>" />
    <input type="hidden" id="start_date_new" value="<?php echo $start_date_new; ?>" />
    <input type="hidden" id="end_date_new" value="<?php echo $end_date_new; ?>" />
    <input type="hidden" id="date_format_new1" value="<?php echo $date_format_new1; ?>" />
    <input type="hidden" id="action_no" value="<?php echo $action_no2; ?>" />
    <input type="hidden" id="exclude" value="<?php echo $exclude2; ?>" />
    <input type="hidden" id="arf_incomplete_entries_exclude_cols" value="<?php echo json_encode( $exclude_from_sorting2 ); ?>"/>
    <div class="arf_form_entry_select">
        <table class="arf_form_entry_select_sub">
            <tr>
                <th class="arf_form_entry_left" style="float:none;<?php (is_rtl())? 'text-align:right;' : 'text-align:left;';?>"><?php echo addslashes(esc_html__("Select form", 'ARForms')); ?></th>
                <th class="arf_form_entry_left"><?php echo addslashes(esc_html__('Select Date', 'ARForms')); ?> (<?php echo addslashes(esc_html__('optional', 'ARForms')); ?>)</th>
            </tr>
            <tr>
                <td><div class="sltstandard" style="float:none; width: 400px !important;<?php echo (is_rtl())? 'margin-left:60px;' : 'margin-right:60px;';?>margin-top:-16px;"><?php $arformhelper->forms_dropdown_incomplete_entries('arfredirecttolist2', $_GET['incomplete_form'], addslashes(esc_html__('Select Form', 'ARForms')), false, ""); ?></div></td>
                <td>
                    <?php
                        if (is_rtl()) {
                            $sel_frm_date_wrap = 'float:right;text-align:right;';
                            $sel_frm_sel_date = 'float:right;';
                            $sel_frm_button = 'float:right;';
                        } else {
                            $sel_frm_date_wrap = 'float:left;text-align:left;';
                            $sel_frm_sel_date = 'float:left;';
                            $sel_frm_button = 'float:left;';
                        }
                        ?>
                        <div style="position:relative; <?php echo $sel_frm_date_wrap; ?>">
                            <?php 
                                $arf_start_date = isset($_GET['start_date2']) ? sanitize_text_field($_GET['start_date2']) : '';
                                $arf_end_date = isset($_GET['end_date2']) ? sanitize_text_field($_GET['end_date2']) : '';
                            ?>
                            <div style="<?php echo $sel_frm_sel_date; ?>position: relative;"><div class="arfentrytitle" style='margin-left:0;'><?php echo addslashes(esc_html__('From', 'ARForms')); ?></div><input type="text" class="txtmodal1" value="<?php echo $arf_start_date; //phpcs:ignore ?>" id="datepicker_from2" name="datepicker_from2" style="width:142px;height:37px;vertical-align:middle;box-sizing: border-box; -webkit-box-sizing: border-box; -moz-box-sizing: border-box; -o-box-sizing: border-box;" /></div> <div class="arfentrytitle"><?php echo addslashes(esc_html__('To', 'ARForms')); ?></div>&nbsp;&nbsp;<div style="<?php echo $sel_frm_sel_date; ?>position: relative;"><input type="text" class="txtmodal1" value="<?php echo $arf_end_date; //phpcs:ignore ?>" id="datepicker_to2" name="datepicker_to2" style="vertical-align:middle; width:142px;height:37px;box-sizing: border-box;-webkit-box-sizing: border-box; -moz-box-sizing: border-box; -o-box-sizing: border-box;"/></div>
                            <div style=" <?php echo esc_html($sel_frm_button); ?>">
                                <div class="arf_form_entry_left">&nbsp;</div>
                                <div style="float:left;text-align:left;"><button type="button" class="rounded_button arf_btn_dark_blue" onclick="change_frm_entries2();" style="width: 35px !important;height: 35px;"><?php echo addslashes(esc_html__('Go', 'ARForms')); ?></button></div>
                            </div>
                            <input type="hidden" name="please_select_form" id="please_select_form" value="<?php echo addslashes(esc_html__('Please select a form', 'ARForms')); ?>" />
                        </div>
                </td>
            </tr>
        </table>
    </div>
    <div style="clear:both; height:30px;"></div>
    <?php
    do_action('arfbeforelistingincompleteentries');
    $inc_dt_no_data = '';
    if( count($items2) < 1 ){
        $inc_dt_no_data = ' arf_entry_empty_table ';
    }
    ?>
        <form method="post" id="list_incomplete_entry_form" class="arf_list_entries_form <?php echo $inc_dt_no_data; ?>" onsubmit="return apply_bulk_action2()" style="float:left;width:98%;padding-left: 15px;">
        <input type="hidden" name="incomplete_form" value="<?php echo !empty($form) ? $form->id : '-1'; ?>" />
        <input type="hidden" name="arfaction" value="list" />
        <input type="hidden" name="show_hide_columns" id="show_hide_columns" value="<?php echo addslashes(esc_html__('Show / Hide columns', 'ARForms')); ?>"/>
        <input type="hidden" name="search_grid" id="search_grid" value="<?php echo addslashes(esc_html__('Search', 'ARForms')); ?>"/>
        <input type="hidden" name="entries_grid" id="entries_grid" value="<?php echo addslashes(esc_html__('entries', 'ARForms')); ?>"/>
        <input type="hidden" name="show_grid" id="show_grid" value="<?php echo addslashes(esc_html__('Show', 'ARForms')); ?>"/>
        <input type="hidden" name="showing_grid" id="showing_grid" value="<?php echo addslashes(esc_html__('Showing', 'ARForms')); ?>"/>
        <input type="hidden" name="to_grid" id="to_grid" value="<?php echo addslashes(esc_html__('to', 'ARForms')); ?>"/>
        <input type="hidden" name="of_grid" id="of_grid" value="<?php echo addslashes(esc_html__('of', 'ARForms')); ?>"/>
        <input type="hidden" name="no_match_record_grid" id="no_match_record_grid" value="<?php echo addslashes(esc_html__('No matching records found', 'ARForms')); ?>"/>
        <input type="hidden" name="no_record_grid" id="no_record_grid" value="<?php echo addslashes(esc_html__('No data available in table', 'ARForms')); ?>"/>
        <input type="hidden" name="filter_grid" id="filter_grid" value="<?php echo addslashes(esc_html__('filtered from', 'ARForms')); ?>"/>
        <input type="hidden" name="totalwd_grid" id="totalwd_grid" value="<?php echo addslashes(esc_html__('total', 'ARForms')); ?>"/>

        <div class="alignleft actions">
            <div class="arf_list_bulk_action_wrapper">
                <?php

                    $arf_change_the_list_action = array( 'onchange' => 'change_inc_listaction(this.value);');
                    echo $maincontroller->arf_selectpicker_dom( 'action3', 'arf_inc_bulk_action_one', '', '', '', $arf_change_the_list_action, $inc_actions );
                ?>
            </div>
            <input type="submit" id="doaction3" class="arf_bulk_action_btn rounded_button btn_green" value="<?php echo addslashes(esc_html__('Apply', 'ARForms')); ?>" />
        </div>

        <table cellpadding="0" cellspacing="0" border="0" class="display table_grid import_export_entries" id="example2">
            <thead>
                <tr>
                    <th class="box">
                        <div style="display:inline-block; position:relative;">
                            <div class="arf_custom_checkbox_div arfmarginl15">
                                <div class="arf_custom_checkbox_wrapper">
                                    <input id="cb-select-all-1" type="checkbox" class="">
                                    <svg width="18px" height="18px">
                                    <?php echo ARF_CUSTOM_UNCHECKED_ICON; ?>
                                    <?php echo ARF_CUSTOM_CHECKED_ICON; ?>
                                    </svg>
                                </div>
                            </div>

                            <label for="cb-select-all-1"  class="cb-select-all"><span class="cb-select-all-checkbox"></span></label>
                        </div>
                    </th>
                    <th><?php echo addslashes(esc_html__('ID', 'ARForms')); ?></th>
                    <?php
                    if (count($form_cols2) > 0) {
                        foreach ($form_cols2 as $col2) {
                            ?>
                            <th><?php echo $armainhelper->truncate($col2->name, 40) ?></th>
                            <?php
                        }
                    }
                    ?>
                    <th><?php echo esc_html__('Entry Key', 'ARForms'); ?></th>
                    <th><?php echo addslashes(esc_html__('Entry creation date', 'ARForms')); ?></th>
                    <th><?php echo addslashes(esc_html__('Browser Name', 'ARForms')); ?></th>
                    <th><?php echo addslashes(esc_html__('IP Address', 'ARForms')); ?></th>
                    <th><?php echo addslashes(esc_html__('Country', 'ARForms')); ?></th>
                    <th><?php echo esc_html__('Page URL', 'ARForms'); ?></th>
                    <th><?php echo addslashes(esc_html__('Referrer URL', 'ARForms')); ?></th>
                    <th class="arf_col_action arf_action_cell"><?php echo addslashes(esc_html__('Action', 'ARForms')); ?></th>
                </tr>
            </thead>
            <tbody>
                <script type="text/javascript" data-cfasync="false">
                    function ChangeID(id)
                    {
                        document.getElementById('delete_entry_id').value = id;
                    }
                </script>
            </tbody>
        </table>
        <div class="alignleft actions">
            <div class="arf_list_bulk_action_wrapper">
                <?php

                    $arf_change_the_list_action = array( 'onchange' => 'change_inc_listaction(this.value);');
                    echo $maincontroller->arf_selectpicker_dom( 'action4', 'arf_inc_bulk_action_two', '', '', '', $arf_change_the_list_action, $inc_actions );
                ?>
            </div>
            <input type="submit" id="doaction4" class="arf_bulk_action_btn rounded_button btn_green" value="<?php echo addslashes(esc_html__('Apply', 'ARForms')); ?>"/>
        </div>
        <div class="footer_grid"></div>
    </form>
</div>
<?php } ?>

<div class='arf_modal_overlay'>
    <div class="arf_entry_popup_container_wrapper">
        <div class='arf_popup_container arf_repeater_view_entry_modal arf_popup_container_view_entry_modal'>
            <div class='arf_popup_container_header'><?php echo esc_html__('View entry', 'ARForms'); ?> <span id="arf_view_entry_modal_form_title"></span>
                
                <div class="arf_modal_close_btn arf_repeater_entry_model_close"></div> 
            </div>
            <div class='arfentry_modal_content arf_popup_content_container'></div>
            <div class="arf_popup_footer arf_view_repeater_entry_modal_footer">
                <?php if( current_user_can('arfeditentries') ){ ?>
                <button class="rounded_button arf_btn_dark_blue" id="arf_update_entry_button" style="<?php echo (is_rtl()) ? 'margin-left:7px;' : 'margin-right:7px;';?>" name="arf_update_entry_button"><?php echo addslashes(esc_html__('Update','ARForms')); ?></button>
                <?php } ?>
                <button class="rounded_button" id="arf_repeater_entry_popup_close_btn" style="color:#666666;" name="arf_entry_popup_close_btn"><?php echo addslashes(esc_html__('Cancel','ARForms')); ?></button>
            </div>
        </div>
    </div>
</div>

<div class='arf_modal_overlay'>
    <div class="arf_entry_popup_container_wrapper">
        <div class='arf_popup_container arf_matrix_view_entry_modal arf_popup_container_view_entry_modal'>
            <div class='arf_popup_container_header'><?php echo esc_html__('View entry', 'ARForms'); ?> <span id="arf_view_entry_modal_form_title"></span>
                <div class="arf_modal_close_btn arf_matrix_entry_model_close"></div> 
            </div>
            <div class='arfentry_modal_content arf_popup_content_container'></div>
            <div class="arf_popup_footer arf_view_matrix_entry_modal_footer">
                <?php if( current_user_can('arfeditentries') ){ ?>
                <button class="rounded_button arf_btn_dark_blue" id="arf_update_entry_button" style="<?php echo (is_rtl()) ? 'margin-left:7px;' : 'margin-right:7px;';?>" name="arf_update_entry_button"><?php echo addslashes(esc_html__('Update','ARForms')); ?></button>
                <?php } ?>
                <button class="rounded_button" id="arf_matrix_entry_popup_close_btn" style="color:#666666;" name="arf_entry_popup_close_btn"><?php echo addslashes(esc_html__('Cancel','ARForms')); ?></button>
            </div>
        </div>
    </div>
</div>

<div class='arf_modal_overlay'>
    <div class="arf_incomplete_entry_popup_container_wrapper">
        <div class='arf_popup_container arf_view_incomplete_entry_modal arf_popup_container_view_entry_modal'>
            <div class='arf_popup_container_header'><?php echo esc_html__('View Partial entry', 'ARForms'); ?> <span id="arf_view_incomplete_entry_modal_form_title"></span>
                
                <div class="arf_modal_close_btn arf_entry_model_close"></div> 
            </div>
            <div class='arfincompleteentry_modal_content arf_popup_content_container'></div>
            <div class="arf_popup_footer arf_view_incomplete_entry_modal_footer">
                <div class="arf_navigation_button">
                    <button class="rounded_button arf_btn_dark_blue" id="arf_prev_incomplete_entry_button" name="arf_prev_incomplete_entry_button" style="<?php echo (is_rtl()) ? 'margin-left:7px;' : 'margin-right:7px;';?>"><?php echo addslashes(esc_html__('Previous Entry','ARForms')); ?></button>

                    <button class="rounded_button arf_btn_dark_blue" id="arf_next_incomplete_entry_button" name="arf_next_incomplete_entry_button"><?php echo addslashes(esc_html__('Next Entry','ARForms')); ?></button>
                </div>
                
                <button class="rounded_button" id="arf_entry_popup_close_btn" style="color:#666666;" name="arf_entry_popup_close_btn"><?php echo addslashes(esc_html__('Cancel','ARForms')); ?></button>
            </div>
        </div>
    </div>
</div>

<div class="arf_modal_overlay">
    <div id="delete_bulk_incomplete_entry_message" class="arfdeletemodabox arfdelete_model_box_incomplete arfmodal arf_popup_container arfdeletemodalboxnew">
        <input type="hidden" value="false" id="delete_bulk_entry_flag"/>
        <div class="arfdelete_modal_msg delete_confirm_message"><?php echo esc_html__( 'Are you sure you want to delete this entries?', 'ARForms' ); ?></div>
        <div class="arf_delete_modal_row delete_popup_footer">
            <button class="rounded_button add_button arf_delete_modal_left arfdelete_color_red" onclick="arf_delete_bulk_incomplete_entries(true)">&nbsp;<?php echo esc_html__( 'Okay', 'ARForms' ); ?></button>&nbsp;&nbsp;<button class="arf_delete_modal_right rounded_button delete_button arfdelete_color_gray arf_bulk_delete_incomplete_entry_close_btn" data-dismiss="arfmodal">&nbsp;<?php echo esc_html__( 'Cancel', 'ARForms' ); ?></button>
        </div>
    </div>
</div>


<input type="hidden" id="arf_is_edit_entries" value="no" />
<input type="hidden" id="arf_is_repeater_edit_entries" value="no" />
<input type="hidden" id="arf_is_matrix_edit_entries" value="no" />
<input type="hidden" id="arf_is_file_upload_edit_entries" value="no" />
    
<script type="text/javascript">

    jQuery(document).ready(function () {

        <?php if ($tabview == 'analytics') { ?>
            show_form_settimgs('analytics', 'form_entries', 'form_incomplete_entries');
        <?php } else if( $tabview == 'form_incomplete_entries') { ?>
            show_form_settimgs('form_incomplete_entries', 'analytics', 'form_entries');
        <?php } else { ?>
            show_form_settimgs('form_entries', 'analytics', 'form_incomplete_entries');
        <?php } ?>

        if (typeof arf_edit_entries_in_viewmodel != "function") {
                return;
            }
        arf_edit_entries_in_viewmodel();
    });
</script>