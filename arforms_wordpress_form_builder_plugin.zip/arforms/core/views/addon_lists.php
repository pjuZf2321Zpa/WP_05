<?php
global $arformcontroller,$arformsplugin;
$setvaltolic = 0;
$setvaltolic = $arformcontroller->$arformsplugin();
?>
<div class="wrap arfforms_page">
    <div class="top_bar" style="margin-bottom: 10px;">
	<span class="h2"> <?php echo addslashes(esc_html__('ARForms Add-Ons','ARForms')); ?></span>
    </div>
    <div id="error_message" class="arf_error_message">
		<div class="message_descripiton">
			<div style="float: left; margin-right: 15px;" id="records_error_message_des"></div>
			<div class="message_svg_icon">
				<svg style="height: 14px;width: 14px;"><path fill-rule="evenodd" clip-rule="evenodd" fill="#ffffff" d="M10.702,10.909L6.453,6.66l-4.249,4.249L1.143,9.848l4.249-4.249L1.154,1.361l1.062-1.061l4.237,4.237l4.238-4.237l1.061,1.061L7.513,5.599l4.249,4.249L10.702,10.909z"></path></svg>
			</div>
		</div>
	</div>
    <input type="hidden" name="arforms_validation_nonce" id="arforms_validation_nonce" value="<?php echo esc_attr( wp_create_nonce( 'arf_wp_nonce' ) ); ?>" />
	<?php
    if ($setvaltolic != 1) {
        $admin_css_url = admin_url('admin.php?page=ARForms-license');
        ?>

        <div style="margin-top:20px;margin-bottom:10px;border-left: 4px solid #ffba00;box-shadow: 0 1px 1px 0 rgba(0, 0, 0, 0.1);height:20px;width:99%;padding:10px 0px 10px 25px;background-color:#f2f2f2;color:#000000;font-size:17px;display:block;visibility:visible;text-align:left;" >ARForms License is not activated. Please activate license from <a href="<?php echo $admin_css_url; ?>">here</a></div>
    <?php } ?>
	<div id="poststuff" class="">
    	<div id="post-body" >
        	<div class="addon_content">
                <?php
                    do_action('arf_addon_page_retrieve_notice');
                ?>
                <div class="addon_page_content">
					<?php
						global $arsettingcontroller;
						$arsettingcontroller->addons_page();
					?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php do_action( 'arforms_quick_help_links'); ?>