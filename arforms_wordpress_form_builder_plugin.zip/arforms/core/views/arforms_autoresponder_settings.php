<?php

global $current_user, $arformcontroller, $maincontroller, $wpdb, $MdlDb;

global $arformcontroller,$arformsplugin;
$setvaltolic = 0;
$setvaltolic = $arformcontroller->$arformsplugin();

$setting_tab = get_option('arforms_current_tab');
$setting_tab = (!isset($setting_tab) || empty($setting_tab) ) ? 'general_settings' : $setting_tab;

$autores_type = get_option('arf_ar_type');
$default_ar = arf_pro_maybe_unserialize(get_option('arfdefaultar'));


$autoresponder_all_data_query = $wpdb->get_results("SELECT * FROM " . $MdlDb->autoresponder); //phpcs:ignore

$mailchimp_data = $autoresponder_all_data_query[0];
$aweber_data = $autoresponder_all_data_query[2];
$getresponse_data = $autoresponder_all_data_query[3];
$icontact_data = $autoresponder_all_data_query[7];
$constant_data = $autoresponder_all_data_query[8];

?>
<div id="autoresponder_settings" style=" <?php if ($setting_tab != 'autoresponder_settings') echo 'display:none;'; ?> background-color:#FFFFFF; padding-top:10px; border-radius:5px 5px 5px 5px;-webkit-border-radius:5px 5px 5px 5px;-o-border-radius:5px 5px 5px 5px;-moz-border-radius:5px 5px 5px 5px; padding-left: 20px; padding-top: 30px; padding-bottom:1px;">

<input type="hidden" name="arf_validation_nonce" id="arf_validation_nonce" value="<?php echo esc_attr( wp_create_nonce( 'arf_wp_nonce' ) ); ?>" />

    <span class="fa-life-bouy-span">
        <a onclick="arf_help_doc_fun('arf_options_email_marketing');" target="_blank" title="" class="fas fa-life-bouy arf_adminhelp_icon">
            <svg width="30px" height="30px" viewBox="0 0 26 32" class="arfsvgposition arfhelptip tipso_style" data-tipso="help" title="help">
            <?php echo ARF_LIFEBOUY_ICON; //phpcs:ignore ?>
            </svg>
        </a>
    </span>

    <table class="wp-list-table widefat post " style="margin:0px 0 0 10px; border:none;">
        <tr>
            <th style="background:none; border:0px;" width="18%">&nbsp;</th>
            <th style="background:none; border:0px;height:98px;" colspan="2"><img alt='' src="<?php echo ARFURL; ?>/images/aweber.png" align="absmiddle" /></th>
        </tr>
        <tr>
            <?php $autores_type['aweber_type'] = ($autores_type['aweber_type'] != '') ? $autores_type['aweber_type'] : 1; ?>
            <th style="background:none; border:0px;" width="18%">&nbsp;</th>
            <th id="th_aweber" style=" background:none; border:none; <?php if ($autores_type['aweber_type'] == 2) { echo 'padding-left: 5px;'; } else { echo 'padding-left: 5px;'; } ?>">
                <div class="arf_radio_wrapper">
                    <div class="arf_custom_radio_div" >
                        <div class="arf_custom_radio_wrapper">
                            <input type="radio" class="arf_submit_action arf_custom_radio" id="aweber_1" <?php if ($autores_type['aweber_type'] == 1) echo 'checked="checked"'; ?> name="aweber_type" value="1" style="margin-top:3px;" onclick="show_api('aweber');"  />
                            <svg width="18px" height="18px">
                                <?php echo ARF_CUSTOM_UNCHECKEDRADIO_ICON; ?>
                                <?php echo ARF_CUSTOM_CHECKEDRADIO_ICON; ?>
                            </svg>
                        </div>
                    </div>
                    <span>
                        <label for="aweber_1"><?php echo esc_html__('Using API', 'ARForms'); ?></label>
                    </span>
                </div>
                <div class="arf_radio_wrapper">
                    <div class="arf_custom_radio_div" >
                        <div class="arf_custom_radio_wrapper">
                            <input type="radio" class="arf_submit_action arf_custom_radio" id="aweber_2" <?php if ($autores_type['aweber_type'] == 0) echo 'checked="checked"'; ?> name="aweber_type" value="0" style="margin-top:3px;" onclick="show_web_form('aweber');" />
                            <svg width="18px" height="18px">
                                <?php echo ARF_CUSTOM_UNCHECKEDRADIO_ICON; ?>
                                <?php echo ARF_CUSTOM_CHECKEDRADIO_ICON; ?>
                            </svg>
                        </div>
                    </div>
                    <span>
                        <label for="aweber_2"><?php echo addslashes(esc_html__('Using Web-form', 'ARForms')); ?></label>
                    </span>
                </div>
                <input type="hidden" name="aweber_status" id="aweber_status" value="<?php echo $aweber_data->is_verify; ?>" />
            </th>
        </tr>
        <?php
            $is_aweber_old = false;
            if( ($aweber_data->consumer_key != '' && $aweber_data->consumer_secret != '' && ($aweber_data->consumer_key != ARF_AWEBER_CONSUMER_KEY || $aweber_data->consumer_secret != ARF_AWEBER_CONSUMER_SECRET)) ){
                $is_aweber_old = true;
            }
        ?>
        <tr id="aweber_api_tr2" <?php if ($aweber_data->is_verify == '1' && false == $is_aweber_old ) { echo 'style="display:none;"'; } else if ($autores_type['aweber_type'] != 1) { echo 'style="display:none;"'; } ?>>
            <td class="tdclass" style="width:18%; padding-right:20px; padding-bottom:3px; text-align: left;">
                <label class="lblsubtitle"><?php esc_html_e('Authorization Code', 'ARForms'); ?></label>
            </td>
            <td style="padding-left: 4px;">
                <input type="text" name="aweber_oauth_code" class="txtmodal1" id="aweber_api" size="80" value="<?php echo esc_attr($aweber_data->responder_api_key); ?>" />&nbsp;&nbsp;
                <span id="aweber_link"><a href="javascript:void(0);" onclick="aweber_continue('<?php echo esc_js( wp_nonce_url( get_home_url() . '?arf_page=arfawb_config', 'arf_aweber_auth_action' ) ); ?>');" class="arlinks"><?php esc_html_e('Get Authorization Code','ARForms'); ?></a></span>
                <input type="hidden" name="aweber_status" id="aweber_status" value="<?php echo $aweber_data->is_verify; ?>" />
                <div class="arferrmessage" id="aweber_api_error" style="display:none;"><?php echo addslashes(esc_html__('This field cannot be blank.', 'ARForms')); ?></div></td>
            </td>
        </tr>
        <tr id="aweber_api_tr3" <?php if ($aweber_data->is_verify == '1' && false == $is_aweber_old ) { echo 'style="display:none;"'; } else if ($autores_type['aweber_type'] != 1) { echo 'style="display:none;"'; } ?>>
            <td class="tdclass" style="padding-left:20px; text-align:left; width:18%;">&nbsp;</td>
            <?php
                $aweber_onclick = 'verify_autores(\'aweber\', \'0\')';
                if( $setvaltolic != 1 ){
                    $aweber_onclick = 'alert(\'Please activate license to authorize Aweber app\');';
                }
            ?>
            <td style="padding-left:4px;">
                <button class="rounded_button arf_btn_dark_blue"  style="width:103px !important; border:0px; color:#FFFFFF; height:41px;" type="button" name="continue" onclick="<?php echo $aweber_onclick; ?>"><?php echo addslashes(esc_html__('Authorize', 'ARForms')); ?></button>
                <span id="aweber_loader"><div class="arf_imageloader"></div></span>
                <span id="aweber_error" class="frm_not_verify_li" style="display:none;"><?php echo addslashes(esc_html__('Not Verified', 'ARForms')); ?></span>
            </td>
        </tr>

        <tr id="aweber_web_form_tr" <?php if ($autores_type['aweber_type'] != 0) echo 'style="display:none;"'; ?>>

            <td class="tdclass" style="padding-right:20px; text-align:left; width:18%;"><label class="lblsubtitle"><?php echo addslashes(esc_html__('Webform code from Aweber', 'ARForms')); ?></label></td>

            <td style="padding-left:5px;">

                <textarea <?php if ($setvaltolic != 1) { echo "readonly=readonly"; } ?> name="aweber_web_form" id="aweber_web_form" class="txtmultinew" <?php if ($setvaltolic != 1) { ?> onclick="alert('Please activate license to set aweber settings');" <?php } ?>><?php echo esc_textarea( stripslashes($aweber_data->responder_web_form) ); ?></textarea>


            </td>

        </tr>


        <?php if ($aweber_data->responder_list_id != "" && false == $is_aweber_old ) { ?>


            <tr id="aweber_api_tr4" <?php if ($autores_type['aweber_type'] != 1) echo 'style="display:none;"'; ?>>


                <td class="tdclass" style="padding-right:20px; text-align:left; width:18%;"><label class="lblsubtitle"><?php echo addslashes(esc_html__('AWEBER LIST', 'ARForms')); ?></label></td>


                <td style="padding-left:5px; overflow: visible;">

                    <span id="select_aweber">
                        <div class="sltstandard" style="float:none; display:inline;">
                            


                            <?php
                            $aweber_lists = explode("-|-", $aweber_data->responder_list_id);


                            $aweber_lists_name = explode("|", $aweber_lists[0]);


                            $aweber_lists_id = explode("|", $aweber_lists[1]);


                            $i = 0;

                            $aweber_responder_list_option = array();
                            $aweber_responder_list_opt_attr = array();
                            foreach ($aweber_lists_name as $aweber_lists_name1) {


                                if ($aweber_lists_id[$i] != "") {
                                    if ($aweber_lists_id[$i] == $aweber_data->responder_list) {
                                        $selected_list_id = $aweber_lists_id[$i];
                                        $selected_list_label = $aweber_lists_name1;
                                    }
                                    
                                    $aweber_responder_list_option[$aweber_lists_id[$i]] = $aweber_lists_name1;

                                    $aweber_responder_list_opt_attr['value'][$aweber_lists_id[$i]] = $aweber_lists_id[$i];
                                } 
                                $i++;
                            }

                            echo $maincontroller->arf_selectpicker_dom( 'responder_list', 'aweber_listid', '', 'width:400px;', $selected_list_id, array(), $aweber_responder_list_option, false, array(), false, $aweber_responder_list_opt_attr, false, array(), true );
                            ?>

                            <span id="aweber_loader2"><div class="arf_imageloader"></div></span>
                        </div>

                    </span>

                    <div style="padding-left:5px; margin-top: 10px; clear: both;" class="arlinks">
                        <a href="javascript:void(0);" onclick="action_aweber('refresh');"><?php echo addslashes(esc_html__('Refresh List', 'ARForms')); ?></a>
                        &nbsp;  &nbsp;  &nbsp;  &nbsp;
                        <a href="javascript:void(0);" onclick="action_aweber('delete');"><?php echo addslashes(esc_html__('Delete Configuration', 'ARForms')); ?></a>
                    </div>


                </td>


            </tr>




        <?php } ?>

        <tr>
            <td colspan="2" style="padding-left:5px;"><div class="dotted_line" style="width:96%"></div></td>
        </tr>
    </table>


    <table class="wp-list-table widefat post " style="margin:20px 0 0 10px; border:none;">

        <tr>
            <th style="background:none; border:0px;" width="18%">&nbsp;</th>
            <th style="background:none; border:none;height:98px;" colspan="2"><img alt='' src="<?php echo ARFURL; ?>/images/mailchimp.png" align="absmiddle" /></th>

            </th>

        </tr>

        <tr>
            <?php
                $autores_type['mailchimp_type'] = ( $autores_type['mailchimp_type'] !== '' ) ? $autores_type['mailchimp_type'] : 1;
            ?>
            <th style="width:18%; background:none; border:none;">&nbsp;</th>
            <th id="th_mailchimp" style=" background:none; border:none; padding-left:5px;">
        <div class="arf_radio_wrapper">
            <div class="arf_custom_radio_div" >
                <div class="arf_custom_radio_wrapper">
                    <input type="radio" class="arf_submit_action arf_custom_radio" id="mailchimp_1" <?php if ($autores_type['mailchimp_type'] == 1) echo 'checked="checked"'; ?> name="mailchimp_type" value="1" style="margin-top:3px;" onclick="show_api('mailchimp');" />
                    <svg width="18px" height="18px">
                    <?php echo ARF_CUSTOM_UNCHECKEDRADIO_ICON; ?>
                    <?php echo ARF_CUSTOM_CHECKEDRADIO_ICON; ?>
                    </svg>
                </div>
            </div>
            <span>
                <label for="mailchimp_1"><?php echo esc_html__('Using API', 'ARForms'); ?></label>
            </span>
        </div>
        <div class="arf_radio_wrapper">
            <div class="arf_custom_radio_div" >
                <div class="arf_custom_radio_wrapper">
                    <input type="radio" class="arf_submit_action arf_custom_radio" id="mailchimp_2" <?php if ($autores_type['mailchimp_type'] == 0) echo 'checked="checked"'; ?>  name="mailchimp_type" value="0" style="margin-top:3px;" onclick="show_web_form('mailchimp');" />
                    <svg width="18px" height="18px">
                    <?php echo ARF_CUSTOM_UNCHECKEDRADIO_ICON; ?>
                    <?php echo ARF_CUSTOM_CHECKEDRADIO_ICON; ?>
                    </svg>
                </div>
            </div>
            <span>
                <label for="mailchimp_2"><?php echo addslashes(esc_html__('Using Web-form', 'ARForms')); ?></label>
            </span>
        </div>
        </th>
        </tr>

        <tr id="mailchimp_api_tr1" <?php if ($autores_type['mailchimp_type'] != 1) echo 'style="display:none;"'; ?>>

            <td class="tdclass" style="width:18%; padding-right:20px; padding-bottom:3px; text-align: left;"><label class="lblsubtitle"><?php echo addslashes(esc_html__('API Key', 'ARForms')); ?></label></td>

            <td style="padding-bottom:3px; padding-left:5px;"><input type="text" name="mailchimp_api" class="txtmodal1" <?php
                if ($setvaltolic != 1) {
                    echo "readonly=readonly";
                }
                ?> <?php if ($setvaltolic != 1) { ?> onclick="alert('Please activate license to set mailchimp settings');" <?php } ?> id="mailchimp_api" size="80" onkeyup="show_verify_btn('mailchimp');" value="<?php echo $mailchimp_data->responder_api_key; ?>" /> &nbsp; &nbsp;
                <span id="mailchimp_link" <?php if ($mailchimp_data->is_verify == 1) { ?>style="display:none;"<?php } ?>><a href="javascript:void(0);" onclick="verify_autores('mailchimp', '0');" class="arlinks"><?php echo addslashes(esc_html__('Verify', 'ARForms')); ?></a></span>
                <span id="mailchimp_loader" style="display:none;"><div class="arf_imageloader" style="float: none !important;display:inline-block !important; "></div></span>
                <span id="mailchimp_verify" class="frm_verify_li" style="display:none;"><?php echo addslashes(esc_html__('Verified', 'ARForms')); ?></span>
                <span id="mailchimp_error" class="frm_not_verify_li" style="display:none;"><?php echo addslashes(esc_html__('Not Verified', 'ARForms')); ?></span>
                <input type="hidden" name="mailchimp_status" id="mailchimp_status" value="<?php echo $mailchimp_data->is_verify; ?>" />
                <div class="arferrmessage" id="mailchimp_api_error" style="display:none;"><?php echo addslashes(esc_html__('This field cannot be blank.', 'ARForms')); ?></div></td>

        </tr>


        <tr id="mailchimp_api_tr2" <?php if ($autores_type['mailchimp_type'] != 1) echo 'style="display:none;"'; ?>>

            <td class="tdclass" style="width:18%; padding-right:20px; padding-top:3px; padding-bottom:3px; text-align: left;"><label class="lblsubtitle"><?php echo addslashes(esc_html__('List/Audience', 'ARForms')); ?></label></td>

            <td style=" padding-top:3px; padding-bottom:3px; padding-left:5px; overflow: visible;"><span id="select_mailchimp">
                    <div class="sltstandard" style="float:none;display:inline;">
                        <?php
                        $responder_list_option = array( '' => esc_html__('Nothing Selected','ARForms') );
                        $selected_list_label = esc_html__('Nothing Selected','ARForms');
                        $selected_list_id = '';
                        $lists = json_decode($mailchimp_data->responder_list_id,true);
                        if ($lists != '' and count($lists) > 0) {
                            foreach ($lists as $key => $list) {
                                if ($mailchimp_data->responder_list != '') {
                                    if ($mailchimp_data->responder_list == $list['id']) {
                                        $selected_list_id = $list['id'];
                                        $responder_list_option[$list['id']] = $list['name'];
                                    }
                                } else {
                                    if ($key == 0) {
                                        $selected_list_id = $list['id'];
                                        $responder_list_option[$list['id']] = $list['name'];
                                    }
                                }

                                $responder_list_option[$list['id']] = $list['name'];
                            }
                        }
                        ?>

                        <?php
                            echo $maincontroller->arf_selectpicker_dom( 'mailchimp_listid', 'mailchimp_listid', '', 'width:400px;', $selected_list_id, array(), $responder_list_option, false, array(), false, array(), false, array(), true );
                        ?>
                    </div></span>



                <div id="mailchimp_del_link" style="padding-left:5px; margin-top:10px; clear: both; <?php if ($mailchimp_data->is_verify == 0) { ?>display:none;<?php } ?>" class="arlinks">
                    <a href="javascript:void(0);" onclick="action_autores('refresh', 'mailchimp');"><?php echo addslashes(esc_html__('Refresh List/Audience', 'ARForms')); ?></a>
                    &nbsp;  &nbsp;  &nbsp;  &nbsp;
                    <a href="javascript:void(0);" onclick="action_autores('delete', 'mailchimp');"><?php echo addslashes(esc_html__('Delete Configuration', 'ARForms')); ?></a>
                </div>


            </td>

        </tr>

        <tr id="mailchimp_web_form_tr" <?php if ($autores_type['mailchimp_type'] != 0) echo 'style="display:none;"'; ?>>

            <td class="tdclass" style="width:18%; padding-right:20px; text-align: left;"><label class="lblsubtitle"><?php echo addslashes(esc_html__('Webform code from Mailchimp', 'ARForms')); ?></label></td>

            <td style="padding-left:5px;">

                <textarea <?php
                if ($setvaltolic != 1) {
                    echo "readonly=readonly";
                }
                ?> name="mailchimp_web_form" id="mailchimp_web_form" class="txtmultinew" <?php if ($setvaltolic != 1) { ?> onclick="alert('Please activate license to set mailchimp settings');" <?php } ?>><?php echo esc_textarea( stripslashes($mailchimp_data->responder_web_form) ); ?></textarea>



            </td>

        </tr>

        <tr>
            <td colspan="2" style="padding-left:5px;"><div class="dotted_line" style="width:96%"></div></td>
        </tr>

    </table>


    <table class="wp-list-table widefat post " style="margin:20px 0 0 10px; border:none;">

        <tr>
            <th style="background:none; border:0px;" width="18%">&nbsp;</th>
            <th colspan="2" style="border:none; background:none;height:98px;"><img alt='' src="<?php echo ARFURL; ?>/images/getresponse.png" align="absmiddle" /></th>

        </tr>

        <tr>
            <?php $autores_type['getresponse_type'] = ( $autores_type['getresponse_type'] != '' ) ? $autores_type['getresponse_type'] : 1; ?>
            <th style="width:18%;  border:none; background:none;"></th>
            <th id="th_getresponse" style=" padding-left:5px; border:none; background:none;">
        <div class="arf_radio_wrapper">
            <div class="arf_custom_radio_div" >
                <div class="arf_custom_radio_wrapper">
                    <input type="radio" class="arf_submit_action arf_custom_radio" id="getresponse_1" <?php if ($autores_type['getresponse_type'] == 1) echo 'checked="checked"'; ?> name="getresponse_type" value="1" onclick="show_api('getresponse');" />
                    <svg width="18px" height="18px">
                    <?php echo ARF_CUSTOM_UNCHECKEDRADIO_ICON; ?>
                    <?php echo ARF_CUSTOM_CHECKEDRADIO_ICON; ?>
                    </svg>
                </div>
            </div>
            <span>
                <label for="getresponse_1"><?php echo esc_html__('Using API', 'ARForms'); ?></label>
            </span>
        </div>

        <div class="arf_radio_wrapper">
            <div class="arf_custom_radio_div" >
                <div class="arf_custom_radio_wrapper">
                    <input type="radio" class="arf_submit_action arf_custom_radio"  <?php if ($autores_type['getresponse_type'] == 0) echo 'checked="checked"'; ?> id="getresponse_2" name="getresponse_type" value="0" onclick="show_web_form('getresponse');"/>
                    <svg width="18px" height="18px">
                    <?php echo ARF_CUSTOM_UNCHECKEDRADIO_ICON; ?>
                    <?php echo ARF_CUSTOM_CHECKEDRADIO_ICON; ?>
                    </svg>
                </div>
            </div>
            <span>
                <label for="getresponse_2"><?php echo addslashes(esc_html__('Using Web-form', 'ARForms')); ?></label>
            </span>
        </div>
        </th>
        </tr>

        <tr id="getresponse_api_tr1" <?php if ($autores_type['getresponse_type'] != 1) echo 'style="display:none;"'; ?>>


            <td class="tdclass" style="width:18%; padding-right:20px; padding-bottom:3px; text-align: left;"><label class="lblsubtitle"><?php echo addslashes(esc_html__('API Key', 'ARForms')); ?></label></td>


            <td style=" padding-bottom:3px; padding-left:5px;"><input type="text" name="getresponse_api" class="txtmodal1" id="getresponse_api" size="80" <?php
                if ($setvaltolic != 1) {
                    echo "readonly=readonly";
                }
                ?> <?php if ($setvaltolic != 1) { ?> onclick="alert('Please activate license to set Getresponse settings');" <?php } ?> onkeyup="show_verify_btn('getresponse');" value="<?php echo $getresponse_data->responder_api_key; ?>" /> &nbsp; &nbsp;

                <span id="getresponse_link" <?php if ($getresponse_data->is_verify == 1) { ?> style="display:none;"<?php } ?>><a href="javascript:void(0);" onclick="verify_autores('getresponse', '0');" class="arlinks"><?php echo addslashes(esc_html__('Verify', 'ARForms')); ?></a></span>
                <span id="getresponse_loader" style="display:none;"><div class="arf_imageloader" style="float: none !important;display:inline-block !important; "></div></span>
                <span id="getresponse_verify" class="frm_verify_li" style="display:none;"><?php echo addslashes(esc_html__('Verified', 'ARForms')); ?></span>
                <span id="getresponse_error" class="frm_not_verify_li" style="display:none;"><?php echo addslashes(esc_html__('Not Verified', 'ARForms')); ?></span>
                <input type="hidden" name="getresponse_status" id="getresponse_status" value="<?php echo $getresponse_data->is_verify; ?>" />
                <div class="arferrmessage" id="getresponse_api_error" style="display:none;"><?php echo addslashes(esc_html__('This field cannot be blank.', 'ARForms')); ?></div></td>


        </tr>


        <tr id="getresponse_api_tr2" <?php if ($autores_type['getresponse_type'] != 1) echo 'style="display:none;"'; ?>>


            <td class="tdclass" style="width:18%; padding-right:20px; padding-top:3px; padding-bottom:3px; text-align: left;"><label class="lblsubtitle"><?php echo addslashes(esc_html__('Campaign Name', 'ARForms')); ?></label></td>


            <td style=" padding-top:3px; padding-bottom:3px; padding-left:5px; overflow: visible;"><span id="select_getresponse">
                    <div class="sltstandard" style="float:none;display:inline;">
                        <?php
                        $responder_list_option = array( '' => esc_html__('Nothing Selected','ARForms') );
                        $selected_list_label = esc_html__('Nothing Selected','ARForms');
                        $selected_list_id = '';
                        $lists = arf_pro_maybe_unserialize($getresponse_data->list_data);
                        if ($lists != '' and count($lists) > 0 ) {
                            foreach ($lists as $list) {
                                if ($getresponse_data->responder_list_id != '') {
                                    if ($getresponse_data->responder_list_id == $list['id']) {
                                        $selected_list_id = $list['id'];
                                        $selected_list_label = $list['name'];
                                    }
                                } else {
                                    if ($key == 0) {
                                        $selected_list_id = $list['id'];
                                        $selected_list_label = $list['name'];
                                    }
                                }
                                
                                $responder_list_option[$list['id']] = $list['name'];
                            }
                        }
                        
                        echo $maincontroller->arf_selectpicker_dom( 'getresponse_listid', 'getresponse_listid', '', 'width:400px;', $selected_list_id, array(), $responder_list_option, false, array(), false, array(), false, array(), true );
                        ?>
                    </div></span>                            


                <div id="getresponse_del_link" style="padding-left:5px; margin-top:10px; clear: both;<?php if ($getresponse_data->is_verify == 0) { ?> display:none;<?php } ?>" class="arlinks">

                    <a href="javascript:void(0);" onclick="action_autores('refresh', 'getresponse');"><?php echo addslashes(esc_html__('Refresh List', 'ARForms')); ?></a>
                    &nbsp;  &nbsp;  &nbsp;  &nbsp;
                    <a href="javascript:void(0);" onclick="action_autores('delete', 'getresponse');"><?php echo addslashes(esc_html__('Delete Configuration', 'ARForms')); ?></a>
                </div>


            </td>


        </tr>

        <tr id="getresponse_web_form_tr" <?php if ($autores_type['getresponse_type'] != 0) echo 'style="display:none;"'; ?>>

            <td class="tdclass" style="width:18%; padding-right:20px; text-align: left;"><label class="lblsubtitle"><?php echo addslashes(esc_html__('Webform code from Getresponse', 'ARForms')); ?></label></td>

            <td style="padding-left:5px;">

                <textarea <?php
                if ($setvaltolic != 1) {
                    echo "readonly=readonly";
                }
                ?> name="getresponse_web_form" id="getresponse_web_form" class="txtmultinew" <?php if ($setvaltolic != 1) { ?> onclick="alert('Please activate license to set Getresponse settings');" <?php } ?>><?php echo esc_textarea( stripslashes($getresponse_data->responder_web_form) ); ?></textarea>


            </td>

        </tr>

        <tr>
            <td colspan="2" style="padding-left:5px;"><div class="dotted_line" style="width:96%"></div></td>
        </tr>

    </table>

    <table class="wp-list-table widefat post " style="margin:20px 0 0 10px; border:none;">


        <tr>

            <th style="background:none; border:0px;" width="18%">&nbsp;</th>
            <th colspan="2" style="background:none; border:none;height:98px;"><img alt='' src="<?php echo ARFURL; ?>/images/icontact.png" align="absmiddle" /></th>

        </tr>

        <tr>
            <?php $autores_type['icontact_type'] = ( $autores_type['icontact_type'] != '' ) ? $autores_type['icontact_type'] : 1; ?>

            <th style="width:18%; background:none; border:none;"></th>
            <th id="th_icontact" style="background:none; border:none; padding-left:5px;">
        <div class="arf_radio_wrapper">
            <div class="arf_custom_radio_div" >
                <div class="arf_custom_radio_wrapper">
                    <input type="radio" class="arf_submit_action arf_custom_radio"   id="icontact_1" <?php if ($autores_type['icontact_type'] == 1) echo 'checked="checked"'; ?> name="icontact_type" value="1"  onclick="show_api('icontact');" />
                    <svg width="18px" height="18px">
                    <?php echo ARF_CUSTOM_UNCHECKEDRADIO_ICON; ?>
                    <?php echo ARF_CUSTOM_CHECKEDRADIO_ICON; ?>
                    </svg>
                </div>
            </div>
            <span>
                <label for="icontact_1"><?php echo esc_html__('Using API', 'ARForms'); ?></label>
            </span>
        </div>
        <div class="arf_radio_wrapper">
            <div class="arf_custom_radio_div" >
                <div class="arf_custom_radio_wrapper">
                    <input type="radio" class="arf_submit_action arf_custom_radio" id="icontact_2" <?php if ($autores_type['icontact_type'] == 0) echo 'checked="checked"'; ?>  name="icontact_type" value="0" onclick="show_web_form('icontact');" />
                    <svg width="18px" height="18px">
                    <?php echo ARF_CUSTOM_UNCHECKEDRADIO_ICON; ?>
                    <?php echo ARF_CUSTOM_CHECKEDRADIO_ICON; ?>
                    </svg>
                </div>
            </div>
            <span>
                <label for="icontact_2"><?php echo addslashes(esc_html__('Using Web-form', 'ARForms')); ?></label>
            </span>
        </div>
        </th>

        </tr>

        <tr id="icontact_api_tr1" <?php if ($autores_type['icontact_type'] != 1) echo 'style="display:none;"'; ?>>

            <td class="tdclass" style="width:18%; padding-right:20px; padding-bottom:3px; text-align: left;"><label class="lblsubtitle"><?php echo addslashes(esc_html__('APP ID', 'ARForms')); ?></label></td>

            <td style="padding-bottom:3px; padding-left:5px;"><input type="text" name="icontact_api" class="txtmodal1" id="icontact_api" size="80" onkeyup="show_verify_btn('icontact');" value="<?php echo $icontact_data->responder_api_key; ?>" <?php
                if ($setvaltolic != 1) {
                    echo "readonly=readonly";
                }
                ?>  <?php if ($setvaltolic != 1) { ?> onclick="alert('Please activate license to set Icontact settings');" <?php } ?>/>
                <div class="arferrmessage" id="icontact_api_error" style="display:none;"><?php echo addslashes(esc_html__('This field cannot be blank.', 'ARForms')); ?></div></td>

        </tr>


        <tr id="icontact_api_tr2" <?php if ($autores_type['icontact_type'] != 1) echo 'style="display:none;"'; ?>>

            <td class="tdclass" style="width:18%; padding-top:3px; padding-bottom:3px; padding-right:20px; text-align: left;"><label class="lblsubtitle"><?php echo esc_html__('Username', 'ARForms'); ?></label></td>

            <td style=" padding-top:3px; padding-bottom:3px; padding-left:5px;"><input type="text" name="icontact_username" class="txtmodal1" id="icontact_username" onkeyup="show_verify_btn('icontact');" size="80" value="<?php echo $icontact_data->responder_username; ?>" <?php
                if ($setvaltolic != 1) {
                    echo "readonly=readonly";
                }
                ?> <?php if ($setvaltolic != 1) { ?> onclick="alert('Please activate license to set Icontact settings');" <?php } ?> />
                <div class="arferrmessage" id="icontact_username_error" style="display:none;"><?php echo addslashes(esc_html__('This field cannot be blank.', 'ARForms')); ?></div></div></td>


        </tr>

        <tr id="icontact_api_tr3" <?php if ($autores_type['icontact_type'] != 1) echo 'style="display:none;"'; ?>>

            <td class="tdclass" style="width:18%; padding-top:3px; padding-bottom:3px; padding-right:20px; text-align: left;"><label class="lblsubtitle"><?php echo addslashes(esc_html__('Password', 'ARForms')); ?></label></td>

            <td style=" padding-top:3px; padding-bottom:3px; padding-left:5px;"><input type="password" name="icontact_password" class="txtmodal1" id="icontact_password" onkeyup="show_verify_btn('icontact');" size="80" value="<?php echo $icontact_data->responder_password; ?>" <?php
                if ($setvaltolic != 1) {
                    echo "readonly=readonly";
                }
                ?> <?php if ($setvaltolic != 1) { ?> onclick="alert('Please activate license to set Icontact settings');" <?php } ?>/> &nbsp; &nbsp;
                <span id="icontact_link" <?php if ($icontact_data->is_verify == 1) { ?> style="display:none"<?php } ?>><a href="javascript:void(0);" onclick="verify_autores('icontact', '0');" class="arlinks"><?php echo addslashes(esc_html__('Verify', 'ARForms')); ?></a></span>
                <span id="icontact_loader" style="display:none;"><div class="arf_imageloader" style="float: none !important;display:inline-block !important; "></div></span>                    <span id="icontact_verify" class="frm_verify_li" style="display:none;"><?php echo addslashes(esc_html__('Verified', 'ARForms')); ?></span>
                <span id="icontact_error" class="frm_not_verify_li" style="display:none;"><?php echo addslashes(esc_html__('Not Verified', 'ARForms')); ?></span>
                <input type="hidden" name="icontact_status" id="icontact_status" value="<?php echo $icontact_data->is_verify; ?>" />
                <div class="arferrmessage" id="icontact_password_error" style="display:none;"><?php echo addslashes(esc_html__('This field cannot be blank.', 'ARForms')); ?></div></td>


        </tr>

        <tr id="icontact_api_tr4" <?php if ($autores_type['icontact_type'] != 1) echo 'style="display:none;"'; ?>>

            <td class="tdclass" style="width:18%; padding-top:3px; padding-bottom:3px; padding-right:20px; text-align: left;"><label class="lblsubtitle"><?php echo addslashes(esc_html__('List Name', 'ARForms')); ?></label></td>

            <td style=" padding-top:3px; padding-bottom:3px; padding-left:5px; overflow: visible;"><span id="select_icontact">
                    <div class="sltstandard" style="float:none;display:inline;">
                        <?php
                        $responder_list_option = array( '' => esc_html__('Nothing Selected','ARForms') );
                        $selected_list_label = esc_html__('Nothing Selected','ARForms');
                        $selected_list_id = '';
                        $lists = arf_pro_maybe_unserialize($icontact_data->responder_list_id);
                        if ($lists != '' and count($lists) > 0) {
                            foreach ($lists as $key => $list) {
                                $list = (array)$list;
                                if ($icontact_data->responder_list != '') {
                                    if ($icontact_data->responder_list == $list['listId']) {
                                        $selected_list_id = $list['listId'];
                                        $responder_list_option[$list['listId']] = $list['name'];
                                    }
                                } else {
                                    if ($key == 0) {
                                        $selected_list_id = $list['listId'];
                                        $responder_list_option[$list['listId']] = $list['name'];
                                    }
                                }

                                $responder_list_option[$list['listId']] = $list['name'];
                            }
                        }

                        echo $maincontroller->arf_selectpicker_dom( 'icontact_listname', 'icontact_listname', '', 'width:400px;', $selected_list_id, array(), $responder_list_option, false, array(), false, array(), false, array(), true );
                        ?>

                    </div></span>


                <div id="icontact_del_link" style="padding-left:5px; margin-top:10px; clear: both; <?php if ($icontact_data->is_verify == 0) { ?>display:none;<?php } ?>" class="arlinks">

                    <a href="javascript:void(0);" onclick="action_autores('refresh', 'icontact');"><?php echo addslashes(esc_html__('Refresh List', 'ARForms')); ?></a>
                    &nbsp;  &nbsp;  &nbsp;  &nbsp;
                    <a href="javascript:void(0);" onclick="action_autores('delete', 'icontact');"><?php echo addslashes(esc_html__('Delete Configuration', 'ARForms')); ?></a>
                </div>


            </td>


        </tr>

        <tr id="icontact_web_form_tr" <?php if ($autores_type['icontact_type'] != 0) echo 'style="display:none;"'; ?>>

            <td class="tdclass" style="width:18%; padding-right:20px; text-align: left;"><label class="lblsubtitle"><?php echo addslashes(esc_html__('Webform code from Icontact', 'ARForms')); ?></label></td>

            <td style="padding-left:5px;">

                <textarea <?php
                if ($setvaltolic != 1) {
                    echo "readonly=readonly";
                }
                ?> name="icontact_web_form" id="icontact_web_form" class="txtmultinew" <?php if ($setvaltolic != 1) { ?> onclick="alert('Please activate license to set Icontact settings');" <?php } ?>><?php echo esc_textarea( stripslashes($icontact_data->responder_web_form) ); ?></textarea>


            </td>

        </tr>

        <tr>
            <td colspan="2" style="padding-left:5px;"><div class="dotted_line" style="width:96%"></div></td>
        </tr>

    </table>


    <table class="wp-list-table widefat post " style="margin:20px 0 0 10px; border:none;">

        <tr>
            <th style="background:none; border:0px;" width="18%">&nbsp;</th>
            <th colspan="2" style="background:none; border:none;height:98px;"><img alt='' src="<?php echo ARFURL; ?>/images/constant-contact.png" align="absmiddle" /></th>


        </tr>

        <tr>
            <?php $autores_type['constant_type'] = ( $autores_type['constant_type'] != '' ) ? $autores_type['constant_type'] : 1; ?>
        <th style="width:18%; background:none; border:none;">&nbsp;</th>
        <th id="th_constant" style="background:none; border:none; padding-left:5px;">
            <input type="hidden" name="constant_type" value="1" />
        </th>
    </tr>

    <!-- Client ID (API Key) -->
    <tr id="constant_api_tr1" <?php if ($autores_type['constant_type'] != 1) echo 'style="display:none;"'; ?>>
        <td class="tdclass" style="width:18%; padding-bottom:3px; padding-right:20px; text-align: left;">
            <label class="lblsubtitle"><?php echo esc_html__('Client ID (API Key)', 'ARForms'); ?></label>
        </td>
        <td style="padding-bottom:3px; padding-left:5px;">
            <input type="text" name="constant_client_id" id="constant_client_id" class="txtmodal1" size="80" value="<?php echo esc_attr($constant_data->responder_api_key); ?>" <?php if ($setvaltolic != 1) {
                                                                                                                                                                                    echo 'readonly="readonly"';
                                                                                                                                                                                } ?> <?php if ($setvaltolic != 1) { ?> onclick="alert('Please activate license to set Constant Contact settings');" <?php } ?> />
            <div class="arferrmessage" id="constant_client_id_error" style="display:none;">
                <?php echo addslashes(esc_html__('This field cannot be blank.', 'ARForms')); ?>
            </div>
        </td>
    </tr>

    <!-- Client Secret -->
    <tr id="constant_api_tr2" <?php if ($autores_type['constant_type'] != 1) echo 'style="display:none;"'; ?>>
        <td class="tdclass" style="width:18%; padding-top:3px; padding-bottom:3px; padding-right:20px; text-align: left;">
            <label class="lblsubtitle"><?php echo esc_html__('Client Secret', 'ARForms'); ?></label>
        </td>
        <td style="padding-top:3px; padding-bottom:3px; padding-left:5px;">
            <input type="password" name="constant_client_secret" id="constant_client_secret" class="txtmodal1" size="80" value="<?php echo esc_attr($constant_data->responder_password); ?>" <?php if ($setvaltolic != 1) {
                                                                                                                                                                                                    echo 'readonly="readonly"';
                                                                                                                                                                                                } ?> <?php if ($setvaltolic != 1) { ?> onclick="alert('Please activate license to set Constant Contact settings');" <?php } ?> />
            <div class="arferrmessage" id="constant_client_secret_error" style="display:none;">
                <?php echo addslashes(esc_html__('This field cannot be blank.', 'ARForms')); ?>
            </div>&nbsp;&nbsp;

            <?php
            $cc_token_data = arf_pro_maybe_unserialize($constant_data->responder_list_id);
            $cc_is_connected = (is_array($cc_token_data) && !empty($cc_token_data['access_token']));
            ?>

            <button type="button" id="arf_cc_connect_btn" class="rounded_button arf_btn_dark_blue" style="height:35px; border:0px; color:#FFFFFF; padding:0 10px; <?php if ($cc_is_connected) {
                                                                                                                                                                        echo 'display:none;';
                                                                                                                                                                    } ?>" <?php if ($setvaltolic != 1) { ?> onclick="alert('Please activate license to connect Constant Contact.');" <?php } else { ?> onclick="arf_cc_initiate_oauth_connect();" <?php } ?>>
                <?php echo addslashes(esc_html__('Authorize', 'ARForms')); ?>
            </button>

            &nbsp;&nbsp;

            <span id="constant_loader" style="display:none;">
                <div class="arf_imageloader" style="float:none !important; display:inline-block !important;"></div>
            </span>

            <span id="constant_verify" class="frm_verify_li" style="display:none;"><?php echo addslashes(esc_html__('Verified', 'ARForms')); ?></span>
            <span id="constant_error" class="frm_not_verify_li" style="display:none;"><?php echo addslashes(esc_html__('Not Verified', 'ARForms')); ?></span>
            <input type="hidden" name="constant_status" id="constant_status" value="<?php echo esc_attr($constant_data->is_verify); ?>" />
        </td>
    </tr>

    <?php
    $cc_token_data = arf_pro_maybe_unserialize($constant_data->responder_list_id);
    $cc_is_connected = (is_array($cc_token_data) && !empty($cc_token_data['access_token']));
    ?>
    <tr id="constant_api_tr3">

        <td class="tdclass" style="width:18%; padding-top:3px; padding-bottom:3px; padding-right:20px; text-align: left;"><label class="lblsubtitle"><?php echo addslashes(esc_html__('List Name', 'ARForms')); ?></label></td>

        <td style="padding-top:3px; padding-bottom:3px; padding-left:5px; overflow: visible;"><span id="select_constant">
                <div class="sltstandard" style="float:none; display:inline;">
                    <?php
                    $responder_list_option = array('' => esc_html__('Nothing Selected', 'ARForms'));
                    $selected_list_label = esc_html__('Nothing Selected', 'ARForms');
                    $selected_list_id = '';
                    $lists = arf_pro_maybe_unserialize($constant_data->list_data);
                    if ($lists != '' and count($lists) > 0) {
                        foreach ($lists as $key => $list) {
                            if ($constant_data->responder_list != '') {
                                if ($constant_data->responder_list == $list['id']) {
                                    $selected_list_id = $list['id'];
                                    $responder_list_option[$list['id']] = $list['name'];
                                }
                            } else {
                                if ($key == 0) {
                                    $selected_list_id = $list['id'];
                                    $responder_list_option[$list['id']] = $list['name'];
                                }
                            }

                            $responder_list_option[$list['id']] = $list['name'];
                        }
                    }

                    echo $maincontroller->arf_selectpicker_dom('constant_listname', 'constant_listname', '', 'width:400px;', $selected_list_id, array(), $responder_list_option, false, array(), false, array(), false, array(), true);
                    ?>

                </div>
            </span>


            <div id="constant_del_link" style="padding-left:5px; margin-top:10px; clear: both;<?php if ($constant_data->is_verify == 0) { ?>display:none;<?php } ?>" class="arlinks">

                <a href="javascript:void(0);" onclick="action_autores('refresh', 'constant');"><?php echo addslashes(esc_html__('Refresh List', 'ARForms')); ?></a>
                &nbsp; &nbsp; &nbsp; &nbsp;
                <a href="javascript:void(0);" onclick="action_autores('delete', 'constant');"><?php echo addslashes(esc_html__('Delete Configuration', 'ARForms')); ?></a>
            </div>


        </td>

    </tr>

    <!-- Redirect URI -->
    <tr id="constant_api_tr_connect" <?php if ($autores_type['constant_type'] != 1) echo 'style="display:none;"'; ?>>
        <td style="padding-top:3px; padding-bottom:3px; padding-left:5px;"></td>
        <td style="padding-top:3px; padding-bottom:3px; padding-left:5px;">
            <p> <?php echo esc_html__('Redirect URI: ', 'ARForms'); ?><code><?php echo esc_html(admin_url('admin-ajax.php') . '?action=arf_cc_oauth_callback'); ?></code></p>
        </td>
    </tr>

    <tr>
        <td colspan="2" style="padding-left:5px;">
            <div class="dotted_line" style="width:96%"></div>
        </td>
    </tr>

</table>

<?php do_action('arf_autoresponder_global_setting_block', $autores_type, $setvaltolic); ?>

</div>