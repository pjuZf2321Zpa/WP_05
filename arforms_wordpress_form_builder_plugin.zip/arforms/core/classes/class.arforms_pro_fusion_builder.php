<?php
class arforms_popup_fusion_builder{
    function __construct(){
        add_action( 'fusion_builder_shortcodes_init', array( $this, 'arflite_load_fusion_elements') );
    }

    function arflite_load_fusion_elements()
    {
        require_once FORMPATH.'/integrations/fusion/fusion_builder_popup.php';
    }
}
global $arforms_popup_fusion_builder;
$arforms_popup_fusion_builder = new arforms_popup_fusion_builder();
?>