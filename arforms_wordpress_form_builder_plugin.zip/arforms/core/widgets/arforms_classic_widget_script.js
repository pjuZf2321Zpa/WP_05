function hasClass(el, className) {
    if (el == null) {
        return false;
    }
    if (el.classList) {
        return el.classList.contains(className);
    } else {
        return !!el.className.match(new RegExp('(\\s|^)' + className + '(\\s|$)'));
    }
}

function addClass(el, className) {
    if (el == null) {
        return false;
    }
    if (el.classList) {
        el.classList.add(className);
    } else if (!hasClass(el, className)) {
        el.className += " " + className;
    }
}

function removeClass(el, className) {
    if (el == null) {
        return false;
    }
    if (el.classList) {
        el.classList.remove(className);
    } else if (hasClass(el, className)) {
        var reg = new RegExp('(\\s|^)' + className + '(\\s|$)')
        el.className = el.className.replace(reg, ' ')
    }
}

function getCookie(cname) {
    var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}

jQuery(document).on('click', '#arf_enable_multicolumn_checkbox', function(){
    if(jQuery(this).is(":checked")) {
        jQuery(".arf_enable_multicolumn_hidden").val("1");
    } else {
        jQuery(".arf_enable_multicolumn_hidden").val("0");
    }
});

function change_onclick(field_id,typename,link_id){
    jQuery('#'+link_id).val(typename);
    jQuery('#'+link_id).trigger('change');
}

function arf_change_type(name, id, link_position, link_position_fly, btn_bg_col,btn_txt_col, angle_div) {
    var type_val = jQuery('input[name="' + name + '"]:checked').val();
    var link_type = jQuery('#' + id).val();


    if (type_val == 'popup') {
        jQuery('#' + id + '_div').show();
        jQuery('#' + id + '_label').show();
        jQuery('#' + id + '_height').show();
        jQuery('#' + id + '_width').show();

        jQuery('select#' + id).trigger('change');

        jQuery('#' + id + '_close_link').show();

        jQuery('#' + id + '_disable_multicol').hide();
        if (link_type == 'scroll') {
            jQuery('#' + id + '_scroll').show();
        } else {
            jQuery('#' + id + '_scroll').hide();
        }

        if (link_type == 'onload') {
            jQuery('#' + id + '_delay').show();
        } else {
            jQuery('#' + id + '_delay').hide();
        }

        if (link_type == 'onload' || link_type == 'scroll') {
            jQuery('#' + id + '_label').hide();
        } else {
            jQuery('#' + id + '_label').show();
        }

        if (link_type == 'link' || link_type == 'button' || link_type == 'image' || link_type == 'onclick') {
            jQuery('#' + id + '_custom_class').show();
        } else {
            jQuery('#' + id + '_custom_class').hide();
        }

        if (link_type == 'sticky' || link_type == 'fly') {
            jQuery('#' + id + '_overlay').hide();
            jQuery('#' + id + '_close_link').hide();

        } else {
            jQuery('#' + id + '_overlay').show();
            jQuery('#' + id + '_close_link').show();
        }

        var fid = '';
        jQuery('.jscolor').each(function (e) {
            var this_val = jQuery(this);

            var color = this_val.attr('value');
            var widget_hex = color.replace('#', '');
            var arfwidgetmodalbgcolor = widget_hex == '' ? '#000000' : (HextoHsl(widget_hex) > 0.5 ? '#000000' : '#ffffff');
            fid = this_val.attr('data-fid');
            colpick_control = new jscolor( this_val[0] );
            colpick_control.valueElement.innerHTML = color;
            colpick_control.valueElement.style.backgroundColor = color;
            colpick_control.valueElement.style.color = arfwidgetmodalbgcolor;
            colpick_control.valueElement = this_val[0];
            colpick_control.hash = true;
            jQuery("#" + fid).val( color.toUpperCase() );
        });        

    } else if (type_val == 'normal') {
        jQuery('#' + id + '_div').hide();
        jQuery('#' + id + '_label').hide();
        jQuery('#' + id + '_height').hide();
        jQuery('#' + id + '_width').hide();

        jQuery('#' + id + '_disable_multicol').show();

        jQuery('#' + id + '_scroll').hide();
        jQuery('#' + id + '_delay').hide();
        jQuery('#' + id + '_overlay').hide();
        jQuery('#' + id + '_close_link').hide();

        jQuery('#' + arf_img_url + '_div').hide();
        jQuery('#' + arf_img_height + '_div').hide();
        jQuery('#' + arf_img_width + '_div').hide();
        jQuery('#' + link_position + '_div').hide();
        jQuery('#' + link_position_fly + '_div').hide();
        jQuery('#' + btn_bg_col + '_div').hide();
        jQuery('#' + btn_txt_col + '_div').hide();
        jQuery('#' + angle_div + '_div').hide();
        jQuery('#' + id + '_custom_class').hide();

    }

}

function arf_change_link_type(id, link_position, link_position_fly, button_angle, btn_bg_col, btn_txt_col, arf_img_url, arf_img_height, arf_img_width) {
    var link_type = jQuery('#' + id).val();
    if (link_type == 'sticky') {
        jQuery('#' + link_position_fly + '_div').hide();
        jQuery('#' + link_position + '_div').show();
        jQuery('#' + button_angle + '_div').hide();
        jQuery('#' + btn_bg_col + '_div').show();
        jQuery('#' + btn_txt_col + '_div').show();
        jQuery('#' + id + '_label').show();
        jQuery('#' + arf_img_url + '_div').hide();
        jQuery('#' + arf_img_width + '_div').hide();
        jQuery('#' + arf_img_height + '_div').hide();
    
        jQuery('#' + id + '_delay').hide();
        jQuery('#' + id + '_scroll').hide();
        jQuery('#' + id + '_overlay').hide();
        jQuery('#' + id + '_close_link').hide();
        jQuery('#' + id + '_onclick_type').show();
        jQuery('#' + id + '_ideal_time').hide();
        jQuery('#' + id + '_full_screen_modal').hide();
        jQuery('#' + id + '_modal_effect').hide();
        jQuery('#' + id + '_height').show();

    } else if (link_type == 'fly') {
        jQuery('#' + link_position + '_div').hide();
        jQuery('#' + link_position_fly + '_div').show();
        jQuery('#' + button_angle + '_div').show();
        jQuery('#' + btn_bg_col + '_div').show();
        jQuery('#' + btn_txt_col + '_div').show();
        jQuery('#' + id + '_label').show();
        jQuery('#' + arf_img_url + '_div').hide();
        jQuery('#' + arf_img_height + '_div').hide();
        jQuery('#' + arf_img_width + '_div').hide();
       
        jQuery('#' + id + '_delay').hide();
        jQuery('#' + id + '_scroll').hide();
        jQuery('#' + id + '_overlay').hide();
        jQuery('#' + id + '_close_link').hide();
        jQuery('#' + id + '_onclick_type').show();
        jQuery('#' + id + '_ideal_time').hide();
        jQuery('#' + id + '_full_screen_modal').hide();
        jQuery('#' + id + '_modal_effect').hide();
        jQuery('#' + id + '_height').hide();

    } else if (link_type == 'scroll') {
        jQuery('#' + link_position + '_div').hide();
        jQuery('#' + link_position_fly + '_div').hide();
        jQuery('#' + button_angle + '_div').hide();
        jQuery('#' + btn_bg_col + '_div').hide();
        jQuery('#' + btn_txt_col + '_div').hide();
        jQuery('#' + id + '_label').hide();
        jQuery('#' + id + '_full_screen_modal').show();

        jQuery('#' + id + '_delay').hide();
        jQuery('#' + id + '_scroll').show();
        jQuery('#' + id + '_overlay').show();
        jQuery('#' + id + '_close_link').show();
        jQuery('#' + id + '_onclick_type').hide();
        jQuery('#' + id + '_ideal_time').hide();
        jQuery('#' + id + '_modal_effect').show();
        jQuery('#' + id + '_height').hide();

    } else if (link_type == 'onload') {
        jQuery('#' + link_position + '_div').hide();
        jQuery('#' + link_position_fly + '_div').hide();
        jQuery('#' + button_angle + '_div').hide();
        jQuery('#' + btn_bg_col + '_div').hide();
        jQuery('#' + btn_txt_col + '_div').hide();
        jQuery('#' + id + '_label').hide();

        jQuery('#' + id + '_scroll').hide();
        jQuery('#' + id + '_delay').hide();
        jQuery('#' + id + '_overlay').show();
        jQuery('#' + id + '_close_link').show();
        jQuery('#' + id + '_onclick_type').hide();
        jQuery('#' + id + '_ideal_time').hide();
        jQuery('#' + id + '_full_screen_modal').show();
        jQuery('#' + id + '_modal_effect').show();
        jQuery('#' + id + '_height').hide();

    } else if (link_type == 'button') {
        jQuery('#' + link_position + '_div').hide();
        jQuery('#' + link_position_fly + '_div').hide();
        jQuery('#' + button_angle + '_div').hide();
        jQuery('#' + btn_bg_col + '_div').show();
        jQuery('#' + btn_txt_col + '_div').show();
        jQuery('#' + arf_img_url + '_div').hide();
        jQuery('#' + id + '_label').show();
        jQuery('#' + arf_img_height + '_div').hide();
        jQuery('#' + arf_img_width + '_div').hide();
    
        jQuery('#' + id + '_scroll').hide();
        jQuery('#' + id + '_delay').hide();
        jQuery('#' + id + '_overlay').hide();
        jQuery('#' + id + '_close_link').hide();
        jQuery('#' + id + '_onclick_type').hide();
        jQuery('#' + id + '_onclick_type').show();
        jQuery('#' + id + '_ideal_time').hide();
        jQuery('#' + id + '_full_screen_modal').show();
        jQuery('#' + id + '_modal_effect').show();
        jQuery('#' + id + '_height').hide();

    } else if( link_type == 'image' ){
        jQuery('#' + link_position_fly + '_div').hide();
        jQuery('#' + link_position + '_div').hide();
        jQuery('#' + button_angle + '_div').hide();
        jQuery('#' + btn_bg_col + '_div').hide();
        jQuery('#' + btn_txt_col + '_div').hide();
        jQuery('#' + arf_img_url + '_div').show();
        jQuery('#' + arf_img_height + '_div').show();
        jQuery('#' + arf_img_width + '_div').show();
        jQuery('#' + id + '_label').hide();

        jQuery('#' + id + '_delay').hide();
        jQuery('#' + id + '_scroll').hide();
        jQuery('#' + id + '_overlay').hide();
        jQuery('#' + id + '_close_link').hide();
        jQuery('#' + id + '_onclick_type').show();
        jQuery('#' + id + '_ideal_time').hide();
        jQuery('#' + id + '_full_screen_modal').show();
        jQuery('#' + id + '_modal_effect').hide();
        jQuery('#' + id + '_height').hide();


    } else if (link_type == 'timer') {

        jQuery('#' + link_position + '_div').hide();
        jQuery('#' + link_position_fly + '_div').hide();
        jQuery('#' + button_angle + '_div').hide();
        jQuery('#' + btn_bg_col + '_div').hide();
        jQuery('#' + btn_txt_col + '_div').hide();
        jQuery('#' + id + '_label').hide();


        jQuery('#' + id + '_scroll').hide();
        jQuery('#' + id + '_delay').show();
        jQuery('#' + id + '_overlay').show();
        jQuery('#' + id + '_close_link').show();
        jQuery('#' + id + '_onclick_type').hide();
        jQuery('#' + id + '_ideal_time').hide();
        jQuery('#' + id + '_full_screen_modal').show();
        jQuery('#' + id + '_modal_effect').show();
        jQuery('#' + id + '_height').hide();

    }else if (link_type == 'on_exit') {

        jQuery('#' + link_position + '_div').hide();
        jQuery('#' + link_position_fly + '_div').hide();
        jQuery('#' + button_angle + '_div').hide();
        jQuery('#' + btn_bg_col + '_div').hide();
        jQuery('#' + btn_txt_col + '_div').hide();
        jQuery('#' + id + '_label').hide();


        jQuery('#' + id + '_scroll').hide();
        jQuery('#' + id + '_delay').hide();
        jQuery('#' + id + '_overlay').show();
        jQuery('#' + id + '_close_link').show();
        jQuery('#' + id + '_onclick_type').hide();
        jQuery('#' + id + '_ideal_time').hide();
        jQuery('#' + id + '_full_screen_modal').show();
        jQuery('#' + id + '_modal_effect').show();
        jQuery('#' + id + '_height').hide();

    }else if (link_type == 'on_idle') {

        jQuery('#' + link_position + '_div').hide();
        jQuery('#' + link_position_fly + '_div').hide();
        jQuery('#' + button_angle + '_div').hide();
        jQuery('#' + btn_bg_col + '_div').hide();
        jQuery('#' + btn_txt_col + '_div').hide();
        jQuery('#' + id + '_label').hide();


        jQuery('#' + id + '_scroll').hide();
        jQuery('#' + id + '_delay').hide();
        jQuery('#' + id + '_overlay').show();
        jQuery('#' + id + '_close_link').show();
        jQuery('#' + id + '_onclick_type').hide();
        jQuery('#' + id + '_ideal_time').show();
        jQuery('#' + id + '_full_screen_modal').show();
        jQuery('#' + id + '_modal_effect').show();
        jQuery('#' + id + '_height').hide();

    } else if(link_type == 'onclick'){
        jQuery('#' + id + '_onclick_type').show();
        jQuery('#' + id + '_ideal_time').hide();

    }else {
        jQuery('#' + link_position + '_div').hide();
        jQuery('#' + link_position_fly + '_div').hide();
        jQuery('#' + button_angle + '_div').hide();
        jQuery('#' + btn_bg_col + '_div').hide();
        jQuery('#' + btn_txt_col + '_div').hide();
        jQuery('#' + id + '_label').hide();
        jQuery('#' + arf_img_url + '_div').hide();
        jQuery('#' + arf_img_height + '_div').hide();
        jQuery('#' + arf_img_width + '_div').hide();

        jQuery('#' + id + '_scroll').hide();
        jQuery('#' + id + '_delay').hide();
        jQuery('#' + id + '_overlay').hide();
        jQuery('#' + id + '_close_link').hide();
        jQuery('#' + id + '_onclick_type').hide();
        jQuery('#' + id + '_ideal_time').hide();
        jQuery('#' + id + '_full_screen_modal').hide();
        jQuery('#' + id + '_modal_effect').hide();
        jQuery('#' + id + '_height').hide();
    }

    if (link_type == 'link' || link_type == 'onclick') {
        jQuery('#' + id + '_close_link').show();
        jQuery('#' + id + '_overlay').show();
        jQuery('#' + id + '_label').show();
        jQuery('#' + id + '_onclick_type').show();
        jQuery('#' + id + '_ideal_time').hide();
        jQuery('#' + id + '_modal_effect').show();
        jQuery('#' + id + '_full_screen_modal').show();
        jQuery('#' + id + '_height').hide();
        jQuery('#' + arf_img_url + '_div').hide();
        jQuery('#' + arf_img_height + '_div').hide();
        jQuery('#' + arf_img_width + '_div').hide(); 
    }

    if (link_type == 'button') {
        jQuery('#' + id + '_close_link').show();
        jQuery('#' + id + '_overlay').show();
        jQuery('#' + id + '_label').show();
        jQuery('#' + id + '_onclick_type').show();
        jQuery('#' + id + '_ideal_time').hide();
        jQuery('#' + id + '_height').hide();
    }

    if (link_type == 'link' || link_type == 'button' || link_type == 'image' || link_type == 'onclick') {
        jQuery('#' + id + '_custom_class').show();
    } else {
        jQuery('#' + id + '_custom_class').hide();
    }

}

function arf_update_color_widget(jscolor, id, is_element) {
    if (is_element == '' || is_element == null || is_element == 'undefined') {
        is_element = 0;
    }

    jQuery('input#arf_color_picker_input').val(jscolor);
    if (is_element == 1) {
        jQuery('#' + id).val('#' + jscolor).trigger('change');
    } else {
        if (!jQuery('#' + id).hasClass('jscolor')) {
            jQuery('#' + id).val('#' + jscolor).trigger('change');
        } else {
            jQuery('#' + id).next('input[type="hidden"]').trigger('change');
        }
    }
    jQuery("#arf_color_picker_input").val(jscolor);

    var inputstyle = jQuery('#' + id).attr('style');
    jQuery('#' + id).attr('style', inputstyle + 'background-color:#' + jscolor + ' !important');
    jQuery('#' + id).attr('style', inputstyle + ' background-color:#' + jscolor + ' !important;');
    jQuery('input#arf_color_picker_input').val(jscolor);
}
function HextoHsl(hex) {
    var hex = '#' + hex;
    if (hex.length == 7) {
        var rgb = [parseInt('0x' + hex.substring(1, 3)) / 255, parseInt('0x' + hex.substring(3, 5)) / 255, parseInt('0x' + hex.substring(5, 7)) / 255];
    } else if (hex.length == 4) {
        var rgb = [parseInt('0x' + hex.substring(1, 2)) / 15, parseInt('0x' + hex.substring(2, 3)) / 15, parseInt('0x' + hex.substring(3, 4)) / 15];
    } else {
        return 1;
    }
    var min, max, delta, h, s, l;
    var r = rgb[0],
        g = rgb[1],
        b = rgb[2];
    min = Math.min(r, Math.min(g, b));
    max = Math.max(r, Math.max(g, b));
    delta = max - min;
    l = (min + max) / 2;
    s = 0;
    if (l > 0 && l < 1) {
        s = delta / (l < 0.5 ? (2 * l) : (2 - 2 * l));
    }
    h = 0;
    if (delta > 0) {
        if (max == r && max != g) h += (g - b) / delta;
        if (max == g && max != b) h += (2 + (b - r) / delta);
        if (max == b && max != r) h += (4 + (r - g) / delta);
        h /= 6;
    }
    return l;
}