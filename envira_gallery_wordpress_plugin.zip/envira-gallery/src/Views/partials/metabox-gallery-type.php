<?php
/**
 * Outputs the Gallery Type Tab Selector and Panels
 *
 * @since   1.5.0
 *
 * @package Envira_Gallery
 * @author  Envira Gallery Team <support@enviragallery.com>
 */

$gallery_data = envira_get_gallery( $data['post']->ID );
$type         = envira_get_config( 'type', $gallery_data ) !== '' ? envira_get_config( 'type', $gallery_data ) : 'default';

?>
<h2 id="envira-types-nav" class="nav-tab-wrapper envira-tabs-nav" data-container="#envira-types" data-update-hashbang="0">
	<label class="nav-tab nav-tab-native-envira-gallery<?php echo ( ( 'default' === $type ) ? ' envira-active' : '' ); ?>" for="envira-gallery-type-default" data-tab="#envira-gallery-native">
		<input id="envira-gallery-type-default" type="radio" name="_envira_gallery[type]" value="default" <?php checked( $type, 'default' ); ?> />
		<?php if ( apply_filters( 'envira_whitelabel', false ) ) { ?>
			<span><?php esc_html_e( 'Native Gallery', 'envira-gallery' ); ?></span>
		<?php } else { ?>
			<span><?php esc_html_e( 'Native Envira Gallery', 'envira-gallery' ); ?></span>
		<?php } ?>

	</label>

	<a href="#envira-gallery-external" title="<?php esc_attr_e( 'External Gallery', 'envira-gallery' ); ?>" class="nav-tab nav-tab-external-gallery<?php echo 'default' !== $type ? ' envira-active' : ''; ?>">
		<span><?php esc_html_e( 'External Gallery', 'envira-gallery' ); ?></span>
	</a>

	<a href="#envira-gallery-envira-ai" title="<?php esc_attr_e( 'Create with Envira AI', 'envira-gallery' ); ?>" class="nav-tab nav-tab-envira-ai">
		<span><?php esc_html_e( 'Create with Envira AI', 'envira-gallery' ); ?></span>
	</a>
</h2>

<!-- Types -->
<div id="envira-types" data-navigation="#envira-types-nav">
	<!-- Native Envira Gallery - Drag and Drop Uploader -->
	<div id="envira-gallery-native" class="envira-tab envira-clear<?php echo 'default' === $type ? ' envira-active' : ''; ?>">
		<!-- Errors -->
		<div id="envira-gallery-upload-error"></div>

		<!-- WP Media Upload Form -->
			<?php
			media_upload_form();
			?>
		<script type="text/javascript">
			var post_id = <?php echo absint( $data['post']->ID ); ?>, shortform = 3;
		</script>
		<input type="hidden" name="post_id" id="post_id" value="<?php echo esc_attr( $data['post']->ID ); ?>" />
	</div>

	<!-- External Gallery -->
	<div id="envira-gallery-external" class="envira-tab envira-clear<?php echo 'default' !== $type ? ' envira-active' : ''; ?>">
		<?php
		$canonical_external_sources = [ 'instagram', 'dribbble', 'tiktok', 'google_photos' ];
		$default_external_titles    = [
			'instagram'     => __( 'Instagram', 'envira-gallery' ),
			'dribbble'      => __( 'Dribbble', 'envira-gallery' ),
			'tiktok'        => __( 'TikTok', 'envira-gallery' ),
			'google_photos' => __( 'Google Photos', 'envira-gallery' ),
		];
		$addons_page_url            = admin_url( 'edit.php?post_type=envira&page=envira-gallery-addons' );
		$upsell_assets              = trailingslashit( ENVIRA_URL ) . 'assets/images/';

		/**
		 * Renders one external source tile (license + addon state).
		 *
		 * @param string $source_id Type key.
		 */
		$render_external_tile = function ( $source_id ) use ( $data, $type, $default_external_titles, $addons_page_url ) {
			$title        = isset( $data['types'][ $source_id ] ) ? $data['types'][ $source_id ] : $default_external_titles[ $source_id ];
			$license_ok   = envira_user_license_allows_external_gallery_source( $source_id );
			$addon_active = envira_is_external_gallery_addon_active( $source_id );
			$li_classes   = ( $type === $source_id && $addon_active && $license_ok ) ? ' envira-active' : '';
			$li_id        = 'envira-gallery-type-' . sanitize_html_class( $source_id );

			if ( $license_ok && $addon_active ) {
				?>
				<li id="<?php echo esc_attr( $li_id ); ?>"<?php echo $li_classes ? ' class="envira-active"' : ''; ?>>
					<label for="envira-gallery-type-<?php echo esc_attr( $source_id ); ?>">
						<input id="envira-gallery-type-<?php echo esc_attr( $source_id ); ?>" type="radio" name="_envira_gallery[type]" value="<?php echo esc_attr( $source_id ); ?>" <?php checked( $type, $source_id ); ?> />
						<div class="icon"></div>
						<div class="title"><?php echo esc_html( $title ); ?></div>
					</label>
				</li>
				<?php
				return;
			}

			if ( $license_ok && ! $addon_active ) {
				?>
				<li id="<?php echo esc_attr( $li_id ); ?>" class="envira-external-tile envira-external-tile--inactive">
					<a href="<?php echo esc_url( $addons_page_url ); ?>" class="envira-external-addon-inactive" title="<?php echo esc_attr( $title ); ?>">
						<div class="icon"></div>
						<div class="title"><?php echo esc_html( $title ); ?></div>
						<div class="envira-external-tile-note"><?php esc_html_e( 'Install and activate this addon to use this source.', 'envira-gallery' ); ?></div>
					</a>
				</li>
				<?php
				return;
			}

			$external_modal_ids = [
				'instagram'     => 'envira-instagram-upsell-modal',
				'dribbble'      => 'envira-dribbble-upsell-modal',
				'tiktok'        => 'envira-tiktok-upsell-modal',
				'google_photos' => 'envira-external-google-photos-upsell-modal',
			];
			$modal_target       = isset( $external_modal_ids[ $source_id ] ) ? $external_modal_ids[ $source_id ] : 'envira-instagram-upsell-modal';
			?>
			<li id="<?php echo esc_attr( $li_id ); ?>" class="envira-external-tile envira-external-tile--upsell">
				<a href="javascript:void(0);" class="envira-external-license-upsell" data-envira-external-modal="<?php echo esc_attr( $modal_target ); ?>" title="<?php echo esc_attr( $title ); ?>">
					<div class="icon"></div>
					<div class="title"><?php echo esc_html( $title ); ?></div>
				</a>
			</li>
			<?php
		};

		?>
			<p class="envira-intro"><?php esc_html_e( 'Create Dynamic Galleries with Envira', 'envira-gallery' ); ?></p>
			<ul id="envira-gallery-types-nav">
				<?php
				foreach ( $canonical_external_sources as $source_id ) {
					$render_external_tile( $source_id );
				}
				foreach ( $data['types'] as $id => $title ) {
					if ( 'default' === $id || in_array( $id, $canonical_external_sources, true ) ) {
						continue;
					}
					?>
					<li id="envira-gallery-type-<?php echo sanitize_html_class( $id ); ?>"<?php echo $type === $id ? ' class="envira-active"' : ''; ?>>
						<label for="envira-gallery-type-<?php echo esc_attr( $id ); ?>">
							<input id="envira-gallery-type-<?php echo esc_attr( $id ); ?>" type="radio" name="_envira_gallery[type]" value="<?php echo esc_attr( $id ); ?>" <?php checked( $type, $id ); ?> />
							<div class="icon"></div>
							<div class="title"><?php echo esc_html( $title ); ?></div>
						</label>
					</li>
					<?php
				}
				?>
			</ul>

		<?php
		$url_instagram     = envira_get_upgrade_link( false, 'adminpageunlock_instagram', 'upgradetopro' );
		$url_dribbble      = envira_get_upgrade_link( false, 'adminpageunlock_dribbble', 'upgradetopro' );
		$url_tiktok        = envira_get_upgrade_link( false, 'adminpageunlock_tiktok', 'upgradetopro' );
		$url_google_photos = envira_get_upgrade_link( false, 'adminpageunlock_google-photos', 'upgradetopro' );
		?>
		<!-- Envira Instagram Upsell Modal (matches Lite) -->
		<div id="envira-instagram-upsell-modal" class="envira-addon-upsell-modal" aria-hidden="true">
			<div class="envira-addon-upsell-modal-overlay"></div>
			<div class="envira-addon-upsell-modal-content">
				<img src="<?php echo esc_url( $upsell_assets . 'close.png' ); ?>" alt="<?php esc_attr_e( 'Close upsell modal', 'envira-gallery' ); ?>" id="close-envira-instagram-upsell-modal" class="close-envira-addon-upsell-modal" />
				<div class="upsell-content-container">
					<div class="top-content">
						<img src="<?php echo esc_url( $upsell_assets . 'lock.png' ); ?>" alt="<?php esc_attr_e( 'Lock icon', 'envira-gallery' ); ?>" class="lock-icon" />
						<h3><?php esc_html_e( 'Instagram is a Pro Feature', 'envira-gallery' ); ?></h3>
						<p><?php esc_html_e( 'We’re sorry, using Instagram is not available on your plan. Please upgrade to the Pro plan to unlock all these awesome features.', 'envira-gallery' ); ?></p>
					</div>
					<div class="bottom-content">
						<div class="connector-icon">
							<img src="<?php echo esc_url( $upsell_assets . 'connector.png' ); ?>" alt="<?php esc_attr_e( 'Connector icon', 'envira-gallery' ); ?>" />
						</div>
						<a href="<?php echo esc_url( $url_instagram ); ?>" rel="noopener noreferrer" class="button button-upsell-modal" target="_blank"><?php esc_html_e( 'Upgrade to Pro', 'envira-gallery' ); ?>
							<img src="<?php echo esc_url( $upsell_assets . 'arrow-right.png' ); ?>" alt="" class="arrow-right-icon" />
						</a>
						<div class="discount-section">
							<div class="discount-percentage">
								<img src="<?php echo esc_url( $upsell_assets . 'discount-icon.png' ); ?>" alt="" />
								<span>%</span>
							</div>
							<p>
								<?php
								echo wp_kses_post(
									sprintf(
										/* translators: %s: plugin version number. Literal percent signs must be doubled (%%) for sprintf. */
										__( 'Envira Gallery %s users <span class="offer-text">get 50%% off</span> the regular price, automatically applied at checkout.', 'envira-gallery' ),
										esc_html( ENVIRA_VERSION )
									)
								);
								?>
							</p>
						</div>
					</div>
				</div>
			</div>
		</div>

		<!-- Envira Dribbble Upsell Modal (matches Lite) -->
		<div id="envira-dribbble-upsell-modal" class="envira-addon-upsell-modal" aria-hidden="true">
			<div class="envira-addon-upsell-modal-overlay"></div>
			<div class="envira-addon-upsell-modal-content">
				<img src="<?php echo esc_url( $upsell_assets . 'close.png' ); ?>" alt="<?php esc_attr_e( 'Close upsell modal', 'envira-gallery' ); ?>" id="close-envira-dribbble-upsell-modal" class="close-envira-addon-upsell-modal" />
				<div class="upsell-content-container">
					<div class="top-content">
						<img src="<?php echo esc_url( $upsell_assets . 'lock.png' ); ?>" alt="<?php esc_attr_e( 'Lock icon', 'envira-gallery' ); ?>" class="lock-icon" />
						<h3><?php esc_html_e( 'Dribbble is a Pro Feature', 'envira-gallery' ); ?></h3>
						<p><?php esc_html_e( 'We’re sorry, using Dribbble is not available on your plan. Please upgrade to the Pro plan to unlock all these awesome features.', 'envira-gallery' ); ?></p>
					</div>
					<div class="bottom-content">
						<div class="connector-icon">
							<img src="<?php echo esc_url( $upsell_assets . 'connector.png' ); ?>" alt="<?php esc_attr_e( 'Connector icon', 'envira-gallery' ); ?>" />
						</div>
						<a href="<?php echo esc_url( $url_dribbble ); ?>" rel="noopener noreferrer" class="button button-upsell-modal" target="_blank"><?php esc_html_e( 'Upgrade to Pro', 'envira-gallery' ); ?>
							<img src="<?php echo esc_url( $upsell_assets . 'arrow-right.png' ); ?>" alt="" class="arrow-right-icon" />
						</a>
						<div class="discount-section">
							<div class="discount-percentage">
								<img src="<?php echo esc_url( $upsell_assets . 'discount-icon.png' ); ?>" alt="" />
								<span>%</span>
							</div>
							<p><?php echo wp_kses_post( __( 'Envira Gallery lite users <span class="offer-text">get 50% off</span> the regular price, automatically applied at checkout.', 'envira-gallery' ) ); ?></p>
						</div>
					</div>
				</div>
			</div>
		</div>

		<!-- Envira Tiktok Upsell Modal (matches Lite) -->
		<div id="envira-tiktok-upsell-modal" class="envira-addon-upsell-modal" aria-hidden="true">
			<div class="envira-addon-upsell-modal-overlay"></div>
			<div class="envira-addon-upsell-modal-content">
				<img src="<?php echo esc_url( $upsell_assets . 'close.png' ); ?>" alt="<?php esc_attr_e( 'Close upsell modal', 'envira-gallery' ); ?>" id="close-envira-tiktok-upsell-modal" class="close-envira-addon-upsell-modal" />
				<div class="upsell-content-container">
					<div class="top-content">
						<img src="<?php echo esc_url( $upsell_assets . 'lock.png' ); ?>" alt="<?php esc_attr_e( 'Lock icon', 'envira-gallery' ); ?>" class="lock-icon" />
						<h3><?php esc_html_e( 'TikTok is a Pro Feature', 'envira-gallery' ); ?></h3>
						<p><?php esc_html_e( 'We’re sorry, using TikTok is not available on your plan. Please upgrade to the Pro plan to unlock all these awesome features.', 'envira-gallery' ); ?></p>
					</div>
					<div class="bottom-content">
						<div class="connector-icon">
							<img src="<?php echo esc_url( $upsell_assets . 'connector.png' ); ?>" alt="<?php esc_attr_e( 'Connector icon', 'envira-gallery' ); ?>" />
						</div>
						<a href="<?php echo esc_url( $url_tiktok ); ?>" rel="noopener noreferrer" class="button button-upsell-modal" target="_blank"><?php esc_html_e( 'Upgrade to Pro', 'envira-gallery' ); ?>
							<img src="<?php echo esc_url( $upsell_assets . 'arrow-right.png' ); ?>" alt="" class="arrow-right-icon" />
						</a>
						<div class="discount-section">
							<div class="discount-percentage">
								<img src="<?php echo esc_url( $upsell_assets . 'discount-icon.png' ); ?>" alt="" />
								<span>%</span>
							</div>
							<p><?php echo wp_kses_post( __( 'Envira Gallery lite users <span class="offer-text">get 50% off</span> the regular price, automatically applied at checkout.', 'envira-gallery' ) ); ?></p>
						</div>
					</div>
				</div>
			</div>
		</div>

		<!-- Envira Google Photos Upsell Modal (matches Lite; distinct id from addon metabox modal) -->
		<div id="envira-external-google-photos-upsell-modal" class="envira-addon-upsell-modal" aria-hidden="true">
			<div class="envira-addon-upsell-modal-overlay"></div>
			<div class="envira-addon-upsell-modal-content">
				<img src="<?php echo esc_url( $upsell_assets . 'close.png' ); ?>" alt="<?php esc_attr_e( 'Close upsell modal', 'envira-gallery' ); ?>" id="close-envira-external-google-photos-upsell-modal" class="close-envira-addon-upsell-modal" />
				<div class="upsell-content-container">
					<div class="top-content">
						<img src="<?php echo esc_url( $upsell_assets . 'lock.png' ); ?>" alt="<?php esc_attr_e( 'Lock icon', 'envira-gallery' ); ?>" class="lock-icon" />
						<h3><?php esc_html_e( 'Google Photos is a Pro Feature', 'envira-gallery' ); ?></h3>
						<p><?php esc_html_e( 'We’re sorry, using Google Photos is not available on your plan. Please upgrade to the Pro plan to unlock all these awesome features.', 'envira-gallery' ); ?></p>
					</div>
					<div class="bottom-content">
						<div class="connector-icon">
							<img src="<?php echo esc_url( $upsell_assets . 'connector.png' ); ?>" alt="<?php esc_attr_e( 'Connector icon', 'envira-gallery' ); ?>" />
						</div>
						<a href="<?php echo esc_url( $url_google_photos ); ?>" rel="noopener noreferrer" class="button button-upsell-modal" target="_blank"><?php esc_html_e( 'Upgrade to Pro', 'envira-gallery' ); ?>
							<img src="<?php echo esc_url( $upsell_assets . 'arrow-right.png' ); ?>" alt="" class="arrow-right-icon" />
						</a>
						<div class="discount-section">
							<div class="discount-percentage">
								<img src="<?php echo esc_url( $upsell_assets . 'discount-icon.png' ); ?>" alt="" />
								<span>%</span>
							</div>
							<p><?php echo wp_kses_post( __( 'Envira Gallery lite users <span class="offer-text">get 50% off</span> the regular price, automatically applied at checkout.', 'envira-gallery' ) ); ?></p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- Envira AI -->
	<div id="envira-gallery-envira-ai" class="envira-tab envira-clear">

		<p><?php esc_html_e( 'Add images to your gallery using the power of AI', 'envira-gallery' ); ?></p>
		<p>
			<?php
			$modal_class      = 'upsell';
			$ai_license_level = envira_get_license_level();
			if ( ! empty( $ai_license_level ) && ( 'pro' === $ai_license_level ) ) {
				$modal_class = 'create-images';
			}
			?>
			<a href="javascript:void(0);" class="button button-primary button-x-large button-envira-ai-tab <?php echo esc_attr( $modal_class ); ?>" title="<?php esc_attr_e( 'Create Images with AI', 'envira-gallery' ); ?>">
				<?php esc_html_e( 'Create Images with AI', 'envira-gallery' ); ?>
			</a>
		</p>

	</div>

</div>

<!-- Envira AI Upsell Modal -->
<div id="envira-ai-upsell-modal" class="envira-ai-modal">
	<div class="envira-ai-modal-overlay"></div>
	<div class="envira-ai-upsell-modal-content">
		<a href="javascript:void(0);" id="close-envira-ai-upsell" class="close-envira-ai-upsell">&times;</a>
		<div class="upsell-content-container">
			<img src="<?php echo esc_url( trailingslashit( ENVIRA_URL ) . 'assets/css/images/icons/locked-with-key.svg' ); ?>" alt="<?php esc_attr_e( 'Unlock feature', 'envira-gallery' ); ?>" class="lock-icon" />
			<h3><?php esc_html_e( 'Upgrade to Envira Gallery and Create images with AI!', 'envira-gallery' ); ?></h3>
			<p><?php esc_html_e( 'Create unique and stunning galleries with Envira AI. No matter the type of site or design style, Envira Gallery makes it easy to create assets without a designer.', 'envira-gallery' ); ?></p>
			<div class="upsell-two-column">
				<div class="upsell-left-column">
					<div class="top-content">
						<h4><?php esc_html_e( 'Here’s what you get with Envira AI', 'envira-gallery' ); ?></h4>
						<ul>
							<li><?php esc_html_e( 'Specify your asset needs.', 'envira-gallery' ); ?></li>
							<li><?php esc_html_e( 'Create an unlimited number of images.', 'envira-gallery' ); ?></li>
							<li><?php esc_html_e( 'Choose your design style.', 'envira-gallery' ); ?></li>
							<li><?php esc_html_e( 'Customize your image sizes.', 'envira-gallery' ); ?></li>
						</ul>
					</div>
					<div class="bottom-content">
						<a href="https://enviragallery.com/lite/?utm_source=liteplugin&amp;utm_medium=adminpageunlockai&amp;utm_campaign=upgradetopro" class="button button-primary" target="_blank"><?php esc_html_e( 'Unlock AI Features', 'envira-gallery' ); ?></a>
						<p class="gift-text">
							<?php
							$image_url = esc_url( trailingslashit( ENVIRA_URL ) . 'assets/css/images/icons/wrapped-gift.svg' );
							$image_alt = esc_attr__( 'Unlock feature', 'envira-gallery' );

							// Create the full HTML string.
							$html = sprintf(
								'<img src="%1$s" alt="%2$s" class="gift-icon" /> %3$s',
								$image_url,
								$image_alt,
								__( 'Plus <span class="offer-text">Save 50%</span> by Upgrading to Pro today', 'envira-gallery' )
							);

							echo wp_kses_post( $html );
							?>
						</p>
					</div>
				</div>
				<div class="upsell-right-column">
					<img src="<?php echo esc_url( trailingslashit( ENVIRA_URL ) . 'assets/images/upsell-ai-group.png' ); ?>" alt="<?php esc_attr_e( 'Demo Images', 'envira-gallery' ); ?>" />
				</div>
			</div>
		</div>
	</div>
</div>

<!-- Envira AI Create Images Modal -->
<div id="envira-ai-create-images-modal" class="envira-ai-modal">
	<div class="envira-ai-modal-overlay"></div>
	<div class="envira-ai-create-images-modal-content">
		<a href="javascript:void(0);" id="close-envira-ai-create-images" class="close-envira-ai-create-images">
			<img src="<?php echo esc_url( trailingslashit( ENVIRA_URL ) . 'assets/css/images/icons/cross-ai-modal.svg' ); ?>" alt="<?php esc_attr_e( 'Close', 'envira-gallery' ); ?>"/>
		</a>
		<div class="create-images-content-container">
			<div class="main-title">
				<h3><?php esc_html_e( 'Create Images with Envira AI', 'envira-gallery' ); ?></h3>
			</div>
			<div class="create-images-two-columns">
				<div class="left-column">
					<div class="form-container">
						<div class="form-group ai-form-field">
							<label for="envira-ai-image-prompt"><?php esc_html_e( 'Describe what you\'d like inside your image', 'envira-gallery' ); ?></label>
							<textarea id="envira-ai-image-prompt" name="envira_ai_image_prompt" rows="4" maxlength="1000" placeholder="<?php esc_attr_e( 'A picture of a happy dog running through a field', 'envira-gallery' ); ?>"></textarea>
							<span class="characters-limit">Maximum 1000 characters.</span>
							<span class="ai-error-message" id="ai-prompt-error"><?php esc_html_e( 'Please provide a description.', 'envira-gallery' ); ?></span>
							<span class="prompt-ajax-error envira-ai-response-error-msg"></span>
						</div>
						<div class="form-group ai-form-field">
							<label for="envira-ai-image-type"><?php esc_html_e( 'Image Type', 'envira-gallery' ); ?></label>
							<select id="envira-ai-image-type" name="envira_ai_image_type">
								<option value=""><?php esc_html_e( 'Select an option', 'envira-gallery' ); ?></option>
								<option value="none"><?php esc_html_e( 'None', 'envira-gallery' ); ?></option>
								<option value="photographic"><?php esc_html_e( 'Photographic', 'envira-gallery' ); ?></option>
								<option value="background"><?php esc_html_e( 'Background', 'envira-gallery' ); ?></option>
								<option value="handmade"><?php esc_html_e( 'Handmade', 'envira-gallery' ); ?></option>
								<option value="digital-art"><?php esc_html_e( 'Digital Art', 'envira-gallery' ); ?></option>
								<option value="3d"><?php esc_html_e( '3D', 'envira-gallery' ); ?></option>
							</select>
							<span class="ai-error-message" id="ai-type-error"><?php esc_html_e( 'Please select an image type.', 'envira-gallery' ); ?></span>
						</div>
						<div class="form-group ai-form-field">
							<label for="envira-ai-image-aspect-ratio"><?php esc_html_e( 'Image Size', 'envira-gallery' ); ?></label>
							<select id="envira-ai-image-aspect-ratio" name="envira_ai_image_aspect_ratio">
								<option value=""><?php esc_html_e( 'Select an option', 'envira-gallery' ); ?></option>
								<option value="1024x1024"><?php esc_html_e( 'Square (1024 x 1024)', 'envira-gallery' ); ?></option>
								<option value="1536x1024"><?php esc_html_e( 'Landscape (1536 x 1024)', 'envira-gallery' ); ?></option>
								<option value="1024x1536"><?php esc_html_e( 'Portrait (1024 x 1536)', 'envira-gallery' ); ?></option>
							</select>
							<span class="ai-error-message" id="ai-aspect-error"><?php esc_html_e( 'Please select an image size.', 'envira-gallery' ); ?></span>
						</div>
						<div class="form-group ai-form-field item-center">
							<?php
								$button_text       = esc_html__( 'Create images', 'envira-gallery' );
								$button_create_new = esc_html__( 'Create new images', 'envira-gallery' );
								$button_write_new  = esc_html__( 'Write New Prompt', 'envira-gallery' );
								$creating_text     = esc_html__( 'Creating...', 'envira-gallery' );
							?>
							<button class="create-images-submit-btn"
									data-button="<?php echo esc_attr( $button_text ); ?>"
									data-create="<?php echo esc_attr( $button_create_new ); ?>"
									data-loading="<?php echo esc_attr( $creating_text ); ?>">
								<?php echo esc_html( $button_text ); ?>
							</button>
							<span class="ajax-create-error envira-ai-response-error-msg"></span>
							<span class="ajax-create-success envira-ai-response-error-msg"></span>
						</div>
						<div class="form-group ai-add-selected-images item-center">
							<?php
								$add_images_text    = esc_html__( 'Add selected images', 'envira-gallery' );
								$add_images_loading = esc_html__( 'Adding...', 'envira-gallery' );
							?>
							<button class="add-selected-images-btn"
									data-add-images="<?php echo esc_attr( $add_images_text ); ?>"
									data-add-loading="<?php echo esc_attr( $add_images_loading ); ?>">
								<?php echo esc_html( $add_images_text ); ?>
							</button>
							<span class="ajax-add-error envira-ai-response-error-msg"></span>
							<span class="ajax-add-success envira-ai-response-error-msg"></span>
						</div>
						<div class="form-group ai-write-new-btn">
							<a href="javascript:void(0);" class="button-envira-ai-write-new" title="<?php echo esc_attr( $button_write_new ); ?>">
								<?php echo esc_html( $button_write_new ); ?>
							</a>
						</div>
					</div>
				</div>
				<div class="right-column">
					<div class="generate-image-text">
						<img src="<?php echo esc_url( trailingslashit( ENVIRA_URL ) . 'assets/css/images/icons/envira-ai-img.svg' ); ?>" alt="<?php esc_attr_e( 'Unlock feature', 'envira-gallery' ); ?>" class="lock-icon" />
						<p><?php esc_html_e( 'Generate images by describing your ideas and selecting the desired type and style.', 'envira-gallery' ); ?></p>
					</div>
				</div>
			</div>
		</div>
		<div class="envira-ai-images-spinner">
			<img src="<?php echo esc_url( trailingslashit( ENVIRA_URL ) . 'assets/css/images/icons/3-dots-spinner.svg' ); ?>" alt="<?php esc_attr_e( 'Please wait...', 'envira-gallery' ); ?>" class="ai-spinner" />
		</div>
	</div>
</div>
