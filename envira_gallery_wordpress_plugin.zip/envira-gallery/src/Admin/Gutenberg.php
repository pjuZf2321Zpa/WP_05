<?php
/**
 * Gutenberg class.
 *
 * @since 1.8.5
 *
 * @package Envira Gallery
 * @author  Envira Gallery Team <support@enviragallery.com>
 */

namespace Envira\Admin;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Gutenberg class.
 *
 * @since 1.8.5
 */
class Gutenberg {

	/**
	 * Flag to determine if media modal is loaded.
	 *
	 * @since 1.8.5
	 *
	 * @var object
	 */
	public $loaded = false;

	/**
	 * Galleries variable.
	 *
	 * @var array
	 */
	public $galleries = [];

	/**
	 * Primary class constructor.
	 *
	 * @since 1.8.5
	 */
	public function __construct() {

		add_action( 'init', [ $this, 'register_block' ] );
		add_action( 'enqueue_block_editor_assets', [ $this, 'editor_assets' ], 12 );
		add_action( 'current_screen', [ $this, 'get_galleries' ] );
	}

	/**
	 * Registers the block's metadata (attributes, apiVersion, editorStyle) from block.json.
	 *
	 * The block's `edit`/`save` are still registered client-side in `envira-gutenberg.js`;
	 * this server-side registration is what makes WordPress enqueue and load `editorStyle`
	 * into the iframed block editor canvas.
	 *
	 * @since 1.16.1
	 */
	public function register_block() {

		$registered = register_block_type( plugin_dir_path( ENVIRA_FILE ) . '_gutenberg/block.json' );

		if ( false === $registered ) {
			_doing_it_wrong( __METHOD__, 'Failed to register the envira/envira-gallery block.json - block editor styles will not load correctly in the iframed canvas.', '1.16.1' );

			// _doing_it_wrong() is silent unless WP_DEBUG is on, and this is the only
			// path that loads editorStyle in the iframed canvas - log unconditionally
			// so the failure is visible in production (see envira-gallery-lite#329).
			error_log( '[Envira Gallery] Failed to register the envira/envira-gallery block.json - block editor styles will not load correctly in the iframed canvas.' ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- deliberate: silent editor-CSS loss needs a production-visible signal.
		}
	}

	/**
	 * Helper Method to get the galleries
	 *
	 * @since 1.0.0
	 */
	public function get_galleries() {

		$current_screen = get_current_screen();

		global $wp_version;

		if ( ! is_null( $current_screen ) && method_exists( $current_screen, 'is_block_editor' ) && ( $current_screen->is_block_editor() || ( ( version_compare( $wp_version, '5.8.0', '>' ) && 'widgets' === $current_screen->base ) || 'customize' === $current_screen->base ) ) ) {
			$this->galleries = $this->fetch_galleries();
		}
	}

	/**
	 * Fetch the galleries the block editor's picker is populated from.
	 *
	 * The picker maps over this list and its placeholder branches on the list
	 * being empty, so anything missing here is unreachable in the editor - a
	 * single page hid every gallery past the first. Bounded because the list is
	 * localized into every editor screen; past the ceiling the picker falls back
	 * to its own `?search=` fetch, which is itself a single page and so not yet a
	 * complete answer for sites above the ceiling.
	 *
	 * @since 1.17.0
	 *
	 * @return array Gallery id/title pairs.
	 */
	protected function fetch_galleries() {

		$per_page = 100; // The collection's maximum page size.

		/**
		 * Filters how many galleries are preloaded into the block editor's picker.
		 *
		 * @since 1.17.0
		 *
		 * @param int $max Maximum number of galleries to localize. Default 500.
		 */
		$max = (int) apply_filters( 'envira_gutenberg_preloaded_galleries_limit', 500 );

		if ( $max < 1 ) {
			return [];
		}

		$server    = rest_get_server();
		$galleries = [];
		$collected = 0;
		$page      = 0;

		while ( $collected < $max ) {

			++$page;

			$request = new \WP_REST_Request( 'GET', '/wp/v2/envira-gallery' );

			// Ask for only the two fields the block editor actually reads off this
			// preload (the gallery picker's id + label). Without an explicit
			// whitelist WordPress runs every registered REST field, including
			// Rest::get_gallery_data(), which resolves each image in each returned
			// gallery one at a time — hundreds of sequential reads on a
			// gallery-heavy site. Where uploads are served through a stream wrapper
			// (Infinite Uploads iu://, WP Offload Media s3://) each of those is a
			// cloud round-trip, so the editor screen stalls until
			// max_execution_time kills it. add_additional_fields_to_object() gates
			// get_callback behind rest_is_field_included(), so naming the fields
			// here skips that work entirely — on local disk too.
			$request->set_query_params(
				[
					'per_page' => $per_page,
					'page'     => $page,
					'_fields'  => 'id,title',
				]
			);

			$response = rest_do_request( $request );

			if ( $response->is_error() ) {

				$data = $response->get_data();
				$code = is_array( $data ) && isset( $data['code'] ) ? $data['code'] : '';

				// Asking past the last page is how this loop ends when the gallery
				// count divides by $per_page, so that code alone is expected. Any
				// other error - a 403 from rest_pre_dispatch, a 500 - would
				// otherwise be indistinguishable from "no more galleries" and leave
				// the picker silently short, or empty and hidden on a page-one
				// failure. Log those, as register_block() does above.
				if ( 'rest_post_invalid_page_number' !== $code ) {
					error_log( // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- deliberate: a silently short gallery picker needs a production-visible signal.
						sprintf(
							'[Envira Gallery] Block editor gallery preload failed on page %d (%s: %s); the picker may be incomplete.',
							$page,
							$code ? $code : 'unknown',
							is_array( $data ) && isset( $data['message'] ) ? $data['message'] : ''
						)
					);
				}

				break;
			}

			$batch = $server->response_to_data( $response, false );

			if ( ! is_array( $batch ) || [] === $batch ) {
				break;
			}

			$galleries  = array_merge( $galleries, $batch );
			$batch_size = count( $batch );
			$collected += $batch_size;

			// WP_REST_Posts_Controller::get_items() calls update_post_thumbnail_cache()
			// on the result, and reading _thumbnail_id primes every one of that post's
			// meta rows - including the whole serialized _eg_gallery_data image list.
			// `_fields` gates the REST field callback, not that priming, so without
			// this the ceiling's worth of gallery blobs sits in the object cache on
			// every editor screen. Only id and title are used here; drop the rest.
			foreach ( $batch as $item ) {
				if ( isset( $item['id'] ) ) {
					wp_cache_delete( $item['id'], 'post_meta' );
				}
			}

			// A short page is the last page.
			if ( $batch_size < $per_page ) {
				break;
			}
		}

		return $collected > $max ? array_slice( $galleries, 0, $max ) : $galleries;
	}

	/**
	 * Enqueue Gutenberg block assets for backend editor.
	 *
	 * `wp-blocks`: includes block type registration and related functions.
	 * `wp-element`: includes the WordPress Element abstraction for describing the structure of your blocks.
	 * `wp-i18n`: To internationalize the block's text.
	 *
	 * @since 1.0.0
	 */
	public function editor_assets() {

		$current_screen = get_current_screen();

		$dependencies = [ 'wp-blocks', 'wp-i18n', 'wp-element', 'wp-components', 'wp-data', 'wp-api-fetch', 'wp-hooks', 'wp-block-editor', 'wp-compose' ];
		if ( isset( $current_screen->id ) && 'widgets' !== $current_screen->id ) {
			$dependencies[] = 'wp-editor';
		}

		wp_enqueue_script(
			'envira_gutenberg-block-js',
			plugins_url( 'assets/js/envira-gutenberg.js', ENVIRA_FILE ), // Block.build.js: we register the block here and built with Webpack.
			$dependencies, // dependencies, defined above.
			ENVIRA_VERSION,
			true // Enqueue the script in the footer.
		);

		wp_localize_script(
			'envira_gutenberg-block-js',
			'enviraData',
			[
				'bnbShowMore' => plugins_url( 'assets/images/bnb-more-icon.svg', ENVIRA_FILE ),
			]
		);

		$current_post_id = get_the_ID();

		if ( ! $current_post_id ) {
			$current_post_id = 0;
		}

		// Localize data to pass to the block script.
		$localized_data = [
			'postId'              => $current_post_id,
			'panelTitle'          => __( 'Envira Gallery', 'envira-gallery' ),
			'contentHeading'      => __( 'Convert this gallery to an Envira Gallery', 'envira-gallery' ),
			'contentDescription'  => __( 'Make your gallery shine with awesome customizations, drag and drop management, and much more.', 'envira-gallery' ),
			'contentButtonText'   => __( 'Convert to Envira Gallery', 'envira-gallery' ),
			'convertLoading'      => __( 'Converting...', 'envira-gallery' ),
			'convertRestNonce'    => wp_create_nonce( 'wp_rest' ),
			'convertApiUrl'       => '/envira-convert/v1/convert-gallery',
			'errorMessage'        => __( 'Failed to convert the gallery. Please try again.', 'envira-gallery' ),
			'confirmationMessage' => __( 'Are you sure you want to convert this gallery to an Envira Gallery?', 'envira-gallery' ),
			'invalidBlockMessage' => __( 'This block is not a WordPress Gallery block.', 'envira-gallery' ),
			'noImagesMessage'     => __( 'This gallery has no images.', 'envira-gallery' ),
		];

		wp_localize_script( 'envira_gutenberg-block-js', 'enviraBlockData', $localized_data );

		$layouts     = envira_get_layouts();
		$new_layouts = [];

		foreach ( $layouts as $layout => $data ) {
			$new_layouts[] = [
				'label' => $data['name'],
				'value' => $layout,
			];
		}

		$columns = envira_get_columns();

		$new_columns = [];
		foreach ( $columns as $options ) {
			$new_columns[] = [
				'label' => $options['name'],
				'value' => $options['value'],
			];
		}
		$lightbox_options = envira_get_lightbox_themes();

		$new_lightbox = [];
		foreach ( $lightbox_options as $options ) {
			$new_lightbox[] = [
				'label' => $options['name'],
				'value' => $options['value'],
			];
		}

		$image_option = envira_get_image_sizes();

		$new_sizes = [];
		foreach ( $image_option as $options ) {
			$new_sizes[] = [
				'label' => $options['name'],
				'value' => $options['value'],
			];
		}
		$options = [
			'layouts'         => $new_layouts,
			'columns'         => $new_columns,
			'lightbox_themes' => $new_lightbox,
			'image_sizes'     => $new_sizes,
			'sorting_options' => envira_get_sorting_options(),
			'galleries'       => is_array( $this->galleries ) ? $this->galleries : [],
		];

		$args_array = [
			'options'        => $options,
			'isLite'         => false,
			'media_position' => envira_get_setting( 'media_position' ),
			'admin_url'      => admin_url(),
			'debug'          => defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG,
		];
		wp_localize_script(
			'envira_gutenberg-block-js',
			'envira_args',
			$args_array
		);
	}
}
