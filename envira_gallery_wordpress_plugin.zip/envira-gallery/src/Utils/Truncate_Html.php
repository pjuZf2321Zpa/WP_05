<?php
/**
 * HTML class.
 *
 * @since 1.9.17
 *
 * @package Envira Gallery
 * @author Envira Gallery Team
 */

namespace Envira\Utils;

// phpcs:disable WordPress.NamingConventions.ValidFunctionName.MethodNameInvalid -- legacy name.
// phpcs:disable WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase

if ( ! class_exists( 'Truncate_Html' ) ) {

	/**
	 * Envira_Html class.
	 *
	 * @since 1.9.17
	 */
	class Truncate_Html {

		/**
		 * Holds the class object.
		 *
		 * @since 1.9.17
		 *
		 * @var object
		 */
		public static $instance;

		/**
		 * Holds the base class object.
		 *
		 * @since 1.9.17
		 *
		 * @var object
		 */
		public $base;

		/**
		 * Characters of text still allowed while walking the tree.
		 *
		 * @since 1.18.0
		 *
		 * @var int
		 */
		private $remaining = 0;

		/**
		 * Whether the cut has happened; every node after it is dropped.
		 *
		 * @since 1.18.0
		 *
		 * @var bool
		 */
		private $done = false;

		/**
		 * Primary class constructor.
		 *
		 * @since 1.9.17
		 */
		public function __construct() {
		}

		/**
		 * Truncate HTML to a number of text characters, keeping the markup valid.
		 *
		 * Tags do not count toward the limit. The cut lands on the last space inside the limit
		 * when there is one, and every tag open at the cut is closed. HTML whose text fits the
		 * limit is returned exactly as given.
		 *
		 * Up to 1.17.3 this was meant to count words but never truncated anything (#5226): the
		 * `DOMText` check was unqualified inside this namespace. Its DOMDocument round trip also
		 * read UTF-8 as Latin-1 and wrapped bare text in <p>.
		 *
		 * @since 1.9.17
		 *
		 * @param string $html     The HTML content to truncate.
		 * @param int    $limit    Maximum number of text characters.
		 * @param bool   $ellipses Whether to add ellipses.
		 * @return string
		 */
		public function truncate_html( $html, $limit, $ellipses = true ) {
			$html  = (string) $html;
			$limit = (int) $limit;

			if ( $limit <= 0 || mb_strlen( html_entity_decode( wp_strip_all_tags( $html ), ENT_QUOTES, 'UTF-8' ), 'UTF-8' ) <= $limit ) {
				return $html;
			}

			$this->remaining = $limit;
			$this->done      = false;

			// The encoding hint keeps UTF-8 from being read as Latin-1, and the wrapper stops
			// libxml from adding its own <p> around bare text.
			$dom = new \DOMDocument();
			libxml_use_internal_errors( true );
			$dom->loadHTML( '<?xml encoding="UTF-8"><div>' . $html . '</div>', LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD );
			libxml_clear_errors();

			$root = $dom->getElementsByTagName( 'div' )->item( 0 );
			if ( ! $root ) {
				return $html;
			}

			$this->trim_node( $root, $ellipses );

			$output = '';
			foreach ( $root->childNodes as $child ) { // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
				$output .= $dom->saveHTML( $child );
			}

			return $output;
		}

		/**
		 * Walk the children of a node, cutting the text node that crosses the limit and
		 * removing everything after it.
		 *
		 * @since 1.9.17
		 *
		 * @param \DOMNode $node     The node whose children to walk.
		 * @param bool     $ellipses Whether to add ellipses.
		 */
		private function trim_node( $node, $ellipses ) {
			$child = $node->firstChild; // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase

			while ( $child ) {
				$next = $child->nextSibling; // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase

				if ( $this->done ) {
					$node->removeChild( $child );
				} elseif ( $child instanceof \DOMText ) {
					$text   = $child->nodeValue; // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
					$length = mb_strlen( $text, 'UTF-8' );

					if ( $length > $this->remaining ) {
						$cut = mb_substr( $text, 0, $this->remaining, 'UTF-8' );

						// Back off to the last space unless the limit already ends a word.
						if ( ! preg_match( '/^\s/u', mb_substr( $text, $this->remaining, 1, 'UTF-8' ) ) ) {
							$space = mb_strrpos( $cut, ' ', 0, 'UTF-8' );
							if ( false !== $space && $space > 0 ) {
								$cut = mb_substr( $cut, 0, $space, 'UTF-8' );
							}
						}

						$child->nodeValue = rtrim( $cut ) . ( $ellipses ? '...' : '' ); // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
						$this->done       = true;
					} else {
						$this->remaining -= $length;
					}
				} elseif ( $child->hasChildNodes() ) {
					$this->trim_node( $child, $ellipses );
				}

				$child = $next;
			}
		}
	}
	// phpcs:enable WordPress.NamingConventions.ValidFunctionName.MethodNameInvalid -- legacy name.
	// phpcs:enable WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
}
