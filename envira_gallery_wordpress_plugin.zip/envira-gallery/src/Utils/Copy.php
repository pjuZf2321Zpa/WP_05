<?php
/**
 * Copy class.
 *
 * @since   1.0.0
 * @package Envira_Gallery
 * @author  Envira Team
 */

namespace Envira\Utils;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {

	exit;

}

/**
 * Helper Class to copy photos between galleries.
 *
 * @since 1.7.0
 */
class Copy {
	/**
	 * Path to the file.
	 *
	 * @since 1.0.0
	 * @var string
	 */
	public $file = __FILE__;

	/**
	 * Holds the base class object.
	 *
	 * @since 1.0.0
	 * @var object
	 */
	public $base;

	/**
	 * Holds any plugin error messages.
	 *
	 * @since 1.0.0
	 * @var array
	 */
	public $errors = [];

	/**
	 * Primary class constructor.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {

		// Copy photos from one gallery to another.
		add_action( 'admin_init', [ $this, 'copy_photos' ] );
		add_action( 'admin_notices', [ $this, 'notices' ] );
	}

	/**
	 * Imports an Envira gallery.
	 *
	 * @return void Return early (possibly setting errors) if failing proper checks to import the gallery.
	 * @since 1.0.0
	 */
	public function copy_photos() {

		if ( ! $this->verify_copy_gallery() ) {
			return;
		}

		if ( ! $this->can_copy_images() ) {
			$this->errors[] = __( 'Sorry, but you lack the permissions to copy images.', 'envira-gallery' );

			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce is verify_copy_gallery().
		$gallery_copy_to = empty( $_POST['envira_copy_target_gallery'] ) ? 0 : intval( $_POST['envira_copy_target_gallery'] );
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Nonce is verify_copy_gallery().
		$gallery_copy_from = empty( $_GET['post'] ) ? 0 : intval( $_GET['post'] );

		if ( ! $gallery_copy_to || ! $gallery_copy_from ) {
			$this->errors[] = __( 'Sorry, but there was an error.', 'envira-gallery' );

			return;
		}

		$existing_images     = [];
		$total_images_copied = 0;

		// Get Gallery Data.
		$gallery_data_copy_to   = envira_get_gallery( $gallery_copy_to );
		$gallery_data_copy_from = envira_get_gallery( $gallery_copy_from );
		if ( ! $gallery_data_copy_to || ! $gallery_data_copy_from ) {
			$this->errors[] = __( 'Sorry, but there was an error.', 'envira-gallery' );

			return;
		}
		// An empty source and an all-duplicates source both copy nothing, but
		// they are different problems, so do not report them with one message.
		if ( empty( $gallery_data_copy_from['gallery'] ) ) {
			$this->errors   = [];
			$this->errors[] = __( 'This gallery has no images to copy.', 'envira-gallery' );

			return;
		}

		// Make sure there is a gallery array. If there is not, then this makes things simple.
		if ( empty( $gallery_data_copy_to['gallery'] ) ) {
			$gallery_data_copy_to['gallery'] = $gallery_data_copy_from['gallery'];
			$total_images_copied             = count( $gallery_data_copy_from['gallery'] );
			// Simply add the images from the copy_from.
		} else {
			// We need to add unique items to the gallery array.
			foreach ( $gallery_data_copy_to['gallery'] as $gallery_data_copy_to_key => $gallery_data_copy_to_info ) {
				$existing_images[] = $gallery_data_copy_to_key;
			}
			foreach ( $gallery_data_copy_from['gallery'] as $gallery_data_copy_from_key => $gallery_data_copy_from_info ) {
				if ( ! in_array( $gallery_data_copy_from_key, $existing_images, true ) ) {
					$gallery_data_copy_to['gallery'][ $gallery_data_copy_from_key ] = $gallery_data_copy_from_info;
					++$total_images_copied;
				}
			}
		}

		if ( 0 === $total_images_copied ) {
			$this->errors   = [];
			$this->errors[] = __( 'Every image in this gallery is already in the gallery you selected, so nothing was copied.', 'envira-gallery' );

			return;
		}

		// Update the meta for the post that is receiving the gallery.
		update_post_meta( $gallery_copy_to, '_eg_gallery_data', $gallery_data_copy_to );

		$gallery_image_ids = array_map( 'intval', array_keys( $gallery_data_copy_to['gallery'] ) );

		// Record the association on each image too, otherwise deleting one from the
		// Media Library leaves this gallery pointing at an attachment that is gone.
		foreach ( $gallery_image_ids as $attach_id ) {
			$has_gallery = get_post_meta( $attach_id, '_eg_has_gallery', true );

			if ( empty( $has_gallery ) || ! is_array( $has_gallery ) ) {
				$has_gallery = [];
			}

			if ( ! in_array( $gallery_copy_to, array_map( 'intval', $has_gallery ), true ) ) {
				$has_gallery[] = $gallery_copy_to;
				update_post_meta( $attach_id, '_eg_has_gallery', $has_gallery );
			}
		}

		// Reading the gallery above primed the transient with its pre-copy contents,
		// so without this the copied images stay invisible until that transient expires.
		envira_flush_gallery_caches(
			$gallery_copy_to,
			! empty( $gallery_data_copy_to['config']['slug'] ) ? $gallery_data_copy_to['config']['slug'] : ''
		);
	}

	/**
	 * Determines if a gallery import nonce is valid and verified.
	 *
	 * @return bool True if the nonce is valid, false otherwise.
	 * @since 1.0.0
	 */
	public function verify_copy_gallery() {
		return isset( $_POST['envira-gallery-copy-images'] ) && wp_verify_nonce( sanitize_key( $_POST['envira-gallery-copy-images'] ), 'envira-gallery-copy-images' );
	}

	/**
	 * Determines if the user can actually import the gallery.
	 *
	 * @return bool True if the user can import the gallery, false otherwise.
	 * @since 1.0.0
	 */
	public function can_copy_images() {

		$manage_options = current_user_can( 'manage_options' );

		return apply_filters( 'envira_gallery_copy_images_cap', $manage_options );
	}

	/**
	 * Outputs any errors or notices generated by the class.
	 *
	 * @since 1.0.0
	 */
	public function notices() {

		if ( ! empty( $this->errors ) ) :
			?>
		<div id="message" class="error">
			<p><?php echo esc_html( implode( '<br>', $this->errors ) ); ?></p>
		</div>
			<?php
		endif;

		// If a gallery has been copied, create a notice for the status.
		if ( empty( $this->errors ) && $this->verify_copy_gallery() ) :
			?>
		<div id="message" class="updated">
			<p><?php echo esc_html( __( 'Photos copied.', 'envira-gallery' ) ); ?></p>
		</div>
			<?php
		endif;
	}
}
