<?php
/**
 * Handles all rest endpoints and functions related to envira ai image creation feature.
 *
 * @since 1.9.18
 *
 * @package Envira Gallery
 * @author  Envira Gallery Team <support@enviragallery.com>
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Strip control characters (including CR/LF) from a value before writing it
 * to the error log, so attacker-controlled input can't forge or inject
 * fake log entries (log forging / CWE-117).
 *
 * @since 1.9.19
 *
 * @param string $value Value to sanitize for logging.
 * @return string
 */
function envira_ai_sanitize_for_log( $value ) {
	return preg_replace( '/[\x00-\x1F\x7F]/', '', (string) $value );
}

/**
 * Response contract this release speaks to the Envira AI image service.
 *
 * 2 is the base64 (b64_json) payload introduced for #5679; 1 was the OpenAI-hosted URLs the
 * retired dall-e models returned. The service refuses anything below its own minimum, which
 * is why it does not need to know this plugin's version number.
 *
 * @since 1.18.0
 */
if ( ! defined( 'ENVIRA_AI_CLIENT_CONTRACT' ) ) {
	define( 'ENVIRA_AI_CLIENT_CONTRACT', 2 );
}

/**
 * Absolute path to the directory that holds AI generations awaiting selection.
 *
 * Generated images arrive from the service as base64 and are written here, so the browser
 * can preview them and the picked ones can be imported without a second network fetch.
 *
 * @since 1.18.0
 *
 * @return string|WP_Error Absolute path, or WP_Error when uploads are unavailable.
 */
function envira_ai_generation_basedir() {
	$uploads = wp_get_upload_dir();

	if ( ! empty( $uploads['error'] ) ) {
		return new WP_Error( 'envira_ai_uploads_unavailable', __( 'The uploads directory is not available. Please check your file permissions.', 'envira-gallery' ) );
	}

	return untrailingslashit( $uploads['basedir'] ) . '/envira-ai-tmp';
}

/**
 * Public URL matching envira_ai_generation_basedir().
 *
 * @since 1.18.0
 *
 * @return string|WP_Error
 */
function envira_ai_generation_baseurl() {
	$uploads = wp_get_upload_dir();

	if ( ! empty( $uploads['error'] ) ) {
		return new WP_Error( 'envira_ai_uploads_unavailable', __( 'The uploads directory is not available. Please check your file permissions.', 'envira-gallery' ) );
	}

	return untrailingslashit( $uploads['baseurl'] ) . '/envira-ai-tmp';
}

/**
 * Map a generation id to its directory on disk.
 *
 * The id is matched against a strict pattern, so a crafted value can never traverse out of
 * the generation directory.
 *
 * @since 1.18.0
 *
 * @param  string $generation_id Generation id.
 * @return string|false Directory path, or false when the id is malformed or unknown.
 */
function envira_ai_generation_dir( $generation_id ) {
	if ( ! is_string( $generation_id ) || ! preg_match( '/^[A-Za-z0-9]{20}$/', $generation_id ) ) {
		return false;
	}

	$basedir = envira_ai_generation_basedir();

	if ( is_wp_error( $basedir ) ) {
		return false;
	}

	$dir = $basedir . '/' . $generation_id;

	return is_dir( $dir ) ? $dir : false;
}

/**
 * Resolve one generated image within a generation.
 *
 * @since 1.18.0
 *
 * @param  string $generation_id Generation id.
 * @param  int    $index         Image index within the generation.
 * @return string|false Absolute file path, or false when it does not exist.
 */
function envira_ai_generation_file( $generation_id, $index ) {
	$dir = envira_ai_generation_dir( $generation_id );

	if ( ! $dir ) {
		return false;
	}

	foreach ( [ 'jpg', 'png', 'webp' ] as $extension ) {
		$path = $dir . '/' . (int) $index . '.' . $extension;

		if ( is_file( $path ) ) {
			return $path;
		}
	}

	return false;
}

/**
 * Write the base64 images returned by the service into a new generation directory.
 *
 * @since 1.18.0
 *
 * @param  array  $images_base64 Base64 encoded image payloads.
 * @param  string $format        Format reported by the service (jpeg, png or webp).
 * @return array|WP_Error Generation id and the stored images, or WP_Error on failure.
 */
function envira_ai_store_generated_images( $images_base64, $format ) {
	// The extension comes from the bytes, not from the service's `format` field, so a
	// mislabelled payload cannot land under the wrong extension. $format is advisory only.
	$allowed_mimes = [
		'image/jpeg' => 'jpg',
		'image/png'  => 'png',
		'image/webp' => 'webp',
	];

	$basedir = envira_ai_generation_basedir();

	if ( is_wp_error( $basedir ) ) {
		return $basedir;
	}

	$baseurl = envira_ai_generation_baseurl();

	if ( is_wp_error( $baseurl ) ) {
		return $baseurl;
	}

	$generation_id = wp_generate_password( 20, false, false );
	$dir           = $basedir . '/' . $generation_id;

	if ( ! wp_mkdir_p( $dir ) ) {
		return new WP_Error( 'envira_ai_generation_mkdir_failed', __( 'Unable to store the generated images. Please check your uploads folder permissions.', 'envira-gallery' ), [ 'status' => 500 ] );
	}

	// Keep the folder itself unlistable, so the unguessable generation ids cannot simply be
	// read off a directory index. A failure here is logged rather than ignored.
	$listing_guard = $basedir . '/index.html';

	if ( ! file_exists( $listing_guard ) ) {
		if ( false === file_put_contents( $listing_guard, '' ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- empty guard file inside our own uploads subfolder.
			envira_ai_log_service_failure( 'storage', 'Could not write the directory listing guard at ' . $listing_guard );
		}
	}

	$stored  = [];
	$dropped = [];
	$images  = array_values( (array) $images_base64 );

	// The service asks OpenAI for 9; a response far beyond that means something upstream
	// changed, so write a bounded number rather than whatever arrives.
	if ( count( $images ) > 25 ) {
		envira_ai_log_service_failure( 'storage', sprintf( 'Response carried %d images; writing the first 25 only.', count( $images ) ) );

		$images = array_slice( $images, 0, 25 );
	}

	foreach ( $images as $index => $image_base64 ) {
		if ( ! is_string( $image_base64 ) || '' === $image_base64 ) {
			$dropped[] = sprintf( 'image %d: empty payload', $index );
			continue;
		}

		$bytes = base64_decode( $image_base64, true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- decoding the service's image payload.

		if ( false === $bytes || '' === $bytes ) {
			$dropped[] = sprintf( 'image %d: payload is not valid base64', $index );
			continue;
		}

		// Silenced deliberately: a truncated or malformed payload makes this emit a notice,
		// and with WP_DEBUG_DISPLAY on that text prefixes the REST body and breaks the JSON
		// the admin JS parses. The false return is the signal we want, and it is handled.
		$image_info = @getimagesizefromstring( $bytes ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- see above.
		$mime       = is_array( $image_info ) && ! empty( $image_info['mime'] ) ? $image_info['mime'] : '';

		if ( ! isset( $allowed_mimes[ $mime ] ) ) {
			$dropped[] = sprintf( 'image %d: not a supported image (detected "%s")', $index, $mime );
			continue;
		}

		$file_name = $index . '.' . $allowed_mimes[ $mime ];

		if ( false === file_put_contents( $dir . '/' . $file_name, $bytes ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- writing decoded image bytes into our own uploads subfolder.
			$dropped[] = sprintf( 'image %d: could not be written to %s', $index, $dir );
			continue;
		}

		$stored[] = [
			'index' => $index,
			'url'   => $baseurl . '/' . $generation_id . '/' . $file_name,
		];
	}

	// Never drop images quietly: a half-written generation looks identical to the service
	// returning fewer, which is the class of invisible failure behind #5679.
	if ( $dropped ) {
		envira_ai_log_service_failure(
			'storage',
			sprintf( 'Stored %d of %d generated images — %s', count( $stored ), count( $images ), implode( '; ', $dropped ) )
		);
	}

	if ( empty( $stored ) ) {
		envira_ai_delete_generation( $generation_id );

		return new WP_Error( 'envira_ai_generation_write_failed', __( 'Unable to store the generated images. Please try again.', 'envira-gallery' ), [ 'status' => 500 ] );
	}

	return [
		'generation_id' => $generation_id,
		'images'        => $stored,
	];
}

/**
 * Delete a generation directory and everything inside it.
 *
 * @since 1.18.0
 *
 * @param  string $generation_id Generation id.
 * @return void
 */
function envira_ai_delete_generation( $generation_id ) {
	$dir = envira_ai_generation_dir( $generation_id );

	if ( ! $dir ) {
		return;
	}

	$files = glob( $dir . '/*' );

	if ( false === $files ) {
		envira_ai_log_service_failure( 'storage', 'Could not read the generation directory ' . $dir );

		return;
	}

	foreach ( $files as $file ) {
		if ( is_file( $file ) ) {
			wp_delete_file( $file );
		}
	}

	// A directory that cannot be removed is re-attempted on every create, so report it
	// rather than letting previews pile up invisibly.
	if ( ! rmdir( $dir ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_rmdir -- removing our own now-empty generation folder.
		envira_ai_log_service_failure( 'storage', 'Could not remove the generation directory ' . $dir );
	}
}

/**
 * Remove generations whose images were never imported.
 *
 * @since 1.18.0
 *
 * @return void
 */
function envira_ai_cleanup_stale_generations() {
	$basedir = envira_ai_generation_basedir();

	if ( is_wp_error( $basedir ) || ! is_dir( $basedir ) ) {
		return;
	}

	$cutoff = time() - HOUR_IN_SECONDS;
	$dirs   = glob( $basedir . '/*', GLOB_ONLYDIR );

	if ( false === $dirs ) {
		envira_ai_log_service_failure( 'storage', 'Could not list generations in ' . $basedir );

		return;
	}

	foreach ( $dirs as $dir ) {
		$modified = filemtime( $dir );

		// Try to sweep anything whose age cannot be read rather than skipping it outright.
		// envira_ai_delete_generation() re-validates the name and existence, so an entry it
		// rejects is still left alone.
		if ( false !== $modified && $modified > $cutoff ) {
			continue;
		}

		envira_ai_delete_generation( basename( $dir ) );
	}
}
add_action( 'envira_ai_cleanup_generations', 'envira_ai_cleanup_stale_generations' );

/**
 * Make sure the stale-generation sweep is scheduled.
 *
 * @since 1.18.0
 *
 * @return void
 */
function envira_ai_maybe_schedule_generation_cleanup() {
	if ( ! wp_next_scheduled( 'envira_ai_cleanup_generations' ) ) {
		wp_schedule_event( time() + HOUR_IN_SECONDS, 'hourly', 'envira_ai_cleanup_generations' );
	}
}
add_action( 'admin_init', 'envira_ai_maybe_schedule_generation_cleanup' );

/**
 * Permission callback for AI image endpoints.
 *
 * @since 1.9.18
 *
 * @param WP_REST_Request $request Request object.
 * @return true|WP_Error Only true/false/WP_Error are valid; a WP_REST_Response would be truthy and silently grant access.
 */
function envira_gallery_ai_verify_permission( $request ) {
	if ( ! is_user_logged_in() ) {
		return new WP_Error( 'rest_not_logged_in', __( 'You must be logged in to access this feature.', 'envira-gallery' ), [ 'status' => 401 ] );
	}

	$required_capability = apply_filters( 'envira_ai_image_capability', 'edit_posts' );
	if ( ! current_user_can( $required_capability ) ) {
		return new WP_Error( 'rest_forbidden', __( 'You do not have permission to access this feature.', 'envira-gallery' ), [ 'status' => 403 ] );
	}

	// Generated images are written into uploads and become attachments, so upload rights are
	// required too — a Contributor has edit_posts but not upload_files.
	if ( ! current_user_can( 'upload_files' ) ) {
		return new WP_Error( 'rest_forbidden', __( 'You do not have permission to upload files.', 'envira-gallery' ), [ 'status' => 403 ] );
	}

	return true;
}

/**
 * Register REST API route for Envira AI Image creation.
 *
 * @since 1.9.18
 */
add_action(
	'rest_api_init',
	function () {
		register_rest_route(
			'envira-ai/v1',
			'/create-ai-images',
			[
				'methods'             => 'POST',
				'callback'            => 'envira_gallery_ai_rest_create_images',
				'permission_callback' => 'envira_gallery_ai_verify_permission',
			]
		);
	}
);

/**
 * REST API Callback to create images using Envira AI.
 *
 * @since 1.9.18
 *
 * @param WP_REST_Request $request Request object.
 * @return WP_REST_Response|WP_Error
 */
function envira_gallery_ai_rest_create_images( $request ) {
	// Get form data from the request.
	$prompt       = sanitize_text_field( $request->get_param( 'prompt' ) );
	$image_type   = sanitize_text_field( $request->get_param( 'image_type' ) );
	$aspect_ratio = sanitize_text_field( $request->get_param( 'aspect_ratio' ) );

	// Prompt should not be empty.
	if ( empty( $prompt ) ) {
		return new WP_REST_Response( [ 'rest_invalid_prompt' => __( 'Please provide a valid description.', 'envira-gallery' ) ], 400 );
	}

	// Regular expression to check if the prompt contains only special characters.
	if ( preg_match( '/^[^a-zA-Z0-9]+$/', $prompt ) ) {
		return new WP_REST_Response( [ 'rest_invalid_prompt' => __( 'Please enter a valid description. It should not contain only special characters.', 'envira-gallery' ) ], 400 );
	}

	// Check for maximum character limit of prompt.
	if ( strlen( $prompt ) > 1000 ) {
		return new WP_REST_Response( [ 'rest_invalid_prompt' => __( 'Description cannot exceed 1000 characters.', 'envira-gallery' ) ], 400 );
	}

	// Call your API to generate images.
	$api_response = envira_openai_image_generator_api_request( $prompt, $image_type, $aspect_ratio );

	if ( is_wp_error( $api_response ) ) {
		return envira_gallery_ai_rest_error_response( $api_response );
	}

	// Sweep here as well as on cron: wp_next_scheduled() reads truthy for a past-due event,
	// so on a site with a stalled scheduler the cron alone would never clear the folder.
	envira_ai_cleanup_stale_generations();

	// The service returns base64 payloads, so write them out before they can be previewed.
	$stored = envira_ai_store_generated_images( $api_response['images'], $api_response['format'] );

	if ( is_wp_error( $stored ) ) {
		return envira_gallery_ai_rest_error_response( $stored );
	}

	envira_ai_save_count_generated_images( count( $stored['images'] ) );

	ob_start();
	?>
	<div class="generated-ai-images-section" data-generation="<?php echo esc_attr( $stored['generation_id'] ); ?>">
		<div class="generated-ai-images-headline">
			<p><?php esc_html_e( 'Click on an image to add it to your gallery.', 'envira-gallery' ); ?></p>
		</div>
		<div class="generated-ai-images-result">
		<?php
		// Process and display the generated images.
		foreach ( $stored['images'] as $image ) {
			?>
			<div class="ai-image-item">
				<input type="checkbox" class="ai-image-checkbox" id="ai-image-checkbox-<?php echo esc_attr( $image['index'] ); ?>" data-index="<?php echo esc_attr( $image['index'] ); ?>" />
				<img class="ai-download-image-link download-image" src="<?php echo esc_url( trailingslashit( ENVIRA_URL ) . 'assets/css/images/icons/download-img.svg' ); ?>" alt="<?php echo esc_attr__( 'AI Generated Image', 'envira-gallery' ); ?>" data-index="<?php echo esc_attr( $image['index'] ); ?>"/>
				<img class="ai-image" src="<?php echo esc_url( $image['url'] ); ?>" />
			</div>
			<?php
		}
		?>
		</div>
	</div>
	<?php
	$html = ob_get_clean();

	// Send back the images and the message.
	return rest_ensure_response(
		[
			'html'          => $html,
			'message'       => isset( $api_response['message'] ) ? $api_response['message'] : '',
			'generation_id' => $stored['generation_id'],
		]
	);
}

/**
 * Convert a WP_Error from the AI image flow into a REST response.
 *
 * The upstream status and code are kept, so a permission problem, a quota problem and a
 * provider outage are distinguishable instead of all arriving as the same bare 400. See
 * #5679.
 *
 * @since 1.18.0
 *
 * @param  WP_Error $error Error to convert.
 * @return WP_REST_Response
 */
function envira_gallery_ai_rest_error_response( $error ) {
	$data            = $error->get_error_data();
	$upstream_status = isset( $data['status'] ) ? (int) $data['status'] : 0;

	// Pass through the statuses that describe the real problem; anything else becomes a
	// bad gateway, because the failure happened upstream rather than in this request.
	$status = in_array( $upstream_status, [ 400, 401, 403, 429, 500, 503 ], true ) ? $upstream_status : 502;

	return new WP_REST_Response(
		[
			'rest_api_error'  => $error->get_error_message(),
			'upstream_status' => $upstream_status ? $upstream_status : null,
			'upstream_code'   => isset( $data['upstream_code'] ) ? $data['upstream_code'] : '',
		],
		$status
	);
}

/**
 * Function to make the REST API call to Envira OpenAI Image Generator.
 *
 * @param string $prompt The image generation prompt.
 * @param string $image_type The type of image.
 * @param string $aspect_ratio The aspect ratio of the image.
 */
function envira_openai_image_generator_api_request( $prompt, $image_type, $aspect_ratio ) {
	$url = 'https://enviragallery.com/wp-json/envira-ai/v1/generate-image';

	// Get license key.
	$license_key = envira_get_license_key();

	$body = [
		'prompt'          => sanitize_text_field( $prompt ),
		'image_type'      => sanitize_text_field( $image_type ),
		'aspect_ratio'    => sanitize_text_field( $aspect_ratio ),
		'license_key'     => $license_key,
		'site_url'        => site_url(),
		// Declares which response shape this release understands, so the service can refuse
		// older callers without tracking plugin release numbers. See #5679.
		'client_contract' => ENVIRA_AI_CLIENT_CONTRACT,
		// Diagnostics only — the gate above is what decides.
		'plugin_version'  => ENVIRA_VERSION,
	];

	$response = wp_remote_post(
		$url,
		[
			'method'  => 'POST',
			'body'    => wp_json_encode( $body ),
			'headers' => [
				'Content-Type' => 'application/json',
			],
			'timeout' => 120,
		]
	);

	// Check if there's a connection error.
	if ( is_wp_error( $response ) ) {
		envira_ai_log_service_failure( 'transport', $response->get_error_message() );

		return new WP_Error(
			'envira_ai_connection_error',
			__( 'We could not reach the Envira AI service. Please try again in a moment.', 'envira-gallery' ),
			[ 'status' => 503 ]
		);
	}

	// Get response body and decode it.
	$response_body = wp_remote_retrieve_body( $response );
	$result        = json_decode( $response_body, true );

	// Retrieve HTTP status code.
	$status_code = wp_remote_retrieve_response_code( $response );

	// Handle different HTTP status codes.
	if ( $status_code >= 400 ) {
		// Define the default messages for each status code.
		$default_messages = [
			400 => __( 'Bad Request: The API request was invalid. Please check your prompt and parameters.', 'envira-gallery' ),
			401 => __( 'Unauthorized: Invalid license key or missing authorization.', 'envira-gallery' ),
			403 => __( 'Forbidden: You do not have access to the Envira AI API endpoint. Please check your permissions.', 'envira-gallery' ),
			404 => __( 'Not Found: The requested resource could not be found on the server.', 'envira-gallery' ),
			429 => __( 'Too Many Requests: You have exceeded the API request limit. Try again later.', 'envira-gallery' ),
			500 => __( 'Server Error: There is a problem on the server. Please try again later.', 'envira-gallery' ),
		];

		// Get the message from the result if available, otherwise use the default message.
		$message       = isset( $result['message'] ) ? $result['message'] : ( isset( $default_messages[ $status_code ] ) ? $default_messages[ $status_code ] : __( 'Unknown error occurred.', 'envira-gallery' ) );
		$upstream_code = isset( $result['code'] ) ? $result['code'] : '';

		envira_ai_log_service_failure( $status_code, $message, $upstream_code );

		return new WP_Error(
			'envira_ai_service_error',
			$message,
			[
				'status'        => $status_code,
				'upstream_code' => $upstream_code,
			]
		);
	}

	if ( empty( $result['format'] ) ) {
		envira_ai_log_service_failure( $status_code, 'Response carries no format field — the AI service has not been updated for the base64 response shape yet.' );

		return new WP_Error(
			'envira_ai_service_outdated',
			__( 'The Envira AI service is being updated. Please try again shortly.', 'envira-gallery' ),
			[ 'status' => 503 ]
		);
	}

	if ( empty( $result['images'] ) || ! is_array( $result['images'] ) ) {
		envira_ai_log_service_failure( $status_code, 'Service responded without any images.' );

		return new WP_Error(
			'envira_ai_no_images',
			__( 'Unexpected error: No images found in the response. Please try again with different image description.', 'envira-gallery' )
		);
	}

	return [
		'images'  => $result['images'],
		'format'  => isset( $result['format'] ) ? sanitize_key( $result['format'] ) : 'png',
		'message' => isset( $result['message'] ) ? $result['message'] : '',
	];
}

/**
 * Log an Envira AI service failure, so the cause stays recoverable from the debug log.
 *
 * @since 1.18.0
 *
 * @param  int|string $status  HTTP status returned by the service, or a short label.
 * @param  string     $message Message returned by the service.
 * @param  string     $code    Service error code, when present.
 * @return void
 */
function envira_ai_log_service_failure( $status, $message, $code = '' ) {
	error_log( // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- deliberate operational audit trail.
		sprintf(
			'Envira AI create-images failed: status=%s code=%s message=%s',
			envira_ai_sanitize_for_log( $status ),
			envira_ai_sanitize_for_log( $code ),
			envira_ai_sanitize_for_log( substr( (string) $message, 0, 500 ) )
		)
	);
}

/**
 * Helper method to save the total generated images count and weekly generated images count.
 *
 * @param  int $image_count image count.
 * @return void
 */
function envira_ai_save_count_generated_images( $image_count ) {
	// Get the current total generated images count.
	$total_generated_images     = get_option( 'envira_ai_total_generated_images_count', 0 );
	$new_total_generated_images = $total_generated_images + $image_count;

	// Get the current week and year using wp_date() to ensure proper timezone handling.
	$current_week = wp_date( 'W' ); // ISO-8601 week number of year (weeks starting on Monday).
	$current_year = wp_date( 'Y' ); // Current year.

	// Get the stored weekly count and the week/year when it was last updated.
	$weekly_data = get_option(
		'envira_ai_weekly_generated_images_data',
		[
			'week'  => 0,
			'year'  => 0,
			'count' => 0,
		]
	);

	// Check if the stored data is from the current week.
	if ( $weekly_data['week'] === $current_week && $weekly_data['year'] === $current_year ) {
		// Add the new images to the existing count for this week.
		$weekly_data['count'] += $image_count;
	} else {
		// It's a new week, so reset the count and set the current week and year.
		$weekly_data = [
			'week'  => $current_week,
			'year'  => $current_year,
			'count' => $image_count,
		];
	}

	// Update the total count and the weekly data in the options table.
	update_option( 'envira_ai_total_generated_images_count', $new_total_generated_images );
	update_option( 'envira_ai_weekly_generated_images_data', $weekly_data );
}

/**
 * Add selected images into gallery.
 *
 * @since 1.9.18
 */
add_action( 'wp_ajax_envira_gallery_ai_add_selected_images', 'envira_gallery_ai_ajax_add_selected_images' );

/**
 * Helper Method to add selected images into gallery.
 *
 * @access public
 * @return void
 */
function envira_gallery_ai_ajax_add_selected_images() {
	// Check nonce.
	check_admin_referer( 'envira-gallery-ai-add-selected-images-nonce', 'ai_add_image_nonce' );

	// Check capability — nonce alone only proves CSRF protection, not authorization.
	$required_capability = apply_filters( 'envira_ai_image_capability', 'edit_posts' );
	if ( ! current_user_can( $required_capability ) || ! current_user_can( 'upload_files' ) ) {
		wp_send_json_error(
			[
				'error_message' => __( 'You do not have permission to access this feature.', 'envira-gallery' ),
			]
		);
	}

	// Generated images already live on this site, so the browser only sends which ones were
	// picked. No client-supplied URL is fetched any more, which is what the SSRF validation
	// on this path used to guard against.
	$generation_id = isset( $_POST['generation_id'] ) ? sanitize_text_field( wp_unslash( $_POST['generation_id'] ) ) : '';
	$raw_indices   = isset( $_POST['selected_indices'] ) ? wp_unslash( $_POST['selected_indices'] ) : []; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- cast to integers below.

	// Get the Envira Gallery ID.
	$post_id = isset( $_POST['post_id'] ) ? absint( wp_unslash( $_POST['post_id'] ) ) : 0;

	// The downstream insert verifies this nonce only after the attachments exist and then
	// wp_die()s, which the import rollback cannot reach — so a stale nonce would leave the
	// orphans the rollback exists to prevent. Verify it up front.
	$insert_nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';

	if ( ! wp_verify_nonce( $insert_nonce, 'envira-gallery-insert-images' ) ) {
		wp_send_json_error(
			[
				'error_message' => __( 'Your session has expired. Please reload the page and try again.', 'envira-gallery' ),
			]
		);
	}

	// Check this before importing anything. envira_gallery_ajax_insert_images() does its own
	// per-post check, but only after the attachments exist — so without this, images land in
	// the media library parented to a gallery the user cannot edit and then stay there.
	if ( ! $post_id || ! current_user_can( 'edit_post', $post_id ) ) {
		wp_send_json_error(
			[
				'error_message' => __( 'You do not have permission to add images to this gallery.', 'envira-gallery' ),
			]
		);
	}

	$image_paths = [];

	foreach ( (array) $raw_indices as $raw_index ) {
		$path = envira_ai_generation_file( $generation_id, absint( $raw_index ) );

		if ( $path ) {
			$image_paths[] = $path;
		}
	}

	if ( empty( $image_paths ) ) {
		wp_send_json_error(
			[
				'error_message' => __( 'These generated images are no longer available. Please create them again.', 'envira-gallery' ),
			]
		);
	}

	// Import the picked images into the media library.
	$attachments_data = envira_ai_insert_generated_images( $image_paths, $post_id );

	// Check if there was an error during the import.
	if ( is_wp_error( $attachments_data ) ) {
		wp_send_json_error(
			[
				'error_message' => $attachments_data->get_error_message(),
			]
		);
	}

	// Deliberately not deleting the generation here: the unselected previews are still on
	// screen, and removing them would break their download button and any second
	// "Add selected images" click. The hourly sweep clears it.

	// Set $_POST data to mimic the structure expected by existing ajax insert images function.
	$_POST['images'] = wp_json_encode( (object) $attachments_data );

	// Call the existing function.
	envira_gallery_ajax_insert_images();
	die;
}

/**
 * Import already-stored image files into the media library.
 *
 * The AI service returns base64 payloads which are written under uploads before preview, so
 * importing is a local file copy. Nothing is fetched over the network on this path.
 *
 * @since 1.18.0
 *
 * @param  array $image_paths Absolute paths of the files to import.
 * @param  int   $post_id     The post ID where images will be attached.
 * @return array|WP_Error Attachment data for each image, or WP_Error on failure.
 */
function envira_ai_insert_generated_images( $image_paths, $post_id ) {
	$attachments_data = [];
	$created_ids      = [];

	// Importing is all-or-nothing. Returning mid-loop would otherwise leave the attachments
	// already created orphaned in the media library, referenced by no gallery.
	$rollback = static function () use ( &$created_ids ) {
		foreach ( $created_ids as $created_id ) {
			wp_delete_attachment( $created_id, true );
		}
	};

	foreach ( $image_paths as $image_path ) {
		if ( ! is_file( $image_path ) ) {
			$rollback();

			return new WP_Error( 'envira_ai_import_missing_file', __( 'These generated images are no longer available. Please create them again.', 'envira-gallery' ) );
		}

		// media_handle_sideload() consumes the file it is handed, so give it a copy and leave
		// the preview in place until the whole generation is cleaned up. The prefix keeps the
		// media library from filling with attachments titled "0", "1", "2".
		$file_name = 'envira-ai-image-' . basename( $image_path );
		$tmp_file  = wp_tempnam( $file_name );

		if ( ! $tmp_file ) {
			$rollback();

			return new WP_Error( 'envira_ai_import_tmp_failed', __( 'Failed to create a temporary file for the image.', 'envira-gallery' ) );
		}

		if ( ! copy( $image_path, $tmp_file ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_copy -- copying between two paths we own.
			wp_delete_file( $tmp_file );
			$rollback();

			return new WP_Error( 'envira_ai_import_copy_failed', __( 'Failed to save the image locally.', 'envira-gallery' ) );
		}

		$attachment_id = media_handle_sideload(
			[
				'name'     => $file_name,
				'tmp_name' => $tmp_file,
			],
			$post_id
		);

		// media_handle_sideload() deletes the temp file on success; clean up on failure.
		if ( is_wp_error( $attachment_id ) ) {
			wp_delete_file( $tmp_file );
			$rollback();

			return $attachment_id;
		}

		$created_ids[]      = $attachment_id;
		$attachments_data[] = envira_ai_build_attachment_data( $attachment_id, $post_id );
	}

	return $attachments_data;
}

/**
 * Build the attachment payload the metabox expects for a newly added attachment.
 *
 * @since 1.18.0
 *
 * @param  int $attachment_id Attachment ID.
 * @param  int $post_id       The post the attachment was uploaded to.
 * @return array
 */
function envira_ai_build_attachment_data( $attachment_id, $post_id ) {
	// Get the file path of the attachment.
	$file = get_attached_file( $attachment_id );

	// Reuse the metadata media_handle_sideload() already stored. Regenerating it here would
	// run every registered image size a second time per image and re-fire the
	// wp_generate_attachment_metadata filters (see #5095).
	$attachment_metadata = wp_get_attachment_metadata( $attachment_id );

	if ( ! is_array( $attachment_metadata ) ) {
		$attachment_metadata = wp_generate_attachment_metadata( $attachment_id, $file );
		wp_update_attachment_metadata( $attachment_id, $attachment_metadata );
	}

	// Get attachment post data (title, description, caption, etc.).
	$attachment_post = get_post( $attachment_id );

	// Get the image alt text.
	$alt_text = get_post_meta( $attachment_id, '_wp_attachment_image_alt', true );

	// Get the image MIME type and other details.
	$mime_type           = get_post_mime_type( $attachment_id );
	$original_image_url  = wp_get_attachment_url( $attachment_id );
	$original_image_name = basename( get_attached_file( $attachment_id ) );

	// Get the upload URL.
	$upload_url = wp_get_attachment_url( $attachment_id );

	// Get the file size in bytes and human-readable format.
	$filesize                = filesize( get_attached_file( $attachment_id ) );
	$filesize_human_readable = size_format( $filesize, 2 );

	// Get the date the file was uploaded.
	$date_uploaded = get_the_date( 'Y-m-d\TH:i:s.000\Z', $attachment_id );
	$modified_date = get_the_modified_date( 'Y-m-d\TH:i:s.000\Z', $attachment_id );

	// Get the author information.
	$author_id   = $attachment_post->post_author;
	$author_name = get_the_author_meta( 'display_name', $author_id );
	$author_link = get_edit_profile_url( $author_id );

	// Generate the nonces for media actions.
	$nonces = [
		'delete' => wp_create_nonce( "delete-attachment_{$attachment_id}" ),
		'edit'   => wp_create_nonce( "edit-attachment_{$attachment_id}" ),
		'update' => wp_create_nonce( "update-attachment_{$attachment_id}" ),
	];

	// Generate the sizes and orientation.
	$sizes       = isset( $attachment_metadata['sizes'] ) ? $attachment_metadata['sizes'] : [];
	$orientation = ( isset( $attachment_metadata['height'] ) && $attachment_metadata['height'] > $attachment_metadata['width'] ) ? 'portrait' : 'landscape';

	// Prepare attachment data arary to return.
	return [
		'id'                    => $attachment_id,
		'title'                 => $attachment_post->post_title,
		'filename'              => basename( $file ),
		'url'                   => $upload_url,
		'link'                  => $upload_url,
		'alt'                   => $alt_text,
		'author'                => $author_id,
		'description'           => $attachment_post->post_content,
		'caption'               => $attachment_post->post_excerpt,
		'name'                  => $attachment_post->post_title,
		'status'                => $attachment_post->post_status,
		'uploadedTo'            => $post_id,
		'date'                  => $date_uploaded,
		'modified'              => $modified_date,
		'menuOrder'             => 0,
		'mime'                  => $mime_type,
		'type'                  => 'image',
		'subtype'               => strtolower( pathinfo( $upload_url, PATHINFO_EXTENSION ) ),
		'icon'                  => wp_mime_type_icon( $attachment_id ),
		'dateFormatted'         => get_the_date( 'F j, Y', $attachment_id ),
		'nonces'                => $nonces,
		'editLink'              => get_edit_post_link( $attachment_id ),
		'meta'                  => false,
		'authorName'            => $author_name,
		'authorLink'            => $author_link,
		'filesizeInBytes'       => $filesize,
		'filesizeHumanReadable' => $filesize_human_readable,
		'context'               => '',
		'originalImageURL'      => $original_image_url,
		'originalImageName'     => $original_image_name,
		'height'                => isset( $attachment_metadata['height'] ) ? $attachment_metadata['height'] : '',
		'width'                 => isset( $attachment_metadata['width'] ) ? $attachment_metadata['width'] : '',
		'orientation'           => $orientation,
		'sizes'                 => $sizes,
		'compat'                => [
			'item' => '',
			'meta' => '',
		],
	];
}

/**
 * Register REST API route for download image.
 *
 * @since 1.9.18
 */
add_action(
	'rest_api_init',
	function () {
		register_rest_route(
			'envira-ai/v1',
			'/download-image',
			[
				'methods'             => 'POST',
				'callback'            => 'envira_gallery_ai_download_image',
				'permission_callback' => 'envira_gallery_ai_verify_permission',
			]
		);
	}
);

/**
 * Determine whether a single IP address is blocked (private, reserved,
 * loopback, or link-local).
 *
 * Filter_var() with FILTER_FLAG_NO_PRIV_RANGE|FILTER_FLAG_NO_RES_RANGE does
 * not unwrap IPv4-mapped (::ffff:a.b.c.d) or IPv4-compatible (::a.b.c.d)
 * IPv6 literals before applying the range check, so those forms of e.g.
 * ::ffff:127.0.0.1 or ::ffff:169.254.169.254 pass the native check even
 * though they resolve to a blocked IPv4 address. Unwrap and re-check the
 * embedded IPv4 explicitly.
 *
 * @since 1.9.19
 *
 * @param string $ip IP address to check.
 * @return bool True if blocked.
 */
function envira_ai_is_ip_blocked( $ip ) {
	if ( ! filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE ) ) {
		return true;
	}

	if ( filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6 ) ) {
		$packed = inet_pton( $ip );
		if ( false !== $packed && 16 === strlen( $packed ) ) {
			$prefix = substr( $packed, 0, 12 );
			// IPv4-mapped (::ffff:a.b.c.d) or IPv4-compatible (::a.b.c.d) prefixes.
			if ( str_repeat( "\x00", 10 ) . "\xff\xff" === $prefix || str_repeat( "\x00", 12 ) === $prefix ) {
				$embedded_ipv4 = inet_ntop( substr( $packed, 12, 4 ) );
				if ( false === $embedded_ipv4 || ! filter_var( $embedded_ipv4, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE ) ) {
					return true;
				}
			}
		}
	}

	return false;
}

/**
 * Determine whether a URL is safe to fetch server-side, and if so, which
 * validated IP it must be fetched from.
 *
 * Restricts to HTTPS, resolves the host via DNS at validation time, and
 * checks every resolved IP against private/reserved/loopback/link-local
 * ranges. The link-local block (169.254.0.0/16) also covers cloud
 * metadata endpoints on AWS, GCP, and Azure, which all serve IMDS on
 * 169.254.169.254.
 *
 * @since 1.9.19
 *
 * @param string $url URL to validate.
 * @return string|false The first validated IP to connect to, or false if unsafe.
 */
function envira_ai_get_safe_connect_ip( $url, $trusted_origins = [] ) {
	$parts = wp_parse_url( $url );

	// A trusted origin is an exact scheme://host[:port] the caller vouches for — in
	// practice the site's own origin, so a poster stored in this site's media library
	// can be fetched on an install whose hostname resolves to a private IP (Docker,
	// LAN, NAT'd staging, split-horizon DNS). It relaxes exactly two things for that
	// one origin: the https-only rule, and the private/reserved IP rejection. Every
	// other origin — including every redirect hop that leaves the trusted one — is
	// still held to the full check, which is what keeps a same-host open redirect from
	// reaching 169.254.169.254 and stops a different port on the same host from being
	// probed at all.
	$is_trusted_origin = in_array( envira_ai_url_origin( $url ), envira_ai_normalize_origins( $trusted_origins ), true );

	$scheme = ! empty( $parts['scheme'] ) ? strtolower( $parts['scheme'] ) : '';

	if ( $is_trusted_origin ) {
		if ( ! in_array( $scheme, [ 'http', 'https' ], true ) ) {
			return false;
		}
	} elseif ( 'https' !== $scheme ) {
		return false;
	}

	if ( empty( $parts['host'] ) ) {
		return false;
	}

	// wp_parse_url() keeps the brackets on IPv6 literals ("https://[::1]/" gives a
	// host of "[::1]"), and FILTER_VALIDATE_IP rejects the bracketed form. Without
	// stripping them, an IPv6-literal URL falls through to the DNS branch below and
	// dns_get_record() is handed something that is not a hostname, which emits a
	// PHP warning. Blocking still happened — the lookup failed, so no IP resolved —
	// but by accident rather than by the IP check this function exists to perform.
	$host = trim( $parts['host'], '[]' );

	if ( filter_var( $host, FILTER_VALIDATE_IP ) ) {
		$ips = [ $host ];
	} else {
		$ipv4_records = gethostbynamel( $host );
		$ipv6_records = dns_get_record( $host, DNS_AAAA );
		$ips          = array_merge(
			false !== $ipv4_records ? $ipv4_records : [],
			is_array( $ipv6_records ) ? wp_list_pluck( $ipv6_records, 'ipv6' ) : []
		);
	}

	if ( empty( $ips ) ) {
		// Host did not resolve to any address.
		return false;
	}

	if ( ! $is_trusted_origin ) {
		foreach ( $ips as $ip ) {
			if ( envira_ai_is_ip_blocked( $ip ) ) {
				return false;
			}
		}
	}

	return $ips[0];
}

/**
 * Normalize a URL to its origin: scheme://host[:port], lowercased, with the port
 * omitted when it is the default for the scheme.
 *
 * Comparing origins rather than bare hostnames is what makes a "this is my own site"
 * exemption safe: a bare-host match would also accept a different port on that host
 * (http://example.com:6379/, reaching a service bound on the same machine) and any
 * path on it.
 *
 * @since 1.16.2
 *
 * @param string $url URL to reduce.
 * @return string Origin, or '' when the URL has no usable scheme/host.
 */
function envira_ai_url_origin( $url ) {
	$parts = wp_parse_url( (string) $url );

	if ( empty( $parts['scheme'] ) || empty( $parts['host'] ) ) {
		return '';
	}

	$scheme = strtolower( $parts['scheme'] );
	$host   = strtolower( $parts['host'] );
	$origin = $scheme . '://' . $host;

	if ( ! empty( $parts['port'] ) ) {
		$port    = (int) $parts['port'];
		$default = ( 'https' === $scheme ) ? 443 : 80;
		$origin .= ( $port === $default ) ? '' : ':' . $port;
	}

	return $origin;
}

/**
 * Reduce a list of URLs or origins to normalized, de-duplicated origins.
 *
 * @since 1.16.2
 *
 * @param array $origins URLs or origins.
 * @return array Normalized origins.
 */
function envira_ai_normalize_origins( $origins ) {
	$normalized = [];

	foreach ( (array) $origins as $origin ) {
		$origin = envira_ai_url_origin( $origin );

		if ( '' !== $origin ) {
			$normalized[] = $origin;
		}
	}

	return array_values( array_unique( $normalized ) );
}

/**
 * Fetch a URL manually following redirects, re-validating the target of
 * every redirect hop instead of trusting a single upfront check.
 *
 * To close the gap between "the hostname we validated" and "the hostname
 * the HTTP transport actually connects to" (a DNS-rebinding attacker could
 * answer the validation lookup and the connection lookup differently),
 * this pins the outbound cURL connection to the exact IP that was
 * validated via CURLOPT_RESOLVE, while keeping the original hostname for
 * the TLS handshake/SNI/certificate check and the Host header.
 *
 * @since 1.9.19
 *
 * @param string $url           URL to fetch.
 * @param int    $max_redirects Maximum number of redirects to follow.
 * @return array|WP_Error wp_remote_get()-style response array, or WP_Error.
 */
function envira_ai_safe_fetch( $url, $max_redirects = 3, $trusted_origins = [] ) {
	// Still in use by src/Utils/Import.php, which fails closed without it, and by the legacy
	// image_url path of the download route below.
	$trusted_origins = envira_ai_normalize_origins( $trusted_origins );

	for ( $i = 0; $i <= $max_redirects; $i++ ) {
		// Re-checked on every hop with the same trusted list, so leaving a trusted
		// origin — including a redirect to another port on the same host — drops back to
		// the full https-plus-public-IP rule.
		$connect_ip = envira_ai_get_safe_connect_ip( $url, $trusted_origins );
		if ( false === $connect_ip ) {
			return new WP_Error( 'envira_ai_unsafe_url', __( 'URL failed security validation.', 'envira-gallery' ) );
		}

		$parts = wp_parse_url( $url );
		$host  = $parts['host'];
		// Derive the port from the scheme instead of assuming 443. CURLOPT_RESOLVE only
		// applies to the exact host:port being connected to, so a hard-coded 443 left an
		// http:// fetch unpinned — cURL ignored the entry and re-resolved at connect
		// time, which is the DNS-rebinding window the pin exists to close. https URLs
		// were unaffected, and only a trusted origin may be http at all, but the pin has
		// to hold for those too.
		$scheme   = ! empty( $parts['scheme'] ) ? strtolower( $parts['scheme'] ) : 'https';
		$port     = isset( $parts['port'] ) ? (int) $parts['port'] : ( 'http' === $scheme ? 80 : 443 );
		$pin_curl = function ( $handle ) use ( $host, $port, $connect_ip ) {
			if ( function_exists( 'curl_setopt' ) && defined( 'CURLOPT_RESOLVE' ) ) {
				curl_setopt( $handle, CURLOPT_RESOLVE, [ "{$host}:{$port}:{$connect_ip}" ] ); // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_setopt -- wp_remote_get() has no way to pin the connection IP; CURLOPT_RESOLVE is required to close the DNS-rebinding TOCTOU.
			}
		};

		add_action( 'http_api_curl', $pin_curl );
		$response = wp_remote_get(
			$url,
			[
				'redirection' => 0,
				'timeout'     => 15,
			]
		);
		remove_action( 'http_api_curl', $pin_curl );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = wp_remote_retrieve_response_code( $response );

		if ( in_array( $code, [ 301, 302, 303, 307, 308 ], true ) ) {
			$location = wp_remote_retrieve_header( $response, 'location' );
			if ( empty( $location ) ) {
				return new WP_Error( 'envira_ai_bad_redirect', __( 'Redirect response with no location header.', 'envira-gallery' ) );
			}

			// Resolve relative redirects against the current URL, then re-validate on the next loop iteration.
			$url = (string) WP_Http::make_absolute_url( $location, $url );
			continue;
		}

		return $response;
	}

	return new WP_Error( 'envira_ai_too_many_redirects', __( 'Too many redirects while fetching the image.', 'envira-gallery' ) );
}

/**
 * Callback method to download a generated image via REST API.
 *
 * @access public
 * @param  WP_REST_Request $request The REST API request object.
 * @return WP_REST_Response|WP_Error
 */
function envira_gallery_ai_download_image( $request ) {

	// Preferred path: generated images are stored on this site, so the request names one by
	// generation and index and nothing is fetched over the network. See #5679.
	$generation_id = sanitize_text_field( (string) $request->get_param( 'generation_id' ) );
	$index         = $request->get_param( 'index' );

	if ( '' !== $generation_id && null !== $index ) {
		$path = envira_ai_generation_file( $generation_id, absint( $index ) );

		if ( ! $path ) {
			return new WP_REST_Response( [ 'image_fetch_failed' => __( 'This generated image is no longer available. Please create it again.', 'envira-gallery' ) ], 404 );
		}

		$image_data = file_get_contents( $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- reading a file we wrote inside our own uploads subfolder.

		if ( empty( $image_data ) ) {
			return new WP_REST_Response( [ 'image_fetch_failed' => __( 'Failed to fetch image.', 'envira-gallery' ) ], 500 );
		}

		return new WP_REST_Response(
			[
				'success' => true,
				'image'   => base64_encode( $image_data ), // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- transporting image bytes to the browser.
				'mime'    => wp_check_filetype( $path )['type'],
			],
			200
		);
	}

	// Legacy path. Nothing in this plugin sends image_url any more — the UI posts
	// generation_id/index — so this branch has no caller here. It is retained only because
	// dev/tests/envira/envira-gallery/Test_Ai_Image_Download.php drives the route by URL to
	// assert the SSRF controls below, and those tests live in another repository. Every hop
	// is still validated exactly as before. Removing it, and updating those tests, is the
	// right end state: see #5679.
	$image_url = $request->get_param( 'image_url' );

	if ( ! $image_url ) {
		return new WP_REST_Response( [ 'no_image_specified' => __( 'No image was specified.', 'envira-gallery' ) ], 400 );
	}

	// Sanitize the image URL.
	$image_url = esc_url_raw( wp_unslash( $image_url ) );

	// Fetch the image data, validating the URL (and every redirect hop) against SSRF.
	$response = envira_ai_safe_fetch( $image_url );
	if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
		// Log the specific reason server-side for abuse monitoring, but return a generic
		// message to the client so an attacker can't use the response to distinguish an SSRF
		// rejection from a genuine network failure.
		if ( is_wp_error( $response ) ) {
			error_log( sprintf( 'Envira AI image download blocked for user #%d: [%s] %s (requested URL: %s)', get_current_user_id(), envira_ai_sanitize_for_log( $response->get_error_code() ), envira_ai_sanitize_for_log( $response->get_error_message() ), envira_ai_sanitize_for_log( $image_url ) ) ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- deliberate security audit trail.
		}
		return new WP_REST_Response( [ 'image_fetch_failed' => __( 'Failed to fetch image.', 'envira-gallery' ) ], 500 );
	}
	$image_data = wp_remote_retrieve_body( $response );
	if ( empty( $image_data ) ) {
		return new WP_REST_Response( [ 'image_fetch_failed' => __( 'Failed to fetch image.', 'envira-gallery' ) ], 500 );
	}

	// Return the image data as a base64 string in a success response.
	return new WP_REST_Response(
		[
			'success' => true,
			'image'   => base64_encode( $image_data ), // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- transporting image bytes to the browser.
		],
		200
	);
}
