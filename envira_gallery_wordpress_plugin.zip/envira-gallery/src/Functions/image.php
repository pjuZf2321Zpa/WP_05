<?php
/**
 * Envira Image Functions.
 *
 * @since 1.7.0
 *
 * @package Envira_Gallery
 * @author  Envira Gallery Team <support@enviragallery.com>
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {

	exit;

}

/**
 * Is this an image function.
 *
 * @access public
 * @param mixed $url // a given url.
 * @return boolean
 */
function envira_is_image( $url ) {

	$parse     = wp_parse_url( $url );
	$filetypes = envira_get_supported_filetypes();

	// bail if its not an array.
	if ( ! is_array( $parse ) ) {

		return false;

	}

	if ( ! isset( $parse['path'] ) ) {
		return false;
	}

	$extension = pathinfo( $parse['path'], PATHINFO_EXTENSION );

	$img_extensions = explode( ',', $filetypes[0]['extensions'] );

	if ( in_array( strtolower( $extension ), $img_extensions, true ) ) {

		return true;

	}

	return false;
}

/**
 * Get_image_sizes function.
 *
 * @access public
 * @param boolean $core_only Only bother with WordPress sizes.
 * @return array
 */
function envira_get_image_sizes( $core_only = false ) {

	if ( ! $core_only ) {
		$sizes = [
			[
				'value' => 'default',
				'name'  => __( 'Default', 'envira-gallery' ),
			],
		];
	}

	global $_wp_additional_image_sizes;
	$wp_sizes = get_intermediate_image_sizes();
	foreach ( $wp_sizes as $size ) {
		if ( isset( $_wp_additional_image_sizes[ $size ] ) ) {
			$width  = absint( $_wp_additional_image_sizes[ $size ]['width'] );
			$height = absint( $_wp_additional_image_sizes[ $size ]['height'] );
		} else {
			$width  = absint( get_option( $size . '_size_w' ) );
			$height = absint( get_option( $size . '_size_h' ) );
		}

		if ( ! $width && ! $height ) {
			$sizes[] = [
				'value' => $size,
				'name'  => ucwords( str_replace( [ '-', '_' ], ' ', $size ) ),
			];
		} else {
			$sizes[] = [
				'value'  => $size,
				'name'   => ucwords( str_replace( [ '-', '_' ], ' ', $size ) ) . ' (' . $width . ' &#215; ' . $height . ')',
				'width'  => $width,
				'height' => $height,
			];
		}
	}
	// Add Option for full image.
	$sizes[] = [
		'value' => 'full',
		'name'  => __( 'Original Image', 'envira-gallery' ),
	];

	return apply_filters( 'envira_gallery_image_sizes', $sizes );
}

/**
 * Get shortcode image sizes
 *
 * @access public
 * @return array
 */
function envira_get_shortcode_image_sizes() {
	global $_wp_additional_image_sizes;
	$sizes = [];

	foreach ( get_intermediate_image_sizes() as $_size ) {
		if ( in_array( $_size, [ 'thumbnail', 'medium', 'medium_large', 'large' ], true ) ) {
			if ( (bool) get_option( "{$_size}_crop" ) === true ) {
				continue;
			}
			$sizes[ $_size ]['name']   = $_size;
			$sizes[ $_size ]['width']  = get_option( "{$_size}_size_w" );
			$sizes[ $_size ]['height'] = get_option( "{$_size}_size_h" );
			$sizes[ $_size ]['crop']   = (bool) get_option( "{$_size}_crop" );
		} elseif ( isset( $_wp_additional_image_sizes[ $_size ] ) ) {
			if ( true === $_wp_additional_image_sizes[ $_size ]['crop'] ) {
				continue;
			}
			$sizes[ $_size ] = [
				'name'   => $_size,
				'width'  => $_wp_additional_image_sizes[ $_size ]['width'],
				'height' => $_wp_additional_image_sizes[ $_size ]['height'],
				'crop'   => $_wp_additional_image_sizes[ $_size ]['crop'],
			];
		}
	}

	return $sizes;
}

/**
 * Read width/height off a WordPress-style "-{width}x{height}" filename suffix.
 *
 * Both core (registered sizes) and envira_get_image_info() itself suffix a
 * resized filename this way (crops add "_c" or an alignment slug, e.g.
 * "photo-640x480_c.jpg"). When present, it's the ground truth for what was
 * actually served — cheaper and more reliable than trusting cached attachment
 * metadata for a size that may never have been generated (e.g. a failed crop
 * that fell back to the full-size original, which carries no suffix at all).
 *
 * @since 1.16.1
 *
 * @param string     $src             Image URL or file path.
 * @param array|null $attachment_meta The attachment's _wp_attachment_metadata, used to
 *                                    tell a derivative from an original so an original
 *                                    whose own name ends "-WxH" is not misread.
 * @return array{0:int,1:int}|null [ width, height ], or null if there is no usable suffix.
 */
function envira_get_dimensions_from_filename( $src, $attachment_meta = null ) {

	if ( empty( $src ) || ! is_string( $src ) || ! preg_match( '/-(\d+)x(\d+)(?:_[a-zA-Z0-9]+)?\.[a-zA-Z0-9]+$/', basename( $src ), $matches ) ) {
		return null;
	}

	// A "-WxH" in the name only describes the file when the file is a derivative.
	// An ORIGINAL upload can carry the same shape - "hero-1600x900.jpg" that is
	// really 800x450 - and trusting it there publishes the filename's numbers over
	// correct cached metadata. Compare against the attachment's own stored filenames:
	// if this IS one of them, the suffix is part of the user's name, not a size.
	//
	// Both names have to be checked. 'file' is whatever WordPress stores, which for
	// an attachment above big_image_size_threshold (WP 5.3+) is the "-scaled"
	// derivative, while 'original_image' holds the untouched upload - and
	// envira_get_image_src() deliberately returns that pre-scale original for
	// full/random sizes. Comparing 'file' alone therefore never matched on a scaled
	// attachment, so a misleadingly named 4000x2250 upload still published 1600x900.
	//
	// Only discard the suffix when cached dimensions can actually answer instead.
	// Returning null with nothing to fall back on pushes the caller into the
	// per-image getimagesize() block that #5544 exists to avoid - so an attachment
	// with a "-WxH" name and no cached dimensions keeps using its suffix.
	if ( is_array( $attachment_meta ) && isset( $attachment_meta['width'], $attachment_meta['height'] ) ) {

		foreach ( [ 'file', 'original_image' ] as $meta_key ) {

			if ( ! empty( $attachment_meta[ $meta_key ] ) && is_string( $attachment_meta[ $meta_key ] )
				&& basename( $src ) === basename( $attachment_meta[ $meta_key ] ) ) {
				return null;
			}
		}
	}

	return [ (int) $matches[1], (int) $matches[2] ];
}

/**
 * Resolve the real pixel dimensions of an image URL.
 *
 * Measures the file instead of trusting the "-WxH" suffix in its name, which
 * records the size that was requested rather than the size written. Memoized.
 *
 * @since 1.17.1
 *
 * @param string $url  Image URL.
 * @param array  $data Gallery data, passed through for path resolution.
 * @return array{0:int,1:int}|null [ width, height ], or null when they cannot be determined.
 */
function envira_get_image_url_dimensions( $url, $data = [] ) {

	static $cache = [];

	if ( empty( $url ) || ! is_string( $url ) ) {
		return null;
	}

	if ( ! array_key_exists( $url, $cache ) ) {
		$info = envira_get_image_info( [ $url, 1, 0, false, 'c', 100, false, $data ] );

		$cache[ $url ] = ( ! is_wp_error( $info ) && ! empty( $info['orig_width'] ) && ! empty( $info['orig_height'] ) )
			? [ (int) $info['orig_width'], (int) $info['orig_height'] ]
			: null;
	}

	return $cache[ $url ];
}

/**
 * Decide whether one image URL is a valid 2x candidate for another.
 *
 * Too small and the browser halves the image's intrinsic size for no extra
 * detail; a different shape gets squashed into the 1x file's box.
 *
 * @since 1.17.1
 *
 * @param string $retina_url The candidate 2x URL.
 * @param string $base_url   The 1x URL it would accompany.
 * @param array  $data       Gallery data, passed through for path resolution.
 * @return bool
 */
function envira_is_valid_retina_candidate( $retina_url, $base_url, $data = [] ) {

	if ( empty( $retina_url ) || empty( $base_url ) || $retina_url === $base_url ) {
		return false;
	}

	$retina_size = envira_get_image_url_dimensions( $retina_url, $data );
	$base_size   = envira_get_image_url_dimensions( $base_url, $data );

	if ( ! $retina_size || ! $base_size ) {
		return false;
	}

	if ( $retina_size[0] < ( $base_size[0] * 2 ) ) {
		return false;
	}

	$base_ratio   = $base_size[0] / $base_size[1];
	$retina_ratio = $retina_size[0] / $retina_size[1];

	// Allow a couple of percent, since a crop rounds to whole pixels.
	return abs( $base_ratio - $retina_ratio ) <= ( $base_ratio * 0.02 );
}

/**
 * Helper method to return common information about an image.
 *
 * @since 1.7.0
 *
 * LiteEquiv:(new Common())->get_image_info()
 *
 * @param array $args List of resizing args to expand for gathering info.
 * @return array|WP_Error Return WP_Error on error, array of data on success.
 */
function envira_get_image_info( $args ) {

	// Unpack arguments.
	list( $url, $width, $height, $crop, $align, $quality, $retina, $data ) = $args;

	// Return an error if no URL is present.
	if ( empty( $url ) ) {
		return new WP_Error( 'envira-gallery-error-no-url', __( 'No image URL specified for cropping.', 'envira-gallery' ) );
	}

	// Get the image file path.
	$urlinfo       = wp_parse_url( $url );
	$wp_upload_dir = wp_upload_dir();

	if ( empty( $urlinfo['path'] ) ) {
		return new WP_Error( 'envira-gallery-error-no-url', __( 'No image URL path for cropping.', 'envira-gallery' ) );
	}

	// Interpret the file path of the image. $folder_base is set only for dynamic
	// "folder_" galleries, where it is the sanitized (traversal-free) source
	// folder path (see the containment check below, which trusts this folder
	// specifically once it can no longer be steered via "../" segments).
	$folder_base = null;

	if ( preg_match( '/\/[0-9]{4}\/[0-9]{2}\/.+$/', $urlinfo['path'], $matches ) ) {

		$file_path = $wp_upload_dir['basedir'] . $matches[0];
	} elseif ( ! empty( $data['dynamic_id'] ) && ! empty( $data['id'] ) && is_string( $data['id'] ) && 0 === strpos( $data['id'], 'folder_' ) ) {
		// $data['id'] is not guaranteed to be admin-only: it can be reached via an
		// unsanitized shortcode attribute (e.g. envira-dynamic's `custom_id`), so a
		// "../" segment here must not be allowed to steer $folder_base anywhere the
		// containment check below would then trust. Drop any '.', '..', or empty
		// path segment before it can participate in that trust.
		$folder_name_segments = array_filter(
			explode( '/', str_replace( '\\', '/', str_replace( 'folder_', '', $data['id'] ) ) ),
			static function ( $segment ) {
				return '' !== $segment && '.' !== $segment && '..' !== $segment;
			}
		);
		$folder_name          = $folder_name_segments ? trailingslashit( implode( '/', $folder_name_segments ) ) : '';
		$folder_base          = trailingslashit( dirname( $wp_upload_dir['basedir'] ) ) . $folder_name;
		$file_path            = $folder_base . basename( $urlinfo['path'] );
	} else {
		// Images are not always in the /YYYY/MM/ month folders matched above: imported
		// sets, custom upload paths and pre-existing folders all keep their own
		// sub-directory under uploads. Map the URL back onto the uploads basedir with
		// those sub-directories intact, and only fall back to the historical
		// basename-in-basedir guess when that file isn't there — galleries that
		// resolved before keep resolving exactly as before, while an image in a
		// sub-folder stops failing with 'No file could be found for the image URL
		// specified.' (which left the lightbox/strip thumbnail with no source at all).
		// Segments are filtered like the folder_ branch above so a '../' in the URL
		// can't steer the path; the containment check below is still the authority.
		$uploads_url_path = wp_parse_url( $wp_upload_dir['baseurl'], PHP_URL_PATH );
		$relative_path    = '';

		// Only map a URL onto the local uploads tree when it actually belongs to this
		// site (or to whatever host serves uploads, e.g. a CDN rewrite). The month-folder
		// branch above matches on path alone for backwards compatibility with sites that
		// changed domain without rewriting stored URLs; this branch must not widen that,
		// or a third-party URL that merely mirrors a local sub-path would be answered
		// with a crop of the local file under the remote host.
		$allowed_hosts = array_filter(
			[
				wp_parse_url( home_url(), PHP_URL_HOST ),
				wp_parse_url( site_url(), PHP_URL_HOST ),
				wp_parse_url( $wp_upload_dir['baseurl'], PHP_URL_HOST ),
			]
		);
		$url_host      = ! empty( $urlinfo['host'] ) ? $urlinfo['host'] : '';
		$host_is_local = '' === $url_host || in_array( $url_host, $allowed_hosts, true );

		if ( $host_is_local && ! empty( $uploads_url_path ) && 0 === strpos( $urlinfo['path'], trailingslashit( $uploads_url_path ) ) ) {
			$relative_segments = array_filter(
				explode( '/', substr( $urlinfo['path'], strlen( trailingslashit( $uploads_url_path ) ) ) ),
				static function ( $segment ) {
					return '' !== $segment && '.' !== $segment && '..' !== $segment;
				}
			);
			$relative_path     = implode( '/', $relative_segments );
		}

		$uploads_basedir = trailingslashit( $wp_upload_dir['basedir'] );
		$subdir_path     = $relative_path ? $uploads_basedir . $relative_path : '';

		// Don't stat a stream-wrapped basedir (s3://, iu://, …) — the remote check
		// further down rejects those anyway, and file_exists() on an unhealthy remote
		// blocks the request. Prefer the sub-directory path unstatted in that case.
		$basedir_is_remote = (bool) preg_match( '#^[a-z][a-z0-9+.\-]*://#i', $uploads_basedir );

		if ( $subdir_path && ( $basedir_is_remote || file_exists( $subdir_path ) ) ) {
			$file_path = $subdir_path;
		} else {
			$file_path = $uploads_basedir . basename( $urlinfo['path'] );
		}
	}

	// Never run file_exists()/getimagesize() against a stream-wrapped path (s3://, iu://,
	// etc.) — a slow or unhealthy remote would block the request until max_execution_time
	// is hit, silently killing block-editor publish. Computed before the "//" collapse
	// below, since collapsing "scheme://" into "scheme:/" would hide the stream wrapper.
	$is_remote = (bool) preg_match( '#^[a-z][a-z0-9+.\-]*://#i', $file_path );

	if ( $is_remote ) {
		return new WP_Error( 'envira-gallery-error-remote-file', __( 'Cannot crop an image stored on a remote/stream-wrapped filesystem.', 'envira-gallery' ) );
	}

	$file_path = preg_replace( '/(\/\/)/', '/', $file_path );

	// Contain path resolution to the uploads directory (or, for dynamic "folder_"
	// galleries, the sanitized source folder itself) so a crafted gallery src or
	// gallery identifier (e.g. containing "../" segments) can't be used to
	// stat/read arbitrary files. All candidate bases are resolved through realpath():
	// comparing
	// against an unresolved dirname() string fails whenever uploads itself is a
	// symlink (mounted volume, NFS, multi-server layouts), since $real_path below
	// is fully resolved but the plain string never follows that symlink.
	//
	// wp_normalize_path() after realpath() matters on Windows: realpath() there
	// returns backslash-separated paths, while trailingslashit() below always
	// appends a forward slash for the prefix comparison — without normalizing,
	// the strpos() check never matches and every image on a Windows-hosted site
	// fails containment, not just the folder_ case this fix targets.
	$real_path         = realpath( $file_path );
	$real_path         = $real_path ? wp_normalize_path( $real_path ) : false;
	$real_uploads_base = realpath( $wp_upload_dir['basedir'] );
	$real_uploads_base = $real_uploads_base ? wp_normalize_path( $real_uploads_base ) : false;
	$real_content_base = realpath( dirname( $wp_upload_dir['basedir'] ) );
	$real_content_base = $real_content_base ? wp_normalize_path( $real_content_base ) : false;

	// A dynamic "folder_" gallery may legitimately point at a directory that is
	// symlinked into wp-content from elsewhere (a mounted NAS or network share), and
	// realpath() resolves such a base to a path outside the content tree — so the two
	// bases above would reject every image in it. That folder is therefore accepted as
	// its own base, but only when the symlink itself lives inside the content tree:
	// $folder_base is checked BEFORE realpath() follows it. Without that anchor the
	// clause validated itself — $real_path is trivially prefixed by its own resolved
	// base — so whoever supplied $data['id'] chose the destination, and since that
	// value reaches here through an unsanitized shortcode attribute (envira-dynamic's
	// `custom_id`) rather than an admin-only setting, naming any symlink under
	// wp-content was enough to make envira_resize_image() write the generated crop
	// wherever it pointed. Traversal was already blocked upstream; this restores the
	// ceiling that check never provided.
	$real_folder_base = null;
	if ( $folder_base ) {
		$unresolved_folder_base = wp_normalize_path( $folder_base );

		/**
		 * Filters the directories a dynamic gallery's source folder may live under.
		 *
		 * The symlink (or real directory) named by a "folder_" gallery id must sit
		 * inside one of these before it is trusted as an image base. Add a path here
		 * to serve images from a location outside wp-content deliberately, rather
		 * than relying on a shortcode attribute to name one.
		 *
		 * @since 1.16.2
		 *
		 * @param array  $bases        Absolute paths, normalized with forward slashes.
		 * @param string $folder_base  The unresolved folder path under consideration.
		 * @param array  $data         Gallery data.
		 */
		$allowed_folder_roots = (array) apply_filters(
			'envira_allowed_image_bases',
			array_filter( [ $real_uploads_base, $real_content_base ] ),
			$unresolved_folder_base,
			$data
		);

		$folder_base_is_anchored = false;

		foreach ( $allowed_folder_roots as $allowed_root ) {
			$allowed_root = $allowed_root ? wp_normalize_path( (string) $allowed_root ) : '';

			if ( '' !== $allowed_root && 0 === strpos( $unresolved_folder_base, trailingslashit( $allowed_root ) ) ) {
				$folder_base_is_anchored = true;
				break;
			}
		}

		if ( $folder_base_is_anchored ) {
			$real_folder_base = realpath( $folder_base );
			$real_folder_base = $real_folder_base ? wp_normalize_path( $real_folder_base ) : false;
		}
	}

	$contained = $real_path && is_file( $real_path ) && (
		( $real_uploads_base && 0 === strpos( $real_path, trailingslashit( $real_uploads_base ) ) ) ||
		( $real_content_base && 0 === strpos( $real_path, trailingslashit( $real_content_base ) ) ) ||
		( $real_folder_base && 0 === strpos( $real_path, trailingslashit( $real_folder_base ) ) )
	);

	if ( ! $contained ) {
		return new WP_Error( 'envira-gallery-error-no-file', __( 'No file could be found for the image URL specified.', 'envira-gallery' ) );
	}

	$file_path = $real_path;

	// Get original image size.
	$size = getimagesize( $file_path );

	// If no size data obtained, return an error.
	if ( ! is_array( $size ) ) {

		return new WP_Error( 'envira-gallery-error-no-size', __( 'The dimensions of the original image could not be retrieved for cropping.', 'envira-gallery' ) );

	}

	// Set original width and height.
	list( $orig_width, $orig_height, $orig_type ) = $size;

	// Generate width or height if not provided.
	if ( $width && ! $height ) {
		$height = max( 1.0, floor( $orig_height * ( $width / $orig_width ) ) );
	} elseif ( $height && ! $width ) {
		$width = max( 1.0, floor( $orig_width * ( $height / $orig_height ) ) );
	} elseif ( ! $width && ! $height ) {
		return new WP_Error( 'envira-gallery-error-no-size', __( 'The dimensions of the original image could not be retrieved for cropping.', 'envira-gallery' ) );
	}

	// Allow for different retina image sizes.
	$retina = $retina ? 2 : 1;

	// Destination width and height variables.
	$dest_width  = $width * $retina;
	$dest_height = $height * $retina;

	// Some additional info about the image.
	$info = pathinfo( $file_path );
	$dir  = $info['dirname'];
	$ext  = $info['extension'];
	$name = wp_basename( $file_path, ".$ext" );

	// Suffix applied to filename.
	$suffix = "{$dest_width}x{$dest_height}";

	// Set alignment information on the file.
	if ( $crop ) {
		$suffix .= ( $align ) ? "_{$align}" : '_c';
	}

	// Get the destination file name.
	$dest_file_name = "{$dir}/{$name}-{$suffix}.{$ext}";

	// Return the info.
	return [
		'dir'            => $dir,
		'name'           => $name,
		'ext'            => $ext,
		'suffix'         => $suffix,
		'orig_width'     => $orig_width,
		'orig_height'    => $orig_height,
		'orig_type'      => $orig_type,
		'dest_width'     => $dest_width,
		'dest_height'    => $dest_height,
		'file_path'      => $file_path,
		'dest_file_name' => $dest_file_name,
	];
}

/**
 * Find Clostest Size function.
 *
 * @access public
 * @param mixed $data Gallery Data.
 * @return bool|int
 */
function envira_find_clostest_size( $data ) {
	$image_sizes = envira_get_shortcode_image_sizes();
	$dimensions  = envira_get_config( 'dimensions', $data );
	$width       = envira_get_config( 'crop_width', $data );
	$height      = envira_get_config( 'crop_height', $data );
	$match       = false;
	usort( $image_sizes, 'envira_usort_callback' );
	foreach ( $image_sizes as $num ) {
		$num['width']  = (int) $num['width'];
		$num['height'] = (int) $num['height'];
		// skip over sizes that are smaller.
		if ( $num['height'] < $height || $num['width'] < $width ) {
			continue;
		}
		if ( $num['width'] > $width && $num['height'] > $height ) {
			if ( false === $match ) {
				$match = true;
				$size  = $num['name'];
				return $size;
			}
		}
	}
	return false;
}

/**
 * Fall back for Usort Callback
 *
 * @param array $a $data to sort.
 * @param array $b $data to sort.
 * @return int
 */
function envira_usort_callback( $a, $b ) {

	return intval( $a['width'] ) - intval( $b['width'] );
}

/**
 * Helper Method to get image src.
 *
 * @param int     $id Image ID.
 * @param array   $item Item Data.
 * @param array   $data Gallery Data.
 * @param boolean $mobile Is Mobile.
 * @param boolean $retina Is Retina.
 * @param boolean $allow_crop Is Retina.
 * @param string  $image_size_config Is Retina.
 * @return bool|string
 */
function envira_get_image_src( $id, $item, $data, $mobile = false, $retina = false, $allow_crop = true, $image_size_config = 'image_size' ) {

	// Define variable.
	$src = false;

	// Check for mobile and mobile setting.
	$type = $mobile && envira_get_config( 'mobile', $data ) ? 'mobile' : 'crop'; // 'crop' is misleading here - it's the key that stores the thumbnail width + height.

	// If this image is an instagram, we grab the src and don't use the $id.
	// otherwise using the $id refers to a postID in the database and has been known.
	// at times to pull up the wrong thumbnail instead of the instagram one.
	$instagram = false;

	if ( ( ! empty( $item['src'] ) && ( strpos( $item['src'], 'cdninstagram' ) !== false ) ) || ! empty( $item['instagram_high_res'] ) ) {
		// using 'cdninstagram' because it seems all urls contain it - but be watchful in the future.
		$instagram = true;
		$src       = $item['src'];
		$image     = $item['src'];
	}

	$image_size = envira_get_config( $image_size_config, $data );

	if ( ! $src && is_int( $id ) ) : // wp_get_attachment_image_src only accepts $id as integer.
		if ( ( envira_get_config( 'crop', $data ) && 'default' === $image_size ) || 'full' === $image_size ) {
			// use the_post_thumbnail because wp_get_original_image_path returns a path, not a url, which is what we need here.
			$src = apply_filters( 'envira_gallery_retina_image_src', wp_get_original_image_url( $id ), $id, $item, $data, $mobile ); // Similar to wp_get_attachment_url() however some images may have been processed after uploading. In this case this function returns the URL to the originally uploaded image file.
		} elseif ( 'full' !== $image_size && ! $retina ) {
			// Check if this Gallery uses a WordPress defined image size.
			if ( 'default' !== $image_size ) {
				// If image size is envira_gallery_random, get a random image size.
				if ( 'envira_gallery_random' === $image_size ) {
					// Get random image sizes that have been chosen for this Gallery.
					$image_sizes_random = (array) envira_get_config( 'image_sizes_random', $data );
					if ( count( $image_sizes_random ) === 0 ) {
						// The user didn't choose any image sizes - use them all.
						$core_image_sizes           = envira_get_image_sizes( true );
						$core_image_size_random_key = array_rand( $core_image_sizes, 1 );
						$image_size                 = $core_image_sizes[ $core_image_size_random_key ]['value'];
					} else {
						$core_image_size_random_key = array_rand( $image_sizes_random, 1 );
						$image_size                 = $image_sizes_random[ $core_image_size_random_key ];
					}
					// Get the random WordPress defined image size.
					$src = wp_get_attachment_image_src( $id, $image_size );
				} else {
					// Get the requested WordPress defined image size.
					$src = wp_get_attachment_image_src( $id, $image_size );
				}
			} else {
				$isize = envira_find_clostest_size( $data ) !== '' ? envira_find_clostest_size( $data ) : 'full';
				$src   = apply_filters( 'envira_gallery_default_image_src', wp_get_attachment_image_src( $id, $isize ), $id, $item, $data, $mobile );
			}
		} else {
			$src = apply_filters( 'envira_gallery_retina_image_src', wp_get_attachment_image_src( $id, 'full' ), $id, $item, $data, $mobile );
		}
	endif;

	// Check if this returned an image.
	if ( ! $src ) {
		// Fallback to the $item's image source.
		$image = isset( $item['src'] ) ? $item['src'] : false;
	} elseif ( $retina && isset( $item['link'] ) && envira_is_image( $item['link'] ) && $item['src'] !== $item['link'] ) {
		$image = esc_url( $item['link'] );
	} elseif ( ! $instagram && is_array( $src ) ) {
		$image = $src[0];
	} elseif ( envira_is_image( $src ) ) {
		$image = $src;
	}

	// If we still don't have an image at this point, something went wrong.
	if ( ! isset( $image ) ) {
		$item_link = isset( $item['link'] ) ? $item['link'] : false;
		return apply_filters( 'envira_gallery_no_image_src', $item_link, $id, $item, $data );
	}

	// Nothing exists above the original, so the retina pass has nothing to generate.
	// Without this it falls through and is sized from the hidden crop_width/height.
	if ( 'full' === $image_size && 'mobile' !== $type ) {
		return apply_filters( 'envira_gallery_image_src', $image, $id, $item, $data );
	}

	// If the current layout is justified/automatic
	// if the image size is a WordPress size and we're not requesting a retina image we don't need to resize or crop anything.
	if ( 'default' !== $image_size && ! $retina && 'mobile' !== $type ) {
		// Return the image.
		return apply_filters( 'envira_gallery_image_src', $image, $id, $item, $data );
	}

	$crop = true === $allow_crop && envira_get_config( 'crop', $data );

	if ( $crop || 'mobile' === $type ) {

		// If the image size is default (i.e. the user has input their own custom dimensions in the Gallery),
		// we may need to resize the image now
		// This is safe to call every time, as resize_image() will check if the image already exists, preventing thumbnails
		// from being generated every single time.
		$args = [
			'position' => envira_get_config( 'crop_position', $data ),
			'width'    => envira_get_config( $type . '_width', $data ),
			'height'   => envira_get_config( $type . '_height', $data ),
			'quality'  => 100,
			'retina'   => $retina,
		];

		// If we're requesting a retina image, and the gallery uses a registered WordPress image size,
		// we need use the width and height of that registered WordPress image size - not the gallery's
		// image width and height, which are hidden settings.
		// if this is mobile, go with the mobile image settings, otherwise proceed?
		if ( 'default' !== $image_size && $retina && 'mobile' !== $type ) {
			// Find WordPress registered image size.
			$core_image_sizes = envira_get_image_sizes( true ); // true = WordPress only image sizes (excludes random).
			foreach ( $core_image_sizes as $size ) {
				if ( $size['value'] !== $image_size ) {
					continue;
				}
				// We found the image size. Use its dimensions.
				if ( ! empty( $size['width'] ) ) {
					$args['width'] = $size['width'];
				}
				if ( ! empty( $size['height'] ) ) {
					$args['height'] = $size['height'];
				}
				break;
			}
		}

		// Filter.
		$args = apply_filters( 'envira_gallery_crop_image_args', $args );

		// Make sure we're grabbing the full image to crop.
		$image_to_crop = apply_filters( 'envira_gallery_crop_image_src', wp_get_attachment_image_src( $id, 'full' ), $id, $item, $data, $mobile );

		// If this has been passed as an array, take the first element which should be the url.
		if ( is_array( $image_to_crop ) ) {
			$image_to_crop = ( false !== esc_url( $image_to_crop[0] ) ) ? esc_url( $image_to_crop[0] ) : false;
		}

		// Check if this returned an image.
		if ( ! $image_to_crop ) {
			// Fallback to the $item's image source.
			$image_to_crop = ! empty( $item['src'] ) ? $item['src'] : false;
		} elseif ( ! $instagram && is_array( $src ) ) {
			$image_to_crop = ! empty( $src[0] ) ? $src[0] : false;
		}

		$resized_image = envira_resize_image( $image_to_crop, $args['width'], $args['height'], true, envira_get_config( 'crop_position', $data ), $args['quality'], $args['retina'], $data );

		// If there is an error, possibly output error message and return the default image src.
		if ( ! is_wp_error( $resized_image ) ) {
			return apply_filters( 'envira_gallery_image_src', $resized_image, $id, $item, $data );
		}
	}

	// return full image.
	return apply_filters( 'envira_gallery_image_src', $image, $id, $item, $data );
}

/**
 * Resolve a small image URL for thumbnail-sized UI: the lightbox thumbnail strip
 * (data-thumb), the horizontal-slideshow thumbnail strip, and envirabox's ghost
 * preload.
 *
 * Resolution order, first non-empty wins:
 *
 * 1. The item's own generated thumb, when it has one (unchanged behaviour for every
 *    gallery that already stores one).
 * 2. A WordPress-generated size for the attachment — small, already on disk, and
 *    never larger than the original.
 * 3. The item's src, as a last resort.
 *
 * Callers used to inline `isset( $item['thumb'] ) ? $item['thumb'] : $item['src']`,
 * which returns an empty string for the many galleries whose stored `thumb` key is
 * `''` — that emitted `data-thumb=""` and made envirabox fall back to the full-size
 * grid image. This never returns an empty string while any source is known.
 *
 * @since 1.16.2
 *
 * @param array      $item    Gallery item data.
 * @param int|string $item_id Attachment/item ID, when the caller knows it.
 * @param string     $size    WordPress image size to prefer for step 2.
 * @return string Image URL, or an empty string when the item has no source at all.
 */
function envira_get_item_thumb_src( $item, $item_id = 0, $size = 'thumbnail' ) {

	$thumb = '';

	if ( ! empty( $item['thumb'] ) && is_string( $item['thumb'] ) ) {
		$thumb = $item['thumb'];
	}

	if ( ! $thumb ) {
		$id = ! empty( $item_id ) ? $item_id : ( isset( $item['id'] ) ? $item['id'] : 0 );

		if ( is_numeric( $id ) && (int) $id > 0 ) {
			$sized = wp_get_attachment_image_url( (int) $id, $size );

			if ( $sized ) {
				$thumb = $sized;
			}
		}
	}

	if ( ! $thumb && ! empty( $item['src'] ) && is_string( $item['src'] ) ) {
		$thumb = $item['src'];
	}

	/**
	 * Filter the resolved thumbnail-sized image URL for a gallery item.
	 *
	 * @since 1.16.2
	 *
	 * @param string     $thumb   Resolved image URL.
	 * @param array      $item    Gallery item data.
	 * @param int|string $item_id Attachment/item ID as passed in.
	 * @param string     $size    WordPress image size that was preferred.
	 */
	return apply_filters( 'envira_item_thumb_src', $thumb, $item, $item_id, $size );
}

/**
 * Helper Method to remove Envira (hopefully) generated cropped images when attachment is removed.
 *
 * @param integer $attach_id Image ID.
 */
function envira_gallery_delete_attachment( $attach_id = false ) {

	if ( false === $attach_id ) {
		return;
	}

	$directory = get_attached_file( $attach_id );

	if ( empty( $directory ) || ! file_exists( $directory ) ) {
		return;
	}

	$basename                   = wp_basename( $directory );
	$extension                  = pathinfo( $directory, PATHINFO_EXTENSION );
	$basename_without_extension = str_replace( '.' . $extension, '', $basename );
	$path                       = str_replace( $basename, '', $directory );
	$mask                       = $path . $basename_without_extension . '-*_c.' . $extension; // delete the crop files Envira can generate.

	if ( empty( $basename ) || empty( $extension ) ) {
		return;
	}

	array_map( 'unlink', glob( $mask ) );
}
add_action( 'delete_attachment', 'envira_gallery_delete_attachment', 10, 1 );
