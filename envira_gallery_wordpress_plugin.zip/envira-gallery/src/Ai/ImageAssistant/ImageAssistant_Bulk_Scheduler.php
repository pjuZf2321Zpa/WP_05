<?php
/**
 * Bulk metadata generation via Action Scheduler.
 *
 * One image = one scheduled action. Job progress lives in a transient keyed by
 * job_id so the UI can poll it without hammering options/term tables.
 *
 * @package Envira Gallery
 * @since 1.13.6
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ImageAssistant_Bulk_Scheduler
 */
class ImageAssistant_Bulk_Scheduler {

	const ACTION_HOOK      = 'envira_ai_image_assistant_bulk_image';
	const ACTION_HOOK_AUTO = 'envira_ai_image_assistant_auto_image';
	const MAX_PER_JOB      = 100;
	const TRANSIENT_TTL    = HOUR_IN_SECONDS;
	const TRANSIENT_GROUP  = 'envira_ai_ia_job_';

	// Per-user index (user_meta) of active bulk job ids → gallery id, so a reloaded
	// editor can discover a running job WITHOUT scanning the options table for
	// `_transient_` rows — that scan returns nothing under a persistent object
	// cache (Redis/Memcached), where transients live in the cache, not the DB.
	const ACTIVE_JOBS_META = '_envira_ia_bulk_active_jobs';
	// Per-attachment status marker for auto-on-upload, so the gallery editor can
	// show a "Generating…" badge and patch the item live when it completes. One
	// transient per attachment → no shared-write race between concurrent workers.
	const AUTO_MARKER_GROUP = 'envira_ai_ia_auto_';
	const AUTO_MARKER_TTL   = 900; // 15 minutes.

	/**
	 * Wire the worker hooks.
	 */
	public function hooks() {
		add_action( self::ACTION_HOOK, [ $this, 'process_image' ], 10, 5 );
		add_action( self::ACTION_HOOK_AUTO, [ $this, 'process_auto_image' ], 10, 4 );
	}

	/**
	 * Queue a single freshly-uploaded image for background metadata generation
	 * (the "Automatically generate on upload" setting). Unlike a bulk job this
	 * keeps no progress state — it's silent background work, one async action
	 * per image — so it never appears in the bulk progress UI.
	 *
	 * @param int    $attachment_id    Attachment ID.
	 * @param string $tone             Tone slug.
	 * @param array  $fields           Fields to generate.
	 * @param bool   $skip_if_existing Skip when the image already has the fields.
	 */
	public static function enqueue_auto( $attachment_id, $tone, $fields, $skip_if_existing = true ) {
		$attachment_id = (int) $attachment_id;
		$fields        = array_values( (array) $fields );
		if ( $attachment_id <= 0 || empty( $fields ) || ! function_exists( 'as_enqueue_async_action' ) ) {
			return;
		}
		as_enqueue_async_action(
			self::ACTION_HOOK_AUTO,
			[
				'attachment_id'    => $attachment_id,
				'tone'             => (string) $tone,
				'fields'           => $fields,
				'skip_if_existing' => (bool) $skip_if_existing,
			],
			'envira-ai-image-assistant'
		);
		// Mark pending so the gallery editor can badge the item while it waits.
		set_transient( self::AUTO_MARKER_GROUP . $attachment_id, [ 'status' => 'pending' ], self::AUTO_MARKER_TTL );
	}

	/**
	 * Read the auto-on-upload status marker for an attachment.
	 *
	 * @param int $attachment_id Attachment ID.
	 * @return array|null { status: pending|done|error, applied?: array, code?: string, message?: string, http?: int } or null.
	 */
	public static function get_auto_marker( $attachment_id ) {
		$marker = get_transient( self::AUTO_MARKER_GROUP . (int) $attachment_id );
		return is_array( $marker ) ? $marker : null;
	}

	/**
	 * Record a terminal "done" status for an auto-on-upload image.
	 *
	 * @param int   $attachment_id Attachment ID.
	 * @param array $applied       Applied fields (empty when skipped/failed).
	 */
	private static function mark_auto_done( $attachment_id, $applied = [] ) {
		set_transient(
			self::AUTO_MARKER_GROUP . (int) $attachment_id,
			[
				'status'  => 'done',
				'applied' => array_intersect_key( (array) $applied, array_flip( [ 'alt_text', 'title', 'caption', 'tags' ] ) ),
			],
			self::AUTO_MARKER_TTL
		);
	}

	/**
	 * Record a terminal "error" status for an auto-on-upload image, carrying the
	 * code/message/HTTP status so the gallery editor can show the user why it
	 * failed (e.g. a 402 credits-exhausted notice).
	 *
	 * @param int      $attachment_id Attachment ID.
	 * @param WP_Error $error         The failure from process_single_attachment().
	 */
	private static function mark_auto_failed( $attachment_id, $error ) {
		$data = is_object( $error ) && method_exists( $error, 'get_error_data' ) ? $error->get_error_data() : [];
		$http = is_array( $data ) && isset( $data['status'] ) ? (int) $data['status'] : 0;
		set_transient(
			self::AUTO_MARKER_GROUP . (int) $attachment_id,
			[
				'status'  => 'error',
				'code'    => $error->get_error_code(),
				'message' => $error->get_error_message(),
				'http'    => $http,
			],
			self::AUTO_MARKER_TTL
		);
	}

	/**
	 * Action Scheduler worker for an auto-on-upload image. Best-effort: generate
	 * and apply, or log and move on. No job state to update.
	 *
	 * @param int    $attachment_id    Attachment ID.
	 * @param string $tone             Tone slug.
	 * @param array  $fields           Fields to generate.
	 * @param bool   $skip_if_existing Skip when already populated.
	 */
	public function process_auto_image( $attachment_id, $tone, $fields, $skip_if_existing = true ) {
		$attachment_id = (int) $attachment_id;
		if ( $attachment_id <= 0 || 'attachment' !== get_post_type( $attachment_id ) ) {
			return;
		}

		// Re-check between enqueue and execution: the setting may have been
		// switched off, or the license downgraded, in the meantime.
		$settings = ImageAssistant_Settings::get_all();
		if ( empty( $settings['auto_on_upload'] ) || ! ImageAssistant_License::is_eligible() ) {
			return;
		}

		$fields = array_values( (array) $fields );
		if ( in_array( 'tags', $fields, true ) && ! taxonomy_exists( 'envira-tag' ) ) {
			$fields = array_values(
				array_filter(
					$fields,
					function ( $f ) {
						return 'tags' !== $f;
					}
				)
			);
		}
		if ( empty( $fields ) ) {
			self::mark_auto_done( $attachment_id );
			return;
		}

		if ( $skip_if_existing ) {
			$missing = self::missing_fields( $attachment_id, $fields );
			if ( empty( $missing ) ) {
				self::mark_auto_done( $attachment_id );
				return;
			}
			$fields = $missing; // regenerate only the empty fields; keep existing ones
		}

		$result = ImageAssistant_REST::process_single_attachment( $attachment_id, (string) $tone, $fields, 'auto-upload-' . $attachment_id );
		if ( is_wp_error( $result ) ) {
			error_log( '[envira-ai-image] auto-on-upload generation failed for #' . $attachment_id . ': ' . $result->get_error_message() );
			// Record the failure (not a silent "done") so the gallery editor can
			// tell the user — most importantly when credits are exhausted, where
			// the spinner would otherwise just vanish with no explanation.
			self::mark_auto_failed( $attachment_id, $result );
			return;
		}
		self::mark_auto_done( $attachment_id, isset( $result['applied'] ) ? (array) $result['applied'] : [] );
	}

	/**
	 * Start a bulk job. Returns the job_id and total count.
	 *
	 * @param array  $attachment_ids   List of attachment IDs to process (will be capped).
	 * @param string $tone             Tone slug.
	 * @param array  $fields           Fields to generate.
	 * @param int    $gallery_id       Source gallery (for context).
	 * @param bool   $skip_if_existing When true, attachments that already have non-empty
	 *                                 values for every requested field are skipped before
	 *                                 the Worker (and credit) is touched.
	 * @return array|WP_Error
	 */
	public static function start( $attachment_ids, $tone, $fields, $gallery_id = 0, $skip_if_existing = false ) {
		if ( ! function_exists( 'as_enqueue_async_action' ) ) {
			return new WP_Error( 'as_missing', __( 'Action Scheduler is not available.', 'envira-gallery' ) );
		}

		$ids = array_values( array_unique( array_map( 'absint', (array) $attachment_ids ) ) );
		$ids = array_values( array_filter( $ids ) );
		if ( empty( $ids ) ) {
			return new WP_Error( 'empty_selection', __( 'No images selected.', 'envira-gallery' ) );
		}
		if ( count( $ids ) > self::MAX_PER_JOB ) {
			return new WP_Error(
				'too_many',
				sprintf(
					/* translators: %d: cap */
					__( 'You can process at most %d images per bulk job.', 'envira-gallery' ),
					self::MAX_PER_JOB
				)
			);
		}

		// Strip 'tags' from the requested fields when the Envira Tags addon is
		// inactive at start time. The taxonomy can also be deactivated between
		// enqueue and AS execution; process_image() also checks at run-time, so
		// this just avoids charging the user up front for a field that will
		// definitely be skipped. See historical regression #3388.
		$fields = array_values( $fields );
		if ( in_array( 'tags', $fields, true ) && ! taxonomy_exists( 'envira-tag' ) ) {
			$fields = array_values(
				array_filter(
					$fields,
					function ( $f ) {
						return 'tags' !== $f;
					}
				)
			);
		}

		$job_id  = wp_generate_uuid4();
		$total   = count( $ids );
		$user_id = (int) get_current_user_id();

		self::write_state(
			$job_id,
			[
				'job_id'           => $job_id,
				'user_id'          => $user_id,
				'gallery_id'       => (int) $gallery_id,
				'attachment_ids'   => $ids,
				'total'            => $total,
				'completed'        => 0,
				'failed'           => 0,
				'skipped'          => 0,
				'errors'           => [],
				'tone'             => $tone,
				'fields'           => $fields,
				'skip_if_existing' => (bool) $skip_if_existing,
				'started'          => time(),
				'status'           => 'running',
				'cancel_requested' => false,
			]
		);

		// Index this job for object-cache-safe discovery on editor reload.
		self::record_active_job( $user_id, $job_id, (int) $gallery_id );

		foreach ( $ids as $attachment_id ) {
			as_enqueue_async_action(
				self::ACTION_HOOK,
				[
					'job_id'           => $job_id,
					'attachment_id'    => $attachment_id,
					'tone'             => $tone,
					'fields'           => $fields,
					'skip_if_existing' => (bool) $skip_if_existing,
				],
				'envira-ai-image-assistant'
			);
		}

		return [
			'job_id' => $job_id,
			'total'  => $total,
		];
	}

	/**
	 * Determine whether the given user owns the job (or has site-level admin).
	 *
	 * @param array $state   Job state.
	 * @param int   $user_id User id checking. Defaults to current user.
	 * @return bool
	 */
	public static function user_can_access_job( $state, $user_id = 0 ) {
		$user_id = ! empty( $user_id ) ? $user_id : (int) get_current_user_id();
		if ( ! $user_id ) {
			return false;
		}
		// Site admins can always inspect/cancel any job (support flows).
		if ( user_can( $user_id, 'manage_options' ) ) {
			return true;
		}
		return (int) ( $state['user_id'] ?? 0 ) === $user_id;
	}

	/**
	 * Mark a running job as cancelled. Pending AS actions for the job will
	 * short-circuit when they fire.
	 *
	 * @param string $job_id Job ID.
	 * @return bool True when the job existed and was running.
	 */
	public static function cancel( $job_id ) {
		$state = self::read_state( $job_id );
		if ( empty( $state ) ) {
			return false;
		}
		if ( in_array( $state['status'] ?? '', [ 'complete', 'cancelled' ], true ) ) {
			return false;
		}
		$state['cancel_requested'] = true;
		$state['status']           = 'cancelled';
		$state['finished']         = time();
		self::write_state( $job_id, $state );
		self::forget_active_job( (int) ( $state['user_id'] ?? 0 ), $job_id );
		return true;
	}

	/**
	 * Process one image inside the AS worker.
	 *
	 * @param string $job_id           Job ID.
	 * @param int    $attachment_id    Attachment ID.
	 * @param string $tone             Tone slug.
	 * @param array  $fields           Fields to generate.
	 * @param bool   $skip_if_existing Whether to skip attachments that already have all targeted fields.
	 */
	public function process_image( $job_id, $attachment_id, $tone, $fields, $skip_if_existing = false ) {
		$state = self::read_state( $job_id );
		if ( empty( $state ) ) {
			return;
		}

		// Re-assert the originating user still has edit_post on this attachment.
		// AS actions run minutes/hours after enqueue — capability changes (role
		// demotion, post status flipped to private, etc.) between then and now
		// must not be ignored. Without this the worker would happily mutate
		// attachments the user can no longer edit.
		$owner_id = (int) ( $state['user_id'] ?? 0 );
		if ( $owner_id && ! user_can( $owner_id, 'edit_post', (int) $attachment_id ) ) {
			$state['failed']   = (int) ( $state['failed'] ?? 0 ) + 1;
			$state['errors'][] = [
				'attachment_id' => (int) $attachment_id,
				'code'          => 'cap_revoked',
				'message'       => __( 'Owner no longer has permission to edit this attachment.', 'envira-gallery' ),
			];
			self::maybe_mark_complete( $state );
			self::write_state( $job_id, $state );
			return;
		}

		// Drop 'tags' at run-time if the taxonomy disappeared between enqueue
		// and execution — prevents an Anthropic call we'd just throw away.
		$fields = array_values( (array) $fields );
		if ( in_array( 'tags', $fields, true ) && ! taxonomy_exists( 'envira-tag' ) ) {
			$fields = array_values(
				array_filter(
					$fields,
					function ( $f ) {
						return 'tags' !== $f;
					}
				)
			);
		}
		if ( empty( $fields ) ) {
			$state['skipped'] = (int) ( $state['skipped'] ?? 0 ) + 1;
			self::maybe_mark_complete( $state );
			self::write_state( $job_id, $state );
			return;
		}

		// Job-level cancel signal — bail before debiting.
		if ( ! empty( $state['cancel_requested'] ) ) {
			return;
		}

		// Skip-if-existing is PER-FIELD: regenerate only the fields that are still
		// empty so already-populated alt/title/caption are preserved, and skip the
		// image entirely only when nothing is missing. Scoped to the job's gallery
		// so the check reads the same per-image copy the editor shows (not the
		// Media Library fields, which can disagree).
		if ( $skip_if_existing ) {
			$missing = self::missing_fields( (int) $attachment_id, (array) $fields, (int) ( $state['gallery_id'] ?? 0 ) );
			if ( empty( $missing ) ) {
				$state['skipped'] = (int) ( $state['skipped'] ?? 0 ) + 1;
				self::maybe_mark_complete( $state );
				self::write_state( $job_id, $state );
				return;
			}
			$fields = $missing;
		}

		$result = ImageAssistant_REST::process_single_attachment(
			(int) $attachment_id,
			(string) $tone,
			(array) $fields,
			'bulk-' . $job_id
		);

		if ( is_wp_error( $result ) ) {
			$state['failed']   = (int) ( $state['failed'] ?? 0 ) + 1;
			$state['errors'][] = [
				'attachment_id' => (int) $attachment_id,
				'code'          => $result->get_error_code(),
				'message'       => $result->get_error_message(),
			];
		} else {
			$state['completed'] = (int) ( $state['completed'] ?? 0 ) + 1;
			if ( isset( $result['credits']['total_remaining'] ) ) {
				$state['credits_remaining'] = (int) $result['credits']['total_remaining'];
			}
			// Record what was written so the gallery editor can patch the
			// in-page item live, without a reload (todo-issue 04). Only the
			// fields the editor list renders/serializes are kept — alt, title,
			// caption — to bound transient size; description does not appear
			// in the editor item and are synced server-side already.
			$applied_map = isset( $result['applied'] ) && is_array( $result['applied'] ) ? $result['applied'] : [];
			$patch       = array_intersect_key( $applied_map, array_flip( [ 'alt_text', 'title', 'caption', 'tags' ] ) );
			if ( ! empty( $patch ) ) {
				if ( ! isset( $state['applied'] ) || ! is_array( $state['applied'] ) ) {
					$state['applied'] = [];
				}
				$state['applied'][ (int) $attachment_id ] = $patch;
			}
		}

		self::maybe_mark_complete( $state );
		self::write_state( $job_id, $state );
	}

	/**
	 * Returns the subset of $fields that are NOT yet populated for the attachment
	 * (gallery-aware). An empty result means the image is already fully populated
	 * for the requested fields. Used by skip-if-existing to (a) skip fully-populated
	 * images and (b) regenerate ONLY the missing fields, leaving existing values
	 * (alt/title/caption) intact rather than clobbering them.
	 *
	 * Gallery context matters for alt/title/caption. The gallery editor shows and
	 * edits Envira's OWN per-image copy (`_eg_gallery_data['gallery'][ id ]`, keys
	 * alt/title/caption), which can disagree with the Media Library attachment
	 * fields — e.g. an earlier generate or an import filled the attachment caption
	 * while the gallery copy is still blank. When a gallery id is supplied we read
	 * that per-image copy, so an image the user sees as empty in the editor is
	 * never skipped just because the Media Library copy is populated. `description`
	 * and `tags` aren't stored in the gallery, so they always come from the
	 * attachment / taxonomy.
	 *
	 * @param int   $attachment_id Attachment ID.
	 * @param array $fields        Fields requested.
	 * @param int   $gallery_id    Gallery the job is scoped to (0 = none, use the
	 *                             Media Library attachment fields).
	 * @return array List of field keys still missing (subset of $fields).
	 */
	private static function missing_fields( $attachment_id, $fields, $gallery_id = 0 ) {
		$post = get_post( $attachment_id );
		if ( ! $post ) {
			// No attachment record → nothing is "already present"; all requested fields are missing.
			return array_values( (array) $fields );
		}

		// Envira's per-image copy for this gallery, when scoped to one. This is the
		// authoritative source for what the gallery editor shows for alt/title/
		// caption (see method docblock).
		$gallery_image = null;
		if ( $gallery_id > 0 ) {
			$data          = get_post_meta( (int) $gallery_id, '_eg_gallery_data', true );
			$gallery_image = ( is_array( $data ) && isset( $data['gallery'][ $attachment_id ] ) && is_array( $data['gallery'][ $attachment_id ] ) )
				? $data['gallery'][ $attachment_id ]
				: []; // In the gallery but no per-image record yet → treat all as empty.
		}
		$filled = function ( $value ) {
			return '' !== trim( (string) $value );
		};

		$missing = [];
		foreach ( (array) $fields as $field ) {
			$has = false;
			switch ( $field ) {
				case 'alt_text':
					$has = null !== $gallery_image
						? $filled( $gallery_image['alt'] ?? '' )
						: (bool) get_post_meta( $attachment_id, '_wp_attachment_image_alt', true );
					break;
				case 'title':
				case 'cleaned_title':
					$has = null !== $gallery_image
						? $filled( $gallery_image['title'] ?? '' )
						: ! empty( $post->post_title );
					break;
				case 'caption':
					$has = null !== $gallery_image
						? $filled( $gallery_image['caption'] ?? '' )
						: ! empty( $post->post_excerpt );
					break;
				case 'description':
					$has = ! empty( $post->post_content );
					break;
				case 'tags':
					if ( taxonomy_exists( 'envira-tag' ) ) {
						$terms = wp_get_object_terms( $attachment_id, 'envira-tag', [ 'fields' => 'ids' ] );
						$has   = ! is_wp_error( $terms ) && ! empty( $terms );
					} else {
						// No taxonomy available — treat as "not skippable".
						$has = false;
					}
					break;
			}
			if ( ! $has ) {
				$missing[] = $field;
			}
		}
		return array_values( $missing );
	}

	/**
	 * Flip the job state to "complete" when all attachments are accounted for.
	 * Caller is still responsible for persisting via write_state().
	 *
	 * @param array $state Job state, modified in place.
	 */
	private static function maybe_mark_complete( &$state ) {
		$processed = (int) ( $state['completed'] ?? 0 )
			+ (int) ( $state['failed'] ?? 0 )
			+ (int) ( $state['skipped'] ?? 0 );
		if ( $processed >= (int) ( $state['total'] ?? 0 ) ) {
			if ( 'cancelled' !== ( $state['status'] ?? '' ) ) {
				$state['status'] = 'complete';
			}
			$state['finished'] = time();
			// Job finished — drop it from the owner's active-job index promptly.
			// (find_active_for_user also self-heals, but this keeps it tight.)
			self::forget_active_job( (int) ( $state['user_id'] ?? 0 ), (string) ( $state['job_id'] ?? '' ) );
		}
	}

	/**
	 * Drive the Action Scheduler queue forward inline (bounded).
	 *
	 * The bulk job is one async action per image. In environments where AS's
	 * background runner isn't firing promptly — cron disabled, or the loopback
	 * request blocked (e.g. local Docker over a self-signed HTTPS host) — those
	 * actions sit pending and the progress UI never advances. The status poll
	 * calls this so each poll processes a short slice of due actions, keeping the
	 * job moving while the client watches.
	 *
	 * Safe alongside a real background runner: AS claim-locking guarantees the
	 * same action is never executed twice. Time-bounded so the REST request
	 * returns quickly; subsequent polls continue draining the queue.
	 */
	public static function run_due_actions() {
		if ( ! class_exists( 'ActionScheduler' ) || ! ActionScheduler::is_initialized() ) {
			return;
		}
		// Only spin up the runner when this plugin actually has queued work (bulk
		// or auto-on-upload), so a poll doesn't shoulder other plugins' queues
		// unless we have our own.
		if ( function_exists( 'as_has_scheduled_action' )
			&& ! as_has_scheduled_action( self::ACTION_HOOK )
			&& ! as_has_scheduled_action( self::ACTION_HOOK_AUTO ) ) {
			return;
		}
		$time_limit = function () {
			return 8;
		};
		add_filter( 'action_scheduler_queue_runner_time_limit', $time_limit, 99 );
		try {
			ActionScheduler::runner()->run( 'Envira AI Image Assistant' );
		} catch ( \Throwable $e ) {
			error_log( '[envira-ai-image] inline Action Scheduler run failed: ' . $e->getMessage() );
		}
		remove_filter( 'action_scheduler_queue_runner_time_limit', $time_limit, 99 );
	}

	/**
	 * Find the current user's still-running bulk job, optionally scoped to a
	 * gallery. Lets a freshly-loaded editor restore the in-progress indicator
	 * after a reload (the client-side job handle is lost, but the job lives on
	 * in a transient + the Action Scheduler queue).
	 *
	 * @param int $gallery_id Restrict to this gallery (0 = any).
	 * @return array|null The running job's state, or null.
	 */
	public static function find_active_for_user( $gallery_id = 0 ) {
		$user_id = (int) get_current_user_id();
		if ( ! $user_id ) {
			return null;
		}

		// Discover the running job via a per-user index in user_meta — NOT by
		// scanning the options table for `_transient_` rows. Under a persistent
		// object cache (Redis/Memcached — standard on production hosting) transients
		// live in the cache, not the options table, so a DB scan finds nothing.
		// user_meta is object-cache-safe, and the per-job state is still read by
		// known key via read_state() (which resolves under any cache backend).
		$jobs = get_user_meta( $user_id, self::ACTIVE_JOBS_META, true );
		if ( ! is_array( $jobs ) || empty( $jobs ) ) {
			return null;
		}

		$found   = null;
		$changed = false;
		foreach ( $jobs as $job_id => $gid ) {
			$state = self::read_state( (string) $job_id );
			// Self-heal: drop entries whose job has finished (complete/cancelled)
			// or whose state transient has expired, so the index can't grow stale.
			if ( ! is_array( $state ) || 'running' !== ( $state['status'] ?? '' ) ) {
				unset( $jobs[ $job_id ] );
				$changed = true;
				continue;
			}
			if ( null === $found
				&& (int) ( $state['user_id'] ?? 0 ) === $user_id
				&& ( ! $gallery_id || (int) ( $state['gallery_id'] ?? 0 ) === (int) $gallery_id ) ) {
				$found = $state;
			}
		}

		if ( $changed ) {
			if ( empty( $jobs ) ) {
				delete_user_meta( $user_id, self::ACTIVE_JOBS_META );
			} else {
				update_user_meta( $user_id, self::ACTIVE_JOBS_META, $jobs );
			}
		}

		return $found;
	}

	/**
	 * Record a running job in the owner's active-job index (object-cache-safe
	 * discovery for {@see find_active_for_user()}).
	 *
	 * @param int    $user_id    Owner user id.
	 * @param string $job_id     Job ID.
	 * @param int    $gallery_id Gallery ID (0 if none).
	 * @return void
	 */
	private static function record_active_job( $user_id, $job_id, $gallery_id ) {
		$user_id = (int) $user_id;
		if ( ! $user_id || '' === (string) $job_id ) {
			return;
		}
		$jobs = get_user_meta( $user_id, self::ACTIVE_JOBS_META, true );
		if ( ! is_array( $jobs ) ) {
			$jobs = [];
		}
		$jobs[ (string) $job_id ] = (int) $gallery_id;
		update_user_meta( $user_id, self::ACTIVE_JOBS_META, $jobs );
	}

	/**
	 * Remove a job from the owner's active-job index (on cancel/completion).
	 *
	 * @param int    $user_id Owner user id.
	 * @param string $job_id  Job ID.
	 * @return void
	 */
	private static function forget_active_job( $user_id, $job_id ) {
		$user_id = (int) $user_id;
		if ( ! $user_id || '' === (string) $job_id ) {
			return;
		}
		$jobs = get_user_meta( $user_id, self::ACTIVE_JOBS_META, true );
		if ( ! is_array( $jobs ) || ! isset( $jobs[ (string) $job_id ] ) ) {
			return;
		}
		unset( $jobs[ (string) $job_id ] );
		if ( empty( $jobs ) ) {
			delete_user_meta( $user_id, self::ACTIVE_JOBS_META );
		} else {
			update_user_meta( $user_id, self::ACTIVE_JOBS_META, $jobs );
		}
	}

	/**
	 * Get a job's state.
	 *
	 * @param string $job_id Job ID.
	 * @return array|null
	 */
	public static function read_state( $job_id ) {
		$state = get_transient( self::TRANSIENT_GROUP . $job_id );
		return is_array( $state ) ? $state : null;
	}

	/**
	 * Persist a job's state.
	 *
	 * @param string $job_id Job ID.
	 * @param array  $state State.
	 */
	public static function write_state( $job_id, $state ) {
		set_transient( self::TRANSIENT_GROUP . $job_id, $state, self::TRANSIENT_TTL );
	}
}
