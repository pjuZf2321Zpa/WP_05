<?php
/**
 * Gallery description generation (manual button + auto-on-save).
 *
 * Samples up to MAX_IMAGES of a gallery's images — their title/alt/caption text
 * only, NOT the image files — and asks the Worker's text-only gallery-description
 * endpoint for a short description. The result is stored in the gallery config
 * (_eg_gallery_data['config']['description']) — the Configuration-tab "Gallery
 * Description" field that the settings metabox edits and the frontend renders.
 *
 * The manual "Regenerate" button hits the REST endpoint directly. When the
 * "Gallery Description Generator" setting is enabled, saving a gallery whose
 * description is still empty schedules an async Action Scheduler job that
 * generates and stores one. It never overwrites an existing description.
 *
 * @package Envira Gallery
 * @since 1.13.6
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ImageAssistant_Gallery_Description
 */
class ImageAssistant_Gallery_Description {

	const AUTO_ACTION = 'envira_ai_image_assistant_gallery_description';
	const AS_GROUP    = 'envira-ai-image-assistant';
	const MAX_IMAGES  = 25;

	/**
	 * Wire hooks: auto-schedule on gallery save + the Action Scheduler worker.
	 *
	 * @return void
	 */
	public function hooks() {
		add_action( 'envira_gallery_saved_settings', [ $this, 'maybe_schedule_auto' ], 20, 3 );
		add_action( self::AUTO_ACTION, [ $this, 'run_auto' ], 10, 1 );
	}

	/**
	 * On gallery save, schedule async description generation when the "Gallery
	 * Description Generator" setting is on, the description is still empty, and
	 * the gallery has images. Never overwrites an existing description.
	 *
	 * @param array   $settings Saved gallery data (_eg_gallery_data).
	 * @param int     $post_id  Gallery post ID.
	 * @param WP_Post $post     Gallery post.
	 * @return void
	 */
	public function maybe_schedule_auto( $settings, $post_id, $post ) {
		if ( ! $post || 'envira' !== $post->post_type ) {
			return;
		}

		$defaults = ImageAssistant_Settings::get_all();
		if ( empty( $defaults['gallery_description_enabled'] ) ) {
			return;
		}

		// Only when the description is currently empty (never overwrite).
		$current = ( is_array( $settings ) && isset( $settings['config']['description'] ) )
			? trim( wp_strip_all_tags( (string) $settings['config']['description'] ) )
			: '';
		if ( '' !== $current ) {
			return;
		}

		if ( empty( $settings['gallery'] ) || ! is_array( $settings['gallery'] ) ) {
			return; // no images to sample.
		}

		if ( ! function_exists( 'as_enqueue_async_action' ) ) {
			return;
		}

		// Don't stack duplicate jobs for the same gallery.
		if ( function_exists( 'as_has_scheduled_action' )
			&& as_has_scheduled_action( self::AUTO_ACTION, [ (int) $post_id ], self::AS_GROUP ) ) {
			return;
		}

		as_enqueue_async_action( self::AUTO_ACTION, [ (int) $post_id ], self::AS_GROUP );
	}

	/**
	 * Action Scheduler worker: generate + store a description for the gallery,
	 * re-checking it is still empty (the user may have added one meanwhile).
	 *
	 * @param int $gallery_id Gallery post ID.
	 * @return void
	 */
	public function run_auto( $gallery_id ) {
		$gallery_id = (int) $gallery_id;
		if ( $gallery_id <= 0 ) {
			return;
		}

		$data    = get_post_meta( $gallery_id, '_eg_gallery_data', true );
		$current = ( is_array( $data ) && isset( $data['config']['description'] ) )
			? trim( wp_strip_all_tags( (string) $data['config']['description'] ) )
			: '';
		if ( '' !== $current ) {
			return; // filled in since scheduling — leave it.
		}

		$response = self::request( $gallery_id );
		if ( is_wp_error( $response ) ) {
			return;
		}
		$description = isset( $response['body']['description'] ) ? (string) $response['body']['description'] : '';
		if ( '' !== $description ) {
			self::apply( $gallery_id, $description );
		}
	}

	/**
	 * Sample the gallery's images and ask the Worker for a description. Shared by
	 * the REST route (manual button) and the auto-generate worker.
	 *
	 * @param int    $gallery_id Gallery post ID.
	 * @param string $tone       Tone slug; defaults to the configured tone.
	 * @return array|\WP_Error Worker response ({status, body}) or WP_Error.
	 */
	public static function request( $gallery_id, $tone = '' ) {
		$gallery = get_post( $gallery_id );
		if ( ! $gallery || 'envira' !== $gallery->post_type ) {
			return new \WP_Error( 'not_gallery', __( 'Not an Envira gallery.', 'envira-gallery' ) );
		}

		$license_key = ImageAssistant_License::get_key();
		if ( empty( $license_key ) ) {
			return new \WP_Error( 'no_license', __( 'No active Envira license found.', 'envira-gallery' ) );
		}

		if ( '' === (string) $tone ) {
			$defaults = ImageAssistant_Settings::get_all();
			$tone     = $defaults['default_tone'];
		}

		$images = self::sample_images( $gallery_id );
		if ( empty( $images ) ) {
			return new \WP_Error( 'empty_gallery', __( 'Gallery has no images to sample.', 'envira-gallery' ) );
		}

		return ImageAssistant_Worker_Client::gallery_description(
			[
				'license_key'     => $license_key,
				'product'         => 'envira',
				'tone'            => $tone,
				'gallery_name'    => (string) $gallery->post_title,
				'images'          => $images,
				'idempotency_key' => 'gallery-desc-' . (int) $gallery_id . '-' . substr( md5( $tone . '|' . wp_json_encode( $images ) ), 0, 12 ),
			]
		);
	}

	/**
	 * Store a description in the gallery config — the field the settings metabox
	 * edits and the frontend renders — and flush Envira's gallery cache.
	 *
	 * @param int    $gallery_id  Gallery post ID.
	 * @param string $description Description text.
	 * @return void
	 */
	public static function apply( $gallery_id, $description ) {
		$gallery_id = (int) $gallery_id;

		$data = get_post_meta( $gallery_id, '_eg_gallery_data', true );
		if ( ! is_array( $data ) ) {
			$data = [];
		}
		if ( empty( $data['config'] ) || ! is_array( $data['config'] ) ) {
			$data['config'] = [];
		}

		$data['config']['description'] = envira_santitize_description( $description );
		update_post_meta( $gallery_id, '_eg_gallery_data', $data );

		if ( function_exists( 'envira_flush_gallery_caches' ) ) {
			$slug = isset( $data['config']['slug'] ) ? (string) $data['config']['slug'] : '';
			envira_flush_gallery_caches( $gallery_id, $slug );
		}
	}

	/**
	 * Up to MAX_IMAGES of the gallery's images as {title, alt_text, caption},
	 * read from the gallery config image list (_eg_gallery_data['gallery']) —
	 * Envira references media by ID there, so images are NOT post_parent children.
	 *
	 * @param int $gallery_id Gallery post ID.
	 * @return array<int, array<string, string>>
	 */
	private static function sample_images( $gallery_id ) {
		$data  = get_post_meta( $gallery_id, '_eg_gallery_data', true );
		$items = ( is_array( $data ) && ! empty( $data['gallery'] ) && is_array( $data['gallery'] ) ) ? $data['gallery'] : [];

		$images = [];
		foreach ( $items as $item ) {
			if ( count( $images ) >= self::MAX_IMAGES ) {
				break;
			}
			if ( ! is_array( $item ) ) {
				continue;
			}
			$images[] = [
				'title'    => isset( $item['title'] ) ? (string) $item['title'] : '',
				'alt_text' => isset( $item['alt'] ) ? (string) $item['alt'] : '',
				'caption'  => isset( $item['caption'] ) ? (string) $item['caption'] : '',
			];
		}

		return $images;
	}
}
