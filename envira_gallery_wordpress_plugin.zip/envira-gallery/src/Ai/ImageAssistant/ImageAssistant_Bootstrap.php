<?php
/**
 * Bootstraps the AI Image Assistant feature.
 *
 * Loaded from envira-gallery.php during the main plugin's init. Owns the
 * require_once chain for the module and instantiates the long-lived classes
 * that register hooks.
 *
 * @package Envira Gallery
 * @since 1.13.6
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ImageAssistant_Bootstrap
 */
class ImageAssistant_Bootstrap {

	/**
	 * Load every file in the module and wire instances.
	 */
	public static function init() {
		$dir = trailingslashit( __DIR__ );

		require_once $dir . 'ImageAssistant_License.php';
		require_once $dir . 'ImageAssistant_Worker_Client.php';
		require_once $dir . 'ImageAssistant_Metadata_Applier.php';
		require_once $dir . 'ImageAssistant_Bulk_Scheduler.php';
		require_once $dir . 'ImageAssistant_AutoUpload.php';
		require_once $dir . 'ImageAssistant_REST.php';
		require_once $dir . 'ImageAssistant_Settings.php';
		require_once $dir . 'ImageAssistant_Assets.php';
		require_once $dir . 'ImageAssistant_GalleryUI.php';
		require_once $dir . 'ImageAssistant_Gallery_Description.php';

		( new ImageAssistant_REST() )->hooks();

		// Settings sub-tab + gallery UI — admin only.
		if ( is_admin() ) {
			( new ImageAssistant_Settings() )->hooks();
			( new ImageAssistant_Assets() )->hooks();
			( new ImageAssistant_GalleryUI() )->hooks();
		}

		// Action Scheduler worker — must register on every request because AS may
		// run on cron, REST, or admin-init depending on how the user's site is
		// configured.
		( new ImageAssistant_Bulk_Scheduler() )->hooks();

		// Auto-generate-on-upload listener. Registered on every request: the
		// gallery upload/insert hooks fire during admin-ajax, and the enqueue is
		// gated on the setting + license inside the handler.
		( new ImageAssistant_AutoUpload() )->hooks();

		// Gallery description: manual regenerate (REST) + auto-generate on save
		// when the setting is on and the description is empty. Registered every
		// request — the save hook fires during admin/REST saves and the Action
		// Scheduler worker runs on cron/REST.
		( new ImageAssistant_Gallery_Description() )->hooks();
	}
}
