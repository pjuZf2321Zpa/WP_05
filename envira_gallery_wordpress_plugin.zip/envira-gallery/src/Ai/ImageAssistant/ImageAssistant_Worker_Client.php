<?php
/**
 * HTTP client for the envira-ai-image Cloudflare Worker.
 *
 * @package Envira Gallery
 * @since 1.13.6
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ImageAssistant_Worker_Client
 *
 * All HTTP I/O to the envira-ai-image Worker. Methods return either an
 * associative array (success) or a WP_Error (network / HTTP error).
 *
 * Customers do not configure anything — the plugin ships pointing at the
 * production Worker. Internal/dev sites flip a single constant to route to
 * staging:
 *
 *     // wp-config.php — staging
 *     define( 'ENVIRA_AI_IMAGE_ENV', 'staging' );
 *
 *     // wp-config.php — production (or omitted)
 *     define( 'ENVIRA_AI_IMAGE_ENV', 'live' );
 *
 * For unusual cases (custom routing, a local `wrangler dev` server) the
 * `envira_ai_image_worker_url` filter still exists as an escape hatch.
 *
 * No shared secret is sent — the Worker authenticates each request via the
 * license_key inside the body (any request for a non-existent license fails
 * at the credits-debit step with a 404).
 */
class ImageAssistant_Worker_Client {

	const TIMEOUT_GENERATE = 60;
	const TIMEOUT_DEFAULT  = 15;

	const DEFAULT_ENV = 'live';

	const WORKER_URLS = [
		'staging' => 'https://envira-ai-image-staging.imagely-envira.workers.dev',
		'live'    => 'https://envira-ai-image.imagely-envira.workers.dev',
	];

	/**
	 * Resolve the active environment slug.
	 *
	 * Reads ENVIRA_AI_IMAGE_ENV from wp-config.php when defined. Invalid
	 * values fall back to the default ('live') so a typo never silently
	 * routes a production install at a non-existent Worker.
	 *
	 * @return string One of self::WORKER_URLS keys.
	 */
	public static function env() {
		if ( defined( 'ENVIRA_AI_IMAGE_ENV' ) ) {
			$env = strtolower( (string) ENVIRA_AI_IMAGE_ENV );
			if ( isset( self::WORKER_URLS[ $env ] ) ) {
				return $env;
			}
			if ( function_exists( 'error_log' ) ) {
				error_log(
					sprintf(
						'[envira-ai-image] Unknown ENVIRA_AI_IMAGE_ENV value "%s" — falling back to "%s". Valid values: %s.',
						$env,
						self::DEFAULT_ENV,
						implode( ', ', array_keys( self::WORKER_URLS ) )
					)
				);
			}
		}
		return self::DEFAULT_ENV;
	}

	/**
	 * Resolve the Worker base URL for the active environment.
	 *
	 * The `envira_ai_image_worker_url` filter still wins so addon authors and
	 * CI can point at an arbitrary URL when really needed.
	 *
	 * @return string Untrailed base URL.
	 */
	public static function base_url() {
		$url = self::WORKER_URLS[ self::env() ];
		$url = apply_filters( 'envira_ai_image_worker_url', $url );
		return untrailingslashit( (string) $url );
	}

	/**
	 * Common request headers. Worker has no shared-secret auth — access is
	 * gated by the license_key inside the body (invalid keys 404 at the
	 * credits-debit step before any provider cost).
	 *
	 * @return array<string, string>
	 */
	private static function request_headers() {
		return [
			'Accept' => 'application/json',
		];
	}

	/**
	 * GET /envira-ai-image/health
	 *
	 * @return array|WP_Error
	 */
	/**
	 * GET /envira-ai-image/v1/tones — the canonical tone list (label + description).
	 *
	 * Cached for a day on the plugin side because the values change rarely and
	 * are loaded on every settings-page render.
	 *
	 * @return array|WP_Error  ['tones' => [['slug','label','description'], ...]]
	 */
	public static function tones() {
		$cached = get_transient( 'envira_ai_ia_tones' );
		if ( is_array( $cached ) && ! empty( $cached['tones'] ) ) {
			return [
				'status' => 200,
				'body'   => $cached,
			];
		}

		$response = wp_remote_get(
			self::base_url() . '/envira-ai-image/v1/tones',
			[
				'timeout' => self::TIMEOUT_DEFAULT,
				'headers' => [ 'Accept' => 'application/json' ],
			]
		);

		$parsed = self::parse_response( $response );
		if ( is_array( $parsed ) && 200 === ( $parsed['status'] ?? 0 ) && ! empty( $parsed['body']['tones'] ) ) {
			set_transient( 'envira_ai_ia_tones', $parsed['body'], DAY_IN_SECONDS );
		}
		return $parsed;
	}

	public static function health() {
		$response = wp_remote_get(
			self::base_url() . '/envira-ai-image/health',
			[
				'timeout' => self::TIMEOUT_DEFAULT,
				'headers' => [ 'Accept' => 'application/json' ],
			]
		);

		return self::parse_response( $response );
	}

	/**
	 * GET /envira-ai-image/v1/balance — proxied to the credits Worker.
	 *
	 * @param string $license_key Customer license key.
	 * @param string $product     Product slug ("envira" or "imagely").
	 * @return array|WP_Error
	 */
	public static function balance( $license_key, $product = 'envira' ) {
		if ( empty( $license_key ) ) {
			return new WP_Error( 'no_license', __( 'No license key.', 'envira-gallery' ) );
		}
		$url      = self::base_url() . '/envira-ai-image/v1/balance?' . http_build_query(
			[
				'license_key' => $license_key,
				'product'     => $product,
			]
		);
		$response = wp_remote_get(
			$url,
			[
				'timeout' => self::TIMEOUT_DEFAULT,
				'headers' => self::request_headers(),
			]
		);
		return self::parse_response( $response );
	}

	/**
	 * POST /envira-ai-image/v1/generate (multipart upload)
	 *
	 * @param array $args {
	 *     @type string $license_key      Customer license key.
	 *     @type string $product          "envira" or "imagely".
	 *     @type string $tone             Tone slug.
	 *     @type array  $fields           Fields to generate.
	 *     @type string $existing_title   Optional.
	 *     @type array  $context          Optional metadata.
	 *     @type string $image_path       Absolute path to image file on disk.
	 *     @type string $image_mime       Image MIME type.
	 *     @type string $image_filename   Filename to use in multipart part.
	 *     @type string $idempotency_key  Idempotency key.
	 * }
	 * @return array|WP_Error
	 */
	public static function generate( $args ) {
		if ( empty( $args['image_path'] ) || ! is_readable( $args['image_path'] ) ) {
			return new WP_Error( 'image_unreadable', __( 'Could not read image file.', 'envira-gallery' ) );
		}

		$boundary = wp_generate_password( 24, false, false );
		$fields   = isset( $args['fields'] ) && is_array( $args['fields'] ) ? $args['fields'] : [];

		$parts = [];

		$parts[] = self::form_field( $boundary, 'license_key', (string) $args['license_key'] );
		$parts[] = self::form_field( $boundary, 'product', (string) $args['product'] );
		$parts[] = self::form_field( $boundary, 'tone', (string) $args['tone'] );
		$parts[] = self::form_field( $boundary, 'fields', implode( ',', $fields ) );

		if ( ! empty( $args['existing_title'] ) ) {
			$parts[] = self::form_field( $boundary, 'existing_title', (string) $args['existing_title'] );
		}
		if ( ! empty( $args['context'] ) && is_array( $args['context'] ) ) {
			$parts[] = self::form_field( $boundary, 'context', wp_json_encode( $args['context'] ) );
		}

		$image_bytes = file_get_contents( $args['image_path'] ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Reading a server-local attachment we already own.
		if ( false === $image_bytes ) {
			return new WP_Error( 'image_unreadable', __( 'Could not read image file.', 'envira-gallery' ) );
		}

		$parts[] = self::form_file(
			$boundary,
			'image',
			$args['image_filename'] ?? 'image',
			$args['image_mime'] ?? 'application/octet-stream',
			$image_bytes
		);

		$body  = implode( '', $parts );
		$body .= "--{$boundary}--\r\n";

		$response = wp_remote_post(
			self::base_url() . '/envira-ai-image/v1/generate',
			[
				'timeout' => self::TIMEOUT_GENERATE,
				'headers' => array_merge(
					self::request_headers(),
					[
						'Content-Type'    => 'multipart/form-data; boundary=' . $boundary,
						'Idempotency-Key' => (string) ( $args['idempotency_key'] ?? '' ),
					]
				),
				'body'    => $body,
			]
		);

		return self::parse_response( $response );
	}

	/**
	 * POST /envira-ai-image/v1/cleanup-titles
	 *
	 * @param array $args {
	 *     @type string $license_key
	 *     @type string $product
	 *     @type array  $titles
	 *     @type string $idempotency_key
	 * }
	 * @return array|WP_Error
	 */
	public static function gallery_description( $args ) {
		$response = wp_remote_post(
			self::base_url() . '/envira-ai-image/v1/gallery-description',
			[
				'timeout' => self::TIMEOUT_DEFAULT,
				'headers' => array_merge(
					self::request_headers(),
					[
						'Content-Type'    => 'application/json',
						'Idempotency-Key' => (string) ( $args['idempotency_key'] ?? '' ),
					]
				),
				'body'    => wp_json_encode(
					[
						'license_key'  => $args['license_key'],
						'product'      => $args['product'] ?? 'envira',
						'tone'         => $args['tone'] ?? 'seo',
						'gallery_name' => $args['gallery_name'] ?? '',
						'images'       => array_values( (array) ( $args['images'] ?? [] ) ),
					]
				),
			]
		);

		return self::parse_response( $response );
	}

	public static function cleanup_titles( $args ) {
		$response = wp_remote_post(
			self::base_url() . '/envira-ai-image/v1/cleanup-titles',
			[
				'timeout' => self::TIMEOUT_DEFAULT,
				'headers' => array_merge(
					self::request_headers(),
					[
						'Content-Type'    => 'application/json',
						'Idempotency-Key' => (string) ( $args['idempotency_key'] ?? '' ),
					]
				),
				'body'    => wp_json_encode(
					[
						'license_key' => $args['license_key'],
						'product'     => $args['product'],
						'titles'      => array_values( (array) $args['titles'] ),
					]
				),
			]
		);

		return self::parse_response( $response );
	}

	/**
	 * Parse a wp_remote_* response into [body_array, status_code] or WP_Error.
	 *
	 * Returns an array on every HTTP response (including 4xx / 5xx) so callers
	 * can inspect `status` and `body` to map error codes to user messages.
	 *
	 * @param array|WP_Error $response Result of wp_remote_* call.
	 * @return array|WP_Error
	 */
	private static function parse_response( $response ) {
		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$status = (int) wp_remote_retrieve_response_code( $response );
		$raw    = wp_remote_retrieve_body( $response );
		$body   = json_decode( $raw, true );
		if ( null === $body && strlen( (string) $raw ) > 0 ) {
			$body = [ 'raw' => $raw ];
		}

		return [
			'status' => $status,
			'body'   => is_array( $body ) ? $body : [],
		];
	}

	/**
	 * Build a multipart text field.
	 *
	 * @param string $boundary Boundary.
	 * @param string $name     Field name.
	 * @param string $value    Field value.
	 * @return string
	 */
	private static function form_field( $boundary, $name, $value ) {
		return "--{$boundary}\r\n"
			. 'Content-Disposition: form-data; name="' . $name . "\"\r\n\r\n"
			. $value . "\r\n";
	}

	/**
	 * Build a multipart file field.
	 *
	 * @param string $boundary Boundary.
	 * @param string $name     Field name.
	 * @param string $filename Filename in the multipart part.
	 * @param string $mime     MIME type.
	 * @param string $bytes    File bytes.
	 * @return string
	 */
	private static function form_file( $boundary, $name, $filename, $mime, $bytes ) {
		return "--{$boundary}\r\n"
			. 'Content-Disposition: form-data; name="' . $name . '"; filename="' . $filename . "\"\r\n"
			. 'Content-Type: ' . $mime . "\r\n\r\n"
			. $bytes . "\r\n";
	}
}
