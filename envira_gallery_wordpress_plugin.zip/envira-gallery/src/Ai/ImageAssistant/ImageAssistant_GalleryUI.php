<?php
/**
 * Injects the bulk control above the gallery image list and exposes the
 * gallery name + count to JS. Per-image sparkle triggers are added by JS
 * directly onto each <li data-envira-gallery-image="..."> element because
 * the gallery output renders/re-renders dynamically and a server-side
 * filter would miss images added after page load.
 *
 * @package Envira Gallery
 * @since 1.13.6
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ImageAssistant_GalleryUI
 */
class ImageAssistant_GalleryUI {

	/**
	 * Wire hooks.
	 */
	public function hooks() {
		add_action( 'envira_gallery_intro_actions', [ $this, 'inject_bulk_toolbar' ], 5, 1 );
	}

	/**
	 * Inject the bulk toolbar above the image list. The "Bulk Image Assistant"
	 * button carries everything the modal needs: gallery id, gallery name, and
	 * the source selector that resolves to selected <li> ids.
	 *
	 * @param WP_Post $post Current gallery post.
	 */
	public function inject_bulk_toolbar( $post ) {
		if ( ! ImageAssistant_License::is_eligible() ) {
			return;
		}
		$post_id   = $post ? (int) $post->ID : 0;
		$gallery_n = $post ? (string) $post->post_title : '';
		?>
		<div class="envira-ia envira-ia-toolbar">
			<button type="button"
				class="envira-ia-bulk"
				disabled
				data-source="#envira-gallery-output li.envira-gallery-image.selected"
				data-gallery-id="<?php echo esc_attr( $post_id ); ?>"
				data-gallery-name="<?php echo esc_attr( $gallery_n ); ?>">
				<span class="envira-ia-sparkle"></span>
				<?php esc_html_e( 'Bulk Image Assistant', 'envira-gallery' ); ?>
			</button>
		</div>
		<?php
	}
}
