<?php
/**
 * REST controller for the AI Image Assistant.
 *
 * Namespace: envira-ai/v1
 * Base:      image-assistant/
 *
 * Routes:
 *   GET    /image-assistant/health
 *   GET    /image-assistant/balance
 *   GET    /image-assistant/settings
 *   POST   /image-assistant/settings
 *   POST   /image-assistant/generate          { attachment_id, tone?, fields?, existing_title? }
 *   POST   /image-assistant/cleanup-titles    { attachment_ids }
 *   POST   /image-assistant/bulk/start        { attachment_ids[], tone?, fields? }
 *   GET    /image-assistant/bulk/(?P<job_id>[a-f0-9-]+)
 *
 * @package Envira Gallery
 * @since 1.13.6
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ImageAssistant_REST
 */
class ImageAssistant_REST extends WP_REST_Controller {

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->namespace = 'envira-ai/v1';
		$this->rest_base = 'image-assistant';
	}

	/**
	 * Register hooks.
	 */
	public function hooks() {
		add_action( 'rest_api_init', [ $this, 'register_routes' ] );
	}

	/**
	 * Register routes.
	 */
	public function register_routes() {
		$base = '/' . $this->rest_base;

		register_rest_route(
			$this->namespace,
			$base . '/health',
			[
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => [ $this, 'route_health' ],
				'permission_callback' => [ $this, 'permission_manage' ],
			]
		);

		register_rest_route(
			$this->namespace,
			$base . '/tones',
			[
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => [ $this, 'route_tones' ],
				'permission_callback' => [ $this, 'permission_manage' ],
			]
		);

		register_rest_route(
			$this->namespace,
			$base . '/balance',
			[
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => [ $this, 'route_balance' ],
				'permission_callback' => [ $this, 'permission_manage' ],
			]
		);

		register_rest_route(
			$this->namespace,
			$base . '/settings',
			[
				[
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => [ $this, 'route_settings_get' ],
					'permission_callback' => [ $this, 'permission_manage' ],
				],
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'route_settings_post' ],
					'permission_callback' => [ $this, 'permission_manage' ],
				],
			]
		);

		register_rest_route(
			$this->namespace,
			$base . '/generate',
			[
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => [ $this, 'route_generate' ],
				'permission_callback' => [ $this, 'permission_edit_attachment' ],
				'args'                => [
					'attachment_id'  => [
						'required' => true,
						'type'     => 'integer',
					],
					'tone'           => [ 'type' => 'string' ],
					'fields'         => [ 'type' => 'array' ],
					'existing_title' => [ 'type' => 'string' ],
				],
			]
		);

		// Preview: generate suggestions WITHOUT applying them. Charges 1 credit.
		register_rest_route(
			$this->namespace,
			$base . '/generate-preview',
			[
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => [ $this, 'route_generate_preview' ],
				'permission_callback' => [ $this, 'permission_edit_attachment' ],
				'args'                => [
					'attachment_id'  => [
						'required' => true,
						'type'     => 'integer',
					],
					'tone'           => [ 'type' => 'string' ],
					'fields'         => [ 'type' => 'array' ],
					'existing_title' => [ 'type' => 'string' ],
				],
			]
		);

		// Apply selected fields from a previous preview. No credits charged.
		register_rest_route(
			$this->namespace,
			$base . '/apply-fields',
			[
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => [ $this, 'route_apply_fields' ],
				'permission_callback' => [ $this, 'permission_edit_attachment' ],
				'args'                => [
					'attachment_id' => [
						'required' => true,
						'type'     => 'integer',
					],
					'metadata'      => [
						'required' => true,
						'type'     => 'object',
					],
				],
			]
		);

		// Regenerate a single field. Charges 1 credit per call (no free window yet).
		register_rest_route(
			$this->namespace,
			$base . '/regenerate-field',
			[
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => [ $this, 'route_regenerate_field' ],
				'permission_callback' => [ $this, 'permission_edit_attachment' ],
				'args'                => [
					'attachment_id' => [
						'required' => true,
						'type'     => 'integer',
					],
					'field'         => [
						'required' => true,
						'type'     => 'string',
					],
					'tone'          => [ 'type' => 'string' ],
				],
			]
		);

		register_rest_route(
			$this->namespace,
			$base . '/gallery-description',
			[
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => [ $this, 'route_gallery_description' ],
				'permission_callback' => [ $this, 'permission_manage' ],
				'args'                => [
					'gallery_id' => [
						'required' => true,
						'type'     => 'integer',
					],
					'tone'       => [ 'type' => 'string' ],
					'apply'      => [ 'type' => 'boolean' ],
				],
			]
		);

		register_rest_route(
			$this->namespace,
			$base . '/cleanup-titles',
			[
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => [ $this, 'route_cleanup_titles' ],
				'permission_callback' => [ $this, 'permission_manage' ],
				'args'                => [
					'attachment_ids' => [
						'required' => true,
						'type'     => 'array',
					],
				],
			]
		);

		register_rest_route(
			$this->namespace,
			$base . '/bulk/start',
			[
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => [ $this, 'route_bulk_start' ],
				'permission_callback' => [ $this, 'permission_manage' ],
				'args'                => [
					'attachment_ids'   => [
						'required' => true,
						'type'     => 'array',
					],
					'tone'             => [ 'type' => 'string' ],
					'fields'           => [ 'type' => 'array' ],
					'gallery_id'       => [ 'type' => 'integer' ],
					'skip_if_existing' => [ 'type' => 'boolean' ],
				],
			]
		);

		// Registered before the {job_id} route so "active" is never captured as
		// a job id (it also contains non-hex chars, but order keeps it clear).
		register_rest_route(
			$this->namespace,
			$base . '/bulk/active',
			[
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => [ $this, 'route_bulk_active' ],
				'permission_callback' => [ $this, 'permission_manage' ],
				'args'                => [
					'gallery_id' => [ 'type' => 'integer' ],
				],
			]
		);

		register_rest_route(
			$this->namespace,
			$base . '/auto-status',
			[
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => [ $this, 'route_auto_status' ],
				'permission_callback' => [ $this, 'permission_manage' ],
				'args'                => [
					'ids'  => [ 'type' => 'string' ],
					'kick' => [ 'type' => 'boolean' ],
				],
			]
		);

		register_rest_route(
			$this->namespace,
			$base . '/bulk/(?P<job_id>[a-f0-9-]+)',
			[
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => [ $this, 'route_bulk_status' ],
				'permission_callback' => [ $this, 'permission_manage' ],
				'args'                => [
					'job_id' => [
						'required' => true,
						'type'     => 'string',
					],
				],
			]
		);

		register_rest_route(
			$this->namespace,
			$base . '/bulk/(?P<job_id>[a-f0-9-]+)/cancel',
			[
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => [ $this, 'route_bulk_cancel' ],
				'permission_callback' => [ $this, 'permission_manage' ],
				'args'                => [
					'job_id' => [
						'required' => true,
						'type'     => 'string',
					],
				],
			]
		);
	}

	/* ─── Permission callbacks ──────────────────────────────────────────── */

	/**
	 * Manage permission — any user with edit_posts.
	 *
	 * @return bool|WP_Error
	 */
	public function permission_manage() {
		$cap = apply_filters( 'envira_ai_image_assistant_capability', 'edit_posts' );
		if ( ! is_user_logged_in() ) {
			return new WP_Error( 'rest_forbidden', __( 'Authentication required.', 'envira-gallery' ), [ 'status' => 401 ] );
		}
		if ( ! current_user_can( $cap ) ) {
			return new WP_Error( 'rest_forbidden', __( 'Insufficient permissions.', 'envira-gallery' ), [ 'status' => 403 ] );
		}
		return true;
	}

	/**
	 * Edit-attachment permission for per-image actions.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return bool|WP_Error
	 */
	public function permission_edit_attachment( $request ) {
		$base = $this->permission_manage();
		if ( is_wp_error( $base ) || true !== $base ) {
			return $base;
		}
		$attachment_id = (int) $request->get_param( 'attachment_id' );
		if ( $attachment_id > 0 && ! current_user_can( 'edit_post', $attachment_id ) ) {
			return new WP_Error( 'rest_forbidden', __( 'You cannot edit this attachment.', 'envira-gallery' ), [ 'status' => 403 ] );
		}
		return true;
	}

	/* ─── Route handlers ────────────────────────────────────────────────── */

	/**
	 * GET /image-assistant/health
	 */
	public function route_health() {
		$license_ok = ImageAssistant_License::is_eligible();
		$service    = ImageAssistant_Worker_Client::health();

		return rest_ensure_response(
			[
				'license_eligible' => $license_ok,
				'plan'             => ImageAssistant_License::get_plan_type(),
				'tags_taxonomy'    => taxonomy_exists( 'envira-tag' ),
				'service'          => is_wp_error( $service )
					? [
						'status'  => 'unreachable',
						'message' => $service->get_error_message(),
					]
					: ( is_array( $service ) ? $service['body'] : null ),
			]
		);
	}

	/**
	 * GET /image-assistant/tones — list of {slug, label, description}.
	 */
	public function route_tones() {
		$result = ImageAssistant_Worker_Client::tones();
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		return rest_ensure_response( isset( $result['body'] ) ? $result['body'] : [ 'tones' => [] ] );
	}

	/**
	 * GET /image-assistant/balance
	 */
	public function route_balance() {
		$license_key = ImageAssistant_License::get_key();
		if ( empty( $license_key ) ) {
			return new WP_Error( 'no_license', __( 'No active Envira license found.', 'envira-gallery' ), [ 'status' => 400 ] );
		}
		$result = ImageAssistant_Worker_Client::balance( $license_key, 'envira' );
		if ( is_wp_error( $result ) ) {
			// A transport WP_Error message can contain the internal Worker
			// hostname (e.g. "cURL error 6: Could not resolve host: …workers.dev").
			// Log it server-side, but return a clean, hostname-free message so
			// internal infrastructure never surfaces in the admin UI.
			error_log( '[envira-ai-image] balance fetch failed: ' . $result->get_error_message() );
			return new WP_Error(
				'balance_unavailable',
				__( 'Could not reach the AI credits service. Please try again shortly.', 'envira-gallery' ),
				[ 'status' => 503 ]
			);
		}
		// Return the balance body directly (not the internal { status, body }
		// transport wrapper), matching route_tones() so every endpoint exposes a
		// consistent shape to REST clients.
		return rest_ensure_response( isset( $result['body'] ) ? $result['body'] : [] );
	}

	/**
	 * GET /image-assistant/settings
	 */
	public function route_settings_get() {
		return rest_ensure_response( ImageAssistant_Settings::get_all() );
	}

	/**
	 * POST /image-assistant/settings
	 *
	 * @param WP_REST_Request $request Request.
	 */
	public function route_settings_post( $request ) {
		$saved = ImageAssistant_Settings::update( $request->get_params() );
		return rest_ensure_response( $saved );
	}

	/**
	 * POST /image-assistant/generate
	 *
	 * @param WP_REST_Request $request Request.
	 */
	public function route_generate( $request ) {
		$attachment_id  = (int) $request->get_param( 'attachment_id' );
		$tone           = (string) $request->get_param( 'tone' );
		$fields         = (array) $request->get_param( 'fields' );
		$existing_title = $request->get_param( 'existing_title' );

		$defaults = ImageAssistant_Settings::get_all();
		if ( empty( $tone ) ) {
			$tone = $defaults['default_tone'];
		}
		if ( empty( $fields ) ) {
			$fields = $defaults['default_fields'];
		}

		$result = self::process_single_attachment( $attachment_id, $tone, $fields, 'rest', is_string( $existing_title ) ? $existing_title : null );
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		return rest_ensure_response( $result );
	}

	/**
	 * POST /image-assistant/generate-preview
	 *
	 * Runs the same Worker call as /generate but does NOT write the result to
	 * the attachment. The caller is expected to follow up with /apply-fields
	 * after the user reviews the suggestions in the modal UI.
	 *
	 * @param WP_REST_Request $request Request.
	 */
	public function route_generate_preview( $request ) {
		$attachment_id  = (int) $request->get_param( 'attachment_id' );
		$tone           = (string) $request->get_param( 'tone' );
		$fields         = (array) $request->get_param( 'fields' );
		$existing_title = $request->get_param( 'existing_title' );

		$defaults = ImageAssistant_Settings::get_all();
		if ( empty( $tone ) ) {
			$tone = $defaults['default_tone'];
		}
		if ( empty( $fields ) ) {
			$fields = $defaults['default_fields'];
		}

		// Salt the prefix per call — different field-set choices on the same
		// attachment/user must not share an idempotency key (the credits Worker
		// would 409 with `idempotency_conflict` on a request-hash mismatch).
		$prefix = 'preview-' . wp_generate_password( 8, false );
		$result = self::process_single_attachment(
			$attachment_id,
			$tone,
			$fields,
			$prefix,
			is_string( $existing_title ) ? $existing_title : null,
			/* apply */ false
		);
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		return rest_ensure_response( $result );
	}

	/**
	 * POST /image-assistant/apply-fields
	 *
	 * Writes the supplied metadata fields onto an attachment without calling
	 * the AI service. Used after /generate-preview when the user clicks
	 * "Accept" on individual fields or "Accept All" in the modal.
	 *
	 * @param WP_REST_Request $request Request.
	 */
	public function route_apply_fields( $request ) {
		$attachment_id = (int) $request->get_param( 'attachment_id' );
		$metadata      = (array) $request->get_param( 'metadata' );
		if ( empty( $metadata ) ) {
			return new WP_Error( 'empty_metadata', __( 'No fields supplied to apply.', 'envira-gallery' ), [ 'status' => 400 ] );
		}
		$result = ImageAssistant_Metadata_Applier::apply( $attachment_id, $metadata, array_keys( $metadata ) );
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		return rest_ensure_response( $result );
	}

	/**
	 * POST /image-assistant/regenerate-field
	 *
	 * Re-runs the Worker for a single field and returns the new suggestion
	 * without applying it. Charges 1 credit per call.
	 *
	 * @param WP_REST_Request $request Request.
	 */
	public function route_regenerate_field( $request ) {
		$attachment_id = (int) $request->get_param( 'attachment_id' );
		$field         = (string) $request->get_param( 'field' );
		$tone          = (string) $request->get_param( 'tone' );

		$valid_fields = [ 'alt_text', 'title', 'caption', 'description', 'tags', 'cleaned_title' ];
		if ( ! in_array( $field, $valid_fields, true ) ) {
			return new WP_Error( 'invalid_field', __( 'Unknown field.', 'envira-gallery' ), [ 'status' => 400 ] );
		}
		// Backstop: the UI never offers a tags regenerate when the Tags addon is
		// inactive, but reject it explicitly here in case of a direct API call.
		if ( 'tags' === $field && ! taxonomy_exists( 'envira-tag' ) ) {
			return new WP_Error( 'tags_unavailable', __( 'AI tags require the Envira Tags addon, which is not active.', 'envira-gallery' ), [ 'status' => 400 ] );
		}

		$defaults = ImageAssistant_Settings::get_all();
		if ( empty( $tone ) ) {
			$tone = $defaults['default_tone'];
		}

		// Use a salted prefix so retries within the same session don't collide
		// with the original /generate-preview idempotency-key.
		$prefix = 'regen-' . $field . '-' . wp_generate_password( 8, false );

		$result = self::process_single_attachment(
			$attachment_id,
			$tone,
			[ $field ],
			$prefix,
			null,
			/* apply */ false
		);
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		// Return only the requested field's suggestion alongside the credit info.
		$generated = isset( $result['generated'] ) ? (array) $result['generated'] : [];
		return rest_ensure_response(
			[
				'attachment_id' => $attachment_id,
				'field'         => $field,
				'value'         => $generated[ $field ] ?? null,
				'credits'       => $result['credits'] ?? null,
				'provider'      => $result['provider'] ?? null,
			]
		);
	}

	/**
	 * POST /image-assistant/gallery-description
	 *
	 * Generates a 2–3 sentence description of an Envira gallery as a whole.
	 * Samples up to 25 attachments (title + alt + caption) and forwards them
	 * to the Worker's text-only gallery-description endpoint. When `apply` is
	 * true (default), stores it in the gallery config
	 * (_eg_gallery_data['config']['description']) — the Description the settings
	 * metabox edits and the frontend renders — and flushes the gallery cache.
	 *
	 * @param WP_REST_Request $request Request.
	 */
	public function route_gallery_description( $request ) {
		$gallery_id = (int) $request->get_param( 'gallery_id' );
		if ( $gallery_id <= 0 ) {
			return new WP_Error( 'invalid_gallery', __( 'Invalid gallery ID.', 'envira-gallery' ), [ 'status' => 400 ] );
		}
		$gallery = get_post( $gallery_id );
		if ( ! $gallery || 'envira' !== $gallery->post_type ) {
			return new WP_Error( 'not_gallery', __( 'Not an Envira gallery.', 'envira-gallery' ), [ 'status' => 400 ] );
		}
		if ( ! current_user_can( 'edit_post', $gallery_id ) ) {
			return new WP_Error( 'rest_forbidden', __( 'You cannot edit this gallery.', 'envira-gallery' ), [ 'status' => 403 ] );
		}

		$license_key = ImageAssistant_License::get_key();
		if ( empty( $license_key ) ) {
			return new WP_Error( 'no_license', __( 'No active Envira license found.', 'envira-gallery' ), [ 'status' => 400 ] );
		}

		$defaults = ImageAssistant_Settings::get_all();
		$tone     = $request->get_param( 'tone' );
		if ( empty( $tone ) || ! is_string( $tone ) ) {
			$tone = $defaults['default_tone'];
		}

		// Sample the gallery's images (title/alt/caption from the config image
		// list) and ask the Worker. Shared with the auto-generate-on-save path.
		$response = ImageAssistant_Gallery_Description::request( $gallery_id, (string) $tone );

		if ( is_wp_error( $response ) ) {
			// Preserve a 400 status for the empty-gallery case surfaced in the editor.
			if ( 'empty_gallery' === $response->get_error_code() || 'not_gallery' === $response->get_error_code() ) {
				return new WP_Error( $response->get_error_code(), $response->get_error_message(), [ 'status' => 400 ] );
			}
			return $response;
		}
		$mapped = self::map_worker_error( $response );
		if ( is_wp_error( $mapped ) ) {
			return $mapped;
		}

		$description = isset( $response['body']['description'] ) ? (string) $response['body']['description'] : '';
		$apply       = null === $request->get_param( 'apply' ) ? true : (bool) $request->get_param( 'apply' );
		$applied     = false;

		if ( $apply && '' !== $description ) {
			// Store it in the gallery config (the Configuration-tab "Gallery
			// Description" field the frontend renders) and flush the cache.
			ImageAssistant_Gallery_Description::apply( $gallery_id, $description );
			$applied = true;
		}

		return rest_ensure_response(
			[
				'gallery_id'  => $gallery_id,
				'description' => $description,
				'applied'     => $applied,
				'credits'     => isset( $response['body']['credits'] ) ? $response['body']['credits'] : null,
				'provider'    => isset( $response['body']['provider'] ) ? $response['body']['provider'] : null,
			]
		);
	}

	/**
	 * POST /image-assistant/cleanup-titles
	 *
	 * @param WP_REST_Request $request Request.
	 */
	public function route_cleanup_titles( $request ) {
		$attachment_ids = array_values( array_filter( array_map( 'absint', (array) $request->get_param( 'attachment_ids' ) ) ) );
		if ( empty( $attachment_ids ) ) {
			return new WP_Error( 'empty', __( 'No attachments selected.', 'envira-gallery' ), [ 'status' => 400 ] );
		}
		if ( count( $attachment_ids ) > 25 ) {
			$attachment_ids = array_slice( $attachment_ids, 0, 25 );
		}

		$license_key = ImageAssistant_License::get_key();
		if ( empty( $license_key ) ) {
			return new WP_Error( 'no_license', __( 'No active Envira license found.', 'envira-gallery' ), [ 'status' => 400 ] );
		}

		$titles = [];
		foreach ( $attachment_ids as $id ) {
			$post = get_post( $id );
			if ( ! $post || 'attachment' !== $post->post_type ) {
				continue;
			}
			if ( ! current_user_can( 'edit_post', $id ) ) {
				continue;
			}
			$titles[ $id ] = (string) $post->post_title;
		}

		if ( empty( $titles ) ) {
			return new WP_Error( 'empty', __( 'No valid attachments to clean.', 'envira-gallery' ), [ 'status' => 400 ] );
		}

		$idempotency_key = self::build_idempotency_key( 'cleanup-titles', md5( implode( ',', array_keys( $titles ) ) ) );

		$response = ImageAssistant_Worker_Client::cleanup_titles(
			[
				'license_key'     => $license_key,
				'product'         => 'envira',
				'titles'          => array_values( $titles ),
				'idempotency_key' => $idempotency_key,
			]
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$mapped = self::map_worker_error( $response );
		if ( is_wp_error( $mapped ) ) {
			return $mapped;
		}

		$cleaned_titles = isset( $response['body']['titles'] ) && is_array( $response['body']['titles'] )
			? $response['body']['titles']
			: [];

		$applied = [];
		$ids     = array_keys( $titles );
		foreach ( $cleaned_titles as $i => $cleaned ) {
			if ( ! isset( $ids[ $i ] ) ) {
				continue;
			}
			$id      = (int) $ids[ $i ];
			$cleaned = sanitize_text_field( (string) $cleaned );
			if ( $cleaned === $titles[ $id ] ) {
				continue;
			}
			$update_result = wp_update_post(
				[
					'ID'         => $id,
					'post_title' => $cleaned,
				],
				true
			);
			if ( ! is_wp_error( $update_result ) ) {
				$applied[ $id ] = $cleaned;
			}
		}

		return rest_ensure_response(
			[
				'applied' => $applied,
				'credits' => isset( $response['body']['credits'] ) ? $response['body']['credits'] : null,
			]
		);
	}

	/**
	 * POST /image-assistant/bulk/start
	 *
	 * @param WP_REST_Request $request Request.
	 */
	public function route_bulk_start( $request ) {
		$ids              = array_values( array_filter( array_map( 'absint', (array) $request->get_param( 'attachment_ids' ) ) ) );
		$tone             = (string) $request->get_param( 'tone' );
		$fields           = (array) $request->get_param( 'fields' );
		$gallery_id       = (int) $request->get_param( 'gallery_id' );
		$skip_if_existing = (bool) $request->get_param( 'skip_if_existing' );

		// Per-attachment permission check.
		$ids = array_values(
			array_filter(
				$ids,
				function ( $id ) {
					return current_user_can( 'edit_post', $id );
				}
			)
		);

		$defaults = ImageAssistant_Settings::get_all();
		if ( empty( $tone ) ) {
			$tone = $defaults['default_tone'];
		}
		if ( empty( $fields ) ) {
			$fields = $defaults['default_fields'];
		}
		// The settings tab carries the org-wide "skip if existing" default — apply
		// it only when the request didn't already opt one way or the other.
		if ( null === $request->get_param( 'skip_if_existing' ) ) {
			$skip_if_existing = ! empty( $defaults['overwrite_behavior'] );
		}

		// Don't start a batch when the account is out of credits. Otherwise the job
		// starts, every image 402s, and it "completes" having generated nothing —
		// which reads to the user as success. Checked here so the client gets an
		// immediate, clear out-of-credits response. Fail OPEN on a balance read
		// error (transient outage) so a blip can't block legitimate batches; the
		// per-image worker calls still enforce credits authoritatively.
		$balance = ImageAssistant_Worker_Client::balance( ImageAssistant_License::get_key(), 'envira' );
		if ( ! is_wp_error( $balance ) && ! empty( $balance['body'] ) && is_array( $balance['body'] ) ) {
			$body      = $balance['body'];
			$unlimited = ! empty( $body['is_unlimited'] );
			$remaining = isset( $body['total_remaining'] ) ? (int) $body['total_remaining'] : null;
			if ( ! $unlimited && null !== $remaining && $remaining <= 0 ) {
				return new WP_Error(
					'credits_exhausted',
					__( "You're out of AI credits. Purchase more credits to run the Bulk Image Assistant.", 'envira-gallery' ),
					[ 'status' => 402 ]
				);
			}
		}

		$result = ImageAssistant_Bulk_Scheduler::start( $ids, $tone, $fields, $gallery_id, $skip_if_existing );
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		return rest_ensure_response( $result );
	}

	/**
	 * POST /image-assistant/bulk/{job_id}/cancel
	 *
	 * @param WP_REST_Request $request Request.
	 */
	public function route_bulk_cancel( $request ) {
		$job_id = (string) $request->get_param( 'job_id' );
		$state  = ImageAssistant_Bulk_Scheduler::read_state( $job_id );
		if ( null === $state ) {
			return new WP_Error( 'cancel_failed', __( 'Job not found or already finished.', 'envira-gallery' ), [ 'status' => 404 ] );
		}
		// IDOR guard: cancelling someone else's running job is a real DoS vector.
		if ( ! ImageAssistant_Bulk_Scheduler::user_can_access_job( $state ) ) {
			return new WP_Error( 'rest_forbidden', __( 'You cannot cancel this job.', 'envira-gallery' ), [ 'status' => 403 ] );
		}
		$ok = ImageAssistant_Bulk_Scheduler::cancel( $job_id );
		if ( ! $ok ) {
			return new WP_Error( 'cancel_failed', __( 'Job is already finished.', 'envira-gallery' ), [ 'status' => 409 ] );
		}
		return rest_ensure_response( ImageAssistant_Bulk_Scheduler::read_state( $job_id ) );
	}

	/**
	 * GET /image-assistant/bulk/{job_id}
	 *
	 * @param WP_REST_Request $request Request.
	 */
	public function route_bulk_status( $request ) {
		$job_id = (string) $request->get_param( 'job_id' );
		$state  = ImageAssistant_Bulk_Scheduler::read_state( $job_id );
		if ( null === $state ) {
			return new WP_Error( 'not_found', __( 'Job not found or expired.', 'envira-gallery' ), [ 'status' => 404 ] );
		}
		// IDOR guard: the UUID is not an access boundary — non-owners must not
		// be able to poll another user's job state (errors, attachment ids,
		// credit balance). Site admins are still allowed for support workflows.
		if ( ! ImageAssistant_Bulk_Scheduler::user_can_access_job( $state ) ) {
			return new WP_Error( 'rest_forbidden', __( 'You cannot access this job.', 'envira-gallery' ), [ 'status' => 403 ] );
		}
		// Drive the queue forward while the client polls. In environments where
		// Action Scheduler's background runner can't fire promptly (cron off /
		// loopback blocked) the job would otherwise sit idle and the progress bar
		// would never move; this processes a bounded slice per poll. Re-read the
		// state afterwards so the response reflects what was just processed.
		if ( 'running' === ( $state['status'] ?? '' ) ) {
			ImageAssistant_Bulk_Scheduler::run_due_actions();
			$refreshed = ImageAssistant_Bulk_Scheduler::read_state( $job_id );
			if ( is_array( $refreshed ) ) {
				$state = $refreshed;
			}
		}
		return rest_ensure_response( $state );
	}

	/**
	 * GET /image-assistant/bulk/active
	 *
	 * Report the current user's still-running bulk job for a gallery, so a
	 * freshly-loaded editor can restore the in-progress indicator (the client's
	 * job handle is lost on reload, but the job keeps running server-side).
	 *
	 * @param WP_REST_Request $request Request.
	 */
	public function route_bulk_active( $request ) {
		$gallery_id = (int) $request->get_param( 'gallery_id' );
		$state      = ImageAssistant_Bulk_Scheduler::find_active_for_user( $gallery_id );
		if ( ! is_array( $state ) ) {
			return rest_ensure_response( [ 'active' => false ] );
		}
		$gid = (int) ( $state['gallery_id'] ?? 0 );
		return rest_ensure_response(
			[
				'active'         => true,
				'job_id'         => (string) ( $state['job_id'] ?? '' ),
				'gallery_id'     => $gid,
				'gallery_name'   => $gid ? (string) get_the_title( $gid ) : '',
				'attachment_ids' => array_values( array_map( 'intval', (array) ( $state['attachment_ids'] ?? [] ) ) ),
				'state'          => $state,
			]
		);
	}

	/**
	 * GET /image-assistant/auto-status?ids=1,2,3
	 *
	 * Report auto-on-upload generation status for the given attachments so the
	 * gallery editor can show a "Generating…" badge and patch each item the
	 * moment it's ready. Also nudges the queue forward (see route_bulk_status).
	 *
	 * @param WP_REST_Request $request Request.
	 */
	public function route_auto_status( $request ) {
		$ids = array_slice(
			array_values( array_filter( array_map( 'absint', explode( ',', (string) $request->get_param( 'ids' ) ) ) ) ),
			0,
			200
		);
		if ( empty( $ids ) ) {
			return rest_ensure_response( [ 'items' => (object) [] ] );
		}

		// Drive pending auto actions forward — but NOT on the first read. The
		// runner executes a queued generation synchronously (a few seconds)
		// before returning, so kicking on the first poll would collapse the
		// "pending" state to "done" before the client ever shows the spinner.
		// The client requests kick=0 first (just read → spinner appears) and
		// kick=1 thereafter (run the queue → completes).
		$kick = null === $request->get_param( 'kick' ) ? true : (bool) $request->get_param( 'kick' );
		if ( $kick ) {
			ImageAssistant_Bulk_Scheduler::run_due_actions();
		}

		$items = [];
		foreach ( $ids as $id ) {
			if ( ! current_user_can( 'edit_post', $id ) ) {
				continue;
			}
			$marker = ImageAssistant_Bulk_Scheduler::get_auto_marker( $id );
			if ( null !== $marker ) {
				$items[ (string) $id ] = $marker;
			}
		}
		return rest_ensure_response( [ 'items' => empty( $items ) ? (object) [] : $items ] );
	}

	/* ─── Core processing ───────────────────────────────────────────────── */

	/**
	 * Run a single attachment through the Worker and (optionally) apply the result.
	 *
	 * Shared by the per-image REST endpoint and the bulk Action Scheduler worker.
	 * When `$apply` is false, the suggestions are returned but NOT written to the
	 * attachment — used by the preview / regenerate-field flows so the user can
	 * accept or reject before any DB writes happen.
	 *
	 * @param int    $attachment_id  Attachment ID.
	 * @param string $tone           Tone slug.
	 * @param array  $fields         Fields.
	 * @param string $idem_prefix    Idempotency-key prefix.
	 * @param string $existing_title Optional override.
	 * @param bool   $apply          Apply the result to the attachment when true (default).
	 * @return array|WP_Error
	 */
	public static function process_single_attachment( $attachment_id, $tone, $fields, $idem_prefix = 'rest', $existing_title = null, $apply = true ) {
		$attachment_id = (int) $attachment_id;
		if ( $attachment_id <= 0 ) {
			return new WP_Error( 'invalid_attachment', __( 'Invalid attachment ID.', 'envira-gallery' ), [ 'status' => 400 ] );
		}

		// Backstop: never ask the Worker for tags when the taxonomy is missing —
		// they'd be generated, charged, then dropped by the applier. The UI
		// already hides tag controls in this state; this guards direct API use.
		$fields = (array) $fields;
		if ( ! taxonomy_exists( 'envira-tag' ) ) {
			$fields = array_values(
				array_filter(
					$fields,
					function ( $f ) {
						return 'tags' !== $f;
					}
				)
			);
			if ( empty( $fields ) ) {
				return new WP_Error( 'tags_unavailable', __( 'AI tags require the Envira Tags addon, which is not active.', 'envira-gallery' ), [ 'status' => 400 ] );
			}
		}

		$post = get_post( $attachment_id );
		if ( ! $post || 'attachment' !== $post->post_type ) {
			return new WP_Error( 'not_attachment', __( 'Not an attachment.', 'envira-gallery' ), [ 'status' => 400 ] );
		}

		$file = get_attached_file( $attachment_id );
		if ( ! $file || ! is_readable( $file ) ) {
			return new WP_Error( 'file_unreadable', __( 'Could not read attachment file.', 'envira-gallery' ), [ 'status' => 500 ] );
		}

		$mime = (string) get_post_mime_type( $attachment_id );
		if ( ! in_array( $mime, [ 'image/jpeg', 'image/png', 'image/webp', 'image/gif' ], true ) ) {
			return new WP_Error( 'unsupported_mime', __( 'Image type not supported.', 'envira-gallery' ), [ 'status' => 400 ] );
		}

		// Prefer a smaller, already-generated intermediate size over the full
		// original. WordPress creates these on upload, so there's no resize cost
		// here — we just send fewer bytes to the Worker and to Anthropic (which
		// downscales to ~1.15MP anyway), cutting latency and token cost with no
		// quality loss for alt-text/tagging. Falls back to the original when no
		// intermediate exists (tiny images, non-standard uploads).
		$source = self::select_source_image( $attachment_id, $file, $mime );

		$license_key = ImageAssistant_License::get_key();
		if ( empty( $license_key ) ) {
			return new WP_Error( 'no_license', __( 'No active Envira license found.', 'envira-gallery' ), [ 'status' => 400 ] );
		}

		$idempotency_key = self::build_idempotency_key( $idem_prefix, (string) $attachment_id );

		$title_for_ctx = $existing_title ?? (string) $post->post_title;
		$context       = [];
		if ( $post->post_parent ) {
			$parent = get_post( $post->post_parent );
			if ( $parent && 'envira' === $parent->post_type ) {
				$context['gallery_name'] = $parent->post_title;
				$context['gallery_id']   = (int) $parent->ID;
			}
		}

		$response = ImageAssistant_Worker_Client::generate(
			[
				'license_key'     => $license_key,
				'product'         => 'envira',
				'tone'            => $tone,
				'fields'          => $fields,
				'existing_title'  => $title_for_ctx,
				'context'         => $context,
				'image_path'      => $source['path'],
				'image_mime'      => $source['mime'],
				'image_filename'  => wp_basename( $source['path'] ),
				'idempotency_key' => $idempotency_key,
			]
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$mapped = self::map_worker_error( $response );
		if ( is_wp_error( $mapped ) ) {
			return $mapped;
		}

		$applied_result = $apply
			? ImageAssistant_Metadata_Applier::apply( $attachment_id, $response['body'], $fields )
			: [
				'applied' => [],
				'skipped' => [],
			];
		if ( is_wp_error( $applied_result ) ) {
			return $applied_result;
		}

		return [
			'attachment_id' => $attachment_id,
			'generated'     => array_intersect_key(
				$response['body'],
				array_flip( [ 'alt_text', 'title', 'caption', 'description', 'tags', 'cleaned_title' ] )
			),
			'applied'       => $applied_result['applied'] ?? [],
			'skipped'       => $applied_result['skipped'] ?? [],
			'credits'       => isset( $response['body']['credits'] ) ? $response['body']['credits'] : null,
			'provider'      => isset( $response['body']['provider'] ) ? $response['body']['provider'] : null,
		];
	}

	/* ─── Helpers ───────────────────────────────────────────────────────── */

	/**
	 * Pick the smallest already-generated image WordPress has that is still big
	 * enough for good AI analysis, falling back to the full original.
	 *
	 * WordPress generates intermediate sizes at upload time, so reusing one
	 * costs no resize work here and sends far fewer bytes to the Worker and to
	 * Anthropic (which downscales to ~1.15MP regardless). For alt-text/tagging
	 * a 768–1024px image is more than enough.
	 *
	 * Preference order is filterable via `envira_ai_image_source_sizes`. The
	 * default skips tiny sizes (thumbnail/medium at ≤300px) that would hurt
	 * recognition quality.
	 *
	 * @param int    $attachment_id Attachment ID.
	 * @param string $original_path Absolute path to the full original.
	 * @param string $original_mime Original MIME type.
	 * @return array{path:string,mime:string} Chosen image path + MIME.
	 */
	private static function select_source_image( $attachment_id, $original_path, $original_mime ) {
		$sizes = apply_filters(
			'envira_ai_image_source_sizes',
			[ 'large', 'medium_large' ],
			$attachment_id
		);

		$dir = trailingslashit( dirname( $original_path ) );

		foreach ( (array) $sizes as $size ) {
			$data = image_get_intermediate_size( $attachment_id, $size );
			if ( ! is_array( $data ) || empty( $data['file'] ) ) {
				continue;
			}
			$path = $dir . wp_basename( $data['file'] );
			if ( ! is_readable( $path ) ) {
				continue;
			}
			// Derive the MIME from the actual intermediate file — a site may
			// generate intermediates in a different format (e.g. WebP) than the
			// original. Skip anything the Worker won't accept.
			$type = wp_check_filetype( $path );
			$mime = ! empty( $type['type'] ) ? $type['type'] : $original_mime;
			if ( ! in_array( $mime, [ 'image/jpeg', 'image/png', 'image/webp', 'image/gif' ], true ) ) {
				continue;
			}
			return [
				'path' => $path,
				'mime' => $mime,
			];
		}

		return [
			'path' => $original_path,
			'mime' => $original_mime,
		];
	}

	/**
	 * Map Worker HTTP error responses to user-facing WP_Error codes.
	 *
	 * @param array $response Response from ImageAssistant_Worker_Client.
	 * @return true|WP_Error true when no error.
	 */
	private static function map_worker_error( $response ) {
		$status = isset( $response['status'] ) ? (int) $response['status'] : 0;
		$body   = isset( $response['body'] ) ? (array) $response['body'] : [];

		if ( $status >= 200 && $status < 300 ) {
			return true;
		}

		$err = isset( $body['error'] ) ? (string) $body['error'] : '';
		$msg = isset( $body['message'] ) ? (string) $body['message'] : '';

		if ( 402 === $status && 'credits_exhausted' === $err ) {
			return new WP_Error(
				'credits_exhausted',
				'' !== $msg ? $msg : __( 'Your AI credits are exhausted. Please purchase more to continue using AI features.', 'envira-gallery' ),
				[
					'status'          => 402,
					'total_remaining' => 0,
				]
			);
		}
		if ( 402 === $status && 'insufficient_credits' === $err ) {
			return new WP_Error(
				'insufficient_credits',
				'' !== $msg ? $msg : sprintf(
					/* translators: %d: credits remaining */
					__( 'Not enough credits. You have %d remaining.', 'envira-gallery' ),
					isset( $body['total_remaining'] ) ? (int) $body['total_remaining'] : 0
				),
				[
					'status'          => 402,
					'total_remaining' => isset( $body['total_remaining'] ) ? (int) $body['total_remaining'] : 0,
				]
			);
		}
		if ( 404 === $status && 'license_not_found' === $err ) {
			return new WP_Error(
				'license_not_found',
				'' !== $msg ? $msg : __( 'No AI credit record was found for this license. Please re-verify your license key.', 'envira-gallery' ),
				[ 'status' => 404 ]
			);
		}
		if ( 401 === $status || 'unauthorized' === $err ) {
			return new WP_Error(
				'ai_service_unauthorized',
				__( 'AI service is unavailable (auth failed). Please contact support.', 'envira-gallery' ),
				[ 'status' => 502 ]
			);
		}
		if ( 503 === $status ) {
			return new WP_Error(
				'ai_service_unavailable',
				'' !== $msg ? $msg : __( 'AI service is temporarily unavailable. Please try again later.', 'envira-gallery' ),
				[ 'status' => 503 ]
			);
		}

		return new WP_Error(
			'' !== $err ? $err : 'ai_service_error',
			'' !== $msg ? $msg : __( 'AI service returned an unexpected error.', 'envira-gallery' ),
			[ 'status' => $status >= 400 ? $status : 502 ]
		);
	}

	/**
	 * Build an idempotency key in the documented format.
	 *
	 * {feature}-{site_md5}-{resource}-{user_id}
	 *
	 * @param string $feature     Feature identifier.
	 * @param string $resource_id Resource identifier (attachment id, hash, etc.).
	 * @return string
	 */
	private static function build_idempotency_key( $feature, $resource_id ) {
		$site = md5( get_site_url() );
		$user = (int) get_current_user_id();
		return $feature . '-' . $site . '-' . $resource_id . '-' . $user;
	}
}
