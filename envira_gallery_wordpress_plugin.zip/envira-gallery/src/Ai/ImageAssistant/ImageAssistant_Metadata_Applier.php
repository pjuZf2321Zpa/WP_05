<?php
/**
 * Writes AI-generated metadata back to a WordPress attachment.
 *
 * @package Envira Gallery
 * @since 1.13.6
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ImageAssistant_Metadata_Applier
 */
class ImageAssistant_Metadata_Applier {

	/**
	 * Field map: AI field → WP attachment field.
	 * - alt_text     → _wp_attachment_image_alt postmeta
	 * - title        → post_title
	 * - cleaned_title→ post_title (overrides "title" when both present)
	 * - caption      → post_excerpt
	 * - description  → post_content
	 * - tags         → wp_set_object_terms( ..., 'envira-tag' ) when taxonomy exists
	 */
	public static function apply( $attachment_id, $metadata, $apply_fields = null ) {
		$attachment_id = (int) $attachment_id;
		if ( $attachment_id <= 0 ) {
			return new WP_Error( 'invalid_attachment', __( 'Invalid attachment ID.', 'envira-gallery' ) );
		}
		if ( 'attachment' !== get_post_type( $attachment_id ) ) {
			return new WP_Error( 'not_attachment', __( 'Target post is not an attachment.', 'envira-gallery' ) );
		}

		$applied = [];
		$skipped = [];
		$fields  = is_array( $apply_fields ) ? $apply_fields : array_keys( (array) $metadata );

		// alt_text → postmeta.
		if ( in_array( 'alt_text', $fields, true ) && isset( $metadata['alt_text'] ) ) {
			$value = sanitize_text_field( (string) $metadata['alt_text'] );
			update_post_meta( $attachment_id, '_wp_attachment_image_alt', $value );
			$applied['alt_text'] = $value;
		}

		// title (or cleaned_title) → post_title.
		$post_title = null;
		if ( in_array( 'cleaned_title', $fields, true ) && ! empty( $metadata['cleaned_title'] ) ) {
			$post_title = sanitize_text_field( (string) $metadata['cleaned_title'] );
		} elseif ( in_array( 'title', $fields, true ) && ! empty( $metadata['title'] ) ) {
			$post_title = sanitize_text_field( (string) $metadata['title'] );
		}

		// caption → post_excerpt; description → post_content.
		$post_args = [ 'ID' => $attachment_id ];
		if ( null !== $post_title ) {
			$post_args['post_title'] = $post_title;
		}
		if ( in_array( 'caption', $fields, true ) && isset( $metadata['caption'] ) ) {
			$post_args['post_excerpt'] = wp_kses_post( (string) $metadata['caption'] );
		}
		if ( in_array( 'description', $fields, true ) && isset( $metadata['description'] ) ) {
			$post_args['post_content'] = wp_kses_post( (string) $metadata['description'] );
		}

		if ( count( $post_args ) > 1 ) {
			$result = wp_update_post( $post_args, true );
			if ( is_wp_error( $result ) ) {
				return $result;
			}
			if ( isset( $post_args['post_title'] ) ) {
				$applied['title'] = $post_args['post_title'];
			}
			if ( isset( $post_args['post_excerpt'] ) ) {
				$applied['caption'] = $post_args['post_excerpt'];
			}
			if ( isset( $post_args['post_content'] ) ) {
				$applied['description'] = $post_args['post_content'];
			}
		}

		// tags → envira-tag taxonomy.
		if ( in_array( 'tags', $fields, true ) && ! empty( $metadata['tags'] ) && is_array( $metadata['tags'] ) ) {
			if ( taxonomy_exists( 'envira-tag' ) ) {
				$clean_tags = array_values(
					array_filter(
						array_map(
							function ( $t ) {
								return sanitize_text_field( (string) $t );
							},
							$metadata['tags']
						)
					)
				);
				wp_set_object_terms( $attachment_id, $clean_tags, 'envira-tag', false );
				$applied['tags'] = $clean_tags;
			} else {
				$skipped['tags'] = __( 'Envira Tags addon is not active — tags were not applied.', 'envira-gallery' );
			}
		}

		// Sync the per-image copy Envira keeps in `_eg_gallery_data` for every
		// gallery that references this attachment. Without this the gallery
		// editor list shows the stale title/alt/caption even though the
		// attachment itself has been updated.
		$synced_galleries = self::sync_envira_gallery_data( $attachment_id, $applied );
		if ( $synced_galleries ) {
			$applied['_synced_galleries'] = $synced_galleries;
		}

		return [
			'attachment_id' => $attachment_id,
			'applied'       => $applied,
			'skipped'       => $skipped,
		];
	}

	/**
	 * Push the same field values into every Envira gallery that contains this
	 * attachment, mirroring what envira_gallery_ajax_save_meta() does for
	 * manual edits.
	 *
	 * The per-image array inside `_eg_gallery_data['gallery'][ $id ]` uses
	 * different key names than the attachment / our $applied map:
	 *   alt_text → 'alt', title → 'title', caption → 'caption'.
	 * `description` and `tags` are NOT stored in the gallery data (description
	 * lives on the attachment post; tags on the envira-tag taxonomy).
	 *
	 * @param int   $attachment_id Attachment ID just updated.
	 * @param array $applied       What was written to the attachment.
	 * @return int[] Gallery IDs that were touched.
	 */
	private static function sync_envira_gallery_data( $attachment_id, $applied ) {
		// Use a LIKE query against the serialized fragment that appears when
		// the attachment id is an array key whose value is an array. Envira
		// stores its per-image data as `$gallery_data['gallery'][ <attachment_id> ]
		// = array( ... )`, so the serialized form contains `i:<id>;a:` — narrow
		// enough that we don't have to scan every envira post.
		$marker = sprintf( 'i:%d;a:', (int) $attachment_id );

		$gallery_ids = get_posts(
			[
				'post_type'        => 'envira',
				'post_status'      => 'any',
				'numberposts'      => -1,
				'fields'           => 'ids',
				'meta_query'       => [ // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- See sync rationale above.
					[
						'key'     => '_eg_gallery_data',
						'value'   => $marker,
						'compare' => 'LIKE',
					],
				],
				'suppress_filters' => true,
			]
		);

		if ( empty( $gallery_ids ) ) {
			return [];
		}

		$touched = [];

		foreach ( $gallery_ids as $gallery_id ) {
			$data = get_post_meta( $gallery_id, '_eg_gallery_data', true );
			if ( ! is_array( $data ) || empty( $data['gallery'][ $attachment_id ] ) ) {
				continue;
			}

			$dirty = false;
			if ( isset( $applied['alt_text'] ) ) {
				$data['gallery'][ $attachment_id ]['alt'] = (string) $applied['alt_text'];
				$dirty                                    = true;
			}
			if ( isset( $applied['title'] ) ) {
				$data['gallery'][ $attachment_id ]['title'] = (string) $applied['title'];
				$dirty                                      = true;
			}
			if ( isset( $applied['caption'] ) ) {
				$data['gallery'][ $attachment_id ]['caption'] = (string) $applied['caption'];
				$dirty                                        = true;
			}

			$tags_changed = isset( $applied['tags'] );

			if ( $dirty ) {
				update_post_meta( $gallery_id, '_eg_gallery_data', $data );
			}

			// Flush gallery caches even when only tags changed: the Envira Tags
			// addon caches per-gallery tag indexes used for filter dropdowns
			// and dynamic galleries, and stale entries display old taxonomy
			// data until manual save (regression #1137).
			if ( ( $dirty || $tags_changed ) && function_exists( 'envira_flush_gallery_caches' ) ) {
				envira_flush_gallery_caches( $gallery_id );
			}

			if ( ! $dirty && ! $tags_changed ) {
				continue;
			}

			$touched[] = (int) $gallery_id;
		}

		return $touched;
	}
}
