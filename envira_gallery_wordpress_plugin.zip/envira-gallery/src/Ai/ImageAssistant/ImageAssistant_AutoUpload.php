<?php
/**
 * Auto-generate metadata for images as they are added to a gallery.
 *
 * Hooks Envira's gallery upload/insert events and, when the "Automatically
 * generate on upload" setting is enabled, queues each new image for background
 * generation via ImageAssistant_Bulk_Scheduler. Each image costs 1 credit;
 * already-populated images are skipped when "skip if existing" is on.
 *
 * @package Envira Gallery
 * @since 1.13.6
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ImageAssistant_AutoUpload
 */
class ImageAssistant_AutoUpload {

	/**
	 * Wire the upload/insert hooks.
	 */
	public function hooks() {
		// Fires once per image uploaded into a gallery.
		add_action( 'envira_gallery_ajax_load_image', [ $this, 'on_load_image' ], 20, 2 );
		// Fires once with the batch of images inserted from the Media Library.
		add_action( 'envira_gallery_ajax_insert_images', [ $this, 'on_insert_images' ], 20, 2 );
	}

	/**
	 * Direct upload into a gallery.
	 *
	 * @param int $attachment_id Attachment ID.
	 * @param int $post_id       Gallery post ID.
	 */
	public function on_load_image( $attachment_id, $post_id ) {
		$this->maybe_enqueue( [ (int) $attachment_id ] );
	}

	/**
	 * Media Library insertion into a gallery.
	 *
	 * @param array $images  Inserted image rows (each with an `id`).
	 * @param int   $post_id Gallery post ID.
	 */
	public function on_insert_images( $images, $post_id ) {
		$ids = [];
		foreach ( (array) $images as $image ) {
			if ( is_array( $image ) && ! empty( $image['id'] ) ) {
				$ids[] = (int) $image['id'];
			}
		}
		$this->maybe_enqueue( $ids );
	}

	/**
	 * Queue the given attachments for generation when the feature is enabled and
	 * the license is eligible.
	 *
	 * @param int[] $ids Attachment IDs.
	 */
	private function maybe_enqueue( $ids ) {
		$ids = array_values( array_filter( array_unique( array_map( 'absint', (array) $ids ) ) ) );
		if ( empty( $ids ) ) {
			return;
		}

		$settings = ImageAssistant_Settings::get_all();
		if ( empty( $settings['auto_on_upload'] ) || ! ImageAssistant_License::is_eligible() ) {
			return;
		}

		// Which fields to generate — the Metadata & SEO toggles. Honor issue-01
		// tag gating: never request tags when the taxonomy is unavailable.
		$fields = array_values( (array) $settings['default_fields'] );
		if ( ! taxonomy_exists( 'envira-tag' ) ) {
			$fields = array_values(
				array_filter(
					$fields,
					function ( $f ) {
						return 'tags' !== $f;
					}
				)
			);
		}
		if ( empty( $fields ) ) {
			return;
		}

		$tone = (string) $settings['default_tone'];
		$skip = ! empty( $settings['overwrite_behavior'] );

		foreach ( $ids as $id ) {
			ImageAssistant_Bulk_Scheduler::enqueue_auto( $id, $tone, $fields, $skip );
		}
	}
}
