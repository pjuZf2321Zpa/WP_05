<?php
/**
 * Asset enqueuer for the AI Image Assistant.
 *
 * @package Envira Gallery
 * @since 1.13.6
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ImageAssistant_Assets
 */
class ImageAssistant_Assets {

	const HANDLE_JS  = 'envira-image-assistant';
	const HANDLE_CSS = 'envira-image-assistant';

	/**
	 * Wire up.
	 */
	public function hooks() {
		add_action( 'admin_enqueue_scripts', [ $this, 'maybe_enqueue' ] );
	}

	/**
	 * Cache-busting version for the AI Image Assistant assets.
	 *
	 * Mirrors the plugin-wide convention (see Shortcode.php / Menu_Nudge.php):
	 * when ENVIRA_DEBUG is on, bust the cache with a timestamp so iterative
	 * edits always reload; otherwise use the pinned ENVIRA_VERSION.
	 *
	 * @return string Version string.
	 */
	private static function asset_version() {
		return is_envira_debug_on() ? time() . '-' . ENVIRA_VERSION : ENVIRA_VERSION;
	}

	/**
	 * Conditionally enqueue assets — only on Envira settings + Envira gallery edit
	 * screens, to keep the rest of wp-admin clean.
	 *
	 * @param string $hook Current admin screen hook.
	 */
	public function maybe_enqueue( $hook ) {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;

		$should_load = false;
		if ( $screen ) {
			if ( false !== strpos( (string) $screen->id, 'envira-gallery' ) ) {
				$should_load = true;
			}
			if ( in_array( $screen->post_type, [ 'envira' ], true ) ) {
				$should_load = true;
			}
			// Media Library — both the dedicated list screen and any screen that
			// loads wp.media (post editors include this) so the attachment-edit
			// modal picks up the AI regenerate controls.
			if ( in_array( $screen->base, [ 'upload', 'post' ], true ) ) {
				$should_load = true;
			}
			if ( 'attachment' === $screen->post_type ) {
				$should_load = true;
			}
		}
		// Settings page.
		if ( false !== strpos( (string) $hook, 'envira-gallery-settings' ) ) {
			$should_load = true;
		}

		if ( ! $should_load ) {
			return;
		}

		$version = self::asset_version();

		wp_register_style(
			self::HANDLE_CSS,
			plugins_url( 'assets/css/ai-image-assistant.css', ENVIRA_FILE ),
			[],
			$version
		);
		wp_enqueue_style( self::HANDLE_CSS );

		wp_register_script(
			self::HANDLE_JS,
			plugins_url( 'assets/js/ai-image-assistant.js', ENVIRA_FILE ),
			[ 'wp-api-fetch', 'wp-i18n' ],
			$version,
			true
		);

		$defaults = ImageAssistant_Settings::get_all();
		wp_localize_script(
			self::HANDLE_JS,
			'enviraImageAssistant',
			[
				'restRoot'   => esc_url_raw( rest_url( 'envira-ai/v1/image-assistant/' ) ),
				'nonce'      => wp_create_nonce( 'wp_rest' ),
				'defaults'   => [
					'tone'            => $defaults['default_tone'],
					'fields'          => $defaults['default_fields'],
					'overwriteSkip'   => ! empty( $defaults['overwrite_behavior'] ),
					'autoOnUpload'    => ! empty( $defaults['auto_on_upload'] ),
					'licenseEligible' => ImageAssistant_License::is_eligible(),
					// Whether AI-generated tags are usable on this site. When the
					// Envira Tags addon is inactive the envira-tag taxonomy does
					// not exist, so all tag UI must be hidden client-side.
					'tagsAvailable'   => taxonomy_exists( 'envira-tag' ),
				],
				'i18n'       => [
					'generating'             => __( 'Generating…', 'envira-gallery' ),
					'generated'              => __( 'Metadata generated.', 'envira-gallery' ),
					'failed'                 => __( 'Could not generate metadata.', 'envira-gallery' ),
					/* translators: %d: number of credits remaining. */
					'creditsRemaining'       => __( '%d credits remaining', 'envira-gallery' ),
					'creditsUsedLabel'       => __( 'Credits Used Per Year', 'envira-gallery' ),
					'creditsLow'             => __( 'Running low on credits. Buy more credits or upgrade your plan.', 'envira-gallery' ),
					'creditsExhausted'       => __( 'Out of credits. Buy more credits to continue using Image Assistant features.', 'envira-gallery' ),
					'creditsExhaustedShort'  => __( 'Out of credits.', 'envira-gallery' ),
					'resetDateLabel'         => __( 'Reset date:', 'envira-gallery' ),
					'unlimited'              => __( 'Unlimited credits', 'envira-gallery' ),
					'noLicense'              => __( 'No active Envira license — settings tab unavailable.', 'envira-gallery' ),
					/* translators: %1$d: current image number, %2$d: total number of images. */
					'bulkRunning'            => __( 'Processing %1$d of %2$d…', 'envira-gallery' ),
					/* translators: %1$d: number generated, %2$d: number failed. */
					'bulkComplete'           => __( 'Done: %1$d generated, %2$d failed.', 'envira-gallery' ),
					'saveOk'                 => __( 'Settings saved.', 'envira-gallery' ),
					'saveFail'               => __( 'Could not save settings.', 'envira-gallery' ),

					// Modal copy.
					'modalTitle'             => __( 'Image Assistant', 'envira-gallery' ),
					'modalSubtitle'          => __( 'Automatically create and edit metadata for your images.', 'envira-gallery' ),
					'bulkModalTitle'         => __( 'Bulk Image Assistant', 'envira-gallery' ),
					'imageAssistantSettings' => __( 'Image Assistant Settings', 'envira-gallery' ),
					'imageAssistantTrigger'  => __( 'Image Assistant', 'envira-gallery' ),
					'cancel'                 => __( 'Cancel', 'envira-gallery' ),
					'close'                  => __( 'Close', 'envira-gallery' ),
					'retry'                  => __( 'Retry', 'envira-gallery' ),
					'generate'               => __( 'Generate', 'envira-gallery' ),
					'regenerate'             => __( 'Regenerate', 'envira-gallery' ),
					'regenerated'            => __( 'Suggestion ready.', 'envira-gallery' ),
					'regenerateCost'         => __( 'Uses 1 credit', 'envira-gallery' ),
					'reject'                 => __( 'Reject', 'envira-gallery' ),
					'accept'                 => __( 'Accept', 'envira-gallery' ),
					'accepted'               => __( 'Accepted', 'envira-gallery' ),
					'acceptAll'              => __( 'Accept All', 'envira-gallery' ),
					'applied'                => __( 'Metadata applied.', 'envira-gallery' ),
					'pickAtLeastOne'         => __( 'Pick at least one field.', 'envira-gallery' ),
					'nothingToApply'         => __( 'Nothing to apply.', 'envira-gallery' ),
					'selectFirst'            => __( 'Select images first.', 'envira-gallery' ),

					// Single-image processing copy.
					'generatingText'         => __( 'Generating Text', 'envira-gallery' ),
					/* translators: %d: number of metadata fields. */
					'generatingDetail'       => __( 'Analyzing image and generating all %d fields', 'envira-gallery' ),

					// Bulk modal copy.
					/* translators: %d: number of images. */
					'bulkAllImages'          => __( '%d images', 'envira-gallery' ),
					/* translators: %d: maximum number of credits the batch will use. */
					'bulkCostNotice'         => __( 'Each image uses 1 credit. The batch will use up to %d credits.', 'envira-gallery' ),
					'bulkSkipNotice'         => __( 'Images with existing metadata will be skipped.', 'envira-gallery' ),
					'bulkOverwriteNotice'    => __( 'Images with existing metadata will be overwritten.', 'envira-gallery' ),
					'changeSettings'         => __( 'Change Settings', 'envira-gallery' ),
					/* translators: %1$d: current image number, %2$d: total number of images. */
					'processingHeader'       => __( 'Processing %1$d of %2$d images', 'envira-gallery' ),
					'bulkBackground'         => __( 'You can close this window and it will keep running in the background.', 'envira-gallery' ),
					'cancelProcessing'       => __( 'Cancel Processing', 'envira-gallery' ),
					'processingCompleted'    => __( 'Processing Completed', 'envira-gallery' ),
					'bulkCancelled'          => __( 'Processing Cancelled', 'envira-gallery' ),
					/* translators: %1$d: number completed, %2$d: total number, %3$d: elapsed seconds. */
					'bulkSummary'            => __( '%1$d / %2$d Metadata completed in %3$ds', 'envira-gallery' ),
					/* translators: %1$d: number completed, %2$d: total number, %3$d: number skipped. */
					'bulkProgressMeta'       => __( '%1$d / %2$d completed · %3$d skipped', 'envira-gallery' ),
					/* translators: %1$d: number completed, %2$d: total number, %3$d: number skipped. */
					'bulkCompletedMeta'      => __( '%1$d / %2$d Metadata completed · %3$d skipped', 'envira-gallery' ),
				],
				'tonesLabel' => [
					'seo'          => __( 'SEO-Optimized', 'envira-gallery' ),
					'minimal'      => __( 'Minimal', 'envira-gallery' ),
					'creative'     => __( 'Creative', 'envira-gallery' ),
					'professional' => __( 'Professional', 'envira-gallery' ),
					'ecommerce'    => __( 'E-commerce', 'envira-gallery' ),
					'photography'  => __( 'Photography', 'envira-gallery' ),
				],
			]
		);

		wp_enqueue_script( self::HANDLE_JS );
	}
}
