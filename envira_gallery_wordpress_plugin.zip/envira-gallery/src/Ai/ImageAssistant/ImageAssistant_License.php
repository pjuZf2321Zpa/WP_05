<?php
/**
 * License + plan helpers for the AI Image Assistant.
 *
 * Wraps the existing Envira license accessors so the rest of the module never
 * touches `get_option('envira_gallery')` directly.
 *
 * @package Envira Gallery
 * @since 1.13.6
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ImageAssistant_License
 */
class ImageAssistant_License {

	/**
	 * Get the active Envira license key.
	 *
	 * @return string Empty string if no key is set.
	 */
	public static function get_key() {
		$key = function_exists( 'envira_get_license_key' ) ? envira_get_license_key() : '';
		return is_string( $key ) ? $key : '';
	}

	/**
	 * Get the plan type (basic | plus | pro | ultra).
	 *
	 * Reads the `envira_gallery` option directly instead of calling the
	 * `envira_get_license_key_type()` helper, because that helper lives in
	 * src/Functions/admin.php and is only required when is_admin() is true.
	 * REST requests don't satisfy is_admin(), so the helper isn't loaded
	 * and a function_exists() check returns false in that context.
	 *
	 * @return string Empty string if unknown.
	 */
	public static function get_plan_type() {
		$option = get_option( 'envira_gallery' );
		if ( ! is_array( $option ) || empty( $option['type'] ) ) {
			return '';
		}
		return is_string( $option['type'] ) ? strtolower( $option['type'] ) : '';
	}

	/**
	 * True when the customer has a usable license + plan.
	 *
	 * @return bool
	 */
	public static function is_eligible() {
		$key  = self::get_key();
		$plan = self::get_plan_type();
		return ! empty( $key ) && in_array( $plan, [ 'basic', 'plus', 'pro', 'ultra' ], true );
	}
}
