<?php
/**
 * Settings storage + sub-tab UI for the AI Image Assistant.
 *
 * @package Envira Gallery
 * @since 1.13.6
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ImageAssistant_Settings
 */
class ImageAssistant_Settings {

	const OPTION_KEY = 'envira_ai_image_assistant';

	const TAB_SLUG = 'image_assistant';

	/**
	 * Defaults applied when the option does not exist yet.
	 *
	 * @return array
	 */
	public static function defaults() {
		return [
			'default_tone'                => 'seo',
			'default_fields'              => [ 'alt_text', 'title', 'caption', 'description', 'tags' ],
			'cleanup_titles'              => false,
			// New in the mockup: "Skip images that already have metadata".
			'overwrite_behavior'          => true,
			// New in the mockup: org-wide enablement for the gallery-level description generator.
			'gallery_description_enabled' => false,
			// Master switch for the Metadata & SEO section: when off, no metadata
			// is generated on upload and the section's field toggles are hidden.
			'auto_on_upload'              => false,
		];
	}

	/**
	 * Read the stored settings, merged over defaults.
	 *
	 * @return array
	 */
	public static function get_all() {
		$stored = get_option( self::OPTION_KEY, [] );
		if ( ! is_array( $stored ) ) {
			$stored = [];
		}
		return array_merge( self::defaults(), $stored );
	}

	/**
	 * Persist settings. Strict whitelist of keys + values.
	 *
	 * @param array $input Raw user input.
	 * @return array Sanitized values that were saved.
	 */
	public static function update( $input ) {
		$valid_tones  = [ 'seo', 'minimal', 'creative', 'professional', 'ecommerce', 'photography' ];
		$valid_fields = [ 'alt_text', 'title', 'caption', 'description', 'tags', 'cleaned_title' ];

		$existing = self::get_all();

		$tone = isset( $input['default_tone'] ) ? strtolower( (string) $input['default_tone'] ) : $existing['default_tone'];
		if ( ! in_array( $tone, $valid_tones, true ) ) {
			$tone = 'seo';
		}

		$fields_in = isset( $input['default_fields'] ) && is_array( $input['default_fields'] ) ? $input['default_fields'] : $existing['default_fields'];
		$fields    = array_values(
			array_intersect(
				$valid_fields,
				array_map( 'strval', $fields_in )
			)
		);

		// When the Envira Tags addon is inactive the settings UI hides the tags
		// toggle, so an incoming save would silently drop a previously-saved
		// 'tags' preference. Preserve it from the stored value so re-activating
		// the addon restores the user's choice instead of resetting it.
		if ( ! taxonomy_exists( 'envira-tag' ) ) {
			$had_tags = in_array( 'tags', (array) $existing['default_fields'], true );
			$has_tags = in_array( 'tags', $fields, true );
			if ( $had_tags && ! $has_tags ) {
				$fields[] = 'tags';
			}
		}

		if ( empty( $fields ) ) {
			$fields = [ 'alt_text' ];
		}

		$cleanup      = ! empty( $input['cleanup_titles'] );
		$overwrite    = isset( $input['overwrite_behavior'] ) ? ! empty( $input['overwrite_behavior'] ) : $existing['overwrite_behavior'];
		$gallery_desc = ! empty( $input['gallery_description_enabled'] );
		$auto_upload  = ! empty( $input['auto_on_upload'] );

		$value = [
			'default_tone'                => $tone,
			'default_fields'              => $fields,
			'cleanup_titles'              => $cleanup,
			'overwrite_behavior'          => $overwrite,
			'gallery_description_enabled' => $gallery_desc,
			'auto_on_upload'              => $auto_upload,
		];

		update_option( self::OPTION_KEY, $value, false );
		return $value;
	}

	/**
	 * Register the settings sub-tab.
	 */
	public function hooks() {
		add_filter( 'envira_gallery_settings_tab_nav', [ $this, 'register_tab' ] );
		add_action( 'envira_gallery_tab_settings_' . self::TAB_SLUG, [ $this, 'render_tab' ] );
		// Credit Usage block also appears on the General tab.
		add_action( 'envira_gallery_settings_general_box', [ $this, 'render_general_tab_credits' ] );
	}

	/**
	 * Insert the credit-usage widget as the last row of the General settings tab.
	 * The General tab is rendered inside a WP form-table; we emit a full-width
	 * row that contains the widget element (the same one the JS targets on the
	 * Image Assistant Settings tab — both surfaces share class names).
	 */
	public function render_general_tab_credits() {
		if ( ! ImageAssistant_License::is_eligible() ) {
			return;
		}
		?>
		<tr class="envira-ia">
			<th scope="row"><?php esc_html_e( 'Credit Usage', 'envira-gallery' ); ?></th>
			<td><?php self::render_credit_widget(); ?></td>
		</tr>
		<?php
	}

	/**
	 * Add tab nav entry.
	 *
	 * @param array $tabs Existing tabs.
	 * @return array
	 */
	public function register_tab( $tabs ) {
		if ( ! is_array( $tabs ) ) {
			return $tabs;
		}
		$tabs[ self::TAB_SLUG ] = __( 'Image Assistant Settings', 'envira-gallery' );
		return $tabs;
	}

	/**
	 * Render the tab body — a thin container; the React-free vanilla JS lives in
	 * assets/js/ai-image-assistant.js and talks to the REST endpoints.
	 */
	public function render_tab() {
		$settings    = self::get_all();
		$nonce       = wp_create_nonce( 'wp_rest' );
		$rest_root   = esc_url_raw( rest_url( 'envira-ai/v1/image-assistant/' ) );
		$license_key = ImageAssistant_License::get_key();
		$plan        = ImageAssistant_License::get_plan_type();
		$env         = ImageAssistant_Worker_Client::env();

		?>
		<div id="envira-image-assistant-settings" class="envira-ia"
			data-rest-root="<?php echo esc_attr( $rest_root ); ?>"
			data-nonce="<?php echo esc_attr( $nonce ); ?>"
			data-tone="<?php echo esc_attr( $settings['default_tone'] ); ?>"
			data-fields="<?php echo esc_attr( implode( ',', $settings['default_fields'] ) ); ?>"
			data-cleanup="<?php echo esc_attr( $settings['cleanup_titles'] ? '1' : '0' ); ?>"
			data-overwrite="<?php echo esc_attr( $settings['overwrite_behavior'] ? '1' : '0' ); ?>"
			data-gallery-desc="<?php echo esc_attr( $settings['gallery_description_enabled'] ? '1' : '0' ); ?>"
			data-license="<?php echo esc_attr( ! empty( $license_key ) ? '1' : '0' ); ?>"
			data-plan="<?php echo esc_attr( $plan ); ?>"
			data-env="<?php echo esc_attr( $env ); ?>">

			<h2 style="margin-top:0;">
				<span class="envira-ia-sparkle envira-ia-sparkle--lg" style="color:var(--ia-green);"></span>
				<?php esc_html_e( 'Image Assistant', 'envira-gallery' ); ?>
				<?php if ( 'live' !== $env ) : ?>
					<span class="envira-ia-env-badge" data-env="<?php echo esc_attr( $env ); ?>" title="<?php esc_attr_e( 'AI worker environment — controlled by ENVIRA_AI_IMAGE_ENV in wp-config.php', 'envira-gallery' ); ?>">
						<?php echo esc_html( strtoupper( $env ) ); ?>
					</span>
				<?php endif; ?>
			</h2>
			<p class="description">
				<?php esc_html_e( 'Automatically generate alt text, tags, captions, and titles for your gallery images.', 'envira-gallery' ); ?>
			</p>

			<?php self::render_credit_widget(); ?>

			<?php $tags_available = taxonomy_exists( 'envira-tag' ); ?>

			<div class="envira-ia-section">
				<h4><?php esc_html_e( 'Metadata & SEO', 'envira-gallery' ); ?></h4>

				<!-- Master switch: enables on-upload generation and reveals the field toggles below. -->
				<div class="envira-ia-row">
					<div class="envira-ia-row-text">
						<strong><?php esc_html_e( 'Automatically generate on upload', 'envira-gallery' ); ?></strong>
						<small><?php esc_html_e( 'Generate the selected metadata for each new image as it is added to a gallery. Uses 1 credit per image.', 'envira-gallery' ); ?></small>
					</div>
					<label class="envira-ia-toggle">
						<input type="checkbox"
							id="envira-image-assistant-auto-upload"
							<?php checked( ! empty( $settings['auto_on_upload'] ) ); ?> />
						<span class="envira-ia-toggle-slider"></span>
					</label>
				</div>

				<div class="envira-image-assistant-auto-fields"<?php echo empty( $settings['auto_on_upload'] ) ? ' hidden' : ''; ?>>

				<?php if ( ! $tags_available ) : ?>
					<div class="envira-ia-warning" role="alert">
						<span class="envira-ia-sparkle"></span>
						<div>
							<strong><?php esc_html_e( 'AI tagging is unavailable', 'envira-gallery' ); ?></strong>
							<p>
								<?php esc_html_e( 'AI-generated tags require the Envira Tags addon, which is not active on this site. Tag options are hidden until it is enabled.', 'envira-gallery' ); ?>
								<a href="<?php echo esc_url( admin_url( 'admin.php?page=envira-gallery-addons' ) ); ?>">
									<?php esc_html_e( 'Manage addons', 'envira-gallery' ); ?>
								</a>
							</p>
						</div>
					</div>
				<?php endif; ?>

				<?php
				$field_rows = [
					'alt_text'      => [
						__( 'Generate Alt Text', 'envira-gallery' ),
						__( 'Automatically create descriptive alt text for accessibility and SEO.', 'envira-gallery' ),
					],
					'tags'          => [
						__( 'Generate Tags', 'envira-gallery' ),
						__( 'Create relevant tags for better organization and searchability.', 'envira-gallery' ),
					],
					'caption'       => [
						__( 'Generate Captions', 'envira-gallery' ),
						__( 'Generate engaging captions that describe your images.', 'envira-gallery' ),
					],
					'cleaned_title' => [
						__( 'Clean Up Titles', 'envira-gallery' ),
						__( 'Transform file names into readable, formatted titles.', 'envira-gallery' ),
					],
				];
				foreach ( $field_rows as $slug => $copy ) :
					// Hide the tags toggle entirely when the taxonomy is unavailable.
					if ( 'tags' === $slug && ! $tags_available ) {
						continue;
					}
					$on = in_array( $slug, $settings['default_fields'], true );
					?>
					<div class="envira-ia-row">
						<div class="envira-ia-row-text">
							<strong><?php echo esc_html( $copy[0] ); ?></strong>
							<small><?php echo esc_html( $copy[1] ); ?></small>
						</div>
						<label class="envira-ia-toggle">
							<input type="checkbox"
								class="envira-image-assistant-field"
								name="default_fields[]"
								value="<?php echo esc_attr( $slug ); ?>"
								<?php checked( $on ); ?> />
							<span class="envira-ia-toggle-slider"></span>
						</label>
					</div>
				<?php endforeach; ?>

				<div class="envira-ia-row">
					<div class="envira-ia-row-text">
						<strong><?php esc_html_e( 'Gallery Description Generator', 'envira-gallery' ); ?></strong>
						<small><?php esc_html_e( 'Create comprehensive descriptions for entire galleries.', 'envira-gallery' ); ?></small>
					</div>
					<label class="envira-ia-toggle">
						<input type="checkbox"
							id="envira-image-assistant-gallery-desc"
							<?php checked( ! empty( $settings['gallery_description_enabled'] ) ); ?> />
						<span class="envira-ia-toggle-slider"></span>
					</label>
				</div>
				</div><!-- /.envira-image-assistant-auto-fields -->
			</div>

			<div class="envira-ia-section">
				<h4><?php esc_html_e( 'Tone & Style', 'envira-gallery' ); ?></h4>
				<select id="envira-image-assistant-tone" name="default_tone" style="min-width:280px;">
					<option value="<?php echo esc_attr( $settings['default_tone'] ); ?>">
						<?php echo esc_html( $settings['default_tone'] ); ?>
					</option>
				</select>
				<p class="description envira-image-assistant-tone-desc" style="margin-top:6px;">
					<?php esc_html_e( 'Loading tones…', 'envira-gallery' ); ?>
				</p>
			</div>

			<div class="envira-ia-section">
				<h4><?php esc_html_e( 'Overwrite Behavior', 'envira-gallery' ); ?></h4>
				<div class="envira-ia-row">
					<div class="envira-ia-row-text">
						<strong><?php esc_html_e( 'Skip images that already have metadata', 'envira-gallery' ); ?></strong>
						<small><?php esc_html_e( 'Prevents AI from overwriting manually written alt text, tags, captions, or titles.', 'envira-gallery' ); ?></small>
					</div>
					<label class="envira-ia-toggle">
						<input type="checkbox"
							id="envira-image-assistant-overwrite"
							<?php checked( ! empty( $settings['overwrite_behavior'] ) ); ?> />
						<span class="envira-ia-toggle-slider"></span>
					</label>
				</div>
			</div>

			<div class="envira-ia-section">
				<button type="button" class="envira-ia-btn envira-ia-btn--primary envira-image-assistant-save">
					<?php esc_html_e( 'Save Settings', 'envira-gallery' ); ?>
				</button>
				<span class="envira-image-assistant-save-status" style="margin-left:10px;color:var(--ia-ink-muted);"></span>
			</div>
		</div>
		<?php
	}

	/**
	 * Render the standalone Credit Usage widget — also reused on the General tab.
	 *
	 * Renders empty bones; the JS populates the numbers, date, and `data-state`.
	 */
	public static function render_credit_widget() {
		?>
		<div class="envira-ia-credit-widget envira-image-assistant-credit-widget" data-state="loading">
			<div class="envira-ia-credit-widget-head">
				<span><span class="envira-ia-sparkle" style="color:var(--ia-green);"></span> <strong class="envira-image-assistant-credit-amount"><?php esc_html_e( 'Loading…', 'envira-gallery' ); ?></strong></span>
				<span class="envira-image-assistant-credit-reset" style="color:var(--ia-ink-muted);font-size:12px;"></span>
			</div>
			<div class="envira-ia-bar" data-state="ok"><div class="envira-ia-bar-fill"></div></div>
			<p class="envira-ia-credit-widget-note envira-image-assistant-credit-note"></p>
			<div class="envira-ia-credit-widget-cta">
				<a class="envira-ia-btn envira-ia-btn--primary" href="https://enviragallery.com/ai-credits-pricing/" target="_blank" rel="noopener noreferrer">
					<?php esc_html_e( 'Buy More Credits', 'envira-gallery' ); ?>
				</a>
				<a class="envira-ia-btn envira-ia-btn--ghost" href="https://enviragallery.com/pricing/" target="_blank" rel="noopener noreferrer">
					<?php esc_html_e( 'Upgrade Plan', 'envira-gallery' ); ?>
				</a>
			</div>
		</div>
		<?php
	}
}
