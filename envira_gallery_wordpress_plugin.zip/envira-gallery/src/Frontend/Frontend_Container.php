<?php
/**
 * Frontend Container
 *
 * @since 1.7.0
 *
 * @package Envira_Gallery
 * @author  Envira Gallery Team <support@enviragallery.com>
 */

namespace Envira\Frontend;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {

	exit;

}

use Envira\Frontend\Gallery_Detector;
use Envira\Frontend\Posttypes;
use Envira\Frontend\Standalone;
use Envira\Frontend\Shortcode;
use Envira\Frontend\Background;
use Envira\Frontend\Rest;
use Envira\Frontend\Convert_Gallery\Convert_Gallery_Main;

use Envira\Widgets\Widget;
use Envira\Utils\Capabilities;

use Envira\Admin\Support;

/**
 * Frontend Container
 *
 * @since 1.7.0
 *
 * @package Envira_Gallery
 * @author  Envira Gallery Team <support@enviragallery.com>
 */
class Frontend_Container {

	/**
	 * __construct function.
	 *
	 * @access public
	 * @return void
	 */
	public function __construct() {

		// Boot the page-level gallery detector so its cache is primed on the wp hook.
		add_action( 'wp', [ Gallery_Detector::class, 'page_has_gallery' ], 1 );

		$posttypes  = new Posttypes();
		$standalone = new Standalone();
		$shortcode  = new Shortcode();
		$background = new Background();
		$rest       = new Rest();
		$usage      = new Envira_Tracking();

		// Link shortcode.
		( new Shortcode_Link() )->init();

		( new Envira_Tracking() )->hooks();

		( new Convert_Gallery_Main() )->hooks();

		/* Yoast SEO */
		add_filter( 'wpseo_sitemap_urlimages', [ $this, 'filter_wpseo_sitemap_urlimages' ], 10, 2 );

		/* Rank Math */
		add_filter( 'rank_math/sitemap/urlimages', [ $this, 'filter_wpseo_sitemap_urlimages' ], 10, 2 );

		/* All In One SEO */
		add_filter( 'aioseo_sitemap_posts', [ $this, 'filter_aioseo_sitemap_posts' ], 10, 2 );

		add_filter( 'widget_text', 'do_shortcode' );

		add_filter( 'envira_gallery_shortcode_start', [ $this, 'filter_shortcode_start' ], 10, 1 );

		// Load the plugin widget.
		add_action( 'widgets_init', [ $this, 'widget' ] );

		// Load any custom admin bar additions.
		add_action( 'admin_bar_menu', [ $this, 'admin_bar' ], 99999 );

		// Load any settings from support.
		add_action( 'init', [ $this, 'fix_ssl' ] );
	}

	/**
	 * Loads potentially support overrides and settings.
	 *
	 * @since 1.8.9
	 */
	public function fix_ssl() {
		if ( is_admin() || ! function_exists( 'is_ssl' ) || ! is_ssl() ) {
			return;
		}

		add_filter( 'wp_get_attachment_url', [ $this, 'envira_fix_ssl_images' ] );
		add_filter( 'envira_gallery_link_href', [ $this, 'envira_fix_ssl_images' ] );
		add_filter( 'envira_albums_image_src', [ $this, 'envira_fix_ssl_images' ] );
		add_filter( 'envira_gallery_image_src', [ $this, 'envira_fix_ssl_images' ] );
	}

	/**
	 * The actual fix.
	 *
	 * @param string $url The url to fix.
	 *
	 * @return string
	 */
	public function envira_fix_ssl_images( $url ) {
		if ( ! is_string( $url ) ) {
			return $url;
		}

		return str_replace( 'http://', 'https://', $url );
	}

	/**
	 * Registers the Envira Gallery widgets.
	 *
	 * @since 1.7.0
	 */
	public function widget() {

		register_widget( 'Envira\Widgets\Widget' );
		register_widget( 'Envira\Widgets\EnviraWidgetRandom' );
	}

	/**
	 * Prevents Envira shortcodes from being rendered due to third-party conflicts
	 *
	 * @since 1.8.0
	 *
	 * @param array $atts shortcode attributes.
	 *
	 * @return array        Updated Array w/ action and reason
	 */
	public function filter_shortcode_start( $atts ) {

		if ( ! is_admin() ) {
			/* these are the things to watch for the frontend... mostly just intercepting do_shortcode() attempts. */

			// All-in-One SEO Pro.
			global $aioseop_options;
			if ( isset( $aioseop_options ) && ! empty( $aioseop_options['aiosp_run_shortcodes'] ) ) {
				return ( [
					'action' => 'warning',
					'reason' => 'All In One SEO: Must deactivate aiosp_run_shortcodes',
				] );
			}
			return;
		}

		// Prevent Yoast And Divi From Previewing, rendering JSON breaking / causing JS errors.
		if ( isset( $_REQUEST['action'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			switch ( $_REQUEST['action'] ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
				case 'wpseo_filter_shortcodes':
					// Yoast.
					return ( [
						'action' => 'bail',
						'reason' => sanitize_text_field( wp_unslash( $_REQUEST['action'] ) ), // phpcs:ignore WordPress.Security.NonceVerification.Recommended
					] );
				case 'et_pb_execute_content_shortcodes':
					// Divi.
					return ( [
						'action' => 'bail',
						'reason' => sanitize_text_field( wp_unslash( $_REQUEST['action'] ) ), // phpcs:ignore WordPress.Security.NonceVerification.Recommended
					] );
				case 'edit':
				case 'editpost':
					// Divi + Yoast.
					if ( defined( 'WPSEO_VERSION' ) && ( function_exists( 'et_setup_theme' ) || function_exists( 'et_divi_load_scripts_styles' ) ) ) {
						return ( [
							'action' => 'bail',
							'reason' => sanitize_text_field( wp_unslash( $_REQUEST['action'] ) ), // phpcs:ignore WordPress.Security.NonceVerification.Recommended
						] );
					}
					break;
			}
		}
	}

	/**
	 * Adds custom links to admin bar
	 *
	 * @since 1.8.4
	 *
	 * @param array $wp_admin_bar Admin bar.
	 */
	public function admin_bar( $wp_admin_bar ) {

		$admin_option = get_option( 'eg_admin_bar' );
		$support_bar  = ! empty( $admin_option ) && true === $admin_option ? true : false;

		if ( $support_bar ) {

			$args = [
				'id'     => 'envira-support',
				'title'  => '<span style="color:#FFA500">Envira Support</span>',
				'parent' => 'top-secondary',
				'href'   => admin_url(
					add_query_arg(
						[
							'post_type' => 'envira',
							'page'      => 'envira-gallery-support-general',
						],
						'edit.php'
					)
				),
			];

			$wp_admin_bar->add_node( $args );

		}
	}

	/**
	 * Inserts images into Yoast SEO Sitexml.
	 *
	 * @since 1.7.0
	 *
	 * @param array $yoast_images Current incoming array of images.
	 * @param int   $post_id WP ID.
	 *
	 * @return array        Updated Yoast Array.
	 */
	public function filter_wpseo_sitemap_urlimages( $yoast_images, $post_id ) {

		// Galleries and albums list their own images; any other type a sitemap can
		// carry is scanned for embedded galleries. The previous form bound `!` to
		// get_post_type() before comparing, so every clause was `false === 'envira'`
		// and the guard never fired — restricting it to post/page while fixing that
		// would newly exclude the custom post types #3251 asked about.
		$post_type = get_post_type( $post_id );

		if ( ! $post_type ) {
			return $yoast_images;
		}

		if ( ! in_array( $post_type, [ 'envira', 'envira_album' ], true ) && ! is_post_type_viewable( $post_type ) ) {
			return $yoast_images;
		}

		// If defaults addon is activated, make sure we returning a number of images for a dynamic or default gallery/album.
		if ( class_exists( 'Envira_Defaults' ) && ( intval( $post_id ) === intval( get_option( 'envira_default_gallery' ) ) || intval( $post_id ) === intval( get_option( 'envira_default_album' ) ) ) ) {
			return $yoast_images;
		}

		// If defaults addon is activated, make sure we returning a number of images for a dynamic or default gallery/album.
		if ( class_exists( 'Envira_Dynamic' ) && ( intval( $post_id ) === intval( get_option( 'envira_dynamic_gallery' ) ) || intval( $post_id ) === intval( get_option( 'envira_dynamic_album' ) ) ) ) {
			return $yoast_images;
		}

		switch ( $post_type ) {
			case 'envira':
				// if this is a gallery get all the images and add them to the array.
				$gallery = envira_get_gallery( $post_id );
				if ( $gallery && ! empty( $gallery['gallery'] ) && ! $this->is_inactive( $gallery ) ) {
					foreach ( $gallery['gallery'] as $image ) {
						// A stored src can be false or an array; #5219 is the AIOSEO
						// sitemap fataling on exactly that.
						if ( ! empty( $image['src'] ) && is_string( $image['src'] ) ) {
							$yoast_images[] = [ 'src' => $image['src'] ];
						}
					}
				}
				break;

			case 'envira_album':
				// if this is an album get all the gallerys, then images,  and add them to the array.
				if ( ! class_exists( 'Envira_Albums' ) ) {
					return $yoast_images;
				}

				$instance_albums = \Envira_Albums::get_instance();
				$album           = $instance_albums->_get_album( $post_id );

				// go through all the galleries, limit to 50 for now to ensure most sites don't timeout.
				$counter = 0;
				if ( ! empty( $album['galleries'] ) ) {
					foreach ( $album['galleries'] as $album_gallery ) {
						// The album's own entry is published, so the SEO plugin's
						// publish-only query never filters its members.
						if ( $counter <= 50 && ! empty( $album_gallery['id'] ) && $this->is_publicly_listable( $album_gallery['id'] ) ) {

							$gallery = envira_get_gallery( $album_gallery['id'] );
							if ( $gallery && ! empty( $gallery['gallery'] ) && ! $this->is_inactive( $gallery ) ) {
								foreach ( $gallery['gallery'] as $image ) {
									if ( ! empty( $image['src'] ) && is_string( $image['src'] ) ) {
										$yoast_images[] = [ 'src' => $image['src'] ];
									}
								}
								++$counter;
							}
						}
					}
				}
				break;

			default:
				$seen = [];

				foreach ( $yoast_images as $yoast_image ) {
					if ( is_array( $yoast_image ) && ! empty( $yoast_image['src'] ) ) {
						$seen[ $yoast_image['src'] ] = true;
					}
				}

				foreach ( $this->get_envira_image_srcs_in_post( $post_id ) as $src ) {
					if ( isset( $seen[ $src ] ) ) {
						continue;
					}

					$yoast_images[] = [ 'src' => $src ];
					$seen[ $src ]   = true;
				}

				break;
		}

		return $yoast_images;
	}

	/**
	 * Inserts images into All in One SEO Sitexml.
	 *
	 * @since 1.7.0
	 *
	 * @param array  $entries Current incoming array of entries.
	 * @param string $post_type Posttype.
	 *
	 * @return array Updated entry Array.
	 */
	public function filter_aioseo_sitemap_posts( $entries, $post_type = false ) {

		if ( ! $post_type || ! is_string( $post_type ) ) {
			return $entries;
		}

		if ( ! in_array( $post_type, [ 'envira', 'envira_album' ], true ) && ! is_post_type_viewable( $post_type ) ) {
			return $entries;
		}

		switch ( $post_type ) {

			case 'envira':
				foreach ( $entries as $key => $entry ) {
					if ( empty( $entry['loc'] ) ) {
						continue;
					}

					$gallery_id = url_to_postid( $entry['loc'] );

					if ( 0 === $gallery_id ) {
						// Was get_page_by_path( ... ) with its default post type of
						// 'page', which can never match a gallery, and then read ->ID
						// off the resulting null.
						// get_page_by_path() applies no post_status filter and no ORDER BY,
						// and wp_unique_post_slug() leaves draft slugs non-unique, so this
						// can hand back an unpublished namesake.
						$gallery_post = get_page_by_path( basename( untrailingslashit( $entry['loc'] ) ), OBJECT, 'envira' );
						$gallery_id   = $gallery_post instanceof \WP_Post && $this->is_publicly_listable( $gallery_post->ID ) ? (int) $gallery_post->ID : 0;
					}

					// `break` here aborted the whole loop, so one unresolvable URL
					// stripped the images from every later entry on the page.
					if ( 0 === $gallery_id ) {
						continue;
					}

					$gallery = envira_get_gallery( $gallery_id );
					if ( $gallery && ! empty( $gallery['gallery'] ) && ! $this->is_inactive( $gallery ) ) {
						foreach ( $gallery['gallery'] as $image ) {
							// A stored src can be false or an array; #5219 is this
							// sitemap fataling on exactly that.
							if ( ! empty( $image['src'] ) && is_string( $image['src'] ) ) {
								$entries[ $key ]['images'][] = [ 'image:loc' => $image['src'] ];
							}
						}
					}
				}
				break;

			case 'envira_album':
				// if this is an album get all the gallerys, then images,  and add them to the array.
				if ( ! class_exists( 'Envira_Albums' ) ) {
					return $entries;
				}

				foreach ( $entries as $key => $entry ) {
					if ( empty( $entry['loc'] ) ) {
						continue;
					}

					$album_id = url_to_postid( $entry['loc'] );

					if ( 0 === $album_id ) {
						// The ternary this replaces assigned the WP_Post itself to
						// $album_id, so intval() ran against an object and
						// _get_album() was handed a post object instead of an ID.
						$album_post = get_page_by_path( basename( untrailingslashit( $entry['loc'] ) ), OBJECT, 'envira_album' );
						$album_id   = $album_post instanceof \WP_Post && $this->is_publicly_listable( $album_post->ID ) ? (int) $album_post->ID : 0;
					}

					if ( 0 === $album_id ) {
						continue;
					}

					$instance_albums = \Envira_Albums::get_instance();
					$album           = $instance_albums->_get_album( $album_id );

					// go through all the galleries, limit to 50 for now to ensure most sites don't timeout.
					$counter = 0;
					if ( ! empty( $album['galleries'] ) ) {
						foreach ( $album['galleries'] as $album_gallery ) {
							if ( $counter <= 50 && ! empty( $album_gallery['id'] ) && $this->is_publicly_listable( $album_gallery['id'] ) ) {

								$gallery = envira_get_gallery( $album_gallery['id'] );
								if ( $gallery && ! empty( $gallery['gallery'] ) && ! $this->is_inactive( $gallery ) ) {
									foreach ( $gallery['gallery'] as $image ) {
										if ( ! empty( $image['src'] ) && is_string( $image['src'] ) ) {
											$entries[ $key ]['images'][] = [ 'image:loc' => $image['src'] ];
										}
									}
									++$counter;
								}
							}
						}
					}
				}
				break;

			default:
				// One sitemap page carries up to a thousand entries and the same
				// gallery is often embedded in many of them, so resolve each post
				// at most once per call.
				$srcs_by_post = [];

				foreach ( $entries as $key => $entry ) {
					if ( empty( $entry['loc'] ) ) {
						continue;
					}

					$entry_post_id = url_to_postid( $entry['loc'] );

					if ( 0 === $entry_post_id ) {
						$entry_post_id = $this->get_front_page_id( $entry['loc'] );
					}

					if ( 0 === $entry_post_id ) {
						$entry_post = get_page_by_path( basename( untrailingslashit( $entry['loc'] ) ), OBJECT, $post_type );
						// get_page_by_path() returns null for an unknown path; the old code read
						// ->ID off that null and silently carried on with an empty post ID. It
						// also matches on slug alone, so the namesake it finds may be a draft.
						$entry_post_id = $entry_post instanceof \WP_Post && $this->is_publicly_listable( $entry_post->ID ) ? (int) $entry_post->ID : 0;
					}

					if ( 0 === $entry_post_id ) {
						continue;
					}

					$seen = [];

					if ( ! empty( $entries[ $key ]['images'] ) && is_array( $entries[ $key ]['images'] ) ) {
						foreach ( $entries[ $key ]['images'] as $entry_image ) {
							// All in One SEO builds these with json_decode() and no
							// assoc flag, so each one is a stdClass. Its own sitemap
							// view casts them the same way before reading the key.
							$entry_image = (array) $entry_image;

							if ( ! empty( $entry_image['image:loc'] ) ) {
								$seen[ $entry_image['image:loc'] ] = true;
							}
						}
					}

					if ( ! isset( $srcs_by_post[ $entry_post_id ] ) ) {
						$srcs_by_post[ $entry_post_id ] = $this->get_envira_image_srcs_in_post( $entry_post_id );
					}

					foreach ( $srcs_by_post[ $entry_post_id ] as $src ) {
						if ( isset( $seen[ $src ] ) ) {
							continue;
						}

						$entries[ $key ]['images'][] = [ 'image:loc' => $src ];
						$seen[ $src ]                = true;
					}
				}

				break;

		}

		return $entries;
	}

	/**
	 * Image URLs of every Envira gallery embedded in a post or page.
	 *
	 * Both sitemap filters used to resolve this from the `_eg_in_posts` meta, which
	 * is written only by Envira\Admin\Editor — a class that loads behind
	 * `is_admin()`. Block-editor saves are REST requests, where `is_admin()` is
	 * false, so the meta was never written and no gallery image ever reached a
	 * sitemap. Reading the post's own content instead works whatever saved it, and
	 * covers posts saved before this fix without a migration.
	 *
	 * @since 1.17.3
	 *
	 * @param int $post_id Post or page ID.
	 * @return string[] Image URLs, de-duplicated, in content order.
	 */
	private function get_envira_image_srcs_in_post( $post_id ) {

		$srcs = [];

		foreach ( $this->get_envira_gallery_ids_in_post( $post_id ) as $gallery_id ) {
			if ( ! $this->is_publicly_listable( $gallery_id ) ) {
				continue;
			}

			$gallery = envira_get_gallery( $gallery_id );

			if ( ! is_array( $gallery ) || empty( $gallery['gallery'] ) || ! is_array( $gallery['gallery'] ) ) {
				continue;
			}

			if ( $this->is_inactive( $gallery ) ) {
				continue;
			}

			foreach ( $gallery['gallery'] as $image ) {
				if ( empty( $image['src'] ) || ! is_string( $image['src'] ) ) {
					continue;
				}

				$src = trim( $image['src'] );

				if ( '' !== $src ) {
					$srcs[ $src ] = $src;
				}
			}
		}

		return array_values( $srcs );
	}

	/**
	 * Gallery IDs referenced by a post's content, with albums expanded.
	 *
	 * @since 1.17.3
	 *
	 * @param int $post_id Post or page ID.
	 * @return int[] Gallery IDs, de-duplicated.
	 */
	private function get_envira_gallery_ids_in_post( $post_id ) {

		$post = get_post( $post_id );

		if ( ! $post instanceof \WP_Post || '' === trim( (string) $post->post_content ) ) {
			return [];
		}

		$gallery_ids = [];
		$album_ids   = [];

		$pattern = get_shortcode_regex( [ 'envira-gallery', 'envira-album' ] );
		$matched = preg_match_all( '/' . $pattern . '/s', $post->post_content, $matches, PREG_SET_ORDER );

		// preg_match_all() returns 0 for "no shortcodes" and false when PCRE gives
		// up — a long post can exhaust pcre.backtrack_limit on this pattern. Both
		// are falsy, so without this the engine failing looks exactly like the
		// empty sitemap this change exists to fix. Logged unconditionally for the
		// same reason Gutenberg::register_block() does: nothing else would show it.
		if ( false === $matched && PREG_NO_ERROR !== preg_last_error() ) {
			error_log( // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- deliberate: a silent regex failure here empties the sitemap with no other signal.
				sprintf(
					// preg_last_error_msg() is PHP 8.0+, and this plugin still runs on 7.x.
					'[Envira Gallery] Could not scan post %1$d for galleries: PCRE error %2$d. Its images are missing from the XML sitemap.',
					(int) $post->ID,
					preg_last_error()
				)
			);
		}

		if ( $matched ) {
			foreach ( $matches as $match ) {
				// [[envira-gallery id="1"]] renders as literal text, so it contributes
				// no images. Group 1 and 6 hold the escaping brackets.
				if ( '[' === $match[1] && ']' === $match[6] ) {
					continue;
				}

				$attrs = shortcode_parse_atts( $match[3] );
				$attrs = is_array( $attrs ) ? $attrs : [];

				if ( 'envira-album' === $match[2] ) {
					$album_ids[] = $this->resolve_envira_id( $attrs, 'envira_album' );
					continue;
				}

				$gallery_ids[] = $this->resolve_envira_id( $attrs, 'envira' );
			}
		}

		// The block's save() writes the shortcode inside its own delimiters, so the
		// parse above normally finds it. Read galleryId too, for content stored
		// without that inner shortcode.
		foreach ( $this->get_envira_block_gallery_ids( $post ) as $block_gallery_id ) {
			$gallery_ids[] = $block_gallery_id;
		}

		foreach ( array_filter( $album_ids ) as $album_id ) {
			$gallery_ids = array_merge( $gallery_ids, $this->get_gallery_ids_in_album( $album_id ) );
		}

		return array_values( array_unique( array_filter( $gallery_ids ) ) );
	}

	/**
	 * Gallery IDs carried by `envira/envira-gallery` blocks, including nested ones.
	 *
	 * @since 1.17.3
	 *
	 * @param \WP_Post $post Post object.
	 * @return int[]
	 */
	private function get_envira_block_gallery_ids( $post ) {

		if ( ! has_block( 'envira/envira-gallery', $post ) ) {
			return [];
		}

		$gallery_ids = [];
		$blocks      = parse_blocks( $post->post_content );

		while ( $blocks ) {
			$block = array_shift( $blocks );

			if ( ! empty( $block['innerBlocks'] ) ) {
				$blocks = array_merge( $blocks, $block['innerBlocks'] );
			}

			if ( 'envira/envira-gallery' !== $block['blockName'] || empty( $block['attrs']['galleryId'] ) ) {
				continue;
			}

			$gallery_ids[] = absint( $block['attrs']['galleryId'] );
		}

		return $gallery_ids;
	}

	/**
	 * Gallery IDs inside an album, capped like the album sitemap branch.
	 *
	 * @since 1.17.3
	 *
	 * @param int $album_id Album ID.
	 * @return int[]
	 */
	private function get_gallery_ids_in_album( $album_id ) {

		// The Albums addon owns envira_get_album(); it may not be active.
		if ( ! function_exists( 'envira_get_album' ) ) {
			return [];
		}

		if ( ! $this->is_publicly_listable( $album_id ) ) {
			return [];
		}

		$album = envira_get_album( $album_id );

		if ( ! is_array( $album ) || empty( $album['galleries'] ) || ! is_array( $album['galleries'] ) ) {
			return [];
		}

		$gallery_ids = [];

		// Capped at 50 galleries, matching the envira_album branch above.
		foreach ( array_slice( $album['galleries'], 0, 50 ) as $album_gallery ) {
			if ( ! empty( $album_gallery['id'] ) ) {
				$gallery_ids[] = absint( $album_gallery['id'] );
			}
		}

		return $gallery_ids;
	}

	/**
	 * The static front page's ID, when a sitemap entry points at the site root.
	 *
	 * WordPress maps the home URL to no post: url_to_postid() returns 0 because the
	 * front page is resolved by
	 * WP::parse_request() short-circuiting rather than by a rewrite rule — and the
	 * get_page_by_path() fallback cannot help either, because basename() of a bare
	 * site root is the host name. All in One SEO rewrites the static homepage
	 * entry's loc to exactly that root and lists it first at homePage priority, so
	 * without this the most important URL in the sitemap loses its gallery images.
	 *
	 * @since 1.17.3
	 *
	 * @param string $loc Sitemap entry URL.
	 * @return int Zero when the URL is not the site root, or the front page is the blog.
	 */
	private function get_front_page_id( $loc ) {

		if ( 'page' !== get_option( 'show_on_front' ) ) {
			return 0;
		}

		// Compare paths so a scheme or www difference between the stored home URL
		// and the emitted loc does not matter.
		$loc_path  = untrailingslashit( (string) wp_parse_url( (string) $loc, PHP_URL_PATH ) );
		$home_path = untrailingslashit( (string) wp_parse_url( home_url(), PHP_URL_PATH ) );

		if ( $loc_path !== $home_path ) {
			return 0;
		}

		return (int) get_option( 'page_on_front' );
	}

	/**
	 * Whether a gallery is switched off.
	 *
	 * Shortcode::setup() refuses to render an inactive gallery, so its images are
	 * not on the page and must not be listed as if they were.
	 *
	 * @since 1.17.3
	 *
	 * @param array $gallery Gallery data.
	 * @return bool
	 */
	private function is_inactive( $gallery ) {

		return isset( $gallery['status'] ) && 'inactive' === $gallery['status'];
	}

	/**
	 * Whether a gallery or album may appear in public sitemap output.
	 *
	 * Both envira_get_gallery() and envira_get_album() are bare `get_post_meta()`
	 * reads and return data for any status, trash included. The `_eg_in_posts` WP_Query
	 * this path replaced carried no `post_status`, so it defaulted to `publish` on
	 * front-end requests and filtered unpublished galleries out for free; resolving
	 * IDs from content has no such default.
	 *
	 * Asks WordPress which statuses are public rather than reusing the render paths'
	 * `envira_allowed_publish_statuses` filter. A sitemap is unauthenticated output
	 * served from cache to everyone, so it must not widen for whoever happened to
	 * trigger the build — and that filter is not safe to reuse here: Standalone
	 * defaults it to publish+private even for anonymous visitors and Shortcode
	 * widens it again for users who can edit, so a callback written for either
	 * would quietly publish private gallery images. Deriving the set from
	 * registered statuses still honours a custom public status.
	 *
	 * @since 1.17.3
	 *
	 * @param int $post_id Gallery or album post ID.
	 * @return bool
	 */
	private function is_publicly_listable( $post_id ) {

		$status = get_post_status( $post_id );

		if ( ! $status ) {
			return false;
		}

		// The Password Protection addon gates on the gallery's own post_password, and
		// every SEO plugin here filters post_password only on the post carrying the
		// entry — never on a gallery embedded inside it. Checked as a field rather
		// than with post_password_required(), because a cached sitemap must not vary
		// with whoever's cookies happened to trigger the build.
		if ( '' !== (string) get_post_field( 'post_password', $post_id ) ) {
			return false;
		}

		return in_array( $status, get_post_stati( [ 'public' => true ] ), true );
	}

	/**
	 * Resolves a gallery or album ID from shortcode attributes.
	 *
	 * @since 1.17.3
	 *
	 * @param array  $attrs     Parsed shortcode attributes.
	 * @param string $post_type Either `envira` or `envira_album`.
	 * @return int Zero when the attributes name nothing resolvable.
	 */
	private function resolve_envira_id( $attrs, $post_type ) {

		if ( ! empty( $attrs['id'] ) && is_numeric( $attrs['id'] ) ) {
			return absint( $attrs['id'] );
		}

		if ( empty( $attrs['slug'] ) ) {
			return 0;
		}

		$slug = sanitize_title( $attrs['slug'] );

		if ( 'envira_album' === $post_type ) {
			if ( ! function_exists( 'envira_get_album_by_slug' ) ) {
				return 0;
			}

			$album = envira_get_album_by_slug( $slug );

			return is_array( $album ) && ! empty( $album['id'] ) ? absint( $album['id'] ) : 0;
		}

		$gallery = envira_get_gallery_by_slug( $slug );

		return is_array( $gallery ) && ! empty( $gallery['id'] ) ? absint( $gallery['id'] ) : 0;
	}
}
