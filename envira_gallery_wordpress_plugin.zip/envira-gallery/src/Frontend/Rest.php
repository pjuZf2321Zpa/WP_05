<?php
/**
 * Envira Gallery Rest Class.
 *
 * @since 1.8.5
 *
 * @package Envira Gallery
 * @author  Envira Gallery Team <support@enviragallery.com>
 */

namespace Envira\Frontend;

use Envira\Utils\Shortcode_Utils;
use Envira\Utils\Sanitize_Utils;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {

	exit;

}

/**
 * Rest Class for envira.
 */
class Rest {

	/**
	 * Images refused by the last gallery_data update in this request.
	 *
	 * @since 1.17.2
	 *
	 * @var int
	 */
	private $gallery_skipped = 0;

	/**
	 * Class Constructor
	 *
	 * @since 1.8.5
	 */
	public function __construct() {
		$this->init();
	}

	/**
	 * Helper Init Method
	 *
	 * @since 1.8.8
	 *
	 * @return void
	 */
	public function init() {
		add_action( 'rest_api_init', [ $this, 'register_post_meta' ] );
		add_filter( 'rest_pre_insert_envira', [ $this, 'reject_refused_gallery_items' ], 10, 2 );
		add_filter( 'rest_prepare_envira', [ $this, 'add_gallery_skipped' ], 10, 1 );
	}

	/**
	 * Reports how many images the gallery_data update refused, so the block can say so.
	 *
	 * Core runs field update callbacks before preparing the response, so the count is
	 * already set when this filter runs. Only added when something was refused.
	 *
	 * @since 1.17.2
	 *
	 * @param \WP_REST_Response $response Response object.
	 * @return \WP_REST_Response
	 */
	public function add_gallery_skipped( $response ) {
		if ( $this->gallery_skipped > 0 && $response instanceof \WP_REST_Response ) {
			$data                    = $response->get_data();
			$data['gallery_skipped'] = $this->gallery_skipped;
			$response->set_data( $data );
		}

		// Consumed: a later item in the same request (e.g. /batch/v1) starts from zero.
		$this->gallery_skipped = 0;

		return $response;
	}

	/**
	 * Refuses a gallery create/update whose images are all ones the user may not add.
	 *
	 * The gallery_data field callback runs after the post is saved, so refusing there
	 * would still leave a new, empty, published gallery behind on create. Checking here
	 * stops the request before anything is written.
	 *
	 * @since 1.17.2
	 *
	 * @param \stdClass|\WP_Error $prepared_post Post about to be inserted.
	 * @param \WP_REST_Request    $request       Request object.
	 * @return \stdClass|\WP_Error
	 */
	public function reject_refused_gallery_items( $prepared_post, $request ) {
		if ( is_wp_error( $prepared_post ) ) {
			return $prepared_post;
		}

		$value = $request->get_param( 'gallery_data' );

		if ( ! is_array( $value ) || empty( $value['gallery'] ) || ! is_array( $value['gallery'] ) ) {
			return $prepared_post;
		}

		$gallery_id = isset( $prepared_post->ID ) ? (int) $prepared_post->ID : 0;

		foreach ( $value['gallery'] as $image ) {
			if ( is_array( $image ) && ! empty( $image['id'] ) && envira_gallery_user_can_insert_attachment( $image['id'], $gallery_id ) ) {
				return $prepared_post;
			}
		}

		return new \WP_Error( 'rest_forbidden', esc_html__( 'You are not allowed to add the selected images to this gallery.', 'envira-gallery' ), [ 'status' => 403 ] );
	}

	/**
	 * Helper Method to register Envira gallery Meta
	 *
	 * @since 1.8.5
	 *
	 * @return void
	 */
	public function register_post_meta() {
		// Probably to be used with gutenberg part later.
		// ( new Overlay_Rest() )->register_routes();.
		register_rest_field(
			'envira',
			'gallery_data',
			[
				'get_callback'    => [ $this, 'get_gallery_data' ],
				'update_callback' => [ $this, 'update_gallery_data' ],
			]
		);
	}

	/**
	 * Rest API callback to get gallery data.
	 *
	 * @param [type] $post_object Post Object.
	 * @param [type] $field_name Rest Field Name.
	 * @param [type] $request Rest Request.
	 * @return array
	 */
	public function get_gallery_data( $post_object, $field_name, $request ) {

		$data = get_post_meta( $post_object['id'], '_eg_gallery_data', true );

		if ( ! is_array( $data ) ) {
			$data = [];
		}

		$data   = ( ! isset( $data['config']['layout'] ) ) ? envira_convert_columns_to_layouts( $data, $data['id'] ?? $post_object['id'] ) : envira_override_layout_settings( $data );
		$i      = 0;
		$images = [];

		$data = apply_filters( 'envira_gallery_pre_data', $data, $post_object['id'] );

		if ( isset( $data['gallery'] ) && is_array( $data['gallery'] ) ) {

			foreach ( $data['gallery'] as $id => $item ) {

				// Skip over images that are pending (ignore if in Preview mode).
				if ( isset( $item['status'] ) && 'pending' === $item['status'] && ! is_preview() ) {
					continue;
				}

				$width    = null;
				$height   = null;
				$imagesrc = envira_get_image_src( $id, $item, $data, false, false );

				// Prefer cached attachment metadata so we never have to touch the filesystem
				// (avoids blocking on slow/broken remote stream wrappers like S3/Infinite Uploads).
				$attachment_meta = wp_get_attachment_metadata( $id );
				$image_size      = envira_get_config( 'image_size', $data );
				$crop_enabled    = (bool) envira_get_config( 'crop', $data );

				if ( 'default' === $image_size && $crop_enabled ) {

					// Hard-cropped images (e.g. the Square layout) come out at the configured
					// crop dimensions ONLY when the crop actually succeeded — trust the "-WxH"
					// suffix envira_resize_image() writes over the config, since a failed crop
					// falls back to the un-cropped original (image.php), which carries no suffix
					// and leaves width/height null here to cascade to the metadata fallback below.
					$suffix_dims = envira_get_dimensions_from_filename( $imagesrc, $attachment_meta );

					if ( $suffix_dims ) {
						list( $width, $height ) = $suffix_dims;
					}
				} elseif ( 'default' === $image_size && ! $crop_enabled ) {

					$closest_size = envira_find_clostest_size( $data );
					$isize        = ( is_string( $closest_size ) && '' !== $closest_size ) ? $closest_size : 'full';

					if ( isset( $attachment_meta['sizes'][ $isize ]['width'], $attachment_meta['sizes'][ $isize ]['height'] ) ) {
						$width  = $attachment_meta['sizes'][ $isize ]['width'];
						$height = $attachment_meta['sizes'][ $isize ]['height'];
					}
				} elseif ( ! in_array( $image_size, [ 'full', 'envira_gallery_random' ], true )
					&& isset( $attachment_meta['sizes'][ $image_size ]['width'], $attachment_meta['sizes'][ $image_size ]['height'] ) ) {

					// A specific registered WordPress image size was selected — use that
					// size's own metadata, since it rarely matches the main file's ratio.
					$width  = $attachment_meta['sizes'][ $image_size ]['width'];
					$height = $attachment_meta['sizes'][ $image_size ]['height'];
				}

				if ( ! $width || ! $height ) {

					$suffix_dims = envira_get_dimensions_from_filename( $imagesrc, $attachment_meta );

					if ( $suffix_dims ) {

						list( $width, $height ) = $suffix_dims;

					} elseif ( isset( $attachment_meta['width'], $attachment_meta['height'] ) && empty( $attachment_meta['original_image'] ) ) {

						// Top-level width/height are only the true original when WordPress
						// hasn't scaled it down for storage (big_image_size_threshold, WP 5.3+)
						// — when 'original_image' is set, these describe the "-scaled"
						// derivative instead, while $imagesrc here (envira_get_image_src()
						// deliberately returns the pre-scale original for 'full'/random sizes)
						// points at the real original, so trusting them would advertise the
						// wrong dimensions. Fall through to measuring the real file instead.
						$width  = $attachment_meta['width'];
						$height = $attachment_meta['height'];

					} else {

						// Get the image file path.
						$urlinfo       = wp_parse_url( $imagesrc );
						$wp_upload_dir = wp_upload_dir();

						// Interpret the file path of the image.
						if ( preg_match( '/\/[0-9]{4}\/[0-9]{2}\/.+$/', $urlinfo['path'], $matches ) ) {

							$file_path = $wp_upload_dir['basedir'] . $matches[0];

						} else {

							$content_dir = defined( 'WP_CONTENT_DIR' ) ? WP_CONTENT_DIR : '/wp-content/';
							$uploads_dir = is_multisite() ? '/files/' : $content_dir;
							$file_path   = trailingslashit( $wp_upload_dir['basedir'] ) . basename( $urlinfo['path'] );

						}

						// Never run getimagesize() against a stream-wrapped path (s3://, iu://, etc.) — a
						// slow or unhealthy remote would block the request until max_execution_time is hit,
						// silently killing block-editor publish. Only stat/read genuinely local files.
						// Computed before the "//" collapse below: collapsing "scheme://" into
						// "scheme:/" would otherwise hide the stream wrapper from this guard.
						$is_remote = (bool) preg_match( '#^[a-z][a-z0-9+.\-]*://#i', $file_path );

						if ( $is_remote ) {

							// Can't safely stat a remote/stream-wrapped path — fall back to an
							// attachment-metadata-derived size instead of leaving width/height
							// null, which publishes as 0x0 and breaks the block editor's
							// aspect-ratio math. attachment_meta['sizes']['full'] is never set
							// for images (WordPress only writes it for PDF preview attachments),
							// so ask WordPress itself for the size it considers "full" instead.
							$fallback_src = wp_get_attachment_image_src( $id, 'full' );

							// Test for usable values, not merely present ones. With no cached
							// dimensions, image_downsize() initialises 0/0, finds no 'full'
							// intermediate, and returns [ $url, 0, 0, false ] - which isset()
							// accepts, so 0x0 was assigned AND the diagnostic below was skipped
							// for exactly the case it documents.
							if ( is_array( $fallback_src ) && ! empty( $fallback_src[1] ) && ! empty( $fallback_src[2] ) ) {
								$width  = $fallback_src[1];
								$height = $fallback_src[2];
							}
						} else {

							$file_path = preg_replace( '/(\/\/)/', '/', $file_path );

							// Contain path resolution to the uploads directory so a crafted gallery
							// src (e.g. containing "../" segments) can't stat/read arbitrary files.
							$real_path = realpath( $file_path );
							$real_base = realpath( $wp_upload_dir['basedir'] );

							if ( $real_path && $real_base && 0 === strpos( $real_path, trailingslashit( $real_base ) ) && is_file( $real_path ) ) {
								$imagesize = getimagesize( $real_path );

								if ( is_array( $imagesize ) ) {
									list( $width, $height ) = $imagesize;
								}
							}
						}
					}
				}

				// Terminal fallbacks: avoid publishing 0x0, which the block editor's
				// aspect-ratio maths and the justified/automatic row heights divide by.
				// Reached when a scaled attachment's pre-scale original is gone, cached
				// dimensions are stored as literal 0, realpath() fails, containment
				// rejects the path, or getimagesize() returns false.
				if ( ! $width || ! $height ) {

					$last_resort = wp_get_attachment_image_src( $id, 'full' );

					if ( is_array( $last_resort ) && ! empty( $last_resort[1] ) && ! empty( $last_resort[2] ) ) {
						$width  = $last_resort[1];
						$height = $last_resort[2];
					}
				}

				// A genuinely different source than the two attempts above, which both go
				// through image_downsize() and so both return 0/0 for a remote attachment
				// with no cached dimensions. Any real registered size beats 0x0.
				if ( ! $width || ! $height ) {

					$largest = 0;

					if ( ! empty( $attachment_meta['sizes'] ) && is_array( $attachment_meta['sizes'] ) ) {
						foreach ( $attachment_meta['sizes'] as $size_meta ) {
							if ( ! empty( $size_meta['width'] ) && ! empty( $size_meta['height'] ) && $size_meta['width'] > $largest ) {
								$largest = $size_meta['width'];
								$width   = $size_meta['width'];
								$height  = $size_meta['height'];
							}
						}
					}
				}

				// Nothing could resolve it: the attachment needs its metadata regenerated.
				// Bounded per attachment for a day - this field is anonymously readable, so
				// an un-throttled write would let any visitor append a line per request -
				// and only the ID is interpolated, since $imagesrc traces back to
				// _eg_gallery_data, which an edit_posts-capable user controls and whose
				// newlines would forge log entries.
				if ( ( ! $width || ! $height ) && ! get_transient( 'envira_missing_dims_' . $id ) ) {

					set_transient( 'envira_missing_dims_' . $id, 1, DAY_IN_SECONDS );

					error_log( sprintf( 'Envira Gallery: no cached dimensions for attachment %d; regenerate its metadata. Further reports for this attachment are suppressed for 24 hours.', $id ) ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
				}

				$item['src']    = $imagesrc;
				$item['id']     = $id;
				$item['height'] = intval( $height );
				$item['width']  = intval( $width );
				$images[ $i ]   = $item;

				++$i;
			}
			$data['gallery'] = $images;

		}

		if ( ! isset( $data['config'] ) || ! is_array( $data['config'] ) ) {
			$data['config'] = [];
		}

		$data['config']['title'] = wp_strip_all_tags( get_the_title( $post_object['id'] ) );

		$data['config']['description'] = Shortcode_Utils::get_description( $data );

		return $data;
	}

	/**
	 * Rest API updater callback.
	 *
	 * @since 1.8.5
	 *
	 * @param array  $value Value to update.
	 * @param object $post Post Object.
	 * @param string $field_name Meta field name.
	 *
	 * @return array
	 */
	public function update_gallery_data( $value, $post, $field_name ) {

		$gallery_data = get_post_meta( $post->ID, '_eg_gallery_data', true );

		// If Gallery Data is emptyy prepare it.
		if ( ! is_array( $gallery_data ) ) {
			$gallery_data = [];
		}

		if ( ! isset( $gallery_data['config'] ) ) {
			$gallery_data['config'] = [];
		}

		if ( ! is_array( $gallery_data['config'] ) || empty( $gallery_data['config'] ) ) {
			// Loop through the defaults and prepare them to be stored.
			$defaults = envira_get_config_defaults( $post->ID );

			foreach ( $defaults as $key => $default ) {

				$gallery_data['config'][ $key ] = $default;

			}
		}

		// Update Fields.
		$gallery_data['id'] = $post->ID;

		// WP_Post has no `title` property, so `$post->title` fell through
		// WP_Post::__get() to get_post_meta( ID, 'title' ) - absent on most sites,
		// which blanked the stored title, and wrote an unrelated value where that
		// meta existed. post_title rather than get_the_title(), because this is
		// stored and later rendered and get_the_title() prepends a localized
		// "Private: "/"Protected: " prefix that would be baked into the title.
		$gallery_data['config']['title'] = wp_strip_all_tags( $post->post_title );

		if ( isset( $value['config'] ) ) {
			// Sanitize config values before saving to prevent XSS
			$value['config']        = $this->sanitize_config_values( $value['config'] );
			$gallery_data['config'] = wp_parse_args( $value['config'], $gallery_data['config'] );
		}

		if ( isset( $value['remove_image'] ) ) {
			$in_gallery  = get_post_meta( $post->ID, '_eg_in_gallery', true );
			$has_gallery = get_post_meta( $value['attach_id'], '_eg_has_gallery', true );

			// Unset the image from the gallery, in_gallery and has_gallery checkers.
			unset( $gallery_data['gallery'][ $value['attach_id'] ] );

			$key = array_search( $value['attach_id'], (array) $in_gallery, true );

			if ( false !== $key ) {
				unset( $in_gallery[ $key ] );
			}

			$has_key = array_search( $post->ID, (array) $has_gallery, true );

			if ( false !== $has_key ) {
				unset( $has_gallery[ $has_key ] );
			}
		}

		if ( isset( $value['update_image'] ) ) {

			$attach_id    = $value['attach_id'];
			$update_image = $value['updated_image'];

			// Only edit an item already in the gallery; this branch must not add one.
			if ( ! isset( $gallery_data['gallery'][ $attach_id ] ) ) {
				return new \WP_Error( 'rest_forbidden', esc_html__( 'That image is not in this gallery.', 'envira-gallery' ), [ 'status' => 403 ] );
			}

			if ( isset( $update_image['title'] ) ) {
				$gallery_data['gallery'][ $attach_id ]['title'] = trim( $update_image['title'] );
			}
			if ( isset( $update_image['caption'] ) ) {
				$gallery_data['gallery'][ $attach_id ]['caption'] = trim( $update_image['caption'] );
			}
		}
		$this->gallery_skipped = 0;

		if ( isset( $value['gallery'] ) ) {
			$requested = count( (array) $value['gallery'] );
			$accepted  = 0;

			foreach ( (array) $value['gallery'] as $i => $image ) {
				// Only attachments the user can edit, matching the AJAX image writers.
				if ( ! is_array( $image ) || empty( $image['id'] ) || ! envira_gallery_user_can_insert_attachment( $image['id'], $post->ID ) ) {
					continue;
				}

				$gallery_data = envira_prepare_gallery_data( $gallery_data, $image['id'] );
				++$accepted;
			}

			$this->gallery_skipped = $requested - $accepted;

			// Every item was refused: fail the request instead of saving as if it worked.
			if ( $requested > 0 && 0 === $accepted ) {
				return new \WP_Error( 'rest_forbidden', esc_html__( 'You are not allowed to add the selected images to this gallery.', 'envira-gallery' ), [ 'status' => 403 ] );
			}
		}

		// Flush gallery cache.
		envira_flush_gallery_caches( $post->ID );

		return update_post_meta( $post->ID, '_eg_gallery_data', $gallery_data );
	}

	/**
	 * Sanitizes config values to prevent XSS attacks.
	 *
	 * Uses shared Sanitize_Utils helper to eliminate code duplication and maintain
	 * consistent validation logic across REST API and frontend rendering.
	 *
	 * @since 1.13.2
	 *
	 * @param array $config The config array to sanitize.
	 * @return array Sanitized config array.
	 */
	private function sanitize_config_values( $config ) {
		// Sanitize title to prevent stored XSS via the REST API. This key is set from
		// the post title just above, but wp_parse_args() lets a request body's own
		// config.title win over that, and the renderers run it through
		// htmlspecialchars_decode() into unescaped markup. The block client never
		// sends it; anything that does gets tags stripped.
		if ( isset( $config['title'] ) ) {
			$config['title'] = sanitize_text_field( is_scalar( $config['title'] ) ? (string) $config['title'] : '' );
		}

		// Sanitize description to prevent stored XSS via the REST API.
		// REST payloads can supply any JSON type, so guard against non-scalar values before
		// passing to wp_kses_post() which expects a string (fatal on PHP 8.1+ otherwise).
		if ( isset( $config['description'] ) ) {
			$description = is_scalar( $config['description'] ) ? (string) $config['description'] : '';

			$config['description'] = wp_kses_post( $description );
		}

		// Sanitize justified_gallery_theme - ensure it's a valid theme
		if ( isset( $config['justified_gallery_theme'] ) ) {
			$valid_themes       = envira_get_justified_gallery_themes();
			$valid_theme_values = Sanitize_Utils::extract_values( $valid_themes );

			$config['justified_gallery_theme'] = Sanitize_Utils::sanitize_against_allowlist(
				$config['justified_gallery_theme'],
				$valid_theme_values,
				envira_get_config_default( 'justified_gallery_theme' )
			);
		}

		// Sanitize justified_gallery_theme_detail - ensure it's a valid theme detail
		if ( isset( $config['justified_gallery_theme_detail'] ) ) {
			$valid_details       = envira_get_justified_gallery_themes_details();
			$valid_detail_values = Sanitize_Utils::extract_values( $valid_details );

			$config['justified_gallery_theme_detail'] = Sanitize_Utils::sanitize_against_allowlist(
				$config['justified_gallery_theme_detail'],
				$valid_detail_values,
				envira_get_config_default( 'justified_gallery_theme_detail' )
			);
		}

		// Sanitize justified_row_height - ensure it's a positive integer
		if ( isset( $config['justified_row_height'] ) ) {
			$row_height = absint( $config['justified_row_height'] );
			if ( $row_height <= 0 ) {
				$row_height = envira_get_config_default( 'justified_row_height' );
			}
			$config['justified_row_height'] = $row_height;
		}

		if ( isset( $config['horizontal_carousel_autoplay'] ) ) {
			$config['horizontal_carousel_autoplay'] = filter_var( $config['horizontal_carousel_autoplay'], FILTER_VALIDATE_BOOLEAN ) ? 1 : 0;
		}
		if ( isset( $config['horizontal_carousel_loop'] ) ) {
			$config['horizontal_carousel_loop'] = filter_var( $config['horizontal_carousel_loop'], FILTER_VALIDATE_BOOLEAN ) ? 1 : 0;
		}
		if ( isset( $config['horizontal_carousel_mousewheel'] ) ) {
			$config['horizontal_carousel_mousewheel'] = filter_var( $config['horizontal_carousel_mousewheel'], FILTER_VALIDATE_BOOLEAN ) ? 1 : 0;
		}
		if ( isset( $config['horizontal_carousel_autoplay_delay'] ) ) {
			$config['horizontal_carousel_autoplay_delay'] = max( 500, absint( $config['horizontal_carousel_autoplay_delay'] ) );
		}

		return $config;
	}
}
