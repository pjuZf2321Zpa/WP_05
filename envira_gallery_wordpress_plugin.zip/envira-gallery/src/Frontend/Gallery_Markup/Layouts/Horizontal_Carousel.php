<?php
/**
 * Horizontal Carousel layout class.
 *
 * @since ??
 *
 * @package Envira_Gallery
 * @author  Envira Gallery Team <support@enviragallery.com>
 */

namespace Envira\Frontend\Gallery_Markup\Layouts;

use Envira\Frontend\Gallery_Markup\Base;

/**
 * Horizontal Carousel layout class.
 */
class Horizontal_Carousel extends Base {

	/**
	 * Generate wrapper classes
	 *
	 * @return array
	 */
	protected function get_wrapper_classes() {
		$classes   = parent::get_wrapper_classes();
		$classes[] = 'envira-layout-horizontal-carousel';
		$classes[] = 'envira-gallery-theme-' . envira_get_config( 'gallery_theme', $this->data );

		return $classes;
	}

	/**
	 * Get container tag (Swiper web component).
	 *
	 * @return string
	 */
	protected function get_container_tag() {
		return 'swiper-container';
	}

	/**
	 * Get container class.
	 *
	 * @return array
	 */
	protected function get_container_classes() {
		$classes   = parent::get_container_classes();
		$classes[] = 'envira-layout-horizontal-carousel--container';

		return $classes;
	}

	/**
	 * Get container extra attributes (inline CSS vars + Swiper web component params as kebab-case attributes).
	 *
	 * @return array
	 */
	protected function get_container_extra_attrs() {
		$crop_width  = absint( envira_get_config( 'crop_width', $this->data ) );
		$crop_height = absint( envira_get_config( 'crop_height', $this->data ) );

		// Use admin Image Dimensions when set; fallback to horizontal-carousel defaults.
		$hc_defaults = envira_get_horizontal_carousel_image_dimension_defaults();
		if ( ! $crop_width ) {
			$crop_width = $hc_defaults['crop_width'];
		}
		if ( ! $crop_height ) {
			$crop_height = $hc_defaults['crop_height'];
		}

		$slide_width     = $crop_width . 'px';
		$slide_min_width = min( $crop_width, 200 ) . 'px';
		$slide_max_width = $crop_width . 'px';

		$vars = [
			'--envira-carousel-slide-width: ' . $slide_width,
			'--envira-carousel-slide-min-width: ' . $slide_min_width,
			'--envira-carousel-slide-max-width: ' . $slide_max_width,
		];

		$style = 'style="' . esc_attr( implode( '; ', $vars ) ) . '"';

		// Responsive: below 768px — centered slides, slidesPerView auto (width from CSS for peek); 768px+ — left-aligned strip, 20px gap.
		$breakpoints = wp_json_encode(
			array(
				'768' => array(
					'centeredSlides'           => false,
					'centerInsufficientSlides' => false,
					'spaceBetween'             => 20,
				),
			)
		);

		// Swiper web component: params as kebab-case attributes (no swiper-wrapper; slides are direct children).
		// Mobile-first (<768): slides-per-view auto + centeredSlides so active slide is centered (numeric slidesPerView + fixed CSS widths breaks offset math).
		$attrs = [
			$style,
			'centered-slides="true"',
			'center-insufficient-slides="true"',
			'slides-per-view="auto"',
			'space-between="10"',
			'breakpoints="' . esc_attr( $breakpoints ) . '"',
			'grab-cursor="true"',
			'simulate-touch="true"',
			'touch-ratio="1"',
			'touch-angle="45"',
			'threshold="5"',
			'resistance="true"',
			'resistance-ratio="0.85"',
			'allow-touch-move="true"',
			'allow-slide-prev="true"',
			'allow-slide-next="true"',
		];

		$mousewheel = filter_var( envira_get_config( 'horizontal_carousel_mousewheel', $this->data ), FILTER_VALIDATE_BOOLEAN );
		if ( $mousewheel ) {
			$attrs[] = 'mousewheel-enabled="true"';
		}

		$loop = filter_var( envira_get_config( 'horizontal_carousel_loop', $this->data ), FILTER_VALIDATE_BOOLEAN );
		if ( $loop ) {
			$attrs[] = 'loop="true"';
		}

		$autoplay = filter_var( envira_get_config( 'horizontal_carousel_autoplay', $this->data ), FILTER_VALIDATE_BOOLEAN );
		if ( $autoplay ) {
			$delay = absint( envira_get_config( 'horizontal_carousel_autoplay_delay', $this->data ) );
			if ( $delay < 500 ) {
				$delay = 500;
			}
			$attrs[] = 'autoplay="true"';
			$attrs[] = 'autoplay-delay="' . esc_attr( (string) $delay ) . '"';
			// Resume autoplay after user interaction (Swiper default stops otherwise).
			$attrs[] = 'autoplay-disable-on-interaction="false"';
		}

		return $attrs;
	}

	/**
	 * Get container inner markup before the item loop (Swiper web component has no wrapper).
	 *
	 * @return string
	 */
	protected function get_container_inner_before() {
		return '';
	}

	/**
	 * Get container inner markup after the item loop.
	 *
	 * @return string
	 */
	protected function get_container_inner_after() {
		return '';
	}

	/**
	 * Get item object.
	 *
	 * @param array $config Item config.
	 *
	 * @return Horizontal_Carousel_Item
	 */
	protected function get_item_object( $config ) {
		return new Horizontal_Carousel_Item( $config );
	}
}
