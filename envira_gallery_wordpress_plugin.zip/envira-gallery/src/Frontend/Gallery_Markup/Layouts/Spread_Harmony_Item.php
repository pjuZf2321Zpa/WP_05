<?php
/**
 * Spread Harmony layout item class.
 *
 * @since ??
 *
 * @package Envira_Gallery
 * @author  Envira Gallery Team <support@enviragallery.com>
 */

namespace Envira\Frontend\Gallery_Markup\Layouts;

use Envira\Frontend\Gallery_Markup\Item;

/**
 * Spread Harmony item class.
 */
class Spread_Harmony_Item extends Item {
	/**
	 * Remove title and caption.
	 *
	 * @return string
	 */
	protected function gallery_image_caption_titles() {
		return '';
	}
}
