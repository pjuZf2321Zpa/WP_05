<?php
/**
 * Horizontal Carousel item layout class.
 *
 * @since ??
 *
 * @package Envira_Gallery
 * @author  Envira Gallery Team <support@enviragallery.com>
 */

namespace Envira\Frontend\Gallery_Markup\Layouts;

use Envira\Frontend\Gallery_Markup\Item;

/**
 * Horizontal Carousel item class. Wraps each gallery item in swiper-slide (Swiper web component).
 */
class Horizontal_Carousel_Item extends Item {

	/**
	 * Generate single item markup wrapped in a swiper-slide element.
	 *
	 * @return string
	 */
	public function markup() {
		return '<swiper-slide>' . parent::markup() . '</swiper-slide>';
	}

	/**
	 * Suppress gutter padding on carousel slides.
	 *
	 * Swiper spaces slides via its `space-between` option, so the gallery's stored
	 * gutter must not add left/right padding here. Pinning the gutter to 0 (rather than
	 * zeroing the stored config) keeps that value meaningful for other layouts after a
	 * layout switch, while preserving the base item's margin and aspect-ratio.
	 *
	 * @param numeric $gutter Gutter size (ignored; forced to 0 for carousel slides).
	 * @param numeric $margin Margin.
	 *
	 * @return string
	 */
	protected function get_item_wrapper_styles( $gutter, $margin ) {
		return parent::get_item_wrapper_styles( 0, $margin );
	}
}
