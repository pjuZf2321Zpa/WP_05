<?php
/**
 * Horizontal slideshow item layout class.
 *
 * Wraps each gallery item in a <swiper-slide> element for the
 * SwiperJS web component stage.
 *
 * @since 1.10.5
 *
 * @package Envira_Gallery
 * @author  Envira Gallery Team <support@enviragallery.com>
 */

namespace Envira\Frontend\Gallery_Markup\Layouts;

use Envira\Frontend\Gallery_Markup\Item;
use Envira\Utils\Shortcode_Utils;

/**
 * Horizontal_Slideshow_Item class.
 */
class Horizontal_Slideshow_Item extends Item {

	/**
	 * Wrap the standard item markup inside a <swiper-slide> element.
	 *
	 * @return string
	 */
	public function markup() {
		add_filter( 'envira_gallery_output_item_srcset', [ $this, 'filter_slideshow_lazy_srcset' ], 10, 7 );
		$item_markup = parent::markup();
		remove_filter( 'envira_gallery_output_item_srcset', [ $this, 'filter_slideshow_lazy_srcset' ], 10 );
		$index = max( 0, $this->count - 1 );

		return "<swiper-slide data-envira-slide-index=\"$index\">$item_markup</swiper-slide>";
	}

	/**
	 * Lazy loading swaps srcset for a 1x1 placeholder; browsers may prefer that over src,
	 * so the main stage can show a flat/washed block. Keep a real srcset for this layout;
	 * enviraLazy still upgrades from data-envira-src / data-envira-srcset.
	 *
	 * @param string $srcset            Filtered srcset value.
	 * @param string $image_src_retina Retina source URL.
	 * @param array  $item             Image item data.
	 * @param int    $item_id          Attachment ID.
	 * @param array  $data             Gallery data.
	 * @param int    $count            Item index.
	 * @param bool   $is_mobile        Whether this is the mobile gallery output.
	 *
	 * @return string
	 */
	public function filter_slideshow_lazy_srcset( $srcset, $image_src_retina, $item, $item_id, $data, $count, $is_mobile ) {
		unset( $item_id, $count, $is_mobile );
		if ( ! Shortcode_Utils::is_lazy_loading( $data ) ) {
			return $srcset;
		}
		if ( $image_src_retina && envira_is_image( $image_src_retina ) ) {
			return "{$image_src_retina}, {$image_src_retina} 2x";
		}
		if ( ! empty( $item['src'] ) ) {
			return esc_url( $item['src'] );
		}

		return $srcset;
	}

	/**
	 * Defer every slide after the first; Swiper preloads the neighbors (lazyPreloadPrevNext).
	 * Respects the gallery's lazy loading setting and the core wp_lazy_loading_enabled filter.
	 *
	 * @param string $output_width  Output width.
	 * @param string $output_height Output height.
	 *
	 * @return array
	 */
	protected function img_extra_attrs( $output_width, $output_height ) {
		unset( $output_width, $output_height );

		if ( $this->count <= 1 || ! Shortcode_Utils::is_lazy_loading( $this->data ) || ! wp_lazy_loading_enabled( 'img', 'envira_gallery' ) ) {
			return [];
		}

		return [ 'loading="lazy"' ];
	}

	/**
	 * The slideshow layout controls spacing itself, so remove default padding.
	 *
	 * @param numeric $gutter Gutter size.
	 * @param numeric $margin Margin.
	 *
	 * @return string
	 */
	protected function get_item_wrapper_styles( $gutter, $margin ) {
		return '';
	}

	/**
	 * Skip the lazy-loading padding-bottom wrapper inside slideshow slides.
	 * The stage controls layout dimensions, and the padding-bottom wrapper
	 * interferes with the single-image presentation.
	 *
	 * @param numeric $img_height Image tag height attr.
	 * @param numeric $img_width Image tag width attr.
	 *
	 * @return array{start: string, end: string}
	 */
	protected function get_img_wrapper( $img_height, $img_width ) {
		return [
			'start' => '',
			'end'   => '',
		];
	}
}
