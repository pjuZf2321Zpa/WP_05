<?php
/**
 * Mason item layout class.
 *
 * @since ??
 *
 * @package Envira_Gallery
 * @author  Envira Gallery Team <support@enviragallery.com>
 */

namespace Envira\Frontend\Gallery_Markup\Layouts;

use Envira\Frontend\Gallery_Markup\Item;
use Envira\Utils\Shortcode_Utils;

/**
 * Mason item class.
 */
class BnB_Overlay_Item extends Item {
	/**
	 * Automatic layout displays the caption and title on hover.
	 *
	 * @return string
	 */
	protected function gallery_image_caption_titles() {
		return '';
	}

	/**
	 * Helper method for getting item wrapper styles.
	 *
	 * The overlay grid spaces its items with `gap`, so the parent's padding is
	 * dropped. The ratio is not: each item is a flex item whose width comes from
	 * its content, and while a lazy-load placeholder stands in there is no ratio
	 * to derive it from, so the item collapses to a square until the real image
	 * arrives. Declaring the ratio against the item's fixed height resolves the
	 * width up front, loaded or not.
	 *
	 * @param numeric $gutter Gutter size.
	 * @param numeric $margin Margin.
	 *
	 * @return string
	 */
	protected function get_item_wrapper_styles( $gutter, $margin ) {
		$ratio = $this->get_display_dimensions();

		if ( empty( $ratio ) ) {
			if ( is_envira_debug_on() ) {
				error_log( sprintf( 'Envira Gallery: no usable dimensions for BnB overlay item %d, so the item keeps the placeholder shape.', (int) $this->item_id ) ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
			}

			return '';
		}

		return "aspect-ratio: {$ratio['width']} / {$ratio['height']};";
	}

	/**
	 * Dimensions describing the shape the item will actually display, or an empty
	 * array when none of the sources hold a usable pair.
	 *
	 * @return array{width: int, height: int}|array{}
	 */
	private function get_display_dimensions() {
		$candidates = [];

		// The mobile path serves its own hard-cropped file (see get_image_tag(),
		// which reaches for the mobile source before it looks at anything else), so
		// that file's shape wins over both the crop settings and the attachment.
		if ( $this->is_mobile && envira_get_config( 'mobile', $this->data ) ) {
			$candidates[] = [
				'width'  => envira_get_config( 'mobile_width', $this->data ),
				'height' => envira_get_config( 'mobile_height', $this->data ),
			];
		}

		// With cropping on the file really is crop_width by crop_height, so the
		// dimensions the image tag resolved describe the shape on screen.
		if ( envira_get_config( 'crop', $this->data ) ) {
			$candidates[] = $this->img_dimensions;
		}

		// With cropping off the file keeps its own shape, and that shape cannot be
		// read off the image tag: get_img_tag_dimensions() reports the gallery's
		// crop size for the 'default' image size without checking whether cropping
		// is on, which would squeeze every image into that one shape.
		$full = wp_get_attachment_image_src( $this->item_id, 'full' );

		if ( is_array( $full ) ) {
			$candidates[] = [
				'width'  => ! empty( $full[1] ) ? $full[1] : 0,
				'height' => ! empty( $full[2] ) ? $full[2] : 0,
			];
		}

		// Items sourced from outside the media library (Instagram, Dribbble,
		// folder galleries) carry their dimensions on the item instead.
		$candidates[] = $this->item;
		$candidates[] = $this->img_dimensions;
		$candidates[] = [
			'width'  => envira_get_config( 'crop_width', $this->data ),
			'height' => envira_get_config( 'crop_height', $this->data ),
		];

		foreach ( $candidates as $candidate ) {
			$width  = ! empty( $candidate['width'] ) ? (int) $candidate['width'] : 0;
			$height = ! empty( $candidate['height'] ) ? (int) $candidate['height'] : 0;

			if ( $width > 0 && $height > 0 ) {
				return [
					'width'  => $width,
					'height' => $height,
				];
			}
		}

		return [];
	}

	/**
	 * Get the image title.
	 *
	 * @param string  $output_caption Output caption.
	 * @param numeric $item_id Item ID.
	 * @param array   $item Item.
	 * @param array   $data Data.
	 * @param int     $count Count.
	 *
	 * @return string
	 */
	protected function envira_gallery_output_after_link( $output_caption, $item_id, $item, $data, $count ) {
		$output = parent::envira_gallery_output_after_link( '', $item_id, $item, $data, $count );

		$caption_title_array = $this->get_title_caption();
		$caption_array       = [];

		if ( $caption_title_array['title'] ) {
			$caption_array[] = '<strong>' . wp_strip_all_tags( $caption_title_array['title'] ) . '</strong>';
		}

		if ( $caption_title_array['caption'] ) {
			$caption_array[] = wp_strip_all_tags( $caption_title_array['caption'] );
		}

		if ( empty( $caption_array ) ) {
			return $output;
		}

		$title_caption = implode( ' ', $caption_array );
		$classes_array = [ 'envira-gallery-item-bnb-title_caption' ];

		if ( false !== strpos( $output, 'envira-woocommerce' ) ) {
			$classes_array[] = 'envira-gallery-item-bnb-title_caption--with-woocommerce';
		}

		$classes    = Shortcode_Utils::classnames( $classes_array );
		$extra_html = "<div class=\"$classes\">$title_caption</div>";

		return $output . $extra_html;
	}
}
