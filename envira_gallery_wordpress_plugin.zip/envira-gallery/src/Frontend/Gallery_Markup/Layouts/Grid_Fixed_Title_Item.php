<?php
/**
 * Grid Fixed Title layout item class.
 *
 * @since ??
 *
 * @package Envira_Gallery
 * @author  Envira Gallery Team <support@enviragallery.com>
 */

namespace Envira\Frontend\Gallery_Markup\Layouts;

use Envira\Frontend\Gallery_Markup\Item;

/**
 * Grid Fixed Title item class.
 */
class Grid_Fixed_Title_Item extends Item {
	/**
	 * Remove title and caption.
	 *
	 * @return string
	 */
	protected function gallery_image_caption_titles() {
		return '';
	}
}
