<?php
/**
 * Bento Grid layout item class.
 *
 * @since ??
 *
 * @package Envira_Gallery
 * @author  Envira Gallery Team <support@enviragallery.com>
 */

namespace Envira\Frontend\Gallery_Markup\Layouts;

use Envira\Frontend\Gallery_Markup\Item;

/**
 * Bento Grid item class.
 */
class Bento_Grid_Item extends Item {

	/**
	 * Suppress default gutter padding — gap is set on the CSS grid container.
	 *
	 * @param numeric $gutter Gutter size.
	 * @param numeric $margin Margin.
	 *
	 * @return string
	 */
	protected function get_item_wrapper_styles( $gutter, $margin ) {
		return '';
	}

	/**
	 * Bento grid layout does not render title/caption.
	 *
	 * @return array{title: string, caption: string}
	 */
	protected function get_title_caption() {
		return [
			'title'   => '',
			'caption' => '',
		];
	}
}
