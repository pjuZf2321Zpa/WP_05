<?php
/**
 * Horizontal Slideshow layout class.
 *
 * Uses a SwiperJS web component for the main stage and a custom thumbnail
 * strip beneath it to render a horizontal slideshow experience.
 *
 * @since 1.10.5
 *
 * @package Envira_Gallery
 * @author  Envira Gallery Team <support@enviragallery.com>
 */

namespace Envira\Frontend\Gallery_Markup\Layouts;

use Envira\Frontend\Gallery_Markup\Base;
use Envira\Utils\Shortcode_Utils;

/**
 * Horizontal_Slideshow layout class.
 */
class Horizontal_Slideshow extends Base {

	/**
	 * Gallery limit from parsed attrs (e.g. Instagram cap).
	 *
	 * @var int
	 */
	private $slideshow_limit;

	/**
	 * Constructor.
	 *
	 * @param array $config All needed data.
	 */
	public function __construct( $config ) {
		parent::__construct( $config );

		// Instagram addon may leave $this->data['gallery'] unset; mirror BnB fallback.
		if ( ! isset( $this->data['gallery'] ) || ! is_array( $this->data['gallery'] ) ) {
			$this->data['gallery'] = ( isset( $config['index'][ $this->gallery_id ] ) && is_array( $config['index'][ $this->gallery_id ] ) )
				? $config['index'][ $this->gallery_id ]
				: [];
		}

		$this->slideshow_limit = isset( $config['limit'] ) ? (int) $config['limit'] : 0;
	}

	/**
	 * Generate wrapper classes.
	 *
	 * @since 1.10.5
	 *
	 * @return array
	 */
	protected function get_wrapper_classes() {
		$classes   = parent::get_wrapper_classes();
		$classes[] = 'envira-layout-horizontal-slideshow';

		return $classes;
	}

	/**
	 * Get container classes for the main slideshow container.
	 *
	 * @return array
	 */
	protected function get_container_classes() {
		return [
			'envira-gallery-public',
			'envira-horizontal-slideshow',
			'envira-clear',
		];
	}

	/**
	 * Get item object for slideshow slides.
	 *
	 * @param array $config Item config.
	 *
	 * @return Horizontal_Slideshow_Item
	 */
	protected function get_item_object( $config ) {
		return new Horizontal_Slideshow_Item( $config );
	}

	/**
	 * Gallery markup using swiper-container for the main stage.
	 *
	 * @return string
	 */
	public function markup() {
		$wrapper_id    = sanitize_html_class( "envira-gallery-wrap-$this->unique_id" );
		$wrapper_class = Shortcode_Utils::classnames(
			apply_filters(
				'envira_gallery_output_classes',
				$this->get_wrapper_classes(),
				$this->data
			)
		);

		$schema_microdata = apply_filters(
			'envira_gallery_output_shortcode_schema_microdata',
			'itemscope itemtype="https://schema.org/ImageGallery"',
			$this->data
		);

		// Gallery description is not supported for this layout (see admin conditional-fields).

		// Container attributes.
		$container_id    = sanitize_html_class( "envira-gallery-$this->unique_id" );
		$extra_class     = explode( ' ', trim( apply_filters( 'envira_gallery_output_extra_css', '', $this->data ) ) );
		$container_class = Shortcode_Utils::classnames( array_merge( $this->get_container_classes(), $extra_class ) );

		$container_extra_attrs = implode( ' ', $this->get_container_extra_attrs() );
		$container_data        = implode( ' ', $this->get_container_data() );

		$type = envira_get_config( 'type', $this->data );

		// Build the main slideshow stage.
		$container  = apply_filters( 'envira_gallery_temp_output_before_container', '', $this->data );
		$container .= '<div class="envira-horizontal-slideshow-shell">';
		$container .= '<button type="button" class="envira-slideshow-nav envira-slideshow-prev" aria-label="' . esc_attr__( 'Previous slide', 'envira-gallery' ) . '">&lsaquo;</button>';
		$container .= '<div class="envira-horizontal-slideshow-main">';
		$container .= "<swiper-container id=\"$container_id\" class=\"$container_class\" init=\"false\" $container_data$container_extra_attrs>";

		$count = 1;
		foreach ( (array) $this->data['gallery'] as $item_id => $item ) {
			$container = $this->generate_gallery_item_markup(
				$container,
				$this->data,
				$item,
				$item_id,
				$count
			);

			if ( 'instagram' === $type && $this->slideshow_limit && $count >= $this->slideshow_limit ) {
				break;
			}

			++$count;
		}

		$container .= '</swiper-container>';
		$container .= '</div>';
		$container .= '<button type="button" class="envira-slideshow-nav envira-slideshow-next" aria-label="' . esc_attr__( 'Next slide', 'envira-gallery' ) . '">&rsaquo;</button>';
		$container .= '</div>';

		$container .= '<div class="envira-slideshow-caption-display" aria-live="polite"></div>';

		// Build the thumbnail strip beneath the main stage.
		$container .= '<div class="envira-slideshow-thumbnails" role="tablist" aria-label="' . esc_attr__( 'Slideshow thumbnails', 'envira-gallery' ) . '">';

		$proofing_enabled = function_exists( 'envira_get_config' ) && envira_get_config( 'proofing', $this->data );

		$count = 1;
		foreach ( (array) $this->data['gallery'] as $item_id => $item ) {
			// The strip renders these at 80x80, so prefer the item's own thumb, then a
			// WordPress-generated small size, and only fall back to the full-size src
			// when neither exists — this used to serve the original for every gallery
			// whose stored 'thumb' key is empty (megabytes of images behind 80px boxes).
			$thumb_src = envira_get_item_thumb_src( $item, $item_id, 'medium' );
			$thumb_alt = ! empty( $item['alt'] ) ? $item['alt'] : $item['title'];
			$is_active = 1 === $count ? ' is-active' : '';
			$tab_index = 1 === $count ? '0' : '-1';
			$selected  = 1 === $count ? 'true' : 'false';
			$label     = sprintf(
				/* translators: %d: slide number. */
				esc_attr__( 'Go to slide %d', 'envira-gallery' ),
				$count
			);

			$thumb_shell_open  = '';
			$thumb_shell_close = '';
			if ( $proofing_enabled ) {
				$proofing_checkbox_id = 'envira_proofing_images_' . absint( $item_id );
				$thumb_shell_open     = '<div class="envira-slideshow-thumbnail-shell" data-envira-item-id="' . esc_attr( (string) absint( $item_id ) ) . '"><label for="' . esc_attr( $proofing_checkbox_id ) . '" class="envira-proofing-select-image envira-proofing-select-image--slideshow-thumb" aria-label="' . esc_attr__( 'Select image for proofing', 'envira-gallery' ) . '"></label>';
				$thumb_shell_close    = '</div>';
			}

			$container .= $thumb_shell_open;
			$container .= sprintf(
				'<button type="button" class="envira-slideshow-thumbnail%s" data-envira-thumb-index="%d" role="tab" aria-selected="%s" tabindex="%s" aria-label="%s"><img src="%s" alt="%s" loading="lazy" /></button>',
				esc_attr( $is_active ),
				(int) ( $count - 1 ),
				esc_attr( $selected ),
				esc_attr( $tab_index ),
				esc_attr( $label ),
				esc_url( $thumb_src ),
				esc_attr( $thumb_alt )
			);
			$container .= $thumb_shell_close;

			if ( 'instagram' === $type && $this->slideshow_limit && $count >= $this->slideshow_limit ) {
				break;
			}

			++$count;
		}

		$container .= '</div>';

		$container = apply_filters( 'envira_gallery_container', $container, $this->data );

		// NoJS fallback.
		$no_js = '<noscript>';
		foreach ( (array) $this->data['gallery'] as $item_id => $item ) {
			if ( ! empty( $item['src'] ) ) {
				$src    = esc_url( $item['src'] );
				$alt    = ! empty( $item['alt'] ) ? esc_attr( $item['alt'] ) : '';
				$no_js .= "<img src='$src' alt='$alt' class='envira_noscript_images' />";
			}
		}
		$no_js .= '</noscript>';
		$no_js  = apply_filters( 'envira_gallery_output_noscript', $no_js, $this->data );

		// Assemble gallery markup.
		$gallery_markup = apply_filters( 'envira_gallery_output_start', '', $this->data );

		$gallery_markup .= "<div id=\"$wrapper_id\" class=\"$wrapper_class\" $schema_microdata>";

		$gallery_markup = apply_filters(
			'envira_gallery_output_loader',
			$gallery_markup . $this->get_loader(),
			$gallery_markup,
			$this->data
		);

		$gallery_markup = $this->envira_gallery_output_before_container( $gallery_markup );
		$gallery_markup = $this->envira_gallery_output_after_container( $gallery_markup . $container );

		$gallery_markup .= '</div>';

		$gallery_markup = apply_filters( 'envira_gallery_output_end', $gallery_markup, $this->data );

		if ( envira_get_config( 'mobile', $this->data ) ) {
			remove_filter( 'envira_gallery_output_image_attr', [ $this, 'mobile_image' ], 999 );
		}

		$gallery_markup .= $no_js;

		return $gallery_markup;
	}
}
