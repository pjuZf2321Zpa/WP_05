<?php
/**
 * Automatic layout item class.
 *
 * @since ??
 *
 * @package Envira_Gallery
 * @author  Envira Gallery Team <support@enviragallery.com>
 */

namespace Envira\Frontend\Gallery_Markup\Layouts;

use Envira\Frontend\Gallery_Markup\Item;

/**
 * Automatic layout item.
 */
class Automatic_Item extends Item {
	/**
	 * Automatic layout displays the caption and title on hover.
	 *
	 * @return string
	 */
	protected function gallery_image_caption_titles() {
		return '';
	}

	/**
	 * Get image sizes.
	 *
	 * @param string $output_width Output width.
	 * @param string $output_height Output height.
	 * @param string $image_size Image size.
	 * @param string $crop_width Crop width.
	 * @param string $crop_height Crop height.
	 *
	 * @return array{width: numeric, height: numeric}
	 */
	protected function get_img_tag_dimensions( $output_width, $output_height, $image_size, $crop_width, $crop_height ) {
		return [
			'width'  => $crop_width,
			'height' => $crop_height,
		];
	}

	/**
	 * Extra attrs to add on extension class.
	 *
	 * @param string $output_width Output width.
	 * @param string $output_height Output height.
	 *
	 * @return array
	 */
	protected function img_extra_attrs( $output_width, $output_height ) {
		$caption_title_array = $this->get_title_caption();
		$caption_array       = [];

		if ( $caption_title_array['title'] ) {
			$caption_array[] = esc_attr( htmlspecialchars( wp_strip_all_tags( $caption_title_array['title'] ) ) );
		}

		if ( $caption_title_array['caption'] ) {
			// Shown in full, like the captions of every other layout. Long captions used to go
			// through Truncate_Html after escaping; its DOMDocument round trip decoded &quot;
			// back to a raw quote, which closed this attribute early and dropped
			// data-envira-width/height from the <img> (#5543). It never truncated anything
			// (#5226), so the full caption is what this layout has shown since 1.9.17.
			$caption_array[] = esc_attr( str_replace( "\n", ' ', htmlspecialchars( wp_strip_all_tags( $caption_title_array['caption'] ) ) ) );
		}

		// justifiedGallery takes each row's aspect ratio from these attributes. They resolve
		// through wp_get_attachment_image_src(), so when _wp_attachment_metadata is missing
		// WordPress reports the size as 1x1 and the row is laid out as a square. Measuring the
		// file needs only _wp_attached_file, so it survives that.
		if ( empty( $output_width ) || empty( $output_height ) || $output_width <= 1 || $output_height <= 1 ) {
			$file = get_attached_file( $this->item_id );

			// Never stat or read a stream-wrapped path (s3://, iu://, etc.). Offload plugins
			// filter get_attached_file() to return one, and an unhealthy remote would block the
			// request until max_execution_time. Same stream-wrapper check as Functions/image.php
			// and Frontend/Rest.php; those also contain the path with realpath(), which they need
			// because they build it from a gallery-supplied URL. This path comes from
			// _wp_attached_file, so there is no caller-controlled component to contain.
			$is_remote = $file && preg_match( '#^[a-z][a-z0-9+.\-]*://#i', $file );

			if ( $file && ! $is_remote && file_exists( $file ) ) {
				$size = function_exists( 'wp_getimagesize' ) ? wp_getimagesize( $file ) : getimagesize( $file );
				if ( is_array( $size ) && ! empty( $size[0] ) && ! empty( $size[1] ) ) {
					$output_width  = $size[0];
					$output_height = $size[1];
				}
			}
		}

		$automatic_caption = implode( ' - ', $caption_array );
		$img_attrs_array   = [];
		$img_attrs_array[] = "data-automatic-caption=\"$automatic_caption\"";
		$img_attrs_array[] = "data-envira-height=\"$output_height\"";
		$img_attrs_array[] = "data-envira-width=\"$output_width\"";

		return $img_attrs_array;
	}

	/**
	 * Wrapper for obtaining title and caption from options:
	 * additional_copy_title
	 * additional_copy_caption
	 * gallery_column_title_caption
	 *
	 * @return array{title: string, caption: string}
	 */
	protected function get_title_caption() {
		// Set defaults as empty.
		$title_caption = [
			'title'   => '',
			'caption' => '',
		];

		foreach ( array_keys( $title_caption ) as $type ) {
			if ( ! empty( $this->item[ $type ] ) ) {
				$additional_copy = envira_get_config( "additional_copy_automatic_$type", $this->data );
				$column_title    = envira_get_config( 'gallery_automatic_title_caption', $this->data );
				if ( 1 === $additional_copy || in_array( $column_title, [ $type, 'title_caption' ], true ) ) {
					$title_caption[ $type ] = $this->item[ $type ];
				}
			}
		}

		return $title_caption;
	}

	/**
	 * Add extra wrappers around img tag.
	 *
	 * Automatic does not need any wrapper.
	 *
	 * @param numeric $img_height Image tag height attr.
	 * @param numeric $img_width Image tag width attr.
	 *
	 * @return array{'start': string, 'end': string}
	 */
	protected function get_img_wrapper( $img_height, $img_width ) {
		return [
			'start' => '',
			'end'   => '',
		];
	}
}
