<?php
/**
 * Bento Grid layout class.
 *
 * @since ??
 *
 * @package Envira_Gallery
 * @author  Envira Gallery Team <support@enviragallery.com>
 */

namespace Envira\Frontend\Gallery_Markup\Layouts;

use Envira\Frontend\Gallery_Markup\Base;
use Envira\Frontend\Gallery_Markup\Layouts\Bento_Grid_Item;

/**
 * Bento Grid layout class.
 */
class Bento_Grid extends Base {

	/**
	 * Pattern slot indices sorted left→right, top→bottom (desktop viewport).
	 * Used to reorder gallery items so DOM position matches visual position,
	 * keeping lightbox / deeplinking / tag-filter index correct.
	 */
	const VISUAL_ORDER = [ 0, 2, 3, 1, 4, 5 ];

	/**
	 * Whether the singleton init script has been emitted this request.
	 *
	 * @var bool
	 */
	private static $script_emitted = false;

	/**
	 * Pre-sort gallery items into visual order before rendering.
	 *
	 * Without this, CSS Grid repositions items visually while DOM order stays
	 * sequential, causing lightbox / deep-linking / tag-filter to open the wrong
	 * image when the user clicks a non-first tile.
	 */
	public function markup() {
		$this->data['gallery'] = $this->sort_gallery_to_visual_order( $this->data['gallery'] );
		return parent::markup();
	}

	/**
	 * Reorder gallery items to match visual left-to-right, top-to-bottom order.
	 *
	 * Desktop and mobile visual orders coincide after this permutation, so one
	 * sort covers both viewports.
	 *
	 * @param array $gallery Gallery items keyed by attachment id.
	 * @return array Items reordered into visual order.
	 */
	private function sort_gallery_to_visual_order( array $gallery ): array {
		$order  = self::VISUAL_ORDER;
		$len    = count( $order );
		$keys   = array_keys( $gallery );
		$values = array_values( $gallery );
		$total  = count( $keys );
		$sorted = [];

		for ( $block = 0; $block < $total; $block += $len ) {
			foreach ( $order as $offset ) {
				$i = $block + $offset;
				if ( $i < $total ) {
					$sorted[ $keys[ $i ] ] = $values[ $i ];
				}
			}
		}

		return $sorted;
	}

	/**
	 * Override data-gallery-images JSON to match visual sort order.
	 *
	 * The lightbox uses this JSON array for next/prev navigation.
	 * Parent builds it from the original gallery order; we rebuild it
	 * with the same visual permutation applied to DOM items.
	 */
	protected function get_container_data(): array {
		$data = parent::get_container_data();

		foreach ( $data as $key => $attr ) {
			if ( strpos( $attr, 'data-gallery-images=' ) !== 0 ) {
				continue;
			}

			// Reuse the JSON the parent already built — decode, permute, re-encode —
			// instead of re-fetching the gallery images.
			$json    = substr( $attr, strlen( "data-gallery-images='" ), -1 );
			$decoded = json_decode( $json, true );
			if ( ! is_array( $decoded ) ) {
				break;
			}

			$sorted       = $this->sort_gallery_to_visual_order( $decoded );
			$data[ $key ] = "data-gallery-images='" . wp_json_encode( array_values( $sorted ), JSON_UNESCAPED_UNICODE ) . "'";
			break;
		}

		return $data;
	}

	/**
	 * Generate wrapper classes.
	 */
	protected function get_wrapper_classes() {
		$classes   = parent::get_wrapper_classes();
		$classes[] = 'envira-layout-bento-grid';

		return $classes;
	}

	/**
	 * Get container class.
	 *
	 * @return array
	 */
	protected function get_container_classes() {
		$classes   = parent::get_container_classes();
		$classes[] = 'envira-layout-bento-grid--container';

		return $classes;
	}

	/**
	 * Get item object.
	 *
	 * @param array $config Item config.
	 *
	 * @return Bento_Grid_Item
	 */
	protected function get_item_object( $config ) {
		return new Bento_Grid_Item( $config );
	}

	/**
	 * Pass gutter/margin as column-gap and --bento-margin on the container.
	 *
	 * @return array
	 */
	protected function get_container_extra_attrs() {
		$gutter = absint( envira_get_config( 'gutter', $this->data, envira_get_config_default( 'gutter' ) ) );
		if ( $this->is_mobile ) {
			// Treat 0 / unset as "follow desktop gutter" so existing galleries that
			// saved `gutter_mobile = 0` still render with column spacing on mobile.
			$mobile = absint( envira_get_config( 'gutter_mobile', $this->data, 0 ) );
			if ( $mobile > 0 ) {
				$gutter = $mobile;
			}
		}
		$margin = absint( envira_get_config( 'margin', $this->data, 0 ) );

		$style = sprintf( 'column-gap: %1$dpx; --bento-margin: %2$dpx;', $gutter, $margin );

		return [ 'style="' . esc_attr( $style ) . '"' ];
	}

	/**
	 * Emit the singleton grid-positioning script once per page render.
	 *
	 * @param string $gallery_markup Gallery markup.
	 * @return string
	 */
	protected function envira_gallery_output_after_container( $gallery_markup ) {
		$gallery_markup = parent::envira_gallery_output_after_container( $gallery_markup );

		// Skip in REST context — innerHTML-injected scripts are inert; the singleton
		// already on the page picks up new containers via envira_load.
		if ( self::$script_emitted || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
			return $gallery_markup;
		}
		self::$script_emitted = true;

		$script = '<script>
(function () {
  if (window.enviraBentoGrid) { return; }

  var desktopPattern = [
    [0, 1, 1, 1],
    [0, 2, 7, 2],
    [0, 4, 3, 1],
    [2, 1, 5, 1],
    [4, 4, 1, 1],
    [6, 4, 1, 1],
  ];
  var mobilePattern = [
    [0, 1, 1, 3],
    [0, 4, 1, 3],
    [1, 1, 2, 6],
    [3, 1, 1, 2],
    [3, 3, 1, 2],
    [3, 5, 1, 2],
  ];

  var SELECTOR    = ".envira-layout-bento-grid--container";
  var hasObserver = typeof ResizeObserver !== "undefined";
  var observed    = hasObserver ? new Map() : null;
  var tracked     = hasObserver ? null : [];

  function applyBentoLayout(container) {
    var isMobile    = window.innerWidth <= 768;
    var pattern     = isMobile ? mobilePattern : desktopPattern;
    var blockHeight = isMobile ? 4 : 8;
    var patternLen  = pattern.length;

    container.querySelectorAll(".envira-gallery-item").forEach(function (item, index) {
      var block = Math.floor(index / patternLen);
      var pi    = index % patternLen;

      item.style.gridRowStart    = block * blockHeight + pattern[pi][0] + 1;
      item.style.gridRowEnd      = "span " + pattern[pi][2];
      item.style.gridColumnStart = pattern[pi][1];
      item.style.gridColumnEnd   = "span " + pattern[pi][3];
    });
  }

  function applyToAll() {
    tracked = tracked.filter(function (container) {
      if (!document.contains(container)) { return false; }
      applyBentoLayout(container);
      return true;
    });
  }

  function sync() {
    if (hasObserver) {
      // Observe new containers, disconnect detached ones.
      document.querySelectorAll(SELECTOR).forEach(function (container) {
        if (observed.has(container)) { return; }
        var ro = new ResizeObserver(function (entries) {
          entries.forEach(function (entry) { applyBentoLayout(entry.target); });
        });
        ro.observe(container);
        observed.set(container, ro);
      });
      observed.forEach(function (ro, container) {
        if (!document.contains(container)) {
          ro.disconnect();
          observed.delete(container);
        }
      });
      return;
    }

    // Fallback: apply once per container, recompute on window resize.
    document.querySelectorAll(SELECTOR).forEach(function (container) {
      if (tracked.indexOf(container) !== -1) { return; }
      tracked.push(container);
      applyBentoLayout(container);
    });
  }

  // Bind container parsed before this script now; later siblings on DOMContentLoaded.
  sync();
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", sync);
  }

  // Re-sync after tag-filter AJAX swap.
  if (typeof jQuery !== "undefined") {
    jQuery(document).on("envira_load", sync);
  }

  if (!hasObserver) {
    window.addEventListener("resize", applyToAll);
  }

  window.enviraBentoGrid = { sync: sync };
}());
</script>';

		return $gallery_markup . $script;
	}
}
