<?php
/**
 * Gallery Detector — page-level detection for Envira content.
 *
 * Centralises the "does this page have an Envira gallery?" decision so that
 * early-hook code (wp_head, wp_enqueue_scripts) can gate asset loading without
 * duplicating has_shortcode / has_block checks across every addon.
 *
 * Usage (namespaced code):
 *   if ( ! Gallery_Detector::page_has_gallery() ) { return; }
 *
 * Usage (legacy non-namespaced addons):
 *   if ( ! envira_page_has_gallery() ) { return; }
 *
 * @since   1.13.4
 * @package Envira_Gallery
 */

namespace Envira\Frontend;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Detects whether the current page contains any Envira gallery or album.
 */
class Gallery_Detector {

	/**
	 * Cached detection result. Null = not yet evaluated.
	 *
	 * @var bool|null
	 */
	private static $result = null;

	/**
	 * Return true if the current page contains an Envira gallery or album.
	 *
	 * Results are cached after the first call — safe to call repeatedly.
	 *
	 * @return bool
	 */
	public static function page_has_gallery(): bool {
		if ( null !== self::$result ) {
			return self::$result;
		}

		self::$result = self::detect();
		return self::$result;
	}

	/**
	 * Clear the cached result so the next call re-evaluates.
	 *
	 * Useful in unit tests or cron contexts where the queried object changes.
	 *
	 * @return void
	 */
	public static function reset() {
		self::$result = null;
	}

	/**
	 * Run the actual detection logic.
	 *
	 * @return bool
	 */
	private static function detect(): bool {
		// Feeds never need front-end gallery assets.
		if ( is_feed() ) {
			return false;
		}

		$post = get_post();

		if ( $post instanceof \WP_Post ) {
			$content = $post->post_content;

			// Shortcode detection.
			if (
				has_shortcode( $content, 'envira-gallery' ) ||
				has_shortcode( $content, 'envira-album' )
			) {
				return true;
			}

			// Gutenberg block detection.
			if (
				has_block( 'envira-gallery/gallery', $post ) ||
				has_block( 'envira-gallery/album', $post )
			) {
				return true;
			}
		}

		/**
		 * Allows addons or themes to signal that a gallery will appear even
		 * when post-content detection is impossible — e.g., programmatic
		 * insertion via PHP template tags, custom post types, or widgets.
		 *
		 * Return true to force asset loading on this page.
		 *
		 * @param bool          $has_gallery Whether a gallery was detected. Default false.
		 * @param \WP_Post|null $post        Current post object, or null.
		 */
		return (bool) apply_filters( 'envira_page_has_gallery', false, $post );
	}
}
