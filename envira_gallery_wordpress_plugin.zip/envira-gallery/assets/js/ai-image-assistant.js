/**
 * Envira AI Image Assistant — admin JS.
 *
 * - Settings sub-tab: status pill, balance bar, default tone/fields, save.
 * - Per-image: "Generate AI metadata" button on each gallery image (data-attachment).
 * - Bulk: bulk action button on selected images.
 *
 * Uses wp.apiFetch with X-WP-Nonce — no admin-ajax.
 */
(function () {
	'use strict';

	if (typeof window.enviraImageAssistant === 'undefined') {
		return;
	}

	const cfg = window.enviraImageAssistant;
	const apiFetch = wp && wp.apiFetch ? wp.apiFetch : null;
	if (!apiFetch) {
		return;
	}

	apiFetch.use(apiFetch.createNonceMiddleware(cfg.nonce));

	const i18n = cfg.i18n || {};

	/* ─── Helpers ────────────────────────────────────────────────────────── */

	function api(path, options) {
		options = options || {};
		// cfg.restRoot is an absolute URL (built server-side via rest_url()), so
		// use apiFetch's `url` option — `path` is for relative paths that apiFetch
		// resolves against its internal rootURL, and passing an absolute URL there
		// produces a malformed request.
		options.url = cfg.restRoot + path;
		options.parse = false; // we want the raw response so we can read status
		// apiFetch rejects on non-2xx even with parse:false — and with parse:false
		// it rejects with the raw Response. Normalize BOTH the resolved and the
		// rejected Response to the same { status, body } shape so callers can
		// branch on status (e.g. 402 → out-of-credits UX) instead of every HTTP
		// error collapsing into a generic .catch(). A true transport failure has
		// no Response object, so re-throw it to preserve network-error handling.
		const toResult = function (res) {
			if (res && typeof res.json === 'function') {
				return res.json().then(
					function (body) {
						return {status: res.status, body: body};
					},
					function () {
						return {status: res.status || 0, body: null};
					}
				);
			}
			return Promise.reject(res);
		};
		return apiFetch(options).then(toResult, toResult);
	}

	function fmt(str, args) {
		args = args || [];
		let i = 0;
		return (str || '').replace(/%(\d+\$)?[dsf]/g, function () {
			return args[i++];
		});
	}

	/**
	 * Show a toast.
	 *
	 * @param {string}  msg          Message text.
	 * @param {string}  kind         'info' | 'success' | 'error'.
	 * @param {Object}  [opts]       Options.
	 * @param {boolean} [opts.persistent] When true the toast stays until the user
	 *                               dismisses it (a × button is shown) instead of
	 *                               auto-hiding. Used for out-of-credits errors so
	 *                               they can't be missed.
	 */
	function toast(msg, kind, opts) {
		opts = opts || {};
		const node = document.createElement('div');
		// The .envira-ia class is REQUIRED here: toasts are appended to
		// document.body (outside any .envira-ia surface), and the toast's
		// background/colors are --ia-* design tokens scoped to .envira-ia. Without
		// it those vars don't resolve and the toast renders white-on-transparent
		// (i.e. invisible — every success/error/credit message silently lost).
		node.className = 'envira-ia envira-ia-toast envira-ia-toast-' + (kind || 'info');
		const text = document.createElement('span');
		text.className = 'envira-ia-toast-msg';
		text.textContent = msg;
		node.appendChild(text);
		document.body.appendChild(node);
		setTimeout(function () {
			node.classList.add('envira-ia-toast-visible');
		}, 10);

		const dismiss = function () {
			node.classList.remove('envira-ia-toast-visible');
			setTimeout(function () {
				node.remove();
			}, 250);
		};

		if (opts.persistent) {
			// No auto-dismiss — the user closes it explicitly.
			const close = document.createElement('button');
			close.type = 'button';
			close.className = 'envira-ia-toast-close';
			close.setAttribute('aria-label', i18n.close || 'Close');
			close.innerHTML = '&times;';
			close.addEventListener('click', dismiss);
			node.appendChild(close);
		} else {
			setTimeout(dismiss, 4000);
		}
	}

	/**
	 * Error toast from an api() result. Out-of-credits (402) errors persist until
	 * the user dismisses them — they're actionable (buy credits) and must not be
	 * missed; everything else auto-dismisses.
	 *
	 * @param {Object} res      api() result ({ status, body }).
	 * @param {string} [fallback] Message when the body carries none.
	 */
	function errorToast(res, fallback) {
		const msg = (res && res.body && res.body.message) || fallback || i18n.failed || 'Failed';
		toast(msg, 'error', {persistent: !!(res && res.status === 402)});
	}

	/**
	 * Populate every .envira-ia-credit-widget on the page with the supplied
	 * balance object. Drives the 3-state visual (ok / low / exhausted / unlimited).
	 *
	 * @param {object|null} balance Worker /v1/balance shape, or null on error.
	 */
	function setCreditWidgets(balance) {
		const widgets = document.querySelectorAll('.envira-ia-credit-widget');
		if (!widgets.length) {
			return;
		}

		let state = 'ok',
			amount = '—',
			resetText = '',
			note = '',
			pct = 0,
			isUnlimited = false;

		if (balance) {
			isUnlimited = !!balance.is_unlimited;
			const remaining = balance.total_remaining || 0;
			if (isUnlimited) {
				state = 'unlimited';
				amount = i18n.unlimited || 'Unlimited';
				pct = 100;
			} else {
				// Count credits ACTUALLY consumed from the explicit figures the
				// service reports — NOT by inferring used = (included_quota +
				// purchased_credits) − remaining. That subtraction folds in
				// expired/forfeited purchased credits (bought but never consumed),
				// overstating usage (QA). included_used + purchased_used is real
				// consumption; total = used + remaining keeps the bar consistent
				// and drops expired credits from the denominator as well.
				const used = (balance.included_used || 0) + (balance.purchased_used || 0);
				const total = used + remaining;
				amount = used + ' / ' + total + ' ' + (i18n.creditsUsedLabel || 'Credits Used Per Year');
				pct = total > 0 ? Math.max(0, Math.min(100, (used / total) * 100)) : 0;
				if (remaining <= 0) {
					state = 'exhausted';
					note =
						i18n.creditsExhausted ||
						'Out of credits. Buy more credits to continue using Image Assistant features.';
				} else if (remaining / Math.max(total, 1) <= 0.1) {
					state = 'low';
					note =
						i18n.creditsLow || 'Running low on credits. Buy more credits or upgrade your plan.';
				}
				if (balance.quota_reset_at) {
					const d = new Date(balance.quota_reset_at * 1000);
					resetText = (i18n.resetDateLabel || 'Reset date:') + ' ' + d.toLocaleDateString();
				}
			}
		}

		Array.prototype.forEach.call(widgets, function (w) {
			w.setAttribute('data-state', state);
			const aEl = w.querySelector('.envira-image-assistant-credit-amount');
			if (aEl) {
				aEl.textContent = amount;
			}
			const rEl = w.querySelector('.envira-image-assistant-credit-reset');
			if (rEl) {
				rEl.textContent = resetText;
			}
			const nEl = w.querySelector('.envira-image-assistant-credit-note');
			if (nEl) {
				nEl.textContent = note;
			}
			const bar = w.querySelector('.envira-ia-bar');
			if (bar) {
				bar.setAttribute('data-state', state);
			}
			const fill = w.querySelector('.envira-ia-bar-fill');
			if (fill) {
				fill.style.width = pct + '%';
			}
		});
	}

	/**
	 * Populate the tone dropdown from /v1/tones (cached for a day on the server).
	 * Updates the description line under the select on change.
	 */
	function bootTones(root) {
		const select = root.querySelector('#envira-image-assistant-tone');
		const desc = root.querySelector('.envira-image-assistant-tone-desc');
		const current = root.getAttribute('data-tone') || 'seo';
		if (!select) {
			return;
		}
		api('tones')
			.then(function (res) {
				if (res.status !== 200 || !res.body || !Array.isArray(res.body.tones)) {
					if (desc) {
						desc.textContent = '';
					}
					return;
				}
				const tones = res.body.tones;
				select.innerHTML = '';
				tones.forEach(function (t) {
					const opt = document.createElement('option');
					opt.value = t.slug;
					opt.textContent = t.label + ('seo' === t.slug ? ' (recommended)' : '');
					if (t.slug === current) {
						opt.selected = true;
					}
					opt.dataset.description = t.description || '';
					select.appendChild(opt);
				});
				const update = function () {
					const picked = select.options[select.selectedIndex];
					if (desc) {
						desc.textContent = picked ? picked.dataset.description || '' : '';
					}
				};
				select.addEventListener('change', update);
				update();
			})
			.catch(function () {
				if (desc) {
					desc.textContent = '';
				}
			});
	}

	/* ─── Settings tab boot ──────────────────────────────────────────────── */

	function bootSettings() {
		const root = document.querySelector('#envira-image-assistant-settings');
		// The credit widget can also live in the General tab — load balance even
		// when the Image Assistant Settings tab isn't mounted on this screen.
		loadAndApplyBalance();

		if (!root) {
			return;
		}

		bootTones(root);

		// Master "Automatically generate on upload" switch: hide the section's
		// field toggles entirely when it's off.
		const autoUploadEl = root.querySelector('#envira-image-assistant-auto-upload');
		const autoFields = root.querySelector('.envira-image-assistant-auto-fields');
		if (autoUploadEl && autoFields) {
			const syncAutoFields = function () {
				autoFields.hidden = !autoUploadEl.checked;
			};
			autoUploadEl.addEventListener('change', syncAutoFields);
			syncAutoFields();
		}

		const saveBtn = root.querySelector('.envira-image-assistant-save');
		const saveStatus = root.querySelector('.envira-image-assistant-save-status');
		if (saveBtn) {
			saveBtn.addEventListener('click', function () {
				const tone = root.querySelector('#envira-image-assistant-tone').value;
				const fields = Array.prototype.map.call(
					root.querySelectorAll('.envira-image-assistant-field:checked'),
					function (cb) {
						return cb.value;
					}
				);
				const overwriteEl = root.querySelector('#envira-image-assistant-overwrite');
				const galleryDescEl = root.querySelector('#envira-image-assistant-gallery-desc');
				const autoUpload = root.querySelector('#envira-image-assistant-auto-upload');
				saveStatus.textContent = '…';
				api('settings', {
					method: 'POST',
					data: {
						default_tone: tone,
						default_fields: fields,
						overwrite_behavior: overwriteEl ? !!overwriteEl.checked : true,
						gallery_description_enabled: galleryDescEl ? !!galleryDescEl.checked : false,
						auto_on_upload: autoUpload ? !!autoUpload.checked : false
					}
				})
					.then(function (res) {
						saveStatus.textContent =
							res.status >= 200 && res.status < 300
								? i18n.saveOk || 'Saved'
								: i18n.saveFail || 'Could not save';
					})
					.catch(function () {
						saveStatus.textContent = i18n.saveFail || 'Could not save';
					});
			});
		}
	}

	/**
	 * Fetch the current balance and propagate to every credit widget on the page.
	 * Safe to call from multiple surfaces (Settings tab + General tab).
	 */
	function loadAndApplyBalance() {
		if (!document.querySelector('.envira-ia-credit-widget')) {
			return;
		}
		api('balance')
			.then(function (res) {
				if (res.status !== 200) {
					setCreditWidgets(null);
					return;
				}
				// route_balance() now returns the balance object directly.
				setCreditWidgets(res.body);
			})
			.catch(function () {
				setCreditWidgets(null);
			});
	}

	/* ─── Modal shell ─────────────────────────────────────────────────────── */

	/**
	 * Open a modal. `content` is an HTMLElement (the modal card). Returns an
	 * object with `close()` and `replace(newContent)` so individual flows can
	 * swap between states without re-binding overlay events.
	 */
	function openModal(content, opts) {
		opts = opts || {};
		const overlay = document.createElement('div');
		overlay.className = 'envira-ia envira-ia-modal-overlay is-open';
		overlay.appendChild(content);
		document.body.appendChild(overlay);

		let closed = false;
		function close() {
			if (closed) {
				return;
			}
			closed = true;
			overlay.classList.remove('is-open');
			setTimeout(function () {
				overlay.remove();
			}, 150);
			if (typeof opts.onClose === 'function') {
				opts.onClose();
			}
		}

		// Click outside the modal card closes it (unless flow explicitly disallows).
		overlay.addEventListener('click', function (evt) {
			if (opts.dismissable === false) {
				return;
			}
			if (evt.target === overlay) {
				close();
			}
		});

		// Esc closes too.
		const onKey = function (evt) {
			if (opts.dismissable === false) {
				return;
			}
			if (evt.key === 'Escape') {
				close();
				document.removeEventListener('keydown', onKey);
			}
		};
		document.addEventListener('keydown', onKey);

		return {
			close: close,
			replace: function (newContent) {
				overlay.innerHTML = '';
				overlay.appendChild(newContent);
			}
		};
	}

	function el(tag, attrs, children) {
		const node = document.createElement(tag);
		if (attrs) {
			Object.keys(attrs).forEach(function (k) {
				if (k === 'className') {
					node.className = attrs[k];
				} else if (k === 'html') {
					node.innerHTML = attrs[k];
				} else if (k === 'text') {
					node.textContent = attrs[k];
				} else if (k.startsWith('on') && typeof attrs[k] === 'function') {
					node.addEventListener(k.substring(2).toLowerCase(), attrs[k]);
				} else {
					node.setAttribute(k, attrs[k]);
				}
			});
		}
		(children || []).forEach(function (c) {
			if (c === null || c === undefined) {
				return;
			}
			node.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
		});
		return node;
	}

	/* ─── Single Image Modal — 4 states ──────────────────────────────────── */

	const FIELD_LABELS = {
		alt_text: 'Alt Text',
		tags: 'Tags',
		caption: 'Caption',
		description: 'Description',
		title: 'Title',
		cleaned_title: 'Title Cleanup'
	};
	// Mockup picker shows these four; the rest are available but hidden by default.
	const SINGLE_DEFAULT_PICKER = ['alt_text', 'tags', 'caption', 'cleaned_title'];

	// Whether AI tags are usable on this site (Envira Tags addon active).
	function tagsAvailable() {
		return !!(cfg.defaults && cfg.defaults.tagsAvailable);
	}

	// Drop 'tags' from a field list when the taxonomy is unavailable, so no tag
	// UI is ever offered for a feature the site can't apply.
	function gateFields(fields) {
		if (tagsAvailable()) {
			return fields.slice();
		}
		return fields.filter(function (f) {
			return f !== 'tags';
		});
	}

	function openSingleImageModal(attachmentId, opts) {
		opts = opts || {};
		// Thumbnail shown in the picker + results states. Prefer an explicit
		// opts.thumb, else reuse the editor's already-loaded <li> image so we
		// don't fetch anything.
		const thumbUrl =
			opts.thumb ||
			(function () {
				const img = document.querySelector(
					'#envira-gallery-output li[data-envira-gallery-image="' + attachmentId + '"] img'
				);
				return img ? img.getAttribute('src') : '';
			})();
		// eslint-disable-next-line prefer-const -- assigned once below, but declared here so the modal's close handlers can close over it.
		let modal;
		// Gate the picker list on tag availability so 'tags' is never offered
		// when the Envira Tags addon is inactive.
		const pickerFields = gateFields(SINGLE_DEFAULT_PICKER);
		let pickedFields = gateFields(
			opts.defaultFields && opts.defaultFields.length ? opts.defaultFields : SINGLE_DEFAULT_PICKER
		);
		const tone = opts.tone || (cfg.defaults && cfg.defaults.tone) || 'seo';

		function header(subtitle) {
			return el('div', null, [
				el('div', {className: 'envira-ia-modal-head'}, [
					el('div', {className: 'envira-ia-modal-title'}, [
						el('span', {className: 'envira-ia-sparkle envira-ia-sparkle--lg'}),
						document.createTextNode(' ' + (i18n.modalTitle || 'Image Assistant'))
					]),
					el('div', {className: 'envira-ia-modal-actions'}, [
						el('button', {
							className: 'envira-ia-btn envira-ia-btn--icon',
							html: '×',
							onclick: function () {
								modal.close();
							}
						})
					])
				]),
				el('p', {className: 'envira-ia-modal-subtitle', text: subtitle})
			]);
		}

		// Square attachment thumbnail (left column of the picker + results),
		// or null when we couldn't resolve a source.
		function thumb() {
			return thumbUrl ? el('img', {className: 'envira-ia-thumb', src: thumbUrl, alt: ''}) : null;
		}

		// ── State 1: field picker ────────────────────────────────────────────
		function renderPicker() {
			const fieldRows = pickerFields.map(function (slug) {
				const checked = pickedFields.indexOf(slug) !== -1;
				const input = el('input', {
					type: 'checkbox',
					className: 'envira-ia-checkbox',
					value: slug,
					onchange: function () {
						if (input.checked) {
							if (pickedFields.indexOf(slug) === -1) {
								pickedFields.push(slug);
							}
						} else {
							pickedFields = pickedFields.filter(function (f) {
								return f !== slug;
							});
						}
					}
				});
				if (checked) {
					input.checked = true;
				}
				// Hidden native input + our own styled box, mirroring the toggle
				// component. WP admin restyles native checkboxes (incl. a Dashicon
				// SVG ::before), so we never style the input directly — the
				// adjacent .envira-ia-checkmark span is fully ours to control.
				return el('label', {className: 'envira-ia-field-checkbox'}, [
					input,
					el('span', {className: 'envira-ia-checkmark'}),
					el('span', {className: 'envira-ia-checkbox-label', text: FIELD_LABELS[slug] || slug})
				]);
			});

			const card = el('div', {className: 'envira-ia-modal'}, [
				header(i18n.modalSubtitle || 'Automatically create and edit metadata for your images.'),
				el('div', {className: 'envira-ia-modal-body'}, [
					el('div', {className: 'envira-ia-single-top'}, [
						thumb(),
						el('div', {className: 'envira-ia-field-picker'}, fieldRows)
					])
				]),
				el('div', {className: 'envira-ia-modal-foot envira-ia-modal-foot--center'}, [
					el('button', {
						className: 'envira-ia-btn envira-ia-btn--primary',
						html: '<span class="envira-ia-sparkle"></span> ' + (i18n.generate || 'Generate'),
						onclick: runGenerate
					})
				])
			]);
			return card;
		}

		// ── State 2: generating ──────────────────────────────────────────────
		function renderGenerating() {
			return el('div', {className: 'envira-ia-modal'}, [
				header(i18n.modalSubtitle || 'Automatically create and edit metadata for your images.'),
				el(
					'div',
					{className: 'envira-ia-modal-body', style: 'text-align:center;padding:36px 20px;'},
					[
						el('div', {className: 'envira-ia-spinner'}),
						el('p', {
							style: 'margin:14px 0 4px;font-weight:600;',
							text: i18n.generatingText || 'Generating Text'
						}),
						el('p', {
							style: 'margin:0;color:var(--ia-ink-muted);font-size:13px;',
							text: fmt(i18n.generatingDetail || 'Analyzing image and generating all %d fields', [
								pickedFields.length
							])
						})
					]
				),
				el('div', {className: 'envira-ia-modal-foot envira-ia-modal-foot--center'}, [
					el('button', {
						className: 'envira-ia-btn envira-ia-btn--primary',
						html: '<span class="envira-ia-sparkle"></span> ' + (i18n.generate || 'Generate'),
						disabled: 'disabled'
					})
				])
			]);
		}

		// ── State 3: results ─────────────────────────────────────────────────
		let currentResult = null;

		function renderResults(result) {
			currentResult = result;
			const cards = pickedFields.map(function (slug) {
				return fieldCard(slug, result.generated && result.generated[slug]);
			});

			return el('div', {className: 'envira-ia-modal envira-ia-modal--wide'}, [
				header(i18n.modalSubtitle || 'Automatically create and edit metadata for your images.'),
				el('div', {className: 'envira-ia-modal-body'}, [
					el('div', {className: 'envira-ia-results'}, [
						thumb(),
						el('div', {className: 'envira-ia-field-list'}, cards)
					])
				]),
				el('div', {className: 'envira-ia-modal-foot envira-ia-modal-foot--center'}, [
					el('button', {
						className: 'envira-ia-btn envira-ia-btn--primary',
						html: '<span class="envira-ia-check"></span> ' + (i18n.acceptAll || 'Accept All'),
						onclick: applyAccepted
					})
				])
			]);
		}

		function fieldCard(slug, value) {
			const card = el('div', {className: 'envira-ia-field'});

			const acceptBtn = el('button', {
				className: 'envira-ia-btn envira-ia-btn--small envira-ia-btn--dark',
				text: i18n.accept || 'Accept',
				onclick: function () {
					applyField(slug, card);
				}
			});

			const head = el('div', {className: 'envira-ia-field-head'}, [
				el('span', {className: 'envira-ia-field-label', text: FIELD_LABELS[slug] || slug}),
				el('div', {className: 'envira-ia-field-actions'}, [
					el('button', {
						className: 'envira-ia-btn envira-ia-btn--small envira-ia-btn--link',
						html: '<span class="envira-ia-recycle"></span> ' + (i18n.regenerate || 'Regenerate'),
						title: i18n.regenerateCost || 'Uses 1 credit',
						onclick: function () {
							regenerateField(slug, card);
						}
					}),
					acceptBtn
				])
			]);
			card.appendChild(head);
			const contentEl = fieldContent(slug, value);
			card.appendChild(contentEl);

			// Cache references so regenerate/accept can act on the card in place.
			card._content = contentEl;
			card._slug = slug;
			card._acceptBtn = acceptBtn;
			return card;
		}

		// Build the (editable) content node for a field value. `card._content`
		// always points at the live one so regenerate can swap it.
		function fieldContent(slug, value) {
			let node;
			if (slug === 'tags' && Array.isArray(value)) {
				node = el(
					'div',
					{className: 'envira-ia-field-content'},
					value.map(function (t) {
						return el('span', {className: 'envira-ia-pill', text: t});
					})
				);
			} else {
				node = el('div', {
					className: 'envira-ia-field-content',
					contenteditable: 'true',
					text: value || '—'
				});
			}
			return node;
		}

		function regenerateField(slug, card) {
			const actions = card.querySelector('.envira-ia-field-actions');
			if (actions) {
				actions.querySelectorAll('button').forEach(function (b) {
					b.disabled = true;
				});
			}
			card.classList.remove('envira-ia-field--error');

			// Per-field loading state: sparkle + "Generating…", swapped in for the
			// content node (the design shows this inline in the field). We always
			// act on the live card._content — a captured node would be detached
			// after the first regenerate, making later clicks no-ops. (QA #2/#10)
			const loading = el(
				'div',
				{className: 'envira-ia-field-content envira-ia-field-content--generating'},
				[
					el('span', {className: 'envira-ia-spinner envira-ia-spinner--inline'}),
					document.createTextNode(' ' + (i18n.generating || 'Generating…'))
				]
			);
			if (card._content) {
				card._content.replaceWith(loading);
			} else {
				card.appendChild(loading);
			}
			card._content = loading;

			api('regenerate-field', {
				method: 'POST',
				data: {attachment_id: attachmentId, field: slug, tone: tone}
			})
				.then(function (res) {
					if (res.status === 402) {
						renderFieldError(
							card,
							(res.body && res.body.message) || i18n.creditsExhaustedShort || 'Out of credits.'
						);
						return;
					}
					if (res.status < 200 || res.status >= 300) {
						renderFieldError(card, (res.body && res.body.message) || i18n.failed || 'Failed');
						return;
					}
					const value = res.body && res.body.value;
					currentResult.generated[slug] = value;
					const newContent = fieldContent(slug, value);
					card._content.replaceWith(newContent);
					card._content = newContent;
					loadAndApplyBalance();
				})
				.catch(function (err) {
					renderFieldError(card, (err && err.message) || i18n.failed || 'Failed');
				})
				.then(function () {
					if (actions) {
						actions.querySelectorAll('button').forEach(function (b) {
							b.disabled = false;
						});
					}
				});
		}

		function renderFieldError(card, msg) {
			card.classList.add('envira-ia-field--error');
			const node = el('div', {className: 'envira-ia-field-content', text: msg});
			if (card._content) {
				card._content.replaceWith(node);
			} else {
				card.appendChild(node);
			}
			card._content = node;
		}

		// Read the (possibly user-edited) current value of a field from its card.
		function readFieldValue(slug) {
			const card = Array.prototype.find.call(
				document.querySelectorAll('.envira-ia-field'),
				function (c) {
					return c._slug === slug;
				}
			);
			if (!card || !card._content) {
				return null;
			}
			if (slug === 'tags') {
				return Array.prototype.map.call(
					card._content.querySelectorAll('.envira-ia-pill'),
					function (pill) {
						return pill.textContent.trim();
					}
				);
			}
			return (card._content.textContent || '').trim();
		}

		// Per-field Accept (results state): apply just this field to the
		// attachment, mark the card accepted, and let the gallery editor patch
		// the item live via the shared event.
		function applyField(slug, card) {
			if (!currentResult || !currentResult.generated || !(slug in currentResult.generated)) {
				return;
			}
			const value = readFieldValue(slug);
			if (value === null || value === undefined || (slug !== 'tags' && value === '')) {
				toast(i18n.nothingToApply || 'Nothing to apply.', 'error');
				return;
			}
			const payload = {};
			payload[slug] = value;
			const btn = card._acceptBtn;
			if (btn) {
				btn.disabled = true;
			}

			api('apply-fields', {
				method: 'POST',
				data: {attachment_id: attachmentId, metadata: payload}
			})
				.then(function (res) {
					if (res.status >= 200 && res.status < 300) {
						card.classList.add('envira-ia-field--accepted');
						if (btn) {
							btn.textContent = i18n.accepted || 'Accepted';
						}
						document.dispatchEvent(
							new CustomEvent('envira-ia:image-generated', {
								detail: {attachmentId: attachmentId, applied: res.body && res.body.applied}
							})
						);
					} else {
						errorToast(res);
						if (btn) {
							btn.disabled = false;
						}
					}
				})
				.catch(function (err) {
					toast((err && err.message) || i18n.failed || 'Failed', 'error');
					if (btn) {
						btn.disabled = false;
					}
				});
		}

		function applyAccepted() {
			if (!currentResult || !currentResult.generated) {
				modal.close();
				return;
			}
			const payload = {};
			pickedFields.forEach(function (slug) {
				if (!(slug in currentResult.generated)) {
					return;
				}
				const value = readFieldValue(slug);
				if (value === null || value === undefined) {
					return;
				}
				if (slug === 'tags') {
					payload.tags = value;
				} else if (value !== '') {
					payload[slug] = value;
				}
			});

			if (!Object.keys(payload).length) {
				toast(i18n.nothingToApply || 'Nothing to apply.', 'error');
				return;
			}

			const foot = document.querySelector('.envira-ia-modal-foot');
			if (foot) {
				foot.querySelectorAll('button').forEach(function (b) {
					b.disabled = true;
				});
			}

			api('apply-fields', {
				method: 'POST',
				data: {attachment_id: attachmentId, metadata: payload}
			})
				.then(function (res) {
					if (res.status >= 200 && res.status < 300) {
						toast(i18n.applied || 'Applied.', 'success');
						document.dispatchEvent(
							new CustomEvent('envira-ia:image-generated', {
								detail: {attachmentId: attachmentId, applied: res.body && res.body.applied}
							})
						);
						modal.close();
					} else {
						errorToast(res);
						if (foot) {
							foot.querySelectorAll('button').forEach(function (b) {
								b.disabled = false;
							});
						}
					}
				})
				.catch(function (err) {
					toast((err && err.message) || i18n.failed || 'Failed', 'error');
					if (foot) {
						foot.querySelectorAll('button').forEach(function (b) {
							b.disabled = false;
						});
					}
				});
		}

		// Out-of-credits notice — shown in place of the results screen when the
		// server declines to generate (status 402), so the modal visibly does NOT
		// produce suggestions. Mirrors the bulk modal's renderBulkNotice().
		function renderSingleNotice(msg) {
			return el('div', {className: 'envira-ia-modal'}, [
				header(i18n.modalSubtitle || 'Automatically create and edit metadata for your images.'),
				el('div', {className: 'envira-ia-modal-body'}, [
					el('div', {className: 'envira-ia-warning'}, [
						el('span', {className: 'envira-ia-sparkle'}),
						el('div', {}, [
							el('strong', {text: i18n.creditsExhaustedShort || 'Out of credits.'}),
							el('p', {text: msg})
						])
					])
				]),
				el('div', {className: 'envira-ia-modal-foot envira-ia-modal-foot--center'}, [
					el('button', {
						className: 'envira-ia-btn envira-ia-btn--dark',
						text: i18n.close || 'Close',
						onclick: function () {
							modal.close();
						}
					})
				])
			]);
		}

		function runGenerate() {
			if (!pickedFields.length) {
				toast(i18n.pickAtLeastOne || 'Pick at least one field.', 'error');
				return;
			}
			modal.replace(renderGenerating());
			api('generate-preview', {
				method: 'POST',
				data: {attachment_id: attachmentId, tone: tone, fields: pickedFields}
			})
				.then(function (res) {
					if (res.status >= 200 && res.status < 300) {
						loadAndApplyBalance();
						modal.replace(renderResults(res.body));
					} else if (res.status === 402) {
						// Out of credits: don't advance to the results screen — show a
						// clear out-of-credits notice instead (mirrors the bulk modal).
						modal.replace(
							renderSingleNotice(
								(res.body && res.body.message) || i18n.creditsExhausted || 'Out of credits.'
							)
						);
					} else {
						errorToast(res);
						modal.close();
					}
				})
				.catch(function (err) {
					toast((err && err.message) || i18n.failed || 'Failed', 'error');
					modal.close();
				});
		}

		modal = openModal(renderPicker());
	}

	/* ─── Bulk Image Modal — 3 states ────────────────────────────────────── */

	// Resolve an attachment's thumbnail URL from the editor's already-loaded
	// <li> image (no extra fetch).
	function galleryThumbUrl(attachmentId) {
		const img = document.querySelector(
			'#envira-gallery-output li[data-envira-gallery-image="' + attachmentId + '"] img'
		);
		return img ? img.getAttribute('src') : '';
	}

	/* ─── Bulk background job (modal closed while still processing) ────────── */

	// When the bulk modal is closed mid-job the work keeps running server-side.
	// We track it here so the toolbar trigger can show a spinner and re-open the
	// modal on the progress view. Holds { jobId, galleryName, attachmentIds,
	// galleryId, lastState, pollHandle } while a backgrounded job runs.
	let bulkBg = null;

	// Swap the sparkle ⇄ spinner on every Bulk Image Assistant trigger.
	function bulkTriggerSetBusy(busy) {
		Array.prototype.forEach.call(document.querySelectorAll('.envira-ia-bulk'), function (btn) {
			const icon = btn.querySelector('.envira-ia-sparkle, .envira-ia-spinner');
			if (!icon) {
				return;
			}
			if (busy) {
				btn.setAttribute('data-busy', '1');
				if (!icon.classList.contains('envira-ia-spinner')) {
					icon.replaceWith(
						el('span', {
							className: 'envira-ia-spinner envira-ia-spinner--inline envira-ia-bulk-spinner'
						})
					);
				}
			} else {
				btn.removeAttribute('data-busy');
				if (icon.classList.contains('envira-ia-spinner')) {
					icon.replaceWith(el('span', {className: 'envira-ia-sparkle'}));
				}
			}
		});
	}

	// Reflect a running bulk job on the per-image sparkle triggers: every image
	// in the batch shows the spinner + is disabled (so it can't be opened in the
	// single-image modal while the batch is handling it). Each image clears as
	// soon as it completes — the poll reports completed ids in state.applied —
	// while skipped/failed ones clear when the whole job ends (bulkClearTriggers).
	// Reuses the auto-on-upload trigger spinner (setItemProcessing).
	function bulkSyncTriggers(ids, doneIds) {
		const done = {};
		(doneIds || []).forEach(function (id) {
			done[String(id)] = true;
		});
		(ids || []).forEach(function (id) {
			setItemProcessing(id, !done[String(id)]);
		});
	}
	function bulkClearTriggers(ids) {
		(ids || []).forEach(function (id) {
			setItemProcessing(id, false);
		});
	}

	// Patch each completed image's attributes (title/alt/caption/tags) the moment
	// the poll reports it in `applied` (id -> applied fields), so the gallery
	// thumbnails refresh per image AS each one finishes — instead of all at once
	// when the whole batch ends. `patchedSet` dedupes across polls so each image
	// is patched once. Mirrors pollAutoStatus()'s per-item patch.
	function bulkPatchApplied(appliedMap, patchedSet) {
		if (!appliedMap || typeof appliedMap !== 'object' || !patchedSet) {
			return;
		}
		Object.keys(appliedMap).forEach(function (id) {
			if (patchedSet[id]) {
				return;
			}
			patchedSet[id] = true;
			patchGalleryItem(parseInt(id, 10), appliedMap[id]);
		});
	}

	function bulkBgStop() {
		if (bulkBg && bulkBg.pollHandle) {
			clearTimeout(bulkBg.pollHandle);
		}
		bulkBg = null;
		bulkTriggerSetBusy(false);
	}

	function bulkBgPoll() {
		if (!bulkBg) {
			return;
		}
		api('bulk/' + encodeURIComponent(bulkBg.jobId))
			.then(function (res) {
				if (!bulkBg) {
					return;
				}
				if (res.status !== 200) {
					bulkBgStop();
					return;
				}
				bulkBg.lastState = res.body;
				if ('complete' === res.body.status || 'cancelled' === res.body.status) {
					bulkClearTriggers(bulkBg.attachmentIds);
					loadAndApplyBalance();
					document.dispatchEvent(new CustomEvent('envira-ia:bulk-complete', {detail: res.body}));
					if ('complete' === res.body.status) {
						toast(
							fmt(i18n.bulkComplete || 'Done: %1$d generated, %2$d failed.', [
								res.body.completed || 0,
								res.body.failed || 0
							]),
							'success'
						);
					}
					bulkBgStop();
				} else {
					bulkPatchApplied(res.body.applied, bulkBg.patched);
					bulkSyncTriggers(bulkBg.attachmentIds, Object.keys(res.body.applied || {}));
					bulkBg.pollHandle = setTimeout(bulkBgPoll, 1500);
				}
			})
			.catch(function () {
				if (bulkBg) {
					bulkBg.pollHandle = setTimeout(bulkBgPoll, 3000);
				}
			});
	}

	// Begin tracking a job in the background (called when the modal closes while
	// the job is still running).
	function bulkBgStart(info) {
		bulkBg = info;
		bulkBg.patched = bulkBg.patched || {};
		bulkTriggerSetBusy(true);
		bulkPatchApplied(bulkBg.lastState && bulkBg.lastState.applied, bulkBg.patched);
		bulkSyncTriggers(
			bulkBg.attachmentIds,
			bulkBg.lastState && bulkBg.lastState.applied ? Object.keys(bulkBg.lastState.applied) : []
		);
		bulkBg.pollHandle = setTimeout(bulkBgPoll, 1500);
	}

	// Enable every Bulk trigger (they render disabled so a click can't fire
	// before the script knows whether a job is already running).
	function enableBulkTrigger() {
		Array.prototype.forEach.call(document.querySelectorAll('.envira-ia-bulk'), function (btn) {
			btn.disabled = false;
		});
	}

	// On a fresh page load the in-memory job handle is gone, but a job may still
	// be running server-side. Ask the server and, if so, restore the background
	// spinner + resume capability for this gallery. Enable the trigger only once
	// this resolves, so the user can't start a duplicate batch in the meantime.
	function checkActiveBulkJob() {
		if (bulkBg) {
			enableBulkTrigger();
			return;
		}
		const btn = document.querySelector('.envira-ia-bulk');
		const gid = btn ? parseInt(btn.getAttribute('data-gallery-id'), 10) || 0 : 0;
		api('bulk/active' + (gid ? '?gallery_id=' + gid : ''))
			.then(function (res) {
				if (res.status === 200 && res.body && res.body.active && !bulkBg) {
					bulkBgStart({
						jobId: res.body.job_id,
						galleryName:
							res.body.gallery_name || (btn && btn.getAttribute('data-gallery-name')) || '',
						attachmentIds: res.body.attachment_ids || [],
						galleryId: res.body.gallery_id || gid,
						lastState: res.body.state || null
					});
				}
			})
			.catch(function () {})
			.then(enableBulkTrigger);
	}

	/* ─── Auto-on-upload: live "Generating…" badge ────────────────────────── */

	const autoTracked = {}; // attachment id -> true while we badge/poll it.
	let autoPollHandle = null;

	// While an image's metadata is generating, swap its per-image sparkle trigger
	// for a spinner and disable it (so it can't open the modal mid-generation);
	// restore the sparkle when done. Mirrors the bulk trigger's busy state.
	function setItemProcessing(id, on) {
		const li = document.querySelector(
			'#envira-gallery-output li[data-envira-gallery-image="' + id + '"]'
		);
		if (!li) {
			return;
		}
		const btn = li.querySelector('.envira-ia-image-trigger');
		if (!btn) {
			return;
		}
		const icon = btn.querySelector('.envira-ia-sparkle, .envira-ia-spinner');
		if (on) {
			btn.disabled = true;
			btn.setAttribute('title', i18n.generating || 'Generating…');
			if (icon && !icon.classList.contains('envira-ia-spinner')) {
				icon.replaceWith(
					el('span', {
						className: 'envira-ia-spinner envira-ia-spinner--inline envira-ia-trigger-spinner'
					})
				);
			}
		} else {
			btn.disabled = false;
			btn.setAttribute('title', i18n.imageAssistantTrigger || 'Image Assistant');
			if (icon && icon.classList.contains('envira-ia-spinner')) {
				icon.replaceWith(el('span', {className: 'envira-ia-sparkle'}));
			}
		}
	}

	function scheduleAutoPoll() {
		if (autoPollHandle || !Object.keys(autoTracked).length) {
			return;
		}
		// Subsequent polls kick the queue (run the queued generation).
		autoPollHandle = setTimeout(function () {
			pollAutoStatus(true);
		}, 2000);
	}

	// kick=false on the first read so the "pending" state (and the spinner) is
	// observed before the runner — which executes the generation synchronously —
	// would collapse it straight to "done".
	function pollAutoStatus(kick) {
		autoPollHandle = null;
		const ids = Object.keys(autoTracked);
		if (!ids.length) {
			return;
		}
		api('auto-status?ids=' + ids.join(',') + '&kick=' + (kick ? '1' : '0'))
			.then(function (res) {
				const items = (res.status === 200 && res.body && res.body.items) || {};
				let errMsg = null; // surface at most one failure per poll cycle.
				ids.forEach(function (id) {
					const m = items[id];
					if (!m) {
						// No marker (never queued, or expired) — stop tracking.
						setItemProcessing(id, false);
						// eslint-disable-next-line @typescript-eslint/no-dynamic-delete -- autoTracked is a plain-object map keyed by attachment ID; delete is required so Object.keys() stops re-polling it.
						delete autoTracked[id];
					} else if ('done' === m.status) {
						if (m.applied && Object.keys(m.applied).length) {
							patchGalleryItem(parseInt(id, 10), m.applied);
						}
						setItemProcessing(id, false);
						// eslint-disable-next-line @typescript-eslint/no-dynamic-delete -- autoTracked is a plain-object map keyed by attachment ID; delete is required so Object.keys() stops re-polling it.
						delete autoTracked[id];
					} else if ('error' === m.status) {
						// Generation failed server-side (commonly out of credits).
						// Restore the sparkle so a manual retry is possible and flag the
						// message for a single auto-dismissing toast after the loop.
						// (Deliberately NOT persistent — no close button on this one.)
						setItemProcessing(id, false);
						// eslint-disable-next-line @typescript-eslint/no-dynamic-delete -- autoTracked is a plain-object map keyed by attachment ID; delete is required so Object.keys() stops re-polling it.
						delete autoTracked[id];
						errMsg = m.message || i18n.failed || 'Could not generate metadata.';
					} else {
						setItemProcessing(id, true); // pending
					}
				});
				// Plain toast (auto-dismisses, no close button) — unlike the manual
				// single/bulk flows, upload-time errors shouldn't require a click.
				if (errMsg) {
					toast(errMsg, 'error');
				}
				scheduleAutoPoll();
			})
			.catch(function () {
				scheduleAutoPoll();
			});
	}

	// Start tracking the given attachment ids (badge appears once the server
	// confirms they're pending). Triggers an immediate poll when new ids appear.
	function trackAutoItems(ids) {
		let added = false;
		(ids || []).forEach(function (id) {
			id = String(id);
			if (id && '0' !== id && !autoTracked[id]) {
				autoTracked[id] = true;
				added = true;
			}
		});
		if (added) {
			if (autoPollHandle) {
				clearTimeout(autoPollHandle);
				autoPollHandle = null;
			}
			pollAutoStatus(false); // first read: don't kick, so the spinner shows
		}
	}

	function openBulkModal(opts) {
		opts = opts || {};
		const galleryName = opts.galleryName || '';
		const attachmentIds = opts.attachmentIds || [];
		const galleryId = opts.galleryId || 0;
		const pickerFields = gateFields(SINGLE_DEFAULT_PICKER);
		let pickedFields = gateFields(
			opts.defaultFields && opts.defaultFields.length ? opts.defaultFields : SINGLE_DEFAULT_PICKER
		);
		const tone = opts.tone || (cfg.defaults && cfg.defaults.tone) || 'seo';
		let modal;
		let pollHandle = null;
		const resume = opts.resume || null;
		let jobId = resume ? resume.jobId : null;
		let lastState = resume ? resume.lastState : null;
		let finished = false;
		const patched = {}; // attachment ids already live-patched into the gallery.

		function header(subtitle) {
			return el('div', null, [
				el('div', {className: 'envira-ia-modal-head'}, [
					el('div', {className: 'envira-ia-modal-title'}, [
						el('span', {className: 'envira-ia-sparkle envira-ia-sparkle--lg'}),
						document.createTextNode(' ' + (i18n.bulkModalTitle || 'Bulk Image Assistant'))
					]),
					el('button', {
						className: 'envira-ia-btn envira-ia-btn--icon',
						html: '×',
						onclick: function () {
							modal.close();
						}
					})
				]),
				el('p', {
					className: 'envira-ia-modal-subtitle',
					text:
						subtitle ||
						i18n.modalSubtitle ||
						'Automatically generate and edit metadata for your images.'
				})
			]);
		}

		// Gallery name + image count (top of the panel in every state).
		function bulkHead() {
			return el('div', {className: 'envira-ia-bulk-head'}, [
				el('div', {
					className: 'envira-ia-bulk-gallery-name',
					text: galleryName || i18n.bulkModalTitle || 'Bulk Image Assistant'
				}),
				el('div', {
					className: 'envira-ia-bulk-count',
					text: fmt(i18n.bulkAllImages || '%d images', [attachmentIds.length])
				})
			]);
		}

		// One representative thumbnail + a darkened "+N" tile for the batch.
		function thumbs() {
			const urls = attachmentIds.map(galleryThumbUrl).filter(Boolean);
			const nodes = [];
			if (urls[0]) {
				nodes.push(el('img', {className: 'envira-ia-bulk-thumb', src: urls[0], alt: ''}));
			}
			if (attachmentIds.length > 1) {
				// "+N" counts the images BEYOND the first thumbnail already shown,
				// so it's length-1 (select 2 → "+1", select 3 → "+2").
				const more = el('div', {className: 'envira-ia-bulk-thumb envira-ia-bulk-thumb-more'}, [
					el('span', {text: '+' + (attachmentIds.length - 1)})
				]);
				if (urls[1]) {
					more.style.backgroundImage = 'url("' + urls[1] + '")';
				}
				nodes.push(more);
			}
			return el('div', {className: 'envira-ia-bulk-thumbs'}, nodes);
		}

		// ── State 1: picker ──────────────────────────────────────────────────
		function renderPicker() {
			const fieldRows = pickerFields.map(function (slug) {
				const checked = pickedFields.indexOf(slug) !== -1;
				const input = el('input', {
					type: 'checkbox',
					className: 'envira-ia-checkbox',
					value: slug,
					onchange: function () {
						if (input.checked) {
							if (pickedFields.indexOf(slug) === -1) {
								pickedFields.push(slug);
							}
						} else {
							pickedFields = pickedFields.filter(function (f) {
								return f !== slug;
							});
						}
					}
				});
				if (checked) {
					input.checked = true;
				}
				return el('label', {className: 'envira-ia-field-checkbox'}, [
					input,
					el('span', {className: 'envira-ia-checkmark'}),
					el('span', {className: 'envira-ia-checkbox-label', text: FIELD_LABELS[slug] || slug})
				]);
			});

			const costNotice = el('div', {
				className: 'envira-ia-cost-notice',
				text: fmt(
					i18n.bulkCostNotice || 'Each image uses 1 credit. The batch will use up to %d credits.',
					[attachmentIds.length]
				)
			});

			// Reflect the actual overwrite setting: when skip-if-existing is off,
			// existing metadata is overwritten, so the notice must say the opposite.
			const skipsExisting = !(cfg.defaults && cfg.defaults.overwriteSkip === false);
			const skipText = skipsExisting
				? i18n.bulkSkipNotice || 'Images with existing metadata will be skipped.'
				: i18n.bulkOverwriteNotice || 'Images with existing metadata will be overwritten.';
			const skipRow = el('div', {className: 'envira-ia-skip-row'}, [
				el('span', {text: skipText}),
				el('a', {
					className: 'envira-ia-change-settings',
					href: 'admin.php?page=envira-gallery-settings#envira-tab-image_assistant',
					target: '_blank',
					text: i18n.changeSettings || 'Change Settings'
				})
			]);

			return el('div', {className: 'envira-ia-modal'}, [
				header(),
				el('div', {className: 'envira-ia-modal-body'}, [
					el('div', {className: 'envira-ia-bulk-panel'}, [
						bulkHead(),
						el('div', {className: 'envira-ia-bulk-row'}, [
							thumbs(),
							el('div', {className: 'envira-ia-field-picker'}, fieldRows)
						]),
						costNotice,
						skipRow
					])
				]),
				el('div', {className: 'envira-ia-modal-foot envira-ia-modal-foot--center'}, [
					el('button', {
						className: 'envira-ia-btn envira-ia-btn--primary',
						html: '<span class="envira-ia-sparkle"></span> ' + (i18n.generate || 'Generate'),
						onclick: startJob
					})
				])
			]);
		}

		// Shared progress block (processing + completed states): an optional
		// leading icon + title, the bar, and a meta line.
		function progressBlock(titleNode, pct, metaNode) {
			return el('div', {className: 'envira-ia-bulk-progress'}, [
				el('p', {className: 'envira-ia-bulk-progress-title'}, titleNode),
				el('div', {className: 'envira-ia-bar', 'data-state': 'ok'}, [
					el('div', {className: 'envira-ia-bar-fill', style: 'width:' + pct + '%;'})
				]),
				el('p', {className: 'envira-ia-bulk-progress-meta'}, metaNode)
			]);
		}

		// ── State 2: processing ──────────────────────────────────────────────
		function renderProcessing(state) {
			const completed = state.completed || 0;
			const skipped = state.skipped || 0;
			const processed = completed + (state.failed || 0) + skipped;
			const total = state.total || attachmentIds.length;
			const pct = total > 0 ? Math.round((processed / total) * 100) : 0;

			return el('div', {className: 'envira-ia-modal'}, [
				header(),
				el('div', {className: 'envira-ia-modal-body'}, [
					el('div', {className: 'envira-ia-bulk-panel'}, [
						bulkHead(),
						el('div', {className: 'envira-ia-bulk-row'}, [
							thumbs(),
							progressBlock(
								[
									document.createTextNode(
										fmt(i18n.processingHeader || 'Processing %1$d of %2$d images', [
											processed,
											total
										])
									)
								],
								pct,
								[
									el('span', {className: 'envira-ia-spinner envira-ia-spinner--inline'}),
									document.createTextNode(
										' ' +
											fmt(i18n.bulkProgressMeta || '%1$d / %2$d completed · %3$d skipped', [
												completed,
												total,
												skipped
											])
									)
								]
							)
						]),
						el('p', {
							className: 'envira-ia-bulk-bg-note',
							text:
								i18n.bulkBackground ||
								'You can close this window and it will keep running in the background.'
						})
					])
				]),
				el('div', {className: 'envira-ia-modal-foot envira-ia-modal-foot--center'}, [
					el('button', {
						className: 'envira-ia-btn envira-ia-btn--danger-ghost',
						text: i18n.cancelProcessing || 'Cancel Processing',
						onclick: cancelJob
					})
				])
			]);
		}

		// ── State 3: completed ───────────────────────────────────────────────
		function renderCompleted(state) {
			const completed = state.completed || 0;
			const skipped = state.skipped || 0;
			const total = state.total || 0;
			const cancelled = 'cancelled' === state.status;
			const msg = cancelled
				? i18n.bulkCancelled || 'Processing Cancelled'
				: i18n.processingCompleted || 'Processing Completed';
			const elapsed = state.finished && state.started ? state.finished - state.started : 0;
			const failed = state.failed || 0;

			const titleNode = [];
			if (!cancelled) {
				titleNode.push(
					el('span', {className: 'envira-ia-check-badge'}, [
						el('span', {className: 'envira-ia-check'})
					])
				);
			}
			titleNode.push(document.createTextNode(' ' + msg));

			return el('div', {className: 'envira-ia-modal'}, [
				header(),
				el('div', {className: 'envira-ia-modal-body'}, [
					el('div', {className: 'envira-ia-bulk-panel envira-ia-bulk-panel--complete'}, [
						bulkHead(),
						el('div', {className: 'envira-ia-bulk-row'}, [
							thumbs(),
							progressBlock(titleNode, 100, [
								document.createTextNode(
									fmt(i18n.bulkCompletedMeta || '%1$d / %2$d Metadata completed · %3$d skipped', [
										completed,
										total,
										skipped
									])
								),
								el('span', {
									className: 'envira-ia-info',
									text: 'i',
									title:
										fmt(i18n.bulkSummary || '%1$d / %2$d Metadata completed in %3$ds', [
											completed,
											total,
											elapsed
										]) + (failed ? ' · ' + failed + ' failed' : '')
								})
							])
						])
					])
				]),
				el('div', {className: 'envira-ia-modal-foot envira-ia-modal-foot--center'}, [
					el('button', {
						className: 'envira-ia-btn envira-ia-btn--ghost',
						text: i18n.retry || 'Retry',
						onclick: function () {
							modal.replace(renderPicker());
						}
					}),
					el('button', {
						className: 'envira-ia-btn envira-ia-btn--dark',
						text: i18n.close || 'Close',
						onclick: function () {
							modal.close();
						}
					})
				])
			]);
		}

		// Out-of-credits notice — shown in place of the picker/progress when the
		// server refuses to start the batch (status 402). The batch visibly does
		// NOT run, so the user never sees a misleading "Processing Completed".
		function renderBulkNotice(msg) {
			return el('div', {className: 'envira-ia-modal'}, [
				header(),
				el('div', {className: 'envira-ia-modal-body'}, [
					el('div', {className: 'envira-ia-bulk-panel'}, [
						el('div', {className: 'envira-ia-warning'}, [
							el('span', {className: 'envira-ia-sparkle'}),
							el('div', {}, [
								el('strong', {text: i18n.creditsExhaustedShort || 'Out of credits.'}),
								el('p', {text: msg})
							])
						])
					])
				]),
				el('div', {className: 'envira-ia-modal-foot envira-ia-modal-foot--center'}, [
					el('button', {
						className: 'envira-ia-btn envira-ia-btn--dark',
						text: i18n.close || 'Close',
						onclick: function () {
							modal.close();
						}
					})
				])
			]);
		}

		function startJob() {
			if (!attachmentIds.length) {
				toast(i18n.selectFirst || 'Select images first.', 'error');
				return;
			}
			if (!pickedFields.length) {
				toast(i18n.pickAtLeastOne || 'Pick at least one field.', 'error');
				return;
			}

			modal.replace(
				renderProcessing({total: attachmentIds.length, completed: 0, failed: 0, skipped: 0})
			);

			api('bulk/start', {
				method: 'POST',
				data: {
					attachment_ids: attachmentIds,
					tone: tone,
					fields: pickedFields,
					gallery_id: galleryId
				}
			})
				.then(function (res) {
					// Out of credits: the server declined to start. Keep the modal open
					// on a clear notice instead of a vanishing toast / a "completed" view.
					if (res.status === 402) {
						modal.replace(
							renderBulkNotice(
								(res.body && res.body.message) || i18n.creditsExhausted || 'Out of credits.'
							)
						);
						return;
					}
					if (res.status < 200 || res.status >= 300) {
						errorToast(res);
						modal.close();
						return;
					}
					jobId = res.body && res.body.job_id;
					if (!jobId) {
						modal.close();
						return;
					}
					bulkSyncTriggers(attachmentIds, []);
					poll();
				})
				.catch(function (err) {
					toast((err && err.message) || i18n.failed || 'Failed', 'error');
					modal.close();
				});
		}

		function poll() {
			api('bulk/' + encodeURIComponent(jobId))
				.then(function (res) {
					if (res.status !== 200) {
						toast((res.body && res.body.message) || 'Job lost', 'error');
						modal.close();
						return;
					}
					const state = res.body;
					lastState = state;
					if (state.status === 'complete' || state.status === 'cancelled') {
						finished = true;
						bulkClearTriggers(attachmentIds);
						loadAndApplyBalance();
						document.dispatchEvent(new CustomEvent('envira-ia:bulk-complete', {detail: state}));
						modal.replace(renderCompleted(state));
					} else {
						modal.replace(renderProcessing(state));
						bulkPatchApplied(state.applied, patched);
						bulkSyncTriggers(attachmentIds, Object.keys(state.applied || {}));
						pollHandle = setTimeout(poll, 1500);
					}
				})
				.catch(function () {
					pollHandle = setTimeout(poll, 3000);
				});
		}

		function cancelJob() {
			if (!jobId) {
				modal.close();
				return;
			}
			api('bulk/' + encodeURIComponent(jobId) + '/cancel', {method: 'POST'}).then(function () {
				if (pollHandle) {
					clearTimeout(pollHandle);
					pollHandle = null;
				}
				poll(); // one more pull to display the cancelled state
			});
		}

		// Closing while a job is still running doesn't stop it (server-side AS
		// keeps going) — hand it to the background tracker so the toolbar shows a
		// spinner and can re-open this progress view.
		function handleClose() {
			if (pollHandle) {
				clearTimeout(pollHandle);
				pollHandle = null;
			}
			if (jobId && !finished) {
				bulkBgStart({
					jobId: jobId,
					galleryName: galleryName,
					attachmentIds: attachmentIds,
					galleryId: galleryId,
					lastState: lastState
				});
			}
		}

		if (resume && jobId) {
			// Re-opened from the background spinner: jump straight to progress.
			modal = openModal(
				renderProcessing(
					lastState || {total: attachmentIds.length, completed: 0, failed: 0, skipped: 0}
				),
				{dismissable: true, onClose: handleClose}
			);
			poll();
		} else {
			modal = openModal(renderPicker(), {dismissable: true, onClose: handleClose});
		}
	}

	/* ─── Triggers: sparkle icon per image + bulk button ─────────────────── */

	/**
	 * Walk current <li data-envira-gallery-image="…"> nodes and prepend our
	 * sparkle trigger to any that don't have one yet.
	 */
	function injectSparkleTriggers(root) {
		root = root || document;
		const lis = root.querySelectorAll('#envira-gallery-output li[data-envira-gallery-image]');
		Array.prototype.forEach.call(lis, function (li) {
			if (li.querySelector('.envira-ia-image-trigger')) {
				return;
			}
			const id = parseInt(li.getAttribute('data-envira-gallery-image'), 10);
			if (!id) {
				return;
			}
			// No per-button click listener here: Envira's drag-sort clones the
			// selected <li>s and replaces the originals (helper/stop in
			// metabox.js), and clones don't carry addEventListener handlers —
			// the cloned button would then be skipped by the early-return above
			// and never rebound, leaving a dead sparkle. The click is handled by
			// a delegated listener in bindGalleryEditor() instead, which survives
			// any clone/re-render.
			const btn = el(
				'button',
				{
					type: 'button',
					className: 'envira-ia-image-trigger',
					'data-attachment': String(id),
					title: i18n.imageAssistantTrigger || 'Image Assistant'
				},
				[el('span', {className: 'envira-ia-sparkle'})]
			);
			li.insertBefore(btn, li.firstChild);
		});
	}

	/**
	 * Patch a gallery-editor <li> in place after metadata is applied, so the
	 * change shows immediately and — crucially — is the value Envira reads back
	 * on save. EnviraGalleryImagesUpdate() rebuilds its Backbone collection from
	 * each item's data-envira-gallery-image-model attribute at save time, so
	 * without this the editor shows the stale title/alt until reload AND a
	 * subsequent Save would write the stale values straight back over the ones
	 * the server just synced into _eg_gallery_data. (todo-issue 04)
	 *
	 * @param {number} attachmentId Attachment ID.
	 * @param {Object} applied      Applied fields keyed by attachment field name:
	 *                              { alt_text?, title?, caption? }. The Backbone
	 *                              model uses Envira's per-image keys (alt/title/
	 *                              caption), so alt_text maps onto `alt`.
	 */
	function patchGalleryItem(attachmentId, applied) {
		attachmentId = parseInt(attachmentId, 10);
		if (!attachmentId || !applied || typeof applied !== 'object') {
			return;
		}

		const li = document.querySelector(
			'#envira-gallery-output li[data-envira-gallery-image="' + attachmentId + '"]'
		);
		if (!li) {
			return;
		}

		const has = function (k) {
			return Object.prototype.hasOwnProperty.call(applied, k);
		};
		const str = function (v) {
			return v === null || v === undefined ? '' : String(v);
		};

		// Visible DOM: alt on the thumbnail.
		if (has('alt_text')) {
			const img = li.querySelector('img');
			if (img) {
				img.setAttribute('alt', str(applied.alt_text));
			}
		}

		// Visible DOM: title text + the "…" hint (shown only when title > 20 chars).
		if (has('title')) {
			const title = str(applied.title);
			const span = li.querySelector('.meta .title span');
			if (span) {
				span.textContent = title;
			}
			const hint = li.querySelector('.meta .title a.hint');
			if (hint) {
				hint.setAttribute('title', title);
				hint.classList.toggle('hidden', title.length <= 20);
			}
		}

		// Backbone source-of-truth: merge into the JSON model attribute that
		// EnviraGalleryImagesUpdate() re-reads on save.
		const raw = li.getAttribute('data-envira-gallery-image-model');
		if (!raw) {
			return;
		}
		let model;
		try {
			model = JSON.parse(raw.replace(/(\r\n|\n|\r)/gm, ''));
		} catch {
			return; // Leave the attribute untouched rather than corrupt it.
		}
		if (!model || typeof model !== 'object') {
			return;
		}
		if (has('alt_text')) {
			model.alt = str(applied.alt_text);
		}
		if (has('title')) {
			model.title = str(applied.title);
		}
		if (has('caption')) {
			model.caption = str(applied.caption);
		}
		// Envira stores per-image tags as a comma-separated STRING (see the Tags
		// addon's get_tags()), which the Edit Metadata modal reads via
		// {{ data.tags }}. The applier returns applied tags as an array — join to
		// match, so freshly-generated tags show in the editor without a reload.
		if (has('tags')) {
			model.tags = Array.isArray(applied.tags) ? applied.tags.join(', ') : str(applied.tags);
		}
		li.setAttribute('data-envira-gallery-image-model', JSON.stringify(model));
	}

	function bindGalleryEditor() {
		const output = document.querySelector('#envira-gallery-output');
		if (!output) {
			return;
		}
		injectSparkleTriggers();

		// Restore the in-progress indicator if a bulk job for this gallery is
		// still running server-side (e.g. the page was reloaded mid-batch).
		// (The toolbar is anchored to the title row purely in CSS, so it's in
		// the right place from first paint — no JS positioning needed here.)
		checkActiveBulkJob();

		// Auto-on-upload: badge images while their metadata generates and patch
		// them live when ready. On load, scan current items (catches in-flight
		// generations after a reload); new uploads are picked up by the observer.
		const autoUpload = cfg.defaults && cfg.defaults.autoOnUpload;
		if (autoUpload) {
			trackAutoItems(liIds(output.querySelectorAll('li[data-envira-gallery-image]')));
		}

		// Delegated sparkle click. Bound once to the stable output container so
		// it keeps working after Envira's drag-sort clones items or re-renders
		// the list — unlike a per-button listener, which a clone would drop.
		output.addEventListener('click', function (evt) {
			const trigger = evt.target.closest && evt.target.closest('.envira-ia-image-trigger');
			if (!trigger) {
				return;
			}
			evt.preventDefault();
			evt.stopPropagation();
			const li = trigger.closest('li[data-envira-gallery-image]');
			const id = li
				? parseInt(li.getAttribute('data-envira-gallery-image'), 10)
				: parseInt(trigger.getAttribute('data-attachment'), 10);
			if (id) {
				openSingleImageModal(id);
			}
		});

		const observer = new MutationObserver(function (muts) {
			const addedIds = [];
			for (let i = 0; i < muts.length; i++) {
				const nodes = muts[i].addedNodes;
				if (!nodes || !nodes.length) {
					continue;
				}
				injectSparkleTriggers();
				// Collect added items unconditionally (not gated on the page-load
				// auto-upload config): the server marker is the source of truth, so
				// this also works if the setting was enabled after this page loaded.
				// Non-queued ids just return no marker and drop out of tracking.
				Array.prototype.forEach.call(nodes, function (n) {
					if (n.nodeType !== 1) {
						return;
					}
					if (n.matches && n.matches('li[data-envira-gallery-image]')) {
						addedIds.push(n.getAttribute('data-envira-gallery-image'));
					}
				});
			}
			// Newly-added items may be fresh uploads queued for generation; track
			// them (non-queued ids simply return no marker and drop out).
			if (addedIds.length) {
				trackAutoItems(addedIds);
			}
		});
		observer.observe(output, {childList: true, subtree: false});
	}

	// Collect attachment ids from a NodeList of gallery <li> items.
	function liIds(lis) {
		return Array.prototype.map
			.call(lis, function (li) {
				return li.getAttribute('data-envira-gallery-image');
			})
			.filter(Boolean);
	}

	function bindBulkTrigger() {
		document.addEventListener('click', function (evt) {
			const btn = evt.target.closest && evt.target.closest('.envira-ia-bulk');
			if (!btn) {
				return;
			}
			evt.preventDefault();

			// A backgrounded job is running — re-open it on the progress view
			// instead of starting a new batch. The modal takes back over polling.
			if (bulkBg) {
				const bg = bulkBg;
				bulkBgStop();
				openBulkModal({
					attachmentIds: bg.attachmentIds,
					galleryId: bg.galleryId,
					galleryName: bg.galleryName,
					resume: {jobId: bg.jobId, lastState: bg.lastState}
				});
				return;
			}

			const selector =
				btn.getAttribute('data-source') ||
				'#envira-gallery-output li.envira-gallery-image.selected';
			let selectedNodes = document.querySelectorAll(selector);
			// Fall back: if nothing selected, treat all images in the gallery as the target.
			if (!selectedNodes.length) {
				selectedNodes = document.querySelectorAll(
					'#envira-gallery-output li[data-envira-gallery-image]'
				);
			}
			const ids = Array.prototype.map
				.call(selectedNodes, function (el) {
					return parseInt(
						el.getAttribute('data-envira-gallery-image') || el.getAttribute('data-attachment'),
						10
					);
				})
				.filter(Boolean);

			if (!ids.length) {
				toast(i18n.selectFirst || 'Select images first.', 'error');
				return;
			}

			openBulkModal({
				attachmentIds: ids,
				galleryId: parseInt(btn.getAttribute('data-gallery-id'), 10) || 0,
				galleryName: btn.getAttribute('data-gallery-name') || ''
			});
		});
	}

	/* ─── Media Library: inline AI controls in attachment edit modal ─────── */

	const ATTACHMENT_FIELD_MAP = {
		title: {selector: 'input[data-setting="title"]', slug: 'title'},
		alt: {selector: 'input[data-setting="alt"]', slug: 'alt_text'},
		caption: {selector: 'textarea[data-setting="caption"]', slug: 'caption'}
	};

	function inlineAttachmentControls(root) {
		Object.keys(ATTACHMENT_FIELD_MAP).forEach(function (key) {
			const meta = ATTACHMENT_FIELD_MAP[key];
			const input = root.querySelector(meta.selector);
			if (!input || input.dataset.enviraIaWired) {
				return;
			}
			input.dataset.enviraIaWired = '1';

			const btn = el('button', {
				type: 'button',
				className:
					'envira-ia-btn envira-ia-btn--small envira-ia-btn--ghost envira-ia-attachment-regen',
				html: '<span class="envira-ia-sparkle"></span> ' + (i18n.regenerate || 'Regenerate'),
				style: 'margin-left:6px;',
				title: i18n.regenerateCost || 'Uses 1 credit'
			});

			btn.addEventListener('click', function (evt) {
				evt.preventDefault();
				const attachmentId = inferAttachmentId(root);
				if (!attachmentId) {
					toast(i18n.failed || 'Failed', 'error');
					return;
				}
				btn.disabled = true;
				const origLabel = btn.innerHTML;
				btn.innerHTML =
					'<span class="envira-ia-sparkle"></span> ' + (i18n.generating || 'Generating…');

				api('regenerate-field', {
					method: 'POST',
					data: {attachment_id: attachmentId, field: meta.slug}
				})
					.then(function (res) {
						if (res.status >= 200 && res.status < 300) {
							const value = res.body && res.body.value;
							input.value =
								meta.slug === 'tags' && Array.isArray(value) ? value.join(', ') : value || '';
							input.dispatchEvent(new Event('input', {bubbles: true}));
							input.dispatchEvent(new Event('change', {bubbles: true}));
							toast(i18n.regenerated || 'Suggestion ready.', 'success');
							loadAndApplyBalance();
						} else {
							errorToast(res);
						}
					})
					.catch(function (err) {
						toast((err && err.message) || i18n.failed || 'Failed', 'error');
					})
					.then(function () {
						btn.disabled = false;
						btn.innerHTML = origLabel;
					});
			});

			// Insert next to the input. WP wraps inputs in <label> with .name + .value;
			// dropping the button after the input keeps the layout sane.
			const parent = input.parentElement;
			if (parent) {
				parent.appendChild(btn);
			}
		});
	}

	/*
	 * Envira's own "Edit Metadata" modal (the pencil on a gallery image). Unlike
	 * WP's media library it uses name="…" inputs, so it isn't matched by
	 * inlineAttachmentControls. Add Regenerate (green text) + Accept (green
	 * button) to each of Title / Caption / Alt Text / Tags. Identified by the
	 * Envira "Save Metadata" button so we never touch the WP media library.
	 */
	const ENVIRA_META_FIELDS = [
		{name: 'title', slug: 'title'},
		{name: 'caption', slug: 'caption'},
		{name: 'alt', slug: 'alt_text'},
		{name: 'tags', slug: 'tags'}
	];

	function enviraEditMetadataControls(root) {
		if (!root || !root.querySelector || !root.querySelector('.envira-gallery-meta-submit')) {
			return;
		}
		const idInput = root.querySelector('input[name="id"]');

		ENVIRA_META_FIELDS.forEach(function (f) {
			// Honor the tag-availability rule (issue 01): no tag controls when
			// the Envira Tags addon is inactive.
			if ('tags' === f.slug && !tagsAvailable()) {
				return;
			}

			const input = root.querySelector('[name="' + f.name + '"]');
			if (!input || 'hidden' === input.type) {
				return;
			}
			const setting = input.closest('.setting');
			if (!setting || setting.dataset.enviraIaWired) {
				return;
			}
			setting.dataset.enviraIaWired = '1';

			function attachmentId() {
				return idInput ? parseInt(idInput.value, 10) : inferAttachmentId(root);
			}

			const regen = el('button', {
				type: 'button',
				className: 'envira-ia-btn envira-ia-btn--small envira-ia-btn--link',
				text: i18n.regenerate || 'Regenerate',
				title: i18n.regenerateCost || 'Uses 1 credit'
			});
			const accept = el('button', {
				type: 'button',
				className: 'envira-ia-btn envira-ia-btn--small envira-ia-btn--primary',
				text: i18n.accept || 'Accept'
			});

			// Regenerate: fetch a fresh AI suggestion and drop it into the field.
			regen.addEventListener('click', function (evt) {
				evt.preventDefault();
				evt.stopPropagation();
				const id = attachmentId();
				if (!id) {
					toast(i18n.failed || 'Failed', 'error');
					return;
				}
				regen.disabled = true;
				const orig = regen.innerHTML;
				regen.innerHTML =
					'<span class="envira-ia-spinner envira-ia-spinner--inline"></span> ' +
					(i18n.generating || 'Generating…');
				api('regenerate-field', {
					method: 'POST',
					data: {attachment_id: id, field: f.slug}
				})
					.then(function (res) {
						if (res.status >= 200 && res.status < 300) {
							const value = res.body && res.body.value;
							input.value =
								'tags' === f.slug && Array.isArray(value) ? value.join(', ') : value || '';
							input.dispatchEvent(new Event('input', {bubbles: true}));
							input.dispatchEvent(new Event('change', {bubbles: true}));
							toast(i18n.regenerated || 'Suggestion ready.', 'success');
							loadAndApplyBalance();
						} else {
							errorToast(res);
						}
					})
					.catch(function (err) {
						toast((err && err.message) || i18n.failed || 'Failed', 'error');
					})
					.then(function () {
						regen.disabled = false;
						regen.innerHTML = orig;
					});
			});

			// Accept: apply the field's current value to the attachment now, and
			// let the gallery editor patch the item live via the shared event.
			accept.addEventListener('click', function (evt) {
				evt.preventDefault();
				evt.stopPropagation();
				const id = attachmentId();
				if (!id) {
					toast(i18n.failed || 'Failed', 'error');
					return;
				}
				const raw = (input.value || '').trim();
				if (!raw) {
					toast(i18n.nothingToApply || 'Nothing to apply.', 'error');
					return;
				}
				const payload = {};
				if ('tags' === f.slug) {
					payload.tags = raw
						.split(',')
						.map(function (t) {
							return t.trim();
						})
						.filter(Boolean);
				} else {
					payload[f.slug] = raw;
				}
				accept.disabled = true;
				api('apply-fields', {
					method: 'POST',
					data: {attachment_id: id, metadata: payload}
				})
					.then(function (res) {
						if (res.status >= 200 && res.status < 300) {
							toast(i18n.applied || 'Applied.', 'success');
							document.dispatchEvent(
								new CustomEvent('envira-ia:image-generated', {
									detail: {attachmentId: id, applied: res.body && res.body.applied}
								})
							);
						} else {
							errorToast(res);
						}
					})
					.catch(function (err) {
						toast((err && err.message) || i18n.failed || 'Failed', 'error');
					})
					.then(function () {
						accept.disabled = false;
					});
			});

			// Place the controls on the same row as the field label, right-
			// aligned (absolute, top-right of the setting). Wrap in .envira-ia so
			// the design tokens (--ia-*) resolve — they're scoped to that class
			// and this modal lives outside our overlay.
			setting.classList.add('envira-ia-has-actions');
			setting.appendChild(
				el('div', {className: 'envira-ia envira-ia-meta-actions'}, [regen, accept])
			);
		});
	}

	function inferAttachmentId(root) {
		// WP's media frame stores the attachment model on a wrapper element.
		const attachmentWrap = root.closest && root.closest('[data-id]');
		if (attachmentWrap) {
			const id = parseInt(attachmentWrap.getAttribute('data-id'), 10);
			if (id) {
				return id;
			}
		}
		// Fall back to global wp.media state if available.
		if (window.wp && wp.media && wp.media.frame) {
			const sel =
				wp.media.frame.state &&
				wp.media.frame.state().get &&
				wp.media.frame.state().get('selection');
			if (sel) {
				const first = sel.first && sel.first();
				if (first && first.get('id')) {
					return first.get('id');
				}
			}
		}
		return 0;
	}

	// Inject both control sets into a panel: WP media library (data-setting)
	// and Envira's Edit Metadata modal (name=). Each is a no-op on the other's
	// markup, and both guard against double-wiring.
	function wireAttachmentPanel(panel) {
		inlineAttachmentControls(panel);
		enviraEditMetadataControls(panel);
	}

	function bindMediaLibrary() {
		// The attachment details panel ('.attachment-details') is added and removed
		// repeatedly by wp.media. Observe the body for it appearing.
		const observer = new MutationObserver(function (muts) {
			muts.forEach(function (m) {
				m.addedNodes.forEach(function (n) {
					if (!(n instanceof HTMLElement)) {
						return;
					}
					const panels =
						n.matches && n.matches('.attachment-details')
							? [n]
							: Array.from(n.querySelectorAll ? n.querySelectorAll('.attachment-details') : []);
					if (panels.length) {
						panels.forEach(wireAttachmentPanel);
					} else {
						// A field rendered into an existing panel after it mounted
						// (e.g. the Tags addon appends its row late) — re-scan the
						// enclosing panel so the tags control gets wired.
						const panel = n.closest && n.closest('.attachment-details');
						if (panel) {
							enviraEditMetadataControls(panel);
						}
					}
				});
			});
		});
		observer.observe(document.body, {childList: true, subtree: true});
		// Cover panels that exist at boot time.
		document.querySelectorAll('.attachment-details').forEach(wireAttachmentPanel);
	}

	/**
	 * Wire the "Regenerate description with AI" button in the gallery
	 * Configuration tab. Calls the gallery-description endpoint (apply=false, so
	 * it only returns text) and drops the result into the description editor for
	 * the user to review and save. Delegated so it works regardless of tab state.
	 */
	function bindGalleryDescriptionButton() {
		document.addEventListener('click', function (evt) {
			const btn = evt.target.closest && evt.target.closest('.envira-ia-generate-desc');
			if (!btn || btn.disabled) {
				return;
			}
			evt.preventDefault();
			const gid = parseInt(btn.getAttribute('data-gallery-id'), 10) || 0;
			if (!gid) {
				return;
			}
			const status = btn.parentNode
				? btn.parentNode.querySelector('.envira-ia-generate-desc-status')
				: null;
			btn.disabled = true;
			if (status) {
				status.textContent = i18n.generating || 'Generating…';
			}
			api('gallery-description', {method: 'POST', data: {gallery_id: gid, apply: false}})
				.then(function (res) {
					btn.disabled = false;
					if (status) {
						status.textContent = '';
					}
					if (res.status >= 200 && res.status < 300 && res.body && res.body.description) {
						setGalleryDescription(res.body.description);
						toast(
							i18n.descGenerated ||
								'Description generated — review it and save the gallery to keep it.',
							'success'
						);
					} else {
						toast(
							(res.body && res.body.message) ||
								i18n.failed ||
								'Could not generate the description.',
							'error'
						);
					}
				})
				.catch(function () {
					btn.disabled = false;
					if (status) {
						status.textContent = '';
					}
					toast(i18n.failed || 'Could not generate the description.', 'error');
				});
		});
	}

	// Put text into the Gallery Description editor — the TinyMCE instance when
	// active (Visual mode) and always the underlying textarea (Text mode / save).
	function setGalleryDescription(text) {
		if (window.tinymce && window.tinymce.get('envira-gallery-description')) {
			window.tinymce.get('envira-gallery-description').setContent(text);
		}
		const ta = document.getElementById('envira-gallery-description');
		if (ta) {
			ta.value = text;
		}
	}

	/* ─── Boot ───────────────────────────────────────────────────────────── */

	function ready(fn) {
		if (document.readyState !== 'loading') {
			fn();
		} else {
			document.addEventListener('DOMContentLoaded', fn);
		}
	}

	ready(function () {
		bootSettings();
		// Without a usable license, hide the modal triggers entirely — the
		// click would 400 anyway, and we don't want to clutter the UI.
		if (cfg.defaults && cfg.defaults.licenseEligible) {
			bindGalleryEditor();
			bindBulkTrigger();
			bindMediaLibrary();
			bindGalleryDescriptionButton();

			// Live-patch the gallery editor when metadata is applied, so changes
			// appear without a reload and survive the next Save (todo-issue 04).
			document.addEventListener('envira-ia:image-generated', function (evt) {
				const detail = evt.detail || {};
				patchGalleryItem(detail.attachmentId, detail.applied);
			});
			document.addEventListener('envira-ia:bulk-complete', function (evt) {
				const map = evt.detail && evt.detail.applied;
				if (!map || typeof map !== 'object') {
					return;
				}
				Object.keys(map).forEach(function (id) {
					patchGalleryItem(id, map[id]);
				});
			});
		}
	});

	// Public hook so other plugins / addons can trigger flows programmatically.
	window.enviraImageAssistantApi = {
		openSingleImageModal: openSingleImageModal,
		openBulkModal: openBulkModal
	};
})();
