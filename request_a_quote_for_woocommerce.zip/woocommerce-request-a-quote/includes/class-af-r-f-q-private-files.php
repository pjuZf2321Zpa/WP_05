<?php
/** Authorized download routes for quote-form uploads. */
defined( 'ABSPATH' ) || exit;

function afrfq_quote_file_url( $quote_id, $field_id ) {
	$args = array(
		'action'   => 'afrfq_quote_file',
		'quote_id' => absint( $quote_id ),
		'field_id' => absint( $field_id ),
	);
	// Guest email recipients need a time-limited, file-specific bearer link.
	if ( ! (int) get_post_meta( $quote_id, '_customer_user', true ) ) {
		$args['expires'] = time() + 7 * DAY_IN_SECONDS;
		$args['signature'] = hash_hmac( 'sha256', $args['quote_id'] . '|' . $args['field_id'] . '|' . $args['expires'], wp_salt( 'auth' ) );
	}
	return add_query_arg( $args, admin_url( 'admin-ajax.php' ) );
}

function afrfq_download_quote_file() {
	$quote_id = isset( $_GET['quote_id'] ) ? absint( $_GET['quote_id'] ) : 0;
	$field_id = isset( $_GET['field_id'] ) ? absint( $_GET['field_id'] ) : 0;
	if ( 'addify_quote' !== get_post_type( $quote_id ) || 'addify_rfq_fields' !== get_post_type( $field_id ) || 'file' !== get_post_meta( $field_id, 'afrfq_field_type', true ) ) {
		wp_die( 'Invalid file', '', array( 'response' => 403 ) );
	}
	$allowed = current_user_can( 'manage_woocommerce' ) || afrfq_customer_owns_quote( $quote_id );
	if ( ! $allowed && ! (int) get_post_meta( $quote_id, '_customer_user', true ) ) {
		$expires = isset( $_GET['expires'] ) ? absint( $_GET['expires'] ) : 0;
		$signature = isset( $_GET['signature'] ) ? sanitize_text_field( wp_unslash( $_GET['signature'] ) ) : '';
		$expected = hash_hmac( 'sha256', $quote_id . '|' . $field_id . '|' . $expires, wp_salt( 'auth' ) );
		$allowed = $expires >= time() && $expires <= time() + 7 * DAY_IN_SECONDS && hash_equals( $expected, $signature );
	}
	if ( ! $allowed ) {
		wp_die( 'Forbidden', '', array( 'response' => 403 ) );
	}
	$key = get_post_meta( $field_id, 'afrfq_field_name', true );
	$file = AF_R_F_Q_File_Upload::safe_stored_name( get_post_meta( $quote_id, $key, true ) );
	afrfq_stream_quote_file( AFRFQ_UPLOAD_DIR, $file );
}

function afrfq_download_temp_quote_file() {
	$file = WC()->session ? AF_R_F_Q_File_Upload::safe_stored_name( WC()->session->get( 'quote_fields_file_name' ) ) : '';
	afrfq_stream_quote_file( AFRFQ_TEMP_UPLOAD_DIR, $file );
}

function afrfq_stream_quote_file( $directory, $file ) {
	$root = realpath( $directory );
	$path = $file ? realpath( $directory . $file ) : false;
	if ( ! $root || ! $path || 0 !== strpos( $path, $root . DIRECTORY_SEPARATOR ) || ! is_file( $path ) || ! is_readable( $path ) ) {
		wp_die( 'File not found', '', array( 'response' => 404 ) );
	}
	while ( ob_get_level() ) {
		ob_end_clean();
	}
	nocache_headers();
	header( 'Content-Type: application/octet-stream' );
	header( 'X-Content-Type-Options: nosniff' );
	header( 'Content-Disposition: attachment; filename="' . sanitize_file_name( $file ) . '"' );
	header( 'Content-Length: ' . filesize( $path ) );
	readfile( $path );
	exit;
}
add_action( 'wp_ajax_afrfq_quote_file', 'afrfq_download_quote_file' );
add_action( 'wp_ajax_nopriv_afrfq_quote_file', 'afrfq_download_quote_file' );
add_action( 'wp_ajax_afrfq_temp_quote_file', 'afrfq_download_temp_quote_file' );
add_action( 'wp_ajax_nopriv_afrfq_temp_quote_file', 'afrfq_download_temp_quote_file' );
