<?php
/**
 * Hardened handling of files uploaded through quote form "file" fields.
 *
 * Every code path that accepts an uploaded file (quote page, popup template
 * one, popup template two review step) must go through this class. It:
 *
 *  - only accepts $_FILES entries that belong to an enabled "file" quote field;
 *  - requires a real, error-free HTTP upload (is_uploaded_file());
 *  - enforces the field's size limit and the server upload limit;
 *  - only allows extensions that are BOTH on the field's allow-list AND in
 *    WordPress' allowed MIME list, and never any executable/script extension,
 *    including in "double extension" names such as shell.php.jpg;
 *  - verifies the real file content matches the extension
 *    (wp_check_filetype_and_ext());
 *  - never uses the client-supplied name on disk: files are stored under a
 *    random name with the validated extension;
 *  - drops .htaccess / web.config / index.php guards into the upload folders so
 *    that, even if something slipped through, scripts are not executed there.
 *
 * Fix for CVE-2026-18143.
 *
 * @package addify-request-a-quote
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'AF_R_F_Q_File_Upload' ) ) {

	/**
	 * AF_R_F_Q_File_Upload.
	 */
	class AF_R_F_Q_File_Upload {

		/**
		 * Extensions used when an admin left a file field's allowed types empty.
		 *
		 * @var string[]
		 */
		const DEFAULT_ALLOWED_EXTENSIONS = array( 'jpg', 'jpeg', 'png', 'gif', 'webp', 'pdf', 'doc', 'docx', 'xls', 'xlsx', 'csv', 'txt' );

		/**
		 * Extensions that are never accepted, whatever the field settings say.
		 * Checked against every dot-separated segment of the original filename.
		 *
		 * @var string[]
		 */
		const BLOCKED_EXTENSIONS = array(
			'php',
			'php2',
			'php3',
			'php4',
			'php5',
			'php6',
			'php7',
			'php8',
			'phps',
			'pht',
			'phtm',
			'phtml',
			'phar',
			'pgif',
			'inc',
			'hphp',
			'ctp',
			'module',
			'cgi',
			'pl',
			'pm',
			'py',
			'pyc',
			'rb',
			'sh',
			'bash',
			'ksh',
			'zsh',
			'csh',
			'bat',
			'cmd',
			'com',
			'exe',
			'dll',
			'msi',
			'vbs',
			'vbe',
			'ps1',
			'jar',
			'war',
			'asp',
			'aspx',
			'ascx',
			'ashx',
			'asmx',
			'asa',
			'cer',
			'cdx',
			'jsp',
			'jspx',
			'jsf',
			'cfm',
			'cfml',
			'shtml',
			'shtm',
			'stm',
			'ssi',
			'htaccess',
			'htpasswd',
			'ini',
			'user',
			'config',
			'conf',
			'html',
			'htm',
			'xhtml',
			'xht',
			'svg',
			'svgz',
			'xml',
			'xsl',
			'xslt',
			'js',
			'mjs',
			'swf',
		);

		/**
		 * Return the IDs of enabled quote fields of type "file", keyed by field name.
		 *
		 * @return array<string,int>
		 */
		public static function get_file_fields() {
			$fields = array();

			if ( ! class_exists( 'AF_R_F_Q_Quote_Fields' ) ) {
				return $fields;
			}

			$fields_obj = new AF_R_F_Q_Quote_Fields();
			$enabled    = $fields_obj->afrfq_get_fields_enabled();

			foreach ( (array) $enabled as $field ) {
				$field_id = is_object( $field ) ? (int) $field->ID : (int) $field;
				if ( 'file' !== get_post_meta( $field_id, 'afrfq_field_type', true ) ) {
					continue;
				}
				$name = (string) get_post_meta( $field_id, 'afrfq_field_name', true );
				if ( '' !== $name ) {
					$fields[ $name ] = $field_id;
				}
			}

			return $fields;
		}

		/**
		 * Whether an entry from $_FILES actually carries a file.
		 *
		 * @param mixed $file $_FILES entry.
		 * @return bool
		 */
		public static function has_file( $file ) {
			return is_array( $file )
				&& isset( $file['error'], $file['name'] )
				&& ! is_array( $file['name'] )
				&& UPLOAD_ERR_NO_FILE !== (int) $file['error']
				&& '' !== (string) $file['name'];
		}

		/**
		 * Extensions allowed for a given field (admin list ∩ WordPress MIME list − blocked list).
		 *
		 * @param int $field_id Quote field post ID.
		 * @return array<string,string> extension => mime.
		 */
		public static function get_allowed_types( $field_id ) {
			$configured = (string) get_post_meta( $field_id, 'afrfq_file_types', true );
			$configured = array_filter( array_map( 'trim', explode( ',', strtolower( $configured ) ) ) );
			$configured = array_map(
				static function ( $ext ) {
					return ltrim( $ext, '.' );
				},
				$configured
			);

			if ( empty( $configured ) ) {
				$configured = self::DEFAULT_ALLOWED_EXTENSIONS;
			}

			$wp_mimes = get_allowed_mime_types();
			$allowed  = array();

			foreach ( $configured as $ext ) {
				if ( ! preg_match( '/^[a-z0-9]{1,10}$/', $ext ) || in_array( $ext, self::BLOCKED_EXTENSIONS, true ) ) {
					continue;
				}
				foreach ( $wp_mimes as $exts => $mime ) {
					if ( in_array( $ext, explode( '|', $exts ), true ) ) {
						$allowed[ $ext ] = $mime;
						break;
					}
				}
			}

			/**
			 * Filter the final list of allowed extensions for a quote file field.
			 * Blocked (executable) extensions are removed again after this filter.
			 *
			 * @param array $allowed  extension => mime.
			 * @param int   $field_id Field ID.
			 */
			$allowed = (array) apply_filters( 'afrfq_allowed_upload_types', $allowed, $field_id );

			foreach ( array_keys( $allowed ) as $ext ) {
				if ( in_array( strtolower( $ext ), self::BLOCKED_EXTENSIONS, true ) ) {
					unset( $allowed[ $ext ] );
				}
			}

			return $allowed;
		}

		/**
		 * Validate one uploaded file for a field.
		 *
		 * @param array $file     $_FILES entry.
		 * @param int   $field_id Quote field post ID.
		 * @return array|WP_Error Array with 'ext' and 'type' on success.
		 */
		public static function validate( $file, $field_id ) {
			$label = (string) get_post_meta( $field_id, 'afrfq_field_label', true );

			if ( ! self::has_file( $file ) || ! isset( $file['tmp_name'] ) || is_array( $file['tmp_name'] ) ) {
				/* translators: %s: field label */
				return new WP_Error( 'afrfq_upload_invalid', sprintf( __( 'Invalid file upload for %s.', 'addify_rfq' ), $label ) );
			}

			if ( UPLOAD_ERR_OK !== (int) $file['error'] || ! is_uploaded_file( $file['tmp_name'] ) ) {
				/* translators: %s: field label */
				return new WP_Error( 'afrfq_upload_failed', sprintf( __( 'The file for %s could not be uploaded. Please try again.', 'addify_rfq' ), $label ) );
			}

			$allowed      = self::get_allowed_types( $field_id );
			$allowed_list = implode( ', ', array_keys( $allowed ) );

			// Reject if ANY segment of the name is an executable extension (shell.php.jpg, x.phtml.png ...).
			$name     = wp_basename( (string) $file['name'] );
			$segments = array_map( 'strtolower', array_map( 'trim', explode( '.', $name ) ) );
			array_shift( $segments ); // Drop the base name.
			foreach ( $segments as $segment ) {
				if ( in_array( rtrim( $segment, " \t\n\r\0\x0B:" ), self::BLOCKED_EXTENSIONS, true ) ) {
					/* translators: 1: field label, 2: allowed extensions */
					return new WP_Error( 'afrfq_upload_type', sprintf( __( 'Selected file type is not allowed for %1$s. Allowed extensions of file are %2$s', 'addify_rfq' ), $label, $allowed_list ) );
				}
			}

			// Final extension must be on the allow-list.
			$ext = strtolower( (string) pathinfo( $name, PATHINFO_EXTENSION ) );
			if ( '' === $ext || ! isset( $allowed[ $ext ] ) ) {
				/* translators: 1: field label, 2: allowed extensions */
				return new WP_Error( 'afrfq_upload_type', sprintf( __( 'Selected file type is not allowed for %1$s. Allowed extensions of file are %2$s', 'addify_rfq' ), $label, $allowed_list ) );
			}

			// Size limits: field setting (bytes) and server limit.
			$size       = (int) filesize( $file['tmp_name'] );
			$field_size = (int) get_post_meta( $field_id, 'afrfq_file_size', true );
			if ( $size <= 0 || ( $field_size > 0 && $size > $field_size ) || $size > wp_max_upload_size() ) {
				$limit = $field_size > 0 ? $field_size : wp_max_upload_size();
				/* translators: 1: field label, 2: max size in KB */
				return new WP_Error( 'afrfq_upload_size', sprintf( __( '%1$s size is too large. Max size for file is %2$s KB', 'addify_rfq' ), $label, round( $limit / 1000, 2 ) ) );
			}

			// Real content must match the extension.
			$check = wp_check_filetype_and_ext( $file['tmp_name'], $name, $allowed );
			if ( empty( $check['ext'] ) || empty( $check['type'] ) || ! isset( $allowed[ strtolower( $check['ext'] ) ] ) ) {
				/* translators: %s: field label */
				return new WP_Error( 'afrfq_upload_content', sprintf( __( 'The contents of the file for %s do not match its file type.', 'addify_rfq' ), $label ) );
			}

			// Belt and braces: refuse files that contain PHP open tags.
			$handle = fopen( $file['tmp_name'], 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen
			if ( $handle ) {
				$head = (string) fread( $handle, 1024 * 1024 ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fread
				fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
				if ( false !== stripos( $head, '<?php' ) ) {
					/* translators: %s: field label */
					return new WP_Error( 'afrfq_upload_content', sprintf( __( 'The contents of the file for %s do not match its file type.', 'addify_rfq' ), $label ) );
				}
			}

			return array(
				'ext'  => strtolower( $check['ext'] ),
				'type' => $check['type'],
			);
		}

		/**
		 * Validate and store a file under a random name.
		 *
		 * @param array  $file     $_FILES entry.
		 * @param int    $field_id Quote field post ID.
		 * @param string $dir      Destination directory (AFRFQ_UPLOAD_DIR or AFRFQ_TEMP_UPLOAD_DIR).
		 * @return string|WP_Error Stored file name (relative to $dir).
		 */
		public static function store( $file, $field_id, $dir ) {
			$result = self::validate( $file, $field_id );
			if ( is_wp_error( $result ) ) {
				return $result;
			}

			$dir = trailingslashit( $dir );
			self::protect_directory( $dir );

			$file_name = time() . '-' . wp_generate_password( 24, false, false ) . '.' . $result['ext'];
			$file_name = wp_unique_filename( $dir, $file_name );
			$target    = $dir . $file_name;

			if ( ! move_uploaded_file( $file['tmp_name'], $target ) ) { // phpcs:ignore Generic.PHP.ForbiddenFunctions.Found
				return new WP_Error( 'afrfq_upload_failed', __( 'The file could not be saved. Please try again.', 'addify_rfq' ) );
			}

			$stat  = stat( dirname( $target ) );
			$perms = $stat ? ( $stat['mode'] & 0000666 ) : 0644;
			chmod( $target, $perms ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_chmod

			return $file_name;
		}

		/**
		 * Return a safe stored file name (no path parts, allowed extension) or ''.
		 * Used before building paths/URLs from values kept in post meta or the session.
		 *
		 * @param string $file_name Stored name.
		 * @return string
		 */
		public static function safe_stored_name( $file_name ) {
			$file_name = wp_basename( (string) $file_name );
			if ( '' === $file_name || '.' === $file_name[0] ) {
				return '';
			}
			foreach ( array_slice( explode( '.', strtolower( $file_name ) ), 1 ) as $segment ) {
				if ( in_array( $segment, self::BLOCKED_EXTENSIONS, true ) ) {
					return '';
				}
			}
			return $file_name;
		}

		/**
		 * Write guard files that stop script execution and directory listing.
		 *
		 * @param string $dir Directory.
		 */
		public static function protect_directory( $dir ) {
			$dir = trailingslashit( $dir );

			if ( ! is_dir( $dir ) && ! wp_mkdir_p( $dir ) ) {
				return;
			}

			// Only directives covered by "AllowOverride Limit/AuthConfig" so the file never
			// causes a 500 on hosts with restricted overrides.
			$htaccess = "# Added by Request a Quote for WooCommerce - do not remove.\n"
				. "<FilesMatch \"\\.(?i:php[0-9]?|phtml|phar|pht|phps|inc|cgi|pl|py|rb|sh|asp|aspx|jsp|shtml|html?|svgz?|js|htaccess|user\\.ini)(\\.|$)\">\n"
				. "\t<IfModule mod_authz_core.c>\n\t\tRequire all denied\n\t</IfModule>\n"
				. "\t<IfModule !mod_authz_core.c>\n\t\tOrder allow,deny\n\t\tDeny from all\n\t</IfModule>\n"
				. "</FilesMatch>\n";

			$webconfig = '<?xml version="1.0" encoding="UTF-8"?>' . "\n"
				. "<configuration><system.webServer>\n"
				. "\t<handlers accessPolicy=\"Read\" />\n"
				. "\t<directoryBrowse enabled=\"false\" />\n"
				. "</system.webServer></configuration>\n";

			// Quote files contain customer data; serve them only through authorized PHP routes.
			$htaccess = "# Request a Quote for WooCommerce private files v2\n<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nOrder allow,deny\nDeny from all\n</IfModule>\n";
			$webconfig = '<?xml version="1.0" encoding="UTF-8"?><configuration><system.webServer><security><authorization><remove users="*" roles="" verbs=""/><add accessType="Deny" users="*"/></authorization></security></system.webServer></configuration>';

			$guards = array(
				'.htaccess'  => $htaccess,
				'web.config' => $webconfig,
				'index.php'  => "<?php\n// Silence is golden.\n",
			);

			foreach ( $guards as $name => $content ) {
				$path = $dir . $name;
				if ( ! file_exists( $path ) || ( in_array( $name, array( '.htaccess', 'web.config' ), true ) && (string) file_get_contents( $path ) !== $content ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
					file_put_contents( $path, $content ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
				}
			}
		}

		/**
		 * Extensions a web server may execute. Files with any of these segments
		 * found in the upload folders are moved to quarantine.
		 *
		 * @var string[]
		 */
		const SERVER_EXECUTABLE = array( 'php', 'php2', 'php3', 'php4', 'php5', 'php6', 'php7', 'php8', 'phps', 'pht', 'phtm', 'phtml', 'phar', 'pgif', 'inc', 'hphp', 'cgi', 'pl', 'py', 'rb', 'sh', 'asp', 'aspx', 'ascx', 'ashx', 'asmx', 'asa', 'cer', 'jsp', 'jspx', 'cfm', 'shtml', 'shtm', 'htaccess', 'ini' );

		/**
		 * Move server-executable files that may have been planted in the upload
		 * folders by the vulnerable versions (<= 2.9.2) into a locked quarantine
		 * folder (renamed so they can never run). Returns the moved paths.
		 *
		 * @param string[] $dirs           Directories to scan (top level only).
		 * @param string   $quarantine_dir Destination directory.
		 * @return string[]
		 */
		public static function quarantine_dangerous_files( $dirs, $quarantine_dir ) {
			$moved          = array();
			$keep           = array( 'index.php', '.htaccess', 'web.config' );
			$quarantine_dir = trailingslashit( $quarantine_dir );

			foreach ( (array) $dirs as $dir ) {
				$dir = trailingslashit( $dir );
				if ( ! is_dir( $dir ) ) {
					continue;
				}
				foreach ( (array) scandir( $dir ) as $entry ) {
					if ( '.' === $entry || '..' === $entry || in_array( $entry, $keep, true ) ) {
						continue;
					}
					$path = $dir . $entry;
					if ( ! is_file( $path ) ) {
						continue;
					}
					$segments = array_map( 'strtolower', explode( '.', $entry ) );
					array_shift( $segments );
					if ( ! array_intersect( $segments, self::SERVER_EXECUTABLE ) && '.' !== $entry[0] ) {
						continue;
					}
					if ( ! is_dir( $quarantine_dir ) ) {
						wp_mkdir_p( $quarantine_dir );
						file_put_contents( $quarantine_dir . '.htaccess', "Require all denied\nDeny from all\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
						file_put_contents( $quarantine_dir . 'index.php', "<?php\n// Silence is golden.\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
					}
					$new = $quarantine_dir . gmdate( 'YmdHis' ) . '-' . preg_replace( '/[^A-Za-z0-9_-]/', '_', $entry ) . '.quarantined';
					if ( @rename( $path, $new ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.rename_rename
						@chmod( $new, 0400 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.file_system_operations_chmod
						$moved[] = $path;
					}
				}
			}

			return $moved;
		}
	}
}
