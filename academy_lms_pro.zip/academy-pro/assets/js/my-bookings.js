/**
 * "My Tutor Bookings" frontend-dashboard page: row action menu (cancel /
 * reschedule). Loaded as a real enqueued script (see
 * addons/tutor-booking/functions.php) — NOT inlined into the PHP template,
 * because WordPress runs frontend-dashboard endpoint output through
 * wptexturize()/convert_chars() (same filters as post content), which
 * rewrites raw `&&` into `&#038;&#038;` etc. inside any inline <script> and
 * silently breaks it. A properly enqueued file is never touched by those
 * filters.
 */
( function () {
	var data = window.AcademyMyBookings || {};
	var ajaxUrl = data.ajaxurl;
	var nonce = data.nonce;
	var strings = data.strings || {};

	function t( key, fallback ) {
		return strings[ key ] || fallback;
	}

	// ---- Row action menu (three-dot dropdown) ----
	// Mirrors @Components/OptionMenu's own behavior (same
	// academy-dropdown-menu / academy-dropdown-menu__lists markup + styles,
	// already loaded on this page): the list portals to <body> with a
	// position computed from the trigger's rect, because the table's
	// scroll container clips anything absolutely positioned inside a row.
	var openMenu = null;

	function closeOpenMenu() {
		if ( ! openMenu ) {
			return;
		}
		openMenu.list.hidden = true;
		openMenu.homeParent.insertBefore( openMenu.list, openMenu.homeNextSibling );
		openMenu.toggle.setAttribute( 'aria-expanded', 'false' );
		openMenu = null;
	}

	document.querySelectorAll( '.academy-dropdown-menu--my-booking' ).forEach( function ( toggle ) {
		var anchor = toggle.parentElement;
		var list = anchor.querySelector( '.academy-dropdown-menu__lists' );

		toggle.addEventListener( 'click', function ( e ) {
			e.stopPropagation();

			var alreadyOpenForThisToggle = openMenu && openMenu.toggle === toggle;
			closeOpenMenu();
			if ( alreadyOpenForThisToggle ) {
				return;
			}

			var rect = toggle.getBoundingClientRect();
			var x = rect.left + window.pageXOffset;
			var y = rect.top + window.pageYOffset;

			list.style.position = 'absolute';
			list.style.left = ( x - 155 ) + 'px';
			list.style.top = ( y + rect.height + 10 ) + 'px';
			list.hidden = false;
			document.body.appendChild( list );

			toggle.setAttribute( 'aria-expanded', 'true' );
			openMenu = {
				toggle: toggle,
				list: list,
				homeParent: anchor,
				homeNextSibling: null,
			};
		} );
	} );

	document.addEventListener( 'mousedown', function ( e ) {
		if ( ! openMenu ) {
			return;
		}
		if ( openMenu.toggle.contains( e.target ) || openMenu.list.contains( e.target ) ) {
			return;
		}
		closeOpenMenu();
	} );

	// ---- Cancel ----
	document.querySelectorAll( '.academy-my-bookings__cancel-btn' ).forEach( function ( btn ) {
		btn.addEventListener( 'click', function () {
			// eslint-disable-next-line no-alert
			if ( ! window.confirm( t( 'confirmCancel', 'Are you sure you want to cancel this booking?' ) ) ) {
				return;
			}

			var bookedId = btn.getAttribute( 'data-booked-id' );
			btn.disabled = true;

			var formData = new FormData();
			formData.append( 'action', 'academy_pro/booking/frontend/cancel_booking' );
			formData.append( 'security', nonce );
			formData.append( 'booked_id', bookedId );

			fetch( ajaxUrl, {
				method: 'POST',
				credentials: 'same-origin',
				body: formData,
			} )
				.then( function ( response ) {
					return response.json();
				} )
				.then( function ( response ) {
					if ( response && response.success ) {
						window.location.reload();
					} else {
						btn.disabled = false;
						// eslint-disable-next-line no-alert
						window.alert(
							( response && response.data ) || t( 'genericError', 'Sorry, something went wrong.' )
						);
					}
				} )
				.catch( function () {
					btn.disabled = false;
					// eslint-disable-next-line no-alert
					window.alert( t( 'genericError', 'Sorry, something went wrong.' ) );
				} );
		} );
	} );

	// ---- Reschedule ----
	var modal = document.getElementById( 'academy-reschedule-modal' );
	if ( ! modal ) {
		return;
	}
	var dateInput = modal.querySelector( '.academy-reschedule-modal__date' );
	var slotsWrap = modal.querySelector( '.academy-reschedule-modal__slots' );
	var errorBox = modal.querySelector( '.academy-reschedule-modal__error' );
	var confirmBtn = modal.querySelector( '.academy-reschedule-modal__confirm' );
	var closeBtn = modal.querySelector( '.academy-reschedule-modal__cancel' );
	var overlay = modal.querySelector( '.academy-reschedule-modal__overlay' );
	var currentBookedId = null;
	var currentSettings = null;
	var selectedTimeSlot = null;

	function pad2( n ) {
		return String( n ).length < 2 ? '0' + n : String( n );
	}

	function toDateInputValue( d ) {
		return d.getFullYear() + '-' + pad2( d.getMonth() + 1 ) + '-' + pad2( d.getDate() );
	}

	function parseTime12h( str, baseDate ) {
		var m = /(\d+):(\d+)\s*(AM|PM)/i.exec( str || '' );
		if ( ! m ) {
			return null;
		}
		var h = parseInt( m[ 1 ], 10 );
		var min = parseInt( m[ 2 ], 10 );
		var ap = m[ 3 ].toUpperCase();
		if ( 'PM' === ap && 12 !== h ) {
			h += 12;
		}
		if ( 'AM' === ap && 12 === h ) {
			h = 0;
		}
		var d = new Date( baseDate.getTime() );
		d.setHours( h, min, 0, 0 );
		return d;
	}

	function formatTime12h( d ) {
		var h = d.getHours();
		var min = d.getMinutes();
		var ap = h >= 12 ? 'PM' : 'AM';
		var h12 = h % 12;
		if ( 0 === h12 ) {
			h12 = 12;
		}
		return h12 + ':' + pad2( min ) + ' ' + ap;
	}

	function buildSlots( startStr, endStr, durationMin, baseDate ) {
		var slots = [];
		var cursor = parseTime12h( startStr, baseDate );
		var end = parseTime12h( endStr, baseDate );
		if ( ! cursor || ! end || ! durationMin ) {
			return slots;
		}
		while ( true ) {
			var slotEnd = new Date( cursor.getTime() + durationMin * 60000 );
			if ( slotEnd > end ) {
				break;
			}
			slots.push( { start: formatTime12h( cursor ), end: formatTime12h( slotEnd ) } );
			cursor = slotEnd;
		}
		return slots;
	}

	function showError( message ) {
		errorBox.textContent = message;
		errorBox.hidden = ! message;
	}

	function renderSlotsForDate( dateStr ) {
		slotsWrap.innerHTML = '';
		selectedTimeSlot = null;
		confirmBtn.disabled = true;
		showError( '' );

		if ( ! currentSettings || ! dateStr ) {
			return;
		}

		var baseDate = new Date( dateStr + 'T00:00:00' );
		var duration = parseInt( currentSettings.duration, 10 ) || 0;
		var slots = [];

		if ( 'single' === currentSettings.schedule_type ) {
			var st = currentSettings.schedule_time || {};
			if ( st.date === dateStr ) {
				slots = buildSlots( st.start_time, st.end_time, duration, baseDate );
			}
		} else if ( 'repeated' === currentSettings.schedule_type ) {
			var weekday = baseDate
				.toLocaleDateString( 'en-US', { weekday: 'long' } )
				.toLowerCase();
			( currentSettings.schedule_repeated_times || [] ).forEach( function ( dayItem ) {
				if ( ( dayItem.day || '' ).toLowerCase() !== weekday ) {
					return;
				}
				( dayItem.scheduleTimes || [] ).forEach( function ( range ) {
					slots = slots.concat(
						buildSlots( range.start_time, range.end_time, duration, baseDate )
					);
				} );
			} );

			if ( ! slots.length ) {
				showError( t( 'noSlotsThisDay', 'This booking has no available slots on the selected day.' ) );
				return;
			}
		}

		if ( ! slots.length ) {
			var empty = document.createElement( 'span' );
			empty.className = 'academy-reschedule-modal__slots-empty';
			empty.textContent = t( 'noSlotsThisDate', 'No slots available for this date.' );
			slotsWrap.appendChild( empty );
			return;
		}

		slots.forEach( function ( slot ) {
			var btn = document.createElement( 'button' );
			btn.type = 'button';
			btn.className = 'academy-reschedule-modal__slot';
			btn.textContent = slot.start + ' - ' + slot.end;
			btn.addEventListener( 'click', function () {
				slotsWrap
					.querySelectorAll( '.academy-reschedule-modal__slot' )
					.forEach( function ( s ) {
						s.classList.remove( 'academy-reschedule-modal__slot--active' );
					} );
				btn.classList.add( 'academy-reschedule-modal__slot--active' );
				selectedTimeSlot = slot.start;
				confirmBtn.disabled = false;
			} );
			slotsWrap.appendChild( btn );
		} );
	}

	function openModal( bookedId, settings ) {
		currentBookedId = bookedId;
		currentSettings = settings;
		selectedTimeSlot = null;
		confirmBtn.disabled = true;
		showError( '' );

		var today = new Date();
		dateInput.min = toDateInputValue( today );

		if ( 'single' === settings.schedule_type && settings.schedule_time && settings.schedule_time.date ) {
			dateInput.value = settings.schedule_time.date;
			dateInput.disabled = true;
		} else {
			dateInput.disabled = false;
			dateInput.value = dateInput.min;
		}

		modal.hidden = false;
		renderSlotsForDate( dateInput.value );
	}

	function closeModal() {
		modal.hidden = true;
		currentBookedId = null;
		currentSettings = null;
	}

	document.querySelectorAll( '.academy-my-bookings__reschedule-btn' ).forEach( function ( btn ) {
		btn.addEventListener( 'click', function () {
			var settingsRaw = btn.getAttribute( 'data-settings' );
			var settings;
			try {
				settings = JSON.parse( settingsRaw );
			} catch ( err ) {
				settings = null;
			}
			if ( ! settings ) {
				// eslint-disable-next-line no-alert
				window.alert( t( 'genericError', 'Sorry, something went wrong.' ) );
				return;
			}
			openModal( btn.getAttribute( 'data-booked-id' ), settings );
		} );
	} );

	dateInput.addEventListener( 'change', function () {
		renderSlotsForDate( dateInput.value );
	} );

	closeBtn.addEventListener( 'click', closeModal );
	overlay.addEventListener( 'click', closeModal );

	confirmBtn.addEventListener( 'click', function () {
		if ( ! currentBookedId || ! selectedTimeSlot ) {
			return;
		}
		confirmBtn.disabled = true;

		var formData = new FormData();
		formData.append( 'action', 'academy_pro/booking/frontend/reschedule_booking' );
		formData.append( 'security', nonce );
		formData.append( 'booked_id', currentBookedId );
		formData.append( 'selectedDate', dateInput.value );
		formData.append( 'selectedTimeSlot', selectedTimeSlot );

		fetch( ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			body: formData,
		} )
			.then( function ( response ) {
				return response.json();
			} )
			.then( function ( response ) {
				if ( response && response.success ) {
					window.location.reload();
				} else {
					confirmBtn.disabled = false;
					showError( ( response && response.data ) || t( 'genericError', 'Sorry, something went wrong.' ) );
				}
			} )
			.catch( function () {
				confirmBtn.disabled = false;
				showError( t( 'genericError', 'Sorry, something went wrong.' ) );
			} );
	} );
} )();
