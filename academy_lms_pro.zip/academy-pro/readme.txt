=== Academy LMS Pro ===
Contributors: academylms, tusharimran
Tags: lms, course, elearning, online courses, learning management system
Requires at least: 6.8
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 4.1.0
License: GPLv3
License URI: https://opensource.org/licenses/GPL-3.0

Academy LMS Pro extends Academy LMS with live classes, content drip, SCORM, gradebook, assignments, and CRM integrations for your online academy.

== Description ==

Academy LMS is a robust and feature-packed eLearning and online course solution for WordPress. This LMS plugin seamlessly connects with any WordPress site and makes it easy to create courses & lessons and sell online. With this user-friendly and superfast plugin, you can transform your website into a professional and intriguing e-learning platform.

Academy LMS is unique since it comes with a Frontend SPA (Single Page Application) interface. It is one of the finest free WordPress LMS plugins for building courses, modifying courses, producing quizzes, and receiving a thorough course overview.

== Changelog ==

= 4.1.0 - 28/10/2026 =
* New - Submitted Assignments: administrators now see submissions on every assignment, not just assignments they authored.
* Fixed - Editing an assignment or booking from the course builder could revert the saved changes right after the update; the course author is also notified when the item is updated.
* Fixed - Admin "cancel enrollment" now honours the reset-progress setting instead of always wiping progress.
* Fixed - Manage Roles toggles no longer dim or lag while a permission is saving; the switch is replaced with a small round loader during save, and the native checkbox stays hidden while the switch is disabled.
* Fixed - Role permissions: staff users can now load quizzes on the Learn page.
* Fixed - Manage Device dashboard template: the table body wrapper was not being closed, breaking the layout on some themes.
* Improved - GamiPress settings: added spacing between the placement fields for better readability.

= 4.0.5 - 13/10/2026 =
* New - Assignments can now have multiple questions
* Fixed - Security issues in SCORM uploads, assignment submissions, WooCommerce course products, course bundles, grade book, social login, email verification, push notifications and email template preview
* Fixed - SCORM package upload showing no message for an invalid package; packages without imsmanifest.xml are now rejected with a clear message
* Fixed - SCORM package name showing a long hash in the course builder
* Improved - SCORM packages are extracted by the SCORM addon and the file path follows the site uploads location
* Improved - Test email now shows the reason when it fails to send
* Improved - Grade scale can only be changed by administrators; instructors see it read-only

= 4.0.4 - 06/10/2026 =
* Fixed - Meeting editor issue fix

= 4.0.3 - 06/10/2026 =
* Fixed - Cyclic characters being embedded into JSON in the Zoom Meeting integration
* Added - A heavy guard to the meeting POST JSON response data
* Fixed - Course bundle filter fixed in the course archive page
* Fixed - Duplicate course bundle data caused by incorrect StoreEngine initialization

= 4.0.2 - 01/10/2026 =
* Improved - White Label: logo fields preview the default image they fall back to, and the Social Login notice uses your brand name.
* Fixed - Content Drip dates ("This content will be accessible on …" and module release dates) now show month and day names in the site's language.
* Fixed - WooCommerce and Easy Digital Downloads: saving a course price when its linked product had been deleted caused an error; a new product is now created and linked.
* Fixed - WooCommerce and Easy Digital Downloads: a product created from a price alone is named after the course instead of being left untitled.

= 4.0-beta2 - 20/08/2026 =
* Added - GameEngine Unlock course access type: require a minimum GameEngine points balance, a specific achievement, or a minimum level to enroll in a course (requires the free GameEngine plugin's Restrict Content addon). Configure per-course or per-category rules, with an optional "require all rules" (AND) toggle, from the Course Type panel in the course editor.
* Added - A read-only "points available toward this purchase" hint on paid courses' pricing block when GameEngine-Pro's points-spending checkout is enabled — the actual payment still runs entirely through GameEngine-Pro's existing WooCommerce/StoreEngine points-payment addons.
* Added - Campus fees run on StoreEngine: a fee plan becomes a product with a price, monthly plans become subscriptions, and the checkout follows whichever e-commerce engine Academy is set to. The Campus invoice ledger is retired.
* Added - Cash taken at the office records a paid order; one-off charges can be collected without a plan; a transport route or hostel room bills its own riders.
* Added - Leave applications: a family applies from their dashboard, the class teacher or the office answers, and approving writes those days into the register as leave rather than absence.
* Added - Teacher tools on the frontend dashboard — my routine, take attendance, enter marks, the class roster with each student's guardians and monthly attendance, behaviour notes, and section notices.
* Added - A student's own view of the campus: attendance, routine, exams, fees and the facilities they use.
* Added - Guardian owns parent–teacher messaging. Conversations are threads per student and teacher with unread counts and a teacher inbox, and the teacher being written to finally has somewhere to read and reply. Campus contributes the section teachers a school's families should be able to reach.
* Added - Settings → Advanced → Guardian, with an on/off switch for Family Messages.
* Added - Hostel blocks with occupancy guards, exam invigilators, and a per-exam schedule summary.
* Added - Semester dimension, with per-class and department/year analytics.
* Improved - Facilities: paging, search, per-campus scoping, and guards that refuse a delete something still references. Library gains its own category register.
* Improved - Class-level daily attendance, so a school that doesn't split classes into sections can still take a register.
* Improved - Exam total and pass marks accept decimals.
* Improved - Pro addon menu items declare which dashboard area they belong to.
* Fixed - Guardian's route flush now only runs from wp-admin. Academy builds its dashboard rewrite rules from the menu, and the menu is capability-dependent — a flush landing on an anonymous front-end request wrote rules with every instructor-only endpoint missing, and those pages 404'd until something flushed again from a privileged context.
* Fixed - Dropped the inventory facility, which duplicated what a school already tracks elsewhere.
* Fixed - Dark mode and colour issues; Digital Campus failing to load.

= 4.0-beta1 - 13/08/2026 =
* Added - Tailwind CSS admin migration (wave 3) with Light / Dark mode and route-based pro editors (assignment, meeting, booking).
* Added - Tutor Booking auto-creates Zoom / Google Meet meetings on a confirmed booking, with inline paid pricing.
* Added - Google Meet Setup modal with instructions and JSON credential upload.
* Added - Guardian Pro: parent dashboard, messaging, and approvals.
* Added - Course Active Timer with server-authoritative, heartbeat-based billing and course locking.
* Added - Incoming Webhooks with HMAC authentication and CPT-based storage.
* Added - Campus SIS (Pro): multi-head fee plans, exams/attendance/fees/notices/behaviour/facilities, multi-campus, and online fee payment via WooCommerce / StoreEngine.
* Added - Cross-platform release build kit (npm run dist).
* Improved - Tutor booking editor two-column layout, restored archive filters, full-width email mail builder, compact tokenized admin UI.
* Fixed - SCORM LMSInitialize / LMSFinish / LMSCommit now return the required sync string.
* Fixed - Instructor could not see their own course events; product duplication on course duplicate; booking settings migration.
* Fixed - Security: hardened the public apply endpoint and Guardian messaging recipient handling.

= 3.8.5 - 14/07/2026 =
* Fixed - Device login Restriction addon user roles undefine issue
* Fixed - Certificate verification id query issue

= 3.8.4 - 09/07/2026 =
* Fixed - Security: access-control (IDOR) hardening across enrollment duration, assignment grading, content duplication, notifications, meetings, group teams, grade book, tutor booking, device login sessions, and Google Classroom so data is only accessible or editable by authorized users.
* Improved - Site-wide meeting API credentials are now restricted to administrators.
* Improved - Hardened direct file access protection and WordPress coding standards compliance (input sanitization, output escaping, and database query safety) across addons and templates.
* Fixed - Production build now ships properly minified assets.
* Fixed - Undefined index notices in notifications and frontend script enqueue.

= 3.8.2 - 01/07/2026 =
* Fixed - Error after triggering course enrollment cancellation.
* Fixed - 'Social Login' addon Google login error.
* Fixed - Translation issues.
* Fixed - Fatal error with the latest SureMembers version and Academy integration.
* Fixed - FluentCRM integration trigger with Academy not working.

= 3.8.1 - 15/06/2026 =
* Improved - Quiz export functionality. Previously, quizzes of all statuses could be exported; now, only published quizzes can be exported.
* Fixed - Store License integration functionality issue.
* Fixed - SureCart integration pricing data array_merge() issue.
* Fixed - Public course topics could not be accessed without enrollment.
* Fixed - Assignment AJAX capability issue.

= 3.8.0 - 25/05/2026 =
* Added: Private REST API endpoints for student assignment data.
* Added: Power-ups section improvements with updated display conditions and icons.
* Fixed: WooCommerce order data retrieval issue.
* Fixed: Plugin compatibility issue when Academy free plugin is deactivated.
* Removed: Freemius licensing dependency.

= 3.7.4 - 13/05/2026 =
* Added: Option to extend course enrollment expiration for individual students.
* Added: Email addon triggers for lesson comment submissions and replies.
* Fixed: Translation and localization issues.

= 3.7.3 - 22/04/2026 =
* Added - StoreEngine SDK integration(License Management) added

= 3.7.1 - 03/04/2026 =
* Fixed: Two-step verification message not displaying after registration completion.
* Fixed: Google reCAPTCHA API response issue.
* Fixed: Incorrect hook name in Email Addon before registration.

= 3.7.0 - 20/03/2026 =
* Added: New addon “Multi-media Attachment” to allow multiple sources in a course.
* Fixed: Quiz results were not updating in the grade results table after manually reviewing an attempt.
* Fixed: Lesson duplication issue.
* Fixed: Push notification course completion trigger function argument type error.

= 3.6.0 - 05/03/2026 =
* Fixed: Course enrollment button loading issue after enrollment.
* Fixed: Bundle enrollment count issue.
* Fixed: Course Bundle Enrolled info show before Enrolled issue.

= 3.5.5 - 19/02/2026 =
* Fixed: Type declaration error in parameters of Academy SureMembers Addon integration function.

= 3.5.4 - 10/02/2026 =
* Fixed: Academy login not working when Google reCAPTCHA is enabled.
* Fixed: Group Plus member and leader search issues.
* Fixed: Academy login not working when Google reCAPTCHA is enabled.
* Fixed: Course bundle total duration displaying incorrectly.
* Fixed: Tutor booking review button not working in FSE themes.
* Fixed: PHPCS compliance issues.Fixed: Group Plus member and leader search issues.
* Fixed: Course Bundle wishlist not working issue.

= 3.5.3 - 02/02/2026 =
* Added: Free course bundle creation feature.
* Added: Certificate duplication feature.
* Fixed: Typo in notification trigger name.
* Fixed: PHPCS compliance issues.
* Fixed: Fatal error in SureMembers addon.
* Fixed: Course Bundle addon documentation link not working.

= 3.5.2 - 20/01/2026 =
* Fixed: SCORM addon security issues

= 3.5.1 - 15/01/2026 =
* Fixed: Duplicate booking records created when paid tutor booking order status changes.

= 3.5.0 - 12/01/2026 =
* Fixed: Group Plus purchase issue with StoreEngine.

= 3.4.0 - 11/12/2025 =
* Added - "Attendance" addon.
* Added - MemberPress integration.
* Added - Color customization support for Tutor Booking single and archive pages.
* Fixed - When marked a course as a favorite and a new student registration complete then existing users received an email.

= 3.3.10 - 24/11/2025 =
* Added: Setting to show the course review form only after a minimum completion percentage.
* Added: Booking table now hides private booking information. 
* Fixed: Google reCAPTCHA not working in the Reset Password form.
* Fixed: Certificate signature and date image replaced with block-based code.
* Fixed: Course bundle description was not being serialized.

= 3.3.9 - 06/10/2025 =
* Added - Option to reset course progress data on expire course when it's re-enrollement.
* Added - Global and individual meeting credentials setup for better flexibility.
* Fixed - Issue preventing re-enrollment after course expiration.
* Fixed - Social login vulnerability.
* Fixed - Critical error during quiz attempt export.
* Fixed - Certificate verification not working for non-logged-in users.

= 3.3.7 - 06/10/2025 =
* Added - Tutor Booking – Seat limitation feature.
* Fixed - Group Plus integration with WooCommerce causing fatal errors and UI breakage.
* Fixed - Student and Instructor data export – CSV file header alignment issue.
* Fixed - Social login security vulnerability.

= 3.3.7 - 24/09/2025 =
* Added - Assignment creation with AI.
* Improved - Course Bundle enrollment widget UI.
* Fixed - WPML addon conflict with StoreEngine webhooks addon.
* Fixed - Zoom meeting description not displaying on LearnPage (both JS and PHP rendering).

= 3.3.6 - 15/09/2025 =
* Fixed - Course Bundle sale price creating a new product on update, and sale price not displaying when editing the bundle.

= 3.3.5 - 02/08/2025 =
* Added - Academy 3.3.5 compatibility

= 3.3.4 - 28/08/2025 =
* Fixed - Enrollment delete icon missing in the enrolled courses list within the student table.  
* Fixed - Team members and leaders unable to see the "Start Course" button on the single course page after purchase.  
* Fixed - Group purchase history not appearing in the frontend dashboard.  
* Fixed - Team member insertion issue where existing user info added empty data in the member list.  
* Fixed - Course team purchase "Add to Cart" button issue.  

= 3.3.3 - 14/08/2025 =
* Fixed - Google Meet and Zoom meeting countdown not showing.
* Fixed - Content Drip not working during PHP rendering.
* Fixed - Tutor Booking calendar schedule date undefined issue in booking page.
* Fixed - Email some trigger can't disable in Email settings page.

= 3.3.2 - 07/08/2025 =
* Fixed - Issue with newly registered student data not appearing in advanced analytics.

= 3.3.1 - 31/07/2025 =
* Improvements - SCORM support in lessons.
* Fixed - PHPCS (PHP CodeSniffer) compliance issues.

= 3.3.0 - 24/07/2025 =
* Added - SendFox integration.
* Added - Display of available seat numbers for Group Plus assigned courses.
* Fixed - No message was shown when a Group Leader was assigned to a Group Plus group and others issue. And more minor issues.

= 3.2.3 - 14/07/2025 =
* Fixed - Fatal error when visiting the site from an incognito browser after activating the Device Login Restrictions addon.
* Fixed - Fatal error when editing the student registration page after activating the Social Login addon.
* Fixed - Spelling error in Email Addon Trigger names.

= 3.2.2 - 01/07/2025 =
* Fixed - Google login was not functioning in the social login feature.
* Fixed - Spelling error in course prerequisite text.
* Fixed - Pagination selection not working in the course details section of the advanced analytics dashboard.
* Fixed - Google login was not functioning in the social login feature.

= 3.2.1 - 24/06/2025 =
* Fixed - Blank page issue when opening a Course Bundle.

= 3.2.0 - 19/06/2025 =
* Fixed -  Manual Enrollment course search issue solved

= 3.1.2 - 16/06/2025 =
* Fixed -  Learn page assignment UI issue when PHP rendering is enabled.
* Fixed -  Wrong message shown when Google Classroom table has no data.
* Fixed -  Course search issue in student table for Manual Enrollment.

= 3.1.1 - 05/06/2025 =
* Fixed - StoreEngine 'Add to Cart' issue for Group purchase.
* Fixed - Group Plus addon bugs.

= 3.1.0 - 04/06/2025 =
* Added - Group Plus integration with StoreEngine.
* Improvements - SCORM course progress now included in Advanced Analytics.
* Fixed - Draft course preview not displaying correctly.
* Fixed - Multiple bugs and UI issues in the Group Plus addon.
* Fixed - Booking conflicts between Tutor Booking and StoreEngine.

= 3.0.2 - 01/06/2025 =
* Fixed - Group Plus addon ui and functionality issue.

= 3.0.1 - 28/05/2025 =
* Fixed - Group Team purchase process not functioning correctly.
* Fixed - WPML lesson settings save issue.
* Fixed - Group Plus UI and search functionality issues.

= 3.0.0 - 26/05/2025 =
* Added - Group Plus addon for enhanced group functionality.
* Added - WPML integration for multilingual course management.
* Added - New "Tutor Booking Booked" email trigger in the Email addon.
* Improvements - SCORM course progress tracking not working perfectly.

= 2.9.0 - 05/05/2024 =
* Updated - Manual Enrollment Multiple course and student support
* Improvements - Rebuilt the SCORM addon for better performance.
* Improvements - Implemented "No time limit" option for assignments.
* Fixed - Error message not showing when trying to create with duplicate booking time.
* Fixed - Google Meet events not appearing in the Event Calendar.
* Fixed - Booking status not updating correctly for Booked bookings table.
* Fixed - UI issue with the "Add to Cart" button on single course bundles.
* Fixed - Instructor review option not disabling on Single tutor bookings.


= 2.8.3 - 05/05/2024 =
* Fixed - Booked Booking not showing in the booking purchase history.
* Fixed - Tutor Booking update notification message not displaying correctly.
* Fixed - "Course content available sequentially" (Content Drip) not working correctly when PHP rendering is enabled.


= 2.8.2 - 22/04/2024 =
* Improvements - Pagination added to the Google Classroom table.
* Fixed - Issue where enabling the Fluent Community addon caused course saving to fail.
* Fixed - Google Classroom table data was not displaying correctly.

= 2.8.1 - 17/04/2024 =
* Added - Support for Course Bundles and paid Tutor Booking integrations with StoreEngine.
* Improvements - Enhanced the Assignment Resubmission Limit feature for better control.
* Fixed - Resolved an error occurring after assignment evaluations.
* Fixed - Issue with displaying course details information in Advanced Analytics.

= 2.8.0 - 07/04/2024 =
* Added - Redux Toolkit
* Removed - Old legacy redux 
* Added - Email addon triggers for instructor withdrawal request accept and denied.
* Added - Push notification triggers for instructor withdrawal request accept and denied.

= 2.7.0 - 20/03/2024 =
* Added - Introduced the FluentCommunity Integration Add-on.
* Added - Content Drip New Feature—Course content automatically locks after a set period (X days) after access.
* Fixed - Addressed the issue where assignments could be resubmitted when the evaluation score was set to 0.
* Fixed - Instructor feedback on submitted assignments now displays correctly when PHP rendering is enabled.

= 2.6.0 - 09/03/2024 =
* Added - The Calendar Addon for enhanced Event Management

= 2.5.2 - 20/02/2024 =
* Fixed - Database prefix issue in the Gradebook Addon.
* Fixed - Search functionality issue with BuddyBoss & BuddyPress in the Academy course builder.
* Fixed - UI issues, including the "Add to Cart" button on the single course page and other minor UI improvements.

= 2.5.1 - 13/02/2024 =
* Added - Push notifications for Question & Answer submissions and replies.
* Added - Email triggers for Question & Answer submissions and replies.
* Fixed - Device counting issue in Device Login Restrictions, ensuring table data is removed after logout.
* Fixed - Duplicate push notification trigger issue after completing a WooCommerce-paid course purchase.
* Fixed - Group search issue in BuddyPress and BuddyBoss.
* Fixed - SureCart "Add to Cart" Button Issue on Course Archive Pages.

= 2.5.0 - 06/02/2024 =
* Added - New Device Login Restriction addon

= 2.4.2 - 04/02/2024 =
* Fixed - Student ZIP file was not submitted in assignments when PHP rendering was enabled.
* Fixed - View link issue in announcement push notifications.

= 2.4.1 - 26/01/2024 =
* Fixed - Issues with Restrict Content Pro level types and course archive filters.
* Fixed - The Academy LMS trigger menu was not appearing in BuddyBoss settings.
* Fixed - Assignment not submitted after Course export with Assignment.

= 2.4.0 - 14/01/2024 =
* Added - BuddyBoss Integration Addon.
* Added - BuddyPress Integration Addon.
* Added - Course View Analytics feature in Advanced Analytics.
* Added - A new type of Content Drip named "Schedule After Topics Complete."
* Fixed - Restrict Content Pro fatal error in the Frontend Dashboard.
* Fixed - Easy Digital Downloads Pricing widget button issue.
* Fixed - Multiple issues with the certificate Addon.
* Fixed - If the Sequential Content Drip type is enabled, topics are marked as complete without finishing previous topics.

= 2.3.0 - 24/12/2024 =
* Added - Restrict Content Pro Addon.
* Added - Frontend Dashboard Assignment analytics card added.
* Fixed - Notification message Evaluate Assignment & Quiz redirect url issue.
* Fixed - Frontend Dashboard Tutor booking Booked menu not showing issue.

= 2.2.4 - 05/12/2024 =
* Fixed - Email Notification Trigger without button enable.
* Fixed - Course Prerequisite not working in new Course layout.
* Fixed - Email Template Button Enable issue.
* Fixed - Tutor Booking price duplicate issue.

= 2.2.2 - 17/11/2024 =
* Fixed - Submit Quiz Notification issue on Push site.
* Fixed - Tutor Booking table category not showing.

= 2.2.1 - 03/11/2024 =
* Added - Quiz Attempts result Export Functionality.

= 2.2.0 - 23/10/2024 =
* Added - Assignment Duplicate feature.
* Added - Multiple courses Enrolled with Bulk Student Enrolment CSV file.
* Added - .zip File upload option in Assignments.
* Fixed - Submitted Assignment not showing when click from Dashboard Notification section.
* Fixed - Namespace change for Vendor directory and packages.
* Fixed - Scorm file upload issue in Instructor Dashboard.
* Fixed - After Registration with Social Login, Email notification trigger issue.

= 2.1.1 - 08/10/2024 =
* Added - New Ui implement in Email Addon.
* Fixed - Assignment after fail download Certificate issue.
* Fixed - Certificate Image Size Optimize.

= 2.1.0 - 06/10/2024 =
* Added - New Certificate Addon
* Added - Push Notification new trigger.
* Added - Email addon new trigger.

= 2.0.13 - 24/09/2024 =
* Fixed - Email settings text mistake
* Fixed - Assignment edit description not available.
* Fixed - Gamipress achivements, rank type not working in frontend dashboard.
* Fixed - Wishlist-Member Addon activation issue.

= 2.0.12 - 15/09/2024 =
* Fixed - Tutor Booking WooCommerce auto product creation issue

= 2.0.11 - 11/09/2024 =
* Fixed - Course Bundle product creation issue
* Fixed - Tutor Booking purchase issue

= 2.0.10 - 09/09/2024 =
* Added - Some Filter hook
* Fixed - Quiz fill in the blank issue
* Fixed - Assignment submit validation issue
* Fixed - Social Login user role issue

= 2.0.9 - 02/09/2024 =
* Fixed - Tutor Booing booked date/time duplicate issue
* Fixed - Edd Auto Product Create issue
* Fixed - Assignment Modal Editor UI issue
* Fixed - Booking Image Issue
* Fixed - Submitted Assignment Section in Instructor Dashboard Issue

= 2.0.8 - 22/08/2024 =
* Fixed - Booking List Table UI break issue.
* Fixed - Assignment Text area Small issue.
* Fixed - Course Curriculum issue with Drip-Content.
* Fixed - Social Login issue in Facebook.

= 2.0.7 - 18/08/2024 =
* Fixed - Meeting redirect issue
* Fixed - Quiz Export issue
* Fixed - Frontend Dashboard permalink issue

= 2.0.6 - 06/08/2024 =
* Added - New 6 trigger for Notification
* Fixed - Google Login button not showing inside popup modal
* Fixed - Content Drip not worked for mark as complete button
* Fixed - Google Meet timezone issue
* Fixed - GradeBook not worked properly
* Fixed - Meeting & Booking pagination issue
* Fixed - Time Countdown issue 

= 2.0.5 - 18/07/2024 =
* Fixed - Course Bundle WooCommerce integration issue
* Fixed - Tutor Booking UI issues
* Fixed - Google class room search

= 2.0.4 - 15/07/2024 =
* Added - Easily Digital Download Automatic Download creation
* Fixed - Assignment Grade Point not worked issue
* Fixed - Social Divider showing in wrong way

= 2.0.3 - 10/07/2024 =
* Fixed - Vulnerability issue fixed

= 2.0.2 - 04/07/2024 =
* Added - Tutor Booking SureCart integration
* Fixed - Paid Membership enroll issues
* Fixed - Quiz Content Drip Not worked issues
* Fixed - GradeBook sorting issues
* Fixed - Quiz Duplicate issues

= 2.0.1 - 27/06/2024 =
* Fixed - Tutor Booking pagination issues
* Fixed - Paid Membership Pro conflict with existing Enrollment
* Fixed - Public Course login issues
* Fixed - Meeting Form UI issues
* Fixed - Email Settings functionality issues

= 2.0 - 11/06/2024 =
* Added - New Addon FluentCRM
* Added - New Addon Gamipress
* Added - New Addon Google Classroom
* Added - New Addon Gradebook
* Added - New Addon Mailchimp
* Added - New Addon Meeting Addon (Google Meet
* Added - New Addon Notification Addon
* Added - New Addon SureCart Integration
* Added - New Addon SureMembers Integration
* Added - New Addon Social Login/Register
* Added - New Addon Wishlist Member Integration
* Fixed - A lot of UI Glitches has been fixed
* Fixed - Improved code structure and removed bloated codes
* Fixed - Paid membership pro Membership pricing, Checkbox UI glitch has been fixed
* Removed - Old Zoom Addon
* Revamped - Tutor Booking Modal
* Revamped - Assignment Modal

= 1.8.12 - 03/04/2024 =
* Fixed - Page loading issue has fixed on Student Dashboard while access Tutor Booking
* Fixed - Amount of Enroll Students has updated on Course Bundle
* Fixed - Tutor Booking Meeting Details Instructor Email Issue
* Added - Tutor Booking Custom Time Schedule 

= 1.8.11 - 19/03/2024 =
* Fixed - File name CSV missing
* Fixed - Student Email verification issue fixed
* Fixed - Tutor booking multiple booking glitch fixed

= 1.8.10 - 07/03/2024 =
* Fixed - Assignment render issue after started

= 1.8.9 - 15/02/2024 =
* Fixed - Special character issue

= 1.8.8 - 13/02/2024 =
* Fixed - Zoom, Tutor Booking, Assignment special character issue

= 1.8.7 - 07/02/2024 =
* Fixed - Student Search not worked properly

= 1.8.6 - 01/02/2024 =
* Fixed - Tutor booking repeated booking date issue (For non-english users)

= 1.8.5 - 30/01/2024 =
* Fixed - Tutor booking minor AM/PM Issue
* Fixed - Tutor booking order processing issue. It was possible to book on same time frame.
* Fixed - Tutor booking details individual details issue
* Fixed - While booking added to cart, it was automatically complete order without payment if back to previous page

= 1.8.4 - 04/01/2024 =
* Added - New 11 Webhook Events for Pro Features
* Fixed - Tutor Booking Content Issues

= 1.8.3 - 21/12/2023 =
* Added - Student and Course data export option
* Fixed - Course Bundle filter issues from course archive
* Fixed - Advance analytics purchase details issue
* Fixed - white label addon minor issue


= 1.8.2 - 14/12/2023 =
* Fixed - Course all instructor not able to see Submitted Assignment
* Fixed - Auto Woo Product Creation Logic not worked properly
* Fixed - Student Bulk Enroll issues

= 1.8.1 - 11/12/2023 =
* Added - Course Bundle Revenue sharing options
* Fixed - Booking calendar booked time issues
* Fixed - Tutor Booking repeated time remove issues
* Fixed - Course Prerequisite restricted current product select option

= 1.8.0 - 06/12/2023 =
* Added - New Course Bundle Addon
* Fixed - Tutor Booking Time zone issue
* Fixed - Tutor Booking Category issue
* Fixed - Bulk Enroll search input wrong message
* Fixed - Email Addon Editor Content empty issues

= 1.7.9 - 23/11/2023 =
* Added - Course Curriculum duplicator
* Fixed - Email Template Editor live update issues

= 1.7.8 - 21/11/2023 =
* Fixed - Email Addon Instructor Settings default data issues

= 1.7.7 - 16/11/2023 =
* Fixed - Email Addon Settings default data issues

= 1.7.6 - 16/11/2023 =
* Added - New Email Notify trigger for Student and Instructor 
* Added - 2 Step Email Verify Template Editor Settings

= 1.7.5 - 11/11/2023 =
* Fixed - Advanced analytics enroll date issue
* Fixed - PMPRO addon view template loading issues

= 1.7.4 - 17/10/2023 =
* Fixed - Email Addon template editor break issues

= 1.7.3 - 12/10/2023 =
* Updated - Addons auto loading

= 1.7.2 - 21/09/2023 =
* Added - New SCORM addon
* Fixed - Tutor Booking content drip not worked

= 1.7.1 - 12/09/2023 =
* Added - New White Label addon

= 1.7.0 - 28/08/2023 =
* Fixed - if lesson has enable preview able then drip content will be not apply.
* Fixed - Booking Archive Permalink & Query issues
* Fixed - Manual Enrollment not worked if enrollment is pending.
* Added - Booking permalink change option
* Added - Quiz Duplicate functionality
* Added - Quiz Export/Import functionality

= 1.6.8 - 10/08/2023 =
* Fixed - Tutor Booking UI issues

= 1.6.7 - 09/08/2023 =
* Fixed - Tutor Booking Responsive Issue
* Updated - Ajax Nonce Checking function

= 1.6.6 - 07/08/2023 =
* Fixed - Tutor Booking addon assets build issue

= 1.6.5 - 02/08/2023 =
* Fixed - Booking and Zoom Meeting title not update inside course builder
* Fixed - Booking modal time update not worked
* Fixed - Zoom Previous data selecting issue
* Fixed - Public Course tab not showing frontend
* Added - Content Drip Support for tutor booking

= 1.6.4 - 13/07/2023 =
* Fixed - reCAPTCHA Settings UI
* Fixed - Zoom Meeting Delete Confirm Issue
* Fixed - Assignment attachment not keep saved issue
* Fixed - Zoom Form Required Notification issue
* Fixed - 2 Step email verification not working issue
* Fixed - Instructor Not able to submit their own assignment issue
* Added - Course Prerequisite Category Support
* Added - Student & Instructor Bulk Import from CSV
* Added - Bulk Enroll from CSV
* Added - Student Progress Analytics
* Added - Duplicate Course & Lesson

= 1.6.3 - 13/07/2023 =
* Added - Lesson, Quiz and Assignment Auto Complete
* Fixed - Assignment and Booking Permanent Delete Issue
* Fixed - Zoom Host Email Issue

= 1.6.2 - 07/07/2023 =
* Added - Google reCAPTCHA V2 & V3
* Fixed - Booked Data Query Issues
* Fixed - Assignment Submit issue
* Fixed - QA API error for public course
* Fixed - Assignment Search Issue
* Updated - License API SDK

= 1.6.1 - 19/06/2023 =
* Fixed - Email button color issue
* Fixed - Email Student Profile Link issue
* Fixed - Assignment Submit not worked if a user already submitted
* Fixed - 2 Step Email verification redirect issue
* Fixed - Booking meta undefined issue
* Added - Added pagination support for Assignment and booking
* Added - Booking content drip support 

= 1.6.0 - 02/06/2023 =
* Fixed - Tutor booking showing static time
* Added - New course prerequisites addon 
* Added - Author name in posts rest API
* Update - Update Zoom API

= 1.5.2 - 19/05/2023 =
* Fixed - 2 Step Email Verification issue
* Fixed - Tutor Booking archive page search issue
* Added - Email Sender Email Settings

= 1.5.1 - 10/05/2023 =
* Fixed - Woocommerce sale price issue
* Added - 2 Step email verification for registration
* Added - Expire Enrollment

= 1.5.0 - 05/05/2023 =
* Added - New Paid Memberships Pro Addon

= 1.4.1 - 23/04/2023 =
* Fixed - Admin Notice Issues
* Fixed - languages path issues

= 1.4.0 - 21/04/2023 =
* Added - WP 6.2 Compatibility
* Added - New Tutor Booking addon

= 1.3.2 - 13/03/2023 =
* Added - Image Select, Short Answer and Fill in the blanks Quiz Types
* Added - Auto Load Next Lesson
* Fixed - Email Template content saving issue

= 1.3.1 - 27/02/2023 =
* Added - New Public Course Option
* Added - Auto WooCommerce Product creation systems
* Fixed - Fix Email Settings Issue
* Fixed - Fix Assignment Edit Issue
* Fixed - Remove Strong Tag From Email Subject

= 1.3.0 - 06/02/2023 =
* Added - New Assignment Addon
* Added - Cancel Enrollment Feature
* Update -Zoom API Improved
* Fixed - Enrolled course email subject issue
* Fixed - Before Creating Zoom check api connected or not

= 1.2.1 - 19/01/2023 =
* Fixed - Content Drip sequentially Not working
* Fixed - Student Search not working

= 1.2.0 - 08/01/2023 =
* Added - New Zoom Addon

= 1.1.1 - 18/12/2022 =
* Fixed - Recent Instructor Query issue
* Fixed - Recent Enrolled Query issue
* Few minor bug fix & improvements

= 1.1.0 - 17/12/2022 =
* Added - Advanced Analytics Addon

= 1.0.2 - 29/11/2022 =
* Fixed - Drip Content sequentially mode not working

= 1.0.1 - 17/11/2022 =
* Fixed - Academy LMS Core Minimum Version Compatibility issue

= 1.0.0 - 16/11/2022 =
* Added - Content Drip Addon
* Added - Manual Enrollment Addon
* Added - Email Notification Addon
* Added - WooCommerce Subscription Addon

== Upgrade Notice ==
= 2.8.0 =
This is a major update with breaking changes. Please back up your site before proceeding with the update.
