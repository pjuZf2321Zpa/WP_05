<?php
namespace AcademyProWebhooks;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Received-delivery audit trail for incoming webhooks.
 *
 * Doubles as the idempotency ledger: {@see self::claim()} inserts the delivery
 * row and the table's UNIQUE(webhook_id, delivery_id) decides — atomically —
 * whether this request is the first sighting or a replay.
 */
class DeliveryLog {

	private static function table(): string {
		global $wpdb;

		return $wpdb->prefix . ACADEMY_PLUGIN_SLUG . '_incoming_webhook_logs';
	}

	/**
	 * Claim a delivery: insert the audit row, or report that it already exists.
	 *
	 * Returns false when the unique key rejects the insert, which means another
	 * request already claimed this exact body — i.e. a replay. Callers must not
	 * run side effects when this returns false.
	 *
	 * @param int   $webhook_id Config post ID.
	 * @param array $entry      { delivery_id, action, status, source_ip, message, payload }.
	 */
	public static function claim( int $webhook_id, array $entry ): bool {
		global $wpdb;

		// Suppress the "duplicate entry" warning wpdb would otherwise print —
		// hitting the unique key is an expected outcome here, not a failure.
		$suppress = $wpdb->suppress_errors( true );

		$inserted = $wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
			self::table(),
			[
				'webhook_id'  => $webhook_id,
				'delivery_id' => (string) ( $entry['delivery_id'] ?? '' ),
				'action'      => (string) ( $entry['action'] ?? '' ),
				'payload'     => wp_json_encode( $entry['payload'] ?? [] ),
				'status'      => (string) ( $entry['status'] ?? 'accepted' ),
				'message'     => (string) ( $entry['message'] ?? '' ),
				'source_ip'   => (string) ( $entry['source_ip'] ?? '' ),
				'received_at' => current_time( 'mysql' ),
			],
			[ '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s' ]
		);

		$wpdb->suppress_errors( $suppress );

		return (bool) $inserted;
	}

	/**
	 * Merge a processing result into an already-claimed delivery.
	 *
	 * @param int    $webhook_id
	 * @param string $delivery_id
	 * @param array  $result { success:bool, message:string }.
	 */
	public static function update_result( int $webhook_id, string $delivery_id, array $result ): void {
		global $wpdb;

		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			self::table(),
			[
				'status'  => empty( $result['success'] ) ? 'failed' : 'processed',
				'message' => (string) ( $result['message'] ?? '' ),
			],
			[
				'webhook_id'  => $webhook_id,
				'delivery_id' => $delivery_id,
			],
			[ '%s', '%s' ],
			[ '%d', '%s' ]
		);
	}

	/**
	 * Recent deliveries for one config, newest first.
	 *
	 * @param int $webhook_id
	 * @param int $per_page
	 * @param int $page
	 *
	 * @return array<int,array>
	 */
	public static function all( int $webhook_id, int $per_page = 50, int $page = 1 ): array {
		global $wpdb;

		$per_page = max( 1, min( $per_page, 100 ) );
		$offset   = max( 0, ( $page - 1 ) * $per_page );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT * FROM ' . self::table() . ' WHERE webhook_id = %d ORDER BY id DESC LIMIT %d OFFSET %d', // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
				$webhook_id,
				$per_page,
				$offset
			),
			ARRAY_A
		);

		return array_map( [ __CLASS__, 'shape' ], $rows ? $rows : [] );
	}

	public static function count( int $webhook_id ): int {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		return (int) $wpdb->get_var(
			$wpdb->prepare(
				'SELECT COUNT(*) FROM ' . self::table() . ' WHERE webhook_id = %d', // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
				$webhook_id
			)
		);
	}

	/**
	 * @param int    $webhook_id
	 * @param string $delivery_id
	 *
	 * @return array|null
	 */
	public static function find( int $webhook_id, string $delivery_id ) {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$row = $wpdb->get_row(
			$wpdb->prepare(
				'SELECT * FROM ' . self::table() . ' WHERE webhook_id = %d AND delivery_id = %s', // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
				$webhook_id,
				$delivery_id
			),
			ARRAY_A
		);

		return $row ? self::shape( $row ) : null;
	}

	/**
	 * Delete every delivery row belonging to a config (used when the config
	 * itself is deleted, so logs don't outlive their webhook).
	 *
	 * @param int $webhook_id
	 */
	public static function purge( int $webhook_id ): void {
		global $wpdb;

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.NoCaching -- custom query with no WP API equivalent
		$wpdb->delete( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
			self::table(),
			[ 'webhook_id' => $webhook_id ],
			[ '%d' ]
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.NoCaching
	}

	/**
	 * Decode the stored payload for API/UI consumption.
	 *
	 * @param array $row
	 */
	private static function shape( array $row ): array {
		$row['id']         = (int) $row['id'];
		$row['webhook_id'] = (int) $row['webhook_id'];
		$row['payload']    = (array) json_decode( (string) $row['payload'], true );

		return $row;
	}
}
