<?php
namespace AcademyProWebhooks\Database;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CreateLogsTable {

	public static function init(): void {
		$self = new self();
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		global $wpdb;
		$self->create_table( $wpdb->prefix, $wpdb->get_charset_collate() );
	}

	public function create_table( string $prefix, string $charset_collate ): void {
		$table_name = $prefix . ACADEMY_PLUGIN_SLUG . '_incoming_webhook_logs';

		/*
		 * Received-delivery audit trail, one row per request.
		 *
		 * `UNIQUE KEY webhook_delivery` is load-bearing, not merely an index: it
		 * makes replay detection atomic. Two concurrent retries of the same
		 * signed body compute the same delivery_id and the database lets exactly
		 * one INSERT win — a SELECT-then-INSERT check would let both through and
		 * run the side effect twice.
		 *
		 * delivery_id is a sha256 hex digest of the raw body (64 chars) for
		 * accepted deliveries, or a random `rej_…` token for rejected ones so
		 * failed attempts never collide with one another.
		 *
		 * status: accepted  — authenticated and stored, not yet processed
		 *         processed — handler ran successfully
		 *         failed    — handler ran and returned an error
		 *         rejected  — never authenticated (bad signature, stale, oversized)
		 */
		$sql = "CREATE TABLE {$table_name} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			webhook_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			delivery_id VARCHAR(64) NOT NULL DEFAULT '',
			action VARCHAR(100) NOT NULL DEFAULT '',
			payload LONGTEXT NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'accepted',
			message TEXT NULL,
			source_ip VARCHAR(100) NOT NULL DEFAULT '',
			received_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (id),
			UNIQUE KEY webhook_delivery (webhook_id, delivery_id),
			KEY idx_webhook_id (webhook_id),
			KEY idx_status (status),
			KEY idx_received_at (received_at)
		) {$charset_collate};";

		dbDelta( $sql );
	}
}
