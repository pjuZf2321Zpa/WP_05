<?php
namespace AcademyProWebhooks\Handlers\Traits;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use WP_Error;

/**
 * Shared payload resolution for handlers that act on a user + course pair.
 *
 * External systems rarely know WordPress user IDs, so every handler accepts
 * either `user_id` or `email`.
 */
trait ResolvesTarget {

	/**
	 * @param array $payload
	 *
	 * @return int|WP_Error User ID.
	 */
	protected function resolve_user( array $payload ) {
		$user_id = absint( $payload['user_id'] ?? 0 );

		if ( $user_id ) {
			return get_user_by( 'ID', $user_id )
				? $user_id
				: new WP_Error( 'invalid_user', __( 'No user matches the given user_id.', 'academy-pro' ), [ 'status' => 422 ] );
		}

		$email = sanitize_email( $payload['email'] ?? '' );

		if ( $email && is_email( $email ) ) {
			$user = get_user_by( 'email', $email );

			return $user
				? (int) $user->ID
				: new WP_Error( 'invalid_user', __( 'No user matches the given email.', 'academy-pro' ), [ 'status' => 422 ] );
		}

		return new WP_Error( 'missing_user', __( 'Provide either user_id or email.', 'academy-pro' ), [ 'status' => 422 ] );
	}

	/**
	 * @param array $payload
	 *
	 * @return int|WP_Error Course ID.
	 */
	protected function resolve_course( array $payload ) {
		$course_id = absint( $payload['course_id'] ?? 0 );

		if ( ! $course_id || 'academy_courses' !== get_post_type( $course_id ) ) {
			return new WP_Error( 'invalid_course', __( 'Invalid or missing course_id.', 'academy-pro' ), [ 'status' => 422 ] );
		}

		return $course_id;
	}

	/**
	 * Run work as the target user, then restore the previous context.
	 *
	 * Academy's enrollment helpers short-circuit when nobody is logged in —
	 * `Helper::is_enrolled()` returns false before it queries anything. An
	 * incoming webhook is an unauthenticated machine request, so without this
	 * every enrollment lookup reports "not enrolled": `course_enroll` would
	 * insert a duplicate enrollment on each delivery and `course_complete`
	 * could never succeed at all.
	 *
	 * Assuming the identity the payload names is also the honest description of
	 * what is happening — the webhook acts on that user's behalf — so the rest
	 * of Academy's hooks and capability checks see the context they expect.
	 *
	 * @param int      $user_id User to act as.
	 * @param callable $work    Receives no arguments; its return value is passed through.
	 *
	 * @return mixed
	 */
	protected function as_user( int $user_id, callable $work ) {
		$previous = get_current_user_id();

		wp_set_current_user( $user_id );

		try {
			return $work();
		} finally {
			wp_set_current_user( $previous );
		}
	}

	/**
	 * Convert a WP_Error into the array shape handlers must return.
	 *
	 * @param WP_Error $error
	 */
	protected function error( WP_Error $error ): array {
		$data = $error->get_error_data();

		return [
			'success' => false,
			'status'  => (int) ( is_array( $data ) && isset( $data['status'] ) ? $data['status'] : 422 ),
			'message' => $error->get_error_message(),
		];
	}
}
