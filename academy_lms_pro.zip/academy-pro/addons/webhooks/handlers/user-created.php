<?php
namespace AcademyProWebhooks\Handlers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AcademyProWebhooks\Interfaces\IncomingHandlerInterface;

/**
 * Create a student account from an external system.
 *
 * Payload: { email, username?, first_name?, last_name? }
 */
class UserCreated implements IncomingHandlerInterface {

	public function handle( array $payload, array $context ): array {
		$email = sanitize_email( $payload['email'] ?? '' );

		if ( empty( $email ) || ! is_email( $email ) ) {
			return [
				'success' => false,
				'status'  => 422,
				'message' => __( 'Invalid or missing email.', 'academy-pro' ),
			];
		}

		// Idempotent: the account already exists, so this delivery is a no-op.
		$existing = get_user_by( 'email', $email );
		if ( $existing ) {
			return [
				'success' => true,
				'message' => __( 'User already exists.', 'academy-pro' ),
				'data'    => [ 'user_id' => (int) $existing->ID ],
			];
		}

		$username = sanitize_user( $payload['username'] ?? '' );

		if ( empty( $username ) ) {
			$username = sanitize_user( strstr( $email, '@', true ) );
		}

		if ( username_exists( $username ) ) {
			$username .= '_' . wp_generate_password( 4, false );
		}

		$user_data = apply_filters(
			'academy_pro/incoming_webhooks/user_created_data',
			[
				'user_login' => $username,
				'user_email' => $email,
				'first_name' => sanitize_text_field( $payload['first_name'] ?? '' ),
				'last_name'  => sanitize_text_field( $payload['last_name'] ?? '' ),
				'user_pass'  => wp_generate_password( 16 ),
				// `role` is a single slug — wp_insert_user passes it straight to
				// WP_User::set_role(), which does not accept an array.
				'role'       => 'academy_student',
			],
			$payload
		);

		$user_id = wp_insert_user( $user_data );

		if ( is_wp_error( $user_id ) ) {
			return [
				'success' => false,
				'status'  => 500,
				'message' => $user_id->get_error_message(),
			];
		}

		do_action( 'academy_pro/incoming_webhooks/user_created', $user_id, $payload, $context );

		return [
			'success' => true,
			'message' => __( 'User created.', 'academy-pro' ),
			'data'    => [ 'user_id' => (int) $user_id ],
		];
	}
}
