<?php
namespace AcademyProWebhooks\Handlers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AcademyProWebhooks\Handlers\Traits\ResolvesTarget;
use AcademyProWebhooks\Interfaces\IncomingHandlerInterface;
use WP_Error;

/**
 * Mark a course complete for a user.
 *
 * Payload: { user_id | email, course_id }
 */
class CourseCompleted implements IncomingHandlerInterface {

	use ResolvesTarget;

	public function handle( array $payload, array $context ): array {
		$user_id = $this->resolve_user( $payload );
		if ( $user_id instanceof WP_Error ) {
			return $this->error( $user_id );
		}

		$course_id = $this->resolve_course( $payload );
		if ( $course_id instanceof WP_Error ) {
			return $this->error( $course_id );
		}

		return $this->as_user(
			$user_id,
			function () use ( $user_id, $course_id, $payload, $context ) {
				return $this->complete( $user_id, $course_id, $payload, $context );
			}
		);
	}

	private function complete( int $user_id, int $course_id, array $payload, array $context ): array {
		global $wpdb;

		$enrolled = \Academy\Helper::is_enrolled( $course_id, $user_id );

		if ( ! $enrolled ) {
			return [
				'success' => false,
				'status'  => 422,
				'message' => __( 'User is not enrolled in this course.', 'academy-pro' ),
			];
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$already_completed = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(comment_ID) FROM {$wpdb->comments}
				WHERE comment_agent = 'academy' AND comment_type = 'course_completed'
				AND comment_post_ID = %d AND user_id = %d",
				$course_id,
				$user_id
			)
		);

		// Idempotent: a completion record already exists, so report success
		// rather than an error — the caller's intent is already satisfied.
		if ( $already_completed > 0 ) {
			return [
				'success' => true,
				'message' => __( 'Course was already completed.', 'academy-pro' ),
				'data'    => [
					'user_id'   => $user_id,
					'course_id' => $course_id,
				],
			];
		}

		do_action( 'academy_pro/admin/course_complete_before', $course_id );

		if ( 'completed' !== $enrolled->enrolled_status ) {
			\Academy\Helper::update_enrollment_status( $course_id, $enrolled->ID, $user_id, 'completed' );
		}

		$date = gmdate( 'Y-m-d H:i:s', \Academy\Helper::get_time() );
		$hash = substr( md5( wp_generate_password( 32 ) . $date . $course_id . $user_id ), 0, 16 );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$is_inserted = $wpdb->insert(
			$wpdb->comments,
			[
				'comment_post_ID'  => $course_id,
				'comment_author'   => $user_id,
				'comment_date'     => $date,
				'comment_date_gmt' => get_gmt_from_date( $date ),
				'comment_content'  => $hash,
				'comment_approved' => 'approved',
				'comment_agent'    => 'academy',
				'comment_type'     => 'course_completed',
				'user_id'          => $user_id,
			]
		);

		if ( ! $is_inserted ) {
			return [
				'success' => false,
				'status'  => 500,
				'message' => __( 'Failed to mark course as completed.', 'academy-pro' ),
			];
		}

		do_action( 'academy_pro/admin/course_complete_after', $course_id, $user_id );
		do_action( 'academy_pro/incoming_webhooks/course_completed', $course_id, $user_id, $enrolled->ID, $payload, $context );

		return [
			'success' => true,
			'message' => __( 'Course marked complete.', 'academy-pro' ),
			'data'    => [
				'user_id'   => $user_id,
				'course_id' => $course_id,
			],
		];
	}
}
