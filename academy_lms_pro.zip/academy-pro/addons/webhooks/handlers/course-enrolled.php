<?php
namespace AcademyProWebhooks\Handlers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AcademyProWebhooks\Handlers\Traits\ResolvesTarget;
use AcademyProWebhooks\Interfaces\IncomingHandlerInterface;
use WP_Error;

/**
 * Enroll a user into a course.
 *
 * Payload: { user_id | email, course_id }
 */
class CourseEnrolled implements IncomingHandlerInterface {

	use ResolvesTarget;

	public function handle( array $payload, array $context ): array {
		$user_id = $this->resolve_user( $payload );
		if ( $user_id instanceof WP_Error ) {
			return $this->error( $user_id );
		}

		$course_id = $this->resolve_course( $payload );
		if ( $course_id instanceof WP_Error ) {
			return $this->error( $course_id );
		}

		return $this->as_user(
			$user_id,
			function () use ( $user_id, $course_id, $payload, $context ) {
				return $this->enroll( $user_id, $course_id, $payload, $context );
			}
		);
	}

	private function enroll( int $user_id, int $course_id, array $payload, array $context ): array {
		// Idempotent: already actively enrolled.
		$existing = \Academy\Helper::is_enrolled( $course_id, $user_id, 'any' );
		if ( $existing && 'cancel' !== $existing->enrolled_status ) {
			return [
				'success' => true,
				'message' => __( 'User is already enrolled.', 'academy-pro' ),
				'data'    => [
					'user_id'   => $user_id,
					'course_id' => $course_id,
					'enroll_id' => (int) $existing->ID,
				],
			];
		}

		$enroll_id = \Academy\Helper::do_enroll( $course_id, $user_id );

		if ( ! $enroll_id ) {
			return [
				'success' => false,
				'status'  => 500,
				'message' => __( 'Enrollment failed.', 'academy-pro' ),
			];
		}

		do_action( 'academy_pro/incoming_webhooks/course_enrolled', $course_id, $user_id, $enroll_id, $payload, $context );

		return [
			'success' => true,
			'message' => __( 'User enrolled.', 'academy-pro' ),
			'data'    => [
				'user_id'   => $user_id,
				'course_id' => $course_id,
				'enroll_id' => (int) $enroll_id,
			],
		];
	}
}
