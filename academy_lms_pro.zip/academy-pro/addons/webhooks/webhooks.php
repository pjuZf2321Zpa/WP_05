<?php
namespace AcademyProWebhooks;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Academy\Interfaces\AddonInterface;

/**
 * Webhooks (Pro) — the incoming half of the free Webhooks addon.
 *
 * Named `webhooks`, not `incoming-webhooks`, on purpose: outgoing and incoming
 * are two directions of one feature, so this shares the free addon's identity
 * rather than presenting itself as a second addon. It has no toggle, no add-on
 * card and no menu entry of its own — enabling the free Webhooks addon enables
 * this too, and the Incoming tab of that one screen is rendered from Pro
 * through `wp.hooks`.
 *
 * When Pro is absent those same filters fall back to their default value, the
 * upsell teaser, so the free screen advertises the feature without needing to
 * know whether Pro exists.
 */
final class Webhooks implements AddonInterface {

	/**
	 * The free addon whose toggle this follows.
	 *
	 * @var string
	 */
	private $addon_name = 'webhooks';

	/**
	 * Bumped when the delivery-log schema changes so the table is reconciled
	 * without needing an activation hook of our own.
	 */
	const DB_VERSION        = '2';
	const DB_VERSION_KEY = 'incoming_webhooks';

	private function __construct() {
		$this->define_constants();
		$this->init_addon();
	}

	public function define_constants() {
		define( 'ACADEMY_PRO_WEBHOOKS_DIR_PATH', ACADEMY_PRO_ADDONS_DIR_PATH . 'webhooks/' );
	}

	public static function init() {
		static $instance = false;

		if ( ! $instance ) {
			$instance = new self();
		}

		return $instance;
	}

	public function init_addon() {
		// Ride the free addon's activation so the table exists as soon as
		// Webhooks is switched on.
		add_action( "academy/addons/activated_{$this->addon_name}", [ $this, 'addon_activation_hook' ] );

		if ( ! \Academy\Helper::get_addon_active_status( $this->addon_name ) ) {
			return;
		}

		add_action( 'init', [ $this, 'maybe_install' ], 1 );

		Incoming::init();
		Receiver::init();

		// Delivery logs are keyed by config ID, so they must not outlive it.
		add_action( 'before_delete_post', [ $this, 'purge_deliveries' ], 10, 2 );

		add_filter( 'academy/assets/backend_scripts_data', [ $this, 'add_script_data' ] );
	}

	/**
	 * Create/upgrade the delivery-log table, guarded by a version option so the
	 * dbDelta cost is paid once rather than on every request.
	 */
	public function maybe_install(): void {
		if ( \Academy\Options::get( \Academy\Options::PRO_DB_VERSIONS, self::DB_VERSION_KEY ) === self::DB_VERSION ) {
			return;
		}

		$this->addon_activation_hook();
	}

	public function addon_activation_hook() {
		Database::init();
		\Academy\Options::set( \Academy\Options::PRO_DB_VERSIONS, self::DB_VERSION_KEY, self::DB_VERSION );
	}

	/**
	 * @param int      $post_id Post being deleted.
	 * @param \WP_Post $post    Post object.
	 */
	public function purge_deliveries( $post_id, $post = null ): void {
		if ( $post && Incoming::POST_TYPE === $post->post_type ) {
			DeliveryLog::purge( (int) $post_id );
		}
	}

	/**
	 * Expose the action picker options and the endpoint base URL to the admin
	 * SPA, so the Incoming tab needs no extra request to render its form.
	 *
	 * @param array $data Existing localized data.
	 */
	public function add_script_data( $data ) {
		$data['incomingWebhooks'] = [
			'actions'      => Registry::get_actions(),
			'endpointBase' => esc_url_raw( rest_url( ACADEMY_PRO_PLUGIN_SLUG . '/v1/incoming/' ) ),
			'restBase'     => ACADEMY_PRO_PLUGIN_SLUG . '/v1/incoming-webhook',
		];

		return $data;
	}
}
