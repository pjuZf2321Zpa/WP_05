<?php
namespace AcademyProWebhooks;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AcademyProWebhooks\Database\CreateLogsTable;

class Database {

	/**
	 * Only the delivery log needs a table. Webhook configs live in the
	 * `academy_in_hook` post type ({@see Incoming}), matching how the free
	 * outgoing addon stores its own configs.
	 */
	public static function init(): void {
		CreateLogsTable::init();
		self::drop_legacy_schema();
	}

	/**
	 * Remove artefacts of the pre-release schema.
	 *
	 * The first cut of this addon kept configs in their own table and logged
	 * against `event_type` / `idempotency_key`. dbDelta adds the new columns but
	 * never removes the old ones, and one of them — `error_message TEXT NOT NULL`
	 * with no default — makes every INSERT that omits it fail outright under
	 * strict SQL mode. So the leftovers have to go, not merely be ignored.
	 *
	 * Safe to run unconditionally: the feature has never shipped, so these
	 * objects only exist on installs that ran a pre-release build.
	 *
	 * Every identifier interpolated below is an internal constant or a literal
	 * from the list here — never request data — and identifiers cannot be bound
	 * as placeholders, hence the suppressions.
	 */
	// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	private static function drop_legacy_schema(): void {
		global $wpdb;

		$logs = $wpdb->prefix . ACADEMY_PLUGIN_SLUG . '_incoming_webhook_logs';

		$columns = (array) $wpdb->get_col( "SHOW COLUMNS FROM {$logs}" );

		foreach ( [ 'event_type', 'error_message', 'idempotency_key', 'created_at' ] as $column ) {
			if ( in_array( $column, $columns, true ) ) {
				$wpdb->query( "ALTER TABLE {$logs} DROP COLUMN `{$column}`" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange -- versioned one-time schema migration
			}
		}

		// Configs moved to the `academy_in_hook` post type.
		$configs = $wpdb->prefix . ACADEMY_PLUGIN_SLUG . '_incoming_webhooks';

		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $configs ) ) ) {
			$wpdb->query( "DROP TABLE {$configs}" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange -- versioned one-time schema migration
		}
	}
	// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
}
