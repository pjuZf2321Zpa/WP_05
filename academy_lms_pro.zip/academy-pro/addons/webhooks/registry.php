<?php
namespace AcademyProWebhooks;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AcademyProWebhooks\Handlers\CourseCompleted;
use AcademyProWebhooks\Handlers\CourseEnrolled;
use AcademyProWebhooks\Handlers\UserCreated;
use AcademyProWebhooks\Interfaces\IncomingHandlerInterface;

/**
 * Maps an action slug to the handler that performs it, and describes the
 * available actions for the admin picker.
 *
 * The action is bound to the webhook *config*, not read from the request body.
 * A caller therefore cannot choose which side effect runs — holding the secret
 * for a "mark course complete" endpoint does not let them create users.
 *
 * The `automation` pseudo-action skips structured handling and only fires the
 * internal `.../received` hooks — the no-code / FluentCRM path.
 */
class Registry {

	const AUTOMATION = 'automation';

	/**
	 * Action slug => handler class.
	 *
	 * @return array<string,class-string<IncomingHandlerInterface>>
	 */
	public static function get_handlers(): array {
		return (array) apply_filters(
			'academy_pro/incoming_webhooks/handlers',
			[
				'user_create'     => UserCreated::class,
				'course_enroll'   => CourseEnrolled::class,
				'course_complete' => CourseCompleted::class,
			]
		);
	}

	/**
	 * @param string $action
	 *
	 * @return IncomingHandlerInterface|null
	 */
	public static function get_handler( string $action ) {
		$handlers = self::get_handlers();

		if ( ! isset( $handlers[ $action ] ) ) {
			return null;
		}

		$class = $handlers[ $action ];

		if ( ! class_exists( $class ) ) {
			return null;
		}

		$instance = new $class();

		return $instance instanceof IncomingHandlerInterface ? $instance : null;
	}

	/**
	 * Action descriptors for the admin picker (value + label + help text),
	 * exposed on the backend script data global.
	 *
	 * @return array<int,array{value:string,label:string,description:string}>
	 */
	public static function get_actions(): array {
		return (array) apply_filters(
			'academy_pro/incoming_webhooks/action_labels',
			[
				[
					'value'       => self::AUTOMATION,
					'label'       => __( 'Automation / Raw (fire internal hook only)', 'academy-pro' ),
					'description' => __( 'Verify and log the request, then fire the academy_pro/incoming_webhook/received action for no-code tools and custom code to handle.', 'academy-pro' ),
				],
				[
					'value'       => 'user_create',
					'label'       => __( 'User → Create', 'academy-pro' ),
					'description' => __( 'Create a student account. Payload: { email, username?, first_name?, last_name? }.', 'academy-pro' ),
				],
				[
					'value'       => 'course_enroll',
					'label'       => __( 'Course → Enroll student', 'academy-pro' ),
					'description' => __( 'Enroll a user into a course. Payload: { user_id, course_id } or { email, course_id }.', 'academy-pro' ),
				],
				[
					'value'       => 'course_complete',
					'label'       => __( 'Course → Mark complete', 'academy-pro' ),
					'description' => __( 'Mark a course complete for a user. Payload: { user_id, course_id } or { email, course_id }.', 'academy-pro' ),
				],
			]
		);
	}
}
