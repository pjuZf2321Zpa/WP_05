<?php
namespace AcademyProWebhooks;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Incoming webhook configuration store.
 *
 * Where the free Webhooks addon lets Academy *announce* events to the world,
 * incoming webhooks let the world *drive* Academy: an external CRM POSTs
 * "user created", a no-code tool (Zapier / Make / n8n) enrolls a student, a
 * partner LMS marks a course complete.
 *
 * Each config is a `academy_in_hook` post — the same storage shape the free
 * outgoing addon uses for `academy_webhook` — so both directions share one
 * REST surface (the core posts controller), one permission model and one
 * Redux shape in the admin UI. Admin CRUD therefore needs no bespoke routes;
 * only the public receiver does ({@see Receiver}).
 */
class Incoming {

	/**
	 * WordPress caps post type names at 20 characters, so the internal slug is
	 * terse. The public REST base stays the readable `incoming-webhook`.
	 */
	const POST_TYPE = 'academy_in_hook';

	const META_KEY    = '_academy_incoming_endpoint_key';
	const META_SECRET = '_academy_incoming_secret';
	const META_AUTH   = '_academy_incoming_auth_type';
	const META_ACTION = '_academy_incoming_action';

	public static function init(): void {
		$self = new self();

		add_action( 'init', [ $self, 'register_post_type' ], 5 );
		add_action( 'rest_api_init', [ $self, 'register_meta' ] );

		// Auto-provision an endpoint key + secret the first time a config is
		// saved, so the admin never has to hand-craft them and they can never
		// be left blank (a blank secret would mean an unauthenticated endpoint).
		add_action( 'rest_after_insert_' . self::POST_TYPE, [ $self, 'ensure_credentials' ], 10, 1 );

		// Deferred processing path (opt-in via the `.../defer` filter).
		add_action( 'academy_pro/incoming_webhook/process', [ Processor::class, 'process_scheduled' ], 10, 1 );
	}

	/**
	 * Register the config post type. Admin CRUD rides the default REST posts
	 * controller, mirroring the free outgoing `academy_webhook` type.
	 */
	public function register_post_type(): void {
		register_post_type(
			self::POST_TYPE,
			[
				'labels'                => [
					'name'          => esc_html__( 'Incoming Webhooks', 'academy-pro' ),
					'singular_name' => esc_html__( 'Incoming Webhook', 'academy-pro' ),
				],
				'public'                => false,
				'publicly_queryable'    => false,
				'show_ui'               => false,
				'show_in_menu'          => false,
				'hierarchical'          => false,
				'rewrite'               => false,
				'query_var'             => false,
				'has_archive'           => false,
				'delete_with_user'      => false,
				'supports'              => [ 'title', 'author', 'custom-fields' ],
				'show_in_rest'          => true,
				'rest_base'             => 'incoming-webhook',
				'rest_namespace'        => ACADEMY_PRO_PLUGIN_SLUG . '/v1',
				'rest_controller_class' => 'WP_REST_Posts_Controller',
				'capability_type'       => 'post',
				'capabilities'          => [
					'edit_post'          => 'manage_options',
					'read_post'          => 'manage_options',
					'delete_post'        => 'manage_options',
					'delete_posts'       => 'manage_options',
					'edit_posts'         => 'manage_options',
					'edit_others_posts'  => 'manage_options',
					'publish_posts'      => 'manage_options',
					'read_private_posts' => 'manage_options',
					'create_posts'       => 'manage_options',
				],
			]
		);
	}

	public function register_meta(): void {
		$meta = [
			self::META_KEY    => 'sanitize_text_field',
			self::META_SECRET => 'sanitize_text_field',
			self::META_AUTH   => 'sanitize_key',
			self::META_ACTION => 'sanitize_key',
		];

		foreach ( $meta as $key => $sanitize ) {
			register_meta(
				'post',
				$key,
				[
					'object_subtype'    => self::POST_TYPE,
					'type'              => 'string',
					'single'            => true,
					'show_in_rest'      => true,
					'sanitize_callback' => $sanitize,
					'auth_callback'     => [ $this, 'can_manage' ],
				]
			);
		}
	}

	public function can_manage(): bool {
		return current_user_can( 'manage_options' );
	}

	/**
	 * Ensure a freshly-created config has a URL key and a secret. Existing
	 * values are never overwritten, so the admin can rotate them deliberately.
	 *
	 * @param \WP_Post $post Inserted post.
	 */
	public function ensure_credentials( $post ): void {
		$id = (int) $post->ID;

		if ( ! get_post_meta( $id, self::META_KEY, true ) ) {
			update_post_meta( $id, self::META_KEY, self::generate_key() );
		}

		if ( ! get_post_meta( $id, self::META_SECRET, true ) ) {
			update_post_meta( $id, self::META_SECRET, self::generate_secret() );
		}

		if ( ! get_post_meta( $id, self::META_AUTH, true ) ) {
			update_post_meta( $id, self::META_AUTH, 'hmac' );
		}

		if ( ! get_post_meta( $id, self::META_ACTION, true ) ) {
			update_post_meta( $id, self::META_ACTION, Registry::AUTOMATION );
		}
	}

	/**
	 * URL-safe, unguessable endpoint key. This is the routable part of the
	 * public URL, so it must be unique across configs.
	 */
	public static function generate_key(): string {
		do {
			$key = wp_generate_password( 24, false, false );
		} while ( self::find_by_key( $key ) );

		return $key;
	}

	/**
	 * Alphanumeric on purpose.
	 *
	 * The secret is stored in post meta whose sanitize_callback is
	 * sanitize_text_field, which HTML-encodes `<`, `>` and `&`. A generated
	 * password containing those would be stored (and shown to the admin) as
	 * `&lt;` while the signature check compared against the decoded `<` — so an
	 * integrator copying the secret out of the UI would get a permanent 401
	 * with nothing to explain it. Restricting the alphabet removes the
	 * round-trip entirely; 48 alphanumeric characters is ~286 bits, far beyond
	 * what an HMAC key needs.
	 */
	public static function generate_secret(): string {
		return wp_generate_password( 48, false, false );
	}

	/**
	 * Resolve a config post by its endpoint key.
	 *
	 * @param string $key Endpoint key.
	 *
	 * @return \WP_Post|null
	 */
	public static function find_by_key( string $key ) {
		if ( '' === $key ) {
			return null;
		}

		$posts = get_posts(
			[
				'post_type'        => self::POST_TYPE,
				'post_status'      => [ 'publish', 'draft', 'private' ],
				'numberposts'      => 1,
				'meta_key'         => self::META_KEY, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
				'meta_value'       => $key, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
				'suppress_filters' => false,
			]
		);

		return $posts ? $posts[0] : null;
	}

	/**
	 * Full public URL for a config's endpoint key.
	 *
	 * @param string $key
	 */
	public static function endpoint_url( string $key ): string {
		return rest_url( ACADEMY_PRO_PLUGIN_SLUG . '/v1/incoming/' . $key );
	}
}
