<?php
namespace AcademyProWebhooks\Interfaces;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

interface IncomingHandlerInterface {

	/**
	 * Perform the mapped action for an authenticated, deduped payload.
	 *
	 * Handlers must be idempotent: the same payload arriving twice (a sender
	 * retry that slipped past dedup) must not produce a second side effect.
	 *
	 * @param array $payload Decoded JSON body.
	 * @param array $context { webhook_id:int, delivery_id:string, action:string }.
	 *
	 * @return array{success:bool,message:string,status?:int,data?:array}
	 */
	public function handle( array $payload, array $context ): array;
}
