<?php
namespace AcademyProWebhooks;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use WP_Error;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

/**
 * Public receiver for incoming webhooks.
 *
 * The ingestion endpoint is intentionally unauthenticated at the WordPress
 * layer (no cookie, no nonce) because callers are machines — the per-config
 * secret *is* the credential. Every request is authenticated, size-capped,
 * freshness-checked and deduped before any side effect runs.
 *
 * The config is addressed by an unguessable key in the URL rather than by a
 * field in the body, so which webhook (and therefore which action) applies is
 * decided before the body is parsed or trusted.
 */
class Receiver {

	public static function init(): void {
		add_action( 'rest_api_init', [ new self(), 'register_routes' ] );
	}

	public function register_routes(): void {
		$ns = ACADEMY_PRO_PLUGIN_SLUG . '/v1';

		// Public ingestion endpoint. Auth is the secret, so permission is open.
		register_rest_route(
			$ns,
			'/incoming/(?P<key>[A-Za-z0-9]+)',
			[
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'handle' ],
					'permission_callback' => '__return_true',
					'args'                => [
						'key' => [ 'sanitize_callback' => 'sanitize_text_field' ],
					],
				],
			]
		);

		// Admin-only: delivery history for one config (audit trail).
		register_rest_route(
			$ns,
			'/incoming-webhook/(?P<id>\d+)/deliveries',
			[
				[
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => [ $this, 'get_deliveries' ],
					'permission_callback' => [ $this, 'admin_permission' ],
				],
			]
		);

		// Admin-only: replay a stored delivery through the current handler.
		register_rest_route(
			$ns,
			'/incoming-webhook/(?P<id>\d+)/replay',
			[
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'replay' ],
					'permission_callback' => [ $this, 'admin_permission' ],
					'args'                => [
						'delivery_id' => [
							'required'          => true,
							'sanitize_callback' => 'sanitize_text_field',
						],
					],
				],
			]
		);
	}

	public function admin_permission(): bool {
		return current_user_can( 'manage_options' );
	}

	/**
	 * Handle a public ingestion request.
	 *
	 * @param WP_REST_Request $request Request.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function handle( WP_REST_Request $request ) {
		$key     = (string) $request->get_param( 'key' );
		$webhook = Incoming::find_by_key( $key );

		if ( ! $webhook ) {
			return new WP_Error(
				'academy_webhook_not_found',
				__( 'Unknown webhook endpoint.', 'academy-pro' ),
				[ 'status' => 404 ]
			);
		}

		$webhook_id = (int) $webhook->ID;

		if ( 'publish' !== $webhook->post_status ) {
			return new WP_Error(
				'academy_webhook_paused',
				__( 'This webhook endpoint is paused.', 'academy-pro' ),
				[ 'status' => 403 ]
			);
		}

		$raw = (string) $request->get_body();

		// Size guard — reject oversized bodies before hashing or parsing them.
		$max = (int) apply_filters( 'academy_pro/incoming_webhook/max_body_size', MB_IN_BYTES, $webhook_id );
		if ( $max > 0 && strlen( $raw ) > $max ) {
			return $this->reject( $webhook_id, 'oversized', __( 'Payload too large.', 'academy-pro' ), 413 );
		}

		// Authenticate.
		$auth   = get_post_meta( $webhook_id, Incoming::META_AUTH, true ) ? get_post_meta( $webhook_id, Incoming::META_AUTH, true ) : 'hmac';
		$secret = (string) get_post_meta( $webhook_id, Incoming::META_SECRET, true );
		$verify = $this->verify( $auth, $secret, $raw, $request, $webhook_id );
		if ( is_wp_error( $verify ) ) {
			return $this->reject( $webhook_id, 'unauthorized', $verify->get_error_message(), 401 );
		}

		// Bound the replay window.
		$fresh = $this->check_timestamp( $request, $webhook_id );
		if ( is_wp_error( $fresh ) ) {
			return $this->reject( $webhook_id, 'stale', $fresh->get_error_message(), 401 );
		}

		$payload = json_decode( $raw, true );
		if ( JSON_ERROR_NONE !== json_last_error() || ! is_array( $payload ) ) {
			return $this->reject( $webhook_id, 'invalid_json', __( 'Request body is not valid JSON.', 'academy-pro' ), 400 );
		}

		$delivery_id = $this->delivery_id( $raw );
		$action      = get_post_meta( $webhook_id, Incoming::META_ACTION, true ) ? get_post_meta( $webhook_id, Incoming::META_ACTION, true ) : Registry::AUTOMATION;

		// Claim the delivery. The unique key decides, atomically, whether this
		// is the first sighting of this exact body or a retry of one we already
		// handled — so concurrent retries cannot both run the side effect.
		$claimed = DeliveryLog::claim(
			$webhook_id,
			[
				'delivery_id' => $delivery_id,
				'action'      => $action,
				'status'      => 'accepted',
				'source_ip'   => $this->client_ip(),
				'message'     => '',
				'payload'     => $payload,
			]
		);

		if ( ! $claimed ) {
			return new WP_REST_Response(
				[
					'success'     => true,
					'duplicate'   => true,
					'delivery_id' => $delivery_id,
					'message'     => __( 'Duplicate delivery ignored.', 'academy-pro' ),
				],
				200
			);
		}

		// Deferred path (opt-in) — acknowledge now, process on a scheduled tick.
		$defer = (bool) apply_filters( 'academy_pro/incoming_webhook/defer', false, $webhook_id, $action, $payload );
		if ( $defer ) {
			wp_schedule_single_event(
				time(),
				'academy_pro/incoming_webhook/process',
				[
					[
						'webhook_id'  => $webhook_id,
						'delivery_id' => $delivery_id,
						'action'      => $action,
						'payload'     => $payload,
					],
				]
			);

			return new WP_REST_Response(
				[
					'success'     => true,
					'queued'      => true,
					'delivery_id' => $delivery_id,
				],
				202
			);
		}//end if

		// Synchronous path — process now and return the real result so the
		// caller learns whether the action actually succeeded.
		$result = Processor::process( $webhook_id, $delivery_id, $action, $payload );
		DeliveryLog::update_result( $webhook_id, $delivery_id, $result );

		$status = $result['success'] ? 200 : (int) ( $result['status'] ?? 422 );

		return new WP_REST_Response(
			[
				'success'     => $result['success'],
				'delivery_id' => $delivery_id,
				'message'     => $result['message'],
				'data'        => $result['data'] ?? null,
			],
			$status
		);
	}

	/**
	 * Verify the request credential.
	 *
	 * @param string          $auth
	 * @param string          $secret
	 * @param string          $raw
	 * @param WP_REST_Request $request
	 * @param int             $webhook_id
	 *
	 * @return true|WP_Error
	 */
	protected function verify( string $auth, string $secret, string $raw, WP_REST_Request $request, int $webhook_id ) {
		if ( '' === $secret ) {
			return new WP_Error( 'no_secret', __( 'Webhook is missing a secret.', 'academy-pro' ) );
		}

		// Generated secrets are alphanumeric, but an admin may type one
		// containing `<`, `>` or `&`, which sanitize_text_field stores encoded.
		// Accept the stored form and the decoded form so the sender works
		// whichever one the admin copied.
		$keys = array_unique( [ $secret, wp_specialchars_decode( $secret, ENT_QUOTES ) ] );

		if ( 'bearer' === $auth ) {
			$header = (string) $request->get_header( 'authorization' );
			$token  = 0 === stripos( $header, 'bearer ' ) ? substr( $header, 7 ) : $header;

			if ( '' === trim( $token ) ) {
				$token = (string) $request->get_header( 'x_academy_token' );
			}

			$token = trim( $token );

			foreach ( $keys as $key ) {
				if ( hash_equals( $key, $token ) ) {
					return true;
				}
			}

			return new WP_Error( 'invalid_token', __( 'Invalid bearer token.', 'academy-pro' ) );
		}

		// Otherwise HMAC, the default scheme.
		$provided = trim( (string) $request->get_header( 'x_academy_signature' ) );

		if ( '' === $provided ) {
			return new WP_Error( 'missing_signature', __( 'Missing signature header.', 'academy-pro' ) );
		}

		// Tolerate an algorithm prefix (e.g. "sha256=") used by some senders.
		$provided = (string) preg_replace( '/^(sha1|sha256|sha512)=/i', '', $provided );

		$algo = (string) apply_filters( 'academy_pro/incoming_webhook/hashing_algorithm', 'sha256', $webhook_id );

		foreach ( $keys as $key ) {
			// Accept the hex digest and the base64 form, since senders differ.
			$candidates = [
				hash_hmac( $algo, $raw, $key, false ),
				base64_encode( hash_hmac( $algo, $raw, $key, true ) ), // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
			];

			foreach ( $candidates as $candidate ) {
				if ( hash_equals( $candidate, $provided ) ) {
					return true;
				}
			}
		}

		return new WP_Error( 'invalid_signature', __( 'Signature verification failed.', 'academy-pro' ) );
	}

	/**
	 * Enforce a freshness window.
	 *
	 * The timestamp header is not itself covered by the HMAC, so on its own it
	 * does not prove freshness against an active attacker. It is enforced to
	 * bound the replay window; combined with the body-derived delivery id
	 * ({@see delivery_id()}) that blocks practical replay of a captured signed
	 * request. An integrator whose sender genuinely cannot supply a timestamp
	 * can disable the window by filtering the tolerance to 0.
	 *
	 * @param WP_REST_Request $request
	 * @param int             $webhook_id
	 *
	 * @return true|WP_Error
	 */
	protected function check_timestamp( WP_REST_Request $request, int $webhook_id ) {
		$tolerance = (int) apply_filters( 'academy_pro/incoming_webhook/timestamp_tolerance', 5 * MINUTE_IN_SECONDS, $webhook_id );

		if ( $tolerance <= 0 ) {
			return true; // Explicitly disabled by the integrator.
		}

		$ts = trim( (string) $request->get_header( 'x_academy_timestamp' ) );

		if ( '' === $ts ) {
			return new WP_Error( 'missing_timestamp', __( 'A request timestamp header is required.', 'academy-pro' ) );
		}

		$when = is_numeric( $ts ) ? (int) $ts : strtotime( $ts );

		if ( ! $when ) {
			return new WP_Error( 'invalid_timestamp', __( 'The request timestamp is invalid.', 'academy-pro' ) );
		}

		if ( abs( time() - $when ) > $tolerance ) {
			return new WP_Error( 'stale_request', __( 'Request timestamp is outside the allowed window.', 'academy-pro' ) );
		}

		return true;
	}

	/**
	 * Replay / idempotency key.
	 *
	 * Derived only from material the signature covers — the raw body. An
	 * `X-Delivery-Id`-style header is attacker-controlled and unsigned: keying
	 * off it would let a captured, validly-signed body be replayed indefinitely
	 * by varying that header on each request. A sender that needs to distinguish
	 * two otherwise-identical payloads must include a unique field (id, sequence
	 * or timestamp) *inside* the signed body so the hash differs.
	 *
	 * @param string $raw
	 */
	protected function delivery_id( string $raw ): string {
		return hash( 'sha256', $raw );
	}

	protected function client_ip(): string {
		return \AcademyPro\Helper::get_remote_addr();
	}

	/**
	 * Log a rejected request and return the error response.
	 *
	 * @param int    $webhook_id
	 * @param string $reason
	 * @param string $message
	 * @param int    $status
	 */
	protected function reject( int $webhook_id, string $reason, string $message, int $status ): WP_Error {
		DeliveryLog::claim(
			$webhook_id,
			[
				// Random, so rejected attempts never collide with each other or
				// with a real (body-derived) delivery id.
				'delivery_id' => 'rej_' . wp_generate_password( 32, false, false ),
				'action'      => '',
				'status'      => 'rejected',
				'source_ip'   => $this->client_ip(),
				'message'     => $reason . ': ' . $message,
				'payload'     => [],
			]
		);

		return new WP_Error( 'academy_webhook_rejected', $message, [ 'status' => $status ] );
	}

	/**
	 * Admin: delivery history for one config.
	 *
	 * @param WP_REST_Request $request
	 */
	public function get_deliveries( WP_REST_Request $request ): WP_REST_Response {
		$id       = (int) $request->get_param( 'id' );
		$per_page = (int) ( $request->get_param( 'per_page' ) ? $request->get_param( 'per_page' ) : 20 );
		$page     = (int) ( $request->get_param( 'page' ) ? $request->get_param( 'page' ) : 1 );

		$response = new WP_REST_Response( DeliveryLog::all( $id, $per_page, $page ), 200 );
		$response->header( 'X-WP-Total', (string) DeliveryLog::count( $id ) );

		return $response;
	}

	/**
	 * Admin: replay a stored delivery through the current handler.
	 *
	 * @param WP_REST_Request $request
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function replay( WP_REST_Request $request ) {
		$id          = (int) $request->get_param( 'id' );
		$delivery_id = (string) $request->get_param( 'delivery_id' );
		$entry       = DeliveryLog::find( $id, $delivery_id );

		if ( ! $entry ) {
			return new WP_Error( 'not_found', __( 'Delivery not found.', 'academy-pro' ), [ 'status' => 404 ] );
		}

		$action = get_post_meta( $id, Incoming::META_ACTION, true ) ? get_post_meta( $id, Incoming::META_ACTION, true ) : Registry::AUTOMATION;
		$result = Processor::process( $id, 'replay_' . $delivery_id, $action, (array) ( $entry['payload'] ?? [] ) );
		$status = $result['success'] ? 200 : (int) ( $result['status'] ?? 422 );

		return new WP_REST_Response( $result, $status );
	}
}
