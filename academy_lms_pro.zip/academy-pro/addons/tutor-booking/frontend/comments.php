<?php
namespace AcademyProTutorBooking\Frontend;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Comments {
	public static function init() {
		$self = new self();
		add_action( 'comment_post', array( $self, 'add_comment_rating' ), 1 );
	}

	/**
	 * Rating field for comments.
	 *
	 * @param int $comment_id Comment ID.
	 */
	public function add_comment_rating( $comment_id ) {
		// Nonce is verified by WordPress core before the `comment_post` action fires.
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$post_id = isset( $_POST['comment_post_ID'] ) ? absint( $_POST['comment_post_ID'] ) : 0;
		if ( $post_id && 'academy_booking' === get_post_type( $post_id ) ) {
			wp_update_comment(
				[
					'comment_ID'   => $comment_id,
					'comment_type' => 'academy_booking',
				]
			);

			// phpcs:ignore WordPress.Security.NonceVerification.Missing
			$academy_rating = isset( $_POST['academy_rating'] ) ? (int) sanitize_text_field( wp_unslash( $_POST['academy_rating'] ) ) : 0;

			if ( ! $academy_rating || $academy_rating > 5 || $academy_rating < 0 ) {
				return;
			}

			add_comment_meta( $comment_id, 'academy_rating', $academy_rating, true );
			do_action( 'academy_pro/fronted/academy_booking_review', $comment_id, $academy_rating );
		}//end if
	}
}
