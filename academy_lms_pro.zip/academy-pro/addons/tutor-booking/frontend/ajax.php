<?php
namespace AcademyProTutorBooking\Frontend;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AcademyProTutorBooking\Helper;
use DateTime;
use DateTimeZone;

class Ajax {
	public static function init() {
		$self = new self();
		add_action( 'wp_ajax_academy_pro/booking/frontend/do_booked', array( $self, 'do_booked' ) );
		add_action( 'wp_ajax_academy_pro/booking/frontend/get_my_booking', array( $self, 'get_my_booking' ) );
		add_action( 'wp_ajax_academy_pro/booking/frontend/get_booking', array( $self, 'get_booking' ) );
		add_action( 'wp_ajax_academy_pro/booking/frontend/get_booked_schedule_details', array( $self, 'get_booked_schedule_details' ) );
		add_action( 'wp_ajax_academy_pro/booking/frontend/archive_booking_filter', array( $self, 'archive_booking_filter' ) );
		add_action( 'wp_ajax_nopriv_academy_pro/booking/frontend/archive_booking_filter', array( $self, 'archive_booking_filter' ) );
		add_action( 'wp_ajax_academy_pro/booking/frontend/cancel_booking', array( $self, 'cancel_booked_schedule' ) );
		add_action( 'wp_ajax_academy_pro/booking/frontend/reschedule_booking', array( $self, 'reschedule_booked_schedule' ) );
		add_action( 'wp_ajax_academy_pro/booking/frontend/render_booking', array( $self, 'render_booking' ) );
		// mark as complete
		add_action( 'academy/frontend/before_mark_topic_complete', array( $self, 'mark_booking_complete' ), 11, 4 );
	}

	public function do_booked() {
		check_ajax_referer( 'academy_nonce', 'security' );

		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotValidated, WordPress.Security.ValidatedSanitizedInput.MissingUnslash 
		$booking_id = (int) sanitize_text_field( $_POST['booking_id'] );
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotValidated, WordPress.Security.ValidatedSanitizedInput.MissingUnslash 
		$selected_date = (string) sanitize_text_field( $_POST['selectedDate'] );
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotValidated, WordPress.Security.ValidatedSanitizedInput.MissingUnslash 
		$selected_time_slot = (string) sanitize_text_field( $_POST['selectedTimeSlot'] );
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotValidated, WordPress.Security.ValidatedSanitizedInput.MissingUnslash 
		$time_zone = (string) sanitize_text_field( $_POST['timeZone'] );
		$user_id = get_current_user_id();
		$schedule_date_time = $selected_date . ' ' . $selected_time_slot . ' ' . $time_zone;
		// The id has to be a real, bookable booking item. Without this any id
		// (e.g. -1) was accepted and left an orphan booking behind — and, being
		// a different "booking item" each time, got around the one-live-booking
		// rule below.
		if ( 'academy_booking' !== get_post_type( $booking_id ) || ! in_array( get_post_status( $booking_id ), array( 'publish', 'private' ), true ) ) {
			wp_send_json_error( array( 'message' => __( 'Sorry, this booking is not available.', 'academy-pro' ) ) );
		}
		// One live booking per user per booking item, wherever it is booked from
		// (the Tutor Booking page or a course's curriculum): a second one has to
		// be a reschedule, or a cancel followed by a new booking. This only
		// applies to "single" schedules, which have exactly one possible
		// occurrence — a "repeated" schedule has many distinct occurrences, so
		// a student may hold several live bookings against it; the exact-slot
		// and capacity checks below still stop the same occurrence being
		// double-booked.
		$schedule_type = get_post_meta( $booking_id, '_academy_booking_schedule_type', true );
		if ( 'single' === $schedule_type && Helper::get_active_booked_id( $booking_id, $user_id ) ) {
			wp_send_json_error( array( 'message' => __( 'You have already booked this. To change the time, reschedule or cancel your existing booking first.', 'academy-pro' ) ) );
		}
		// Check already booked
		$is_booked = Helper::booking_schedule_already_booked( $schedule_date_time, $user_id );
		if ( $is_booked ) {
			/* translators: %s is a date., %s is a date */
			wp_send_json_error( array( 'message' => sprintf( __( 'Sorry, The Booking Schedule %1$s %2$s is Already Booked', 'academy-pro' ), $selected_date, $selected_time_slot ) ) );
		}
		// Generate date time.
		$booking_type = Helper::get_booking_type( $booking_id );
		$processing_booked = Helper::get_processing_booking_booked( $booking_id, $user_id );
		if ( $processing_booked ) {
			foreach ( $processing_booked as $booked ) {
				$schedule = get_post_meta( $booked->ID, '_academy_booked_schedule_time', true );
				if ( $schedule_date_time === $schedule ) {
					wp_send_json_error( array( 'message' => __( 'Sorry, Your Booked Schedule is under processing wait for Admin Approval!!', 'academy-pro' ) ) );
				}
			}
		}
		$seat_limit = (int) get_post_meta( $booking_id, '_academy_booking_seat_limit', true );
		$total_booked = Helper::get_total_booked_schedule( $booking_id, $schedule_date_time );
		if ( ! empty( $seat_limit ) && $seat_limit <= $total_booked ) {
			wp_send_json_error( array( 'message' => __( 'Sorry, This Booking schedule has reached capacity', 'academy-pro' ) ) );
		}
		// Run booking process
		if ( 'paid' === $booking_type ) {
			$engine = \Academy\Helper::get_settings( 'monetization_engine' );
			if ( \Academy\Helper::is_active_woocommerce() && 'woocommerce' === $engine ) {
				global $woocommerce;
				$product_id = Helper::get_booked_product_id( $booking_id );
				$woocommerce->cart->add_to_cart( $product_id, 1, 0, array(), array( 'booked_schedule_date_time' => $schedule_date_time ) );
				wp_send_json_success(array(
					'message' => __( 'Congratulations, successfully Added to cart and redirecting...', 'academy-pro' ),
					'booking_type'   => $booking_type,
					'redirect_url' => esc_url( wc_get_checkout_url() )
				));
			} elseif ( 'storeengine' === $engine && \Academy\Helper::is_plugin_active( 'storeengine/storeengine.php' ) ) {
				$price_id = apply_filters('academy_pro_booking/storeengine/get_product_price', array(
					'booked_schedule_date_time' => $schedule_date_time,
					'user_id'                   => $user_id
				), $booking_id );
				if ( ! $price_id ) {
					wp_send_json_error( array(
						'message' => __( 'Price not found for this product', 'academy-pro' ),
					));
				}
				$cart = storeengine_cart();
				$cart->clear_cart();
				$cart->add_product_to_cart( (int) $price_id, 1, 0, [], [
					'academy_pro_tutor_booking_id' => $booking_id,
				] );

				wp_send_json_success(array(
					'message' => __( 'Congratulations, successfully Added to cart and redirecting...', 'academy-pro' ),
					'booking_type'   => $booking_type,
					'redirect_url' => esc_url( \StoreEngine\Utils\Helper::get_checkout_url() ),
				));
			} elseif ( 'woocommerce' !== $engine && \Academy\Helper::is_plugin_active( 'surecart/surecart.php' ) && \Academy\Helper::get_addon_active_status( 'surecart' ) ) {
				$price_id = apply_filters( 'academy_pro/single_booking/get_product_price', array(
					'booked_schedule_date_time' => $schedule_date_time,
					'user_id'                   => $user_id
				), $booking_id );
				wp_send_json_success( array(
					'message'      => __( 'Congratulations, successfully Added to cart and redirecting..', 'academy-pro' ),
					'book_type'    => $booking_type,
					'redirect_url' => esc_url( add_query_arg(
						[
							'line_items' => [
								[
									'price_id' => $price_id,
									'quantity' => 1,
								],
							],
						],
						\SureCart::pages()->url( 'checkout' )
					) ),
				) );
			}//end if
			// end if
			wp_send_json_error( array( 'message' => __( 'Sorry, Failed to booked!!', 'academy-pro' ) ) );
		} else {
			$is_booked = Helper::do_booked( $booking_id, $user_id, $schedule_date_time );
			if ( $is_booked ) {
				wp_send_json_success(array(
					'message' => __( 'Congratulations, successfully booked.', 'academy-pro' ),
					'booking_type'   => $booking_type,
					'redirect_url' => esc_url( get_the_permalink( $booking_id ) )
				));
			}
		}//end if

		wp_send_json_error( array( 'message' => __( 'Sorry, Failed to booked!!', 'academy-pro' ) ) );
	}

	public function get_my_booking() {
		check_ajax_referer( 'academy_nonce', 'security' );
		$user_id = get_current_user_id();

		$args = array(
			'post_type'      => 'academy_booked',
			'post_status'    => 'completed',
			'numberposts'    => 100,
			'author'         => $user_id
		);

		$response = array();
		$my_booked = get_posts( $args );
		foreach ( $my_booked as $booked_item ) {
			$response[] = Helper::prepare_booked_response( $booked_item );
		}
		wp_send_json_success( $response );
	}

	public function get_booking() {
		check_ajax_referer( 'academy_nonce', 'security' );
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.MissingUnslash 
		$booking_id = ( isset( $_POST['booking_id'] ) ? sanitize_text_field( $_POST['booking_id'] ) : '' );
		$user_id = (int) get_current_user_id();

		$my_booked = get_posts( array(
			'post_type'      => 'academy_booked',
			'post_status'    => 'completed',
			'post_parent'    => $booking_id,
		) );

		$response = array();
		foreach ( $my_booked as $booked_item ) {

			if ( (int) $booked_item->post_author === $user_id ) {
				$response[] = Helper::prepare_booked_response( $booked_item );
			}
		}
		wp_send_json_success( $response );
	}

	public function get_booked_schedule_details() {
		check_ajax_referer( 'academy_nonce', 'security' );

		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotValidated, WordPress.Security.ValidatedSanitizedInput.MissingUnslash 
		$booking_id = (int) sanitize_text_field( $_POST['booking_id'] );

		// Only expose a booking's order details to the user who owns that booking.
		$booked = get_post( $booking_id );
		if ( ! $booked || 'academy_booked' !== $booked->post_type || get_current_user_id() !== (int) $booked->post_author ) {
			wp_send_json_error( __( 'Sorry, you are not allowed to view this booking.', 'academy-pro' ) );
		}

		$order_id = get_post_meta( $booking_id, '_academy_booked_by_order_id', true );

		$response = [];

		$user = get_user_by( 'id', get_current_user_id() );
		$first_name = $user->first_name;
		$last_name = $user->last_name;
		$full_name = $first_name . ' ' . $last_name;
		$email_address = $user->user_email;

		$response = array(
			'first_name' => $first_name,
			'last_name' => $last_name,
			'full_name' => $full_name,
			'email_address' => $email_address,
		);

		if ( $order_id && \Academy\Helper::is_active_woocommerce() ) {
			$order = wc_get_order( $order_id );
			$response['payment_method'] = $order->get_payment_method_title();
			$response['payment_status'] = $order->get_status();
		}

		wp_send_json_success( $response );
	}

	public function archive_booking_filter() {
		check_ajax_referer( 'academy_nonce', 'security' );

		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.MissingUnslash 
		$search   = ( isset( $_POST['search'] ) ? sanitize_text_field( $_POST['search'] ) : '' );
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.MissingUnslash 
		$category = ( isset( $_POST['category'] ) ? \Academy\Helper::sanitize_text_or_array_field( $_POST['category'] ) : [] );
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.MissingUnslash 
		$tags     = ( isset( $_POST['tags'] ) ? \Academy\Helper::sanitize_text_or_array_field( $_POST['tags'] ) : [] );
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.MissingUnslash 
		$levels   = ( isset( $_POST['levels'] ) ? \Academy\Helper::sanitize_text_or_array_field( $_POST['levels'] ) : [] );
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.MissingUnslash 
		$type     = ( isset( $_POST['type'] ) ? \Academy\Helper::sanitize_text_or_array_field( $_POST['type'] ) : [] );
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.MissingUnslash 
		$classType     = ( isset( $_POST['classType'] ) ? \Academy\Helper::sanitize_text_or_array_field( $_POST['classType'] ) : [] );
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.MissingUnslash 
		$orderby  = ( isset( $_POST['orderby'] ) ? sanitize_text_field( $_POST['orderby'] ) : '' );
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.MissingUnslash 
		$paged    = ( isset( $_POST['paged'] ) ) ? absint( $_POST['paged'] ) : 1;

		$args = \AcademyProTutorBooking\Helper::prepare_booking_search_query_args(
			[
				'search'         => $search,
				'category'       => $category,
				'tags'           => $tags,
				'levels'         => $levels,
				'type'           => $type,
				'classType'      => $classType,
				'paged'          => $paged,
				'orderby'        => $orderby,
				'posts_per_page' => (int) \Academy\Helper::get_customizer_settings( 'course_per_page', 12 ),
			]
		);

		$courses = new \WP_Query( $args );
		ob_start();
		?>
		<div class="academy-row">
				<?php
				if ( $courses->have_posts() ) :
					while ( $courses->have_posts() ) :
						$courses->the_post();
						\AcademyPro\Helper::get_template_part( 'booking/content', 'booking' );
				endwhile;

					// phpcs:ignore WordPress.WP.DiscouragedFunctions.wp_reset_query_wp_reset_query 
					wp_reset_query(); else :
						?>
			<div class='academy-mybooking'>
				<h3 class='academy-not-found'><?php esc_html_e( 'Sorry no tutor found.', 'academy-pro' ); ?>
				</h3>
			</div>
				<?php endif; ?>
		</div>
		<?php
		$markup = ob_get_clean();
		wp_send_json_success(
			[
				'markup'      => $markup,
				'found_posts' => $courses->found_posts,
			]
		);
		wp_die();
	}
	public function cancel_booked_schedule() {
		check_ajax_referer( 'academy_nonce', 'security' );
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotValidated, WordPress.Security.ValidatedSanitizedInput.MissingUnslash 
		$booked_id = (int) sanitize_text_field( $_POST['booked_id'] );

		// Verify the booking belongs to the current user (from the record, not a
		// caller-supplied user_id) before cancelling — otherwise any user could
		// cancel another user's booking by supplying its booked_id.
		$booked = get_post( $booked_id );
		if ( ! $booked || 'academy_booked' !== $booked->post_type || get_current_user_id() !== (int) $booked->post_author ) {
			wp_send_json_error( __( 'Sorry, you have no permission to cancel appointment', 'academy-pro' ) );
		}

		// Self-service cancellation is opt-in: admin enables it per booking via
		// the "Allow Cancel" setting on the booking's edit screen (registered
		// meta default is false).
		$is_cancel_allowed = get_post_meta( $booked->post_parent, '_academy_booking_allow_cancel', true );
		if ( ! $is_cancel_allowed ) {
			wp_send_json_error( __( 'Sorry, cancellation is not allowed for this booking.', 'academy-pro' ) );
		}

		$is_update = wp_update_post( array(
			'ID'        => $booked_id,
			'post_status'   => 'cancel',
		), true, true );

		// Lets the Email/Notifications addons send their own cancel
		// confirmation without this endpoint knowing anything about them —
		// same pattern as `academy_pro/booking/after_booked`.
		do_action( 'academy_pro/booking/after_cancelled', (int) $booked->post_parent, $booked_id, get_current_user_id() );

		wp_send_json_success( $is_update );
	}

	public function reschedule_booked_schedule() {
		check_ajax_referer( 'academy_nonce', 'security' );
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotValidated, WordPress.Security.ValidatedSanitizedInput.MissingUnslash
		$booked_id = (int) sanitize_text_field( $_POST['booked_id'] );
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotValidated, WordPress.Security.ValidatedSanitizedInput.MissingUnslash
		$selected_date = (string) sanitize_text_field( $_POST['selectedDate'] );
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotValidated, WordPress.Security.ValidatedSanitizedInput.MissingUnslash
		$selected_time_slot = (string) sanitize_text_field( $_POST['selectedTimeSlot'] );

		// Only the booking's owner may reschedule it (same ownership check as cancel).
		$booked = get_post( $booked_id );
		if ( ! $booked || 'academy_booked' !== $booked->post_type || get_current_user_id() !== (int) $booked->post_author ) {
			wp_send_json_error( __( 'Sorry, you have no permission to reschedule this appointment', 'academy-pro' ) );
		}

		$booking_id = (int) $booked->post_parent;

		// Self-service reschedule is opt-in: admin enables it per booking via
		// the "Allow Re-schedule" setting on the booking's edit screen.
		$is_reschedule_allowed = get_post_meta( $booking_id, '_academy_booking_allow_reschedule', true );
		if ( ! $is_reschedule_allowed ) {
			wp_send_json_error( __( 'Sorry, rescheduling is not allowed for this booking.', 'academy-pro' ) );
		}

		// Reuse the timezone the booking was originally made in — reschedule
		// only moves the date/time, not the timezone context the student
		// already agreed to.
		$existing_schedule = (string) get_post_meta( $booked_id, '_academy_booked_schedule_time', true );
		$existing_parts    = explode( ' ', $existing_schedule );
		$time_zone         = $existing_parts[3] ?? get_post_meta( $booking_id, '_academy_booking_schedule_time_zone', true );

		$duration      = (int) get_post_meta( $booking_id, '_academy_booking_duration', true );
		$schedule_type = get_post_meta( $booking_id, '_academy_booking_schedule_type', true );
		$slot_is_valid = false;

		if ( 'single' === $schedule_type ) {
			$schedule_time = get_post_meta( $booking_id, '_academy_booking_schedule_time', true );
			if ( is_array( $schedule_time ) && ( $schedule_time['date'] ?? '' ) === $selected_date ) {
				$slot_is_valid = self::is_slot_within_range( $selected_time_slot, $schedule_time['start_time'] ?? '', $schedule_time['end_time'] ?? '', $duration );
			}
		} elseif ( 'repeated' === $schedule_type ) {
			$repeated_times = get_post_meta( $booking_id, '_academy_booking_schedule_repeated_times', true );
			$weekday        = strtolower( gmdate( 'l', strtotime( $selected_date ) ) );
			if ( is_array( $repeated_times ) ) {
				foreach ( $repeated_times as $day_item ) {
					if ( strtolower( $day_item['day'] ?? '' ) !== $weekday ) {
						continue;
					}
					foreach ( (array) ( $day_item['scheduleTimes'] ?? array() ) as $range ) {
						if ( self::is_slot_within_range( $selected_time_slot, $range['start_time'] ?? '', $range['end_time'] ?? '', $duration ) ) {
							$slot_is_valid = true;
							break 2;
						}
					}
				}
			}
		}//end if

		if ( ! $slot_is_valid ) {
			wp_send_json_error( __( 'Sorry, the selected slot is not available for this booking.', 'academy-pro' ) );
		}

		$schedule_date_time = $selected_date . ' ' . $selected_time_slot . ' ' . $time_zone;

		// Same "already booked" / capacity checks used at initial booking time.
		// Excludes $booked_id itself: it still carries its old slot at this
		// point (the meta update happens below), so without the exclusion a
		// no-op reschedule — or moving a "single" booking, which only ever has
		// the one valid slot — would always flag itself as the conflict.
		if ( Helper::booking_schedule_already_booked( $schedule_date_time, get_current_user_id(), $booked_id ) ) {
			wp_send_json_error( __( 'Sorry, you already have a booking at this slot.', 'academy-pro' ) );
		}

		$seat_limit   = (int) get_post_meta( $booking_id, '_academy_booking_seat_limit', true );
		$total_booked = Helper::get_total_booked_schedule( $booking_id, $schedule_date_time, $booked_id );
		if ( ! empty( $seat_limit ) && $seat_limit <= $total_booked ) {
			wp_send_json_error( __( 'Sorry, this slot has reached capacity.', 'academy-pro' ) );
		}

		update_post_meta( $booked_id, '_academy_booked_schedule_time', $schedule_date_time );

		// Lets the Email/Notifications addons send their own reschedule
		// confirmation without this endpoint knowing anything about them —
		// same pattern as `academy_pro/booking/after_booked`. $existing_schedule
		// (captured above, before the meta update) is the old slot, in case a
		// listener wants to show "moved from X to Y".
		do_action( 'academy_pro/booking/after_rescheduled', $booking_id, $booked_id, get_current_user_id(), $existing_schedule, $schedule_date_time );

		wp_send_json_success( array( 'schedule_time' => $schedule_date_time ) );
	}

	/**
	 * Whether a "h:mm A" slot starting at $slot_start fits inside the
	 * [$range_start, $range_end) window and aligns to a $duration-minute
	 * boundary — i.e. is one of the slots the admin's configured range would
	 * actually generate, not an arbitrary time the client made up.
	 *
	 * @param mixed $slot_start
	 * @param mixed $range_start
	 * @param mixed $range_end
	 * @param mixed $duration
	 */
	private static function is_slot_within_range( $slot_start, $range_start, $range_end, $duration ) {
		if ( empty( $slot_start ) || empty( $range_start ) || empty( $range_end ) || empty( $duration ) ) {
			return false;
		}
		$base     = '2000-01-01 ';
		$slot_dt  = DateTime::createFromFormat( 'Y-m-d h:i A', $base . $slot_start );
		$start_dt = DateTime::createFromFormat( 'Y-m-d h:i A', $base . $range_start );
		$end_dt   = DateTime::createFromFormat( 'Y-m-d h:i A', $base . $range_end );
		if ( ! $slot_dt || ! $start_dt || ! $end_dt ) {
			return false;
		}
		$slot_end_dt = ( clone $slot_dt )->modify( "+{$duration} minutes" );
		if ( $slot_dt < $start_dt || $slot_end_dt > $end_dt ) {
			return false;
		}
		$diff_minutes = ( $slot_dt->getTimestamp() - $start_dt->getTimestamp() ) / 60;
		return 0 === ( (int) $diff_minutes % (int) $duration );
	}

	public function render_booking() {
		check_ajax_referer( 'academy_nonce', 'security' );
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotValidated, WordPress.Security.ValidatedSanitizedInput.MissingUnslash 
		$course_id = (int) sanitize_text_field( $_POST['course_id'] );
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotValidated, WordPress.Security.ValidatedSanitizedInput.MissingUnslash 
		$booking_id = sanitize_text_field( $_POST['booking_id'] );
		$booking = get_post( $booking_id );

		$has_permission = \Academy\Helper::has_permission_to_access_curriculum( $course_id, get_current_user_id(), $booking_id, 'booking' );

		if ( $has_permission ) {
			if ( ! $booking ) {
				wp_send_json_error( esc_html__( 'Sorry, something went wrong!', 'academy-pro' ) );
			}

			do_action( 'academy_pro_tutor_booking/frontend/before_render_booking', $course_id, $booking_id );

			$response = [
				'ID' => $booking_id,
				'settings' => \AcademyProTutorBooking\Helper::get_booking_calendar_settings( $booking_id ),
			];
			wp_send_json_success( $response );
		}
		wp_send_json_error( __( 'Access Denied', 'academy-pro' ) );
	}

	public function mark_booking_complete( $topic_type, $course_id, $topic_id, $user_id ) {
		if ( 'booking' === $topic_type && ! \AcademyProTutorBooking\Helper::has_booking_booked( $topic_id, $user_id ) ) {
			if ( \Academy\Helper::is_server_learn_page() ) {
				$referer_url = \Academy\Helper::sanitize_referer_url( wp_get_referer() );
				wp_safe_redirect( $referer_url );
				exit;
			}
			wp_send_json_error( __( 'Complete the Booking before marking it as done.', 'academy-pro' ) );
		}
	}
}
