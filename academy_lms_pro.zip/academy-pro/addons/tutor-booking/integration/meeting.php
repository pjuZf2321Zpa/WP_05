<?php
namespace AcademyProTutorBooking\Integration;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Bridges a confirmed tutor booking to an auto-created Zoom / Google Meet event.
 *
 * A booking can opt into a meeting provider (`_academy_booking_meeting_provider`).
 * When a student's slot is CONFIRMED — free bookings immediately, paid bookings
 * once the order completes — we create the meeting with the instructor's
 * credentials and store the join link on the `academy_booked` record so it can
 * be shown in the student's "Meeting Details".
 */
class Meeting {

	public static function init() {
		$self = new self();
		// Free bookings: after_booked fires with the record already `completed`.
		add_action( 'academy_pro/booking/after_booked', array( $self, 'on_after_booked' ), 20, 3 );
		// Paid bookings: fired by the Woo integration once the order completes.
		add_action( 'academy_pro/booking/booked_status_changed', array( $self, 'on_status_changed' ), 20, 2 );
	}

	public function on_after_booked( $booking_id, $booked_id, $user_id ) {
		self::maybe_create_for_booked( (int) $booked_id );
	}

	public function on_status_changed( $booked_id, $status_to ) {
		if ( 'completed' === $status_to ) {
			self::maybe_create_for_booked( (int) $booked_id );
		}
	}

	/**
	 * Create the meeting for a booked slot if eligible. Idempotent: only runs
	 * once per booked record, only when confirmed, and only if the booking has
	 * a provider set and the meeting addon is available.
	 *
	 * @param int $booked_id
	 */
	public static function maybe_create_for_booked( $booked_id ) {
		if ( ! class_exists( '\AcademyProMeeting\Integration\Zoom' ) ) {
			return; // meeting addon inactive
		}

		$booked = get_post( $booked_id );
		if ( ! $booked || 'academy_booked' !== $booked->post_type ) {
			return;
		}
		if ( 'completed' !== $booked->post_status ) {
			return; // wait until the booking is confirmed / paid
		}
		if ( get_post_meta( $booked_id, '_academy_booked_meeting_join_url', true ) ) {
			return; // already created
		}

		$booking_id = (int) $booked->post_parent;
		$provider   = get_post_meta( $booking_id, '_academy_booking_meeting_provider', true );
		if ( ! in_array( $provider, array( 'zoom', 'google_meet' ), true ) ) {
			return;
		}

		$instructor_id = (int) get_post_field( 'post_author', $booking_id );
		$schedule      = (string) get_post_meta( $booked_id, '_academy_booked_schedule_time', true );

		$parsed = \AcademyProTutorBooking\Helper::parse_booked_schedule_datetime( $schedule );
		if ( ! $parsed ) {
			return;
		}
		$date = $parsed->format( 'Y-m-d' );
		$time = $parsed->format( 'H:i' );

		$duration = (int) get_post_meta( $booking_id, '_academy_booking_duration', true );
		$duration = $duration > 0 ? $duration : 30;
		$timezone = (string) get_post_meta( $booking_id, '_academy_booking_schedule_time_zone', true );
		if ( ! $timezone ) {
			$timezone = wp_timezone_string();
		}
		$title = get_the_title( $booking_id );

		$result = null;
		if ( 'zoom' === $provider ) {
			$result = \AcademyProMeeting\Integration\Zoom::create_meeting_service( $instructor_id, array(
				'title'         => $title,
				'description'   => '',
				'date'          => $date,
				'time'          => $time,
				'duration'      => $duration,
				'duration_unit' => 'minute',
				'timezone'      => $timezone,
				'password'      => '',
			) );
		} elseif ( 'google_meet' === $provider && class_exists( '\AcademyProMeeting\Integration\GoogleMeet' ) ) {
			try {
				$tz    = new \DateTimeZone( $timezone );
				$start = new \DateTime( $date . ' ' . $time, $tz );
				$end   = clone $start;
				$end->modify( '+' . $duration . ' minutes' );
			} catch ( \Exception $e ) {
				return;
			}
			$result = \AcademyProMeeting\Integration\GoogleMeet::create_meeting_service( $instructor_id, array(
				'title'      => $title,
				'description' => '',
				'start_date' => $start->format( 'Y-m-d H:i:s' ),
				'end_date'   => $end->format( 'Y-m-d H:i:s' ),
				'timezone'   => $timezone,
			) );
		}//end if

		if ( is_wp_error( $result ) || empty( $result['join_url'] ) ) {
			update_post_meta(
				$booked_id,
				'_academy_booked_meeting_error',
				is_wp_error( $result ) ? $result->get_error_message() : __( 'Could not create the meeting.', 'academy-pro' )
			);
			return;
		}

		update_post_meta( $booked_id, '_academy_booked_meeting_provider', $provider );
		update_post_meta( $booked_id, '_academy_booked_meeting_join_url', esc_url_raw( $result['join_url'] ) );
		update_post_meta( $booked_id, '_academy_booked_meeting_id', (int) $result['post_id'] );
		delete_post_meta( $booked_id, '_academy_booked_meeting_error' );

		do_action( 'academy_pro/booking/meeting_created', $booked_id, $booking_id, $result );
	}
}
