<?php
namespace AcademyProTutorBooking\Admin;

use StoreEngine;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


class Ajax {
	public static function init() {
		$self = new self();
		add_action( 'wp_ajax_academy_pro/booking/admin/get_booked_schedules', array( $self, 'get_booked_schedules' ) );
		add_action( 'wp_ajax_academy_pro/booking/admin/get_booked_schedule_details', array( $self, 'get_booked_schedule_details' ) );
		add_action( 'wp_ajax_academy_pro/booking/admin/delete_booked_schedule', array( $self, 'delete_booked_schedule' ) );
		add_action( 'wp_ajax_academy_pro/booking/admin/get_meeting_configuration_status', array( $self, 'get_meeting_configuration_status' ) );
	}

	/**
	 * Whether the Meeting addon is on, and whether Zoom / Google Meet have
	 * credentials saved for the given instructor — used by the booking
	 * form's "Auto Meeting" select to warn before a provider is picked that
	 * can't actually create anything at booking time.
	 */
	public function get_meeting_configuration_status() {
		check_ajax_referer( 'academy_nonce', 'security' );

		if ( ! current_user_can( 'manage_academy_instructor' ) ) {
			wp_die();
		}

		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.MissingUnslash, WordPress.Security.ValidatedSanitizedInput.InputNotValidated
		$user_id = (int) ( isset( $_POST['user_id'] ) ? sanitize_text_field( $_POST['user_id'] ) : get_current_user_id() );

		$addon_active = \Academy\Helper::get_addon_active_status( 'meeting', true );

		wp_send_json_success(
			array(
				'addon_active'    => $addon_active,
				'zoom'            => $addon_active && class_exists( '\AcademyProMeeting\Integration\Zoom' )
					? \AcademyProMeeting\Integration\Zoom::is_configured( $user_id )
					: false,
				'google_meet'     => $addon_active && class_exists( '\AcademyProMeeting\Integration\GoogleMeet' )
					? \AcademyProMeeting\Integration\GoogleMeet::is_configured( $user_id )
					: false,
			)
		);
	}


	public function get_booked_schedules() {
		check_ajax_referer( 'academy_nonce', 'security' );

		if ( ! current_user_can( 'manage_academy_instructor' ) ) {
			wp_die();
		}

		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.MissingUnslash 
		$page = ( isset( $_POST['page'] ) ? sanitize_text_field( $_POST['page'] ) : 1 );
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.MissingUnslash 
		$per_page = ( isset( $_POST['per_page'] ) ? sanitize_text_field( $_POST['per_page'] ) : 10 );
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.MissingUnslash 
		$post_status = ( isset( $_POST['status'] ) ? sanitize_text_field( $_POST['status'] ) : 'any' );
		$offset = ( $page - 1 ) * $per_page;
		$author_id = get_current_user_id();
		$has_manage_options = current_user_can( 'manage_options' );

		// Get all academy_booking posts created by the current instructor
		// phpcs:disable WordPressVIPMinimum.Performance.NoPaging.posts_per_page_posts_per_page -- needs the complete (small, bounded) set
		$args_booking = array(
			'post_type'      => 'academy_booking',
			'post_status'    => $post_status,
			'author'         => $author_id,
			'posts_per_page' => -1,
		);
		// phpcs:enable WordPressVIPMinimum.Performance.NoPaging.posts_per_page_posts_per_page

		$all_bookings = new \WP_Query( $args_booking );
		$booking_ids = count( $all_bookings->posts ) ? wp_list_pluck( $all_bookings->posts, 'ID' ) : array();

		if ( empty( $booking_ids ) && ! $has_manage_options ) {
			header( 'x-wp-total: ' . 0 );
			wp_send_json_success( [] );
		}

		$total_booked = new \WP_Query( array(
			'post_type' => 'academy_booked',
			'post_status' => 'any',
		) );
		wp_reset_postdata();

		// Set the x-wp-total header
		header( 'x-wp-total: ' . $total_booked->found_posts );

		$args = array(
			'post_type' => 'academy_booked',
			'post_status' => $post_status,
			'posts_per_page' => $per_page,
			'offset' => $offset,
		);
		if ( ! $has_manage_options ) {
			$args['post_parent__in'] = $booking_ids;
		}

		$all_booked = get_posts( $args );
		$response = array();
		foreach ( $all_booked as $booked_item ) {
			$response[] = \AcademyProTutorBooking\Helper::prepare_booked_response( $booked_item );
		}
		wp_reset_postdata();
		wp_send_json_success( $response );
	}
	public function get_booked_schedule_details() {
		check_ajax_referer( 'academy_nonce', 'security' );

		if ( ! current_user_can( 'manage_academy_instructor' ) ) {
			wp_die();
		}

		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.MissingUnslash, WordPress.Security.ValidatedSanitizedInput.InputNotValidated 	
		$user_id = sanitize_text_field( $_POST['user_id'] );
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.MissingUnslash, WordPress.Security.ValidatedSanitizedInput.InputNotValidated 	
		$booking_id = sanitize_text_field( $_POST['booking_id'] );
		$order_id = get_post_meta( $booking_id, '_academy_booked_by_order_id', true );

		$user = get_user_by( 'id', $user_id );
		$first_name = $user->first_name;
		$last_name = $user->last_name;
		$full_name = $first_name . ' ' . $last_name;
		$email_address = $user->user_email;

		$response = array(
			'first_name'     => $first_name,
			'last_name'      => $last_name,
			'full_name'      => $full_name,
			'email_address'  => $email_address,
			'payment_method' => '',
			'payment_status' => '',
			'order_details'  => '',
		);

		if ( $order_id ) {
			$monetize_engine = \Academy\Helper::monetization_engine();
			if ( 'woocommerce' === $monetize_engine && \Academy\Helper::is_active_woocommerce() ) {
				$order = \wc_get_order( $order_id );
				$response['payment_method'] = \wc_get_payment_gateway_by_order( $order )->get_title();
				$response['payment_status'] = $order->get_status();
			} elseif ( 'storeengine' === $monetize_engine && class_exists( \StoreEngine::class ) ) {
				try {
					$order = storeengine_get_order( (int) $order_id );
					$response['payment_method'] = $order->get_payment_method_title();
					$response['payment_status'] = $order->get_status();
					$response['order_details']  = $order->get_edit_order_url();
				} catch ( StoreEngine\Classes\Exceptions\StoreEngineException $e ) {// phpcs:ignore Generic.CodeAnalysis.EmptyStatement.DetectedCatch
					// phpcs:ignore Generic.CodeAnalysis.EmptyStatement.DetectedCatch
				}
			}
		}

		wp_send_json_success( $response );
	}
	public function delete_booked_schedule() {
		check_ajax_referer( 'academy_nonce', 'security' );

		if ( ! current_user_can( 'manage_academy_instructor' ) ) {
			wp_die();
		}

		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.MissingUnslash, WordPress.Security.ValidatedSanitizedInput.InputNotValidated
		$booked_id = (int) sanitize_text_field( $_POST['booked_id'] );

		// Scope deletion to the tutor who owns the parent booking, so an instructor
		// cannot force-delete another instructor's booked schedules by ID.
		$booked = get_post( $booked_id );
		if ( ! $booked || 'academy_booked' !== $booked->post_type ) {
			wp_send_json_error( __( 'Invalid booking.', 'academy-pro' ) );
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			$booking = get_post( $booked->post_parent );
			if ( ! $booking || get_current_user_id() !== (int) $booking->post_author ) {
				wp_send_json_error( __( 'Sorry, you are not allowed to delete this booking.', 'academy-pro' ) );
			}
		}

		wp_delete_post( $booked_id, true );

		wp_send_json_success( $booked_id );
	}
}
