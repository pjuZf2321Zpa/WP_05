<?php
namespace AcademyProTutorBooking\Admin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


class Settings {

	public static function init() {
		$self = new self();
		add_filter( 'academy/admin/settings/base_default_data', array( $self, 'set_settings_default_data' ), 11, 1 );
		add_filter( 'academy/admin/settings/sanitize_payload', array( $self, 'sanitize_settings_data' ) );
		add_filter( 'academy/admin/settings/save', array( $self, 'save_settings_data' ), 11, 3 );
	}

	public function set_settings_default_data( $default_settings ) {
		$default_tutor_settings = array(
			'tutor_booking_page' => '',
			'tutor_booking_archive_sidebar_position' => 'right',
			'tutor_booking_archive_filters' => [
				[
					'search'   => true,
				],
				[
					'category'   => true,
				],
				[
					'tags'   => true,
				],
				[
					'type'   => true,
				],
				[
					'class_type'   => true,
				],
			],
			'tutor_booking_archive_booking_per_row' => array(
				'desktop' => 3,
				'tablet'  => 2,
				'mobile'  => 1,
			),
			'tutor_booking_archive_booking_per_page' => 12,
			'tutor_booking_archive_booking_order' => 'DESC',
			'tutor_booking_card_style' => 'default',
		);
		$default_settings = array_merge( $default_settings, $default_tutor_settings );
		return $default_settings;
	}

	public function sanitize_settings_data( $sanitize_rules ) {
		$sanitize_rules['tutor_booking_page']                       = 'integer';
		$sanitize_rules['tutor_booking_archive_booking_per_page']   = 'integer';
		$sanitize_rules['tutor_booking_archive_booking_order']      = 'string';
		$sanitize_rules['tutor_booking_archive_booking_per_row']    = 'array';
		$sanitize_rules['tutor_booking_archive_filters']   = 'json';
		$sanitize_rules['tutor_booking_archive_sidebar_position']   = 'string';
		$sanitize_rules['tutor_booking_archive_booking_order']   = 'string';
		return $sanitize_rules;
	}

	public function save_settings_data( $data, $payload, $default ) {
		$data['tutor_booking_page'] = $payload['tutor_booking_page'] ?? $default['tutor_booking_page'];
		$data['tutor_booking_archive_booking_per_page'] = $payload['tutor_booking_archive_booking_per_page'] ?? $default['tutor_booking_archive_booking_per_page'];
		$data['tutor_booking_archive_booking_order']    = $payload['tutor_booking_archive_booking_order'] ?? $default['tutor_booking_archive_booking_order'];
		$data['tutor_booking_archive_booking_per_row']  = $payload['tutor_booking_archive_booking_per_row'] ?? $default['tutor_booking_archive_booking_per_row'];
		$data['tutor_booking_archive_filters'] = $payload['tutor_booking_archive_filters'] ?? $default['tutor_booking_archive_filters'];
		$data['tutor_booking_archive_sidebar_position'] = $payload['tutor_booking_archive_sidebar_position'] ?? $default['tutor_booking_archive_sidebar_position'];
		$data['tutor_booking_archive_booking_order'] = $payload['tutor_booking_archive_booking_order'] ?? $default['tutor_booking_archive_booking_order'];
		return $data;
	}
}
