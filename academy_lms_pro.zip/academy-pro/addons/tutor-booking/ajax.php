<?php
namespace AcademyProTutorBooking;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AcademyProTutorBooking\Admin\Woocommerce;

class Ajax {
	public static function init() {
		$self = new self();
		$self->init_frontend_request();
		$self->init_admin_request();
		$self->dispatch_hooks();
	}

	public function init_admin_request() {
		Admin\Ajax::init();
	}
	public function init_frontend_request() {
		Frontend\Ajax::init();
	}
	public function dispatch_hooks() {
		( new Woocommerce() )->dispatch_actions();
	}
}
