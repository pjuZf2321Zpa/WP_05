<?php

namespace AcademyProWoocommerceSubscriptions;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
class Subscriptions {
	/**
	 * User ID => that user's subscriptions, for the current request.
	 *
	 * @var array
	 */
	private $user_subscriptions = array();

	public static function init() {
		$self = new self();
		if ( ! class_exists( 'WooCommerce' ) || ! class_exists( 'WC_Subscriptions' ) ) {
			return;
		}
		add_filter( 'academy/course/is_enrolled', array( $self, 'is_user_enrolled' ), 10, 3 );
		add_action( 'woocommerce_subscription_status_updated', array( $self, 'update_enroll_status' ), 10, 3 );
		add_filter( 'academy/templates/frontend-dashboard/course_access_note', array( $self, 'course_access_note' ), 10, 3 );
		add_action( 'academy/templates/after_course_loop_content_inner', array( $self, 'render_loop_access_note' ) );
	}

	/**
	 * Gates access on the subscription's live status, but only once we know
	 * this course was actually bought via a subscription at all — checked by
	 * whether the user holds ANY subscription (any status) containing the
	 * product, not by the product's own is_subscription() type. With "All
	 * Products for WooCommerce Subscriptions" (_wcsatt_* meta), subscribing
	 * is optional per purchase, so the product is never "inherently" a
	 * subscription — is_subscription() on it stays false even for a student
	 * who chose to subscribe (see the matching comment on course_access_note()
	 * below, which hit exactly this while testing against a live wcsatt
	 * product). A student who bought the same product one-time is correctly
	 * left alone: get_course_subscription() finds nothing for them, so
	 * $enrolled_info — whatever the plain enrollment record already says —
	 * passes through untouched.
	 *
	 * Access is kept while any matching subscription is active or
	 * pending-cancel (paid up until its end date). Read through the WC
	 * Subscriptions API rather than a shop_subscription post query, which
	 * finds nothing on HPOS stores and would lock every subscriber out.
	 *
	 * @param mixed $enrolled_info Enrollment record, or false.
	 * @param int   $course_id     Course ID.
	 * @param int   $user_id       User ID.
	 * @return mixed
	 */
	public function is_user_enrolled( $enrolled_info, $course_id, $user_id ) {
		$subscriptions = $this->get_course_subscriptions( $course_id, $user_id );
		if ( ! $subscriptions ) {
			return $enrolled_info;
		}

		foreach ( $subscriptions as $subscription ) {
			if ( $subscription->has_status( array( 'active', 'pending-cancel' ) ) ) {
				return $enrolled_info;
			}
		}
		return false;
	}
	public function update_enroll_status( $wc_subscription, $new_status, $old_status ) {
		$this->user_subscriptions = array();
		$order_id = method_exists( $wc_subscription, 'get_parent_id' ) ? $wc_subscription->get_parent_id() : $wc_subscription->order->id;
		if ( $order_id && \Academy\Helper::is_academy_order( $order_id ) ) {
			// pending-cancel is paid up until its end date; WC Subscriptions
			// moves it to cancelled/expired then, which cancels the enrollment.
			$enroll_status = in_array( $new_status, array( 'active', 'pending-cancel' ), true ) ? 'completed' : 'cancel';
			$enrollments = \Academy\Helper::get_course_enrolled_ids_by_order_id( $order_id );
			if ( is_array( $enrollments ) && count( $enrollments ) ) {
				$ids = array();
				foreach ( $enrollments as $enrollment ) {
					$ids[] = $enrollment['enrolled_id'];
				}
				if ( count( $ids ) ) {
					\Academy\Helper::update_enroll_status_by_course_ids( $enroll_status, $ids );
				}
			}
		}
	}
	public function get_user_subscription( $user_id = 0 ) {
		$query = new \WP_Query();
		// phpcs:disable WordPressVIPMinimum.Performance.NoPaging.posts_per_page_posts_per_page -- needs the complete (small, bounded) set
		$subscription_ids = $query->query( array(
			'post_type'           => 'shop_subscription',
			'posts_per_page'      => -1,
			'post_status'         => 'wc-active',
			'orderby'             => array(
				'date' => 'DESC',
				'ID'   => 'DESC',
			),
			'fields'              => 'ids',
			'no_found_rows'       => true,
			'ignore_sticky_posts' => true,
			// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
			'meta_query'          => array(
				array(
					'key'   => '_customer_user',
					'value' => $user_id,
				),
			),
		) );
		// phpcs:enable WordPressVIPMinimum.Performance.NoPaging.posts_per_page_posts_per_page

		$results = array();
		foreach ( $subscription_ids as $subscription_id ) {
			$subscription = \wcs_get_subscription( $subscription_id );
			if ( $subscription ) {
				$results[ $subscription_id ] = $subscription;
			}
		}
		return $results;
	}

	/**
	 * Every subscription (any status) this user holds that contains the
	 * course's product. Memoised per request (is_user_enrolled() runs for
	 * each course on list pages); a status change clears it.
	 *
	 * @param int $course_id Course ID.
	 * @param int $user_id   User ID.
	 * @return \WC_Subscription[]
	 */
	private function get_course_subscriptions( $course_id, $user_id ) {
		$user_id    = absint( $user_id );
		$product_id = \Academy\Helper::get_course_product_id( $course_id );
		// wcs_get_users_subscriptions( 0 ) falls back to the current user.
		if ( ! $user_id || ! $product_id || ! function_exists( 'wcs_get_users_subscriptions' ) ) {
			return array();
		}

		if ( ! isset( $this->user_subscriptions[ $user_id ] ) ) {
			$this->user_subscriptions[ $user_id ] = wcs_get_users_subscriptions( $user_id );
		}

		$matches = array();
		foreach ( $this->user_subscriptions[ $user_id ] as $subscription ) {
			if ( $subscription->has_product( $product_id ) ) {
				$matches[] = $subscription;
			}
		}
		return $matches;
	}

	/**
	 * The subscription (of any status, not just active — unlike
	 * get_user_subscription() above, which is_user_enrolled() deliberately
	 * limits to 'wc-active' for the access gate) covering this course for
	 * this user. Picks the active one when there is one, otherwise the most
	 * recently created, so course_access_note() has something to report an
	 * end date from even once a subscription has lapsed.
	 *
	 * @param int $course_id
	 * @param int $user_id
	 * @return \WC_Subscription|null
	 */
	private function get_course_subscription( $course_id, $user_id ) {
		$matches = $this->get_course_subscriptions( $course_id, $user_id );
		if ( ! $matches ) {
			return null;
		}

		foreach ( $matches as $subscription ) {
			if ( $subscription->has_status( 'active' ) ) {
				return $subscription;
			}
		}

		usort(
			$matches,
			static function ( $a, $b ) {
				return strcmp( $b->get_date( 'date_created' ), $a->get_date( 'date_created' ) );
			}
		);

		return reset( $matches );
	}

	/**
	 * Fills the dashboard course-card "access note" (see the matching
	 * comment in enrolled-courses.php) for a course sold as a WooCommerce
	 * Subscription — a renewal or expiry date that is_user_enrolled() above
	 * never surfaces, since it only ever checks the subscription's status,
	 * never a date.
	 *
	 * Deliberately does NOT gate on the product's own type/is_subscription()
	 * first (unlike is_user_enrolled() above): with "All Products for
	 * WooCommerce Subscriptions" (the _wcsatt_* product meta), subscribing is
	 * optional per purchase, so the product itself is never "inherently" a
	 * subscription — is_subscription() on it stays false even for a student
	 * who chose to subscribe. Whether THIS student has a real subscription is
	 * exactly what get_course_subscription() below already answers, so that
	 * alone is both the necessary and sufficient check.
	 *
	 * @param string $note      Empty unless an earlier filter already set one.
	 * @param int    $course_id
	 * @param int    $user_id
	 * @return string
	 */
	public function course_access_note( $note, $course_id, $user_id ) {
		$product_id = \Academy\Helper::get_course_product_id( $course_id );
		if ( ! $product_id ) {
			return $note;
		}

		$subscription = $this->get_course_subscription( $course_id, $user_id );
		if ( ! $subscription ) {
			return $note;
		}

		// A still-renewing subscription has a next_payment date; one that's
		// cancelled, pending-cancel, expired, or on-hold does not (WC
		// Subscriptions clears it), so falling back to the end date covers
		// all of those in one go instead of branching on status.
		$next_payment = $subscription->get_date( 'next_payment' );
		if ( $next_payment ) {
			return sprintf(
				/* translators: %s: next renewal date */
				__( 'Renews on %s', 'academy-pro' ),
				date_i18n( get_option( 'date_format' ), strtotime( $next_payment ) )
			);
		}

		$end = $subscription->get_date( 'end' );
		if ( $end ) {
			return sprintf(
				/* translators: %s: date access ends */
				__( 'Access ends %s', 'academy-pro' ),
				date_i18n( get_option( 'date_format' ), strtotime( $end ) )
			);
		}

		return $note;
	}

	/**
	 * Same note as course_access_note(), rendered directly onto a course card
	 * in the course archive/grid (templates/loop/content.php, via its
	 * academy/templates/after_course_loop_content_inner hook) — that template
	 * doesn't go through a filter that returns a value to place, so this
	 * echoes markup instead. Only ever prints something for a logged-in
	 * viewer with a real subscription on the card's own course; empty for
	 * every other card and every anonymous visitor.
	 */
	public function render_loop_access_note() {
		$user_id = get_current_user_id();
		if ( ! $user_id ) {
			return;
		}

		$course_id = get_the_ID();
		if ( ! $course_id ) {
			return;
		}

		$note = $this->course_access_note( '', $course_id, $user_id );
		if ( ! $note ) {
			return;
		}

		printf(
			'<p class="academy-course__meta academy-course__access-note"><i class="academy-icon academy-icon--clock" aria-hidden="true"></i> %s</p>',
			esc_html( $note )
		);
	}
}
