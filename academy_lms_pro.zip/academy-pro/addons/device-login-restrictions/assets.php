<?php
namespace AcademyProDeviceLoginRestrictions;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Assets {
	public static function init() {
		$enqueue = function () {
			wp_enqueue_script( 'academy_pro_device_login_restrictions', ACADEMY_PRO_PLUGIN_ROOT_URI . 'addons/device-login-restrictions/assets/script.js', array( 'jquery' ), ACADEMY_PRO_DEVICE_LOGIN_RESTRICTIONS_VERSION, true );
			wp_localize_script(
				'academy_pro_device_login_restrictions',
				'academy_pro_device_login_restrictions',
				[
					'ajax_url' => admin_url( 'admin-ajax.php' ),
					'nonce'    => wp_create_nonce( 'academy_nonce' ),
				]
			);
		};

		add_action( 'login_enqueue_scripts', $enqueue );

		add_action( 'wp_enqueue_scripts', function () use ( $enqueue ) {
			if ( ! is_user_logged_in() ) {
				$enqueue();
			}
		} );
	}
}
