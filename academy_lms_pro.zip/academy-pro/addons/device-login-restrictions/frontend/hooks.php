<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// frontend dashboard
add_filter( 'academy/frontend_dashboard_menu_items', 'academy_pro_manage_device_added_frontend_dashboard_menu', 10, 1 );
// device login restriction endpoint
add_action( 'academy_frontend_dashboard_manage-device_endpoint', 'academy_pro_manage_frontend_dashboard_login_device_page' );
