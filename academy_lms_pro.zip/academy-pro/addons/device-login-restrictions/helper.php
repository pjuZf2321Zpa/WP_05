<?php
namespace AcademyProDeviceLoginRestrictions;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Helper {

	public static function get_browser_name() {

		if ( isset( $_SERVER['HTTP_USER_AGENT_CLIENT_HINT'] ) ) {
			$userAgentHints = json_decode( sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT_CLIENT_HINT'] ) ), true );
			if ( isset( $userAgentHints['brand'] ) ) {
				return sanitize_text_field( $userAgentHints['brand'] );
			}
		}

		$userAgent = isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : ''; // phpcs:ignore WordPressVIPMinimum.Variables.RestrictedVariables.cache_constraints___SERVER__HTTP_USER_AGENT__ -- read in AJAX/login handlers only, never in page-cached output

		$browser_name = 'Unknown';

		if ( strpos( $userAgent, 'MSIE' ) !== false || strpos( $userAgent, 'Trident' ) !== false ) {
			$browser_name = 'Internet Explorer';
		} elseif ( strpos( $userAgent, 'Edg' ) !== false ) {
			$browser_name = 'Edge';
		} elseif ( strpos( $userAgent, 'Chrome' ) !== false && strpos( $userAgent, 'Edg' ) === false ) {
			$browser_name = 'Google Chrome';
		} elseif ( strpos( $userAgent, 'Firefox' ) !== false ) {
			$browser_name = 'Mozilla Firefox';
		} elseif ( strpos( $userAgent, 'Safari' ) !== false && strpos( $userAgent, 'Chrome' ) === false ) {
			$browser_name = 'Apple Safari';
		} elseif ( strpos( $userAgent, 'Opera' ) !== false || strpos( $userAgent, 'OPR' ) !== false ) {
			$browser_name = 'Opera';
		}

		return $browser_name;
	}

	public static function get_platform() {
		$u_agent = isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : ''; // phpcs:ignore WordPressVIPMinimum.Variables.RestrictedVariables.cache_constraints___SERVER__HTTP_USER_AGENT__ -- read in AJAX/login handlers only, never in page-cached output

		// Always ends with a value: a user agent that matches none of these (Linux
		// desktops, for one) used to leave $platform undefined, and the resulting
		// PHP warning was printed ahead of the login response and broke its JSON.
		$platform = 'Unknown';

		// Real iOS user agents say "iPhone"/"iPad" (and also contain "Mac OS X"),
		// so they have to be checked before Mac.
		if ( false !== stripos( $u_agent, 'iPhone' ) || false !== stripos( $u_agent, 'iPad' ) ) {
			$platform = 'iOS';
		} elseif ( false !== strpos( $u_agent, 'Android' ) ) {
			$platform = 'Android';
		} elseif ( false !== strpos( $u_agent, 'Windows' ) ) {
			$platform = 'Windows';
		} elseif ( false !== strpos( $u_agent, 'Mac' ) ) {
			$platform = 'Mac';
		} elseif ( false !== strpos( $u_agent, 'Linux' ) || false !== strpos( $u_agent, 'X11' ) ) {
			$platform = 'Linux';
		}

		return $platform;
	}

	public static function get_location( $user_ip = '' ) {
		if ( '' === $user_ip ) {
			$user_ip = \AcademyPro\Helper::get_remote_addr();
		}

		$response = filter_var( $user_ip, FILTER_VALIDATE_IP )
			? wp_safe_remote_get( "http://ipinfo.io/{$user_ip}/json", array( 'timeout' => 3 ) )
			: new \WP_Error( 'academy_pro_invalid_ip' );

		if ( is_wp_error( $response ) ) {
			return array(
				'country' => '',
				'city'    => '',
			);
		}

		$details = json_decode( wp_remote_retrieve_body( $response ) );

		$location = array(
			'country' => $details->country ?? '',
			'city'    => $details->city ?? '',
		);

		return $location;
	}

	public static function get_device_type() {
		$u_agent = isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : ''; // phpcs:ignore WordPressVIPMinimum.Variables.RestrictedVariables.cache_constraints___SERVER__HTTP_USER_AGENT__ -- read in AJAX/login handlers only, never in page-cached output

		$device = 'Laptop';

		$is_mob = is_numeric( strpos( $u_agent, 'Mobile' ) );
		$is_tab = is_numeric( strpos( $u_agent, 'Tablet' ) );

		if ( $is_mob ) {
			$device = 'Mobile';
		} elseif ( $is_tab ) {
			$device = 'Tablet';
		}

		return $device;
	}

	public static function get_logged_in_devices( $user_id ) {
		global $wpdb;
		$key = Admin::$meta_key . '%';
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->usermeta} WHERE meta_key LIKE %s AND user_id = %d",
				$key,
				$user_id
			)
		);
	}
}
