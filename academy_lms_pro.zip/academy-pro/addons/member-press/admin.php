<?php
namespace AcademyProMemberPress;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AcademyProMemberPress\Admin\Ajax;

class Admin {
	public static function init() {
		$self = new self();
		$self->dispatch_hooks();
	}

	public function dispatch_hooks() {
		( new Ajax() )->dispatch_actions();
	}
}
