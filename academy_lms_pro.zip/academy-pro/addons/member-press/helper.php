<?php
namespace AcademyProMemberPress;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

class Helper {

	public static function has_course_access( $course_id, $user_id = '' ): bool {
		$membership_id = self::get_current_course_memberships( $course_id );
		$user_id = ! empty( $user_id ) ? $user_id : get_current_user_id();
		if ( empty( $user_id ) ) {
			return false;
		}
		$is_administrator = current_user_can( 'manage_options' );
		$is_instructor    = \Academy\Helper::is_instructor_of_this_course( get_current_user_id(), $course_id );

		if ( $is_administrator || $is_instructor ) {
			return true;
		}
		$has_access = false;
		$user = new \MeprUser( $user_id );
		if ( $user->is_active_on_membership( $membership_id ) ) {
			$has_access = true;
		}
		return $has_access;
	}

	public static function get_current_course_memberships( $course_id ) {
		return get_post_meta( $course_id, 'academy_courses_mempr_membership_id', true );
	}

	public static function is_inactive_in_membership_levels( $membership_id, $user_id ) {
		$user = new \MeprUser( $user_id );
		return ! $user->is_active_on_membership( $membership_id );
	}
}
