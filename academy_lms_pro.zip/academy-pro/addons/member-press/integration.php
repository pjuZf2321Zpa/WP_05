<?php
namespace AcademyProMemberPress;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Integration {
	public static function init() {
		$self = new self();
		add_filter( 'academy/templates/single_course/enroll_form', array( $self, 'mempr_modify_enrollment_form' ), 10, 2 );
		add_filter( 'academy/before_enroll_course_type', array( $self, 'change_course_type_before_enrollment' ), 10, 2 );
		add_filter( 'academy/templates/start_course_url', array( $self, 'handle_subscription_of_membership' ), 10, 2 );
		add_filter( 'academy/templates/loop/price', array( $self, 'modify_loop_price_args' ), 10, 2 );
		add_filter( 'academy/single/enroll_content_args', array( $self, 'modify_enroll_form_content_args' ), 10, 2 );
		add_filter( 'academy/get_course_filter_types', array( $self, 'add_course_membership_filter' ) );
		add_filter( 'academy/course/get_course_type', array( $self, 'modify_course_typ' ), 10, 2 );
	}

	public function mempr_modify_enrollment_form( $html, $course_id ) {
		$course_type = \Academy\Helper::get_course_type( $course_id );

		if ( 'mempr_membership' !== $course_type ) {
			return $html;
		}
		$user_id = get_current_user_id();
		$is_enrolled = \Academy\Helper::is_enrolled( $course_id, $user_id );

		if ( $is_enrolled || Helper::has_course_access( $course_id ) ) {
			return $html;
		}
		$is_inactive = false;
		$membership_id = Helper::get_current_course_memberships( $course_id );
		if ( Helper::is_inactive_in_membership_levels( $membership_id, $user_id ) ) {
			$is_inactive = true;
		}
		$is_enabled_academy_login = \Academy\Helper::get_settings( 'is_enabled_academy_login', true );
		ob_start();
		\AcademyPro\Helper::get_template( 'member-press/mempr-message.php', [
			'is_enable_academy_login' => $is_enabled_academy_login,
			'is_inactive_membership' => $is_inactive,
			'membership_id' => $membership_id,
		] );

		return ob_get_clean();
	}

	public function change_course_type_before_enrollment( $course_type, $course_id ) {
		if ( 'mempr_membership' === $course_type && Helper::has_course_access( $course_id ) ) {
			return 'free';
		}

		return $course_type;
	}

	public function handle_subscription_of_membership( $permalink, $course_id ) {
		$course_type = get_post_meta( $course_id, 'academy_course_type', true );
		$user_id = get_current_user_id();

		if ( 'mempr_membership' !== $course_type ) {
			return $permalink;
		}

		if ( ! Helper::has_course_access( $course_id, $user_id ) ) {
			\Academy\Helper::cancel_course_enroll( $course_id, $user_id );
			return $permalink;
		}

		return $permalink;
	}

	public function modify_loop_price_args( $course_type, $course_id ) {
		$type = get_post_meta( $course_id, 'academy_course_type', true );
		if ( 'mempr_membership' === $type ) {
			$course_type = esc_html__( 'Membership', 'academy-pro' );
		}
		return $course_type;
	}

	public function modify_enroll_form_content_args( $args, $course_id ) {
		if ( 'mempr_membership' === get_post_meta( $course_id, 'academy_course_type', true ) ) {
			$args['is_paid'] = true;
			$args['price'] = '<div class="academy-course-type">' . __( 'Membership', 'academy-pro' ) . '</div>';
		}
		return $args;
	}

	public function add_course_membership_filter( $types ) {
		$types['mempr_membership'] = __( 'Membership', 'academy-pro' );
		return $types;
	}

	public function modify_course_typ( $type, $course_id ) {
		if ( 'mempr_membership' === $type && Helper::has_course_access( $course_id ) ) {
			$type = 'free';
		}
		return $type;
	}
}
