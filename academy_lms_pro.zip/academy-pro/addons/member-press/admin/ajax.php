<?php
namespace AcademyProMemberPress\Admin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Academy\Classes\AbstractAjaxHandler;

class Ajax extends AbstractAjaxHandler {
	protected $namespace = 'academy_pro_memberpress/admin';
	public function __construct() {
		$this->actions = array(
			'get_memberships' => array(
				'callback' => array( $this, 'get_all_memberships' ),
				'capability' => 'manage_options',
			)
		);
	}


	public function get_all_memberships() {
		$products = \MeprProduct::get_all();
		$args = [];
		foreach ( $products as $key => $product ) {
			$args[ $key ] = [
				'membership_id' => $product->ID,
				'membership_title' => $product->post_title,
			];
		}
		wp_send_json_success( $args );
	}
}
