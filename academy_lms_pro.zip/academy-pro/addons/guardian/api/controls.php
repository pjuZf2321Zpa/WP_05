<?php
namespace AcademyProGuardian\API;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AcademyProGuardian\Helper;
use AcademyProGuardian\Controls as ControlsService;
use Academy\Guardian\Store;
use WP_Error;

/**
 * Parental-control settings + enrollment-approval queue.
 * academy/v1/family/controls, /family/pending[/{id}/approve|reject]
 */
class Controls {

	private $namespace = ACADEMY_PLUGIN_SLUG . '/v1';

	public static function init() {
		$self = new self();
		add_action( 'rest_api_init', array( $self, 'register_routes' ) );
	}

	public function register_routes() {
		register_rest_route( $this->namespace, '/family/controls', array(
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_controls' ),
				'permission_callback' => array( $this, 'guardian_check' ),
			),
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'set_controls' ),
				'permission_callback' => array( $this, 'guardian_check' ),
			),
		) );

		register_rest_route( $this->namespace, '/family/pending', array(
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'list_pending' ),
				'permission_callback' => array( $this, 'guardian_check' ),
			),
		) );

		register_rest_route( $this->namespace, '/family/pending/(?P<id>\d+)/(?P<action>approve|reject)', array(
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'act_on_pending' ),
				'permission_callback' => array( $this, 'guardian_check' ),
			),
		) );
	}

	public function guardian_check() {
		return is_user_logged_in() && (
			current_user_can( 'manage_academy_guardian' ) ||
			in_array( 'academy_guardian', (array) wp_get_current_user()->roles, true )
		);
	}

	private function owns_child( $student_id ) {
		return current_user_can( 'manage_options' )
			|| in_array( get_current_user_id(), Store::get_guardians( (int) $student_id ), true );
	}

	public function get_controls( $request ) {
		$student_id = (int) $request->get_param( 'student_id' );
		if ( ! $this->owns_child( $student_id ) ) {
			return new WP_Error( 'forbidden', __( 'Not your child.', 'academy-pro' ), array( 'status' => 403 ) );
		}
		return rest_ensure_response( Helper::get_child_controls( get_current_user_id(), $student_id ) );
	}

	public function set_controls( $request ) {
		$student_id = (int) $request->get_param( 'student_id' );
		if ( ! $this->owns_child( $student_id ) ) {
			return new WP_Error( 'forbidden', __( 'Not your child.', 'academy-pro' ), array( 'status' => 403 ) );
		}
		$saved = Helper::set_child_controls( get_current_user_id(), $student_id, array(
			'require_approval' => (bool) $request->get_param( 'require_approval' ),
			'spending_limit'   => (float) $request->get_param( 'spending_limit' ),
		) );
		return rest_ensure_response( $saved );
	}

	public function list_pending( $request ) {
		global $wpdb;
		$table = Helper::pending_table();
		$gid   = get_current_user_id();
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- only $wpdb-prefixed table names, whitelisted columns and intval/placeholder lists are interpolated; values are prepared
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM {$table} WHERE guardian_id = %d AND status = 'pending' ORDER BY id DESC",
			$gid
		), ARRAY_A );
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$items = array_map( function ( $r ) {
			$student = get_user_by( 'id', (int) $r['student_id'] );
			$r['student_name'] = $student ? $student->display_name : '';
			$r['course_title'] = get_the_title( (int) $r['course_id'] );
			return $r;
		}, $rows ? $rows : array() );
		return rest_ensure_response( $items );
	}

	public function act_on_pending( $request ) {
		global $wpdb;
		$id     = (int) $request['id'];
		$action = $request['action'];
		$table  = Helper::pending_table();
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$owner = (int) $wpdb->get_var( $wpdb->prepare( "SELECT guardian_id FROM {$table} WHERE id = %d", $id ) );
		if ( ! $owner || ( get_current_user_id() !== $owner && ! current_user_can( 'manage_options' ) ) ) {
			return new WP_Error( 'forbidden', __( 'Not your request.', 'academy-pro' ), array( 'status' => 403 ) );
		}
		$ok = 'approve' === $action ? ControlsService::approve( $id ) : ControlsService::reject( $id );
		return rest_ensure_response( array(
			'ok' => (bool) $ok,
			'action' => $action,
			'id' => $id
		) );
	}
}
