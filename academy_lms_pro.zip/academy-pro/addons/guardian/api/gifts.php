<?php
namespace AcademyProGuardian\API;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AcademyProGuardian\Helper;
use AcademyProGuardian\Gifting;
use Academy\Guardian\Store;
use WP_Error;

/**
 * Course gifting. academy/v1/family/gifts
 */
class Gifts {

	private $namespace = ACADEMY_PLUGIN_SLUG . '/v1';

	public static function init() {
		$self = new self();
		add_action( 'rest_api_init', array( $self, 'register_routes' ) );
	}

	public function register_routes() {
		register_rest_route( $this->namespace, '/family/gifts', array(
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'list_gifts' ),
				'permission_callback' => array( $this, 'guardian_check' ),
			),
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'create_gift' ),
				'permission_callback' => array( $this, 'guardian_check' ),
			),
		) );
	}

	public function guardian_check() {
		return is_user_logged_in() && (
			current_user_can( 'manage_academy_guardian' ) ||
			in_array( 'academy_guardian', (array) wp_get_current_user()->roles, true )
		);
	}

	public function list_gifts( $request ) {
		global $wpdb;
		$table = Helper::gifts_table();
		$gid   = get_current_user_id();
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- only $wpdb-prefixed table names, whitelisted columns and intval/placeholder lists are interpolated; values are prepared
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM {$table} WHERE gifter_id = %d ORDER BY id DESC",
			$gid
		), ARRAY_A );
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$items = array_map( function ( $r ) {
			$student = get_user_by( 'id', (int) $r['student_id'] );
			$r['student_name'] = $student ? $student->display_name : '';
			$r['course_title'] = get_the_title( (int) $r['course_id'] );
			return $r;
		}, $rows ? $rows : array() );
		return rest_ensure_response( $items );
	}

	public function create_gift( $request ) {
		$student_id = (int) $request->get_param( 'student_id' );
		$course_id  = (int) $request->get_param( 'course_id' );

		if ( ! $course_id || 'academy_courses' !== get_post_type( $course_id ) ) {
			return new WP_Error( 'invalid_course', __( 'A valid course is required.', 'academy-pro' ), array( 'status' => 400 ) );
		}
		if ( ! current_user_can( 'manage_options' ) && ! in_array( get_current_user_id(), Store::get_guardians( $student_id ), true ) ) {
			return new WP_Error( 'forbidden', __( 'Not your child.', 'academy-pro' ), array( 'status' => 403 ) );
		}

		$gift = Gifting::gift( get_current_user_id(), $student_id, $course_id );
		if ( is_wp_error( $gift ) ) {
			return $gift;
		}
		return rest_ensure_response( array(
			'gift_id' => (int) $gift,
			'student_id' => $student_id,
			'course_id' => $course_id
		) );
	}
}
