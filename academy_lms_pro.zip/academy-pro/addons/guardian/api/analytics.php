<?php
namespace AcademyProGuardian\API;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Academy\Guardian\Store;

/**
 * Multi-child analytics for a guardian. academy/v1/family/analytics
 */
class Analytics {

	private $namespace = ACADEMY_PLUGIN_SLUG . '/v1';

	public static function init() {
		$self = new self();
		add_action( 'rest_api_init', array( $self, 'register_routes' ) );
	}

	public function register_routes() {
		register_rest_route( $this->namespace, '/family/analytics', array(
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_analytics' ),
				'permission_callback' => function () {
					return is_user_logged_in() && (
						current_user_can( 'manage_academy_guardian' ) ||
						in_array( 'academy_guardian', (array) wp_get_current_user()->roles, true )
					);
				},
			),
		) );
	}

	public function get_analytics( $request ) {
		$guardian_id = current_user_can( 'manage_options' ) && $request->get_param( 'guardian_id' )
			? (int) $request->get_param( 'guardian_id' )
			: get_current_user_id();

		$children      = Store::get_children( $guardian_id );
		$total_enrolled = 0;
		$total_completed = 0;
		$total_certs   = 0;
		$per_child     = array();

		foreach ( $children as $student_id ) {
			$snap = Store::child_snapshot( $student_id );
			$total_enrolled  += (int) $snap['enrolled_count'];
			$total_completed += (int) $snap['completed_count'];
			$total_certs     += (int) $snap['certificate_count'];
			$avg = $snap['enrolled_count']
				? (int) round( array_sum( array_map( 'intval', wp_list_pluck( $snap['courses'], 'progress' ) ) ) / max( 1, count( $snap['courses'] ) ) )
				: 0;
			$per_child[] = array(
				'id'                => (int) $snap['id'],
				'name'              => $snap['name'],
				'enrolled'          => (int) $snap['enrolled_count'],
				'completed'         => (int) $snap['completed_count'],
				'certificates'      => (int) $snap['certificate_count'],
				'avg_progress'      => $avg,
				'completion_rate'   => $snap['enrolled_count'] ? (int) round( ( $snap['completed_count'] / $snap['enrolled_count'] ) * 100 ) : 0,
			);
		}

		return rest_ensure_response( array(
			'children_count'   => count( $children ),
			'total_enrolled'   => $total_enrolled,
			'total_completed'  => $total_completed,
			'total_certificates' => $total_certs,
			'overall_completion_rate' => $total_enrolled ? (int) round( ( $total_completed / $total_enrolled ) * 100 ) : 0,
			'per_child'        => $per_child,
		) );
	}
}
