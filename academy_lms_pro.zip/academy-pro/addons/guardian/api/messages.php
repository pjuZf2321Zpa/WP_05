<?php
namespace AcademyProGuardian\API;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AcademyProGuardian\Helper;
use Academy\Guardian\Store;
use WP_Error;

/**
 * Guardian ↔ teacher messaging. academy/v1/family/messages
 *
 * A thread is every message sharing a (student, teacher) pair, so both of a
 * child's guardians write into one conversation and a teacher's inbox is that
 * list with unread counts. Opening a thread is what marks the other side read.
 *
 * Who counts as "my child's teacher" is a seam, not a hard-coded rule: on a
 * plain LMS it is the instructor of a course the child is enrolled in, and a
 * school SIS adds the people who actually teach that child's section through
 * the `academy/guardian/message_contacts` filter.
 *
 * Access here is by participation, not by rank. Being able to *see* a
 * student's record — which any site manager can — does not open the
 * conversations their family is having, so nothing here bypasses on a
 * capability.
 */
class Messages {

	private $namespace = ACADEMY_PLUGIN_SLUG . '/v1';

	public static function init() {
		$self = new self();
		add_action( 'rest_api_init', array( $self, 'register_routes' ) );
	}

	public function register_routes() {
		register_rest_route( $this->namespace, '/family/messages', array(
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'inbox' ),
				'permission_callback' => 'is_user_logged_in',
			),
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'send' ),
				'permission_callback' => 'is_user_logged_in',
			),
		) );

		// Who a family may write to about this child.
		register_rest_route( $this->namespace, '/family/messages/contacts', array(
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'contacts' ),
				'permission_callback' => array( $this, 'can_view_student' ),
			),
		) );

		// Everything waiting on a teacher.
		register_rest_route( $this->namespace, '/family/messages/threads', array(
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'threads' ),
				'permission_callback' => 'is_user_logged_in',
			),
		) );

		// One conversation.
		register_rest_route( $this->namespace, '/family/messages/thread', array(
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'thread' ),
				'permission_callback' => array( $this, 'is_participant' ),
			),
		) );

		register_rest_route( $this->namespace, '/family/messages/(?P<id>\d+)/read', array(
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'mark_read' ),
				'permission_callback' => 'is_user_logged_in',
			),
		) );
	}

	public function can_view_student( $request ) {
		return Store::can_view( (int) $request->get_param( 'student_id' ) );
	}

	/**
	 * Either end of this particular conversation — and nobody else.
	 *
	 * @param \WP_REST_Request $request
	 */
	public function is_participant( $request ) {
		if ( ! is_user_logged_in() ) {
			return false;
		}
		$student_id = (int) $request->get_param( 'student_id' );
		$teacher_id = (int) $request->get_param( 'teacher_id' );
		if ( ! $student_id || ! $teacher_id ) {
			return new WP_Error( 'invalid', __( 'Choose who the message is about.', 'academy-pro' ), array( 'status' => 400 ) );
		}
		return $this->participates( $student_id, $teacher_id );
	}

	private function participates( $student_id, $teacher_id ) {
		$user_id = get_current_user_id();
		if ( $user_id === (int) $teacher_id || $user_id === (int) $student_id ) {
			return true;
		}
		return in_array( $user_id, array_map( 'intval', (array) Store::get_guardians( (int) $student_id ) ), true );
	}

	/**
	 * The teachers a family may write to about one child.
	 *
	 * The instructors of the courses the child is enrolled in, plus whatever a
	 * school SIS adds for the section the child actually sits in.
	 *
	 * @param \WP_REST_Request $request
	 */
	public function contacts( $request ) {
		global $wpdb;
		$student_id = (int) $request->get_param( 'student_id' );

		$found = array();
		foreach ( (array) Store::child_courses( $student_id ) as $course ) {
			$course_id  = (int) $course['course_id'];
			$teacher_id = (int) get_post_field( 'post_author', $course_id );
			if ( ! $teacher_id ) {
				continue;
			}
			$found[ $teacher_id ]['roles'][]      = $this->title( $course_id );
			$found[ $teacher_id ]['course_id']    = $found[ $teacher_id ]['course_id'] ?? $course_id;
		}

		/**
		 * Who else may be written to about this student.
		 *
		 * @param array $found      teacher_id => [ 'roles' => string[], 'course_id' => int ].
		 * @param int   $student_id The child in question.
		 */
		$found = (array) apply_filters( 'academy/guardian/message_contacts', $found, $student_id );

		$table = Helper::messages_table();
		$out   = array();
		foreach ( $found as $teacher_id => $meta ) {
			$teacher = get_user_by( 'id', (int) $teacher_id );
			if ( ! $teacher ) {
				continue;
			}
			// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- only $wpdb-prefixed table names, whitelisted columns and intval/placeholder lists are interpolated; values are prepared
			$unread = (int) $wpdb->get_var( $wpdb->prepare(
				"SELECT COUNT(id) FROM {$table}
				 WHERE student_id = %d AND teacher_id = %d AND from_teacher = 1 AND is_read = 0",
				$student_id,
				(int) $teacher_id
			) );
			// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$out[] = array(
				'teacher_id' => (int) $teacher_id,
				'name'       => $teacher->display_name,
				'roles'      => array_values( array_unique( (array) ( $meta['roles'] ?? array() ) ) ),
				'course_id'  => (int) ( $meta['course_id'] ?? 0 ),
				'unread'     => $unread,
			);
		}//end foreach

		return rest_ensure_response( $out );
	}

	/**
	 * The caller's conversations, most recently spoken in first — the threads
	 * addressed to them as a teacher, and the threads about their children.
	 */
	public function threads() {
		global $wpdb;
		$user_id = get_current_user_id();
		$table   = Helper::messages_table();

		$children = array_map( 'intval', (array) Store::get_children( $user_id ) );
		$mine     = $children;
		// A learner reads their own threads too.
		$mine[]   = $user_id;
		$in       = implode( ',', array_map( 'intval', array_unique( $mine ) ) );

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- only $wpdb-prefixed table names, whitelisted columns and intval/placeholder lists are interpolated; values are prepared
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT student_id, teacher_id, MAX(id) AS last_id
			 FROM {$table}
			 WHERE teacher_id = %d OR student_id IN ({$in})
			 GROUP BY student_id, teacher_id
			 ORDER BY last_id DESC LIMIT 100",
			$user_id
		), ARRAY_A );
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		$out = array();
		foreach ( (array) $rows as $row ) {
			$as_teacher = $user_id === (int) $row['teacher_id'];
			// Unread means "said by the other side": a teacher counts what the
			// family wrote, a family counts what the teacher wrote.
			// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$unread = (int) $wpdb->get_var( $wpdb->prepare(
				"SELECT COUNT(id) FROM {$table}
				 WHERE student_id = %d AND teacher_id = %d AND from_teacher = %d AND is_read = 0",
				(int) $row['student_id'],
				(int) $row['teacher_id'],
				$as_teacher ? 0 : 1
			) );
			$last = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", (int) $row['last_id'] ), ARRAY_A );
			// phpcs:enable
			$student = get_user_by( 'id', (int) $row['student_id'] );
			$teacher = get_user_by( 'id', (int) $row['teacher_id'] );

			$out[] = array(
				'student_id' => (int) $row['student_id'],
				'student'    => $student ? $student->display_name : '',
				'teacher_id' => (int) $row['teacher_id'],
				'teacher'    => $teacher ? $teacher->display_name : '',
				'as_teacher' => $as_teacher,
				'unread'     => $unread,
				'last'       => $last ? wp_trim_words( (string) $last['body'], 14 ) : '',
				'last_at'    => $last ? (string) $last['created_at'] : '',
			);
		}//end foreach

		return rest_ensure_response( $out );
	}

	/**
	 * One conversation. Opening it is what marks the other side's messages read.
	 *
	 * @param \WP_REST_Request $request
	 */
	public function thread( $request ) {
		global $wpdb;
		$student_id = (int) $request->get_param( 'student_id' );
		$teacher_id = (int) $request->get_param( 'teacher_id' );
		$table      = Helper::messages_table();
		$as_teacher = get_current_user_id() === $teacher_id;

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->query( $wpdb->prepare(
			"UPDATE {$table} SET is_read = 1
			 WHERE student_id = %d AND teacher_id = %d AND from_teacher = %d AND is_read = 0",
			$student_id,
			$teacher_id,
			$as_teacher ? 0 : 1
		) );

		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM {$table} WHERE student_id = %d AND teacher_id = %d ORDER BY id ASC LIMIT 200",
			$student_id,
			$teacher_id
		), ARRAY_A );
		// phpcs:enable

		$teacher = get_user_by( 'id', $teacher_id );
		$student = get_user_by( 'id', $student_id );
		$user_id = get_current_user_id();

		return rest_ensure_response( array(
			'teacher'  => $teacher ? $teacher->display_name : '',
			'student'  => $student ? $student->display_name : '',
			'messages' => array_map( function ( $row ) use ( $user_id ) {
				$sender = get_user_by( 'id', (int) $row['sender_id'] );
				return array(
					'id'           => (int) $row['id'],
					'body'         => (string) $row['body'],
					'from_teacher' => (bool) $row['from_teacher'],
					'sender'       => $sender ? $sender->display_name : '',
					'mine'         => $user_id === (int) $row['sender_id'],
					'course'       => $row['course_id'] ? $this->title( (int) $row['course_id'] ) : '',
					'created_at'   => (string) $row['created_at'],
				);
			}, (array) $rows ),
		) );
	}

	/**
	 * The flat list of everything the caller has said or been sent.
	 *
	 * Superseded by threads() + thread(), and kept because it is the shape the
	 * original inbox spoke.
	 *
	 * @param \WP_REST_Request $request
	 */
	public function inbox( $request ) {
		global $wpdb;
		$table = Helper::messages_table();
		$uid   = get_current_user_id();
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- only $wpdb-prefixed table names, whitelisted columns and intval/placeholder lists are interpolated; values are prepared
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM {$table} WHERE recipient_id = %d OR sender_id = %d ORDER BY id DESC LIMIT 200",
			$uid, $uid
		), ARRAY_A );
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$items = array_map( function ( $r ) {
			$s = get_user_by( 'id', (int) $r['sender_id'] );
			$rec = get_user_by( 'id', (int) $r['recipient_id'] );
			$r['sender_name']    = $s ? $s->display_name : '';
			$r['recipient_name'] = $rec ? $rec->display_name : '';
			$r['course_title']   = $r['course_id'] ? $this->title( (int) $r['course_id'] ) : '';
			return $r;
		}, $rows ? $rows : array() );
		return rest_ensure_response( $items );
	}

	/**
	 * Send a message into a thread.
	 *
	 * A caller names the teacher; a caller that only knows a course (the shape
	 * the old composer sent) gets its author resolved for them. Either way the
	 * sender must be one end of the conversation, so nobody can write to an
	 * arbitrary user by passing an id.
	 *
	 * @param \WP_REST_Request $request
	 */
	public function send( $request ) {
		global $wpdb;
		$sender_id  = get_current_user_id();
		$student_id = (int) $request->get_param( 'student_id' );
		$course_id  = (int) $request->get_param( 'course_id' );
		$teacher_id = (int) $request->get_param( 'teacher_id' );
		$body       = trim( (string) $request->get_param( 'body' ) );

		if ( '' === $body ) {
			return new WP_Error( 'empty', __( 'Message body is required.', 'academy-pro' ), array( 'status' => 400 ) );
		}
		if ( ! $teacher_id && $course_id ) {
			$teacher_id = (int) get_post_field( 'post_author', $course_id );
		}
		if ( ! $student_id || ! $teacher_id ) {
			return new WP_Error( 'no_recipient', __( 'Choose a child and the teacher to write to.', 'academy-pro' ), array( 'status' => 400 ) );
		}
		if ( ! $this->participates( $student_id, $teacher_id ) ) {
			return new WP_Error( 'forbidden', __( 'That isn’t your conversation.', 'academy-pro' ), array( 'status' => 403 ) );
		}

		$from_teacher = $sender_id === $teacher_id;
		$body         = wp_kses_post( $body );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->insert( Helper::messages_table(), array(
			'sender_id'    => $sender_id,
			// The far end of the thread, kept so the flat inbox still reads.
			'recipient_id' => $from_teacher ? $student_id : $teacher_id,
			'student_id'   => $student_id,
			'teacher_id'   => $teacher_id,
			'from_teacher' => $from_teacher ? 1 : 0,
			'course_id'    => $course_id ? $course_id : null,
			'body'         => $body,
		) );
		$id = (int) $wpdb->insert_id;

		$this->notify( $id, $student_id, $teacher_id, $from_teacher, $body );

		return rest_ensure_response( array(
			'id' => $id,
			'sent' => true
		) );
	}

	/**
	 * Tell the other end.
	 *
	 * Email is the default. A site with a messaging gateway wired up — a school
	 * running Digital Campus, say — answers the filter and delivers it its own
	 * way instead, so the same message doesn't go out twice.
	 *
	 * @param int   $id
	 * @param int   $student_id
	 * @param int   $teacher_id
	 * @param mixed $from_teacher
	 * @param mixed $body
	 */
	private function notify( $id, $student_id, $teacher_id, $from_teacher, $body ) {
		$sender     = wp_get_current_user();
		$subject    = __( 'New message on Academy', 'academy-pro' );
		/* translators: 1: sender name, 2: the message */
		$message    = sprintf( __( '%1$s wrote: %2$s', 'academy-pro' ), $sender->display_name, wp_strip_all_tags( $body ) );
		$recipients = $from_teacher
			? array_merge( array( (int) $student_id ), array_map( 'intval', (array) Store::get_guardians( $student_id ) ) )
			: array( (int) $teacher_id );

		/**
		 * Whether something else has delivered this message.
		 *
		 * @param bool  $handled Return true to suppress the default email.
		 * @param array $context id, recipients, subject, message, student_id, teacher_id, from_teacher.
		 */
		$handled = apply_filters( 'academy/guardian/notify_message', false, array(
			'id'           => (int) $id,
			'recipients'   => $recipients,
			'subject'      => $subject,
			'message'      => $message,
			'student_id'   => (int) $student_id,
			'teacher_id'   => (int) $teacher_id,
			'from_teacher' => (bool) $from_teacher,
		) );
		if ( $handled ) {
			return;
		}

		foreach ( array_unique( array_filter( $recipients ) ) as $user_id ) {
			$user = get_user_by( 'id', $user_id );
			if ( $user && is_email( $user->user_email ) ) {
				wp_mail( $user->user_email, $subject, $message ); // phpcs:ignore WordPressVIPMinimum.Functions.RestrictedFunctions.wp_mail_wp_mail -- single transactional email
			}
		}
	}

	public function mark_read( $request ) {
		global $wpdb;
		$id = (int) $request['id'];
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->update( Helper::messages_table(), array( 'is_read' => 1 ), array(
			'id' => $id,
			'recipient_id' => get_current_user_id()
		) );
		return rest_ensure_response( array(
			'ok' => true,
			'id' => $id
		) );
	}

	/**
	 * A post title as a person would read it — get_the_title() runs wptexturize,
	 * and the entities it leaves behind print literally in the dashboard.
	 *
	 * @param int $post_id
	 */
	private function title( $post_id ) {
		return html_entity_decode( get_the_title( (int) $post_id ), ENT_QUOTES, 'UTF-8' );
	}
}
