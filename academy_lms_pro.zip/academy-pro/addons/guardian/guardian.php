<?php
namespace AcademyProGuardian;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Academy\Interfaces\AddonInterface;

/**
 * Academy Guardian — Pro power features.
 *
 * Extends the free Guardian/Family layer in Academy core with: digest &
 * inactivity emails, parental controls (enrollment approval + spending limit),
 * multi-child analytics, guardian ↔ teacher messaging, and course gifting.
 *
 * Runs only when the core Guardian feature is present (Academy\Guardian\Store).
 */
final class Guardian implements AddonInterface {

	public function __construct() {
		$this->define_constants();
		$this->init_addon();
	}

	public static function init() {
		static $instance = false;
		if ( ! $instance ) {
			$instance = new self();
		}
		return $instance;
	}

	public function define_constants(): void {
		// 1.1.0 adds threading columns to the messages table.
		define( 'ACADEMY_PRO_GUARDIAN_VERSION', '1.1.0' );
		define( 'ACADEMY_PRO_GUARDIAN_DIR_PATH', ACADEMY_PRO_ADDONS_DIR_PATH . 'guardian/' );
	}

	public function init_addon(): void {
		// Requires Academy core's Guardian feature (the canonical family store).
		if ( ! class_exists( '\Academy\Guardian\Store' ) ) {
			return;
		}

		// The Pro guardian features have no toggle of their own: they follow the
		// free "Guardian" addon switch. Activating it installs + boots Pro too;
		// deactivating it unschedules the Pro cron. The listeners are registered
		// before the active-status gate so the toggle is always caught.
		add_action( 'academy/addons/activated_guardian', array( $this, 'addon_activation_hook' ) );
		add_action( 'academy/addons/deactivated_guardian', array( $this, 'addon_deactivation_hook' ) );

		if ( ! \Academy\Helper::get_addon_active_status( 'guardian' ) ) {
			return;
		}

		$this->maybe_install();

		Settings::init();
		Database::init();
		API::init();
		Emails::init();
		Controls::init();
		Gifting::init();
		Frontend::init();
	}

	private function maybe_install(): void {
		if ( \Academy\Options::get( \Academy\Options::PRO_DB_VERSIONS, 'guardian' ) !== ACADEMY_PRO_GUARDIAN_VERSION ) {
			$this->addon_activation_hook();
		}
	}

	public function addon_activation_hook(): void {
		Installer::init();
	}

	public function addon_deactivation_hook(): void {
		Emails::unschedule_events();
	}
}
