<?php
namespace AcademyProGuardian;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Installer {

	public static function init() {
		Database::create_initial_custom_table();
		Emails::schedule_events();
		\Academy\Options::set( \Academy\Options::PRO_DB_VERSIONS, 'guardian', ACADEMY_PRO_GUARDIAN_VERSION );
	}
}
