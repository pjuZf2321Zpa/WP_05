<?php
namespace AcademyProGuardian;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Guardian settings, on Academy's own settings screen
 * (Settings → Advanced → Guardian).
 *
 * The addon toggle is all-or-nothing: turning Guardian off takes the digests,
 * the parental controls and the gifting with it. A school that wants the family
 * dashboard but not an open channel to its teachers needs to switch just the
 * messaging off, which is what this is for.
 */
class Settings {

	const MESSAGING = 'academy_guardian_enable_messaging';

	public static function init() {
		$self = new self();
		add_filter( 'academy/admin/settings/base_default_data', array( $self, 'default_data' ) );
		add_filter( 'academy/admin/settings/sanitize_payload', array( $self, 'sanitize' ) );
		add_filter( 'academy/admin/settings/save', array( $self, 'save' ), 11, 3 );
		add_filter( 'academy/api/settings/get_settings', array( $self, 'fill_in' ) );
	}

	/**
	 * Messaging is on unless a site turns it off — it worked before there was a
	 * switch, and an upgrade shouldn't quietly close a channel families are
	 * already using.
	 *
	 * @param mixed $defaults
	 */
	public function default_data( $defaults ) {
		$defaults[ self::MESSAGING ] = true;
		return $defaults;
	}

	public function sanitize( $types ) {
		$types[ self::MESSAGING ] = 'boolean';
		return $types;
	}

	/**
	 * Read the *sanitized* payload, never the raw one: the switch posts the
	 * string "false", which casts to true.
	 *
	 * @param array $data
	 * @param array $payload
	 * @param array $default
	 */
	public function save( $data, $payload = array(), $default = array() ) {
		$data[ self::MESSAGING ] = $payload[ self::MESSAGING ] ?? $default[ self::MESSAGING ] ?? true;
		return $data;
	}

	/**
	 * The settings endpoint answers with what is *stored*, not stored merged
	 * over defaults — so a key added after a site last saved its settings is
	 * simply missing, and the switch renders off while the feature is on. Fill
	 * it in on the way out so the screen agrees with the server.
	 *
	 * @param array $settings
	 */
	public function fill_in( $settings ) {
		if ( is_array( $settings ) && ! array_key_exists( self::MESSAGING, $settings ) ) {
			$settings[ self::MESSAGING ] = true;
		}
		return $settings;
	}

	/** Whether families and teachers may write to each other at all. */
	public static function messaging_enabled() {
		// A site that saved its settings before this switch existed has no
		// value stored; the feature was on then, so it stays on.
		return (bool) \Academy\Helper::get_settings( self::MESSAGING, true );
	}
}
