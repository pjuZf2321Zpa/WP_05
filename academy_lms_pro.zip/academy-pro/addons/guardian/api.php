<?php
namespace AcademyProGuardian;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class API {

	public static function init() {
		API\Controls::init();
		API\Analytics::init();
		// Messaging is switchable on the settings screen; when it is off the
		// routes aren't there at all, not merely hidden.
		if ( Settings::messaging_enabled() ) {
			API\Messages::init();
		}
		API\Gifts::init();
	}
}
