<?php
namespace AcademyProGuardian;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Academy\Guardian\Store;

/**
 * Course gifting. Answers core's `academy/guardian/assign_course` filter so a
 * guardian can gift a paid course to a ward. Enforces the per-child spending
 * limit and records the gift; the actual payment is delegated through a seam so
 * a gateway (WooCommerce / StoreEngine / native) can settle it.
 */
class Gifting {

	public static function init() {
		$self = new self();
		add_filter( 'academy/guardian/assign_course', array( $self, 'handle_paid_assign' ), 10, 4 );
	}

	/**
	 * @param bool $handled   Whether a prior handler already settled it.
	 * @param int  $course_id
	 * @param int  $student_id
	 * @param int  $actor_id  The guardian doing the assign.
	 * @return bool True when this handler has gifted/enrolled the course.
	 */
	public function handle_paid_assign( $handled, $course_id, $student_id, $actor_id ) {
		if ( true === $handled ) {
			return $handled;
		}

		$price = (float) get_post_meta( (int) $course_id, 'academy_course_price', true );
		// Free courses fall through to core's direct enrollment.
		if ( $price <= 0 ) {
			return $handled;
		}

		return (bool) self::gift( $actor_id, $student_id, $course_id );
	}

	/**
	 * Gift a course to a learner: spending-limit check → payment seam → record
	 * gift → enroll. Returns the gift id, or a WP_Error.
	 *
	 * @param int $gifter_id
	 * @param int $student_id
	 * @param int $course_id
	 * @param int $order_id
	 */
	public static function gift( $gifter_id, $student_id, $course_id, $order_id = 0 ) {
		global $wpdb;
		$gifter_id  = (int) $gifter_id;
		$student_id = (int) $student_id;
		$course_id  = (int) $course_id;
		$price      = (float) get_post_meta( $course_id, 'academy_course_price', true );

		// Enforce the per-child spending limit (0 = unlimited).
		$controls = Helper::get_child_controls( $gifter_id, $student_id );
		$limit    = (float) $controls['spending_limit'];
		if ( $limit > 0 && ( Helper::gifted_spend( $gifter_id, $student_id ) + $price ) > $limit ) {
			return new \WP_Error( 'spending_limit', __( 'This gift exceeds the spending limit you set for this child.', 'academy-pro' ), array( 'status' => 403 ) );
		}

		/**
		 * Payment seam. A gateway integration returns an order id (truthy) once
		 * the gifter has paid; until then gifting is recorded as pending unless
		 * a manager grants it. Default: managers grant free; others need payment.
		 */
		$order_id = (int) apply_filters( 'academy/guardian/gift_payment', $order_id, $gifter_id, $student_id, $course_id, $price );
		$status   = ( $order_id || current_user_can( 'manage_options' ) ) ? 'completed' : 'pending';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->insert( Helper::gifts_table(), array(
			'gifter_id'  => $gifter_id,
			'student_id' => $student_id,
			'course_id'  => $course_id,
			'order_id'   => $order_id ? $order_id : null,
			'status'     => $status,
		) );
		$gift_id = (int) $wpdb->insert_id;

		if ( 'completed' === $status && ! \Academy\Helper::is_enrolled( $course_id, $student_id ) ) {
			\Academy\Helper::do_enroll( $course_id, $student_id, $order_id );
			do_action( 'academy/guardian/course_gifted', $course_id, $student_id, $gifter_id, $gift_id );
		}

		return $gift_id;
	}
}
