<?php
namespace AcademyProGuardian\Database;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Guardian ↔ teacher messages.
 *
 * A conversation isn't a row of its own: it is every message sharing the same
 * (student_id, teacher_id) pair. Both of a child's guardians write into the
 * same thread, the child can write into it too, and nothing has to be created
 * before the first message is sent. `course_id` stays as optional context —
 * which course the family is asking about — not as the thread key, because in
 * a school the person teaching a child often isn't the author of any course.
 */
class CreateMessagesTable {
	public static function up( $prefix, $charset_collate ) {
		$table = $prefix . 'academy_guardian_messages';
		$sql   = "CREATE TABLE IF NOT EXISTS $table (
			id bigint(20) unsigned NOT NULL auto_increment,
			sender_id bigint(20) unsigned NOT NULL,
			recipient_id bigint(20) unsigned NOT NULL,
			student_id bigint(20) unsigned DEFAULT NULL,
			teacher_id bigint(20) unsigned NOT NULL DEFAULT 0,
			from_teacher tinyint(1) NOT NULL DEFAULT 0,
			course_id bigint(20) unsigned DEFAULT NULL,
			body text NOT NULL,
			is_read tinyint(1) NOT NULL DEFAULT 0,
			created_at timestamp DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			KEY recipient_id (recipient_id),
			KEY sender_id (sender_id),
			KEY thread (student_id, teacher_id, id)
		) $charset_collate;";
		dbDelta( $sql );

		global $wpdb;

		// Tables created before threading arrived get the columns explicitly —
		// dbDelta's CREATE TABLE IF NOT EXISTS won't touch an existing table.
		$adds = array(
			'teacher_id'   => 'bigint(20) unsigned NOT NULL DEFAULT 0',
			'from_teacher' => 'tinyint(1) NOT NULL DEFAULT 0',
		);
		foreach ( $adds as $column => $definition ) {
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			if ( ! $wpdb->get_var( "SHOW COLUMNS FROM {$table} LIKE '{$column}'" ) ) {
				$wpdb->query( "ALTER TABLE {$table} ADD COLUMN {$column} {$definition}" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange -- versioned one-time schema migration
			}
		}

		// …and the index the thread lookups read through.
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		if ( ! $wpdb->get_var( "SHOW INDEX FROM {$table} WHERE Key_name = 'thread'" ) ) {
			$wpdb->query( "ALTER TABLE {$table} ADD KEY thread (student_id, teacher_id, id)" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange -- versioned one-time schema migration
		}

		// Older rows only knew a course; its author is the teacher end of that
		// thread, which is exactly what the old sender rule resolved to.
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$legacy = $wpdb->get_results( "SELECT id, sender_id, recipient_id, course_id FROM {$table} WHERE teacher_id = 0", ARRAY_A );
		foreach ( (array) $legacy as $row ) {
			$teacher_id = $row['course_id'] ? (int) get_post_field( 'post_author', (int) $row['course_id'] ) : 0;
			// No course to go on: the party who isn't the sender is the other end.
			if ( ! $teacher_id ) {
				$teacher_id = (int) $row['recipient_id'];
			}
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->update(
				$table,
				array(
					'teacher_id'   => $teacher_id,
					'from_teacher' => (int) $row['sender_id'] === $teacher_id ? 1 : 0,
				),
				array( 'id' => (int) $row['id'] )
			);
		}
	}
}
