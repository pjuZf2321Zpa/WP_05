<?php
namespace AcademyProGuardian\Database;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Enrollment-approval requests: a ward's enrollment held for guardian sign-off. */
class CreatePendingTable {
	public static function up( $prefix, $charset_collate ) {
		$table = $prefix . 'academy_guardian_pending';
		$sql   = "CREATE TABLE IF NOT EXISTS $table (
			id bigint(20) unsigned NOT NULL auto_increment,
			guardian_id bigint(20) unsigned NOT NULL,
			student_id bigint(20) unsigned NOT NULL,
			course_id bigint(20) unsigned NOT NULL,
			status varchar(20) NOT NULL DEFAULT 'pending',
			created_at timestamp DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			KEY guardian_id (guardian_id),
			KEY student_course (student_id, course_id)
		) $charset_collate;";
		dbDelta( $sql );
	}
}
