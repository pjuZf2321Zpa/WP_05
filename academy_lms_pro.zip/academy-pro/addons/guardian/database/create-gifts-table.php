<?php
namespace AcademyProGuardian\Database;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Course gifts: a guardian (or anyone) gifting a course to a learner. */
class CreateGiftsTable {
	public static function up( $prefix, $charset_collate ) {
		$table = $prefix . 'academy_guardian_gifts';
		$sql   = "CREATE TABLE IF NOT EXISTS $table (
			id bigint(20) unsigned NOT NULL auto_increment,
			gifter_id bigint(20) unsigned NOT NULL,
			student_id bigint(20) unsigned NOT NULL,
			course_id bigint(20) unsigned NOT NULL,
			order_id bigint(20) unsigned DEFAULT NULL,
			status varchar(20) NOT NULL DEFAULT 'completed',
			created_at timestamp DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			KEY gifter_id (gifter_id),
			KEY student_id (student_id)
		) $charset_collate;";
		dbDelta( $sql );
	}
}
