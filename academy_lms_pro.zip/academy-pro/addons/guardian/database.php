<?php
namespace AcademyProGuardian;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Database {

	public static function init() {
		// Tables are created by the installer; nothing to register on init.
	}

	public static function create_initial_custom_table() {
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		global $wpdb;
		$prefix          = $wpdb->prefix;
		$charset_collate = $wpdb->get_charset_collate();
		Database\CreatePendingTable::up( $prefix, $charset_collate );
		Database\CreateMessagesTable::up( $prefix, $charset_collate );
		Database\CreateGiftsTable::up( $prefix, $charset_collate );
	}
}
