<?php
namespace AcademyProGuardian;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Academy\Guardian\Store;

/**
 * Parental controls — enrollment approval.
 *
 * When a ward whose guardian requires approval enrolls, the enrollment is held
 * as `processing` (not active) and a pending request is recorded + the guardian
 * is notified. Approving flips the held enrollment to `completed`.
 */
class Controls {

	public static function init() {
		$self = new self();
		add_filter( 'academy/course/enroll_data', array( $self, 'maybe_hold_enrollment' ) );
	}

	public function maybe_hold_enrollment( $data ) {
		// Only intervene on would-be-active enrollments.
		if ( empty( $data['post_status'] ) || 'completed' !== $data['post_status'] ) {
			return $data;
		}
		$student_id = (int) ( $data['post_author'] ?? 0 );
		$course_id  = (int) ( $data['post_parent'] ?? 0 );
		if ( ! $student_id || ! $course_id ) {
			return $data;
		}

		foreach ( Store::get_guardians( $student_id ) as $guardian_id ) {
			$controls = Helper::get_child_controls( $guardian_id, $student_id );
			if ( empty( $controls['require_approval'] ) ) {
				continue;
			}
			// Hold it and record a pending request for this guardian.
			$data['post_status'] = 'processing';
			$this->record_pending( $guardian_id, $student_id, $course_id );
		}

		return $data;
	}

	private function record_pending( $guardian_id, $student_id, $course_id ) {
		global $wpdb;
		$table = Helper::pending_table();
		// Dedupe: one open request per (guardian, student, course).
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- only $wpdb-prefixed table names, whitelisted columns and intval/placeholder lists are interpolated; values are prepared
		$exists = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT id FROM {$table} WHERE guardian_id = %d AND student_id = %d AND course_id = %d AND status = 'pending'",
			$guardian_id, $student_id, $course_id
		) );
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		if ( $exists ) {
			return;
		}
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->insert( $table, array(
			'guardian_id' => (int) $guardian_id,
			'student_id'  => (int) $student_id,
			'course_id'   => (int) $course_id,
		) );

		$guardian = get_user_by( 'id', $guardian_id );
		if ( $guardian && is_email( $guardian->user_email ) ) {
			$student = get_user_by( 'id', $student_id );
			// phpcs:disable WordPressVIPMinimum.Functions.RestrictedFunctions.wp_mail_wp_mail -- single transactional email
			wp_mail(
				$guardian->user_email,
				esc_html__( 'Approval needed: course enrollment', 'academy-pro' ),
				sprintf(
					/* translators: 1: learner, 2: course */
					esc_html__( '%1$s requested to enroll in "%2$s". Approve it from your family dashboard.', 'academy-pro' ),
					$student ? $student->display_name : esc_html__( 'Your child', 'academy-pro' ),
					get_the_title( $course_id )
				)
			);
			// phpcs:enable WordPressVIPMinimum.Functions.RestrictedFunctions.wp_mail_wp_mail
		}
	}

	/**
	 * Approve a pending request: flip the held enrollment to completed.
	 *
	 * @param int $pending_id
	 */
	public static function approve( $pending_id ) {
		global $wpdb;
		$table = Helper::pending_table();
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", (int) $pending_id ), ARRAY_A );
		if ( ! $row || 'pending' !== $row['status'] ) {
			return false;
		}

		$enrolled = \Academy\Helper::is_enrolled( (int) $row['course_id'], (int) $row['student_id'], 'any' );
		if ( $enrolled && 'processing' === $enrolled->enrolled_status ) {
			wp_update_post( array(
				'ID' => $enrolled->ID,
				'post_status' => 'completed'
			) );
			clean_post_cache( $enrolled->ID );
		} else {
			\Academy\Helper::do_enroll( (int) $row['course_id'], (int) $row['student_id'] );
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->update( $table, array( 'status' => 'approved' ), array( 'id' => (int) $pending_id ) );
		return true;
	}

	public static function reject( $pending_id ) {
		global $wpdb;
		$table = Helper::pending_table();
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", (int) $pending_id ), ARRAY_A );
		if ( ! $row ) {
			return false;
		}
		// Remove the held enrollment if present.
		$enrolled = \Academy\Helper::is_enrolled( (int) $row['course_id'], (int) $row['student_id'], 'any' );
		if ( $enrolled && 'processing' === $enrolled->enrolled_status ) {
			wp_trash_post( $enrolled->ID );
		}
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->update( $table, array( 'status' => 'rejected' ), array( 'id' => (int) $pending_id ) );
		return true;
	}
}
