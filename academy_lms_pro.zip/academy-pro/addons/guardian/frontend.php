<?php
namespace AcademyProGuardian;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Pro guardian dashboard UI. Hooks the seams the free "My Family" dashboard
 * exposes:
 *  - `dashboard_before_children` → pending-enrollment-approval notice (above table)
 *  - `table_controls`            → per-child parental controls (table cell)
 *  - `dashboard_after_children`  → page scripts (approve/reject + save controls)
 * and registers a dedicated "Messages" dashboard route for instructor messaging.
 * All actions go through the pro family/* REST endpoints.
 */
class Frontend {

	const ROUTES_VERSION = '2';

	public static function init() {
		$self = new self();

		// My Family page seams.
		add_action( 'academy/guardian/dashboard_before_children', array( $self, 'render_approvals' ), 10, 2 );
		add_action( 'academy/guardian/table_controls', array( $self, 'render_controls_cell' ), 10, 1 );
		add_action( 'academy/guardian/dashboard_after_children', array( $self, 'render_scripts' ), 10, 2 );

		// Dedicated "Messages" dashboard route.
		add_filter( 'academy/frontend_dashboard_menu_items', array( $self, 'add_messages_menu_item' ) );
		add_action( 'academy_frontend_dashboard_guardian-messages_endpoint', array( $self, 'render_messages_page' ) );

		$self->maybe_flush_routes();
	}

	/**
	 * Register the "Messages" tab on the student dashboard.
	 *
	 * @param array $items
	 */
	public function add_messages_menu_item( $items ) {
		$items['guardian-messages'] = array(
			'label'    => __( 'Family Messages', 'academy-pro' ),
			'area'     => 'family',
			'icon'     => 'academy-icon academy-icon--chat',
			'public'   => self::may_use_messages(),
			'priority' => 13,
		);
		return $items;
	}

	/**
	 * Both ends of the conversation get this page.
	 *
	 * It was guardian-only, which left the teacher being written to with
	 * nowhere to read it — the messages simply arrived as email and the reply
	 * had to happen outside Academy.
	 */
	public static function may_use_messages() {
		if ( ! is_user_logged_in() || ! Settings::messaging_enabled() ) {
			return false;
		}
		if ( current_user_can( 'manage_academy_guardian' ) ) {
			return true;
		}
		// Anyone who teaches, and any learner or guardian with a family link.
		if ( in_array( 'academy_instructor', (array) wp_get_current_user()->roles, true ) ) {
			return true;
		}
		$user_id = get_current_user_id();
		if ( \Academy\Guardian\Store::get_children( $user_id ) ) {
			return true;
		}
		return (bool) \Academy\Guardian\Store::get_guardians( $user_id );
	}

	/**
	 * Flush rewrite rules once so the new dashboard route resolves. The menu
	 * item filter is already registered above, so the flush picks it up.
	 */
	private function maybe_flush_routes() {
		if ( \Academy\Options::get( \Academy\Options::PRO_DB_VERSIONS, 'guardian_routes' ) === self::ROUTES_VERSION ) {
			return;
		}
		// Only from wp-admin. Academy builds its dashboard rewrite rules from
		// the menu, and the menu is capability-dependent — so a flush that
		// happens to land on an anonymous front-end request writes rules with
		// every instructor-only endpoint missing, and those pages 404 until
		// something flushes again from a privileged context.
		if ( ! is_admin() ) {
			return;
		}
		\Academy\Helper::flush_rewrite_rules();
		\Academy\Options::set( \Academy\Options::PRO_DB_VERSIONS, 'guardian_routes', self::ROUTES_VERSION );
	}

	/**
	 * Pending enrollment approvals — rendered above the children table.
	 *
	 * @param int   $guardian_id
	 * @param mixed $children
	 */
	public function render_approvals( $guardian_id, $children ) {
		global $wpdb;
		$table   = Helper::pending_table();
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$pending = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE guardian_id = %d AND status = 'pending' ORDER BY id DESC", (int) $guardian_id ), ARRAY_A );

		if ( empty( $pending ) ) {
			return;
		}

		\AcademyPro\Helper::get_template(
			'frontend-dashboard/pages/partials/guardian-approvals.php',
			array( 'pending' => $pending )
		);
	}

	/**
	 * Per-child controls, injected into the table's "Parental controls" cell.
	 *
	 * @param mixed $child
	 */
	public function render_controls_cell( $child ) {
		\AcademyPro\Helper::get_template(
			'frontend-dashboard/pages/partials/guardian-controls.php',
			array(
				'child'    => $child,
				'controls' => Helper::get_child_controls( get_current_user_id(), $child['id'] ),
			)
		);
	}

	/**
	 * Page-level scripts for approve/reject + save-controls (My Family page).
	 *
	 * @param int   $guardian_id
	 * @param mixed $children
	 */
	public function render_scripts( $guardian_id, $children ) {
		\AcademyPro\Helper::get_template( 'frontend-dashboard/pages/partials/guardian-scripts.php' );
	}

	/** The dedicated "Messages" dashboard route. */
	public function render_messages_page() {
		if ( ! self::may_use_messages() ) {
			echo '<p class="academy-guardian-restricted">' . esc_html__( 'This area is available to families and the teachers they write to.', 'academy-pro' ) . '</p>';
			return;
		}

		$user_id  = get_current_user_id();
		$children = array();
		foreach ( \Academy\Guardian\Store::get_children( $user_id ) as $student_id ) {
			$children[] = \Academy\Guardian\Store::child_profile( $student_id );
		}
		// A learner writes to their own teachers, with no guardian in between.
		if ( ! $children && \Academy\Guardian\Store::get_guardians( $user_id ) ) {
			$children[] = \Academy\Guardian\Store::child_profile( $user_id );
		}

		\AcademyPro\Helper::get_template(
			'frontend-dashboard/pages/guardian-messages.php',
			array( 'children' => $children )
		);
	}
}
