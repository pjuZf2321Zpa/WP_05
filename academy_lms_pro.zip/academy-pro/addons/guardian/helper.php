<?php
namespace AcademyProGuardian;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Helper {

	public static function pending_table() {
		global $wpdb;
		return $wpdb->prefix . 'academy_guardian_pending';
	}

	public static function messages_table() {
		global $wpdb;
		return $wpdb->prefix . 'academy_guardian_messages';
	}

	public static function gifts_table() {
		global $wpdb;
		return $wpdb->prefix . 'academy_guardian_gifts';
	}

	/**
	 * Per-guardian control settings, keyed by child id:
	 * [ child_id => [ require_approval: bool, spending_limit: float ] ]
	 *
	 * @param int $guardian_id
	 */
	public static function get_controls( $guardian_id ) {
		$data = get_user_meta( (int) $guardian_id, 'academy_guardian_controls', true );
		return is_array( $data ) ? $data : array();
	}

	public static function get_child_controls( $guardian_id, $student_id ) {
		$all = self::get_controls( $guardian_id );
		$row = $all[ (int) $student_id ] ?? array();
		return wp_parse_args( $row, array(
			'require_approval' => false,
			'spending_limit'   => 0,
		) );
	}

	public static function set_child_controls( $guardian_id, $student_id, $settings ) {
		$all = self::get_controls( $guardian_id );
		$all[ (int) $student_id ] = array(
			'require_approval' => ! empty( $settings['require_approval'] ),
			'spending_limit'   => isset( $settings['spending_limit'] ) ? (float) $settings['spending_limit'] : 0,
		);
		update_user_meta( (int) $guardian_id, 'academy_guardian_controls', $all );
		return $all[ (int) $student_id ];
	}

	/**
	 * Total gifted spend by a guardian on a given ward (for spending limits).
	 *
	 * @param int $guardian_id
	 * @param int $student_id
	 */
	public static function gifted_spend( $guardian_id, $student_id ) {
		global $wpdb;
		$table = self::gifts_table();
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- only $wpdb-prefixed table names, whitelisted columns and intval/placeholder lists are interpolated; values are prepared
		$rows = $wpdb->get_col( $wpdb->prepare(
			"SELECT course_id FROM {$table} WHERE gifter_id = %d AND student_id = %d AND status = 'completed'",
			(int) $guardian_id, (int) $student_id
		) );
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$sum = 0.0;
		foreach ( (array) $rows as $course_id ) {
			$sum += (float) get_post_meta( (int) $course_id, 'academy_course_price', true );
		}
		return $sum;
	}

	public static function manager_check() {
		if ( ! is_user_logged_in() || ! current_user_can( 'manage_academy_guardian' ) ) {
			return new \WP_Error( 'unauthorized', __( 'You are not allowed to manage guardians.', 'academy-pro' ), array( 'status' => 401 ) );
		}
		return true;
	}
}
