<?php
namespace AcademyProGuardian;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Academy\Guardian\Store;

/**
 * Pro guardian emails: weekly progress digest, inactivity nudges, and a richer
 * course-completion email (supersedes core's plain one).
 */
class Emails {

	const DIGEST_HOOK     = 'academy_guardian_weekly_digest';
	const INACTIVITY_HOOK = 'academy_guardian_inactivity_check';

	public static function init() {
		$self = new self();
		add_filter( 'cron_schedules', array( $self, 'add_weekly_schedule' ) ); // phpcs:ignore WordPress.WP.CronInterval.CronSchedulesInterval
		add_action( self::DIGEST_HOOK, array( $self, 'send_weekly_digests' ) );
		add_action( self::INACTIVITY_HOOK, array( $self, 'run_inactivity_check' ) );

		// Replace core's plain completion email with a richer one.
		add_filter( 'academy/guardian/send_completion_email', '__return_false' );
		add_action( 'academy/guardian/notify', array( $self, 'on_notify' ), 10, 2 );

		// Self-heal scheduling if the events were cleared.
		if ( ! wp_next_scheduled( self::DIGEST_HOOK ) || ! wp_next_scheduled( self::INACTIVITY_HOOK ) ) {
			self::schedule_events();
		}
	}

	public function add_weekly_schedule( $schedules ) {
		if ( ! isset( $schedules['weekly'] ) ) {
			$schedules['weekly'] = array(
				'interval' => WEEK_IN_SECONDS,
				'display' => __( 'Once Weekly', 'academy-pro' )
			);
		}
		return $schedules;
	}

	public static function schedule_events() {
		if ( ! wp_next_scheduled( self::DIGEST_HOOK ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'weekly', self::DIGEST_HOOK );
		}
		if ( ! wp_next_scheduled( self::INACTIVITY_HOOK ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', self::INACTIVITY_HOOK );
		}
	}

	public static function unschedule_events() {
		wp_clear_scheduled_hook( self::DIGEST_HOOK );
		wp_clear_scheduled_hook( self::INACTIVITY_HOOK );
	}

	/**
	 * Richer per-guardian completion email (core's is suppressed above).
	 *
	 * @param string $type
	 * @param array  $data
	 */
	public function on_notify( $type, $data ) {
		if ( 'course_completed' !== $type ) {
			return;
		}
		$guardian = get_user_by( 'id', $data['guardian_id'] ?? 0 );
		if ( ! $guardian || ! is_email( $guardian->user_email ) ) {
			return;
		}
		$student = get_user_by( 'id', $data['student_id'] ?? 0 );
		$name    = $student ? $student->display_name : __( 'Your child', 'academy-pro' );
		$course  = get_the_title( $data['course_id'] ?? 0 );

		$subject = sprintf( /* translators: %s: learner */ esc_html__( '🎉 %s earned a course completion', 'academy-pro' ), $name );
		$body    = sprintf(
			/* translators: 1: learner, 2: course */
			esc_html__( "Congratulations! %1\$s just completed \"%2\$s\".\n\nOpen your family dashboard to review their progress and see if a certificate is available.", 'academy-pro' ),
			$name,
			$course
		);
		wp_mail( $guardian->user_email, $subject, $body ); // phpcs:ignore WordPressVIPMinimum.Functions.RestrictedFunctions.wp_mail_wp_mail -- single transactional email
	}

	// ---------------------------------------------------------------------

	/**
	 * Sends each guardian their weekly digest email.
	 */
	public function send_weekly_digests() {
		$guardians = get_users( array(
			'role' => 'academy_guardian',
			'fields' => array( 'ID', 'user_email', 'display_name' )
		) );
		foreach ( $guardians as $g ) {
			if ( ! is_email( $g->user_email ) ) {
				continue;
			}
			$children = Store::get_children( $g->ID );
			if ( empty( $children ) ) {
				continue;
			}

			$lines = array();
			foreach ( $children as $student_id ) {
				$snap = Store::child_snapshot( $student_id );
				$lines[] = sprintf(
					/* translators: 1: child name, 2: enrolled, 3: completed, 4: certificates */
					esc_html__( '- %1$s: %2$d enrolled, %3$d completed, %4$d certificates', 'academy-pro' ),
					$snap['name'],
					(int) $snap['enrolled_count'],
					(int) $snap['completed_count'],
					(int) $snap['certificate_count']
				);
			}
			if ( empty( $lines ) ) {
				continue;
			}

			$body = esc_html__( "Here is this week's learning summary for your family:", 'academy-pro' ) . "\n\n" . implode( "\n", $lines );
			wp_mail( $g->user_email, esc_html__( 'Your family learning digest', 'academy-pro' ), $body ); // phpcs:ignore WordPressVIPMinimum.Functions.RestrictedFunctions.wp_mail_wp_mail -- single transactional email
		}//end foreach
	}

	public function run_inactivity_check() {
		$days      = (int) apply_filters( 'academy/guardian/inactivity_days', 7 );
		$threshold = time() - ( $days * DAY_IN_SECONDS );
		$guardians = get_users( array(
			'role' => 'academy_guardian',
			'fields' => array( 'ID', 'user_email' )
		) );

		foreach ( $guardians as $g ) {
			if ( ! is_email( $g->user_email ) ) {
				continue;
			}
			foreach ( Store::get_children( $g->ID ) as $student_id ) {
				$enrolled = \Academy\Helper::get_enrolled_courses_ids_by_user( $student_id );
				if ( empty( $enrolled ) ) {
					continue;
				}
				$last = $this->last_activity_ts( $student_id );
				if ( $last && $last < $threshold ) {
					$student = get_user_by( 'id', $student_id );
					// phpcs:disable WordPressVIPMinimum.Functions.RestrictedFunctions.wp_mail_wp_mail -- single transactional email
					wp_mail(
						$g->user_email,
						esc_html__( 'Learning reminder', 'academy-pro' ),
						sprintf(
							/* translators: 1: learner, 2: days */
							esc_html__( "%1\$s hasn't made progress in %2\$d days. A gentle nudge might help them get back on track.", 'academy-pro' ),
							$student ? $student->display_name : esc_html__( 'Your child', 'academy-pro' ),
							$days
						)
					);
					// phpcs:enable WordPressVIPMinimum.Functions.RestrictedFunctions.wp_mail_wp_mail
				}
			}//end foreach
		}//end foreach
	}

	/**
	 * Best-effort last-activity timestamp: newest of the learner's completion
	 * records and enrollment dates.
	 *
	 * @param int $student_id
	 */
	private function last_activity_ts( $student_id ) {
		global $wpdb;
		// Latest completion comment.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$comment = $wpdb->get_var( $wpdb->prepare(
			"SELECT MAX(comment_date_gmt) FROM {$wpdb->comments} WHERE user_id = %d AND comment_type = 'course_completed' AND comment_agent = 'academy'",
			(int) $student_id
		) );
		// Latest enrollment.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$enroll = $wpdb->get_var( $wpdb->prepare(
			"SELECT MAX(post_date_gmt) FROM {$wpdb->posts} WHERE post_author = %d AND post_type = 'academy_enrolled'",
			(int) $student_id
		) );

		$ts = 0;
		foreach ( array( $comment, $enroll ) as $d ) {
			if ( $d ) {
				$ts = max( $ts, (int) strtotime( $d . ' UTC' ) );
			}
		}
		return $ts;
	}
}
