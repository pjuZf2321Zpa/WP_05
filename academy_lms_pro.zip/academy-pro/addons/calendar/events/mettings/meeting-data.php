<?php

namespace AcademyProCalendar\Events\Mettings;

use AcademyProCalendar\Events\QueryAbstract;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class MeetingData extends QueryAbstract {

	public string $select    = 'pm.meta_value, pm.post_id';
	public string $count_col = 'p.ID';

	public int $per_page       = 0;
	public string $order_direction = 'DESC';
	public ?string $order_by     = 'p.ID';

	public function __construct() {
		global $wpdb;

		$current_user_id = get_current_user_id();

		$this->table  = $wpdb->postmeta . ' pm';
		// Use LEFT JOINs for the enrollment record and the co-instructor
		// usermeta record so that courses the current user is NOT enrolled
		// in are still selectable as long as they are the course author OR
		// an instructor assigned to the course (multi-instructor addon
		// stores this as usermeta 'academy_instructor_course_id' =>
		// course_id, rather than only via post_author). The WHERE clause
		// below allows the row when any of these conditions is true.
		$this->join   = "
			INNER JOIN {$wpdb->posts} p
				ON p.ID = pm.post_id
			LEFT JOIN {$wpdb->posts} pe
				ON p.ID = pe.post_parent AND 
				pe.post_type = %s AND 
				pe.post_author = %d AND
				pe.post_status = %s
			LEFT JOIN {$wpdb->usermeta} um
				ON um.user_id = %d AND
				um.meta_key = %s AND
				um.meta_value = p.ID
			WHERE 
				pm.meta_key = %s AND 
				pm.meta_value LIKE %s AND
				( pe.ID IS NOT NULL OR p.post_author = %d OR um.umeta_id IS NOT NULL )
		";

		$this->args[]   = 'academy_enrolled';
		$this->args[]   = $current_user_id;
		$this->args[]   = 'completed';
		$this->args[]   = $current_user_id;
		$this->args[]   = 'academy_instructor_course_id';
		$this->args[]   = 'academy_course_curriculum';
		$this->args[]   = '%\"type\";s:7:\"meeting\"%';
		$this->args[]   = $current_user_id;
	}

	public static function get( int $year, int $month ): array {
		$ins = new self();
		$data = $ins->get_events_data();
		$ids = [];
		$post_ids = [];

		// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value 
		foreach ( $data['data'] ?? [] as ['meta_value' => $item, 'post_id' => $post_id] ) {
			foreach ( maybe_unserialize( $item ) ?? [] as $curriculum ) {
				foreach ( $curriculum['topics'] ?? [] as $c ) {
					if ( ( 'meeting' === $c['type'] ?? '' ) &&
						! empty( $c['id'] ?? '' )
					) {
						$ids[] = $c['id'];
						$post_ids[ $c['id'] ] = $post_id;
					}
				}
			}
		}
		$output = [];
		if ( ! empty( $ids ) ) {

			$output['meet'] = ( new Meet( $year, $month, $ids ) )
				->get_events_data();

			$output['zoom'] = ( new Zoom( $year, $month, $ids ) )
				->get_events_data();

			foreach ( [ 'meet', 'zoom' ] as $item ) {
				foreach ( $output[ $item ]['data'] as $key => $m ) {
					$output[ $item ]['data'][ $key ]['link'] = isset( $post_ids[ $m['ID'] ] ) ? get_permalink( $post_ids[ $m['ID'] ] ) : '';

					$start_dt = new \DateTime( $m['start_date'], new \DateTimeZone( $m['timezone'] ) );
					$output[ $item ]['data'][ $key ]['start_date'] = $start_dt->format( 'c' ); // store formatted

					if ( 'meet' === $item ) {
						$end_dt = clone $start_dt;
						$end_dt->modify( "+{$m['duration']} minutes" );

						$output[ $item ]['data'][ $key ]['end_date'] = $end_dt->format( 'c' );

						$intv = $start_dt->diff( $end_dt );
						$output[ $item ]['data'][ $key ]['duration'] = sprintf(
							'%d %s %d %s %d %s',
							( $intv->days * 24 ) + $intv->h,
							__( 'hr', 'academy-pro' ),
							$intv->i,
							__( 'min', 'academy-pro' ),
							$intv->s,
							__( 's', 'academy-pro' )
						);
					} else {
						$end_dt = clone $start_dt;
						$end_dt->modify( "+{$m['duration']} minutes" );

						$output[ $item ]['data'][ $key ]['end_date'] = $end_dt->format( 'c' );
						$output[ $item ]['data'][ $key ]['duration'] = sprintf(
							'%d %s',
							$m['duration'],
							__( 'min', 'academy-pro' )
						);
					}//end if
				}//end foreach
			}//end foreach
		}//end if
		return $output;
	}
}
