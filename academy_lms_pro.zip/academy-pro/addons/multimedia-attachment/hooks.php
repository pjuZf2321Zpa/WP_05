<?php
namespace AcademyProMultimediaAttachment;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Hooks {

	public static function init() {
		$self = new self();
		add_action( 'rest_api_init', [ $self, 'register_academy_courses_meta' ] );
		// attachment file
		add_action( 'academy/templates/single_course_content', [ $self, 'academy_single_course_attachment_file' ], 26 );
	}

	public function register_academy_courses_meta() {
		register_meta(
			'post',
			'academy_course_attachments',
			array(
				'object_subtype' => 'academy_courses',
				'type'           => 'array',
				'single'         => true,
				'show_in_rest'   => [
					'schema' => array(
						'items' => array(
							'type'       => 'integer',
						),
					),
				],
			)
		);
	}

	public function academy_single_course_attachment_file() {
		$course_id = get_the_ID();
		if ( ! \Academy\Helper::is_enrolled( $course_id, get_current_user_id() ) ) {
			return;
		}

		$attachments = get_post_meta( $course_id, 'academy_course_attachments', true );

		\AcademyPro\Helper::get_template(
			'multimedia-attachment/attachment-file.php',
			[
				'attachments' => $attachments
			]
		);
	}
}
