<?php
namespace AcademyProMultimediaAttachment;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Academy\Interfaces\AddonInterface;

final class MultimediaAttachment implements AddonInterface {
	private $addon_name = 'multimedia-attachment';
	private function __construct() {
		$this->define_constants();
		$this->init_addon();
	}
	public static function init() {
		static $instance = false;

		if ( ! $instance ) {
			$instance = new self();
		}

		return $instance;
	}
	public function define_constants() {
		/**
		 * Defines CONSTANTS for Whole Addon.
		 */
		define( 'ACADEMY_MULTIMEDIA_ATTACHMENT_VERSION', '0.1' );
		define( 'ACADEMY_PRO_MULTIMEDIA_ATTACHMENT_DIR_PATH', ACADEMY_PRO_ADDONS_DIR_PATH . 'attachments/' );
	}
	public function init_addon() {
		// fire addon activation hook
		add_action( "academy/addons/activated_{$this->addon_name}", array( $this, 'addon_activation_hook' ) );
		// if disable then stop running addon
		if ( ! \Academy\Helper::get_addon_active_status( $this->addon_name ) ) {
			return;
		}
		Hooks::init();
	}

	public function load_dependency() {
	}

	public function addon_activation_hook() {
	}
}
