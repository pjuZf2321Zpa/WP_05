<?php
namespace AcademyProAdvancedAnalytics;

use AcademyProAdvancedAnalytics\Database\CreateCourseAnalyticsTable;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


class Database {
	public static function init() {
		$self = new self();
		$self->create_database();
	}

	public function create_database(): void {
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		global $wpdb;
		$prefix = $wpdb->prefix;
		$charset_collate = $wpdb->get_charset_collate();
		CreateCourseAnalyticsTable::create( $prefix, $charset_collate );
	}
}
