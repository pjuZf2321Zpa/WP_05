<?php
namespace AcademyProAdvancedAnalytics\Database;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CreateCourseAnalyticsTable {
	public static function create( $prefix, $charset_collate ): void {
		$table_name = $prefix . ACADEMY_PLUGIN_SLUG . '_course_view_analytics';
		$sql        = "CREATE TABLE IF NOT EXISTS $table_name (
			ID bigint(20) unsigned NOT NULL auto_increment,
			course_id bigint(20) NOT NULL,
			visitor_ip varchar(100) NOT NULL,
			country varchar(100) NOT NULL,
			cities varchar(100) NOT NULL,
			platform varchar(100) NOT NULL,
			browser varchar(100) NOT NULL,
			device varchar(100) NOT NULL,
			PRIMARY KEY (ID)
		) $charset_collate;";
		dbDelta( $sql );
	}
}
