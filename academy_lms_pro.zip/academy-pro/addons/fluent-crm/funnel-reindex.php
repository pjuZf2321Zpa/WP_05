<?php

namespace AcademyProFluentCRM;

use FluentCrm\App\Hooks\Handlers\FunnelHandler;
use FluentCrm\App\Models\Funnel;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Keeps FluentCRM's active-trigger cache in sync for Academy automations.
 *
 * Since FluentCRM 3.1.0 ("Core automation trigger registration timing issue"),
 * FunnelHandler no longer queries published funnels live on every request. It
 * attaches WordPress listeners only for the trigger names cached in the
 * `fluentcrm_funnel_settings` option, and that option is rebuilt only when a
 * funnel is saved through the FluentCRM admin (FunnelHandler::resetFunnelIndexes()).
 * FluentCRM ships no upgrade migration to backfill it, so any Academy funnel that
 * was published before the site updated to 3.1.x is absent from the cache: its
 * trigger never gets a listener and the automation silently stops firing on course
 * enrollment / completion / lesson completion.
 *
 * This runs on `fluentcrm_loaded` (FluentCRM is fully booted, and we are still ahead
 * of the init-time trigger registration passes). It heals whenever drift is actually
 * present — a published Academy funnel whose trigger is missing from the cache — so it
 * recovers no matter how the cache got out of sync (a FluentCRM update that resets it,
 * a stale pre-3.1.x funnel, a manual reset), and on every occurrence rather than once.
 *
 * To stay cheap it is gated on a signature of the cache itself: while
 * `fluentcrm_funnel_settings` is unchanged since the last verification, the check
 * short-circuits on a free autoloaded-option comparison with no database query. The
 * funnel lookup runs only when the cache actually changes (funnel saved, FluentCRM
 * update, manual reset), and `resetFunnelIndexes()` runs only when drift is found.
 */
class FunnelReindex {

	/**
	 * Stores a signature of the `fluentcrm_funnel_settings` value we last verified,
	 * so an unchanged cache skips the database lookup entirely.
	 */
	const SIGNATURE_OPTION = 'academy_fcrm_cache_signature';

	/**
	 * Trigger hooks owned by the Academy LMS FluentCRM integration.
	 */
	const ACADEMY_TRIGGERS = [
		'academy/course/after_enroll',
		'academy/admin/course_complete_after',
		'academy/frontend/after_mark_topic_complete',
	];

	/**
	 * Invoked from Integrations::init() inside the `fluentcrm_loaded` callback, so
	 * FluentCRM is already loaded and we can run synchronously.
	 */
	public static function init() {
		if ( ! class_exists( Funnel::class ) || ! class_exists( FunnelHandler::class ) ) {
			return;
		}

		$cached    = (array) get_option( 'fluentcrm_funnel_settings', [] );
		$signature = md5( self::signature_payload( $cached ) );

		// Cache unchanged since the last verification — nothing to do (no query).
		if ( get_option( self::SIGNATURE_OPTION ) === $signature ) {
			return;
		}

		if ( self::has_unindexed_academy_funnel( $cached ) ) {
			// Rebuild the full active-trigger index (covers every integration's
			// published funnels and benchmarks, not just Academy's).
			( new FunnelHandler() )->resetFunnelIndexes();

			// Re-read: resetFunnelIndexes() just rewrote the cache.
			$cached    = (array) get_option( 'fluentcrm_funnel_settings', [] );
			$signature = md5( self::signature_payload( $cached ) );
		}

		update_option( self::SIGNATURE_OPTION, $signature, true );
	}

	/**
	 * Build an order-independent signature payload for the cache, so a reordered
	 * but equivalent active-trigger list does not force a needless re-verification.
	 *
	 * @param array $cached Current `fluentcrm_funnel_settings` value.
	 * @return string
	 */
	private static function signature_payload( array $cached ): string {
		$cached = array_values( array_unique( array_map( 'strval', $cached ) ) );
		sort( $cached );

		return (string) wp_json_encode( $cached );
	}

	/**
	 * Whether any published Academy funnel's trigger is missing from the given
	 * active-trigger cache (i.e. its listener would never be attached).
	 *
	 * @param array $cached Current `fluentcrm_funnel_settings` value.
	 * @return bool
	 */
	private static function has_unindexed_academy_funnel( array $cached ): bool {
		$published = Funnel::where( 'status', 'published' )
			->whereIn( 'trigger_name', self::ACADEMY_TRIGGERS )
			->get();

		foreach ( $published as $funnel ) {
			if ( ! in_array( $funnel->trigger_name, $cached, true ) ) {
				return true;
			}
		}

		return false;
	}
}
