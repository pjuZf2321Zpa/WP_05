<?php

namespace AcademyProWoocommerce\Ajax;

use Academy\Classes\AbstractAjaxHandler;
use Academy\Classes\Sanitizer;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Admin extends AbstractAjaxHandler {
	protected $namespace = 'academy_pro_woo';
	public function __construct() {
		$this->actions = [
			'get_product' => array(
				'callback' => array( $this, 'woo_get_product' ),
				'capability' => 'manage_academy_instructor',
			),
			'create_or_update_product' => array(
				'callback' => array( $this, 'woo_create_or_update_product' ),
				'capability' => 'manage_academy_instructor',
			)
		];
	}

	public function woo_get_product( $payload_data ) {
		$payload = Sanitizer::sanitize_payload([
			'productId' => 'integer',
		], $payload_data );

		$productId = isset( $payload['productId'] ) ? $payload['productId'] : 0;
		// A course can still point at a product deleted in WooCommerce since;
		// reading that one throws ("Invalid product.") and 500s the request.
		if ( ! $productId || 'product' !== get_post_type( $productId ) || 'yes' !== get_post_meta( $productId, '_academy_product', true ) ) {
			wp_send_json_error( [
				'message' => esc_html__( 'Product not found', 'academy-pro' ),
			] );
		}
		$product = new \WC_Product_Simple( $productId );

		$response = [
			'product_id' => $productId,
		];
		if ( $product->get_regular_price() ) {
			$response['regular_price'] = (float) $product->get_regular_price();
		}
		if ( $product->get_sale_price() ) {
			$response['sale_price'] = (float) $product->get_sale_price();
		}
		wp_send_json_success( $response );
	}

	public function woo_create_or_update_product( $payload_data ) {
		$payload = Sanitizer::sanitize_payload([
			'id'                => 'integer',
			'title'             => 'string',
			'slug'              => 'string',
			'payment_id'        => 'integer',
			'regular_price'     => 'string',
			'sale_price'        => 'string',
		], $payload_data );

		$course_id = (int) isset( $payload['id'] ) ? $payload['id'] : 0;
		$product_id = isset( $payload['payment_id'] ) ? $payload['payment_id'] : 0;
		$course_title = isset( $payload['title'] ) ? $payload['title'] : '';
		$course_slug = isset( $payload['slug'] ) ? $payload['slug'] : '';
		$regular_price = isset( $payload['regular_price'] ) ? $payload['regular_price'] : '';
		$sale_price = isset( $payload['sale_price'] ) ? $payload['sale_price'] : '';

		if ( 'undefined' === $course_id || 0 === $course_id ) {
			wp_send_json_error(
				esc_html__( 'Save Course Then Create Product', 'academy-pro' )
			);
		}
		// Only a real course the user manages: an administrator or its instructor.
		if (
			'academy_courses' !== get_post_type( $course_id ) ||
			( ! current_user_can( 'manage_options' ) && ! \Academy\Helper::is_instructor_of_this_course( get_current_user_id(), $course_id ) )
		) {
			wp_send_json_error( esc_html__( 'You are not allowed to change this course.', 'academy-pro' ), 403 );
		}
		// A price alone is enough to create the product, so the builder may
		// send no title (e.g. the title field was cleared after the course was
		// saved). Name it after the saved course rather than blanking the name.
		if ( '' === $course_title ) {
			$course_title = get_post_field( 'post_title', $course_id, 'raw' );
		}
		$product_id = get_post_meta( $course_id, 'academy_course_product_id', true );
		// The linked product may have been deleted in WooCommerce since —
		// reading it would throw. Create a new one and relink the course.
		if ( $product_id && 'product' !== get_post_type( $product_id ) ) {
			$product_id = 0;
		}
		// Only ever edit a product that was created for courses; a course must not
		// be able to point at (and then rewrite) an unrelated store product.
		if ( $product_id && 'yes' !== get_post_meta( $product_id, '_academy_product', true ) ) {
			$product_id = 0;
		}
		// ...and never one that belongs to a different course.
		if ( $product_id ) {
			$other_course = get_posts( [
				'post_type'      => 'academy_courses',
				'post_status'    => 'any',
				'fields'         => 'ids',
				'posts_per_page' => 1,
				'post__not_in'   => [ $course_id ],
				'meta_key'       => 'academy_course_product_id', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
				'meta_value'     => $product_id, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
			] );
			if ( $other_course ) {
				$product_id = 0;
			}
		}

		// that's CRUD object
		$product = new \WC_Product_Simple( $product_id );
		$product->set_name( $course_title );
		$product->set_slug( $course_slug );
		$product->set_regular_price( $regular_price );
		if ( $sale_price ) {
			$product->set_sale_price( $sale_price );
		}
		$product_id = $product->save();

		if ( $product_id ) {
			update_post_meta( $product_id, '_academy_product', 'yes' );
		}
		if ( $course_id ) {
			update_post_meta( $course_id, 'academy_course_product_id', $product_id );
		}
		$response = [
			'product_id' => $product_id,
		];

		if ( $product->get_regular_price() ) {
			$response['regular_price'] = (float) $product->get_regular_price();
		}
		if ( $product->get_sale_price() ) {
			$response['sale_price'] = (float) $product->get_sale_price();
		}

		wp_send_json_success( $response );
	}
}
