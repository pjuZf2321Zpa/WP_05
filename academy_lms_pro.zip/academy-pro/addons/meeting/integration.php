<?php
namespace AcademyProMeeting;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Integration {
	public static function init() {
		$self = new self();
		$self->init_zoom();
		$self->init_google_meet();
		$self->init_common();
		add_filter( 'academy/admin/settings/base_default_data', array( $self, 'get_meeting_default_settings_data' ) );
		add_filter( 'academy/admin/settings/sanitize_payload', array( $self, 'sanitize_meeting_default_settings' ) );
		add_filter( 'academy/admin/settings/save', array( $self, 'save_meeting_settings_data' ), 11, 3 );
	}

	public function init_zoom() {
		Integration\Zoom::init();
	}

	public function init_google_meet() {
		Integration\GoogleMeet::init();
		Integration\GoogleMeetInvites::init();
	}

	public function init_common() {
		Integration\Common::init();
	}

	public function get_meeting_default_settings_data( $default_data ) {
		return array_merge(
			$default_data,
			array(
				'academy_meeting_api_handler_type' => 'individual'
			)
		);
	}

	public function sanitize_meeting_default_settings( $sanitize_data ) {
		return array_merge(
			$sanitize_data,
			array(
				'academy_meeting_api_handler_type' => 'string'
			)
		);
	}

	public function save_meeting_settings_data( $data, $payload, $default ) {
		$meet_type = $payload['academy_meeting_api_handler_type'] ?? $default['academy_meeting_api_handler_type'];
		return array_merge( $data,
			array(
				'academy_meeting_api_handler_type' => $meet_type
			)
		);
	}
}
