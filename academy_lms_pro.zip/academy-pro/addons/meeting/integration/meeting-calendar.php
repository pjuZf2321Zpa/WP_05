<?php
namespace AcademyProMeeting\Integration;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * One normalized view of an Academy meeting (Zoom or Google Meet) and its
 * iCalendar (.ics) form, for email invites.
 */
class MeetingCalendar {

	/**
	 * @param int $post_id Academy meeting post ID.
	 * @return array|null { type, title, description, start, end, timezone, link, password, cancelled }
	 *                    with start/end as Unix timestamps; null if unusable.
	 */
	public static function describe( $post_id ) {
		$type     = get_post_meta( $post_id, 'academy_meeting_type', true );
		$response = json_decode( (string) get_post_meta( $post_id, 'academy_meeting_response', true ), true );
		if ( ! is_array( $response ) ) {
			return null;
		}

		if ( 'zoom' === $type ) {
			$tz    = (string) ( $response['timezone'] ?? '' );
			$start = self::zoom_start( (string) ( $response['start_time'] ?? '' ), $tz );
			$end   = $start ? $start + ( (int) ( $response['duration'] ?? 30 ) ) * MINUTE_IN_SECONDS : false;
			$link  = (string) ( $response['join_url'] ?? '' );
			$pass  = (string) ( $response['password'] ?? '' );
		} else {
			$start = isset( $response['meetingDate'] ) ? strtotime( (string) $response['meetingDate'] ) : false;
			$end   = isset( $response['meetingDuration'] ) ? strtotime( (string) $response['meetingDuration'] ) : false;
			$link  = (string) ( $response['meetingLink'] ?? '' );
			$pass  = '';
			$tz    = (string) ( $response['meetingTimezone'] ?? '' );
		}
		if ( ! $start || ! $end ) {
			return null;
		}

		return array(
			'type'        => $type,
			'title'       => get_the_title( $post_id ),
			'description' => (string) get_post_field( 'post_content', $post_id ),
			'start'       => $start,
			'end'         => $end,
			'timezone'    => $tz ? $tz : 'UTC',
			'link'        => $link,
			'password'    => $pass,
			'cancelled'   => 'cancelled' === ( $response['meetingStatus'] ?? $response['status'] ?? '' ),
		);
	}

	/**
	 * Zoom returns start_time in UTC ("…Z"), but meetings edited by older
	 * versions stored the local time with no offset — read that in the
	 * meeting's own timezone.
	 *
	 * @param string $value    Stored start_time.
	 * @param string $timezone Meeting timezone.
	 * @return int|false Unix timestamp.
	 */
	private static function zoom_start( $value, $timezone ) {
		if ( '' === $value ) {
			return false;
		}
		if ( preg_match( '/(Z|[+-]\d{2}:?\d{2})$/', $value ) ) {
			return strtotime( $value );
		}
		try {
			$zone = new \DateTimeZone( $timezone ? $timezone : 'UTC' );
			return ( new \DateTime( $value, $zone ) )->getTimestamp();
		} catch ( \Exception $e ) {
			return strtotime( $value );
		}
	}

	/**
	 * An iCalendar event for the meeting. Re-sending with a higher sequence
	 * updates the same event in the student's calendar app.
	 *
	 * @param int $post_id  Academy meeting post ID.
	 * @param int $sequence Revision number (0 for the first invite).
	 * @return string|null
	 */
	public static function ics( $post_id, $sequence = 0 ) {
		$m = self::describe( $post_id );
		if ( ! $m ) {
			return null;
		}
		$escape = function ( $text ) {
			return str_replace( array( '\\', ';', ',', "\r\n", "\n" ), array( '\\\\', '\\;', '\\,', '\\n', '\\n' ), (string) $text );
		};
		$details = trim( $m['description'] . "\n\n" . $m['link'] . ( $m['password'] ? "\n" . __( 'Passcode', 'academy-pro' ) . ': ' . $m['password'] : '' ) );
		$host    = wp_parse_url( home_url(), PHP_URL_HOST );
		$lines   = array(
			'BEGIN:VCALENDAR',
			'VERSION:2.0',
			'PRODID:-//Academy LMS//Meeting//EN',
			'METHOD:' . ( $m['cancelled'] ? 'CANCEL' : 'PUBLISH' ),
			'BEGIN:VEVENT',
			'UID:academy-meeting-' . (int) $post_id . '@' . $host,
			'SEQUENCE:' . (int) $sequence,
			'DTSTAMP:' . gmdate( 'Ymd\THis\Z' ),
			'DTSTART:' . gmdate( 'Ymd\THis\Z', $m['start'] ),
			'DTEND:' . gmdate( 'Ymd\THis\Z', $m['end'] ),
			'SUMMARY:' . $escape( $m['title'] ),
			'DESCRIPTION:' . $escape( $details ),
			'LOCATION:' . $escape( $m['link'] ),
			'URL:' . $escape( $m['link'] ),
			'STATUS:' . ( $m['cancelled'] ? 'CANCELLED' : 'CONFIRMED' ),
			'END:VEVENT',
			'END:VCALENDAR',
		);
		return implode( "\r\n", $lines ) . "\r\n";
	}
}
