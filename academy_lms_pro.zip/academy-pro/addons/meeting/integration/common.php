<?php
namespace AcademyProMeeting\Integration;

use AcademyProMeeting\Integration\Zoom;
use AcademyProMeeting\Integration\GoogleMeet;
use AcademyProMeeting\Integration\GoogleMeetInvites;
use AcademyProMeeting\Integration\ZoomInvites;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Common {

	public static function init() {
		$self = new self();
		add_action( 'wp_ajax_academy_pro_meeting/get_meeting_credentials', array( $self, 'get_meeting_credentials' ) );
		add_action( 'wp_ajax_academy_pro_meeting/frontend/render_meeting', array( $self, 'render_meeting' ) );
		add_action( 'wp_ajax_academy_pro_meeting/delete_meeting', array( $self, 'delete_meeting' ) );

		// Meetings hold join links, passwords and Zoom's host start_url; only
		// staff screens read them over REST (students use render_meeting).
		add_filter( 'rest_pre_dispatch', array( $self, 'restrict_meeting_rest' ), 10, 3 );
		add_filter( 'rest_prepare_academy_meeting', array( $self, 'strip_host_link_from_rest' ), 10, 2 );
	}

	/**
	 * Block the academy_meeting REST routes for anyone who isn't an
	 * instructor or admin — they were readable logged out, exposing every
	 * meeting's join link, password and Zoom host start_url.
	 *
	 * @param mixed            $result  Response to replace the requested one with.
	 * @param \WP_REST_Server  $server  Server instance.
	 * @param \WP_REST_Request $request Request.
	 * @return mixed
	 */
	public function restrict_meeting_rest( $result, $server, $request ) {
		unset( $server );
		if ( null !== $result || ! preg_match( '#^/academy/v1/academy_meeting(/|$)#', (string) $request->get_route() ) ) {
			return $result;
		}
		if ( ! current_user_can( 'manage_academy_instructor' ) && ! current_user_can( 'manage_options' ) ) {
			return new \WP_Error( 'rest_forbidden', __( 'Sorry, you are not allowed to view meetings.', 'academy-pro' ), array( 'status' => rest_authorization_required_code() ) );
		}
		// Instructors hold edit_others_academy_meetings, so without this any
		// instructor could rewrite another's meeting (e.g. its join link).
		if ( 'GET' !== $request->get_method() && preg_match( '#^/academy/v1/academy_meeting/(\d+)#', (string) $request->get_route(), $m ) && ! self::is_owner_or_admin( (int) $m[1] ) ) {
			return new \WP_Error( 'rest_forbidden', __( 'Sorry, you can only change your own meetings.', 'academy-pro' ), array( 'status' => 403 ) );
		}
		return $result;
	}

	/**
	 * The meeting's author, or a real administrator. `allcaps` is read
	 * directly because Caps::elevate() grants manage_options to staff
	 * during some requests.
	 *
	 * @param int $post_id Academy meeting post ID.
	 * @return bool
	 */
	private static function is_owner_or_admin( $post_id ) {
		$post = get_post( $post_id );
		if ( ! $post || 'academy_meeting' !== $post->post_type ) {
			return false;
		}
		return get_current_user_id() === (int) $post->post_author || ! empty( wp_get_current_user()->allcaps['manage_options'] );
	}

	/**
	 * Zoom's start_url lets whoever holds it start the meeting as host: only
	 * people who can edit the meeting get it.
	 *
	 * @param \WP_REST_Response $response The response.
	 * @param \WP_Post          $post     The meeting.
	 * @return \WP_REST_Response
	 */
	public function strip_host_link_from_rest( $response, $post ) {
		if ( self::is_owner_or_admin( $post->ID ) ) {
			return $response;
		}
		$data = $response->get_data();
		foreach ( array( 'academy_meeting_response', 'academy_meeting_request' ) as $key ) {
			if ( isset( $data['meta'][ $key ] ) ) {
				$data['meta'][ $key ] = self::without_host_fields( $data['meta'][ $key ] );
			}
		}
		$response->set_data( $data );
		return $response;
	}

	/**
	 * @param string $json Stored meeting JSON.
	 * @return string The JSON without host-only fields.
	 */
	private static function without_host_fields( $json ) {
		$decoded = json_decode( (string) $json, true );
		if ( ! is_array( $decoded ) ) {
			return $json;
		}
		unset( $decoded['start_url'] );
		return wp_json_encode( $decoded );
	}

	public function get_meeting_credentials() {
		check_ajax_referer( 'academy_nonce', 'security' );
		if ( ! current_user_can( 'manage_academy_instructor' ) ) {
			wp_die();
		}

		// Only what the UI needs to know — whether each provider is connected,
		// and Zoom's host email/status. Never tokens or client secrets, for
		// anyone: the browser has no use for them.
		$user_id          = get_current_user_id();
		$meet_credentials = GoogleMeet::is_configured( $user_id ) ? array( 'access_token' => true ) : '';
		$zoom_credentials = '';
		if ( Zoom::is_configured( $user_id ) ) {
			$zoom_settings    = Zoom::get_zoom_api_settings( $user_id );
			$zoom_credentials = wp_json_encode(
				array(
					'host_email' => $zoom_settings['host_email'] ?? '',
					'status'     => $zoom_settings['status'] ?? 'active',
				)
			);
		}

		$response = [
			'google_meet' => $meet_credentials,
			'zoom' => is_string( $zoom_credentials ) ? json_decode( $zoom_credentials ) : $zoom_credentials,
		];

		wp_send_json_success( $response );
	}

	public function render_meeting() {
		check_ajax_referer( 'academy_nonce', 'security' );
		$course_id = (int) isset( $_POST['course_id'] ) ? sanitize_text_field( wp_unslash( $_POST['course_id'] ) ) : '';
		$post_id   = (int) isset( $_POST['zoom_id'] ) ? sanitize_text_field( wp_unslash( $_POST['zoom_id'] ) ) : '';
		$user_id   = (int) get_current_user_id();

		$has_permission = \Academy\Helper::has_permission_to_access_curriculum( $course_id, $user_id, $post_id, 'meeting' );

		if ( $has_permission ) {
			do_action( 'academy_pro_meeting/frontend/before_render_meeting', $course_id, $post_id );
			$is_meeting = get_post( $post_id );
			if ( ! $is_meeting ) {
				wp_send_json_error( esc_html__( 'Sorry, something went wrong!', 'academy-pro' ) );
			}
			// Pick up changes made in Google Calendar (moved, cancelled).
			if ( 'google_meet' === get_post_meta( $post_id, 'academy_meeting_type', true ) ) {
				GoogleMeetInvites::refresh_from_google( $post_id );
			} elseif ( 'zoom' === get_post_meta( $post_id, 'academy_meeting_type', true ) ) {
				ZoomInvites::refresh_from_zoom( $post_id );
			}
			$meeting = json_decode( get_post_meta( $post_id, 'academy_meeting_response', true ), true );
			if ( isset( $meeting['meetingLink'] ) && empty( $meeting['meetCode'] ) ) {
				$meeting['meetCode'] = GoogleMeet::meet_code( $meeting['meetingLink'] );
			}
			$meeting_author_id = (int) get_post_field( 'post_author', $post_id );
			$meeting['description'] = get_post_field( 'post_content', $post_id );
			$meeting['meeting_type'] = get_post_meta( $post_id, 'academy_meeting_type', true );
			$meeting['is_meeting_creator'] = get_current_user_id() === $meeting_author_id ? true : false;
			// Only the host (or an admin) may receive Zoom's start_url.
			if ( ! self::is_owner_or_admin( $post_id ) ) {
				unset( $meeting['start_url'] );
			}
			$meeting_date = isset( $meeting['meetingDate'] ) ? $meeting['meetingDate'] : $meeting['start_time'];
			$meeting['meeting_start_time'] = new \DateTime( $meeting_date, new \DateTimeZone( 'UTC' ) );
			wp_send_json_success( $meeting );
		}//end if
		wp_send_json_error( __( 'Access Denied', 'academy-pro' ) );
	}

	public function delete_meeting() {
		check_ajax_referer( 'academy_nonce', 'security' );
		if ( ! current_user_can( 'manage_academy_instructor' ) ) {
			wp_die();
		}

		$post_id = (int) ( isset( $_POST['post_id'] ) ? sanitize_text_field( wp_unslash( $_POST['post_id'] ) ) : 0 );
		$meeting_type = ( isset( $_POST['meeting_type'] ) ? sanitize_text_field( wp_unslash( $_POST['meeting_type'] ) ) : '' );
		$meeting_id = ( isset( $_POST['meeting_id'] ) ? sanitize_text_field( wp_unslash( $_POST['meeting_id'] ) ) : '' );

		// Only the meeting's owner (or an admin) may delete it — otherwise any
		// instructor could force-delete another instructor's meeting, or an
		// arbitrary post, by supplying its post_id.
		$meeting_post = get_post( $post_id );
		if ( ! $meeting_post || 'academy_meeting' !== $meeting_post->post_type || ( get_current_user_id() !== (int) $meeting_post->post_author && ! current_user_can( 'manage_options' ) ) ) {
			wp_send_json_error( esc_html__( 'Sorry, you are not allowed to delete this meeting.', 'academy-pro' ) );
		}

		if ( 'zoom' === $meeting_type ) {
			$zoom = new Zoom();
			$zoom->delete_zoom_meeting( $meeting_id, $post_id );
		}

		if ( 'google_meet' === $meeting_type ) {
			$googleMeet = new GoogleMeet();
			$googleMeet->delete_google_meet_meeting( $meeting_id, $post_id );
		}
	}
}
