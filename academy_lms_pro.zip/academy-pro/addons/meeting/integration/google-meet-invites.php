<?php
namespace AcademyProMeeting\Integration;

use AcademyPro\Google\Service\Calendar as Google_Service_Calendar;
use AcademyPro\Google\Service\Calendar\Event as Google_Service_Calendar_Event;
use AcademyPro\Google\Service\Calendar\EventAttendee as Google_Service_Calendar_EventAttendee;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Keeps a Google Meet event's guest list in step with the students enrolled
 * in the course(s) the meeting is part of, and keeps the Academy meeting in
 * step with the event (moved or cancelled in Google Calendar).
 *
 * Only the guests this site added are ever removed; guests the instructor
 * invites by hand in Google Calendar are left alone.
 */
class GoogleMeetInvites {
	const META_ENABLED   = 'academy_meet_invite_students';
	const META_MANAGED   = 'academy_meet_invited_emails';
	const META_SYNCED_AT = 'academy_meet_invites_synced_at';
	const META_INVITED   = 'academy_meet_invited_count';
	const META_ERROR     = 'academy_meet_invite_error';
	const HOOK_SYNC      = 'academy_pro_meet_sync_invites';

	/** How long a meeting page trusts its copy of the Google event. */
	const REFRESH_TTL = 10 * MINUTE_IN_SECONDS;

	public static function init() {
		add_action( self::HOOK_SYNC, array( __CLASS__, 'sync' ) );
		add_action( 'academy/course/after_enroll', array( __CLASS__, 'on_enroll' ), 10, 3 );
		add_action( 'added_post_meta', array( __CLASS__, 'on_curriculum_saved' ), 10, 4 );
		add_action( 'updated_post_meta', array( __CLASS__, 'on_curriculum_saved' ), 10, 4 );
		// Course published/unpublished, enrolment completed/cancelled/deleted.
		add_action( 'transition_post_status', array( __CLASS__, 'on_status_change' ), 10, 3 );
		add_action( 'after_delete_post', array( __CLASS__, 'on_post_deleted' ), 10, 2 );
		add_action( 'rest_api_init', array( __CLASS__, 'register_rest_field' ) );
		add_action( 'wp_ajax_academy_pro_meeting/sync_meet_invites', array( __CLASS__, 'ajax_sync' ) );
	}

	/**
	 * Queue the inviting meetings of a course.
	 *
	 * @param int $course_id Course ID.
	 */
	private static function queue_course( $course_id ) {
		foreach ( self::meetings_in_course( (int) $course_id ) as $meeting_id ) {
			if ( self::is_enabled( $meeting_id ) ) {
				self::queue( $meeting_id );
			}
		}
	}

	/**
	 * A course goes live or offline, or an enrolment becomes (or stops being)
	 * active: the guest list may need to change.
	 *
	 * @param string   $new_status New status.
	 * @param string   $old_status Old status.
	 * @param \WP_Post $post       The post.
	 */
	public static function on_status_change( $new_status, $old_status, $post ) {
		if ( $new_status === $old_status ) {
			return;
		}
		if ( 'academy_courses' === $post->post_type && in_array( 'publish', array( $new_status, $old_status ), true ) ) {
			self::queue_course( $post->ID );
		} elseif ( 'academy_enrolled' === $post->post_type && in_array( 'completed', array( $new_status, $old_status ), true ) ) {
			self::queue_course( $post->post_parent );
		}
	}

	/**
	 * An active enrolment was deleted: remove that student at the next sync.
	 *
	 * @param int      $post_id Deleted post ID.
	 * @param \WP_Post $post    The deleted post.
	 */
	public static function on_post_deleted( $post_id, $post ) {
		unset( $post_id );
		if ( $post instanceof \WP_Post && 'academy_enrolled' === $post->post_type && 'completed' === $post->post_status ) {
			self::queue_course( $post->post_parent );
		}
	}

	/**
	 * Invite status on each meeting in the REST API (read-only), for the
	 * meetings list. Only people who can edit the meeting see it.
	 */
	public static function register_rest_field() {
		register_rest_field(
			'academy_meeting',
			'meet_invites',
			array(
				'get_callback' => function ( $data ) {
					$post_id = (int) $data['id'];
					if ( ! current_user_can( 'edit_post', $post_id ) ) {
						return null;
					}
					return self::get_status( $post_id );
				},
				'schema'       => array(
					'type'     => array( 'object', 'null' ),
					'readonly' => true,
					'context'  => array( 'view', 'edit' ),
				),
			)
		);
	}

	/**
	 * @param int $post_id Academy meeting post ID.
	 * @return array { enabled, invited, synced_at, error, queued }
	 */
	public static function get_status( $post_id ) {
		$synced = (int) get_post_meta( $post_id, self::META_SYNCED_AT, true );
		$error  = (string) get_post_meta( $post_id, self::META_ERROR, true );
		return array(
			'enabled'   => self::is_enabled( $post_id ),
			'invited'   => (int) get_post_meta( $post_id, self::META_INVITED, true ),
			'synced_at' => $synced ? $synced : null,
			'error'     => '' !== $error ? $error : null,
			'queued'    => (bool) wp_next_scheduled( self::HOOK_SYNC, array( (int) $post_id ) ),
		);
	}

	/** "Sync invites now" from the meetings list (meeting owner or admin). */
	public static function ajax_sync() {
		check_ajax_referer( 'academy_nonce', 'security' );
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- verified above
		$post_id = isset( $_POST['post_id'] ) ? absint( $_POST['post_id'] ) : 0;
		$post    = get_post( $post_id );
		if ( ! current_user_can( 'manage_academy_instructor' ) || ! $post || 'academy_meeting' !== $post->post_type
			|| ( get_current_user_id() !== (int) $post->post_author && ! current_user_can( 'manage_options' ) ) ) {
			wp_send_json_error( __( 'Sorry, you are not allowed to do that.', 'academy-pro' ) );
		}
		$result = self::sync( $post_id );
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( $result->get_error_message() );
		}
		wp_send_json_success(
			array(
				'message' => sprintf(
					/* translators: 1: students invited, 2: newly added, 3: removed */
					__( 'Invites synced: %1$d students (%2$d added, %3$d removed).', 'academy-pro' ),
					$result['invited'],
					$result['added'],
					$result['removed']
				),
				'status'  => self::get_status( $post_id ),
			)
		);
	}

	/**
	 * @param int $post_id Academy meeting post ID.
	 * @return bool
	 */
	public static function is_enabled( $post_id ) {
		return (bool) get_post_meta( $post_id, self::META_ENABLED, true );
	}

	/**
	 * Turn inviting on or off for a meeting, then sync.
	 *
	 * @param int  $post_id Academy meeting post ID.
	 * @param bool $enabled Whether enrolled students should be invited.
	 * @return array|\WP_Error Sync result.
	 */
	public static function set_enabled( $post_id, $enabled ) {
		if ( $enabled ) {
			update_post_meta( $post_id, self::META_ENABLED, 1 );
		} else {
			delete_post_meta( $post_id, self::META_ENABLED );
		}
		return self::sync( $post_id );
	}

	/**
	 * Run a sync in the background (cron), once per meeting per queue.
	 *
	 * @param int $post_id Academy meeting post ID.
	 */
	public static function queue( $post_id ) {
		if ( ! wp_next_scheduled( self::HOOK_SYNC, array( (int) $post_id ) ) ) {
			wp_schedule_single_event( time(), self::HOOK_SYNC, array( (int) $post_id ) );
		}
	}

	/**
	 * A student enrolled: queue the course's inviting meetings.
	 *
	 * @param int $course_id Course ID.
	 * @param int $enroll_id Enrolment ID.
	 * @param int $user_id   Student ID.
	 */
	public static function on_enroll( $course_id, $enroll_id, $user_id ) {
		unset( $enroll_id, $user_id );
		foreach ( self::meetings_in_course( (int) $course_id ) as $meeting_id ) {
			if ( self::is_enabled( $meeting_id ) ) {
				self::queue( $meeting_id );
			}
		}
	}

	/**
	 * A course curriculum was saved: its meetings may have been added or
	 * removed, so queue the inviting ones.
	 *
	 * @param int    $meta_id   Meta ID.
	 * @param int    $object_id Post ID.
	 * @param string $meta_key  Meta key.
	 * @param mixed  $value     New value.
	 */
	public static function on_curriculum_saved( $meta_id, $object_id, $meta_key, $value ) {
		unset( $meta_id );
		if ( 'academy_course_curriculum' !== $meta_key || ! is_array( $value ) ) {
			return;
		}
		foreach ( self::meeting_ids_in_curriculum( $value ) as $meeting_id ) {
			if ( self::is_enabled( $meeting_id ) ) {
				self::queue( $meeting_id );
			}
		}
		unset( $object_id );
	}

	/**
	 * @param array $curriculum A course's academy_course_curriculum.
	 * @return int[] Meeting IDs in it.
	 */
	private static function meeting_ids_in_curriculum( $curriculum ) {
		$ids = array();
		foreach ( (array) $curriculum as $section ) {
			foreach ( (array) ( $section['topics'] ?? array() ) as $item ) {
				if ( 'meeting' === ( $item['type'] ?? '' ) && ! empty( $item['id'] ) ) {
					$ids[] = (int) $item['id'];
				}
			}
		}
		return array_values( array_unique( $ids ) );
	}

	/**
	 * @param int $course_id Course ID.
	 * @return int[] Meeting IDs in the course.
	 */
	private static function meetings_in_course( $course_id ) {
		return self::meeting_ids_in_curriculum( get_post_meta( $course_id, 'academy_course_curriculum', true ) );
	}

	/**
	 * Published courses whose curriculum includes the meeting.
	 *
	 * @param int $meeting_id Academy meeting post ID.
	 * @return int[]
	 */
	public static function courses_with_meeting( $meeting_id ) {
		global $wpdb;
		// Serialized curricula store the type as s:7:"meeting"; narrow in SQL, confirm in PHP.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- small lookup on save/sync
		$rows    = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT pm.post_id, pm.meta_value FROM {$wpdb->postmeta} pm
				INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
				WHERE pm.meta_key = %s AND p.post_type = %s AND p.post_status = %s AND pm.meta_value LIKE %s",
				'academy_course_curriculum',
				'academy_courses',
				'publish',
				'%' . $wpdb->esc_like( '"meeting"' ) . '%'
			)
		);
		$courses = array();
		foreach ( $rows as $row ) {
			if ( in_array( (int) $meeting_id, self::meeting_ids_in_curriculum( maybe_unserialize( $row->meta_value ) ), true ) ) {
				$courses[] = (int) $row->post_id;
			}
		}
		return $courses;
	}

	/**
	 * Emails of students actively enrolled in any of the courses.
	 *
	 * @param int[] $course_ids Course IDs.
	 * @return string[] Lower-case emails.
	 */
	public static function enrolled_emails( array $course_ids ) {
		if ( ! $course_ids ) {
			return array();
		}
		global $wpdb;
		$placeholders = implode( ',', array_fill( 0, count( $course_ids ), '%d' ) );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- enrolment lookup on sync
		$student_ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT DISTINCT post_author FROM {$wpdb->posts}
				WHERE post_type = 'academy_enrolled' AND post_status = 'completed' AND post_parent IN ($placeholders)", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- placeholders built above
				$course_ids
			)
		);
		if ( ! $student_ids ) {
			return array();
		}
		$emails = get_users(
			array(
				'include' => array_map( 'intval', $student_ids ),
				'fields'  => 'user_email',
				'number'  => count( $student_ids ),
			)
		);
		return array_values( array_unique( array_filter( array_map( 'strtolower', $emails ), 'is_email' ) ) );
	}

	/**
	 * Make the event's guests match the enrolled students (or remove the ones
	 * this site added, when inviting is off). New guests get Google's
	 * invitation email; guests can't see each other.
	 *
	 * @param int                          $post_id  Academy meeting post ID.
	 * @param Google_Service_Calendar|null $calendar For tests; the host's calendar by default.
	 * @return array|\WP_Error { invited, added, removed }
	 */
	public static function sync( $post_id, $calendar = null ) {
		// Zoom has no guest list: its students are invited by email instead.
		$result = 'zoom' === get_post_meta( $post_id, 'academy_meeting_type', true )
			? ZoomInvites::sync( (int) $post_id )
			: self::run_sync( (int) $post_id, $calendar );
		if ( is_wp_error( $result ) ) {
			// Kept for the meetings list, so a failed background sync is visible.
			update_post_meta( $post_id, self::META_ERROR, $result->get_error_message() );
		} else {
			delete_post_meta( $post_id, self::META_ERROR );
			update_post_meta( $post_id, self::META_INVITED, $result['invited'] );
		}
		return $result;
	}

	/**
	 * @param int                          $post_id  Academy meeting post ID.
	 * @param Google_Service_Calendar|null $calendar For tests; the host's calendar by default.
	 * @return array|\WP_Error
	 */
	private static function run_sync( $post_id, $calendar ) {
		if ( 'google_meet' !== get_post_meta( $post_id, 'academy_meeting_type', true ) ) {
			return new \WP_Error( 'not_google_meet', __( 'Not a Google Meet meeting.', 'academy-pro' ) );
		}
		$event_id = self::event_id( $post_id );
		if ( ! $calendar ) {
			$client   = GoogleMeet::authorized_client( (int) get_post_field( 'post_author', $post_id ) );
			$calendar = $client ? new Google_Service_Calendar( $client ) : null;
		}
		if ( ! $event_id || ! $calendar ) {
			return new \WP_Error( 'not_connected', __( 'The host\'s Google Meet connection has expired or was removed. Reconnect Google Meet, then sync again.', 'academy-pro' ) );
		}

		$managed = array_filter( array_map( 'strtolower', (array) get_post_meta( $post_id, self::META_MANAGED, true ) ) );
		$wanted  = self::is_enabled( $post_id ) ? self::enrolled_emails( self::courses_with_meeting( $post_id ) ) : array();

		try {
			$event = $calendar->events->get( 'primary', $event_id );
		} catch ( \Exception $e ) {
			return new \WP_Error( 'google_failed', GoogleMeet::google_error_message( $e ) );
		}

		$attendees = array();
		$present   = array();
		foreach ( (array) $event->getAttendees() as $attendee ) {
			$email = strtolower( (string) $attendee->getEmail() );
			// Drop guests we added whose student is no longer enrolled.
			if ( in_array( $email, $managed, true ) && ! in_array( $email, $wanted, true ) && ! $attendee->getOrganizer() ) {
				continue;
			}
			$attendees[]       = $attendee;
			$present[ $email ] = true;
		}
		$removed = count( (array) $event->getAttendees() ) - count( $attendees );
		$added   = 0;
		foreach ( $wanted as $email ) {
			if ( ! isset( $present[ $email ] ) ) {
				$attendees[] = new Google_Service_Calendar_EventAttendee( array( 'email' => $email ) );
				++$added;
			}
		}

		if ( $added || $removed ) {
			try {
				$calendar->events->patch(
					'primary',
					$event_id,
					new Google_Service_Calendar_Event(
						array(
							'attendees'               => $attendees,
							'guestsCanSeeOtherGuests' => false,
							'guestsCanInviteOthers'   => false,
						)
					),
					// New guests get Google's invitation; removals are silent.
					array( 'sendUpdates' => $added ? 'all' : 'none' )
				);
			} catch ( \Exception $e ) {
				return new \WP_Error( 'google_failed', GoogleMeet::google_error_message( $e ) );
			}
		}

		update_post_meta( $post_id, self::META_MANAGED, $wanted );
		update_post_meta( $post_id, self::META_SYNCED_AT, time() );
		return array(
			'invited' => count( $wanted ),
			'added'   => $added,
			'removed' => $removed,
		);
	}

	/**
	 * @param int $post_id Academy meeting post ID.
	 * @return string The Google Calendar event ID saved on the meeting.
	 */
	private static function event_id( $post_id ) {
		$response = json_decode( (string) get_post_meta( $post_id, 'academy_meeting_response', true ), true );
		return is_array( $response ) ? (string) ( $response['meetingId'] ?? '' ) : '';
	}

	/**
	 * Refresh the meeting from its Google event at most every REFRESH_TTL:
	 * picks up a new time/link and marks it cancelled when the event was
	 * cancelled or deleted in Google Calendar.
	 *
	 * @param int $post_id Academy meeting post ID.
	 */
	public static function refresh_from_google( $post_id ) {
		$key = 'academy_meet_checked_' . (int) $post_id;
		if ( get_transient( $key ) ) {
			return;
		}
		set_transient( $key, 1, self::REFRESH_TTL );

		$event_id = self::event_id( $post_id );
		$client   = GoogleMeet::authorized_client( (int) get_post_field( 'post_author', $post_id ) );
		if ( ! $event_id || ! $client ) {
			return;
		}
		$response = json_decode( (string) get_post_meta( $post_id, 'academy_meeting_response', true ), true );
		try {
			$event = ( new Google_Service_Calendar( $client ) )->events->get( 'primary', $event_id );
			if ( 'cancelled' === $event->getStatus() ) {
				$response['meetingStatus'] = 'cancelled';
			} else {
				$response['meetingDate']     = $event->getStart()->getDateTime();
				$response['meetingDuration'] = $event->getEnd()->getDateTime();
				$response['meetingTimezone'] = $event->getStart()->getTimeZone() ? $event->getStart()->getTimeZone() : ( $response['meetingTimezone'] ?? '' );
				$response['meetingLink']     = $event->getHangoutLink() ? $event->getHangoutLink() : ( $response['meetingLink'] ?? '' );
				$response['meetingStatus']   = $event->getStatus();
			}
		} catch ( \Exception $e ) {
			if ( ! in_array( (int) $e->getCode(), array( 404, 410 ), true ) ) {
				return;
			}
			$response['meetingStatus'] = 'cancelled';
		}
		update_post_meta( $post_id, 'academy_meeting_response', wp_json_encode( $response ) );
	}
}
