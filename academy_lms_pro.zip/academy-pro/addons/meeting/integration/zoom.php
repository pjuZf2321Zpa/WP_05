<?php
namespace AcademyProMeeting\Integration;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Zoom {
	private static $type;
	public static function init() {
		$self = new self();
		add_action( 'wp_ajax_academy_pro_meeting/get_zoom_settings', array( $self, 'get_zoom_settings' ) );
		add_action( 'wp_ajax_academy_pro_meeting/save_zoom_settings', array( $self, 'save_zoom_settings' ) );
		add_action( 'wp_ajax_academy_pro_meeting/save_zoom_meeting_credentials', array( $self, 'save_zoom_meeting_credentials' ) );
		add_action( 'wp_ajax_academy_pro_meeting/create_zoom_meeting', array( $self, 'create_zoom_meeting' ) );
		add_action( 'wp_ajax_academy_pro_meeting/update_zoom_meeting', array( $self, 'update_zoom_meeting' ) );
		add_action( 'wp_ajax_academy_pro_meeting/disconnect_zoom', array( $self, 'disconnect_zoom' ) );
		self::$type = \Academy\Helper::get_settings( 'academy_meeting_api_handler_type', 'individual' );
	}

	public function get_zoom_settings() {
		check_ajax_referer( 'academy_nonce', 'security' );
		if ( ! current_user_can( 'manage_academy_instructor' ) ) {
			wp_die();
		}
		// SECURITY: when the site uses one SHARED Zoom API handler (not
		// per-instructor), these are the shared account-wide settings —
		// restricted to a real admin. `manage_options` is checked against
		// $user->allcaps directly (not current_user_can()) because
		// AcademyProRolePermission\Caps::elevate() grants BOTH
		// manage_academy_instructor and manage_options to any staff member for
		// the whole academy_pro ajax request; current_user_can('manage_options')
		// would therefore also pass for a staffer who only holds e.g.
		// academy.courses, letting them reach shared Zoom configuration.
		// $user->allcaps reflects the stored role/user caps, ignoring that
		// dynamic elevation. Found via a live report asking to lock Meeting
		// setup down to admins only.
		if ( 'individual' !== self::$type && empty( wp_get_current_user()->allcaps['manage_options'] ) ) {
			wp_send_json_error( esc_html__( 'Sorry, you are not allowed to access these settings.', 'academy-pro' ) );
		}
		$settings = 'individual' === self::$type ? get_user_meta( get_current_user_id(), 'academy_pro_zoom_settings', true ) : get_option( 'academy_pro_zoom_settings' );
		wp_send_json_success( json_decode( $settings, true ) );
	}

	public static function get_zoom_api_settings( $user_id ) {
		if ( 'individual' === self::$type ) {
			$zoom_meta_key = get_user_meta( $user_id, 'academy_pro_zoom_credentials', true );
		} else {
			$zoom_meta_key = get_option( 'academy_pro_zoom_credentials' );
		}
		return json_decode( $zoom_meta_key, true );
	}

	public static function get_user_zoom_settings( $user_id ) {
		$settings = 'individual' === self::$type ? get_user_meta( $user_id, 'academy_pro_zoom_settings', true ) : get_option( 'academy_pro_zoom_settings' );
		if ( ! empty( $settings ) ) {
			return json_decode( $settings, true );
		}
		return array(
			'join_before_host'  => true,
			'host_video'        => false,
			'participant_video' => false,
			'mute_upon_entry'   => false,
			'auto_recording'    => false,
			'enforce_login'     => false,
		);
	}

	public static function generate_access_token( $account_id, $client_id, $client_secret, $user_id = null ) {
		$url = 'https://zoom.us/oauth/token?grant_type=account_credentials';

		if ( ! $account_id || ! $client_id || ! $client_secret ) {
			return false;
		}

		$url = $url . '&account_id=' . $account_id;
		// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
		$encode   = base64_encode( $client_id . ':' . $client_secret );
		$response = wp_remote_post(
			$url,
			array(
				'headers' => array(
					'Content-Type'  => 'application/x-www-form-urlencoded',
					'Authorization' => 'Basic ' . $encode,
				),
				'timeout' => 10, // phpcs:ignore WordPressVIPMinimum.Performance.RemoteRequestTimeout.timeout_timeout -- OAuth token exchange from an instructor/admin action.
			)
		);

		if ( ! is_wp_error( $response ) ) {
			$generate_token = json_decode( $response['body'] );
			if ( is_object( $generate_token ) && property_exists( $generate_token, 'access_token' ) ) {
				// Cached for the user whose credentials these are (in cron there is no current user).
				set_transient( 'academy_pro_zoom_access_token_' . ( $user_id ? $user_id : get_current_user_id() ), $generate_token->access_token, $generate_token->expires_in );
				return $generate_token->access_token;
			}
			return false;
		}
		return false;
	}
	/**
	 * Whether Zoom credentials (account/client id + secret) have been saved
	 * for this instructor (individual mode) or globally (shared mode).
	 * Does not verify the credentials still work — only that they're present.
	 *
	 * @param int|null $user_id Defaults to the current user.
	 * @return bool
	 */
	public static function is_configured( $user_id = null ) {
		$settings = self::get_zoom_api_settings( $user_id ? $user_id : get_current_user_id() );
		return ! empty( $settings['account_id'] ) && ! empty( $settings['client_id'] ) && ! empty( $settings['client_secret'] );
	}

	public static function get_access_token( $user_id ) {
		$access_token = get_transient( 'academy_pro_zoom_access_token_' . $user_id );
		// if not have access token then create new one
		if ( false === $access_token ) {
			$settings = self::get_zoom_api_settings( $user_id );
			$access_token = self::generate_access_token( $settings['account_id'] ?? '', $settings['client_id'] ?? '', $settings['client_secret'] ?? '', $user_id );
		}
		return $access_token;
	}

	public function save_zoom_settings() {
		check_ajax_referer( 'academy_nonce', 'security' );
		if ( ! current_user_can( 'manage_academy_instructor' ) ) {
			wp_die();
		}
		// SECURITY: see the note in get_zoom_settings() above — writing the
		// shared, site-wide Zoom settings is admin-only.
		if ( 'individual' !== self::$type && empty( wp_get_current_user()->allcaps['manage_options'] ) ) {
			wp_send_json_error( esc_html__( 'Sorry, you are not allowed to change these settings.', 'academy-pro' ) );
		}
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.MissingUnslash, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$enforce_login = (bool) ( isset( $_POST['enforce_login'] ) ? \Academy\Helper::sanitize_checkbox_field( $_POST['enforce_login'] ) : false );
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.MissingUnslash, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$host_video = (bool) ( isset( $_POST['host_video'] ) ? \Academy\Helper::sanitize_checkbox_field( $_POST['host_video'] ) : false );
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.MissingUnslash, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$join_before_host = (bool) ( isset( $_POST['join_before_host'] ) ? \Academy\Helper::sanitize_checkbox_field( $_POST['join_before_host'] ) : false );
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.MissingUnslash, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$mute_participants = (bool) ( isset( $_POST['mute_participants'] ) ? \Academy\Helper::sanitize_checkbox_field( $_POST['mute_participants'] ) : false );
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.MissingUnslash, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$participants_video = (bool) ( isset( $_POST['participants_video'] ) ? \Academy\Helper::sanitize_checkbox_field( $_POST['participants_video'] ) : false );
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.MissingUnslash, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$recording_settings = ( isset( $_POST['recording_settings'] ) ? \Academy\Helper::sanitize_checkbox_field( $_POST['recording_settings'] ) : 'none' );
		$settings = [
			'join_before_host'      => $join_before_host,
			'host_video'            => $host_video,
			'participants_video'    => $participants_video,
			'mute_participants'     => $mute_participants,
			'enforce_login'         => $enforce_login,
			'recording_settings'    => $recording_settings,
		];
		if ( 'individual' === self::$type ) {
			update_user_meta( get_current_user_id(), 'academy_pro_zoom_settings', wp_json_encode( $settings ) );
		} else {
			update_option( 'academy_pro_zoom_settings', wp_json_encode( $settings ), false );
		}
		wp_send_json_success( $settings );
	}

	public function save_zoom_meeting_credentials() {
		check_ajax_referer( 'academy_nonce', 'security' );

		if ( ! current_user_can( 'manage_academy_instructor' ) ) {
			wp_die();
		}
		// SECURITY: see the note in get_zoom_settings() above — saving the
		// shared, site-wide Zoom API credentials is admin-only.
		if ( 'individual' !== self::$type && empty( wp_get_current_user()->allcaps['manage_options'] ) ) {
			wp_send_json_error( esc_html__( 'Sorry, you are not allowed to save these credentials.', 'academy-pro' ) );
		}

		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.MissingUnslash, WordPress.Security.ValidatedSanitizedInput.InputNotValidated
		$account_id = sanitize_text_field( $_POST['account_id'] );
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.MissingUnslash, WordPress.Security.ValidatedSanitizedInput.InputNotValidated
		$client_id = sanitize_text_field( $_POST['client_id'] );
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.MissingUnslash, WordPress.Security.ValidatedSanitizedInput.InputNotValidated
		$client_secret = sanitize_text_field( $_POST['client_secret'] );

		if ( empty( $account_id ) || empty( $client_id ) || empty( $client_secret ) ) {
			wp_send_json_error( __( 'Account ID, Client ID and Client Secret is required', 'academy-pro' ) );
		}

		$response = wp_remote_retrieve_body( wp_safe_remote_get('https://api.zoom.us/v2/users/me', array(
			'method'     => 'GET',
			'headers' => array(
				'Authorization' => 'Bearer ' . self::generate_access_token( $account_id, $client_id, $client_secret ),
				'Content-Type' => 'application/json',
			),
		)) );
		$response = json_decode( $response, true );
		if ( count( $response ) && 'active' === $response['status'] ) {
			$user_id = get_current_user_id();
			$form_data = array(
				'account_id' => $account_id,
				'client_id' => $client_id,
				'client_secret' => $client_secret,
				'host_email' => $response['email'],
				'status' => $response['status']
			);
			if ( 'individual' === self::$type ) {
				update_user_meta( $user_id, 'academy_pro_zoom_credentials', wp_json_encode( $form_data ) );
			} else {
				update_option( 'academy_pro_zoom_credentials', wp_json_encode( $form_data ), false );
			}
			wp_send_json_success( $form_data );
		}
		wp_send_json_error( __( 'Wrong API Key and Secret Key', 'academy-pro' ) );
	}

	/**
	 * Create a Zoom meeting for a given instructor (user), independent of the
	 * request context. Returns an array with post_id/join_url/start_url on
	 * success, or a WP_Error. Reusable by AJAX and by the tutor-booking bridge.
	 *
	 * @param int   $user_id Instructor whose Zoom credentials are used.
	 * @param array $args    title, description, date (Y-m-d), time (H:i),
	 *                       duration (minutes), duration_unit, timezone, password.
	 * @return array|\WP_Error
	 */
	public static function create_meeting_service( $user_id, $args ) {
		$title       = isset( $args['title'] ) ? sanitize_text_field( $args['title'] ) : '';
		$description = isset( $args['description'] ) ? sanitize_text_field( $args['description'] ) : '';
		$date        = isset( $args['date'] ) ? sanitize_text_field( $args['date'] ) : '';
		$time        = isset( $args['time'] ) ? sanitize_text_field( $args['time'] ) : '';
		$duration    = isset( $args['duration'] ) ? (int) $args['duration'] : 30;
		$unit        = isset( $args['duration_unit'] ) ? sanitize_text_field( $args['duration_unit'] ) : 'minute';
		$timezone    = isset( $args['timezone'] ) ? sanitize_text_field( $args['timezone'] ) : '';
		$password    = isset( $args['password'] ) ? sanitize_text_field( $args['password'] ) : '';

		$start = \DateTime::createFromFormat( 'Y-m-d H:i', $date . ' ' . $time );
		if ( ! $start ) {
			return new \WP_Error( 'invalid_datetime', __( 'Sorry, Invalid Date Time Format', 'academy-pro' ) );
		}

		$access_token = self::get_access_token( $user_id );
		if ( empty( $access_token ) ) {
			return new \WP_Error( 'no_zoom_credentials', __( 'Zoom is not connected for this instructor.', 'academy-pro' ) );
		}

		$request_body = wp_json_encode( array(
			'topic'       => $title,
			'description' => $description,
			'type'        => 2,
			'start_time'  => $start->format( 'Y-m-d\TH:i:s' ),
			'timezone'    => $timezone,
			'duration'    => ( 'hour' === $unit ? $duration * 60 : $duration ),
			'password'    => $password,
			'settings'    => self::get_user_zoom_settings( $user_id ),
		) );

		$response = wp_remote_retrieve_body( wp_remote_post( 'https://api.zoom.us/v2/users/me/meetings', array(
			'method'    => 'POST',
			'headers'   => array(
				'Authorization' => 'Bearer ' . $access_token,
				'Content-Type'  => 'application/json',
			),
			'body'      => $request_body,
		) ) );

		$response_array = json_decode( $response, true );
		if ( empty( $response ) || ! isset( $response_array['id'] ) ) {
			return new \WP_Error( 'zoom_create_failed', __( 'Sorry, Failed to Create Zoom Meeting.', 'academy-pro' ) );
		}

		$post_id = wp_insert_post( array(
			'post_title'   => $title,
			'post_content' => $description,
			'post_status'  => 'publish',
			'post_author'  => $user_id,
			'post_type'    => 'academy_meeting',
			'meta_input'   => array(
				'academy_meeting_type'     => 'zoom',
				'academy_meeting_request'  => $request_body,
				'academy_meeting_response' => $response,
			),
		) );

		return array(
			'post_id'   => $post_id,
			'meeting_id' => $response_array['id'],
			'join_url'  => $response_array['join_url'] ?? '',
			'start_url' => $response_array['start_url'] ?? '',
			'password'  => $response_array['password'] ?? $password,
			'response'  => $response,
		);
	}

	public function create_zoom_meeting() {
		check_ajax_referer( 'academy_nonce', 'security' );
		if ( ! current_user_can( 'manage_academy_instructor' ) ) {
			wp_die();
		}

		$result = self::create_meeting_service( get_current_user_id(), array(
			// phpcs:disable WordPress.Security.ValidatedSanitizedInput.MissingUnslash, WordPress.Security.ValidatedSanitizedInput.InputNotValidated, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			'title'         => isset( $_POST['meetingTitle'] ) ? wp_unslash( $_POST['meetingTitle'] ) : '',
			'description'   => isset( $_POST['meetingSummary'] ) ? wp_unslash( $_POST['meetingSummary'] ) : '',
			'date'          => $_POST['meetingDate'] ?? '',
			'time'          => $_POST['meetingTime'] ?? '',
			'duration'      => $_POST['meetingDuration'] ?? '',
			'duration_unit' => $_POST['meetingTimeUnit'] ?? 'minute',
			'timezone'      => isset( $_POST['meetingTimeZone'] ) ? wp_unslash( $_POST['meetingTimeZone'] ) : '',
			'password'      => isset( $_POST['meetingPassword'] ) ? wp_unslash( $_POST['meetingPassword'] ) : '',
			// phpcs:enable
		) );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( $result->get_error_message() );
		}
		// Not in a course yet on create; kept, and students are emailed once
		// the meeting is added to a course curriculum.
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- only compared
		if ( ! empty( $_POST['invite_students'] ) && 'false' !== $_POST['invite_students'] ) {
			update_post_meta( $result['post_id'], GoogleMeetInvites::META_ENABLED, 1 );
			$stored                   = json_decode( (string) get_post_meta( $result['post_id'], 'academy_meeting_response', true ), true );
			$stored['inviteStudents'] = true;
			update_post_meta( $result['post_id'], 'academy_meeting_response', wp_json_encode( $stored ) );
		}
		wp_send_json_success( [ 'post_id' => $result['post_id'] ] );
	}

	public function update_zoom_meeting() {
		check_ajax_referer( 'academy_nonce', 'security' );
		if ( ! current_user_can( 'manage_academy_instructor' ) ) {
			wp_die();
		}

		$user_id = get_current_user_id();
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.MissingUnslash
		$post_id = (int) ( isset( $_POST['post_id'] ) ? sanitize_text_field( $_POST['post_id'] ) : 0 );

		// The target must be a meeting owned by the current user (or an admin),
		// otherwise any instructor could overwrite another instructor's meeting
		// (or an arbitrary post) by supplying its post_id.
		$meeting_post = get_post( $post_id );
		if ( ! $meeting_post || 'academy_meeting' !== $meeting_post->post_type || ( (int) $meeting_post->post_author !== $user_id && ! current_user_can( 'manage_options' ) ) ) {
			wp_send_json_error( esc_html__( 'Sorry, you are not allowed to modify this meeting.', 'academy-pro' ) );
		}
		// The Zoom meeting comes from the Academy meeting itself, never the
		// request: in shared mode every instructor uses one Zoom account, so a
		// posted ID could otherwise edit any meeting on it.
		$meeting_id = self::stored_meeting_id( $post_id );
		if ( ! $meeting_id ) {
			wp_send_json_error( __( 'This meeting isn\'t linked to a Zoom meeting.', 'academy-pro' ) );
		}
		$meeting_title = ( isset( $_POST['meetingTitle'] ) ? sanitize_text_field( wp_unslash( $_POST['meetingTitle'] ) ) : '' );
		$meeting_description = ( isset( $_POST['meetingSummary'] ) ? sanitize_text_field( wp_unslash( $_POST['meetingSummary'] ) ) : '' );
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.MissingUnslash
		$meeting_date = ( isset( $_POST['meetingDate'] ) ? sanitize_text_field( $_POST['meetingDate'] ) : '' );
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.MissingUnslash
		$meeting_time = ( isset( $_POST['meetingTime'] ) ? sanitize_text_field( $_POST['meetingTime'] ) : '' );
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.MissingUnslash
		$meeting_duration = ( isset( $_POST['meetingDuration'] ) ? sanitize_text_field( $_POST['meetingDuration'] ) : '' );
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.MissingUnslash
		$meeting_duration_unit = ( isset( $_POST['meetingTimeUnit'] ) ? sanitize_text_field( $_POST['meetingTimeUnit'] ) : 'minute' );
		$timezone = ( isset( $_POST['meetingTimeZone'] ) ? sanitize_text_field( wp_unslash( $_POST['meetingTimeZone'] ) ) : '' );
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotValidated
		$password = sanitize_text_field( wp_unslash( $_POST['meetingPassword'] ) );

		$meeting_start_time    = \DateTime::createFromFormat( 'Y-m-d H:i', $meeting_date . ' ' . $meeting_time );
		if ( ! $meeting_start_time ) {
			wp_send_json_error( __( 'Sorry, Invalid Date Time Format', 'academy-pro' ) );
		}
		// The meeting lives in its author's Zoom account (per-instructor mode),
		// even when an admin is the one editing it.
		$host_id = (int) $meeting_post->post_author;
		$before  = MeetingCalendar::describe( $post_id );

		$request_body     = wp_json_encode(array(
			'topic'      => $meeting_title,
			'type'       => 2,
			'start_time' => $meeting_start_time->format( 'Y-m-d\TH:i:s' ),
			'timezone'   => $timezone,
			'duration'   => ( 'hour' === $meeting_duration_unit ? $meeting_duration * 60 : $meeting_duration ),
			'password'   => $password,
			'settings'   => self::get_user_zoom_settings( $user_id ),
		));

			$response_code = wp_remote_retrieve_response_code(wp_remote_post('https://api.zoom.us/v2/meetings/' . $meeting_id, array(
				'method'     => 'PATCH',
				'headers' => array(
					'Authorization' => 'Bearer ' . self::get_access_token( $host_id ),
					'Content-Type' => 'application/json',
				),
				'body'  => $request_body
			)));

		if ( 204 !== (int) $response_code ) {
			wp_send_json_error( __( 'Sorry, Failed to update zoom meeting', 'academy-pro' ) );
		}

		// Update Existing Response
		$zoom_response = json_decode( get_post_meta( $post_id, 'academy_meeting_response', true ), true );
		$zoom_response['topic']   = $meeting_title;
		$zoom_response['start_time'] = $meeting_start_time->format( 'Y-m-d\TH:i:s' );
		$zoom_response['duration'] = ( 'hour' === $meeting_duration_unit ? $meeting_duration * 60 : $meeting_duration );
		$zoom_response['timezone'] = $timezone;
		$zoom_response['password'] = $password;
		$zoom_response['settings'] = array_merge( (array) ( $zoom_response['settings'] ?? [] ), self::get_user_zoom_settings( $user_id ) );
		// Only forms that show the option send it; others leave it unchanged.
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- only compared
		$invite = isset( $_POST['invite_students'] ) ? ( ! empty( $_POST['invite_students'] ) && 'false' !== $_POST['invite_students'] ) : null;
		$zoom_response['inviteStudents'] = null === $invite ? GoogleMeetInvites::is_enabled( $post_id ) : $invite;

		$args = array(
			'ID' => $post_id,
			'post_title'    => $meeting_title,
			'post_content'  => $meeting_description,
			'post_status'   => 'publish',
			'post_type'     => 'academy_meeting',
			'meta_input'    => array(
				'academy_meeting_type' => 'zoom',
				'academy_meeting_request' => $request_body,
				'academy_meeting_response' => wp_json_encode( $zoom_response )

			)
		);
		$is_post = wp_update_post( $args );

		// Tell invited students about a new time, then invite anyone new.
		$after = MeetingCalendar::describe( $post_id );
		if ( $before && $after && ( $before['start'] !== $after['start'] || $before['end'] !== $after['end'] ) ) {
			ZoomInvites::send_update( $post_id );
		}
		if ( null !== $invite ) {
			GoogleMeetInvites::set_enabled( $post_id, $invite );
		}
		wp_send_json_success( [ 'post_id' => $is_post ] );
	}

	/**
	 * Forget this user's (or the shared) Zoom credentials. Meetings already
	 * created in Zoom are not affected.
	 */
	public function disconnect_zoom() {
		check_ajax_referer( 'academy_nonce', 'security' );
		if ( ! current_user_can( 'manage_academy_instructor' ) ) {
			wp_die();
		}
		if ( 'individual' !== self::$type && empty( wp_get_current_user()->allcaps['manage_options'] ) ) {
			wp_send_json_error( esc_html__( 'Sorry, you are not allowed to change these credentials.', 'academy-pro' ) );
		}
		if ( 'individual' === self::$type ) {
			delete_user_meta( get_current_user_id(), 'academy_pro_zoom_credentials' );
		} else {
			delete_option( 'academy_pro_zoom_credentials' );
		}
		delete_transient( 'academy_pro_zoom_access_token_' . get_current_user_id() );
		wp_send_json_success( __( 'Zoom disconnected.', 'academy-pro' ) );
	}

	/**
	 * The Zoom meeting ID saved on an Academy meeting when it was created.
	 *
	 * @param int $post_id Academy meeting post ID.
	 * @return int
	 */
	private static function stored_meeting_id( $post_id ) {
		$response = json_decode( (string) get_post_meta( $post_id, 'academy_meeting_response', true ), true );
		return is_array( $response ) ? (int) ( $response['id'] ?? 0 ) : 0;
	}

	/**
	 * Delete the meeting on Zoom and in Academy. The caller
	 * (Common::delete_meeting) has checked ownership; the Zoom ID is read from
	 * the meeting, not taken from the request.
	 *
	 * @param string $meeting_id Ignored; kept for the caller's signature.
	 * @param int    $post_id    Academy meeting post ID.
	 */
	public function delete_zoom_meeting( $meeting_id, $post_id ) {
		check_ajax_referer( 'academy_nonce', 'security' );
		if ( ! current_user_can( 'manage_academy_instructor' ) ) {
			wp_die();
		}
		// The meeting lives in its author's Zoom account (per-instructor mode),
		// even when an admin is the one deleting it.
		$host_id    = (int) get_post_field( 'post_author', $post_id );
		$meeting_id = self::stored_meeting_id( $post_id );
		if ( ! $meeting_id ) {
			// Nothing on Zoom to cancel; just remove the Academy meeting.
			wp_delete_post( $post_id, true );
			wp_send_json_success( [ 'post_id' => $post_id ] );
		}

		$request_body     = wp_json_encode(array(
			'meetingId' => $meeting_id,
		));

		$response_code = wp_remote_retrieve_response_code(wp_remote_post('https://api.zoom.us/v2/meetings/' . $meeting_id, array(
			'method'     => 'DELETE',
			'headers' => array(
				'Authorization' => 'Bearer ' . self::get_access_token( $host_id ),
				'Content-Type' => 'application/json',
			),
			'body'  => $request_body
		)));

		if ( 204 !== (int) $response_code && 404 !== $response_code ) {
			wp_send_json_error( __( 'Sorry, Failed to Delete Zoom Meeting.', 'academy-pro' ) );
		}

		wp_delete_post( $post_id, true );
		wp_send_json_success( [ 'post_id' => $post_id ] );
	}
}
