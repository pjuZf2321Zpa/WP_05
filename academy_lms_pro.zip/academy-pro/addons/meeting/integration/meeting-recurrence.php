<?php
namespace AcademyProMeeting\Integration;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Recurring classes ("every Tue and Thu at 7 PM, 10 sessions").
 *
 * The provider holds one real recurring series (a Google Calendar event with
 * an RRULE, or a Zoom recurring meeting) with one join link. Academy keeps
 * the rule plus the series' first start on the meeting, and the stored start
 * time always points at the current or next session — rolled forward when a
 * session ends — so the list, the student countdown and reminders work per
 * session without knowing about recurrence.
 *
 * Rule: { freq: daily|weekly, interval: int, days: [MO..SU], count: int|null, until: Y-m-d|null }.
 */
class MeetingRecurrence {
	const MAX_SESSIONS = 50;
	const HOOK_ROLL    = 'academy_pro_meeting_roll_recurring';
	const DAYS         = array( 'MO', 'TU', 'WE', 'TH', 'FR', 'SA', 'SU' );

	public static function init() {
		add_action( self::HOOK_ROLL, array( __CLASS__, 'roll_all' ) );
		add_action( 'init', array( __CLASS__, 'schedule' ) );
	}

	public static function schedule() {
		if ( ! wp_next_scheduled( self::HOOK_ROLL ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'hourly', self::HOOK_ROLL );
		}
	}

	/**
	 * Validate a rule from a form; null when it isn't a usable rule.
	 *
	 * @param mixed $raw Rule array or JSON string.
	 * @return array|null
	 */
	public static function sanitize( $raw ) {
		if ( is_string( $raw ) ) {
			$raw = json_decode( wp_unslash( $raw ), true );
		}
		if ( ! is_array( $raw ) || empty( $raw['freq'] ) || ! in_array( $raw['freq'], array( 'daily', 'weekly' ), true ) ) {
			return null;
		}
		$days = array_values( array_intersect( self::DAYS, array_map( 'strtoupper', (array) ( $raw['days'] ?? array() ) ) ) );
		$rule = array(
			'freq'     => $raw['freq'],
			'interval' => max( 1, min( 12, (int) ( $raw['interval'] ?? 1 ) ) ),
			'days'     => 'weekly' === $raw['freq'] ? $days : array(),
			'count'    => null,
			'until'    => null,
		);
		if ( ! empty( $raw['until'] ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $raw['until'] ) ) {
			$rule['until'] = (string) $raw['until'];
		} else {
			$rule['count'] = max( 2, min( self::MAX_SESSIONS, (int) ( $raw['count'] ?? 10 ) ) );
		}
		return $rule;
	}

	/**
	 * Session start times of a series, oldest first.
	 *
	 * @param array  $rule     Sanitized rule.
	 * @param int    $first    Unix start of the first session.
	 * @param string $timezone Series timezone (weekdays are counted in it).
	 * @return int[]
	 */
	public static function occurrences( array $rule, $first, $timezone ) {
		try {
			$zone = new \DateTimeZone( $timezone ? $timezone : 'UTC' );
		} catch ( \Exception $e ) {
			$zone = new \DateTimeZone( 'UTC' );
		}
		$start = ( new \DateTimeImmutable( '@' . (int) $first ) )->setTimezone( $zone );
		$until = $rule['until'] ? new \DateTimeImmutable( $rule['until'] . ' 23:59:59', $zone ) : null;
		$limit = $rule['count'] ? (int) $rule['count'] : self::MAX_SESSIONS;
		$days  = $rule['days'] ? $rule['days'] : array( self::DAYS[ (int) $start->format( 'N' ) - 1 ] );

		$out = array();
		// Walk day by day (same time of day), keeping days that match the rule.
		$week0 = (int) $start->modify( 'monday this week' )->format( 'U' );
		for ( $i = 0; $i < 3660; $i++ ) {
			if ( count( $out ) >= $limit ) {
				break;
			}
			$day = $start->modify( '+' . $i . ' days' );
			if ( $until && $day > $until ) {
				break;
			}
			if ( 'daily' === $rule['freq'] ) {
				$match = 0 === $i % $rule['interval'];
			} else {
				$weeks = (int) floor( ( (int) $day->modify( 'monday this week' )->format( 'U' ) - $week0 ) / WEEK_IN_SECONDS + 0.5 );
				$match = 0 === $weeks % $rule['interval'] && in_array( self::DAYS[ (int) $day->format( 'N' ) - 1 ], $days, true );
			}
			if ( $match ) {
				$out[] = (int) $day->format( 'U' );
			}
		}
		return $out;
	}

	/**
	 * The session happening now, or the next one.
	 *
	 * @param array  $rule     Sanitized rule.
	 * @param int    $first    Unix start of the first session.
	 * @param int    $length   Session length in seconds.
	 * @param string $timezone Series timezone.
	 * @param int    $now      Current time.
	 * @return array|null { start, end, index (1-based), total } or null when the series is over.
	 */
	public static function current( array $rule, $first, $length, $timezone, $now = null ) {
		$now      = $now ? $now : time();
		$sessions = self::occurrences( $rule, $first, $timezone );
		foreach ( $sessions as $i => $start ) {
			if ( $start + $length >= $now ) {
				return array(
					'start' => $start,
					'end'   => $start + $length,
					'index' => $i + 1,
					'total' => count( $sessions ),
				);
			}
		}
		return null;
	}

	/**
	 * RFC 5545 RRULE (Google Calendar, .ics).
	 *
	 * @param array $rule Sanitized rule.
	 * @return string
	 */
	public static function rrule( array $rule ) {
		$parts = array( 'FREQ=' . strtoupper( $rule['freq'] ) );
		if ( $rule['interval'] > 1 ) {
			$parts[] = 'INTERVAL=' . $rule['interval'];
		}
		if ( 'weekly' === $rule['freq'] && $rule['days'] ) {
			$parts[] = 'BYDAY=' . implode( ',', $rule['days'] );
		}
		if ( $rule['until'] ) {
			$parts[] = 'UNTIL=' . gmdate( 'Ymd\THis\Z', strtotime( $rule['until'] . ' 23:59:59 UTC' ) );
		} else {
			$parts[] = 'COUNT=' . (int) $rule['count'];
		}
		return 'RRULE:' . implode( ';', $parts );
	}

	/**
	 * Zoom's recurrence object (meeting type 8, fixed time).
	 *
	 * @param array $rule Sanitized rule.
	 * @return array
	 */
	public static function zoom( array $rule ) {
		$zoom = array(
			'type'            => 'weekly' === $rule['freq'] ? 2 : 1,
			'repeat_interval' => $rule['interval'],
		);
		if ( 'weekly' === $rule['freq'] && $rule['days'] ) {
			// Zoom numbers weekdays 1 = Sunday … 7 = Saturday.
			$map                 = array(
				'SU' => 1,
				'MO' => 2,
				'TU' => 3,
				'WE' => 4,
				'TH' => 5,
				'FR' => 6,
				'SA' => 7,
			);
			$zoom['weekly_days'] = implode( ',', array_map( fn( $d ) => $map[ $d ], $rule['days'] ) );
		}
		if ( $rule['until'] ) {
			$zoom['end_date_time'] = gmdate( 'Y-m-d\TH:i:s\Z', strtotime( $rule['until'] . ' 23:59:59 UTC' ) );
		} else {
			$zoom['end_times'] = (int) $rule['count'];
		}
		return $zoom;
	}

	/**
	 * Short human description, e.g. "Weekly on Tue, Thu · 10 sessions".
	 *
	 * @param array $rule Sanitized rule.
	 * @return string
	 */
	public static function describe( array $rule ) {
		$labels = array(
			'MO' => __( 'Mon', 'academy-pro' ),
			'TU' => __( 'Tue', 'academy-pro' ),
			'WE' => __( 'Wed', 'academy-pro' ),
			'TH' => __( 'Thu', 'academy-pro' ),
			'FR' => __( 'Fri', 'academy-pro' ),
			'SA' => __( 'Sat', 'academy-pro' ),
			'SU' => __( 'Sun', 'academy-pro' ),
		);
		if ( 'daily' === $rule['freq'] ) {
			/* translators: %d: every N days */
			$text = 1 === $rule['interval'] ? __( 'Daily', 'academy-pro' ) : sprintf( __( 'Every %d days', 'academy-pro' ), $rule['interval'] );
		} else {
			$on = $rule['days'] ? ' ' . __( 'on', 'academy-pro' ) . ' ' . implode( ', ', array_map( fn( $d ) => $labels[ $d ], $rule['days'] ) ) : '';
			/* translators: %d: every N weeks */
			$text = ( 1 === $rule['interval'] ? __( 'Weekly', 'academy-pro' ) : sprintf( __( 'Every %d weeks', 'academy-pro' ), $rule['interval'] ) ) . $on;
		}
		if ( $rule['until'] ) {
			/* translators: %s: end date */
			return $text . ' · ' . sprintf( __( 'until %s', 'academy-pro' ), wp_date( get_option( 'date_format' ), strtotime( $rule['until'] ) ) );
		}
		/* translators: %d: number of sessions */
		return $text . ' · ' . sprintf( _n( '%d session', '%d sessions', (int) $rule['count'], 'academy-pro' ), (int) $rule['count'] );
	}

	/**
	 * Point the stored start/end at the current or next session. Clears the
	 * reminder/started flags when moving to a new session, so each session
	 * gets its own reminder.
	 *
	 * @param int $post_id Academy meeting post ID.
	 * @return bool Whether anything changed.
	 */
	public static function roll( $post_id ) {
		$response = json_decode( (string) get_post_meta( $post_id, 'academy_meeting_response', true ), true );
		$rule     = is_array( $response ) ? self::sanitize( $response['recurrence'] ?? null ) : null;
		if ( ! $rule || empty( $response['seriesStart'] ) ) {
			return false;
		}
		$first  = strtotime( (string) $response['seriesStart'] );
		$length = max( MINUTE_IN_SECONDS, (int) ( $response['seriesLength'] ?? HOUR_IN_SECONDS ) );
		$tz     = (string) ( $response['seriesTimezone'] ?? 'UTC' );
		$now    = self::current( $rule, $first, $length, $tz );
		if ( ! $now ) {
			$now = array(
				'start' => $first,
				'end'   => $first + $length,
				'index' => 0,
				'total' => 0,
			);
			$last   = self::occurrences( $rule, $first, $tz );
			if ( $last ) {
				$now['start'] = end( $last );
				$now['end']   = $now['start'] + $length;
				$now['index'] = count( $last );
				$now['total'] = count( $last );
			}
		}

		$type    = get_post_meta( $post_id, 'academy_meeting_type', true );
		$current = 'zoom' === $type ? strtotime( (string) ( $response['start_time'] ?? '' ) ) : strtotime( (string) ( $response['meetingDate'] ?? '' ) );
		$changed = (int) $current !== (int) $now['start'] || (int) ( $response['sessionIndex'] ?? 0 ) !== (int) $now['index'];
		if ( ! $changed ) {
			return false;
		}

		if ( 'zoom' === $type ) {
			$response['start_time'] = gmdate( 'Y-m-d\TH:i:s\Z', $now['start'] );
			$response['duration']   = (int) round( $length / MINUTE_IN_SECONDS );
		} else {
			$zone                        = new \DateTimeZone( $tz );
			$response['meetingDate']     = ( new \DateTime( '@' . $now['start'] ) )->setTimezone( $zone )->format( \DateTime::ATOM );
			$response['meetingDuration'] = ( new \DateTime( '@' . $now['end'] ) )->setTimezone( $zone )->format( \DateTime::ATOM );
		}
		$response['sessionIndex'] = $now['index'];
		$response['sessionTotal'] = $now['total'];
		update_post_meta( $post_id, 'academy_meeting_response', wp_json_encode( $response ) );

		// A new session: let it have its own reminder and "started" notice.
		if ( (int) $current !== (int) $now['start'] ) {
			delete_post_meta( $post_id, '_academy_meeting_reminder_notified' );
			delete_post_meta( $post_id, '_academy_meeting_started_notified' );
			do_action( 'academy_pro/meeting/recurring_session_changed', $post_id, $now );
		}
		return true;
	}

	/** Hourly: roll every recurring meeting, 100 at a time. */
	public static function roll_all() {
		$page = 1;
		do {
			$ids = get_posts(
				array(
					'post_type'      => 'academy_meeting',
					'post_status'    => 'publish',
					'posts_per_page' => 100,
					'paged'          => $page,
					'orderby'        => 'ID',
					'order'          => 'ASC',
					'fields'         => 'ids',
					'no_found_rows'  => true,
					'meta_key'       => 'academy_meeting_response', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- hourly cron over meetings
					'meta_value'     => '"recurrence":{', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value -- matched with LIKE below
					'meta_compare'   => 'LIKE',
				)
			);
			foreach ( $ids as $id ) {
				self::roll( $id );
			}
			$found = count( $ids );
			++$page;
		} while ( 100 === $found );
	}

	/**
	 * Series fields to store on a new/updated meeting.
	 *
	 * @param array|null $rule     Sanitized rule, or null for a one-off meeting.
	 * @param int        $first    Unix start of the first session.
	 * @param int        $length   Session length in seconds.
	 * @param string     $timezone Series timezone.
	 * @return array Fields to merge into the stored response.
	 */
	public static function series_fields( $rule, $first, $length, $timezone ) {
		if ( ! $rule ) {
			return array(
				'recurrence'     => null,
				'seriesStart'    => null,
				'seriesLength'   => null,
				'seriesTimezone' => null,
				'sessionIndex'   => null,
				'sessionTotal'   => null,
			);
		}
		return array(
			'recurrence'     => $rule,
			'seriesStart'    => gmdate( 'Y-m-d\TH:i:s\Z', $first ),
			'seriesLength'   => (int) $length,
			'seriesTimezone' => $timezone ? $timezone : 'UTC',
			'recurrenceText' => self::describe( $rule ),
		);
	}
}
