<?php
namespace AcademyProMeeting\Integration;

use AcademyPro\Google\Client as Google_Client;
use AcademyPro\Google\Service\Calendar as Google_Service_Calendar;
use AcademyPro\Google\Service\Calendar\Event as Google_Service_Calendar_Event;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Google Meet through Google Calendar events with a Meet conference.
 *
 * Two modes (Settings → academy_meeting_api_handler_type):
 * - individual: each instructor connects their own Google account; the OAuth
 *   client, token and redirect URI live in that user's meta.
 * - globally:   one admin-connected account is shared; they live in options.
 *
 * The OAuth client JSON (it holds the client secret) is kept in meta/options
 * — never in the public uploads folder — and tokens never reach the browser.
 */
class GoogleMeet {
	const KEY_CLIENT      = 'academy_pro_google_meet_client';
	const KEY_TOKEN       = 'academy_pro_google_calendar_access_token';
	const KEY_REDIRECT    = 'academy_pro_google_meet_redirect_url';
	const KEY_LEGACY_FILE = 'academy_pro_google_meet_credential_filepath';

	/** @var string 'individual' or 'globally'. */
	private $type;

	public static function init() {
		$self = new self();
		add_action( 'wp_ajax_academy_pro_meeting/fetch_meet_credential', array( $self, 'fetch_meet_credential' ) );
		add_action( 'wp_ajax_academy_pro_meeting/save_meeting_credentials', array( $self, 'save_meeting_credentials' ) );
		add_action( 'wp_ajax_academy_pro_meeting/get_auth_code', array( $self, 'get_access_token' ) );
		add_action( 'wp_ajax_academy_pro_meeting/disconnect_google_meet', array( $self, 'disconnect' ) );
		add_action( 'wp_ajax_academy_pro_meeting/create_google_meet_meeting', array( $self, 'create_meeting' ) );
		add_action( 'wp_ajax_academy_pro_meeting/update_google_meet_meeting', array( $self, 'update_meeting' ) );
		add_action( 'admin_init', array( __CLASS__, 'migrate_public_credentials' ) );
		add_filter( 'academy/assets/backend_scripts_data', array( __CLASS__, 'set_scripts_data' ) );
	}

	/**
	 * The admin redirect URI for the setup guide to show — the same value
	 * save_meeting_credentials() sends Google, filters included.
	 *
	 * @param array $data Backend scripts data.
	 * @return array
	 */
	public static function set_scripts_data( $data ) {
		$data['google_meet_redirect_url'] = esc_url_raw( apply_filters( 'academy_pro/google_meet/redirect_url', admin_url( 'admin.php?page=academy-meeting' ), true ) );
		return $data;
	}

	public function __construct() {
		$this->type = self::get_type();
	}

	/**
	 * @return string 'individual' or 'globally'.
	 */
	private static function get_type() {
		return \Academy\Helper::get_settings( 'academy_meeting_api_handler_type', 'individual' );
	}

	/*
	 * Storage: per user in individual mode, site-wide options otherwise.
	 */

	/**
	 * @param string   $key     One of the KEY_* constants.
	 * @param int|null $user_id Defaults to the current user.
	 * @return mixed
	 */
	private static function read( $key, $user_id = null ) {
		if ( 'individual' === self::get_type() ) {
			return get_user_meta( $user_id ? $user_id : get_current_user_id(), $key, true );
		}
		return get_option( $key );
	}

	/**
	 * @param string   $key     One of the KEY_* constants.
	 * @param mixed    $value   Value to store.
	 * @param int|null $user_id Defaults to the current user.
	 */
	private static function write( $key, $value, $user_id = null ) {
		if ( 'individual' === self::get_type() ) {
			update_user_meta( $user_id ? $user_id : get_current_user_id(), $key, $value );
		} else {
			update_option( $key, $value, false );
		}
	}

	/**
	 * @param string   $key     One of the KEY_* constants.
	 * @param int|null $user_id Defaults to the current user.
	 */
	private static function forget( $key, $user_id = null ) {
		if ( 'individual' === self::get_type() ) {
			delete_user_meta( $user_id ? $user_id : get_current_user_id(), $key );
		} else {
			delete_option( $key );
		}
	}

	/*
	 * OAuth client (the uploaded JSON).
	 */

	/**
	 * Validate an OAuth client JSON download and keep only what the client
	 * needs.
	 *
	 * @param string $json Raw file contents.
	 * @return array|\WP_Error
	 */
	public static function parse_client_json( $json ) {
		$data = json_decode( (string) $json, true );
		$kind = is_array( $data ) ? ( isset( $data['web'] ) ? 'web' : ( isset( $data['installed'] ) ? 'installed' : '' ) ) : '';
		if ( ! $kind || empty( $data[ $kind ]['client_id'] ) || empty( $data[ $kind ]['client_secret'] ) ) {
			return new \WP_Error( 'invalid_client', __( 'This isn\'t an OAuth client file. In Google Cloud, create an OAuth client ID of type "Web application" and download its JSON.', 'academy-pro' ) );
		}
		$keys = [ 'client_id', 'client_secret', 'project_id', 'auth_uri', 'token_uri', 'auth_provider_x509_cert_url', 'redirect_uris' ];
		return [ $kind => array_intersect_key( $data[ $kind ], array_flip( $keys ) ) ];
	}

	/**
	 * @param int|null $user_id Defaults to the current user.
	 * @return array The OAuth client config, or [] when none is saved.
	 */
	public static function get_client_config( $user_id = null ) {
		$config = self::read( self::KEY_CLIENT, $user_id );
		return is_array( $config ) ? $config : [];
	}

	/**
	 * Older versions saved the uploaded JSON (client secret included) into
	 * the public uploads folder. Move each into meta/options and delete the
	 * files. Runs once.
	 */
	public static function migrate_public_credentials() {
		if ( 'yes' === \Academy\Options::get( \Academy\Options::PRO_MIGRATIONS, 'meet_private_credentials' ) ) {
			return;
		}

		$files = [];
		$path  = get_option( self::KEY_LEGACY_FILE );
		if ( $path ) {
			$config = self::read_legacy_file( $path, $files );
			if ( $config ) {
				update_option( self::KEY_CLIENT, $config, false );
			}
			delete_option( self::KEY_LEGACY_FILE );
		}

		$user_ids = get_users(
			[
				'meta_key' => self::KEY_LEGACY_FILE, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- one-time migration
				'fields'   => 'ID',
				'number'   => 500,
			]
		);
		foreach ( $user_ids as $user_id ) {
			$config = self::read_legacy_file( get_user_meta( $user_id, self::KEY_LEGACY_FILE, true ), $files );
			if ( $config ) {
				update_user_meta( $user_id, self::KEY_CLIENT, $config );
			}
			delete_user_meta( $user_id, self::KEY_LEGACY_FILE );
		}

		// Delete only after every user has been read — they may share a file.
		foreach ( array_keys( $files ) as $file ) {
			wp_delete_file( $file );
		}

		\Academy\Options::set( \Academy\Options::PRO_MIGRATIONS, 'meet_private_credentials', 'yes' );
	}

	/**
	 * @param string $path  Path relative to the uploads folder.
	 * @param array  $files Collects files to delete (by reference).
	 * @return array Parsed config, or [].
	 */
	private static function read_legacy_file( $path, array &$files ) {
		$upload = wp_upload_dir();
		$base   = realpath( $upload['basedir'] );
		$file   = realpath( $upload['basedir'] . '/' . ltrim( (string) $path, '/' ) );
		// Only ever touch the addon's own file inside uploads.
		if ( ! $file || ! $base || 0 !== strpos( $file, $base . DIRECTORY_SEPARATOR ) || 'meet_credential.json' !== basename( $file ) ) {
			return [];
		}
		$files[ $file ] = true;
		if ( ! is_readable( $file ) ) {
			return [];
		}
		$config = self::parse_client_json( file_get_contents( $file ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents, WordPressVIPMinimum.Performance.FetchingRemoteData.FileGetContentsUnknown -- local file, one-time migration
		return is_wp_error( $config ) ? [] : $config;
	}

	/*
	 * Client + token.
	 */

	/**
	 * The redirect URI registered for this user/site (admin page or the
	 * frontend dashboard, whichever they connected from). Filterable so local
	 * `*.test` sites can route the callback via localhost.
	 *
	 * @param int|null $user_id Defaults to the current user.
	 * @return string
	 */
	private static function get_redirect_url( $user_id = null ) {
		$url = self::read( self::KEY_REDIRECT, $user_id );
		if ( ! $url ) {
			// Older versions kept one site-wide value.
			$url = get_option( self::KEY_REDIRECT );
		}
		return (string) $url;
	}

	/**
	 * @param int|null $user_id Defaults to the current user.
	 * @return Google_Client
	 */
	private static function build_client( $user_id = null ) {
		$client = new Google_Client();
		$client->setApplicationName( 'Academy LMS Google Meet' );
		$client->setAuthConfig( self::get_client_config( $user_id ) );
		$client->setRedirectUri( self::get_redirect_url( $user_id ) );
		$client->addScope( [ Google_Service_Calendar::CALENDAR, Google_Service_Calendar::CALENDAR_EVENTS ] );
		$client->setAccessType( 'offline' );
		$client->setPrompt( 'consent' );
		return $client;
	}

	/**
	 * An authorised client for the user (or the shared account), refreshing
	 * an expired token. A token Google no longer accepts is forgotten, so the
	 * UI shows "not connected" and asks to reconnect.
	 *
	 * @param int|null $user_id Defaults to the current user.
	 * @return Google_Client|false
	 */
	public static function authorized_client( $user_id = null ) {
		$token = self::read( self::KEY_TOKEN, $user_id );
		if ( ! is_array( $token ) || empty( $token['access_token'] ) || ! self::get_client_config( $user_id ) ) {
			return false;
		}
		$client = self::build_client( $user_id );
		$client->setAccessToken( $token );
		if ( ! $client->isAccessTokenExpired() ) {
			return $client;
		}
		$refresh = $client->getRefreshToken();
		$new     = $refresh ? $client->fetchAccessTokenWithRefreshToken( $refresh ) : [];
		if ( empty( $new['access_token'] ) ) {
			self::forget( self::KEY_TOKEN, $user_id );
			return false;
		}
		self::write( self::KEY_TOKEN, $client->getAccessToken(), $user_id );
		return $client;
	}

	/**
	 * Whether Google Meet is connected for this instructor (individual mode)
	 * or for the site (shared mode).
	 *
	 * @param int|null $user_id Defaults to the current user.
	 * @return bool
	 */
	public static function is_configured( $user_id = null ) {
		$token = self::read( self::KEY_TOKEN, $user_id );
		return is_array( $token ) && ! empty( $token['access_token'] ) && ! empty( self::get_client_config( $user_id ) );
	}

	/**
	 * In shared mode only a real administrator may change the credentials.
	 * `allcaps` is read directly because Caps::elevate() grants
	 * manage_options broadly to any staff member for this request.
	 */
	private function verify_can_configure() {
		check_ajax_referer( 'academy_nonce', 'security' );
		if ( ! current_user_can( 'manage_academy_instructor' ) ) {
			wp_die();
		}
		if ( 'individual' !== $this->type && empty( wp_get_current_user()->allcaps['manage_options'] ) ) {
			wp_send_json_error( esc_html__( 'Sorry, you are not allowed to configure these credentials.', 'academy-pro' ) );
		}
	}

	/*
	 * AJAX: connection.
	 */

	/** Upload the OAuth client JSON: parsed and stored, never written to disk. */
	public function fetch_meet_credential() {
		$this->verify_can_configure();
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.NonceVerification.Missing -- verified above; the file is parsed, not stored
		$file = isset( $_FILES['upload_file'] ) ? $_FILES['upload_file'] : null;
		if ( ! $file || ! empty( $file['error'] ) || empty( $file['tmp_name'] ) || ! is_uploaded_file( $file['tmp_name'] ) ) {
			wp_send_json_error( __( 'The file didn\'t upload. Please try again.', 'academy-pro' ) );
		}
		if ( 'json' !== strtolower( pathinfo( (string) $file['name'], PATHINFO_EXTENSION ) ) || $file['size'] > 64 * KB_IN_BYTES ) {
			wp_send_json_error( __( 'Wrong file. Upload the OAuth client .json file you downloaded from Google Cloud.', 'academy-pro' ) );
		}
		$config = self::parse_client_json( file_get_contents( $file['tmp_name'] ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents, WordPressVIPMinimum.Performance.FetchingRemoteData.FileGetContentsUnknown -- local temp upload
		if ( is_wp_error( $config ) ) {
			wp_send_json_error( $config->get_error_message() );
		}
		self::write( self::KEY_CLIENT, $config );
		// A new OAuth client can't reuse the old client's token.
		self::forget( self::KEY_TOKEN );
		wp_send_json_success( __( 'Google Meet credentials saved.', 'academy-pro' ) );
	}

	/** Remember where Google should return to, and hand back the consent URL. */
	public function save_meeting_credentials() {
		$this->verify_can_configure();
		// Same rule as before: any non-empty `is_admin` (the UI sends "true"
		// or "false") means the admin page, so existing OAuth clients keep
		// working with the redirect URI they already registered.
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- verified above
		$is_admin = '' !== sanitize_text_field( wp_unslash( $_POST['is_admin'] ?? '' ) );
		$redirect = $is_admin
			? admin_url( 'admin.php?page=academy-meeting' )
			: \Academy\Helper::get_frontend_dashboard_endpoint_url( 'meeting' );
		$redirect = esc_url_raw( apply_filters( 'academy_pro/google_meet/redirect_url', $redirect, $is_admin ) );
		self::write( self::KEY_REDIRECT, $redirect );

		if ( ! self::get_client_config() ) {
			wp_send_json_error( __( 'Upload your OAuth client JSON first.', 'academy-pro' ) );
		}
		$client = self::build_client();
		$client->setRedirectUri( $redirect );
		wp_send_json_success( $client->createAuthUrl() );
	}

	/** Google redirected back with `code`: exchange it for a token. */
	public function get_access_token() {
		$this->verify_can_configure();
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- verified above
		$code = isset( $_POST['authCode'] ) ? sanitize_text_field( wp_unslash( $_POST['authCode'] ) ) : '';
		if ( '' === $code || ! self::get_client_config() ) {
			wp_send_json_error( __( 'Google didn\'t return an authorization code.', 'academy-pro' ) );
		}
		try {
			$token = self::build_client()->fetchAccessTokenWithAuthCode( $code );
		} catch ( \Exception $e ) {
			wp_send_json_error( $e->getMessage() );
		}
		if ( isset( $token['error'] ) ) {
			wp_send_json_error( $token['error_description'] ?? $token['error'] );
		}
		self::write( self::KEY_TOKEN, $token );
		wp_send_json_success( __( 'Google Meet connected.', 'academy-pro' ) );
	}

	/** Forget the token (and revoke it at Google); credentials are kept. */
	public function disconnect() {
		$this->verify_can_configure();
		$token = self::read( self::KEY_TOKEN );
		if ( is_array( $token ) && self::get_client_config() ) {
			try {
				self::build_client()->revokeToken( $token );
			} catch ( \Exception $e ) {
				unset( $e );
			}
		}
		self::forget( self::KEY_TOKEN );
		wp_send_json_success( __( 'Google Meet disconnected.', 'academy-pro' ) );
	}

	/*
	 * Meetings.
	 */

	/**
	 * Create a Google Meet event for a given instructor, independent of the
	 * request context. Reusable by AJAX and by the tutor-booking bridge.
	 *
	 * @param int   $user_id Instructor whose Google credentials are used.
	 * @param array $args    title, description, start_date, end_date, timezone.
	 * @return array|\WP_Error { post_id, meeting_id, join_url, response }
	 */
	public static function create_meeting_service( $user_id, $args ) {
		if ( ! self::is_configured( $user_id ) ) {
			return new \WP_Error( 'no_google_credentials', __( 'Google Meet is not connected for this instructor.', 'academy-pro' ) );
		}
		$client = self::authorized_client( $user_id );
		if ( ! $client ) {
			return new \WP_Error( 'google_reauth_required', __( 'Google Meet needs to be reconnected for this instructor.', 'academy-pro' ) );
		}

		$title       = sanitize_text_field( $args['title'] ?? '' );
		$description = sanitize_textarea_field( $args['description'] ?? '' );
		$event       = self::build_event( $title, $description, $args['start_date'] ?? '', $args['end_date'] ?? '', $args['timezone'] ?? '' );
		if ( is_wp_error( $event ) ) {
			return $event;
		}

		try {
			$created = ( new Google_Service_Calendar( $client ) )->events->insert( 'primary', $event, array( 'conferenceDataVersion' => 1 ) );
		} catch ( \Exception $e ) {
			return new \WP_Error( 'google_create_failed', self::google_error_message( $e ) );
		}

		$data    = self::event_to_response( $created );
		$post_id = wp_insert_post(
			array(
				'post_title'   => $title,
				'post_content' => $description,
				'post_status'  => 'publish',
				'post_author'  => $user_id,
				'post_type'    => 'academy_meeting',
				'meta_input'   => array(
					'academy_meeting_type'     => 'google_meet',
					'academy_meeting_request'  => wp_json_encode( $data ),
					'academy_meeting_response' => wp_json_encode( $data ),
				),
			)
		);

		return array(
			'post_id'    => $post_id,
			'meeting_id' => $data['meetingId'],
			'join_url'   => $data['meetingLink'],
			'response'   => wp_json_encode( $data ),
		);
	}

	/**
	 * @param string $title       Event title.
	 * @param string $description Event description.
	 * @param string $start_date  Start date/time.
	 * @param string $end_date    End date/time.
	 * @param string $timezone    IANA timezone; UTC when empty.
	 * @return Google_Service_Calendar_Event|\WP_Error
	 */
	private static function build_event( $title, $description, $start_date, $end_date, $timezone ) {
		$timezone = sanitize_text_field( $timezone );
		$timezone = '' !== $timezone ? $timezone : 'UTC';
		try {
			$start = new \DateTime( (string) $start_date, new \DateTimeZone( $timezone ) );
			$end   = new \DateTime( (string) $end_date, new \DateTimeZone( $timezone ) );
		} catch ( \Exception $e ) {
			return new \WP_Error( 'invalid_datetime', __( 'The meeting date, time or timezone isn\'t valid.', 'academy-pro' ) );
		}
		if ( $end <= $start ) {
			return new \WP_Error( 'invalid_duration', __( 'The meeting must end after it starts.', 'academy-pro' ) );
		}

		return new Google_Service_Calendar_Event(
			array(
				'summary'        => $title,
				'location'       => 'Google Meet',
				'description'    => $description,
				'start'          => array(
					'dateTime' => $start->format( \DateTime::ATOM ),
					'timeZone' => $timezone,
				),
				'end'            => array(
					'dateTime' => $end->format( \DateTime::ATOM ),
					'timeZone' => $timezone,
				),
				'conferenceData' => array(
					'createRequest' => array(
						'requestId'             => wp_generate_uuid4(),
						'conferenceSolutionKey' => array( 'type' => 'hangoutsMeet' ),
					),
				),
			)
		);
	}

	/**
	 * @param Google_Service_Calendar_Event $event A created/updated event.
	 * @return array The meeting data stored on the Academy meeting post.
	 */
	private static function event_to_response( $event ) {
		return array(
			'meetingId'          => $event->getId(),
			'meetingLink'        => $event->getHangoutLink(),
			'meetingTitle'       => $event->getSummary(),
			'meetingDescription' => $event->getDescription(),
			'meetingDate'        => $event->getStart()->getDateTime(),
			'meetingDuration'    => $event->getEnd()->getDateTime(),
			'meetingTimezone'    => $event->getStart()->getTimeZone(),
			'meetingStatus'      => $event->getStatus(),
			'meetCode'           => self::meet_code( $event->getHangoutLink() ),
		);
	}

	/**
	 * The code people type into Meet, e.g. abc-defg-hij, from its link.
	 *
	 * @param string $link Meet link.
	 * @return string
	 */
	public static function meet_code( $link ) {
		return preg_match( '#meet\.google\.com/([a-z]{3}-[a-z]{4}-[a-z]{3})#i', (string) $link, $m ) ? strtolower( $m[1] ) : '';
	}

	/**
	 * @param \Exception $e A caught Google API exception.
	 * @return string A readable message (Google's is JSON).
	 */
	public static function google_error_message( \Exception $e ) {
		$data = json_decode( $e->getMessage(), true );
		return isset( $data['error']['message'] ) ? (string) $data['error']['message'] : $e->getMessage();
	}

	/**
	 * The Google event ID stored on an Academy meeting post — never taken
	 * from the request, so a user can only touch the event their own meeting
	 * points to (in shared mode everyone uses one calendar).
	 *
	 * @param int $post_id Academy meeting post ID.
	 * @return string
	 */
	private static function stored_event_id( $post_id ) {
		$response = json_decode( (string) get_post_meta( $post_id, 'academy_meeting_response', true ), true );
		return is_array( $response ) ? (string) ( $response['meetingId'] ?? '' ) : '';
	}

	/** Not connected (or connection expired) → one clear error. */
	private function client_or_fail() {
		$client = self::authorized_client();
		if ( ! $client ) {
			wp_send_json_error( esc_html__( 'Google Meet is not connected, or the connection expired. Connect your Google account again.', 'academy-pro' ) );
		}
		return $client;
	}

	public function create_meeting() {
		check_ajax_referer( 'academy_nonce', 'security' );
		if ( ! current_user_can( 'manage_academy_instructor' ) ) {
			wp_die();
		}
		$client = $this->client_or_fail();

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- verified above
		$event = self::build_event(
			isset( $_POST['title'] ) ? sanitize_text_field( wp_unslash( $_POST['title'] ) ) : '',
			isset( $_POST['content'] ) ? sanitize_textarea_field( wp_unslash( $_POST['content'] ) ) : '',
			isset( $_POST['start_date'] ) ? sanitize_text_field( wp_unslash( $_POST['start_date'] ) ) : '',
			isset( $_POST['end_date'] ) ? sanitize_text_field( wp_unslash( $_POST['end_date'] ) ) : '',
			isset( $_POST['timezone'] ) ? sanitize_text_field( wp_unslash( $_POST['timezone'] ) ) : ''
		);
		// phpcs:enable
		if ( is_wp_error( $event ) ) {
			wp_send_json_error( $event->get_error_message() );
		}

		try {
			$created = ( new Google_Service_Calendar( $client ) )->events->insert( 'primary', $event, array( 'conferenceDataVersion' => 1 ) );
		} catch ( \Exception $e ) {
			wp_send_json_error( sprintf( /* translators: %s: error from Google */ __( 'Google couldn\'t create the meeting: %s', 'academy-pro' ), self::google_error_message( $e ) ) );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- verified above
		$invite = ! empty( $_POST['invite_students'] ) && 'false' !== $_POST['invite_students'];
		$this->create_academy_meeting_callback( self::event_to_response( $created ), $invite );
	}

	/**
	 * @param array $data   Meeting data from event_to_response().
	 * @param bool  $invite Invite the enrolled students of the meeting's course(s).
	 */
	public function create_academy_meeting_callback( $data, $invite = false ) {
		$data['inviteStudents'] = (bool) $invite;
		$post_id = wp_insert_post(
			array(
				'post_title'   => sanitize_text_field( $data['meetingTitle'] ),
				'post_content' => sanitize_textarea_field( (string) $data['meetingDescription'] ),
				'post_status'  => 'publish',
				'post_author'  => get_current_user_id(),
				'post_type'    => 'academy_meeting',
				'meta_input'   => array(
					'academy_meeting_type'     => 'google_meet',
					'academy_meeting_request'  => wp_json_encode( $data ),
					'academy_meeting_response' => wp_json_encode( $data ),
				),
			)
		);
		// Not in a course yet on create; the flag is kept and the guest list
		// fills in when the meeting is added to a course curriculum.
		if ( $post_id && $invite ) {
			update_post_meta( $post_id, GoogleMeetInvites::META_ENABLED, 1 );
		}
		wp_send_json_success( [ 'post_id' => $post_id ] );
	}

	/**
	 * @param int $post_id Academy meeting post ID.
	 * @return bool Whether the current user owns the meeting or is an admin.
	 */
	private static function can_manage_meeting( $post_id ) {
		$post = get_post( $post_id );
		return $post && 'academy_meeting' === $post->post_type
			&& ( get_current_user_id() === (int) $post->post_author || current_user_can( 'manage_options' ) );
	}

	public function update_meeting() {
		check_ajax_referer( 'academy_nonce', 'security' );
		if ( ! current_user_can( 'manage_academy_instructor' ) ) {
			wp_die();
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- verified above
		$post_id = isset( $_POST['post_id'] ) ? absint( $_POST['post_id'] ) : 0;
		if ( ! self::can_manage_meeting( $post_id ) ) {
			wp_send_json_error( esc_html__( 'Sorry, you are not allowed to modify this meeting.', 'academy-pro' ) );
		}
		$event_id = self::stored_event_id( $post_id );
		if ( '' === $event_id ) {
			wp_send_json_error( esc_html__( 'This meeting isn\'t linked to a Google Calendar event.', 'academy-pro' ) );
		}
		$client = $this->client_or_fail();

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- verified above
		$changes = self::build_event(
			isset( $_POST['title'] ) ? sanitize_text_field( wp_unslash( $_POST['title'] ) ) : '',
			isset( $_POST['content'] ) ? sanitize_textarea_field( wp_unslash( $_POST['content'] ) ) : '',
			isset( $_POST['start_date'] ) ? sanitize_text_field( wp_unslash( $_POST['start_date'] ) ) : '',
			isset( $_POST['end_date'] ) ? sanitize_text_field( wp_unslash( $_POST['end_date'] ) ) : '',
			isset( $_POST['timezone'] ) ? sanitize_text_field( wp_unslash( $_POST['timezone'] ) ) : ''
		);
		// phpcs:enable
		if ( is_wp_error( $changes ) ) {
			wp_send_json_error( $changes->get_error_message() );
		}

		try {
			$calendar = new Google_Service_Calendar( $client );
			$event    = $calendar->events->get( 'primary', $event_id );
			$event->setSummary( $changes->getSummary() );
			$event->setDescription( $changes->getDescription() );
			$event->setStart( $changes->getStart() );
			$event->setEnd( $changes->getEnd() );
			$updated = $calendar->events->update( 'primary', $event_id, $event );
		} catch ( \Exception $e ) {
			wp_send_json_error( sprintf( /* translators: %s: error from Google */ __( 'Google couldn\'t update the meeting: %s', 'academy-pro' ), self::google_error_message( $e ) ) );
		}

		// Only forms that show the option send it; others leave it unchanged.
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- verified above
		$invite = isset( $_POST['invite_students'] ) ? ( ! empty( $_POST['invite_students'] ) && 'false' !== $_POST['invite_students'] ) : null;
		$data   = self::event_to_response( $updated );

		$data['inviteStudents'] = null === $invite ? GoogleMeetInvites::is_enabled( $post_id ) : $invite;
		$this->update_academy_meeting_callback( $post_id, $data, $invite );
	}

	/**
	 * @param int       $post_id Academy meeting post ID.
	 * @param array     $data    Meeting data from event_to_response().
	 * @param bool|null $invite  Invite enrolled students; null leaves it as is.
	 */
	public function update_academy_meeting_callback( $post_id, $data, $invite = null ) {
		// The author stays the meeting's owner even when an admin edits it.
		$updated = wp_update_post(
			array(
				'ID'           => $post_id,
				'post_title'   => sanitize_text_field( $data['meetingTitle'] ),
				'post_content' => sanitize_textarea_field( (string) $data['meetingDescription'] ),
				'meta_input'   => array(
					'academy_meeting_request'  => wp_json_encode( $data ),
					'academy_meeting_response' => wp_json_encode( $data ),
				),
			)
		);
		if ( null !== $invite ) {
			// Sync now so the host sees the guest list change straight away.
			GoogleMeetInvites::set_enabled( $post_id, $invite );
		}
		wp_send_json_success( [ 'post_id' => $updated ] );
	}

	/**
	 * Delete the meeting's Google event and the Academy meeting. The caller
	 * (Common::delete_meeting) has already checked ownership; the event ID is
	 * read from the meeting, not from the request.
	 *
	 * @param string $meeting_id Ignored; kept for the caller's signature.
	 * @param int    $post_id    Academy meeting post ID.
	 */
	public function delete_google_meet_meeting( $meeting_id, $post_id ) {
		unset( $meeting_id );
		$event_id = self::stored_event_id( $post_id );
		if ( '' !== $event_id ) {
			$client = $this->client_or_fail();
			try {
				( new Google_Service_Calendar( $client ) )->events->delete( 'primary', $event_id );
			} catch ( \Exception $e ) {
				// Already gone in Google (deleted or cancelled there) is fine.
				if ( ! in_array( (int) $e->getCode(), [ 404, 410 ], true ) ) {
					wp_send_json_error( sprintf( /* translators: %s: error from Google */ __( 'Google couldn\'t delete the meeting: %s', 'academy-pro' ), self::google_error_message( $e ) ) );
				}
			}
		}
		wp_delete_post( $post_id, true );
		wp_send_json_success( [ 'post_id' => $post_id ] );
	}
}
