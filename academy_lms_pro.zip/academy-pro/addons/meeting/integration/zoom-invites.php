<?php
namespace AcademyProMeeting\Integration;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Zoom has no guest list on free plans, so for Zoom meetings Academy emails
 * each enrolled student the join details with a calendar (.ics) file, and
 * emails an update when the time changes. Also keeps the Academy meeting in
 * step with the meeting in Zoom (moved or deleted there).
 */
class ZoomInvites {
	const META_EMAILED  = 'academy_zoom_emailed';
	const META_SEQUENCE = 'academy_zoom_invite_sequence';

	/** How long a meeting page trusts its copy of the Zoom meeting. */
	const REFRESH_TTL = 10 * MINUTE_IN_SECONDS;

	/**
	 * Email students who haven't been invited yet; forget ones who left, so
	 * they're invited again if they re-enrol. Emails can't be taken back, so
	 * nobody is "removed".
	 *
	 * @param int $post_id Academy meeting post ID.
	 * @return array|\WP_Error { invited, added, removed }
	 */
	public static function sync( $post_id ) {
		$wanted = GoogleMeetInvites::is_enabled( $post_id )
			? GoogleMeetInvites::enrolled_emails( GoogleMeetInvites::courses_with_meeting( $post_id ) )
			: array();
		// An unset meta is '' — (array) '' would be [''], so drop empties.
		$sent   = array_values( array_filter( array_map( 'strtolower', (array) get_post_meta( $post_id, self::META_EMAILED, true ) ) ) );
		$new    = array_values( array_diff( $wanted, $sent ) );

		if ( $new ) {
			$failed = self::send( $post_id, $new, false );
			if ( count( $failed ) === count( $new ) ) {
				return new \WP_Error( 'mail_failed', __( 'The invitation emails couldn\'t be sent. Check that this site can send email.', 'academy-pro' ) );
			}
			$new = array_values( array_diff( $new, $failed ) );
		}

		$still = array_values( array_intersect( $sent, $wanted ) );
		update_post_meta( $post_id, self::META_EMAILED, array_values( array_unique( array_merge( $still, $new ) ) ) );
		update_post_meta( $post_id, GoogleMeetInvites::META_SYNCED_AT, time() );
		return array(
			'invited' => count( $wanted ),
			'added'   => count( $new ),
			'removed' => count( $sent ) - count( $still ),
		);
	}

	/**
	 * Tell everyone already invited that the meeting changed (new time or
	 * link), with an updated calendar file that replaces the old entry.
	 *
	 * @param int $post_id Academy meeting post ID.
	 */
	public static function send_update( $post_id ) {
		$sent = array_values( array_filter( (array) get_post_meta( $post_id, self::META_EMAILED, true ) ) );
		if ( $sent && GoogleMeetInvites::is_enabled( $post_id ) ) {
			self::send( $post_id, $sent, true );
		}
	}

	/**
	 * One email per student, so nobody sees the others' addresses.
	 *
	 * @param int      $post_id   Academy meeting post ID.
	 * @param string[] $emails    Recipients.
	 * @param bool     $is_update Whether this is a change notice.
	 * @return string[] Emails that failed.
	 */
	private static function send( $post_id, array $emails, $is_update ) {
		$meeting = MeetingCalendar::describe( $post_id );
		if ( ! $meeting ) {
			return $emails;
		}
		$sequence = (int) get_post_meta( $post_id, self::META_SEQUENCE, true ) + ( $is_update ? 1 : 0 );
		update_post_meta( $post_id, self::META_SEQUENCE, $sequence );

		$ics  = MeetingCalendar::ics( $post_id, $sequence );
		// wp_tempnam() creates the file; the .ics copy is what gets attached.
		$tmp  = wp_tempnam( 'academy-meeting' );
		$file = $tmp . '.ics';
		file_put_contents( $file, $ics ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents, WordPressVIPMinimum.Functions.RestrictedFunctions.file_ops_file_put_contents -- temp-dir attachment, removed below

		$when = wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $meeting['start'], new \DateTimeZone( $meeting['timezone'] ) );
		/* translators: 1: meeting title, 2: date and time */
		$subject = sprintf( $is_update ? __( 'Updated: %1$s — %2$s', 'academy-pro' ) : __( 'Invitation: %1$s — %2$s', 'academy-pro' ), $meeting['title'], $when );
		$body    = self::body( $meeting, $when, $is_update );
		$headers = array( 'Content-Type: text/html; charset=UTF-8' );

		$failed = array();
		foreach ( $emails as $email ) {
			// One per student so addresses stay private; runs in background cron.
			if ( ! wp_mail( $email, $subject, $body, $headers, array( $file ) ) ) { // phpcs:ignore WordPressVIPMinimum.Functions.RestrictedFunctions.wp_mail_wp_mail
				$failed[] = $email;
			}
		}
		wp_delete_file( $file );
		wp_delete_file( $tmp );
		return $failed;
	}

	/**
	 * @param array  $meeting   From MeetingCalendar::describe().
	 * @param string $when      Formatted start in the meeting's timezone.
	 * @param bool   $is_update Whether this is a change notice.
	 * @return string HTML body.
	 */
	private static function body( array $meeting, $when, $is_update ) {
		$rows = array(
			__( 'When', 'academy-pro' )     => esc_html( $when . ' (' . $meeting['timezone'] . ')' ),
			__( 'Join', 'academy-pro' )     => '<a href="' . esc_url( $meeting['link'] ) . '">' . esc_html( $meeting['link'] ) . '</a>',
			__( 'Passcode', 'academy-pro' ) => $meeting['password'] ? esc_html( $meeting['password'] ) : '',
		);
		$html  = '<p>' . esc_html( $is_update ? __( 'The meeting below has changed. The attached calendar file updates it in your calendar.', 'academy-pro' ) : __( 'You\'re invited to the meeting below. Open the attached file to add it to your calendar.', 'academy-pro' ) ) . '</p>';
		$html .= '<h2 style="margin:16px 0 8px">' . esc_html( $meeting['title'] ) . '</h2><table cellpadding="4">';
		foreach ( $rows as $label => $value ) {
			if ( '' !== $value ) {
				$html .= '<tr><td><strong>' . esc_html( $label ) . '</strong></td><td>' . $value . '</td></tr>';
			}
		}
		$html .= '</table>';
		if ( $meeting['description'] ) {
			$html .= '<p>' . nl2br( esc_html( $meeting['description'] ) ) . '</p>';
		}
		return $html;
	}

	/**
	 * Refresh the meeting from Zoom at most every REFRESH_TTL: picks up a new
	 * time/link and marks it cancelled when it was deleted in Zoom.
	 *
	 * @param int $post_id Academy meeting post ID.
	 */
	public static function refresh_from_zoom( $post_id ) {
		$key = 'academy_zoom_checked_' . (int) $post_id;
		if ( get_transient( $key ) ) {
			return;
		}
		set_transient( $key, 1, self::REFRESH_TTL );

		$response = json_decode( (string) get_post_meta( $post_id, 'academy_meeting_response', true ), true );
		$zoom_id  = is_array( $response ) ? (int) ( $response['id'] ?? 0 ) : 0;
		$token    = $zoom_id ? Zoom::get_access_token( (int) get_post_field( 'post_author', $post_id ) ) : '';
		if ( ! $zoom_id || ! $token ) {
			return;
		}
		$get   = function_exists( 'vip_safe_wp_remote_get' ) ? 'vip_safe_wp_remote_get' : 'wp_safe_remote_get';
		$reply = $get(
			'https://api.zoom.us/v2/meetings/' . $zoom_id,
			array(
				'headers' => array( 'Authorization' => 'Bearer ' . $token ),
				'timeout' => 5, // phpcs:ignore WordPressVIPMinimum.Performance.RemoteRequestTimeout.timeout_timeout -- read on the meeting page, cached
			)
		);
		if ( is_wp_error( $reply ) ) {
			return;
		}
		$code = (int) wp_remote_retrieve_response_code( $reply );
		if ( 404 === $code ) {
			$response['status'] = 'cancelled';
		} elseif ( 200 === $code ) {
			$live = json_decode( wp_remote_retrieve_body( $reply ), true );
			if ( ! is_array( $live ) ) {
				return;
			}
			// start_url too: Zoom's host link expires about two hours after it's issued.
			foreach ( array( 'start_time', 'duration', 'timezone', 'join_url', 'start_url', 'password', 'encrypted_password' ) as $field ) {
				if ( isset( $live[ $field ] ) && '' !== $live[ $field ] ) {
					$response[ $field ] = $live[ $field ];
				}
			}
			if ( 'cancelled' === ( $response['status'] ?? '' ) ) {
				unset( $response['status'] );
			}
		} else {
			return;
		}
		update_post_meta( $post_id, 'academy_meeting_response', wp_json_encode( $response ) );
	}
}
