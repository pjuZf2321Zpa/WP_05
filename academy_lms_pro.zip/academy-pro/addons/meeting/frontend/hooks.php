<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


add_filter( 'academy/frontend_dashboard_menu_items', 'academy_pro_meeting_added_frontend_dashboard_menu', 10, 1 );

// Quizzes Endpoint
add_action( 'academy_frontend_dashboard_meeting_endpoint', 'academy_pro_meeting_frontend_dashboard_meetings_page' );

/*
 * Load php rendering template hook
 */
add_action( 'academy/templates/curriculum/meeting_content', 'academy_pro_meeting_course_curriculum_meeting_content', 10, 2 );
