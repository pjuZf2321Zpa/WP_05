<?php
namespace AcademyProCourseBundle;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
use AcademyProCourseBundle\Integration\Woocommerce;

class Integration {
	public static function init() {
		$self = new self();
		$self->add_woocommerce();
	}
	public function add_woocommerce() {
		if ( \Academy\Helper::is_active_woocommerce() ) {
			Woocommerce::init();
		}
	}
}
