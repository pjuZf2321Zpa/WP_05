<?php

namespace AcademyProCourseBundle\Ajax;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Academy\Classes\AbstractAjaxHandler;
use Academy\Classes\Sanitizer;

class Woocommerce extends AbstractAjaxHandler {
	protected $namespace = 'academy_pro_woo';
	public function __construct() {
		$this->actions = array(
			'create_or_update_course_bundle' => array(
				'callback' => array( $this, 'create_or_update_course_bundle' ),
				'capability' => 'manage_academy_instructor',
			),
			'get_bundle_product' => array(
				'callback' => array( $this, 'get_bundle_product' ),
				'capability' => 'manage_academy_instructor',
			)
		);
	}

	public function create_or_update_course_bundle( $payload_data ) {
		$payload = Sanitizer::sanitize_payload([
			'id'                => 'integer',
			'title'             => 'string',
			'slug'              => 'string',
			'payment_id'        => 'integer',
			'regular_price'     => 'string',
			'sale_price'        => 'string',
		], $payload_data );

		$bundle_id = (int) isset( $payload['id'] ) ? $payload['id'] : 0;
		// Only a real course bundle the user manages: an administrator or its instructor.
		if (
			! $bundle_id ||
			'alms_course_bundle' !== get_post_type( $bundle_id ) ||
			( ! current_user_can( 'manage_options' ) && ! \Academy\Helper::is_instructor_of_this_course( get_current_user_id(), $bundle_id ) )
		) {
			wp_send_json_error( esc_html__( 'You are not allowed to change this bundle.', 'academy-pro' ), 403 );
		}
		// The product comes from the bundle's own meta, never from the request.
		$product_id = 0;
		$bundle_title = isset( $payload['title'] ) ? $payload['title'] : '';
		$bundle_slug = isset( $payload['slug'] ) ? $payload['slug'] : '';
		$regular_price = isset( $payload['regular_price'] ) ? $payload['regular_price'] : '';
		$sale_price = isset( $payload['sale_price'] ) ? $payload['sale_price'] : '';
		$exist_product = get_post_meta( $bundle_id, 'academy_course_product_id', true );
		// Reuse the linked product only if it is a course product.
		if ( $exist_product > 0 && 'product' === get_post_type( $exist_product ) && 'yes' === get_post_meta( $exist_product, '_academy_product', true ) ) {
			$product_id = (int) $exist_product;
			// ...and never one that belongs to a different course.
			$other_course = get_posts( [
				'post_type'      => [ 'academy_courses', 'alms_course_bundle' ],
				'post_status'    => 'any',
				'fields'         => 'ids',
				'posts_per_page' => 1,
				'post__not_in'   => [ $bundle_id ],
				'meta_key'       => 'academy_course_product_id', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
				'meta_value'     => $product_id, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
			] );
			if ( $other_course ) {
				$product_id = 0;
			}
		}
		// that's CRUD object
		$product = new \WC_Product_Simple( $product_id );
		$product->set_name( $bundle_title );
		$product->set_slug( $bundle_slug );
		$product->set_regular_price( $regular_price );
		if ( $sale_price ) {
			$product->set_sale_price( $sale_price );
		}
		$product_id = $product->save();

		if ( $product_id ) {
			update_post_meta( $product_id, '_academy_product', 'yes' );
		}
		if ( $bundle_id ) {
			update_post_meta( $bundle_id, 'academy_course_product_id', $product_id );
		}
		$response = [
			'product_id' => $product_id,
		];

		if ( $product->get_regular_price() ) {
			$response['regular_price'] = (float) $product->get_regular_price();
		}
		if ( $product->get_sale_price() ) {
			$response['sale_price'] = (float) $product->get_sale_price();
		}

		wp_send_json_success( $response );
	}

	public function get_bundle_product( $payload_data ) {
		$payload = Sanitizer::sanitize_payload([
			'productId' => 'integer',
		], $payload_data );

		$productId = isset( $payload['productId'] ) ? $payload['productId'] : 0;
		// Only course products are readable here, not arbitrary store products.
		if ( ! $productId || 'product' !== get_post_type( $productId ) || 'yes' !== get_post_meta( $productId, '_academy_product', true ) ) {
			wp_send_json_error( [ 'message' => esc_html__( 'Product not found', 'academy-pro' ) ] );
		}
		$product = new \WC_Product_Simple( $productId );

		$response = [
			'product_id' => $productId,
		];
		if ( $product->get_regular_price() ) {
			$response['regular_price'] = (float) $product->get_regular_price();
		}
		if ( $product->get_sale_price() ) {
			$response['sale_price'] = (float) $product->get_sale_price();
		}
		wp_send_json_success( $response );
	}
}
