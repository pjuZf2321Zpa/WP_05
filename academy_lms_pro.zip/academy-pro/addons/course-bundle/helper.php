<?php
namespace AcademyProCourseBundle;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Helper {
	public static function get_bundle_enrolled( $bundle_id ) {
		$product_id = get_post_meta( $bundle_id, 'academy_course_bundle_product_id', true );
		$type = get_post_meta( $bundle_id, 'academy_course_bundle_type', true );
		$enrolled = 0;
		if ( 'paid' === $type && ! empty( $product_id ) ) {
			return (int) self::count_enrolled_course_bundle( $product_id );
		}
		if ( 'free' === $type ) {
			$all_students = \Academy\Helper::get_all_students();
			if ( empty( $all_students ) ) {
				return $enrolled;
			}
			foreach ( $all_students as $student ) {
				if ( self::is_user_enrolled_in_bundle( $bundle_id, $student->ID ) ) {
					++$enrolled;
				}
			}
		}
		return $enrolled;
	}
	public static function get_max_students( $bundle_id ) {
		$course_ids   = self::get_bundle_courses_id( $bundle_id );
		$max_students = 0;
		if ( is_array( $course_ids ) ) {
			foreach ( $course_ids as $course_id ) {
				$max_students += (int) get_post_meta( $course_id, 'academy_course_max_students', true );
			}
		}
		return $max_students;
	}
	public static function get_bundle_duration( $bundle_id ) {
		$course_ids = self::get_bundle_courses_id( $bundle_id );

		if ( empty( $course_ids ) || ! is_array( $course_ids ) ) {
			return '00:00:00';
		}

		$total_seconds = 0;

		foreach ( $course_ids as $course_id ) {
			$duration = \Academy\Helper::get_course_duration( $course_id );

			if ( empty( $duration ) ) {
				continue;
			}

			if ( preg_match(
				'/(\d+)\s*hr.*?(\d+)\s*mins?.*?(\d+)\s*sec/i',
				$duration,
				$matches
			) ) {
				$total_seconds +=
					( (int) $matches[1] * 3600 ) +
					( (int) $matches[2] * 60 ) +
					( (int) $matches[3] );
			}
		}

		$hours   = floor( $total_seconds / 3600 );
		$minutes = floor( ( $total_seconds % 3600 ) / 60 );
		$seconds = $total_seconds % 60;

		return sprintf( '%02d:%02d:%02d', $hours, $minutes, $seconds );
	}
	public static function get_bundle_lessons( $bundle_id ) {
		$course_ids = self::get_bundle_courses_id( $bundle_id );
		$lessons = 0;
		if ( is_array( $course_ids ) ) {
			foreach ( $course_ids as $course_id ) {
				$lessons += (int) \Academy\Helper::get_total_number_of_course_lesson( $course_id );
			}
		}
		return $lessons;
	}
	public static function get_bundle_courses_id( $bundle_id ) {
		$raw_courses = (array) get_post_meta( $bundle_id, 'academy_course_bundle_courses_ids', true );
		$course_ids  = [];
		foreach ( $raw_courses as $course ) {
			if ( is_array( $course ) && isset( $course['value'] ) ) {
				$course_ids[] = absint( $course['value'] );
			}
		}

		return apply_filters( 'academy_pro/course_bundle/get_course_bundle_courses_id', $course_ids, $bundle_id );
	}
	public static function product_belongs_with_bundle( $product_id ) {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$query = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM 	{$wpdb->postmeta} WHERE	meta_key = %s  AND meta_value = %d  limit 1",
				'academy_course_bundle_product_id',
				$product_id
			)
		);

		return $query;
	}
	public static function product_belongs_with_course_bundle( $product_id ) {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$query = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM 	{$wpdb->postmeta} WHERE	meta_key = %s  AND meta_value = %d  limit 1",
				'academy_course_bundle_product_id',
				$product_id
			)
		);

		return $query;
	}
	public static function get_bundle_product_id( $bundle_id ) {
		$product_id = absint( get_post_meta( $bundle_id, 'academy_course_bundle_product_id', true ) );
		return apply_filters( 'academy_pro/course_bundle/get_course_bundle_product_id', $product_id, $bundle_id );
	}

	/**
	 * The StoreEngine price object for a bundle. StoreEngine courses and
	 * bundles aren't tied to a WooCommerce-style product post — their price
	 * lives in StoreEngine's own integration/price tables, looked up by
	 * provider + bundle ID (the same repository the admin pricing UI reads
	 * and writes via the `academy-pro_storeengine/*_course_bundle_product`
	 * ajax actions).
	 *
	 * @param int $bundle_id Bundle ID.
	 * @return \StoreEngine\Classes\Price|null
	 */
	public static function get_bundle_storeengine_price( $bundle_id ) {
		if ( ! class_exists( \StoreEngine::class ) ) {
			return null;
		}

		$integrations = \StoreEngine\Utils\Helper::get_integration_repository_by_id( 'storeengine/course-bundle', $bundle_id );
		$integration  = current( $integrations );

		return $integration ? $integration->price : null;
	}

	/**
	 * The StoreEngine price for a bundle, formatted for display (regular/sale
	 * HTML, same shape as WC_Product::get_price_html()).
	 *
	 * @param int $bundle_id Bundle ID.
	 * @return string Price HTML, or '' if StoreEngine has no price for it.
	 */
	public static function get_bundle_storeengine_price_html( $bundle_id ) {
		$price = self::get_bundle_storeengine_price( $bundle_id );

		return $price ? $price->get_price_html() : '';
	}

	public static function is_bundle_fully_booked( $bundle_id ) {
		$total_enrolled = self::get_bundle_enrolled( $bundle_id );
		$max_students   = self::get_max_students( $bundle_id );

		return ( $total_enrolled > 0 ) && ( $max_students > 0 ) && ( $total_enrolled >= $max_students );
	}
	public static function get_order_by_customer_id_and_product_id( $customer_id, $product_id, $bundle_id = 0 ) {
		global $wpdb;
		$order = [];
		// The WooCommerce order lookup below only applies when WooCommerce is the
		// active monetization engine. It must not gate the filter after it —
		// addons (e.g. the free-bundle direct-enrollment check) hook into that
		// filter to report enrollment independently of any WooCommerce order.
		if ( class_exists( 'WooCommerce', false ) ) {
			if ( 'yes' === get_option( 'woocommerce_custom_orders_table_enabled' ) ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
				$order = $wpdb->get_row(
					$wpdb->prepare(
						"SELECT
							orders.id,
							SUBSTRING_INDEX(orders.status, 'wc-', -1) AS status,
							orders.billing_email,
							orders.date_created_gmt,
							orders.date_updated_gmt
						FROM
							{$wpdb->prefix}wc_orders AS orders
						INNER JOIN
							{$wpdb->prefix}wc_order_product_lookup AS lookup
						ON
							orders.id = lookup.order_id
						WHERE
							orders.customer_id = %d
						AND
							lookup.product_id = %d",
						$customer_id,
						$product_id
					)
				);
			} else {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
				$order = $wpdb->get_row(
					$wpdb->prepare(
						"SELECT
							orders.ID,
							orders.post_author,
							SUBSTRING_INDEX(orders.post_status, 'wc-', -1) AS status,
							orders.post_date_gmt AS date
						FROM
							{$wpdb->prefix}posts orders
						INNER JOIN
							{$wpdb->prefix}woocommerce_order_items as items
						ON
							orders.id = items.order_id
						AND
							items.order_item_type = 'line_item'
						INNER JOIN
							{$wpdb->prefix}woocommerce_order_itemmeta as meta
						ON
							items.order_item_id = meta.order_item_id
						AND
							meta.meta_key = '_product_id'
						AND
							meta.meta_value = %d
						WHERE
							orders.post_type = 'shop_order'
						AND
							orders.post_author = %d",
						$product_id,
						$customer_id
					)
				);
			}//end if
		}//end if

		return apply_filters( 'academy_pro/bundle/get_enrollment_data', $order, $customer_id, $bundle_id );
	}

	public static function count_enrolled_course_bundle( $product_id ) {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$enrolled_ids = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) 
				FROM (
				SELECT DISTINCT opl.order_id 
				FROM {$wpdb->prefix}wc_order_product_lookup AS opl
				INNER JOIN {$wpdb->prefix}wc_orders AS o 
				ON opl.order_id = o.id
				WHERE opl.product_id = %d
				AND o.status = %s
				) AS subquery;",
				$product_id, 'wc-completed'
			)
		);
		return (int) $enrolled_ids;
	}

	public static function is_user_enrolled_in_bundle( $bundle_id, $user_id ) {

		global $wpdb;

		$course_ids = self::get_bundle_courses_id( $bundle_id );

		if ( empty( $course_ids ) || ! is_array( $course_ids ) ) {
			return false;
		}

		// Sanitize IDs
		$course_ids = array_map( 'absint', $course_ids );

		$placeholders = implode( ',', array_fill( 0, count( $course_ids ), '%d' ) );

		$table = $wpdb->posts;

		$sql = "
			SELECT COUNT(DISTINCT post_parent)
			FROM {$table}
			WHERE post_type = %s
			AND post_author = %d
			AND post_status = %s
			AND post_parent IN ($placeholders)
		";

		// Only a 'completed' academy_enrolled record counts as genuinely enrolled —
		// matching the same convention Academy\Helper::is_enrolled() uses for a
		// single course. A paid bundle's enrollment rows are created as soon as the
		// WooCommerce order is placed (see Woocommerce::create_course_order_from_customer())
		// and their status is kept in sync with the order's real status afterward
		// (Woocommerce::enrolled_courses_status_change()) — so without this filter, a
		// pending/on-hold/cancelled/refunded order would count as fully enrolled here.
		$params = array_merge(
			[ 'academy_enrolled', absint( $user_id ), 'completed' ],
			$course_ids
		);

		$query = $wpdb->prepare( $sql, $params );// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared

		$enrolled_count = (int) $wpdb->get_var( $query );// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		// Must be enrolled in ALL courses of bundle
		return count( $course_ids ) === $enrolled_count;
	}

	public static function bundle_enrolled_info( $bundle_id, $user_id ) {

		global $wpdb;

		$course_ids = self::get_bundle_courses_id( $bundle_id );

		if ( empty( $course_ids ) || ! is_array( $course_ids ) ) {
			return false;
		}

		// Sanitize IDs
		$course_ids = array_map( 'absint', $course_ids );

		$placeholders = implode( ',', array_fill( 0, count( $course_ids ), '%d' ) );

		$table = $wpdb->posts;

		$sql = "
			SELECT post_date
			FROM {$table}
			WHERE post_type = %s
			AND post_author = %d
			AND post_parent IN ($placeholders)
		";

		$params = array_merge(
			[ 'academy_enrolled', absint( $user_id ) ],
			$course_ids
		);
		$results = $wpdb->get_results( $wpdb->prepare( $sql, $params ) );// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		return current( $results );
	}
}
