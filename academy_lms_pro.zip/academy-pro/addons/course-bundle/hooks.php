<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Single bundle
 */
add_action( 'academy_pro/templates/course_bundle/single_bundle_content', 'academy_pro_course_bundle_single_header', 10 );
add_action( 'academy_pro/templates/course_bundle/single_bundle_content', 'academy_pro_course_bundle_single_description', 15 );
add_action( 'academy_pro/templates/course_bundle/single_bundle_content', 'academy_pro_course_bundle_single_bundle_course_list', 20 );

/**
 * Single bundle sidebar.
 */
add_action( 'academy_pro/templates/course_bundle/single_bundle_sidebar', 'academy_pro_course_bundle_single_sidebar', 10 );
add_action( 'academy_pro/templates/course_bundle/single_bundle_sidebar_widgets', 'academy_pro_course_bundle_single_enroll', 10 );

/**
 * Single bundle enroll.
 */
add_action( 'academy_pro/templates/course_bundle/single_bundle_enroll_content', 'academy_pro_course_bundle_single_price', 10 );
add_action( 'academy_pro/templates/course_bundle/single_bundle_enroll_content', 'academy_pro_course_bundle_single_enroll_form', 10 );
add_action( 'academy_pro/templates/course_bundle/single_bundle_enroll_content', 'academy_pro_course_bundle_single_enroll_content', 15 );
add_action( 'academy_pro/templates/course_bundle/single_bundle_enroll_content', 'academy_pro_course_bundle_single_enroll_wishlist_and_share', 20 );
add_action( 'academy_pro/templates/course_bundle/after_bundle_price', 'academy_pro_course_bundle_discount_information', 10, 2 );

/**
 * Single bundle loop.
 */
add_action( 'academy/templates/before_course_loop_content_inner', 'academy_pro_course_bundle_single_course_count' );
add_action( 'academy/templates/course_loop', 'academy_pro_remove_bundle_ratings_and_price' );
add_action( 'academy/templates/course_loop_footer_inner', 'academy_pro_add_bundle_loop_enrollment_count', 10 );
add_action( 'academy/templates/course_loop_footer_inner', 'academy_pro_add_bundle_loop_price', 11 );

// Free bundle enroll
add_filter( 'academy/before_enroll_course_type', 'academy_enroll_free_bundle_courses', 11, 2 );
add_filter( 'academy_pro/bundle/get_enrollment_data', 'academy_course_bundle_get_enrollment_data', 11, 3 );
