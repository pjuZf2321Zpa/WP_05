<?php
namespace AcademyProCourseBundle;

use stdClass;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}


class Ajax {
	public static function init() {
		$self = new self();
		add_action( 'wp_ajax_academy_pro_course_bundle/admin/get_courses', array( $self, 'get_course' ) );
		add_action( 'wp_ajax_academy_pro_course_bundle/get_courses', array( $self, 'get_courses' ) );

		( new Ajax\Woocommerce() )->dispatch_actions();
	}

	public function get_course() {
		check_ajax_referer( 'academy_nonce', 'security' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die();
		}

		$course_id = ! empty( $_POST['course_id'] ) ? absint( $_POST['course_id'] ) : 0;

		if ( ! $course_id ) {
			wp_send_json_error();
		}

		$engine = \Academy\Helper::get_settings( 'monetization_engine' );
		$course     = get_post( $course_id );
		$woo_product_id = absint( get_post_meta( $course_id, 'academy_course_product_id', true ) );
		$store_product_id = absint( get_post_meta( $course_id, 'academy_store_product', true ) );

		if ( $woo_product_id && 'woocommerce' === $engine ) {
			$product       = wc_get_product( $woo_product_id );
			$sale_price    = $product->get_sale_price();
			$regular_price = $product->get_regular_price();
			if ( $sale_price ) {
				$course->sale_price = $sale_price;
			}

			if ( $regular_price ) {
				$course->regular_price = $regular_price;
			}
		}

		$thumbnail_id      = get_post_thumbnail_id( $course_id );
		$course->image_src = $thumbnail_id ?
			wp_get_attachment_image_src( $thumbnail_id, 'medium' )[0] :
			ACADEMY_ASSETS_URI . '/images/thumbnail-placeholder.png';

		$course->author = \Academy\Helper::get_addon_active_status( 'multi_instructor' ) ? \Academy\Helper::get_instructors_by_course_id( absint( $course->id ) ) :
				\Academy\Helper::get_instructor_by_author_id( absint( $course->id ) );

		$course->meta = new stdClass();
		if ( $store_product_id && 'storeengine' === $engine ) {
			$integrations = \StoreEngine\Utils\Helper::get_integration_repository_by_id( 'storeengine/academylms', $course_id );
			$prices = [];
			foreach ( $integrations as $integration ) {
				$prices[] = [
					'price_type' => $integration->price->get_type(),
					'regular_price' => $integration->price->get_compare_price(),
					'sale_price' => $integration->price->get_price(),
				];
			}
			$course->store_prices = $prices;
		}
		$course->meta->academy_course_expire_enrollment        = get_post_meta( $course_id, 'academy_course_expire_enrollment', true );
		$course->meta->academy_course_type                     = get_post_meta( $course_id, 'academy_course_type', true );
		$course->meta->academy_course_product_id               = get_post_meta( $course_id, 'academy_course_product_id', true );
		$course->meta->academy_store_product                   = get_post_meta( $course_id, 'academy_store_product', true );
		$course->meta->academy_course_max_students             = get_post_meta( $course_id, 'academy_course_max_students', true );
		$course->meta->academy_course_language                 = get_post_meta( $course_id, 'academy_course_language', true );
		$course->meta->academy_course_difficulty_level         = get_post_meta( $course_id, 'academy_course_difficulty_level', true );
		$course->meta->academy_course_benefits                 = get_post_meta( $course_id, 'academy_course_benefits', true );
		$course->meta->academy_course_requirements             = get_post_meta( $course_id, 'academy_course_requirements', true );
		$course->meta->academy_course_audience                 = get_post_meta( $course_id, 'academy_course_audience', true );
		$course->meta->academy_course_materials_included       = get_post_meta( $course_id, 'academy_course_materials_included', true );
		$course->meta->academy_is_enabled_course_qa            = get_post_meta( $course_id, 'academy_is_enabled_course_qa', true );
		$course->meta->academy_is_enabled_course_announcements = get_post_meta( $course_id, 'academy_is_enabled_course_announcements', true );
		$course->meta->academy_course_duration                 = get_post_meta( $course_id, 'academy_course_duration', true );
		$course->meta->academy_course_intro_video              = get_post_meta( $course_id, 'academy_course_intro_video', true );
		$course->meta->academy_course_curriculum               = get_post_meta( $course_id, 'academy_course_curriculum', true );

		wp_send_json_success( $course );
	}

	public function get_courses() {
		check_ajax_referer( 'academy_nonce', 'security' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die();
		}

		global $wpdb;

		$type   = isset( $_POST['type'] ) ? sanitize_text_field( wp_unslash( $_POST['type'] ) ) : 'all';
		$engine = \Academy\Helper::get_settings( 'monetization_engine' );

		$where  = [];
		$params = [];

		$join = "INNER JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID";

		// Course type filter
		if ( 'free' === $type || 'paid' === $type ) {
			$join     .= ' AND pm.meta_key = %s AND pm.meta_value = %s';
			$params[] = 'academy_course_type';
			$params[] = $type;
		} else {
			// type = all → exclude public
			$join     .= ' AND pm.meta_key = %s AND pm.meta_value != %s';
			$params[] = 'academy_course_type';
			$params[] = 'public';
		}

		$where[]  = 'p.post_status = %s';
		$where[]  = 'p.post_type = %s';
		$params[] = 'publish';
		$params[] = 'academy_courses';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$sql = $wpdb->prepare(
			"
			SELECT DISTINCT
				p.ID   AS value,
				p.post_title AS label
			FROM {$wpdb->posts} p {$join} WHERE " . implode( ' AND ', $where ), // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
			$params
		);

		$courses = $wpdb->get_results( $sql );// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter

		if ( empty( $courses ) ) {
			wp_send_json_success( [] );
		}

		$is_free = ( 'free' === $type );
		$is_paid = ( 'paid' === $type || 'all' === $type );

		$is_woo = $is_paid
			&& 'woocommerce' === $engine
			&& class_exists( 'WooCommerce', false );

		$is_storeengine = $is_paid
			&& 'storeengine' === $engine
			&& class_exists( \StoreEngine::class, false );

		$response = [];

		foreach ( $courses as $course ) {

			if ( ! isset( $course->value, $course->label ) ) {
				continue;
			}

			$course_id = (int) $course->value;
			if ( $course_id <= 0 ) {
				continue;
			}

			// Free courses (type = free OR all)
			if ( $is_free || 'all' === $type ) {
				$response[] = [
					'label' => $course->label,
					'value' => $course_id,
				];
				continue;
			}

			// Paid courses (engine based)
			if ( $is_storeengine ) {
				$response[] = [
					'label' => $course->label,
					'value' => $course_id,
				];
				continue;
			}

			if ( $is_woo && $this->is_woocommerce_product( $course_id ) ) {
				$response[] = [
					'label' => $course->label,
					'value' => $course_id,
				];
			}
		}//end foreach

		wp_send_json_success( $response );
	}

	public function is_woocommerce_product( $course_id ) {
		$product_id = get_post_meta( $course_id, 'academy_course_product_id', true );
		$post_type = get_post_type( $product_id );

		return ( 'product' === $post_type );
	}
}
