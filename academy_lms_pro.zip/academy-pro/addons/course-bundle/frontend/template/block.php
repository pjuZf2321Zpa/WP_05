<?php
namespace AcademyProCourseBundle\Frontend\Template;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers a file-based block (FSE) template for the Course Bundle single page,
 * mirroring Academy\Frontend\Template\Block so block themes get a real wp_template
 * for alms_course_bundle instead of falling back to the theme's generic single
 * template - keeping it editable/overridable from the Site Editor like single-course.
 */
class Block {
	const TEMPLATE_SLUG = 'single-alms_course_bundle';

	public static function init() {
		$self = new self();
		add_filter( 'pre_get_block_file_template', [ $self, 'get_block_file_template' ], 10, 3 );
		add_filter( 'get_block_templates', [ $self, 'add_block_templates' ], 10, 3 );
	}

	public function get_block_file_template( $template, $id, $template_type ) {
		$template_name_parts = explode( '//', $id );

		if ( count( $template_name_parts ) < 2 ) {
			return $template;
		}

		list( $template_id, $template_slug ) = $template_name_parts;

		// Must match the ACTIVE theme's stylesheet, not a plugin-name pseudo
		// theme - WP's own hierarchy walk (and, critically, what gets written
		// to the wp_theme term when the Site Editor saves an edit of this
		// template) keys off get_stylesheet(). Tagging it "academy-pro"
		// instead orphans the saved customization: WP's native resolution
		// only looks for wp_template posts tagged with the active theme, so
		// it can never find it again and silently falls back to the theme's
		// generic single.html - losing every shortcode in this file. Found
		// via a live report where a saved custom header wiped the bundle
		// content.
		if ( get_stylesheet() !== $template_id || self::TEMPLATE_SLUG !== $template_slug ) {
			return $template;
		}

		$template_file_path = ACADEMY_PRO_BLOCK_TEMPLATES_DIR_PATH . $template_slug . '.html';

		if ( ! is_readable( $template_file_path ) ) {
			return $template;
		}

		return $this->build_template_result_from_file( $template_file_path, $template_type );
	}

	public function get_block_templates_from_db( $template_type = 'wp_template' ) {
		// phpcs:disable WordPressVIPMinimum.Performance.NoPaging.posts_per_page_posts_per_page -- needs the complete (small, bounded) set
		$check_query = new \WP_Query(
			[
				'post_type'      => $template_type,
				'posts_per_page' => -1,
				'no_found_rows'  => true,
				'post_name__in'  => [ self::TEMPLATE_SLUG ],
				'tax_query'      => [ // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
					[
						'taxonomy' => 'wp_theme',
						// Also matches the legacy "academy-pro" tag from
						// before this was fixed to key off get_stylesheet(),
						// so an already-broken save is still found here (and
						// skipped in add_block_templates()) instead of
						// silently duplicating a second copy of this template.
						'field'    => 'name',
						'terms'    => [ ACADEMY_PRO_PLUGIN_SLUG, get_stylesheet() ],
					],
				],
			]
		);
		// phpcs:enable WordPressVIPMinimum.Performance.NoPaging.posts_per_page_posts_per_page

		return $check_query->posts;
	}

	public function build_template_result_from_file( $template_file_path, $template_type ) {
		$template_content = file_get_contents( $template_file_path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents, WordPressVIPMinimum.Performance.FetchingRemoteData.FileGetContentsUnknown -- local file, not a remote URL

		$template                = new \WP_Block_Template();
		$template->id             = get_stylesheet() . '//' . self::TEMPLATE_SLUG;
		$template->theme          = get_stylesheet();
		$template->content        = $this->inject_theme_attribute_in_content( $template_content );
		$template->source         = 'plugin';
		$template->slug           = self::TEMPLATE_SLUG;
		$template->type           = $template_type;
		$template->title          = __( 'Single Course Bundle', 'academy-pro' );
		$template->description    = __( 'Template used to display the single course bundle.', 'academy-pro' );
		$template->status         = 'publish';
		$template->has_theme_file = true;
		$template->origin         = 'plugin';
		$template->is_custom      = false;
		$template->post_types     = [];
		$template->area           = 'uncategorized';

		if ( function_exists( 'inject_ignored_hooked_blocks_metadata_attributes' ) ) {
			$hooked_blocks = get_hooked_blocks();
			if ( ! empty( $hooked_blocks ) || has_filter( 'hooked_block_types' ) ) {
				$before_block_visitor = make_before_block_visitor( $hooked_blocks, $template );
				$after_block_visitor  = make_after_block_visitor( $hooked_blocks, $template );
				$blocks               = parse_blocks( $template->content );
				$template->content    = traverse_and_serialize_blocks( $blocks, $before_block_visitor, $after_block_visitor );
			}
		}

		return $template;
	}

	/**
	 * Template parts (e.g. {"slug":"header"}) need an explicit "theme" attribute
	 * or Gutenberg resolves them against this plugin's virtual theme id instead
	 * of the site's active theme, so the real header/footer parts never match.
	 *
	 * @param mixed $template_content
	 */
	public function inject_theme_attribute_in_content( $template_content ) {
		$blocks       = parse_blocks( $template_content );
		$flat_blocks  = $this->flatten_blocks( $blocks );
		$has_updated  = false;

		foreach ( $flat_blocks as &$block ) {
			if ( 'core/template-part' === $block['blockName'] && ! isset( $block['attrs']['theme'] ) ) {
				$block['attrs']['theme'] = wp_get_theme()->get_stylesheet();
				$has_updated             = true;
			}
		}
		unset( $block );

		if ( ! $has_updated ) {
			return $template_content;
		}

		$new_content = '';
		foreach ( $blocks as $block ) {
			$new_content .= serialize_block( $block );
		}

		return $new_content;
	}

	public function flatten_blocks( &$blocks ) {
		$all_blocks = [];
		$queue      = [];
		foreach ( $blocks as &$block ) {
			$queue[] = &$block;
		}

		while ( ! empty( $queue ) ) {
			$block = &$queue[0];
			array_shift( $queue );
			$all_blocks[] = &$block;

			if ( ! empty( $block['innerBlocks'] ) ) {
				foreach ( $block['innerBlocks'] as &$inner_block ) {
					$queue[] = &$inner_block;
				}
			}
		}

		return $all_blocks;
	}

	public function add_block_templates( $query_result, $query, $template_type ) {
		if ( 'wp_template' !== $template_type ) {
			return $query_result;
		}

		$slugs = isset( $query['slug__in'] ) ? $query['slug__in'] : [];

		if ( is_array( $slugs ) && count( $slugs ) > 0 && ! in_array( self::TEMPLATE_SLUG, $slugs, true ) ) {
			return $query_result;
		}

		// A custom (DB-saved) copy of this template already fits the query - don't add the file default on top of it.
		if ( $this->get_block_templates_from_db( $template_type ) ) {
			return $query_result;
		}

		foreach ( $query_result as $existing ) {
			$existing = (object) $existing;
			if ( isset( $existing->slug ) && self::TEMPLATE_SLUG === $existing->slug ) {
				return $query_result;
			}
		}

		$template_file_path = ACADEMY_PRO_BLOCK_TEMPLATES_DIR_PATH . self::TEMPLATE_SLUG . '.html';

		if ( ! is_readable( $template_file_path ) ) {
			return $query_result;
		}

		$fits_area_query = ! isset( $query['area'] ) || 'uncategorized' === $query['area'];

		if ( $fits_area_query ) {
			$query_result[] = $this->build_template_result_from_file( $template_file_path, $template_type );
		}

		return $query_result;
	}
}
