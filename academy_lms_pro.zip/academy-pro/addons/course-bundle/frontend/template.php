<?php
namespace AcademyProCourseBundle\Frontend;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Template {
	public static function init() {
		$self = new self();
		$self->dispatch_hook();
		Template\Loader::init();
	}

	public function dispatch_hook() {
		add_filter( 'academy/get_course_archive_post_types', array( $this, 'add_course_bundle_course_type' ) );
		add_filter( 'academy/course_archive_post_types', array( $this, 'add_bundle_course_type' ) );
		add_filter( 'academy/get_course_filter_types', array( $this, 'add_course_bundle_filter' ) );
		add_action( 'academy/get_course_archive_search_query_args', array( $this, 'add_course_bundle_search_args' ), 10, 2 );

		// Every template-routing check in both the classic and block-theme
		// paths calls is_post_type_archive('academy_courses') by that exact
		// string — changing query_vars['post_type'] away from it (e.g. to
		// 'alms_course_bundle' alone, or breaking it out of a 1-item array on
		// an FSE theme — see widen_fse_archive_post_type_where()) makes that
		// check fail and the whole styled archive template silently falls
		// back to the theme's generic one. So post_type is never touched
		// here; both widening the archive to include bundles (FSE themes)
		// and narrowing it to bundles only (the "Bundle" filter checkbox,
		// which CourseFilters::query_args() can't express — see
		// clear_bundle_filter_meta_query() below) happen at the SQL level via
		// posts_where instead.
		add_filter( 'posts_where', array( $this, 'adjust_course_archive_post_type_where' ), 10, 2 );

		// The "Bundle" checkbox added above to the Course Filters block's
		// "type" group (academy/get_course_filter_types) flows into
		// Academy\Blocks\CourseFilters::query_args(), which only knows how to
		// turn course "type" values into an `academy_course_type` meta_query —
		// bundles have no such meta key, so selecting it built an impossible
		// meta_query and silently zeroed the results. Clear it; the actual
		// post_type narrowing happens in adjust_course_archive_post_type_where().
		add_action( 'pre_get_posts', array( $this, 'clear_bundle_filter_meta_query' ), 41 );
	}

	public function add_course_bundle_course_type( $post_types ) {
		$post_types[] = 'alms_course_bundle';
		return $post_types;
	}

	public function add_bundle_course_type( $post_types ) {
		if ( ! \Academy\Helper::is_fse_theme() ) {
			$post_types[] = 'alms_course_bundle';
		}
		return $post_types;
	}

	public function adjust_course_archive_post_type_where( $where, $query ) {
		global $wpdb;

		if ( is_admin() || ! $query->is_main_query() || ! $query->is_post_type_archive( 'academy_courses' ) || $query->is_tax( 'academy_courses_category' ) ) {
			return $where;
		}

		$values = \Academy\Blocks\CourseFilters::current();
		if ( in_array( 'bundle', $values['type'], true ) ) {
			// The "Bundle" filter is selected: narrow to bundles only,
			// replacing whatever post_type clause is already there (a plain
			// '= academy_courses', or the IN(...) below on FSE themes).
			return (string) preg_replace(
				'/' . preg_quote( $wpdb->posts, '/' ) . "\\.post_type (?:= '[^']*'|IN \\([^)]*\\))/",
				$wpdb->prepare( "{$wpdb->posts}.post_type = %s", 'alms_course_bundle' ), // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$where,
				1
			);
		}

		if ( \Academy\Helper::is_fse_theme() ) {
			return str_replace(
				$wpdb->prepare( "{$wpdb->posts}.post_type = %s", 'academy_courses' ), // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$wpdb->prepare( "{$wpdb->posts}.post_type IN (%s, %s)", 'academy_courses', 'alms_course_bundle' ), // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$where
			);
		}

		return $where;
	}

	public function clear_bundle_filter_meta_query( $q ) {
		if ( is_admin() || ! $q->is_main_query() ) {
			return;
		}
		if ( ! $q->is_post_type_archive( 'academy_courses' ) && ! $q->is_tax( [ 'academy_courses_category', 'academy_courses_tag' ] ) ) {
			return;
		}

		$values = \Academy\Blocks\CourseFilters::current();
		if ( in_array( 'bundle', $values['type'], true ) ) {
			$q->set( 'meta_query', [] ); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- clearing, not querying
		}
	}

	public function add_course_bundle_filter( $types ) {
		$types['bundle'] = __( 'Bundle', 'academy-pro' );
		return $types;
	}

	public function add_course_bundle_search_args( $args, $data ) {
		if ( in_array( 'bundle', $data['type'], true ) ) {
			$args['post_type']  = 'alms_course_bundle';
			unset( $args['meta_query'] );
		}

		return $args;
	}
}
