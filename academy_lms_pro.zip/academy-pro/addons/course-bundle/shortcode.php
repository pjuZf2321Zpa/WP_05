<?php
namespace AcademyProCourseBundle;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Exposes the single-bundle content pieces as shortcodes so block themes can
 * place them inside the single-alms_course_bundle.html block template, the
 * same way core Academy exposes [academy_single_course_description] etc. for
 * single-academy_courses.html.
 */
class Shortcode {

	public function __construct() {
		add_shortcode( 'academy_course_bundle_header', [ $this, 'header' ] );
		add_shortcode( 'academy_course_bundle_description', [ $this, 'description' ] );
		add_shortcode( 'academy_course_bundle_course_list', [ $this, 'course_list' ] );
		add_shortcode( 'academy_course_bundle_enroll_widget', [ $this, 'enroll_widget' ] );
	}

	public function header( $attributes, $content = '' ) {
		ob_start();
		academy_pro_course_bundle_single_header();
		return apply_filters( 'academy_pro/templates/shortcode/course_bundle_header', ob_get_clean() );
	}

	public function description( $attributes, $content = '' ) {
		ob_start();
		academy_pro_course_bundle_single_description();
		return apply_filters( 'academy_pro/templates/shortcode/course_bundle_description', ob_get_clean() );
	}

	public function course_list( $attributes, $content = '' ) {
		ob_start();
		academy_pro_course_bundle_single_bundle_course_list();
		return apply_filters( 'academy_pro/templates/shortcode/course_bundle_course_list', ob_get_clean() );
	}

	public function enroll_widget( $attributes, $content = '' ) {
		ob_start();
		academy_pro_course_bundle_single_sidebar();
		return apply_filters( 'academy_pro/templates/shortcode/course_bundle_enroll_widget', ob_get_clean() );
	}
}
