<?php
namespace AcademyProSocialLogin;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use Academy\Interfaces\AddonInterface;
final class SocialLogin implements AddonInterface {
	private $addon_name = 'social-login';
	private function __construct() {
		$this->define_constants();
		$this->init_addon();
	}
	public static function init() {
		static $instance = false;

		if ( ! $instance ) {
			$instance = new self();
		}

		return $instance;
	}
	public function define_constants() {
		/**
		 * Defines CONSTANTS for Whole Addon.
		 */
		define( 'ACADEMY_PRO_SOCIAL_LOGIN_VERSION', '1.0.0' );
		define( 'ACADEMY_PRO_SOCIAL_LOGIN_DIR_PATH', ACADEMY_PRO_ADDONS_DIR_PATH . 'social-login/' );
	}
	public function init_addon() {
		// fire addon activation hook
		add_action( "academy/addons/activated_{$this->addon_name}", array( $this, 'addon_activation_hook' ) );
		// Once GemSecurity's own Social Login module is active, this
		// addon's internals keep initializing even if an admin has toggled
		// this addon off — not to render Academy Pro's own native buttons
		// (Shortcode/Ajax already suppress those on their own whenever
		// GemSecurity is active — see AcademyPro\Helper::
		// is_gemsecurity_social_login_active()), but because Hooks::init()
		// is also where the Student/Instructor Registration pages'
		// GemSecurity relay lives (rendering GemSecurity's role-scoped
		// button there, since GemSecurity's own module has no other way to
		// reach those pages) and where the post-registration completion
		// listener is registered. Toggling this addon off must not
		// silently remove those — it would otherwise leave the
		// registration pages with no social login button at all.
		if ( ! \Academy\Helper::get_addon_active_status( $this->addon_name ) && ! \AcademyPro\Helper::is_gemsecurity_social_login_active() ) {
			return;
		}
		// Run Addon functionality
		Assets::init();
		Hooks::init();
		( new Ajax() )->dispatch_actions();
		Admin\settings::init();
		new Shortcode();
	}

	public function load_dependency() {
	}

	public function addon_activation_hook() {
	}
}
