<?php
namespace AcademyProSocialLogin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


class Hooks {

	public static function init() {
		$self = new self();
		add_action( 'academy/templates/student_reg_form_end', array( $self, 'add_student_social_register' ) );
		add_action( 'academy/templates/instructor_reg_form_end', array( $self, 'add_instructor_social_register' ) );
		add_action( 'gemsecurity/social_login/role_registered', array( $self, 'complete_gemsecurity_role_registration' ), 10, 2 );
		// phpcs:ignore Squiz.PHP.CommentedOutCode.Found
		// add_action( 'login_form', array($self, 'add_social_login') );
	}

	public function add_student_social_register() {
		if ( \AcademyPro\Helper::is_gemsecurity_social_login_active() ) {
			// GemSecurity's own buttons have no separate registration-page
			// rendering path — Shortcode::social_login() suppresses Academy
			// Pro's native buttons everywhere once GemSecurity is active, so
			// call GemSecurity's role-aware renderer directly here instead,
			// passing the same role Academy Pro's own buttons registered
			// students under below.
			( new \GemSecurity\Modules\SocialLogin() )->render_frontend( 'academy_student' );
			return;
		}
		echo do_shortcode( '[academy_social_login is_register=true]' );
	}
	public function add_instructor_social_register() {
		if ( \AcademyPro\Helper::is_gemsecurity_social_login_active() ) {
			// See add_student_social_register()'s matching guard. 'subscriber'
			// matches the role Academy Pro's own native buttons registered
			// instructor sign-ups under (the `role=subscriber` shortcode
			// attribute below) — complete_gemsecurity_role_registration()
			// picks up from here once GemSecurity actually creates the
			// account, to finish what Academy Pro's native AJAX handler
			// used to do for this same role.
			( new \GemSecurity\Modules\SocialLogin() )->render_frontend( 'subscriber' );
			return;
		}
		echo do_shortcode( '[academy_social_login is_register=true role=subscriber]' );
	}

	/**
	 * Completes Academy's own post-registration bookkeeping for a user
	 * GemSecurity's Social Login module just created under a role this
	 * addon explicitly requested (see add_student_social_register() /
	 * add_instructor_social_register() passing 'academy_student' /
	 * 'subscriber' into render_frontend()). GemSecurity only creates the
	 * WordPress user with that role; everything Academy itself needs on
	 * top of that — the pending-instructor status meta, the bonus
	 * academy_student role instructor applicants also get, the admin/user
	 * notification email, and Academy's own registration hooks — normally
	 * comes from Ajax::set_user_auth_cookie() in this same addon, which
	 * never runs for a GemSecurity-driven sign-up. This replicates that
	 * same behavior from here instead, hooked onto GemSecurity's own
	 * `gemsecurity/social_login/role_registered` action (fired only for a
	 * caller-supplied role, never for the generic login-page button).
	 *
	 * @param int    $user_id
	 * @param string $role 'academy_student' or 'subscriber' — any other
	 *                     value wasn't requested by this addon, so it's
	 *                     left alone.
	 */
	public function complete_gemsecurity_role_registration( $user_id, $role ) {
		if ( ! in_array( $role, array( 'academy_student', 'subscriber' ), true ) ) {
			return;
		}

		$user_role = 'subscriber' === $role ? 'instructor' : 'student';
		do_action( "academy/admin/after_register_{$user_role}", $user_id );

		if ( 'academy_student' === $role ) {
			update_user_meta( $user_id, 'is_academy_student', \Academy\Helper::get_time() );
		}

		if ( 'subscriber' === $role ) {
			$user = get_user_by( 'id', $user_id );
			if ( $user ) {
				// Matches Ajax::google_login()/facebook_login(): instructor
				// applicants also get academy_student so they can use the
				// LMS as a student while their application is pending.
				$user->add_role( 'academy_student' );
			}
			update_user_meta( $user_id, 'is_academy_instructor', \Academy\Helper::get_time() );
			update_user_meta( $user_id, 'academy_instructor_status', apply_filters( 'academy/admin/registration_instructor_status', 'pending' ) );
		}

		wp_new_user_notification( $user_id, null, 'both' );
		do_action( "academy/api/auth/after_{$user_role}_registration", $user_id );
	}
}
