<?php
namespace AcademyProGradeBook;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Ajax {
	public static function init(): void {
		Admin\Ajax::init();
	}
}
