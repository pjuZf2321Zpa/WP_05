<?php
namespace AcademyProGradeBook;

use AcademyProGradeBook\Database\CreateGradeBookResultsTable;
use AcademyProGradeBook\Database\CreateGradeBooksTable;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Database {
	public static function init(): void {
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		global $wpdb;
		$prefix = $wpdb->prefix;
		$charset_collate = $wpdb->get_charset_collate();
		CreateGradeBooksTable::create( $prefix, $charset_collate );
		CreateGradeBookResultsTable::create( $prefix, $charset_collate );
	}
}
