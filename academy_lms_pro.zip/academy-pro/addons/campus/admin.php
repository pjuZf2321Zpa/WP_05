<?php
namespace AcademyProCampus;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The Campus admin menu is a single top-level entry owned by the free spine;
 * the pro module sections (exams, fees, reports, attendance, timetable) are
 * surfaced by the in-app section nav, gated client-side by Pro + addon status.
 *
 * Kept as a no-op hook point so future pro-only admin wiring has a home.
 */
class Admin {

	public static function init() {
		do_action( 'academy_pro_campus/admin_init' );
	}
}
