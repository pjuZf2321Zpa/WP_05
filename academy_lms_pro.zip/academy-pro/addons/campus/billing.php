<?php
namespace AcademyProCampus;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Fees, on StoreEngine.
 *
 * A school fee is a product a family buys: a monthly fee is a subscription, a
 * one-off fee is a single purchase. So the money lives where money belongs —
 * StoreEngine's orders, subscriptions, receipts, refunds and gateways — and the
 * campus keeps only the school-shaped part: which plan a student is on, and
 * what that means for their class.
 *
 * Each fee plan owns a hidden StoreEngine product with one price. Families pay
 * through a direct checkout link (which is also what starts a subscription —
 * StoreEngine creates those from a real checkout, never behind a parent's
 * back). Cash at the office is a paid order recorded by staff, the same way the
 * POS records one.
 */
class Billing {

	/** Order and product meta linking a purchase back to the campus. */
	const PLAN_META    = '_adc_fee_plan_id';
	const STUDENT_META = '_adc_student_id';
	const PRODUCT_META = '_adc_fee_plan_product';

	public static function init() {
		// A family checking out on their own doesn't go through this plugin, so
		// stamp the order as a fee when it lands — otherwise the campus has no
		// way to tell a school fee from any other purchase.
		add_action( 'storeengine/checkout/order_processed', array( __CLASS__, 'tag_fee_order' ), 20 );
	}

	/**
	 * Mark an order as a campus fee if it contains a fee plan's product.
	 *
	 * @param mixed $order StoreEngine order.
	 */
	public static function tag_fee_order( $order ) {
		if ( ! is_object( $order ) || ! method_exists( $order, 'get_items' ) ) {
			return;
		}
		foreach ( (array) $order->get_items() as $item ) {
			if ( ! method_exists( $item, 'get_product_id' ) ) {
				continue;
			}
			$plan_id = (int) get_post_meta( (int) $item->get_product_id(), self::PRODUCT_META, true );
			if ( ! $plan_id ) {
				continue;
			}
			$order->update_meta_data( self::PLAN_META, $plan_id );
			if ( ! (int) $order->get_meta( self::STUDENT_META ) && method_exists( $order, 'get_customer_id' ) ) {
				$order->update_meta_data( self::STUDENT_META, (int) $order->get_customer_id() );
			}
			$order->save();
			return;
		}
	}

	/**
	 * What the school has taken, and what is still outstanding — read from the
	 * orders themselves, so it agrees with StoreEngine's own reports.
	 */
	public static function summary(): array {
		global $wpdb;
		$empty = array(
			'collected' => 0.0,
			'collected_this_month' => 0.0,
			'unpaid_count' => 0,
			'unpaid_amount' => 0.0
		);
		if ( ! self::available() ) {
			return $empty;
		}

		$orders = $wpdb->prefix . 'storeengine_orders';
		$meta   = $wpdb->prefix . 'storeengine_orders_meta';

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT o.status, o.total_amount, o.date_created_gmt
			 FROM {$orders} o
			 INNER JOIN {$meta} m ON m.order_id = o.id AND m.meta_key = %s
			 WHERE o.type = 'order' AND o.status NOT IN ( 'trash', 'draft', 'cancelled', 'refunded' )",
			self::PLAN_META
		), ARRAY_A );
		// phpcs:enable

		$out   = $empty;
		$month = gmdate( 'Y-m' );
		foreach ( (array) $rows as $row ) {
			$total = (float) $row['total_amount'];
			$paid  = in_array( (string) $row['status'], array( 'completed', 'processing', 'payment_confirmed' ), true );
			if ( $paid ) {
				$out['collected'] += $total;
				if ( 0 === strpos( (string) $row['date_created_gmt'], $month ) ) {
					$out['collected_this_month'] += $total;
				}
			} else {
				++$out['unpaid_count'];
				$out['unpaid_amount'] += $total;
			}
		}
		return $out;
	}

	/**
	 * What a class has been billed and has paid, across its fee plans.
	 *
	 * @param int $class_id
	 */
	public static function class_fee_summary( int $class_id ): array {
		global $wpdb;
		$out = array(
			'billed' => 0.0,
			'collected' => 0.0,
			'unpaid' => 0,
			'outstanding' => 0.0
		);
		if ( ! self::available() || ! $class_id ) {
			return $out;
		}

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- custom query with no WP API equivalent; only $wpdb-prefixed table names, whitelisted columns and intval/placeholder lists are interpolated; values are prepared
		$plans = $wpdb->get_results( $wpdb->prepare(
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			'SELECT * FROM ' . Helper::fee_plans_table() . ' WHERE class_id = %d',
			$class_id
		), ARRAY_A );
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared

		foreach ( (array) $plans as $plan ) {
			foreach ( self::collection( (int) $plan['id'], $plan ) as $row ) {
				$out['billed']    += (float) $plan['amount'];
				$out['collected'] += (float) $row['paid'];
				if ( 'due' === $row['status'] || 'partial' === $row['status'] ) {
					++$out['unpaid'];
				}
			}
		}
		$out['outstanding'] = max( 0, $out['billed'] - $out['collected'] );
		return $out;
	}

	/** Is StoreEngine here and usable? */
	public static function available(): bool {
		return function_exists( 'storeengine' )
			&& class_exists( '\\StoreEngine\\Classes\\Order' )
			&& class_exists( '\\StoreEngine\\Classes\\Price' );
	}

	/** Whether recurring fees can actually recur on this install. */
	public static function subscriptions_available(): bool {
		return self::available() && class_exists( '\\StoreEngine\\Addons\\Subscription\\Classes\\Subscription' );
	}

	/**
	 * Give a fee plan its StoreEngine product and price, or update them.
	 *
	 * @param array $plan Row from the fee-plans table.
	 * @param int   $link_product_id
	 * @return array{product_id:int, price_id:int}
	 */
	public static function sync_plan( array $plan, int $link_product_id = 0 ): array {
		if ( ! self::available() ) {
			return array(
				'product_id' => 0,
				'price_id' => 0
			);
		}

		$plan_id = (int) ( $plan['id'] ?? 0 );

		// A school that already sells "Tuition" can point the plan at that
		// product instead of collecting a second one.
		$adopting = false;
		if ( $link_product_id && 'storeengine_product' === get_post_type( $link_product_id ) ) {
			$adopting = self::find_product( $plan_id ) !== (int) $link_product_id;
			update_post_meta( $link_product_id, self::PRODUCT_META, $plan_id );
			self::release_other_products( $plan_id, $link_product_id );
			$product_id = $link_product_id;
		} else {
			$product_id = self::find_product( $plan_id );
		}

		$title = $plan['name'] ? (string) $plan['name'] : __( 'School fee', 'academy-pro' );

		if ( $product_id ) {
			wp_update_post( array(
				'ID' => $product_id,
				'post_title' => $title
			) );
		} else {
			$product_id = (int) wp_insert_post( array(
				'post_type'   => 'storeengine_product',
				'post_status' => 'publish',
				'post_title'  => $title,
			) );
			if ( ! $product_id ) {
				return array(
					'product_id' => 0,
					'price_id' => 0
				);
			}
			update_post_meta( $product_id, '_storeengine_product_type', 'simple' );
			// Fees are sold through the campus, not browsed in the shop.
			update_post_meta( $product_id, '_storeengine_product_hide_from_shop', true );
			update_post_meta( $product_id, self::PRODUCT_META, $plan_id );
		}//end if

		// Adopting a product that has already sold leaves its price alone —
		// rewriting it would change what past customers see and what any live
		// subscription renews at. The plan follows the product instead.
		if ( $adopting && self::has_sales( $product_id ) ) {
			return array(
				'product_id' => $product_id,
				'price_id' => self::find_price( $product_id )
			);
		}

		$price_id = self::sync_price( $product_id, $plan );

		return array(
			'product_id' => $product_id,
			'price_id' => $price_id
		);
	}

	/**
	 * The plan's price — a subscription when the fee repeats, so StoreEngine
	 * owns the renewals, the retries and the receipts.
	 *
	 * @param int   $product_id
	 * @param array $plan
	 */
	private static function sync_price( int $product_id, array $plan ): int {
		$monthly  = 'monthly' === ( $plan['frequency'] ?? 'one-time' );
		$price_id = self::find_price( $product_id );

		try {
			$price = new \StoreEngine\Classes\Price( $price_id ? $price_id : 0 );
			$price->set_product_id( $product_id );
			$price->set_price_name( (string) ( $plan['name'] ?? __( 'Fee', 'academy-pro' ) ) );
			$price->set_price( (float) ( $plan['amount'] ?? 0 ) );
			$price->set_price_type( $monthly ? 'subscription' : 'onetime' );
			if ( $monthly ) {
				$price->set_payment_duration( 1 );
				$price->set_payment_duration_type( 'month' );
			}
			$price->save();
			return (int) $price->get_id();
		} catch ( \Throwable $e ) {
			return (int) $price_id;
		}
	}

	/**
	 * A link that drops the fee straight into checkout.
	 *
	 * @param int $product_id
	 * @param int $price_id
	 */
	public static function checkout_url( int $product_id, int $price_id ): string {
		if ( ! $product_id || ! class_exists( '\\StoreEngine\\Utils\\Helper' ) ) {
			return '';
		}
		return add_query_arg(
			array(
				'product_id' => $product_id,
				'price_id' => $price_id,
				'qty' => 1
			),
			\StoreEngine\Utils\Helper::get_checkout_url()
		);
	}

	/**
	 * Record a fee paid at the office.
	 *
	 * Cash can't be a subscription — nobody can auto-charge a banknote — so
	 * each payment is its own completed order, which is exactly what the POS
	 * does for an over-the-counter sale.
	 *
	 * @param array  $plan
	 * @param int    $student_id
	 * @param float  $amount
	 * @param string $method
	 *
	 * @return int|\WP_Error Order id.
	 */
	public static function record_offline_payment( array $plan, int $student_id, float $amount = 0, string $method = 'cash' ) {
		if ( ! self::available() ) {
			return new \WP_Error( 'storeengine_unavailable', __( 'StoreEngine is not active, so fees can’t be recorded.', 'academy-pro' ), array( 'status' => 400 ) );
		}

		$ids      = self::sync_plan( $plan );
		$price_id = (int) $ids['price_id'];
		if ( ! $price_id ) {
			return new \WP_Error( 'no_price', __( 'This fee plan has no price yet.', 'academy-pro' ), array( 'status' => 400 ) );
		}

		try {
			$order = new \StoreEngine\Classes\Order();
			$order->set_created_via( 'academy_digital_campus' );
			$order->set_payment_method( $method );
			$order->set_payment_method_title( ucfirst( $method ) );

			$student = get_user_by( 'id', $student_id );
			if ( $student ) {
				$order->set_customer_id( $student_id );
				$order->set_billing_email( $student->user_email );
				$order->set_billing_first_name( $student->display_name );
			}

			$order->add_product( $price_id, 1 );

			// A part payment is the fee minus what is still owed, taken as a
			// discount line so the order total matches the cash in the drawer.
			$full = (float) ( $plan['amount'] ?? 0 );
			if ( $amount > 0 && $full > 0 && $amount < $full ) {
				$order->add_fee( __( 'Part payment adjustment', 'academy-pro' ), -1 * ( $full - $amount ) );
			}

			$order->calculate_totals();
			$order->update_meta_data( self::PLAN_META, (int) ( $plan['id'] ?? 0 ) );
			$order->update_meta_data( self::STUDENT_META, $student_id );
			$order->save();

			// The money is already in the drawer, so the order is paid outright
			// — the same seam StoreEngine's own "Mark as paid" uses. Without it
			// the order lands in processing but still reads as unpaid.
			if ( method_exists( $order, 'mark_as_paid_force' ) ) {
				$order->mark_as_paid_force( __( 'Fee collected at the office.', 'academy-pro' ) );
			} else {
				$order->payment_complete();
			}

			return (int) $order->get_id();
		} catch ( \Throwable $e ) {
			return new \WP_Error( 'order_failed', $e->getMessage(), array( 'status' => 500 ) );
		}//end try
	}

	/**
	 * A student's fee history, straight from StoreEngine.
	 *
	 * Orders are matched on the student meta the campus writes, and — for
	 * checkouts a family completed themselves — on the customer id.
	 *
	 * @param int    $student_id
	 * @param string $type
	 */
	public static function student_orders( int $student_id, string $type = 'order' ): array {
		global $wpdb;
		if ( ! self::available() || ! $student_id ) {
			return array();
		}

		$orders = $wpdb->prefix . 'storeengine_orders';
		$meta   = $wpdb->prefix . 'storeengine_orders_meta';

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- only $wpdb-prefixed table names, whitelisted columns and intval/placeholder lists are interpolated; values are prepared
		$ids = $wpdb->get_col( $wpdb->prepare(
			"SELECT DISTINCT o.id FROM {$orders} o
			 LEFT JOIN {$meta} m ON m.order_id = o.id AND m.meta_key = %s
			 WHERE ( m.meta_value = %d OR o.customer_id = %d )
			   AND o.type = %s
			   AND o.status NOT IN ( 'trash', 'draft' )
			 ORDER BY o.id DESC LIMIT 100",
			self::STUDENT_META,
			$student_id,
			$student_id,
			$type
		) );
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		$rows = array();
		foreach ( (array) $ids as $id ) {
			$order = \StoreEngine\Utils\Helper::get_order( (int) $id );
			if ( is_wp_error( $order ) || ! is_object( $order ) ) {
				continue;
			}
			$rows[] = array(
				'id'       => (int) $id,
				'number'   => method_exists( $order, 'get_order_number' ) ? $order->get_order_number() : (string) $id,
				'total'    => (float) $order->get_total(),
				'status'   => (string) $order->get_status(),
				'paid'     => method_exists( $order, 'is_paid' ) ? (bool) $order->is_paid() : false,
				'date'     => method_exists( $order, 'get_date_created_gmt' ) && $order->get_date_created_gmt()
					? $order->get_date_created_gmt()->date( 'Y-m-d' )
					: '',
				'plan_id'  => (int) $order->get_meta( self::PLAN_META ),
				'edit_url' => admin_url( 'admin.php?page=storeengine-orders&action=edit&id=' . (int) $id ),
			);
		}
		return $rows;
	}

	/**
	 * A student's live subscriptions — the recurring fees they are signed up to.
	 *
	 * @param int $student_id
	 */
	public static function student_subscriptions( int $student_id ): array {
		if ( ! self::subscriptions_available() ) {
			return array();
		}
		return array_values( array_filter(
			self::student_orders( $student_id, 'subscription' ),
			function ( $row ) {
				return ! in_array( $row['status'], array( 'cancelled', 'expired', 'trash' ), true );
			}
		) );
	}

	/**
	 * Who has paid a fee plan, and who hasn't.
	 *
	 * The people who owe it are the students enrolled in the plan's class (or
	 * every enrolled student, for a school-wide fee). A monthly plan is judged
	 * on the current month — an active subscription counts, because that is
	 * StoreEngine's job to collect from here on.
	 *
	 * @param int   $plan_id
	 * @param array $plan
	 *
	 * @return array<int, array>
	 */
	public static function collection( int $plan_id, array $plan ): array {
		global $wpdb;
		if ( ! class_exists( '\\AcademyDigitalCampus\\Helper' ) ) {
			return array();
		}

		// A facility plan is owed by the students riding that route or sleeping
		// in that room, not by a class.
		$member_fees = array();
		if ( ! empty( $plan['source_module'] ) ) {
			$member_fees = self::facility_member_fees( (string) $plan['source_module'], (int) $plan['source_id'] );
			$student_ids = array_keys( $member_fees );
		} else {
			$admissions = \AcademyDigitalCampus\Helper::admissions_table();
			$class_id   = (int) ( $plan['class_id'] ?? 0 );

			// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$student_ids = $class_id
				? $wpdb->get_col( $wpdb->prepare( "SELECT student_id FROM {$admissions} WHERE class_id = %d AND status = 'enrolled'", $class_id ) )
				: $wpdb->get_col( "SELECT student_id FROM {$admissions} WHERE status = 'enrolled'" );
			// phpcs:enable
		}

		$monthly = 'monthly' === ( $plan['frequency'] ?? 'one-time' );
		$since   = $monthly ? gmdate( 'Y-m-01' ) : '';
		$rows    = array();

		foreach ( array_map( 'intval', (array) $student_ids ) as $student_id ) {
			$user  = get_user_by( 'id', $student_id );
			$paid  = 0;
			$order = null;
			foreach ( self::student_orders( $student_id ) as $row ) {
				if ( (int) $row['plan_id'] !== $plan_id || ! $row['paid'] ) {
					continue;
				}
				if ( $since && $row['date'] && $row['date'] < $since ) {
					continue; // an earlier month doesn't settle this one
				}
				$paid += (float) $row['total'];
				$order = $order ? $order : $row;
			}

			$subscribed = false;
			if ( $monthly ) {
				foreach ( self::student_subscriptions( $student_id ) as $sub ) {
					if ( (int) $sub['plan_id'] === $plan_id ) {
						$subscribed = true;
						break;
					}
				}
			}

			$expected = ! empty( $member_fees[ $student_id ] )
				? (float) $member_fees[ $student_id ]
				: (float) ( $plan['amount'] ?? 0 );
			$due      = max( 0, $expected - $paid );
			$rows[] = array(
				'student_id' => $student_id,
				'name'       => $user ? $user->display_name : '',
				'expected'   => $expected,
				'paid'       => $paid,
				'due'        => $subscribed ? 0 : $due,
				'subscribed' => $subscribed,
				'status'     => $subscribed ? 'subscribed' : ( $due <= 0 && $paid > 0 ? 'paid' : ( $paid > 0 ? 'partial' : 'due' ) ),
				'order'      => $order,
			);
		}//end foreach

		return $rows;
	}

	/**
	 * A one-off charge with no plan behind it — a replacement ID card, a trip,
	 * a transport fee for one term. Recorded as a paid order like any other.
	 *
	 * @param string $label
	 * @param float  $amount
	 * @param int    $student_id
	 * @param string $method
	 *
	 * @return int|\WP_Error
	 */
	public static function record_adhoc_payment( string $label, float $amount, int $student_id, string $method = 'cash' ) {
		if ( ! self::available() ) {
			return new \WP_Error( 'storeengine_unavailable', __( 'StoreEngine is not active, so fees can’t be recorded.', 'academy-pro' ), array( 'status' => 400 ) );
		}
		if ( $amount <= 0 ) {
			return new \WP_Error( 'invalid', __( 'Enter the amount collected.', 'academy-pro' ), array( 'status' => 400 ) );
		}

		try {
			$order = new \StoreEngine\Classes\Order();
			$order->set_created_via( 'academy_digital_campus' );
			$order->set_payment_method( $method );
			$order->set_payment_method_title( ucfirst( $method ) );

			$student = get_user_by( 'id', $student_id );
			if ( $student ) {
				$order->set_customer_id( $student_id );
				$order->set_billing_email( $student->user_email );
				$order->set_billing_first_name( $student->display_name );
			}

			$order->add_fee( $label ? $label : __( 'Campus fee', 'academy-pro' ), $amount );
			$order->calculate_totals();
			$order->update_meta_data( self::STUDENT_META, $student_id );
			$order->save();
			if ( method_exists( $order, 'mark_as_paid_force' ) ) {
				$order->mark_as_paid_force( __( 'Fee collected at the office.', 'academy-pro' ) );
			} else {
				$order->payment_complete();
			}
			return (int) $order->get_id();
		} catch ( \Throwable $e ) {
			return new \WP_Error( 'order_failed', $e->getMessage(), array( 'status' => 500 ) );
		}//end try
	}

	/** Which transaction module holds the members of each facility. */
	const FACILITY_PLANS = array(
		'transport' => array(
			'members'  => 'transport_assignment',
			'link_key' => 'route',
			'label'    => 'Transport',
		),
		'hostel'    => array(
			'members'  => 'hostel_allocation',
			'link_key' => 'room_id',
			'label'    => 'Hostel',
		),
	);

	/**
	 * The students on one route or room, each with the fee agreed for them.
	 *
	 * @param string $module
	 * @param int    $asset_id
	 */
	public static function facility_member_fees( string $module, int $asset_id ): array {
		global $wpdb;
		$rule = self::FACILITY_PLANS[ $module ] ?? null;
		if ( ! $rule || ! $asset_id ) {
			return array();
		}

		$table = Helper::records_table();
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_col( $wpdb->prepare( "SELECT data FROM {$table} WHERE module = %s", $rule['members'] ) );

		$out = array();
		foreach ( (array) $rows as $json ) {
			$data = json_decode( (string) $json, true );
			if ( ! is_array( $data ) || 'active' !== ( $data['status'] ?? '' ) ) {
				continue;
			}
			if ( (int) ( $data[ $rule['link_key'] ] ?? 0 ) !== $asset_id ) {
				continue;
			}
			$student_id = (int) ( $data['student_id'] ?? 0 );
			if ( $student_id ) {
				// A family may have been given their own rate.
				$out[ $student_id ] = (float) ( $data['fee'] ?? 0 );
			}
		}
		return $out;
	}

	/**
	 * Give a route or room its own fee plan, so the families using it are
	 * billed the way everyone else is — a monthly subscription in the store,
	 * rather than a charge somebody has to remember to raise.
	 *
	 * @param string $module
	 * @param int    $asset_id
	 *
	 * @return int Plan id, or 0 when the facility has no fee to charge.
	 */
	public static function sync_facility_plan( string $module, int $asset_id ): int {
		global $wpdb;
		$rule = self::FACILITY_PLANS[ $module ] ?? null;
		if ( ! $rule || ! $asset_id ) {
			return 0;
		}

		$records = Helper::records_table();
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$asset = $wpdb->get_row( $wpdb->prepare( "SELECT id, title, data FROM {$records} WHERE id = %d AND module = %s", $asset_id, $module ), ARRAY_A );
		if ( ! $asset ) {
			return 0;
		}

		$data = (array) json_decode( (string) $asset['data'], true );
		$fee  = (float) ( $data['fee'] ?? 0 );

		$plans = Helper::fee_plans_table();
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$existing = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$plans} WHERE source_module = %s AND source_id = %d", $module, $asset_id ), ARRAY_A );

		// Nothing to bill: leave any existing plan alone rather than deleting
		// a plan orders already point at, but don't invent one either.
		if ( $fee <= 0 && ! $existing ) {
			return 0;
		}

		$name = sprintf( '%s — %s', __( $rule['label'], 'academy-pro' ), $asset['title'] ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralText
		$row  = array(
			'name'          => $name,
			'amount'        => $fee,
			'frequency'     => 'monthly',
			'components'    => wp_json_encode( array(
				array(
					'name' => $name,
					'amount' => $fee
				)
			) ),
			'status'        => ( $fee > 0 && 'active' === ( $data['status'] ?? 'active' ) ) ? 'active' : 'inactive',
			'source_module' => $module,
			'source_id'     => $asset_id,
		);

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		if ( $existing ) {
			$wpdb->update( $plans, $row, array( 'id' => (int) $existing['id'] ) );
			$plan_id = (int) $existing['id'];
		} else {
			$wpdb->insert( $plans, $row );
			$plan_id = (int) $wpdb->insert_id;
		}
		// phpcs:enable

		self::sync_plan( array_merge( $row, array( 'id' => $plan_id ) ) );
		return $plan_id;
	}

	/** Bring every route and room's fee plan up to date. */
	public static function sync_facility_plans(): int {
		global $wpdb;
		$records = Helper::records_table();
		$synced  = 0;
		foreach ( array_keys( self::FACILITY_PLANS ) as $module ) {
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$ids = $wpdb->get_col( $wpdb->prepare( "SELECT id FROM {$records} WHERE module = %s", $module ) );
			foreach ( array_map( 'intval', (array) $ids ) as $id ) {
				if ( self::sync_facility_plan( $module, $id ) ) {
					++$synced;
				}
			}
		}
		return $synced;
	}

	/** Products that could stand in for a fee plan, and what they cost today. */
	public static function catalog(): array {
		if ( ! self::available() ) {
			return array();
		}
		// phpcs:disable WordPress.WP.PostsPerPage.posts_per_page_posts_per_page -- admin picker list capped at 200
		$products = get_posts( array(
			'post_type'      => 'storeengine_product',
			'post_status'    => array( 'publish', 'draft' ),
			'posts_per_page' => 200,
			'orderby'        => 'title',
			'order'          => 'ASC',
		) );
		// phpcs:enable WordPress.WP.PostsPerPage.posts_per_page_posts_per_page

		$rows = array();
		foreach ( $products as $product ) {
			$price_id = self::find_price( (int) $product->ID );
			$price    = null;
			if ( $price_id ) {
				try {
					$price = new \StoreEngine\Classes\Price( $price_id );
				} catch ( \Throwable $e ) {
					$price = null;
				}
			}
			$rows[] = array(
				'id'         => (int) $product->ID,
				'title'      => $product->post_title,
				'price'      => $price ? (float) $price->get_price() : 0,
				'price_type' => $price ? (string) $price->get_price_type() : '',
				'plan_id'    => (int) get_post_meta( $product->ID, self::PRODUCT_META, true ),
				'has_sales'  => self::has_sales( (int) $product->ID ),
			);
		}
		return $rows;
	}

	/**
	 * Has anything ever been bought at this product's prices?
	 *
	 * @param int $product_id
	 */
	public static function has_sales( int $product_id ): bool {
		global $wpdb;
		$prices = $wpdb->prefix . 'storeengine_product_price';
		$lookup = $wpdb->prefix . 'storeengine_order_product_lookup';
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- only $wpdb-prefixed table names, whitelisted columns and intval/placeholder lists are interpolated; values are prepared
		return (bool) $wpdb->get_var( $wpdb->prepare(
			"SELECT 1 FROM {$lookup} l INNER JOIN {$prices} p ON p.id = l.price_id WHERE p.product_id = %d LIMIT 1",
			$product_id
		) );
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	}

	/**
	 * Only one product may stand for a plan.
	 *
	 * @param int $plan_id
	 * @param int $keep_id
	 */
	private static function release_other_products( int $plan_id, int $keep_id ): void {
		foreach ( (array) get_posts( array(
			'post_type'      => 'storeengine_product',
			'post_status'    => 'any',
			'posts_per_page' => 50,
			'fields'         => 'ids',
			// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
			'meta_key'       => self::PRODUCT_META,
			// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
			'meta_value'     => $plan_id,
		) ) as $id ) {
			if ( (int) $id !== $keep_id ) {
				delete_post_meta( (int) $id, self::PRODUCT_META );
			}
		}
	}

	/**
	 * The store ids for a plan, without touching them.
	 *
	 * @param int $plan_id
	 */
	public static function plan_ids( int $plan_id ): array {
		$product_id = self::available() ? self::find_product( $plan_id ) : 0;
		return array(
			'product_id' => $product_id,
			'price_id'   => $product_id ? self::find_price( $product_id ) : 0,
		);
	}

	/**
	 * The product already made for this plan, if any.
	 *
	 * @param int $plan_id
	 */
	private static function find_product( int $plan_id ): int {
		if ( ! $plan_id ) {
			return 0;
		}
		$found = get_posts( array(
			'post_type'      => 'storeengine_product',
			'post_status'    => 'any',
			'posts_per_page' => 1,
			'fields'         => 'ids',
			// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
			'meta_key'       => self::PRODUCT_META,
			// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
			'meta_value'     => $plan_id,
		) );
		return $found ? (int) $found[0] : 0;
	}

	/**
	 * A product's first price row.
	 *
	 * @param int $product_id
	 */
	private static function find_price( int $product_id ): int {
		global $wpdb;
		$table = $wpdb->prefix . 'storeengine_product_price';
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE product_id = %d ORDER BY id ASC LIMIT 1", $product_id ) );
	}
}
