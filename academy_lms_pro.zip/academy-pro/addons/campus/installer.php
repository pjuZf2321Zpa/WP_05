<?php
namespace AcademyProCampus;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Installer {

	public static function init() {
		$self = new self();
		$self->create_database();
		$self->grant_exam_caps();
		$self->save_option();
	}

	public function create_database() {
		Database::create_initial_custom_table();
	}

	/**
	 * Exam CPT caps are pro-only; grant them to admin + registrar here.
	 */
	public function grant_exam_caps() {
		$caps = array(
			'edit_adc_exam',
			'read_adc_exam',
			'delete_adc_exam',
			'delete_adc_exams',
			'edit_adc_exams',
			'edit_others_adc_exams',
			'publish_adc_exams',
			'read_private_adc_exams',
		);
		foreach ( array( 'administrator', 'adc_registrar' ) as $role_name ) {
			$role = get_role( $role_name );
			if ( ! $role ) {
				continue;
			}
			foreach ( $caps as $cap ) {
				$role->add_cap( $cap );
			}
		}
	}

	public function save_option() {
		\Academy\Options::set( \Academy\Options::PRO_DB_VERSIONS, 'campus', ACADEMY_PRO_CAMPUS_VERSION );
	}
}
