<?php
namespace AcademyProCampus\API;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use WP_Error;

/**
 * Pro tools: bulk student promotion / year rollover and CSV-style import.
 *
 * Route: academy/v1/sis/promote
 * academy/v1/sis/import
 */
class Tools extends \WP_REST_Controller {

	public static function init() {
		$self            = new self();
		$self->namespace = ACADEMY_DIGITAL_CAMPUS_PLUGIN_SLUG . '/v1';
		add_action( 'rest_api_init', array( $self, 'register_routes' ) );
	}

	public function register_routes() {
		register_rest_route( $this->namespace, '/sis/promote', array(
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'promote' ),
				'permission_callback' => array( 'AcademyProCampus\\Helper', 'manager_check' ),
			),
		) );
		register_rest_route( $this->namespace, '/sis/import', array(
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'import' ),
				'permission_callback' => array( 'AcademyProCampus\\Helper', 'manager_check' ),
			),
		) );
		register_rest_route( $this->namespace, '/sis/transfer', array(
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'transfer' ),
				'permission_callback' => array( 'AcademyProCampus\\Helper', 'manager_check' ),
			),
		) );
		register_rest_route( $this->namespace, '/sis/promotion-candidates', array(
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'promotion_candidates' ),
				'permission_callback' => array( 'AcademyProCampus\\Helper', 'manager_check' ),
			),
		) );
	}

	/**
	 * Enrolled students of a class, each flagged with whether they have a
	 * failing subject on any exam recorded for that class — so the promotion
	 * screen can offer to hold a student back instead of promoting everyone
	 * blind.
	 *
	 * @param \WP_REST_Request $request
	 */
	public function promotion_candidates( $request ) {
		global $wpdb;
		$class_id = (int) $request->get_param( 'class_id' );
		if ( ! $class_id || ! class_exists( '\AcademyDigitalCampus\Helper' ) ) {
			return rest_ensure_response( array() );
		}

		$student_ids = \AcademyDigitalCampus\Helper::get_class_student_ids( $class_id );
		if ( ! $student_ids ) {
			return rest_ensure_response( array() );
		}

		// Every exam recorded against this class — promotion happens at
		// year-end, after however many exams the class sat, not just one.
		// phpcs:disable WordPressVIPMinimum.Performance.NoPaging.posts_per_page_posts_per_page -- needs the complete (small, bounded) set
		$exam_ids = get_posts( array(
			'post_type'      => 'adc_exam',
			'post_status'    => 'publish',
			'posts_per_page' => -1,
			'fields'         => 'ids',
			// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
			'meta_key'       => 'adc_exam_class_id',
			// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
			'meta_value'     => $class_id,
		) );
		// phpcs:enable WordPressVIPMinimum.Performance.NoPaging.posts_per_page_posts_per_page

		$fails = array(); // student_id => [subject names]
		if ( $exam_ids ) {
			$table        = \AcademyProCampus\Helper::exam_results_table();
			$placeholders = implode( ',', array_fill( 0, count( $exam_ids ), '%d' ) );
			// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- only $wpdb-prefixed table names, whitelisted columns and intval/placeholder lists are interpolated; values are prepared
			$marks = $wpdb->get_results( $wpdb->prepare(
				"SELECT student_id, subject_id, obtained_marks, total_marks FROM {$table} WHERE exam_id IN ({$placeholders})",
				$exam_ids
			), ARRAY_A );
			// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber

			foreach ( $marks as $m ) {
				if ( null === $m['obtained_marks'] ) {
					continue;
				}
				$subject = \AcademyDigitalCampus\Helper::class_subject( $class_id, (int) $m['subject_id'] );
				$pass    = $subject['pass_marks'] > 0 ? $subject['pass_marks'] : ( (float) $m['total_marks'] * 0.33 );
				if ( (float) $m['obtained_marks'] < $pass ) {
					$fails[ (int) $m['student_id'] ][] = get_the_title( (int) $m['subject_id'] );
				}
			}
		}//end if

		$rows = array();
		foreach ( $student_ids as $sid ) {
			$user = get_user_by( 'id', $sid );
			if ( ! $user ) {
				continue;
			}
			$subjects = array_values( array_unique( $fails[ $sid ] ?? array() ) );
			$rows[]   = array(
				'id'            => $sid,
				'name'          => $user->display_name,
				'failed'        => ! empty( $subjects ),
				'fail_count'    => count( $subjects ),
				'fail_subjects' => $subjects,
			);
		}

		return rest_ensure_response( $rows );
	}

	/**
	 * Transfer a single student to another campus / class / section, keeping
	 * their admission record (used by the multi-campus workflow).
	 *
	 * @param \WP_REST_Request $request
	 */
	public function transfer( $request ) {
		global $wpdb;
		$table      = $this->admissions_table();
		$student_id = (int) $request->get_param( 'student_id' );
		if ( ! $student_id ) {
			return new WP_Error( 'invalid', __( 'A student is required.', 'academy-pro' ), array( 'status' => 400 ) );
		}

		$data = array( 'updated_at' => current_time( 'mysql' ) );
		foreach ( array( 'campus_id', 'class_id', 'section_id', 'academic_year_id' ) as $field ) {
			$val = $request->get_param( $field );
			if ( null !== $val && '' !== $val ) {
				$data[ $field ] = (int) $val;
			}
		}

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$admission = $wpdb->get_row( $wpdb->prepare( "SELECT id FROM {$table} WHERE student_id = %d ORDER BY id DESC LIMIT 1", $student_id ), ARRAY_A );
		if ( ! $admission ) {
			return new WP_Error( 'not_found', __( 'This student has no admission record to transfer.', 'academy-pro' ), array( 'status' => 404 ) );
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->update( $table, $data, array( 'id' => (int) $admission['id'] ) );
		\AcademyProCampus\Helper::audit( 'admission', (int) $admission['id'], 'transferred', '' );
		do_action( 'academy_digital_campus/student_transferred', $student_id, $data );

		return rest_ensure_response( array(
			'transferred' => true,
			'student_id' => $student_id
		) );
	}

	private function admissions_table() {
		global $wpdb;
		return $wpdb->prefix . 'adc_admissions';
	}

	/**
	 * Promote enrolled students of a class to a target class (or graduate them
	 * when no target is given).
	 *
	 * @param \WP_REST_Request $request
	 */
	public function promote( $request ) {
		global $wpdb;
		$table         = $this->admissions_table();
		$from_class_id = (int) $request->get_param( 'from_class_id' );
		$to_class_id   = (int) $request->get_param( 'to_class_id' );
		$to_section_id = (int) $request->get_param( 'to_section_id' );
		$year_id       = (int) $request->get_param( 'academic_year_id' );
		$term_id       = (int) $request->get_param( 'term_id' );
		// Students held back — e.g. a failed subject, a fee hold — stay in
		// their current class instead of moving with the rest.
		$exclude_ids   = array_map( 'intval', (array) $request->get_param( 'exclude_student_ids' ) );

		if ( ! $from_class_id ) {
			return new WP_Error( 'invalid', __( 'Select the class to promote from.', 'academy-pro' ), array( 'status' => 400 ) );
		}

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- only $wpdb-prefixed table names, whitelisted columns and intval/placeholder lists are interpolated; values are prepared
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT id, student_id, section_id, academic_year_id, term_id FROM {$table} WHERE class_id = %d AND status = 'enrolled'",
			$from_class_id
		), ARRAY_A );
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		$count    = 0;
		$excluded = 0;
		foreach ( (array) $rows as $row ) {
			if ( in_array( (int) $row['student_id'], $exclude_ids, true ) ) {
				++$excluded;
				continue;
			}
			$admission_id = (int) $row['id'];
			if ( $to_class_id ) {
				$data = array(
					'class_id' => $to_class_id,
					'section_id' => $to_section_id,
					'updated_at' => current_time( 'mysql' )
				);
				if ( $year_id ) {
					$data['academic_year_id'] = $year_id;
				}
				if ( $term_id ) {
					$data['term_id'] = $term_id;
				}
			} else {
				$data = array(
					'status' => 'graduated',
					'updated_at' => current_time( 'mysql' )
				);
			}
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->update( $table, $data, array( 'id' => $admission_id ) );
			++$count;

			// Per-student audit trail for the move.
			\AcademyProCampus\Helper::audit( 'admission', $admission_id, $to_class_id ? 'promoted' : 'graduated', '' );

			// Re-sync course access for the new class/term. Firing the same
			// event the admission path uses means the free plugin's
			// sync_course_enrollment (and any fee-on-enroll listener) runs for
			// the promoted student — closing the loop that promotion used to
			// leave open. Only meaningful when moving to a class (not graduating).
			if ( $to_class_id ) {
				do_action( 'academy_digital_campus/admission_updated', $admission_id, array(
					'student_id' => (int) $row['student_id'],
					'class_id'   => $to_class_id,
					'section_id' => $to_section_id ? $to_section_id : (int) $row['section_id'],
					'term_id'    => $term_id ? $term_id : (int) $row['term_id'],
					'status'     => 'enrolled',
				) );
			}
		}//end foreach

		do_action( 'academy_digital_campus/students_promoted', $from_class_id, $to_class_id, $count );

		return rest_ensure_response( array(
			'success'   => true,
			'promoted'  => $to_class_id ? $count : 0,
			'graduated' => $to_class_id ? 0 : $count,
			'excluded'  => $excluded,
		) );
	}

	/**
	 * Import students + admissions from parsed rows.
	 * Row: { name, email, admission_no, roll_no, class_id, section_id, status }
	 *
	 * @param \WP_REST_Request $request
	 */
	public function import( $request ) {
		global $wpdb;
		$table = $this->admissions_table();
		$rows  = (array) $request->get_param( 'rows' );

		$created = 0;
		$skipped = 0;
		$errors  = array();

		foreach ( $rows as $i => $row ) {
			$email = sanitize_email( (string) ( $row['email'] ?? '' ) );
			if ( ! is_email( $email ) ) {
				++$skipped;
				$errors[] = sprintf( /* translators: %d: row number */ __( 'Row %d: invalid email.', 'academy-pro' ), (int) $i + 1 );
				continue;
			}

			$user_id = email_exists( $email );
			if ( ! $user_id ) {
				$user_id = wp_insert_user( array(
					'user_login'   => $email,
					'user_email'   => $email,
					'display_name' => sanitize_text_field( (string) ( $row['name'] ?? $email ) ),
					'user_pass'    => wp_generate_password( 16 ),
					'role'         => 'academy_student',
				) );
				if ( is_wp_error( $user_id ) ) {
					++$skipped;
					$errors[] = sprintf( /* translators: %d: row number */ __( 'Row %d: could not create user.', 'academy-pro' ), (int) $i + 1 );
					continue;
				}
			} else {
				$user = get_user_by( 'id', $user_id );
				if ( $user && ! in_array( 'academy_student', (array) $user->roles, true ) ) {
					$user->add_role( 'academy_student' );
				}
			}

			$status = in_array( ( $row['status'] ?? '' ), array( 'applied', 'enrolled', 'withdrawn', 'graduated' ), true )
				? $row['status'] : 'enrolled';

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->insert( $table, array(
				'student_id'   => (int) $user_id,
				'class_id'     => (int) ( $row['class_id'] ?? 0 ),
				'section_id'   => (int) ( $row['section_id'] ?? 0 ),
				'admission_no' => sanitize_text_field( (string) ( $row['admission_no'] ?? '' ) ),
				'roll_no'      => sanitize_text_field( (string) ( $row['roll_no'] ?? '' ) ),
				'status'       => $status,
				'applied_at'   => current_time( 'mysql' ),
				'enrolled_at'  => 'enrolled' === $status ? current_time( 'mysql' ) : null,
			) );
			++$created;
		}//end foreach

		return rest_ensure_response( array(
			'success' => true,
			'created' => $created,
			'skipped' => $skipped,
			'errors'  => array_slice( $errors, 0, 20 ),
		) );
	}
}
