<?php
namespace AcademyProCampus\API;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AcademyProCampus\Helper;

/**
 * Audit log — records who changed admissions, marks, fees and notices.
 *
 * Route: academy/v1/sis/audit
 */
class Audit extends \WP_REST_Controller {

	public static function init() {
		$self            = new self();
		$self->namespace = ACADEMY_DIGITAL_CAMPUS_PLUGIN_SLUG . '/v1';
		add_action( 'rest_api_init', array( $self, 'register_routes' ) );

		// Log domain events (fired by free spine + pro modules).
		add_action( 'academy_digital_campus/admission_created', array( $self, 'on_admission_created' ), 20, 2 );
		add_action( 'academy_digital_campus/admission_updated', array( $self, 'on_admission_updated' ), 20, 2 );
		add_action( 'academy_digital_campus/students_promoted', array( $self, 'on_promoted' ), 20, 3 );
	}

	public function register_routes() {
		register_rest_route( $this->namespace, '/sis/audit', array(
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_items' ),
				'permission_callback' => array( 'AcademyProCampus\\Helper', 'manager_check' ),
			),
		) );
	}

	public function on_admission_created( $id, $data ) {
		Helper::audit( 'admission', $id, 'created', $this->student_label( $data['student_id'] ?? 0 ) );
	}

	public function on_admission_updated( $id, $data ) {
		$note = $this->student_label( $data['student_id'] ?? 0 );
		if ( ! empty( $data['status'] ) ) {
			$note .= ' → ' . $data['status'];
		}
		Helper::audit( 'admission', $id, 'updated', $note );
	}

	public function on_promoted( $from_class_id, $to_class_id, $count ) {
		$from = get_the_title( (int) $from_class_id );
		$to   = $to_class_id ? get_the_title( (int) $to_class_id ) : __( 'Graduated', 'academy-pro' );
		/* translators: 1: number of students, 2: class they left, 3: class they joined. */
		Helper::audit( 'promotion', $from_class_id, 'promoted', sprintf( __( '%1$d students: %2$s → %3$s', 'academy-pro' ), (int) $count, $from, $to ) );
	}

	private function student_label( $student_id ) {
		$u = get_user_by( 'id', (int) $student_id );
		return $u ? $u->display_name : ( '#' . (int) $student_id );
	}

	public function get_items( $request ) {
		global $wpdb;
		$table = Helper::audit_table();
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results( "SELECT * FROM {$table} ORDER BY id DESC LIMIT 200", ARRAY_A );
		$rows = array_map( function ( $r ) {
			$actor = $r['actor_id'] ? get_user_by( 'id', (int) $r['actor_id'] ) : null;
			$r['actor_name'] = $actor ? $actor->display_name : __( 'System', 'academy-pro' );
			$r['when']       = mysql2date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $r['created_at'] );
			return $r;
		}, $rows ? $rows : array() );
		return rest_ensure_response( $rows );
	}
}
