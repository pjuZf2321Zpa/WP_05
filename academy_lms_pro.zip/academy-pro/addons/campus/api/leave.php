<?php
namespace AcademyProCampus\API;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AcademyProCampus\Helper;
use AcademyProCampus\Notifier;
use WP_Error;

/**
 * Leave applications.
 *
 * Until now a family telling the school "he'll be away on Thursday" happened
 * over the phone, and the register still said absent. This is the same
 * conversation with a record behind it: the family asks, the class teacher (or
 * the office) answers, and an approval writes the days into the register as
 * leave rather than absence — so the attendance percentage a parent sees on
 * their dashboard stops punishing a day the school agreed to.
 *
 * academy-digital-campus/v1/sis/leave/*
 */
class Leave extends \WP_REST_Controller {

	/** How far a single application may stretch, so one typo can't fill a term. */
	const MAX_DAYS = 60;

	public static function init() {
		$self            = new self();
		$self->namespace = ACADEMY_DIGITAL_CAMPUS_PLUGIN_SLUG . '/v1';
		add_action( 'rest_api_init', array( $self, 'register_routes' ) );
	}

	public function register_routes() {
		register_rest_route( $this->namespace, '/sis/leave', array(
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_items' ),
				'permission_callback' => array( $this, 'can_read' ),
			),
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'create_item' ),
				'permission_callback' => array( $this, 'can_apply' ),
			),
		) );

		register_rest_route( $this->namespace, '/sis/leave/(?P<id>\d+)/decide', array(
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'decide' ),
				'permission_callback' => array( $this, 'can_decide' ),
			),
		) );

		register_rest_route( $this->namespace, '/sis/leave/(?P<id>\d+)/cancel', array(
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'cancel' ),
				'permission_callback' => array( $this, 'can_apply' ),
			),
		) );
	}

	/**
	 * Reading is either "my child's applications" or "the ones waiting on me".
	 * Which one it is depends on whether a student was named.
	 *
	 * @param \WP_REST_Request $request
	 */
	public function can_read( $request ) {
		$student_id = (int) $request->get_param( 'student_id' );
		if ( $student_id ) {
			return \AcademyDigitalCampus\Helper::current_user_can_view_student( $student_id );
		}
		return $this->is_staff_or_teacher();
	}

	/**
	 * A family applies for its own student; so may the office.
	 *
	 * @param \WP_REST_Request $request
	 */
	public function can_apply( $request ) {
		$student_id = (int) $request->get_param( 'student_id' );
		if ( ! $student_id && $request->get_param( 'id' ) ) {
			$row        = $this->row( (int) $request->get_param( 'id' ) );
			$student_id = (int) ( $row['student_id'] ?? 0 );
		}
		if ( ! $student_id ) {
			return new WP_Error( 'invalid', __( 'Choose a student first.', 'academy-pro' ), array( 'status' => 400 ) );
		}
		return \AcademyDigitalCampus\Helper::current_user_can_view_student( $student_id );
	}

	/**
	 * Only whoever teaches that section — or campus staff — may answer it.
	 *
	 * @param \WP_REST_Request $request
	 */
	public function can_decide( $request ) {
		if ( ! $this->is_staff_or_teacher() ) {
			return false;
		}
		$row = $this->row( (int) $request->get_param( 'id' ) );
		if ( ! $row ) {
			return new WP_Error( 'not_found', __( 'That application no longer exists.', 'academy-pro' ), array( 'status' => 404 ) );
		}
		return Helper::teaches_section( get_current_user_id(), (int) $row['section_id'] );
	}

	private function is_staff_or_teacher() {
		if ( ! is_user_logged_in() ) {
			return false;
		}
		return current_user_can( 'manage_adc_sis' ) || in_array( 'academy_instructor', (array) wp_get_current_user()->roles, true );
	}

	/**
	 * A student's applications, or the ones a teacher has to answer.
	 *
	 * @param \WP_REST_Request $request
	 */
	public function get_items( $request ) {
		global $wpdb;
		$table  = Helper::leave_requests_table();
		$status = sanitize_key( (string) $request->get_param( 'status' ) );

		$student_id = (int) $request->get_param( 'student_id' );
		if ( $student_id ) {
			$where  = 'student_id = %d';
			$params = array( $student_id );
		} else {
			// A teacher sees their own sections; staff see the whole school.
			$section_id = (int) $request->get_param( 'section_id' );
			if ( $section_id ) {
				if ( ! Helper::teaches_section( get_current_user_id(), $section_id ) ) {
					return new WP_Error( 'forbidden', __( 'That section isn’t yours.', 'academy-pro' ), array( 'status' => 403 ) );
				}
				$sections = array( $section_id );
			} elseif ( current_user_can( 'manage_adc_sis' ) ) {
				$sections = array();
			} else {
				$sections = wp_list_pluck( Helper::teacher_sections( get_current_user_id() ), 'id' );
				if ( ! $sections ) {
					return rest_ensure_response( array() );
				}
			}

			if ( $sections ) {
				$in     = implode( ',', array_map( 'intval', $sections ) );
				$where  = "section_id IN ({$in})";
				$params = array();
			} else {
				$where  = '1 = %d';
				$params = array( 1 );
			}
		}//end if

		if ( $status && 'all' !== $status ) {
			$where   .= ' AND status = %s';
			$params[] = $status;
		}

		$sql = "SELECT * FROM {$table} WHERE {$where} ORDER BY FIELD(status,'pending') DESC, start_date DESC LIMIT 200";
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared -- only $wpdb-prefixed table names, whitelisted columns and intval/placeholder lists are interpolated; values are prepared
		$rows = $params
			? $wpdb->get_results( $wpdb->prepare( $sql, $params ), ARRAY_A )
			: $wpdb->get_results( $sql, ARRAY_A );
		// phpcs:enable WordPress.DB.PreparedSQL.NotPrepared
		// phpcs:enable

		return rest_ensure_response( array_map( array( $this, 'present' ), (array) $rows ) );
	}

	/**
	 * Ask for the days off.
	 *
	 * @param \WP_REST_Request $request
	 */
	public function create_item( $request ) {
		global $wpdb;
		$student_id = (int) $request->get_param( 'student_id' );
		$from       = $this->date( $request->get_param( 'from_date' ) );
		$to         = $this->date( $request->get_param( 'to_date' ) ) ? $this->date( $request->get_param( 'to_date' ) ) : $from;

		if ( ! $from || ! $to ) {
			return new WP_Error( 'invalid', __( 'Give the first and last day of the leave.', 'academy-pro' ), array( 'status' => 400 ) );
		}
		if ( $to < $from ) {
			return new WP_Error( 'invalid', __( 'The last day can’t fall before the first.', 'academy-pro' ), array( 'status' => 400 ) );
		}

		$days = $this->span( $from, $to );
		if ( $days > self::MAX_DAYS ) {
			return new WP_Error(
				'invalid',
				/* translators: %d: maximum number of days */
				sprintf( __( 'One application can cover at most %d days.', 'academy-pro' ), self::MAX_DAYS ),
				array( 'status' => 400 )
			);
		}

		$reason = sanitize_textarea_field( (string) $request->get_param( 'reason' ) );
		if ( '' === $reason ) {
			return new WP_Error( 'invalid', __( 'Say why the leave is needed.', 'academy-pro' ), array( 'status' => 400 ) );
		}

		// An application already covering these days is a double-send, not a
		// second request.
		$table = Helper::leave_requests_table();
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- only $wpdb-prefixed table names, whitelisted columns and intval/placeholder lists are interpolated; values are prepared
		$clash = $wpdb->get_var( $wpdb->prepare(
			"SELECT id FROM {$table}
			 WHERE student_id = %d AND status IN ('pending','approved')
			 AND start_date <= %s AND end_date >= %s",
			$student_id,
			$to,
			$from
		) );
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		if ( $clash ) {
			return new WP_Error( 'duplicate', __( 'Those days are already covered by another application.', 'academy-pro' ), array( 'status' => 409 ) );
		}

		$admission = \AcademyDigitalCampus\Helper::get_student_admission( $student_id );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->insert( $table, array(
			'student_id'     => $student_id,
			'class_id'       => (int) ( $admission['class_id'] ?? 0 ),
			'section_id'     => (int) ( $admission['section_id'] ?? 0 ),
			'start_date'     => $from,
			'end_date'       => $to,
			'days'           => $days,
			'type'           => $this->type( $request->get_param( 'type' ) ),
			'reason'         => $reason,
			'attachment_url' => esc_url_raw( (string) $request->get_param( 'attachment_url' ) ),
			'status'         => 'pending',
			'requested_by'   => get_current_user_id(),
		) );
		$id = (int) $wpdb->insert_id;

		$this->notify_school( $id );
		Helper::audit( 'leave', $id, 'applied', $from . ' → ' . $to );

		return rest_ensure_response( $this->present( $this->row( $id ) ) );
	}

	/**
	 * Answer it. Approving also marks the days as leave in the register, so the
	 * absence a parent would otherwise see never appears.
	 *
	 * @param \WP_REST_Request $request
	 */
	public function decide( $request ) {
		global $wpdb;
		$id  = (int) $request->get_param( 'id' );
		$row = $this->row( $id );
		if ( ! $row ) {
			return new WP_Error( 'not_found', __( 'That application no longer exists.', 'academy-pro' ), array( 'status' => 404 ) );
		}
		if ( 'pending' !== $row['status'] ) {
			return new WP_Error( 'settled', __( 'That application has already been answered.', 'academy-pro' ), array( 'status' => 409 ) );
		}

		$status = 'approved' === $request->get_param( 'status' ) ? 'approved' : 'rejected';
		$note   = sanitize_text_field( (string) $request->get_param( 'decision_note' ) );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->update( Helper::leave_requests_table(), array(
			'status'        => $status,
			'decision_note' => $note,
			'decided_by'    => get_current_user_id(),
			'decided_at'    => current_time( 'mysql' ),
		), array( 'id' => $id ) );

		$marked = 'approved' === $status ? $this->mark_register( $row ) : 0;

		$this->notify_family( $id, $status, $note );
		Helper::audit( 'leave', $id, $status, $row['start_date'] . ' → ' . $row['end_date'] );

		return rest_ensure_response( array_merge(
			$this->present( $this->row( $id ) ),
			array( 'register_marked' => $marked )
		) );
	}

	/**
	 * Withdraw an application the school hasn't answered yet.
	 *
	 * @param \WP_REST_Request $request
	 */
	public function cancel( $request ) {
		global $wpdb;
		$id  = (int) $request->get_param( 'id' );
		$row = $this->row( $id );
		if ( ! $row ) {
			return new WP_Error( 'not_found', __( 'That application no longer exists.', 'academy-pro' ), array( 'status' => 404 ) );
		}
		if ( 'pending' !== $row['status'] ) {
			return new WP_Error( 'settled', __( 'Only an unanswered application can be withdrawn.', 'academy-pro' ), array( 'status' => 409 ) );
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->update( Helper::leave_requests_table(), array( 'status' => 'cancelled' ), array( 'id' => $id ) );
		Helper::audit( 'leave', $id, 'withdrawn', '' );

		return rest_ensure_response( $this->present( $this->row( $id ) ) );
	}

	/**
	 * Write the approved days into the day register.
	 *
	 * Only days nobody has marked yet: if a teacher already recorded the
	 * student present, the register saw them and the register wins.
	 *
	 * @param array $row
	 */
	private function mark_register( $row ) {
		global $wpdb;
		$section_id = (int) $row['section_id'];
		$student_id = (int) $row['student_id'];
		if ( ! $section_id ) {
			return 0;
		}

		$table  = Helper::attendance_table();
		$marked = 0;
		$day    = strtotime( $row['start_date'] );
		$last   = strtotime( $row['end_date'] );

		while ( $day <= $last && $marked < self::MAX_DAYS ) {
			$date = gmdate( 'Y-m-d', $day );
			$day  = strtotime( '+1 day', $day );

			// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$exists = $wpdb->get_var( $wpdb->prepare(
				"SELECT id FROM {$table} WHERE student_id = %d AND att_date = %s LIMIT 1",
				$student_id,
				$date
			) );
			if ( $exists ) {
				continue;
			}
			$wpdb->insert( $table, array(
				'section_id' => $section_id,
				'subject_id' => 0,
				'student_id' => $student_id,
				'att_date'   => $date,
				'status'     => 'leave',
				'remarks'    => __( 'Approved leave', 'academy-pro' ),
				'marked_by'  => get_current_user_id(),
			) );
			// phpcs:enable
			++$marked;
		}//end while

		return $marked;
	}

	/**
	 * Tell whoever has to answer that something is waiting.
	 *
	 * @param int $id
	 */
	private function notify_school( $id ) {
		$row = $this->row( $id );
		if ( ! $row ) {
			return;
		}
		$teacher_id = (int) get_post_meta( (int) $row['section_id'], 'adc_section_teacher_id', true );
		if ( ! $teacher_id ) {
			return;
		}
		$student = get_user_by( 'id', (int) $row['student_id'] );
		Notifier::dispatch(
			array( $teacher_id ),
			__( 'Leave application', 'academy-pro' ),
			sprintf(
				/* translators: 1: student name, 2: first day, 3: last day, 4: reason */
				__( '%1$s has applied for leave from %2$s to %3$s. Reason: %4$s', 'academy-pro' ),
				$student ? $student->display_name : '',
				$row['start_date'],
				$row['end_date'],
				$row['reason']
			)
		);
	}

	/**
	 * Tell the family what the school decided.
	 *
	 * @param int    $id
	 * @param string $status
	 * @param mixed  $note
	 */
	private function notify_family( $id, $status, $note ) {
		$row = $this->row( $id );
		if ( ! $row ) {
			return;
		}
		$message = 'approved' === $status
			/* translators: 1: first day, 2: last day */
			? sprintf( __( 'The leave from %1$s to %2$s has been approved.', 'academy-pro' ), $row['start_date'], $row['end_date'] )
			/* translators: 1: first day, 2: last day */
			: sprintf( __( 'The leave from %1$s to %2$s was not approved.', 'academy-pro' ), $row['start_date'], $row['end_date'] );
		if ( $note ) {
			$message .= ' ' . $note;
		}
		Notifier::notify_student_guardians( (int) $row['student_id'], __( 'Leave application', 'academy-pro' ), $message );
	}

	/**
	 * One application, as the dashboard wants to read it.
	 *
	 * @param array $row
	 */
	private function present( $row ) {
		if ( ! $row ) {
			return null;
		}
		$student = get_user_by( 'id', (int) $row['student_id'] );
		$decider = $row['decided_by'] ? get_user_by( 'id', (int) $row['decided_by'] ) : null;
		return array(
			'id'             => (int) $row['id'],
			'student_id'     => (int) $row['student_id'],
			'student'        => $student ? $student->display_name : '',
			'section_id'     => (int) $row['section_id'],
			'section'        => $row['section_id'] ? Helper::title( (int) $row['section_id'] ) : '',
			'class'          => $row['class_id'] ? Helper::title( (int) $row['class_id'] ) : '',
			'from_date'      => (string) $row['start_date'],
			'to_date'        => (string) $row['end_date'],
			'days'           => (int) $row['days'],
			'type'           => (string) $row['type'],
			'reason'         => (string) $row['reason'],
			'attachment_url' => (string) $row['attachment_url'],
			'status'         => (string) $row['status'],
			'decision_note'  => (string) $row['decision_note'],
			'decided_by'     => $decider ? $decider->display_name : '',
			'created_at'     => (string) $row['created_at'],
		);
	}

	private function row( $id ) {
		global $wpdb;
		$table = Helper::leave_requests_table();
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", (int) $id ), ARRAY_A );
	}

	private function date( $value ) {
		$value = sanitize_text_field( (string) $value );
		return preg_match( '/^\d{4}-\d{2}-\d{2}$/', $value ) ? $value : '';
	}

	private function type( $value ) {
		$value = sanitize_key( (string) $value );
		return in_array( $value, array( 'sick', 'family', 'travel', 'other' ), true ) ? $value : 'other';
	}

	private function span( $from, $to ) {
		return (int) round( ( strtotime( $to ) - strtotime( $from ) ) / DAY_IN_SECONDS ) + 1;
	}
}
