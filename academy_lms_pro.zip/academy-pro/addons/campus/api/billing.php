<?php
namespace AcademyProCampus\API;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AcademyProCampus\Billing as BillingService;
use AcademyProCampus\Helper;
use WP_Error;

/**
 * Fee collection, on StoreEngine.
 *
 * Route: academy-digital-campus/v1/sis/billing/*
 */
class Billing extends \WP_REST_Controller {

	public static function init() {
		$self            = new self();
		$self->namespace = ACADEMY_DIGITAL_CAMPUS_PLUGIN_SLUG . '/v1';
		add_action( 'rest_api_init', array( $self, 'register_routes' ) );
	}

	public function register_routes() {
		// What this install can do with fees at all.
		register_rest_route( $this->namespace, '/sis/billing/status', array(
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_status' ),
				'permission_callback' => function () {
					return is_user_logged_in();
				},
			),
		) );

		// Record a fee taken at the office.
		register_rest_route( $this->namespace, '/sis/billing/collect', array(
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'collect' ),
				'permission_callback' => array( Helper::class, 'fees_check' ),
			),
		) );

		// Who has paid a plan and who hasn't.
		register_rest_route( $this->namespace, '/sis/billing/collection', array(
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'collection' ),
				'permission_callback' => array( Helper::class, 'fees_check' ),
			),
		) );

		// A fee with no plan behind it.
		register_rest_route( $this->namespace, '/sis/billing/collect-adhoc', array(
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'collect_adhoc' ),
				'permission_callback' => array( Helper::class, 'fees_check' ),
			),
		) );

		// Products a plan could be sold as.
		register_rest_route( $this->namespace, '/sis/billing/products', array(
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'products' ),
				'permission_callback' => array( Helper::class, 'fees_check' ),
			),
		) );

		// Give a plan its product without having to edit it.
		register_rest_route( $this->namespace, '/sis/billing/sync-plan', array(
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'sync_plan' ),
				'permission_callback' => array( Helper::class, 'fees_check' ),
			),
		) );

		// Bring every route and room's fee plan up to date.
		register_rest_route( $this->namespace, '/sis/billing/sync-facilities', array(
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'sync_facilities' ),
				'permission_callback' => array( Helper::class, 'fees_check' ),
			),
		) );

		// A student's fee history — orders, not invoices.
		register_rest_route( $this->namespace, '/sis/billing/orders', array(
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'orders' ),
				'permission_callback' => function ( $request ) {
					$student_id = (int) $request->get_param( 'student_id' );
					return \AcademyDigitalCampus\Helper::current_user_can_view_student( $student_id );
				},
			),
		) );
	}

	public function get_status() {
		return rest_ensure_response( array(
			'available'     => BillingService::available(),
			'subscriptions' => BillingService::subscriptions_available(),
		) );
	}

	public function collect( $request ) {
		$plan = $this->plan( (int) $request->get_param( 'plan_id' ) );
		if ( ! $plan ) {
			return new WP_Error( 'not_found', __( 'Fee plan not found.', 'academy-pro' ), array( 'status' => 404 ) );
		}
		$student_id = (int) $request->get_param( 'student_id' );
		if ( ! $student_id ) {
			return new WP_Error( 'invalid', __( 'Choose a student first.', 'academy-pro' ), array( 'status' => 400 ) );
		}

		$order_id = BillingService::record_offline_payment(
			$plan,
			$student_id,
			(float) $request->get_param( 'amount' ),
			sanitize_text_field( (string) ( $request->get_param( 'method' ) ? $request->get_param( 'method' ) : 'cash' ) )
		);
		if ( is_wp_error( $order_id ) ) {
			return $order_id;
		}

		Helper::audit( 'fee', $order_id, 'collected', (string) $plan['name'] );

		return rest_ensure_response( array(
			'order_id' => $order_id,
			'edit_url' => admin_url( 'admin.php?page=storeengine-orders&action=edit&id=' . $order_id ),
		) );
	}

	public function orders( $request ) {
		$student_id = (int) $request->get_param( 'student_id' );
		return rest_ensure_response( array(
			'orders'        => BillingService::student_orders( $student_id ),
			'subscriptions' => BillingService::student_subscriptions( $student_id ),
		) );
	}

	public function products() {
		return rest_ensure_response( BillingService::catalog() );
	}

	public function sync_plan( $request ) {
		$plan = $this->plan( (int) $request->get_param( 'plan_id' ) );
		if ( ! $plan ) {
			return new WP_Error( 'not_found', __( 'Fee plan not found.', 'academy-pro' ), array( 'status' => 404 ) );
		}
		$ids = BillingService::sync_plan( $plan, (int) $request->get_param( 'product_id' ) );
		if ( ! $ids['product_id'] ) {
			return new WP_Error( 'storeengine_unavailable', __( 'StoreEngine is not active, so the plan can’t be sold yet.', 'academy-pro' ), array( 'status' => 400 ) );
		}
		return rest_ensure_response( $ids );
	}

	public function sync_facilities() {
		return rest_ensure_response( array( 'synced' => BillingService::sync_facility_plans() ) );
	}

	public function collection( $request ) {
		$plan_id = (int) $request->get_param( 'plan_id' );
		$plan    = $this->plan( $plan_id );
		if ( ! $plan ) {
			return new WP_Error( 'not_found', __( 'Fee plan not found.', 'academy-pro' ), array( 'status' => 404 ) );
		}
		return rest_ensure_response( array(
			'plan' => array(
				'id'        => $plan_id,
				'name'      => $plan['name'],
				'amount'    => (float) $plan['amount'],
				'frequency' => $plan['frequency'],
			),
			'rows' => BillingService::collection( $plan_id, $plan ),
		) );
	}

	public function collect_adhoc( $request ) {
		$order_id = BillingService::record_adhoc_payment(
			sanitize_text_field( (string) $request->get_param( 'label' ) ),
			(float) $request->get_param( 'amount' ),
			(int) $request->get_param( 'student_id' ),
			sanitize_text_field( (string) ( $request->get_param( 'method' ) ? $request->get_param( 'method' ) : 'cash' ) )
		);
		if ( is_wp_error( $order_id ) ) {
			return $order_id;
		}
		Helper::audit( 'fee', $order_id, 'collected', sanitize_text_field( (string) $request->get_param( 'label' ) ) );
		return rest_ensure_response( array( 'order_id' => $order_id ) );
	}

	/**
	 * One fee plan row.
	 *
	 * @param int $id
	 */
	private function plan( $id ) {
		global $wpdb;
		$table = Helper::fee_plans_table();
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", (int) $id ), ARRAY_A );
	}
}
