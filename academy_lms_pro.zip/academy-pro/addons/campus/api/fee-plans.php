<?php
namespace AcademyProCampus\API;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AcademyProCampus\Helper;

/**
 * Fee plan CRUD.  academy/v1/sis/fee-plans
 */
class FeePlans extends \WP_REST_Controller {

	public static function init() {
		$self            = new self();
		$self->namespace = ACADEMY_DIGITAL_CAMPUS_PLUGIN_SLUG . '/v1';
		$self->rest_base = 'sis/fee-plans';
		add_action( 'rest_api_init', array( $self, 'register_routes' ) );
	}

	public function register_routes() {
		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base,
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_items' ),
					'permission_callback' => array( 'AcademyProCampus\\Helper', 'fees_check' ),
				),
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'create_item' ),
					'permission_callback' => array( 'AcademyProCampus\\Helper', 'fees_check' ),
				),
			)
		);
		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/(?P<id>\d+)',
			array(
				array(
					'methods'             => \WP_REST_Server::EDITABLE,
					'callback'            => array( $this, 'update_item' ),
					'permission_callback' => array( 'AcademyProCampus\\Helper', 'fees_check' ),
				),
				array(
					'methods'             => \WP_REST_Server::DELETABLE,
					'callback'            => array( $this, 'delete_item' ),
					'permission_callback' => array( 'AcademyProCampus\\Helper', 'fees_check' ),
				),
			)
		);
	}

	public function get_items( $request ) {
		global $wpdb;
		$table = Helper::fee_plans_table();
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results( "SELECT * FROM {$table} ORDER BY id DESC", ARRAY_A );
		$rows = array_map( function ( $r ) {
			$r['components'] = (array) json_decode( (string) $r['components'], true );
			$r['class_name'] = $r['class_id'] ? get_the_title( (int) $r['class_id'] ) : '';

			// Where this plan lives in the store, and the link a family pays it
			// through — a subscription checkout when the fee repeats.
			$ids                 = \AcademyProCampus\Billing::plan_ids( (int) $r['id'] );
			$r['product_id']     = $ids['product_id'];
			$r['price_id']       = $ids['price_id'];
			$r['checkout_url']   = \AcademyProCampus\Billing::checkout_url( $ids['product_id'], $ids['price_id'] );
			$r['is_subscription'] = 'monthly' === $r['frequency'];

			// A facility plan bills the students on that route or in that room.
			$r['source_label'] = '';
			if ( ! empty( $r['source_module'] ) ) {
				$rule              = \AcademyProCampus\Billing::FACILITY_PLANS[ $r['source_module'] ] ?? null;
				$r['source_label'] = $rule ? $rule['label'] : $r['source_module'];
			}
			return $r;
		}, $rows ? $rows : array() );
		return rest_ensure_response( $rows );
	}

	private function payload( $request ) {
		// Named fee heads: [{ name, amount }, …]. The plan amount is their sum so
		// the total always matches the breakdown.
		$components = self::clean_components( $request->get_param( 'components' ) );
		$amount     = $components
			? array_sum( wp_list_pluck( $components, 'amount' ) )
			: (float) $request->get_param( 'amount' );

		return array(
			'name'             => sanitize_text_field( (string) $request->get_param( 'name' ) ),
			'class_id'         => (int) $request->get_param( 'class_id' ),
			'academic_year_id' => (int) $request->get_param( 'academic_year_id' ),
			'term_id'          => (int) $request->get_param( 'term_id' ),
			'amount'           => $amount,
			'frequency'        => sanitize_text_field( (string) ( $request->get_param( 'frequency' ) ? $request->get_param( 'frequency' ) : 'one-time' ) ),
			'components'       => wp_json_encode( $components ),
			'status'           => sanitize_text_field( (string) ( $request->get_param( 'status' ) ? $request->get_param( 'status' ) : 'active' ) ),
		);
	}

	/**
	 * Sanitize an array of fee heads into [{ name, amount(float) }].
	 *
	 * @param mixed $raw
	 */
	public static function clean_components( $raw ) {
		$out = array();
		foreach ( (array) $raw as $c ) {
			$name = sanitize_text_field( (string) ( $c['name'] ?? '' ) );
			if ( '' === $name ) {
				continue;
			}
			$out[] = array(
				'name' => $name,
				'amount' => round( (float) ( $c['amount'] ?? 0 ), 2 )
			);
		}
		return $out;
	}

	public function create_item( $request ) {
		global $wpdb;
		$table = Helper::fee_plans_table();
		$data  = $this->payload( $request );
		if ( '' === $data['name'] ) {
			return new \WP_Error( 'invalid', __( 'A plan name is required.', 'academy-pro' ), array( 'status' => 400 ) );
		}
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->insert( $table, $data );
		$id = (int) $wpdb->insert_id;

		// A fee plan is something a family buys, so it gets a StoreEngine
		// product: monthly plans as a subscription, one-offs as a single sale.
		$ids = \AcademyProCampus\Billing::sync_plan(
			array_merge( $data, array( 'id' => $id ) ),
			(int) $request->get_param( 'product_id' )
		);

		return rest_ensure_response( array_merge( array( 'id' => $id ), $ids ) );
	}

	public function update_item( $request ) {
		global $wpdb;
		$table = Helper::fee_plans_table();
		$data = $this->payload( $request );
		$id   = (int) $request['id'];
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->update( $table, $data, array( 'id' => $id ) );

		$ids = \AcademyProCampus\Billing::sync_plan(
			array_merge( $data, array( 'id' => $id ) ),
			(int) $request->get_param( 'product_id' )
		);

		return rest_ensure_response( array_merge( array(
			'updated' => true,
			'id' => $id
		), $ids ) );
	}

	public function delete_item( $request ) {
		global $wpdb;
		$table = Helper::fee_plans_table();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->delete( $table, array( 'id' => (int) $request['id'] ) );
		return rest_ensure_response( array(
			'deleted' => true,
			'id' => (int) $request['id']
		) );
	}
}
