<?php
namespace AcademyProCampus\API;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AcademyProCampus\Helper;
use WP_Error;

/**
 * Exam timetable + admit cards.
 *
 * Route: academy/v1/sis/exam-schedule
 * academy/v1/sis/admit-card
 */
class ExamSchedule extends \WP_REST_Controller {

	public static function init() {
		$self            = new self();
		$self->namespace = ACADEMY_DIGITAL_CAMPUS_PLUGIN_SLUG . '/v1';
		add_action( 'rest_api_init', array( $self, 'register_routes' ) );
	}

	public function register_routes() {
		register_rest_route( $this->namespace, '/sis/exam-schedule', array(
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_items' ),
				'permission_callback' => array( 'AcademyProCampus\\Helper', 'manager_check' ),
			),
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'save_item' ),
				'permission_callback' => array( 'AcademyProCampus\\Helper', 'manager_check' ),
			),
		) );
		register_rest_route( $this->namespace, '/sis/exam-schedule/(?P<id>\d+)', array(
			array(
				'methods'             => \WP_REST_Server::DELETABLE,
				'callback'            => array( $this, 'delete_item' ),
				'permission_callback' => array( 'AcademyProCampus\\Helper', 'manager_check' ),
			),
		) );
		register_rest_route( $this->namespace, '/sis/exam-schedule-summary', array(
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'summary' ),
				'permission_callback' => array( 'AcademyProCampus\\Helper', 'manager_check' ),
			),
		) );
		register_rest_route( $this->namespace, '/sis/admit-card', array(
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'admit_card' ),
				'permission_callback' => array( $this, 'view_check' ),
			),
		) );
	}

	public function view_check( $request ) {
		$student_id = (int) $request->get_param( 'student_id' );
		if ( $student_id && class_exists( '\AcademyDigitalCampus\Helper' ) && \AcademyDigitalCampus\Helper::current_user_can_view_student( $student_id ) ) {
			return true;
		}
		return Helper::manager_check();
	}

	private function rows_for_exam( $exam_id ) {
		global $wpdb;
		$table = Helper::exam_schedule_table();
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE exam_id = %d ORDER BY exam_date, start_time", $exam_id ), ARRAY_A );
		return array_map( function ( $r ) {
			$r['subject_name'] = get_the_title( (int) $r['subject_id'] );
			$inv               = ! empty( $r['invigilator_id'] ) ? get_user_by( 'id', (int) $r['invigilator_id'] ) : null;
			$r['invigilator_name'] = $inv ? $inv->display_name : '';
			return $r;
		}, $rows ? $rows : array() );
	}

	public function get_items( $request ) {
		$exam_id = (int) $request->get_param( 'exam_id' );
		if ( ! $exam_id ) {
			return rest_ensure_response( array() );
		}
		return rest_ensure_response( $this->rows_for_exam( $exam_id ) );
	}

	/** Scheduled-subject count per exam (subjects with a date) for the list view. */
	public function summary() {
		global $wpdb;
		$table = Helper::exam_schedule_table();
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results( "SELECT exam_id, COUNT(id) AS total FROM {$table} WHERE exam_date IS NOT NULL GROUP BY exam_id", ARRAY_A );
		$map = array();
		foreach ( (array) $rows as $r ) {
			$map[ (int) $r['exam_id'] ] = (int) $r['total'];
		}
		return rest_ensure_response( (object) $map );
	}

	public function save_item( $request ) {
		global $wpdb;
		$table      = Helper::exam_schedule_table();
		$exam_id    = (int) $request->get_param( 'exam_id' );
		$subject_id = (int) $request->get_param( 'subject_id' );
		if ( ! $exam_id || ! $subject_id ) {
			return new WP_Error( 'invalid', __( 'An exam and subject are required.', 'academy-pro' ), array( 'status' => 400 ) );
		}
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$existing = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE exam_id = %d AND subject_id = %d", $exam_id, $subject_id ) );
		$data = array(
			'exam_id'        => $exam_id,
			'subject_id'     => $subject_id,
			'exam_date'      => sanitize_text_field( (string) $request->get_param( 'exam_date' ) ) ? sanitize_text_field( (string) $request->get_param( 'exam_date' ) ) : null,
			'start_time'     => sanitize_text_field( (string) $request->get_param( 'start_time' ) ),
			'end_time'       => sanitize_text_field( (string) $request->get_param( 'end_time' ) ),
			'room'           => sanitize_text_field( (string) $request->get_param( 'room' ) ),
			'invigilator_id' => (int) $request->get_param( 'invigilator_id' ) ? (int) $request->get_param( 'invigilator_id' ) : null,
		);
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		if ( $existing ) {
			$wpdb->update( $table, $data, array( 'id' => (int) $existing ) );
			$id = (int) $existing;
		} else {
			$wpdb->insert( $table, $data );
			$id = (int) $wpdb->insert_id;
		}
		// phpcs:enable
		return rest_ensure_response( array( 'id' => $id ) );
	}

	public function delete_item( $request ) {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->delete( Helper::exam_schedule_table(), array( 'id' => (int) $request['id'] ) );
		return rest_ensure_response( array( 'deleted' => true ) );
	}

	public function admit_card( $request ) {
		$student_id = (int) $request->get_param( 'student_id' );
		$exam_id    = (int) $request->get_param( 'exam_id' );
		$student    = get_user_by( 'id', $student_id );
		$admission  = class_exists( '\AcademyDigitalCampus\Helper' ) ? \AcademyDigitalCampus\Helper::get_student_admission( $student_id ) : null;

		return rest_ensure_response( array(
			'student'  => array(
				'name'         => $student ? $student->display_name : '',
				'admission_no' => $admission['admission_no'] ?? '',
				'roll_no'      => $admission['roll_no'] ?? '',
				'class'        => ! empty( $admission['class_id'] ) ? get_the_title( (int) $admission['class_id'] ) : '',
			),
			'exam'     => array( 'title' => get_the_title( $exam_id ) ),
			'schedule' => $this->rows_for_exam( $exam_id ),
		) );
	}
}
