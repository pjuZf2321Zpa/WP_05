<?php
namespace AcademyProCampus\API;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AcademyProCampus\Helper;
use WP_Error;

/**
 * The teacher's own view of the campus, from the front-end dashboard.
 *
 * A teacher has no `manage_adc_sis`, so every campus endpoint refused them and
 * the dashboard could only ever show an empty page. These answer a teacher's
 * questions — when do I teach, and who is in front of me — and each is gated on
 * whether this teacher actually teaches that section, not on being an admin.
 *
 * academy-digital-campus/v1/sis/teacher/*
 */
class Teacher extends \WP_REST_Controller {

	public static function init() {
		$self            = new self();
		$self->namespace = ACADEMY_DIGITAL_CAMPUS_PLUGIN_SLUG . '/v1';
		add_action( 'rest_api_init', array( $self, 'register_routes' ) );
	}

	public function register_routes() {
		register_rest_route( $this->namespace, '/sis/teacher/timetable', array(
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_timetable' ),
				'permission_callback' => array( $this, 'is_teacher' ),
			),
		) );

		register_rest_route( $this->namespace, '/sis/teacher/sections', array(
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_sections' ),
				'permission_callback' => array( $this, 'is_teacher' ),
			),
		) );

		// The exams a teacher's classes face, and the marks they enter.
		register_rest_route( $this->namespace, '/sis/teacher/exams', array(
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_exams' ),
				'permission_callback' => array( $this, 'is_teacher' ),
			),
		) );

		register_rest_route( $this->namespace, '/sis/teacher/marks', array(
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_marks' ),
				'permission_callback' => array( $this, 'teaches_requested_section' ),
			),
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'save_marks' ),
				'permission_callback' => array( $this, 'teaches_requested_section' ),
			),
		) );

		// Who is in the room, and how to reach their family.
		register_rest_route( $this->namespace, '/sis/teacher/students', array(
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_students' ),
				'permission_callback' => array( $this, 'teaches_requested_section' ),
			),
		) );

		// The month's register, per student.
		register_rest_route( $this->namespace, '/sis/teacher/attendance-history', array(
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_attendance_history' ),
				'permission_callback' => array( $this, 'teaches_requested_section' ),
			),
		) );

		// What a teacher observed, and what the class needs to be told.
		register_rest_route( $this->namespace, '/sis/teacher/behavior', array(
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'add_behavior' ),
				'permission_callback' => array( $this, 'teaches_requested_section' ),
			),
		) );

		register_rest_route( $this->namespace, '/sis/teacher/notice', array(
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'add_notice' ),
				'permission_callback' => array( $this, 'teaches_requested_section' ),
			),
		) );

		register_rest_route( $this->namespace, '/sis/teacher/attendance', array(
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_attendance' ),
				'permission_callback' => array( $this, 'teaches_requested_section' ),
			),
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'save_attendance' ),
				'permission_callback' => array( $this, 'teaches_requested_section' ),
			),
		) );
	}

	/** Anyone who teaches here. Admins and registrars qualify too. */
	public function is_teacher() {
		if ( ! is_user_logged_in() ) {
			return false;
		}
		return current_user_can( 'manage_adc_sis' ) || in_array( 'academy_instructor', (array) wp_get_current_user()->roles, true );
	}

	/**
	 * …and specifically teaches the section being asked about.
	 *
	 * @param \WP_REST_Request $request
	 */
	public function teaches_requested_section( $request ) {
		if ( ! $this->is_teacher() ) {
			return false;
		}
		$section_id = (int) $request->get_param( 'section_id' );
		if ( ! $section_id ) {
			return new WP_Error( 'invalid', __( 'Choose a section first.', 'academy-pro' ), array( 'status' => 400 ) );
		}
		if ( current_user_can( 'manage_adc_sis' ) ) {
			return true;
		}
		return in_array( $section_id, wp_list_pluck( $this->sections_of( get_current_user_id() ), 'id' ), true );
	}

	/**
	 * The week as this teacher sees it.
	 *
	 * A teacher's routine is the class routine read from the other end: the
	 * school builds one timetable per section, and a teacher's own week is
	 * every period in it that lands on them. A period lands on them either
	 * because the slot names them outright (an override — a substitute, a split
	 * section) or, far more often, because the class assigned them that subject
	 * and nobody overrode it. Both are collected here; without the second the
	 * page stays empty on a school that never re-picked a teacher per period.
	 *
	 * @param \WP_REST_Request $request
	 */
	public function get_timetable( $request ) {
		global $wpdb;
		$teacher_id = get_current_user_id();
		$table      = Helper::timetable_table();

		// Periods the routine hands this teacher by name.
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- only $wpdb-prefixed table names, whitelisted columns and intval/placeholder lists are interpolated; values are prepared
		$rows = (array) $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM {$table} WHERE teacher_id = %d",
			$teacher_id
		), ARRAY_A );
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		// …plus the periods that fall to them through the subject assignment.
		// Keyed by slot id, so a slot found both ways is only counted once.
		$by_id = array();
		foreach ( $rows as $row ) {
			$by_id[ (int) $row['id'] ] = $row;
		}
		foreach ( $this->assigned_slots( $teacher_id ) as $row ) {
			$by_id[ (int) $row['id'] ] = $row;
		}

		$out = array_map( function ( $row ) {
			$section_id = (int) $row['section_id'];
			$class_id   = (int) get_post_meta( $section_id, 'adc_section_class_id', true );
			return array(
				'weekday'    => (int) $row['weekday'],
				'period_no'  => (int) $row['period_no'],
				'section_id' => $section_id,
				'section'    => get_the_title( $section_id ),
				'class'      => $class_id ? get_the_title( $class_id ) : '',
				'subject'    => $row['subject_id'] ? get_the_title( (int) $row['subject_id'] ) : '',
				'subject_id' => (int) $row['subject_id'],
				'room'       => (string) $row['room'],
				'start_time' => (string) $row['start_time'],
				'end_time'   => (string) $row['end_time'],
			);
		}, array_values( $by_id ) );

		usort( $out, function ( $a, $b ) {
			return array( $a['weekday'], $a['period_no'] ) <=> array( $b['weekday'], $b['period_no'] );
		} );

		return rest_ensure_response( $out );
	}

	/**
	 * Slots a teacher gets from the per-class subject assignments — the class
	 * teaches subject X, X is assigned to them, and the slot itself names
	 * nobody else.
	 *
	 * @param int $teacher_id User id.
	 * @return array<int,array> Raw timetable rows.
	 */
	private function assigned_slots( $teacher_id ) {
		if ( ! class_exists( '\AcademyDigitalCampus\Helper' ) ) {
			return array();
		}
		global $wpdb;
		$table = Helper::timetable_table();
		$out   = array();

		foreach ( \AcademyDigitalCampus\Helper::teacher_class_subjects( $teacher_id ) as $class_id => $subject_ids ) {
			$section_ids = \AcademyDigitalCampus\Helper::sections_of_class( $class_id );
			if ( ! $section_ids || ! $subject_ids ) {
				continue;
			}
			$sections    = implode( ',', array_map( 'intval', $section_ids ) );
			$subjects    = implode( ',', array_map( 'intval', $subject_ids ) );
			// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- only $wpdb-prefixed table names, whitelisted columns and intval/placeholder lists are interpolated; values are prepared
			$rows = $wpdb->get_results(
				"SELECT * FROM {$table}
				 WHERE section_id IN ({$sections}) AND subject_id IN ({$subjects})
				   AND ( teacher_id = 0 OR teacher_id IS NULL )",
				ARRAY_A
			);
			// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			foreach ( (array) $rows as $row ) {
				$out[] = $row;
			}
		}
		return $out;
	}

	/**
	 * The sections this teacher can mark attendance for. Campus staff can mark
	 * any register — they already can from the admin — so they see them all.
	 */
	public function get_sections() {
		if ( current_user_can( 'manage_adc_sis' ) ) {
			return rest_ensure_response( $this->all_sections() );
		}
		return rest_ensure_response( $this->sections_of( get_current_user_id() ) );
	}

	/**
	 * Today's register for one section: the roster, with anything already marked.
	 *
	 * @param \WP_REST_Request $request
	 */
	public function get_attendance( $request ) {
		global $wpdb;
		$section_id = (int) $request->get_param( 'section_id' );
		$subject_id = (int) $request->get_param( 'subject_id' );
		$att_date   = sanitize_text_field( (string) $request->get_param( 'att_date' ) ) ? sanitize_text_field( (string) $request->get_param( 'att_date' ) ) : gmdate( 'Y-m-d' );

		$roster = $this->roster( $section_id );
		$marked = array();

		if ( $roster ) {
			$table = Helper::attendance_table();
			$in    = implode( ',', array_map( 'intval', $roster ) );
			// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- only $wpdb-prefixed table names, whitelisted columns and intval/placeholder lists are interpolated; values are prepared
			$rows = $wpdb->get_results( $wpdb->prepare(
				"SELECT student_id, status FROM {$table} WHERE student_id IN ({$in}) AND subject_id = %d AND att_date = %s",
				$subject_id,
				$att_date
			), ARRAY_A );
			// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			foreach ( (array) $rows as $row ) {
				$marked[ (int) $row['student_id'] ] = $row['status'];
			}
		}

		$students = array();
		foreach ( $roster as $student_id ) {
			$user       = get_user_by( 'id', $student_id );
			$admission  = class_exists( '\AcademyDigitalCampus\Helper' )
				? \AcademyDigitalCampus\Helper::get_student_admission( $student_id )
				: array();
			$students[] = array(
				'student_id' => $student_id,
				'name'       => $user ? $user->display_name : '',
				'roll_no'    => (string) ( $admission['roll_no'] ?? '' ),
				'status'     => $marked[ $student_id ] ?? '',
			);
		}

		return rest_ensure_response( array(
			'att_date' => $att_date,
			'marked'   => ! empty( $marked ),
			'students' => $students,
		) );
	}

	/**
	 * Save the register. Marking twice updates rather than duplicates.
	 *
	 * @param \WP_REST_Request $request
	 */
	public function save_attendance( $request ) {
		global $wpdb;
		$section_id = (int) $request->get_param( 'section_id' );
		$subject_id = (int) $request->get_param( 'subject_id' );
		$att_date   = sanitize_text_field( (string) $request->get_param( 'att_date' ) ) ? sanitize_text_field( (string) $request->get_param( 'att_date' ) ) : gmdate( 'Y-m-d' );
		$records    = (array) $request->get_param( 'records' );

		if ( ! $records ) {
			return new WP_Error( 'invalid', __( 'Nothing to save.', 'academy-pro' ), array( 'status' => 400 ) );
		}

		$roster = $this->roster( $section_id );
		$table  = Helper::attendance_table();
		$saved  = 0;

		foreach ( $records as $record ) {
			$student_id = (int) ( $record['student_id'] ?? 0 );
			// A teacher may only mark the students actually in front of them.
			if ( ! $student_id || ! in_array( $student_id, $roster, true ) ) {
				continue;
			}
			$status = in_array( ( $record['status'] ?? '' ), array( 'present', 'absent', 'late', 'leave' ), true )
				? $record['status']
				: 'present';

			// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$existing = $wpdb->get_var( $wpdb->prepare(
				"SELECT id FROM {$table} WHERE student_id = %d AND subject_id = %d AND att_date = %s",
				$student_id,
				$subject_id,
				$att_date
			) );
			if ( $existing ) {
				$wpdb->update( $table, array(
					'status' => $status,
					'marked_by' => get_current_user_id()
				), array( 'id' => (int) $existing ) );
			} else {
				$wpdb->insert( $table, array(
					'section_id' => $section_id,
					'subject_id' => $subject_id,
					'student_id' => $student_id,
					'att_date'   => $att_date,
					'status'     => $status,
					'marked_by'  => get_current_user_id(),
				) );
			}
			// phpcs:enable
			++$saved;
		}//end foreach

		Helper::audit( 'attendance', $section_id, 'marked', $att_date );

		return rest_ensure_response( array(
			'saved' => $saved,
			'att_date' => $att_date
		) );
	}

	/**
	 * The exams facing the classes this teacher takes.
	 *
	 * @param \WP_REST_Request $request
	 */
	public function get_exams( $request ) {
		$section_id = (int) $request->get_param( 'section_id' );
		$class_ids  = array();

		if ( $section_id ) {
			$class_ids[] = (int) get_post_meta( $section_id, 'adc_section_class_id', true );
		} else {
			foreach ( $this->sections_of( get_current_user_id() ) as $section ) {
				$class_ids[] = (int) get_post_meta( $section['id'], 'adc_section_class_id', true );
			}
		}
		$class_ids = array_values( array_filter( array_unique( $class_ids ) ) );
		if ( ! $class_ids ) {
			return rest_ensure_response( array() );
		}

		$exams = get_posts( array(
			'post_type'      => 'adc_exam',
			'post_status'    => 'publish',
			'posts_per_page' => 50,
			'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
				array(
					'key'     => 'adc_exam_class_id',
					'value'   => $class_ids,
					'compare' => 'IN',
				),
			),
		) );

		return rest_ensure_response( array_map( function ( $exam ) {
			$class_id = (int) get_post_meta( $exam->ID, 'adc_exam_class_id', true );
			return array(
				'id'          => (int) $exam->ID,
				'name'        => $exam->post_title,
				'class_id'    => $class_id,
				'class'       => $class_id ? get_the_title( $class_id ) : '',
				'total_marks' => (float) get_post_meta( $exam->ID, 'adc_exam_total_marks', true ),
				'pass_marks'  => (float) get_post_meta( $exam->ID, 'adc_exam_pass_marks', true ),
				'subjects'    => $this->subjects_of_class( $class_id ),
			);
		}, $exams ) );
	}

	/**
	 * The mark sheet for one exam and subject.
	 *
	 * @param \WP_REST_Request $request
	 */
	public function get_marks( $request ) {
		global $wpdb;
		$exam_id    = (int) $request->get_param( 'exam_id' );
		$subject_id = (int) $request->get_param( 'subject_id' );
		$section_id = (int) $request->get_param( 'section_id' );
		if ( ! $exam_id || ! $subject_id ) {
			return new WP_Error( 'invalid', __( 'Choose an exam and a subject.', 'academy-pro' ), array( 'status' => 400 ) );
		}

		$roster = $this->roster( $section_id );
		$table  = Helper::exam_results_table();
		$marks  = array();

		if ( $roster ) {
			$in = implode( ',', array_map( 'intval', $roster ) );
			// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- only $wpdb-prefixed table names, whitelisted columns and intval/placeholder lists are interpolated; values are prepared
			$rows = $wpdb->get_results( $wpdb->prepare(
				"SELECT student_id, obtained_marks, total_marks, remarks FROM {$table}
				 WHERE exam_id = %d AND subject_id = %d AND student_id IN ({$in})",
				$exam_id,
				$subject_id
			), ARRAY_A );
			// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			foreach ( (array) $rows as $row ) {
				$marks[ (int) $row['student_id'] ] = $row;
			}
		}

		$total = (float) get_post_meta( $exam_id, 'adc_exam_total_marks', true );
		$out   = array();
		foreach ( $roster as $student_id ) {
			$user  = get_user_by( 'id', $student_id );
			$mark  = $marks[ $student_id ] ?? null;
			$out[] = array(
				'student_id' => $student_id,
				'name'       => $user ? $user->display_name : '',
				'obtained'   => $mark ? (float) $mark['obtained_marks'] : '',
				'remarks'    => $mark ? (string) $mark['remarks'] : '',
			);
		}

		return rest_ensure_response( array(
			'total_marks' => $total,
			'students' => $out
		) );
	}

	/**
	 * Save the mark sheet. Re-entering a mark corrects it.
	 *
	 * @param \WP_REST_Request $request
	 */
	public function save_marks( $request ) {
		global $wpdb;
		$exam_id    = (int) $request->get_param( 'exam_id' );
		$subject_id = (int) $request->get_param( 'subject_id' );
		$section_id = (int) $request->get_param( 'section_id' );
		$records    = (array) $request->get_param( 'records' );
		if ( ! $exam_id || ! $subject_id || ! $records ) {
			return new WP_Error( 'invalid', __( 'Nothing to save.', 'academy-pro' ), array( 'status' => 400 ) );
		}

		$roster = $this->roster( $section_id );
		$table  = Helper::exam_results_table();
		$total  = (float) get_post_meta( $exam_id, 'adc_exam_total_marks', true );
		$saved  = 0;

		foreach ( $records as $record ) {
			$student_id = (int) ( $record['student_id'] ?? 0 );
			if ( ! $student_id || ! in_array( $student_id, $roster, true ) ) {
				continue;
			}
			// An empty box means "not marked yet", not a zero.
			if ( '' === ( $record['obtained'] ?? '' ) || null === ( $record['obtained'] ?? null ) ) {
				continue;
			}
			$obtained = min( max( 0, (float) $record['obtained'] ), $total ? $total : (float) $record['obtained'] );
			$remarks  = sanitize_text_field( (string) ( $record['remarks'] ?? '' ) );

			// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$existing = $wpdb->get_var( $wpdb->prepare(
				"SELECT id FROM {$table} WHERE exam_id = %d AND subject_id = %d AND student_id = %d",
				$exam_id,
				$subject_id,
				$student_id
			) );
			$payload = array(
				'obtained_marks' => $obtained,
				'total_marks'    => $total,
				'remarks'        => $remarks,
				'entered_by'     => get_current_user_id(),
			);
			if ( $existing ) {
				$wpdb->update( $table, $payload, array( 'id' => (int) $existing ) );
			} else {
				$wpdb->insert( $table, array_merge( $payload, array(
					'exam_id'    => $exam_id,
					'subject_id' => $subject_id,
					'student_id' => $student_id,
				) ) );
			}
			// phpcs:enable
			++$saved;
		}//end foreach

		Helper::audit( 'exam', $exam_id, 'marks entered', (string) $saved );
		return rest_ensure_response( array( 'saved' => $saved ) );
	}

	/**
	 * The class list, with the family behind each student.
	 *
	 * @param \WP_REST_Request $request
	 */
	public function get_students( $request ) {
		$section_id = (int) $request->get_param( 'section_id' );
		$out        = array();

		foreach ( $this->roster( $section_id ) as $student_id ) {
			$user      = get_user_by( 'id', $student_id );
			$admission = class_exists( '\AcademyDigitalCampus\Helper' )
				? \AcademyDigitalCampus\Helper::get_student_admission( $student_id )
				: array();

			$guardians = array();
			if ( class_exists( '\AcademyDigitalCampus\Helper' ) ) {
				foreach ( (array) \AcademyDigitalCampus\Helper::get_parent_ids( $student_id ) as $parent_id ) {
					$parent = get_user_by( 'id', (int) $parent_id );
					if ( $parent ) {
						$guardians[] = array(
							'name'  => $parent->display_name,
							'email' => $parent->user_email,
							'phone' => (string) get_user_meta( $parent->ID, 'adc_phone', true ),
						);
					}
				}
			}

			$out[] = array(
				'student_id'   => $student_id,
				'name'         => $user ? $user->display_name : '',
				'email'        => $user ? $user->user_email : '',
				'roll_no'      => (string) ( $admission['roll_no'] ?? '' ),
				'admission_no' => (string) ( $admission['admission_no'] ?? '' ),
				'guardians'    => $guardians,
			);
		}//end foreach

		return rest_ensure_response( $out );
	}

	/**
	 * How the section has attended over a month.
	 *
	 * @param \WP_REST_Request $request
	 */
	public function get_attendance_history( $request ) {
		global $wpdb;
		$section_id = (int) $request->get_param( 'section_id' );
		$month      = sanitize_text_field( (string) $request->get_param( 'month' ) );
		$from       = preg_match( '/^\d{4}-\d{2}$/', $month ) ? $month . '-01' : gmdate( 'Y-m-01' );
		$to         = gmdate( 'Y-m-t', strtotime( $from ) );

		$roster = $this->roster( $section_id );
		if ( ! $roster ) {
			return rest_ensure_response( array(
				'month' => gmdate( 'Y-m', strtotime( $from ) ),
				'students' => array()
			) );
		}

		$table = Helper::attendance_table();
		$in    = implode( ',', array_map( 'intval', $roster ) );
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- only $wpdb-prefixed table names, whitelisted columns and intval/placeholder lists are interpolated; values are prepared
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT student_id, status, COUNT(*) AS total FROM {$table}
			 WHERE student_id IN ({$in}) AND att_date BETWEEN %s AND %s
			 GROUP BY student_id, status",
			$from,
			$to
		), ARRAY_A );
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		$tally = array();
		foreach ( (array) $rows as $row ) {
			$tally[ (int) $row['student_id'] ][ $row['status'] ] = (int) $row['total'];
		}

		$out = array();
		foreach ( $roster as $student_id ) {
			$counts  = $tally[ $student_id ] ?? array();
			$marked  = array_sum( $counts );
			$present = ( $counts['present'] ?? 0 ) + ( $counts['late'] ?? 0 );
			$user    = get_user_by( 'id', $student_id );
			$out[]   = array(
				'student_id' => $student_id,
				'name'       => $user ? $user->display_name : '',
				'present'    => $counts['present'] ?? 0,
				'absent'     => $counts['absent'] ?? 0,
				'late'       => $counts['late'] ?? 0,
				'leave'      => $counts['leave'] ?? 0,
				'percentage' => $marked ? round( ( $present / $marked ) * 100, 1 ) : null,
			);
		}

		return rest_ensure_response( array(
			'month' => gmdate( 'Y-m', strtotime( $from ) ),
			'students' => $out
		) );
	}

	/**
	 * Record something a teacher saw.
	 *
	 * @param \WP_REST_Request $request
	 */
	public function add_behavior( $request ) {
		global $wpdb;
		$section_id = (int) $request->get_param( 'section_id' );
		$student_id = (int) $request->get_param( 'student_id' );
		if ( ! in_array( $student_id, $this->roster( $section_id ), true ) ) {
			return new WP_Error( 'invalid', __( 'That student isn’t in this section.', 'academy-pro' ), array( 'status' => 400 ) );
		}

		$description = sanitize_textarea_field( (string) $request->get_param( 'description' ) );
		if ( '' === $description ) {
			return new WP_Error( 'invalid', __( 'Describe what happened.', 'academy-pro' ), array( 'status' => 400 ) );
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->insert( Helper::behavior_table(), array(
			'student_id'    => $student_id,
			'class_id'      => (int) get_post_meta( $section_id, 'adc_section_class_id', true ),
			'section_id'    => $section_id,
			'incident_date' => gmdate( 'Y-m-d' ),
			'type'          => sanitize_text_field( (string) ( $request->get_param( 'type' ) ? $request->get_param( 'type' ) : 'note' ) ),
			'severity'      => in_array( $request->get_param( 'severity' ), array( 'low', 'medium', 'high' ), true )
				? $request->get_param( 'severity' )
				: 'low',
			'description'   => $description,
			'created_by'    => get_current_user_id(),
		) );

		return rest_ensure_response( array( 'id' => (int) $wpdb->insert_id ) );
	}

	/**
	 * Tell the section something.
	 *
	 * @param \WP_REST_Request $request
	 */
	public function add_notice( $request ) {
		global $wpdb;
		$section_id = (int) $request->get_param( 'section_id' );
		$title      = sanitize_text_field( (string) $request->get_param( 'title' ) );
		$body       = wp_kses_post( (string) $request->get_param( 'body' ) );
		if ( '' === $title ) {
			return new WP_Error( 'invalid', __( 'Give the notice a title.', 'academy-pro' ), array( 'status' => 400 ) );
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->insert( Helper::notices_table(), array(
			'title'      => $title,
			'body'       => $body,
			// A teacher speaks to their own section, never the whole school.
			'audience'   => 'section',
			'target_id'  => $section_id,
			'created_by' => get_current_user_id(),
			'status'     => 'published',
		) );
		$notice_id = (int) $wpdb->insert_id;

		do_action( 'academy_digital_campus/notice_published', $notice_id, 'section' );

		return rest_ensure_response( array( 'id' => $notice_id ) );
	}

	/**
	 * Subjects taught in a class, for the marks picker.
	 *
	 * @param int $class_id
	 */
	private function subjects_of_class( $class_id ) {
		if ( ! $class_id || ! class_exists( '\AcademyDigitalCampus\Helper' ) ) {
			return array();
		}
		$out = array();
		foreach ( (array) \AcademyDigitalCampus\Helper::subjects_for_class( (int) $class_id ) as $subject ) {
			$id = (int) ( $subject['id'] ?? 0 );
			if ( $id ) {
				$out[] = array(
					'id' => $id,
					'name' => (string) ( $subject['name'] ?? get_the_title( $id ) )
				);
			}
		}
		return $out;
	}

	/**
	 * Sections a teacher is responsible for.
	 *
	 * @param int $teacher_id
	 */
	private function sections_of( $teacher_id ) {
		return Helper::teacher_sections( $teacher_id );
	}

	/** Every section, for staff who may mark any of them. */
	private function all_sections() {
		return Helper::all_sections();
	}

	/**
	 * Enrolled students of a section.
	 *
	 * @param int $section_id
	 */
	private function roster( $section_id ) {
		return Helper::section_roster( $section_id );
	}
}
