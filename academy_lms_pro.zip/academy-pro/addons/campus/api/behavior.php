<?php
namespace AcademyProCampus\API;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AcademyProCampus\Helper;
use AcademyProCampus\Notifier;
use WP_Error;

/**
 * Student behaviour / discipline alerts, with optional parent notification.
 *
 * Route: academy-digital-campus/v1/sis/behavior          (manager CRUD)
 * academy-digital-campus/v1/sis/behavior/{id}     (delete)
 */
class Behavior extends \WP_REST_Controller {

	public static function init() {
		$self            = new self();
		$self->namespace = ACADEMY_DIGITAL_CAMPUS_PLUGIN_SLUG . '/v1';
		add_action( 'rest_api_init', array( $self, 'register_routes' ) );
	}

	public function register_routes() {
		register_rest_route( $this->namespace, '/sis/behavior', array(
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_items' ),
				'permission_callback' => array( $this, 'view_check' ),
			),
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'create_item' ),
				'permission_callback' => array( 'AcademyProCampus\\Helper', 'manager_check' ),
			),
		) );
		register_rest_route( $this->namespace, '/sis/behavior/(?P<id>\d+)', array(
			array(
				'methods'             => \WP_REST_Server::EDITABLE,
				'callback'            => array( $this, 'update_item' ),
				'permission_callback' => array( 'AcademyProCampus\\Helper', 'manager_check' ),
			),
			array(
				'methods'             => \WP_REST_Server::DELETABLE,
				'callback'            => array( $this, 'delete_item' ),
				'permission_callback' => array( 'AcademyProCampus\\Helper', 'manager_check' ),
			),
		) );
	}

	/**
	 * Managers see all; a student/parent may read their own / their child's log.
	 *
	 * @param \WP_REST_Request $request
	 */
	public function view_check( $request ) {
		$student_id = (int) $request->get_param( 'student_id' );
		if ( $student_id && class_exists( '\AcademyDigitalCampus\Helper' ) && \AcademyDigitalCampus\Helper::current_user_can_view_student( $student_id ) ) {
			return true;
		}
		return Helper::manager_check();
	}

	public function get_items( $request ) {
		global $wpdb;
		$table = Helper::behavior_table();
		$where  = '1=1';
		$params = array();
		$student_id = (int) $request->get_param( 'student_id' );
		if ( $student_id ) {
			$where   .= ' AND student_id = %d';
			$params[] = $student_id;
		}
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- only $wpdb-prefixed table names, whitelisted columns and intval/placeholder lists are interpolated; values are prepared
		$rows = $wpdb->get_results( $params
			? $wpdb->prepare( "SELECT * FROM {$table} WHERE {$where} ORDER BY id DESC LIMIT 300", $params )
		: "SELECT * FROM {$table} WHERE {$where} ORDER BY id DESC LIMIT 300", ARRAY_A );
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber
		$rows = array_map( function ( $r ) {
			$student = get_user_by( 'id', (int) $r['student_id'] );
			$r['student_name'] = $student ? $student->display_name : '';
			$r['class_name']   = $r['class_id'] ? get_the_title( (int) $r['class_id'] ) : '';
			return $r;
		}, $rows ? $rows : array() );
		return rest_ensure_response( $rows );
	}

	public function create_item( $request ) {
		global $wpdb;
		$table      = Helper::behavior_table();
		$student_id = (int) $request->get_param( 'student_id' );
		if ( ! $student_id ) {
			return new WP_Error( 'invalid', __( 'A student is required.', 'academy-pro' ), array( 'status' => 400 ) );
		}
		$severity = in_array( $request->get_param( 'severity' ), array( 'low', 'medium', 'high' ), true )
			? $request->get_param( 'severity' ) : 'low';

		$data = array(
			'student_id'       => $student_id,
			'class_id'         => (int) $request->get_param( 'class_id' ),
			'section_id'       => (int) $request->get_param( 'section_id' ),
			'incident_date'    => sanitize_text_field( (string) $request->get_param( 'incident_date' ) ) ? sanitize_text_field( (string) $request->get_param( 'incident_date' ) ) : current_time( 'Y-m-d' ),
			'type'             => sanitize_text_field( (string) $request->get_param( 'type' ) ),
			'severity'         => $severity,
			'description'      => sanitize_textarea_field( (string) $request->get_param( 'description' ) ),
			'action_taken'     => sanitize_textarea_field( (string) $request->get_param( 'action_taken' ) ),
			'follow_up_status' => 'open',
			'created_by'       => get_current_user_id(),
		);

		$notify = (bool) $request->get_param( 'notify_parent' );
		$data['parent_notified'] = $notify ? 1 : 0;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->insert( $table, $data );
		$id = (int) $wpdb->insert_id;
		Helper::audit( 'behavior', $id, 'created', $data['type'] );

		if ( $notify ) {
			$student = get_user_by( 'id', $student_id );
			$name    = $student ? $student->display_name : __( 'Your child', 'academy-pro' );
			/* translators: 1: student name, 2: incident type */
			$subject = sprintf( __( 'Behaviour alert for %s', 'academy-pro' ), $name );
			$message = sprintf(
				/* translators: 1: student name, 2: date, 3: type, 4: severity, 5: description */
				__( "Dear guardian,\n\nA behaviour note has been recorded for %1\$s on %2\$s.\nType: %3\$s (%4\$s severity)\nDetails: %5\$s\n\nPlease contact the school for more information.", 'academy-pro' ),
				$name,
				$data['incident_date'],
				$data['type'] ? $data['type'] : __( 'General', 'academy-pro' ),
				$severity,
				$data['description']
			);
			Notifier::notify_student_guardians( $student_id, $subject, $message, array( 'email', 'sms' ) );
		}

		return rest_ensure_response( array( 'id' => $id ) );
	}

	public function update_item( $request ) {
		global $wpdb;
		$table = Helper::behavior_table();
		$id    = (int) $request['id'];
		$data  = array();
		foreach ( array( 'action_taken', 'description', 'type' ) as $field ) {
			if ( null !== $request->get_param( $field ) ) {
				$data[ $field ] = sanitize_textarea_field( (string) $request->get_param( $field ) );
			}
		}
		if ( null !== $request->get_param( 'follow_up_status' ) ) {
			$data['follow_up_status'] = in_array( $request->get_param( 'follow_up_status' ), array( 'open', 'in_progress', 'resolved' ), true )
				? $request->get_param( 'follow_up_status' ) : 'open';
		}
		if ( ! $data ) {
			return rest_ensure_response( array( 'updated' => false ) );
		}
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->update( $table, $data, array( 'id' => $id ) );
		return rest_ensure_response( array(
			'updated' => true,
			'id' => $id
		) );
	}

	public function delete_item( $request ) {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->delete( Helper::behavior_table(), array( 'id' => (int) $request['id'] ) );
		return rest_ensure_response( array( 'deleted' => true ) );
	}
}
