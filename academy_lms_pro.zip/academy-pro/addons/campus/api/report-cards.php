<?php
namespace AcademyProCampus\API;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AcademyProCampus\Helper;

/**
 * Report card aggregation — the bridge that pulls a student's results together
 * from written exams, mapped quizzes and the grade-book addon.
 *
 * Route: academy/v1/sis/report-card
 */
class ReportCards extends \WP_REST_Controller {

	public static function init() {
		$self            = new self();
		$self->namespace = ACADEMY_DIGITAL_CAMPUS_PLUGIN_SLUG . '/v1';
		$self->rest_base = 'sis/report-card';
		add_action( 'rest_api_init', array( $self, 'register_routes' ) );
	}

	public function register_routes() {
		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base,
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_report_card' ),
					'permission_callback' => array( $this, 'permission_check' ),
				),
			)
		);
	}

	public function permission_check( $request ) {
		$student_id = (int) $request->get_param( 'student_id' );
		if ( class_exists( '\AcademyDigitalCampus\Helper' ) && \AcademyDigitalCampus\Helper::current_user_can_view_student( $student_id ) ) {
			return true;
		}
		return Helper::manager_check();
	}

	public function get_report_card( $request ) {
		global $wpdb;
		$student_id = (int) $request->get_param( 'student_id' );
		$exam_id    = (int) $request->get_param( 'exam_id' );
		$term_id    = (int) $request->get_param( 'term_id' );

		if ( ! $student_id ) {
			return new \WP_Error( 'invalid', __( 'A student is required.', 'academy-pro' ), array( 'status' => 400 ) );
		}

		$rows = array();

		// 1. Written exam marks.
		$table  = Helper::exam_results_table();
		$where  = 'student_id = %d';
		$params = array( $student_id );
		if ( $exam_id ) {
			$where   .= ' AND exam_id = %d';
			$params[] = $exam_id;
		}
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber
		$results = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE {$where}", $params ), ARRAY_A );

		// Students/parents only see results for exams marked published; managers
		// see everything (for review before publishing).
		$is_manager = ( true === Helper::manager_check() );
		foreach ( $results as $r ) {
			if ( ! $is_manager && ! get_post_meta( (int) $r['exam_id'], 'adc_exam_published', true ) ) {
				continue;
			}
			// Term/semester filter: keep only exams scheduled in that term.
			if ( $term_id && (int) get_post_meta( (int) $r['exam_id'], 'adc_exam_term_id', true ) !== $term_id ) {
				continue;
			}
			$rows[] = array(
				'subject'        => get_the_title( (int) $r['subject_id'] ),
				'source'         => __( 'Exam', 'academy-pro' ),
				'obtained_marks' => (float) $r['obtained_marks'],
				'total_marks'    => (float) $r['total_marks'],
				'grade'          => $r['grade'],
			);
		}

		// 2. Mapped quiz attempts (bridge to the quizzes addon). Quizzes are not
		// term-scoped, so they are omitted when a specific term is requested.
		if ( ! $term_id && Helper::is_addon_active( 'quizzes' ) ) {
			$attempts_table = $wpdb->prefix . ACADEMY_PLUGIN_SLUG . '_quiz_attempts';
			// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- only $wpdb-prefixed table names, whitelisted columns and intval/placeholder lists are interpolated; values are prepared
			$quiz_rows = $wpdb->get_results( $wpdb->prepare(
				"SELECT quiz_id, total_marks, earned_marks FROM {$attempts_table} WHERE user_id = %d AND attempt_status = %s",
				$student_id, 'attempt_ended'
			), ARRAY_A );
			// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			foreach ( (array) $quiz_rows as $q ) {
				$rows[] = array(
					'subject'        => get_the_title( (int) $q['quiz_id'] ) ? get_the_title( (int) $q['quiz_id'] ) : __( 'Quiz', 'academy-pro' ),
					'source'         => __( 'Quiz', 'academy-pro' ),
					'obtained_marks' => (float) $q['earned_marks'],
					'total_marks'    => (float) $q['total_marks'],
					'grade'          => (float) $q['total_marks'] > 0 ? Helper::grade_from_percentage( ( (float) $q['earned_marks'] / (float) $q['total_marks'] ) * 100 ) : null,
				);
			}
		}

		$total_obtained = array_sum( wp_list_pluck( $rows, 'obtained_marks' ) );
		$total_max      = array_sum( wp_list_pluck( $rows, 'total_marks' ) );
		$percentage     = $total_max > 0 ? round( ( $total_obtained / $total_max ) * 100, 2 ) : 0;

		$student = get_user_by( 'id', $student_id );

		return rest_ensure_response( array(
			'student'    => array(
				'id'    => $student_id,
				'name'  => $student ? $student->display_name : '',
				'email' => $student ? $student->user_email : '',
			),
			'rows'       => $rows,
			'summary'    => array(
				'obtained'   => $total_obtained,
				'total'      => $total_max,
				'percentage' => $percentage,
				'grade'      => Helper::grade_from_percentage( $percentage ),
				'gpa'        => Helper::grade_points( $percentage ),
			),
		) );
	}
}
