<?php
namespace AcademyProCampus\API;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AcademyProCampus\Helper;
use WP_Error;

/**
 * Timetable slots per section (weekday × period).
 *
 * Route: academy/v1/sis/timetable
 */
class Timetable extends \WP_REST_Controller {

	public static function init() {
		$self            = new self();
		$self->namespace = ACADEMY_DIGITAL_CAMPUS_PLUGIN_SLUG . '/v1';
		add_action( 'rest_api_init', array( $self, 'register_routes' ) );
	}

	public function register_routes() {
		register_rest_route( $this->namespace, '/sis/timetable', array(
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_items' ),
				'permission_callback' => array( 'AcademyProCampus\\Helper', 'manager_check' ),
			),
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'save_slot' ),
				'permission_callback' => array( 'AcademyProCampus\\Helper', 'manager_check' ),
			),
		) );
		register_rest_route( $this->namespace, '/sis/timetable/(?P<id>\d+)', array(
			array(
				'methods'             => \WP_REST_Server::DELETABLE,
				'callback'            => array( $this, 'delete_slot' ),
				'permission_callback' => array( 'AcademyProCampus\\Helper', 'manager_check' ),
			),
		) );
	}

	public function get_items( $request ) {
		global $wpdb;
		$table      = Helper::timetable_table();
		$section_id = (int) $request->get_param( 'section_id' );
		if ( ! $section_id ) {
			return rest_ensure_response( array() );
		}
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- only $wpdb-prefixed table names, whitelisted columns and intval/placeholder lists are interpolated; values are prepared
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM {$table} WHERE section_id = %d ORDER BY weekday, period_no",
			$section_id
		), ARRAY_A );
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = array_map( function ( $r ) use ( $section_id ) {
			// `teacher_id` stays the raw override (the Teacher select edits it);
			// `teacher_name` is who actually takes the period, which for most
			// slots is the teacher the class assigned the subject to.
			$teacher_id = self::effective_teacher( $section_id, (int) $r['subject_id'], (int) $r['teacher_id'] );
			$teacher    = $teacher_id ? get_user_by( 'id', $teacher_id ) : null;
			$r['subject_name']         = $r['subject_id'] ? ( get_the_title( (int) $r['subject_id'] ) ) : '';
			$r['teacher_name']         = $teacher ? $teacher->display_name : '';
			// True when the name above came from the subject assignment rather
			// than from this slot — the grid marks those as inherited.
			$r['teacher_from_subject'] = $teacher_id && ! (int) $r['teacher_id'];
			return $r;
		}, $rows ? $rows : array() );
		return rest_ensure_response( $rows );
	}

	/**
	 * Upsert a slot. An empty subject clears the slot (delete).
	 *
	 * @param \WP_REST_Request $request
	 */
	public function save_slot( $request ) {
		global $wpdb;
		$table      = Helper::timetable_table();
		$section_id = (int) $request->get_param( 'section_id' );
		$weekday    = (int) $request->get_param( 'weekday' );
		$period_no  = (int) $request->get_param( 'period_no' );
		$subject_id = (int) $request->get_param( 'subject_id' );

		if ( ! $section_id ) {
			return new WP_Error( 'invalid', __( 'A section is required.', 'academy-pro' ), array( 'status' => 400 ) );
		}

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- only $wpdb-prefixed table names, whitelisted columns and intval/placeholder lists are interpolated; values are prepared
		$existing = $wpdb->get_var( $wpdb->prepare(
			"SELECT id FROM {$table} WHERE section_id = %d AND weekday = %d AND period_no = %d",
			$section_id, $weekday, $period_no
		) );
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		if ( ! $subject_id ) {
			if ( $existing ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
				$wpdb->delete( $table, array( 'id' => (int) $existing ) );
			}
			return rest_ensure_response( array( 'cleared' => true ) );
		}

		$data = array(
			'section_id' => $section_id,
			'weekday'    => $weekday,
			'period_no'  => $period_no,
			'subject_id' => $subject_id,
			'teacher_id' => (int) $request->get_param( 'teacher_id' ),
			'room'       => sanitize_text_field( (string) $request->get_param( 'room' ) ),
			'start_time' => sanitize_text_field( (string) $request->get_param( 'start_time' ) ),
			'end_time'   => sanitize_text_field( (string) $request->get_param( 'end_time' ) ),
		);
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		if ( $existing ) {
			$wpdb->update( $table, $data, array( 'id' => (int) $existing ) );
			$id = (int) $existing;
		} else {
			$wpdb->insert( $table, $data );
			$id = (int) $wpdb->insert_id;
		}
		// phpcs:enable

		// Teacher clash within the same weekday+period across sections. Compared
		// on the *effective* teacher: most slots leave `teacher_id` empty and
		// inherit whoever the class assigned the subject to, so matching on the
		// stored column alone would miss the double-booking that matters.
		$teacher_id = self::effective_teacher( $section_id, $subject_id, $data['teacher_id'] );
		$clash      = false;
		if ( $teacher_id ) {
			// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- only $wpdb-prefixed table names, whitelisted columns and intval/placeholder lists are interpolated; values are prepared
			$others = (array) $wpdb->get_results( $wpdb->prepare(
				"SELECT section_id, subject_id, teacher_id FROM {$table} WHERE weekday = %d AND period_no = %d AND id <> %d",
				$weekday, $period_no, $id
			), ARRAY_A );
			// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			foreach ( $others as $other ) {
				if ( self::effective_teacher( (int) $other['section_id'], (int) $other['subject_id'], (int) $other['teacher_id'] ) === $teacher_id ) {
					$clash = true;
					break;
				}
			}
		}

		return rest_ensure_response( array(
			'id' => $id,
			'teacher_clash' => $clash
		) );
	}

	/**
	 * Who takes a period: the slot's own teacher when one is picked, otherwise
	 * the teacher the class assigned that subject to.
	 *
	 * @param int $section_id
	 * @param int $subject_id
	 * @param int $slot_teacher_id
	 */
	private static function effective_teacher( $section_id, $subject_id, $slot_teacher_id ) {
		if ( ! class_exists( '\AcademyDigitalCampus\Helper' ) ) {
			return (int) $slot_teacher_id;
		}
		return (int) \AcademyDigitalCampus\Helper::resolve_slot_teacher( $section_id, $subject_id, $slot_teacher_id );
	}

	public function delete_slot( $request ) {
		global $wpdb;
		$table = Helper::timetable_table();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->delete( $table, array( 'id' => (int) $request['id'] ) );
		return rest_ensure_response( array( 'deleted' => true ) );
	}
}
