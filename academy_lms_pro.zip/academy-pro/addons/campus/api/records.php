<?php
namespace AcademyProCampus\API;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AcademyProCampus\Helper;
use WP_Error;

/**
 * Generic CRUD for the facility modules (library / transport / hostel).
 * Module-specific fields are stored as JSON in `data`.
 *
 * Route: academy/v1/sis/records
 */
class Records extends \WP_REST_Controller {

	const MODULES = array(
		'library',
		'transport',
		'hostel',
		// Transaction modules: issues/returns, assignments, allocations.
		'library_issue',
		'transport_assignment',
		'hostel_allocation',
		// Registers the asset modules pick their category or block from.
		'library_category',
		'hostel_block',
	);

	/** Ceiling for a per_page=-1 request, so "everything" can't run away. */
	const MAX_ALL = 2000;

	/**
	 * Which module points at which, and under what key. Used to stop an asset
	 * being deleted while transactions still reference it.
	 */
	const DEPENDENTS = array(
		'library'            => array( array( 'library_issue', 'book_id' ) ),
		'transport'          => array( array( 'transport_assignment', 'route' ) ),
		'hostel'             => array( array( 'hostel_allocation', 'room_id' ) ),
		'library_category'   => array( array( 'library', 'category' ) ),
		'hostel_block'       => array( array( 'hostel', 'block' ) ),
	);

	/**
	 * Transaction modules that consume a finite asset. Used to refuse an
	 * allocation once the room (or vehicle) is full, and to stop two rows
	 * claiming the same bed or the same rider twice.
	 */
	const CAPACITY_RULES = array(
		'hostel_allocation' => array(
			'asset'    => 'hostel',
			'asset_key' => 'room_id',
			'capacity' => 'capacity',
			'active'   => array( 'active' ),
			'holder'   => 'student_id',
			'unique'   => 'bed',
		),
		'transport_assignment' => array(
			'asset'    => 'transport',
			'asset_key' => 'route',
			'capacity' => 'capacity',
			'active'   => array( 'active' ),
			'holder'   => 'student_id',
			'unique'   => '',
		),
	);

	public static function init() {
		$self            = new self();
		$self->namespace = ACADEMY_DIGITAL_CAMPUS_PLUGIN_SLUG . '/v1';
		add_action( 'rest_api_init', array( $self, 'register_routes' ) );
	}

	public function register_routes() {
		register_rest_route( $this->namespace, '/sis/records', array(
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_items' ),
				'permission_callback' => array( 'AcademyProCampus\\Helper', 'manager_check' ),
			),
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'save_item' ),
				'permission_callback' => array( 'AcademyProCampus\\Helper', 'manager_check' ),
			),
		) );
		register_rest_route( $this->namespace, '/sis/records/(?P<id>\d+)', array(
			array(
				'methods'             => \WP_REST_Server::DELETABLE,
				'callback'            => array( $this, 'delete_item' ),
				'permission_callback' => array( 'AcademyProCampus\\Helper', 'manager_check' ),
			),
		) );
	}

	private function module( $request ) {
		$module = sanitize_key( (string) $request->get_param( 'module' ) );
		return in_array( $module, self::MODULES, true ) ? $module : '';
	}

	/**
	 * One page of a module's records.
	 *
	 * `per_page` = -1 returns every row (capped at self::MAX_ALL) — used to
	 * populate the selects that point at another module, which need the whole
	 * list, not a page. Everything else pages, with the total in the
	 * X-WP-Total header so the table can render a pager instead of silently
	 * stopping at some cut-off.
	 *
	 * @param \WP_REST_Request $request
	 */
	public function get_items( $request ) {
		global $wpdb;
		$module = $this->module( $request );
		if ( ! $module ) {
			return new WP_Error( 'invalid', __( 'Unknown module.', 'academy-pro' ), array( 'status' => 400 ) );
		}
		$table = Helper::records_table();

		$per_page = null === $request->get_param( 'per_page' ) ? 20 : (int) $request->get_param( 'per_page' );
		$fetch_all = -1 === $per_page;
		$per_page = $fetch_all ? self::MAX_ALL : max( 1, min( 200, $per_page ) );
		$page     = max( 1, (int) $request->get_param( 'page' ) );
		$offset   = $fetch_all ? 0 : ( $page - 1 ) * $per_page;

		$where  = 'module = %s';
		$params = array( $module );

		// A campus filter shows that branch's records plus the ones that
		// belong to no branch in particular, so a shared library doesn't
		// vanish the moment a school adds a second campus.
		$campus_id = (int) $request->get_param( 'campus_id' );
		if ( $campus_id ) {
			$where   .= ' AND ( campus_id = %d OR campus_id IS NULL OR campus_id = 0 )';
			$params[] = $campus_id;
		}

		$search = trim( sanitize_text_field( (string) $request->get_param( 'search' ) ) );
		if ( '' !== $search ) {
			// The module's own fields live in `data`, so a search that only
			// looked at `title` would miss a vehicle number or an ISBN.
			$like    = '%' . $wpdb->esc_like( $search ) . '%';
			$where  .= ' AND ( title LIKE %s OR data LIKE %s )';
			$params[] = $like;
			$params[] = $like;
		}

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- placeholders are generated to match the values
		$total = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(id) FROM {$table} WHERE {$where}", $params ) );
		$rows  = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$table} WHERE {$where} ORDER BY id DESC LIMIT %d OFFSET %d",
				array_merge( $params, array( $per_page, $offset ) )
			),
			ARRAY_A
		);
		// phpcs:enable

		$rows = array_map( function ( $r ) {
			$r['data'] = (array) json_decode( (string) $r['data'], true );
			return $r;
		}, $rows ? $rows : array() );

		$response = rest_ensure_response( $rows );
		$response->header( 'X-WP-Total', $total );
		$response->header( 'X-WP-TotalPages', $fetch_all ? 1 : (int) ceil( $total / $per_page ) );
		return $response;
	}

	public function save_item( $request ) {
		global $wpdb;
		$module = $this->module( $request );
		if ( ! $module ) {
			return new WP_Error( 'invalid', __( 'Unknown module.', 'academy-pro' ), array( 'status' => 400 ) );
		}
		$title = sanitize_text_field( (string) $request->get_param( 'title' ) );
		if ( '' === $title ) {
			return new WP_Error( 'invalid', __( 'A name is required.', 'academy-pro' ), array( 'status' => 400 ) );
		}
		$data = self::sanitize_data( (array) $request->get_param( 'data' ) );
		$id   = (int) $request->get_param( 'id' );
		$table = Helper::records_table();

		$conflict = self::capacity_conflict( $module, $id, $data );
		if ( $conflict ) {
			return new WP_Error( 'adc_no_room', $conflict, array( 'status' => 409 ) );
		}

		$payload = array(
			'module'     => $module,
			'title'      => $title,
			'data'       => wp_json_encode( $data ),
			'updated_at' => current_time( 'mysql' ),
		);
		if ( null !== $request->get_param( 'campus_id' ) ) {
			$payload['campus_id'] = (int) $request->get_param( 'campus_id' ) ? (int) $request->get_param( 'campus_id' ) : null;
		}
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		if ( $id ) {
			$wpdb->update( $table, $payload, array( 'id' => $id ) );
		} else {
			$wpdb->insert( $table, $payload );
			$id = (int) $wpdb->insert_id;
		}
		// phpcs:enable

		// A route or room with a fee is billed like any other plan, so keep its
		// plan (and the product behind it) in step with the asset.
		if ( isset( \AcademyProCampus\Billing::FACILITY_PLANS[ $module ] ) ) {
			\AcademyProCampus\Billing::sync_facility_plan( $module, $id );
		}

		return rest_ensure_response( array( 'id' => $id ) );
	}

	public function delete_item( $request ) {
		global $wpdb;
		$table = Helper::records_table();
		$id    = (int) $request['id'];

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT module, title FROM {$table} WHERE id = %d", $id ), ARRAY_A );
		if ( ! $row ) {
			return new WP_Error( 'not_found', __( 'Record not found.', 'academy-pro' ), array( 'status' => 404 ) );
		}

		$blocker = self::first_dependent( $row['module'], $id );
		if ( $blocker ) {
			return new WP_Error(
				'adc_record_in_use',
				sprintf(
					/* translators: 1: number of records, 2: what they are, 3: the record being deleted */
					_n(
						'%1$d %2$s still points at “%3$s”. Move or remove it first.',
						'%1$d %2$s still point at “%3$s”. Move or remove them first.',
						$blocker['count'],
						'academy-pro'
					),
					$blocker['count'],
					$blocker['label'],
					$row['title']
				),
				array(
					'status' => 409,
					'count' => $blocker['count'],
					'module' => $blocker['module']
				)
			);
		}//end if

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->delete( $table, array( 'id' => $id ) );
		return rest_ensure_response( array( 'deleted' => true ) );
	}

	/**
	 * Why this row can't be saved against its asset, or null when it can.
	 *
	 * Three ways an allocation goes wrong: the room is already full, the
	 * student is already in it, or the bed is already someone else's. All
	 * three were previously accepted, leaving a hostel that looked correct
	 * until someone counted the beds.
	 *
	 * @param mixed $module
	 * @param int   $id
	 * @param array $data
	 *
	 * @return string|null Message for the operator.
	 */
	private static function capacity_conflict( $module, $id, $data ) {
		global $wpdb;
		$rule = self::CAPACITY_RULES[ $module ] ?? null;
		if ( ! $rule ) {
			return null;
		}
		$asset_id = (int) ( $data[ $rule['asset_key'] ] ?? 0 );
		$status   = (string) ( $data['status'] ?? '' );
		// Only a row that occupies the asset can clash with another.
		if ( ! $asset_id || ! in_array( $status, $rule['active'], true ) ) {
			return null;
		}

		$table = Helper::records_table();
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$asset = $wpdb->get_row( $wpdb->prepare( "SELECT title, data FROM {$table} WHERE id = %d AND module = %s", $asset_id, $rule['asset'] ), ARRAY_A );
		$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT id, data FROM {$table} WHERE module = %s", $module ), ARRAY_A );
		// phpcs:enable
		if ( ! $asset ) {
			return null;
		}

		$asset_data = (array) json_decode( (string) $asset['data'], true );
		$capacity   = (int) ( $asset_data[ $rule['capacity'] ] ?? 0 );
		$holder     = (string) ( $data[ $rule['holder'] ] ?? '' );
		$unique     = $rule['unique'] ? (string) ( $data[ $rule['unique'] ] ?? '' ) : '';

		$taken = 0;
		foreach ( (array) $rows as $row ) {
			if ( (int) $row['id'] === $id ) {
				continue; // the row being edited doesn't compete with itself
			}
			$other = json_decode( (string) $row['data'], true );
			if ( ! is_array( $other )
				|| (int) ( $other[ $rule['asset_key'] ] ?? 0 ) !== $asset_id
				|| ! in_array( (string) ( $other['status'] ?? '' ), $rule['active'], true ) ) {
				continue;
			}
			++$taken;

			if ( '' !== $holder && (string) ( $other[ $rule['holder'] ] ?? '' ) === $holder ) {
				return sprintf(
					/* translators: %s: room or route name */
					__( 'This student is already on “%s”.', 'academy-pro' ),
					$asset['title']
				);
			}
			if ( '' !== $unique && (string) ( $other[ $rule['unique'] ] ?? '' ) === $unique ) {
				return sprintf(
					/* translators: 1: bed number, 2: room name */
					__( 'Bed %1$s in “%2$s” is already taken.', 'academy-pro' ),
					$unique,
					$asset['title']
				);
			}
		}//end foreach

		if ( $capacity > 0 && $taken >= $capacity ) {
			return sprintf(
				/* translators: 1: room or route name, 2: capacity */
				__( '“%1$s” is full — all %2$d places are taken.', 'academy-pro' ),
				$asset['title'],
				$capacity
			);
		}

		return null;
	}

	/**
	 * Sanitise a data payload, keeping list fields (a route's stops) as lists.
	 *
	 * @param array $data
	 */
	private static function sanitize_data( $data ) {
		$clean = array();
		foreach ( $data as $key => $value ) {
			$key = sanitize_key( $key );
			if ( '' === $key ) {
				continue;
			}
			$clean[ $key ] = is_array( $value )
				? array_values( array_filter( array_map( 'sanitize_text_field', $value ), 'strlen' ) )
				: sanitize_text_field( (string) $value );
		}
		return $clean;
	}

	/**
	 * The first module still referencing `$id`, with how many rows do so.
	 * Rows are decoded rather than matched with SQL LIKE so an id like 1 can't
	 * match 11 (or a value that merely contains it).
	 *
	 * @param mixed $module
	 * @param int   $id
	 */
	private static function first_dependent( $module, $id ) {
		global $wpdb;
		if ( empty( self::DEPENDENTS[ $module ] ) ) {
			return null;
		}
		$table = Helper::records_table();
		foreach ( self::DEPENDENTS[ $module ] as $dependent ) {
			list( $child, $key ) = $dependent;
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$rows  = $wpdb->get_col( $wpdb->prepare( "SELECT data FROM {$table} WHERE module = %s", $child ) );
			$count = 0;
			foreach ( (array) $rows as $json ) {
				$data = json_decode( (string) $json, true );
				if ( is_array( $data ) && isset( $data[ $key ] ) && (int) $data[ $key ] === (int) $id ) {
					++$count;
				}
			}
			if ( $count ) {
				return array(
					'count' => $count,
					'module' => $child,
					'label' => self::label( $child, $count )
				);
			}
		}
		return null;
	}

	/**
	 * Human name for a module, used in the "still in use" message.
	 *
	 * @param mixed $module
	 * @param int   $count
	 */
	private static function label( $module, $count ) {
		$labels = array(
			'library_issue'        => array( __( 'book issue', 'academy-pro' ), __( 'book issues', 'academy-pro' ) ),
			'transport_assignment' => array( __( 'transport member', 'academy-pro' ), __( 'transport members', 'academy-pro' ) ),
			'hostel_allocation'    => array( __( 'hostel allocation', 'academy-pro' ), __( 'hostel allocations', 'academy-pro' ) ),
			'library'              => array( __( 'book', 'academy-pro' ), __( 'books', 'academy-pro' ) ),
		);
		$pair = $labels[ $module ] ?? array( __( 'record', 'academy-pro' ), __( 'records', 'academy-pro' ) );
		return 1 === $count ? $pair[0] : $pair[1];
	}
}
