<?php
namespace AcademyProCampus\API;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AcademyProCampus\Helper;

/**
 * Computed exam results: merit list, GPA/CGPA, fail tracking + publish gate.
 *
 * Route: academy-digital-campus/v1/sis/result-sheet   (GET  — merit list for an exam)
 * academy-digital-campus/v1/sis/exam-publish    (POST — toggle result publish)
 */
class Results extends \WP_REST_Controller {

	public static function init() {
		$self            = new self();
		$self->namespace = ACADEMY_DIGITAL_CAMPUS_PLUGIN_SLUG . '/v1';
		add_action( 'rest_api_init', array( $self, 'register_routes' ) );
	}

	public function register_routes() {
		register_rest_route( $this->namespace, '/sis/result-sheet', array(
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'result_sheet' ),
				'permission_callback' => array( 'AcademyProCampus\\Helper', 'manager_check' ),
			),
		) );
		register_rest_route( $this->namespace, '/sis/exam-publish', array(
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'set_publish' ),
				'permission_callback' => array( 'AcademyProCampus\\Helper', 'manager_check' ),
			),
		) );
	}

	public function set_publish( $request ) {
		$exam_id   = (int) $request->get_param( 'exam_id' );
		$published = $request->get_param( 'published' ) ? 1 : 0;
		if ( ! $exam_id ) {
			return new \WP_Error( 'invalid', __( 'An exam is required.', 'academy-pro' ), array( 'status' => 400 ) );
		}
		update_post_meta( $exam_id, 'adc_exam_published', $published );
		Helper::audit( 'exam', $exam_id, $published ? 'result_published' : 'result_unpublished', get_the_title( $exam_id ) );
		return rest_ensure_response( array(
			'exam_id' => $exam_id,
			'published' => $published
		) );
	}

	/**
	 * Build a ranked merit list for an exam across a class / section.
	 *
	 * @param \WP_REST_Request $request
	 */
	public function result_sheet( $request ) {
		global $wpdb;
		$exam_id    = (int) $request->get_param( 'exam_id' );
		$class_id   = (int) $request->get_param( 'class_id' );
		$section_id = (int) $request->get_param( 'section_id' );

		if ( ! $exam_id ) {
			return new \WP_Error( 'invalid', __( 'An exam is required.', 'academy-pro' ), array( 'status' => 400 ) );
		}

		// Subjects in scope (a class if given, else whatever has marks).
		$subjects = array();
		if ( $class_id ) {
			// Class-scoped + global subjects that apply to this class.
			$posts = \AcademyDigitalCampus\Helper::subjects_for_class( $class_id, 'ids' );
			foreach ( $posts as $sid ) {
				$subjects[ (int) $sid ] = $this->subject_meta( $sid, $class_id );
			}
		}

		// Students in scope.
		$student_ids = array();
		if ( $section_id && class_exists( '\AcademyDigitalCampus\Helper' ) ) {
			$student_ids = \AcademyDigitalCampus\Helper::get_section_student_ids( $section_id );
		} elseif ( $class_id ) {
			$adm = \AcademyDigitalCampus\Helper::admissions_table();
			// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- only $wpdb-prefixed table names, whitelisted columns and intval/placeholder lists are interpolated; values are prepared
			$student_ids = array_map( 'intval', $wpdb->get_col( $wpdb->prepare(
				"SELECT DISTINCT student_id FROM {$adm} WHERE class_id = %d", $class_id
			) ) );
			// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		}

		// Marks for this exam.
		$rt = Helper::exam_results_table();
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$marks = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$rt} WHERE exam_id = %d", $exam_id ), ARRAY_A );

		// If no explicit student scope, derive it from who has marks.
		if ( ! $student_ids ) {
			$student_ids = array_values( array_unique( array_map( function ( $m ) {
				return (int) $m['student_id'];
			}, $marks ) ) );
		}

		// Index marks by student → subject.
		$by_student = array();
		foreach ( $marks as $m ) {
			$by_student[ (int) $m['student_id'] ][ (int) $m['subject_id'] ] = $m;
			// Learn subjects from marks when no class scope was given.
			if ( ! isset( $subjects[ (int) $m['subject_id'] ] ) ) {
				$subjects[ (int) $m['subject_id'] ] = $this->subject_meta( (int) $m['subject_id'] );
			}
		}

		$rows = array();
		foreach ( $student_ids as $sid ) {
			$student   = get_user_by( 'id', $sid );
			$obtained  = 0.0;
			$max       = 0.0;
			$points    = array();
			$fails     = array();
			$has_marks = false;

			foreach ( $subjects as $subject_id => $subj ) {
				$mark = $by_student[ $sid ][ $subject_id ] ?? null;
				if ( null === $mark ) {
					continue;
				}
				$has_marks = true;
				$o         = (float) $mark['obtained_marks'];
				$t         = (float) $mark['total_marks'] ? (float) $mark['total_marks'] : (float) $subj['full_marks'];
				$obtained += $o;
				$max      += $t;
				$pct       = $t > 0 ? ( $o / $t ) * 100 : 0;
				$points[]  = Helper::grade_points( $pct );
				$pass      = $subj['pass_marks'] > 0 ? $subj['pass_marks'] : ( $t * 0.33 );
				if ( $o < $pass ) {
					$fails[] = $subj['name'];
				}
			}

			if ( ! $has_marks ) {
				continue;
			}

			$percentage = $max > 0 ? round( ( $obtained / $max ) * 100, 2 ) : 0;
			$failed     = count( $fails ) > 0;
			$gpa        = $failed ? 0.0 : ( $points ? round( array_sum( $points ) / count( $points ), 2 ) : 0 );

			$rows[] = array(
				'student_id'   => $sid,
				'student_name' => $student ? $student->display_name : '',
				// Summed as floats across subjects — round off the binary
				// floating-point drift (e.g. 84.99999999999999) so the merit
				// list shows the clean number the marks actually add up to.
				'obtained'     => round( $obtained, 2 ),
				'total'        => round( $max, 2 ),
				'percentage'   => $percentage,
				'grade'        => $failed ? 'F' : Helper::grade_from_percentage( $percentage ),
				'gpa'          => $gpa,
				'failed'       => $failed,
				'fail_count'   => count( $fails ),
				'fail_subjects' => $fails,
			);
		}//end foreach

		// Rank by total obtained → merit position (ties share a position).
		usort( $rows, function ( $a, $b ) {
			return $b['obtained'] <=> $a['obtained'];
		} );
		$position = 0;
		$last     = null;
		foreach ( $rows as $i => &$row ) {
			if ( null === $last || $row['obtained'] < $last ) {
				$position = $i + 1;
				$last     = $row['obtained'];
			}
			$row['position'] = $position;
		}
		unset( $row );

		return rest_ensure_response( array(
			'exam_id'   => $exam_id,
			'published' => (int) get_post_meta( $exam_id, 'adc_exam_published', true ) ? 1 : 0,
			'subjects'  => array_values( $subjects ),
			'students'  => $rows,
		) );
	}

	private function subject_meta( $subject_id, $class_id = 0 ) {
		// Marks are a per-class assignment detail; resolve them for this class
		// (falls back to the subject's legacy meta when no class context).
		$assignment = \AcademyDigitalCampus\Helper::class_subject( $class_id, (int) $subject_id );
		return array(
			'id'         => (int) $subject_id,
			'name'       => get_the_title( (int) $subject_id ),
			'full_marks' => (float) $assignment['full_marks'],
			'pass_marks' => (float) $assignment['pass_marks'],
		);
	}
}
