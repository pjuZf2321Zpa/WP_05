<?php
namespace AcademyProCampus\API;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AcademyProCampus\Helper;

/**
 * REST controller for per-subject exam marks.
 *
 * Route: academy/v1/sis/exam-results
 */
class ExamResults extends \WP_REST_Controller {

	public static function init() {
		$self            = new self();
		$self->namespace = ACADEMY_DIGITAL_CAMPUS_PLUGIN_SLUG . '/v1';
		$self->rest_base = 'sis/exam-results';
		add_action( 'rest_api_init', array( $self, 'register_routes' ) );
	}

	public function register_routes() {
		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base,
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_items' ),
					'permission_callback' => array( 'AcademyProCampus\\Helper', 'manager_check' ),
				),
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'bulk_save' ),
					'permission_callback' => array( 'AcademyProCampus\\Helper', 'manager_check' ),
				),
			)
		);
	}

	public function get_items( $request ) {
		global $wpdb;
		$table  = Helper::exam_results_table();
		$where  = '1=1';
		$params = array();
		foreach ( array( 'exam_id', 'subject_id', 'student_id' ) as $col ) {
			$val = $request->get_param( $col );
			if ( null !== $val && '' !== $val ) {
				$where   .= " AND {$col} = %d";
				$params[] = (int) $val;
			}
		}
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- only $wpdb-prefixed table names, whitelisted columns and intval/placeholder lists are interpolated; values are prepared
		$rows = $wpdb->get_results( $params
			? $wpdb->prepare( "SELECT * FROM {$table} WHERE {$where} ORDER BY id DESC", $params )
		: "SELECT * FROM {$table} WHERE {$where} ORDER BY id DESC", ARRAY_A );
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber

		$items = array_map( function ( $row ) {
			$student = get_user_by( 'id', (int) $row['student_id'] );
			$row['student_name'] = $student ? $student->display_name : '';
			$row['subject_name'] = get_the_title( (int) $row['subject_id'] );
			return $row;
		}, $rows ? $rows : array() );

		return rest_ensure_response( $items );
	}

	/**
	 * Save a batch of marks for an exam (upsert per subject/student).
	 *
	 * @param \WP_REST_Request $request
	 */
	public function bulk_save( $request ) {
		global $wpdb;
		$table   = Helper::exam_results_table();
		$exam_id = (int) $request->get_param( 'exam_id' );
		$results = (array) $request->get_param( 'results' );

		if ( ! $exam_id || ! $results ) {
			return new \WP_Error( 'invalid', __( 'An exam and results are required.', 'academy-pro' ), array( 'status' => 400 ) );
		}

		$saved = 0;
		foreach ( $results as $r ) {
			$subject_id = (int) ( $r['subject_id'] ?? 0 );
			$student_id = (int) ( $r['student_id'] ?? 0 );
			if ( ! $subject_id || ! $student_id ) {
				continue;
			}
			$obtained = isset( $r['obtained_marks'] ) ? (float) $r['obtained_marks'] : null;
			$total    = isset( $r['total_marks'] ) ? (float) $r['total_marks'] : (float) get_post_meta( $exam_id, 'adc_exam_total_marks', true );
			$grade    = $total > 0 && null !== $obtained ? Helper::grade_from_percentage( ( $obtained / $total ) * 100 ) : null;

			// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- only $wpdb-prefixed table names, whitelisted columns and intval/placeholder lists are interpolated; values are prepared
			$existing = $wpdb->get_var( $wpdb->prepare(
				"SELECT id FROM {$table} WHERE exam_id = %d AND subject_id = %d AND student_id = %d",
				$exam_id, $subject_id, $student_id
			) );
			// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

			$data = array(
				'exam_id'        => $exam_id,
				'subject_id'     => $subject_id,
				'student_id'     => $student_id,
				'obtained_marks' => $obtained,
				'total_marks'    => $total,
				'grade'          => $grade,
				'remarks'        => sanitize_text_field( (string) ( $r['remarks'] ?? '' ) ),
				'entered_by'     => get_current_user_id(),
				'updated_at'     => current_time( 'mysql' ),
			);

			// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			if ( $existing ) {
				$wpdb->update( $table, $data, array( 'id' => (int) $existing ) );
			} else {
				$wpdb->insert( $table, $data );
			}
			// phpcs:enable
			++$saved;
		}//end foreach

		return rest_ensure_response( array( 'saved' => $saved ) );
	}
}
