<?php
namespace AcademyProCampus\API;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AcademyProCampus\Helper;
use WP_Error;

/**
 * Native section/date attendance marking.
 *
 * Route: academy/v1/sis/attendance-sheet
 */
class AttendanceMarking extends \WP_REST_Controller {

	public static function init() {
		$self            = new self();
		$self->namespace = ACADEMY_DIGITAL_CAMPUS_PLUGIN_SLUG . '/v1';
		add_action( 'rest_api_init', array( $self, 'register_routes' ) );
	}

	public function register_routes() {
		register_rest_route( $this->namespace, '/sis/attendance-sheet', array(
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_sheet' ),
				'permission_callback' => array( 'AcademyProCampus\\Helper', 'manager_check' ),
			),
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'save_sheet' ),
				'permission_callback' => array( 'AcademyProCampus\\Helper', 'manager_check' ),
			),
		) );
		register_rest_route( $this->namespace, '/sis/attendance-report', array(
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_report' ),
				'permission_callback' => array( 'AcademyProCampus\\Helper', 'manager_check' ),
			),
		) );
	}

	/**
	 * Per-student attendance summary for a section over a month or date range,
	 * with percentage and a low-attendance flag.
	 *
	 * @param \WP_REST_Request $request
	 */
	public function get_report( $request ) {
		global $wpdb;
		$table      = Helper::attendance_table();
		$class_id   = (int) $request->get_param( 'class_id' );
		$section_id = (int) $request->get_param( 'section_id' );
		$month      = sanitize_text_field( (string) $request->get_param( 'month' ) ); // YYYY-MM
		$from       = sanitize_text_field( (string) $request->get_param( 'from' ) );
		$to         = sanitize_text_field( (string) $request->get_param( 'to' ) );
		$threshold  = (float) ( $request->get_param( 'threshold' ) ? $request->get_param( 'threshold' ) : apply_filters( 'academy_digital_campus/low_attendance_threshold', 75 ) );

		if ( ! $class_id && ! $section_id ) {
			return new WP_Error( 'invalid', __( 'A class or section is required.', 'academy-pro' ), array( 'status' => 400 ) );
		}

		if ( $month && preg_match( '/^\d{4}-\d{2}$/', $month ) ) {
			$from = $month . '-01';
			$to   = gmdate( 'Y-m-t', strtotime( $from ) );
		}
		if ( ! $from ) {
			$from = gmdate( 'Y-m-01' );
		}
		if ( ! $to ) {
			$to = gmdate( 'Y-m-t', strtotime( $from ) );
		}

		// Roster is section- or class-based; marks are matched by student so the
		// report works whether attendance was stored per-section or class-level.
		$roster = $this->roster( $class_id, $section_id );
		$in     = implode( ',', array_map( 'intval', $roster ? $roster : array( 0 ) ) );

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT student_id, status, att_date FROM {$table} WHERE student_id IN ({$in}) AND att_date BETWEEN %s AND %s",
			$from, $to
		), ARRAY_A );
		// Distinct working days = days any attendance was taken for this roster.
		$working_days = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(DISTINCT att_date) FROM {$table} WHERE student_id IN ({$in}) AND att_date BETWEEN %s AND %s",
			$from, $to
		) );
		// phpcs:enable

		$by_student = array();
		foreach ( (array) $rows as $r ) {
			$sid = (int) $r['student_id'];
			if ( ! isset( $by_student[ $sid ] ) ) {
				$by_student[ $sid ] = array(
					'present' => 0,
					'absent' => 0,
					'late' => 0,
					'leave' => 0
				);
			}
			$status = $r['status'];
			if ( isset( $by_student[ $sid ][ $status ] ) ) {
				++$by_student[ $sid ][ $status ];
			}
		}

		$report = array();
		foreach ( $roster as $sid ) {
			$c        = $by_student[ $sid ] ?? array(
				'present' => 0,
				'absent' => 0,
				'late' => 0,
				'leave' => 0
			);
			$user     = get_user_by( 'id', $sid );
			$attended = $c['present'] + $c['late']; // late still counts as attended.
			$pct      = $working_days > 0 ? round( ( $attended / $working_days ) * 100, 1 ) : 0;
			$report[] = array(
				'student_id'   => $sid,
				'student_name' => $user ? $user->display_name : '',
				'present'      => $c['present'],
				'absent'       => $c['absent'],
				'late'         => $c['late'],
				'leave'        => $c['leave'],
				'working_days' => $working_days,
				'percentage'   => $pct,
				'low'          => $working_days > 0 && $pct < $threshold,
			);
		}//end foreach

		return rest_ensure_response( array(
			'from'         => $from,
			'to'           => $to,
			'working_days' => $working_days,
			'threshold'    => $threshold,
			'students'     => $report,
		) );
	}

	/**
	 * Roster: a section's students when a section is chosen, else the whole class.
	 *
	 * @param int $class_id
	 * @param int $section_id
	 */
	private function roster( $class_id, $section_id ) {
		if ( ! class_exists( '\AcademyDigitalCampus\Helper' ) ) {
			return array();
		}
		return $section_id
			? \AcademyDigitalCampus\Helper::get_section_student_ids( $section_id )
			: \AcademyDigitalCampus\Helper::get_class_student_ids( $class_id );
	}

	public function get_sheet( $request ) {
		global $wpdb;
		$table      = Helper::attendance_table();
		$class_id   = (int) $request->get_param( 'class_id' );
		$section_id = (int) $request->get_param( 'section_id' );
		$subject_id = (int) $request->get_param( 'subject_id' );
		$att_date   = sanitize_text_field( (string) $request->get_param( 'att_date' ) );

		if ( ( ! $class_id && ! $section_id ) || ! $att_date ) {
			return new WP_Error( 'invalid', __( 'A class or section, and a date, are required.', 'academy-pro' ), array( 'status' => 400 ) );
		}

		$roster = $this->roster( $class_id, $section_id );

		// Existing marks for the day, matched by student so it works whether the
		// record was stored per-section or class-level.
		$marked = array();
		if ( $roster ) {
			$in = implode( ',', array_map( 'intval', $roster ) );
			// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- only $wpdb-prefixed table names, whitelisted columns and intval/placeholder lists are interpolated; values are prepared
			$rows = $wpdb->get_results( $wpdb->prepare(
				"SELECT student_id, status FROM {$table} WHERE student_id IN ({$in}) AND subject_id = %d AND att_date = %s",
				$subject_id, $att_date
			), ARRAY_A );
			// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			foreach ( (array) $rows as $r ) {
				$marked[ (int) $r['student_id'] ] = $r['status'];
			}
		}

		$students = array();
		foreach ( $roster as $student_id ) {
			$user = get_user_by( 'id', $student_id );
			$students[] = array(
				'student_id' => $student_id,
				'name'       => $user ? $user->display_name : '',
				'avatar'     => get_avatar_url( $student_id ),
				'status'     => $marked[ $student_id ],
			);
		}

		return rest_ensure_response( array( 'students' => $students ) );
	}

	public function save_sheet( $request ) {
		global $wpdb;
		$table      = Helper::attendance_table();
		$class_id   = (int) $request->get_param( 'class_id' );
		$section_id = (int) $request->get_param( 'section_id' );
		$subject_id = (int) $request->get_param( 'subject_id' );
		$att_date   = sanitize_text_field( (string) $request->get_param( 'att_date' ) );
		$records    = (array) $request->get_param( 'records' );

		if ( ( ! $class_id && ! $section_id ) || ! $att_date || ! $records ) {
			return new WP_Error( 'invalid', __( 'A class or section, a date and records are required.', 'academy-pro' ), array( 'status' => 400 ) );
		}

		// Marking the whole class (no section chosen): stamp each record with the
		// student's own section (0 if none) so section-level reports still align.
		$section_map = ( ! $section_id && class_exists( '\AcademyDigitalCampus\Helper' ) )
			? \AcademyDigitalCampus\Helper::get_class_student_sections( $class_id )
			: array();

		$saved = 0;
		foreach ( $records as $rec ) {
			$student_id = (int) ( $rec['student_id'] ?? 0 );
			$status     = in_array( ( $rec['status'] ?? '' ), array( 'present', 'absent', 'late', 'leave' ), true ) ? $rec['status'] : 'present';
			if ( ! $student_id ) {
				continue;
			}
			$sec = $section_id ? $section_id : (int) ( $section_map[ $student_id ] ?? 0 );
			// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- only $wpdb-prefixed table names, whitelisted columns and intval/placeholder lists are interpolated; values are prepared
			$existing = $wpdb->get_var( $wpdb->prepare(
				"SELECT id FROM {$table} WHERE section_id = %d AND subject_id = %d AND student_id = %d AND att_date = %s",
				$sec, $subject_id, $student_id, $att_date
			) );
			// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$data = array(
				'section_id' => $sec,
				'subject_id' => $subject_id,
				'student_id' => $student_id,
				'att_date'   => $att_date,
				'status'     => $status,
				'marked_by'  => get_current_user_id(),
				'updated_at' => current_time( 'mysql' ),
			);
			// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			if ( $existing ) {
				$wpdb->update( $table, $data, array( 'id' => (int) $existing ) );
			} else {
				$wpdb->insert( $table, $data );
			}
			// phpcs:enable
			++$saved;
		}//end foreach

		return rest_ensure_response( array(
			'success' => true,
			'saved' => $saved
		) );
	}
}
