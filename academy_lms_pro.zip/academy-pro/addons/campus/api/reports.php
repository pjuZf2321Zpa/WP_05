<?php
namespace AcademyProCampus\API;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AcademyProCampus\Helper;

/**
 * School-level report summaries (enrollment, fee collection).
 *
 * Route: academy/v1/sis/reports
 */
class Reports extends \WP_REST_Controller {

	public static function init() {
		$self            = new self();
		$self->namespace = ACADEMY_DIGITAL_CAMPUS_PLUGIN_SLUG . '/v1';
		$self->rest_base = 'sis/reports';
		add_action( 'rest_api_init', array( $self, 'register_routes' ) );
	}

	public function register_routes() {
		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base,
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_reports' ),
					'permission_callback' => array( 'AcademyProCampus\\Helper', 'manager_check' ),
				),
			)
		);
		register_rest_route(
			$this->namespace,
			'/sis/analytics',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_analytics' ),
					'permission_callback' => array( 'AcademyProCampus\\Helper', 'manager_check' ),
				),
			)
		);
		register_rest_route(
			$this->namespace,
			'/sis/campus-stats',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_campus_stats' ),
					'permission_callback' => array( 'AcademyProCampus\\Helper', 'manager_check' ),
				),
			)
		);
		register_rest_route(
			$this->namespace,
			'/sis/class-analytics',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_class_analytics' ),
					'permission_callback' => array( 'AcademyProCampus\\Helper', 'manager_check' ),
					'args'                => array(
						'class_id' => array(
							'required' => true,
							'sanitize_callback' => 'absint'
						),
					),
				),
			)
		);
	}

	/**
	 * Analytics scoped to a single class: student headcount by status, section /
	 * subject counts, attendance rate, fee billed / collected / outstanding, and
	 * the average result — all filtered to that class.
	 *
	 * @param \WP_REST_Request $request
	 */
	public function get_class_analytics( $request ) {
		global $wpdb;
		$class_id = (int) $request->get_param( 'class_id' );
		if ( ! $class_id || ! class_exists( '\AcademyDigitalCampus\Helper' ) ) {
			return new \WP_Error( 'invalid', __( 'A class is required.', 'academy-pro' ), array( 'status' => 400 ) );
		}

		$admissions = \AcademyDigitalCampus\Helper::admissions_table();

		// Students by status.
		$statuses = array( 'applied', 'enrolled', 'withdrawn', 'graduated' );
		$students = array();
		foreach ( $statuses as $st ) {
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$students[ $st ] = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(id) FROM {$admissions} WHERE class_id = %d AND status = %s", $class_id, $st ) );
		}

		// Section + subject counts (subjects via the assignment resolver).
		// phpcs:disable WordPressVIPMinimum.Performance.NoPaging.posts_per_page_posts_per_page, WordPress.DB.SlowDBQuery -- needs the complete (small, bounded) set of the class's sections
		$sections = get_posts( array(
			'post_type' => 'adc_section',
			'posts_per_page' => -1,
			'post_status' => 'publish',
			'fields' => 'ids',
			'meta_key' => 'adc_section_class_id',
			'meta_value' => $class_id
		) );
		// phpcs:enable WordPressVIPMinimum.Performance.NoPaging.posts_per_page_posts_per_page, WordPress.DB.SlowDBQuery
		$subjects = \AcademyDigitalCampus\Helper::subjects_for_class( $class_id, 'ids' );

		// Attendance rate for the class's sections.
		$attendance = array(
			'total' => 0,
			'present' => 0,
			'percentage' => 0
		);
		if ( $sections ) {
			$att_table = Helper::attendance_table();
			$in        = implode( ',', array_map( 'intval', $sections ) );
			// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$attendance['total']   = (int) $wpdb->get_var( "SELECT COUNT(id) FROM {$att_table} WHERE section_id IN ({$in})" );
			$attendance['present'] = (int) $wpdb->get_var( "SELECT COUNT(id) FROM {$att_table} WHERE section_id IN ({$in}) AND status = 'present'" );
			// phpcs:enable
			$attendance['percentage'] = $attendance['total'] > 0 ? round( ( $attendance['present'] / $attendance['total'] ) * 100, 1 ) : 0;
		}

		// Fees for this class, summed from the plans that bill it.
		$fee = \AcademyProCampus\Billing::class_fee_summary( $class_id );

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		// Average result for enrolled students of this class.
		$results_table = Helper::exam_results_table();
		$student_ids   = array_map( 'intval', $wpdb->get_col( $wpdb->prepare( "SELECT DISTINCT student_id FROM {$admissions} WHERE class_id = %d", $class_id ) ) );
		$avg_pct       = 0;
		if ( $student_ids ) {
			$in      = implode( ',', $student_ids );
			$avg_pct = (float) $wpdb->get_var( "SELECT COALESCE(AVG(CASE WHEN total_marks > 0 THEN obtained_marks/total_marks*100 ELSE NULL END),0) FROM {$results_table} WHERE student_id IN ({$in})" );
		}
		// phpcs:enable

		return rest_ensure_response( array(
			'class'      => array(
				'id' => $class_id,
				'name' => get_the_title( $class_id )
			),
			'students'   => $students,
			'sections'   => count( $sections ),
			'subjects'   => count( $subjects ),
			'attendance' => $attendance,
			'fee'        => $fee,
			'results'    => array( 'avg_percentage' => round( $avg_pct, 1 ) ),
		) );
	}

	/**
	 * Per-campus enrolled-student counts (multi-campus overview).
	 *
	 * @param \WP_REST_Request $request
	 */
	public function get_campus_stats( $request ) {
		$out = array();
		if ( ! class_exists( '\AcademyDigitalCampus\Helper' ) ) {
			return rest_ensure_response( $out );
		}
		// Campuses are posts, not terms — the id here is the campus post id,
		// which is what admissions store.
		// phpcs:disable WordPress.WP.PostsPerPage.posts_per_page_posts_per_page -- admin picker list capped at 200
		$campuses = get_posts( array(
			'post_type'      => 'adc_campus',
			'post_status'    => array( 'publish', 'draft' ),
			'posts_per_page' => 200,
			'orderby'        => array(
				'menu_order' => 'ASC',
				'title' => 'ASC'
			),
		) );
		// phpcs:enable WordPress.WP.PostsPerPage.posts_per_page_posts_per_page
		global $wpdb;
		$admissions = \AcademyDigitalCampus\Helper::admissions_table();
		foreach ( $campuses as $campus ) {
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$students = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(id) FROM {$admissions} WHERE campus_id = %d AND status = 'enrolled'", $campus->ID ) );
			$out[] = array(
				'id'       => $campus->ID,
				'name'     => $campus->post_title,
				'students' => $students,
				'link'     => get_permalink( $campus ),
			);
		}
		return rest_ensure_response( $out );
	}

	/**
	 * Superset dashboard: enrollment, admission funnel, fees, attendance, results.
	 *
	 * @param \WP_REST_Request $request
	 */
	public function get_analytics( $request ) {
		global $wpdb;
		$reports = $this->get_reports( $request )->get_data();

		$statuses = array( 'applied', 'enrolled', 'withdrawn', 'graduated' );
		$funnel   = array();
		if ( class_exists( '\AcademyDigitalCampus\Helper' ) ) {
			$admissions = \AcademyDigitalCampus\Helper::admissions_table();
			foreach ( $statuses as $st ) {
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
				$funnel[ $st ] = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(id) FROM {$admissions} WHERE status = %s", $st ) );
			}
		}

		// Attendance rate.
		$att_table = Helper::attendance_table();
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$att_total   = (int) $wpdb->get_var( "SELECT COUNT(id) FROM {$att_table}" );
		$att_present = (int) $wpdb->get_var( "SELECT COUNT(id) FROM {$att_table} WHERE status = 'present'" );
		// Results average.
		$results_table = Helper::exam_results_table();
		$avg_pct = (float) $wpdb->get_var( "SELECT COALESCE(AVG(CASE WHEN total_marks > 0 THEN obtained_marks/total_marks*100 ELSE NULL END),0) FROM {$results_table}" );
		$results_count = (int) $wpdb->get_var( "SELECT COUNT(id) FROM {$results_table}" );
		// phpcs:enable

		return rest_ensure_response( array(
			'enrollment'               => $reports['enrollment'],
			'enrollment_by_department' => $reports['enrollment_by_department'],
			'enrollment_by_year'       => $reports['enrollment_by_year'],
			'enrollment_by_term'       => $reports['enrollment_by_term'],
			'fee'          => $reports['fee'],
			'admissions'   => $funnel,
			'attendance'   => array(
				'total'      => $att_total,
				'present'    => $att_present,
				'percentage' => $att_total > 0 ? round( ( $att_present / $att_total ) * 100, 1 ) : 0,
			),
			'results'      => array(
				'entries'        => $results_count,
				'avg_percentage' => round( $avg_pct, 1 ),
			),
		) );
	}

	public function get_reports( $request ) {
		global $wpdb;

		// Fees are StoreEngine orders, so the numbers here are the store's.
		$summary = \AcademyProCampus\Billing::summary();
		$fee     = array(
			'billed'      => $summary['collected'] + $summary['unpaid_amount'],
			'collected'   => $summary['collected'],
			'unpaid'      => $summary['unpaid_count'],
			'outstanding' => $summary['unpaid_amount'],
		);
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		$enrollment              = array();
		$enrollment_by_year      = array();
		$enrollment_by_term      = array();
		$enrollment_by_department = array();
		if ( class_exists( '\AcademyDigitalCampus\Helper' ) ) {
			$admissions = \AcademyDigitalCampus\Helper::admissions_table();

			// By class.
			$rows = $wpdb->get_results( "SELECT class_id, COUNT(id) AS total FROM {$admissions} WHERE status = 'enrolled' GROUP BY class_id", ARRAY_A );
			$dept_totals = array();
			foreach ( (array) $rows as $r ) {
				$class_id     = (int) $r['class_id'];
				$enrollment[] = array(
					'class' => $class_id ? ( get_the_title( $class_id ) ? get_the_title( $class_id ) : __( 'Unassigned', 'academy-pro' ) ) : __( 'Unassigned', 'academy-pro' ),
					'total' => (int) $r['total'],
				);
				// Roll the class total up into its department (department lives on
				// the class, not the student).
				$dept_id                 = $class_id ? (int) get_post_meta( $class_id, 'adc_class_department_id', true ) : 0;
				$dept_totals[ $dept_id ] = ( $dept_totals[ $dept_id ] ?? 0 ) + (int) $r['total'];
			}
			foreach ( $dept_totals as $dept_id => $total ) {
				$enrollment_by_department[] = array(
					'department' => self::term_name( $dept_id ),
					'total'      => (int) $total,
				);
			}

			// By academic year.
			$rows = $wpdb->get_results( "SELECT academic_year_id, COUNT(id) AS total FROM {$admissions} WHERE status = 'enrolled' GROUP BY academic_year_id", ARRAY_A );
			foreach ( (array) $rows as $r ) {
				$enrollment_by_year[] = array(
					'year'  => self::term_name( (int) $r['academic_year_id'] ),
					'total' => (int) $r['total'],
				);
			}

			// By term / semester.
			$rows = $wpdb->get_results( "SELECT term_id, COUNT(id) AS total FROM {$admissions} WHERE status = 'enrolled' GROUP BY term_id", ARRAY_A );
			foreach ( (array) $rows as $r ) {
				$enrollment_by_term[] = array(
					'term'  => self::term_name( (int) $r['term_id'] ),
					'total' => (int) $r['total'],
				);
			}
		}//end if
		// phpcs:enable

		return rest_ensure_response( array(
			'fee'                     => $fee,
			'enrollment'              => $enrollment,
			'enrollment_by_department' => $enrollment_by_department,
			'enrollment_by_year'      => $enrollment_by_year,
			'enrollment_by_term'      => $enrollment_by_term,
		) );
	}

	/**
	 * Resolve a taxonomy term id to its name, or an "Unassigned" fallback.
	 *
	 * @param int $term_id
	 */
	private static function term_name( $term_id ) {
		if ( ! $term_id ) {
			return __( 'Unassigned', 'academy-pro' );
		}
		$term = get_term( (int) $term_id );
		return ( $term && ! is_wp_error( $term ) ) ? $term->name : '#' . (int) $term_id;
	}
}
