<?php
namespace AcademyProCampus\API;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AcademyProCampus\Helper;
use WP_Error;

/**
 * The student's own view of the campus.
 *
 * The admin controllers answer school-wide questions and are gated on
 * `manage_adc_sis`, which a parent will never have. These answer the same
 * questions for one student, and are gated on "may this person see this
 * student" — so a family sees their attendance, their routine, their exams and
 * the facilities they use, and nobody else's.
 *
 * academy-digital-campus/v1/sis/my/*
 */
class MyCampus extends \WP_REST_Controller {

	public static function init() {
		$self            = new self();
		$self->namespace = ACADEMY_DIGITAL_CAMPUS_PLUGIN_SLUG . '/v1';
		add_action( 'rest_api_init', array( $self, 'register_routes' ) );
	}

	public function register_routes() {
		foreach ( array( 'attendance', 'timetable', 'exams', 'facilities' ) as $what ) {
			register_rest_route( $this->namespace, '/sis/my/' . $what, array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_' . $what ),
					'permission_callback' => array( $this, 'can_view' ),
				),
			) );
		}
	}

	/**
	 * A student, their parent, or campus staff.
	 *
	 * @param \WP_REST_Request $request
	 */
	public function can_view( $request ) {
		if ( ! class_exists( '\AcademyDigitalCampus\Helper' ) ) {
			return false;
		}
		return \AcademyDigitalCampus\Helper::current_user_can_view_student( (int) $request->get_param( 'student_id' ) );
	}

	/**
	 * This term's attendance: the tally, the percentage, and the days that
	 * weren't a plain "present" — the ones a parent actually wants to see.
	 *
	 * @param \WP_REST_Request $request
	 */
	public function get_attendance( $request ) {
		global $wpdb;
		$student_id = (int) $request->get_param( 'student_id' );
		$month      = sanitize_text_field( (string) $request->get_param( 'month' ) );
		$from       = preg_match( '/^\d{4}-\d{2}$/', $month ) ? $month . '-01' : gmdate( 'Y-m-01' );
		$to         = gmdate( 'Y-m-t', strtotime( $from ) );
		$table      = Helper::attendance_table();

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT att_date, status, remarks FROM {$table}
			 WHERE student_id = %d AND att_date BETWEEN %s AND %s
			 ORDER BY att_date DESC",
			$student_id,
			$from,
			$to
		), ARRAY_A );
		// phpcs:enable

		$counts = array(
			'present' => 0,
			'absent' => 0,
			'late' => 0,
			'leave' => 0
		);
		foreach ( (array) $rows as $row ) {
			$status = (string) $row['status'];
			if ( isset( $counts[ $status ] ) ) {
				++$counts[ $status ];
			}
		}
		$marked  = array_sum( $counts );
		$present = $counts['present'] + $counts['late'];

		return rest_ensure_response( array(
			'month'      => gmdate( 'Y-m', strtotime( $from ) ),
			'counts'     => $counts,
			'marked'     => $marked,
			'percentage' => $marked ? round( ( $present / $marked ) * 100, 1 ) : null,
			// Present days are the norm; the exceptions are the news.
			'exceptions' => array_values( array_filter( (array) $rows, function ( $row ) {
				return 'present' !== $row['status'];
			} ) ),
		) );
	}

	/**
	 * The weekly routine of the section this student sits in.
	 *
	 * @param \WP_REST_Request $request
	 */
	public function get_timetable( $request ) {
		global $wpdb;
		$section_id = $this->section_of( (int) $request->get_param( 'student_id' ) );
		if ( ! $section_id ) {
			return rest_ensure_response( array(
				'section_id' => 0,
				'rows' => array()
			) );
		}

		$table = Helper::timetable_table();
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE section_id = %d ORDER BY weekday ASC, period_no ASC", $section_id ), ARRAY_A );

		return rest_ensure_response( array(
			'section_id' => $section_id,
			'rows'       => array_map( function ( $row ) use ( $section_id ) {
				// The slot's own teacher is an override; normally the name comes
				// from the class's subject assignment, so a routine the school
				// built without re-picking a teacher per period still says who
				// takes it.
				$teacher_id = class_exists( '\AcademyDigitalCampus\Helper' )
					? \AcademyDigitalCampus\Helper::resolve_slot_teacher( $section_id, (int) $row['subject_id'], (int) $row['teacher_id'] )
					: (int) $row['teacher_id'];
				$teacher    = $teacher_id ? get_user_by( 'id', $teacher_id ) : null;
				return array(
					'weekday'    => (int) $row['weekday'],
					'period_no'  => (int) $row['period_no'],
					'subject'    => $row['subject_id'] ? get_the_title( (int) $row['subject_id'] ) : '',
					'teacher'    => $teacher ? $teacher->display_name : '',
					'room'       => (string) $row['room'],
					'start_time' => (string) $row['start_time'],
					'end_time'   => (string) $row['end_time'],
				);
			}, (array) $rows ),
		) );
	}

	/**
	 * Exams still to come, with the sitting details already scheduled.
	 *
	 * @param \WP_REST_Request $request
	 */
	public function get_exams( $request ) {
		global $wpdb;
		$student_id = (int) $request->get_param( 'student_id' );
		$class_id   = $this->class_of( $student_id );
		if ( ! $class_id ) {
			return rest_ensure_response( array() );
		}

		$exams = get_posts( array(
			'post_type'      => 'adc_exam',
			'post_status'    => 'publish',
			'posts_per_page' => 20,
			// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
			'meta_key'       => 'adc_exam_class_id',
			// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
			'meta_value'     => $class_id,
		) );

		$schedule = Helper::exam_schedule_table();
		$out      = array();
		foreach ( $exams as $exam ) {
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$slots = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$schedule} WHERE exam_id = %d ORDER BY exam_date ASC, start_time ASC", $exam->ID ), ARRAY_A );
			$out[] = array(
				'id'    => (int) $exam->ID,
				'name'  => $exam->post_title,
				'date'  => (string) get_post_meta( $exam->ID, 'adc_exam_start_date', true ),
				'published' => (bool) get_post_meta( $exam->ID, 'adc_exam_is_published', true ),
				'slots' => array_map( function ( $slot ) {
					return array(
						'subject'    => $slot['subject_id'] ? get_the_title( (int) $slot['subject_id'] ) : '',
						'date'       => (string) $slot['exam_date'],
						'start_time' => (string) $slot['start_time'],
						'end_time'   => (string) $slot['end_time'],
						'room'       => (string) $slot['room'],
					);
				}, (array) $slots ),
			);
		}
		return rest_ensure_response( $out );
	}

	/**
	 * The facilities this student actually uses: their bus and stop, their room
	 * and bed, and the library books they still have out.
	 *
	 * @param \WP_REST_Request $request
	 */
	public function get_facilities( $request ) {
		global $wpdb;
		$student_id = (int) $request->get_param( 'student_id' );
		$table      = Helper::records_table();

		$rows = function ( $module ) use ( $wpdb, $table ) {
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$found = $wpdb->get_results( $wpdb->prepare( "SELECT id, title, data FROM {$table} WHERE module = %s", $module ), ARRAY_A );
			return array_map( function ( $row ) {
				$row['data'] = (array) json_decode( (string) $row['data'], true );
				return $row;
			}, (array) $found );
		};

		$mine = function ( $rows, $key ) use ( $student_id ) {
			return array_values( array_filter( $rows, function ( $row ) use ( $student_id, $key ) {
				return (int) ( $row['data'][ $key ] ?? 0 ) === $student_id;
			} ) );
		};

		$assets = function ( $rows ) {
			$out = array();
			foreach ( $rows as $row ) {
				$out[ (int) $row['id'] ] = $row;
			}
			return $out;
		};

		$routes = $assets( $rows( 'transport' ) );
		$rooms  = $assets( $rows( 'hostel' ) );
		$books  = $assets( $rows( 'library' ) );

		$transport = array();
		foreach ( $mine( $rows( 'transport_assignment' ), 'student_id' ) as $row ) {
			if ( 'active' !== ( $row['data']['status'] ?? '' ) ) {
				continue;
			}
			$route       = $routes[ (int) ( $row['data']['route'] ?? 0 ) ] ?? null;
			$transport[] = array(
				'route'        => $route ? $route['title'] : '',
				'pickup_point' => (string) ( $row['data']['pickup_point'] ?? '' ),
				'vehicle_no'   => $route ? (string) ( $route['data']['vehicle_no'] ?? '' ) : '',
				'driver'       => $route ? (string) ( $route['data']['driver'] ?? '' ) : '',
				'driver_phone' => $route ? (string) ( $route['data']['driver_phone'] ?? '' ) : '',
			);
		}

		$hostel = array();
		foreach ( $mine( $rows( 'hostel_allocation' ), 'student_id' ) as $row ) {
			if ( 'active' !== ( $row['data']['status'] ?? '' ) ) {
				continue;
			}
			$room     = $rooms[ (int) ( $row['data']['room_id'] ?? 0 ) ] ?? null;
			$hostel[] = array(
				'room'   => $room ? $room['title'] : '',
				'bed'    => (string) ( $row['data']['bed'] ?? '' ),
				'warden' => $room ? (string) ( $room['data']['warden'] ?? '' ) : '',
				'from'   => (string) ( $row['data']['from_date'] ?? '' ),
			);
		}

		$library = array();
		foreach ( $mine( $rows( 'library_issue' ), 'member' ) as $row ) {
			if ( 'returned' === ( $row['data']['status'] ?? '' ) ) {
				continue;
			}
			$book      = $books[ (int) ( $row['data']['book_id'] ?? 0 ) ] ?? null;
			$library[] = array(
				'book'     => $book ? $book['title'] : $row['title'],
				'author'   => $book ? (string) ( $book['data']['author'] ?? '' ) : '',
				'due_date' => (string) ( $row['data']['due_date'] ?? '' ),
				'overdue'  => ! empty( $row['data']['due_date'] ) && $row['data']['due_date'] < gmdate( 'Y-m-d' ),
			);
		}

		return rest_ensure_response( compact( 'transport', 'hostel', 'library' ) );
	}

	/**
	 * The section this student is enrolled in.
	 *
	 * @param int $student_id
	 */
	private function section_of( $student_id ) {
		$admission = class_exists( '\AcademyDigitalCampus\Helper' )
			? \AcademyDigitalCampus\Helper::get_student_admission( (int) $student_id )
			: array();
		return (int) ( $admission['section_id'] ?? 0 );
	}

	/**
	 * The class this student is enrolled in.
	 *
	 * @param int $student_id
	 */
	private function class_of( $student_id ) {
		$admission = class_exists( '\AcademyDigitalCampus\Helper' )
			? \AcademyDigitalCampus\Helper::get_student_admission( (int) $student_id )
			: array();
		return (int) ( $admission['class_id'] ?? 0 );
	}
}
