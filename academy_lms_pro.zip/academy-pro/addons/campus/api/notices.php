<?php
namespace AcademyProCampus\API;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AcademyProCampus\Helper;
use WP_Error;

/**
 * Notices / announcements targeted at everyone, a class, a section or parents.
 *
 * Route: academy/v1/sis/notices        (manager CRUD)
 * academy/v1/sis/my-notices     (logged-in: notices relevant to me)
 */
class Notices extends \WP_REST_Controller {

	public static function init() {
		$self            = new self();
		$self->namespace = ACADEMY_DIGITAL_CAMPUS_PLUGIN_SLUG . '/v1';
		add_action( 'rest_api_init', array( $self, 'register_routes' ) );
	}

	public function register_routes() {
		register_rest_route( $this->namespace, '/sis/notices', array(
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_items' ),
				'permission_callback' => array( 'AcademyProCampus\\Helper', 'manager_check' ),
			),
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'create_item' ),
				'permission_callback' => array( 'AcademyProCampus\\Helper', 'manager_check' ),
			),
		) );
		register_rest_route( $this->namespace, '/sis/notices/(?P<id>\d+)', array(
			array(
				'methods'             => \WP_REST_Server::DELETABLE,
				'callback'            => array( $this, 'delete_item' ),
				'permission_callback' => array( 'AcademyProCampus\\Helper', 'manager_check' ),
			),
		) );
		register_rest_route( $this->namespace, '/sis/notices/(?P<id>\d+)/read', array(
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'mark_read' ),
				'permission_callback' => function () {
					return is_user_logged_in();
				},
			),
		) );
		register_rest_route( $this->namespace, '/sis/my-notices', array(
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'my_notices' ),
				'permission_callback' => function () {
					return is_user_logged_in();
				},
			),
		) );
	}

	public function get_items( $request ) {
		global $wpdb;
		$table = Helper::notices_table();
		$reads = Helper::notice_reads_table();
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- only $wpdb-prefixed table names, whitelisted columns and intval/placeholder lists are interpolated; values are prepared
		$rows = $wpdb->get_results(
			"SELECT n.*, ( SELECT COUNT(*) FROM {$reads} r WHERE r.notice_id = n.id ) AS read_count
			 FROM {$table} n ORDER BY n.pinned DESC, n.id DESC LIMIT 200",
			ARRAY_A
		);
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		return rest_ensure_response( array_map( array( $this, 'decorate' ), $rows ? $rows : array() ) );
	}

	public function create_item( $request ) {
		global $wpdb;
		$table = Helper::notices_table();
		$title = sanitize_text_field( (string) $request->get_param( 'title' ) );
		if ( '' === $title ) {
			return new WP_Error( 'invalid', __( 'A title is required.', 'academy-pro' ), array( 'status' => 400 ) );
		}
		$audience = in_array( $request->get_param( 'audience' ), array( 'all', 'class', 'section', 'parents' ), true )
			? $request->get_param( 'audience' ) : 'all';
		$priority = in_array( $request->get_param( 'priority' ), array( 'normal', 'high', 'emergency' ), true )
			? $request->get_param( 'priority' ) : 'normal';

		// Channels: emergency notices also push over SMS/WhatsApp when enabled.
		$channels = array_values( array_intersect(
			(array) ( $request->get_param( 'channels' ) ? $request->get_param( 'channels' ) : array( 'email' ) ),
			array( 'email', 'sms', 'whatsapp' )
		) );
		if ( 'emergency' === $priority ) {
			$channels = array_unique( array_merge( $channels, array( 'email', 'sms', 'whatsapp' ) ) );
		}

		// Scheduling: a future publish_at holds the notice until the cron releases it.
		$publish_at = sanitize_text_field( (string) $request->get_param( 'publish_at' ) );
		$is_future  = $publish_at && strtotime( $publish_at ) > current_time( 'timestamp' );
		$status     = $is_future ? 'scheduled' : 'published';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->insert( $table, array(
			'title'          => $title,
			'body'           => wp_kses_post( (string) $request->get_param( 'body' ) ),
			'audience'       => $audience,
			'target_id'      => (int) $request->get_param( 'target_id' ),
			'pinned'         => $request->get_param( 'pinned' ) ? 1 : 0,
			'priority'       => $priority,
			'channels'       => implode( ',', $channels ? $channels : array( 'email' ) ),
			'attachment_url' => esc_url_raw( (string) $request->get_param( 'attachment_url' ) ),
			'status'         => $status,
			'publish_at'     => $publish_at ? $publish_at : null,
			'created_by'     => get_current_user_id(),
		) );
		$id = (int) $wpdb->insert_id;
		Helper::audit( 'notice', $id, 'created', $title );

		if ( 'published' === $status ) {
			self::publish_now( $id );
		}
		return rest_ensure_response( array(
			'id' => $id,
			'status' => $status
		) );
	}

	/**
	 * Dispatch a published notice to its audience via the Notifier.
	 *
	 * @param int $notice_id
	 */
	public static function publish_now( $notice_id ) {
		global $wpdb;
		$table = Helper::notices_table();
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$notice = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", (int) $notice_id ), ARRAY_A );
		if ( ! $notice ) {
			return;
		}
		$channels  = array_filter( explode( ',', (string) $notice['channels'] ) );
		$recipients = \AcademyProCampus\Notifier::audience_user_ids( $notice['audience'], (int) $notice['target_id'] );
		$body       = wp_strip_all_tags( (string) $notice['body'] );
		\AcademyProCampus\Notifier::dispatch( $recipients, $notice['title'], $body, $channels );
		do_action( 'academy_digital_campus/notice_published', (int) $notice_id, $notice['audience'] );
	}

	/**
	 * Cron: release scheduled notices whose time has arrived.
	 */
	public static function publish_scheduled() {
		global $wpdb;
		$table = Helper::notices_table();
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- only $wpdb-prefixed table names, whitelisted columns and intval/placeholder lists are interpolated; values are prepared
		$due = $wpdb->get_col( $wpdb->prepare(
			"SELECT id FROM {$table} WHERE status = 'scheduled' AND publish_at IS NOT NULL AND publish_at <= %s",
			current_time( 'mysql' )
		) );
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		foreach ( (array) $due as $id ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->update( $table, array( 'status' => 'published' ), array( 'id' => (int) $id ) );
			self::publish_now( (int) $id );
		}
	}

	/**
	 * Mark a notice as read for the current user (read confirmation).
	 *
	 * @param \WP_REST_Request $request
	 */
	public function mark_read( $request ) {
		global $wpdb;
		$table = Helper::notice_reads_table();
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- only $wpdb-prefixed table names, whitelisted columns and intval/placeholder lists are interpolated; values are prepared
		$wpdb->query( $wpdb->prepare(
			"INSERT IGNORE INTO {$table} (notice_id, user_id) VALUES (%d, %d)",
			(int) $request['id'], get_current_user_id()
		) );
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return rest_ensure_response( array( 'read' => true ) );
	}

	public function delete_item( $request ) {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->delete( Helper::notices_table(), array( 'id' => (int) $request['id'] ) );
		return rest_ensure_response( array( 'deleted' => true ) );
	}

	public function my_notices( $request ) {
		global $wpdb;
		$table   = Helper::notices_table();
		$user_id = get_current_user_id();

		$class_ids   = array();
		$section_ids = array();
		$is_parent   = user_can( $user_id, 'academy_is_parent' );

		if ( class_exists( '\AcademyDigitalCampus\Helper' ) ) {
			$student_ids = $is_parent ? \AcademyDigitalCampus\Helper::get_children_ids( $user_id ) : array( $user_id );
			foreach ( $student_ids as $sid ) {
				$adm = \AcademyDigitalCampus\Helper::get_student_admission( $sid );
				if ( $adm ) {
					if ( ! empty( $adm['class_id'] ) ) {
						$class_ids[] = (int) $adm['class_id'];
					}
					if ( ! empty( $adm['section_id'] ) ) {
						$section_ids[] = (int) $adm['section_id'];
					}
				}
			}
		}

		$where  = array( "audience = 'all'" );
		$params = array();
		if ( $is_parent ) {
			$where[] = "audience = 'parents'";
		}
		if ( $class_ids ) {
			$in      = implode( ',', array_fill( 0, count( $class_ids ), '%d' ) );
			$where[] = "(audience = 'class' AND target_id IN ($in))";
			$params  = array_merge( $params, $class_ids );
		}
		if ( $section_ids ) {
			$in      = implode( ',', array_fill( 0, count( $section_ids ), '%d' ) );
			$where[] = "(audience = 'section' AND target_id IN ($in))";
			$params  = array_merge( $params, $section_ids );
		}

		$where_sql = implode( ' OR ', $where );
		// Only published notices (older rows may have NULL status = published).
		$reads = Helper::notice_reads_table();
		$sql   = "SELECT n.*, ( SELECT COUNT(*) FROM {$reads} r WHERE r.notice_id = n.id AND r.user_id = %d ) AS is_read
			FROM {$table} n
			WHERE ( {$where_sql} ) AND ( n.status = 'published' OR n.status IS NULL OR n.status = '' )
			ORDER BY n.pinned DESC, n.id DESC LIMIT 50";
		$params = array_merge( array( $user_id ), $params );
		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $params ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- only $wpdb-prefixed table names, whitelisted columns and intval/placeholder lists are interpolated; values are prepared
		return rest_ensure_response( array_map( array( $this, 'decorate' ), $rows ? $rows : array() ) );
	}

	private function decorate( $row ) {
		$target = '';
		if ( 'class' === $row['audience'] || 'section' === $row['audience'] ) {
			$target = get_the_title( (int) $row['target_id'] );
		}
		$row['target_name'] = $target;
		$row['date']        = mysql2date( get_option( 'date_format' ), $row['created_at'] );
		return $row;
	}
}
