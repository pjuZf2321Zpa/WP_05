<?php
namespace AcademyProCampus;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Injects the pro metrics into the Campus dashboard endpoint
 * (academy_digital_campus/dashboard_data): today's attendance, pending fees,
 * revenue, upcoming exams, recent activities and notifications.
 */
class Dashboard {

	public static function init() {
		add_filter( 'academy_digital_campus/dashboard_data', array( __CLASS__, 'add_metrics' ) );
	}

	public static function add_metrics( $data ) {
		global $wpdb;
		$today = current_time( 'Y-m-d' );

		// Today's attendance.
		$att = Helper::attendance_table();
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$data['today_attendance'] = array(
			'present' => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$att} WHERE att_date = %s AND status = 'present'", $today ) ),
			'total'   => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$att} WHERE att_date = %s", $today ) ),
		);

		// Fees, straight from StoreEngine: what has been collected, and the
		// checkouts that were started but never paid.
		$fees = Billing::summary();
		$data['pending_fees'] = array(
			'count'  => $fees['unpaid_count'],
			'amount' => $fees['unpaid_amount'],
		);
		$data['revenue'] = array(
			'total'      => $fees['collected'],
			'this_month' => $fees['collected_this_month'],
		);

		// Recent activities (audit log).
		$audit = Helper::audit_table();
		$rows  = $wpdb->get_results( "SELECT object_type, action, note, created_at FROM {$audit} ORDER BY id DESC LIMIT 8", ARRAY_A );
		// phpcs:enable
		$data['recent_activities'] = array_map(
			function ( $r ) {
				return array(
					'object_type' => $r['object_type'],
					'action'      => $r['action'],
					'note'        => $r['note'],
					'date'        => mysql2date( get_option( 'date_format' ) . ' g:ia', $r['created_at'] ),
				);
			},
			$rows ? $rows : array()
		);

		// Notifications (recent notices).
		$notices = Helper::notices_table();
		$nrows = $wpdb->get_results( "SELECT title, audience, created_at FROM {$notices} ORDER BY id DESC LIMIT 6", ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- only $wpdb-prefixed table names, whitelisted columns and intval/placeholder lists are interpolated; values are prepared
		$data['notifications'] = array_map(
			function ( $n ) {
				return array(
					'title'    => $n['title'],
					'audience' => $n['audience'],
					'date'     => mysql2date( get_option( 'date_format' ), $n['created_at'] ),
				);
			},
			$nrows ? $nrows : array()
		);

		// Upcoming exams (published exams with a start date today or later).
		$exams = get_posts( array(
			'post_type'      => 'adc_exam',
			'post_status'    => 'publish',
			'posts_per_page' => 5,
			'meta_key'       => 'adc_exam_start_date', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
			'orderby'        => 'meta_value',
			'order'          => 'ASC',
			'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
				array(
					'key'     => 'adc_exam_start_date',
					'value'   => $today,
					'compare' => '>=',
					'type'    => 'DATE',
				),
			),
		) );
		$data['upcoming_exams'] = array(
			'count' => count( $exams ),
			'list'  => array_map(
				function ( $e ) {
					return array(
						'title' => $e->post_title,
						'date'  => mysql2date( get_option( 'date_format' ), get_post_meta( $e->ID, 'adc_exam_start_date', true ) ),
					);
				},
				$exams
			),
		);

		return $data;
	}
}
