<?php
namespace AcademyProCampus;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class API {

	public static function init() {
		API\ExamResults::init();
		API\Results::init();
		API\ReportCards::init();
		API\FeePlans::init();
		API\Billing::init();
		API\MyCampus::init();
		API\Teacher::init();
		API\Leave::init();
		API\Reports::init();
		API\Tools::init();
		API\AttendanceMarking::init();
		API\Timetable::init();
		API\Notices::init();
		API\Behavior::init();
		API\Audit::init();
		API\Records::init();
		API\ExamSchedule::init();
		// Applications (public admission + review) now ship in the free plugin so
		// they work without Pro. See AcademyDigitalCampus\API\Applications.
	}
}
