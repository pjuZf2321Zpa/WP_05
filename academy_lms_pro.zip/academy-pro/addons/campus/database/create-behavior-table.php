<?php
namespace AcademyProCampus\Database;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Student behaviour / discipline incidents.
 */
class CreateBehaviorTable {

	public static function up( $prefix, $charset_collate ) {
		$table_name = $prefix . 'adc_behavior';
		$sql        = "CREATE TABLE IF NOT EXISTS $table_name (
			id bigint(20) unsigned NOT NULL auto_increment,
			student_id bigint(20) unsigned NOT NULL,
			class_id bigint(20) DEFAULT 0,
			section_id bigint(20) DEFAULT 0,
			incident_date date DEFAULT NULL,
			type varchar(50) DEFAULT NULL,
			severity varchar(20) NOT NULL DEFAULT 'low',
			description text DEFAULT NULL,
			action_taken text DEFAULT NULL,
			follow_up_status varchar(20) NOT NULL DEFAULT 'open',
			parent_notified tinyint(1) NOT NULL DEFAULT 0,
			created_by bigint(20) DEFAULT NULL,
			created_at timestamp DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			KEY student_id (student_id)
		) $charset_collate;";
		dbDelta( $sql );
	}
}
