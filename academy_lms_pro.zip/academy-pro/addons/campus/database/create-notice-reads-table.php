<?php
namespace AcademyProCampus\Database;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Read receipts for notices (one row per user per notice).
 */
class CreateNoticeReadsTable {

	public static function up( $prefix, $charset_collate ) {
		$table_name = $prefix . 'adc_notice_reads';
		$sql        = "CREATE TABLE IF NOT EXISTS $table_name (
			id bigint(20) unsigned NOT NULL auto_increment,
			notice_id bigint(20) unsigned NOT NULL,
			user_id bigint(20) unsigned NOT NULL,
			read_at timestamp DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			UNIQUE KEY notice_user (notice_id, user_id)
		) $charset_collate;";
		dbDelta( $sql );
	}
}
