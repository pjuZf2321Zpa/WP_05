<?php
namespace AcademyProCampus\Database;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CreateNoticesTable {

	public static function up( $prefix, $charset_collate ) {
		$table_name = $prefix . 'adc_notices';
		$sql        = "CREATE TABLE IF NOT EXISTS $table_name (
			id bigint(20) unsigned NOT NULL auto_increment,
			title varchar(191) NOT NULL,
			body text DEFAULT NULL,
			audience varchar(20) NOT NULL DEFAULT 'all',
			target_id bigint(20) DEFAULT 0,
			pinned tinyint(1) NOT NULL DEFAULT 0,
			priority varchar(20) NOT NULL DEFAULT 'normal',
			channels varchar(100) DEFAULT 'email',
			attachment_url varchar(255) DEFAULT NULL,
			status varchar(20) NOT NULL DEFAULT 'published',
			publish_at datetime DEFAULT NULL,
			created_by bigint(20) DEFAULT NULL,
			created_at timestamp DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			KEY audience (audience, target_id)
		) $charset_collate;";
		dbDelta( $sql );

		// Add the newer columns explicitly for tables created before this batch.
		global $wpdb;
		$adds = array(
			'priority'       => "varchar(20) NOT NULL DEFAULT 'normal'",
			'channels'       => "varchar(100) DEFAULT 'email'",
			'attachment_url' => 'varchar(255) DEFAULT NULL',
			'status'         => "varchar(20) NOT NULL DEFAULT 'published'",
			'publish_at'     => 'datetime DEFAULT NULL',
		);
		foreach ( $adds as $col => $def ) {
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			if ( ! $wpdb->get_var( "SHOW COLUMNS FROM {$table_name} LIKE '{$col}'" ) ) {
				$wpdb->query( "ALTER TABLE {$table_name} ADD COLUMN {$col} {$def}" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange -- versioned one-time schema migration
			}
		}
	}
}
