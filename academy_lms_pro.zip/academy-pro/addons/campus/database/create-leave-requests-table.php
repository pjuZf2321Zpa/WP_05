<?php
namespace AcademyProCampus\Database;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Leave applications: a family asks for days off, the school answers.
 */
class CreateLeaveRequestsTable {

	public static function up( $prefix, $charset_collate ) {
		$table_name = $prefix . 'adc_leave_requests';
		$sql        = "CREATE TABLE IF NOT EXISTS $table_name (
			id bigint(20) unsigned NOT NULL auto_increment,
			student_id bigint(20) unsigned NOT NULL,
			class_id bigint(20) DEFAULT 0,
			section_id bigint(20) DEFAULT 0,
			start_date date NOT NULL,
			end_date date NOT NULL,
			days smallint(5) NOT NULL DEFAULT 1,
			type varchar(20) NOT NULL DEFAULT 'sick',
			reason text DEFAULT NULL,
			attachment_url varchar(255) DEFAULT NULL,
			status varchar(20) NOT NULL DEFAULT 'pending',
			decision_note varchar(191) DEFAULT NULL,
			requested_by bigint(20) DEFAULT NULL,
			decided_by bigint(20) DEFAULT NULL,
			decided_at datetime DEFAULT NULL,
			created_at timestamp DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			KEY student_id (student_id),
			KEY section_status (section_id, status)
		) $charset_collate;";
		dbDelta( $sql );
	}
}
