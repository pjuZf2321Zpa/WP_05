<?php
namespace AcademyProCampus\Database;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Timetable slots: one row per (section, weekday, period).
 */
class CreateTimetableTable {

	public static function up( $prefix, $charset_collate ) {
		$table_name = $prefix . 'adc_timetable';
		$sql        = "CREATE TABLE IF NOT EXISTS $table_name (
			id bigint(20) unsigned NOT NULL auto_increment,
			section_id bigint(20) unsigned NOT NULL,
			weekday tinyint(1) NOT NULL,
			period_no int(11) NOT NULL,
			subject_id bigint(20) unsigned DEFAULT 0,
			teacher_id bigint(20) unsigned DEFAULT 0,
			room varchar(100) DEFAULT NULL,
			start_time varchar(20) DEFAULT NULL,
			end_time varchar(20) DEFAULT NULL,
			created_at timestamp DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			UNIQUE KEY slot (section_id, weekday, period_no),
			KEY section_id (section_id)
		) $charset_collate;";
		dbDelta( $sql );
	}
}
