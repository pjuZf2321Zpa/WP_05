<?php
namespace AcademyProCampus\Database;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Fee plans.
 *
 * `source_module` / `source_id` bind a plan to the facility that generates it —
 * a bus route, a hostel room — so its members are the people who owe it. A plan
 * without them bills a class.
 */
class CreateFeePlansTable {

	public static function up( $prefix, $charset_collate ) {
		$table_name = $prefix . 'adc_fee_plans';
		$sql        = "CREATE TABLE IF NOT EXISTS $table_name (
			id bigint(20) unsigned NOT NULL auto_increment,
			name varchar(191) NOT NULL,
			class_id bigint(20) DEFAULT NULL,
			academic_year_id bigint(20) DEFAULT NULL,
			term_id bigint(20) DEFAULT NULL,
			amount decimal(12,2) NOT NULL DEFAULT 0,
			frequency varchar(20) NOT NULL DEFAULT 'one-time',
			components longtext DEFAULT NULL,
			status varchar(20) NOT NULL DEFAULT 'active',
			source_module varchar(30) DEFAULT NULL,
			source_id bigint(20) DEFAULT NULL,
			created_at timestamp DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			KEY class_id (class_id),
			KEY source (source_module, source_id)
		) $charset_collate;";
		dbDelta( $sql );

		// dbDelta can miss added columns on some MySQL/collation combos.
		global $wpdb;
		foreach ( array(
			'source_module' => 'varchar(30) DEFAULT NULL',
			'source_id' => 'bigint(20) DEFAULT NULL'
		) as $column => $definition ) {
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			if ( ! $wpdb->get_var( "SHOW COLUMNS FROM {$table_name} LIKE '{$column}'" ) ) {
				$wpdb->query( "ALTER TABLE {$table_name} ADD COLUMN {$column} {$definition}" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQLPlaceholders.QuotedDynamicPlaceholderGeneration, WordPress.DB.DirectDatabaseQuery.SchemaChange -- versioned one-time schema migration
			}
		}
	}
}
