<?php
namespace AcademyProCampus\Database;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CreateExamResultsTable {

	public static function up( $prefix, $charset_collate ) {
		$table_name = $prefix . 'adc_exam_results';
		$sql        = "CREATE TABLE IF NOT EXISTS $table_name (
			id bigint(20) unsigned NOT NULL auto_increment,
			exam_id bigint(20) unsigned NOT NULL,
			subject_id bigint(20) unsigned NOT NULL,
			student_id bigint(20) unsigned NOT NULL,
			obtained_marks decimal(9,2) DEFAULT NULL,
			total_marks decimal(9,2) DEFAULT NULL,
			grade varchar(20) DEFAULT NULL,
			remarks text DEFAULT NULL,
			entered_by bigint(20) DEFAULT NULL,
			created_at timestamp DEFAULT CURRENT_TIMESTAMP,
			updated_at timestamp DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			UNIQUE KEY exam_subject_student (exam_id, subject_id, student_id),
			KEY student_id (student_id)
		) $charset_collate;";
		dbDelta( $sql );
	}
}
