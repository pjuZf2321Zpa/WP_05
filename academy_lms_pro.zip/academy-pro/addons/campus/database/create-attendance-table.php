<?php
namespace AcademyProCampus\Database;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Section/date based daily attendance (distinct from the course-based
 * attendance addon; this is the SIS roster attendance).
 */
class CreateAttendanceTable {

	public static function up( $prefix, $charset_collate ) {
		$table_name = $prefix . 'adc_attendance';
		$sql        = "CREATE TABLE IF NOT EXISTS $table_name (
			id bigint(20) unsigned NOT NULL auto_increment,
			section_id bigint(20) unsigned NOT NULL,
			subject_id bigint(20) unsigned NOT NULL DEFAULT 0,
			student_id bigint(20) unsigned NOT NULL,
			att_date date NOT NULL,
			status varchar(20) NOT NULL DEFAULT 'present',
			remarks varchar(191) DEFAULT NULL,
			marked_by bigint(20) DEFAULT NULL,
			created_at timestamp DEFAULT CURRENT_TIMESTAMP,
			updated_at timestamp DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			UNIQUE KEY roster_day (section_id, subject_id, student_id, att_date),
			KEY student_id (student_id)
		) $charset_collate;";
		dbDelta( $sql );
	}
}
