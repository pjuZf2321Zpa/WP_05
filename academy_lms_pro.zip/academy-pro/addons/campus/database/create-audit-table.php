<?php
namespace AcademyProCampus\Database;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CreateAuditTable {

	public static function up( $prefix, $charset_collate ) {
		$table_name = $prefix . 'adc_audit';
		$sql        = "CREATE TABLE IF NOT EXISTS $table_name (
			id bigint(20) unsigned NOT NULL auto_increment,
			object_type varchar(30) NOT NULL,
			object_id bigint(20) DEFAULT 0,
			action varchar(50) NOT NULL,
			note varchar(255) DEFAULT NULL,
			actor_id bigint(20) DEFAULT NULL,
			created_at timestamp DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			KEY object (object_type, object_id)
		) $charset_collate;";
		dbDelta( $sql );
	}
}
