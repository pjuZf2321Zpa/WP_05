<?php
namespace AcademyProCampus\Database;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Shared store for the facility modules (library, transport, hostel).
 *
 * `campus_id` scopes a record to one branch; NULL means it belongs to the
 * school as a whole and shows wherever you look.
 * Each record's module-specific fields live in the JSON `data` column.
 */
class CreateRecordsTable {

	public static function up( $prefix, $charset_collate ) {
		$table_name = $prefix . 'adc_records';
		$sql        = "CREATE TABLE IF NOT EXISTS $table_name (
			id bigint(20) unsigned NOT NULL auto_increment,
			module varchar(30) NOT NULL,
			campus_id bigint(20) DEFAULT NULL,
			title varchar(191) NOT NULL,
			data longtext DEFAULT NULL,
			created_at timestamp DEFAULT CURRENT_TIMESTAMP,
			updated_at timestamp DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			KEY module (module),
			KEY campus_id (campus_id)
		) $charset_collate;";
		dbDelta( $sql );

		// dbDelta can miss a single added column on some MySQL/collation
		// combos, so add `campus_id` explicitly when upgrading an older table.
		global $wpdb;
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$has_campus = $wpdb->get_var( "SHOW COLUMNS FROM {$table_name} LIKE 'campus_id'" );
		if ( ! $has_campus ) {
			$wpdb->query( "ALTER TABLE {$table_name} ADD COLUMN campus_id bigint(20) DEFAULT NULL AFTER module" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQLPlaceholders.QuotedDynamicPlaceholderGeneration, WordPress.DB.DirectDatabaseQuery.SchemaChange -- versioned one-time schema migration
		}
	}
}
