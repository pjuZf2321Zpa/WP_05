<?php
namespace AcademyProCampus\Database;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CreateExamScheduleTable {

	public static function up( $prefix, $charset_collate ) {
		global $wpdb;
		$table_name = $prefix . 'adc_exam_schedule';
		$sql        = "CREATE TABLE IF NOT EXISTS $table_name (
			id bigint(20) unsigned NOT NULL auto_increment,
			exam_id bigint(20) unsigned NOT NULL,
			subject_id bigint(20) unsigned NOT NULL,
			exam_date date DEFAULT NULL,
			start_time varchar(20) DEFAULT NULL,
			end_time varchar(20) DEFAULT NULL,
			room varchar(100) DEFAULT NULL,
			invigilator_id bigint(20) unsigned DEFAULT NULL,
			created_at timestamp DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			UNIQUE KEY exam_subject (exam_id, subject_id),
			KEY exam_id (exam_id)
		) $charset_collate;";
		dbDelta( $sql );

		// dbDelta can miss single-column adds on existing tables — add explicitly.
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$has = $wpdb->get_var( "SHOW COLUMNS FROM {$table_name} LIKE 'invigilator_id'" );
		if ( ! $has ) {
			$wpdb->query( "ALTER TABLE {$table_name} ADD COLUMN invigilator_id bigint(20) unsigned DEFAULT NULL AFTER room" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange -- versioned one-time schema migration
		}
		// phpcs:enable
	}
}
