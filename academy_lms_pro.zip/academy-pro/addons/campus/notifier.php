<?php
namespace AcademyProCampus;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Central notification dispatcher for the campus modules.
 *
 * Email is delivered directly via wp_mail(). SMS / WhatsApp / push are handled
 * through the `academy_digital_campus/send_message` filter so a gateway addon
 * (or a site's own integration) can fulfil them with its own credentials —
 * without this plugin bundling any paid SDK, or asking a school to enter the
 * same API key twice. Such an addon enables its channels through the
 * `academy_digital_campus/comms_settings` filter.
 */
class Notifier {

	/**
	 * Communication settings (channels + provider config), with defaults.
	 */
	public static function settings() {
		$defaults = array(
			'email_enabled'    => true,
			'sms_enabled'      => false,
			'whatsapp_enabled' => false,
			'from_name'        => get_bloginfo( 'name' ),
			'sms_provider'     => '',
			'sms_api_key'      => '',
			'sms_sender_id'    => '',
			'whatsapp_provider' => '',
			'whatsapp_api_key' => '',
		);
		$saved = get_option( 'adc_comms_settings', array() );
		/**
		 * Channel settings. The campus admin no longer configures SMS or
		 * WhatsApp — a gateway integration owns those credentials, so it
		 * enables its own channels here rather than asking the school to type
		 * an API key into two plugins.
		 */
		return apply_filters(
			'academy_digital_campus/comms_settings',
			wp_parse_args( is_array( $saved ) ? $saved : array(), $defaults )
		);
	}

	/**
	 * Which channels are actually enabled (intersection of requested + settings).
	 *
	 * @param mixed $requested
	 */
	private static function enabled_channels( $requested ) {
		$s   = self::settings();
		$map = array(
			'email'    => ! empty( $s['email_enabled'] ),
			'sms'      => ! empty( $s['sms_enabled'] ),
			'whatsapp' => ! empty( $s['whatsapp_enabled'] ),
		);
		$requested = $requested ? $requested : array( 'email' );
		return array_values( array_filter( $requested, function ( $c ) use ( $map ) {
			return ! empty( $map[ $c ] );
		} ) );
	}

	/**
	 * Send a message to a set of users across the given channels.
	 *
	 * @param int[]    $user_ids Recipient user IDs.
	 * @param string   $subject  Subject / title.
	 * @param string   $message  Body (plain text; HTML allowed for email).
	 * @param string[] $channels e.g. ['email','sms']. Defaults to email.
	 * @return array  Per-channel counts of messages handed off.
	 */
	public static function dispatch( $user_ids, $subject, $message, $channels = null ) {
		$channels = self::enabled_channels( $channels );
		$settings = self::settings();
		$counts   = array(
			'email' => 0,
			'sms' => 0,
			'whatsapp' => 0
		);

		foreach ( array_unique( array_filter( array_map( 'intval', (array) $user_ids ) ) ) as $uid ) {
			$user = get_user_by( 'id', $uid );
			if ( ! $user ) {
				continue;
			}
			$phone = get_user_meta( $uid, 'adc_phone', true );

			foreach ( $channels as $channel ) {
				if ( 'email' === $channel && $user->user_email ) {
					$headers = array( 'From: ' . $settings['from_name'] . ' <' . get_option( 'admin_email' ) . '>' );
					if ( wp_mail( $user->user_email, $subject, $message, $headers ) ) { // phpcs:ignore WordPressVIPMinimum.Functions.RestrictedFunctions.wp_mail_wp_mail -- single transactional email
						++$counts['email'];
					}
					continue;
				}
				/**
				 * Gateway seam for SMS / WhatsApp / push. A handler should return
				 * true when it has delivered the message. Receives the resolved
				 * recipient + provider settings so it needs no other context.
				 *
				 * @param bool     $handled  Whether a handler delivered it.
				 * @param array    $context  channel, user, phone, subject, message, settings.
				 */
				$handled = apply_filters( 'academy_digital_campus/send_message', false, array(
					'channel'  => $channel,
					'user'     => $user,
					'phone'    => $phone,
					'subject'  => $subject,
					'message'  => $message,
					'settings' => $settings,
				) );
				if ( $handled && isset( $counts[ $channel ] ) ) {
					++$counts[ $channel ];
				}
			}//end foreach
		}//end foreach

		return $counts;
	}

	/**
	 * Notify a student's guardians (and the student) — used by behavior alerts,
	 * fee reminders, attendance alerts, etc.
	 *
	 * @param int    $student_id
	 * @param string $subject
	 * @param string $message
	 * @param mixed  $channels
	 */
	public static function notify_student_guardians( $student_id, $subject, $message, $channels = null ) {
		$user_ids = array( (int) $student_id );
		if ( class_exists( '\Academy\Guardian\Store' ) ) {
			$user_ids = array_merge( $user_ids, \Academy\Guardian\Store::get_guardians( (int) $student_id ) );
		} elseif ( class_exists( '\AcademyDigitalCampus\Helper' ) ) {
			global $wpdb;
			$map = \AcademyDigitalCampus\Helper::parent_map_table();
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$parents  = $wpdb->get_col( $wpdb->prepare( "SELECT parent_id FROM {$map} WHERE student_id = %d", (int) $student_id ) );
			$user_ids = array_merge( $user_ids, array_map( 'intval', (array) $parents ) );
		}
		return self::dispatch( $user_ids, $subject, $message, $channels );
	}

	/**
	 * Resolve a notice audience to concrete recipient user IDs.
	 *
	 * @param mixed $audience
	 * @param int   $target_id
	 */
	public static function audience_user_ids( $audience, $target_id ) {
		$student_ids = array();

		if ( 'section' === $audience && $target_id && class_exists( '\AcademyDigitalCampus\Helper' ) ) {
			$student_ids = \AcademyDigitalCampus\Helper::get_section_student_ids( (int) $target_id );
		} elseif ( 'class' === $audience && $target_id && class_exists( '\AcademyDigitalCampus\Helper' ) ) {
			global $wpdb;
			$adm         = \AcademyDigitalCampus\Helper::admissions_table();
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$student_ids = array_map( 'intval', $wpdb->get_col( $wpdb->prepare( "SELECT DISTINCT student_id FROM {$adm} WHERE class_id = %d", (int) $target_id ) ) );
		} elseif ( 'all' === $audience ) {
			$student_ids = get_users( array(
				'role' => 'academy_student',
				'fields' => 'ID'
			) );
		}

		$user_ids = array_map( 'intval', $student_ids );
		if ( 'parents' === $audience ) {
			return get_users( array(
				'role' => 'adc_parent',
				'fields' => 'ID'
			) );
		}

		// Include guardians of the resolved students.
		$guardians = array();
		if ( class_exists( '\Academy\Guardian\Store' ) ) {
			foreach ( $user_ids as $sid ) {
				$guardians = array_merge( $guardians, \Academy\Guardian\Store::get_guardians( $sid ) );
			}
		}
		return array_values( array_unique( array_merge( $user_ids, array_map( 'intval', $guardians ) ) ) );
	}
}
