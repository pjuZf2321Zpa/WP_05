<?php
namespace AcademyProCampus;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * What a school adds to Academy's parent–teacher messaging.
 *
 * The conversations themselves belong to the Guardian addon — they need a
 * family, not a school, and every Academy site with guardians wants them. Two
 * things are only true in a school, and they are all that lives here:
 *
 *  1. Who counts as "my child's teacher". On a plain LMS it is the author of a
 *     course the child is enrolled in. In a school it is the person who takes
 *     their section — the class teacher, and whoever holds a period on the
 *     routine — which is often nobody's course author.
 *  2. How the message is delivered. The campus Notifier already speaks email,
 *     SMS and WhatsApp through a school's own gateway, so it answers for
 *     delivery and Guardian's plain wp_mail steps aside.
 */
class MessagingBridge {

	public static function init() {
		add_filter( 'academy/guardian/message_contacts', array( __CLASS__, 'add_section_teachers' ), 10, 2 );
		add_filter( 'academy/guardian/notify_message', array( __CLASS__, 'notify' ), 10, 2 );
	}

	/**
	 * Add the teachers who actually stand in front of this student.
	 *
	 * @param array $contacts   teacher_id => [ 'roles' => string[], 'course_id' => int ].
	 * @param int   $student_id The child in question.
	 */
	public static function add_section_teachers( $contacts, $student_id ) {
		global $wpdb;

		if ( ! class_exists( '\AcademyDigitalCampus\Helper' ) ) {
			return $contacts;
		}
		$admission  = \AcademyDigitalCampus\Helper::get_student_admission( (int) $student_id );
		$section_id = (int) ( $admission['section_id'] ?? 0 );
		if ( ! $section_id ) {
			return $contacts;
		}

		$class_teacher = (int) get_post_meta( $section_id, 'adc_section_teacher_id', true );
		if ( $class_teacher ) {
			$contacts[ $class_teacher ]['roles'][] = function_exists( 'academy_digital_campus_term' )
				? sprintf(
					/* translators: %s: the institution's word for a class (e.g. Class, Batch). */
					__( '%s teacher', 'academy-pro' ),
					academy_digital_campus_term( 'class' )
				)
				: __( 'Class teacher', 'academy-pro' );
		}

		$table = Helper::timetable_table();
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- only $wpdb-prefixed table names, whitelisted columns and intval/placeholder lists are interpolated; values are prepared
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT DISTINCT teacher_id, subject_id FROM {$table} WHERE section_id = %d AND teacher_id > 0",
			$section_id
		), ARRAY_A );
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		foreach ( (array) $rows as $row ) {
			$teacher_id = (int) $row['teacher_id'];
			$subject    = $row['subject_id'] ? Helper::title( (int) $row['subject_id'] ) : '';
			if ( $subject ) {
				$contacts[ $teacher_id ]['roles'][] = $subject;
			} elseif ( ! isset( $contacts[ $teacher_id ] ) ) {
				$contacts[ $teacher_id ] = array( 'roles' => array() );
			}
		}

		return $contacts;
	}

	/**
	 * Deliver through the campus Notifier, so a school that has wired up SMS or
	 * WhatsApp gets these on it rather than email alone.
	 *
	 * @param bool  $handled Whether something has already delivered it.
	 * @param array $context The message: recipients, subject and message.
	 */
	public static function notify( $handled, $context ) {
		if ( $handled || empty( $context['recipients'] ) ) {
			return $handled;
		}
		Notifier::dispatch(
			(array) $context['recipients'],
			(string) $context['subject'],
			(string) $context['message']
		);
		return true;
	}
}
