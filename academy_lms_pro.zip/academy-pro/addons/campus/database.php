<?php
namespace AcademyProCampus;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Pro data model: the Exam CPT + exam-results / fee tables.
 */
class Database {

	public static function init() {
		$self = new self();
		add_action( 'init', array( $self, 'register_exam_post_type' ), 5 );
		add_action( 'rest_api_init', array( $self, 'register_exam_meta' ) );
	}

	public function register_exam_post_type() {
		register_post_type(
			'adc_exam',
			array(
				'labels'                => array(
					'name'          => __( 'Exams', 'academy-pro' ),
					'singular_name' => __( 'Exam', 'academy-pro' ),
					'add_new_item'  => __( 'Add New Exam', 'academy-pro' ),
					'edit_item'     => __( 'Edit Exam', 'academy-pro' ),
				),
				'public'                => false,
				'publicly_queryable'    => false,
				'show_ui'               => false,
				'show_in_menu'          => false,
				'hierarchical'          => false,
				'rewrite'               => array( 'slug' => 'academy-exam' ),
				'supports'              => array( 'title', 'editor', 'author', 'custom-fields' ),
				'show_in_rest'          => true,
				'rest_base'             => 'adc_exam',
				'rest_namespace'        => ACADEMY_DIGITAL_CAMPUS_PLUGIN_SLUG . '/v1',
				'rest_controller_class' => \AcademyDigitalCampus\Authorization\SisPostController::class,
				// Standard post caps; SIS gating via the controller + meta auth.
				'capability_type'       => 'post',
				'map_meta_cap'          => true,
			)
		);
	}

	public function register_exam_meta() {
		$fields = array(
			'adc_exam_class_id'         => 'integer',
			'adc_exam_academic_year_id' => 'integer',
			'adc_exam_term_id'          => 'integer',
			'adc_exam_type'             => 'string',
			'adc_exam_total_marks'      => 'number',
			'adc_exam_pass_marks'       => 'number',
			'adc_exam_start_date'       => 'string',
			'adc_exam_end_date'         => 'string',
			'adc_exam_is_published'     => 'boolean',
		);
		foreach ( $fields as $meta_key => $type ) {
			register_meta(
				'post',
				$meta_key,
				array(
					'object_subtype' => 'adc_exam',
					'type'           => $type,
					'single'         => true,
					'show_in_rest'   => true,
					'auth_callback'  => function () {
						return current_user_can( 'manage_adc_sis' );
					},
				)
			);
		}
	}

	public static function create_initial_custom_table() {
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		global $wpdb;
		$prefix          = $wpdb->prefix;
		$charset_collate = $wpdb->get_charset_collate();
		Database\CreateExamResultsTable::up( $prefix, $charset_collate );
		Database\CreateFeePlansTable::up( $prefix, $charset_collate );
		Database\CreateAttendanceTable::up( $prefix, $charset_collate );
		Database\CreateTimetableTable::up( $prefix, $charset_collate );
		Database\CreateNoticesTable::up( $prefix, $charset_collate );
		Database\CreateNoticeReadsTable::up( $prefix, $charset_collate );
		Database\CreateBehaviorTable::up( $prefix, $charset_collate );
		Database\CreateAuditTable::up( $prefix, $charset_collate );
		Database\CreateRecordsTable::up( $prefix, $charset_collate );
		Database\CreateExamScheduleTable::up( $prefix, $charset_collate );
		Database\CreateLeaveRequestsTable::up( $prefix, $charset_collate );
		// adc_applications is now created by the free plugin (always present).
	}
}
