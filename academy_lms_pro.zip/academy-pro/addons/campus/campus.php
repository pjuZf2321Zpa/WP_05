<?php
namespace AcademyProCampus;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Academy\Interfaces\AddonInterface;

/**
 * Academy Digital Campus — pro modules.
 *
 * These premium modules (Exams & Report Cards, Fees, Attendance, Timetable,
 * Notices, Analytics, Facilities, Multi-campus + the bridges to Academy's
 * attendance / calendar / grade-book addons) ship in Academy Pro but belong to
 * the standalone **Academy Digital Campus** free plugin. They therefore run
 * whenever that free plugin is active (detected via ACADEMY_DIGITAL_CAMPUS_VERSION)
 * — not via an Academy addon toggle.
 */
final class Campus implements AddonInterface {

	public function __construct() {
		$this->define_constants();
		$this->init_addon();
	}

	public static function init() {
		static $instance = false;
		if ( ! $instance ) {
			$instance = new self();
		}
		return $instance;
	}

	public function define_constants(): void {
		// Bumped for the adc_ schema (standalone Academy Digital Campus plugin);
		// the version change re-triggers maybe_install() to create the new tables.
		define( 'ACADEMY_PRO_CAMPUS_VERSION', '1.7.0' );
		define( 'ACADEMY_PRO_CAMPUS_DIR_PATH', ACADEMY_PRO_ADDONS_DIR_PATH . 'campus/' );
	}

	public function init_addon(): void {
		// Only run when the Academy Digital Campus free plugin is active — it
		// owns the SIS spine (class/section/subject CPTs + shared helpers). The
		// version constant is defined at the free plugin's file-load time, so it
		// is the only reliable "plugin present" signal available this early
		// (this addon boots during Academy core's `academy_loaded`, before the
		// free plugin's own `plugins_loaded` init has run).
		if ( ! defined( 'ACADEMY_DIGITAL_CAMPUS_VERSION' ) ) {
			return;
		}

		// Defer the actual module boot to the free plugin's init action. That
		// action fires ONLY after the free plugin passes its Academy-core
		// compatibility check — so the pro modules never run against a
		// half-loaded spine (e.g. if the free plugin bailed on an incompatible
		// core), independent of any core-version drift between the two plugins.
		if ( did_action( 'academy_digital_campus_init' ) ) {
			$this->boot_modules();
		} else {
			add_action( 'academy_digital_campus_init', array( $this, 'boot_modules' ) );
		}
	}

	/**
	 * Boot the pro campus modules. Runs once the free Digital Campus plugin has
	 * fully initialised (hooked to `academy_digital_campus_init`).
	 */
	public function boot_modules(): void {
		static $booted = false;
		if ( $booted ) {
			return;
		}
		$booted = true;

		// Self-heal install: the free plugin's own activation can't create the
		// pro tables, so create them here on the first load of a new version.
		$this->maybe_install();

		Database::init();
		API::init();
		Admin::init();
		Hooks::init();
		Dashboard::init();
		Billing::init();
		// Parent–teacher messaging lives in the Guardian addon; this only
		// tells it who a school's teachers are, and how to deliver.
		MessagingBridge::init();

		// Auto-invoice on enrollment / promotion (opt-in via payment settings).
		// Promotion re-fires admission_updated per student, so promoted students
		// are covered by the same listener.
		// Recurring fees are StoreEngine subscriptions now, so there is no
		// monthly invoice run to schedule: it renews them, retries them and
		// receipts them.
		wp_clear_scheduled_hook( 'academy_digital_campus/daily_fee_tick' );

		// Hourly tick: release scheduled notices whose publish time has arrived.
		add_action( 'academy_digital_campus/publish_notices', array( '\AcademyProCampus\API\Notices', 'publish_scheduled' ) );
		if ( ! wp_next_scheduled( 'academy_digital_campus/publish_notices' ) ) {
			wp_schedule_event( time() + ( 5 * MINUTE_IN_SECONDS ), 'hourly', 'academy_digital_campus/publish_notices' );
		}
	}

	/**
	 * Create the pro tables + grant exam caps once per version (idempotent),
	 * since there is no Academy addon-activation hook to trigger it anymore.
	 */
	private function maybe_install(): void {
		if ( \Academy\Options::get( \Academy\Options::PRO_DB_VERSIONS, 'campus' ) !== ACADEMY_PRO_CAMPUS_VERSION ) {
			$this->addon_activation_hook();
		}
	}

	/**
	 * Required by AddonInterface. Runs the pro installer (tables + exam caps)
	 * and flushes rewrites. Invoked from maybe_install() on first load of a new
	 * version.
	 */
	public function addon_activation_hook(): void {
		Installer::init();
		if ( class_exists( '\Academy\Helper' ) ) {
			\Academy\Helper::flush_rewrite_rules();
		}
	}
}
