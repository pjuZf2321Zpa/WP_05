<?php
namespace AcademyProCampus;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Helper {

	public static function exam_results_table() {
		global $wpdb;
		return $wpdb->prefix . 'adc_exam_results';
	}

	public static function fee_plans_table() {
		global $wpdb;
		return $wpdb->prefix . 'adc_fee_plans';
	}

	public static function attendance_table() {
		global $wpdb;
		return $wpdb->prefix . 'adc_attendance';
	}

	public static function timetable_table() {
		global $wpdb;
		return $wpdb->prefix . 'adc_timetable';
	}

	public static function notices_table() {
		global $wpdb;
		return $wpdb->prefix . 'adc_notices';
	}

	public static function audit_table() {
		global $wpdb;
		return $wpdb->prefix . 'adc_audit';
	}

	public static function notice_reads_table() {
		global $wpdb;
		return $wpdb->prefix . 'adc_notice_reads';
	}

	public static function behavior_table() {
		global $wpdb;
		return $wpdb->prefix . 'adc_behavior';
	}

	public static function records_table() {
		global $wpdb;
		return $wpdb->prefix . 'adc_records';
	}

	public static function exam_schedule_table() {
		global $wpdb;
		return $wpdb->prefix . 'adc_exam_schedule';
	}

	public static function leave_requests_table() {
		global $wpdb;
		return $wpdb->prefix . 'adc_leave_requests';
	}

	public static function applications_table() {
		global $wpdb;
		return $wpdb->prefix . 'adc_applications';
	}

	/**
	 * Write an audit-log entry.
	 *
	 * @param string $object_type
	 * @param int    $object_id
	 * @param string $action
	 * @param string $note
	 */
	public static function audit( $object_type, $object_id, $action, $note = '' ) {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->insert( self::audit_table(), array(
			'object_type' => $object_type,
			'object_id'   => (int) $object_id,
			'action'      => $action,
			'note'        => $note,
			'actor_id'    => get_current_user_id(),
		) );
	}

	public static function manager_check() {
		if ( ! is_user_logged_in() || ! current_user_can( 'manage_adc_sis' ) ) {
			return new \WP_Error( 'unauthorized', __( 'You are not allowed to manage campus modules.', 'academy-pro' ), array( 'status' => 401 ) );
		}
		return true;
	}

	public static function fees_check() {
		if ( ! is_user_logged_in() || ! current_user_can( 'manage_adc_fees' ) ) {
			return new \WP_Error( 'unauthorized', __( 'You are not allowed to manage fees.', 'academy-pro' ), array( 'status' => 401 ) );
		}
		return true;
	}

	/**
	 * Map a numeric percentage to a letter grade using a sensible default scale.
	 *
	 * @param mixed $percentage
	 */
	public static function grade_from_percentage( $percentage ) {
		$scale = apply_filters( 'academy_digital_campus/grade_scale', array(
			80 => 'A+',
			70 => 'A',
			60 => 'B',
			50 => 'C',
			40 => 'D',
			0  => 'F',
		) );
		foreach ( $scale as $threshold => $grade ) {
			if ( $percentage >= $threshold ) {
				return $grade;
			}
		}
		return 'F';
	}

	/**
	 * GPA points per letter grade (default GPA-5 scale, filterable).
	 */
	public static function grade_points_scale() {
		return apply_filters( 'academy_digital_campus/grade_points', array(
			'A+' => 5.0,
			'A'  => 4.0,
			'B'  => 3.0,
			'C'  => 2.0,
			'D'  => 1.0,
			'F'  => 0.0,
		) );
	}

	/**
	 * GPA points for a percentage (via its letter grade).
	 *
	 * @param mixed $percentage
	 */
	public static function grade_points( $percentage ) {
		$letter = self::grade_from_percentage( $percentage );
		$scale  = self::grade_points_scale();
		return isset( $scale[ $letter ] ) ? (float) $scale[ $letter ] : 0.0;
	}

	/**
	 * A post title as a person would read it.
	 *
	 * Note: get_the_title() runs wptexturize, so a section called "Grade 5 - A" comes
	 * back carrying `&#8211;`. React prints that literally, so the entity ends
	 * up on screen — decode it here, at the edge, rather than in every view.
	 *
	 * @param int $post_id
	 */
	public static function title( $post_id ) {
		return html_entity_decode( get_the_title( (int) $post_id ), ENT_QUOTES, 'UTF-8' );
	}

	/**
	 * Sections a teacher is responsible for: the ones they are class teacher
	 * of, the ones they hold a named period in, and the ones whose class
	 * assigns them a subject.
	 *
	 * @param int $teacher_id
	 */
	public static function teacher_sections( $teacher_id ) {
		global $wpdb;
		$found = array();

		$own = get_posts( array(
			'post_type'      => 'adc_section',
			'post_status'    => 'publish',
			'posts_per_page' => 100,
			'fields'         => 'ids',
			// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
			'meta_key'       => 'adc_section_teacher_id',
			// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
			'meta_value'     => (int) $teacher_id,
		) );
		foreach ( (array) $own as $id ) {
			$found[ (int) $id ] = true;
		}

		$table = self::timetable_table();
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$ids = $wpdb->get_col( $wpdb->prepare( "SELECT DISTINCT section_id FROM {$table} WHERE teacher_id = %d", (int) $teacher_id ) );
		foreach ( (array) $ids as $id ) {
			$found[ (int) $id ] = true;
		}

		// A subject teacher belongs to the room too. Naming a teacher on every
		// period is the exception, so relying on the two lookups above alone
		// would leave whoever teaches a subject with no register to take and no
		// marks to enter — they are assigned in the class's subject list.
		if ( class_exists( '\AcademyDigitalCampus\Helper' ) ) {
			foreach ( array_keys( \AcademyDigitalCampus\Helper::teacher_class_subjects( $teacher_id ) ) as $class_id ) {
				foreach ( \AcademyDigitalCampus\Helper::sections_of_class( $class_id ) as $section_id ) {
					$found[ (int) $section_id ] = true;
				}
			}
		}

		$out = array();
		foreach ( array_keys( $found ) as $section_id ) {
			if ( 'adc_section' !== get_post_type( $section_id ) ) {
				continue;
			}
			$class_id = (int) get_post_meta( $section_id, 'adc_section_class_id', true );
			$out[]    = array(
				'id'    => (int) $section_id,
				'name'  => self::title( $section_id ),
				'class' => $class_id ? self::title( $class_id ) : '',
			);
		}
		return $out;
	}

	/** Every section, for staff who may see any of them. */
	public static function all_sections() {
		$out = array();
		// phpcs:disable WordPress.WP.PostsPerPage.posts_per_page_posts_per_page -- admin picker list capped at 200
		foreach ( (array) get_posts( array(
			'post_type'      => 'adc_section',
			'post_status'    => 'publish',
			'posts_per_page' => 200,
			'orderby'        => 'title',
			'order'          => 'ASC',
		) ) as $section ) {
		// phpcs:enable WordPress.WP.PostsPerPage.posts_per_page_posts_per_page
			$class_id = (int) get_post_meta( $section->ID, 'adc_section_class_id', true );
			$out[]    = array(
				'id'    => (int) $section->ID,
				'name'  => html_entity_decode( $section->post_title, ENT_QUOTES, 'UTF-8' ),
				'class' => $class_id ? self::title( $class_id ) : '',
			);
		}
		return $out;
	}

	/**
	 * Whether this teacher answers for this section. Campus staff answer for
	 * every section — they already can from the admin screens.
	 *
	 * @param int $teacher_id
	 * @param int $section_id
	 */
	public static function teaches_section( $teacher_id, $section_id ) {
		if ( user_can( (int) $teacher_id, 'manage_adc_sis' ) ) {
			return true;
		}
		return in_array( (int) $section_id, wp_list_pluck( self::teacher_sections( (int) $teacher_id ), 'id' ), true );
	}

	/**
	 * Enrolled students of a section.
	 *
	 * @param int $section_id
	 */
	public static function section_roster( $section_id ) {
		global $wpdb;
		if ( ! class_exists( '\AcademyDigitalCampus\Helper' ) ) {
			return array();
		}
		$admissions = \AcademyDigitalCampus\Helper::admissions_table();
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- only $wpdb-prefixed table names, whitelisted columns and intval/placeholder lists are interpolated; values are prepared
		return array_map( 'intval', (array) $wpdb->get_col( $wpdb->prepare(
			"SELECT student_id FROM {$admissions} WHERE section_id = %d AND status = 'enrolled'",
			(int) $section_id
		) ) );
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	}

	/**
	 * Whether a bridged pro addon is currently active.
	 *
	 * @param string $slug
	 */
	public static function is_addon_active( $slug ) {
		return \Academy\Helper::get_addon_active_status( $slug );
	}
}
