<?php
namespace AcademyProCampus;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Bridge hooks — expose data from the existing pro addons (attendance,
 * calendar) scoped to SIS classes/sections so the Campus UI can render them.
 */
class Hooks {

	public static function init() {
		$self = new self();
		add_action( 'rest_api_init', array( $self, 'register_bridge_routes' ) );
		// The [academy_digital_campus_apply] shortcode + apply pipeline now ship
		// in the free plugin (AcademyDigitalCampus\Hooks) so they work without Pro.
	}

	public function register_bridge_routes() {
		$namespace = ACADEMY_DIGITAL_CAMPUS_PLUGIN_SLUG . '/v1';

		// Section attendance summary bridged from the attendance addon.
		register_rest_route(
			$namespace,
			'/sis/attendance-summary',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'attendance_summary' ),
					'permission_callback' => array( 'AcademyProCampus\\Helper', 'manager_check' ),
				),
			)
		);
	}

	/**
	 * Attendance for a section, derived from the mapped subject's course in the
	 * existing attendance addon. Degrades to an empty payload when that addon
	 * is inactive.
	 *
	 * @param \WP_REST_Request $request
	 */
	public function attendance_summary( $request ) {
		if ( ! Helper::is_addon_active( 'attendance' ) ) {
			return rest_ensure_response( array(
				'available' => false,
				'message'   => sprintf(
					/* translators: %s: the institution's lowercase word for a class (e.g. class, batch). */
					__( 'Enable the Attendance addon to track %s attendance.', 'academy-pro' ),
					function_exists( 'academy_digital_campus_term' )
						? strtolower( academy_digital_campus_term( 'class' ) )
						: __( 'class', 'academy-pro' )
				),
				'rows'      => array(),
			) );
		}

		global $wpdb;
		$section_id = (int) $request->get_param( 'section_id' );
		$subject_id = (int) $request->get_param( 'subject_id' );

		$course_id = 0;
		if ( $subject_id && $section_id && class_exists( '\AcademyDigitalCampus\Helper' ) ) {
			// The linked course is a per-class assignment detail; resolve it for
			// the class that owns this section.
			$course_id = \AcademyDigitalCampus\Helper::section_subject_course_id( $section_id, $subject_id );
		}

		$rows        = array();
		$student_ids = array();
		if ( $section_id && class_exists( '\AcademyDigitalCampus\Helper' ) ) {
			$student_ids = \AcademyDigitalCampus\Helper::get_section_student_ids( $section_id );
		}

		if ( $course_id && $student_ids ) {
			$att_table = $wpdb->prefix . ACADEMY_PLUGIN_SLUG . '_attendance_records';
			foreach ( $student_ids as $student_id ) {
				// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- only $wpdb-prefixed table names, whitelisted columns and intval/placeholder lists are interpolated; values are prepared
				$present = (int) $wpdb->get_var( $wpdb->prepare(
					"SELECT COUNT(id) FROM {$att_table} WHERE course_id = %d AND user_id = %d AND status = 'present'",
					$course_id, $student_id
				) );
				// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
				// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- only $wpdb-prefixed table names, whitelisted columns and intval/placeholder lists are interpolated; values are prepared
				$total = (int) $wpdb->get_var( $wpdb->prepare(
					"SELECT COUNT(id) FROM {$att_table} WHERE course_id = %d AND user_id = %d",
					$course_id, $student_id
				) );
				// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
				$student = get_user_by( 'id', $student_id );
				$rows[]  = array(
					'student_id'   => $student_id,
					'student_name' => $student ? $student->display_name : '',
					'present'      => $present,
					'total'        => $total,
					'percentage'   => $total > 0 ? round( ( $present / $total ) * 100, 1 ) : 0,
				);
			}//end foreach
		}//end if

		return rest_ensure_response( array(
			'available' => true,
			'course_id' => $course_id,
			'rows'      => $rows,
		) );
	}
}
