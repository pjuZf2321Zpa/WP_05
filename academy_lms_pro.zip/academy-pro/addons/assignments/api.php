<?php
namespace AcademyProAssignments;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AcademyProAssignments\Classes\Query;

class API extends \WP_REST_Controller {

	public static function init() {
		$self = new self();
		$self::api_execute();
		add_filter( 'academy/api/user/meta_values', array( $self, 'user_assignments_analytics' ) );
		add_filter( 'rest_prepare_academy_assignments', array( $self, 'add_author_name_to_rest_response' ), 10, 3 );
		add_filter( 'rest_prepare_academy_assignments', array( $self, 'decode_special_character' ), 10, 3 );
	}

	public static function api_execute() {
		$self            = new self();
		$self->namespace = ACADEMY_PRO_PLUGIN_SLUG . '/v1';
		$self->rest_base = 'assignments';
		add_action( 'rest_api_init', array( $self, 'register_routes' ) );
	}

	public function register_routes() {
		// GET /academy-pro/v1/assignments — retrieve assignment with student submission
		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base,
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_assignment' ),
					'permission_callback' => array( $this, 'check_permissions' ),
					'args'                => array(
						'course_id' => array(
							'required'          => true,
							'type'              => 'integer',
							'sanitize_callback' => 'absint',
							'description'       => esc_html__( 'Course ID.', 'academy-pro' ),
						),
						'assignment_id' => array(
							'required'          => true,
							'type'              => 'integer',
							'sanitize_callback' => 'absint',
							'description'       => esc_html__( 'Assignment post ID.', 'academy-pro' ),
						),
						'timezone' => array(
							'required'          => false,
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_text_field',
							'description'       => esc_html__( 'Student timezone string.', 'academy-pro' ),
						),
					),
				),
			)
		);

		// GET /academy-pro/v1/assignments/user — all submissions for the current student
		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/user',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_user_assignment_submissions' ),
					'permission_callback' => array( $this, 'check_permissions' ),
				),
			)
		);

		// POST /academy-pro/v1/assignments/start
		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/start',
			array(
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'start_assignment' ),
					'permission_callback' => array( $this, 'check_permissions' ),
					'args'                => array(
						'course_id' => array(
							'required'          => true,
							'type'              => 'integer',
							'sanitize_callback' => 'absint',
						),
						'assignment_id' => array(
							'required'          => true,
							'type'              => 'integer',
							'sanitize_callback' => 'absint',
						),
						'submitting_time' => array(
							'required'          => true,
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_text_field',
							'description'       => esc_html__( 'ISO 8601 datetime when student started.', 'academy-pro' ),
						),
					),
				),
			)
		);

		// POST /academy-pro/v1/assignments/submit
		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/submit',
			array(
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'submit_assignment' ),
					'permission_callback' => array( $this, 'check_permissions' ),
					'args'                => array(
						'course_id' => array(
							'required'          => true,
							'type'              => 'integer',
							'sanitize_callback' => 'absint',
						),
						'assignment_id' => array(
							'required'          => true,
							'type'              => 'integer',
							'sanitize_callback' => 'absint',
						),
						'assignment_comment_id' => array(
							'required'          => true,
							'type'              => 'integer',
							'sanitize_callback' => 'absint',
							'description'       => esc_html__( 'Comment ID returned by the start endpoint.', 'academy-pro' ),
						),
						'submitted_time' => array(
							'required'          => true,
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_text_field',
						),
						'assignment_answer' => array(
							'required'          => false,
							'type'              => 'string',
							'sanitize_callback' => 'wp_kses_post',
							'default'           => '',
						),
						'assignment_answers' => array(
							'required'    => false,
							'type'        => array( 'object', 'string' ),
							'description' => esc_html__( 'Map of question ID to answer HTML (or its JSON).', 'academy-pro' ),
						),
						'assignment_attachment' => array(
							'required'          => false,
							'type'              => 'integer',
							'sanitize_callback' => 'absint',
							'default'           => 0,
						),
					),
				),
			)
		);
	}

	public function user_assignments_analytics( $values ) {
		$values['total_assignments'] = Query::get_total_number_of_assignments_by_instructor_id( get_current_user_id() );
		return $values;
	}
	public function add_author_name_to_rest_response( $item, $post, $request ) {
		$author_data = get_userdata( $item->data['author'] );
		$item->data['author_name'] = $author_data ? $author_data->display_name : '';
		return $item;
	}
	public function decode_special_character( $item, $post, $request ) {
		$item->data['title']['rendered'] = html_entity_decode( $item->data['title']['rendered'] );
		return $item;
	}

	public function check_permissions( $request ) {
		$user_id  = get_current_user_id();
		$course_id = absint( $request->get_param( 'course_id' ) );

		if ( ! $user_id ) {
			return new \WP_Error(
				'rest_forbidden',
				esc_html__( 'You must be logged in to access assignments.', 'academy-pro' ),
				array( 'status' => 401 )
			);
		}

		if ( ! \Academy\Helper::is_enrolled( $course_id, $user_id ) ) {
			return new \WP_Error(
				'rest_forbidden',
				esc_html__( 'You must be enrolled in the course to access assignments.', 'academy-pro' ),
				array( 'status' => 403 )
			);
		}

		return true;
	}

	public function get_user_assignment_submissions( $request ) {
		$user_id = get_current_user_id();

		$comments = get_comments( array(
			'user_id' => $user_id,
			'type'    => 'academy_assignments',
			'status'  => 'any',
			'number'  => 100,
			'order'   => 'DESC',
			'orderby' => 'comment_date',
		) );

		$items = array();
		foreach ( $comments as $comment ) {
			$item               = Helper::prepare_submitted_assignment_item( $comment );
			$attachment_id      = (int) $item->meta['academy_pro_assignment_attachment'];
			$item->course_id    = (int) $comment->comment_parent;
			$item->course_title = get_the_title( (int) $comment->comment_parent );
			$item->attachment_url = $attachment_id ? wp_get_attachment_url( $attachment_id ) : '';
			$items[]            = $item;
		}

		return rest_ensure_response( $items );
	}

	public function get_assignment( $request ) {
		$course_id     = (int) $request->get_param( 'course_id' );
		$assignment_id = (int) $request->get_param( 'assignment_id' );
		$time_zone     = $request->get_param( 'timezone' ) ? $request->get_param( 'timezone' ) : date_default_timezone_get();
		$user_id       = get_current_user_id();

		$has_permission = \Academy\Helper::has_permission_to_access_curriculum( $course_id, $user_id, $assignment_id, 'assignment' );

		if ( ! $has_permission ) {
			return new \WP_Error(
				'rest_forbidden',
				esc_html__( 'Access Denied', 'academy-pro' ),
				array( 'status' => 403 )
			);
		}

		$assignment = get_post( $assignment_id );

		if ( ! $assignment ) {
			return new \WP_Error(
				'rest_not_found',
				esc_html__( 'Assignment not found.', 'academy-pro' ),
				array( 'status' => 404 )
			);
		}

		$assignment->post_content_rendered = \Academy\Helper::get_content_html( stripslashes( $assignment->post_content ) );

		$attachment_id      = (int) get_post_meta( $assignment_id, 'academy_assignment_attachment', true );
		$assignment->attachment = array(
			'ID'    => $attachment_id,
			'url'   => $attachment_id ? wp_get_attachment_url( $attachment_id ) : '',
			'title' => $attachment_id ? get_the_title( $attachment_id ) : '',
		);

		$assignment->settings  = get_post_meta( $assignment_id, 'academy_assignment_settings', true );
		$assignment->questions = Helper::get_questions( $assignment_id );

		$submitted_assignments = get_comments( array(
			'post_id'      => $assignment_id,
			'comment_type' => 'academy_assignments',
			'parent'       => $course_id,
			'user_id'      => $user_id,
			'status'       => array( 'submitted', 'submitting', 'pass', 'failed' ),
		) );

		$assignment->submitted_assignment = null;
		$assignment->resubmit_attempt     = 0;

		if ( ! empty( $submitted_assignments ) ) {
			$prepared                         = Helper::prepare_submitted_assignment_items( $submitted_assignments );
			$sub                              = current( $prepared );
			$attach_id                        = (int) ( $sub->meta['academy_pro_assignment_attachment'] ?? 0 );
			$sub->attachment_url              = $attach_id ? wp_get_attachment_url( $attach_id ) : '';
			$assignment->submitted_assignment = $sub;
			$assignment->resubmit_attempt     = (int) get_option( 'academy_pro_assignment_' . $submitted_assignments[0]->comment_ID . '_submission_attempt', 0 );
		}

		$assignment->submission_status = 'active';
		if ( Helper::is_assignment_submission_expired( $assignment, $time_zone ) ) {
			$assignment->submission_status = 'expired';
		}

		$assignment = apply_filters( 'academy_pro_assignments/frontend/evaluate_submitted_assignment', $assignment, $course_id, $user_id, $assignment_id );

		return rest_ensure_response( $assignment );
	}

	public function start_assignment( $request ) {
		$course_id       = (int) $request->get_param( 'course_id' );
		$assignment_id   = (int) $request->get_param( 'assignment_id' );
		$submitting_time = $request->get_param( 'submitting_time' );
		$current_user    = wp_get_current_user();

		if ( ! $this->user_can_access_course( $current_user->ID, $course_id ) ) {
			return new \WP_Error(
				'rest_forbidden',
				esc_html__( 'Access Denied', 'academy-pro' ),
				array( 'status' => 403 )
			);
		}

		$existing = get_comments( array(
			'post_id'      => $assignment_id,
			'parent'       => $course_id,
			'user_id'      => $current_user->ID,
			'comment_type' => 'academy_assignments',
			'status'       => array( 'submitted', 'submitting' ),
		) );

		if ( ! empty( $existing ) ) {
			return new \WP_Error(
				'rest_already_started',
				esc_html__( 'Assignment already started or submitted.', 'academy-pro' ),
				array( 'status' => 400 )
			);
		}

		$comment_id = wp_insert_comment( array(
			'comment_post_ID'      => $assignment_id,
			'comment_parent'       => $course_id,
			'user_id'              => $current_user->ID,
			'comment_author'       => $current_user->user_login,
			'comment_author_email' => $current_user->user_email,
			'comment_author_url'   => $current_user->user_url,
			'comment_approved'     => 'submitting',
			'comment_agent'        => 'academy',
			'comment_type'         => 'academy_assignments',
		) );

		if ( ! $comment_id ) {
			return new \WP_Error(
				'rest_insert_failed',
				esc_html__( 'Failed to start assignment.', 'academy-pro' ),
				array( 'status' => 500 )
			);
		}

		add_comment_meta( $comment_id, 'academy_pro_assignment_start_time', $submitting_time );

		$response = Helper::prepare_submitted_assignment_item( get_comment( $comment_id ) );

		return rest_ensure_response( $response );
	}

	public function submit_assignment( $request ) {
		$course_id             = (int) $request->get_param( 'course_id' );
		$assignment_id         = (int) $request->get_param( 'assignment_id' );
		$assignment_comment_id = (int) $request->get_param( 'assignment_comment_id' );
		$submitted_time        = $request->get_param( 'submitted_time' );
		$assignment_answer     = $request->get_param( 'assignment_answer' ) ?? '';
		$assignment_attachment = (int) $request->get_param( 'assignment_attachment' );
		$current_user          = wp_get_current_user();

		if ( ! $this->user_can_access_course( $current_user->ID, $course_id ) ) {
			return new \WP_Error(
				'rest_forbidden',
				esc_html__( 'Access Denied', 'academy-pro' ),
				array( 'status' => 403 )
			);
		}

		$started_assignment = get_comment( $assignment_comment_id );

		// Verify the comment belongs to this user, assignment, and course, and is still in progress.
		if (
			! $started_assignment ||
			(int) $started_assignment->user_id !== $current_user->ID ||
			(int) $started_assignment->comment_post_ID !== $assignment_id ||
			(int) $started_assignment->comment_parent !== $course_id ||
			'academy_assignments' !== $started_assignment->comment_type ||
			'submitting' !== $started_assignment->comment_approved
		) {
			return new \WP_Error(
				'rest_invalid_submission',
				esc_html__( 'Invalid submission reference.', 'academy-pro' ),
				array( 'status' => 400 )
			);
		}

		$assignment           = get_post( $assignment_id );
		$assignment->settings = get_post_meta( $assignment_id, 'academy_assignment_settings', true );
		$enable_resubmit      = (bool) get_post_meta( $assignment_id, 'academy_assignment_enable_resubmit', true );

		$submitted_assignments = get_comments( array(
			'post_id'      => $assignment_id,
			'comment_type' => 'academy_assignments',
			'user_id'      => $current_user->ID,
			'status'       => array( 'submitted', 'submitting' ),
		) );
		$submitted_assignments            = Helper::prepare_submitted_assignment_items( $submitted_assignments );
		$assignment->submitted_assignment = current( $submitted_assignments );

		if ( Helper::is_assignment_submission_expired( $assignment, date_default_timezone_get() ) ) {
			return new \WP_Error(
				'rest_submission_expired',
				esc_html__( 'Submission time has expired. Please contact your instructor.', 'academy-pro' ),
				array( 'status' => 400 )
			);
		}

		$questions = Helper::get_questions( $assignment_id );
		$answers   = Helper::sanitize_answers( $request->get_param( 'assignment_answers' ), $questions );
		if ( ! $answers && '' !== (string) $assignment_answer ) {
			$answers['_default'] = wp_kses_post( $assignment_answer );
		}
		if ( ! Helper::has_answer( $answers ) && ! $assignment_attachment ) {
			return new \WP_Error(
				'rest_empty_submission',
				esc_html__( 'Please provide an assignment answer or attachment.', 'academy-pro' ),
				array( 'status' => 400 )
			);
		}

		if ( $enable_resubmit ) {
			$resubmit_limit = (int) get_post_meta( $assignment_id, 'academy_assignment_resubmit_limit', true );
			$option_key     = 'academy_pro_assignment_' . $assignment_comment_id . '_submission_attempt';
			$attempt_count  = (int) get_option( $option_key, 0 );

			if ( $resubmit_limit > 0 && $attempt_count >= $resubmit_limit ) {
				return new \WP_Error(
					'rest_resubmit_limit',
					esc_html__( 'You have reached the maximum number of submission attempts.', 'academy-pro' ),
					array( 'status' => 400 )
				);
			}

			update_option( $option_key, $attempt_count + 1 );
		}

		list( $answers, $plain_content ) = Helper::save_submission_answers( $assignment_comment_id, $assignment_id, $answers );

		wp_update_comment( array(
			'comment_ID'       => $assignment_comment_id,
			'comment_post_ID'  => $assignment_id,
			'comment_content'  => wp_slash( $plain_content ),
			'comment_approved' => 'submitted',
		) );

		update_comment_meta( $assignment_comment_id, 'academy_pro_assignment_end_time', $submitted_time );
		if ( $assignment_attachment ) {
			update_comment_meta( $assignment_comment_id, 'academy_pro_assignment_attachment', $assignment_attachment );
		}

		$response = Helper::prepare_submitted_assignment_item( get_comment( $assignment_comment_id ) );

		do_action( 'academy_pro/frontend/submitted_assignment', $response );
		do_action( 'academy_pro_assignment/after_submit_assignment', $assignment_id, $current_user->ID, $course_id );

		return rest_ensure_response( $response );
	}

	/**
	 * Check whether a user can access a course as admin, instructor, enrolled student, or via public access.
	 *
	 * @param int $user_id
	 * @param int $course_id
	 */
	private function user_can_access_course( int $user_id, int $course_id ): bool {
		return current_user_can( 'manage_options' )
			|| \Academy\Helper::is_instructor_of_this_course( $user_id, $course_id )
			|| \Academy\Helper::is_enrolled( $course_id, $user_id )
			|| \Academy\Helper::is_public_course( $course_id );
	}
}
