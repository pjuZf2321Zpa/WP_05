<?php
namespace AcademyProAssignments;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Helper {
	public static function prepare_submitted_assignment_item( $submitted_assignment ) {
		$submitted_assignment->post_title = html_entity_decode( get_the_title( $submitted_assignment->comment_post_ID ) );
		$submitted_assignment->academy_assignment_settings = get_post_meta( $submitted_assignment->comment_post_ID, 'academy_assignment_settings', true );
		$submitted_assignment->academy_assignment_enable_resubmit = (bool) get_post_meta( $submitted_assignment->comment_post_ID, 'academy_assignment_enable_resubmit', true );
		$submitted_assignment->academy_assignment_resubmit_limit = get_post_meta( $submitted_assignment->comment_post_ID, 'academy_assignment_resubmit_limit', true ) ?? 0;
		$submitted_assignment->questions = self::get_questions( $submitted_assignment->comment_post_ID );
		$submitted_assignment->meta = array(
			'academy_pro_assignment_start_time' => get_comment_meta( $submitted_assignment->comment_ID, 'academy_pro_assignment_start_time', true ),
			'academy_pro_assignment_end_time' => get_comment_meta( $submitted_assignment->comment_ID, 'academy_pro_assignment_end_time', true ),
			'academy_pro_assignment_attachment' => (int) get_comment_meta( $submitted_assignment->comment_ID, 'academy_pro_assignment_attachment', true ),
			'academy_pro_assignment_evaluate_point' => (int) get_comment_meta( $submitted_assignment->comment_ID, 'academy_pro_assignment_evaluate_point', true ),
			'academy_pro_assignment_evaluate_feedback' => get_comment_meta( $submitted_assignment->comment_ID, 'academy_pro_assignment_evaluate_feedback', true ),
			'academy_pro_assignment_evaluate_feedback_type' => 'rich' === get_comment_meta( $submitted_assignment->comment_ID, 'academy_pro_assignment_evaluate_feedback_type', true ) ? 'rich' : 'plain',
			'academy_pro_assignment_answers' => self::get_submission_answers( $submitted_assignment ),
		);
		return $submitted_assignment;
	}
	/**
	 * Questions an instructor attached to an assignment. Empty for assignments
	 * created before multi-question support; those keep the single answer box.
	 *
	 * @param int $assignment_id Assignment post ID.
	 * @return array
	 */
	public static function get_questions( $assignment_id ) {
		$questions = get_post_meta( $assignment_id, 'academy_assignment_questions', true );
		return is_array( $questions ) ? array_values( $questions ) : [];
	}

	/**
	 * Meta sanitize callback: trims each question to the known shape, escapes
	 * according to the chosen plain/rich format and drops blank questions.
	 *
	 * @param mixed $questions Raw questions value.
	 * @return array
	 */
	public static function sanitize_questions( $questions ) {
		if ( ! is_array( $questions ) ) {
			return [];
		}
		$clean = [];
		$used  = [];
		foreach ( $questions as $question ) {
			if ( ! is_array( $question ) ) {
				continue;
			}
			$title_type = 'rich' === ( $question['title_type'] ?? '' ) ? 'rich' : 'plain';
			$desc_type  = 'rich' === ( $question['description_type'] ?? '' ) ? 'rich' : 'plain';
			$title      = (string) ( $question['title'] ?? '' );
			$desc       = (string) ( $question['description'] ?? '' );
			$title      = 'rich' === $title_type ? wp_kses_post( $title ) : sanitize_text_field( $title );
			$desc       = 'rich' === $desc_type ? wp_kses_post( $desc ) : sanitize_textarea_field( $desc );
			if ( '' === trim( wp_strip_all_tags( $title ) ) && '' === trim( wp_strip_all_tags( $desc ) ) ) {
				continue;
			}
			$id = sanitize_key( $question['id'] ?? '' );
			if ( '' === $id || '_default' === $id || in_array( $id, $used, true ) ) {
				$id = 'q' . substr( md5( uniqid( '', true ) ), 0, 10 );
			}
			$used[]  = $id;
			$clean[] = [
				'id'               => $id,
				'title'            => $title,
				'title_type'       => $title_type,
				'description'      => $desc,
				'description_type' => $desc_type,
			];
		}
		return $clean;
	}

	public static function is_answer_empty( $answer ) {
		$answer = (string) $answer;
		return '' === trim( wp_strip_all_tags( $answer ) ) && false === stripos( $answer, '<img' );
	}

	public static function has_answer( $answers ) {
		foreach ( (array) $answers as $id => $answer ) {
			// A note on its own isn't a submission.
			if ( '_note' !== $id && ! self::is_answer_empty( $answer ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Keeps only answers for known question IDs (plus the legacy `_default`
	 * single answer) and sanitizes each as post-level HTML.
	 *
	 * @param array|string $raw       Map of question ID => answer, or its JSON.
	 * @param array        $questions Assignment questions.
	 * @return array
	 */
	public static function sanitize_answers( $raw, $questions = [] ) {
		if ( is_string( $raw ) ) {
			$raw = json_decode( $raw, true );
		}
		if ( ! is_array( $raw ) ) {
			return [];
		}
		// `_default` is the single answer box, `_note` the student's optional
		// message to the instructor.
		$allowed = array_merge( [ '_default', '_note' ], wp_list_pluck( $questions, 'id' ) );
		$answers = [];
		foreach ( $raw as $question_id => $answer ) {
			if ( ! is_string( $answer ) || ! in_array( (string) $question_id, $allowed, true ) ) {
				continue;
			}
			$answers[ (string) $question_id ] = wp_kses_post( $answer );
		}
		return $answers;
	}

	/**
	 * Persists the answers on the submission and returns [ answers, plain text ].
	 *
	 * They live in comment meta, not in comment_content: WordPress runs
	 * comment_content through a tag allowlist for users without
	 * unfiltered_html (every student), which strips lists, headings and
	 * paragraphs from a rich answer. comment_content only keeps the plain-text
	 * copy for search and for older code that reads it.
	 *
	 * @param int          $comment_id    Submission comment ID.
	 * @param int          $assignment_id Assignment post ID.
	 * @param array|string $raw_answers   Map of question ID => answer.
	 * @param string       $legacy_answer Single-box answer from older clients.
	 * @return array
	 */
	public static function save_submission_answers( $comment_id, $assignment_id, $raw_answers, $legacy_answer = '' ) {
		$questions = self::get_questions( $assignment_id );
		$answers   = self::sanitize_answers( $raw_answers, $questions );
		if ( ! $answers && '' !== (string) $legacy_answer ) {
			$answers['_default'] = wp_kses_post( $legacy_answer );
		}
		// update_metadata() unslashes its input.
		update_comment_meta( $comment_id, 'academy_pro_assignment_answers', wp_slash( $answers ) );

		$plain = [];
		foreach ( $questions as $question ) {
			if ( isset( $answers[ $question['id'] ] ) ) {
				$plain[] = wp_strip_all_tags( $question['title'] ) . "\n" . wp_strip_all_tags( $answers[ $question['id'] ] );
			}
		}
		if ( isset( $answers['_default'] ) ) {
			$plain[] = wp_strip_all_tags( $answers['_default'] );
		}
		if ( isset( $answers['_note'] ) ) {
			$plain[] = wp_strip_all_tags( $answers['_note'] );
		}
		return [ $answers, implode( "\n\n", $plain ) ];
	}

	/**
	 * Answers of a submission as a map of question ID => HTML. Submissions made
	 * before multi-question support only have comment_content, exposed as
	 * `_default`.
	 *
	 * @param \WP_Comment $comment Submission comment.
	 * @return array
	 */
	public static function get_submission_answers( $comment ) {
		$answers = get_comment_meta( $comment->comment_ID, 'academy_pro_assignment_answers', true );
		if ( is_array( $answers ) && $answers ) {
			return $answers;
		}
		return '' !== trim( (string) $comment->comment_content ) ? [ '_default' => $comment->comment_content ] : [];
	}

	public static function prepare_submitted_assignment_items( $submitted_assignments ) {
		$response = [];
		foreach ( $submitted_assignments as $submitted_assignment ) {
			$response[] = self::prepare_submitted_assignment_item( $submitted_assignment );
		}
		return $response;
	}
	public static function get_hours_from_submission_time( $number, $unit ) {
		$hours = $number;
		if ( 'weeks' === $unit ) {
			$hours = $number * 7 * 24;
			return $hours .= ' hours';
		} elseif ( 'days' === $unit ) {
			$hours = $number * 24;
			return $hours .= ' hours';
		}
		if ( $hours <= 1 ) {
			return $hours . ' hour';
		}
		return $hours . ' hours';
	}
	public static function is_assignment_submission_expired( $assignment, $time_zone ) {
		if ( 0 !== $assignment->settings['submission_time'] && $assignment->submitted_assignment && 'submitting' === $assignment->submitted_assignment->comment_approved ) {
			$assignment_duration_hours = self::get_hours_from_submission_time( $assignment->settings['submission_time'], $assignment->settings['submission_time_unit'] );
			$assignment_last_submission_time = strtotime( $assignment->submitted_assignment->meta['academy_pro_assignment_start_time'] . "+ $assignment_duration_hours" );
			$current_time = strtotime( wp_date( 'Y-m-d H:i:s', null, new \DateTimeZone( $time_zone ) ) );
			$assignment->last_submission_timestamp = $assignment_last_submission_time;
			if ( $assignment_last_submission_time < $current_time ) {
				return true;
			}
		}
		return false;
	}
	public static function has_submitted_assignment( $course_id, $user_id ) {
		$submitted_assignments = get_comments(array(
			'post_id' => $course_id,
			'comment_type' => 'academy_assignments',
			'user_id'   => $user_id,
			'status' => array( 'submitted', 'pass', 'failed' ),
			'number' => 1
		));
		return $submitted_assignments;
	}
	public static function render_assignment_for_php_rendering( $course_id, $assignment_id ) {
		$course_id     = (int) sanitize_text_field( $course_id );
		$assignment_id = (int) sanitize_text_field( $assignment_id );
		$time_zone     = date_default_timezone_get();
		$user_id       = (int) get_current_user_id();

		$has_permission = \Academy\Helper::has_permission_to_access_curriculum( $course_id );

		if ( $has_permission ) {
			do_action( 'academy_pro_assignments/frontend/before_render_assignment', $course_id, $assignment_id );
			$assignment = get_post( $assignment_id );
			if ( ! $assignment ) {
				return esc_html__( 'Sorry, something went wrong!', 'academy-pro' );
			}
			$assignment->post_content_rendered = \Academy\Helper::get_content_html( stripslashes( $assignment->post_content ) );
			$attachment_id = (int) get_post_meta( $assignment_id, 'academy_assignment_attachment', true );
			$assignment->attachment = [
				'ID' => $attachment_id ? $attachment_id : (int) get_post_meta( $assignment_id, '_thumbnail_id', true ),
				'url' => $attachment_id ? wp_get_attachment_url( $attachment_id ) : '',
				'title' => $attachment_id ? get_the_title( $attachment_id ) : '',
			];
			$assignment->settings = get_post_meta( $assignment_id, 'academy_assignment_settings', true );
			$submitted_assignments = get_comments(array(
				'post_id' => $assignment->ID,
				'comment_type' => 'academy_assignments',
				'parent'    => $course_id,
				'user_id'   => $user_id,
				'status' => array( 'submitted', 'submitting', 'pass', 'failed' )
			));
			if ( $submitted_assignments ) {
				$submitted_assignments = self::prepare_submitted_assignment_items( $submitted_assignments );
				$assignment->submitted_assignment = current( $submitted_assignments );
			}
			$assignment->submission_status = 'active';
			if ( self::is_assignment_submission_expired( $assignment, $time_zone ) ) {
				$assignment->submission_status = 'expired';
			}
			$data = apply_filters( 'academy_pro_assignments/frontend/berfore_render_result', $assignment, $course_id, $user_id, $assignment_id );
			return $data;
		}//end if
		return esc_html__( 'Access Denied', 'academy-pro' );
	}
	public static function get_the_remaining_time_of_an_assignment_in_php_render( $time, $count, $assignment ) {
		$unit = strtoupper( $assignment->settings['submission_time_unit'][0] );
		$current_time = new \DateTime();
		$interval = ( 'H' === $unit ) ? "PT{$count}{$unit}" : "P{$count}{$unit}";
		$given_time = ( new \DateTime( $time ) )->add( new \DateInterval( $interval ) );
		$diff = $current_time->diff( $given_time );

		if ( $current_time > $given_time ) {
			$diff->invert = 1;
		}

		return $diff;
	}

	public static function get_date_time_translations( $unit ) {
		switch ( $unit ) {
			case 'weeks':
				return __( 'Weeks', 'academy-pro' );
			case 'days':
				return __( 'Days', 'academy-pro' );
			case 'hours':
				return __( 'Hours', 'academy-pro' );
			default:
				return $unit;
		}
	}
}
