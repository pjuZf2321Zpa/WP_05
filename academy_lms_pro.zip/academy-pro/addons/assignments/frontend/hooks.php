<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


// Frontend Dashboard
add_filter( 'academy/frontend_dashboard_menu_items', 'academy_pro_assignments_added_frontend_dashboard_menu', 10, 1 );

// Assignment Endpoint
add_action( 'academy_frontend_dashboard_assignments_endpoint', 'academy_pro_assignments_frontend_dashboard_assignments_page' );

/*
 * Load php rendering template hook
 */
add_action( 'academy/templates/curriculum/assignment_content', 'academy_pro_assignment_curriculum_assignment_content', 10, 2 );
add_action( 'admin_post_academy_pro_start_assignment', 'academy_pro_assignment_start_assignment' );
add_action( 'admin_post_academy_pro_submit_assignment', 'academy_pro_assignment_submit_assignment' );
