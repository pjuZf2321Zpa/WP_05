<?php
namespace AcademyProAssignments;

use Academy;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Academy\Classes\Sanitizer;
use Academy\Classes\AbstractAjaxHandler;

class Ajax extends AbstractAjaxHandler {
	protected $namespace = 'academy_pro_assignments';
	public function __construct() {
		$this->actions = array(
			'get_submitted_assignments' => array(
				'callback' => array( $this, 'get_submitted_assignments' ),
				'capability' => 'manage_academy_instructor',
			),
			'evaluate_submitted_assignment' => array(
				'callback' => array( $this, 'evaluate_submitted_assignment' ),
				'capability' => 'manage_academy_instructor',
			),
			'frontend/render_assignment' => array(
				'callback' => array( $this, 'render_assignment' ),
				'capability' => 'read',
			),
			'frontend/start_assignment' => array(
				'callback' => array( $this, 'start_assignment' ),
				'capability' => 'read',
			),
			'frontend/submit_assignment' => array(
				'callback' => array( $this, 'submit_assignment' ),
				'capability' => 'read',
			),
			'delete_submitted_assignment' => array(
				'callback' => array( $this, 'delete_submitted_assignment' ),
				'capability' => 'manage_academy_instructor'
			)
		);
		add_action( 'academy/frontend/before_mark_topic_complete', array( $this, 'mark_assignment_complete' ), 11, 4 );
	}

	public function get_submitted_assignments( $payload_data ) {
		$payload = Sanitizer::sanitize_payload( [
			'user_id' => 'integer',
			'page' => 'integer',
			'per_page' => 'integer',
			'search' => 'string',
			'status' => 'string'
		], $payload_data );

		// Authorize against the current user, never a caller-supplied user_id —
		// otherwise an instructor could pass another instructor's id and read that
		// instructor's students' submissions. Admins may target a specific
		// instructor via user_id.
		$user_id = current_user_can( 'manage_options' ) && ! empty( $payload['user_id'] )
			? (int) $payload['user_id']
			: get_current_user_id();
		$page = isset( $payload['page'] ) ? $payload['page'] : 1;
		$per_page = isset( $payload['per_page'] ) && 'null' !== $payload['per_page'] ? $payload['per_page'] : 10;
		$search = isset( $payload['search'] ) ? $payload['search'] : '';
		$status = isset( $payload['status'] ) ? $payload['status'] : 'all';
		$offset = ( $page - 1 ) * $per_page;
		$course_ids = \Academy\Helper::get_course_ids_by_instructor_id( $user_id );
		$author_in = array();
		if ( is_array( $course_ids ) && count( $course_ids ) ) {
			foreach ( $course_ids as $course_id ) {
				$instructors = \Academy\Helper::get_course_instructor( $course_id );

				foreach ( $instructors as $instructor ) {
					$author_in[] = $instructor->user_id;
				}
			}
		}

		$args = array(
			'comment_type' => 'academy_assignments',
			'status'       => 'any' === $status ? array( 'submitted', 'pass', 'failed' ) : $status,
		);
		// An administrator without an explicit instructor filter sees every
		// submission; scoping to post_author hid assignments written by instructors.
		$is_admin_overview = current_user_can( 'manage_options' ) && empty( $payload['user_id'] );
		if ( ! $is_admin_overview ) {
			if ( ! \Academy\Helper::get_addon_active_status( 'multi_instructor' ) && $user_id ) {
				$args['post_author'] = $user_id;
			} elseif ( count( $author_in ) === 1 ) {
				$args['post_author'] = $user_id;
			} else {
				$args['parent__in'] = $course_ids;
				$args['post_author__in'] = $author_in;
			}
		}

		$total_comments = count( get_comments( $args ) );

		// Set the x-wp-total header
		header( 'x-wp-total: ' . $total_comments );

		if ( ! empty( $search ) ) {
			$args['search'] = $search;
		}
		// pagination
		$args['offset'] = $offset;
		$args['number'] = $per_page;

		$submitted_assignments = get_comments( $args );
		$submitted_assignments = Helper::prepare_submitted_assignment_items( $submitted_assignments );
		$submitted_assignments = apply_filters( 'academy_pro_assignments/admin/submitted_assignments', $submitted_assignments );
		wp_send_json_success( $submitted_assignments );
	}
	public function evaluate_submitted_assignment( $payload_data ) {
		$payload = Sanitizer::sanitize_payload( [
			'comment_id' => 'integer',
			'evaluate_point' => 'integer',
			'minimum_passing_points' => 'integer',
			'evaluate_feedback_type' => 'string',
		], $payload_data );

		$comment_id = $payload['comment_id'];
		$evaluate_point = $payload['evaluate_point'];
		$minimum_passing_points = $payload['minimum_passing_points'];

		if ( ! $this->can_manage_submission( $comment_id ) ) {
			wp_send_json_error( __( 'Sorry, you are not allowed to evaluate this submission.', 'academy-pro' ) );
		}

		// Grading rules come from the assignment, not from the request: the
		// client-sent passing mark could otherwise be tampered with.
		$settings = get_post_meta( get_comment( $comment_id )->comment_post_ID, 'academy_assignment_settings', true );
		$settings = is_array( $settings ) ? $settings : [];
		if ( isset( $settings['minimum_passing_points'] ) ) {
			$minimum_passing_points = (int) $settings['minimum_passing_points'];
		}
		$total_points = (int) ( $settings['total_points'] ?? 0 );
		if ( $total_points > 0 ) {
			$evaluate_point = min( $evaluate_point, $total_points );
		}

		// Feedback is plain text (line breaks kept) or rich HTML, as the
		// instructor chose. sanitize_text_field would flatten both.
		$feedback_type     = 'rich' === ( $payload['evaluate_feedback_type'] ?? '' ) ? 'rich' : 'plain';
		$evaluate_feedback = (string) ( $payload_data['evaluate_feedback'] ?? '' );
		$evaluate_feedback = 'rich' === $feedback_type ? wp_kses_post( $evaluate_feedback ) : sanitize_textarea_field( $evaluate_feedback );

		update_comment_meta( $comment_id, 'academy_pro_assignment_evaluate_point', $evaluate_point );
		// update_metadata() unslashes its input.
		update_comment_meta( $comment_id, 'academy_pro_assignment_evaluate_feedback', wp_slash( $evaluate_feedback ) );
		update_comment_meta( $comment_id, 'academy_pro_assignment_evaluate_feedback_type', $feedback_type );

		// Update Assignment Status
		$comment_approved = $evaluate_point < $minimum_passing_points ? 'failed' : 'pass';

		$args = array(
			'comment_ID'         => $comment_id,
			'comment_approved'   => $comment_approved,
		);

		wp_update_comment( $args );

		$response = get_comment( $comment_id );
		$response = Helper::prepare_submitted_assignment_item( $response );
		do_action( 'academy_pro/frontend/evaluate_submitted_assignment', $response );

		// for gradebook integration
		$total_marks   = $total_points;
		if ( $evaluate_point < 0 ) {
			$evaluate_point = 0;
		} elseif ( $evaluate_point > $total_marks ) {
			$evaluate_point = $total_marks;
		}

		$earned_percentage = $total_marks > 0 ? ( $evaluate_point / $total_marks ) * 100 : 0;
		$passing_percentage = ( $minimum_passing_points > 0 && $total_marks > 0 ) ? ( $minimum_passing_points / $total_marks ) * 100 : 0;
		$evaluate_info = (object) array(
			'user_id'           => $response->user_id,
			'course_id'         => $response->comment_parent,
			'quiz_id'           => null,
			'assignment_id'     => get_comment( $comment_id )->comment_post_ID,
			'result_for'        => 'assignment',
			'earned_percentage' => $earned_percentage,
		);
		do_action( 'academy_pro/frontend/after_evaluate_assignment', $evaluate_info );

		// hooks for GamiPress integration
		if ( $earned_percentage >= $passing_percentage ) {
			do_action( 'academy_pro_assignment/after_evaluate_status_pass', get_comment( $comment_id )->comment_post_ID, $response->user_id, $response->comment_parent );
		} else {
			do_action( 'academy_pro_assignment/after_evaluate_status_fail', get_comment( $comment_id )->comment_post_ID, $response->user_id, $response->comment_parent );
		}

		$response = apply_filters( 'academy_pro_assignments/admin/before_evaluate_assignment', $response );

		wp_send_json_success( $response );
	}
	public function render_assignment( $payload_data ) {
		$payload = Sanitizer::sanitize_payload( [
			'course_id' => 'integer',
			'assignment_id' => 'integer',
			'time_zone' => 'string',
		], $payload_data );

		$course_id = $payload['course_id'];
		$assignment_id = $payload['assignment_id'];
		$time_zone = $payload['time_zone'];
		$user_id   = (int) get_current_user_id();

		$has_permission = \Academy\Helper::has_permission_to_access_curriculum( $course_id, $user_id, $assignment_id, 'assignment' );

		if ( $has_permission ) {
			do_action( 'academy_pro_assignments/frontend/before_render_assignment', $course_id, $assignment_id );
			$assignment = get_post( $assignment_id );
			if ( ! $assignment ) {
				wp_send_json_error( esc_html__( 'Sorry, something went wrong!', 'academy-pro' ) );
			}
			$assignment->post_content_rendered = \Academy\Helper::get_content_html( stripslashes( $assignment->post_content ) );
			$attachment_id = (int) get_post_meta( $assignment_id, 'academy_assignment_attachment', true );
			$assignment->attachment = [
				'ID' => $attachment_id ? $attachment_id : (int) get_post_meta( $assignment_id, '_thumbnail_id', true ),
				'url' => get_the_post_thumbnail_url( $assignment_id ),
			];
			$assignment->settings = get_post_meta( $assignment_id, 'academy_assignment_settings', true );
			$assignment->questions = Helper::get_questions( $assignment_id );
			$submitted_assignments = get_comments(array(
				'post_id' => $assignment->ID,
				'comment_type' => 'academy_assignments',
				'parent'    => $course_id,
				'user_id'   => $user_id,
				'status' => array( 'submitted', 'submitting', 'pass', 'failed' )
			));
			if ( $submitted_assignments ) {
				$submitted_assignments = Helper::prepare_submitted_assignment_items( $submitted_assignments );
				$assignment->submitted_assignment = current( $submitted_assignments );
				$assignment->resubmit_attempt = get_option( 'academy_pro_assignment_' . $submitted_assignments[0]->comment_ID . '_submission_attempt' );
			}
			$assignment->submission_status = 'active';
			if ( Helper::is_assignment_submission_expired( $assignment, $time_zone ) ) {
				$assignment->submission_status = 'expired';
			}
			$assignment = apply_filters( 'academy_pro_assignments/frontend/evaluate_submitted_assignment', $assignment, $course_id, $user_id, $assignment_id );
			wp_send_json_success( $assignment );
		}//end if
		wp_send_json_error( __( 'Access Denied', 'academy-pro' ) );
	}

	public function start_assignment( $payload_data ) {
		$payload = Sanitizer::sanitize_payload( [
			'course_id' => 'integer',
			'assignment_id' => 'integer',
			'submitting_time' => 'string',
			'timezone' => 'string',
		], $payload_data );

		$course_id              = $payload['course_id'];
		$assignment_id          = $payload['assignment_id'];
		$submitting_time        = $payload['submitting_time'];
		$time_zone              = $payload['time_zone'];
		$current_user           = wp_get_current_user();
		$is_administrator       = current_user_can( 'manage_options' );
		$is_instructor          = \Academy\Helper::is_instructor_of_this_course( $current_user->ID, $course_id );
		$is_enrolled               = \Academy\Helper::is_enrolled( $course_id, $current_user->ID );
		$is_public_course = \Academy\Helper::is_public_course( $course_id );

		$submitting_assignments = get_comments(array(
			'post_id'           => $assignment_id,
			'parent'    => $course_id,
			'user_id'   => $current_user->ID,
			'comment_type' => 'academy_assignments',
			'status' => array( 'submitted', 'submitting' )
		));

		if ( count( $submitting_assignments ) ) {
			wp_send_json_error( __( 'Already Submitted', 'academy-pro' ) );
		}

		if ( $is_administrator || $is_instructor || $is_enrolled || $is_public_course ) {
			$data = array(
				'comment_post_ID'      => $assignment_id,
				'comment_parent'       => $course_id,
				'user_id'              => $current_user->ID,
				'comment_author'       => $current_user->user_login,
				'comment_author_email' => $current_user->user_email,
				'comment_author_url'   => $current_user->user_url,
				'comment_approved'     => 'submitting',
				'comment_agent'        => 'academy',
				'comment_type'         => 'academy_assignments',
				'comment_meta'         => array(
					'academy_pro_assignment_start_time' => $submitting_time,
				)
			);
			$assignment_answer_id = wp_insert_comment( $data );
			$response = get_comment( $assignment_answer_id );
			$response = Helper::prepare_submitted_assignment_item( $response );
			wp_send_json_success( $response );
		}
		wp_send_json_error( __( 'Access Denied', 'academy-pro' ) );
	}
	public function submit_assignment( $payload_data ) {
		$payload = Sanitizer::sanitize_payload( [
			'course_id' => 'integer',
			'assignment_id' => 'integer',
			'assignment_comment_id' => 'integer',
			'submitted_time' => 'string',
			'time_zone' => 'string',
			'assignment_answer' => 'post',
			'assignment_attachment' => 'integer',
		], $payload_data );

		$course_id              = $payload['course_id'];
		$assignment_id          = $payload['assignment_id'];
		$assignment_comment_id  = $payload['assignment_comment_id'];
		$submitted_time         = $payload['submitted_time'];
		$time_zone              = $payload['time_zone'];
		$current_user           = wp_get_current_user();
		$is_administrator       = current_user_can( 'manage_options' );
		$is_instructor          = \Academy\Helper::is_instructor_of_this_course( $current_user->ID, $course_id );
		$is_enrolled               = \Academy\Helper::is_enrolled( $course_id, $current_user->ID );
		$is_public_course = \Academy\Helper::is_public_course( $course_id );
		$assignment_answer      = isset( $payload['assignment_answer'] ) ? $payload['assignment_answer'] : '';
		$assignment_attachment  = isset( $payload['assignment_attachment'] ) ? $payload['assignment_attachment'] : '';

		$started_assignment = get_comment( $assignment_comment_id );

		if ( ! $started_assignment ) {
			wp_send_json_error( __( 'Assignment Haven\'t started yet.', 'academy-pro' ) );
		}

		// The comment must be this user's own in-progress submission for this
		// assignment and course, never an arbitrary comment.
		if (
			(int) $started_assignment->user_id !== (int) $current_user->ID ||
			(int) $started_assignment->comment_post_ID !== (int) $assignment_id ||
			(int) $started_assignment->comment_parent !== (int) $course_id ||
			'academy_assignments' !== $started_assignment->comment_type ||
			! (
				'submitting' === $started_assignment->comment_approved ||
				( 'submitted' === $started_assignment->comment_approved && get_post_meta( $assignment_id, 'academy_assignment_enable_resubmit', true ) )
			)
		) {
			wp_send_json_error( __( 'Invalid submission reference.', 'academy-pro' ), 400 );
		}

		if ( $is_administrator || $is_instructor || $is_enrolled || $is_public_course ) {
			// first check submission is expired or not
			$assignment = get_post( $assignment_id );
			$assignment->settings = get_post_meta( $assignment_id, 'academy_assignment_settings', true );
			$enable_resubmit  = get_post_meta( $assignment_id, 'academy_assignment_enable_resubmit', true );
			// Scoped to the current user: without user_id this picked up another
			// student's in-progress submission and judged expiry against it.
			$submitted_assignments = get_comments(array(
				'post_id' => $assignment->ID,
				'comment_type' => 'academy_assignments',
				'user_id' => $current_user->ID,
				'status' => array( 'submitted', 'submitting' )
			));
			$submitted_assignments = Helper::prepare_submitted_assignment_items( $submitted_assignments );
			$assignment->submitted_assignment = current( $submitted_assignments );

			if ( Helper::is_assignment_submission_expired( $assignment, $time_zone ) ) {
				wp_send_json_error( __( 'Expired Your Submission. Contact with instructor', 'academy-pro' ) );
			}

			// One answer per question (JSON map), or the single legacy answer.
			$raw_answers = $payload_data['assignment_answers'] ?? '';
			$questions   = Helper::get_questions( $assignment_id );
			$answers     = Helper::sanitize_answers( $raw_answers, $questions );
			if ( ! $answers && '' !== $assignment_answer ) {
				$answers['_default'] = $assignment_answer;
			}
			if ( ! Helper::has_answer( $answers ) && ! $assignment_attachment ) {
				wp_send_json_error( __( 'Please provide an assignment answer or attachment.', 'academy-pro' ) );
			}

			// Check the attempt limit before saving, so a refused resubmit
			// doesn't overwrite the previous answer.
			$resubmit_limit = (int) get_post_meta( $assignment_id, 'academy_assignment_resubmit_limit', true );
			$option_key = 'academy_pro_assignment_' . $assignment_comment_id . '_submission_attempt';
			if ( $enable_resubmit && $resubmit_limit > 0 ) {
				$assignment_attempt = (int) get_option( $option_key, 0 );
				if ( $assignment_attempt >= $resubmit_limit ) {
					wp_send_json_error( __( 'You have reached the maximum number of submission attempts.', 'academy-pro' ) );
				}
			}

			list( $answers, $plain_content ) = Helper::save_submission_answers( $assignment_comment_id, $assignment_id, $answers );

			// Update comment
			$data = array(
				'comment_ID'           => $assignment_comment_id,
				'comment_post_ID'      => $assignment_id,
				'comment_content'      => wp_slash( $plain_content ),
				'comment_date_gmt'     => $started_assignment->comment_date_gmt,
				'comment_approved'     => 'submitted',
				'comment_meta'         => array(
					'academy_pro_assignment_end_time' => $submitted_time,
					'academy_pro_assignment_attachment' => $assignment_attachment,
				)
			);
			wp_update_comment( $data );
			if ( $enable_resubmit && $resubmit_limit > 0 ) {
				update_option( $option_key, $assignment_attempt + 1 );
			}
			$response = get_comment( $assignment_comment_id );
			$response = Helper::prepare_submitted_assignment_item( $response );
			do_action( 'academy_pro/frontend/submitted_assignment', $response );
			do_action( 'academy_pro_assignment/after_submit_assignment', $assignment_id, get_current_user_id(), $course_id );
			wp_send_json_success( $response );
		}//end if
		wp_send_json_error( __( 'Access Denied', 'academy-pro' ) );
	}

	public function delete_submitted_assignment( $payload_data ) {
		$payload = Sanitizer::sanitize_payload( [
			'comment_ID' => 'integer',
		], $payload_data );

		$comment_ID = $payload['comment_ID'];

		if ( ! $this->can_manage_submission( $comment_ID ) ) {
			wp_send_json_error( __( 'Sorry, you are not allowed to delete this submission.', 'academy-pro' ) );
		}

		$is_delete = wp_delete_comment( $comment_ID, true );
		if ( $is_delete ) {
			wp_send_json_success( array(
				'id' => $comment_ID
			) );
		}

		wp_send_json_error( __( 'Sorry, Failed to delete submission.', 'academy-pro' ) );
	}

	/**
	 * An assignment submission may only be evaluated/deleted by an administrator
	 * or by an instructor of the course the submission belongs to. The bare
	 * manage_academy_instructor capability is site-wide, so without a per-course
	 * check any instructor could grade or delete any submission (or, since the
	 * comment type was never verified, any WordPress comment) by ID.
	 *
	 * @param int $comment_id Submission comment ID.
	 * @return bool
	 */
	protected function can_manage_submission( $comment_id ) {
		$comment = get_comment( $comment_id );
		if ( ! $comment || 'academy_assignments' !== $comment->comment_type ) {
			return false;
		}
		if ( current_user_can( 'manage_options' ) ) {
			return true;
		}
		// For assignment submissions the course id is stored as comment_parent.
		return (bool) \Academy\Helper::is_instructor_of_this_course( get_current_user_id(), (int) $comment->comment_parent );
	}

	public function mark_assignment_complete( $topic_type, $course_id, $topic_id, $user_id ) {
		if ( 'assignment' === $topic_type ) {
			$assignment = \AcademyProAssignments\Helper::has_submitted_assignment( $topic_id, $user_id );

			if ( ! $assignment || 'pass' !== current( $assignment )->comment_approved ) {
				if ( \Academy\Helper::is_server_learn_page() ) {
					wp_safe_redirect( \Academy\Helper::sanitize_referer_url( wp_get_referer() ) );
					exit;
				}

				$message = $assignment ? __( 'Pass the assignment before marking it as done.', 'academy-pro' ) : __( 'Complete the assignment before marking it as done.', 'academy-pro' );
				wp_send_json_error( $message );
			}
		}
	}
}
