<?php
namespace AcademyProBuddypress;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Academy\Interfaces\AddonInterface;
use Exception;
use AcademyProBuddypress\Activities\CourseActivity;
use Academy\Admin\Notices;


final class Buddypress implements AddonInterface {
	private $addon_name = 'buddypress';


	private function __construct() {
		$this->define_constants();
		$this->init_addon();
	}


	public static function init() {
		static $instance = false;

		if ( ! $instance ) {
			$instance = new self();
		}

		return $instance;
	}


	public function define_constants() {
		/**
		 * Defines CONSTANTS for Whole Addon.
		 */
		define( 'ACADEMY_BUDDYPRESS_VERSION', '1.0' );
	}


	public function init_addon() {
		// fire addon activation hook
		add_action( "academy/addons/activated_{$this->addon_name}", array( $this, 'addon_activation_hook' ) );
		// if disable then stop running addons
		if (
			! \Academy\Helper::get_addon_active_status( $this->addon_name ) ||
			! self::is_active_buddypress() ||
			self::is_active_buddyboss()
		) {
			return;
		}

		add_action( 'init', [ __CLASS__, 'load' ] );
	}

	public function addon_activation_hook() {
	}

	public static function load() {

		if ( ! function_exists( 'bp_is_active' ) ) {
			return;
		}

		// The "Groups" component is the only hard requirement for course <->
		// group assignment (Configaration::get_groups() / the REST meta). It
		// used to be bundled with "Activity" behind a single all-or-nothing
		// check, which meant a site running Groups without Activity Streams
		// got no group picker at all, with the AJAX handler simply never
		// registered (a silent 400 on the frontend) and no explanation beyond
		// a top-of-admin notice easy to miss from the Course Settings screen.
		if ( ! bp_is_active( 'groups' ) ) {
			Notices::add_notice('buddypress-groups-needs-to-be-activated', [
				'type'          => 'danger',
				'message'       => esc_html__( 'BuddyPress "Groups" component is not activated yet.', 'academy-pro' ),
				'button_text'   => __( 'Go Settings', 'academy-pro' ),
				'button_action' => esc_url( admin_url( 'options-general.php?page=bp-components' ) )
			]);

			// Buddypress is not properly configured, doesnt need to load inegration file
			return;
		}

		Configaration::init();

		// Activity Streams only gates the course activity feed (GroupSettings'
		// per-group notification checkboxes and the activity registrations
		// themselves) — group selection above works without it.
		if ( bp_is_active( 'activity' ) ) {
			GroupSettings::init();
			ActivityRegistration::init();
		} else {
			Notices::add_notice('buddypress-activity-needs-to-be-activated', [
				'type'          => 'warning',
				'message'       => esc_html__( 'BuddyPress "Activity Streams" component is not activated — the course activity feed will stay disabled until you enable it.', 'academy-pro' ),
				'button_text'   => __( 'Go Settings', 'academy-pro' ),
				'button_action' => esc_url( admin_url( 'options-general.php?page=bp-components' ) )
			]);
		}
	}
	public static function is_active_buddypress(): bool {
		include_once ABSPATH . 'wp-admin/includes/plugin.php';
		return is_plugin_active( 'buddypress/bp-loader.php' );
	}

	public static function is_active_buddyboss(): bool {
		include_once ABSPATH . 'wp-admin/includes/plugin.php';
		return is_plugin_active( 'buddyboss-platform-release/bp-loader.php' );
	}
}
