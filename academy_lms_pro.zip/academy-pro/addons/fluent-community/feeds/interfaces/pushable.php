<?php
namespace AcademyProFluentCommunity\Feeds\Interfaces;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
interface Pushable {
	public function push(): void;
}
