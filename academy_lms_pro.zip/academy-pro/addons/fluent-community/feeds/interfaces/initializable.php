<?php
namespace AcademyProFluentCommunity\Feeds\Interfaces;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
interface Initializable {
	public function init(): void;
}
