<?php
namespace AcademyProGroupPlus;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * @class Expiry
 *
 * Daily housekeeping for seat packages: flips `group_courses.status` to
 * 'expired' once `end_date` has passed.
 *
 * This is *not* what actually blocks access — Helper::get_enrolled_courses_ids_by_user()
 * and Helper::is_team_member_enrolled() compare against `end_date` directly and in
 * real time, so access is cut off the instant a package expires regardless of
 * when this tick next runs. `status` is a denormalized, eventually-consistent
 * cache: it exists so admin listings/reports can filter/sort on "expired"
 * cheaply (via idx_expiry) without a live date comparison over every row, and
 * so the {@see self::TICK} action gives other code (notifications, etc.) a
 * single, once-per-package moment to react to an expiry instead of re-deriving
 * "did this just expire" from a raw date range on every page load.
 */
class Expiry {

	const TICK = 'academy_pro_group_plus/seat_expiry_tick';

	public static function init(): void {
		$self = new self();

		add_action( self::TICK, array( $self, 'expire_due_seats' ) );

		add_action( 'academy/addons/activated_group-plus', array( $self, 'schedule' ) );
		add_action( 'academy/addons/deactivated_group-plus', array( $self, 'unschedule' ) );

		// self-heal: an install that was already active before this addon shipped
		// Expiry never got the activation hook, so make sure the tick is scheduled
		// on every load too (wp_schedule_event() is itself idempotent/cheap to call
		// when already scheduled, via the wp_next_scheduled() guard below).
		self::schedule();
	}

	public static function schedule(): void {
		if ( ! wp_next_scheduled( self::TICK ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', self::TICK );
		}
	}

	public static function unschedule(): void {
		$timestamp = wp_next_scheduled( self::TICK );
		if ( $timestamp ) {
			wp_unschedule_event( $timestamp, self::TICK );
		}
	}

	/**
	 * Flips due packages to 'expired' and fires an action per affected
	 * (group_id, course_id) pair so other code (e.g. Notifications) can react.
	 *
	 * Deliberately a single bulk UPDATE for the flip (cheap, uses idx_expiry),
	 * then a small follow-up SELECT only for the rows that just changed — so a
	 * site with thousands of packages doesn't pay for a row-by-row PHP loop
	 * just to keep `status` in sync, but callers still get a discrete "this
	 * one expired" moment instead of having to diff status themselves.
	 */
	public function expire_due_seats(): void {
		global $wpdb;
		$table = $wpdb->prefix . ACADEMY_PLUGIN_SLUG . '_group_courses';

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- only $wpdb-prefixed table names, whitelisted columns and intval/placeholder lists are interpolated; values are prepared
		$due = $wpdb->get_results(
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			$wpdb->prepare(
				"SELECT group_id, course_id FROM {$table} WHERE status = %s AND end_date IS NOT NULL AND end_date < UTC_TIMESTAMP()",
				'active'
			)
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		if ( empty( $due ) ) {
			return;
		}

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- only $wpdb-prefixed table names, whitelisted columns and intval/placeholder lists are interpolated; values are prepared
		$wpdb->query(
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			$wpdb->prepare(
				"UPDATE {$table} SET status = %s WHERE status = %s AND end_date IS NOT NULL AND end_date < UTC_TIMESTAMP()",
				'expired',
				'active'
			)
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		foreach ( $due as $row ) {
			/**
			 * Fires once per seat package the moment the daily tick notices it
			 * has expired (access was already cut off in real time before this
			 * ever fires — see the class docblock).
			 *
			 * @param int $group_id
			 * @param int $course_id
			 */
			do_action( 'academy_pro_group_plus/seats_expired', (int) $row->group_id, (int) $row->course_id );
		}
	}
}
