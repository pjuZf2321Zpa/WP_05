<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AcademyProGroupPlus\Helper;
// Course single
add_action( 'academy/templates/single_course_enroll_before', 'academy_pro_group_plus_add_enroll_widget_tab_head' );
add_action( 'academy/templates/single_course_enroll_before', 'academy_pro_group_plus_add_enroll_widget_team_content' );
add_action( 'woocommerce_before_add_to_cart_button', 'academy_pro_group_plus_bulk_purchase_from_product_single' );

add_action( 'wp_enqueue_scripts', 'academy_pro_group_plus_load_assets' );
add_filter( 'academy/enrolled_courses_ids_by_user', [ Helper::class, 'get_enrolled_courses_ids_by_user' ], 10, 2 );
