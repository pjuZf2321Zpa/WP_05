<?php
use Academy\Helper;
use AcademyProGroupPlus\Db\Models\{
	Group,
	Team
};
use StoreEngine\Utils\Formatting;
use StoreEngine\Utils\Helper as StoreEngineHelper;
use AcademyProGroupPlus\Integration\Woocommerce\Woocommerce;
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
function academy_pro_group_plus_bulk_purchase_from_product_single() {

	if (
		! Helper::is_active_woocommerce() ||
		! property_exists( $GLOBALS['academy_settings'], 'monetization_engine' ) ||
		'woocommerce' !== $GLOBALS['academy_settings']->monetization_engine
	) {
		return;
	}

	$is_academy_course = ! empty(
		Woocommerce::get_course_id_by_product_id( get_the_ID() )
	);
	if ( $is_academy_course ) {
		\AcademyPro\Helper::get_template( 'group-plus/group-purchase-from-product-form.php', [] );
	}
}

function academy_pro_group_plus_add_enroll_widget_tab_head() {
	$course_id = get_the_ID();
	if (
		! Helper::is_enrolled( $course_id, get_current_user_id(), 'any' ) &&
		property_exists( $GLOBALS['academy_settings'], 'monetization_engine' ) &&
		! empty( $GLOBALS['academy_settings']->monetization_engine ) &&
		'paid' === Helper::get_course_type( $course_id )
	) {
		$engine = $GLOBALS['academy_settings']->monetization_engine;
		$data = apply_filters( "academy_pro/group_plus/{$engine}/product_data", [], (int) $course_id );
		if ( empty( $data ) ) {
			return;
		}
		\AcademyPro\Helper::get_template( 'group-plus/tab-head.php', [] );
	}
}

function academy_pro_group_plus_add_enroll_widget_team_content() {
	$course_id = get_the_ID();
	if (
		! Helper::is_enrolled( $course_id, get_current_user_id(), 'any' ) &&
		property_exists( $GLOBALS['academy_settings'], 'monetization_engine' ) &&
		! empty( $GLOBALS['academy_settings']->monetization_engine ) &&
		'paid' === Helper::get_course_type( $course_id )
	) {
		$engine = $GLOBALS['academy_settings']->monetization_engine;
		$data = apply_filters( "academy_pro/group_plus/{$engine}/product_data", [], (int) $course_id );
		if ( empty( $data ) ) {
			return;
		}
		\AcademyPro\Helper::get_template( 'group-plus/group-purchase-form.php', $data );
	}
}

/**
 * Version for a Group Plus asset: its modified time, so edits reach browsers.
 *
 * @param string $file Path under group-plus/assets/.
 * @return string
 */
function academy_pro_group_plus_asset_version( $file ) {
	$mtime = filemtime( ACADEMY_PRO_ADDONS_DIR_PATH . 'group-plus/assets/' . $file );
	return $mtime ? (string) $mtime : ACADEMY_PRO_VERSION;
}

function academy_pro_group_plus_load_assets() {
	wp_enqueue_script(
		'academy-group-static-js',
		ACADEMY_PRO_PLUGIN_ROOT_URI . 'addons/group-plus/assets/js/bulk-purchase.js',
		[ 'jquery' ],
		academy_pro_group_plus_asset_version( 'js/bulk-purchase.js' ),
		true
	);

	wp_localize_script(
		'academy-group-static-js',
		'academy_group',
		[
			'ajax_url' => admin_url( 'admin-ajax.php' ),
			'nonce'    => wp_create_nonce( 'academy_nonce' ),
			'i18n'     => [
				'searching'  => __( 'Searching…', 'academy-pro' ),
				'no_groups'  => __( 'No groups found.', 'academy-pro' ),
				'pick_group' => __( 'Please search and select one of your groups.', 'academy-pro' ),
			],
		]
	);
	wp_enqueue_style(
		'academy-group-static-css',
		ACADEMY_PRO_PLUGIN_ROOT_URI . 'addons/group-plus/assets/css/bulk-purchase.css',
		[],
		academy_pro_group_plus_asset_version( 'css/bulk-purchase.css' )
	);
}
