<?php
namespace AcademyProGroupPlus;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * @class Settings
 *
 * Seat-validity configuration for corporate packages: how long a purchased
 * `group_courses` seat block stays active before it needs renewing.
 *
 * Stored as a single option (not per-course post meta, unlike e.g. the
 * course-active-timer addon) because seat validity is a property of the
 * *purchased package*, not the course itself — the same course can be sold
 * to one organization as a 1-year package and to another as unlimited.
 */
class Settings {

	const OPTION_NAME = 'academy_pro_group_plus_settings';

	const MODE_UNLIMITED  = 'unlimited';
	const MODE_DURATION   = 'duration';
	const MODE_FIXED_DATE = 'fixed_date';

	/**
	 * Per-course override of seat validity, set on the course edit page and
	 * registered as REST-editable post meta in Hooks::register_course_meta().
	 * A group assigned this course inherits it automatically whenever an
	 * admin doesn't supply an explicit start_date/end_date of their own — see
	 * resolve_end_date_for_course(). 'course_default' means "use the site-wide
	 * setting above"; there's no course-level fixed_date mode, a fixed
	 * calendar date is a property of a specific purchase/contract, not
	 * something that makes sense as a reusable course template default.
	 */
	const COURSE_META_MODE           = 'academy_group_plus_seat_validity_mode';
	const COURSE_META_DURATION_VALUE = 'academy_group_plus_seat_validity_duration_value';
	const COURSE_META_DURATION_UNIT  = 'academy_group_plus_seat_validity_duration_unit';

	const COURSE_MODE_DEFAULT = 'course_default';

	const DEFAULTS = array(
		'mode'           => self::MODE_UNLIMITED,
		'duration_value' => 1,
		'duration_unit'  => 'years', // One of days, months or years.
		'fixed_end_date' => '',      // 'Y-m-d', only used when mode = fixed_date.
	);

	/**
	 * @return array{mode:string,duration_value:int,duration_unit:string,fixed_end_date:string}
	 */
	public static function get(): array {
		$stored = get_option( self::OPTION_NAME, array() );
		if ( ! is_array( $stored ) ) {
			$stored = array();
		}
		return wp_parse_args( $stored, self::DEFAULTS );
	}

	/**
	 * @param array $settings Any subset of the keys in self::DEFAULTS; unknown
	 *                         keys are dropped, missing keys keep their current value.
	 * @return array The full, merged settings that were saved.
	 */
	public static function update( array $settings ): array {
		$current = self::get();

		if ( isset( $settings['mode'] ) && in_array( $settings['mode'], array( self::MODE_UNLIMITED, self::MODE_DURATION, self::MODE_FIXED_DATE ), true ) ) {
			$current['mode'] = $settings['mode'];
		}
		if ( isset( $settings['duration_value'] ) ) {
			$current['duration_value'] = max( 1, (int) $settings['duration_value'] );
		}
		if ( isset( $settings['duration_unit'] ) && in_array( $settings['duration_unit'], array( 'days', 'months', 'years' ), true ) ) {
			$current['duration_unit'] = $settings['duration_unit'];
		}
		if ( isset( $settings['fixed_end_date'] ) ) {
			$current['fixed_end_date'] = self::normalize_date( $settings['fixed_end_date'] ) ?? '';
		}

		update_option( self::OPTION_NAME, $current );

		return $current;
	}

	/**
	 * Resolves the default access window for a newly purchased/renewed seat
	 * package, applying the global mode. A per-purchase explicit end_date
	 * (organizer override) should always take precedence over this — callers
	 * only call this when no explicit override was supplied.
	 *
	 * @param string $from_date 'Y-m-d H:i:s' the package starts counting from
	 *                          (purchase time, or "today" on renewal).
	 * @return string|null 'Y-m-d H:i:s', or null for unlimited access.
	 */
	public static function resolve_end_date( string $from_date ): ?string {
		$settings = self::get();

		switch ( $settings['mode'] ) {
			case self::MODE_DURATION:
				return self::add_duration( $from_date, (int) $settings['duration_value'], $settings['duration_unit'] );

			case self::MODE_FIXED_DATE:
				$normalized = self::normalize_date( $settings['fixed_end_date'] );
				// end of that calendar day, not midnight, so the package stays
				// valid through the whole day an admin picked.
				return $normalized ? $normalized . ' 23:59:59' : null;

			case self::MODE_UNLIMITED:
			default:
				return null;
		}
	}

	/**
	 * Resolves the default access window for a course, checking that course's
	 * own seat-validity override (set on the course edit page) before falling
	 * back to the site-wide setting. This is what "a group inherits the
	 * course's timespan automatically" means in practice: callers that don't
	 * have an explicit per-purchase override call this instead of
	 * resolve_end_date() directly, so the course-level default wins first.
	 *
	 * @param int    $course_id
	 * @param string $from_date 'Y-m-d H:i:s' the package starts counting from.
	 * @return string|null 'Y-m-d H:i:s', or null for unlimited access.
	 */
	public static function resolve_end_date_for_course( int $course_id, string $from_date ): ?string {
		$mode = get_post_meta( $course_id, self::COURSE_META_MODE, true );

		if ( self::MODE_UNLIMITED === $mode ) {
			return null;
		}

		if ( self::MODE_DURATION === $mode ) {
			$value = absint( get_post_meta( $course_id, self::COURSE_META_DURATION_VALUE, true ) );
			$unit  = get_post_meta( $course_id, self::COURSE_META_DURATION_UNIT, true );

			if ( $value > 0 && in_array( $unit, array( 'days', 'months', 'years' ), true ) ) {
				return self::add_duration( $from_date, $value, $unit );
			}
		}

		// COURSE_MODE_DEFAULT, or unset/invalid meta (a course created before
		// this addon shipped) — fall through to the site-wide setting.
		return self::resolve_end_date( $from_date );
	}

	/**
	 * @param string $from_date
	 * @param int    $value
	 * @param string $unit 'days' | 'months' | 'years'; anything else is treated as 'days'.
	 * @return string|null 'Y-m-d H:i:s', or null if $from_date doesn't parse.
	 */
	private static function add_duration( string $from_date, int $value, string $unit ): ?string {
		$value    = max( 1, $value );
		$interval = array(
			'days'   => "+{$value} days",
			'months' => "+{$value} months",
			'years'  => "+{$value} years",
		)[ $unit ] ?? "+{$value} days";

		$timestamp = strtotime( $interval, strtotime( $from_date ) );
		return $timestamp ? gmdate( 'Y-m-d H:i:s', $timestamp ) : null;
	}

	/**
	 * @param string $value
	 *
	 * @return string|null 'Y-m-d', or null if $value doesn't parse as a date.
	 */
	public static function normalize_date( $value ): ?string {
		$value = is_string( $value ) ? trim( $value ) : '';
		if ( '' === $value ) {
			return null;
		}
		$timestamp = strtotime( $value );
		return $timestamp ? gmdate( 'Y-m-d', $timestamp ) : null;
	}

	/**
	 * Normalizes a user-supplied date (from an AJAX payload, say) into the
	 * 'Y-m-d H:i:s' shape group_courses.start_date/end_date are stored as,
	 * anchored to the start or end of that calendar day.
	 *
	 * @param string $value
	 * @param bool   $end_of_day
	 *
	 * @return string|null null if $value is empty or doesn't parse.
	 */
	public static function normalize_datetime( $value, bool $end_of_day = false ): ?string {
		$date = self::normalize_date( $value );
		if ( ! $date ) {
			return null;
		}
		return $date . ( $end_of_day ? ' 23:59:59' : ' 00:00:00' );
	}
}
