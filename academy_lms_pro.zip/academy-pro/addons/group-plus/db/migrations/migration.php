<?php
namespace AcademyProGroupPlus\Db\Migrations;

use AcademyProGroupPlus\Db\Common;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * @class Migration
 */
abstract class Migration extends Common {

	/**
	 * @method up
	 * Run query on addon activation
	 * @return string
	 */
	abstract public function up(): string;

	/**
	 * @method down
	 * Run query on addon deactivation
	 * @return string
	 */
	abstract public function down(): string;

	/**
	 * @method runOnActivation
	 * Run code statement on addon activation
	 * @return void
	 */
	public static function runOnActivation(): void {
		self::execute( ( new static() )->up() );
	}

	/**
	 * Whether this migration's table already exists on the current site.
	 *
	 * @return bool
	 */
	public static function tableExists(): bool {
		global $wpdb;
		$table = ( new static() )->table;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		return $table === $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $table ) ) );
	}

	/**
	 * @method runOnDeactivation
	 * Run code statement on addon deactivation
	 * @return void
	 */
	public static function runOnDeactivation(): void {
		self::execute( ( new static() )->down() );
	}

	/**
	 * @method execute
	 * Run SQL Query
	 * @param  string $query
	 * @return void
	 */
	protected static function execute( string $query ): void {
		if ( empty( $query ) ) {
			return;
		}
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		// dbDelta() extracts the table name via `/CREATE TABLE ([^ ]*)/`, so an
		// "IF NOT EXISTS" clause makes it read "IF" as the table name. It then looks
		// up that (nonexistent) table, decides nothing needs altering, and silently
		// skips adding any new/changed columns on an existing table — first-run table
		// creation still "works" only because dbDelta falls back to executing the
		// original CREATE TABLE string as-is, and MySQL's own IF NOT EXISTS makes that
		// a harmless no-op. Strip the clause so dbDelta can actually diff and ALTER
		// existing tables, per https://developer.wordpress.org/reference/functions/dbdelta/.
		$query = preg_replace( '/CREATE TABLE IF NOT EXISTS/i', 'CREATE TABLE', $query, 1 );

		dbDelta( $query );
	}
}
