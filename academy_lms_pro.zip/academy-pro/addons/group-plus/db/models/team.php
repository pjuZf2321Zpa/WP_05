<?php
namespace AcademyProGroupPlus\Db\Models;

use AcademyProGroupPlus\Db\Models\Model;
use AcademyProGroupPlus\Roles\{
	TeamMember,
	TeamOrganizer
};

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Team
 */
final class Team extends Model {

	/**
	 * @var string
	 */
	protected string $table = 'teams';

	public function organizers(
		int $group_id,
		int $team_id,
		int $per_page = 20,
		int $current_page = 1,
		?string $order_by = null,
		string $order_direction = 'DESC'
	): array {
		global $wpdb;

		if ( ! $this->belongs_to_group( $group_id, $team_id ) ) {
			return [];
		}

		// phpcs:disable WordPressVIPMinimum.Variables.RestrictedVariables.user_meta__wpdb__users -- reporting JOIN on users/usermeta that get_users() cannot express
		return Group::ins()->get_advance_ct(
			'u.ID, u.user_login, u.user_email',
			'u.ID',
			"{$wpdb->users} AS u",
			"INNER JOIN {$this->prefix}team_organizers tor ON u.ID = tor.organizer_id",
			[
				'tor.group_id = %d',
				'tor.team_id = %d',
			],
			[
				$group_id,
				$team_id,
			],
			'',
			$per_page,
			$current_page,
			$order_by,
			$order_direction
		);
		// phpcs:enable WordPressVIPMinimum.Variables.RestrictedVariables.user_meta__wpdb__users
	}

	public function organizer_assigned(
		int $group_id,
		int $team_id,
		int $organizer_id
	): bool {
		global $wpdb;

		$query = "SELECT COUNT(*)
			FROM {$this->prefix}team_organizers
			WHERE group_id = %d
				AND team_id = %d
				AND organizer_id = %d";

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter -- custom query with no WP API equivalent
		return intval(
			$wpdb->get_var(
				$wpdb->prepare( $query, $group_id, $team_id, $organizer_id )// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			)
		) > 0;
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
	}

	public function add_organizer(
		int $group_id,
		int $team_id,
		int $organizer_id
	): bool {
		global $wpdb;

		if ( ! $this->belongs_to_group( $group_id, $team_id ) ) {
			return false;
		}

		$user = get_user_by( 'id', $organizer_id );

		if (
			false === $user
			|| $this->organizer_assigned( $group_id, $team_id, $organizer_id )
		) {
			return false;
		}

		$user->add_role( TeamOrganizer::ROLE_SLUG );

		do_action(
			'academy_pro_group_plus/api/before_add_organizer_to_team',
			$group_id,
			$team_id,
			$organizer_id
		);

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$wpdb->insert(
			"{$this->prefix}team_organizers",
			[
				'group_id'     => $group_id,
				'team_id'      => $team_id,
				'organizer_id' => $organizer_id,
				'user_id'      => get_current_user_id(),
			],
			[ '%d', '%d', '%d', '%d' ]
		);

		do_action(
			'academy_pro_group_plus/api/after_add_organizer_to_team',
			$group_id,
			$team_id,
			$organizer_id
		);

		return false !== $wpdb->insert_id;
	}

	public function remove_organizer(
		int $group_id,
		int $team_id,
		int $organizer_id
	): bool {
		global $wpdb;

		if ( ! $this->belongs_to_group( $group_id, $team_id ) ) {
			return false;
		}

		if ( ! $this->organizer_assigned( $group_id, $team_id, $organizer_id ) ) {
			return false;
		}

		do_action(
			'academy_pro_group_plus/api/before_remove_organizer_from_team',
			$group_id,
			$team_id,
			$organizer_id
		);

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$result = $wpdb->delete(
			"{$this->prefix}team_organizers",
			[
				'group_id'     => $group_id,
				'team_id'      => $team_id,
				'organizer_id' => $organizer_id,
			],
			[ '%d', '%d', '%d' ]
		);

		do_action(
			'academy_pro_group_plus/api/after_remove_organizer_from_team',
			$group_id,
			$team_id,
			$organizer_id
		);

		return is_int( $result );
	}

	public function members(
		int $group_id,
		int $team_id,
		int $per_page = 20,
		int $current_page = 1,
		?string $order_by = null,
		string $order_direction = 'DESC',
		?string $search = null
	): array {
		global $wpdb;

		if ( ! $this->belongs_to_group( $group_id, $team_id ) ) {
			return [];
		}

		$where = [
			'tmr.group_id = %d',
			'tmr.team_id = %d',
		];

		$args = [
			$group_id,
			$team_id,
		];

		if ( ! empty( $search ) ) {
			$where[] = 'u.user_email LIKE %s';
			$args[]  = '%' . $wpdb->esc_like( $search ) . '%';
		}

		// phpcs:disable WordPressVIPMinimum.Variables.RestrictedVariables.user_meta__wpdb__users -- reporting JOIN on users/usermeta that get_users() cannot express
		return Group::ins()->get_advance_ct(
			'u.ID, u.user_login, u.user_email',
			'u.ID',
			"{$wpdb->users} AS u",
			"INNER JOIN {$this->prefix}team_members tmr ON u.ID = tmr.member_id",
			$where,
			$args,
			'',
			$per_page,
			$current_page,
			$order_by,
			$order_direction
		);
		// phpcs:enable WordPressVIPMinimum.Variables.RestrictedVariables.user_meta__wpdb__users
	}

	public function members_count( int $group_id, int $team_id ): int {
		global $wpdb;

		$query = "SELECT COUNT(id)
			FROM {$this->prefix}team_members
			WHERE group_id = %d AND team_id = %d";

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter -- custom query with no WP API equivalent
		return intval(
			$wpdb->get_var(
				$wpdb->prepare( $query, $group_id, $team_id )// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			)
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
	}

	public function member_assigned(
		int $group_id,
		int $team_id,
		int $member_id
	): bool {
		global $wpdb;

		$query = "SELECT COUNT(*)
			FROM {$this->prefix}team_members
			WHERE group_id = %d
				AND team_id = %d
				AND member_id = %d";

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter -- custom query with no WP API equivalent
		return intval(
			$wpdb->get_var(
				$wpdb->prepare( $query, $group_id, $team_id, $member_id )// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			)
		) > 0;
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
	}

	public function add_member(
		int $group_id,
		int $team_id,
		int $member_id
	): bool {
		global $wpdb;

		if ( ! $this->belongs_to_group( $group_id, $team_id ) ) {
			return false;
		}

		$user = get_user_by( 'id', $member_id );

		if (
			false === $user
			|| $this->member_assigned( $group_id, $team_id, $member_id )
		) {
			return false;
		}

		$user->add_role( TeamMember::ROLE_SLUG );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$wpdb->insert(
			"{$this->prefix}team_members",
			[
				'group_id'  => $group_id,
				'team_id'   => $team_id,
				'member_id' => $member_id,
				'user_id'   => get_current_user_id(),
			],
			[ '%d', '%d', '%d', '%d' ]
		);

		return false !== $wpdb->insert_id;
	}

	public function remove_member(
		int $group_id,
		int $team_id,
		int $member_id
	): bool {
		global $wpdb;

		if ( ! $this->belongs_to_group( $group_id, $team_id ) ) {
			return false;
		}

		if ( ! $this->member_assigned( $group_id, $team_id, $member_id ) ) {
			return false;
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$result = $wpdb->delete(
			"{$this->prefix}team_members",
			[
				'group_id'  => $group_id,
				'team_id'   => $team_id,
				'member_id' => $member_id,
			],
			[ '%d', '%d', '%d' ]
		);

		return is_int( $result );
	}

	/**
	 * Authoritative team↔group binding check against the teams table.
	 *
	 * Handlers authorize with `Group::is_organizer($group_id) || Team::is_organizer(...)`,
	 * but the group-level branch passes for any group the caller organizes while the
	 * operation still targets a caller-supplied $team_id. Enforcing this invariant in
	 * the model prevents a group organizer from reading/mutating a team that belongs
	 * to a different group (cross-group IDOR).
	 *
	 * @param int $group_id Group the caller is authorized for.
	 * @param int $team_id  Team being operated on.
	 * @return bool
	 */
	public function belongs_to_group( int $group_id, int $team_id ): bool {
		global $wpdb;
		if ( ! $group_id || ! $team_id ) {
			return false;
		}
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		return (bool) $wpdb->get_var(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				"SELECT COUNT(id) FROM {$this->table} WHERE id = %d AND group_id = %d",
				$team_id,
				$group_id
			)
		);
	}

	public function is_organizer( int $group_id, int $team_id ): bool {
		global $wpdb;

		$query = "SELECT COUNT(id)
			FROM {$this->prefix}team_organizers
			WHERE organizer_id = %d
				AND group_id = %d
				AND team_id = %d";

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter -- custom query with no WP API equivalent
		$exists = boolval(
			$wpdb->get_var(
				$wpdb->prepare( $query, get_current_user_id(), $group_id, $team_id )// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			)
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter

		return ( current_user_can( 'manage_academy_team' ) && $exists )
			|| current_user_can( 'manage_options' );
	}

	public function is_member( int $group_id, int $team_id ): bool {
		global $wpdb;

		$query = "SELECT COUNT(id)
			FROM {$this->prefix}team_members
			WHERE member_id = %d
				AND group_id = %d
				AND team_id = %d";

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter -- custom query with no WP API equivalent
		$exists = boolval(
			$wpdb->get_var(
				$wpdb->prepare( $query, get_current_user_id(), $group_id, $team_id )// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			)
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter

		return ( current_user_can( 'academy_team_member' ) && $exists )
			|| current_user_can( 'manage_options' );
	}

	public function courses(
		int $group_id,
		int $team_id,
		int $per_page = 20,
		int $current_page = 1,
		?string $order_by = null,
		string $order_direction = 'DESC'
	): array {
		global $wpdb;

		if ( ! $this->belongs_to_group( $group_id, $team_id ) ) {
			return [];
		}

		return Group::ins()->get_advance_ct(
			"p.ID,
			p.post_title,
			(
				SELECT meta_value 
					FROM {$wpdb->postmeta} 
						WHERE 
							post_id = p.ID AND meta_key = 'academy_course_type'
			) AS type", // select rows
			'p.ID', // select count for pagination
			"{$wpdb->posts} as p", // main table alias
			"INNER JOIN {$this->prefix}team_courses tcr
					ON p.ID = tcr.course_id",  // join clause
			[
				'tcr.group_id = %d',
				'tcr.team_id = %d',
			], // where condition
			[
				$group_id,
				$team_id
			],   // where condition args
			'',   // after where, before order & limit query
			$per_page,
			$current_page,
			$order_by,
			$order_direction
		);
	}

	public function is_seats_available( int $group_id, int $assigned = 0 ): void {
		global $wpdb;

		$table_team_members  = $this->prefix . 'team_members';
		$table_team_courses = $this->prefix . 'team_courses';
		$table_group_courses = $this->prefix . 'group_courses';

		$sql = '
			SELECT
				tc.group_id,
				tc.course_id,
				COUNT( tm.member_id ) AS used,
				(
					SELECT total_seats
					FROM %s
					WHERE course_id = tc.course_id
				) AS total
			FROM %s tc
			LEFT JOIN %s tm
				ON tc.group_id = tm.group_id
				AND tc.team_id = tm.team_id
			WHERE tc.group_id = %d
			GROUP BY tc.course_id, tc.group_id
		';

		$query = $wpdb->prepare(// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			sprintf( $sql, $table_group_courses, $table_team_courses, $table_team_members, $group_id ) // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		);

		$results = $wpdb->get_results( $query, ARRAY_A );// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter

		if ( empty( $results ) ) {
			return;
		}

		array_map(
			function ( ?array $res ) use ( $assigned ): array {

				$used  = absint( $res['used'] ?? 0 );
				$total = absint( $res['total'] ?? 0 );

				if ( $used >= $total ) {
					wp_send_json_error(
						[
							'message' => sprintf(
								/* translators: %s: assigned members count */
								__( 'Seat is not available. %1$s assigned.', 'academy-pro' ),
								0 === $assigned ? __( 'No member', 'academy-pro' ) : $assigned
							),
						],
						422
					);
				}

				return $res;
			},
			$results
		);
	}


	public function remove_course( int $group_id, int $team_id, int $course_id ): bool {
		global $wpdb;
		$table = $this->prefix . 'team_courses';

		if ( ! $this->belongs_to_group( $group_id, $team_id ) ) {
			return false;
		}

		if (
			$this->course_assigned( $group_id, $team_id, $course_id )
		) {
			$where = [
				'group_id'  => $group_id,
				'course_id' => $course_id,
				'team_id'   => $team_id,
			];

			do_action( 'academy_pro_group_plus/api/before_remove_course_from_team', $group_id, $team_id, $course_id );
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$result = $wpdb->delete(
				$table,
				$where,
				[ '%d', '%d', '%d' ]
			);

			do_action( 'academy_pro_group_plus/api/after_remove_course_from_team', $group_id, $team_id, $course_id );

			return is_int( $result ) ? true : false;
		}
		return false;
	}

	public function add_course( int $group_id, int $team_id, int $course_id ): bool {
		global $wpdb;
		$table = $this->prefix . 'team_courses';

		if ( ! $this->belongs_to_group( $group_id, $team_id ) ) {
			return false;
		}

		if (
			! $this->course_assigned( $group_id, $team_id, $course_id ) &&
			'academy_courses' === ( get_post_type( $course_id ) ) &&
			Group::ins()->course_assigned( $group_id, $course_id )
		) {
			$data = [
				'group_id'    => $group_id,
				'course_id'   => $course_id,
				'team_id'     => $team_id,
				'user_id'     => get_current_user_id(),
			];

			do_action( 'academy_pro_group_plus/api/before_add_course_to_team', $group_id, $team_id, $course_id );

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared 
			$wpdb->insert(
				$table,
				$data,
				[ '%d', '%d', '%d', '%d' ]
			);

			do_action( 'academy_pro_group_plus/api/after_add_course_to_team', $group_id, $team_id, $course_id );

			return false === $wpdb->insert_id ? false : true;
		}//end if
		return false;
	}

	public function course_assigned( int $group_id, int $team_id, int $course_id ): bool {
		global $wpdb;
		$table = $this->prefix . 'team_courses';
		$count_query = "SELECT COUNT(*) FROM {$table} 
			WHERE group_id = %d AND  course_id = %d AND  team_id = %d";

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
		return intval( $wpdb->get_var( $wpdb->prepare( $count_query, $group_id, $course_id, $team_id ) ) ) > 0;
	}
}
