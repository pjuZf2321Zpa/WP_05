<?php
namespace AcademyProGroupPlus\Db\Models;

use AcademyProGroupPlus\Db\Models\Model;
use stdClass;
use AcademyProGroupPlus\Roles\{
	GroupOrganizer,
	TeamOrganizer
};
use AcademyProGroupPlus\Settings;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * @class Group
 */
final class Group extends Model {


	/** @var string $table */
	protected string $table = 'groups';

	protected array $columns = [ 'name', 'created_at', 'updated_at' ];

	public function teams(
		int $id,
		array $conditions = [],
		array $args = [],
		int $per_page = 20,
		int $current_page = 1,
		?string $order_by = null,
		string $order_direction = 'DESC'
	): array {
		$conditions[] = 'group_id = %d';
		$args[]       = $id;
		return Team::ins()->get( $conditions, $args, $per_page, $current_page, $order_by, $order_direction );
	}

	public function organizers(
		int $group_id,
		int $per_page = 20,
		int $current_page = 1,
		?string $order_by = null,
		string $order_direction = 'DESC'
	): array {
		global $wpdb;
		// phpcs:disable WordPressVIPMinimum.Variables.RestrictedVariables.user_meta__wpdb__users -- reporting JOIN on users/usermeta that get_users() cannot express
		return self::ins()->get_advance_ct(
			'u.ID, u.user_login, u.user_email ', // select rows
			'u.ID', // select count for pagination
			"{$wpdb->users} as u", // main table alias
			"INNER JOIN {$this->prefix}group_organizers ugr
					ON u.ID = ugr.organizer_id",  // join clause
			[ 'ugr.group_id = %d' ], // where condition
			[ $group_id ],   // where condition args
			'',   // after where, before order & limit query
			$per_page,
			$current_page,
			$order_by,
			$order_direction
		);
		// phpcs:enable WordPressVIPMinimum.Variables.RestrictedVariables.user_meta__wpdb__users
	}

	public function courses(
		int $group_id,
		int $per_page = 20,
		int $current_page = 1,
		?string $order_by = null,
		string $order_direction = 'DESC'
	): array {
		global $wpdb;
		return self::ins()->get_advance_ct(
			"p.ID,
			p.post_title,
			p.post_status,
			gcr.total_seats,
			gcr.req_seats,
			gcr.start_date,
			gcr.end_date,
			gcr.status AS seat_status,
			(
				SELECT COUNT(tmr.id)
					FROM {$this->prefix}team_members tmr
					INNER JOIN {$this->prefix}team_courses tcr
						ON tcr.group_id = tmr.group_id
						WHERE
							tcr.group_id = gcr.group_id AND
							tcr.course_id = p.ID
			) AS seat_used,
			(
				SELECT meta_value 
					FROM {$wpdb->postmeta} 
						WHERE 
							post_id = p.ID AND meta_key = 'academy_course_type'
			) AS type", // select rows
			'p.ID', // select count for pagination
			"{$wpdb->posts} as p", // main table alias
			"INNER JOIN {$this->prefix}group_courses gcr
					ON p.ID = gcr.course_id",  // join clause
			[ 'gcr.group_id = %d' ], // where condition
			[ $group_id ],   // where condition args
			'',   // after where, before order & limit query
			$per_page,
			$current_page,
			$order_by,
			$order_direction
		);
	}

	public function course_assigned( int $group_id, int $course_id ): bool {
		global $wpdb;
		$table = $this->prefix . 'group_courses';
		$count_query = "SELECT COUNT(*) FROM {$table} 
			WHERE group_id = %d AND  course_id = %d";

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
		return intval( $wpdb->get_var( $wpdb->prepare( $count_query, $group_id, $course_id ) ) ) > 0;
	}

	public function course_seats( int $group_id, int $course_id ): int {
		global $wpdb;
		$table = $this->prefix . 'group_courses';
		$count_query = "SELECT total_seats FROM {$table} 
			WHERE group_id = %d AND  course_id = %d";

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
		return intval( $wpdb->get_var( $wpdb->prepare( $count_query, $group_id, $course_id ) ?? 0 ) );
	}



	public function get_available_seats_by_course( int $group_id, int $course_id ): int {
		global $wpdb;
		$table = $this->prefix . 'group_courses';
		$count_query = "SELECT total_seats FROM {$table} 
			WHERE group_id = %d AND  course_id = %d";

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
		$total = intval( $wpdb->get_var( $wpdb->prepare( $count_query, $group_id, $course_id ) ) ?? 0 );

		$team_members_q = "SELECT COUNT(tmr.id) 
					FROM {$this->prefix}team_members tmr
					INNER JOIN {$this->prefix}team_courses tcr
						ON tmr.team_id = tcr.team_id
					WHERE tmr.group_id = %d AND  tcr.course_id = %d";
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
		$used = intval( $wpdb->get_var( $wpdb->prepare( $team_members_q, $group_id, $course_id ) ) ?? 0 );

		if ( $total > $used ) {
			return $total - $used;
		}
		return 0;
	}

	/**
	 * @param int         $group_id
	 * @param int         $course_id
	 * @param int         $total_seats
	 * @param bool        $req
	 * @param string|null $start_date 'Y-m-d H:i:s' the seat package becomes active,
	 *                                or null to default to now.
	 * @param string|null $end_date   'Y-m-d H:i:s' explicit expiry override, '' to force
	 *                                unlimited (no expiry) regardless of the global
	 *                                setting, or null to resolve it from Settings.
	 */
	public function add_course(
		int $group_id,
		int $course_id,
		int $total_seats,
		bool $req = false,
		?string $start_date = null,
		?string $end_date = null
	): bool {
		global $wpdb;
		$table = $this->prefix . 'group_courses';

		if (
			! $this->course_assigned( $group_id, $course_id ) &&
			( 'academy_courses' === get_post_type( $course_id ) ) // course exists
		) {
			$data = [
				'group_id'    => $group_id,
				'course_id'   => $course_id,
				'user_id'     => get_current_user_id(),
			];

			if ( $req ) {
				$data['req_seats'] = $total_seats;
			} else {
				$data['total_seats'] = $total_seats;

				// Seat-expiry window: only meaningful once seats are actually
				// granted, a merely-requested package has nothing to expire yet.
				$resolved_start     = $start_date ? $start_date : current_time( 'mysql', true );
				$data['start_date'] = $resolved_start;
				$data['end_date']   = '' === $end_date
					? null
					: ( $end_date ?? Settings::resolve_end_date_for_course( $course_id, $resolved_start ) );
			}

			do_action( 'academy_pro_group_plus/api/before_add_courses_to_group', $data );
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->insert(
				$table,
				$data,
				self::column_formats( $data )
			);
			do_action( 'academy_pro_group_plus/api/after_add_courses_to_group', $data );

			return false === $wpdb->insert_id ? false : true;
		}//end if
		return false;
	}



	/**
	 * @param int         $group_id
	 * @param int         $course_id
	 * @param int         $total_seats
	 * @param bool        $req
	 * @param string|null $start_date Explicit start_date override, null leaves the
	 *                                existing start_date untouched (renewing seats
	 *                                doesn't reset "since when has this group had
	 *                                access").
	 * @param string|null $end_date   Explicit end_date override, '' to force
	 *                                unlimited, or null to leave the current
	 *                                end_date untouched unless $extend is set.
	 * @param bool        $extend     When true and $end_date wasn't explicitly given,
	 *                                recompute end_date from Settings counting from
	 *                                today — the renewal policy: a repurchase extends
	 *                                validity by the configured duration from *now*,
	 *                                it doesn't stack onto whatever end_date remained.
	 */
	public function update_course(
		int $group_id,
		int $course_id,
		int $total_seats,
		bool $req = false,
		?string $start_date = null,
		?string $end_date = null,
		bool $extend = false
	): bool {
		global $wpdb;
		$table = $this->prefix . 'group_courses';

		if (
			$this->course_assigned( $group_id, $course_id ) &&
			( 'academy_courses' === get_post_type( $course_id ) ) // course exists
		) {
			$data = [];

			if ( $req ) {
				$data['req_seats'] = $total_seats;
			} else {
				$data['total_seats'] = $total_seats;
			}

			if ( null !== $start_date ) {
				$data['start_date'] = $start_date;
			}

			if ( '' === $end_date ) {
				$data['end_date'] = null;
				$data['status']   = 'active';
			} elseif ( null !== $end_date ) {
				$data['end_date'] = $end_date;
				$data['status']   = 'active';
			} elseif ( $extend ) {
				$data['end_date'] = Settings::resolve_end_date_for_course( $course_id, current_time( 'mysql', true ) );
				$data['status']   = 'active';
			}

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$result = $wpdb->update(
				$table,
				$data,
				[
					'group_id'  => $group_id,
					'course_id' => $course_id,
				],
				self::column_formats( $data ),
				[ '%d', '%d' ],
			);

			return is_int( $result ) ? true : false;
		}//end if
		return $this->add_course( $group_id, $course_id, $total_seats, $req, $start_date, $end_date );
	}

	/**
	 * Positional %d/%s format array matching $data's key order, for wpdb
	 * insert()/update() calls whose column set varies by call site.
	 *
	 * @param array<string,mixed> $data
	 * @return string[]
	 */
	protected static function column_formats( array $data ): array {
		$formats = [
			'group_id'    => '%d',
			'course_id'   => '%d',
			'user_id'     => '%d',
			'total_seats' => '%d',
			'req_seats'   => '%d',
			'start_date'  => '%s',
			'end_date'    => '%s',
			'status'      => '%s',
		];
		return array_map(
			static fn ( $key ) => $formats[ $key ] ?? '%s',
			array_keys( $data )
		);
	}

	public function remove_course( int $group_id, int $course_id ): bool {
		global $wpdb;

		$table = $this->prefix . 'group_courses';
		$table_team = $this->prefix . 'team_courses';

		if (
			$this->course_assigned( $group_id, $course_id )
		) {
			$where = [
				'group_id'  => $group_id,
				'course_id' => $course_id,
			];

			do_action( 'academy_pro_group_plus/api/before_remove_courses_from_group', $group_id, $course_id );
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$result = $wpdb->delete(
				$table,
				$where,
				[ '%d', '%d' ]
			);
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$result_ = $wpdb->delete(
				$table_team,
				$where,
				[ '%d', '%d' ]
			);
			do_action( 'academy_pro_group_plus/api/after_remove_courses_from_group', $group_id, $course_id );

			return is_int( $result ) ? true : false;
		}//end if
		return false;
	}

	public function organizer_assigned( int $group_id, int $organizer_id ): bool {
		global $wpdb;
		$table = $this->prefix . 'group_organizers';
		$count_query = "SELECT COUNT(*) FROM {$table} 
			WHERE group_id = %d AND  organizer_id = %d";

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
		return intval( $wpdb->get_var( $wpdb->prepare( $count_query, $group_id, $organizer_id ) ) ) > 0;
	}

	public function add_organizer( int $group_id, int $organizer_id ): bool {
		global $wpdb;
		$table = $this->prefix . 'group_organizers';

		$user_data = get_user_by( 'id', $organizer_id );

		if (
			! $this->organizer_assigned( $group_id, $organizer_id ) &&
			( false !== $user_data )
		) {

			$user_data->add_role( GroupOrganizer::ROLE_SLUG );

			$data = [
				'group_id'     => $group_id,
				'organizer_id' => $organizer_id,
				'user_id'      => get_current_user_id(),
			];
			do_action( 'academy_pro_group_plus/api/before_add_group_organizer', $data );
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->insert(
				$table,
				$data,
				[ '%d', '%d', '%d' ]
			);
			do_action( 'academy_pro_group_plus/api/after_add_group_organizer', $data );

			return false === $wpdb->insert_id ? false : true;
		}
		return false;
	}



	public function remove_organizer( int $group_id, int $organizer_id ): bool {
		global $wpdb;
		$table = $this->prefix . 'group_organizers';
		if (
			$this->organizer_assigned( $group_id, $organizer_id )
		) {
			$where = [
				'group_id'     => $group_id,
				'organizer_id' => $organizer_id,
			];

			do_action( 'academy_pro_group_plus/api/before_remove_group_organizer', $group_id, $organizer_id );
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$result = $wpdb->delete(
				$table,
				$where,
				[ '%d', '%d' ]
			);
			do_action( 'academy_pro_group_plus/api/after_remove_group_organizer', $group_id, $organizer_id );

			return is_int( $result ) ? true : false;
		}
		return false;
	}

	public function is_organizer( int $group_id ): bool {
		global $wpdb;
		$query = "SELECT COUNT(id)  
					FROM
						{$this->prefix}group_organizers
							WHERE organizer_id = %d AND group_id = %d";

		return ( current_user_can( 'manage_academy_group' ) && boolval(
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
			$wpdb->get_var(
				// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared 
				$wpdb->prepare( $query, get_current_user_id(), $group_id )
			) ?? false
		) ) || current_user_can( 'manage_options' );
	}

	public function validate_organizers( int $group_id, int ...$user_ids ): array {
		global $wpdb;
		$query = "SELECT ugr.organizer_id  
					FROM
						{$this->prefix}group_organizers ugr
							WHERE ugr.group_id = %d AND 
							ugr.organizer_id IN (" . implode( ', ', array_fill( 0, count( $user_ids ), '%d' ) ) . ')';
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
		return $wpdb->get_col(
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared 
			$wpdb->prepare( $query, $group_id, ...$user_ids )
		) ?? [];
	}
	public static function get_user_info( $user_id ) {
		$user = get_userdata( $user_id );

		if ( ! $user ) {
			return null; // or return an empty array if you prefer []
		}

		return [
			'id'    => $user->ID,
			'email' => $user->user_email,
			'name'  => $user->display_name,
		];
	}

	public function is_group_organizer( int $user_id, int $group_id ): bool {
		$join = 'INNER JOIN ' . self::add_prefix( 'group_organizers' ) . ' ugr
					ON g.id = ugr.group_id';
		$conditions = [];
		$args = [];

		$conditions[] = 'ugr.organizer_id = %d';
		$args[]       = $user_id;

		$conditions[] = 'ugr.group_id = %d';
		$args[]       = $group_id;
		return ! empty( self::ins()->get_advance(
			'g.*', // select rows
			'g.id', // select count for pagination
			'g', // main table alias
			$join,  // join clause
			$conditions, // where condition
			$args,   // where condition args
			'',   // after where, before order & limit query
			1
		) );
	}
}
