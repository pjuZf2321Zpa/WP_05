<?php
namespace AcademyProGroupPlus;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


class Hooks {
	public static function init() {
		$self = new self();
		add_filter( 'academy/course/is_enrolled', [ $self, 'check_team_member_enroll' ], 10, 3 );
		add_filter( 'academy/count_course_enrolled', [ $self, 'count_course_enrolled' ], 10, 2 );

		// Register post meta so the course builder can read/write the
		// per-course seat-validity default via the REST API (course builder
		// meta saves are generic — no addon-specific save handler needed once
		// registered, same pattern as course-active-timer).
		add_action( 'rest_api_init', [ $self, 'register_course_meta' ] );
		add_action( 'init', [ $self, 'register_course_meta' ] );
	}
	public function check_team_member_enroll( $enrolled_status, $course_id, $user_id ) {
		$is_group_member_enrolled = Helper::ins()->is_team_member_enrolled( (int) $course_id, (int) $user_id );
		if ( $is_group_member_enrolled ) {
			return $is_group_member_enrolled;
		}
		return $enrolled_status;
	}
	public function count_course_enrolled( $enrolled_course_count, $course_id ) {
		return $enrolled_course_count + Helper::ins()->total_seat_count_by_course( $course_id );
	}

	public function register_course_meta() {
		$meta_keys = array(
			Settings::COURSE_META_MODE           => array(
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_text_field',
			),
			Settings::COURSE_META_DURATION_VALUE => array(
				'type'              => 'integer',
				'sanitize_callback' => 'absint',
			),
			Settings::COURSE_META_DURATION_UNIT  => array(
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_text_field',
			),
			// Volume pricing: JSON-encoded [{min_seats, price}, ...], validated
			// and normalized by Pricing::sanitize_tiers() — registered as a
			// string meta (not an 'array'/'object' REST schema) to keep this
			// symmetric with the rest of group-plus's course meta and avoid
			// committing to a REST array-item schema this repeater doesn't need.
			Pricing::COURSE_META_TIERS           => array(
				'type'              => 'string',
				'sanitize_callback' => array( Pricing::class, 'sanitize_tiers' ),
			),
		);

		foreach ( $meta_keys as $key => $schema ) {
			register_post_meta(
				'academy_courses',
				$key,
				array(
					'show_in_rest'      => true,
					'single'            => true,
					'type'              => $schema['type'],
					'sanitize_callback' => $schema['sanitize_callback'],
					'auth_callback'     => function () {
						return current_user_can( 'manage_academy_instructor' );
					},
				)
			);
		}
	}
}
