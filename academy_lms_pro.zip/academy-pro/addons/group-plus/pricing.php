<?php
namespace AcademyProGroupPlus;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * @class Pricing
 *
 * Volume/sliding per-seat pricing for a course's group-plus seat package:
 * more seats bought at once, lower price per seat. Tiers are stored on the
 * course itself — set alongside the course's regular product price, the
 * same "course-level default" pattern Settings::resolve_end_date_for_course()
 * already uses — so they apply the moment a group buys seats for that
 * course, regardless of which commerce engine (WooCommerce or StoreEngine)
 * processes the sale.
 *
 * Deliberately flat-rate, not graduated: buying 12 seats at a "5+" tier
 * prices all 12 seats at that tier's rate, not a per-band sum (seats 1-4 at
 * one rate, 5-12 at another). Simpler to compute and to show a buyer
 * ("12 seats @ $90 = $1,080"), and matches how most volume-pricing plugins
 * behave.
 */
class Pricing {

	const COURSE_META_TIERS = 'academy_group_plus_price_tiers';

	/**
	 * @param int $course_id
	 *
	 * @return array<int, array{min_seats:int, price:float}> Sorted ascending by min_seats.
	 */
	public static function get_tiers( int $course_id ): array {
		$raw = get_post_meta( $course_id, self::COURSE_META_TIERS, true );
		if ( empty( $raw ) ) {
			return array();
		}

		$decoded = is_array( $raw ) ? $raw : json_decode( (string) $raw, true );
		if ( ! is_array( $decoded ) ) {
			return array();
		}

		$tiers = array();
		foreach ( $decoded as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$min_seats = absint( $row['min_seats'] ?? 0 );
			$price     = isset( $row['price'] ) && is_numeric( $row['price'] ) ? (float) $row['price'] : null;

			// Skip malformed rows rather than fail the whole lookup over one bad tier.
			if ( $min_seats < 1 || null === $price || $price < 0 ) {
				continue;
			}

			$tiers[] = array(
				'min_seats' => $min_seats,
				'price'     => $price,
			);
		}

		usort(
			$tiers,
			static function ( $a, $b ) {
				return $a['min_seats'] <=> $b['min_seats'];
			}
		);

		return $tiers;
	}

	/**
	 * Resolves the per-seat price for buying $quantity seats of $course_id,
	 * per the highest configured tier whose min_seats <= $quantity (flat,
	 * not graduated — see class docblock).
	 *
	 * @param int $course_id
	 * @param int $quantity
	 *
	 * @return float|null null if no tiers are configured for this course, or
	 *                     $quantity falls below every configured tier's
	 *                     min_seats — callers fall back to the course's
	 *                     regular product price in either case.
	 */
	public static function resolve_unit_price( int $course_id, int $quantity ): ?float {
		$tiers = self::get_tiers( $course_id );
		if ( empty( $tiers ) ) {
			return null;
		}

		$matched = null;
		foreach ( $tiers as $tier ) {
			if ( $tier['min_seats'] > $quantity ) {
				break; // tiers are sorted ascending — nothing further can match either.
			}
			$matched = $tier['price']; // keep the highest-min_seats match seen so far.
		}

		return $matched;
	}

	/**
	 * Validates and normalizes a tiers payload from the course editor before
	 * it's saved as post meta — used by the REST sanitize_callback.
	 *
	 * @param mixed $value Raw value from the REST request (JSON string or array).
	 * @return string JSON-encoded, de-duplicated (by min_seats), sorted tier list.
	 */
	public static function sanitize_tiers( $value ): string {
		$decoded = is_array( $value ) ? $value : json_decode( (string) $value, true );
		if ( ! is_array( $decoded ) ) {
			return '[]';
		}

		$by_min_seats = array();
		foreach ( $decoded as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$min_seats = absint( $row['min_seats'] ?? 0 );
			$price     = isset( $row['price'] ) && is_numeric( $row['price'] ) ? (float) $row['price'] : null;

			if ( $min_seats < 1 || null === $price || $price < 0 ) {
				continue;
			}

			// Last write for a given min_seats wins, so editing a row in place
			// (rather than appending a duplicate) behaves as the user expects.
			$by_min_seats[ $min_seats ] = array(
				'min_seats' => $min_seats,
				'price'     => $price,
			);
		}

		ksort( $by_min_seats );

		return wp_json_encode( array_values( $by_min_seats ) );
	}
}
