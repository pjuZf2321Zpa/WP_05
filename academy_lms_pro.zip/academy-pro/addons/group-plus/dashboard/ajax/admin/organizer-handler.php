<?php
namespace AcademyProGroupPlus\Dashboard\Ajax\Admin;

use Academy\Classes\AbstractAjaxHandler;
use Academy\Classes\Sanitizer;
use AcademyProGroupPlus\Db\Models\Group;
use AcademyProGroupPlus\Roles\{
	GroupOrganizer,
	TeamOrganizer
};
use WP_User;
use WP_User_Query;
use AcademyProGroupPlus\interfaces\Ajax\OrganizerHandlerInterface;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


class OrganizerHandler extends AbstractAjaxHandler implements OrganizerHandlerInterface {

	protected $namespace = 'academy_pro_group_plus';
	public function __construct() {
		$this->actions = array(
			'get_organizers' => array(
				'callback' => array( $this, 'get_organizers' ),
				'capability' => 'academy_team_member',
			),
			'get_team_members' => array(
				'callback' => array( $this, 'get_team_members' ),
				'capability' => 'academy_team_member',
			),
		);
	}
	public function get_organizers( $payload_data ): void {

		// This returns site-wide user records incl. email addresses, so it must be
		// restricted to organizers/administrators — not every team member.
		if ( ! ( current_user_can( 'manage_academy_group' ) || current_user_can( 'manage_academy_team' ) || current_user_can( 'manage_options' ) ) ) {
			wp_send_json_error( esc_html__( 'Unauthorized request.', 'academy-pro' ) );
		}

		$payload = Sanitizer::sanitize_payload(
			[
				'page'         => 'integer',
				'email_search' => 'string',
			],
			$payload_data
		);

		$per_page = 20;
		$page     = max( 1, (int) ( $payload['page'] ?? 1 ) );
		$offset   = ( $page - 1 ) * $per_page;

		$args = [
			'number'   => $per_page,
			'offset'  => $offset,
			'role__in' => [ 'academy_group_organizer', 'academy_team_organizer' ],
		];

		$email = sanitize_email( $payload['email_search'] ?? '' );

		if ( ! empty( $email ) ) {
			$args['search']         = '*' . esc_attr( $email ) . '*';
			$args['search_columns'] = [ 'user_email' ];
		}

		$user_query = new WP_User_Query( $args );
		$users      = $user_query->get_results();
		$total      = (int) $user_query->get_total();

		$output = [
			'current_page' => $page,
			'total_page'   => $per_page > 0 ? (int) ceil( $total / $per_page ) : 0,
			'users'        => [],
		];

		if ( ! empty( $users ) ) {
			foreach ( $users as $user ) {

				// Hide admin/editor unless super admin
				if (
					! current_user_can( 'manage_options' ) &&
					array_intersect( [ 'administrator', 'editor' ], (array) $user->roles )
				) {
					continue;
				}

				$output['users'][] = [
					'id'           => (int) $user->ID,
					'display_name' => $user->display_name,
					'email'        => $user->user_email,
				];
			}
		}

		wp_send_json_success( $output );
	}

	public function get_team_members( $payload_data ): void {

		// Enumerates site-wide users incl. email addresses — restrict to
		// organizers/administrators rather than any team member.
		if ( ! ( current_user_can( 'manage_academy_group' ) || current_user_can( 'manage_academy_team' ) || current_user_can( 'manage_options' ) ) ) {
			wp_send_json_error( esc_html__( 'Unauthorized request.', 'academy-pro' ) );
		}

		$payload = Sanitizer::sanitize_payload([
			'page'    => 'integer',
			'email_search'    => 'string',
		], $payload_data);

		$args = [
			'number' => 20,
			'paged'  => abs( intval( $payload['page'] ?? 1 ) ),
		];
		$email = $payload['email_search'] ?? '';
		if ( ! empty( $email ) ) {
			$args['search_columns'] = [ 'user_email' ];
			$args['search']         = '*' . $email . '*';
		}

		$user_query = new WP_User_Query( $args );

		$output = [];

		$output['current_page'] = $args['paged'];
		$output['total_page']   = ceil( $user_query->get_total() / $args['number'] );
		$output['users'] = [];
		$users = $user_query->get_results();
		if ( ! empty( $users ) ) {
			foreach ( $users as $user ) {

				if (
					! current_user_can( 'manage_options' ) &&
					(
						in_array( 'administrator', $user->roles, true ) ||
						in_array( 'editor', $user->roles, true ) ||
						in_array( 'academy_team_organizer', $user->roles, true ) ||
						in_array( 'academy_group_organizer', $user->roles, true )
					)
				) {
					continue;
				}

				$output['users'][] = [
					'id'           => intval( $user->ID ),
					'display_name' => $user->display_name,
					'email'        => $user->user_email,
				];
			}
		}//end if
		wp_send_json_success( $output );
	}
}
