jQuery(document).ready(function($){
    let groupComboboxCount = 0;
    const enrollWidgetTabs = () => {
        const individualTab = $(".academy-btn-enroll-tab-individual");
        const teamTab = $(".academy-btn-enroll-tab-team");
        const contentIndividual = $(".academy-widget-enroll__content");
        const contentTeam = $(".academy-g-plus-enroll-content-team");
        
        if (individualTab.length == 0 || teamTab.length == 0 || contentIndividual.length == 0 || contentTeam.length == 0 ) {
            return;
        }
        // Initial state: show individual content, hide team content
        contentIndividual.show();
        // contentTeam.hide();
        individualTab.addClass("active");

        function clearActiveTabs() {
            individualTab.removeClass("active");
            teamTab.removeClass("active");
        }

        individualTab.on("click", function () {
            clearActiveTabs();
            individualTab.addClass("active");
            contentTeam.fadeOut();
            contentTeam.hide();
            contentIndividual.fadeIn();
        });

        teamTab.on("click", function () {
            clearActiveTabs();
            teamTab.addClass("active");
            contentIndividual.fadeOut();
            contentIndividual.hide();
            contentTeam.fadeIn();
        });
    },
    /*
     * One "search and select" field for the buyer's existing groups
     * (replaces a search box + a separate <select>). Typing searches the
     * server (debounced); picking an option stores its id in the hidden
     * #academy_group_id the add-to-cart request reads. Names go in as text,
     * never HTML.
     */
    groupCombobox = function(elm){
        const $root = $(elm).find('.academy-group-combobox').first();
        if (!$root.length) {
            return;
        }
        const $input = $root.find('#academy_group_search');
        const $list = $root.find('.academy-group-combobox__list');
        const $value = $root.find('#academy_group_id');
        // The widget can render more than once per page (fixed template ids),
        // so the list and its options get ids unique to this widget.
        const uid = 'academy_group_listbox_' + (++groupComboboxCount);
        $list.attr('id', uid);
        $input.attr('aria-controls', uid);
        let groups = [];
        let active = -1;
        let timer;
        let requestId = 0;
        let loadedFor = null;

        const open = function(isOpen){
            $list.prop('hidden', !isOpen);
            $input.attr('aria-expanded', isOpen ? 'true' : 'false');
            if (!isOpen) {
                setActive(-1);
            }
        };
        const setActive = function(index){
            active = index;
            const $options = $list.children('[role="option"]');
            $options.removeClass('is-active').attr('aria-selected', 'false');
            if (index < 0 || !$options.length) {
                $input.removeAttr('aria-activedescendant');
                return;
            }
            const $option = $options.eq(index).addClass('is-active').attr('aria-selected', 'true');
            $input.attr('aria-activedescendant', $option.attr('id'));
            $option[0].scrollIntoView({ block: 'nearest' });
        };
        const render = function(message){
            $list.empty();
            if (message) {
                $('<li class="academy-group-combobox__empty" role="presentation"></li>').text(message).appendTo($list);
                return;
            }
            groups.forEach(function(group, index){
                $('<li role="option" aria-selected="false"></li>')
                    .attr('id', uid + '_option_' + group.id)
                    .attr('data-index', index)
                    .toggleClass('is-selected', String(group.id) === String($value.val()))
                    .text(group.name)
                    .appendTo($list);
            });
        };
        const load = function(search){
            if (loadedFor === search) {
                return;
            }
            const current = ++requestId;
            render(academy_group.i18n.searching);
            $.ajax({
                url: academy_group.ajax_url,
                type: 'POST',
                data: {
                    action: 'academy_pro_group_plus/frontend/ecommerce/get_groups',
                    _wpnonce: academy_group.nonce,
                    search: search,
                },
                success: function(data){
                    // A slower, older search must not overwrite a newer one.
                    if (current !== requestId) {
                        return;
                    }
                    loadedFor = search;
                    groups = (data && data.data && data.data.data) || [];
                    render(groups.length ? '' : academy_group.i18n.no_groups);
                },
                error: function(){
                    if (current === requestId) {
                        groups = [];
                        render(academy_group.i18n.no_groups);
                    }
                },
            });
        };
        const choose = function(index){
            const group = groups[index];
            if (!group) {
                return;
            }
            $value.val(group.id);
            $input.val(group.name);
            loadedFor = null;
            open(false);
        };

        $input.on('focus click', function(){
            open(true);
            // Show every group again after a pick, not just the picked name.
            load($value.val() ? '' : this.value.trim());
        });
        $input.on('input', function(){
            // Editing the text drops the previous pick until a new one is made.
            $value.val('');
            open(true);
            const search = this.value.trim();
            clearTimeout(timer);
            timer = setTimeout(function(){ load(search); }, 250);
        });
        $input.on('keydown', function(e){
            const count = $list.children('[role="option"]').length;
            if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
                e.preventDefault();
                open(true);
                if (count) {
                    const step = e.key === 'ArrowDown' ? 1 : -1;
                    setActive((active + step + count) % count);
                }
            } else if (e.key === 'Enter') {
                // Enter picks a group; it must not submit the add-to-cart form.
                if (!$list.prop('hidden') && active >= 0) {
                    e.preventDefault();
                    choose(active);
                }
            } else if (e.key === 'Escape') {
                open(false);
            }
        });
        // mousedown, not click, so the input's blur doesn't close the list first.
        $list.on('mousedown', '[role="option"]', function(e){
            e.preventDefault();
            choose(parseInt(this.dataset.index, 10));
        });
        $input.on('blur', function(){
            // Typed an exact group name without picking it: take that group.
            if (!$value.val()) {
                const typed = this.value.trim().toLowerCase();
                const match = groups.findIndex(function(group){
                    return String(group.name).trim().toLowerCase() === typed;
                });
                if (typed && match >= 0) {
                    choose(match);
                }
            }
            open(false);
        });
    },
    showErrors = function(elm, msg){
        if(msg){
            elm.show();
            elm.text(msg);
            return;
        }
        elm.hide();
        elm.text('');
    },
    academy_errors = $('#academy_errors'),
    academy_messages = $('#academy_messages'),
    academy_group_errors = $('#academy_group_errors'),
    academy_group_name_errors = $('#academy_group_name_errors'),
    academy_group_id_errors = $('#academy_group_id_errors');
    quantity_errors = $('#academy_g_plus_quantity_errors'),
    quantity = $('input[name="quantity"]'),
    group_name = $('#academy_g_plus_group_name'),
    academy_group_id = $('#academy_group_id'),
    type_ = function(element){
            let type;
            element.each(function(index,elm){
                if(elm.checked){
                    type = elm.value;
                }
            });
            return type;
        },
    type_e = $('[name="group_"]'),
    academy_product_id = $('#academy_product_id');
    
    enrollWidgetTabs();
    showErrors(academy_errors, false);
    showErrors(academy_messages, false);
    showErrors(academy_group_errors, false);
    showErrors(academy_group_name_errors, false);
    showErrors(academy_group_id_errors, false);
    showErrors(quantity_errors, false);


    $('#academy-bulk-purchase-from-single-course, #academy-bulk-purchase-from-single-product-page').each(function(index, elm){
        // existing-group search and select
        groupCombobox(elm);

        // The widget can render more than once per page with the same ids, so
        // a label's `for` would resolve to the first copy (often a hidden one)
        // and clicking "New Group" / "Group existing" changed that copy
        // instead. Route each label to the element inside its own widget.
        $(elm).find('label[for]').on('click', function(e){
            const target = $(elm).find('#' + CSS.escape(this.htmlFor)).get(0);
            // Clicking the control itself already works natively.
            if (!target || e.target === target) {
                return;
            }
            e.preventDefault();
            if (target.type === 'radio' || target.type === 'checkbox') {
                // A real click, so the widget's own click handlers run too.
                if (target.type === 'checkbox' || !target.checked) {
                    target.click();
                }
                target.focus();
            } else {
                target.focus();
            }
        });

        // only for single product page
        if(this.id == 'academy-bulk-purchase-from-single-product-page'){
            $(elm.children[1]).hide();
            $(elm).fadeIn();
        }
        else{
            let price_total = $(elm).find('#academy_g_plus_price_total');
            let sym = elm.dataset.curSym == undefined ? '' : elm.dataset.curSym;
            // Volume pricing means the per-seat rate depends on the quantity
            // itself, so it's no longer a client-side unitPrice * qty
            // multiply — it has to ask the server, which knows the course's
            // configured tiers, for the price at this specific quantity.
            let priceRequestTimer;
            $(elm).find('#academy_g_plus_quantity').on('input', function(){
                let qty = this.value;
                let productId = $(elm).find('#academy_product_id').val();

                // Optimistic placeholder using the base (no-tier) rate while
                // the debounced request is in flight, so the total never sits
                // stale or blank.
                let placeholder = sym + String(elm.dataset.unitPrice * qty);
                price_total.val(placeholder);
                price_total.text(placeholder);

                clearTimeout(priceRequestTimer);
                if (!qty || !productId) {
                    return;
                }
                priceRequestTimer = setTimeout(function () {
                    $.ajax({
                        url: academy_group.ajax_url,
                        type: 'POST',
                        data: {
                            action: 'academy_pro_group_plus/frontend/ecommerce/get_price',
                            _wpnonce: academy_group.nonce,
                            product_id: productId,
                            quantity: qty,
                        },
                        success: function (data) {
                            let unitPrice = data?.data?.unit_price;
                            if (unitPrice === undefined || unitPrice === null) {
                                return;
                            }
                            let price = sym + String(unitPrice * qty);
                            price_total.val(price);
                            price_total.text(price);
                        },
                        // A failed price lookup leaves the optimistic base-rate
                        // placeholder in place rather than blocking the buyer.
                        error: function (error) {
                            console.log(error);
                        },
                    });
                }, 400);
            })
        }

        $(elm).find('[data-id="new_group"]').first().hide();
        $(elm).find('[data-id="group_existing"]').first().hide();

        // only for single product page
        $(elm).find('#academy_g_plus_bulk_purchase').click(function(){
            if(this.checked){
                 $(this).parent().next().fadeIn();
            }
            else{
                 $(this).parent().next().fadeOut();
            }
           
        });

        $(elm).find('[name="group_"]').click(function(){
            if(this.value == 'new_group'){
                 $(elm).find('[data-id="new_group"]').first().fadeIn();
                 $(elm).find('[data-id="group_existing"]').first().fadeOut();
            }
            else{
                $(elm).find('[data-id="new_group"]').first().fadeOut();
                $(elm).find('[data-id="group_existing"]').first().fadeIn();
            }
           
        });
        $(elm).fadeIn();
    })


    $('[name="add-to-cart"]').click(function(e){

        let procuct_page = $('#academy_g_plus_bulk_purchase');
        if(
            ($('.academy-g-plus-enroll-content-team').length && this.value) ||
            ( procuct_page.length > 0 && !procuct_page[0].checked)
        ) return;
        
        if ( procuct_page.length !== 0 ) {
            e.preventDefault();
        }
        showErrors(academy_errors, false);
        showErrors(academy_messages, false);
        showErrors(academy_group_errors, false);
        showErrors(academy_group_name_errors, false);
        showErrors(academy_group_id_errors, false);
        showErrors(quantity_errors, false);
        // procuct_page: only for single product page
        if(
            procuct_page.length == 0 ||
            procuct_page[0].checked
        ){
            if(procuct_page.length > 0){
                $('[name="add-to-cart"]')[0].disabled = true;
            }

            // The course-page widget markup (fixed IDs) can be rendered more than
            // once per page via the [academy_enroll_form] shortcode. Scope field
            // lookups to the widget that owns the clicked button instead of the
            // page-wide cached selectors, which always resolve to the first widget.
            let widget = procuct_page.length === 0
                ? $(this).closest('#academy-bulk-purchase-from-single-course')
                : null;

            // Existing group chosen but no group picked from the list.
            let scope = widget || $('#academy-bulk-purchase-from-single-product-page');
            if (type_(scope.find('[name="group_"]')) === 'group_existing' && !scope.find('#academy_group_id').val()) {
                showErrors(scope.find('#academy_group_id_errors').first(), academy_group.i18n.pick_group);
                scope.find('#academy_group_search').trigger('focus');
                if(procuct_page.length > 0){
                    $('[name="add-to-cart"]')[0].disabled = false;
                }
                return;
            }

            $.ajax({
                url: academy_group.ajax_url,
                type: 'POST',
                data: {
                    action: 'academy_pro_group_plus/frontend/ecommerce/add_to_cart',
                    _wpnonce: academy_group.nonce,
                    product_id: widget ? widget.find('#academy_product_id').val() : academy_product_id.val(),
                    quantity:   widget ? widget.find('input[name="quantity"]').val() : quantity.val(),
                    group_name: widget ? widget.find('#academy_g_plus_group_name').val() : group_name.val(),
                    group_id:   widget ? widget.find('#academy_group_id').val() : academy_group_id.val(),
                    type:       widget ? type_(widget.find('[name="group_"]')) : type_(type_e),
                },
                success: function(data){
                    if(procuct_page.length > 0){
                        $('[name="add-to-cart"]')[0].disabled = false;
                    }
                    
                    showErrors(academy_messages, data.data.message);
                    setTimeout(function(){
                        window.location.href = data.data.cart_url;
                    }, 500);
                },
                error: function(error){
                    let data = error.responseJSON.data;
                    data = typeof error.responseJSON.data.errors == 'object' ? error.responseJSON.data.errors : {};
                    if(procuct_page.length > 0){
                        $('[name="add-to-cart"]')[0].disabled = false;
                    }
                    else{
                        showErrors(quantity_errors, typeof data.quantity == 'object' ? data.quantity.join("\n"):'');
                    }
                    
                    showErrors(academy_errors,data.message);
                    showErrors(academy_group_errors,typeof data.type == 'object' ? data.type.join("\n"):'');
                    showErrors(academy_group_name_errors,typeof data.group_name == 'object' ? data.group_name.join("\n"):'');
                    showErrors(academy_group_id_errors,typeof data.group_id == 'object' ? data.group_id.join("\n"):'');
                }
            });
        }
    })
});
    