<?php
namespace AcademyProGroupPlus;

use AcademyProGroupPlus\Db\Migrations\{
	CreateGroupsTable,
	CreateGroupCoursesTable,
	CreateGroupOrganizersTable,
	CreateTeamsTable,
	CreateTeamMembersTable,
	CreateTeamCoursesTable,
	CreateTeamOrganizersTable
};

use AcademyProGroupPlus\Roles\{
	GroupOrganizer,
	TeamOrganizer,
	TeamMember,
	GiveFrontendManagementCapabilityToAdmin,
	GiveFrontendManagementCapabilityToEditor
};

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * @class Installation
 */
final class Installation {

	/**
	 * Option storing the schema version that has actually been applied to the DB,
	 * so already-active installs can be brought up to date on load (see maybe_upgrade()),
	 * independent of ACADEMY_PRO_GROUPPLUS_VERSION which is only set on fresh activation.
	 *
	 * @var string
	 */
	const DB_VERSION_KEY = 'group_plus';

	protected array $migrations = [
		CreateGroupsTable::class,
		CreateGroupCoursesTable::class,
		CreateGroupOrganizersTable::class,
		CreateTeamsTable::class,
		CreateTeamMembersTable::class,
		CreateTeamCoursesTable::class,
		CreateTeamOrganizersTable::class,
	];

	/**
	 * Maps a target version to only the migrations that changed to reach it, so
	 * maybe_upgrade() re-runs dbDelta solely against tables that actually need it.
	 * Re-running it against untouched tables is wasted work, and — because dbDelta
	 * can't parse the multi-line FOREIGN KEY / REFERENCES / ON DELETE·UPDATE clauses
	 * these migrations use — it also throws harmless but noisy DB errors on tables
	 * that didn't need touching. $migrations (above) remains the full fresh-install set.
	 *
	 * @var array<string, class-string[]>
	 */
	protected array $upgrade_steps = [
		'1.1' => [ CreateGroupCoursesTable::class ], // adds seat-expiry columns: start_date, end_date, status.
		// These three referenced {$wpdb->prefix}users, which doesn't exist on multisite subsites, so
		// the CREATE failed there. Only created where missing, never re-run against an existing table.
		'1.2' => [ CreateGroupOrganizersTable::class, CreateTeamMembersTable::class, CreateTeamOrganizersTable::class ],
	];

	protected array $roles = [
		GroupOrganizer::class,
		TeamOrganizer::class,
		TeamMember::class,
		GiveFrontendManagementCapabilityToAdmin::class,
		GiveFrontendManagementCapabilityToEditor::class,
	];

	/**
	 * @method init
	 * @return void
	 */
	public static function init(): void {
		$instance = new self();

		$instance->run_migration();
		$instance->add_roles();

		// fresh activation always installs the current schema; record it so
		// maybe_upgrade() doesn't redundantly re-run migrations on the next load.
		\Academy\Options::set( \Academy\Options::PRO_DB_VERSIONS, self::DB_VERSION_KEY, ACADEMY_PRO_GROUPPLUS_VERSION );
	}

	/**
	 * Bring an already-active install's schema up to date with the code.
	 *
	 * Unlike init(), this runs on every load (see GroupPlus::init_addon()) but is
	 * version-gated so it's a single cheap option read in the common case, and only
	 * re-runs dbDelta + one-off data backfills the first time it sees a version bump.
	 *
	 * @return void
	 */
	public static function maybe_upgrade(): void {
		$installed_version = \Academy\Options::get( \Academy\Options::PRO_DB_VERSIONS, self::DB_VERSION_KEY );

		if ( ACADEMY_PRO_GROUPPLUS_VERSION === $installed_version ) {
			return;
		}

		$instance = new self();

		foreach ( $instance->upgrade_steps as $version => $migrations ) {
			// already applied (or a fresh install ahead of this step) - skip it.
			if ( $installed_version && version_compare( $installed_version, $version, '>=' ) ) {
				continue;
			}

			foreach ( $migrations as $migration ) {
				if ( '1.2' === $version && $migration::tableExists() ) {
					continue;
				}
				// dbDelta() is additive/idempotent, safe to re-run against an existing table.
				$migration::runOnActivation();
			}
		}

		$instance->backfill_seat_expiry_columns( $installed_version );

		\Academy\Options::set( \Academy\Options::PRO_DB_VERSIONS, self::DB_VERSION_KEY, ACADEMY_PRO_GROUPPLUS_VERSION );
	}

	/**
	 * @method init
	 * @return void
	 */
	public function run_migration(): void {
		foreach ( $this->migrations as $migration ) {
			$migration::runOnActivation();
		}
	}
	public function add_roles(): void {
		foreach ( $this->roles as $role ) {
			$role::init();
		}
	}

	/**
	 * Seed start_date/end_date/status on group_courses rows that predate those
	 * columns (1.1). New rows are unaffected: start_date defaults to NULL at the
	 * column level, and callers are expected to set it explicitly going forward.
	 *
	 * @param string|false $from_version Previously installed db version, or false
	 *                                   if this is the first time it's been tracked.
	 * @return void
	 */
	protected function backfill_seat_expiry_columns( $from_version ): void {
		if ( $from_version && version_compare( $from_version, '1.1', '>=' ) ) {
			return;
		}

		global $wpdb;
		$table = $wpdb->prefix . ACADEMY_PLUGIN_SLUG . '_group_courses';

		// Existing packages never had a start date; treat their last update as the
		// best available proxy for when the package became active. end_date/status
		// are left at their column defaults (NULL / 'active') so nobody already
		// enrolled is locked out by this upgrade.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->query( "UPDATE {$table} SET start_date = updated_at WHERE start_date IS NULL" );
	}
}
