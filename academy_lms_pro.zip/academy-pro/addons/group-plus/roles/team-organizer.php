<?php
namespace AcademyProGroupPlus\Roles;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


class TeamOrganizer extends Abstracts\Role {

	public const ROLE_SLUG = 'academy_team_organizer';
	protected array $caps = [
		'manage_academy_team',
		'academy_team_member',
	];
	public function role_name(): string {
		return __( 'Academy team organizer', 'academy-pro' );
	}
}
