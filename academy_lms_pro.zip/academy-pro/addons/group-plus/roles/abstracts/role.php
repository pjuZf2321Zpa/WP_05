<?php
namespace AcademyProGroupPlus\Roles\Abstracts;

use AcademyProGroupPlus\Interfaces\Roles\RoleInterface;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


abstract class Role implements RoleInterface {

	protected array $caps = [];
	public function role_name(): string {
		return '';
	}

	public static function init(): void {
		$instance = new static();
		$instance->add_roles();
	}

	public function add_roles(): void {
		global $wp_roles;
		if ( empty( $wp_roles->roles[ static::ROLE_SLUG ] ?? '' ) ) {
			if ( function_exists( 'wpcom_vip_add_role' ) ) {
				wpcom_vip_add_role( static::ROLE_SLUG, $this->role_name(), array() );
				$role = get_role( static::ROLE_SLUG );
			} else {
				$role = add_role( static::ROLE_SLUG, $this->role_name() ); // phpcs:ignore WordPressVIPMinimum.Functions.RestrictedFunctions.custom_role_add_role -- non-VIP fallback.
			}
		} else {
			$role = get_role( static::ROLE_SLUG );
		}

		if ( $role && ! empty( $this->caps ) ) {
			foreach ( $this->caps as $cap ) {
				$role->add_cap( $cap );
			}
		}
	}
}
