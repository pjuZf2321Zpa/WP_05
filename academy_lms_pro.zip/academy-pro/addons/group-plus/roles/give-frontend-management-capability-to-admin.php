<?php
namespace AcademyProGroupPlus\Roles;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


class GiveFrontendManagementCapabilityToAdmin extends GiveFrontendManagementCapabilityToEditor {

	public const ROLE_SLUG = 'administrator';
}
