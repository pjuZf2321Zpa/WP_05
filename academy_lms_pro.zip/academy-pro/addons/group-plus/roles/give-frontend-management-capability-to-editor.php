<?php
namespace AcademyProGroupPlus\Roles;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


class GiveFrontendManagementCapabilityToEditor extends Abstracts\Role {

	public const ROLE_SLUG = 'editor';
	protected array $caps = [
		'manage_academy_group',
		'manage_academy_team',
		'academy_team_member',
	];
}
