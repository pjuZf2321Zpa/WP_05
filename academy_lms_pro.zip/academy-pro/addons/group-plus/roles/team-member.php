<?php
namespace AcademyProGroupPlus\Roles;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class TeamMember extends Abstracts\Role {

	public const ROLE_SLUG = 'academy_team_member_role';
	protected array $caps = [
		'academy_team_member',
	];
	public function role_name(): string {
		return __( 'Academy team member', 'academy-pro' );
	}
}
