<?php
namespace AcademyProGroupPlus\Roles;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


class GroupOrganizer extends Abstracts\Role {

	public const ROLE_SLUG = 'academy_group_organizer';
	protected array $caps = [
		'manage_academy_group',
		'manage_academy_team',
		'academy_team_member',
	];
	public function role_name(): string {
		return __( 'Academy group organizer', 'academy-pro' );
	}
}
