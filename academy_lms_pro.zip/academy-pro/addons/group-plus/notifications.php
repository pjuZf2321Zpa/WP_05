<?php
namespace AcademyProGroupPlus;

use AcademyProGroupPlus\Db\Models\Group;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * @class Notifications
 *
 * Emails a group's organizers when one of their seat packages expires.
 *
 * Scoped to the "just expired" moment only (fired once per package by
 * {@see Expiry::expire_due_seats()}) — no separate "expiring in N days"
 * reminder yet, since that needs its own per-package "already reminded" state
 * to avoid re-sending the reminder every day it stays inside the window,
 * and group_courses doesn't carry that yet. Left as a follow-up rather than
 * bolted on here without it.
 */
class Notifications {

	public static function init(): void {
		$self = new self();
		add_action( 'academy_pro_group_plus/seats_expired', array( $self, 'notify_expired' ), 10, 2 );
	}

	public function notify_expired( int $group_id, int $course_id ): void {
		$group = Group::ins()->get_by_id( $group_id );
		if ( ! $group ) {
			return;
		}

		$course_title = get_the_title( $course_id );
		if ( '' === $course_title ) {
			return; // course was deleted out from under an expiring package.
		}

		$organizers = Group::ins()->organizers( $group_id, 100, 1 );

		foreach ( $organizers['data'] ?? [] as $organizer ) {
			$email = $organizer['user_email'] ?? '';
			if ( ! is_email( $email ) ) {
				continue;
			}

			$subject = sprintf(
				/* translators: %s: course title */
				__( 'Seat access expired: %s', 'academy-pro' ),
				$course_title
			);

			$body = sprintf(
				/* translators: 1: organizer name, 2: course title, 3: group name */
				__(
					"Hi %1\$s,\n\nYour team's seat package for \"%2\$s\" (group: %3\$s) has expired. Members of this group can no longer access the course.\n\nRenew the package to restore access.",
					'academy-pro'
				),
				$organizer['user_login'] ?? '',
				$course_title,
				$group['name'] ?? ''
			);

			/**
			 * Filters the recipient/subject/body before an expiry email is sent,
			 * so a site can swap in its own template without editing this class.
			 *
			 * @param array $args {group_id, course_id, email, subject, body}
			 */
			$args = apply_filters(
				'academy_pro_group_plus/seat_expired_email',
				array(
					'group_id'  => $group_id,
					'course_id' => $course_id,
					'email'     => $email,
					'subject'   => $subject,
					'body'      => $body,
				)
			);

			wp_mail( $args['email'], $args['subject'], $args['body'] ); // phpcs:ignore WordPressVIPMinimum.Functions.RestrictedFunctions.wp_mail_wp_mail -- single transactional email
		}//end foreach
	}
}
