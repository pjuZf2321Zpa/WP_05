<?php
namespace AcademyProGroupPlus\interfaces\Roles;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


interface RoleInterface {

	public function role_name(): string;
	public static function init(): void;
	public function add_roles(): void;
}
