<?php
namespace AcademyProGroupPlus\interfaces\Db;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


interface CommonInterface {
	public function __construct();
	public static function add_prefix( string $table ): string;
}
