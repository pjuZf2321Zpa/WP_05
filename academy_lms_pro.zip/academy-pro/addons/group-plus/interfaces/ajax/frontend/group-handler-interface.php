<?php
namespace AcademyProGroupPlus\Interfaces\Ajax\Frontend;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


interface GroupHandlerInterface {

	public function __construct();

	public function get_groups( $payload_data ): void;
	public function get_group( $payload_data ): void;
	public function update_group( $payload_data ): void;
	public function delete_group( $payload_data ): void;


	public function create_organizer( $payload_data ): void;

	public function get_selectable_organizers( $payload_data ): void;
	public function add_organizers_to_group( $payload_data ): void;
	public function remove_organizers_from_group( $payload_data ): void;
	public function get_organizers_from_group( $payload_data ): void;

	public function request_courses_to_group( $payload_data ): void;
	public function update_course_seats( $payload_data ): void;
	public function remove_courses_from_group( $payload_data ): void;
	public function get_courses_from_group( $payload_data ): void;
}
