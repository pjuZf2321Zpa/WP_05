<?php
namespace AcademyProGroupPlus\interfaces\Ajax;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


interface OrganizerHandlerInterface {
	public function get_organizers( $payload_data ): void;
}
