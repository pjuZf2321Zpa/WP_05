<?php
namespace AcademyProGroupPlus\Interfaces\Ajax\Admin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


interface TeamHandlerInterface {


	public function __construct();

	public function get_teams( $payload_data ): void;
	public function get_team( $payload_data ): void;
	public function create_team( $payload_data ): void;
	public function update_team( $payload_data ): void;
	public function delete_team( $payload_data ): void;


	public function create_user_to_team( $payload_data ): void;

	public function add_members_to_team( $payload_data ): void;
	public function remove_members_from_team( $payload_data ): void;
	public function get_members_from_team( $payload_data ): void;

	public function add_organizers_to_team( $payload_data ): void;
	public function remove_organizers_from_team( $payload_data ): void;
	public function get_organizers_from_team( $payload_data ): void;

	public function add_courses_to_team( $payload_data ): void;
	public function remove_courses_from_team( $payload_data ): void;
	public function get_courses_from_team( $payload_data ): void;
}
