<?php
/**
 * Per-resource WRITE enforcement for staff on academy/v1 routes.
 *
 * Reads are intentionally permissive (a screen needs many cross-resource reads
 * to function; {@see Caps} elevates those). Writes to a mapped resource
 * require the matching verb permission (courses.create / courses.update /
 * courses.delete, etc.). Everything else for a staff user falls through to
 * the normal flow (which `Caps` has elevated).
 *
 * Courses/lessons/quizzes/announcements/certificates additionally ride real
 * native post-type caps the controller grants per-permission (see
 * Permissions::native_caps_for()) — this guard is what separates "view" from
 * "create/update/delete" for them, since native caps alone can't.
 *
 * Ported from `storeengine-pro/addons/role-permission/rest-guard.php`.
 *
 * @package AcademyProRolePermission
 */

namespace AcademyProRolePermission;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use WP_Error;
use WP_REST_Request;

class RestGuard {

	const ROUTE_PREFIX = '/academy/v1/';

	const WRITE_METHODS = array( 'POST', 'PUT', 'PATCH', 'DELETE' );

	public function register(): void {
		add_filter( 'rest_pre_dispatch', array( $this, 'guard' ), 10, 3 );
	}

	/**
	 * @param mixed $result
	 * @param mixed $server
	 * @param mixed $request
	 *
	 * @return mixed
	 */
	public function guard( $result, $server, $request ) {
		if ( null !== $result || ! $request instanceof WP_REST_Request ) {
			return $result;
		}

		$route = $request->get_route();
		if ( 0 !== strpos( $route, self::ROUTE_PREFIX ) ) {
			return $result;
		}

		// Flag the dispatch so Caps can elevate this academy/v1 request.
		Caps::mark_academy_rest();

		// Only staff are constrained; real admins and non-staff are untouched.
		if ( ! Permissions::is_staff_user() ) {
			return $result;
		}

		$method = strtoupper( $request->get_method() );
		if ( ! in_array( $method, self::WRITE_METHODS, true ) ) {
			return $result; // reads always allowed
		}

		$slug = $this->required_write_slug( $route, $method );
		if ( null === $slug || current_user_can( $slug ) ) {
			return $result;
		}

		return new WP_Error(
			'academy_staff_forbidden',
			Permissions::denied_message( $slug ),
			array( 'status' => rest_authorization_required_code() )
		);
	}

	/**
	 * The staff slug a write requires, or null when the route isn't gated.
	 *
	 * @param string $route
	 * @param string $method
	 */
	private function required_write_slug( string $route, string $method ): ?string {
		$path     = trim( substr( $route, strlen( self::ROUTE_PREFIX ) ), '/' );
		$segments = explode( '/', $path );
		$segment  = $segments[0] ?? '';

		$map = Permissions::write_route_map();
		if ( ! isset( $map[ $segment ] ) ) {
			return null;
		}

		$resource = $map[ $segment ];
		$base     = Permissions::PREFIX . '.' . $resource;

		// Single-slug resource (e.g. settings): any write needs the base cap.
		if ( ! Permissions::is_crud_resource( $resource ) ) {
			return $base;
		}

		$is_collection = count( $segments ) === 1;

		if ( $is_collection ) {
			return 'POST' === $method ? $base . '.create' : $base . '.update';
		}

		// Item-level: deleting the item itself = delete; everything else (sub-
		// resource writes, edits) = update.
		if ( 'DELETE' === $method && count( $segments ) === 2 ) {
			return $base . '.delete';
		}

		return $base . '.update';
	}
}
