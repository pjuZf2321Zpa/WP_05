<?php
/**
 * Let managed staff see ALL records of a resource they can view.
 *
 * `CourseController`/`AnnouncementController::prepare_items_query()` scope
 * non-admin list queries to the current user's own authored posts (a guard
 * meant for Instructor self-service). A staff user never has real
 * `manage_options` on an admin page load ({@see Caps} only elevates inside
 * Academy REST/ajax), so that guard misfires: a "courses view" staffer would
 * see only the one course they happen to have authored instead of every
 * course an administrator sees.
 *
 * A back-office "view" permission means "see this resource", not "see only
 * your own". Staff already hold the resource's `edit_others_*` native cap
 * (granted alongside the view slug — see Permissions::native_cap_bundles()),
 * so the sole thing hiding the rest is the injected `author` arg. For a staff
 * user who holds the resource's view permission we strip that scoping from
 * the CPT list query so they see every record, exactly like an admin.
 *
 * Ported from `storeengine-pro/addons/role-permission/list-scope.php`.
 *
 * @package AcademyProRolePermission
 */

namespace AcademyProRolePermission;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ListScope {

	/**
	 * CPT post type => the staff view slug that unlocks the full list.
	 *
	 * @return array<string,string>
	 */
	private static function resource_map(): array {
		$map = array(
			'academy_courses'      => Permissions::PREFIX . '.courses',
			'academy_lessons'      => Permissions::PREFIX . '.lessons',
			'academy_quiz'         => Permissions::PREFIX . '.quizzes',
			'academy_announcement' => Permissions::PREFIX . '.announcements',
			'academy_certificate'  => Permissions::PREFIX . '.certificates',
		);

		return apply_filters( 'academy/staff/list_scope_map', $map );
	}

	public function register(): void {
		foreach ( self::resource_map() as $post_type => $view_slug ) {
			add_filter( "rest_{$post_type}_query", array( $this, 'unscope_for_staff' ), 20, 2 );
		}
	}

	/**
	 * Drop the own-author restriction for a staff user who may view the resource.
	 *
	 * @param array $args    WP_Query args assembled from the REST request.
	 * @param mixed $request The REST request (unused, signature contract).
	 *
	 * @return array
	 */
	public function unscope_for_staff( array $args, $request = null ): array {
		if ( ! Permissions::is_staff_user() ) {
			return $args;
		}

		$post_type = is_array( $args['post_type'] ?? null ) ? ( $args['post_type'][0] ?? '' ) : ( $args['post_type'] ?? '' );
		$view_slug = self::resource_map()[ $post_type ] ?? '';

		if ( ! $view_slug || ! current_user_can( $view_slug ) ) {
			return $args;
		}

		// Remove the own-records scoping so the staffer sees the whole list.
		unset( $args['author'], $args['author__in'] );

		return $args;
	}
}
