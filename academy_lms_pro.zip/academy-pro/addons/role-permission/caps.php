<?php
/**
 * Scoped privilege elevation for staff users.
 *
 * Academy's admin checks `manage_options` (or Instructor-only caps like
 * `manage_academy_instructor`) across many REST endpoints AND admin-ajax
 * actions. Gating each one individually is brittle and breaks the many
 * cross-resource reads a single screen needs. Instead we grant a staff user
 * `manage_options` ONLY for the duration of an Academy request (REST route
 * under academy/v1, or an `academy/*`-prefixed admin-ajax action). Outside
 * those contexts the user has no elevated access.
 *
 * This makes every permitted screen fully functional. The boundary on WHAT a
 * staff user can reach is enforced elsewhere: menus per-screen ({@see Menu})
 * and writes per-resource ({@see RestGuard} / {@see AjaxGuard}).
 *
 * Ported from `storeengine-pro/addons/role-permission/caps.php`.
 *
 * @package AcademyProRolePermission
 */

namespace AcademyProRolePermission;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use WP_User;

class Caps {

	/**
	 * Set by {@see RestGuard} when dispatching an academy/v1 route.
	 *
	 * @var bool
	 */
	private static bool $in_academy_rest = false;

	public function register(): void {
		add_filter( 'user_has_cap', array( $this, 'elevate' ), 10, 4 );
	}

	public static function mark_academy_rest(): void {
		self::$in_academy_rest = true;
	}

	/**
	 * Coarse gate capabilities elevated for staff, in addition to
	 * `manage_options`. Unlike StoreEngine — where nearly every ajax/REST
	 * action gates on `manage_options` alone — Academy's own ajax handlers
	 * gate the majority of course/lesson/quiz/announcement actions on
	 * `manage_academy_instructor` instead. Without also elevating that cap,
	 * `AbstractAjaxHandler`'s *base* capability check (which runs before the
	 * `academy/request/authorize` filter this addon hooks) would reject staff
	 * before AjaxGuard ever gets a chance to apply its own, finer per-action
	 * policy. Reads staying broadly reachable for any elevated staff member
	 * (e.g. Settings, Q&A) mirrors StoreEngine's own explicit design — writes,
	 * not reads, are the enforcement point (see {@see RestGuard} /
	 * {@see AjaxGuard}, and openspec design.md's note on this tradeoff).
	 *
	 * @var string[]
	 */
	private static array $elevated_caps = array( 'manage_options', 'manage_academy_instructor' );

	/**
	 * @param array   $allcaps User's caps map.
	 * @param array   $caps    Required primitive caps.
	 * @param array   $args    [ $cap, $user_id, ...$context ].
	 * @param WP_User $user    User object.
	 *
	 * @return array
	 */
	public function elevate( array $allcaps, array $caps, array $args, $user ): array {
		if ( ! $user instanceof WP_User || ! $user->ID ) {
			return $allcaps;
		}

		// Real admins already have it; non-staff get nothing.
		if ( ! empty( $allcaps['manage_options'] ) ) {
			return $allcaps;
		}
		if ( empty( get_user_meta( $user->ID, Permissions::META_IS_SET, true ) ) ) {
			return $allcaps;
		}

		// SECURITY: never elevate for the staff-permission management endpoints
		// themselves, regardless of what in_academy_context() says. Those routes
		// are gated on a real current_user_can('manage_options')
		// (Permissions::admin_can()) specifically so a staff member can never
		// touch their own or another staff member's grants — see design.md
		// Decision 4. If this method ever elevated during a request to that
		// endpoint, that guarantee would be silently defeated. This check is
		// deliberately redundant with is_academy_rest_uri() being scoped away
		// from academy-pro/v1 below: a single narrow namespace is easy to keep
		// correct, but a self-management endpoint is exactly the place to also
		// have an explicit, impossible-to-miss denylist.
		if ( self::is_staff_management_route() ) {
			return $allcaps;
		}

		if ( self::in_academy_context() ) {
			foreach ( self::$elevated_caps as $cap ) {
				$allcaps[ $cap ] = true;
			}
		}

		return $allcaps;
	}

	/**
	 * Whether the current request targets the staff-permission management
	 * REST controller (list/search/get/grant/revoke/remove-all for OTHER
	 * users' permissions) — see the SECURITY note in {@see elevate()}.
	 */
	private static function is_staff_management_route(): bool {
		if ( ! ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
			return false;
		}

		$needle = 'academy-pro/v1/staff-permissions';

		$route = isset( $_GET['rest_route'] ) ? sanitize_text_field( wp_unslash( $_GET['rest_route'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( $route ) {
			return false !== strpos( ltrim( $route, '/' ), $needle );
		}

		$uri = isset( $_SERVER['REQUEST_URI'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '';

		return false !== strpos( $uri, $needle );
	}

	/**
	 * Whether the current request is an Academy data context worth elevating.
	 *
	 * Deliberately limited to REST + Academy admin-ajax — single-endpoint
	 * requests where no admin menu is rendered. We do NOT elevate during an
	 * admin PAGE load: that request also renders the global WP sidebar, and
	 * elevating manage_options there would reveal every OTHER plugin's admin
	 * menu. Staff reach Academy pages via the `read` cap on its menu items
	 * instead ({@see Menu}); the SPA's data then flows through these elevated
	 * REST/ajax calls.
	 */
	private static function in_academy_context(): bool {
		if ( wp_doing_ajax() ) {
			$action = isset( $_REQUEST['action'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['action'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

			// Pro addons (Tutor Booking, Assignments, Meeting/Zoom/Google Meet,
			// Analytics, Grade Book, Group Plus, etc.) register their ajax actions
			// under an `academy_pro`-prefixed namespace (e.g. `academy_pro/...`,
			// `academy_pro_meeting/...`, `academy_pro_assignments/...`) rather than
			// the free plugin's `academy/` — see AbstractAjaxHandler::$namespace
			// across addons/*/ajax.php. Without matching this prefix too, staff
			// never get elevated for any pro-addon ajax action and every one of
			// those screens silently 403s despite being visible in the menu.
			return 0 === strpos( $action, 'academy/' ) || 0 === strpos( $action, 'academy_pro' );
		}

		if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
			return self::$in_academy_rest || self::is_academy_rest_uri();
		}

		return false;
	}

	/**
	 * Fallback REST detection straight off the request URI / rest_route param,
	 * for the window before {@see RestGuard} has flagged the dispatch.
	 *
	 * Deliberately scoped to ONLY `academy/v1` (the free plugin's namespace,
	 * which pro screens for courses/lessons/etc. also read through) — NOT
	 * `academy-pro/v1` generally. Broadening this to the whole `academy-pro/v1`
	 * namespace was tried and reverted: that namespace also hosts
	 * {@see \AcademyProRolePermission\Api\StaffPermissionController}, and
	 * elevating staff there would defeat its manage_options-only guarantee
	 * (see the SECURITY note in {@see elevate()}). If a pro-addon resource in
	 * the permission taxonomy (Tutor Booking, Assignments, Course Bundle,
	 * Group Plus — see openspec design.md's flagged risk) turns out to
	 * register its REST routes under academy-pro/v1 rather than academy/v1,
	 * elevate for that *specific* route segment here, not the whole namespace.
	 */
	private static function is_academy_rest_uri(): bool {
		$prefix = 'academy/v1';

		// SECURITY: match the route as an anchored prefix of the URI *path*, never
		// a substring of the whole URI. A bare strpos() on REQUEST_URI also
		// matched the query string, so `/wp-json/wp/v2/settings?x=/wp-json/academy/v1`
		// elevated any staff member to manage_options on WP core's settings
		// endpoint (read AND write site title/URL/admin email).
		$route = isset( $_GET['rest_route'] ) ? sanitize_text_field( wp_unslash( $_GET['rest_route'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( $route ) {
			return 0 === strpos( '/' . ltrim( $route, '/' ) . '/', '/' . $prefix . '/' );
		}

		$uri  = isset( $_SERVER['REQUEST_URI'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '';
		$path = (string) wp_parse_url( $uri, PHP_URL_PATH );
		$home = (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH );

		return 0 === strpos( trailingslashit( $path ), trailingslashit( $home ) . rest_get_url_prefix() . '/' . $prefix . '/' );
	}
}
