<?php
/**
 * Staff menu access — the per-screen boundary.
 *
 * Academy's top-level menu page is registered with a hardcoded `manage_options`
 * (`includes/admin/menu.php::admin_menu()`), separately from its submenu items
 * (which come from `Helper::get_admin_menu_list()`, itself already run through
 * `apply_filters('academy/admin_menu_list', $menu)`). So this addon has two
 * jobs:
 *   1. hook `academy/admin_menu_list` (drives the SPA nav JSON + each
 *      `add_submenu_page()` cap): drop items a staff user lacks permission
 *      for and lower the rest to `read`.
 *   2. `admin_menu` (late): relax the hardcoded top-level cap in
 *      `$GLOBALS['menu']` so the parent menu (and therefore its permitted
 *      children) is reachable at all.
 *
 * Every Academy submenu routes through `get_admin_menu_list()` — unlike
 * StoreEngine, there's no confirmed case of a submenu registered directly via
 * `add_submenu_page()` outside that filter, so no native-submenu gating pass
 * is needed here (see StoreEngine's `gate_native_submenus()` for what that
 * would look like if one is found later).
 *
 * Dashboard, Add-ons, Tools, Get-Pro, What's New, and Withdraw are not in the
 * permission map, so they are hidden from staff entirely.
 *
 * Ported from `storeengine-pro/addons/role-permission/menu.php`.
 *
 * @package AcademyProRolePermission
 */

namespace AcademyProRolePermission;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Menu {

	const STAFF_CAP = 'read';

	const PARENT_SLUG = 'academy';

	public function register(): void {
		add_filter( 'academy/admin_menu_list', array( $this, 'filter_menu_for_staff' ), 99 );
		add_action( 'admin_menu', array( $this, 'relax_top_level' ), 9999 );
	}

	/**
	 * @param array $items menu-key => item.
	 *
	 * @return array
	 */
	public function filter_menu_for_staff( array $items ): array {
		if ( ! Permissions::is_staff_user() ) {
			return $items;
		}

		$map = Permissions::menu_permission_map();

		foreach ( array_keys( $items ) as $key ) {
			if ( ! isset( $map[ $key ] ) || ! current_user_can( $map[ $key ] ) ) {
				unset( $items[ $key ] );
				continue;
			}

			$items[ $key ]['capability'] = self::STAFF_CAP;
		}

		return $items;
	}

	/**
	 * Relax the hardcoded top-level menu capability so the menu is visible and
	 * the parent link resolves for staff.
	 *
	 * We deliberately do NOT repoint the top-level slug (that desyncs WP's page
	 * registration and the parent link breaks). The parent keeps pointing at
	 * the `academy` Dashboard page; Dashboard content itself stays admin-only
	 * (not in the permission map) — the SPA is expected to redirect staff to
	 * their first permitted screen before rendering it (mirrors StoreEngine's
	 * Dashboard-lock precedent; confirm/implement the equivalent redirect in
	 * the React shell during Phase F).
	 */
	public function relax_top_level(): void {
		if ( ! Permissions::is_staff_user() ) {
			return;
		}

		if ( empty( $GLOBALS['menu'] ) || ! is_array( $GLOBALS['menu'] ) ) {
			return;
		}

		foreach ( $GLOBALS['menu'] as &$entry ) {
			if ( isset( $entry[2] ) && self::PARENT_SLUG === $entry[2] ) {
				$entry[1] = self::STAFF_CAP; // capability
				break;
			}
		}
		unset( $entry );
	}

	/**
	 * First menu page (in map order) the current staff user may access.
	 */
	public static function first_permitted_page(): ?string {
		foreach ( Permissions::menu_permission_map() as $page => $slug ) {
			if ( current_user_can( $slug ) ) {
				return $page;
			}
		}

		return null;
	}
}
