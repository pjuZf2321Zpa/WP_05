<?php
/**
 * Staff permission management REST controller (admin-only).
 *
 * Per-user capability grants with auto-granted base logic, ported from
 * `storeengine-pro/addons/role-permission/api/staff-permission-controller.php`.
 *
 * @package AcademyProRolePermission\Api
 */

namespace AcademyProRolePermission\Api;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AcademyProRolePermission\Permissions;
use WP_User;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

class StaffPermissionController {

	protected string $namespace = 'academy-pro/v1';

	protected string $rest_base = 'staff-permissions';

	public function register_routes(): void {
		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base,
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'list_staff' ),
					'permission_callback' => array( Permissions::class, 'admin_can' ),
				),
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'update_permission' ),
					'permission_callback' => array( Permissions::class, 'admin_can' ),
				),
			)
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/search',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'search_users' ),
					'permission_callback' => array( Permissions::class, 'admin_can' ),
				),
			)
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/(?P<id>\d+)',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_user' ),
					'permission_callback' => array( Permissions::class, 'admin_can' ),
				),
				array(
					'methods'             => WP_REST_Server::DELETABLE,
					'callback'            => array( $this, 'remove_all' ),
					'permission_callback' => array( Permissions::class, 'admin_can' ),
				),
			)
		);
	}

	public function list_staff(): WP_REST_Response {
		$users = get_users(
			array(
				'meta_key'   => Permissions::META_IS_SET, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
				'meta_value' => '1', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
			)
		);

		return new WP_REST_Response( array_map( array( $this, 'payload' ), $users ) );
	}

	public function search_users( WP_REST_Request $request ): WP_REST_Response {
		$q = sanitize_text_field( (string) $request->get_param( 'q' ) );
		if ( strlen( $q ) < 2 ) {
			return new WP_REST_Response( array() );
		}

		$users = get_users(
			array(
				'search'         => "*{$q}*",
				'search_columns' => array( 'user_email', 'display_name', 'user_login' ),
				'number'         => 10,
			)
		);

		return new WP_REST_Response(
			array_map(
				fn( WP_User $u ) => array(
					'id'    => $u->ID,
					'name'  => $u->display_name,
					'email' => $u->user_email,
				),
				$users
			)
		);
	}

	public function get_user( WP_REST_Request $request ): WP_REST_Response {
		$user = get_user_by( 'id', (int) $request['id'] );
		if ( ! $user ) {
			return $this->not_found();
		}

		return new WP_REST_Response( $this->payload( $user ) );
	}

	public function update_permission( WP_REST_Request $request ): WP_REST_Response {
		$user_id    = (int) $request->get_param( 'user_id' );
		$permission = sanitize_text_field( (string) $request->get_param( 'permission' ) );
		$action     = sanitize_text_field( (string) $request->get_param( 'action' ) );

		$user = $user_id ? get_user_by( 'id', $user_id ) : null;
		if ( ! $user ) {
			return $this->not_found();
		}

		if ( ! in_array( $permission, Permissions::all_slugs(), true ) ) {
			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => __( 'Invalid permission slug.', 'academy-pro' ),
				),
				422
			);
		}

		if ( ! in_array( $action, array( 'grant', 'revoke' ), true ) ) {
			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => __( 'Action must be "grant" or "revoke".', 'academy-pro' ),
				),
				422
			);
		}

		if ( 'grant' === $action ) {
			$user->add_cap( $permission );
			$this->sync_auto_granted_base( $user, $permission, 'grant' );
			update_user_meta( $user->ID, Permissions::META_IS_SET, 1 );
		} else {
			$user->remove_cap( $permission );
			$this->sync_auto_granted_base( $user, $permission, 'revoke' );
			$this->sync_is_set_meta( $user );
		}

		$this->sync_manager_role( $user );
		Permissions::reconcile_native_caps( $user );

		/**
		 * Fires after a staff user's permission set changes (grant or revoke).
		 * Lets other addons reconcile the native caps they own for their own
		 * dotted slugs without this controller needing to know about them.
		 *
		 * @param WP_User $user The user whose permissions changed.
		 */
		do_action( 'academy/staff/permissions_changed', $user );

		return new WP_REST_Response( $this->payload( $user ) );
	}

	public function remove_all( WP_REST_Request $request ): WP_REST_Response {
		$user = get_user_by( 'id', (int) $request['id'] );
		if ( ! $user ) {
			return $this->not_found();
		}

		foreach ( Permissions::all_slugs() as $slug ) {
			$user->remove_cap( $slug );
		}
		foreach ( Permissions::managed_native_caps() as $cap ) {
			$user->remove_cap( $cap );
		}
		foreach ( Permissions::generic_authoring_caps() as $cap ) {
			$user->remove_cap( $cap );
		}

		delete_user_meta( $user->ID, Permissions::META_IS_SET );
		delete_user_meta( $user->ID, Permissions::META_AUTO_CAPS );

		$this->sync_manager_role( $user );

		// Slugs are gone now; addons reconcile their native caps down to none.
		do_action( 'academy/staff/permissions_changed', $user );

		return new WP_REST_Response( array( 'success' => true ) );
	}

	/**
	 * Keeps the real, wp-admin-visible `academy_manager` role in lockstep with
	 * whether Manage Roles currently considers this user "staff"
	 * ({@see Permissions::META_IS_SET}) — granting any permission here should
	 * make the user show up (and be labeled) as Academy Manager in the native
	 * Users list, the same way Instructor/Student already do; losing every
	 * permission should take the label back off. Added additively
	 * ({@see WP_User::add_role()} / {@see WP_User::remove_role()}), never
	 * replacing whatever other role(s) the account already holds.
	 *
	 * This is also what makes the `manage_academy_manager` capability the
	 * frontend's author-scoping check relies on (see the 10 Redux slices'
	 * `!current_user_can.manage_academy_manager` condition) actually true for
	 * Manage-Roles-granted staff — that capability comes from holding the real
	 * role ({@see \Academy\Classes\Role::get_manager_caps()}), which until this
	 * sync existed only ever applied to a user assigned the role directly.
	 *
	 * @param WP_User $user
	 */
	private function sync_manager_role( WP_User $user ): void {
		$is_staff    = (bool) get_user_meta( $user->ID, Permissions::META_IS_SET, true );
		$has_role    = in_array( 'academy_manager', (array) $user->roles, true );

		if ( $is_staff && ! $has_role ) {
			$user->add_role( 'academy_manager' );
		} elseif ( ! $is_staff && $has_role ) {
			$user->remove_role( 'academy_manager' );
		}
	}

	// ── payload ──────────────────────────────────────────────────────────────

	/**
	 * The staff member's permissions, as returned by the API.
	 *
	 * @param WP_User $user
	 */
	private function payload( WP_User $user ): array {
		$granted = array_values(
			array_filter(
				Permissions::all_slugs(),
				fn( string $slug ) => $user->has_cap( $slug )
			)
		);

		return array(
			'id'           => $user->ID,
			'email'        => $user->user_email,
			'name'         => $user->display_name,
			'permissions'  => $granted,
			'is_set'       => (bool) get_user_meta( $user->ID, Permissions::META_IS_SET, true ),
			'auto_granted' => $this->get_auto_caps( $user ),
		);
	}

	private function not_found(): WP_REST_Response {
		return new WP_REST_Response(
			array(
				'success' => false,
				'message' => __( 'User not found.', 'academy-pro' ),
			),
			404
		);
	}

	// ── auto-grant base (granting a verb auto-grants its base) ────────────────

	/**
	 * Flags whether the staff member holds any permission at all.
	 *
	 * @param WP_User $user
	 */
	private function sync_is_set_meta( WP_User $user ): void {
		foreach ( Permissions::all_slugs() as $slug ) {
			if ( $user->has_cap( $slug ) ) {
				update_user_meta( $user->ID, Permissions::META_IS_SET, 1 );
				return;
			}
		}
		delete_user_meta( $user->ID, Permissions::META_IS_SET );
	}

	private function sync_auto_granted_base( WP_User $user, string $permission, string $action ): void {
		$parts = explode( '.', $permission );
		if ( count( $parts ) !== 3 ) {
			return;
		}

		$base = $parts[0] . '.' . $parts[1];

		if ( 'grant' === $action ) {
			if ( ! $user->has_cap( $base ) ) {
				$user->add_cap( $base );
				$auto = $this->get_auto_caps( $user );
				if ( ! in_array( $base, $auto, true ) ) {
					$auto[] = $base;
					update_user_meta( $user->ID, Permissions::META_AUTO_CAPS, $auto );
				}
			}

			return;
		}

		$auto = $this->get_auto_caps( $user );
		if ( ! in_array( $base, $auto, true ) ) {
			return;
		}

		$siblings = array_filter(
			Permissions::all_slugs(),
			fn( string $slug ) => str_starts_with( $slug, $base . '.' ) && $user->has_cap( $slug )
		);

		if ( empty( $siblings ) ) {
			$user->remove_cap( $base );
			update_user_meta(
				$user->ID,
				Permissions::META_AUTO_CAPS,
				array_values( array_filter( $auto, fn( $c ) => $c !== $base ) )
			);
		}
	}

	private function get_auto_caps( WP_User $user ): array {
		$raw = get_user_meta( $user->ID, Permissions::META_AUTO_CAPS, true );

		return is_array( $raw ) ? $raw : array();
	}
}
