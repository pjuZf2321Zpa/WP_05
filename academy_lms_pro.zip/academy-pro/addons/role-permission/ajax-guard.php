<?php
/**
 * Per-action AJAX authorization for staff users.
 *
 * Every Academy request handler declares a single coarse `capability` per
 * action — `manage_options`, `manage_academy_instructor`, or `read`. {@see
 * Caps} elevates a staff user to both `manage_options` and
 * `manage_academy_instructor` for the whole Academy request, so WITHOUT this
 * guard a staff user passes every one of those checks: someone granted only
 * "Courses: View" could import courses, change enrollment status, moderate
 * lesson comments, or touch Settings. This closes that hole on the admin-ajax
 * surface; {@see RestGuard} closes the equivalent hole on the academy/v1 REST
 * surface.
 *
 * Enforcement hooks the free plugin's `academy/request/authorize` filter
 * (added by `academy/openspec/changes/role-permission/`), which fires after
 * the base capability + nonce checks and hands us the dispatching handler
 * instance. We map (handler class, action) -> the staff permission slug the
 * action needs and deny when the user lacks it.
 *
 * Design (mirrors `storeengine-pro/addons/role-permission/ajax-guard.php`):
 *   - ONLY staff users are constrained. Admins and ordinary logged-in users
 *     are never touched — zero regression risk for everyone who isn't
 *     managed staff.
 *   - Keyed by handler CLASS, not bare action name, since actions are unique
 *     per class here but this still avoids any future collision risk.
 *   - Deny-by-default: an unclassified handler is denied for staff, so a
 *     newly added or not-yet-audited handler stays admin-only until someone
 *     explicitly maps it. Extend via the `academy/staff/ajax_policy` filter.
 *
 * This first pass was built by reading every handler in `includes/ajax/`
 * (`Course`, `Instructor`, `Lesson`, `Miscellaneous`, `PluginDownloader`,
 * `Registration`, `Settings`, `Student`, `Tools`) — see
 * academy-pro/openspec/changes/role-permission/tasks.md for notes on any
 * classification made on a best-effort basis pending further product input
 * (e.g. Registration's admin-triggered vs. self-service actions).
 *
 * @package AcademyProRolePermission
 */

namespace AcademyProRolePermission;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use WP_Error;

class AjaxGuard {

	/** Action is always allowed for staff (frontend / per-user / self-service). */
	const ALLOW = '__allow__';

	/** Action is never allowed for staff (admin-only surface). */
	const DENY = '__deny__';

	public function register(): void {
		add_filter( 'academy/request/authorize', array( $this, 'authorize' ), 10, 2 );
	}

	/**
	 * @param true|WP_Error $authorized
	 * @param array         $context
	 *
	 * @return true|WP_Error
	 */
	public function authorize( $authorized, array $context ) {
		if ( is_wp_error( $authorized ) ) {
			return $authorized; // already denied upstream.
		}

		// Only managed staff are constrained; admins & other users pass untouched.
		if ( ! Permissions::is_staff_user() ) {
			return $authorized;
		}

		$handler = $context['handler'] ?? null;
		$action  = (string) ( $context['action'] ?? '' );
		if ( ! is_object( $handler ) ) {
			return $authorized;
		}

		$requirement = self::required_slug( get_class( $handler ), $action );

		if ( self::ALLOW === $requirement ) {
			return $authorized;
		}

		if ( self::DENY !== $requirement && current_user_can( $requirement ) ) {
			return $authorized;
		}

		// A specific slug yields a resource-aware message ("…to update courses.");
		// an admin-only (DENY) surface has no slug, so the generic line is used.
		$slug = self::DENY === $requirement ? null : $requirement;

		return new WP_Error(
			'academy_staff_forbidden',
			Permissions::denied_message( $slug ),
			array(
				'status' => rest_authorization_required_code(),
				'title'  => __( 'Insufficient permission!', 'academy-pro' ),
			)
		);
	}

	/**
	 * Resolve the staff permission a (handler, action) pair requires.
	 *
	 * @param string $class
	 * @param string $action
	 *
	 * @return string One of self::ALLOW, self::DENY, or a permission slug.
	 */
	public static function required_slug( string $class, string $action ): string {
		$policy = self::policy();

		// Unknown handler → deny (admin-only or unclassified surface).
		if ( ! isset( $policy[ $class ] ) ) {
			return self::DENY;
		}

		$rules = $policy[ $class ];

		if ( isset( $rules[ $action ] ) ) {
			return $rules[ $action ];
		}

		return $rules['_default'] ?? self::DENY;
	}

	/**
	 * Handler class => [ '_default' => requirement, '<action>' => requirement ].
	 *
	 * Each requirement is a staff slug (allow iff held), self::ALLOW, or self::DENY.
	 *
	 * @return array<string,array<string,string>>
	 */
	private static function policy(): array {
		$p = Permissions::PREFIX; // 'academy'

		$courses       = "$p.courses";
		$courses_w     = "$p.courses.update";
		$lessons       = "$p.lessons";
		$lessons_w     = "$p.lessons.update";
		$instructors   = "$p.instructors";
		$instructors_w = "$p.instructors.update";
		$students      = "$p.students";
		$students_w    = "$p.students.update";
		$settings      = "$p.settings";
		$group_plus    = "$p.group_plus";
		$group_plus_u  = "$p.group_plus.update";
		$attendance    = "$p.attendance";
		$course_bundle_u = "$p.course_bundle.update";

		$policy = array(

			// ─── Courses ───────────────────────────────────────────────────────
			'Academy\\Ajax\\Course' => array(
				'_default'              => self::ALLOW, // student-facing: enrollment, wishlist, favorites, reviews, get_course_details
				'preview_curriculum_item' => $courses,
				'get_course_slug'       => $courses,
				'fetch_course_category' => $courses,
				'get_my_courses'        => $courses,
				'import_course'         => "$p.courses.create",
				'validate_youtube_api'  => self::DENY, // admin-only integration key
				'import_from_playlist'  => "$p.courses.create",
				// Featured-course ordering is a write; the `_default` ALLOW above let
				// any staff member (even Students-only) reach it.
				'get_sticky_courses_priorities' => $courses,
				'reorder_sticky_courses'        => $courses_w,
			),

			// ─── Lessons ───────────────────────────────────────────────────────
			'Academy\\Ajax\\Lesson' => array(
				'_default'                => self::ALLOW, // student-facing: render_lesson, notes, video-complete
				'import_lessons'          => "$p.lessons.create",
				'lesson_slug_unique_check' => $lessons,
			),

			// ─── Instructors ───────────────────────────────────────────────────
			'Academy\\Ajax\\Instructor' => array(
				'_default'                         => $instructors, // list/select reads default to manage_options base
				'update_instructor_status'         => $instructors_w,
			),

			// ─── Students ──────────────────────────────────────────────────────
			'Academy\\Ajax\\Student' => array(
				'_default'               => self::ALLOW, // get_enrolled_students is visitor-allowed
				'get_all_students'       => $students,
				'remove_student'         => "$p.students.delete",
				'frontend/get_students'  => $students,
				'update_enrollment_status' => $students_w,
			),

			// ─── Misc (admin menu, analytics, reviews, lesson comments) ────────
			'Academy\\Ajax\\Miscellaneous' => array(
				// get_admin_menu_items must stay reachable — Menu (this addon)
				// filters its *content*, not whether staff may fetch it at all.
				'get_admin_menu_items'   => self::ALLOW,
				'get_analytics'          => self::DENY, // Dashboard/Analytics stay admin-only
				// SECURITY: DENY, not $courses_w. Miscellaneous::change_post_status()
				// (free plugin) takes an arbitrary post_id + status with NO post_type
				// check, and permits the write on `manage_options || own post_author`.
				// Caps elevates manage_options for ANY staff user for the whole
				// request, which — combined with the missing post_type check — would
				// let a staffer holding only academy.courses.update change the status
				// of any post/page/CPT item on the site, not just their own courses.
				// A single capability slug can't safely scope this action (it's used
				// for courses AND lessons per the comment this replaced, and neither
				// slug maps to "only posts of type X, only if owned"), so it's denied
				// for staff entirely until the free-plugin handler validates post_type
				// and true ownership itself. Found via security-review self-audit.
				'change_post_status'     => self::DENY,
				'fetch_posts'            => $courses,
				'mark_topic_complete'    => self::ALLOW,
				'saved_user_info'        => self::ALLOW,
				'reset_password'         => self::ALLOW,
				'get_user_given_reviews' => self::ALLOW,
				'get_user_received_reviews' => self::ALLOW,
				'get_user_purchase_history' => self::ALLOW,
				'insert_lesson_comment'  => self::ALLOW,
				'get_lesson_comment'     => self::ALLOW,
				'delete_lesson_comment'  => $lessons_w,
				'hide_zencommunity_ads'  => self::DENY,
				'fetch_roles'            => self::DENY, // WP role list — admin-only
				'fetch_courses'          => $courses,
				'update_review'          => self::ALLOW,
			),

			// ─── Settings ──────────────────────────────────────────────────────
			'Academy\\Ajax\\Settings' => array(
				'_default' => $settings,
			),

			// ─── Registration (best-effort — see class doc-comment) ────────────
			'Academy\\Ajax\\Registration' => array(
				'register_student'             => "$p.students.create",
				'register_instructor'          => "$p.instructors.create",
				'save_instructor_form_settings' => $settings,
				'save_student_form_settings'   => $settings,
			),

			// ─── Bulk Import/Export (pro addon) ─────────────────────────────────
			// Same deny-by-default AbstractAjaxHandler gap as Assignments: without
			// an entry here every bulk-import action is denied for staff outright.
			// The callbacks themselves allow administrators and guarded staff
			// only (ExportImport::authorize_bulk_action()), since plain
			// instructors pass this guard untouched.
			'AcademyPro\\Ajax\\ExportImport' => array(
				'_default'               => self::DENY,
				'bulk_import_instructor' => "$p.instructors.create",
				'bulk_import_student'    => "$p.students.create",
				'bulk_enroll_student'    => "$p.students.create",
				'import_quizzes'         => "$p.quizzes.create",
			),

			// ─── Admin-only surfaces: explicitly denied for staff ──────────────
			'Academy\\Ajax\\Tools'             => array( '_default' => self::DENY ),
			'Academy\\Ajax\\PluginDownloader'  => array( '_default' => self::DENY ),

			// ─── Assignments (pro addon) ────────────────────────────────────────
			// Unlike Booking/Meeting (which check current_user_can() directly and
			// never dispatch this filter), Assignments extends AbstractAjaxHandler
			// so it hits this deny-by-default guard like any free-plugin handler.
			// Without an entry here, a staffer holding academy.assignments could
			// never load the Assignments screen even after Caps::elevate() grants
			// manage_academy_instructor — found via a live report.
			'AcademyProAssignments\\Ajax'      => array(
				'_default'                     => "$p.assignments",
				'frontend/render_assignment'   => self::ALLOW, // student-facing
				'frontend/start_assignment'    => self::ALLOW, // student-facing
				'frontend/submit_assignment'   => self::ALLOW, // student-facing
				'evaluate_submitted_assignment' => "$p.assignments.update",
				'delete_submitted_assignment'  => "$p.assignments.delete",
			),

			// ─── Quizzes (free addon) ───────────────────────────────────────────
			// The Learn page's render_quiz / insert_quiz_answer(s) / resume calls
			// are student-facing and check enrollment themselves, exactly like
			// the Lesson handler above. Unlisted, this guard denied them for any
			// staff user, so a staffer opening a quiz saw "Content Not Found!".
			'AcademyQuizzes\\Ajax\\Frontend' => array(
				'_default' => self::ALLOW,
			),
			// Attempt review and instructor feedback.
			'AcademyQuizzes\\Ajax\\Admin' => array(
				'_default'                                => "$p.quizzes",
				'update_quiz_attempt_instructor_feedback' => "$p.quizzes.update",
				'quiz_answer_manual_review'               => "$p.quizzes.update",
			),

			// ─── Tutor Booking (pro addon) — WooCommerce price sync ────────────
			// Same AbstractAjaxHandler gap as Assignments above: setting/updating
			// a paid booking's price (used from the booking admin editor when
			// WooCommerce billing is enabled) is gated on manage_academy_instructor
			// in the handler itself but denied by this guard's default without an
			// explicit entry.
			'AcademyProTutorBooking\\Admin\\Woocommerce' => array(
				'_default'                          => "$p.tutor_booking.update",
			),

			// ─── Group Plus (pro addon) — Admin dashboard handlers ─────────────
			// None of these three declare a per-action `capability` (defaults to
			// manage_options, which Caps::elevate() already grants broadly in
			// academy_pro context), and this guard previously had no entry at
			// all for any of them — deny-by-default blocked every staff member
			// outright regardless of what Manage Roles granted them. The base
			// native caps these need (academy_team_member / manage_academy_group
			// / manage_academy_team) are bridged via Permissions::
			// native_cap_bundles()'s 'group_plus' entry.
			'AcademyProGroupPlus\\Dashboard\\Ajax\\Admin\\GroupHandler' => array(
				'_default'                   => $group_plus_u,
				'get_group'                  => $group_plus,
				'get_groups'                 => $group_plus,
				'get_organizers_from_group'  => $group_plus,
				'get_courses_from_group'     => $group_plus,
			),
			'AcademyProGroupPlus\\Dashboard\\Ajax\\Admin\\TeamHandler' => array(
				'_default'                 => $group_plus_u,
				'get_team'                 => $group_plus,
				'get_teams'                => $group_plus,
				'get_members_from_team'    => $group_plus,
				'get_organizers_from_team' => $group_plus,
				'get_courses_from_team'    => $group_plus,
			),
			'AcademyProGroupPlus\\Dashboard\\Ajax\\Admin\\OrganizerHandler' => array(
				'_default' => $group_plus,
			),

			// ─── Group Plus (pro addon) — Frontend organizer-facing handlers ────
			// Base capability is already declared per-action here
			// (academy_team_member / manage_academy_group / manage_academy_team);
			// this guard is the secondary per-resource layer, same as every
			// other mapped class.
			'AcademyProGroupPlus\\Dashboard\\Ajax\\Frontend\\GroupHandler' => array(
				'_default'   => $group_plus_u,
				'get_group'  => $group_plus,
				'get_groups' => $group_plus,
			),
			'AcademyProGroupPlus\\Dashboard\\Ajax\\Frontend\\TeamHandler' => array(
				'_default'              => $group_plus_u,
				'get_team'              => $group_plus,
				'get_teams'             => $group_plus,
				'get_members_from_team' => $group_plus,
			),
			'AcademyProGroupPlus\\Dashboard\\Ajax\\Frontend\\EcommerceInegration' => array(
				'_default'    => $group_plus,
				'add_to_cart' => self::ALLOW, // allow_visitor_action — nothing to gate
				'get_price'   => self::ALLOW, // allow_visitor_action — nothing to gate
			),

			// ─── Attendance (pro addon) ──────────────────────────────────────────
			// Declared capability is manage_options per action (elevated for
			// staff by Caps::elevate()); this guard simply had no entry, denying
			// every staff member outright. attendance is a single_feature (no
			// create/update/delete verbs), so one slug covers everything.
			'AcademyProAttendance\\Admin\\Ajax' => array(
				'_default' => $attendance,
			),

			// ─── Course Active Timer (pro addon) ─────────────────────────────────
			'AcademyProCourseActiveTimer\\Ajax\\Admin' => array(
				'_default' => "$p.course_active_timer",
			),
			'AcademyProCourseActiveTimer\\Ajax\\Frontend' => array(
				'_default' => self::ALLOW, // capability: 'read' — student self-service
			),

			// ─── Course Bundle (pro addon) — WooCommerce price sync ──────────────
			// Same shape as Tutor Booking's Woocommerce handler above.
			'AcademyProCourseBundle\\Ajax\\Woocommerce' => array(
				'_default' => $course_bundle_u,
			),
		);

		return apply_filters( 'academy/staff/ajax_policy', $policy );
	}
}
