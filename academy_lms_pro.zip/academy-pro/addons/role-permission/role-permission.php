<?php
/**
 * Role & Permission addon.
 *
 * StoreEngine-Role-Permission-style per-user staff permissions for the Academy
 * admin, built on native WP capabilities (no roles table, no schema). When
 * active it:
 *   - exposes a REST controller to grant/revoke per-user permissions,
 *   - elevates staff to scoped `manage_options` inside Academy requests so
 *     every permitted screen actually works ({@see Caps}),
 *   - gates writes per-resource ({@see RestGuard}) and ajax actions
 *     ({@see AjaxGuard}), unscopes list queries for permitted staff
 *     ({@see ListScope}), and menus per-screen ({@see Menu}),
 *   - bootstraps the admin Settings "Manage Roles" tab.
 *
 * Ported from `storeengine-pro/addons/role-permission/`; see that addon and
 * `academy/openspec/changes/role-permission/` (the two small free-plugin
 * extension points this depends on) and
 * `academy-pro/openspec/changes/role-permission/` (design rationale) for the
 * full context behind the choices made here.
 *
 * @package AcademyProRolePermission
 */

namespace AcademyProRolePermission;

use Academy\Interfaces\AddonInterface;
use AcademyProRolePermission\Api\StaffPermissionController;
use WP_User;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class RolePermission implements AddonInterface {

	private $addon_name = 'role-permission';

	private function __construct() {
		$this->define_constants();
		$this->init_addon();
	}

	public static function init() {
		static $instance = false;

		if ( ! $instance ) {
			$instance = new self();
		}

		return $instance;
	}

	public function define_constants() {
		define( 'ACADEMY_PRO_ROLE_PERMISSION_VERSION', '1.0.0' );
		define( 'ACADEMY_PRO_ROLE_PERMISSION_DIR_PATH', ACADEMY_PRO_ADDONS_DIR_PATH . 'role-permission/' );
	}

	public function init_addon() {
		add_action( "academy/addons/activated_{$this->addon_name}", array( $this, 'addon_activation_hook' ) );
		add_action( "academy/addons/deactivated_{$this->addon_name}", array( $this, 'addon_deactivation_hook' ) );

		if ( ! \Academy\Helper::get_addon_active_status( $this->addon_name ) ) {
			return;
		}

		add_action(
			'rest_api_init',
			static function () {
				( new StaffPermissionController() )->register_routes();
			}
		);

		( new Caps() )->register();
		( new RestGuard() )->register();
		( new AjaxGuard() )->register();
		( new ListScope() )->register();

		if ( is_admin() ) {
			( new Menu() )->register();
		}

		add_action( 'set_user_role', array( $this, 'sync_role_dropdown_to_staff' ), 10, 3 );

		// Exposes the current user's granted permission slugs to the SPA so
		// list/action-menu buttons can disable themselves (and explain why)
		// instead of rendering a control that only fails once clicked.
		add_filter( 'academy/assets/backend_scripts_data', array( $this, 'localize_staff_permissions' ) );
		add_filter( 'academy/assets/frontend_scripts_data', array( $this, 'localize_staff_permissions' ) );
	}

	/**
	 * `staff_permissions` is `null` for a real admin or an ordinary (non-staff)
	 * user — meaning "unrestricted", so the frontend's `can()` helper always
	 * returns true for them. For a managed staff user it's the exact array
	 * {@see Permissions::all_slugs()} currently grants, mirroring the same
	 * source of truth {@see RestGuard} / {@see AjaxGuard} enforce against —
	 * so a button is disabled if and only if the matching request would
	 * actually be rejected server-side.
	 *
	 * @param array $data
	 * @return array
	 */
	public function localize_staff_permissions( array $data ): array {
		$user = wp_get_current_user();

		$data['staff_permissions'] = Permissions::is_staff_user( $user )
			? array_values( array_filter( Permissions::all_slugs(), array( $user, 'has_cap' ) ) )
			: null;

		return $data;
	}

	/**
	 * The other half of {@see StaffPermissionController::sync_manager_role()}:
	 * a site owner can also assign "Academy Manager" straight from wp-admin's
	 * native Users screen (it's just another role in that dropdown) instead of
	 * going through Manage Roles. Without this, that account gets the role
	 * label but none of the dotted-slug permissions or `META_IS_SET` flag that
	 * actually drive access — Caps::elevate() never fires for it, so every
	 * screen looks empty (confirmed live: the Lessons list renders "No Data
	 * Available" because the frontend still scopes the request to
	 * `&author={their id}`, and the account never authored any). Mirrors that
	 * method's other direction: grant
	 * every permission slug (there's no way to know which ones were intended
	 * from a bare role assignment, so default to full access rather than a
	 * silently non-functional account) when assigned directly; revoke
	 * everything when switched away via the same dropdown.
	 *
	 * Only reacts to `set_role()` (wp-admin's single-role dropdown), not
	 * `add_role()`/`remove_role()` — those fire `add_user_role`/
	 * `remove_user_role` instead, which is what `sync_manager_role()` itself
	 * uses, so the two directions can't recursively re-trigger each other.
	 *
	 * @param int    $user_id   The user whose role changed.
	 * @param string $role      The new role.
	 * @param array  $old_roles The user's previous role(s).
	 */
	public function sync_role_dropdown_to_staff( int $user_id, string $role, array $old_roles ): void {
		$user = get_user_by( 'id', $user_id );
		if ( ! $user ) {
			return;
		}

		$became_manager = 'academy_manager' === $role;
		$was_manager    = in_array( 'academy_manager', $old_roles, true );

		if ( $became_manager === $was_manager ) {
			return;
		}

		if ( $became_manager ) {
			// Already staff (e.g. re-picked the same role, or granted via
			// Manage Roles moments ago) — nothing to do, avoid clobbering
			// whatever specific permissions were already chosen there.
			if ( Permissions::is_staff_user( $user ) ) {
				return;
			}

			foreach ( Permissions::all_slugs() as $slug ) {
				$user->add_cap( $slug );
			}
			update_user_meta( $user_id, Permissions::META_IS_SET, 1 );
		} else {
			foreach ( Permissions::all_slugs() as $slug ) {
				$user->remove_cap( $slug );
			}
			foreach ( Permissions::managed_native_caps() as $cap ) {
				$user->remove_cap( $cap );
			}
			foreach ( Permissions::generic_authoring_caps() as $cap ) {
				$user->remove_cap( $cap );
			}
			delete_user_meta( $user_id, Permissions::META_IS_SET );
			delete_user_meta( $user_id, Permissions::META_AUTO_CAPS );
		}//end if

		Permissions::reconcile_native_caps( $user );
		do_action( 'academy/staff/permissions_changed', $user );
	}

	/**
	 * On activation, re-mirror native post-type caps for every existing staff
	 * user (covers the addon being toggled off and back on).
	 */
	public function addon_activation_hook() {
		foreach ( $this->get_staff_users() as $user ) {
			Permissions::reconcile_native_caps( $user );
		}
	}

	/**
	 * On deactivation, strip the native post-type + generic authoring caps from
	 * staff users so they can't keep editing courses/etc. while enforcement is
	 * off. The dotted permission slugs are left intact, so re-activating fully
	 * restores each user's access — see design.md Decision 7.
	 */
	public function addon_deactivation_hook() {
		foreach ( $this->get_staff_users() as $user ) {
			foreach ( Permissions::managed_native_caps() as $cap ) {
				$user->remove_cap( $cap );
			}
			foreach ( Permissions::generic_authoring_caps() as $cap ) {
				$user->remove_cap( $cap );
			}
		}
	}

	/**
	 * @return WP_User[]
	 */
	private function get_staff_users(): array {
		return get_users(
			array(
				'meta_key'   => Permissions::META_IS_SET, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
				'meta_value' => '1', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
			)
		);
	}
}
