<?php
/**
 * Staff permission taxonomy, gatekeeper and native-cap bridge.
 *
 * Per-user permissions stored as native WP capabilities (dotted slugs like
 * `academy.courses.create`). No roles table, no schema.
 *
 * Ported from `storeengine-pro/addons/role-permission/permissions.php`.
 *
 * @package AcademyProRolePermission
 */

namespace AcademyProRolePermission;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use WP_User;

class Permissions {

	const PREFIX = 'academy';

	/** Meta flag: user holds at least one staff permission. */
	const META_IS_SET = 'academy_staff_is_set';

	/** Meta array: base caps auto-granted as a side effect of a sub-permission. */
	const META_AUTO_CAPS = 'academy_staff_auto_caps';

	/**
	 * Resources with verb-level sub-permissions (base + create/update/delete).
	 * `_addon` (when set) gates a resource on that addon being active.
	 *
	 * @var array<string,array{addon?:string}>
	 */
	private static array $crud_resources = array(
		'courses'       => array(),
		'lessons'       => array(),
		'instructors'   => array(),
		'students'      => array(),
		'announcements' => array(),
		'quizzes'       => array( 'addon' => 'quizzes' ),
		'certificates'  => array( 'addon' => 'certificates' ),
		'tutor_booking' => array( 'addon' => 'tutor-booking' ),
		'assignments'   => array( 'addon' => 'assignments' ),
		'course_bundle' => array( 'addon' => 'course-bundle' ),
		'group_plus'    => array( 'addon' => 'group-plus' ),
	);

	/**
	 * Single-slug features (no verb sub-permissions). Value = gating addon slug,
	 * or null when always available. Dashboard / Add-ons / Tools / Get-Pro /
	 * What's-New / Withdraw are intentionally absent — those screens stay
	 * admin-only, mirroring StoreEngine's Dashboard/Analytics/Licenses exclusion.
	 *
	 * @var array<string,?string>
	 */
	private static array $single_features = array(
		'settings'          => null,
		'question_answer'   => null,
		'webhooks'          => null,
		'meeting'           => 'meeting',
		'google_classroom'  => 'google-classroom',
		'attendance'        => 'attendance',
		'grade_book'        => 'grade-book',
		'course_active_timer' => 'course-active-timer',
	);

	/**
	 * Every valid staff permission slug (base + sub-permissions), filtered to
	 * only those whose gating addon (if any) is currently active.
	 *
	 * @return string[]
	 */
	public static function all_slugs(): array {
		$slugs = array();

		foreach ( self::$crud_resources as $resource => $meta ) {
			if ( ! self::is_group_available( $meta ) ) {
				continue;
			}
			$base    = self::PREFIX . '.' . $resource;
			$slugs[] = $base;
			$slugs[] = $base . '.create';
			$slugs[] = $base . '.update';
			$slugs[] = $base . '.delete';
		}

		foreach ( self::$single_features as $feature => $addon ) {
			if ( $addon && ! \Academy\Helper::get_addon_active_status( $addon ) ) {
				continue;
			}
			$slugs[] = self::PREFIX . '.' . $feature;
		}

		return apply_filters( 'academy/staff/all_slugs', $slugs );
	}

	private static function is_group_available( array $meta ): bool {
		return empty( $meta['addon'] ) || \Academy\Helper::get_addon_active_status( $meta['addon'] );
	}

	/** Guards the staff-management endpoints — admins only. */
	public static function admin_can(): bool {
		return current_user_can( 'manage_options' );
	}

	/**
	 * A clear, user-facing "permission denied" message for a staff user, tailored
	 * to the permission they are missing when it is known (e.g.
	 * `academy.courses.update` -> "You don't have permission to update courses.").
	 * Falls back to a generic — but still actionable — line for admin-only
	 * surfaces where no specific slug applies.
	 *
	 * @param string|null $slug The staff slug the action required.
	 */
	public static function denied_message( ?string $slug = null ): string {
		$generic = __( "You don't have permission to perform this action. Please contact your site administrator if you need access.", 'academy-pro' );

		$parts    = $slug ? explode( '.', $slug ) : array();
		$resource = $parts[1] ?? '';
		$verb     = $parts[2] ?? '';

		if ( ! $resource ) {
			return $generic;
		}

		$verbs  = array(
			'create' => __( 'create', 'academy-pro' ),
			'update' => __( 'update', 'academy-pro' ),
			'delete' => __( 'delete', 'academy-pro' ),
		);
		$action = $verbs[ $verb ] ?? __( 'manage', 'academy-pro' );

		// Human resource label: "question_answer" -> "question answer".
		$resource_label = str_replace( '_', ' ', $resource );

		return sprintf(
			/* translators: 1: action verb (create/update/delete/manage). 2: resource name (courses, lessons, settings, …). */
			__( "You don't have permission to %1\$s %2\$s. Please contact your site administrator to request access.", 'academy-pro' ),
			$action,
			$resource_label
		);
	}

	/**
	 * Whether a resource supports verb-level sub-permissions.
	 *
	 * @param string $resource
	 */
	public static function is_crud_resource( string $resource ): bool {
		return isset( self::$crud_resources[ $resource ] );
	}

	/**
	 * Real (role-derived) admin check that ignores the dynamic `user_has_cap`
	 * elevation in {@see Caps} — reads `$user->allcaps`, which only reflects
	 * stored role/user caps. Without this, an elevated staff request would look
	 * like an admin and skip enforcement.
	 *
	 * @param WP_User|null $user
	 */
	public static function is_real_admin( ?WP_User $user = null ): bool {
		$user = $user ? $user : wp_get_current_user();

		return ! empty( $user->allcaps['manage_options'] );
	}

	/**
	 * Whether the user is a managed staff member (non-admin holding ≥1 staff
	 * permission). Administrators are never staff.
	 *
	 * @param WP_User|null $user
	 */
	public static function is_staff_user( ?WP_User $user = null ): bool {
		$user = $user ? $user : wp_get_current_user();
		if ( ! $user || ! $user->ID || self::is_real_admin( $user ) ) {
			return false;
		}

		return (bool) get_user_meta( $user->ID, self::META_IS_SET, true );
	}

	/**
	 * Maps each academy/v1 route segment => resource. Drives write-gating in the REST
	 * guard. Courses/lessons/quizzes/announcements/certificates are CPTs served
	 * by WP post-type REST — their native caps ({@see native_caps_for}) grant
	 * LIST + READ so a "view" user can see the list, but WP's `edit_posts` cap
	 * (required just to load the edit-context list) also implies creating
	 * drafts, so native caps alone can't separate view from create/update/
	 * delete. The REST guard closes that gap by gating the actual writes
	 * (POST/PUT/DELETE) on these routes by verb.
	 *
	 * @return array<string,string>
	 */
	public static function write_route_map(): array {
		$map = array(
			'academy_courses'      => 'courses',
			// `academy_lessons` is the legacy/HP-render lesson REST base
			// (`is_disabled_academy_hp_lessons` on); the default, modern
			// lesson builder instead calls the free plugin's own
			// `Academy\API\Lessons` controller at `/academy/v1/lessons`.
			// That controller's own `permissions_check()` only requires
			// `manage_academy_instructor` — which `Caps::elevate()` grants
			// to every staff member regardless of which dotted slug they
			// actually hold — so without a `lessons` entry here too, this
			// guard silently treated the modern endpoint as ungated:
			// a staffer holding ONLY `academy.lessons.create` (or any other
			// single Academy permission) could update or delete any lesson
			// with no error. Found via a live report.
			'academy_lessons'      => 'lessons',
			'lessons'              => 'lessons',
			'academy_quiz'         => 'quizzes',
			'academy_announcement' => 'announcements',
			'academy_certificate'  => 'certificates',
			// The certificate builder saves designs through its own routes, not the
			// post type's REST base, so they need the same write gate.
			'certificate-builder'  => 'certificates',
			'instructors'          => 'instructors',
			'students'             => 'students',
			'settings'             => 'settings',
			'question-answer'      => 'question_answer',
			// The actual REST base is `academy_webhook` (singular, underscore) —
			// see AcademyWebhooks\Authorization\WebHookController's
			// parent::__construct('academy_webhook') — not 'webhooks'. With the
			// wrong key here, RestGuard::required_write_slug() never matched this
			// route at all, so once WebHookController's own base check is fixed
			// to admit elevated staff, writes would fall through completely
			// unguarded instead of requiring `academy.webhooks`. Found via a live
			// report investigating why staff couldn't create webhooks.
			'academy_webhook'      => 'webhooks',
			// Same class of gap as academy_webhook above — these are the actual
			// rest_base values (AcademyProTutorBooking\Database, AcademyProMeeting\
			// Database, AcademyProCourseBundle\Database), not the resource names
			// used elsewhere in this map. Found during a broader audit after the
			// webhooks route-key mismatch.
			'academy_booking'      => 'tutor_booking',
			'academy_meeting'      => 'meeting',
			'alms_course_bundle'   => 'course_bundle',
			'academy_assignments'  => 'assignments',
		);

		return apply_filters( 'academy/staff/write_route_map', $map );
	}

	/**
	 * Admin menu keys (the `?page=` slugs, from Helper::get_admin_menu_list())
	 * => staff slug. Keys absent here are hidden from staff (Dashboard,
	 * Add-ons, Tools, Get-Pro, What's New, Withdraw, …).
	 *
	 * @return array<string,string>
	 */
	public static function menu_permission_map(): array {
		$map = array(
			'academy-courses'          => self::PREFIX . '.courses',
			'academy-lessons'          => self::PREFIX . '.lessons',
			'academy-instructors'      => self::PREFIX . '.instructors',
			'academy-students'         => self::PREFIX . '.students',
			'academy-announcements'    => self::PREFIX . '.announcements',
			'academy-quizzes'          => self::PREFIX . '.quizzes',
			'academy-certificates'     => self::PREFIX . '.certificates',
			'academy-tutor-booking'    => self::PREFIX . '.tutor_booking',
			'academy-assignments'      => self::PREFIX . '.assignments',
			'academy-course-bundle'    => self::PREFIX . '.course_bundle',
			'academy-group-plus'       => self::PREFIX . '.group_plus',
			'academy-settings'         => self::PREFIX . '.settings',
			'academy-question_answer'  => self::PREFIX . '.question_answer',
			'academy-webhooks'         => self::PREFIX . '.webhooks',
			'academy-meeting'          => self::PREFIX . '.meeting',
			'academy-google-classroom' => self::PREFIX . '.google_classroom',
			'academy-attendance'       => self::PREFIX . '.attendance',
			'academy-grade-book'       => self::PREFIX . '.grade_book',
			'academy-course-timer'     => self::PREFIX . '.course_active_timer',
		);

		return apply_filters( 'academy/staff/menu_permission_map', $map );
	}

	// ── native post-type cap bridge (courses / lessons / quizzes / announcements / certificates) ─────────

	/**
	 * Academy-specific native caps a dotted slug mirrors. Empty for slugs
	 * enforced purely through academy/v1 (instructors/students/settings/etc.)
	 * or through pro-addon-specific mechanisms not yet bridged (see
	 * openspec design.md's flagged risk on pro-addon-gated resources).
	 *
	 * @param string $slug
	 *
	 * @return string[]
	 */
	public static function native_caps_for( string $slug ): array {
		$parts    = explode( '.', $slug );
		$resource = $parts[1] ?? '';
		$verb     = $parts[2] ?? '';

		$bundles = self::native_cap_bundles();
		if ( ! isset( $bundles[ $resource ] ) ) {
			return array();
		}

		// SECURITY: verb must map to its OWN bundle, not fall back to 'edit'.
		// Previously every non-delete verb (including the bare base/"view"
		// slug) resolved to the same 'edit' bundle — granting real
		// edit_others_academy_X / publish_academy_X native caps just for
		// holding the base "View" permission. Since the base slug is
		// auto-granted and toggle-locked whenever any sub-permission is held
		// (see StaffPermissionController::sync_auto_granted_base()), revoking
		// only "Update" never actually removed those native caps: the still-
		// held base slug kept re-granting the full edit bundle on every
		// reconcile. Found via a live report — a staffer with Update revoked
		// could still edit (and edit others') courses because
		// edit_others_academy_courses/publish_academy_courses never left
		// their wp_capabilities.
		$bundle    = $bundles[ $resource ];
		$verb_keys = array(
			''       => 'view',
			'create' => 'create',
			'update' => 'edit',
			'delete' => 'delete',
		);
		$key  = $verb_keys[ $verb ] ?? 'view';
		$caps = $bundle[ $key ] ?? array();

		return apply_filters( 'academy/staff/native_caps', $caps, $slug );
	}

	/**
	 * Reconcile a user's native post-type caps to match the dotted slugs they
	 * currently hold (add/remove to converge — avoids shared-cap clobbering).
	 *
	 * @param WP_User $user
	 */
	public static function reconcile_native_caps( WP_User $user ): void {
		$desired = array();
		foreach ( self::all_slugs() as $slug ) {
			if ( $user->has_cap( $slug ) ) {
				$desired = array_merge( $desired, self::native_caps_for( $slug ) );
			}
		}
		$desired = array_unique( $desired );

		foreach ( self::managed_native_caps() as $cap ) {
			if ( in_array( $cap, $desired, true ) ) {
				$user->add_cap( $cap );
			} else {
				$user->remove_cap( $cap );
			}
		}

		// SECURITY: strip these symmetrically with managed_native_caps() above,
		// not just add them. Previously this only ever added — a user revoked
		// down to zero slugs (e.g. via the per-permission toggle, not "Remove
		// all") kept edit_posts/edit_others_posts/upload_files/read
		// indefinitely, since is_staff_user() going false stops every OTHER
		// enforcement layer in this addon from applying to them, but never
		// touched these already-granted native WP capabilities. Found via
		// security-review self-audit.
		foreach ( self::generic_authoring_caps() as $cap ) {
			if ( ! empty( $desired ) ) {
				if ( ! $user->has_cap( $cap ) ) {
					$user->add_cap( $cap );
				}
			} else {
				$user->remove_cap( $cap );
			}
		}
	}

	/**
	 * Every Academy-specific native cap this addon manages (reconcile universe).
	 *
	 * @return string[]
	 */
	public static function managed_native_caps(): array {
		$caps = array();
		foreach ( self::native_cap_bundles() as $bundle ) {
			foreach ( $bundle as $verb_caps ) {
				$caps = array_merge( $caps, $verb_caps );
			}
		}

		return array_values( array_unique( $caps ) );
	}

	/**
	 * Generic WP authoring caps the post-type editor needs; added additively,
	 * never auto-stripped (cleared only on remove-all / deactivation).
	 *
	 * @return string[]
	 */
	public static function generic_authoring_caps(): array {
		return array( 'edit_posts', 'edit_others_posts', 'upload_files', 'read' );
	}

	/**
	 * Per-resource native caps, one sub-bundle per verb:
	 *   - view:   granted by the bare base slug (e.g. `academy.courses`) — read-only.
	 *   - create: granted by the `.create` slug — make + publish new items.
	 *   - edit:   granted by the `.update` slug — edit own AND others' items.
	 *   - delete: granted by the `.delete` slug.
	 *
	 * Kept as separate bundles (rather than one shared 'edit' bundle for
	 * view/create/update) so revoking Update actually strips
	 * edit_others_academy_X / publish_academy_X — previously all three verbs
	 * shared one bundle, so the base "View" slug (auto-granted and
	 * toggle-locked whenever any sub-permission is held) kept re-granting the
	 * full edit bundle even after Update was revoked.
	 *
	 * `view` deliberately also includes the resource's plural `edit_academy_X`
	 * (WP's `edit_posts`/`create_posts` primitive for this CPT) — NOT because
	 * View should let anyone write anything, but because
	 * WP_REST_Posts_Controller::sanitize_post_statuses() requires that exact
	 * primitive just to request any status other than the schema default
	 * ('publish') at all, e.g. `status=any`/`draft` — with `map_meta_cap:
	 * false` on these CPTs it has nothing to do with per-post ownership. Real
	 * write authorization stays entirely with the dotted-slug checks in
	 * {@see RestGuard}/{@see AjaxGuard} (which don't consult native caps), so
	 * a View-only user gaining this primitive still can't create, update, or
	 * delete anything — found via a live report: a staffer granted only
	 * "Courses: View" got a hard `rest_forbidden_status` 400 on the default
	 * "All" tab (status=any) and an empty table on every other tab, because
	 * they had no way to hold this primitive without also holding Create.
	 *
	 * @return array<string,array{view:string[],create:string[],edit:string[],delete:string[]}>
	 */
	private static function native_cap_bundles(): array {
		// NOTE on the singular `edit_academy_X` cap appearing in every `view`
		// bucket below (in addition to `edit`): every Academy CPT registers
		// with `map_meta_cap` left at its default `false`, so WP core's
		// map_meta_cap() never runs its normal author-vs-others / publish-status
		// logic for `current_user_can( 'edit_post'|'delete_post', $id )` — it
		// takes the early `! $post_type->map_meta_cap` branch and requires the
		// singular cap LITERALLY, with no ownership check at all. The
		// dashboard's list requests always send `context=edit`, which makes
		// WP_REST_Posts_Controller::get_items() call check_update_permission()
		// (→ `edit_post`) for every row — so a staffer holding only the base
		// "View" slug, who never gets the singular cap from the `edit` bucket
		// (that only comes from the `.update` slug), saw a permanently EMPTY
		// list on every screen. Real write authorization is unaffected: it
		// stays entirely with the dotted-slug checks in RestGuard/AjaxGuard,
		// which don't consult native caps at all. Found via a live report
		// after fixing the identical webhooks-specific case: any resource's
		// View-only grant produced an empty table, not just Webhooks.
		$bundles = array(
			'courses'       => array(
				'view'   => array(
					'read_academy_course',
					'edit_academy_course',
					'read_private_academy_courses',
					'edit_academy_courses',
				),
				'create' => array(
					'edit_academy_courses',
					'publish_academy_courses',
				),
				'edit'   => array(
					'edit_academy_course',
					'edit_academy_courses',
					'edit_others_academy_courses',
					'publish_academy_courses',
				),
				'delete' => array(
					'delete_academy_course',
					'delete_academy_courses',
				),
			),
			'lessons'       => array(
				'view'   => array(
					'read_academy_lesson',
					'edit_academy_lesson',
					'read_private_academy_lessons',
					'edit_academy_lessons',
				),
				'create' => array(
					'edit_academy_lessons',
					'publish_academy_lessons',
				),
				'edit'   => array(
					'edit_academy_lesson',
					'edit_academy_lessons',
					'edit_others_academy_lessons',
					'publish_academy_lessons',
				),
				'delete' => array(
					'delete_academy_lesson',
					'delete_academy_lessons',
				),
			),
			'quizzes'       => array(
				'view'   => array(
					'read_academy_quiz',
					'edit_academy_quiz',
					'read_private_academy_quizzes',
					'edit_academy_quizzes',
				),
				'create' => array(
					'edit_academy_quizzes',
					'publish_academy_quizzes',
				),
				'edit'   => array(
					'edit_academy_quiz',
					'edit_academy_quizzes',
					'edit_others_academy_quizzes',
					'publish_academy_quizzes',
				),
				'delete' => array(
					'delete_academy_quiz',
					'delete_academy_quizzes',
				),
			),
			'announcements' => array(
				'view'   => array(
					'read_academy_announcement',
					'edit_academy_announcement',
					'read_private_academy_announcements',
					'edit_academy_announcements',
				),
				'create' => array(
					'edit_academy_announcements',
					'publish_academy_announcements',
				),
				'edit'   => array(
					'edit_academy_announcement',
					'edit_academy_announcements',
					'edit_others_academy_announcements',
					'publish_academy_announcements',
				),
				'delete' => array(
					'delete_academy_announcement',
					'delete_academy_announcements',
				),
			),
			// Same missing-native-cap-bundle gap as webhooks/tutor_booking/meeting/
			// course_bundle: `academy_assignments` is a real custom-capability-type
			// CPT served by the DEFAULT WP_REST_Posts_Controller, so WP core's own
			// checks (publish_posts for status=publish/private,
			// edit_posts for status=any/draft) run directly against these native
			// caps. Found via a live report: GET .../academy_assignments?status=any
			// 403'd for staff even after AjaxGuard's ajax-level assignments policy
			// was fixed, because that only covers the ajax surface, not this
			// separate REST route the CPT also exposes.
			'assignments'   => array(
				'view'   => array(
					'read_academy_assignment',
					'edit_academy_assignment',
					'read_private_academy_assignments',
					'edit_academy_assignments',
				),
				'create' => array(
					'edit_academy_assignments',
					'publish_academy_assignments',
				),
				'edit'   => array(
					'edit_academy_assignment',
					'edit_academy_assignments',
					'edit_others_academy_assignments',
					'publish_academy_assignments',
				),
				'delete' => array(
					'delete_academy_assignment',
					'delete_academy_assignments',
				),
			),
			'certificates'  => array(
				'view'   => array(
					'read_academy_certificate',
					'edit_academy_certificate',
					'read_private_academy_certificates',
					'edit_academy_certificates',
				),
				'create' => array(
					'edit_academy_certificates',
					'publish_academy_certificates',
				),
				'edit'   => array(
					'edit_academy_certificate',
					'edit_academy_certificates',
					'edit_others_academy_certificates',
					'publish_academy_certificates',
				),
				'delete' => array(
					'delete_academy_certificate',
					'delete_academy_certificates',
				),
			),
			// Webhooks is a single_feature (no create/update/delete sub-verbs —
			// see $single_features), so `academy.webhooks` is the only slug ever
			// granted for it and native_caps_for() always resolves it to the
			// 'view' key. RestGuard's write-route check is what actually
			// separates "has the feature" from "may write" for every other
			// single_feature (settings, question_answer, ...), but webhooks is a
			// real CPT with map_meta_cap capabilities — WP_REST_Posts_Controller
			// checks the native `publish_academy_webhooks` cap directly in
			// handle_status_param() before RestGuard ever runs. Without granting
			// the full read+write bundle here, a staffer holding `academy.webhooks`
			// still got a `rest_cannot_publish` 403 from WP core itself. Found via
			// a live report: webhook create failed even after the controller's
			// own hardcoded manage_options-only check and the write-route-map
			// key mismatch were both fixed.
			//
			// `edit_academy_webhook`/`delete_academy_webhook` (SINGULAR) are also
			// required, and are NOT the same thing as the plural caps above: this
			// CPT (like every Academy CPT) registers with `map_meta_cap` left at
			// its default `false`, so WP core's map_meta_cap() takes the early
			// `! $post_type->map_meta_cap` branch and uses the singular cap
			// LITERALLY as the required primitive for `current_user_can(
			// 'edit_post'|'delete_post', $id )` — no author-vs-others distinction,
			// no publish-status distinction, just "does the user hold this exact
			// string". WP_REST_Posts_Controller::get_items() calls
			// check_update_permission() (which resolves to `edit_post`) for every
			// item whenever `context=edit` — which the dashboard always sends —
			// so without the singular cap, `status=any` (and every other status)
			// came back completely EMPTY for staff despite the query itself
			// correctly matching their own posts. Found via a live report: GET
			// .../academy_webhook?status=any returned `[]` for a staffer holding
			// `academy.webhooks`, even after every REST/ajax-guard layer had
			// already been fixed.
			'webhooks'      => array(
				'view'   => array(
					'read_academy_webhook',
					'edit_academy_webhook',
					'delete_academy_webhook',
					'read_private_academy_webhooks',
					'edit_academy_webhooks',
					'edit_others_academy_webhooks',
					'publish_academy_webhooks',
					'delete_academy_webhooks',
				),
				'create' => array(),
				'edit'   => array(),
				'delete' => array(),
			),
			// Same "unverified pro-addon CPT" gap flagged above, confirmed via a
			// broader audit: tutor_booking, meeting, and course_bundle each
			// register a real custom-capability-type CPT (AcademyProTutorBooking\
			// Database, AcademyProMeeting\Database, AcademyProCourseBundle\
			// Database) whose REST controller is the DEFAULT
			// WP_REST_Posts_Controller — meaning WP core's own capability checks
			// (handle_status_param()'s publish_posts check, sanitize_post_statuses()'s
			// edit_posts check for status=any/draft) run directly against these
			// native caps with no custom override to bypass, exactly like
			// webhooks. Without these bundles, a staffer granted e.g.
			// `academy.tutor_booking.create` still hit `rest_cannot_publish` from
			// WP core itself.
			'tutor_booking' => array(
				'view'   => array(
					'read_academy_booking',
					'edit_academy_booking',
					'read_private_academy_bookings',
					'edit_academy_bookings',
				),
				'create' => array(
					'edit_academy_bookings',
					'publish_academy_bookings',
				),
				'edit'   => array(
					'edit_academy_booking',
					'edit_academy_bookings',
					'edit_others_academy_bookings',
					'publish_academy_bookings',
				),
				'delete' => array(
					'delete_academy_booking',
					'delete_academy_bookings',
				),
			),
			'course_bundle' => array(
				'view'   => array(
					'read_academy_course_bundle',
					'edit_academy_course_bundle',
					'read_private_academy_course_bundles',
					'edit_academy_course_bundles',
				),
				'create' => array(
					'edit_academy_course_bundles',
					'publish_academy_course_bundles',
				),
				'edit'   => array(
					'edit_academy_course_bundle',
					'edit_academy_course_bundles',
					'edit_others_academy_course_bundles',
					'publish_academy_course_bundles',
				),
				'delete' => array(
					'delete_academy_course_bundle',
					'delete_academy_course_bundles',
				),
			),
			// meeting is a single_feature (see $single_features) — `academy.meeting`
			// is the only slug ever granted, always resolving to the 'view' key
			// (see the webhooks bundle above for the same reasoning), so the full
			// read+write cap set lives there. `edit_academy_meeting`/
			// `delete_academy_meeting` (SINGULAR) are required for the same
			// map_meta_cap:false reason documented on the webhooks bundle above —
			// without them, `context=edit` list requests (what the dashboard
			// always sends) came back empty for staff even though the underlying
			// WP_Query matched their meetings fine.
			'meeting'       => array(
				'view'   => array(
					'read_academy_meeting',
					'edit_academy_meeting',
					'delete_academy_meeting',
					'read_private_academy_meetings',
					'edit_academy_meetings',
					'edit_others_academy_meetings',
					'publish_academy_meetings',
					'delete_academy_meetings',
				),
				'create' => array(),
				'edit'   => array(),
				'delete' => array(),
			),
			// Group Plus predates this addon and runs its own, independent
			// WP-role-based capability system (academy_team_member /
			// manage_academy_group / manage_academy_team — see
			// AcademyProGroupPlus's ajax handlers), not a CPT. Caps::elevate()
			// only ever grants manage_options/manage_academy_instructor, so a
			// staffer holding `academy.group_plus` would still fail Group Plus's
			// own base ajax-capability checks without this bridge.
			// group_plus IS a crud_resource (has .create/.update/.delete), so
			// unlike meeting/webhooks this distributes across real verbs: the
			// base slug grants member-level read access, any write-verb slug
			// additionally grants organizer-level control (Group Plus's own ajax
			// handlers don't cleanly separate "manage groups" from "manage
			// teams" by CRUD verb, so both organizer caps are granted together).
			'group_plus'    => array(
				'view'   => array(
					'academy_team_member',
				),
				'create' => array(
					'academy_team_member',
					'manage_academy_group',
					'manage_academy_team',
				),
				'edit'   => array(
					'academy_team_member',
					'manage_academy_group',
					'manage_academy_team',
				),
				'delete' => array(
					'academy_team_member',
					'manage_academy_group',
					'manage_academy_team',
				),
			),
		);

		// tutor_booking / assignments / course_bundle / group_plus are pro-addon
		// CPTs whose exact capability names weren't verified while building this
		// first pass (see openspec design.md's flagged risk) — addons can supply
		// their bundles via this filter without touching this file.
		return apply_filters( 'academy/staff/native_cap_bundles', $bundles );
	}
}
