<?php
namespace AcademyProScorm\Lesson;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
use WP_REST_Request;
use WP_REST_Response;
use Academy\Lesson\LessonApi\Lesson;
use ZipArchive;
class Hooks {

	public static function init() {
		ProgressTracker::init();
		add_action( 'rest_api_init', function (): void {
			$namespace = ACADEMY_PRO_PLUGIN_SLUG . '/v1';
			register_rest_route(
				$namespace,
				'/lesson/(?P<lesson_id>[\d-]+)/scorm-upload',
				[
					[
						'methods'             => 'POST',
						'permission_callback' => [ static::class, 'admin_can' ],
						'callback'            => [ static::class, 'upload' ],
					],
					[
						'methods'             => 'DELETE',
						'permission_callback' => [ static::class, 'admin_can' ],
						'callback'            => [ static::class, 'delete' ],
					]
				]
			);
		} );

		add_filter( 'academy/api/lesson/rest_prepare_meta_item', [ static::class, 'rest_prepare_meta_item' ], 10, 2 );
		add_filter( 'academy/lesson', [ static::class, 'lesson_data' ], 10, 2 );
		add_filter( 'academy/api/lesson/public_item_schema', [ static::class, 'public_item_schema' ] );

		add_action(
			'academy/frontend/before_mark_topic_complete',
			[ static::class, 'before_mark_lesson_complete' ],
			10,
			4
		);
	}

	public static function lesson_data( array $data, ?int $id ): array {
		if ( isset( $data['meta']['scorm_data'] ) && is_string( $data['meta']['scorm_data'] ) ) {
			$data['meta']['scorm_data'] = json_decode( $data['meta']['scorm_data'], true );
		}
		return $data;
	}

	public static function rest_prepare_meta_item( array $data, array $lesson_data ): array {
		$data['scorm_data'] = isset( $lesson_data['scorm_data'] ) ? $lesson_data['scorm_data'] : '';
		return $data;
	}

	public static function public_item_schema( array $schema ): array {
		$schema['properties']['meta']['properties'] = array_merge( $schema['properties']['meta']['properties'], static::schema() );
		return $schema;
	}

	public static function schema(): array {
		return [
			'scorm_data' => [
				'type'       => 'object',
				'properties' => [
					'filename' => [
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					],
					'url' => [
						'type'              => 'string',
						'sanitize_callback' => 'esc_url_raw',
					],
					'version' => [
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					],
				],
			],
		];
	}
	public static function admin_can(): bool {
		return current_user_can( 'manage_academy_instructor' ) || current_user_can( 'manage_options' );
	}

	public static function upload( WP_REST_Request $req ): WP_REST_Response {
		$meta = [];
		try {
			$lesson = Lesson::get_by_id( absint( $req['lesson_id'] ) );
		} catch ( \Throwable $e ) {
			return new WP_REST_Response( [
				'success' => false,
				'message' => $e->getMessage()
			], 404 );
		}
		if ( ! static::can_manage_lesson( $lesson ) ) {
			return new WP_REST_Response( [
				'success' => false,
				'message' => __( 'You are not allowed to change this lesson.', 'academy-pro' )
			], 403 );
		}
		// REST route: auth is enforced via the register_rest_route permission_callback ( admin_can ), not a form nonce.
		if ( empty( $_FILES['file'] ) || empty( $_FILES['file']['tmp_name'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			return new WP_REST_Response( [
				'success' => false,
				'message' => sprintf(
					/* translators: %s: the server's maximum upload size, e.g. "64 MB". */
					__( 'File not found. It may be larger than the server upload limit (%s).', 'academy-pro' ),
					size_format( wp_max_upload_size() )
				)
			], 422 );
		}

		$file = $_FILES['file']; // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- REST-authorized upload; file array validated ( ext/zip ) below.
		$ext = strtolower( pathinfo( $file['name'], PATHINFO_EXTENSION ) );

		if ( 'zip' !== $ext ) {
			return new WP_REST_Response( [
				'success' => false,
				'message' => __( 'Invalid file', 'academy-pro' )
			], 422 );
		}

		// Move the uploaded file instead of reading it into memory: a package of
		// several hundred MB would exhaust memory_limit (file_get_contents plus
		// wp_upload_bits hold two copies) and end in a 500 with no JSON message.
		$upload_dir = wp_upload_dir();
		if ( ! empty( $upload_dir['error'] ) ) {
			return new WP_REST_Response( [
				'success' => false,
				'message' => __( 'Error during upload file', 'academy-pro' )
			], 422 );
		}
		$filename = wp_unique_filename( $upload_dir['path'], md5( uniqid( '', true ) ) . '_' . sanitize_file_name( basename( $file['name'] ) ) );
		$zip_path = trailingslashit( $upload_dir['path'] ) . $filename;

		if ( ! move_uploaded_file( $file['tmp_name'], $zip_path ) ) {
			return new WP_REST_Response( [
				'success' => false,
				'message' => __( 'Error during upload file', 'academy-pro' )
			], 422 );
		}

		$zip = new ZipArchive();

		if ( $zip->open( $zip_path ) !== true ) {
			wp_delete_file( $zip_path );
			return new WP_REST_Response( [
				'success' => false,
				'message' => __( 'Error during unpac archive', 'academy-pro' )
			], 422 );
		}

		$blocked = static::get_blocked_entry( $zip );
		if ( $blocked ) {
			$zip->close();
			wp_delete_file( $zip_path );
			return new WP_REST_Response( [
				'success' => false,
				'message' => sprintf(
					/* translators: 1: file path inside the zip, 2: reason it was refused. */
					__( 'This zip archive contains a file that is not allowed: "%1$s" (%2$s).', 'academy-pro' ),
					$blocked['name'],
					$blocked['reason']
				)
			], 422 );
		}

		$upload_dir    = wp_upload_dir();
		$scorm_folder  = $upload_dir['basedir'] . '/academy_uploads/' . sanitize_title( pathinfo( $filename, PATHINFO_FILENAME ) );
		wp_mkdir_p( $scorm_folder );

		$extracted = self::extract_entries( $zip, $scorm_folder );
		$zip->close();
		wp_delete_file( $zip_path );

		if ( ! $extracted ) {
			static::rmdir_recursive( $scorm_folder );
			return new WP_REST_Response( [
				'success' => false,
				'message' => __( 'Error during unpac archive', 'academy-pro' )
			], 422 );
		}

		$version     = self::get_scorm_version( $scorm_folder );
		$iframe_url  = self::get_scorm_iframe_url( $scorm_folder );

		if ( $iframe_url ) {
			$meta['scorm_data'] = [
				'filename' => sanitize_text_field( basename( $file['name'] ) ),
				'url'     => esc_url_raw( $iframe_url ),
				'version' => sanitize_text_field( $version )
			];
		}

		if ( empty( $meta ) ) {
			// Never keep an extracted package that has no valid manifest.
			static::rmdir_recursive( $scorm_folder );
			return new WP_REST_Response( [
				'success' => false,
				'message' => __( 'Invalid file', 'academy-pro' )
			], 422 );
		}

		try {
			$lesson->set_meta_data( $meta );
			$lesson->save_meta_data();
		} catch ( \Throwable $e ) {
			return new WP_REST_Response( [
				'success' => false,
				'message' => $e->getMessage()
			], 404 );
		}
		$data = $lesson->get_data();
		$data['meta'] = array_merge( $data['meta'], $meta );
		return new WP_REST_Response( $data );
	}

	public static function excutable_check( ZipArchive $zip ): bool {
		return null !== static::get_blocked_entry( $zip );
	}

	/**
	 * First archive entry that is refused, with the reason, so the upload error
	 * can name the file instead of only saying the archive is rejected.
	 *
	 * @param ZipArchive $zip Opened archive.
	 * @return array{name:string,reason:string}|null Null when every entry is allowed.
	 */
	public static function get_blocked_entry( ZipArchive $zip ): ?array {
		$allowed = static::allowed_extensions();
		// phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
		for ( $i = 0; $i < $zip->numFiles; $i++ ) {
			$raw_name = (string) $zip->getNameIndex( $i );
			// Some Windows tools write "\" as the folder separator; treat it as "/".
			$file_name = self::normalize_entry_name( $raw_name );

			// OS metadata added by Finder / Explorer is harmless and skipped on extract.
			if ( self::is_ignorable_entry( $file_name ) ) {
				continue;
			}

			// Traversal, absolute paths and drive letters.
			if ( false !== strpos( $file_name, '..' ) || false !== strpos( $file_name, ':' ) || false !== strpos( $file_name, "\0" ) || 0 === strpos( $file_name, '/' ) ) {
				return self::blocked( $file_name, __( 'unsafe path', 'academy-pro' ) );
			}

			// Directory entries carry no content.
			if ( '/' === substr( $file_name, -1 ) ) {
				continue;
			}

			$base = basename( $file_name );
			// Dotfiles (.htaccess, .user.ini, .htpasswd ...) change how the server behaves.
			if ( 0 === strpos( $base, '.' ) ) {
				return self::blocked( $file_name, __( 'hidden file', 'academy-pro' ) );
			}

			// Every dot-separated part is checked, so shell.php.png is refused too.
			$parts = array_slice( explode( '.', strtolower( $base ) ), 1 );
			if ( empty( $parts ) ) {
				return self::blocked( $file_name, __( 'file has no extension', 'academy-pro' ) );
			}
			if ( ! in_array( end( $parts ), $allowed, true ) ) {
				return self::blocked( $file_name, __( 'file type not allowed', 'academy-pro' ) );
			}
			foreach ( $parts as $part ) {
				if ( preg_match( '/^(php\d*|pht|phtml?|phps|phar|inc|shtml?|cgi|pl|py|rb|asp|aspx|jsp|jspx|exe|dll|so|sh|bash|bat|cmd|com|jar|htaccess|ini)$/', $part ) ) {
					return self::blocked( $file_name, __( 'executable file type', 'academy-pro' ) );
				}
			}

			if ( self::has_shebang_or_is_executable( $zip, $raw_name ) ) {
				return self::blocked( $file_name, __( 'contains server-side code', 'academy-pro' ) );
			}
		}

		return null;
	}

	private static function normalize_entry_name( string $name ): string {
		return str_replace( '\\', '/', $name );
	}

	/**
	 * Finder / Explorer leftovers (__MACOSX, .DS_Store, Thumbs.db ...).
	 *
	 * @param string $normalized_name Entry name with "/" separators.
	 */
	private static function is_ignorable_entry( string $normalized_name ): bool {
		if ( 0 === strpos( $normalized_name, '__MACOSX/' ) ) {
			return true;
		}
		return in_array( strtolower( basename( $normalized_name ) ), [ '.ds_store', 'thumbs.db', 'desktop.ini' ], true );
	}

	/**
	 * Extract entry by entry instead of ZipArchive::extractTo(), so "\" separators
	 * become real folders on every OS and nothing can land outside $folder.
	 * Call only after get_blocked_entry() returned null.
	 *
	 * @param ZipArchive $zip    Opened archive.
	 * @param string     $folder Existing destination folder.
	 */
	public static function extract_entries( ZipArchive $zip, string $folder ): bool {
		$root = realpath( $folder );
		if ( ! $root ) {
			return false;
		}
		// phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
		for ( $i = 0; $i < $zip->numFiles; $i++ ) {
			$raw_name = (string) $zip->getNameIndex( $i );
			$name     = self::normalize_entry_name( $raw_name );
			if ( self::is_ignorable_entry( $name ) ) {
				continue;
			}

			$target = $root . '/' . $name;
			if ( '/' === substr( $name, -1 ) ) {
				wp_mkdir_p( $target );
				continue;
			}

			$dir = dirname( $target );
			wp_mkdir_p( $dir );
			$real_dir = realpath( $dir );
			if ( ! $real_dir || ( $real_dir !== $root && 0 !== strpos( $real_dir, $root . DIRECTORY_SEPARATOR ) ) ) {
				return false;
			}

			$in  = $zip->getStream( $raw_name );
			$out = fopen( $real_dir . '/' . basename( $name ), 'wb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen
			if ( ! $in || ! $out ) {
				return false;
			}
			stream_copy_to_stream( $in, $out );
			fclose( $in ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
			fclose( $out ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
		}//end for
		return true;
	}

	private static function blocked( string $name, string $reason ): array {
		return array(
			'name'   => sanitize_text_field( mb_substr( $name, 0, 120 ) ),
			'reason' => $reason,
		);
	}

	/**
	 * Extensions a SCORM package may contain. Everything else, including all
	 * server-side script types and dotfiles, is refused.
	 *
	 * @return string[]
	 */
	protected static function allowed_extensions(): array {
		return apply_filters( 'academy_pro/scorm/allowed_extensions', [
			'html', 'htm', 'xhtml', 'js', 'mjs', 'css', 'json', 'xml', 'xsd', 'dtd', 'xsl', 'xslt',
			'txt', 'csv', 'md', 'map', 'svg', 'png', 'jpg', 'jpeg', 'gif', 'webp', 'ico', 'cur', 'bmp',
			'mp3', 'mp4', 'm4a', 'm4v', 'ogg', 'ogv', 'oga', 'webm', 'wav', 'wmv', 'avi', 'mov', 'flv',
			'swf', 'woff', 'woff2', 'ttf', 'otf', 'eot', 'vtt', 'srt', 'pdf', 'wasm', 'zip', 'dat',
		] );
	}

	/**
	 * Admin, the lesson author, or an instructor of a course whose
	 * curriculum contains the lesson.
	 */
	protected static function can_manage_lesson( $lesson ): bool {
		if ( current_user_can( 'manage_options' ) ) {
			return true;
		}
		$user_id = get_current_user_id();
		$data    = $lesson->get_data();
		if ( ! empty( $data['lesson_author'] ) && (int) $data['lesson_author'] === $user_id ) {
			return true;
		}
		$lesson_id = (int) $lesson->id();
		foreach ( (array) \Academy\Helper::get_assigned_courses_ids_by_instructor_id( $user_id ) as $course_id ) {
			if ( \Academy\Helper::is_course_curriculum( (int) $course_id, $lesson_id, 'lesson' ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Absolute path of the package folder for a stored launch URL, or ''
	 * when it is not a direct child of academy_uploads.
	 */
	protected static function get_scorm_folder_from_url( string $url ): string {
		$upload_dir = wp_upload_dir();
		$prefix     = trailingslashit( $upload_dir['baseurl'] ) . 'academy_uploads/';
		if ( 0 !== strpos( $url, $prefix ) ) {
			return '';
		}
		$segments = explode( '/', ltrim( substr( $url, strlen( $prefix ) ), '/' ) );
		$folder   = $segments[0] ?? '';
		if ( '' === $folder || '.' === $folder || '..' === $folder ) {
			return '';
		}
		$root = realpath( $upload_dir['basedir'] . '/academy_uploads' );
		$path = realpath( $upload_dir['basedir'] . '/academy_uploads/' . $folder );
		if ( ! $root || ! $path || 0 !== strpos( $path, $root . DIRECTORY_SEPARATOR ) ) {
			return '';
		}
		return $path;
	}

	private static function has_shebang_or_is_executable( ZipArchive $zip, string $file_name ): bool {
		// Nested zip/tar/gzip/7z archives are allowed; only PHAR archives are refused.
		$archive_magic_bytes = [
			'phar' => [ 0x50, 0x48, 0x41, 0x52 ],
		];

		$file = $zip->getStream( $file_name );

		if ( false === $file ) {
			return false;
		}

		$file_content = fread( $file, 1024 );// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fread 
		fclose( $file );// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose

		foreach ( $archive_magic_bytes as $format => $signature ) {
			if ( static::matches_magic_bytes( $file_content, $signature ) ) {
				return true;
			}
		}

		if ( 0 === strpos( $file_content, '#!' ) ) {
			return true;
		}

		if ( false !== stripos( $file_content, '<?php' ) || false !== strpos( $file_content, '<?=' ) ) {
			return true;
		}

		return false;
	}


	private static function matches_magic_bytes( string $file_bytes, array $signature ): bool {
		return substr( $file_bytes, 0, count( $signature ) ) === implode( '', array_map( 'chr', $signature ) );
	}

	public static function delete( WP_REST_Request $req ): WP_REST_Response {

		try {
			$lesson = Lesson::get_by_id( absint( $req['lesson_id'] ) );
		} catch ( \Throwable $e ) {
			return new WP_REST_Response( [
				'success' => false,
				'message' => $e->getMessage()
			], 404 );
		}
		if ( ! static::can_manage_lesson( $lesson ) ) {
			return new WP_REST_Response( [
				'success' => false,
				'message' => __( 'You are not allowed to change this lesson.', 'academy-pro' )
			], 403 );
		}
		$data       = $lesson->get_data();
		$scorm_meta = $data['meta']['scorm_data'] ?? '';
		if ( empty( $scorm_meta ) ) {
			return new WP_REST_Response( [
				'success' => false,
				'message' => __( 'Scorm not exists', 'academy-pro' )
			], 404 );
		}
		$scorm_folder = static::get_scorm_folder_from_url( (string) ( $scorm_meta['url'] ?? '' ) );

		// Delete folder (only ever a direct child of academy_uploads).
		if ( $scorm_folder && is_dir( $scorm_folder ) ) {
			static::rmdir_recursive( $scorm_folder );
		}

		try {
			$meta = [];
			$meta['scorm_data'] = null;
			$lesson->set_meta_data( $meta );
			$lesson->save_meta_data();
		} catch ( \Throwable $e ) {
			return new WP_REST_Response( [
				'success' => false,
				'message' => $e->getMessage()
			], 404 );
		}

		return new WP_REST_Response( [ 'status' => __( 'Scorm deleted', 'academy-pro' ) ] );
	}

	public static function rmdir_recursive( string $dir ): bool {
		if ( ! is_dir( $dir ) ) {
			return false;
		}

		$items = scandir( $dir );
		if ( ! $items ) {
			return false;
		}

		foreach ( $items as $item ) {
			if ( '.' === $item || '..' === $item ) {
				continue;
			}

			$path = $dir . DIRECTORY_SEPARATOR . $item;

			if ( is_dir( $path ) ) {
				self::rmdir_recursive( $path );
			} elseif ( is_file( $path ) ) {
				wp_delete_file( $path );
			}
		}

		// Directory inside uploads; WP_Filesystem may need FTP credentials here.
		return rmdir( $dir ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_rmdir, WordPressVIPMinimum.Functions.RestrictedFunctions.directory_rmdir
	}


	protected static function get_scorm_manifest( $path ) {
		$manifest_path = rtrim( $path, '/' ) . '/imsmanifest.xml';
		return ( file_exists( $manifest_path ) ) ? $manifest_path : false;
	}

	protected static function get_scorm_version( $scorm_path ) {
		$scorm_version = '1.2';
		$manifest      = self::get_scorm_manifest( $scorm_path );

		if ( ! $manifest ) {
			return $scorm_version;
		}

		$xml = simplexml_load_file( $manifest );

		if ( ! empty( $xml->metadata ) && count( $xml->metadata ) >= 1 ) {
			$schema_version = $xml->metadata[0]->schemaversion;
			if ( ! empty( $schema_version ) && '1.2' !== (string) $schema_version ) {
				$scorm_version = '2004';
			}
		} elseif ( ! empty( $xml['version'] ) ) {
			$scorm_version = (string) $xml['version'];
		}

		return $scorm_version;
	}

	protected static function get_scorm_iframe_url( $scorm_path ) {
		$upload_dir = wp_upload_dir();
		$scorm_url  = $upload_dir['baseurl'] . '/academy_uploads/' . basename( $scorm_path );

		$manifest_path = self::get_scorm_manifest( $scorm_path );
		if ( ! $manifest_path ) {
			return false;
		}

		$xml = simplexml_load_file( $manifest_path );

		if (
			! empty( $xml )
			&& ! empty( $xml->resources )
			&& ! empty( $xml->resources->resource )
			&& ! empty( $xml->resources->resource->attributes() )
		) {
			$atts = $xml->resources->resource->attributes();
			if ( ! empty( $atts->href ) ) {
				return trailingslashit( $scorm_url ) . ltrim( (string) $atts->href, '/' );
			}
		}

		return false;
	}

	public static function before_mark_lesson_complete( ?string $topic_type, ?int $course_id, ?int $topic_id, ?int $user_id ): void {
		if ( 'lesson' !== $topic_type ) {
			return;
		}

		try {
			$lesson = Lesson::get_by_id( absint( $topic_id ) );
			$data       = $lesson->get_data();
			$scorm_meta = $data['meta']['scorm_data'] ?? '';
			if ( empty( $scorm_meta ) ) {
				return;
			}

			$option_name        = 'academy_course_' . $course_id . '_completed_topics';
			$is_complete = true;
			$saved_topics_lists = json_decode( get_user_meta( $user_id, $option_name, true ), true );

			if ( isset( $saved_topics_lists[ $topic_type ][ $topic_id ] ) ) {
				return;
			}

			$tracker = new ProgressTracker();
			$lesson_data = $tracker->get_data( $course_id, $topic_id )['lessons'] ?? '';

			if ( ! empty( $lesson_data ) && ! static::is_completed( $lesson_data ) ) {
				wp_send_json_error( __( 'You need to complete scorm.', 'academy-pro' ) );
			}
		} catch ( \Throwable $e ) {
			return;
		}//end try
	}

	public static function is_completed( string $str ): bool {
		if ( trim( $str ) === '' ) {
			return true;
		}

		$items = explode( ',', $str );

		foreach ( $items as $item ) {
			$item = trim( $item );
			if ( '0' === $item ) {
				return false;
			} elseif ( '1' !== $item && '0' !== $item ) {
				continue;
			}
		}

		return true;
	}
}
