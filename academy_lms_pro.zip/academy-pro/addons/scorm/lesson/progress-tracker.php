<?php
namespace AcademyProScorm\Lesson;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use WP_REST_Request;
class ProgressTracker {
	protected array $fields = [
		'current',
		'lessons',
		'status',
		'time',
		'score'
	];
	protected int $student_id;
	public function __construct() {
		$id = get_current_user_id();
		$this->student_id = is_int( $id ) ? $id : 0;
	}
	public static function init(): void {
		$self = new self();
		add_action( 'rest_api_init', [ $self, 'course_progress_endpoint' ] );
	}

	public function course_progress_endpoint(): void {
		$namespace = ACADEMY_PRO_PLUGIN_SLUG . '/v1';
		register_rest_route(
			$namespace,
			'/scorm-lesson-progress/(?P<course_id>[\d-]+)/(?P<lesson_id>[\d-]+)/',
			array(
				'methods'             => 'GET',
				'permission_callback' => array( $this, 'progress_permission_check' ),
				'callback'            => array( $this, 'scorm_get_course_progress' ),
			)
		);

		register_rest_route(
			$namespace,
			'/scorm-lesson-progress/(?P<course_id>[\d-]+)/(?P<lesson_id>[\d-]+)/',
			array(
				'methods'             => 'POST',
				'permission_callback' => array( $this, 'progress_permission_check' ),
				'callback'            => array( $this, 'scorm_update_course_progress' ),
			)
		);
	}

	/**
	 * SCORM lesson progress is per-user; require a logged-in user with access to
	 * the course (enrolled/instructor/admin/public) instead of leaving it open.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return bool|\WP_Error
	 */
	public function progress_permission_check( WP_REST_Request $request ) {
		if ( ! is_user_logged_in() ) {
			return new \WP_Error( 'rest_forbidden', esc_html__( 'Sorry, you are not allowed to access this resource.', 'academy-pro' ), array( 'status' => rest_authorization_required_code() ) );
		}
		$course_id = (int) $request->get_param( 'course_id' );
		if ( \Academy\Helper::has_permission_to_access_curriculum( $course_id ) ) {
			return true;
		}
		return new \WP_Error( 'rest_forbidden', esc_html__( 'Sorry, you are not allowed to access this resource.', 'academy-pro' ), array( 'status' => rest_authorization_required_code() ) );
	}

	public function get_data_key( int $course_id, int $lesson_id ): string {
		return "academy_scrom_course_{$course_id}_lesson_{$lesson_id}_progress";
	}

	public function get_data( int $course_id, int $lesson_id ): array {
		$data = get_user_meta(
			$this->student_id,
			$this->get_data_key( $course_id, $lesson_id ),
			true
		);
		return is_array( $data ) ? $data : [];
	}

	public function scorm_get_course_progress( WP_REST_Request $request ): array {
		return apply_filters( 'academy_pro/scorm/get_course_progress',
			$this->get_data( absint( $request['course_id'] ), absint( $request['lesson_id'] ) )
		);
	}

	public function scorm_update_course_progress( WP_REST_Request $request ): array {
		$data = apply_filters(
			'academy_pro/scorm/update_lesson_progress',
			$this->get_data( absint( $request['course_id'] ), absint( $request['lesson_id'] ) )
		);

		foreach ( $this->fields as $field ) {
			if ( isset( $request[ $field ] ) ) {
				$data[ $field ] = 'status' === $field
					? sanitize_text_field( (string) $request[ $field ] )
					: $request[ $field ];
			}
		}

		$course_id = absint( $request['course_id'] );
		$lesson_id = absint( $request['lesson_id'] );

		update_user_meta(
			$this->student_id,
			$this->get_data_key( $course_id, $lesson_id ),
			$data
		);

		$result = $this->get_data( $course_id, $lesson_id );

		// The package reports completion through its status; that is the only
		// signal the LMS gets, so mark the topic complete here instead of
		// leaving the student to find "Mark as complete" after a finished SCO.
		$status                      = isset( $data['status'] ) ? strtolower( (string) $data['status'] ) : '';
		$result['topic_completed_now'] = in_array( $status, [ 'completed', 'passed' ], true )
			&& $this->mark_lesson_complete( $course_id, $lesson_id );

		return $result;
	}

	/**
	 * Mark a SCORM lesson complete for the current student. Idempotent: the
	 * regular mark-complete endpoint toggles, so never call that for this.
	 *
	 * @param int $course_id Course ID.
	 * @param int $lesson_id Lesson ID.
	 * @return bool True only when this call newly completed the topic.
	 */
	protected function mark_lesson_complete( int $course_id, int $lesson_id ): bool {
		$user_id = get_current_user_id();
		if ( ! $user_id
			|| ! \Academy\Helper::is_enrolled( $course_id, $user_id )
			|| ! \Academy\Helper::is_course_curriculum( $course_id, $lesson_id, 'lesson' )
			|| empty( \Academy\Helper::get_lesson_meta( $lesson_id, 'scorm_data' ) )
		) {
			return false;
		}

		$option_name = 'academy_course_' . $course_id . '_completed_topics';
		$saved       = (array) json_decode( (string) get_user_meta( $user_id, $option_name, true ), true );
		if ( isset( $saved['lesson'][ $lesson_id ] ) ) {
			return false;
		}

		$saved['lesson'][ $lesson_id ] = \Academy\Helper::get_time();
		update_user_meta( $user_id, $option_name, wp_json_encode( $saved ) );
		do_action( 'academy/frontend/after_mark_topic_complete', 'lesson', $course_id, $lesson_id, $user_id );

		return true;
	}
}
