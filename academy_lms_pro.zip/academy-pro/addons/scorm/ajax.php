<?php
namespace AcademyProScorm;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Academy\Classes\FileUpload;

class Ajax {
	public static function init() {
		$self = new self();
		add_action( 'wp_ajax_academy_pro_scorm/admin/scorm_file_upload', array( $self, 'scorm_file_upload' ) );
		add_action( 'wp_ajax_academy_pro_scorm/admin/delete_upload_scorm_file', array( $self, 'delete_upload_scorm_file' ) );

		add_action( 'wp_ajax_academy_pro/frontend/get_scorm_course_progress', array( $self, 'get_scorm_course_progress' ) );
		add_action( 'wp_ajax_academy_pro/frontend/update_scorm_course_progress', array( $self, 'update_scorm_course_progress' ) );
	}
	public function scorm_file_upload() {
		check_ajax_referer( 'academy_nonce', 'security' );
		if ( ! current_user_can( 'manage_academy_instructor' ) ) {
			wp_die();
		}
		if ( empty( $_FILES['upload_file']['name'] ) || ! empty( $_FILES['upload_file']['error'] ) ) {
			wp_send_json_error( __( 'The file could not be uploaded. It may be larger than the server upload limit.', 'academy-pro' ) );
		}
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotValidated, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$upload_file = $_FILES['upload_file'];
		$FileUpload = new FileUpload();
		$has_upload = $FileUpload->upload_file( $upload_file, [ 'zip' ] );
		// upload_file() returns a plain message string for a rejected extension.
		if ( ! is_array( $has_upload ) ) {
			wp_send_json_error( __( 'Please upload a SCORM package (.zip).', 'academy-pro' ) );
		}
		if ( $has_upload['error'] ) {
			wp_send_json_error( $has_upload['error'] );
		}
		// Unzip File
		$is_unzip = $this->extract_package( $FileUpload, $has_upload['path'] );
		if ( ! $is_unzip ) {
			// Don't leave the rejected archive behind in the public uploads folder.
			if ( ! empty( $has_upload['path'] ) && file_exists( $has_upload['path'] ) ) {
				wp_delete_file( $has_upload['path'] );
			}
			wp_send_json_error( __( 'This package could not be extracted. The file may be corrupted, or it contains file types that are not allowed.', 'academy-pro' ) );
		}
		// A SCORM package always has its manifest at the root of the archive.
		$folder = $FileUpload->get_upload_dir() . '/' . $is_unzip;
		if ( ! file_exists( $folder . '/imsmanifest.xml' ) ) {
			\AcademyProScorm\Lesson\Hooks::rmdir_recursive( $folder );
			wp_send_json_error( __( 'This is not a valid SCORM package: imsmanifest.xml was not found at the root of the zip.', 'academy-pro' ) );
		}
		wp_send_json_success( $is_unzip );
	}
	public function delete_upload_scorm_file() {
		check_ajax_referer( 'academy_nonce', 'security' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die();
		}
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotValidated, WordPress.Security.ValidatedSanitizedInput.MissingUnslash 
		// Folder names are generated as [A-Za-z0-9_-], so anything else is not one of ours.
		$file_name = isset( $_POST['file_name'] ) ? sanitize_text_field( wp_unslash( $_POST['file_name'] ) ) : '';
		if ( ! preg_match( '/^[A-Za-z0-9_\-]+$/', $file_name ) ) {
			wp_send_json_error( __( 'Sorry, failed to delete', 'academy-pro' ) );
		}
		$FileUpload = new FileUpload();

		// Only a direct child of academy_uploads may be removed: no "../", no
		// separators, and the resolved path must stay inside that folder.
		$root = realpath( $FileUpload->get_upload_dir() );
		$path = '' !== $file_name ? realpath( $FileUpload->get_file_path( $file_name ) ) : false;
		if ( ! $root || ! $path || basename( $path ) !== $file_name || dirname( $path ) !== $root ) {
			wp_send_json_error( __( 'Sorry, failed to delete', 'academy-pro' ) );
		}
		$is_delete = $FileUpload->delete_file( $path );
		if ( $is_delete ) {
			wp_send_json_success( __( 'Successfully Removed', 'academy-pro' ) );
		}
		wp_send_json_error( __( 'Sorry, failed to delete', 'academy-pro' ) );
	}

	public function get_scorm_course_progress() {

		wp_send_json_success( false );
	}
	public function update_scorm_course_progress() {

		wp_send_json_success( false );
	}

	/**
	 * Extract an uploaded SCORM zip into its own folder under academy_uploads.
	 *
	 * Refuses archives with path-traversal entries or anything that can execute
	 * server-side or reconfigure the server (.htaccess). HTML is allowed, since
	 * every SCORM package ships an HTML launch file.
	 *
	 * @param FileUpload $file_upload
	 * @param string     $zip_file Absolute path of the uploaded zip.
	 * @return string|false Extracted folder name, or false on failure.
	 */
	private function extract_package( FileUpload $file_upload, $zip_file ) {
		$zip = new \ZipArchive();
		if ( true !== $zip->open( $zip_file ) ) {
			return false;
		}

		// Same allowlist, dotfile, double-extension and traversal checks as the REST upload.
		if ( \AcademyProScorm\Lesson\Hooks::get_blocked_entry( $zip ) ) {
			$zip->close();
			wp_delete_file( $zip_file );
			return false;
		}

		// Never reuse an existing package folder: that would merge into, or overwrite, another package.
		$folder_name      = preg_replace( '/[^A-Za-z0-9\-]/', '_', pathinfo( $zip_file, PATHINFO_FILENAME ) );
		$folder_name     .= '-' . wp_generate_password( 8, false );
		$extracted_folder = $file_upload->get_upload_dir() . '/' . $folder_name;
		wp_mkdir_p( $extracted_folder );

		$extracted = \AcademyProScorm\Lesson\Hooks::extract_entries( $zip, $extracted_folder );
		$zip->close();
		wp_delete_file( $zip_file );

		if ( ! $extracted ) {
			\AcademyProScorm\Lesson\Hooks::rmdir_recursive( $extracted_folder );
			return false;
		}

		return $folder_name;
	}
}
