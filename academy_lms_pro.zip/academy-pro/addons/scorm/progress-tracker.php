<?php
namespace AcademyProScorm;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use WP_REST_Request;
class ProgressTracker {
	protected array $fields = [
		'current',
		'lessons',
		'status',
		'time',
		'score'
	];
	protected int $student_id;
	public function __construct() {
		$id = get_current_user_id();
		$this->student_id = is_int( $id ) ? $id : 0;
	}
	public static function init(): void {
		$self = new self();
		add_action( 'rest_api_init', [ $self, 'course_progress_endpoint' ] );

		add_filter(
			"academy/topic_completed_by_student_id_{$self->student_id}",
			[ $self, 'topic_completed' ],
			10,
			3
		);
		add_filter(
			'academy/count_total_topics_in_course',
			[ $self, 'total_topics_in_course' ],
			10,
			2
		);
		add_filter(
			'academy/count_total_topics_in_curriculums',
			[ $self, 'total_topics_in_course' ],
			10,
			2
		);
		add_filter(
			'academy/get_student_course_analytics',
			[ $self, 'get_scrom_course_topic_info' ],
			10,
			2
		);
		// The student-facing "Course Details" modal (View Details on the
		// Enrolled Courses widget) gets its data from a *different* AJAX
		// path — Academy\Helper::prepare_analytics_for_user() via
		// includes/ajax/course.php's get_course_details(), which fires
		// 'academy/get_course_analytics' (singular "course_analytics"), not
		// 'academy/get_student_course_analytics' above (that one only feeds
		// the Advanced Analytics addon's own endpoints). Without this, the
		// modal never learns a SCORM file exists and falls back to counting
		// the course's normal curriculum lessons, which is empty for a
		// SCORM-only course — hence "Lessons: 0/0" even though the widget's
		// own progress figure (driven by the filters above) is correct.
		add_filter(
			'academy/get_course_analytics',
			[ $self, 'get_scrom_course_topic_info' ],
			10,
			2
		);
		add_filter(
			'academy/get_courses_analytics',
			[ $self, 'get_scrom_course_total_topics' ],
			10,
			2
		);
	}

	public function course_progress_endpoint(): void {
		$namespace = ACADEMY_PRO_PLUGIN_SLUG . '/v1';
		register_rest_route(
			$namespace,
			'/scorm_course_progress/(?P<course_id>[\d-]+)/',
			array(
				'methods'             => 'GET',
				'permission_callback' => array( $this, 'progress_permission_check' ),
				'callback'            => array( $this, 'scorm_get_course_progress' ),
			)
		);

		register_rest_route(
			$namespace,
			'/scorm_course_progress/(?P<course_id>[\d-]+)/',
			array(
				'methods'             => 'POST',
				'permission_callback' => array( $this, 'progress_permission_check' ),
				'callback'            => array( $this, 'scorm_update_course_progress' ),
			)
		);
	}

	/**
	 * SCORM progress reads/writes are per-user and also write a shared course
	 * option — they must not be open to unauthenticated callers. Require a logged-in
	 * user with access to the course (enrolled/instructor/admin/public).
	 *
	 * @param WP_REST_Request $request Request.
	 * @return bool|\WP_Error
	 */
	public function progress_permission_check( WP_REST_Request $request ) {
		if ( ! is_user_logged_in() ) {
			return new \WP_Error( 'rest_forbidden', esc_html__( 'Sorry, you are not allowed to access this resource.', 'academy-pro' ), array( 'status' => rest_authorization_required_code() ) );
		}
		$course_id = (int) $request->get_param( 'course_id' );
		if ( \Academy\Helper::has_permission_to_access_curriculum( $course_id ) ) {
			return true;
		}
		return new \WP_Error( 'rest_forbidden', esc_html__( 'Sorry, you are not allowed to access this resource.', 'academy-pro' ), array( 'status' => rest_authorization_required_code() ) );
	}

	public function total_topics_in_course( int $completed, int $course_id ): int {
		$data = $this->get_data( $course_id );
		$lessons = count(
			array_filter(
				explode( ',', $data['lessons'] ?? '' ), fn( string $value ) => in_array( $value, [ '0', '1' ], true )
			)
		);
		if ( empty( get_post_meta( $course_id, '_academy_course_builder_scorm_file', true ) ) ) {
			return $completed;
		}
		// Packages whose suspend_data carries no 0/1 lesson flags still count as one topic.
		return 0 === $lessons ? max( $completed, 1 ) : $lessons;
	}

	/**
	 * Whether the student finished the course's SCORM package: the package
	 * reported completed/passed, or the course was already completed (the
	 * player completes it when the package calls LMSFinish).
	 *
	 * @param int        $course_id Course ID.
	 * @param int        $student_id Student ID.
	 * @param array|null $data Saved progress, read when omitted.
	 */
	protected function is_package_finished( int $course_id, int $student_id, ?array $data = null ): bool {
		$data   = $data ?? $this->get_data( $course_id, $student_id );
		$status = strtolower( (string) ( $data['status'] ?? '' ) );
		if ( in_array( $status, [ 'completed', 'passed' ], true ) ) {
			return true;
		}
		return $student_id > 0 && (bool) \Academy\Helper::is_completed_course( $course_id, $student_id );
	}

	public function get_scrom_course_topic_info( $response, $course_id ) {
		$is_array = is_array( $response );

		$set = static function ( &$target, $key, $value, $is_array ) {
			if ( $is_array ) {
				$target[ $key ] = $value;
			} else {
				$target->$key = $value;
			}
		};

		$scorm_file = get_post_meta( $course_id, '_academy_course_builder_scorm_file', true );

		// No SCORM file found → set and return early.
		if ( empty( $scorm_file ) ) {
			$set( $response, 'is_scorm_file_added', false, $is_array );
			return $response;
		}

		// Process SCORM topic information.
		// `academy/get_course_analytics` (the Course Details modal's filter,
		// registered above) doesn't carry a `student_ID` key on $response the
		// way `academy/get_student_course_analytics` does — that handler
		// (includes/ajax/course.php get_course_details()) only ever computes
		// analytics for the current user anyway, so fall back to that.
		$student_id = $is_array
			? ( $response['student_ID'] ?? $this->student_id ) // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
			: ( $response->student_ID ?? $this->student_id ); // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
		$data          = $this->get_data( $course_id, $student_id );
		$lesson_values = explode( ',', $data['lessons'] ?? '' );
		$total_topics     = count( array_filter( $lesson_values, fn( $v ) => in_array( $v, [ '0', '1' ], true ) ) );
		$completed_topics = count( array_filter( $lesson_values, fn( $v ) => '1' === $v ) );
		if ( 0 === $total_topics ) {
			// No 0/1 lesson flags in suspend_data: the package is one topic.
			$total_topics     = 1;
			$completed_topics = $this->is_package_finished( (int) $course_id, (int) $student_id, $data ) ? 1 : 0;
		}
		$progress_percentage = \Academy\Helper::calculate_percentage( $total_topics, $completed_topics ) . '%';

		// set response data
		$set( $response, 'scorm_total_topics', $total_topics, $is_array );
		$set( $response, 'scorm_completed_topics', $completed_topics, $is_array );
		$set( $response, 'is_scorm_file_added', true, $is_array );
		$set( $response, 'progress_percentage', $progress_percentage, $is_array );

		return $response;
	}

	public function get_scrom_course_total_topics( $response, $course_id ) {
		$scorm_file = get_post_meta( $course_id, '_academy_course_builder_scorm_file', true );
		if ( empty( $scorm_file ) ) {
			return $response;
		}
		$response->number_of_lessons = max( 1, $this->get_total_scorm_topics( $course_id ) );
		return $response;
	}

	public function topic_completed( int $topics, int $course_id, int $student_id ): int {
		$data = $this->get_data( $course_id, $student_id );
		$lessons = count(
			array_filter( explode( ',', $data['lessons'] ?? '' ), fn( string $value ) => in_array( $value, [ '1' ], true ) )
		);
		if ( empty( get_post_meta( $course_id, '_academy_course_builder_scorm_file', true ) ) || 0 === $student_id ) {
			return $topics;
		}
		if ( $lessons > 0 ) {
			return $lessons;
		}
		return $this->is_package_finished( $course_id, $student_id, $data ) ? max( $topics, 1 ) : $topics;
	}

	public function get_data_key( int $course_id ): string {
		return "academy_scrom_{$course_id}_course_progress";
	}

	public function get_data( int $course_id, $student_id = null ): array {
		$s_id = $student_id ?? $this->student_id;
		$data = get_user_meta(
			$s_id,
			$this->get_data_key( $course_id ),
			true
		);
		return is_array( $data ) ? $data : [];
	}

	public function scorm_get_course_progress( WP_REST_Request $request ): array {
		$course_id = (int) $request->get_param( 'course_id' );
		$user_id   = (int) $request->get_param( 'user_id' );

		$data = $this->get_data( $course_id );

		return apply_filters(
			'academy_pro/scorm/get_course_progress',
			$data,
			$course_id,
			$user_id
		);
	}

	public function scorm_update_course_progress( WP_REST_Request $request ): array {
		$data = apply_filters(
			'academy_pro/scorm/update_course_progress',
			$this->get_data( absint( $request['course_id'] ), $this->student_id )
		);

		foreach ( $this->fields as $field ) {
			// A non-scalar value (array/object) would make later explode() calls fatal.
			if ( isset( $request[ $field ] ) && is_scalar( $request[ $field ] ) ) {
				$data[ $field ] = 'status' === $field
					? sanitize_text_field( (string) $request[ $field ] )
					: $request[ $field ];
			}
		}

		update_user_meta(
			$this->student_id,
			$this->get_data_key( absint( $request['course_id'] ) ),
			$data
		);
		// update scorm total topics count
		$lesson_values = explode( ',', $data['lessons'] ?? '' );
		$total_topics     = count( array_filter( $lesson_values, fn( $v ) => in_array( $v, [ '0', '1' ], true ) ) );
		update_option( $this->get_data_key( absint( $request['course_id'] ) ), $total_topics );

		return $this->get_data( absint( $request['course_id'] ), $this->student_id );
	}

	public function get_total_scorm_topics( $course_id ) {
		return (int) get_option( $this->get_data_key( $course_id ) );
	}
}
