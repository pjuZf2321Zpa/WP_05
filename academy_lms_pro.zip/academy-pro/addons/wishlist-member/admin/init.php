<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$data = (array) wishlistmember_instance()->get_option( 'academylms_settings' );
$config = \AcademyProWishlistMember\Helper::get_config_for_wishlist();

thirdparty_integration_data(
	$config['id'],
	array(
		'academylms_settings' => $data,
	)
);
