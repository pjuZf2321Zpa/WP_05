<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Config of integration
 * Load this config via helper to further use in the plugin
 */

return \AcademyProWishlistMember\Helper::get_config_for_wishlist();
