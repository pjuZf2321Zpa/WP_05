<?php
namespace AcademyProNotifications;

use AcademyProNotifications\Database\CreateNotificationsTable;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Database {
	public static function create_initial_custom_table() {
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		global $wpdb;
		$prefix          = $wpdb->prefix;
		$charset_collate = $wpdb->get_charset_collate();
		CreateNotificationsTable::create_notifications_table( $prefix, $charset_collate );
	}
}
