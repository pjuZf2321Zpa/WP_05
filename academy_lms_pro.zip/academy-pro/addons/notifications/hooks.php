<?php
namespace AcademyProNotifications;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AcademyProNotifications\Admin\Settings;
use AcademyProNotifications\Meeting\Resolver;

class Hooks {
	private $settings = [
		'instructor_registration' => 'is_enabled_new_instructor_registration_onsite',
		'instructor_approval'     => 'is_enabled_new_instructor_approve_onsite',
		'instructor_remove'       => 'is_enabled_new_instructor_remove_onsite',
		'course_enrollment'       => 'is_enabled_new_course_enrollment_onsite',
		'cancel_enrollment'       => 'is_enabled_cancel_enrollment_onsite',
		'announcement_publish'    => 'is_enabled_announcement_publish_onsite',
		'student_registration'    => 'is_enabled_new_student_registration_onsite',
		'course_publish'          => 'is_enabled_new_course_publish_onsite',
		'course_complete'         => 'is_enabled_course_complete_onsite',
		'course_review'           => 'is_enabled_course_review_onsite',
		'quiz_submit'             => 'is_enabled_quiz_submit_onsite',
		'quiz_evaluate'           => 'is_enabled_quiz_evaluate_onsite',
		'assignment_submit'       => 'is_enabled_assignment_submit_onsite',
		'assignment_evaluate'     => 'is_enabled_assignment_evaluate_onsite',
		'withdraw_request_approved' => 'is_enabled_withdraw_request_approved_onsite',
		'withdraw_request_rejected' => 'is_enabled_withdraw_request_rejected_onsite',
		'question_answer_submit'  => 'is_enabled_question_answer_submit_onsite',
		'question_answer_reply'   => 'is_enabled_question_answer_reply_onsite',
		'meeting_reminder'        => 'is_enabled_meeting_reminder_onsite',
		'meeting_started'         => 'is_enabled_meeting_started_onsite',
		'tutor_booked'            => 'is_enabled_tutor_booked_onsite',
		'tutor_booking_cancelled' => 'is_enabled_tutor_booking_cancelled_onsite',
		'tutor_booking_rescheduled' => 'is_enabled_tutor_booking_rescheduled_onsite',
	];
	public static function init() {
		$self = new self();
		add_filter( 'academy/api/settings/get_settings', array( $self, 'add_settings' ) );
		add_filter( 'academy/get_analytics', array( $self, 'add_meeting_analytics' ) );

		add_action( 'academy/admin/update_instructor_status', array( $self, 'instructor_approval_or_remove_onsite' ), 10, 2 );
		add_action( 'academy/course/after_enroll', array( $self, 'after_enroll_new_course_onsite' ), 10, 3 );
		add_action( 'academy_pro_enrollment/course/after_cancel_enroll', array( $self, 'after_cancel_enroll_onsite' ), 10, 3 );
		add_action( 'rest_after_insert_academy_announcement', array( $self, 'after_academy_announcement_onsite' ) );
		add_action( 'academy/api/auth/after_instructor_registration', array( $self, 'after_instructor_registration_onsite' ) );
		add_action( 'academy/admin/after_register_instructor', array( $self, 'after_instructor_registration_onsite' ) );
		add_action( 'academy/admin/after_register_student', array( $self, 'after_student_registration_onsite' ) );
		add_action( 'academy/api/auth/before_student_registration', array( $self, 'after_student_registration_onsite' ) );
		add_action( 'transition_post_status', array( $self, 'after_academy_course_publish_onsite' ), 10, 3 );
		add_action( 'academy/admin/course_complete_after', array( $self, 'after_course_complete_onsite' ), 10, 2 );
		add_action( 'academy/templates/review_after_comment_text', array( $self, 'after_new_course_review_onsite' ) );
		add_action( 'academy_quizzes/after_quiz_insert', array( $self, 'after_quiz_submit_onsite' ) );
		add_action( 'academy_quizzes/after_quiz_attempt_manual_review', array( $self, 'after_quiz_attempt_manual_review_onsite' ) );
		add_action( 'academy_pro/frontend/submitted_assignment', array( $self, 'after_assignment_submit_onsite' ) );
		add_action( 'academy_pro/frontend/after_evaluate_assignment', array( $self, 'after_assignment_evaluate_onsite' ) );
		add_action( 'academy/multi_instructor/withdraw_request_approved', array( $self, 'after_withdraw_request_updated_onsite' ) );
		add_action( 'academy/multi_instructor/withdraw_request_rejected', array( $self, 'after_withdraw_request_updated_onsite' ) );
		add_action( 'academy/frontend/insert_course_qa', array( $self, 'course_question_answer_insert_onsite' ) );
		add_action( 'academy/frontend/insert_course_qa_answered', array( $self, 'course_question_answer_reply_onsite' ) );
		add_action( 'academy_pro/meeting/reminder_due', array( $self, 'meeting_reminder_due_onsite' ) );
		add_action( 'academy_pro/meeting/started', array( $self, 'meeting_started_onsite' ) );
		add_action( 'academy_pro/booking/after_booked', array( $self, 'tutor_booked_onsite' ), 10, 3 );
		add_action( 'academy_pro/booking/after_cancelled', array( $self, 'tutor_booking_cancelled_onsite' ), 10, 3 );
		add_action( 'academy_pro/booking/after_rescheduled', array( $self, 'tutor_booking_rescheduled_onsite' ), 10, 5 );

		// Frontend dashboard landing page — inject 2 more cards into the
		// existing analytics row (same hook the gamipress addon already
		// uses for its own card, see addons/gamipress/hooks.php).
		add_action( 'academy/templates/frontend_dashboard/after_analytics_card_item', array( $self, 'render_meetings_overview_cards' ) );
	}
	/**
	 * Adds unscoped (admin-view) meeting counts to the existing
	 * `academy/get_analytics` payload, consumed by the backend admin
	 * dashboard's Overview tab analytics cards (see the matching free-plugin
	 * edits: analyticsSlice.js's key whitelist and AnalyticCards/index.js's
	 * `applyFilters` wrap).
	 *
	 * @param array $analytics
	 */
	public function add_meeting_analytics( array $analytics ): array {
		$analytics['live_meetings_count']     = count( Resolver::get_live_now() );
		$analytics['upcoming_meetings_count'] = count( Resolver::get_upcoming_meetings( 0, 7 ) ) + count( Resolver::get_upcoming_bookings( 0, 7 ) );
		return $analytics;
	}

	public function add_settings( $settings ) {
		if ( ! isset( $settings['notifications'] ) ) {
			$settings['notifications'] = Settings::get_saved_data();
		}
		return $settings;
	}

	public function instructor_approval_or_remove_onsite( $ID, $status ) {
		$isApproved = ( 'approved' === $status && Helper::get_setting( $this->settings['instructor_approval'] ) );
		$isRemoved = ( 'remove' === $status && Helper::get_setting( $this->settings['instructor_remove'] ) );

		if ( $isApproved || $isRemoved ) {
			$name = \Academy\Helper::get_instructor( $ID )->display_name;
			/* translators: %s is a username, %s is a username. */
			$content = $isApproved ? sprintf( __( 'Congratulations, %s! You are become an instructor now.', 'academy-pro' ), $name ) : sprintf( __( 'Alas, %s! You are removed from instructor.', 'academy-pro' ), $name );
			$status = $isApproved ? __( 'Approval', 'academy-pro' ) : __( 'Removed', 'academy-pro' );
			Helper::insert_notification_details(
				array(
					/* translators: %s is a username */
					'title' => sprintf( __( 'Instructor %s', 'academy-pro' ), $status ),
					'content' => $content,
					'status' => 'UNREAD',
					'receiver_id' => $ID,
					'post_id'  => 0,
					'topic_id' => 0,
					'type' => 'user-dashboard',
					'created_at' => current_time( 'mysql' ),
				)
			);
		}
	}

	public function after_enroll_new_course_onsite( $course_id, $enroll_id, $user_id ) {

		if (
			! Helper::is_enrollment_completed( $course_id, $user_id ) ||
			Helper::is_duplicate( $course_id, $user_id ) ||
			! Helper::get_setting( $this->settings['course_enrollment'] )
		) {
			return;
		}
		$enrolled_post = get_post( $enroll_id );
		$name          = get_userdata( $user_id )->display_name;
		$course_title  = get_the_title( $course_id );
		/* translators: %s is a username, %s is a coursename. */
		$body          = sprintf( __( 'Hey, %1$s! You have successfully enrolled the course %2$s .', 'academy-pro' ), $name, $course_title );
		Helper::insert_notification_details( array(
			'title' => __( 'Successfully Enrolled', 'academy-pro' ),
			'content' => $body,
			'status' => 'UNREAD',
			'receiver_id' => $user_id,
			'post_id'  => $course_id,
			'topic_id' => 0,
			'type' => 'academy_courses',
			'created_at' => $enrolled_post->post_date,
		) );
	}

	public function after_cancel_enroll_onsite( $course_id, $enroll_id, $user_id ) {
		if ( \Academy\Helper::is_enrolled( $course_id, $user_id ) || ! Helper::get_setting( $this->settings['cancel_enrollment'] ) ) {
			return;
		}

		$name         = get_userdata( $user_id )->display_name;
		$course_title = get_the_title( $course_id );
		/* translators: %s is a username, %s is a coursename. */
		$body         = sprintf( __( 'Alas, %1$s! You enrollment has been removed from the course %2$s .', 'academy-pro' ), $name, $course_title );
		Helper::insert_notification_details( array(
			'title' => 'Cancel Enrolled',
			'content' => $body,
			'status' => 'UNREAD',
			'receiver_id' => $user_id,
			'post_id'  => $course_id,
			'topic_id' => 0,
			'type' => 'academy_courses',
			'created_at' => current_time( 'mysql' ),
		) );
	}

	public function after_academy_announcement_onsite( $announcement ) {
		if ( ! Helper::get_setting( $this->settings['announcement_publish'] ) ) {
			return;
		}

		$announcement_course = get_post_meta( $announcement->ID, 'academy_announcements_course_ids', true );
		if ( ! count( $announcement_course ) ) {
			return;
		}
		$announcement_course = current( maybe_unserialize( $announcement_course ) );
		$course_id = $announcement_course['value'];
		$student_ids = Helper::get_students_ids_by_course_id( $course_id );
		/* translators: %s is a coursename. */
		$body = sprintf( 'New announcement publish for the course %s .', $announcement_course['label'] );

		foreach ( $student_ids as $student_id ) {
			Helper::insert_notification_details(
				array(
					'title' => __( 'Announcement Publish', 'academy-pro' ),
					'content' => $body,
					'status' => 'UNREAD',
					'receiver_id' => $student_id->post_author,
					'post_id'  => $course_id,
					'topic_id' => 0,
					'type' => 'announcement_publish',
					'created_at' => current_time( 'mysql' ),
				)
			);
		}
	}

	public function after_instructor_registration_onsite( $user_id ) {
		if ( ! Helper::get_setting( $this->settings['instructor_registration'] ) ) {
			return;
		}
		$admin_data = get_users(
			array( 'role' => 'administrator' )
		);
		if ( empty( $admin_data ) ) {
			return;
		}
		$user_data = get_userdata( $user_id );
		/* translators: %s is a username. */
		$body  = sprintf( __( 'New Instructor Registration Approval Request by %s', 'academy-pro' ), $user_data->display_name );

		foreach ( $admin_data as $admin ) {
			Helper::insert_notification_details(
				array(
					'title' => __( 'Instructor Approval Request', 'academy-pro' ),
					'content' => $body,
					'status' => 'UNREAD',
					'receiver_id' => $admin->ID,
					'post_id'  => 0,
					'topic_id' => 0,
					'type' => 'instructor-approval-request',
					'created_at' => current_time( 'mysql' ),
				)
			);
		}
	}

	public function after_student_registration_onsite( $user_id ) {
		if ( ! Helper::get_setting( $this->settings['student_registration'] ) ) {
			return;
		}
		$admin_data = get_users(
			array( 'role' => 'administrator' )
		);
		if ( empty( $admin_data ) ) {
			return;
		}
		$user_data = get_userdata( $user_id );
		/* translators: %s is a username */
		$body = sprintf( __( 'New Student %s Registration Successfully', 'academy-pro' ), ! empty( $user_data->display_name ) ? $user_data->display_name : '' );
		foreach ( $admin_data as $admin ) {
			Helper::insert_notification_details(
				array(
					'title' => __( 'Student Registration', 'academy-pro' ),
					'content' => $body,
					'status' => 'UNREAD',
					'receiver_id' => $admin->ID,
					'post_id' => 0,
					'topic_id' => 0,
					'type' => 'student-registration',
					'created_at' => current_time( 'mysql' ),
				)
			);
		}
	}

	public function after_academy_course_publish_onsite( $new_status, $old_status, $post ) {
		if ( ! Helper::get_setting( $this->settings['course_publish'] ) ) {
			return;
		}

		if ( 'academy_courses' === $post->post_type && 'publish' === $new_status && 'publish' !== $old_status ) {
			Helper::insert_notification_details(array(
				'title' => __( 'New Course Publish', 'academy-pro' ),
				/* translators: %s is a coursename. */
				'content' => sprintf( __( 'You have Published A New Course %s', 'academy-pro' ), $post->post_title ),
				'status' => 'UNREAD',
				'receiver_id' => $post->post_author,
				'post_id' => $post->ID,
				'topic_id' => 0,
				'type' => 'academy_courses',
				'created_at' => current_time( 'mysql' ),
			));
		}
	}

	public function after_course_complete_onsite( $course_id, $user_id ) {
		if ( ! Helper::get_setting( $this->settings['course_complete'] ) ) {
			return;
		}
		$instructors = Helper::get_course_receivers( $course_id );
		if ( empty( $instructors ) ) {
			return;
		}
		foreach ( $instructors as $instructor ) {
			Helper::insert_notification_details(array(
				'title' => __( 'Course Completed', 'academy-pro' ),
				/* translators: %s is a username */
				'content' => sprintf( __( 'Hey %1$s, Successfully Your student %2$s Complete a course %3$s', 'academy-pro' ), $instructor->display_name, get_userdata( $user_id )->display_name, get_the_title( $course_id ) ),
				'status' => 'UNREAD',
				'receiver_id' => $instructor->ID,
				'post_id' => $course_id,
				'topic_id' => 0,
				'type' => 'academy_courses',
				'created_at' => current_time( 'mysql' ),
			));
		}
	}

	public function after_new_course_review_onsite( $comment ) {
		if ( ! Helper::get_setting( $this->settings['course_review'] ) ) {
			return;
		}

		if ( ! (bool) $comment->comment_approved && 'academy_courses' !== $comment->comment_type ) {
			return;
		}

		$instructors = Helper::get_course_receivers( $comment->comment_post_ID );
		foreach ( $instructors as $instructor ) {
			Helper::insert_notification_details(array(
				'title' => __( 'Course Review', 'academy-pro' ),
				/* translators: %s is a username, %s is a courratingsename, %s is a coursename. */
				'content' => sprintf( __( 'Hey, %1$s! You have found %2$s star rating of this course %3$s', 'academy-pro' ), $instructor->display_name, get_comment_meta( $comment->comment_ID, 'academy_rating', true ), get_the_title( $comment->comment_post_ID ) ),
				'status' => 'UNREAD',
				'receiver_id' => $instructor->ID,
				'post_id' => $comment->comment_post_ID,
				'topic_id' => 0,
				'type' => 'academy_courses',
				'created_at' => current_time( 'mysql' ),
			));
		}
	}
	public function after_quiz_submit_onsite( $quiz_data ) {
		if ( ! Helper::get_setting( $this->settings['quiz_submit'] ) ) {
			return;
		}

		$course_id = $quiz_data->course_id;
		$instructors = Helper::get_course_receivers( $course_id );
		foreach ( $instructors as $instructor ) {
			Helper::insert_notification_details(array(
				'title' => __( 'Quiz Submit', 'academy-pro' ),
				'content' => __( 'A new quiz has been submitted', 'academy-pro' ),
				'status' => 'UNREAD',
				'receiver_id' => $instructor->ID,
				'post_id' => $quiz_data->course_id,
				'topic_id' => 0,
				'type' => 'academy_quizzes',
				'created_at' => current_time( 'mysql' ),
			));
		}
	}

	public function after_quiz_attempt_manual_review_onsite( $attempt ) {
		if ( ! Helper::get_setting( $this->settings['quiz_evaluate'] ) ) {
			return;
		}
		$student_id = isset( $attempt['student_id'] ) ? $attempt['student_id'] : 0;
		$student = get_userdata( $student_id );

		Helper::insert_notification_details(array(
			'title' => __( 'Quiz Reviewed', 'academy-pro' ),
			/* translators: %s is a username. */
			'content' => sprintf( __( 'Hey, %1$s! A quiz has been reviewed.', 'academy-pro' ), $student->display_name ),
			'status' => 'UNREAD',
			'receiver_id' => isset( $attempt['user_id'] ) ? $attempt['user_id'] : 0,
			'post_id' => isset( $attempt['course_id'] ) ? $attempt['course_id'] : 0,
			'topic_id' => isset( $attempt['quiz_id'] ) ? $attempt['quiz_id'] : 0,
			'type' => 'evaluate_quiz',
			'created_at' => current_time( 'mysql' ),
		));
	}

	public function after_assignment_submit_onsite( $assignment_data ) {
		if ( ! Helper::get_setting( $this->settings['assignment_submit'] ) ) {
			return;
		}

		$course_id = $assignment_data->comment_parent;
		$instructors = Helper::get_course_receivers( $course_id );
		foreach ( $instructors as $instructor ) {
			Helper::insert_notification_details(array(
				'title' => __( 'Assignment Submit', 'academy-pro' ),
				'content' => __( 'A new assignment has been submitted', 'academy-pro' ),
				'status' => 'UNREAD',
				'receiver_id' => $instructor->ID,
				'post_id' => $assignment_data->comment_post_ID,
				'topic_id' => 0,
				'type' => 'academy_pro_assignments',
				'created_at' => current_time( 'mysql' ),
			));
		}
	}

	public function after_assignment_evaluate_onsite( $assignment_data ) {
		if ( ! Helper::get_setting( $this->settings['assignment_evaluate'] ) ) {
			return;
		}

		$student = get_userdata( $assignment_data->user_id );

		Helper::insert_notification_details(array(
			'title' => __( 'Assignment Reviewed', 'academy-pro' ),
			/* translators: %s is a username. */
			'content' => sprintf( __( 'Hey, %1$s! An assignment has been reviewed.', 'academy-pro' ), $student->display_name ),
			'status' => 'UNREAD',
			'receiver_id' => $assignment_data->user_id,
			'post_id' => $assignment_data->course_id,
			'topic_id' => $assignment_data->assignment_id,
			'type' => 'evaluate_assignments',
			'created_at' => current_time( 'mysql' ),
		));
	}

	public function after_withdraw_request_updated_onsite( $result ) {
		$isApproved = ( 'approved' === $result->status && Helper::get_setting( $this->settings['withdraw_request_approved'] ) );
		$isRejected = ( 'rejected' === $result->status && Helper::get_setting( $this->settings['withdraw_request_rejected'] ) );

		if ( $isApproved || $isRejected ) {
			$name = $result->user_login;
			/* translators: %s is a username., %s is a username */
			$content = $isApproved ? sprintf( __( 'Congratulations, %s! Your submitted withdraw request is Approved.', 'academy-pro' ), $name ) : sprintf( __( 'Alas, %s! Your submitted withdraw request is Rejected.', 'academy-pro' ), $name );
			$status = $isApproved ? __( 'Approved', 'academy-pro' ) : __( 'Rejected', 'academy-pro' );
			Helper::insert_notification_details(
				array(
					// translators: %s is request status
					'title' => sprintf( __( 'Withdraw Request %s', 'academy-pro' ), $status ),
					'content' => $content,
					'status' => 'UNREAD',
					'receiver_id' => $result->user_id,
					'post_id'  => 0,
					'topic_id' => 0,
					'type' => 'withdraw-request',
					'created_at' => current_time( 'mysql' ),
				)
			);
		}
	}

	public function course_question_answer_insert_onsite( $comment ) {
		if ( ! Helper::get_setting( $this->settings['question_answer_submit'] ) || 'waiting_for_answer' !== $comment['status'] ) {
			return;
		}
		$author_id = get_post( $comment['post'] )->post_author;
		$course_name = get_the_title( $comment['post'] );
		Helper::insert_notification_details(array(
			'title' => __( 'User Course Question', 'academy-pro' ),
			/* translators: %s is a username., %s is a coursename */
			'content' => sprintf( __( 'Hey, your student %1$s submitted question in a course of %2$s', 'academy-pro' ), $comment['author_name'], $course_name ),
			'status' => 'UNREAD',
			'receiver_id' => $author_id,
			'post_id' => $comment['post'],
			'topic_id' => 0,
			'type' => 'question_answer_submit',
			'created_at' => current_time( 'mysql' ),
		));
	}

	public function course_question_answer_reply_onsite( $comment ) {
		if ( ! Helper::get_setting( $this->settings['question_answer_reply'] ) || 'answered' !== $comment['status'] ) {
			return;
		}
		$receiver_id = get_comment( $comment['parent'] )->user_id;
		$student_name = get_userdata( $receiver_id )->display_name;
		$course_name = get_the_title( $comment['post'] );
		Helper::insert_notification_details(array(
			'title' => __( 'Course Question Reply', 'academy-pro' ),
			/* translators: %s is a username., %s is a coursename */
			'content' => sprintf( __( 'Hey %1$s, your submitted question has replied in a course of %2$s', 'academy-pro' ), $student_name, $course_name ),
			'status' => 'UNREAD',
			'receiver_id' => $receiver_id,
			'post_id' => $comment['post'],
			'topic_id' => 0,
			'type' => 'question_answer_reply',
			'created_at' => current_time( 'mysql' ),
		));
	}

	/**
	 * @param array $context Normalized occurrence context — see
	 *              `AcademyProMeetingNotifications\Resolver`.
	 */
	public function meeting_reminder_due_onsite( array $context ) {
		if ( ! Helper::get_setting( $this->settings['meeting_reminder'] ) ) {
			return;
		}
		/* translators: %1$s is a meeting/booking title, %2$s is the scheduled date/time. */
		$body = sprintf( __( '"%1$s" starts soon (%2$s).', 'academy-pro' ), $context['title'], self::format_context_time( $context ) );
		$this->insert_meeting_notification_for_all( $context, __( 'Meeting Starting Soon', 'academy-pro' ), $body );
	}

	/**
	 * @param array $context Normalized occurrence context — see
	 *              `AcademyProMeetingNotifications\Resolver`.
	 */
	public function meeting_started_onsite( array $context ) {
		if ( ! Helper::get_setting( $this->settings['meeting_started'] ) ) {
			return;
		}
		/* translators: %s is a meeting/booking title. */
		$body = sprintf( __( '"%s" has started.', 'academy-pro' ), $context['title'] );
		$this->insert_meeting_notification_for_all( $context, __( 'Meeting Started', 'academy-pro' ), $body );
	}

	/**
	 * `$context['start_time']` is a unix timestamp for both source types
	 * (see Resolver) — format it in the site's date/time format for use in
	 * notification bodies, so they read as more than just a bare title.
	 *
	 * @param array $context
	 */
	public static function format_context_time( array $context ): string {
		return wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), (int) $context['start_time'] );
	}

	private function insert_meeting_notification_for_all( array $context, string $title, string $body ) {
		$receiver_ids = array_filter( array_unique( array_merge(
			array( $context['instructor_id'] ),
			$context['student_ids'],
			wp_list_pluck( get_users( array( 'role' => 'administrator' ) ), 'ID' )
		) ) );

		$type    = 'meeting' === $context['source_type'] ? 'academy_courses' : 'meeting_tutor_booking';
		$post_id = 'meeting' === $context['source_type'] ? (int) $context['course_id'] : 0;

		foreach ( $receiver_ids as $receiver_id ) {
			Helper::insert_notification_details( array(
				'title'       => $title,
				'content'     => $body,
				'status'      => 'UNREAD',
				'receiver_id' => $receiver_id,
				'post_id'     => $post_id,
				'topic_id'    => (int) $context['source_id'],
				'type'        => $type,
				'created_at'  => current_time( 'mysql' ),
			) );
		}
	}

	/**
	 * Booking confirmed — mirrors the existing `course_enrollment` onsite
	 * notification, just for `academy_pro/booking/after_booked` instead of
	 * `academy/course/after_enroll`. The Email addon already sends a
	 * confirmation email for this same event (`tutor_booked_email_to_*`);
	 * this adds the matching bell + push (see Pusher::tutor_booked_push()).
	 *
	 * @param int $booking_id
	 * @param int $booked_id
	 * @param int $user_id
	 */
	public function tutor_booked_onsite( $booking_id, $booked_id, $user_id ) {
		if ( ! Helper::get_setting( $this->settings['tutor_booked'] ) ) {
			return;
		}

		$student_name    = get_userdata( $user_id )->display_name ?? '';
		$instructor_id   = (int) get_post_field( 'post_author', $booking_id );
		$title           = get_the_title( $booking_id );
		$session_time    = \AcademyProTutorBooking\Helper::format_booked_schedule_time( $booked_id );
		$body            = $session_time
			/* translators: %1$s is a student name, %2$s is a booking/session title, %3$s is the scheduled date/time. */
			? sprintf( __( '%1$s booked "%2$s" for %3$s', 'academy-pro' ), $student_name, $title, $session_time )
			/* translators: %1$s is a student name, %2$s is a booking/session title. */
			: sprintf( __( '%1$s booked a session: %2$s', 'academy-pro' ), $student_name, $title );

		$receiver_ids = array_filter( array_unique( array_merge(
			array( $instructor_id, (int) $user_id ),
			wp_list_pluck( get_users( array( 'role' => 'administrator' ) ), 'ID' )
		) ) );

		foreach ( $receiver_ids as $receiver_id ) {
			Helper::insert_notification_details( array(
				'title'       => __( 'Booking Confirmed', 'academy-pro' ),
				'content'     => $body,
				'status'      => 'UNREAD',
				'receiver_id' => $receiver_id,
				'post_id'     => 0,
				'topic_id'    => (int) $booked_id,
				'type'        => 'meeting_tutor_booking',
				'created_at'  => current_time( 'mysql' ),
			) );
		}
	}

	/**
	 * Booking cancelled — same shape as tutor_booked_onsite, fired by the
	 * student's self-service Cancel button (or admin force-cancel) on
	 * `academy_pro/booking/after_cancelled`.
	 *
	 * @param int $booking_id
	 * @param int $booked_id
	 * @param int $user_id
	 */
	public function tutor_booking_cancelled_onsite( $booking_id, $booked_id, $user_id ) {
		if ( ! Helper::get_setting( $this->settings['tutor_booking_cancelled'] ) ) {
			return;
		}

		$student_name  = get_userdata( $user_id )->display_name ?? '';
		$instructor_id = (int) get_post_field( 'post_author', $booking_id );
		$title         = get_the_title( $booking_id );
		/* translators: %1$s is a student name, %2$s is a booking/session title. */
		$body          = sprintf( __( '%1$s cancelled their booking: %2$s', 'academy-pro' ), $student_name, $title );

		$receiver_ids = array_filter( array_unique( array_merge(
			array( $instructor_id, (int) $user_id ),
			wp_list_pluck( get_users( array( 'role' => 'administrator' ) ), 'ID' )
		) ) );

		foreach ( $receiver_ids as $receiver_id ) {
			Helper::insert_notification_details( array(
				'title'       => __( 'Booking Cancelled', 'academy-pro' ),
				'content'     => $body,
				'status'      => 'UNREAD',
				'receiver_id' => $receiver_id,
				'post_id'     => 0,
				'topic_id'    => (int) $booked_id,
				'type'        => 'meeting_tutor_booking',
				'created_at'  => current_time( 'mysql' ),
			) );
		}
	}

	/**
	 * Booking rescheduled — fired by the student's self-service Reschedule
	 * button on `academy_pro/booking/after_rescheduled`.
	 *
	 * @param int   $booking_id
	 * @param int   $booked_id
	 * @param int   $user_id
	 * @param mixed $old_schedule
	 * @param mixed $new_schedule
	 */
	public function tutor_booking_rescheduled_onsite( $booking_id, $booked_id, $user_id, $old_schedule, $new_schedule ) {
		if ( ! Helper::get_setting( $this->settings['tutor_booking_rescheduled'] ) ) {
			return;
		}

		$student_name  = get_userdata( $user_id )->display_name ?? '';
		$instructor_id = (int) get_post_field( 'post_author', $booking_id );
		$title         = get_the_title( $booking_id );
		/* translators: %1$s is a student name, %2$s is a booking/session title, %3$s is the new scheduled date/time. */
		$body          = sprintf( __( '%1$s rescheduled "%2$s" to %3$s', 'academy-pro' ), $student_name, $title, $new_schedule );

		$receiver_ids = array_filter( array_unique( array_merge(
			array( $instructor_id, (int) $user_id ),
			wp_list_pluck( get_users( array( 'role' => 'administrator' ) ), 'ID' )
		) ) );

		foreach ( $receiver_ids as $receiver_id ) {
			Helper::insert_notification_details( array(
				'title'       => __( 'Booking Rescheduled', 'academy-pro' ),
				'content'     => $body,
				'status'      => 'UNREAD',
				'receiver_id' => $receiver_id,
				'post_id'     => 0,
				'topic_id'    => (int) $booked_id,
				'type'        => 'meeting_tutor_booking',
				'created_at'  => current_time( 'mysql' ),
			) );
		}
	}

	/**
	 * Adds "Live Meetings" / "Upcoming Meetings" cards to the frontend
	 * dashboard's existing analytics-cards row (same markup as the built-in
	 * cards in templates/frontend-dashboard/pages/dashboard.php), scoped to
	 * the current viewer: instructor sees their own scheduled sessions,
	 * student sees their own bookings.
	 */
	public function render_meetings_overview_cards() {
		$is_instructor = current_user_can( 'manage_academy_instructor' );
		$user_id       = get_current_user_id();

		if ( $is_instructor ) {
			$live       = array_filter( Resolver::get_live_now(), fn( $o ) => (int) $o['instructor_id'] === $user_id );
			$upcoming   = count( Resolver::get_upcoming_meetings( $user_id ) ) + count( Resolver::get_upcoming_bookings( $user_id ) );
		} else {
			$live       = array_filter( Resolver::get_live_now(), fn( $o ) => in_array( $user_id, $o['student_ids'], true ) );
			$upcoming   = count( Resolver::get_upcoming_meetings( 0, 30, $user_id ) ) + count( Resolver::get_upcoming_bookings( 0, 30, $user_id ) );
		}
		$live_count = count( $live );

		// Instructors have a dedicated "Meetings" dashboard page; students only
		// have "My Tutor Bookings" — neither page unifies course meetings and
		// tutor bookings, but each is the closest existing list for its viewer,
		// same target the sidebar item already uses (functions.php's
		// $my_booking_page_url).
		$cards_link = $is_instructor
			? \Academy\Helper::get_frontend_dashboard_endpoint_url( 'meeting' )
			: \Academy\Helper::get_frontend_dashboard_endpoint_url( 'my-bookings' );
		?>
		<a class="academy-analytics-cards--card" href="<?php echo esc_url( $cards_link ); ?>">
			<div class="academy-analytics-card--icon <?php echo $live_count ? 'icon-live' : 'icon-upcoming'; ?>"><span class="academy-icon academy-icon--calendar"></span></div>
			<div class="academy-analytics-card--data">
				<h2 class="academy-analytics-card--value"><?php echo esc_html( $live_count ); ?></h2>
				<p class="academy-analytics-card--label"><?php esc_html_e( 'Live Meetings Now', 'academy-pro' ); ?><span></span></p>
			</div>
		</a>
		<a class="academy-analytics-cards--card" href="<?php echo esc_url( $cards_link ); ?>">
			<div class="academy-analytics-card--icon icon-upcoming"><span class="academy-icon academy-icon--calendar"></span></div>
			<div class="academy-analytics-card--data">
				<h2 class="academy-analytics-card--value"><?php echo esc_html( $upcoming ); ?></h2>
				<p class="academy-analytics-card--label"><?php esc_html_e( 'Upcoming Meetings', 'academy-pro' ); ?><span></span></p>
			</div>
		</a>
		<?php
	}
}
