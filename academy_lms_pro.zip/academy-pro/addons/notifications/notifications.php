<?php
namespace AcademyProNotifications;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Academy\Interfaces\AddonInterface;
use AcademyProNotifications\Classes\Pusher;
use AcademyProNotifications\Meeting\Tick;
use AcademyProNotifications\Meeting\Badge as MeetingBadge;
use AcademyProNotifications\Meeting\Ajax as MeetingAjax;


final class Notifications implements AddonInterface {
	private $addon_name = 'notifications';

	private function __construct() {
		$this->define_constants();
		$this->init_addon();
	}

	public static function init() {
		static $instance = false;

		if ( ! $instance ) {
			$instance = new self();
		}

		return $instance;
	}

	public function define_constants() {
		/**
		 * Define constant for whole addon
		 */
		define( 'ACADEMY_PRO_NOTIFICATIONS_VERSION', 1.0 );
		define( 'ACADEMY_PRO_NOTIFICATIONS_VERSION_NAME', 'academy_pro_notification_version' );
		define( 'ACADEMY_PRO_NOTIFICATIONS_SETTINGS_NAME', 'academy_pro_notifications_settings' );
		define( 'ACADEMY_PRO_NOTIFICATIONS_PATH', ACADEMY_PRO_ROOT_DIR_PATH . 'addons/notifications' );
		define( 'ACADEMY_PRO_NOTIFICATIONS_ASSETS', ACADEMY_PRO_PLUGIN_ROOT_URI . 'addons/notifications/assets' );
	}

	public function init_addon() {
		// fire addon activation hook
		add_action( "academy/addons/activated_$this->addon_name", array( $this, 'addon_activation_hook' ) );
		add_action( "academy/addons/deactivated_{$this->addon_name}", array( $this, 'addon_deactivation_hook' ) );

		// if addon is not enabled then stop working
		if ( ! \Academy\Helper::get_addon_active_status( $this->addon_name ) ) {
			return;
		}

		// Run addon functionality
		Ajax::init();
		Pusher::init();
		Hooks::init();
		Tick::init();
		MeetingBadge::init();
		MeetingAjax::init();

		$this->run_migration();
	}

	/**
	 * Backfills new setting keys into a site that already saved notification
	 * settings before these existed — Admin\Settings::get_saved_data() only
	 * ever returns exactly what was saved, so a site that saved before
	 * "tutor_booking_cancelled"/"tutor_booking_rescheduled" were added would
	 * otherwise have Helper::get_setting() return false for them forever
	 * (silently OFF), even though their default is enabled.
	 */
	public function run_migration() {
		if ( \Academy\Options::get( \Academy\Options::PRO_MIGRATIONS, 'notifications_booking_cancel_reschedule' ) ) {
			return;
		}

		$saved_data = Admin\Settings::get_saved_data();
		// Nothing saved yet at all — the normal save flow (which already
		// includes these new keys via get_default_data()) will populate the
		// option instead.
		if ( count( $saved_data ) ) {
			$default_data = Admin\Settings::get_default_data();
			foreach ( array(
				'is_enabled_tutor_booking_cancelled_push',
				'is_enabled_tutor_booking_cancelled_onsite',
				'is_enabled_tutor_booking_rescheduled_push',
				'is_enabled_tutor_booking_rescheduled_onsite',
			) as $key ) {
				if ( ! array_key_exists( $key, $saved_data ) ) {
					$saved_data[ $key ] = $default_data[ $key ];
				}
			}
			update_option( ACADEMY_PRO_NOTIFICATIONS_SETTINGS_NAME, wp_json_encode( $saved_data ) );
		}
		\Academy\Options::set( \Academy\Options::PRO_MIGRATIONS, 'notifications_booking_cancel_reschedule', true );
	}

	public function addon_activation_hook() {
		Installer::init();
		\Academy\Helper::flush_rewrite_rules();
		Tick::schedule();
	}

	public function addon_deactivation_hook() {
		\Academy\Helper::flush_rewrite_rules();
		Tick::unschedule();
	}
}
