<?php
namespace AcademyProNotifications\Database;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CreateNotificationsTable {
	public static function create_notifications_table( $prefix, $charset_collate ) {
		$table_name = $prefix . ACADEMY_PLUGIN_SLUG . '_notifications';
		$sql = "CREATE TABLE $table_name (
			ID bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			title tinytext,
			content text,
			`status` enum('READ','UNREAD'),
			receiver_id bigint(20) unsigned,
			post_id bigint(20) unsigned NULL,
			topic_id bigint(20) unsigned NULL,
			`type` varchar(255) NULL,
			created_at datetime,
			PRIMARY KEY (ID)
		) $charset_collate;";
		dbDelta( $sql );
	}
}
