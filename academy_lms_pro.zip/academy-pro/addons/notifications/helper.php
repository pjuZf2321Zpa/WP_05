<?php
namespace AcademyProNotifications;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
/**
 * Notification
 * insert or update notification details
 */
class Helper {

	public static function insert_notification_details( $args ) {
		if ( ! is_array( $args ) ) {
			return false;
		}

		global $wpdb;

		$defaults = array(
			'title' => '',
			'content' => '',
			'status'  => 'UNREAD',
			'receiver_id' => 0,
			'post_id'  => 0,
			'topic_id' => 0,
			'type' => '',
			'created_at' => current_time( 'mysql' ),
		);

		$args = wp_parse_args( $args, $defaults );

		$table_name = $wpdb->prefix . 'academy_notifications';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		return $wpdb->insert(
			$table_name,
			array(
				'title'       => $args['title'],
				'content'     => $args['content'],
				'status'      => $args['status'],
				'receiver_id' => $args['receiver_id'],
				'post_id'     => $args['post_id'],
				'topic_id'    => $args['topic_id'],
				'type'        => $args['type'],
				'created_at'  => $args['created_at'],
			),
			array(
				'%s',
				'%s',
				'%s',
				'%d',
				'%d',
				'%d',
				'%s',
				'%s',
			)
		);
	}

	public static function get_all_notifications_by_user_id( $user_id ) {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$notifications = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}academy_notifications
				WHERE receiver_id = %d ORDER BY created_at DESC",
				$user_id
			),
			OBJECT
		);

		foreach ( $notifications as $notification ) {
			switch ( $notification->type ) {
				case 'user-dashboard':
					$notification->topic_url = \Academy\Helper::get_page_permalink( 'frontend_dashboard_page' );
					break;
				case 'academy_courses':
					$notification->topic_url = get_permalink( $notification->post_id );
					break;
				case 'instructor-approval-request':
					$notification->topic_url = admin_url( 'admin.php?page=academy-instructors' );
					break;
				case 'student-registration':
					$notification->topic_url = admin_url( 'admin.php?page=academy-students' );
					break;
				case 'academy_quizzes':
					$notification->topic_url = esc_url( \Academy\Helper::get_frontend_dashboard_endpoint_url( 'quizzes/attempts/' ) );
					break;
				case 'evaluate_quiz':
					$notification->topic_url = esc_url( \Academy\Helper::get_start_course_permalink( $notification->post_id ) ) . '#/quiz/' . $notification->topic_id;
					if ( \Academy\Helper::is_server_learn_page() ) {
						$topic = [
							'type' => 'quiz',
							'slug' => get_post_field( 'post_name', $notification->topic_id )
						];
						$notification->topic_url = \Academy\Helper::get_topic_play_link( $topic, $notification->post_id );
					}
					break;
				case 'academy_pro_assignments':
					$notification->topic_url = esc_url( \Academy\Helper::get_frontend_dashboard_endpoint_url( 'assignments/submitted-assignments/' ) );
					break;
				case 'evaluate_assignments':
					$notification->topic_url = esc_url( \Academy\Helper::get_start_course_permalink( $notification->post_id ) ) . '#/assignment/' . $notification->topic_id;
					if ( \Academy\Helper::is_server_learn_page() ) {
						$topic = [
							'type' => 'assignment',
							'slug' => get_post_field( 'post_name', $notification->topic_id )
						];
						$notification->topic_url = \Academy\Helper::get_topic_play_link( $topic, $notification->post_id );
					}
					break;
				case 'question_answer_submit':
					$notification->topic_url = esc_url( \Academy\Helper::get_frontend_dashboard_endpoint_url( 'question-answer' ) );
					break;
				case 'question_answer_reply':
				case 'announcement_publish':
					$notification->topic_url = esc_url( \Academy\Helper::get_start_course_permalink( $notification->post_id ) );
					break;
				case 'withdraw-request':
					$notification->topic_url = esc_url( \Academy\Helper::get_frontend_dashboard_endpoint_url( 'withdrawal' ) );
					break;
				case 'meeting_tutor_booking':
					$notification->topic_url = esc_url( \Academy\Helper::get_frontend_dashboard_endpoint_url( 'tutor-booking' ) );
			}//end switch
		}//end foreach
		return $notifications;
	}

	public static function mark_as_read( $id ) {
		global $wpdb;

		$table = $wpdb->prefix . 'academy_notifications';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		return $wpdb->update(
			$table,
			array(
				'status' => 'READ'
			),
			array(
				'ID'          => $id,
				'receiver_id' => get_current_user_id()
			),
			array(
				'%s'
			),
			array(
				'%d',
				'%d'
			)
		);
	}

	public static function mark_as_unread( $id ) {
		global $wpdb;

		$table = $wpdb->prefix . 'academy_notifications';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		return $wpdb->update(
			$table,
			array(
				'status' => 'UNREAD'
			),
			array(
				'ID'          => $id,
				'receiver_id' => get_current_user_id()
			),
			array(
				'%s'
			),
			array(
				'%d',
				'%d'
			)
		);
	}

	public static function delete_notification( $ID ) {
		global $wpdb;
		// Scope to the current user so a caller cannot delete another user's
		// notification by passing an arbitrary (enumerable) primary-key ID.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		return $wpdb->delete(
			$wpdb->prefix . 'academy_notifications',
			array(
				'ID'          => $ID,
				'receiver_id' => get_current_user_id()
			),
			array( '%d', '%d' )
		);
	}

	public static function get_students_ids_by_course_id( $course_id ): array {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT post_author FROM {$wpdb->posts} WHERE post_parent = %d",
				$course_id
			),
			OBJECT
		);
	}

	public static function get_setting( $setting_name ): bool {
		$settings = Admin\Settings::get_saved_data();
		if ( array_key_exists( $setting_name, $settings ) ) {
			return $settings[ $setting_name ];
		}

		return false;
	}

	public static function get_instructors( $course_id ) {
		$instructors_data = \Academy\Helper::get_instructors_by_course_id( $course_id );
		$instructors = [];
		if ( ! empty( $instructors_data ) ) {
			foreach ( $instructors_data as $instructor ) {
				$instructors[] = $instructor->ID;
			}
		}
		return $instructors;
	}

	/**
	 * Who hears about activity on a course: its instructors, plus the course
	 * author. A course an administrator wrote has no instructor record, so it
	 * used to have nobody to notify and the notification was silently dropped.
	 *
	 * @param int $course_id Course ID.
	 * @return array Objects with ID and display_name.
	 */
	public static function get_course_receivers( $course_id ) {
		$receivers = \Academy\Helper::get_instructors_by_course_id( $course_id );
		$known_ids = array_map( fn( $receiver ) => (int) $receiver->ID, $receivers );
		$author_id = (int) get_post_field( 'post_author', $course_id );
		$author    = $author_id && ! in_array( $author_id, $known_ids, true ) ? get_userdata( $author_id ) : false;
		if ( $author ) {
			$receivers[] = (object) array(
				'ID'           => (int) $author->ID,
				'display_name' => $author->display_name,
			);
		}
		return $receivers;
	}

	public static function is_enrollment_completed( int $course_id, int $user_id ): bool {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		return intval($wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*)
					 FROM {$wpdb->posts} 
					 	WHERE 
							post_type = %s AND
							post_status = %s AND 
							post_author = %d AND 
							post_parent = %d
				",
				'academy_enrolled',
				'completed',
				$user_id,
				$course_id,
			)
		)) > 0;
	}

	public static function is_duplicate( int $course_id, int $user_id ): bool {
		global $wpdb;
		$table = esc_sql( $wpdb->prefix . ACADEMY_PLUGIN_SLUG . '_notifications' );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$query = $wpdb->prepare(
			"SELECT COUNT(*) FROM {$table} WHERE type = %s AND status = %s AND receiver_id = %d	AND post_id = %d", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			'academy_courses',
			'UNREAD',
			$user_id,
			$course_id
		);

		return ( $wpdb->get_var( $query ) > 0 );// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	}

	// --- Meeting/booking reminder idempotency flags -------------------------
	// `academy_meeting` and `academy_booked` posts are one-off occurrences (a
	// new post per actual meeting/booked slot), so a simple boolean flag with
	// no reset logic is sufficient — see Meeting\Tick's docblock for why this
	// is required at all (a sweep re-checking "is this due" would otherwise
	// re-fire every run for as long as the occurrence matches the window).
	const META_MEETING_REMINDER_NOTIFIED = '_academy_meeting_reminder_notified';
	const META_MEETING_STARTED_NOTIFIED  = '_academy_meeting_started_notified';
	const META_BOOKED_REMINDER_NOTIFIED  = '_academy_booked_reminder_notified';
	const META_BOOKED_STARTED_NOTIFIED   = '_academy_booked_started_notified';

	public static function is_reminder_notified( string $source_type, int $source_id ): bool {
		$meta_key = 'meeting' === $source_type ? self::META_MEETING_REMINDER_NOTIFIED : self::META_BOOKED_REMINDER_NOTIFIED;
		return (bool) get_post_meta( $source_id, $meta_key, true );
	}

	public static function mark_reminder_notified( string $source_type, int $source_id ): void {
		$meta_key = 'meeting' === $source_type ? self::META_MEETING_REMINDER_NOTIFIED : self::META_BOOKED_REMINDER_NOTIFIED;
		update_post_meta( $source_id, $meta_key, 1 );
	}

	public static function is_started_notified( string $source_type, int $source_id ): bool {
		$meta_key = 'meeting' === $source_type ? self::META_MEETING_STARTED_NOTIFIED : self::META_BOOKED_STARTED_NOTIFIED;
		return (bool) get_post_meta( $source_id, $meta_key, true );
	}

	public static function mark_started_notified( string $source_type, int $source_id ): void {
		$meta_key = 'meeting' === $source_type ? self::META_MEETING_STARTED_NOTIFIED : self::META_BOOKED_STARTED_NOTIFIED;
		update_post_meta( $source_id, $meta_key, 1 );
	}

	/**
	 * All students enrolled in a course, as plain ints. Reuses
	 * `get_students_ids_by_course_id()` above rather than a third copy of the
	 * same query.
	 *
	 * @param int $course_id
	 *
	 * @return int[]
	 */
	public static function get_enrolled_student_ids( int $course_id ): array {
		$rows = self::get_students_ids_by_course_id( $course_id );
		return array_values( array_unique( array_map( fn( $row ) => (int) $row->post_author, $rows ) ) );
	}
}
