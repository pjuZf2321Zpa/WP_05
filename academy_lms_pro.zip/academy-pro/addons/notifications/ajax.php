<?php
namespace AcademyProNotifications;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AcademyProNotifications\Ajax\Settings;


class Ajax {
	public static function init() {

		$self = new self();
		$self->dispatch_hooks();
		Frontend\Ajax::init();
	}
	public function dispatch_hooks() {
		( new Settings() )->dispatch_actions();
	}
}
