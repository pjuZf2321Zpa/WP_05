<?php
namespace AcademyProNotifications\Meeting;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Academy\Classes\AbstractAjaxHandler;

/**
 * Serves `CoursesTable.js`'s "Live Now" course-list indicator (used on both
 * the backend admin Courses page and the frontend-dashboard instructor
 * Courses page — they render the same component). No viewer-scoping is
 * needed here: `CoursesTable.js`'s own row set is already filtered to
 * "courses this viewer can see" by its existing REST query, so
 * cross-referencing the full live-ID list against those rows naturally only
 * lights up courses the viewer already has.
 */
class Ajax extends AbstractAjaxHandler {
	protected $namespace = 'academy_pro_notifications_meeting';

	public function __construct() {
		$this->actions = array(
			'get_live_course_ids' => array(
				'callback'   => array( $this, 'get_live_course_ids' ),
				'capability' => 'manage_academy_instructor',
			),
		);
	}

	public static function init() {
		$self = new self();
		$self->dispatch_actions();
	}

	public function get_live_course_ids() {
		wp_send_json_success( Resolver::get_live_course_ids() );
	}
}
