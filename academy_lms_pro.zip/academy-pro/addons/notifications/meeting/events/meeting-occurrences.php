<?php
namespace AcademyProNotifications\Meeting\Events;

use AcademyProNotifications\Helper;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Resolves standalone (course-curriculum) Zoom/Google Meet `academy_meeting`
 * occurrences, site-wide — i.e. NOT scoped to the current user. Modeled on
 * `AcademyProCalendar\Events\Mettings\MeetingData`/`Meet`/`Zoom`, but those
 * three hardcode `get_current_user_id()` into their JOIN/WHERE (they answer
 * "what's upcoming for me" for a logged-in dashboard request); this class
 * answers "what's due for anyone, right now" for the cron sweep, so the
 * current-user scoping is dropped and no year/month bucketing is needed.
 */
class MeetingOccurrences {

	/**
	 * Every `academy_meeting` post ID referenced as a "meeting" topic in any
	 * published course's curriculum, mapped to its owning course ID. Same
	 * JSON-scan approach as `MeetingData::get()`.
	 *
	 * @return array<int,int> meeting_post_id => course_id
	 */
	private static function get_meeting_course_map(): array {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.SlowDBQuery.slow_db_query_meta_value
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT pm.post_id, pm.meta_value
				FROM {$wpdb->postmeta} pm
				INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
				WHERE pm.meta_key = %s
					AND pm.meta_value LIKE %s
					AND p.post_type = %s
					AND p.post_status = %s",
				'academy_course_curriculum',
				'%"type";s:7:"meeting"%',
				'academy_courses',
				'publish'
			)
		);

		$map = [];
		foreach ( $rows as $row ) {
			foreach ( maybe_unserialize( $row->meta_value ) ?? [] as $curriculum ) {
				foreach ( $curriculum['topics'] ?? [] as $topic ) {
					if ( 'meeting' === ( $topic['type'] ?? '' ) && ! empty( $topic['id'] ?? '' ) ) {
						$map[ (int) $topic['id'] ] = (int) $row->post_id;
					}
				}
			}
		}
		return $map;
	}

	/**
	 * All not-yet-fully-processed meeting occurrences (i.e. still missing
	 * either the reminder or the started flag), normalized regardless of
	 * provider. Callers decide what "due" means from `start_time`.
	 *
	 * @return array<int,array{id:int,course_id:int,instructor_id:int,title:string,start_time:\DateTime,join_info:string,provider:string}>
	 */
	public static function get_pending(): array {
		$meeting_course_map = self::get_meeting_course_map();
		if ( empty( $meeting_course_map ) ) {
			return [];
		}
		$ids = array_keys( $meeting_course_map );

		global $wpdb;
		$placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- only $wpdb-prefixed table names, whitelisted columns and intval/placeholder lists are interpolated; values are prepared
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT p.ID, p.post_title, p.post_author, p.post_status,
					mt.meta_value AS meeting_type,
					mr.meta_value AS meeting_response,
					COALESCE(rm.meta_value, '') AS reminder_notified,
					COALESCE(sm.meta_value, '') AS started_notified
				FROM {$wpdb->posts} p
				INNER JOIN {$wpdb->postmeta} mt ON mt.post_id = p.ID AND mt.meta_key = 'academy_meeting_type'
				INNER JOIN {$wpdb->postmeta} mr ON mr.post_id = p.ID AND mr.meta_key = 'academy_meeting_response'
				LEFT JOIN {$wpdb->postmeta} rm ON rm.post_id = p.ID AND rm.meta_key = %s
				LEFT JOIN {$wpdb->postmeta} sm ON sm.post_id = p.ID AND sm.meta_key = %s
				WHERE p.ID IN ({$placeholders})
					AND ( COALESCE(rm.meta_value, '') = '' OR COALESCE(sm.meta_value, '') = '' )", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				array_merge(
					[ Helper::META_MEETING_REMINDER_NOTIFIED, Helper::META_MEETING_STARTED_NOTIFIED ],
					$ids
				)
			)
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber

		$occurrences = [];
		foreach ( $rows as $row ) {
			$response = json_decode( $row->meeting_response, true );
			if ( ! is_array( $response ) ) {
				continue;
			}

			$is_google = 'google_meet' === $row->meeting_type;
			$start_raw = $is_google ? ( $response['meetingDate'] ?? '' ) : ( $response['start_time'] ?? '' );
			$join_url  = $is_google ? ( $response['meetingLink'] ?? '' ) : ( $response['join_url'] ?? '' );

			if ( empty( $start_raw ) ) {
				continue;
			}

			try {
				// Matches AcademyProMeeting\Integration\Common::render_meeting():
				// the ISO string carries its own offset/Z when present, so the
				// explicit UTC only applies when the string has none.
				$start_time = new \DateTime( $start_raw, new \DateTimeZone( 'UTC' ) );
			} catch ( \Exception $e ) {
				continue;
			}

			$occurrences[] = [
				'id'            => (int) $row->ID,
				'course_id'     => $meeting_course_map[ (int) $row->ID ] ?? 0,
				'instructor_id' => (int) $row->post_author,
				'title'         => html_entity_decode( $row->post_title ),
				'start_time'    => $start_time,
				'join_info'     => $join_url ? esc_url_raw( $join_url ) : '',
				'provider'      => $is_google ? 'google_meet' : 'zoom',
				'already_reminded' => ! empty( $row->reminder_notified ),
				'already_started'  => ! empty( $row->started_notified ),
			];
		}//end foreach
		return $occurrences;
	}

	/**
	 * Meeting occurrences currently in progress (`start_time <= now <=
	 * end_time`) — a different question from `get_pending()`'s "still needs a
	 * reminder/started event fired," so it deliberately doesn't filter by
	 * those flags: a meeting can be fully notified and still be live, or
	 * live without ever having been notified yet.
	 *
	 * @return array<int,array{id:int,course_id:int,instructor_id:int,title:string,start_time:\DateTime,end_time:\DateTime,join_info:string,provider:string}>
	 */
	public static function get_live_now(): array {
		$meeting_course_map = self::get_meeting_course_map();
		if ( empty( $meeting_course_map ) ) {
			return [];
		}
		$ids = array_keys( $meeting_course_map );

		global $wpdb;
		$placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- placeholders are generated to match the values
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT p.ID, p.post_title, p.post_author,
					mt.meta_value AS meeting_type,
					mr.meta_value AS meeting_response
				FROM {$wpdb->posts} p
				INNER JOIN {$wpdb->postmeta} mt ON mt.post_id = p.ID AND mt.meta_key = 'academy_meeting_type'
				INNER JOIN {$wpdb->postmeta} mr ON mr.post_id = p.ID AND mr.meta_key = 'academy_meeting_response'
				WHERE p.ID IN ({$placeholders})", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$ids
			)
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber

		$now = new \DateTime( 'now', new \DateTimeZone( 'UTC' ) );
		$occurrences = [];
		foreach ( $rows as $row ) {
			$response = json_decode( $row->meeting_response, true );
			if ( ! is_array( $response ) ) {
				continue;
			}

			$is_google = 'google_meet' === $row->meeting_type;
			$start_raw = $is_google ? ( $response['meetingDate'] ?? '' ) : ( $response['start_time'] ?? '' );
			$join_url  = $is_google ? ( $response['meetingLink'] ?? '' ) : ( $response['join_url'] ?? '' );

			if ( empty( $start_raw ) ) {
				continue;
			}

			try {
				$start_time = new \DateTime( $start_raw, new \DateTimeZone( 'UTC' ) );
				if ( $is_google ) {
					// `meetingDuration` is misleadingly named — for Google
					// Meet it's already the end dateTime, not a duration
					// count (see AcademyProMeeting\Integration\GoogleMeet).
					$end_raw  = $response['meetingDuration'] ?? '';
					$end_time = $end_raw ? new \DateTime( $end_raw, new \DateTimeZone( 'UTC' ) ) : ( clone $start_time );
				} else {
					$duration_minutes = (int) ( $response['duration'] ?? 0 );
					$end_time = ( clone $start_time )->modify( '+' . $duration_minutes . ' minutes' );
				}
			} catch ( \Exception $e ) {
				continue;
			}

			if ( $now < $start_time || $now > $end_time ) {
				continue;
			}

			$occurrences[] = [
				'id'            => (int) $row->ID,
				'course_id'     => $meeting_course_map[ (int) $row->ID ] ?? 0,
				'instructor_id' => (int) $row->post_author,
				'title'         => html_entity_decode( $row->post_title ),
				'start_time'    => $start_time,
				'end_time'      => $end_time,
				'join_info'     => $join_url ? esc_url_raw( $join_url ) : '',
				'provider'      => $is_google ? 'google_meet' : 'zoom',
			];
		}//end foreach
		return $occurrences;
	}
}
