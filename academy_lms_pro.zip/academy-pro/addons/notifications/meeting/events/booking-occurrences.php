<?php
namespace AcademyProNotifications\Meeting\Events;

use AcademyProNotifications\Helper;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Resolves confirmed Tutor Booking occurrences (`academy_booked` posts),
 * site-wide. Modeled on `AcademyProCalendar\Events\Booking\Tutor`, which
 * hardcodes `b.post_author = get_current_user_id()` (it answers "what's
 * upcoming for me"); that scoping is dropped here since the cron sweep needs
 * every confirmed booking regardless of who booked it.
 *
 * `academy_booked` is never `register_post_type()`-ed in this codebase (a
 * pre-existing quirk, not something to fix here) — it's queried the same way
 * the rest of the codebase already does, via raw SQL / explicit post_type
 * args, not `get_posts()` with type-registration assumptions.
 */
class BookingOccurrences {

	/**
	 * Every `academy_booking` post ID embedded as a "booking" topic in any
	 * published course's curriculum, mapped to its owning course ID. A
	 * booking is usually course-independent (its own standalone listing),
	 * but the curriculum builder also lets a course embed one directly —
	 * same JSON/serialize-scan approach as
	 * `MeetingOccurrences::get_meeting_course_map()`, just for `type=booking`
	 * topics instead of `type=meeting`.
	 *
	 * @return array<int,int> booking_post_id => course_id
	 */
	private static function get_booking_course_map(): array {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.SlowDBQuery.slow_db_query_meta_value
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT pm.post_id, pm.meta_value
				FROM {$wpdb->postmeta} pm
				INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
				WHERE pm.meta_key = %s
					AND pm.meta_value LIKE %s
					AND p.post_type = %s
					AND p.post_status = %s",
				'academy_course_curriculum',
				'%"type";s:7:"booking"%',
				'academy_courses',
				'publish'
			)
		);

		$map = [];
		foreach ( $rows as $row ) {
			foreach ( maybe_unserialize( $row->meta_value ) ?? [] as $curriculum ) {
				foreach ( $curriculum['topics'] ?? [] as $topic ) {
					if ( 'booking' === ( $topic['type'] ?? '' ) && ! empty( $topic['id'] ?? '' ) ) {
						$map[ (int) $topic['id'] ] = (int) $row->post_id;
					}
				}
			}
		}
		return $map;
	}

	/**
	 * @return array<int,array{id:int,booking_id:int,course_id:int|null,instructor_id:int,student_ids:int[],title:string,start_time:\DateTime,join_info:string,provider:string}>
	 */
	public static function get_pending(): array {
		global $wpdb;
		$booking_course_map = self::get_booking_course_map();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT b.ID AS booked_id, b.post_parent AS booking_id, b.post_author AS student_id,
					p.post_title AS title, p.post_author AS instructor_id,
					m.meta_value AS schedule_raw,
					COALESCE(rm.meta_value, '') AS reminder_notified,
					COALESCE(sm.meta_value, '') AS started_notified
				FROM {$wpdb->posts} b
				INNER JOIN {$wpdb->posts} p ON p.ID = b.post_parent AND p.post_type = %s
				INNER JOIN {$wpdb->postmeta} m ON m.post_id = b.ID AND m.meta_key = %s
				LEFT JOIN {$wpdb->postmeta} rm ON rm.post_id = b.ID AND rm.meta_key = %s
				LEFT JOIN {$wpdb->postmeta} sm ON sm.post_id = b.ID AND sm.meta_key = %s
				WHERE b.post_type = %s
					AND b.post_status = %s
					AND ( COALESCE(rm.meta_value, '') = '' OR COALESCE(sm.meta_value, '') = '' )",
				'academy_booking',
				'_academy_booked_schedule_time',
				Helper::META_BOOKED_REMINDER_NOTIFIED,
				Helper::META_BOOKED_STARTED_NOTIFIED,
				'academy_booked',
				'completed'
			)
		);

		$occurrences = [];
		foreach ( $rows as $row ) {
			$start_time = \AcademyProTutorBooking\Helper::parse_booked_schedule_datetime( (string) $row->schedule_raw );
			if ( ! $start_time ) {
				continue;
			}

			$occurrences[] = [
				'id'                => (int) $row->booked_id,
				'booking_id'        => (int) $row->booking_id,
				'course_id'         => $booking_course_map[ (int) $row->booking_id ] ?? null,
				'instructor_id'     => (int) $row->instructor_id,
				'student_ids'       => [ (int) $row->student_id ],
				'title'             => html_entity_decode( $row->title ),
				'start_time'        => $start_time,
				'join_info'         => \AcademyProTutorBooking\Helper::resolve_booked_join_info( (int) $row->booked_id ),
				'provider'          => (string) get_post_meta( (int) $row->booked_id, '_academy_booked_meeting_provider', true ),
				'already_reminded'  => ! empty( $row->reminder_notified ),
				'already_started'   => ! empty( $row->started_notified ),
			];
		}
		return $occurrences;
	}

	/**
	 * Booking occurrences currently in progress (`start_time <= now <=
	 * end_time`) — see `MeetingOccurrences::get_live_now()`'s docblock for
	 * why this doesn't reuse/filter by the reminder/started flags.
	 *
	 * @return array<int,array{id:int,booking_id:int,course_id:int|null,instructor_id:int,student_ids:int[],title:string,start_time:\DateTime,end_time:\DateTime,join_info:string,provider:string}>
	 */
	public static function get_live_now(): array {
		global $wpdb;
		$booking_course_map = self::get_booking_course_map();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT b.ID AS booked_id, b.post_parent AS booking_id, b.post_author AS student_id,
					p.post_title AS title, p.post_author AS instructor_id,
					m.meta_value AS schedule_raw,
					COALESCE(bd.meta_value, '') AS duration_minutes
				FROM {$wpdb->posts} b
				INNER JOIN {$wpdb->posts} p ON p.ID = b.post_parent AND p.post_type = %s
				INNER JOIN {$wpdb->postmeta} m ON m.post_id = b.ID AND m.meta_key = %s
				LEFT JOIN {$wpdb->postmeta} bd ON bd.post_id = p.ID AND bd.meta_key = %s
				WHERE b.post_type = %s
					AND b.post_status = %s",
				'academy_booking',
				'_academy_booked_schedule_time',
				'_academy_booking_duration',
				'academy_booked',
				'completed'
			)
		);

		$now = new \DateTime( 'now', new \DateTimeZone( 'UTC' ) );
		$occurrences = [];
		foreach ( $rows as $row ) {
			$start_time = \AcademyProTutorBooking\Helper::parse_booked_schedule_datetime( (string) $row->schedule_raw );
			if ( ! $start_time ) {
				continue;
			}

			$duration_minutes = (int) $row->duration_minutes;
			$duration_minutes = $duration_minutes > 0 ? $duration_minutes : 30;
			$end_time = ( clone $start_time )->modify( '+' . $duration_minutes . ' minutes' );

			if ( $now < $start_time || $now > $end_time ) {
				continue;
			}

			$occurrences[] = [
				'id'                => (int) $row->booked_id,
				'booking_id'        => (int) $row->booking_id,
				'course_id'         => $booking_course_map[ (int) $row->booking_id ] ?? null,
				'instructor_id'     => (int) $row->instructor_id,
				'student_ids'       => [ (int) $row->student_id ],
				'title'             => html_entity_decode( $row->title ),
				'start_time'        => $start_time,
				'end_time'          => $end_time,
				'join_info'         => \AcademyProTutorBooking\Helper::resolve_booked_join_info( (int) $row->booked_id ),
				'provider'          => (string) get_post_meta( (int) $row->booked_id, '_academy_booked_meeting_provider', true ),
			];
		}//end foreach
		return $occurrences;
	}
}
