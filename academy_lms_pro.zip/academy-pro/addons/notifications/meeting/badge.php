<?php
namespace AcademyProNotifications\Meeting;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Prints a "Live Now" badge on a course's archive/catalog card when it has a
 * currently-running meeting. Hooks the free plugin's existing (previously
 * unused) `academy/templates/after_course_loop_header_inner` action —
 * `templates/loop/header.php` fires this on every card style, so no
 * free-plugin edit is needed.
 */
class Badge {

	/** @var int[]|null Per-request cache — the hook fires once per card. */
	private static $live_course_ids = null;

	/** @var bool Guard so the badge's inline CSS is only printed once. */
	private static $styles_printed = false;

	public static function init(): void {
		add_action( 'academy/templates/after_course_loop_header_inner', array( __CLASS__, 'render' ) );
	}

	public static function render(): void {
		if ( null === self::$live_course_ids ) {
			self::$live_course_ids = Resolver::get_live_course_ids();
		}
		if ( empty( self::$live_course_ids ) ) {
			return;
		}

		$course_id = get_the_ID();
		if ( ! $course_id || ! in_array( (int) $course_id, self::$live_course_ids, true ) ) {
			return;
		}

		if ( ! self::$styles_printed ) {
			self::$styles_printed = true;
			// Inline (not the Pro frontend.css bundle) because that bundle
			// is only enqueued for logged-in users (see
			// academy-pro/includes/assets.php: frontend_scripts()), but this
			// badge must render on the public archive for guests too.
			// Positioned bottom-left, deliberately NOT reusing
			// `.academy-course-header-meta` (top-left anchor for the
			// wishlist heart, which escapes to top-right via negative
			// offsets — see _courses.scss) to avoid colliding with it.
			echo '<style>
				.academy-course__live-badge {
					position: absolute;
					bottom: 12px;
					left: 12px;
					z-index: 10;
					background: #e53935;
					color: #fff;
					font-size: 11px;
					font-weight: 600;
					line-height: 1;
					padding: 4px 8px;
					border-radius: 3px;
					text-transform: uppercase;
					letter-spacing: 0.3px;
				}
			</style>';
		}//end if

		echo '<div class="academy-course__live-badge">' . esc_html__( 'Live Now', 'academy-pro' ) . '</div>';
	}
}
