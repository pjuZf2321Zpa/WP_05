<?php
namespace AcademyProNotifications\Meeting;

use AcademyProNotifications\Helper;
use AcademyProNotifications\Meeting\Events\MeetingOccurrences;
use AcademyProNotifications\Meeting\Events\BookingOccurrences;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Turns the raw occurrence rows from `Events\MeetingOccurrences` /
 * `Events\BookingOccurrences` into the normalized context array both the
 * cron sweep (Tick) and the dashboard "upcoming meetings" widget consume.
 */
class Resolver {

	/**
	 * @param int $lead_minutes
	 *
	 * @return array{reminders:array,started:array} Each entry is a normalized
	 *         context array ready to pass to the `reminder_due`/`started`
	 *         domain events, plus an internal `_backlog` flag (see Tick).
	 */
	public static function get_due( int $lead_minutes ): array {
		$now       = new \DateTime( 'now', new \DateTimeZone( 'UTC' ) );
		$reminders = [];
		$started   = [];

		foreach ( self::all_pending_normalized() as $occurrence ) {
			$seconds_to_start = $occurrence['start_time'] - $now->getTimestamp();
			$is_backlog       = $seconds_to_start < -DAY_IN_SECONDS;

			if ( $is_backlog ) {
				// Cron was down / addon just activated with old data — don't
				// fire a storm of stale notifications, just silence them.
				$occurrence['_backlog'] = true;
				if ( ! $occurrence['already_reminded'] ) {
					$reminders[] = $occurrence;
				}
				if ( ! $occurrence['already_started'] ) {
					$started[] = $occurrence;
				}
				continue;
			}

			if ( ! $occurrence['already_reminded'] && $seconds_to_start <= ( $lead_minutes * MINUTE_IN_SECONDS ) ) {
				$reminders[] = $occurrence;
			}
			if ( ! $occurrence['already_started'] && $seconds_to_start <= 0 ) {
				$started[] = $occurrence;
			}
		}//end foreach

		return [
			'reminders' => $reminders,
			'started' => $started
		];
	}

	/**
	 * @return array Normalized context rows (unix timestamp `start_time`),
	 *         regardless of source, for both the sweep and the widget.
	 */
	private static function all_pending_normalized(): array {
		$out = [];

		foreach ( MeetingOccurrences::get_pending() as $m ) {
			$course_id   = (int) $m['course_id'];
			$student_ids = $course_id ? Helper::get_enrolled_student_ids( $course_id ) : [];
			$out[] = [
				'source_type'      => 'meeting',
				'source_id'        => $m['id'],
				'title'            => $m['title'],
				'start_time'       => $m['start_time']->getTimestamp(),
				'join_info'        => $m['join_info'],
				'provider'         => $m['provider'],
				'course_id'        => $course_id ? $course_id : null,
				'instructor_id'    => $m['instructor_id'],
				'student_ids'      => $student_ids,
				'already_reminded' => $m['already_reminded'],
				'already_started'  => $m['already_started'],
			];
		}

		foreach ( BookingOccurrences::get_pending() as $b ) {
			$out[] = [
				'source_type'      => 'tutor_booking',
				'source_id'        => $b['id'],
				'title'            => $b['title'],
				'start_time'       => $b['start_time']->getTimestamp(),
				'join_info'        => $b['join_info'],
				'provider'         => $b['provider'],
				'course_id'        => $b['course_id'],
				'instructor_id'    => $b['instructor_id'],
				'student_ids'      => $b['student_ids'],
				'already_reminded' => $b['already_reminded'],
				'already_started'  => $b['already_started'],
			];
		}

		return $out;
	}

	/**
	 * Upcoming (future, not-yet-started) meeting occurrences for the
	 * dashboard widget. `$instructor_id = 0` means unscoped (admin view).
	 *
	 * @param int $instructor_id
	 * @param int $days
	 * @param int $student_id
	 */
	public static function get_upcoming_meetings( int $instructor_id = 0, int $days = 30, int $student_id = 0 ): array {
		return self::filter_upcoming(
			array_filter( self::all_pending_normalized(), fn( $o ) => 'meeting' === $o['source_type'] ),
			$instructor_id,
			$days,
			$student_id
		);
	}

	public static function get_upcoming_bookings( int $instructor_id = 0, int $days = 30, int $student_id = 0 ): array {
		return self::filter_upcoming(
			array_filter( self::all_pending_normalized(), fn( $o ) => 'tutor_booking' === $o['source_type'] ),
			$instructor_id,
			$days,
			$student_id
		);
	}

	private static function filter_upcoming( array $occurrences, int $instructor_id, int $days, int $student_id = 0 ): array {
		$now     = time();
		$horizon = $now + ( $days * DAY_IN_SECONDS );

		return array_values( array_filter( $occurrences, function ( $o ) use ( $now, $horizon, $instructor_id, $student_id ) {
			if ( $o['start_time'] < $now || $o['start_time'] > $horizon ) {
				return false;
			}
			if ( $instructor_id && (int) $o['instructor_id'] !== $instructor_id ) {
				return false;
			}
			if ( $student_id && ! in_array( $student_id, $o['student_ids'], true ) ) {
				return false;
			}
			return true;
		} ) );
	}

	/**
	 * Occurrences currently in progress, regardless of source — for the
	 * "Live Now" course badge and the Overview widgets/cards. Unlike
	 * `get_due()`/`all_pending_normalized()`, this is notification-flag
	 * agnostic (a fully-notified meeting can still be live).
	 *
	 * @return array Normalized rows, same shape as `all_pending_normalized()`
	 *         entries but with `end_time` (unix timestamp) instead of the
	 *         `already_reminded`/`already_started` flags.
	 */
	public static function get_live_now(): array {
		$out = [];

		foreach ( MeetingOccurrences::get_live_now() as $m ) {
			$course_id   = (int) $m['course_id'];
			$student_ids = $course_id ? Helper::get_enrolled_student_ids( $course_id ) : [];
			$out[] = [
				'source_type'   => 'meeting',
				'source_id'     => $m['id'],
				'title'         => $m['title'],
				'start_time'    => $m['start_time']->getTimestamp(),
				'end_time'      => $m['end_time']->getTimestamp(),
				'join_info'     => $m['join_info'],
				'provider'      => $m['provider'],
				'course_id'     => $course_id ? $course_id : null,
				'instructor_id' => $m['instructor_id'],
				'student_ids'   => $student_ids,
			];
		}

		foreach ( BookingOccurrences::get_live_now() as $b ) {
			$out[] = [
				'source_type'   => 'tutor_booking',
				'source_id'     => $b['id'],
				'title'         => $b['title'],
				'start_time'    => $b['start_time']->getTimestamp(),
				'end_time'      => $b['end_time']->getTimestamp(),
				'join_info'     => $b['join_info'],
				'provider'      => $b['provider'],
				'course_id'     => $b['course_id'],
				'instructor_id' => $b['instructor_id'],
				'student_ids'   => $b['student_ids'],
			];
		}

		return $out;
	}

	/**
	 * Course IDs with a currently-live meeting — used by the archive "Live
	 * Now" badge and the backend/frontend course table indicator. A Tutor
	 * Booking is usually course-independent, but the curriculum builder also
	 * lets a course embed one directly as a "booking" topic (see
	 * `BookingOccurrences::get_booking_course_map()`), so both source types
	 * are included here whenever a `course_id` was actually resolved.
	 *
	 * @return int[]
	 */
	public static function get_live_course_ids(): array {
		$course_ids = array_map(
			fn( $o ) => $o['course_id'],
			array_filter( self::get_live_now(), fn( $o ) => ! empty( $o['course_id'] ) )
		);
		return array_values( array_unique( $course_ids ) );
	}
}
