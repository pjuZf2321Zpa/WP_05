<?php
namespace AcademyProNotifications\Meeting;

use AcademyProNotifications\Helper;
use AcademyProNotifications\Admin\Settings;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Recurring sweep that notices "a meeting/booking is due soon" and "a
 * meeting/booking just started", firing one `do_action()` per occurrence so
 * this same addon's onsite/push listeners (Hooks/Pusher) and the Email
 * addon's listeners can react — mirrors the `wp_schedule_event` + self-heal +
 * activation/deactivation (un)schedule pattern already established by
 * `AcademyProGroupPlus\Expiry`.
 *
 * Lives inside the Notifications addon (rather than a standalone addon) so
 * meeting/booking reminders are available the moment Notifications is
 * enabled — no separate addon toggle to find and turn on. The trade-off:
 * Email's meeting-reminder emails also need Notifications active, since this
 * is what fires the underlying `academy_pro/meeting/*` events Email listens
 * to.
 *
 * Idempotency: a sweep that keeps re-checking "is this due" would re-fire
 * every run for as long as the occurrence stays inside the matched window
 * unless "already notified" is tracked per-record — see Helper's postmeta
 * flags, and the identical gotcha already flagged in group-plus's own
 * `expiry.php`/`notifications.php` docblocks.
 */
class Tick {
	const TICK              = 'academy_pro_notifications/meeting_sweep_tick';
	const CRON_INTERVAL_KEY = 'academy_pro_notifications_meeting_five_minutes';

	public static function init(): void {
		$self = new self();

		add_filter( 'cron_schedules', array( $self, 'register_cron_interval' ) ); // phpcs:ignore WordPress.WP.CronInterval.CronSchedulesInterval
		add_action( self::TICK, array( $self, 'sweep' ) );

		// Self-heal: an install where the addon was already active before
		// this tick shipped never got the activation hook, so make sure the
		// event is scheduled on every load too (wp_schedule_event() is
		// idempotent/cheap when already scheduled, via wp_next_scheduled()).
		self::schedule();
	}

	public function register_cron_interval( array $schedules ): array {
		$schedules[ self::CRON_INTERVAL_KEY ] = array(
			'interval' => 5 * MINUTE_IN_SECONDS,
			'display'  => __( 'Every 5 minutes (Academy Meeting Notifications)', 'academy-pro' ),
		);
		return $schedules;
	}

	public static function schedule(): void {
		if ( ! wp_next_scheduled( self::TICK ) ) {
			wp_schedule_event( time() + 5 * MINUTE_IN_SECONDS, self::CRON_INTERVAL_KEY, self::TICK );
		}
	}

	public static function unschedule(): void {
		$timestamp = wp_next_scheduled( self::TICK );
		if ( $timestamp ) {
			wp_unschedule_event( $timestamp, self::TICK );
		}
	}

	/**
	 * The tick handler: resolve due occurrences, fire one event per
	 * occurrence, then mark it notified so the next run doesn't re-fire.
	 */
	public static function sweep(): void {
		$lead_minutes = Settings::get_reminder_lead_minutes();
		$due          = Resolver::get_due( $lead_minutes );

		foreach ( $due['reminders'] as $context ) {
			if ( empty( $context['_backlog'] ) ) {
				/**
				 * Fires once, `reminder_lead_minutes` before a meeting/booking's
				 * start time (or immediately, if the sweep first noticed it
				 * already inside that window).
				 *
				 * @param array $context Normalized occurrence context — see Resolver.
				 */
				do_action( 'academy_pro/meeting/reminder_due', $context );
			}
			Helper::mark_reminder_notified( $context['source_type'], $context['source_id'] );
		}

		foreach ( $due['started'] as $context ) {
			if ( empty( $context['_backlog'] ) ) {
				/**
				 * Fires once, at/just after a meeting/booking's actual start time.
				 *
				 * @param array $context Normalized occurrence context — see Resolver.
				 */
				do_action( 'academy_pro/meeting/started', $context );
			}
			Helper::mark_started_notified( $context['source_type'], $context['source_id'] );
		}
	}
}
