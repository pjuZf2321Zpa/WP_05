<?php
namespace AcademyProNotifications;

use AcademyProNotifications\Admin\Settings;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Installer {
	public static function init() {
		$self = new self();
		$self->create_database();
		$self->saved_settings();
	}

	public function create_database() {
		Database::create_initial_custom_table();
	}

	public function saved_settings() {
		Settings::save_settings();
	}
}
