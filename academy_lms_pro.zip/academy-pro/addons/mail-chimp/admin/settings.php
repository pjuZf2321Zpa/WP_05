<?php
namespace AcademyProMailChimp\Admin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Settings {
	public static function get_saved_data() {
		$settings = get_option( ACADEMY_PRO_MAILCHIMP_SETTINGS_NAME );
		if ( ! $settings ) {
			return [];
		}
		$decoded = json_decode( $settings, true );
		// A corrupt option (invalid JSON) decodes to null — never let that
		// reach callers that do array access / count() on it.
		return is_array( $decoded ) ? $decoded : [];
	}
	public static function get_default_data() {
		return apply_filters('academy_pro_mailchimp/settings_default_data', [
			'is_enable_force_subscription' => false,
			'api_key'                      => '',
			'subscriber_consent_message'   => '',
			'triggers'                     => [
				'student_registration'    => [
					'enable'      => false,
					'list_id'     => '',
					'group_id'    => '',
					'interest_id' => ''
				],
				'instructor_registration' => [
					'enable'      => false,
					'list_id'     => '',
					'group_id'    => '',
					'interest_id' => ''
				],
				'course_enroll'           => [
					'enable'      => false,
					'list_id'     => '',
					'group_id'    => '',
					'interest_id' => ''
				]
			]
		]);
	}

	public static function save_settings( $form_data = false ) {
		$default_data  = self::get_default_data();
		$saved_data    = self::get_saved_data();
		$settings_data = wp_parse_args( $saved_data, $default_data );

		if ( is_array( $form_data ) ) {
			// Merge triggers per-key so a partial save — e.g. the API-key
			// verify step passing only `api_key` — doesn't blow away the
			// saved trigger config (plain wp_parse_args is shallow).
			if ( isset( $form_data['triggers'] ) && is_array( $form_data['triggers'] ) ) {
				foreach ( $form_data['triggers'] as $key => $trigger ) {
					$existing = isset( $settings_data['triggers'][ $key ] ) && is_array( $settings_data['triggers'][ $key ] )
						? $settings_data['triggers'][ $key ]
						: [];
					$settings_data['triggers'][ $key ] = wp_parse_args(
						is_array( $trigger ) ? $trigger : [],
						$existing
					);
				}
				unset( $form_data['triggers'] );
			}
			$settings_data = wp_parse_args( $form_data, $settings_data );
		}

		// if settings already saved, then update it
		if ( count( $saved_data ) ) {
			return update_option( ACADEMY_PRO_MAILCHIMP_SETTINGS_NAME, wp_json_encode( $settings_data ) );
		}
		return add_option( ACADEMY_PRO_MAILCHIMP_SETTINGS_NAME, wp_json_encode( $settings_data ) );
	}
}
