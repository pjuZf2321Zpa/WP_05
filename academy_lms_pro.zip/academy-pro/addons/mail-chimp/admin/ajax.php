<?php

namespace AcademyProMailChimp\Admin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Exception;
use AcademyProMailChimp\MailChimpService;
use AcademyPro\DrewM\MailChimp\MailChimp;


class Ajax {
	public static function init(): void {
		$self = new self();
		add_action( 'wp_ajax_academy_pro_mailchimp/get_mailchimp_data', array( $self, 'get_mailchimp_data' ) );
		add_action( 'wp_ajax_academy_pro/update_mail_chimp_settings', array( $self, 'update_mailchimp_settings' ) );
		add_action( 'wp_ajax_academy_pro_mailchimp/verify_mailchimp_api_key', array(
			$self,
			'verify_mailchimp_api_key'
		) );
		add_filter( 'academy/api/settings/get_settings', array( $self, 'get_mailchimp_settings' ), 10, 1 );
	}

	public function get_mailchimp_settings( $settings ) {
		if ( ! isset( $settings['mailchimp'] ) ) {
			$settings['mailchimp'] = Settings::get_saved_data();
		}
		return $settings;
	}

	public function get_mailchimp_data() {
		check_ajax_referer( 'academy_nonce', 'security' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( __( 'Permission denied.', 'academy-pro' ), 403 );
		}

		$data = MailChimpService::get_mailchimp_audience_and_groups();

		// Surface failures as an actual error response instead of wrapping a
		// WP_Error / {error: ...} shape in wp_send_json_success (which left the
		// UI unable to tell success from failure).
		if ( is_wp_error( $data ) ) {
			wp_send_json_error( $data->get_error_message() );
		}
		if ( is_array( $data ) && isset( $data['error'] ) ) {
			wp_send_json_error( $data['error'] );
		}

		wp_send_json_success( $data );
	}

	public function update_mailchimp_settings() {
		check_ajax_referer( 'academy_nonce', 'security' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die();
		}
		$is_enable_force_subscription = isset( $_POST['is_enable_force_subscription'] )
			? filter_var( wp_unslash( $_POST['is_enable_force_subscription'] ), FILTER_VALIDATE_BOOLEAN )
			: false;
		$api_key                    = isset( $_POST['api_key'] ) ? sanitize_text_field( wp_unslash( $_POST['api_key'] ) ) : '';
		$subscriber_consent_message = isset( $_POST['subscriber_consent_message'] ) ? sanitize_text_field( wp_unslash( $_POST['subscriber_consent_message'] ) ) : '';
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$triggers_raw = isset( $_POST['triggers'] ) ? json_decode( wp_unslash( $_POST['triggers'] ), true ) : array();
		if ( ! is_array( $triggers_raw ) ) {
			$triggers_raw = array();
		}

		$sanitize_trigger = static function ( $trigger ) {
			$trigger = is_array( $trigger ) ? $trigger : array();
			return array(
				// Store as a real bool so the service's `enable` check is
				// meaningful — a disabled trigger must actually not fire.
				'enable'      => ! empty( $trigger['enable'] ) && filter_var( $trigger['enable'], FILTER_VALIDATE_BOOLEAN ),
				'list_id'     => isset( $trigger['list_id'] ) ? sanitize_text_field( $trigger['list_id'] ) : '',
				'group_id'    => isset( $trigger['group_id'] ) ? sanitize_text_field( $trigger['group_id'] ) : '',
				'interest_id' => isset( $trigger['interest_id'] ) ? sanitize_text_field( $trigger['interest_id'] ) : '',
			);
		};

		$mailchimp_settings = array(
			'is_enable_force_subscription' => $is_enable_force_subscription,
			'api_key'                      => $api_key,
			'subscriber_consent_message'   => $subscriber_consent_message,
			'triggers'                     => array(
				'student_registration'    => $sanitize_trigger( $triggers_raw['student_registration'] ?? array() ),
				'instructor_registration' => $sanitize_trigger( $triggers_raw['instructor_registration'] ?? array() ),
				'course_enroll'           => $sanitize_trigger( $triggers_raw['course_enroll'] ?? array() ),
			),
		);

		Settings::save_settings( $mailchimp_settings );

		do_action( 'academy_pro_mailchimp_settings_updated', $mailchimp_settings, 'mailchimp_settings' );
		wp_send_json_success( 'Settings saved successfully' );
	}


	public function verify_mailchimp_api_key() {
		check_ajax_referer( 'academy_nonce', 'security' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die();
		}
		$api_key = isset( $_POST['api_key'] ) ? sanitize_text_field( wp_unslash( $_POST['api_key'] ) ) : '';

		if ( empty( $api_key ) ) {
			wp_send_json_error( 'API key is empty' );
		}

		try {
			$mailchimp = new MailChimp( $api_key );
			// /ping is the canonical "is this key valid" probe — it doesn't
			// depend on the account already having an audience, so a fresh
			// account's valid key no longer reads as "Invalid API key".
			$mailchimp->get( 'ping' );
			if ( $mailchimp->success() ) {
				Settings::save_settings( array( 'api_key' => $api_key ) );
				wp_send_json_success( 'API key verified successfully' );
			}
			wp_send_json_error( 'Invalid API key' );
		} catch ( Exception $e ) {
			wp_send_json_error( 'Invalid API key' );
		}
	}
}
