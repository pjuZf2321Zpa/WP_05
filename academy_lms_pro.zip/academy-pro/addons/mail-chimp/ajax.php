<?php
namespace AcademyProMailChimp;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Ajax {
	public static function init(): void {
		Admin\Ajax::init();
	}
}
