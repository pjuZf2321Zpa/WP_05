<?php

namespace AcademyProMailChimp;

use Exception;
use WP_Error;
use AcademyPro\DrewM\MailChimp\MailChimp;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MailChimpService {
	public static function init() {
		$self     = new self();
		$settings = Admin\Settings::get_saved_data();
		if ( empty( $settings['api_key'] ) ) {
			return false;
		}

		// Registration hooks (includes/api/auth.php → process_user_registration)
		// pass a single argument: the new user id.
		add_action(
			'academy/api/auth/after_student_registration',
			array( $self, 'mailchimp_email_insertion_on_student_registration' ),
			10,
			1
		);
		add_action(
			'academy/api/auth/after_instructor_registration',
			array( $self, 'mailchimp_email_insertion_on_instructor_registration' ),
			10,
			1
		);
		// The free plugin fires this as
		// do_action( 'academy/course/after_enroll', $course_id, $enroll_id, $user_id )
		// (includes/traits/courses.php) — mind the argument order below.
		add_action(
			'academy/course/after_enroll',
			array( $self, 'mailchimp_email_insertion_on_course_enroll' ),
			10,
			3
		);
	}

	/**
	 * A trigger only runs when its own "enable" toggle is on *and* it has a
	 * target list. Every trigger key is always present in the saved settings,
	 * so an `isset()` check on the key alone is meaningless — the `enable`
	 * flag is the real switch.
	 *
	 * @param string $trigger_key One of student_registration, instructor_registration or course_enroll.
	 * @return bool
	 */
	private function is_trigger_enabled( $trigger_key ) {
		$trigger = $this->get_trigger_settings( $trigger_key );
		if ( ! filter_var( $trigger['enable'], FILTER_VALIDATE_BOOLEAN ) ) {
			return false;
		}
		return ! empty( $trigger['list_id'] );
	}

	/**
	 * @param string $trigger_key
	 * @return array{enable:mixed,list_id:string,group_id:string,interest_id:string}
	 */
	private function get_trigger_settings( $trigger_key ) {
		$settings = Admin\Settings::get_saved_data();
		$trigger  = isset( $settings['triggers'][ $trigger_key ] ) && is_array( $settings['triggers'][ $trigger_key ] )
			? $settings['triggers'][ $trigger_key ]
			: array();
		return wp_parse_args(
			$trigger,
			array(
				'enable'      => false,
				'list_id'     => '',
				'group_id'    => '',
				'interest_id' => '',
			)
		);
	}

	public static function get_mailchimp_audience_and_groups() {
		$settings = Admin\Settings::get_saved_data();
		$api_key  = isset( $settings['api_key'] ) ? $settings['api_key'] : '';
		if ( empty( $api_key ) ) {
			return array();
		}

		try {
			$mailchimp = new MailChimp( $api_key );
		} catch ( Exception $e ) {
			return new WP_Error( 'academy_mailchimp_bad_key', $e->getMessage() );
		}

		$result = $mailchimp->get( 'lists', array( 'count' => 100 ) );

		if ( ! $mailchimp->success() ) {
			return new WP_Error(
				'academy_mailchimp_request_failed',
				$mailchimp->getLastError() ? $mailchimp->getLastError() : __( 'Could not reach MailChimp.', 'academy-pro' )
			);
		}

		// Valid key with no audiences yet is not an error.
		if ( empty( $result['lists'] ) ) {
			return array();
		}

		$audiences = array();
		foreach ( $result['lists'] as $list ) {
			$audience = array(
				'value'  => $list['id'],
				'label'  => $list['name'],
				'groups' => array(),
			);

			$groups_result = $mailchimp->get(
				'lists/' . $list['id'] . '/interest-categories',
				array( 'count' => 100 )
			);

			// A list with no interest categories is perfectly normal — leave
			// its groups empty and carry on instead of bailing out of the
			// whole audience list (the old `return` here meant one group-less
			// audience hid every other audience).
			if ( ! empty( $groups_result['categories'] ) ) {
				foreach ( $groups_result['categories'] as $group ) {
					$interests        = array();
					$interests_result = $mailchimp->get(
						'lists/' . $list['id'] . '/interest-categories/' . $group['id'] . '/interests',
						array( 'count' => 100 )
					);
					if ( ! empty( $interests_result['interests'] ) ) {
						foreach ( $interests_result['interests'] as $interest ) {
							$interests[] = array(
								'value' => $interest['id'],
								'label' => $interest['name'],
							);
						}
					}
					$audience['groups'][] = array(
						'value'     => $group['id'],
						'label'     => $group['title'],
						'interests' => $interests,
					);
				}
			}//end if

			$audiences[] = $audience;
		}//end foreach

		return $audiences;
	}

	public function mailchimp_email_insertion_on_course_enroll( $course_id, $enroll_id, $user_id ) {
		if ( ! $this->is_trigger_enabled( 'course_enroll' ) ) {
			return array( 'error' => 'Course enroll trigger is not enabled' );
		}
		$trigger = $this->get_trigger_settings( 'course_enroll' );
		return $this->insert_into_mailchimp( $user_id, $trigger['list_id'], $trigger['interest_id'] );
	}

	public function mailchimp_email_insertion_on_instructor_registration( $user_id ) {
		if ( ! $this->is_trigger_enabled( 'instructor_registration' ) ) {
			return array( 'error' => 'Instructor registration trigger is not enabled' );
		}
		$trigger = $this->get_trigger_settings( 'instructor_registration' );
		return $this->insert_into_mailchimp( $user_id, $trigger['list_id'], $trigger['interest_id'] );
	}

	public function mailchimp_email_insertion_on_student_registration( $user_id ) {
		if ( ! $this->is_trigger_enabled( 'student_registration' ) ) {
			return array( 'error' => 'Student registration trigger is not enabled' );
		}
		$trigger = $this->get_trigger_settings( 'student_registration' );
		return $this->insert_into_mailchimp( $user_id, $trigger['list_id'], $trigger['interest_id'] );
	}

	/**
	 * Add (or update) a member in a MailChimp audience.
	 *
	 * Uses PUT on the subscriber hash so re-running a trigger for the same
	 * address — e.g. a student who registers and then enrols — updates the
	 * existing member (adding the new interest) instead of failing with
	 * "Member Exists" the way a plain POST does.
	 *
	 * @param int    $user_id
	 * @param string $list_id
	 * @param string $interest_id  Optional; an empty value is skipped rather
	 *                              than sent as `'' => true` (which MailChimp rejects).
	 * @return array
	 */
	public function insert_into_mailchimp( $user_id, $list_id, $interest_id ) {
		$settings = Admin\Settings::get_saved_data();
		$api_key  = isset( $settings['api_key'] ) ? $settings['api_key'] : '';

		if ( empty( $api_key ) || empty( $list_id ) ) {
			return array( 'error' => 'MailChimp is not configured' );
		}

		$user = get_userdata( $user_id );
		if ( ! $user || empty( $user->user_email ) || ! is_email( $user->user_email ) ) {
			return array( 'error' => 'Invalid user' );
		}

		try {
			$mailchimp = new MailChimp( $api_key );
		} catch ( Exception $e ) {
			return array( 'error' => $e->getMessage() );
		}

		$force = ! empty( $settings['is_enable_force_subscription'] )
			&& filter_var( $settings['is_enable_force_subscription'], FILTER_VALIDATE_BOOLEAN );

		$payload = array(
			// MailChimp requires `email_address` in the body even on a PUT to
			// the subscriber-hash endpoint (it 400s "Required fields were not
			// provided: email_address" otherwise).
			'email_address' => $user->user_email,
			// FNAME/LNAME are the only merge fields every audience has by
			// default. USERNAME is a custom field most audiences don't define,
			// and sending an unknown merge field makes MailChimp reject the
			// whole request — so it's opt-in via this filter now.
			'merge_fields' => apply_filters(
				'academy_pro_mailchimp/subscribe_merge_fields',
				array(
					'FNAME' => $user->first_name,
					'LNAME' => $user->last_name,
				),
				$user
			),
		);

		if ( $force ) {
			// "Forced Subscription" on: (re)subscribe even a previously
			// unsubscribed address.
			$payload['status'] = 'subscribed';
		} else {
			// Default: only set them subscribed if they're new; never flip an
			// existing unsubscribed member back on without consent.
			$payload['status_if_new'] = 'subscribed';
		}

		if ( ! empty( $interest_id ) ) {
			$payload['interests'] = array( $interest_id => true );
		}

		$subscriber_hash = MailChimp::subscriberHash( $user->user_email );
		$mailchimp->put( "lists/{$list_id}/members/{$subscriber_hash}", $payload );

		if ( $mailchimp->success() ) {
			return array( 'success' => true );
		}

		return array( 'error' => $mailchimp->getLastError() );
	}
}
