<?php

namespace AcademyProGamipress;

use AcademyProGamipress\Integrations\Hooks;
use AcademyProGamipress\Integrations\Points;
use AcademyProGamipress\Integrations\Triggers;

class Integrations {
	public static function init() {
		Triggers::init();
	}
}
