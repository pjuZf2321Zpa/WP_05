<?php
namespace AcademyProGamipress;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AcademyProGamipress\Ajax\Admin;
use AcademyProGamipress\Ajax\Settings;


class Ajax {
	public static function init() {
		$self = new self();
		$self->dispatch_hooks();
	}
	public function dispatch_hooks() {
		( new Settings() )->dispatch_actions();
		( new Admin() )->dispatch_actions();
	}
}
