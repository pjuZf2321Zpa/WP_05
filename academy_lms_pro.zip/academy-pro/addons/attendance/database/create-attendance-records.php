<?php
namespace AcademyProAttendance\Database;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CreateAttendanceRecords {

	public static function init(): void {
		$self = new self();
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		global $wpdb;
		$prefix = $wpdb->prefix;
		$charset_collate = $wpdb->get_charset_collate();
		$self->create_attendance_record_table( $prefix, $charset_collate );
	}

	public function create_attendance_record_table( $prefix, $charset ) {
		$table_name = $prefix . ACADEMY_PLUGIN_SLUG . '_attendance_records';
		$sql        = "CREATE TABLE IF NOT EXISTS $table_name (
            id INT AUTO_INCREMENT PRIMARY KEY,
            course_id INT NOT NULL,
            topic_id INT NOT NULL,
            topic_type VARCHAR(50) NOT NULL,
            user_id INT NOT NULL,
            status ENUM('present', 'absent') NOT NULL DEFAULT 'absent',
            recorded_via ENUM('manual', 'self_service') NOT NULL DEFAULT 'manual',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) $charset;";

		dbDelta( $sql );
	}
}
