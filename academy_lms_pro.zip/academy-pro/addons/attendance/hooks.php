<?php
namespace AcademyProAttendance;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


class Hooks {
	public static function init() {
		$self = new self();
		add_action( 'academy/course/after_enroll', [ $self, 'add_attendance_after_enroll' ], 10, 3 );
		add_action( 'academy/frontend/before_mark_topic_complete', [ $self, 'mark_attendance_on_topic_complete' ], 11, 4 );
	}

	public function add_attendance_after_enroll( $course_id, $enrolled_id, $user_id ) {
		$lessons = Helper::get_attendance_course_topics( $course_id );
		if ( ! empty( $lessons ) ) {
			foreach ( $lessons as $lesson ) {
				Helper::insert_attendance_record([
					'course_id' => $course_id,
					'topic_id' => $lesson['id'],
					'topic_type' => 'lesson',
					'user_id' => $user_id
				]);
			}
		}
	}

	public function mark_attendance_on_topic_complete( $topic_type, $course_id, $topic_id, $user_id ) {
		if ( 'lesson' === $topic_type ) {
			// Attendance (required or just recorded) only ever applies to a
			// lesson whose Video Source is set to Online/Offline class — the
			// "Attendance Required" toggle itself is only shown in the editor
			// for those two source types (see LessonMeta.js). Without this
			// check, completing ANY ordinary lesson inserted a phantom
			// "present" record for it, polluting the attendance table with
			// lessons that were never configured for attendance.
			$video_source = \Academy\Helper::get_lesson_meta( (int) $topic_id, 'video_source' );
			if ( ! in_array( $video_source['type'] ?? '', [ 'online', 'offline' ], true ) ) {
				return;
			}

			$is_required = (bool) \Academy\Helper::get_lesson_meta( (int) $topic_id, 'is_required_to_attendance' );
			if ( $is_required ) {
				if ( \Academy\Helper::is_server_learn_page() ) {
					wp_safe_redirect( \Academy\Helper::sanitize_referer_url( wp_get_referer() ) );
					exit;
				}
				wp_send_json_error(
					__( 'You cannot complete this topic — it must be marked as completed by an admin.', 'academy-pro' ),
				);
			}
			Helper::insert_attendance_record([
				'course_id' => $course_id,
				'topic_id' => $topic_id,
				'topic_type' => $topic_type,
				'user_id' => $user_id,
				'status' => 'present',
			]);
		}//end if
	}
}
