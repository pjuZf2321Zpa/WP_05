<?php
namespace AcademyProAttendance;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use Academy\Interfaces\AddonInterface;
use AcademyProAttendance;

final class Attendance implements AddonInterface {
	private $addon_name = 'attendance';
	private function __construct() {
		$this->define_constants();
		$this->init_addon();
	}
	public static function init() {
		static $instance = false;

		if ( ! $instance ) {
			$instance = new self();
		}

		return $instance;
	}
	public function define_constants() {
		/**
		 * Defines CONSTANTS for Whole Addon.
		 */
		define( 'ACADEMY_PRO_ATTENDANCE_VERSION', '0.1' );
		define( 'ACADEMY_PRO_ATTENDANCE_DIR_PATH', ACADEMY_PRO_ADDONS_DIR_PATH . 'attendance/' );
	}
	public function init_addon() {
		// fire addon activation hook
		add_action( "academy/addons/activated_{$this->addon_name}", array( $this, 'addon_activation_hook' ) );
		// if disable then stop running addon
		if ( ! \Academy\Helper::get_addon_active_status( $this->addon_name ) ) {
			return;
		}

		API::init();
		Admin::init();
		Database::init();
		Hooks::init();
		Settings::init();
	}

	public function load_dependency() {
		require_once ACADEMY_PRO_ATTENDANCE_DIR_PATH . 'frontend/functions.php';
		require_once ACADEMY_PRO_ATTENDANCE_DIR_PATH . 'frontend/hooks.php';
	}

	public function addon_activation_hook() {
	}
}
