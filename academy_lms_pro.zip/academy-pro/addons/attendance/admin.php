<?php
namespace AcademyProAttendance;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AcademyProAttendance\Admin\Ajax;

class Admin {
	public static function init() {
		$self = new self();
		$self::dispatch_hooks();
	}

	public static function dispatch_hooks() {
		( new Ajax() )->dispatch_actions();
	}
}
