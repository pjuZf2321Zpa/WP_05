<?php
namespace AcademyProAttendance;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Settings {
	public static function init() {
		$self = new self();
		// attendance settings
		add_action( 'academy/admin/settings/base_default_data', array( $self, 'get_attendance_default_settings_data' ) );
		add_filter( 'academy/admin/settings/sanitize_payload', array( $self, 'sanitize_attendance_default_settings' ) );
		add_filter( 'academy/admin/settings/save', array( $self, 'save_attendance_settings_data' ), 11, 3 );
	}

	public function get_attendance_default_settings_data( $default_data ) {
		$default_data['lesson_offline_class_address'] = '';
		return $default_data;
	}

	public function sanitize_attendance_default_settings( $sanitize_data ) {
		$sanitize_data['lesson_offline_class_address'] = 'string';
		return $sanitize_data;
	}

	public function save_attendance_settings_data( $data, $payload, $default ) {
		$data['lesson_offline_class_address'] = $payload['lesson_offline_class_address'] ?? $default['attendance_trigger_lists'];
		return $data;
	}
}
