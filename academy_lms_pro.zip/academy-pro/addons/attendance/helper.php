<?php
namespace AcademyProAttendance;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


class Helper {

	public static function insert_attendance_record( $data ) {
		global $wpdb;

		$table = $wpdb->prefix . 'academy_attendance_records';

		// Default array with empty values
		$defaults = array(
			'topic_type'   => '',
			'topic_id'     => 0,
			'user_id'      => 0,
			'course_id'    => 0,
			'status'       => 'absent',
			'recorded_via' => 'manual',
			'created_at'   => current_time( 'mysql' ),
		);

		// Merge defaults with provided data (correct order!)
		$record = wp_parse_args( $data, $defaults );

		// Check if record already exists (based on user_id + course_id + topic_id)
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
		$existing_id = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT id FROM {$table} WHERE user_id = %d AND course_id = %d AND topic_id = %d", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$record['user_id'],
				$record['course_id'],
				$record['topic_id']
			)
		);

		if ( $existing_id ) {
			// Do not overwrite created_at on update
			unset( $record['created_at'] );

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->update(
				$table,
				$record,
				array( 'id' => $existing_id ),
				array(
					'%s', // topic_type
					'%d', // topic_id
					'%d', // user_id
					'%d', // course_id
					'%s', // status
					'%s', // recorded_via
				),
				array( '%d' )
			);
			return $existing_id;
		} else {
			// Insert new record
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
			$wpdb->insert(
				$table,
				$record,
				array(
					'%s', // topic_type
					'%d', // topic_id
					'%d', // user_id
					'%d', // course_id
					'%s', // status
					'%s', // recorded_via
					'%s', // created_at
				)
			);
			return $wpdb->insert_id;
		}//end if
	}

	public static function get_attendance_count_by_course_id( $course_id, $status ) {
		global $wpdb;
		$table = $wpdb->prefix . ACADEMY_PLUGIN_SLUG . '_attendance_records';
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
		$results = $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(id) FROM {$table} WHERE course_id = %d AND status = %s ", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$course_id, $status
		) );

		return intval( $results );
	}

	public static function get_total_students( $course_id ) {
		global $wpdb;
		$table = $wpdb->prefix . ACADEMY_PLUGIN_SLUG . '_attendance_records';
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
		$results = $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(user_id) FROM {$table} WHERE course_id = %d", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$course_id
		) );

		return intval( $results );
	}

	public static function get_attendance_course_topics( $course_id ) {
		$prepare_curriculum = \AcademyProContentDrip\Helper::get_course_curriculum_array( $course_id );
		$lessons = [];
		if ( empty( $prepare_curriculum ) ) {
			return $lessons;
		}

		foreach ( $prepare_curriculum as $curriculum ) {
			if ( 'lesson' === $curriculum['type'] ) {
				$lesson_source = \Academy\Helper::get_lesson_meta( (int) $curriculum['id'], 'video_source' );
				$source = isset( $lesson_source['type'] ) ? $lesson_source['type'] : '';
				if ( in_array( $source, [ 'offline', 'online' ], true ) ) {
					$lessons[] = [
						'id' => $curriculum['id'],
						'title' => \Academy\Helper::get_lesson( $curriculum['id'] )->lesson_title,
					];
				}
			}
		}
		return $lessons;
	}

	public static function get_attendance_by_course_id( $course_id ) {
		global $wpdb;
		$table = $wpdb->prefix . ACADEMY_PLUGIN_SLUG . '_attendance_records';
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
		$results = $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM {$table} WHERE course_id = %d", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$course_id
		) );

		return $results;
	}

	public static function get_student_by_course_id( $course_id, $topic_id = null, $user_id = null ) {
		global $wpdb;

		$table = $wpdb->prefix . ACADEMY_PLUGIN_SLUG . '_attendance_records';

		// phpcs:disable WordPressVIPMinimum.Variables.RestrictedVariables.user_meta__wpdb__users -- reporting JOIN on users/usermeta that get_users() cannot express
		$sql = "SELECT a.*, u.ID AS user_id, u.display_name, u.user_email
                FROM {$table} AS a
                INNER JOIN {$wpdb->users} AS u 
                    ON a.user_id = u.ID
                WHERE a.course_id = %d";
		// phpcs:enable WordPressVIPMinimum.Variables.RestrictedVariables.user_meta__wpdb__users

		// Params start with course_id
		$params = [ $course_id ];

		// Add user ID condition only if provided
		if ( ! empty( $user_id ) ) {
			$sql .= ' AND a.user_id = %d';
			$params[] = $user_id;
		}

		// Add topic condition
		if ( ! empty( $topic_id ) ) {
			$sql .= ' AND a.topic_id = %d';
			$params[] = $topic_id;
		}

		// Prepare using spread operator
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
		$results = $wpdb->get_results(
			$wpdb->prepare( $sql, ...$params )// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		);

		if ( empty( $results ) ) {
			return [];
		}

		// Add avatar URLs
		foreach ( $results as $result ) {
			$result->avatar_url = get_avatar_url( $result->user_id );
		}

		return $results;
	}
}
