<?php
namespace AcademyProAttendance\Admin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Academy\Classes\AbstractAjaxHandler;
use Academy\Classes\Sanitizer;
use AcademyProAttendance\Helper;

class Ajax extends AbstractAjaxHandler {
	protected $namespace = ACADEMY_PLUGIN_SLUG . '_pro/attendance';
	public function __construct() {
		$this->actions = array(
			'get_courses' => array(
				'callback' => array( $this, 'get_all_course_attendance' ),
				'capability' => 'manage_options',
			),
			'get_attendance' => array(
				'callback' => array( $this, 'get_course_attendance' ),
				'capability' => 'manage_options',
			),
			'update_student_attendance' => array(
				'callback' => array( $this, 'update_student_attendance' ),
				'capability' => 'manage_options'
			),
			'get_lessons' => array(
				'callback' => array( $this, 'get_lessons' ),
				'capability' => 'manage_options',
			)
		);
	}

	public function get_all_course_attendance( $payload_data ) {
		$payload = Sanitizer::sanitize_payload([
			'page'     => 'integer',
			'per_page' => 'integer',
			'search'   => 'string',
		], $payload_data );

		$page     = max( 1, (int) ( $payload['page'] ?? 1 ) );
		$per_page = max( 1, (int) ( $payload['per_page'] ?? 10 ) );
		$keyword  = $payload['search'] ?? '';
		$offset = ( $page - 1 ) * $per_page;

		// phpcs:disable WordPressVIPMinimum.Performance.NoPaging.posts_per_page_posts_per_page -- needs the complete (small, bounded) set
		$args = [
			'post_type'      => 'academy_courses',
			'post_status'    => 'publish',
			'posts_per_page' => -1,
			'fields'         => 'ids',
			's'              => $keyword
		];
		// phpcs:enable WordPressVIPMinimum.Performance.NoPaging.posts_per_page_posts_per_page

		$query = new \WP_Query( $args );

		$response      = [];

		if ( $query->have_posts() ) {
			foreach ( $query->posts as $course_id ) {
				$curriculum = \AcademyProContentDrip\Helper::get_course_curriculum_array( $course_id );

				if ( empty( $curriculum ) ) {
					continue;
				}

				$lessons = array_filter(
					$curriculum,
					static fn( $topic ) => ( $topic['type'] ?? '' ) === 'lesson'
				);

				$has_attendance_lesson = false;
				foreach ( $lessons as $lesson ) {
					$video_source = \Academy\Helper::get_lesson_meta( $lesson['id'] ?? 0, 'video_source' );
					if ( in_array( $video_source['type'] ?? '', [ 'offline', 'online' ], true ) ) {
						$has_attendance_lesson = true;
						break;
					}
				}

				if ( ! $has_attendance_lesson ) {
					continue;
				}

				$response[] = [
					'id'        => $course_id,
					'title'     => get_the_title( $course_id ),
					'permalink' => get_permalink( $course_id ),
					'total_users' => Helper::get_total_students( $course_id ),
					'total_attendance' => Helper::get_attendance_count_by_course_id( $course_id, 'present' ),
				];
			}//end foreach
		}//end if
		header( 'X-Wp-Total: ' . count( $response ) );
		wp_send_json_success( array_slice( $response, $offset, $per_page ) );
	}

	public function get_course_attendance( $payload_data ) {
		$payload = Sanitizer::sanitize_payload( [ 'course_id' => 'integer' ], $payload_data );
		$course_id = $payload['course_id'] ?? 0;
		if ( empty( $course_id ) ) {
			wp_send_json_error(
				__( 'Invalid or Empty Course ID', 'academy-pro' )
			);
		}
		$attendances = Helper::get_student_by_course_id( $course_id );
		foreach ( $attendances as &$attendance ) {
			$attendance->topic_title = \Academy\Helper::get_lesson_title( $attendance->topic_id );
		}
		wp_send_json_success( $attendances );
	}

	public function update_student_attendance( $payload_data ) {
		$payload = Sanitizer::sanitize_payload(
			[
				'course_id' => 'integer',
				'user_id'   => 'string',
				'topic_id'  => 'string',
				'status'    => 'string',
			],
			$payload_data
		);

		$course_id = $payload['course_id'] ?? 0;
		$user_id  = $payload['user_id'] ?? '';
		$status    = $payload['status'] ?? '';
		$user_ids = explode( ',', $user_id );
		$topic_ids = explode( ',', $payload['topic_id'] ?? '' );

		if ( empty( $course_id ) ) {
			wp_send_json_error( __( 'Invalid or empty course ID.', 'academy-pro' ) );
		}

		if ( empty( $user_ids ) || ! is_array( $user_ids ) ) {
			wp_send_json_error( __( 'User IDs must be provided.', 'academy-pro' ) );
		}

		if ( empty( $topic_ids ) || ! is_array( $topic_ids ) ) {
			wp_send_json_error( __( 'Topic IDs must be provided.', 'academy-pro' ) );
		}

		if ( empty( $status ) ) {
			wp_send_json_error( __( 'Attendance status cannot be empty.', 'academy-pro' ) );
		}
		foreach ( $user_ids as $user_id ) {
			foreach ( $topic_ids as $topic_id ) {
				$attendance_id = Helper::insert_attendance_record(
					[
						'course_id' => absint( $course_id ),
						'user_id'   => absint( $user_id ),
						'topic_id'  => absint( $topic_id ),
						'status'    => $status,
					]
				);

				// Attendance is authoritative for a tracked (online/offline)
				// lesson: present completes it (the only path for a lesson
				// with "Attendance Required" on, since self-completion is
				// blocked there — see Hooks::mark_attendance_on_topic_complete()),
				// absent un-completes it below, regardless of how it got
				// completed.
				if ( 'present' === $status ) {
					$option_name = 'academy_course_' . $course_id . '_completed_topics';
					$saved_topics_lists = (array) json_decode( get_user_meta( $user_id, $option_name, true ), true );

					if ( ! isset( $saved_topics_lists['lesson'][ $topic_id ] ) ) {
						$saved_topics_lists['lesson'][ $topic_id ] = \Academy\Helper::get_time();
						update_user_meta( $user_id, $option_name, wp_json_encode( $saved_topics_lists ) );
						do_action( 'academy/frontend/after_mark_topic_complete', 'lesson', $course_id, $topic_id, $user_id );
					}
				} elseif ( 'absent' === $status ) {
					// Symmetric with the 'present' branch above: attendance is
					// authoritative for a lesson that's tracked here (only
					// online/offline-class lessons ever reach this endpoint —
					// see get_all_course_attendance()'s filtering). Marking a
					// student absent un-completes it even if the student had
					// self-completed it themselves — being marked absent means
					// they didn't attend the session, regardless of whether
					// "Attendance Required" was toggled on for it.
					$option_name = 'academy_course_' . $course_id . '_completed_topics';
					$saved_topics_lists = (array) json_decode( get_user_meta( $user_id, $option_name, true ), true );

					if ( isset( $saved_topics_lists['lesson'][ $topic_id ] ) ) {
						unset( $saved_topics_lists['lesson'][ $topic_id ] );
						update_user_meta( $user_id, $option_name, wp_json_encode( $saved_topics_lists ) );
						do_action( 'academy/frontend/mark_topic_incomplete', 'lesson', $course_id, $topic_id, $user_id );
					}
				}//end if
			}//end foreach
		}//end foreach
		$message = $attendance_id ? __( 'Successfully updated attendance.', 'academy-pro' ) : __( 'Sorry, not updated attendance.', 'academy-pro' );
		wp_send_json_success( $message );
	}

	public function get_lessons( $payload_data ) {
		$payload = Sanitizer::sanitize_payload( [ 'course_id' => 'integer' ], $payload_data );
		$course_id = $payload['course_id'] ?? 0;
		if ( empty( $course_id ) ) {
			wp_send_json_error(
				__( 'Invalid or Empty Course ID', 'academy-pro' )
			);
		}
		$attendance = Helper::get_attendance_course_topics( $course_id );
		wp_send_json_success( $attendance );
	}
}
