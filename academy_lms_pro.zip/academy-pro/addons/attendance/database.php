<?php
namespace AcademyProAttendance;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AcademyProAttendance\Database\CreateAttendanceRecords;

class Database {
	public static function init(): void {
		CreateAttendanceRecords::init();
	}
}
