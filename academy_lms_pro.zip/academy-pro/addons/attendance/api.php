<?php
namespace AcademyProAttendance;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


class API {

	public static function init() {
		$self = new self();
		// lesson
		add_filter( 'academy/api/lesson/public_item_schema', [ $self, 'attendance_public_item_schema' ] );
		add_filter( 'academy/api/lesson/item_schema', [ $self, 'attendance_item_schema' ] );
		add_filter( 'academy/api/lesson/rest_pre_insert_lesson_meta', [ $self, 'attendance_rest_pre_insert_lesson_meta' ], 10, 3 );
		add_filter( 'academy/api/lesson/rest_prepare_meta_item', [ $self, 'attendance_rest_prepare_meta_item' ], 10, 4 );
	}

	public function attendance_public_item_schema( $schema ) {
		if ( ! isset( $schema['properties']['meta']['properties'] ) ) {
			return $schema;
		}
		$meta = $schema['properties']['meta']['properties'];
		$meta['is_required_to_attendance'] = [
			'type' => 'boolean',
		];
		$schema['properties']['meta']['properties'] = $meta;
		return $schema;
	}

	public function attendance_item_schema( $schema ) {
		if ( ! isset( $schema['meta']['properties'] ) ) {
			return $schema;
		}
		$meta = $schema['meta'];
		$meta['properties']['is_required_to_attendance'] = [
			'type'              => 'boolean',
			'sanitize_callback' => 'rest_sanitize_boolean',
		];
		$schema['meta'] = $meta;
		return $schema;
	}

	public function attendance_rest_pre_insert_lesson_meta( $lesson_meta, $request, $schema ) {
		if ( ! empty( $schema['meta']['properties']['is_required_to_attendance'] ) && isset( $request['meta']['is_required_to_attendance'] ) ) {
			$lesson_meta->is_required_to_attendance = $request['meta']['is_required_to_attendance'];
		}

		return $lesson_meta;
	}

	public function attendance_rest_prepare_meta_item( $data, $lesson_meta, $request, $schema ) {
		if ( isset( $schema['meta']['properties']['is_required_to_attendance'] ) && isset( $lesson_meta['is_required_to_attendance'] ) ) {
			$data['is_required_to_attendance'] = (bool) $lesson_meta['is_required_to_attendance'];
		}
		return $data;
	}
}
