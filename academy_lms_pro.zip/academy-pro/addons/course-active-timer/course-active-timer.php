<?php
namespace AcademyProCourseActiveTimer;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Academy\Interfaces\AddonInterface;

final class CourseActiveTimer implements AddonInterface {

	private $addon_name = 'course-active-timer';

	private function __construct() {
		$this->define_constants();
		$this->init_addon();
	}

	public static function init() {
		static $instance = false;
		if ( ! $instance ) {
			$instance = new self();
		}
		return $instance;
	}

	public function define_constants() {
		define( 'ACADEMY_PRO_COURSE_TIMER_DIR_PATH', ACADEMY_PRO_ADDONS_DIR_PATH . 'course-active-timer/' );
	}

	public function init_addon() {
		add_action( "academy/addons/activated_{$this->addon_name}", array( $this, 'addon_activation_hook' ) );

		if ( ! \Academy\Helper::get_addon_active_status( $this->addon_name ) ) {
			return;
		}

		Hooks::init();
		Ajax::init();
		Api::init();
	}

	public function addon_activation_hook() {
		Database::init();
	}
}
