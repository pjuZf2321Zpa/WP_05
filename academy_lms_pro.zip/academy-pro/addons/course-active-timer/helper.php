<?php
namespace AcademyProCourseActiveTimer;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Helper {

	/**
	 * Seconds the browser is expected to wait between heartbeats.
	 *
	 * Server-side on purpose: it bounds how much time a single heartbeat may
	 * bill, so it must never come from the request. See {@see self::heartbeat()}.
	 */
	const HEARTBEAT_INTERVAL = 30;

	/**
	 * The expected heartbeat interval, filterable for sites that tune the
	 * browser-side cadence.
	 */
	public static function get_heartbeat_interval(): int {
		return max( 1, (int) apply_filters( 'academy_pro/course_timer/heartbeat_interval', self::HEARTBEAT_INTERVAL ) );
	}

	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'academy_course_timers';
	}

	/**
	 * Returns the allowed time for a course in seconds, or null for unlimited.
	 *
	 * @param int $course_id
	 */
	public static function get_course_allowed_time( $course_id ) {
		if ( ! get_post_meta( $course_id, 'academy_course_timer_enabled', true ) ) {
			return null;
		}
		$value = (int) get_post_meta( $course_id, 'academy_course_timer_duration_value', true );
		$unit  = get_post_meta( $course_id, 'academy_course_timer_duration_unit', true ) ? get_post_meta( $course_id, 'academy_course_timer_duration_unit', true ) : 'minutes';
		if ( $value <= 0 ) {
			return null;
		}
		$multipliers = array(
			'minutes' => 60,
			'hours'   => 3600,
			'days'    => 86400,
		);
		return $value * ( $multipliers[ $unit ] ?? 60 );
	}

	public static function is_timer_enabled( $course_id ) {
		return (bool) get_post_meta( $course_id, 'academy_course_timer_enabled', true );
	}

	public static function get_expiry_action( $course_id ) {
		$action = get_post_meta( $course_id, 'academy_course_timer_expiry_action', true );
		$actions = array(
			'course_lock'       => 'lock',
			'lock'              => 'lock',
			'cancel_enrollment' => 'cancel',
			'cancel'            => 'cancel',
		);
		return $actions[ (string) $action ] ?? 'lock';
	}


	public static function get_timer( $user_id, $course_id ) {
		global $wpdb;
		$table = self::table();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		return $wpdb->get_row(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				"SELECT * FROM {$table} WHERE user_id = %d AND course_id = %d LIMIT 1",
				$user_id,
				$course_id
			)
		);
	}

	public static function is_expired( $user_id, $course_id ) {
		$timer = self::get_timer( $user_id, $course_id );
		return $timer && 'expired' === $timer->status;
	}

	public static function is_course_locked( $user_id, $course_id ) {
		if ( ! $user_id || ! $course_id ) {
			return false;
		}

		return self::is_expired( $user_id, $course_id );
	}


	/**
	 * Called on enrollment. Idempotent — does nothing if row already exists.
	 *
	 * @param int   $user_id
	 * @param int   $course_id
	 * @param mixed $allowed_time
	 */
	public static function create_timer( $user_id, $course_id, $allowed_time ) {
		global $wpdb;
		if ( self::get_timer( $user_id, $course_id ) ) {
			$current_allowed_time = (int) self::get_course_allowed_time( $course_id );
			self::update_timer( $user_id, $course_id, $current_allowed_time );
			return;
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$wpdb->insert(
			self::table(),
			array(
				'user_id'      => (int) $user_id,
				'course_id'    => (int) $course_id,
				'allowed_time' => $allowed_time,
				'status'       => 'not_started',
				'created_at'   => current_time( 'mysql' ),
				'updated_at'   => current_time( 'mysql' ),
			),
			array( '%d', '%d', null === $allowed_time ? '%s' : '%d', '%s', '%s', '%s' )
		);
	}


	/**
	 * Start: called when a student first opens the course page.
	 * Also used as a reconnect after a browser crash.
	 *
	 * Syncs latest course timer settings with existing user timer.
	 *
	 * @param int $user_id
	 * @param int $course_id
	 */
	public static function start_timer( $user_id, $course_id ) {
		global $wpdb;

		$timer = self::get_timer( $user_id, $course_id );

		$current_allowed_time = (int) self::get_course_allowed_time( $course_id );

		// Create timer if not exists.
		if ( ! $timer ) {
			self::create_timer( $user_id, $course_id, $current_allowed_time );
			$timer = self::get_timer( $user_id, $course_id );
		}

		// Sync updated allowed time.
		if ( (int) $timer->allowed_time !== $current_allowed_time ) {
			if ( self::update_timer( $user_id, $course_id, $current_allowed_time ) ) {
				$timer->allowed_time = $current_allowed_time;
			}
		}

		// Check expiration.
		if ( 'expired' === $timer->status ) {
			return array(
				'error' => __( 'Your access to this course has expired.', 'academy-pro' ),
			);
		}

		$now = time();

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- custom query with no WP API equivalent
		$wpdb->update(
			self::table(),
			array(
				'last_start_time' => $now,
				'last_activity'   => $now,
				'status'          => 'active',
				'updated_at'      => current_time( 'mysql' ),
			),
			array(
				'user_id'   => (int) $user_id,
				'course_id' => (int) $course_id,
			),
			array( '%d', '%d', '%s', '%s' ),
			array( '%d', '%d' )
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		$timer->last_start_time = $now;
		$timer->last_activity   = $now;
		$timer->status          = 'active';

		return self::build_response( $timer );
	}

	public static function update_timer( $user_id, $course_id, $current_allowed_time ) {
		global $wpdb;
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- custom query with no WP API equivalent
		return $wpdb->update(
			self::table(),
			array(
				'allowed_time' => $current_allowed_time,
				'status'          => 'active',
			),
			array(
				'user_id'   => (int) $user_id,
				'course_id' => (int) $course_id,
			),
			array( '%d', '%s' ),
			array( '%d', '%d' )
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	}

	/**
	 * Pause: accumulate elapsed time into consumed_time.
	 * Idempotent when already paused.
	 *
	 * @param int $user_id
	 * @param int $course_id
	 */
	public static function pause_timer( $user_id, $course_id ) {
		global $wpdb;

		$timer = self::get_timer( $user_id, $course_id );

		if ( ! $timer || 'active' !== $timer->status ) {
			return self::build_response( $timer );
		}

		$now          = time();
		$elapsed      = max( 0, $now - (int) $timer->last_start_time );
		$new_consumed = (int) $timer->consumed_time + $elapsed;
		$new_status   = 'paused';

		if ( null !== $timer->allowed_time && $new_consumed >= (int) $timer->allowed_time ) {
			$new_consumed = (int) $timer->allowed_time;
			$new_status   = 'expired';
			self::handle_expiry( (int) $user_id, (int) $course_id );
		}

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- custom query with no WP API equivalent
		$wpdb->update(
			self::table(),
			array(
				'consumed_time' => $new_consumed,
				'last_activity' => $now,
				'status'        => $new_status,
				'updated_at'    => current_time( 'mysql' ),
			),
			array(
				'user_id' => (int) $user_id,
				'course_id' => (int) $course_id
			),
			array( '%d', '%d', '%s', '%s' ),
			array( '%d', '%d' )
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		$timer->consumed_time = $new_consumed;
		$timer->last_activity = $now;
		$timer->status        = $new_status;

		// Same as heartbeat(): once the enrollment is gone, start the timer
		// over so a re-enrollment isn't born expired.
		if ( 'expired' === $new_status && 'cancel' === self::get_expiry_action( $course_id ) ) {
			self::reset_timer( $user_id, $course_id );
		}

		return self::build_response( $timer );
	}

	/**
	 * Resume: reset last_start_time so elapsed is measured from now.
	 * Called when the tab becomes visible again.
	 *
	 * @param int $user_id
	 * @param int $course_id
	 */
	public static function resume_timer( $user_id, $course_id ) {
		global $wpdb;

		$timer = self::get_timer( $user_id, $course_id );

		if ( ! $timer ) {
			return self::start_timer( $user_id, $course_id );
		}

		if ( 'expired' === $timer->status ) {
			return array( 'error' => __( 'Your access to this course has expired.', 'academy-pro' ) );
		}

		$now = time();
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- custom query with no WP API equivalent
		$wpdb->update(
			self::table(),
			array(
				'last_start_time' => $now,
				'last_activity'   => $now,
				'status'          => 'active',
				'updated_at'      => current_time( 'mysql' ),
			),
			array(
				'user_id' => (int) $user_id,
				'course_id' => (int) $course_id
			),
			array( '%d', '%d', '%s', '%s' ),
			array( '%d', '%d' )
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		$timer->last_start_time = $now;
		$timer->last_activity   = $now;
		$timer->status          = 'active';

		return self::build_response( $timer );
	}

	/**
	 * Heartbeat: called every N seconds from JS.
	 *
	 * Computes actual elapsed since last_start_time, caps it at 2× the nominal
	 * interval to guard against clock skew or missed beats, then resets
	 * last_start_time to now. This naturally handles multiple open tabs:
	 * the first heartbeat to arrive updates last_start_time; subsequent tabs
	 * see near-zero elapsed and contribute negligible time.
	 *
	 * @param int $user_id
	 * @param int $course_id
	 */
	public static function heartbeat( $user_id, $course_id ) {
		global $wpdb;

		$timer = self::get_timer( $user_id, $course_id );

		if ( ! $timer || 'active' !== $timer->status ) {
			return self::build_response( $timer );
		}

		$now     = time();
		$elapsed = max( 0, $now - (int) $timer->last_start_time );

		/*
		 * Cap to 2× the expected interval so a laptop sleeping or a tab being
		 * suspended doesn't bill hours in one jump.
		 *
		 * The interval is read from the server, never from the request. It used
		 * to be a request parameter, which let a student decide how much of
		 * their own allowance each heartbeat consumed: posting interval=1 while
		 * heartbeating every 30s billed 2 seconds per 30 elapsed, stretching a
		 * time-limited course roughly 15× — and lower still with a slower beat.
		 * That defeats the entire feature, so the bound stays server-owned.
		 */
		$elapsed = min( $elapsed, self::get_heartbeat_interval() * 2 );

		$new_consumed = (int) $timer->consumed_time + $elapsed;
		$new_status   = 'active';

		if ( null !== $timer->allowed_time && $new_consumed >= (int) $timer->allowed_time ) {
			$new_consumed = (int) $timer->allowed_time;
			$new_status   = 'expired';
			self::handle_expiry( (int) $user_id, (int) $course_id );
		}

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- custom query with no WP API equivalent
		$wpdb->update(
			self::table(),
			array(
				'consumed_time'   => $new_consumed,
				'last_start_time' => $now,
				'last_activity'   => $now,
				'status'          => $new_status,
				'updated_at'      => current_time( 'mysql' ),
			),
			array(
				'user_id' => (int) $user_id,
				'course_id' => (int) $course_id
			),
			array( '%d', '%d', '%d', '%s', '%s' ),
			array( '%d', '%d' )
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		$timer->consumed_time   = $new_consumed;
		$timer->last_start_time = $now;
		$timer->last_activity   = $now;
		$timer->status          = $new_status;
		if ( 'expired' === $timer->status && 'cancel' === self::get_expiry_action( $course_id ) ) {
			self::reset_timer( $user_id, $course_id );
		}
		return self::build_response( $timer );
	}

	/**
	 * Runs when a timer runs out, from every path that can detect it (heartbeat
	 * and pause), so an expired "Cancel Enrollment" course ends up the same way
	 * whichever path noticed first: the enrollment is removed. Pause used to
	 * only flag it `cancel`, which the admin Students list shows as "pending"
	 * rather than removing it, unlike heartbeat.
	 *
	 * @param int $user_id
	 * @param int $course_id
	 */
	private static function handle_expiry( $user_id, $course_id ) {
		do_action( 'academy_pro/course_timer/before_expire', $user_id, $course_id );

		if ( 'cancel' === self::get_expiry_action( $course_id ) ) {
			if ( class_exists( '\AcademyProEnrollment\Helper' ) ) {
				\AcademyProEnrollment\Helper::cancel_enroll( $course_id, $user_id );
			} else {
				$enrolled = \Academy\Helper::is_enrolled( $course_id, $user_id, 'any' );
				if ( $enrolled ) {
					\Academy\Helper::update_enrollment_status( $course_id, $enrolled->ID, $user_id, 'cancel' );
				}
			}
		}

		do_action( 'academy_pro/course_timer/after_expire', $user_id, $course_id );
	}


	public static function reset_timer( $user_id, $course_id ) {
		global $wpdb;
		$allowed = self::get_course_allowed_time( $course_id );
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- custom query with no WP API equivalent
		$wpdb->update(
			self::table(),
			array(
				'consumed_time'   => 0,
				'last_start_time' => null,
				'last_activity'   => null,
				'allowed_time'    => $allowed,
				'status'          => 'not_started',
				'updated_at'      => current_time( 'mysql' ),
			),
			array(
				'user_id' => (int) $user_id,
				'course_id' => (int) $course_id
			),
			array( '%d', '%s', '%s', null === $allowed ? '%s' : '%d', '%s', '%s' ),
			array( '%d', '%d' )
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	}


	public static function get_courses_with_timers( $page, $per_page, $search ) {
		$args = array(
			'post_type'      => 'academy_courses',
			'post_status'    => 'publish',
			'posts_per_page' => (int) $per_page,
			'paged'          => max( 1, (int) $page ),
			// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
			'meta_key'       => 'academy_course_timer_enabled',
			// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
			'meta_value'     => '1',
		);
		if ( ! empty( $search ) ) {
			$args['s'] = sanitize_text_field( $search );
		}
		$query = new \WP_Query( $args );

		$courses = array();
		foreach ( $query->posts as $post ) {
			$courses[] = array(
				'id'             => $post->ID,
				'title'          => $post->post_title,
				'timer_duration' => self::get_course_allowed_time( $post->ID ),
				'expiry_action'  => self::get_expiry_action( $post->ID ),
				'enrolled_count' => self::get_enrolled_count( $post->ID ),
			);
		}

		return array(
			'items' => $courses,
			'total' => (int) $query->found_posts,
		);
	}

	/**
	 * Returns timer rows joined with user data, paginated.
	 * Single indexed join query — avoids N+1 meta lookups.
	 *
	 * @param int $course_id
	 * @param int $page
	 * @param int $per_page
	 */
	public static function get_student_timers( $course_id, $page, $per_page ) {
		global $wpdb;

		$table  = self::table();
		$offset = ( max( 1, (int) $page ) - 1 ) * (int) $per_page;

		/*
		 * The only interpolated value is the table name, which is an internal
		 * constant and cannot be bound as a placeholder; every caller-supplied
		 * value below goes through prepare(). Scoped as a block because the
		 * statement spans several lines, so a single-line ignore misses it.
		 */
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPressVIPMinimum.Variables.RestrictedVariables.user_meta__wpdb__users -- reporting JOIN on users/usermeta that get_users() cannot express
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT t.*, u.display_name, u.user_email
				 FROM {$table} t
				 INNER JOIN {$wpdb->users} u ON t.user_id = u.ID
				 WHERE t.course_id = %d
				 ORDER BY t.last_activity DESC
				 LIMIT %d OFFSET %d",
				(int) $course_id,
				(int) $per_page,
				$offset
			)
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPressVIPMinimum.Variables.RestrictedVariables.user_meta__wpdb__users

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- custom table count.
		$total = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$table} WHERE course_id = %d",
				(int) $course_id
			)
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		$students = array();
		foreach ( $rows as $row ) {
			$remaining = null;
			if ( null !== $row->allowed_time ) {
				$remaining = max( 0, (int) $row->allowed_time - (int) $row->consumed_time );
			}
			$students[] = array(
				'user_id'       => (int) $row->user_id,
				'display_name'  => $row->display_name,
				'user_email'    => $row->user_email,
				'status'        => $row->status,
				'consumed_time' => (int) $row->consumed_time,
				'allowed_time'  => null !== $row->allowed_time ? (int) $row->allowed_time : null,
				'remaining'     => $remaining,
				'last_activity' => $row->last_activity ? (int) $row->last_activity : null,
			);
		}

		return array(
			'items' => $students,
			'total' => $total
		);
	}

	/**
	 * Builds the standard response array sent to the frontend JS.
	 *
	 * @param mixed $timer
	 */
	public static function build_response( $timer ) {
		if ( ! $timer ) {
			return array(
				'status'        => 'not_started',
				'consumed_time' => 0,
				'allowed_time'  => null,
				'remaining'     => null,
				'server_time'   => time(),
			);
		}

		$remaining = null;
		if ( null !== $timer->allowed_time ) {
			$remaining = max( 0, (int) $timer->allowed_time - (int) $timer->consumed_time );
		}

		return array(
			'status'        => $timer->status,
			'consumed_time' => (int) $timer->consumed_time,
			'allowed_time'  => null !== $timer->allowed_time ? (int) $timer->allowed_time : null,
			'remaining'     => $remaining,
			'server_time'   => time(),
		);
	}

	public static function get_enrolled_count( $course_id ) {
		// Count via found_posts instead of loading every enrolment ID.
		$query = new \WP_Query( array(
			'post_type'              => 'academy_enrolled',
			'post_parent'            => (int) $course_id,
			'post_status'            => 'completed',
			'posts_per_page'         => 1,
			'fields'                 => 'ids',
			'update_post_meta_cache' => false,
			'update_post_term_cache' => false,
		) );
		return (int) $query->found_posts;
	}

	/**
	 * Seconds → "HH:MM:SS" string.
	 *
	 * @param mixed $seconds
	 */
	public static function format_seconds( $seconds ) {
		if ( null === $seconds ) {
			return __( 'Unlimited', 'academy-pro' );
		}
		$seconds = max( 0, (int) $seconds );
		return sprintf(
			'%02d:%02d:%02d',
			floor( $seconds / 3600 ),
			floor( ( $seconds % 3600 ) / 60 ),
			$seconds % 60
		);
	}
}
