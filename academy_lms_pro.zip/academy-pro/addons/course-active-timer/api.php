<?php
namespace AcademyProCourseActiveTimer;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * REST equivalent of Ajax\Frontend — same three actions (start, heartbeat,
 * get_status), same authorization (enrolled + timer-enabled), same response
 * shape, just reachable over academy_pro/v1 for non-WordPress clients (the
 * zenappbuilder mobile app) instead of admin-ajax.php + a nonce.
 */
class Api {

	public static function init() {
		$self = new self();
		add_action( 'rest_api_init', array( $self, 'register_routes' ) );
	}

	public function register_routes() {
		$namespace = ACADEMY_PRO_PLUGIN_SLUG . '/v1';
		$base      = 'course-active-timer';
		$args      = array(
			'course_id' => array(
				'description'       => esc_html__( 'Course ID.', 'academy-pro' ),
				'type'              => 'integer',
				'required'          => true,
				'sanitize_callback' => 'absint',
			),
		);

		register_rest_route(
			$namespace,
			'/' . $base . '/start',
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'start' ),
				'permission_callback' => array( $this, 'permissions_check' ),
				'args'                => $args,
			)
		);

		register_rest_route(
			$namespace,
			'/' . $base . '/heartbeat',
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'heartbeat' ),
				'permission_callback' => array( $this, 'permissions_check' ),
				'args'                => $args,
			)
		);

		register_rest_route(
			$namespace,
			'/' . $base . '/status',
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_status' ),
				'permission_callback' => array( $this, 'permissions_check' ),
				'args'                => $args,
			)
		);
	}

	public function permissions_check( $request ) {
		if ( ! is_user_logged_in() ) {
			return new \WP_Error(
				'rest_forbidden_context',
				esc_html__( 'You must be logged in.', 'academy-pro' ),
				array( 'status' => rest_authorization_required_code() )
			);
		}
		return true;
	}

	public function start( $request ) {
		return $this->handle( $request, array( Helper::class, 'start_timer' ) );
	}

	public function heartbeat( $request ) {
		return $this->handle( $request, array( Helper::class, 'heartbeat' ) );
	}

	public function get_status( $request ) {
		$course_id = (int) $request->get_param( 'course_id' );
		$user_id   = get_current_user_id();

		$denied = $this->check_access( $course_id, $user_id );
		if ( null !== $denied ) {
			return $denied;
		}

		$timer = Helper::get_timer( $user_id, $course_id );
		return new \WP_REST_Response( $this->add_course_context( Helper::build_response( $timer ), $course_id ), 200 );
	}

	/**
	 * Shared body for start/heartbeat: both take just course_id, run the same
	 * enrolled + timer-enabled checks, and call a Helper method that returns
	 * either an ['error' => ...] array or a state array ready for build_response-
	 * style output.
	 *
	 * @param \WP_REST_Request $request
	 * @param mixed            $callback
	 */
	private function handle( $request, $callback ) {
		$course_id = (int) $request->get_param( 'course_id' );
		$user_id   = get_current_user_id();

		$denied = $this->check_access( $course_id, $user_id );
		if ( null !== $denied ) {
			return $denied;
		}

		$result = call_user_func( $callback, $user_id, $course_id );
		if ( isset( $result['error'] ) ) {
			return new \WP_REST_Response( array( 'error' => $result['error'] ), 400 );
		}

		return new \WP_REST_Response( $this->add_course_context( $result, $course_id ), 200 );
	}

	/**
	 * @param int $course_id
	 * @param int $user_id
	 *
	 * @return \WP_Error|null Null when access is fine.
	 */
	private function check_access( $course_id, $user_id ) {
		if ( ! $course_id || ! $user_id ) {
			return new \WP_Error( 'invalid_request', esc_html__( 'Invalid request.', 'academy-pro' ), array( 'status' => 400 ) );
		}

		if ( ! Helper::is_timer_enabled( $course_id ) ) {
			return new \WP_Error( 'timer_disabled', esc_html__( 'Course Active Timer is not enabled for this course.', 'academy-pro' ), array( 'status' => 400 ) );
		}

		// Matches the AJAX handler: without this, any logged-in user could drive
		// timer rows for courses they have no access to.
		if ( ! \Academy\Helper::is_enrolled( $course_id, $user_id, 'any' ) ) {
			return new \WP_Error( 'not_enrolled', esc_html__( 'You are not enrolled in this course.', 'academy-pro' ), array( 'status' => 403 ) );
		}

		return null;
	}

	private function add_course_context( $response, $course_id ) {
		$response['course_url'] = get_permalink( $course_id );
		return $response;
	}
}
