<?php
namespace AcademyProCourseActiveTimer;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AcademyProCourseActiveTimer\Ajax\Frontend;
use AcademyProCourseActiveTimer\Ajax\Admin;

class Ajax {
	public static function init() {
		( new Frontend() )->dispatch_actions();
		( new Admin() )->dispatch_actions();
	}
}
