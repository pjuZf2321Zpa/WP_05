<?php
namespace AcademyProCourseActiveTimer\Ajax;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Academy\Classes\AbstractAjaxHandler;
use Academy\Classes\Sanitizer;
use AcademyProCourseActiveTimer\Helper;

/**
 * Handles admin monitoring AJAX actions.
 *
 * Namespace: "academy_pro/course-active-timer/admin"
 *   - get_courses : paginated list of courses with timer enabled
 *   - get_students: paginated list of enrolled students + their timer data
 *   - reset_timer : admin resets a specific student's timer
 */
class Admin extends AbstractAjaxHandler {

	protected $namespace = ACADEMY_PLUGIN_SLUG . '_pro/admin/course-active-timer';

	public function __construct() {
		$this->actions = array(
			'get_courses'  => array(
				'callback' => array( $this, 'get_courses' ),
				'capability' => 'manage_options'
			),
			'get_students' => array(
				'callback' => array( $this, 'get_students' ),
				'capability' => 'manage_options'
			),
			'reset_timer'  => array(
				'callback' => array( $this, 'reset_timer' ),
				'capability' => 'manage_options'
			),
		);
	}

	// ── Handlers ────────────────────────────────────────────────────────────────

	/**
	 * Courses listed on the course timer admin screen, paginated and searchable.
	 *
	 * @param array $payload_data
	 */
	public function get_courses( $payload_data ) {
		$payload  = Sanitizer::sanitize_payload(
			array(
				'page' => 'integer',
				'per_page' => 'integer',
				'search' => 'string'
			),
			$payload_data
		);
		$page     = max( 1, (int) ( $payload['page'] ?? 1 ) );
		$per_page = max( 1, min( 100, (int) ( $payload['per_page'] ?? 20 ) ) );
		$search   = sanitize_text_field( $payload['search'] ?? '' );

		$data = Helper::get_courses_with_timers( $page, $per_page, $search );

		header( 'X-WP-Total: ' . $data['total'] );
		wp_send_json_success( $data['items'] );
	}

	public function get_students( $payload_data ) {
		$payload   = Sanitizer::sanitize_payload(
			array(
				'course_id' => 'integer',
				'page' => 'integer',
				'per_page' => 'integer'
			),
			$payload_data
		);
		$course_id = (int) ( $payload['course_id'] ?? 0 );
		$page      = max( 1, (int) ( $payload['page'] ?? 1 ) );
		$per_page  = max( 1, min( 100, (int) ( $payload['per_page'] ?? 20 ) ) );

		if ( ! $course_id ) {
			wp_send_json_error( __( 'Invalid course ID.', 'academy-pro' ) );
		}

		$data = Helper::get_student_timers( $course_id, $page, $per_page );

		header( 'X-WP-Total: ' . $data['total'] );
		wp_send_json_success( $data['items'] );
	}

	public function reset_timer( $payload_data ) {
		$payload   = Sanitizer::sanitize_payload(
			array(
				'course_id' => 'integer',
				'user_id' => 'integer'
			),
			$payload_data
		);
		$course_id = (int) ( $payload['course_id'] ?? 0 );
		$user_id   = (int) ( $payload['user_id'] ?? 0 );

		if ( ! $course_id || ! $user_id ) {
			wp_send_json_error( __( 'Invalid parameters.', 'academy-pro' ) );
		}

		Helper::reset_timer( $user_id, $course_id );

		wp_send_json_success( __( 'Timer reset successfully.', 'academy-pro' ) );
	}
}
