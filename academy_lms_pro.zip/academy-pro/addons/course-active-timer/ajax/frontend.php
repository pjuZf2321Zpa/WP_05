<?php
namespace AcademyProCourseActiveTimer\Ajax;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Academy\Classes\AbstractAjaxHandler;
use Academy\Classes\Sanitizer;
use AcademyProCourseActiveTimer\Helper;

/**
 * Handles all student-facing timer AJAX actions.
 *
 * Registered actions (prefixed with namespace "academy_pro/course-active-timer"):
 *   - start      : first open of course page; creates row if needed, sets active
 *   - heartbeat  : sent every 30 s; accurate billing of active time
 *   - get_status : retrieve current timer state (used on initial page load)
 */
class Frontend extends AbstractAjaxHandler {

	protected $namespace = ACADEMY_PLUGIN_SLUG . '_pro/course-active-timer';

	public function __construct() {
		$this->actions = array(
			'start'      => array(
				'callback' => array( $this, 'start' ),
				'capability' => 'read'
			),
			'heartbeat'  => array(
				'callback' => array( $this, 'heartbeat' ),
				'capability' => 'read'
			),
			'get_status' => array(
				'callback' => array( $this, 'get_status' ),
				'capability' => 'read'
			),
		);
	}

	// ── Handlers ────────────────────────────────────────────────────────────────

	/**
	 * Starts or resumes the current user's timer for a course.
	 *
	 * @param array $payload_data
	 */
	public function start( $payload_data ) {
		$payload   = Sanitizer::sanitize_payload( array( 'course_id' => 'integer' ), $payload_data );
		$course_id = (int) ( $payload['course_id'] ?? 0 );
		$user_id   = get_current_user_id();

		if ( ! $course_id || ! $user_id ) {
			wp_send_json_error( __( 'Invalid request.', 'academy-pro' ) );
		}

		if ( ! Helper::is_timer_enabled( $course_id ) ) {
			wp_send_json_error( array( 'code' => 'timer_disabled' ) );
		}

		if ( ! \Academy\Helper::is_enrolled( $course_id, $user_id, 'any' ) ) {
			wp_send_json_error( __( 'You are not enrolled in this course.', 'academy-pro' ) );
		}

		$result = Helper::start_timer( $user_id, $course_id );
		if ( isset( $result['error'] ) ) {
			wp_send_json_error( $result['error'] );
		}

		wp_send_json_success( $this->add_course_context( $result, $course_id ) );
	}

	public function heartbeat( $payload_data ) {
		// `interval` is deliberately not read from the payload — the amount of
		// allowance a heartbeat may consume is decided server-side.
		$payload   = Sanitizer::sanitize_payload( array( 'course_id' => 'integer' ), $payload_data );
		$course_id = (int) ( $payload['course_id'] ?? 0 );
		$user_id   = get_current_user_id();

		if ( ! $course_id || ! $user_id ) {
			wp_send_json_error( __( 'Invalid request.', 'academy-pro' ) );
		}

		if ( ! Helper::is_timer_enabled( $course_id ) ) {
			wp_send_json_error( array( 'code' => 'timer_disabled' ) );
		}

		// Matches start() and get_status(); without it any logged-in user could
		// drive timer rows for courses they have no access to.
		if ( ! \Academy\Helper::is_enrolled( $course_id, $user_id, 'any' ) ) {
			wp_send_json_error( __( 'You are not enrolled in this course.', 'academy-pro' ) );
		}

		wp_send_json_success( $this->add_course_context( Helper::heartbeat( $user_id, $course_id ), $course_id ) );
	}

	public function get_status( $payload_data ) {
		$payload   = Sanitizer::sanitize_payload( array( 'course_id' => 'integer' ), $payload_data );
		$course_id = (int) ( $payload['course_id'] ?? 0 );
		$user_id   = get_current_user_id();

		if ( ! $course_id || ! $user_id ) {
			wp_send_json_error( __( 'Invalid request.', 'academy-pro' ) );
		}

		if ( ! \Academy\Helper::is_enrolled( $course_id, $user_id, 'any' ) ) {
			wp_send_json_error( array( 'code' => __( 'You are not enrolled in this course.', 'academy-pro' ) ) );
		}

		if ( ! Helper::is_timer_enabled( $course_id ) ) {
			wp_send_json_error( array( 'code' => 'timer_disabled' ) );
		}

		$timer = Helper::get_timer( $user_id, $course_id );
		wp_send_json_success( $this->add_course_context( Helper::build_response( $timer ), $course_id ) );
	}

	private function add_course_context( $response, $course_id ) {
		$response['course_url'] = get_permalink( $course_id );
		return $response;
	}
}
