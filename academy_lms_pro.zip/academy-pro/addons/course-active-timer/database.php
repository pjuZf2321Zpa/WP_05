<?php
namespace AcademyProCourseActiveTimer;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AcademyProCourseActiveTimer\Database\CreateCourseTimersTable;

class Database {
	public static function init() {
		CreateCourseTimersTable::init();
	}
}
