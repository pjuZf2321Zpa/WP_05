<?php
namespace AcademyProCourseActiveTimer;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Hooks {

	public static function init() {
		$self = new self();

		// Create timer row on enrollment.
		add_action( 'academy/course/after_enroll', array( $self, 'on_enroll' ), 10, 3 );

		// Treat expired enrollment as unenrolled when expiry_action = 'cancel'.
		add_filter( 'academy/course/is_enrolled', array( $self, 'filter_enrollment_if_expired' ), 13, 3 );

		// Hide course complete button
		add_filter( 'academy/single/is_show_complete_form', array( $self, 'filter_course_complete_button' ), 13, 3 );

		// Replace the entire enroll form with an expired notice when timer is expired.
		add_filter( 'academy/templates/single_course/enroll_form', array( $self, 'filter_expired_enroll_form' ), 13, 2 );

		// Register post meta so course builder can read/write via REST API.
		add_action( 'rest_api_init', array( $self, 'register_course_meta' ) );
		add_action( 'init', array( $self, 'register_course_meta' ) );
	}

	// ── Enrollment ─────────────────────────────────────────────────────────────

	/**
	 * Creates the student's course timer when they enroll.
	 *
	 * @param int $course_id
	 * @param int $enrolled_id
	 * @param int $user_id
	 */
	public function on_enroll( $course_id, $enrolled_id, $user_id ) {
		$allowed = Helper::get_course_allowed_time( $course_id );
		if ( get_post_meta( $course_id, 'academy_course_timer_enabled', true ) ) {
			Helper::create_timer( (int) $user_id, (int) $course_id, $allowed );
		}
	}

	// ── Access control ─────────────────────────────────────────────────────────

	/**
	 * Blocks AJAX lesson render (React curriculum player).
	 * Fires before lesson data is returned to the frontend.
	 *
	 * @param mixed $lesson
	 * @param int   $course_id
	 * @param int   $lesson_id
	 */
	public function check_lesson_access_ajax( $lesson, $course_id, $lesson_id ) {
		$user_id = get_current_user_id();
		if ( ! $user_id ) {
			return;
		}
		if ( Helper::is_expired( $user_id, $course_id ) ) {
			wp_send_json_error(
				array(
					'message' => __( 'Your course access time has expired. You can no longer view lessons.', 'academy-pro' ),
					'code'    => 'timer_expired',
				)
			);
		}
	}

	/**
	 * Blocks PHP-rendered lesson content (legacy curriculum template).
	 *
	 * @param mixed $lesson
	 * @param int   $course_id
	 * @param int   $topic_id
	 */
	public function check_lesson_access_php( $lesson, $course_id, $topic_id ) {
		$user_id = get_current_user_id();
		if ( ! $user_id ) {
			return;
		}
		if ( Helper::is_expired( $user_id, $course_id ) ) {
			add_filter( 'academy/templates/curriculums/has_access_lesson_content', '__return_false' );
		}
	}

	/**
	 * When is_enrolled() is called, return false if timer expired and action = 'cancel'.
	 * For 'lock' action, enrollment stays; only lesson access is blocked.
	 *
	 * @param mixed $enrolled
	 * @param int   $course_id
	 * @param int   $user_id
	 */
	public function filter_enrollment_if_expired( $enrolled, $course_id, $user_id ) {
		if ( ! $enrolled || 'completed' !== $enrolled->enrolled_status ) {
			return $enrolled;
		}
		if ( ! Helper::is_expired( $user_id, $course_id ) ) {
			return $enrolled;
		}
		if ( 'cancel' === Helper::get_expiry_action( $course_id ) ) {
			return false;
		}
		return $enrolled;
	}

	public function filter_expired_enroll_form( $html, $course_id ) {
		$user_id = get_current_user_id();
		if ( ! $user_id || ! Helper::is_timer_enabled( $course_id ) || ! Helper::is_expired( $user_id, $course_id ) ) {
			return $html;
		}

		if ( 'cancel_enrollment' === get_post_meta( $course_id, 'academy_course_timer_expiry_action', true ) ) {
			return $html;
		}

		$enrolled = \Academy\Helper::is_enrolled( $course_id, $user_id, 'any' );

		if ( ! $enrolled || 'completed' !== $enrolled->enrolled_status ) {
			return $html;
		}

		$current_allowed_time = Helper::get_course_allowed_time( $course_id );
		if ( ! $current_allowed_time ) {
			return $html;
		}

		$timer = Helper::get_timer( $user_id, $course_id );
		if ( $timer && (int) $timer->allowed_time !== $current_allowed_time ) {
			Helper::update_timer( $user_id, $course_id, $current_allowed_time );
			return $html;
		}

		$enrolled_info = sprintf(
			/* translators: %s: enrolment date. */
			esc_html__( 'You have been enrolled on %s', 'academy-pro' ),
			wp_kses_post( '<span>' . date_i18n( get_option( 'date_format' ), strtotime( $enrolled->post_date ) ) . '</span>' )
		);

		ob_start();
		\AcademyPro\Helper::get_template(
			'course-active-timer/course-lock.php',
			array(
				'course_id' => $course_id,
				'enrolled_info' => $enrolled_info
			)
		);

		return ob_get_clean();
	}

	public function filter_course_complete_button( $is_show, $is_complete, $course_id ) {
		if ( ! Helper::get_course_allowed_time( $course_id ) || ! Helper::is_course_locked( get_current_user_id(), $course_id ) ) {
			return $is_show;
		}
		return false;
	}

	// ── REST / post meta ───────────────────────────────────────────────────────

	/**
	 * Registers the course timer post meta for the REST API.
	 */
	public function register_course_meta() {
		$meta_keys = array(
			'academy_course_timer_enabled'        => array(
				'type' => 'boolean',
				'sanitize_callback' => 'rest_sanitize_boolean'
			),
			'academy_course_timer_duration_value' => array(
				'type' => 'integer',
				'sanitize_callback' => 'absint'
			),
			'academy_course_timer_duration_unit'  => array(
				'type' => 'string',
				'sanitize_callback' => 'sanitize_text_field'
			),
			'academy_course_timer_expiry_action'  => array(
				'type' => 'string',
				'sanitize_callback' => 'sanitize_text_field'
			),
		);

		foreach ( $meta_keys as $key => $schema ) {
			register_post_meta(
				'academy_courses',
				$key,
				array(
					'show_in_rest'      => true,
					'single'            => true,
					'type'              => $schema['type'],
					'sanitize_callback' => $schema['sanitize_callback'],
					'auth_callback'     => function () {
						return current_user_can( 'manage_academy_instructor' );
					},
				)
			);
		}
	}
}
