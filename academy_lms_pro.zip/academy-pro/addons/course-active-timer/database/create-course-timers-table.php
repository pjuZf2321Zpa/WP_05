<?php
namespace AcademyProCourseActiveTimer\Database;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CreateCourseTimersTable {

	public static function init() {
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		global $wpdb;

		$charset = $wpdb->get_charset_collate();
		$table   = $wpdb->prefix . 'academy_course_timers';

		/*
		 * Indexing strategy:
		 *  - UNIQUE KEY user_course  — one row per user+course; fast upsert lookups
		 *  - KEY idx_course_id       — admin monitoring queries that list students per course
		 *  - KEY idx_status          — filter queries by status (expired / active)
		 *  - KEY idx_last_activity   — admin sorting by most-recently-active student
		 *
		 * allowed_time NULL = unlimited access (no expiry).
		 * consumed_time / last_start_time are in seconds (Unix timestamps / elapsed seconds).
		 */
		$sql = "CREATE TABLE IF NOT EXISTS {$table} (
			id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			user_id      BIGINT UNSIGNED NOT NULL,
			course_id    BIGINT UNSIGNED NOT NULL,
			allowed_time INT UNSIGNED    NULL     DEFAULT NULL,
			consumed_time INT UNSIGNED   NOT NULL DEFAULT 0,
			last_start_time INT UNSIGNED NULL     DEFAULT NULL,
			status       ENUM('not_started','active','paused','expired') NOT NULL DEFAULT 'not_started',
			last_activity INT UNSIGNED   NULL     DEFAULT NULL,
			created_at   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
			updated_at   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			UNIQUE KEY   user_course     (user_id, course_id),
			KEY          idx_course_id   (course_id),
			KEY          idx_status      (status),
			KEY          idx_last_activity (last_activity)
		) {$charset};";

		dbDelta( $sql );
	}
}
