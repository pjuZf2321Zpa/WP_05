/**
 * Academy LMS — Course Timer Monitor (admin)
 *
 * Two-level drill-down table:
 *   Level 1 → Courses with timer enabled
 *   Level 2 → Students enrolled in a course + their timer state
 */
/* global academyTimerAdmin, jQuery */
(function ($) {
	'use strict';

	var cfg = window.academyTimerAdmin;
	if ( ! cfg ) return;

	var AJAX_URL  = cfg.ajaxUrl;
	var NONCE     = cfg.nonce;
	var i18n      = cfg.i18n || {};
	var PER_PAGE  = 20;
	var NAMESPACE = 'academy_pro/admin/course-active-timer';

	var currentCourseId   = null;
	var currentCourseName = null;

	// ── AJAX helper ────────────────────────────────────────────────────────────

	function ajax( action, data, onSuccess, onError ) {
		$.post(
			AJAX_URL,
			$.extend( { action: NAMESPACE + action, security: NONCE }, data || {} ),
			function ( res ) {
				if ( res && res.success ) { if ( onSuccess ) onSuccess( res.data ); }
				else { if ( onError ) onError( res && res.data ); }
			}
		).fail( function () {
			if ( onError ) onError( null );
		} );
	}

	// ── Formatting ─────────────────────────────────────────────────────────────

	function formatSeconds( secs ) {
		if ( secs === null || secs === undefined ) return i18n.unlimited || 'Unlimited';
		secs = Math.max( 0, Math.floor( secs ) );
		var h = Math.floor( secs / 3600 );
		var m = Math.floor( ( secs % 3600 ) / 60 );
		var s = secs % 60;
		return pad( h ) + ':' + pad( m ) + ':' + pad( s );
	}

	function pad( n ) { return n < 10 ? '0' + n : String( n ); }

	function timeAgo( ts ) {
		if ( ! ts ) return i18n.never || 'Never';
		var diff = Math.floor( Date.now() / 1000 - parseInt( ts, 10 ) );
		if ( diff < 5 )    return 'Just now';
		if ( diff < 60 )   return diff + 's ago';
		if ( diff < 3600 ) return Math.floor( diff / 60 ) + 'm ago';
		if ( diff < 86400) return Math.floor( diff / 3600 ) + 'h ago';
		return Math.floor( diff / 86400 ) + 'd ago';
	}

	function statusBadge( s ) {
		var map = {
			not_started : '<span class="at-badge at-badge--grey">'   + ( i18n.notStarted || 'Not Started' ) + '</span>',
			active      : '<span class="at-badge at-badge--green">'  + ( i18n.active     || 'Active'      ) + '</span>',
			paused      : '<span class="at-badge at-badge--yellow">' + ( i18n.paused     || 'Paused'      ) + '</span>',
			expired     : '<span class="at-badge at-badge--red">'    + ( i18n.expired    || 'Expired'     ) + '</span>',
		};
		return map[ s ] || esc( s );
	}

	function esc( str ) {
		return $( '<div>' ).text( str || '' ).html();
	}

	// ── Pagination ─────────────────────────────────────────────────────────────

	function buildPagination( $container, total, currentPage, onPageClick ) {
		var totalPages = Math.ceil( total / PER_PAGE );
		if ( totalPages <= 1 ) { $container.empty(); return; }

		var html = '<div class="tablenav-pages">';
		for ( var i = 1; i <= totalPages; i++ ) {
			if ( i === currentPage ) {
				html += '<span class="page-numbers current">' + i + '</span>';
			} else {
				html += '<a class="page-numbers at-page-link" href="#" data-page="' + i + '">' + i + '</a>';
			}
		}
		html += '</div>';
		$container.html( html );
		$container.find( '.at-page-link' ).on( 'click', function ( e ) {
			e.preventDefault();
			onPageClick( parseInt( $( this ).data( 'page' ), 10 ) );
		} );
	}

	// ── Courses view ───────────────────────────────────────────────────────────

	function loadCourses( page, search ) {
		page   = page || 1;
		search = search || '';

		var $tbody = $( '#at-courses-tbody' );
		$tbody.html( '<tr><td colspan="5">' + ( i18n.loading || 'Loading…' ) + '</td></tr>' );

		ajax(
			'get_courses',
			{ page: page, per_page: PER_PAGE, search: search },
			function ( data, jqXHR ) {
				var total = parseInt( $( '#at-courses-tbody' ).data( 'total' ) || 0, 10 );
				// Try to get total from custom response header (set server-side).
				// We can't read it directly from the $.post callback; instead the
				// server echoes it in data or we fall back to list length heuristic.
				total = data.length < PER_PAGE
					? ( page - 1 ) * PER_PAGE + data.length
					: page * PER_PAGE + 1;

				if ( ! data.length ) {
					$tbody.html( '<tr><td colspan="5">' + ( i18n.noResults || 'No results found.' ) + '</td></tr>' );
					$( '#at-courses-pagination' ).empty();
					return;
				}

				var html = '';
				$.each( data, function ( idx, course ) {
					html +=
						'<tr>' +
							'<td><strong>' + esc( course.title ) + '</strong></td>' +
							'<td>' + formatSeconds( course.timer_duration ) + '</td>' +
							'<td>' + esc( course.expiry_action ) + '</td>' +
							'<td>' + parseInt( course.enrolled_count, 10 ) + '</td>' +
							'<td>' +
								'<button class="button button-small at-view-students" ' +
									'data-id="' + parseInt( course.id, 10 ) + '" ' +
									'data-title="' + esc( course.title ) + '">' +
									( i18n.viewStudents || 'View Students' ) +
								'</button>' +
							'</td>' +
						'</tr>';
				} );
				$tbody.html( html );

				buildPagination( $( '#at-courses-pagination' ), total, page, function ( p ) {
					loadCourses( p, search );
				} );
			},
			function () {
				$tbody.html( '<tr><td colspan="5">Failed to load courses.</td></tr>' );
			}
		);
	}

	// ── Students view ──────────────────────────────────────────────────────────

	function loadStudents( courseId, page ) {
		page = page || 1;
		var $tbody = $( '#at-students-tbody' );
		$tbody.html( '<tr><td colspan="7">' + ( i18n.loading || 'Loading…' ) + '</td></tr>' );

		ajax(
			'get_students',
			{ course_id: courseId, page: page, per_page: PER_PAGE },
			function ( data ) {
				if ( ! data.length ) {
					$tbody.html( '<tr><td colspan="7">' + ( i18n.noResults || 'No results found.' ) + '</td></tr>' );
					$( '#at-students-pagination' ).empty();
					return;
				}

				var html = '';
				$.each( data, function ( idx, s ) {
					html +=
						'<tr>' +
							'<td>' + esc( s.display_name ) + '</td>' +
							'<td>' + esc( s.user_email ) + '</td>' +
							'<td>' + statusBadge( s.status ) + '</td>' +
							'<td>' + formatSeconds( s.consumed_time ) + '</td>' +
							'<td>' + formatSeconds( s.remaining ) + '</td>' +
							'<td>' + timeAgo( s.last_activity ) + '</td>' +
							'<td>' +
								'<button class="button button-small at-reset-btn" ' +
									'data-uid="' + parseInt( s.user_id, 10 ) + '" ' +
									'data-cid="' + parseInt( courseId, 10 ) + '">' +
									( i18n.reset || 'Reset' ) +
								'</button>' +
							'</td>' +
						'</tr>';
				} );
				$tbody.html( html );

				buildPagination( $( '#at-students-pagination' ), data.length < PER_PAGE
					? ( page - 1 ) * PER_PAGE + data.length
					: page * PER_PAGE + 1,
				page, function ( p ) {
					loadStudents( courseId, p );
				} );
			},
			function () {
				$tbody.html( '<tr><td colspan="7">Failed to load students.</td></tr>' );
			}
		);
	}

	// ── Events ─────────────────────────────────────────────────────────────────

	$( function () {
		// Initial load
		loadCourses( 1, '' );

		// Search
		$( '#at-search-btn' ).on( 'click', function () {
			loadCourses( 1, $( '#at-search' ).val() );
		} );
		$( '#at-search' ).on( 'keypress', function ( e ) {
			if ( 13 === e.which ) loadCourses( 1, $( this ).val() );
		} );

		// Drill into course
		$( document ).on( 'click', '.at-view-students', function () {
			currentCourseId   = $( this ).data( 'id' );
			currentCourseName = $( this ).data( 'title' );
			$( '#at-courses-view' ).hide();
			$( '#at-students-view' ).show();
			$( '#at-course-title' ).text( currentCourseName );
			loadStudents( currentCourseId, 1 );
		} );

		// Back to courses
		$( '#at-back-btn' ).on( 'click', function () {
			$( '#at-students-view' ).hide();
			$( '#at-courses-view' ).show();
		} );

		// Reset timer
		$( document ).on( 'click', '.at-reset-btn', function () {
			// eslint-disable-next-line no-alert
			if ( ! window.confirm( i18n.confirmReset || "Reset this student's timer? This cannot be undone." ) ) return;

			var $btn = $( this );
			var uid  = $btn.data( 'uid' );
			var cid  = $btn.data( 'cid' );
			$btn.prop( 'disabled', true ).text( i18n.resetting || 'Resetting…' );

			ajax(
				'reset_timer',
				{ user_id: uid, course_id: cid },
				function () {
					loadStudents( currentCourseId, 1 );
				},
				function ( err ) {
					// eslint-disable-next-line no-alert
					window.alert( err || i18n.resetFailed || 'Failed to reset timer.' );
					$btn.prop( 'disabled', false ).text( i18n.reset || 'Reset' );
				}
			);
		} );
	} );

} )( jQuery );
