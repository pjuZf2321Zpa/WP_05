/**
 * Academy LMS — Course Active Timer (frontend)
 *
 * Responsibilities:
 *  - Show a floating widget with remaining time and status
 *  - Send start/pause/resume/heartbeat AJAX actions
 *  - Detect tab visibility changes and page unload
 *  - Show an overlay when the timer expires
 *
 * Server is the source of truth. Client-side countdown is display-only
 * and is corrected on every heartbeat response.
 */
/* global academyCourseTimer, jQuery */
(function ($) {
	'use strict';

	var cfg = window.academyCourseTimer;
	if ( ! cfg ) return;

	// ── Config ─────────────────────────────────────────────────────────────────

	var AJAX_URL       = cfg.ajaxUrl;
	var NONCE          = cfg.nonce;
	var COURSE_ID      = cfg.courseId;
	var INTERVAL_SEC   = cfg.heartbeatInterval || 30;
	var i18n           = cfg.i18n || {};
	var NAMESPACE      = 'academy_pro/course-active-timer/';

	// ── State ──────────────────────────────────────────────────────────────────

	var consumed     = parseInt( cfg.timerData.consumed_time, 10 ) || 0;
	var allowed      = cfg.timerData.allowed_time !== null
		? parseInt( cfg.timerData.allowed_time, 10 )
		: null;
	var status       = cfg.timerData.status || 'not_started';
	var destroyed    = false;

	var heartbeatTimer  = null;
	var countdownTimer  = null;
	var lastTickAt      = null;  // Date.now() reference for client-side tick
	var $widget         = null;

	// ── Utility ────────────────────────────────────────────────────────────────

	function formatSeconds( secs ) {
		if ( secs === null || secs === undefined ) return i18n.unlimited || 'Unlimited';
		secs = Math.max( 0, Math.floor( secs ) );
		var h = Math.floor( secs / 3600 );
		var m = Math.floor( ( secs % 3600 ) / 60 );
		var s = secs % 60;
		return pad( h ) + ':' + pad( m ) + ':' + pad( s );
	}

	function pad( n ) { return n < 10 ? '0' + n : String( n ); }

	function remaining() {
		return allowed !== null ? Math.max( 0, allowed - consumed ) : null;
	}

	function statusLabel() {
		var map = {
			not_started : i18n.paused   || 'Paused',
			active      : i18n.active   || 'Active',
			paused      : i18n.paused   || 'Paused',
			expired     : i18n.expired  || 'Expired',
		};
		return map[ status ] || status;
	}

	// ── AJAX ───────────────────────────────────────────────────────────────────

	function ajax( action, extra, onSuccess, onError ) {
		$.post(
			AJAX_URL,
			$.extend(
				{ action: NAMESPACE + action, security: NONCE, course_id: COURSE_ID },
				extra || {}
			),
			function ( res ) {
				if ( res && res.success ) {
					if ( onSuccess ) onSuccess( res.data );
				} else {
					if ( onError ) onError( res && res.data );
				}
			}
		).fail( function () {
			// Network error — swallow silently; next heartbeat will recover.
		} );
	}

	/**
	 * sendBeacon is used in beforeunload because regular XHR is unreliable
	 * when the browser is navigating away.
	 */
	function sendBeaconPause() {
		if ( 'active' !== status || ! navigator.sendBeacon ) return;
		var fd = new FormData();
		fd.append( 'action',    NAMESPACE + 'pause' );
		fd.append( 'security',  NONCE );
		fd.append( 'course_id', COURSE_ID );
		navigator.sendBeacon( AJAX_URL, fd );
	}

	// ── Widget ─────────────────────────────────────────────────────────────────

	function buildWidget() {
		if ( $( '#academy-timer-widget' ).length ) {
			$widget = $( '#academy-timer-widget' );
			return;
		}
		$widget = $(
			'<div id="academy-timer-widget" class="academy-timer-widget" aria-live="polite">' +
				'<span class="at-status-dot"></span>' +
				'<span class="at-label"></span>' +
				'<span class="at-display"></span>' +
			'</div>'
		);
		$( 'body' ).append( $widget );
	}

	function refreshWidget() {
		if ( ! $widget ) return;
		var rem = remaining();
		$widget
			.attr( 'data-status', status )
			.find( '.at-label' ).text( statusLabel() ).end()
			.find( '.at-display' ).text( formatSeconds( rem ) );
	}

	// ── Countdown (client-side display only) ───────────────────────────────────

	function startCountdown() {
		stopCountdown();
		lastTickAt    = Date.now();
		countdownTimer = setInterval( function () {
			if ( 'active' !== status ) { stopCountdown(); return; }

			var now   = Date.now();
			var delta = Math.floor( ( now - lastTickAt ) / 1000 );
			lastTickAt = now;
			consumed  += delta;

			if ( allowed !== null && consumed >= allowed ) {
				consumed = allowed;
				onExpire();
				return;
			}
			refreshWidget();
		}, 1000 );
	}

	function stopCountdown() {
		if ( countdownTimer ) { clearInterval( countdownTimer ); countdownTimer = null; }
	}

	// ── Heartbeat ──────────────────────────────────────────────────────────────

	function startHeartbeat() {
		stopHeartbeat();
		heartbeatTimer = setInterval( doHeartbeat, INTERVAL_SEC * 1000 );
	}

	function stopHeartbeat() {
		if ( heartbeatTimer ) { clearInterval( heartbeatTimer ); heartbeatTimer = null; }
	}

	function doHeartbeat() {
		if ( 'active' !== status || destroyed ) return;
		// No interval is sent: how much allowance a heartbeat consumes is
		// decided server-side, so passing it here would only be misleading.
		ajax(
			'heartbeat',
			{},
			function ( data ) { syncFromServer( data ); },
			function ( err ) {
				if ( err && err.expired ) { onExpire(); }
			}
		);
	}

	// ── Server sync ────────────────────────────────────────────────────────────

	/**
	 * Overwrite local state with authoritative server values.
	 * Called after every AJAX response so the client stays in sync.
	 */
	function syncFromServer( data ) {
		if ( ! data ) return;
		consumed = parseInt( data.consumed_time, 10 ) || 0;
		allowed  = data.allowed_time !== null ? parseInt( data.allowed_time, 10 ) : null;
		status   = data.status || status;

		if ( 'expired' === status ) { onExpire(); return; }
		if ( 'active' === status ) { startCountdown(); }
		refreshWidget();
	}

	// ── State transitions ──────────────────────────────────────────────────────

	function doStart() {
		ajax( 'start', {}, function ( data ) {
			syncFromServer( data );
			if ( 'active' === status ) { startHeartbeat(); }
		} );
	}

	function doPause() {
		if ( 'active' !== status ) return;
		stopCountdown();
		stopHeartbeat();
		status = 'paused';
		refreshWidget();
		// Fire-and-forget; if it fails the server will reconcile on next resume.
		ajax( 'pause' );
	}

	function doResume() {
		if ( 'active' === status ) return; // Already running (another tab just started).
		ajax( 'resume', {}, function ( data ) {
			syncFromServer( data );
			if ( 'active' === status ) { startHeartbeat(); startCountdown(); }
		}, function ( err ) {
			if ( err && err.expired ) { onExpire(); }
		} );
	}

	function onExpire() {
		status = 'expired';
		stopCountdown();
		stopHeartbeat();
		refreshWidget();
		showExpiredOverlay();
	}

	function showExpiredOverlay() {
		if ( $( '.academy-timer-expired-overlay' ).length ) return;
		var msg = i18n.timeUp || 'Your course access time has expired.';
		$( 'body' ).append(
			'<div class="academy-timer-expired-overlay" role="alertdialog">' +
				'<div class="academy-timer-expired-box">' +
					'<div class="at-expired-icon">&#9201;</div>' +
					'<h2>' + msg + '</h2>' +
					'<p>' + ( i18n.expiredHint || 'Please contact your administrator.' ) + '</p>' +
				'</div>' +
			'</div>'
		);
	}

	// ── Browser events ─────────────────────────────────────────────────────────

	document.addEventListener( 'visibilitychange', function () {
		if ( destroyed ) return;
		if ( document.hidden ) {
			doPause();
		} else {
			doResume();
		}
	} );

	window.addEventListener( 'beforeunload', function () {
		destroyed = true;
		stopCountdown();
		stopHeartbeat();
		sendBeaconPause();
	} );

	// ── Boot ───────────────────────────────────────────────────────────────────

	$( function () {
		buildWidget();

		if ( 'expired' === status ) {
			refreshWidget();
			showExpiredOverlay();
			return;
		}

		// Always call start on page load.
		// - First visit     : creates the DB row and sets active.
		// - Returning visit : resets last_start_time (crash recovery).
		doStart();
		refreshWidget();
	} );

} )( jQuery );
