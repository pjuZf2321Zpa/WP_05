<?php
namespace AcademyProCertificates;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Shortcode {

	public function __construct() {
		add_shortcode( 'academy_pro_certificate_verification', [ $this, 'academy_certificate_verification' ] );
	}
	public function academy_certificate_verification() {
		ob_start();
		\AcademyPro\Helper::get_template( 'shortcode/certificate-verification.php' );
		return apply_filters( 'academy_pro/templates/shortcode/certificate_verification', ob_get_clean() );
	}
}
