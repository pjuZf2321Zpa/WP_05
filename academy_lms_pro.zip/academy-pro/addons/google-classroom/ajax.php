<?php
namespace AcademyProGoogleClassroom;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Ajax {

	public static function init() {
		$self = new self();
		$self->init_google_class();
	}

	public function init_google_class() {
		Admin\Ajax::init();
	}
}
