<?php
namespace AcademyProGoogleClassroom;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AcademyProGoogleClassroom\Admin\Service;

/**
 * Daily roster sync: courses with "Sync students daily" on are re-synced
 * from their Google class, using the course author's own connection.
 */
class Sync {
	const HOOK = 'academy_pro_google_classroom_daily_sync';

	/** Courses synced per run, so one run stays well inside a request. */
	const BATCH = 50;

	public static function init() {
		add_action( self::HOOK, array( __CLASS__, 'run' ) );
		add_action( 'init', array( __CLASS__, 'schedule' ) );
	}

	public static function schedule() {
		if ( ! wp_next_scheduled( self::HOOK ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', self::HOOK );
		}
	}

	public static function unschedule() {
		wp_clear_scheduled_hook( self::HOOK );
	}

	public static function run() {
		// Least recently synced first (never-synced before all), so a long
		// list rotates through over successive days.
		$post_ids = get_posts(
			[
				'post_type'      => 'academy_courses',
				'post_status'    => 'publish',
				'posts_per_page' => self::BATCH,
				'fields'         => 'ids',
				'no_found_rows'  => true,
				// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- opt-in flag, daily cron
				'meta_query'     => [
					'relation' => 'AND',
					'auto'     => [
						'key'     => Service::POST_AUTO_SYNC,
						'compare' => 'EXISTS',
					],
					[
						'relation' => 'OR',
						'synced'   => [
							'key'  => Service::POST_LAST_SYNC,
							'type' => 'NUMERIC',
						],
						'never'    => [
							'key'     => Service::POST_LAST_SYNC,
							'compare' => 'NOT EXISTS',
						],
					],
				],
				'orderby'        => 'synced',
				'order'          => 'ASC',
			]
		);

		$services = [];
		foreach ( $post_ids as $post_id ) {
			$class_id = get_post_meta( $post_id, Service::POST_CLASS_ID, true );
			$author   = (int) get_post_field( 'post_author', $post_id );
			if ( ! $class_id || ! $author ) {
				continue;
			}
			if ( ! isset( $services[ $author ] ) ) {
				$services[ $author ] = new Service( $author );
			}
			try {
				$services[ $author ]->sync_students( $class_id, $post_id );
			} catch ( \Exception $e ) {
				// Disconnected or Google error: try again tomorrow.
				update_post_meta( $post_id, 'academy_google_classroom_sync_error', sanitize_text_field( $e->getMessage() ) );
				continue;
			}
			delete_post_meta( $post_id, 'academy_google_classroom_sync_error' );
		}
	}
}
