<?php
namespace AcademyProGoogleClassroom;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Academy\Interfaces\AddonInterface;
final class GoogleClassroom implements AddonInterface {
	private $addon_name = 'google-classroom';
	private function __construct() {
		$this->define_constants();
		$this->init_addon();
	}

	public static function init() {
		static $instance = false;

		if ( ! $instance ) {
			$instance = new self();
		}

		return $instance;
	}
	public function define_constants() {
		define( 'ACADEMY_PRO_GOOGLE_CLASSROOM_VERSION', '1.0' );
	}

	public function init_addon() {
		// fire addon activation hook
		add_action( "academy/addons/activated_{$this->addon_name}", array( $this, 'addon_activation_hook' ) );
		add_action( "academy/addons/deactivated_{$this->addon_name}", array( $this, 'addon_deactivation_hook' ) );

		// if disable then stop running addon
		if ( ! \Academy\Helper::get_addon_active_status( $this->addon_name ) ) {
			return;
		}

		Ajax::init();
		Hooks::init();
		Sync::init();

		// Older versions kept the OAuth client JSON (with its secret) in the
		// public uploads folder; move it into user meta and delete the file.
		add_action( 'admin_init', array( $this, 'migrate_public_credentials' ) );
	}

	public function migrate_public_credentials() {
		if ( 'yes' === \Academy\Options::get( \Academy\Options::PRO_MIGRATIONS, 'classroom_private_credentials' ) ) {
			return;
		}
		Admin\Service::migrate_all_legacy_files();
		\Academy\Options::set( \Academy\Options::PRO_MIGRATIONS, 'classroom_private_credentials', 'yes' );
	}

	public function addon_activation_hook() {
		\Academy\Helper::flush_rewrite_rules();
	}

	public function addon_deactivation_hook() {
		Sync::unschedule();
		\Academy\Helper::flush_rewrite_rules();
	}
}
