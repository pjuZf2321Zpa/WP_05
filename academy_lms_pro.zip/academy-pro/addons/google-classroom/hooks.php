<?php
namespace AcademyProGoogleClassroom;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


class Hooks {
	public static function init() {
		$self = new self();
		// set continue learning url
		add_filter( 'academy/templates/start_course_url', array( $self, 'start_course_url' ) );
		// frontend stream template
		add_action( 'academy/templates/single_course_content', array( $self, 'academy_single_course_stream' ), 33 );
		// the setup guide shows the exact redirect URI to register with Google
		add_filter( 'academy/assets/backend_scripts_data', array( $self, 'set_scripts_data' ) );
	}

	public function set_scripts_data( $scripts_data ) {
		$scripts_data['google_classroom_redirect_url'] = Admin\Service::get_redirect_url();
		return $scripts_data;
	}

	public function start_course_url( $url ) {
		if ( ! \Academy\Helper::get_addon_active_status( 'google-classroom' ) ) {
			return $url;
		}
		$course_id = get_the_ID();
		$is_google_classroom = get_post_meta( $course_id, 'academy_google_classroom_id', true );
		if ( empty( $is_google_classroom ) ) {
			return $url;
		}
		$alternative_link = get_post_meta( $course_id, 'academy_classroom_alternative_link', true );
		if ( empty( $alternative_link ) ) {
			return $url;
		}
		return $alternative_link;
	}

	public function academy_single_course_stream() {
		$course_id = get_the_ID();
		$title = get_post_meta( $course_id, 'academy_google_classroom_title', true );
		$invite_code = get_post_meta( $course_id, 'academy_classroom_invite_code', true );
		$classroom_url = get_post_meta( $course_id, 'academy_classroom_alternative_link', true );
		if ( ! $classroom_url || ! $invite_code ) {
			return;
		}
		$is_enrolled = \Academy\Helper::is_enrolled( $course_id, get_current_user_id() );
		if ( $is_enrolled ) {
			\AcademyPro\Helper::get_template( 'google-classroom/stream.php', array(
				'title'         => $title,
				'join_code'     => $invite_code,
				'classroom_url' => $classroom_url,
				'upcoming'      => $this->get_upcoming_work( $course_id ),
			) );
		}
	}

	/**
	 * Upcoming Classroom coursework for the course page, read with the course
	 * author's connection and cached for an hour (also when it fails, so a
	 * disconnected author doesn't cost a Google call on every page view).
	 *
	 * @param int $course_id Academy course ID.
	 */
	private function get_upcoming_work( $course_id ) {
		$key    = 'academy_gc_upcoming_' . $course_id;
		$cached = get_transient( $key );
		if ( is_array( $cached ) ) {
			return $cached;
		}
		$items    = [];
		$class_id = get_post_meta( $course_id, Admin\Service::POST_CLASS_ID, true );
		$author   = (int) get_post_field( 'post_author', $course_id );
		if ( $class_id && $author ) {
			try {
				$items = ( new Admin\Service( $author ) )->get_upcoming_work( $class_id, 3 );
			} catch ( \Exception $e ) {
				$items = [];
			}
		}
		set_transient( $key, $items, HOUR_IN_SECONDS );
		return $items;
	}
}
