<?php
namespace AcademyProGoogleClassroom\Admin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AcademyPro\Google\Client;
use AcademyPro\Google\Service\Classroom;

/**
 * One instructor's Google Classroom connection: their OAuth client (the JSON
 * they uploaded), their token, and the Classroom calls made with it.
 *
 * Everything is per user — each instructor connects their own Google account.
 */
class Service {
	const META_CLIENT      = 'academy_pro_google_classroom_client';
	const META_LEGACY_FILE = 'academy_pro_google_classroom_credential_filepath';
	const META_TOKEN       = 'academy_pro_google_classroom_access_token';
	const META_ACCOUNT     = 'academy_pro_google_classroom_account';

	const POST_CLASS_ID    = 'academy_google_classroom_id';
	const POST_LAST_SYNC   = 'academy_google_classroom_last_synced';
	const POST_ROSTER      = 'academy_google_classroom_roster_count';
	const POST_AUTO_SYNC   = 'academy_google_classroom_auto_sync';

	const CLASSES_CACHE_TTL = 10 * MINUTE_IN_SECONDS;

	/** Thrown when the saved token can't be used or refreshed any more. */
	const ERROR_RECONNECT = 'reconnect_required';

	/** @var int */
	private $user_id;

	/** @var Client|null */
	private $client;

	public function __construct( $user_id = 0 ) {
		$this->user_id = $user_id ? (int) $user_id : get_current_user_id();
	}

	public static function scopes() {
		return [
			Classroom::CLASSROOM_COURSES,
			Classroom::CLASSROOM_COURSES_READONLY,
			Classroom::CLASSROOM_ROSTERS_READONLY,
			Classroom::CLASSROOM_PROFILE_PHOTOS,
			Classroom::CLASSROOM_PROFILE_EMAILS,
			Classroom::CLASSROOM_TOPICS_READONLY,
			Classroom::CLASSROOM_ANNOUNCEMENTS_READONLY,
			Classroom::CLASSROOM_COURSEWORK_ME_READONLY,
			Classroom::CLASSROOM_COURSEWORK_STUDENTS_READONLY,
			// Publishing course sections as topics and lessons as materials.
			Classroom::CLASSROOM_TOPICS,
			Classroom::CLASSROOM_COURSEWORKMATERIALS,
		];
	}

	/** Scopes needed to publish course content to Classroom. */
	public static function publish_scopes() {
		return [
			Classroom::CLASSROOM_TOPICS,
			Classroom::CLASSROOM_COURSEWORKMATERIALS,
		];
	}

	/**
	 * Whether the saved token was granted every publishing scope. Accounts
	 * connected before publishing existed need to reconnect once.
	 */
	public function can_publish() {
		$token = get_user_meta( $this->user_id, self::META_TOKEN, true );
		if ( ! is_array( $token ) || empty( $token['scope'] ) ) {
			return false;
		}
		$granted = explode( ' ', (string) $token['scope'] );
		return ! array_diff( self::publish_scopes(), $granted );
	}

	/**
	 * The OAuth redirect URI sent to Google — must match an "Authorized
	 * redirect URI" on the user's OAuth client exactly, in both the consent
	 * request and the code-for-token exchange.
	 *
	 * Filterable because Google only accepts public TLDs (or localhost), so a
	 * local site such as `*.test` needs to route the callback via localhost.
	 *
	 * @return string
	 */
	public static function get_redirect_url() {
		return esc_url_raw(
			apply_filters(
				'academy_pro/google_classroom/redirect_url',
				admin_url( 'admin.php?page=academy-google-classroom' )
			)
		);
	}


	/**
	 * Validate an OAuth client JSON download and keep only what the client
	 * needs. Accepts Google's "web" (and legacy "installed") shapes.
	 *
	 * @param string $json Raw file contents.
	 * @return array|\WP_Error
	 */
	public static function parse_client_json( $json ) {
		$data = json_decode( (string) $json, true );
		if ( ! is_array( $data ) ) {
			return new \WP_Error( 'invalid_json', __( 'That file isn\'t valid JSON. Download the OAuth client JSON from Google Cloud and try again.', 'academy-pro' ) );
		}
		$type = isset( $data['web'] ) ? 'web' : ( isset( $data['installed'] ) ? 'installed' : '' );
		if ( ! $type || empty( $data[ $type ]['client_id'] ) || empty( $data[ $type ]['client_secret'] ) ) {
			return new \WP_Error( 'invalid_client', __( 'This isn\'t an OAuth client file. In Google Cloud, create an OAuth client ID of type "Web application" and download its JSON.', 'academy-pro' ) );
		}
		$keys = [ 'client_id', 'client_secret', 'project_id', 'auth_uri', 'token_uri', 'auth_provider_x509_cert_url', 'redirect_uris' ];
		return [ $type => array_intersect_key( $data[ $type ], array_flip( $keys ) ) ];
	}

	public function save_client_config( array $config ) {
		update_user_meta( $this->user_id, self::META_CLIENT, $config );
		// A new OAuth client can't reuse a token issued to the old one.
		$this->forget_token();
	}

	public function get_client_config() {
		$config = get_user_meta( $this->user_id, self::META_CLIENT, true );
		if ( empty( $config ) ) {
			$config = self::migrate_legacy_file( $this->user_id );
		}
		return is_array( $config ) ? $config : [];
	}

	public function has_client_config() {
		return ! empty( $this->get_client_config() );
	}

	/**
	 * Older versions saved the uploaded JSON (client secret included) into the
	 * public uploads folder. Move it into user meta and delete the file once no
	 * other user still points at it.
	 *
	 * @param int $user_id WordPress user ID.
	 *
	 * @return array The migrated config, or [] when there was nothing usable.
	 */
	public static function migrate_legacy_file( $user_id ) {
		$path = (string) get_user_meta( $user_id, self::META_LEGACY_FILE, true );
		if ( '' === $path ) {
			return [];
		}

		$upload = wp_upload_dir();
		$base   = realpath( $upload['basedir'] );
		$file   = realpath( $upload['basedir'] . '/' . ltrim( $path, '/' ) );
		$config = [];

		// Only ever touch the addon's own file inside uploads.
		$is_ours = $file && $base && 0 === strpos( $file, $base . DIRECTORY_SEPARATOR ) && 'classroom_credential.json' === basename( $file );

		if ( $is_ours && is_readable( $file ) ) {
			$parsed = self::parse_client_json( file_get_contents( $file ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents, WordPressVIPMinimum.Performance.FetchingRemoteData.FileGetContentsUnknown -- local file
			if ( ! is_wp_error( $parsed ) ) {
				$config = $parsed;
				update_user_meta( $user_id, self::META_CLIENT, $config );
			}
		}

		delete_user_meta( $user_id, self::META_LEGACY_FILE );

		if ( $is_ours && file_exists( $file ) ) {
			$others = get_users(
				[
					'meta_key'   => self::META_LEGACY_FILE, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- one-time migration
					'meta_value' => $path, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value -- one-time migration
					'fields'     => 'ID',
					'number'     => 1,
				]
			);
			if ( empty( $others ) ) {
				wp_delete_file( $file );
			}
		}

		return $config;
	}

	/** Migrate every user still pointing at a public credential file. */
	public static function migrate_all_legacy_files() {
		$user_ids = get_users(
			[
				'meta_key' => self::META_LEGACY_FILE, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- one-time migration
				'fields'   => 'ID',
				'number'   => 500,
			]
		);
		foreach ( $user_ids as $user_id ) {
			self::migrate_legacy_file( (int) $user_id );
		}
	}


	private function base_client() {
		$client = new Client();
		$client->setApplicationName( 'Academy LMS Google Classroom' );
		$client->setAuthConfig( $this->get_client_config() );
		$client->setRedirectUri( self::get_redirect_url() );
		$client->addScope( self::scopes() );
		$client->setAccessType( 'offline' );
		$client->setPrompt( 'consent' );
		return $client;
	}

	public function get_auth_url() {
		if ( ! $this->has_client_config() ) {
			return new \WP_Error( 'no_client', __( 'Upload your OAuth client JSON first.', 'academy-pro' ) );
		}
		return $this->base_client()->createAuthUrl();
	}

	/**
	 * Exchange the code Google sent back for a token, and remember which
	 * Google account it belongs to.
	 *
	 * @param string $code Authorization code from Google.
	 *
	 * @return true|\WP_Error
	 */
	public function connect_with_code( $code ) {
		if ( ! $this->has_client_config() ) {
			return new \WP_Error( 'no_client', __( 'Upload your OAuth client JSON first.', 'academy-pro' ) );
		}
		$client = $this->base_client();
		try {
			$token = $client->fetchAccessTokenWithAuthCode( $code );
		} catch ( \Exception $e ) {
			return new \WP_Error( 'token_exchange', $e->getMessage() );
		}
		if ( isset( $token['error'] ) ) {
			return new \WP_Error( 'token_exchange', $token['error_description'] ?? $token['error'] );
		}
		update_user_meta( $this->user_id, self::META_TOKEN, $token );
		$this->client = $client;

		$this->remember_account();
		$this->forget_classes_cache();
		return true;
	}

	/**
	 * Store the connected Google account's name, email and photo for display.
	 * Failure is harmless: the connection works without it.
	 */
	private function remember_account() {
		try {
			$profile = $this->classroom()->userProfiles->get( 'me' );
			$account = [
				'email' => (string) $profile->getEmailAddress(),
				'name'  => (string) ( $profile->getName() ? $profile->getName()->getFullName() : '' ),
				'photo' => (string) $profile->getPhotoUrl(),
			];
			update_user_meta( $this->user_id, self::META_ACCOUNT, $account );
			return $account;
		} catch ( \Exception $e ) {
			delete_user_meta( $this->user_id, self::META_ACCOUNT );
			return null;
		}
	}

	public function is_connected() {
		$token = get_user_meta( $this->user_id, self::META_TOKEN, true );
		return is_array( $token ) && ! empty( $token['access_token'] );
	}

	/**
	 * What the admin UI needs to know — never the token itself.
	 */
	public function get_status() {
		$account = get_user_meta( $this->user_id, self::META_ACCOUNT, true );
		// Connected before the account was recorded: look it up once.
		if ( ! is_array( $account ) && $this->is_connected() ) {
			$account = $this->remember_account();
		}
		return [
			'configured'   => $this->has_client_config(),
			'connected'    => $this->is_connected(),
			'can_publish'  => $this->can_publish(),
			'account'      => is_array( $account ) ? $account : null,
			'redirect_uri' => self::get_redirect_url(),
		];
	}

	public function disconnect() {
		$token = get_user_meta( $this->user_id, self::META_TOKEN, true );
		if ( is_array( $token ) && $this->has_client_config() ) {
			try {
				// Best effort: also withdraw the grant on Google's side.
				$this->base_client()->revokeToken( $token );
			} catch ( \Exception $e ) {
				unset( $e );
			}
		}
		$this->forget_token();
	}

	private function forget_token() {
		delete_user_meta( $this->user_id, self::META_TOKEN );
		delete_user_meta( $this->user_id, self::META_ACCOUNT );
		$this->forget_classes_cache();
		$this->client = null;
	}

	/**
	 * An authorised client, refreshing the token when it has expired.
	 *
	 * @throws \RuntimeException With code ERROR_RECONNECT when it can't.
	 */
	public function client() {
		if ( $this->client ) {
			return $this->client;
		}
		$token = get_user_meta( $this->user_id, self::META_TOKEN, true );
		if ( ! $this->has_client_config() || ! is_array( $token ) || empty( $token['access_token'] ) ) {
			throw new \RuntimeException( esc_html( self::ERROR_RECONNECT ) );
		}

		$client = $this->base_client();
		$client->setAccessToken( $token );

		if ( $client->isAccessTokenExpired() ) {
			$refresh = $client->getRefreshToken();
			$new     = $refresh ? $client->fetchAccessTokenWithRefreshToken( $refresh ) : [ 'error' => 'no_refresh_token' ];
			if ( empty( $new['access_token'] ) ) {
				// Revoked, or expired (Testing-mode apps get 7-day refresh tokens).
				$this->forget_token();
				throw new \RuntimeException( esc_html( self::ERROR_RECONNECT ) );
			}
			update_user_meta( $this->user_id, self::META_TOKEN, $client->getAccessToken() );
		}

		$this->client = $client;
		return $client;
	}

	public function classroom() {
		return new Classroom( $this->client() );
	}


	private function classes_cache_key() {
		return 'academy_gc_classes_' . $this->user_id;
	}

	public function forget_classes_cache() {
		delete_transient( $this->classes_cache_key() );
	}

	/**
	 * Every active or new class this user teaches, as plain arrays, following
	 * all result pages. Cached briefly per user.
	 *
	 * @param bool $refresh Bypass the cache and fetch from Google.
	 */
	public function get_teaching_classes( $refresh = false ) {
		$cached = $refresh ? false : get_transient( $this->classes_cache_key() );
		if ( is_array( $cached ) ) {
			return $cached;
		}

		$service = $this->classroom();
		$classes = [];
		$token   = null;
		do {
			$params = [
				'teacherId'    => 'me',
				'courseStates' => [ 'ACTIVE', 'PROVISIONED' ],
				'pageSize'     => 100,
			];
			if ( $token ) {
				$params['pageToken'] = $token;
			}
			$page = $service->courses->listCourses( $params );
			foreach ( (array) $page->getCourses() as $course ) {
				$classes[] = self::class_to_array( $course );
			}
			$token = $page->getNextPageToken();
		} while ( $token );

		set_transient( $this->classes_cache_key(), $classes, self::CLASSES_CACHE_TTL );
		return $classes;
	}

	/**
	 * The class if this user teaches it, else null.
	 *
	 * @param string $class_id Google Classroom class ID.
	 */
	public function find_teaching_class( $class_id ) {
		foreach ( $this->get_teaching_classes() as $gc_class ) {
			if ( (string) $gc_class['id'] === (string) $class_id ) {
				return $gc_class;
			}
		}
		// Not in the cached list: it may be brand new, so check once fresh.
		foreach ( $this->get_teaching_classes( true ) as $gc_class ) {
			if ( (string) $gc_class['id'] === (string) $class_id ) {
				return $gc_class;
			}
		}
		return null;
	}

	public static function class_to_array( $course ) {
		return [
			'id'                 => (string) $course->getId(),
			'name'               => (string) $course->getName(),
			'section'            => (string) $course->getSection(),
			'descriptionHeading' => (string) $course->getDescriptionHeading(),
			'description'        => (string) $course->getDescription(),
			'room'               => (string) $course->getRoom(),
			'enrollmentCode'     => (string) $course->getEnrollmentCode(),
			'alternateLink'      => (string) $course->getAlternateLink(),
			'courseState'        => (string) $course->getCourseState(),
			'creationTime'       => (string) $course->getCreationTime(),
			'updateTime'         => (string) $course->getUpdateTime(),
		];
	}

	/**
	 * Topic names in the class, in Classroom's order.
	 *
	 * @param string $class_id Google Classroom class ID.
	 */
	public function get_topics( $class_id ) {
		$service = $this->classroom();
		$topics  = [];
		$token   = null;
		do {
			$params = [ 'pageSize' => 100 ];
			if ( $token ) {
				$params['pageToken'] = $token;
			}
			$page = $service->courses_topics->listCoursesTopics( $class_id, $params );
			foreach ( (array) $page->getTopic() as $topic ) {
				$topics[] = (string) $topic->getName();
			}
			$token = $page->getNextPageToken();
		} while ( $token );
		return $topics;
	}

	/**
	 * Every student email on the class roster, following all pages.
	 *
	 * @param string $class_id Google Classroom class ID.
	 */
	public function get_student_emails( $class_id ) {
		$service = $this->classroom();
		$emails  = [];
		$token   = null;
		do {
			$params = [ 'pageSize' => 100 ];
			if ( $token ) {
				$params['pageToken'] = $token;
			}
			$page = $service->courses_students->listCoursesStudents( $class_id, $params );
			foreach ( (array) $page->getStudents() as $student ) {
				$profile = $student->getProfile();
				$email   = $profile ? (string) $profile->getEmailAddress() : '';
				if ( is_email( $email ) ) {
					$emails[] = strtolower( $email );
				}
			}
			$token = $page->getNextPageToken();
		} while ( $token );
		return array_values( array_unique( $emails ) );
	}

	/**
	 * Published coursework due from now on, soonest first.
	 *
	 * @param string $class_id Google Classroom class ID.
	 * @param int    $limit Most items to return.
	 *
	 * @return array[] { title, due (unix), link }
	 */
	public function get_upcoming_work( $class_id, $limit = 5 ) {
		$page  = $this->classroom()->courses_courseWork->listCoursesCourseWork(
			$class_id,
			[
				'courseWorkStates' => [ 'PUBLISHED' ],
				'pageSize'         => 50,
			]
		);
		$now   = time();
		$items = [];
		foreach ( (array) $page->getCourseWork() as $work ) {
			$date = $work->getDueDate();
			if ( ! $date ) {
				continue;
			}
			$time = $work->getDueTime();
			$due  = gmmktime(
				$time ? (int) $time->getHours() : 23,
				$time ? (int) $time->getMinutes() : 59,
				0,
				(int) $date->getMonth(),
				(int) $date->getDay(),
				(int) $date->getYear()
			);
			if ( $due < $now ) {
				continue;
			}
			$items[] = [
				'title' => (string) $work->getTitle(),
				'due'   => $due,
				'link'  => (string) $work->getAlternateLink(),
			];
		}//end foreach
		usort(
			$items,
			function ( $a, $b ) {
				return $a['due'] <=> $b['due'];
			}
		);
		return array_slice( $items, 0, $limit );
	}


	public static function get_course_by_class_id( $class_id ) {
		if ( ! $class_id ) {
			return 0;
		}
		$posts = get_posts(
			[
				'post_type'      => 'academy_courses',
				'post_status'    => 'any',
				'posts_per_page' => 1,
				'fields'         => 'ids',
				'no_found_rows'  => true,
				'meta_key'       => self::POST_CLASS_ID, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- the link between the two
				'meta_value'     => (string) $class_id, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value -- the link between the two
			]
		);
		return $posts ? (int) $posts[0] : 0;
	}

	/**
	 * The course's author, or an admin, may act on it.
	 *
	 * @param int $post_id Academy course ID.
	 * @param int $user_id WordPress user ID.
	 */
	public static function can_manage_course( $post_id, $user_id = 0 ) {
		$user_id = $user_id ? $user_id : get_current_user_id();
		$post    = get_post( $post_id );
		if ( ! $post || 'academy_courses' !== $post->post_type ) {
			return false;
		}
		return (int) $post->post_author === (int) $user_id || user_can( $user_id, 'manage_options' );
	}

	/**
	 * Row data for the admin table about the Academy course a class links to.
	 *
	 * @param string $class_id Google Classroom class ID.
	 */
	public static function get_link_info( $class_id ) {
		$post_id = self::get_course_by_class_id( $class_id );
		if ( ! $post_id ) {
			return null;
		}
		$last = (int) get_post_meta( $post_id, self::POST_LAST_SYNC, true );
		return [
			'post_id'      => $post_id,
			'status'       => get_post_status( $post_id ),
			'title'        => get_the_title( $post_id ),
			'preview_link' => html_entity_decode( esc_url_raw( get_preview_post_link( $post_id ) ) ),
			'students'     => (int) \Academy\Helper::count_course_enrolled( $post_id ),
			'last_synced'  => $last ? $last : null,
			'auto_sync'    => (bool) get_post_meta( $post_id, self::POST_AUTO_SYNC, true ),
			'can_manage'   => self::can_manage_course( $post_id ),
			'pushed'       => self::get_push_info( $post_id ),
		];
	}

	/**
	 * What has been posted to Classroom from this course.
	 *
	 * @param int $post_id Academy course ID.
	 * @return array|null { at, lessons, topics } or null if never posted.
	 */
	public static function get_push_info( $post_id ) {
		$at = (int) get_post_meta( $post_id, Publisher::META_LAST_PUSHED, true );
		if ( ! $at ) {
			return null;
		}
		$map    = Publisher::get_map( $post_id );
		$drafts = count(
			array_filter(
				$map['materials'],
				function ( $saved ) {
					return 'DRAFT' === ( $saved['state'] ?? '' );
				}
			)
		);
		return [
			'at'      => $at,
			'lessons' => count( $map['materials'] ),
			'drafts'  => $drafts,
			'topics'  => count( $map['topics'] ),
		];
	}

	/**
	 * Enrol every student on the class roster into the linked course, creating
	 * accounts for new emails (they get WordPress's set-password email).
	 *
	 * @param string $class_id Google Classroom class ID.
	 * @param int    $post_id Academy course ID.
	 *
	 * @return array|\WP_Error { roster, enrolled, already, created, failed }
	 */
	public function sync_students( $class_id, $post_id ) {
		$emails = $this->get_student_emails( $class_id );
		$result = [
			'roster'   => count( $emails ),
			'enrolled' => 0,
			'already'  => 0,
			'created'  => 0,
			'failed'   => 0,
		];
		foreach ( $emails as $email ) {
			$user_id = email_exists( $email );
			if ( ! $user_id ) {
				$user_id = \Academy\Helper::insert_student( $email );
				if ( is_wp_error( $user_id ) || ! is_numeric( $user_id ) ) {
					++$result['failed'];
					continue;
				}
				++$result['created'];
			}
			if ( \Academy\Helper::do_enroll( $post_id, (int) $user_id ) ) {
				++$result['enrolled'];
			} else {
				++$result['already'];
			}
		}
		update_post_meta( $post_id, self::POST_LAST_SYNC, time() );
		update_post_meta( $post_id, self::POST_ROSTER, $result['roster'] );
		return $result;
	}
}
