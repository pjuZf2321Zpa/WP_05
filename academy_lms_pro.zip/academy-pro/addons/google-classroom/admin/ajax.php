<?php
namespace AcademyProGoogleClassroom\Admin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AcademyPro\Google\Service\Classroom\Course;

/**
 * Admin AJAX for Google Classroom. Google access lives in Service; these
 * handlers check the request, act on the current user's own connection, and
 * report per-class results so bulk actions can say what happened.
 */
class Ajax {
	/**
	 * Kept for code that still reads the old public properties.
	 *
	 * @var string
	 */
	public static $course_class_id = Service::POST_CLASS_ID;
	public static $class_code      = 'academy_classroom_invite_code';

	public static function init() {
		$self    = new self();
		$actions = [
			'upload_classroom_credentials'          => 'upload_classroom_credentials',
			'save_classroom_credentials'            => 'get_auth_url',
			'get_auth_code'                         => 'get_access_token',
			'get_classroom_credential'              => 'get_status',
			'disconnect'                            => 'disconnect',
			'fetch_all_google_classroom'            => 'fetch_all_google_classroom',
			'import_google_classroom'               => 'import_google_classroom',
			'publish_course'                        => 'publish_course',
			'delete_course'                         => 'delete_course',
			'create_new_google_classroom'           => 'create_new_google_classroom',
			'import_students_from_google_classroom' => 'import_students_from_google_classroom',
			'set_auto_sync'                         => 'set_auto_sync',
			'push_to_classroom'                     => 'push_to_classroom',
			'unpublish_from_classroom'              => 'unpublish_from_classroom',
		];
		foreach ( $actions as $action => $method ) {
			add_action( "wp_ajax_academy_pro_google_classroom/{$action}", array( $self, $method ) );
		}
	}

	/** @deprecated Use Service::get_redirect_url(). */
	public static function get_redirect_url() {
		return Service::get_redirect_url();
	}

	/**
	 * @deprecated Use Service::get_course_by_class_id().
	 *
	 * @param int  $classroom_id Google Classroom class ID.
	 * @param bool $clear Unused; kept for compatibility.
	 */
	public static function get_course_by_google_class_id( int $classroom_id, bool $clear = false ): ?int {
		unset( $clear );
		$post_id = Service::get_course_by_class_id( $classroom_id );
		return $post_id ? $post_id : null;
	}


	private function verify() {
		check_ajax_referer( 'academy_nonce', 'security' );
		if ( ! current_user_can( 'manage_academy_instructor' ) ) {
			wp_send_json_error( [ 'message' => __( 'Sorry, you are not allowed to do that.', 'academy-pro' ) ], 403 );
		}
	}

	/** Class IDs from `course_ids[]` (bulk) or `course_id` (single). */
	private function requested_class_ids() {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- verified in verify()
		$ids = [];
		if ( isset( $_POST['course_ids'] ) ) {
			$raw = wp_unslash( $_POST['course_ids'] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitized below
			$ids = is_array( $raw ) ? $raw : explode( ',', (string) $raw );
		} elseif ( isset( $_POST['course_id'] ) ) {
			$ids = [ wp_unslash( $_POST['course_id'] ) ]; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitized below
		}
		// phpcs:enable
		$ids = array_map(
			function ( $id ) {
				return preg_replace( '/[^0-9]/', '', (string) $id );
			},
			$ids
		);
		return array_values( array_unique( array_filter( $ids ) ) );
	}

	/**
	 * A readable message from a Google API error (its message is JSON).
	 *
	 * @param \Exception $e The caught exception.
	 */
	private function google_error_message( \Exception $e ) {
		$data = json_decode( $e->getMessage(), true );
		if ( isset( $data['error']['message'] ) ) {
			return (string) $data['error']['message'];
		}
		if ( isset( $data['error_description'] ) ) {
			return (string) $data['error_description'];
		}
		return $e->getMessage();
	}

	/**
	 * Send an exception as an error, flagging an expired connection.
	 *
	 * @param \Exception $e The caught exception.
	 */
	private function send_exception( \Exception $e ) {
		if ( Service::ERROR_RECONNECT === $e->getMessage() ) {
			wp_send_json_error(
				[
					'code'    => Service::ERROR_RECONNECT,
					'message' => __( 'Your Google connection has expired or was removed. Reconnect your Google account to continue.', 'academy-pro' ),
				]
			);
		}
		wp_send_json_error( [ 'message' => $this->google_error_message( $e ) ] );
	}

	/**
	 * One summary line plus per-class results for bulk actions.
	 *
	 * @param array  $results Per-class results.
	 * @param string $done_label What was done, e.g. "imported".
	 */
	private function send_results( array $results, $done_label ) {
		$ok     = count( array_filter( array_column( $results, 'ok' ) ) );
		$failed = count( $results ) - $ok;
		$parts  = [];
		if ( $ok ) {
			/* translators: 1: number of classes, 2: what was done, e.g. "imported" */
			$parts[] = sprintf( _n( '%1$d class %2$s.', '%1$d classes %2$s.', $ok, 'academy-pro' ), $ok, $done_label );
		}
		if ( $failed ) {
			$first   = current( array_filter( $results, fn( $r ) => ! $r['ok'] ) );
			/* translators: 1: number of classes, 2: reason for the first failure */
			$parts[] = sprintf( _n( '%1$d failed: %2$s', '%1$d failed. First error: %2$s', $failed, 'academy-pro' ), $failed, $first['message'] );
		}
		$payload = [
			'message' => implode( ' ', $parts ),
			'results' => $results,
		];
		if ( $ok ) {
			wp_send_json_success( $payload );
		}
		wp_send_json_error( $payload );
	}


	public function upload_classroom_credentials() {
		$this->verify();
		// phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.InputNotValidated -- verified above; file is parsed, not stored
		$file = isset( $_FILES['upload_file'] ) ? $_FILES['upload_file'] : null;
		if ( ! $file || ! empty( $file['error'] ) || empty( $file['tmp_name'] ) || ! is_uploaded_file( $file['tmp_name'] ) ) {
			wp_send_json_error( [ 'message' => __( 'The file didn\'t upload. Please try again.', 'academy-pro' ) ] );
		}
		if ( 'json' !== strtolower( pathinfo( (string) $file['name'], PATHINFO_EXTENSION ) ) || $file['size'] > 64 * KB_IN_BYTES ) {
			wp_send_json_error( [ 'message' => __( 'Wrong file. Upload the OAuth client .json file you downloaded from Google Cloud.', 'academy-pro' ) ] );
		}

		// Read it straight from PHP's temp upload: the client secret is kept in
		// user meta and never written anywhere web-accessible.
		$config = Service::parse_client_json( file_get_contents( $file['tmp_name'] ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents, WordPressVIPMinimum.Performance.FetchingRemoteData.FileGetContentsUnknown -- local temp upload
		if ( is_wp_error( $config ) ) {
			wp_send_json_error( [ 'message' => $config->get_error_message() ] );
		}

		$service = new Service();
		$service->save_client_config( $config );
		wp_send_json_success(
			[
				'message'  => __( 'Credentials saved. Continue to Google to connect your account.', 'academy-pro' ),
				'auth_url' => $service->get_auth_url(),
			]
		);
	}

	/** The Google consent URL (after upload, or to reconnect). */
	public function get_auth_url() {
		$this->verify();
		$url = ( new Service() )->get_auth_url();
		if ( is_wp_error( $url ) ) {
			wp_send_json_error( [ 'message' => $url->get_error_message() ] );
		}
		wp_send_json_success( $url );
	}

	/** Google redirected back with `code`: exchange it for a token. */
	public function get_access_token() {
		$this->verify();
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- verified above
		$code = isset( $_POST['authCode'] ) ? sanitize_text_field( wp_unslash( $_POST['authCode'] ) ) : '';
		if ( '' === $code ) {
			wp_send_json_error( [ 'message' => __( 'Google didn\'t return an authorization code.', 'academy-pro' ) ] );
		}
		$result = ( new Service() )->connect_with_code( $code );
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( [ 'message' => $result->get_error_message() ] );
		}
		wp_send_json_success( ( new Service() )->get_status() );
	}

	/** Connection state for the UI — no tokens or secrets leave the server. */
	public function get_status() {
		$this->verify();
		wp_send_json_success( ( new Service() )->get_status() );
	}

	public function disconnect() {
		$this->verify();
		$service = new Service();
		$service->disconnect();
		wp_send_json_success( $service->get_status() );
	}


	public function fetch_all_google_classroom() {
		$this->verify();
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- verified above
		$keyword  = isset( $_POST['search'] ) ? sanitize_text_field( wp_unslash( $_POST['search'] ) ) : '';
		$page     = isset( $_POST['page'] ) ? max( 1, absint( $_POST['page'] ) ) : 1;
		$per_page = isset( $_POST['per_page'] ) ? min( 100, max( 1, absint( $_POST['per_page'] ) ) ) : 10;
		$refresh  = ! empty( $_POST['refresh'] );
		// phpcs:enable

		try {
			$classes = ( new Service() )->get_teaching_classes( $refresh );
		} catch ( \Exception $e ) {
			$this->send_exception( $e );
		}

		if ( '' !== $keyword ) {
			$classes = array_values(
				array_filter(
					$classes,
					function ( $gc_class ) use ( $keyword ) {
						return false !== stripos( $gc_class['name'] . ' ' . $gc_class['section'], $keyword );
					}
				)
			);
		}

		$total = count( $classes );
		$rows  = array_slice( $classes, ( $page - 1 ) * $per_page, $per_page );
		foreach ( $rows as &$row ) {
			$row['link'] = Service::get_link_info( $row['id'] );
		}
		unset( $row );

		header( 'X-Wp-Total: ' . $total );
		wp_send_json_success( $rows );
	}

	public function import_google_classroom() {
		$this->verify();
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- verified above
		$with_topics = ! isset( $_POST['with_topics'] ) || 'false' !== $_POST['with_topics'];
		$service     = new Service();
		$results     = [];

		foreach ( $this->requested_class_ids() as $class_id ) {
			try {
				$gc_class = $service->find_teaching_class( $class_id );
			} catch ( \Exception $e ) {
				$this->send_exception( $e );
			}
			if ( ! $gc_class ) {
				$results[] = [
					'id' => $class_id,
					'ok' => false,
					'message' => __( 'You don\'t teach this class.', 'academy-pro' )
				];
				continue;
			}
			if ( Service::get_course_by_class_id( $class_id ) ) {
				$results[] = [
					'id' => $class_id,
					'ok' => false,
					'message' => __( 'Already imported.', 'academy-pro' )
				];
				continue;
			}

			$sections = [];
			if ( $with_topics ) {
				try {
					foreach ( $service->get_topics( $class_id ) as $topic ) {
						$sections[] = [
							'title' => $topic,
							'content' => '',
							'topics' => []
						];
					}
				} catch ( \Exception $e ) {
					// Topics are a nicety; import the class without them.
					unset( $e );
				}
			}

			$post_id = $this->create_course( $gc_class, $sections );
			if ( is_wp_error( $post_id ) ) {
				$results[] = [
					'id' => $class_id,
					'ok' => false,
					'message' => $post_id->get_error_message()
				];
				continue;
			}
			$results[] = [
				'id'       => $class_id,
				'ok'       => true,
				'message'  => '',
				'link'     => Service::get_link_info( $class_id ),
				'sections' => count( $sections ),
			];
		}//end foreach

		$this->send_results( $results, __( 'imported as draft courses', 'academy-pro' ) );
	}

	/**
	 * A draft Academy course for the class: its description as content and
	 * its Classroom topics as empty curriculum sections.
	 *
	 * @param array $gc_class Class data from Service::class_to_array().
	 * @param array $sections Curriculum sections.
	 */
	private function create_course( array $gc_class, array $sections ) {
		$description = trim( $gc_class['descriptionHeading'] . "\n\n" . $gc_class['description'] );
		$post_id     = wp_insert_post(
			[
				'post_title'   => $gc_class['name'],
				'post_content' => wpautop( esc_html( $description ) ),
				'post_status'  => 'draft',
				'post_type'    => 'academy_courses',
				'post_author'  => get_current_user_id(),
			],
			true
		);
		if ( is_wp_error( $post_id ) ) {
			return $post_id;
		}

		$meta = [
			Service::POST_CLASS_ID                     => $gc_class['id'],
			'academy_google_classroom_title'           => $gc_class['name'],
			self::$class_code                          => $gc_class['enrollmentCode'],
			'academy_classroom_alternative_link'       => $gc_class['alternateLink'],
			'academy_course_expire_enrollment'         => false,
			'academy_is_enabled_course_announcements'  => true,
			'academy_is_enabled_course_qa'             => true,
			'academy_course_materials_included'        => '',
			'academy_course_requirements'              => '',
			'academy_course_language'                  => '',
			'academy_course_benefits'                  => '',
			'academy_course_duration'                  => array( 0, 0, 0 ),
			'academy_course_intro_video'               => '',
			'academy_course_drip_content_enabled'      => false,
			'academy_course_drip_content_type'         => 'schedule_by_date',
			'academy_prerequisite_type'                => 'course',
			'academy_prerequisite_courses'             => array(),
			'academy_prerequisite_categories'          => array(),
			'academy_course_max_students'              => 0,
			'_thumbnail_id'                            => 0,
			'academy_course_audience'                  => '',
			'academy_course_difficulty_level'          => 'beginner',
			'academy_course_curriculum'                => $sections,
			'academy_course_product_id'                => 0,
			'academy_course_type'                      => 'free',
		];
		foreach ( $meta as $key => $value ) {
			add_post_meta( $post_id, $key, $value );
		}
		add_user_meta( get_current_user_id(), 'academy_instructor_course_id', $post_id );
		return $post_id;
	}

	/**
	 * Run $callback on each requested class's linked course the user may manage.
	 *
	 * @param callable $callback Receives ($class_id, $post_id), returns a result array.
	 */
	private function for_each_owned_course( callable $callback ) {
		$results = [];
		foreach ( $this->requested_class_ids() as $class_id ) {
			$post_id = Service::get_course_by_class_id( $class_id );
			if ( ! $post_id ) {
				$results[] = [
					'id' => $class_id,
					'ok' => false,
					'message' => __( 'Not imported yet.', 'academy-pro' )
				];
				continue;
			}
			if ( ! Service::can_manage_course( $post_id ) ) {
				$results[] = [
					'id' => $class_id,
					'ok' => false,
					'message' => __( 'Only the course author or an admin can do this.', 'academy-pro' )
				];
				continue;
			}
			$results[] = array_merge( [ 'id' => $class_id ], $callback( $class_id, $post_id ) );
		}
		return $results;
	}

	public function publish_course() {
		$this->verify();
		$results = $this->for_each_owned_course(
			function ( $class_id, $post_id ) {
				if ( 'publish' !== get_post_status( $post_id ) ) {
					$updated = wp_update_post( [
						'ID' => $post_id,
						'post_status' => 'publish'
					], true );
					if ( is_wp_error( $updated ) ) {
						return [
							'ok' => false,
							'message' => $updated->get_error_message()
						];
					}
				}
				return [
					'ok' => true,
					'message' => '',
					'link' => Service::get_link_info( $class_id )
				];
			}
		);
		$this->send_results( $results, __( 'published', 'academy-pro' ) );
	}

	public function import_students_from_google_classroom() {
		$this->verify();
		$service = new Service();
		$results = $this->for_each_owned_course(
			function ( $class_id, $post_id ) use ( $service ) {
				try {
					$counts = $service->sync_students( $class_id, $post_id );
				} catch ( \Exception $e ) {
					if ( Service::ERROR_RECONNECT === $e->getMessage() ) {
						$this->send_exception( $e );
					}
					return [
						'ok' => false,
						'message' => $this->google_error_message( $e )
					];
				}
				return [
					'ok'      => true,
					'message' => sprintf(
						/* translators: 1: newly enrolled, 2: new accounts, 3: already enrolled */
						__( '%1$d newly enrolled (%2$d new accounts), %3$d already enrolled.', 'academy-pro' ),
						$counts['enrolled'],
						$counts['created'],
						$counts['already']
					),
					'counts'  => $counts,
					'link'    => Service::get_link_info( $class_id ),
				];
			}
		);

		// For one class, say exactly what the sync did.
		if ( 1 === count( $results ) && $results[0]['ok'] ) {
			wp_send_json_success( [
				'message' => $results[0]['message'],
				'results' => $results
			] );
		}
		$this->send_results( $results, __( 'synced', 'academy-pro' ) );
	}

	/**
	 * Post the course's sections as Classroom topics and its lessons as
	 * materials (or update what was posted before).
	 */
	public function push_to_classroom() {
		$this->verify();
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- verified above
		$as_draft = ! empty( $_POST['draft'] ) && 'false' !== $_POST['draft'];
		$service  = new Service();
		if ( ! $service->can_publish() ) {
			wp_send_json_error(
				[
					'code'    => 'reconnect_scopes',
					'message' => __( 'Reconnect your Google account once to allow Academy to post topics and materials to Classroom.', 'academy-pro' ),
				]
			);
		}
		$publisher = new Publisher( $service );
		$results   = $this->for_each_owned_course(
			function ( $class_id, $post_id ) use ( $publisher, $service, $as_draft ) {
				try {
					$gc_class = $service->find_teaching_class( $class_id );
					if ( ! $gc_class ) {
						return [
							'ok'      => false,
							'message' => __( 'You don\'t teach this class.', 'academy-pro' ),
						];
					}
					// Google rejects posts to a class nobody has accepted yet.
					if ( 'PROVISIONED' === $gc_class['courseState'] ) {
						return [
							'ok'      => false,
							'message' => __( 'Accept this class in Google Classroom first, then post again.', 'academy-pro' ),
						];
					}
					$counts = $publisher->publish( $class_id, $post_id, $as_draft );
				} catch ( \Exception $e ) {
					if ( Service::ERROR_RECONNECT === $e->getMessage() ) {
						$this->send_exception( $e );
					}
					return [
						'ok'      => false,
						'message' => $this->google_error_message( $e ),
						'link'    => Service::get_link_info( $class_id ),
					];
				}//end try
				if ( is_wp_error( $counts ) ) {
					return [
						'ok'      => false,
						'message' => $counts->get_error_message(),
					];
				}
				$changed = array_sum( $counts );
				return [
					'ok'      => true,
					'message' => $changed
						? sprintf(
							/* translators: 1: lessons posted, 2: lessons updated, 3: topics posted or renamed, 4: items removed */
							__( 'Classroom updated: %1$d lessons posted, %2$d updated, %3$d topics added or renamed, %4$d removed.', 'academy-pro' ),
							$counts['materials_created'],
							$counts['materials_updated'],
							$counts['topics_created'] + $counts['topics_updated'],
							$counts['materials_removed'] + $counts['topics_removed']
						)
						: __( 'Classroom is already up to date.', 'academy-pro' ),
					'counts'  => $counts,
					'link'    => Service::get_link_info( $class_id ),
				];
			}
		);

		if ( 1 === count( $results ) && $results[0]['ok'] ) {
			wp_send_json_success(
				[
					'message' => $results[0]['message'],
					'results' => $results,
				]
			);
		}
		$this->send_results( $results, __( 'posted to Classroom', 'academy-pro' ) );
	}

	/**
	 * Delete the topics and materials this site posted to the class.
	 */
	public function unpublish_from_classroom() {
		$this->verify();
		$publisher = new Publisher( new Service() );
		$results   = $this->for_each_owned_course(
			function ( $class_id, $post_id ) use ( $publisher ) {
				try {
					$publisher->unpublish( $class_id, $post_id );
				} catch ( \Exception $e ) {
					if ( Service::ERROR_RECONNECT === $e->getMessage() ) {
						$this->send_exception( $e );
					}
					return [
						'ok'      => false,
						'message' => $this->google_error_message( $e ),
					];
				}
				return [
					'ok'      => true,
					'message' => '',
					'link'    => Service::get_link_info( $class_id ),
				];
			}
		);
		$this->send_results( $results, __( 'removed from Google Classroom', 'academy-pro' ) );
	}

	public function set_auto_sync() {
		$this->verify();
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- verified above
		$enabled = ! empty( $_POST['enabled'] ) && 'false' !== $_POST['enabled'];
		$results = $this->for_each_owned_course(
			function ( $class_id, $post_id ) use ( $enabled ) {
				if ( $enabled ) {
					update_post_meta( $post_id, Service::POST_AUTO_SYNC, 1 );
				} else {
					delete_post_meta( $post_id, Service::POST_AUTO_SYNC );
				}
				return [
					'ok' => true,
					'message' => '',
					'link' => Service::get_link_info( $class_id )
				];
			}
		);
		$this->send_results( $results, $enabled ? __( 'set to sync students daily', 'academy-pro' ) : __( 'set to manual sync', 'academy-pro' ) );
	}

	/** Deletes the imported Academy course; the Google class is untouched. */
	public function delete_course() {
		$this->verify();
		$results = $this->for_each_owned_course(
			function ( $class_id, $post_id ) {
				if ( ! wp_delete_post( $post_id, true ) ) {
					return [
						'ok' => false,
						'message' => __( 'The course couldn\'t be deleted.', 'academy-pro' )
					];
				}
				delete_user_meta( get_current_user_id(), 'academy_instructor_course_id', $post_id );
				return [
					'ok' => true,
					'message' => ''
				];
			}
		);
		$this->send_results( $results, __( 'removed from Academy', 'academy-pro' ) );
	}

	public function create_new_google_classroom() {
		$this->verify();
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- verified above
		$name    = isset( $_POST['class_name'] ) ? sanitize_text_field( wp_unslash( $_POST['class_name'] ) ) : '';
		$section = isset( $_POST['section'] ) ? sanitize_text_field( wp_unslash( $_POST['section'] ) ) : '';
		$subject = isset( $_POST['subject'] ) ? sanitize_text_field( wp_unslash( $_POST['subject'] ) ) : '';
		$room    = isset( $_POST['room'] ) ? sanitize_text_field( wp_unslash( $_POST['room'] ) ) : '';
		// phpcs:enable
		if ( '' === $name ) {
			wp_send_json_error( [ 'message' => __( 'Class name is required.', 'academy-pro' ) ] );
		}

		$service = new Service();
		try {
			$created = $service->classroom()->courses->create(
				new Course(
					[
						'name'               => $name,
						'section'            => $section,
						'descriptionHeading' => trim( $name . ' ' . $section ),
						'description'        => $subject ? sprintf( /* translators: %s: subject */ __( 'Subject: %s', 'academy-pro' ), $subject ) : '',
						'room'               => $room,
						'ownerId'            => 'me',
						'courseState'        => 'PROVISIONED',
					]
				)
			);
		} catch ( \Exception $e ) {
			$this->send_exception( $e );
		}

		$service->forget_classes_cache();
		wp_send_json_success(
			[
				'message' => __( 'Class created in Google Classroom. Accept it there to activate it.', 'academy-pro' ),
				'class'   => Service::class_to_array( $created ),
			]
		);
	}
}
