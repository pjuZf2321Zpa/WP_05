<?php
namespace AcademyProGoogleClassroom\Admin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AcademyPro\Google\Service\Classroom\CourseWorkMaterial;
use AcademyPro\Google\Service\Classroom\Link;
use AcademyPro\Google\Service\Classroom\Material;
use AcademyPro\Google\Service\Classroom\Topic;

/**
 * Publishes an Academy course's curriculum to its linked Google class:
 * each section becomes a Classroom topic and each lesson a Classroom
 * material linking back to the lesson on this site.
 *
 * The site owns what it publishes. A map on the course remembers which
 * Google topic/material belongs to which section/lesson, so publishing again
 * updates them in place, and items removed from the course are removed from
 * Classroom. Anything a teacher created by hand in Classroom is never touched.
 */
class Publisher {
	const META_MAP         = 'academy_google_classroom_push_map';
	const META_LAST_PUSHED = 'academy_google_classroom_last_pushed';

	/** @var Service */
	private $service;

	/**
	 * @param Service $service The course author's connection.
	 */
	public function __construct( Service $service ) {
		$this->service = $service;
	}

	/**
	 * @param int $post_id Academy course ID.
	 * @return array { topics: [index => topic_id], topic_names: [...], materials: [lesson_id => {id, hash, state}] }
	 */
	public static function get_map( $post_id ) {
		$map = get_post_meta( $post_id, self::META_MAP, true );
		$map = is_array( $map ) ? $map : [];
		return array_merge(
			[
				'topics'      => [],
				'topic_names' => [],
				'materials'   => [],
			],
			$map
		);
	}

	/**
	 * Create or update the class's topics and materials from the course.
	 *
	 * @param string $class_id Google Classroom class ID.
	 * @param int    $post_id  Academy course ID.
	 * @param bool   $as_draft Post new materials as drafts only the teacher sees.
	 * @return array|\WP_Error Counts of what changed.
	 * @throws \Exception When a Google call fails (what was posted is still saved).
	 */
	public function publish( $class_id, $post_id, $as_draft = false ) {
		if ( 'publish' !== get_post_status( $post_id ) ) {
			return new \WP_Error( 'course_not_published', __( 'Publish the course first, so the lesson links work for students.', 'academy-pro' ) );
		}
		if ( ! $this->service->can_publish() ) {
			return new \WP_Error( 'reconnect_scopes', __( 'Reconnect your Google account to allow Academy to post topics and materials.', 'academy-pro' ) );
		}

		$curriculum = get_post_meta( $post_id, 'academy_course_curriculum', true );
		$curriculum = is_array( $curriculum ) ? array_values( $curriculum ) : [];
		$state      = $as_draft ? 'DRAFT' : 'PUBLISHED';
		$map        = self::get_map( $post_id );
		$counts     = [
			'topics_created'    => 0,
			'topics_updated'    => 0,
			'topics_removed'    => 0,
			'materials_created' => 0,
			'materials_updated' => 0,
			'materials_removed' => 0,
		];
		$classroom  = $this->service->classroom();

		try {
			// 1. Sections → topics, by position.
			foreach ( $curriculum as $index => $section ) {
				$name = trim( wp_strip_all_tags( (string) ( $section['title'] ?? '' ) ) );
				/* translators: %d: section number */
				$name = '' !== $name ? $name : sprintf( __( 'Section %d', 'academy-pro' ), $index + 1 );
				$topic_id = $map['topics'][ $index ] ?? '';

				if ( $topic_id && ( $map['topic_names'][ $index ] ?? '' ) === $name ) {
					continue;
				}
				if ( $topic_id ) {
					try {
						$classroom->courses_topics->patch( $class_id, $topic_id, new Topic( [ 'name' => $name ] ), [ 'updateMask' => 'name' ] );
						$map['topic_names'][ $index ] = $name;
						++$counts['topics_updated'];
						continue;
					} catch ( \Exception $e ) {
						if ( ! self::is_not_found( $e ) ) {
							throw $e;
						}
						// Deleted in Classroom: create it again below.
					}
				}
				$topic                        = $classroom->courses_topics->create( $class_id, new Topic( [ 'name' => $name ] ) );
				$map['topics'][ $index ]      = (string) $topic->getTopicId();
				$map['topic_names'][ $index ] = $name;
				++$counts['topics_created'];
			}//end foreach

			// 2. Lessons → materials in their section's topic.
			$lessons = [];
			foreach ( $curriculum as $index => $section ) {
				foreach ( (array) ( $section['topics'] ?? [] ) as $item ) {
					if ( 'lesson' === ( $item['type'] ?? '' ) && ! empty( $item['id'] ) ) {
						$lessons[ (int) $item['id'] ] = $map['topics'][ $index ] ?? '';
					}
				}
			}

			// Classroom lists newest first, so create the last lesson first to
			// keep the course order top to bottom.
			foreach ( array_reverse( $lessons, true ) as $lesson_id => $topic_id ) {
				$data = $this->material_data( $lesson_id, $post_id, $topic_id );
				if ( ! $data ) {
					continue;
				}
				$saved = $map['materials'][ $lesson_id ] ?? null;

				if ( $saved ) {
					$mask = [];
					if ( $saved['hash'] !== $data['hash'] ) {
						$mask = [ 'title', 'description', 'topicId' ];
					}
					// Drafts can be published later; published can't go back.
					if ( 'DRAFT' === $saved['state'] && 'PUBLISHED' === $state ) {
						$mask[] = 'state';
					}
					if ( ! $mask ) {
						continue;
					}
					try {
						// phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- Google API property
						$classroom->courses_courseWorkMaterials->patch(
							$class_id,
							$saved['id'],
							new CourseWorkMaterial(
								[
									'title'       => $data['title'],
									'description' => $data['description'],
									'topicId'     => $topic_id,
									'state'       => $state,
								]
							),
							[ 'updateMask' => implode( ',', $mask ) ]
						);
						$map['materials'][ $lesson_id ] = [
							'id'    => $saved['id'],
							'hash'  => $data['hash'],
							'state' => in_array( 'state', $mask, true ) ? $state : $saved['state'],
						];
						++$counts['materials_updated'];
						continue;
					} catch ( \Exception $e ) {
						if ( ! self::is_not_found( $e ) ) {
							throw $e;
						}
					}//end try
				}//end if

				// phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- Google API property
				$material = $classroom->courses_courseWorkMaterials->create(
					$class_id,
					new CourseWorkMaterial(
						[
							'title'       => $data['title'],
							'description' => $data['description'],
							'topicId'     => $topic_id,
							'state'       => $state,
							'materials'   => [
								new Material(
									[
										'link' => new Link( [ 'url' => $data['url'] ] ),
									]
								),
							],
						]
					)
				);
				$map['materials'][ $lesson_id ] = [
					'id'    => (string) $material->getId(),
					'hash'  => $data['hash'],
					'state' => $state,
				];
				++$counts['materials_created'];
			}//end foreach

			// 3. Remove what this site posted for lessons and sections that
			// are no longer in the course.
			foreach ( array_diff_key( $map['materials'], $lessons ) as $lesson_id => $saved ) {
				$this->delete_quietly( 'courses_courseWorkMaterials', $class_id, $saved['id'] );
				unset( $map['materials'][ $lesson_id ] );
				++$counts['materials_removed'];
			}
			foreach ( $map['topics'] as $index => $topic_id ) {
				if ( $index >= count( $curriculum ) ) {
					$this->delete_quietly( 'courses_topics', $class_id, $topic_id );
					unset( $map['topics'][ $index ], $map['topic_names'][ $index ] );
					++$counts['topics_removed'];
				}
			}
		} finally {
			// Keep what did get created, even if a later call failed, so a
			// retry updates it instead of posting duplicates.
			update_post_meta( $post_id, self::META_MAP, $map );
		}//end try

		update_post_meta( $post_id, self::META_LAST_PUSHED, time() );
		return $counts;
	}

	/**
	 * Remove every topic and material this site posted to the class.
	 *
	 * @param string $class_id Google Classroom class ID.
	 * @param int    $post_id  Academy course ID.
	 * @return array Counts removed.
	 */
	public function unpublish( $class_id, $post_id ) {
		$map    = self::get_map( $post_id );
		$counts = [
			'materials_removed' => 0,
			'topics_removed'    => 0,
		];
		foreach ( $map['materials'] as $saved ) {
			$this->delete_quietly( 'courses_courseWorkMaterials', $class_id, $saved['id'] );
			++$counts['materials_removed'];
		}
		foreach ( $map['topics'] as $topic_id ) {
			$this->delete_quietly( 'courses_topics', $class_id, $topic_id );
			++$counts['topics_removed'];
		}
		delete_post_meta( $post_id, self::META_MAP );
		delete_post_meta( $post_id, self::META_LAST_PUSHED );
		return $counts;
	}

	/**
	 * Title, description and link for a lesson's material, or null if the
	 * lesson is gone or not published.
	 *
	 * @param int    $lesson_id Lesson ID.
	 * @param int    $post_id   Academy course ID.
	 * @param string $topic_id  Classroom topic ID.
	 * @return array|null
	 */
	private function material_data( $lesson_id, $post_id, $topic_id ) {
		$lesson = \Academy\Helper::get_lesson( $lesson_id, true );
		if ( ! $lesson || 'publish' !== ( $lesson['lesson_status'] ?? '' ) ) {
			return null;
		}
		$title       = trim( wp_strip_all_tags( (string) $lesson['lesson_title'] ) );
		$summary     = trim( wp_strip_all_tags( (string) ( $lesson['lesson_excerpt'] ?? '' ) ) );
		$summary     = '' !== $summary ? $summary : wp_trim_words( wp_strip_all_tags( strip_shortcodes( (string) $lesson['lesson_content'] ) ), 40 );
		$description = trim( $summary . "\n\n" . __( 'Open the lesson to continue.', 'academy-pro' ) );
		$url         = \Academy\Helper::get_topic_play_link(
			[
				'type' => 'lesson',
				'id'   => $lesson_id,
			],
			$post_id
		);
		return [
			'title'       => '' !== $title ? $title : __( 'Lesson', 'academy-pro' ),
			'description' => $description,
			'url'         => $url,
			'hash'        => md5( $title . '|' . $description . '|' . $topic_id ),
		];
	}

	/**
	 * Delete a topic or material, ignoring ones already gone.
	 *
	 * @param string $collection Classroom resource property, e.g. courses_topics.
	 * @param string $class_id   Google Classroom class ID.
	 * @param string $id         Item ID.
	 * @throws \Exception When Google fails for a reason other than "not found".
	 */
	private function delete_quietly( $collection, $class_id, $id ) {
		if ( ! $id ) {
			return;
		}
		try {
			$this->service->classroom()->{$collection}->delete( $class_id, $id );
		} catch ( \Exception $e ) {
			if ( ! self::is_not_found( $e ) ) {
				throw $e;
			}
		}
	}

	/**
	 * @param \Exception $e The caught exception.
	 * @return bool Whether Google said the item doesn't exist.
	 */
	private static function is_not_found( \Exception $e ) {
		return 404 === (int) $e->getCode();
	}
}
