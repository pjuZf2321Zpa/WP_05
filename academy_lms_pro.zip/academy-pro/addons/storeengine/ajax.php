<?php

namespace AcademyProStoreEngine;

use AcademyProStoreEngine\Ajax\TutorBooking;
use AcademyProStoreEngine\Ajax\CourseBundle;

class Ajax {
	/**
	 * Initialize the Ajax class.
	 *
	 * @return void
	 */
	public static function init() {
		( new TutorBooking() )->dispatch_actions();
		( new CourseBundle() )->dispatch_actions();
	}
}
