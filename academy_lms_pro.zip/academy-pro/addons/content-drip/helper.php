<?php
namespace AcademyProContentDrip;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Helper {
	public static function get_course_curriculum_array( $course_id ) {
		$course_curriculum = get_post_meta( $course_id, 'academy_course_curriculum', true );
		$prepare_curriculum = array();
		if ( is_array( $course_curriculum ) ) {
			foreach ( $course_curriculum as $curriculum ) {
				if ( is_array( $curriculum['topics'] ) ) {
					foreach ( $curriculum['topics'] as $topic ) {
						$prepare_curriculum[] = $topic;
					}
				}
			}
		}
		return $prepare_curriculum;
	}
	public static function get_previous_topic( $topics, $topic_id, $topic_type ) {
		foreach ( $topics as $key => $topic ) {
			$subTopics = isset( $topic['topics'] ) ? $topic['topics'] : [];
			if ( ! empty( $subTopics ) ) {
				foreach ( $subTopics as $subKey => $subTopic ) {
					if ( (int) $subTopic['id'] === (int) $topic_id && $subTopic['type'] === $topic_type ) {
						$n = 0;
						if ( $subKey > 0 ) {
							return $topic['topics'][ $subKey - 1 ];
						}
						$previousTopics = $topics[ $key - 1 ]['topics'] ?? $topics[ $key - 1 ];
						$set_topic = ! empty( $previousTopics ) ? $previousTopics : ++$n;
						return is_numeric( $set_topic ) ? ( $topics[ $key - ( 1 + $n ) ] ?? $topic['topics'][ $subKey ] ) : $set_topic;
					}
				}
			}

			if ( (int) $topic['id'] === (int) $topic_id && $topic['type'] === $topic_type ) {
				if ( isset( $topics[ $key - 1 ] ) ) {
					$i = 0;
					$prevTopics = isset( $topics[ $key - 1 ]['topics'] ) ? end( $topics[ $key - 1 ]['topics'] ) : $topics[ $key - 1 ];
					$set_topic = ! empty( $prevTopics ) ? $prevTopics : ++$i;
					return is_numeric( $set_topic ) ? ( $topics[ $key - ( 1 + $i ) ] ?? $topic ) : $set_topic;
				}
				return $topic;
			}
		}//end foreach
		return false;
	}

	public static function is_complete_previous_topic( $course_id, $topic_id, $topic_type ) {
		$course_curriculum = self::get_course_curriculum_array( $course_id );
		$previous_topic = self::get_previous_topic( $course_curriculum, $topic_id, $topic_type );
		$completed_topics_lists = (array) json_decode( get_user_meta( get_current_user_id(), 'academy_course_' . $course_id . '_completed_topics', true ), true );
		if ( is_array( $previous_topic ) ) {
			// if first element and previous element is same then return true.
			if ( (int) $topic_id === (int) $previous_topic['id'] ) {
				return true;
			} elseif ( 'lesson' === $previous_topic['type'] ) {
				if ( \Academy\Helper::get_lesson_meta( $topic_id, 'is_previewable' ) ) {
					return true;
				}
				return (bool) isset( $completed_topics_lists[ $previous_topic['type'] ][ $previous_topic['id'] ] );
			} elseif ( 'quiz' === $previous_topic['type'] ) {
				return (bool) isset( $completed_topics_lists[ $previous_topic['type'] ][ $previous_topic['id'] ] );
			} elseif ( 'assignment' === $previous_topic['type'] ) {
				return (bool) isset( $completed_topics_lists[ $previous_topic['type'] ][ $previous_topic['id'] ] );
			} elseif ( 'booking' === $previous_topic['type'] ) {
				return (bool) isset( $completed_topics_lists[ $previous_topic['type'] ][ $previous_topic['id'] ] );
			} elseif ( 'zoom' === $previous_topic['type'] ) {
				return (bool) isset( $completed_topics_lists[ $previous_topic['type'] ][ $previous_topic['id'] ] );
			}
		}
		return false;
	}

	/**
	 * Get the release/expiry window for every module (curriculum section) of
	 * a 'schedule_by_module' drip course: module N releases N months after
	 * the course's drip start point and expires when module N+1 releases
	 * (the last module never expires) — unless an admin has set a per-student
	 * override end date for that module, which replaces the computed expiry.
	 *
	 * @param int      $course_id Course ID.
	 * @param int|null $user_id   Student to compute the window for. Defaults to the current user.
	 * @return array<int,array{release:int,expiry:int|null}> Keyed by module (section) index.
	 */
	public static function get_module_drip_windows( $course_id, $user_id = null ) {
		$user_id = $user_id ? (int) $user_id : get_current_user_id();

		$course_curriculum = get_post_meta( $course_id, 'academy_course_curriculum', true );
		if ( ! is_array( $course_curriculum ) ) {
			return [];
		}

		$basis      = get_post_meta( $course_id, 'academy_course_module_drip_basis', true );
		$start_date = get_post_meta( $course_id, 'academy_course_module_drip_start_date', true );

		if ( 'fixed_date' === $basis && $start_date ) {
			$start_ts = strtotime( $start_date );
		} else {
			$enrolled = \Academy\Helper::is_enrolled( $course_id, $user_id );
			if ( ! $enrolled ) {
				return [];
			}
			// post_date is the site's local wall-clock time with no
			// timezone info, so strtotime() on it drifts by the site's UTC
			// offset against wp_date( 'U' ) (used below and by the caller)
			// — use the GMT column instead so both sides agree.
			$start_ts = strtotime( $enrolled->post_date_gmt . ' +00:00' );
		}

		$overrides = self::get_module_access_overrides( $course_id, $user_id );

		$total_modules = count( $course_curriculum );
		$windows       = [];
		foreach ( $course_curriculum as $index => $section ) {
			$release_ts = strtotime( "+{$index} month", $start_ts );
			$expiry_ts  = ( $index + 1 < $total_modules ) ? strtotime( '+1 month', $release_ts ) : null;

			if ( ! empty( $overrides[ $index ]['end_date'] ) ) {
				$override_ts = strtotime( $overrides[ $index ]['end_date'] . ' 23:59:59' );
				if ( $override_ts ) {
					$expiry_ts = $override_ts;
				}
			}

			$windows[ $index ] = array(
				'release' => $release_ts,
				'expiry'  => $expiry_ts,
			);
		}

		return $windows;
	}

	/**
	 * Get the release/expiry window for the curriculum module (Topic/section)
	 * a given lesson/quiz/assignment/booking belongs to.
	 *
	 * @param int      $course_id
	 * @param int      $topic_id
	 * @param string   $topic_type
	 * @param int|null $user_id Student to compute the window for. Defaults to the current user.
	 * @return array{release:int,expiry:int|null}|false
	 */
	public static function get_module_drip_window( $course_id, $topic_id, $topic_type, $user_id = null ) {
		$course_curriculum = get_post_meta( $course_id, 'academy_course_curriculum', true );
		if ( ! is_array( $course_curriculum ) ) {
			return false;
		}

		$module_index = false;
		foreach ( $course_curriculum as $index => $section ) {
			$items = ( isset( $section['topics'] ) && is_array( $section['topics'] ) ) ? $section['topics'] : [];
			foreach ( $items as $item ) {
				if ( isset( $item['id'], $item['type'] ) && (int) $item['id'] === (int) $topic_id && $item['type'] === $topic_type ) {
					$module_index = $index;
					break 2;
				}
			}
		}

		if ( false === $module_index ) {
			return false;
		}

		$windows = self::get_module_drip_windows( $course_id, $user_id );

		return $windows[ $module_index ] ?? false;
	}

	/**
	 * The curriculum modules (top-level curriculum sections) of a course, as
	 * a flat list — what the "Extend Module Access" admin UI lets an admin
	 * pick from.
	 *
	 * @param int $course_id
	 *
	 * @return array<int,array{index:int,title:string}>
	 */
	public static function get_modules_list( $course_id ) {
		$course_curriculum = get_post_meta( $course_id, 'academy_course_curriculum', true );
		if ( ! is_array( $course_curriculum ) ) {
			return [];
		}

		$modules = [];
		foreach ( $course_curriculum as $index => $section ) {
			$modules[] = array(
				'index' => $index,
				'title' => '' !== ( $section['title'] ?? '' )
					? (string) $section['title']
					/* translators: %d: module (curriculum section) number. */
					: sprintf( __( 'Module %d', 'academy-pro' ), $index + 1 ),
			);
		}

		return $modules;
	}

	/**
	 * A student's per-module access-end-date overrides for a course, as set
	 * by an admin/instructor via "Extend Module Access". Keyed by module
	 * (curriculum section) index.
	 *
	 * @param int $course_id
	 * @param int $user_id
	 *
	 * @return array<int,array{end_date:string,reason:string,extended_by:int,extended_at:int}>
	 */
	public static function get_module_access_overrides( $course_id, $user_id ) {
		$overrides = get_user_meta( $user_id, "academy_course_{$course_id}_module_access_overrides", true );
		$overrides = json_decode( (string) $overrides, true );

		return is_array( $overrides ) ? $overrides : [];
	}

	/**
	 * Set (or replace) a student's access-end-date override for one module of
	 * a course.
	 *
	 * @param int   $course_id
	 * @param int   $user_id
	 * @param mixed $module_index
	 * @param mixed $end_date
	 * @param mixed $reason
	 * @param mixed $extended_by
	 *
	 * @return array{end_date:string,reason:string,extended_by:int,extended_at:int} The saved override.
	 */
	public static function save_module_access_override( $course_id, $user_id, $module_index, $end_date, $reason, $extended_by ) {
		$overrides = self::get_module_access_overrides( $course_id, $user_id );

		$overrides[ $module_index ] = array(
			'end_date'    => $end_date,
			'reason'      => $reason,
			'extended_by' => (int) $extended_by,
			'extended_at' => time(),
		);

		update_user_meta( $user_id, "academy_course_{$course_id}_module_access_overrides", wp_json_encode( $overrides ) );

		return $overrides[ $module_index ];
	}
}
