<?php
namespace AcademyProContentDrip;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Hooks {
	public static function init() {
		$self = new self();
		add_action( 'academy/frontend/before_render_lesson', array( $self, 'render_drip_lesson' ), 10, 3 );
		add_action( 'academy_quizzes/frontend/before_render_quiz', array( $self, 'render_drip_quiz' ), 10, 2 );
		add_action( 'academy_pro_assignments/frontend/before_render_assignment', array( $self, 'render_drip_assignment' ), 10, 2 );
		add_action( 'academy_pro_tutor_booking/frontend/before_render_booking', array( $self, 'render_drip_booking' ), 10, 2 );
		add_action( 'academy/frontend/before_mark_topic_complete', array( $self, 'before_mark_topic_complete_check_drip_content' ), 10, 4 );

		add_action( 'academy/templates/curriculums/before_render_lesson_content', array( $self, 'lesson_php_render_content_drip' ), 10, 3 );
		add_action( 'academy/templates/curriculums/before_render_quiz_content', array( $self, 'quiz_php_render_content_drip' ), 10, 3 );
		add_action( 'academy/templates/curriculums/before_render_assignment_content', array( $self, 'assignment_php_render_content_drip' ), 10, 3 );
		add_action( 'academy/templates/curriculums/before_render_booking_content', array( $self, 'booking_php_render_content_drip' ), 10, 3 );

		add_filter( 'academy/get_course_curriculums', array( $self, 'add_module_drip_status_to_curriculums' ), 10, 2 );
	}

	/**
	 * Surface each module's (curriculum section's) release/expiry window on
	 * the learn-page curriculum payload for 'schedule_by_module' courses, so
	 * the sidebar can mark an expired module and its items without every
	 * client re-deriving the drip window itself. Mirrors the gate already
	 * enforced server-side in drip_content_checker() for the same drip type.
	 *
	 * @param mixed $curriculums
	 * @param int   $course_id
	 */
	public function add_module_drip_status_to_curriculums( $curriculums, $course_id ) {
		$drip_content_enabled = (bool) get_post_meta( $course_id, 'academy_course_drip_content_enabled', true );
		$drip_content_type    = get_post_meta( $course_id, 'academy_course_drip_content_type', true );
		if ( ! $drip_content_enabled || 'schedule_by_module' !== $drip_content_type ) {
			return $curriculums;
		}

		$windows = Helper::get_module_drip_windows( $course_id );
		if ( ! $windows ) {
			return $curriculums;
		}

		$now = wp_date( 'U' );
		foreach ( $curriculums as $index => &$section ) {
			$window = $windows[ $index ] ?? null;
			if ( ! $window ) {
				continue;
			}

			$is_released = $now >= $window['release'];
			$is_expired  = null !== $window['expiry'] && $now >= $window['expiry'];

			$section['is_module_expired']   = $is_expired;
			$section['module_release_date'] = self::format_date( $window['release'] );

			if ( ! isset( $section['topics'] ) || ! is_array( $section['topics'] ) ) {
				continue;
			}
			foreach ( $section['topics'] as &$topic ) {
				if ( ! $is_released || $is_expired ) {
					$topic['is_accessible'] = false;
				}
				$topic['is_module_expired'] = $is_expired;
			}
			unset( $topic );
		}//end foreach
		unset( $section );

		return $curriculums;
	}

	public function lesson_php_render_content_drip( $lesson, $course_id, $topic_id ) {
		$lesson = is_object( $lesson ) ? $lesson : (object) $lesson;
		$drip_content = isset( $lesson->meta['drip_content'] ) ? $lesson->meta['drip_content'] : '';
		if ( empty( $drip_content ) ) {
			$drip_content = $this->get_default_value();
		}
		$has_drip_content = $this->drip_content_checker( $drip_content, $course_id, 'lesson', $lesson->ID, true );
		if ( $has_drip_content ) {
			// hide existing content
			add_filter( 'academy/templates/curriculums/has_access_lesson_content', '__return_false' );
			// show content drip message
			\AcademyPro\Helper::get_template( 'curriculums/content-drip.php',
				$has_drip_content
			);
		}
	}

	public function render_drip_lesson( $lesson, $course_id, $lesson_id ) {
		$lesson = is_object( $lesson ) ? $lesson : (object) $lesson;
		$drip_content = isset( $lesson->meta['drip_content'] ) ? $lesson->meta['drip_content'] : '';
		if ( empty( $drip_content ) ) {
			$drip_content = $this->get_default_value();
		}
		$has_drip_content = $this->drip_content_checker( $drip_content, $course_id, 'lesson', $lesson_id );
		if ( $has_drip_content ) {
			wp_send_json_error( $has_drip_content );
		}
	}

	public function quiz_php_render_content_drip( $quiz, $course_id, $quiz_id ) {
		$drip_content = get_post_meta( $quiz_id, 'academy_quiz_drip_content', true );
		if ( empty( $drip_content ) ) {
			$drip_content = $this->get_default_value();
		}
		$has_drip_content = $this->drip_content_checker( $drip_content, $course_id, 'quiz', $quiz_id );
		if ( $has_drip_content ) {
			// hide existing content
			add_filter( 'academy/templates/curriculums/has_access_quiz_content', '__return_false' );
			// show content drip message
			\AcademyPro\Helper::get_template( 'curriculums/content-drip.php',
				$has_drip_content
			);
		}
	}

	public function render_drip_quiz( $course_id, $quiz_id ) {
		$drip_content = get_post_meta( $quiz_id, 'academy_quiz_drip_content', true );
		if ( empty( $drip_content ) ) {
			$drip_content = $this->get_default_value();
		}
		$has_drip_content = $this->drip_content_checker( $drip_content, $course_id, 'quiz', $quiz_id );
		if ( $has_drip_content ) {
			wp_send_json_error( $has_drip_content );
		}
	}

	public function assignment_php_render_content_drip( $assignment, $course_id, $assignment_id ) {
		$drip_content = get_post_meta( $assignment_id, 'academy_assignment_drip_content', true );
		if ( empty( $drip_content ) ) {
			$drip_content = $this->get_default_value();
		}
		$has_drip_content = $this->drip_content_checker( $drip_content, $course_id, 'assignment', $assignment_id );
		if ( $has_drip_content ) {
			// hide existing content
			add_filter( 'academy/templates/curriculums/has_access_assignment_content', '__return_false' );
			// show content drip message
			\AcademyPro\Helper::get_template( 'curriculums/content-drip.php',
				$has_drip_content
			);
		}
	}

	public function render_drip_assignment( $course_id, $assignment_id ) {
		$drip_content = get_post_meta( $assignment_id, 'academy_assignment_drip_content', true );
		if ( empty( $drip_content ) ) {
			$drip_content = $this->get_default_value();
		}
		$has_drip_content = $this->drip_content_checker( $drip_content, $course_id, 'assignment', $assignment_id );
		if ( $has_drip_content ) {
			wp_send_json_error( $has_drip_content );
		}
	}

	public function render_drip_booking( $course_id, $booking_id ) {
		$drip_content = get_post_meta( $booking_id, '_academy_booking_drip_content', true );
		if ( empty( $drip_content ) ) {
			$drip_content = $this->get_default_value();
		}
		$has_drip_content = $this->drip_content_checker( $drip_content, $course_id, 'booking', $booking_id );
		if ( $has_drip_content ) {
			wp_send_json_error( $has_drip_content );
		}
	}

	public function booking_php_render_content_drip( $calendar_settings, $course_id, $booking_id ) {
		$drip_content = get_post_meta( $booking_id, '_academy_booking_drip_content', true );
		if ( empty( $drip_content ) ) {
			$drip_content = $this->get_default_value();
		}
		$has_drip_content = $this->drip_content_checker( $drip_content, $course_id, 'booking', $booking_id );
		if ( $has_drip_content ) {
			// hide existing content
			add_filter( 'academy/templates/curriculums/has_access_booking_content', '__return_false' );
			// show the drip message
			\AcademyPro\Helper::get_template( 'curriculums/content-drip.php',
				$has_drip_content
			);
		}
	}

	public function before_mark_topic_complete_check_drip_content( $type, $course_id, $topic_id, $user_id ) {
		$drip_content_enabled = (bool) get_post_meta( $course_id, 'academy_course_drip_content_enabled', true );
		$drip_type = get_post_meta( $course_id, 'academy_course_drip_content_type', true );
		if ( ! $drip_content_enabled ) {
			return;
		}
		// check is course drip sequentially
		if ( 'schedule_by_sequentially' === $drip_type && true !== Helper::is_complete_previous_topic( $course_id, $topic_id, $type ) ) {
			if ( \Academy\Helper::is_server_learn_page() ) {
				wp_die(
					// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					esc_html__( 'You must complete the previous topic to proceed.', 'academy-pro' ),
					// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					esc_html__( 'Error', 'academy-pro' ),
					array(
						'response' => 403,
						'back_link' => true,
					)
				);
			}
			wp_send_json_error(
				__( 'You must complete the previous topic to proceed.', 'academy-pro' ),
			);
		}

		switch ( $type ) {
			case 'lesson':
				$drip_content = \Academy\Helper::get_lesson_meta( $topic_id, 'drip_content' );
				break;
			case 'quiz':
				$drip_content = get_post_meta( $topic_id, 'academy_quiz_drip_content', true );
				break;
			case 'assignment':
				$drip_content = get_post_meta( $topic_id, 'academy_assignment_drip_content', true );
				break;
			case 'booking':
				$drip_content = get_post_meta( $topic_id, '_academy_booking_drip_content', true );
				break;
			default:
				$drip_content = null;
		}//end switch

		// Types with no per-item drip meta set (e.g. a 'schedule_by_module'
		// course, which is configured at the course level only) still need
		// to go through the checker — fall back to defaults instead of
		// skipping it.
		if ( null !== $drip_content ) {
			if ( empty( $drip_content ) ) {
				$drip_content = $this->get_default_value();
			}
			$has_drip_content = $this->drip_content_checker( $drip_content, $course_id, $type, $topic_id );
		}

		if ( ! empty( $has_drip_content ) ) {
			wp_send_json_error(
				$has_drip_content['message']
			);
		}
	}

	/**
	 * Format a drip date in the site's date format and language.
	 *
	 * gmdate() never translates month/day names, so French sites got
	 * "6 October 2026". wp_date() localizes them; the UTC zone keeps the
	 * calendar day identical to what gmdate() showed, since the drip
	 * timestamps (e.g. strtotime() of the scheduled date) are UTC-based.
	 *
	 * @param int $timestamp Unix timestamp.
	 * @return string
	 */
	private static function format_date( $timestamp ) {
		return (string) wp_date( get_option( 'date_format' ), (int) $timestamp, new \DateTimeZone( 'UTC' ) );
	}

	public function get_default_value() {
		return [
			'schedule_by_date' => '',
			'schedule_by_topic_complete_date' => 0,
			'schedule_by_enroll_date' => 0,
			'schedule_by_prerequisite' => [],
			'schedule_by_topic_unlock_date' => 0,
		];
	}
	public function drip_content_checker( $drip_content, $course_id, $type, $topic_id, $is_php_render = false ) {
		$drip_content_enabled = (bool) get_post_meta( $course_id, 'academy_course_drip_content_enabled', true );
		if ( ! $drip_content_enabled ) {
			return false;
		}

		if ( is_string( $drip_content ) ) {
			$drip_content = json_decode( $drip_content, true );
		}

		if ( ! is_array( $drip_content ) ) {
			$drip_content  = [];
		}

		$drip_content_type = get_post_meta( $course_id, 'academy_course_drip_content_type', true );
		$message = '';
		// check drip content isset or not
		if ( 'schedule_by_date' === $drip_content_type && $drip_content['schedule_by_date'] ) {
			if ( strtotime( $drip_content['schedule_by_date'] ) > wp_date( 'U' ) ) {
				$message = __( 'This content will be accessible on', 'academy-pro' ) . ' ' . self::format_date( strtotime( $drip_content['schedule_by_date'] ) );
				return array(
					'message' => $message,
					'type' => $type
				);
			}
		} elseif ( 'schedule_by_topic_complete_date' === $drip_content_type && ! empty( $drip_content['schedule_by_topic_complete_date'] ) ) {
			$is_complete = Helper::is_complete_previous_topic( $course_id, $topic_id, $type );
			if ( ! $is_complete ) {
				return array(
					'message' => __( 'You must complete the previous topic to proceed.', 'academy-pro' ),
					'type' => $type
				);
			}

			$completed_topics_lists = (array) json_decode( get_user_meta( get_current_user_id(), 'academy_course_' . $course_id . '_completed_topics', true ), true );
			// Already completed itself — content drip no longer applies.
			if ( isset( $completed_topics_lists[ $type ][ $topic_id ] ) ) {
				return false;
			}

			// Count the days from the SPECIFIC previous topic's completion —
			// not from whichever topic happens to appear first in the
			// completed-topics list (which was the previous behaviour and
			// picked an unrelated timestamp whenever the learner had
			// completed anything else in the course).
			$course_curriculum = Helper::get_course_curriculum_array( $course_id );
			$previous_topic     = Helper::get_previous_topic( $course_curriculum, $topic_id, $type );
			// The very first topic in the course has no previous topic to
			// count from (get_previous_topic returns the topic itself), so
			// it stays accessible as soon as `is_complete_previous_topic`
			// above already confirmed that.
			if ( is_array( $previous_topic ) && ! ( (int) $previous_topic['id'] === (int) $topic_id && $previous_topic['type'] === $type ) ) {
				$previous_completed_at = $completed_topics_lists[ $previous_topic['type'] ][ $previous_topic['id'] ] ?? null;
				if ( $previous_completed_at ) {
					$content_available_date = $previous_completed_at + ( $drip_content['schedule_by_topic_complete_date'] * DAY_IN_SECONDS );
					if ( $content_available_date > wp_date( 'U' ) ) {
						return array(
							'message' => __( 'This content will be accessible on', 'academy-pro' ) . ' ' . self::format_date( $content_available_date ),
							'type'    => $type,
						);
					}
				}
			}
		} elseif ( 'schedule_by_topic_unlock_date' === $drip_content_type && ! empty( $drip_content['schedule_by_topic_unlock_date'] ) ) {
			// This type locks a topic a fixed number of days after the
			// student got ACCESS to the course — it does not depend on
			// finishing any topic. The previous implementation only ever
			// checked the day math inside `if ($saved_topics_lists)`, so a
			// learner who hadn't completed anything yet (the common case)
			// never got locked out at all, no matter how many days passed.
			// Enrollment date is the only "access" timestamp we have, so use
			// that directly instead.
			$completed_topics_lists = (array) json_decode( get_user_meta( get_current_user_id(), 'academy_course_' . $course_id . '_completed_topics', true ), true );
			if ( isset( $completed_topics_lists[ $type ][ $topic_id ] ) ) {
				return false;
			}

			$enrolled = \Academy\Helper::is_enrolled( $course_id, get_current_user_id() );
			if ( $enrolled ) {
				// post_date is local wall-clock time with no timezone info;
				// use the GMT column so this lines up with wp_date( 'U' ) below.
				$content_unavailable_date = strtotime( "$enrolled->post_date_gmt +00:00 +" . $drip_content['schedule_by_topic_unlock_date'] . ' days' );
				if ( $content_unavailable_date < wp_date( 'U' ) ) {
					return array(
						'message' => __( 'This content has been expired on', 'academy-pro' ) . ' ' . self::format_date( $content_unavailable_date ),
						'type'    => $type,
					);
				}
			}
		} elseif ( 'schedule_by_enroll_date' === $drip_content_type && $drip_content['schedule_by_enroll_date'] ) {
			$enrolled    = \Academy\Helper::is_enrolled( $course_id, get_current_user_id() );
			// post_date is local wall-clock time with no timezone info;
			// use the GMT column so this lines up with wp_date( 'U' ) below.
			$content_available_date = strtotime( "$enrolled->post_date_gmt +00:00 +" . $drip_content['schedule_by_enroll_date'] . ' days' );
			if ( $content_available_date > wp_date( 'U' ) ) {
				$message = __( 'This content will be accessible on', 'academy-pro' ) . ' ' . self::format_date( $content_available_date );
				return array(
					'message' => $message,
					'type' => $type
				);
			}
		} elseif ( 'schedule_by_sequentially' === $drip_content_type ) {
			if ( true !== Helper::is_complete_previous_topic( $course_id, $topic_id, $type ) ) {
				return array(
					'message' => __( 'You must complete the previous topic to proceed.', 'academy-pro' ),
					'type' => $type
				);
			}
		} elseif ( 'schedule_by_prerequisite' === $drip_content_type && count( $drip_content['schedule_by_prerequisite'] ) ) {
			$completed_topics_lists = (array) json_decode( get_user_meta( get_current_user_id(), 'academy_course_' . $course_id . '_completed_topics', true ), true );
			$have_to_complete = array();
			if ( is_array( $drip_content['schedule_by_prerequisite'] ) ) {
				foreach ( $drip_content['schedule_by_prerequisite'] as $prerequisite_item ) {
					$is_completed = ( isset( $completed_topics_lists[ $prerequisite_item['type'] ][ $prerequisite_item['value'] ] ) ? $completed_topics_lists[ $prerequisite_item['type'] ][ $prerequisite_item['value'] ] : '' );
					if ( ! $is_completed ) {
						$have_to_complete[] = $prerequisite_item;
					}
				}
			}

			if ( count( $have_to_complete ) ) {
				return array(
					'message' => __( 'To access this topic, finish the following prerequisites.', 'academy-pro' ),
					'type' => $type,
					'data' => $have_to_complete,
				);
			}
		} elseif ( 'schedule_by_module' === $drip_content_type ) {
			$window = Helper::get_module_drip_window( $course_id, $topic_id, $type );
			if ( $window ) {
				$now = wp_date( 'U' );
				if ( $now < $window['release'] ) {
					return array(
						'message' => __( 'This content will be accessible on', 'academy-pro' ) . ' ' . self::format_date( $window['release'] ),
						'type'    => $type,
					);
				}
				if ( null !== $window['expiry'] && $now >= $window['expiry'] ) {
					return array(
						'message' => __( 'This content has expired.', 'academy-pro' ),
						'type'    => $type,
					);
				}
			}
		}//end if
	}
}
