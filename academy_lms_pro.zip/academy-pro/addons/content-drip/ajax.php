<?php
namespace AcademyProContentDrip;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Backs the "Extend Module Access" admin action: lets an admin/instructor
 * grant a student more time on one module of a 'schedule_by_module' drip
 * course, overriding that module's computed expiry for that student only.
 */
class Ajax {

	public static function init() {
		$self = new self();
		add_action( 'wp_ajax_academy_pro/get_module_access_info', array( $self, 'get_module_access_info' ) );
		add_action( 'wp_ajax_academy_pro/extend_module_access', array( $self, 'extend_module_access' ) );
	}

	/**
	 * Managing a student's module access is an instructor/admin operation.
	 * Require a valid nonce and that the caller is an administrator or an
	 * instructor of the specific course — mirrors
	 * CourseExtendDuration::verify_can_manage_enrollment_duration().
	 *
	 * @param int $course_id
	 */
	protected function verify_can_manage_module_access( $course_id ) {
		check_ajax_referer( 'academy_nonce', 'security' );
		if ( ! current_user_can( 'manage_options' ) &&
			! ( current_user_can( 'manage_academy_instructor' ) && \Academy\Helper::is_instructor_of_this_course( get_current_user_id(), $course_id ) ) ) {
			wp_send_json_error( __( 'Sorry, you are not allowed to manage module access for this course.', 'academy-pro' ) );
		}
	}

	/**
	 * This action only makes sense for a course whose drip type is
	 * 'schedule_by_module' — anything else has no module windows to extend.
	 *
	 * @param int $course_id
	 */
	protected function assert_module_drip_course( $course_id ) {
		$drip_content_enabled = (bool) get_post_meta( $course_id, 'academy_course_drip_content_enabled', true );
		$drip_content_type    = get_post_meta( $course_id, 'academy_course_drip_content_type', true );
		if ( ! $drip_content_enabled || 'schedule_by_module' !== $drip_content_type ) {
			wp_send_json_error( __( 'This course does not use module-based content drip.', 'academy-pro' ) );
		}
	}

	/**
	 * The module list for a course, each with its computed release/expiry
	 * window and any existing override for the given student — what the
	 * "Extend Module Access" modal needs to render.
	 */
	public function get_module_access_info() {
		// Nonce is verified in verify_can_manage_module_access() below before any data is returned.
		$course_id = isset( $_POST['course_id'] ) ? absint( $_POST['course_id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$user_id   = isset( $_POST['user_id'] ) ? absint( $_POST['user_id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing

		if ( ! $course_id || ! $user_id ) {
			wp_send_json_error( __( 'Missing or invalid parameters.', 'academy-pro' ) );
		}

		$this->verify_can_manage_module_access( $course_id );
		$this->assert_module_drip_course( $course_id );

		$modules   = Helper::get_modules_list( $course_id );
		$windows   = Helper::get_module_drip_windows( $course_id, $user_id );
		$overrides = Helper::get_module_access_overrides( $course_id, $user_id );

		foreach ( $modules as &$module ) {
			$window                   = $windows[ $module['index'] ] ?? null;
			$module['release_date']   = ( $window && $window['release'] ) ? gmdate( 'Y-m-d', $window['release'] ) : '';
			$module['expiry_date']       = ( $window && $window['expiry'] ) ? gmdate( 'Y-m-d', $window['expiry'] ) : '';
			$override                    = $overrides[ $module['index'] ] ?? null;
			$module['override_end_date'] = $override['end_date'] ?? '';
			$module['override_reason']   = $override['reason'] ?? '';
		}
		unset( $module );

		wp_send_json_success( array( 'modules' => $modules ) );
	}

	/**
	 * Save a student's access-end-date override for one module.
	 */
	public function extend_module_access() {
		// Nonce is verified in verify_can_manage_module_access() below before any state change.
		$course_id    = isset( $_POST['course_id'] ) ? absint( $_POST['course_id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$user_id      = isset( $_POST['user_id'] ) ? absint( $_POST['user_id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$module_index = isset( $_POST['module_index'] ) && '' !== $_POST['module_index'] ? absint( $_POST['module_index'] ) : null; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$end_date     = isset( $_POST['end_date'] ) ? sanitize_text_field( wp_unslash( $_POST['end_date'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$reason       = isset( $_POST['reason'] ) ? sanitize_textarea_field( wp_unslash( $_POST['reason'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing

		if ( ! $course_id || ! $user_id || null === $module_index || ! $end_date || ! strtotime( $end_date ) ) {
			wp_send_json_error( __( 'Missing or invalid parameters.', 'academy-pro' ) );
		}

		$this->verify_can_manage_module_access( $course_id );
		$this->assert_module_drip_course( $course_id );

		$modules       = Helper::get_modules_list( $course_id );
		$valid_indexes = wp_list_pluck( $modules, 'index' );
		if ( ! in_array( $module_index, $valid_indexes, true ) ) {
			wp_send_json_error( __( 'Invalid module.', 'academy-pro' ) );
		}

		$override = Helper::save_module_access_override( $course_id, $user_id, $module_index, $end_date, $reason, get_current_user_id() );

		wp_send_json_success( array( 'override' => $override ) );
	}
}
