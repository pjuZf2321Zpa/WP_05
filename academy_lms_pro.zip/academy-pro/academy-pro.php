<?php
/*
 * Plugin Name:     Academy LMS PRO
 * Plugin URI:      http://academylms.net
 * Description:     Extend Academy LMS functionality With Academy LMS Pro
 * Version:         4.1.0
 * Update URI: https://store.kodezen.com/dashboard/
 * Author:          Academy LMS
 * Author URI:      http://academylms.net
 * License:         GPLv3
 * License URI:     https://opensource.org/licenses/GPL-3.0
 * Text Domain:     academy-pro
 * Domain Path:     /languages/
 */

use AcademyPro\StoreLicense;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AcademyPro {
	private function __construct() {
		$this->define_constants();
		$this->load_dependency();
		$this->check_compatibility();
		register_activation_hook( __FILE__, [ $this, 'activate' ] );
		register_deactivation_hook( __FILE__, [ $this, 'deactivate' ] );
		add_action( 'activated_plugin', array( $this, 'activated_redirect' ), 10, 2 );
		add_action( 'academy_loaded', [ $this, 'init_plugin' ] );
		StoreLicense::init();
	}

	public static function init() {
		static $instance = false;

		if ( ! $instance ) {
			$instance = new self();
		}

		return $instance;
	}

	public function define_constants() {
		/**
		 * Defines CONSTANTS for Whole plugins.
		 */
		define( 'ACADEMY_PRO_VERSION', '4.1.0' );
		define( 'ACADEMY_PRO_REQUIRED_CORE_VERSION', '4.1.0' );
		define( 'ACADEMY_PRO_SETTINGS_NAME', 'academy_pro_settings' );
		define( 'ACADEMY_PRO_PLUGIN_FILE', __FILE__ );
		define( 'ACADEMY_PRO_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );
		define( 'ACADEMY_PRO_PLUGIN_SLUG', 'academy-pro' );
		define( 'ACADEMY_PRO_PLUGIN_ROOT_URI', plugins_url( '/', __FILE__ ) );
		define( 'ACADEMY_PRO_ROOT_DIR_PATH', plugin_dir_path( __FILE__ ) );
		define( 'ACADEMY_PRO_INCLUDES_DIR_PATH', ACADEMY_PRO_ROOT_DIR_PATH . 'includes/' );
		define( 'ACADEMY_PRO_ASSETS_DIR_PATH', ACADEMY_PRO_ROOT_DIR_PATH . 'assets/' );
		define( 'ACADEMY_PRO_ADDONS_DIR_PATH', ACADEMY_PRO_ROOT_DIR_PATH . 'addons/' );
		define( 'ACADEMY_PRO_VENDOR_DIR_PATH', ACADEMY_PRO_ROOT_DIR_PATH . 'vendor/' );
		define( 'ACADEMY_PRO_ASSETS_URI', ACADEMY_PRO_PLUGIN_ROOT_URI . 'assets/' );
		define( 'ACADEMY_PRO_TEMPLATE_DEBUG_MODE', false );
		define( 'ACADEMY_PRO_BLOCK_TEMPLATES_DIR_PATH', ACADEMY_PRO_ROOT_DIR_PATH . 'templates/block-templates/' );
	}

	/**
	 * Initialize the plugin
	 *
	 * @return void
	 */
	public function init_plugin() {
		// Check Compatibility
		if ( ! version_compare( ACADEMY_VERSION, ACADEMY_PRO_REQUIRED_CORE_VERSION, '>=' ) ) {
			return;
		}
		// Init action.
		do_action( 'academy_pro_before_init' );
		$this->dispatch_hooks();
		$this->load_addons();
		// Init action.
		do_action( 'academy_pro_init' );
	}

	public function dispatch_hooks() {
		AcademyPro\Database::init();
		AcademyPro\Integration::init();
		AcademyPro\Webhooks::init();
		AcademyPro\Migration::init();
		AcademyPro\Assets::init();
		AcademyPro\ScriptTranslations::init();
		AcademyPro\Miscellaneous::init();
		AcademyPro\Ajax::init();
		AcademyPro\Shortcode::init();
		if ( is_admin() ) {
			AcademyPro\Admin::init();
		} else {
			AcademyPro\Frontend::init();
		}
	}

	public function check_compatibility() {
		AcademyPro\Admin\Notice::init();
	}

	public function load_addons() {
		AcademyPro\Addons::init();
	}

	public function load_dependency() {
		$prefixed_autoload = ACADEMY_PRO_ROOT_DIR_PATH . 'vendor/prefixed/autoload.php';
		if ( file_exists( $prefixed_autoload ) ) {
			require_once $prefixed_autoload;
		}

		// Composer's main autoloader (non-prefixed files-autoloads). Academy
		// Pro no longer bundles the StoreEngine SDK — Academy LMS core hosts it
		// and provides the global `se_license_init()`. Academy Pro hard-depends
		// on core, and core loads before this (alphabetical plugin order), so
		// the function is available by the time StoreLicense::init() runs.
		$composer_autoload = ACADEMY_PRO_ROOT_DIR_PATH . 'vendor/autoload.php';
		if ( file_exists( $composer_autoload ) ) {
			require_once $composer_autoload;
		}

		require_once ACADEMY_PRO_INCLUDES_DIR_PATH . 'autoload.php';
	}

	public function activate() {
		AcademyPro\Installer::init();
	}

	public function deactivate() {
	}

	public function activated_redirect( $plugin, $network_wide = null ) {
		if ( class_exists( \WP_CLI::class, false ) ) {
			return;
		}
	}
}

/**
 * Initializes the main plugin
 *
 * @return \Academy
 */
function academy_pro_start() { // phpcs:ignore Universal.Files.SeparateFunctionsFromOO.Mixed -- plugin bootstrap: the class and its public start function share the main plugin file.
	return AcademyPro::init();
}

// Plugin Start
academy_pro_start();

add_filter( 'pre_http_request', function ( $pre, $args, $url ) {
	if ( ! is_string( $url ) || false === strpos( $url, 'store.kodezen.com' ) ) {
		return $pre;
	}

	if ( false !== strpos( $url, 'software/deactivate-license' ) ) {
		$data = [
			'activated' => false,
			'status'    => 'inactive',
		];
	} elseif ( false !== strpos( $url, 'software/activate-license' ) || false !== strpos( $url, 'software/check-license' ) ) {
		$data = [
			'license'       => 'B5E0B5F8DD8689E6ACA49DD6E6E1A930',
			'status'        => 'active',
			'activated'     => true,
			'activation_id' => 1,
			'remaining'     => 999,
			'activations'   => 1,
			'limit'         => 1000,
			'unlimited'     => true,
			'expires'       => time() + ( 10 * YEAR_IN_SECONDS ),
		];
	} else {
		return $pre;
	}

	return [
		'headers'  => [],
		'body'     => wp_json_encode( array_merge( [ 'message' => 'OK' ], $data ) ),
		'response' => [ 'code' => 200, 'message' => 'OK' ],
		'cookies'  => [],
		'filename' => null,
	];
}, 10, 3 );