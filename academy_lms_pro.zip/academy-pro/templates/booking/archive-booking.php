<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

	academy_get_header( 'booking' );

	$sidebar_position = \Academy\Helper::get_settings( 'tutor_booking_archive_sidebar_position', 'right' );

	/**
	 * @hook - academy/templates/before_main_content
	 */
	do_action( 'academy/templates/before_main_content', 'archive-booking.php' );
?>

<div class="academy-bookings">
	<div class="academy-container">
		<div class="academy-row">
			<div class="academy-col-12">
				<?php do_action( 'academy_pro/templates/booking/archive_booking_header' ); ?>
			</div>
			<?php
			if ( 'left' === $sidebar_position ) :
				?>
				<div class="academy-col-md-3"><?php do_action( 'academy_pro/templates/booking/archive_booking_sidebar' ); ?></div> 
				<?php
				endif;
			?>
			<div class="<?php echo esc_attr( 'none' === $sidebar_position ? 'academy-col-12' : 'academy-col-md-9' ); ?>"><?php do_action( 'academy_pro/templates/booking/archive_booking_content' ); ?></div>
			<?php
			if ( 'right' === $sidebar_position ) :
				?>
				<div class="academy-col-md-3"><?php do_action( 'academy_pro/templates/booking/archive_booking_sidebar' ); ?></div> 
				<?php
				endif;
			?>
			<div class="academy-col-12">
				<?php do_action( 'academy_pro/templates/booking/archive_booking_footer' ); ?>
			</div>
		</div>
	</div>
</div>

<?php
	/**
	 * @hook - academy/templates/after_main_content
	 */
	do_action( 'academy/templates/after_main_content', 'archive-booking.php' );
?>

<?php
academy_get_footer( 'booking' );