<?php
namespace AcademyPro\Ajax;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


class CourseExtendDuration {

	public static function init() {
		$self = new self();
		if ( ! \Academy\Helper::get_settings( 'is_expire_course_enrollment', false ) ) {
			return;
		}
		add_action( 'wp_ajax_academy_pro/extend_enrollment_duration', array( $self, 'extend_enrollment_duration' ) );
		add_action( 'wp_ajax_academy_pro/get_enrollment_duration', array( $self, 'get_enrollment_duration' ) );
	}

	/**
	 * Managing a student's enrollment duration is an instructor/admin operation.
	 * Require a valid nonce and that the caller is an administrator or an
	 * instructor of the specific course. Without this, any logged-in user could
	 * grant themselves (or anyone) unlimited access to any course, and the
	 * missing nonce also made it CSRF-able against an admin.
	 *
	 * @param int $course_id
	 */
	protected function verify_can_manage_enrollment_duration( $course_id ) {
		check_ajax_referer( 'academy_nonce', 'security' );
		if ( ! current_user_can( 'manage_options' ) &&
			! ( current_user_can( 'manage_academy_instructor' ) && \Academy\Helper::is_instructor_of_this_course( get_current_user_id(), $course_id ) ) ) {
			wp_send_json_error( __( 'Sorry, you are not allowed to manage enrollment duration for this course.', 'academy-pro' ) );
		}
	}

	public function extend_enrollment_duration() {
		// Nonce is verified in verify_can_manage_enrollment_duration() below before any state change.
		$extend_time = isset( $_POST['extend_duration'] ) ? absint( $_POST['extend_duration'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$course_id   = isset( $_POST['course_id'] ) ? absint( $_POST['course_id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$user_id     = isset( $_POST['user_id'] ) ? absint( $_POST['user_id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$unit        = isset( $_POST['duration_unit'] ) ? sanitize_text_field( wp_unslash( $_POST['duration_unit'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing

		if ( ! $extend_time || ! $course_id || ! $user_id || ! $unit ) {
			wp_send_json_error( 'Missing or invalid parameters.' );
			return;
		}

		$this->verify_can_manage_enrollment_duration( $course_id );

		$expire_time    = (int) get_post_meta( $course_id, 'academy_course_expire_enrollment', true );
		$extend_time    = $this->convert_duration_to_days( $extend_time, $unit );
		$total_time     = $expire_time + $extend_time;
		// update extend duration for user
		update_user_meta( $user_id, "academy_course_extended_expire_time_{$course_id}", $extend_time );
		wp_send_json_success( array( 'new_expiry' => $total_time ) );
	}

	public function get_enrollment_duration() {
		// Nonce is verified in verify_can_manage_enrollment_duration() below before any state change.
		$course_id   = isset( $_POST['course_id'] ) ? absint( $_POST['course_id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$user_id     = isset( $_POST['user_id'] ) ? absint( $_POST['user_id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing

		if ( ! $course_id || ! $user_id ) {
			wp_send_json_error( 'Missing or invalid parameters.' );
			return;
		}

		$this->verify_can_manage_enrollment_duration( $course_id );

		$get_extend_enrollment_time = (int) get_user_meta( $user_id, "academy_course_extended_expire_time_{$course_id}", true );
		$expire_time       = (int) get_post_meta( $course_id, 'academy_course_expire_enrollment', true );
		$extend_total_time = $expire_time + $get_extend_enrollment_time;
		// Empty for a course on Academy's own day-count expiry (or with no
		// expiry system at all) — filled in by academy-pro's WooCommerce
		// Subscriptions addon when this course's access instead comes from a
		// subscription, so the admin sees why extending the day-count here
		// wouldn't do anything for this student.
		$access_note = apply_filters( 'academy/templates/frontend-dashboard/course_access_note', '', $course_id, $user_id );
		wp_send_json_success(
			array(
				'total_time'  => $extend_total_time,
				'access_note' => $access_note,
			)
		);
	}

	public function convert_duration_to_days( $time, $unit ) {
		switch ( $unit ) {
			case 'week':
				return $time * 7;
			case 'month':
				return $time * 30;
			case 'day':
			default:
				return $time;
		}
	}
}
