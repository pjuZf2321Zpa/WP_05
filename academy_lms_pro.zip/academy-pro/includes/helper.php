<?php
namespace AcademyPro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Helper {
	/**
	 * Wraps count_user_posts(), using WordPress VIP's cached variant when available.
	 *
	 * @param int    $user_id   User ID.
	 * @param string $post_type Post type.
	 * @return int
	 */
	public static function count_user_posts( $user_id, $post_type = 'post' ) {
		if ( function_exists( 'wpcom_vip_count_user_posts' ) ) {
			return (int) wpcom_vip_count_user_posts( $user_id, $post_type );
		}
		return (int) count_user_posts( $user_id, $post_type ); // phpcs:ignore WordPressVIPMinimum.Functions.RestrictedFunctions.count_user_posts_count_user_posts -- non-VIP fallback.
	}

	/**
	 * Client IP for rate limits, analytics and captcha checks.
	 *
	 * @return string Empty when unavailable.
	 */
	public static function get_remote_addr() {
		// The connecting address, validated as an IP. On WordPress VIP (and most
		// reverse proxies that rewrite it) this is the real client address.
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? filter_var( wp_unslash( $_SERVER['REMOTE_ADDR'] ), FILTER_VALIDATE_IP ) : false; // phpcs:ignore WordPressVIPMinimum.Variables.ServerVariables.UserControlledHeaders, WordPressVIPMinimum.Variables.RestrictedVariables.cache_constraints___SERVER__REMOTE_ADDR__ -- validated as an IP; only read in AJAX/REST/login handlers, never in page-cached output.
		return $ip ? $ip : '';
	}

	/**
	 * Build a text/plain email body from the (HTML-capable) heading, content
	 * and footer settings: line breaks become newlines, all other markup is
	 * dropped, entities are decoded, and the parts are separated by a newline.
	 *
	 * @param string ...$parts Heading, content, footer.
	 * @return string
	 */
	public static function plain_text_email_body( ...$parts ) {
		$lines = array();
		foreach ( $parts as $part ) {
			$text    = wp_strip_all_tags( preg_replace( '#<br\s*/?>#i', "\n", (string) $part ) );
			$lines[] = html_entity_decode( $text, ENT_QUOTES, 'UTF-8' );
		}
		return implode( "\n", $lines );
	}

	/**
	 * Get the template path.
	 *
	 * @return string
	 */
	public static function template_path() {
		return apply_filters( 'academy_pro\template_path', 'academy-pro/' );
	}
	/**
	 * Get the template path.
	 *
	 * @return string
	 */
	public static function plugin_path() {
		return apply_filters( 'academy_pro\plugin_path', ACADEMY_PRO_ROOT_DIR_PATH );
	}

	/**
	 * Get template part (for templates like the course-loop).
	 *
	 * ACADEMY_PRO_TEMPLATE_DEBUG_MODE will prevent overrides in themes from taking priority.
	 *
	 * @param mixed  $slug Template slug.
	 * @param string $name Template name (default: '').
	 */
	public static function get_template_part( $slug, $name = '' ) {
		$template = false;
		if ( $name ) {
			$template = ACADEMY_PRO_TEMPLATE_DEBUG_MODE ? '' : locate_template(
				array(
					"{$slug}-{$name}.php",
					self::template_path() . "{$slug}-{$name}.php",
				)
			);

			if ( ! $template ) {
				$fallback = self::plugin_path() . "/templates/{$slug}-{$name}.php";
				$template = file_exists( $fallback ) ? $fallback : '';
			}
		}

		if ( ! $template ) {
			// If template file doesn't exist, look in yourtheme/slug.php and yourtheme/academy/slug.php.
			$template = ACADEMY_PRO_TEMPLATE_DEBUG_MODE ? '' : locate_template(
				array(
					"{$slug}.php",
					self::template_path() . "{$slug}.php",
				)
			);
		}
		// Allow 3rd party plugins to filter template file from their plugin.
		$template = apply_filters( 'academy_pro/get_template_part', $template, $slug, $name );
		if ( $template ) {
			load_template( $template, false );
		}
	}

	/**
	 * Locate a template and return the path for inclusion.
	 *
	 * This is the load order:
	 *
	 * yourtheme/$template_path/$template_name
	 * yourtheme/$template_name
	 * $default_path/$template_name
	 *
	 * @param string $template_name Template name.
	 * @param string $template_path Template path. (default: '').
	 * @param string $default_path  Default path. (default: '').
	 * @return string
	 */
	public static function locate_template( $template_name, $template_path = '', $default_path = '' ) {
		if ( ! $template_path ) {
			$template_path = self::template_path();
		}

		if ( ! $default_path ) {
			$default_path = self::plugin_path() . 'templates/';
		}

		$cs_template = str_replace( '_', '-', $template_name );
		$template    = locate_template(
			array(
				trailingslashit( $template_path ) . $cs_template,
				$cs_template,
			)
		);

		if ( empty( $template ) ) {
			$template = locate_template(
				array(
					trailingslashit( $template_path ) . $template_name,
					$template_name,
				)
			);
		}

		// Get default template/.
		if ( ! $template || ACADEMY_PRO_TEMPLATE_DEBUG_MODE ) {
			if ( empty( $cs_template ) ) {
				$template = $default_path . $template_name;
			} else {
				$template = $default_path . $cs_template;
			}
		}

		// Return what we found.
		return apply_filters( 'academy_pro/locate_template', $template, $template_name, $template_path );
	}

	/**
	 * Get other templates (e.g. course attributes) passing attributes and including the file.
	 *
	 * @param string $template_name Template name.
	 * @param array  $args          Arguments. (default: array).
	 * @param string $template_path Template path. (default: '').
	 * @param string $default_path  Default path. (default: '').
	 */
	public static function get_template( $template_name, $args = array(), $template_path = '', $default_path = '' ) {
		$template = false;

		if ( ! $template ) {
			$template = self::locate_template( $template_name, $template_path, $default_path );
		}

		// Allow 3rd party plugin filter template file from their plugin.
		$filter_template = apply_filters( 'academy_pro/get_template', $template, $template_name, $args, $template_path, $default_path );

		if ( $filter_template !== $template ) {
			if ( ! file_exists( $filter_template ) ) {
				/* translators: %s template */
				wc_doing_it_wrong( __FUNCTION__, sprintf( __( '%s does not exist.', 'academy-pro' ), '<code>' . $filter_template . '</code>' ), '1.0.0' );
				return;
			}
			$template = $filter_template;
		}

		$action_args = array(
			'template_name' => $template_name,
			'template_path' => $template_path,
			'located'       => $template,
			'args'          => $args,
		);

		if ( ! empty( $args ) && is_array( $args ) ) {
			if ( isset( $args['action_args'] ) ) {
				wc_doing_it_wrong(
					__FUNCTION__,
					__( 'action_args should not be overwritten when calling academy_pro/get_template.', 'academy-pro' ),
					'1.0.0'
				);
				unset( $args['action_args'] );
			}
            extract($args); // @codingStandardsIgnoreLine
		}

		do_action( 'academy_pro/before_template_part', $action_args['template_name'], $action_args['template_path'], $action_args['located'], $action_args['args'] );
		include $action_args['located'];

		do_action( 'academy_pro/after_template_part', $action_args['template_name'], $action_args['template_path'], $action_args['located'], $action_args['args'] );
	}

	public static function is_plugin_active( $basename ) {
		if ( ! function_exists( 'get_plugins' ) ) {
			include_once ABSPATH . '/wp-admin/includes/plugin.php';
		}
		return is_plugin_active( $basename );
	}

	public static function is_active_academy() {
		$academy = 'academy/academy.php';
		return self::is_plugin_active( $academy );
	}

	public static function is_academy_installed() {
		$file_path = 'academy/academy.php';
		$installed_plugins = get_plugins();
		return isset( $installed_plugins[ $file_path ] );
	}

	/**
	 * Whether GemSecurity's own Captcha module is loadable, its module page
	 * is turned on in GemSecurity's Module Manager, the feature toggle
	 * inside that page is on, and a site/secret key pair is saved — i.e.
	 * whether `GemSecurity\Modules\Captcha::init()` actually wired its own
	 * hooks this request.
	 *
	 * When this is true, `LoginRegister` and `Assets` suppress Academy Pro's
	 * own reCAPTCHA everywhere it currently applies (wp-login.php's native
	 * login/register forms, and Academy's own login/password-reset/
	 * instructor-reg/student-reg forms) rather than running two
	 * uncoordinated CAPTCHA widgets side by side. wp-login.php is always
	 * covered independently by GemSecurity's own hooks. Academy's own forms
	 * get GemSecurity's actual widget in its place only when
	 * {@see is_gemsecurity_captcha_embeddable()} is also true — see that
	 * method for why not every configured provider qualifies. Only Academy
	 * Pro's files are touched for this; Academy core is untouched by
	 * design.
	 *
	 * Uses direct class/static-option checks rather than the
	 * `gemsecurity/module_active` filter so it's safe to call from any hook
	 * timing, including inside `init()`-time registration — WordPress
	 * doesn't guarantee which of two plugins' `plugins_loaded` runs first,
	 * but PHP class autoloading and `get_option()` reads are available
	 * regardless of that order.
	 *
	 * @return bool
	 */
	public static function is_gemsecurity_captcha_active() {
		return class_exists( '\\GemSecurity\\Modules\\Captcha' )
			&& class_exists( '\\GemSecurity\\Modules\\Registry' )
			&& \GemSecurity\Modules\Registry::is_active( 'captcha' )
			&& \GemSecurity\Modules\Captcha::is_configured()
			&& \GemSecurity\Helper::get_setting( 'captcha_enabled', false );
	}

	/**
	 * Whether GemSecurity's currently-configured CAPTCHA provider can be
	 * embedded directly inside Academy's own AJAX-submitted forms (login,
	 * password reset, instructor/student registration) without touching
	 * any file under `plugins/academy/`.
	 *
	 * Two things narrow this beyond "captcha is active":
	 *
	 * - Academy's REST handlers (`academy/includes/api/auth.php`, not
	 *   modified for this) read the token from a hardcoded
	 *   `g-recaptcha-response` param. Only a provider using that exact
	 *   field name round-trips correctly — true for `recaptcha_v2` and
	 *   `recaptcha_v3`, but not hCaptcha (`h-captcha-response`) or
	 *   Turnstile (`cf-turnstile-response`).
	 * - `GemSecurity\Modules\Captcha::render_widget()`'s v3 branch prints
	 *   an inline `<script>` that calls the native `form.submit()` once a
	 *   token resolves, bypassing Academy's own AJAX submit handler
	 *   (`frontendssr.js`, not modified for this) entirely and causing a
	 *   full page reload instead of the expected fetch-based flow. Only
	 *   the v2 (checkbox) branch is a plain `<div data-sitekey>` with no
	 *   such script, so only v2 is safe to embed as-is.
	 *
	 * When GemSecurity's captcha is active but this is false (v3, hCaptcha
	 * or Turnstile configured), Academy's own forms intentionally render no
	 * CAPTCHA at all rather than risk breaking submission — GemSecurity's
	 * widget still fully covers wp-login.php independently either way.
	 *
	 * @return bool
	 */
	public static function is_gemsecurity_captcha_embeddable() {
		if ( ! self::is_gemsecurity_captcha_active() ) {
			return false;
		}
		$key       = \GemSecurity\Helper::get_setting( 'captcha_provider', 'recaptcha_v2' );
		$providers = \GemSecurity\Modules\Captcha::providers();
		$provider  = $providers[ $key ] ?? $providers['recaptcha_v2'];
		return 'g-recaptcha-response' === $provider['field'] && empty( $provider['v3'] );
	}

	/**
	 * Whether GemSecurity's own Social Login module is loadable, its module
	 * page is turned on in GemSecurity's Module Manager, the feature toggle
	 * inside that page is on, and at least one provider has both a client
	 * ID and secret saved — i.e. whether `GemSecurity\Modules\SocialLogin`
	 * actually renders its own buttons and handles its own OAuth flow this
	 * request.
	 *
	 * When this is true, Academy Pro's own Social Login addon (`addons/
	 * social-login/`) suppresses its buttons and AJAX login/register
	 * handlers rather than running two competing "Sign in with Google/
	 * Facebook" buttons wired to two separate OAuth apps on the same login
	 * form — GemSecurity's module already hooks the identical
	 * `academy/templates/shortcode/after_login` action Academy Pro's own
	 * shortcode uses. Only Academy Pro's files are touched for this;
	 * Academy core is untouched by design.
	 *
	 * Uses direct class/static-option checks rather than the
	 * `gemsecurity/module_active` filter so it's safe to call from any hook
	 * timing, including inside `init()`-time registration — see
	 * {@see is_gemsecurity_captcha_active()} for the same rationale.
	 *
	 * @return bool
	 */
	public static function is_gemsecurity_social_login_active() {
		return class_exists( '\\GemSecurity\\Modules\\SocialLogin' )
			&& class_exists( '\\GemSecurity\\Modules\\Registry' )
			&& \GemSecurity\Modules\Registry::is_active( 'social-login' )
			&& \GemSecurity\Helper::get_setting( 'social_login_enabled', false )
			&& ! empty( \GemSecurity\Modules\SocialLogin::enabled_providers() );
	}

	public static function get_attachment_file_details( $attachment_id ) {
		$url       = wp_get_attachment_url( $attachment_id );
		$file_type = wp_check_filetype( $url );
		$ext       = $file_type['ext'];
		$title     = get_the_title( $attachment_id );

		$file_path  = get_attached_file( $attachment_id );
		$size_bytes = file_exists( $file_path ) ? filesize( $file_path ) : 0;
		$size       = size_format( $size_bytes, 2 );
		return [
			'url' => $url,
			'ext' => $ext,
			'title' => $title,
			'name'       => $title . '.' . $ext,
			'size' => $size
		];
	}
}
