<?php

namespace AcademyPro;

use SE_License_SDK_Client;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * StoreEngine SDK bootstrap for Academy Pro.
 *
 * The SDK is NOT bundled here — Academy LMS core hosts it (composer-managed
 * there) and exposes the global `se_license_init()`. Academy Pro hard-depends
 * on Academy core and loads after it, so the function is available. We defer
 * the call until plugins_loaded (where translations + the SDK's helper
 * functions are guaranteed to be available) and bridge the SDK's REST +
 * frontend localization into Academy's existing script-data filter.
 */
final class StoreLicense {

	protected static ?SE_License_SDK_Client $sdk_client = null;

	/**
	 * Prevent instantiation — everything here is static.
	 */
	private function __construct() {}

	public static function init(): void {
		if ( ! did_action( 'plugins_loaded' ) ) {
			add_action( 'plugins_loaded', [ __CLASS__, 'load_sdk' ] );
		} else {
			self::load_sdk();
		}
	}

	public static function load_sdk(): void {
		if ( null !== self::$sdk_client ) {
			return;
		}

		// The composer files-autoload guarantees `se_license_init()` is
		// declared by now. If it isn't, the plugin's composer install is
		// broken — fail loud rather than producing a silent no-op.
		if ( ! function_exists( 'se_license_init' ) ) {
			_doing_it_wrong(
				__METHOD__,
				'StoreEngine SDK is missing. Run `composer install` in the academy-pro plugin directory.',
				'1.5.0'
			);
			return;
		}

		self::$sdk_client = se_license_init( [
			'package_file'        => ACADEMY_PRO_PLUGIN_FILE,
			'package_name'        => 'AcademyLMS Pro',
			'product_id'          => 198,
			'is_free'             => false,
			'slug'                => ACADEMY_PRO_PLUGIN_SLUG,
			'basename'            => ACADEMY_PRO_PLUGIN_BASENAME,
			'package_type'        => 'plugin',
			'package_version'     => ACADEMY_PRO_VERSION,
			'allow_local'         => true,
			'menu'                => admin_url( 'admin.php?page=academy-settings&path=license' ),
			'init_restapi'        => true,
			'script_handler'      => 'academy-admin-scripts',
			'license_server'      => 'https://store.kodezen.com/',
			'purchase_url'        => 'https://store.kodezen.com/product/academy-pro/',
			'product_logo'        => defined( 'ACADEMY_ASSETS_URI' ) ? ACADEMY_ASSETS_URI . 'images/logo.svg' : '',
			'store_dashboard_url' => 'https://store.kodezen.com/dashboard/license-keys/',
			'terms_url'           => 'https://kodezen.com/terms-and-conditions/',
			'privacy_policy_url'  => 'https://store.kodezen.com/privacy-policy/',
			'support_url'         => 'https://community.kodezen.com/tickets',
			'primary_color'       => '#7b68ee',
			'first_install_time'  => get_option( 'academy_pro_first_install_time' ),
			'optin_notice_delay'  => 3 * DAY_IN_SECONDS,
		] );

		// Bridge the SDK's frontend params into Academy's existing
		// `academy/assets/backend_scripts_data` filter so the React
		// Licence component can read `SeSdk` from the localized
		// `academy-admin-scripts` data. The SDK also auto-localizes the
		// same payload under `window.SE_SDK_ACADEMY_PRO` (via the
		// `script_handler` config above) — both shapes are exposed so
		// either consumer pattern works.
		add_filter( 'academy/assets/backend_scripts_data', [ __CLASS__, 'add_script_data' ] );
	}

	public static function add_script_data( array $data ): array {
		if ( self::$sdk_client ) {
			$data['SeSdk'] = method_exists( self::$sdk_client, 'get_js_params' ) ? self::$sdk_client->get_js_params() : [];
		}
		return $data;
	}

	public static function get_client(): ?SE_License_SDK_Client {
		return self::$sdk_client;
	}
}
