<?php
namespace AcademyPro\Admin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


class Notice {
	public static function init() {
		$self = new self();
		add_action( 'plugins_loaded', array( $self, 'dispatch_notice' ), 30 );
	}

	public function dispatch_notice() {
		if ( ! did_action( 'academy_loaded' ) ) {
			add_action( 'admin_notices', array( $this, 'academy_pro_fail_load' ) );
			return;
		}

		/*
		 * Testing only: to preview the "Academy LMS Free update required" notice without
		 * downgrading Academy LMS Free, swap in the line below. The leading `true ||`
		 * skips the version compare, so the notice always shows. Revert it afterwards.
		 *
		 * if ( true || ! version_compare( ACADEMY_VERSION, ACADEMY_PRO_REQUIRED_CORE_VERSION, '>=' ) ) {
		 */
		if ( ! version_compare( ACADEMY_VERSION, ACADEMY_PRO_REQUIRED_CORE_VERSION, '>=' ) ) {
			add_action( 'admin_notices', array( $this, 'academy_pro_fail_load_out_of_date' ) );
			// Academy's own admin screens strip `admin_notices`, so show it there too.
			add_action( 'init', array( $this, 'add_academy_out_of_date_notice' ) );
			return;
		}
	}

	public function academy_pro_fail_load() {
		$screen = get_current_screen();
		if ( isset( $screen->parent_file ) && 'plugins.php' === $screen->parent_file && 'update' === $screen->id ) {
			return;
		}

		$plugin = 'academy/academy.php';

		if ( \AcademyPro\Helper::is_academy_installed() ) {
			if ( ! current_user_can( 'activate_plugins' ) ) {
				return;
			}

			$activation_url = wp_nonce_url( 'plugins.php?action=activate&amp;plugin=' . $plugin . '&amp;plugin_status=all&amp;paged=1&amp;s', 'activate-plugin_' . $plugin );

			$message = '<h3>' . esc_html__( 'Activate the Academy LMS Plugin', 'academy-pro' ) . '</h3>';
			$message .= '<p>' . esc_html__( 'Before you can use all the features of Academy LMS Pro, you need to activate the Academy LMS Free plugin first.', 'academy-pro' ) . '</p>';
			$message .= '<p>' . sprintf( '<a href="%s" class="button-primary">%s</a>', $activation_url, esc_html__( 'Activate Now', 'academy-pro' ) ) . '</p>';
		} else {
			if ( ! current_user_can( 'install_plugins' ) ) {
				return;
			}

			$install_url = wp_nonce_url( self_admin_url( 'update.php?action=install-plugin&plugin=academy' ), 'install-plugin_academy' );

			$message = '<h3>' . esc_html__( 'Install and Activate the Academy LMS Free Plugin', 'academy-pro' ) . '</h3>';
			$message .= '<p>' . esc_html__( 'Before you can use all the features of Academy LMS Pro, you need to install and activate the Academy LMS Free plugin first.', 'academy-pro' ) . '</p>';
			$message .= '<p>' . sprintf( '<a href="%s" class="button-primary">%s</a>', $install_url, esc_html__( 'Install Academy LMS', 'academy-pro' ) ) . '</p>';
		}//end if

		$this->print_error( $message );
	}

	public function academy_pro_fail_load_out_of_date() {
		if ( ! current_user_can( 'update_plugins' ) ) {
			return;
		}

		$message = '<h3>' . esc_html__( 'Academy LMS Free update required', 'academy-pro' ) . '</h3>';
		$message .= '<p>' . self::get_out_of_date_message() . '</p>';
		$message .= '<p>' . sprintf(
			'<a href="%s" class="button-primary" target="_blank" rel="noopener noreferrer">%s</a>',
			esc_url( self::get_free_download_url() ),
			esc_html( self::get_download_button_text() )
		) . '</p>';

		$this->print_error( $message );
	}

	/**
	 * Show the same notice inside Academy's React admin screens.
	 */
	public function add_academy_out_of_date_notice() {
		if ( ! is_admin() || ! current_user_can( 'update_plugins' ) ) {
			return;
		}

		if ( ! class_exists( '\Academy\Admin\Notices' ) || ! method_exists( '\Academy\Admin\Notices', 'add_notice' ) ) {
			return;
		}

		\Academy\Admin\Notices::add_notice(
			'academy_pro_free_update_required',
			array(
				'type'          => 'danger',
				'message'       => self::get_out_of_date_message(),
				'button_text'   => self::get_download_button_text(),
				'button_action' => esc_url( self::get_free_download_url() ),
			)
		);
	}

	private static function get_out_of_date_message() {
		return sprintf(
			/* translators: 1: required Academy LMS Free version, 2: installed Academy LMS Free version */
			esc_html__( 'Academy LMS Pro needs Academy LMS Free %1$s or later (you have %2$s). Download and install it to keep using Pro.', 'academy-pro' ),
			esc_html( ACADEMY_PRO_REQUIRED_CORE_VERSION ),
			esc_html( ACADEMY_VERSION )
		);
	}

	private static function get_download_button_text() {
		/* translators: %s: required Academy LMS Free version */
		return sprintf( __( 'Download Academy LMS %s', 'academy-pro' ), ACADEMY_PRO_REQUIRED_CORE_VERSION );
	}

	/**
	 * Download URL of the Academy LMS (Free) version required by this Pro release.
	 *
	 * @return string
	 */
	public static function get_free_download_url() {
		return (string) apply_filters( 'academy_pro/free_download_url', 'https://github.com/imrantushar/kodezen-assets/raw/master/academy/academy.4.1.0.zip' );
	}

	public function print_error( $message ) {
		if ( ! $message ) {
			return;
		}
		// PHPCS - $message should not be escaped
		echo '<div class="error">' . $message . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
}
