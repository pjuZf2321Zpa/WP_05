<?php
namespace AcademyPro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Shortcode {
	public static function init() {
		Shortcode\LoginRegister::init();
	}
}
