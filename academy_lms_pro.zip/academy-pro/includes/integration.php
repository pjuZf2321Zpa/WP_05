<?php
namespace AcademyPro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Academy\Helper;

class Integration {
	public static function init() {
		$self = new self();
	}
}
