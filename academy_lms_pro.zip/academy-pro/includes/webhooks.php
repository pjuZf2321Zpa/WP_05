<?php
namespace AcademyPro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AcademyPro\Webhooks\Listeners;

/**
 * Webhook events for Pro features (assignments, tutor booking, Zoom, course
 * bundles). Registered into the free Webhooks add-on's listener list.
 */
class Webhooks {
	public static function init() {
		add_filter( 'academy_webhooks/get_listeners', array( __CLASS__, 'add_listeners' ) );
	}

	/**
	 * @param array $listeners Event name => listener class.
	 * @return array
	 */
	public static function add_listeners( $listeners ) {
		return array_merge(
			(array) $listeners,
			array(
				'assignment_publish' => Listeners\AssignmentPublish::class,
				'tutor_booking_publish' => Listeners\TutorBookingPublish::class,
				'tutor_booking_completed' => Listeners\TutorBookingCompleted::class,
				'assignment_completed' => Listeners\AssignmentCompleted::class,
				'tutor_booking_review' => Listeners\TutorBookingReview::class,
				'submitted_assignment' => Listeners\SubmittedAssignment::class,
				'evaluate_submitted_assignment' => Listeners\EvaluateSubmittedAssignment::class,
				'tutor_booking_booked' => Listeners\TutorBookingBooked::class,
				'zoom_publish' => Listeners\ZoomPublish::class,
				'zoom_complete' => Listeners\ZoomCompleted::class,
				'course-bundle_publish' => Listeners\CourseBundlePublish::class,
			)
		);
	}
}
