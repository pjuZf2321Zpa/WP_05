<?php
namespace AcademyPro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Migration {

	public static function init() {
		$self = new self();
		$self->run_migration();
	}

	public function run_migration() {
		$academy_pro_version = get_option( 'academy_pro_version' );
		if ( version_compare( $academy_pro_version, '2.5.1', '<' ) ) {
			add_option( 'academy_pro_run_email_migration', true );
		}

		if ( version_compare( $academy_pro_version, '2.9.1', '<' ) ) {
			add_option( 'academy_pro_run_email_migration_2_9_0', true );
		}

		if ( version_compare( $academy_pro_version, '2.7.1', '<' ) ) {
			add_option( 'academy_pro_run_email_migration_2_7_0', true );
		}

		$this->migrate_zoom_addon_data_to_meeting_addon();

		// Notification migrate
		$this->migrate_2_2_4( $academy_pro_version );

		// assignment migrate
		if ( ! get_option( 'academy_assignments_meta_update_2_8_0' ) ) {
			$this->migrate_2_8_0();
		}

		// Save Version Number
		if ( ACADEMY_PRO_VERSION !== $academy_pro_version ) {
			update_option( 'academy_pro_version', ACADEMY_PRO_VERSION );
		}

		// Migrate 3.9.0
		if ( \Academy\Helper::get_addon_active_status( 'tutor-booking' ) && \Academy\Options::get( \Academy\Options::PRO_MIGRATIONS, 'booking_390' ) !== 'yes' ) {
			$this->migrate_3_9_0( $academy_pro_version );
			\Academy\Options::set( \Academy\Options::PRO_MIGRATIONS, 'booking_390', 'yes' );
		}

		// Grade Book comments: merge the standalone comments table into the results table
		if ( \Academy\Helper::get_addon_active_status( 'grade_book' ) && ! \Academy\Options::get( \Academy\Options::PRO_MIGRATIONS, 'grade_book_comments_merged' ) ) {
			$this->migrate_grade_book_comments_to_results();
		}
	}

	public function migrate_zoom_addon_data_to_meeting_addon() {
		if ( \Academy\Helper::get_addon_active_status( 'zoom' ) && ! get_option( 'academy_pro_has_migrate_zoom_addon_data' ) ) {
			$zooms = get_posts(array(
				'post_status' => 'publish',
				'post_type'   => 'academy_zoom'
			));
			if ( is_array( $zooms ) && ! empty( $zooms ) ) {
				foreach ( $zooms as $zoom ) {
					wp_update_post(
						array(
							'ID'        => $zoom->ID,
							'post_type' => 'academy_meeting'
						)
					);
					$courses = get_posts(array(
						'post_type' => 'academy_courses',
						'post_status' => 'publish'
					));
					foreach ( $courses as $course ) {
						$curriculums = get_post_meta( $course->ID, 'academy_course_curriculum', true );
						if ( is_array( $curriculums ) ) {
							foreach ( $curriculums as $key => $curriculum ) {
								foreach ( $curriculum['topics'] as $subkey => $topics ) {
									if ( 'zoom' === $topics['type'] && $zoom->ID === $topics['id'] ) {
										$curriculums[ $key ]['topics'][ $subkey ]['type'] = 'meeting';
									}

									if ( 'sub-curriculum' === $topics['type'] ) {
										foreach ( $topics['topics'] as $SubKey => $sub_curriculum ) {
											if ( 'zoom' === $sub_curriculum['type'] && $zoom->ID === $sub_curriculum['id'] ) {
												$curriculums[ $key ]['topics'][ $subkey ]['topics'][ $SubKey ]['type'] = 'meeting';
											}
										}
									}
								}
								update_post_meta( $course->ID, 'academy_course_curriculum', $curriculums );
							}
						}
					}//end foreach
					$zoom_request = get_post_meta( $zoom->ID, 'academy_zoom_request', true );
					$zoom_response = get_post_meta( $zoom->ID, 'academy_zoom_response', true );
					update_post_meta( $zoom->ID, 'academy_meeting_type', 'zoom' );
					update_post_meta( $zoom->ID, 'academy_meeting_request', $zoom_request );
					update_post_meta( $zoom->ID, 'academy_meeting_response', $zoom_response );
				}//end foreach
			}//end if
			add_option( 'academy_pro_has_migrate_zoom_addon_data', true );
		}//end if
	}

	public function migrate_2_2_4( $academy_pro_version ) {
		if ( ! \Academy\Helper::get_addon_active_status( 'notifications' ) ) {
			return;
		}
		if ( ! get_option( 'academy_pro_notifications_migrate_2_4' ) && version_compare( $academy_pro_version, '2.2.4', '>' ) ) {
			global $wpdb;
			$table_name = $wpdb->prefix . ACADEMY_PLUGIN_SLUG . '_notifications';
			// Check if the column exists
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching,  WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
			$column_exists = $wpdb->get_results( "SHOW COLUMNS FROM `$table_name` LIKE 'topic_id'" );

			if ( empty( $column_exists ) ) {
				// Add the new column
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
				$wpdb->query( "ALTER TABLE `$table_name` ADD `topic_id` BIGINT(20) UNSIGNED NULL AFTER `post_id`" );
			}
			add_option( 'academy_pro_notifications_migrate_2_4', true );
		}
	}

	public function migrate_2_8_0() {
		// phpcs:disable WordPressVIPMinimum.Performance.NoPaging.posts_per_page_numberposts -- one-time migration over a bounded set
		$assignments = get_posts([
			'post_status' => 'publish',
			'post_type' => 'academy_assignments',
			'numberposts' => -1
		]);
		// phpcs:enable WordPressVIPMinimum.Performance.NoPaging.posts_per_page_numberposts
		if ( is_array( $assignments ) && ! empty( $assignments ) ) {
			foreach ( $assignments as $assignment ) {
				update_post_meta( $assignment->ID, 'academy_assignment_enable_resubmit', false );
				update_post_meta( $assignment->ID, 'academy_assignment_resubmit_limit', 0 );
			}
		}
		add_option( 'academy_assignments_meta_update_2_8_0', true );
	}

	public function migrate_grade_book_comments_to_results() {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		require_once ACADEMY_PRO_ADDONS_DIR_PATH . 'grade-book/database/create-grade-book-results-table.php';

		// Ensure the results table has the `comment` column. dbDelta covers the
		// normal case; fall back to an explicit ALTER if its parser skips the add.
		\AcademyProGradeBook\Database\CreateGradeBookResultsTable::create( $wpdb->prefix, $wpdb->get_charset_collate() );

		$results_table = $wpdb->prefix . 'academy_grade_book_results';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
		$has_comment_column = $wpdb->get_results( "SHOW COLUMNS FROM `{$results_table}` LIKE 'comment'" );

		if ( empty( $has_comment_column ) ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
			$wpdb->query( "ALTER TABLE `{$results_table}` ADD `comment` text DEFAULT NULL" );
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
			$has_comment_column = $wpdb->get_results( "SHOW COLUMNS FROM `{$results_table}` LIKE 'comment'" );
		}

		if ( empty( $has_comment_column ) ) {
			// Column still absent - bail and retry on a later load; never touch the legacy data.
			return;
		}

		$comments_table = $wpdb->prefix . 'academy_grade_book_comments';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$has_legacy_table = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $comments_table ) );

		if ( $has_legacy_table ) {
			// Move every existing comment onto the student's final grade row.
			// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- only $wpdb-prefixed table names, whitelisted columns and intval/placeholder lists are interpolated; values are prepared
			$moved = $wpdb->query(
				"UPDATE {$wpdb->prefix}academy_grade_book_results r
				INNER JOIN {$comments_table} c
					ON ( c.course_id = r.course_id AND c.user_id = r.user_id )
				SET r.comment = c.comment
				WHERE r.result_for = 'final'"
			);
			// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter

			if ( false === $moved ) {
				// Copy failed - keep the legacy table intact and retry on a later load.
				return;
			}

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
			$wpdb->query( "DROP TABLE IF EXISTS {$comments_table}" );
		}

		\Academy\Options::set( \Academy\Options::PRO_MIGRATIONS, 'grade_book_comments_merged', true );
	}

	public function migrate_3_9_0( $academy_version ) {
		if ( version_compare( $academy_version, '3.9.0', '<=' ) ) {
			$course_archive_filters = \Academy\Helper::get_customizer_settings(
				'archive_booking_filters',
				array(
					'items' =>
						array(
							'search'   => 1,
							'category' => 1,
							'tags'     => 1,
							'levels'   => 1,
							'type'     => 1,
						),
				)
			);

			$course_archive_filters = $course_archive_filters['items'];
			$course_archive_filters = array_reduce(array_keys( $course_archive_filters ), function ( $carry, $key ) use ( $course_archive_filters ) {
				$carry[] = [ $key => $course_archive_filters[ $key ] ];
				return $carry;
			}, []);

			\Academy\Admin\Settings\Base::save_settings( array(
				'tutor_booking_archive_sidebar_position' => \Academy\Helper::get_settings( 'course_archive_sidebar_position' ),
				'tutor_booking_archive_filters' => $course_archive_filters,
				'tutor_booking_archive_booking_per_row' => \Academy\Helper::get_settings( 'course_archive_courses_per_row' ),
				'tutor_booking_archive_booking_per_page' => \Academy\Helper::get_settings( 'course_archive_courses_per_page' ),
				'tutor_booking_archive_booking_order' => 'DESC',
				'tutor_booking_card_style' => 'default',
			) );
		}//end if
	}
}
