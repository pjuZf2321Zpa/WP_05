<?php
namespace AcademyPro\Shortcode;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


class LoginRegister {
	public static function init() {
		$self = new self();
		// Registered whenever Academy's own toggle is on (the fallback path)
		// OR GemSecurity's captcha is active (the replacement path) — the
		// latter must reach these hooks independently of Academy's own
		// setting, otherwise turning Academy's toggle off (its default
		// state once GemSecurity takes over) would also remove GemSecurity's
		// widget from Academy's own forms. is_gemsecurity_captcha_active()
		// is documented safe to call at this init()-time registration point.
		if ( \Academy\Helper::get_settings( 'is_enabled_recaptcha', false ) || \AcademyPro\Helper::is_gemsecurity_captcha_active() ) {
			// recaptcha
			add_action( 'academy/templates/login_form_before_submit', [ $self, 'add_google_recaptcha_markup' ] );
			add_action( 'academy/templates/password_reset_form_before_submit', [ $self, 'add_google_recaptcha_markup' ] );
			add_action( 'academy/templates/instructor_reg_form_before_submit', [ $self, 'add_google_recaptcha_markup' ] );
			add_action( 'academy/templates/student_reg_form_before_submit', [ $self, 'add_google_recaptcha_markup' ] );
			// default
			add_action( 'login_form', [ $self, 'add_google_recaptcha_markup' ] );
			add_action( 'register_form', [ $self, 'add_google_recaptcha_markup' ] );
			// verify captcha
			add_action( 'academy/api/auth/before_login_signon', array( $self, 'verify_recaptcha' ), 10, 3 );
			add_action( 'academy/api/auth/before_password_reset', array( $self, 'verify_recaptcha' ), 10, 3 );
			add_action( 'academy/api/auth/before_student_registration', array( $self, 'verify_recaptcha' ), 10, 3 );
			add_action( 'academy/api/auth/before_instructor_registration', array( $self, 'verify_recaptcha' ), 10, 3 );
			// default form
			add_filter( 'authenticate', [ $self, 'check_default_login_recaptcha' ], 30 );
			add_filter( 'registration_errors', [ $self, 'check_default_register_recaptcha' ], 30 );
		}
	}

	public function check_default_login_recaptcha( $user ) {
		if ( \AcademyPro\Helper::is_gemsecurity_captcha_active() ) {
			// GemSecurity's own Captcha module already independently covers
			// wp-login.php (its own `authenticate` hook) whenever it's
			// active — verifying here too would double-check the same
			// submission against a widget Academy Pro no longer renders
			// (see add_google_recaptcha_markup()'s own guard below).
			return $user;
		}
		// Runs inside the core `authenticate` filter where WordPress owns the login nonce; there is no plugin nonce to verify here.
		if ( ! isset( $_POST['log'], $_POST['pwd'] ) ) {// phpcs:ignore WordPress.Security.NonceVerification.Missing
			return $user;
		}
		if ( empty( $_POST['g-recaptcha-response'] ) ) {// phpcs:ignore WordPress.Security.NonceVerification.Missing
			return new \WP_Error( 'recaptcha_missing', __( 'Please complete the Google reCAPTCHA.', 'academy-pro' ) );
		}

		if ( ! $this->verify_recaptcha_common( sanitize_text_field( wp_unslash( $_POST['g-recaptcha-response'] ) ) ) ) {// phpcs:ignore WordPress.Security.NonceVerification.Missing
			return new \WP_Error( 'recaptcha_failed', __( 'Google reCAPTCHA verification failed.', 'academy-pro' ) );
		}

		return $user;
	}

	public function check_default_register_recaptcha( $errors ) {
		if ( \AcademyPro\Helper::is_gemsecurity_captcha_active() ) {
			// See check_default_login_recaptcha()'s matching guard.
			return $errors;
		}
		// Runs inside the core `registration_errors` filter; WordPress owns the registration nonce here.
		$recaptcha_response = isset( $_POST['g-recaptcha-response'] ) ? sanitize_text_field( wp_unslash( $_POST['g-recaptcha-response'] ) ) : '';// phpcs:ignore WordPress.Security.NonceVerification.Missing
		if ( ! $this->verify_recaptcha_common( $recaptcha_response ) ) {
			$errors->add( 'recaptcha_failed', __( 'Google reCAPTCHA verification failed.', 'academy-pro' ) );
		}
		return $errors;
	}

	public function add_google_recaptcha_markup() {
		if ( \AcademyPro\Helper::is_gemsecurity_captcha_active() ) {
			// Covers all 6 hooks this single method is registered on (the 4
			// Academy template hooks plus core's login_form/register_form).
			// wp-login.php's own login_form/register_form are already
			// independently covered by GemSecurity's own widget, so skip
			// rendering a second one there — but Academy's own forms have
			// no other widget, so render GemSecurity's here when the
			// configured provider allows it (see AcademyPro\Helper::
			// is_gemsecurity_captcha_embeddable()).
			$current_hook = current_action();
			if ( ! in_array( $current_hook, [ 'login_form', 'register_form' ], true ) && \AcademyPro\Helper::is_gemsecurity_captcha_embeddable() ) {
				// GemSecurity's own `wp_enqueue_scripts` hook only loads the
				// provider script for comment forms (`is_singular() &&
				// comments_open()`) and its `login_enqueue_scripts` hook only
				// covers wp-login.php — neither fires for Academy's own
				// login/registration/password-reset pages, so the widget div
				// below would otherwise render with no script to turn it into
				// an actual checkbox. Enqueue it ourselves; it's safe to call
				// more than once (wp_enqueue_script() de-dupes by handle) and
				// timing is fine even this late since the script prints in
				// the footer.
				( new \GemSecurity\Modules\Captcha() )->enqueue_script();
				echo '<div class="academy-form-group">';
				( new \GemSecurity\Modules\Captcha() )->render_widget();
				echo '</div>';
			}
			return;
		}//end if
		$recaptcha_type = \Academy\Helper::get_settings( 'recaptcha_type', 'v2' );
		if ( 'v3' === $recaptcha_type ) {
			?>
			<div class="academy-form-group">
				<input type="hidden" id="g-recaptcha-response" name="g-recaptcha-response">
			</div>
			<?php
		} else {
			?>
			<div class="academy-form-group">
				<div class="g-recaptcha" data-sitekey="<?php echo esc_attr( \Academy\Helper::get_settings( 'recaptcha_v2_site_key', false ) ); ?>"></div>
			</div>
			<?php
		}
	}

	public function verify_recaptcha( $user_data, $role, $rechaptcha_response ) {
		if ( \AcademyPro\Helper::is_gemsecurity_captcha_active() ) {
			if ( ! \AcademyPro\Helper::is_gemsecurity_captcha_embeddable() ) {
				// No widget was rendered for this provider — see
				// add_google_recaptcha_markup()'s matching guard — so there
				// is nothing submitted to verify.
				return;
			}
			// Academy's own REST layer (auth.php, unmodified) always reads
			// the token under the 'g-recaptcha-response' param name, which
			// is_gemsecurity_captcha_embeddable() already confirmed matches
			// the active provider's field name.
			if ( empty( $rechaptcha_response ) || ! ( new \GemSecurity\Modules\Captcha() )->verify_token( $rechaptcha_response ) ) {
				// Academy's own frontend JS (frontendssr.js) always reads the
				// error text back out as `error.response.data.message` —
				// wrapping it in a plain array here (as this used to) sends
				// `data: ["…"]`, so `data.message` resolves to `undefined` on
				// screen instead of the actual text.
				wp_send_json_error( [ 'message' => __( 'Complete the reCAPTCHA verification.', 'academy-pro' ) ] );
			}
			return;
		}//end if
		if ( empty( $rechaptcha_response ) ) {
			wp_send_json_error( [ 'message' => __( 'Complete the reCAPTCHA verification.', 'academy-pro' ) ] );
		}
		$recaptcha_type   = \Academy\Helper::get_settings( 'recaptcha_type', 'v2' );
		$recaptcha_secret = '';
		if ( 'v2' === $recaptcha_type ) {
			$recaptcha_secret = \Academy\Helper::get_settings( 'recaptcha_v2_secret_key', '' );
		} else {
			$recaptcha_secret = \Academy\Helper::get_settings( 'recaptcha_v3_secret_key', '' );
		}
		$verify               = $this->verify( sanitize_text_field( $rechaptcha_response ), \AcademyPro\Helper::get_remote_addr(), $recaptcha_secret );

		if ( false === $verify ) {
			wp_send_json_error( [ 'message' => __( 'Captcha is not matching, please try again.', 'academy-pro' ) ] );
		}
	}

	private function verify( $form_recaptcha_response, $server_remoteip, $recaptcha_secret_key ) {
		// POST, so the secret key never ends up in a URL (and in proxy/server logs).
		$google_response = wp_safe_remote_post(
			'https://www.google.com/recaptcha/api/siteverify',
			array(
				'timeout' => 3,
				'body'    => array(
					'secret'   => $recaptcha_secret_key,
					'response' => $form_recaptcha_response,
					'remoteip' => $server_remoteip,
				),
			)
		);
		if ( is_wp_error( $google_response ) ) {
			return false;
		}
		$decode_google_response = json_decode( wp_remote_retrieve_body( $google_response ) );
		return ! empty( $decode_google_response->success );
	}

	public function verify_recaptcha_common( $token ) {
		if ( empty( $token ) ) {
			return false;
		}

		$recaptcha_type = \Academy\Helper::get_settings( 'recaptcha_type', 'v2' );

		$secret = ( 'v2' === $recaptcha_type )
			? \Academy\Helper::get_settings( 'recaptcha_v2_secret_key', '' )
			: \Academy\Helper::get_settings( 'recaptcha_v3_secret_key', '' );

		if ( empty( $secret ) ) {
			return false;
		}

		$result = $this->verify( $token, \AcademyPro\Helper::get_remote_addr(), $secret );

		return ! empty( $result );
	}
}
