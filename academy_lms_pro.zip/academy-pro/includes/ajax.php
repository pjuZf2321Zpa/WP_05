<?php
namespace AcademyPro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AcademyPro\Ajax\Duplicate;
use AcademyPro\Ajax\ExportImport;
use AcademyPro\Ajax\CourseExtendDuration;

class Ajax {
	public static function init() {
		$self = new self();
		$self->dispatch_hooks();
		CourseExtendDuration::init();
	}

	public function dispatch_hooks() {
		( new Duplicate() )->dispatch_actions();
		( new ExportImport() )->dispatch_actions();
	}
}
