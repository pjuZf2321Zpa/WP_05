<?php
namespace AcademyPro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Academy\Helper;
use Academy\Classes\ScriptsBase;

class Assets {

	public static function init() {
		$self = new self();
		add_action( 'admin_enqueue_scripts', [ $self, 'backend_scripts' ] );
		add_action( 'wp_enqueue_scripts', [ $self, 'frontend_scripts' ], 30 );
		add_action( 'wp_enqueue_scripts', [ $self, 'enqueue_recaptcha_script' ], 10 );
		// Registered unconditionally — the GemSecurity-captcha suppression
		// check moves inside the method body instead (see
		// default_enqueue_recaptcha_script()), so it runs at call-time.
		add_action( 'login_enqueue_scripts', [ $self, 'default_enqueue_recaptcha_script' ], 10 );
		add_filter( 'academy/assets/frontend_scripts_data', [ $self, 'localize_scripts_data' ] );
		add_filter( 'academy/assets/backend_scripts_data', [ $self, 'localize_backend_scripts_data' ] );
	}
	/**
	 * Enqueue Files on Start Plugin
	 *
	 * @param string $hook
	 * @function backend_scripts
	 */
	public function backend_scripts( $hook ) {
		if ( \Academy\Helper::plugin_page_hook_suffix( $hook ) ) {
			wp_enqueue_style( 'academy-pro-admin-style', ACADEMY_PRO_ASSETS_URI . 'build/backend.css', array( 'wp-components' ), filemtime( ACADEMY_PRO_ASSETS_DIR_PATH . 'build/backend.css' ), 'all' );
			// js
			$dependencies = include ACADEMY_PRO_ASSETS_DIR_PATH . sprintf( 'build/backend.%s.asset.php', ACADEMY_PRO_VERSION );
			wp_enqueue_script(
				'academy-pro-admin-scripts',
				ACADEMY_PRO_ASSETS_URI . sprintf( 'build/backend.%s.js', ACADEMY_PRO_VERSION ),
				array_merge( $dependencies['dependencies'] ?? [], [ 'academy-admin-scripts' ] ),
				$dependencies['version'],
				true
			);
			wp_set_script_translations( 'academy-pro-admin-scripts', 'academy-pro', ACADEMY_PRO_ROOT_DIR_PATH . 'languages' );
		}//end if
	}

	public function frontend_scripts() {
		$scriptBase = new ScriptsBase();
		if ( is_user_logged_in() ) {
			wp_enqueue_style( 'academy-pro-frontend-style', ACADEMY_PRO_ASSETS_URI . 'build/frontend.css', array(), filemtime( ACADEMY_PRO_ASSETS_DIR_PATH . 'build/frontend.css' ), 'all' );
			$dependencies = include ACADEMY_PRO_ASSETS_DIR_PATH . sprintf( 'build/frontend.%s.asset.php', ACADEMY_PRO_VERSION );
			wp_enqueue_style(
				'academy-pro-frontend-styles',
				ACADEMY_PRO_ASSETS_URI . 'build/frontend.css',
				array(),
				$dependencies['version']
			);
			wp_enqueue_script(
				'academy-pro-frontend-scripts',
				ACADEMY_PRO_ASSETS_URI . sprintf( 'build/frontend.%s.js', ACADEMY_PRO_VERSION ),
				array_merge( $dependencies['dependencies'] ?? [], [] ),
				$dependencies['version'],
				true
			);
			wp_set_script_translations( 'academy-pro-frontend-scripts', 'academy-pro', ACADEMY_PRO_ROOT_DIR_PATH . 'languages' );
		}
	}
	public function default_enqueue_recaptcha_script() {
		if ( ! \Academy\Helper::get_settings( 'is_enabled_recaptcha', false ) || \AcademyPro\Helper::is_gemsecurity_captcha_active() ) {
			// GemSecurity's own Captcha module already enqueues its own
			// script on login_enqueue_scripts whenever it's active.
			return;
		}
		wp_enqueue_script(
			'google-recaptcha',
			'https://www.google.com/recaptcha/api.js',
			[],
			ACADEMY_PRO_VERSION,
			true
		);
	}

	public function enqueue_recaptcha_script() {
		global $post;

		// GemSecurity's widget needs its own script (loaded via its own
		// enqueue_script(), not Google's bare api.js URL) on the same pages
		// where add_google_recaptcha_markup() rendered it — see
		// AcademyPro\Helper::is_gemsecurity_captcha_embeddable() for why
		// only some configured providers reach this branch.
		$gemsecurity_embeddable = \AcademyPro\Helper::is_gemsecurity_captcha_embeddable();

		$academy_v3_recaptcha = ! \AcademyPro\Helper::is_gemsecurity_captcha_active()
			&& \Academy\Helper::get_settings( 'is_enabled_recaptcha', false )
			&& 'v3' === \Academy\Helper::get_settings( 'recaptcha_type', 'v2' );

		if ( ! $gemsecurity_embeddable && ! $academy_v3_recaptcha ) {
			return;
		}

		if (
			$post &&
			(
				is_singular( 'academy_courses' ) ||
				(int) \Academy\Helper::get_settings( 'frontend_instructor_reg_page' ) === $post->ID ||
				(int) \Academy\Helper::get_settings( 'frontend_student_reg_page' ) === $post->ID ||
				(int) \Academy\Helper::get_settings( 'frontend_dashboard_page' ) === $post->ID ||
				(int) \Academy\Helper::get_settings( 'password_reset_page' ) === $post->ID ||
				has_shortcode( $post->post_content, 'academy_dashboard' ) ||
				has_shortcode( $post->post_content, 'academy_instructor_registration_form' ) ||
				has_shortcode( $post->post_content, 'academy_student_registration_form' ) ||
				has_shortcode( $post->post_content, 'academy_login_form' ) ||
				has_shortcode( $post->post_content, 'academy_password_reset_form' )
			)
		) {
			if ( $gemsecurity_embeddable ) {
				( new \GemSecurity\Modules\Captcha() )->enqueue_script();
				return;
			}
			wp_enqueue_script( 'google-recaptcha', 'https://www.google.com/recaptcha/api.js?render=' . \Academy\Helper::get_settings( 'recaptcha_v3_site_key', '' ), array(), ACADEMY_PRO_VERSION, false );
		}
	}
	public function localize_scripts_data( $data ) {
		// recaptcha — forced off once GemSecurity's Captcha module is
		// active, so the frontend's existing is_enabled_recaptcha check
		// (in Academy core's frontendssr.js, unmodified) is automatically
		// inert without that file needing any GemSecurity-awareness.
		$data['is_enabled_recaptcha'] = \Academy\Helper::get_settings( 'is_enabled_recaptcha', false )
			&& ! \AcademyPro\Helper::is_gemsecurity_captcha_active();
		$data['is_enabled_group_plus'] = \Academy\Helper::get_addon_active_status( 'group-plus', true );
		if ( $data['is_enabled_recaptcha'] ) {
			$data['recaptcha_type'] = \Academy\Helper::get_settings( 'recaptcha_type', 'v2' );
			if ( 'v3' === $data['recaptcha_type'] ) {
				$data['recaptcha_v3_site_key'] = \Academy\Helper::get_settings( 'recaptcha_v3_site_key', '' );
			} else {
				$data['recaptcha_v2_site_key'] = \Academy\Helper::get_settings( 'recaptcha_v2_site_key', '' );
			}
		}
		return $data;
	}

	/**
	 * Lets the Advanced → reCAPTCHA settings screen show a deprecation
	 * banner without re-deriving GemSecurity's state itself — same pattern
	 * as the existing `gemsecurity_social_login_active` flag Academy core
	 * already exposes on this same `AcademyGlobal` object for its own
	 * Social Login screen.
	 *
	 * Hooked onto Academy core's `academy/assets/backend_scripts_data`
	 * filter (applied in `Academy\Classes\ScriptsBase::get_backend_scripts_data()`)
	 * rather than editing that file directly.
	 *
	 * @param array $data
	 * @return array
	 */
	public function localize_backend_scripts_data( $data ) {
		$data['gemsecurity_captcha_active'] = \AcademyPro\Helper::is_gemsecurity_captcha_active();
		return $data;
	}
}
