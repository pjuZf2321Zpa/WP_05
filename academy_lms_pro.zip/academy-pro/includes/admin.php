<?php
namespace AcademyPro;

use AcademyProDeviceLoginRestrictions;
use AcademyProDeviceLoginRestrictions\DeviceLoginRestrictions;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


class Admin {
	public static function init() {
		$self = new self();
		$self->dispatch_hooks();
		$self->init_hooks();
	}
	public function dispatch_hooks() {
		Admin\Settings::init();
		Admin\Export::init();
	}

	public function init_hooks() {
		ExportImport\Admin::init();
	}
}
