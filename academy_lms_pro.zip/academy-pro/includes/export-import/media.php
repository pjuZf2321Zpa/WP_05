<?php
namespace AcademyPro\ExportImport;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Thin wrapper over Academy core's MediaImporter so Pro keeps working
 * (without image support) next to an older core that lacks it.
 */
class Media {
	private static function available() {
		return class_exists( '\Academy\Classes\MediaImporter' );
	}

	public static function get_attachment_url( $attachment_id ) {
		return self::available() ? \Academy\Classes\MediaImporter::get_attachment_url( $attachment_id ) : '';
	}

	public static function import_image( $url, $parent_id = 0 ) {
		if ( empty( $url ) || ! self::available() ) {
			return 0;
		}
		return \Academy\Classes\MediaImporter::import_image_from_url( $url, $parent_id );
	}

	public static function import_content_images( $content, $parent_id = 0 ) {
		return self::available() ? \Academy\Classes\MediaImporter::import_content_images( $content, $parent_id ) : $content;
	}
}
