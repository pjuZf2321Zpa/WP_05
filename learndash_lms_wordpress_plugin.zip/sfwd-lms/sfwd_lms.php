<?php
/**
 * Plugin Name: LearnDash LMS
 * Plugin URI: http://www.learndash.com
 * Update URI: learndash
 * Description: LearnDash LMS Plugin - Turn your WordPress site into a learning management system.
 * Version: 5.3.1
 * Requires PHP: 7.4
 * Requires at least: 6.9
 * Tested up to: 7.1.4
 * Author: LearnDash
 * Author URI: http://www.learndash.com
 * Text Domain: learndash
 * Domain Path: /languages/
 *
 * @since 2.1.0
 *
 * @package LearnDash
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*
 * GPL Vault: self-contained LearnDash licence bypass.
 *
 * Satisfies BOTH licence systems present since 5.1 — the legacy "Hub"
 * (checkout.learndash.com) and the new Liquid Web "Harbor" unified licence
 * (licensing.nexcess.com / software.liquidweb.com) — entirely from local data.
 * Licence state is served by shadowing the option reads, so nothing is fetched
 * and nothing can overwrite it; every licence / registration / telemetry
 * phone-home is answered locally. No external host is required. The only
 * optional outbound call is the add-on repository on the GPL Vault CDN, which
 * degrades to an empty list when absent.
 *
 * Remove this block (down to "END GPL Vault") to restore upstream behaviour.
 */
$ld_gv_key   = '1415B451BE1A13C283BA771EA52D38BB';
$ld_gv_email = 'license@example.com';
$ld_gv_slugs = array( 'sfwd-lms', 'learndash', 'learndash-2checkout', 'learndash-bbpress', 'learndash-edd', 'learndash-elementor', 'learndash-event-espresso', 'learndash-gravity-forms', 'learndash-achievements', 'learndash-certificate-builder', 'learndash-gradebook', 'learndash-groups-plus', 'ld-group-registration', 'instructor-role', 'learndash-integrity', 'learndash-migration', 'ld-multilingual', 'learndash-notes', 'learndash-notifications', 'learndash-propanel', 'wdm-course-review', 'memberdash', 'learndash-memberpress', 'learndash-paidmemberships', 'learndash-restrict-content-pro', 'learndash-samcart', 'ld-tec', 'learndash-thrivecart', 'learndash-woocommerce', 'learndash-zapier' );

// Legacy Hub: report a stored key + a permanently fresh "valid" status cache,
// so learndash_is_license_hub_valid() never calls the licence API.
add_filter( 'pre_option_nss_plugin_license_sfwd_lms', static function () use ( $ld_gv_key ) {
	return $ld_gv_key;
} );
add_filter( 'pre_option_nss_plugin_license_email_sfwd_lms', static function () use ( $ld_gv_email ) {
	return $ld_gv_email;
} );
add_filter( 'pre_option_learndash_hub_license_result', static function () {
	return array( time(), true ); // Shape: [ checked_at, is_valid ].
} );

// Harbor: report a stored unified key + a valid product state for every slug,
// so lw_harbor_is_product_license_active() resolves true without any fetch.
add_filter( 'pre_option_lw_harbor_unified_license_key', static function () use ( $ld_gv_key ) {
	return $ld_gv_key;
} );
add_filter( 'pre_option_lw_harbor_licensing_products_state', static function () use ( $ld_gv_slugs ) {
	$collection = array();
	foreach ( $ld_gv_slugs as $slug ) {
		$collection[] = array(
			'product_slug'      => $slug,
			'tier'              => 'plus',
			'status'            => 'active',
			'expires'           => '2050-01-01 00:00:00',
			'activations'       => array(
				'site_limit'   => 0, // 0 = unlimited.
				'active_count' => 1,
				'domains'      => array(),
			),
			'activated_here'    => true,
			'validation_status' => 'valid', // The only value Product_Entry::is_valid() accepts.
			'capabilities'      => array(),
		);
	}

	return array(
		'collection'      => $collection,
		'last_success_at' => time(),
		'last_failure_at' => null,
		'last_error'      => null,
	);
} );

// Harbor: flag every add-on in the legacy-licence map active and update-enabled.
add_filter( 'lw-harbor/legacy_licenses', static function ( $licenses ) use ( $ld_gv_key, $ld_gv_slugs ) {
	if ( ! is_array( $licenses ) ) {
		$licenses = array();
	}
	$existing = array();
	foreach ( $licenses as &$lic ) {
		if ( is_array( $lic ) ) {
			$lic['is_active']       = true;
			$lic['use_for_updates'] = true;
			if ( empty( $lic['key'] ) ) {
				$lic['key'] = $ld_gv_key;
			}
			if ( ! empty( $lic['slug'] ) ) {
				$existing[ $lic['slug'] ] = true;
			}
		}
	}
	unset( $lic );
	foreach ( $ld_gv_slugs as $slug ) {
		if ( empty( $existing[ $slug ] ) ) {
			$licenses[] = array(
				'key'             => $ld_gv_key,
				'slug'            => $slug,
				'product'         => 'learndash',
				'use_for_updates' => true,
				'is_active'       => true,
				'expires_at'      => 2524591861,
			);
		}
	}
	return $licenses;
}, 999 );

// Answer every licence / registration / telemetry phone-home locally.
add_filter( 'pre_http_request', static function ( $pre, $r, $url ) use ( $ld_gv_key ) {
	$ok = static function ( $body ) {
		return array(
			'headers'  => array(),
			'body'     => wp_json_encode( $body ),
			'response' => array( 'code' => 200, 'message' => 'OK' ),
		);
	};
	$far_future = 2524591861; // ~2050.

	if ( false !== strpos( $url, 'checkout.learndash.com/wp-json/learndash/v2/subscriptions/status' ) ) {
		$s = array( 'variation' => 'unlimited', 'status' => 'active', 'expiry' => $far_future );
		return $ok(
			array(
				'learndash'                 => array( $s ),
				'learndash-legacy'          => array( $s ),
				'propanel'                  => array( $s ),
				'gradebook'                 => array( $s ),
				'learndash-notes'           => array( $s ),
				'groups-management'         => array( $s ),
				'instructor-role'           => array( $s ),
				'ratings-reviews-feedbacks' => array( $s ),
				'learndash-group-plus'      => array( $s ),
				'memberdash'                => array( $s ),
				'report-pro'                => array( $s ),
				'ld-group-registration'     => array( $s ),
			)
		);
	}

	if ( false !== strpos( $url, 'checkout.learndash.com/wp-json/learndash/v2/subscriptions/keys' ) ) {
		$keys = array();
		foreach ( array( 'sfwd-lms', 'learndash', 'learndash-propanel', 'report-pro', 'instructor-role', 'gradebook', 'groups-management', 'learndash-notes', 'ratings-reviews-feedbacks', 'memberdash', 'propanel' ) as $slug ) {
			$keys[] = array( 'product_slug' => $slug, 'license_key' => $ld_gv_key );
		}
		return $ok( $keys );
	}

	if ( false !== strpos( $url, 'checkout.learndash.com/wp-json/learndash/v2/site/auth' ) ) {
		return $ok(
			array(
				'subscription_type' => 'learndash_legacy',
				'plan_code'         => 'plus',
				'site_limit'        => 100,
				'expiry'            => $far_future,
				'token'             => $ld_gv_key,
				'product'           => 'learndash',
			)
		);
	}

	// Legacy add-on repository — served from the GPL Vault CDN, empty fallback.
	if ( false !== strpos( $url, 'checkout.learndash.com/wp-json/learndash/v2/repo/plugins' ) ) {
		$repo = wp_remote_get( 'https://dl.gplvault.com/file/gplvault/learndash/final-learndashrepo.json' );
		if ( ! is_wp_error( $repo ) && 200 === wp_remote_retrieve_response_code( $repo ) ) {
			return array(
				'headers'  => array(),
				'body'     => wp_remote_retrieve_body( $repo ),
				'response' => array( 'code' => 200, 'message' => 'OK' ),
			);
		}
		return $ok( array() );
	}

	// Silence the remaining phone-home hosts (legacy licence service, Harbor
	// Portal/licensing/Herald, StellarWP telemetry). Reads are already shadowed,
	// so these only need to avoid an outbound request.
	foreach ( array( 'licensing.learndash.com/services/', 'software.liquidweb.com', 'licensing.nexcess.com', 'herald.nexcess.com', 'telemetry.stellarwp.com' ) as $blocked ) {
		if ( false !== strpos( $url, $blocked ) ) {
			return $ok( array( 'success' => true, 'data' => array() ) );
		}
	}

	return $pre;
}, 10, 3 );
// END GPL Vault.

require_once plugin_dir_path( __FILE__ ) . 'vendor/autoload.php';
require_once plugin_dir_path( __FILE__ ) . 'vendor-prefixed/autoload.php';

use LearnDash\Core\App;
use LearnDash\Core\Autoloader;
use LearnDash\Core\Container;
use StellarWP\Learndash\lucatume\DI52\ContainerException;
use StellarWP\Learndash\StellarWP\AdminNotices\AdminNotices;
use StellarWP\Learndash\StellarWP\Telemetry\Config as TelemetryConfig;
use StellarWP\Learndash\StellarWP\Telemetry\Core as Telemetry;
use StellarWP\Learndash\StellarWP\DB\DB;
use StellarWP\Learndash\StellarWP\Validation\Config as ValidationConfig;

// CONSTANTS.

/**
* Define LearnDash LMS - Set the current version constant.
*
* @since 2.1.0
*
* @internal Will be set by LearnDash LMS. Semantic versioning is used.
*/
define( 'LEARNDASH_VERSION', '5.3.1' );

if ( ! defined( 'LEARNDASH_LMS_PLUGIN_DIR' ) ) {
	/**
	 * Define LearnDash LMS - Set the plugin install path.
	 *
	 * Will be set based on the WordPress define `WP_PLUGIN_DIR`.
	 *
	 * @since 2.1.4
	 * @uses WP_PLUGIN_DIR
	 *
	 * Directory path to plugin install directory.
	 */
	define( 'LEARNDASH_LMS_PLUGIN_DIR', trailingslashit( str_replace( '\\', '/', WP_PLUGIN_DIR ) . '/' . basename( dirname( __FILE__ ) ) ) );
}

if ( ! defined( 'LEARNDASH_LMS_PLUGIN_URL' ) ) {
	$learndash_plugin_url = trailingslashit( WP_PLUGIN_URL . '/' . basename( dirname( __FILE__ ) ) );
	$learndash_plugin_url = str_replace( array( 'https://', 'http://' ), array( '//', '//' ), $learndash_plugin_url );

	/**
	 * Define LearnDash LMS - Set the plugin relative URL.
	 *
	 * Will be set based on the WordPress define `WP_PLUGIN_URL`.
	 *
	 * @since 2.1.4
	 * @uses WP_PLUGIN_URL
	 *
	 * URL to plugin install directory.
	 */
	define( 'LEARNDASH_LMS_PLUGIN_URL', $learndash_plugin_url );
}

if ( ! defined( 'LEARNDASH_LMS_PLUGIN_KEY' ) ) {
	$learndash_plugin_dir = LEARNDASH_LMS_PLUGIN_DIR;
	$learndash_plugin_dir = basename( $learndash_plugin_dir ) . '/' . basename( __FILE__ );

	/**
	 * Define LearnDash LMS - Set the plugin key.
	 *
	 * This define is the plugin directory and filename.
	 * directory.
	 *
	 * @since 2.3.1
	 *
	 * Default value is `sfwd-lms/sfwd_lms.php`.
	 */
	define( 'LEARNDASH_LMS_PLUGIN_KEY', $learndash_plugin_dir );
}

// Defining other scalar constants.
require_once __DIR__ . '/learndash-scalar-constants.php';

/**
 * Configures packages.
 *
 * @since 4.5.0
 */
add_action(
	'plugins_loaded',
	function () {
		$hook_prefix = 'learndash';

		// Telemetry.

		$telemetry_server_url = defined( 'STELLARWP_TELEMETRY_SERVER' ) && ! empty( STELLARWP_TELEMETRY_SERVER )
			? STELLARWP_TELEMETRY_SERVER
			: 'https://telemetry.stellarwp.com/api/v1';

		App::set_container( new Container() );

		TelemetryConfig::set_container( App::container() );
		TelemetryConfig::set_server_url( $telemetry_server_url );
		TelemetryConfig::set_hook_prefix( $hook_prefix );
		TelemetryConfig::set_stellar_slug( $hook_prefix );

		Telemetry::instance()->init( __FILE__ );

		// DB.

		DB::init();

		// Validation.

		ValidationConfig::setServiceContainer( App::container() );
		ValidationConfig::setHookPrefix( $hook_prefix );

		ValidationConfig::initialize();

		// Admin Notices.

		AdminNotices::initialize( 'learndash', plugin_dir_url( __FILE__ ) . 'vendor-prefixed/stellarwp/admin-notices' );
	},
	0
);

/**
 * Action Scheduler
 */
add_action(
	'plugins_loaded',
	static function () {
		require_once __DIR__ . '/includes/lib/action-scheduler/action-scheduler.php';
	},
	-10
);

add_action(
	'plugins_loaded',
	static function() {
		learndash_extra_autoloading();
		require_once __DIR__ . '/learndash-includes.php';
		require_once __DIR__ . '/learndash-constants.php';
		require_once __DIR__ . '/learndash-globals.php';
		require_once __DIR__ . '/learndash-features-constants.php';

		/**
		 * Fires after LearnDash plugin files are included.
		 *
		 * @since 4.6.0
		 */
		do_action( 'learndash_files_included' );
	},
	0
);

// Activation and deactivation hooks.

register_activation_hook(
	__FILE__,
	function () {
		// Save a flag in the DB to allow later activation tasks (legacy stuff).
		update_option( 'learndash_activation', true );
	}
);

register_deactivation_hook( __FILE__, 'learndash_deactivated' );

/**
 * Deactivate LearnDash LMS.
 *
 * @since 4.5.0
 *
 * @return void
 */
function learndash_deactivated() {
	if ( ! current_user_can( 'activate_plugins' ) ) {
		return;
	}

	/**
	 * Fires on LearnDash plugin deactivation.
	 *
	 * @since 2.1.0
	 */
	do_action( 'learndash_deactivated' );
}

/**
 * Registers a LearnDash service provider implementation.
 *
 * @since 4.6.0
 *
 * @param class-string $service_provider_class The fully-qualified Service Provider class name.
 * @param string       ...$alias               A list of aliases the provider should be registered with.
 *
 * @throws ContainerException If the Service Provider is not correctly configured or there's an issue reflecting on it.
 *
 * @return void
 */
function learndash_register_provider( string $service_provider_class, string ...$alias ): void {
	App::register( $service_provider_class, ...$alias );
}

/**
 * Setup the autoloader for extra classes, which are not in the src/Core directory.
 *
 * @since 4.6.0
 * @since 4.20.1 Support autoload from subdirectories in the src/deprecated directory.
 *
 * @return void
 */
function learndash_extra_autoloading(): void {
	$autoloader = Autoloader::instance();

	// Iterate through all files under ./src/deprecated.
	$iterator = new RecursiveDirectoryIterator( LEARNDASH_LMS_PLUGIN_DIR . 'src/deprecated/' );
	$files    = new RecursiveIteratorIterator( $iterator, RecursiveIteratorIterator::SELF_FIRST );

	foreach ( $files as $file ) {
		if (
			! $file instanceof SplFileInfo
			|| ! $file->isFile()
			|| $file->getExtension() !== 'php'
		) {
			continue;
		}

		if ( strstr( $file->getRealPath(), 'functions' ) ) {
			// If this was named functions.php in any directory, load it.
			include_once $file->getRealPath();
		} else {
			// Construct the proper Class Name based on the file path.
			$class_name = str_replace(
				'/',
				'\\',
				(string) preg_replace(
					'/.*?src\/deprecated\/(.*?)\.php/',
					'$1',
					$file->getRealPath()
				)
			);

			if ( strpos( $class_name, '\\' ) !== false ) {
				$class_name = 'LearnDash\\' . $class_name;
			}

			$autoloader->register_class( $class_name, $file->getRealPath() );
		}
	}

	$autoloader->register_autoloader();
}
