<?php
/**
 * Generate PDF
 *
 * Originally by Redcocker 2012/3/5
 * License: GPL v2
 * http://www.near-mint.com/blog/
 *
 * @since 2.1.0
 *
 * @package LearnDash\PDF
 */

use LearnDash\Core\Modules\Certificates\Legacy\Deprecated_Hooks;
use LearnDash\Core\Modules\Certificates\Legacy\Pdf_Renderer;
use LearnDash\Core\Utilities\Cast;
use StellarWP\Learndash\Mpdf\MpdfException;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'learndash_get_thumb_path' ) ) {

	/**
	 * Gets featured image of certificate post.
	 *
	 * @param int $post_id Post ID.
	 *
	 * @return string Optional. Certificate featured image path. Default 0.
	 */
	function learndash_get_thumb_path( $post_id = 0 ) {
		if ( ! empty( $post_id ) ) {
			$post_type = get_post_type( $post_id );
			if ( post_type_supports( $post_type, 'thumbnail' ) ) {
				$thumbnail_id = get_post_meta( $post_id, '_thumbnail_id', true );
				$thumbnail_id = absint( $thumbnail_id );
				if ( $thumbnail_id ) {
					/**
					 * Filters the type of the image to use for the certificate PDF background.
					 *
					 * Filter to allow URLs to be used for certificate background images. LEARNDASH-3430
					 *
					 * Applies only to shortcode (v1) certificates, and to block-based (v2) ones printed while the
					 * Certificate Builder is turned off.
					 *
					 * @since 3.2.0
					 *
					 * @param string $type         Default 'path' will user local server path. 'url' will use image URL.
					 * @param int    $post_id      Post ID of certificate to be shown.
					 * @param int    $thumbnail_id Image thumbnail ID.
					 */
					$image_type = apply_filters( 'ld_certificate_image_type', 'path', $post_id, $thumbnail_id );
					if ( 'url' === $image_type ) {
						$img_full_path = get_the_post_thumbnail_url( get_post( $post_id ), 'full' );
					} else {
						$img_path              = get_post_meta( $thumbnail_id, '_wp_attached_file', true );
						$upload_url            = wp_upload_dir();
						$upload_url['basedir'] = str_replace( '\\', '/', $upload_url['basedir'] );
						$img_full_path         = $upload_url['basedir'] . '/' . $img_path;
					}
					return $img_full_path;
				}
			}
		}
		return '';
	}
}

if ( ! function_exists( 'learndash_post2pdf_conv_image_align_center' ) ) {
	/**
	 * Adds the markup to align image to center.
	 *
	 * Used as callback in `preg_replace_callback` function.
	 *
	 * @param  array $matches An array with strings to search and replace.
	 *
	 * @return string Image align center output.
	 */
	function learndash_post2pdf_conv_image_align_center( $matches ) {
		$tag_begin = '<p class="post2pdf_conv_image_align_center">';
		$tag_end   = '</p>';

		return $tag_begin . $matches[1] . $tag_end;
	}
}

if ( ! function_exists( 'learndash_post2pdf_conv_img_size' ) ) {
	/**
	 * Adds the height and width to the image tag.
	 *
	 * Used as a callback in `preg_replace_callback` function.
	 *
	 * @param  array $matches array with strings to search and replace.
	 *
	 * @return string The image align center markup.
	 */
	function learndash_post2pdf_conv_img_size( $matches ) {
		global $q_config;
		$size = null;

		if ( strpos( $matches[2], site_url() ) === false ) {
			return $matches[1] . $matches[5];
		}

		$image_path = ABSPATH . str_replace( site_url() . '/', '', $matches[2] );

		if ( file_exists( $image_path ) ) {
			$size = getimagesize( $image_path );
		} else {
			return $matches[1] . $matches[5];
		}

		return $matches[1] . ' ' . $size[3] . $matches[5];
	}
}

if ( ! function_exists( 'learndash_certificate_post_shortcode' ) ) {

	/**
	 * Converts a post to PDF.
	 *
	 * @since 3.2.0
	 *
	 * @param array $cert_args Optional. Array of arguments passed in for processing. Default empty array.
	 */
	function learndash_certificate_post_shortcode( $cert_args = array() ) {

		$cert_args_defaults = array(
			'cert_id'       => 0,     // The certificate Post ID.
			'post_id'       => 0,     // The Course/Quiz Post ID.
			'user_id'       => 0,     // The User ID for the Certificate.
			'lang'          => 'eng', // The default language.

			'filename'      => '',
			'filename_url'  => '',
			'filename_type' => 'title',

			'pdf_title'     => '',
			'ratio'         => 1.25,

			/*
			I: send the file inline to the browser (default).
			D: send to the browser and force a file download with the name given by name.
			F: save to a local server file with the name given by name.
			S: return the document as a string (name is ignored).
			FI: equivalent to F + I option
			FD: equivalent to F + D option
			E: return the document as base64 mime multi-part email attachment (RFC 2045)
			*/
		);
		$cert_args = shortcode_atts( $cert_args_defaults, $cert_args );

		// Just to ensure we have valid IDs.
		$cert_args['cert_id'] = absint( $cert_args['cert_id'] );
		$cert_args['post_id'] = absint( $cert_args['post_id'] );
		$cert_args['user_id'] = absint( $cert_args['user_id'] );

		if ( empty( $cert_args['cert_id'] ) ) {
			if ( isset( $_GET['id'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
				$cert_args['cert_id'] = absint( $_GET['id'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			} else {
				$cert_args['cert_id'] = get_the_id();
			}
		}

		if ( empty( $cert_args['user_id'] ) ) {
			if ( isset( $_GET['user'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
				$cert_args['user_id'] = absint( $_GET['user'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			} elseif ( isset( $_GET['user_id'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
				$cert_args['user_id'] = absint( $_GET['user_id'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			}
		}

		$cert_args['cert_post'] = get_post( $cert_args['cert_id'] );
		if ( ( ! $cert_args['cert_post'] ) || ( ! is_a( $cert_args['cert_post'], 'WP_Post' ) ) || ( learndash_get_post_type_slug( 'certificate' ) !== $cert_args['cert_post']->post_type ) ) {
			wp_die( esc_html__( 'Certificate Post does not exist.', 'learndash' ) );
		}

		$cert_args['post_post'] = get_post( $cert_args['post_id'] );
		if ( ( ! $cert_args['post_post'] ) || ( ! is_a( $cert_args['post_post'], 'WP_Post' ) ) ) {
			wp_die( esc_html__( 'Awarded Post does not exist.', 'learndash' ) );
		}

		$cert_args['user'] = get_user_by( 'ID', $cert_args['user_id'] );
		if ( ( ! $cert_args['user'] ) || ( ! is_a( $cert_args['user'], 'WP_User' ) ) ) {
			wp_die( esc_html__( 'User does not exist.', 'learndash' ) );
		}

		// Start config override section.

		/*
		 * Language codes are the three-character form, eng, fra, ger and so on. `cert_lang` is
		 * checked first since it may need to differ from `lang`.
		 */
		$config_lang_tmp = '';
		if ( ! empty( $_GET['cert_lang'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$config_lang_tmp = substr(
				esc_attr( sanitize_text_field( wp_unslash( $_GET['cert_lang'] ) ) ), // phpcs:ignore WordPress.Security.NonceVerification.Recommended
				0,
				3
			);
		} elseif ( ! empty( $_GET['lang'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$config_lang_tmp = substr(
				esc_attr( sanitize_text_field( wp_unslash( $_GET['lang'] ) ) ), // phpcs:ignore WordPress.Security.NonceVerification.Recommended
				0,
				3
			);
		}

		/*
		 * The code is recorded so a filter reading the args still sees it, and it goes no further:
		 * the renderer draws every certificate left-to-right.
		 */
		if ( strlen( $config_lang_tmp ) === 3 ) {
			$cert_args['lang'] = $config_lang_tmp;
		}

		$target_post_id             = 0;
		$cert_args['filename_type'] = 'title';

		$logo_file         = '';
		$logo_enable       = '';
		$logo_width        = '';
		$subsetting_enable = '';
		$filters           = '';
		$header_enable     = '';
		$footer_enable     = '';
		$monospaced_font   = '';
		$font              = '';
		$font_size         = '';
		$destination       = 'I';
		$destination_type  = 'U';

		ob_start();

		$cert_args['cert_title'] = $cert_args['cert_post']->post_title;
		$cert_args['cert_title'] = wp_strip_all_tags( $cert_args['cert_title'] );

		/** This filter is documented in https://developer.wordpress.org/reference/hooks/document_title_separator/ */
		$sep = apply_filters( 'document_title_separator', '-' ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WP Core Hook

		/**
		 * Filters username of the user to be used in creating certificate PDF.
		 *
		 * Applies only to shortcode (v1) certificates, and to block-based (v2) ones printed while the
		 * Certificate Builder is turned off.
		 *
		 * @param string $user_name User display name.
		 * @param int    $user_id   User ID.
		 * @param int    $cert_id   Certificate post ID.
		 */
		$learndash_pdf_username = apply_filters( 'learndash_pdf_username', $cert_args['user']->display_name, $cert_args['user_id'], $cert_args['cert_id'] );
		if ( ! empty( $learndash_pdf_username ) ) {
			if ( ! empty( $cert_args['pdf_title'] ) ) {
				$cert_args['pdf_title'] .= " $sep ";
			}
			$cert_args['pdf_title'] .= $learndash_pdf_username;
		}

		$cert_for_post_title = get_the_title( $cert_args['post_id'] );
		wp_strip_all_tags( $cert_for_post_title );
		if ( ! empty( $cert_for_post_title ) ) {
			if ( ! empty( $cert_args['pdf_title'] ) ) {
				$cert_args['pdf_title'] .= " $sep ";
			}
			$cert_args['pdf_title'] .= $cert_for_post_title;
		}

		if ( ! empty( $cert_args['pdf_title'] ) ) {
			$cert_args['pdf_title'] .= " $sep ";
		}
		$cert_args['pdf_title'] .= $cert_args['cert_title'];

		if ( ! empty( $cert_args['pdf_title'] ) ) {
			$cert_args['pdf_title'] .= " $sep ";
		}
		$cert_args['pdf_title'] .= get_bloginfo( 'name', 'display' );

		$cert_args['cert_permalink']  = get_permalink( $cert_args['cert_post']->ID );
		$cert_args['pdf_author_name'] = $cert_args['user']->display_name;

		$tags_array                = array();
		$cert_args['pdf_keywords'] = '';
		$tags_data                 = wp_get_post_tags( $cert_args['cert_post']->ID );

		if ( $tags_data ) {
			foreach ( $tags_data as $val ) {
				$tags_array[] = $val->name;
			}
			$cert_args['pdf_keywords'] = implode( ' ', $tags_array );
		}

		if ( ! empty( $_GET['file'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$cert_args['filename_type'] = sanitize_text_field( wp_unslash( $_GET['file'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		}

		if ( 'title' === $cert_args['filename_type'] ) {
			$filename = sanitize_file_name( str_replace( " $sep ", "$sep", $cert_args['pdf_title'] ) );
			/**
			 * Filters the file name of the certificate pdf.
			 *
			 * Applies only to shortcode (v1) certificates, and to block-based (v2) ones printed while the
			 * Certificate Builder is turned off.
			 *
			 * @param string $filename Name of the pdf file.
			 * @param int    $cert_id Certificate post ID.
			 */
			$filename = apply_filters( 'learndash_pdf_filename', $filename, $cert_args['cert_id'] );

		} else {
			$filename = $cert_args['cert_id'] . '.pdf';
		}
		$filename = basename( $filename );
		$filename = substr( $filename, 0, 255 );
		$filename = sanitize_file_name( $filename );

		$cached_filename = '';

		$query_string_params_supported = array( 'font', 'monospaced', 'fontsize', 'subsetting', 'ratio', 'header', 'logo', 'logo_file', 'logo_width', 'footer', 'destination', 'destination_type' );

		$query_string_params_allowed = array( 'destination', 'destination_type' );

		/**
		 * Filter for allowed PDF Certificate parameters.
		 *
		 * Applies only to shortcode (v1) certificates, and to block-based (v2) ones printed while the
		 * Certificate Builder is turned off.
		 *
		 * @since 3.4.1
		 *
		 * @param array $query_string_params_allowed   Array of allowed query string params.
		 * @param array $query_string_params_supported Array of supported query string params.
		 */
		$query_string_params_allowed = apply_filters( 'learndash_certificate_query_string_params_allowed', $query_string_params_allowed, $query_string_params_supported );

		if ( ! is_array( $query_string_params_allowed ) ) {
			$query_string_params_allowed = array();
		}

		$query_string_params_allowed = array_intersect( $query_string_params_allowed, $query_string_params_supported );

		if ( in_array( 'font', $query_string_params_allowed, true ) ) {
			if ( ! empty( $_GET['font'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
				$font = esc_html( sanitize_text_field( wp_unslash( $_GET['font'] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			}
		}

		if ( in_array( 'monospaced', $query_string_params_allowed, true ) ) {
			if ( ! empty( $_GET['monospaced'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
				$monospaced_font = esc_html( sanitize_text_field( wp_unslash( $_GET['monospaced'] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			}
		}

		if ( in_array( 'fontsize', $query_string_params_allowed, true ) ) {
			if ( ! empty( $_GET['fontsize'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
				$font_size = intval( sanitize_text_field( wp_unslash( $_GET['fontsize'] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			}
		}

		if ( in_array( 'subsetting', $query_string_params_allowed, true ) ) {
			if ( ! empty( sanitize_text_field( wp_unslash( $_GET['subsetting'] ) ) ) && ( 1 === $_GET['subsetting'] || 0 === $_GET['subsetting'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
				$subsetting_enable = sanitize_text_field( wp_unslash( $_GET['subsetting'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			}
		}

		if ( $subsetting_enable ) {
			$subsetting = true;
		} else {
			$subsetting = false;
		}

		if ( in_array( 'ratio', $query_string_params_allowed, true ) ) {
			if ( ! empty( $_GET['ratio'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
				$cert_args['ratio'] = floatval( $_GET['ratio'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			}
		}

		if ( in_array( 'header', $query_string_params_allowed, true ) ) {
			if ( ! empty( $_GET['header'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
				$header_enable = sanitize_text_field( wp_unslash( $_GET['header'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			}
		}

		if ( in_array( 'logo', $query_string_params_allowed, true ) ) {
			if ( ! empty( $_GET['logo'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
				$logo_enable = sanitize_text_field( wp_unslash( $_GET['logo'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			}
		}

		if ( in_array( 'logo_file', $query_string_params_allowed, true ) ) {
			if ( ! empty( $_GET['logo_file'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
				$logo_file = esc_html( sanitize_text_field( wp_unslash( $_GET['logo_file'] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			}
		}

		if ( in_array( 'logo_width', $query_string_params_allowed, true ) ) {
			if ( ! empty( $_GET['logo_width'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
				$logo_width = intval( $_GET['logo_width'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			}
		}

		if ( in_array( 'footer', $query_string_params_allowed, true ) ) {
			if ( ! empty( $_GET['footer'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
				$footer_enable = sanitize_text_field( wp_unslash( $_GET['footer'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			}
		}

		if ( in_array( 'destination', $query_string_params_allowed, true ) ) {
			if ( ( isset( $_GET['destination'] ) ) && ( ! empty( $_GET['destination'] ) ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
				if ( 'F' === $_GET['destination'] ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
					$destination = 'F';
				} else {
					$destination = 'I';
				}
			} else {
				$destination = 'I';
			}
		}

		if ( in_array( 'destination_type', $query_string_params_allowed, true ) ) {
			if ( 'F' === $destination ) {
				if ( ( isset( $_GET['destination_type'] ) ) && ( ! empty( $_GET['destination_type'] ) ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
					if ( 'F' === $_GET['destination_type'] ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
						$destination_type = 'F';
					} else {
						$destination_type = 'U';
					}
				}
			}
		}

		if ( 'F' === $destination ) {
			if ( ( defined( 'LEARNDASH_UPLOADS_BASE_URL' ) ) && ( ! empty( LEARNDASH_UPLOADS_BASE_URL ) ) ) {
				$cert_args['filename_url'] = LEARNDASH_UPLOADS_BASE_URL . '/certificates/' . $filename;
			}

			if ( ( defined( 'LEARNDASH_UPLOADS_BASE_DIR' ) ) && ( ! empty( LEARNDASH_UPLOADS_BASE_DIR ) ) && ( file_exists( LEARNDASH_UPLOADS_BASE_DIR ) ) && ( is_writable( LEARNDASH_UPLOADS_BASE_DIR ) ) ) {
				$ld_upload_certificates_dir = trailingslashit( LEARNDASH_UPLOADS_BASE_DIR ) . 'certificates';
				if ( ! file_exists( $ld_upload_certificates_dir ) ) {
					if ( wp_mkdir_p( $ld_upload_certificates_dir ) !== false ) {
						// To prevent security browsing add an index.php file.
						learndash_put_directory_index_file( trailingslashit( $ld_upload_certificates_dir ) . 'index.php' );
					}
				}
				$filename = trailingslashit( $ld_upload_certificates_dir ) . $filename;
			}
		}

		/**
		 * Start Cert post content processing.
		 */

		/**
		 * Filters whether to enable legacy TCPDF processing logic.
		 *
		 * The returned value is no longer applied: certificates always render the way the default
		 * `true` did.
		 *
		 * @since 3.2.2
		 * @deprecated 5.3.0
		 *
		 * @param bool                 $use_LD322_define Whether to enable legacy TCPDF processing logic.
		 * @param array<string, mixed> $cert_args        Certificate arguments.
		 */
		apply_filters_deprecated(
			'learndash_tcpdf_legacy_ld322',
			[ true, $cert_args ],
			'5.3.0',
			'',
			esc_html__( 'The returned value is no longer applied. Certificates always render the way its default value did.', 'learndash' )
		);

		/*
		 * `LEARNDASH_TCPDF_LEGACY_LD322` is deprecated since 5.3.0 and no longer defined here, so a
		 * defined one was set by the site. Certificates always render the way its default did.
		 */
		if ( defined( 'LEARNDASH_TCPDF_LEGACY_LD322' ) ) {
			_doing_it_wrong(
				'LEARNDASH_TCPDF_LEGACY_LD322',
				esc_html__( 'This constant is deprecated and no longer applied. Certificates always render the way its default value did.', 'learndash' ),
				'5.3.0'
			);
		}

		$cert_content = $cert_args['cert_post']->post_content;

		// Delete shortcode for POST2PDF Converter.
		$cert_content = preg_replace( '|\[pdf[^\]]*?\].*?\[/pdf\]|i', '', $cert_content );
		$cert_content = do_shortcode( $cert_content );

		// Convert relative image path to absolute image path.
		$cert_content = preg_replace( "/<img([^>]*?)src=['\"]((?!(http:\/\/|https:\/\/|\/))[^'\"]+?)['\"]([^>]*?)>/i", '<img$1src="' . site_url() . '/$2"$4>', $cert_content );

		// Set image align to center.
		$cert_content = preg_replace_callback( "/(<img[^>]*?class=['\"][^'\"]*?aligncenter[^'\"]*?['\"][^>]*?>)/i", 'learndash_post2pdf_conv_image_align_center', $cert_content );

		// Add width and height into image tag.
		$cert_content = preg_replace_callback( "/(<img[^>]*?src=['\"]((http:\/\/|https:\/\/|\/)[^'\"]*?(jpg|jpeg|gif|png))['\"])([^>]*?>)/i", 'learndash_post2pdf_conv_img_size', $cert_content );

		// For other source code.
		$cert_content = preg_replace( '/<pre[^>]*?><code[^>]*?>(.*?)<\/code><\/pre>/is', '<pre style="word-wrap:break-word; color: #406040; background-color: #F1F1F1; border: 1px solid #9F9F9F;">$1</pre>', $cert_content );

		// For blockquote.
		$cert_content = preg_replace( '/<blockquote[^>]*?>(.*?)<\/blockquote>/is', '<blockquote style="color: #406040;">$1</blockquote>', $cert_content );

		$cert_content = '<br/><br/>' . $cert_content;

		/**
		 * If the $font variable is not empty we use it to replace all font
		 * definitions. This only affects inline styles within the structure
		 * of the certificate content HTML elements.
		 */
		if ( ! empty( $font ) ) {
			$cert_content = preg_replace( '/(<[^>]*?font-family[^:]*?:)([^;]*?;[^>]*?>)/is', '$1' . $font . ',$2', $cert_content );
		}

		$cert_content = preg_replace( '/\n/', '<br/>', $cert_content ); // "\n" should be treated as a next line.

		/**
		 * Filters whether to include certificate CSS styles in certificate content or not.
		 *
		 * Applies only to shortcode (v1) certificates, and to block-based (v2) ones printed while the
		 * Certificate Builder is turned off.
		 *
		 * @param boolean $include_certificate_styles Whether to include certificate styles.
		 * @param int     $cert_id                   Certificate post ID.
		 */
		if ( apply_filters( 'learndash_certificate_styles', true, $cert_args['cert_id'] ) ) {
			$certificate_styles = LearnDash_Settings_Section::get_section_setting( 'LearnDash_Settings_Certificates_Styles', 'styles' );
			$certificate_styles = preg_replace( '/<style[^>]*?>(.*?)<\/style>/is', '$1', $certificate_styles );
			if ( ! empty( $certificate_styles ) ) {
				$cert_content = '<style>' . $certificate_styles . '</style>' . $cert_content;
			}
		}

		/**
		 * Filters certificate content after all processing.
		 *
		 * Applies only to shortcode (v1) certificates, and to block-based (v2) ones printed while the
		 * Certificate Builder is turned off.
		 *
		 * @since 3.2.0
		 *
		 * @param string $cert_content Certificate post content HTML/TEXT.
		 * @param int    $cert_id      Certificate post ID.
		 */
		$cert_content = apply_filters( 'learndash_certificate_content', $cert_content, $cert_args['cert_id'] );

		/**
		 * Build the PDF certificate.
		 */
		$learndash_certificate_options = get_post_meta( $cert_args['cert_post']->ID, 'learndash_certificate_options', true );
		if ( ! is_array( $learndash_certificate_options ) ) {
			$learndash_certificate_options = array( $learndash_certificate_options );
		}

		if ( ! isset( $learndash_certificate_options['pdf_page_format'] ) ) {
			$learndash_certificate_options['pdf_page_format'] = 'A4';
		}

		if ( ! isset( $learndash_certificate_options['pdf_page_orientation'] ) ) {
			$learndash_certificate_options['pdf_page_orientation'] = 'P';
		}

		// Set header data.
		if ( mb_strlen( $cert_args['cert_title'], 'UTF-8' ) < 42 ) {
			$header_title = $cert_args['cert_title'];
		} else {
			$header_title = mb_substr( $cert_args['cert_title'], 0, 42, 'UTF-8' ) . '...';
		}

		Deprecated_Hooks::prepare();

		/**
		 * Filters the value of pdf creator.
		 *
		 * Replaces `learndash_pdf_creator`, whose single-argument callbacks are migrated onto
		 * this filter. The default is the literal `LearnDash`, since TCPDF's `PDF_CREATOR`
		 * constant went with TCPDF.
		 *
		 * Applies only to shortcode (v1) certificates, and to block-based (v2) ones printed while the
		 * Certificate Builder is turned off.
		 *
		 * @since 5.3.0
		 *
		 * @param string $pdf_creator The name of the PDF creator.
		 * @param int    $cert_id     Certificate post ID.
		 */
		$pdf_creator = apply_filters( 'learndash_certificate_document_creator', 'LearnDash', $cert_args['cert_id'] );

		/**
		 * Filters the name of the pdf author.
		 *
		 * Replaces `learndash_pdf_author`, whose single-argument callbacks are migrated onto this
		 * filter.
		 *
		 * Applies only to shortcode (v1) certificates, and to block-based (v2) ones printed while the
		 * Certificate Builder is turned off.
		 *
		 * @since 5.3.0
		 *
		 * @param string $pdf_author_name PDF author name.
		 * @param int    $cert_id         Certificate post ID.
		 */
		$pdf_author = apply_filters( 'learndash_certificate_document_author', $cert_args['pdf_author_name'], $cert_args['cert_id'] );

		/**
		 * Filters the title of the pdf.
		 *
		 * Replaces `learndash_pdf_title`, whose single-argument callbacks are migrated onto this
		 * filter.
		 *
		 * Applies only to shortcode (v1) certificates, and to block-based (v2) ones printed while the
		 * Certificate Builder is turned off.
		 *
		 * @since 5.3.0
		 *
		 * @param string $pdf_title PDF title.
		 * @param int    $cert_id   Certificate post ID.
		 */
		$pdf_title = apply_filters( 'learndash_certificate_document_title', $cert_args['pdf_title'], $cert_args['cert_id'] );

		/**
		 * Filters the subject of the pdf.
		 *
		 * Replaces `learndash_pdf_subject`, whose single-argument callbacks are migrated onto this
		 * filter.
		 *
		 * Applies only to shortcode (v1) certificates, and to block-based (v2) ones printed while the
		 * Certificate Builder is turned off.
		 *
		 * @since 5.3.0
		 *
		 * @param string $pdf_subject PDF subject.
		 * @param int    $cert_id     Certificate post ID.
		 */
		$pdf_subject = apply_filters(
			'learndash_certificate_document_subject',
			wp_strip_all_tags( Cast::to_string( get_the_category_list( ',', '', $cert_args['cert_id'] ) ) ),
			$cert_args['cert_id']
		);

		/**
		 * Filters the pdf keywords.
		 *
		 * Replaces `learndash_pdf_keywords`, whose single-argument callbacks are migrated onto
		 * this filter.
		 *
		 * Applies only to shortcode (v1) certificates, and to block-based (v2) ones printed while the
		 * Certificate Builder is turned off.
		 *
		 * @since 5.3.0
		 *
		 * @param string $pdf_keywords PDF keywords.
		 * @param int    $cert_id      Certificate post ID.
		 */
		$pdf_keywords = apply_filters( 'learndash_certificate_document_keywords', $cert_args['pdf_keywords'], $cert_args['cert_id'] );

		$learndash_certificate_metadata = [
			'creator'  => Cast::to_string( $pdf_creator ),
			'author'   => Cast::to_string( $pdf_author ),
			'title'    => Cast::to_string( $pdf_title ),
			'subject'  => Cast::to_string( $pdf_subject ),
			'keywords' => Cast::to_string( $pdf_keywords ),
		];

		ob_clean();

		$learndash_certificate_renderer = new Pdf_Renderer( Cast::to_int( $cert_args['cert_id'] ) );

		try {
			$learndash_certificate_renderer->render(
				[
					'filename'    => $filename . '.pdf',
					'destination' => $destination,
					'body'        => Deprecated_Hooks::forward_content( Cast::to_string( $cert_content ), $cert_args ),
					'font'        => Cast::to_string( $font ),
					'font_size'   => Cast::to_string( $font_size ),
					'monospaced'  => Cast::to_string( $monospaced_font ),
					'ratio'       => Cast::to_float( $cert_args['ratio'] ),
					'background'  => learndash_get_thumb_path( $cert_args['cert_id'] ),
					'page'        => [
						'format'      => Cast::to_string( $learndash_certificate_options['pdf_page_format'] ),
						'orientation' => Cast::to_string( $learndash_certificate_options['pdf_page_orientation'] ),
					],
					'header'      => [
						'enabled'    => Cast::to_bool( $header_enable ),
						'title'      => $header_title,
						'subtitle'   => 'by ' . $cert_args['pdf_author_name'] . ' - ' . $cert_args['cert_permalink'],
						'logo'       => ! $logo_enable && $logo_file ? Cast::to_string( $logo_file ) : '',
						'logo_width' => Cast::to_float( $logo_width ),
					],
					'metadata'    => $learndash_certificate_metadata,
				]
			);
		} catch ( MpdfException $e ) {
			wp_die( esc_html__( 'The certificate could not be generated.', 'learndash' ) );
		}

		if ( 'F' === $destination ) {
			if ( 'F' === $destination_type ) {
				echo $filename; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			} else {
				echo $cert_args['filename_url']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
		}
	}
}
