<?php
/**
 * LearnDash Certificate Builder module main included file.
 *
 * @since 5.3.0
 *
 * @package LearnDash\Certificate_Builder
 */

// If this file is called directly, abort.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Legacy includes.

require_once plugin_dir_path( __FILE__ ) . 'src/classmap.php';
require_once plugin_dir_path( __FILE__ ) . 'src/constants.php';
require_once plugin_dir_path( __FILE__ ) . 'src/functions.php';

use LearnDash\Certificate_Builder\Plugin;
use LearnDash\Core\App;
use LearnDash_Certificate_Builder\Controller\Certificate_Builder;

/**
 * Define LearnDash LMS - Certificate Builder add-on version.
 *
 * The value is the last version the add-on shipped as a standalone plugin. The bundled copy ships with
 * LearnDash, so the number no longer tracks the code it versions.
 *
 * Still defined so third-party code that checks it to detect the add-on keeps working.
 *
 * @since 5.3.0
 * @deprecated 5.3.0 Use {@see 'LEARNDASH_SCRIPT_VERSION_TOKEN'} for asset versions and
 *             {@see 'LEARNDASH_VERSION'} for the plugin version.
 *
 * @var string $value Default is `1.1.5`.
 */
define( 'LEARNDASH_CERTIFICATE_BUILDER_VERSION', '1.1.5' );
define( 'LEARNDASH_CERTIFICATE_BUILDER_DIR', plugin_dir_path( __FILE__ ) );
define( 'LEARNDASH_CERTIFICATE_BUILDER_URL', plugins_url( '/', __FILE__ ) );
define( 'LEARNDASH_CERTIFICATE_BUILDER_FILE', __FILE__ );

add_action(
	'learndash_init',
	function () {
		learndash_register_provider( Plugin::class );

		// Instantiate the plugin.
		// The legacy way of initializing the plugin is to create an object of the Certificate_Builder class.
		// Here we get the singleton instance of the class which is registered in the App container.
		App::get( Certificate_Builder::class );
	}
);
