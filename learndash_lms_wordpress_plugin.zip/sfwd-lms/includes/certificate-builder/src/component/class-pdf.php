<?php
/**
 * This class will init the mPDF and do ser the output, though the PDF content will be
 * processed in \LearnDash_Certificate_Builder\Component\Pdf\Content_Builder.
 *
 * @file
 * @package LearnDash\Certificate_Builder
 *
 * cspell:ignore pallete -- Misspelled in a public method name, kept for backward compatibility.
 */

namespace LearnDash_Certificate_Builder\Component;

use Certificate_Builder\Traits\IO;
use LearnDash_Certificate_Builder\Component\Pdf\Pdf_Content;
use LearnDash_Certificate_Builder\Controller\Fonts_Manager;
use StellarWP\Learndash\Mpdf\Config\FontVariables;
use StellarWP\Learndash\StellarWP\Arrays\Arr;
use StellarWP\Learndash\Mpdf\HTMLParserMode;
use StellarWP\Learndash\Mpdf\Mpdf;
use StellarWP\Learndash\Mpdf\Output\Destination;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class PDF
 *
 * @package LearnDash\Certificate_Builder
 */
class PDF {
	use IO;

	/**
	 * The mPDF instance
	 *
	 * @var Mpdf
	 */
	private $mpdf;
	/**
	 * Enable debug for element border
	 *
	 * @var bool
	 */
	private $debug = false;

	/**
	 * Course ID, use in generating
	 *
	 * @var int
	 */
	private $course_id = 0;

	/**
	 * PDF init.
	 *
	 * @throws \StellarWP\Learndash\Mpdf\MpdfException Throw error if Mpdf cant not be init, should never be here.
	 *
	 * @return Mpdf|null
	 */
	public function init() {
		if ( $this->mpdf instanceof Mpdf ) {
			return $this->mpdf;
		}
		$this->mpdf = new Mpdf(
			array(
				'tempDir'       => $this->get_working_path(),
				// by default, as it will be auto override when we define custom font.
				'default_font'  => 'freeserif',
				'margin_left'   => 0,
				'margin_right'  => 0,
				'margin_top'    => 0,
				'margin_bottom' => 0,
				'debug'         => $this->debug,
				'fontdata'      => array(
					'freesans'  => array(
						'R'      => 'FreeSans.ttf',
						'B'      => 'FreeSansBold.ttf',
						'I'      => 'FreeSansOblique.ttf',
						'BI'     => 'FreeSansBoldOblique.ttf',
						'useOTL' => 0xFF,
					),
					'freeserif' => array(
						'R'          => 'FreeSerif.ttf',
						'B'          => 'FreeSerifBold.ttf',
						'I'          => 'FreeSerifItalic.ttf',
						'BI'         => 'FreeSerifBoldItalic.ttf',
						'useOTL'     => 0xFF,
						'useKashida' => 75,
					),
					'freemono'  => array(
						'R'  => 'FreeMono.ttf',
						'B'  => 'FreeMonoBold.ttf',
						'I'  => 'FreeMonoOblique.ttf',
						'BI' => 'FreeMonoBoldOblique.ttf',
					),
				),
			)
		);
		// fallback to freesans if any font corrupt.
		$this->mpdf->backupSubsFont = array( 'freesans' );
		$user_fonts                 = get_option( Fonts_Manager::OPTION_NAME, array() );
		foreach ( $user_fonts as $key => $font ) {
			foreach ( $font as $k => &$url ) {
				if ( in_array( $k, array( 'R', 'B', 'I', 'BI' ), true ) ) {
					$url                              = pathinfo( $url, PATHINFO_BASENAME );
					$this->mpdf->available_unifonts[] = $key . trim( $k, 'R' );
				} else {
					unset( $font[ $k ] );
				}
			}
			$this->mpdf->fontdata[ $key ] = $font;
		}
		$this->mpdf->default_available_fonts = $this->mpdf->available_unifonts;
		$this->mpdf->AddFontDirectory( $this->get_user_font_path() );
	}

	/**
	 * Get all the fonts that supported
	 *
	 * @return array<string, mixed>
	 */
	public function get_fonts() {
		$configs    = ( new FontVariables() )->getDefaults();
		$font_data  = $configs['fontdata'];
		$dictionary = $this->get_mpdf_fonts();
		foreach ( $font_data as $key => &$data ) {
			if ( ! isset( $dictionary[ $key ] ) ) {
				unset( $font_data[ $key ] );
				continue;
			}
			$name         = isset( $dictionary[ $key ] ) ? $dictionary[ $key ] : $key;
			$data['name'] = $name;
		}
		$user_fonts = get_option( Fonts_Manager::OPTION_NAME, array() );
		$font_data  = array_merge( $font_data, Arr::wrap( $user_fonts ) );
		// move the freeserif to top.
		$free_serif = $font_data['freeserif'];
		unset( $font_data['freeserif'] );

		return array_merge( array( 'freeserif' => $free_serif ), $font_data );
	}

	/**
	 * Output the pdf to screen
	 *
	 * @param array<string, mixed>[] $blocks    The blocks that been added.
	 * @param int                    $cert_id   Certificate ID.
	 * @param int                    $course_id Course ID.
	 *
	 * @return void
	 */
	public function serve( $blocks, $cert_id = 0, $course_id = 0 ) {
		$this->init();
		$builder                         = new Pdf_Content( $blocks, $this->mpdf );
		$builder->course_id              = $course_id;
		$builder->default_colors_palette = $this->get_default_pallete_colors();
		$builder->init_colors();
		$this->mpdf->setMBencoding( 'UTF-8' );
		$this->mpdf->usingCoreFont = false;
		$this->mpdf->onlyCoreFonts = false;
		/**
		 * Filters the mPDF instance a block-based certificate's PDF is printed with, before its blocks are written.
		 *
		 * The blocks are laid out with the instance given, so a callback should change that instance and return it, not
		 * return a new one.
		 *
		 * Applies only to block-based (v2) certificates.
		 *
		 * First shipped in the Certificate Builder add-on 1.0.1.
		 *
		 * @since 5.3.0
		 *
		 * @param Mpdf $mpdf mPDF instance.
		 *
		 * @return Mpdf mPDF instance.
		 */
		$this->mpdf                = apply_filters( 'learndash_certificate_builder_mpdf', $this->mpdf );
		$builder->build_html_structure();
		$gutenberg_style = file_get_contents( learndash_certificate_builder_path( 'src/component/pdf/style.css' ) );

		if ( false !== $gutenberg_style ) {
			$this->mpdf->WriteHTML( $gutenberg_style, HTMLParserMode::HEADER_CSS );
		}

		$this->mpdf->WriteHTML( $builder->style_builder->output(), HTMLParserMode::HEADER_CSS );
		$this->mpdf->WriteHTML( sprintf( '<div id="wrap">%s</div>', $builder->html_builder->output() ) );

		/**
		 * Filters the file name a block-based certificate's PDF is sent under.
		 *
		 * Applies only to block-based (v2) certificates.
		 *
		 * First shipped in the Certificate Builder add-on 1.0.0.
		 *
		 * @since 5.3.0
		 *
		 * @param string $pdf_name  File name, with its `.pdf` extension.
		 * @param int    $cert_id   Certificate post ID, or 0 for a preview.
		 * @param int    $course_id Course, quiz or group post ID the certificate is awarded for, or 0 for a preview.
		 *
		 * @return string File name, with its `.pdf` extension.
		 */
		$pdf_name    = apply_filters( 'learndash_certificate_builder_pdf_name', $this->build_pdf_file_name( $cert_id, $course_id ), $cert_id, $course_id );
		/**
		 * Filters how a block-based certificate's PDF is sent.
		 *
		 * Applies only to block-based (v2) certificates.
		 *
		 * First shipped in the Certificate Builder add-on 1.0.0.
		 *
		 * @since 5.3.0
		 *
		 * @param string $destination mPDF output destination: `I` to show it inline, `D` to download it or `F` to save it
		 *                            to a file. Default `I`. A destination that returns the PDF, such as `S`, sends
		 *                            nothing, since the returned PDF is not used.
		 * @param int    $cert_id     Certificate post ID, or 0 for a preview.
		 * @param int    $course_id   Course, quiz or group post ID the certificate is awarded for, or 0 for a preview.
		 *
		 * @return string mPDF output destination.
		 */
		$destination = apply_filters( 'learndash_certificate_builder_pdf_output_mode', Destination::INLINE, $cert_id, $course_id );
		$this->mpdf->Output( $pdf_name, $destination );
	}

	/**
	 * Build the file name
	 *
	 * @param int $certificate_id The certificate ID.
	 * @param int $course_id The course ID.
	 *
	 * @return string
	 */
	private function build_pdf_file_name( $certificate_id = 0, $course_id = 0 ) {
		if (
			0 !== $course_id
			&& 0 !== $certificate_id
		) {
			// we only need post title.
			$cert   = get_post( $certificate_id );
			$course = get_post( $course_id );
			$user   = wp_get_current_user();

			return sanitize_file_name( $user->user_login . ' ' . $course->post_title . ' ' . $cert->post_title . ' ' . get_bloginfo( 'name' ) ) . '.pdf';
		} else {
			return 'preview.pdf';
		}
	}

	/**
	 * The default color palette
	 *
	 * @return array<int, array<string, string>>
	 */
	public function get_default_pallete_colors() {
		return array(
			array(
				'name'  => __( 'Black', 'learndash' ),
				'slug'  => 'black',
				'color' => '#000000',
			),
			array(
				'name'  => __( 'Cyan bluish gray', 'learndash' ),
				'slug'  => 'cyan-bluish-gray',
				'color' => '#abb8c3',
			),
			array(
				'name'  => __( 'White', 'learndash' ),
				'slug'  => 'white',
				'color' => '#ffffff',
			),
			array(
				'name'  => __( 'Pale pink', 'learndash' ),
				'slug'  => 'pale-pink',
				'color' => '#f78da7',
			),
			array(
				'name'  => __( 'Vivid red', 'learndash' ),
				'slug'  => 'vivid-red',
				'color' => '#cf2e2e',
			),
			array(
				'name'  => __( 'Luminous vivid orange', 'learndash' ),
				'slug'  => 'luminous-vivid-orange',
				'color' => '#ff6900',
			),
			array(
				'name'  => __( 'Luminous vivid amber', 'learndash' ),
				'slug'  => 'luminous-vivid-amber',
				'color' => '#fcb900',
			),
			array(
				'name'  => __( 'Light green cyan', 'learndash' ),
				'slug'  => 'light-green-cyan',
				'color' => '#7bdcb5',
			),
			array(
				'name'  => __( 'Vivid green cyan', 'learndash' ),
				'slug'  => 'vivid-green-cyan',
				'color' => '#00d084',
			),
			array(
				'name'  => __( 'Pale cyan blue', 'learndash' ),
				'slug'  => 'pale-cyan-blue',
				'color' => '#8ed1fc',
			),
			array(
				'name'  => __( 'Vivid cyan blue', 'learndash' ),
				'slug'  => 'vivid-green-cyan',
				'color' => '#00d084',
			),
			array(
				'name'  => __( 'Vivid purple', 'learndash' ),
				'slug'  => 'vivid-purple',
				'color' => '#9b51e0',
			),
		);
	}

	/**
	 * Return a list of native supported fonts
	 *
	 * @return array<string, string>
	 */
	private function get_mpdf_fonts() {
		return array(
			'freeserif' => 'Free Serif',
			'freesans'  => 'Free Sans',
			'freemono'  => 'Free Mono',
		);
	}
}
