<?php
/**
 * Store and output the html.
 *
 * @file
 * @package LearnDash\Certificate_Builder
 */

namespace LearnDash_Certificate_Builder\Component\Pdf\Builder;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Html_Builder
 *
 * @package LearnDash\Certificate_Builder
 */
class Html_Builder implements Builder {
	/**
	 * Contain the html blocks
	 *
	 * @var string[]
	 */
	protected $html = array();

	/**
	 * The width of this view port
	 *
	 * @var int|float
	 */
	public $width = 0;

	/**
	 * Add the html element into the pool.
	 *
	 * @param string $element The element html.
	 *
	 * @return void
	 */
	public function add( $element ) {
		$this->html[] = $element;
	}

	/**
	 * Output the content
	 *
	 * @return string
	 */
	public function output() {
		$html = '';
		foreach ( $this->html as $line ) {
			$html .= $line . PHP_EOL;
		}

		return $html;
	}
}
