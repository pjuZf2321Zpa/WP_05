<?php
/**
 * Builder interface
 *
 * @file
 * @package LearnDash\Certificate_Builder
 */

namespace LearnDash_Certificate_Builder\Component\Pdf\Builder;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

interface Builder {
	/**
	 * Output the content
	 *
	 * @return string
	 */
	public function output();
}
