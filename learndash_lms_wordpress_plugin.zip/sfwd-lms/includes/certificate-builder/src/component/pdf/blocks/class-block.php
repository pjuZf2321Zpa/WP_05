<?php
/**
 * Abstract class, other block must extend from this.
 *
 * @file
 * @package LearnDash\Certificate_Builder
 */

namespace LearnDash_Certificate_Builder\Component\Builder\Pdf\Blocks;

use LearnDash_Certificate_Builder\Component\Pdf\Builder\Html_Builder;
use LearnDash_Certificate_Builder\Component\Pdf\Builder\Style_Builder;
use LearnDash_Certificate_Builder\Component\Pdf\Pdf_Content;
use WP_HTML_Processor;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Block
 *
 * @package LearnDash\Certificate_Builder
 */
abstract class Block {
	/**
	 * The class that calling it
	 *
	 * @var Pdf_Content
	 */
	public $caller;

	/**
	 * The style builder class.
	 *
	 * @var Style_Builder
	 */
	public $style;

	/**
	 * /**
	 * The Html builder class
	 *
	 * @var Html_Builder
	 */
	public $html;

	/**
	 * The root block
	 *
	 * @var array{id: string, blockName: string, attrs: array<string, mixed>, innerBlocks: array<string, mixed>[], innerHTML: string, innerContent: mixed[]}
	 */
	public $block;

	/**
	 * A flag to know if this element is inside a column, mostly for deal with margin bottom issue.
	 *
	 * @var bool
	 */
	public $is_nested = false;

	/**
	 * Block constructor.
	 *
	 * @param array{id: string, blockName: string, attrs: array<string, mixed>, innerBlocks: array<string, mixed>[], innerHTML: string, innerContent: mixed[]} $block  The root block.
	 * @param Style_Builder                                                                                                                                    $style  The style builder class.
	 * @param Html_Builder                                                                                                                                     $html   The html builder class.
	 * @param Pdf_Content                                                                                                                                      $caller The caller class, we use this for accessing to parent data.
	 */
	public function __construct( array $block, Style_Builder $style, Html_Builder $html, Pdf_Content $caller ) {
		$this->block  = $block;
		$this->html   = $html;
		$this->style  = $style;
		$this->caller = $caller;
		$this->fix_id();
	}

	/**
	 * Trigger code
	 *
	 * @return void
	 */
	abstract public function run();

	/**
	 * Append the id into innerHtml
	 *
	 * @return void
	 */
	protected function fix_id() {
		if ( empty( $this->block['innerHTML'] ) ) {
			return;
		}

		$this->block['innerHTML'] = $this->tag_wrapper( $this->block['innerHTML'] );

		// A block holding inner blocks is rebuilt from innerContent, which carries its own copy of the wrapper.
		if (
			isset( $this->block['innerContent'][0] )
			&& is_string( $this->block['innerContent'][0] )
		) {
			$this->block['innerContent'][0] = $this->tag_wrapper( $this->block['innerContent'][0] );
		}
	}

	/**
	 * Mark the block's wrapper element with the block id and the builder's class.
	 *
	 * @since 5.3.0
	 *
	 * @param string $html The block markup.
	 *
	 * @return string The markup unchanged when it wraps no element.
	 */
	protected function tag_wrapper( string $html ): string {
		$processor = WP_HTML_Processor::create_fragment( $html );

		if ( ! $processor instanceof WP_HTML_Processor ) {
			return $html;
		}

		// Gutenberg writes the wrapper last at the top level, below the fragment's own HTML and BODY.
		$found = false;

		while ( $processor->next_tag() ) {
			if ( 3 === count( $processor->get_breadcrumbs() ) ) {
				$processor->set_bookmark( 'wrapper' );
				$found = true;
			}
		}

		if (
			! $found
			|| ! $processor->seek( 'wrapper' )
		) {
			return $html;
		}

		$processor->set_attribute( 'id', $this->block['id'] );
		$processor->add_class( 'cb-block' );

		return $processor->get_updated_html();
	}
}
