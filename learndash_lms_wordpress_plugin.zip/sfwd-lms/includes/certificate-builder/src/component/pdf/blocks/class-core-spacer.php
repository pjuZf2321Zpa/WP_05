<?php
/**
 * Process the Spacer block.
 *
 * @file
 * @package LearnDash\Certificate_Builder
 */

namespace LearnDash_Certificate_Builder\Component\Builder\Pdf\Blocks;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Process the Spacer block.
 *
 * Class Core_Spacer
 *
 * @package LearnDash\Certificate_Builder
 */
class Core_Spacer extends Block {
	/**
	 * Trigger function
	 *
	 * @return void
	 */
	public function run() {
		$this->html->add( $this->block['innerHTML'] );
	}
}
