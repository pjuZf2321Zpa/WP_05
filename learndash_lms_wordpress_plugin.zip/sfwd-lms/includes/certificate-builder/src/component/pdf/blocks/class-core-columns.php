<?php
/**
 * Process the columns block.
 *
 * @file
 * @package LearnDash\Certificate_Builder
 */

namespace LearnDash_Certificate_Builder\Component\Builder\Pdf\Blocks;

use LearnDash\Core\Utilities\Cast;
use LearnDash_Certificate_Builder\Component\Pdf\Builder\Html_Builder;
use StellarWP\Learndash\StellarWP\Arrays\Arr;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Core_Columns
 *
 * @package LearnDash\Certificate_Builder
 */
class Core_Columns extends Block {
	/**
	 * Trigger
	 *
	 * @return void
	 */
	public function run() {
		$inner_html = '';
		$convert    = 3.7795275591;
		$padding    = 32;
		if (
			isset( $this->block['attrs']['backgroundColor'] )
			|| null !== Arr::get( $this->block['attrs'], array( 'style', 'color', 'gradient' ) )
		) {
			// going to add a padding.
			$this->style->add( $this->block['id'], 'padding-top', '1rem' );
			if ( $this->is_nested ) {
				$this->style->add( $this->block['id'], 'margin-bottom', '0' );
			}
			$this->style->add( $this->block['id'], 'padding-bottom', '1rem' );
			$this->style->add( $this->block['id'], 'padding-left', '40px' );
			$padding += 40;
		}
		// the pdf width.
		$is_nested = false;
		if ( 0 === $this->html->width ) {
			$w = absint( $this->caller->mpdf->w * $convert );
		} else {
			$w         = $this->html->width;
			$is_nested = true;
		}
		foreach ( $this->block['innerBlocks'] as $key => $column ) {
			$html_builder = new Html_Builder();
			$column_id    = Cast::to_string( Arr::get( $column, 'id', '' ) );
			$width        = Arr::get( $column, array( 'attrs', 'width' ), round( 100 / count( $this->block['innerBlocks'] ) ) . '%' );
			if ( false === $is_nested ) {
				$width = ( ( $w * ( $this->caller->container_width / 100 ) ) - ( $padding * ( count( $this->block['innerBlocks'] ) - 1 ) ) ) * ( absint( Cast::to_int( $width ) ) / 100 );
			} else {
				// this is use in nested.
				$width = ( $w - ( $padding * ( count( $this->block['innerBlocks'] ) - 1 ) ) ) * ( absint( Cast::to_int( $width ) ) / 100 );
			}
			$html_builder->width = $width;
			$this->style->add( $column_id, 'width', Cast::to_string( absint( $width ) ) );
			$this->style->add( $column_id, 'float', 'left' );
			if ( $key > 0 ) {
				$this->style->add( $column_id, 'margin-left', '31px' );
			}

			if ( count( Arr::wrap( Arr::get( $column, 'innerBlocks', array() ) ) ) ) {
				$this->caller->build_html_structure( $this->style, $html_builder, $column );
				$inner_html .= '<div id="' . $column_id . '">' . $html_builder->output() . '</div>';
			} else {
				$inner_html .= '<div id="' . $column_id . '"><div style="height:1px;"></div></div>';
			}
		}
		// innerContent holds the wrapper split around a null per inner block, so the strings either side are its tags.
		$chunks = array_values( array_filter( $this->block['innerContent'], 'is_string' ) );
		$open   = (string) array_shift( $chunks );
		$close  = (string) array_pop( $chunks );

		$this->html->add( $open . $inner_html . $close );
	}
}
