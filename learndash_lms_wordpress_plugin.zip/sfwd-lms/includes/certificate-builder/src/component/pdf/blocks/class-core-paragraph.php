<?php
/**
 * Process the paragraph block.
 *
 * @file
 * @package LearnDash\Certificate_Builder
 */

namespace LearnDash_Certificate_Builder\Component\Builder\Pdf\Blocks;

use StellarWP\Learndash\StellarWP\Arrays\Arr;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Core_Paragraph
 *
 * @package LearnDash\Certificate_Builder
 */
class Core_Paragraph extends Core_Heading {
	/**
	 * Loop through the attributes and building css.
	 *
	 * @param array<string, mixed> $attrs The block attributes.
	 *
	 * @return void
	 */
	protected function parse_css( $attrs ) {
		parent::parse_css( $attrs );

		if ( null === Arr::get( $this->block['attrs'], array( 'style', 'typography', 'lineHeight' ) ) ) {
			$this->style->add( $this->block['id'], 'line-height', '1.4' );
		}
	}
}
