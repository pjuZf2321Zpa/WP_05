<?php
/**
 * Process the Ld_groupinfo block
 *
 * @file
 * @package LearnDash\Certificate_Builder
 */

namespace LearnDash_Certificate_Builder\Component\Builder\Pdf\Blocks;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Learndash_Ld_Courseinfo
 *
 * @package LearnDash\Certificate_Builder
 */
class Learndash_Ld_Groupinfo extends Learndash_Ld_Usermeta {
	/**
	 * Trigger
	 *
	 * @return void
	 */
	public function run() {
		$block = new \WP_Block( $this->block );
		$el    = sprintf( '<div id="%s">' . $block->render() . '</div>', $this->block['id'] );
		$this->html->add( $el );
		$this->build_style();
	}
}
