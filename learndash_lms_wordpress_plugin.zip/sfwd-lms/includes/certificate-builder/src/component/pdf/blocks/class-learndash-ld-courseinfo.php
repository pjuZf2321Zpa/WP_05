<?php
/**
 * Process the Ld_usermeta block
 *
 * @file
 * @package LearnDash\Certificate_Builder
 */

namespace LearnDash_Certificate_Builder\Component\Builder\Pdf\Blocks;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Learndash_Ld_Courseinfo
 *
 * @package LearnDash\Certificate_Builder
 */
class Learndash_Ld_Courseinfo extends Learndash_Ld_Usermeta {
	/**
	 * Trigger
	 *
	 * @return void
	 */
	public function run() {
		if (
			! isset( $this->block['attrs']['course_id'] )
			|| empty( $this->block['attrs']['course_id'] )
		) {
			// need to convert into string or it will be empty.
			$this->block['attrs']['course_id'] = "{$this->caller->course_id}";
		}
		$block = new \WP_Block( $this->block );
		$el    = sprintf( '<div id="%s">' . $block->render() . '</div>', $this->block['id'] );
		$this->html->add( $el );
		$this->build_style();
	}
}
