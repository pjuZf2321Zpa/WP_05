<?php
/**
 * Process the heading block.
 *
 * @file
 * @package LearnDash\Certificate_Builder
 */

namespace LearnDash_Certificate_Builder\Component\Builder\Pdf\Blocks;

use LearnDash\Core\Utilities\Cast;
use StellarWP\Learndash\StellarWP\Arrays\Arr;
use WP_HTML_Tag_Processor;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Core_Heading
 *
 * @package LearnDash\Certificate_Builder
 */
class Core_Heading extends Block {
	/**
	 * Trigger
	 *
	 * @return void
	 */
	public function run() {
		$html = do_shortcode( $this->block['innerHTML'] ?? '' );

		// Hold the heading on one line. Only text is rewritten, so spaces separating attributes survive.
		$processor = new WP_HTML_Tag_Processor( $html );

		while ( $processor->next_token() ) {
			if ( '#text' !== $processor->get_token_type() ) {
				continue;
			}

			$processor->set_modifiable_text( str_replace( ' ', "\xc2\xa0", $processor->get_modifiable_text() ) );
		}

		$html = $processor->get_updated_html();

		$this->style->add( $this->block['id'], 'position', 'relative' );
		$this->parse_css( $this->block['attrs'] );
		$this->html->add( $html );
	}

	/**
	 * Loop through the attributes and building css.
	 *
	 * @param array<string, mixed> $attrs The block attributes.
	 *
	 * @return void
	 */
	protected function parse_css( $attrs ) {
		if ( isset( $attrs['fontSize'] ) ) {
			switch ( $attrs['fontSize'] ) {
				case 'small':
					$this->style->add( $this->block['id'], 'font-size', '18px' );
					break;
				case 'extra-small':
					$this->style->add( $this->block['id'], 'font-size', '16px' );
					break;
				case 'normal':
					$this->style->add( $this->block['id'], 'font-size', '20px' );
					break;
				case 'large':
					$this->style->add( $this->block['id'], 'font-size', '24px' );
					break;
				case 'extra-large':
					$this->style->add( $this->block['id'], 'font-size', '40px' );
					break;
				case 'huge':
					$this->style->add( $this->block['id'], 'font-size', '96px' );
					break;
				case 'gigantic':
					$this->style->add( $this->block['id'], 'font-size', '122px' );
					break;
			}
		}
		if ( isset( $attrs['textAlign'] ) ) {
			$this->style->add( $this->block['id'], 'text-align', Cast::to_string( $attrs['textAlign'] ) );
		}
		if ( isset( $attrs['textColor'] ) ) {
			if ( strpos( Cast::to_string( $attrs['textColor'] ), '#' ) === 0 ) {
				$this->style->add( $this->block['id'], 'color', Cast::to_string( $attrs['textColor'] ) );
			}
		}
		if ( isset( $attrs['backgroundColor'] ) ) {
			if ( strpos( Cast::to_string( $attrs['textColor'] ), '#' ) === 0 ) {
				$this->style->add( $this->block['id'], 'background-color', Cast::to_string( $attrs['backgroundColor'] ) );
			}
		}
		if (
			isset( $attrs['useFont'] )
			&& true === $attrs['useFont']
		) {
			$font = Cast::to_string( $attrs['font'] );
			$this->style->add( $this->block['id'], 'font-family', "'$font'" );
		}

		if ( null === Arr::get( $attrs, array( 'style', 'typography', 'lineHeight' ) ) ) {
			$this->style->add( $this->block['id'], 'line-height', '1.4' );
		}
	}

	/**
	 * From color to hex code
	 *
	 * @param string $color The color.
	 *
	 * @return string|null
	 */
	public function color_palette( $color ) {
		$colors = array(
			'accent'            => '#cd2653',
			'primary'           => '#000',
			'secondary'         => '#6d6d6d',
			'subtle-background' => '#dcd7ca',
			'background'        => '#f5efe0',
			'dark-gray'         => '#28303d',
			'green'             => '#d1e4dd',
			'gray'              => '#39414d',
			'blue'              => '#d1dfe4',
			'purple'            => '#d1d1e4',
			'red'               => '#e4d1d1',
			'orange'            => '#e4dad1',
			'yellow'            => '#eeeadd',
		);
		if ( isset( $colors[ $color ] ) ) {
			return $colors[ $color ];
		}

		return null;
	}
}
