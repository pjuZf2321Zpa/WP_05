<?php
/**
 * The default class for processing normal block
 *
 * @file
 * @package LearnDash\Certificate_Builder
 */

namespace LearnDash_Certificate_Builder\Component\Builder\Pdf\Blocks;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Fallback
 *
 * @package LearnDash\Certificate_Builder
 */
class Fallback extends Block {
	/**
	 * Trigger code
	 *
	 * @return void
	 */
	public function run() {
		/**
		 * Filters the fallback output of a Block within the Certificate Builder.
		 *
		 * Applies only to block-based (v2) certificates.
		 *
		 * @since 5.3.0
		 *
		 * @param string                                                                                                                               $output The output for the current Block.
		 * @param array{id: string, blockName: string, attrs: array<string, mixed>, innerBlocks: array<string, mixed>[], innerHTML: string, innerContent: mixed[]} $block  The current Block.
		 *
		 * @return string
		 */
		$output = apply_filters(
			'learndash_certificate_builder_block_fallback',
			do_shortcode( trim( $this->block['innerHTML'] ?? '' ) ),
			$this->block
		);

		$this->html->add( $output );
	}
}
