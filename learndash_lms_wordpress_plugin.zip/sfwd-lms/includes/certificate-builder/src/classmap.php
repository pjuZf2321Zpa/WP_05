<?php
/**
 * This contains all the classes we use
 *
 * @file
 * @package LearnDash\Certificate_Builder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// class map, use for autoload.

$learndash_certificate_builder_dir = dirname( __DIR__ );

$learndash_certificate_builder_class_map = array(
	'Certificate_Builder\\Traits\\IO'                     => $learndash_certificate_builder_dir . '/src/traits/io.php',
	'LearnDash_Certificate_Builder\\Bootstrap'            => $learndash_certificate_builder_dir . '/src/deprecated/class-bootstrap.php',
	'LearnDash_Certificate_Builder\\Component\\Builder\\Pdf\\Blocks\\Block' => $learndash_certificate_builder_dir . '/src/component/pdf/blocks/class-block.php',
	'LearnDash_Certificate_Builder\\Component\\Builder\\Pdf\\Blocks\\Core_Columns' => $learndash_certificate_builder_dir . '/src/component/pdf/blocks/class-core-columns.php',
	'LearnDash_Certificate_Builder\\Component\\Builder\\Pdf\\Blocks\\Core_Heading' => $learndash_certificate_builder_dir . '/src/component/pdf/blocks/class-core-heading.php',
	'LearnDash_Certificate_Builder\\Component\\Builder\\Pdf\\Blocks\\Core_Paragraph' => $learndash_certificate_builder_dir . '/src/component/pdf/blocks/class-core-paragraph.php',
	'LearnDash_Certificate_Builder\\Component\\Builder\\Pdf\\Blocks\\Core_Spacer' => $learndash_certificate_builder_dir . '/src/component/pdf/blocks/class-core-spacer.php',
	'LearnDash_Certificate_Builder\\Component\\Builder\\Pdf\\Blocks\\Fallback' => $learndash_certificate_builder_dir . '/src/component/pdf/blocks/class-fallback.php',
	'LearnDash_Certificate_Builder\\Component\\Builder\\Pdf\\Blocks\\Learndash_Ld_Quizinfo' => $learndash_certificate_builder_dir . '/src/component/pdf/blocks/class-learndash-ld-quizinfo.php',
	'LearnDash_Certificate_Builder\\Component\\Builder\\Pdf\\Blocks\\Learndash_Ld_Courseinfo' => $learndash_certificate_builder_dir . '/src/component/pdf/blocks/class-learndash-ld-courseinfo.php',
	'LearnDash_Certificate_Builder\\Component\\Builder\\Pdf\\Blocks\\Learndash_Ld_Groupinfo' => $learndash_certificate_builder_dir . '/src/component/pdf/blocks/class-learndash-ld-groupinfo.php',
	'LearnDash_Certificate_Builder\\Component\\Builder\\Pdf\\Blocks\\Learndash_Ld_Usermeta' => $learndash_certificate_builder_dir . '/src/component/pdf/blocks/class-learndash-ld-usermeta.php',
	'LearnDash_Certificate_Builder\\Component\\PDF'       => $learndash_certificate_builder_dir . '/src/component/class-pdf.php',
	'LearnDash_Certificate_Builder\\Component\\Pdf\\Builder\\Builder' => $learndash_certificate_builder_dir . '/src/component/pdf/builder/builder.php',
	'LearnDash_Certificate_Builder\\Component\\Pdf\\Builder\\Html_Builder' => $learndash_certificate_builder_dir . '/src/component/pdf/builder/class-html-builder.php',
	'LearnDash_Certificate_Builder\\Component\\Pdf\\Builder\\Style_Builder' => $learndash_certificate_builder_dir . '/src/component/pdf/builder/class-style-builder.php',
	'LearnDash_Certificate_Builder\\Component\\Pdf\\Pdf_Content' => $learndash_certificate_builder_dir . '/src/component/pdf/class-pdf-content.php',
	'LearnDash_Certificate_Builder\\Controller\\Certificate_Builder' => $learndash_certificate_builder_dir . '/src/controller/class-certificate-builder.php',
	'LearnDash_Certificate_Builder\\Controller\\Fonts_Manager' => $learndash_certificate_builder_dir . '/src/controller/class-fonts-manager.php',
	'LearnDash_Certificate_Builder\\Controller\\Switcher' => $learndash_certificate_builder_dir . '/src/controller/class-switcher.php',
);


spl_autoload_register(
	function ( $class ) use ( $learndash_certificate_builder_class_map ) {
		if ( isset( $learndash_certificate_builder_class_map[ $class ] ) ) {
			require_once $learndash_certificate_builder_class_map[ $class ];
		}
	}
);
