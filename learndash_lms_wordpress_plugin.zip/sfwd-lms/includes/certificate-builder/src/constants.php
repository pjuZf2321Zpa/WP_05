<?php
/**
 * Constant settings for the PDF, some will be replace later with gutenberg block settings
 *
 * @package LearnDash\Certificate_Builder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The container that we display elements inside, this will be use in both the PDF and Editor.
 */
if ( ! defined( 'LD_CERTIFICATE_BUILDER_BLOCK_MARGIN_BOTTOM' ) ) {
	define( 'LD_CERTIFICATE_BUILDER_BLOCK_MARGIN_BOTTOM', '1.75rem' ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedConstantFound -- Legacy code.
}
