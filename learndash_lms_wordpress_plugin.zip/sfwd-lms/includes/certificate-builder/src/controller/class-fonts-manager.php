<?php
/**
 * Add a font manager to LearnDash->Certificate for managing custom fonts
 *
 * @file
 * @package LearnDash\Certificate_Builder
 */

namespace LearnDash_Certificate_Builder\Controller;

use Certificate_Builder\Traits\IO;
use LearnDash\Core\App;
use LearnDash\Core\Modules\Certificates\V3\Assets\Asset_Exception;
use LearnDash\Core\Modules\Certificates\V3\Assets\Font_Usage;
use LearnDash\Core\Utilities\Cast;
use StellarWP\Learndash\Mpdf\Cache;
use StellarWP\Learndash\Mpdf\Fonts\FontCache;
use StellarWP\Learndash\Mpdf\MpdfException;
use StellarWP\Learndash\Mpdf\TTFontFileAnalysis;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Fonts_Manager
 *
 * @package LearnDash\Certificate_Builder
 */
class Fonts_Manager extends \LearnDash_Settings_Page {
	use IO;

	const OPTION_NAME = 'learndash_certificate_builder_fonts'; // phpcs:ignore LearnDash.Classes.DisallowNonPrivateConst.ImplicitPublicConst -- Legacy code.
	/**
	 * Validation errors
	 *
	 * @var string[]
	 */
	private $errors = array();

	/**
	 * The removal of a font in use that was posted without a confirmation, shown as a notice on the page.
	 *
	 * The usage is null when it could not be read.
	 *
	 * @since 5.3.0
	 *
	 * @var array{key: string, usage: array{templates: array<int, array{id: int, title: string, status: string}>, issued: int}|null}|null
	 */
	private $unconfirmed_removal = null;

	/**
	 * Public constructor for class
	 */
	public function __construct() {
		$this->parent_menu_page_url  = 'edit.php?post_type=sfwd-certificates';
		$this->menu_page_capability  = LEARNDASH_ADMIN_CAPABILITY_CHECK;
		$this->settings_page_id      = 'learndash-lms-certificate-fonts-manager';
		$this->settings_page_title   = esc_html__( 'Fonts', 'learndash' );
		$this->settings_tab_priority = 40;
		parent::__construct();
		add_action( 'wp_loaded', array( $this, 'process_font_uploader' ) );
		add_action( 'wp_loaded', array( $this, 'process_font_remove' ) );
	}

	/**
	 * Removes a font posted from the Fonts screen.
	 *
	 * A font that a certificate or an issued certificate uses, or whose usage cannot be read, is removed only when the
	 * removal was confirmed. Otherwise the font is kept, and the page shows a notice that names its usage and can confirm
	 * the removal.
	 *
	 * @since 5.3.0
	 *
	 * @return void
	 */
	public function process_font_remove() {
		$post = wp_unslash( $_POST );
		if (
			! isset( $post['learndash_certificate_builder_font_remove'] )
			|| ! is_user_logged_in()
			|| ! current_user_can( 'manage_options' )
		) {
			return;
		}

		if (
			! isset( $post['_wpnonce'] )
			|| ! wp_verify_nonce( $post['_wpnonce'], 'learndash_certificate_builder_remove_font' )
		) {
			return;
		}

		$key   = Cast::to_string( $post['learndash_certificate_builder_font_remove'] );
		$fonts = $this->get_user_fonts();

		if ( ! isset( $fonts[ $key ] ) ) {
			return;
		}

		// Only 1 confirms. The Remove form posts the field empty until its dialog sets it.
		if ( '1' !== Cast::to_string( $post['learndash_certificate_builder_font_remove_confirmed'] ?? '' ) ) {
			$usage = $this->get_font_usage( array( $key ) );

			// The usage has no entry for an empty key, which no certificate can name, so that font is not in use.
			if (
				null === $usage
				|| (
					isset( $usage[ $key ] )
					&& App::get( Font_Usage::class )->is_in_use( $usage[ $key ] )
				)
			) {
				$this->unconfirmed_removal = array(
					'key'   => $key,
					'usage' => null === $usage ? null : $usage[ $key ],
				);

				return;
			}
		}

		$this->remove_font( $key );

		wp_safe_redirect( admin_url( 'admin.php?page=learndash-lms-certificate-fonts-manager' ) );
		exit;
	}

	/**
	 * Removes an uploaded font and deletes its font files.
	 *
	 * Removes the font whether or not a certificate uses it, and asks for no confirmation.
	 *
	 * @since 5.3.0
	 *
	 * @param string $key Font key, as the font list stores it.
	 *
	 * @return bool Whether a font was removed. False when no font is stored under the key, or the font list could not be
	 *              written, in which case no file is deleted.
	 */
	public function remove_font( string $key ): bool {
		$fonts = $this->get_user_fonts();

		if ( ! isset( $fonts[ $key ] ) ) {
			return false;
		}

		$font = $fonts[ $key ];

		unset( $fonts[ $key ] );

		// The list is written first, so a failed write never leaves it naming files that were deleted.
		if ( ! update_option( self::OPTION_NAME, $fonts ) ) {
			return false;
		}

		foreach ( array( 'R', 'B', 'I', 'BI' ) as $face ) {
			$file = $this->font_file_name( $font[ $face ] ?? null );

			if ( '' === $file ) {
				continue;
			}

			$path = $this->get_user_font_path() . DIRECTORY_SEPARATOR . $file;

			if ( is_file( $path ) ) {
				wp_delete_file( $path );
			}
		}

		return true;
	}

	/**
	 * Handle the fonts uploading
	 *
	 * @since 5.3.0
	 *
	 * @throws MpdfException Catch when font is not valid.
	 *
	 * @return void
	 */
	public function process_font_uploader() {
		$post = wp_unslash( $_POST );
		// check the condition.
		if (
			! isset( $post['learndash_certificate_builder_font_upload'] )
			|| ! is_user_logged_in()
			|| ! current_user_can( 'manage_options' )
		) {
			return;
		}
		if (
			! isset( $post['_wpnonce'] )
			|| ! wp_verify_nonce( $post['_wpnonce'], 'learndash_certificate_builder_upload_font' )
		) {
			return;
		}

		$files = $_FILES;

		// validate.
		$label       = isset( $post['label'] ) ? sanitize_text_field( $post['label'] ) : null;
		$regular     = isset( $files['regular'] ) ? $files['regular'] : array();
		$bold        = isset( $files['bold'] ) ? $files['bold'] : array();
		$italic      = isset( $files['italic'] ) ? $files['italic'] : array();
		$bold_italic = isset( $files['bold_italic'] ) ? $files['bold_italic'] : array();
		if (
			! isset( $regular['name'] )
			|| empty( $regular['name'] )
		) {
			$this->errors[] = __( 'The Regular font is required', 'learndash' );

			return;
		}

		// now extract the family info and validate regular file.
		$ret = $this->is_file_as_font( $regular['tmp_name'] );
		if ( $ret instanceof \Exception ) {
			$this->errors[] = $ret->getMessage();

			return;
		}
		if ( empty( $label ) ) {
			$label = Cast::to_string( $ret[0] );
		}

		$family_name = $this->font_key( Cast::to_string( $ret[0] ) );
		// starting upload.
		// init the user font folder before start upload, as the hook can be nested.
		$this->get_user_font_path();
		foreach (
				array(
					'R'  => $regular,
					'B'  => $bold,
					'I'  => $italic,
					'BI' => $bold_italic,
				) as $key => $font
		) {
			if (
				! isset( $font['name'] )
				|| empty( $font['name'] )
			) {
				continue;
			}
			$ret = $this->is_file_as_font( $font['tmp_name'] );
			if ( $ret instanceof \Exception ) {
				$this->errors[] = $ret->getMessage();

				return;
			}
			add_filter( 'upload_dir', array( $this, 'correct_upload_path' ) );
			if ( ! function_exists( 'wp_handle_upload' ) ) {
				require_once ABSPATH . 'wp-admin' . DIRECTORY_SEPARATOR . 'includes' . DIRECTORY_SEPARATOR . 'file.php';
			}
			$result = wp_handle_upload(
				$font,
				array(
					'test_form' => false,
					'test_type' => false,
				)
			);
			if ( isset( $result['file'] ) ) {
				// done, update the family.
				$this->save_font( $label, $family_name, $key, $result['url'] );
			}
			remove_filter( 'upload_dir', array( $this, 'correct_upload_path' ) );
		}
		wp_safe_redirect( admin_url( 'admin.php?page=learndash-lms-certificate-fonts-manager' ) );
		exit;
	}

	/**
	 * Filters the uploads directory data.
	 *
	 * @param array<string, mixed> $uploads Array of information about the upload directory.
	 *
	 * @return array<string, mixed>
	 */
	public function correct_upload_path( $uploads ) {
		$rev_dir           = '/learndash-certificate-builder/user_fonts';
		$uploads['path']   = $uploads['basedir'] . $rev_dir;
		$uploads['url']    = $uploads['baseurl'] . $rev_dir;
		$uploads['subdir'] = $rev_dir;

		return $uploads;
	}

	/**
	 * Validate the upload file
	 *
	 * @param string $path Font file.
	 *
	 * @return array<int|string, mixed>|\Exception
	 * @throws MpdfException Catch when the font is not valid format.
	 */
	private function is_file_as_font( $path ) {
		$cache      = new Cache( $this->get_working_path() );
		$font_cache = new FontCache( $cache );
		$ttfont     = new TTFontFileAnalysis( $font_cache, '' );
		try {
			return $ttfont->extractCoreInfo( $path );
		} catch ( \Exception $e ) {
			return $e;
		}
	}

	/**
	 * Custom function to show settings page output
	 *
	 * @since 5.3.0
	 *
	 * @return void
	 */
	public function show_settings_page() {
		$fonts       = $this->get_user_fonts();
		$usage       = empty( $fonts ) ? array() : $this->get_font_usage( array_map( 'strval', array_keys( $fonts ) ) );
		$unconfirmed = $this->unconfirmed_removal;
		?>
		<div id="certificate-builder-fonts-manager" class="wrap">
			<?php if ( null !== $unconfirmed ) : ?>
				<div class="notice notice-warning">
					<p>
						<?php
						echo esc_html(
							null === $unconfirmed['usage']
								? sprintf(
									// translators: %s: Font name.
									__( 'The font "%s" was not removed. It could not be checked whether certificates use it.', 'learndash' ),
									$this->font_label( $unconfirmed['key'] )
								)
								: sprintf(
									// translators: %s: Font name.
									__( 'The font "%s" was not removed because certificates use it. After it is removed, their text in this font prints in Free Serif.', 'learndash' ),
									$this->font_label( $unconfirmed['key'] )
								)
						);
						?>
					</p>
					<?php if ( null !== $unconfirmed['usage'] ) : ?>
						<p><?php $this->render_font_usage( $unconfirmed['usage'] ); ?></p>
					<?php endif; ?>
					<form method="post">
						<input type="hidden" name="learndash_certificate_builder_font_remove" value="<?php echo esc_attr( $unconfirmed['key'] ); ?>">
						<input type="hidden" name="learndash_certificate_builder_font_remove_confirmed" value="1">
						<?php wp_nonce_field( 'learndash_certificate_builder_remove_font' ); ?>
						<p>
							<button type="submit" class="button">
								<?php esc_html_e( 'Remove anyway', 'learndash' ); ?>
							</button>
						</p>
					</form>
				</div>
			<?php endif; ?>
			<div class="font-uploader">
				<?php if ( ! empty( $this->errors ) ) : ?>
					<div class="notice notice-error settings-error">
						<p><?php echo esc_html( implode( PHP_EOL, $this->errors ) ); ?></p>
					</div>
				<?php endif; ?>
				<form method="post" enctype="multipart/form-data">
					<?php wp_nonce_field( 'learndash_certificate_builder_upload_font' ); ?>
					<input type="hidden" name="learndash_certificate_builder_font_upload" value="1"/>
					<table class="form-table">
						<tbody>
						<tr>
							<th scope="row">
								<label for="label"><?php esc_html_e( 'Label', 'learndash' ); ?></label>
							</th>
							<td>
								<input name="label" type="text" id="label" class="regular-text">
							</td>
						</tr>
						<tr>
							<th scope="row">
								<label for="regular"><?php esc_html_e( 'Regular (*)', 'learndash' ); ?></label>
							</th>
							<td>
								<input name="regular" type="file" id="regular">
							</td>
						</tr>
						<tr>
							<th scope="row">
								<label for="bold"><?php esc_html_e( 'Bold', 'learndash' ); ?></label>
							</th>
							<td>
								<input name="bold" type="file" id="bold">
							</td>
						</tr>
						<tr>
							<th scope="row">
								<label for="italic"><?php esc_html_e( 'Italic', 'learndash' ); ?></label>
							</th>
							<td>
								<input name="italic" type="file" id="italic">
							</td>
						</tr>
						<tr>
							<th scope="row">
								<label for="bold_italic"><?php esc_html_e( 'Bold Italic', 'learndash' ); ?></label>
							</th>
							<td>
								<input name="bold_italic" type="file" id="bold_italic">
							</td>
						</tr>
						</tbody>
					</table>
					<p class="submit">
						<input type="submit" name="submit" id="submit" class="button button-primary" value="Save Changes">
					</p>
				</form>
			</div>
			<?php if ( ! empty( $fonts ) ) : ?>
				<table class="wp-list-table widefat fixed striped table-view-list">
					<thead>
					<tr>
						<th><?php esc_html_e( 'Label', 'learndash' ); ?></th>
						<th><?php esc_html_e( 'Regular', 'learndash' ); ?></th>
						<th><?php esc_html_e( 'Bold', 'learndash' ); ?></th>
						<th><?php esc_html_e( 'Italic', 'learndash' ); ?></th>
						<th><?php esc_html_e( 'Bold Italic', 'learndash' ); ?></th>
						<th><?php esc_html_e( 'Used by', 'learndash' ); ?></th>
					</tr>
					</thead>
					<tbody>
					<?php foreach ( $fonts as $key => $font ) : ?>
						<tr>
							<td>
								<div><?php echo esc_html( Cast::to_string( $font['name'] ) ); ?></div>
								<form
									method="post"
									id="frm_<?php echo esc_attr( Cast::to_string( $key ) ); ?>"
									class="learndash-certificate-builder-font-remove"
									data-learndash-font-usage="<?php echo esc_attr( (string) wp_json_encode( $this->font_usage_data( Cast::to_string( $key ), $usage ) ) ); ?>"
								>
									<input type="hidden" name="learndash_certificate_builder_font_remove" value="<?php echo esc_attr( Cast::to_string( $key ) ); ?>">
									<input type="hidden" name="learndash_certificate_builder_font_remove_confirmed" value="">
									<?php wp_nonce_field( 'learndash_certificate_builder_remove_font' ); ?>
									<button type="submit" class="button-link button-link-delete">
										<?php esc_html_e( 'Remove', 'learndash' ); ?>
									</button>
								</form>
							</td>
							<td><?php echo esc_html( pathinfo( Cast::to_string( $font['R'] ), PATHINFO_BASENAME ) ); ?></td>
							<td><?php echo isset( $font['B'] ) ? esc_html( pathinfo( Cast::to_string( $font['B'] ), PATHINFO_BASENAME ) ) : null; ?></td>
							<td><?php echo isset( $font['I'] ) ? esc_html( pathinfo( Cast::to_string( $font['I'] ), PATHINFO_BASENAME ) ) : null; ?></td>
							<td><?php echo isset( $font['BI'] ) ? esc_html( pathinfo( Cast::to_string( $font['BI'] ), PATHINFO_BASENAME ) ) : null; ?></td>
							<td>
								<?php
								if ( null === $usage ) {
									esc_html_e( 'It could not be checked whether certificates use this font.', 'learndash' );
								} elseif (
									isset( $usage[ $key ] )
									&& App::get( Font_Usage::class )->is_in_use( $usage[ $key ] )
								) {
									$this->render_font_usage( $usage[ $key ] );
								} else {
									esc_html_e( 'No certificate uses this font.', 'learndash' );
								}
								?>
							</td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			<?php endif ?>
		</div>
		<?php
		// reset the error.
		$this->errors              = array();
		$this->unconfirmed_removal = null;
	}

	/**
	 * Returns the usage of font families, or null when it cannot be read.
	 *
	 * @since 5.3.0
	 *
	 * @param string[] $keys Font keys.
	 *
	 * @return array<int|string, array{templates: array<int, array{id: int, title: string, status: string}>, issued: int}>|null
	 */
	private function get_font_usage( array $keys ): ?array {
		try {
			return App::get( Font_Usage::class )->for_fonts( $keys );
		} catch ( Asset_Exception $e ) {
			return null;
		}
	}

	/**
	 * Prints the certificates a font's usage lists, each linked to its editor, and the count of issued certificates.
	 *
	 * @since 5.3.0
	 *
	 * @param array{templates: array<int, array{id: int, title: string, status: string}>, issued: int} $usage Usage of one
	 *                                                                                                       font.
	 *
	 * @return void
	 */
	private function render_font_usage( array $usage ): void {
		$templates = $this->readable_templates( $usage['templates'] );
		$parts     = array();
		$links     = array();

		foreach ( $templates['readable'] as $template ) {
			$title = '' !== $template['title'] ? $template['title'] : __( '(no title)', 'learndash' );
			$url   = get_edit_post_link( $template['id'], 'raw' );

			$links[] = is_string( $url ) && '' !== $url
				? sprintf( '<a href="%s">%s</a>', esc_url( $url ), esc_html( $title ) )
				: esc_html( $title );
		}

		if ( ! empty( $links ) ) {
			$parts[] = '<span>' . implode( ', ', $links ) . '</span>';
		}

		if ( $templates['others'] > 0 ) {
			$parts[] = esc_html(
				sprintf(
					// translators: %d: Number of certificates the current user cannot read.
					_n( '%d other certificate', '%d other certificates', $templates['others'], 'learndash' ),
					$templates['others']
				)
			);
		}

		if ( $usage['issued'] > 0 ) {
			$parts[] = esc_html(
				sprintf(
					// translators: %d: Number of issued certificates.
					_n( '%d issued certificate', '%d issued certificates', $usage['issued'], 'learndash' ),
					$usage['issued']
				)
			);
		}

		echo implode( '<br>', $parts ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Each part is escaped above.
	}

	/**
	 * Splits the certificates a font's usage lists into those the current user can read and a count of the others.
	 *
	 * The Fonts screen needs `LEARNDASH_ADMIN_CAPABILITY_CHECK`, which does not grant the course capabilities that
	 * reading another user's draft or private certificate takes, so the title of a certificate the user cannot read is
	 * left out.
	 *
	 * @since 5.3.0
	 *
	 * @param array<int, array{id: int, title: string, status: string}> $templates Certificates the usage lists.
	 *
	 * @return array{readable: array<int, array{id: int, title: string, status: string}>, others: int}
	 */
	private function readable_templates( array $templates ): array {
		$readable = array_values(
			array_filter(
				$templates,
				static fn( array $template ): bool => current_user_can( 'read_post', $template['id'] )
			)
		);

		return array(
			'readable' => $readable,
			'others'   => count( $templates ) - count( $readable ),
		);
	}

	/**
	 * Returns what the removal confirmation needs to know about a font: its name, the titles of the certificates that
	 * use it and that the current user can read, the number of other certificates, the count of issued certificates,
	 * and whether its usage could not be read.
	 *
	 * @since 5.3.0
	 *
	 * @param string                                                                                                           $key   Font key.
	 * @param array<int|string, array{templates: array<int, array{id: int, title: string, status: string}>, issued: int}>|null $usage Usage of every font, or null when it cannot be read.
	 *
	 * @return array{name: string, templates: string[], other_templates: int, issued: int, unknown: bool}
	 */
	private function font_usage_data( string $key, ?array $usage ): array {
		$font_usage = $usage[ $key ] ?? array(
			'templates' => array(),
			'issued'    => 0,
		);
		$templates  = $this->readable_templates( $font_usage['templates'] );

		return array(
			'name'            => $this->font_label( $key ),
			'templates'       => array_map(
				static fn( array $template ): string => '' !== $template['title'] ? $template['title'] : __( '(no title)', 'learndash' ),
				$templates['readable']
			),
			'other_templates' => $templates['others'],
			'issued'          => $font_usage['issued'],
			'unknown'         => null === $usage,
		);
	}

	/**
	 * Returns the name a font is stored with, or its key when it has none.
	 *
	 * @since 5.3.0
	 *
	 * @param string $key Font key.
	 *
	 * @return string
	 */
	private function font_label( string $key ): string {
		$fonts = $this->get_user_fonts();
		$name  = isset( $fonts[ $key ]['name'] ) ? Cast::to_string( $fonts[ $key ]['name'] ) : '';

		return '' !== $name ? $name : $key;
	}

	/**
	 * Returns the file name a stored font URL points at, or an empty string when the value is not a URL with a file name.
	 *
	 * @since 5.3.0
	 *
	 * @param mixed $url Stored font URL.
	 *
	 * @return string
	 */
	private function font_file_name( $url ): string {
		if (
			! is_string( $url )
			|| '' === $url
		) {
			return '';
		}

		$path = wp_parse_url( $url, PHP_URL_PATH );

		if (
			! is_string( $path )
			|| '' === $path
		) {
			return '';
		}

		return wp_basename( rawurldecode( $path ) );
	}

	/**
	 * Save the font meta
	 *
	 * @param string $label  User friendly name.
	 * @param string $family Font family.
	 * @param string $type   Font type.
	 * @param string $url    Font URL.
	 *
	 * @return void
	 */
	private function save_font( $label, $family, $type, $url ) {
		$fonts = $this->get_user_fonts();
		$info  = array(
			'name'   => $label,
			$type    => $url,
			'custom' => true,
		);
		if ( isset( $fonts[ $family ] ) ) {
			$fonts[ $family ] = array_replace( $fonts[ $family ], $info );
		} else {
			$fonts[ $family ] = $info;
		}
		update_option( self::OPTION_NAME, $fonts );
	}

	/**
	 * Returns the key a font is stored under: its family name as a slug, cut to the first 191 characters.
	 *
	 * The family name comes from the uploaded Regular file, so an admin cannot shorten it. 191 characters is the length
	 * of the certificate asset table's `asset_key`, which records the fonts each certificate uses by this key.
	 *
	 * @since 5.3.0
	 *
	 * @param string $family Family name read from the font file.
	 *
	 * @return string
	 */
	private function font_key( string $family ): string {
		return substr( sanitize_title( $family ), 0, 191 );
	}

	/**
	 * Get all the fonts uploaded by the user
	 *
	 * @return array<string, array<string, mixed>>
	 */
	private function get_user_fonts() {
		$fonts = get_option( self::OPTION_NAME, array() );

		return is_array( $fonts ) ? $fonts : array();
	}
}
