<?php
/**
 * Contains set of helper function.
 *
 * @file
 * @package LearnDash\Certificate_Builder
 */

use LearnDash_Certificate_Builder\Controller\Fonts_Manager;
use StellarWP\Learndash\StellarWP\Arrays\Arr;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Return the plugin asset URL
 *
 * @param string $path relative path to the assets.
 *
 * @return string
 */
function learndash_certificate_builder_asset_url( $path ) {
	$base_url = plugin_dir_url( __DIR__ );

	return untrailingslashit( $base_url ) . $path;
}

/**
 * Return the plugin asset path
 *
 * @param string $path relative path to the assets.
 *
 * @return string
 */
function learndash_certificate_builder_path( $path ) {
	$base_path = plugin_dir_path( __DIR__ );

	return $base_path . $path;
}

/**
 * Activate gutenberg for this post type
 *
 * @deprecated 5.3.0 LearnDash registers the certificate post type with `show_in_rest` enabled.
 *
 * @param array<string, mixed> $args The big array that contains all the CPT define.
 *
 * @return mixed
 */
function learndash_certificate_builder_enable_show_in_rest( $args ) {
	_deprecated_function( __FUNCTION__, '5.3.0' );

	if ( ! function_exists( 'learndash_get_post_type_slug' ) ) {
		return;
	}
	$post_type = learndash_get_post_type_slug( 'certificate' );
	if ( isset( $args[ $post_type ] ) ) {
		$args = Arr::set( $args, array( $post_type, 'cpt_options', 'show_in_rest' ), true );
	}

	return $args;
}

// register the Font Manager in Certificates section.
add_action(
	'learndash_settings_pages_init',
	function () {
		Fonts_Manager::add_page_instance();
	}
);

add_action( 'enqueue_block_editor_assets', 'learndash_certificate_builder_enqueue_block_extender' );
/**
 * Enqueue the extender js to apply new functions to ld block. This need to add before the core block queue.
 *
 * @return void
 */
function learndash_certificate_builder_enqueue_block_extender() {
	if ( ! function_exists( 'learndash_get_post_type_slug' ) ) {
		return;
	}
	// only load inside certificate.
	global $current_screen;
	if ( ! $current_screen instanceof WP_Screen ) {
		return;
	}

	if ( learndash_get_post_type_slug( 'certificate' ) === $current_screen->id ) {
		wp_enqueue_script(
			'learndash-certificate-builder-extender',
			learndash_certificate_builder_asset_url( '/build/certificate-builder-extender.js' ),
			array(
				'wp-hooks',
				'wp-polyfill',
			),
			LEARNDASH_SCRIPT_VERSION_TOKEN,
			false
		);
	}
}
