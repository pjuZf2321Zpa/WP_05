<?php
/**
 * Admin provider class file.
 *
 * @since 5.3.0
 *
 * @package LearnDash\Certificate_Builder
 */

namespace LearnDash\Certificate_Builder\Admin;

use StellarWP\Learndash\lucatume\DI52\ServiceProvider;

/**
 * Admin service provider class.
 *
 * @since 5.3.0
 */
class Provider extends ServiceProvider {
	/**
	 * Register service providers.
	 *
	 * @since 5.3.0
	 *
	 * @return void
	 */
	public function register(): void {
		$this->hooks();
	}

	/**
	 * Hooks wrapper.
	 *
	 * @since 5.3.0
	 *
	 * @return void
	 */
	public function hooks(): void {
	}
}
