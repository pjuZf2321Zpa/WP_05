<?php
/**
 * Deprecated Certificate Builder translations settings section file.
 *
 * @since 5.3.0
 * @deprecated 5.3.0
 *
 * @package LearnDash\Certificate_Builder
 */

_deprecated_file( __FILE__, '5.3.0' );

require_once __DIR__ . '/../../deprecated/App/Admin/Translation.php';
