<?php
/**
 * Deprecated bootstrap class file.
 *
 * The add-on's service provider boots it now.
 *
 * @since 5.3.0
 * @deprecated 5.3.0
 *
 * @package LearnDash\Certificate_Builder\Deprecated
 */

namespace LearnDash_Certificate_Builder;

use LearnDash_Certificate_Builder\Controller\Certificate_Builder;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

_deprecated_file( __FILE__, '5.3.0' );

/**
 * Class Bootstrap
 *
 * Kept for backward compatibility if in any case the class is referred directly.
 *
 * @since 5.3.0
 * @deprecated 5.3.0
 */
class Bootstrap {
	/**
	 * Contain the controller stack, so we don't need to init again
	 *
	 * @deprecated 5.3.0
	 *
	 * @var array<class-string, object>
	 */
	public $pool = array();

	/**
	 * Initial function, everything should be start here
	 *
	 * @deprecated 5.3.0
	 *
	 * @return void
	 */
	public function init() {
		if ( class_exists( '\SFWD_LMS' ) ) {
			$this->pool[ Certificate_Builder::class ] = new Certificate_Builder();
		} else {
			// going to add an admin notice.
			add_action( 'admin_notices', array( $this, 'requirement_notice' ) );
		}
	}

	/**
	 * Register all the assets that will be use in this plugin, the controllers will enqueue it later
	 *
	 * @deprecated 5.3.0
	 *
	 * @return void
	 */
	public function register_assets() {
		if ( ! class_exists( '\SFWD_LMS' ) ) {
			return;
		}
		$this->get_controller( Certificate_Builder::class )->register_block();
	}

	/**
	 * If the learndash core doesn't activated, then we show this message.
	 *
	 * @deprecated 5.3.0
	 *
	 * @return void
	 */
	public function requirement_notice() {
		?>
		<div class="notice notice-warning is-dismissible">
			<p>
			<?php
				// translators: Learndash website.
				printf( esc_html__( 'LearnDash LMS - Certificate Builder Add-on requires the following plugin(s) to be active: %s', 'learndash' ), '<a target="_blank" href="https://www.learndash.com/">LearnDash LMS</a>' );
			?>
			</p>
		</div>
		<?php
	}

	/**
	 * Load text domain.
	 *
	 * The strings now use the `learndash` text domain, which LearnDash core loads, so this method does nothing.
	 *
	 * @deprecated 5.3.0
	 *
	 * @return void
	 */
	public function load_plugin_textdomain() {
	}

	/**
	 * This function will check if a controller class has been initialed in the pool or not, if not, init and return
	 *
	 * @deprecated 5.3.0
	 *
	 * @param class-string $name Should be the class name.
	 *
	 * @return object|false
	 */
	private function get_controller( $name ) {
		if ( isset( $this->pool[ $name ] ) ) {
			return $this->pool[ $name ];
		}

		if ( class_exists( $name ) ) {
			$this->pool[ $name ] = new $name();

			return $this->pool[ $name ];
		}

		return false;
	}
}
