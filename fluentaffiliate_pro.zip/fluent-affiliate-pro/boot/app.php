<?php

return function ($file) {
    $loadAutoloader = function() {
        static $loaded = false;
        if (!$loaded) {
            require_once __DIR__ . '/../vendor/autoload.php';
            $loaded = true;
        }
    };

    add_action('fluent_affiliate/loaded', function ($app) use ($file, $loadAutoloader) {
        $loadAutoloader();
        new \FluentAffiliatePro\App\Core\Application($app, $file);

        $licenseManager = (new \FluentAffiliatePro\App\Services\PluginManager\FluentLicensing())->register([
            'version'           => FLUENT_AFFILIATE_PRO_VERSION,
            'plugin_title'      => 'FluentAffiliate Pro',
            'item_id'           => 7562841, // FluentCart product ID
            'settings_key'      => '__fluent-affiliate-pro_sl_info',
            'basename'          => 'fluent-affiliate-pro/fluent-affiliate-pro.php',
            'api_url'           => 'https://fluentapi.wpmanageninja.com/',
            'store_url'         => 'https://wpmanageninja.com/',
            'purchase_url'      => 'https://fluentaffiliate.com/',
            'account_url'       => 'https://wpmanageninja.com/account/',
            'support_url'       => 'https://wpmanageninja.com/account/support-tickets/',
            'activate_url'      => \FluentAffiliate\App\Helper\Utility::getAdminPageUrl('settings/license-settings'),
            'show_check_update' => true,
            // Refuse unsigned update packages; site owners can opt out via wp-config.php.
            'verify_updates'    => !(defined('FLUENT_AFFILIATE_PRO_SKIP_UPDATE_VERIFY') && FLUENT_AFFILIATE_PRO_SKIP_UPDATE_VERIFY),
        ]);

        // On init: the messages are translated, plugins_loaded is too early for the text domain.
        add_action('init', function () use ($licenseManager) {
            $licenseMessage = $licenseManager->getLicenseMessages();
            if (!$licenseMessage) {
                return;
            }

            add_action('admin_notices', function () use ($licenseMessage) {
                $class = 'notice notice-error fa_message';
                $message = $licenseMessage['message'];
                printf('<div class="%1$s"><p>%2$s</p></div>', esc_attr($class), wp_kses_post($message));
            });
            add_filter('fluent_affiliate/dashboard_notices', function ($notices) use ($licenseMessage) {
                if (current_user_can('manage_options')) {
                    $notices[] = '<div class="error">' . $licenseMessage['message'] . '</div>';
                }
                return $notices;
            });
        });

        add_action('fluent_affiliate/admin_app_rendering', function () {
            $currentDBVersion = get_option('fluent_affiliate_pro_db_version');
            if (!$currentDBVersion || version_compare($currentDBVersion, FLUENT_AFFILIATE_PRO_DB_VERSION, '<')) {
                update_option('fluent_affiliate_pro_db_version', FLUENT_AFFILIATE_PRO_DB_VERSION, 'no');
                \FluentAffiliatePro\Database\DBMigrator::run();
            }
        });

        do_action('fluent_affiliate/pro_loaded', $app);
    });

    add_action('plugins_loaded', function () use ($loadAutoloader) {
        if (!defined('FLUENT_AFFILIATE_VERSION')) {
            $loadAutoloader();
            (new \FluentAffiliatePro\App\Hooks\Handlers\CoreDepenedencyHandler())->register();
        }
    });

    register_activation_hook($file, function ($network_wide = false) use ($loadAutoloader) {
        $loadAutoloader();
        \FluentAffiliatePro\Database\DBMigrator::run($network_wide);
    });
};
