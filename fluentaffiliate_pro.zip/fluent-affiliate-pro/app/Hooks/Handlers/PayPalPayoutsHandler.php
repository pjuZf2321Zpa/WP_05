<?php

namespace FluentAffiliatePro\App\Hooks\Handlers;

use FluentAffiliatePro\App\Services\PayPal\PayPalPayouts;

class PayPalPayoutsHandler
{
    public function register()
    {
        add_filter('fluent_affiliate/payout_methods', [PayPalPayouts::class, 'filterMethods']);
        add_filter('fluent_affiliate/payout/validated_config', [PayPalPayouts::class, 'filterValidatedConfig'], 10, 2);
        add_filter('fluent_affiliate/payout/details', [PayPalPayouts::class, 'addPayoutDetails']);

        add_action(PayPalPayouts::SEND_ACTION, [PayPalPayouts::class, 'runSend']);
        add_action(PayPalPayouts::SYNC_ACTION, [PayPalPayouts::class, 'runSync']);
        add_action('fluent_affiliate_scheduled_hour_jobs', [PayPalPayouts::class, 'runHourly']);
        add_action('fluent_affiliate_scheduled_daily_jobs', [PayPalPayouts::class, 'runDaily']);
        add_action('init', [PayPalPayouts::class, 'maybeHandleWebhook']);

        add_filter('fluent_affiliate/admin_vars', [$this, 'addAdminVars']);
    }

    /**
     * The send confirmation names the mode, because Live moves real money.
     * Payout managers cannot read the settings, so the mode comes with the app.
     */
    public function addAdminVars($vars)
    {
        $vars['paypal_payouts'] = [
            'mode' => \FluentAffiliatePro\App\Services\PayPal\PayPalSettings::get()['mode'],
        ];

        return $vars;
    }
}
