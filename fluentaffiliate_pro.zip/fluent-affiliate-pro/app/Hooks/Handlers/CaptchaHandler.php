<?php

namespace FluentAffiliatePro\App\Hooks\Handlers;

use FluentAffiliatePro\App\Services\Captcha\CaptchaManager;

class CaptchaHandler
{
    public function register()
    {
        add_filter('fluent_affiliate/settings_menu_items', [$this, 'enableMenuItem'], 10, 1);
        add_action('fluent_affiliate/auth/register_form_after_fields', [$this, 'renderWidget']);
        add_filter('fluent_affiliate/auth/pre_registration_errors', [$this, 'verify'], 10, 3);
    }

    public function enableMenuItem($items)
    {
        if (isset($items['registration_settings']['children']['captcha_settings'])) {
            $items['registration_settings']['children']['captcha_settings']['disable'] = false;
        }

        return $items;
    }

    public function verify($errors, $data, $request)
    {
        // Respect an earlier rejection, and skip when captcha is not effectively on.
        if (!empty($errors) || !CaptchaManager::isEnabled()) {
            return $errors;
        }

        if (!CaptchaManager::verifyActive($request)) {
            return [
                'message' => CaptchaManager::getErrorMessage(),
            ];
        }

        return $errors;
    }

    public function renderWidget()
    {
        CaptchaManager::renderActive();
    }
}
