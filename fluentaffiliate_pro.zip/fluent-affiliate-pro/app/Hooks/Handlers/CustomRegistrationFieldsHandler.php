<?php

namespace FluentAffiliatePro\App\Hooks\Handlers;

use FluentAffiliate\App\Modules\Auth\AuthHelper;
use FluentAffiliate\Framework\Support\Arr;
use FluentAffiliatePro\App\Services\CustomRegistrationFieldsService;

class CustomRegistrationFieldsHandler
{
    public function register()
    {
        add_filter('fluent_affiliate/admin_vars', [$this, 'addFieldTypes'], 10, 1);
        add_filter('fluent_affiliate/auth/custom_field_values', [$this, 'validateValues'], 10, 3);
        add_filter('fluent_affiliate/affiliate_view_data', [$this, 'addAffiliateCustomFields'], 10, 1);
        add_filter('fluent_affiliate/portal/settings_data', [$this, 'addPortalCustomFields'], 10, 2);
    }

    public function addFieldTypes($vars)
    {
        $vars['registration_custom_field_types'] = CustomRegistrationFieldsService::getFieldTypes();

        return $vars;
    }

    public function validateValues($values, $fields, $submitted)
    {
        $customFields = array_values(array_filter((array) $fields, function ($field) {
            return CustomRegistrationFieldsService::isCustomField($field);
        }));

        if (empty($customFields)) {
            return $values;
        }

        // No value column (unsupported DB / no ALTER) → skip so a bad write can't break registration.
        if (!CustomRegistrationFieldsService::hasValueColumn()) {
            return $values;
        }

        try {
            // Merge into (not replace) accumulated filter values from earlier hooks.
            $customValues = CustomRegistrationFieldsService::sanitizeAndValidateValues($submitted, $customFields);
            return array_merge((array) $values, $customValues);
        } catch (\Exception $e) {
            return new \WP_Error('fa_custom_field_required', $e->getMessage());
        }
    }

    public function addAffiliateCustomFields($affiliate)
    {
        $values = (array) $affiliate->custom_fields;
        if (empty($values)) {
            return $affiliate;
        }

        $fields  = AuthHelper::getRegistrationFormFields(null, 'view', true);
        $details = [];

        foreach ($fields as $name => $field) {
            if (Arr::get($field, 'custom') !== 'yes' || !array_key_exists($name, $values)) {
                continue;
            }

            $value = $values[$name];
            if (is_array($value)) {
                $value = implode(', ', $value);
            }

            if ($value === '' || $value === null) {
                continue;
            }

            if (Arr::get($field, 'type') === 'date' && strtotime($value)) {
                $value = date_i18n(get_option('date_format'), strtotime($value));
            }

            $details[] = [
                'label' => Arr::get($field, 'label', $name),
                'value' => $value,
            ];
        }

        $affiliate->custom_field_details = $details;

        return $affiliate;
    }

    public function addPortalCustomFields($data, $affiliate)
    {
        $allFields = AuthHelper::getRegistrationFormFields(null, 'view', true);
        $values    = (array) $affiliate->custom_fields;

        foreach ($allFields as $name => $field) {
            if (Arr::get($field, 'custom') !== 'yes' || Arr::get($field, 'enabled') !== 'yes') {
                continue;
            }

            $type    = Arr::get($field, 'type', 'text');
            $options = array_map(function ($option) {
                return ['value' => $option, 'label' => $option];
            }, (array) Arr::get($field, 'options', []));

            $portalField = [
                'atts'        => ['size' => 'large'],
                'label'       => Arr::get($field, 'label', ''),
                'help_text'   => Arr::get($field, 'help_text', ''),
                'placeholder' => Arr::get($field, 'placeholder', ''),
                'required'    => Arr::get($field, 'required') === 'yes',
            ];

            if ($type === 'multiselect') {
                $portalField['type']    = 'checkbox';
                $portalField['options'] = $options;
            } elseif ($type === 'select') {
                $portalField['type']    = 'select';
                $portalField['options'] = $options;
            } elseif ($type === 'radio') {
                $portalField['type']    = 'radio';
                $portalField['options'] = $options;
            } elseif ($type === 'textarea') {
                $portalField['type'] = 'textarea';
            } elseif ($type === 'date') {
                $portalField['type'] = 'date';
            } else {
                $portalField['type']      = 'text';
                $portalField['data_type'] = in_array($type, ['number', 'url'], true) ? $type : 'text';
            }

            $data['form_fields'][$name] = $portalField;

            $default = $type === 'multiselect' ? [] : '';
            $data['settings'][$name] = array_key_exists($name, $values) ? $values[$name] : $default;
        }

        return $data;
    }
}
