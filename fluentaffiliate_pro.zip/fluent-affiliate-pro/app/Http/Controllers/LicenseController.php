<?php

namespace FluentAffiliatePro\App\Http\Controllers;

use FluentAffiliate\App\Http\Controllers\Controller;
use FluentAffiliate\Framework\Http\Request\Request;
use FluentAffiliatePro\App\Services\PluginManager\FluentLicensing;

class LicenseController extends Controller
{
    public function getStatus(Request $request, FluentLicensing $licenseManager)
    {
        $licenseInstance = $licenseManager::getInstance();

        $data = $licenseInstance->getStatus(true);

        if (is_wp_error($data)) {
            $message = $data->get_error_message();

            return [
                'status'        => 'invalid',
                'message'       => $message,
                'error_message' => $message,
            ];
        }

        return $this->formatLicenseData($data, $licenseInstance);
    }

    public function saveLicense(Request $request, FluentLicensing $licenseManager)
    {
        $licenseKey = $request->getSafe('license_key', 'sanitize_text_field');

        $licenseInstance = $licenseManager::getInstance();
        $response = $licenseInstance->activate($licenseKey);

        if (is_wp_error($response)) {
            return $this->sendError([
                'message' => $response->get_error_message(),
            ]);
        }

        return [
            'license_data' => $this->formatLicenseData($licenseInstance->getStatus(), $licenseInstance),
            'message'      => __('Your license key has been successfully updated', 'fluent-affiliate-pro'),
        ];
    }

    public function deactivateLicense(Request $request, FluentLicensing $licenseManager)
    {
        $licenseInstance = $licenseManager::getInstance();

        $response = $licenseInstance->deactivate();

        if (is_wp_error($response)) {
            return $this->sendError([
                'message' => $response->get_error_message(),
            ]);
        }

        return [
            'license_data' => $this->formatLicenseData($licenseInstance->getStatus(), $licenseInstance),
            'message'      => __('Your license key has been successfully deactivated', 'fluent-affiliate-pro'),
        ];
    }

    /**
     * Only add fields here, never rename: an older free plugin still reads
     * status, expires, renew_url, is_expired and error_message.
     */
    protected function formatLicenseData($data, FluentLicensing $licenseManager)
    {
        $status = isset($data['status']) ? $data['status'] : 'unregistered';
        $expires = isset($data['expires']) ? $data['expires'] : '';
        $isLifetime = $expires === 'lifetime';

        if (empty($data['renew_url']) && in_array($status, ['expired', 'valid'], true)) {
            $data['renew_url'] = $licenseManager->getRenewUrl();
        }

        $data['purchase_url'] = $licenseManager->getConfig('purchase_url');
        $data['account_url'] = $licenseManager->getConfig('account_url');
        $data['support_url'] = $licenseManager->getConfig('support_url');
        $data['license_key_masked'] = $licenseManager->getMaskedLicenseKey();
        $data['product_title'] = !empty($data['product_title']) ? $data['product_title'] : $licenseManager->getConfig('plugin_title');
        $data['is_lifetime'] = $isLifetime;
        $data['expires_human'] = '';
        $data['days_remaining'] = null;
        $data['last_checked_human'] = '';

        $remoteGraceDays = isset($data['grace_period_days']) ? (int)$data['grace_period_days'] : 0;
        $data['in_grace_period'] = false;
        $data['grace_period_days'] = null;

        if (!$isLifetime && $expires && $expiresAt = strtotime($expires)) {
            $data['expires_human'] = wp_date(get_option('date_format'), $expiresAt);
            $data['days_remaining'] = (int)floor(($expiresAt - time()) / DAY_IN_SECONDS);
            $data = $this->attachGraceData($data, $expiresAt, $status, $remoteGraceDays);
        }

        if (!empty($data['last_checked']) && $lastChecked = strtotime($data['last_checked'])) {
            $data['last_checked_human'] = sprintf(
                /* translators: %s: human readable time difference, e.g. "2 mins" */
                __('%s ago', 'fluent-affiliate-pro'),
                human_time_diff($lastChecked)
            );
        }

        // Never send these to the browser.
        unset($data['license_key'], $data['activation_hash']);

        return $data;
    }

    /**
     * The store keeps an expired-by-date license "valid" for a grace window but
     * does not report it; detect it locally. Only the fact is reported, never an
     * end date, since the fallback length is an assumption about the store.
     */
    protected function attachGraceData($data, $expiresAt, $status, $remoteGraceDays = 0)
    {
        if ($status !== 'valid' || $expiresAt > time()) {
            return $data;
        }

        $graceDays = $remoteGraceDays;

        if ($graceDays < 1) {
            /** @param int $days Grace window in days; return 0 to disable. */
            $graceDays = (int)apply_filters('fluent_affiliate/license_grace_period_days', 15);
        }

        if ($graceDays < 1) {
            return $data;
        }

        $graceEndsAt = $expiresAt + ($graceDays * DAY_IN_SECONDS);

        if ($graceEndsAt <= time()) {
            return $data;
        }

        $data['in_grace_period'] = true;
        $data['grace_period_days'] = $graceDays;

        return $data;
    }
}
