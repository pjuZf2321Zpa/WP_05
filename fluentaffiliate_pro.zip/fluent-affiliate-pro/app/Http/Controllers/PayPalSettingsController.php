<?php

namespace FluentAffiliatePro\App\Http\Controllers;

use FluentAffiliate\App\Http\Controllers\Controller;
use FluentAffiliate\Framework\Http\Request\Request;
use FluentAffiliatePro\App\Services\PayPal\PayPalApi;
use FluentAffiliatePro\App\Services\PayPal\PayPalSettings;

class PayPalSettingsController extends Controller
{
    public function get(Request $request)
    {
        return $this->settingsResponse();
    }

    public function save(Request $request)
    {
        $prev = PayPalSettings::get();
        $settings = PayPalSettings::sanitize($request->get('settings', []), $prev);
        $notices = [];

        $changedModes = array_filter(PayPalSettings::MODES, function ($mode) use ($settings, $prev) {
            return PayPalSettings::keysChanged($settings, $prev, $mode);
        });

        // check every changed key pair with PayPal before anything changes, so a
        // bad pair for one mode cannot leave the other mode half updated
        foreach ($changedModes as $mode) {
            list($clientId, $secret) = PayPalSettings::getCredentials($mode, $settings);

            if (!$clientId && !$secret) {
                continue;
            }

            if (!$clientId || !$secret) {
                return $this->sendError([
                    /* translators: %s: PayPal mode, Sandbox or Live */
                    'message' => sprintf(__('Add both the client ID and the secret for %s.', 'fluent-affiliate-pro'), $this->modeLabel($mode)),
                ]);
            }

            $token = PayPalApi::getAccessToken($mode, $clientId, $secret);
            if (is_wp_error($token)) {
                return $this->sendError([
                    /* translators: 1: PayPal mode, Sandbox or Live, 2: PayPal error message */
                    'message' => sprintf(__('PayPal refused the %1$s keys: %2$s', 'fluent-affiliate-pro'), $this->modeLabel($mode), $token->get_error_message()),
                ]);
            }
        }

        foreach ($changedModes as $mode) {
            // a webhook belongs to the PayPal app, not to its secret, so a new
            // secret for the same client ID keeps it
            if ($settings[$mode . '_client_id'] === $prev[$mode . '_client_id']) {
                continue;
            }

            // the old webhook belongs to the old app, so remove it while its keys still work
            if ($prev[$mode . '_webhook_id']) {
                $deleted = PayPalApi::deleteWebhook($mode, $prev[$mode . '_webhook_id']);
                if (is_wp_error($deleted)) {
                    $notices[] = $this->webhookNotice(__('Could not remove the old webhook at PayPal. Remove it in your PayPal app.', 'fluent-affiliate-pro'), $mode, $deleted);
                }
                $settings[$mode . '_webhook_id'] = '';
            }
        }

        PayPalSettings::save($settings);

        foreach (PayPalSettings::MODES as $mode) {
            if (!$settings[$mode . '_webhook_id'] && PayPalSettings::isConfigured($mode)) {
                $notice = $this->maybeRegisterWebhook($mode);
                if ($notice) {
                    $notices[] = $notice;
                }
            }
        }

        return $this->settingsResponse(__('PayPal Payouts settings saved.', 'fluent-affiliate-pro'), $notices);
    }

    public function test(Request $request)
    {
        $mode = $request->get('mode') === 'live' ? 'live' : 'test';

        if (!PayPalSettings::isConfigured($mode)) {
            return $this->sendError([
                /* translators: %s: PayPal mode, Sandbox or Live */
                'message' => sprintf(__('Save the %s keys first.', 'fluent-affiliate-pro'), $this->modeLabel($mode)),
            ]);
        }

        list($clientId, $secret) = PayPalSettings::getCredentials($mode);
        $token = PayPalApi::getAccessToken($mode, $clientId, $secret);

        if (is_wp_error($token)) {
            return $this->sendError([
                /* translators: %s: PayPal error message */
                'message' => sprintf(__('PayPal refused the connection: %s', 'fluent-affiliate-pro'), $token->get_error_message()),
            ]);
        }

        return [
            /* translators: %s: PayPal mode, Sandbox or Live */
            'message' => sprintf(__('Connected to PayPal (%s).', 'fluent-affiliate-pro'), $this->modeLabel($mode)),
        ];
    }

    public function registerWebhook(Request $request)
    {
        $mode = $request->get('mode') === 'live' ? 'live' : 'test';

        if (!PayPalSettings::isConfigured($mode)) {
            return $this->sendError([
                /* translators: %s: PayPal mode, Sandbox or Live */
                'message' => sprintf(__('Save the %s keys first.', 'fluent-affiliate-pro'), $this->modeLabel($mode)),
            ]);
        }

        $notice = $this->maybeRegisterWebhook($mode);
        if ($notice) {
            return $this->sendError(['message' => $notice]);
        }

        return $this->settingsResponse(__('The webhook is registered at PayPal.', 'fluent-affiliate-pro'));
    }

    public function delete(Request $request)
    {
        $settings = PayPalSettings::get();
        $notices = [];

        foreach (PayPalSettings::MODES as $mode) {
            if (!$settings[$mode . '_webhook_id']) {
                continue;
            }

            $deleted = PayPalApi::deleteWebhook($mode, $settings[$mode . '_webhook_id']);
            if (is_wp_error($deleted)) {
                $notices[] = $this->webhookNotice(__('Could not remove the webhook at PayPal. Remove it in your PayPal app.', 'fluent-affiliate-pro'), $mode, $deleted);
            }
        }

        // the keys go even when PayPal is unreachable, so the admin is never stuck with them
        PayPalSettings::delete();

        return $this->settingsResponse(__('The PayPal keys are removed.', 'fluent-affiliate-pro'), $notices);
    }

    /**
     * Registers the webhook and saves its ID. A local site or a URL PayPal
     * refuses saves nothing; the hourly check covers the missed events.
     *
     * @return string an error notice, or '' on success
     */
    protected function maybeRegisterWebhook($mode)
    {
        // the keys this request registers with; PayPalApi reads the same settings
        $usedSettings = PayPalSettings::get();
        $webhookId = PayPalApi::registerWebhook($mode);

        if (is_wp_error($webhookId) || !$webhookId) {
            return $this->webhookNotice(__('Could not register the webhook at PayPal. Payout results will arrive with the hourly check instead.', 'fluent-affiliate-pro'), $mode, $webhookId);
        }

        if (!PayPalSettings::saveWebhookId($mode, $webhookId, $usedSettings)) {
            return $this->webhookNotice(__('The keys changed while the webhook was registered, so the webhook was not saved. Open the settings again and check the webhook status.', 'fluent-affiliate-pro'), $mode, null);
        }

        return '';
    }

    protected function webhookNotice($message, $mode, $error)
    {
        $notice = $this->modeLabel($mode) . ': ' . $message;

        if (is_wp_error($error)) {
            $notice .= ' (' . $error->get_error_message() . ')';
        }

        return $notice;
    }

    protected function modeLabel($mode)
    {
        return $mode === 'live' ? __('Live', 'fluent-affiliate-pro') : __('Sandbox', 'fluent-affiliate-pro');
    }

    protected function settingsResponse($message = '', $notices = [])
    {
        return [
            'message'     => $message,
            'notices'     => $notices,
            'settings'    => PayPalSettings::getDisplay(),
            'webhook_url' => PayPalApi::getWebhookUrl(),
        ];
    }
}
