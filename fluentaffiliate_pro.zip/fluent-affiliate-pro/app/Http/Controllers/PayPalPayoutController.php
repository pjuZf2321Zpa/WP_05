<?php

namespace FluentAffiliatePro\App\Http\Controllers;

use FluentAffiliate\App\Http\Controllers\Controller;
use FluentAffiliate\App\Models\Payout;
use FluentAffiliate\Framework\Http\Request\Request;
use FluentAffiliatePro\App\Services\PayPal\PayPalPayouts;

class PayPalPayoutController extends Controller
{
    public function sendPayout(Request $request, $id)
    {
        $result = PayPalPayouts::startSend((int) $id);

        if (is_wp_error($result)) {
            return $this->sendError([
                'message' => $result->get_error_message(),
            ]);
        }

        return [
            'message' => __('The payout is being sent to PayPal.', 'fluent-affiliate-pro'),
            'payout'  => Payout::query()->find((int) $id),
        ];
    }

    public function syncPayout(Request $request, $id)
    {
        $payout = Payout::query()->findOrFail((int) $id);

        if (!PayPalPayouts::isPayPalPayout($payout)) {
            return $this->sendError([
                'message' => __('This payout is not a PayPal payout.', 'fluent-affiliate-pro'),
            ]);
        }

        $result = PayPalPayouts::sync($payout);

        if (is_wp_error($result)) {
            return $this->sendError([
                'message' => $result->get_error_message(),
            ]);
        }

        return [
            'message' => __('The payout status is updated from PayPal.', 'fluent-affiliate-pro'),
            'payout'  => Payout::query()->find($payout->id),
        ];
    }

    public function markNotSent(Request $request, $id)
    {
        $payout = Payout::query()->findOrFail((int) $id);

        if (!PayPalPayouts::isPayPalPayout($payout)) {
            return $this->sendError([
                'message' => __('This payout is not a PayPal payout.', 'fluent-affiliate-pro'),
            ]);
        }

        $result = PayPalPayouts::markNotSent($payout);

        if (is_wp_error($result)) {
            return $this->sendError([
                'message' => $result->get_error_message(),
            ]);
        }

        return [
            'message' => __('The payout is marked as not in PayPal. Its payments are failed, so you can pay them by hand or remove them.', 'fluent-affiliate-pro'),
            'payout'  => Payout::query()->find($payout->id),
        ];
    }

    public function recoverBatch(Request $request, $id)
    {
        $payout = Payout::query()->findOrFail((int) $id);

        if (!PayPalPayouts::isPayPalPayout($payout)) {
            return $this->sendError([
                'message' => __('This payout is not a PayPal payout.', 'fluent-affiliate-pro'),
            ]);
        }

        $result = PayPalPayouts::recoverBatch($payout, trim((string) $request->getSafe('batch_id', 'sanitize_text_field')));

        if (is_wp_error($result)) {
            return $this->sendError([
                'message' => $result->get_error_message(),
            ]);
        }

        return [
            'message' => __('The PayPal batch ID is added, and the payout status is updated from PayPal.', 'fluent-affiliate-pro'),
            'payout'  => Payout::query()->find($payout->id),
        ];
    }
}
