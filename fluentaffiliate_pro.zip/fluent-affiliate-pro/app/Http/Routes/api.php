<?php

/**
 * @var FluentAffiliate\Framework\Http\Router $router
 */

use FluentAffiliatePro\App\Http\Controllers\DomainController;
use FluentAffiliatePro\App\Http\Controllers\ProSettingController;
use FluentAffiliatePro\App\Http\Controllers\AffiliateGroupController;
use FluentAffiliatePro\App\Http\Controllers\CreativeController;
use FluentAffiliatePro\App\Http\Controllers\LicenseController;
use FluentAffiliatePro\App\Http\Controllers\LifetimeCommissionController;
use FluentAffiliatePro\App\Http\Controllers\PayPalSettingsController;
use FluentAffiliatePro\App\Http\Controllers\PayPalPayoutController;

$router->prefix('settings')->withPolicy(\FluentAffiliate\App\Http\Policies\AdminPolicy::class)->group(function ($router) {
    $router->get('connected-sites-config', [DomainController::class, 'getConnectedConfig']);
    $router->patch('connected-sites-config', [DomainController::class, 'updateGlobalStatus']);
    $router->patch('connected-sites-config/update', [DomainController::class, 'patchSingleSiteConfig']);
    $router->post('connected-sites-config/issue', [DomainController::class, 'validateAndIssueNewSiteToken']);
    $router->post('connected-sites-config/disconnect', [DomainController::class, 'disconnectSite']);

    $router->get('/groups', [AffiliateGroupController::class, 'index']);
    $router->post('/groups', [AffiliateGroupController::class, 'store']);
    $router->patch('/groups/{id}', [AffiliateGroupController::class, 'update'])->int('id');
    $router->get('/groups/{id}', [AffiliateGroupController::class, 'show'])->int('id');
    $router->get('/groups/{id}/affiliates', [AffiliateGroupController::class, 'affiliates'])->int('id');
    $router->get('/groups/{id}/overview', [AffiliateGroupController::class, 'overview'])->int('id');
    $router->get('/groups/{id}/statistics', [AffiliateGroupController::class, 'statistics'])->int('id');
    $router->delete('/groups/{id}', [AffiliateGroupController::class, 'destroy'])->int('id');

    
    $router->get('/creatives', [CreativeController::class, 'index']);
    $router->get('/creatives/{id}', [CreativeController::class, 'show'])->int('id');
    $router->post('/creatives', [CreativeController::class, 'store']);
    $router->patch('/creatives/{id}', [CreativeController::class, 'update'])->int('id');
    $router->delete('/creatives/{id}', [CreativeController::class, 'destroy'])->int('id');

    $router->get('/options/affiliate-groups', [ProSettingController::class, 'getAffiliateGroupsOptions']);

    $router->post('/registration-fields', [ProSettingController::class, 'saveRegistrationFields']);

    $router->get('/captcha', [ProSettingController::class, 'getCaptchaSettings']);
    $router->post('/captcha', [ProSettingController::class, 'saveCaptchaSettings']);
    $router->post('/captcha/validate', [ProSettingController::class, 'validateCaptchaKeys']);

    $router->get('/managers', [ProSettingController::class, 'getManagers']);
});

$router->prefix('settings')->withPolicy(\FluentAffiliate\App\Http\Policies\SuperAdminPolicy::class)->group(function ($router) {
    $router->get('/license', [LicenseController::class, 'getStatus']);
    $router->post('/license', [LicenseController::class, 'saveLicense']);
    $router->delete('/license', [LicenseController::class, 'deactivateLicense']);

    $router->post('/managers', [ProSettingController::class, 'updateManager']);
    $router->delete('/managers/{id}', [ProSettingController::class, 'deleteManager'])->int('id');

    // the keys decide which PayPal account sends payout money, so site admins only
    $router->get('/paypal-payouts', [PayPalSettingsController::class, 'get']);
    $router->post('/paypal-payouts', [PayPalSettingsController::class, 'save']);
    $router->delete('/paypal-payouts', [PayPalSettingsController::class, 'delete']);
    $router->post('/paypal-payouts/test', [PayPalSettingsController::class, 'test']);
    $router->post('/paypal-payouts/webhook', [PayPalSettingsController::class, 'registerWebhook']);
});

$router->prefix('payouts')->withPolicy(\FluentAffiliate\App\Http\Policies\PayoutPolicy::class)->group(function ($router) {
    $router->post('/{id}/paypal-send', [PayPalPayoutController::class, 'sendPayout'])->int('id');
    $router->post('/{id}/paypal-sync', [PayPalPayoutController::class, 'syncPayout'])->int('id');
    $router->post('/{id}/paypal-batch', [PayPalPayoutController::class, 'recoverBatch'])->int('id');
    $router->post('/{id}/paypal-not-sent', [PayPalPayoutController::class, 'markNotSent'])->int('id');
});

$router->prefix('affiliates')->withPolicy(\FluentAffiliate\App\Http\Policies\AdminPolicy::class)->group(function ($router) {
    $router->get('/{id}/customers/search', [LifetimeCommissionController::class, 'searchCustomers'])->int('id');
    $router->post('/{id}/customers/link', [LifetimeCommissionController::class, 'link'])->int('id');
    $router->delete('/{id}/customers/{customerId}', [LifetimeCommissionController::class, 'unlink'])->int('id')->int('customerId');
});

$router->prefix('portal')->withPolicy(\FluentAffiliate\App\Http\Policies\UserPolicy::class)->group(function ($router) {
    $router->get('creatives', [CreativeController::class, 'portalCreatives']);
});