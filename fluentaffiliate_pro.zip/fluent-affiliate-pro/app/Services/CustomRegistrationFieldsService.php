<?php

namespace FluentAffiliatePro\App\Services;

use FluentAffiliate\Framework\Support\Arr;

class CustomRegistrationFieldsService
{
    private static $hasValueColumn = null;

    /** Max stored length for a free-text custom value (mirrors bank_details max:5000). */
    const MAX_VALUE_LENGTH = 5000;

    /**
     * The supported field types (type => label). Fixed set — adding a type also
     * needs a renderer in FormBuilder, a case in sanitizeFieldValue, and the
     * portal mapping in CustomRegistrationFieldsHandler, so it is not filterable.
     *
     * @return array type => label
     */
    public static function getFieldTypes()
    {
        return [
            'text'        => __('Text', 'fluent-affiliate-pro'),
            'textarea'    => __('Textarea', 'fluent-affiliate-pro'),
            'number'      => __('Number', 'fluent-affiliate-pro'),
            'date'        => __('Date', 'fluent-affiliate-pro'),
            'select'      => __('Dropdown', 'fluent-affiliate-pro'),
            'radio'       => __('Radio', 'fluent-affiliate-pro'),
            'url'         => __('URL', 'fluent-affiliate-pro'),
            'multiselect' => __('Multi Select', 'fluent-affiliate-pro'),
        ];
    }

    public static function isCustomField($field)
    {
        return Arr::get($field, 'custom') === 'yes';
    }

    public static function sanitizeCustomField($field, &$usedNames)
    {
        $label = sanitize_text_field(Arr::get($field, 'label', ''));
        if (!$label) {
            return null;
        }

        $allowedTypes = array_keys(self::getFieldTypes());
        $type = self::sanitizeEnum(Arr::get($field, 'type', 'text'), $allowedTypes, 'text');

        $name = self::uniqueName(Arr::get($field, 'name', '') ?: $label, $usedNames);

        return [
            'name'              => $name,
            'label'             => $label,
            'type'              => $type,
            'placeholder'       => self::typeSupportsPlaceholder($type)
                ? sanitize_text_field(Arr::get($field, 'placeholder', ''))
                : '',
            'help_text'         => sanitize_text_field(Arr::get($field, 'help_text', '')),
            'options'           => self::sanitizeOptions(Arr::get($field, 'options', []), $type),
            'required'          => Arr::get($field, 'required') === 'yes' ? 'yes' : 'no',
            'enabled'           => Arr::get($field, 'enabled', 'yes') === 'no' ? 'no' : 'yes',
            'custom'            => 'yes',
            'system_defined'    => 'no',
            'disable_alter'     => 'no',
            'sanitize_callback' => self::sanitizeCallbackForType($type),
        ];
    }

    public static function sanitizeAndValidateValues($submitted, $customFields)
    {
        $clean = [];

        foreach ($customFields as $field) {
            $name = Arr::get($field, 'name');
            if (!$name || Arr::get($field, 'enabled', 'yes') === 'no') {
                continue;
            }

            $value = self::sanitizeFieldValue(Arr::get($submitted, $name), $field);

            if (Arr::get($field, 'required') === 'yes' && (is_array($value) ? empty($value) : $value === '')) {
                throw new \Exception(
                    sprintf(__('%s is required', 'fluent-affiliate-pro'), Arr::get($field, 'label', $name))
                );
            }

            // Reject over-long free-text values, mirroring bank_details' max:5000.
            if (is_string($value) && mb_strlen($value) > self::MAX_VALUE_LENGTH) {
                throw new \Exception(sprintf(
                    // translators: %1$s: field label, %2$d: character limit
                    __('%1$s must be at most %2$d characters', 'fluent-affiliate-pro'),
                    Arr::get($field, 'label', $name),
                    self::MAX_VALUE_LENGTH
                ));
            }

            $clean[$name] = $value;
        }

        return $clean;
    }

    public static function sanitizeFieldValue($value, $field)
    {
        $type    = Arr::get($field, 'type', 'text');
        $options = Arr::get($field, 'options', []);

        if ($type === 'multiselect') {
            if (!is_array($value)) {
                return [];
            }

            $sanitized = [];
            foreach ($value as $val) {
                $choice = self::sanitizeChoiceValue($val, $options);
                if ($choice !== '') {
                    $sanitized[] = $choice;
                }
            }

            // Dedupe — duplicate selections are meaningless and bound the array to the option count.
            return array_values(array_unique($sanitized));
        }

        if (!is_scalar($value)) {
            return '';
        }

        $sanitizers = [
            'textarea' => function ($v) {
                return sanitize_textarea_field($v);
            },
            'number'   => function ($v) {
                return is_numeric($v) ? floatval($v) : '';
            },
            'url'      => function ($v) {
                return sanitize_url($v);
            },
            'date'     => function ($v) {
                $date = \DateTime::createFromFormat('Y-m-d', $v);
                return ($date && $date->format('Y-m-d') === $v) ? $v : '';
            },
            'select'   => function ($v) use ($options) {
                return self::sanitizeChoiceValue($v, $options);
            },
            'radio'    => function ($v) use ($options) {
                return self::sanitizeChoiceValue($v, $options);
            },
        ];

        $sanitizer = isset($sanitizers[$type]) ? $sanitizers[$type] : function ($v) {
            return sanitize_text_field($v);
        };

        return $sanitizer($value);
    }

    // Request-cached guard: does the custom_fields column exist yet (before the migration runs)?
    public static function hasValueColumn()
    {
        if (self::$hasValueColumn === null) {
            global $wpdb;
            $table = $wpdb->prefix . 'fa_affiliates';
            // phpcs:ignore WordPress.DB, PluginCheck.Security.DirectDB -- column-existence check
            self::$hasValueColumn = (bool) $wpdb->get_var($wpdb->prepare("SHOW COLUMNS FROM `$table` LIKE %s", 'custom_fields'));
        }

        return self::$hasValueColumn;
    }

    private static function sanitizeChoiceValue($value, $options)
    {
        if (!is_array($options) || empty($options)) {
            return '';
        }

        $value = sanitize_text_field($value);
        if (!$value) {
            return '';
        }

        $isList = array_keys($options) === range(0, count($options) - 1);

        if ($isList ? !in_array($value, $options, true) : !array_key_exists($value, $options)) {
            return '';
        }

        return $value;
    }

    private static function sanitizeOptions($rawOptions, $type)
    {
        if (!in_array($type, ['select', 'radio', 'multiselect'], true) || !is_array($rawOptions)) {
            return [];
        }

        $options = [];
        foreach ($rawOptions as $option) {
            if (!is_string($option) && !is_numeric($option)) {
                continue;
            }
            $sanitized = sanitize_text_field((string) $option);
            if ($sanitized !== '') {
                $options[] = $sanitized;
            }
        }

        return array_values(array_unique($options));
    }

    private static function sanitizeCallbackForType($type)
    {
        $map = [
            'textarea' => 'sanitize_textarea_field',
            'url'      => 'sanitize_url',
        ];

        return isset($map[$type]) ? $map[$type] : 'sanitize_text_field';
    }

    private static function typeSupportsPlaceholder($type)
    {
        return !in_array($type, ['radio', 'multiselect', 'date', 'select'], true);
    }

    private static function sanitizeEnum($value, $allowed, $default)
    {
        $value = sanitize_text_field($value);

        return in_array($value, $allowed, true) ? $value : $default;
    }

    private static function uniqueName($source, &$usedNames)
    {
        $name = sanitize_title($source);
        $name = str_replace('-', '_', $name);
        if ($name === '') {
            $name = 'custom_field';
        }

        // Keep custom names namespaced so they never collide with system field names.
        if (strpos($name, 'cf_') !== 0) {
            $name = 'cf_' . $name;
        }

        $name = substr($name, 0, 40);
        $original = $name;
        $counter = 1;

        while (in_array($name, $usedNames, true)) {
            $suffix = '_' . $counter++;
            $name = substr($original, 0, 40 - strlen($suffix)) . $suffix;
        }

        $usedNames[] = $name;

        return $name;
    }
}
