<?php

namespace FluentAffiliatePro\App\Services;

use FluentAffiliate\Framework\Support\Arr;

class ProHelper
{
    public static function sanitizeRegistrationFields($fieldsData)
    {
        $fieldTypes = [
            'text'   => [
                'fields'    => ['label', 'placeholder', 'help_text', 'name', 'type'],
                'sanitizer' => 'sanitize_text_field'
            ],
            'html'   => [
                'fields'    => ['html', 'inline_label'],
                'sanitizer' => 'wp_kses_post'
            ],
            'yes_no' => [
                'fields'    => ['system_defined', 'required', 'public_only', 'disable_alter', 'enabled'],
                'sanitizer' => function ($value) {
                    return $value === 'yes' ? 'yes' : 'no';
                }
            ]
        ];

        $systemNames = self::reservedRegistrationFieldNames();

        $usedNames = [];
        $formattedFields = [];
        foreach ($fieldsData as $field) {
            if (CustomRegistrationFieldsService::isCustomField($field)) {
                $customField = CustomRegistrationFieldsService::sanitizeCustomField($field, $usedNames);
                if ($customField) {
                    $formattedFields[] = $customField;
                }
                continue;
            }

            $sanitizedField = [];
            foreach ($fieldTypes as $type) {
                $values = Arr::only($field, $type['fields']);
                $sanitized = array_map($type['sanitizer'], $values);
                $sanitizedField = wp_parse_args($sanitizedField, $sanitized);
            }

            if (!empty($sanitizedField['name'])) {
                $name = $sanitizedField['name'];
                if (!in_array($name, $systemNames, true) && strpos($name, 'cf_') !== 0) {
                    $name = 'cf_' . $name;
                    $sanitizedField['name'] = $name;
                }
                $usedNames[] = $name;
            }

            $formattedFields[] = $sanitizedField;
        }

        return $formattedFields;
    }

    protected static function reservedRegistrationFieldNames()
    {
        $names = [
            'full_name', 'email', 'username', 'password', 'conf_password',
            'raw_html', 'note', 'url', 'terms_condition', 'bank_details', 'payment_email'
        ];

        return apply_filters('fluent_affiliate/reserved_registration_field_names', $names);
    }
}
