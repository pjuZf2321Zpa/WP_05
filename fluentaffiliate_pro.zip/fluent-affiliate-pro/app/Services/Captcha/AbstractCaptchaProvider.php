<?php

namespace FluentAffiliatePro\App\Services\Captcha;

abstract class AbstractCaptchaProvider
{
    abstract public function getKey();

    abstract public function getTitle();

    abstract public function getDefaults();

    abstract public function sanitize($input, $prev = []);

    // Mask stored secrets before settings reach the admin UI. No-op unless a provider has secrets.
    public function maskSecrets($settings)
    {
        return $settings;
    }

    abstract public function isConfigured($settings);

    abstract public function render($settings);

    abstract public function verify($settings, $request);

    abstract public function validateCredentials($settings, $token);

    public function credentialFingerprint($settings)
    {
        return md5(wp_json_encode($settings));
    }

    protected function remoteVerify($url, $params)
    {
        $response = wp_remote_post($url, [
            'body'    => $params,
            'timeout' => 10,
        ]);

        if (is_wp_error($response)) {
            return null;
        }

        $result = json_decode(wp_remote_retrieve_body($response), true);

        return is_array($result) ? $result : null;
    }

    protected function getIpAddress()
    {
        $ip = '';

        foreach (['HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR'] as $key) {
            if (!empty($_SERVER[$key])) {
                $ip = sanitize_text_field(wp_unslash($_SERVER[$key]));
                break;
            }
        }

        // X-Forwarded-For may be a comma-separated list; take the first.
        if (strpos($ip, ',') !== false) {
            $parts = explode(',', $ip);
            $ip    = trim($parts[0]);
        }

        return $ip;
    }
}
