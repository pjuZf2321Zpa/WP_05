<?php

namespace FluentAffiliatePro\App\Services\Captcha;

use FluentAffiliate\Framework\Support\Arr;
use FluentAffiliate\App\Helper\Helper;

class RecaptchaProvider extends AbstractCaptchaProvider
{
    const VERIFY_URL = 'https://www.google.com/recaptcha/api/siteverify';

    // v3 action name; verify() rejects tokens minted for any other action.
    const V3_ACTION = 'affiliate_register';

    // Placeholder for a stored secret in the admin UI; on save means "unchanged".
    const SECRET_MASK = '__FA_CAPTCHA_SECRET_KEY__';

    public function getKey()
    {
        return 'recaptcha';
    }

    public function getTitle()
    {
        return __('Google reCAPTCHA', 'fluent-affiliate-pro');
    }

    public function getDefaults()
    {
        return [
            'version'            => 'v2_visible', // v2_visible | v3_invisible
            'v2_site_key'        => '',
            'v2_secret_key'      => '',
            'v3_site_key'        => '',
            'v3_secret_key'      => '',
            'v3_score_threshold' => 0.5,
            'error_message'      => __('Security check failed. Please try again.', 'fluent-affiliate-pro'),
        ];
    }

    public function sanitize($input, $prev = [])
    {
        if (!is_array($input)) {
            $input = [];
        }

        $threshold = (float) Arr::get($input, 'v3_score_threshold', 0.5);
        $threshold = max(0, min(1, $threshold));

        $defaults     = $this->getDefaults();
        $errorMessage = sanitize_text_field(Arr::get($input, 'error_message', ''));
        if ($errorMessage === '') {
            $errorMessage = $defaults['error_message'];
        }

        return [
            'version'            => Arr::get($input, 'version') === 'v3_invisible' ? 'v3_invisible' : 'v2_visible',
            'v2_site_key'        => sanitize_text_field(Arr::get($input, 'v2_site_key', '')),
            'v2_secret_key'      => $this->resolveSecret(Arr::get($input, 'v2_secret_key', ''), Arr::get($prev, 'v2_secret_key', '')),
            'v3_site_key'        => sanitize_text_field(Arr::get($input, 'v3_site_key', '')),
            'v3_secret_key'      => $this->resolveSecret(Arr::get($input, 'v3_secret_key', ''), Arr::get($prev, 'v3_secret_key', '')),
            'v3_score_threshold' => $threshold,
            'error_message'      => $errorMessage,
        ];
    }

    private function resolveSecret($incoming, $prevEncrypted)
    {
        $incoming = trim((string) $incoming);

        if ($incoming === '') {
            return '';
        }

        if ($incoming === self::SECRET_MASK) {
            return (string) $prevEncrypted;
        }

        return Helper::encryptDecrypt(sanitize_text_field($incoming), 'e');
    }

    public function maskSecrets($settings)
    {
        foreach (['v2_secret_key', 'v3_secret_key'] as $field) {
            if (!empty($settings[$field])) {
                $settings[$field] = self::SECRET_MASK;
            }
        }

        return $settings;
    }

    public function isConfigured($settings)
    {
        return $this->getSiteKey($settings) && $this->getSecretKey($settings);
    }

    public function render($settings)
    {
        $siteKey = $this->getSiteKey($settings);

        if ($this->getVersion($settings) === 'v3_invisible') {
            $this->renderV3($siteKey);
        } else {
            $this->renderV2($siteKey);
        }

        echo $this->disclosureHtml(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped via wp_kses
    }

    private function disclosureHtml()
    {
        $notice = sprintf(
            /* translators: %1$s: opening Privacy Policy link tag, %2$s: closing tag, %3$s: opening Terms of Service link tag, %4$s: closing tag. */
            __('This site is protected by reCAPTCHA and the Google %1$sPrivacy Policy%2$s and %3$sTerms of Service%4$s apply.', 'fluent-affiliate-pro'),
            '<a href="https://policies.google.com/privacy" target="_blank" rel="noopener noreferrer">',
            '</a>',
            '<a href="https://policies.google.com/terms" target="_blank" rel="noopener noreferrer">',
            '</a>'
        );

        $allowed = ['a' => ['href' => [], 'target' => [], 'rel' => []]];

        return '<div class="fa_recaptcha_disclosure fa_help_text">' . wp_kses($notice, $allowed) . '</div>';
    }

    public function verify($settings, $request)
    {
        $token = $request->get('g-recaptcha-response', '');

        if (empty($token)) {
            return false;
        }

        $secret = $this->getSecretKey($settings);

        if (empty($secret)) {
            return false;
        }

        $params = [
            'secret'   => $secret,
            'response' => $token,
        ];

        // remoteip is optional to Google; let operators drop it (return empty)
        // for data minimization.
        $remoteIp = apply_filters('fluent_affiliate/recaptcha_remoteip', $this->getIpAddress(), $settings);
        if (!empty($remoteIp)) {
            $params['remoteip'] = $remoteIp;
        }

        $result = $this->remoteVerify(self::VERIFY_URL, $params);

        // Fail closed: an anti-spam gate should deny when it cannot verify.
        if (empty($result['success'])) {
            return false;
        }

        if ($this->getVersion($settings) === 'v3_invisible') {
            // Reject a token minted for a different action on the same site key.
            if (Arr::get($result, 'action') !== self::V3_ACTION) {
                return false;
            }

            $threshold = (float) apply_filters(
                'fluent_affiliate/recaptcha_v3_ref_score',
                (float) Arr::get($settings, 'v3_score_threshold', 0.5)
            );
            $score = isset($result['score']) ? (float) $result['score'] : 0;

            return $score >= $threshold;
        }

        return true;
    }

    public function validateCredentials($settings, $token)
    {
        $secret = $this->getSecretKey($settings);

        if (empty($secret)) {
            return [
                'valid'   => false,
                'message' => __('Enter a Secret Key first.', 'fluent-affiliate-pro'),
            ];
        }

        if (empty($token)) {
            return [
                'valid'   => false,
                'message' => __('Solve the reCAPTCHA challenge to validate your keys.', 'fluent-affiliate-pro'),
            ];
        }

        $result = $this->remoteVerify(self::VERIFY_URL, [
            'secret'   => $secret,
            'response' => $token,
        ]);

        if ($result === null) {
            return [
                'valid'   => false,
                'message' => __('Could not reach Google to validate the keys. Check your connection and try again.', 'fluent-affiliate-pro'),
            ];
        }

        if (!empty($result['success'])) {
            return [
                'valid'   => true,
                'message' => __('Both keys are valid.', 'fluent-affiliate-pro'),
            ];
        }

        // Distinguish a bad secret from a site/secret mismatch or spent token.
        $errorCodes = (array) Arr::get($result, 'error-codes', []);

        if (in_array('invalid-input-secret', $errorCodes, true)) {
            return [
                'valid'   => false,
                'message' => __('Invalid Secret Key.', 'fluent-affiliate-pro'),
            ];
        }

        return [
            'valid'   => false,
            'message' => __('The Site Key and Secret Key do not match, or the challenge was invalid. Re-check both keys and try again.', 'fluent-affiliate-pro'),
        ];
    }

    public function credentialFingerprint($settings)
    {
        return md5(implode('|', [
            $this->getVersion($settings),
            $this->getSiteKey($settings),
            $this->getSecretKey($settings),
        ]));
    }

    private function getVersion($settings)
    {
        return Arr::get($settings, 'version', 'v2_visible');
    }

    private function getSiteKey($settings)
    {
        $prefix = $this->getVersion($settings) === 'v3_invisible' ? 'v3' : 'v2';

        return Arr::get($settings, $prefix . '_site_key', '');
    }

    private function getSecretKey($settings)
    {
        $prefix = $this->getVersion($settings) === 'v3_invisible' ? 'v3' : 'v2';
        $stored = Arr::get($settings, $prefix . '_secret_key', '');

        return $stored ? Helper::encryptDecrypt($stored, 'd') : '';
    }

    private function renderV2($siteKey)
    {
        wp_enqueue_script('google-recaptcha', 'https://www.google.com/recaptcha/api.js', [], null, true);
        ?>
        <div class="fa_form-group fa_recaptcha_group">
            <div class="g-recaptcha" data-sitekey="<?php echo esc_attr($siteKey); ?>"></div>
        </div>
        <?php
    }

    private function renderV3($siteKey)
    {
        wp_enqueue_script(
            'google-recaptcha',
            'https://www.google.com/recaptcha/api.js?render=' . rawurlencode($siteKey),
            [],
            null,
            true
        );
        ?>
        <input type="hidden" name="g-recaptcha-response" id="fa_recaptcha_v3_token" value=""/>
        <?php
        wp_add_inline_script('google-recaptcha', $this->v3InlineScript($siteKey));
    }

    /**
     * Mint a fresh v3 token on submit (capture-phase), then re-dispatch — avoids
     * the stale-token reject a background timer causes (v3 tokens expire at 120s).
     */
    private function v3InlineScript($siteKey)
    {
        $siteKey = esc_js($siteKey);
        $action  = esc_js(self::V3_ACTION);

        return <<<JS
        (function () {
            var form = document.getElementById('fa_user_registration_form');
            if (!form) { return; }

            var siteKey = '{$siteKey}';
            var action = '{$action}';
            var tokenReady = false;

            // Capture phase: run before core's bubble-phase submit handler.
            form.addEventListener('submit', function (e) {
                // Second pass: token already injected, let the core handler proceed.
                if (tokenReady) {
                    tokenReady = false;
                    return;
                }

                e.preventDefault();
                e.stopImmediatePropagation();

                // Script not ready yet; user can retry once it loads.
                if (typeof grecaptcha === 'undefined' || !grecaptcha.execute) {
                    return;
                }

                grecaptcha.ready(function () {
                    grecaptcha.execute(siteKey, { action: action }).then(function (token) {
                        var input = document.getElementById('fa_recaptcha_v3_token');
                        if (input) {
                            input.value = token;
                        }

                        tokenReady = true;

                        if (form.requestSubmit) {
                            form.requestSubmit();
                        } else {
                            form.dispatchEvent(new Event('submit', { cancelable: true }));
                        }
                    });
                });
            }, true);
        })();
        JS;
    }
}
