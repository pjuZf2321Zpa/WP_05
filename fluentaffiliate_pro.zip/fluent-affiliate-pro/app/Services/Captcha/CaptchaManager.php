<?php

namespace FluentAffiliatePro\App\Services\Captcha;

use FluentAffiliate\App\Helper\Utility;
use FluentAffiliate\Framework\Support\Arr;

class CaptchaManager
{
    const OPTION_KEY = '_captcha_settings';

    // Option storing the fingerprint of the last keys that passed "Validate Keys".
    const VALIDATED_KEY = '_captcha_validated_fingerprint';

    private static $providersCache = null;

    public static function getProviders()
    {
        if (self::$providersCache !== null) {
            return self::$providersCache;
        }

        $providers = [];

        $registered = apply_filters('fluent_affiliate/captcha_providers', [
            'recaptcha' => new RecaptchaProvider(),
        ]);

        foreach ($registered as $provider) {
            if ($provider instanceof AbstractCaptchaProvider) {
                $providers[$provider->getKey()] = $provider;
            }
        }

        return self::$providersCache = $providers;
    }

    public static function getProvider($key)
    {
        $providers = self::getProviders();

        return isset($providers[$key]) ? $providers[$key] : null;
    }

    public static function getSettings()
    {
        $stored = Utility::getOption(self::OPTION_KEY, []);

        if (!is_array($stored)) {
            $stored = [];
        }

        $providers = self::getProviders();

        $providerSettings = [];
        foreach ($providers as $key => $provider) {
            $providerSettings[$key] = wp_parse_args(
                (array) Arr::get($stored, 'providers.' . $key, []),
                $provider->getDefaults()
            );
        }

        $active = Arr::get($stored, 'active_provider');
        if (!isset($providers[$active])) {
            $active = self::firstProviderKey($providers);
        }

        return [
            'enabled'         => Arr::get($stored, 'enabled') === 'yes' ? 'yes' : 'no',
            'active_provider' => $active,
            'providers'       => $providerSettings,
        ];
    }

    public static function getDisplaySettings()
    {
        $settings  = self::getSettings();
        $providers = self::getProviders();

        foreach ((array) Arr::get($settings, 'providers', []) as $key => $providerSettings) {
            if (isset($providers[$key])) {
                $settings['providers'][$key] = $providers[$key]->maskSecrets($providerSettings);
            }
        }

        return $settings;
    }

    private static function storedProviderSettings($key)
    {
        $stored = Utility::getOption(self::OPTION_KEY, []);

        return (array) Arr::get($stored, 'providers.' . $key, []);
    }

    public static function save($input)
    {
        if (!is_array($input)) {
            $input = [];
        }

        $providers = self::getProviders();

        $cleanProviders = [];
        foreach ($providers as $key => $provider) {
            $cleanProviders[$key] = $provider->sanitize(
                (array) Arr::get($input, 'providers.' . $key, []),
                self::storedProviderSettings($key)
            );
        }

        $active = Arr::get($input, 'active_provider');
        if (!isset($providers[$active])) {
            $active = self::firstProviderKey($providers);
        }

        $clean = [
            'enabled'         => Arr::get($input, 'enabled') === 'yes' ? 'yes' : 'no',
            'active_provider' => $active,
            'providers'       => $cleanProviders,
        ];

        Utility::updateOption(self::OPTION_KEY, $clean);

        return self::getSettings();
    }

    public static function isEnabled()
    {
        $settings = self::getSettings();

        if (Arr::get($settings, 'enabled') !== 'yes') {
            return false;
        }

        $provider = self::getProvider($settings['active_provider']);

        return $provider && $provider->isConfigured(self::activeProviderSettings($settings));
    }

    public static function renderActive()
    {
        if (!self::isEnabled()) {
            return;
        }

        $settings = self::getSettings();
        $provider = self::getProvider($settings['active_provider']);

        if ($provider) {
            $provider->render(self::activeProviderSettings($settings));
        }
    }

    public static function verifyActive($request)
    {
        $settings = self::getSettings();
        $provider = self::getProvider($settings['active_provider']);

        if (!$provider) {
            return false;
        }

        return $provider->verify(self::activeProviderSettings($settings), $request);
    }

    public static function validateCredentials($providerKey, $input, $token)
    {
        $provider = self::getProvider($providerKey);

        if (!$provider) {
            return [
                'valid'   => false,
                'message' => __('Unknown captcha provider.', 'fluent-affiliate-pro'),
            ];
        }

        $settings = $provider->sanitize((array) $input, self::storedProviderSettings($providerKey));
        $result   = $provider->validateCredentials($settings, $token);

        // Remember which keys passed so save() can require a validated pair.
        if (!empty($result['valid'])) {
            Utility::updateOption(self::VALIDATED_KEY, $provider->credentialFingerprint($settings));
        }

        return $result;
    }

    public static function isValidatedPayload($input)
    {
        $activeKey = Arr::get($input, 'active_provider');
        $provider  = self::getProvider($activeKey);

        if (!$provider) {
            return false;
        }

        $providerSettings = $provider->sanitize(
            (array) Arr::get($input, 'providers.' . $activeKey, []),
            self::storedProviderSettings($activeKey)
        );
        $stored           = Utility::getOption(self::VALIDATED_KEY);

        return $stored && $stored === $provider->credentialFingerprint($providerSettings);
    }

    public static function isActiveValidated($settings)
    {
        $provider = self::getProvider(Arr::get($settings, 'active_provider'));

        if (!$provider) {
            return false;
        }

        $stored = Utility::getOption(self::VALIDATED_KEY);

        return $stored && $stored === $provider->credentialFingerprint(self::activeProviderSettings($settings));
    }

    public static function getErrorMessage()
    {
        $settings = self::getSettings();

        $message = Arr::get(self::activeProviderSettings($settings), 'error_message');
        if ($message) {
            return $message;
        }

        // Fall back to the provider's own default — getDefaults() owns the string.
        $provider = self::getProvider($settings['active_provider']);

        return $provider ? Arr::get($provider->getDefaults(), 'error_message', '') : '';
    }

    public static function providerList()
    {
        $list = [];
        foreach (self::getProviders() as $provider) {
            $list[] = [
                'key'   => $provider->getKey(),
                'title' => $provider->getTitle(),
            ];
        }

        return $list;
    }

    private static function activeProviderSettings($settings)
    {
        return (array) Arr::get($settings, 'providers.' . $settings['active_provider'], []);
    }

    private static function firstProviderKey($providers)
    {
        $keys = array_keys($providers);

        return $keys ? $keys[0] : 'recaptcha';
    }
}
