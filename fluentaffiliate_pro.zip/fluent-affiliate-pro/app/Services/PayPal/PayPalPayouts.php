<?php

namespace FluentAffiliatePro\App\Services\PayPal;

use FluentAffiliate\App\Helper\Utility;
use FluentAffiliate\App\Models\Payout;
use FluentAffiliate\App\Models\Referral;
use FluentAffiliate\App\Models\Transaction;
use FluentAffiliate\Framework\Support\Arr;

/**
 * Sends a payout through PayPal Payouts and syncs the results back. The free
 * plugin creates the payout and owns its rows; this class moves a PayPal
 * payout through processing → sending → processing (with a batch ID) and
 * settles each transaction from the status PayPal reports.
 */
class PayPalPayouts
{
    const METHOD = 'paypal_payouts';

    const SEND_ACTION = 'fluent_affiliate_pro/paypal_send';

    const SYNC_ACTION = 'fluent_affiliate_pro/paypal_sync';

    // PayPal sends one webhook per payment, mostly within seconds, so one
    // delayed sync covers the whole burst
    const WEBHOOK_SYNC_DELAY = 30;

    // a real burst needs one check per batch, because a pending sync skips the rest
    const WEBHOOK_CHECKS_PER_MINUTE = 30;

    // PayPal accepts up to 15,000 items in one batch
    const MAX_ITEMS = 15000;

    // the job died if a payout stays "sending" this long, so the hourly job sends it again
    const SEND_TIMEOUT = 900;

    const ZERO_DECIMAL = ['HUF', 'JPY', 'TWD'];

    const CURRENCIES = [
        'AUD', 'BRL', 'CAD', 'CHF', 'CNY', 'CZK', 'DKK', 'EUR', 'GBP', 'HKD', 'HUF', 'ILS',
        'JPY', 'MXN', 'MYR', 'NOK', 'NZD', 'PHP', 'PLN', 'SEK', 'SGD', 'THB', 'TWD', 'USD',
    ];

    public static function isAvailable()
    {
        return Utility::getReferralSetting('payout_method') === 'paypal'
            && PayPalSettings::isConfigured(PayPalSettings::get()['mode']);
    }

    public static function isPayPalPayout($payout)
    {
        return $payout && $payout->payout_method === self::METHOD && Arr::get((array) $payout->settings, 'gateway');
    }

    public static function filterMethods($methods)
    {
        if (self::isAvailable()) {
            $methods[self::METHOD] = __('PayPal Payouts', 'fluent-affiliate-pro');
        }

        return $methods;
    }

    /**
     * Leaves out affiliates without a valid PayPal email, so "Create payout"
     * never claims referrals PayPal cannot pay. Their referrals stay unpaid.
     */
    public static function filterValidatedConfig($validated, $config)
    {
        if (!is_array($validated) || Arr::get($validated, 'config.payout_method') !== self::METHOD) {
            return $validated;
        }

        $affiliates = $validated['payable_affiliates'];

        $payable = $affiliates->filter(function ($affiliate) {
            return is_email($affiliate->payment_email);
        })->values();

        $skipped = $affiliates->reject(function ($affiliate) {
            return is_email($affiliate->payment_email);
        })->values();

        // an empty array, not an empty collection, so processPayout() reports "no affiliates"
        $validated['payable_affiliates'] = $payable->isEmpty() ? [] : $payable;
        $validated['payable_total_amount'] = $payable->sum('total_payable_amount');
        $validated['skipped'] = [
            'count'        => $skipped->count(),
            'total_amount' => $skipped->sum('total_payable_amount'),
            'affiliates'   => $skipped,
        ];

        return $validated;
    }

    /**
     * Checks the payout and hands it to the send job. One conditional update
     * moves it from processing to sending, so a double click sends it once.
     *
     * @return true|\WP_Error
     */
    public static function startSend($payoutId)
    {
        $payout = Payout::query()->find($payoutId);

        if (!self::isPayPalPayout($payout)) {
            return new \WP_Error('not_paypal', __('This payout is not a PayPal payout.', 'fluent-affiliate-pro'));
        }

        // after 30 days PayPal accepts the same batch ID again, so a resend could pay twice
        if (Arr::get((array) $payout->settings, 'payout_batch_id')) {
            return new \WP_Error('already_sent', __('This payout was already sent to PayPal.', 'fluent-affiliate-pro'));
        }

        if (Arr::get((array) $payout->settings, 'batch_lost') && !self::canResendUnconfirmed($payout)) {
            return new \WP_Error('batch_lost', __('PayPal may already have this payout. Add its PayPal batch ID instead of sending it again.', 'fluent-affiliate-pro'));
        }

        $mode = PayPalSettings::get()['mode'];
        if (!PayPalSettings::isConfigured($mode)) {
            return new \WP_Error('paypal_not_configured', __('Add the PayPal API keys first.', 'fluent-affiliate-pro'));
        }

        $transactions = Transaction::query()
            ->where('payout_id', $payout->id)
            ->where('status', 'processing')
            ->get();

        if ($transactions->isEmpty()) {
            return new \WP_Error('nothing_to_send', __('This payout has no transactions to send.', 'fluent-affiliate-pro'));
        }

        if ($transactions->count() > self::MAX_ITEMS) {
            return new \WP_Error('too_many_items', sprintf(
                /* translators: %d: maximum number of payments in one PayPal payout */
                __('PayPal can send at most %d payments in one payout. Split this payout into smaller payouts.', 'fluent-affiliate-pro'),
                self::MAX_ITEMS
            ));
        }

        $currency = strtoupper($transactions->first()->currency ?: Utility::getCurrency());

        // amounts in different currencies were added together, so the sums are wrong (audit M-8)
        $currencies = Referral::query()
            ->where('payout_id', $payout->id)
            ->whereNotNull('currency')
            ->where('currency', '!=', '')
            ->distinct()
            ->pluck('currency')
            ->map(function ($code) {
                return strtoupper($code);
            })
            ->push($currency)
            ->unique();

        if ($currencies->count() > 1) {
            return new \WP_Error('mixed_currencies', __('The referrals in this payout use more than one currency. PayPal can send one currency in one payout.', 'fluent-affiliate-pro'));
        }

        if (!in_array($currency, self::CURRENCIES, true)) {
            return new \WP_Error('currency_not_supported', sprintf(
                /* translators: %s: currency code, for example USD */
                __('PayPal does not support the currency %s.', 'fluent-affiliate-pro'),
                $currency
            ));
        }

        $claimed = Payout::query()
            ->where('id', $payout->id)
            ->where('status', 'processing')
            ->where('payout_method', self::METHOD)
            ->update(['status' => 'sending']);

        if (!$claimed) {
            return new \WP_Error('already_sending', __('This payout is already being sent.', 'fluent-affiliate-pro'));
        }

        self::updateSettings($payout->id, [
            'paypal_mode'   => $mode,
            'sending_at'    => time(),
            // the resend window of an unconfirmed send counts from the first try
            'first_send_at'   => Arr::get((array) $payout->settings, 'first_send_at') ?: time(),
            // fixed at the first try, so a later send carries the same ID even after the site URL changes
            'sender_batch_id' => self::batchKey($payout),
            'paypal_error'    => '',
        ]);

        as_enqueue_async_action(self::SEND_ACTION, [$payout->id], 'fluent-affiliate');

        return true;
    }

    /**
     * The send job. A timeout or a lost response is safe to retry: the batch
     * ID and the request ID are fixed per payout, so PayPal pays only once
     * and answers a repeat with the original batch.
     */
    public static function runSend($payoutId)
    {
        $payout = Payout::query()->find($payoutId);

        if (!self::isPayPalPayout($payout) || $payout->status !== 'sending') {
            return;
        }

        if (Arr::get((array) $payout->settings, 'payout_batch_id')) {
            self::endSend($payout->id);
            return;
        }

        $mode = Arr::get((array) $payout->settings, 'paypal_mode', PayPalSettings::get()['mode']);
        $siteName = wp_specialchars_decode(get_bloginfo('name'), ENT_QUOTES);

        $transactions = Transaction::query()
            ->with('affiliate')
            ->where('payout_id', $payout->id)
            ->where('status', 'processing')
            ->get();

        $items = [];
        foreach ($transactions as $transaction) {
            $email = $transaction->affiliate ? $transaction->affiliate->payment_email : '';

            // one malformed receiver makes PayPal refuse the whole batch
            if (!is_email($email)) {
                self::failTransaction($transaction, __('The affiliate has no valid PayPal email.', 'fluent-affiliate-pro'));
                continue;
            }

            $items[] = [
                'recipient_type' => 'EMAIL',
                'receiver'       => $email,
                'amount'         => [
                    'value'    => self::formatAmount($transaction->total_amount, $transaction->currency),
                    'currency' => strtoupper($transaction->currency),
                ],
                'sender_item_id' => self::senderItemId($transaction->id),
                /* translators: %s: site name */
                'note'           => sprintf(__('Affiliate commission from %s', 'fluent-affiliate-pro'), $siteName),
            ];
        }

        if (!$items) {
            self::endSend($payout->id, __('No transaction in this payout can be sent.', 'fluent-affiliate-pro'));
            return;
        }

        $batchKey = self::batchKey($payout);

        // PayPal refuses a repeated sender_batch_id for 30 days only. A retry that
        // comes later (a send job restarted after the scheduler was down) could pay
        // twice, so it locks the payout for the admin to check in PayPal instead.
        $firstPost = (int) Arr::get((array) $payout->settings, 'first_post_at');
        if ($firstPost && $firstPost < time() - 29 * DAY_IN_SECONDS) {
            self::updateSettings($payout->id, ['batch_lost' => true, 'send_unconfirmed' => true]);
            self::endSend($payout->id, __('This payout was sent to PayPal more than 29 days ago, so it is not sent again. Check the payout in your PayPal account. If it is there, add its batch ID. If it is not there, mark it as not in PayPal.', 'fluent-affiliate-pro'));
            return;
        }

        if (!$firstPost) {
            self::updateSettings($payout->id, ['first_post_at' => time()]);
        }

        $response = PayPalApi::request($mode, 'POST', '/v1/payments/payouts', [
            'sender_batch_header' => [
                'sender_batch_id' => $batchKey,
                'recipient_type'  => 'EMAIL',
                /* translators: %s: site name */
                'email_subject'   => sprintf(__('You have a payment from %s', 'fluent-affiliate-pro'), $siteName),
                'email_message'   => __('You received an affiliate commission payment.', 'fluent-affiliate-pro'),
            ],
            'items'               => $items,
        ], ['PayPal-Request-Id' => $batchKey]);

        self::log($payout->id, 'send', $response);

        $batchId = is_wp_error($response)
            ? self::batchIdFromDuplicate($response)
            : Arr::get($response, 'batch_header.payout_batch_id');

        if ($batchId) {
            self::updateSettings($payout->id, ['payout_batch_id' => $batchId, 'batch_lost' => false, 'send_unconfirmed' => false]);
            self::endSend($payout->id);
            return;
        }

        // PayPal has the batch from an earlier try whose reply was lost, and its
        // duplicate error carries no link to it (checked in the sandbox). The flag
        // keeps the rows locked until the admin adds the batch ID.
        if (self::isDuplicateBatch($response)) {
            self::updateSettings($payout->id, ['batch_lost' => true, 'send_unconfirmed' => false]);
            self::endSend($payout->id, __('PayPal already has this payout, but its batch ID did not come back. Add the PayPal batch ID to get the payment status.', 'fluent-affiliate-pro'));
            return;
        }

        // a 2xx is PayPal taking the batch, so a reply without its ID (a broken
        // body) locks the rows like a lost answer, and a send again stays safe
        if (!is_wp_error($response)) {
            self::updateSettings($payout->id, ['batch_lost' => true, 'send_unconfirmed' => true]);
            self::endSend($payout->id, __('PayPal took the payout, but its batch ID did not come back. Check the payout in your PayPal account, then add its batch ID.', 'fluent-affiliate-pro'));
            return;
        }

        // no answer, or a server error: PayPal may have made the batch, so the rows
        // lock now. A send again stays safe while PayPal refuses a repeated batch ID.
        if (self::isMaybeSent($response)) {
            self::updateSettings($payout->id, ['batch_lost' => true, 'send_unconfirmed' => true]);
            self::endSend($payout->id, __('PayPal did not answer, so the payout may be sent. Check the payout in your PayPal account. If it is there, add its batch ID. If it is not there, send it again.', 'fluent-affiliate-pro') . ' (' . $response->get_error_message() . ')');
            return;
        }

        self::endSend($payout->id, self::errorMessage($response));
    }

    /**
     * The way out of an unconfirmed send once a send again is no longer safe.
     * The admin checked the PayPal account and the payout is not there, so its
     * open rows fail: the admin can then pay them by hand or remove them.
     *
     * @return true|\WP_Error
     */
    public static function markNotSent($payout)
    {
        $settings = (array) $payout->settings;

        if (!Arr::get($settings, 'batch_lost') || !Arr::get($settings, 'send_unconfirmed') || Arr::get($settings, 'payout_batch_id') || $payout->status !== 'processing') {
            return new \WP_Error('not_unconfirmed', __('Only a payout that PayPal may not have can be marked as not in PayPal.', 'fluent-affiliate-pro'));
        }

        // while a send again is safe, it finds out the truth itself; a wrong
        // "not in PayPal" could let the same referrals be paid twice
        if (self::canResendUnconfirmed($payout)) {
            return new \WP_Error('send_again_first', __('Send the payout again instead. PayPal refuses it if it already has the payout.', 'fluent-affiliate-pro'));
        }

        $transactions = Transaction::query()
            ->where('payout_id', $payout->id)
            ->where('status', 'processing')
            ->get();

        foreach ($transactions as $transaction) {
            self::failTransaction($transaction, __('PayPal did not get this payout. An admin checked the PayPal account.', 'fluent-affiliate-pro'));
        }

        self::updateSettings($payout->id, [
            'batch_lost'       => false,
            'send_unconfirmed' => false,
            'marked_not_sent'  => time(),
            'paypal_error'     => '',
        ]);

        self::log($payout->id, 'not_sent', []);

        $fresh = Payout::query()->find($payout->id);
        if ($fresh) {
            $fresh->recountPaymentTotal();
        }

        return true;
    }

    /**
     * Saves the batch ID of a lost batch and settles the rows from it. The batch
     * must carry this payout's sender_batch_id, so a wrong ID never settles a row.
     *
     * @return true|\WP_Error
     */
    public static function recoverBatch($payout, $batchId)
    {
        $settings = (array) $payout->settings;

        if (!Arr::get($settings, 'batch_lost') || Arr::get($settings, 'payout_batch_id') || $payout->status !== 'processing') {
            return new \WP_Error('batch_not_lost', __('This payout does not need a PayPal batch ID.', 'fluent-affiliate-pro'));
        }

        if (!preg_match('/^[A-Z0-9]{8,30}$/i', $batchId)) {
            return new \WP_Error('invalid_batch_id', __('Enter a valid PayPal batch ID. It has letters and digits only.', 'fluent-affiliate-pro'));
        }

        $mode = Arr::get($settings, 'paypal_mode', PayPalSettings::get()['mode']);
        $response = PayPalApi::request($mode, 'GET', '/v1/payments/payouts/' . rawurlencode($batchId) . '?page_size=1');

        self::log($payout->id, 'recover', $response);

        if (is_wp_error($response)) {
            return $response;
        }

        if (Arr::get($response, 'batch_header.sender_batch_header.sender_batch_id') !== self::batchKey($payout)) {
            return new \WP_Error('batch_mismatch', __('This PayPal batch does not belong to this payout. Check the batch ID in your PayPal account.', 'fluent-affiliate-pro'));
        }

        self::updateSettings($payout->id, [
            'payout_batch_id' => (string) Arr::get($response, 'batch_header.payout_batch_id', $batchId),
            'batch_lost'       => false,
            'send_unconfirmed' => false,
            'paypal_error'     => '',
        ]);

        return self::sync(Payout::query()->find($payout->id));
    }

    /**
     * Reads the batch from PayPal and settles each transaction. The webhook,
     * the hourly job and "Check now" all call this, so it must be idempotent.
     *
     * @return true|\WP_Error
     */
    public static function sync($payout)
    {
        $settings = (array) $payout->settings;
        $batchId = Arr::get($settings, 'payout_batch_id');

        if (!$batchId) {
            return new \WP_Error('not_sent', __('This payout was not sent to PayPal yet.', 'fluent-affiliate-pro'));
        }

        $mode = Arr::get($settings, 'paypal_mode', PayPalSettings::get()['mode']);
        $items = [];
        $batchStatus = '';
        $page = 1;

        do {
            $response = PayPalApi::request($mode, 'GET', '/v1/payments/payouts/' . rawurlencode($batchId) . '?' . http_build_query([
                'page'           => $page,
                'page_size'      => 1000,
                'total_required' => 'true',
            ]));

            if (is_wp_error($response)) {
                self::log($payout->id, 'sync', $response);
                return $response;
            }

            $batchStatus = (string) Arr::get($response, 'batch_header.batch_status');
            $items = array_merge($items, (array) Arr::get($response, 'items', []));
            $totalPages = max(1, (int) Arr::get($response, 'total_pages', 1));
            $page++;
        } while ($page <= $totalPages);

        self::log($payout->id, 'sync', $response);

        $transactions = Transaction::query()->where('payout_id', $payout->id)->get()->keyBy('id');

        foreach ($items as $item) {
            $transaction = $transactions->get(self::transactionIdFromSenderItem(Arr::get($item, 'payout_item.sender_item_id')));
            if ($transaction) {
                self::applyItem($transaction, $item);
            }
        }

        // a denied batch can come without items
        if ($batchStatus === 'DENIED' && !$items) {
            foreach ($transactions as $transaction) {
                self::failTransaction($transaction, __('PayPal denied this payout.', 'fluent-affiliate-pro'));
            }
        }

        $fresh = Payout::query()->find($payout->id);
        if ($fresh) {
            $fresh->recountPaymentTotal();
        }

        return true;
    }

    /**
     * The webhook listener. Nothing in the event body is trusted: the
     * signature is checked with PayPal, and the status is read from the API.
     * The event only triggers a sync of its batch, which runs in the background.
     */
    public static function maybeHandleWebhook()
    {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- public PayPal endpoint, verified by its signature below
        if (!isset($_GET['fa_paypal_payouts_webhook'])) {
            return;
        }

        $raw = (string) file_get_contents('php://input');
        $event = json_decode($raw, true);

        // ignore unknown requests without a call to PayPal
        if (!is_array($event) || !in_array(Arr::get($event, 'event_type'), PayPalApi::WEBHOOK_EVENTS, true)) {
            self::respond(200);
        }

        $batchId = Arr::get($event, 'resource.payout_batch_id') ?: Arr::get($event, 'resource.batch_header.payout_batch_id');
        $payout = self::findByBatchId($batchId);

        // no check is needed when the event can change nothing: its batch is not
        // a payout of this site (PayPal sends every event of the account to every
        // site that shares it), or a queued sync of it reads every item anyway
        if (!$payout || self::hasPendingSync($payout->id)) {
            self::respond(200);
        }

        if (!self::verifyWebhook($raw)) {
            self::respond(400);
        }

        as_schedule_single_action(time() + self::WEBHOOK_SYNC_DELAY, self::SYNC_ACTION, [$payout->id], 'fluent-affiliate');

        self::respond(200);
    }

    /**
     * The queued sync of one payout, from the webhook.
     */
    public static function runSync($payoutId)
    {
        $payout = Payout::query()->find($payoutId);

        if (self::isPayPalPayout($payout) && Arr::get((array) $payout->settings, 'payout_batch_id')) {
            self::sync($payout);
        }
    }

    /**
     * Pending only: a sync that is already running may have read an item
     * before this event changed it, so a new event then queues one more.
     */
    protected static function hasPendingSync($payoutId)
    {
        return (bool) as_get_scheduled_actions([
            'hook'     => self::SYNC_ACTION,
            'args'     => [(int) $payoutId],
            'group'    => 'fluent-affiliate',
            'status'   => \ActionScheduler_Store::STATUS_PENDING,
            'per_page' => 1,
        ], 'ids');
    }

    /**
     * The fallback for a send job that died, and for lost webhook events of a
     * payout sent in the last day, when most results come in. A site the
     * webhook cannot reach (local, staging, a firewall) stays current there.
     */
    public static function runHourly()
    {
        // stuck sends have their own query, so no other payout can push them out
        $sending = Payout::query()
            ->where('payout_method', self::METHOD)
            ->where('status', 'sending')
            ->get();

        foreach ($sending as $payout) {
            $stale = (int) Arr::get((array) $payout->settings, 'sending_at') < time() - self::SEND_TIMEOUT;
            if ($stale && !as_has_scheduled_action(self::SEND_ACTION, [$payout->id], 'fluent-affiliate')) {
                as_enqueue_async_action(self::SEND_ACTION, [$payout->id], 'fluent-affiliate');
            }
        }

        // a payout sent in the last day was saved in the last day. Other payouts
        // saved then (the daily sync logs to 50) are skipped by isRecentSend(),
        // so the list is not cut by a small limit that they could fill.
        // ponytail: capped at 500 per hour; a queued sync per payout if a site sends more
        $recent = self::openBatchPayouts()
            ->where('updated_at', '>=', gmdate('Y-m-d H:i:s', current_time('timestamp') - DAY_IN_SECONDS))
            ->orderBy('id', 'DESC')
            ->limit(500)
            ->get();

        foreach ($recent as $payout) {
            if (self::isRecentSend($payout) && self::isPayPalPayout($payout)) {
                self::sync($payout);
            }
        }
    }

    /**
     * The fallback for older open payouts, mostly unclaimed payments that wait
     * at PayPal for up to 30 days. Their status changes rarely, so once a day.
     * Each sync saves its log entry, which moves updated_at, so the oldest go
     * first and the list rotates when more than 50 payouts wait.
     */
    public static function runDaily()
    {
        $payouts = self::openBatchPayouts()
            ->orderBy('updated_at', 'ASC')
            ->limit(50)
            ->get();

        foreach ($payouts as $payout) {
            if (!self::isRecentSend($payout) && self::isPayPalPayout($payout)) {
                self::sync($payout);
            }
        }
    }

    /**
     * Sent payouts with open rows. A payout kept processing by failed or unsent
     * rows has no work to sync, so it is not selected.
     */
    protected static function openBatchPayouts()
    {
        return Payout::query()
            ->where('payout_method', self::METHOD)
            ->where('status', 'processing')
            ->where('settings', 'LIKE', '%"payout_batch_id";s:%')
            ->where('settings', 'NOT LIKE', '%"payout_batch_id";s:0:%')
            ->whereHas('transactions', function ($query) {
                $query->where('status', 'processing');
            });
    }

    protected static function isRecentSend($payout)
    {
        return (int) Arr::get((array) $payout->settings, 'sending_at') > time() - DAY_IN_SECONDS;
    }

    public static function formatAmount($amount, $currency)
    {
        $decimals = in_array(strtoupper((string) $currency), self::ZERO_DECIMAL, true) ? 0 : 2;

        return number_format((float) $amount, $decimals, '.', '');
    }

    /**
     * Unique per site as well as per payout: sites that share one PayPal
     * account must never match each other's batches.
     */
    public static function senderBatchId($payoutId)
    {
        return 'fa_' . substr(md5(home_url()), 0, 8) . '_payout_' . (int) $payoutId;
    }

    /**
     * The sender_batch_id this payout was first sent with. PayPal refuses a
     * repeat only for the same ID, so every try must use the saved one. A payout
     * sent before the ID was saved falls back to the computed one.
     */
    protected static function batchKey($payout)
    {
        return (string) Arr::get((array) $payout->settings, 'sender_batch_id') ?: self::senderBatchId($payout->id);
    }

    protected static function senderItemId($transactionId)
    {
        return 'fa_tx_' . (int) $transactionId;
    }

    protected static function transactionIdFromSenderItem($senderItemId)
    {
        return preg_match('/^fa_tx_(\d+)$/', (string) $senderItemId, $match) ? (int) $match[1] : 0;
    }

    protected static function applyItem(Transaction $transaction, $item)
    {
        $status = strtoupper((string) Arr::get($item, 'transaction_status'));
        $fee = Arr::get($item, 'payout_item_fee');

        $previous = (array) $transaction->settings;
        $settings = array_merge($previous, [
            'paypal_item_id' => (string) Arr::get($item, 'payout_item_id'),
            'paypal_status'  => $status,
            'paypal_fee'     => $fee ? ['value' => Arr::get($fee, 'value'), 'currency' => Arr::get($fee, 'currency')] : null,
            'paypal_error'   => (string) Arr::get($item, 'errors.message', ''),
        ]);

        // every sync reads the whole batch, so most items come back unchanged
        $settled = ($status === 'SUCCESS' && $transaction->status === 'paid')
            || (in_array($status, ['FAILED', 'BLOCKED', 'RETURNED'], true) && $transaction->status === 'failed')
            || !in_array($status, ['SUCCESS', 'FAILED', 'BLOCKED', 'RETURNED'], true);
        if ($settings == $previous && $settled) {
            return;
        }

        if ($settings != $previous) {
            Transaction::query()->where('id', $transaction->id)->update(['settings' => maybe_serialize($settings)]);
            $transaction->settings = $settings;
        }

        if ($status === 'SUCCESS') {
            $transaction->markAsPaid();
        } else if (in_array($status, ['FAILED', 'BLOCKED', 'RETURNED'], true)) {
            self::failTransaction($transaction);
        }

        // PENDING, ONHOLD, UNCLAIMED stay processing. REFUNDED comes after SUCCESS
        // and is shown as a warning, so the admin decides. REVERSED is web-upload only.
    }

    protected static function failTransaction(Transaction $transaction, $reason = '')
    {
        // only an open row fails; a paid row never moves back
        $changed = Transaction::query()
            ->where('id', $transaction->id)
            ->where('status', 'processing')
            ->update(['status' => 'failed']);

        if ($changed && $reason) {
            $settings = array_merge((array) $transaction->settings, ['paypal_error' => $reason]);
            Transaction::query()->where('id', $transaction->id)->update(['settings' => maybe_serialize($settings)]);
        }
    }

    protected static function endSend($payoutId, $error = '')
    {
        Payout::query()->where('id', $payoutId)->where('status', 'sending')->update(['status' => 'processing']);

        self::updateSettings($payoutId, ['paypal_error' => $error]);

        $payout = Payout::query()->find($payoutId);
        if ($payout) {
            $payout->recountPaymentTotal();
        }
    }

    protected static function batchIdFromDuplicate(\WP_Error $error)
    {
        foreach ((array) Arr::get((array) $error->get_error_data(), 'links', []) as $link) {
            if (preg_match('#/v1/payments/payouts/([A-Z0-9]+)$#i', (string) Arr::get($link, 'href'), $match)) {
                return $match[1];
            }
        }

        return '';
    }

    /**
     * True when the request may have reached PayPal: no HTTP answer, or a 5xx.
     * A failure before the request left, or a DNS or connect error, is not.
     */
    protected static function isMaybeSent($response)
    {
        if (!is_wp_error($response)) {
            return false;
        }

        $data = (array) $response->get_error_data();
        if (!empty($data['not_sent']) || preg_match('/cURL error (6|7):/', $response->get_error_message())) {
            return false;
        }

        $status = (int) Arr::get($data, 'status');

        return $status === 0 || $status >= 500;
    }

    /**
     * Tells the payout page whether a send again is still safe, from the server
     * clock, so a skewed browser clock or an old page never shows a refused button.
     */
    public static function addPayoutDetails($payout)
    {
        if (self::isPayPalPayout($payout)) {
            $payout->paypal_can_send_again = self::canResendUnconfirmed($payout);
        }

        return $payout;
    }

    /**
     * After 30 days PayPal accepts the same sender_batch_id again, so a send
     * again could then pay twice. One day short of that, for clock drift.
     */
    protected static function canResendUnconfirmed($payout)
    {
        $settings = (array) $payout->settings;
        // PayPal's 30 days count from the first request it got; first_send_at is the older fallback
        $firstSend = (int) (Arr::get($settings, 'first_post_at') ?: Arr::get($settings, 'first_send_at'));

        return Arr::get($settings, 'send_unconfirmed') && $firstSend && $firstSend > time() - 29 * DAY_IN_SECONDS;
    }

    protected static function isDuplicateBatch($response)
    {
        if (!is_wp_error($response)) {
            return false;
        }

        // the sandbox puts a sentence in the issue field, the docs name a code; both name sender_batch_id
        return stripos((string) Arr::get((array) $response->get_error_data(), 'issue'), 'sender_batch_id') !== false;
    }

    protected static function errorMessage($error)
    {
        if (!is_wp_error($error)) {
            return __('PayPal did not return a payout batch.', 'fluent-affiliate-pro');
        }

        $status = (int) Arr::get((array) $error->get_error_data(), 'status');

        if ($status === 403 || in_array($error->get_error_code(), ['AUTHORIZATION_ERROR', 'NOT_AUTHORIZED', 'PERMISSION_DENIED'], true)) {
            return __('Payouts is not enabled on this PayPal account. Turn on Payouts in PayPal, then try again.', 'fluent-affiliate-pro') . ' (' . $error->get_error_message() . ')';
        }

        return $error->get_error_message();
    }

    protected static function verifyWebhook($raw)
    {
        $headers = [];
        foreach (['auth_algo' => 'AUTH_ALGO', 'cert_url' => 'CERT_URL', 'transmission_id' => 'TRANSMISSION_ID', 'transmission_sig' => 'TRANSMISSION_SIG', 'transmission_time' => 'TRANSMISSION_TIME'] as $key => $header) {
            $value = isset($_SERVER['HTTP_PAYPAL_' . $header]) ? sanitize_text_field(wp_unslash($_SERVER['HTTP_PAYPAL_' . $header])) : '';
            if ($value === '') {
                return false;
            }
            $headers[$key] = $value;
        }

        // checks that cost no PayPal call come first, so a forged request is cheap
        $certHost = strtolower((string) wp_parse_url($headers['cert_url'], PHP_URL_HOST));
        if (wp_parse_url($headers['cert_url'], PHP_URL_SCHEME) !== 'https' || !preg_match('/(^|\.)paypal\.com$/', $certHost)) {
            return false;
        }

        if (self::isWebhookThrottled()) {
            self::respond(429);
        }

        $settings = PayPalSettings::get();

        foreach (PayPalSettings::MODES as $mode) {
            if (!$settings[$mode . '_webhook_id'] || !PayPalSettings::isConfigured($mode)) {
                continue;
            }

            // the event goes back as the exact bytes PayPal signed
            $body = substr(wp_json_encode($headers + ['webhook_id' => $settings[$mode . '_webhook_id']]), 0, -1) . ',"webhook_event":' . $raw . '}';
            $result = PayPalApi::request($mode, 'POST', '/v1/notifications/verify-webhook-signature', $body);

            if (!is_wp_error($result) && Arr::get($result, 'verification_status') === 'SUCCESS') {
                return true;
            }
        }

        return false;
    }

    /**
     * At most WEBHOOK_CHECKS_PER_MINUTE signature checks per IP and minute.
     * PayPal retries an event it gets a 429 for, and the hourly sync covers the rest.
     */
    protected static function isWebhookThrottled()
    {
        $ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : '';
        $transient = 'fa_paypal_wh_' . md5($ip . '|' . gmdate('YmdHi'));

        // ponytail: read and write are not atomic, so a burst can pass a few extra; an object-cache incr if that matters
        $count = (int) get_transient($transient);
        if ($count >= self::WEBHOOK_CHECKS_PER_MINUTE) {
            return true;
        }

        set_transient($transient, $count + 1, 2 * MINUTE_IN_SECONDS);

        return false;
    }

    protected static function findByBatchId($batchId)
    {
        if (!$batchId || !preg_match('/^[A-Z0-9]+$/i', $batchId)) {
            return null;
        }

        global $wpdb;

        $payouts = Payout::query()
            ->where('payout_method', self::METHOD)
            ->where('settings', 'LIKE', '%' . $wpdb->esc_like($batchId) . '%')
            ->get();

        foreach ($payouts as $payout) {
            if (Arr::get((array) $payout->settings, 'payout_batch_id') === $batchId) {
                return $payout;
            }
        }

        return null;
    }

    /**
     * Keeps the last 20 PayPal calls for support. Never the token, the secret
     * or a request body.
     */
    protected static function log($payoutId, $action, $response)
    {
        $isError = is_wp_error($response);

        $entry = [
            'time'    => current_time('mysql'),
            'action'  => $action,
            'status'  => $isError ? (int) Arr::get((array) $response->get_error_data(), 'status') : 200,
            'error'   => $isError ? $response->get_error_code() : '',
            'message' => $isError ? $response->get_error_message() : '',
        ];

        $payout = Payout::query()->find($payoutId);
        if (!$payout) {
            return;
        }

        $log = (array) Arr::get((array) $payout->settings, 'paypal_log', []);
        array_unshift($log, $entry);

        self::updateSettings($payoutId, ['paypal_log' => array_slice($log, 0, 20)]);
    }

    protected static function updateSettings($payoutId, $data)
    {
        $payout = Payout::query()->find($payoutId);
        if (!$payout) {
            return;
        }

        $payout->settings = array_merge((array) $payout->settings, $data);
        $payout->save();
    }

    protected static function respond($status)
    {
        status_header($status);
        exit;
    }
}
