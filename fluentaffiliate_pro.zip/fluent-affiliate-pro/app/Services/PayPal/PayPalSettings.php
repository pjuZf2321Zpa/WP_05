<?php

namespace FluentAffiliatePro\App\Services\PayPal;

use FluentAffiliate\App\Helper\Helper;
use FluentAffiliate\App\Helper\Utility;
use FluentAffiliate\App\Models\Meta;
use FluentAffiliate\Framework\Support\Arr;

/**
 * The seller's own PayPal REST app keys for Payouts, one set per mode, kept in
 * one fa_meta option. Secrets are stored encrypted and never leave the server.
 */
class PayPalSettings
{
    const OPTION_KEY = '_paypal_payouts_settings';

    // Placeholder for a stored secret in the admin UI; on save means "unchanged".
    const SECRET_MASK = '__FA_PAYPAL_SECRET__';

    const MODES = ['test', 'live'];

    public static function get()
    {
        $stored = Utility::getOption(self::OPTION_KEY, []);

        return wp_parse_args(is_array($stored) ? $stored : [], [
            'mode'               => 'test',
            'test_client_id'     => '',
            'test_client_secret' => '',
            'test_webhook_id'    => '',
            'live_client_id'     => '',
            'live_client_secret' => '',
            'live_webhook_id'    => '',
        ]);
    }

    public static function getDisplay()
    {
        $settings = self::get();

        foreach (self::MODES as $mode) {
            if ($settings[$mode . '_client_secret']) {
                $settings[$mode . '_client_secret'] = self::SECRET_MASK;
            }
        }

        return $settings;
    }

    /**
     * Cleans the admin input against the stored settings. A field left out of
     * the input keeps its stored value; an empty string clears it. The webhook
     * IDs are never taken from the input.
     */
    public static function sanitize($input, $prev)
    {
        $input = is_array($input) ? $input : [];

        $settings = [
            'mode' => array_key_exists('mode', $input)
                ? (Arr::get($input, 'mode') === 'live' ? 'live' : 'test')
                : $prev['mode'],
        ];

        foreach (self::MODES as $mode) {
            $secret = array_key_exists($mode . '_client_secret', $input)
                ? trim((string) $input[$mode . '_client_secret'])
                : self::SECRET_MASK;

            if ($secret === self::SECRET_MASK) {
                $secret = $prev[$mode . '_client_secret'];
            } else if ($secret !== '') {
                $secret = Helper::encryptDecrypt(sanitize_text_field($secret), 'e');
            }

            $settings[$mode . '_client_id'] = array_key_exists($mode . '_client_id', $input)
                ? sanitize_text_field(trim((string) $input[$mode . '_client_id']))
                : $prev[$mode . '_client_id'];
            $settings[$mode . '_client_secret'] = $secret;
            $settings[$mode . '_webhook_id'] = $prev[$mode . '_webhook_id'];
        }

        return $settings;
    }

    /**
     * A re-typed secret encrypts to a new value, so it counts as changed too.
     */
    public static function keysChanged($settings, $prev, $mode)
    {
        return $settings[$mode . '_client_id'] !== $prev[$mode . '_client_id']
            || $settings[$mode . '_client_secret'] !== $prev[$mode . '_client_secret'];
    }

    public static function save($settings)
    {
        self::forgetChangedTokens($settings);
        Utility::updateOption(self::OPTION_KEY, $settings);
    }

    /**
     * Stores a webhook ID only while the keys it was registered with are still
     * saved. Registering takes several PayPal calls, and a save or "Remove keys"
     * in another request may land meanwhile, so the option is read fresh from
     * the table, not from the request cache, and only the ID is changed.
     *
     * @return bool false when the keys changed or were removed meanwhile
     */
    public static function saveWebhookId($mode, $webhookId, $usedSettings)
    {
        $meta = Meta::where('object_type', 'option')
            ->where('meta_key', self::OPTION_KEY)
            ->first();

        $current = $meta && is_array($meta->value) ? $meta->value : [];

        foreach (['_client_id', '_client_secret'] as $field) {
            if (Arr::get($current, $mode . $field) !== $usedSettings[$mode . $field]) {
                return false;
            }
        }

        $current[$mode . '_webhook_id'] = $webhookId;
        self::save($current);

        return true;
    }

    public static function delete()
    {
        self::forgetChangedTokens(null);
        Utility::deleteOption(self::OPTION_KEY);
    }

    /**
     * Forgets the cached PayPal token of each mode whose keys change or go.
     */
    protected static function forgetChangedTokens($next)
    {
        $prev = self::get();

        foreach (self::MODES as $mode) {
            $same = $next
                && Arr::get($next, $mode . '_client_id') === $prev[$mode . '_client_id']
                && Arr::get($next, $mode . '_client_secret') === $prev[$mode . '_client_secret'];

            if (!$same) {
                list($clientId, $secret) = self::getCredentials($mode, $prev);
                PayPalApi::forgetToken($mode, $clientId, $secret);
            }
        }
    }

    /**
     * @return array [client id, decrypted secret]
     */
    public static function getCredentials($mode, $settings = null)
    {
        $settings = $settings ?: self::get();

        return [
            $settings[$mode . '_client_id'],
            Helper::encryptDecrypt($settings[$mode . '_client_secret'], 'd'),
        ];
    }

    public static function isConfigured($mode)
    {
        list($clientId, $secret) = self::getCredentials($mode);

        return $clientId && $secret;
    }
}
