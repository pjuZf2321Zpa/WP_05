<?php

namespace FluentAffiliatePro\App\Services\PayPal;

use FluentAffiliate\Framework\Support\Arr;

/**
 * A thin PayPal REST client on the WordPress HTTP API, authenticated with the
 * seller's own keys (OAuth2 client credentials). No partner account is needed.
 */
class PayPalApi
{
    // the item events carry the batch ID; the listener reads the real status from the API
    const WEBHOOK_EVENTS = [
        'PAYMENT.PAYOUTS-ITEM.SUCCEEDED',
        'PAYMENT.PAYOUTS-ITEM.FAILED',
        'PAYMENT.PAYOUTS-ITEM.BLOCKED',
        'PAYMENT.PAYOUTS-ITEM.RETURNED',
        'PAYMENT.PAYOUTS-ITEM.UNCLAIMED',
        'PAYMENT.PAYOUTS-ITEM.HELD',
        'PAYMENT.PAYOUTS-ITEM.REFUNDED',
        'PAYMENT.PAYOUTS-ITEM.CANCELED',
        'PAYMENT.PAYOUTSBATCH.DENIED',
        'PAYMENT.PAYOUTSBATCH.SUCCESS',
    ];

    private static $tokens = [];

    // seconds each token is valid, from PayPal's answer
    private static $expires = [];

    public static function getBaseUrl($mode)
    {
        return $mode === 'live' ? 'https://api-m.paypal.com' : 'https://api-m.sandbox.paypal.com';
    }

    public static function getWebhookUrl()
    {
        return add_query_arg('fa_paypal_payouts_webhook', '1', site_url('/'));
    }

    /**
     * @return string|\WP_Error
     */
    public static function getAccessToken($mode, $clientId, $secret)
    {
        // cached per request only, so "Test connection" always asks PayPal; request() keeps it longer
        $cacheKey = $mode . md5($clientId . $secret);
        if (isset(self::$tokens[$cacheKey])) {
            return self::$tokens[$cacheKey];
        }

        $response = wp_remote_post(self::getBaseUrl($mode) . '/v1/oauth2/token', [
            'timeout' => 20,
            'headers' => [
                // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- HTTP Basic auth, not obfuscation
                'Authorization' => 'Basic ' . base64_encode($clientId . ':' . $secret),
                'Accept'        => 'application/json',
            ],
            'body'    => ['grant_type' => 'client_credentials'],
        ]);

        $body = self::parseResponse($response);
        if (is_wp_error($body)) {
            return $body;
        }

        if (empty($body['access_token'])) {
            return new \WP_Error('paypal_no_token', __('PayPal did not return an access token.', 'fluent-affiliate-pro'));
        }

        self::$expires[$cacheKey] = (int) Arr::get($body, 'expires_in', 0);

        return self::$tokens[$cacheKey] = $body['access_token'];
    }

    /**
     * The token for API calls, kept in a transient until shortly before it
     * expires, so the send job, the hourly sync and each webhook check do not
     * ask PayPal for a new token every time.
     *
     * @return string|\WP_Error
     */
    private static function cachedToken($mode, $clientId, $secret, $fresh = false)
    {
        $transient = self::tokenTransient($mode, $clientId, $secret);

        if (!$fresh) {
            $token = get_transient($transient);
            if ($token) {
                return $token;
            }
        } else {
            unset(self::$tokens[$mode . md5($clientId . $secret)]);
        }

        $token = self::getAccessToken($mode, $clientId, $secret);
        if (is_wp_error($token)) {
            return $token;
        }

        $lifetime = Arr::get(self::$expires, $mode . md5($clientId . $secret), 0) - 300;
        if ($lifetime > 0) {
            set_transient($transient, $token, $lifetime);
        }

        return $token;
    }

    /**
     * Calls the PayPal REST API with the saved keys of the given mode.
     *
     * @return array|\WP_Error the decoded body ([] for 204)
     */
    public static function request($mode, $method, $path, $body = null, $headers = [])
    {
        list($clientId, $secret) = PayPalSettings::getCredentials($mode);

        // not_sent: the call failed before this request left, so PayPal never saw it
        if (!$clientId || !$secret) {
            return new \WP_Error('paypal_not_configured', __('Add the PayPal API keys first.', 'fluent-affiliate-pro'), ['not_sent' => true]);
        }

        $token = self::cachedToken($mode, $clientId, $secret);
        if (is_wp_error($token)) {
            $token->add_data(array_merge((array) $token->get_error_data(), ['not_sent' => true]));
            return $token;
        }

        $result = self::send($mode, $method, $path, $body, $headers, $token);

        // a cached token PayPal no longer accepts (revoked, or keys rotated at
        // PayPal): PayPal refused the call, so one retry with a new token is safe
        if (is_wp_error($result) && (int) Arr::get((array) $result->get_error_data(), 'status') === 401) {
            $token = self::cachedToken($mode, $clientId, $secret, true);
            if (is_wp_error($token)) {
                $token->add_data(array_merge((array) $token->get_error_data(), ['not_sent' => true]));
                return $token;
            }
            $result = self::send($mode, $method, $path, $body, $headers, $token);
        }

        return $result;
    }

    /**
     * Drops the cached token of these keys, so a bearer token does not stay in
     * the database after the keys are removed or replaced.
     */
    public static function forgetToken($mode, $clientId, $secret)
    {
        if ($clientId && $secret) {
            delete_transient(self::tokenTransient($mode, $clientId, $secret));
        }
    }

    private static function tokenTransient($mode, $clientId, $secret)
    {
        return 'fa_paypal_token_' . md5($mode . $clientId . $secret);
    }

    private static function send($mode, $method, $path, $body, $headers, $token)
    {
        $args = [
            'method'  => $method,
            'timeout' => 30,
            'headers' => [
                'Authorization' => 'Bearer ' . $token,
                'Content-Type'  => 'application/json',
                'Accept'        => 'application/json',
            ] + $headers,
        ];

        if ($body !== null) {
            // a string is sent as is: the webhook check must pass PayPal's event bytes unchanged
            $args['body'] = is_string($body) ? $body : wp_json_encode($body);
        }

        return self::parseResponse(wp_remote_request(self::getBaseUrl($mode) . $path, $args));
    }

    /**
     * Registers the listener URL for the Payouts events and returns the webhook ID.
     * A URL registered before (keys saved again, a reinstall) is reused.
     *
     * @return string|\WP_Error
     */
    public static function registerWebhook($mode)
    {
        $events = array_map(function ($name) {
            return ['name' => $name];
        }, self::WEBHOOK_EVENTS);

        $webhook = self::request($mode, 'POST', '/v1/notifications/webhooks', [
            'url'         => self::getWebhookUrl(),
            'event_types' => $events,
        ]);

        if (!is_wp_error($webhook)) {
            return (string) Arr::get($webhook, 'id');
        }

        if ($webhook->get_error_code() !== 'WEBHOOK_URL_ALREADY_EXISTS') {
            return $webhook;
        }

        $list = self::request($mode, 'GET', '/v1/notifications/webhooks');
        if (is_wp_error($list)) {
            return $list;
        }

        foreach ((array) Arr::get($list, 'webhooks', []) as $existing) {
            if (Arr::get($existing, 'url') !== self::getWebhookUrl()) {
                continue;
            }

            // PayPal keeps the event list from creation, so add any missing events.
            // A patch with no change is an error, so skip it when nothing is missing.
            $missing = array_diff(self::WEBHOOK_EVENTS, array_column((array) Arr::get($existing, 'event_types', []), 'name'));
            if (!$missing) {
                return (string) $existing['id'];
            }

            $patched = self::request($mode, 'PATCH', '/v1/notifications/webhooks/' . rawurlencode($existing['id']), [
                ['op' => 'replace', 'path' => '/event_types', 'value' => $events],
            ]);

            return is_wp_error($patched) ? $patched : (string) $existing['id'];
        }

        return $webhook;
    }

    /**
     * Deletes the webhook only when it points to this site. A site copied to
     * staging keeps the stored ID of the live site's webhook, and must not
     * delete it; it only drops its local copy of the ID.
     *
     * @return array|\WP_Error
     */
    public static function deleteWebhook($mode, $webhookId)
    {
        $path = '/v1/notifications/webhooks/' . rawurlencode($webhookId);
        $webhook = self::request($mode, 'GET', $path);

        if (is_wp_error($webhook)) {
            // already gone at PayPal, so there is nothing to delete
            $status = (int) Arr::get((array) $webhook->get_error_data(), 'status');
            return $status === 404 ? [] : $webhook;
        }

        if (Arr::get($webhook, 'url') !== self::getWebhookUrl()) {
            return [];
        }

        return self::request($mode, 'DELETE', $path);
    }

    /**
     * Turns a PayPal response into the decoded body or a WP_Error that carries
     * the PayPal error name and a readable message. Never keeps the raw body.
     */
    private static function parseResponse($response)
    {
        if (is_wp_error($response)) {
            return $response;
        }

        $code = (int) wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);
        $body = is_array($body) ? $body : [];

        if ($code >= 200 && $code < 300) {
            return $body;
        }

        // OAuth errors use error / error_description, REST errors use name / message / details
        $name = Arr::get($body, 'name') ?: Arr::get($body, 'error') ?: 'paypal_http_' . $code;
        $message = Arr::get($body, 'details.0.description')
            ?: Arr::get($body, 'message')
            ?: Arr::get($body, 'error_description')
            /* translators: %d: HTTP status code */
            ?: sprintf(__('PayPal returned HTTP %d.', 'fluent-affiliate-pro'), $code);

        // links and the first issue identify a duplicate batch; nothing else of the body is kept
        return new \WP_Error($name, $message, [
            'status'   => $code,
            'debug_id' => Arr::get($body, 'debug_id'),
            'issue'    => Arr::get($body, 'details.0.issue'),
            'links'    => (array) Arr::get($body, 'links', []),
        ]);
    }
}
