<?php defined('ABSPATH') or die;
/*
Plugin Name: FluentAffiliate Pro
Description: FluentAffiliate Pro Package
Version: 1.7.0
Author: WPManageNinja LLC
Author URI: https://fluentaffiliate.com
Plugin URI: https://fluentaffiliate.com
License: GPLv2 or later
Text Domain: fluent-affiliate-pro
Domain Path: /language
*/

if (defined('FLUENT_AFFILIATE_PRO')) {
    return;
}

/* GPL Vault: activates FluentAffiliate Pro and keeps its update channel intact.
   Additive filters only. Answer the licence verbs and nothing else - the version
   endpoint must always reach the network or update detection stops working.
   Remove down to "END GPL Vault" to restore upstream behaviour. */

defined('FLUENT_AFFILIATE_PRO_SKIP_UPDATE_VERIFY') || define('FLUENT_AFFILIATE_PRO_SKIP_UPDATE_VERIFY', true);

if (!function_exists('fluent_affiliate_pro_license_record')) {
    function fluent_affiliate_pro_license_record()
    {
        static $record = null;

        if (null === $record) {
            $licenseKey = '1415B451BE1A13C283BA771EA52D38BB';

            $record = [
                'license_key'     => $licenseKey,
                'status'          => 'valid',
                'variation_id'    => '1',
                'variation_title' => 'Lifetime License',
                'expires'         => 'lifetime',
                'activation_hash' => md5($licenseKey . home_url()),
                'product_title'   => 'FluentAffiliate Pro',
                'customer_name'   => 'Licensed User',
            ];
        }

        return $record;
    }
}

add_filter('pre_option___fluent-affiliate-pro_sl_info', 'fluent_affiliate_pro_license_record');

add_filter('pre_http_request', function ($preempt, $args, $url) {
    if ('fluentapi.wpmanageninja.com' !== wp_parse_url($url, PHP_URL_HOST)) {
        return $preempt;
    }

    $query = [];
    parse_str((string) wp_parse_url($url, PHP_URL_QUERY), $query);

    $action = isset($query['fluent-cart']) ? $query['fluent-cart'] : '';

    if (!in_array($action, ['activate_license', 'check_license'], true)) {
        return $preempt;
    }

    $license = fluent_affiliate_pro_license_record();

    return [
        'headers'  => [],
        'cookies'  => [],
        'filename' => null,
        'response' => ['code' => 200, 'message' => 'OK'],
        'body'     => wp_json_encode([
            'status'          => 'valid',
            'variation_id'    => $license['variation_id'],
            'variation_title' => $license['variation_title'],
            'expiration_date' => 'lifetime',
            'activation_hash' => $license['activation_hash'],
            'product_title'   => $license['product_title'],
            'customer_name'   => $license['customer_name'],
        ]),
    ];
}, 10, 3);

// END GPL Vault.

define('FLUENT_AFFILIATE_PRO', true);
define('FLUENT_AFFILIATE_PRO_DIR', plugin_dir_path(__FILE__));
define('FLUENT_AFFILIATE_PRO_URL', plugin_dir_url(__FILE__));
define('FLUENT_AFFILIATE_PRO_BASE_NAME', plugin_basename(__FILE__));
define('FLUENT_AFFILIATE_PRO_DIR_FILE', __FILE__);
define('FLUENT_AFFILIATE_PRO_VERSION', '1.7.0');
define('FLUENT_AFFILIATE_PRO_DB_VERSION', '1.0.0');
define('FLUENT_AFFILIATE_MIN_CORE_VERSION', '1.7.0');

call_user_func(function ($bootstrap) {
    $bootstrap(__FILE__);
}, require(__DIR__ . '/boot/app.php'));
