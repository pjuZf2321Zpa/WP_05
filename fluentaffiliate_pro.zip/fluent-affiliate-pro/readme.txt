=== FluentAffiliate Pro  ===
Contributors: techjewel
Tags: affiliate
Requires at least: 5.6
Tested up to: 7.1
Stable tag: 1.7.0
Requires PHP: 7.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

FluentAffiliate is a complete affiliate management system for WordPress. It allows you to manage affiliates, track referrals, and pay commissions.

== Description ==
= FluentAffiliate - Affiliate Management System for WordPress =

[FluentAffiliate](https://fluentaffiliate.com) is a complete affiliate management system for WordPress. It allows you to manage affiliates, track referrals, and pay commissions. It is a self-hosted affiliate management system that is built on top of WordPress. It is a complete solution for you to run your own affiliate program. It is a perfect solution for your WooCommerce store, LMS, Membership site, or any other WordPress site.


👉 **[Get Started with FluentAffiliate](https://fluentaffiliate.com)**

= Your Self Hosted Affiliate Solution in WordPress =

FluentAffiliate is a self-hosted affiliate management system. You own your data and you can manage your affiliate program from your own WordPress site. It is a perfect solution for your WooCommerce store, LMS, Membership site, or any other WordPress site.

= FEATURES - Every Online Business Needs =

**🎉 Affiliate Management**
* Manage your affiliates
* Approve or reject affiliate applications
* Set custom commission rates for each affiliate

**🎉 Referral Tracking**
* Track referrals
* View referral details
* View referral source

**🎉 Payout Management**
* Set payout methods
* Pay your affiliates
* View payout history

**🎉 Affiliate Dashboard**
* Affiliates can view their referral stats
* Affiliates can view their payout history
* Affiliates can view their referral details

**🎉 Customer Portal**
* Affiliates can view their referral stats
* Affiliates can view their payout history
* Affiliates can view their referral details
* Affiliates can view their referral source

**🎉 Built for Speed & Productivity**
FluentAffiliate has been built to save time and make your affiliate management experience more pleasant. FluentAffiliate is built on top of VueJS & REST API as a Single Page Application. For each page transition, it does not load the full page. It just fetches the required data over AJAX and loads your UI instantly. It's like magic (Thanks to VueJS and REST API). We also made the UX super friendly, easy, and super simple so you don't need a learning curve for getting started.

= 🛡️ Fully GDPR Ready =
FluentAffiliate is a self-hosted WordPress plugin. You own your data, and no external SAAS connection is required to run your Support system with FluentAffiliate.

= 🚀 Modern. Powerful. Super Fast 🚀 =

* Build with VueJS and REST API as a Single-page Application
* Super fast and lean interface so anyone can use it without any learning curve
* Super awesome Dashboard with charts, graphs, essential data points to show your overall support quality.
* Separate DB Tables, and it's does not affect your WordPress page speed

= SEAMLESS INTEGRATIONS & Features =

FluentAffiliate features and integrations that will help your business –

<h4>First Class integrations with WooCommerce & EDD:</h4>
If you are running a WooCommerce or Easy Digital Downloads store then FluentAffiliate is a perfect solution for you. It will track all the referrals and sales from your WooCommerce or EDD store and show you the details of each referral and sales.

<h4>Integrations with Sure Cart</h4>
If you are using Sure Cart then FluentAffiliate gives you the power to track all the referrals and sales from your Sure Cart and show you the details of each referral and sales.

<h4>Integrations with Fluent CRM</h4>
If you are using Fluent CRM then FluentAffiliate gives you the power to track all the referrals and sales from your Fluent CRM and show you the details of each referral and sales.

<h4>Integrations with Fluent Forms</h4>
If you are using Fluent Forms then FluentAffiliate gives you the power to track all the referrals and sales from your Fluent Forms and show you the details of each referral and sales.

= Migrate From Other Affiliate Plugins =
If you are using any other affiliate plugin then FluentAffiliate has a migration tool that will help you to migrate your data from other affiliate plugins to FluentAffiliate.

<h4> Migrate From AffiliateWp - FluentAffiliate</h4>
If you are an AffiliateWp plugin user then it's super easy to migrate to FluentAffiliate. Just install FluentAffiliate, Configure with basic settings, create your affiliates and then follow the following steps

* Go to FluentAffiliate -> Settings
* You can see the Migrator
* Select AffiliateWp from the dropdown
* Click on the migrate button
* It will take confirmation from you to migrate the data
* If you confirm then it will show you the details of the migration which includes the number of affiliates, referrals, and payouts
* Once you confirm it will take few minutes depends on your affiliate data size in AffiliateWp Plugin
* Once completed it will ask if you want to close the migration or leave it as it is. If you leave it then all data in AffiliateWp will remain as it is.

== Other Plugins By The Same Team ==
<ul>
  <li><a href="https://wordpress.org/plugins/fluent-crm/" target="_blank">Fluent CRM – Email Marketing Automation, Newsletter and CRM Plugin for WordPress</a></li>
	<li><a href="https://wordpress.org/plugins/fluentform/" target="_blank">Fluent Forms – Fastest WordPress Form Builder Plugin</a></li>
	<li><a href="https://wordpress.org/plugins/ninja-tables/" target="_blank">Ninja Tables – Best WP DataTables Plugin for WordPress</a></li>
	<li><a href="https://wordpress.org/plugins/ninja-charts/" target="_blank">Ninja Charts – Best WP Charts Plugin for WordPress</a></li>
	<li><a href="https://wordpress.org/plugins/wp-payment-form/" target="_blank">WPPayForm - Stripe Payments Plugin for WordPress</a></li>
	<li><a href="https://wordpress.org/plugins/fluentforms-pdf/" target="_blank">Fluent Forms PDF - PDF Entries for Fluent Forms</a></li>
	<li><a href="https://wordpress.org/plugins/fluent-smtp/" target="_blank">FluentSMTP - WordPress Mail SMTP, SES, SendGrid, MailGun Plugin</a></li>
</ul>



== Installation ==
This section describes how to install the plugin and get it working.

1. Upload the plugin files to the `/wp-content/plugins/fluent-affiliate` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the \'Plugins\' screen in WordPress
3. Use the `FluentAffiliate` -> `Settings` screen to configure the plugin
4. (Make your instructions match the desired user flow for activating and installing your plugin. Include any steps that might be needed for explanatory purposes)

== Frequently Asked Questions ==
= Is it a self-hosted solution? =

Yes, FluentAffiliate is a 100% self-hosted solution. It will not connect with any of our SAAS servers. You own the data, and your data should be hosted on your hosting server.

= Is it GDPR-compliant? =

Yes, FluentAffiliate is fully GDPR-compliant. It does not store any personal data without the user's consent. It also has a data erasure feature that will help you to erase any user's data from the system.

= Will it affect my WordPress database? =

Absolutely not! From the very first, We were careful about this. It stores all the related data in custom database tables, so it will not affect your WordPress database. We built the application with VueJS, and it’s only run when you go to the admin dashboard of FluentAffiliate. Also, The Admin UI is superfast as It’s a SPA and communicates over ajax.

== Screenshots ==
1. Affiliate Dashboard
2. Affiliate Referral Details
3. Affiliate Payout History
4. Affiliate Settings
5. Affiliate Registration Form
7. Customer Portal - Affiliate Dashboard
8. Customer Portal - Affiliate Referral Details
9. Customer Portal - Affiliate Payout History

== Changelog ==

= 1.7.0 - Oct 28, 2026 =
- Introduced: Send Affiliate Payouts Through PayPal (pro)
- Introduced: Commission Holding Period
- Added: PayPal Payouts File Export for Manual Payouts
- Added: Option to Ignore the Holding Period on a Payout
- Added: Creatives Migration from Affiliate Manager (pro)
- Updated: WPFluent Framework to 2.16.0
- Security: Hardened Permissions, Registration, Integration Feeds, CSV Exports and Output Escaping
- Fixed: Wrong Commission on Zero-Decimal Currencies in FluentCart and FluentBooking
- Fixed: FluentCart Tax-Inclusive Commission Including VAT
- Fixed: Flat Commission Paid on Free Orders
- Fixed: Default Commission Rate Decimals and Rounding
- Fixed: Paymattic Coupon and FluentForms Pending Payment Commissions
- Fixed: Referral Attribution With Inactive Affiliates and Numeric Usernames
- Fixed: Self-Referral Check on Lifetime Commissions (pro)
- Fixed: Lifetime Commissions on WooCommerce Orders and Coupon Sales (pro)
- Fixed: Lost Visit and Referral Counts Under Load
- Fixed: Payout Accuracy for Inactive Affiliates, Deductions and Deleted Records
- Fixed: Migration Accuracy for AffiliateWP, Affiliate Manager and Solid Affiliate
- Fixed: Failed Payouts From Migrations Stuck in Processing
- Fixed: FluentCRM Automation Actions and Smart Codes
- Fixed: Signup Altering Passwords and Accepting Taken Usernames
- Fixed: Scheduled Jobs Not Rescheduling or Failing Without Pro
- Fixed: Dates Ignoring the Site Date Format and Week Start
- Fixed: Export Amounts Dropping Trailing Zeros

= 1.6.5 - Aug 20, 2026 =
- Added: Filters for Signup Roles and Reserved Field Names
- Improved: License Management with Plan, Expiry and Renewal Alerts
- Improved: Custom Conversion Referrals Now Await Admin Approval
- Improved: Visit Deduplication and Per-IP Flood Limits
- Updated: Licensing Engine With Signed Update Package Verification
- Security: Hardened Permissions, Registration, Tracking and Output Escaping

= 1.6.01 - Aug 10, 2026 =
- Improved: reCAPTCHA Keys Validated Automatically on Save
- Fixed: Affiliate Registration and Login Forms in Production Builds
- Fixed: Affiliate Portal Not Loading With Cookie Consent Blockers

= 1.6.0 - Aug 03, 2026 =
- Introduced: Captcha Protection on Affiliate Registration
- Introduced: Custom Affiliate Registration Fields
- Added: Admin Menu Title Filter Hook
- Added: Manage CRM Tags and Lists From Affiliate Profile
- Added: Creatives Migration from Solid Affiliate
- Improved: Dark Mode Palette, Contrast and Admin Styles
- Improved: Referral and Payout Transaction Table Indexes
- Improved: Bounded Payout Export and Reconciliation Query Budgets
- Improved: Batched Lookups and Failure Handling in Data Migration
- Improved: Output Escaping and Input Sanitization Compliance
- Security: Gated Report Endpoints Behind Permission Checks
- Security: Validated Proxy-Supplied IP Headers
- Security: Escaped Redirect URL in Auth Success Markup
- Fixed: Manual Referral Amounts Losing a Cent
- Fixed: Cart Manual Order Credited to the Admin's Cookie Affiliate
- Fixed: Group Commission Rate Disagreed Between Checkout and Admin
- Fixed: Payout Transactions Hardcoded to USD
- Fixed: Referrals Stranded in Processing Status
- Fixed: Per Transaction Referral Count Counted the Whole Payout
- Fixed: Division by Zero on Zero Total Refund
- Fixed: Tracker Dropped the Referrer on Every Visit
- Fixed: Referral Links Broke When the Link Format Changed
- Fixed: Checkout Fatal When an Affiliate's User Was Deleted
- Fixed: Affiliate List Filters Lost to Sanitization
- Fixed: Group Options Endpoint Unreachable for Managers
- Fixed: Custom Notification Email Subjects Ignored
- Fixed: Manual Referral Fired the Unpaid Hook for Every Status
- Fixed: Solid Affiliate Group, Rate Type and Product Migration

= 1.5.0 - Jun 22, 2026 =
- Introduced: Lifetime Commissions
- Added: Ultimate Affiliate Data Migration
- Improved: Migration Performance and Memory Use on Large Datasets
- Improved: Affiliate Portal Sidebar and Body Equal Height
- Security: Hardened Input Sanitization and v-html XSS Sinks in Admin and Portal
- Security: Fixed CSRF on Manual Update-Check Trigger
- Fixed: Doubled FluentCart Commission on Setup Fee
- Fixed: Self-Referral Not Blocked When Disabled
- Fixed: Duplicate Customers and Payouts on Migration Re-Run
- Fixed: Earnings Recount and Payout Totals During Migration
- Fixed: Null Check After Referral Recording in Integrations
- Fixed: Dark Mode Background Leaking to All Admin Pages
- Fixed: FluentCRM Manage Button URL in Features & Addons

= 1.4.0 - Apr 10, 2026 =
- Introduced: SliceWP Migration
- Introduced: Commission on WooCommerce Subscription Renewal
- Added: CSV Export for Affiliates, Referrals, and Visits
- Added: Social Media Share for Affiliates in the Affiliate Portal
- Added: QR Code Settings for Affiliate Portal
- Added: Recommended Plugins and Add-ons Section
- Improved: Creatives Now Included in Data Migration
- Fixed: Visits Filter Not Working
- Fixed: Payout Currency Symbol Display
- Fixed: FluentBooking Product Selector Issue
- Fixed: ProfilePress Integration Issue
- Fixed: EDD Coupon Affiliate Lookup Issue
- Fixed: PMPro Integration Ignoring Disabled Connector State
- Fixed: Renewal Rate Not Accepting Decimal Values
- Fixed: WooCommerce Renewal Commission Note
- Fixed: Affiliate Commission on Conversion Script
- Fixed: Individual Integration Settings Issue
- Fixed: Network Activation Skipping Pro Migrations on Multisite Child Sites
- Fixed: Infinite Loop in Username Generation
- Security: Hardened Nonce Verification on AJAX Actions

= 1.3.0 - Feb 03, 2026 =
- Introduced: Affiliate Commission on Subscription
- Introduced: Dynamic Affiliate QR Code
- Added: Bank Details Payout Method
- Added: Decimal Number Support in Manual Referral
- Fixed: Login Option Showing for Logged-in User
- Fixed: Issue with Tutor LMS Integration
- Fixed: Affiliate Manager Migration Issue
- Fixed: Data Unserialization Issue

= 1.2.0 - Oct 28, 2025 =
- Added: Integration with TutorLMS
- Added: ProfilePress Pro Integration!
- Added: RTL (Right-to-Left) Compatibility
- Introduce: Solid Affiliate Migration
- Introduce: Affiliate Manager Migration
- Fixed: Payment Email Validation
- Improved: UI-UX

= 1.1.0 - Sep 16, 2025 =
- Introduced Affiliate Creative Module
- Added: Affiliate ID in Affiliates Listing
- Added: Affiliate ID Support in Affiliate Searching
- Added: Pagination Jump-to-Page Option
- Added: Missing Translation Strings
- Improved: Affiliate and Referral Linking
- Improved: Menu Capability for Permission Management
- Fixed: Money Formatting Issue in Email Notifications
- Fixed: Registration Fields Not Updating Issue
- Fixed: Standard Commission Amount Incorrectly Applied as Percentage
- Fixed: Affiliate Registration Issue with Fluentform
- Fixed: Commission Rate Not Allowing Zero

= 1.0.2 - Sep 03, 2025 =
- Introduced Permission Management
- Deed Integration with FluentCRM!
- Added Custom Html Block Support in Customer Portal
- Added Missing Translation String
- Fixed: Email Content Update Issue
- Fixed: Referral Settings Issue with Multisite
- Fixed: Website Link is Not Showing in Email Notification

= 1.0.1 (Date: August 27, 2025) =
* Initial Release

= 0.9.1 (Date: July 08, 2025) =
* Added Dark Mode
* Added Membership support for Voxel
* Fixed all reported bugs
* Fixed UI Issues

= 0.9.0 (Date: July 04, 2025) =
* Initial Release
