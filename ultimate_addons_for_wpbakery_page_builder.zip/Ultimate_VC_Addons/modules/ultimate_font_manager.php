<?php
/**
 * Add-on Name: Google Font Manager
 * Add-on URI: http://dev.brainstormforce.com
 *
 *  @package UAVC Font manager
 */

/*
* Add-on Name: Google Font Manager
* Add-on URI: https://www.brainstormforce.com
* Usage:
	# VC Params Type: (Note - "ultimate_google_fonts_style" param must be next to "ultimate_google_fonts" param only)
		1) ultimate_google_fonts - for dropdown of google fonts in collection
			For Ex -
			array(
				"type" => "ultimate_google_fonts",
				"heading" => __("Font Family", "smile"),
				"param_name" => "heading_font"
			),
		2) ultimate_google_fonts_style - for respective google font style or default style
			For Ex -
			array(
				"type" => "ultimate_google_fonts_style",
				"heading" 		=>	__("Font Style", "smile"),
				"param_name"	=>	"heading_style"
			),
	# In respective comoponent shortcode process function
		1) Get font family -
			For Ex -
			$font_family = get_ultimate_font_family($heading_font);
		2) Get font style -
			For Ex -
			$font_style = get_ultimate_font_style($heading_style);
			// deprecated since 3.7.0 - automatically detected font and enqueue accordingly
		3) Enqueue the respective fonts - Note send number of font param as a parameter in array
			For Ex -
			$args = array(
				$heading_font
			);
			enquque_ultimate_google_fonts($args);
*/
if ( ! class_exists( 'Ultimate_VC_Addons_Google_Font_Manager' ) ) {
	/**
	 * Function that initializes  Ultimate Parallax.
	 *
	 * @class Ultimate_VC_Addons_Google_Font_Manager
	 */
	class Ultimate_VC_Addons_Google_Font_Manager {
		/**
		 * Constructor function that constructs default values for the Ultimate Parallax.
		 *
		 * @method __construct
		 */
		public function __construct() {
			add_option( 'ultimate_google_fonts', array() );
			add_option( 'ultimate_selected_google_fonts', array() );
			add_action( 'wp_ajax_ultimate_google_fonts_refresh', array( $this, 'refresh_google_fonts_list' ) );
			add_action( 'wp_ajax_get_google_fonts', array( $this, 'get_google_fonts_list' ) );
			add_action( 'wp_ajax_add_google_font', array( $this, 'add_selected_google_font' ) );
			add_action( 'wp_ajax_delete_google_font', array( $this, 'delete_selected_google_font' ) );
			add_action( 'wp_ajax_update_google_font', array( $this, 'update_selected_google_font' ) );
			add_action( 'wp_ajax_get_font_variants', array( $this, 'get_font_variants_callback' ) );
			add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_selected_ultimate_google_fonts' ) );
		}
		/**
		 * Google font manager menu.
		 *
		 * @since ----
		 * @access public
		 */
		public function google_font_manager_menu() {
			$current_theme = wp_get_theme();
			if ( 'Smile' == $current_theme ) {
				$page = add_submenu_page(
					'smile_dashboard',
					__( 'Google Font Manager', 'ultimate_vc' ),
					__( 'Google Fonts', 'ultimate_vc' ),
					'administrator',
					'Ultimate_VC_Addons_Font_Manager',
					array( $this, 'ultimate_font_manager_dashboard' )
				);
			} else {
				$page = add_submenu_page(
					'bsf-dashboard',
					__( 'Google Font Manager', 'ultimate_vc' ),
					__( 'Google Fonts', 'ultimate_vc' ),
					'administrator',
					'ultimate-font-manager',
					array( $this, 'ultimate_font_manager_dashboard' )
				);
			}
			add_action( 'admin_print_scripts-' . $page, array( $this, 'admin_google_font_scripts' ) );
		}
		/**
		 * Google font admin scripts.
		 *
		 * @since ----
		 * @access public
		 */
		public function admin_google_font_scripts() {
			wp_register_script( 'ultimate-vc-addons-google-fonts-script', UAVC_URL . 'admin/js/google-fonts-admin.js', array( 'jquery' ), ULTIMATE_VERSION, false );
			wp_enqueue_script( 'ultimate-vc-addons-google-fonts-script' );
			wp_localize_script(
				'ultimate-vc-addons-google-fonts-script',
				'uavc',
				array(
					'google_font_nonce'   => wp_create_nonce( 'uavc-google-font-nonce' ),
					'get_google_fonts'    => wp_create_nonce( 'uavc-get-google-fonts-nonce' ),
					'add_google_fonts'    => wp_create_nonce( 'uavc-add-google-fonts-nonce' ),
					'delete_google_fonts' => wp_create_nonce( 'uavc-delete-google-fonts-nonce' ),
					'update_google_fonts' => wp_create_nonce( 'uavc-update-google-fonts-nonce' ),
				)
			);

			Ultimate_VC_Addons::ultimate_register_style( 'ultimate-vc-addons-google-fonts-style', UAVC_URL . 'admin/css/google-fonts-admin.css', true );

			wp_enqueue_style( 'ultimate-vc-addons-google-fonts-style' );
		}
		/**
		 * Enqueue Google font.
		 *
		 * @since ----
		 * @access public
		 */
		public function enqueue_selected_ultimate_google_fonts() {
			$selected_fonts    = get_option( 'ultimate_selected_google_fonts' );
			$subset_main_array = array();
			if ( ! empty( $selected_fonts ) ) {

				$count     = count( $selected_fonts );
				$font_call = '';
				foreach ( $selected_fonts as $key => $sfont ) {
					$variants_array = array();
					if ( 0 != $key ) {
						$font_call .= '|';
					}
					$font_call .= $sfont['font_family'];
                                       if ( isset( $sfont['variants'] ) ) :
                                               $variants = $sfont['variants'];
                                               if ( ! is_array( $variants ) ) {
                                                       $variants = json_decode( stripslashes( (string) $variants ), true );
                                               }
                                               if ( ! is_array( $variants ) ) {
                                                       $variants = array();
                                               }
                                               if ( ! empty( $variants ) ) {
                                                       foreach ( $variants as $variant ) {
                                                               if ( is_array( $variant ) ) {
                                                                       $variant_selected = isset( $variant['variant_selected'] ) ? $variant['variant_selected'] : 'true';
                                                                       $variant_value    = isset( $variant['variant_value'] ) ? $variant['variant_value'] : '';
                                                               } else {
                                                                       $variant_selected = 'true';
                                                                       $variant_value    = $variant;
                                                               }

                                                               if ( '' === $variant_value ) {
                                                                       continue;
                                                               }

                                                               if ( 'true' === $variant_selected || is_admin() ) {
                                                                       $variants_array[] = $variant_value;
                                                               }
                                                       }

                                                       // Only emit the ':' separator when a value follows it, or a
                                                       // row whose variants are all empty produces "Family:".
                                                       if ( ! empty( $variants_array ) ) {
                                                               $font_call .= ':normal,' . implode( ',', $variants_array );
                                                       }
                                               }
                                       endif;

                                       if ( ! empty( $sfont['subsets'] ) ) {
                                               $subset_array = array();
                                               $subsets = $sfont['subsets'];
                                               if ( ! is_array( $subsets ) ) {
                                                       $subsets = json_decode( stripslashes( (string) $subsets ), true );
                                               }
                                               if ( ! is_array( $subsets ) ) {
                                                       $subsets = array();
                                               }

                                               foreach ( $subsets as $tsubset ) {
                                                       if ( is_array( $tsubset ) ) {
                                                               $subset_selected = isset( $tsubset['subset_selected'] ) ? $tsubset['subset_selected'] : 'true';
                                                               $subset_value    = isset( $tsubset['subset_value'] ) ? $tsubset['subset_value'] : '';
                                                       } else {
                                                               $subset_selected = 'true';
                                                               $subset_value    = $tsubset;
                                                       }

                                                       if ( '' === $subset_value ) {
                                                               continue;
                                                       }

                                                       if ( 'true' == $subset_selected || true == $subset_selected ) {
                                                               $subset_main_array[] = $subset_value;
                                                       }
                                               }
                                        }
				}

				$subset_string = '';

				if ( ! empty( $subset_main_array ) ) {
					$subset_main_array = array_unique( $subset_main_array );

					$subset_string     = '&subset=';
					$subset_count      = count( $subset_main_array );
					$subset_main_array = array_values( $subset_main_array );

					foreach ( $subset_main_array as $skey => $subset ) {
						if ( '' !== $subset ) {
							$subset_string .= $subset;
							if ( ( $skey != $subset_count - 1 ) ) {
								$subset_string .= ',';
							}
						}
					}
				}

				$font_call = str_replace( '||', '|', $font_call );

				$link = 'https://fonts.googleapis.com/css?family=' . $font_call;

				$font_api_call = $link . $subset_string;

				wp_register_style( 'ultimate-vc-addons-selected-google-fonts-style', $font_api_call, array(), null );// @codingStandardsIgnoreLine.
				wp_enqueue_style( 'ultimate-vc-addons-selected-google-fonts-style' );
			}
		}
		/**
		 * Google font manager Dashboard menu.
		 *
		 * @since ----
		 * @access public
		 */
		public function ultimate_font_manager_dashboard() {            ?>
		<div class="wrap uavc-gfont">
			<h2>
					<?php esc_attr_e( 'Google Fonts Manager', 'ultimate_vc' ); ?>
					<input style="cursor:pointer" type="button" class="add-new-h2" id="refresh-google-fonts" value="<?php esc_attr_e( 'Refresh Font List', 'ultimate_vc' ); ?>"/>
				&nbsp;<span class="spinner"></span>
				</h2>
				<div id="vc-gf-msg"></div>
				<div class="nav">
					<input type="text" id="search_gfont" name="search_gfont" placeholder="<?php echo esc_attr__( 'Search font..', 'ultimate_vc' ); ?>"/>
				</div>
				<div>
				<div class="fonts-list">
					<div id="fonts-list-wrapper" style="overflow:auto" data-gstart="0" data-gfetch="20"></div>
					<div id="load-more" class="spinner" style="float:left"></div>
				</div>
				<div class="fonts-selected-list">
					<h3><?php echo esc_html__( 'Your Font Collection', 'ultimate_vc' ); ?></h3>
					<div id="fonts-selected-wrapper">
						<?php
							$selected_fonts = get_option( 'ultimate_selected_google_fonts' );
						if ( ! empty( $selected_fonts ) ) {
							foreach ( $selected_fonts as $key => $sfont ) {
								?>
										<div class="selected-font">
											<div class="selected-font-top <?php echo ( ! empty( $sfont['variants'] ) || ! empty( $sfont['subsets'] ) ) ? 'have-variants' : ''; ?>">
												<div class="font-header" style="font-family:'<?php esc_attr_e( $sfont['font_name'] ); ?>'"><?php esc_html_e( $sfont['font_name'] ); ?></div>
											<?php if ( ! empty( $sfont['variants'] ) || ! empty( $sfont['subsets'] ) ) : ?>
													<i class="dashicons dashicons-arrow-down"></i>
												<?php endif; ?>
												<div class="clear"></div>
											</div>
											<span class="font-delete" data-font_name="<?php esc_attr_e( $sfont['font_name'] ); ?>"><i class="dashicons dashicons-no-alt"></i></span>
										<?php
											$is_varients = false;
										if ( ! empty( $sfont['variants'] ) || ! empty( $sfont['subsets'] ) ) :
											?>
												<div class="selected-font-content">
											<?php
												$lid          = str_replace( ' ', '-', $sfont['font_name'] );
												$variant_font = 'font-family:\'' . $sfont['font_name'] . '\';';
											if ( ! empty( $sfont['variants'] ) ) :
												$is_varients = true;
												?>
															<div class="selected-font-varient-wrapper">
													<?php
												foreach ( $this->to_array( $sfont['variants'] ) as $svkey => $svariants ) {
                                                       if ( ! is_array( $svariants ) ) {
                                                               $svariants = array(
                                                                       'variant_value'    => $svariants,
                                                                       'variant_selected' => 'true',
                                                               );
                                                       }
														$variant_style = $variant_font;
														if ( preg_match( '/italic/i', $svariants['variant_value'] ) ) {
															$variant_style .= 'font-style:italic;';
														}
														$weight = 'normal';
														if ( $weight = preg_replace( '/\D/', '', $svariants['variant_value'] ) ) { // @codingStandardsIgnoreLine.
															$variant_style .= 'font-weight:' . $weight . ';';
														}
														$tlid = $lid . '-' . $svkey;
														?>
																		<span class="font-variant">
																			<input type="checkbox" id="<?php esc_attr_e( $tlid ); ?>" value="<?php esc_attr_e( $svariants['variant_value'] ); ?>" class="selected-variant-checkbox" <?php echo ( 'true' == $svariants['variant_selected'] ) ? 'checked' : ''; ?> />
																			<label style="<?php esc_attr_e( $variant_style ); ?>" for="<?php esc_attr_e( $tlid ); ?>"><?php echo $svariants['variant_value']; // @codingStandardsIgnoreLine. ?></label>
																		</span>
															<?php
													}
													?>
															</div>
													<?php
														endif;
											if ( ! empty( $sfont['subsets'] ) ) :
												?>
															<div class="<?php echo ( $is_varients ) ? 'selected-font-subset-wrapper' : ''; ?>">
													<?php
												foreach ( $this->to_array( $sfont['subsets'] ) as $sbkey => $ssubset ) {
                                                       if ( ! is_array( $ssubset ) ) {
                                                               $ssubset = array(
                                                                       'subset_value'    => $ssubset,
                                                                       'subset_selected' => 'true',
                                                               );
                                                       }
                                                       $slid = $lid . '-subset-' . $sbkey;
														?>
																		<span class="font-subset">
																			<input type="checkbox" id="<?php esc_attr_e( $slid ); ?>" value="<?php esc_attr_e( $ssubset['subset_value'] ); ?>" class="selected-subset-checkbox" <?php echo ( 'true' == $ssubset['subset_selected'] ) ? 'checked' : ''; ?> />
																			<label style="" for="<?php esc_attr_e( $slid ); ?>"><?php echo $ssubset['subset_value']; // @codingStandardsIgnoreLine. ?></label>
																		</span>
															<?php
													}
													?>
															</div>
													<?php
														endif;
											?>
													<input type="button" class="button alignleft update-google-font-button" value="<?php echo esc_attr__( 'Update font', 'ultimate_vc' ); ?>" data-font_name="<?php esc_attr_e( $sfont['font_name'] ); ?>" />
													<span class="spinner fspinner"></span>
													<div class="clear"></div>
												</div>
												<?php
												endif;
										?>
										</div>
									<?php
							}
						}
						?>
					</div>
				</div>
				<div class="clear"></div>
				</div>
			</div>
			<?php
		}
		/**
		 * Google font manager list.
		 *
		 * @since ----
		 * @access public
		 */
		public function refresh_google_fonts_list() {

			if ( ! current_user_can( 'manage_options' ) ) {
				return false;
			}

			check_ajax_referer( 'uavc-google-font-nonce', 'security' );

			$fonts      = array();
			$temp_count = 0;
			$temp       = get_option( 'ultimate_google_fonts' );
			if ( ! empty( $temp ) ) {
				$temp_count = count( $temp );
			}
			$error = false;
			if ( empty( $fonts ) ) {
				try {
					$fonts = wp_remote_get( 'https://www.googleapis.com/webfonts/v1/webfonts?key=AIzaSyD_6TR2RyX2VRf8bABDRXCcVqdMXB5FQvs' ); // @codingStandardsIgnoreLine.
					if ( is_wp_error( $fonts ) || 200 !== wp_remote_retrieve_response_code( $fonts ) ) {
						$error = true;
					} else {
						$fonts = json_decode( wp_remote_retrieve_body( $fonts ) );
					}
				} catch ( Exception $e ) {
					$error = true;
				}
			}
			if ( true != $error || 0 == count( $fonts ) ) {
				$google_fonts      = $fonts->items;
				$google_font_count = count( is_countable( $google_fonts ) ? $google_fonts : array() ); // PHPCS:Ignore PHPCompatibility.FunctionUse.NewFunctions.is_countableFound
				update_option( 'ultimate_google_fonts', $google_fonts );
				$response['count']   = ( $google_font_count - $temp_count );
				$response['message'] = __( ( $google_font_count - $temp_count ) . ' new fonts added. ', 'ultimate_vc' );
			} else {
				$response['count']   = 0;
				$response['message'] = __( 'Fonts could not be downloaded as there might be some issue with file_get_contents or wp_remote_get due to your server configuration.', 'ultimate_vc' );
			}
			echo wp_json_encode( $response );
			die();
		}
		/**
		 * Get Google font list.
		 *
		 * @since ----
		 * @access public
		 */
		public function get_google_fonts_list() {

			if ( ! current_user_can( 'manage_options' ) ) {
				return false;
			}

			check_ajax_referer( 'uavc-get-google-fonts-nonce', 'security' );

			$google_fonts       = get_option( 'ultimate_google_fonts' );
			$response           = array();
			$fonts              = array();
						$search = '';
			if ( ! empty( $google_fonts ) ) :
				$selected_google_fonts = get_option( 'ultimate_selected_google_fonts' );
				$temp_selected         = array();
				if ( ! empty( $selected_google_fonts ) ) {
					foreach ( $selected_google_fonts as $selected_font ) {
						array_push( $temp_selected, $selected_font['font_name'] );
					}
				}
				$start_count      = isset( $_POST['start'] ) ? sanitize_text_field( $_POST['start'] ) : '';
				$fetch_count      = isset( $_POST['fetch'] ) ? sanitize_text_field( $_POST['fetch'] ) : '';
				$search           = isset( $_POST['search'] ) ? trim( sanitize_text_field( $_POST['search'] ) ) : '';
				$font_slice_array = array();
				if ( '' != $search ) {
					$temp = array();
					foreach ( $google_fonts as $tkey => $tfont ) {
						if ( stripos( $tfont->family, $search ) !== false ) {
							array_push( $temp, $google_fonts[ $tkey ] );
						}
					}
					$font_slice_array = $temp;
				} else {
					$font_slice_array = array_slice( $google_fonts, $start_count, $fetch_count );
				}
				$count = count( $font_slice_array );
				foreach ( $font_slice_array as $key => $tempfont ) {
					$fontinfo = array();
					if ( in_array( $tempfont->family, $temp_selected ) ) {
						$already_selected = 'true';
					} else {
						$already_selected = 'false';
					}
					$font_call = str_replace( ' ', '+', $tempfont->family );
					$variants  = $tempfont->variants;
					$subsets   = $tempfont->subsets;
					$fontinfo  = array(
						'font_name' => $tempfont->family,
						'font_call' => $font_call,
						'variants'  => $variants,
						'subsets'   => $subsets,
						'selected'  => $already_selected,
					);
					array_push( $fonts, $fontinfo );
				}
			endif;
			$response['fonts']       = $fonts;
			$response['fonts_count'] = count( is_countable( $google_fonts ) ? $google_fonts : array() ); // PHPCS:Ignore PHPCompatibility.FunctionUse.NewFunctions.is_countableFound
			if ( '' != $search ) {
				$response['is_search'] = 'true';
			} else {
				$response['is_search'] = 'false';
			}
			echo wp_json_encode( $response );
			die();
		}
		/**
		 * Normalise a variants/subsets payload into an array.
		 *
		 * The value arrives either as a real array (jQuery serialised form) or
		 * as a JSON encoded string. Anything else is discarded.
		 *
		 * @since 3.21.6
		 * @access private
		 * @param mixed $value Raw payload.
		 * @return array
		 */
		private function to_array( $value ) {
			if ( is_array( $value ) ) {
				return $value;
			}

			$decoded = json_decode( stripslashes( (string) $value ), true );

			return is_array( $decoded ) ? $decoded : array();
		}

		/**
		 * Normalise a single variant into the { variant_value, variant_selected } shape.
		 *
		 * The Google Fonts API returns variants as plain strings ("regular",
		 * "700"), and older builds persisted them that way. Reading
		 * `$variant['variant_selected']` off such a string is a fatal TypeError
		 * on PHP 8, so coerce it here - a bare string means a selected variant,
		 * matching how the dashboard has always rendered it.
		 *
		 * @since 3.21.6
		 * @access private
		 * @param mixed $variant Raw variant.
		 * @return array Empty array when the variant is unusable.
		 */
		private static function normalize_variant( $variant ) {
			if ( is_array( $variant ) ) {
				return isset( $variant['variant_value'] ) ? $variant : array();
			}

			if ( is_string( $variant ) && '' !== $variant ) {
				return array(
					'variant_value'    => $variant,
					'variant_selected' => 'true',
				);
			}

			return array();
		}

		/**
		 * Normalise a single subset into the { subset_value, subset_selected } shape.
		 *
		 * @since 3.21.6
		 * @access private
		 * @param mixed $subset Raw subset.
		 * @return array Empty array when the subset is unusable.
		 */
		private static function normalize_subset( $subset ) {
			if ( is_array( $subset ) ) {
				return isset( $subset['subset_value'] ) ? $subset : array();
			}

			if ( is_string( $subset ) && '' !== $subset ) {
				return array(
					'subset_value'    => $subset,
					'subset_selected' => 'true',
				);
			}

			return array();
		}

		/**
		 * Sanitize font variants while preserving their object shape.
		 *
		 * `sanitize_text_field()` cannot be mapped over the list directly - it
		 * flattens every variant object to an empty string, which corrupts the
		 * stored option.
		 *
		 * @since 3.21.6
		 * @access private
		 * @param mixed $variants Raw variants payload.
		 * @return array
		 */
		private function sanitize_variants( $variants ) {
			$sanitized = array();

			foreach ( $this->to_array( $variants ) as $variant ) {
				$variant = self::normalize_variant( $variant );
				if ( empty( $variant ) ) {
					continue;
				}
				$sanitized[] = array(
					'variant_value'    => isset( $variant['variant_value'] ) ? sanitize_text_field( $variant['variant_value'] ) : '',
					'variant_selected' => ( isset( $variant['variant_selected'] ) && filter_var( $variant['variant_selected'], FILTER_VALIDATE_BOOLEAN ) ) ? 'true' : 'false',
				);
			}

			return $sanitized;
		}

		/**
		 * Sanitize font subsets while preserving their object shape.
		 *
		 * @since 3.21.6
		 * @access private
		 * @param mixed $subsets Raw subsets payload.
		 * @return array
		 */
		private function sanitize_subsets( $subsets ) {
			$sanitized = array();

			foreach ( $this->to_array( $subsets ) as $subset ) {
				$subset = self::normalize_subset( $subset );
				if ( empty( $subset ) ) {
					continue;
				}
				$sanitized[] = array(
					'subset_value'    => isset( $subset['subset_value'] ) ? sanitize_text_field( $subset['subset_value'] ) : '',
					'subset_selected' => ( isset( $subset['subset_selected'] ) && filter_var( $subset['subset_selected'], FILTER_VALIDATE_BOOLEAN ) ) ? 'true' : 'false',
				);
			}

			return $sanitized;
		}

		/**
		 * Add selected Google font.
		 *
		 * @since ----
		 * @access public
		 */
		public function add_selected_google_font() {

			if ( ! current_user_can( 'manage_options' ) ) {
				wp_send_json_error( __( 'You are not allowed to manage fonts.', 'ultimate_vc' ), 403 );
			}

			check_ajax_referer( 'uavc-add-google-fonts-nonce', 'security' );

			$font_family = isset( $_POST['font_family'] ) ? sanitize_text_field( $_POST['font_family'] ) : '';
			$font_name   = isset( $_POST['font_name'] ) ? sanitize_text_field( $_POST['font_name'] ) : '';
			$variants    = $this->sanitize_variants( isset( $_POST['variants'] ) ? $_POST['variants'] : array() ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			$subsets     = $this->sanitize_subsets( isset( $_POST['subsets'] ) ? $_POST['subsets'] : array() ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized

			$fonts = get_option( 'ultimate_selected_google_fonts' );
			if ( ! is_array( $fonts ) ) {
				$fonts = array();
			}
			$new_font = array(
				'font_family' => $font_family,
				'font_name'   => $font_name,
				'variants'    => $variants,
				'subsets'     => $subsets,
			);
			array_push( $fonts, $new_font );
			update_option( 'ultimate_selected_google_fonts', $fonts );
			echo 'Added';
			die();
		}
		/**
		 * Delete selected Google font.
		 *
		 * @since ----
		 * @access public
		 */
		public function delete_selected_google_font() {

			if ( ! current_user_can( 'manage_options' ) ) {
				wp_send_json_error( __( 'You are not allowed to manage fonts.', 'ultimate_vc' ), 403 );
			}

			check_ajax_referer( 'uavc-delete-google-fonts-nonce', 'security' );

			$font_name = isset( $_POST['font_name'] ) ? sanitize_text_field( $_POST['font_name'] ) : '';
			$fonts     = get_option( 'ultimate_selected_google_fonts' );
			if ( ! is_array( $fonts ) ) {
				$fonts = array();
			}
			foreach ( $fonts as $key => $font ) {
				if ( $font['font_name'] == $font_name ) {
					unset( $fonts[ $key ] );
				}
			}
			$fonts = array_values( $fonts );
			update_option( 'ultimate_selected_google_fonts', $fonts );
			echo 'Deleted';
			die();
		}
		/**
		 * Update selected Google font.
		 *
		 * @since ----
		 * @access public
		 */
		public function update_selected_google_font() {

			if ( ! current_user_can( 'manage_options' ) ) {
				wp_send_json_error( __( 'You are not allowed to manage fonts.', 'ultimate_vc' ), 403 );
			}

			check_ajax_referer( 'uavc-update-google-fonts-nonce', 'security' );

			$font_name = isset( $_POST['font_name'] ) ? sanitize_text_field( $_POST['font_name'] ) : '';
			$variants  = $this->sanitize_variants( isset( $_POST['variants'] ) ? $_POST['variants'] : array() ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			$subsets   = $this->sanitize_subsets( isset( $_POST['subsets'] ) ? $_POST['subsets'] : array() ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			$fonts     = get_option( 'ultimate_selected_google_fonts' );
			if ( ! is_array( $fonts ) ) {
				$fonts = array();
			}
			foreach ( $fonts as $key => $font ) {
				if ( $font['font_name'] == $font_name ) {
					$fonts[ $key ]['variants'] = $variants;
					$fonts[ $key ]['subsets']  = $subsets;
				}
			}
			update_option( 'ultimate_selected_google_fonts', $fonts );
			echo 'Updated';
			die();
		}
		/**
		 * Get Google font callback.
		 *
		 * @since ----
		 * @access public
		 */
		public function get_font_variants_callback() {

			if ( ! current_user_can( 'manage_options' ) ) {
				wp_send_json_error( __( 'You are not allowed to manage fonts.', 'ultimate_vc' ), 403 );
			}

			check_ajax_referer( 'uavc-get-font-variants-nonce', 'security' );

			$font_name              = isset( $_POST['font_name'] ) ? sanitize_text_field( $_POST['font_name'] ) : '';
			$fonts                  = get_option( 'ultimate_selected_google_fonts' );
			$font_variants          = array();
			$json_variants          = array();
			$default_variant_styles = array(
				0 => array(
					'label' => 'Underline',
					'style' => 'text-decoration:underline;',
					'type'  => 'checkbox',
					'group' => 'ultimate_defaults_styles',
					'class' => 'ultimate_defaults_styles',
				),
				1 => array(
					'label' => 'Italic',
					'style' => 'font-style:italic;',
					'type'  => 'checkbox',
					'group' => 'ultimate_defaults_styles',
					'class' => 'ultimate_defaults_styles',
				),
				2 => array(
					'label' => 'Bold',
					'style' => 'font-weight:bold;',
					'type'  => 'checkbox',
					'group' => 'ultimate_defaults_styles',
					'class' => 'ultimate_defaults_styles',
				),
			);
			if ( ! is_array( $fonts ) ) {
				$fonts = array();
			}
			foreach ( $fonts as $key => $font ) {
				if ( $font['font_name'] == $font_name ) {
					$font_variants = $this->to_array( $fonts[ $key ]['variants'] );
				}
			}
			if ( ! empty( $font_variants ) ) {
				$is_italic            = false;
				$is_weight            = false;
				$uniq_grp             = uniqid( '_' );
				$pre_default_variants = array();
				foreach ( $font_variants as $key => $variant ) {
					$variant = self::normalize_variant( $variant );
					if ( empty( $variant ) || ! isset( $variant['variant_selected'] ) ) {
						continue;
					}
					if ( 'true' == $variant['variant_selected'] ) :
						$temp_array = array();
						$is_weight  = false;
						$is_italic  = false;
						if ( preg_match( '/italic/i', $variant['variant_value'] ) && $weight = preg_replace( '/\D/', '', $variant['variant_value'] ) ) { // @codingStandardsIgnoreLine.
							$temp_array['label'] = $variant['variant_value'];
							$temp_array['style'] = 'font-style:italic;font-weight:' . $weight . ';';
							$is_italic           = true;
							$is_weight           = true;
						} elseif ( preg_match( '/italic/i', $variant['variant_value'] ) ) {
							$temp_array['label'] = $variant['variant_value'];
							$temp_array['style'] = 'font-style:italic;';
							$is_italic           = true;
						} elseif ( $weight = preg_replace( '/\D/', '', $variant['variant_value'] ) ) { // @codingStandardsIgnoreLine.
							$temp_array['label'] = $variant['variant_value'];
							$temp_array['style'] = 'font-weight:' . $weight . ';';
							$is_weight           = true;
						}
						// The "regular" variant produces neither a weight nor a
						// style, so it has no label to render. It is already
						// covered by the "Default" radio the JS adds - pushing
						// it here renders an "undefined" option.
						if ( ! isset( $temp_array['label'] ) ) {
							continue;
						}
						$temp_array['type']  = 'radio';
						$temp_array['group'] = 'style_by_google' . $uniq_grp;
						$temp_array['class'] = 'style_by_google';
						array_push( $json_variants, $temp_array );
					endif;
				}
				array_push( $pre_default_variants, $default_variant_styles[0] ); // 2 for bold
				if ( false == $is_italic ) {
					array_push( $pre_default_variants, $default_variant_styles[1] ); // 2 for bold
				}
				if ( false == $is_weight ) {
					array_push( $pre_default_variants, $default_variant_styles[2] ); // 2 for bold
				}
				$json_variants = array_merge( $pre_default_variants, $json_variants );
			} else {
				$json_variants = $default_variant_styles;
			}
			echo wp_json_encode( $json_variants );
			die();
		}

	}
	// Instantiate the Google Font Manager.
	new Ultimate_VC_Addons_Google_Font_Manager();
}
if ( ! function_exists( 'uavc_get_selected_font_values' ) ) {
	/**
	 * Collect the selected values out of a stored variants or subsets list.
	 *
	 * The stored list can be an array of objects, an array of plain strings, or a
	 * JSON encoded string, and older builds could leave empty entries behind.
	 * Iterating it without normalising first is a PHP 8 warning, and empty entries
	 * produce a malformed Google Fonts request such as "&subset=,".
	 *
	 * @since 3.21.6
	 * @param mixed  $list         Stored variants/subsets value.
	 * @param string $value_key    Key holding the value.
	 * @param string $selected_key Key holding the selected flag.
	 * @return array Selected, non-empty values.
	 */
	function uavc_get_selected_font_values( $list, $value_key, $selected_key ) {

		if ( ! is_array( $list ) ) {
			$list = json_decode( stripslashes( (string) $list ), true );
		}

		if ( ! is_array( $list ) ) {
			return array();
		}

		$values = array();

		foreach ( $list as $item ) {
			if ( is_array( $item ) ) {
				$value    = isset( $item[ $value_key ] ) ? $item[ $value_key ] : '';
				$selected = isset( $item[ $selected_key ] ) ? $item[ $selected_key ] : 'true';
			} else {
				$value    = $item;
				$selected = 'true';
			}

			if ( '' === $value || 'true' != $selected ) {
				continue;
			}

			$values[] = $value;
		}

		return $values;
	}
}
if ( ! function_exists( 'enquque_ultimate_google_fonts' ) ) {
	/**
	 * Enqueue Google font.
	 *
	 * @since ----
	 * @param mixed $enqueue_fonts enqip fonts.
	 * @access public
	 */
	function enquque_ultimate_google_fonts( $enqueue_fonts ) {

		$selected_fonts = apply_filters( 'enquque_selected_ultimate_google_fonts_optimzed', get_option( 'ultimate_selected_google_fonts' ) );

		if ( ! is_array( $selected_fonts ) ) {
			$selected_fonts = array();
		}

		$skip_font_enqueue = apply_filters( 'enquque_ultimate_google_fonts_skip', false );

		if ( true == $skip_font_enqueue ) {
			return '';
		}

		$fonts       = array();
		$subset_call = '';
		if ( ! empty( $enqueue_fonts ) ) {
			foreach ( $enqueue_fonts as $key => $efont ) {
				$font_name       = '';
				$font_call       = '';
				$font_variant    = '';
				$font_arr        = array();
				$font_call_arr   = array();
				$font_weight_arr = array();
				$font_arr        = explode( '|', $efont );
				if ( isset( $font_arr[1] ) ) {
					$font_call_arr = explode( ':', $font_arr[1] );
					if ( isset( $font_arr[2] ) ) {
						$font_weight_arr = explode( ':', $font_arr[2] );
					}
					if ( isset( $font_call_arr[1] ) && '' != $font_call_arr[1] ) {
						$font_call = $font_call_arr[1];
						$font_name = $font_call_arr[1];

						foreach ( $selected_fonts as $sfont ) {
							if ( ! isset( $sfont['font_family'] ) || $font_name != $sfont['font_family'] ) {
								continue;
							}
							$subset_array = uavc_get_selected_font_values(
								isset( $sfont['subsets'] ) ? $sfont['subsets'] : array(),
								'subset_value',
								'subset_selected'
							);
							if ( ! empty( $subset_array ) ) {
								$subset_call = '&subset=' . implode( ',', $subset_array );
							}
						}

						if ( isset( $font_weight_arr[1] ) && '' != $font_weight_arr[1] ) {
							$font_variant = $font_weight_arr[1];
						}
						$eq_name = str_replace( ' ', '-', $font_name );
						if ( '' != $font_variant || 'regular' != $font_variant ) {
							$font_call .= ':' . $font_variant;
							$eq_name   .= '-' . $font_variant;
						}
						$link = 'https://fonts.googleapis.com/css?family=' . $font_call . $subset_call;

						if ( ! wp_script_is( 'ultimate-vc-addons-' . $eq_name, 'registered' ) ) {
							wp_register_style( 'ultimate-vc-addons-' . $eq_name, $link );// @codingStandardsIgnoreLine.
							wp_enqueue_style( 'ultimate-vc-addons-' . $eq_name );
						} elseif ( wp_script_is( 'ultimate-vc-addons-' . $eq_name, 'registered' ) ) {
							wp_enqueue_style( 'ultimate-vc-addons-' . $eq_name );
						}
					}
				} else // font is without varients.
				{
					$eq_name = $font_arr[0];
					$link    = 'https://fonts.googleapis.com/css?family=' . $eq_name;

					if ( '' != $eq_name ) {
						if ( ! wp_script_is( 'ultimate-vc-addons-' . $eq_name, 'registered' ) ) {
							wp_register_style( 'ultimate-vc-addons-' . $eq_name, $link );// @codingStandardsIgnoreLine.
							wp_enqueue_style( 'ultimate-vc-addons-' . $eq_name );
						} elseif ( wp_script_is( 'ultimate-vc-addons-' . $eq_name, 'registered' ) ) {
							wp_enqueue_style( 'ultimate-vc-addons-' . $eq_name );
						}
					}
				}
			}
		}
	}
}
if ( ! function_exists( 'get_ultimate_font_family' ) ) {
	/**
	 * Get ultimate font family.
	 *
	 * @since ----
	 * @param mixed $font_attributes attr variable.
	 * @access public
	 */
	function get_ultimate_font_family( $font_attributes ) {
		if ( ! empty( $font_attributes ) ) {
			$font_family_arr = explode( '|', $font_attributes );
			$font_family_str = $font_family_arr[0];
			$font_family     = explode( ':', $font_family_str );
			if ( isset( $font_family[1] ) && '' != $font_family[1] ) {
				return $font_family[1];
			} else {
				return '';
			}
		} else {
			return '';
		}
	}
}
if ( ! function_exists( 'get_ultimate_font_style' ) ) {
	/**
	 * Get ultimate font style.
	 *
	 * @since ----
	 * @param mixed $font_style font style.
	 * @access public
	 */
	function get_ultimate_font_style( $font_style ) {
		$weight_match = 0;
		$temp         = '';
		if ( '' != $font_style ) {
			$font_styles = explode( ',', $font_style ); // split by comma<strong></strong>.
			foreach ( $font_styles as $fstyle ) {
				$temp .= $fstyle; // convert to css.
				if ( preg_match( '/font-weight:/i', $fstyle ) ) {
					$weight_match++;
				}
			}
		}
		// hack to font weight to normal if font weight not available.
		if ( 0 == $weight_match ) {
			$temp .= 'font-weight:normal;';
		}
		return $temp;
	}
}

if ( ! function_exists( 'enquque_ultimate_google_fonts_optimzed' ) ) {
	/**
	 * Get enquque ultimate google fonts optimzed.
	 *
	 * @since ----
	 * @param mixed $enqueue_fonts enquip fonts.
	 * @access public
	 */
	function enquque_ultimate_google_fonts_optimzed( $enqueue_fonts ) {

		$selected_fonts = apply_filters( 'enquque_selected_ultimate_google_fonts', get_option( 'ultimate_selected_google_fonts' ) );

		if ( ! is_array( $selected_fonts ) ) {
			$selected_fonts = array();
		}

		$skip_font_enqueue = apply_filters( 'enquque_ultimate_google_fonts_skip', false );

		if ( true == $skip_font_enqueue ) {
			return '';
		}

		$main              = array();
		$subset_main_array = array();
		$fonts             = array();
		$subset_call       = '';

		if ( ! empty( $enqueue_fonts ) ) {
			$font_count = 0;
			foreach ( $enqueue_fonts as $key => $efont ) {
				$font_name       = '';
				$font_call       = '';
				$font_variant    = '';
				$font_arr        = array();
				$font_call_arr   = array();
				$font_weight_arr = array();
				$font_arr        = explode( '|', $efont );

				$font_name = trim( $font_arr[0] );

				if ( ! isset( $main[ $font_name ] ) ) {
					$main[ $font_name ] = array();
				}

				if ( ! empty( $font_name ) ) :

					$font_count++;
					if ( isset( $font_arr[1] ) ) {
						$font_call_arr = explode( ':', $font_arr[1] );

						if ( isset( $font_arr[2] ) ) {
							$font_weight_arr = explode( ':', $font_arr[2] );
						}

						if ( isset( $font_call_arr[1] ) && '' != $font_call_arr[1] ) {
							$font_variant  = $font_call_arr[1];
							$pre_font_call = $font_name;

							if ( '' != $font_variant && 'regular' !== $font_variant ) {
								$main[ $font_name ]['varients'][] = $font_variant;
								array_push( $main[ $font_name ]['varients'], $font_variant );
								if ( ! empty( $main[ $font_name ]['varients'] ) ) {
									$main[ $font_name ]['varients'] = array_values( array_unique( $main[ $font_name ]['varients'] ) );
								}
							}
						}
					}

					foreach ( $selected_fonts as $sfont ) {
						if ( ! isset( $sfont['font_family'] ) || $sfont['font_family'] != $font_name ) {
							continue;
						}
						$subset_array = uavc_get_selected_font_values(
							isset( $sfont['subsets'] ) ? $sfont['subsets'] : array(),
							'subset_value',
							'subset_selected'
						);
						if ( ! empty( $subset_array ) ) {
							array_push( $subset_main_array, implode( ',', $subset_array ) );
						}
					}
				endif;
			}

			$link       = 'https://fonts.googleapis.com/css?family=';
			$main_count = count( $main );
			$mcount     = 0;

			foreach ( $main as $font => $font_data ) {
				if ( '' !== $font ) {
					$link .= $font;
					if ( 'Open+Sans+Condensed' == $font && empty( $font_data['varients'] ) ) {
						$link .= ':300';
					}
					if ( ! empty( $font_data['varients'] ) ) {
						$link         .= ':regular,';
						$varient_count = count( $font_data['varients'] );
						foreach ( $font_data['varients'] as $vkey => $varient ) {
							$link .= $varient;
							if ( ( $varient_count - 1 ) != $vkey ) {
								$link .= ',';
							}
						}
					}

					if ( ! empty( $font_data['subset'] ) ) {
						$subset_string .= '&subset=' . $font_data['subset'];
					}

					if ( ( $main_count - 1 ) != $mcount ) {
						$link .= '|';
					}
					$mcount++;
				}
			}

			$subset_string = '';

			if ( ! empty( $subset_array ) ) {
				$subset_main_array = array_unique( $subset_main_array );

				$subset_string     = '&subset=';
				$subset_count      = count( $subset_main_array );
				$subset_main_array = array_values( $subset_main_array );

				foreach ( $subset_main_array as $skey => $subset ) {
					if ( '' !== $subset ) {
						$subset_string .= $subset;
						if ( ( $subset_count - 1 ) != $skey ) {
							$subset_string .= ',';
						}
					}
				}
			}

			$font_api_call = $link . $subset_string;

			if ( $font_count > 0 ) {
				wp_enqueue_style( 'ultimate-vc-addons-google-fonts', $font_api_call, array(), null );// @codingStandardsIgnoreLine.
			}
		}
	}
}
