<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Deprecated gateway handling.
 *
 * Keeps deprecated gateways loading on sites that still use them, and provides
 * the workflow to migrate the remaining active subscriptions off of a
 * deprecated gateway (either to placeholder Stripe subscriptions or to
 * expiration dates) so the stored gateway credentials can be removed.
 *
 * @since 3.9
 */

/**
 * Get the list of deprecated gateways.
 *
 * @since 3.5
 */
function pmpro_get_deprecated_gateways() {
	return apply_filters( 'pmpro_deprecated_gateways', array(
		'twocheckout',
		'cybersource',
		'paypalwpp',
		'authorizenet',
		'payflowpro',
		'paypalstandard',
		'braintree',
		'paypalexpress',
	) );
}

/**
 * Get the list of deprecated gateways that are still loaded by this site.
 *
 * @since 3.9
 *
 * @return array
 */
function pmpro_get_undeprecated_gateways() {
	$undeprecated_gateways = get_option( 'pmpro_undeprecated_gateways' );
	if ( empty( $undeprecated_gateways ) ) {
		return array();
	}

	if ( is_string( $undeprecated_gateways ) ) {
		// pmpro_setOption turns this into a comma separated string.
		$undeprecated_gateways = explode( ',', $undeprecated_gateways );
	}

	return array_values( array_filter( array_map( 'sanitize_key', (array) $undeprecated_gateways ) ) );
}

/**
 * Whether the site has any deprecated gateways still loaded.
 *
 * @since 3.9
 *
 * @return bool
 */
function pmpro_has_undeprecated_gateways() {
	return ! empty( pmpro_get_undeprecated_gateways() );
}

/**
 * Adds back deprecated gateways if they have ever been the selected gateway.
 * In future versions, we will remove gateway code entirely.
 * And you will have to use a stand alone add on for those gateways
 * or choose a new gateway.
 */
function pmpro_check_for_deprecated_gateways() {
	$undeprecated_gateways = pmpro_get_undeprecated_gateways();
	$default_gateway = get_option( 'pmpro_gateway' );

	$deprecated_gateways = pmpro_get_deprecated_gateways();
	foreach ( $deprecated_gateways as $deprecated_gateway ) {
		if ( $default_gateway === $deprecated_gateway || in_array( $deprecated_gateway, $undeprecated_gateways, true ) ) {
			require_once( PMPRO_DIR . '/classes/gateways/class.pmprogateway_' . $deprecated_gateway . '.php' );
			if ( ! in_array( $deprecated_gateway, $undeprecated_gateways, true ) ) {
				$undeprecated_gateways[] = $deprecated_gateway;
				update_option( 'pmpro_undeprecated_gateways', $undeprecated_gateways );
			}
		}
	}
}

/**
 * Normalize a gateway environment value to 'live' or 'sandbox'.
 *
 * Subscriptions can carry nonstandard environment values (imports, hand-edited
 * data, very old rows). The workflow treats anything that is not 'live' as
 * sandbox everywhere: in the counts, in the batch queries, and in the
 * per-subscription checks. Counting a subscription in one place but refusing
 * to process it in another would leave the workflow unable to finish and
 * cleanup permanently blocked.
 *
 * @since 3.9
 *
 * @param string $environment Gateway environment value.
 * @return string 'live' or 'sandbox'.
 */
function pmpro_deprecated_gateway_normalize_environment( $environment ) {
	return 'live' === $environment ? 'live' : 'sandbox';
}

/**
 * Get the number of active subscriptions for a gateway in each environment.
 *
 * @since 3.9
 *
 * @param string $gateway Gateway slug.
 * @return array Counts keyed 'live' and 'sandbox'. Unrecognized environments count as sandbox.
 */
function pmpro_deprecated_gateway_get_subscription_counts( $gateway ) {
	global $wpdb;

	$counts = array(
		'live'    => 0,
		'sandbox' => 0,
	);

	$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Queries the PMPro subscriptions custom table, which has no WordPress API or object cache layer.
		$wpdb->prepare(
			"SELECT gateway_environment, COUNT(*) as count
				FROM {$wpdb->pmpro_subscriptions}
				WHERE gateway = %s AND status = 'active'
				GROUP BY gateway_environment",
			$gateway
		)
	);
	foreach ( $rows as $row ) {
		$counts[ pmpro_deprecated_gateway_normalize_environment( $row->gateway_environment ) ] += (int) $row->count;
	}

	return $counts;
}

/**
 * Get active subscription IDs for a gateway/environment after a given ID.
 *
 * @since 3.9
 *
 * @param string $gateway Gateway slug.
 * @param string $environment Gateway environment. 'sandbox' matches every
 *               non-live environment value, mirroring how
 *               pmpro_deprecated_gateway_get_subscription_counts() buckets them.
 * @param int    $last_subscription_id Last subscription ID already queried.
 * @param int    $limit Number of subscription IDs to return.
 * @return int[]
 */
function pmpro_deprecated_gateway_get_active_subscription_ids( $gateway, $environment, $last_subscription_id = 0, $limit = 10 ) {
	global $wpdb;

	$environment_condition = 'live' === $environment ? "gateway_environment = 'live'" : "gateway_environment != 'live'";

	// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- $environment_condition is only ever one of the two hard-coded clauses above.
	$subscription_ids = $wpdb->get_col( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Queries the PMPro subscriptions custom table, which has no WordPress API or object cache layer.
		$wpdb->prepare(
			"SELECT id
				FROM {$wpdb->pmpro_subscriptions}
				WHERE gateway = %s
					AND {$environment_condition}
					AND status = 'active'
					AND id > %d
				ORDER BY id ASC
				LIMIT %d",
			$gateway,
			(int) $last_subscription_id,
			(int) $limit
		)
	);
	// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter

	return array_map( 'intval', $subscription_ids );
}

/**
 * Get the Action Scheduler group for a gateway/environment.
 *
 * @since 3.9
 *
 * @param string $gateway Gateway slug.
 * @param string $environment Gateway environment.
 * @return string
 */
function pmpro_deprecated_gateway_get_action_group( $gateway, $environment ) {
	return 'pmpro_deprecated_gateway_' . sanitize_key( $gateway ) . '_' . sanitize_key( $environment );
}

/**
 * Whether pending or running batch actions exist for a gateway/environment.
 *
 * @since 3.9
 *
 * @param string $gateway Gateway slug.
 * @param string $environment Gateway environment.
 * @return bool
 */
function pmpro_deprecated_gateway_has_scheduled_actions( $gateway, $environment ) {
	if ( ! function_exists( 'as_has_scheduled_action' ) ) {
		return false;
	}

	return as_has_scheduled_action( 'pmpro_deprecated_gateway_process_batch', null, pmpro_deprecated_gateway_get_action_group( $gateway, $environment ) );
}

/**
 * Get the saved workflow state for a gateway/environment.
 *
 * @since 3.9
 *
 * @param string $gateway Gateway slug.
 * @param string $environment Gateway environment.
 * @return array Empty array if no workflow has run.
 */
function pmpro_deprecated_gateway_get_state( $gateway, $environment ) {
	$state = get_option( 'pmpro_deprecated_gateway_state_' . sanitize_key( $gateway ) . '_' . sanitize_key( $environment ) );
	return is_array( $state ) ? $state : array();
}

/**
 * Merge changes into the saved workflow state for a gateway/environment.
 *
 * @since 3.9
 *
 * @param string $gateway Gateway slug.
 * @param string $environment Gateway environment.
 * @param array  $changes State keys to update.
 * @return array The updated state.
 */
function pmpro_deprecated_gateway_update_state( $gateway, $environment, $changes ) {
	$state = array_merge( pmpro_deprecated_gateway_get_state( $gateway, $environment ), $changes, array( 'updated_at' => time() ) );
	update_option( 'pmpro_deprecated_gateway_state_' . sanitize_key( $gateway ) . '_' . sanitize_key( $environment ), $state, false );
	return $state;
}

/**
 * Record the result of processing one subscription in the workflow state and log.
 *
 * @since 3.9
 *
 * @param string $gateway Gateway slug.
 * @param string $environment Gateway environment.
 * @param string $outcome One of 'complete', 'skipped', 'needs_review'.
 * @param string $message Log message.
 */
function pmpro_deprecated_gateway_record_result( $gateway, $environment, $outcome, $message ) {
	if ( ! in_array( $outcome, array( 'complete', 'skipped', 'needs_review' ), true ) ) {
		$outcome = 'needs_review';
	}

	// Only write the counters being incremented. Writing the full state back
	// would revert a concurrent status change (e.g. an admin stopping the
	// workflow) to the stale snapshot read above.
	$state   = pmpro_deprecated_gateway_get_state( $gateway, $environment );
	$changes = array(
		'processed' => empty( $state['processed'] ) ? 1 : $state['processed'] + 1,
		$outcome    => empty( $state[ $outcome ] ) ? 1 : $state[ $outcome ] + 1,
	);

	pmpro_deprecated_gateway_update_state( $gateway, $environment, $changes );
	pmpro_deprecated_gateway_log( '[' . $outcome . '] ' . $message );
}

/**
 * Schedule a deprecated gateway workflow for the current environment.
 *
 * @since 3.9
 *
 * @param string $gateway Gateway slug.
 * @param string $strategy Strategy slug: 'stripe' or 'expiration'.
 * @param bool   $send_email Whether to email members.
 * @param bool   $expire_past_due Expire the membership and cancel at the gateway for subscriptions
 *               whose next payment date is missing or in the past (instead of skipping them).
 * @param bool   $dry_run Preview the workflow without making changes. Outcomes are
 *               logged, but nothing is created, cancelled, emailed, or saved.
 * @param bool   $manual_cancel_acknowledged Whether the admin acknowledged that this gateway
 *               cannot cancel subscriptions automatically. Required for a real run on such gateways.
 * @return true|WP_Error
 */
function pmpro_deprecated_gateway_schedule( $gateway, $strategy, $send_email = true, $expire_past_due = false, $dry_run = false, $manual_cancel_acknowledged = false ) {
	// Normalize the environment so the state option key always matches what the panel reads.
	$environment = pmpro_deprecated_gateway_normalize_environment( get_option( 'pmpro_gateway_environment', 'sandbox' ) );
	$gateway         = sanitize_key( $gateway );
	$strategy        = sanitize_key( $strategy );
	$send_email      = ! empty( $send_email );
	$expire_past_due = ! empty( $expire_past_due );
	$dry_run         = ! empty( $dry_run );

	if ( ! in_array( $gateway, pmpro_get_deprecated_gateways(), true ) ) {
		return new WP_Error( 'pmpro_deprecated_gateway_not_deprecated', __( 'This workflow is only available for deprecated gateways.', 'paid-memberships-pro' ) );
	}

	if ( ! in_array( $strategy, array( 'stripe', 'expiration' ), true ) ) {
		return new WP_Error( 'pmpro_deprecated_gateway_invalid_strategy', __( 'Invalid migration type.', 'paid-memberships-pro' ) );
	}

	if ( pmpro_is_paused() ) {
		return new WP_Error( 'pmpro_deprecated_gateway_paused', __( 'Paid Memberships Pro services are paused because this looks like a staging or development copy of your site. Resume services before running this workflow.', 'paid-memberships-pro' ) );
	}

	if ( $gateway === get_option( 'pmpro_gateway' ) ) {
		return new WP_Error( 'pmpro_deprecated_gateway_no_replacement', __( 'A different gateway must be active before this workflow can start.', 'paid-memberships-pro' ) );
	}

	if ( 'stripe' === $strategy && 'stripe' !== get_option( 'pmpro_gateway' ) ) {
		return new WP_Error( 'pmpro_deprecated_gateway_stripe_unavailable', __( 'Stripe must be the active payment gateway before subscriptions can be migrated to Stripe.', 'paid-memberships-pro' ) );
	}

	// Refuse to start while Stripe is active without credentials for this environment: a Stripe
	// migration would flag every subscription needs_review, and an expiration migration would send
	// members to a checkout that cannot take payment.
	if ( 'stripe' === get_option( 'pmpro_gateway' ) ) {
		$stripe_blockers = pmpro_deprecated_gateway_get_stripe_migration_blockers();
		if ( ! empty( $stripe_blockers ) ) {
			return new WP_Error( 'pmpro_deprecated_gateway_stripe_not_ready', $stripe_blockers[0] );
		}
	}

	// A real run on a gateway that cannot cancel automatically leaves every member billed by both
	// gateways until the admin cancels each subscription by hand, so make them say so first.
	if ( ! $dry_run && '' !== pmpro_deprecated_gateway_get_manual_cancel_reason( $gateway ) && ! $manual_cancel_acknowledged ) {
		return new WP_Error( 'pmpro_deprecated_gateway_manual_cancel_not_acknowledged', __( 'This gateway cannot cancel subscriptions automatically. Confirm that you will cancel each subscription in the gateway dashboard before starting a real migration.', 'paid-memberships-pro' ) );
	}

	if ( ! function_exists( 'as_enqueue_async_action' ) ) {
		return new WP_Error( 'pmpro_deprecated_gateway_no_action_scheduler', __( 'Action Scheduler is not available, so this workflow cannot be scheduled.', 'paid-memberships-pro' ) );
	}

	$counts = pmpro_deprecated_gateway_get_subscription_counts( $gateway );
	$total  = 'live' === $environment ? $counts['live'] : $counts['sandbox'];
	if ( empty( $total ) ) {
		return new WP_Error( 'pmpro_deprecated_gateway_no_subscriptions', __( 'No active subscriptions were found for this gateway in the current environment.', 'paid-memberships-pro' ) );
	}

	// The state check closes the gap between a concurrent request marking the
	// workflow as running and its first batch action being enqueued.
	$state = pmpro_deprecated_gateway_get_state( $gateway, $environment );
	if (
		pmpro_deprecated_gateway_has_scheduled_actions( $gateway, $environment ) ||
		( ! empty( $state['status'] ) && 'running' === $state['status'] && time() - (int) $state['updated_at'] <= 60 )
	) {
		return new WP_Error( 'pmpro_deprecated_gateway_already_running', __( 'A workflow is already queued or running for this gateway.', 'paid-memberships-pro' ) );
	}

	// A unique, sortable ID for this run. Names the per-run migration CSV and lets
	// each batch write to the same file. A new run (new schedule) gets a new ID.
	$run_id = $gateway . '_' . $environment . '_' . gmdate( 'Ymd-His' ) . ( $dry_run ? '_dryrun' : '' );

	// Start from a clean state so the new run's counters and feed are fresh.
	delete_option( 'pmpro_deprecated_gateway_state_' . $gateway . '_' . $environment );
	pmpro_deprecated_gateway_update_state(
		$gateway,
		$environment,
		array(
			'status'          => 'running',
			'strategy'        => $strategy,
			'send_email'      => $send_email,
			'expire_past_due' => $expire_past_due,
			'dry_run'         => $dry_run,
			'run_id'          => $run_id,
			'started_at'      => time(),
			'completed_at'    => 0,
			'total'           => $total,
			'processed'       => 0,
			'complete'        => 0,
			'skipped'         => 0,
			'needs_review'    => 0,
			'note'            => '',
		)
	);

	// $unique guards against two concurrent start requests both passing the checks
	// above and enqueueing parallel batch chains. Only the initial enqueue can be
	// unique; uniqueness is per hook+group, so using it on the chained enqueue in
	// pmpro_deprecated_gateway_process_batch() would block the next batch.
	$action_id = as_enqueue_async_action(
		'pmpro_deprecated_gateway_process_batch',
		array( $gateway, $environment, $strategy, $send_email ? 1 : 0, $expire_past_due ? 1 : 0, $dry_run ? 1 : 0, 0 ),
		pmpro_deprecated_gateway_get_action_group( $gateway, $environment ),
		true
	);
	if ( empty( $action_id ) ) {
		// A concurrent start request may have won the unique enqueue race, in which
		// case its workflow is running now and the state should be left as is.
		if ( pmpro_deprecated_gateway_has_scheduled_actions( $gateway, $environment ) ) {
			return new WP_Error( 'pmpro_deprecated_gateway_already_running', __( 'A workflow is already queued or running for this gateway.', 'paid-memberships-pro' ) );
		}
		pmpro_deprecated_gateway_update_state( $gateway, $environment, array( 'status' => 'stopped', 'note' => __( 'The workflow could not be scheduled.', 'paid-memberships-pro' ) ) );
		return new WP_Error( 'pmpro_deprecated_gateway_schedule_failed', __( 'The workflow could not be scheduled. Check the migration log for details.', 'paid-memberships-pro' ) );
	}

	// Create the per-run CSV with its header row now that the workflow is queued.
	pmpro_deprecated_gateway_csv_init( $run_id );

	pmpro_deprecated_gateway_log( sprintf( 'Queued deprecated gateway workflow. Gateway=%s, environment=%s, strategy=%s, send_email=%s, expire_past_due=%s, dry_run=%s, subscriptions=%d.', $gateway, $environment, $strategy, $send_email ? 'yes' : 'no', $expire_past_due ? 'yes' : 'no', $dry_run ? 'yes' : 'no', $total ) );

	// Kick the Action Scheduler queue so the workflow starts right away.
	if ( is_callable( array( 'PMPro_Action_Scheduler', 'dispatch_queue' ) ) ) {
		PMPro_Action_Scheduler::dispatch_queue();
	}

	return true;
}

/**
 * Stop a queued or running workflow for the current environment.
 *
 * Pending batches are unscheduled immediately; a batch that is mid-run will
 * finish its current group of subscriptions and then stop.
 *
 * @since 3.9
 *
 * @param string $gateway Gateway slug.
 * @return true|WP_Error
 */
function pmpro_deprecated_gateway_stop( $gateway ) {
	$environment = pmpro_deprecated_gateway_normalize_environment( get_option( 'pmpro_gateway_environment', 'sandbox' ) );
	$gateway     = sanitize_key( $gateway );

	$state = pmpro_deprecated_gateway_get_state( $gateway, $environment );
	if ( empty( $state['status'] ) || 'running' !== $state['status'] ) {
		return new WP_Error( 'pmpro_deprecated_gateway_not_running', __( 'No workflow is currently running for this gateway.', 'paid-memberships-pro' ) );
	}

	if ( function_exists( 'as_unschedule_all_actions' ) ) {
		as_unschedule_all_actions( '', array(), pmpro_deprecated_gateway_get_action_group( $gateway, $environment ) );
	}
	// A stopped dry run changed nothing, so restarting previews everything again.
	$note = empty( $state['dry_run'] )
		? __( 'Stopped by an administrator. Start the workflow again to continue; subscriptions that were already processed will be skipped.', 'paid-memberships-pro' )
		: __( 'Dry run stopped by an administrator. Start it again to preview the migration from the beginning.', 'paid-memberships-pro' );
	pmpro_deprecated_gateway_update_state( $gateway, $environment, array( 'status' => 'stopped', 'note' => $note ) );
	pmpro_deprecated_gateway_log( 'Deprecated gateway workflow stopped by an administrator. Gateway=' . $gateway . ', environment=' . $environment . '.' );

	return true;
}

/**
 * Process one batch of deprecated gateway subscriptions.
 *
 * @since 3.9
 *
 * @param string $gateway Gateway slug.
 * @param string $environment Gateway environment.
 * @param string $strategy Strategy slug.
 * @param bool   $send_email Whether to email members.
 * @param bool   $expire_past_due Expire the membership and cancel at the gateway for subscriptions
 *               whose next payment date is missing or in the past (instead of skipping them).
 * @param bool   $dry_run Preview the workflow without making changes.
 * @param int    $last_subscription_id Last subscription ID processed by the previous batch.
 */
function pmpro_deprecated_gateway_process_batch( $gateway, $environment, $strategy, $send_email = true, $expire_past_due = false, $dry_run = false, $last_subscription_id = 0 ) {
	$gateway              = sanitize_key( $gateway );
	$environment          = sanitize_key( $environment );
	$strategy             = sanitize_key( $strategy );
	$send_email           = ! empty( $send_email );
	$expire_past_due      = ! empty( $expire_past_due );
	$dry_run              = ! empty( $dry_run );
	$last_subscription_id = (int) $last_subscription_id;

	// Never touch gateway APIs from a paused (likely cloned) site. This also protects
	// against a database copied to staging while a workflow was queued on the live site.
	if ( pmpro_is_paused() ) {
		pmpro_deprecated_gateway_update_state( $gateway, $environment, array( 'status' => 'stopped', 'note' => __( 'Stopped because Paid Memberships Pro services are paused on this site.', 'paid-memberships-pro' ) ) );
		pmpro_deprecated_gateway_log( 'Stopped deprecated gateway workflow because PMPro services are paused. Gateway=' . $gateway . ', environment=' . $environment . '.' );
		return;
	}

	// The state option is the control plane: stopping the workflow clears this flag.
	$state = pmpro_deprecated_gateway_get_state( $gateway, $environment );
	if ( empty( $state['status'] ) || 'running' !== $state['status'] ) {
		pmpro_deprecated_gateway_log( 'Skipped a deprecated gateway workflow batch because the workflow is no longer running. Gateway=' . $gateway . ', environment=' . $environment . '.' );
		return;
	}

	// The gateway calls below all use the current environment's endpoints, so bail if
	// the environment or replacement gateway changed since the workflow was scheduled.
	if ( $environment !== pmpro_deprecated_gateway_normalize_environment( get_option( 'pmpro_gateway_environment', 'sandbox' ) )
		|| ! in_array( $strategy, array( 'stripe', 'expiration' ), true )
		|| $gateway === get_option( 'pmpro_gateway' )
		|| ( 'stripe' === $strategy && 'stripe' !== get_option( 'pmpro_gateway' ) )
	) {
		pmpro_deprecated_gateway_update_state( $gateway, $environment, array( 'status' => 'stopped', 'note' => __( 'Stopped because the gateway environment or active gateway changed after the workflow was scheduled.', 'paid-memberships-pro' ) ) );
		pmpro_deprecated_gateway_log( 'Stopped deprecated gateway workflow because the gateway environment or active gateway changed. Gateway=' . $gateway . ', environment=' . $environment . ', strategy=' . $strategy . '.' );
		return;
	}

	// Stripe credentials can be disconnected while a workflow is queued. Stop the
	// run instead of recording a needs_review failure for every remaining
	// subscription.
	if ( 'stripe' === $strategy && ! empty( pmpro_deprecated_gateway_get_stripe_migration_blockers() ) ) {
		pmpro_deprecated_gateway_update_state( $gateway, $environment, array( 'status' => 'stopped', 'note' => __( 'Stopped because Stripe is no longer connected for this gateway environment. Reconnect Stripe and start the workflow again to continue.', 'paid-memberships-pro' ) ) );
		pmpro_deprecated_gateway_log( 'Stopped deprecated gateway workflow because Stripe credentials are missing. Gateway=' . $gateway . ', environment=' . $environment . '.' );
		return;
	}

	/**
	 * Filter the number of subscriptions processed per batch.
	 *
	 * Each batch chains the next one through Action Scheduler, so this controls
	 * how much work happens in a single request, not the total processed. The
	 * default is deliberately small: each Stripe migration can make several
	 * sequential gateway API calls, so a larger batch risks exceeding the PHP
	 * execution time limit mid-run, which would break the chain to the next batch.
	 *
	 * @since 3.9
	 *
	 * @param int    $batch_size Number of subscriptions per batch.
	 * @param string $gateway Gateway slug.
	 * @param string $environment Gateway environment.
	 */
	$batch_size       = (int) apply_filters( 'pmpro_deprecated_gateway_batch_size', 5, $gateway, $environment );
	$batch_size       = $batch_size > 0 ? $batch_size : 5;
	$subscription_ids = pmpro_deprecated_gateway_get_active_subscription_ids( $gateway, $environment, $last_subscription_id, $batch_size );
	if ( empty( $subscription_ids ) ) {
		pmpro_deprecated_gateway_update_state( $gateway, $environment, array( 'status' => 'completed', 'completed_at' => time() ) );
		pmpro_deprecated_gateway_log( ( $dry_run ? 'Deprecated gateway dry run completed; no changes were made. ' : 'Deprecated gateway workflow completed. ' ) . 'Gateway=' . $gateway . ', environment=' . $environment . '.' );
		return;
	}

	$run_id = empty( $state['run_id'] ) ? '' : $state['run_id'];
	foreach ( $subscription_ids as $subscription_id ) {
		$result = pmpro_deprecated_gateway_process_subscription( (int) $subscription_id, $gateway, $environment, $strategy, $send_email, $expire_past_due, $dry_run );
		pmpro_deprecated_gateway_record_result( $gateway, $environment, $result['outcome'], ( $dry_run ? 'Dry run: ' : '' ) . $result['message'] );
		pmpro_deprecated_gateway_csv_append( $run_id, (int) $subscription_id, $result );
	}

	if ( count( $subscription_ids ) < $batch_size ) {
		pmpro_deprecated_gateway_update_state( $gateway, $environment, array( 'status' => 'completed', 'completed_at' => time() ) );
		pmpro_deprecated_gateway_log( ( $dry_run ? 'Deprecated gateway dry run completed; no changes were made. ' : 'Deprecated gateway workflow completed. ' ) . 'Gateway=' . $gateway . ', environment=' . $environment . '.' );
		return;
	}

	$action_id = as_enqueue_async_action(
		'pmpro_deprecated_gateway_process_batch',
		array( $gateway, $environment, $strategy, $send_email ? 1 : 0, $expire_past_due ? 1 : 0, $dry_run ? 1 : 0, max( $subscription_ids ) ),
		pmpro_deprecated_gateway_get_action_group( $gateway, $environment )
	);
	if ( empty( $action_id ) ) {
		pmpro_deprecated_gateway_update_state( $gateway, $environment, array( 'status' => 'stopped', 'note' => __( 'The next batch could not be queued. Start the workflow again to continue.', 'paid-memberships-pro' ) ) );
		pmpro_deprecated_gateway_log( 'Could not queue the next deprecated gateway workflow batch. Gateway=' . $gateway . ', environment=' . $environment . '.' );
	}
}
add_action( 'pmpro_deprecated_gateway_process_batch', 'pmpro_deprecated_gateway_process_batch', 10, 7 );


/**
 * Get the number of payments remaining on a billing-limited subscription.
 *
 * Billing limits do not count the subscription's initial checkout order, so a
 * subscription allows billing_limit + 1 successful orders in total. One initial
 * order is assumed even if it predates the recorded order history.
 *
 * @since 3.9
 *
 * @param PMPro_Subscription $subscription The subscription to check.
 * @return int Remaining payments. 0 or less means the limit is already reached.
 */
function pmpro_deprecated_gateway_get_remaining_payments( $subscription ) {
	$billing_limit = (int) $subscription->get_billing_limit();
	$paid_orders   = count( $subscription->get_orders( array( 'status' => 'success', 'limit' => $billing_limit + 2 ) ) );
	return $billing_limit + 1 - max( 1, $paid_orders );
}

/**
 * Get identifying details for a subscription log entry.
 *
 * @since 3.9
 *
 * @param PMPro_Subscription $subscription The subscription to describe.
 * @return string Subscription details for logs.
 */
function pmpro_deprecated_gateway_get_subscription_log_description( $subscription ) {
	$user = get_userdata( $subscription->get_user_id() );

	if ( empty( $user ) ) {
		$user_description = 'user #' . $subscription->get_user_id() . ' deleted';
	} else {
		$user_description = 'user ' . $user->user_login . ' <' . $user->user_email . '>';
	}

	$subscription_transaction_id = (string) $subscription->get_subscription_transaction_id();
	if ( '' === $subscription_transaction_id ) {
		$subscription_transaction_id = 'not set';
	}

	return 'subscription #' . $subscription->get_id()
		. ' (' . $user_description
		. '; subscription transaction ID: ' . $subscription_transaction_id . ')';
}

/**
 * Build a process-subscription result, including the structured fields recorded
 * in the per-run migration CSV.
 *
 * @since 3.9
 *
 * @param string $outcome One of 'complete', 'skipped', 'needs_review'.
 * @param string $message Log message.
 * @param string $action The action taken (or attempted) for this subscription, for
 *               the CSV (e.g. 'migrated_to_stripe', 'membership_expired',
 *               'cancelled_no_migration', 'cancelled_limit_reached',
 *               'skipped_missed_payment', 'skipped_not_applicable', 'skipped_deleted').
 *               This is the intended path; the 'outcome' field reports whether it
 *               succeeded ('complete'), was 'skipped', or 'needs_review'.
 * @param array  $extra Optional CSV fields: 'handoff_date', 'new_subscription_id',
 *               'new_subscription_transaction_id', 'email_sent'.
 * @return array
 */
function pmpro_deprecated_gateway_subscription_result( $outcome, $message, $action, $extra = array() ) {
	return array_merge(
		array(
			'outcome'                         => $outcome,
			'message'                         => $message,
			'action'                          => $action,
			'handoff_date'                    => '',
			'new_subscription_id'             => '',
			'new_subscription_transaction_id' => '',
			'email_sent'                      => '',
		),
		$extra
	);
}

/**
 * Get the reason a gateway's subscriptions must be cancelled manually, if any.
 *
 * Some deprecated gateways cannot cancel a subscription through their API from
 * this workflow. Their subscriptions are marked cancelled in PMPro and recorded
 * as needs_review so the admin cancels them in the gateway dashboard.
 *
 * @since 3.9
 *
 * @param string $gateway Gateway slug.
 * @return string Empty when the gateway can cancel subscriptions automatically.
 */
function pmpro_deprecated_gateway_get_manual_cancel_reason( $gateway ) {
	switch ( $gateway ) {
		case 'paypalstandard':
		case 'paypalexpress':
		case 'paypalwpp':
			// Every PayPal gateway cancels through the same NVP API credentials. PayPal Standard
			// sites usually never entered them; the others cannot work at all without them.
			if ( empty( get_option( 'pmpro_apiusername' ) ) || empty( get_option( 'pmpro_apipassword' ) ) || empty( get_option( 'pmpro_apisignature' ) ) ) {
				return 'paypalstandard' === $gateway
					? __( 'PayPal Standard cannot cancel subscriptions automatically unless PayPal API credentials (API username, password, and signature) are saved in the gateway settings.', 'paid-memberships-pro' )
					: __( 'The PayPal API credentials (API username, password, and signature) are missing from the gateway settings, so subscriptions cannot be cancelled automatically.', 'paid-memberships-pro' );
			}
			return '';
		case 'twocheckout':
			// The 2Checkout cancel call needs the original sale ID, which subscriptions do not store.
			return __( '2Checkout subscriptions cannot be cancelled automatically from this workflow.', 'paid-memberships-pro' );
	}

	return '';
}

/**
 * Cancel the old gateway subscription as the last step of processing it.
 *
 * @since 3.9
 *
 * @param PMPro_Subscription $subscription The deprecated gateway subscription.
 * @param string             $gateway Gateway slug.
 * @return bool|string True if cancelled at the gateway, false if the gateway call failed, or
 *                     'manual' if the gateway cannot cancel automatically and the subscription
 *                     was only marked cancelled in PMPro.
 */
function pmpro_deprecated_gateway_cancel_old_subscription( $subscription, $gateway ) {
	if ( '' !== pmpro_deprecated_gateway_get_manual_cancel_reason( $gateway ) ) {
		// Mark it cancelled in PMPro, as cancel_at_gateway() does before its gateway call, but skip
		// the API call that cannot succeed and the admin error email it would send for every subscription.
		$subscription->set( 'status', 'cancelled' );
		$subscription->save();
		update_pmpro_subscription_meta( $subscription->get_id(), 'deprecated_gateway_cancel_pending', time() );
		return 'manual';
	}

	$cancelled = $subscription->cancel_at_gateway();
	if ( $cancelled ) {
		delete_pmpro_subscription_meta( $subscription->get_id(), 'deprecated_gateway_cancel_pending' );
	} else {
		// cancel_at_gateway() already marked the row cancelled, so nothing else will notice that the
		// gateway may still be billing it. Record it so cleanup is held until the admin confirms.
		update_pmpro_subscription_meta( $subscription->get_id(), 'deprecated_gateway_cancel_pending', time() );
	}

	return $cancelled;
}

/**
 * Count this gateway's subscriptions that were marked cancelled in PMPro but may
 * still be active at the gateway (manual cancellation, a failed gateway call, or a
 * payment received after migration).
 *
 * Deliberately not scoped to an environment: this gates cleanup, which deletes the
 * credentials for both environments at once, so the confirmation covers both.
 *
 * @since 3.9
 *
 * @param string $gateway Gateway slug.
 * @return int
 */
function pmpro_deprecated_gateway_get_cancel_pending_count( $gateway ) {
	global $wpdb;

	return (int) $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Queries the PMPro subscriptions and subscription meta custom tables, which have no WordPress API or object cache layer.
		$wpdb->prepare(
			"SELECT COUNT(*)
				FROM {$wpdb->pmpro_subscriptions} s
				INNER JOIN {$wpdb->pmpro_subscriptionmeta} sm
					ON s.id = sm.pmpro_subscription_id
					AND sm.meta_key = 'deprecated_gateway_cancel_pending'
				WHERE s.gateway = %s",
			$gateway
		)
	);
}

/**
 * Clear the pending-cancellation markers for a gateway once the admin confirms the
 * subscriptions were cancelled in the gateway dashboard.
 *
 * @since 3.9
 *
 * @param string $gateway Gateway slug.
 */
function pmpro_deprecated_gateway_clear_cancel_pending( $gateway ) {
	global $wpdb;

	$wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Deletes from the PMPro subscription meta custom table with a join, which no WordPress API supports.
		$wpdb->prepare(
			"DELETE sm
				FROM {$wpdb->pmpro_subscriptionmeta} sm
				INNER JOIN {$wpdb->pmpro_subscriptions} s
					ON s.id = sm.pmpro_subscription_id
				WHERE sm.meta_key = 'deprecated_gateway_cancel_pending'
					AND s.gateway = %s",
			$gateway
		)
	);
}

/**
 * Get the log note for a subscription that must be cancelled manually at the gateway.
 *
 * @since 3.9
 *
 * @param string $gateway Gateway slug.
 * @param bool   $dry_run Whether to phrase the note for a dry run.
 * @return string
 */
function pmpro_deprecated_gateway_get_manual_cancel_note( $gateway, $dry_run = false ) {
	if ( '' === pmpro_deprecated_gateway_get_manual_cancel_reason( $gateway ) ) {
		return '';
	}

	if ( $dry_run ) {
		return ' The old gateway subscription would only be marked cancelled in PMPro; it would still need to be cancelled manually in the ' . pmpro_get_gateway_nicename( $gateway ) . ' dashboard.';
	}

	return ' The old gateway subscription was marked cancelled in PMPro but is still active at the gateway. Cancel it manually in the ' . pmpro_get_gateway_nicename( $gateway ) . ' dashboard so the member is not billed twice.';
}

/**
 * Process one deprecated gateway subscription.
 *
 * Order of operations is deliberate: create the replacement (Stripe placeholder
 * or expiration date) first, email the member second, and cancel the old gateway
 * subscription last. Cancelling flips the local status permanently, so anything
 * that must happen for the member needs to happen before that final step.
 *
 * @since 3.9
 *
 * @param int    $subscription_id Subscription ID.
 * @param string $gateway Gateway slug.
 * @param string $environment Gateway environment.
 * @param string $strategy Strategy slug.
 * @param bool   $send_email Whether to email members.
 * @param bool   $expire_past_due Expire the membership and cancel at the gateway for subscriptions
 *               whose next payment date is missing or in the past (instead of skipping them).
 * @param bool   $dry_run Report what would happen without making changes. No
 *               gateway calls, emails, or database writes; gateway-side failures
 *               can only be detected by a real run.
 * @return array See pmpro_deprecated_gateway_subscription_result() for the shape.
 */
function pmpro_deprecated_gateway_process_subscription( $subscription_id, $gateway, $environment, $strategy, $send_email = true, $expire_past_due = false, $dry_run = false ) {
	$subscription = PMPro_Subscription::get_subscription( $subscription_id );
	if ( empty( $subscription ) ) {
		return pmpro_deprecated_gateway_subscription_result( 'skipped', 'Subscription #' . $subscription_id . ' no longer exists.', 'skipped_deleted' );
	}

	// Used in every log message so entries can be traced back to the member and
	// the subscription at the gateway without cross-referencing IDs.
	$subscription_description = pmpro_deprecated_gateway_get_subscription_log_description( $subscription );

	// Non-empty when this gateway cannot cancel subscriptions automatically; appended to dry run outcomes.
	$manual_cancel_note_dry = pmpro_deprecated_gateway_get_manual_cancel_note( $gateway, true );

	if ( 'active' !== $subscription->get_status() || $gateway !== $subscription->get_gateway() || $environment !== pmpro_deprecated_gateway_normalize_environment( $subscription->get_gateway_environment() ) ) {
		return pmpro_deprecated_gateway_subscription_result( 'skipped', ucfirst( $subscription_description ) . ' is no longer an active subscription for this gateway and environment.', 'skipped_not_applicable' );
	}

	// If the user no longer has the level, just cancel the old gateway subscription.
	// (A level ID of 0 would make pmpro_hasMembershipLevel() report true for users with no level.)
	if ( empty( $subscription->get_membership_level_id() ) || ! pmpro_hasMembershipLevel( $subscription->get_membership_level_id(), $subscription->get_user_id() ) ) {
		if ( $dry_run ) {
			return pmpro_deprecated_gateway_subscription_result( '' === $manual_cancel_note_dry ? 'complete' : 'needs_review', 'would cancel ' . $subscription_description . ' without migration because the user no longer has the associated membership level.' . $manual_cancel_note_dry, 'cancelled_no_migration' );
		}
		$cancelled = pmpro_deprecated_gateway_cancel_old_subscription( $subscription, $gateway );
		if ( true === $cancelled ) {
			return pmpro_deprecated_gateway_subscription_result( 'complete', 'Cancelled ' . $subscription_description . ' without migration because the user no longer has the associated membership level.', 'cancelled_no_migration' );
		}
		if ( 'manual' === $cancelled ) {
			return pmpro_deprecated_gateway_subscription_result( 'needs_review', 'Processed ' . $subscription_description . ' without migration because the user no longer has the associated membership level.' . pmpro_deprecated_gateway_get_manual_cancel_note( $gateway ), 'cancelled_no_migration' );
		}
		return pmpro_deprecated_gateway_subscription_result( 'needs_review', 'Could not confirm cancellation of ' . $subscription_description . ' at the gateway. The user no longer has the associated membership level. Verify this subscription in the gateway; an error email was sent to the admin.', 'cancelled_no_migration' );
	}

	// A subscription with Stripe placeholder meta is already mid-migration from an
	// earlier run. A dry run reports that a real run would resume it instead of
	// running the recovery logic below, which clears and rewrites meta.
	if ( $dry_run && ( get_pmpro_subscription_meta( $subscription_id, 'deprecated_gateway_stripe_subscription_id', true ) || get_pmpro_subscription_meta( $subscription_id, 'deprecated_gateway_stripe_transaction_id', true ) ) ) {
		return pmpro_deprecated_gateway_subscription_result( 'complete', ucfirst( $subscription_description ) . ' is already mid-migration from an earlier run. A real run would complete the handoff to Stripe and cancel the old gateway subscription.', 'migrated_to_stripe' );
	}

	// Load a Stripe placeholder created by an earlier run, if any. If one exists,
	// this member is on the Stripe path even if the strategy has since changed.
	$placeholder    = null;
	$placeholder_id = (int) get_pmpro_subscription_meta( $subscription_id, 'deprecated_gateway_stripe_subscription_id', true );
	if ( ! empty( $placeholder_id ) ) {
		$placeholder = PMPro_Subscription::get_subscription( $placeholder_id );
		if ( ! empty( $placeholder ) && 'active' !== $placeholder->get_status() ) {
			// The placeholder died since the last run (e.g. its trial ended without a
			// payment method). Clear the stale references so a fresh one is created
			// and the member is emailed again with the new dates. Bump the attempt
			// counter so the next Stripe create call uses a fresh idempotency key;
			// reusing the old key within 24 hours would make Stripe replay the
			// original response and hand back the dead subscription.
			update_pmpro_subscription_meta( $subscription_id, 'deprecated_gateway_stripe_attempt', (int) get_pmpro_subscription_meta( $subscription_id, 'deprecated_gateway_stripe_attempt', true ) + 1 );
			delete_pmpro_subscription_meta( $subscription_id, 'deprecated_gateway_stripe_subscription_id' );
			delete_pmpro_subscription_meta( $subscription_id, 'deprecated_gateway_stripe_transaction_id' );
			delete_pmpro_subscription_meta( $subscription_id, 'deprecated_gateway_email_sent' );
			$placeholder = null;
		}
	}

	// A Stripe subscription created by an earlier run that failed before saving the
	// local record. Loaded here so the check below never mistakes its local record
	// (created but not yet linked by meta when the earlier run died) for an
	// unrelated subscription.
	$transaction_id = (string) get_pmpro_subscription_meta( $subscription_id, 'deprecated_gateway_stripe_transaction_id', true );

	// If the user already has another active subscription for this level (e.g. they
	// already checked out again on the new gateway), just cancel the old gateway
	// subscription instead of migrating or setting an expiration date. Only
	// subscriptions in the same environment count: a leftover sandbox subscription
	// must never decide the fate of a live one.
	$other_subscriptions = PMPro_Subscription::get_subscriptions_for_user( $subscription->get_user_id(), $subscription->get_membership_level_id() );
	foreach ( $other_subscriptions as $other_subscription ) {
		if (
			$environment !== pmpro_deprecated_gateway_normalize_environment( $other_subscription->get_gateway_environment() )
			|| (int) $other_subscription->get_id() === (int) $subscription_id
			|| ( ! empty( $placeholder ) && (int) $other_subscription->get_id() === (int) $placeholder->get_id() )
			|| ( '' !== $transaction_id && (string) $other_subscription->get_subscription_transaction_id() === $transaction_id )
		) {
			continue;
		}
		if ( $dry_run ) {
			return pmpro_deprecated_gateway_subscription_result( '' === $manual_cancel_note_dry ? 'complete' : 'needs_review', 'would cancel ' . $subscription_description . ' without migration because the user already has active subscription #' . $other_subscription->get_id() . ' for this level.' . $manual_cancel_note_dry, 'cancelled_no_migration' );
		}
		$cancelled = pmpro_deprecated_gateway_cancel_old_subscription( $subscription, $gateway );
		if ( true === $cancelled ) {
			return pmpro_deprecated_gateway_subscription_result( 'complete', 'Cancelled ' . $subscription_description . ' without migration because the user already has active subscription #' . $other_subscription->get_id() . ' for this level.', 'cancelled_no_migration' );
		}
		if ( 'manual' === $cancelled ) {
			return pmpro_deprecated_gateway_subscription_result( 'needs_review', 'Processed ' . $subscription_description . ' without migration because the user already has active subscription #' . $other_subscription->get_id() . ' for this level.' . pmpro_deprecated_gateway_get_manual_cancel_note( $gateway ), 'cancelled_no_migration' );
		}
		return pmpro_deprecated_gateway_subscription_result( 'needs_review', 'Could not confirm cancellation of ' . $subscription_description . ' at the gateway. The user already has active subscription #' . $other_subscription->get_id() . ' for this level. Verify this subscription in the gateway; an error email was sent to the admin.', 'cancelled_no_migration' );
	}

	// The next payment date is the handoff point: when the new Stripe subscription
	// starts billing or when the membership expires. It is only needed when a
	// replacement has not been created yet by an earlier run. An active subscription
	// should always have an upcoming payment date, so a missing or past date is
	// treated the same: it usually means a payment notification (IPN/webhook) was
	// missed and the gateway may actually still be billing, so these are skipped by
	// default and only expired when the admin explicitly opts in.
	$handoff_timestamp = $subscription->get_next_payment_date( 'timestamp', false );
	$expire_this_subscription  = false;
	if ( empty( $placeholder ) && ( empty( $handoff_timestamp ) || $handoff_timestamp <= time() ) ) {
		if ( ! $expire_past_due ) {
			return pmpro_deprecated_gateway_subscription_result( 'skipped', ucfirst( $subscription_description ) . ' has a next payment date in the past (or none at all). This is often caused by a missed IPN or webhook, so the gateway may still be billing it. Verify this subscription at the gateway and migrate it manually, or run the migration again set to cancel and expire subscriptions with a missed payment.', 'skipped_missed_payment' );
		}
		// Admin chose to expire: expire the membership and cancel below. The three day minimum
		// below moves the expiration date out of the past.
		$expire_this_subscription  = true;
		$handoff_timestamp = empty( $handoff_timestamp ) ? time() : $handoff_timestamp;
	}

	// Give members time to act on the email. A handoff within the next few days (or in the past, for
	// a missed payment) would have Stripe cancel the placeholder, or the membership expire, almost as
	// soon as the email arrives. Push it out to a minimum of three days. The old gateway subscription
	// is cancelled below, so (where the gateway supports cancellation) the member is not charged there
	// in between.
	$handoff_note = '';
	if ( empty( $placeholder ) && $handoff_timestamp < time() + 3 * DAY_IN_SECONDS ) {
		$handoff_timestamp = time() + 3 * DAY_IN_SECONDS;
		$handoff_note      = ( $expire_this_subscription ? ' The missed payment date is in the past' : ' The next payment date was less than three days away' ) . ', so the handoff was moved to ' . gmdate( 'Y-m-d', $handoff_timestamp ) . ' to give the member time to act.';
	}

	$use_stripe = ( 'stripe' === $strategy && ! $expire_this_subscription ) || ! empty( $placeholder );

	// Set below if the $0 billing limit bridge order cannot be saved.
	$bridge_note         = '';
	$bridge_needs_review = false;

	if ( $use_stripe ) {
		if ( empty( $placeholder ) ) {
			// Billing limits migrate as a remaining-payment count on the new
			// subscription, enforced locally by order counting just like native
			// Stripe subscriptions.
			$remaining_payments = 0;
			if ( ! empty( $subscription->get_billing_limit() ) ) {
				$remaining_payments = pmpro_deprecated_gateway_get_remaining_payments( $subscription );
				if ( $remaining_payments < 1 ) {
					// The limit was already reached, so no replacement is needed and
					// the membership is left unchanged, matching billing limit semantics.
					if ( $dry_run ) {
						return pmpro_deprecated_gateway_subscription_result( '' === $manual_cancel_note_dry ? 'complete' : 'needs_review', 'would cancel ' . $subscription_description . ' without migration because its billing limit has already been reached. The membership would be left unchanged and no email would be sent.' . $manual_cancel_note_dry, 'cancelled_limit_reached' );
					}
					$cancelled = pmpro_deprecated_gateway_cancel_old_subscription( $subscription, $gateway );
					if ( true === $cancelled ) {
						return pmpro_deprecated_gateway_subscription_result( 'complete', 'Cancelled ' . $subscription_description . ' without migration because its billing limit has already been reached. The membership was left unchanged and no email was sent.', 'cancelled_limit_reached' );
					}
					if ( 'manual' === $cancelled ) {
						return pmpro_deprecated_gateway_subscription_result( 'needs_review', 'Processed ' . $subscription_description . ' without migration because its billing limit has already been reached. The membership was left unchanged and no email was sent.' . pmpro_deprecated_gateway_get_manual_cancel_note( $gateway ), 'cancelled_limit_reached' );
					}
					return pmpro_deprecated_gateway_subscription_result( 'needs_review', 'Could not confirm cancellation of ' . $subscription_description . ' at the gateway. Its billing limit has already been reached. Verify this subscription in the gateway; an error email was sent to the admin.', 'cancelled_limit_reached' );
				}
			}

			// If an earlier run created the Stripe subscription but failed before saving
			// the local record, $transaction_id (loaded above) lets us reuse it instead
			// of creating a duplicate at Stripe.
			if ( '' === $transaction_id ) {
				if ( ! class_exists( 'PMProGateway_stripe' ) || ! method_exists( 'PMProGateway_stripe', 'create_deprecated_gateway_migration_subscription' ) ) {
					return pmpro_deprecated_gateway_subscription_result( 'needs_review', 'Could not create a Stripe placeholder for ' . $subscription_description . ' because the Stripe gateway is not available.', 'migrated_to_stripe' );
				}
				if ( $dry_run ) {
					// No Stripe calls in a dry run. Replicate the create call's local
					// validations so data problems a real run would hit still show up
					// in the preview; Stripe-side failures only surface in a real run.
					if ( empty( get_userdata( $subscription->get_user_id() ) ) ) {
						return pmpro_deprecated_gateway_subscription_result( 'needs_review', 'could not create a Stripe placeholder for ' . $subscription_description . ' because the user no longer exists.', 'migrated_to_stripe' );
					}
					$dry_run_level = new PMPro_Membership_Level( $subscription->get_membership_level_id() );
					if ( empty( $dry_run_level->ID ) ) {
						return pmpro_deprecated_gateway_subscription_result( 'needs_review', 'could not create a Stripe placeholder for ' . $subscription_description . ' because the membership level no longer exists.', 'migrated_to_stripe' );
					}
				} else {
					$stripe_gateway          = new PMProGateway_stripe( 'stripe' );
					$stripe_api_subscription = $stripe_gateway->create_deprecated_gateway_migration_subscription(
						$subscription,
						array(
							'trial_end' => $handoff_timestamp,
							'attempt'   => (int) get_pmpro_subscription_meta( $subscription_id, 'deprecated_gateway_stripe_attempt', true ),
						)
					);
					if ( is_wp_error( $stripe_api_subscription ) ) {
						return pmpro_deprecated_gateway_subscription_result( 'needs_review', 'Could not create a Stripe placeholder for ' . $subscription_description . '. Error: ' . $stripe_api_subscription->get_error_message(), 'migrated_to_stripe' );
					}
					$transaction_id = $stripe_api_subscription->id;
					update_pmpro_subscription_meta( $subscription_id, 'deprecated_gateway_stripe_transaction_id', $transaction_id );
				}
			}

			// Everything below saves the new placeholder, so a dry run is done with
			// this subscription once the validations above have passed.
			if ( ! $dry_run ) {
				// The Stripe webhook or an earlier run may have already created the local
				// record. Only adopt an active one: a cancelled record with this
				// transaction ID means the Stripe subscription is dead, and create()
				// below will return null for it, surfacing this as needs_review instead
				// of silently migrating the member onto a dead subscription.
				$placeholder = PMPro_Subscription::get_subscription(
					array(
						'subscription_transaction_id' => $transaction_id,
						'gateway'                     => 'stripe',
						'gateway_environment'         => $environment,
						'status'                      => 'active',
					)
				);
				if ( empty( $placeholder ) ) {
					$placeholder = PMPro_Subscription::create(
						array(
							'user_id'                     => $subscription->get_user_id(),
							'membership_level_id'         => $subscription->get_membership_level_id(),
							'gateway'                     => 'stripe',
							'gateway_environment'         => $environment,
							'subscription_transaction_id' => $transaction_id,
							'status'                      => 'active',
							'startdate'                   => gmdate( 'Y-m-d H:i:s' ),
							'next_payment_date'           => gmdate( 'Y-m-d H:i:s', $handoff_timestamp ),
							'billing_amount'              => $subscription->get_billing_amount(),
							'cycle_number'                => $subscription->get_cycle_number(),
							'cycle_period'                => $subscription->get_cycle_period(),
							'billing_limit'               => $remaining_payments,
						)
					);
				}
				// create() syncs the new record with Stripe, so a subscription that already died
				// there (e.g. its trial ended before a rerun got this far) comes back cancelled, and
				// a cancelled record left by the webhook makes create() return null. Either way,
				// clear the reference and bump the attempt counter so the next run creates a fresh
				// placeholder with a new idempotency key instead of migrating the member onto a
				// dead subscription.
				if ( empty( $placeholder ) || 'active' !== $placeholder->get_status() ) {
					update_pmpro_subscription_meta( $subscription_id, 'deprecated_gateway_stripe_attempt', (int) get_pmpro_subscription_meta( $subscription_id, 'deprecated_gateway_stripe_attempt', true ) + 1 );
					delete_pmpro_subscription_meta( $subscription_id, 'deprecated_gateway_stripe_transaction_id' );
					return pmpro_deprecated_gateway_subscription_result( 'needs_review', 'Stripe subscription ' . $transaction_id . ' for ' . $subscription_description . ( empty( $placeholder ) ? ' could not be saved as a PMPro subscription' : ' is no longer active at Stripe' ) . ', so the member was not migrated onto it. Run the migration again to create a fresh Stripe placeholder, and verify ' . $transaction_id . ' in Stripe.', 'migrated_to_stripe', array( 'new_subscription_transaction_id' => $transaction_id ) );
				}

				update_pmpro_subscription_meta( $subscription_id, 'deprecated_gateway_stripe_subscription_id', $placeholder->get_id() );
			}
		}

		if ( ! $dry_run && ! empty( $placeholder ) ) {
			// Per-placeholder bookkeeping, kept outside the creation block so a rerun after a crash
			// between saving the placeholder reference and this point still completes it. The
			// back-reference doubles as the "already flagged" marker so a member who has since
			// added a payment method is not flagged again.
			if ( empty( get_pmpro_subscription_meta( $placeholder->get_id(), 'deprecated_gateway_old_subscription_id', true ) ) ) {
				pmpro_deprecated_gateway_flag_needs_payment_method( $placeholder->get_id() );
				update_pmpro_subscription_meta( $placeholder->get_id(), 'deprecated_gateway_old_subscription_id', $subscription_id );
			}

			// Billing limits do not count a subscription's initial order, but a
			// migrated subscription never has one. Record a $0 migration order so
			// the remaining-payment count is enforced exactly. The lookup mirrors
			// billing limit enforcement, which only counts successful orders.
			if ( ! empty( $placeholder->get_billing_limit() ) && empty( $placeholder->get_orders( array( 'status' => 'success', 'limit' => 1 ) ) ) ) {
				$bridge_order                              = new MemberOrder();
				$bridge_order->user_id                     = $subscription->get_user_id();
				$bridge_order->membership_id               = $subscription->get_membership_level_id();
				$bridge_order->gateway                     = 'stripe';
				$bridge_order->gateway_environment         = $environment;
				$bridge_order->subscription_transaction_id = $placeholder->get_subscription_transaction_id();
				$bridge_order->total                       = 0;
				$bridge_order->status                      = 'success';
				$bridge_order->notes                       = 'Deprecated gateway migration: stands in for the original checkout order of ' . $gateway . ' ' . $subscription_description . ' so the remaining billing limit of ' . (int) $placeholder->get_billing_limit() . ' is enforced.';
				if ( ! $bridge_order->saveOrder() ) {
					// Reruns only retry this while the old subscription is still active, so a
					// silent failure here could permanently under-enforce the limit.
					$bridge_note         = ' Could not save the $0 billing limit order, so the billing limit may allow one extra payment; review this subscription\'s billing limit in PMPro.';
					$bridge_needs_review = true;
				}
			}
		}
	} elseif ( ! $dry_run ) {
		pmpro_set_expiration_date( $subscription->get_user_id(), $subscription->get_membership_level_id(), $handoff_timestamp );
	}
	if ( ! $dry_run && ! empty( $handoff_timestamp ) ) {
		update_pmpro_subscription_meta( $subscription_id, 'deprecated_gateway_handoff_date', gmdate( 'Y-m-d H:i:s', $handoff_timestamp ) );
	}

	// Email the member before cancelling so a cancellation failure never leaves
	// a member unnotified. A meta flag prevents duplicate emails across reruns.
	$email_note         = '';
	$email_needs_review = false;
	$already_emailed    = (bool) get_pmpro_subscription_meta( $subscription_id, 'deprecated_gateway_email_sent', true );
	// CSV field: 'yes' if the member has been emailed (now or on an earlier run),
	// 'no' if not, 'failed' if a send was attempted and failed, 'would' on a dry run.
	$email_sent_status  = $already_emailed ? 'yes' : 'no';
	if ( $send_email && ! $already_emailed ) {
		$user = get_userdata( $subscription->get_user_id() );
		if ( empty( $user ) ) {
			$email_note         = ' Could not email the member because the user no longer exists.';
			$email_needs_review = true;
			$email_sent_status  = 'failed';
		} elseif ( $dry_run ) {
			$email_note        = ' Would email the member.';
			$email_sent_status = 'would';
		} else {
			$email = $use_stripe
				? new PMPro_Email_Template_Deprecated_Gateway_Stripe_Migration( $placeholder )
				: new PMPro_Email_Template_Deprecated_Gateway_Checkout_Required( $user, (int) $subscription->get_membership_level_id(), (int) $handoff_timestamp );
			if ( $email->send() ) {
				update_pmpro_subscription_meta( $subscription_id, 'deprecated_gateway_email_sent', time() );
				$email_note        = ' Emailed the member.';
				$email_sent_status = 'yes';
			} else {
				$email_note         = ' The member email failed to send.';
				$email_needs_review = true;
				$email_sent_status  = 'failed';
			}
		}
	}

	// Shared CSV fields for the final outcomes below.
	$handoff_date = empty( $handoff_timestamp ) ? '' : gmdate( 'Y-m-d', $handoff_timestamp );

	// Surface the billing terms copied to Stripe in the log so admins can sanity check them.
	// pmpro_formatPrice() entity-encodes the currency symbol for HTML; decode it for the plain-text log and CSV.
	// (e.g. sites that add tax at checkout). A real run reports the placeholder, which reflects
	// the Stripe price after sync; a dry run only has the old subscription's stored terms.
	$stored_amount = $subscription->get_billing_amount();
	$billing_terms = '';
	if ( $use_stripe ) {
		if ( ! $dry_run && ! empty( $placeholder ) ) {
			$billing_terms = ' at ' . html_entity_decode( $placeholder->get_cost_text(), ENT_QUOTES, 'UTF-8' );
		} elseif ( empty( $stored_amount ) ) {
			// get_billing_amount() returns a float, so 0.00 is the "missing" value; the Stripe
			// method falls back to the level's billing amount in that case.
			$billing_terms = ' at the level\'s current billing price';
		} else {
			$billing_terms = ' at ' . html_entity_decode( $subscription->get_cost_text(), ENT_QUOTES, 'UTF-8' );
		}
	}

	// A dry run reaching this point is always a fresh migration: mid-migration
	// subscriptions returned earlier, so $placeholder is null and
	// $handoff_timestamp is set.
	if ( $dry_run ) {
		$outcome = ( $email_needs_review || '' !== $manual_cancel_note_dry ) ? 'needs_review' : 'complete';
		if ( $use_stripe ) {
			return pmpro_deprecated_gateway_subscription_result( $outcome, 'would migrate ' . $subscription_description . ' to a new Stripe placeholder subscription' . $billing_terms . ' (no payment method, trial ending ' . gmdate( 'Y-m-d', $handoff_timestamp ) . ( empty( $remaining_payments ) ? '' : ', remaining billing limit of ' . $remaining_payments ) . ') and cancel the old gateway subscription.' . $handoff_note . $manual_cancel_note_dry . $email_note, 'migrated_to_stripe', array( 'handoff_date' => $handoff_date, 'email_sent' => $email_sent_status ) );
		}
		return pmpro_deprecated_gateway_subscription_result( $outcome, ( $expire_this_subscription ? 'missed payment: would set' : 'would set' ) . ' the membership expiration date for ' . $subscription_description . ' to ' . gmdate( 'Y-m-d', $handoff_timestamp ) . ' and cancel the old gateway subscription.' . $handoff_note . $manual_cancel_note_dry . $email_note, 'membership_expired', array( 'handoff_date' => $handoff_date, 'email_sent' => $email_sent_status ) );
	}

	$cancelled = pmpro_deprecated_gateway_cancel_old_subscription( $subscription, $gateway );
	if ( false === $cancelled ) {
		// Lead with what was completed so the entry does not read as a failed migration.
		$completed_phrase = $use_stripe
			? 'Migrated ' . $subscription_description . ' to Stripe placeholder subscription #' . $placeholder->get_id() . $billing_terms
			: ( $expire_this_subscription ? 'Missed payment: set' : 'Set' ) . ' the membership expiration date for ' . $subscription_description . ' to ' . $handoff_date;
		return pmpro_deprecated_gateway_subscription_result( 'needs_review', $completed_phrase . ', but could not confirm cancellation of the old gateway subscription. Verify it in the gateway; an error email was sent to the admin.' . $handoff_note . $bridge_note . $email_note, $use_stripe ? 'migrated_to_stripe' : 'membership_expired', array( 'handoff_date' => $handoff_date, 'new_subscription_id' => ( $use_stripe && ! empty( $placeholder ) ) ? $placeholder->get_id() : '', 'new_subscription_transaction_id' => $use_stripe ? $transaction_id : '', 'email_sent' => $email_sent_status ) );
	}

	// Gateways that cannot cancel automatically leave the old subscription active at the gateway.
	$manual_cancel_note = ( 'manual' === $cancelled ) ? pmpro_deprecated_gateway_get_manual_cancel_note( $gateway ) : '';
	$cancel_phrase      = ( 'manual' === $cancelled ) ? ' and marked the old gateway subscription cancelled.' : ' and cancelled the old gateway subscription.';

	$outcome = ( $email_needs_review || $bridge_needs_review || '' !== $manual_cancel_note ) ? 'needs_review' : 'complete';
	if ( $use_stripe ) {
		return pmpro_deprecated_gateway_subscription_result( $outcome, 'Migrated ' . $subscription_description . ' to Stripe placeholder subscription #' . $placeholder->get_id() . $billing_terms . $cancel_phrase . $handoff_note . $manual_cancel_note . $bridge_note . $email_note, 'migrated_to_stripe', array( 'handoff_date' => $handoff_date, 'new_subscription_id' => $placeholder->get_id(), 'new_subscription_transaction_id' => $transaction_id, 'email_sent' => $email_sent_status ) );
	}
	return pmpro_deprecated_gateway_subscription_result( $outcome, ( $expire_this_subscription ? 'Missed payment: set' : 'Set' ) . ' the membership expiration date for ' . $subscription_description . $cancel_phrase . $handoff_note . $manual_cancel_note . $bridge_note . $email_note, 'membership_expired', array( 'handoff_date' => $handoff_date, 'email_sent' => $email_sent_status ) );
}

/**
 * Clean up a deprecated gateway after its subscriptions are handled.
 *
 * Live subscriptions block cleanup no matter which environment is currently
 * selected: the stored credentials are shared by both environments, and
 * deleting them would strand any remaining live subscriptions.
 *
 * @since 3.9
 *
 * @param string $gateway Gateway slug.
 * @param bool   $cancel_pending_confirmed Whether the admin confirmed that subscriptions this
 *               workflow could only mark cancelled in PMPro were cancelled at the gateway.
 * @return true|WP_Error
 */
function pmpro_deprecated_gateway_cleanup_gateway( $gateway, $cancel_pending_confirmed = false ) {
	$gateway = sanitize_key( $gateway );

	if ( ! in_array( $gateway, pmpro_get_deprecated_gateways(), true ) ) {
		return new WP_Error( 'pmpro_deprecated_gateway_cleanup_not_deprecated', __( 'This workflow is only available for deprecated gateways.', 'paid-memberships-pro' ) );
	}

	if ( pmpro_is_paused() ) {
		return new WP_Error( 'pmpro_deprecated_gateway_cleanup_paused', __( 'Paid Memberships Pro services are paused because this looks like a staging or development copy of your site. Resume services before removing gateway data.', 'paid-memberships-pro' ) );
	}

	if ( $gateway === get_option( 'pmpro_gateway' ) ) {
		return new WP_Error( 'pmpro_deprecated_gateway_cleanup_no_replacement', __( 'A different gateway must be active before this gateway can be removed.', 'paid-memberships-pro' ) );
	}

	// The Add PayPal Express Add On offers this gateway at checkout without it being the active
	// gateway, so it has no subscriptions of its own to count. Same detection as the gateway table.
	if ( 'paypalexpress' === $gateway && function_exists( 'pmproappe_pmpro_valid_gateways' ) ) {
		return new WP_Error( 'pmpro_deprecated_gateway_cleanup_add_on_active', __( 'The Add PayPal Express Add On is active and still offers this gateway at checkout. Deactivate it before removing gateway data.', 'paid-memberships-pro' ) );
	}

	$counts = pmpro_deprecated_gateway_get_subscription_counts( $gateway );
	if ( ! empty( $counts['live'] ) ) {
		return new WP_Error(
			'pmpro_deprecated_gateway_cleanup_live_subscriptions',
			sprintf(
				// translators: %d: Number of live subscriptions.
				_n( '%d live subscription is still active for this gateway. Migrate it before removing gateway data.', '%d live subscriptions are still active for this gateway. Migrate them before removing gateway data.', $counts['live'], 'paid-memberships-pro' ),
				$counts['live']
			)
		);
	}

	// The panel only offers cleanup once both environments are at zero; enforce the
	// same rule here so a direct request cannot orphan active sandbox subscriptions
	// by unloading the gateway class they rely on.
	if ( ! empty( $counts['sandbox'] ) ) {
		return new WP_Error(
			'pmpro_deprecated_gateway_cleanup_sandbox_subscriptions',
			sprintf(
				// translators: %d: Number of sandbox subscriptions.
				_n( '%d sandbox subscription is still active for this gateway. Process it in the sandbox environment before removing gateway data.', '%d sandbox subscriptions are still active for this gateway. Process them in the sandbox environment before removing gateway data.', $counts['sandbox'], 'paid-memberships-pro' ),
				$counts['sandbox']
			)
		);
	}

	if ( pmpro_deprecated_gateway_has_scheduled_actions( $gateway, 'live' ) || pmpro_deprecated_gateway_has_scheduled_actions( $gateway, 'sandbox' ) ) {
		return new WP_Error( 'pmpro_deprecated_gateway_cleanup_blocked', __( 'A workflow is queued or running for this gateway. Wait for it to finish or stop it before removing gateway data.', 'paid-memberships-pro' ) );
	}

	// Subscriptions this workflow could only mark cancelled in PMPro may still be billing at the
	// gateway, and the credentials deleted below are what the gateway's IPN/webhook handler
	// needs to process the cancellations the admin was told to make. Hold cleanup until confirmed.
	$cancel_pending = pmpro_deprecated_gateway_get_cancel_pending_count( $gateway );
	if ( $cancel_pending > 0 ) {
		if ( ! $cancel_pending_confirmed ) {
			return new WP_Error(
				'pmpro_deprecated_gateway_cleanup_cancel_pending',
				sprintf(
					// translators: %d: Number of subscriptions.
					_n( '%d subscription was marked cancelled in Paid Memberships Pro but may still be active at the gateway. Cancel it in the gateway dashboard and confirm before removing gateway data.', '%d subscriptions were marked cancelled in Paid Memberships Pro but may still be active at the gateway. Cancel them in the gateway dashboard and confirm before removing gateway data.', $cancel_pending, 'paid-memberships-pro' ),
					$cancel_pending
				)
			);
		}
		pmpro_deprecated_gateway_clear_cancel_pending( $gateway );
		pmpro_deprecated_gateway_log( 'Administrator confirmed that ' . $cancel_pending . ' ' . $gateway . ' subscription(s) marked cancelled in PMPro were cancelled at the gateway.' );
	}

	delete_option( 'pmpro_deprecated_gateway_state_' . $gateway . '_live' );
	delete_option( 'pmpro_deprecated_gateway_state_' . $gateway . '_sandbox' );

	$undeprecated_gateways = array_values( array_diff( pmpro_get_undeprecated_gateways(), array( $gateway ) ) );
	update_option( 'pmpro_undeprecated_gateways', $undeprecated_gateways );

	// Delete stored credentials. The PayPal gateways share one set of credentials,
	// so only delete those once no PayPal gateway is loaded or active.
	$option_names           = array();
	$shared_paypal_gateways = array( 'paypalexpress', 'paypalwpp', 'paypalstandard' );
	if ( in_array( $gateway, $shared_paypal_gateways, true ) ) {
		if ( empty( array_intersect( $shared_paypal_gateways, $undeprecated_gateways ) ) && ! in_array( get_option( 'pmpro_gateway' ), $shared_paypal_gateways, true ) ) {
			$option_names = array( 'gateway_email', 'apiusername', 'apipassword', 'apisignature', 'paypalexpress_skip_confirmation' );
		}
		// Website Payments Pro also stored 3-D Secure (Cardinal) credentials that only it reads.
		if ( 'paypalwpp' === $gateway ) {
			$option_names = array_merge( $option_names, array( 'paypal_enable_3dsecure', 'paypal_cardinal_apikey', 'paypal_cardinal_apiidentifier', 'paypal_cardinal_orgunitid', 'paypal_cardinal_merchantid', 'paypal_cardinal_processorid' ) );
		}
	} else {
		switch ( $gateway ) {
			case 'authorizenet':
				$option_names = array( 'loginname', 'transactionkey', 'authnet_silent_post_token' );
				break;
			case 'payflowpro':
				$option_names = array( 'payflow_partner', 'payflow_vendor', 'payflow_user', 'payflow_pwd' );
				break;
			case 'braintree':
				$option_names = array( 'braintree_merchantid', 'braintree_publickey', 'braintree_privatekey', 'braintree_encryptionkey' );
				break;
			case 'twocheckout':
				$option_names = array( 'twocheckout_apiusername', 'twocheckout_apipassword', 'twocheckout_accountnumber', 'twocheckout_secretword' );
				break;
			case 'cybersource':
				$option_names = array( 'cybersource_merchantid', 'cybersource_securitykey' );
				break;
		}
	}

	foreach ( $option_names as $option_name ) {
		delete_option( 'pmpro_' . $option_name );
	}

	// The per-run migration CSVs and the shared text log are intentionally kept as a
	// record of the migration.
	pmpro_deprecated_gateway_log( 'Deprecated gateway cleanup completed. Gateway=' . $gateway . '. Removed gateway from pmpro_undeprecated_gateways. Deleted options: ' . ( empty( $option_names ) ? 'none' : implode( ', ', $option_names ) ) . '.' );

	return true;
}

/**
 * Flag a migrated subscription as having no payment method yet.
 *
 * Drives the member-facing account notice, the {{ needs_payment_method }}
 * recurring payment reminder variable, and the admin "awaiting payment method" count and filter.
 *
 * @since 3.9
 *
 * @param int $subscription_id The subscription to flag.
 */
function pmpro_deprecated_gateway_flag_needs_payment_method( $subscription_id ) {
	update_pmpro_subscription_meta( (int) $subscription_id, 'deprecated_gateway_needs_payment_method', time() );
	// Cheap marker so sites that never migrated a subscription skip the count query entirely.
	update_option( 'pmpro_deprecated_gateway_migrated_subscriptions', 1 );
	pmpro_deprecated_gateway_delete_needs_payment_method_count_cache();
}

/**
 * Invalidate the cached "awaiting payment method" counts for both environments.
 *
 * @since 3.9
 */
function pmpro_deprecated_gateway_delete_needs_payment_method_count_cache() {
	delete_transient( 'pmpro_deprecated_gateway_needs_pm_count_live' );
	delete_transient( 'pmpro_deprecated_gateway_needs_pm_count_sandbox' );
}

/**
 * Clear the no-payment-method flag for a migrated subscription.
 *
 * @since 3.9
 *
 * @param int $subscription_id The subscription to clear.
 */
function pmpro_deprecated_gateway_clear_needs_payment_method( $subscription_id ) {
	delete_pmpro_subscription_meta( (int) $subscription_id, 'deprecated_gateway_needs_payment_method' );
	delete_pmpro_subscription_meta( (int) $subscription_id, 'deprecated_gateway_needs_payment_method_checked' );
	pmpro_deprecated_gateway_delete_needs_payment_method_count_cache();
}

/**
 * Whether a migrated subscription is still waiting for a payment method.
 *
 * The local flag can go stale if a payment method is attached outside of PMPro
 * (e.g. from the Stripe dashboard), so by default the flag is reverified
 * against Stripe, throttled to one API call per subscription per six hours.
 * The flag is cleared permanently as soon as a payment method is found.
 *
 * @since 3.9
 *
 * @param PMPro_Subscription $subscription The subscription to check.
 * @param bool               $verify Whether to reverify the flag against Stripe.
 * @param bool               $skip_throttle Whether to verify even if recently checked.
 *                           Use before acting on the flag in ways that are hard
 *                           to take back, like emailing the member.
 * @return bool
 */
function pmpro_deprecated_gateway_subscription_needs_payment_method( $subscription, $verify = true, $skip_throttle = false ) {
	if ( empty( $subscription ) || ! is_a( $subscription, 'PMPro_Subscription' ) ) {
		return false;
	}

	if ( 'active' !== $subscription->get_status() || 'stripe' !== $subscription->get_gateway() ) {
		return false;
	}

	if ( ! get_pmpro_subscription_meta( $subscription->get_id(), 'deprecated_gateway_needs_payment_method', true ) ) {
		return false;
	}

	if ( ! $verify ) {
		return true;
	}

	// Only call Stripe when the active API keys match this subscription's environment.
	if ( $subscription->get_gateway_environment() !== pmpro_deprecated_gateway_normalize_environment( get_option( 'pmpro_gateway_environment', 'sandbox' ) ) ) {
		return true;
	}

	if ( ! $skip_throttle ) {
		$last_checked = (int) get_pmpro_subscription_meta( $subscription->get_id(), 'deprecated_gateway_needs_payment_method_checked', true );
		if ( ! empty( $last_checked ) && time() - $last_checked < 6 * HOUR_IN_SECONDS ) {
			return true;
		}
	}

	if ( ! class_exists( 'PMProGateway_stripe' ) || ! method_exists( 'PMProGateway_stripe', 'subscription_has_payment_method' ) ) {
		return true;
	}

	$stripe_gateway     = new PMProGateway_stripe( 'stripe' );
	$has_payment_method = $stripe_gateway->subscription_has_payment_method( $subscription );
	if ( true === $has_payment_method ) {
		pmpro_deprecated_gateway_clear_needs_payment_method( $subscription->get_id() );
		return false;
	}

	// No payment method, or the API call failed. Keep the flag and let the
	// throttle prevent hammering Stripe.
	update_pmpro_subscription_meta( $subscription->get_id(), 'deprecated_gateway_needs_payment_method_checked', time() );
	return true;
}

/**
 * Get the number of active subscriptions still waiting for a payment method.
 *
 * Cached briefly; the cache is invalidated whenever a flag is set or cleared.
 *
 * @since 3.9
 *
 * @return int
 */
function pmpro_deprecated_gateway_get_needs_payment_method_count() {
	global $wpdb;

	// This runs on every PMPro admin page through the admin notice, so sites that never
	// migrated a subscription must not pay for the query.
	if ( empty( get_option( 'pmpro_deprecated_gateway_migrated_subscriptions' ) ) ) {
		return 0;
	}

	// Scoped to the current environment so a sandbox test run does not leave a permanent notice
	// once the site is back in live mode.
	$environment = pmpro_deprecated_gateway_normalize_environment( get_option( 'pmpro_gateway_environment', 'sandbox' ) );
	$count       = get_transient( 'pmpro_deprecated_gateway_needs_pm_count_' . $environment );
	if ( false === $count ) {
		$environment_condition = 'live' === $environment ? "s.gateway_environment = 'live'" : "s.gateway_environment != 'live'";
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- $environment_condition is only ever one of the two hard-coded clauses above.
		$count = (int) $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Queries the PMPro subscriptions and subscription meta custom tables, which have no WordPress API; the result is cached in a transient.
			"SELECT COUNT(*)
				FROM {$wpdb->pmpro_subscriptions} s
				INNER JOIN {$wpdb->pmpro_subscriptionmeta} sm
					ON s.id = sm.pmpro_subscription_id
					AND sm.meta_key = 'deprecated_gateway_needs_payment_method'
				WHERE s.status = 'active'
					AND {$environment_condition}"
		);
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
		set_transient( 'pmpro_deprecated_gateway_needs_pm_count_' . $environment, $count, 15 * MINUTE_IN_SECONDS );
	}

	return (int) $count;
}

/**
 * Clear the no-payment-method flag once an order proves a payment method exists.
 *
 * @since 3.9
 *
 * @param MemberOrder $order The order whose subscription now has a payment method.
 */
function pmpro_deprecated_gateway_payment_method_updated( $order ) {
	if ( empty( $order ) || ! is_a( $order, 'MemberOrder' ) ) {
		return;
	}

	$subscription = $order->get_subscription();
	if ( empty( $subscription ) ) {
		return;
	}

	// A payment on an old gateway subscription this workflow already cancelled means the gateway is
	// still billing the member. Record it so cleanup is held and the admin can find it in the log.
	if ( 'cancelled' === $subscription->get_status() && 'stripe' !== $subscription->get_gateway() && get_pmpro_subscription_meta( $subscription->get_id(), 'deprecated_gateway_handoff_date', true ) ) {
		update_pmpro_subscription_meta( $subscription->get_id(), 'deprecated_gateway_cancel_pending', time() );
		pmpro_deprecated_gateway_log( 'Received a payment at the old gateway for cancelled ' . pmpro_deprecated_gateway_get_subscription_log_description( $subscription ) . ' after it was migrated. The gateway is still billing this member; cancel the subscription in the gateway dashboard.' );
		return;
	}

	if ( get_pmpro_subscription_meta( $subscription->get_id(), 'deprecated_gateway_needs_payment_method', true ) ) {
		pmpro_deprecated_gateway_clear_needs_payment_method( $subscription->get_id() );
	}
}
add_action( 'pmpro_subscription_payment_completed', 'pmpro_deprecated_gateway_payment_method_updated' );

/**
 * Clear the no-payment-method flag after a successful billing update.
 *
 * @since 3.9
 *
 * @param int         $user_id The user who updated their billing information.
 * @param MemberOrder $order The order used for the billing update.
 */
function pmpro_deprecated_gateway_after_update_billing( $user_id, $order ) {
	pmpro_deprecated_gateway_payment_method_updated( $order );
}
add_action( 'pmpro_after_update_billing', 'pmpro_deprecated_gateway_after_update_billing', 10, 2 );

/**
 * Reset the verification throttle when a member visits the billing update page
 * for a flagged subscription.
 *
 * Sites using the Stripe Customer Portal add the payment method entirely on
 * Stripe's side, so none of the local clearing hooks fire. Clearing the
 * throttle before the portal redirect (which runs on this same action at
 * priority 5) means the next account page view reverifies against Stripe
 * immediately instead of showing a stale notice for up to six hours.
 *
 * @since 3.9
 */
function pmpro_deprecated_gateway_billing_preheader_reset_throttle() {
	global $pmpro_billing_subscription;

	if ( empty( $pmpro_billing_subscription ) || ! is_a( $pmpro_billing_subscription, 'PMPro_Subscription' ) ) {
		return;
	}

	if ( get_pmpro_subscription_meta( $pmpro_billing_subscription->get_id(), 'deprecated_gateway_needs_payment_method', true ) ) {
		delete_pmpro_subscription_meta( $pmpro_billing_subscription->get_id(), 'deprecated_gateway_needs_payment_method_checked' );
	}
}
add_action( 'pmpro_billing_preheader', 'pmpro_deprecated_gateway_billing_preheader_reset_throttle', 1 );

/**
 * Prepare the recurring payment reminder for migrated subscriptions that still
 * have no payment method.
 *
 * The reminder reads the stored flag through {{ needs_payment_method }}, so
 * reverify it against Stripe (no throttle) first in case a payment method was
 * added outside of PMPro. Also skip the reminder if the migration email just
 * went out (the migration ran inside the reminder window), since it says the same thing.
 *
 * @since 3.9
 *
 * @param bool               $send_email Whether to send the reminder.
 * @param PMPro_Subscription $subscription The subscription being reminded.
 * @param int                $days Days until the next payment.
 * @return bool
 */
function pmpro_deprecated_gateway_recurring_payment_reminder( $send_email, $subscription, $days ) {
	if ( empty( $send_email ) ) {
		return $send_email;
	}

	if ( ! pmpro_deprecated_gateway_subscription_needs_payment_method( $subscription, true, true ) ) {
		return $send_email;
	}

	$old_subscription_id = (int) get_pmpro_subscription_meta( $subscription->get_id(), 'deprecated_gateway_old_subscription_id', true );
	if ( ! empty( $old_subscription_id ) ) {
		$migration_email_sent = (int) get_pmpro_subscription_meta( $old_subscription_id, 'deprecated_gateway_email_sent', true );
		if ( ! empty( $migration_email_sent ) && time() - $migration_email_sent < 2 * DAY_IN_SECONDS ) {
			return false;
		}
	}

	return $send_email;
}
add_filter( 'pmpro_send_recurring_payment_reminder_email', 'pmpro_deprecated_gateway_recurring_payment_reminder', 10, 3 );

/**
 * Whether the site's customized recurring payment reminder subject or body is
 * missing the {{ needs_payment_method }} check while migrated Stripe subscriptions exist.
 *
 * Members without a payment method would otherwise get a reminder implying
 * their renewal will happen normally.
 *
 * @since 3.9
 *
 * @return bool
 */
function pmpro_deprecated_gateway_recurring_reminder_missing_payment_method_check() {
	if ( ! get_option( 'pmpro_deprecated_gateway_migrated_subscriptions' ) ) {
		return false;
	}

	$disabled = get_option( 'pmpro_email_membership_recurring_disabled' );
	if ( ! empty( $disabled ) && 'false' !== $disabled ) {
		return false;
	}

	// An empty subject or body means the default, which already has the check.
	foreach ( array( 'subject', 'body' ) as $part ) {
		$value = get_option( 'pmpro_email_membership_recurring_' . $part );
		if ( ! empty( $value ) && false === strpos( $value, 'needs_payment_method' ) ) {
			return true;
		}
	}

	return false;
}

/**
 * Show an action-required notice on the Membership Account page for migrated
 * subscriptions that still have no payment method.
 *
 * @since 3.9
 *
 * @param object $level The level whose card is being rendered.
 */
function pmpro_deprecated_gateway_account_payment_method_notice( $level ) {
	global $current_user;

	if ( empty( $current_user->ID ) || empty( $level->id ) ) {
		return;
	}

	$subscriptions = PMPro_Subscription::get_subscriptions_for_user( $current_user->ID, $level->id );
	foreach ( $subscriptions as $subscription ) {
		if ( ! pmpro_deprecated_gateway_subscription_needs_payment_method( $subscription ) ) {
			continue;
		}

		$next_payment_date = $subscription->get_next_payment_date( get_option( 'date_format' ) );
		$billing_url       = pmpro_url( 'billing', 'pmpro_subscription_id=' . (int) $subscription->get_id(), 'https' );
		?>
		<div class="<?php echo esc_attr( pmpro_get_element_class( 'pmpro_message pmpro_alert', 'pmpro_alert' ) ); ?>">
			<p>
				<strong><?php esc_html_e( 'Action required:', 'paid-memberships-pro' ); ?></strong>
				<?php
				if ( ! empty( $next_payment_date ) ) {
					printf(
						// translators: %s is the next payment date.
						esc_html__( 'Your subscription has no payment method on file. Add billing information before %s to keep your membership active.', 'paid-memberships-pro' ),
						esc_html( $next_payment_date )
					);
				} else {
					esc_html_e( 'Your subscription has no payment method on file. Add billing information to keep your membership active.', 'paid-memberships-pro' );
				}
				if ( ! empty( $billing_url ) ) {
					?>
					<a href="<?php echo esc_url( $billing_url ); ?>"><?php esc_html_e( 'Update Billing Information', 'paid-memberships-pro' ); ?></a>
					<?php
				}
				?>
			</p>
		</div>
		<?php
	}
}
add_action( 'pmpro_membership_account_after_level_card_content', 'pmpro_deprecated_gateway_account_payment_method_notice' );

/**
 * Show a notice on PMPro admin pages while migrated subscriptions are still
 * waiting for a payment method, linking to the filtered Subscriptions list.
 *
 * @since 3.9
 */
function pmpro_deprecated_gateway_needs_payment_method_admin_notice() {
	// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only: only decides which admin pages show the notice.
	if ( empty( $_REQUEST['page'] ) || 0 !== strpos( sanitize_text_field( wp_unslash( $_REQUEST['page'] ) ), 'pmpro' ) ) {
		return;
	}

	if ( ! current_user_can( pmpro_get_edit_member_capability() ) ) {
		return;
	}

	// No need for the notice when already viewing the filtered list.
	if ( 'pmpro-subscriptions' === $_REQUEST['page'] && isset( $_REQUEST['status'] ) && 'needs_payment_method' === $_REQUEST['status'] ) {
		return;
	}
	// phpcs:enable WordPress.Security.NonceVerification.Recommended

	$count = pmpro_deprecated_gateway_get_needs_payment_method_count();
	if ( empty( $count ) ) {
		return;
	}

	$url = add_query_arg(
		array(
			'page'   => 'pmpro-subscriptions',
			'status' => 'needs_payment_method',
		),
		admin_url( 'admin.php' )
	);
	?>
	<div class="notice notice-warning">
		<p>
			<?php
			printf(
				// translators: %d is the number of subscriptions.
				esc_html( _n( '%d migrated subscription is still waiting for the member to add a payment method.', '%d migrated subscriptions are still waiting for members to add a payment method.', $count, 'paid-memberships-pro' ) ),
				(int) $count
			);
			?>
			<a href="<?php echo esc_url( $url ); ?>"><?php esc_html_e( 'View these subscriptions', 'paid-memberships-pro' ); ?></a>
		</p>
	</div>
	<?php
}
add_action( 'admin_notices', 'pmpro_deprecated_gateway_needs_payment_method_admin_notice' );

/**
 * Get the reasons the Stripe migration strategy cannot be offered right now.
 *
 * Credentials only: webhook detection and warnings live on the Stripe gateway
 * settings page and intentionally do not gate or annotate the migration.
 *
 * @since 3.9
 *
 * @return string[] Empty when Stripe can receive migrations.
 */
function pmpro_deprecated_gateway_get_stripe_migration_blockers() {
	if ( ! class_exists( 'PMProGateway_stripe' ) || ! method_exists( 'PMProGateway_stripe', 'has_credentials' ) ) {
		return array( __( 'The Stripe gateway is not available.', 'paid-memberships-pro' ) );
	}

	$stripe_gateway = new PMProGateway_stripe( 'stripe' );
	if ( ! $stripe_gateway->has_credentials() ) {
		return array( __( 'Stripe is not connected for the current gateway environment.', 'paid-memberships-pro' ) );
	}

	return array();
}

/**
 * Get everything the deprecated gateway panel needs to render its current status.
 *
 * Used for both the initial page render and AJAX status polling.
 *
 * @since 3.9
 *
 * @param string $gateway Gateway slug.
 * @return array
 */
function pmpro_deprecated_gateway_get_status_data( $gateway ) {
	$gateway     = sanitize_key( $gateway );
	$environment = pmpro_deprecated_gateway_normalize_environment( get_option( 'pmpro_gateway_environment', 'sandbox' ) );
	$counts      = pmpro_deprecated_gateway_get_subscription_counts( $gateway );
	$paused      = pmpro_is_paused();
	$active      = get_option( 'pmpro_gateway' );
	$has_actions = pmpro_deprecated_gateway_has_scheduled_actions( $gateway, $environment );
	$state       = pmpro_deprecated_gateway_get_state( $gateway, $environment );

	// Self-heal: if the state says running but nothing is queued or in progress
	// (e.g. a batch action failed fatally), mark the workflow stopped so the admin
	// can start it again. The 60 second grace period avoids racing a fresh start.
	if ( ! empty( $state['status'] ) && 'running' === $state['status'] && ! $has_actions && time() - (int) $state['updated_at'] > 60 ) {
		$note  = empty( $state['dry_run'] )
			? __( 'The workflow stopped unexpectedly. Start it again to continue; subscriptions that were already processed will be skipped.', 'paid-memberships-pro' )
			: __( 'The dry run stopped unexpectedly. Start it again to preview the migration from the beginning.', 'paid-memberships-pro' );
		$state = pmpro_deprecated_gateway_update_state( $gateway, $environment, array( 'status' => 'stopped', 'note' => $note ) );
	}

	$is_running = ! empty( $state['status'] ) && 'running' === $state['status'];

	$start_blockers = array();
	if ( $paused ) {
		$start_blockers[] = __( 'Paid Memberships Pro services are paused because this looks like a staging or development copy of your site. Resume services to use this workflow.', 'paid-memberships-pro' );
	}
	if ( $gateway === $active ) {
		$start_blockers[] = __( 'Activate a different payment gateway before starting a migration.', 'paid-memberships-pro' );
	}
	if ( empty( $counts[ $environment ] ) ) {
		$start_blockers[]  = __( 'There are no active subscriptions for this gateway in the current environment.', 'paid-memberships-pro' );
		$other_environment = 'live' === $environment ? 'sandbox' : 'live';
		if ( ! empty( $counts[ $other_environment ] ) ) {
			$start_blockers[] = 'live' === $other_environment
				? __( 'To migrate the remaining live subscriptions, set the gateway environment to Live and reload this page.', 'paid-memberships-pro' )
				: __( 'To process the remaining sandbox subscriptions, set the gateway environment to Sandbox/Testing and reload this page.', 'paid-memberships-pro' );
		}
	}

	if ( $has_actions && ! $is_running ) {
		// A batch that was mid-run when the workflow was stopped still queues one more action;
		// schedule() refuses until it drains, so do not offer Start yet.
		$start_blockers[] = __( 'The last batch of the previous workflow is still finishing.', 'paid-memberships-pro' );
	}

	$cleanup_blockers = array();
	if ( $paused ) {
		$cleanup_blockers[] = __( 'Gateway data cannot be removed while Paid Memberships Pro services are paused.', 'paid-memberships-pro' );
	}
	if ( 'paypalexpress' === $gateway && function_exists( 'pmproappe_pmpro_valid_gateways' ) ) {
		$cleanup_blockers[] = __( 'The Add PayPal Express Add On is active and still offers this gateway at checkout. Deactivate it before removing gateway data.', 'paid-memberships-pro' );
	}
	if ( $gateway === $active ) {
		$cleanup_blockers[] = __( 'Gateway data cannot be removed while this is the active payment gateway.', 'paid-memberships-pro' );
	}
	if ( ! empty( $counts['live'] ) ) {
		$cleanup_blockers[] = sprintf(
			// translators: %d: Number of live subscriptions.
			_n( '%d live subscription is still active for this gateway. Live subscriptions must be migrated before gateway data can be removed, even while testing in the sandbox environment.', '%d live subscriptions are still active for this gateway. Live subscriptions must be migrated before gateway data can be removed, even while testing in the sandbox environment.', $counts['live'], 'paid-memberships-pro' ),
			$counts['live']
		);
	}
	if ( ! empty( $counts['sandbox'] ) ) {
		$cleanup_blockers[] = sprintf(
			// translators: %d: Number of sandbox subscriptions.
			_n( '%d sandbox subscription is still active for this gateway. Process it in the sandbox environment before removing gateway data.', '%d sandbox subscriptions are still active for this gateway. Process them in the sandbox environment before removing gateway data.', $counts['sandbox'], 'paid-memberships-pro' ),
			$counts['sandbox']
		);
	}
	if ( $has_actions || pmpro_deprecated_gateway_has_scheduled_actions( $gateway, 'live' === $environment ? 'sandbox' : 'live' ) ) {
		$cleanup_blockers[] = __( 'A workflow is queued or running for this gateway.', 'paid-memberships-pro' );
	}

	$workflow = null;
	if ( ! empty( $state['status'] ) ) {
		$datetime_format = get_option( 'date_format' ) . ' ' . get_option( 'time_format' );
		$workflow        = array(
			'status'            => $state['status'],
			'strategy'          => empty( $state['strategy'] ) ? '' : $state['strategy'],
			'dry_run'           => ! empty( $state['dry_run'] ),
			'total'             => empty( $state['total'] ) ? 0 : (int) $state['total'],
			'processed'         => empty( $state['processed'] ) ? 0 : (int) $state['processed'],
			'complete'          => empty( $state['complete'] ) ? 0 : (int) $state['complete'],
			'skipped'           => empty( $state['skipped'] ) ? 0 : (int) $state['skipped'],
			'needs_review'      => empty( $state['needs_review'] ) ? 0 : (int) $state['needs_review'],
			'note'              => empty( $state['note'] ) ? '' : $state['note'],
			'started_display'   => empty( $state['started_at'] ) ? '' : wp_date( $datetime_format, (int) $state['started_at'] ),
			'completed_display' => empty( $state['completed_at'] ) ? '' : wp_date( $datetime_format, (int) $state['completed_at'] ),
			'csv_url'           => empty( $state['run_id'] ) ? '' : pmpro_deprecated_gateway_get_csv_url( $state['run_id'] ),
		);
	}

	// Only offer the Stripe strategy when Stripe can actually receive
	// migrations; the blockers explain a disabled Stripe option to the admin.
	$stripe_blockers = ( 'stripe' === $active && $gateway !== $active ) ? pmpro_deprecated_gateway_get_stripe_migration_blockers() : array();
	// The new gateway step is only done once the active gateway can take payments. Stripe is the only
	// gateway that can be checked here, so other gateways are trusted to be set up.
	$has_replacement = $gateway !== $active && empty( $stripe_blockers );

	return array(
		'gateway'          => $gateway,
		'environment'      => $environment,
		'counts'           => $counts,
		'paused'           => $paused,
		'has_replacement'  => $has_replacement,
		'stripe_available' => 'stripe' === $active && $has_replacement,
		'stripe_blockers'  => $stripe_blockers,
		'workflow'         => $workflow,
		'is_running'       => $is_running,
		// The panel keeps polling while this is true so the start blocker above clears itself.
		'has_actions'      => $has_actions,
		'can_start'        => ! $is_running && ! $has_actions && empty( $start_blockers ),
		'start_blockers'   => $start_blockers,
		'can_cleanup'      => ! $is_running && empty( $cleanup_blockers ),
		'cleanup_blockers' => $cleanup_blockers,
		// Non-empty when this gateway cannot cancel subscriptions automatically.
		'manual_cancel_reason' => pmpro_deprecated_gateway_get_manual_cancel_reason( $gateway ),
		// Subscriptions marked cancelled in PMPro that may still bill at the gateway; cleanup
		// requires the admin to confirm they were cancelled there.
		'cancel_pending'   => pmpro_deprecated_gateway_get_cancel_pending_count( $gateway ),
		// The full list of this gateway's run CSVs, surfaced at the cleanup step so
		// admins have one place to download them (cleanup keeps them as a record).
		// Skipped while a run is active to avoid globbing the logs dir on every poll.
		// Shown at the last step when the customized Recurring Payment Reminder cannot tell
		// migrated members that they need to add a payment method.
		'recurring_reminder_outdated' => pmpro_deprecated_gateway_recurring_reminder_missing_payment_method_check(),
		'csv_files'        => $is_running ? array() : pmpro_deprecated_gateway_get_csv_files( $gateway ),
		'has_log'          => file_exists( pmpro_get_restricted_file_path( 'logs', 'deprecated-gateways.txt' ) ),
	);
}

/**
 * Handle AJAX requests from the deprecated gateway panel.
 *
 * @since 3.9
 */
function pmpro_deprecated_gateway_ajax() {
	if ( ! current_user_can( 'manage_options' ) && ! current_user_can( 'pmpro_paymentsettings' ) ) {
		wp_send_json_error( array( 'message' => __( 'You do not have permissions to perform this action.', 'paid-memberships-pro' ) ), 403 );
	}
	check_ajax_referer( 'pmpro_deprecated_gateway', 'nonce' );

	$gateway = isset( $_POST['gateway'] ) ? sanitize_key( wp_unslash( $_POST['gateway'] ) ) : '';
	$task    = isset( $_POST['task'] ) ? sanitize_key( wp_unslash( $_POST['task'] ) ) : 'status';
	if ( ! in_array( $gateway, pmpro_get_deprecated_gateways(), true ) ) {
		wp_send_json_error( array( 'message' => __( 'This workflow is only available for deprecated gateways.', 'paid-memberships-pro' ) ), 400 );
	}

	$result   = true;
	$message  = '';
	$redirect = '';
	switch ( $task ) {
		case 'start':
			$strategy        = isset( $_POST['strategy'] ) ? sanitize_key( wp_unslash( $_POST['strategy'] ) ) : '';
			$send_email      = empty( $_POST['skip_email'] );
			$expire_past_due = ! empty( $_POST['expire_past_due'] );
			$dry_run         = ! empty( $_POST['dry_run'] );
			$result          = pmpro_deprecated_gateway_schedule( $gateway, $strategy, $send_email, $expire_past_due, $dry_run, ! empty( $_POST['manual_cancel_acknowledged'] ) );
			$message         = $dry_run ? __( 'Dry run started. No changes will be made.', 'paid-memberships-pro' ) : __( 'Migration workflow started.', 'paid-memberships-pro' );
			break;
		case 'stop':
			$result  = pmpro_deprecated_gateway_stop( $gateway );
			$message = __( 'Workflow stopped.', 'paid-memberships-pro' );
			break;
		case 'cleanup':
			$result   = pmpro_deprecated_gateway_cleanup_gateway( $gateway, ! empty( $_POST['cancel_pending_confirmed'] ) );
			$message  = __( 'Deprecated gateway data has been removed from this site.', 'paid-memberships-pro' );
			$redirect = add_query_arg( array( 'page' => 'pmpro-paymentsettings', 'deprecated_gateway_removed' => $gateway ), admin_url( 'admin.php' ) );
			break;
		case 'activate_stripe':
			$environment = pmpro_deprecated_gateway_normalize_environment( get_option( 'pmpro_gateway_environment', 'sandbox' ) );
			if ( ! class_exists( 'PMProGateway_stripe' ) || ! ( PMProGateway_stripe::has_connect_credentials( $environment ) || ( method_exists( 'PMProGateway_stripe', 'has_credentials' ) && ( new PMProGateway_stripe( 'stripe' ) )->has_credentials() ) ) ) {
				$result = new WP_Error( 'pmpro_deprecated_gateway_stripe_not_connected', __( 'Connect to Stripe before making it the active gateway.', 'paid-memberships-pro' ) );
			} else {
				update_option( 'pmpro_gateway', 'stripe' );

				// Make sure a webhook is set up, like the Stripe Connect return flow does.
				// Placeholder subscriptions rely on webhooks for renewal orders, billing
				// limit enforcement, and syncing cancellations when a trial lapses.
				// update_webhook_events() returns null when the webhook already exists with every
				// event (the usual case for a previously connected site), so only a WP_Error means
				// the webhook is actually missing.
				$stripe_gateway          = new PMProGateway_stripe();
				$update_webhook_response = $stripe_gateway->update_webhook_events();
				if ( is_wp_error( $update_webhook_response ) ) {
					$result = new WP_Error( 'pmpro_deprecated_gateway_stripe_webhook', __( 'Stripe is now the active payment gateway, but a webhook could not be created automatically. Set up the webhook from the Stripe gateway settings before migrating subscriptions.', 'paid-memberships-pro' ) );
				} else {
					$message = __( 'Stripe is now the active payment gateway.', 'paid-memberships-pro' );
				}
			}
			break;
		case 'status':
			break;
		default:
			wp_send_json_error( array( 'message' => __( 'Invalid task.', 'paid-memberships-pro' ) ), 400 );
	}

	$data = pmpro_deprecated_gateway_get_status_data( $gateway );
	if ( is_wp_error( $result ) ) {
		$data['message'] = $result->get_error_message();
		$data['error']   = true;
	} elseif ( ! empty( $message ) ) {
		$data['message'] = $message;
		$data['error']   = false;
		if ( ! empty( $redirect ) ) {
			$data['redirect'] = $redirect;
		}
	}
	wp_send_json_success( $data );
}
add_action( 'wp_ajax_pmpro_deprecated_gateway', 'pmpro_deprecated_gateway_ajax' );

/**
 * Allow payment settings admins to view the migration log.
 *
 * @since 3.9
 *
 * @param bool   $can_access Whether the file can be accessed.
 * @param string $file_dir File directory.
 * @param string $file File name.
 * @return bool
 */
function pmpro_deprecated_gateway_allow_log_access( $can_access, $file_dir, $file ) {
	// Allow the global text log and any per-run CSV. The strict pattern (no slashes
	// or extra dots) keeps this from being widened into a path traversal.
	if ( 'logs' === $file_dir
		&& preg_match( '/^deprecated-gateways(-[A-Za-z0-9_\-]+)?\.(txt|csv)$/', (string) $file )
		&& ( current_user_can( 'manage_options' ) || current_user_can( 'pmpro_paymentsettings' ) ) ) {
		return true;
	}

	return $can_access;
}
add_filter( 'pmpro_can_access_restricted_file', 'pmpro_deprecated_gateway_allow_log_access', 20, 3 );

/**
 * Append a message to the migration log file.
 *
 * @since 3.9
 *
 * @param string $logstr Log output.
 */
function pmpro_deprecated_gateway_log( $logstr ) {
	$logstr = (string) $logstr;
	if ( '' === $logstr ) {
		return;
	}

	$logfile = pmpro_get_restricted_file_path( 'logs', 'deprecated-gateways.txt' );
	if ( empty( $logfile ) ) {
		return;
	}

	$loghandle = fopen( $logfile, 'a+' );
	if ( $loghandle ) {
		fwrite( $loghandle, '[' . date_i18n( 'Y-m-d H:i:s' ) . '] ' . $logstr . "\n" );
		fclose( $loghandle );
	}
}

/**
 * Column headings for the per-run migration CSV.
 *
 * @since 3.9
 *
 * @return string[]
 */
function pmpro_deprecated_gateway_get_csv_columns() {
	return array(
		'processed_date',
		'user_id',
		'user_email',
		'display_name',
		'membership_level',
		'old_subscription_id',
		'new_subscription_id',
		'new_subscription_transaction_id',
		'action',
		'handoff_date',
		'outcome',
		'email_sent',
		'notes',
	);
}

/**
 * Get the file name for a run's migration CSV.
 *
 * @since 3.9
 *
 * @param string $run_id Run identifier stored in the workflow state.
 * @return string Empty string if no run ID.
 */
function pmpro_deprecated_gateway_get_csv_filename( $run_id ) {
	if ( empty( $run_id ) ) {
		return '';
	}
	return 'deprecated-gateways-' . sanitize_file_name( $run_id ) . '.csv';
}

/**
 * Get the file path for a run's migration CSV.
 *
 * @since 3.9
 *
 * @param string $run_id Run identifier.
 * @return string Empty string if no run ID.
 */
function pmpro_deprecated_gateway_get_csv_path( $run_id ) {
	$filename = pmpro_deprecated_gateway_get_csv_filename( $run_id );
	if ( empty( $filename ) ) {
		return '';
	}
	return pmpro_get_restricted_file_path( 'logs', $filename );
}

/**
 * Get the download URL for a run's migration CSV.
 *
 * @since 3.9
 *
 * @param string $run_id Run identifier.
 * @return string Empty string if no run ID.
 */
function pmpro_deprecated_gateway_get_csv_url( $run_id ) {
	$filename = pmpro_deprecated_gateway_get_csv_filename( $run_id );
	if ( empty( $filename ) ) {
		return '';
	}
	return add_query_arg(
		array(
			'pmpro_restricted_file_dir' => 'logs',
			'pmpro_restricted_file'     => $filename,
		),
		admin_url( 'admin.php' )
	);
}

/**
 * Create a run's migration CSV and write the header row.
 *
 * @since 3.9
 *
 * @param string $run_id Run identifier.
 */
function pmpro_deprecated_gateway_csv_init( $run_id ) {
	$path = pmpro_deprecated_gateway_get_csv_path( $run_id );
	if ( empty( $path ) ) {
		return;
	}

	$handle = fopen( $path, 'w' );
	if ( $handle ) {
		// Write the UTF-8 BOM so Excel on Windows reads accented names correctly.
		fwrite( $handle, pmpro_get_csv_bom( 'deprecated-gateways' ) );
		// Pass the separator/enclosure/escape explicitly; relying on the default
		// $escape is deprecated in PHP 8.4.
		fputcsv( $handle, pmpro_deprecated_gateway_get_csv_columns(), ',', '"', '\\' );
		fclose( $handle );
	}
}

/**
 * Neutralize spreadsheet formula triggers in a CSV cell.
 *
 * Display names and emails are member-controlled, so a value starting with a
 * formula character could execute when the CSV is opened in a spreadsheet.
 *
 * @since 3.9
 *
 * @param mixed $value Cell value.
 * @return string
 */
function pmpro_deprecated_gateway_csv_cell( $value ) {
	$value = (string) $value;
	if ( '' !== $value && preg_match( '/^[=+\-@\t\r]/', $value ) ) {
		$value = "'" . $value;
	}
	return $value;
}

/**
 * Append one processed subscription to a run's migration CSV.
 *
 * Batches run sequentially (Action Scheduler concurrency is 1), so appending
 * here needs no locking, just like the text log.
 *
 * @since 3.9
 *
 * @param string $run_id Run identifier.
 * @param int    $subscription_id The subscription that was processed.
 * @param array  $result Result from pmpro_deprecated_gateway_process_subscription().
 */
function pmpro_deprecated_gateway_csv_append( $run_id, $subscription_id, $result ) {
	$path = pmpro_deprecated_gateway_get_csv_path( $run_id );
	if ( empty( $path ) ) {
		return;
	}

	$user_id             = 0;
	$user_email          = '';
	$display_name        = '';
	$membership_level    = '';
	$old_subscription_id = (int) $subscription_id;

	$subscription = PMPro_Subscription::get_subscription( $subscription_id );
	if ( ! empty( $subscription ) ) {
		$user_id = (int) $subscription->get_user_id();
		$user    = get_userdata( $user_id );
		if ( ! empty( $user ) ) {
			$user_email   = $user->user_email;
			$display_name = $user->display_name;
		}
		$level            = pmpro_getLevel( $subscription->get_membership_level_id() );
		$membership_level = empty( $level ) ? '' : $level->name;
	}

	$row = array(
		date_i18n( 'Y-m-d H:i:s' ),
		$user_id,
		$user_email,
		$display_name,
		$membership_level,
		$old_subscription_id,
		isset( $result['new_subscription_id'] ) ? $result['new_subscription_id'] : '',
		isset( $result['new_subscription_transaction_id'] ) ? $result['new_subscription_transaction_id'] : '',
		isset( $result['action'] ) ? $result['action'] : '',
		isset( $result['handoff_date'] ) ? $result['handoff_date'] : '',
		isset( $result['outcome'] ) ? $result['outcome'] : '',
		isset( $result['email_sent'] ) ? $result['email_sent'] : '',
		isset( $result['message'] ) ? trim( (string) $result['message'] ) : '',
	);

	$handle = fopen( $path, 'a' );
	if ( $handle ) {
		fputcsv( $handle, array_map( 'pmpro_deprecated_gateway_csv_cell', $row ), ',', '"', '\\' );
		fclose( $handle );
	}
}

/**
 * Get the migration CSV files that exist for a gateway, newest first.
 *
 * @since 3.9
 *
 * @param string $gateway Gateway slug.
 * @return array[] Each entry has 'filename', 'url', and 'date' keys.
 */
function pmpro_deprecated_gateway_get_csv_files( $gateway ) {
	$gateway = sanitize_key( $gateway );

	// Resolve the logs directory from a known restricted-file path.
	$sample_path = pmpro_get_restricted_file_path( 'logs', 'deprecated-gateways.txt' );
	if ( empty( $sample_path ) ) {
		return array();
	}

	$matches = glob( dirname( $sample_path ) . '/deprecated-gateways-' . $gateway . '_*.csv' );
	if ( empty( $matches ) ) {
		return array();
	}

	// Filenames embed a sortable YYYYMMDD-HHMMSS stamp, so reverse-sorting the
	// paths puts the newest run first.
	rsort( $matches );

	$files = array();
	foreach ( $matches as $path ) {
		$filename = basename( $path );
		// Pull the YYYYMMDD-HHMMSS stamp (UTC, set at schedule time) out of the
		// filename for a readable label.
		$date = '';
		if ( preg_match( '/_(\d{4})(\d{2})(\d{2})-(\d{2})(\d{2})(\d{2})(_dryrun)?\.csv$/', $filename, $m ) ) {
			$timestamp = strtotime( $m[1] . '-' . $m[2] . '-' . $m[3] . ' ' . $m[4] . ':' . $m[5] . ':' . $m[6] . ' UTC' );
			$date      = $timestamp ? wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $timestamp ) : '';
			if ( ! empty( $m[7] ) ) {
				$date .= ' (dry run)';
			}
		}
		$files[] = array(
			'filename' => $filename,
			'url'      => add_query_arg(
				array(
					'pmpro_restricted_file_dir' => 'logs',
					'pmpro_restricted_file'     => $filename,
				),
				admin_url( 'admin.php' )
			),
			'date'     => $date,
		);
	}

	return $files;
}

/**
 * Render the deprecated gateway notice on the gateway's settings page.
 *
 * Links to the migration tool and surfaces any unfinished migration work.
 *
 * @since 3.9
 *
 * @param string $gateway Gateway slug.
 */
function pmpro_deprecated_gateway_render_notice( $gateway ) {
	$gateway = sanitize_key( $gateway );

	$gateway_names = pmpro_gateways();
	$gateway_name  = empty( $gateway_names[ $gateway ] ) ? $gateway : $gateway_names[ $gateway ];

	$tool_url = add_query_arg(
		array(
			'page'                               => 'pmpro-paymentsettings',
			'edit_gateway'                       => $gateway,
			'pmpro_deprecated_gateway_migration' => 1,
		),
		admin_url( 'admin.php' )
	);

	// Surface unfinished work so an admin returning to this page can find it.
	$environment    = pmpro_deprecated_gateway_normalize_environment( get_option( 'pmpro_gateway_environment', 'sandbox' ) );
	$state          = pmpro_deprecated_gateway_get_state( $gateway, $environment );
	$cancel_pending = pmpro_deprecated_gateway_get_cancel_pending_count( $gateway );
	$status_line    = '';
	if ( ! empty( $state['status'] ) && in_array( $state['status'], array( 'running', 'stopped' ), true ) ) {
		$status_line = sprintf(
			'running' === $state['status']
				// translators: %1$d: number processed, %2$d: total number.
				? __( 'A migration is in progress: %1$d of %2$d subscriptions processed.', 'paid-memberships-pro' )
				// translators: %1$d: number processed, %2$d: total number.
				: __( 'A migration was stopped after processing %1$d of %2$d subscriptions.', 'paid-memberships-pro' ),
			empty( $state['processed'] ) ? 0 : (int) $state['processed'],
			empty( $state['total'] ) ? 0 : (int) $state['total']
		);
	}
	if ( $cancel_pending > 0 ) {
		$status_line .= ' ' . sprintf(
			// translators: %d: number of subscriptions.
			_n( '%d subscription still needs to be cancelled in the gateway dashboard.', '%d subscriptions still need to be cancelled in the gateway dashboard.', $cancel_pending, 'paid-memberships-pro' ),
			$cancel_pending
		);
	}
	?>
	<div class="pmpro_notification pmpro_notification-error">
		<div class="pmpro_notification-icon">
			<span class="dashicons dashicons-warning"></span>
		</div>
		<div class="pmpro_notification-content">
			<h3><?php esc_html_e( 'You Are Using a Deprecated Gateway', 'paid-memberships-pro' ); ?></h3>
			<p>
				<?php
				// translators: %s is the gateway name.
				printf( esc_html__( 'The %s gateway has been deprecated and will not receive updates or support. To ensure your payments continue running smoothly, switch to a supported payment gateway.', 'paid-memberships-pro' ), esc_html( $gateway_name ) );
				?>
			</p>
			<?php if ( '' !== trim( $status_line ) ) { ?>
				<p><strong><?php echo esc_html( trim( $status_line ) ); ?></strong></p>
			<?php } ?>
			<ul>
				<?php if ( 'paypalexpress' === $gateway ) { ?>
					<li><a href="https://www.paidmembershipspro.com/paypal-express-deprecation-hub/?utm_source=plugin&utm_medium=pmpro-paymentsettings&utm_campaign=blog&utm_content=paypal-express-deprecation" target="_blank" rel="nofollow noopener"><?php esc_html_e( 'PayPal Express Deprecation Hub', 'paid-memberships-pro' ); ?></a></li>
				<?php } ?>
				<li><a href="https://www.paidmembershipspro.com/documentation/compatibility/incompatible-deprecated-add-ons/?utm_source=plugin&utm_medium=pmpro-paymentsettings&utm_campaign=documentation&utm_content=deprecated-gateways#deprecated-payment-gateways" target="_blank" rel="nofollow noopener"><?php esc_html_e( 'About Deprecated Gateways', 'paid-memberships-pro' ); ?></a></li>
				<li><a href="https://www.paidmembershipspro.com/switching-payment-gateways/?utm_source=plugin&utm_medium=pmpro-paymentsettings&utm_campaign=blog&utm_content=switching-payment-gateways" target="_blank" rel="nofollow noopener"><?php esc_html_e( 'How to Switch Payment Gateways', 'paid-memberships-pro' ); ?></a></li>
			</ul>
			<p>
				<a class="button" href="<?php echo esc_url( $tool_url ); ?>"><?php esc_html_e( 'Migrate Subscriptions Off This Gateway', 'paid-memberships-pro' ); ?></a>
			</p>
		</div>
	</div>
	<?php
}

/**
 * Render the deprecated gateway migration tool.
 *
 * Shown in place of the gateway's settings when the migration tool is opened
 * from the deprecated gateway notice.
 *
 * @since 3.9
 *
 * @param string $gateway Gateway slug.
 */
function pmpro_deprecated_gateway_render_panel( $gateway ) {
	$gateway = sanitize_key( $gateway );

	$gateway_names = pmpro_gateways();
	$gateway_name  = empty( $gateway_names[ $gateway ] ) ? $gateway : $gateway_names[ $gateway ];
	$data = pmpro_deprecated_gateway_get_status_data( $gateway );

	$log_url = add_query_arg(
		array(
			'pmpro_restricted_file_dir' => 'logs',
			'pmpro_restricted_file'     => 'deprecated-gateways.txt',
		),
		admin_url( 'admin.php' )
	);
	$stripe_template_url   = add_query_arg( array( 'page' => 'pmpro-emailtemplates', 'edit' => 'deprecated_gateway_stripe_migration' ), admin_url( 'admin.php' ) );
	$checkout_template_url = add_query_arg( array( 'page' => 'pmpro-emailtemplates', 'edit' => 'deprecated_gateway_checkout_required' ), admin_url( 'admin.php' ) );
	$recurring_template_url = add_query_arg( array( 'page' => 'pmpro-emailtemplates', 'edit' => 'membership_recurring' ), admin_url( 'admin.php' ) );

	// For the "activate a new gateway" step, offer the same Stripe Connect flow used in the setup wizard.
	// Stripe Connect or legacy API keys both work for migrations; has_credentials() checks the current environment.
	$stripe_connected   = class_exists( 'PMProGateway_stripe' ) && ( PMProGateway_stripe::has_connect_credentials( $data['environment'] ) || ( method_exists( 'PMProGateway_stripe', 'has_credentials' ) && ( new PMProGateway_stripe( 'stripe' ) )->has_credentials() ) );
	$stripe_connect_url = add_query_arg(
		array(
			'action'              => 'authorize',
			'gateway_environment' => 'live' === $data['environment'] ? 'live' : 'test',
			'return_url'          => rawurlencode( add_query_arg( array( 'page' => 'pmpro-paymentsettings', 'edit_gateway' => $gateway, 'pmpro_deprecated_gateway_migration' => 1, 'pmpro_stripe_connect_nonce' => wp_create_nonce( 'pmpro_stripe_connect_nonce' ) ), admin_url( 'admin.php' ) ) ),
		),
		apply_filters( 'pmpro_stripe_connect_url', 'https://connect.paidmembershipspro.com' )
	);

	$config = array(
		'gateway' => $gateway,
		'log_url' => $log_url,
		'nonce'   => wp_create_nonce( 'pmpro_deprecated_gateway' ),
		'initial' => $data,
		'i18n'    => array(
			'env_live'                => __( 'Live environment', 'paid-memberships-pro' ),
			'env_sandbox'             => __( 'Sandbox environment', 'paid-memberships-pro' ),
			// translators: %s: number of live subscriptions.
			'finish_other_live'       => __( '%s live subscriptions still need to be migrated. Switch the Gateway Environment to Live/Production, updating the gateway API keys as needed, then return to this page to migrate them.', 'paid-memberships-pro' ),
			// translators: %s: number of sandbox subscriptions.
			'finish_other_sandbox'    => __( '%s sandbox subscriptions still need to be migrated. Switch the Gateway Environment to Sandbox/Testing, updating the gateway API keys as needed, then return to this page to migrate them.', 'paid-memberships-pro' ),
			'no_workflow'             => __( 'No workflow has been run for this gateway in the current environment yet.', 'paid-memberships-pro' ),
			'running'                 => __( 'Migration in progress', 'paid-memberships-pro' ),
			'running_dry'             => __( 'Dry run in progress', 'paid-memberships-pro' ),
			// translators: %1$s: number processed, %2$s: total number.
			'progress_of'             => __( '%1$s of %2$s subscriptions processed', 'paid-memberships-pro' ),
			// translators: %s: date and time.
			'completed_on'            => __( 'Workflow completed %s', 'paid-memberships-pro' ),
			// translators: %s: date and time.
			'completed_on_dry'        => __( 'Dry run completed %s. No changes were made.', 'paid-memberships-pro' ),
			// translators: %s: date and time.
			'started_on'              => __( 'Started %s', 'paid-memberships-pro' ),
			'stopped'                 => __( 'Workflow stopped', 'paid-memberships-pro' ),
			'chip_complete'           => __( 'Complete', 'paid-memberships-pro' ),
			'chip_skipped'            => __( 'Skipped', 'paid-memberships-pro' ),
			'chip_needs_review'       => __( 'Needs Review', 'paid-memberships-pro' ),
			'needs_review_warning'    => __( 'Some subscriptions need review. Search the migration log for "[needs_review]" entries and review each note before removing gateway data.', 'paid-memberships-pro' ),
			'skipped_warning'         => __( 'Some subscriptions were skipped. Search the migration log for "[skipped]" entries and handle them manually, or run the migration again and set "Subscriptions With a Missed Payment" to cancel and expire them.', 'paid-memberships-pro' ),
			// translators: %1$s: number of subscriptions, %2$s: environment label.
			'confirm_start'           => __( 'This will process %1$s active subscriptions in the %2$s and cancel them at the old gateway.', 'paid-memberships-pro' ),
			// translators: %1$s: number of subscriptions, %2$s: environment label.
			'confirm_start_dry'       => __( 'Dry run: this will preview the migration of %1$s active subscriptions in the %2$s and record the planned outcomes in the migration log. No changes will be made and no emails will be sent.', 'paid-memberships-pro' ),
			'confirm_start_email'     => __( 'Members WILL be emailed.', 'paid-memberships-pro' ),
			'confirm_start_noemail'   => __( 'Members will NOT be emailed.', 'paid-memberships-pro' ),
			'confirm_start_stripe'    => __( 'Members who do not add a payment method before their next payment date will have their membership cancelled.', 'paid-memberships-pro' ),
			'confirm_start_expire_past_due' => __( 'Subscriptions with a missed payment (a next payment date in the past) will be cancelled and their memberships expired.', 'paid-memberships-pro' ),
			'confirm_start_manual'    => __( 'This gateway cannot cancel subscriptions automatically: each old subscription will only be marked cancelled in Paid Memberships Pro, and you must cancel it in the gateway dashboard yourself.', 'paid-memberships-pro' ),
			// translators: %s: number of subscriptions.
			'cancel_pending_ack'      => __( '%s subscriptions were marked cancelled in Paid Memberships Pro but may still be active at the gateway. I have cancelled all of them in the gateway dashboard.', 'paid-memberships-pro' ),
			'cancel_pending_ack_one'  => __( '1 subscription was marked cancelled in Paid Memberships Pro but may still be active at the gateway. I have cancelled it in the gateway dashboard.', 'paid-memberships-pro' ),
			'confirm_continue'        => __( 'Continue?', 'paid-memberships-pro' ),
			'download_log'            => __( 'Download Migration Log', 'paid-memberships-pro' ),
			'download_csv'            => __( 'Download Migration CSV', 'paid-memberships-pro' ),
			'csv_none'                => __( 'No Migration CSV files were found for this gateway.', 'paid-memberships-pro' ),
			'confirm_stop'            => __( 'Stop this workflow? Subscriptions that were already processed stay processed. You can start the workflow again later to continue.', 'paid-memberships-pro' ),
			'confirm_cleanup'         => __( 'This will permanently delete the stored credentials for this gateway and stop loading it on this site. Your Migration Log and Migration CSV files are kept.', 'paid-memberships-pro' ),
			'error_generic'           => __( 'Something went wrong. Please reload the page and try again.', 'paid-memberships-pro' ),
			'start_dry'               => __( 'Preview Migration (Dry Run)', 'paid-memberships-pro' ),
			'start_real'              => __( 'Start Real Migration', 'paid-memberships-pro' ),
		),
	);
	?>
	<div class="pmpro-dgs" id="pmpro-dgs">
		<p>
			<?php
			// translators: %s is the gateway name.
			printf( esc_html__( 'Move your active %s subscriptions to a supported payment gateway, let your members know what changed, and then remove the deprecated gateway from your site.', 'paid-memberships-pro' ), esc_html( $gateway_name ) );
			?>
			<a href="https://www.paidmembershipspro.com/documentation/settings/payment-gateway-settings/deprecated-gateway-migration-tool/?utm_source=plugin&utm_medium=pmpro-paymentsettings&utm_campaign=documentation&utm_content=deprecated-gateway-migration" target="_blank" rel="nofollow noopener"><?php esc_html_e( 'Learn more about the gateway migration tool', 'paid-memberships-pro' ); ?></a>
		</p>
		<div class="pmpro_section">
			<div class="pmpro_section_inside">
			<nav class="pmpro-stepper">
				<ul class="pmpro-stepper__steps">
					<li class="pmpro-stepper__step" id="pmpro-dgs-step-1" data-step="1">
						<div class="pmpro-stepper__step-icon"><span class="pmpro-stepper__step-number">1</span></div>
						<span class="pmpro-stepper__step-label"><?php esc_html_e( 'Activate a new gateway', 'paid-memberships-pro' ); ?></span>
					</li>
					<li class="pmpro-stepper__step" id="pmpro-dgs-step-2" data-step="2">
						<div class="pmpro-stepper__step-icon"><span class="pmpro-stepper__step-number">2</span></div>
						<span class="pmpro-stepper__step-label"><?php esc_html_e( 'Migrate subscriptions', 'paid-memberships-pro' ); ?></span>
					</li>
					<li class="pmpro-stepper__step" id="pmpro-dgs-step-3" data-step="3">
						<div class="pmpro-stepper__step-icon"><span class="pmpro-stepper__step-number">3</span></div>
						<span class="pmpro-stepper__step-label"><?php esc_html_e( 'Remove gateway data', 'paid-memberships-pro' ); ?></span>
					</li>
				</ul>
				<div class="pmpro-stepper__step-divider"></div>
			</nav>
			<div id="pmpro-dgs-notice" hidden></div>
			<div id="pmpro-dgs-switch" <?php if ( $data['has_replacement'] ) { echo 'hidden'; } ?>>
				<p>
					<?php if ( ! empty( $data['stripe_blockers'] ) ) { ?>
						<strong><?php esc_html_e( 'First, connect Stripe.', 'paid-memberships-pro' ); ?></strong>
						<?php echo esc_html( $data['stripe_blockers'][0] ); ?>
					<?php } else { ?>
						<strong><?php esc_html_e( 'First, activate a new payment gateway.', 'paid-memberships-pro' ); ?></strong>
						<?php esc_html_e( 'We recommend Stripe: it is the only gateway with an automatic migration flow. Each active subscription is recreated at Stripe with its price and billing schedule intact, and members add a payment method instead of checking out again.', 'paid-memberships-pro' ); ?>
					<?php } ?>
				</p>
				<p>
					<?php if ( $stripe_connected ) { ?>
						<button type="button" class="button button-primary" id="pmpro-dgs-activate-stripe"><?php esc_html_e( 'Make Stripe the Active Gateway', 'paid-memberships-pro' ); ?></button>
						<p class="description"><?php esc_html_e( 'Your Stripe account is already connected in this environment.', 'paid-memberships-pro' ); ?></p>
					<?php } elseif ( ! current_user_can( 'manage_options' ) ) { ?>
						<?php // The Stripe Connect return handler requires manage_options, so a lesser payment settings user would come back with the credentials silently discarded. ?>
						<span class="description"><?php esc_html_e( 'Connecting to Stripe requires an administrator. Ask an administrator to connect Stripe from the Stripe gateway settings, then return here.', 'paid-memberships-pro' ); ?></span>
					<?php } else { ?>
						<a href="<?php echo esc_url( $stripe_connect_url ); ?>" class="pmpro-stripe-connect"><span><?php esc_html_e( 'Connect with Stripe', 'paid-memberships-pro' ); ?></span></a>
					<?php } ?>
				</p>
				<hr />
				<p class="description">
					<?php esc_html_e( 'Prefer PayPal? The new PayPal Add On is also supported, but it cannot migrate subscriptions automatically. Your site will email members a link to check out again.', 'paid-memberships-pro' ); ?>
					<a href="https://www.paidmembershipspro.com/add-ons/pmpro-paypal/?utm_source=plugin&utm_medium=pmpro-paymentsettings&utm_campaign=add-ons&utm_content=pmpro-paypal" target="_blank" rel="nofollow noopener"><?php esc_html_e( 'Get the PayPal Add On', 'paid-memberships-pro' ); ?></a>
				</p>
			</div>
			<div id="pmpro-dgs-main" <?php if ( ! $data['has_replacement'] ) { echo 'hidden'; } ?>>
			<div class="pmpro-dgs-counts">
				<div class="pmpro-dgs-count" id="pmpro-dgs-card-live">
					<span class="pmpro-dgs-count-num" id="pmpro-dgs-count-live">&ndash;</span>
					<span class="pmpro-dgs-count-label" data-current-label="<?php esc_attr_e( 'current environment', 'paid-memberships-pro' ); ?>"><?php esc_html_e( 'Live subscriptions', 'paid-memberships-pro' ); ?></span>
				</div>
				<div class="pmpro-dgs-count" id="pmpro-dgs-card-sandbox">
					<span class="pmpro-dgs-count-num" id="pmpro-dgs-count-sandbox">&ndash;</span>
					<span class="pmpro-dgs-count-label" data-current-label="<?php esc_attr_e( 'current environment', 'paid-memberships-pro' ); ?>"><?php esc_html_e( 'Sandbox subscriptions', 'paid-memberships-pro' ); ?></span>
				</div>
			</div>
			<div class="pmpro-dgs-workflow" id="pmpro-dgs-workflow"></div>
			<?php if ( '' !== $data['manual_cancel_reason'] ) { ?>
				<div class="pmpro_message pmpro_alert" id="pmpro-dgs-manual-cancel">
					<p>
						<strong><?php esc_html_e( 'Manual cancellation required.', 'paid-memberships-pro' ); ?></strong>
						<?php echo esc_html( $data['manual_cancel_reason'] ); ?>
						<?php esc_html_e( 'Each processed subscription is marked cancelled in Paid Memberships Pro and recorded as "needs review", but it stays active at the gateway until you cancel it in the gateway dashboard. Use the Migration CSV to work through the list; members are billed twice until each one is cancelled.', 'paid-memberships-pro' ); ?>
					</p>
					<p id="pmpro-dgs-manual-ack-row">
						<label for="pmpro-dgs-manual-ack">
							<input type="checkbox" id="pmpro-dgs-manual-ack" />
							<?php esc_html_e( 'I understand that I must cancel each subscription in the gateway dashboard myself. A real migration cannot start until this is checked.', 'paid-memberships-pro' ); ?>
						</label>
					</p>
				</div>
			<?php } ?>
			<div id="pmpro-dgs-finish" hidden>
				<div class="pmpro_message pmpro_alert" id="pmpro-dgs-recurring-outdated" hidden>
					<p>
						<strong><?php esc_html_e( 'Your Recurring Payment Reminder email is customized.', 'paid-memberships-pro' ); ?></strong>
						<?php
						printf(
							/* translators: %s: Liquid conditional tag. */
							esc_html__( 'Migrated Stripe members without a payment method get this reminder before their next payment date, but your version does not check for a missing payment method, so it tells them their membership will renew normally. Use %s in the subject and body to ask them to update their billing information, or reset the template to the default.', 'paid-memberships-pro' ),
							'<code>{% if needs_payment_method %}</code>'
						);
						?>
						<a href="<?php echo esc_url( $recurring_template_url ); ?>"><?php esc_html_e( 'Edit the Recurring Payment Reminder email', 'paid-memberships-pro' ); ?></a>
					</p>
				</div>
				<div id="pmpro-dgs-finish-other" hidden>
					<p id="pmpro-dgs-finish-other-text"></p>
					<p>
						<a class="button button-primary" href="<?php echo esc_url( add_query_arg( array( 'page' => 'pmpro-paymentsettings' ), admin_url( 'admin.php' ) ) ); ?>"><?php esc_html_e( 'Go to Payment Settings', 'paid-memberships-pro' ); ?></a>
					</p>
				</div>
				<div id="pmpro-dgs-finish-clear" hidden>
					<p><?php esc_html_e( 'All subscriptions have been migrated off this gateway. Removing gateway data permanently deletes this gateway\'s stored API credentials and stops loading the gateway. The migration log and Migration CSV files are kept as a record.', 'paid-memberships-pro' ); ?></p>
					<p class="description"><?php esc_html_e( 'Migration CSVs for this gateway:', 'paid-memberships-pro' ); ?></p>
					<ul class="pmpro-dgs-csv-list" id="pmpro-dgs-csv-list"></ul>
					<p id="pmpro-dgs-cancel-pending" hidden>
						<label for="pmpro-dgs-cancel-pending-ack">
							<input type="checkbox" id="pmpro-dgs-cancel-pending-ack" />
							<strong id="pmpro-dgs-cancel-pending-text"></strong>
						</label>
					</p>
					<p>
						<button type="button" class="button button-primary" id="pmpro-dgs-cleanup"><?php esc_html_e( 'Remove Gateway Data', 'paid-memberships-pro' ); ?></button>
					</p>
				</div>
			</div>
			<table class="form-table" role="presentation" id="pmpro-dgs-controls">
				<tbody>
					<tr>
						<th scope="row">
							<label for="pmpro-dgs-strategy"><?php esc_html_e( 'Migration Type', 'paid-memberships-pro' ); ?></label>
						</th>
						<td>
							<select id="pmpro-dgs-strategy">
								<option value="stripe"><?php esc_html_e( 'Migrate to Stripe subscriptions', 'paid-memberships-pro' ); ?></option>
								<option value="expiration"><?php esc_html_e( 'Cancel subscriptions and set expiration dates', 'paid-memberships-pro' ); ?></option>
							</select>
							<p class="description" id="pmpro-dgs-desc-stripe" hidden>
								<?php esc_html_e( 'Each subscription is recreated at Stripe with the same price and billing schedule, starting on its next payment date, and the old subscription is cancelled. Memberships don\'t change. The new subscription has no payment method on file: if the member doesn\'t add one by their next payment date, Stripe cancels it and the membership ends. Members in a trial period move to the regular price. Track these members on the Subscriptions list under Awaiting Payment Method.', 'paid-memberships-pro' ); ?>
							</p>
							<p class="description" id="pmpro-dgs-desc-expiration" hidden>
								<?php esc_html_e( 'Each old subscription is cancelled and the membership is set to expire on its next payment date. To stay, members check out again at your current level pricing, so they lose any grandfathered price or billing schedule.', 'paid-memberships-pro' ); ?>
							</p>
						</td>
					</tr>
					<tr>
						<th scope="row">
							<label for="pmpro-dgs-email"><?php esc_html_e( 'Member Emails', 'paid-memberships-pro' ); ?></label>
						</th>
						<td>
							<select id="pmpro-dgs-email">
								<option value="yes"><?php esc_html_e( 'Email members about the change', 'paid-memberships-pro' ); ?></option>
								<option value="no"><?php esc_html_e( 'Do not email members', 'paid-memberships-pro' ); ?></option>
							</select>
							<p class="description">
								<?php esc_html_e( 'Send each migrated member one email when their subscription is processed: the Stripe migration email asks them to add a payment method, and the checkout required email asks them to check out again. To send through your own email service instead, choose "Do not email members" and use the Migration CSV after the migration. Either way, members still get your site\'s regular automatic emails: Stripe members without a payment method get a recurring payment reminder asking them to add one, and expiring members get the standard expiration warning.', 'paid-memberships-pro' ); ?>
								<a href="<?php echo esc_url( $stripe_template_url ); ?>"><?php esc_html_e( 'Edit the Stripe migration email', 'paid-memberships-pro' ); ?></a>
								|
								<a href="<?php echo esc_url( $checkout_template_url ); ?>"><?php esc_html_e( 'Edit the checkout required email', 'paid-memberships-pro' ); ?></a>
							</p>
						</td>
					</tr>
					<tr>
						<th scope="row">
							<label for="pmpro-dgs-no-payment"><?php esc_html_e( 'Subscriptions With a Missed Payment', 'paid-memberships-pro' ); ?></label>
						</th>
						<td>
							<select id="pmpro-dgs-no-payment">
								<option value="skip"><?php esc_html_e( 'Skip them and log them for manual review', 'paid-memberships-pro' ); ?></option>
								<option value="expire"><?php esc_html_e( 'Cancel them and expire the membership', 'paid-memberships-pro' ); ?></option>
							</select>
							<p class="description"><?php esc_html_e( 'A next payment date in the past (or none at all) usually means a payment notification from the old gateway never arrived, so the gateway may still be billing the member. Skip leaves these subscriptions alone and lists them in the migration log to check by hand. Cancel and expire cancels them at the old gateway and ends the membership three days after the migration runs. This applies to either migration type.', 'paid-memberships-pro' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row">
							<label for="pmpro-dgs-dry-run"><?php esc_html_e( 'Dry Run', 'paid-memberships-pro' ); ?></label>
						</th>
						<td>
							<label for="pmpro-dgs-dry-run">
								<input type="checkbox" id="pmpro-dgs-dry-run" checked />
								<?php esc_html_e( 'Preview the migration without making any changes', 'paid-memberships-pro' ); ?>
							</label>
							<p class="description"><?php esc_html_e( 'Records what would happen to each subscription in the migration log without changing anything or sending email. Some gateway errors only show up during a real migration.', 'paid-memberships-pro' ); ?></p>
						</td>
					</tr>
				</tbody>
			</table>
			<div class="pmpro_message pmpro_error" id="pmpro-dgs-realbar" hidden>
				<p><?php esc_html_e( 'Dry run is off, so this is a real migration. These changes are permanent and cannot be undone: subscriptions will be migrated and cancelled at the old gateway.', 'paid-memberships-pro' ); ?></p>
			</div>
			<div class="pmpro-dgs-actions">
				<button type="button" class="button button-primary" id="pmpro-dgs-start"><?php esc_html_e( 'Start Migration', 'paid-memberships-pro' ); ?></button>
				<button type="button" class="button" id="pmpro-dgs-stop" hidden><?php esc_html_e( 'Stop Workflow', 'paid-memberships-pro' ); ?></button>
			</div>
			<ul class="pmpro-dgs-blockers" id="pmpro-dgs-blockers"></ul>
			</div><!-- end pmpro-dgs-main -->
			<div class="pmpro-dgs-footer" id="pmpro-dgs-footer" <?php if ( empty( $data['has_log'] ) ) { echo 'hidden'; } ?>>
				<a href="<?php echo esc_url( $log_url ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'View the full migration log', 'paid-memberships-pro' ); ?></a>
			</div>
			</div><!-- end pmpro_section_inside -->
		</div><!-- end pmpro_section -->
		<script>
		( function() {
			var cfg = <?php echo wp_json_encode( $config, JSON_HEX_TAG | JSON_HEX_AMP ); ?>;
			var pollTimer = null;
			var $ = function( id ) { return document.getElementById( id ); };

			function sprintf( tpl ) {
				var args = Array.prototype.slice.call( arguments, 1 ), i = 0;
				return tpl.replace( /%(\d+\$)?s/g, function( match, pos ) {
					return String( args[ pos ? parseInt( pos, 10 ) - 1 : i++ ] );
				} );
			}

			function el( tag, className, text ) {
				var node = document.createElement( tag );
				if ( className ) { node.className = className; }
				if ( text ) { node.textContent = text; }
				return node;
			}

			function api( task, extra ) {
				var body = new URLSearchParams( { action: 'pmpro_deprecated_gateway', nonce: cfg.nonce, gateway: cfg.gateway, task: task } );
				Object.keys( extra || {} ).forEach( function( key ) { body.append( key, extra[ key ] ); } );
				fetch( ajaxurl, { method: 'POST', credentials: 'same-origin', body: body } )
					.then( function( response ) { return response.json(); } )
					.then( function( response ) {
						if ( ! response || ! response.success ) {
							notice( ( response && response.data && response.data.message ) || cfg.i18n.error_generic, true );
							return;
						}
						if ( response.data.redirect ) {
							window.location.href = response.data.redirect;
							return;
						}
						render( response.data );
						if ( response.data.message ) { notice( response.data.message, !! response.data.error ); }
					} )
					.catch( function() {
						notice( cfg.i18n.error_generic, true );
						// Keep polling through transient request failures so one bad
						// response doesn't freeze the progress display mid-migration.
						if ( cfg.latest && ( cfg.latest.is_running || cfg.latest.has_actions ) ) {
							clearTimeout( pollTimer );
							pollTimer = setTimeout( function() { api( 'status' ); }, 4000 );
						}
					} );
			}

			function notice( message, isError ) {
				var node = $( 'pmpro-dgs-notice' );
				node.textContent = '';
				node.className = 'pmpro_message ' + ( isError ? 'pmpro_error' : 'pmpro_success' );
				node.appendChild( el( 'p', '', message ) );
				node.hidden = false;
			}

			function warning( message ) {
				var node = el( 'div', 'pmpro_message pmpro_alert' );
				node.appendChild( el( 'p', '', message ) );
				return node;
			}

			function summary( w ) {
				var wrap = el( 'p', 'pmpro-dgs-summary' );
				wrap.appendChild( el( 'span', 'pmpro_tag pmpro_tag-success', cfg.i18n.chip_complete + ': ' + w.complete ) );
				wrap.appendChild( el( 'span', 'pmpro_tag pmpro_tag-' + ( w.skipped > 0 ? 'alert' : 'info' ), cfg.i18n.chip_skipped + ': ' + w.skipped ) );
				wrap.appendChild( el( 'span', 'pmpro_tag pmpro_tag-' + ( w.needs_review > 0 ? 'alert pmpro_tag-has_icon' : 'info' ), cfg.i18n.chip_needs_review + ': ' + w.needs_review ) );
				return wrap;
			}

			function renderWorkflow( d ) {
				var box = $( 'pmpro-dgs-workflow' ), w = d.workflow;
				box.textContent = '';
				if ( ! w ) {
					box.appendChild( el( 'p', 'pmpro-dgs-meta', cfg.i18n.no_workflow ) );
					return;
				}
				var title = el( 'p', 'pmpro-dgs-workflow-title' );
				if ( 'running' === w.status ) {
					title.appendChild( el( 'span', 'spinner is-active' ) );
					title.appendChild( document.createTextNode( w.dry_run ? cfg.i18n.running_dry : cfg.i18n.running ) );
					box.appendChild( title );
					box.appendChild( el( 'p', 'pmpro-dgs-meta', sprintf( cfg.i18n.started_on, w.started_display ) ) );
					var bar = el( 'div', 'pmpro-dgs-bar' ), fill = el( 'div', 'pmpro-dgs-bar-fill' );
					var percent = w.total ? Math.min( 100, Math.round( w.processed / w.total * 100 ) ) : 0;
					fill.style.width = percent + '%';
					bar.appendChild( fill );
					box.appendChild( bar );
					box.appendChild( el( 'p', 'pmpro-dgs-meta', sprintf( cfg.i18n.progress_of, w.processed, w.total ) ) );
				} else if ( 'completed' === w.status ) {
					title.textContent = sprintf( w.dry_run ? cfg.i18n.completed_on_dry : cfg.i18n.completed_on, w.completed_display );
					box.appendChild( title );
				} else {
					title.textContent = cfg.i18n.stopped;
					box.appendChild( title );
					if ( w.note ) { box.appendChild( el( 'p', 'pmpro-dgs-meta', w.note ) ); }
				}
				box.appendChild( summary( w ) );
				if ( w.needs_review > 0 ) { box.appendChild( warning( cfg.i18n.needs_review_warning ) ); }
				if ( 'running' !== w.status && w.skipped > 0 ) { box.appendChild( warning( cfg.i18n.skipped_warning ) ); }
				if ( 'completed' === w.status ) {
					var download = el( 'a', 'button button-secondary', cfg.i18n.download_log );
					download.href = cfg.log_url;
					download.setAttribute( 'download', '' );
					box.appendChild( download );

					// The per-run Migration CSV is offered only after the run finishes.
					if ( w.csv_url && w.processed > 0 ) {
						var csv = el( 'a', 'button button-secondary', cfg.i18n.download_csv );
						csv.href = w.csv_url;
						csv.setAttribute( 'download', '' );
						csv.style.marginLeft = '8px';
						box.appendChild( csv );
					}
				}
			}

			function render( d ) {
				cfg.latest = d;
				var isLive = 'live' === d.environment;
				$( 'pmpro-dgs-count-live' ).textContent = d.counts.live;
				$( 'pmpro-dgs-count-live' ).className = 'pmpro-dgs-count-num' + ( d.counts.live > 0 ? ' is-live' : '' );
				$( 'pmpro-dgs-count-sandbox' ).textContent = d.counts.sandbox;
				$( 'pmpro-dgs-card-live' ).className = 'pmpro-dgs-count' + ( isLive ? ' is-current' : '' );
				$( 'pmpro-dgs-card-sandbox' ).className = 'pmpro-dgs-count' + ( isLive ? '' : ' is-current' );

				function step( id, state ) {
					var item = $( id );
					item.className = 'pmpro-stepper__step' + ( state ? ' is-' + state : '' );
					item.querySelector( '.pmpro-stepper__step-number' ).textContent = 'done' === state ? '✓' : item.getAttribute( 'data-step' );
				}
				var migrated = 0 === d.counts.live && 0 === d.counts.sandbox;
				step( 'pmpro-dgs-step-1', d.has_replacement ? 'done' : 'active' );
				step( 'pmpro-dgs-step-2', migrated ? 'done' : ( d.has_replacement ? 'active' : '' ) );

				// Only surface cleanup once the current environment is fully migrated.
				var envMigrated = 0 === ( isLive ? d.counts.live : d.counts.sandbox );
				step( 'pmpro-dgs-step-3', envMigrated && d.can_cleanup ? 'active' : '' );

				$( 'pmpro-dgs-footer' ).hidden = ! d.has_log;
				$( 'pmpro-dgs-switch' ).hidden = d.has_replacement;
				$( 'pmpro-dgs-main' ).hidden = ! d.has_replacement;

				renderWorkflow( d );

				// On step 3, replace the migration controls with either a prompt to
				// switch environments or the final download/remove actions.
				var onStep3 = envMigrated && ! d.is_running;
				var otherCount = isLive ? d.counts.sandbox : d.counts.live;
				$( 'pmpro-dgs-controls' ).hidden = onStep3;
				$( 'pmpro-dgs-finish' ).hidden = ! onStep3;
				$( 'pmpro-dgs-finish-other' ).hidden = ! onStep3 || 0 === otherCount;
				$( 'pmpro-dgs-finish-clear' ).hidden = ! onStep3 || otherCount > 0;
				$( 'pmpro-dgs-recurring-outdated' ).hidden = ! d.recurring_reminder_outdated;
				$( 'pmpro-dgs-finish-other-text' ).textContent = sprintf( isLive ? cfg.i18n.finish_other_sandbox : cfg.i18n.finish_other_live, otherCount );

				// List this gateway's Migration CSVs at the cleanup step as a convenient
				// place to download them (they are kept after removal, not deleted).
				var csvList = $( 'pmpro-dgs-csv-list' );
				csvList.textContent = '';
				var csvFiles = d.csv_files || [];
				if ( csvFiles.length ) {
					csvFiles.forEach( function( file ) {
						var li = el( 'li' );
						var link = el( 'a', '', cfg.i18n.download_csv + ( file.date ? ' — ' + file.date : '' ) );
						link.href = file.url;
						link.setAttribute( 'download', '' );
						li.appendChild( link );
						csvList.appendChild( li );
					} );
				} else {
					csvList.appendChild( el( 'li', '', cfg.i18n.csv_none ) );
				}

				$( 'pmpro-dgs-start' ).hidden = d.is_running || onStep3;
				$( 'pmpro-dgs-stop' ).hidden = ! d.is_running;

				// The manual-cancel acknowledgement only matters while Start is on screen, and a
				// new real run must be acknowledged again.
				if ( $( 'pmpro-dgs-manual-ack-row' ) ) {
					$( 'pmpro-dgs-manual-ack-row' ).hidden = $( 'pmpro-dgs-start' ).hidden;
					$( 'pmpro-dgs-manual-ack' ).disabled = d.is_running;
					if ( d.is_running ) { $( 'pmpro-dgs-manual-ack' ).checked = false; }
				}

				// Cleanup needs an explicit confirmation while subscriptions this workflow could
				// only mark cancelled in PMPro may still be active at the gateway.
				var pending = d.cancel_pending || 0;
				$( 'pmpro-dgs-cancel-pending' ).hidden = ! pending;
				$( 'pmpro-dgs-cancel-pending-text' ).textContent = pending ? ( 1 === pending ? cfg.i18n.cancel_pending_ack_one : sprintf( cfg.i18n.cancel_pending_ack, pending ) ) : '';
				if ( ! pending ) { $( 'pmpro-dgs-cancel-pending-ack' ).checked = false; }
				updateCleanupButton();
				$( 'pmpro-dgs-strategy' ).disabled = d.is_running;
				$( 'pmpro-dgs-strategy' ).options[0].disabled = ! d.stripe_available;
				if ( ! d.stripe_available && 'stripe' === $( 'pmpro-dgs-strategy' ).value ) {
					$( 'pmpro-dgs-strategy' ).value = 'expiration';
				}
				$( 'pmpro-dgs-email' ).disabled = d.is_running;
				$( 'pmpro-dgs-no-payment' ).disabled = d.is_running;
				$( 'pmpro-dgs-dry-run' ).disabled = d.is_running;
				updateDescription();

				updateDryRunMode();
				updateStartButton();

				var blockers = $( 'pmpro-dgs-blockers' );
				blockers.textContent = '';
				if ( ! d.is_running ) {
					// Only explain the action that is actually on screen: cleanup
					// blockers on step 3, start blockers while migrating. Stripe
					// blockers keep step 1 open, so they are shown there instead.
					var visible_blockers = onStep3 ? ( 0 === otherCount ? d.cleanup_blockers : [] ) : d.start_blockers;
					visible_blockers.forEach( function( blocker ) {
						blockers.appendChild( el( 'li', '', blocker ) );
					} );
				}

				clearTimeout( pollTimer );
				// Keep polling while the last action of a finished or stopped run drains, so the
				// "still finishing" start blocker clears without a reload.
				if ( d.is_running || d.has_actions ) {
					pollTimer = setTimeout( function() { api( 'status' ); }, 4000 );
				}
			}

			// A real run on a gateway that cannot cancel automatically also needs the acknowledgement box.
			function updateStartButton() {
				var d = cfg.latest, ack = $( 'pmpro-dgs-manual-ack' );
				var blocked = ! d || ! d.can_start;
				if ( ! blocked && d.manual_cancel_reason && ! $( 'pmpro-dgs-dry-run' ).checked && ack && ! ack.checked ) { blocked = true; }
				$( 'pmpro-dgs-start' ).disabled = blocked;
			}
			if ( $( 'pmpro-dgs-manual-ack' ) ) {
				$( 'pmpro-dgs-manual-ack' ).addEventListener( 'change', updateStartButton );
			}

			function updateCleanupButton() {
				var d = cfg.latest;
				var pending = d ? ( d.cancel_pending || 0 ) : 0;
				$( 'pmpro-dgs-cleanup' ).disabled = ! d || ! d.can_cleanup || ( pending && ! $( 'pmpro-dgs-cancel-pending-ack' ).checked );
			}
			$( 'pmpro-dgs-cancel-pending-ack' ).addEventListener( 'change', updateCleanupButton );

			function updateDescription() {
				var isStripe = 'stripe' === $( 'pmpro-dgs-strategy' ).value;
				$( 'pmpro-dgs-desc-stripe' ).hidden = ! isStripe;
				$( 'pmpro-dgs-desc-expiration' ).hidden = isStripe;
			}
			$( 'pmpro-dgs-strategy' ).addEventListener( 'change', updateDescription );

			// Show the real-run warning while Start is on screen with Dry Run off, and keep the button label in sync.
			function updateDryRunMode() {
				var dryRun = $( 'pmpro-dgs-dry-run' ).checked;
				$( 'pmpro-dgs-realbar' ).hidden = dryRun || $( 'pmpro-dgs-start' ).hidden;
				$( 'pmpro-dgs-start' ).textContent = dryRun ? cfg.i18n.start_dry : cfg.i18n.start_real;
			}
			$( 'pmpro-dgs-dry-run' ).addEventListener( 'change', function() { updateDryRunMode(); updateStartButton(); } );

			if ( $( 'pmpro-dgs-activate-stripe' ) ) {
				$( 'pmpro-dgs-activate-stripe' ).addEventListener( 'click', function() {
					// Preselect the Stripe migration path; render() reverts this if activation fails.
					$( 'pmpro-dgs-strategy' ).value = 'stripe';
					api( 'activate_stripe' );
				} );
			}

			$( 'pmpro-dgs-start' ).addEventListener( 'click', function() {
				var d = cfg.latest;
				var count = 'live' === d.environment ? d.counts.live : d.counts.sandbox;
				var envLabel = 'live' === d.environment ? cfg.i18n.env_live : cfg.i18n.env_sandbox;
				var sendEmail = 'yes' === $( 'pmpro-dgs-email' ).value;
				var expirePastDue = 'expire' === $( 'pmpro-dgs-no-payment' ).value;
				var dryRun = $( 'pmpro-dgs-dry-run' ).checked;
				var isStripe = 'stripe' === $( 'pmpro-dgs-strategy' ).value;
				var text = dryRun
					? sprintf( cfg.i18n.confirm_start_dry, count, envLabel ) + ' ' + cfg.i18n.confirm_continue
					: sprintf( cfg.i18n.confirm_start, count, envLabel ) + ' ' +
						( sendEmail ? cfg.i18n.confirm_start_email : cfg.i18n.confirm_start_noemail ) +
						( isStripe ? ' ' + cfg.i18n.confirm_start_stripe : '' ) +
						( expirePastDue ? ' ' + cfg.i18n.confirm_start_expire_past_due : '' ) +
						( d.manual_cancel_reason ? ' ' + cfg.i18n.confirm_start_manual : '' ) + ' ' + cfg.i18n.confirm_continue;
				if ( window.confirm( text ) ) {
					var ack = $( 'pmpro-dgs-manual-ack' );
					api( 'start', { strategy: $( 'pmpro-dgs-strategy' ).value, skip_email: sendEmail ? '' : '1', expire_past_due: expirePastDue ? '1' : '', dry_run: dryRun ? '1' : '', manual_cancel_acknowledged: ( ack && ack.checked ) ? '1' : '' } );
				}
			} );

			$( 'pmpro-dgs-stop' ).addEventListener( 'click', function() {
				if ( window.confirm( cfg.i18n.confirm_stop ) ) { api( 'stop' ); }
			} );

			$( 'pmpro-dgs-cleanup' ).addEventListener( 'click', function() {
				if ( window.confirm( cfg.i18n.confirm_cleanup + ' ' + cfg.i18n.confirm_continue ) ) { api( 'cleanup', { cancel_pending_confirmed: $( 'pmpro-dgs-cancel-pending-ack' ).checked ? '1' : '' } ); }
			} );

			render( cfg.initial );
		} )();
		</script>
	</div>
	<?php
}
