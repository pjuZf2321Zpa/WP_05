<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class PMPro_Email_Template_Deprecated_Gateway_Checkout_Required extends PMPro_Email_Template {
	/**
	 * The user object of the user to send the email to.
	 *
	 * @var WP_User
	 */
	protected $user;

	/**
	 * The level ID.
	 *
	 * @var int
	 */
	protected $membership_level_id;

	/**
	 * Unix timestamp when the membership expires.
	 *
	 * @var int
	 */
	protected $expiration_timestamp;

	/**
	 * Constructor.
	 *
	 * @since 3.9
	 *
	 * @param WP_User $user The user object of the user to send the email to.
	 * @param int     $membership_level_id The ID of the membership level.
	 * @param int     $expiration_timestamp Unix timestamp when the membership expires.
	 */
	public function __construct( WP_User $user, int $membership_level_id, int $expiration_timestamp ) {
		$this->user = $user;
		$this->membership_level_id = $membership_level_id;
		$this->expiration_timestamp = $expiration_timestamp;
	}

	/**
	 * Get the email template slug.
	 *
	 * @since 3.9
	 *
	 * @return string The email template slug.
	 */
	public static function get_template_slug() {
		return 'deprecated_gateway_checkout_required';
	}

	/**
	 * Get the "nice name" of the email template.
	 *
	 * @since 3.9
	 *
	 * @return string The "nice name" of the email template.
	 */
	public static function get_template_name() {
		return esc_html__( 'Deprecated Gateway Checkout Required', 'paid-memberships-pro' );
	}

	/**
	 * Get "help text" to display to the admin when editing the email template.
	 *
	 * @since 3.9
	 *
	 * @return string The help text.
	 */
	public static function get_template_description() {
		return esc_html__( 'This email is sent when an administrator cancels a deprecated gateway subscription and sets the member\'s expiration date to the old next payment date, or three days out if that date is sooner. It tells the member they will need to check out again to continue their membership.', 'paid-memberships-pro' );
	}

	/**
	 * Get the default subject for the email.
	 *
	 * @since 3.9
	 *
	 * @return string The default subject.
	 */
	public static function get_default_subject() {
		return esc_html__( 'Action required: renew your membership at {{ sitename }}', 'paid-memberships-pro' );
	}

	/**
	 * Get the default body content for the email.
	 *
	 * @since 3.9
	 *
	 * @return string The default body content.
	 */
	public static function get_default_body() {
		return wp_kses_post( __( '<p>We\'ve updated the way {{ sitename }} processes payments, so we can no longer renew your {{ membership_level_name }} membership automatically.</p>

<p>Your membership stays active until {{ expiration_date }}.</p>

<p>To keep your membership, please check out again before {{ expiration_date }} so you don\'t lose access. Note that checking out again before that date may replace any remaining time on your current membership.</p>

<p>Renew your membership here: {{ checkout_url }}</p>', 'paid-memberships-pro' ) );
	}

	/**
	 * Get the email template variables for the email paired with a description.
	 *
	 * @since 3.9
	 *
	 * @return array The email template variables for the email.
	 */
	public static function get_email_template_variables_with_description() {
		return array(
			'{{ display_name }}' => __( 'The display name of the user.', 'paid-memberships-pro' ),
			'{{ user_login }}' => __( 'The username of the user.', 'paid-memberships-pro' ),
			'{{ user_email }}' => __( 'The email address of the user.', 'paid-memberships-pro' ),
			'{{ membership_id }}' => __( 'The ID of the membership level.', 'paid-memberships-pro' ),
			'{{ membership_level_name }}' => __( 'The name of the membership level.', 'paid-memberships-pro' ),
			'{{ expiration_date }}' => __( 'The date when the member\'s current access expires.', 'paid-memberships-pro' ),
			'{{ checkout_url }}' => __( 'The checkout URL for the member\'s membership level.', 'paid-memberships-pro' ),
		);
	}

	/**
	 * Get the email address to send the email to.
	 *
	 * @since 3.9
	 *
	 * @return string The email address.
	 */
	public function get_recipient_email() {
		return $this->user->user_email;
	}

	/**
	 * Get the name of the email recipient.
	 *
	 * @since 3.9
	 *
	 * @return string The name.
	 */
	public function get_recipient_name() {
		return $this->user->display_name;
	}

	/**
	 * Get the email template variables for the email.
	 *
	 * @since 3.9
	 *
	 * @return array The email template variables.
	 */
	public function get_email_template_variables() {
		$user = $this->user;
		$level = pmpro_getSpecificMembershipLevelForUser( $user->ID, $this->membership_level_id );
		if ( empty( $level ) ) {
			$level = pmpro_getLevel( $this->membership_level_id );
		}

		$expiration_date = date_i18n( get_option( 'date_format' ), $this->expiration_timestamp );

		return array(
			'name' => $user->display_name,
			'display_name' => $user->display_name,
			'user_login' => $user->user_login,
			'user_email' => $user->user_email,
			'membership_id' => ! empty( $level->id ) ? $level->id : $this->membership_level_id,
			'membership_level_name' => ! empty( $level->name ) ? $level->name : '',
			'expiration_date' => $expiration_date,
			'checkout_url' => pmpro_url( 'checkout', 'pmpro_level=' . (int) $this->membership_level_id ),
		);
	}

	/**
	 * Returns the arguments to send the test email from the abstract class.
	 *
	 * @since 3.9
	 *
	 * @return array The arguments to send the test email from the abstract class.
	 */
	public static function get_test_email_constructor_args() {
		global $current_user;

		$levels = pmpro_getAllLevels( true );
		$level  = current( $levels );
		$level_id = empty( $level ) ? 1 : (int) $level->id;

		return array( $current_user, $level_id, strtotime( '+1 month' ) );
	}
}

/**
 * Register the email template.
 *
 * @since 3.9
 *
 * @param array $email_templates The email templates.
 * @return array The modified email templates array.
 */
function pmpro_deprecated_gateway_register_checkout_required_email_template( $email_templates ) {
	if ( function_exists( 'pmpro_has_undeprecated_gateways' ) && pmpro_has_undeprecated_gateways() ) {
		$email_templates['deprecated_gateway_checkout_required'] = 'PMPro_Email_Template_Deprecated_Gateway_Checkout_Required';
	}

	return $email_templates;
}
add_filter( 'pmpro_email_templates', 'pmpro_deprecated_gateway_register_checkout_required_email_template' );
