<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class PMPro_Email_Template_Credit_Card_Expiring extends PMPro_Email_Template {

	/**
	 * The user object of the user to send the email to.
	 *
	 * @var WP_User
	 */
	protected $user;

	/**
	 * The {@link MemberOrder} object of the order that was updated.
	 *
	 * @var MemberOrder
	 */
	protected $order;

	/**
	 * Constructor.
	 *
	 * @since 3.4
	 * @deprecated 3.8
	 *
	 * @param WP_User $user The user object of the user to send the email to.
	 * @param MemberOrder $order The order object that is associated to the member.
	 */
	public function __construct( WP_User $user,  MemberOrder $order ) {
		_deprecated_function( __CLASS__, '3.8' );
		$this->user = $user;
		$this->order = $order;
	}

	/**
	 * Get the email template slug.
	 *
	 * @since 3.4
	 *
	 * @return string The email template slug.
	 */
	public static function get_template_slug() {
		return 'credit_card_expiring';
	}

	/**
	 * Get the "nice name" of the email template.
	 *
	 * @since 3.4
	 *
	 * @return string The "nice name" of the email template.
	 */
	public static function get_template_name() {
		return esc_html__( 'Credit Card Expiring', 'paid-memberships-pro' );
	}

	/**
	 * Get "help text" to display to the admin when editing the email template.
	 *
	 * @since 3.4
	 *
	 * @return string The "help text" to display to the admin when editing the email template.
	 */
	public static function get_template_description() {
		return esc_html__( "Legacy email that was sent when a member's payment method was be expiring soon. This email is no longer sent by default and will be removed in a future version of PMPro.", 'paid-memberships-pro' );
	}

	/**
	 * Get the default subject for the email.
	 *
	 * @since 3.4
	 *
	 * @return string The default subject for the email.
	 */
	public static function get_default_subject() {
		return esc_html__( 'Credit card on file expiring soon at {{ sitename }}', 'paid-memberships-pro' );
	}

	/**
	 * Get the default body content for the email.
	 *
	 * @since 3.4
	 *
	 * @return string The default body content for the email.
	 */
	public static function get_default_body() {
		return wp_kses_post( __( '<p>The payment method used for your membership at {{ sitename }} will expire soon.</p>

<p>
	<strong>Please click the following link to log in and update your billing information to avoid account suspension.</strong><br />
	{{ login_url }}
</p>

<p>Account: {{ display_name }} ({{ user_email }})</p>

<p>The most recent account information we have on file is:</p>

<p>
	{{ billing_name }}<br />
	{{ billing_address }}
</p>

{% if accountnumber %}<p>
	{{ cardtype }}: {{ accountnumber }}<br />
	Expires: {{ expirationmonth }}/{{ expirationyear }}
</p>{% endif %}', 'paid-memberships-pro' ) );
	}

	/**
	 * Get the email address to send the email to.
	 *
	 * @since 3.4
	 *
	 * @return string The email address to send the email to.
	 */
	public function get_recipient_email() {
		return $this->user->user_email;
	}

	/**
	 * Get the name of the email recipient.
	 *
	 * @since 3.4
	 *
	 * @return string The name of the email recipient.
	 */
	public function get_recipient_name() {
		return $this->user->display_name;
	}

	/**
	 * Get the email template variables for the email paired with a description of the variable.
	 *
	 * @since 3.4
	 *
	 * @return array The email template variables for the email (key => value pairs).
	 */
	public static function get_email_template_variables_with_description() {
		return array(
			'{{ display_name }}' => __( 'The display name of the user.', 'paid-memberships-pro' ),
			'{{ user_login }}' => __( 'The username of the user.', 'paid-memberships-pro' ),
			'{{ user_email }}' => __( 'The email address of the user.', 'paid-memberships-pro' ),
			'{{ membership_id }}' => __( 'The ID of the membership level.', 'paid-memberships-pro' ),
			'{{ level_group_id }}' => __( 'The ID of the level group that the membership level belongs to.', 'paid-memberships-pro' ),
			'{{ membership_level_name }}' => __( 'The name of the membership level.', 'paid-memberships-pro' ),
			'{{ billing_address }}' => __( 'The complete billing address of the order.', 'paid-memberships-pro' ),
			'{{ billing_name }}' => __( 'The billing name of the order.', 'paid-memberships-pro' ),
			'{{ billing_street }}' => __( 'The billing street of the order.', 'paid-memberships-pro' ),
			'{{ billing_street2 }}' => __( 'The billing street line 2 of the order.', 'paid-memberships-pro' ),
			'{{ billing_city }}' => __( 'The billing city of the order.', 'paid-memberships-pro' ),
			'{{ billing_state }}' => __( 'The billing state of the order.', 'paid-memberships-pro' ),
			'{{ billing_zip }}' => __( 'The billing ZIP code of the order.', 'paid-memberships-pro' ),
			'{{ billing_country }}' => __( 'The billing country of the order.', 'paid-memberships-pro' ),
			'{{ billing_phone }}' => __( 'The billing phone number of the order.', 'paid-memberships-pro' ),
			'{{ cardtype }}' => __( 'The type of credit card used.', 'paid-memberships-pro' ),
			'{{ accountnumber }}' => __( 'The last four digits of the credit card number.', 'paid-memberships-pro' ),
			'{{ expirationmonth }}' => __( 'The expiration month of the credit card.', 'paid-memberships-pro' ),
			'{{ expirationyear }}' => __( 'The expiration year of the credit card.', 'paid-memberships-pro' ),
		);
	}

	/**
	 * Get the email template variables for the email.
	 *
	 * @since 3.4
	 *
	 * @return array The email template variables for the email (key => value pairs).
	 */
	public function get_email_template_variables() {
		$user = $this->user;
		$order = $this->order;
		$membership_level = pmpro_getLevel( $order->membership_id );

		return array(
			'subject' => $this->get_default_subject(),
			'name' => $user->display_name,
			'display_name' => $user->display_name,
			'user_login' => $user->user_login,
			'user_email' => $user->user_email,
			'membership_id' => $membership_level->id,
			'level_group_id' => pmpro_get_group_id_for_level( $membership_level->id ) ?: 0,
			'membership_level_name' => $membership_level->name,
			'billing_name' => $order->billing->name,
			'billing_street' => $order->billing->street,
			'billing_street2' => $order->billing->street2,
			'billing_city' => $order->billing->city,
			'billing_state' => $order->billing->state,
			'billing_zip' => $order->billing->zip,
			'billing_country' => $order->billing->country,
			'billing_phone' => $order->billing->phone,
			'billing_address'=> pmpro_formatAddress( $order->billing->name,
				$order->billing->street,
				$order->billing->street2,
				$order->billing->city,
				$order->billing->state,
				$order->billing->zip,
				$order->billing->country,
				$order->billing->phone ),
			'cardtype' => $order->cardtype,
			'accountnumber' => hideCardNumber( $order->accountnumber ),
			'expirationmonth' => $order->expirationmonth,
			'expirationyear' => $order->expirationyear,
		);
	}

	/**
	 * Returns the arguments to send the test email from the abstract class.
	 *
	 * @since 3.5
	 *
	 * @return array The arguments to send the test email from the abstract class.
	 */
	public static function get_test_email_constructor_args() {
		global $current_user;
		//Create test order
		$test_order = new MemberOrder();

		return array( $current_user, $test_order->get_test_order() );
	}
}

/**
 * Register the email template.
 *
 * @since 3.4
 * @deprecated 3.8
 *
 * @param array $email_templates The email templates (template slug => email template class name)
 * @return array The modified email templates array.
 */
function pmpro_email_templates_credit_card_expiring( $email_templates ) {
	_deprecated_function( __FUNCTION__, '3.8' );
	$email_templates['credit_card_expiring'] = 'PMPro_Email_Template_Credit_Card_Expiring';
	return $email_templates;
}
