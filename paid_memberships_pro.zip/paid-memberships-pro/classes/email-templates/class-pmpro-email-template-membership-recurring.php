<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class PMPro_Email_Template_Membership_Recurring extends PMPro_Email_Template {

	/**
	 * The subscription object relating to this transaction.
	 *
	 * @var PMPro_Subscription
	 */
	protected $subscription_obj;

	/**
	 * Constructor.
	 *
	 * @since 3.4
	 *
	 * @param PMPro_Subscription $subscription_obj The PMPro subscription object.
	 */
	public function __construct( PMPro_Subscription $subscription_obj ) {
		$this->subscription_obj = $subscription_obj;
	}

	/**
	 * Get the email template slug.
	 *
	 * @since 3.4
	 *
	 * @return string The email template slug.
	 */
	public static function get_template_slug() {
		return 'membership_recurring';
	}

	/**
	 * Get the "nice name" of the email template.
	 *
	 * @since 3.4
	 *
	 * @return string The "nice name" of the email template.
	 */
	public static function get_template_name() {
		return esc_html__( 'Recurring Payment Reminder', 'paid-memberships-pro' );
	}

	/**
	 * Get "help text" to display to the admin when editing the email template.
	 *
	 * @since 3.4
	 *
	 * @return string The "help text" to display to the admin when editing the email template.
	 */
	public static function get_template_description() {
		return sprintf(
			esc_html__( 'This email is sent when a subscription is approaching its renewal date. The additional placeholders %1$s and %2$s can be used to print the date that the subscription will renew and the renewal price.', 'paid-memberships-pro' ),
			'{{ renewaldate }}',
			'{{ billing_amount }}'
		);
	}

	/**
	 * Get the default subject for the email.
	 *
	 * @since 3.4
	 *
	 * @return string The default subject for the email.
	 */
	public static function get_default_subject() {
		// The original subject is its own string so existing translations still apply.
		return '{% if needs_payment_method %}' . esc_html__( 'Action required: add a payment method for {{ sitename }}', 'paid-memberships-pro' ) . '{% else %}' . esc_html__( 'Your membership at {{ sitename }} will renew soon', 'paid-memberships-pro' ) . '{% endif %}';
	}

	/**
	 * Get the default body content for the email.
	 *
	 * @since 3.4
	 *
	 * @return string The default body content for the email.
	 */
	public static function get_default_body() {
		// The original body is its own string so existing translations still apply.
		return '{% if needs_payment_method %}' . wp_kses_post( __( '<p>Thank you for your membership to {{ sitename }}.</p>

<p>Your {{ membership_level_name }} membership is scheduled to renew on {{ renewaldate }}, but we don\'t have a payment method on file.</p>

<p><strong>To keep your membership active, please add your payment information before {{ renewaldate }}.</strong> If we don\'t have a payment method on file by then, your membership will be cancelled.</p>

<p>Update your billing information here: {{ billing_update_url }}</p>

<p>Account: {{ display_name }} ({{ user_email }})</p>

<p>If for some reason you do not want to renew your membership you can cancel here: {{ cancel_url }}</p>', 'paid-memberships-pro' ) ) . '{% else %}' . wp_kses_post( __( '<p>Thank you for your membership to {{ sitename }}.</p>

<p>This is just a reminder that your {{ membership_level_name }} membership will automatically renew on {{ renewaldate }}.</p>

<p>Account: {{ display_name }} ({{ user_email }})</p>

<p>If for some reason you do not want to renew your membership you can cancel here: {{ cancel_url }}</p>', 'paid-memberships-pro' ) ) . '{% endif %}';
	}

	/**
	 * Get the email address to send the email to.
	 *
	 * @since 3.4
	 *
	 * @return string The email address to send the email to.
	 */
	public function get_recipient_email() {
		$user = get_userdata( $this->subscription_obj->get_user_id() );
		return $user->user_email;
	}

	/**
	 * Get the name of the email recipient.
	 *
	 * @since 3.4
	 *
	 * @return string The name of the email recipient.
	 */
	public function get_recipient_name() {
		$user = get_userdata( $this->subscription_obj->get_user_id() );
		return $user->display_name;
	}


	/**
	 * Get the email template variables for the email paired with a description of the variable.
	 *
	 * @since 3.4
	 *
	 * @return array The email template variables for the email (key => value pairs).
	 */
	public static function get_email_template_variables_with_description() {
		return array(
			'{{ display_name }}' => __( 'The display name of the user.', 'paid-memberships-pro' ),
			'{{ user_login }}' => __( 'The username of the user.', 'paid-memberships-pro' ),
			'{{ user_email }}' => __( 'The email address of the user.', 'paid-memberships-pro' ),
			'{{ membership_id }}' => __( 'The ID of the membership level.', 'paid-memberships-pro' ),
			'{{ level_group_id }}' => __( 'The ID of the level group that the membership level belongs to.', 'paid-memberships-pro' ),
			'{{ membership_level_name }}' => __( 'The name of the membership level.', 'paid-memberships-pro' ),
			'{{ membership_cost }}' => __( 'The cost of the membership level.', 'paid-memberships-pro' ),
			'{{ billing_amount }}' => __( 'The amount billed for the subscription.', 'paid-memberships-pro' ),
			'{{ renewaldate }}' => __( 'The date of the next payment.', 'paid-memberships-pro' ),
			'{{ cancel_url }}' => __( 'The link to cancel the subscription.', 'paid-memberships-pro' ),
			'{{ billing_update_url }}' => __( 'The URL where the member can update billing information for the subscription.', 'paid-memberships-pro' ),
			'{{ needs_payment_method }}' => __( 'Whether the subscription was moved to Stripe by the deprecated gateway migration and still has no payment method. Use it in a conditional, for example: {% if needs_payment_method %}...{% endif %}', 'paid-memberships-pro' ),
		);
	}

	/**
	 * Get the email template variables for the email.
	 *
	 * @since 3.4
	 *
	 * @return array The email template variables for the email (key => value pairs).
	 */
	public function get_email_template_variables() {
		$subscription_obj = $this->subscription_obj;
		$membership_id = $subscription_obj->get_membership_level_id();		
		$membership_level = pmpro_getLevel( $membership_id );
		$user = get_userdata( $subscription_obj->get_user_id() );
		$billing_update_url = pmpro_url( 'billing', empty( $subscription_obj->get_id() ) ? '' : 'pmpro_subscription_id=' . (int) $subscription_obj->get_id(), 'https' );
		if ( empty( $billing_update_url ) ) {
			$billing_update_url = pmpro_login_url();
		}

		return array(
			'name' => $user->display_name,
			'display_name' => $user->display_name,
			'user_login' => $user->user_login,
			'user_email' => $user->user_email,
			'membership_id' => $membership_id,
			'level_group_id' => pmpro_get_group_id_for_level( $membership_id ) ?: 0,
			'membership_level_name' => $membership_level->name,
			'membership_cost' => $subscription_obj->get_cost_text(),
			'billing_amount' =>  pmpro_formatPrice( $subscription_obj->get_billing_amount() ),
			'renewaldate' => date_i18n( get_option( 'date_format' ), $subscription_obj->get_next_payment_date() ),
			'cancel_link' => wp_login_url( pmpro_url( 'cancel' ) ),
			'cancel_url' => wp_login_url( pmpro_url( 'cancel' ) ),
			'billing_update_url' => $billing_update_url,
			// Uses the stored flag; pmpro_deprecated_gateway_recurring_payment_reminder() refreshes it before the reminder is sent.
			'needs_payment_method' => pmpro_deprecated_gateway_subscription_needs_payment_method( $subscription_obj, false ),
		);
	}

	/**
	 * Returns the arguments to send the test email from the abstract class.
	 *
	 * @since 3.5
	 *
	 * @return array The arguments to send the test email from the abstract class.
	 */
	public static function get_test_email_constructor_args() {
		global $current_user;
		$test_user = $current_user;
		$all_levels = pmpro_getAllLevels( true );
		$test_user->membership_level = array_pop( $all_levels );
		$test_subscription = new PMPro_Subscription( array( 'user_id' => $test_user->ID, 'membership_level_id' => $test_user->membership_level->id, 'next_payment_date' => date( 'Y-m-d', strtotime( '+1 month' )  ) )  );
		return array( $test_subscription );
	}
}

/**
 * Register the email template.
 *
 * @since 3.4
 *
 * @param array $email_templates The email templates (template slug => email template class name)
 * @return array The modified email templates array.
 */
function pmpro_email_templates_membership_recurring( $email_templates ) {
	$email_templates['membership_recurring'] = 'PMPro_Email_Template_Membership_Recurring';
	return $email_templates;
}
add_filter( 'pmpro_email_templates', 'pmpro_email_templates_membership_recurring' );