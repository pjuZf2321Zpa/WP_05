<?php return array (
  'root' => 
  array (
    'name' => 'learndash/notifications',
    'pretty_version' => 'dev-main',
    'version' => 'dev-main',
    'reference' => '0d4d1dd226c2d4aa790129163ba009b5598e361e',
    'type' => 'wordpress-plugin',
    'install_path' => __DIR__ . '/../',
    'aliases' => 
    array (
    ),
    'dev' => false,
  ),
  'versions' => 
  array (
    'stellarwp/arrays' => 
    array (
      'pretty_version' => '1.3.2',
      'version' => '1.3.2.0',
      'reference' => 'e994abcdb5d76fb5fdea7f2e1549d0603c13f91e',
      'type' => 'library',
      'install_path' => __DIR__ . '/../stellarwp/arrays',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'stellarwp/templates' => 
    array (
      'pretty_version' => '1.0.1',
      'version' => '1.0.1.0',
      'reference' => '0e7444a08d810bb3cdbc44767e446ab04ff95e3f',
      'type' => 'library',
      'install_path' => __DIR__ . '/../stellarwp/templates',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
  ),
);