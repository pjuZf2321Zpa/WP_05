=== Share-One-Drive ===
Requires at least: 5.8 
Tested up to: 7.1
Requires PHP: 8.0

Share-one-Drive is the #1 Ultimate OneDrive & SharePoint plugin for WordPress plugin on the market and part of a series of Cloud Plugins already powering 5.000+ company websites improving their workflow. Join now and start using your OneDrive even more efficiently by integrating it into your website!

== Description ==
Share-one-Drive is the #1 Ultimate OneDrive & SharePoint plugin for WordPress plugin on the market and part of a series of Cloud Plugins.

This plugin will help you to easily integrate OneDrive Personal, OneDrive Business and SharePoint Libraries into your WordPress website or blog. Share-one-Drive allows you to view, download, delete, rename files & folders stored in the cloud directly from a WordPress page. You can use Share-one-Drive as a File browser, Gallery, Audio- or Video-Player!

== Changelog ==
You can find the changelog in the [Documentation](https://documentation.wpcloudplugins.com/other/changelog).

== Upgrade Notice ==

If you have multiple WP Cloud Plugins on your site, please make sure they are all updated to avoid compatibility issues.