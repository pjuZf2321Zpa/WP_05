<?php
/**
 * Divi 5 bootstrap.
 */

namespace TheLion\Integrations\Divi\D5;

defined('ABSPATH') || exit;

final class Bootstrap
{
    private static string $path = '';

    private static string $url = '';

    private static bool $booted = false;

    /**
     * Register hooks. Runs once per request.
     */
    public static function init(): void
    {
        if (self::$booted) {
            return;
        }

        self::$booted = true;
        self::$path = WPCP_DIVI_EXTENSION_PATH.'divi-5/';
        self::$url = WPCP_DIVI_EXTENSION_URL.'divi-5/';

        self::register_autoloader();

        Conversion::init();

        // Only fires if this file loaded before Divi built its dependency tree.
        add_action('divi_module_library_modules_dependency_tree', [Modules::class, 'register']);

        // The reliable path: the plugin's integration loader runs on `init` priority 9,
        // by which time the action above has already fired.
        if (doing_action('init') || !did_action('init')) {
            add_action('init', [Modules::class, 'register_modules'], 20);
        } else {
            Modules::register_modules();
        }

        add_action('divi_visual_builder_assets_before_enqueue_scripts', [Assets::class, 'enqueue']);
    }

    /**
     * Absolute path inside the divi-5 directory.
     */
    public static function path(string $relative = ''): string
    {
        return self::$path.ltrim($relative, '/');
    }

    /**
     * Public URL inside the divi-5 directory.
     */
    public static function url(string $relative = ''): string
    {
        return self::$url.ltrim($relative, '/');
    }

    /**
     * Diagnostic line, written only when `WPCP_DIVI_DEBUG` is enabled in wp-config.php.
     */
    public static function log(string $message): void
    {
        if (!defined('WPCP_DIVI_DEBUG') || !WPCP_DIVI_DEBUG) {
            return;
        }

        error_log(sprintf('[wpcp-divi][pid:%d] %s', getmypid(), $message));
    }

    /**
     * Register the autoloader for this namespace.
     */
    private static function register_autoloader(): void
    {

        spl_autoload_register(static function (string $class): void {
            $prefix = __NAMESPACE__.'\\';

            if (0 !== strncmp($prefix, $class, \strlen($prefix))) {
                return;
            }

            $file = self::$path.'server/'.str_replace('\\', '/', substr($class, \strlen($prefix))).'.php';

            if (file_exists($file)) {
                require_once $file;
            }
        });
    }
}

Bootstrap::init();
