<?php
/**
 * Divi 5 module for the LetsBox plugin.
 */

namespace TheLion\Integrations\Divi\D5\Modules;

defined('ABSPATH') || exit;

final class LetsBox extends AbstractShortcodeModule
{
    protected const SLUG = 'letsbox';
    protected const D4_SHORTCODE = 'wpcp_letsbox';
}
