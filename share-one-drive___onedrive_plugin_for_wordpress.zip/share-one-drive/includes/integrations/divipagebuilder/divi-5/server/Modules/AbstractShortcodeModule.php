<?php
/**
 * Shared frontend renderer for the WP Cloud Plugins Divi 5 modules.
 */

namespace TheLion\Integrations\Divi\D5\Modules;

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Options\Element\ElementClassnames;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use TheLion\Integrations\Divi\D5\Bootstrap;
use TheLion\Integrations\Divi\D5\Conversion;

defined('ABSPATH') || exit;

/**
 * Every module holds a WP Cloud Plugins shortcode and renders it, so subclasses only
 * declare their slug and Divi 4 shortcode tag.
 */
abstract class AbstractShortcodeModule implements DependencyInterface
{
    /**
     * Module slug. Matches the metadata folder and the `module.json` name.
     */
    protected const SLUG = '';

    /**
     * Divi 4 shortcode tag, reused as the CSS class so Divi 4 styling keeps matching.
     */
    protected const D4_SHORTCODE = '';

    /**
     * Slugs already registered, shared across subclasses.
     *
     * @var array<string, bool>
     */
    private static array $registered = [];

    public function load(): void
    {
        add_action('init', [static::class, 'register_module']);
    }

    /**
     * Hand the module metadata to Divi. The same files drive the builder and the
     * frontend.
     */
    public static function register_module(): void
    {
        if (isset(self::$registered[static::SLUG]) || !class_exists(ModuleRegistration::class)) {
            return;
        }

        $json = Bootstrap::path('modules/'.static::SLUG.'/module.json');

        if (!is_readable($json)) {
            Bootstrap::log(sprintf('MISSING module.json for %s at %s', static::SLUG, $json));
            return; // don't mark as registered
        }

        self::$registered[static::SLUG] = true;

        // Divi concatenates this folder with `module.json` and `conversion-outline.json`
        // without inserting a separator, so the trailing slash is required.
        ModuleRegistration::register_module(
            trailingslashit(Bootstrap::path('modules/'.static::SLUG)),
            ['render_callback' => [static::class, 'render_callback']]
        );

        Bootstrap::log(sprintf(
            'Registered Divi 5 module %s (slug %s, shortcode %s)',
            static::class,
            static::SLUG,
            static::D4_SHORTCODE
        ));
    }

    /**
     * Render the module on the frontend.
     *
     * @param array<string, mixed> $attrs    module attributes
     * @param string               $content  unused
     * @param object               $block    parsed block
     * @param object               $elements elements API
     */
    public static function render_callback($attrs, $content, $block, $elements): string
    {
        Bootstrap::log(sprintf(
            'Rendering Divi 5 module %s (slug %s, shortcode %s)',
            static::class,
            static::SLUG,
            static::D4_SHORTCODE
        ));

        $shortcode = Conversion::decode_shortcode($attrs['content']['innerContent']['desktop']['value'] ?? '');

        $inner = '' === $shortcode
            ? sprintf(
                '<p class="wpcp-module-notice">%s</p>',
                esc_html__('This WP Cloud Plugins module is not configured yet.', 'wpcloudplugins')
            )
            : trim((string) do_shortcode($shortcode));

        return Module::render(
            [
                'orderIndex' => $block->parsed_block['orderIndex'],
                'storeInstance' => $block->parsed_block['storeInstance'],
                'attrs' => $attrs,
                'elements' => $elements,
                'id' => $block->parsed_block['id'],
                'name' => $block->block_type->name,
                'moduleCategory' => $block->block_type->category,
                'moduleClassName' => static::D4_SHORTCODE,
                'classnamesFunction' => [static::class, 'module_classnames'],
                'stylesComponent' => [static::class, 'module_styles'],
                'scriptDataComponent' => [static::class, 'module_script_data'],
                'children' => $elements->style_components(['attrName' => 'module']).$inner,
            ]
        );
    }

    /**
     * @param array<string, mixed> $args
     */
    public static function module_classnames($args): void
    {
        $args['classnamesInstance']->add(
            ElementClassnames::classnames(['attrs' => $args['attrs']['module']['decoration'] ?? []])
        );
    }

    /**
     * @param array<string, mixed> $args
     */
    public static function module_styles($args): void
    {
        Style::add(
            [
                'id' => $args['id'],
                'name' => $args['name'],
                'orderIndex' => $args['orderIndex'],
                'storeInstance' => $args['storeInstance'],
                'styles' => [
                    $args['elements']->style(
                        [
                            'attrName' => 'module',
                            'styleProps' => [
                                'disabledOn' => [
                                    'disabledModuleVisibility' => $args['settings']['disabledModuleVisibility'] ?? null,
                                ],
                            ],
                        ]
                    ),
                ],
            ]
        );
    }

    /**
     * @param array<string, mixed> $args
     */
    public static function module_script_data($args): void
    {
        $args['elements']->script_data(['attrName' => 'module']);
    }
}
