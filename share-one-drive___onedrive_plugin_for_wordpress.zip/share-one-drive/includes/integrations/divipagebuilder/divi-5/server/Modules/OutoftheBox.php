<?php
/**
 * Divi 5 module for the OutoftheBox plugin.
 */

namespace TheLion\Integrations\Divi\D5\Modules;

defined('ABSPATH') || exit;

final class OutoftheBox extends AbstractShortcodeModule
{
    protected const SLUG = 'outofthebox';
    protected const D4_SHORTCODE = 'wpcp_outofthebox';
}
