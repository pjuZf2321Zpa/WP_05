/**
 * WP Cloud Plugins - PDF Viewer Widget
 * Generic PDF.js viewer for all WP Cloud Plugins
 *
 * Features:
 * - Continuous scroll with lazy loading
 * - Text selection & copying
 * - Zoom controls (in/out/fit, Ctrl+Scroll)
 * - Keyboard navigation (arrows, PageUp/Down, +/-/0)
 * - HiDPI/Retina display support
 * - Loading states & error handling
 * - Canvas rendering with range request support
 *
 * Based on PDF.js library v5.4.530+
 * @see https://github.com/mozilla/pdf.js
 */

(function ($, window) {
    'use strict';

    // Initialize PDF.js worker only once
    var pdfWorkerInitialized = false;
    var pdfLibraryLoading = false;
    var pdfLibraryCallbacks = [];

    $.widget('wpcp.WPCPPDFViewer', {
        options: {
            pdfUrl: null,
            container: null,
            listtoken: null,
            theme: 'light',
            vendorPath: null,
            canPrint: false,
            minZoom: 0.1,
            maxZoom: 3,
        },

        // Widget state
        pdf: null,
        numPages: null,
        currentPage: 1,
        scale: null, // null = auto-fit mode
        containerHeight: 0,
        containerWidth: 0,
        pageHeight: 0,
        pageWidth: 0,
        canvasContainer: null,
        renderedPages: {}, // Track which pages have been rendered (for lazy loading)
        renderTasks: {}, // Track active render tasks per page
        isLoading: true,
        isRendering: false,
        wheelZoomTimeout: null, // Throttle wheel zoom events
        scrollRafId: null,
        searchQuery: '',
        searchResults: [],
        currentSearchResult: -1,
        searchTimeout: null,
        isDestroyed: false,
        resizeObserver: null,
        activePointers: {},
        pinchActive: false,
        pinchStartDistance: 0,
        pinchStartScale: null,
        pinchLastAppliedScale: null,
        pinchRafId: null,
        pendingPinchScale: null,
        pendingPinchCenter: null,
        originalTouchAction: null,
        pinchPreviewScale: null,

        _create: function () {
            var self = this;

            // Build UI structure
            self._buildUI();

            // Track container size for responsive scaling
            self._initResizeHandler();

            // Load the PDF document
            self._loadPDF();
        },

        _buildUI: function () {
            var self = this;

            // Main container
            self.element.addClass('wpcp-pdf-viewer-wrapper');

            // Canvas container - will hold multiple canvas elements
            var $canvasContainer = $('<div class="wpcp-pdf-canvas-container"></div>');
            self.canvasContainer = $canvasContainer[0];
            self.element.append($canvasContainer);

            // Loading indicator
            var $loading = $('<div class="wpcp-pdf-loading"><i class="eva eva-loader-outline eva-spin"></i></div>');
            self.element.append($loading);

            // Error container
            var $error = $('<div class="wpcp-pdf-error" style="display:none;"></div>');
            $error.append('<i class="eva eva-alert-triangle wpcp-pdf-error-icon"></i>');
            $error.append('<p class="wpcp-pdf-error-title">Failed to load PDF</p>');
            $error.append('<p class="wpcp-pdf-error-message"></p>');
            self.element.append($error);

            // Controls bar (bottom)
            var $controls = $('<div class="wpcp-pdf-controls" style="display:none;"></div>');
            var $controlsInner = $('<div class="wpcp-pdf-controls-inner"></div>');

            // Previous button
            $controlsInner.append(
                '<button class="wpcp-pdf-btn wpcp-pdf-prev" title="Previous page" disabled>' +
                    '<i class="eva eva-arrow-back"></i>' +
                    '</button>',
            );

            // Page info
            $controlsInner.append(
                '<div class="wpcp-pdf-page-info">' +
                    '<span class="wpcp-pdf-page-current">1</span>' +
                    '<span class="wpcp-pdf-page-total-wrapper"> / <span class="wpcp-pdf-page-total">1</span></span>' +
                    '</div>',
            );

            // Next button
            $controlsInner.append(
                '<button class="wpcp-pdf-btn wpcp-pdf-next" title="Next page" disabled>' +
                    '<i class="eva eva-arrow-forward"></i>' +
                    '</button>',
            );

            // Divider
            $controlsInner.append('<div class="wpcp-pdf-divider"></div>');

            // Zoom out
            $controlsInner.append(
                '<button class="wpcp-pdf-btn wpcp-pdf-zoom-out" title="Zoom out">' +
                    '<i class="eva eva-minus"></i>' +
                    '</button>',
            );

            // Zoom level
            $controlsInner.append('<span class="wpcp-pdf-zoom-level"></span>');

            // Zoom in
            $controlsInner.append(
                '<button class="wpcp-pdf-btn wpcp-pdf-zoom-in" title="Zoom in">' +
                    '<i class="eva eva-plus"></i>' +
                    '</button>',
            );

            // Divider
            $controlsInner.append('<div class="wpcp-pdf-divider"></div>');

            // Fit to page button
            $controlsInner.append(
                '<button class="wpcp-pdf-btn wpcp-pdf-fit active" title="Fit to page">' +
                    '<i class="eva eva-expand"></i>' +
                    '</button>',
            );

            // Divider
            $controlsInner.append('<div class="wpcp-pdf-divider"></div>');

            // Search button
            $controlsInner.append(
                '<button class="wpcp-pdf-btn wpcp-pdf-search" title="Search in PDF">' +
                    '<i class="eva eva-search"></i>' +
                    '</button>',
            );

            // Print button (only if canPrint is enabled)
            if (self.options.canPrint) {
                $controlsInner.append(
                    '<button class="wpcp-pdf-btn wpcp-pdf-print" title="Print PDF">' +
                        '<i class="eva eva-printer"></i>' +
                        '</button>',
                );
            }

            $controls.append($controlsInner);
            self.element.append($controls);

            // Search panel (hidden by default)
            var $searchPanel = $('<div class="wpcp-pdf-search-panel" style="display:none;"></div>');
            var $searchInner = $('<div class="wpcp-pdf-search-inner"></div>');

            // Search input
            $searchInner.append(
                '<input name="pdf-search" type="text" class="wpcp-pdf-search-input" placeholder="..." />' +
                    '<button class="wpcp-pdf-search-prev" title="Previous result" disabled>' +
                    '<i class="eva eva-arrow-up"></i>' +
                    '</button>' +
                    '<button class="wpcp-pdf-search-next" title="Next result" disabled>' +
                    '<i class="eva eva-arrow-down"></i>' +
                    '</button>' +
                    '<span class="wpcp-pdf-search-count"></span>' +
                    '<button class="wpcp-pdf-search-close" title="Close search">' +
                    '<i class="eva eva-close"></i>' +
                    '</button>',
            );

            $searchPanel.append($searchInner);
            self.element.append($searchPanel);

            // Initialize event handlers
            self._initEventHandlers();
        },

        _initEventHandlers: function () {
            var self = this;

            // Navigation buttons
            self.element.find('.wpcp-pdf-prev').on('click', function () {
                self._scrollToPage(self.currentPage - 1);
            });

            self.element.find('.wpcp-pdf-next').on('click', function () {
                self._scrollToPage(self.currentPage + 1);
            });

            // Zoom buttons
            self.element.find('.wpcp-pdf-zoom-in').on('click', function () {
                self._zoomIn();
            });

            self.element.find('.wpcp-pdf-zoom-out').on('click', function () {
                self._zoomOut();
            });

            self.element.find('.wpcp-pdf-fit').on('click', function () {
                self._fitToPage();
            });

            // Search button
            self.element.find('.wpcp-pdf-search').on('click', function () {
                self._toggleSearch();
            });

            // Print button
            self.element.find('.wpcp-pdf-print').on('click', function () {
                self._printPDF();
            });

            // Search input with debounce
            self.element.find('.wpcp-pdf-search-input').on('input', function () {
                clearTimeout(self.searchTimeout);
                self.searchTimeout = setTimeout(function () {
                    self._performSearch(self.element.find('.wpcp-pdf-search-input').val());
                }, 300);
            });

            // Search input - Enter key to go to next result
            self.element.find('.wpcp-pdf-search-input').on('keydown', function (e) {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    if (e.shiftKey) {
                        self._goToPrevSearchResult();
                    } else {
                        self._goToNextSearchResult();
                    }
                } else if (e.key === 'Escape') {
                    self._toggleSearch();
                }
            });

            // Search navigation buttons
            self.element.find('.wpcp-pdf-search-prev').on('click', function () {
                self._goToPrevSearchResult();
            });

            self.element.find('.wpcp-pdf-search-next').on('click', function () {
                self._goToNextSearchResult();
            });

            // Search close button
            self.element.find('.wpcp-pdf-search-close').on('click', function () {
                self._toggleSearch();
            });

            // Scroll detection to update current page and lazy load
            var scrollTimeout;
            $(self.canvasContainer).on('scroll', function () {
                self._updateCurrentPageFromScroll();

                // Throttle lazy loading with rAF + debounce
                clearTimeout(scrollTimeout);
                scrollTimeout = setTimeout(function () {
                    if (self.scrollRafId) {
                        return;
                    }
                    self.scrollRafId = requestAnimationFrame(function () {
                        self.scrollRafId = null;
                        self._renderVisiblePages();
                    });
                }, 120);
            });

            // Ctrl+Scroll to zoom (like most PDF viewers) - throttled
            $(self.canvasContainer).on('wheel', function (e) {
                // Check if Ctrl (Windows/Linux) or Cmd (Mac) is pressed
                if (e.ctrlKey || e.metaKey) {
                    e.preventDefault();

                    // Throttle to prevent too many zoom events
                    if (self.wheelZoomTimeout) {
                        return;
                    }

                    self.wheelZoomTimeout = setTimeout(function () {
                        self.wheelZoomTimeout = null;
                    }, 150);

                    // Negative deltaY = scroll up = zoom in
                    // Positive deltaY = scroll down = zoom out
                    if (e.originalEvent.deltaY < 0) {
                        self._zoomIn(0.1);
                    } else {
                        self._zoomOut(0.1);
                    }
                }
            });

            // Keyboard navigation
            self._initKeyboardNavigation();

            // Touch pinch zoom
            self._initTouchZoom();
        },

        _initTouchZoom: function () {
            var self = this;
            var $container = $(self.canvasContainer);

            if (!self.originalTouchAction) {
                self.originalTouchAction = $container.css('touch-action') || '';
            }

            // Allow normal pan by default; switch to none during pinch
            $container.css('touch-action', 'pan-x pan-y');

            $container.on('pointerdown.pdfviewer-touch-' + self.options.listtoken, function (e) {
                if (e.pointerType && e.pointerType !== 'touch') {
                    return;
                }

                self.activePointers[e.pointerId] = { x: e.clientX, y: e.clientY };

                if (Object.keys(self.activePointers).length === 2) {
                    self._startPinch();
                }
            });

            $container.on('pointermove.pdfviewer-touch-' + self.options.listtoken, function (e) {
                if (!self.activePointers[e.pointerId]) {
                    return;
                }

                self.activePointers[e.pointerId] = { x: e.clientX, y: e.clientY };

                if (self.pinchActive) {
                    e.preventDefault();
                    self._queuePinchZoom();
                }
            });

            $container.on('pointerup.pdfviewer-touch-' + self.options.listtoken, function (e) {
                delete self.activePointers[e.pointerId];
                self._endPinchIfNeeded();
            });

            $container.on('pointercancel.pdfviewer-touch-' + self.options.listtoken, function (e) {
                delete self.activePointers[e.pointerId];
                self._endPinchIfNeeded();
            });
        },

        _startPinch: function () {
            var self = this;
            var points = Object.values(self.activePointers);
            if (points.length !== 2) {
                return;
            }

            self.pinchActive = true;
            self.pinchStartDistance = self._getPinchDistance(points[0], points[1]);
            self.pinchStartScale = self.scale !== null ? self.scale : self._calculateFitScale();
            self.pinchLastAppliedScale = self.pinchStartScale;
            self.pinchPreviewScale = self.pinchStartScale;

            $(self.canvasContainer)
                .addClass('pinch-zoom-active')
                .css('touch-action', 'none');
        },

        _queuePinchZoom: function () {
            var self = this;
            var points = Object.values(self.activePointers);
            if (points.length !== 2 || !self.pinchActive) {
                return;
            }

            var distance = self._getPinchDistance(points[0], points[1]);
            if (!self.pinchStartDistance) {
                return;
            }

            var scaleFactor = distance / self.pinchStartDistance;
            var targetScale = self.pinchStartScale * scaleFactor;
            targetScale = Math.max(self.options.minZoom, Math.min(targetScale, self.options.maxZoom));

            var center = self._getPinchCenter(points[0], points[1]);
            var containerOffset = $(self.canvasContainer).offset() || { left: 0, top: 0 };
            var centerInContainer = {
                x: center.x - containerOffset.left,
                y: center.y - containerOffset.top,
            };

            self.pendingPinchScale = targetScale;
            self.pendingPinchCenter = centerInContainer;

            if (self.pinchRafId) {
                return;
            }

            self.pinchRafId = requestAnimationFrame(function () {
                self.pinchRafId = null;
                if (!self.pinchActive || self.pendingPinchScale === null) {
                    return;
                }

                if (Math.abs(self.pendingPinchScale - self.pinchLastAppliedScale) < 0.05) {
                    return;
                }

                self.pinchLastAppliedScale = self.pendingPinchScale;
                self._applyPinchPreview(self.pendingPinchScale, self.pendingPinchCenter);
            });
        },

        _endPinchIfNeeded: function () {
            var self = this;
            if (Object.keys(self.activePointers).length < 2) {
                var finalScale = self.pendingPinchScale;
                var finalCenter = self.pendingPinchCenter;

                self.pinchActive = false;
                self.pinchStartDistance = 0;
                self.pinchStartScale = null;
                self.pendingPinchScale = null;
                self.pendingPinchCenter = null;
                self.pinchPreviewScale = null;

                $(self.canvasContainer)
                    .removeClass('pinch-zoom-active')
                    .css({
                        'touch-action': 'pan-x pan-y',
                        'transform': '',
                        'transform-origin': ''
                    });

                if (finalScale) {
                    self._applyScale(finalScale, finalCenter);
                }
            }
        },

        _getPinchDistance: function (p1, p2) {
            var dx = p1.x - p2.x;
            var dy = p1.y - p2.y;
            return Math.sqrt(dx * dx + dy * dy);
        },

        _getPinchCenter: function (p1, p2) {
            return {
                x: (p1.x + p2.x) / 2,
                y: (p1.y + p2.y) / 2,
            };
        },

        _applyPinchPreview: function (targetScale, center) {
            var self = this;
            var baseScale = self.pinchStartScale || (self.scale !== null ? self.scale : self._calculateFitScale());
            var previewScale = targetScale / baseScale;

            self.pinchPreviewScale = targetScale;

            var origin = (center ? center.x + 'px ' + center.y + 'px' : '50% 50%');
            $(self.canvasContainer).css({
                'transform-origin': origin,
                'transform': 'scale(' + previewScale + ')'
            });

            // Update zoom level display without forcing a re-render
            self.element.find('.wpcp-pdf-zoom-level').text(Math.round(targetScale * 100) + '%');
        },

        _initKeyboardNavigation: function () {
            var self = this;

            $(document).on('keydown.pdfviewer-' + self.options.listtoken, function (e) {
                // Only handle if this viewer is visible
                if (!self.element.is(':visible')) {
                    return;
                }

                // Only handle if focus is within this viewer
                var activeEl = document.activeElement;
                if (activeEl && !$.contains(self.element[0], activeEl)) {
                    return;
                }

                switch (e.key) {
                    case 'ArrowLeft':
                    case 'PageUp':
                        e.preventDefault();
                        self._scrollToPage(self.currentPage - 1);
                        break;
                    case 'ArrowRight':
                    case 'PageDown':
                        e.preventDefault();
                        self._scrollToPage(self.currentPage + 1);
                        break;
                    case '+':
                    case '=':
                        e.preventDefault();
                        self._zoomIn();
                        break;
                    case '-':
                        e.preventDefault();
                        self._zoomOut();
                        break;
                    case '0':
                        e.preventDefault();
                        self._fitToPage();
                        break;
                }
            });
        },

        _initResizeHandler: function () {
            var self = this;
            var resizeTimeout;

            var onResize = function () {
                clearTimeout(resizeTimeout);
                resizeTimeout = setTimeout(function () {
                    var prevWidth = self.containerWidth;
                    var prevHeight = self.containerHeight;
                    self._updateContainerSize();

                    // Only re-render in fit mode when the size actually changed meaningfully
                    if (
                        self.scale === null &&
                        self.pdf &&
                        (Math.abs(self.containerWidth - prevWidth) > 2 ||
                            Math.abs(self.containerHeight - prevHeight) > 2)
                    ) {
                        self.renderedPages = {};
                        self._renderAllPages();
                    }
                }, 250);
            };

            // ResizeObserver detects container size changes caused by the lightbox
            // opening/animating — window resize does not fire in that case
            if (typeof ResizeObserver !== 'undefined') {
                self.resizeObserver = new ResizeObserver(onResize);
                self.resizeObserver.observe(self.element[0]);
            }

            // Keep window resize as fallback (older browsers, embedded iframes, etc.)
            $(window).on('resize.pdfviewer-' + self.options.listtoken, onResize);

            // Initial size
            self._updateContainerSize();
        },

        _updateContainerSize: function () {
            var self = this;
            var $container = self.element.find('.wpcp-pdf-canvas-container');
            self.containerHeight = $container.height();
            self.containerWidth = $container.width();
        },

        _loadPDF: function () {
            var self = this;

            if (!self.options.pdfUrl) {
                self._showError('No PDF URL provided');
                return;
            }

            // Validate PDF URL - only allow HTTP and HTTPS protocols
            try {
                var url = new URL(self.options.pdfUrl, window.location.href);
                if (url.protocol !== 'http:' && url.protocol !== 'https:') {
                    self._showError('Invalid PDF URL: Only HTTP and HTTPS protocols are allowed');
                    console.error('Blocked PDF URL with invalid protocol:', url.protocol);
                    return;
                }
            } catch (e) {
                self._showError('Invalid PDF URL format');
                console.error('PDF URL validation error:', e);
                return;
            }

            // Show loading indicator
            self.element.find('.wpcp-pdf-loading').show();
            self.element.find('.wpcp-pdf-error').hide();

            // Check if PDF.js is already loaded
            if (typeof pdfjsLib === 'undefined') {
                // Dynamically load PDF.js library first
                self._loadPDFJSLibrary(function(success) {
                    if (success) {
                        self._initializePDF();
                    } else {
                        self._showError('Failed to load PDF.js library');
                    }
                });
            } else {
                // PDF.js already loaded, proceed directly
                self._initializePDF();
            }
        },

        _loadPDFJSLibrary: function (callback) {
            var self = this;

            if (!self.options.vendorPath) {
                console.error('PDF.js vendor path not provided');
                callback(false);
                return;
            }

            // If library is already loading, queue this callback
            if (pdfLibraryLoading) {
                pdfLibraryCallbacks.push(callback);
                return;
            }

            // If library is already loaded, call callback immediately
            if (typeof pdfjsLib !== 'undefined' && pdfWorkerInitialized) {
                callback(true);
                return;
            }

            // Start loading
            pdfLibraryLoading = true;
            pdfLibraryCallbacks.push(callback);

            // Ensure vendorPath ends with /
            var vendorPath = self.options.vendorPath;
            if (vendorPath.substr(-1) !== '/') {
                vendorPath += '/';
            }

            var mainLibPath = vendorPath + 'pdf.js';
            var workerPath = vendorPath + 'pdf.worker.js';

            // Load main PDF.js library
            var script = document.createElement('script');
            script.src = mainLibPath;
            script.type = 'module';
            script.async = true;

            script.onload = function () {
                // Configure worker after main library loads
                if (typeof pdfjsLib !== 'undefined') {
                    pdfjsLib.GlobalWorkerOptions.workerSrc = workerPath;
                    pdfWorkerInitialized = true;
                    pdfLibraryLoading = false;
                    
                    // Call all queued callbacks
                    var callbacks = pdfLibraryCallbacks.slice();
                    pdfLibraryCallbacks = [];
                    callbacks.forEach(function(cb) {
                        cb(true);
                    });
                } else {
                    console.error('PDF.js library loaded but pdfjsLib not available');
                    pdfLibraryLoading = false;
                    
                    // Call all queued callbacks with error
                    var callbacks = pdfLibraryCallbacks.slice();
                    pdfLibraryCallbacks = [];
                    callbacks.forEach(function(cb) {
                        cb(false);
                    });
                }
            };

            script.onerror = function () {
                console.error('Failed to load PDF.js library from:', mainLibPath);
                pdfLibraryLoading = false;
                
                // Call all queued callbacks with error
                var callbacks = pdfLibraryCallbacks.slice();
                pdfLibraryCallbacks = [];
                callbacks.forEach(function(cb) {
                    cb(false);
                });
            };

            document.head.appendChild(script);
        },

        _initializePDF: function () {
            var self = this;

            var vendorPath = self.options.vendorPath;
            if (vendorPath.substr(-1) !== '/') {
                vendorPath += '/';
            }

            // Load PDF document (loading indicator already shown in _loadPDF)
            var loadingTask = pdfjsLib.getDocument({
                url: self.options.pdfUrl,
                wasmUrl: vendorPath + 'wasm/',
                cMapUrl: vendorPath + 'cmaps/',
                cMapPacked: true,
                standardFontDataUrl: vendorPath + 'standard_fonts/',                
                withCredentials: false,
                rangeChunkSize: 65536, // Enable range requests
                disableAutoFetch: false,
                disableStream: false,
                disableRange: false,
            });

            self.loadingTask = loadingTask;

            loadingTask.promise
                .then(function (pdf) {
                    self.pdf = pdf;
                    self.numPages = pdf.numPages;
                    self.isLoading = false;

                    // Hide loading, show controls
                    self.element.find('.wpcp-pdf-loading').hide();
                    self.element.find('.wpcp-pdf-controls').show();

                    // Update UI
                    self.element.find('.wpcp-pdf-page-total').text(self.numPages);
                    self._updateButtons();

                    // Render all pages
                    self._renderAllPages();
                })
                .catch(function (error) {
                    console.error('PDF.js load error:', error);
                    self._showError(error.message || 'Failed to load PDF');
                });
        },

        _renderAllPages: function () {
            var self = this;

            // Remeasure before every render pass so we never work with stale dimensions
            self._updateContainerSize();

            // Clear existing wrappers and reset state
            $(self.canvasContainer)
                .find('.wpcp-pdf-page-wrapper')
                .each(function () {
                    $(this).find('canvas').remove();
                    $(this).find('.textLayer').remove();
                });
            $(self.canvasContainer).empty();
            self.renderedPages = {};

            // Create lightweight placeholder wrappers for all pages
            // Canvas elements will be created on-demand during rendering
            for (var i = 1; i <= self.numPages; i++) {
                var $pageWrapper = $('<div class="wpcp-pdf-page-wrapper" data-page="' + i + '"></div>');

                // Create placeholder with loading spinner
                var estimatedScale = self.scale !== null ? self.scale : self._calculateFitScale();
                var estimatedHeight = self.pageHeight ? self.pageHeight * estimatedScale : 800;
                var estimatedWidth = self.pageWidth ? self.pageWidth * estimatedScale : 600;

                var $placeholder = $('<div class="wpcp-pdf-placeholder"></div>');
                $placeholder.css({
                    'min-height': estimatedHeight + 'px',
                    width: estimatedWidth + 'px',
                });
                $placeholder.append('<i class="eva eva-loader-outline eva-spin"></i>');

                $pageWrapper.append($placeholder);
                $pageWrapper.css('min-height', estimatedHeight + 'px');
                $(self.canvasContainer).append($pageWrapper);
            }

            // Lazy loading: Only render visible pages initially
            self._renderVisiblePages();
        },

        _renderVisiblePages: function () {
            var self = this;
            var scrollTop = $(self.canvasContainer).scrollTop();
            var containerHeight = self.containerHeight;
            var viewportTop = scrollTop;
            var viewportBottom = scrollTop + containerHeight;

            // Calculate buffer zone (1 page height estimate)
            var bufferZone = 800;

            // Cleanup pages far outside viewport to free memory
            self._cleanupDistantPages();

            // Only check pages within extended viewport range
            var $pages = $(self.canvasContainer).find('.wpcp-pdf-page-wrapper');

            $pages.each(function () {
                var $page = $(this);
                var pageNum = parseInt($page.attr('data-page'), 10);

                // Skip already rendered pages
                if (self.renderedPages[pageNum]) {
                    return true; // continue
                }

                var pageTop = $page.position().top + scrollTop;
                var pageHeight = $page.height() || 800;
                var pageBottom = pageTop + pageHeight;

                // Check if page is within viewport + buffer
                var isInViewport = pageBottom >= viewportTop - bufferZone && pageTop <= viewportBottom + bufferZone;

                if (isInViewport) {
                    self._renderPage(pageNum);
                }
            });
        },

        _cleanupDistantPages: function () {
            var self = this;
            var scrollTop = $(self.canvasContainer).scrollTop();
            var containerHeight = self.containerHeight;
            var viewportTop = scrollTop;
            var viewportBottom = scrollTop + containerHeight;

            // Cleanup threshold: 2 pages outside viewport
            var cleanupThreshold = 1600;

            $(self.canvasContainer)
                .find('.wpcp-pdf-page-wrapper')
                .each(function () {
                    var $page = $(this);
                    var pageNum = parseInt($page.attr('data-page'), 10);
                    var $canvas = $page.find('canvas');

                    // Skip if no canvas exists
                    if ($canvas.length === 0) {
                        return true; // continue
                    }

                    var pageTop = $page.position().top + scrollTop;
                    var pageHeight = $page.height() || 800;
                    var pageBottom = pageTop + pageHeight;

                    // Check if page is far outside viewport
                    var isFarOutside =
                        pageBottom < viewportTop - cleanupThreshold || pageTop > viewportBottom + cleanupThreshold;

                    if (isFarOutside) {
                        // Remove canvas and text layer to free memory
                        $page.find('canvas').remove();
                        $page.find('.textLayer').remove();
                        // Mark as not rendered so it can be re-rendered when visible
                        delete self.renderedPages[pageNum];
                        // Cancel any active render task
                        if (self.renderTasks[pageNum] && self.renderTasks[pageNum].cancel) {
                            try {
                                self.renderTasks[pageNum].cancel();
                            } catch (e) {}
                        }
                        delete self.renderTasks[pageNum];
                    }
                });
        },

        _renderPage: function (pageNum) {
            var self = this;

            if (!self.pdf || pageNum < 1 || pageNum > self.numPages) {
                return;
            }

            if (self.isDestroyed) {
                return;
            }

            // If already rendering, avoid duplicate work
            if (self.renderTasks[pageNum]) {
                return;
            }

            // Get page wrapper
            var $pageWrapper = $(self.canvasContainer).find('.wpcp-pdf-page-wrapper[data-page="' + pageNum + '"]');
            if ($pageWrapper.length === 0) {
                return;
            }

            // Create canvas on-demand if it doesn't exist
            var canvas = $pageWrapper.find('canvas')[0];
            if (!canvas) {
                canvas = document.createElement('canvas');
                canvas.className = 'wpcp-pdf-canvas';
                canvas.setAttribute('data-page', pageNum);
                $pageWrapper.append(canvas);
            }

            //var context = canvas.getContext('2d');

            self.pdf
                .getPage(pageNum)
                .then(function (page) {
                    // Calculate scale on first page
                    if (pageNum === 1) {
                        var viewport = page.getViewport({ scale: 1 });
                        self.pageHeight = viewport.height;
                        self.pageWidth = viewport.width;

                        // Update all wrapper and placeholder dimensions with actual page dimensions
                        var estimatedScale = self.scale !== null ? self.scale : self._calculateFitScale();
                        var scaledHeight = self.pageHeight * estimatedScale;
                        var scaledWidth = self.pageWidth * estimatedScale;

                        $(self.canvasContainer)
                            .find('.wpcp-pdf-page-wrapper')
                            .each(function () {
                                $(this).css('min-height', scaledHeight + 'px');
                                $(this)
                                    .find('.wpcp-pdf-placeholder')
                                    .css({
                                        'min-height': scaledHeight + 'px',
                                        width: scaledWidth + 'px',
                                    });
                            });
                    }

                    var effectiveScale = self.scale !== null ? self.scale : self._calculateFitScale();

                    // Account for device pixel ratio (retina displays) for sharp rendering
                    var outputScale = window.devicePixelRatio || 1;

                    // Get UNSCALED viewport for base dimensions
                    var unscaledViewport = page.getViewport({ scale: 1 });

                    // Get SCALED viewport for rendering
                    var viewport = page.getViewport({ scale: effectiveScale });

                    // Set canvas internal dimensions (high DPI)
                    canvas.height = viewport.height * outputScale;
                    canvas.width = viewport.width * outputScale;

                    // Set canvas CSS dimensions (normal scale)
                    canvas.style.height = viewport.height + 'px';
                    canvas.style.width = viewport.width + 'px';

                    // Scale context to match high DPI canvas
                    //context.setTransform(outputScale, 0, 0, outputScale, 0, 0);

                    // Render PDF page
                    var renderContext = {
                        canvas: canvas,
                        //canvasContext: context,
                        viewport: viewport,
                        transform: outputScale !== 1 ? [outputScale, 0, 0, outputScale, 0, 0] : null,
                    };

                    var renderTask = page.render(renderContext);
                    self.renderTasks[pageNum] = renderTask;

                    renderTask.promise
                        .then(function () {
                            // Remove placeholder spinner now that canvas is rendered
                            $pageWrapper.find('.wpcp-pdf-placeholder').remove();

                            // Mark as rendered only after successful render
                            self.renderedPages[pageNum] = true;

                            // Render text layer for text selection/copying
                            return page.getTextContent();
                        })
                        .then(function (textContent) {
                            // Create text layer div if it doesn't exist
                            var $pageWrapper = $(canvas).parent();
                            var $textLayer = $pageWrapper.find('.textLayer');

                            if ($textLayer.length === 0) {
                                $textLayer = $('<div class="textLayer"></div>');
                                $pageWrapper.append($textLayer);
                            } else {
                                $textLayer.empty();
                            }

                            // Set text layer dimensions and scale
                            // Use UNSCALED dimensions with scale factor for proper text rendering
                            $textLayer.css({
                                '--scale-factor': effectiveScale,
                                '--total-scale-factor': effectiveScale,
                                '--viewport-scale': effectiveScale,
                                '--scale-round-x': '1px',
                                '--scale-round-y': '1px',
                                '--min-font-size': '1',
                                width: unscaledViewport.width + 'px',
                                height: unscaledViewport.height + 'px',
                            });

                            // Set rotation attribute
                            $textLayer.attr('data-main-rotation', viewport.rotation || 0);

                            // PDF.js v4.0+ uses TextLayer class instead of renderTextLayer function
                            if (typeof pdfjsLib.TextLayer !== 'undefined') {
                                var textLayer = new pdfjsLib.TextLayer({
                                    textContentSource: textContent,
                                    container: $textLayer[0],
                                    viewport: viewport,
                                });

                                textLayer.render();
                            }

                            // Update zoom display as soon as page 1 renders — this is when
                            // pageHeight/pageWidth are first known, so _calculateFitScale()
                            // returns the real fit scale instead of the fallback value
                            if (pageNum === 1) {
                                self._updateUI();
                            }
                            if (pageNum === self.numPages) {
                                self.isRendering = false;
                                if (pageNum > 1) {
                                    self._updateUI();
                                }
                            }
                            delete self.renderTasks[pageNum];
                        })
                        .catch(function (error) {
                            console.error('PDF.js render error:', error);
                            $pageWrapper.find('.wpcp-pdf-placeholder').remove();
                            delete self.renderTasks[pageNum];
                            delete self.renderedPages[pageNum];
                        });
                })
                .catch(function (error) {
                    console.error('PDF.js getPage error:', error);
                });
        },

        _calculateFitScale: function () {
            var self = this;

            if (
                !self.containerHeight ||
                !self.containerWidth ||
                !self.pageHeight ||
                !self.pageWidth
            ) {
                return self.options.minZoom;
            }

            // Reserve container padding
            var availableHeight = self.containerHeight - 10;
            var availableWidth = self.containerWidth - 40;

            // If the available area is too small to compute a meaningful scale,
            // return minZoom so we get at least a visible render
            if (availableHeight <= 0 || availableWidth <= 0) {
                return self.options.minZoom;
            }

            var scaleHeight = availableHeight / self.pageHeight;
            var scaleWidth = availableWidth / self.pageWidth;

            // Use the most restrictive axis so the whole page fits in both dimensions
            var fitScale = Math.min(scaleHeight, scaleWidth);

            // Fit-to-page: never scale up beyond 100% (natural size), and respect minZoom
            return Math.min(Math.max(fitScale, self.options.minZoom), 1.0);
        },

        _scrollToPage: function (pageNum) {
            var self = this;

            if (pageNum < 1 || pageNum > self.numPages) {
                return;
            }

            var $pageWrapper = $(self.canvasContainer).find('.wpcp-pdf-page-wrapper[data-page="' + pageNum + '"]');
            if ($pageWrapper.length) {
                // Smooth scroll to page
                $(self.canvasContainer).animate(
                    {
                        scrollTop: $pageWrapper.position().top + $(self.canvasContainer).scrollTop(),
                    },
                    300,
                );

                self.currentPage = pageNum;
                self._updateUI();
            }
        },

        _updateCurrentPageFromScroll: function () {
            var self = this;
            var scrollTop = $(self.canvasContainer).scrollTop();

            // Find which page is most visible
            $(self.canvasContainer)
                .find('.wpcp-pdf-page-wrapper')
                .each(function () {
                    var $page = $(this);
                    var pageTop = $page.position().top + scrollTop;
                    var pageHeight = $page.height();
                    var pageCenter = pageTop + pageHeight / 2;

                    if (pageCenter >= scrollTop && pageCenter <= scrollTop + self.containerHeight) {
                        var pageNum = parseInt($page.attr('data-page'), 10);
                        if (self.currentPage !== pageNum) {
                            self.currentPage = pageNum;

                            // Update current page indicator
                            $(self.canvasContainer).find('.wpcp-pdf-page-wrapper').removeClass('current-page');
                            $page.addClass('current-page');

                            self._updateUI();
                        }
                        return false; // break
                    }
                });
        },

        _zoomIn: function (step) {
            var self = this;
            var zoomStep = typeof step === 'number' ? step : 0.25;
            var currentScale = self.scale !== null ? self.scale : self._calculateFitScale();
            var newScale = Math.min(currentScale + zoomStep, self.options.maxZoom);
            self._applyScale(newScale);
        },

        _zoomOut: function (step) {
            var self = this;
            var zoomStep = typeof step === 'number' ? step : 0.25;
            var currentScale = self.scale !== null ? self.scale : self._calculateFitScale();
            var newScale = Math.max(currentScale - zoomStep, self.options.minZoom);
            self._applyScale(newScale);
        },

        _fitToPage: function () {
            var self = this;

            self.scale = null; // Reset to auto-fit mode
            self.element.find('.wpcp-pdf-fit').addClass('active');
            self._cancelAllRenderTasks();
            self.renderedPages = {}; // Reset for re-render
            self._updateUI();
            self._renderAllPages();
        },

        _applyScale: function (newScale, center) {
            var self = this;
            var clampedScale = Math.max(self.options.minZoom, Math.min(newScale, self.options.maxZoom));
            var currentScale = self.scale !== null ? self.scale : self._calculateFitScale();
            var scaleRatio = clampedScale / currentScale;

            // Save current scroll position
            var scrollTop = $(self.canvasContainer).scrollTop();
            var scrollLeft = $(self.canvasContainer).scrollLeft();

            var centerPoint = center || {
                x: self.containerWidth / 2,
                y: self.containerHeight / 2,
            };

            self.scale = clampedScale;
            self.element.find('.wpcp-pdf-fit').removeClass('active');
            self._cancelAllRenderTasks();
            self.renderedPages = {}; // Reset for re-render
            self._updateUI();
            self._renderAllPages();

            // Restore scroll position adjusted for new scale, keeping center point stable
            requestAnimationFrame(function () {
                var newScrollTop = (scrollTop + centerPoint.y) * scaleRatio - centerPoint.y;
                var newScrollLeft = (scrollLeft + centerPoint.x) * scaleRatio - centerPoint.x;
                $(self.canvasContainer).scrollTop(newScrollTop);
                $(self.canvasContainer).scrollLeft(newScrollLeft);
            });
        },

        _cancelAllRenderTasks: function () {
            var self = this;
            Object.keys(self.renderTasks).forEach(function (pageNum) {
                var task = self.renderTasks[pageNum];
                if (task && task.cancel) {
                    try {
                        task.cancel();
                    } catch (e) {}
                }
            });
            self.renderTasks = {};
        },

        _updateUI: function () {
            var self = this;

            // Update page counter
            self.element.find('.wpcp-pdf-page-current').text(self.currentPage);

            // Update zoom level display
            // Shows actual percentage (e.g., 75% if PDF is scaled down to fit)
            var currentScale = self.scale !== null ? self.scale : self._calculateFitScale();
            var zoomPercent = Math.round(currentScale * 100);
            self.element.find('.wpcp-pdf-zoom-level').text(zoomPercent + '%');

            // Update buttons
            self._updateButtons();
        },

        _updateButtons: function () {
            var self = this;

            // Navigation buttons
            self.element.find('.wpcp-pdf-prev').prop('disabled', self.currentPage <= 1);
            self.element.find('.wpcp-pdf-next').prop('disabled', self.currentPage >= self.numPages);

            // Zoom buttons
            var currentScale = self.scale !== null ? self.scale : self._calculateFitScale();
            self.element.find('.wpcp-pdf-zoom-out').prop('disabled', currentScale <= self.options.minZoom);
            self.element.find('.wpcp-pdf-zoom-in').prop('disabled', currentScale >= self.options.maxZoom);
        },

        _showError: function (message) {
            var self = this;

            self.isLoading = false;
            self.element.find('.wpcp-pdf-loading').hide();
            self.element.find('.wpcp-pdf-controls').hide();
            self.element.find('.wpcp-pdf-canvas-container').hide();

            var $error = self.element.find('.wpcp-pdf-error');
            $error.find('.wpcp-pdf-error-message').text(message);
            $error.show();
        },

        _toggleSearch: function () {
            var self = this;
            var $panel = self.element.find('.wpcp-pdf-search-panel');
            var $input = self.element.find('.wpcp-pdf-search-input');
            var $searchBtn = self.element.find('.wpcp-pdf-search');

            if ($panel.is(':visible')) {
                // Hide search panel
                $panel.slideUp(200);
                $searchBtn.removeClass('active');
                self._clearSearch();
            } else {
                // Show search panel
                $panel.slideDown(200, function () {
                    $input.focus();
                });
                $searchBtn.addClass('active');
            }
        },

        _performSearch: function (query) {
            var self = this;

            // Clear previous highlights
            self._clearSearchHighlights();

            if (!query || query.length < 2) {
                self.searchQuery = '';
                self.searchResults = [];
                self.currentSearchResult = -1;
                self._updateSearchUI();
                return;
            }

            self.searchQuery = query.toLowerCase();
            self.searchResults = [];
            self.currentSearchResult = -1;

            // Search through all pages
            var searchPromises = [];
            for (var pageNum = 1; pageNum <= self.numPages; pageNum++) {
                searchPromises.push(self._searchPage(pageNum, self.searchQuery));
            }

            Promise.all(searchPromises).then(function () {
                if (self.searchResults.length > 0) {
                    self.currentSearchResult = 0;
                    self._highlightSearchResults();
                    self._scrollToSearchResult(0);
                }
                self._updateSearchUI();
            });
        },

        _searchPage: function (pageNum, query) {
            var self = this;

            return self.pdf.getPage(pageNum).then(function (page) {
                return page.getTextContent().then(function (textContent) {
                    var textItems = textContent.items;
                    var pageText = '';
                    var positions = [];

                    // Build full page text and track positions
                    textItems.forEach(function (item, index) {
                        var str = item.str;
                        positions.push({
                            start: pageText.length,
                            end: pageText.length + str.length,
                            itemIndex: index,
                        });
                        pageText += str + ' ';
                    });

                    // Search for query in page text
                    var searchText = pageText.toLowerCase();
                    var searchIndex = 0;

                    while ((searchIndex = searchText.indexOf(query, searchIndex)) !== -1) {
                        // Find which text item(s) contain this match
                        var matchStart = searchIndex;
                        var matchEnd = searchIndex + query.length;

                        self.searchResults.push({
                            pageNum: pageNum,
                            start: matchStart,
                            end: matchEnd,
                            text: pageText.substring(matchStart, matchEnd),
                        });

                        searchIndex = matchEnd;
                    }
                });
            });
        },

        _highlightSearchResults: function () {
            var self = this;

            // Clear previous highlights first
            $(self.canvasContainer).find('.textLayer span').removeClass('search-highlight search-highlight-current');

            // Highlight all search results
            self.searchResults.forEach(function (result, index) {
                var $pageWrapper = $(self.canvasContainer).find(
                    '.wpcp-pdf-page-wrapper[data-page="' + result.pageNum + '"]',
                );
                var $textLayer = $pageWrapper.find('.textLayer');

                if ($textLayer.length === 0) {
                    return;
                }

                // Get all text spans in this page
                var $spans = $textLayer.find('span');
                var isCurrent = index === self.currentSearchResult;

                // Highlight the matching text by finding spans that contain the search query
                self._highlightTextInLayer($textLayer, result, isCurrent);
            });

            // Mark current result page
            $(self.canvasContainer).find('.wpcp-pdf-page-wrapper').removeClass('current-search-result');
            if (self.currentSearchResult >= 0) {
                var currentResult = self.searchResults[self.currentSearchResult];
                var $currentPage = $(self.canvasContainer).find(
                    '.wpcp-pdf-page-wrapper[data-page="' + currentResult.pageNum + '"]',
                );
                $currentPage.addClass('current-search-result');
            }
        },

        _highlightTextInLayer: function ($textLayer, result, isCurrent) {
            var self = this;
            var $spans = $textLayer.find('span');
            var searchQuery = self.searchQuery;
            var highlightClass = isCurrent ? 'search-highlight-current' : 'search-highlight';

            // Iterate through all text spans and check if they contain the search term
            $spans.each(function () {
                var $span = $(this);
                var text = $span.text();

                if (text && text.toLowerCase().indexOf(searchQuery) !== -1) {
                    $span.addClass(highlightClass);
                }
            });
        },

        _clearSearchHighlights: function () {
            var self = this;
            $(self.canvasContainer).find('.textLayer span').removeClass('search-highlight search-highlight-current');
            $(self.canvasContainer).find('.wpcp-pdf-page-wrapper').removeClass('current-search-result');
        },

        _clearSearch: function () {
            var self = this;
            self.searchQuery = '';
            self.searchResults = [];
            self.currentSearchResult = -1;
            self.element.find('.wpcp-pdf-search-input').val('');
            self._clearSearchHighlights();
            self._updateSearchUI();
        },

        _goToNextSearchResult: function () {
            var self = this;

            if (self.searchResults.length === 0) {
                return;
            }

            self.currentSearchResult = (self.currentSearchResult + 1) % self.searchResults.length;
            self._highlightSearchResults(); // Refresh highlights to show new current result
            self._scrollToSearchResult(self.currentSearchResult);
            self._updateSearchUI();
        },

        _goToPrevSearchResult: function () {
            var self = this;

            if (self.searchResults.length === 0) {
                return;
            }

            self.currentSearchResult = self.currentSearchResult - 1;
            if (self.currentSearchResult < 0) {
                self.currentSearchResult = self.searchResults.length - 1;
            }
            self._highlightSearchResults(); // Refresh highlights to show new current result
            self._scrollToSearchResult(self.currentSearchResult);
            self._updateSearchUI();
        },

        _scrollToSearchResult: function (resultIndex) {
            var self = this;

            if (resultIndex < 0 || resultIndex >= self.searchResults.length) {
                return;
            }

            var result = self.searchResults[resultIndex];

            // Remove previous current-result highlighting
            $(self.canvasContainer).find('.wpcp-pdf-page-wrapper').removeClass('current-search-result');

            // Add current-result to the page containing this result
            var $pageWrapper = $(self.canvasContainer).find(
                '.wpcp-pdf-page-wrapper[data-page="' + result.pageNum + '"]',
            );
            $pageWrapper.addClass('current-search-result');

            // Ensure page is rendered
            if (!self.renderedPages[result.pageNum]) {
                self.renderedPages[result.pageNum] = true;
                self._renderPage(result.pageNum);
            }

            // Scroll to page
            if ($pageWrapper.length) {
                var scrollTop = $pageWrapper.position().top + $(self.canvasContainer).scrollTop();
                $(self.canvasContainer).animate(
                    {
                        scrollTop: scrollTop - 50, // Offset for visibility
                    },
                    300,
                );
            }
        },

        _printPDF: function () {
            var self = this;

            if (!self.pdf) {
                console.warn('PDF not loaded yet');
                return;
            }

            // Get the PDF data and open in new window for printing
            self.pdf
                .getData()
                .then(function (data) {
                    // Create a blob from the PDF data
                    var blob = new Blob([data], { type: 'application/pdf' });
                    var blobUrl = URL.createObjectURL(blob);

                    // Open in new window
                    var printWindow = window.open(blobUrl, '_blank');

                    if (printWindow) {
                        // Wait for the window to load, then trigger print
                        printWindow.onload = function () {
                            printWindow.focus();
                            printWindow.print();

                            // Clean up after print dialog closes
                            printWindow.onafterprint = function () {
                                URL.revokeObjectURL(blobUrl);
                                printWindow.close();
                            };
                        };
                    } else {
                        // If popup was blocked, clean up and notify
                        URL.revokeObjectURL(blobUrl);
                        alert('Please allow popups to print the PDF');
                    }
                })
                .catch(function (error) {
                    console.error('Error preparing PDF for print:', error);
                    alert('Failed to prepare PDF for printing');
                });
        },

        _updateSearchUI: function () {
            var self = this;
            var $count = self.element.find('.wpcp-pdf-search-count');
            var $prev = self.element.find('.wpcp-pdf-search-prev');
            var $next = self.element.find('.wpcp-pdf-search-next');

            if (self.searchResults.length === 0) {
                $count.text('');
                $prev.prop('disabled', true);
                $next.prop('disabled', true);
            } else {
                $count.text(self.currentSearchResult + 1 + ' / ' + self.searchResults.length);
                $prev.prop('disabled', false);
                $next.prop('disabled', false);
            }
        },

        _destroy: function () {
            var self = this;

            self.isDestroyed = true;

            // Cleanup all event listeners
            $(document).off('keydown.pdfviewer-' + self.options.listtoken);
            $(window).off('resize.pdfviewer-' + self.options.listtoken);
            $(self.canvasContainer).off('scroll wheel');

            if (self.resizeObserver) {
                self.resizeObserver.disconnect();
                self.resizeObserver = null;
            }

            // Clear timeouts
            if (self.wheelZoomTimeout) {
                clearTimeout(self.wheelZoomTimeout);
            }
            if (self.searchTimeout) {
                clearTimeout(self.searchTimeout);
            }

            if (self.scrollRafId) {
                cancelAnimationFrame(self.scrollRafId);
                self.scrollRafId = null;
            }

            if (self.pinchRafId) {
                cancelAnimationFrame(self.pinchRafId);
                self.pinchRafId = null;
            }

            self._cancelAllRenderTasks();

            // Destroy PDF document
            if (self.loadingTask) {
                self.loadingTask.destroy();
                self.loadingTask = null;
            }

            // Clear references
            self.renderedPages = {};
            self.searchResults = [];

            $(self.canvasContainer)
                .off('.pdfviewer-touch-' + self.options.listtoken)
                .removeClass('pinch-zoom-active')
                .css({
                    'touch-action': 'pan-x pan-y',
                    'transform': '',
                    'transform-origin': ''
                });

            return this._super();
        },
    });
})(jQuery, window);
