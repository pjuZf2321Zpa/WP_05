<?php

/**
 * @author WP Cloud Plugins
 * @copyright Copyright (c) 2023, WP Cloud Plugins
 *
 * @since       2.0
 * @see https://www.wpcloudplugins.com
 */

namespace TheLion\ShareoneDrive\Modules;

use TheLion\ShareoneDrive\App;
use TheLion\ShareoneDrive\Core;
use TheLion\ShareoneDrive\Helpers;
use TheLion\ShareoneDrive\Processor;
use TheLion\ShareoneDrive\Settings;
use TheLion\ShareoneDrive\User;

defined('ABSPATH') || exit;

class Upload
{
    public static $enqueued_scripts = false;

    public static function render_standalone($attributes)
    {
        echo "<div class='wpcp-module ShareoneDrive upload jsdisabled' ".Module::parse_attributes($attributes).'>';
        self::render();
        echo '</div>';
    }

    public static function render()
    {
        $user_can_upload = User::can_upload();

        if (false === $user_can_upload) {
            if (
                'upload' === Processor::instance()->get_shortcode_option('mode')
                    && '1' === Processor::instance()->get_shortcode_option('upload')
                    && App::get_current_account()->is_drive_readonly()
                    && Helpers::check_user_role(Settings::get('permissions_add_shortcodes'))) {
                echo '&#9888; <strong>'.esc_html__('This module is not available because the connected account is set to read-only mode. Please reconnect your cloud account using the correct permissions.', 'wpcloudplugins').'</strong>';
            }

            return;
        }

        self::enqueue_scripts();

        include sprintf('%s/templates/modules/upload_box.php', SHAREONEDRIVE_ROOTDIR);
    }

    public static function enqueue_scripts()
    {
        if (true === self::$enqueued_scripts) {
            return;
        }

        Core::instance()->load_scripts();
        Core::instance()->load_styles();

        wp_enqueue_script('jquery-ui-droppable');
        wp_enqueue_script('ShareoneDrive.UploadBox');

        Helpers::append_dependency('ShareoneDrive', 'ShareoneDrive.UploadBox');

        self::$enqueued_scripts = true;
    }
}
