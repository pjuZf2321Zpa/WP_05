<?php

/**
 * @author WP Cloud Plugins
 * @copyright Copyright (c) 2023, WP Cloud Plugins
 *
 * @since       2.0
 * @see https://www.wpcloudplugins.com
 */

namespace TheLion\ShareoneDrive;

defined('ABSPATH') || exit;

/**
 * Verifies that the web server can reach the Microsoft endpoints required for
 * authorization and Microsoft Graph requests.
 */
final class MicrosoftConnectionTest
{
    public const LOGIN_ENDPOINT = 'https://login.microsoftonline.com/common/v2.0/.well-known/openid-configuration';
    public const GRAPH_ENDPOINT = 'https://graph.microsoft.com/v1.0/';
    public const ERROR_TRANSIENT = 'shareonedrive_microsoft_connection_error';

    /**
     * Test every Microsoft endpoint required to connect an account.
     *
     * @return array<string, mixed> the aggregate result and individual endpoint results
     */
    public static function run(): array
    {
        $login_result = self::test_login();
        $graph_result = self::test_graph();

        if (!$login_result['is_available']) {
            return self::create_aggregate_result($login_result, $graph_result);
        }

        return self::create_aggregate_result($graph_result, $login_result);
    }

    /**
     * Test the Microsoft OpenID configuration endpoint used by OAuth.
     *
     * @return array<string, mixed> the endpoint connection result
     */
    public static function test_login(): array
    {
        return self::request_endpoint('login', self::LOGIN_ENDPOINT, true);
    }

    /**
     * Test the Microsoft Graph endpoint used after authorization succeeds.
     *
     * @return array<string, mixed> the endpoint connection result
     */
    public static function test_graph(): array
    {
        return self::request_endpoint('graph', self::GRAPH_ENDPOINT, false);
    }

    /**
     * Register the Microsoft endpoint checks with WordPress Site Health.
     *
     * @param array<string, mixed> $tests the existing Site Health tests
     *
     * @return array<string, mixed> the Site Health tests including Microsoft checks
     */
    public static function add_health_tests(array $tests): array
    {

        $tests['direct']['shareonedrive_api_graph'] = [
            'label' => __('Communication with Microsoft Graph (graph.microsoft.com)', 'wpcloudplugins'),
            'test' => [__CLASS__, 'test_api_graph'],
        ];

        $tests['direct']['shareonedrive_api_login'] = [
            'label' => __('Communication with Microsoft Login (login.microsoftonline.com)', 'wpcloudplugins'),
            'test' => [__CLASS__, 'test_api_login'],
        ];

        return $tests;
    }

    /**
     * Build the Site Health result for the Microsoft Graph endpoint.
     *
     * @return array<string, mixed> the Site Health result structure
     */
    public static function test_api_graph(): array
    {
        return self::create_site_health_result(
            'shareonedrive_api_graph',
            self::test_graph(),
            __('Microsoft Graph (graph.microsoft.com)', 'wpcloudplugins'),
            __('The plugin contacts the Microsoft Graph endpoint to list, download, upload and manage files stored in your OneDrive or SharePoint account. If your server cannot reach this host, the plugin will not be able to function.', 'wpcloudplugins')
        );
    }

    /**
     * Build the Site Health result for the Microsoft Login endpoint.
     *
     * @return array<string, mixed> the Site Health result structure
     */
    public static function test_api_login(): array
    {
        return self::create_site_health_result(
            'shareonedrive_api_login',
            self::test_login(),
            __('Microsoft Login (login.microsoftonline.com)', 'wpcloudplugins'),
            __('The plugin contacts the Microsoft Login endpoint during the authorization flow and to refresh access tokens. If your server cannot reach this host, existing authorizations will stop working and new accounts cannot be connected.', 'wpcloudplugins')
        );
    }

    /**
     * Create a result that represents the first failed endpoint while retaining
     * both individual checks for diagnostics.
     *
     * @param array<string, mixed> $primary_result   the result that determines availability
     * @param array<string, mixed> $secondary_result the other endpoint result
     *
     * @return array<string, mixed> the aggregate connection result
     */
    private static function create_aggregate_result(array $primary_result, array $secondary_result): array
    {
        return [
            'is_available' => (bool) $primary_result['is_available'] && (bool) $secondary_result['is_available'],
            'category' => $primary_result['is_available'] ? null : $primary_result['category'],
            'message' => $primary_result['is_available'] ? '' : $primary_result['message'],
            'endpoint' => $primary_result['is_available'] ? '' : $primary_result['endpoint'],
            'http_status' => $primary_result['is_available'] ? 0 : $primary_result['http_status'],
            'technical_message' => $primary_result['is_available'] ? '' : $primary_result['technical_message'],
            'login' => 'login' === $primary_result['endpoint'] ? $primary_result : $secondary_result,
            'graph' => 'graph' === $primary_result['endpoint'] ? $primary_result : $secondary_result,
        ];
    }

    /**
     * Convert a normalized endpoint result into the WordPress Site Health format.
     *
     * @param string               $test_id           the Site Health test identifier
     * @param array<string, mixed> $connection_result the normalized endpoint connection result
     * @param string               $endpoint          the human-readable endpoint name
     * @param string               $description       the reason this endpoint is required
     *
     * @return array<string, mixed> the Site Health result structure
     */
    private static function create_site_health_result(string $test_id, array $connection_result, string $endpoint, string $description): array
    {
        $result = [
            'label' => sprintf(
                // translators: %s: endpoint name.
                __('Your server can communicate with %s', 'wpcloudplugins'),
                $endpoint
            ),
            'status' => 'good',
            'badge' => [
                'label' => 'Share-one-Drive',
                'color' => 'green',
            ],
            'description' => sprintf('<p>%s</p>', $description),
            'actions' => '',
            'test' => $test_id,
        ];

        if ($connection_result['is_available']) {
            return $result;
        }

        $result['status'] = 'critical';
        $result['label'] = sprintf(
            // translators: %s: endpoint name.
            __('Your server cannot communicate with %s', 'wpcloudplugins'),
            $endpoint
        );
        $result['badge']['color'] = 'red';
        $result['description'] = sprintf(
            '<p>%s</p><h3>%s</h3><code>%s</code>',
            $description,
            __('Error information', 'wpcloudplugins'),
            htmlentities($connection_result['technical_message'], ENT_QUOTES | ENT_HTML401)
        );
        $result['actions'] = sprintf(
            '<p><a href="%s" target="_blank">%s <span class="dashicons dashicons-external"></span></a> - <a href="%s" target="_blank">%s <span class="dashicons dashicons-external"></span></a></p>',
            esc_url('https://support.wpcloudplugins.com/hc/en-us/articles/38507132873362'),
            esc_html__('Troubleshooting guide', 'wpcloudplugins'),
            esc_url('https://support.wpcloudplugins.com/hc/en-us/articles/201845893'),
            esc_html__('Contact Support', 'wpcloudplugins')
        );

        return $result;
    }

    /**
     * Request and validate a fixed Microsoft endpoint.
     *
     * @param string $endpoint_id            the endpoint identifier used in diagnostics
     * @param string $url                    the Microsoft endpoint URL
     * @param bool   $validate_openid_config whether to validate the OpenID response body
     *
     * @return array<string, mixed> the endpoint connection result
     */
    private static function request_endpoint(string $endpoint_id, string $url, bool $validate_openid_config): array
    {

        // Some servers with openSSL 3.5.0 can't talk to Microsoft endpoints with ALPN enabled.
        // This filter allows disabling ALPN for those servers.
        $disable_alpn = apply_filters('wpcloudplugins_curl_disable_alpn', false);
        if ($disable_alpn) {
            add_action('http_api_curl', function ($handle, $args, $url) {
                if (strpos($url, 'microsoftonline.com') !== false
                 || strpos($url, 'microsoft.com')       !== false) {
                    curl_setopt($handle, CURLOPT_SSL_ENABLE_ALPN, false);
                }
            }, 10, 3);
        }

        try {
            // A short timeout provides immediate feedback without delaying the authorization flow.
            $response = wp_remote_get(
                $url,
                [
                    'timeout' => 10,
                    'redirection' => 0,
                    'sslverify' => true,
                    'user-agent' => 'WP Cloud Plugins Microsoft Connection Test/'.SHAREONEDRIVE_VERSION,
                ]
            );
        } catch (\Exception $exception) {
            return self::create_error_result($endpoint_id, 'connection_error', $exception->getMessage());
        }

        if (is_wp_error($response)) {
            return self::create_error_result($endpoint_id, self::get_error_category($response->get_error_message()), $response->get_error_message());
        }

        $status_code = (int) wp_remote_retrieve_response_code($response);

        if (200 !== $status_code) {
            // A 404 from this public document is the known signature of blocked Microsoft sign-in traffic.
            $category = 404 === $status_code ? 'blocked' : 'unexpected_response';

            return self::create_error_result(
                $endpoint_id,
                $category,
                sprintf('Unexpected HTTP status code: %d', $status_code),
                $status_code
            );
        }

        if ($validate_openid_config && !self::has_valid_openid_configuration(wp_remote_retrieve_body($response))) {
            return self::create_error_result($endpoint_id, 'invalid_response', 'The OpenID configuration response is invalid.', $status_code);
        }

        return [
            'is_available' => true,
            'category' => null,
            'message' => '',
            'endpoint' => $endpoint_id,
            'http_status' => $status_code,
            'technical_message' => '',
        ];
    }

    /**
     * Validate the public OpenID configuration before considering sign-in available.
     *
     * @param string $response_body the HTTP response body
     *
     * @return bool whether the response contains the required OpenID endpoints
     */
    private static function has_valid_openid_configuration(string $response_body): bool
    {
        $configuration = json_decode($response_body, true);

        if (!is_array($configuration)) {
            return false;
        }

        foreach (['authorization_endpoint', 'token_endpoint', 'issuer'] as $required_key) {
            if (empty($configuration[$required_key]) || !is_string($configuration[$required_key])) {
                return false;
            }
        }

        return true;
    }

    /**
     * Convert a transport failure into an actionable, user-safe category.
     *
     * @param string $error_message the transport error returned by WordPress
     *
     * @return string the failure category
     */
    private static function get_error_category(string $error_message): string
    {
        if (preg_match('/cURL error (\d+)/i', $error_message, $matches)) {
            return match ((int) $matches[1]) {
                6 => 'dns_error',
                7, 28 => 'connection_error',
                35, 51, 58, 60, 77 => 'tls_error',
                default => 'connection_error',
            };
        }

        return 'connection_error';
    }

    /**
     * Create a normalized failed endpoint result.
     *
     * @param string $endpoint_id       the endpoint identifier used in diagnostics
     * @param string $category          the failure category
     * @param string $technical_message the sanitized technical error message
     * @param int    $status_code       the HTTP status code, if available
     *
     * @return array<string, mixed> the failed endpoint connection result
     */
    private static function create_error_result(string $endpoint_id, string $category, string $technical_message, int $status_code = 0): array
    {
        return [
            'is_available' => false,
            'category' => $category,
            'message' => self::get_user_message($endpoint_id, $category),
            'endpoint' => $endpoint_id,
            'http_status' => $status_code,
            'technical_message' => sanitize_text_field($technical_message),
        ];
    }

    /**
     * Return a user-safe explanation that can be displayed in every UI surface.
     *
     * @param string $endpoint_id the endpoint that could not be reached
     * @param string $category    the failure category
     *
     * @return string the localized user-facing message
     */
    private static function get_user_message(string $endpoint_id, string $category): string
    {
        if ('login' === $endpoint_id && 'blocked' === $category) {
            return __('Your hosting server is being blocked before it reaches Microsoft’s sign-in service.', 'wpcloudplugins');
        }

        if ('dns_error' === $category) {
            return __('Your hosting server cannot find the Microsoft service address.', 'wpcloudplugins');
        }

        if ('tls_error' === $category) {
            return __('Your hosting server cannot establish a trusted secure connection to Microsoft.', 'wpcloudplugins');
        }

        if ('graph' === $endpoint_id) {
            return __('Microsoft sign-in is reachable, but your hosting server cannot reach Microsoft Graph to finish connecting the account.', 'wpcloudplugins');
        }

        return __('Your hosting server cannot establish a connection to Microsoft’s sign-in service.', 'wpcloudplugins');
    }
}
