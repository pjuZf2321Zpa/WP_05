<?php

/**
 * @author WP Cloud Plugins
 * @copyright Copyright (c) 2023, WP Cloud Plugins
 *
 * @since       2.0
 * @see https://www.wpcloudplugins.com
 */

namespace TheLion\ShareoneDrive;

defined('ABSPATH') || exit;

class Search
{
    /**
     * @var CacheNode
     */
    private $_top_folder_node;

    /**
     * @var string
     */
    private $_query;

    /**
     * @var bool
     */
    private $search_contents;

    /**
     * @var string Specifies the scope of the search.
     *             Default is 'site', which limits the search to the current site.
     */
    private $search_where = 'site';

    /**
     ** @var int Specifies the maximum number of search results to return.
     *                        Default is 100. Maximum is 1000
     */
    private $max_results = 100;

    public function do_search($query, CacheNode $folder_node, $search_contents = false)
    {
        $this->_top_folder_node = $folder_node;
        $this->_query = $query;
        $this->search_contents = $search_contents;
        $this->max_results = apply_filters('shareonedrive_api_search_max_results', $this->max_results);

        // Search
        if ($this->is_using_v2()) {
            // Use new POST /v1.0/search/query endpoint
            $api_results = $this->query_v2();
        } else {
            // Use old GET /v1.0/me/drive...?search(q=...) endpoint
            $api_results = $this->query_v1();
        }

        // Process the results and store them in cache
        if ($this->is_using_v2()) {
            $entries_found = $api_results;
        } else {
            $entries_found = $this->process($api_results);
        }

        // Filter them for this specific request
        $entries_filtered = $this->filter($entries_found);

        // Save the cache
        Cache::instance()->set_updated();
        Cache::instance()->update_cache(false);

        return $entries_filtered;
    }

    public function query_v1()
    {
        $query = apply_filters('shareonedrive_api_search_set_query', $this->_query);

        // Find all items containing query
        $params = [
            'id' => $this->_top_folder_node->get_id(),
            'driveId' => $this->_top_folder_node->get_drive_id(),
            'q' => stripslashes($query),
            'expand' => API::$apilistfilesfields,
            'top' => $this->max_results,
        ];

        // Set all params
        $params = apply_filters('shareonedrive_api_search_set_params', $params, 'v1');

        // Do the request
        $next_page_token = null;
        $api_results = [];

        do_action('shareonedrive_log_event', 'shareonedrive_searched', $this->_top_folder_node, ['query' => $query]);

        do {
            try {
                $search_response = App::instance()->get_drive()->items->search($params);
            } catch (\Exception $ex) {
                Helpers::log_error('', 'Search', null, __LINE__, $ex);

                return [];
            }

            // Process the response
            $more_files = $search_response->getValue();
            $api_results = array_merge($api_results, $more_files);

            if (isset($search_response['@odata.nextLink'])) {
                $next_page_token = $search_response['@odata.nextLink'];
                $next_link = parse_url($next_page_token);
                parse_str($next_link['query'], $next_link_attributes);
                $next_page_token = isset($next_link_attributes['$skiptoken']) ? $next_link_attributes['$skiptoken'] : null;
            } else {
                $next_page_token = null;
            }
            $params['skiptoken'] = $next_page_token;
        } while (null !== $next_page_token && count($api_results) < $this->max_results);

        return $api_results;
    }

    public function query_v2()
    {
        $query = apply_filters('shareonedrive_api_search_set_query', $this->_query);

        // Search Location
        // Path is not yet full supported due to differences between driveItem and listItem

        $where = '';
        if ('path' === $this->search_where) {
            // Search by Path

            $path = $this->_top_folder_node->get_entry()->get_weburl();
            $where = ' AND path:"'.$path.'"';
        } elseif ('site' === $this->search_where) {
            // Search in Site
            $drive_node = $this->_top_folder_node->get_drive_node();
            $site = $drive_node->get_entry()->get_weburl();
            $where = ' AND site:"'.$site.'/*"';
        }

        // Search Params
        $page_size = 500;
        $params = [
            'requests' => [
                [
                    'entityTypes' => ['driveItem'],
                    'query' => [
                        'queryString' => stripslashes($query).$where,
                    ],
                    'fields' => [
                        'name', 'id', 'parentReference',
                    ],
                    'from' => 0,
                    'size' => $page_size,
                    'trimDuplicates' => true,
                ],
            ],
        ];

        // Set all params
        $params = apply_filters('shareonedrive_api_search_set_params', $params, 'v2');

        // Do the request
        $api_results = [];
        $more_results_available = false;

        do_action('shareonedrive_log_event', 'shareonedrive_searched', $this->_top_folder_node, ['query' => $query]);

        do {
            try {
                $search_responses = App::instance()->get_search()->search->query($params);
            } catch (\Exception $ex) {
                Helpers::log_error('', 'Search', null, __LINE__, $ex);

                return $api_results;
            }

            $responses = $search_responses->getValue();

            foreach ($responses as $response) {
                foreach ($response->getHitsContainers() as $hitcontainer) {
                    foreach ($hitcontainer->getHits() as $hit) {
                        if (count($api_results) >= $this->max_results) {
                            // Stop if we have enough results
                            $more_results_available = false;

                            break 3;
                        }

                        $api_entry = $hit->getResource();
                        $entry_id = $api_entry->getId();
                        $parent_id = $api_entry->getParentReference()->getId();
                        $entry_drive_id = $api_entry->getParentReference()->getDriveId();

                        // Check if files are in cache
                        $cached_node = Cache::instance()->is_cached($entry_id, $entry_drive_id, 'id', true);
                        if (!$cached_node) {
                            // Load Parent folder
                            $parent_folder = API::get_folder($parent_id);
                            $cached_node = Cache::instance()->is_cached($entry_id, $entry_drive_id, 'id', true);
                        }

                        if (!$cached_node) {
                            // If we haven't found the file at all, skip it
                            continue;
                        }

                        if ('site' === $this->search_where && false === $cached_node->is_in_folder($this->_top_folder_node->get_id())) {
                            // If we are searching site wide, check if the file is in the searched folder. If not, skip it.
                            continue;
                        }

                        $api_results[] = $cached_node;
                    }

                    $more_results_available = $hitcontainer->getMoreResultsAvailable();
                    $params['requests'][0]['from'] += $page_size;
                }
            }
        } while (true === $more_results_available && (count($api_results) < $this->max_results));

        return $api_results;
    }

    public function process($api_results = [])
    {
        $entries_found = [];
        $entries_in_searchedfolder = [];

        // Convert API results into Entries
        foreach ($api_results as $file) {
            if (false === $this->search_contents && false === stripos($file->getName(), $this->_query)) {
                // Only find files query in name */
                continue;
            }
            $entries_found[$file->getId()] = new Entry($file);
        }

        // Add / Update files in cache
        foreach ($entries_found as $entry) {
            // Update the time_limit as this can take a while
            Helpers::set_time_limit(30);

            // Check if files are in cache
            $cachedentry = Cache::instance()->is_cached($entry->get_id(), $entry->get_drive_id());

            // If not found, add to cache
            if (false === $cachedentry) {
                $cachedentry = Cache::instance()->add_to_cache($entry);
            }

            $entries_in_searchedfolder[] = $cachedentry;
        }

        return $entries_in_searchedfolder;
    }

    public function filter($entries_filtered)
    {
        foreach ($entries_filtered as $key => $cached_node) {
            if (false === Processor::instance()->_is_entry_authorized($cached_node)) {
                unset($entries_filtered[$key]);
            }
        }

        return $entries_filtered;
    }

    /**
     * Get the value of _top_folder_node.
     *
     * @return CacheNode
     */
    public function get_top_folder_node()
    {
        return $this->_top_folder_node;
    }

    /**
     * Set the value of _top_folder_node.
     *
     * @return self
     */
    public function set_top_folder_node(CacheNode $_top_folder_node)
    {
        $this->_top_folder_node = $_top_folder_node;

        return $this;
    }

    /**
     * Get the value of _query.
     *
     * @return string
     */
    public function get_query()
    {
        return $this->_query;
    }

    /**
     * Set the value of _query.
     *
     * @return self
     */
    public function set_query(string $_query)
    {
        $this->_query = $_query;

        return $this;
    }

    public function is_using_v2()
    {
        return !in_array(App::get_current_account()->get_type(), ['personal']) && 'Yes' === Settings::get('use_search_v2', 'No');
    }
}
