<?php

/**
 * @author WP Cloud Plugins
 * @copyright Copyright (c) 2023, WP Cloud Plugins
 *
 * @since       2.0
 * @see https://www.wpcloudplugins.com
 */

namespace TheLion\ShareoneDrive;

defined('ABSPATH') || exit;

class Account
{
    /**
     * Account ID.
     *
     * @var string
     */
    private $_id;

    /**
     * Identifier for front-end use.
     */
    private $_uuid;

    /**
     * Account Name.
     *
     * @var string
     */
    private $_name;

    /**
     * Account Email.
     *
     * @var string
     */
    private $_email;

    /**
     * Account profile picture (url).
     *
     * @var string
     */
    private $_image;

    /**
     * Kind of Account.
     *
     * @var string
     */
    private $_type;

    /**
     * $_authorization contains the authorization token for the linked Cloud storage.
     *
     * @var Authorization
     */
    private $_authorization;

    /**
     * Scopes that are approved during authorization.
     */
    private $_scopes = [];

    public function __construct($id, $name, $email, $type = null, $image = null)
    {
        $this->_id = $id;
        $this->_name = $name;
        $this->_email = $email;
        $this->_image = $image;
        $this->_type = $type;
        $this->_authorization = new Authorization($this);

        $this->set_uuid();
    }

    public function __sleep()
    {
        // Don't store authorization class in DB */
        $keys = get_object_vars($this);
        unset($keys['_authorization']);

        return array_keys($keys);
    }

    public function __wakeup()
    {
        $this->_authorization = new Authorization($this);

        // Add old default scopes for accounts that don't yet have scopes stored
        $old_scopes = [
            'offline_access',
            'Files.ReadWrite.All',
            'User.Read',
            'Sites.ReadWrite.All',
        ];

        if (empty($this->_scopes)) {
            $this->_scopes = $old_scopes;
        }
    }

    public function get_id()
    {
        return $this->_id;
    }

    public function get_uuid()
    {
        if ('Yes' === Settings::get('mask_account_id')) {
            return 'wpcp-'.$this->_uuid;
        }

        return $this->_id;
    }

    public function get_name()
    {
        return $this->_name;
    }

    public function get_email()
    {
        return $this->_email;
    }

    public function get_image()
    {
        if (empty($this->_image)) {
            return SHAREONEDRIVE_ROOTPATH.'/css/images/onedrive_logo.png';
        }

        return $this->_image;
    }

    public function get_scopes()
    {
        if (true === in_array('userread', $this->_scopes)) {
            $this->set_scopes($this->_scopes);
            Accounts::instance()->save();
        }

        if (empty($this->_scopes)) {
            // Add old default scopes for accounts that don't yet have scopes stored
            $old_scopes = [
                'offline_access',
                'Files.ReadWrite.All',
                'User.Read',
                'Sites.ReadWrite.All',
            ];
            $this->_scopes = $old_scopes;
        }

        return apply_filters('shareonedrive_app_scopes', $this->_scopes);
    }

    public function has_scope($scope)
    {
        return in_array($scope, $this->_scopes);
    }

    public function set_id($_id)
    {
        $this->_id = $_id;
    }

    public function set_uuid()
    {
        $this->_uuid = hash_hmac('md5', $this->_id, SHAREONEDRIVE_AUTH_KEY);
    }

    public function set_name($_name)
    {
        $this->_name = $_name;
    }

    public function set_email($_email)
    {
        $this->_email = $_email;
    }

    public function set_image($_image)
    {
        $this->_image = $_image;
    }

    public function get_type()
    {
        return $this->_type;
    }

    public function set_type($_type)
    {
        $this->_type = $_type;
    }

    public function set_scopes($_scopes)
    {
        $this->_scopes = explode(' ', $_scopes);
    }

    /**
     * @return StorageInfo
     */
    public function get_storage_info()
    {
        $transient_name = 'shareonedrive_'.$this->get_id().'_driveinfo';
        $storage_info = get_transient($transient_name);

        if (empty($storage_info)) {
            $storage_info = new StorageInfo();

            if ('service' === $this->get_type()) {
                // Service Accounts don't have any drive data
                $storage_info->set_quota_total(0);
                $storage_info->set_quota_used(0);
            } else {
                App::set_current_account($this);
                $storage_info_data = API::get_space_info();

                $storage_info->set_quota_total($storage_info_data->getQuota()->getTotal());
                $storage_info->set_quota_used($storage_info_data->getQuota()->getUsed());
            }
            set_transient($transient_name, $storage_info, DAY_IN_SECONDS);
        }

        return $storage_info;
    }

    /**
     * @return Authorization
     */
    public function get_authorization()
    {
        return $this->_authorization;
    }

    public function has_drive_access()
    {
        return $this->has_scope('Files.ReadWrite') || $this->has_scope('Files.ReadWrite.All') || $this->has_scope('Sites.ReadWrite.All');
    }

    public function is_drive_readonly()
    {
        return ($this->has_scope('Files.Read') || $this->has_scope('Files.Read.All')) && false === $this->has_scope('Files.ReadWrite') && false === $this->has_scope('Files.ReadWrite.All');
    }
}
