<?php

/**
 * @author WP Cloud Plugins
 * @copyright Copyright (c) 2023, WP Cloud Plugins
 *
 * @since       2.0
 * @see https://www.wpcloudplugins.com
 */

namespace TheLion\ShareoneDrive;

use ZipStream\Option\Archive;
use ZipStream\Option\File;
use ZipStream\Option\Method;
use ZipStream\ZipStream;

defined('ABSPATH') || exit;

class Zip
{
    /**
     * Unique ID.
     *
     * @var string
     */
    public $request_id;

    /**
     * Name of the zip file.
     *
     * @var string
     */
    public $zip_name;

    /**
     * Files that need to be added to ZIP.
     *
     * @var CacheNode[]
     */
    public $entries = [];

    /**
     * Folder paths.
     */
    public $folders = [];

    /**
     * Number of bytes that are downloaded so far.
     *
     * @var int
     */
    public $bytes_so_far = 0;

    /**
     * Bytes that need to be download in total.
     *
     * @var int
     */
    public $bytes_total = 0;

    /**
     * Current status.
     *
     * @var string
     */
    public $current_action = 'starting';

    /**
     * Message describing the current status.
     *
     * @var string
     */
    public $current_action_str = '';

    /**
     * @var CacheNode[]
     */
    public $entries_downloaded = [];

    /**
     * @var ZipStream
     */
    private $_zip_handler;

    /**
     * @var array
     */
    private $_temp_files = [];

    /**
     * @var int
     */
    private $_last_progress_update = 0;

    public function __construct($request_id)
    {
        $this->request_id = $request_id;

        require_once SHAREONEDRIVE_ROOTDIR.'/vendors/ZipStream/vendor/autoload.php';
    }

    public function do_zip()
    {
        $this->initialize();
        $this->current_action_str = esc_html__('Selecting files...', 'wpcloudplugins');
        $this->set_progress('indexing');

        $this->index();
        $this->create();

        do_action('shareonedrive_log_event', 'shareonedrive_downloaded_zip', Processor::instance()->get_requested_entry(), ['name' => $this->zip_name, 'files' => count($this->entries), 'size' => $this->bytes_total]);

        $this->set_progress('downloading');
        $this->add_entries();

        $this->current_action_str = esc_html__('Almost ready', 'wpcloudplugins');
        $this->set_progress('finalizing');
        $this->finalize();

        $this->current_action_str = esc_html__('Finished', 'wpcloudplugins');
        $this->set_progress('finished');

        exit;
    }

    /**
     * Load the ZIP library and make sure that the root folder is loaded.
     */
    public function initialize()
    {
        ignore_user_abort(false);

        // Check if file/folder is cached and still valid
        $cachedfolder = Client::instance()->get_folder();

        if (false === $cachedfolder || false === $cachedfolder['folder']) {
            return new \WP_Error('broke', esc_html__("Requested directory isn't allowed", 'wpcloudplugins'));
        }

        $folder = $cachedfolder['folder']->get_entry();

        // Check if entry is allowed
        if (!Processor::instance()->_is_entry_authorized($cachedfolder['folder'])) {
            return new \WP_Error('broke', esc_html__("Requested directory isn't allowed", 'wpcloudplugins'));
        }

        $this->zip_name = basename($folder->get_name()).'_'.time().'.zip';

        $single_entry = null;

        if (!empty($_REQUEST['files']) && 1 === count($_REQUEST['files'])) {
            $single_entry = Client::instance()->get_entry($_REQUEST['files'][0]);
            $this->zip_name = basename($single_entry->get_name()).'_'.time().'.zip';
        }

        if ($download_limit_hit_message = Restrictions::has_reached_download_limit($single_entry ?? $folder->get_id(), false, 'download_zip')) {
            $this->current_action_str = $download_limit_hit_message;
            $this->set_progress('finished');

            http_response_code(429);

            exit;
        }

        $this->set_progress();

        // Stop WP from buffering, and discard the current buffer.
        $levels = ob_get_level();
        for ($i = 0; $i < $levels; ++$i) {
            ob_end_clean();
        }
    }

    /**
     * Create the ZIP File.
     */
    public function create()
    {
        if (function_exists('apache_setenv')) {
            @apache_setenv('no-gzip', 1);
        }

        @set_time_limit(0);
        @ini_set('max_execution_time', 0);

        @ini_set('zlib.output_compression', 'Off');
        @ini_set('implicit_flush', 1);
        @session_write_close();

        $options = new Archive();
        $options->setSendHttpHeaders(true);
        $options->setFlushOutput(true);
        $options->setContentType('application/octet-stream');
        $options->setDeflateLevel(-1);
        header('X-Accel-Buffering: no');

        // create a new zipstream object
        $this->_zip_handler = new ZipStream(Helpers::filter_filename($this->zip_name), $options);

        $this->_clear_temp_folder();

        register_shutdown_function(function () {
            foreach ($this->_temp_files as $temp_file) {
                if (!empty($temp_file['stream']) && is_resource($temp_file['stream'])) {
                    fclose($temp_file['stream']);
                }
                if (!empty($temp_file['path']) && @file_exists($temp_file['path'])) {
                    @unlink($temp_file['path']);
                }
            }

            // If script was unexpectedly terminated, set status to failed
            if (!in_array($this->current_action, ['finished', 'aborted', 'failed'], true)) {
                $this->current_action_str = esc_html__('ZIP creation failed unexpectedly', 'wpcloudplugins');
                $this->set_progress('failed');
            }
        });
    }

    /**
     * Create a list of files and folders that need to be zipped.
     */
    public function index()
    {
        $requested_ids = [Processor::instance()->get_requested_entry()];

        if (!empty($_REQUEST['files'])) {
            $requested_ids = $_REQUEST['files'];
        }

        foreach ($requested_ids as $fileid) {
            $cached_entry = Client::instance()->get_entry($fileid);

            if (false === $cached_entry) {
                continue;
            }

            $entry = $cached_entry->get_entry();

            $this->folders[] = $cached_entry->get_path(Processor::instance()->get_last_folder());

            if ($entry->is_dir()) {
                $entries_in_dir = Client::instance()->get_folder_recursive($cached_entry);
                $this->entries = array_merge($this->entries, $entries_in_dir);

                foreach ($entries_in_dir as $cached_entry) {
                    $this->bytes_total += $cached_entry->get_entry()->get_size();
                }
            } else {
                $this->entries[] = $cached_entry;
                $this->bytes_total += $entry->get_size();
            }

            $this->current_action_str = esc_html__('Selecting files...', 'wpcloudplugins').' ('.count($this->entries).')';
            $this->set_progress();
        }
    }

    /**
     * Add all requests files to Zip file.
     */
    public function add_entries()
    {
        if (count($this->entries) > 0) {
            foreach ($this->entries as $key => $cached_entry) {
                // Check if user is still connected
                if (connection_aborted()) {
                    $this->set_progress('aborted');

                    break;
                }

                // Skip file if the download limit is reached
                if ($download_limit_hit_message = Restrictions::has_reached_download_limit($cached_entry->get_id(), false)) {
                    $fileOptions = new File();
                    $fileOptions->setComment($download_limit_hit_message);

                    $relative_path = $cached_entry->get_path(Processor::instance()->get_last_folder());

                    $this->_zip_handler->addFile(trim($relative_path, '/').'.download-limit-exceeded', '', $fileOptions);

                    unset($this->entries[$key]);

                    continue;
                }

                $this->add_entry_to_zip($cached_entry);

                unset($this->entries[$key]);
                $this->entries_downloaded[] = $cached_entry;

                do_action('shareonedrive_log_event', 'shareonedrive_downloaded_entry', $cached_entry, ['as_zip' => true]);

                $this->current_action_str = esc_html__('Downloading...', 'wpcloudplugins').'<br/>('.Helpers::bytes_to_size_1024($this->bytes_so_far).' / '.Helpers::bytes_to_size_1024($this->bytes_total).')';
                $this->set_progress();
            }
        }
    }

    /**
     * Download the request file and add it to the ZIP.
     */
    public function add_entry_to_zip(CacheNode $cached_entry)
    {
        // Make the path of the files relative
        foreach ($this->folders as $folder) {
            $relative_path = $cached_entry->get_path(Processor::instance()->get_last_folder());
            if (0 === strpos($relative_path, $folder)) {
                $relative_path = str_replace($folder, '/'.basename($folder), $relative_path);

                break;
            }
        }

        $fileOptions = new File();

        if (!empty($cached_entry->get_entry()->get_last_edited())) {
            $date = new \DateTime();
            $date->setTimestamp(strtotime($cached_entry->get_entry()->get_last_edited()));
            $fileOptions->setTime($date);
        }

        $fileOptions->setComment((string) $cached_entry->get_entry()->get_description());
        $fileOptions->setMethod(Method::STORE());

        if ($cached_entry->get_entry()->is_dir()) {
            $this->_zip_handler->addFile(ltrim($relative_path, '/'), '');

            return;
        }

        // Download the File
        // Update the time_limit as this can take a while
        Helpers::set_time_limit(0);

        // Get Download Url
        $download_url = API::create_temporarily_download_url($cached_entry->get_id());

        if (false === $download_url) {
            return;
        }

        // Get file
        $request = new \SODOneDrive_Http_Request($download_url, 'GET');

        $tmpfname = tempnam(sys_get_temp_dir(), 'WPC-');

        if (false === $tmpfname) {
            Helpers::log_error('Cannot create temp file', 'Zip', null, __LINE__);

            return;
        }

        $download_stream = fopen($tmpfname, 'w+b');
        $this->_temp_files[] = ['stream' => $download_stream, 'path' => $tmpfname];
        $stream_meta_data = stream_get_meta_data($download_stream);

        $bytes_before = $this->bytes_so_far;
        $self = $this;

        App::instance()->get_sdk_client()->getIo()->setOptions(
            [
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_RETURNTRANSFER => false,
                CURLOPT_FILE => $download_stream,
                CURLOPT_HEADER => false,
                CURLOPT_CONNECTTIMEOUT => null,
                CURLOPT_TIMEOUT => null,
                CURLOPT_NOPROGRESS => false,
                CURLOPT_PROGRESSFUNCTION => function ($curl, $download_total, $downloaded, $upload_total, $uploaded) use ($self, $bytes_before) {
                    if (time() - $self->_last_progress_update < 1) {
                        return connection_aborted() ? 1 : 0;
                    }

                    $self->_last_progress_update = time();

                    $self->current_action_str = esc_html__('Downloading...', 'wpcloudplugins')
                        .'<br/>('.Helpers::bytes_to_size_1024($bytes_before + $downloaded)
                        .' / '.Helpers::bytes_to_size_1024($self->bytes_total).')';
                    $this->bytes_so_far = $bytes_before + $downloaded;
                    $self->set_progress();

                    return connection_aborted() ? 1 : 0;
                },
            ]
        );

        try {
            if (false !== strpos($download_url, 'tempauth')) {
                // Download url has own token
                $request->enableExpectedRaw();
                App::instance()->get_sdk_client()->execute($request);
            } else {
                // Download url requires authorization
                App::instance()->get_sdk_client()->getAuth()->authenticatedRequest($request);
            }

            curl_close(App::instance()->get_sdk_client()->getIo()->getHandler());
        } catch (\Exception $ex) {
            fclose($download_stream);
            @unlink($stream_meta_data['uri']);
            Helpers::log_error('Not able to stream file', 'ZIP', null, __LINE__, $ex);

            exit;
        } finally {
            App::instance()->get_sdk_client()->getIo()->clearOptions();
        }

        rewind($download_stream);

        $this->bytes_so_far = $bytes_before + $cached_entry->get_entry()->get_size();

        // Add file contents to zip
        try {
            $this->_zip_handler->addFileFromStream(trim($relative_path, '/'), $download_stream, $fileOptions);
        } catch (\Exception $ex) {
            fclose($download_stream);
            @unlink($stream_meta_data['uri']);
            array_pop($this->_temp_files);
            Helpers::log_error('Cannot add file to ZIP.', 'Zip', null, __LINE__, $ex);

$this->set_progress('failed');

            exit;
        }

        fclose($download_stream);
        @unlink($stream_meta_data['uri']);
        array_pop($this->_temp_files);
    }

    /**
     * Finalize the zip file.
     */
    public function finalize()
    {
        $this->set_progress();

        // Close zip
        $this->_zip_handler->finish();

        // Send email if needed
        if ('1' === Processor::instance()->get_shortcode_option('notificationdownload')) {
            Processor::instance()->send_notification_email('download', $this->entries_downloaded);
        }

        // Download Zip Hook
        do_action('shareonedrive_download_zip', $this->entries_downloaded);
    }

    /**
     * Received progress information for the ZIP process from database.
     *
     * @param string $request_id
     */
    public static function get_progress($request_id)
    {
        return get_transient('shareonedrive_zip_'.substr($request_id, 0, 40));
    }

    /**
     * Set current progress information for ZIP process in database.
     *
     * @param null|mixed $action
     */
    public function set_progress($action = null)
    {
        if (!empty($action)) {
            $this->current_action = $action;
        }

        $status = [
            'id' => $this->request_id,
            'status' => [
                'bytes_so_far' => $this->bytes_so_far,
                'bytes_total' => $this->bytes_total,
                'percentage' => ($this->bytes_total > 0) ? (round(($this->bytes_so_far / $this->bytes_total) * 100)) : 0,
                'progress' => $this->current_action,
                'progress_str' => $this->current_action_str,
            ],
        ];

        // Update progress
        return set_transient('shareonedrive_zip_'.substr($this->request_id, 0, 40), $status, HOUR_IN_SECONDS);
    }

    /**
     * Get progress information for the ZIP process
     * Used to display a progress percentage on Front-End.
     *
     * @param string $request_id
     */
    public static function get_status($request_id)
    {
        // Try to get the upload status of the file
        for ($_try = 1; $_try < 6; ++$_try) {
            $result = self::get_progress($request_id);

            if (false !== $result) {
                if ('failed' === $result['status']['progress'] || 'finished' === $result['status']['progress']) {
                    delete_transient('shareonedrive_zip_'.substr($request_id, 0, 40));
                }

                break;
            }

            // Wait a moment, perhaps the upload still needs to start
            usleep(500000 * $_try);
        }

        if (false === $result) {
            $result = ['file' => false, 'status' => ['bytes_down_so_far' => 0, 'total_bytes_down_expected' => 0, 'percentage' => 0, 'progress' => 'failed']];
        }

        echo json_encode($result);

        exit;
    }

    /**
     * Clear temporary files older than specific number of hours.
     *
     * @param int $max_age_hours
     */
    private function _clear_temp_folder($max_age_hours = 1)
    {
        // Define the temp directory and file pattern
        $temp_dir = rtrim(sys_get_temp_dir(), DIRECTORY_SEPARATOR).DIRECTORY_SEPARATOR;
        $file_pattern = $temp_dir.'WPC-*';

        // Define the age limit
        $max_age = $max_age_hours * 3600;
        $current_time = time();

        // Get all files matching the pattern
        $files = glob($file_pattern);

        if (false !== $files) {
            foreach ($files as $file) {
                // Check if it's a file and not a directory
                if (is_file($file)) {
                    // Get the file's modification time
                    $file_mod_time = filemtime($file);
                    if (false !== $file_mod_time && ($current_time - $file_mod_time) > $max_age) {
                        // Attempt to delete the file
                        @unlink($file);
                    }
                }
            }
        }
    }
}
