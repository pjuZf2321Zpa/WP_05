=== Ajax Search Pro ===
Contributors: wpdreams
Tags: search, ajax, live
Donate link: https://ajaxsearchpro.com/
Requires at least: 6.0
Tested up to: 7.0
Requires PHP: 7.4
Stable tag: 4.29.6

Most powerful WordPress Search Engine