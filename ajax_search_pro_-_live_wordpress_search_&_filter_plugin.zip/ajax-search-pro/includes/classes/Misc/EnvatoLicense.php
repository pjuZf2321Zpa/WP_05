<?php

namespace WPDRMS\ASP\Misc;

if ( !defined('ABSPATH') ) {
	die("You can't access this file directly.");
}

/**
 * Class only kept to avoid a fatal error during an update from 4.26.x
 *
 * 4.26.x keeps running in the request that replaces it with this build, and its updater looks for this class here.
 * Nothing in this build uses it, and it must not touch the stored licence: this build migrates that itself.
 *
 * @deprecated 4.26.16
 */
class EnvatoLicense {
	public static function isActivated(): bool {
		return false;
	}

	public static function deactivate(): bool {
		return false;
	}
}
