<?php /** @noinspection HttpUrlsUsage */

namespace WPDRMS\ASP\Misc;

/**
 * Class only kept to avoid fatal errors during activation
 *
 * @deprecated 4.27
 */
class OutputBuffer {

	public static function getInstance(): self {
		return new self();
	}

	public function obStart(): void {}

	public function obClose(): bool {
		return false;
	}

	public function obFound(): bool {
		return false;
	}
}
