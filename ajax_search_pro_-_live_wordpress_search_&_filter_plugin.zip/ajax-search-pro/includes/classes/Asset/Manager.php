<?php

namespace WPDRMS\ASP\Asset;

if ( !defined('ABSPATH') ) {
	die("You can't access this file directly.");
}

/**
 * Class only kept to avoid a fatal error during an update from 4.26.x
 *
 * 4.26.x keeps running in the request that replaces it with this build, and its hooks look for this class here: on
 * shutdown, and in the admin footer of the update screens. Nothing in this build uses it.
 *
 * @deprecated 4.26.16
 */
class Manager {
	public static function _o(): self {
		return new self();
	}

	public function enqueue(): void {}

	public function onPluginFooter(): void {}

	public function onPluginBackendFooter(): void {}

	public function printBackup(): void {}

	/**
	 * @param string $buffer
	 * @return string
	 */
	public function injectToBuffer( $buffer ) {
		return $buffer;
	}
}
