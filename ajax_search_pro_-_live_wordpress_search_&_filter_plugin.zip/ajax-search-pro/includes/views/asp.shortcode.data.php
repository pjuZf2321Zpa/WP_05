<?php
/* Prevent direct access */
defined('ABSPATH') or die("You can't access this file directly.");
?>
<div class='asp_hidden_data' style="display:none !important;">
    <div class='asp_item_overlay'>
        <div class='asp_item_inner'>
            <?php
            if (w_isset_def($style['i_res_custom_magnifierimage'], "") == "") {
                // SECURITY: only a shipped SVG is read, see Icon::svg()
                echo \WPDRMS\ASP\Utils\Icon::svg(w_isset_def($style['i_res_magnifierimage'], "/ajax-search-pro/img/svg/magnifiers/magn4.svg"));
            } else {
                echo "<img src='" . esc_url($style['i_res_custom_magnifierimage']) . "'>";
            }
            ?>
            <?php do_action('asp_layout_in_loading', $id); ?>
        </div>
    </div>
</div>