/******/ (function() { // webpackBootstrap
/******/ 	"use strict";
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	!function() {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = function(exports, definition) {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	!function() {
/******/ 		__webpack_require__.o = function(obj, prop) { return Object.prototype.hasOwnProperty.call(obj, prop); }
/******/ 	}();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": function() { return /* binding */ asp_ga; }
});

;// external "AjaxSearchPro"
var external_AjaxSearchPro_namespaceObject = Object(window.WPD)["AjaxSearchPro"];
;// external "DoMini"
var external_DoMini_namespaceObject = Object(window.WPD)["DoMini"];
;// ./src/client/plugin/core/actions/ga_events.js



"use strict";
const ASP = window.ASP;
external_AjaxSearchPro_namespaceObject.plugin.gaEvent = function(which, d) {
  let $this = this;
  if (typeof ASP.analytics == "undefined" || !ASP.analytics.method)
    return;
  let _gtag = typeof window.gtag === "function" ? window.gtag : false;
  if (_gtag === false && typeof window.dataLayer === "undefined")
    return;
  let tracking_id = $this.gaGetTrackingID();
  let def_data = {
    "search_id": $this.o.id,
    "search_name": $this.n("search").data("name"),
    "phrase": $this.n("text").val(),
    "option_label": "",
    "option_value": "",
    "result_title": "",
    "result_url": "",
    "results_count": ""
  };
  const mergedData = external_DoMini_namespaceObject.fn.extend({}, def_data, d);
  const items = ASP.analytics.event[which]?.items ?? [];
  for (const ev of items) {
    if (!ev.active) continue;
    const eventParams = { "send_to": "" };
    for (const p of ev.params ?? []) {
      if (!p.key) continue;
      let val = p.value;
      Object.keys(mergedData).forEach(function(k) {
        const v = String(mergedData[k]).replace(/[\s\n\r]+/g, " ").trim();
        val = val.replace(new RegExp("\\{" + k + "\\}", "gmi"), v);
      });
      eventParams[p.key] = val;
    }
    if (_gtag !== false) {
      if (tracking_id !== false) {
        tracking_id.forEach(function(id) {
          eventParams.send_to = id;
          _gtag("event", ev.action, eventParams);
        });
      } else {
        delete eventParams.send_to;
        _gtag("event", ev.action, eventParams);
      }
    } else if (typeof window.dataLayer?.push !== "undefined") {
      window.dataLayer.push({
        "event": "gaEvent",
        "eventAction": ev.action,
        ...eventParams
      });
    }
  }
};
external_AjaxSearchPro_namespaceObject.plugin.gaGetTrackingID = function() {
  if (typeof ASP.analytics === "undefined") {
    return false;
  }
  if (ASP.analytics.tracking_id) {
    return [ASP.analytics.tracking_id];
  }
  return false;
};
/* harmony default export */ var ga_events = ((/* unused pure expression or super */ null && (AjaxSearchPro)));

;// ./src/client/bundle/optimized/asp-ga.js



/* harmony default export */ var asp_ga = (external_AjaxSearchPro_namespaceObject);

Object(window.WPD).AjaxSearchPro = __webpack_exports__["default"];
/******/ })()
;