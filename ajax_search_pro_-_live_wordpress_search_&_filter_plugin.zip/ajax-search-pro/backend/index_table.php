<?php
if ( !defined('ABSPATH') ) {
	die("You can't access this file directly.");
}

use WPDRMS\Utils\Script;

?>
<div class="wdo" id="wdo"><div id="asp-root"></div></div>
<?php

$metadata = require_once ASP_PATH . 'build/css/wdo-global.asset.php';
wp_enqueue_style(
	'wpo-global',
	ASP_URL_NP . 'build/css/wdo-global.css',
	$metadata['dependencies'],
	$metadata['version'],
);

$metadata = require_once ASP_PATH . 'build/js/index-table.asset.php';
wp_enqueue_script(
	'wpd-asp-index-table',
	ASP_URL_NP . 'build/js/index-table.js',
	$metadata['dependencies'],
	$metadata['version'],
	array( 'in_footer' => true ),
);

$metadata = require_once __DIR__ . '/global.asset.php';
Script::objectToInlineScript(
	'wpd-asp-index-table',
	'ASP_BACKEND',
	$metadata['ASP_BACKEND'],
	'before',
	true,
);
Script::objectToInlineScript(
	'wpd-asp-index-table',
	'wpdrmsAdminUi',
	$metadata['wpdrmsAdminUi'],
	'before',
	true,
);
