<div class="wdo" id="wdo"><div id="asp-root"></div></div>
<?php

use WPDRMS\Utils\Script;

$metadata = require_once ASP_PATH . 'build/css/wdo-global.asset.php';
wp_enqueue_style(
	'wpo-global',
	ASP_URL_NP . 'build/css/wdo-global.css',
	$metadata['dependencies'],
	$metadata['version'],
);

$metadata = require_once ASP_PATH . 'build/js/maintenance.asset.php';
wp_enqueue_script(
	'wpd-asp-maintenance',
	ASP_URL_NP . 'build/js/maintenance.js',
	$metadata['dependencies'],
	$metadata['version'],
	array( 'in_footer' => true ),
);

$metadata = require_once __DIR__ . '/global.asset.php';
Script::objectToInlineScript(
	'wpd-asp-maintenance',
	'ASP_BACKEND',
	$metadata['ASP_BACKEND'],
	'before',
	true,
);
Script::objectToInlineScript(
	'wpd-asp-maintenance',
	'wpdrmsAdminUi',
	$metadata['wpdrmsAdminUi'],
	'before',
	true,
);
