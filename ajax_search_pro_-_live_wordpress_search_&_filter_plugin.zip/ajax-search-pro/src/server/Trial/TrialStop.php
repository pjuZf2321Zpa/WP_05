<?php
namespace WPDRMS\ASP\Trial;

use WPDRMS\ASP\Utils\Ajax;

if ( !defined('ABSPATH') ) {
	die('-1');
}

/**
 * What an ended trial does outside wp-admin: the plugin acts as if it were switched off.
 */
class TrialStop {

	/**
	 * True when the trial has ended and the context is not one of the plugin's back-end screens.
	 *
	 * @param string $context One of the Manager contexts.
	 */
	public static function active( string $context ): bool {
		if ( is_admin() && ( $context === 'backend' || $context === 'global_backend' ) ) {
			return false;
		}
		return TrialGate::state() === TrialGate::ENDED;
	}

	/**
	 * Registers the stub for the search action only, so a cached page's search box gets an empty
	 * answer instead of an error. Every other plugin action stays unregistered.
	 *
	 * @param bool $custom_ajax True for the custom handler's ASP_ prefix, false for wp_ajax_.
	 */
	public static function registerAjaxStub( bool $custom_ajax ): void {
		$prefix = $custom_ajax ? 'ASP_' : 'wp_ajax_';
		add_action( $prefix . 'ajaxsearchpro_search', array( self::class, 'ajaxStub' ) );
		add_action( $prefix . 'nopriv_ajaxsearchpro_search', array( self::class, 'ajaxStub' ) );
	}

	/**
	 * The search action while stopped: the reply the search gives an unknown instance, with both
	 * `results` and `html` present, which the front-end script needs. Takes no parameter: hook callbacks
	 * may not declare typed ones.
	 */
	public static function ajaxStub(): void {
		Ajax::prepareHeaders('application/json');
		echo wp_json_encode(
			array(
				'html'               => '',
				'results_count'      => 0,
				'full_results_count' => 0,
				'lang'               => '',
				'results'            => array(),
			)
		);
		if ( wp_doing_ajax() ) {
			wp_die( '', '', array( 'response' => 200 ) );
		}
		die();
	}

	/**
	 * Shortcode handler for every plugin tag while stopped: nothing for visitors, a note for admins.
	 *
	 * @param mixed $atts    Unused.
	 * @param mixed $content Unused.
	 * @param mixed $tag     Unused.
	 */
	public static function shortcode( $atts = array(), $content = '', $tag = '' ): string { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter
		if ( !current_user_can('manage_options') ) {
			return '';
		}
		return '<p class="asp_trial_ended_note">' .
			esc_html__("Your Ajax Search Pro trial ended, so visitors don't see this search box. Only admins see this note.", 'ajax-search-pro') .
			' <a href="' . esc_url(admin_url('admin.php?page=asp_updates_help')) . '">' .
			esc_html__('Fix this', 'ajax-search-pro') . '</a></p>';
	}
}
