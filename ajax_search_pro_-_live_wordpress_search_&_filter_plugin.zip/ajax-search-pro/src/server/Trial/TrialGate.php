<?php
namespace WPDRMS\ASP\Trial;

if ( !defined('ABSPATH') ) {
	die('-1');
}

/**
 * Where a trial stands, from the stored record and the clock. No remote call.
 */
class TrialGate {

	public const NONE     = 'none';
	public const RUNNING  = 'running';
	public const ENDING   = 'ending';
	public const LAST_DAY = 'last_day';
	public const ENDED    = 'ended';

	/** Seconds left at or below which the trial is ending. */
	private const ENDING_WITHIN = 259200;

	/** Seconds left at or below which it is the last day. */
	private const LAST_DAY_WITHIN = 86400;

	/** @var array{key: string, ends_at: int, sig: string}|null */
	private static $record = null;

	private static bool $loaded = false;

	public static function state( ?int $now = null ): string {
		$ends_at = self::endsAt();
		if ( $ends_at === null ) {
			return self::NONE;
		}
		$left = $ends_at - ( $now ?? time() );
		if ( $left <= 0 ) {
			return self::ENDED;
		}
		if ( $left <= self::LAST_DAY_WITHIN ) {
			return self::LAST_DAY;
		}
		if ( $left <= self::ENDING_WITHIN ) {
			return self::ENDING;
		}
		return self::RUNNING;
	}

	public static function endsAt(): ?int {
		if ( ! self::$loaded ) {
			self::$record = TrialRecord::get();
			self::$loaded = true;
		}
		return self::$record === null ? null : self::$record['ends_at'];
	}

	/**
	 * Forgets what was read, so the next call reads the record again.
	 */
	public static function reset(): void {
		self::$record = null;
		self::$loaded = false;
	}
}
