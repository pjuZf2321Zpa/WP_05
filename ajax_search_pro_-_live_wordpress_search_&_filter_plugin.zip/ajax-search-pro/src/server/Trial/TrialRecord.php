<?php
namespace WPDRMS\ASP\Trial;

use WPDRMS\ASP\Misc\PluginLicense;

if ( !defined('ABSPATH') ) {
	die('-1');
}

/**
 * The signed end date of a trial licence, kept apart from the licence record
 * so that deactivating the licence does not lift it.
 */
class TrialRecord {

	public const OPTION = 'asp_trial_data';

	private const MESSAGE_PREFIX = 'wpdreams-trial-v1:';

	/**
	 * The stored record, or null when there is none or it does not verify.
	 *
	 * @return array{key: string, ends_at: int, sig: string}|null
	 */
	public static function get(): ?array {
		$data = get_site_option( self::OPTION );
		if ( ! is_array($data) ) {
			return null;
		}
		$key     = $data['key'] ?? null;
		$ends_at = $data['ends_at'] ?? null;
		$sig     = $data['sig'] ?? null;
		if ( ! is_string($key) || $key === '' || ! is_int($ends_at) || ! is_string($sig) || $sig === '' ) {
			return null;
		}
		if ( ! self::verified($key, $ends_at, $sig) ) {
			return null;
		}
		return array(
			'key'     => $key,
			'ends_at' => $ends_at,
			'sig'     => $sig,
		);
	}

	/**
	 * Takes in a licence server reply for a key.
	 *
	 * A valid trial object writes the record. A success without one clears it.
	 * Anything else, a refusal or an object that does not verify, changes nothing.
	 *
	 * @param string       $key   The key the reply answers for.
	 * @param array<mixed> $reply The decoded reply.
	 */
	public static function fromReply( string $key, array $reply ): void {
		if ( isset($reply['trial']) ) {
			$trial = $reply['trial'];
			if (
				$key !== '' && is_array($trial) &&
				isset($trial['ends_at'], $trial['sig']) &&
				is_int($trial['ends_at']) && is_string($trial['sig']) && $trial['sig'] !== '' &&
				self::verified($key, $trial['ends_at'], $trial['sig'])
			) {
				update_site_option(
					self::OPTION,
					array(
						'key'     => $key,
						'ends_at' => $trial['ends_at'],
						'sig'     => $trial['sig'],
					)
				);
				TrialGate::reset();
			}
			return;
		}

		if ( isset($reply['status']) && (int) $reply['status'] === 1 ) {
			self::clear();
		}
	}

	public static function clear(): void {
		delete_site_option( self::OPTION );
		TrialGate::reset();
	}

	private static function verified( string $key, int $ends_at, string $sig ): bool {
		// Without libsodium nothing can be verified, so no record counts.
		if ( ! function_exists('sodium_crypto_sign_verify_detached') ) {
			return false;
		}
		return PluginLicense::verifySignature( self::MESSAGE_PREFIX . $key . '|' . $ends_at, $sig );
	}
}
