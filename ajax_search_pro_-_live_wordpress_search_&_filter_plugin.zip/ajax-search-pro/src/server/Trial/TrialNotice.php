<?php
namespace WPDRMS\ASP\Trial;

use WPDRMS\ASP\Core\Menu;

if ( !defined('ABSPATH') ) {
	die('-1');
}

/**
 * The countdown bar shown while a trial runs. data() says what it shows. bar() prints that as plain
 * markup with inline colours, for the legacy plugin pages and the rest of wp-admin, which load no
 * bundle. The React pages show TrialBar.tsx from the same data: nothing printed outside .wdo shows there.
 */
class TrialNotice {

	public const BUY_URL = 'https://wp-dreams.com/products/?buy=3357410';

	/** Bar colours: background, border, text. */
	private const COLORS = array(
		'blue'  => array( '#e7f1fa', '#b6d3ec', '#0b3a63' ),
		'amber' => array( '#fcf3dc', '#e6c56f', '#4f3a00' ),
		'red'   => array( '#fbe9ea', '#e6a5a8', '#7a1f22' ),
	);

	/**
	 * What the bar shows for the running trial; null without a record and once the trial has ended.
	 *
	 * @param int|null $now Unix time, for tests.
	 * @return array{tone: string, first: string, then: string, buy_label: string, buy_url: string, key_label: string, key_url: string}|null
	 */
	public static function data( ?int $now = null ): ?array {
		$now   = $now ?? time();
		$state = TrialGate::state($now);
		$end   = TrialGate::endsAt();
		if ( $end === null || $state === TrialGate::NONE || $state === TrialGate::ENDED ) {
			return null;
		}

		if ( $state === TrialGate::LAST_DAY ) {
			$tone  = 'red';
			$first = __('Last day of your trial.', 'ajax-search-pro');
			$day   = wp_date('Y-m-d', $end) === wp_date('Y-m-d', $now) ?
				__('today', 'ajax-search-pro') : __('tomorrow', 'ajax-search-pro');
			$then  = sprintf(
				/* translators: 1: "today" or "tomorrow", 2: the time, like 14:30 */
				__('Search stops %1$s at %2$s unless this site has a licence.', 'ajax-search-pro'),
				$day,
				wp_date('H:i', $end)
			);
		} else {
			$tone  = $state === TrialGate::ENDING ? 'amber' : 'blue';
			$first = sprintf(
				/* translators: %d: number of days */
				__('Trial: %d days left.', 'ajax-search-pro'),
				(int) ceil(( $end - $now ) / 86400)
			);
			$then = sprintf(
				/* translators: %s: a date like 18 November */
				__('Search stops on %s unless this site has a licence.', 'ajax-search-pro'),
				wp_date('j F', $end)
			);
		}

		return array(
			'tone'      => $tone,
			'first'     => $first,
			'then'      => $then,
			'buy_label' => __('Buy a licence', 'ajax-search-pro'),
			'buy_url'   => self::BUY_URL,
			'key_label' => __('I have a key', 'ajax-search-pro'),
			'key_url'   => admin_url('admin.php?page=asp_updates_help#license'),
		);
	}

	/**
	 * The bar for the running trial; empty without a record and once the trial has ended.
	 *
	 * Every part sets its own margin: inside #wpdreams the legacy `.wpdreams *` rule gives the rest margin:auto.
	 *
	 * @param int|null $now    Unix time, for tests.
	 * @param string   $margin The bar's CSS margin.
	 */
	public static function bar( ?int $now = null, string $margin = '0 0 12px' ): string {
		$data = self::data($now);
		if ( $data === null ) {
			return '';
		}

		list($bg, $border, $text) = self::COLORS[ $data['tone'] ];

		return '<div class="asp-trial-bar asp-trial-bar--' . $data['tone'] . '" style="display:flex;flex-wrap:wrap;align-items:center;' .
			'justify-content:space-between;gap:8px 16px;box-sizing:border-box;margin:' . $margin . ';padding:10px 16px;' .
			'background:' . $bg . ';border:1px solid ' . $border . ';border-radius:4px;color:' . $text . ';font-size:14px;line-height:1.4">' .
			'<span class="asp-trial-bar__text" style="margin:0"><strong>' . esc_html($data['first']) . '</strong> ' . esc_html($data['then']) . '</span>' .
			'<span class="asp-trial-bar__actions" style="display:flex;align-items:center;gap:16px;margin:0">' .
			'<a href="' . esc_url($data['buy_url']) . '" target="_blank" rel="noopener" style="display:inline-block;margin:0;padding:6px 14px;' .
			'background:#2271b1;border-radius:3px;color:#fff;font-weight:600;text-decoration:none">' .
			esc_html($data['buy_label']) . '</a>' .
			'<a href="' . esc_url($data['key_url']) . '" style="margin:0;color:' . $text . '">' .
			esc_html($data['key_label']) . '</a>' .
			'</span></div>';
	}

	/**
	 * The asp_admin_notices callback: the bar on the legacy pages, inside #wpdreams, with the margin of the boxes there.
	 *
	 * Takes no parameter: hook callbacks may not declare typed ones. Tests call printLegacy() with a time.
	 */
	public static function legacyNotice(): void {
		self::printLegacy();
	}

	/**
	 * Prints the bar for the legacy pages.
	 *
	 * @param int|null $now Unix time, for tests.
	 */
	public static function printLegacy( ?int $now = null ): void {
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped where it is built.
		echo self::bar($now, '10px');
	}

	/**
	 * The admin_notices callback: the bar across wp-admin for the last 3 days, for administrators,
	 * and never on the plugin's own pages, which show the bar themselves.
	 *
	 * Takes no parameter: hook callbacks may not declare typed ones. Tests call printNotice() with a time.
	 */
	public static function adminNotice(): void {
		self::printNotice();
	}

	/**
	 * Prints the notice.
	 *
	 * @param int|null $now Unix time, for tests.
	 */
	public static function printNotice( ?int $now = null ): void {
		if ( !current_user_can('manage_options') ) {
			return;
		}
		$state = TrialGate::state($now);
		if ( $state !== TrialGate::ENDING && $state !== TrialGate::LAST_DAY ) {
			return;
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Reading the page slug only.
		$page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';
		if ( $page !== '' && in_array($page, Menu::getMenuPages(), true) ) {
			return;
		}
		// The bar is built from escaped parts.
		echo '<div class="notice asp-trial-notice" style="padding:0;border:0;background:none;box-shadow:none">' .
			self::bar($now) . // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			'</div>';
	}
}
