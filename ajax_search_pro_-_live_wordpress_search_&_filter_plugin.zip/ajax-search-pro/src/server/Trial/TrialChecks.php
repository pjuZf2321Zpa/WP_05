<?php
namespace WPDRMS\ASP\Trial;

use WPDRMS\ASP\Misc\PluginLicense;
use WPDRMS\Utils\Server;

if ( !defined('ABSPATH') ) {
	die('-1');
}

/**
 * Asking the licence server about a trial key: on a schedule, near the end, and from the ended screen.
 * It runs in every context, also while the front end is stopped.
 */
class TrialChecks {

	public const HOOK_CHECK = 'asp_trial_check';
	public const HOOK_END   = 'asp_trial_check_end';

	private const THROTTLE_KEY = 'asp_trial_check_at';

	/** Seconds between two checks made by opening an admin page. */
	private const THROTTLE = 60;

	/** The single check runs this long before the end. */
	private const BEFORE_END = 300;

	/** Hourly checks go on this long after the end. */
	private const AFTER_END = 604800;

	/**
	 * Registers the two cron handlers and brings the schedule in step with the record.
	 */
	public static function register(): void {
		add_action( self::HOOK_CHECK, array( self::class, 'cron' ) );
		add_action( self::HOOK_END, array( self::class, 'cron' ) );
		self::maintain();
	}

	/**
	 * The cron handler. It takes no parameter: hook callbacks may not declare typed ones.
	 */
	public static function cron(): void {
		self::ask();
	}

	/**
	 * Asks the server whether the key still stands, and takes the answer in.
	 * A purchase or an extension restores the licence when it is gone. A failed
	 * or unreadable answer changes nothing.
	 *
	 * @param bool $retry True only for the "I bought one, check again" button: a refusal without a
	 *                    trial object then also tries to activate the key (a paid key whose slot was released).
	 * @return bool False when the server gave no usable answer; true when it answered, a refusal included
	 *              (and when there is no record to ask about).
	 */
	public static function ask( bool $retry = false ): bool {
		// Read before fromReply() can clear the record: the key is needed to re-activate.
		$record = TrialRecord::get();
		if ( $record === null ) {
			return true;
		}
		$key = $record['key'];

		$url      = rawurlencode( Server::getHTTPHost() );
		$env      = rawurlencode( Server::getEnvironmentType() );
		$response = wp_remote_get( PluginLicense::$url . 'license/is_active/' . rawurlencode($key) . '/?url=' . $url . '&env_type=' . $env );
		if ( is_wp_error($response) ) {
			return false;
		}
		$code = (int) wp_remote_retrieve_response_code($response);
		if ( $code >= 500 ) {
			return false;
		}
		$reply = json_decode( (string) wp_remote_retrieve_body($response), true );
		if ( ! is_array($reply) ) {
			return false;
		}

		$paid        = isset($reply['status']) && (int) $reply['status'] === 1;
		$has_trial   = isset($reply['trial']);
		$has_licence = PluginLicense::isActivated() !== false;

		if ( $paid && ! $has_trial && ! $has_licence ) {
			// A purchase. The record is kept until the activation works: activate() clears it on success,
			// so a failed activation leaves the site stopped and the next check tries again.
			PluginLicense::activate( $key );
			return true;
		}

		TrialRecord::fromReply( $key, $reply );

		if ( $paid && $has_trial && ! $has_licence ) {
			// An extension after the end: the licence record is gone, so restore it.
			PluginLicense::activate( $key );
		} elseif ( $retry && ! $paid && ! $has_trial ) {
			// The licence record usually survives the end, so this does not depend on it.
			PluginLicense::activate( $key );
		}
		return true;
	}

	/**
	 * Keeps the cron events in step with the record. The record is network-wide while cron is per site:
	 * a network-active plugin schedules on the main site only; one activated on a single site schedules there.
	 *
	 * @param int|null $now The time to use, for tests.
	 */
	public static function maintain( ?int $now = null ): void {
		$ends_at = TrialGate::endsAt();
		if ( $ends_at === null || ( self::networkActive() && ! is_main_site() ) ) {
			self::clearEvent( self::HOOK_CHECK );
			self::clearEvent( self::HOOK_END );
			return;
		}
		$now = $now ?? time();

		if ( $now >= $ends_at ) {
			self::clearEvent( self::HOOK_END );
			if ( $now > $ends_at + self::AFTER_END ) {
				self::clearEvent( self::HOOK_CHECK );
				return;
			}
			self::ensureRecurring( 'hourly', $now );
			return;
		}

		self::ensureRecurring( 'daily', $now );
		// A due event is left alone: moving it from the request that is about to run it would postpone it forever.
		$when = $ends_at - self::BEFORE_END;
		if ( $when > $now && wp_next_scheduled( self::HOOK_END ) !== $when ) {
			wp_clear_scheduled_hook( self::HOOK_END );
			wp_schedule_single_event( $when, self::HOOK_END );
		}
	}

	/**
	 * Called when an admin page opens: while the trial has ended, asks at most once a minute.
	 */
	public static function onAdminPage(): void {
		if ( TrialGate::state() !== TrialGate::ENDED ) {
			return;
		}
		if ( get_site_transient( self::THROTTLE_KEY ) !== false ) {
			return;
		}
		set_site_transient( self::THROTTLE_KEY, 1, self::THROTTLE );
		self::ask();
	}

	private static function networkActive(): bool {
		if ( ! is_multisite() ) {
			return false;
		}
		if ( ! function_exists( 'is_plugin_active_for_network' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		return is_plugin_active_for_network( ASP_PLUGIN_BASE );
	}

	private static function clearEvent( string $hook ): void {
		if ( wp_next_scheduled( $hook ) !== false ) {
			wp_clear_scheduled_hook( $hook );
		}
	}

	private static function ensureRecurring( string $recurrence, int $now ): void {
		if ( wp_get_schedule( self::HOOK_CHECK ) === $recurrence ) {
			return;
		}
		wp_clear_scheduled_hook( self::HOOK_CHECK );
		wp_schedule_event( $now + 60, $recurrence, self::HOOK_CHECK );
	}
}
