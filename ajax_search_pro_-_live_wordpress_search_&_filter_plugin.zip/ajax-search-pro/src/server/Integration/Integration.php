<?php

namespace WPDRMS\ASP\Integration;

use WPDRMS\PluginCore\Interfaces\Registrable;

interface Integration extends Registrable {}
