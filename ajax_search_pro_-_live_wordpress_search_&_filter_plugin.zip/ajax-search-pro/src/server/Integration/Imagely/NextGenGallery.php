<?php

namespace WPDRMS\ASP\Integration\Imagely;

use WP_Error;
use WP_Post;
use WPDRMS\ASP\Integration\Integration;
use WPDRMS\PluginCore\Traits\SingletonTrait;
use WPDRMS\Utils\Arg;
use WPDRMS\ASP\Utils\Imagely\NggImage;

class NextGenGallery implements Integration {
	use SingletonTrait;

	public function register(): void {
		if ( !class_exists('\Imagely\NGG\DataMappers\Image') ) {
			return;
		}
		add_filter('asp_results', array( $this, 'searchResults' ), 10, 4);
		add_filter('asp/utils/advanced-field/raw_value', array( $this, 'resultAdvancedFields' ), 10, 4);
		add_filter('asp/utils/advanced-field/field-types/taxonomy/args', array( $this, 'resultAdvancedFieldsTaxonomy' ), 10, 4);
		add_filter(
			'asp/index/database/get_posts_to_index/query/add_where_post_status',
			array( $this, 'indexTablePostStatusFix' ),
			10,
			2
		);
		add_filter(
			'asp/index/hooks/post_update/allowed_statuses',
			array( $this, 'indexTablePostUpdateFix' ),
			10,
			2
		);
		add_filter(
			'asp/search/index/query/add_where_post_status',
			array( $this, 'indexSearchPostStatusFix' ),
			10,
			2
		);

		add_filter('asp_index_post', array( $this, 'indexTablePost' ), 10, 2);
		add_filter('asp_index_terms', array( $this, 'indexTableTerms' ), 10, 3);
	}

	public function deregister(): void {
		remove_filter('asp_results', array( $this, 'searchResults' ));
		remove_filter('asp/utils/advanced-field/raw_value', array( $this, 'resultAdvancedFields' ));
		remove_filter('asp/utils/advanced-field/field-types/taxonomy/args', array( $this, 'resultAdvancedFieldsTaxonomy' ));
		remove_filter('asp/index/database/get_posts_to_index/query/add_where_post_status', array( $this, 'indexTablePostStatusFix' ));
		remove_filter('asp/search/index/query/add_where_post_status', array( $this, 'indexSearchPostStatusFix' ));
		remove_filter('asp_index_post', array( $this, 'indexTablePost' ) );
		remove_filter('asp_index_terms', array( $this, 'indexTableTerms' ) );
	}

	/**
	 * Fixes live search results
	 *
	 * @hook asp_results
	 * @param mixed $results
	 * @param mixed $search_id
	 * @param mixed $is_ajax
	 * @param mixed $args
	 * @return mixed
	 */
	public function searchResults( $results, $search_id = 0, $is_ajax = false, $args = array() ) {
		// asp_results hands over a SearchQueryArgs (ArrayAccess), not an array
		if ( !is_array($results) || !( is_array($args) || $args instanceof \ArrayAccess ) ) {
			return $results;
		}
		foreach ( $results as $k => $r ) {
			if ( !isset($r->post_type) ) {
				continue;
			}
			if ( $r->post_type === 'ngg_pictures' ) {
				$r->image = NggImage::getImageUrl($r->id);

				if ( count($args['attachment_include_directories']) > 0 ) {
					$found = false;
					foreach ( $args['attachment_include_directories'] as $include_dir ) {
						if ( str_contains( $r->image, $include_dir) ) {
							$found = true;
							break;
						}
					}
					if ( !$found ) {
						unset($results[ $k ]);
						continue;
					}
				}

				foreach ( $args['attachment_exclude_directories'] as $exclude_dir ) {
					if ( str_contains( $r->image, $exclude_dir) ) {
						unset($results[ $k ]);
						continue 2;
					}
				}

				$r->link = $r->image;
			}
		}
		return $results;
	}

	/**
	 * Fixes advanced title and content fields
	 *
	 * @hook asp/utils/advanced-field/raw_value
	 * @param mixed $value
	 * @param mixed $field
	 * @param mixed $result
	 * @param mixed $args
	 * @return mixed
	 */
	public function resultAdvancedFields( $value, $field = '', $result = null, $args = array() ) {
		if ( !is_string($value) || !( $result instanceof \stdClass ) || !is_array($args) ) {
			return $value;
		}
		if (
			$field !== 'result_field' ||
			( $result->post_type ?? '' ) !== 'ngg_pictures'
		) {
			return $value;
		}

		if ( $args['field_name'] === 'title' ) {
			return NggImage::getImageTitle($result->id);
		}

		if ( $args['field_name'] === 'content' ) {
			return NggImage::getImageDescription($result->id);
		}

		return $value;
	}

	/**
	 * Fixes taxonomy term advanced title field
	 *
	 * @hook asp/utils/advanced-field/field-types/taxonomy/args
	 * @param mixed $args
	 * @param mixed $result
	 * @return mixed
	 */
	public function resultAdvancedFieldsTaxonomy( $args, $result = null ) {
		if ( !is_array($args) || !( $result instanceof \stdClass ) ) {
			return $args;
		}
		// Only a gallery image's lookup is redirected: every other result (posts, users, terms) keeps its own terms
		if ( ( $result->post_type ?? '' ) !== 'ngg_pictures' ) {
			return $args;
		}
		$image = NggImage::getImageFromPostId( $result->id );
		if ( $image === null ) {
			return array();
		}

		$args['object_ids'] = $image->pid;
		return $args;
	}

	/**
	 * Allows indexing "draft" ngg_pictures post type for indexed search
	 *
	 * @hook asp/index/database/get_posts_to_index/query/add_where_post_status
	 * @param mixed $add_where
	 * @param mixed $args
	 * @return mixed
	 */
	public function indexTablePostStatusFix( $add_where, $args = array() ) {
		if ( !is_string($add_where) || !is_array($args) || !isset($args['post_types']) || !is_array($args['post_types']) ) {
			return $add_where;
		}
		if ( !in_array('ngg_pictures', $args['post_types'], true) ) {
			return $add_where;
		}

		return $add_where . " OR ( post.post_status = 'draft' AND post.post_type = 'ngg_pictures') ";
	}

	/**
	 * The "draft" ngg_pictures posts are NextGen images, the index engine still returns them
	 *
	 * @hook asp/search/index/query/add_where_post_status
	 * @param mixed $add_where
	 * @param mixed $args
	 * @return mixed
	 */
	public function indexSearchPostStatusFix( $add_where, $args = null ) {
		if ( !is_string($add_where) ) {
			return $add_where;
		}
		return $add_where . " OR ( post.post_status = 'draft' AND post.post_type = 'ngg_pictures' ) ";
	}

	/**
	 * Allows indexing "draft" ngg_pictures post type when they are saved
	 *
	 * @hook asp/index/hooks/post_update/allowed_statuses
	 * @param mixed $allowed_statuses
	 * @param mixed $post_id
	 * @return mixed
	 */
	public function indexTablePostUpdateFix( $allowed_statuses, $post_id = 0 ) {
		$post_id = Arg::positiveInt($post_id);
		if ( !is_array($allowed_statuses) || $post_id === null ) {
			return $allowed_statuses;
		}
		$post_type = get_post_type($post_id);
		if ( $post_type === 'ngg_pictures' ) {
			$allowed_statuses[] = 'draft';
			$allowed_statuses   = array_unique($allowed_statuses);
		}

		return $allowed_statuses;
	}

	/**
	 * Fixes post fields on index table process
	 *
	 * @hook asp_index_post
	 * @param mixed $post
	 * @param mixed $args
	 * @return mixed WP_Post|null for a post, any other value untouched
	 */
	public function indexTablePost( $post, $args = array() ) {
		if ( !( $post instanceof WP_Post ) || !is_array($args) ) {
			return $post;
		}
		if ( $post->post_type !== 'ngg_pictures' ) {
			return $post;
		}
		$file_url = NggImage::getImageUrl( $post->ID );
		if ( count($args['attachment_include_directories']) > 0 ) {
			$found = false;
			foreach ( $args['attachment_include_directories'] as $include_dir ) {
				if ( str_contains( $file_url, $include_dir) ) {
					$found = true;
					break;
				}
			}
			if ( !$found ) {
				return null;
			}
		}
		foreach ( $args['attachment_exclude_directories'] as $exclude_dir ) {
			if ( str_contains( $file_url, $exclude_dir) ) {
				return null;
			}
		}
		$post->post_title   = NggImage::getImageTitle( $post->ID );
		$post->post_content =
			NggImage::getImageDescription( $post->ID ) . ' ' .
			NggImage::getImageFileName( $post->ID );

		return $post;
	}

	/**
	 * Fixes taxonomy term indexing for ngg_tag
	 *
	 * @param mixed $terms
	 * @param mixed $taxonomy
	 * @param mixed $post
	 * @return mixed
	 */
	public function indexTableTerms( $terms, $taxonomy = '', $post = null ) {
		if ( !is_string($taxonomy) || !( $post instanceof WP_Post ) ) {
			return $terms;
		}
		if ( $post->post_type !== 'ngg_pictures' || $taxonomy !== 'ngg_tag' ) {
			return $terms;
		}
		return NggImage::getImageTags( $post->ID );
	}
}
