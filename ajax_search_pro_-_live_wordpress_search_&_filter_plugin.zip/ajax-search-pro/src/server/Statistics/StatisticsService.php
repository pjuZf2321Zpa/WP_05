<?php

namespace WPDRMS\ASP\Statistics;

use wpdb;
use WPDRMS\ASP\Query\SearchQueryArgs;
use WPDRMS\PluginCore\Traits\SingletonTrait;
use WPDRMS\ASP\Query\SearchQuery as ASP_SearchQuery;
use WPDRMS\ASP\Statistics\Exporters\InteractionCSVExporter;
use WPDRMS\ASP\Statistics\Exporters\LegacyCSVExporter;
use WPDRMS\ASP\Statistics\Exporters\ResultsCSVExporter;
use WPDRMS\ASP\Statistics\Exporters\SearchCSVExporter;
use WPDRMS\ASP\Statistics\ORM\Interaction;
use WPDRMS\ASP\Statistics\ORM\Result;
use WPDRMS\ASP\Statistics\ORM\Search;
use WPDRMS\ASP\Statistics\ORM\StatisticsOptions;
use WPDRMS\ASP\Statistics\Queries\InteractionQuery;
use WPDRMS\ASP\Statistics\Queries\ResultQuery;
use WPDRMS\ASP\Statistics\Queries\SearchQuery;
use WPDRMS\Utils\MB;
use WPDRMS\Utils\Server;

/**
 * @phpstan-type Searches array<array{
 *     phrase?: string,
 *     page?: int,
 *     asp_id?: int,
 *     device_type?: string,
 *     lang?: string,
 *     found_results?: int,
 *     user_id?: int,
 *     cached?: 1|0,
 *     suggested?: 1|0,
 *     results?: mixed|array<array{id?: int, result_type?: string}>
 * }>
 */
class StatisticsService {
	use SingletonTrait;

	public StatisticsOptions $options;

	/**
	 * @var array<string, int>
	 */
	public static array $result_type_arr = array(
		'pagepost'        => 1,
		'term'            => 2,
		'user'            => 3,
		'blog'            => 4,
		'bp_group'        => 5,
		'bp_activity'     => 6,
		'comment'         => 7,
		'attachment'      => 8,
		'peepso_activity' => 9,
		'peepso_group'    => 10,
	);

	public static int $last_search_id = 0;

	/**
	 * The most searches registerCachedSearchesQueries() stores from one request
	 */
	public const MAX_CACHED_SEARCHES = 20;

	/**
	 * The most found results a reported cached search is stored with
	 */
	public const MAX_FOUND_RESULTS = 1000000;

	/**
	 * @var SearchQuery
	 * @readonly
	 */
	public SearchQuery $search_query;

	public ResultQuery $result_query;
	public InteractionQuery $interaction_query;

	public LegacyCSVExporter $legacy_csv_exporter;
	public SearchCSVExporter $search_csv_exporter;
	public ResultsCSVExporter $results_csv_exporter;
	public InteractionCSVExporter $interaction_csv_exporter;

	private function __construct() {
		$this->search_query             = SearchQuery::instance();
		$this->result_query             = ResultQuery::instance();
		$this->legacy_csv_exporter      = LegacyCSVExporter::instance();
		$this->interaction_query        = InteractionQuery::instance();
		$this->search_csv_exporter      = SearchCSVExporter::instance();
		$this->results_csv_exporter     = ResultsCSVExporter::instance();
		$this->interaction_csv_exporter = InteractionCSVExporter::instance();
	}

	public function loadHooks(): void {
		$this->options = StatisticsOptions::instance();
		if ( $this->options->status->value ) {
			add_action(
				'wp_footer',
				function () {
					?>
					<div id="asp-statistics" data-statistics-id="<?php echo esc_attr(self::$last_search_id); ?>" style="display:none;"></div>
					<?php
				}
			);
			add_action('asp/search/override/args', array( $this, 'searchOverrideArgsHook' ), 99, 4);
			add_action('asp/search/results', array( $this, 'registerSearchAndResultsHook' ), 99, 4);
			add_action('asp/ajax/search/custom_output', array( $this, 'registerCachedSearchesQueriesHook' ), 9999, 6);
			add_action(
				'asp/statistics/retention',
				function () {
					$this->enforceRetention(
						$this->options->data_retention_age->value,
						$this->options->data_retention_max_searches->value
					);
				}
			);
			if ( ! wp_next_scheduled( 'asp/statistics/retention' ) ) {
				wp_schedule_event( time() + 30, 'hourly', 'asp/statistics/retention' );
			}
		} else {
			if ( wp_next_scheduled( 'asp/statistics/retention' ) ) {
				wp_unschedule_event( wp_next_scheduled( 'asp/statistics/retention' ), 'asp/statistics/retention');
			}
			wp_clear_scheduled_hook('asp/statistics/retention');
		}
	}

	/**
	 *
	 * @uses apply_filters('asp/search/override/args', array $args, array $data);
	 *
	 * @param mixed $args array; anything else is passed through
	 * @param mixed $data
	 * @return mixed
	 */
	public function searchOverrideArgsHook( $args, $data = array() ) {
		if ( !is_array($args) ) {
			return $args;
		}
		if ( class_exists('SitePress') && is_array($data) && ( $data['override_count'] ?? null ) === 0 ) {
			$args['record_statistics'] = false;
		}
		return $args;
	}


	/**
	 * @uses apply_filters('asp/search/results', $results, SearchQueryArgs $args, SearchQuery $query);
	 *
	 * @param mixed $results array; anything else is passed through
	 * @param mixed $args    SearchQueryArgs
	 * @param mixed $query   SearchQuery
	 * @return mixed
	 */
	public function registerSearchAndResultsHook( $results, $args = null, $query = null ) {
		if ( !is_array($results) || !( $args instanceof SearchQueryArgs ) || !( $query instanceof ASP_SearchQuery ) ) {
			return $results;
		}
		if ( !$args->record_statistics ) {
			return $results;
		}

		/**
		 * Exclude requests from admin preview
		 */
		$referer = Server::getCleanReferrerPath();
		if ( str_starts_with($referer ?? '', Server::getCleanUrlPath( get_admin_url() ) ?? 'wp-admin/admin.php' ) ) {
			return $results;
		}

		/**
		 * Excluded keywords
		 */
		if ( $args->s !== '' ) {
			foreach ( $this->options->exclude_phrases_partial->value as $excluded_phrase ) {
				if ( str_contains($args->s, $excluded_phrase) ) {
					return $results;
				}
			}

			if ( in_array($args->s, $this->options->exclude_phrases_whole->value, true) ) {
				return $results;
			}
		}

		$search            = new Search();
		$search->phrase    = MB::substr(sanitize_text_field($args->s), 0, $this->options->max_phrase_length->value);
		$search->type      = $args->_ajax_search ? 1 : 0;
		$search->user_id   = get_current_user_id();
		$search->page      = $args->_ajax_search ? ( $args->_call_num === 0 ? 1 : $args->_call_num + 1 ) : $args->page;
		$search->asp_id    = $args->_id > 0 ? $args->_id : null;
		$search->suggested = $args->is_suggestion_query ? 1 : 0;

		if ( !$this->options->record_suggested_searches->value && $search->suggested !== 0 ) {
			return $results;
		}

		if ( is_multisite() ) {
			$search->blog_id = get_current_blog_id();
		}
		switch ( $args->device_type ) {
			case 'tablet':
				$search->device_type = 2;
				break;
			case 'mobile':
				$search->device_type = 3;
				break;
			default:
				$search->device_type = 1;
		}
		if ( $args->_wpml_lang !== '' ) {
			$search->lang = $args->_wpml_lang;
		} elseif ( $args->_polylang_lang !== '' ) {
			$search->lang = $args->_polylang_lang;
		}
		$search->found_results = $query->found_posts;
		$search->referer       = $referer;
		$search                = $search->save();  // Save and return updated model

		if ( !$search ) {
			return $results;
		}

		self::$last_search_id = $search->id;

		if ( $this->options->record_results->value ) {
			$results_arr = array();
			$count       = 0;
			$max_count   = $this->options->record_results_max_count->value;
			foreach ( $results as $result ) {
				$r            = new Result();
				$r->search_id = $search->id;
				/**
				 * $result->ID can be a string, intval() is not redundant
				 */
				$r->result_id = intval( $result->id ?? $result->ID ?? 0 );
				if ( $r->result_id === 0 ) {
					continue;
				}
				$r->result_type = isset($result->content_type, self::$result_type_arr[ $result->content_type ]) ?
					self::$result_type_arr[ $result->content_type ] : 1;
				$results_arr[]  = $r;
				++$count;
				if ( $count >= $max_count ) {
					break;
				}
			}
			if ( !empty($results_arr) ) {
				Result::bulkInsert($results_arr);
			}
		}

		return $results;
	}

	/**
	 * @param mixed $output   The cached output (string); anything else is passed through
	 * @param mixed $id
	 * @param mixed $s
	 * @param mixed $options
	 * @param mixed $call_num
	 * @param mixed $autop
	 * @return mixed
	 */
	public function registerCachedSearchesQueriesHook( $output, $id = 0, $s = '', $options = array(), $call_num = 0, $autop = '' ) {
		if ( !is_string($output) || !is_numeric($id) || !is_scalar($s) || !is_array($options) || !is_numeric($call_num) ) {
			return $output;
		}
		$id       = (int) $id;
		$s        = (string) $s;
		$call_num = (int) $call_num;

		$data = json_decode($output, true);
		if ( empty($data) || !isset($data['results']) || !is_array($data['results']) ) {
			return $output;
		}
		$search_data = array(
			'phrase'        => $s,
			'page'          => $call_num + 1,
			'asp_id'        => $id,
			'device_type'   => $options['device'] ?? '',
			'lang'          => $data['lang'] ?? '',
			'found_results' => $data['full_results_count'] ?? '',
			// The suggestion marker is nested inside `results` -- resultsSuggestions()
			// returns array('suggested' => $posts, ...) and that is what the response
			// carries. There is no top-level `suggested` key (dev #479, #532).
			'suggested'     => isset($data['results']['suggested']) ? 1 : 0,
			'user_id'       => get_current_user_id(),
		);
		if ( isset($data['results']['groups']) && is_array($data['results']['groups']) ) {
			$search_data['results'] = array();
			foreach ( $data['results']['groups'] as $group ) {
				if ( isset($group['items']) && is_array($group['items']) ) {
					foreach ( $group['items'] as $result ) {
						$result_id    = $result['id'] ?? $result['result_id'] ?? 0;
						$content_type = $result['content_type'] ?? $result['result_type'] ?? 'pagepost';

						$exists = false;
						foreach ( $search_data['results'] as $existing_result ) {
							if ( $existing_result['id'] === $result_id ) {
								$exists = true;
								break;
							}
						}

						if ( !$exists ) {
							$search_data['results'][] = array(
								'id'          => $result_id,
								'result_type' => $content_type,
							);
						}
					}
				}
			}
		} else {
			$search_data['results'] = array_filter(
				array_map(
					function ( $result ) {
						return array(
							'id'          => $result['id'] ?? $result['result_id'] ?? 0,
							'result_type' => $result['content_type'] ?? $result['result_type'] ?? 'pagepost',
						);
					},
					$data['results']
				),
				function ( $result ) {
					return $result['id'] > 0;
				}
			);
		}

		$this->registerCachedSearchesQueries(array( $search_data ));

		return $output;
	}


	/**
	 * Records the searches served from the cache, the browser reports them on the public
	 * statistics/searches/add route. Every value is untrusted: at most MAX_CACHED_SEARCHES searches
	 * are stored per call, under the current user, with each field validated.
	 *
	 * @param Searches|array<mixed> $searches
	 * @return void
	 */
	public function registerCachedSearchesQueries( array $searches ): void {
		if ( empty($searches) || !$this->options->status->value ) {
			return;
		}

		/**
		 * Exclude requests from admin preview
		 */
		$referer = Server::getCleanReferrerPath();
		if ( str_starts_with($referer ?? '', Server::getCleanUrlPath( get_admin_url() ) ?? 'wp-admin/admin.php' ) ) {
			return;
		}

		$search_models     = array();
		$results_by_search = array();

		foreach ( array_slice($searches, 0, self::MAX_CACHED_SEARCHES) as $search_data ) {
			if ( !is_array($search_data) ) {
				continue;
			}
			/**
			 * The phrase is what the visitor typed. It is never unserialized or JSON decoded
			 * (Str::anyToString() does both), a serialized object must stay plain text.
			 */
			$phrase = isset($search_data['phrase']) && is_scalar($search_data['phrase']) ? (string) $search_data['phrase'] : '';
			$phrase = sanitize_text_field($phrase);
			/**
			 * Excluded keywords
			 */
			if ( $phrase !== '' ) {
				foreach ( $this->options->exclude_phrases_partial->value as $excluded_phrase ) {
					if ( str_contains($phrase, $excluded_phrase) ) {
						continue 2;
					}
				}

				if ( in_array($phrase, $this->options->exclude_phrases_whole->value, true) ) {
					continue;
				}
			}

			$asp_id = isset($search_data['asp_id']) && is_numeric($search_data['asp_id']) ? intval($search_data['asp_id']) : 0;

			$search            = new Search();
			$search->phrase    = MB::substr($phrase, 0, $this->options->max_phrase_length->value);
			$search->type      = 1;
			$search->user_id   = get_current_user_id(); // A posted user_id is never trusted
			$search->page      = isset($search_data['page']) ? intval($search_data['page']) : 1;
			$search->asp_id    = $asp_id > 0 && wd_asp()->instances->exists($asp_id) ? $asp_id : null;
			$search->cached    = 1;
			$search->suggested = !empty($search_data['suggested']) ? 1 : 0;

			if ( !$this->options->record_suggested_searches->value && $search->suggested !== 0 ) {
				continue;
			}

			if ( is_multisite() ) {
				$search->blog_id = get_current_blog_id();
			}

			if ( isset($search_data['device_type']) ) {
				if ( is_numeric($search_data['device_type']) ) {
					$search->device_type = intval($search_data['device_type']);
					$search->device_type = max(1, min(3, $search->device_type));
				} else {
					switch ( $search_data['device_type'] ) {
						case 'tablet':
							$search->device_type = 2;
							break;
						case 'mobile':
							$search->device_type = 3;
							break;
						default:
							$search->device_type = 1;
					}
				}
			} else {
				$search->device_type = 1;
			}

			$search->lang          = self::validLang($search_data['lang'] ?? null);
			$search->found_results = isset($search_data['found_results']) && is_numeric($search_data['found_results']) ?
				max(0, min(self::MAX_FOUND_RESULTS, intval($search_data['found_results']))) : 0;
			$search->referer       = $referer;

			$search = $search->save();

			if ( $search && isset($search_data['results']) && is_array($search_data['results']) ) {
				$search_models[]                  = $search;
				$results_by_search[ $search->id ] = $search_data['results'];
			}
		}

		if ( $this->options->record_results->value && !empty($search_models) ) {
			$results_arr = array();
			$max_count   = $this->options->record_results_max_count->value;

			foreach ( $search_models as $search ) {
				$count   = 0;
				$results = $results_by_search[ $search->id ] ?? array();

				foreach ( $results as $result ) {
					if ( !is_array($result) ) {
						continue;
					}
					$r            = new Result();
					$r->search_id = $search->id;
					$r->result_id = intval($result['id'] ?? $result['result_id'] ?? 0);

					if ( $r->result_id === 0 ) {
						continue;
					}

					$content_type   = $result['content_type'] ?? $result['result_type'] ?? 'pagepost';
					$r->result_type = is_string($content_type) ? ( self::$result_type_arr[ $content_type ] ?? 1 ) : 1;

					$results_arr[] = $r;
					++$count;

					if ( $count >= $max_count ) {
						break;
					}
				}
			}

			if ( !empty($results_arr) ) {
				Result::bulkInsert($results_arr);
			}
		}
	}

	/**
	 * A reported language code: "en", "fil", "pt_BR", "en-US". Anything else, or a code longer than
	 * the lang column (VARCHAR(5), the insert fails in MySQL strict mode), is not stored.
	 *
	 * @param mixed $lang
	 * @return string|null
	 */
	private static function validLang( $lang ): ?string {
		if (
			!is_string($lang) ||
			strlen($lang) > 5 ||
			preg_match('/^[a-z]{2,3}([_-][A-Za-z]{2,4})?$/D', $lang) !== 1
		) {
			return null;
		}
		return $lang;
	}

	public function createTables(): void {
		Search::createTable();
		Result::createTable();
		Interaction::createTable();
	}

	public function dropTables(): void {
		Search::dropTable();
		Result::dropTable();
		Interaction::dropTable();
	}


	/**
	 * Add an interaction
	 *
	 * @param int    $search_id
	 * @param int    $result_id
	 * @param string $result_type
	 * @return ?Interaction The saved Interaction model
	 */
	public function addInteraction( int $search_id, int $result_id, string $result_type ): ?Interaction {
		if ( $result_id < 1 ) {
			return null;
		}

		$type    = self::$result_type_arr[ $result_type ] ?? 1;
		$results = Result::findBy(
			array(
				'search_id'   => $search_id,
				'result_id'   => $result_id,
				'result_type' => $type,
			),
			1
		);
		if ( empty($results) ) {
			return null;
		}
		$result                 = $results[0];
		$interaction            = new Interaction();
		$interaction->result_id = $result->id;
		$interaction->date      = current_time('mysql'); // @phpstan-ignore-line

		return $interaction->save();
	}

	public function deleteSearch( int $id ): bool {
		global $wpdb;
		$search = Search::find($id);
		if ( $search === null ) {
			return false;
		}
		// A JOIN, not "IN (SELECT …)": see enforceRetention().
		$wpdb->query(
			$wpdb->prepare(
				'DELETE i FROM ' . Interaction::getTableName() . ' i
				JOIN ' . Result::getTableName() . ' r ON r.id = i.result_id
				WHERE r.search_id = %d',
				$search->id
			)
		);
		$wpdb->query(
			$wpdb->prepare(
				'DELETE FROM ' . Result::getTableName() . ' WHERE search_id = %d',
				$search->id
			)
		);
		$search->delete();

		return true;
	}

	public function enforceRetention( string $max_age = '1 year', int $max_searches = 1000000 ): void {
		/**
		 * @var wpdb $wpdb;
		 */
		global $wpdb;

		$allowed_max_age = array( '1 year', '2 year', '1 month', '3 month', '6 month', '1 week', '2 week' );
		if ( !in_array($max_age, $allowed_max_age, true ) ) {
			$max_age = '1 year';
		}

		/*
		 * Multi-table JOIN deletes, never "WHERE col IN (SELECT …)": MariaDB before 11.1 does not
		 * semi-join a single-table DELETE, so the subquery ran once per row of the results table,
		 * a full table scan on every hourly run (dev #536). The JOINs start from the searches'
		 * date index and reach the rows through the results' and interactions' indexes.
		 */
		// phpcs:disable
		// One cut-off for all three tables: a search expiring between two statements would leave its results behind.
		$cutoff = $wpdb->get_var( 'SELECT DATE_SUB(NOW(), INTERVAL ' . $max_age . ')' );
		if ( is_string( $cutoff ) ) {
			$wpdb->query(
				$wpdb->prepare(
					'DELETE i FROM ' . Interaction::getTableName() . ' i
					JOIN ' . Result::getTableName() . ' r ON r.id = i.result_id
					JOIN ' . Search::getTableName() . ' s ON s.id = r.search_id
					WHERE s.date < %s',
					$cutoff
				)
			);
			$wpdb->query(
				$wpdb->prepare(
					'DELETE r FROM ' . Result::getTableName() . ' r
					JOIN ' . Search::getTableName() . ' s ON s.id = r.search_id
					WHERE s.date < %s',
					$cutoff
				)
			);
			$wpdb->query(
				$wpdb->prepare(
					'DELETE FROM ' . Search::getTableName() . ' WHERE date < %s',
					$cutoff
				)
			);
		}

		$count = (int) $wpdb->get_var('SELECT COUNT(*) FROM ' . Search::getTableName());
		if ( $count > $max_searches ) {
			/*
			 * The same N oldest searches in all three statements: the id breaks ties within one
			 * date second. A derived table, since an IN subquery cannot have a LIMIT; one with a
			 * LIMIT is materialised, so the searches statement may read the table it deletes from.
			 */
			$oldest = 'SELECT id FROM ' . Search::getTableName() . ' ORDER BY date ASC, id ASC LIMIT ' . ( $count - $max_searches );
			$wpdb->query(
				'DELETE i FROM ' . Interaction::getTableName() . ' i
				JOIN ' . Result::getTableName() . ' r ON r.id = i.result_id
				JOIN ( ' . $oldest . ' ) o ON o.id = r.search_id'
			);
			$wpdb->query(
				'DELETE r FROM ' . Result::getTableName() . ' r
				JOIN ( ' . $oldest . ' ) o ON o.id = r.search_id'
			);
			$wpdb->query(
				'DELETE s FROM ' . Search::getTableName() . ' s
				JOIN ( ' . $oldest . ' ) o ON o.id = s.id'
			);
		}
		// phpcs:enable
	}

	/**
	 * Deletes all data from the tables with an auto-increment reset
	 *
	 * @return void
	 */
	public function reset(): void {
		Search::truncateTable();
		Result::truncateTable();
		Interaction::truncateTable();
	}
}
