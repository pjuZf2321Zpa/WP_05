<?php

namespace WPDRMS\ASP\Statistics\Exporters;

/**
 * Writes the statistics CSV exports without spreadsheet formula injection.
 *
 * Phrases, referers, languages, user names and titles in the exports come from visitors or users. A
 * spreadsheet runs a cell starting with = + - @ (or a tab / carriage return) as a formula when the
 * export is opened, so such a cell is written with a leading single quote. A plain number or
 * percentage, ex. a negative change rate, can not be a formula and stays as it is.
 */
class SafeCSV {
	/**
	 * @param mixed $value
	 * @return mixed
	 */
	public static function cell( $value ) {
		if ( !is_string($value) || $value === '' ) {
			return $value;
		}
		if ( strpos("=+-@\t\r", $value[0]) === false ) {
			return $value;
		}
		if ( preg_match('/^-?\d+(\.\d+)?%?$/', $value) === 1 ) {
			return $value;
		}
		return "'" . $value;
	}

	/**
	 * Writes the row with fputcsv(), every cell through self::cell()
	 *
	 * @param resource     $handle
	 * @param array<mixed> $row
	 */
	public static function putRow( $handle, array $row ): void {
		fputcsv($handle, array_map(array( self::class, 'cell' ), $row), ',', '"', '\\');
	}
}
