<?php
namespace WPDRMS\ASP\Compatibility\ORM;

use WPDRMS\AdminUI\Data\AbstractOptionDataSiteOption;
use WPDRMS\AdminUI\Options\BoolOption;
use WPDRMS\AdminUI\Options\SelectOption;
use WPDRMS\AdminUI\Options\StringArrayOption;

final class CompatibilityOptions extends AbstractOptionDataSiteOption {
	public StringArrayOption $selective_exin;
	public StringArrayOption $meta_box_post_types;
	public SelectOption $css_compatibility_level;
	public SelectOption $js_source;
	public SelectOption $script_loading_method;
	public SelectOption $css_loading_method;
	public SelectOption $selective_exin_logic;
	public SelectOption $db_force_case;
	public BoolOption $js_prevent_body_scroll;
	public BoolOption $detect_ajax;
	public BoolOption $css_minify;
	public BoolOption $load_google_fonts;
	public BoolOption $usecustomajaxhandler;
	public BoolOption $init_instances_inviewport_only;
	public BoolOption $selective_enabled;
	public BoolOption $selective_front;
	public BoolOption $selective_archive;
	public BoolOption $query_soft_check;
	public BoolOption $use_acf_getfield;
	public BoolOption $db_force_unicode;
	public BoolOption $db_force_utf8_like;
	public BoolOption $rest_api_enabled;

	protected const OPTION_NAME = 'asp_compatibility_options';

	protected const OPTIONS = array(
		'selective_exin'                 => array(
			'type'         => 'string_array',
			'default_args' => array( 'value' => array() ),
		),
		'meta_box_post_types'            => array(
			'type'         => 'string_array',
			'default_args' => array( 'value' => array( 'post', 'page', 'product' ) ),
		),
		'css_compatibility_level'        => array(
			'type'         => 'select',
			'default_args' => array(
				'value'         => 'medium',
				'default_value' => 'medium',
				'options'       => array( 'low', 'medium', 'maximum' ),
			),
		),
		'js_source'                      => array(
			'type'         => 'select',
			'default_args' => array(
				'value'         => 'jqueryless-min',
				'default_value' => 'jqueryless-min',
				'options'       => array( 'jqueryless-nomin', 'jqueryless-min' ),
			),
		),
		'script_loading_method'          => array(
			'type'         => 'select',
			'default_args' => array(
				'value'         => 'optimized',
				'default_value' => 'optimized',
				'options'       => array( 'classic', 'optimized', 'optimized_async' ),
			),
		),
		'css_loading_method'             => array(
			'type'         => 'select',
			'default_args' => array(
				'value'         => 'optimized',
				'default_value' => 'optimized',
				'options'       => array( 'optimized', 'inline', 'file' ),
			),
		),
		'selective_exin_logic'           => array(
			'type'         => 'select',
			'default_args' => array(
				'value'         => 'exclude',
				'default_value' => 'exclude',
				'options'       => array( 'exclude', 'include' ),
			),
		),
		'db_force_case'                  => array(
			'type'         => 'select',
			'default_args' => array(
				'value'         => 'none',
				'default_value' => 'none',
				'options'       => array( 'none', 'sensitivity', 'insensitivity' ),
			),
		),
		'js_prevent_body_scroll'         => array(
			'type'         => 'bool',
			'default_args' => array( 'value' => false ),
		),
		'detect_ajax'                    => array(
			'type'         => 'bool',
			'default_args' => array( 'value' => true ),
		),
		'css_minify'                     => array(
			'type'         => 'bool',
			'default_args' => array( 'value' => true ),
		),
		'load_google_fonts'              => array(
			'type'         => 'bool',
			'default_args' => array( 'value' => true ),
		),
		'usecustomajaxhandler'           => array(
			'type'         => 'bool',
			'default_args' => array( 'value' => false ),
		),
		'init_instances_inviewport_only' => array(
			'type'         => 'bool',
			'default_args' => array( 'value' => true ),
		),
		'selective_enabled'              => array(
			'type'         => 'bool',
			'default_args' => array( 'value' => false ),
		),
		'selective_front'                => array(
			'type'         => 'bool',
			'default_args' => array( 'value' => true ),
		),
		'selective_archive'              => array(
			'type'         => 'bool',
			'default_args' => array( 'value' => true ),
		),
		'query_soft_check'               => array(
			'type'         => 'bool',
			'default_args' => array( 'value' => false ),
		),
		'use_acf_getfield'               => array(
			'type'         => 'bool',
			'default_args' => array( 'value' => true ),
		),
		'db_force_unicode'               => array(
			'type'         => 'bool',
			'default_args' => array( 'value' => false ),
		),
		'db_force_utf8_like'             => array(
			'type'         => 'bool',
			'default_args' => array( 'value' => false ),
		),
		'rest_api_enabled'               => array(
			'type'         => 'bool',
			'default_args' => array( 'value' => false ),
		),
	);
}
