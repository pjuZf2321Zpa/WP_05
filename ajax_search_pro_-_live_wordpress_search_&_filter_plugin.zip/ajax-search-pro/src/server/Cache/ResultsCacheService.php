<?php

namespace WPDRMS\ASP\Cache;

use Exception;
use WPDRMS\ASP\Cache\ORM\CacheOptions;
use WPDRMS\ASP\Cache\Queries\SearchStatisticsQuery;
use WPDRMS\ASP\Query\RequestOptions;
use WPDRMS\PluginCore\Traits\SingletonTrait;

class ResultsCacheService {
	use SingletonTrait;

	const RESULTS_CACHE_DIR = 'results';
	// Every new phrase is an entry: the cap bounds the growth a flood of phrases causes
	const MAX_ENTRIES = 10000;
	// The keyset is fetched on every page view
	const KEYSET_LIMIT = 2000;

	public SearchStatisticsQuery $search_statistics_query;

	private CacheOptions $options;
	private Cache $cache;


	public function __construct() {
		$this->options                 = CacheOptions::instance();
		$this->search_statistics_query = SearchStatisticsQuery::instance();

		if ( $this->options->cache_type->value === 'database' ) {
			$this->cache = new DatabaseCache( $this->options->results_max_age->value );
		} else {
			$this->cache = new FileHybridCache(
				wd_asp()->cache_path,
				self::RESULTS_CACHE_DIR,
				$this->options->results_max_age->value
			);
		}
	}

	public function loadHooks(): void {
		if ( !$this->options->status->value ) {
			if ( wp_next_scheduled( 'asp/cache/retention' ) ) {
				wp_unschedule_event( wp_next_scheduled( 'asp/cache/retention' ), 'asp/cache/retention');
			}
			wp_clear_scheduled_hook('asp/cache/retention');
			return;
		}

		add_action(
			'asp/cache/retention',
			function () {
				$this->clear();
			}
		);
		if ( ! wp_next_scheduled( 'asp/cache/retention' ) ) {
			wp_schedule_event( time() + 60, 'hourly', 'asp/cache/retention' );
		}

		if ( $this->options->clear_on_save->value ) {
			add_action('save_post', array( $this, 'purge' ), 10, 0);
		}

		add_filter(
			'asp/ajax/search/response',
			function ( $response, $id = 0, $s = '', $options = array(), $call_num = 0, $autop = '' ) {
				if ( !is_array($response) || !is_numeric($id) || !is_scalar($s) || !is_array($options) || !is_numeric($call_num) ) {
					return $response;
				}
				if ( !self::cacheable() ) {
					return $response;
				}
				$id           = (int) $id;
				$s            = (string) $s;
				$call_num     = (int) $call_num;
				$new_response = array_merge(
					$response,
					array(
						'created' => time(),
					)
				);
				$file_name    = self::key($id, $s, $options, $call_num, $autop);
				if ( defined('JSON_INVALID_UTF8_IGNORE') ) {
					$text = wp_json_encode(
						$new_response,
						JSON_INVALID_UTF8_IGNORE
					);
				} else {
					$text = wp_json_encode(
						$new_response
					);
				}
				// Over the cap the search is served live, until the retention frees entries
				if ( $text !== false && $this->cache->count() < self::maxEntries() ) {
					try {
						$this->cache->set($file_name, $text, self::scope());
					} catch ( Exception $e ) {
						return $response;
					}
				}
				return $response;
			},
			999,
			6
		);

		add_filter(
			'asp/ajax/search/custom_output',
			function ( $output, $id = 0, $s = '', $options = array(), $call_num = 0, $autop = '' ) {
				if ( !is_string($output) || !is_numeric($id) || !is_scalar($s) || !is_array($options) || !is_numeric($call_num) ) {
					return $output;
				}
				if ( !self::cacheable() ) {
					return $output;
				}
				$id        = (int) $id;
				$s         = (string) $s;
				$call_num  = (int) $call_num;
				$file_name = self::key($id, $s, $options, $call_num, $autop);
				try {
					$content = $this->cache->get($file_name);
					if ( $content !== false ) {
						return $content;
					}
				} catch ( Exception $e ) { // phpcs:ignore
				}

				return '';
			},
			999,
			6
		);
	}

	/**
	 * SECURITY: the visitors share the cached responses, results depend on the user (private posts,
	 * unlocked password protected bodies) and the admin preview uses unsaved instance options. A logged-in
	 * user (an option, on by default) only reads and writes their own entries (scope()). A post password
	 * cookie or the admin preview never uses the cache.
	 */
	public static function cacheable(): bool {
		$cacheable = true;
		if ( is_user_logged_in() ) {
			// Each logged-in user has their own entries (scope())
			$cacheable = CacheOptions::instance()->logged_in_users->value;
		}
		foreach ( array_keys($_COOKIE) as $name ) {
			if ( is_string($name) && strpos($name, 'wp-postpass_') === 0 ) {
				$cacheable = false;
			}
		}
		if ( isset($_POST['asp_preview_options']) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			$cacheable = false;
		}

		/**
		 * Whether the current user's search responses may be cached and served from the cache
		 *
		 * @param bool $cacheable
		 */
		return (bool) apply_filters('asp/results_cache/cacheable', $cacheable);
	}

	/**
	 * The cache scope of the current user: '' for visitors, a keyed hash of the user for logged-in
	 * users, whose entries are their own. The super file cache serves the files to anyone who knows the
	 * name: no one else can compute it without the site's secret, and the keyset only lists it to them.
	 */
	public static function scope(): string {
		if ( !is_user_logged_in() ) {
			return '';
		}
		return substr(
			hash_hmac('sha256', 'asp-results-cache|' . get_current_blog_id() . '|' . get_current_user_id(), wp_salt('auth')),
			0,
			16
		);
	}

	/**
	 * The cache key of a search response. Super file mode computes the same key in the browser
	 * (src/client/plugin/core/actions/search.js getCacheHash(), src/client/global/utils/cache.ts), keep
	 * the two identical.
	 *
	 * Only the posted options the search reads are part of it (RequestOptions): the rest of the request
	 * cannot change the response, so it must not make another entry of the same response. The blog id is
	 * part of the key, the cache directory is shared by every site of a network. The language is part of
	 * $options (wpml_lang, polylang_lang, qtranslate_lang in the settings form). A logged-in user's
	 * scope() ends the key, visitors' keys have none.
	 *
	 * @param int          $id
	 * @param string       $s
	 * @param array<mixed> $options
	 * @param int|string   $call_num
	 * @param int|string   $autop
	 * @return string
	 */
	public static function key( int $id, string $s, array $options, $call_num, $autop ): string {
		$scope = self::scope();
		return substr(
			md5($id . $s . wp_json_encode(RequestOptions::normalize($options)) . $autop . $call_num . '|' . get_current_blog_id() . ( $scope !== '' ? '|' . $scope : '' )),
			0,
			14
		);
	}

	/**
	 * The number of entries the cache stops at
	 */
	public static function maxEntries(): int {
		/**
		 * @param int $max_entries
		 */
		return max(1, (int) apply_filters('asp/results_cache/max_entries', self::MAX_ENTRIES));
	}

	/**
	 * The number of the newest entries the keyset lists
	 */
	public static function keysetLimit(): int {
		/**
		 * @param int $limit
		 */
		return max(1, (int) apply_filters('asp/results_cache/keyset_limit', self::KEYSET_LIMIT));
	}

	public function purge(): int {
		return $this->cache->purge();
	}

	public function delete( string $filename ): bool {
		try {
			return $this->cache->delete($filename);
		} catch ( Exception $e ) {
			return false;
		}
	}

	public function resultsCacheUrl(): string {
		return wd_asp()->cache_url . self::RESULTS_CACHE_DIR . '/';
	}

	/**
	 * The newest of the visitors' entries and the current user's own
	 *
	 * @return string[]
	 */
	public function keySet(): array {
		return $this->cache->keySet(self::scope(), self::keysetLimit());
	}

	public function create(): void {
		$this->cache->create();
	}

	public function destroy(): void {
		$this->cache->destroy();
	}

	public function count(): int {
		return $this->cache->count();
	}

	public function clear(): int {
		return $this->cache->clear();
	}
}
