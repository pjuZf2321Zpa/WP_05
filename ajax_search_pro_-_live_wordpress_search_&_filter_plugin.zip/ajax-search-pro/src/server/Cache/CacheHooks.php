<?php

namespace WPDRMS\ASP\Cache;

use WPDRMS\PluginCore\Interfaces\Registrable;

if ( !defined('ABSPATH') ) {
	die('-1');
}

/**
 * Registers the global cache action hooks.
 *
 * Other domains can invalidate the search results cache without depending on the
 * cache classes directly — they only need to fire the action:
 *
 *     do_action( 'asp/cache/purge' );
 *
 * This keeps the cache an implementation detail and avoids circular dependencies
 * between domains (e.g. Priorities purging the cache after a group is saved).
 */
class CacheHooks implements Registrable {
	public function register(): void {
		add_action('asp/cache/purge', array( $this, 'purge' ), 10, 0);
	}

	public function deregister(): void {
		remove_action('asp/cache/purge', array( $this, 'purge' ), 10);
	}

	/**
	 * Purges all cached search results.
	 */
	public function purge(): void {
		ResultsCacheService::instance()->purge();
	}
}
