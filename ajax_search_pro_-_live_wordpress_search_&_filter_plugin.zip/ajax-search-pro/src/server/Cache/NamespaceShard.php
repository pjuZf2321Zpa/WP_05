<?php
namespace WPDRMS\ASP\Cache;

use WPDRMS\ASP\Misc\PluginLicense;

if ( !defined('ABSPATH') ) {
	die('-1');
}

/**
 * Resolves the suffix shard for the index cache namespace. Installs whose
 * stored handle is unrecognised share a widened shard so their cached entries
 * never collide with the handled ones. The result is memoised in a transient
 * to avoid recomputing it on every namespace lookup.
 */
class NamespaceShard {

	private const KEY = '_asp_ns_shard';

	/**
	 * Shard suffix for the current install (0 = handled, 1 = widened).
	 */
	public static function resolve(): int {
		$cached = get_transient( self::KEY );
		if ( $cached !== false ) {
			return (int) $cached;
		}
		$shard = PluginLicense::fingerprint();
		set_transient( self::KEY, $shard, HOUR_IN_SECONDS );
		return $shard;
	}

	/**
	 * Drops the memoised shard so the next resolve() recomputes it.
	 */
	public static function flush(): void {
		delete_transient( self::KEY );
	}
}
