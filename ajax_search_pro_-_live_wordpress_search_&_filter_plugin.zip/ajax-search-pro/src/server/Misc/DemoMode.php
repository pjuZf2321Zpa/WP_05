<?php

namespace WPDRMS\ASP\Misc;

use WP_Error;
use WP_REST_Request;
use WPDRMS\ASP\Utils\Plugin;
use WPDRMS\PluginCore\Interfaces\Registrable;

if ( !defined('ABSPATH') ) {
	die('-1');
}

/**
 * Adjusts the plugin's admin REST API for demo mode, in two complementary ways.
 *
 * When the site runs in demo mode (`ASP_DEMO`) the admin menu is exposed to any
 * logged-in user (`read` capability, see WPDRMS\ASP\Core\Menu) so visitors can
 * explore the panels. Those non-admin visitors:
 *
 *  1. **must be able to read** every panel — but the admin REST routes guard
 *     themselves with `AbstractRest::allowOnlyAdmins()` (requires `manage_options`),
 *     which would 401 every GET. {@see allowDemoRestReads} hooks the per-plugin
 *     `ajax-search-pro/core/rest/allow_only_admins` / `..._logged_in` filters
 *     (plugin-core ≥ 1.3 derives the filter tag from the namespace a route was
 *     registered under; Core\Manager passes `ASP_DIR` for every route, the shared
 *     admin-ui lookup routes — posts/users/taxonomies/… — included) to grant
 *     read-only (GET/HEAD/OPTIONS) access while the demo lock is active.
 *
 *  2. **must not be able to persist anything**. Every modern admin panel saves
 *     through this plugin's REST namespace (`ASP_DIR`), so a single
 *     `rest_pre_dispatch` guard ({@see blockDemoWrites}) blocks all write requests
 *     centrally. Because the read filter only ever loosens read-only methods, the
 *     `allowOnlyAdmins()` capability check still rejects demo writes too — so even
 *     a future write route registered outside the `ASP_DIR` namespace stays locked.
 *
 * Not affected by the write guard:
 *  - real administrators / super-admins (they satisfy `manage_options`);
 *  - read-only requests (GET / HEAD / OPTIONS), so panels can still be viewed;
 *  - the public front-end search API ({@see \WPDRMS\ASP\Api\Rest0\Rest}), which is
 *    GET-only;
 *  - the `search_instance` endpoints — the per-instance options are the one part
 *    of the admin UI demo visitors are allowed to change. The legacy instance
 *    list and per-instance options editor are plain admin-page POST handlers
 *    (backend/main_settings.php, backend/search.php), not REST, so they are
 *    unaffected too.
 */
class DemoMode implements Registrable {
	/**
	 * HTTP methods that only read state and are therefore safe for demo visitors.
	 */
	private const READ_ONLY_METHODS = array( 'GET', 'HEAD', 'OPTIONS' );

	/**
	 * SECURITY: the shared admin-ui lookup routes live in the plugin's namespace too, and these return what no demo
	 * visitor may see: WP_User objects (password hash, email), draft and private post titles, private post meta, the
	 * server's directories and the network's sites. They stay administrator-only in demo mode; the plugin's own
	 * panels and the public lookups (post types, taxonomies, languages) stay readable.
	 *
	 * @var string[] the route paths below the namespace, prefixes
	 */
	private const ADMIN_ONLY_LOOKUPS = array(
		'options/users/',
		'options/posts/',
		'options/post-meta-keys/',
		'options/post-meta-values/',
		'options/directories/',
		'options/sites/',
	);

	public function register(): void {
		add_filter('rest_pre_dispatch', array( $this, 'blockDemoWrites' ), 10, 3);
		add_filter(ASP_DIR . '/core/rest/allow_only_admins', array( $this, 'allowDemoRestReads' ), 10, 2);
		add_filter(ASP_DIR . '/core/rest/allow_only_logged_in', array( $this, 'allowDemoRestReads' ), 10, 2);
	}

	public function deregister(): void {
		remove_filter('rest_pre_dispatch', array( $this, 'blockDemoWrites' ), 10);
		remove_filter(ASP_DIR . '/core/rest/allow_only_admins', array( $this, 'allowDemoRestReads' ), 10);
		remove_filter(ASP_DIR . '/core/rest/allow_only_logged_in', array( $this, 'allowDemoRestReads' ), 10);
	}

	/**
	 * Grants read-only REST access to demo visitors who would otherwise be rejected by
	 * the admin/logged-in permission callbacks.
	 *
	 * Loosen-only: this only ever returns true (to grant access); it preserves an allow
	 * another handler already produced and never tightens. Access is granted only for
	 * read-only methods while the demo lock is active, so writes still fall through to
	 * the normal capability check (and are blocked there as well as by {@see blockDemoWrites}).
	 *
	 * @param mixed $allowed Whether access has already been granted (a bool; anything else is passed through).
	 * @param mixed $request The current request (a WP_REST_Request).
	 * @return mixed
	 */
	public function allowDemoRestReads( $allowed, $request = null ) {
		if ( !is_bool($allowed) ) {
			return $allowed;
		}

		if ( $allowed ) {
			return true;
		}

		if ( ! Plugin::isDemoWriteLocked() ) {
			return false;
		}

		return $request instanceof WP_REST_Request && $this->isReadOnly( $request ) && ! $this->isAdminOnlyLookup( $request );
	}

	/**
	 * Whether the request is for one of the shared lookup routes that stay administrator-only, see ADMIN_ONLY_LOOKUPS.
	 *
	 * @param WP_REST_Request $request The current request.
	 * @return bool
	 */
	private function isAdminOnlyLookup( WP_REST_Request $request ): bool {
		// The route is /{namespace}/{path}; the namespace is this plugin's, see register()
		$path = (string) preg_replace( '#^/[^/]+/#', '', $request->get_route() );
		foreach ( self::ADMIN_ONLY_LOOKUPS as $prefix ) {
			if ( strpos( $path, $prefix ) === 0 ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Short-circuits write requests to the plugin's admin REST namespace while the
	 * demo write lock is active.
	 *
	 * @param mixed $result  Response to replace the requested version with. Null by default.
	 * @param mixed $server  Server instance (unused).
	 * @param mixed $request Current request (a WP_REST_Request; without one the value passes through).
	 * @return mixed
	 */
	public function blockDemoWrites( $result, $server = null, $request = null ) {
		if ( !( $request instanceof WP_REST_Request ) ) {
			return $result;
		}

		// Respect a short-circuit already set by another handler.
		if ( null !== $result ) {
			return $result;
		}

		if ( ! Plugin::isDemoWriteLocked() ) {
			return $result;
		}

		// Read-only methods are always allowed so the panels can still be viewed.
		if ( $this->isReadOnly( $request ) ) {
			return $result;
		}

		$route = $request->get_route();

		// Only guard this plugin's own admin routes (registered under ASP_DIR).
		if ( 0 !== strpos( $route, '/' . ASP_DIR . '/' ) ) {
			return $result;
		}

		// The per-instance search options are the one admin area demo users may edit.
		if ( false !== strpos( $route, 'search_instance' ) ) {
			return $result;
		}

		return new WP_Error(
			'asp_demo_read_only',
			__( 'Settings cannot be changed while the plugin is running in demo mode.', 'ajax-search-pro' ),
			array( 'status' => 403 )
		);
	}

	/**
	 * Whether the request only reads state (safe to expose to demo visitors).
	 *
	 * @param WP_REST_Request $request The current request.
	 * @return bool
	 */
	private function isReadOnly( WP_REST_Request $request ): bool {
		return in_array( $request->get_method(), self::READ_ONLY_METHODS, true );
	}
}
