<?php

namespace WPDRMS\ASP\Suggest;

use WPDRMS\PluginCore\Interfaces\Registrable;

if ( !defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/**
 * Registers Suggest-domain WordPress hooks. Currently purges the index-table suggestion
 * vocabulary pool whenever a full index rebuild completes, so keyword suggestions never serve
 * a vocabulary that predates the reindex for up to the pool TTL.
 */
class SuggestHooks implements Registrable {
	public const REBUILD_HOOK = 'asp_index_rebuild_complete';

	public function register(): void {
		add_action( self::REBUILD_HOOK, array( SuggestIndexTable::class, 'purgePool' ) );
	}

	public function deregister(): void {
		remove_action( self::REBUILD_HOOK, array( SuggestIndexTable::class, 'purgePool' ) );
	}
}
