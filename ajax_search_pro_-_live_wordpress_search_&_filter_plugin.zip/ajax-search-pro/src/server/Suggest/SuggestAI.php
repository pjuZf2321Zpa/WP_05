<?php

namespace WPDRMS\ASP\Suggest;

use WPDRMS\Utils\Suggest;

defined( 'ABSPATH' ) || die( "You can't access this file directly." );

class SuggestAI extends AbstractSuggest {
	protected $args;

	public function __construct( $args = array() ) {
		$this->args = wp_parse_args(
			$args,
			array(
				'maxCount'  => 10,
				'search_id' => 0,
			)
		);
	}

	public function getKeywords( string $q ): array {
		$asp_id = (int) $this->args['search_id'];
		if ( $asp_id === 0 ) {
			return array();
		}
		$list = get_option( "asp_ai_suggestions_{$asp_id}" );
		if ( empty( $list ) || ! is_array( $list ) ) {
			return array();
		}
		return Suggest::getSimilarText( array_values( $list ), $q, (int) $this->args['maxCount'] );
	}
}
