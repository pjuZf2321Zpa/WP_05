<?php

namespace WPStaging\Core\Utils;

use WPStaging\Framework\Filesystem\Filesystem;

 
if (!defined("WPINC")) {
    die;
}






class IISWebConfig
{
 
    const STATIC_FILE_HANDLER = '<add name="StaticFile" path="*" verb="*" modules="StaticFileModule,DefaultDocumentModule,DirectoryListingModule" resourceType="Either" requireAccess="Read" />';

 
    const STATIC_CONTENT_RULES = [
        '<handlers>',
        '<clear/>',
        self::STATIC_FILE_HANDLER,
        '</handlers>',
        '<staticContent>',
        '<clear/>',
        '<mimeMap fileExtension=".log" mimeType="application/octet-stream" />',
        '<mimeMap fileExtension=".wpstg" mimeType="application/octet-stream" />',
        '<mimeMap fileExtension=".wpstgtmp" mimeType="application/octet-stream" />',
        '</staticContent>',
    ];





    private $filesystem;

    public function __construct()
    {
        $this->filesystem = new Filesystem();
    }







    public function create($path)
    {
        return $this->filesystem->create($path, implode(PHP_EOL, array_merge(['<configuration>', '<system.webServer>'], self::STATIC_CONTENT_RULES, [
            '<defaultDocument>',
            '<files>',
            '<clear/>',
            '<add value="index.php" />',
            '</files>',
            '</defaultDocument>',
            '<directoryBrowse enabled="false" />',
            '</system.webServer>',
            '</configuration>',
        ])));
    }

 
    const DENY_DIRECTIVE = '<deny users="*" />';








    public function createDeny($path)
    {
        return $this->filesystem->create($path, implode(PHP_EOL, [
            '<?xml version="1.0" encoding="UTF-8"?>',
            '<configuration>',
            '<system.webServer>',
            '<handlers>',
            '<clear />',
            '</handlers>',
            '<staticContent>',
            '<clear />',
            '</staticContent>',
            '<security>',
            '<requestFiltering>',
            '<fileExtensions allowUnlisted="false" />',
            '</requestFiltering>',
            '<authorization>',
            '<remove users="*" roles="" verbs="" />',
            self::DENY_DIRECTIVE,
            '</authorization>',
            '</security>',
            '<directoryBrowse enabled="false" />',
            '</system.webServer>',
            '</configuration>',
        ]));
    }
}
