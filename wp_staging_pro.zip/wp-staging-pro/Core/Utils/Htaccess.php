<?php

namespace WPStaging\Core\Utils;

use WPStaging\Framework\Facades\Hooks;
use WPStaging\Framework\Filesystem\Filesystem;

 
if (!defined("WPINC")) {
    die;
}






class Htaccess
{



    const FILTER_CREATE_LITE_SPEED_SERVER_CONFIG = 'wpstg.create_litespeed_server_config';




    const PHP_HANDLER_EXTENSIONS = '.php .php3 .php4 .php5 .php7 .php8 .phtml .phps .phar .pht';

 
    const MOD_MIME_RULES = [
        '<IfModule mod_mime.c>',
        'AddType application/octet-stream .log',
        'AddType application/octet-stream .wpstg',
        'AddType application/octet-stream .wpstgtmp',
        'RemoveHandler ' . self::PHP_HANDLER_EXTENSIONS,
        'RemoveType ' . self::PHP_HANDLER_EXTENSIONS,
        '</IfModule>',
    ];

 
    const PHP_FILES_BLOCK_DIRECTIVE = 'RedirectMatch 403 "(?i)\.(php[0-9]?|phtml|phps|phar|pht)(/|$)"';

 
    const PHP_FILES_BLOCK_RULES = [
        '<IfModule mod_alias.c>',
        self::PHP_FILES_BLOCK_DIRECTIVE,
        '</IfModule>',
    ];





    public $filesystem;

    public function __construct()
    {
        $this->filesystem = new Filesystem();
    }







    public function create($path)
    {
        return $this->filesystem->create($path, implode(PHP_EOL, array_merge(self::MOD_MIME_RULES, self::PHP_FILES_BLOCK_RULES, [
            '<IfModule mod_dir.c>',
            'DirectoryIndex index.html index.php',
            '</IfModule>',
            '<IfModule mod_autoindex.c>',
            'Options -Indexes',
            '</IfModule>',
        ])));
    }





    public function addPhpFilesBlock($path)
    {
        return $this->filesystem->create($path, PHP_EOL . implode(PHP_EOL, self::PHP_FILES_BLOCK_RULES) . PHP_EOL, 'ab');
    }

 
    const DENY_DIRECTIVE = 'Require all denied';







    public function createDeny($path)
    {
        return $this->filesystem->create($path, implode(PHP_EOL, [
            '<IfModule mod_authz_core.c>',
            self::DENY_DIRECTIVE,
            '</IfModule>',
            '<IfModule !mod_authz_core.c>',
            'Order deny,allow',
            'Deny from all',
            '</IfModule>',
        ]));
    }









    public function createLitespeed($path)
    {
        if (!Hooks::applyFilters(self::FILTER_CREATE_LITE_SPEED_SERVER_CONFIG, false)) {
            return false;
        }

        return $this->filesystem->createWithMarkers($path, 'LiteSpeed', [
            '<IfModule Litespeed>',
            'SetEnv noabort 1',
            '</IfModule>',
        ]);
    }








    public function createForStagingNetwork($path, $baseDirectory)
    {
        if (!function_exists('insert_with_markers')) {
            require_once ABSPATH . 'wp-admin/includes/misc.php';
        }

        $rules = [
            '<IfModule mod_rewrite.c>',
            'RewriteEngine On',
            'RewriteRule .* - [E=HTTP_AUTHORIZATION:%{HTTP:Authorization}]',
            'RewriteBase ' . trailingslashit($baseDirectory),
            'RewriteRule ^index\.php$ - [L]',
        ];

        if (get_site_option('ms_files_rewriting')) {
            $rules[] = '';
            $rules[] = '# uploaded files';
            $rules[] = 'RewriteRule ^([_0-9a-zA-Z-]+/)?files/(.+) wp-includes/ms-files.php?file=$2 [L]';
        }

        $rules = array_merge($rules, [
            '',
            '# add a trailing slash to /wp-admin',
            'RewriteRule ^([_0-9a-zA-Z-]+/)?wp-admin$ $1wp-admin/ [R=301,L]',
            '',
            'RewriteCond %{REQUEST_FILENAME} -f [OR]',
            'RewriteCond %{REQUEST_FILENAME} -d',
            'RewriteRule ^ - [L]',
            'RewriteRule ^([_0-9a-zA-Z-]+/)?(wp-(content|admin|includes).*) $2 [L]',
            'RewriteRule ^([_0-9a-zA-Z-]+/)?(.*\.php)$ $2 [L]',
            'RewriteRule . index.php [L]',
            '</IfModule>',
        ]);

        return $this->filesystem->createWithMarkers($path, 'WordPress', $rules);
    }
}
