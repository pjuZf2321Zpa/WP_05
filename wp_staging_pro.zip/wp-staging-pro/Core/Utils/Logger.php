<?php







namespace WPStaging\Core\Utils;

use WPStaging\Backend\Modules\SystemInfo;
use WPStaging\Backend\Optimizer\Optimizer;
use WPStaging\Backup\Storage\Providers;
use WPStaging\Core\DTO\Settings;
use WPStaging\Core\WPStaging;
use WPStaging\Framework\Adapter\WpAdapter;
use WPStaging\Framework\Filesystem\Filesystem;
use WPStaging\Framework\Interfaces\ShutdownableInterface;
use WPStaging\Framework\Job\JobTransientCache;
use WPStaging\Framework\Logger\SseEventCache;
use WPStaging\Framework\SiteInfo;
use WPStaging\Framework\Traits\FormatTrait;
use WPStaging\Vendor\Psr\Log\LoggerInterface;
use WPStaging\Vendor\Psr\Log\LogLevel;





class Logger implements LoggerInterface, ShutdownableInterface
{
    use FormatTrait;

    const TYPE_ERROR    = "ERROR";

    const TYPE_CRITICAL = "CRITICAL";

    const TYPE_FATAL    = "FATAL";

    const TYPE_WARNING  = "WARNING";

    const TYPE_NOTICE   = "NOTICE";

    const TYPE_INFO     = "INFO";

    const TYPE_DEBUG    = "DEBUG";

    const TYPE_INFO_SUB = "INFO_SUB";




    const LOG_DATETIME_FORMAT = "Y/m/d H:i:s";





    private $logDir;





    private $logExtension   = "log";





    private $messages       = [];





    private $committedCount = 0;





    private $fileName       = null;

 
    private $settingsDto;




    private $sseEventCache = null;

 
    private $sseSetupAttempted = false;









    public function __construct($logDir = null, $logExtension = null, $settingsDto = null)
    {
 
        if (!empty($logDir) && is_dir($logDir)) {
            $this->logDir = rtrim($logDir, "/\\") . DIRECTORY_SEPARATOR;
        } else {
 
            $this->logDir = WPStaging::getContentDir() . "logs" . DIRECTORY_SEPARATOR;
        }

 
        if (!empty($logExtension)) {
            $this->logExtension = $logExtension;
        }





        (new Filesystem())->mkdir($this->logDir);

        $this->settingsDto = $settingsDto;
        if ($this->settingsDto === null) {
            $this->settingsDto = WPStaging::make(Settings::class);
        }
    }

    public function onWpShutdown()
    {
        $this->commit();
    }

    public function setupSseLogger(string $jobId)
    {
        if ($this->sseEventCache === null) {
            $this->sseEventCache = WPStaging::make(SseEventCache::class);
        }

        $this->sseEventCache->setJobId($jobId);
        $this->sseEventCache->load();
        $this->sseSetupAttempted = true;
    }







    private function lazyAttachSseEventCache()
    {
        if ($this->sseSetupAttempted || $this->sseEventCache !== null) {
            return;
        }

        $this->sseSetupAttempted = true;

        try {
            $jobId = WPStaging::make(JobTransientCache::class)->getJobId();
            if (empty($jobId)) {
                return;
            }

            $this->sseEventCache = WPStaging::make(SseEventCache::class);
            $this->sseEventCache->setJobId($jobId);
            $this->sseEventCache->load();
        } catch (\Throwable $e) {
 
        }
    }





    public function writeLogHeader(string $additionalHeader = '')
    {
        $systemInfo = WPStaging::make(SystemInfo::class);

 
        $siteInfo   = WPStaging::make(SiteInfo::class);
 
        $host       = 'General';
        if ($siteInfo->isHostedOnWordPressCom()) {
            $host   = 'WordPress.com';
        } elseif ($siteInfo->isFlywheel()) {
            $host   = 'Flywheel';
        }

 
        $wpAdapter = WPStaging::make(WpAdapter::class);

        $this->info('System Info' . $additionalHeader);
        $this->add(sprintf('- WP Staging Version: %s', $systemInfo->getWpStagingVersion()), self::TYPE_INFO_SUB);
        $this->add(sprintf('- PHP Version: %s', $systemInfo->getPhpVersion()), self::TYPE_INFO_SUB);
        $this->add(sprintf('- Server: %s', $systemInfo->getWebServerInfo()), self::TYPE_INFO_SUB);
        $this->add(sprintf('- MySQL: %s', $systemInfo->getMySqlVersionCompact()), self::TYPE_INFO_SUB);
        $this->add(sprintf('- WP Version: %s', get_bloginfo("version")), self::TYPE_INFO_SUB);
        $this->add(sprintf('- Site URL: %s', esc_html(get_site_url())), self::TYPE_INFO_SUB);
        $this->add(sprintf('- Home URL: %s', esc_html(get_home_url())), self::TYPE_INFO_SUB);
        $this->add(sprintf('- Site Type: %s', is_multisite() ? 'Multisite' : 'Single site'), self::TYPE_INFO_SUB);
        if (is_multisite()) {
            $this->add(sprintf('- Network ID: %s', $wpAdapter->getCurrentNetworkId()), self::TYPE_INFO_SUB);
            $this->add(sprintf('- Current Subsite ID: %s', get_current_blog_id()), self::TYPE_INFO_SUB);
        }

        $this->add(sprintf('- Host: %s', esc_html($host)), self::TYPE_INFO_SUB);
        $this->add(sprintf('- PHP Memory Limit: %s', $this->formatSize(wp_convert_hr_to_bytes(ini_get("memory_limit")), 2, true)), self::TYPE_INFO_SUB);
        $this->add(sprintf('- WP Memory Limit: %s', (defined('WP_MEMORY_LIMIT') ? $this->formatSize(wp_convert_hr_to_bytes(WP_MEMORY_LIMIT), 2, true) : '')), self::TYPE_INFO_SUB);
        $this->add(sprintf('- PHP Max Execution Time: %s', ini_get("max_execution_time")), self::TYPE_INFO_SUB);
    }








    public function log($level, $message, array $context = [])
    {
        $this->add($message, $level, isset($context['errorCode']) ? $context['errorCode'] : '');
    }






    public function add($message, $type = self::TYPE_ERROR, string $errorCode = '')
    {
        $log = [
            "type"    => $type,
            "date"    => current_time(self::LOG_DATETIME_FORMAT),
            "message" => str_replace('<', '&lt;', $this->collapseLineBreaks(html_entity_decode((string)$message, ENT_QUOTES, 'UTF-8'))),
        ];

        if ($errorCode !== '') {
            $log["errorCode"] = $errorCode;
        }

        $this->messages[] = $log;

        $this->lazyAttachSseEventCache();

        if ($this->sseEventCache !== null) {
            $this->sseEventCache->push($log);
        }
    }







    private function collapseLineBreaks(string $message): string
    {
        return (string)preg_replace('/[\r\n]+[ \t]*/', ' ', $message);
    }






    public function pushSseEvent(string $type, array $data)
    {
        $this->lazyAttachSseEventCache();

        if ($this->sseEventCache !== null) {
            $this->sseEventCache->push([
                "type" => $type,
                "data" => $data,
            ]);
        }
    }




    public function getFileName()
    {
        return $this->fileName;
    }




    public function setFileName($fileName)
    {
        $this->fileName = $fileName;
    }




    public function commit()
    {
        $uncommittedMessages = array_slice($this->messages, $this->committedCount);
        if (empty($uncommittedMessages)) {
            return true;
        }

        $messageString = '';
        foreach ($uncommittedMessages as $message) {
            if (is_array($message)) {
                $messageString .= "[{$message["type"]}]-[{$message["date"]}] {$message["message"]}" . PHP_EOL;
            }
        }

        if (strlen($messageString) < 1) {
            $this->markMessagesCommitted($uncommittedMessages);
            return true;
        }

        if (!$this->appendToLogFile($this->getLogFile(), $messageString)) {
            return false;
        }

        $this->markMessagesCommitted($uncommittedMessages);

        return true;
    }





    private function markMessagesCommitted(array $messages)
    {
        $this->committedCount += count($messages);
    }










    private function appendToLogFile(string $logFile, string $messageString): bool
    {
        set_error_handler([$this, 'handleLogFileWriteError']);

        $isRecordComplete = $this->writeRecordUnderLock($logFile, $messageString);

        restore_error_handler();

        return $isRecordComplete;
    }










    private function writeRecordUnderLock(string $logFile, string $messageString): bool
    {
        $handle = fopen($logFile, 'a');
        if ($handle === false) {
            return false;
        }

        if (!flock($handle, LOCK_EX)) {
            fclose($handle);

            return false;
        }

        fseek($handle, 0, SEEK_END);
        $sizeBeforeWrite = ftell($handle);

        $bytesWritten = fwrite($handle, $messageString);
        fflush($handle);

        $isRecordComplete = $bytesWritten === strlen($messageString);
        if (!$isRecordComplete && $sizeBeforeWrite !== false) {
            ftruncate($handle, $sizeBeforeWrite);
        }

        flock($handle, LOCK_UN);
        fclose($handle);

        return $isRecordComplete;
    }








    public function handleLogFileWriteError(int $errno, string $errstr, string $errfile = '', int $errline = 0): bool
    {
        return true;
    }






    public function read($file = null)
    {
        return @file_get_contents($this->getLogFile($file));
    }






    public function getLogFile($fileName = null)
    {
 
        if ($fileName === null) {
            $fileName = ($this->fileName !== null) ? $this->fileName : date("Y_m_d");
        }

        return $this->logDir . $fileName . '.' . $this->logExtension;
    }









    public function delete($logFileName)
    {
        $logFile = $this->logDir . $logFileName . '.' . $this->logExtension;

        if (@unlink($logFile) === false) {
            throw new \Exception("Couldn't delete cache: {$logFileName}. Full Path: {$logFile}");
        }

        return true;
    }




    public function getLogDir()
    {
        return $this->logDir;
    }




    public function getLogExtension()
    {
        return $this->logExtension;
    }








    public function getLastLogMsg()
    {
        $messageCount = count($this->messages);

        if ($messageCount > 1) {
            return $this->messages;
        }

        if ($messageCount === 1) {
            return $this->messages[0];
        }

        return null;
    }








    public function getLastErrorMsg($types = [self::TYPE_ERROR, self::TYPE_CRITICAL])
    {
        if (count($this->messages) === 0) {
            return false;
        }

        foreach (array_reverse($this->messages) as $message) {
 
            if (empty($message['type'])) {
                continue;
            }

            if (in_array(strtoupper($message['type']), $types)) {
                return $message;
            }
        }

        return false;
    }




    public function emergency($message, array $context = [])
    {
        $this->add($message, LogLevel::EMERGENCY);
    }




    public function alert($message, array $context = [])
    {
        $this->add($message, LogLevel::ALERT);
    }




    public function critical($message, array $context = [])
    {
        $this->add($message, LogLevel::CRITICAL, isset($context['errorCode']) ? $context['errorCode'] : '');
    }




    public function error($message, array $context = [])
    {
        $this->add($message, LogLevel::ERROR, isset($context['errorCode']) ? $context['errorCode'] : '');
    }




    public function warning($message, array $context = [])
    {
        $this->add($message, LogLevel::WARNING);
    }




    public function notice($message, array $context = [])
    {
        $this->add($message, LogLevel::NOTICE);
    }




    public function info($message, array $context = [])
    {
        $this->add($message, LogLevel::INFO);
    }






    public function debug($message, array $context = [])
    {
        if ($this->isDebugMode()) {
            $this->add($message, LogLevel::DEBUG);
        }
    }




    public function writeInstalledPluginsAndThemes()
    {
        $allPlugins = get_plugins();
        $activePlugins = get_option("active_plugins", []);
        $allThemes = wp_get_themes();
        $activeTheme = wp_get_theme();

        $networkActivePlugins = [];
        if (is_multisite()) {
            $networkActivePlugins = array_keys(get_site_option("active_sitewide_plugins", []));
        }

        $this->listActivePlugins($allPlugins, $activePlugins, $networkActivePlugins);
        $allActivePlugins = array_merge($activePlugins, $networkActivePlugins);
        $this->listInactivePlugins($allPlugins, $allActivePlugins);
        $this->listActiveTheme($activeTheme);
        $this->listInactiveThemes($allThemes, $activeTheme);
    }





    public function writeGlobalSettingsToLogs()
    {
        $globalSettings = (object)get_option('wpstg_settings', []);
        $this->add('Global Settings', Logger::TYPE_INFO);
        $this->add(sprintf('- DB Query Limit : %s', ($globalSettings->queryLimit ?? 'Not Set')), Logger::TYPE_INFO_SUB);
        $this->add(sprintf('- DB Search & Replace Limit : %s', ($globalSettings->querySRLimit ?? 'Not Set')), Logger::TYPE_INFO_SUB);
        $this->add(sprintf('- File Copy Limit : %s', ($globalSettings->fileLimit ?? 'Not Set')), Logger::TYPE_INFO_SUB);
        $this->add(sprintf('- Maximum File Size : %s', ($globalSettings->maxFileSize ?? 'Not Set')), Logger::TYPE_INFO_SUB);
        $this->add(sprintf('- File Copy Batch Size : %s', ($globalSettings->batchSize ?? 'Not Set')), Logger::TYPE_INFO_SUB);
        $this->add(sprintf('- Optimizer Active : %s', $this->getOptimizerStatus($globalSettings)), Logger::TYPE_INFO_SUB);
    }





    public function writeSelectedTablesToLogs($tables)
    {
        if (count($tables) === 0) {
            return;
        }

        $this->add(sprintf('Selected Tables : %s', count($tables)), Logger::TYPE_INFO_SUB);
        if (count($tables) > 100) {
            return;
        }

        for ($i = 0; $i < count($tables); $i += 2) {
            $this->add(sprintf('- %s, %s', $tables[$i], $tables[$i + 1] ?? ''), Logger::TYPE_INFO_SUB);
        }
    }






    public function logProviderSettings($providerName, $provider)
    {
        $excludedFields = [
            'expiresIn',
            'created',
            'showNotice',
            'userData',
            'storageInfo',
            'lastUpdated',
        ];

        $providerOptions = $provider->getOptions();

        $this->add(sprintf('%s Settings', esc_html($providerName)), Logger::TYPE_INFO);

        foreach ($providerOptions as $key => $value) {
            if (in_array($key, $excludedFields)) {
                continue;
            }

            if (Providers::isSensitiveOptionKey((string)$key) || !is_scalar($value)) {
                $this->add(sprintf('- %s : %s', ucfirst($key), (empty($value) ? 'Not Set' : '***********')), Logger::TYPE_INFO_SUB);
                continue;
            }

            $value = is_bool($value) || $value === 1 || $value === '1' ? ($value ? 'True' : 'False') : $value;
            $this->add(sprintf('- %s : %s', ucfirst($key), (empty($value) ? 'Not Set' : $value)), Logger::TYPE_INFO_SUB);
        }
    }

 
    protected function isDebugMode(): bool
    {
        if (defined('WPSTG_DEBUG') && WPSTG_DEBUG === true) {
            return true;
        }

        return $this->settingsDto->isDebugMode();
    }








    protected function listActivePlugins(array $allPlugins, array $activePlugins, array $networkActivePlugins = [])
    {
        $isMultisite = is_multisite();

        if ($isMultisite) {
            $this->info("Activated Plugins on this Site");
        } else {
            $this->info("Activated Plugins");
        }

        foreach ($allPlugins as $path => $plugin) {
            if (in_array($path, $activePlugins)) {
                $this->add(sprintf("- %s : %s", esc_html($plugin['Name']), esc_html($plugin['Version'])), self::TYPE_INFO_SUB);
            }
        }

        if ($isMultisite) {
            $this->info("Activated Network Plugins");

            foreach ($networkActivePlugins as $pluginPath) {
                if (isset($allPlugins[$pluginPath])) {
                    $plugin = $allPlugins[$pluginPath];
                    $this->add(sprintf("- %s : %s", esc_html($plugin['Name']), esc_html($plugin['Version'])), self::TYPE_INFO_SUB);
                }
            }
        }
    }






    protected function listInactivePlugins(array $allPlugins, array $allActivePlugins)
    {
        $this->info("Inactive Plugins");

        foreach ($allPlugins as $path => $plugin) {
            if (!in_array($path, $allActivePlugins)) {
                $this->add(sprintf("- %s : %s", esc_html($plugin['Name']), esc_html($plugin['Version'])), self::TYPE_INFO_SUB);
            }
        }
    }





    protected function listActiveTheme(\WP_Theme $activeTheme)
    {
        $this->info("Activated Theme");
        $this->add(sprintf("- %s : %s", $activeTheme->get('Name'), $activeTheme->get('Version')), self::TYPE_INFO_SUB);
    }






    protected function listInactiveThemes(array $allThemes, \WP_Theme $activeTheme)
    {
        $this->info("Inactive Themes");

        foreach ($allThemes as $theme) {
            if ($theme->get_stylesheet() !== $activeTheme->get_stylesheet()) {
                $this->add(sprintf("- %s : %s", $theme->get('Name'), $theme->get('Version')), self::TYPE_INFO_SUB);
            }
        }
    }








    private function getOptimizerStatus($globalSettings): string
    {
        if (get_option(Optimizer::OPTION_OPTIMIZER_DISABLED_AFTER_FATAL) === '1') {
            return 'False (disabled after a plugin conflict)';
        }

        return isset($globalSettings->optimizer) && $globalSettings->optimizer ? 'True' : 'False';
    }
}
