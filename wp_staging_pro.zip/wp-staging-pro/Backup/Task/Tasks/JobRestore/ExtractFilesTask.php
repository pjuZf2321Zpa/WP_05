<?php








namespace WPStaging\Backup\Task\Tasks\JobRestore;

use WPStaging\Backup\Dto\File\ExtractorDto;
use WPStaging\Framework\Filesystem\MissingFileException;
use WPStaging\Framework\Queue\FinishedQueueException;
use WPStaging\Framework\Queue\SeekableQueueInterface;
use WPStaging\Framework\Job\Dto\StepsDto;
use WPStaging\Backup\Dto\Task\Restore\ExtractFilesTaskDto;
use WPStaging\Framework\Job\Exception\DiskNotWritableException;
use WPStaging\Backup\Task\RestoreTask;
use WPStaging\Vendor\Psr\Log\LoggerInterface;
use WPStaging\Framework\Utils\Cache\Cache;
use WPStaging\Backup\Entity\BackupMetadata;
use WPStaging\Backup\Interfaces\ExtractorTaskInterface;
use WPStaging\Backup\Service\Extractor;
use WPStaging\Core\WPStaging;
use WPStaging\Framework\Adapter\Directory;
use WPStaging\Framework\Facades\Hooks;
use WPStaging\Framework\Filesystem\Filesystem;
use WPStaging\Framework\Filesystem\PartIdentifier;
use WPStaging\Framework\Filesystem\PathIdentifier;

class ExtractFilesTask extends RestoreTask implements ExtractorTaskInterface
{
 
    protected $extractorService;

 
    protected $start;

 
    protected $totalFiles;

 
    protected $metadata;

 
    protected $currentTaskDto;

 
    private $filesystem;

 
    private $directory;

    public function __construct(Extractor $extractor, LoggerInterface $logger, Cache $cache, StepsDto $stepsDto, SeekableQueueInterface $taskQueue, Filesystem $filesystem, Directory $directory)
    {
        parent::__construct($logger, $cache, $stepsDto, $taskQueue);
        $this->extractorService = $extractor;
        $this->filesystem       = $filesystem;
        $this->directory        = $directory;
    }

    public static function getTaskName()
    {
        return 'backup_restore_extract';
    }

    public static function getTaskTitle()
    {
        return 'Extracting Files';
    }

    public function execute()
    {
        try {
            $this->prepareTask();
        } catch (MissingFileException $ex) {
            $this->jobDataDto->setFilePartIndex($this->jobDataDto->getFilePartIndex() + 1);
            $this->currentTaskDto->totalFilesExtracted       = 0;
            $this->currentTaskDto->currentIndexOffset        = 0;
            $this->currentTaskDto->currentHeaderBytesRemoved = 0;
            return $this->generateResponse(false);
        }

        $this->start = microtime(true);
 
        $this->extractorService->getExtractorDto()->setSkippedSplitFilePath($this->jobDataDto->getSkippedSplitFilePath());

        try {
            $this->extractorService->execute();
            $this->currentTaskDto->fromExtractorDto($this->extractorService->getExtractorDto());
        } catch (DiskNotWritableException $e) {
            $this->logger->warning($e->getMessage());
            $this->currentTaskDto->fromExtractorDto($this->extractorService->getExtractorDto());
            $this->setCurrentTaskDto($this->currentTaskDto);
 
            throw $e;
        } catch (FinishedQueueException $e) {
            $this->currentTaskDto->fromExtractorDto($this->extractorService->getExtractorDto());
            $this->extractionFinishedLog();
 
            $this->currentTaskDto->totalFilesExtracted = $this->stepsDto->getTotal();
        }

        $this->jobDataDto->setSkippedSplitFilePath($this->extractorService->getExtractorDto()->getSkippedSplitFilePath());
        $this->logger->info(sprintf('Extracted %d/%d files (%s)', $this->currentTaskDto->totalFilesExtracted, $this->stepsDto->getTotal(), $this->getExtractSpeed()));
        $this->stepsDto->setCurrent($this->currentTaskDto->totalFilesExtracted);

        $this->setCurrentTaskDto($this->currentTaskDto);
        if (!$this->stepsDto->isFinished()) {
            return $this->generateResponse(false);
        }

        if (!$this->metadata->getIsMultipartBackup() && $this->metadata->getIsExportingUploads() && !$this->isBackupPartSkipped(PartIdentifier::UPLOAD_PART_IDENTIFIER)) {
            $this->logger->info(__('Restored Media Library', 'wp-staging'));
            return $this->generateResponse(false);
        }

        if ($this->isBackupPartSkipped(PartIdentifier::UPLOAD_PART_IDENTIFIER)) {
            $this->logger->warning(__('Restoring Media Skipped by filter!', 'wp-staging'));
            return $this->generateResponse(false);
        }

        if (!$this->metadata->getIsMultipartBackup()) {
            return $this->generateResponse(false);
        }

        $this->setNextBackupToExtract();

        return $this->generateResponse(false);
    }




    public function persistDto(ExtractorDto $extractorDto)
    {
        $this->currentTaskDto->fromExtractorDto($extractorDto);
        $this->setCurrentTaskDto($this->currentTaskDto);
        $this->persistJobDataDto();
    }

    protected function getExtractSpeed()
    {
        $elapsed = microtime(true) - $this->start;
        $bytesPerSecond = min(10 * GB_IN_BYTES, absint($this->extractorService->getBytesWrittenInThisRequest() / $elapsed));

        if ($bytesPerSecond === 10 * GB_IN_BYTES) {
            return '10GB/s+';
        }

        return size_format($bytesPerSecond) . '/s';
    }




    protected function prepareTask()
    {
        $this->metadata   = $this->jobDataDto->getBackupMetadata();
        $this->totalFiles = $this->metadata->getTotalFiles();
        $this->extractorService->setIsFastPerformanceMode($this->jobDataDto->getIsFastPerformanceMode());
        $this->extractorService->setIsBackupFormatV1($this->metadata->getIsBackupFormatV1(false));
        $this->extractorService->inject($this, $this->logger);
        $this->extractorService->setExcludedIdentifiers($this->getExcludedIdentifiers());
        $this->extractorService->setIsRepairMultipleHeadersIssue($this->canHaveMultipleHeadersIssue());
        $this->extractorService->setRestoreDatabaseFiles($this->getDatabaseFilesNamedByEntryFile());
        $this->filesystem->mkdir($this->directory->getTmpDirectory(), true);
        $this->setupExtractor();
    }





    private function getDatabaseFilesNamedByEntryFile(): array
    {
        $multipartMetadata = $this->metadata->getMultipartMetadata();
        $databaseFiles     = $multipartMetadata === null ? [] : $multipartMetadata->getDatabaseFiles();
        $databaseFiles[]   = (string)$this->metadata->getDatabaseFile();

        return $databaseFiles;
    }




    protected function setupExtractor()
    {
        $this->stepsDto->setTotal($this->totalFiles);
        $this->extractorService->setup($this->currentTaskDto->toExtractorDto(), $this->jobDataDto->getFile(), $this->jobDataDto->getTmpDirectory());
    }




    protected function setNextBackupToExtract()
    {
 
    }

 
    protected function getCurrentTaskType(): string
    {
        return ExtractFilesTaskDto::class;
    }





    protected function canHaveMultipleHeadersIssue(): bool
    {
 
        if ($this->metadata->getIsBackupFormatV1()) {
            return false;
        }

        $wpstgVersion = $this->metadata->getWpstgVersion();
        $createdOnPro = $this->metadata->getCreatedOnPro();
        if ($createdOnPro && version_compare($wpstgVersion, '6.0.0', '>=') && version_compare($wpstgVersion, '6.1.4', '<')) {
            return true;
        }

        if (!$createdOnPro && version_compare($wpstgVersion, '4.0.0', '>=') && version_compare($wpstgVersion, '4.1.4', '<')) {
            return true;
        }

        return false;
    }




    private function getExcludedIdentifiers(): array
    {
        $excludedParts = Hooks::applyFilters(RestoreTask::FILTER_EXCLUDE_BACKUP_PARTS, []);
        if (empty($excludedParts)) {
            return [];
        }

 
        $pathIdentifier      = WPStaging::make(PathIdentifier::class);
        $excludedIdentifiers = [];
        foreach ($excludedParts as $part) {
 
            if ($part === PartIdentifier::DATABASE_PART_IDENTIFIER) {
                $excludedIdentifiers[] = PartIdentifier::DATABASE_PART_IDENTIFIER;
                continue;
            }

            $excludedIdentifiers[] = $pathIdentifier->getIdentifierByPartName($part);
        }

        $excludedIdentifiers = array_filter($excludedIdentifiers, function ($identifier) {
            return !empty($identifier);
        });

        return $excludedIdentifiers;
    }




    private function extractionFinishedLog()
    {
        $totalFilesProcessed = $this->currentTaskDto->totalFilesExtracted + $this->currentTaskDto->totalFilesSkipped;
        if ($totalFilesProcessed === $this->stepsDto->getTotal()) {
            if ($this->currentTaskDto->totalFilesSkipped > 0) {
                $this->logger->info(sprintf(
                    'Extraction complete: %d files extracted, %d files skipped.',
                    $this->currentTaskDto->totalFilesExtracted,
                    $this->currentTaskDto->totalFilesSkipped
                ));
            }

            return;
        }

        $this->logger->warning(sprintf(
            'Expected to process %d files in Backup, but processed %d instead (extracted: %d, skipped: %d).',
            $this->stepsDto->getTotal(),
            $totalFilesProcessed,
            $this->currentTaskDto->totalFilesExtracted,
            $this->currentTaskDto->totalFilesSkipped
        ));
    }
}
