<?php

namespace WPStaging\Backup\Ajax\Restore;

use WPStaging\Backup\Dto\Job\JobRestoreDataDto;
use WPStaging\Backup\Job\JobRestoreProvider;
use WPStaging\Backup\Job\Jobs\JobRestore;
use WPStaging\Core\WPStaging;
use WPStaging\Framework\Adapter\Directory;
use WPStaging\Framework\Database\TableService;
use WPStaging\Framework\Facades\Hooks;
use WPStaging\Framework\Facades\Sanitize;
use WPStaging\Framework\Filesystem\Filesystem;
use WPStaging\Framework\Job\Ajax\PrepareJob;
use WPStaging\Framework\Job\JobTransientCache;
use WPStaging\Framework\Job\ProcessLock;
use WPStaging\Framework\Job\Traits\WithTmpDatabasePrefix;
use WPStaging\Framework\Security\Auth;

class PrepareRestore extends PrepareJob
{
    use WithTmpDatabasePrefix;

 
    private $jobDataDto;

 
    private $jobRestore;

 
    private $tableService;

    public function __construct(Filesystem $filesystem, Directory $directory, Auth $auth, ProcessLock $processLock, TableService $tableService)
    {
        parent::__construct($filesystem, $directory, $auth, $processLock);
        $this->tableService = $tableService;
    }

    public function prepare($data = null)
    {
 
        $container        = WPStaging::getInstance()->getContainer();
        $this->jobDataDto = $container->get(JobRestoreDataDto::class);
        $this->jobRestore = $container->get(JobRestoreProvider::class)->getJob();

        if (empty($data) && array_key_exists('wpstgRestoreData', $_POST)) {
            $data = Sanitize::sanitizeArray($_POST['wpstgRestoreData'], [
                'backupMetadata'                 => 'array',
                'headerStart'                    => 'int',
                'headerEnd'                      => 'int',
                'totalFiles'                     => 'int',
                'totalDirectories'               => 'int',
                'maxTableLength'                 => 'int',
                'databaseFileSize'               => 'int',
                'backupSize'                     => 'int',
                'blogId'                         => 'int',
                'networkId'                      => 'int',
                'dateCreated'                    => 'int',
                'isAutomatedBackup'              => 'bool',
                'phpShortOpenTags'               => 'bool',
                'wpBakeryActive'                 => 'bool',
                'subdomainInstall'               => 'bool',
                'isExportingPlugins'             => 'bool',
                'isExportingMuPlugins'           => 'bool',
                'isExportingThemes'              => 'bool',
                'isExportingUploads'             => 'bool',
                'isExportingOtherWpContentFiles' => 'bool',
                'isExportingOtherWpRootFiles'    => 'bool',
                'isExportingDatabase'            => 'bool',
            ]);
        }

        try {
            $sanitizedData = $this->setupInitialJob($data);
        } catch (\Exception $e) {
            return new \WP_Error(400, $e->getMessage());
        }

        $this->deleteSseCacheFiles();

        return $sanitizedData;
    }




    public function validateAndSanitizeData($data): array
    {
        $expectedKeys = [
            'file',
        ];

 
        $data = array_intersect_key($data, array_flip($expectedKeys));

 
        foreach ($expectedKeys as $expectedKey) {
            if (!array_key_exists($expectedKey, $data)) {
                throw new \UnexpectedValueException("Invalid request. Missing '$expectedKey'.");
            }
        }

        return $data;
    }

    public function getJob()
    {
        return $this->jobRestore;
    }

    public function persist(): bool
    {
        if (!$this->jobRestore instanceof JobRestore) {
            return false;
        }

        $this->jobRestore->persist();

        return true;
    }

    protected function setupInitialData($sanitizedData): array
    {
        $sanitizedData = $this->validateAndSanitizeData($sanitizedData);
        $this->clearCacheFolder();

        $this->jobDataDto->hydrate($sanitizedData);
        $this->jobDataDto->setInit(true);
        $this->jobDataDto->setFinished(false);
        $this->jobDataDto->setTmpDatabasePrefix($this->getTmpDatabasePrefix());

        $this->jobDataDto->generateId();

        $this->jobRestore->setJobDataDto($this->jobDataDto);

        if (!$this->jobDataDto->getIsSyncRequest()) {
            $this->jobRestore->getTransientCache()->startJob($this->jobDataDto->getId(), esc_html__('Restore in Progress', 'wp-staging'), JobTransientCache::JOB_TYPE_RESTORE, $this->queueId);
        }

        return $sanitizedData;
    }
}
