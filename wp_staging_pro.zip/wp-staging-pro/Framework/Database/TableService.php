<?php

 
 

namespace WPStaging\Framework\Database;

use RuntimeException;
use UnexpectedValueException;
use WPStaging\Backup\Service\Database\DatabaseImporter;
use WPStaging\Framework\Adapter\Database;
use WPStaging\Framework\Collection\Collection;
use WPStaging\Framework\Traits\SqlIdentifierTrait;
use WPStaging\Framework\Utils\Strings;

class TableService
{
    use SqlIdentifierTrait;

 
    const LOCK_WAIT_SECONDS = 3;

 
    const LOCK_WAIT_TIMEOUT_ERRNO = 1205;

 
    const DROP_ATTEMPTS = 3;

 
    private $database;

 
    private $client;

 
    private $shouldStop;

 
    private $errors = [];

 
    private $hasRefusedProductionTable = false;

 
    private $strHelper;

 
    private $customTmpPrefix = '';

    private $isSqlLite = false;




    public function __construct($database = null)
    {
        $this->database  = $database ?: new Database();
        $this->client    = $this->database->getClient();
        $this->strHelper = new Strings();

        $this->isSqlLite = property_exists($this->client, 'isSQLite');
    }




    public function getErrors()
    {
        return $this->errors;
    }




    public function hasRefusedProductionTable(): bool
    {
        return $this->hasRefusedProductionTable;
    }




    public function getShouldStop()
    {
        return $this->shouldStop;
    }





    public function setShouldStop($shouldStop = null)
    {
        $this->shouldStop = $shouldStop;
        return $this;
    }







    public function setCustomTmpPrefix(string $customTmpPrefix): TableService
    {
        $this->customTmpPrefix = $customTmpPrefix;
        return $this;
    }





    public function tableExists(string $tableName): bool
    {
        $wpdb   = $this->database->getWpdb();
        $tables = $wpdb->get_results(
            $wpdb->prepare('SHOW TABLES LIKE %s;', $wpdb->esc_like($tableName)),
            ARRAY_A
        );

        if (!$tables) {
            return false;
        }

        return true;
    }






    public function findAllTableStatus()
    {
        $tables = $this->database->find("SHOW TABLE STATUS");
        if (!$tables) {
            return null;
        }

        $collection = new Collection(TableDto::class);
        foreach ($tables as $table) {
            $collection->attach((new TableDto())->hydrate((array) $table));
        }

        return $collection;
    }







    public function findTableStatusStartsWith($prefix = null)
    {
 
        $tables = $this->database->find("SHOW TABLE STATUS LIKE '{$this->database->escapeSqlPrefixForLIKE($prefix)}%'");
        if (!$tables) {
            return null;
        }

        $collection = new Collection(TableDto::class);
        foreach ($tables as $table) {
            $collection->attach((new TableDto())->hydrate((array) $table));
        }

        return $collection;
    }







    public function getTablesName($tables): array
    {
        return (!is_array($tables)) ? [] : array_map(function ($table) {
            return ($table->getName());
        }, $tables);
    }








    public function findTableNamesStartWith(string $prefix = ''): array
    {
        $query  = $this->getTablesFindQueryByTableType('BASE TABLE', $prefix);
        $result = $this->client->query($query);
        if (!$result) {
            return [];
        }

        $tables = [];
        while ($row = $this->client->fetchRow($result)) {
            if (isset($row[0])) {
                $tables[] = $row[0];
            }
        }

        $this->client->freeResult($result);

        return $tables;
    }








    public function findViewsNamesStartWith(string $prefix = ''): array
    {
        $query  = $this->getTablesFindQueryByTableType('VIEW', $prefix);
        $result = $this->client->query($query);
        if (!$result) {
            return [];
        }

        $views = [];
        while ($row = $this->client->fetchRow($result)) {
            if (isset($row[0])) {
                $views[] = $row[0];
            }
        }

        $this->client->freeResult($result);

        return $views;
    }






    public function getCreateViewQuery(string $viewName): string
    {
        $result = $this->client->query("SHOW CREATE VIEW `{$viewName}`");
        $row    = $this->client->fetchAssoc($result);

        $this->client->freeResult($result);

        if (isset($row['Create View'])) {
            return $row['Create View'];
        }

        return '';
    }








    public function getCreateTableQuery(string $tableName): string
    {
        $result = $this->client->query("SHOW CREATE TABLE `{$tableName}`");
        if ($result === false) {
            return '';
        }

        $row = $this->client->fetchAssoc($result);

        $this->client->freeResult($result);

        if (isset($row['Create Table'])) {
            return $row['Create Table'];
        }

        return '';
    }









    public function deleteTablesStartWith(string $prefix, array $excludedTables = [], bool $deleteViews = false): bool
    {
        if ($deleteViews) {
 
            $views = $this->findViewsNamesStartWith($prefix);
            if (is_array($views) && !empty($views)) {
                $viewsToRemove = array_diff($views, $excludedTables);
                if (!$this->deleteViews($viewsToRemove)) {
                    return false;
                }
            }
        }

        $tables = $this->findTableStatusStartsWith($prefix);
        if ($tables === null) {
            return true;
        }

        $tables = $this->getTablesName($tables->toArray());

        $tablesToRemove = array_diff($tables, $excludedTables);
        if ($tablesToRemove === []) {
            return true;
        }

        if (!$this->deleteTables($tablesToRemove)) {
            return false;
        }

        return true;
    }







    public function deleteTables($tables): bool
    {
        $foreignKeyChecksWereOn = $this->foreignKeyChecksAreOn();

        if ($foreignKeyChecksWereOn) {
            $this->client->query("SET FOREIGN_KEY_CHECKS = 0");
        }

        $lockWaitTimeout = $this->boundLockWait();

        try {
            return $this->dropTables($tables);
        } finally {
            $this->restoreLockWait($lockWaitTimeout);
            if ($foreignKeyChecksWereOn) {
                $this->client->query("SET FOREIGN_KEY_CHECKS = 1");
            }
        }
    }




    private function foreignKeyChecksAreOn(): bool
    {
        if ($this->isSqlLite) {
            return false;
        }

        $foreignKeyChecks = $this->client->query("SELECT @@FOREIGN_KEY_CHECKS AS fk_check");
        if ($foreignKeyChecks === false) {
            return true;
        }

        $result = $this->client->fetchAssoc($foreignKeyChecks);
        if (!isset($result['fk_check'])) {
            return true;
        }

        return (string)$result['fk_check'] !== "0";
    }




    private function boundLockWait(): string
    {
        if ($this->isSqlLite) {
            return '';
        }

        $lockWait = $this->client->query("SELECT @@SESSION.lock_wait_timeout AS lock_wait");
        if ($lockWait === false) {
            return '';
        }

        $result = $this->client->fetchAssoc($lockWait);
        if (empty($result['lock_wait'])) {
            return '';
        }

        $this->client->query("SET SESSION lock_wait_timeout = " . self::LOCK_WAIT_SECONDS);

        return (string)$result['lock_wait'];
    }





    private function restoreLockWait(string $lockWaitTimeout)
    {
        if ($lockWaitTimeout === '') {
            return;
        }

        $this->client->query("SET SESSION lock_wait_timeout = " . (int)$lockWaitTimeout);
    }





    private function dropTables(array $tables): bool
    {
        $isDeleted = true;
        foreach ($tables as $table) {
            if ($this->refusesToDropProductionTable($table)) {
                return false;
            }

            if ($this->dropTableWithRetries($table)) {
                continue;
            }

            $isDeleted = false;
        }

        return $isDeleted;
    }







    private function refusesToDropProductionTable(string $table): bool
    {
        if (!$this->isProductionSiteTableOrView($table)) {
            return false;
        }

        $this->errors[]                  = sprintf(__("Fatal Error: Trying to delete table %s of main WP installation!", 'wp-staging'), $table);
        $this->hasRefusedProductionTable = true;

        return true;
    }







    private function dropTableWithRetries(string $table): bool
    {
        $lastError = '';
        for ($attempt = 1; $attempt <= self::DROP_ATTEMPTS; $attempt++) {
            if ($this->client->query("DROP TABLE {$this->quoteSqlIdentifier($table)};") !== false) {
                return true;
            }

            $lastError = $this->client->error();
        }

        $this->errors[] = sprintf(
            'Could not delete the table %s after %d attempts. Error: %s',
            $table,
            self::DROP_ATTEMPTS,
            $lastError
        );

        return false;
    }







    public function deleteViews($views): bool
    {
        $lockWaitTimeout = $this->boundLockWait();

        try {
            return $this->dropViews($views);
        } finally {
            $this->restoreLockWait($lockWaitTimeout);
        }
    }





    private function dropViews(array $views): bool
    {
        $isDeleted = true;
        foreach ($views as $view) {
 
            if ($this->isProductionSiteTableOrView($view)) {
                $this->errors[]                  = sprintf(__("Fatal Error: Trying to delete view %s of main WP installation!", 'wp-staging'), $view);
                $this->hasRefusedProductionTable = true;

                return false;
            }

            if ($this->database->getWpdba()->exec("DROP VIEW {$this->quoteSqlIdentifier($view)};") !== false) {
                continue;
            }

            $this->errors[] = sprintf('Could not delete the view %s. Error: %s', $view, $this->getLastWpdbError());
            $isDeleted      = false;
        }

        return $isDeleted;
    }




    public function getDatabase()
    {
        return $this->database;
    }





    public function dropTablesLike(string $likeCondition): bool
    {
        $wpdb   = $this->database->getWpdb();
        $tables = $wpdb->get_results(
            $wpdb->prepare('SHOW TABLES LIKE %s;', $wpdb->esc_like($likeCondition) . '%'),
            ARRAY_A
        );

        if (!$tables) {
            return false;
        }

        return $this->dropFoundTables($tables);
    }





    public function dropTable(string $tableName): bool
    {
        $wpdb   = $this->database->getWpdb();
        $tables = $wpdb->get_results(
            $wpdb->prepare('SHOW TABLES LIKE %s;', $wpdb->esc_like($tableName)),
            ARRAY_A
        );

        if (!$tables) {
            return true;
        }

        return $this->dropFoundTables($tables);
    }





    private function dropFoundTables(array $rows): bool
    {
        $wpdb = $this->database->getWpdb();
        foreach ($rows as $row) {
            $tableName = current($row);
            if ($tableName === false) {
                continue;
            }

            if ($this->refusesToDropProductionTable($tableName)) {
                return false;
            }

            $wpdb->query("DROP TABLE IF EXISTS {$this->quoteSqlIdentifier($tableName)}");
        }

        return true;
    }






    public function renameTable(string $sourceTable, string $destinationTable): bool
    {
 
        $result = $this->client->query(sprintf(
            "RENAME TABLE %s TO %s;",
            $this->quoteSqlIdentifier($sourceTable),
            $this->quoteSqlIdentifier($destinationTable)
        ));

        return $result !== false;
    }






    public function cloneTableWithoutData(string $sourceTable, string $destinationTable): bool
    {
        return $this->client->query("CREATE TABLE $destinationTable LIKE $sourceTable");
    }








    public function copyTableData(string $sourceTable, string $destinationTable, int $offset = 0, int $limit = 0): bool
    {
        $query = sprintf(
            "INSERT INTO %s SELECT * FROM %s LIMIT %d OFFSET %d",
            $destinationTable,
            $sourceTable,
            $limit,
            $offset
        );

        return $this->client->query($query);
    }





    public function getRowsCount(string $tableName, bool $encapsulateTableName = true): int
    {
        $tableName = $encapsulateTableName ? "`$tableName`" : $tableName;

        return (int)$this->database->getWpdb()->get_var("SELECT COUNT(1) FROM $tableName");
    }




    public function getLastWpdbError(): string
    {
 
        $wpdb = $this->database->getWpdba()->getClient();

        return $wpdb->last_error;
    }






    public function getUniqueAutoIncrementColumn(string $database, string $table, bool $mustBeThePrimaryKey = false): string
    {
        $primaryKeyCondition = $mustBeThePrimaryKey ? "AND c.COLUMN_KEY = 'PRI' AND NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.STATISTICS p WHERE p.TABLE_NAME = '$table' AND p.TABLE_SCHEMA = '$database' AND p.INDEX_NAME = 'PRIMARY' AND p.SEQ_IN_INDEX > 1)" : '';
        $query = "SELECT c.COLUMN_NAME
                  FROM INFORMATION_SCHEMA.COLUMNS c
                  JOIN INFORMATION_SCHEMA.STATISTICS s ON s.COLUMN_NAME = c.COLUMN_NAME
                  WHERE c.TABLE_NAME = '$table'
                  AND c.TABLE_SCHEMA = '$database'
                  AND s.TABLE_NAME = '$table'
                  AND s.TABLE_SCHEMA = '$database'
                  AND c.IS_NULLABLE = 'NO'
                  AND c.DATA_TYPE IN ('int', 'bigint', 'smallint', 'mediumint')
                  AND c.EXTRA like '%auto_increment%'
                  AND s.NON_UNIQUE = 0
                  {$primaryKeyCondition}
                  AND NOT EXISTS (
                      SELECT 1 FROM INFORMATION_SCHEMA.STATISTICS k
                      WHERE k.TABLE_NAME = '$table' AND k.TABLE_SCHEMA = '$database' AND k.INDEX_NAME = s.INDEX_NAME AND k.SEQ_IN_INDEX > 1
                  );";

        $result = $this->client->query($query);

        if (!$result) {
            throw new UnexpectedValueException();
        }

        $primaryKey = $this->client->fetchObject($result);

        $this->client->freeResult($result);

        if (!is_object($primaryKey)) {
            throw new UnexpectedValueException();
        }

        if (!property_exists($primaryKey, 'COLUMN_NAME')) {
            throw new UnexpectedValueException();
        }

        if (empty($primaryKey->COLUMN_NAME)) {
            throw new UnexpectedValueException();
        }

        return $primaryKey->COLUMN_NAME;
    }










    public function replaceTableConstraints(string $input): string
    {
        $quotedName        = '(?:`(?:[^`]|``)+`|\w+)';
        $columnList        = '\([^)]*\)';
        $referentialAction = '\s+ON\s+(?:DELETE|UPDATE)\s+(?:CASCADE|RESTRICT|NO\s+ACTION|SET\s+NULL|SET\s+DEFAULT)';

        return (string)preg_replace(
            '/,\s*CONSTRAINT\s+' . $quotedName . '\s+FOREIGN\s+KEY\s*' . $columnList
            . '\s*REFERENCES\s+(?:' . $quotedName . '\.)?' . $quotedName . '\s*' . $columnList
            . '(?:' . $referentialAction . ')*/i',
            '',
            $input
        );
    }








    public function dropForeignKeys(string $tableName, array $constraintNames): bool
    {
        if ($this->isSqlLite || $constraintNames === []) {
            return true;
        }

 
        if ($this->isProductionSiteTableOrView($tableName)) {
            $this->errors[] = sprintf('Trying to drop the foreign keys of table %s of the main WP installation!', $tableName);

            return false;
        }

        $isDropped = true;
        $lastError = '';
        foreach ($constraintNames as $constraintName) {
            $result = $this->client->query(sprintf(
                "ALTER TABLE `%s` DROP FOREIGN KEY `%s`;",
                str_replace('`', '``', $tableName),
                str_replace('`', '``', $constraintName)
            ));

            if ($result !== false) {
                continue;
            }

            $isDropped = false;
            $lastError = $this->client->error();
        }

        if (!$isDropped) {
            $this->errors[] = sprintf('Could not drop the foreign keys of the table %s. Error: %s', $tableName, $lastError);
        }

        return $isDropped;
    }








    public function getForeignKeysByTable(string $prefix): array
    {
        if ($this->isSqlLite) {
            return [];
        }

        $wpdb = $this->database->getWpdba()->getClient();

 
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT DISTINCT TABLE_NAME, CONSTRAINT_NAME FROM information_schema.KEY_COLUMN_USAGE
                 WHERE TABLE_SCHEMA = %s AND TABLE_NAME LIKE %s AND REFERENCED_TABLE_NAME IS NOT NULL",
                $wpdb->dbname,
                $this->database->escapeSqlPrefixForLIKE($prefix) . '%'
            ),
            ARRAY_A
        );

        if (!is_array($rows)) {
            return [];
        }

        $foreignKeys = [];
        foreach ($rows as $row) {
            $foreignKeys[$row['TABLE_NAME']][] = $row['CONSTRAINT_NAME'];
        }

        return $foreignKeys;
    }






    public function replaceTableOptions(string $input): string
    {
        $search = [
            'TYPE=InnoDB',
            'TYPE=MyISAM',
            'ENGINE=Aria',
            'TRANSACTIONAL=0',
            'TRANSACTIONAL=1',
            'PAGE_CHECKSUM=0',
            'PAGE_CHECKSUM=1',
            'TABLE_CHECKSUM=0',
            'TABLE_CHECKSUM=1',
            'ROW_FORMAT=PAGE',
            'ROW_FORMAT=FIXED',
            'ROW_FORMAT=DYNAMIC',
        ];
        $replace = [
            'ENGINE=InnoDB',
            'ENGINE=MyISAM',
            'ENGINE=MyISAM',
            '',
            '',
            '',
            '',
            '',
            '',
            '',
            '',
            '',
        ];

        return str_ireplace($search, $replace, $input);
    }





    public function lockTable(string $tableName)
    {
        if (!$this->client->query("LOCK TABLES `$tableName` WRITE;")) {
            throw new RuntimeException("WP STAGING: Could not lock table $tableName: " . $this->client->error(), (int)$this->client->errno());
        }
    }








    public function lockTableOrGiveUp(string $tableName)
    {
        $lockWaitTimeout = $this->boundLockWait();

        try {
            $this->lockTable($tableName);
        } finally {
            $this->restoreLockWait($lockWaitTimeout);
        }
    }





    public function unlockTables()
    {
        if (!$this->client->query("UNLOCK TABLES;")) {
            throw new RuntimeException("WP STAGING: Could not unlock tables");
        }
    }






    public function getColumnTypes(string $tableName): array
    {
        $column_types = [];

        $result = $this->client->query("SHOW COLUMNS FROM `{$tableName}`");
        while ($row = $this->client->fetchAssoc($result)) {
            if (isset($row['Field'])) {
                $column_types[strtolower($row['Field'])] = strtolower($row['Type']);
            }
        }

        $this->client->freeResult($result);

        return $column_types;
    }





    public function isProductionSiteTableOrView($tableOrView): bool
    {
 
        if ($this->database->isExternal()) {
            return false;
        }

        $tableOrView      = $this->database->normalizeTableNameCase($tableOrView);
        $productionPrefix = $this->database->normalizeTableNameCase($this->database->getProductionPrefix());

 
        $result = $this->strHelper->startsWith($tableOrView, $productionPrefix);
        if (!$result) {
            return false;
        }

        $tmpPrefixes = $this->getTmpPrefixes($productionPrefix);

        if (in_array($productionPrefix, $tmpPrefixes)) {
            return true;
        }

        foreach ($tmpPrefixes as $tmpPrefix) {
            if ($this->strHelper->startsWith($tableOrView, $tmpPrefix) && $this->strHelper->startsWith($tmpPrefix, $productionPrefix)) {
                return false;
            }
        }

        return true;
    }








    private function getTmpPrefixes(string $productionPrefix): array
    {
        $tmpPrefixes = [
            DatabaseImporter::TMP_DATABASE_PREFIX,
            DatabaseImporter::TMP_DATABASE_PREFIX_TO_DROP,
        ];

        $customTmpPrefix = $this->database->normalizeTableNameCase($this->customTmpPrefix);
        if ($customTmpPrefix === '' || $customTmpPrefix === $productionPrefix || in_array($customTmpPrefix, $tmpPrefixes)) {
            return $tmpPrefixes;
        }

        $tmpPrefixes[] = $customTmpPrefix;

        return $tmpPrefixes;
    }






    private function getTablesFindQueryByTableType(string $tableType, string $prefix = ''): string
    {

        if ($this->isSqlLite) {
 
            $tableType = $tableType === 'VIEW' ? 'view' : 'table';
            $query     = "SELECT name FROM sqlite_master WHERE type = '{$tableType}'";
            if (!empty($prefix)) {
                $query .= " AND name LIKE '{$this->database->escapeSqlPrefixForLIKE($prefix)}%'";
            }
        } else {
 
            $dbname = $this->database->getWpdba()->getClient()->dbname;
            $query  = "SHOW FULL TABLES FROM `{$dbname}` WHERE `Table_type` = '{$tableType}'";
            if (!empty($prefix)) {
                $query .= " AND `Tables_in_{$dbname}` LIKE '{$this->database->escapeSqlPrefixForLIKE($prefix)}%'";
            }
        }

        return $query;
    }
}
