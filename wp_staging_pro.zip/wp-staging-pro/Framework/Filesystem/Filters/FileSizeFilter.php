<?php

namespace WPStaging\Framework\Filesystem\Filters;

use Iterator;

class FileSizeFilter extends AbstractFilterIterator
{
    private $sizeFilters = [];
    public function __construct(Iterator $iterator, $sizeFilters = [])
    {
        parent::__construct($iterator);
        $this->sizeFilters = $sizeFilters;
    }

    #[\ReturnTypeWillChange]
    public function accept()
    {
        $current = $this->current();

        $isFile = $this->isFileSafely($current);
        if ($isFile === null) {
            return false;
        }

 
        if (!$isFile) {
            return true;
        }

        $fileSize = $current->getSize();
        foreach ($this->sizeFilters as $sizeFilter) {
            $sizeComparator = explode(' ', $sizeFilter);
            if (count($sizeComparator) !== 2) {
                continue;
            }

            if ($this->compareBytes($fileSize, $sizeComparator[1], $sizeComparator[0])) {
                return false;
            }
        }

        return true;
    }









    public function compareBytes($compare, $compareWith, $comparator = '=')
    {
        $compare = wp_convert_hr_to_bytes($compare);
        $compareWith = wp_convert_hr_to_bytes($compareWith);

 
        if (($comparator === '=' || $comparator === ExcludeFilter::SIZE_EQUAL_TO) && ($compare == $compareWith)) {
            return true;
        }

 
        if (($comparator === '>' || $comparator === ExcludeFilter::SIZE_GREATER_THAN) && ($compare > $compareWith)) {
            return true;
        }

 
        if (($comparator === '<' || $comparator === ExcludeFilter::SIZE_LESS_THAN) && ($compare < $compareWith)) {
            return true;
        }

        return false;
    }
}
