<?php

namespace WPStaging\Framework\Facades\UI;

use WPStaging\Component\Alert as AlertComponent;
use WPStaging\Framework\Facades\Facade;

/**
 * @method static void render(string $title = '', string $desc = '', string $buttonText = '', string $buttonUrl = '', bool $closeable = false, array $attributes = [])
 * @method static void renderCloseable()
 */
class Alert extends Facade
{



    protected static function getFacadeAccessor(): string
    {
        return AlertComponent::class;
    }
}
