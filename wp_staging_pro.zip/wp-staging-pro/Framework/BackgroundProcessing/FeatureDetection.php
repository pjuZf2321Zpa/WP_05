<?php







namespace WPStaging\Framework\BackgroundProcessing;

use WP_Error;
use WPStaging\Framework\Adapter\WpAdapter;
use WPStaging\Framework\Network\HttpBasicAuth;
use WPStaging\Framework\Notices\Notices;

use function WPStaging\functions\debug_log;






class FeatureDetection
{
    use HttpBasicAuth;

 
    const ACTION_AJAX_TEST = 'wpstg_ajax_test_action';

 
    const ACTION_AJAX_SUPPORT_FEATURE_DETECTION = 'wpstg_q_ajax_support_feature_detection';

 
    const FILTER_HTTPS_LOCAL_SSL_VERIFY = 'https_local_ssl_verify';

 
    const AJAX_OPTION_NAME = 'wpstg_q_feature_detection_ajax_available';

 
    const AJAX_REQUEST_QUERY_VAR = 'wpstg_q_ajax_check';






    protected $isAjaxAvailableCache;








    public function isAjaxAvailable($showAdminNotice = true)
    {
 
        if ($this->isAjaxAvailableCache === null) {
 
 
            $notRightContext = wp_installing() || (defined('REST_REQUEST') && REST_REQUEST) || (new WpAdapter())->doingAjax()
                || wp_doing_cron() || !is_admin();

            if ($notRightContext) {
 
                debug_log(sprintf(
                    "isAjaxAvailable not right context: Is WP Installing? %s - Is Rest? %s - Is Ajax? %s - Is Cron? %s - Is admin? %s",
                    wp_installing() ? 'true' : 'false',
                    (defined('REST_REQUEST') && REST_REQUEST) ? 'true' : 'false',
                    (new WpAdapter())->doingAjax() ? 'true' : 'false',
                    wp_doing_cron() ? 'true' : 'false',
                    is_admin() ? 'true' : 'false'
                ), 'info', false);
                return true;
            }

            $availableOptionValue = get_option(self::AJAX_OPTION_NAME, null);

            if (!in_array($availableOptionValue, ['y', 'n'], true)) {
                $available            = $this->runAjaxFeatureTest();
                $availableOptionValue = $available ? 'y' : 'n';
                update_option(self::AJAX_OPTION_NAME, $availableOptionValue, false);
            }

            $this->isAjaxAvailableCache = $availableOptionValue === 'y';
        }

        if (!$this->isAjaxAvailableCache && $showAdminNotice) {
            add_action(Notices::ACTION_ADMIN_NOTICES, [$this, 'ajaxSupportMissingAdminNotice']);
        }

 

        return $this->isAjaxAvailableCache;
    }



















    public function runAjaxFeatureTest()
    {
 
        debug_log('Starting from a clean state...', 'info', false);
        delete_option(self::AJAX_OPTION_NAME);

        $ajaxUrl = add_query_arg([
            'action'      => self::ACTION_AJAX_TEST,
            '_ajax_nonce' => wp_create_nonce(self::ACTION_AJAX_TEST),
        ], admin_url('admin-ajax.php'));

        $hash = md5(uniqid(__CLASS__, true));

        debug_log('Sending request to: ' . $ajaxUrl, 'info', false);

        $httpAuthHeaders = $this->getHttpAuthHeaders();
        $response        = wp_remote_post(esc_url_raw($ajaxUrl), [
            'headers'   => array_merge(
                ['X-WPSTG-Request' => self::ACTION_AJAX_TEST],
                $httpAuthHeaders
            ),
            'blocking'  => false,
            'timeout'   => 0.01,
            'cookies'   => !empty($_COOKIE) ? $_COOKIE : [],
            'sslverify' => $this->shouldVerifySslForHttpAuthHeaders($httpAuthHeaders),
            'body'      => [self::AJAX_OPTION_NAME => $hash],
        ]);

        debug_log(wp_json_encode($response), 'info', false);

        if ($response instanceof WP_Error) {
            return false;
        }

        $test = static function () {
 
            global $wpdb;
            $fetched = $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT `option_value` from `{$wpdb->options}` WHERE `option_name` = '%s' AND `option_value` = 'y'",
                    self::AJAX_OPTION_NAME
                )
            );

            debug_log('Fetched is equal to: ' . $fetched, 'info', false);
            debug_log('Fetched is equal to (get_option): ' . get_option(self::AJAX_OPTION_NAME), 'info', false);

            return $fetched === 'y';
        };

        $waited   = 0;
        $waitStep = .5 * 1e6; 
        $timeout  = 10 * 1e6; 

        do {
            debug_log('runAjaxFeatureTest waited ' . number_format($waited / 1e6, 1) . ' seconds...', 'info', false);
            $waited += $waitStep;
            usleep((int)$waitStep);

            if ($test()) {
 
                debug_log('runAjaxFeatureTest worked', 'info', false);
                return true;
            }
        } while ($waited <= $timeout);

 
        debug_log('runAjaxFeatureTest did not work', 'info', false);
        return false;
    }














    public function updateAjaxTestOption()
    {
        debug_log('Running updateAjaxTestOption', 'info', false);
        check_ajax_referer(self::ACTION_AJAX_TEST);

        if (!update_option(self::AJAX_OPTION_NAME, 'y', false)) {
            debug_log('updateAjaxTestOption update_option returned false', 'info', false);
        }

        debug_log('Complete updateAjaxTestOption. New value: ' . get_option(self::AJAX_OPTION_NAME), 'info', false);
    }







    public function ajaxSupportMissingAdminNotice()
    {
        $message = __(
            'WP STAGING Background Processing system cannot use AJAX: this will prevent it from performing at its best.',
            'wp-staging'
        );
        $checkLink = sprintf(
            '<a href="%s">%s</a>',
            esc_url(admin_url('/?' . self::AJAX_REQUEST_QUERY_VAR . '=1')),
            __('Click here to check again now.', 'wp-staging')
        );
        ?>
        <div class="notice notice-warning is-dismissible wpstg__notice wpstg__notice--warning">
            <p><?php echo wp_kses_post($message); ?></p>
            <p><?php echo wp_kses_post($checkLink); ?></p>
        </div>
        <?php
    }
}
