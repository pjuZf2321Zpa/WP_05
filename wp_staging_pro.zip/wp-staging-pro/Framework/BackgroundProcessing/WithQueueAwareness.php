<?php







namespace WPStaging\Framework\BackgroundProcessing;

use WP_Error;
use WPStaging\Framework\Facades\Hooks;
use WPStaging\Framework\Network\HttpBasicAuth;
use WPStaging\Framework\SiteInfo;

use function WPStaging\functions\debug_log;






trait WithQueueAwareness
{
    use HttpBasicAuth;






    private $didFireAjaxAction = false;







    public static function getDefaultPriority()
    {
        return 0;
    }












    public function fireAjaxAction($bodyData = null)
    {
        if ($this->didFireAjaxAction) {
 
            return false;
        }

        $ajaxUrl = add_query_arg([
            'action'      => QueueProcessor::ACTION_QUEUE_PROCESS,
            '_ajax_nonce' => wp_create_nonce(QueueProcessor::ACTION_QUEUE_PROCESS),
        ], admin_url('admin-ajax.php'));

        $useGetMethod = false;
        $requestSent  = false;
 
        $useGetMethod = get_site_transient(QueueProcessor::TRANSIENT_REQUEST_GET_METHOD);
 
        if ($useGetMethod === false) {
 
            $useGetMethod = $this->checkGetRequestNeededForQueue($ajaxUrl, $bodyData);
 
            $requestSent  = !$useGetMethod;

            set_site_transient(QueueProcessor::TRANSIENT_REQUEST_GET_METHOD, $useGetMethod ? 'Yes' : 'No', HOUR_IN_SECONDS);
            debug_log('[WPSTG Fire Ajax] GET method is ' . ($useGetMethod ? 'needed' : 'not needed') . ' for Queue AJAX request.', 'info', false);
        } else {
            $useGetMethod = $useGetMethod === 'Yes';
        }

 
        if ($requestSent) {
            $this->didFireAjaxAction = true;

            Hooks::doAction('wpstg_queue_fire_ajax_request', $this);

            return true;
        }

 
        $useGetMethod = Hooks::applyFilters(QueueProcessor::FILTER_REQUEST_FORCE_GET_METHOD, $useGetMethod);

        $blocking = $this->useBlockingRequest();
        debug_log('[WPSTG Fire Ajax] Firing AJAX request to process Queue actions. GET method: ' . ($useGetMethod ? 'Yes' : 'No'), 'debug', false);

        $httpAuthHeaders = $this->getHttpAuthHeaders();
        $response        = wp_remote_request(esc_url_raw($ajaxUrl), [
            'headers'   => array_merge(
                ['X-WPSTG-Request' => QueueProcessor::ACTION_QUEUE_PROCESS],
                $httpAuthHeaders
            ),
            'method'    => $useGetMethod ? 'GET' : 'POST',
            'blocking'  => $blocking,
            'timeout'   => $blocking ? 30 : 0.01, 
            'cookies'   => $this->getQueueRequestCookies(),
            'sslverify' => $this->shouldVerifySslForHttpAuthHeaders($httpAuthHeaders),
            'body'      => $this->normalizeAjaxRequestBody($bodyData),
        ]);






        if ($response instanceof WP_Error) {
            \WPStaging\functions\debug_log(json_encode([
                'root'     => 'Queue processing admin-ajax request failed.',
                'class'    => get_class($this),
                'code'     => $response->get_error_code(),
                'message'  => $response->get_error_message(),
                'data'     => $response->get_error_data(),
                'blocking' => $blocking,
                'method'   => $useGetMethod ? 'GET' : 'POST',
            ], JSON_PRETTY_PRINT));

            delete_site_transient(QueueProcessor::TRANSIENT_REQUEST_GET_METHOD);
            $this->recordFireFailure();

            return false;
        }

        if ($blocking && is_array($response)) {
            $code = isset($response['response']['code']) ? (int)$response['response']['code'] : 0;
            if ($code < 200 || $code >= 300) {
                $failures = (int)get_site_transient(QueueProcessor::TRANSIENT_FIRE_FAILURE_COUNT) + 1;
                debug_log('[BG Queue] fire failed: HTTP code=' . $code . ' (failure ' . $failures . ')', 'info', false);
                delete_site_transient(QueueProcessor::TRANSIENT_REQUEST_GET_METHOD);
                $this->recordFireFailure();
                return false;
            }

            if ((int)get_site_transient(QueueProcessor::TRANSIENT_FIRE_FAILURE_COUNT) > 0) {
                debug_log('[BG Queue] fire mode -> non-blocking (loopback healthy, code=' . $code . ')', 'info', false);
                delete_site_transient(QueueProcessor::TRANSIENT_FIRE_FAILURE_COUNT);
            }
        }

 
        set_site_transient(QueueProcessor::TRANSIENT_LAST_FIRE_TIMESTAMP, time(), QueueProcessor::TRANSIENT_FIRE_STATE_TTL);

        $this->didFireAjaxAction = true;








        do_action('wpstg_queue_fire_ajax_request', $this);

        return true;
    }











    private function normalizeAjaxRequestBody($bodyData)
    {
        $normalized = (array)$bodyData;

        $normalized['_referer'] = __CLASS__;

        return $normalized;
    }






    private function checkGetRequestNeededForQueue(string $ajaxUrl, $bodyData = null): bool
    {
 
        $httpAuthHeaders = $this->getHttpAuthHeaders();
        $response        = wp_remote_post(esc_url_raw($ajaxUrl), [
            'headers'   => array_merge(
                ['X-WPSTG-Request' => QueueProcessor::ACTION_QUEUE_PROCESS],
                $httpAuthHeaders
            ),
            'blocking'  => true,
            'timeout'   => 5,
            'cookies'   => $this->getQueueRequestCookies(),
            'sslverify' => $this->shouldVerifySslForHttpAuthHeaders($httpAuthHeaders),
            'body'      => $this->normalizeAjaxRequestBody($bodyData),
        ]);

        if ($response instanceof WP_Error) {
            debug_log('[WPSTG Fire Ajax] checkGetRequestNeededForQueue POST failed: code=' . $response->get_error_code() . ' message=' . $response->get_error_message(), 'debug', false);
        } elseif (is_array($response) && isset($response['response']['code'])) {
            debug_log('[WPSTG Fire Ajax] checkGetRequestNeededForQueue POST response code=' . $response['response']['code'], 'debug', false);
        }

 
        if ($response instanceof WP_Error) {
            return true;
        }

        if (!is_array($response)) {
            return false;
        }

 
        if (
            array_key_exists('response', $response) &&
            array_key_exists('code', $response['response']) &&
            $response['response']['code'] === 404
        ) {
            return true;
        }

        return false;
    }

 
    private function getQueueRequestCookies(): array
    {
        $cookies = $this->getLoginRelatedCookies();
        if (!$this->isWPEngine()) {
            return $cookies;
        }

        $wpEngineAuthCookie = $_COOKIE['wpe-auth'] ?? null; // phpcs:ignore WPStagingCS.Security.SanitizeInput.InputNotSanitized -- Read the opaque token; RFC 6265 octet validation below gates forwarding without altering authentication.
        if (is_scalar($wpEngineAuthCookie) && preg_match('/^[\x21\x23-\x2b\x2d-\x3a\x3c-\x5b\x5d-\x7e]*$/D', (string)$wpEngineAuthCookie) === 1) {
            $cookies['wpe-auth'] = (string)$wpEngineAuthCookie;
            return $cookies;
        }

        $wpEngineApiKey = $this->getWPEngineApiKey();
        if ($wpEngineApiKey !== null && $wpEngineApiKey !== '') {
            $cookies['wpe-auth'] = md5('wpe_auth_salty_dog|' . $wpEngineApiKey);
        }

        return $cookies;
    }

    protected function isWPEngine(): bool
    {
        return (new SiteInfo())->isWPEngine();
    }




    protected function getWPEngineApiKey()
    {
        if (!defined('WPE_APIKEY')) {
            return null;
        }

        return (string)constant('WPE_APIKEY');
    }

    private function useBlockingRequest(): bool
    {
        if (defined('DOING_AJAX') && DOING_AJAX) {
            return false;
        }

        if (function_exists('wp_get_environment_type') && wp_get_environment_type() === 'local') {
            return true;
        }

        return (int)get_site_transient(QueueProcessor::TRANSIENT_FIRE_FAILURE_COUNT) >= QueueProcessor::ADAPTIVE_BLOCKING_THRESHOLD;
    }




    private function recordFireFailure()
    {
        $failures = (int)get_site_transient(QueueProcessor::TRANSIENT_FIRE_FAILURE_COUNT);
        if ($failures >= 10) {
            return;
        }

        $newFailures = $failures + 1;
        set_site_transient(QueueProcessor::TRANSIENT_FIRE_FAILURE_COUNT, $newFailures, QueueProcessor::TRANSIENT_FIRE_STATE_TTL);

        if ($failures < QueueProcessor::ADAPTIVE_BLOCKING_THRESHOLD && $newFailures >= QueueProcessor::ADAPTIVE_BLOCKING_THRESHOLD) {
            debug_log('[BG Queue] fire mode -> blocking (consecutive silent failures=' . $newFailures . ')', 'info', false);
        }
    }
}
