<?php

namespace WPStaging\Backend\Pro\Upgrade;

use WPStaging\Backend\Optimizer\Optimizer;
use WPStaging\Notifications\Notifications;
use WPStaging\Pro\Notices\BackupsDifferentPrefixNotice;
use WPStaging\Core\Cron\Cron;
use WPStaging\Core\Utils\Logger;
use WPStaging\Core\Utils\IISWebConfig;
use WPStaging\Core\Utils\Htaccess;
use WPStaging\Core\WPStaging;
use WPStaging\Framework\Utils\Urls;
use WPStaging\Staging\Sites;
use WPStaging\Staging\Service\StagingEngine;
use WPStaging\Backup\BackupRepairer;
use WPStaging\Backup\Service\BackupsFinder;
use WPStaging\Backup\BackupScheduler;
use WPStaging\Framework\BackgroundProcessing\Queue;
use WPStaging\Framework\Notices\NextGenEngineNotice;
use WPStaging\Backup\Storage\Providers;
use WPStaging\Backup\Storage\SftpProfileStore;
use WPStaging\Framework\Upgrade\UpgradeFlags;
use WPStaging\Pro\Auth\TemporaryLogins;
use WPStaging\Pro\Backup\Storage\GoogleDrive\Auth as GoogleDriveAuth;

use function WPStaging\functions\debug_log;






class Upgrade
{



    const OPTION_UPGRADE_DATE = 'wpstgpro_upgrade_date';




    const OPTION_INSTALL_DATE = 'wpstgpro_install_date';




    const LOCK_TEMPORARY_LOGIN_LINKS_REISSUE = 'wpstg_temporary_login_links_reissue';





    private $previousVersion;





    private $clones;





    private $settings;





    private $logger;





    private $db;




    private $stagingSitesHelper;




    private $backupRepairer;




    private $backupsFinder;




    private $upgradeFlags;

    public function __construct()
    {
 
        $this->previousVersion = preg_replace('/[^0-9.].*/', '', get_option('wpstgpro_version'));

 
        $this->clones = get_option("wpstg_existing_clones", []);

 
 
        $this->settings = (object)get_option("wpstg_settings", []);

        $this->db = WPStaging::getInstance()->get("wpdb");

 
        $this->logger = new Logger();

 
        $this->stagingSitesHelper = WPStaging::make(Sites::class);
        $this->backupRepairer     = WPStaging::make(BackupRepairer::class);
        $this->backupsFinder      = WPStaging::make(BackupsFinder::class);
        $this->upgradeFlags       = WPStaging::make(UpgradeFlags::class);
    }




    public function doUpgrade()
    {
        $this->upgrade2_0_3();
        $this->upgrade2_0_4();
        $this->upgrade2_1_7();
        $this->upgrade2_3_6();
        $this->upgrade2_6_5();
        $this->upgrade2_8_6();
        $this->upgrade4_0_3();
        $this->upgrade4_0_5();
        $this->upgrade4_0_6();
        $this->upgrade4_2_1();
        $this->upgrade4_3_1();
        $this->upgrade5_0_5();
        $this->upgrade5_0_7();
        $this->upgrade6_7_1();
        $this->migrateExcludedHostingFilesOptionName();
        $this->migrateRemoteStorageOptionNames();
        $this->migrateSftpDestinationsToSettingsTable();
        $this->encryptStoredGoogleDriveTokens();
        $this->deleteMigratedLegacyStorageOptions();
        $this->maybeWarnAboutAffectedNextGenStagingSites();
        $this->adoptTheRunsOfTheStoredBackupPlans();
        $this->reissueStoredTemporaryLoginLinks();
        $this->maybeUpdateOptimizer();
        $this->normalizeSettingsShape();
        if (!$this->upgradeFlags->has('corrupted_staging_report_removed')) {
            WPStaging::make(\WPStaging\Staging\Ajax\Repair::class)->deleteLegacyReport();
        }

        $this->setVersion();
    }


















    private function adoptTheRunsOfTheStoredBackupPlans()
    {
        if ($this->upgradeFlags->has('schedule_runs_adopted')) {
            return;
        }

        WPStaging::make(BackupScheduler::class)->adoptRunsFromExistingBackups();
        $this->upgradeFlags->mark('schedule_runs_adopted');
    }







    private function reissueStoredTemporaryLoginLinks()
    {
        if ($this->upgradeFlags->has('temporary_login_links_reissued') || wp_doing_ajax()) {
            return;
        }

        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        if (!\WP_Upgrader::create_lock(self::LOCK_TEMPORARY_LOGIN_LINKS_REISSUE, MINUTE_IN_SECONDS)) {
            return;
        }

        if (WPStaging::make(TemporaryLogins::class)->reissueLoginLinks()) {
            $this->upgradeFlags->mark('temporary_login_links_reissued');
        }

        \WP_Upgrader::release_lock(self::LOCK_TEMPORARY_LOGIN_LINKS_REISSUE);
    }

    private function maybeWarnAboutAffectedNextGenStagingSites()
    {
        if ($this->upgradeFlags->has('next_gen_engine_disabled')) {
            return;
        }

        $stagingEngine = WPStaging::make(StagingEngine::class);
        if ($stagingEngine->getStoredEngine() === StagingEngine::ENGINE_NEXT_GEN) {
            if (!$stagingEngine->isNextGenEnabled()) {
                $stagingEngine->saveEngine(StagingEngine::ENGINE_LEGACY);
            }

            $hasStagingSites = !empty(get_option(Sites::STAGING_SITES_OPTION, []))
                || !empty(get_option(Sites::OLD_STAGING_SITES_OPTION, []));
            if ($hasStagingSites) {
                WPStaging::make(NextGenEngineNotice::class)->enable();
            }
        }

        $this->upgradeFlags->mark('next_gen_engine_disabled');
    }





    private function upgrade5_0_7()
    {
 
        if (version_compare($this->previousVersion, '5.0.6', '>')) {
            return;
        }

        $queueUtil = WPStaging::make(Queue::class);
        $queueUtil->maybeAddResponseColumnToTable();
    }







    private function migrateExcludedHostingFilesOptionName()
    {
        $newOptionName = Sites::STAGING_EXCLUDED_HOSTING_FILES_OPTION;
        $oldOptionName = 'wpstg_clone_excluded_gd_files_list';
        $missing       = '__wpstg_missing__';

        if (get_option($newOptionName, $missing) !== $missing) {
            return;
        }

        $oldOption = get_option($oldOptionName, $missing);
        if ($oldOption !== $missing) {
            update_option($newOptionName, $oldOption, false);
            return;
        }

        add_option($newOptionName, [], '', false);
    }










    private function migrateRemoteStorageOptionNames()
    {
        if ($this->upgradeFlags->has('remote_storage_option_names_migrated')) {
            return;
        }

        (new Providers())->migrateRemoteStorageOptions();
        $this->upgradeFlags->mark('remote_storage_option_names_migrated');
    }






    private function migrateSftpDestinationsToSettingsTable()
    {
        if ($this->upgradeFlags->has('sftp_destinations_migrated')) {
            return;
        }

        if (!WPStaging::make(SftpProfileStore::class)->migrateLegacyOption()) {
            return;
        }

        $this->upgradeFlags->mark('sftp_destinations_migrated');
    }




    private function encryptStoredGoogleDriveTokens()
    {
        if ($this->upgradeFlags->has('google_drive_tokens_encrypted')) {
            return;
        }

        WPStaging::make(GoogleDriveAuth::class)->encryptStoredCredentials();
        $this->upgradeFlags->mark('google_drive_tokens_encrypted');
    }




    private function deleteMigratedLegacyStorageOptions()
    {
        if ($this->upgradeFlags->has('migrated_legacy_storage_options_deleted')) {
            return;
        }

        (new Providers())->deleteMigratedLegacyStorageOptions();
        $this->upgradeFlags->mark('migrated_legacy_storage_options_deleted');
    }






    private function upgrade5_0_5()
    {
 
        if (!empty($this->previousVersion)) {
            return;
        }

        $user = wp_get_current_user();
        if (is_admin() && current_user_can('activate_plugins') && !empty($user->user_email)) {
            update_option(Notifications::OPTION_BACKUP_SCHEDULE_REPORT_EMAIL, $user->user_email);
        }

        update_option(BackupScheduler::OPTION_BACKUP_SCHEDULE_ERROR_REPORT, 'true');
    }






    private function upgrade4_3_1()
    {
        if (!is_multisite()) {
            return;
        }

 
        if (version_compare($this->previousVersion, '4.3.1', '<') && version_compare($this->previousVersion, '4.0.0', '>=')) {
 
            $backupsFinder = WPStaging::make(BackupsFinder::class);
            $backups       = $backupsFinder->findBackups();
 
            if (count($backups) > 0) {
                (new BackupsDifferentPrefixNotice())->enable();
            }
        }
    }





    public function upgrade2_0_3()
    {
 
        if (version_compare($this->previousVersion, '2.0.2', '<')) {
            $this->initialInstall();
            $this->upgradeClonesBeta();
            $this->upgradeNotices();
        }
    }





    public function upgrade2_0_4()
    {
        if ($this->previousVersion === false || version_compare($this->previousVersion, '2.0.5', '<')) {
 
            $cron = new Cron();
            $cron->scheduleEvent();
        }
    }





    private function upgrade4_2_1()
    {
        $forceUpgrade = false;

        if ($forceUpgrade || (version_compare($this->previousVersion, '4.2.1', '<=') && version_compare($this->previousVersion, '4.1.9', '>='))) {
            $this->addMissingBackupSizeToBackupMetadata();
        }
    }





    private function upgrade4_0_6(bool $forceUpgrade = false)
    {
        $forceUpgrade = false;

        if ($forceUpgrade || version_compare($this->previousVersion, '4.0.6', '<')) {
            $this->upgradeCopyExcludedTablesToTablePushSelection();
        }
    }





    private function upgrade4_0_5()
    {
        $this->stagingSitesHelper->addMissingCloneNameUpgradeStructure();
        $this->stagingSitesHelper->upgradeStagingSitesOption();
    }






    private function upgrade4_0_3()
    {
 
        if (version_compare($this->previousVersion, '4.0.3', '<') && version_compare($this->previousVersion, '4.0.0', '>=')) {
 
            $backupsFinder = WPStaging::make(BackupsFinder::class);
            $backups       = $backupsFinder->findBackups();
 
            if (count($backups) > 0) {
                (new BackupsDifferentPrefixNotice())->enable();
            }
        }
    }





    private function upgrade2_8_6()
    {
 
        if (version_compare($this->previousVersion, '2.8.6', '<')) {
 
            $sites = $this->stagingSitesHelper->tryGettingStagingSites();

            $new = [];

 
            foreach ($sites as $oldKey => $site) {
                $key       = preg_replace("#\W+#", '-', strtolower($oldKey));
                $new[$key] = $sites[$oldKey];
            }

            if (!empty($new)) {
                $this->stagingSitesHelper->updateStagingSites($new);
            }
        }
    }




    private function upgrade2_6_5()
    {
 
        if (version_compare($this->previousVersion, '2.6.5', '<')) {
 
            $htaccess = new Htaccess();
            $htaccess->create(trailingslashit(WPStaging::getContentDir()) . '.htaccess');
            $htaccess->create(trailingslashit(WPStaging::getContentDir()) . 'logs/.htaccess');

 
            if (extension_loaded('litespeed')) {
                $htaccess->createLitespeed(ABSPATH . '.htaccess');
            }

 
            $webconfig = new IISWebConfig();
            $webconfig->create(trailingslashit(WPStaging::getContentDir()) . 'web.config');
            $webconfig->create(trailingslashit(WPStaging::getContentDir()) . 'logs/web.config');
        }
    }






    private function upgrade2_1_7()
    {
        if ($this->previousVersion === false || version_compare($this->previousVersion, '2.1.7', '<')) {
            $sites = $this->stagingSitesHelper->tryGettingStagingSites();

            foreach ($sites as $key => $value) {
                unset($sites[$key]);
                $sites[preg_replace("#\W+#", '-', strtolower($key))] = $value;
            }

            if (!empty($sites)) {
                $this->stagingSitesHelper->updateStagingSites($sites);
            }
        }
    }





    private function upgrade2_3_6()
    {
 
        if (version_compare($this->previousVersion, '2.3.6', '<')) {
            $this->upgradeElements();
        }
    }





    private function upgradeElements()
    {
 
        $sites = $this->stagingSitesHelper->tryGettingStagingSites();

        if ($sites === false || count($sites) === 0) {
            return;
        }

 
        foreach ($sites as $key => $value) {
            if (empty($sites[$key]['directoryName'])) {
                continue;
            }

            !empty($sites[$key]['prefix']) ?
                $sites[$key]['prefix'] = $value['prefix'] :
                $sites[$key]['prefix'] = $this->getStagingPrefix($sites[$key]['directoryName']);
        }

        if (count($sites) > 0) {
            $this->stagingSitesHelper->updateStagingSites($sites);
        }
    }






    private function getStagingPrefix(string $directory): string
    {
 
        $path = ABSPATH . $directory . "/wp-config.php";

        if (($content = @file_get_contents($path)) === false) {
            $prefix = "";
        } else {
 
            preg_match("/table_prefix\s*=\s*'(\w*)';/", $content, $matches);

            $prefix = "";
            if (!empty($matches[1])) {
                $prefix = $matches[1];
            }
        }

 
        if ($this->db->prefix !== $prefix) {
            return $prefix;
        }

        return "";
    }





    private function initialInstall()
    {
 
        add_option('wpstg_installDate', date('Y-m-d h:i:s'));
        add_option(self::OPTION_INSTALL_DATE, date('Y-m-d h:i:s'));
        $this->settings->optimizer = "1";
        update_option('wpstg_settings', (array)$this->settings);
    }






    private function normalizeSettingsShape()
    {
        $settings = get_option('wpstg_settings');
        if (!is_object($settings)) {
            return;
        }

        update_option('wpstg_settings', (array)$settings);
    }





    private function setVersion(): bool
    {
 
        if (version_compare($this->previousVersion, WPStaging::getVersion(), '<') || $this->isInvalidVersionNumber()) {
 
            update_option('wpstgpro_version', preg_replace('/[^0-9.].*/', '', WPStaging::getVersion()));
 
            update_option('wpstgpro_version_upgraded_from', preg_replace('/[^0-9.].*/', '', $this->previousVersion));
 
            update_option(self::OPTION_UPGRADE_DATE, date('Y-m-d H:i'));

            return true;
        }

        return false;
    }








    private function isInvalidVersionNumber(): bool
    {
        if (strpos($this->previousVersion, '2021', 0) === 0) {
            return true;
        }

        return false;
    }





    private function upgradeClonesBeta()
    {
        if (empty($this->clones) || count($this->clones) === 0) {
            return;
        }

        $existingClones = $this->stagingSitesHelper->tryGettingStagingSites();
        $urlsHelper     = WPStaging::make(Urls::class);

 
        foreach ($this->clones as $key => &$value) {
 
            if (isset($value['directoryName']) || !empty($value['directoryName'])) {
                continue;
            }

 
            if (isset($existingClones[$value])) {
                continue;
            }

            $existingClones[$value]['directoryName'] = $value;
            $existingClones[$value]['path']          = get_home_path() . $value;
            $existingClones[$value]['url']           = $urlsHelper->getHomeUrl() . "/" . $value;
            $existingClones[$value]['number']        = $key + 1;
            $existingClones[$value]['version']       = $this->previousVersion;
        }

        unset($value);

        if (empty($existingClones) || $this->stagingSitesHelper->updateStagingSites($existingClones) === false) {
            $this->logger->log('INFO', 'Failed to upgrade clone data from ' . $this->previousVersion . ' to ' . WPStaging::getVersion());
        }
    }






    private function upgradeNotices()
    {
        $poll   = get_option("wpstg_start_poll", false);
        $beta   = get_option("wpstg_hide_beta", false);
        $rating = get_option("wpstg_RatingDiv", false);

        if ($beta && $beta === "yes") {
            update_option('wpstg_beta', 'no');
        }

        if ($rating && $rating === 'yes') {
            update_option('wpstg_rating', 'no');
        }
    }








    private function upgradeCopyExcludedTablesToTablePushSelection()
    {
        $sites = $this->stagingSitesHelper->tryGettingStagingSites();

        if (empty($sites)) {
            return;
        }

 
        foreach ($sites as &$value) {
            if (!empty($value['excludedTables']) && empty($value['tablePushSelection'])) {
                $value['tablePushSelection'] = $value['excludedTables'];
            }
        }

        if (update_option(Sites::STAGING_SITES_OPTION, $sites, false)) {
 
            update_option(Sites::BACKUP_STAGING_SITES_OPTION, $sites, false);
        }
    }





    private function addMissingBackupSizeToBackupMetadata()
    {
        foreach ($this->backupsFinder->findBackups() as $backup) {
            if (!$this->backupRepairer->repairMetadataSize($backup->getRealPath())) {
                $error = $this->backupRepairer->getError();
                debug_log('Error in WP STAGING upgrade routine affects Backup ' . $backup->getRealPath() . ' - ' . $error, 'error');
            }
        }
    }






    private function upgrade6_7_1()
    {
        if (version_compare($this->previousVersion, '6.7.1', '>')) {
            return;
        }

        $existingEnabledOption = get_option('wpstg_remote_sync_enabled', null);

 
        if ($existingEnabledOption !== null) {
            return;
        }

        $apiToken = get_option('wpstg_remote_sync_api_token', false);

 
        if (!empty($apiToken)) {
            update_option('wpstg_remote_sync_enabled', '1', false);
            return;
        }

 
        update_option('wpstg_remote_sync_enabled', '0', false);
    }




    private function maybeUpdateOptimizer()
    {
        $optimizer = new Optimizer();
        if (!$this->upgradeFlags->has('optimizer_safety_check_revalidated')) {
            $optimizer->forgetSafetyCheckPass();
            $this->upgradeFlags->mark('optimizer_safety_check_revalidated');
        }

        if ($this->previousVersion === false || version_compare($this->previousVersion, WPStaging::getVersion(), '<')) {
            $optimizer->installOptimizer();
        }
    }
}
