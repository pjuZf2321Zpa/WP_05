<?php

namespace WPStaging\Backend\Pro\Modules\Jobs;

use Exception;
use WPStaging\Backend\Modules\Jobs\Job;
use WPStaging\Backend\Pro\Modules\Jobs\Backups\BackupUploadsDir;
use WPStaging\Core\Utils\Logger;
use WPStaging\Core\WPStaging;
use WPStaging\Framework\Analytics\Actions\AnalyticsStagingPush;
use WPStaging\Framework\Database\TableService;
use WPStaging\Pro\Push\Jobs\StagingSitePush;





class Finish extends Job
{
 
    private $tables;

 
    private $tableService;






    public function start()
    {
        $this->tableService = WPStaging::make(TableService::class);

        $this->getTableRecords();

 
        $this->deleteTables();

        $this->scheduleCronToDeleteUploadsBackup();

 
        $this->deleteCacheFiles();

        WPStaging::make(AnalyticsStagingPush::class)->enqueueFinishEvent($this->options->jobIdentifier, $this->options);

        do_action(StagingSitePush::ACTION_PUSHING_COMPLETE, ['networkClone' => !empty($this->options->networkClone)]);

        $this->logger->info("✓ Staging site successfully pushed");

        return [
            "status"     => 'finished',
            "percentage" => 100,
            "total"      => $this->options->totalSteps,
            "step"       => $this->options->currentStep,
            "last_msg"   => $this->logger->getLastLogMsg(),
            "job_done"   => true,
        ];
    }




    protected function scheduleCronToDeleteUploadsBackup()
    {
        $backup = new BackupUploadsDir($this);
        $backup->scheduleDeleteOfTheBackup();

        foreach ($backup->getLogs() as $log) {
            if ($log['type'] === Logger::TYPE_INFO) {
                $this->log($log['msg']);
            }
        }
    }





    protected function deleteCacheFiles()
    {
        $this->log("Finish: Deleting clone job's cache files...");

 
        $this->cloneOptionCache->delete();
        $this->filesIndexCache->delete();

        $this->log("Finish: Clone job's cache files have been deleted!");
    }




    public function deleteTables()
    {
        foreach ($this->tables as $table) {
            $this->tableService->deleteTables([$table]);
        }
    }




    private function getTableRecords()
    {
        $tmpPrefix    = DatabaseTmp::TMP_PREFIX;
        $this->tables = [];
        if ($tmpPrefix !== $this->tableService->getDatabase()->getPrefix()) {
            $this->tables = $this->tableService->findTableNamesStartWith($tmpPrefix);
        }

        $this->tables = array_merge($this->tables, $this->tableService->findTableNamesStartWith(DatabaseTmp::TMP_PREFIX_TO_DROP));
    }
}
