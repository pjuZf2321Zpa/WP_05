<?php

namespace WPStaging\Backend\Pro\Modules\Jobs;

use WPStaging\Backend\Modules\Jobs\Data as CloningData;
use WPStaging\Pro\Staging\Data\Steps\InvalidateLoginLinks;
use WPStaging\Pro\Staging\Data\Steps\MultisiteAddNetworkAdministrators;
use WPStaging\Pro\Staging\Data\Steps\MultisiteUpdateActivePlugins;
use WPStaging\Pro\Staging\Data\Steps\NewAdminAccount;






class CloningProData extends CloningData
{
    protected function initializeSteps()
    {
        parent::initializeSteps();

        if ($this->isMultisiteAndPro() && !$this->isNetworkClone()) {
            $this->steps[] = MultisiteUpdateActivePlugins::class; 
            $this->steps[] = MultisiteAddNetworkAdministrators::class; 
        }

        $this->steps[] = InvalidateLoginLinks::class; 
        $this->steps[] = NewAdminAccount::class; 
    }




    protected function getTables()
    {
        parent::getTables();

        if ($this->isMultisiteAndPro() && !$this->isNetworkClone()) {
 
            $this->tables[] = $this->options->prefix . 'users';
            $this->tables[] = $this->options->prefix . 'usermeta';
        }
    }





    protected function calculateTotalSteps()
    {
        $this->options->totalSteps = 9;

        if ($this->isMultisiteAndPro() && !$this->isNetworkClone()) {
            $this->options->totalSteps = 11;
        }

        $this->options->totalSteps += 2;
    }
}
