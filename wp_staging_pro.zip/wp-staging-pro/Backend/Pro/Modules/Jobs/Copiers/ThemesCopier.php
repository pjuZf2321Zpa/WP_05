<?php

namespace WPStaging\Backend\Pro\Modules\Jobs\Copiers;








class ThemesCopier extends Copier
{



    protected function getCopierType()
    {
        return Copier::TYPE_THEME;
    }
}
