<?php

namespace WPStaging\Backend\Pro\Modules\Jobs\Copiers;








class PluginsCopier extends Copier
{



    protected function getCopierType()
    {
        return Copier::TYPE_PLUGIN;
    }
}
