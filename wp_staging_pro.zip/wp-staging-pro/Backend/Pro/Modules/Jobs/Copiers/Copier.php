<?php

namespace WPStaging\Backend\Pro\Modules\Jobs\Copiers;

use WPStaging\Core\WPStaging;
use WPStaging\Framework\Adapter\Directory;
use WPStaging\Framework\Filesystem\Filesystem;
use WPStaging\Framework\Filesystem\FilesystemExceptions;
use WPStaging\Framework\SiteInfo;
use WPStaging\Framework\Traits\WindowsOsTrait;
use WPStaging\Pro\Push\Service\WindowsLockedRename;









abstract class Copier
{
    use WindowsOsTrait;

 
    const PREFIX_TEMP = 'wpstg-tmp-';

 
    const PREFIX_BACKUP = 'wpstg-bak-';

 
    const TYPE_PLUGIN = 'plugin';

 
    const TYPE_THEME = 'theme';

 
    protected $themesDir;

 
    protected $pluginsDir;

 
    protected $tmpThemesDir;

 
    protected $tmpPluginsDir;

 
    protected $errors = [];






    protected $filesystem;

 
    protected $siteInfo;

 
    private $itemName;

 
    private $basePath;

 
    private $tmpPath;

 
    private $backupPath;

 
    private $logTitle;

 
    private $isFile;

    public function __construct(Filesystem $fileSystem, Directory $directory, SiteInfo $siteInfo)
    {
        $this->filesystem    = $fileSystem;
        $this->siteInfo      = $siteInfo;
        $this->themesDir     = $directory->getActiveThemeParentDirectory();
        $this->pluginsDir    = $directory->getPluginsDirectory();
        $this->tmpPluginsDir = $directory->getPluginsTmpDirectory();
        $this->tmpThemesDir  = $directory->getThemesTmpDirectory();
    }

 
    public function getErrors(): array
    {
        return $this->errors;
    }





    public function copy()
    {
        $destDir = '';
        $tempDir = '';

        $copierType = $this->getCopierType();
        if ($copierType === self::TYPE_PLUGIN) {
            $destDir = $this->pluginsDir;
            $tempDir = $this->tmpPluginsDir;

            $this->logTitle = 'Plugin';
        } elseif ($copierType === self::TYPE_THEME) {
            $destDir = $this->themesDir;
            $tempDir = $this->tmpThemesDir;

            $this->logTitle = 'Theme';
        } else {
            throw new \RuntimeException('Unknown copier type: ' . $copierType);
        }

        if (!is_dir($tempDir)) {
            return;
        }

        $iterator = $this->filesystem
                        ->setRecursive(false)
                        ->setDotSkip()
                        ->setDirectory($tempDir)
                        ->get();

        foreach ($iterator as $item) {
            $this->itemName = $item->getFilename();
 
            if ($this->itemName === 'index.php') {
                @unlink($item->getPathname());
                continue;
            }

 
            if (strpos($this->itemName, Copier::PREFIX_BACKUP) === 0) {
                continue;
            }

            $this->basePath   = $destDir . $this->itemName;
            $this->tmpPath    = $item->getPathname();
            $this->backupPath = $tempDir . Copier::PREFIX_BACKUP . $this->itemName;
            $this->isFile     = $item->isFile();

            if (!$this->backupItem()) {
                $this->errors[] = sprintf('%s Handler: Skipping item %s. Please copy it manually from staging to live via FTP!', $this->logTitle, $this->itemName);
                $this->removeTmpItem();
                continue;
            }

            if (!$this->activateTmpItem()) {
                $this->errors[] = sprintf('%s Handler: Skipping item %s Can not activate it. Please copy it manually from staging to live via FTP.', $this->logTitle, $this->itemName);
                $this->restoreBackupItem();
                continue;
            }

            if (!$this->removeBackupItem()) {
                $this->errors[] = sprintf('%s Handler: Can not remove backup item: %s. Please remove it manually via wp-admin > plugins|themes or via FTP.', $this->logTitle, $this->itemName);
                continue;
            }
        }

 
        $tempDir = untrailingslashit($tempDir);
        if ($this->filesystem->isEmptyDir($tempDir)) {
            $this->filesystem->delete($tempDir);
        }
    }





    public function cleanup()
    {
        $tempDir    = '';
        $destDir    = '';
        $copierType = $this->getCopierType();
        if ($copierType === self::TYPE_PLUGIN) {
            $tempDir        = $this->tmpPluginsDir;
            $destDir        = $this->pluginsDir;
            $this->logTitle = 'Plugin';
        } elseif ($copierType === self::TYPE_THEME) {
            $tempDir        = $this->tmpThemesDir;
            $destDir        = $this->themesDir;
            $this->logTitle = 'Theme';
        } else {
            throw new \RuntimeException('Unknown copier type: ' . $copierType);
        }

        if ($this->siteInfo->isBitnami()) {
            $tempDir = wp_normalize_path(realpath($tempDir));
        }

        if (!is_dir($tempDir)) {
            return;
        }

        $iterator = null;

        try {
            $iterator = $this->filesystem
                ->setRecursive(false)
                ->setDirectory($tempDir)
                ->setDotSkip()
                ->get();
        } catch (FilesystemExceptions $ex) {
            $this->errors[] = $ex->getMessage();
            return;
        }

        foreach ($iterator as $item) {
            if ($this->isBackupOfMissingLiveItem($item->getFilename(), $destDir)) {
                $liveItemPath   = $destDir . substr($item->getFilename(), strlen(self::PREFIX_BACKUP));
                $this->errors[] = sprintf('%s Handler: Kept backup %s because the live item %s is missing. If that item is still missing after this push, move the backup there via FTP to restore it, or delete the backup if the item was removed on purpose.', $this->logTitle, trailingslashit($tempDir) . $item->getFilename(), $liveItemPath);
                continue;
            }

            if ($item->isFile()) {
                unlink($item->getPathname());
                continue;
            }

            if ($item->isDir()) {
                $this->rmDir($item->getPathname());
            }
        }

        $tempDir = untrailingslashit($tempDir);
        if ($this->filesystem->isEmptyDir($tempDir)) {
            $this->filesystem->delete($tempDir);
        }
    }






    private function isBackupOfMissingLiveItem(string $fileName, string $destDir): bool
    {
        if (strpos($fileName, self::PREFIX_BACKUP) !== 0) {
            return false;
        }

        return !file_exists($destDir . substr($fileName, strlen(self::PREFIX_BACKUP)));
    }










    protected function isAllowedToRenameOrRemove(string $path, bool $isInTemp = false): bool
    {
        $realPath = wp_normalize_path(realpath($path));

        if ($realPath === false) {
            return false;
        }

        $pluginsDir = $isInTemp ? $this->tmpPluginsDir : $this->pluginsDir;
        $themesDir  = $isInTemp ? $this->tmpThemesDir : $this->themesDir;
        if ($this->siteInfo->isBitnami()) {
            $pluginsDir = wp_normalize_path(realpath($pluginsDir));
            $themesDir  = wp_normalize_path(realpath($themesDir));
        }

        $isInPluginsFolder = strpos($realPath, $pluginsDir) === 0;
        $isInThemesFolder  = strpos($realPath, $themesDir) === 0;

        return $isInPluginsFolder || $isInThemesFolder;
    }






    protected function isWritable(string $fullPath): bool
    {
        if ($this->isFile && is_writable($fullPath)) {
            return true;
        }

        return is_dir($fullPath) && is_writable($fullPath);
    }





    protected function rm(string $fullPath)
    {
        if ($this->isFile && $this->isAllowedToRenameOrRemove($fullPath, $isInTemp = true)) {
            unlink($fullPath);
            return;
        }

        $this->rmDir($fullPath);
    }





    protected function rmDir(string $fullPath)
    {
        if (!$this->isAllowedToRenameOrRemove($fullPath, $isInTemp = true)) {
            $this->errors[] = 'Trying to remove a file/folder that is outside the expected path: ' . $fullPath;

            return;
        }

        try {
            $this->filesystem->setRecursive()->delete($fullPath);
        } catch (\Exception $e) {
            $this->errors[] = $e->getMessage();

            return;
        }
    }







    protected function rename(string $from, string $to): bool
    {
        if (!$this->isAllowedToRenameOrRemove($from) && !$this->isAllowedToRenameOrRemove($from, $isInTemp = true)) {
            $this->errors[] = 'Trying to rename a file/folder that is outside the expected path: ' . $from;

            return false;
        }

        if ($this->isWindowsOs()) {
            return WPStaging::make(WindowsLockedRename::class)->rename($from, $to);
        }

        return @rename($from, $to);
    }




    protected function getCopierType()
    {
        throw new \RuntimeException('Method getCopierType() must be implemented.');
    }

 
    private function activateTmpItem(): bool
    {
        if (!$this->isWritable($this->tmpPath)) {
            $this->errors[] = sprintf('%s Handler: Temp directory does not exist or is not writable: %s', $this->logTitle, $this->tmpPath);

            return false;
        }

        if (!$this->isWritable($this->tmpPath) || !$this->rename($this->tmpPath, $this->basePath)) {
            $this->errors[] = sprintf('%s Handler: Can not activate item: %s', $this->logTitle, $this->itemName);

            return false;
        }

        return true;
    }





    private function backupItem(): bool
    {
 
        if (!file_exists($this->basePath)) {
            return true;
        }

        if ($this->isWritable($this->backupPath)) {
            $this->rm($this->backupPath);
        }

        if (!$this->isWritable($this->basePath)) {
            $this->errors[] = sprintf('%s Handler: Can not backup item: %s. Path not writeable.', $this->logTitle, $this->basePath);

            return false;
        }

        if (!$this->rename($this->basePath, $this->backupPath)) {
            $this->errors[] = sprintf('%s Handler: Can not backup item: %s. Rename failed.', $this->logTitle, $this->itemName);

            return false;
        }

        return true;
    }




    private function restoreBackupItem(): bool
    {
        if (!$this->isWritable($this->backupPath)) {
            $this->errors[] = sprintf('%s Handler: Can not restore backup item: %s. Path is not writeable.', $this->logTitle, $this->backupPath);

            return false;
        }

        if (!$this->rename($this->backupPath, $this->basePath)) {
            $this->errors[] = sprintf('%s Handler: Can not restore backup item: %s. Rename failed.', $this->logTitle, $this->itemName);

            return false;
        }

        return true;
    }




    private function removeTmpItem(): bool
    {
        if ($this->isWritable($this->tmpPath)) {
            $this->rm($this->tmpPath);

            return true;
        }

        $this->errors[] = sprintf('%s Handler: Can not remove temp item: %s. Path is not writeable. Remove it manually via FTP.', $this->logTitle, $this->tmpPath);

        return false;
    }




    private function removeBackupItem(): bool
    {
 
        if (!file_exists($this->backupPath)) {
            return true;
        }

        if ($this->isWritable($this->backupPath)) {
            $this->rm($this->backupPath);

            return true;
        }

        $this->errors[] = sprintf('%s Handler: Can not remove backup item: %s. Path is not writeable. Remove it manually via FTP.', $this->logTitle, $this->backupPath);

        return false;
    }
}
