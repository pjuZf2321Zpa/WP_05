<?php

namespace WPStaging\Backend\Pro\Modules\Jobs;

use Exception;
use stdClass;
use WPStaging\Backend\Modules\Jobs\JobExecutable;
use WPStaging\Backend\Modules\Jobs\SearchReplace as JobsSearchReplace;
use WPStaging\Backup\Task\Tasks\JobBackup\FinishBackupTask;
use WPStaging\Core\Utils\Logger;
use WPStaging\Core\WPStaging;
use WPStaging\Framework\Facades\Hooks;
use WPStaging\Pro\Database\CustomRulesSearchReplace;
use WPStaging\Staging\Sites;
use WPStaging\Framework\Traits\DbRowsGeneratorTrait;
use WPStaging\Framework\Traits\SerializeTrait;
use WPStaging\Framework\Utils\Strings;
use WPStaging\Framework\Utils\Urls;
use WPStaging\Staging\Service\Database\SubsiteUrlSearchReplace;












class SearchReplace extends JobExecutable
{
    use DbRowsGeneratorTrait;
    use SerializeTrait;

 
    const FILTER_PUSH_SEARCHREPLACE_PARAMS = 'wpstg_push_searchreplace_params';






    protected $maxFailedAttempts = 10;





    protected $processed;




    private $total = 0;




    public $db;





    public $tmpPrefix;





    private $homeUrl;





    private $homeHost;

 
    private $urls;




    public function initialize()
    {
        $this->total = count($this->options->tables);
        $this->db = WPStaging::getInstance()->get("wpdb");
        $this->tmpPrefix = 'wpstgtmp_';
        $this->urls = WPStaging::make(Urls::class);
        $this->homeHost = $this->urls->getBaseUrlWithoutScheme();
        $this->homeUrl = $this->urls->getHomeUrlWithoutScheme();
    }





    private function getDestinationHost()
    {
        $destinationHost = $this->urls->getHomeUrlWithoutScheme();

        if ($this->isSubDir()) {
            $destinationHost = $this->urls->getHomeUrlWithoutScheme() . '/' . $this->getSubDir();
        }

        return $destinationHost;
    }




    public function start()
    {

        $this->run();

 
        $this->saveOptions();

        return (object)$this->response;
    }





    protected function calculateTotalSteps()
    {
        $this->options->totalSteps = $this->total !== 0 ? $this->total : 1;
    }







    protected function execute()
    {
 
        if ($this->isOverThreshold()) {
 
            $this->prepareResponse(false, false);
            $this->saveOptions();
            return false;
        }

 
        if ($this->total === 0) {
            $this->prepareResponse(true, false);
            return false;
        }

 
        if ($this->options->currentStep > $this->total || !isset($this->options->tables[$this->options->currentStep])) {
            $this->prepareResponse(true, false);
            return false;
        }

 
        $tablesExcluded = is_object($this->options) && property_exists($this->options, 'tablesExcludedByFilter') ? $this->options->tablesExcludedByFilter : [];
        if (!empty($this->options->tables[$this->options->currentStep]) && in_array((string)$this->options->tables[$this->options->currentStep], $tablesExcluded)) {
            $table = $this->options->tables[$this->options->currentStep];
            $this->log("DB Search & Replace: Table $table excluded");
            $this->prepareResponse();
            return true;
        }

 
        if (!$this->stopExecution() && !$this->updateTable($this->options->tables[$this->options->currentStep])) {
 
            $this->prepareResponse(false, false);

 
            return true;
        }

 
        $this->prepareResponse();

 
        return true;
    }





    private function stopExecution()
    {
        if ($this->db->prefix == DatabaseTmp::TMP_PREFIX) {
            $this->returnException('Fatal Error 9: Prefix ' . $this->db->prefix . ' is used for the live site hence it can not be used for the staging site as well. Please ask support@wp-staging.com how to resolve this.');
        }

        return false;
    }






    private function updateTable($tableName)
    {
        $strings = new Strings();
        $tableNameWithoutPrefix = $strings->str_replace_first($this->options->prefix, '', $tableName);
        $srcTableName = DatabaseTmp::TMP_PREFIX . $tableNameWithoutPrefix;

 
        if ($strings->startsWith($tableName, $this->options->prefix) === false) {
            return true;
        }

 
        $this->setJob($srcTableName);

 
        if (!$this->startJob($srcTableName)) {
            return true;
        }

        $this->startReplace($srcTableName);

        return $this->finishStep();
    }





    private function startReplace($table)
    {
        $rows = $this->options->job->start + $this->settings->querySRLimit;
        $this->log(
            "DB Search & Replace:  Table $table {$this->options->job->start} to $rows records"
        );

 
        if (defined('WPSTG_DISABLE_SEARCH_REPLACE_GENERATOR') && WPSTG_DISABLE_SEARCH_REPLACE_GENERATOR) {
            $this->options->job->start += $this->settings->querySRLimit;
        }

        $this->searchReplace($table, []);

    }








    protected function getColumns($table)
    {
        $primaryKeys = [];
        $columns = [];
        $fields = $this->db->get_results('DESCRIBE ' . $table);

        if (empty($fields)) {
 
            return false;
        }

        if (is_array($fields)) {
            foreach ($fields as $column) {
                $columns[] = $column->Field;
                if ($column->Key === 'PRI') {
                    $primaryKeys[] = $column->Field;
                }
            }
        }

        return [$primaryKeys, $columns];
    }






    private function get_url_without_scheme($str)
    {
        return preg_replace('#^https?://#', '', rtrim($str, '/'));
    }







    private function searchReplace($table, $args)
    {
        $table = esc_sql($table);

 
        $args['search_for'] = [
            '\/\/' . str_replace('/', '\/', $this->get_url_without_scheme($this->options->url)), 
            '//' . $this->get_url_without_scheme($this->options->url), 
            rtrim($this->options->path, DIRECTORY_SEPARATOR),
            str_replace('/', '%2F', $this->get_url_without_scheme($this->options->url)),
        ];

        $args['replace_with'] = [
            '\/\/' . str_replace('/', '\/', $this->getDestinationHost()), 
            '//' . $this->getDestinationHost(), 
            rtrim(ABSPATH, '/'),
            $this->urls->getHomeUrlWithoutScheme(),
        ];

        $args['replace_guids'] = 'off';
        $args['dry_run'] = 'off';
        $args['case_insensitive'] = false;
        $args['skip_transients'] = 'off';

        if ($this->isMultisiteAndPro()) {
            $args['replace_mails'] = 'off';
 
            if (!empty($this->options->existingClones[$this->options->current]["version"]) && version_compare($this->options->existingClones[$this->options->current]["version"], '2.8.2', '>=')) {
 
                $args['search_for'] = [
                    '\/\/' . str_replace('/', '\/', $this->get_url_without_scheme($this->options->url)),
                    '//' . $this->get_url_without_scheme($this->options->url),
                    rtrim($this->options->path, DIRECTORY_SEPARATOR),
                    $this->homeHost . '%2F' . $this->options->directoryName,
                ];
                $args['replace_with'] = [
                    '\/\/' . str_replace('/', '\/', $this->homeUrl),
                    '//' . $this->homeUrl,
                    rtrim(ABSPATH, '/'),
                    $this->homeUrl,
                ];
            } else {
 
 
                $args['search_for'] = [
                    '\/\/' . str_replace('/', '\/', $this->get_url_without_scheme($this->options->url)),
                    '//' . $this->get_url_without_scheme($this->options->url),
                    rtrim($this->options->path, DIRECTORY_SEPARATOR),
                    $this->getImagePathStaging(),
                    $this->homeHost . '%2F' . $this->options->directoryName,
                ];
                $args['replace_with'] = [
                    '\/\/' . str_replace('/', '\/', $this->homeUrl),
                    '//' . $this->homeUrl,
                    rtrim(ABSPATH, '/'),
                    $this->getImagePathLive(),
                    $this->homeUrl,
                ];
            }
        }

 
        $args = Hooks::applyFilters(self::FILTER_PUSH_SEARCHREPLACE_PARAMS, $args);

        $this->log("DB Search & Replace: Table $table");

 
        $primaryKeyAndColumns = $this->getColumns($table);

        if (false === $primaryKeyAndColumns) {
 
            ++$this->options->job->failedAttempts;
            return false;
        }

        list($primaryKeys, $columns) = $primaryKeyAndColumns;

        $current_row = 0;
        $start = $this->options->job->start;

 
        $end = $this->settings->querySRLimit;

 
        if (defined('WPSTG_DISABLE_SEARCH_REPLACE_GENERATOR') && WPSTG_DISABLE_SEARCH_REPLACE_GENERATOR) {
            $data = $this->db->get_results("SELECT * FROM $table LIMIT $start, $end", ARRAY_A);
        } else {
            $this->lastFetchedPrimaryKeyValue = is_object($this->options->job) && property_exists($this->options->job, 'lastProcessedId') ? $this->options->job->lastProcessedId : false;
            $this->rowsBatchSize = is_object($this->options->job) && property_exists($this->options->job, 'rowsBatchSize') ? (int)$this->options->job->rowsBatchSize : 0;
            $data = $this->rowsGenerator($table, $start, $end, $this->db);
        }

 
        $filter = [
            'Admin_custome_login_Slidshow',
            'Admin_custome_login_Social',
            'Admin_custome_login_logo',
            'Admin_custome_login_text',
            'Admin_custome_login_login',
            'Admin_custome_login_top',
            'Admin_custome_login_dashboard',
            'Admin_custome_login_Version',
        ];

        $filter[] = FinishBackupTask::OPTION_LAST_BACKUP;

        if (!$this->isMultisiteAndPro()) {
            $filter = array_merge($filter, [
                'upload_path',
                'wpstg_existing_clones_beta',
                'wpstg_existing_clones',
                Sites::STAGING_SITES_OPTION,
                'wpstg_settings',
                'wpstg_license_status',
                'siteurl',
                'home',
            ]);
        }

        $filter = apply_filters(JobsSearchReplace::FILTER_CLONE_SEARCH_REPLACE_EXCLUDED_ROWS, $filter);

        $searchReplace = new \WPStaging\Framework\Database\SearchReplace($args['search_for'], $args['replace_with'], $args['case_insensitive'], $filter);
        if (!empty($this->options->subsiteUrlMappings) && is_array($this->options->subsiteUrlMappings)) {
            $searchReplace = new SubsiteUrlSearchReplace(
                $searchReplace,
                $this->options->subsiteUrlMappings,
                true,
                $filter,
                $args['search_for'],
                $args['replace_with']
            );
        }

        if (!empty($this->options->customSearchReplaceRules) && is_array($this->options->customSearchReplaceRules)) {
            $searchReplace = new CustomRulesSearchReplace($searchReplace, $this->options->customSearchReplaceRules);
        }

        if (is_object($this->options) && property_exists($this->options, 'wpBakeryActive')) {
            $searchReplace->setWpBakeryActive($this->options->wpBakeryActive);
        }

        $processed = 0;

 
        foreach ($data as $row) {
            $processed++;
            $current_row++;
            $update_sql = [];
            $where_sql = [];
            $upd = false;

            if ($this->lastFetchedPrimaryKeyValue !== false) {
                $this->lastFetchedPrimaryKeyValue = $row[$this->numericPrimaryKey];
            }

 
            if (isset($row['option_name']) && in_array($row['option_name'], $filter)) {
                continue;
            }

 
            if (
                isset($row['option_name']) && $args['skip_transients'] === 'on' && strpos($row['option_name'], '_transient')
                !== false
            ) {
                continue;
            }

 
            if (isset($row['option_value']) && strlen($row['option_value']) >= 5000000) {
                continue;
            }

 
            foreach ($columns as $column) {
                $dataRow = isset($row[$column]) ? $row[$column] : '';

 
                $size = strlen((string)$dataRow);
                if ($size >= 5000000) {
                    continue;
                }

 
                if (in_array($column, $primaryKeys)) {
                    $where_sql[] = $column . ' = "' . $this->mysql_escape_mimic($dataRow) . '"';
                    continue;
                }

 
                if ($args['replace_guids'] !== 'on' && $column === 'guid') {
                    continue;
                }

 
                if ($this->isMultisiteAndPro() && $args['replace_mails'] === 'off' && strpos($dataRow, '@' . $this->homeHost) !== false) {
                    continue;
                }

                $dataRow = $searchReplace->replaceExtended($dataRow);

 
                if ($row[$column] != $dataRow) {
                    $update_sql[] = $column . ' = "' . $this->mysql_escape_mimic($dataRow) . '"';
                    $upd = true;
                }
            }

 
            if ($args['dry_run'] === 'on') {
 
            } elseif ($upd && !empty($where_sql)) {
 
                $sql = 'UPDATE ' . $table . ' SET ' . implode(', ', $update_sql) . ' WHERE ' . implode(' AND ', array_filter($where_sql));
                $result = $this->db->query($sql);

                if (!$result) {
                    $this->log("Error updating row $current_row", Logger::TYPE_ERROR);
                }
            }
        } 

        unset($row, $update_sql, $where_sql, $sql, $current_row);

        if (
            !defined('WPSTG_DISABLE_SEARCH_REPLACE_GENERATOR') ||
            (defined('WPSTG_DISABLE_SEARCH_REPLACE_GENERATOR') && !WPSTG_DISABLE_SEARCH_REPLACE_GENERATOR)
        ) {
            $this->updateJobStart($processed, $this->db, $table);
        }

 
        $this->db->flush();
        return true;
    }


















    private function recursive_unserialize_replace($from = '', $to = '', $data = '', $serialized = false, $case_insensitive = false)
    {
        try {
            $rejected      = false;
            $failedToParse = false;
            $unserialized  = $this->safeMaybeUnserialize($data, [stdClass::class], $rejected, $failedToParse);

            if ($rejected && !$failedToParse) {
                $this->log('DB Search & Replace: Skipped a serialized value holding a class outside the allow-list, or nested too deep to scan.', Logger::TYPE_WARNING);
                return $serialized ? serialize($data) : $data;
            }

            if (is_serialized($data) && $unserialized !== false) {
                $data = $this->recursive_unserialize_replace($from, $to, $unserialized, true, $case_insensitive);
            } elseif (is_array($data)) {
                $tmp = [];
                foreach ($data as $key => $value) {
                    $tmp[$key] = $this->recursive_unserialize_replace($from, $to, $value, false, $case_insensitive);
                }

                $data = $tmp;
                unset($tmp);
            } elseif (is_object($data)) {
                $props = get_object_vars($data);

 
                if (empty($props['__PHP_Incomplete_Class_Name'])) {
                    $tmp = $data;
                    foreach ($props as $key => $value) {
                        if ($key === '' || (isset($key[0]) && ord($key[0]) === 0)) {
                            continue;
                        }

                        $tmp->$key = $this->recursive_unserialize_replace($from, $to, $value, false, $case_insensitive);
                    }

                    $data = $tmp;
                    $tmp = '';
                    $props = '';
                    unset($tmp);
                    unset($props);
                }
            } else {
                if (is_string($data)) {
                    if (!empty($from) && !empty($to)) {
                        $data = $this->str_replace($from, $to, $data, $case_insensitive);
                    }
                }
            }

            if ($serialized) {
                return serialize($data);
            }
        } catch (Exception $error) {
        }

        return $data;
    }








    private function mysql_escape_mimic($input)
    {
        if (is_array($input)) {
            return array_map(__METHOD__, $input);
        }

        if (!empty($input) && is_string($input)) {
            return str_replace(['\\', "\0", "\n", "\r", "'", '"', "\x1a"], ['\\\\', '\\0', '\\n', '\\r', "\\'", '\\"', '\\Z'], $input);
        }

        return $input;
    }











    private function str_replace($from, $to, $data, $case_insensitive = false)
    {
        if ($case_insensitive === 'on') {
            $data = str_ireplace($from, $to, $data);
        } else {
            $data = str_replace($from, $to, $data);
        }

        return $data;
    }





    private function setJob($table)
    {
        if (!empty($this->options->job->current)) {
            return;
        }

 
        if (!is_object($this->options->job)) {
            $this->options->job = new stdClass();
        }

        $this->options->job->current = $table;
        $this->options->job->start = 0;
    }







    private function startJob($srcTableName)
    {
        if ($this->isExcludedTable($srcTableName)) {
            return false;
        }

        if (!isset($this->options->job->failedAttempts)) {
            $this->options->job->failedAttempts = 0;
        }

        if ($this->options->job->start != 0) {
 
            return !($this->options->job->failedAttempts > $this->maxFailedAttempts);
        }

        $this->options->job->total = (int)$this->db->get_var("SELECT COUNT(1) FROM $srcTableName");
        $this->options->job->failedAttempts = 0;

        if ($this->options->job->total == 0) {
            $this->finishStep();
            return false;
        }

        return true;
    }






    private function isExcludedTable($srcTableName)
    {
        $tables = $this->excludedTableService->getExcludedTablesForSearchReplacePushOnly();

        $excludedTables = [];
        foreach ($tables as $key => $value) {
            $excludedTables[] = DatabaseTmp::TMP_PREFIX . ltrim($value, '_');
        }

        if (in_array($srcTableName, $excludedTables)) {
            $this->log("DB Search & Replace: Table excluded by WP STAGING: $srcTableName");
            return true;
        }

        return false;
    }




    protected function finishStep()
    {
 
        if (!$this->noResultRows && ($this->options->job->total > $this->options->job->start)) {
            return false;
        }

 
        $this->options->clonedTables[] = $this->options->tables[$this->options->currentStep];

 
        $this->options->job = new \stdClass();

        return true;
    }






    private function isSubDir()
    {
 
 
        $siteurl = preg_replace('#^https?://#', '', rtrim(get_option('siteurl'), '/'));
        $home = preg_replace('#^https?://#', '', rtrim(get_option('home'), '/'));

        return $home !== $siteurl;
    }





    private function getSubDir()
    {
        $home = get_option('home');
        $siteurl = get_option('siteurl');

        if (empty($home) || empty($siteurl)) {
            return '';
        }

        return str_replace([$home, '/'], '', $siteurl);
    }












    protected function updateJobStart($processed, \wpdb $db, $table)
    {
        $this->processed = absint($processed);
        $this->options->job->rowsBatchSize = $this->rowsBatchSize;

 
 
        if ($this->executeNumericPrimaryKeyQuery && $this->lastFetchedPrimaryKeyValue !== false) {
            $this->options->job->lastProcessedId = $this->lastFetchedPrimaryKeyValue;
            $this->options->job->start += $this->processed;
            return;
        }

 
        $minimumProcessed = 1;






        if ($this->processed === 0) {
            $this->logDebug('SEARCH_REPLACE: Processed is zero');

            $totalRowsInTable = $db->get_var("SELECT COUNT(*) FROM $table");

            if (is_numeric($totalRowsInTable)) {
                $this->logDebug("SEARCH_REPLACE: Rows count is numeric: $totalRowsInTable");
 
                $minimumProcessed = min(max((int)$totalRowsInTable / 100, 1), $this->settings->querySRLimit);
            } else {
                $this->logDebug(sprintf("SEARCH_REPLACE: Rows count is not numeric. Type: %s. Json encoded value: %s", gettype($totalRowsInTable), wp_json_encode($totalRowsInTable)));
 
                $minimumProcessed = $this->settings->querySRLimit;
            }

            $this->logDebug("SEARCH_REPLACE: Minimum processed is: $minimumProcessed");
        }

        $this->options->job->start += max($processed, $minimumProcessed);
    }







    public function getProcessed()
    {
        return $this->processed;
    }





    private function getImagePathLive()
    {
 
        $uploads = wp_upload_dir();
        $basedir = $uploads['basedir'];
        $blogId = get_current_blog_id();

        if (strpos($basedir, 'blogs.dir') === false) {
 
            $path = $blogId > 1 ? "wp-content/uploads/sites/$blogId/" : 'wp-content/uploads/';
        } else {
 
            $path = $blogId > 1 ? "wp-content/blogs.dir/$blogId/files/" : 'wp-content/uploads/';
        }

        return $path;
    }





    private function getImagePathStaging()
    {
        return 'wp-content' . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR;
    }

    protected function logDebug($message)
    {
        \WPStaging\functions\debug_log($message);
    }
}
