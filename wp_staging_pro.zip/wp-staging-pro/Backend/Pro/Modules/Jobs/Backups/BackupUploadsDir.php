<?php

namespace WPStaging\Backend\Pro\Modules\Jobs\Backups;

use WPStaging\Framework\Filesystem\FilesystemExceptions;
use WPStaging\Framework\Utils\WpDefaultDirectories;
use WPStaging\Framework\Filesystem\Filesystem;
use WPStaging\Backend\Modules\Jobs\Job;
use WPStaging\Core\Utils\Logger;
use WPStaging\Core\WPStaging;













class BackupUploadsDir
{



    const BACKUP_DELETE_CRON_HOOK_NAME = 'wpstg.cron.delete.uploads_backup';




    const TIME_TO_DELETE_BACKUP_AFTER = 604800; 




    const BACKUP_UPLOADS_DIR_POSTFIX = ".wpstg_backup";




    const KEEP_FOR_NEXT_PUSH_FILE = '.wpstg-keep-for-next-push';




    private $logs = [];




    private $job;




    public function __construct($job)
    {
        $this->job = $job;
    }





    public function getLogs()
    {
        return $this->logs;
    }












    public function backupWpUploadsDir($directory = ABSPATH)
    {
        $options = $this->job->getOptions();

        if ($options->statusBackupUploadsDir === 'finished' || $options->statusBackupUploadsDir === 'skipped') {
            return true;
        }

        $isBackupKeptByStoppedPush = $options->statusBackupUploadsDir === 'pending' && $this->removeKeepMarker();

        if (!$options->deleteUploadsFolder || !$options->backupUploadsFolder) {
            $options->statusBackupUploadsDir = 'skipped';
            $this->job->saveOptions($options);
            return true;
        }

        if ($isBackupKeptByStoppedPush) {
            $options->statusBackupUploadsDir = 'finished';
            $this->job->saveOptions($options);
            $this->logs[] = [
                "msg"  => __("Files: Keeping the uploads backup of the stopped push", "wp-staging"),
                "type" => Logger::TYPE_INFO,
            ];

            return true;
        }

        if (!is_dir($directory)) {
            $this->logs[] = [
                "msg"  => sprintf(__("Files: Error - No such directory exists: %s. Backup Uploads Dir", "wp-staging"), $directory),
                "type" => Logger::TYPE_ERROR,
            ];
            return false;
        }

        $directory = trailingslashit($directory);
 
        $relUploadPath = (new WpDefaultDirectories())->getRelativeUploadPath();
 
        $uploadPath = trailingslashit($directory . $relUploadPath);
 
        $backupUploadPath = trailingslashit(rtrim($uploadPath, '/') . self::BACKUP_UPLOADS_DIR_POSTFIX);

        if (!is_dir($uploadPath)) {
            $this->logs[] = [
                "msg"  => sprintf(__("Files: Error - No such directory exists: %s. Backup Uploads Dir", "wp-staging"), $uploadPath),
                "type" => Logger::TYPE_ERROR,
            ];
            return false;
        }

        $fs = new Filesystem();
        $wpstgContentDir = WPStaging::getContentDir();
        $wpstgContentDir = $fs->normalizePath($wpstgContentDir);

        $relWpstgContentDir = str_replace($fs->normalizePath(ABSPATH), '', $wpstgContentDir);
 
        if ($directory !== ABSPATH) {
            $wpstgContentDir = trailingslashit($directory . trim($relWpstgContentDir, '/'));
        }

        if (!is_dir($wpstgContentDir)) {
            $this->logs[] = [
                "msg"  => sprintf(__("Files: Error - No such directory exists: %s. Backup Uploads Dir", "wp-staging"), $wpstgContentDir),
                "type" => Logger::TYPE_ERROR,
            ];
            return false;
        }

        if ($options->statusBackupUploadsDir === 'pending') {
            $options->statusBackupUploadsDir = 'cleaning';
            $this->job->saveOptions($options);
            $this->logs[] = [
                "msg"  => __("Files: Removing Old Uploads Dir Backup", "wp-staging"),
                "type" => Logger::TYPE_INFO,
            ];
        }

        if ($options->statusBackupUploadsDir === 'cleaning') {
            if (!$this->removeBackup($backupUploadPath)) {
                return false;
            }

            $options->statusBackupUploadsDir = 'copying';
            $this->job->saveOptions($options);
            $this->logs[] = [
                "msg"  => __("Files: Backing Up WP Staging Content Dir", "wp-staging"),
                "type" => Logger::TYPE_INFO,
            ];
            if ($this->job->isOverThreshold()) {
                return false;
            }
        }

 
        if ($options->statusBackupUploadsDir === 'copying') {
            if (!$this->copyWpstgContentDir($wpstgContentDir, $backupUploadPath . 'wp-staging')) {
                return false;
            }

            $options->statusBackupUploadsDir = 'moving';
            $this->job->saveOptions($options);
            $this->logs[] = [
                "msg"  => __("Files: Moving Uploads Dir for Backup", "wp-staging"),
                "type" => Logger::TYPE_INFO,
            ];
            if ($this->job->isOverThreshold()) {
                return false;
            }
        }

 
        if ($options->statusBackupUploadsDir === 'moving') {
            if (
                !$this->moveToBackup(rtrim($uploadPath, '/'), rtrim($backupUploadPath, '/'), [
                    '/' . untrailingslashit($relWpstgContentDir)
                ], $directory)
            ) {
                return false;
            }

            $options->statusBackupUploadsDir = 'finished';
            $this->job->saveOptions($options);
            $this->logs[] = [
                "msg"  => __("Files: Finished Backing Up and Cleaning Uploads Dir", "wp-staging"),
                "type" => Logger::TYPE_INFO,
            ];

            return true;
        }

        return false;
    }







    private function removeBackup($backupDir)
    {
        if (is_dir($backupDir)) {
            $fs = (new Filesystem())
                ->setShouldStop([$this->job, 'isOverThreshold'])
                ->setRecursive();
            try {
                if (!$fs->delete($backupDir)) {
                    return false;
                }
            } catch (\RuntimeException $ex) {
                $this->logs[] = [
                    "msg"  => sprintf(__("Files: Error - %s. Backing Uploads Dir", "wp-staging"), $ex->getMessage()),
                    "type" => Logger::TYPE_ERROR,
                ];
                return false;
            }
        }

        return true;
    }









    private function moveToBackup($uploadsDir, $backupDir, $excludeDirs = [], $wpRootPath = ABSPATH)
    {
        if (is_dir($uploadsDir)) {
            $fs = (new Filesystem())
                ->setRecursive()
                ->setShouldStop([$this->job, 'isOverThreshold'])
                ->setWpRootPath($wpRootPath)
                ->setExcludePaths($excludeDirs);
            try {
                if (!$fs->move($uploadsDir, $backupDir)) {
                    return false;
                }
            } catch (\RuntimeException $ex) {
                $this->logs[] = [
                    "msg"  => sprintf(__("Files: Error - %s. Backing Uploads Dir", "wp-staging"), $ex->getMessage()),
                    "type" => Logger::TYPE_ERROR,
                ];
            }
        }

        return true;
    }







    private function copyWpstgContentDir($wpstgContentDir, $backupDir)
    {
        $fs = (new Filesystem())
            ->setRecursive()
            ->setShouldStop([$this->job, 'isOverThreshold']);
        try {
            if (!$fs->copy(rtrim($wpstgContentDir, '/'), $backupDir)) {
                return false;
            }
        } catch (\RuntimeException $ex) {
            $this->logs[] = [
                "msg"  => sprintf(__("Files: Error - %s. Backing Uploads Dir", "wp-staging"), $ex->getMessage()),
                "type" => Logger::TYPE_ERROR,
            ];
            return false;
        }

        return true;
    }





    public function scheduleDeleteOfTheBackup()
    {
        $options = $this->job->getOptions();

 
        if ($options->statusBackupUploadsDir !== 'finished') {
            return;
        }

 
        wp_clear_scheduled_hook(self::BACKUP_DELETE_CRON_HOOK_NAME);

        wp_schedule_single_event(time() + self::TIME_TO_DELETE_BACKUP_AFTER, self::BACKUP_DELETE_CRON_HOOK_NAME);

        $this->logs[] = [
            "msg"  => __("Finish: Scheduled uploads backup at wp-content/uploads.wpstg_backup to be deleted after 7 days.", "wp-staging"),
            "type" => Logger::TYPE_INFO,
        ];
    }





    public function keepBackupForNextPush()
    {
        $backupUploadsPath = $this->getBackupUploadsPath();
        if (!is_dir($backupUploadsPath) || file_put_contents($backupUploadsPath . self::KEEP_FOR_NEXT_PUSH_FILE, '') === false) {
            return '';
        }

        wp_clear_scheduled_hook(self::BACKUP_DELETE_CRON_HOOK_NAME);
        return $backupUploadsPath;
    }





    public function removeKeepMarker()
    {
        $keepMarker = $this->getBackupUploadsPath() . self::KEEP_FOR_NEXT_PUSH_FILE;
        if (!is_file($keepMarker)) {
            return false;
        }

        wp_delete_file($keepMarker);
        return true;
    }





    public function removeUploadsBackup()
    {
        $backupUploadsPath = $this->getBackupUploadsPath();
        if (!is_dir($backupUploadsPath)) {
            return;
        }

        (new Filesystem())->setRecursive()->delete($backupUploadsPath);
    }




    private function getBackupUploadsPath()
    {
        return trailingslashit(rtrim((new WpDefaultDirectories())->getUploadsPath(), '/') . self::BACKUP_UPLOADS_DIR_POSTFIX);
    }
}
