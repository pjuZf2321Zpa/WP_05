<?php

namespace WPStaging\Backend\Pro\Modules\Jobs;

use WPStaging\Backend\Modules\Jobs\Cloning;
use WPStaging\Backend\Modules\Jobs\Data as CloningData;
use WPStaging\Core\WPStaging;
use WPStaging\Framework\Adapter\Database\DatabaseException;
use WPStaging\Framework\Database\DbInfo;
use WPStaging\Framework\Facades\Hooks;
use WPStaging\Framework\Utils\Sanitize;
use WPStaging\Pro\Multisite\Service\SubsiteUrlMapping;
use WPStaging\Pro\WPStagingPro;




class CloningPro extends Cloning
{
 
    const FILTER_CLONING_EMAIL_ALLOWED = 'wpstg_cloning_email_allowed';





    protected $sanitize;




    public function getDataJob(): CloningData
    {
        return new CloningProData();
    }




    protected function setAdvancedCloningOptions()
    {
        $this->options->useNewAdminAccount = isset($_POST["useNewAdminAccount"]) && $this->sanitize->sanitizeBool($_POST["useNewAdminAccount"]);

        if (!empty($_POST["adminEmail"])) {
            $this->options->adminEmail = $this->sanitize->sanitizeEmail($_POST["adminEmail"]);
        }

        if (!empty($_POST["adminPassword"])) {
            $this->options->adminPassword = $this->sanitize->sanitizePassword($_POST["adminPassword"]);
            $this->options->adminPassword = wp_hash_password($this->options->adminPassword);
        }

        $this->options->useCustomDatabase = isset($_POST["useCustomDatabase"]) && $this->sanitize->sanitizeBool($_POST["useCustomDatabase"]);
        if ($this->options->useCustomDatabase) {
            if (!empty($_POST["databaseServer"])) {
                $this->options->databaseServer = $this->sanitize->sanitizeString($_POST["databaseServer"]);
            }

            if (!empty($_POST["databaseUser"])) {
                $this->options->databaseUser = $this->sanitize->sanitizeString($_POST["databaseUser"]);
            }

            if (!empty($_POST["databasePassword"])) {
                $this->options->databasePassword = $this->sanitize->sanitizePassword($_POST["databasePassword"]);
            }

            if (!empty($_POST["databaseDatabase"])) {
                $this->options->databaseDatabase = $this->sanitize->sanitizeString($_POST["databaseDatabase"]);
            }

            if (!empty($_POST["databasePrefix"])) {
                $this->options->databasePrefix = $this->strUtil->maybeAppendUnderscore($this->sanitize->sanitizeString($_POST["databasePrefix"]));
            }

            if (isset($_POST["databaseSsl"]) && 'true' === $this->sanitize->sanitizeString($_POST["databaseSsl"])) {
                $this->options->databaseSsl = true;
            }
        } else {
            $this->options->databaseServer   = 'localhost';
            $this->options->databaseUser     = '';
            $this->options->databasePassword = '';
            $this->options->databaseDatabase = '';
            $this->options->databasePrefix   = '';
            $this->options->databaseSsl      = false;
        }

        if (!empty($_POST["cloneDir"])) {
            $this->options->cloneDir = trailingslashit(wpstg_urldecode($this->sanitize->sanitizePath($_POST["cloneDir"])));
        }

        if (!empty($_POST["cloneHostname"])) {
            $this->options->cloneHostname = $this->sanitize->sanitizeString($_POST["cloneHostname"]);
        }

        $this->options->isEmailsAllowed = Hooks::applyFilters(
            self::FILTER_CLONING_EMAIL_ALLOWED,
            isset($_POST['isEmailsAllowed']) && $this->sanitize->sanitizeBool($_POST['isEmailsAllowed'])
        );

        $this->options->isCronEnabled           = empty($_POST['isCronEnabled']) ? false : $this->sanitize->sanitizeBool($_POST['isCronEnabled']);
        $this->options->isWooSchedulerEnabled   = empty($_POST['isWooSchedulerEnabled']) ? false : $this->sanitize->sanitizeBool($_POST['isWooSchedulerEnabled']);
        $this->options->isEmailsReminderEnabled = empty($_POST['isEmailsReminderEnabled']) ? false : $this->sanitize->sanitizeBool($_POST["isEmailsReminderEnabled"]);
        $this->options->isAutoUpdatePlugins     = empty($_POST["isAutoUpdatePlugins"]) ? false : $this->sanitize->sanitizeBool($_POST["isAutoUpdatePlugins"]);
    }




    protected function setDestinationDependentCloningOptions()
    {
        $this->options->subsiteUrlMappings = [];
        if (!empty($this->options->networkClone)) {
            $mainTargetUrl = $this->getDestinationUrl();
            $postedMappings = isset($_POST['subsiteUrlMappings']) && is_array($_POST['subsiteUrlMappings'])
                ? $this->sanitize->sanitizeArrayString($_POST['subsiteUrlMappings'])
                : [];

 
            $subsiteUrlMapping = WPStaging::make(SubsiteUrlMapping::class);
            $this->options->subsiteUrlMappings = $subsiteUrlMapping->sanitizeMappings(
                $postedMappings,
                $subsiteUrlMapping->getClonePreview($mainTargetUrl),
                $mainTargetUrl
            );
        }
    }






    protected function getStagingPrefixInUseMessage(): string
    {
        if (!$this->isExternalDatabase()) {
            return '';
        }

        $stagingPrefix = $this->getDestinationDatabasePrefix();
        try {
            $stagingDb = (new DbInfo(
                $this->options->databaseServer,
                $this->options->databaseUser,
                str_replace("\\\\", "\\", $this->options->databasePassword),
                $this->options->databaseDatabase,
                $this->options->databaseSsl
            ))->connect();
        } catch (DatabaseException $e) {
            return $e->getMessage();
        }

        $existingTable = $stagingDb->get_var($stagingDb->prepare('SHOW TABLES LIKE %s', $stagingDb->esc_like($stagingPrefix) . '%'));
        if ($stagingDb->last_error !== '') {
            return esc_html($stagingDb->last_error);
        }

        if ($existingTable === null) {
            return '';
        }

        return sprintf(
            __("Can not proceed. Tables beginning with the prefix '%s' already exist in the database i.e. %s. Choose another table prefix and try again.", 'wp-staging'),
            esc_html($stagingPrefix),
            esc_html($existingTable)
        );
    }




    protected function getDefaultDestinationNotWritableMessage(): string
    {
        if (!WPStagingPro::isValidLicense()) {
            return parent::getDefaultDestinationNotWritableMessage();
        }

        return __('The staging site cannot be created because neither the WordPress root folder nor the wp-content folder is writable. Make one of them writable, or customize the path in staging settings.', 'wp-staging');
    }
}
