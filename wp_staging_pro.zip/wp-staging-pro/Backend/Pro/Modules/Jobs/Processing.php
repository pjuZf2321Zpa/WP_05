<?php

namespace WPStaging\Backend\Pro\Modules\Jobs;

use RuntimeException;
use WPStaging\Backend\Modules\Jobs\Job;
use WPStaging\Backup\Ajax\Backup\PrepareBackup;
use WPStaging\Backup\BackupDeleter;
use WPStaging\Framework\Job\Dto\TaskResponseDto;
use WPStaging\Core\Utils\Logger;
use WPStaging\Core\WPStaging;
use WPStaging\Framework\Adapter\Directory;
use WPStaging\Framework\Analytics\Actions\AnalyticsStagingPush;
use WPStaging\Framework\Database\SelectedTables;
use WPStaging\Framework\Filesystem\Filesystem;
use WPStaging\Framework\Security\AccessToken;
use WPStaging\Staging\Dto\StagingSiteDto;
use WPStaging\Staging\Sites;
use WPStaging\Framework\Utils\Sanitize;
use WPStaging\Framework\Utils\WpDefaultDirectories;
use WPStaging\Framework\Facades\Hooks;
use WPStaging\Framework\Filesystem\Scanning\ScanConst;
use WPStaging\Pro\Backup\Job\Jobs\JobBackup;
use WPStaging\Pro\Database\CustomSearchReplaceRuleSanitizer;
use WPStaging\Pro\Push\Service\WordPressVersionCompatibility;
use WPStaging\Pro\Multisite\Service\SubsiteUrlMapping;
use WPStaging\Pro\Push\PushSecret;
use WPStaging\Pro\Push\Service\StagingPrefixResolver;
use WPStaging\Pro\WPStagingPro;
use WPStaging\Staging\Service\StagingEngine;






class Processing extends Job
{
    use BackupTrait;

 
    const FILTER_PUSH_EXCLUDED_DIRECTORIES = 'wpstg.push_excluded_directories';

 
    const FILTER_PUSH_EXCLUDED_FILES = 'wpstg_push_excluded_files';




    private $filesystem;




    private $sanitize;




    public function initialize()
    {
        $this->sanitize = WPStaging::make(Sanitize::class);
    }




    public function start()
    {
 
        $this->filesystem = WPStaging::make(Filesystem::class);

 
        $isPushStartedByThisRequest = $this->init();
        if (!$isPushStartedByThisRequest && !WPStaging::make(PushSecret::class)->requestCarries($this->options->pushSecret ?? '')) {
            $this->returnException(WPStaging::make(PushSecret::class)->getRefusalMessage());
        }

        try {
            WPStaging::make(StagingPrefixResolver::class)->validate($this->options->prefix ?? null);
        } catch (RuntimeException $exception) {
            $this->returnException($exception->getMessage());
        }

        $methodName = $this->options->currentJob;

        if (!method_exists($this, $methodName)) {
 
            $methodName = 'jobFinish';
            $this->log("Processing: Force method '{$methodName}'");
            $this->cloneOptionCache->delete();
            $this->filesIndexCache->delete();
 
            $this->init();
        }

 
        return $this->{$methodName}();
    }





    private function init()
    {
 
        if (!isset($_POST) || !isset($_POST["clone"]) || !empty($this->options->currentJob) || WPStaging::make(PushSecret::class)->getRequestSecret() === '') {
            return false;
        }

 
        $this->cloneOptionCache->delete();
        $this->filesIndexCache->delete();

 
        $this->options->root           = wp_normalize_path(ABSPATH);
        $this->options->existingClones = WPStaging::make(Sites::class)->tryGettingStagingSites();

 
        $this->options->databaseSsl = false;

        $cloneID = $this->sanitize->sanitizeString($_POST['clone']);

        if (array_key_exists($cloneID, $this->options->existingClones)) {
            $this->options->current          = $cloneID;
            $this->options->databaseUser     = $this->options->existingClones[strtolower($this->options->current)]['databaseUser'];
            $this->options->databasePassword = $this->options->existingClones[strtolower($this->options->current)]['databasePassword'];
            $this->options->databaseDatabase = $this->options->existingClones[strtolower($this->options->current)]['databaseDatabase'];
            $this->options->databaseServer   = $this->options->existingClones[strtolower($this->options->current)]['databaseServer'];
            $this->options->databasePrefix   = $this->options->existingClones[strtolower($this->options->current)]['databasePrefix'];
            $this->options->databaseSsl      = !empty($this->options->existingClones[strtolower($this->options->current)]['databaseSsl']);
            $this->options->url              = $this->options->existingClones[strtolower($this->options->current)]['url'];
            $this->options->path             = $this->filesystem->normalizePath($this->options->existingClones[strtolower($this->options->current)]['path'], true);
            $this->options->uploadsSymlinked = isset($this->options->existingClones[strtolower($this->options->current)]['uploadsSymlinked']) ? $this->options->existingClones[strtolower($this->options->current)]['uploadsSymlinked'] : false;
            $this->options->networkClone     = isset($this->options->existingClones[$this->options->current]['networkClone']) ? (bool)$this->options->existingClones[strtolower($this->options->current)]['networkClone'] : false;
        }

 
        $this->options->clone              = $cloneID;
        $this->options->cloneDirectoryName = preg_replace("#\W+#", '-', strtolower($this->options->clone));
        $this->options->cloneNumber        = $this->options->existingClones[strtolower($this->options->clone)]['number'];
        $this->options->prefix             = $this->getPrefix();
        $this->options->mainJob            = Job::PUSH;
        $this->options->pushSecret         = WPStaging::make(PushSecret::class)->getRequestSecret();
        $this->markLegacyStagingEngine();
        $this->validateWordPressVersionCompatibility();

        $this->options->tablePushSelection = [];
        $this->options->excludedTables     = [];
        $this->options->tables             = [];
        $this->options->clonedTables       = [];

 
        $this->options->totalFiles  = 0;
        $this->options->copiedFiles = 0;
        $this->options->failedFiles = 0;

 
        $this->options->includedDirectories = [];
        $this->options->excludedDirectories = [];
        $this->options->extraDirectories    = [];
        $this->options->directoriesToCopy   = [];
        $this->options->scannedDirectories  = [];

 
 

        if (is_multisite() && !is_main_site() && !$this->isNetworkClone()) {
 
            $this->options->currentJob = 'jobFileScanning';
        } else {
            $this->options->currentJob = 'jobDeleteOldBackups';
        }

        $this->options->currentStep = 0;
        $this->options->totalSteps  = 0;

 
        $this->options->job = new \stdClass();

 
        $includedTables              = isset($_POST['includedTables']) ? $this->sanitize->sanitizeString($_POST['includedTables']) : '';
        $excludedTables              = isset($_POST['excludedTables']) ? $this->sanitize->sanitizeString($_POST['excludedTables']) : '';
        $selectedTablesWithoutPrefix = isset($_POST['selectedTablesWithoutPrefix']) ? $this->sanitize->sanitizeString($_POST['selectedTablesWithoutPrefix']) : '';
        $selectedTables              = new SelectedTables($includedTables, $excludedTables, $selectedTablesWithoutPrefix);
        $selectedTables->setAllTablesExcluded(empty($_POST['allTablesExcluded']) ? false : $this->sanitize->sanitizeBool($_POST['allTablesExcluded']));
        $selectedTables->setDatabaseInfo($this->options->databaseServer, $this->options->databaseUser, $this->options->databasePassword, $this->options->databaseDatabase, $this->options->prefix, $this->options->databaseSsl);
        $tables                            = $selectedTables->getSelectedTables($this->options->networkClone);
        $this->options->tables             = $tables;
        $this->options->tablePushSelection = $tables;

        $this->options->subsiteUrlMappings = [];
        if ($this->options->networkClone) {
            $postedMappings = isset($_POST['subsiteUrlMappings']) && is_array($_POST['subsiteUrlMappings'])
                ? $this->sanitize->sanitizeArrayString($_POST['subsiteUrlMappings'])
                : [];
            $stagingSite = WPStaging::make(Sites::class)->getStagingSiteDtoByCloneId($cloneID);

 
            $subsiteUrlMapping = WPStaging::make(SubsiteUrlMapping::class);
            $this->options->subsiteUrlMappings = $subsiteUrlMapping->sanitizePushMappings(
                $postedMappings,
                $subsiteUrlMapping->getPushPreview($stagingSite),
                $stagingSite,
                [home_url(), site_url()]
            );
        }

 
        if (isset($_POST["excludedDirectories"]) && is_array($_POST["excludedDirectories"])) {
            $this->options->excludedDirectories = $this->sanitize->sanitizeArrayString($_POST["excludedDirectories"]);
        }

 
        if (isset($_POST["includedDirectories"]) && is_array($_POST["includedDirectories"])) {
            $this->options->includedDirectories = $this->sanitize->sanitizeArrayString($_POST["includedDirectories"]);
        }

 
        if (isset($_POST["extraDirectories"]) && !empty($_POST["extraDirectories"])) {
            if (is_array($_POST["extraDirectories"])) {
                $this->options->extraDirectories = $this->sanitize->sanitizeArrayString($_POST["extraDirectories"]);
            } else {
                $this->options->extraDirectories = explode(
                    ScanConst::DIRECTORIES_SEPARATOR,
                    $this->sanitize->sanitizeString($_POST["extraDirectories"])
                );
            }
        }

        $stagingUploadsFolder = $this->options->path . WPStaging::make(WpDefaultDirectories::class)->getRelativeUploadPath();
        $excludedDirectories  = $this->getDirectoriesNeverCopiedByPush($stagingUploadsFolder);

 
        $this->options->deleteUploadsFolder = !$this->options->uploadsSymlinked && isset($_POST['deleteUploadsBeforePushing']) && $this->sanitize->sanitizeBool($_POST['deleteUploadsBeforePushing']);
 
        $this->options->backupUploadsFolder = $this->options->deleteUploadsFolder && isset($_POST['backupUploadsBeforePushing']) && $this->sanitize->sanitizeBool($_POST['backupUploadsBeforePushing']);
 
        $this->options->deletePluginsAndThemes = isset($_POST['deletePluginsAndThemes']) && $this->sanitize->sanitizeBool($_POST['deletePluginsAndThemes']);
 
        $this->options->statusBackupUploadsDir = 'pending';
        $this->options->statusContentCleaner   = 'pending';
        $this->options->statusCopierCleanup    = 'pending';

        $this->options->excludedDirectories = Hooks::applyFilters(self::FILTER_PUSH_EXCLUDED_DIRECTORIES, $this->options->excludedDirectories);

        $this->options->excludedDirectories = array_merge($excludedDirectories, $this->options->excludedDirectories);

 
        $this->options->excludedFiles = Hooks::applyFilters(self::FILTER_PUSH_EXCLUDED_FILES, [
            '.htaccess',
            '.DS_Store',
            '*.git',
            '*.svn',
            '*.tmp',
            'desktop.ini',
            '.gitignore',
            '*.log',
            'wp-staging-optimizer.php',
            '.wp-staging',
        ]);

 
        $this->options->directoriesToCopy = array_merge(
            $this->options->includedDirectories,
            $this->options->extraDirectories
        );

        $this->options->createBackupBeforePushing = isset($_POST["createBackupBeforePushing"]) && $this->sanitize->sanitizeBool($_POST["createBackupBeforePushing"]);
        $this->options->customSearchReplaceRules  = WPStagingPro::licenseAllowsCustomSearchReplace() && isset($_POST['customSearchReplaceRules']) ? CustomSearchReplaceRuleSanitizer::sanitize(wp_unslash($_POST['customSearchReplaceRules'])) : [];

 
        $this->saveExcludedDirectories();
        $this->saveSelectionsForNextPush();

        if (isset($this->options->jobIdentifier)) {
            WPStaging::make(AnalyticsStagingPush::class)->enqueueStartEvent($this->options->jobIdentifier, $this->options);
        }

        $this->writePushLogHeader();

        return $this->saveOptions();
    }




    private function validateWordPressVersionCompatibility()
    {
 
        $versionCompatibility = WPStaging::make(WordPressVersionCompatibility::class);
        $compatibility        = $versionCompatibility->evaluateForEngine($this->options->path, StagingEngine::ENGINE_LEGACY);

        if (!$compatibility['allowed']) {
            $this->returnException($compatibility['message']);
        }
    }





    private function saveExcludedDirectories()
    {
        if (empty($this->options->existingClones[$this->options->clone])) {
            return false;
        }

        $this->options->existingClones[$this->options->clone]['excludedDirs']        = $this->options->excludedDirectories;
        $this->options->existingClones[$this->options->clone]['excludedDirsVersion'] = StagingSiteDto::EXCLUDED_DIRS_VERSION;

        if (update_option(Sites::STAGING_SITES_OPTION, $this->options->existingClones, false) === false) {
            return false;
        }

        return true;
    }






    private function saveSelectionsForNextPush()
    {
        if (empty($this->options->existingClones[$this->options->clone])) {
            return false;
        }

        $this->options->existingClones[$this->options->clone]['tablePushSelection'] = $this->options->tables;
        if (WPStagingPro::licenseAllowsCustomSearchReplace()) {
            $this->options->existingClones[$this->options->clone]['customSearchReplaceRules'] = $this->options->customSearchReplaceRules;
        }

        return update_option(Sites::STAGING_SITES_OPTION, $this->options->existingClones, false) !== false;
    }





    private function getPrefix()
    {
        try {
            return WPStaging::make(StagingPrefixResolver::class)->resolve($this->options->existingClones[$this->options->clone] ?? []);
        } catch (RuntimeException $exception) {
            $this->returnException($exception->getMessage());
            return '';
        }
    }








    private function handleJobResponse($response, $nextJob)
    {



        if ($response instanceof TaskResponseDto) {
            $this->options->currentStep = $response->getStep();
            $this->options->totalSteps  = $response->getTotal();
            $this->saveOptions();
            $response = json_decode(json_encode($response), false);
 
            $response->status = !$response->isRunning;
        }





        if (is_array($response) && array_key_exists('status', $response)) {
            return $response; // @phpstan-ignore-line
        }

        if (!isset($response->status)) {
            $response->error   = true;
            $response->message = "Response does not have status, therefore we can't detect whether it finished or not.";

            return $response;
        }

 
 
        if ($response->status !== true) {
            return $response;
        }

        $this->options->currentJob  = $nextJob;
        $this->options->currentStep = 0;
        $this->options->totalSteps  = 0;

 
        $this->saveOptions();

        return $response;
    }

    public function jobDeleteOldBackups()
    {
 
        if (!$this->options->createBackupBeforePushing) {
            return $this->jobFileScanning();
        }

 
        if (is_multisite() && !is_main_site()) {
            $this->log(__("Skip creating full site backup, as backup of a subsite is not implemented yet!", "wp-staging"));
            return $this->jobFileScanning();
        }

 
        $backupDeleter = WPStaging::getInstance()->getContainer()->make(BackupDeleter::class);
        $backupDeleter->deleteAllAutomatedPushBackups();

        foreach ($backupDeleter->getErrors() as $error) {
            $this->log($error, Logger::TYPE_ERROR);
        }

        $response = new TaskResponseDto();
        $response->setIsRunning(false);
        $response->addMessage($this->logger->getLastLogMsg());

        return $this->handleJobResponse($response, 'jobPrepareBackup');
    }

    public function jobPrepareBackup()
    {
 
        $prepare  = WPStaging::make(PrepareBackup::class);
        $prepared = $prepare->prepare([
            'isExportingDatabase'            => true,
            'isExportingPlugins'             => true,
            'isExportingMuPlugins'           => true,
            'isExportingThemes'              => true,
            'isExportingUploads'             => true,
            'isExportingOtherWpContentFiles' => true,
            'isExportingOtherWpRootFiles'    => true,
            'isAutomatedBackup'              => true,
            'isBeforePushBackup'             => true,
            'storages'                       => ['localStorage'],
            'name'                           => __('Full Site Backup Before Push', 'wp-staging'),
        ]);

        if (is_wp_error($prepared)) {
            throw new \UnexpectedValueException($prepared->get_error_message(), $prepared->get_error_code());
        }

        $response = new TaskResponseDto();
        $response->setIsRunning(false);

        return $this->handleJobResponse($response, 'jobBackup');
    }





    public function jobBackup()
    {
        $job = WPStaging::getInstance()->getContainer()->make(JobBackup::class);

        if (!$job) {
            throw new RuntimeException('Failed to get Job Site Backup');
        }

        $response = $job->prepareAndExecute();
        if ($response->getJobStatus() === 'JOB_FAIL') {
            return $this->backupFailedResponse($job, $response);
        }

        return $this->handleJobResponse($response, 'jobFileScanning');
    }








    private function backupFailedResponse(JobBackup $job, TaskResponseDto $response): array
    {
        $messages = $response->getMessages();
        $message  = empty($messages) ? __('The backup before the push failed.', 'wp-staging') : $messages[0]['message'];
        $this->log($message, Logger::TYPE_ERROR);
        $job->getTransientCache()->failJob('', $message);

        return [
            'job'     => isset($this->options->currentJob) ? $this->options->currentJob : '',
            'status'  => false,
            'message' => esc_html($message),
            'error'   => true,
        ];
    }






    public function jobFileScanning()
    {
        $directories = new ScanDirectories();

        return $this->handleJobResponse($directories->start(), 'jobCopy');
    }






    public function jobCopy()
    {
        $files = new Files();

        return $this->handleJobResponse($files->start(), 'jobCopyDatabaseTmp');
    }






    public function jobCopyDatabaseTmp()
    {
        $database = new DatabaseTmp();

        return $this->handleJobResponse($database->start(), 'jobSearchReplace');
    }






    public function jobSearchReplace()
    {
        $searchReplace = new SearchReplace();

        return $this->handleJobResponse($searchReplace->start(), 'jobData');
    }






    public function jobData()
    {
        return $this->handleJobResponse((new Data())->start(), 'jobDatabaseRename');
    }






    public function jobDatabaseRename()
    {
        $databaseBackup = new \WPStaging\Backend\Pro\Modules\Jobs\DatabaseTmpRename();

        return $this->handleJobResponse($databaseBackup->start(), 'jobFinish');
    }






    public function jobFinish()
    {
        $finish = new \WPStaging\Backend\Pro\Modules\Jobs\Finish();

 
 
 
        $accessToken = new AccessToken();
        $accessToken->generateNewToken();

        return $this->handleJobResponse($finish->start(), '');
    }




    private function writePushLogHeader()
    {
        $this->log('#################### Start Push Job ####################');
        $this->logger->info(esc_html('Pushing staging site ' . $this->options->clone . '.'));
        $this->logger->info(esc_html('Source: ' . $this->options->path . '.'));
        $this->logger->info(esc_html('Destination: ' . ABSPATH . '.'));
        $this->logger->writeLogHeader();
        $this->logger->writeInstalledPluginsAndThemes();
        $this->addJobSettingsToLogs("Push");
    }








    private function getDirectoriesNeverCopiedByPush(string $stagingUploadsFolder): array
    {
        $stagingUploadsFolder = rtrim($stagingUploadsFolder, '/\\');

        $excludedDirectories = [
            $this->options->path . 'wp-content/plugins/wp-staging-pro',
            $this->options->path . 'wp-content/plugins/wp-staging-pro-1',
            $this->options->path . 'wp-content/plugins/wp-staging',
            $this->options->path . 'wp-content/plugins/wp-staging-1',
            $this->options->path . 'wp-content/uploads/wp-staging',
            $this->options->path . 'wp-content/wp-staging',
            $this->options->path . 'wp-content/wp-staging-sites',
            $this->options->path . 'wp-content/uploads/wp-staging-sites',
            $stagingUploadsFolder . '/' . WPSTG_PLUGIN_DOMAIN,
            $stagingUploadsFolder . '/' . Directory::STAGING_SITE_DIRECTORY,
        ];

        if (is_link($stagingUploadsFolder)) {
            $excludedDirectories[] = $stagingUploadsFolder;
        }

        return $excludedDirectories;
    }
}
