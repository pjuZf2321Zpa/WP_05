<?php

namespace WPStaging\Backend\Pro\Modules\Jobs;

use RuntimeException;
use WPStaging\Backend\Modules\Jobs\JobExecutable;
use WPStaging\Backup\Dto\Task\Restore\RenameDatabaseTaskDto;
use WPStaging\Core\WPStaging;
use WPStaging\Framework\Database\TablesRenamer;
use WPStaging\Framework\Database\TableService;
use WPStaging\Pro\Push\Service\TableScanner;

use function WPStaging\functions\debug_log;




class DatabaseTmpRename extends JobExecutable
{
 
    const TOTAL_STEPS = 5;

 
    const STEP_BEFORE_RENAMING = 0;

 
    const STEP_RENAME_NON_CONFLICTING_TABLES = 1;

 
    const STEP_RENAME_CONFLICTING_TABLES = 2;

 
    const STEP_RENAME_CUSTOM_TABLES = 3;

 
    const STEP_AFTER_RENAMING = 4;




    private $tablesRenamer;

 
    private $productionTablePrefix;





    public function initialize()
    {
        $wpdb                        = WPStaging::make('wpdb');
        $this->productionTablePrefix = $wpdb->prefix;

        $this->checkFatalError();
        $this->tablesRenamer = WPStaging::make(TablesRenamer::class);
    }




    protected function checkFatalError()
    {
        if (DatabaseTmp::TMP_PREFIX === $this->productionTablePrefix) {
            $this->returnException('Fatal Error: Prefix ' . $this->productionTablePrefix . ' is used for the live site and used for the temporary database tables hence we can not replace the production database. Please ask support@wp-staging.com how to resolve this.');
        }
    }





    protected function calculateTotalSteps()
    {
        $this->options->totalSteps = self::TOTAL_STEPS;
    }







    protected function execute(): bool
    {
 
        if ($this->isOverThreshold()) {
            $this->log('DB Rename: Is over threshold. Continuing ...');
 
            $this->prepareResponse(false, false);
            $this->saveOptions();
            return false;
        }

        if ($this->options->currentStep === self::STEP_BEFORE_RENAMING) {
            $this->stepBeforeTablesRenaming();
            $this->prepareResponse(false, true);
            return false;
        }

        if ($this->options->currentStep === self::STEP_RENAME_NON_CONFLICTING_TABLES) {
            $incrementStep = $this->stepRenameNonConflictingTables();
            $this->prepareResponse(false, $incrementStep);
            return false;
        }

        if ($this->options->currentStep === self::STEP_RENAME_CONFLICTING_TABLES) {
            $incrementStep = $this->stepRenameConflictingTables();
            $this->prepareResponse(false, $incrementStep);
            return false;
        }

        if ($this->options->currentStep === self::STEP_RENAME_CUSTOM_TABLES) {
            $incrementStep = $this->stepRenameCustomTables();
            $this->prepareResponse(false, $incrementStep);
            return false;
        }

        if ($this->options->currentStep === self::STEP_AFTER_RENAMING) {
            $this->stepAfterTablesRenaming();
            $this->prepareResponse(false, true);
            return false;
        }

        $this->isFinished();
        $this->prepareResponse(true, false);
        return false;
    }




    protected function setupTableRenamer()
    {
        $this->tablesRenamer->setTmpPrefix(DatabaseTmp::TMP_PREFIX);
        $this->tablesRenamer->setCustomTableTmpPrefix(DatabaseTmp::TMP_PREFIX_CUSTOM_TABLE);
        $this->tablesRenamer->setProductionTablePrefix($this->productionTablePrefix);
        $this->tablesRenamer->setDropPrefix(DatabaseTmp::TMP_PREFIX_TO_DROP);
        $this->tablesRenamer->setShortNamedTablesToRename([]);
        $this->tablesRenamer->setShortNamedTablesToDrop([]);
        $this->tablesRenamer->setRenameViews(false);
 
        $this->tablesRenamer->setRenameCustomTables($this->isExternalDatabase());
        $temporaryTables = WPStaging::make(TableService::class)->findTableNamesStartWith(DatabaseTmp::TMP_PREFIX);
        $excludedTables = TableScanner::getExcludedTables(DatabaseTmp::TMP_PREFIX, $temporaryTables);
        $this->tablesRenamer->setExcludedTables(array_map(function ($table) {
            return substr($table, strlen(DatabaseTmp::TMP_PREFIX));
        }, $excludedTables));
        $this->tablesRenamer->setLogEachRename(true);
        $this->tablesRenamer->setLogger($this->logger);
        $this->tablesRenamer->setThresholdCallable([$this, 'isOverThreshold']);
    }




    protected function stepBeforeTablesRenaming()
    {
        $this->setupTableRenamer();
        $this->options->renameJobData           = $this->tablesRenamer->setupRenamer()->toArray();
        $this->options->totalTablesToRename     = $this->tablesRenamer->getTotalTables();
        $this->options->totalTablesRenamed      = 0;
        $this->options->activePluginsToPreserve = $this->tablesRenamer->getActivePluginsToPreserve();
        $this->options->isNetworkActivePlugin   = is_plugin_active_for_network(WPSTG_PLUGIN_FILE);

        if ($this->options->isNetworkActivePlugin && $this->options->isNetworkClone) {
            $this->options->activeSitewidePluginsToPreserve = $this->tablesRenamer->getActiveSitewidePluginsToPreserve();
        }

        if (!empty($this->options->activePluginsToPreserve)) {
            $this->log('DB Rename: Preserved Active Plugins');
        }
    }

 
    protected function stepRenameNonConflictingTables(): bool
    {
        $taskDto = $this->prepareTablesRenaming();

        try {
            $result = $this->tablesRenamer->cleanTemporaryBackupTables();
        } catch (RuntimeException $exception) {
            $this->returnException($exception->getMessage());
            return false;
        }

        if ($result === false) {
            $this->log(sprintf('DB Rename: Cleaning Temporary Tables failed. Remaining: %s', $this->tablesRenamer->getTablesRemainingToBeDropped()));
            return false;
        }

        $result = $this->tablesRenamer->renameNonConflictingTables();
        $taskDto->nonConflictingTablesRenamed = $this->tablesRenamer->getNonConflictingTablesRenamed();
        $this->log(sprintf('DB Rename: Renamed %d/%d tables', $taskDto->nonConflictingTablesRenamed, $this->options->totalTablesToRename));
        $this->options->renameJobData = $taskDto->toArray();

        return $result;
    }

 
    protected function stepRenameConflictingTables(): bool
    {
        $taskDto = $this->prepareTablesRenaming();
        $result  = $this->tablesRenamer->renameConflictingTables();
        $taskDto->conflictingTablesRenamed = $this->tablesRenamer->getConflictingTablesRenamed();
        $totalTablesRenamed = $taskDto->nonConflictingTablesRenamed + $taskDto->conflictingTablesRenamed;
        $this->log(sprintf('DB Rename: Renamed %d/%d tables', $totalTablesRenamed, $this->options->totalTablesToRename));
        $this->options->renameJobData = $taskDto->toArray();

        return $result;
    }

 
    protected function stepRenameCustomTables(): bool
    {






        if (!$this->isExternalDatabase()) {
            return true;
        }

        $taskDto = $this->prepareTablesRenaming();
        $result  = $this->tablesRenamer->renameCustomTables();
        $taskDto->customTablesRenamed = $this->tablesRenamer->getCustomTablesRenamed();
        $totalTablesRenamed = $taskDto->nonConflictingTablesRenamed + $taskDto->conflictingTablesRenamed + $taskDto->customTablesRenamed;
        $this->log(sprintf('DB Rename: Renamed %d/%d tables', $totalTablesRenamed, $this->options->totalTablesToRename));
        $this->options->renameJobData = $taskDto->toArray();

        return $result;
    }




    protected function stepAfterTablesRenaming()
    {
        $activeWpstgPlugin = plugin_basename(trim(WPSTG_PLUGIN_FILE));
        if (!empty($this->options->activePluginsToPreserve)) {
            $this->tablesRenamer->setProductionTablePrefix($this->productionTablePrefix);
            $this->tablesRenamer->restorePreservedActivePlugins($this->options->activePluginsToPreserve, $activeWpstgPlugin, false);
            $this->log('DB Rename: Restored Preserved Active Plugins');
        }

        if ($this->options->isNetworkActivePlugin && $this->options->isNetworkClone) {
            $this->tablesRenamer->restorePreservedActiveSitewidePlugins($this->options->isNetworkActivePlugin, $activeWpstgPlugin);
            $this->log('DB Rename: Preserved Network Active Plugin Status');
        }

        try {
            $this->flush();
        } catch (\Throwable $e) {
            debug_log('Failed to flush after tables renaming. Error message: ' . $e->getMessage());
        }
    }




    protected function prepareTablesRenaming(): RenameDatabaseTaskDto
    {
        $this->setupTableRenamer();
        $taskData = json_decode(json_encode($this->options->renameJobData), true);
        $taskDto  = new RenameDatabaseTaskDto();
        $taskDto->hydrateProperties($taskData);
        $this->tablesRenamer->setTaskDto($taskDto);

        return $taskDto;
    }







    protected function flush()
    {
        wp_cache_flush();
        global $wp_rewrite;
        $wp_rewrite->init();
        flush_rewrite_rules(true); 
    }





    protected function isFinished(): bool
    {
 
        if ($this->options->currentStep >= $this->options->totalSteps) {
            $this->log('DB Rename: Has been finished successfully. Cleaning up...');
            $this->prepareResponse(true, false);
            return true;
        }

        return false;
    }
}
