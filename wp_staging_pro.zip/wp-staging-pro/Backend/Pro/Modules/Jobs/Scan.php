<?php

namespace WPStaging\Backend\Pro\Modules\Jobs;

use Countable;
use DirectoryIterator;
use Exception;
use RuntimeException;
use wpdb;
use WPStaging\Backend\Modules\Jobs\Job;
use WPStaging\Core\WPStaging;
use WPStaging\Backend\Optimizer\Optimizer;
use WPStaging\Framework\Adapter\Database\DatabaseException;
use WPStaging\Framework\Database\SelectedTables;
use WPStaging\Framework\Facades\Escape;
use WPStaging\Framework\Facades\UI\Checkbox;
use WPStaging\Framework\Filesystem\Filesystem;
use WPStaging\Staging\Sites;
use WPStaging\Framework\Utils\Sanitize;
use WPStaging\Framework\Utils\WpDefaultDirectories;
use WPStaging\Framework\Utils\Strings;
use WPStaging\Framework\Language\Language;
use WPStaging\Framework\Traits\ValueGetterTrait;
use WPStaging\Pro\Push\Service\TableScanner;
use WPStaging\Pro\Push\Service\StagingPrefixResolver;
use WPStaging\Pro\Push\Service\WordPressVersionCompatibility;
use WPStaging\Staging\Service\StagingEngine;






class Scan extends Job
{
    use BackupTrait;
    use ValueGetterTrait;




    private $directories = [];




    private $strUtils;





    private $db;




    private $filesystem;




    private $sanitize;




    private $dirUtils;





    public function initialize()
    {
 
        $this->filesystem = WPStaging::make(Filesystem::class);
        $this->sanitize   = WPStaging::make(Sanitize::class);
        $this->dirUtils   = WPStaging::make(WpDefaultDirectories::class);

        $this->strUtils = WPStaging::make(Strings::class);

        $this->start();

        $this->getDb();

        $this->installOptimizer();

        $this->getStagingTables();

        $this->setTablesToPush();

        $this->buildDirectories();

        $this->buildUploadsDirectories();

        $this->isVersionIdentical();
    }




    protected function getDb()
    {
        $this->options->existingClones = array_change_key_case(get_option(Sites::STAGING_SITES_OPTION, []), CASE_LOWER);

        $cloneID      = isset($_POST["clone"]) ? $this->sanitize->sanitizeString($_POST['clone']) : '';
        $cloneKey     = strtolower($cloneID);
        $currentClone = $this->options->existingClones[$cloneKey] ?? [];
        $useCustomDatabase = $this->externalDatabaseConfiguration->isEnabled($currentClone);

        if ($useCustomDatabase) {
            try {
                $this->externalDatabaseConfiguration->validateConnectionTarget($currentClone);
            } catch (DatabaseException $exception) {
                $this->returnException($exception->getMessage());
            }

            $this->options->current          = $cloneKey;
            $this->options->databaseUser     = $this->getValueFromArray('databaseUser', $currentClone);
            $this->options->databasePassword = $this->getValueFromArray('databasePassword', $currentClone);
            $this->options->databaseDatabase = $this->getValueFromArray('databaseDatabase', $currentClone);
            $this->options->databaseServer   = $this->getValueFromArray('databaseServer', $currentClone);
            $this->options->databasePrefix   = $this->getValueFromArray('databasePrefix', $currentClone);
            $this->options->databaseSsl      = $this->getValueFromArray('databaseSsl', $currentClone, false);

            if ($this->options->databaseSsl && !defined('MYSQL_CLIENT_FLAGS')) {
                // phpcs:disable PHPCompatibility.Constants.NewConstants.mysqli_client_ssl_dont_verify_server_certFound
                define('MYSQL_CLIENT_FLAGS', MYSQLI_CLIENT_SSL | MYSQLI_CLIENT_SSL_DONT_VERIFY_SERVER_CERT);
            }

            $this->db         = new wpdb($this->options->databaseUser, str_replace("\\\\", "\\", $this->options->databasePassword), $this->options->databaseDatabase, $this->options->databaseServer);
            $this->db->prefix = $this->options->prefix;
        } else {
            $this->db = WPStaging::getInstance()->get("wpdb");
        }

        $this->options->wpBakeryActive = $this->isWpBakeryActive();
        $this->saveOptions();
    }






    public function start()
    {
 
        $this->cloneOptionCache->delete();
        $this->filesIndexCache->delete();

 
        $this->options->root           = wp_normalize_path(WPStaging::getWPpath());
        $this->options->existingClones = array_change_key_case(get_option(Sites::STAGING_SITES_OPTION, []), CASE_LOWER);
        $this->options->current        = null;

        $cloneID  = isset($_POST["clone"]) ? $this->sanitize->sanitizeString($_POST['clone']) : '';
        $cloneKey = strtolower($cloneID);

 
        if (array_key_exists($cloneKey, $this->options->existingClones)) {
            $currentClone                      = $this->options->existingClones[$cloneKey];
            $this->options->current            = $cloneKey;
            $this->options->clone              = $cloneKey;
            $this->options->cloneDirectoryName = preg_replace("#\W+#", '-', strtolower($this->options->clone));
            $this->options->cloneNumber        = $currentClone['number'];
            $this->options->directoryName      = $currentClone['directoryName'];
            $this->options->cloneName          = $currentClone['cloneName'];
            $this->options->url                = $currentClone['url'];
            try {
                $this->options->prefix = WPStaging::make(StagingPrefixResolver::class)->resolve($currentClone);
            } catch (RuntimeException $exception) {
                $this->returnException($exception->getMessage());
            }
            $this->options->path               = $this->filesystem->normalizePath($currentClone['path'], true);
            $this->options->databaseUser       = $currentClone['databaseUser'];
            $this->options->databasePassword   = $currentClone['databasePassword'];
            $this->options->databaseDatabase   = $currentClone['databaseDatabase'];
            $this->options->databaseServer     = $currentClone['databaseServer'];
            $this->options->databasePrefix     = $currentClone['databasePrefix'];
            $this->options->databaseSsl        = isset($currentClone['databaseSsl']) ? (bool)$currentClone['databaseSsl'] : false;
            $this->options->uploadsSymlinked   = isset($currentClone['uploadsSymlinked']) ? (bool)$currentClone['uploadsSymlinked'] : false;
            $this->options->networkClone       = isset($currentClone['networkClone']) ? (bool)$currentClone['networkClone'] : false;
        } else {
            wp_die('Fatal error - The clone does not exist in database. This should not happen.');
        }

 
        $this->options->clonedTables   = [];

 
        $this->options->totalFiles    = 0;
        $this->options->copiedFiles   = 0;
        $this->options->totalFileSize = 0;

 
        $this->options->includedDirectories = [];
        $this->options->excludedDirectories = [];
        $this->options->extraDirectories    = [];
        $this->options->directoriesToCopy   = [];
        $this->options->scannedDirectories  = [];

 
        $this->options->excludedDirectories = $this->getExcludedDirectories();

 
        $this->options->currentJob  = "";
        $this->options->currentStep = 0;
        $this->options->totalSteps  = 0;

 
        $this->assignBackupId($this->options);

 
        $this->saveOptions();

        return $this;
    }

    protected function setTablesToPush()
    {
        $this->options->tablePushSelection     = $this->getTablePushSelection();
        $this->options->tablesExcludedByFilter = $this->getExcludedCustomTables();
        $this->saveOptions();
    }





    protected function getExcludedDirectories()
    {
        if (!empty($this->options->existingClones[$this->options->clone]['excludedDirs'])) {
            return $this->options->existingClones[$this->options->clone]['excludedDirs'];
        }

        return [];
    }





    protected function getTablePushSelection()
    {
        $excludedTables = $this->getExcludedCustomTables();
        $pushSelections = [];
        foreach ($this->getTablesSelection() as $table) {
            if (in_array($table, $excludedTables)) {
                continue;
            }

            $pushSelections[] = $table;
        }

        return $pushSelections;
    }

    protected function getTablesSelection()
    {
        if (!empty($this->options->existingClones[$this->options->clone]['tablePushSelection'])) {
            return $this->options->existingClones[$this->options->clone]['tablePushSelection'];
        }

        $tableObjects = $this->options->tables;
        $tables       = [];
        foreach ($tableObjects as $table) {
            if ($this->isTableSelected($table->name)) {
                $tables[] = $table->name;
            }
        }

        return $tables;
    }

    protected function isTableSelected($table)
    {
        $tableWithoutPrefix = wpstg_replace_first_match($this->options->prefix, '', $table);
        preg_match('/^\D*/', $tableWithoutPrefix, $match);
        if (is_multisite() && is_main_site() && !$this->isNetworkClone() && array_filter($match)) {
            return true;
        }

        if (is_multisite() && is_main_site() && !$this->isNetworkClone()) {
            return false;
        }

        if (strpos($table, $this->options->prefix) === 0) {
            return true;
        }

        return false;
    }





    protected function getExcludedCustomTables()
    {
        return TableScanner::getExcludedTables($this->options->prefix, array_map(function ($table) {
            return $table->name;
        }, $this->options->tables));
    }




    private function installOptimizer()
    {
        $optimizer = new Optimizer();
        $optimizer->installOptimizer();
    }






    public function directoryListing($directories = null, $forceDisabled = false)
    {
        if ($directories === null && !in_array('uploads', $this->directories)) {
            $stagingUploadsFolder = $this->options->path . $this->dirUtils->getRelativeUploadPath();
            $currentArray = &$this->directories;
            $currentArray['uploads']["metaData"] = [
                "size" => 0,
                "path" => rtrim($stagingUploadsFolder, '/\\'),
            ];
        }

        if ($directories == null) {
            $directories = $this->directories;
        }

        $output = '';
        foreach ($directories as $name => $directory) {
 
            if (!is_array($directory)) {
                continue;
            }

 
            $data = reset($directory);
            unset($directory[key($directory)]);

            $cloneDir = trailingslashit($this->options->path);
 
            $directoriesToCheck = [
                $cloneDir . 'wp-content/plugins',
                $cloneDir . 'wp-content/themes',
                $cloneDir . 'wp-content/uploads',
            ];

            $isChecked = false;
            if (!empty($this->options->excludedDirectories) || $this->strUtils->startsWithAnyFromList($directoriesToCheck, $data["path"])) {
                $isChecked = true;
            }

 
            if (in_array($data["path"], $this->options->excludedDirectories)) {
                $isDisabled = true;
            } else {
                $isDisabled = false;
            }

            $idName = uniqid('wpstg');
            $output .= "<div class='wpstg-dir'>";

            $isCheckboxChecked = false;

            if ($isChecked && !$isDisabled && !$forceDisabled) {
                $isCheckboxChecked = true;
            }

            $attributes = [
                'classes' => 'wpstg-check-dir',
            ];

            if (!empty($directory)) {
                $attributes['classes'] .= ' wpstg-parent-dir';
            }

            $disabledClass = '';

            if (is_link($data['path'])) {
                $attributes['isDisabled'] = true;
                $disabledClass .= ' wpstg-storage-settings-disabled';
                $output .= Checkbox::render($idName, '', $data["path"], false, $attributes, [], true);
            } else {
                $output .= Checkbox::render($idName, 'selectedDirectories[]', $data["path"], $isCheckboxChecked, $attributes, [], true);
            }

            $output .= "<label class='wpstg-push-expand-dirs{$disabledClass}' for='{$idName}'>{$name}</label>";

            if (is_link($data['path'])) {
                $assetsUrl = trailingslashit(WPSTG_PLUGIN_URL);
                $output .= "<span class='wpstg--tooltip wpstg--tooltip-normal'>
                    <img class='wpstg--dashicons wpstg--grey wpstg-symlink-dir-tooltip' src='{$assetsUrl}assets/svg/info-outline.svg' alt='info'/>
                    <span class='wpstg--tooltiptext'>
                        " . __('This option is disabled as uploads directory was symlinked', 'wp-staging') . "
                    </span>
                </span>";
            }

            if (!empty($directory)) {
                $output .= "<div class='wpstg-dir wpstg-subdir wpstg-push'>";
                $output .= $this->directoryListing($directory, $isDisabled);
                $output .= "</div>";
            }

            $output .= "</div>";
        }

        return $output;
    }






    public function hasFreeDiskSpace()
    {
        $freeSpace = false;
 
        if (function_exists("disk_free_space")) {
            $freeSpace = @disk_free_space($this->options->path);
        }

        $data = [
            'freespace' => $freeSpace === false ? false : $this->utilsMath->formatSize($freeSpace),
            'usedspace' => $this->utilsMath->formatSize($this->getDirectorySizeInclSubdirs($this->options->path)),
        ];

        echo json_encode($data);
        die();
    }




    protected function buildDirectories()
    {
        $wpcontentDir = $this->options->path . 'wp-content';
 
        if (!file_exists($wpcontentDir)) {
            wp_die(sprintf(
                Escape::escapeHtml(__('<strong>Fatal error:</strong> Path <code>%s</code> does not exist!  <br><br> Did you move from one server to another recently or changed the location of your site? <br><br>
                ​If you moved your site please reconnect the staging site to the new location and change the path in WP STAGING settings.
                <br><br>​
                <a href="%s" target="_blank">Learn how to fix this.</a><br>
                <br>
                If you still need help, <a href="%s" target="_blank">please contact us!</a>', 'wp-staging')),
                esc_html($wpcontentDir),
                'https://wp-staging.com/docs/moved-website-to-new-server-can-not-push-staging-site/',
                Language::localizeSupportUrl('https://wp-staging.com/support/')
            ));
        }

        $directories = new DirectoryIterator($wpcontentDir);

        foreach ($directories as $directory) {
 
            if (($path = $this->getPath($directory)) === false) {
                continue;
            }

            $this->handleDirectory($path);

 
            $this->getSubDirectories($this->filesystem->normalizePath($directory->getRealPath()));
        }
    }





    protected function buildUploadsDirectories()
    {
        $relPath = rtrim($this->dirUtils->getRelativeUploadPath(), '/\\');
        $absPath = wpstg_get_abs_upload_dir();
        $path    = $this->options->path . $relPath;

 
        if (strpos($absPath, 'wp-content/uploads') !== false) {
            return false;
        }

        $currentArray = &$this->directories;

        $currentArray[$relPath]["metaData"] = [
            "size" => 0,
            "path" => $path,
        ];

        return true;
    }








    protected function getPath(DirectoryIterator $directory)
    {
        if (!$directory->isDir() || $directory->isDot()) {
            return false;
        }






        $realPath = $this->filesystem->normalizePath($directory->getRealPath());
        if (strpos($realPath, $this->options->path) === false) {
            return false;
        }

        $path = str_replace($this->options->path . 'wp-content/', '', $realPath);
        if (empty($path) || strpos($realPath, $this->options->path . 'wp-content/mu-plugins') === 0) {
            return false;
        }

        return $path;
    }




    protected function getSubDirectories($path)
    {
        if (!is_dir($path)) {
            return;
        }

        $directories = new DirectoryIterator($path);

        foreach ($directories as $directory) {
 
            if (($path = $this->getPath($directory)) === false) {
                continue;
            }

            $this->handleDirectory($path);
        }
    }





    protected function handleDirectory($path)
    {
        $directoryArray = explode('/', $path);
        $total          = (is_array($directoryArray) || $directoryArray instanceof Countable) ? count($directoryArray) : 0;

        if ($total < 1) {
            return;
        }

        $total        = $total - 1;
        $currentArray = &$this->directories;

        for ($i = 0; $i <= $total; $i++) {
            if (!isset($currentArray[$directoryArray[$i]])) {
                $currentArray[$directoryArray[$i]] = [];
            }

            $currentArray = &$currentArray[$directoryArray[$i]];

 
            if ($i < $total) {
                continue;
            }

            $fullPath = $this->options->path . 'wp-content' . '/' . $path;

            $currentArray["metaData"] = [
                "path" => $fullPath,
            ];
        }
    }






    protected function getDirectorySizeInclSubdirs($dir)
    {
        $size = 0;
        foreach (glob(rtrim($dir, '/') . '/*', GLOB_NOSORT) as $each) {
            $size += is_file($each) ? filesize($each) : $this->getDirectorySizeInclSubdirs($each);
        }

        return $size;
    }

    public function loadStagingDBTables($onlyStagingPrefix = true)
    {
        $selectedTables = new SelectedTables();
        $selectedTables->setWpdb($this->db, $this->options->prefix);
        if (!$onlyStagingPrefix) {
            $selectedTables->shouldIncludeAllTables(true);
        }

        $currentTables = $selectedTables->getPrefixedTables($this->isNetworkClone(), true);

        $this->options->tables = json_decode(json_encode($currentTables));
    }





    protected function getStagingTables()
    {
 
        $this->loadStagingDBTables();
    }





    private function isVersionIdentical()
    {
 
        $versionCompatibility = WPStaging::make(WordPressVersionCompatibility::class);
        $compatibility        = $versionCompatibility->evaluateForEngine($this->options->path, StagingEngine::ENGINE_LEGACY);

        if (!$compatibility['allowed']) {
            wp_die(Escape::escapeHtml($compatibility['message']));
        }

        return true;
    }






    protected function isWpBakeryActive()
    {
 
        $pluginIndexFile = 'js_composer.php';
        return $this->isPluginActive($pluginIndexFile);
    }







    protected function isPluginActive($pluginIndexFile)
    {
        $optionTable = $this->options->prefix . 'options';
        if (!$this->tableExists($optionTable)) {
            return false;
        }

        $stagingActivePlugins = $this->db->get_var("SELECT option_value FROM `$optionTable` WHERE option_name = 'active_plugins';");

        if (empty($stagingActivePlugins)) {
            return false;
        }

        return strpos($stagingActivePlugins, $pluginIndexFile) !== false;
    }






    private function tableExists($table)
    {
        return !($table != $this->db->get_var("SHOW TABLES LIKE '{$table}'"));
    }
}
