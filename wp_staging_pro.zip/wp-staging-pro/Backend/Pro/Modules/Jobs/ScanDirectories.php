<?php

namespace WPStaging\Backend\Pro\Modules\Jobs;

use Exception;
use WPStaging\Backend\Modules\Jobs\JobExecutable;
use WPStaging\Backend\Pro\Modules\Jobs\Copiers\Copier;
use WPStaging\Core\Utils\Logger;
use WPStaging\Core\WPStaging;
use WPStaging\Framework\Adapter\Directory;
use WPStaging\Framework\Filesystem\Filesystem;
use WPStaging\Framework\Filesystem\PathIdentifier;
use WPStaging\Framework\SiteInfo;
use WPStaging\Framework\Traits\FileScanToCacheTrait;
use WPStaging\Framework\Utils\Strings;
use WPStaging\Framework\Utils\WpDefaultDirectories;








class ScanDirectories extends JobExecutable
{
    use FileScanToCacheTrait;









    private $total = 4;





    private $filename;








    private $filesystem;

 
    private $pathAdapter;

 
    private $dirAdapter;




    private $siteInfo;




    private $stagingPath;




    private $stagingWpContentPath;

 
    private $canonicalStagingRoot;




    public function initialize()
    {
        $this->filename      = $this->getFilesIndexCacheFilePath();

 
        $this->filesystem  = WPStaging::make(Filesystem::class);
        $this->stagingPath = rtrim($this->filesystem->normalizePath($this->options->path));
        $this->pathAdapter = WPStaging::make(PathIdentifier::class);
        $this->siteInfo    = WPStaging::make(SiteInfo::class);
        $this->dirAdapter  = WPStaging::make(Directory::class);
        $this->strUtils    = WPStaging::make(Strings::class);

        $this->stagingWpContentPath = trailingslashit($this->stagingPath) . 'wp-content/';

        if ($this->options->currentStep === 0) {
 
            $this->options->extraDirectories = array_merge($this->options->extraDirectories, $this->getOtherWpContentFolders());
        }

        $this->filesIndexCache->initWithPhpHeader();
    }





    protected function calculateTotalSteps()
    {
        $this->options->totalSteps = $this->total + count($this->options->extraDirectories);
    }





    public function start()
    {
 
        $this->run();

 
        $this->saveProgress();

        return (object) $this->response;
    }





    public function getStagingPlugins()
    {
        $path          = $this->stagingWpContentPath . 'plugins/';
        $normalizePath = $this->filesystem->normalizePath($path);

        if ($this->isDirectoryExcluded($path)) {
            $this->log('Scanning: Skip ' . $normalizePath);
            return true;
        }

        $files = $this->open($this->filename, 'a');

        $excludeFolders = [
            '**/nbproject',
            '**/wp-staging*', 
            '**/wps-hide-login',
            '**/' . Copier::PREFIX_BACKUP . '*',
            '**/' . Copier::PREFIX_TEMP . '*',
        ];
        $excludeFolders = array_merge($this->options->excludedDirectories, $excludeFolders);

        $this->log(sprintf('Scanning %s, its sub-directories and files', $normalizePath));
        try {
            $this->setPathIdentifier(PathIdentifier::IDENTIFIER_PLUGINS);
            $this->options->totalFiles += $this->scanToCacheFile($files, $path, true, $excludeFolders, [], $normalizePath);
        } catch (Exception $e) {
            $this->returnException('Error: ' . $e->getMessage());
        }

        $this->close($files);
        return true;
    }





    public function getStagingThemes()
    {
        $path          = $this->stagingWpContentPath . 'themes/';
        $normalizePath = $this->filesystem->normalizePath($path);

        if ($this->isDirectoryExcluded($path)) {
            $this->log('Scanning: Skip ' . $normalizePath);
            return true;
        }

        $files = $this->open($this->filename, 'a');

        $excludeFolders = [
            '**/nbproject',
            '**/' . Copier::PREFIX_BACKUP . '*',
            '**/' . Copier::PREFIX_TEMP . '*',
        ];
        $excludeFolders = array_merge($this->options->excludedDirectories, $excludeFolders);

        $this->log(sprintf('Scanning %s, its sub-directories and files', $normalizePath));
        try {
            $this->setPathIdentifier(PathIdentifier::IDENTIFIER_THEMES);
            $this->options->totalFiles += $this->scanToCacheFile($files, $path, true, $excludeFolders, [], $normalizePath);
        } catch (Exception $e) {
            $this->returnException('Error: ' . $e->getMessage());
        }

        $this->close($files);
        return true;
    }





    public function getStagingUploads()
    {
        if ($this->isMultisiteAndPro()) {
 
            $folder = $this->stagingWpContentPath . 'uploads/sites';
            if (is_dir($folder)) {
                $this->getStagingUploadsNew();
            } else {
                $this->getStagingUploadsOld();
            }

            return true;
        }

        $path = trailingslashit($this->stagingPath) . $this->getUploadFolder() . "/";
        if ($this->siteInfo->isWpContentOutsideAbspath()) {
            $path = trailingslashit($this->stagingPath) . "wp-content/uploads/";
        }

        $normalizePath = $this->filesystem->normalizePath($path);

 
        if ($this->isDirectoryExcluded($normalizePath)) {
            $this->log('Scanning: Skip ' . $normalizePath);
            return true;
        }

        if (!is_dir($normalizePath)) {
            $this->log('Scanning: Not a valid path ' . $normalizePath);
            return true;
        }

        $files = $this->open($this->filename, 'a');

        $relpath = str_replace($this->stagingPath, '', $normalizePath);

        $excludeFolders = [
            '**/node_modules',
            '**/nbproject',
            $relpath . 'wp-staging',
            $path . 'wp-staging', 
        ];
        $excludeFolders = array_merge($this->options->excludedDirectories, $excludeFolders);

        $this->log(sprintf('Scanning %s, its sub-directories and files', $normalizePath));

        try {
            $this->setPathIdentifier(PathIdentifier::IDENTIFIER_UPLOADS);
            $this->options->totalFiles += $this->scanToCacheFile($files, $path, true, $excludeFolders, [], $normalizePath);
        } catch (Exception $e) {
            $this->returnException('Error: ' . $e->getMessage());
        }

        $this->close($files);
        return true;
    }







    public function getStagingUploadsOld()
    {
        $path          = $this->stagingWpContentPath . 'uploads/';
        $normalizePath = $this->filesystem->normalizePath($path);

        if ($this->isDirectoryExcluded($path)) {
            return true;
        }

        if (!is_dir($path)) {
            return true;
        }

        $files = $this->open($this->filename, 'a');

        $excludeFolders = [
            '**/wp-staging',
            '**/node_modules',
            '**/nbproject',
        ];

        $this->log(sprintf('Scanning %s, its sub-directories and files', $normalizePath));

        try {
            $this->setPathIdentifier(PathIdentifier::IDENTIFIER_UPLOADS);
            $this->options->totalFiles += $this->scanToCacheFile($files, $path, true, $excludeFolders, [], $normalizePath);
        } catch (Exception $e) {
            $this->returnException('Error: ' . $e->getMessage());
        }

        $this->close($files);
        return true;
    }





    private function getStagingUploadsNew()
    {
        $path          = trailingslashit($this->stagingPath) . $this->getRelUploadDir();
        $normalizePath = $this->filesystem->normalizePath($path);

        if ($this->isDirectoryExcluded($path)) {
            return true;
        }

        if (!is_dir($path)) {
            return true;
        }

        $files = $this->open($this->filename, 'a');

        $excludeFolders = [
            '**/wp-staging',
            '**/node_modules',
            '**/nbproject',
        ];
        $excludeFolders = array_merge($this->options->excludedDirectories, $excludeFolders);

        $this->log(sprintf('Scanning %s, its sub-directories and files', $normalizePath));

        try {
            $this->setPathIdentifier(PathIdentifier::IDENTIFIER_UPLOADS);
            $this->options->totalFiles += $this->scanToCacheFile($files, $path, true, $excludeFolders, [], $normalizePath);
        } catch (Exception $e) {
            $this->returnException('Error: ' . $e->getMessage());
        }

        $this->close($files);
        return true;
    }




    private function getRelUploadDir()
    {
        $uploads     = wp_upload_dir();
        $basedir     = $uploads['basedir'];
        $relativeDir = str_replace(ABSPATH, '', $this->filesystem->normalizePath($basedir, true));
        return trailingslashit($relativeDir);
    }







    private function getRelUploadPath()
    {
 
        $uploads = wp_upload_dir();
        $basedir = $uploads['basedir'];
        $blogId  = get_current_blog_id();
        if (strpos($basedir, 'blogs.dir') === false) {
 
            $getRelUploadPath = $blogId > 1 ?
                    'wp-content/uploads/sites/' . get_current_blog_id() . "/" :
                    'wp-content/uploads/';
        } else {
 
            $getRelUploadPath = $blogId > 1 ?
                    'wp-content/blogs.dir/' . get_current_blog_id() . '/files/' :
                    'wp-content/';
        }
        return $getRelUploadPath;
    }






    private function getOtherWpContentFolders(): array
    {
        $pluginsPath     = $this->stagingWpContentPath . 'plugins';
        $themesPath      = $this->stagingWpContentPath . 'themes';
        $uploadsPath     = $this->stagingWpContentPath . 'uploads';
        $realUploadsPath = trailingslashit($this->stagingPath) . $this->getUploadFolder();
        $muPluginsPath   = $this->stagingWpContentPath . 'mu-plugins';

        $includedDirectories = $this->options->includedDirectories;

        $filteredPaths = array_filter($includedDirectories, function ($path) use ($pluginsPath, $themesPath, $uploadsPath, $realUploadsPath, $muPluginsPath) {
            if ($this->isWindowsOs()) {
                return !$this->strUtils->isPathInsideAnyIgnoringCase($path, [$pluginsPath, $themesPath, $uploadsPath, $realUploadsPath, $muPluginsPath]);
            }

            return (
                strpos($path, $pluginsPath)     === false &&
                strpos($path, $themesPath)      === false &&
                strpos($path, $uploadsPath)     === false &&
                strpos($path, $realUploadsPath) === false &&
                strpos($path, $muPluginsPath)   === false
            );
        });

        if (!is_array($filteredPaths)) {
            return [];
        }

        return $filteredPaths;
    }






    protected function getExtraFiles($folder)
    {
        $folder        = rtrim($folder, DIRECTORY_SEPARATOR);
        $normalizePath = $this->filesystem->normalizePath($folder);

        if (!is_dir($normalizePath)) {
            return true;
        }

 
 
        $canonicalPath = $this->canonicalizeWithinStagingRoot($normalizePath);
        if ($canonicalPath === '') {
            $this->log(sprintf('Skipping extra directory "%s" because it resolves outside the staging site root.', $normalizePath));
            return true;
        }

        if ($this->isReservedWordPressDirectory($canonicalPath)) {
            $this->log(sprintf('Skipping extra directory "%s" because it resolves to the staging site root or a default WordPress directory.', $canonicalPath));
            return true;
        }

        if ($this->isDirectoryExcluded($normalizePath) || $this->isDirectoryExcluded($canonicalPath)) {
            $this->log('Scanning: Skip ' . $canonicalPath);
            return true;
        }

 
        if ($this->strUtils->startsWithAnyFromList($this->options->scannedDirectories, $canonicalPath . '/')) {
            $this->log(sprintf('Skipping extra directory "%s" because a selected folder containing it was already scanned.', $canonicalPath));
            return true;
        }

        $normalizePath = $canonicalPath;
        $canonicalRoot = $this->getCanonicalRootPath();

        $files = $this->open($this->filename, 'a');

        $this->log(sprintf('Scanning %s, its sub-directories and files', $normalizePath));

        $canonicalWpContent = trailingslashit($canonicalRoot) . 'wp-content/';
        if ($this->siteInfo->isWpContentOutsideAbspath() && strpos(trailingslashit($normalizePath), $canonicalWpContent) === 0) {
            $dirPrefix = PathIdentifier::IDENTIFIER_WP_CONTENT;
            $rootPath  = $canonicalWpContent;
        } else {
            $dirPrefix = PathIdentifier::IDENTIFIER_ABSPATH;
            $rootPath  = trailingslashit($canonicalRoot);
        }

        $pluginWpContentDir = rtrim($this->dirAdapter->getPluginWpContentDirectory(), '/\\');

 
 
        $userExclusions = array_merge($this->options->excludedDirectories, array_map([$this, 'canonicalizeWithinStagingRoot'], $this->options->excludedDirectories));
        $userExclusions = array_filter(array_unique($userExclusions), function ($excludedPath) use ($canonicalPath) {
            return $this->strUtils->startsWith($excludedPath, $canonicalPath . '/');
        });

 
        $excludedPaths = array_merge([
            $this->pathAdapter->transformPathToIdentifiable($pluginWpContentDir),
            PathIdentifier::IDENTIFIER_WP_CONTENT . WPSTG_PLUGIN_DOMAIN, 
        ], $userExclusions);

        try {
            $this->setPathIdentifier($dirPrefix);
            $this->options->totalFiles += $this->scanToCacheFile($files, $normalizePath, true, $excludedPaths, [], $rootPath);
        } catch (Exception $e) {
            $this->returnException('Error: ' . $e->getMessage());
        }

        if (is_readable($canonicalPath)) {
            $this->options->scannedDirectories[] = $canonicalPath . '/';
        }

        $this->close($files);
        return true;
    }







    protected function isReservedWordPressDirectory(string $canonicalPath): bool
    {
        $canonicalRoot = $this->getCanonicalRootPath();
        if ($canonicalRoot === '') {
            return false;
        }

        if ($canonicalPath === $canonicalRoot || $canonicalPath === $canonicalRoot . '/wp-content') {
            return true;
        }

        foreach (['wp-admin', 'wp-includes'] as $defaultDirectory) {
            $defaultPath = $canonicalRoot . '/' . $defaultDirectory;
            if ($canonicalPath === $defaultPath || strpos($canonicalPath, $defaultPath . '/') === 0) {
                return true;
            }
        }

        return false;
    }

 
    protected function getCanonicalRootPath(): string
    {
        if ($this->canonicalStagingRoot !== null) {
            return $this->canonicalStagingRoot;
        }

        $realRoot = $this->realpathQuietly($this->stagingPath);
        $this->canonicalStagingRoot = $realRoot === false ? '' : rtrim($this->filesystem->normalizePath($realRoot, true), '/');

        return $this->canonicalStagingRoot;
    }

 
    protected function canonicalizeWithinStagingRoot(string $path): string
    {
        $realPath      = $this->realpathQuietly($path);
        $canonicalRoot = $this->getCanonicalRootPath();
        if ($realPath === false || $canonicalRoot === '') {
            return '';
        }

        $normalizedPath = rtrim($this->filesystem->normalizePath($realPath, true), '/');

        if ($normalizedPath !== $canonicalRoot && strpos($normalizedPath, $canonicalRoot . '/') !== 0) {
            return '';
        }

        return $normalizedPath;
    }

 
    protected function realpathQuietly(string $path)
    {
        set_error_handler(function () {
            return true;
        });

        try {
            return realpath($path);
        } finally {
            restore_error_handler();
        }
    }







    public function close($handle)
    {
        return @fclose($handle);
    }









    public function open($file, $mode)
    {
        $file_handle = @fopen($file, $mode);
        if ($file_handle === false) {
            $this->returnException(sprintf(__('Unable to open %s with mode %s', 'wp-staging'), $file, $mode));
        }

        return $file_handle;
    }










    public function write($handle, $content)
    {
        $write_result = @fwrite($handle, $content);
        if ($write_result === false) {
            if (( $meta = stream_get_meta_data($handle) )) {
 
                throw new Exception(sprintf(__('Unable to write to: %s', 'wp-staging'), $meta['uri']));
            }
        } elseif ($write_result !== strlen($content)) {
 
            throw new Exception(__('Out of disk space.', 'wp-staging'));
        }

        return $write_result;
    }






    protected function execute()
    {
 
        if ($this->isFinished()) {
            $this->prepareResponse(true, false);
            return false;
        }

        if ($this->options->currentStep == 0) {
            $this->getStagingPlugins();
            $this->prepareResponse(false, true);
            return false;
        }

        if ($this->options->currentStep == 1) {
            $this->getStagingThemes();
            $this->prepareResponse(false, true);
            return false;
        }

        if ($this->options->currentStep == 2) {
            $this->getStagingUploads();
            $this->prepareResponse(false, true);
            return false;
        }

        if (isset($this->options->extraDirectories[$this->options->currentStep - $this->total])) {
            $this->getExtraFiles($this->options->extraDirectories[$this->options->currentStep - $this->total]);
            $this->prepareResponse(false, true);
            return false;
        }

 
        $this->prepareResponse(false, true);
        return true;
    }





    protected function isFinished()
    {
        return ($this->options->currentStep > $this->options->totalSteps);
    }





    protected function saveProgress()
    {
        return $this->saveOptions();
    }








    private function sanitizeDirectorySeparator($path)
    {
        $string = str_replace("/", "\\", $path);
        return str_replace('\\\\', '\\', $string);
    }






    protected function isDirectoryExcluded($directory)
    {
        if ($this->isWindowsOs()) {
            return $this->strUtils->isPathInsideAnyIgnoringCase($directory, $this->options->excludedDirectories);
        }

        $directory = $this->sanitizeDirectorySeparator($directory);
        foreach ($this->options->excludedDirectories as $excludedDirectory) {
            $excludedDirectory = $this->sanitizeDirectorySeparator($excludedDirectory);
            if (strpos(trailingslashit($directory), trailingslashit($excludedDirectory)) === 0) {
                return true;
            }
        }

        return false;
    }




    public function log($msg, $type = Logger::TYPE_INFO)
    {
        parent::log($msg, $type);
    }

    protected function isWindowsOs(): bool
    {
        return WPStaging::isWindowsOs();
    }






    protected function getUploadFolder()
    {
        $uploads = wp_upload_dir();
        $folder  = str_replace(ABSPATH, '', $uploads['basedir']);
        return $folder;
    }
}
