<?php

namespace WPStaging\Backend\Pro\Modules\Jobs;

use stdClass;
use WPStaging\Backend\Modules\Jobs\CloningProcess;
use WPStaging\Framework\Database\QueryBuilder\InsertValues;
use WPStaging\Framework\Database\QueryBuilder\SelectQuery;
use WPStaging\Framework\Database\TableService;
use WPStaging\Framework\Utils\Strings;
use WPStaging\Core\Utils\Logger;
use WPStaging\Core\WPStaging;





class DatabaseTmp extends CloningProcess
{
 
    private $total = 0;

 
    const TMP_PREFIX = 'wpstgtmp_';







    const TMP_PREFIX_CUSTOM_TABLE = 'wpstgtmx_';

 
    const TMP_PREFIX_TO_DROP = 'wpstgbak_';

 
    private $strings;




    protected $selectQueryBuilder;

    public function initialize()
    {
        $this->total = count($this->options->tables);
        $this->strings = new Strings();
        $this->selectQueryBuilder = new SelectQuery();
        $this->initializeDbObjects();
    }





    protected function calculateTotalSteps()
    {
        $this->options->totalSteps = $this->total !== 0 ? $this->total : 1;
    }







    protected function execute()
    {
 
        if ($this->isOverThreshold()) {
 
            $this->prepareResponse(false, false);
            $this->saveOptions();
            return false;
        }

 
        if ($this->total === 0) {
            $this->prepareResponse(true, false);
            return false;
        }

 
        if ($this->options->currentStep > $this->total || !isset($this->options->tables[$this->options->currentStep])) {
            $this->prepareResponse(true, false);
            return false;
        }

        $tablesExcluded = is_object($this->options) && property_exists($this->options, 'tablesExcludedByFilter') ? $this->options->tablesExcludedByFilter : [];

        if (in_array($this->options->tables[$this->options->currentStep], $tablesExcluded)) {
            $this->prepareResponse();
            return true;
        }

 
        if (($this->isExternalDatabase() || !$this->stopExecution()) && !$this->copyTable($this->options->tables[$this->options->currentStep])) {
            $this->prepareResponse(false, false);

 
            return true;
        }

 
        $this->prepareResponse();

 
        return true;
    }






    private function stopExecution()
    {
        if ($this->productionDb->prefix == self::TMP_PREFIX) {
            $this->returnException('Fatal Error 9: Prefix ' . $this->productionDb->prefix . ' is used for the live site hence it can not be used for the staging site as well. Please ask support@wp-staging.com how to resolve this.');
        }

        return false;
    }






    public function shouldReplaceTablePrefix($srcTableName, $prefix)
    {
        return $this->strings->startsWith($srcTableName, $prefix);
    }






    private function copyTable($srcTableName)
    {
        if ($this->shouldReplaceTablePrefix($srcTableName, $this->options->prefix)) {
            $destTableName = self::TMP_PREFIX . $this->strings->str_replace_first($this->options->prefix, '', $srcTableName);
        } else {
            $destTableName = self::TMP_PREFIX_CUSTOM_TABLE . $srcTableName;
        }

 
        $this->dropTable($destTableName);

 
        $this->setJob($destTableName);

 
        if (!$this->startJob($destTableName, $srcTableName)) {
            return true;
        }

 
        $this->copyData($srcTableName, $destTableName);

 
        return $this->finishStep();
    }







    private function copyData($srcTableName, $destTableName)
    {
        if ($this->isExternalDatabase()) {
            $this->copyDataExternal($destTableName, $srcTableName);
            return;
        }

        $rows = $this->options->job->start + $this->settings->queryLimit;
        $this->log(
            "DB tmp table: $srcTableName as $destTableName from {$this->options->job->start} to $rows records"
        );

        $preparedQuery = $this->selectQueryBuilder->prepareQueryWithFilter($srcTableName, (int)$this->settings->queryLimit, $this->options->job->start, 'pushing');
        $preparedValues = $this->selectQueryBuilder->getPreparedValues();
        $preparedQuery = "INSERT INTO `$destTableName` $preparedQuery";

        if (count($preparedValues) > 0) {
            $preparedQuery = $this->productionDb->prepare($preparedQuery, $preparedValues);
        }

        $this->productionDb->query("SET SESSION sql_mode='NO_AUTO_VALUE_ON_ZERO'");
        $this->productionDb->query($preparedQuery);

 
        $this->options->job->start += $this->settings->queryLimit;
    }






    private function copyDataExternal($destTableName, $srcTableName)
    {
        $rows = $this->options->job->start + $this->settings->queryLimit;

        $this->log(
            "DB tmp table: INSERT {$this->stagingDb->dbname}.$srcTableName as {$this->productionDb->dbname}.$destTableName from {$this->options->job->start} to $rows records"
        );

        $preparedQuery = $this->selectQueryBuilder->prepareQueryWithFilter($srcTableName, (int)$this->settings->queryLimit, $this->options->job->start, 'pushing');
        $preparedValues = $this->selectQueryBuilder->getPreparedValues();

        if (count($preparedValues) > 0) {
            $preparedQuery = $this->stagingDb->prepare($preparedQuery, $preparedValues);
        }

 
        $rows = $this->stagingDb->get_results($preparedQuery, ARRAY_A);
        if ($this->stagingDb->last_error !== '') {
            $this->stopCopyExternal("DB Tmp Table: Error - Can not read rows of $srcTableName db error - {$this->stagingDb->last_error}");
            return;
        }

 
        $insertValues = WPStaging::make(InsertValues::class);
        $columnTypes  = $insertValues->readColumnTypes($this->stagingDb, $srcTableName);

 
        $this->productionDb->query('SET autocommit=0;');
        $this->productionDb->query('SET FOREIGN_KEY_CHECKS=0;');
        $this->productionDb->query('START TRANSACTION;');

 
        $suppressedErrors = $this->productionDb->suppress_errors(true);
        $duplicateRows    = 0;
        $firstDuplicate   = '';
        $error            = '';
        foreach ($rows as $row) {
            if ($this->productionDb->query("INSERT INTO `$destTableName` VALUES (" . $insertValues->formatRow($row, $columnTypes) . ")") !== false) {
                continue;
            }

            if (stripos($this->productionDb->last_error, 'Duplicate entry') === false) {
                $error = "Can not copy a row of $srcTableName TO $destTableName db error - {$this->productionDb->last_error}";
                break;
            }

            $duplicateRows++;
            $firstDuplicate = $firstDuplicate ?: $this->productionDb->last_error;
        }

        if ($error !== '') {
            $this->productionDb->query('ROLLBACK;');
        } elseif ($this->productionDb->query('COMMIT;') === false) {
            $error = "Can not commit rows of $srcTableName TO $destTableName db error - {$this->productionDb->last_error}";
        }

        $this->productionDb->query('SET autocommit=1;');
        $this->productionDb->suppress_errors($suppressedErrors);
        if ($error !== '') {
            $this->stopCopyExternal("DB Tmp Table: Error - $error");
            return;
        }

        if ($duplicateRows > 0) {
            $this->log("DB tmp table: Skipped $duplicateRows rows of $srcTableName whose key already exists in $destTableName (first: $firstDuplicate)", Logger::TYPE_WARNING);
        }

 
        $this->options->job->start += $this->settings->queryLimit;
    }




    private function stopCopyExternal($message)
    {
        $this->log($message, Logger::TYPE_ERROR);
        $this->returnException($message);
    }





    private function setJob($tableName)
    {
        if (isset($this->options->job->current)) {
            return;
        }

 
        if (!is_object($this->options->job)) {
            $this->options->job = new stdClass();
        }

        $this->options->job->current = $tableName;
        $this->options->job->start = 0;
    }







    private function startJob($destTableName, $srcTableName)
    {
        if ($this->isExternalDatabase()) {
            return $this->startJobExternal($destTableName, $srcTableName);
        }

        if ($this->options->job->start != 0) {
            return true;
        }

        $this->log("DB tmp table: CREATE table $destTableName");

        $this->productionDb->query("CREATE TABLE `$destTableName` LIKE `$srcTableName`");

        $this->options->job->total = (int)$this->productionDb->get_var("SELECT COUNT(1) FROM `$srcTableName`");

        if ($this->options->job->total == 0) {
            $this->finishStep();
            return false;
        }

        return true;
    }







    private function startJobExternal($destTableName, $srcTableName)
    {
        if ($this->options->job->start != 0) {
            return true;
        }

        $this->log("DB tmp table: CREATE table `{$this->productionDb->dbname}.$destTableName`");

 
        $sql = $this->getCreateStatement($srcTableName);

 
        if ($sql === []) {
            return false;
        }

 
        $sql = str_replace("CREATE TABLE `$srcTableName`", "CREATE TABLE `$destTableName`", $sql);

        $sql = WPStaging::make(TableService::class)->replaceTableConstraints($sql);
        $sql = wpstg_unique_constraint($sql);

        $this->productionDb->query('SET FOREIGN_KEY_CHECKS=0;');

 
        if ($this->productionDb->query($this->adaptCreateStatement($sql)) === false) {
            $this->returnException("DB Tmp Table: Error - Can not copy table $srcTableName TO $destTableName Query: $sql db error - " . $this->productionDb->last_error);
        }

 
        $this->options->job->total = (int)$this->stagingDb->get_var("SELECT COUNT(1) FROM `{$this->stagingDb->dbname}`.`$srcTableName`");

        if ($this->options->job->total == 0) {
            $this->finishStep();
            return false;
        }

        return true;
    }






    private function adaptCreateStatement($sqlQuery)
    {
        $fromDbVersion = $this->stagingDb->get_var("SELECT VERSION()");

        $toDbVersion = $this->productionDb->get_var("SELECT VERSION()");

 
        if (version_compare($fromDbVersion, $toDbVersion) == 0) {
            return $sqlQuery;
        }

 
        if (version_compare($toDbVersion, '5.6', '<')) {
            $sqlQuery = str_replace('utf8mb4_unicode_520_ci', 'utf8mb4_unicode_ci', $sqlQuery);
            $sqlQuery = str_replace('utf8_unicode_520_ci', 'utf8_unicode_ci', $sqlQuery);
        }

        return $sqlQuery;
    }







    private function getCreateStatement($tableName)
    {
        $row = $this->stagingDb->get_results("SHOW CREATE TABLE `$tableName`", ARRAY_A);

 
        if (isset($row[0]['Create Table'])) {
            return $row[0]['Create Table'];
        }

        return [];
    }




    private function finishStep()
    {
 
        if ($this->options->job->total > $this->options->job->start) {
            return false;
        }

 
        $this->options->clonedTables[] = $this->options->tables[$this->options->currentStep];

 
        $this->options->job = new \stdClass();

        return true;
    }





    private function dropTable($destTableName)
    {
        $srcTableName = $this->productionDb->get_var($this->productionDb->prepare("SHOW TABLES LIKE %s", $destTableName));

        if (!$this->shouldDropTable($destTableName, $srcTableName)) {
            return;
        }

        $this->log("DB tmp table: $destTableName already exists, dropping it first");
        $this->productionDb->query("DROP TABLE `$destTableName`");
    }







    private function shouldDropTable($destTableName, $srcTableName)
    {
        return (
            $srcTableName == $destTableName &&
            (
                !isset($this->options->job->current) ||
                !isset($this->options->job->start) ||
                $this->options->job->start == 0
            )
        );
    }
}
