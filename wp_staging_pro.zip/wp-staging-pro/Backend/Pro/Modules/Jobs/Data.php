<?php

namespace WPStaging\Backend\Pro\Modules\Jobs;

use WPStaging\Backend\Modules\Jobs\Job;
use WPStaging\Framework\CloningProcess\Data\Job as DataJob;
use WPStaging\Pro\Push\Data\PreserveBlogPublicSettings;
use WPStaging\Pro\Push\Data\PreserveHomeSiteURL;
use WPStaging\Pro\Push\Data\PreserveOptions;
use WPStaging\Pro\Push\Data\PreservePermalinkStructure;
use WPStaging\Pro\Push\Data\PreserveSessionTokenUserMetaTable;
use WPStaging\Pro\Push\Data\PreserveWPStagingInfo;
use WPStaging\Pro\Push\Data\PreserveWPStagingProVersion;
use WPStaging\Pro\Push\Data\RemoveStagingOptions;
use WPStaging\Pro\Push\Data\UpdateActivePluginsOptionsTable;
use WPStaging\Pro\Push\Data\UpdateDomainPathBlogsTable;
use WPStaging\Pro\Push\Data\UpdateDomainPathSiteTable;
use WPStaging\Pro\Push\Data\UpdatePrefixOptionsTable;
use WPStaging\Pro\Push\Data\UpdatePrefixUserMetaTable;
use WPStaging\Pro\Push\Data\CleanupTemporaryLogins;





class Data extends DataJob
{



    public function initialize()
    {
        parent::initialize();

        $this->options->destinationDir = '';
        $this->options->mainJob = Job::PUSH;
        $this->tables = [];
    }

    protected function initializeSteps()
    {
        $this->steps = [
            PreserveWPStagingInfo::class, 
            UpdatePrefixOptionsTable::class, 
            UpdatePrefixUserMetaTable::class, 
            UpdateActivePluginsOptionsTable::class, 
            PreserveSessionTokenUserMetaTable::class, 
            PreservePermalinkStructure::class, 
            PreserveHomeSiteURL::class, 
            PreserveWPStagingProVersion::class, 
            PreserveBlogPublicSettings::class, 
            PreserveOptions::class, 
            RemoveStagingOptions::class, 
            CleanupTemporaryLogins::class, 
        ];

        if ($this->isNetworkClone()) {
            $this->steps[] = UpdateDomainPathSiteTable::class; 
            $this->steps[] = UpdateDomainPathBlogsTable::class; 
        }
    }





    protected function calculateTotalSteps()
    {
        $this->options->totalSteps = 12;

        if ($this->isNetworkClone()) {
            $this->options->totalSteps = 14;
        }
    }





    protected function isFinished()
    {
        return
            $this->options->currentStep > $this->options->totalSteps ||
            $this->options->currentStep >= count($this->steps);
    }

    protected function getTables()
    {
        $this->tables = [];
    }
}
