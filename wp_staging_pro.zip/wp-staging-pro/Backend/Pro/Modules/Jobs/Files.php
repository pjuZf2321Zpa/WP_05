<?php

namespace WPStaging\Backend\Pro\Modules\Jobs;

use RuntimeException;
use WPStaging\Core\Utils\Logger;
use WPStaging\Backend\Modules\Jobs\JobExecutable;
use WPStaging\Backend\Modules\Jobs\Cleaners\WpContentCleaner;
use WPStaging\Backend\Pro\Modules\Jobs\Copiers\PluginsCopier;
use WPStaging\Backend\Pro\Modules\Jobs\Copiers\ThemesCopier;
use WPStaging\Backend\Pro\Modules\Jobs\Backups\BackupUploadsDir;
use WPStaging\Core\WPStaging;
use WPStaging\Framework\Filesystem\FileObject;
use WPStaging\Framework\Filesystem\Filesystem;
use WPStaging\Framework\Filesystem\PathIdentifier;
use WPStaging\Framework\Filesystem\Permissions;
use WPStaging\Framework\SiteInfo;
use WPStaging\Framework\Utils\Cache\Cache;
use WPStaging\Framework\Utils\Strings;
use WPStaging\Framework\Utils\WpDefaultDirectories;








class Files extends JobExecutable
{
 
    private $file;






    protected $maxFilesPerRun;




    private $permissions;




    private $filesystem;

 
    private $pathAdapter;

 
    private $wpDefaultDirectories;

 
    private $siteInfo;




    private $stagingPath;






    public function initialize()
    {
        $this->permissions = new Permissions();
 
        $this->filesystem  = WPStaging::make(Filesystem::class);
        $this->pathAdapter = WPStaging::make(PathIdentifier::class);
        $this->siteInfo    = WPStaging::make(SiteInfo::class);
        $this->wpDefaultDirectories = WPStaging::make(WpDefaultDirectories::class);

        if (empty($this->options->clone)) {
            $this->returnException('Fatal Error: Files - Can not detect staging site sub folder');
        }

        $this->stagingPath = $this->filesystem->normalizePath($this->options->path, true);

        $filePath = $this->getFilesIndexCacheFilePath();

        if (is_file($filePath)) {
            $this->file = new FileObject($filePath, 'r');
        } elseif ($this->options->totalFiles !== 0) {
            $this->returnException(sprintf('Fatal Error: Files - File: %s is missing! Either the file was deleted after directory scanning or there is a permission issue in the file system.', $filePath));
        }

 
 
        if ($this->options->currentStep === 1) {
            $this->log("Files: Copying files...");
        }

        $this->settings->batchSize = $this->settings->batchSize * 1000000;
        $this->maxFilesPerRun = ($this->settings->cpuLoad === 'low') ? $this->settings->fileLimit : 1;

 
        if ($this->isFinished()) {
            $this->prepareResponse(true, false);
            return false;
        }
    }





    protected function calculateTotalSteps()
    {
 
        $this->options->totalSteps = ceil($this->options->totalFiles / $this->maxFilesPerRun) + 1;
    }






    protected function execute()
    {
        if ($this->isFinished() && !empty($this->options->failedFiles)) {
            $this->stopPushForFailedFiles();
        }

        if ($this->isFinished()) {
 
            $pluginsCopier = WPStaging::make(PluginsCopier::class);
            $themesCopier  = WPStaging::make(ThemesCopier::class);
            $this->log('Files: Copying plugins...');
            $pluginsCopier->copy();

            foreach ($pluginsCopier->getErrors() as $error) {
                $this->log($error, Logger::TYPE_ERROR);
            }

            $this->log('Files: Copying themes...');
            $themesCopier->copy();
            foreach ($themesCopier->getErrors() as $error) {
                $this->log($error, Logger::TYPE_ERROR);
            }

            $this->log('Files: Copy process finished. Continue next step...');
            $this->prepareResponse(true, false);
            return false;
        }

 
        if (!$this->backupWpContent()) {
            $this->prepareResponse(false, false);
            return false;
        }

 
        if (!$this->getFilesAndCopy()) {
            $this->prepareResponse(false, false);
            return false;
        }

 
        $this->prepareResponse();

 
        return true;
    }




    private function backupWpContent()
    {
        if ($this->options->currentStep !== 0) {
            return true;
        }

        $this->cleanupCopierLeftoversOncePerPush();

 
        $backupUploads = new BackupUploadsDir($this);
        $contentCleaner = new WpContentCleaner($this);

        $result = $backupUploads->backupWpUploadsDir();
        foreach ($backupUploads->getLogs() as $log) {
            if ($log['type'] === Logger::TYPE_ERROR) {
                $this->log($log['msg'], $log['type']);
            } else {
                $this->debugLog($log['msg'], $log['type']);
            }
        }

        if (!$result) {
            return false;
        }

        $result = $contentCleaner->tryCleanWpContent(ABSPATH);
        foreach ($contentCleaner->getLogs() as $log) {
            if ($log['type'] === Logger::TYPE_ERROR) {
                $this->log($log['msg'], $log['type']);
                $this->returnException($log['msg']);
            } else {
                $this->debugLog($log['msg'], $log['type']);
            }
        }

        if (!$result) {
            return false;
        }

        return true;
    }






    private function cleanupCopierLeftoversOncePerPush()
    {
        if (($this->options->statusCopierCleanup ?? '') === 'finished') {
            return;
        }

 
        $pluginsCopier = WPStaging::make(PluginsCopier::class);
        $themesCopier  = WPStaging::make(ThemesCopier::class);

        $this->debugLog('Files: Cleaning leftover wpstg-tmp-* and wpstg-bak-* of plugins...');
        $pluginsCopier->cleanup();
        foreach ($pluginsCopier->getErrors() as $error) {
            $this->log($error, Logger::TYPE_ERROR);
        }

        $this->debugLog('Files: Cleaning leftover wpstg-tmp-* and wpstg-bak-* of themes...');
        $themesCopier->cleanup();
        foreach ($themesCopier->getErrors() as $error) {
            $this->log($error, Logger::TYPE_ERROR);
        }

        $this->options->statusCopierCleanup = 'finished';
        $this->saveOptions();
    }





    private function getFilesAndCopy()
    {
        if ($this->options->currentStep === 0) {
            return true;
        }

        if ($this->isOverThreshold()) {
            $this->prepareResponse(false, false);
            $this->saveOptions();
            return false;
        }

        if (isset($this->options->copiedFiles) && $this->options->copiedFiles != 0) {
            $this->file->seek($this->options->copiedFiles + 1); 
        } else {
 
            $this->file->seek(1);
        }

        $this->file->setFlags(FileObject::DROP_NEW_LINE);

        for ($i = 0; $i < $this->maxFilesPerRun; $i++) {
            if ($this->file->eof()) {
                break;
            }

            $file = trim($this->file->readAndMoveNext());

 
            if ($file === trim(Cache::PHP_HEADER)) {
                continue;
            }

            if (empty($file)) {
                continue;
            }

            if (!$this->copyFile($file)) {
                $this->options->failedFiles++;
            }

            $this->options->copiedFiles++;
        }

        if ($this->options->copiedFiles % 50 == 0) {
            $this->log(sprintf('Total %s files processed', $this->options->copiedFiles));
        }

        return true;
    }





    private function isFinished()
    {
        if (
            $this->options->totalSteps == 1 ||
            $this->options->currentStep > $this->options->totalSteps ||
            $this->options->copiedFiles >= $this->options->totalFiles
        ) {
            return true;
        }

        return false;
    }






    protected function copyFile($file)
    {
        $identifier = $this->pathAdapter->getIdentifierFromPath($file);
        $file       = $this->pathAdapter->getPathWithoutIdentifier($file);
 
        if ($file === '') {
            return true;
        }

        $filePath   = $this->getStagingPathByIdentifier($identifier, $file);
        $fullPath   = $this->filesystem->maybeNormalizePath($filePath);
        $directory  = dirname($fullPath);

 
        if ($this->isDirectoryExcluded($directory)) {
            $this->debugLog("Files: Skipping file/directory by rule: {$fullPath}", Logger::TYPE_INFO);
            return true;
        }

 
        if (!is_file($fullPath) && !is_dir($fullPath)) {
            $this->debugLog("Not a file {$fullPath}");
            return true;
        }

 
        if (!$this->filesystem->isReadableFile($fullPath)) {
            $this->log("Can't read file {$fullPath}", Logger::TYPE_WARNING);
            return true;
        }

 
        if ($this->filesystem->isFilenameExcluded($fullPath, $this->options->excludedFiles)) {
            $this->debugLog("Files: Skipping file by rule: {$fullPath}", Logger::TYPE_INFO);
            return true;
        }

 
        $fileSize = filesize($fullPath);

 
        if ($fileSize >= $this->settings->maxFileSize * 1000000) {
            $this->debugLog("Files: Skipping big file: {$fullPath}", Logger::TYPE_INFO);
            return true;
        }

 
        if (($destination = $this->getDestination($identifier, $file)) === false) {
            $this->log("Files: Can't get the destination of {$fullPath}", Logger::TYPE_WARNING);
            return false;
        }

 
        if ($fileSize >= $this->settings->batchSize) {
            if ($this->copyBig($fullPath, $destination, $this->settings->batchSize)) {
                return true;
            }

            $this->log("Files: Can not copy {$fullPath}", Logger::TYPE_ERROR);
            return false;
        }

 
        try {
            $isCopied = is_dir($fullPath) ? $this->copyDirectory($fullPath, $destination) : $this->filesystem->copyFile($fullPath, $destination);
        } catch (RuntimeException $ex) {
            $this->log('Files: ' . $ex->getMessage(), Logger::TYPE_ERROR);
            return false;
        }

        if (!$isCopied) {
            $this->log("Files: Can not copy {$fullPath}", Logger::TYPE_ERROR);
            return false;
        }

        if (!$this->isMultisiteAndPro()) {
            if (is_file($destination)) {
 
                @chmod($destination, $this->permissions->getFilePermission($destination));
            }




            $this->setDirPermissions($destination);
        }

        $this->debugLog('Files: Copy file ' . $fullPath, Logger::TYPE_DEBUG);

        return true;
    }







    private function copyDirectory(string $directory, string $destination): bool
    {
        $sourceDirectory = is_link($directory) ? realpath($directory) : $directory;
        return $sourceDirectory !== false && $this->filesystem->copy($sourceDirectory, $destination);
    }









    private function setDirPermissions($file)
    {
        $dir = dirname($file);
        if (is_dir($dir)) {
            @chmod($dir, $this->permissions->getDirectoryOctal());
        }

        return false;
    }







    private function getStagingPathByIdentifier($identifier, $file)
    {
        if ($this->siteInfo->isWpContentOutsideAbspath()) {
            $source = trailingslashit($this->stagingPath) . ltrim($this->wpDefaultDirectories->getDefaultDirectoryByIdentifier($identifier), '/');

            return trailingslashit($source) . $file;
        }

        $fullPath = $this->pathAdapter->transformIdentifiableToPath($identifier . $file);

        return trailingslashit($this->stagingPath) . str_replace(trailingslashit(wp_normalize_path(ABSPATH)), '', wp_normalize_path($fullPath));
    }








    protected function getDestination($identifier, $file)
    {
        if ($this->pathAdapter->hasPathTraversal($identifier . $file)) {
            $this->log("Files: Refusing an unsafe destination path: {$file}", Logger::TYPE_ERROR);
            return false;
        }

        $destinationPath = $this->pathAdapter->transformIdentifiableToPath($identifier . $file);

 
        if ($this->options->deletePluginsAndThemes === false) {
            $destinationPath = $this->filesystem->tmpDestinationPath($destinationPath);
        }

        $destinationPath = $this->filesystem->normalizePath($destinationPath);

 
 
        $isWithinOwnRoot   = $this->pathAdapter->isPathWithinRoot($destinationPath, $this->pathAdapter->getAbsolutePath($identifier));
        $isWithinWpContent = $this->pathAdapter->isPathWithinRoot($destinationPath, $this->pathAdapter->getAbsolutePath(PathIdentifier::IDENTIFIER_WP_CONTENT));
        if (!$isWithinOwnRoot && !$isWithinWpContent) {
            $this->log("Files: Refusing to write outside the production root: {$destinationPath}", Logger::TYPE_ERROR);
            return false;
        }

        $destinationDirectory = dirname($destinationPath);

        if (!is_dir($destinationDirectory) && !$this->filesystem->mkdir($destinationDirectory)) {
            $this->log("Files: Can not create directory {$destinationDirectory}", Logger::TYPE_ERROR);
            return false;
        }

        return $destinationPath;
    }








    private function copyBig($src, $dst, $buffersize)
    {
        $src = fopen($src, 'rb');
        $dest = fopen($dst, 'wb');

        if (!$src || !$dest) {
            return false;
        }

        $isCopied = true;
        while ($isCopied && !feof($src)) {
            $chunk    = fread($src, $buffersize);
            $isCopied = $chunk !== false && fwrite($dest, $chunk) === strlen($chunk);
        }

        fclose($src);
        fclose($dest);
        return $isCopied;
    }





    private function stopPushForFailedFiles()
    {
        WPStaging::make(PluginsCopier::class)->cleanup();
        WPStaging::make(ThemesCopier::class)->cleanup();

        $message = sprintf(
            /* translators: %d: number of files that could not be copied */
            _n(
                '%d selected file could not be copied to the production site. The push stopped before the database step. Some copied files may already be on the production site. The log lists the affected file.',
                '%d selected files could not be copied to the production site. The push stopped before the database step. Some copied files may already be on the production site. The log lists the affected files.',
                $this->options->failedFiles,
                'wp-staging'
            ),
            $this->options->failedFiles
        );

        $keptUploadsBackup = $this->options->statusBackupUploadsDir === 'finished' ? (new BackupUploadsDir($this))->keepBackupForNextPush() : '';
        if ($keptUploadsBackup !== '') {
            /* translators: %s: folder holding the production uploads from before the push */
            $message .= ' ' . sprintf(__('The production uploads from before the push are kept in %s, and the next push keeps them there.', 'wp-staging'), $keptUploadsBackup);
        }

        $this->log('Files: ' . $message, Logger::TYPE_ERROR);
        $this->returnException($message);
    }








    private function sanitizeDirectorySeparator($path)
    {
        return (new Strings())->sanitizeDirectorySeparator($path);
    }






    private function isDirectoryExcluded($directory)
    {
        if (WPStaging::isWindowsOs()) {
            return $this->strUtil->isPathInsideAnyIgnoringCase($directory, $this->options->excludedDirectories);
        }

        $directory = $this->sanitizeDirectorySeparator($directory);
        foreach ($this->options->excludedDirectories as $excludedDirectory) {
            $excludedDirectory = $this->sanitizeDirectorySeparator($excludedDirectory);
            if (strpos(trailingslashit($directory), trailingslashit($excludedDirectory)) === 0) {
                return true;
            }
        }

        return false;
    }
}
