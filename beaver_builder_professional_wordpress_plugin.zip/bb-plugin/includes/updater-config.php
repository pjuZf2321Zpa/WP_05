<?php

if ( class_exists( 'FLUpdater' ) ) {
	FLUpdater::add_product(array(
		'name'    => 'Beaver Builder Plugin (Pro Version)',
		'version' => '2.11.2.1',
		'slug'    => 'bb-plugin',
		'type'    => 'plugin',
	));
}
