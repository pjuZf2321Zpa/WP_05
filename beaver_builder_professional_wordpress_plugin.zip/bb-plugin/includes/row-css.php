<?php
// Text Color
FLBuilderCSS::responsive_rule( array(
	'settings'     => $settings,
	'setting_name' => 'text_color',
	'selector'     => ".fl-node-$id",
	'prop'         => 'color',
) );

$has_text_color = ! empty( $settings->text_color ) || ! empty( $settings->text_color_large ) || ! empty( $settings->text_color_medium ) || ! empty( $settings->text_color_responsive );

FLBuilderCSS::rule( array(
	'selector' => ":where(.fl-builder-content .fl-node-$id *:not(input):not(textarea):not(select):not(a):not(.fl-menu-mobile-toggle))",
	'enabled'  => $has_text_color,
	'props'    => array( 'color' => 'inherit' ),
) );
?>

<?php
// Link Color
FLBuilderCSS::responsive_rule( array(
	'settings'     => $settings,
	'setting_name' => 'link_color',
	'selector'     => ".fl-builder-content .fl-node-$id :where(.fl-row-content-wrap) a",
	'prop'         => 'color',
) );

// Link Color - text_color fallback when no link_color set
FLBuilderCSS::rule( array(
	'selector' => ".fl-builder-content .fl-node-$id a",
	'enabled'  => empty( $settings->link_color ) && ! empty( $settings->text_color ),
	'props'    => array( 'color' => $settings->text_color ),
) );
?>

<?php
// Link Hover Color — text_color < link_color < hover_color via source order
FLBuilderCSS::responsive_rule( array(
	'settings'     => $settings,
	'setting_name' => 'text_color',
	'selector'     => ".fl-builder-content .fl-node-$id :where(.fl-row-content-wrap) a:hover",
	'prop'         => 'color',
) );

FLBuilderCSS::responsive_rule( array(
	'settings'     => $settings,
	'setting_name' => 'link_color',
	'selector'     => ".fl-builder-content .fl-node-$id :where(.fl-row-content-wrap) a:hover",
	'prop'         => 'color',
) );

FLBuilderCSS::responsive_rule( array(
	'settings'     => $settings,
	'setting_name' => 'hover_color',
	'selector'     => ".fl-builder-content .fl-node-$id :where(.fl-row-content-wrap) a:hover",
	'prop'         => 'color',
) );
?>

<?php
// Heading Color
$heading_selectors = array(
	".fl-builder-content .fl-node-$id h1",
	".fl-builder-content .fl-node-$id h2",
	".fl-builder-content .fl-node-$id h3",
	".fl-builder-content .fl-node-$id h4",
	".fl-builder-content .fl-node-$id h5",
	".fl-builder-content .fl-node-$id h6",
	".fl-builder-content .fl-node-$id h1 a",
	".fl-builder-content .fl-node-$id h2 a",
	".fl-builder-content .fl-node-$id h3 a",
	".fl-builder-content .fl-node-$id h4 a",
	".fl-builder-content .fl-node-$id h5 a",
	".fl-builder-content .fl-node-$id h6 a",
);

// Text Color applied to headings (heading_color overrides via source order)
FLBuilderCSS::responsive_rule( array(
	'settings'     => $settings,
	'setting_name' => 'text_color',
	'selector'     => $heading_selectors,
	'prop'         => 'color',
) );

FLBuilderCSS::responsive_rule( array(
	'settings'     => $settings,
	'setting_name' => 'heading_color',
	'selector'     => $heading_selectors,
	'prop'         => 'color',
) );

// Link color overrides heading color for links within headings
$heading_link_selectors = array(
	".fl-builder-content .fl-node-$id h1 a",
	".fl-builder-content .fl-node-$id h2 a",
	".fl-builder-content .fl-node-$id h3 a",
	".fl-builder-content .fl-node-$id h4 a",
	".fl-builder-content .fl-node-$id h5 a",
	".fl-builder-content .fl-node-$id h6 a",
);

FLBuilderCSS::responsive_rule( array(
	'settings'     => $settings,
	'setting_name' => 'link_color',
	'selector'     => $heading_link_selectors,
	'prop'         => 'color',
) );

FLBuilderCSS::responsive_rule( array(
	'settings'     => $settings,
	'setting_name' => 'hover_color',
	'selector'     => array_map( fn( $s ) => $s . ':hover', $heading_link_selectors ),
	'prop'         => 'color',
) );
?>

<?php if ( 'yes' === $row->settings->bg_video_play_pause ) : ?>
.fl-node-<?php echo $row->node; ?> .fl-bg-video-play-pause {
	cursor: pointer;
	position: absolute;
	bottom: 20px;
	left: 20px;
	z-index: 5;
	width: 18px;
}
.fl-node-<?php echo $row->node; ?> .fl-bg-video-play-pause-control {
	font-size: 18px;
}
<?php endif; ?>

<?php if ( 'yes' === $row->settings->bg_video_audio ) : ?>
.fl-node-<?php echo $row->node; ?> .fl-bg-video-audio {
	display: none;
	cursor: pointer;
	position: absolute;
	bottom: 20px;
	right: 20px;
	z-index: 5;
	width: 20px;
}
.fl-node-<?php echo $row->node; ?> .fl-bg-video-audio .fl-audio-control {
	font-size: 20px;
}
.fl-node-<?php echo $row->node; ?> .fl-bg-video-audio .fa-times {
	font-size: 10px;
	vertical-align: middle;
	position: absolute;
	top: 5px;
	left: 11px;
	bottom: 0;
}
<?php endif; ?>

<?php

// Background Color
FLBuilderCSS::responsive_rule( array(
	'settings'     => $settings,
	'setting_name' => 'bg_color',
	'selector'     => ".fl-node-$id > .fl-row-content-wrap",
	'enabled'      => array( 'bg_type' => array( 'color', 'photo', 'parallax', 'slideshow', 'video' ) ),
	'prop'         => 'background-color',
) );

// Background Gradient
FLBuilderCSS::rule( array(
	'selector' => ".fl-node-$id > .fl-row-content-wrap",
	'enabled'  => 'gradient' === $settings->bg_type,
	'media'    => 'default',
	'props'    => array(
		'background-image' => FLBuilderColor::gradient( $settings->bg_gradient ),
	),
) );

FLBuilderCSS::rule( array(
	'selector' => ".fl-node-$id > .fl-row-content-wrap",
	'enabled'  => 'gradient' === $settings->bg_type && ! empty( $settings->bg_gradient_large ) && isset( $settings->bg_gradient_large['colors'] ) && is_array( $settings->bg_gradient_large['colors'] ) && ! empty( array_filter( $settings->bg_gradient_large['colors'] ) ),
	'media'    => 'large',
	'props'    => array(
		'background-image' => FLBuilderColor::gradient( $settings->bg_gradient_large ),
	),
) );

FLBuilderCSS::rule( array(
	'selector' => ".fl-node-$id > .fl-row-content-wrap",
	'enabled'  => 'gradient' === $settings->bg_type && ! empty( $settings->bg_gradient_medium ) && isset( $settings->bg_gradient_medium['colors'] ) && is_array( $settings->bg_gradient_medium['colors'] ) && ! empty( array_filter( $settings->bg_gradient_medium['colors'] ) ),
	'media'    => 'medium',
	'props'    => array(
		'background-image' => FLBuilderColor::gradient( $settings->bg_gradient_medium ),
	),
) );

FLBuilderCSS::rule( array(
	'selector' => ".fl-node-$id > .fl-row-content-wrap",
	'enabled'  => 'gradient' === $settings->bg_type && ! empty( $settings->bg_gradient_responsive ) && isset( $settings->bg_gradient_responsive['colors'] ) && is_array( $settings->bg_gradient_responsive['colors'] ) && ! empty( array_filter( $settings->bg_gradient_responsive['colors'] ) ),
	'media'    => 'responsive',
	'props'    => array(
		'background-image' => FLBuilderColor::gradient( $settings->bg_gradient_responsive ),
	),
) );

// Background Overlay - Default
FLBuilderCSS::rule( array(
	'selector' => ".fl-node-$id > .fl-row-content-wrap:after",
	'enabled'  => 'none' !== $settings->bg_overlay_type && in_array( $settings->bg_type, array( 'photo', 'parallax', 'slideshow', 'video' ) ),
	'props'    => array(
		'background-color' => 'color' === $settings->bg_overlay_type ? $settings->bg_overlay_color : '',
		'background-image' => 'gradient' === $settings->bg_overlay_type ? FLBuilderColor::gradient( $settings->bg_overlay_gradient ) : '',
	),
) );

// Background Overlay - Responsive breakpoints
foreach ( array( 'large', 'medium', 'responsive' ) as $bp ) {
	$suffix = '_' . $bp;
	$type   = empty( $settings->{ 'bg_overlay_type' . $suffix } ) ? '' : $settings->{ 'bg_overlay_type' . $suffix };

	if ( '' === $type ) {
		continue;
	}

	if ( 'none' === $type ) {
		FLBuilderCSS::rule( array(
			'selector' => ".fl-node-$id > .fl-row-content-wrap:after",
			'media'    => $bp,
			'props'    => array(
				'display' => 'none',
			),
		) );
	} else {
		$color_key    = 'bg_overlay_color' . $suffix;
		$gradient_key = 'bg_overlay_gradient' . $suffix;
		$color        = empty( $settings->{ $color_key } ) ? $settings->bg_overlay_color : $settings->{ $color_key };
		$gradient     = empty( $settings->{ $gradient_key } ) ? $settings->bg_overlay_gradient : $settings->{ $gradient_key };

		FLBuilderCSS::rule( array(
			'selector' => ".fl-node-$id > .fl-row-content-wrap:after",
			'enabled'  => in_array( $settings->bg_type, array( 'photo', 'parallax', 'slideshow', 'video' ) ),
			'media'    => $bp,
			'props'    => array(
				'display'          => 'block',
				'background-color' => 'color' === $type ? $color : 'transparent',
				'background-image' => 'gradient' === $type ? FLBuilderColor::gradient( $gradient ) : 'none',
			),
		) );
	}
}

// Vertical Alignment - Responsive breakpoints
$align_selectors  = array(
	".fl-node-$id.fl-row-default-height > .fl-row-content-wrap",
	".fl-node-$id.fl-row-full-height > .fl-row-content-wrap",
	".fl-node-$id.fl-row-custom-height > .fl-row-content-wrap",
);
$align_substitute = array(
	'top'    => 'flex-start',
	'center' => 'center',
	'bottom' => 'flex-end',
);

foreach ( array( 'align-items', 'justify-content' ) as $prop ) {
	FLBuilderCSS::responsive_rule( array(
		'settings'        => $settings,
		'setting_name'    => 'content_alignment',
		'selector'        => $align_selectors,
		'prop'            => $prop,
		'substitute_vals' => $align_substitute,
	) );
}

// Background Photo - Desktop
if ( 'photo' == $row->settings->bg_type ) :
	$row_bg_image_xl = '';

	if ( 'library' == $row->settings->bg_image_source ) {
		$row_bg_image_xl = $row->settings->bg_image_src;
	} elseif ( 'url' == $row->settings->bg_image_source && ! empty( $row->settings->bg_image_url ) ) {
		if ( 'array' == gettype( $row->settings->bg_image_url ) ) {
			$row_bg_image_xl = do_shortcode( $row->settings->bg_image_url['url'] );
		} else {
			$row_bg_image_xl = (string) do_shortcode( $row->settings->bg_image_url );
		}
	}
	if ( 'custom_pos' == $row->settings->bg_position ) {
		$row_bg_position_lg  = empty( $row->settings->bg_x_position ) ? '0' : $row->settings->bg_x_position;
		$row_bg_position_lg .= $row->settings->bg_x_position_unit;
		$row_bg_position_lg .= ' ';
		$row_bg_position_lg .= empty( $row->settings->bg_y_position ) ? '0' : $row->settings->bg_y_position;
		$row_bg_position_lg .= $row->settings->bg_y_position_unit;

	} else {
		$row_bg_position_lg = $row->settings->bg_position;
	}

	FLBuilderCSS::rule( array(
		'selector' => ".fl-node-$id > .fl-row-content-wrap",
		'enabled'  => 'photo' === $settings->bg_type,
		'props'    => array(
			'background-image'      => $row_bg_image_xl,
			'background-repeat'     => $settings->bg_repeat,
			'background-position'   => $row_bg_position_lg,
			'background-attachment' => $settings->bg_attachment,
			'background-size'       => $settings->bg_size,
		),
	) );
endif;

// Background Photo - Large
if ( 'photo' == $row->settings->bg_type ) :
	$row_bg_image_lg = '';

	if ( 'library' == $row->settings->bg_image_source ) {
		$row_bg_image_lg = $row->settings->bg_image_large_src;
	} elseif ( 'url' == $row->settings->bg_image_source && ! empty( $row->settings->bg_image_url ) ) {
		$row_bg_image_lg = $row_bg_image_xl;
	}

	$bg_position_large = '' == $row->settings->bg_position_large ? $row->settings->bg_position : $row->settings->bg_position_large;
	if ( 'custom_pos' == $bg_position_large ) {
		$row_bg_position_lg  = empty( $row->settings->bg_x_position_large ) ? '0' : $row->settings->bg_x_position_large;
		$row_bg_position_lg .= $row->settings->bg_x_position_large_unit;
		$row_bg_position_lg .= ' ';
		$row_bg_position_lg .= empty( $row->settings->bg_y_position_large ) ? '0' : $row->settings->bg_y_position_large;
		$row_bg_position_lg .= $row->settings->bg_y_position_large_unit;
	} else {
		$row_bg_position_lg = $bg_position_large;
	}

	FLBuilderCSS::rule( array(
		'media'    => 'large',
		'selector' => ".fl-node-$id > .fl-row-content-wrap",
		'enabled'  => 'photo' === $settings->bg_type,
		'props'    => array(
			'background-image'      => $row_bg_image_lg,
			'background-repeat'     => $settings->bg_repeat_large,
			'background-position'   => $row_bg_position_lg,
			'background-attachment' => $settings->bg_attachment_large,
			'background-size'       => $settings->bg_size_large,
		),
	) );
endif;

// Background Photo - Medium
if ( 'photo' == $row->settings->bg_type ) :
	$row_bg_image_md = '';

	if ( 'library' == $row->settings->bg_image_source ) {
		$row_bg_image_md = $row->settings->bg_image_medium_src;
	} elseif ( 'url' == $row->settings->bg_image_source && ! empty( $row->settings->bg_image_url ) ) {
		$row_bg_image_md = $row_bg_image_xl;
	}

	$bg_position_medium = '' == $row->settings->bg_position_medium ? $row->settings->bg_position : $row->settings->bg_position_medium;
	if ( 'custom_pos' == $bg_position_medium ) {
		$row_bg_position_md  = empty( $row->settings->bg_x_position_medium ) ? '0' : $row->settings->bg_x_position_medium;
		$row_bg_position_md .= $row->settings->bg_x_position_medium_unit;
		$row_bg_position_md .= ' ';
		$row_bg_position_md .= empty( $row->settings->bg_y_position_medium ) ? '0' : $row->settings->bg_y_position_medium;
		$row_bg_position_md .= $row->settings->bg_y_position_medium_unit;

	} else {
		$row_bg_position_md = $bg_position_medium;
	}

	FLBuilderCSS::rule( array(
		'media'    => 'medium',
		'selector' => ".fl-node-$id > .fl-row-content-wrap",
		'enabled'  => 'photo' === $settings->bg_type,
		'props'    => array(
			'background-image'      => $row_bg_image_md,
			'background-repeat'     => $settings->bg_repeat_medium,
			'background-position'   => $row_bg_position_md,
			'background-attachment' => $settings->bg_attachment_medium,
			'background-size'       => $settings->bg_size_medium,
		),
	) );
endif;

// Background Photo - Responsive
if ( 'photo' == $row->settings->bg_type ) :
	$row_bg_image_sm = '';

	if ( 'library' == $row->settings->bg_image_source ) {
		$row_bg_image_sm = $row->settings->bg_image_responsive_src;
	} elseif ( 'url' == $row->settings->bg_image_source && ! empty( $row->settings->bg_image_url ) ) {
		$row_bg_image_sm = $row_bg_image_xl;
	}

	$bg_position_responsive = '' == $row->settings->bg_position_responsive ? $row->settings->bg_position : $row->settings->bg_position_responsive;
	if ( 'custom_pos' == $bg_position_responsive ) {
		$row_bg_position_sm  = empty( $row->settings->bg_x_position_responsive ) ? '0' : $row->settings->bg_x_position_responsive;
		$row_bg_position_sm .= $row->settings->bg_x_position_responsive_unit;
		$row_bg_position_sm .= ' ';
		$row_bg_position_sm .= empty( $row->settings->bg_y_position_responsive ) ? '0' : $row->settings->bg_y_position_responsive;
		$row_bg_position_sm .= $row->settings->bg_y_position_responsive_unit;
	} else {
		$row_bg_position_sm = $bg_position_responsive;
	}

	FLBuilderCSS::rule( array(
		'media'    => 'responsive',
		'selector' => ".fl-node-$id > .fl-row-content-wrap",
		'enabled'  => 'photo' === $settings->bg_type,
		'props'    => array(
			'background-image'      => $row_bg_image_sm,
			'background-repeat'     => $settings->bg_repeat_responsive,
			'background-position'   => $row_bg_position_sm,
			'background-attachment' => $settings->bg_attachment_responsive,
			'background-size'       => $settings->bg_size_responsive,
		),
	) );
endif;

// Background Parallax
FLBuilderCSS::rule( array(
	'selector' => ".fl-node-$id > .fl-row-content-wrap",
	'enabled'  => 'parallax' === $settings->bg_type,
	'props'    => array(
		'background-repeat'     => 'no-repeat',
		'background-position'   => 'center center',
		'background-attachment' => 'fixed',
		'background-size'       => 'cover',
	),
) );

FLBuilderCSS::rule( array(
	'selector' => ".fl-builder-mobile .fl-node-$id > .fl-row-content-wrap",
	'enabled'  => 'parallax' === $settings->bg_type && ! empty( $settings->bg_parallax_image_src ),
	'props'    => array(
		'background-image'      => $settings->bg_parallax_image_src,
		'background-position'   => 'center center',
		'background-attachment' => 'scroll',
	),
) );

// Parallax BG Medium
FLBuilderCSS::rule( array(
	'media'    => 'medium',
	'selector' => ".fl-builder-mobile .fl-node-$id > .fl-row-content-wrap",
	'enabled'  => 'parallax' === $settings->bg_type && ! empty( $settings->bg_parallax_image_medium_src ),
	'props'    => array(
		'background-image'      => $settings->bg_parallax_image_medium_src,
		'background-position'   => 'center center',
		'background-attachment' => 'scroll',
	),
) );

// Parallax BG Small
FLBuilderCSS::rule( array(
	'media'    => 'responsive',
	'selector' => ".fl-builder-mobile .fl-node-$id > .fl-row-content-wrap",
	'enabled'  => 'parallax' === $settings->bg_type && ! empty( $settings->bg_parallax_image_responsive_src ),
	'props'    => array(
		'background-image'      => $settings->bg_parallax_image_responsive_src,
		'background-position'   => 'center center',
		'background-attachment' => 'scroll',
	),
) );

// Background Video Fallback
$video_data = FLBuilderUtils::get_video_data( do_shortcode( $settings->bg_video_service_url ) );

FLBuilderCSS::rule( array(
	'selector' => ".fl-node-$id .fl-bg-video",
	'enabled'  => 'video_service' === $settings->bg_video_source && isset( $video_data['type'] ) && 'vimeo' == $video_data['type'] && ! empty( $settings->bg_video_fallback_src ),
	'props'    => array(
		'background-image'      => $settings->bg_video_fallback_src,
		'background-repeat'     => 'no-repeat',
		'background-position'   => 'center center',
		'background-attachment' => 'fixed',
		'background-size'       => 'cover',
	),
) );

// Border
FLBuilderCSS::border_field_rule( array(
	'settings'     => $settings,
	'setting_name' => 'border',
	'selector'     => ".fl-node-$id > .fl-row-content-wrap",
) );

// Min Height
FLBuilderCSS::responsive_rule( array(
	'settings'     => $settings,
	'setting_name' => 'min_height',
	'selector'     => ".fl-node-$id.fl-row-custom-height > .fl-row-content-wrap",
	'prop'         => 'min-height',
	'enabled'      => 'custom' === $settings->full_height,
) );

// Aspect Ratio
FLBuilderCSS::responsive_rule( array(
	'settings'     => $settings,
	'setting_name' => 'aspect_ratio',
	'selector'     => ".fl-node-$id > .fl-row-content-wrap",
	'prop'         => 'aspect-ratio',
) );

// Row Resize - Max Width
if ( isset( $settings->max_content_width ) || isset( $settings->max_content_width_large ) || isset( $settings->max_content_width_medium ) || isset( $settings->max_content_width_responsive ) ) {
	$has_max_width            = ! FLBuilderCSS::is_empty( $settings->max_content_width );
	$has_large_max_width      = isset( $settings->max_content_width_large ) && ! FLBuilderCSS::is_empty( $settings->max_content_width_large );
	$has_medium_max_width     = isset( $settings->max_content_width_medium ) && ! FLBuilderCSS::is_empty( $settings->max_content_width_medium );
	$has_responsive_max_width = isset( $settings->max_content_width_responsive ) && ! FLBuilderCSS::is_empty( $settings->max_content_width_responsive );
	$is_row_fixed             = ( 'fixed' === $settings->width );
	$is_row_content_fixed     = ( 'fixed' === $settings->content_width );
	$are_both_full_width      = ( ! $is_row_fixed && ! $is_row_content_fixed );
	$max_width_selector       = '';

	if ( $is_row_fixed ) {
		$max_width_selector = ".fl-node-$id.fl-row-fixed-width, .fl-node-$id .fl-row-fixed-width";
	} else {
		$max_width_selector = ".fl-node-$id .fl-row-content";
	}

	FLBuilderCSS::rule( array(
		'selector' => $max_width_selector,
		'enabled'  => $has_max_width && ! $are_both_full_width,
		'props'    => array(
			'max-width' => array(
				'value' => $settings->max_content_width,
				'unit'  => FLBuilderCSS::get_unit( 'max_content_width', $settings ),
			),
		),
	) );

	if ( isset( $settings->max_content_width_large ) ) {
		FLBuilderCSS::rule( array(
			'selector' => $max_width_selector,
			'media'    => 'large',
			'enabled'  => $has_large_max_width && ! $are_both_full_width,
			'props'    => array(
				'max-width' => array(
					'value' => $settings->max_content_width_large,
					'unit'  => FLBuilderCSS::get_unit( 'max_content_width_large', $settings ),
				),
			),
		) );
	}

	if ( isset( $settings->max_content_width_medium ) ) {
		FLBuilderCSS::rule( array(
			'selector' => $max_width_selector,
			'media'    => 'medium',
			'enabled'  => $has_medium_max_width && ! $are_both_full_width,
			'props'    => array(
				'max-width' => array(
					'value' => $settings->max_content_width_medium,
					'unit'  => FLBuilderCSS::get_unit( 'max_content_width_medium', $settings ),
				),
			),
		) );
	}

	if ( isset( $settings->max_content_width_responsive ) ) {
		FLBuilderCSS::rule( array(
			'selector' => $max_width_selector,
			'media'    => 'responsive',
			'enabled'  => $has_responsive_max_width && ! $are_both_full_width,
			'props'    => array(
				'max-width' => array(
					'value' => $settings->max_content_width_responsive,
					'unit'  => FLBuilderCSS::get_unit( 'max_content_width_responsive', $settings ),
				),
			),
		) );
	}
}

FLBuilderArt::render_shape_layers_css( $row );

$breakpoints = array( '', 'large', 'medium', 'responsive' );

foreach ( $breakpoints as $breakpoint ) {
	$name    = empty( $breakpoint ) ? 'border' : "border_{$breakpoint}";
	$setting = isset( $settings->{$name} ) ? $settings->{$name} : null;

	if ( ! $setting ) {
		continue;
	}

	$radius = array(
		'top_left'     => (int) ( $setting['radius']['top_left'] ?? 0 ),
		'top_right'    => (int) ( $setting['radius']['top_right'] ?? 0 ),
		'bottom_right' => (int) ( $setting['radius']['bottom_right'] ?? 0 ),
		'bottom_left'  => (int) ( $setting['radius']['bottom_left'] ?? 0 ),
	);

	$width = array(
		'top'    => (int) ( $setting['width']['top'] ?? 0 ),
		'right'  => (int) ( $setting['width']['right'] ?? 0 ),
		'bottom' => (int) ( $setting['width']['bottom'] ?? 0 ),
		'left'   => (int) ( $setting['width']['left'] ?? 0 ),
	);

	$props = array();

	if ( array_filter( $radius ) ) {
		$props['border-top-left-radius']     = sprintf( '%dpx', max( 0, $radius['top_left'] - max( $width['top'], $width['left'] ) ) );
		$props['border-top-right-radius']    = sprintf( '%dpx', max( 0, $radius['top_right'] - max( $width['top'], $width['right'] ) ) );
		$props['border-bottom-right-radius'] = sprintf( '%dpx', max( 0, $radius['bottom_right'] - max( $width['bottom'], $width['right'] ) ) );
		$props['border-bottom-left-radius']  = sprintf( '%dpx', max( 0, $radius['bottom_left'] - max( $width['bottom'], $width['left'] ) ) );

		// Filter out any properties with zero or negative values
		$props = array_filter( $props, function ( $prop ) {
			return (int) $prop > 0;
		} );
	}

	if ( ! empty( $props ) ) {
		FLBuilderCSS::rule(
			array(
				'selector' => array(
					'.fl-node-' . $id . '.fl-row .fl-row-content-wrap .fl-builder-layer',
					'.fl-node-' . $id . '.fl-row-bg-multiple .fl-row-content-wrap .fl-row-content',
					'.fl-node-' . $id . '.fl-row-bg-embed .fl-row-content-wrap .fl-bg-embed-code',
					'.fl-node-' . $id . '.fl-row-bg-slideshow .fl-row-content-wrap .fl-bg-slideshow',
					'.fl-node-' . $id . '.fl-row-bg-video .fl-row-content-wrap .fl-bg-video',
				),
				'media'    => empty( $breakpoint ) ? 'default' : $breakpoint,
				'props'    => $props,
			)
		);
	}
}

if ( ! empty( $settings->full_height ) && ( 'full' == $settings->full_height || 'custom' == $row->settings->full_height ) ) :
	?>
	/* Full Height Rows */
	.fl-node-<?php echo $id; ?>.fl-row-full-height > .fl-row-content-wrap,
	.fl-node-<?php echo $id; ?>.fl-row-custom-height > .fl-row-content-wrap {
		display: -webkit-box;
		display: -webkit-flex;
		display: -ms-flexbox;
		display: flex;
	}
	.fl-node-<?php echo $id; ?>.fl-row-full-height > .fl-row-content-wrap {
		min-height: 100vh;
	}
	.fl-node-<?php echo $id; ?>.fl-row-custom-height > .fl-row-content-wrap {
		min-height: 0;
	}

	.fl-builder-edit .fl-node-<?php echo $id; ?>.fl-row-full-height > .fl-row-content-wrap {
		min-height: calc( 100vh - 48px );
	}

	/* Full height iPad with portrait orientation. */
	@media all and (width: 768px) and (height: 1024px) and (orientation:portrait){
		.fl-node-<?php echo $id; ?>.fl-row-full-height > .fl-row-content-wrap {
			min-height: 1024px;
		}
	}
	/* Full height iPad with landscape orientation. */
	@media all and (width: 1024px) and (height: 768px) and (orientation:landscape){
		.fl-node-<?php echo $id; ?>.fl-row-full-height > .fl-row-content-wrap {
			min-height: 768px;
		}
	}
	/* Full height iPhone 5. You can also target devices with aspect ratio. */
	@media screen and (aspect-ratio: 40/71) {
		.fl-node-<?php echo $id; ?>.fl-row-full-height > .fl-row-content-wrap {
			min-height: 500px;
		}
	}
<?php endif; ?>
