<<?php echo $module->get_posts_container(); ?> <?php $module->render_post_class(); ?><?php FLPostGridModule::print_schema( ' itemscope itemtype="' . FLPostGridModule::schema_itemtype() . '"' ); ?>>

	<?php FLPostGridModule::schema_meta(); ?>
	<?php $module->render_featured_image( array( 'above-title', 'beside', 'beside-right' ) ); ?>

	<?php if ( in_array( $settings->image_position, array( 'above-title', 'beside', 'beside-right' ) ) || ! $module->has_featured_image( array( 'beside-content', 'beside-content-right' ) ) ) : ?>
	<div class="fl-post-feed-text">
	<?php endif; ?>

		<div class="fl-post-feed-header">

			<<?php echo esc_attr( $settings->posts_title_tag ); ?> class="fl-post-feed-title" itemprop="headline">
				<a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a>
			</<?php echo esc_attr( $settings->posts_title_tag ); ?>>

			<?php
			/**
			 * Fires before the post feed meta (author, date, comments) is rendered.
			 *
			 * @since 1.0
			 * @param object $settings Module settings.
			 * @param object $module   The post grid module instance.
			 */
			do_action( 'fl_builder_post_feed_before_meta', $settings, $module );
			?>

			<?php if ( $settings->show_author || $settings->show_date || $settings->show_comments ) : ?>
			<div class="fl-post-feed-meta">
				<?php if ( $settings->show_author ) : ?>
					<span class="fl-post-feed-author">
						<?php

						$author = '<span>' . get_the_author_meta( 'display_name', get_the_author_meta( 'ID' ) ) . '</span>';
						if ( (bool) $settings->link_author ) {
							$author = '<a href="' . get_author_posts_url( get_the_author_meta( 'ID' ) ) . '">' . $author . '</a>';
						}
						printf(
							/* translators: %s: author name */
							_x( 'By %s', '%s stands for author name.', 'fl-builder' ),
							$author
						);

						?>
					</span>
				<?php endif; ?>
				<?php if ( $settings->show_date ) : ?>
					<?php if ( $settings->show_author ) : ?>
						<span class="fl-sep"><?php echo $settings->info_separator; ?></span>
					<?php endif; ?>
					<span class="fl-post-feed-date">
						<?php FLBuilderLoop::post_date( $settings->date_format ); ?>
					</span>
				<?php endif; ?>
				<?php if ( $settings->show_comments ) : ?>
					<?php if ( $settings->show_author || $settings->show_date ) : ?>
						<span class="fl-sep"><?php echo $settings->info_separator; ?></span>
					<?php endif; ?>
					<span class="fl-post-feed-comments">
						<?php comments_popup_link( __( '0 Comments', 'fl-builder' ), __( '1 Comment', 'fl-builder' ), __( '% Comments', 'fl-builder' ) ); ?>
					</span>
				<?php endif; ?>
			</div>
			<?php endif; ?>

			<?php if ( $settings->show_terms && $module->get_post_terms() ) : ?>
			<div class="fl-post-feed-meta-terms">
				<div class="fl-post-feed-terms">
					<span class="fl-terms-label"><?php echo $settings->terms_list_label; ?></span>
					<?php echo $module->get_post_terms(); ?>
				</div>
			</div>
			<?php endif; ?>

			<?php
			/**
			 * Fires after the post feed meta (author, date, comments) is rendered.
			 *
			 * @since 1.0
			 * @param object $settings Module settings.
			 * @param object $module   The post grid module instance.
			 */
			do_action( 'fl_builder_post_feed_after_meta', $settings, $module );
			?>

		</div>

	<?php if ( $module->has_featured_image( 'above' ) ) : ?>
	</div>
	<?php endif; ?>

	<?php $module->render_featured_image( array( 'above', 'beside-content', 'beside-content-right' ) ); ?>

	<?php if ( $module->has_featured_image( array( 'above', 'beside-content', 'beside-content-right' ) ) ) : ?>
	<div class="fl-post-feed-text">
	<?php endif; ?>

		<?php
		/**
		 * Fires before the post feed content (excerpt, more link) is rendered.
		 *
		 * @since 1.0
		 * @param object $settings Module settings.
		 * @param object $module   The post grid module instance.
		 */
		do_action( 'fl_builder_post_feed_before_content', $settings, $module );
		?>

		<?php if ( $settings->show_content || $settings->show_more_link ) : ?>
		<div class="fl-post-feed-content" itemprop="text">
			<?php

			if ( $settings->show_content ) {

				if ( 'full' == $settings->content_type ) {
					$module->render_content();
				} else {
					$module->render_excerpt();
				}
			}

			?>
			<?php
			if ( $settings->show_more_link ) :
				$more_link_context = '<span class="sr-only"> about ' . the_title_attribute( array( 'echo' => false ) ) . '</span>';
				?>
				<a class="fl-post-feed-more" href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" aria-hidden="true" tabindex="-1"><?php echo $settings->more_link_text . $more_link_context; ?></a>
			<?php endif; ?>
		</div>
		<?php endif; ?>

		<?php
		/**
		 * Fires after the post feed content (excerpt, more link) is rendered.
		 *
		 * @since 1.0
		 * @param object $settings Module settings.
		 * @param object $module   The post grid module instance.
		 */
		do_action( 'fl_builder_post_feed_after_content', $settings, $module );
		?>

	</div>

	<div class="fl-clear"></div>
</<?php echo $module->get_posts_container(); ?>>
