<div class="brz-posts__filter-wrapper">
    <ul class="brz-ul brz-posts__filter <?php echo esc_attr($ulClassName);?>">
        <li class="brz-posts__filter__item <?php echo esc_attr($liClassName);?>" data-filter="*" role="button" tabindex="0"><?php echo $allTag;?></li>
	    <?php foreach( $tags as $tag ): ?>
            <li class="brz-posts__filter__item <?php echo esc_attr($liClassName);?>" data-filter="<?php echo esc_attr($tag->slug);?>" role="button" tabindex="0"><?php echo $tag->name;?></li>
	    <?php endforeach; ?>
    </ul>
</div>
