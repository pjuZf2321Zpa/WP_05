<?php
use BrizyPlaceholders\ContentPlaceholder;
use BrizyPlaceholders\ContextInterface;

class BrizyPro_Content_Placeholders_MenuItemActive extends Brizy_Content_Placeholders_Simple
{
	/**
	 * BrizyPro_Content_Placeholders_MenuItemActive constructor.
	 *
	 * @param $label
	 * @param $placeholder
	 */
	public function __construct( $label, $placeholder, $group=null )
	{
		parent::__construct(
			$label,
			$placeholder,
			function ( Brizy_Content_Context $context, ContentPlaceholder $contentPlaceholder ) {
				return $this->getMenuUids( $contentPlaceholder->getAttributes() );
			},
            $group
		);
	}

	/**
	 * @param $attrs
	 *
	 * @return string
	 */
	public function getMenuUids($attrs ) {

		if ( empty( $attrs['menu'] ) ) {
			return '';
		}

		$menu = get_terms( 
			[ 
				'taxonomy'   => 'nav_menu', 
				'meta_key'   => 'brizy_uid', 
				'meta_value' => $attrs['menu'], 
				'fields'     => 'ids' 
			] 
		);

		if ( is_wp_error( $menu ) || count( $menu ) !== 1 ) {
			return '';
		}

		$items = wp_get_nav_menu_items( $menu[0] );

		_wp_menu_item_classes_by_context( $items );

		$allUids = [];
		foreach ( $items as $item ) {
			if ( ! empty( $item->current ) ) {
				$chainUids = $this->collectCurrentChainUids( $item, $items );
				foreach ( $chainUids as $uid ) {
					$allUids[ $uid ] = true;
				}
			}
		}

		return implode( ',', array_keys( $allUids ) );
	}

	/**
	 * Collects UIDs for the current item and all its ancestors (parent chain up to root).
	 *
	 * @param object $item  Current menu item.
	 * @param array  $items All menu items.
	 * @param array  $uids  Accumulated UIDs (current + ancestors).
	 * @return array
	 */
	private function collectCurrentChainUids( $item, $items, $uids = [] ) {
		$uid = get_post_meta( $item->ID, 'brizy_post_uid', true );
		if ( $uid ) {
			$uids[] = $uid;
		}

		if ( empty( $item->menu_item_parent ) ) {
			return $uids;
		}

		foreach ( $items as $parent ) {
			if ( (int) $parent->ID === (int) $item->menu_item_parent ) {
				return $this->collectCurrentChainUids( $parent, $items, $uids );
			}
		}

		return $uids;
	}
}