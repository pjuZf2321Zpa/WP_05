=== Brizy Pro - Page Builder ===
Contributors: themefuse
Tags: brizy, page builder, editor, visual editor, unyson, wysiwyg, landing page, drag-and-drop, design, website builder, landing page builder, front-end builder
Requires at least: 4.5
Tested up to: 7.1.4
Requires PHP: 7.4
Stable tag: 2.8.14
License: To be announced

Extended functionality for the Brizy WordPress builder plugin.
More details on: https://brizy.io

== Changelog ==

= 2.8.14 - 2026-11-11 =
* Fixed: License settings page

= 2.8.13 - 2026-11-02 =
* New: AI page generator settings in White Label
* Improved: Lightbox functionality updated for better compatibility
* Improved: WooCommerce Cart updates correctly on cached pages and the cart panel works more reliably
* Improved: Accessibility for Breadcrumbs, Post Navigation, Pagination, Post Filters, Comments and Cart
* Improved: Brizy Pro now requires PHP 7.4 or newer and shows a notice on older servers
* Fixed: Menu – hover colors now apply correctly to submenu items
* Fixed: Menu – copy and paste actions work correctly for menu items
* Fixed: Mega Menu – opens in the correct position on smaller screens
* Fixed: Global Blocks – icons now display as circles instead of ovals
* Fixed: Posts – pagination settings are preserved after reloading the page
* Fixed: Column – scroll effects now respect element visibility settings
* Fixed: Video Playlist – improved accessibility with descriptive iframe titles
* Fixed: Posts sorting by custom fields

= 2.8.12 - 2026-07-23 =
* Fixed: Header glitch in Safari

= 2.8.11 - 2026-07-20 =
* New: Added configurable default country for phone form fields 
* Improved: Search by post types
* Improved: Added Lazy loading for animated text when loop option is off 
* Fixed: Menu / Header loading 
* Fixed: Gallery in Mega Menu 
* Fixed: Removed Twitter/X element
* Fixed: Link color does not apply for authorized view in Login element 
* Fixed: Inconsistent height of the Phone field in the Form element
* Fixed: Google PageSpeed Insights flags the mobile menu icon
* Fixed: External popup code breaks the site
* Fixed: Start time option does not work correctly for playlist videos

= 2.8.10 - 2026-06-29 =
* New: Tabs now remember the last selected tab in preview

= 2.8.9 - 2026-06-09 =
* New: Pinterest widget
* New: Accessibility improvements for Menu, Accordion, Tabs, Carousel, Counter, Countdown, Progress Bar, Switcher, Button, Map, Image Comparison, Video, Tooltip, Translation, Form, Audio, Flipbox, Login, Video Playlist, Gallery, Popup and Section Slider
* New: Carousel option to disable dynamic content via config
* Fixed: Posts multiselect showing incorrect items
* Fixed: Mega Menu width in preview for static headers
* Fixed: Video lightbox playback issues
* Fixed: Initial editor compilation issues
* Fixed: Incorrect preview positioning for buttons/icons with scroll effects
* Fixed: Extra spacing between words for some fonts
* Fixed: Form capitalize option not working correctly for messages
* Fixed: Menu overflow caused by spacing
* Fixed: ARIA label added for hamburger menu icon
* Fixed: Posts “order by field” for current query
* Fixed: Gallery mask affecting all images instead of one
* Fixed: Reveal timing for Section and Section Header
* Fixed: Sticky header keyboard navigation
* Fixed: Plugin updater


= 2.8.8 - 2026-05-05 =
* Fixed: The delay that caused the menu/header to load after about 1 second

= 2.8.7 - 2026-04-28 =
* Fixed: Deleting Pro elements on free sites causes infinite loading and prevents update

= 2.8.6 - 2026-04-09 =
* Fixed: apply data sanitization across admin view templates


= 2.8.5 - 2026-04-08 =
* Fixed: Phone field in Forms arrow overlap 
* Fixed: Mega-Menu accesibility
* Fixed: Phone field in Forms now works in preview 
* Fixed: Form Thumbnail Not Loading When Importing ZIP Archives

= 2.8.4 - 2026-04-01 =
* New: Accessibility improvements for Carousel element 
* New: Accessibility improvements for Form element
* New: Menu – full accessibility support added
* New: Accessibility improvements for Gallery element 
* New: Accessibility improvements for Video Playlist element
* New: Accessibility improvements for Switcher element
* New: Accessibility improvements for Login element
* New: Accessibility improvements for Flipbox element
* New: Accessibility improvements for Popup
* New: Accessibility improvements for Image Comparison element

= 2.8.3 - 2026-03-19 =
* Fixed: Image gallery crash
* Fixed: Popup is not displaying in the preview

= 2.8.2 - 2026-03-16 =
* Fixed: Form submission button customization

= 2.8.1 - 2026-03-11 =
* New:  Image Comparison element
* New:  Form country code field
* Fixed:  Calculated form field
* Fixed:  Timeline border color
* Fixed:  Mega Menu inside submenu items
* Fixed:  Form reCAPTCHA
* Fixed:  Excerpt typography
* Fixed:  Removed default browser tooltip from menu
* Fixed:  Global block rules
* Fixed:  Mega Menu appearance
* Fixed:  Stories appearance

= 2.8.0 - 2026-03-09 =
* New: AI integration for WordPress

= 2.7.17 - 2026-03-02 =
* Fixed: permission handling on integration account deletion with explicit checks and error message


= 2.7.16 - 2026-02-10 =
* Fixed: Generate global styles bug

= 2.7.15 - 2026-01-22 =
* Fixed: Megamenu in static header is broken

= 2.7.14 - 2026-01-21 =
* New: Chart items now support custom label text
* New: Styling options added for form success and error messages
* Fixed: Terms of agreement now work correctly on login

= 2.7.14 - 2026-01-21 =
* New: Multi-language for Brizy Shops
* New: Chart items now support custom label text
* New: Styling options added for form success and error messages
* Fixed: Terms of agreement now work correctly on login

= 2.7.13 - 2025-12-18 =
* Fixed: Text copy and paste shows editable text in preview

= 2.7.12 - 2025-12-15 =
* New: Posts element includes a random order option
* Fixed: RichText link popup now works correctly with dynamic text
* Fixed: Incorrect number of products or posts in preview resolved

= 2.7.11 - 2025-12-03 =
* Fixed: Richtext does not works correctly for emails

= 2.7.10 - 2025-12-01 =
* Improved: Form – improved toolbar for field editing
* Fixed: Adobe Integration – no longer crashes in the editor
* Fixed: Animated Headline – text prefix now wraps correctly

= 2.7.9 - 2025-11-10 =
* Fixed: Missing label for Search element
* Fixed: Mmenu expands submenu in panel for items without link
* Improved: Placeholder loading performance
* Improved: Popup added possibility to disable "Close Popup" action via config

= 2.7.8 - 2025-10-21 =
* New: Carousel – new arrow and dot styling options
* New: Carousel – added “order by custom field” option for dynamic content
* New: Forms – new calculable form field
* New: Posts – added “order by custom fields” option
* New: SMTP – improved remove SMTP option
* Fixed: Menu – dropdown menu no longer gets overlapped by the lower header block
* Fixed: Form – input fields no longer zoom in on iOS devices
* Fixed: Gallery – filters now work properly in Justified layout
* Fixed: Tooltip – stays within screen bounds on small viewports
* Fixed: Carousel – effects now apply correctly to the last slide

= 2.7.7 - 2025-09-30 =
* New: Global Blocks – confirmation dialog before removing items
* New: Global Blocks – improved handling when removing items
* New: Rules – removed rules are now hidden
* Fixed: Story – styles now render properly in Story mode
* Fixed: Menu – background image can now be set for responsive mode
* Fixed: Menu – submenus now expand correctly for items without links
* Fixed:  WP_Query creation for post loops
* Fixed:  PHP Deprecation warnings

= 2.7.6 - 2025-09-04 =
* New: Forms – option to set predefined default values
* New: Forms – option to display a message for empty required fields
* New: Forms – option to close a popup automatically after form submission
* New: Menu – animated hamburger icon
* Fixed: Fonts – duplicate fonts no longer appear when importing layouts in Cloud
* Fixed: Post Info – removed unnecessary spacing in preview
* Fixed: Menu – context menu works properly inside Mega Menu

= 2.7.5 - 2025-08-26 =
* New: Menu – quickly jump to a menu item directly from the toolbar
* New: Condition Choices – improved search request on filtering
* Fixed: Login – redirect URL now works correctly after logout
* Fixed: PayPal – account option title in toolbar fits properly
* Fixed: Menu – dropdown visible even with only one block on the page
* Fixed: Star Rating – custom icon background now visible
* Fixed: Video – custom video lightbox works correctly
* Fixed: Section Header – extra spacing removed in responsive editor view

= 2.7.3 - 2025-08-11 =
* New: Global Popup “add” prompt now includes search
* New: Increase/decrease zoom buttons in Image Lightbox
* Improved: Dropdown width in population settings
* Improved: PayPal widget – clearer notification text
* Fixed: Flipbox border rendering
* Fixed: Image Gallery – handles duplicate images correctly
* Fixed: Posts element – context menu title consistency
* Fixed: Story – settings option now visible
* Fixed: Featured image display in WordPress left sidebar
* Fixed: Menu – Mega Menu no longer shifts when scrolling
* Fixed: Facebook – updated to handle deprecated Group API
* Fixed: Woo Attributes – element border rendering
* Fixed: Embed – placeholder renders when no height is set
* Fixed: Form – reCAPTCHA position in Story mode

= 2.7.2 - 2025-07-23 =
* Fixed: reverse column
* Fixed: popup trigger once condtion

= 2.7.1 - 2025-07-17 =
* New: Compatibility with Wordpress 6.8.2

= 2.7.0 - 2025-07-15 =
* New: DC Text can be limited to a chosen number of lines
* New: Global Blocks can be renamed directly in the sidebar
* Fixed: WS Form Pro now embeds and submits correctly inside Brizy pages
* Fixed: Global Block Rules – category selector works
* Fixed: Global Block Rules – missing loading indicator when saving
* Fixed: Scroll Animation – scale effect option now functions correctly
* Fixed: Fonts – all Adobe Font weights are available
* Fixed: Menu – hamburger icons display correctly
* Fixed: Story – background DC image shows
* Fixed: Accordion – tag color picker works
* Fixed: DC‑Text – number of lines setting works

= 2.6.14 - 2025-06-10 =
* Improved: Enhanced performance for image resizing.

= 2.6.13 - 2025-05-26 =
* Fixed: Plugin name for WL users.

= 2.6.12 - 2025-05-13 =
* New: Chart element
* Fixed: Rounded corners on video playlists look right in the preview
* Fixed: Social icons use the correct default URL
* Fixed: Webhook names display correctly
* Fixed: Playlist items with only a cover image work on click
* Fixed: Form styles render properly in RTL
* Fixed: Select fields show up in Global Pop-ups
* Fixed: Mega Menu opens from the Hamburger Menu without issues

= 2.6.11 - 2025-04-24 =
* Fixed: Review component fix

= 2.6.10 - 2025-04-17 =
* Fixed: Not all weights in Fonts tab for Adobe Fonts

= 2.6.9 - 2025-03-13 =
* Fixed: Elements not displayed in preview
* Fixed: User with "Editor" role cannot edit page

= 2.6.8 - 2025-02-25 =
* New: Added Linkedin Feed Component
* Fixed: Wrong arrangement of gallery images (masonry layout) at first render
* Fixed: Placeholder is rendered in comment
* Fixed: Custom icons for menu subitems
* Fixed: Form bug unable to set more fields on same row
* Fixed: Flipbox copy and paste styles
* Fixed: Flipbox set background image on Tablet and Mobile

= 2.6.7 - 2025-02-18 =
* Fixed: Gallery with layout justify 

= 2.6.6 - 2025-02-03 =
* Fixed: Issues with recursive menu

= 2.6.5 - 2025-01-30 =
* Fixed: Images cannot be deleted from Media Gallery

= 2.6.4 - 2025-01-15 =
* Improved: Lazy load for Carousel element
* Fixed: Overlapped text on icons on Form and Login elements
* Fixed: Translate status messages in Form element
* Fixed: Instagram element is not loaded when Facebook element persists in page
* Fixed: Radio and Checkbox values are not send to Webhook in Form element
* Fixed: Hover color of custom icon in Menu element
* Fixed: Menu items alignment
* Fixed: Copy and paste styles from dynamic content text to simple text
* Fixed: Alt tag for featured image not working
* Fixed: Carousel dots in responsive mode
* Fixed: Input sanitization 

= 2.6.3 - 2024-12-20 =
* Fixed: Featured image focal point

= 2.6.2 - 2024-12-17 =
* Fixed: Page crash because of adobe fonts
* Fixed: Zapier integration

= 2.6.1 - 2024-11-26 =
* Fixed: Text domain loaded too early

= 2.6.0 - 2024-11-12 =
* New: Added option to set number of columns for Carousel element on mobile 
* New: Add a link to a checkbox in the Form element 
* New: Set width in % and PX for column in Table element 
* New: Instagram Feed element 
* New: Added dotLottie and Media Library 
* Fixed: Scroll Effect (MouseTrack, 3D Title) for PostInfo Element on Tablet/Mobile
* Fixed: Effects panel disappears when an effect is activated 
* Fixed: Header block overlaps the add new block blue icon 
* Fixed: Logout is not Translated 
* Fixed: Gallery light box not working with animations 
* Fixed: Form reCAPTCHA error on disconnect 
* Fixed: Hamburger Menu 

= 2.5.6 - 2024-11-05 =
* Fixed: Polylang compatibilty with  Brizy pages

= 2.5.5 - 2024-10-21 =
* Fixed: PayPal element displaying Brizy branded keywords.

= 2.5.4 - 2024-09-19 =
* Fixed: The flipbox element is not working on Firefox 
* Improved: Adobe Fonts Helper message

= 2.5.3 - 2024-09-18 =
* Fixed: nav_menu_css_class filter parameter count

= 2.5.2 - 2024-09-17 =
* New: Multistep option for the Form element
* New: Flipbox element
* New: Table of Contents element
* New: Adobe Fonts integration
* New: Custom icons upload in Icon element
* New: Transform effects for elements
* New: Features for Lottie element (trigger options, lazy load and more)
* New: Search in Global blocks conditions
* New: Height and Overflow options for Embed element
* New: Ability to change order of rows in Table element
* New: Columns options for Posts element in responsive modes
* Improved: Increase Dynamic Content selection size
* Improved: Moved EmbedCode element to PRO
* Improved: Text decoration underline for Text element with Dynamic Content link
* Improved: Use original name for custom uploaded files
* Fixed: Background video size when persists Lottie
* Fixed: Twitter element has no default type
* Fixed: Close popup button in Image and Icon elements
* Fixed: EmbedCode font size in Story mode
* Fixed: Form select drowdown height
* Fixed: Carousel element change min and max values for speed and stop time
* Fixed: Post content elements typography styles with link
* Fixed: Update Lottie element in story items after changing lottie link
* Fixed: Broken space of Text element when is used DC as block type
* Fixed: Popup conditions (displaying multiple times)
* Fixed: Menu element does not display in category
* Fixed: Form does not work when recaptcha is enabled

= 2.5.1 - 2024-08-01 =
* Fixed: Placeholder terms links

= 2.5.0 - 2024-07-22 =
* Fixed: Rating element bug with tooltip for settings
* Fixed: Bug with align for next post in PostNavigation
* Fixed: Popup close button not showing in some cases
* Fixed: Form margin not showing with radio type option
* Fixed: Popup with MegaMenu z-index bug
* Fixed: Bug when duplicating popups in some instances

= 2.4.38 - 2024-03-26 =
* Fixed: dynamic content

= 2.4.37 - 2024-03-20 =
* Fixed: Breadcrumbs title for non-ascii code
* Fixed: Switcher element cursor not showing pointer
* Fixed: Text element mask with Dynamic Image not working
* Improved: Changed UI for Dynamic population option
* Improved: Text element toolbar closing when changing Dynamic option

= 2.4.36 - 2024-02-13 =
* Fixed: Text color from hex when we have the type transparent
* Fixed: Text Copy and Paste

= 2.4.35 - 2024-02-07 =
* New: Dynamic Image for Video cover
* Improved: Increases rows number for Posts
* Fixed: Stories are not aligned in the middle of the screen
* Fixed: Animated background section when Carousel element is on the page
* Fixed: Unable to set Global Block

= 2.4.34 - 2024-01-17 =
 * New: Add Right Click context Menu to Mega Menu element
 * Improved: Update Integration name Sendinblue to Brevo
 * Improved: AI Options for Text
 * Fixed: Carousel element is not displayed on mobile
 * Fixed: Hover Animation on Icon with link
 * Fixed: Save Trigger condition for popups do not save
 * Fixed: Lottie element crash on non-lottie json upload

= 2.4.33 - 2023-12-19 =
* Improved: Localisation for Login element
* Improved: Localisation for Playlist element
* Improved: Localisation for Gallery tags
* Improved: Localisation for Login element
* Improved: Localisation for Twitter element
* Improved: Localisation for Condition Triggers
* Improved: Localisation for Global Blocks
* Improved: Localisation for Timeline element
* Improved: Localisation for Integrations
* Improved: Localisation for Gallery element
* Fixed: Youtube Shorts link in Playlist

= 2.4.32 - 2023-12-07 =
Improved: Reduce text generation time

= 2.4.31 - 2023-12-05 =
* Fixed: Buttons width in preview
* Fixed: Overlay was visible under gradient color

= 2.4.30 - 2023-12-01 =
* Fixed: Buttons width in preview
* Fixed: Overlay was visible under gradient color

= 2.4.29 - 2023-11-29 =
* New: Close button for hamburger menu
* New: Transition speed for carousel
* New: AI option for Text
* New: Custom column width for table element
* Improved: Optimised code output for the Playlist element
* Improved: Optimised code output for the Timeline element
* Improved: Optimised code output for the Switcher element
* Fixed: Popup conditions dropdown too small
* Fixed: Row and Column items alignment when you set up a scroll effect
* Fixed: Carousel element is zoomed when placed in a block that has background video

= 2.4.26 - 2023-10-20 =
* Fixed: Login element error when try to register

= 2.4.25 - 2023-10-11 =
* Improved: Changed Popup close delay suffix to s instead of px
* Improved: Extended population option with custom attributes
* Improved: Posts columns number for mobile and tablet 
* Fixed: Image gallery empty space when changing column number 
* Fixed: Menu will not open on mobile or tablet inside Section Slider and Carousel 
* Fixed: Toolbar Dynamic Content 
* Fixed: Division by 0 on image resize
* Fixed: Images are not uploading when GoDaddy CDN or Jetpack CDN is configured
* Fixed: Gallery option cannot load images in thumbnails 
* Fixed: Popup styles in preview 
* Fixed: Mega Menu styles in preview 

= 2.4.24 - 2023-07-12 =
* New: Added vertical spacing option for the Timeline element
* New: Mask image for all containers: Headers, Footers
* Fixed: The color gets reset when a dynamic text is linked to its URL
* Fixed: Option Scroll page behind on popups was not working correctly

= 2.4.23 - 2023-06-26 =
* Fixed: MegaMenu dnd
* Fixed: Scrollbar inside Popup

= 2.4.22 - 2023-06-22 =
* Fixed: Section Header container
* Fixed: Section Footer container

= 2.4.21 - 2023-06-21 =
* New: Image Gallery multi upload
* New: Added layout types and aspect ratio options to Image Gallery
* New: Added option to sort tags alphabetically in Gallery
* New: Added new order filter Relevance in Posts element
* New: Added Webhooks integration in the Form element
* Fixed: Popup Scroll when you disable Click outside to close pop-up
* Fixed: Posts Element query
* Fixed: Posts Element custom dynamic image
* Fixed: Sticky Menu on scrolling
* Fixed: Added Typography in mobile and tablet for Product Rating

= 2.4.20 - 2023-06-07 =
* Fixed: Button style fill
* Fixed: IconBox with hover effect

= 2.4.18 - 2023-05-31 =
* Improved: Menu option source 
* Improved: Carousel toolbar when reordering items 
* Improved: Added active color in mobile Menu element
* Improved: Twitter element 
* Improved: Added .min suffix for all css and js minified files 
* Improved: Removed demo.themefuse URLs in Brizy blocks when white label is activated
* Fixed: Dynamic content link 
* Fixed: Dynamic content image in preview 
* Fixed: Click on an image in the Cart element 
* Fixed: Filter and Offset options for Posts element in mobile and tablet 
* Fixed: White label is not working in multisite dashboard

= 2.4.17 - 2023-04-03 =
* Fixed: Sticky Menu scroll 
* Fixed: Mega Menu colors and typography 
* Fixed: Popup removes hardcoded value 300px for width 
* Fixed: Popup in preview 

= 2.4.16 - 2023-03-10 =
* Fixed: Screenshots
* Fixed: Section Background Image

= 2.4.15 - 2023-03-07 =
* New: Preparations for future UI color themes
* Improved: Minified CSS in HTML 
* Improved: Alphabetical sorting for Gallery tags
* Updated: Twitter library 
* Fixed: Excerpt element is saving the font family from the post title
* Fixed: Typography styles for dynamic content in Text element 
* Fixed: Capitalize dynamic content for Text element 
* Fixed: Posts include or exclude query 
* Fixed: Timeline horizontal style in preview
* Fixed: Losing global styling in Text element after refresh
* Fixed: Mobile hamburger menu items scroll bar 
* Fixed: Blurred image in Carousel element
* Fixed: Posts pagination when Blocky theme is activated
* Fixed: Copy style from text to dynamic content 
* Fixed: Copy error when menu is not selected in the Menu element
* Fixed: HubSpot connection: Invalid key
* Fixed: Compatibility with php 8.1 

= 2.4.15 - 2023-03-07 =
* New: Preparations for future UI color themes
* Improved: Minified CSS in HTML 
* Improved: Alphabetical sorting for Gallery tags
* Updated: Twitter library 
* Fixed: Excerpt element is saving the font family from the post title
* Fixed: Typography styles for dynamic content in Text element 
* Fixed: Capitalize dynamic content for Text element 
* Fixed: Posts include or exclude query 
* Fixed: Timeline horizontal style in preview
* Fixed: Losing global styling in Text element after refresh
* Fixed: Mobile hamburger menu items scroll bar 
* Fixed: Blurred image in Carousel element
* Fixed: Posts pagination when Blocky theme is activated
* Fixed: Copy style from text to dynamic content 
* Fixed: Copy error when menu is not selected in the Menu element
* Fixed: HubSpot connection: Invalid key
* Fixed: Compatibility with php 8.1 

= 2.4.14 - 2023-01-31 =
* Fixed: Menu hamburger - items link on responsive mode

= 2.4.13 - 2022-12-26 =
* New: Added stroke option for the Post Title element
* New: Added paddings for the Facebook element
* Improved: Shadow for Header and Footer elements 
* Fixed: Text alignment in the hamburger Menu  
* Fixed: WOO Pages Order Tracking
* Fixed: Popup cookies problems with local-storage
* Fixed: Carousel preview - custom height in responsive mode
* Fixed: Timeline style
* Improved: StickTitle option on hamburger menu was deleted. Now new users always will have non sticky title 
* Improved: Table responsive
* Fixed: The order of woo reviews

= 2.4.12 - 2022-11-17 =
* New: Added width and corner options for the Facebook element 
* New: Added padding options for Facebook, Lottie, Search, VideoPlayList
* New: Added corner option for the Menu element
* Fixed: Breadcrumbs typography 
* Fixed: White space for text in Playlist element 
* Fixed: Button color in the Facebook Comments element 
* Fixed: Custom fonts in Post Info 

= 2.4.11 - 2022-10-27 =
* New: Calendly element
* Improved: Added badge status in global blocks conditions
* Fixed: Post Title
* Fixed: Woo Add To Cart breaks the template
* Fixed: Video doesn't stop when story slide is changed
* Fixed: Header translations
* Fixed: Align center not working in previews for Posts

= 2.4.10 - 2022-10-11 =
* New: Added type Outset to Shadow option for Header and Footer blocks
* Fixed: Twitter height issue
* Fixed: Corner option for the close icon in a popup
* Fixed: Redirect after login incompatibility with WishList Member TM plugin
* Fixed: Table width issue
* Improved: Timeline element options

= 2.4.9 - 2022-10-03 =
* Fixed: Content shift caused by Carousel on page load 

= 2.4.8 - 2022-09-28 =
* Fixed: Mailchimp error on creating new list 
* Fixed: Link to File option was missing in toolbar on Button 
* Fixed: Section Image crop issue in mobile view for Popups
* Fixed: Mobile 100vw width for Mega Menus
* Fixed: Misalignment for Menu arrows in mobile view
* Fixed: Switcher spacing option 
* Fixed: Fatal error happening in is_plugin_active function
* Fixed: Review element is broken in product pages
* Fixed: Fatal error happening with Highend theme

= 2.4.7 - 2022-09-17 =
* New: Text Image mask that works with post and page featured image
* Fixed: Pagination color on hover for Posts element
* Fixed: Post type names were not white label   
* Fixed: Global styles changes in post content
* Fixed: Switcher style two icon active color 
* Fixed: Adding more than one popup in Text element on text links
* Fixed: Menu gradient background
* Fixed: Popup inside Posts Element 
* Fixed: White label - Form apps contained the name Brizy 
* Fixed: Posts context right click menu does not appear 
* Fixed: Table syncing styles between all cells 
* Fixed: Hamburger menu closing if is in Mega Menu 
* Fixed: Menu tab overlaps menu items on scroll
* Fixed: Sticky options on Header element 
* Fixed: Option go to slide in Story on Lottie elements
* Fixed: WooGallery does not change main image 
* Fixed: Popup content vertical alignment
* Fixed: PostExcerpt in Woo Products 
* Fixed: Header type fixed shaking on scroll 
* Fixed: Hamburger menu drawer position in responsive 
* Fixed: Edit static header 
* Fixed: getting global popups 
* Fixed: Mega Menu 100 vw width in responsive modes 
* Fixed: Activate and Deactivate license when all license fields license are empty
* Fixed: Do not load updater hooks on multisite envs, show only in network admin the notice about license
* Improved: Current Query for customers in Posts element
* Improved: The size icons in the Timeline element   
* Improved: Post navigation links  

= 2.4.6 - 2022-08-30 =
* Fixed: RichText with popups

= 2.4.5 - 2022-08-16 =
* Fixed: RichText with popups

= 2.4.4 - 2022-08-09 =
* New: Is activated command for wp-cli 
* Fixed: Error handling for forms
* Fixed: Admin notice in dashboard

= 2.4.3 - 2022-07-20 =
* New: New Templates

= 2.4.2 - 2022-06-15 =
* Fixed:  Check immediately if there is a new version of the pro plugin after we got a new version of the free plugin

= 2.4.1 - 2022-06-02 =
* New: Added background image and gradient to hamburger menu 
* New: In excerpt dynamic content on Text, display only the filled in tags: p, H1, H2, etc
* Fixed: Leave page window when you did not change anything in the page
* Fixed: Feature image on hover did not inherit image from normal state for Menu, Header, Footer, Popup
* Fixed: Rounded corners on Images that are dynamic 
* Fixed: Contact forms in Mega Menu 
* Fixed: Some outline icons did not display in the editor
* Fixed: Dynamic text alignment 
* Fixed: Sidebar for Timeline element in mobile view 
* Fixed: Menu background color hover when you select a global color 

= 2.4.0 - 2022-05-18 =
* New: Added dynamic text population method in the Line element
* New: Added Icons for Switcher element
* New: Added Rating scale option 5 and 10
* New: Added scroll animation Effects funtionality
* New: Added reorder to Gallery element
* New: Added reorder to Timeline element
* New: Added reorder to Playlist element
* New: Added support for placeholders in email templates
* New: Added new Sale element for the WooCommerce builder
* Improved: WooCart variable products label styling
* Improved: Can change name for All tag in Posts element
* Improved: Removed max depth limit for the Menu element
* Improved: Multi tabs for the Facebook element
* Improved: WooCart styling improvements
* Improved: WooAtributes made title come from backend
* Fixed: Hover option for filters on Header and Footer elements
* Fixed: Fonts in the Menu element when you have Twenty Twenty-One WP theme activated
* Fixed: Lottie resize dots
* Fixed: White label default links for Twitter and Facebook
* Fixed: Mobile Menu text when empty
* Fixed: Added horizontal scroll for Table element in responsive views
* Fixed: Hide additional info about the product if there is no data
* Fixed: Editor product gallery
* Fixed: Added all tags in post tag loop
* Fixed: Compiler returns empty array on page styles and scripts

= 2.3.30 - 2022-05-05 =
* Fixed: Hover on menu dropdown
* Fixed: Header and Footer dividers on Firefox

= 2.3.29 - 2022-05-03 =
* Fixed: Hover transition on the play icon in the Playlist element 
* Fixed: Popups screenshots 

= 2.3.28 - 2022-04-21 =
* Fixed: Headers Dividers
* Fixed: Footer Dividers

= 2.3.27 - 2022-04-20 =
* New: Text link to specific story slide 
* Improved: Hover Transition for ImageGallery 
* Improved: Hover Transition for Comments, WOOAddToCart, WOORating
* Improved: Posts in Archive page 
* Improved: RichText with dynamic content 
* Improved: Global color palette performance 
* Improved: Global typography performance 
* Improved: Performance when you remove blocks from the sidebar  
* Fixed: Active color for Image Gallery
* Fixed: Colors and transition for the Video Playlist element
* Fixed: Video with border radius in Safari 
* Fixed: Menu placeholder issue for desktop
* Fixed: Empty license key submitted error
* Fixed: Warning: This plugin has not been tested with your current version of WordPress 

= 2.3.26 - 2022-03-10 =
* New: Show progress on story when autoplay is on
* Updated: Removed loop from story 
* Fixed: Disabled Lottie link for responsive 
* Fixed: Background image for Header blocks with Sticky option on
* Fixed: Posts include and exclude select 

= 2.3.25 - 2022-03-02 =
* New: Add links to any slide in Stories 
* New: Auto slide option for Stories
* Fixed: Prefetching fonts in white label Agency and Reseller plans
* Fixed: Reset password
* Fixed: Added hover state on Back to Login and Register links in the Login element
* Fixed: Loop for VideoPlaylist element

= 2.3.24 - 2022-02-09 =
* New: Stories - added Lottie render option
* Fixed: Timeline element - element spacing bug on mobile
* Fixed: Timeline element - line and border display issues
* Fixed: Buttons and Icons - custom class, ID population
* Fixed: Playlist element - cover image not working

= 2.3.23 - 2022-02-07 =
* Fixed: Restore blog on multisite environments
* New: Added User registration URL placeholder

= 2.3.22 - 2022-02-03 =
* Fixed: Saves scripts relative to the plugin main folder
* Fixed: Get license key in the multisite environments

= 2.3.21 - 2022-01-17 =
* Fixed: Color and align for text element

= 2.3.20 - 2022-01-14 =
* Fixed:  Load One Site License admin notice only on multisite

= 2.3.19 - 2022-01-10 =
* New: Added spacing for text in timeline
* Fixed: Do not opened PromptConditions when make it global on a simple page
* Fixed: Image toolbar with dynamic content
* Fixed: Sanitize the white label prefix
* Fixed:  WPML Menu switcher is missing from Brizy pages

= 2.3.18 - 2021-12-20 =
* New: Archive for title and excerpt
* Fixed: Text gradient in safari

= 2.3.17 - 2021-12-13 =
* Fixed: MegaMenu Drag and Drop 
* Fixed: Popup v1 alignment 
* Fixed: Carousel dots style on 2021 theme
* Fixed: The canonical URL for brizy pagination
* Fixed: Use original URL of the image when featured image is used as background
* Updated: Exclude WP navigation from simple page
* Improved: TranslatePress compatibility for the Menu element 

= 2.3.16 - 2021-11-30 =
* New: 13 Popups design
* New: 8 Layout packs and Landing pages
* Improved: Logout URL with redirect
* New: Added custom context for the Post Title dynamic element
* Fixed: Publish option when you create internal Popups 
* Fixed: Image dynamic content
* Fixed: Active state for Switcher element
* Fixed: Login and Logout redirect 
* Fixed: Saved blocks in white label instance
* Fixed: Sale and price color for WooPrice
* Fixed: Remove undefined index placeholder
* Fixed: Display a notification when the free version is not activated


= 2.3.15 - 2021-11-09 =
* Improved: Changed the default Twitter handle when you added it to the page 
* Improved: Changed icon in toolbar for Navigation 
* Fixed: Regex for some placeholders in Dynamic content 
* Fixed: Carousel sidebar for mobile and tablet 
* Fixed: Gallery sidebar for responsive 
* Fixed: The lines in the timeline element now connect correctly on mobile 
* Fixed: Changed default paragraph text value for Carousel 
* Fixed: Alt attribute for logo on dynamic content
* Fixed: Show and Hide posts title on navigation post on single post

= 2.3.14 - 2021-10-18 =
* Improved: Show display conditions popup on setting a global Block
* Improved: Active tags hover behavior for Posts element 
* Improved: White label options, removed Brizy from custom font upload 
* New: 9 design layout packs
* New: Added categories in Posts element
* Fixed: Story text and images flickering on different devices
* Fixed: Some PRO layouts are displaying in the FREE category 
* Fixed: File upload on Lottie element
* Fixed: Nested Switcher elements 
* Fixed: Styles issues for nested Switcher elements 
* Fixed: Menu element font broken by Twenty Twenty-One theme
* Fixed: UI issues when Dynamic content is larger in toolbar
* Fixed: Mega Menu hover transition
* Fixed: Content alignment when you activate membership options in Footer blocks
* Fixed: Dynamic content value in Countdown element
* Fixed: Close option hover on Image Gallery lightbox
* Fixed: Post loop setup global post on every iteration
* Fixed: Added back the post tags placeholder
* Fixed: Product short description does not work in the products element
* Fixed: Woocommerce Product Bundle plugin failed to open stream
* Fixed: Renamed brizy_dc_post_tags to brizy_dc_post_terms and changed it according to its name

= 2.3.13 - 2021-09-16 =
* Fixed: Shortcodes Element in popup 
* Fixed: Mega Menu preview position
* Fixed: Options toolbar position inside Sticky Header
* Improved: Mega Menu passive events on touch 
* Improved: Page loading speed on preview when you have custom fonts on your page
* Fixed: False positives malware File Found notifications 
* Fixed: Brizy Yoast pagination incompatibility
* Fixed: Post Loop, Pagination, Tags refactoring 
* Fixed: Apply do_shortcode in the post loop on every item 

= 2.3.12 - 2021-09-06 =
* New: Added the Lottie element in Stories 
* Fixed: Text links in Stories 
* Fixed: Placeholder options values for the Post element

= 2.3.11 - 2021-08-26 =
* Fixed: Editor for Internal Popup

= 2.3.10 - 2021-08-24 =
* Fixed: Global popup bug
* Fixed: Icon link in Story
* Fixed: Mega Menu secondary level bug
* Fixed: Hamburger Menu on mobile bug
* Fixed: Mobile menu bug when using Astra theme

= 2.3.8 - 2021-08-17 =
* Improved: White Label, removed keyword Brizy from two places in the code
* Fixed: Global popup
* Fixed: Cache assets on Brizy websites
* Fixed: Fatal error on compile templates for single product

= 2.3.7 - 2021-08-06 =
* Fixed: Assets on preview
* Fixed: Toolset and metabox custom fields

= 2.3.6 - 2021-08-05 =
* Fixed: Composer versions

= 2.3.5 - 2021-08-05 =
* Fixed: Broken WooCommerce Products template in preview

= 2.3.4 - 2021-08-04 =
* New: Added Free stories category in sidebar when you add stories
* New: Added 10 new Layout Packs (Templates)
* Improved: Renamed a couple of Story templates
* Improved: Stories templates global styling, previews, thumbs, etc

= 2.3.3 - 2021-07-26 =
* New: Added icon position option for Menu item
* Improved: Removed submenu lvl limit for the Menu element
* Improved: White label for blocks and layouts syncing popup
* Improved: White label for the default global style name
* Fixed: Adapt Pods placeholder to the latest version of dynamic content
* Fixed: Filters for dynamic images
* Fixed: Submenu styles for the Menu element


= 2.3.2 - 2021-07-23 =
* Fixed: Comments placeholder
* Fixed: Carousel with dynamic content
* Fixed: Empty items in Posts component

= 2.3.1 - 2021-07-20 =
* Fixed: Pods, Metabox and Toolset placeholder providers

= 2.3.0 - 2021-07-19 =
* New: Dynamic Content in editor mode
* New: Added pagination in Archive element
* New: Added reorder option in Carousel
* Improved: Moved password link to type links dynamic content
* Improved: Posts include, exclude filters
* Improved: Login element
* Fixed: Action priority
* Fixed: Changed the behavior for offset attribute in Posts element

= 2.2.13 - 2021-07-13 =
* Fixed: empty breadcrumbs when there are no conditions in the template
* Fixed: translate membership string View as role
* Fixed: show role change only for allowed users

= 2.2.12 - 2021-07-07 =
* Fixed: Menu transparency bug and icon size spacing unit
* Fixed: Login submit button normal color
* Fixed: Custom audio not close automatically
* Fixed: Cart element display total with calculated taxes
* Fixed: Cart element do not ignore the settings of WooCommerce currency position
* Fixed: Login Element - Wrong Password Redirects to standard WP login page
* Fixed: Empty breadcrumbs when the template has the condition for search archive

= 2.2.11 - 2021-05-18 =
* Fixed: Mega menu scrollable

= 2.2.10 - 2021-05-13 =
* Fixed: Mega menu in small viewport
* Fixed: Lightbox blurred image

= 2.2.9 - 2021-04-12 =
* Fixed: Burger Menu scroll with anchor
* Fixed: Global popups in global Block

= 2.2.8 - 2021-04-08 =
* New: Added horizontal align for Table aside and header
* New:  Placeholder for active menu item
* New: Calculate the excerpt for posts edited with Brizy by excluding the header and footer
* Fixed: Show plugins when the white label is enabled
* Fixed: Post content placeholder for posts edited with Gutenberg
* Fixed: Always render comments to HTML5
* Fixed: Align left for Image Gallery element
* Fixed: Hovers for custom Video element
* Fixed: Typography for Menu element
* Fixed: Added href for title in Menu element

= 2.2.7 - 2021-03-23 =
* New:  Placeholder for menu item active
* Fixed: Post content placeholder for posts edited with Gutenberg
* Fixed: Always render comments to HTML5

= 2.2.5 - 2021-02-16 =
* Fixed: Global Popups CSS

= 2.2.4 - 2021-02-04 =
* Fixed: Excerpt component

= 2.2.3 - 2021-02-02 =
* Improved: Code refactoring and optimization
* Fixed: Popups on links within RichText element
* Fixed: Broken URL for uploaded fonts

= 2.2.2 - 2021-01-14 =
* Fixed: Global Popups

= 2.2.1 - 2021-01-12 =
* New: Added margin option in Footer
* Fixed: Lottie in section
* Fixed: Post content line breaks with classic editor
* Fixed: License form for other languages
* Fixed: Pagination refactoring
* Fixed: Posts loop no products with polylang
* Fixed: calculate the excerpt a bit different for posts edited with Brizy


= 2.2.0 - 2020-12-03 =
* New: 14 Pre-made Layouts and Landing pages

= 2.1.3 - 2020-11-13 =
* Fixed: Show editor elements on Product page
* Fixed: Show cart on Woocommerce pages

= 2.1.2 - 2020-11-12 =
* Fixed: PostContent in template

= 2.1.1 - 2020-11-10 =
* Improved: WooRating better color defaults
* Improved: WooCart vertical align option also appears when height is Auto
* Fixed: MegaMenu offset and width options

= 2.1.0 - 2020-11-05 =
* New: Multiple WooCommerce elements
* New: Added shop page option in template rules


= 2.0.9 - 2020-11-03 =
* Fixed: Featured image upload

= 2.0.8 - 2020-10-28 =
* Fixed: MenuPro dropdowns toolbar was missing typography and color options
* Fixed: MenuPro was escaping HTML Entities
* Fixed: Videos inside Switcher element were continuing to play when switching between tabs
* Fixed: Media upload on white label settings page

= 2.0.7 - 2020-10-13 =
* Improved: MegaMenu alignment
* Improved: Integration SDK
* Fixed: Posts element columns were sometimes of different heights

= 2.0.6 - 2020-09-17 =
* Fixed: Show License page if white label is activated and the white label menu is available

= 2.0.5 - 2020-09-11 =
* Improvement: Playlist element
* Fixed: RichText dynamic content wasn't editable in posts
* Fixed: Custom font with white label
* Fixed: Call do_shortcode on every iteration in post loop
* Fixed: Breadcrumbs styles
* Fixed: Remove a warning in white label
* Fixed: Added white label flag in config
* Fixed: Mark all pages to be re-compiled if the white label prefix is changed

= 2.0.4 - 2020-08-19 =
* Fixed: The License page for multi-sites

= 2.0.3 - 2020-08-18 =
* Fixed: Take the license data from main site if the multi-site is enabled
* Fixed: License page
* Fixed: apply the_content filter on component post content

= 2.0.2 - 2020-08-06 =
* Fixed: Table width on Safari
* Fixed: Lightbox in Carousel Element
* Fixed: Carousel refresh when changed tabs on mobile
* Fixed: Archive component

= 2.0.1 - 2020-08-05 =
* Fixed: Archive component

= 2.0.1 - 2020-07-31 =
* Fixed: Archive component

= 2.0 - 2020-07-30 =
* New: Global blocks conditions
* New: Mega Menu builder
* New: Table element
* New: Lottie element
* New: Login element
* New: Post Navigation element
* Improved: Added active color option for the Playlist element
* Improved: Added vertical orientation for the Menu Element
* Improved: Menu padding option for mobile menu items
* Improved: Menu styling options for active menu item
* Improved: Load plugin
* Improved: Styles are added automatically when importing a Layout
* Improved: Custom Email template is now edited with a code editor
* Improved: Dynamic content was partly re written and extended
* Improved: Added option to change the link prefix ?brizy-edit (White Label)
* Improved: Removed any content related to Brizy from the pre made blocks and popups (White Label)
* Improved: Replaced block thumbnails that contained Brizy related content (White Label)
* Improved: Added active state colour for Accordion, Switch, Tabs, Menu, Playlist and Gallery elements
* Improved: Moved submenu license in a new tab in the sub-menu settings
* Improved: Added brizy_form_email_subject filter
* Improved: Added support for placeholders in email subject
* Improved: Styles are added automatically when importing a Layout
* Improved: Custom Email template can now be edited with a code editor
* Fixed: Posts element masonry layout jumping
* Fixed: MMenu z-index for shape
* Fixed: Gallery inside container elements (Tabs, Accordion, Switcher, etc.)
* Fixed: Restricted access for non licensed users
* Fixed: Carousel incorrect width
* Fixed: PostContent bold and italic styles
* Fixed: Encryption values for SMTP integration
* Fixed: Comments skin 1 divider width
* Fixed: Post pagination colour and spacing
* Fixed: Search on multisite installations
* Fixed: Search button corner option
* Fixed: Carousel inside container elements (Tabs, Accordion, Switcher, etc.)
* Fixed: White labeling in query string
* Fixed: Gallery inside container elements (Tabs, Accordion, Switcher, etc.)

= 0.0.41 - 2020-04-25 =
* New: Minor refactoring needed to integrate with new icon system

= 0.0.40 - 2020-04-14 =
* Fixed: Mobile menu now closes when clicking on an anchor link from it
* Fixed: Search Element not appearing in the elements list

= 0.0.39 - 2020-03-27 =
* Fixed: Menu options on mobile

= 0.0.38 - 2020-03-25 =
* Fixed: Check for Brizy Free version

= 0.0.37 - 2020-03-25 =
* New: Comments element (Discuss, WP Comments)
* New: Timeline element
* New: Audio element (Custom audio)
* New: Switcher element
* New: Star Rating element
* New: Video Player element
* New: Search element
* New: Twitter element
* Improved: Added custom video upload for the Video element
* Improved: Added tags for the Gallery element
* Fixed: Post field shortcode to use a sample post for templates
* Fixed: Refactoring the post type field in editor config
* Fixed: Removed header ‘To’ from email headers
* Fixed: Force SMTP encryption by default until there will be a option to change it in configuration form
* Fixed: Disabled news dasbaboard widget not for instances with white label
* Fixed: File type field
* Fixed: Disabled news dashboard widget for instances where white label is active
* Fixed: Force SMTP encryption by default until there will be a option to change it in configuration form
* Fixed: Updated forms SDK
* Fixed: Menu element
* Fixed: Fixed post loop pagination for all categories
* Fixed: Project save when activate/disable License

= 0.0.36 - 2020-03-12 =
* Fixed: Updated forms sdk
* Fixed: Menu element

= 0.0.35 - 2020-03-10 =
* Fixed: enqueue scripts preview.pro.js

= 0.0.34 - 2020-01-24 =
* New: Added new Layouts to Pro

= 0.0.33 - 2020-01-23 =
* Fixed: GetResponse form integration

= 0.0.32 - 2020-01-16 =
* New: Forms added Gmail SMTP, Custom SMTP
* Fixed: Front page pagination for posts component
* Fixed: Featured images placeholder to work with svg images

= 0.0.31 - 2019-11-13 =
* New: Popups

= 0.0.30 - 2019-10-08 =
* New: Added Kit 2

= 0.0.29 - 2019-10-01 =
* New: Added Breadcrumbs element (WP only)
* New: Added File tab to Link option enabling linking to custom uploaded files
* New: Hover background filters for Section, Footer, Header, Row, Column
* Fixed: Translation texts

= 0.0.28 - 2019-09-18 =
* New: Custom fonts
* Improved: Reduced JavaScript file size
* Fixed: Background images not working with dynamic content

= 0.0.27 - 2019-05-29 =
* Fixed: Post loop pagination
* Fixed: Deactivate license form

= 0.0.26 - 2019-05-23 =
* Improved: Cleaned up the Popup blank block
* Fixed: Videos in the page changing src after a popup is closed
* Fixed: Popups not working properly in Global blocks, after duplicating and in other situations

= 0.0.25 - 2019-04-23 =
* Fixed: Redirect URL after license activation/deactivation in networks

= 0.0.24 - 2019-04-18 =
* New: Hover transition option for Facebook elements
* New: Map Address option supports dynamic content
* New: Video Link option supports dynamic content
* Improved: Link to popup option available in tablet and mobile
* Fixed: Carousel in rtl mode
* Fixed: Posts order by option
* Fixed: License menu

= 0.0.23 - 2019-04-12 =
* Fixed: License form

= 0.0.22 - 2019-04-09 =
* Fixed: License activation bug

= 0.0.21 - 2019-04-09 =
* Fixed: Fixed white-label bug for new installs

= 0.0.20 - 2019-04-09 =
* New: White label
* Fixed: Fixed post-loop notice warning

= 0.0.19 - 2019-03-21
* New: Added 17 layouts
* Fixed: The default post loop attributes


= 0.0.18 - 2019-03-11 =
* New: Custom CSS option
* New: Facebook Button element
* New: Facebook Comments element
* New: Facebook Page element
* New: Facebook Embed element
* Fixed: Return login name if the first name and last name are not set.
* Fixed: Fixed updater
* Fixed: Small tweaks in getLicenseActivationData
* Fixed: Removed some "code optimizations"
* Fixed: Fixed compile parameters
* Fixed: Return no image url if there is the height attribute for attachment
* Fixed: moved the filter for license data config
* Fixed: Fixed the license deactivation action

= 0.0.17 - 2019-01-25 =
* New: Added form integrations with 12 services

= 0.0.16 - 2019-01-09 =
* New: Dynamic content placeholders for Metabox

= 0.0.15 - 2018-12-19 =
* Improved: Menu. Not found message
* Fixed: Menu. Hide submenu items when page is loading
* Fixed: Carousel. Zooming before slider initialization
* Fixed: Carousel. Showing submenu items in Astra theme
* Fixed: Popup. z-index conflicts with header blocks
* Fixed: Activate/Dezactivate license callbacks

= 0.0.14 - 2018-12-06 =
* New: Added new Header blocks
* New: Added new Footer blocks
* New: Added Menu element
* New: RichText can now set colors for different tags when using Post Content dynamic content
* Fixed: Fixed autloader path
* Fixed: Pagination refactoring
* Fixed: ACF dynamic content fixes
* Fixed: Limited access option in role manager

= 0.0.13 - 2018-11-23 =
* New: Added Brizy PRO licensing system
* New: Added Brizy PRO dashboard update system
* New: Added possibility to use block dynamic content in RichText
* Fixed: Multiple Galleries in Tabs and Accordion
* Fixed: Updated license form layout
* Fixed: Dynamic content placeholders for pods
* Fixed: Post loop pagination
* Fixed: The content for post loops
* Fixed: Added placeholder display type

= 0.0.12 - 2018-11-08 =
* New: Added more Popup and Blog blocks
* Fixed: Dynamic content post loop

= 0.0.11 - 2018-10-03 =
* New: Added first batch of predesigned pages (53) and styles (10)
* New: Renamed main plugin file
* Improved: Optimised svg shapes
* Fixed: Bugs in dynamic content module
* Fixed: Class autoloader fix

= 0.0.10 - 2018-10-03 =
* New: Added Pods support
* New: Added Toolset support
* Fixed:  Taxonomy return data type

= 0.0.9 - 2018-10-01 =
* New: Added dynamic content option for Section background image
* New: Added dynamic content option to Carousel
* New: Added filter options to Posts
* New: Added Archives element (available in templates only)
* Improved: Added order attr. for post loop place holder
* Improved: Format the content from content placeholder
* Improved: Changed the post loop to be able to work with posts from main loop.
* Fixed: Animations in Popup
* Fixed: Carousel image quality
* Fixed: Added loop pagination
* Fixed: Added filters to template posts
* Fixed: Calculate the container width and height from image size
* Fixed: Allow any char in placeholder name
* Fixed: Fixed the crop function to accept 0 in container width/height
* Fixed: Calculate the container width and height from image size
* Fixed: Fixed brizy min version waring

= 0.0.8 - 2018-09-22 =
* New: Added Posts element

= 0.0.7 - 2018-09-21 =
* New: Return the taxonomies in editor config
* New: Added filters to Image and Video
* New: Added shape dividers to Section
* Fixed: Dynamic context extractor
* Fixed: RichText dynamic content trigger  not working for non US keyboard layouts

= 0.0.6 - 2018-09-17 =
* New: Added Carousel element
* Fixed: Hide certain options in Popup for limited Role Manager role

= 0.0.5 - 2018-09-14 =
* New: Added popups
* Fixed: Removed one warning from acf provider

= 0.0.4 - 2018-09-07 =
* New: Added ACF support

= 0.0.3 - 2018-09-04 =
* New: Added Gallery element

= 0.0.2 - 2018-08-31 =
* New: Added dynamic content for images, links and rich texts

= 0.0.1 - 2018-08-24 =
* New: Added limited Role Manager role



== Frequently Asked Questions ==

= Where do I report security bugs found in this plugin? =

Please report security bugs found in the source code of the Brizy Pro plugin through the [Patchstack Vulnerability Disclosure Program](https://patchstack.com/database/wordpress/plugin/brizy-pro/vulnerabilities). The Patchstack team will assist you with verification, CVE assignment, and notify the developers of this plugin.