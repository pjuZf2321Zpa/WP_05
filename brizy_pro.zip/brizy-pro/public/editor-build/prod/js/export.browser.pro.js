(()=>{"use strict";var e={},t={};function s(o){var l=t[o];if(void 0!==l)return l.exports;var i=t[o]={exports:{}};return e[o](i,i.exports,s),i.exports}s.d=(e,t)=>{for(var o in t)s.o(t,o)&&!s.o(e,o)&&Object.defineProperty(e,o,{enumerable:!0,get:t[o]})},s.g=(()=>{if("object"==typeof globalThis)return globalThis;try{return this||Function("return this")()}catch(e){if("object"==typeof window)return window}})(),s.o=(e,t)=>Object.prototype.hasOwnProperty.call(e,t),s.r=e=>{"u">typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},s.rv=()=>"1.7.11",s.ruid="bundler=rspack@1.7.11";var o={};s.r(o),s.d(o,{getItems:()=>eb});var l={};s.r(l),s.d(l,{getItems:()=>eg});var i={};s.r(i),s.d(i,{getItems:()=>ey});var a={};s.r(a),s.d(a,{getItems:()=>eS});var r={};s.r(r),s.d(r,{getItems:()=>em});var n={};s.r(n),s.d(n,{getItems:()=>eu});var p={};s.r(p),s.d(p,{getItems:()=>ez});var d={};s.r(d),s.d(d,{getItems:()=>ev});var c={};s.r(c),s.d(c,{getItems:()=>eC});var b={};s.r(b),s.d(b,{getItems:()=>eh});var g={};s.r(g),s.d(g,{getItems:()=>ef});var y={};s.r(y),s.d(y,{getItems:()=>eT});var S={};s.r(S),s.d(S,{getItems:()=>ek});var m={};s.r(m),s.d(m,{getItems:()=>e_});var u={};s.r(u),s.d(u,{getItems:()=>eB});var z={};s.r(z),s.d(z,{getItems:()=>eA});var v={};s.r(v),s.d(v,{getItems:()=>e$});var C={};s.r(C),s.d(C,{getItems:()=>ew});var h={};s.r(h),s.d(h,{getItems:()=>eI});var f={};s.r(f),s.d(f,{getItems:()=>eM});var T={};s.r(T),s.d(T,{getItems:()=>eP});var k={};s.r(k),s.d(k,{getItems:()=>eE});var _={};s.r(_),s.d(_,{getItems:()=>eY});var B={};s.r(B),s.d(B,{getItems:()=>eF});var A={};s.r(A),s.d(A,{getItems:()=>ex});var $={};s.r($),s.d($,{getItems:()=>eU});var w={};s.r(w),s.d(w,{getItems:()=>eO});var I={};s.r(I),s.d(I,{getItems:()=>eR});var M={};s.r(M),s.d(M,{getItems:()=>eW});var P={};s.r(P),s.d(P,{getItems:()=>eG});var E={};s.r(E),s.d(E,{getItems:()=>eL});var Y={};s.r(Y),s.d(Y,{getItems:()=>ej});var F={};s.r(F),s.d(F,{getItems:()=>eH});var x={};s.r(x),s.d(x,{getItems:()=>eV});var U={};s.r(U),s.d(U,{getItems:()=>eD});var O={};s.r(O),s.d(O,{getItems:()=>eZ});var R={};s.r(R),s.d(R,{getItems:()=>eq});var W={};s.r(W),s.d(W,{getItems:()=>eJ});var G={};s.r(G),s.d(G,{getItems:()=>eK});var L={};s.r(L),s.d(L,{getItems:()=>eN});var j={};s.r(j),s.d(j,{getItems:()=>eQ});var H={};s.r(H),s.d(H,{getItems:()=>eX});var V={};s.r(V),s.d(V,{getItems:()=>e0});var D={};s.r(D),s.d(D,{getItems:()=>e5});var Z={};s.r(Z),s.d(Z,{getItems:()=>e4});var q={};s.r(q),s.d(q,{getItems:()=>e1});var J={};s.r(J),s.d(J,{getItems:()=>e2});var K={};s.r(K),s.d(K,{getItems:()=>e3});var N={};s.r(N),s.d(N,{getItems:()=>e7});var Q={};s.r(Q),s.d(Q,{getItems:()=>e6});var X={};s.r(X),s.d(X,{getItems:()=>e9});var ee={};s.r(ee),s.d(ee,{getItems:()=>e8});var et={};s.r(et),s.d(et,{getItems:()=>te});var es={};s.r(es),s.d(es,{getItems:()=>tt});var eo={};s.r(eo),s.d(eo,{getItems:()=>ts});var el={};s.r(el),s.d(el,{getItems:()=>to});var ei={};s.r(ei),s.d(ei,{getItems:()=>tl});var ea={};s.r(ea),s.d(ea,{getItems:()=>ti});var er={};s.r(er),s.d(er,{getItems:()=>ta});var en={};s.r(en),s.d(en,{getItems:()=>tr});var ep={};s.r(ep),s.d(ep,{getItems:()=>tn});var ed={};s.r(ed),s.d(ed,{getItems:()=>tp});var ec={};function eb(){let{t:e}=s.g.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=s.g.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}function eg(){let{t:e}=s.g.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Styling"),label:e("Styling"),options:[{id:"settingsTabs",type:"tabs",tabs:[{id:"moreSettingsAdvanced",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=s.g.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]}function ey(){let{t:e}=s.g.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Styling"),label:e("Styling"),options:[{id:"settingsTabs",type:"tabs",tabs:[{id:"moreSettingsAdvanced",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=s.g.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]}function eS(){let{t:e}=s.g.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Styling"),label:e("Styling"),options:[{id:"settingsTabs",type:"tabs",tabs:[{id:"moreSettingsAdvanced",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=s.g.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]}function em(){let{t:e}=s.g.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Styling"),label:e("Styling"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=s.g.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]}function eu(){let{t:e}=s.g.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Basic"),label:e("Basic"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",helper:{content:(()=>{let{t:e}=s.g.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]}s.r(ec),s.d(ec,{getItems:()=>td});let ez=()=>{let{t:e}=s.g.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Styling"),label:e("Styling"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},devices:"desktop",tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=s.g.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]};function ev(){let{t:e}=s.g.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Basic"),label:e("Basic"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=s.g.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]}let eC=()=>{let{t:e}=s.g.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Styling"),label:e("Styling"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",helper:{content:(()=>{let{t:e}=s.g.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]},eh=()=>{let{t:e}=s.g.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Styling"),label:e("Styling"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:100,display:"block",helper:{content:`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`},placeholder:e("element { CSS goes here }")}]}]}]}]}]};function ef(){let{t:e}=s.g.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Styling"),label:e("Styling"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},devices:"desktop",tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=s.g.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]}let eT=()=>{let{t:e}=s.g.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Styling"),label:e("Styling"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},devices:"desktop",tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=s.g.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]},ek=()=>{let{t:e}=s.g.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Styling"),label:e("Styling"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",helper:{content:(()=>{let{t:e}=s.g.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]},e_=({device:e})=>{let{t}=s.g.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",options:[{id:"settingsTabs",type:"tabs",tabs:[{id:"moreSettingsAdvanced",options:[{id:"customCSS",label:t("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=s.g.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${t("CSS goes here")} }`}]}]}]},{id:"effects",options:[{id:"tabs",type:"tabs",tabs:[{id:"scroll",label:t("Scroll"),options:[{id:"motion",type:"motion",position:10,config:{disabled:"desktop"===e?void 0:["mouseTrack","mouseTilt"]}}]}]}]}]}]};function eB({device:e}){let{t}=s.g.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",options:[{id:"tabs",type:"tabs",config:{align:"start"},tabs:[{id:"settingsStyling",label:t("Styling"),icon:"nc-styling",options:[]},{id:"moreSettingsAdvanced",label:t("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:t("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=s.g.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${t("CSS goes here")} }`}]},{id:"moreSettingsTransform",label:t("Transform"),icon:"nc-cog",position:110,options:[{id:"transform",type:"transform",devices:"desktop"}]}]},{id:"settingsTabsResponsive",type:"tabs",config:{align:"start"},devices:"responsive",tabs:[{id:"moreSettingsTransform",label:t("Transform"),icon:"nc-cog",position:110,options:[{id:"transform",type:"transform",devices:"responsive"}]}]}]},{id:"effects",options:[{id:"tabs",type:"tabs",tabs:[{id:"scroll",label:t("Scroll"),options:[{id:"motion",type:"motion",position:10,config:{disabled:"desktop"===e?void 0:["mouseTrack","mouseTilt"]}}]}]}]}]}]}function eA(){let{t:e}=s.g.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Basic"),label:e("Basic"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=s.g.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]}function e$(){let{t:e}=s.g.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Basic"),label:e("Basic"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=s.g.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]}let ew=()=>{let{t:e}=s.g.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Basic"),label:e("Basic"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},devices:"desktop",tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=s.g.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]},eI=()=>{let{t:e}=s.g.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Styling"),label:e("Styling"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},devices:"desktop",tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=s.g.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]},eM=()=>{let{t:e}=s.g.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Styling"),label:e("Styling"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},devices:"desktop",tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=s.g.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]},eP=()=>{let{t:e}=s.g.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Styling"),label:e("Styling"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=s.g.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]};function eE(){let{t:e}=s.g.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Styling"),label:e("Styling"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},devices:"desktop",tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=s.g.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]}let eY=()=>{let{t:e}=s.g.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Styling"),label:e("Styling"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},devices:"desktop",tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",helper:{content:(()=>{let{t:e}=s.g.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]};function eF(){let{t:e}=s.g.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Styling"),label:e("Styling"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},devices:"desktop",tabs:[{id:"settingsStyling",label:e("Basic"),icon:"nc-styling"},{id:"moreSettingsAdvanced",label:e("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=s.g.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]}function ex(){let{t:e}=s.g.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Basic"),label:e("Basic"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=s.g.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]}let eU=()=>{let{t:e}=s.g.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Styling"),label:e("Styling"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",helper:{content:(()=>{let{t:e}=s.g.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]},eO=()=>{let{t:e}=s.g.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Styling"),label:e("Styling"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},devices:"desktop",tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=s.g.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]},eR=()=>{let{t:e}=s.g.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Styling"),label:e("Styling"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},devices:"desktop",tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=s.g.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">${e("element")}</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">${e("element .child-element")}</span> {...}
</p>`})()},placeholder:e("element { CSS goes here }")}]}]}]}]}]},eW=()=>{let{t:e}=s.g.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Styling"),label:e("Styling"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=s.g.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]};function eG(){let{t:e}=s.g.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Styling"),label:e("Styling"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},devices:"desktop",tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=s.g.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]}function eL({device:e}){let{t}=s.g.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:t("Styling"),label:t("Styling"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},devices:"desktop",tabs:[{id:"moreSettingsAdvanced",label:t("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:t("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=s.g.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${t("CSS goes here")} }`}]},{id:"moreSettingsTransform",label:t("Transform"),icon:"nc-cog",position:110,options:[{id:"transform",type:"transform",devices:"desktop"}]}]},{id:"settingsTabsResponsive",type:"tabs",config:{align:"start"},devices:"responsive",tabs:[{id:"moreSettingsTransform",label:t("Transform"),icon:"nc-cog",position:110,options:[{id:"transform",type:"transform",devices:"responsive"}]}]}]},{id:"effects",options:[{id:"tabs",type:"tabs",tabs:[{id:"scroll",label:t("Scroll"),options:[{id:"motion",type:"motion",position:10,config:{disabled:"desktop"===e?void 0:["mouseTrack","mouseTilt"]}}]}]}]}]}]}function ej(){let{t:e}=s.g.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Styling"),label:e("Styling"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=s.g.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]}function eH(){let{t:e}=s.g.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Styling"),label:e("Styling"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=s.g.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]}function eV(){let{t:e}=s.g.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Basic"),label:e("Basic"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=s.g.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]}function eD(){let{t:e}=s.g.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Styling"),label:e("Styling"),options:[{id:"settingsTabs",type:"tabs",tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=s.g.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]}function eZ(){let{t:e}=s.g.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Styling"),label:e("Styling"),options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=s.g.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`},{id:"customAttributes",label:e("Custom Attributes"),type:"codeMirror",position:50,placeholder:'key1:"value1"\nkey2:"value2"',display:"block",helper:{content:e("Set your custom attribute for wrapper element. Each attribute in a separate line. Separate attribute key from the value using : character.")}}]}]}]}function eq({context:e}){let{t,utils:{getDynamicContentOption:o,DCTypes:l}}=s.g.Brizy,i=o({options:e.dynamicContent.config,type:l.richText});return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:t("Styling"),label:t("Styling"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},tabs:[{id:"moreSettingsAdvanced",label:t("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:t("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=s.g.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${t("CSS goes here")} }`},{id:"customAttributes",label:t("Custom Attributes"),type:"codeMirror",position:50,placeholder:'key1:"value1"\nkey2:"value2"',display:"block",helper:{content:t("Set your custom attribute for wrapper element. Each attribute in a separate line. Separate attribute key from the value using : character.")},population:i}]}]}]}]}]}function eJ(){let{t:e}=s.g.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Styling"),label:e("Styling"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=s.g.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]}function eK(){let{t:e}=s.g.Brizy;return[{id:"settingsTabs",type:"tabs",tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=s.g.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}function eN(){let{t:e}=s.g.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Basic"),label:e("Basic"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=s.g.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]}let eQ=()=>{let{t:e}=s.g.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Styling"),label:e("Styling"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:100,display:"block",helper:{content:(()=>{let{t:e}=s.g.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:"element { CSS goes here }"}]}]}]}]}]};function eX(){let{t:e}=s.g.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Basic"),label:e("Basic"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},devices:"desktop",tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=s.g.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]}let e0=()=>{let{t:e}=s.g.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Styling"),label:e("Styling"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},devices:"desktop",tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=s.g.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]},e5=({device:e})=>{let{t}=s.g.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:t("Styling"),label:t("Styling"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},devices:"desktop",tabs:[{id:"moreSettingsTransform",label:t("Transform"),icon:"nc-cog",position:110,options:[{id:"transform",type:"transform"}]}]},{id:"settingsTabsResponsive",type:"tabs",config:{align:"start"},devices:"responsive",tabs:[{id:"moreSettingsTransform",label:t("Transform"),icon:"nc-cog",options:[{id:"transform",type:"transform",position:20}]}]}]},{id:"effects",label:t("Effects"),options:[{id:"tabs",type:"tabs",tabs:[{id:"scroll",label:t("Scroll"),options:[{id:"motion",type:"motion",position:10,config:{disabled:"desktop"===e?void 0:["mouseTrack","mouseTilt"]}}]}]}]}]}]};function e4(){return[]}let e1=({v:e,device:t,component:o})=>{let{t:l,utils:{defaultValueValue:i,isBackgroundPointerEnabled:a}}=s.g.Brizy,r=s=>i({v:e,key:s,device:t}),n="soundcloud"===r("type"),p=a(o.getGlobalConfig(),"audio"),d=o.getGlobalConfig().elements?.audio,c=d?.disableSelectType;return[{id:"toolbarCurrentElement",type:"popover",options:[{id:"tabsCurrentElement",type:"tabs",tabs:[{id:"tabCurrentElementUpload",label:l("Audio"),options:[{id:"type",label:l("Audio"),type:"select",devices:"desktop",position:20,choices:[{value:"soundcloud",title:l("SoundCloud")},{value:"custom",title:l("Custom")}],disabled:c},{id:"audio",type:"fileUpload",label:l("File"),config:{allowedExtensions:[".mp3",".ogg",".wav"]},devices:"desktop",disabled:n},{id:"groupIconSize",type:"group",disabled:n,options:[{id:"iconSize",label:l("Icons"),type:"radioGroup",devices:"desktop",choices:[{value:"small",icon:"nc-16"},{value:"medium",icon:"nc-24"},{value:"large",icon:"nc-32"},{value:"custom",icon:"nc-more"}]},{id:"iconCustomSize",type:"slider",disabled:"custom"!==r("iconSize"),config:{min:1,max:100,units:[{title:"px",value:"px"}]}}]},{id:"loop",label:l("Loop"),type:"switch",devices:"desktop",disabled:n}]},{id:"tabCurrentElementCover",label:l("Cover"),devices:"desktop",options:[{label:l("Cover"),id:"cover",type:"imageUpload",disabled:n,config:{pointer:p,edit:"desktop"===t}},{id:"coverZoom",label:l("Zoom"),type:"slider",disabled:n,config:{min:100,max:300,units:[{value:"%",title:"%"}]}}]},{id:"tabCurrentElementAdvanced",label:l("Advanced"),options:[{id:"showTitle",label:l("Title"),type:"switch",devices:"desktop",disabled:n},{id:"showCurrentTime",label:l("Time"),type:"switch",devices:"desktop",disabled:n},{id:"showDurationTime",label:l("Duration"),type:"switch",devices:"desktop",disabled:n},{id:"showProgressBarTrack",label:l("Progress"),type:"switch",devices:"desktop",disabled:n},{id:"showProgressBarVolume",label:l("Volume"),type:"switch",devices:"desktop",disabled:n},{id:"caption",label:l("Captions (CC)"),type:"fileUpload",devices:"desktop",disabled:n,acceptedExtensions:["vtt"],helper:{content:l("Upload a .vtt file with captions for your video")}}]}]}]},{id:"popoverTypography",type:"popover",config:{icon:"nc-font",size:"desktop"===t?"large":"auto",title:l("Typography")},roles:["admin"],position:90,disabled:"on"!==r("showCurrentTime")&&"on"!==r("showDurationTime"),options:[{id:"",type:"typography",disabled:n,config:{fontFamily:"desktop"===t}}]}]},e2=({v:e,component:t,editorMode:o})=>{let{t:l,utils:{context:{isPopup:i,isStory:a},getEnabledLinkOptions:r}}=s.g.Brizy,n=i(o),p=!!t.props.meta?.sectionPopup2,{linkUpload:d,linkAction:c}=r(t.getGlobalConfig()),b="on"!==e.enableTooltip,g=t.props.renderer?.disableTooltip||a(o);return[{id:"toolbarCurrentShortcode",type:"popover",options:[{id:"currentShortcodeTabs",type:"tabs",tabs:[{id:"buttonTooltip",label:l("Tooltip"),options:[{id:"enableTooltip",label:l("Enable Tooltip"),type:"switch",devices:"desktop",disabled:g},{id:"tooltipText",label:l("Text"),disabled:b,type:"textarea",placeholder:l("Paste your text here"),devices:"desktop",config:{lines:3}},{id:"tooltipTriggerClick",label:l("Enable on Click"),helper:{content:l("Enable tooltip on click instead of hover")},type:"switch",disabled:b,devices:"desktop"}]}]}]},{id:"toolbarLink",type:"popover",options:[{id:"linkType",type:"tabs",config:{saveTab:!0},tabs:[{id:"upload",label:l("File"),options:[{id:"linkUpload",label:l("File"),type:"fileUpload",disabled:!d}]},{id:"action",label:l("Action"),options:[{id:"actionClosePopup",label:l("Close Popup"),type:"switch",devices:"desktop",disabled:!(p||n)||!c}]}]}]}]};function e3({component:e}){let{t,utils:{stateMode:{NORMAL:o,HOVER:l},getEnabledLinkOptions:i}}=s.g.Brizy,{linkUpload:a}=i(e.getGlobalConfig());return[{id:"toolbarCurrentElement",type:"popover",options:[{id:"tabsCurrentElement",type:"tabs",tabs:[{id:"filters",label:t("Filters"),options:[{id:"",type:"filters",states:[o,l]}]}]}]},{id:"toolbarLink",type:"popover",options:[{id:"linkType",type:"tabs",config:{saveTab:!0},tabs:[{id:"upload",label:t("File"),options:[{id:"linkUpload",label:t("File"),type:"fileUpload",disabled:!a}]}]}]},{id:"toolbarSettings",type:"popover",config:{icon:"nc-cog",title:t("Settings")},position:110,devices:"desktop",options:[{id:"grid",type:"grid",config:{separator:!0},columns:[{id:"grid-settings",width:50,options:[{id:"styles",type:"sidebarTabsButton",config:{text:t("Styling"),icon:"nc-cog",tabId:"styles"}}]}]}]}]}function e7({component:e,editorMode:t,v:o}){let{t:l,utils:{context:{isPopup:i,isStory:a},getEnabledLinkOptions:r}}=s.g.Brizy,n=!!e.props.meta?.sectionPopup2,p=a(t),d="on"===o.enableTooltip,{linkUpload:c,linkAction:b}=r(e.getGlobalConfig()),g=!d||p;return[{id:"toolbarCurrentShortcode",type:"popover",options:[{id:"currentShortcodeTabs",type:"tabs",tabs:[{id:"iconTooltip",label:l("Tooltip"),options:[{id:"enableTooltip",label:l("Enable Tooltip"),type:"switch",devices:"desktop",disabled:p},{id:"tooltipText",label:l("Text"),devices:"desktop",disabled:g,type:"textarea",placeholder:l("Paste your text here"),config:{lines:3}},{id:"tooltipTriggerClick",label:l("Enable on Click"),devices:"desktop",helper:{content:l("Enable tooltip on click instead of hover")},type:"switch",disabled:g}]}]}]},{id:"toolbarLink",type:"popover",options:[{id:"linkType",type:"tabs",config:{saveTab:!0},tabs:[{id:"upload",label:l("File"),options:[{id:"linkUpload",label:l("File"),type:"fileUpload",disabled:!c}]},{id:"action",label:l("Action"),options:[{id:"actionClosePopup",label:l("Close Popup"),type:"switch",devices:"desktop",disabled:!(n||i(t))||!b}]}]}]},{id:"advancedSettings",devices:"desktop",type:"advancedSettings",roles:["admin"],position:110,title:l("Settings")}]}let e6=({v:e,component:t,editorMode:o})=>{let{t:l,utils:{context:{isPopup:i,isStory:a},stateMode:{NORMAL:r,HOVER:n},getEnabledLinkOptions:p}}=s.g.Brizy,d=!!t.props.meta.sectionPopup2,c=a(o),{linkUpload:b,linkAction:g}=p(t.getGlobalConfig()),y="off"===e.enableTooltip||c;return[{id:"toolbarImage",type:"popover",options:[{id:"media",type:"tabs",tabs:[{id:"tabFilters",label:l("Filters"),options:[{id:"image",type:"filters",states:[r,n]}]},{id:"imageTooltip",label:l("Tooltip"),position:120,options:[{id:"enableTooltip",label:l("Enable Tooltip"),type:"switch",devices:"desktop",disabled:c},{id:"tooltipText",label:l("Text"),disabled:y,type:"textarea",placeholder:l("Paste your text here"),devices:"desktop",config:{lines:3}},{id:"tooltipTriggerClick",label:l("Enable on Click"),helper:{content:l("Enable tooltip on click instead of hover")},type:"switch",disabled:y,devices:"desktop"}]}]}]},{id:"toolbarLink",type:"popover",options:[{id:"linkType",type:"tabs",tabs:[{id:"upload",label:l("File"),options:[{id:"linkUpload",label:l("File"),type:"fileUpload",disabled:c||!b,devices:"desktop"}]},{id:"action",label:l("Action"),options:[{id:"actionClosePopup",label:l("Close Popup"),type:"switch",devices:"desktop",disabled:!(d||i(o))||!g}]}]}]}]};function e9({component:e}){let{t,utils:{getEnabledLinkOptions:o}}=s.g.Brizy,{linkUpload:l}=o(e.getGlobalConfig());return[{id:"toolbarLink",type:"popover",options:[{id:"linkType",type:"tabs",config:{saveTab:!0},tabs:[{id:"upload",label:t("File"),options:[{id:"linkUpload",label:t("File"),type:"fileUpload",disabled:!l}]}]}]}]}let e8=()=>{let{t:e,utils:{stateMode:{NORMAL:t,HOVER:o}}}=s.g.Brizy;return[{id:"toolbarCurrentElement",type:"popover",devices:"desktop",options:[{id:"tabsCurrentElement",type:"tabs",tabs:[{id:"filters",label:e("Filters"),options:[{id:"",type:"filters",states:[t,o],selector:"{{WRAPPER}}:hover .brz-ui-ed-iframe"}]}]}]}]};function te({component:e}){let{t,utils:{getEnabledLinkOptions:o}}=s.g.Brizy,{linkUpload:l}=o(e.getGlobalConfig());return[{id:"toolbarLink",type:"popover",options:[{id:"linkType",type:"tabs",config:{saveTab:!0},tabs:[{id:"upload",label:t("File"),options:[{id:"linkUpload",label:t("File"),type:"fileUpload",disabled:!l}]}]}]}]}function tt({component:e}){let{t,utils:{getEnabledLinkOptions:o}}=s.g.Brizy,{linkUpload:l}=o(e.getGlobalConfig());return[{id:"toolbarLink",type:"popover",options:[{id:"linkType",type:"tabs",config:{saveTab:!0},tabs:[{id:"upload",label:t("File"),options:[{id:"linkUpload",label:t("File"),type:"fileUpload",disabled:!l}]}]}]}]}let ts=({component:e})=>{let{t,utils:{stateMode:{NORMAL:o,HOVER:l},getEnabledLinkOptions:i}}=s.g.Brizy,{linkUpload:a}=i(e.getGlobalConfig());return[{id:"toolbarMedia",type:"popover",options:[{id:"tabsMedia",type:"tabs",tabs:[{id:"tabFilters",label:t("Filters"),options:[{id:"",type:"filters",states:[o,l]}]}]}]},{id:"toolbarLink",type:"popover",devices:"responsive",options:[{id:"linkType",type:"tabs",config:{saveTab:!0},tabs:[{id:"upload",label:t("File"),options:[{id:"linkUpload",label:t("File"),type:"fileUpload",disabled:!a}]}]}]}]};function to(){let{t:e,utils:{stateMode:{NORMAL:t,HOVER:o}}}=s.g.Brizy;return[{id:"toolbarCurrentElement",type:"popover",options:[{id:"tabsCurrentElement",type:"tabs",tabs:[{id:"filters",label:e("Filters"),options:[{id:"",type:"filters",states:[t,o]}]}]}]}]}function tl(){let{t:e,utils:{stateMode:{NORMAL:t,HOVER:o}}}=s.g.Brizy;return[{id:"toolbarCurrentElement",type:"popover",options:[{id:"tabsCurrentElement",type:"tabs",tabs:[{id:"filters",label:e("Filters"),options:[{id:"",type:"filters",states:[t,o]}]}]}]}]}function ti(){let{t:e,utils:{stateMode:{NORMAL:t,HOVER:o}}}=s.g.Brizy;return[{id:"toolbarCurrentElement",type:"popover",options:[{id:"tabsCurrentElement",type:"tabs",tabs:[{id:"filters",label:e("Filters"),options:[{id:"",type:"filters",states:[t,o]}]}]}]}]}function ta(){let{t:e,utils:{stateMode:{NORMAL:t,HOVER:o}}}=s.g.Brizy;return[{id:"toolbarCurrentElement",type:"popover",options:[{id:"tabsCurrentElement",type:"tabs",tabs:[{id:"filters",label:e("Filters"),options:[{id:"",type:"filters",states:[t,o]}]}]}]}]}function tr(){let{t:e,utils:{stateMode:{NORMAL:t,HOVER:o}}}=s.g.Brizy;return[{id:"toolbarMedia",type:"popover",options:[{id:"tabsMedia",type:"tabs",tabs:[{id:"tabFilters",label:e("Filters"),options:[{id:"",type:"filters",states:[t,o]}]}]}]},{id:"advancedSettings",type:"advancedSettings",devices:"desktop",roles:["admin"],position:110,title:e("Settings")}]}let tn=()=>{let{t:e,utils:{stateMode:{NORMAL:t,HOVER:o}}}=s.g.Brizy;return[{id:"toolbarMedia",type:"popover",options:[{id:"tabsMedia",type:"tabs",tabs:[{id:"tabFilters",label:e("Filters"),options:[{id:"",type:"filters",states:[t,o]}]}]}]}]};function tp(){let{t:e}=s.g.Brizy;return[{id:"toolbarCurrentElement",type:"popover",options:[{id:"tabsCurrentElement",type:"tabs",tabs:[{id:"filters",label:e("Filters"),options:[{id:"",type:"filters"}]}]}]}]}let td=()=>{let{t:e,utils:{stateMode:{NORMAL:t,HOVER:o}}}=s.g.Brizy;return[{id:"toolbarCurrentElement",type:"popover",options:[{id:"tabsCurrentElement",type:"tabs",tabs:[{id:"tabCurrentElementFilter",label:e("Filters"),options:[{id:"",type:"filters",states:[t,o],selector:"{{WRAPPER}}:hover .brz-iframe, {{WRAPPER}}:hover .brz-video__cover:before, {{WRAPPER}}:hover.brz-custom-video video, {{WRAPPER}}:hover .brz-video__cover::before"}]}]}]}]},tc=s.g.Brizy;for(let[e,t]of Object.entries({Button:J,Icon:N,Image:Q,Video:ec,Audio:q,Map:ee,Column:K,Row:eo,SectionItem:el,StoryItem:ed,SectionFooter:ei,SectionHeaderItem:ea,SectionHeaderStickyItem:er,SectionPopup:en,SectionPopup2:ep,Lottie:X,PostTitle:es,PostExcerpt:et,WPSidebar:Z}))tc.addFilter(`toolbarItemsExtend_${e}`,()=>t);for(let[e,t]of Object.entries({AccordionParent:d,Button:y,Column:u,Countdown:z,Countdown2:v,Counter:C,EmbedCode:T,FormParent:k,Icon:_,IconTextParent:B,Image:A,Line:$,Map:w,ProgressBar:M,RichText:P,Row:E,SectionFooter:F,SectionHeaderItem:x,SectionHeaderStickyItem:U,SectionItem:Y,StoryItem:G,SectionPopup:O,SectionPopup2:R,SoundCloud:W,TabsParent:H,Video:V,Audio:g,TableParent:L,AnimatedHeadline:b,Alert:c,Calendly:S,TableOfContents:j,Price:p,Paypal:I,EcwidPrice:f,EcwidAddToCart:h,Wrapper:D,Cloneable:m,WPCustomShortcode:r,WPSidebar:n,WOOCategories:o,WOOProducts:a,WOOProductPage:i,WOOPages:l}))tc.addFilter(`sidebarItemsExtend_${e}`,()=>t)})();