var e={};e.d=(t,s)=>{for(var o in s)e.o(s,o)&&!e.o(t,o)&&Object.defineProperty(t,o,{enumerable:!0,get:s[o]})},e.o=(e,t)=>Object.prototype.hasOwnProperty.call(e,t),e.r=e=>{"u">typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})};var t={};e.r(t),e.d(t,{getItems:()=>ed});var s={};e.r(s),e.d(s,{getItems:()=>eb});var o={};e.r(o),e.d(o,{getItems:()=>ec});var l={};e.r(l),e.d(l,{getItems:()=>eg});var a={};e.r(a),e.d(a,{getItems:()=>ey});var i={};e.r(i),e.d(i,{getItems:()=>eS});var r={};e.r(r),e.d(r,{getItems:()=>em});var n={};e.r(n),e.d(n,{getItems:()=>eu});var p={};e.r(p),e.d(p,{getItems:()=>ez});var d={};e.r(d),e.d(d,{getItems:()=>ev});var b={};e.r(b),e.d(b,{getItems:()=>eC});var c={};e.r(c),e.d(c,{getItems:()=>eh});var g={};e.r(g),e.d(g,{getItems:()=>ef});var y={};e.r(y),e.d(y,{getItems:()=>eT});var S={};e.r(S),e.d(S,{getItems:()=>ek});var m={};e.r(m),e.d(m,{getItems:()=>e_});var u={};e.r(u),e.d(u,{getItems:()=>eB});var z={};e.r(z),e.d(z,{getItems:()=>eA});var v={};e.r(v),e.d(v,{getItems:()=>e$});var C={};e.r(C),e.d(C,{getItems:()=>eI});var h={};e.r(h),e.d(h,{getItems:()=>ew});var f={};e.r(f),e.d(f,{getItems:()=>eM});var T={};e.r(T),e.d(T,{getItems:()=>eP});var k={};e.r(k),e.d(k,{getItems:()=>eE});var _={};e.r(_),e.d(_,{getItems:()=>eY});var B={};e.r(B),e.d(B,{getItems:()=>eF});var A={};e.r(A),e.d(A,{getItems:()=>ex});var $={};e.r($),e.d($,{getItems:()=>eU});var I={};e.r(I),e.d(I,{getItems:()=>eO});var w={};e.r(w),e.d(w,{getItems:()=>eR});var M={};e.r(M),e.d(M,{getItems:()=>eW});var P={};e.r(P),e.d(P,{getItems:()=>eG});var E={};e.r(E),e.d(E,{getItems:()=>eL});var Y={};e.r(Y),e.d(Y,{getItems:()=>ej});var F={};e.r(F),e.d(F,{getItems:()=>eH});var x={};e.r(x),e.d(x,{getItems:()=>eV});var U={};e.r(U),e.d(U,{getItems:()=>eD});var O={};e.r(O),e.d(O,{getItems:()=>eZ});var R={};e.r(R),e.d(R,{getItems:()=>eq});var W={};e.r(W),e.d(W,{getItems:()=>eJ});var G={};e.r(G),e.d(G,{getItems:()=>eK});var L={};e.r(L),e.d(L,{getItems:()=>eN});var j={};e.r(j),e.d(j,{getItems:()=>eQ});var H={};e.r(H),e.d(H,{getItems:()=>eX});var V={};e.r(V),e.d(V,{getItems:()=>e5});var D={};e.r(D),e.d(D,{getItems:()=>e0});var Z={};e.r(Z),e.d(Z,{getItems:()=>e4});var q={};e.r(q),e.d(q,{getItems:()=>e1});var J={};e.r(J),e.d(J,{getItems:()=>e2});var K={};e.r(K),e.d(K,{getItems:()=>e3});var N={};e.r(N),e.d(N,{getItems:()=>e6});var Q={};e.r(Q),e.d(Q,{getItems:()=>e9});var X={};e.r(X),e.d(X,{getItems:()=>e7});var ee={};e.r(ee),e.d(ee,{getItems:()=>e8});var et={};e.r(et),e.d(et,{getItems:()=>te});var es={};e.r(es),e.d(es,{getItems:()=>tt});var eo={};e.r(eo),e.d(eo,{getItems:()=>ts});var el={};e.r(el),e.d(el,{getItems:()=>to});var ea={};e.r(ea),e.d(ea,{getItems:()=>tl});var ei={};e.r(ei),e.d(ei,{getItems:()=>ta});var er={};e.r(er),e.d(er,{getItems:()=>ti});var en={};e.r(en),e.d(en,{getItems:()=>tr});var ep={};function ed(){let{t:e}=global.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=global.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}function eb(){let{t:e}=global.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Styling"),label:e("Styling"),options:[{id:"settingsTabs",type:"tabs",tabs:[{id:"moreSettingsAdvanced",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=global.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]}function ec(){let{t:e}=global.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Styling"),label:e("Styling"),options:[{id:"settingsTabs",type:"tabs",tabs:[{id:"moreSettingsAdvanced",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=global.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]}function eg(){let{t:e}=global.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Styling"),label:e("Styling"),options:[{id:"settingsTabs",type:"tabs",tabs:[{id:"moreSettingsAdvanced",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=global.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]}function ey(){let{t:e}=global.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Styling"),label:e("Styling"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=global.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]}function eS(){let{t:e}=global.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Basic"),label:e("Basic"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",helper:{content:(()=>{let{t:e}=global.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]}e.r(ep),e.d(ep,{getItems:()=>tn});let em=()=>{let{t:e}=global.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Styling"),label:e("Styling"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},devices:"desktop",tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=global.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]};function eu(){let{t:e}=global.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Basic"),label:e("Basic"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=global.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]}let ez=()=>{let{t:e}=global.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Styling"),label:e("Styling"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",helper:{content:(()=>{let{t:e}=global.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]},ev=()=>{let{t:e}=global.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Styling"),label:e("Styling"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:100,display:"block",helper:{content:`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`},placeholder:e("element { CSS goes here }")}]}]}]}]}]};function eC(){let{t:e}=global.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Styling"),label:e("Styling"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},devices:"desktop",tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=global.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]}let eh=()=>{let{t:e}=global.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Styling"),label:e("Styling"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},devices:"desktop",tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=global.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]},ef=()=>{let{t:e}=global.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Styling"),label:e("Styling"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",helper:{content:(()=>{let{t:e}=global.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]},eT=({device:e})=>{let{t}=global.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",options:[{id:"settingsTabs",type:"tabs",tabs:[{id:"moreSettingsAdvanced",options:[{id:"customCSS",label:t("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=global.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${t("CSS goes here")} }`}]}]}]},{id:"effects",options:[{id:"tabs",type:"tabs",tabs:[{id:"scroll",label:t("Scroll"),options:[{id:"motion",type:"motion",position:10,config:{disabled:"desktop"===e?void 0:["mouseTrack","mouseTilt"]}}]}]}]}]}]};function ek({device:e}){let{t}=global.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",options:[{id:"tabs",type:"tabs",config:{align:"start"},tabs:[{id:"settingsStyling",label:t("Styling"),icon:"nc-styling",options:[]},{id:"moreSettingsAdvanced",label:t("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:t("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=global.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${t("CSS goes here")} }`}]},{id:"moreSettingsTransform",label:t("Transform"),icon:"nc-cog",position:110,options:[{id:"transform",type:"transform",devices:"desktop"}]}]},{id:"settingsTabsResponsive",type:"tabs",config:{align:"start"},devices:"responsive",tabs:[{id:"moreSettingsTransform",label:t("Transform"),icon:"nc-cog",position:110,options:[{id:"transform",type:"transform",devices:"responsive"}]}]}]},{id:"effects",options:[{id:"tabs",type:"tabs",tabs:[{id:"scroll",label:t("Scroll"),options:[{id:"motion",type:"motion",position:10,config:{disabled:"desktop"===e?void 0:["mouseTrack","mouseTilt"]}}]}]}]}]}]}function e_(){let{t:e}=global.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Basic"),label:e("Basic"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=global.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]}function eB(){let{t:e}=global.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Basic"),label:e("Basic"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=global.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]}let eA=()=>{let{t:e}=global.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Basic"),label:e("Basic"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},devices:"desktop",tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=global.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]},e$=()=>{let{t:e}=global.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Styling"),label:e("Styling"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},devices:"desktop",tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=global.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]},eI=()=>{let{t:e}=global.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Styling"),label:e("Styling"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},devices:"desktop",tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=global.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]},ew=()=>{let{t:e}=global.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Styling"),label:e("Styling"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=global.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]};function eM(){let{t:e}=global.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Styling"),label:e("Styling"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},devices:"desktop",tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=global.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]}let eP=()=>{let{t:e}=global.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Styling"),label:e("Styling"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},devices:"desktop",tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",helper:{content:(()=>{let{t:e}=global.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]};function eE(){let{t:e}=global.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Styling"),label:e("Styling"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},devices:"desktop",tabs:[{id:"settingsStyling",label:e("Basic"),icon:"nc-styling"},{id:"moreSettingsAdvanced",label:e("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=global.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]}function eY(){let{t:e}=global.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Basic"),label:e("Basic"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=global.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]}let eF=()=>{let{t:e}=global.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Styling"),label:e("Styling"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",helper:{content:(()=>{let{t:e}=global.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]},ex=()=>{let{t:e}=global.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Styling"),label:e("Styling"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},devices:"desktop",tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=global.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]},eU=()=>{let{t:e}=global.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Styling"),label:e("Styling"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},devices:"desktop",tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=global.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">${e("element")}</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">${e("element .child-element")}</span> {...}
</p>`})()},placeholder:e("element { CSS goes here }")}]}]}]}]}]},eO=()=>{let{t:e}=global.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Styling"),label:e("Styling"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=global.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]};function eR(){let{t:e}=global.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Styling"),label:e("Styling"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},devices:"desktop",tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=global.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]}function eW({device:e}){let{t}=global.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:t("Styling"),label:t("Styling"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},devices:"desktop",tabs:[{id:"moreSettingsAdvanced",label:t("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:t("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=global.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${t("CSS goes here")} }`}]},{id:"moreSettingsTransform",label:t("Transform"),icon:"nc-cog",position:110,options:[{id:"transform",type:"transform",devices:"desktop"}]}]},{id:"settingsTabsResponsive",type:"tabs",config:{align:"start"},devices:"responsive",tabs:[{id:"moreSettingsTransform",label:t("Transform"),icon:"nc-cog",position:110,options:[{id:"transform",type:"transform",devices:"responsive"}]}]}]},{id:"effects",options:[{id:"tabs",type:"tabs",tabs:[{id:"scroll",label:t("Scroll"),options:[{id:"motion",type:"motion",position:10,config:{disabled:"desktop"===e?void 0:["mouseTrack","mouseTilt"]}}]}]}]}]}]}function eG(){let{t:e}=global.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Styling"),label:e("Styling"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=global.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]}function eL(){let{t:e}=global.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Styling"),label:e("Styling"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=global.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]}function ej(){let{t:e}=global.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Basic"),label:e("Basic"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=global.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]}function eH(){let{t:e}=global.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Styling"),label:e("Styling"),options:[{id:"settingsTabs",type:"tabs",tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=global.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]}function eV(){let{t:e}=global.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Styling"),label:e("Styling"),options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=global.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`},{id:"customAttributes",label:e("Custom Attributes"),type:"codeMirror",position:50,placeholder:'key1:"value1"\nkey2:"value2"',display:"block",helper:{content:e("Set your custom attribute for wrapper element. Each attribute in a separate line. Separate attribute key from the value using : character.")}}]}]}]}function eD({context:e}){let{t,utils:{getDynamicContentOption:s,DCTypes:o}}=global.Brizy,l=s({options:e.dynamicContent.config,type:o.richText});return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:t("Styling"),label:t("Styling"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},tabs:[{id:"moreSettingsAdvanced",label:t("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:t("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=global.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${t("CSS goes here")} }`},{id:"customAttributes",label:t("Custom Attributes"),type:"codeMirror",position:50,placeholder:'key1:"value1"\nkey2:"value2"',display:"block",helper:{content:t("Set your custom attribute for wrapper element. Each attribute in a separate line. Separate attribute key from the value using : character.")},population:l}]}]}]}]}]}function eZ(){let{t:e}=global.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Styling"),label:e("Styling"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=global.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]}function eq(){let{t:e}=global.Brizy;return[{id:"settingsTabs",type:"tabs",tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=global.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}function eJ(){let{t:e}=global.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Basic"),label:e("Basic"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=global.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]}let eK=()=>{let{t:e}=global.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Styling"),label:e("Styling"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:100,display:"block",helper:{content:(()=>{let{t:e}=global.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:"element { CSS goes here }"}]}]}]}]}]};function eN(){let{t:e}=global.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Basic"),label:e("Basic"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},devices:"desktop",tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=global.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]}let eQ=()=>{let{t:e}=global.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:e("Styling"),label:e("Styling"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},devices:"desktop",tabs:[{id:"moreSettingsAdvanced",label:e("Advanced"),icon:"nc-cog",options:[{id:"customCSS",label:e("Custom CSS"),type:"codeMirror",position:45,display:"block",devices:"desktop",helper:{content:(()=>{let{t:e}=global.Brizy;return`
<p class="brz-p">${e("You can use the following selectors to create targeted CSS.")}</p>
<p class="brz-p">
  <span class="brz-span brz-ed-tooltip__overlay-code">element</span> {...}
  <br class="brz-br">
  <span class="brz-span brz-ed-tooltip__overlay-code">element .child-element</span> {...}
</p>`})()},placeholder:`element { ${e("CSS goes here")} }`}]}]}]}]}]},eX=({device:e})=>{let{t}=global.Brizy;return[{id:"sidebarTabs",type:"sidebarTabs",tabs:[{id:"styles",title:t("Styling"),label:t("Styling"),options:[{id:"settingsTabs",type:"tabs",config:{align:"start"},devices:"desktop",tabs:[{id:"moreSettingsTransform",label:t("Transform"),icon:"nc-cog",position:110,options:[{id:"transform",type:"transform"}]}]},{id:"settingsTabsResponsive",type:"tabs",config:{align:"start"},devices:"responsive",tabs:[{id:"moreSettingsTransform",label:t("Transform"),icon:"nc-cog",options:[{id:"transform",type:"transform",position:20}]}]}]},{id:"effects",label:t("Effects"),options:[{id:"tabs",type:"tabs",tabs:[{id:"scroll",label:t("Scroll"),options:[{id:"motion",type:"motion",position:10,config:{disabled:"desktop"===e?void 0:["mouseTrack","mouseTilt"]}}]}]}]}]}]};function e5(){return[]}let e0=({v:e,device:t,component:s})=>{let{t:o,utils:{defaultValueValue:l,isBackgroundPointerEnabled:a}}=global.Brizy,i=s=>l({v:e,key:s,device:t}),r="soundcloud"===i("type"),n=a(s.getGlobalConfig(),"audio"),p=s.getGlobalConfig().elements?.audio,d=p?.disableSelectType;return[{id:"toolbarCurrentElement",type:"popover",options:[{id:"tabsCurrentElement",type:"tabs",tabs:[{id:"tabCurrentElementUpload",label:o("Audio"),options:[{id:"type",label:o("Audio"),type:"select",devices:"desktop",position:20,choices:[{value:"soundcloud",title:o("SoundCloud")},{value:"custom",title:o("Custom")}],disabled:d},{id:"audio",type:"fileUpload",label:o("File"),config:{allowedExtensions:[".mp3",".ogg",".wav"]},devices:"desktop",disabled:r},{id:"groupIconSize",type:"group",disabled:r,options:[{id:"iconSize",label:o("Icons"),type:"radioGroup",devices:"desktop",choices:[{value:"small",icon:"nc-16"},{value:"medium",icon:"nc-24"},{value:"large",icon:"nc-32"},{value:"custom",icon:"nc-more"}]},{id:"iconCustomSize",type:"slider",disabled:"custom"!==i("iconSize"),config:{min:1,max:100,units:[{title:"px",value:"px"}]}}]},{id:"loop",label:o("Loop"),type:"switch",devices:"desktop",disabled:r}]},{id:"tabCurrentElementCover",label:o("Cover"),devices:"desktop",options:[{label:o("Cover"),id:"cover",type:"imageUpload",disabled:r,config:{pointer:n,edit:"desktop"===t}},{id:"coverZoom",label:o("Zoom"),type:"slider",disabled:r,config:{min:100,max:300,units:[{value:"%",title:"%"}]}}]},{id:"tabCurrentElementAdvanced",label:o("Advanced"),options:[{id:"showTitle",label:o("Title"),type:"switch",devices:"desktop",disabled:r},{id:"showCurrentTime",label:o("Time"),type:"switch",devices:"desktop",disabled:r},{id:"showDurationTime",label:o("Duration"),type:"switch",devices:"desktop",disabled:r},{id:"showProgressBarTrack",label:o("Progress"),type:"switch",devices:"desktop",disabled:r},{id:"showProgressBarVolume",label:o("Volume"),type:"switch",devices:"desktop",disabled:r},{id:"caption",label:o("Captions (CC)"),type:"fileUpload",devices:"desktop",disabled:r,acceptedExtensions:["vtt"],helper:{content:o("Upload a .vtt file with captions for your video")}}]}]}]},{id:"popoverTypography",type:"popover",config:{icon:"nc-font",size:"desktop"===t?"large":"auto",title:o("Typography")},roles:["admin"],position:90,disabled:"on"!==i("showCurrentTime")&&"on"!==i("showDurationTime"),options:[{id:"",type:"typography",disabled:r,config:{fontFamily:"desktop"===t}}]}]},e4=({v:e,component:t,editorMode:s})=>{let{t:o,utils:{context:{isPopup:l,isStory:a},getEnabledLinkOptions:i}}=global.Brizy,r=l(s),n=!!t.props.meta?.sectionPopup2,{linkUpload:p,linkAction:d}=i(t.getGlobalConfig()),b="on"!==e.enableTooltip,c=t.props.renderer?.disableTooltip||a(s);return[{id:"toolbarCurrentShortcode",type:"popover",options:[{id:"currentShortcodeTabs",type:"tabs",tabs:[{id:"buttonTooltip",label:o("Tooltip"),options:[{id:"enableTooltip",label:o("Enable Tooltip"),type:"switch",devices:"desktop",disabled:c},{id:"tooltipText",label:o("Text"),disabled:b,type:"textarea",placeholder:o("Paste your text here"),devices:"desktop",config:{lines:3}},{id:"tooltipTriggerClick",label:o("Enable on Click"),helper:{content:o("Enable tooltip on click instead of hover")},type:"switch",disabled:b,devices:"desktop"}]}]}]},{id:"toolbarLink",type:"popover",options:[{id:"linkType",type:"tabs",config:{saveTab:!0},tabs:[{id:"upload",label:o("File"),options:[{id:"linkUpload",label:o("File"),type:"fileUpload",disabled:!p}]},{id:"action",label:o("Action"),options:[{id:"actionClosePopup",label:o("Close Popup"),type:"switch",devices:"desktop",disabled:!(n||r)||!d}]}]}]}]};function e1({component:e}){let{t,utils:{stateMode:{NORMAL:s,HOVER:o},getEnabledLinkOptions:l}}=global.Brizy,{linkUpload:a}=l(e.getGlobalConfig());return[{id:"toolbarCurrentElement",type:"popover",options:[{id:"tabsCurrentElement",type:"tabs",tabs:[{id:"filters",label:t("Filters"),options:[{id:"",type:"filters",states:[s,o]}]}]}]},{id:"toolbarLink",type:"popover",options:[{id:"linkType",type:"tabs",config:{saveTab:!0},tabs:[{id:"upload",label:t("File"),options:[{id:"linkUpload",label:t("File"),type:"fileUpload",disabled:!a}]}]}]},{id:"toolbarSettings",type:"popover",config:{icon:"nc-cog",title:t("Settings")},position:110,devices:"desktop",options:[{id:"grid",type:"grid",config:{separator:!0},columns:[{id:"grid-settings",width:50,options:[{id:"styles",type:"sidebarTabsButton",config:{text:t("Styling"),icon:"nc-cog",tabId:"styles"}}]}]}]}]}function e2({component:e,editorMode:t,v:s}){let{t:o,utils:{context:{isPopup:l,isStory:a},getEnabledLinkOptions:i}}=global.Brizy,r=!!e.props.meta?.sectionPopup2,n=a(t),p="on"===s.enableTooltip,{linkUpload:d,linkAction:b}=i(e.getGlobalConfig()),c=!p||n;return[{id:"toolbarCurrentShortcode",type:"popover",options:[{id:"currentShortcodeTabs",type:"tabs",tabs:[{id:"iconTooltip",label:o("Tooltip"),options:[{id:"enableTooltip",label:o("Enable Tooltip"),type:"switch",devices:"desktop",disabled:n},{id:"tooltipText",label:o("Text"),devices:"desktop",disabled:c,type:"textarea",placeholder:o("Paste your text here"),config:{lines:3}},{id:"tooltipTriggerClick",label:o("Enable on Click"),devices:"desktop",helper:{content:o("Enable tooltip on click instead of hover")},type:"switch",disabled:c}]}]}]},{id:"toolbarLink",type:"popover",options:[{id:"linkType",type:"tabs",config:{saveTab:!0},tabs:[{id:"upload",label:o("File"),options:[{id:"linkUpload",label:o("File"),type:"fileUpload",disabled:!d}]},{id:"action",label:o("Action"),options:[{id:"actionClosePopup",label:o("Close Popup"),type:"switch",devices:"desktop",disabled:!(r||l(t))||!b}]}]}]},{id:"advancedSettings",devices:"desktop",type:"advancedSettings",roles:["admin"],position:110,title:o("Settings")}]}let e3=({v:e,component:t,editorMode:s})=>{let{t:o,utils:{context:{isPopup:l,isStory:a},stateMode:{NORMAL:i,HOVER:r},getEnabledLinkOptions:n}}=global.Brizy,p=!!t.props.meta.sectionPopup2,d=a(s),{linkUpload:b,linkAction:c}=n(t.getGlobalConfig()),g="off"===e.enableTooltip||d;return[{id:"toolbarImage",type:"popover",options:[{id:"media",type:"tabs",tabs:[{id:"tabFilters",label:o("Filters"),options:[{id:"image",type:"filters",states:[i,r]}]},{id:"imageTooltip",label:o("Tooltip"),position:120,options:[{id:"enableTooltip",label:o("Enable Tooltip"),type:"switch",devices:"desktop",disabled:d},{id:"tooltipText",label:o("Text"),disabled:g,type:"textarea",placeholder:o("Paste your text here"),devices:"desktop",config:{lines:3}},{id:"tooltipTriggerClick",label:o("Enable on Click"),helper:{content:o("Enable tooltip on click instead of hover")},type:"switch",disabled:g,devices:"desktop"}]}]}]},{id:"toolbarLink",type:"popover",options:[{id:"linkType",type:"tabs",tabs:[{id:"upload",label:o("File"),options:[{id:"linkUpload",label:o("File"),type:"fileUpload",disabled:d||!b,devices:"desktop"}]},{id:"action",label:o("Action"),options:[{id:"actionClosePopup",label:o("Close Popup"),type:"switch",devices:"desktop",disabled:!(p||l(s))||!c}]}]}]}]};function e6({component:e}){let{t,utils:{getEnabledLinkOptions:s}}=global.Brizy,{linkUpload:o}=s(e.getGlobalConfig());return[{id:"toolbarLink",type:"popover",options:[{id:"linkType",type:"tabs",config:{saveTab:!0},tabs:[{id:"upload",label:t("File"),options:[{id:"linkUpload",label:t("File"),type:"fileUpload",disabled:!o}]}]}]}]}let e9=()=>{let{t:e,utils:{stateMode:{NORMAL:t,HOVER:s}}}=global.Brizy;return[{id:"toolbarCurrentElement",type:"popover",devices:"desktop",options:[{id:"tabsCurrentElement",type:"tabs",tabs:[{id:"filters",label:e("Filters"),options:[{id:"",type:"filters",states:[t,s],selector:"{{WRAPPER}}:hover .brz-ui-ed-iframe"}]}]}]}]};function e7({component:e}){let{t,utils:{getEnabledLinkOptions:s}}=global.Brizy,{linkUpload:o}=s(e.getGlobalConfig());return[{id:"toolbarLink",type:"popover",options:[{id:"linkType",type:"tabs",config:{saveTab:!0},tabs:[{id:"upload",label:t("File"),options:[{id:"linkUpload",label:t("File"),type:"fileUpload",disabled:!o}]}]}]}]}function e8({component:e}){let{t,utils:{getEnabledLinkOptions:s}}=global.Brizy,{linkUpload:o}=s(e.getGlobalConfig());return[{id:"toolbarLink",type:"popover",options:[{id:"linkType",type:"tabs",config:{saveTab:!0},tabs:[{id:"upload",label:t("File"),options:[{id:"linkUpload",label:t("File"),type:"fileUpload",disabled:!o}]}]}]}]}let te=({component:e})=>{let{t,utils:{stateMode:{NORMAL:s,HOVER:o},getEnabledLinkOptions:l}}=global.Brizy,{linkUpload:a}=l(e.getGlobalConfig());return[{id:"toolbarMedia",type:"popover",options:[{id:"tabsMedia",type:"tabs",tabs:[{id:"tabFilters",label:t("Filters"),options:[{id:"",type:"filters",states:[s,o]}]}]}]},{id:"toolbarLink",type:"popover",devices:"responsive",options:[{id:"linkType",type:"tabs",config:{saveTab:!0},tabs:[{id:"upload",label:t("File"),options:[{id:"linkUpload",label:t("File"),type:"fileUpload",disabled:!a}]}]}]}]};function tt(){let{t:e,utils:{stateMode:{NORMAL:t,HOVER:s}}}=global.Brizy;return[{id:"toolbarCurrentElement",type:"popover",options:[{id:"tabsCurrentElement",type:"tabs",tabs:[{id:"filters",label:e("Filters"),options:[{id:"",type:"filters",states:[t,s]}]}]}]}]}function ts(){let{t:e,utils:{stateMode:{NORMAL:t,HOVER:s}}}=global.Brizy;return[{id:"toolbarCurrentElement",type:"popover",options:[{id:"tabsCurrentElement",type:"tabs",tabs:[{id:"filters",label:e("Filters"),options:[{id:"",type:"filters",states:[t,s]}]}]}]}]}function to(){let{t:e,utils:{stateMode:{NORMAL:t,HOVER:s}}}=global.Brizy;return[{id:"toolbarCurrentElement",type:"popover",options:[{id:"tabsCurrentElement",type:"tabs",tabs:[{id:"filters",label:e("Filters"),options:[{id:"",type:"filters",states:[t,s]}]}]}]}]}function tl(){let{t:e,utils:{stateMode:{NORMAL:t,HOVER:s}}}=global.Brizy;return[{id:"toolbarCurrentElement",type:"popover",options:[{id:"tabsCurrentElement",type:"tabs",tabs:[{id:"filters",label:e("Filters"),options:[{id:"",type:"filters",states:[t,s]}]}]}]}]}function ta(){let{t:e,utils:{stateMode:{NORMAL:t,HOVER:s}}}=global.Brizy;return[{id:"toolbarMedia",type:"popover",options:[{id:"tabsMedia",type:"tabs",tabs:[{id:"tabFilters",label:e("Filters"),options:[{id:"",type:"filters",states:[t,s]}]}]}]},{id:"advancedSettings",type:"advancedSettings",devices:"desktop",roles:["admin"],position:110,title:e("Settings")}]}let ti=()=>{let{t:e,utils:{stateMode:{NORMAL:t,HOVER:s}}}=global.Brizy;return[{id:"toolbarMedia",type:"popover",options:[{id:"tabsMedia",type:"tabs",tabs:[{id:"tabFilters",label:e("Filters"),options:[{id:"",type:"filters",states:[t,s]}]}]}]}]};function tr(){let{t:e}=global.Brizy;return[{id:"toolbarCurrentElement",type:"popover",options:[{id:"tabsCurrentElement",type:"tabs",tabs:[{id:"filters",label:e("Filters"),options:[{id:"",type:"filters"}]}]}]}]}let tn=()=>{let{t:e,utils:{stateMode:{NORMAL:t,HOVER:s}}}=global.Brizy;return[{id:"toolbarCurrentElement",type:"popover",options:[{id:"tabsCurrentElement",type:"tabs",tabs:[{id:"tabCurrentElementFilter",label:e("Filters"),options:[{id:"",type:"filters",states:[t,s],selector:"{{WRAPPER}}:hover .brz-iframe, {{WRAPPER}}:hover .brz-video__cover:before, {{WRAPPER}}:hover.brz-custom-video video, {{WRAPPER}}:hover .brz-video__cover::before"}]}]}]}]},tp=global.Brizy;for(let[e,t]of Object.entries({Button:Z,Icon:J,Image:K,Video:ep,Audio:D,Map:Q,Column:q,Row:et,SectionItem:es,StoryItem:en,SectionFooter:eo,SectionHeaderItem:el,SectionHeaderStickyItem:ea,SectionPopup:ei,SectionPopup2:er,Lottie:N,PostTitle:ee,PostExcerpt:X,WPSidebar:V}))tp.addFilter(`toolbarItemsExtend_${e}`,()=>t);for(let[e,V]of Object.entries({AccordionParent:n,Button:c,Column:S,Countdown:m,Countdown2:u,Counter:z,EmbedCode:h,FormParent:f,Icon:T,IconTextParent:k,Image:_,Line:B,Map:A,ProgressBar:I,RichText:w,Row:M,SectionFooter:E,SectionHeaderItem:Y,SectionHeaderStickyItem:F,SectionItem:P,StoryItem:R,SectionPopup:x,SectionPopup2:U,SoundCloud:O,TabsParent:L,Video:j,Audio:b,TableParent:W,AnimatedHeadline:d,Alert:p,Calendly:g,TableOfContents:G,Price:r,Paypal:$,EcwidPrice:C,EcwidAddToCart:v,Wrapper:H,Cloneable:y,WPCustomShortcode:a,WPSidebar:i,WOOCategories:t,WOOProducts:l,WOOProductPage:o,WOOPages:s}))tp.addFilter(`sidebarItemsExtend_${e}`,()=>V);