<?php
/**
 * Plugin Name: Brizy Pro
 * Description: Extended functionality for the Brizy WordPress builder plugin.
 * Plugin URI: https://brizy.io/
 * Author: Brizy.io
 * Author URI: https://brizy.io/
 * Version: 2.8.14
 * Text Domain: brizy-pro
 * License: To be announced
 * Domain Path: /languages
 * Requires PHP: 7.4
 */

define('BRIZY_PRO_MINIMUM_PHP_VERSION', '7.4');

if (version_compare(PHP_VERSION, BRIZY_PRO_MINIMUM_PHP_VERSION, '<')) {
    // bail before the autoloader: the plugin code is not parsable on older PHP
    add_action('admin_notices', 'brizy_pro_php_version_notice');

    return;
}

function brizy_pro_php_version_notice()
{
    ?>
    <div class="notice notice-error is-dismissible">
        <p>
            <?php
            printf(
                'Brizy PRO requires PHP version %1$s or newer, your server is running PHP %2$s. <b>BRIZY PRO IS NOT RUNNING.</b>',
                BRIZY_PRO_MINIMUM_PHP_VERSION,
                PHP_VERSION
            );
            ?>
        </p>
    </div>
    <?php
}

// GPL Vault: neutralise Brizy Pro license-server calls.
// Additive — the injected mock license (admin/license.php) never touches Brizy's
// servers. This short-circuits the license/update endpoint so the mock key is
// never phoned home, no invalid-key error is cached (which would otherwise raise
// an admin notice and block updates), and WordPress update detection is left
// alone for GPL Vault to handle. Remove this block (to "END GPL Vault") to restore
// upstream behaviour.
add_filter( 'pre_http_request', function ( $preempt, $args, $url ) {
	if ( false === strpos( $url, 'brizy.io/account/misc/brizy-license' ) ) {
		return $preempt;
	}

	$body = array(
		'code'          => 'ok',
		'message'       => '',
		'name'          => 'Brizy Pro',
		'slug'          => 'brizy-pro',
		'plugin'        => defined( 'BRIZY_PRO_PLUGIN_BASE' ) ? BRIZY_PRO_PLUGIN_BASE : 'brizy-pro/brizy-pro.php',
		'new_version'   => defined( 'BRIZY_PRO_VERSION' ) ? BRIZY_PRO_VERSION : '',
		'requires'      => '',
		'requires_php'  => '',
		'tested'        => '',
		'download_link' => '',
		'sections'      => serialize( array( 'description' => '' ) ),
	);

	return array(
		'headers'  => array(),
		'body'     => wp_json_encode( $body ),
		'response' => array( 'code' => 200, 'message' => 'OK' ),
		'cookies'  => array(),
		'filename' => null,
	);
}, 10, 3 );
// END GPL Vault.

define('BRIZY_PRO_DEVELOPMENT', false );
define('BRIZY_PRO_VERSION', '2.8.14');
define('BRIZY_PRO_EDITOR_VERSION', BRIZY_PRO_DEVELOPMENT ? 'dev' : '256-wp' );
define('BRIZY_PRO_FILE', __FILE__);
define('BRIZY_REQUIRED_VERSION', '2.8.25');
define('BRIZY_PRO_PLUGIN_BASE', plugin_basename(BRIZY_PRO_FILE));
define('BRIZY_PRO_PLUGIN_PATH', dirname(BRIZY_PRO_FILE));
define('BRIZY_PRO_PLUGIN_URL', rtrim(plugin_dir_url(BRIZY_PRO_FILE), "/"));

include_once rtrim(BRIZY_PRO_PLUGIN_PATH, "/").'/autoload.php';
include_once rtrim(BRIZY_PRO_PLUGIN_PATH, "/").'/whitelabel/main.php';

if (BRIZY_PRO_DEVELOPMENT) {
    $dotenv = new \Symfony\Component\Dotenv\Dotenv('APP_ENV');
    $dotenv->load(__DIR__.'/.env');
}

add_action('plugins_loaded', 'brizy_pro_loaded', 11);
add_action('brizy_plugin_included', function () {

    if (version_compare(BRIZY_VERSION, BRIZY_REQUIRED_VERSION) < 0) {
        // show a notice if the free version of the plugin is not installed
        add_action('admin_notices', 'brizy_pro_notices');

        return;
    }

    $mainInstance = new BrizyPro_Main();
    $mainInstance->run();

    add_action('upgrader_process_complete', 'brizypro_upgrade_completed', 10, 2);
    register_activation_hook(BRIZY_PRO_FILE, 'brizypro_install');
});

function brizy_pro_loaded()
{
    if ( ! defined('BRIZY_VERSION')) {
        add_action('admin_notices', 'brizy_pro_notices');

        return;
    }

    BrizyPro_Admin_Updater::_init();
}

function brizy_pro_notices()
{

    $name = __bt('brizy', 'Brizy');

    ?>
    <div class="notice notice-error is-dismissible">
        <p>
            <?php echo $name ?> PRO requires <?php echo $name ?> Free <?php echo BRIZY_REQUIRED_VERSION ?> or newer.
            <b><?php echo strtoupper(__bt('brizy', 'Brizy')) ?> PRO IS NOT RUNNING. </b>
        </p>
    </div>
    <?php
}

/**
 * @param $upgrader_object
 * @param $options
 */
function brizypro_upgrade_completed($upgrader_object, $options)
{
    if ($options['action'] == 'update' && $options['type'] == 'plugin' && isset($options['plugins'])) {
        foreach ($options['plugins'] as $plugin) {
            if ($plugin == BRIZY_PRO_PLUGIN_BASE) {
                add_option('brizypro-regenerate-permalinks', 1);
            }
        }
    }
}

function brizypro_install()
{

    if (defined('BRIZY_VERSION')) {
        Brizy_Editor::get()->registerCustomPostTemplates();
    }

    $mainInstance = new BrizyPro_Main();
    $mainInstance->registerCustomPosts();

    add_option('brizypro-regenerate-permalinks', 1);
}
