<?php

class BrizyPro_Editor_ModuleGroups_WooArchive implements Brizy_Editor_Editor_ModuleGroups_ProviderInterface {

	use Brizy_Editor_Editor_ModuleGroups_ContextUtils;

	public function supportContext( $context ) {
		return $this->isWoocomerceEnabled() && $this->isTemplateType( $context, 'product_archive' );
	}

	public function collect( $context ) {
		return [
			new Brizy_Editor_Editor_ModuleGroups_ModuleGroup( __( 'product', 'brizy' ), [
				"WOOAddToCart",
				"WOOPrice",
				"WOOStock",
				"WOOProductMeta",
				"WOORating",
				"WOOExcerpt",
				"WOOSaleBadge",
				"WOOOutOfStockBadge",
			], 200 ),
		];
	}
}
