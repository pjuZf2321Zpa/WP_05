<?php
/*
 * Copyright (c) 2026 LatePoint LLC. All rights reserved.
 */

if ( ! class_exists( 'OsCartAbandonmentModel' ) ) :

	/**
	 * A snapshot of a cart taken at the customer step (email captured or login completed), well
	 * before an OsOrderIntentModel would normally exist. Deliberately independent of order intents -
	 * see the comment on LATEPOINT_TABLE_CART_ABANDONMENTS for why. A real order intent is only
	 * minted lazily, from this snapshot, at the moment the visitor clicks the resume link.
	 */
	class OsCartAbandonmentModel extends OsModel {

		public $id;
		public $abandonment_key;
		public $cart_id;
		public $customer_id;
		public $cart_items_data;
		public $booking_form_page_url;
		public $total;
		public $subtotal;
		public $status;
		public $order_id;
		public $created_at;
		public $updated_at;

		public function __construct( $id = false ) {
			$this->table_name = LATEPOINT_TABLE_CART_ABANDONMENTS;
			$this->nice_names = [
				'cart_id'     => __( 'Cart', 'latepoint-pro-features' ),
				'customer_id' => __( 'Customer', 'latepoint-pro-features' ),
			];

			parent::__construct( $id );
		}

		public function get_customer(): OsCustomerModel {
			if ( ! isset( $this->customer ) || ( isset( $this->customer ) && ( $this->customer->id != $this->customer_id ) ) ) {
				$this->customer = $this->customer_id ? new OsCustomerModel( $this->customer_id ) : new OsCustomerModel();
			}

			return $this->customer;
		}

		public function is_converted(): bool {
			return 'converted' === $this->status;
		}

		protected function before_create() {
			if ( empty( $this->abandonment_key ) ) {
				$this->abandonment_key = bin2hex( openssl_random_pseudo_bytes( 10 ) );
			}
			if ( empty( $this->status ) ) {
				$this->status = 'pending';
			}
		}

		protected function allowed_params( $role = 'admin' ) {
			return [
				'cart_id',
				'customer_id',
				'cart_items_data',
				'booking_form_page_url',
				'total',
				'subtotal',
				'status',
				'order_id',
			];
		}

		protected function params_to_save( $role = 'admin' ) {
			return [
				'abandonment_key',
				'cart_id',
				'customer_id',
				'cart_items_data',
				'booking_form_page_url',
				'total',
				'subtotal',
				'status',
				'order_id',
			];
		}

		protected function properties_to_validate() {
			return [
				'cart_id'     => [ 'presence' ],
				'customer_id' => [ 'presence' ],
			];
		}
	}

endif;
