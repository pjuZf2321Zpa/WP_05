<?php
/*
 * Copyright (c) 2024 LatePoint LLC. All rights reserved.
 */

if ( ! class_exists( 'OsEventWaitingListModel' ) ) :

	/**
	 * One customer's place in one event's waiting list.
	 *
	 * A queue entry is deliberately NOT an event registration. It holds a position, not a place:
	 * it must never consume capacity, never appear in the attendee list or the CSV export, never
	 * be issued a ticket and never be checked in. Keeping it in its own table makes all of that
	 * true by construction rather than by remembering to filter a status everywhere.
	 *
	 * A registration is created only when the customer actually takes the place, through the
	 * normal registration path, so e-tickets, ticket types and every `latepoint_event_registration_created`
	 * listener fire exactly as they do for anyone else.
	 */
	class OsEventWaitingListModel extends OsModel {

		public $id;
		public $event_id;
		public $customer_id;
		// Null on an event that sells one flat ticket, where the queue is for the event itself.
		public $ticket_type_id;
		public $quantity;
		public $status;
		public $active_lock;
		public $invite_token_hash;
		public $invited_at;
		public $invite_expires_at;
		public $converted_registration_id;
		public $converted_order_id;
		public $source_url;
		public $created_at;
		public $updated_at;

		public function __construct( $id = false ) {
			$this->table_name = LATEPOINT_TABLE_EVENT_WAITING_LIST;
			$this->nice_names = [
				'event_id'       => __( 'Event', 'latepoint-pro-features' ),
				'customer_id'    => __( 'Customer', 'latepoint-pro-features' ),
				'ticket_type_id' => __( 'Ticket Type', 'latepoint-pro-features' ),
				'quantity'       => __( 'Number of Places', 'latepoint-pro-features' ),
			];

			parent::__construct( $id );
		}

		// ─── Relationships ──────────────────────────────────────────────────────

		public function get_event(): ?OsEventModel {
			if ( ! isset( $this->event ) ) {
				$this->event = $this->event_id ? new OsEventModel( $this->event_id ) : null;
			}

			return $this->event;
		}

		public function get_customer(): ?OsCustomerModel {
			if ( ! isset( $this->customer ) ) {
				$this->customer = $this->customer_id ? new OsCustomerModel( $this->customer_id ) : null;
			}

			return $this->customer;
		}

		/**
		 * The ticket type this entry is queuing for, or null when the queue is for the event as a
		 * whole. Also null once a type has been deleted out from under a live entry.
		 */
		public function get_ticket_type(): ?OsEventTicketTypeModel {
			if ( ! isset( $this->ticket_type ) ) {
				$type              = $this->ticket_type_id ? new OsEventTicketTypeModel( $this->ticket_type_id ) : null;
				$this->ticket_type = ( $type && $type->id ) ? $type : null;
			}

			return $this->ticket_type;
		}

		public function get_registration(): ?OsEventRegistrationModel {
			if ( ! isset( $this->registration ) ) {
				$this->registration = $this->converted_registration_id ? new OsEventRegistrationModel( $this->converted_registration_id ) : null;
			}

			return $this->registration;
		}

		// ─── Status ─────────────────────────────────────────────────────────────

		/**
		 * Statuses in which the entry still occupies a place in the queue. Everything else is
		 * terminal and keeps only its history.
		 */
		public static function live_statuses(): array {
			return [
				LATEPOINT_EVENT_WAITING_LIST_STATUS_WAITING,
				LATEPOINT_EVENT_WAITING_LIST_STATUS_INVITED,
			];
		}

		public function is_live(): bool {
			return in_array( $this->status, self::live_statuses(), true );
		}

		public function is_invited(): bool {
			return LATEPOINT_EVENT_WAITING_LIST_STATUS_INVITED === $this->status;
		}

		public function is_converted(): bool {
			return LATEPOINT_EVENT_WAITING_LIST_STATUS_CONVERTED === $this->status;
		}

		/**
		 * Whether this entry is holding a live, unexpired invitation. An invitation whose window
		 * has closed is treated as dead the moment it is read, so a lapsed row can never keep a
		 * place reserved while its status still says invited.
		 */
		public function has_live_invite(): bool {
			if ( ! $this->is_invited() || ! $this->invite_token_hash ) {
				return false;
			}
			if ( ! $this->invite_expires_at ) {
				return true;
			}

			return strtotime( $this->invite_expires_at . ' UTC' ) > current_time( 'timestamp', true );
		}

		public function get_status_label(): string {
			$labels = [
				LATEPOINT_EVENT_WAITING_LIST_STATUS_WAITING   => __( 'Waiting', 'latepoint-pro-features' ),
				LATEPOINT_EVENT_WAITING_LIST_STATUS_INVITED   => __( 'Invited', 'latepoint-pro-features' ),
				LATEPOINT_EVENT_WAITING_LIST_STATUS_CONVERTED => __( 'Registered', 'latepoint-pro-features' ),
				LATEPOINT_EVENT_WAITING_LIST_STATUS_REMOVED   => __( 'Removed', 'latepoint-pro-features' ),
				LATEPOINT_EVENT_WAITING_LIST_STATUS_EXPIRED   => __( 'Expired', 'latepoint-pro-features' ),
			];

			return $labels[ $this->status ] ?? (string) $this->status;
		}

		/**
		 * The lock value that makes "one live entry per customer per event and ticket type" a
		 * database constraint. NULL for terminal rows, so any number of them may coexist.
		 *
		 * The ticket type is part of the key because somebody shut out of the front row may
		 * legitimately want to queue for the back row too; 0 stands for an event-level queue.
		 */
		public function build_active_lock(): ?string {
			if ( ! $this->is_live() || ! $this->event_id || ! $this->customer_id ) {
				return null;
			}

			return (int) $this->event_id . '-' . (int) $this->customer_id . '-' . (int) $this->ticket_type_id;
		}

		// ─── Persistence ────────────────────────────────────────────────────────

		protected function set_defaults() {
			if ( ! isset( $this->status ) ) {
				$this->status = LATEPOINT_EVENT_WAITING_LIST_STATUS_WAITING;
			}
			if ( ! isset( $this->quantity ) || (int) $this->quantity < 1 ) {
				$this->quantity = 1;
			}
		}

		protected function before_save() {
			// Kept in lockstep with status on every write, so the unique index cannot be bypassed
			// by a status change that forgets to clear it.
			$this->active_lock = $this->build_active_lock();
			$this->quantity    = max( 1, (int) $this->quantity );
		}

		/**
		 * Status is assigned server side only. It drives capacity and the invitation window, so it
		 * must never be mass-assignable from a request.
		 */
		protected function allowed_params( $role = 'admin' ) {
			return [
				'event_id',
				'customer_id',
				'quantity',
			];
		}

		protected function params_to_save( $role = 'admin' ) {
			return [
				'event_id',
				'customer_id',
				'ticket_type_id',
				'quantity',
				'status',
				'active_lock',
				'invite_token_hash',
				'invited_at',
				'invite_expires_at',
				'converted_registration_id',
				'converted_order_id',
				'source_url',
				'created_at',
				'updated_at',
			];
		}

		protected function properties_to_validate() {
			return [
				'event_id'    => [ 'presence' ],
				'customer_id' => [ 'presence' ],
			];
		}
	}

endif;
