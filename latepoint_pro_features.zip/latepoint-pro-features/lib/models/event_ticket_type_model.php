<?php
/*
 * Copyright (c) 2024 LatePoint LLC. All rights reserved.
 */

/**
 * A named, separately-priced ticket tier for one event — e.g. "General $20" / "VIP $50".
 *
 * Not to be confused with OsEventTicketModel, which is the individual QR-coded e-ticket issued
 * to an attendee (see feature_event_tickets_helper.php) — a registration that bought 2 of this
 * ticket type would get 2 of those, each optionally tagged with this type's id.
 */

if ( ! class_exists( 'OsEventTicketTypeModel' ) ) :

	class OsEventTicketTypeModel extends OsModel {

		public $id;
		public $event_id;
		public $name;
		public $price;
		public $capacity;
		public $order_number;
		public $status;
		public $created_at;
		public $updated_at;

		public function __construct( $id = false ) {
			$this->table_name = LATEPOINT_TABLE_EVENT_TICKET_TYPES;
			$this->nice_names = [
				'name' => __( 'Name', 'latepoint-pro-features' ),
			];

			parent::__construct( $id );
		}

		// ─── Relationship getters ──────────────────────────────────────────

		public function get_event(): ?OsEventModel {
			if ( ! isset( $this->event ) ) {
				$this->event = $this->event_id ? new OsEventModel( $this->event_id ) : null;
			}

			return $this->event;
		}

		// ─── Capacity ───────────────────────────────────────────────────────

		public function is_active(): bool {
			return $this->status === LATEPOINT_EVENT_TICKET_TYPE_STATUS_ACTIVE;
		}

		/**
		 * Sum of quantities purchased for this type across non-cancelled registrations.
		 */
		public function get_booked_quantity(): int {
			if ( ! $this->id ) {
				return 0;
			}
			global $wpdb;
			$total = $wpdb->get_var(
				$wpdb->prepare(
					'SELECT SUM(ertt.quantity) FROM ' . LATEPOINT_TABLE_EVENT_REGISTRATION_TICKET_TYPES . ' ertt' .
					' INNER JOIN ' . LATEPOINT_TABLE_EVENT_REGISTRATIONS . ' er ON er.id = ertt.registration_id' .
					' WHERE ertt.ticket_type_id = %d AND er.status NOT IN (%s)',
					$this->id,
					LATEPOINT_EVENT_REGISTRATION_STATUS_CANCELLED
				)
			);

			return (int) $total;
		}

		public function get_available_capacity(): int {
			if ( ! $this->capacity ) {
				return PHP_INT_MAX; // unlimited, so there is nothing to hold back and the filter is not reached
			}

			$available = max( 0, (int) $this->capacity - $this->get_booked_quantity() );

			/**
			 * Places this ticket type still has to sell.
			 *
			 * Lets an addon keep a type closed while places are technically free. A waiting list
			 * holds a freed place for the queue that is waiting on that type, rather than releasing
			 * it to whoever happens to be looking at the page. The event-wide equivalent is
			 * `latepoint_event_is_sold_out`.
			 *
			 * This is the only place a type's remaining capacity is worked out, so a filter here
			 * reaches the selector, the event's own total, and the checkout capacity check alike.
			 *
			 * @param {int}                    $available Places left before any addon adjusts it.
			 * @param {OsEventTicketTypeModel} $type      The ticket type being asked.
			 * @returns {int} The filtered number of places.
			 *
			 * @since 1.7.3
			 * @hook latepoint_event_ticket_type_available_capacity
			 *
			 */
			return max( 0, (int) apply_filters( 'latepoint_event_ticket_type_available_capacity', $available, $this ) );
		}

		public function is_sold_out(): bool {
			if ( ! $this->capacity ) {
				return false;
			}

			return $this->get_available_capacity() <= 0;
		}

		public function get_formatted_price(): string {
			return OsMoneyHelper::format_price( $this->get_effective_price(), true, false );
		}

		public function get_formatted_base_price(): string {
			return OsMoneyHelper::format_price( (float) $this->price, true, false );
		}

		// ─── Date-range pricing ─────────────────────────────────────────────

		/**
		 * @return OsEventTicketTypePriceRuleModel[] Ordered by order_number — resolution order.
		 */
		public function get_price_rules(): array {
			if ( ! isset( $this->price_rules ) ) {
				if ( ! $this->id ) {
					$this->price_rules = [];
				} else {
					$rule              = new OsEventTicketTypePriceRuleModel();
					$this->price_rules = $rule->where( [ 'ticket_type_id' => $this->id ] )->order_by( 'order_number asc' )->get_results_as_models();
				}
			}

			return $this->price_rules;
		}

		/**
		 * First rule (in order_number order) whose window covers $at_timestamp, or null if none
		 * does — overlapping rules are resolved by order, not by which one is "more specific".
		 *
		 * Gated on the event's "Enable tickets price by date range" toggle — a type can have rules saved
		 * while that's off (the admin form never deletes them, only hides the editor), so this is
		 * the single choke point every pricing path (get_effective_price(), the selector's
		 * strikethrough display, cart snapshotting) funnels through for that gate.
		 */
		public function get_active_price_rule( ?int $at_timestamp = null ): ?OsEventTicketTypePriceRuleModel {
			$event = $this->get_event();
			if ( ! $event || ! OsFeatureEventTicketTypesHelper::is_price_range_pricing_enabled_for_event( $event ) ) {
				return null;
			}
			foreach ( $this->get_price_rules() as $rule ) {
				if ( $rule->is_active_at( $at_timestamp ) ) {
					return $rule;
				}
			}

			return null;
		}

		/**
		 * The price to charge right now (or at $at_timestamp) — the active date-range rule's
		 * price, or this type's own base `price` when no rule is currently active.
		 *
		 * @param {float}                  $price Base price, before any rule is applied.
		 * @param {OsEventTicketTypeModel} $type  The ticket type being priced.
		 *
		 * @returns {float} The filtered effective price.
		 *
		 * @since 1.7.6
		 * @hook latepoint_event_ticket_type_effective_price
		 */
		public function get_effective_price( ?int $at_timestamp = null ): float {
			$rule  = $this->get_active_price_rule( $at_timestamp );
			$price = $rule ? (float) $rule->price : (float) $this->price;

			return (float) apply_filters( 'latepoint_event_ticket_type_effective_price', $price, $this );
		}

		// ─── Lifecycle ────────────────────────────────────────────────────

		protected function set_defaults() {
			if ( empty( $this->status ) ) {
				$this->status = LATEPOINT_EVENT_TICKET_TYPE_STATUS_ACTIVE;
			}
			if ( ! isset( $this->capacity ) || $this->capacity === null ) {
				$this->capacity = 0;
			}
			if ( ! isset( $this->order_number ) || $this->order_number === null ) {
				$this->order_number = 0;
			}
		}

		protected function before_create() {
			if ( empty( $this->created_at ) ) {
				$this->created_at = current_time( 'mysql', true );
			}
			$this->updated_at = current_time( 'mysql', true );
		}

		protected function before_save() {
			$this->updated_at = current_time( 'mysql', true );
		}

		// ─── Mass-assignment ──────────────────────────────────────────────

		protected function allowed_params( $role = 'admin' ) {
			return [
				'id',
				'event_id',
				'name',
				'price',
				'capacity',
				'order_number',
				'status',
				'created_at',
				'updated_at',
			];
		}

		protected function params_to_save( $role = 'admin' ) {
			return [
				'id',
				'event_id',
				'name',
				'price',
				'capacity',
				'order_number',
				'status',
				'created_at',
				'updated_at',
			];
		}

		protected function params_to_sanitize() {
			return [ 'price' => 'money' ];
		}

		protected function properties_to_validate() {
			return [
				'event_id' => [ 'presence' ],
				'name'     => [ 'presence' ],
			];
		}
	}

endif;
