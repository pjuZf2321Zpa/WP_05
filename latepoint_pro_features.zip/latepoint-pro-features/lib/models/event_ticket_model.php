<?php
/*
 * Copyright (c) 2024 LatePoint LLC. All rights reserved.
 */

if ( ! class_exists( 'OsEventTicketModel' ) ) :

	class OsEventTicketModel extends OsModel {

		public $id;
		public $ticket_code;
		public $registration_id;
		public $event_id;
		public $customer_id;
		public $ticket_number;
		public $ticket_type;
		public $ticket_type_id;
		public $status;
		public $checked_in_dates;
		public $last_scanned_at;
		public $created_at;
		public $updated_at;

		// Characters that are never ambiguous when read aloud or typed by hand (no 0/O/1/I/L).
		const CODE_ALPHABET = '23456789ABCDEFGHJKMNPQRSTUVWXYZ';

		public function __construct( $id = false ) {
			$this->table_name = LATEPOINT_TABLE_EVENT_TICKETS;
			$this->nice_names = [
				'ticket_code' => __( 'Ticket Code', 'latepoint-pro-features' ),
			];

			parent::__construct( $id );
		}

		// ─── Relationship getters ──────────────────────────────────────────

		public function get_registration(): ?OsEventRegistrationModel {
			if ( ! isset( $this->registration ) ) {
				$this->registration = $this->registration_id ? new OsEventRegistrationModel( $this->registration_id ) : null;
			}

			return $this->registration;
		}

		public function get_event(): ?OsEventModel {
			if ( ! isset( $this->event ) ) {
				$this->event = $this->event_id ? new OsEventModel( $this->event_id ) : null;
			}

			return $this->event;
		}

		public function get_customer(): ?OsCustomerModel {
			if ( ! isset( $this->customer ) ) {
				$this->customer = $this->customer_id ? new OsCustomerModel( $this->customer_id ) : null;
			}

			return $this->customer;
		}

		public function get_ticket_type(): ?OsEventTicketTypeModel {
			if ( ! isset( $this->ticket_type_model ) ) {
				$this->ticket_type_model = $this->ticket_type_id ? new OsEventTicketTypeModel( $this->ticket_type_id ) : null;
			}

			return $this->ticket_type_model;
		}

		/**
		 * Ticket type name to display — prefers the purchase-time snapshot saved on
		 * OsEventRegistrationTicketTypeModel, so renaming or disabling a type later never
		 * rewrites an already-issued ticket's label. Falls back to the live type only for
		 * tickets issued before that snapshot existed.
		 */
		public function get_ticket_type_name(): ?string {
			if ( ! $this->ticket_type_id ) {
				return null;
			}
			if ( ! isset( $this->ticket_type_snapshot_name ) ) {
				$join                            = new OsEventRegistrationTicketTypeModel();
				$rows                            = $join->where(
					[
						'registration_id' => $this->registration_id,
						'ticket_type_id'  => $this->ticket_type_id,
					]
				)->get_results_as_models();
				$this->ticket_type_snapshot_name = $rows[0]->name ?? null;
			}
			if ( $this->ticket_type_snapshot_name ) {
				return $this->ticket_type_snapshot_name;
			}
			$ticket_type = $this->get_ticket_type();

			return ( $ticket_type && $ticket_type->id ) ? $ticket_type->name : null;
		}

		/**
		 * Individual tickets that belong to the same registration as this one (excludes the group ticket itself).
		 *
		 * @return OsEventTicketModel[]
		 */
		public function get_sibling_individual_tickets(): array {
			$ticket = new OsEventTicketModel();

			return $ticket->where(
				[
					'registration_id' => $this->registration_id,
					'ticket_type'     => LATEPOINT_EVENT_TICKET_TYPE_INDIVIDUAL,
				]
			)->order_by( 'ticket_number asc' )->get_results_as_models();
		}

		// ─── Status helpers ────────────────────────────────────────────────

		public function is_group_ticket(): bool {
			return $this->ticket_type === LATEPOINT_EVENT_TICKET_TYPE_GROUP;
		}

		public function is_void(): bool {
			return $this->status === LATEPOINT_EVENT_TICKET_STATUS_VOID;
		}

		public function is_checked_in(): bool {
			return $this->status === LATEPOINT_EVENT_TICKET_STATUS_CHECKED_IN;
		}

		/**
		 * Mirrors Free's OsEventRegistrationModel::get_status_label() — translated label for
		 * $this->status, shared by the customer dashboard and admin scanner ticket lists instead
		 * of each inlining an untranslated ucwords(str_replace('_', ' ', $status)).
		 */
		public function get_status_label(): string {
			$labels = [
				LATEPOINT_EVENT_TICKET_STATUS_ISSUED     => __( 'Issued', 'latepoint-pro-features' ),
				LATEPOINT_EVENT_TICKET_STATUS_CHECKED_IN => __( 'Checked In', 'latepoint-pro-features' ),
				LATEPOINT_EVENT_TICKET_STATUS_VOID       => __( 'Void', 'latepoint-pro-features' ),
			];

			return $labels[ $this->status ] ?? ucfirst( $this->status );
		}

		/**
		 * @return array Map of date (Y-m-d) => ['at' => datetime UTC, 'by' => agent/user id]
		 */
		public function get_checked_in_dates(): array {
			if ( empty( $this->checked_in_dates ) ) {
				return [];
			}
			$decoded = json_decode( $this->checked_in_dates, true );

			return is_array( $decoded ) ? $decoded : [];
		}

		public function is_checked_in_on( string $date_key ): bool {
			$dates = $this->get_checked_in_dates();

			return ! empty( $dates[ $date_key ] );
		}

		/**
		 * Records a check-in for the given date (Y-m-d) and persists it.
		 */
		public function mark_checked_in( string $date_key, int $checked_in_by = 0 ): bool {
			$dates                  = $this->get_checked_in_dates();
			$dates[ $date_key ]     = [
				'at' => current_time( 'mysql', true ),
				'by' => $checked_in_by,
			];
			$this->checked_in_dates = wp_json_encode( $dates );
			$this->last_scanned_at  = current_time( 'mysql', true );
			$this->status           = LATEPOINT_EVENT_TICKET_STATUS_CHECKED_IN;

			return $this->save();
		}

		public function get_display_label(): string {
			if ( $this->is_group_ticket() ) {
				return __( 'Group Ticket', 'latepoint-pro-features' );
			}

			$total = count( $this->get_sibling_individual_tickets() );

			// translators: %1$d current ticket number, %2$d total tickets on the registration.
			$label = sprintf( __( 'Ticket %1$d of %2$d', 'latepoint-pro-features' ), max( 1, (int) $this->ticket_number ), max( 1, $total ) );

			$type_name = $this->get_ticket_type_name();
			if ( $type_name ) {
				// translators: %1$s ticket type name (e.g. "VIP"), %2$s the "Ticket X of Y" label.
				$label = sprintf( __( '%1$s — %2$s', 'latepoint-pro-features' ), $type_name, $label );
			}

			return $label;
		}

		// ─── URLs ────────────────────────────────────────────────────────

		public function get_public_url(): string {
			return OsRouterHelper::build_admin_post_link( OsRouterHelper::build_route_name( 'event_tickets', 'show' ), [ 'code' => $this->ticket_code ] );
		}

		public function get_qr_image_url(): string {
			return OsRouterHelper::build_admin_post_link( OsRouterHelper::build_route_name( 'event_tickets', 'qr_image' ), [ 'code' => $this->ticket_code ] );
		}

		public function get_pdf_download_url(): string {
			return OsRouterHelper::build_admin_post_link( OsRouterHelper::build_route_name( 'event_tickets', 'download_pdf' ), [ 'code' => $this->ticket_code ] );
		}

		// ─── Lifecycle ────────────────────────────────────────────────────

		protected function set_defaults() {
			if ( empty( $this->status ) ) {
				$this->status = LATEPOINT_EVENT_TICKET_STATUS_ISSUED;
			}
			if ( empty( $this->ticket_type ) ) {
				$this->ticket_type = LATEPOINT_EVENT_TICKET_TYPE_INDIVIDUAL;
			}
		}

		protected function before_create() {
			if ( empty( $this->ticket_code ) ) {
				$this->ticket_code = self::generate_unique_code();
			}
			if ( empty( $this->created_at ) ) {
				$this->created_at = current_time( 'mysql', true );
			}
			$this->updated_at = current_time( 'mysql', true );
		}

		protected function before_save() {
			$this->updated_at = current_time( 'mysql', true );
		}

		/**
		 * Generates a random, human-typeable code that isn't derivable from any known ID,
		 * retrying on the rare collision against the UNIQUE ticket_code index.
		 */
		public static function generate_unique_code(): string {
			$alphabet     = self::CODE_ALPHABET;
			$max_index    = strlen( $alphabet ) - 1;
			$max_attempts = 5;

			for ( $attempt = 0; $attempt < $max_attempts; $attempt++ ) {
				$code = '';
				for ( $i = 0; $i < 10; $i++ ) {
					$code .= $alphabet[ random_int( 0, $max_index ) ];
				}

				$existing = new OsEventTicketModel();
				$existing = $existing->where( [ 'ticket_code' => $code ] )->set_limit( 1 )->get_results_as_models();
				if ( empty( $existing ) ) {
					return $code;
				}
			}

			// Astronomically unlikely fallback: widen with a timestamp-based suffix to guarantee termination.
			return $code . strtoupper( base_convert( (string) time(), 10, 36 ) );
		}

		// ─── Mass-assignment ──────────────────────────────────────────────

		protected function allowed_params( $role = 'admin' ) {
			return [
				'id',
				'ticket_code',
				'registration_id',
				'event_id',
				'customer_id',
				'ticket_number',
				'ticket_type',
				'ticket_type_id',
				'status',
				'checked_in_dates',
				'last_scanned_at',
				'created_at',
				'updated_at',
			];
		}

		protected function params_to_save( $role = 'admin' ) {
			return [
				'id',
				'ticket_code',
				'registration_id',
				'event_id',
				'customer_id',
				'ticket_number',
				'ticket_type',
				'ticket_type_id',
				'status',
				'checked_in_dates',
				'last_scanned_at',
				'created_at',
				'updated_at',
			];
		}

		protected function properties_to_validate() {
			return [
				'registration_id' => [ 'presence' ],
				'event_id'        => [ 'presence' ],
			];
		}
	}

endif;
