<?php
/*
 * Copyright (c) 2024 LatePoint LLC. All rights reserved.
 */

/**
 * A date-range price override for one OsEventTicketTypeModel — e.g. "€20 until Mar 1" or
 * "€35 from Mar 25". Either bound may be empty: no start means active immediately, no end means
 * never expires. The ticket type's own `price` is untouched and remains the fallback whenever no
 * rule is currently active — see OsEventTicketTypeModel::get_effective_price().
 */

if ( ! class_exists( 'OsEventTicketTypePriceRuleModel' ) ) :

	class OsEventTicketTypePriceRuleModel extends OsModel {

		public $id;
		public $ticket_type_id;
		public $price;
		public $start_datetime_utc;
		public $end_datetime_utc;
		public $order_number;
		public $created_at;
		public $updated_at;

		public function __construct( $id = false ) {
			$this->table_name = LATEPOINT_TABLE_EVENT_TICKET_TYPE_PRICE_RULES;
			$this->nice_names = [
				'price' => __( 'Price', 'latepoint-pro-features' ),
			];

			parent::__construct( $id );
		}

		// ─── Relationship getters ──────────────────────────────────────────

		public function get_ticket_type(): ?OsEventTicketTypeModel {
			if ( ! isset( $this->ticket_type ) ) {
				$this->ticket_type = $this->ticket_type_id ? new OsEventTicketTypeModel( $this->ticket_type_id ) : null;
			}

			return $this->ticket_type;
		}

		// ─── Window check ───────────────────────────────────────────────────

		/**
		 * Whether this rule is the active price at $at_timestamp (defaults to now), in UTC.
		 * Mirrors the zero-date guard OsEventModel::is_registration_open() uses for the same
		 * optional-bound datetime columns.
		 */
		public function is_active_at( ?int $at_timestamp = null ): bool {
			$at_timestamp = $at_timestamp ?? current_time( 'timestamp', true );

			if ( $this->start_datetime_utc ) {
				$start = strtotime( $this->start_datetime_utc . ' UTC' );
				if ( $start > 0 && $at_timestamp < $start ) {
					return false;
				}
			}

			if ( $this->end_datetime_utc ) {
				$end = strtotime( $this->end_datetime_utc . ' UTC' );
				if ( $end > 0 && $at_timestamp > $end ) {
					return false;
				}
			}

			return true;
		}

		public function get_formatted_price(): string {
			return OsMoneyHelper::format_price( (float) $this->price, true, false );
		}

		// ─── Lifecycle ────────────────────────────────────────────────────

		protected function set_defaults() {
			if ( ! isset( $this->order_number ) || $this->order_number === null ) {
				$this->order_number = 0;
			}
		}

		protected function before_create() {
			if ( empty( $this->created_at ) ) {
				$this->created_at = current_time( 'mysql', true );
			}
			$this->updated_at = current_time( 'mysql', true );
		}

		protected function before_save() {
			$this->updated_at = current_time( 'mysql', true );
		}

		// ─── Mass-assignment ──────────────────────────────────────────────

		protected function allowed_params( $role = 'admin' ) {
			return [
				'id',
				'ticket_type_id',
				'price',
				'start_datetime_utc',
				'end_datetime_utc',
				'order_number',
				'created_at',
				'updated_at',
			];
		}

		protected function params_to_save( $role = 'admin' ) {
			return [
				'id',
				'ticket_type_id',
				'price',
				'start_datetime_utc',
				'end_datetime_utc',
				'order_number',
				'created_at',
				'updated_at',
			];
		}

		protected function params_to_sanitize() {
			return [ 'price' => 'money' ];
		}

		protected function properties_to_validate() {
			return [
				'ticket_type_id' => [ 'presence' ],
			];
		}
	}

endif;
