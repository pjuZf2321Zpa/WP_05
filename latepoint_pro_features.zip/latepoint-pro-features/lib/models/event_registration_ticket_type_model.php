<?php
/*
 * Copyright (c) 2024 LatePoint LLC. All rights reserved.
 */

/**
 * Join row recording how many of a given ticket type an event registration purchased.
 *
 * `name` and `price` are snapshotted at purchase time (same pattern as
 * OsBookingServiceExtraModel) so editing or deleting a ticket type later never rewrites a past
 * order's history.
 */

if ( ! class_exists( 'OsEventRegistrationTicketTypeModel' ) ) :

	class OsEventRegistrationTicketTypeModel extends OsModel {

		public $id;
		public $registration_id;
		public $ticket_type_id;
		public $name;
		public $quantity;
		public $price;
		public $created_at;
		public $updated_at;

		public function __construct( $id = false ) {
			$this->table_name = LATEPOINT_TABLE_EVENT_REGISTRATION_TICKET_TYPES;
			$this->nice_names = [
				'name' => __( 'Name', 'latepoint-pro-features' ),
			];

			parent::__construct( $id );
		}

		public function get_registration(): ?OsEventRegistrationModel {
			if ( ! isset( $this->registration ) ) {
				$this->registration = $this->registration_id ? new OsEventRegistrationModel( $this->registration_id ) : null;
			}

			return $this->registration;
		}

		public function get_ticket_type(): ?OsEventTicketTypeModel {
			if ( ! isset( $this->ticket_type ) ) {
				$this->ticket_type = $this->ticket_type_id ? new OsEventTicketTypeModel( $this->ticket_type_id ) : null;
			}

			return $this->ticket_type;
		}

		public function get_line_total(): float {
			return (float) $this->price * max( 0, (int) $this->quantity );
		}

		public function get_formatted_line_total(): string {
			return OsMoneyHelper::format_price( $this->get_line_total(), true, false );
		}

		// ─── Lifecycle ────────────────────────────────────────────────────

		protected function before_create() {
			if ( empty( $this->created_at ) ) {
				$this->created_at = current_time( 'mysql', true );
			}
			$this->updated_at = current_time( 'mysql', true );
		}

		protected function before_save() {
			$this->updated_at = current_time( 'mysql', true );
		}

		// ─── Mass-assignment ──────────────────────────────────────────────

		protected function allowed_params( $role = 'admin' ) {
			return [
				'id',
				'registration_id',
				'ticket_type_id',
				'name',
				'quantity',
				'price',
				'created_at',
				'updated_at',
			];
		}

		protected function params_to_save( $role = 'admin' ) {
			return [
				'id',
				'registration_id',
				'ticket_type_id',
				'name',
				'quantity',
				'price',
				'created_at',
				'updated_at',
			];
		}

		protected function params_to_sanitize() {
			return [ 'price' => 'money' ];
		}

		protected function properties_to_validate() {
			return [
				'registration_id' => [ 'presence' ],
				'name'            => [ 'presence' ],
			];
		}
	}

endif;
