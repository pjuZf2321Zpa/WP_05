<?php
/*
 * Copyright (c) 2024 LatePoint LLC. All rights reserved.
 */

/**
 * E-Tickets (QR check-in) for Events.
 *
 * Notifications for 'event_registration_created'/'_cancelled' are scheduled solely by Free's
 * OsEventsHooksHelper, off whatever workflow the user configured in Automation — this helper never
 * schedules a job itself, and never supplies anything that engine depends on to function (the
 * object_model_type/event_time_utc cases and the base {{event_name}} etc. replacement vars are
 * Free's own responsibility, so the trigger works with Pro deactivated). This helper only
 * issues/voids ticket rows on those same hooks and layers the E-Ticket-specific
 * {{event_tickets_qr}}/{{event_tickets_url}} vars on top, once Free's base vars are resolved.
 */
class OsFeatureEventTicketsHelper {

	public static function init_hooks(): void {
		// ── Settings ───────────────────────────────────────────────────────
		add_action( 'latepoint_general_settings_section_events_after', [ __CLASS__, 'output_settings' ], 15 );

		// ── Admin menu ─────────────────────────────────────────────────────
		add_filter( 'latepoint_side_menu', [ __CLASS__, 'add_check_in_menu_item' ] );

		// ── Capabilities ───────────────────────────────────────────────────
		add_filter( 'latepoint_capabilities_for_controllers', [ __CLASS__, 'add_capabilities_for_controller' ] );

		// ── Ticket issuance / voiding ──────────────────────────────────────
		add_action( 'latepoint_event_registration_created', [ __CLASS__, 'issue_tickets_for_registration' ] );
		add_action( 'latepoint_event_registration_cancelled', [ __CLASS__, 'void_tickets_for_registration' ] );
		add_action( 'latepoint_event_deleted', [ __CLASS__, 'delete_tickets_for_event' ] );

		// ── Notifications (Processes engine) — QR-ticket-specific vars only; the base
		// object_model_type/event_time_utc/replacement-vars wiring for event_registration_created/
		// _cancelled lives entirely in Free's OsEventsHooksHelper so it works without Pro ──
		add_filter( 'latepoint_replace_all_vars_in_template', [ __CLASS__, 'replace_vars_in_template' ], 10, 3 );
		add_action( 'latepoint_available_vars_event', [ __CLASS__, 'output_available_vars' ] );
		add_filter( 'latepoint_process_prepare_data_for_run', [ __CLASS__, 'attach_ticket_pdfs' ] );

		// ── Customer dashboard ──────────────────────────────────────────────
		add_action( 'latepoint_customer_dashboard_after_tabs', [ __CLASS__, 'render_customer_dashboard_tab_trigger' ] );
		add_action( 'latepoint_customer_dashboard_after_tab_contents', [ __CLASS__, 'render_customer_dashboard_tickets' ] );
	}

	// ─── Settings ───────────────────────────────────────────────────────────

	public static function is_enabled(): bool {
		return OsSettingsHelper::is_on( 'enable_event_etickets' );
	}

	public static function output_settings(): void {
		?>
		<div class="sub-section-row">
			<div class="sub-section-label">
				<h3><?php esc_html_e( 'E-Tickets', 'latepoint-pro-features' ); ?></h3>
			</div>
			<div class="sub-section-content">
				<?php
				echo OsFormHelper::toggler_field(
					'settings[enable_event_etickets]',
					__( 'Enable E-Tickets - QR Code', 'latepoint-pro-features' ),
					self::is_enabled(),
					false,
					false,
					[ 'sub_label' => __( 'When enabled, every event registration gets a e-ticket with QR code, emailed to the customer and scannable at check-in.', 'latepoint-pro-features' ) ]
				);
				?>
			</div>
		</div>
		<?php
	}

	// ─── Capabilities ───────────────────────────────────────────────────────

	/**
	 * OsEventTicketsController was never registered here, so every action fell back to
	 * settings__edit — an agent with scoped event-registration access couldn't scan tickets
	 * without also being able to edit all plugin settings. Reuses Free's event_registration__*
	 * capabilities rather than adding a new capability just for this controller.
	 */
	public static function add_capabilities_for_controller( array $capabilities ): array {
		$capabilities['OsEventTicketsController'] = [
			'default'    => [ 'event_registration__view' ],
			'per_action' => [
				'validate' => [ 'event_registration__edit' ],
				'check_in' => [ 'event_registration__edit' ],
			],
		];

		return $capabilities;
	}

	// ─── Admin menu ───────────────────────────────────────────────────────

	/**
	 * Free always declares an Events > Tickets menu item pointing at an upgrade teaser
	 * (OsProController::event_tickets()) — see lib/helpers/menu_helper.php in the base plugin.
	 * With this addon active it's repointed to the real scanner route regardless of the
	 * enable_event_etickets setting; when that setting is off, scanner.php renders a notice
	 * prompting the user to enable it (same treatment as Assets). The append branch is a
	 * fallback for a Free version that predates the placeholder.
	 */
	public static function add_check_in_menu_item( array $menu_items ): array {
		$tickets_link = OsRouterHelper::build_link( OsRouterHelper::build_route_name( 'event_tickets', 'scanner' ) );

		foreach ( $menu_items as &$item ) {
			if ( ! isset( $item['id'] ) || 'events' !== $item['id'] || empty( $item['children'] ) ) {
				continue;
			}

			$found = false;
			foreach ( $item['children'] as $key => $child ) {
				if ( isset( $child['id'] ) && 'tickets' === $child['id'] ) {
					$found                            = true;
					$item['children'][ $key ]['link'] = $tickets_link;
				}
			}

			if ( ! $found ) {
				$item['children'][] = [
					'id'    => 'tickets',
					'label' => __( 'Tickets', 'latepoint-pro-features' ),
					'icon'  => '',
					'link'  => $tickets_link,
				];
			}
		}
		unset( $item );

		return $menu_items;
	}

	// ─── Ticket issuance ────────────────────────────────────────────────────

	public static function issue_tickets_for_registration( OsEventRegistrationModel $reg ): void {
		if ( ! self::is_enabled() ) {
			return;
		}
		if ( self::get_tickets_for_registration( $reg->id ) ) {
			return; // already issued
		}

		$quantity     = max( 1, (int) $reg->quantity );
		$type_for_seq = self::build_ticket_type_sequence( $reg->id, $quantity );

		for ( $i = 1; $i <= $quantity; $i++ ) {
			$ticket                  = new OsEventTicketModel();
			$ticket->registration_id = $reg->id;
			$ticket->event_id        = $reg->event_id;
			$ticket->customer_id     = $reg->customer_id;
			$ticket->ticket_number   = $i;
			$ticket->ticket_type     = LATEPOINT_EVENT_TICKET_TYPE_INDIVIDUAL;
			$ticket->ticket_type_id  = $type_for_seq[ $i ] ?? null;
			$ticket->save();
		}

		if ( $quantity > 1 ) {
			$group_ticket                  = new OsEventTicketModel();
			$group_ticket->registration_id = $reg->id;
			$group_ticket->event_id        = $reg->event_id;
			$group_ticket->customer_id     = $reg->customer_id;
			$group_ticket->ticket_number   = 0;
			$group_ticket->ticket_type     = LATEPOINT_EVENT_TICKET_TYPE_GROUP;
			$group_ticket->save();
		}
	}

	/**
	 * Expands a registration's Ticket Types breakdown (OsFeatureEventTicketTypesHelper) into a
	 * ticket_number => ticket_type_id map, so each individual QR ticket issued above can be
	 * tagged with the type it was bought as (see OsEventTicketModel::get_ticket_type()). Empty
	 * when the registration has no breakdown — every ticket_type_id stays null, unchanged from
	 * before Ticket Types existed.
	 *
	 * @return array<int,int>
	 */
	private static function build_ticket_type_sequence( int $registration_id, int $quantity ): array {
		if ( ! class_exists( 'OsFeatureEventTicketTypesHelper' ) ) {
			return [];
		}
		$rows = OsFeatureEventTicketTypesHelper::get_types_for_registration( $registration_id );
		if ( empty( $rows ) ) {
			return [];
		}

		$sequence      = [];
		$ticket_number = 1;
		foreach ( $rows as $row ) {
			for ( $n = 0; $n < (int) $row->quantity && $ticket_number <= $quantity; $n++ ) {
				$sequence[ $ticket_number ] = (int) $row->ticket_type_id;
				++$ticket_number;
			}
		}

		return $sequence;
	}

	public static function void_tickets_for_registration( OsEventRegistrationModel $reg ): void {
		foreach ( self::get_tickets_for_registration( $reg->id ) as $ticket ) {
			if ( $ticket->is_void() ) {
				continue;
			}
			$ticket->status = LATEPOINT_EVENT_TICKET_STATUS_VOID;
			$ticket->save();
		}
	}

	/**
	 * Deletes all tickets for an event once it's gone — latepoint_event_deleted otherwise leaves
	 * them orphaned with their public show/qr_image/download_pdf URLs still live indefinitely.
	 */
	public static function delete_tickets_for_event( OsEventModel $event ): void {
		( new OsEventTicketModel() )->delete_where( [ 'event_id' => $event->id ] );
	}

	// ─── Lookups ────────────────────────────────────────────────────────────

	/**
	 * @return OsEventTicketModel[]
	 */
	public static function get_tickets_for_registration( int $registration_id ): array {
		$ticket = new OsEventTicketModel();

		return $ticket->where( [ 'registration_id' => $registration_id ] )->order_by( 'ticket_number asc' )->get_results_as_models();
	}

	/**
	 * @return OsEventTicketModel[]
	 */
	public static function get_tickets_for_event( int $event_id, string $search = '' ): array {
		global $wpdb;

		$ticket = new OsEventTicketModel();
		$ticket->where( [ 'event_id' => $event_id ] );
		if ( '' !== $search ) {
			$like = '%' . $wpdb->esc_like( sanitize_text_field( $search ) ) . '%';
			$ticket->where( [ 'ticket_code LIKE' => $like ] );
		}

		return $ticket->order_by( 'ticket_number asc' )->set_limit( 200 )->get_results_as_models();
	}

	/**
	 * @return OsEventTicketModel[]
	 */
	public static function get_upcoming_tickets_for_customer( int $customer_id ): array {
		$ticket = new OsEventTicketModel();

		return $ticket->where( [ 'customer_id' => $customer_id ] )->where( [ 'status !=' => LATEPOINT_EVENT_TICKET_STATUS_VOID ] )->order_by( 'event_id asc, ticket_number asc' )->get_results_as_models();
	}

	public static function get_ticket_by_code( string $raw_code ): ?OsEventTicketModel {
		$code = self::extract_code_from_input( $raw_code );
		if ( empty( $code ) ) {
			return null;
		}
		$ticket = ( new OsEventTicketModel() )->where( [ 'ticket_code' => $code ] )->set_limit( 1 )->get_results_as_models();

		return empty( $ticket ) ? null : $ticket;
	}

	/**
	 * Normalizes manual entry and pulls the `code` query arg back out of a scanned URL
	 * (the QR encodes the public ticket page URL, see OsEventTicketQrHelper::build_qr_payload()).
	 */
	public static function extract_code_from_input( string $raw ): string {
		$raw = trim( $raw );
		if ( '' === $raw ) {
			return '';
		}

		if ( filter_var( $raw, FILTER_VALIDATE_URL ) ) {
			$parsed = wp_parse_url( $raw );
			if ( ! empty( $parsed['query'] ) ) {
				parse_str( $parsed['query'], $query_args );
				if ( ! empty( $query_args['code'] ) ) {
					$raw = $query_args['code'];
				}
			}
		}

		return strtoupper( preg_replace( '/[^A-Za-z0-9]/', '', $raw ) );
	}

	// ─── Scan validation / check-in ─────────────────────────────────────────

	public static function validate_scan( string $raw_code, ?string $scanned_on = null ): array {
		$scanned_on = $scanned_on ?: current_time( 'Y-m-d' );
		$ticket     = self::get_ticket_by_code( $raw_code );

		if ( ! $ticket ) {
			return self::verdict( 'not_found', __( 'Ticket not found.', 'latepoint-pro-features' ) );
		}

		return self::process_ticket_scan( $ticket, $scanned_on, self::get_current_checked_in_by_id() );
	}

	public static function check_in_ticket_by_id( int $ticket_id ): array {
		$ticket = new OsEventTicketModel( $ticket_id );
		if ( $ticket->is_new_record() ) {
			return self::verdict( 'not_found', __( 'Ticket not found.', 'latepoint-pro-features' ) );
		}

		return self::process_ticket_scan( $ticket, current_time( 'Y-m-d' ), self::get_current_checked_in_by_id() );
	}

	private static function get_current_checked_in_by_id(): int {
		$user = OsAuthHelper::get_current_user();
		if ( $user->agent ) {
			return (int) $user->agent->id;
		}
		if ( $user->wp_user ) {
			return (int) $user->wp_user->ID;
		}

		return 0;
	}

	private static function process_ticket_scan( OsEventTicketModel $ticket, string $scanned_on, int $checked_in_by ): array {
		$reg = $ticket->get_registration();
		if ( ! $reg || $reg->is_new_record() || $reg->is_cancelled() ) {
			return self::verdict( 'registration_cancelled', __( 'This registration has been cancelled.', 'latepoint-pro-features' ), $ticket );
		}

		$event = $ticket->get_event();
		if ( ! $event || $event->is_new_record() || $event->status === LATEPOINT_EVENT_STATUS_CANCELLED ) {
			return self::verdict( 'event_cancelled', __( 'This event has been cancelled.', 'latepoint-pro-features' ), $ticket );
		}

		if ( $ticket->is_void() ) {
			return self::verdict( 'void', __( 'This ticket is no longer valid.', 'latepoint-pro-features' ), $ticket );
		}

		if ( ! self::is_date_within_event( $event, $scanned_on ) ) {
			return self::verdict( 'not_valid_for_date', __( 'This ticket is not valid today.', 'latepoint-pro-features' ), $ticket );
		}

		if ( $ticket->is_group_ticket() ) {
			$siblings  = $ticket->get_sibling_individual_tickets();
			$remaining = array_filter(
				$siblings,
				function ( $sibling ) use ( $scanned_on ) {
					return ! $sibling->is_void() && ! $sibling->is_checked_in_on( $scanned_on );
				}
			);

			if ( empty( $remaining ) ) {
				return self::verdict( 'all_already_scanned', __( 'All tickets in this group have already been checked in today.', 'latepoint-pro-features' ), $ticket );
			}

			$was_partial = count( $remaining ) < count( $siblings );
			foreach ( $remaining as $sibling ) {
				$sibling->mark_checked_in( $scanned_on, $checked_in_by );
			}
			$ticket->mark_checked_in( $scanned_on, $checked_in_by );
			self::maybe_mark_registration_checked_in( $reg, $scanned_on );

			$verdict_code = $was_partial ? 'group_partially_scanned' : 'valid';
			$message      = $was_partial
				? sprintf(
					/* translators: %d: number of attendees just checked in */
					__( 'Checked in %d remaining attendee(s) in this group.', 'latepoint-pro-features' ),
					count( $remaining )
				)
				: __( 'Group ticket valid — all attendees checked in.', 'latepoint-pro-features' );

			return self::verdict( $verdict_code, $message, $ticket );
		}

		if ( $ticket->is_checked_in_on( $scanned_on ) ) {
			return self::verdict( 'already_scanned', __( 'This ticket has already been checked in today.', 'latepoint-pro-features' ), $ticket );
		}

		$ticket->mark_checked_in( $scanned_on, $checked_in_by );
		self::maybe_mark_registration_checked_in( $reg, $scanned_on );

		return self::verdict( 'valid', __( 'Ticket valid — checked in.', 'latepoint-pro-features' ), $ticket );
	}

	private static function maybe_mark_registration_checked_in( ?OsEventRegistrationModel $reg, string $date_key ): void {
		if ( ! $reg || $reg->is_cancelled() ) {
			return;
		}
		$individuals = ( new OsEventTicketModel() )->where(
			[
				'registration_id' => $reg->id,
				'ticket_type'     => LATEPOINT_EVENT_TICKET_TYPE_INDIVIDUAL,
				'status !='       => LATEPOINT_EVENT_TICKET_STATUS_VOID,
			]
		)->get_results_as_models();

		if ( empty( $individuals ) ) {
			return;
		}
		foreach ( $individuals as $individual ) {
			if ( ! $individual->is_checked_in_on( $date_key ) ) {
				return;
			}
		}

		if ( $reg->status !== LATEPOINT_EVENT_REGISTRATION_STATUS_CHECKED_IN ) {
			$reg->status = LATEPOINT_EVENT_REGISTRATION_STATUS_CHECKED_IN;
			$reg->save();
		}
	}

	/**
	 * Multi-day events admit a ticket once per calendar day of the event, not once for the whole
	 * run — checked against OsEventDateModel ranges when present, else the event's own start/end.
	 */
	private static function is_date_within_event( OsEventModel $event, string $date_key ): bool {
		$timezone = OsTimeHelper::get_wp_timezone_name();
		$dates    = $event->get_dates();
		$ranges   = [];
		if ( $dates ) {
			foreach ( $dates as $date ) {
				$ranges[] = [ $date->start_datetime_utc, $date->end_datetime_utc ];
			}
		} else {
			$ranges[] = [ $event->start_datetime_utc, $event->end_datetime_utc ];
		}

		foreach ( $ranges as $range ) {
			list( $start_utc, $end_utc ) = $range;
			if ( empty( $start_utc ) ) {
				continue;
			}
			try {
				$start_local = new OsWpDateTime( $start_utc, new DateTimeZone( 'UTC' ) );
				$start_local->setTimezone( new DateTimeZone( $timezone ) );
				$end_local = new OsWpDateTime( $end_utc ?: $start_utc, new DateTimeZone( 'UTC' ) );
				$end_local->setTimezone( new DateTimeZone( $timezone ) );
			} catch ( Exception $e ) {
				continue;
			}

			if ( $date_key >= $start_local->format( 'Y-m-d' ) && $date_key <= $end_local->format( 'Y-m-d' ) ) {
				return true;
			}
		}

		return false;
	}

	private static function verdict( string $verdict_code, string $message, ?OsEventTicketModel $ticket = null ): array {
		$result = [
			'verdict' => $verdict_code,
			'message' => $message,
		];

		if ( $ticket ) {
			$event    = $ticket->get_event();
			$reg      = $ticket->get_registration();
			$customer = $ticket->get_customer();

			$result['ticket'] = [
				'id'                => $ticket->id,
				'code'              => $ticket->ticket_code,
				'label'             => $ticket->get_display_label(),
				'is_group'          => $ticket->is_group_ticket(),
				'status'            => $ticket->status,
				'event_name'        => $event ? $event->name : '',
				'registration_code' => $reg ? $reg->registration_code : '',
				'customer_name'     => $customer ? $customer->full_name : '',
			];
		}

		return $result;
	}

	// ─── Notification pipeline (Processes engine) ──────────────────────────

	/**
	 * Only the two E-Ticket-specific vars — object_model_type, event_time_utc, and the base
	 * event_registration replacement vars ({{event_name}}, {{registration_code}}, etc.) are
	 * Free's responsibility (OsEventsHooksHelper), since the trigger itself must work without
	 * Pro. This runs after Free's own replace_vars_in_template (same default priority, Free's
	 * OsEventsHooksHelper::init_hooks() registers first), filling in QR content on top of it.
	 */
	public static function replace_vars_in_template( string $text, array $vars, string $original_text ): string {
		if ( empty( $vars['event_registration'] ) ) {
			return $text;
		}

		$reg     = $vars['event_registration'];
		$tickets = self::get_tickets_for_registration( $reg->id );

		$needles      = [
			'{{event_tickets_qr}}',
			'{{event_tickets_url}}',
		];
		$replacements = [
			self::build_tickets_qr_html( $tickets ),
			$tickets ? esc_url( $tickets[0]->get_public_url() ) : '',
		];

		return str_replace( $needles, $replacements, $text );
	}

	private static function build_tickets_qr_html( array $tickets ): string {
		if ( empty( $tickets ) ) {
			return '';
		}

		$html = '<div class="event-tickets-qr-block">';
		foreach ( $tickets as $ticket ) {
			$html .= '<div class="event-ticket-qr-item" style="margin-bottom:16px;text-align:center;">';
			$html .= '<img src="' . esc_url( $ticket->get_qr_image_url() ) . '" width="160" height="160" alt="' . esc_attr( $ticket->ticket_code ) . '" style="display:block;margin:0 auto 6px;">';
			$html .= '<div style="font-size:13px;color:#555;">' . esc_html( $ticket->get_display_label() ) . ' &middot; ' . esc_html( $ticket->ticket_code ) . '</div>';
			$html .= '<div><a href="' . esc_url( $ticket->get_public_url() ) . '">' . esc_html__( 'View Ticket', 'latepoint-pro-features' ) . '</a></div>';
			$html .= '</div>';
		}
		$html .= '</div>';

		return $html;
	}

	public static function output_available_vars(): void {
		?>
		<li><span class="var-label"><?php esc_html_e( 'Event Tickets (QR images)', 'latepoint-pro-features' ); ?></span> <span class="var-code os-click-to-copy">{{event_tickets_qr}}</span></li>
		<li><span class="var-label"><?php esc_html_e( 'First Ticket URL', 'latepoint-pro-features' ); ?></span> <span class="var-code os-click-to-copy">{{event_tickets_url}}</span></li>
		<?php
	}

	/**
	 * Attaches one PDF per ticket to the registration-confirmation email. Temp files are listed
	 * under `_attachments_temp_files`, which ProcessAction::run() deletes right after wp_mail().
	 */
	public static function attach_ticket_pdfs( \LatePoint\Misc\ProcessAction $action ): \LatePoint\Misc\ProcessAction {
		if ( 'send_email' !== $action->type || ! self::is_enabled() ) {
			return $action;
		}

		foreach ( $action->selected_data_objects as $data_object ) {
			if ( 'event_registration' !== $data_object['model'] ) {
				continue;
			}
			$reg = $data_object['model_ready'] ?? new OsEventRegistrationModel( $data_object['id'] );
			if ( $reg->is_new_record() ) {
				continue;
			}

			$temp_files = [];
			foreach ( self::get_tickets_for_registration( $reg->id ) as $ticket ) {
				if ( $ticket->is_void() ) {
					continue;
				}
				$pdf_path = OsEventTicketQrHelper::build_ticket_pdf_temp_file( $ticket );
				if ( $pdf_path ) {
					$display_name = OsEventTicketQrHelper::build_ticket_display_filename( $ticket );

					$action->prepared_data_for_run['attachments'][ $display_name ] = $pdf_path;
					$temp_files[] = $pdf_path;
				}
			}

			if ( $temp_files ) {
				$action->prepared_data_for_run['_attachments_temp_files'] = array_merge(
					$action->prepared_data_for_run['_attachments_temp_files'] ?? [],
					$temp_files
				);
			}
		}

		return $action;
	}

	// ─── Customer dashboard ─────────────────────────────────────────────────

	public static function render_customer_dashboard_tab_trigger( OsCustomerModel $customer ): void {
		if ( ! self::is_enabled() ) {
			return;
		}
		?>
		<a href="#" data-tab-target=".tab-content-customer-event-tickets" class="latepoint-tab-trigger"><?php esc_html_e( 'Event Tickets', 'latepoint-pro-features' ); ?></a>
		<?php
	}

	public static function render_customer_dashboard_tickets( OsCustomerModel $customer ): void {
		if ( ! self::is_enabled() ) {
			return;
		}
		$tickets = self::get_upcoming_tickets_for_customer( $customer->id );
		$context = 'customer';
		?>
		<div class="latepoint-tab-content tab-content-customer-event-tickets">
			<?php if ( empty( $tickets ) ) : ?>
				<p><?php esc_html_e( 'No event tickets yet.', 'latepoint-pro-features' ); ?></p>
			<?php else : ?>
				<?php include LATEPOINT_ADDON_PRO_VIEWS_ABSPATH . 'event_tickets/_tickets_list.php'; ?>
			<?php endif; ?>
		</div>
		<?php
	}
}
