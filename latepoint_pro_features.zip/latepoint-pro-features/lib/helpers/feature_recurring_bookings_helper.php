<?php
/*
 * Copyright (c) 2024 LatePoint LLC. All rights reserved.
 */

class OsFeatureRecurringBookingsHelper {

	public static string $step_code = 'booking__recurring_bookings';


	/**
	 * Hooks for the admin order quick edit screen (#396). Registered from one call in the bootstrap so the
	 * feature owns its own wiring.
	 *
	 * @return void
	 */
	public static function init_admin_hooks() {
		add_action( 'latepoint_booking_data_form_after', [ self::class, 'output_admin_recurring_section' ], 11, 2 );
		add_filter( 'latepoint_order_quick_edit_has_extra_variants', [ self::class, 'has_recurring_variant' ], 10, 2 );
		add_action( 'latepoint_order_quick_edit_variant_tiles', [ self::class, 'output_recurring_variant_tile' ] );
		add_action( 'latepoint_order_quick_edit_item_pickers', [ self::class, 'output_recurring_services_picker' ] );
		add_action( 'latepoint_order_quick_edit_booking_items_after', [ self::class, 'output_recurring_groups' ], 10, 2 );
		add_filter( 'latepoint_order_item_pill_for_booking', [ self::class, 'recurring_order_item_pill' ], 10, 3 );
		add_action( 'latepoint_model_set_data', [ self::class, 'sanitize_recurrence_id_on_booking' ], 10, 2 );
		add_filter( 'latepoint_capabilities_for_controllers', [ self::class, 'add_capabilities_for_controller' ] );
	}


	public static function save_recurring_settings_in_service( $service, $is_new_record, $service_params ) {

		if ( isset( $service_params['meta'] ) ) {
			foreach ( [ 'allow_recurring_bookings', 'maximum_number_of_recurring_bookings', 'allow_recurring_periods' ] as $service_meta_key ) {
				if ( $service_meta_value = ( $service_params['meta'][ $service_meta_key ] ?? false ) ) {
					$service->save_meta_by_key( $service_meta_key, $service_meta_value );
				}
			}
		}
	}


	public static function add_recurring_modal_to_datepicker_step( string $step_code ) {
		if ( $step_code == 'booking__datepicker' ) {
			?>
			<div class="os-recurring-suggestion-wrapper">
				<div class="os-recurring-suggestion">
					<div class="os-recurring-suggestion-heading"><?php esc_html_e( 'Make it a recurring appointment?', 'latepoint-pro-features' ) ?></div>
					<div class="os-recurring-suggestion-sub-heading"><?php esc_html_e( 'You will set the frequency in the next step.', 'latepoint-pro-features' ) ?></div>
					<div class="os-recurring-suggestion-options">
						<div class="os-recurring-suggestion-option" data-value="<?php echo LATEPOINT_VALUE_ON; ?>"><?php esc_html_e( 'Yes', 'latepoint-pro-features' ); ?></div>
						<div class="os-recurring-suggestion-option" data-value="<?php echo LATEPOINT_VALUE_OFF; ?>"><?php esc_html_e( 'No', 'latepoint-pro-features' ); ?></div>
					</div>
				</div>
			</div>
			<?php
		}
	}

	public static function add_svg_for_step( string $svg, string $step_code ) {
		if ( $step_code == self::$step_code ) {
				$svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 73 73">
					<path class="latepoint-step-svg-highlight" d="M36.270771,27.7026501h16.8071289c0.4140625,0,0.75-0.3359375,0.75-0.75s-0.3359375-0.75-0.75-0.75H36.270771 c-0.4140625,0-0.75,0.3359375-0.75,0.75S35.8567085,27.7026501,36.270771,27.7026501z"/>
					<path class="latepoint-step-svg-highlight" d="M40.5549507,42.3081207c0,0.4140625,0.3359375,0.75,0.75,0.75h12.6015625c0.4140625,0,0.75-0.3359375,0.75-0.75 s-0.3359375-0.75-0.75-0.75H41.3049507C40.8908882,41.5581207,40.5549507,41.8940582,40.5549507,42.3081207z"/>
					<path class="latepoint-step-svg-highlight" d="M45.6980171,51.249527H29.9778023c-0.4140625,0-0.75,0.3359375-0.75,0.75s0.3359375,0.75,0.75,0.75h15.7202148 c0.4140625,0,0.75-0.3359375,0.75-0.75S46.1120796,51.249527,45.6980171,51.249527z"/>
					<path class="latepoint-step-svg-highlight" d="M62.1623726,11.5883932l0.3300781-3.3564453c0.0405273-0.4121094-0.2607422-0.7792969-0.6728516-0.8193359 c-0.4091797-0.0458984-0.77882,0.2597656-0.8203125,0.6728516l-0.3300781,3.3564453 c-0.0405273,0.4121094,0.2612305,0.7792969,0.6733398,0.8193359 C61.7317963,12.3070383,62.1204109,12.0155325,62.1623726,11.5883932z"/>
					<path class="latepoint-step-svg-highlight" d="M63.9743843,13.9233541c1.1010704-0.3369141,2.0717735-1.0410156,2.7333946-1.9814453 c0.2382813-0.3388672,0.1567383-0.8066406-0.1816406-1.0449219c-0.3383789-0.2392578-0.8066406-0.1572266-1.0449219,0.1816406 c-0.4711914,0.6699219-1.1621094,1.1708984-1.9462852,1.4111328c-0.3959961,0.1210938-0.6186523,0.5400391-0.4975586,0.9365234 C63.1588402,13.8212023,63.5774651,14.0450754,63.9743843,13.9233541z"/>
					<path class="latepoint-step-svg-highlight" d="M68.8601227,17.4516735c0.0356445-0.4121094-0.2695313-0.7763672-0.6826172-0.8115234l-3.859375-0.3349609 c-0.4072227-0.0390625-0.7758751,0.2695313-0.8115196,0.6826172c-0.0356445,0.4121094,0.2695313,0.7763672,0.6826134,0.8115234 l3.859375,0.3349609C68.4594727,18.1708145,68.8244781,17.8649578,68.8601227,17.4516735z"/>
					<path class="latepoint-step-svg-highlight" d="M4.7497134,18.4358044c1.0574932,1.9900436,1.9738078,2.5032253,13.2814941,11.7038574 c0.5604858,11.4355488,0.9589844,22.8789082,1.1829224,34.3259277c0.3128052,0.1918945,0.6256714,0.3835449,0.9384766,0.5751953 c0.1058846,0.3764038,0.416275,0.5851364,0.7949219,0.5466309c12.6464844-1.4892578,25.8935547-2.0419922,40.4916992-1.6767578 c0.4600639-0.0021172,0.763813-0.3514481,0.7685547-0.7421875c0.1805725-16.3819695-0.080349-32.8599472,0.0605469-49.1875 c0.003418-0.3740234-0.2685547-0.6923828-0.6376953-0.7480469c-14.1435547-2.140625-28.5092773-2.3291016-42.6953125-0.5664063 c-0.331604,0.0407715-0.5751953,0.2971191-0.6331177,0.6113281c-0.3464966,0.277832-0.6930542,0.5556641-1.0396118,0.8334961 c0.1156616,1.137207,0.0985718,2.392333,0.1765137,3.5629873c-2.2901011-1.8925772-4.5957651-3.8081045-6.9354258-5.7802725 c-0.7441406-0.6269531-1.6889648-0.9277344-2.683105-0.8378906C4.4105406,11.3600969,3.320657,15.7476349,4.7497134,18.4358044z M60.7629585,14.6196432c-0.1265907,15.9033155,0.1148987,31.8954544-0.046875,47.7734375 c-14.0498047-0.3193359-26.8598633,0.2099609-39.1044922,1.6074219c0.0154419-10.8208008-0.2228394-21.3803711-0.6828613-31.503418 c8.6963615,7.0753174,9.1210613,7.5400124,10.6517334,8.1962891c2.7804565,1.1923828,7.8590698,1.5974121,8.4487305,0.6987305 c0.0741577-0.0522461,0.1495361-0.1047363,0.2015381-0.1826172c0.1469727-0.2207031,0.1669922-0.5029297,0.0517578-0.7412109 c-1.0354347-2.1505203-2.3683548-6.0868149-3.1914063-6.7568359c-5.5252628-4.5023842-10.581501-8.5776329-16.84375-13.7214375 c-0.1300049-1.973877-0.2654419-3.9484863-0.4165039-5.9221182C33.4343452,12.4419088,47.1985054,12.6274557,60.7629585,14.6196432 z M9.5368834,13.0405416c9.0454321,7.6246099,17.5216217,14.4366217,26.5917969,21.8203125 c0.3883591,0.3987503,1.5395088,3.3786926,2.2700195,5.078125c-1.4580688-0.1650391-2.9936523-0.479248-4.7089233-0.8842773 c0.4859009-0.9790039,1.1461182-1.8769531,1.953064-2.6108398c0.3061523-0.2783203,0.3286133-0.7529297,0.0498047-1.0595703 c-0.2783203-0.3046875-0.7519531-0.328125-1.0595703-0.0498047c-0.9295654,0.8461914-1.6932373,1.8774414-2.2598877,3.0026855 c-8.9527779-7.1637478-17.1909065-14.1875877-25.8739014-21.1394062c-0.5556641-0.4443359-0.8725586-1.09375-0.8481445-1.7363272 C5.7526169,12.8167362,8.1288319,11.8543167,9.5368834,13.0405416z"/>
				</svg>';
		}
		return $svg;
	}


	public static function output_recurrence_settings_on_service_form( $service ) {
		?>
		<div class="white-box section-anchor" id="stickySectionRecurring">
			<div class="white-box-header">
				<div class="os-form-sub-header">
					<h3><?php _e( 'Recurring Appointments', 'latepoint-pro-features' ); ?></h3>
				</div>
			</div>
			<div class="white-box-content">
				<?php echo OsFormHelper::toggler_field( 'service[meta][allow_recurring_bookings]', esc_html__( 'Allow Recurring Appointments', 'latepoint-pro-features' ), ( $service->get_meta_by_key( 'allow_recurring_bookings' ) == 'on' ), 'lp-allow-recurring-bookings', false, [ 'sub_label' => __( 'Allows customers to book this service in a recurring schedule', 'latepoint-pro-features' ) ] ); ?>
				<div id="lp-allow-recurring-bookings" <?php echo ( $service->get_meta_by_key( 'allow_recurring_bookings' ) == 'on' ) ? '' : 'style="display: none;"' ?>>
					<div class="merged-fields os-mt-1">
						<div class="merged-label"><?php esc_html_e( 'Allow a maximum of', 'latepoint-pro-features' ); ?></div>
						<?php echo OsFormHelper::text_field( 'service[meta][maximum_number_of_recurring_bookings]', false, $service->get_meta_by_key( 'maximum_number_of_recurring_bookings', '20' ), [ 'placeholder' => esc_html__( 'Value', 'latepoint-pro-features' ) ] ); ?>
						<div class="merged-label"><?php esc_html_e( 'future appointments', 'latepoint-pro-features' ); ?></div>
					</div>
					<div class="merged-fields os-mt-1">
						<div class="merged-label"><?php esc_html_e( 'Allow Repeat Intervals', 'latepoint-pro-features' ); ?></div>
						<?php echo OsFormHelper::select_field(
							'service[meta][allow_recurring_periods]',
							false,
							[
								'all'   => __( 'All', 'latepoint-pro-features' ),
								'day'   => __( 'Daily', 'latepoint-pro-features' ),
								'week'  => __( 'Weekly', 'latepoint-pro-features' ),
								'month' => __( 'Monthly', 'latepoint-pro-features' ),
							],
							$service->get_meta_by_key( 'allow_recurring_periods', 'all' )
						); ?>
					</div>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * @param OsBookingModel[] $bookings
	 *
	 * @return string
	 */
	public static function output_recurring_info_for_sequence_of_bookings( string $html, array $bookings = [], bool $same_location = false, bool $same_agent = false ): string {
		if ( empty( $bookings ) ) {
			return $html;
		}

		$main_booking = $bookings[0];

		$html .= OsBookingHelper::generate_summary_for_booking( $main_booking, $main_booking->cart_item_id );
		$html .= OsFeatureRecurringBookingsHelper::output_recurrent_bookings_summary( $bookings );

		if ( ( ! $same_agent && OsAgentHelper::count_agents() > 1 ) || ! $same_location ) {

			$html .= '<div class="booking-summary-info-w">';
			$html .= '<div class="summary-boxes-columns">';

			ob_start();
			if ( ! $same_agent && OsAgentHelper::count_agents() > 1 ) {
				OsAgentHelper::generate_summary_for_agent( $main_booking );
			}
			if ( ! $same_location ) {
				OsLocationHelper::generate_summary_for_location( $main_booking );
			}
			$html .= ob_get_clean();

			$html .= '</div>';
			$html .= '</div>';
		}


		return $html;
	}

	public static function get_max_limit_of_allowed_recurring_bookings( OsBookingModel $booking ) {
		if ( $booking->is_bundle_scheduling() ) {
			$remaining_slots       = OsBundlesHelper::get_remaining_slots_for_bundle_order_item( $booking->order_item_id );
			$max_limit_of_bookings = $remaining_slots;
		} else {
			$max_limit_of_bookings = $booking->service->get_meta_by_key( 'maximum_number_of_recurring_bookings', 20 );
		}
		return $max_limit_of_bookings;
	}

	public static function output_recurring_info_on_booking_summary( string $summary_html, OsBookingModel $booking, ?string $cart_item_id, string $viewer ): string {
		if ( ! empty( $booking->generate_recurrent_sequence ) ) {
			$recurring_bookings_data_and_errors = OsFeatureRecurringBookingsHelper::generate_recurring_bookings_data( $booking, $booking->generate_recurrent_sequence['rules'], $booking->generate_recurrent_sequence['overrides'], $booking->get_customer_timezone() );
			$bookings_data                      = $recurring_bookings_data_and_errors['bookings_data'];
			$bookings                           = [];
			foreach ( $bookings_data as $booking_data ) {
				if ( $booking_data['unchecked'] == 'yes' ) {
					continue;
				}
				$bookings[] = $booking_data['booking'];
			}
			$summary_html .= self::output_recurrent_bookings_summary( $bookings );
		}

		return $summary_html;
	}

	public static function add_step_for_recurring_bookings( array $steps ): array {
		$steps[ self::$step_code ] = [ 'after' => 'datepicker' ];

		return $steps;
	}

	public static function add_step_show_next_btn_rules( $rules, $step_code ): array {
		$rules[ self::$step_code ] = false;

		return $rules;
	}

	public static function should_step_be_skipped( bool $skip, string $step_code, OsCartModel $cart, OsCartItemModel $active_cart_item, OsBookingModel $booking ): bool {
		if ( $step_code == self::$step_code ) {
			if ( $active_cart_item->is_booking() ) {
				$booking = $active_cart_item->build_original_object_from_item_data();
				if ( empty( $booking->generate_recurrent_sequence ) ) {
					return true;
				}
			} else {
				$skip = true;
			}
		}

		return $skip;
	}


	public static function add_settings_for_step( array $settings ): array {
		$settings[ self::$step_code ] = [
			'side_panel_heading'     => 'Recurring Appointment',
			'side_panel_description' => 'Please select if you want to make it a recurring appointment',
			'main_panel_heading'     => 'Recurring Appointment',
		];

		return $settings;
	}


	public static function add_label_for_step( array $labels ): array {
		$labels[ self::$step_code ] = __( 'Recurring Appointment', 'latepoint-pro-features' );

		return $labels;
	}

	public static function load_step_recurring_bookings( $step_code, $format = 'json' ) {
		if ( $step_code == self::$step_code ) {

			$recurring_bookings_controller                                = new OsRecurringBookingsController();
			$recurring_bookings_controller->vars['booking']               = OsStepsHelper::$booking_object;
			$recurring_bookings_controller->vars['current_step_code']     = $step_code;
			$recurring_bookings_controller->vars['recurrence_start_date'] = OsStepsHelper::$booking_object->get_start_datetime( OsStepsHelper::$booking_object->get_customer_timezone_name() );
			$recurring_bookings_controller->vars['repeat_end_date']       = OsStepsHelper::$booking_object->get_start_datetime( OsStepsHelper::$booking_object->get_customer_timezone_name() )->modify( '+2 months' );

			if ( OsStepsHelper::is_bundle_scheduling() ) {
				$recurring_bookings_controller->vars['max_repeat_end_counter'] = OsBundlesHelper::get_remaining_slots_for_bundle_order_item( OsStepsHelper::$booking_object->order_item_id );
			} else {
				$recurring_bookings_controller->vars['max_repeat_end_counter'] = OsStepsHelper::$booking_object->service->get_meta_by_key( 'maximum_number_of_recurring_bookings', 20 );
			}

			$recurring_bookings_controller->set_layout( 'none' );
			$recurring_bookings_controller->set_return_format( $format );
			$recurring_bookings_controller->format_render(
				'_step_booking__recurring_bookings',
				[],
				[
					'step_code'        => $step_code,
					'show_next_btn'    => OsStepsHelper::can_step_show_next_btn( $step_code ),
					'show_prev_btn'    => OsStepsHelper::can_step_show_prev_btn( $step_code ),
					'is_first_step'    => OsStepsHelper::is_first_step( $step_code ),
					'is_last_step'     => OsStepsHelper::is_last_step( $step_code ),
					'is_pre_last_step' => OsStepsHelper::is_pre_last_step( $step_code ),
				]
			);
		}
	}

	public static function generate_bookings_info_for_recurring_set( array $recurring_bookings_data ): string {
		$total_selected = 0;

		foreach ( $recurring_bookings_data as $data ) {
			if ( $data['unchecked'] != 'yes' && $data['is_bookable'] ) {
				$total_selected++;
			}
		}

		$html = '<div class="rb-bookings-info"><div class="rb-bookings-info-label">' . sprintf( esc_html__( 'Found %s Available Slots', 'latepoint-pro-features' ), $total_selected ) . '</div><div class="rb-bookings-info-link-wrapper"><a href="#" class="rb-bookings-info-link">' . __( 'Review', 'latepoint-pro-features' ) . '</a></div></div>';

		return $html;
	}


	/**
	 * @param array $recurring_bookings_data
	 * @param bool $is_bundle_scheduling
	 * @param array $options 'ignore_availability' counts an occurrence on its tick alone - the admin may tick
	 *                       an unavailable slot on purpose, and it does get created.
	 *
	 * @return string
	 */
	public static function generate_price_info_for_recurring_set( array $recurring_bookings_data, bool $is_bundle_scheduling = false, array $options = [] ): string {
		$total_count         = count( $recurring_bookings_data );
		$total_selected      = 0;
		$ignore_availability = ! empty( $options['ignore_availability'] );
		$temp_cart           = new OsCartModel();


		foreach ( $recurring_bookings_data as $data ) {
			if ( $data['unchecked'] != 'yes' && ( $ignore_availability || $data['is_bookable'] ) ) {
				$total_selected++;

				$item            = new OsCartItemModel();
				$item->variant   = LATEPOINT_ITEM_VARIANT_BOOKING;
				$item->item_data = wp_json_encode( $data['booking']->generate_params_for_booking_form() );
				$temp_cart->add_item( $item, false );
			}
		}

		$html = '<div class="rb-preview-count"><div class="rb-preview-count-label">' . __( 'Selected', 'latepoint-pro-features' ) . '</div><div class="rb-preview-count-number">' . $total_selected . '</div><div class="rb-preview-count-label">' . __( 'of', 'latepoint-pro-features' ) . '</div><div class="rb-preview-count-number">' . $total_count . '</div></div>';

		if ( ! $is_bundle_scheduling && ( $temp_cart->get_subtotal() > 0 || OsSettingsHelper::is_off( 'hide_breakdown_if_subtotal_zero' ) ) ) {
			$html .= '<div class="rb-preview-price">' . OsMoneyHelper::format_price( $temp_cart->get_total(), true, false ) . '</div>';
		}

		return $html;
	}

	public static function generate_recurring_bookings_data( OsBookingModel $first_booking, array $rules, array $overrides, DateTimeZone $customer_timezone, $max_limit_of_bookings = false, array $options = [] ): array {
		$max_limit_of_bookings = $max_limit_of_bookings ? $max_limit_of_bookings : OsFeatureRecurringBookingsHelper::get_max_limit_of_allowed_recurring_bookings( $first_booking );

		$errors              = [];
		$bookings            = [];
		$condition_satisfied = false;

		$first_booking_start_date = $first_booking->get_start_datetime_object();
		$first_booking_start_date->setTimezone( $customer_timezone );
		$loop_booking_start_date = clone $first_booking_start_date;

		$bookings[]              = $first_booking;
		$bookings_count          = 1;
		$skipped_first_identical = false;
		$i                       = 1;

		do {
			$booking = clone $first_booking;

			$modify_by = [];

			if ( $rules['repeat_unit'] == 'week' ) {
				$recurring_weekdays = explode( ',', $rules['repeat_on_weekdays'] );
				foreach ( $recurring_weekdays as $weekday ) {
					$modify_by[] = $weekday - $loop_booking_start_date->format( 'N' );
				}
			} else {
				$modify_by[] = 0;
			}

			foreach ( $modify_by as $modify ) {
				$weekday_loop_start_date = clone $loop_booking_start_date;

				$modify_str = ( $modify > 0 ) ? '+' . $modify . ' days' : $modify . ' days';
				$weekday_loop_start_date->modify( $modify_str );
				if ( $weekday_loop_start_date < $first_booking_start_date ) {
					continue;
				}
				$wp_tz_loop_booking_start_date = clone $weekday_loop_start_date;
				$wp_tz_loop_booking_start_date->setTimezone( OsTimeHelper::get_wp_timezone() );
				$booking->start_date = $wp_tz_loop_booking_start_date->format( 'Y-m-d' );
				$booking->start_time = OsTimeHelper::convert_datetime_to_minutes( $wp_tz_loop_booking_start_date );

				if ( $booking->is_start_date_and_time_set() ) {
					$booking->calculate_end_date_and_time();
					$booking->set_utc_datetimes();
				}

				// check for ending conditions before adding booking to a list
				if ( $rules['repeat_end_operator'] == 'date' ) {
					if ( $booking->start_date > $rules['repeat_end_date'] ) {
						$condition_satisfied = true;
						break;
					}
				} else {
					if ( ( $bookings_count ) >= $rules['repeat_end_counter'] ) {
						$condition_satisfied = true;
						break;
					}
				}

				if ( $bookings_count >= $max_limit_of_bookings ) {
					$condition_satisfied = true;
					if ( $first_booking->is_bundle_scheduling() ) {
						$errors[] = sprintf( esc_html__( 'This bundle has only %s remaining appointments to schedule.', 'latepoint-pro-features' ), $max_limit_of_bookings );
					} else {
						$errors[] = sprintf( esc_html__( 'You can only schedule a maximum of %s recurring bookings at once.', 'latepoint-pro-features' ), $max_limit_of_bookings );
					}
					break;
				}

				if ( $modify == 0 & ! $skipped_first_identical ) {
					// skip the first booking with the same time, because we already added it before the loop
					$skipped_first_identical = true;
				} else {
					$bookings[] = clone $booking;
					$bookings_count++;
				}
			}
			$loop_booking_start_date = clone $first_booking_start_date;
			$loop_booking_start_date->modify( '+' . ( $i * $rules['repeat_interval'] ) . ' ' . $rules['repeat_unit'] );
			$i++;

		} while ( ! $condition_satisfied );

		$recurring_bookings_data = [];

		foreach ( $bookings as $booking ) {
			$original_stamp = 'stamp_' . $booking->get_start_datetime()->getTimestamp();
			if ( ! empty( $overrides[ $original_stamp ]['custom_day'] ) ) {
				try {
					$datetime_in_customer_timezone = new OsWpDateTime( $overrides[ $original_stamp ]['custom_day'] . 'T' . OsTimeHelper::minutes_to_army_hours_and_minutes( $overrides[ $original_stamp ]['custom_minutes'] ?? '0' ), $customer_timezone );
					$original_start_datetime       = $booking->get_nice_start_datetime_for_customer( $customer_timezone );
					$datetime_in_wp_timezone       = clone $datetime_in_customer_timezone;
					$datetime_in_wp_timezone->setTimezone( OsTimeHelper::get_wp_timezone() );
					$booking->start_date = $datetime_in_wp_timezone->format( 'Y-m-d' );
					$booking->start_time = OsTimeHelper::convert_datetime_to_minutes( $datetime_in_wp_timezone );
					if ( $booking->is_start_date_and_time_set() ) {
						$booking->calculate_end_date_and_time();
						$booking->set_utc_datetimes();
						if ( $original_start_datetime != $booking->get_nice_start_datetime_for_customer( $customer_timezone ) ) {
							$recurring_bookings_data[ $original_stamp ]['original_start_datetime'] = $original_start_datetime;
							$recurring_bookings_data[ $original_stamp ]['custom_day']              = $overrides[ $original_stamp ]['custom_day'];
							$recurring_bookings_data[ $original_stamp ]['custom_minutes']          = $overrides[ $original_stamp ]['custom_minutes'];
						}
					}
				} catch ( Exception $e ) {

				}
			}
			$recurring_bookings_data[ $original_stamp ]['booking']     = $booking;
			$recurring_bookings_data[ $original_stamp ]['is_bookable'] = self::is_occurrence_bookable( $booking, $options );
			$recurring_bookings_data[ $original_stamp ]['unchecked']   = $overrides[ $original_stamp ]['unchecked'] ?? 'no';
		}

		return [
			'bookings_data' => $recurring_bookings_data,
			'errors'        => $errors,
		];
	}

	/**
	 * Availability check for one generated occurrence.
	 *
	 * From the backend the customer facing booking window must not apply, and is_bookable() calls
	 * is_booking_request_available() without settings so it cannot be told that. Core's own admin availability
	 * panel sets the same flag, keeping the two in agreement. Its ANY agent/location branches are not needed:
	 * the admin form only offers concrete ones.
	 *
	 * @param OsBookingModel $booking
	 * @param array $options
	 *
	 * @return bool
	 */
	private static function is_occurrence_bookable( OsBookingModel $booking, array $options = [] ): bool {
		if ( empty( $options['accessed_from_backend'] ) ) {
			return $booking->is_bookable(
				[
					'log_errors'          => false,
					'skip_customer_check' => true,
				]
			);
		}

		return OsBookingHelper::is_booking_request_available(
			\LatePoint\Misc\BookingRequest::create_from_booking_model( $booking ),
			[ 'accessed_from_backend' => true ]
		);
	}

	/**
	 * @param OsWpDateTime $start
	 * @param array $rules
	 *
	 * @return string
	 */
	public static function generate_recurrence_rules_for_booking_form( OsWpDateTime $start, array $rules, OsBookingModel $booking, array $options = [] ): string {
		// Prefix and route are overridable so the admin order form can namespace fields under its order item.
		// Defaults keep the booking form unchanged.
		$field_prefix = $options['field_prefix'] ?? 'recurrence';
		$route_name   = $options['route_name'] ?? OsRouterHelper::build_route_name( 'recurring_bookings', 'reload_recurrence_rules' );
		$defaults     = [
			'repeat_unit'            => 'week',
			'repeat_interval'        => 1,
			'repeat_on_weekdays'     => $start->format( 'N' ),
			'repeat_end_operator'    => 'count',
			'repeat_end_date'        => '',
			'repeat_end_counter'     => 10,
			'changed'                => 'yes',
			'max_repeat_end_counter' => 100,
		];

		$rules = OsUtilHelper::merge_default_atts( $defaults, $rules );

		if ( empty( $rules['repeat_end_date'] ) ) {
			$end                      = clone $start;
			$rules['repeat_end_date'] = $end->modify( '+2 months' )->format( 'Y-m-d' );
		} else {
			$end = OsWpDateTime::os_createFromFormat( 'Y-m-d', sanitize_text_field( $rules['repeat_end_date'] ) );
		}

		$start_utc = clone $start;
		$start_utc->setTimezone( new DateTimeZone( 'UTC' ) );

		$repeat_units         = [];
		$allowed_repeat_units = $booking->service->get_meta_by_key( 'allow_recurring_periods', 'all' );
		if ( $allowed_repeat_units == 'all' ) {
			$repeat_units = [
				'day'   => __( 'day', 'latepoint-pro-features' ),
				'week'  => __( 'week', 'latepoint-pro-features' ),
				'month' => __( 'month', 'latepoint-pro-features' ),
			];
		} else {
			switch ( $allowed_repeat_units ) {
				case 'day':
					$rules['repeat_unit'] = 'day';
					$repeat_units['day']  = __( 'day', 'latepoint-pro-features' );
					break;
				case 'week':
					$rules['repeat_unit'] = 'week';
					$repeat_units['week'] = __( 'week', 'latepoint-pro-features' );
					break;
				case 'month':
					$rules['repeat_unit']  = 'month';
					$repeat_units['month'] = __( 'month', 'latepoint-pro-features' );
					break;
			}
		}

		ob_start();
		?>
		<div class="os-recurrence-rules" data-route-name="<?php echo esc_attr( $route_name ); ?>"
			 data-repeat-unit="<?php echo esc_attr( $rules['repeat_unit'] ); ?>" data-ends="<?php echo esc_attr( $rules['repeat_end_operator'] ); ?>">
			<div class="os-recurrence-interval">
				<div class="os-ri-label"><?php _e( 'First on', 'latepoint-pro-features' ); ?></div>
				<div class="os-start-recurrence-datetime-picker"
					 data-start-datetime-utc="<?php echo esc_attr( $start_utc->format( LATEPOINT_DATETIME_DB_FORMAT ) ); ?>"><?php echo $start->format( OsSettingsHelper::get_readable_datetime_format() ); ?></div>
			</div>
			<div class="os-recurrence-interval">
				<div class="os-ri-label"><?php _e( 'Repeats every', 'latepoint-pro-features' ); ?></div>
				<div class="os-ri-input"><?php echo OsFormHelper::number_field( $field_prefix . '[rules][repeat_interval]', '', $rules['repeat_interval'], 1, 500, [ 'skip_id' => true ] ); ?></div>
				<div class="os-ri-select"><?php echo OsFormHelper::select_field( $field_prefix . '[rules][repeat_unit]', '', $repeat_units, $rules['repeat_unit'], [ 'skip_id' => true ] ); ?></div>
			</div>
			<div class="os-recurrence-weekdays">
				<?php
				$start_of_week = OsSettingsHelper::get_start_of_week();
				$weekdays      = OsBookingHelper::get_weekdays_arr();

				$repeat_on_weekdays_arr = explode( ',', $rules['repeat_on_weekdays'] );

				// Output the divs for each weekday
				for ( $i = $start_of_week - 1; $i < $start_of_week - 1 + 7; $i++ ) {
					// Calculate the index within the range of 0-6
					$index    = $i % 7;
					$selected = ( in_array( $i + 1, $repeat_on_weekdays_arr ) ) ? 'os-weekday-selected' : '';

					// Output the div for the current weekday
					echo '<div class="weekday weekday-' . esc_attr( $index + 1 ) . ' ' . $selected . '" data-weekday="' . ( $index + 1 ) . '">' . esc_html( $weekdays[ $index ] ) . '</div>';
				}
				echo OsFormHelper::hidden_field( $field_prefix . '[rules][repeat_on_weekdays]', $rules['repeat_on_weekdays'], [ 'skip_id' => true ] );
				?>
			</div>
			<div class="os-recurrence-ends">
				<div class="os-ri-label"><?php _e( 'Ends', 'latepoint-pro-features' ); ?></div>
				<div class="os-ri-select">
				<?php
					echo OsFormHelper::select_field(
						$field_prefix . '[rules][repeat_end_operator]',
						'',
						[
							'count' => __( 'After', 'latepoint-pro-features' ),
							'date'  => __( 'On', 'latepoint-pro-features' ),
						],
						$rules['repeat_end_operator'],
						[ 'skip_id' => true ]
					);
				?>
				</div>
				<div class="os-ri-end-option-count">
					<div class="os-ri-input"><?php echo OsFormHelper::number_field( $field_prefix . '[rules][repeat_end_counter]', '', $rules['repeat_end_counter'], 2, $rules['max_repeat_end_counter'], [ 'skip_id' => true ] ); ?></div>
					<div class="os-ri-label"><?php _e( 'occurrences', 'latepoint-pro-features' ); ?></div>
				</div>
				<div class="os-ri-end-option-date">
					<div class="os-end-recurrence-datetime-picker" data-preselected-day="<?php echo esc_attr( $rules['repeat_end_date'] ) ?>"
						 data-route-name="<?php echo esc_attr( OsRouterHelper::build_route_name( 'recurring_bookings', 'pick_end_date_on_calendar' ) ); ?>"><?php echo $end->format( OsSettingsHelper::get_readable_date_format() ); ?></div>
					<?php echo OsFormHelper::hidden_field( $field_prefix . '[rules][repeat_end_date]', $rules['repeat_end_date'], [ 'skip_id' => true ] ); ?>
				</div>
			</div>
			<?php echo OsFormHelper::hidden_field( $field_prefix . '[rules][changed]', $rules['changed'], [ 'skip_id' => true ] ); ?>
		</div>
		<?php
		$html = ob_get_clean();

		return $html;
	}

	/**
	 *
	 * @param array $connected_bookings
	 *
	 * @return string
	 */
	public static function output_recurrent_bookings_summary( array $connected_bookings, bool $skip_first = true ): string {
		$html           = '';
		$total_bookings = $skip_first ? count( $connected_bookings ) - 1 : count( $connected_bookings );
		if ( empty( $total_bookings ) ) {
			return $html;
		}

		$html .= '<div class="os-recurring-bookings-wrapper">';
		$html .= '<div class="os-recurring-bookings-count">' . sprintf( __( '+%s Recurring Appointments:', 'latepoint-pro-features' ), $total_bookings ) . '</div>';
		$html .= '<div class="os-recurring-unfolded-bookings">';
		$i     = 0;
		foreach ( $connected_bookings as $booking ) {
			$i++;
			// skip the first one because it's time is printed in the main summary
			if ( $skip_first && $i == 1 ) {
				continue;
			}
			$html .= '<div class="os-recurring-unfolded-booking">';
			$html .= '<div>' . $booking->get_nice_start_date_for_customer( false, true ) . '</div>';
			$html .= '<div>' . $booking->get_nice_start_time_for_customer() . '</div>';
			$html .= '</div>';
		}
		$html .= '</div>';
		if ( count( $connected_bookings ) > LATEPOINT_RECURRING_BOOKINGS_UNFOLDED_COUNT ) {
			$html .= '<div class="os-recurring-bookings-unfold"><i class="latepoint-icon latepoint-icon-chevron-right"></i><div>' . __( 'show all', 'latepoint-pro-features' ) . '</div></div>';
		}
		$html .= '</div>';
		return $html;
	}

	/* --- Recurring appointments in the admin order quick edit form (#396) ---
	 * One order item per occurrence, like the booking form makes one cart item per occurrence, so the total,
	 * the breakdown and per occurrence editing all come from core. Rendered into the form before submit, so the
	 * numbers on screen are the numbers that get saved.
	 * ------------------------------------------------------------------- */

	/**
	 * Hard ceiling per submission: the order form is re-parsed from one POST field with parse_str(), which
	 * truncates silently at max_input_vars.
	 */
	const ADMIN_MAX_OCCURRENCES = 20;

	/** @var array<int, bool> Per request memo of services that allow recurring, to avoid an N+1 on service meta. */
	private static $admin_service_supports_recurring = [];

	/** @var bool True only while the order item block created from the "Recurring" tile is being rendered. */
	private static $is_rendering_recurring_form = false;

	/** @var array<int, int> Per request memo of how many appointments a series holds, to avoid an N+1. */
	private static $recurring_series_sizes = [];

	/** @var array<int, bool> Per request memo of recurrence ids that were checked to actually exist. */
	private static $verified_recurrence_ids = [];

	/** @var array|null Memoized list of active services that allow recurring appointments. */
	private static $recurring_services_cache = null;

	/**
	 * Strips anything that is not safe to use as an array key or as part of an HTML field name.
	 *
	 * @param mixed $value
	 *
	 * @return string
	 */
	public static function admin_sanitize_key( $value ): string {
		return preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) $value );
	}

	/**
	 * Field name prefix for one booking form inside the order quick edit screen.
	 *
	 * Namespacing under the order item is required, not cosmetic: the booking form's flat "recurrence[...]"
	 * names collide as soon as two booking forms are open in the same modal.
	 *
	 * @param string $order_item_id
	 * @param string $booking_form_id
	 *
	 * @return string
	 */
	public static function admin_recurring_field_prefix( string $order_item_id, string $booking_form_id ): string {
		return 'order_items[' . self::admin_sanitize_key( $order_item_id ) . '][bookings][' . self::admin_sanitize_key( $booking_form_id ) . '][recurrence]';
	}

	/**
	 * @param int $service_id
	 *
	 * @return bool
	 */
	public static function admin_service_allows_recurring( int $service_id ): bool {
		if ( empty( $service_id ) ) {
			return false;
		}
		if ( ! isset( self::$admin_service_supports_recurring[ $service_id ] ) ) {
			$service = new OsServiceModel( $service_id );
			self::$admin_service_supports_recurring[ $service_id ] = ( $service->get_meta_by_key( 'allow_recurring_bookings' ) === LATEPOINT_VALUE_ON );
		}

		return self::$admin_service_supports_recurring[ $service_id ];
	}

	/**
	 * Maximum occurrences for this booking's service.
	 *
	 * Reads the meta directly on purpose: get_max_limit_of_allowed_recurring_bookings() branches on
	 * is_bundle_scheduling() - true for every admin booking - and then fatals on the uninitialised typed static
	 * OsStepsHelper::$booking_object.
	 *
	 * @param OsBookingModel $booking
	 *
	 * @return int
	 */
	public static function admin_recurring_max_limit( OsBookingModel $booking ): int {
		$max = self::ADMIN_MAX_OCCURRENCES;
		// Into a local first: OsModel has __get but no __isset, so empty( $booking->service ) is always true.
		$service = $booking->service_id ? $booking->service : null;
		if ( $service instanceof OsServiceModel && ! empty( $service->id ) ) {
			$from_meta = absint( $service->get_meta_by_key( 'maximum_number_of_recurring_bookings', self::ADMIN_MAX_OCCURRENCES ) );
			if ( $from_meta > 0 ) {
				$max = $from_meta;
			}
		}

		return min( $max, self::ADMIN_MAX_OCCURRENCES );
	}

	/**
	 * @param OsBookingModel $booking
	 *
	 * @return array
	 */
	public static function admin_default_recurrence_rules( OsBookingModel $booking ): array {
		$max_limit = self::admin_recurring_max_limit( $booking );

		try {
			// Customer facing on purpose: get_start_datetime() is UTC, so the weekday would be out by one.
			$start = $booking->is_start_date_and_time_set() ? $booking->get_start_datetime_for_customer() : new OsWpDateTime( 'now', OsTimeHelper::get_wp_timezone() );
		} catch ( Exception $e ) {
			$start = new OsWpDateTime( 'now', OsTimeHelper::get_wp_timezone() );
		}

		$repeat_unit = 'week';
		$service     = $booking->service_id ? $booking->service : null;
		if ( $service instanceof OsServiceModel && ! empty( $service->id ) ) {
			$allowed = $service->get_meta_by_key( 'allow_recurring_periods', 'all' );
			if ( in_array( $allowed, [ 'day', 'week', 'month' ], true ) ) {
				$repeat_unit = $allowed;
			}
		}

		return [
			'repeat_unit'            => $repeat_unit,
			'repeat_interval'        => 1,
			'repeat_on_weekdays'     => (string) $start->format( 'N' ),
			'repeat_end_operator'    => 'count',
			'repeat_end_date'        => '',
			'repeat_end_counter'     => min( $max_limit, 10 ),
			'changed'                => 'yes',
			'max_repeat_end_counter' => $max_limit,
		];
	}

	/**
	 * @param OsBookingModel $booking
	 * @param array|null $rules
	 * @param string $field_prefix
	 *
	 * @return string
	 */
	public static function admin_render_recurrence_rules_form( OsBookingModel $booking, ?array $rules, string $field_prefix ): string {
		try {
			$start = $booking->is_start_date_and_time_set() ? $booking->get_start_datetime_for_customer() : new OsWpDateTime( 'now', OsTimeHelper::get_wp_timezone() );
		} catch ( Exception $e ) {
			$start = new OsWpDateTime( 'now', OsTimeHelper::get_wp_timezone() );
		}
		if ( null === $rules ) {
			$rules = self::admin_default_recurrence_rules( $booking );
		}

		return self::generate_recurrence_rules_for_booking_form(
			$start,
			$rules,
			$booking,
			[
				'field_prefix' => $field_prefix,
				'route_name'   => OsRouterHelper::build_route_name( 'recurring_bookings', 'admin_recurring_preview' ),
			]
		);
	}

	/**
	 * Occurrences for the admin preview. Two differences from the booking form: availability is evaluated with
	 * accessed_from_backend, and an unavailable occurrence starts unticked so the selection matches what is
	 * created.
	 *
	 * @param OsBookingModel $booking
	 * @param array $rules
	 * @param array $overrides
	 *
	 * @return array
	 */
	public static function admin_compute_recurring_preview( OsBookingModel $booking, array $rules, array $overrides ): array {
		$max_limit = self::admin_recurring_max_limit( $booking );
		$data      = self::generate_recurring_bookings_data(
			$booking,
			$rules,
			$overrides,
			$booking->get_customer_timezone(),
			$max_limit,
			[ 'accessed_from_backend' => true ]
		);

		$non_bookable_count = 0;
		foreach ( $data['bookings_data'] as $stamp => $datum ) {
			if ( ! empty( $datum['is_bookable'] ) ) {
				continue;
			}
			$non_bookable_count++;
			// Unticked by default, unless the admin has already decided about it.
			if ( ! isset( $overrides[ $stamp ]['unchecked'] ) ) {
				$data['bookings_data'][ $stamp ]['unchecked'] = 'yes';
			}
		}

		return [
			'bookings_data'      => $data['bookings_data'],
			'errors'             => $data['errors'],
			'non_bookable_count' => $non_bookable_count,
		];
	}

	/**
	 * @param array $bookings_data
	 * @param string $field_prefix
	 *
	 * @return string
	 */
	public static function admin_render_recurring_override_fields( array $bookings_data, string $field_prefix ): string {
		$html = '';
		foreach ( $bookings_data as $stamp => $datum ) {
			$stamp = self::admin_sanitize_key( $stamp );
			$html .= OsFormHelper::hidden_field( $field_prefix . '[overrides][' . $stamp . '][custom_day]', $datum['custom_day'] ?? '', [ 'class' => 'recurring_booking_custom_day' ] );
			$html .= OsFormHelper::hidden_field( $field_prefix . '[overrides][' . $stamp . '][custom_minutes]', $datum['custom_minutes'] ?? '', [ 'class' => 'recurring_booking_custom_minutes' ] );
			$html .= OsFormHelper::hidden_field( $field_prefix . '[overrides][' . $stamp . '][unchecked]', $datum['unchecked'] ?? 'no', [ 'class' => 'recurring_booking_unchecked' ] );
		}

		return $html;
	}

	/**
	 * @param array $preview
	 * @param OsBookingModel $booking
	 *
	 * @return string
	 */
	public static function admin_render_recurring_slots( array $preview, OsBookingModel $booking ): string {
		$bookings_data      = $preview['bookings_data'];
		$errors             = $preview['errors'];
		$non_bookable_count = $preview['non_bookable_count'];
		$timezone           = $booking->get_customer_timezone_name();

		ob_start();
		if ( $non_bookable_count > 0 ) {
			// translators: %1$s is the number of unavailable slots, %2$s is the total number of slots
			echo '<div class="recurring-bookings-error">' . esc_html( sprintf( __( '%1$s of %2$s time slots are not available and have been deselected. Adjust the rules, change a time, or select one anyway to book it regardless.', 'latepoint-pro-features' ), $non_bookable_count, count( $bookings_data ) ) ) . '</div>';
		}
		$index = 1;
		foreach ( $bookings_data as $stamp => $data ) {
			$stamp       = self::admin_sanitize_key( $stamp );
			$is_on       = ( ( $data['unchecked'] ?? 'no' ) !== 'yes' );
			$is_bookable = ! empty( $data['is_bookable'] );
			$css_state   = $is_on ? 'rbp-is-on' : 'rbp-is-off';
			$css_avail   = $is_bookable ? 'is-available' : 'is-not-available';
			$utc_attr    = isset( $data['booking']->start_datetime_utc ) ? $data['booking']->start_datetime_utc : '';
			?>
			<div data-stamp="<?php echo esc_attr( $stamp ); ?>"
				class="recurring-booking-preview <?php echo esc_attr( $css_state . ' ' . $css_avail ); ?>"
				data-start-datetime-utc="<?php echo esc_attr( $utc_attr ); ?>">
				<div class="rbp-index"><?php echo esc_html( $index ); ?></div>
				<div class="rbp-info">
					<?php if ( ! empty( $data['original_start_datetime'] ) ) { ?>
						<div class="rbp-original-datetime"><?php echo esc_html( $data['original_start_datetime'] ); ?></div>
					<?php } ?>
					<div class="rbp-date"><?php echo esc_html( $data['booking']->get_nice_start_date_in_timezone( $timezone ) ); ?></div>
					<div class="rbp-time">
						<span><?php echo esc_html( $data['booking']->get_nice_start_time_in_timezone( $timezone ) ); ?></span>
						<a href="#" class="rbp-time-edit" title="<?php esc_attr_e( 'Change date or time', 'latepoint-pro-features' ); ?>"><i class="latepoint-icon latepoint-icon-edit-3"></i></a>
					</div>
				</div>
				<?php if ( ! $is_bookable ) { ?>
					<?php // Drawn with CSS rather than an icon: the admin icon font has no warning glyph. ?>
					<div class="rbp-warn-slot">
						<div class="rbp-warn-slot-message"><?php esc_html_e( 'This slot is unavailable. Select it anyway to book it regardless.', 'latepoint-pro-features' ); ?></div>
					</div>
				<?php } ?>
				<div class="rbp-checkbox" role="checkbox" tabindex="0" aria-checked="<?php echo $is_on ? 'true' : 'false'; ?>"></div>
			</div>
			<?php
			$index++;
		}
		foreach ( $errors as $error ) {
			echo '<div class="recurring-bookings-notice">' . esc_html( $error ) . '</div>';
		}

		return ob_get_clean();
	}

	/**
	 * The recurring panel inside a booking data form. Runs for every booking form in the modal, so the gates
	 * below are ordered cheapest first and cost no queries until the last.
	 *
	 * @param OsBookingModel $booking
	 * @param string $order_item_id
	 *
	 * @return void
	 */
	public static function output_admin_recurring_section( $booking, $order_item_id ) {
		if ( ! ( $booking instanceof OsBookingModel ) ) {
			return;
		}

		$field_prefix = self::admin_recurring_field_prefix( (string) $order_item_id, (string) $booking->get_form_id() );

		// Already in a series - keep the link, offer no rules to re-run.
		if ( ! empty( $booking->recurrence_id ) ) {
			echo self::admin_render_series_member_row( $booking, (string) $order_item_id );

			return;
		}

		// Only the item created from the "Recurring" tile carries the panel.
		if ( ! self::$is_rendering_recurring_form ) {
			return;
		}

		// Out of scope, and it guarantees re-saving an order never regenerates a series.
		if ( ! $booking->is_new_record() ) {
			return;
		}

		$service_id       = absint( $booking->service_id );
		$service_supports = self::admin_service_allows_recurring( $service_id );
		$can_preview      = $service_supports && $booking->is_start_date_and_time_set();
		$rules            = self::admin_default_recurrence_rules( $booking );
		$preview          = $can_preview ? self::admin_compute_recurring_preview( $booking, $rules, [] ) : null;

		?>
		<div class="admin-recurring-section<?php echo $service_supports ? '' : ' is-unsupported'; ?>"
			data-order-item-id="<?php echo esc_attr( self::admin_sanitize_key( $order_item_id ) ); ?>"
			data-booking-form-id="<?php echo esc_attr( self::admin_sanitize_key( $booking->get_form_id() ) ); ?>"
			data-field-prefix="<?php echo esc_attr( $field_prefix ); ?>"
			data-preview-route-name="<?php echo esc_attr( OsRouterHelper::build_route_name( 'recurring_bookings', 'admin_recurring_preview' ) ); ?>"
			data-expand-route-name="<?php echo esc_attr( OsRouterHelper::build_route_name( 'recurring_bookings', 'admin_recurring_expand' ) ); ?>">


			<div class="admin-recurring-heading">
				<i class="latepoint-icon latepoint-icon-refresh"></i>
				<span><?php esc_html_e( 'Recurring Schedule', 'latepoint-pro-features' ); ?></span>
			</div>

			<div class="admin-recurring-body">
				<div class="admin-recurring-banner"></div>

				<?php // Rules left, "Review Slots" right - the same split the booking form step uses. ?>
				<div class="admin-recurring-columns">
					<div class="admin-recurring-rules-pane">
						<div class="admin-recurring-rules-holder">
							<?php
							if ( $service_supports ) {
								echo self::admin_render_recurrence_rules_form( $booking, $rules, $field_prefix );
							} else {
								?>
								<div class="admin-recurring-placeholder"><?php esc_html_e( 'Pick a service that has recurring appointments enabled.', 'latepoint-pro-features' ); ?></div>
								<?php
							}
							?>
						</div>

						<div class="os-recurrence-selection-fields-wrapper">
							<?php echo $preview ? self::admin_render_recurring_override_fields( $preview['bookings_data'], $field_prefix ) : ''; ?>
						</div>
					</div>

					<div class="admin-recurring-preview-pane">
						<div class="summary-header">
							<div class="summary-header-inner">
								<span class="summary-header-label"><?php esc_html_e( 'Review Slots', 'latepoint-pro-features' ); ?></span>
							</div>
						</div>
						<div class="recurring-bookings-preview-wrapper"><?php echo $preview ? self::admin_render_recurring_slots( $preview, $booking ) : ''; ?></div>
						<div class="recurring-bookings-preview-total-wrapper"><?php echo $preview ? self::generate_price_info_for_recurring_set( $preview['bookings_data'], false, [ 'ignore_availability' => true ] ) : ''; ?></div>
					</div>
				</div>

				<?php // Below both columns, so it reads as "set the rules, review the slots, then add them". ?>
				<div class="admin-recurring-actions">
					<a href="#" class="latepoint-btn latepoint-btn-primary admin-recurring-expand-btn"><?php esc_html_e( 'Add appointments to order', 'latepoint-pro-features' ); ?></a>
				</div>

				<?php echo OsFormHelper::hidden_field( $field_prefix . '[token]', '', [ 'class' => 'admin-recurring-token-field' ] ); ?>
				<?php echo OsFormHelper::hidden_field( 'order_items[' . self::admin_sanitize_key( $order_item_id ) . '][bookings][' . self::admin_sanitize_key( $booking->get_form_id() ) . '][recurrence_id]', '', [ 'class' => 'admin-recurring-id-field' ] ); ?>
			</div>
		</div>
		<?php
	}

	/**
	 * Replaces the collapsed pill of the recurring order item with the stacked card a bundle uses, so folding
	 * the item reads as "this is a series", not as a single appointment.
	 *
	 * Two shapes: the stacked card for the series item being set up, and the compact row for a saved occurrence
	 * inside it. Every other booking keeps core's pill.
	 *
	 * @param string $html
	 * @param OsBookingModel $booking
	 * @param string $order_item_id
	 *
	 * @return string
	 */
	public static function recurring_order_item_pill( $html, $booking, $order_item_id ) {
		if ( ! ( $booking instanceof OsBookingModel ) ) {
			return $html;
		}

		// A saved occurrence inside the series card gets a bundle session's compact row.
		if ( self::is_grouped_series_member( $booking ) ) {
			return self::recurring_series_member_pill( $booking, (string) $order_item_id );
		}
		// Two entry points: the initial render of the recurring item, and orders__fold_booking_data_form, which
		// re-renders the pill from the posted form and knows nothing about the flag - there the recurrence
		// fields posted alongside the booking are what identify it.
		$recurrence_in_request = self::recurrence_params_in_request( (string) $order_item_id, $booking );
		if ( ! self::$is_rendering_recurring_form && empty( $recurrence_in_request['rules'] ) ) {
			return $html;
		}

		$service      = $booking->service_id ? $booking->service : null;
		$service_name = ( $service instanceof OsServiceModel && ! empty( $service->id ) )
			? $service->name
			: __( 'Recurring appointment', 'latepoint-pro-features' );

		// One override per generated slot, so this is the real selection, not the rule's requested length.
		$count = 0;
		foreach ( ( $recurrence_in_request['overrides'] ?? [] ) as $override ) {
			if ( is_array( $override ) && ( $override['unchecked'] ?? 'no' ) !== 'yes' ) {
				$count++;
			}
		}
		if ( $count < 1 ) {
			// Nothing generated yet, so the rules' own length is the estimate.
			$rules = self::admin_default_recurrence_rules( $booking );
			$count = absint( $rules['repeat_end_counter'] ?? 0 );
		}

		$order_item_id = self::admin_sanitize_key( (string) $order_item_id );

		// Both classes matter: -booking is what core's click-to-unfold handler binds to, -bundle gives the
		// stacked layout. The hidden inputs must survive - the save path reads the item's id from this pill.
		$pill  = '<div class="order-item-pill order-item-pill-variant-booking order-item-pill-variant-bundle order-item-pill-variant-recurring" data-order-item-id="' . esc_attr( $order_item_id ) . '">';
		$pill .= '<input name="order_items[' . esc_attr( $order_item_id ) . '][id]" class="order_item_id" value="' . esc_attr( $order_item_id ) . '" type="hidden"/>';
		$pill .= '<input name="order_items[' . esc_attr( $order_item_id ) . '][variant]" value="' . esc_attr( LATEPOINT_ITEM_VARIANT_BOOKING ) . '" type="hidden"/>';
		$pill .= '<div class="order-item-pill-inner">';
		$pill .= '<div class="order-item-remove-btn remove-order-item-btn" data-os-prompt="' . esc_attr__( 'Are you sure you want to remove this recurring appointment from the order?', 'latepoint-pro-features' ) . '"></div>';
		$pill .= '<div class="summary-box main-box">';
		$pill .= '<div class="summary-box-content is-removable">';
		$pill .= '<div class="sbc-big-item">' . esc_html( $service_name ) . '</div>';
		$pill .= '<div class="sbc-subtle-item recurring-pill-summary">' . esc_html( self::recurring_pill_summary( $count ) ) . '</div>';
		$pill .= '</div>';
		$pill .= '<div class="bookable-items recurring-pill-items">' . self::recurring_pill_dots( $count ) . '</div>';
		$pill .= '</div>';
		// Clicking it falls through to core's pill handler, which unfolds the item.
		$pill .= '<div class="bundle-icon"><i class="latepoint-icon latepoint-icon-chevron-down"></i></div>';
		$pill .= '</div>';
		$pill .= '<div class="order-item-shadow"></div><div class="order-item-shadow"></div>';
		$pill .= '</div>';

		return $pill;
	}

	/**
	 * The recurring panel's params out of the request being handled. Needed because
	 * orders__fold_booking_data_form re-renders the pill from the posted form and knows nothing about the flag.
	 *
	 * @param string $order_item_id
	 * @param OsBookingModel $booking
	 *
	 * @return array
	 */
	private static function recurrence_params_in_request( string $order_item_id, OsBookingModel $booking ): array {
		$params     = OsParamsHelper::get_params();
		$form_id    = self::admin_sanitize_key( (string) $booking->get_form_id() );
		$recurrence = $params['order_items'][ self::admin_sanitize_key( $order_item_id ) ]['bookings'][ $form_id ]['recurrence'] ?? null;

		return is_array( $recurrence ) ? $recurrence : [];
	}

	/**
	 * Whether this booking is drawn inside the series card. A lone survivor is not - it stays an ordinary item.
	 *
	 * @param OsBookingModel $booking
	 *
	 * @return bool
	 */
	private static function is_grouped_series_member( OsBookingModel $booking ): bool {
		if ( $booking->is_new_record() || empty( $booking->recurrence_id ) ) {
			return false;
		}

		return self::recurring_series_size( absint( $booking->recurrence_id ) ) > 1;
	}

	/**
	 * Appointments in a series. Memoised: one query per series, not one per occurrence.
	 *
	 * @param int $recurrence_id
	 *
	 * @return int
	 */
	private static function recurring_series_size( int $recurrence_id ): int {
		if ( $recurrence_id < 1 ) {
			return 0;
		}

		if ( ! isset( self::$recurring_series_sizes[ $recurrence_id ] ) ) {
			self::$recurring_series_sizes[ $recurrence_id ] = ( new OsBookingModel() )->where( [ 'recurrence_id' => $recurrence_id ] )->count();
		}

		return self::$recurring_series_sizes[ $recurrence_id ];
	}

	/**
	 * The collapsed row for one appointment, using core's compact bundle session markup so core's styling and
	 * click to unfold drive it unchanged.
	 *
	 * Unlike a bundle session it carries the item's hidden id and variant, because the occurrence is its own
	 * order item. Like one, it has no remove button: the card owns the series, the form's trash icon owns one.
	 *
	 * @param OsBookingModel $booking
	 * @param string $order_item_id
	 *
	 * @return string
	 */
	private static function recurring_series_member_pill( OsBookingModel $booking, string $order_item_id ): string {
		$order_item_id = self::admin_sanitize_key( $order_item_id );
		$is_past       = $booking->is_upcoming() ? '' : 'is-past';

		// order-item-pill is what the fold routine replaces; the other carries core's compact session styling.
		$html  = '<div class="order-item-pill order-item-variant-bundle-booking is-booked" data-order-item-id="' . esc_attr( $order_item_id ) . '">';
		$html .= '<input name="order_items[' . esc_attr( $order_item_id ) . '][id]" class="order_item_id" value="' . esc_attr( $order_item_id ) . '" type="hidden"/>';
		$html .= '<input name="order_items[' . esc_attr( $order_item_id ) . '][variant]" value="' . esc_attr( LATEPOINT_ITEM_VARIANT_BOOKING ) . '" type="hidden"/>';
		$html .= '<div class="bundle-booking-item-pill ' . esc_attr( $is_past ) . ' status-' . esc_attr( $booking->status ) . '">';
		$html .= '<div class="bundle-booking-item-pill-inner">';
		$html .= '<div class="booking-item-status-pill"></div>';
		$html .= '<div class="bib-datetime">' . esc_html( $booking->get_nice_start_datetime() ) . '</div>';
		$html .= '</div>';
		$html .= '</div>';
		$html .= '</div>';

		return $html;
	}

	/**
	 * One segment per appointment, the same indicator a bundle shows for its sessions.
	 *
	 * @param int $count
	 *
	 * @return string
	 */
	public static function recurring_pill_dots( int $count ): string {
		$html = '';
		for ( $i = 0; $i < max( 0, $count ); $i++ ) {
			$html .= '<div class="bookable-item is-booked"></div>';
		}

		return $html;
	}

	/**
	 * @param int $count
	 *
	 * @return string
	 */
	public static function recurring_pill_summary( int $count ): string {
		if ( $count < 1 ) {
			return __( 'No appointments selected', 'latepoint-pro-features' );
		}

		// translators: %d is the number of appointments in the recurring series.
		return sprintf( _n( '%d recurring appointment', '%d recurring appointments', $count, 'latepoint-pro-features' ), $count );
	}

	/**
	 * latepoint_order_quick_edit_booking_items_after - one empty card per recurring series, printed after core's
	 * own order items. _recurring-admin.js then moves each series' items inside its card.
	 *
	 * Presentation only: each occurrence keeps its own order item and form, so the form still posts one item per
	 * appointment. The previous build really did store the series as one item, and that is what made the total
	 * show a single appointment.
	 *
	 * @param array $order_bookings OsBookingModel per order item id.
	 * @param OsOrderModel $order
	 *
	 * @return void
	 */
	public static function output_recurring_groups( $order_bookings, $order ) {
		if ( ! is_array( $order_bookings ) ) {
			return;
		}

		$series = [];
		foreach ( $order_bookings as $order_item_id => $booking ) {
			if ( ! ( $booking instanceof OsBookingModel ) || empty( $booking->recurrence_id ) ) {
				continue;
			}
			$series[ absint( $booking->recurrence_id ) ][ (string) $order_item_id ] = $booking;
		}

		foreach ( $series as $recurrence_id => $members ) {
			// A lone survivor reads better as an ordinary appointment - core already marks it as recurring.
			if ( count( $members ) < 2 ) {
				continue;
			}

			/**
			 * The card a recurring series is folded into, before it is printed.
			 *
			 * @param string $html
			 * @param int $recurrence_id
			 * @param OsBookingModel[] $members Keyed by order item id.
			 */
			echo apply_filters(
				'latepoint_recurring_order_item_group_html',
				self::render_recurring_group( $recurrence_id, $members ),
				$recurrence_id,
				$members
			);
		}
	}

	/**
	 * The stacked card, printed empty. Class names mirror core's bundle item, so its chevron handler and
	 * open/closed styling drive this with no extra javascript.
	 *
	 * @param int $recurrence_id
	 * @param OsBookingModel[] $members Keyed by order item id.
	 *
	 * @return string
	 */
	public static function render_recurring_group( int $recurrence_id, array $members ): string {
		$count = count( $members );
		$first = reset( $members );

		$service      = ( $first instanceof OsBookingModel && $first->service_id ) ? $first->service : null;
		$service_name = ( $service instanceof OsServiceModel && ! empty( $service->id ) )
			? $service->name
			: __( 'Recurring appointment', 'latepoint-pro-features' );

		// translators: %d is the number of appointments in the recurring series.
		$subtitle = sprintf( _n( '%d recurring appointment', '%d recurring appointments', $count, 'latepoint-pro-features' ), $count );

		$dots = '';
		foreach ( $members as $member ) {
			$is_past = ( $member instanceof OsBookingModel && ! $member->is_upcoming() ) ? 'is-past' : '';
			$dots   .= '<div class="bookable-item is-booked ' . esc_attr( $is_past ) . '"></div>';
		}

		// Nesting matches generate_order_summary_for_bundle() - core's open/closed rules expect that shape.
		$html  = '<div class="order-item order-item-variant-bundle order-item-variant-recurring is-folding" data-recurrence-id="' . esc_attr( $recurrence_id ) . '"';
		$html .= ' data-recurring-order-item-ids="' . esc_attr( implode( ',', array_keys( $members ) ) ) . '">';
		$html .= '<div class="order-item-pill order-item-pill-variant-bundle order-item-pill-variant-recurring">';
		$html .= '<div class="order-item-pill-inner">';
		$html .= '<div class="order-item-remove-btn remove-order-item-btn" data-os-prompt="' . esc_attr__( 'Are you sure you want to remove this item from the order? All appointments in the series will be removed as well.', 'latepoint-pro-features' ) . '"></div>';
		$html .= '<div class="summary-box main-box">';
		$html .= '<div class="summary-box-content">';
		$html .= '<div class="sbc-big-item">' . esc_html( $service_name ) . '</div>';
		$html .= '<div class="sbc-subtle-item">' . esc_html( $subtitle ) . '</div>';
		$html .= '</div>';
		$html .= '<div class="bookable-items-breakdown"></div>';
		$html .= '<div class="bookable-items">' . $dots . '</div>';
		$html .= '</div>';
		$html .= '<div class="bundle-icon"><i class="latepoint-icon latepoint-icon-chevron-down"></i></div>';
		$html .= '</div>';
		$html .= '<div class="order-item-shadow"></div><div class="order-item-shadow"></div>';
		$html .= '</div>';
		$html .= '</div>';

		return $html;
	}

	/**
	 * Read only row for a booking already in a series. Carries recurrence_id back so the link survives a
	 * re-save - it is already an allowed and saved param on OsBookingModel.
	 *
	 * @param OsBookingModel $booking
	 * @param string $order_item_id
	 *
	 * @return string
	 */
	public static function admin_render_series_member_row( OsBookingModel $booking, string $order_item_id ): string {
		$html  = '<div class="admin-recurring-series-member">';
		$html .= '<i class="latepoint-icon latepoint-icon-refresh-cw"></i>';
		$html .= '<span>' . esc_html__( 'Part of a recurring series', 'latepoint-pro-features' ) . '</span>';
		$html .= '</div>';
		$html .= OsFormHelper::hidden_field(
			'order_items[' . self::admin_sanitize_key( $order_item_id ) . '][bookings][' . self::admin_sanitize_key( $booking->get_form_id() ) . '][recurrence_id]',
			$booking->recurrence_id,
			[ 'class' => 'admin-recurring-id-field' ]
		);

		return $html;
	}

	/**
	 * Every selected occurrence except the anchor, as a folded booking data form wrapped the way core wraps a
	 * new order item, so the ordinary save path picks each up as its own order item.
	 *
	 * @param OsBookingModel $first_booking
	 * @param array $bookings_data
	 * @param int $recurrence_id
	 *
	 * @return array{html: string, count: int}
	 */
	public static function admin_build_occurrence_blocks( OsBookingModel $first_booking, array $bookings_data, int $recurrence_id ): array {
		$html  = '';
		$count = 0;

		// Always the first entry - generate_recurring_bookings_data() seeds the list with it. Matched by key, not
		// start time: that method holds the anchor itself, so an override on it mutates what we would compare to.
		$anchor_stamp = array_key_first( $bookings_data );

		foreach ( $bookings_data as $stamp => $datum ) {
			if ( empty( $datum['booking'] ) || ! ( $datum['booking'] instanceof OsBookingModel ) ) {
				continue;
			}
			if ( ( $datum['unchecked'] ?? 'no' ) === 'yes' ) {
				continue;
			}
			if ( $stamp === $anchor_stamp ) {
				// Already in the form as the order item this panel is attached to.
				continue;
			}
			if ( $count >= self::ADMIN_MAX_OCCURRENCES ) {
				break;
			}

			$occurrence                = clone $datum['booking'];
			$occurrence->id            = null;
			$occurrence->booking_code  = '';
			$occurrence->cart_item_id  = null;
			$occurrence->order_item_id = null;
			$occurrence->created_at    = null;
			$occurrence->updated_at    = null;
			$occurrence->customer_id   = $first_booking->customer_id;
			$occurrence->recurrence_id = $recurrence_id;
			$occurrence->form_id       = OsUtilHelper::generate_form_id();

			$order_item_id = OsUtilHelper::generate_form_id();

			$html .= '<div class="order-item order-item-variant-booking" data-order-item-id="' . esc_attr( $order_item_id ) . '" data-recurrence-id="' . esc_attr( $recurrence_id ) . '">';
			$html .= OsOrdersHelper::booking_data_form_for_order_item_id( $order_item_id, $occurrence, LATEPOINT_ITEM_VARIANT_BOOKING, true );
			$html .= '</div>';
			$count++;
		}

		return [
			'html'  => $html,
			'count' => $count,
		];
	}

	/**
	 * Guards recurrence_id off the request: it is an allowed and saved param, so without this a hand crafted
	 * POST could point a booking at an arbitrary recurrence.
	 *
	 * @param OsModel $model
	 * @param array $data
	 *
	 * @return void
	 */
	public static function sanitize_recurrence_id_on_booking( $model, $data = [] ) {
		if ( ! ( $model instanceof OsBookingModel ) ) {
			return;
		}
		if ( ! is_array( $data ) || ! isset( $data['recurrence_id'] ) ) {
			return;
		}

		$recurrence_id = absint( $data['recurrence_id'] );
		if ( empty( $recurrence_id ) ) {
			$model->recurrence_id = null;

			return;
		}

		if ( ! isset( self::$verified_recurrence_ids[ $recurrence_id ] ) ) {
			$recurrence                                      = new OsRecurrenceModel( $recurrence_id );
			self::$verified_recurrence_ids[ $recurrence_id ] = ! $recurrence->is_new_record();
		}

		$model->recurrence_id = self::$verified_recurrence_ids[ $recurrence_id ] ? $recurrence_id : null;
	}

	/**
	 * @param array $capabilities
	 *
	 * @return array
	 */
	public static function add_capabilities_for_controller( array $capabilities ): array {
		$capabilities['OsRecurringBookingsController']['per_action'] = [
			'generate_recurring_order_item_block' => [ 'booking__create' ],
			'admin_recurring_preview'             => [ 'booking__view' ],
			'admin_recurring_expand'              => [ 'booking__create' ],
		];

		return $capabilities;
	}

	/* -------------------------------------------------------------------------
	 * The "Recurring" item type in the New Order picker.
	 * ---------------------------------------------------------------------- */

	/**
	 * Active services the current user may book that allow recurring. With none, the tile never appears and the
	 * admin screen is exactly as it was.
	 *
	 * @return array
	 */
	public static function get_recurring_enabled_services(): array {
		if ( null !== self::$recurring_services_cache ) {
			return self::$recurring_services_cache;
		}

		$result   = [];
		$services = OsServiceHelper::get_allowed_active_services();

		if ( ! empty( $services ) ) {
			$service_ids = [];
			foreach ( $services as $service ) {
				$service_ids[] = (int) $service->id;
			}
			$enabled_map = self::get_recurring_enabled_service_ids_map( $service_ids );
			foreach ( $services as $service ) {
				if ( isset( $enabled_map[ (int) $service->id ] ) ) {
					$result[] = $service;
					// Warm the per service memo so the panel does not re-query for the same answer.
					self::$admin_service_supports_recurring[ (int) $service->id ] = true;
				}
			}
		}

		self::$recurring_services_cache = $result;

		return $result;
	}

	/**
	 * One query for every service's allow_recurring_bookings meta, instead of one per service.
	 *
	 * @param array $service_ids
	 *
	 * @return array<int, bool>
	 */
	private static function get_recurring_enabled_service_ids_map( array $service_ids ): array {
		global $wpdb;

		$service_ids = array_filter( array_map( 'absint', $service_ids ) );
		if ( empty( $service_ids ) ) {
			return [];
		}

		$placeholders = implode( ',', array_fill( 0, count( $service_ids ), '%d' ) );
		$query        = $wpdb->prepare(
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table name is a constant, ids are placeholders.
			'SELECT object_id FROM ' . LATEPOINT_TABLE_SERVICE_META . " WHERE meta_key = %s AND meta_value = %s AND object_id IN ( $placeholders )",
			array_merge( [ 'allow_recurring_bookings', LATEPOINT_VALUE_ON ], $service_ids )
		);

		$map = [];
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared
		foreach ( (array) $wpdb->get_col( $query ) as $service_id ) {
			$map[ (int) $service_id ] = true;
		}

		return $map;
	}

	/**
	 * latepoint_order_quick_edit_has_extra_variants - show the item type picker even when there are no bundles.
	 *
	 * @param bool $has_extra_variants
	 * @param OsOrderModel $order
	 *
	 * @return bool
	 */
	public static function has_recurring_variant( $has_extra_variants, $order ) {
		if ( $has_extra_variants ) {
			return $has_extra_variants;
		}
		// A series is several order items, which the modal only offers when multi item orders are on.
		if ( ! OsCartsHelper::can_checkout_multiple_items() ) {
			return $has_extra_variants;
		}

		return ! empty( self::get_recurring_enabled_services() );
	}

	/**
	 * latepoint_order_quick_edit_variant_tiles - the "Recurring" tile next to Booking and Bundle.
	 *
	 * @param OsOrderModel $order
	 *
	 * @return void
	 */
	public static function output_recurring_variant_tile( $order ) {
		$services = self::get_recurring_enabled_services();
		if ( empty( $services ) || ! OsCartsHelper::can_checkout_multiple_items() ) {
			return;
		}

		$order_id     = ( $order instanceof OsOrderModel && ! $order->is_new_record() ) ? $order->id : 0;
		$nonce_action = $order_id ? 'edit_order_' . $order_id : 'new_order';
		?>
		<div class="new-order-item-variant new-order-item-variant-recurring"
			data-route-name="<?php echo esc_attr( OsRouterHelper::build_route_name( 'recurring_bookings', 'generate_recurring_order_item_block' ) ); ?>"
			data-order-id="<?php echo esc_attr( $order_id ); ?>"
			data-nonce="<?php echo esc_attr( wp_create_nonce( $nonce_action ) ); ?>">
			<i class="latepoint-icon latepoint-icon-refresh"></i>
			<div><?php esc_html_e( 'Recurring', 'latepoint-pro-features' ); ?></div>
		</div>
		<?php
	}

	/**
	 * latepoint_order_quick_edit_item_pickers - service list shown when more than one service allows recurring.
	 *
	 * @param OsOrderModel $order
	 *
	 * @return void
	 */
	public static function output_recurring_services_picker( $order ) {
		$services = self::get_recurring_enabled_services();
		if ( count( $services ) <= 1 || ! OsCartsHelper::can_checkout_multiple_items() ) {
			return;
		}

		$order_id     = ( $order instanceof OsOrderModel && ! $order->is_new_record() ) ? $order->id : 0;
		$nonce_action = $order_id ? 'edit_order_' . $order_id : 'new_order';
		?>
		<div class="new-order-item-list-recurring-services-wrapper new-order-item-list-extra-picker-wrapper">
			<div class="centered-question-label"><?php esc_html_e( 'Select a service for the recurring appointment', 'latepoint-pro-features' ); ?></div>
			<div class="new-order-item-list-recurring-services">
				<?php
				foreach ( $services as $recurring_service ) {
					echo '<div class="new-order-item-list-recurring-service"
								data-os-after-call="latepoint_recurring_added_to_quick_order"
								data-os-pass-this="yes"
								data-os-output-target=".order-items-list"
								data-os-output-target-do="prepend"
								data-os-action="' . esc_attr( OsRouterHelper::build_route_name( 'recurring_bookings', 'generate_recurring_order_item_block' ) ) . '"
								data-os-params="' . esc_attr(
									OsUtilHelper::build_os_params(
										[
											'service_id' => $recurring_service->id,
											'order_id'   => $order_id,
										],
										$nonce_action
									)
								) . '">
							<div class="noi-description-wrapper">
								<div class="noi-label">' . esc_html( $recurring_service->name ) . '</div>
								<div class="noi-description">' . esc_html( sprintf( __( '%d min', 'latepoint-pro-features' ), $recurring_service->duration ) ) . '</div>
							</div>
							<div class="noi-price">' . esc_html( OsMoneyHelper::format_price( $recurring_service->charge_amount, true, false ) ) . '</div>
						</div>';
				}
				?>
			</div>
		</div>
		<?php
	}

	/**
	 * Marks the block being rendered as the recurring one, so the panel attaches to it and nothing else.
	 *
	 * @param bool $is_rendering
	 *
	 * @return void
	 */
	public static function set_rendering_recurring_form( bool $is_rendering ) {
		self::$is_rendering_recurring_form = $is_rendering;
	}
}
