<?php

class OsProTranslationHelper {

	public static function init_hooks(): void {
		// Registered unconditionally (not gated behind any feature flag) so booking-form step
		// settings seeded while a feature was enabled still translate after it's turned off.
		add_filter( 'latepoint_translatable_default_strings', [ __CLASS__, 'register_translatable_strings' ] );
	}

	/**
	 * Registers this plugin's booking-form default strings on the free plugin's
	 * `latepoint_translatable_default_strings` filter, using this plugin's own text domain so Loco
	 * Translate (and any other .po/.mo based tool) picks them up under "latepoint-pro-features".
	 *
	 * Values here are stored as-is (not gettext-wrapped) in each feature's add_settings_for_step()
	 * method because they get auto-seeded into the `steps_settings` DB option on first load. Any
	 * string changed there must be mirrored here.
	 *
	 * @param array<string, string> $strings Map of English source string => translated string.
	 *
	 * @return array<string, string>
	 */
	public static function register_translatable_strings( array $strings ): array {
		$pro_strings = [
			// Service extras step (feature_service_extras_helper.php).
			'Service Extras Selection'                 => __( 'Service Extras Selection', 'latepoint-pro-features' ),
			'Please select service extras for your appointment' => __( 'Please select service extras for your appointment', 'latepoint-pro-features' ),
			'Service Extras'                           => __( 'Service Extras', 'latepoint-pro-features' ),

			// Recurring bookings step (feature_recurring_bookings_helper.php).
			'Recurring Appointment'                    => __( 'Recurring Appointment', 'latepoint-pro-features' ),
			'Please select if you want to make it a recurring appointment' => __( 'Please select if you want to make it a recurring appointment', 'latepoint-pro-features' ),

			// Locations step (feature_locations_helper.php).
			'Location Selections'                      => __( 'Location Selections', 'latepoint-pro-features' ),
			'Please select a location for your appointment' => __( 'Please select a location for your appointment', 'latepoint-pro-features' ),
			'Locations'                                => __( 'Locations', 'latepoint-pro-features' ),

			// Service durations step (feature_service_durations_helper.php).
			'Service Duration Selections'              => __( 'Service Duration Selections', 'latepoint-pro-features' ),
			'Please select service duration for your appointment' => __( 'Please select service duration for your appointment', 'latepoint-pro-features' ),
			'Service Durations'                        => __( 'Service Durations', 'latepoint-pro-features' ),

			// Group bookings step (feature_group_bookings_helper.php).
			'Total Attendees'                          => __( 'Total Attendees', 'latepoint-pro-features' ),
			'Please select how many people are coming' => __( 'Please select how many people are coming', 'latepoint-pro-features' ),

			// Custom fields step (feature_custom_fields_helper.php).
			'Custom Fields'                            => __( 'Custom Fields', 'latepoint-pro-features' ),
			'Please answer this set of questions to proceed.' => __( 'Please answer this set of questions to proceed.', 'latepoint-pro-features' ),
		];

		return array_merge( $strings, $pro_strings );
	}
}
