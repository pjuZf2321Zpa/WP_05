<?php
/*
 * Copyright (c) 2024 LatePoint LLC. All rights reserved.
 */

class OsEventTicketQrHelper {

	/**
	 * Raw PNG bytes for the QR code — used by the qr_image route so it can be embedded
	 * as a normal hosted <img> in emails (webmail clients strip data: URIs).
	 */
	public static function render_png( string $code, int $scale = 6 ): string {
		$options = new chillerlan\QRCode\QROptions(
			[
				'outputType'       => chillerlan\QRCode\Output\QROutputInterface::GDIMAGE_PNG,
				'outputBase64'     => false,
				'scale'            => $scale,
				'imageTransparent' => false,
			]
		);

		return ( new chillerlan\QRCode\QRCode( $options ) )->render( self::build_qr_payload( $code ) );
	}

	/**
	 * data: URI form, for embedding inside the PDF ticket template (Dompdf renders <img> tags,
	 * not remote requests, so a hosted URL isn't an option there).
	 */
	public static function render_data_uri( string $code, int $scale = 5 ): string {
		$options = new chillerlan\QRCode\QROptions(
			[
				'outputType'       => chillerlan\QRCode\Output\QROutputInterface::GDIMAGE_PNG,
				'outputBase64'     => true,
				'scale'            => $scale,
				'imageTransparent' => false,
			]
		);

		return ( new chillerlan\QRCode\QRCode( $options ) )->render( self::build_qr_payload( $code ) );
	}

	/**
	 * The QR encodes the public ticket page URL so a plain phone camera (no app) can open it
	 * directly, while the in-admin scanner pulls `code` back out of the same URL.
	 */
	public static function build_qr_payload( string $code ): string {
		$ticket              = new OsEventTicketModel();
		$ticket->ticket_code = $code;

		return $ticket->get_public_url();
	}

	/**
	 * Renders a single-ticket PDF and returns its binary content.
	 */
	public static function build_ticket_pdf( OsEventTicketModel $ticket ): string {
		$event = $ticket->get_event();

		ob_start();
		include LATEPOINT_ADDON_PRO_VIEWS_ABSPATH . 'event_tickets/_ticket_pdf.php';
		$html = ob_get_clean();

		$dompdf = new Dompdf\Dompdf( [ 'isRemoteEnabled' => false ] );
		$dompdf->setPaper( 'A4', 'portrait' );
		$dompdf->loadHtml( $html );
		$dompdf->render();

		return $dompdf->output();
	}

	/**
	 * Writes the PDF to a temp file and returns its path, for use as an email attachment.
	 * Caller is responsible for deleting it after send (see ProcessAction's
	 * `_attachments_temp_files` cleanup, which OsFeatureEventTicketsHelper hooks into).
	 */
	public static function build_ticket_pdf_temp_file( OsEventTicketModel $ticket ): ?string {
		$pdf_content = self::build_ticket_pdf( $ticket );
		if ( empty( $pdf_content ) ) {
			return null;
		}

		$temp_file = tempnam( sys_get_temp_dir(), 'latepoint_eticket_' );
		if ( ! $temp_file ) {
			return null;
		}
		$pdf_temp_file = $temp_file . '.pdf';
		rename( $temp_file, $pdf_temp_file );

		file_put_contents( $pdf_temp_file, $pdf_content );

		return $pdf_temp_file;
	}

	const MAX_EVENT_SLUG_LENGTH = 60;

	/**
	 * Descriptive filename to show the recipient, decoupled from the random tempnam() path
	 * build_ticket_pdf_temp_file() actually writes to on disk. The registration code is already
	 * guaranteed unique (event_registration_model.php generates it the same way ticket codes
	 * are generated), so no collision-detection/random-suffix logic is needed here.
	 */
	public static function build_ticket_display_filename( OsEventTicketModel $ticket ): string {
		$event      = $ticket->get_event();
		$event_slug = $event ? sanitize_title( $event->name ) : '';
		$event_slug = trim( mb_substr( $event_slug, 0, self::MAX_EVENT_SLUG_LENGTH ), '-' );
		if ( '' === $event_slug ) {
			$event_slug = 'event';
		}

		if ( $ticket->is_group_ticket() ) {
			$descriptor = 'group';
		} else {
			$total      = count( $ticket->get_sibling_individual_tickets() );
			$descriptor = $total > 1 ? (string) max( 1, (int) $ticket->ticket_number ) : '';
		}

		$reg      = $ticket->get_registration();
		$reg_code = $reg ? sanitize_file_name( $reg->registration_code ) : sanitize_file_name( $ticket->ticket_code );

		return implode( '-', array_filter( [ $event_slug, 'e-ticket', $descriptor, $reg_code ] ) ) . '.pdf';
	}
}
