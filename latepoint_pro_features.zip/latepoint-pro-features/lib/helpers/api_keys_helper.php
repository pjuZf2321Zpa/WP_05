<?php
/*
 * Copyright (c) 2024 LatePoint LLC. All rights reserved.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Credential-level read/write/delete permissions for the free plugin's REST API.
 *
 * Custom keys: a single non-autoloaded `latepoint_api_keys` option (no new DB table) —
 * {id, label, user_id, hashed_key, can_read, can_write, can_delete, created_at,
 * last_used_at, revoked_at}. Only a hash of the key is ever persisted; the raw key is
 * returned exactly once, at creation, and cannot be retrieved again. Generation mirrors
 * OsUtilHelper::generate_key_to_manage() (free plugin) — random_bytes(), not a predictable
 * source.
 *
 * hash_key() is a plain, unsalted SHA-256 hash — no HMAC, no secret mixed in. That's
 * deliberate: a salt/pepper exists to make a low-entropy secret (a password) resistant to
 * dictionary/rainbow-table attacks. The raw key here is 192 bits of random_bytes(), already
 * far beyond brute-forceable regardless of any secret mixed into the hash — exactly how
 * GitHub/Stripe/AWS verify their own high-entropy API tokens. Tying it to an external
 * secret (e.g. wp_salt('auth')) would only add a liability: that salt can legitimately
 * change for reasons that have nothing to do with this plugin (a routine security-hardening
 * key rotation, a staging-to-production migration with fresh salts), silently invalidating
 * every previously-issued key with no indication why. Still deliberately not
 * wp_check_password() — that's intentionally slow (bcrypt-shaped), the wrong tool for a
 * credential verified on every API request; hash_equals() for the comparison is what
 * actually matters for timing-safety here, independent of which hash algorithm feeds it.
 *
 * Custom keys only — the free plugin rejects WordPress Application Password auth outright
 * (OsAuthHelper::$authenticated_via_application_password) before this layer would ever run,
 * so this class never needs to cover that credential type.
 */
class OsApiKeysHelper {

	const OPTION_NAME = 'latepoint_api_keys';

	/**
	 * The permission record matched during the current request's authentication, if any —
	 * read by OsRestController::check_backend_access() via the latepoint_rest_api_key_permission
	 * filter. Populated by authenticate(). Null means no custom key was used to authenticate
	 * this request (e.g. a logged-in wp-admin browser session instead) — deliberately
	 * permissive in that specific case, since there's no credential to apply a toggle to at
	 * all; the real capability check is what governs that case, same as always.
	 *
	 * @var array|null
	 */
	private static $matched_key = null;

	/**
	 * @return array[]
	 */
	public static function get_keys(): array {
		$keys = get_option( self::OPTION_NAME, [] );

		return is_array( $keys ) ? $keys : [];
	}

	private static function save_keys( array $keys ): void {
		update_option( self::OPTION_NAME, $keys, false );
	}

	/**
	 * @param string $label
	 * @param int    $user_id
	 * @param bool   $can_read
	 * @param bool   $can_write
	 * @param bool   $can_delete
	 * @return array{record: array, raw_key: string}
	 */
	public static function create_key( string $label, int $user_id, bool $can_read, bool $can_write, bool $can_delete ): array {
		$raw_key = 'lp_' . bin2hex( random_bytes( 24 ) );
		$keys    = self::get_keys();

		$record = [
			'id'           => (string) wp_generate_uuid4(),
			'label'        => $label,
			'user_id'      => $user_id,
			'hashed_key'   => self::hash_key( $raw_key ),
			'can_read'     => $can_read,
			'can_write'    => $can_write,
			'can_delete'   => $can_delete,
			'created_at'   => current_time( 'mysql', true ),
			'last_used_at' => '',
			'revoked_at'   => '',
		];

		$keys[] = $record;
		self::save_keys( $keys );

		return [
			'record'  => $record,
			'raw_key' => $raw_key,
		];
	}

	public static function revoke_key( string $id ): bool {
		$keys    = self::get_keys();
		$revoked = false;

		foreach ( $keys as &$key ) {
			if ( $key['id'] === $id && empty( $key['revoked_at'] ) ) {
				$key['revoked_at'] = current_time( 'mysql', true );
				$revoked           = true;
			}
		}
		unset( $key );

		if ( $revoked ) {
			self::save_keys( $keys );
		}

		return $revoked;
	}

	/**
	 * Edits an existing custom key's label and toggles after creation — the generate-time
	 * values are no longer the only chance to set these.
	 *
	 * @param string $id
	 * @param string $label
	 * @param bool   $can_read
	 * @param bool   $can_write
	 * @param bool   $can_delete
	 * @return bool Whether a matching, non-revoked key was found and updated.
	 */
	public static function update_key( string $id, string $label, bool $can_read, bool $can_write, bool $can_delete ): bool {
		$keys    = self::get_keys();
		$updated = false;

		foreach ( $keys as &$key ) {
			if ( $key['id'] === $id && empty( $key['revoked_at'] ) ) {
				$key['label']      = $label;
				$key['can_read']   = $can_read;
				$key['can_write']  = $can_write;
				$key['can_delete'] = $can_delete;
				$updated           = true;
			}
		}
		unset( $key );

		if ( $updated ) {
			self::save_keys( $keys );
		}

		return $updated;
	}

	private static function hash_key( string $raw_key ): string {
		return hash( 'sha256', $raw_key );
	}

	/**
	 * Verifies a raw bearer token against the stored key list. On a match, stashes the
	 * record for the rest of this request (see $matched_key) and records last_used_at.
	 *
	 * The 'lp_' prefix check is a cheap fast-fail for tokens that obviously aren't one of
	 * ours (a mistaken Application Password passed as Bearer, a JWT, random garbage) —
	 * skips the hash computation and key-list loop entirely for those. Not a security
	 * boundary: the prefix is a static, already-documented format marker, not a secret.
	 *
	 * @param string $raw_token
	 * @return int|false The linked WP user id, or false if no active key matches.
	 */
	public static function authenticate( string $raw_token ) {
		if ( substr( $raw_token, 0, 3 ) !== 'lp_' ) {
			return false;
		}

		$hashed = self::hash_key( $raw_token );
		$keys   = self::get_keys();

		foreach ( $keys as $index => $key ) {
			if ( ! empty( $key['revoked_at'] ) ) {
				continue;
			}
			if ( ! hash_equals( $key['hashed_key'], $hashed ) ) {
				continue;
			}

			self::$matched_key = $key;

			$keys[ $index ]['last_used_at'] = current_time( 'mysql', true );
			self::save_keys( $keys );

			return (int) $key['user_id'];
		}

		return false;
	}

	/**
	 * @param string $operation One of read|create|update|delete.
	 * @return bool
	 */
	public static function matched_key_allows( string $operation ): bool {
		if ( null === self::$matched_key ) {
			// no API key was used to authenticate this request — nothing to restrict.
			return true;
		}

		switch ( $operation ) {
			case 'create':
			case 'update':
				return ! empty( self::$matched_key['can_write'] );
			case 'delete':
				return ! empty( self::$matched_key['can_delete'] );
			default:
				return ! empty( self::$matched_key['can_read'] );
		}
	}
}
