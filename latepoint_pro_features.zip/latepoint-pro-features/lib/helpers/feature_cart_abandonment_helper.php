<?php
/*
 * Copyright (c) 2026 LatePoint LLC. All rights reserved.
 */

class OsFeatureCartAbandonmentHelper {

	const EVENT_TYPE = 'cart_abandoned';

	// Opt-in: this feature hasn't shipped to any site yet, so there's no existing workflow to
	// avoid silently breaking by defaulting on.
	public static function is_enabled(): bool {
		return OsSettingsHelper::is_on( 'enable_cart_abandonment', LATEPOINT_VALUE_OFF );
	}

	public static function init_hooks(): void {
		// Settings UI must render in both states, or there'd be no way to turn the feature back on.
		add_action( 'latepoint_settings_general_before_other', 'OsFeatureCartAbandonmentHelper::output_settings' );
		add_filter( 'latepoint_general_settings_sticky_section_items', 'OsFeatureCartAbandonmentHelper::add_settings_sticky_menu_item' );

		// This is what actually enforces the toggle for jobs already scheduled - gating it would
		// mean disabling the feature never stops a pending reminder from sending.
		add_filter( 'latepoint_should_run_process_job', 'OsFeatureCartAbandonmentHelper::should_run_job', 10, 2 );

		// The type must stay listed for an existing workflow to keep editing safely even while
		// disabled - see add_process_event_types() for the existing-workflow carve-out.
		add_filter( 'latepoint_process_event_types', 'OsFeatureCartAbandonmentHelper::add_process_event_types' );

		// Pure display-name lookup, no side effects - keep historical job rows readable regardless.
		add_filter( 'latepoint_process_event_names', 'OsFeatureCartAbandonmentHelper::add_process_event_names' );

		if ( ! self::is_enabled() ) {
			return;
		}

		// Priority 20 runs after Free's own OsStepsHelper::process_step() (priority 10), which is
		// what actually saves the customer record - for both a new registration and an existing
		// customer logging in mid-flow. One hook covers both cases.
		add_action( 'latepoint_process_step', 'OsFeatureCartAbandonmentHelper::handle_customer_step', 20, 3 );
		add_action( 'latepoint_order_intent_converted', 'OsFeatureCartAbandonmentHelper::mark_abandonment_converted' );
		add_filter( 'latepoint_get_object_model_type_for_process', 'OsFeatureCartAbandonmentHelper::set_object_model_type_for_process', 10, 3 );
		add_filter( 'latepoint_get_event_time_utc_for_process', 'OsFeatureCartAbandonmentHelper::set_event_time_utc_for_process', 10, 3 );
		add_filter( 'latepoint_prepare_replacement_vars_from_data_objects', 'OsFeatureCartAbandonmentHelper::prepare_replacement_vars', 10, 3 );
		add_filter( 'latepoint_replace_all_vars_in_template', 'OsFeatureCartAbandonmentHelper::replace_vars_in_template', 10, 3 );
		add_filter( 'latepoint_load_templates_for_action_type', 'OsFeatureCartAbandonmentHelper::add_cart_abandonment_templates', 10, 3 );
		add_action( 'latepoint_available_vars_after', 'OsFeatureCartAbandonmentHelper::output_available_vars' );
	}

	public static function add_process_event_types( array $types ): array {
		if ( self::is_enabled() || self::has_existing_processes() ) {
			$types[] = self::EVENT_TYPE;
		}

		return $types;
	}

	// Memoized so repeated calls within a request (e.g. the dropdown + an existing workflow's own
	// edit form) don't each re-query. Keeps an existing "Cart Abandoned" workflow editable (and its
	// trigger from being silently rewritten on save) even while the feature is toggled off.
	private static function has_existing_processes(): bool {
		static $has_processes = null;
		if ( null === $has_processes ) {
			$process       = new OsProcessModel();
			$results       = $process->where( [ 'event_type' => self::EVENT_TYPE ] )->set_limit( 1 )->get_results_as_models();
			$has_processes = ! empty( $results );
		}

		return $has_processes;
	}

	public static function output_settings(): void {
		?>
		<div class="white-box section-anchor" id="stickySectionCartAbandonment">
			<div class="white-box-header">
				<div class="os-form-sub-header"><h3><?php esc_html_e( 'Cart Abandonment', 'latepoint-pro-features' ); ?></h3></div>
			</div>
			<div class="white-box-content no-padding">
				<div class="sub-section-row">
					<div class="sub-section-label">
						<h3><?php esc_html_e( 'Cart Abandonment', 'latepoint-pro-features' ); ?></h3>
					</div>
					<div class="sub-section-content">
						<?php
						echo OsFormHelper::toggler_field(
							'settings[enable_cart_abandonment]',
							__( 'Enable Cart Abandonment Reminders', 'latepoint-pro-features' ),
							self::is_enabled(),
							false,
							false,
							[ 'sub_label' => __( 'Lets you email customers who started a booking and left before paying, using the Cart Abandoned trigger in Automation.', 'latepoint-pro-features' ) ]
						);
						?>
					</div>
				</div>
			</div>
		</div>
		<?php
	}

	public static function add_settings_sticky_menu_item( array $items ): array {
		$items[] = [
			'href'  => 'stickySectionCartAbandonment',
			'label' => __( 'Cart Abandonment', 'latepoint-pro-features' ),
		];

		return $items;
	}

	// Checked at the moment a job would actually fire, not when the setting changes - a job already
	// scheduled while enabled simply won't send once its run time arrives if the feature has since
	// been disabled, with no need to proactively find and cancel rows when the setting is saved.
	public static function should_run_job( array $run_data, OsProcessJobModel $job ): array {
		if ( 'cart_abandonment' !== $job->object_model_type ) {
			return $run_data;
		}

		if ( ! self::is_enabled() ) {
			return array_merge(
				$run_data,
				[
					'should_run' => false,
					'reason'     => __( 'Cart Abandonment Reminders are disabled.', 'latepoint-pro-features' ),
				]
			);
		}

		$abandonment = new OsCartAbandonmentModel( $job->object_id );
		if ( $abandonment->is_converted() ) {
			return array_merge(
				$run_data,
				[
					'should_run' => false,
					'reason'     => __( 'This cart was already converted to an order.', 'latepoint-pro-features' ),
				]
			);
		}

		return $run_data;
	}

	public static function add_process_event_names( array $names ): array {
		$names[ self::EVENT_TYPE ] = __( 'Cart Abandoned', 'latepoint-pro-features' );

		return $names;
	}

	// Fires after Free's own customer-step handler has saved the customer (registration or an
	// existing customer logging in) - captures a snapshot of the cart at that point, well before an
	// order intent would normally exist. See the comment on LATEPOINT_TABLE_CART_ABANDONMENTS for
	// why this is a dedicated table rather than an early-minted OsOrderIntentModel.
	public static function handle_customer_step( string $step_code, $booking, array $params ): void {
		if ( 'customer' !== $step_code ) {
			return;
		}

		$customer = OsStepsHelper::get_customer_object();
		if ( $customer->is_new_record() || empty( $customer->email ) ) {
			return;
		}

		$cart = OsStepsHelper::build_cart_object();
		if ( empty( $cart->get_items() ) ) {
			return;
		}

		self::create_or_update_abandonment( $cart, $customer, $params );
	}

	// Upserts by cart_id so a visitor going back and forth on the customer step doesn't create
	// duplicate rows or duplicate reminder jobs (create_jobs_for_event() only runs for a brand new row).
	private static function create_or_update_abandonment( OsCartModel $cart, OsCustomerModel $customer, array $params ): OsCartAbandonmentModel {
		$abandonment = new OsCartAbandonmentModel();
		$existing    = $abandonment->where( [ 'cart_id' => $cart->id ] )->set_limit( 1 )->get_results_as_models();
		if ( $existing ) {
			$abandonment = $existing;
			if ( $abandonment->is_converted() ) {
				return $abandonment;
			}
		}
		$is_new = $abandonment->is_new_record();

		$abandonment->cart_id               = $cart->id;
		$abandonment->customer_id           = $customer->id;
		$abandonment->booking_form_page_url = $params['booking_form_page_url'] ?? OsUtilHelper::get_referrer();
		$abandonment->cart_items_data       = self::serialize_cart_items( $cart, $customer );
		$abandonment->total                 = $cart->get_total();
		$abandonment->subtotal              = $cart->get_subtotal();
		$abandonment->status                = 'pending';

		if ( $abandonment->save() && $is_new ) {
			$objects = [
				[
					'model'       => 'cart_abandonment',
					'id'          => $abandonment->id,
					'model_ready' => $abandonment,
				],
			];
			OsProcessJobsHelper::create_jobs_for_event( self::EVENT_TYPE, $objects );
		}

		return $abandonment;
	}

	// Same envelope OsOrderIntentHelper::set_order_intent_data_from_cart() produces, so addon-injected
	// item_data (service extras, custom fields, etc.) survives and the resume controller can rebuild
	// cart items with OsCartsHelper::create_cart_item_from_item_data() unchanged.
	private static function serialize_cart_items( OsCartModel $cart, OsCustomerModel $customer ): string {
		$cart_items_data = [];
		foreach ( $cart->get_items() as $cart_item ) {
			$item_data                = json_decode( $cart_item->item_data, true );
			$item_data['customer_id'] = $customer->id;

			$cart_items_data[] = [
				'variant'         => $cart_item->variant,
				'item_data'       => $item_data,
				'subtotal'        => $cart_item->get_subtotal(),
				'total'           => $cart_item->get_total(),
				'coupon_discount' => $cart_item->get_coupon_discount(),
				'coupon_code'     => $cart_item->get_coupon_code(),
				'tax_total'       => $cart_item->get_tax_total(),
			];
		}

		return wp_json_encode( $cart_items_data );
	}

	public static function get_abandonment_by_key( string $abandonment_key ): OsCartAbandonmentModel {
		$abandonment = new OsCartAbandonmentModel();

		return $abandonment->where( [ 'abandonment_key' => $abandonment_key ] )->set_limit( 1 )->get_results_as_models() ?: $abandonment;
	}

	public static function generate_continue_abandonment_url( string $abandonment_key ): string {
		return OsRouterHelper::build_admin_post_link(
			[ 'cart_abandonments', 'continue_cart_abandonment' ],
			[ 'abandonment_key' => $abandonment_key ]
		);
	}

	// Flags the row rather than deleting any still-scheduled job - should_run_job() is what actually
	// blocks the send, same lazy philosophy as the enable/disable toggle.
	public static function mark_abandonment_converted( OsOrderIntentModel $order_intent ): void {
		$carts = ( new OsCartModel() )->where( [ 'order_intent_id' => $order_intent->id ] )->get_results_as_models();
		if ( empty( $carts ) ) {
			return;
		}

		$cart_ids     = array_column( $carts, 'id' );
		$abandonments = ( new OsCartAbandonmentModel() )->where_in( 'cart_id', $cart_ids )->get_results_as_models();
		foreach ( $abandonments as $abandonment ) {
			$abandonment->update_attributes(
				[
					'status'   => 'converted',
					'order_id' => $order_intent->order_id,
				]
			);
		}
	}

	public static function set_object_model_type_for_process( ?string $object_model_type, OsProcessModel $process, array $objects ): ?string {
		if ( self::EVENT_TYPE === $process->event_type ) {
			$object_model_type = 'cart_abandonment';
		}

		return $object_model_type;
	}

	public static function set_event_time_utc_for_process( ?OsWpDateTime $event_time_utc, OsProcessModel $process, array $objects ): ?OsWpDateTime {
		if ( self::EVENT_TYPE !== $process->event_type ) {
			return $event_time_utc;
		}

		try {
			$abandonment    = $objects[0]['model_ready'] ?? new OsCartAbandonmentModel( $objects[0]['id'] );
			$event_time_utc = new OsWpDateTime( $abandonment->created_at, new DateTimeZone( 'UTC' ) );
		} catch ( Exception $e ) {
			OsDebugHelper::log( 'Error creating event time for cart_abandoned process', 'process_jobs_error', $e->getMessage() );
		}

		return $event_time_utc;
	}

	// Deliberately does NOT populate $vars['order'] - an abandoned cart has no order yet, and
	// OsReplacerHelper::replace_order_vars() assumes every order item is a booking and fatals
	// otherwise (same caution OsEventsHooksHelper follows for event_registration templates).
	public static function prepare_replacement_vars( array $vars, array $data_objects, array $other_vars ): array {
		foreach ( $data_objects as $data_object ) {
			if ( 'cart_abandonment' !== $data_object['model'] ) {
				continue;
			}
			$abandonment         = $data_object['model_ready'] ?? new OsCartAbandonmentModel( $data_object['id'] );
			$vars['abandonment'] = $abandonment;
			if ( empty( $vars['customer'] ) ) {
				$vars['customer'] = $abandonment->get_customer();
			}
		}

		return $vars;
	}

	public static function replace_vars_in_template( string $text, array $vars, string $original_text ): string {
		if ( empty( $vars['abandonment'] ) ) {
			return $text;
		}

		$abandonment  = $vars['abandonment'];
		$needles      = [
			'{{cart_abandoned_continue_url}}',
			'{{cart_abandoned_total}}',
		];
		$replacements = [
			esc_url( self::generate_continue_abandonment_url( $abandonment->abandonment_key ) ),
			OsMoneyHelper::format_price( $abandonment->total, true, false ),
		];

		return str_replace( $needles, $replacements, $text );
	}

	public static function output_available_vars(): void {
		?>
		<div class="available-vars-block">
			<h4><?php esc_html_e( 'Cart Abandonment', 'latepoint-pro-features' ); ?></h4>
			<ul>
				<li><span class="var-label"><?php esc_html_e( 'Continue Booking URL', 'latepoint-pro-features' ); ?></span> <span class="var-code os-click-to-copy">{{cart_abandoned_continue_url}}</span></li>
				<li><span class="var-label"><?php esc_html_e( 'Cart Total', 'latepoint-pro-features' ); ?></span> <span class="var-code os-click-to-copy">{{cart_abandoned_total}}</span></li>
			</ul>
		</div>
		<?php
	}

	public static function add_cart_abandonment_templates( array $templates, string $action_type, $wp_filesystem ): array {
		if ( 'send_email' !== $action_type ) {
			return $templates;
		}

		$templates[] = [
			'id'           => 'cart_abandoned__to_customer',
			'to_user_type' => 'customer',
			'name'         => __( 'Cart Abandonment Reminder', 'latepoint-pro-features' ),
			'to_email'     => '{{customer_full_name}} <{{customer_email}}>',
			'subject'      => __( 'Did you forget something?', 'latepoint-pro-features' ),
			'content'      => OsEmailHelper::get_email_layout( $wp_filesystem->get_contents( LATEPOINT_ADDON_PRO_VIEWS_ABSPATH . 'mailers/customer/cart_abandoned.html' ) ),
		];

		return $templates;
	}
}
