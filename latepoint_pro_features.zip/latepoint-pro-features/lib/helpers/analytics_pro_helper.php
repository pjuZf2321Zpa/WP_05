<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class OsAnalyticsProHelper {

	/**
	 * Initialize BSF Analytics for Pro plugin.
	 *
	 * @return void
	 */
	public static function init() {
		add_filter( 'bsf_core_stats', [ __CLASS__, 'add_latepoint_pro_analytics_data' ], 11 );
		add_action( 'latepoint_settings_updated', [ __CLASS__, 'on_event_features_toggled' ] );
		add_action( 'latepoint_settings_updated', [ __CLASS__, 'on_cart_abandonment_toggled' ] );
		add_action( 'latepoint_coupon_created', [ __CLASS__, 'on_first_coupon_created' ] );
	}

	/**
	 * Track pro license activation event.
	 *
	 * @return void
	 */
	public static function on_license_activated() {
		if ( is_callable( [ 'OsAnalyticsHelper', 'events' ] ) ) {
			OsAnalyticsHelper::events()->track( 'pro_license_activated', LATEPOINT_ADDON_PRO_VERSION );
		}
	}

	/**
	 * Capture current state of the Events add-ons (E-Tickets, Ticket Types) on settings save.
	 *
	 * @param array<mixed> $settings Settings array.
	 * @return void
	 */
	public static function on_event_features_toggled( $settings ) {
		if ( ! is_array( $settings ) || ! is_callable( [ 'OsAnalyticsHelper', 'events' ] ) ) {
			return;
		}

		if ( class_exists( 'OsFeatureEventTicketsHelper' ) && OsFeatureEventTicketsHelper::is_enabled() ) {
			OsAnalyticsHelper::events()->track( 'event_etickets_enabled', LATEPOINT_ADDON_PRO_VERSION, [], true );
		}

		if ( class_exists( 'OsFeatureEventTicketTypesHelper' ) && OsFeatureEventTicketTypesHelper::is_enabled() ) {
			OsAnalyticsHelper::events()->track( 'event_ticket_types_enabled', LATEPOINT_ADDON_PRO_VERSION, [], true );
		}
	}

	/**
	 * Capture current state of the Cart Abandonment setting on settings save.
	 *
	 * @param array<mixed> $settings Settings array.
	 * @return void
	 */
	public static function on_cart_abandonment_toggled( $settings ) {
		if ( ! is_array( $settings ) || ! is_callable( [ 'OsAnalyticsHelper', 'events' ] ) ) {
			return;
		}

		if ( class_exists( 'OsFeatureCartAbandonmentHelper' ) && OsFeatureCartAbandonmentHelper::is_enabled() ) {
			OsAnalyticsHelper::events()->track( 'cart_abandonment_enabled', LATEPOINT_ADDON_PRO_VERSION, [], true );
		}
	}

	/**
	 * Track first_coupon_created event. Called via latepoint_coupon_created hook.
	 *
	 * @param OsCouponModel $coupon The coupon that was just created.
	 * @return void
	 */
	public static function on_first_coupon_created( $coupon ) {
		if ( ! is_callable( [ 'OsAnalyticsHelper', 'events' ] ) || get_option( 'latepoint_first_coupon_created' ) ) {
			return;
		}
		update_option( 'latepoint_first_coupon_created', LATEPOINT_ADDON_PRO_VERSION, false );
		OsAnalyticsHelper::events()->track(
			'first_coupon_created',
			LATEPOINT_ADDON_PRO_VERSION,
			[ 'discount_type' => $coupon->discount_type ]
		);
	}

	/**
	 * Add LatePoint Pro specific analytics data.
	 *
	 * Merges pro data into the existing LatePoint stats payload at priority 11,
	 * after the free plugin has added its data at priority 10.
	 *
	 * @param array $stats_data Existing stats data.
	 * @return array
	 */
	public static function add_latepoint_pro_analytics_data( $stats_data ) {
		if ( empty( $stats_data['plugin_data']['latepoint'] ) || ! is_array( $stats_data['plugin_data']['latepoint'] ) ) {
			return $stats_data;
		}

		$latepoint = &$stats_data['plugin_data']['latepoint'];

		// Pro version.
		$latepoint['pro_version'] = LATEPOINT_ADDON_PRO_VERSION;

		if ( ! isset( $latepoint['numeric_values'] ) || ! is_array( $latepoint['numeric_values'] ) ) {
			$latepoint['numeric_values'] = [];
		}
		$latepoint['numeric_values']['total_event_tickets']      = self::get_table_count( LATEPOINT_TABLE_EVENT_TICKETS );
		$latepoint['numeric_values']['total_event_ticket_types'] = self::get_table_count( LATEPOINT_TABLE_EVENT_TICKET_TYPES );

		return $stats_data;
	}

	/**
	 * Get total row count from a table.
	 *
	 * @param string $table_name Full table name.
	 * @return int
	 */
	private static function get_table_count( $table_name ) {
		global $wpdb;
		$count = $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i', $table_name ) );
		return $count ? (int) $count : 0;
	}
}
