<?php
/*
 * Copyright (c) 2024 LatePoint LLC. All rights reserved.
 */

/**
 * Ticket Types — flexible, per-event ticket pricing (e.g. "General $20" / "VIP $50 (cap 50)").
 *
 * Distinct from the E-Ticket QR check-in feature (OsFeatureEventTicketsHelper): a Ticket Type is
 * a priced tier a customer can buy; an e-ticket is the QR-coded credential issued afterward. An
 * event with no ticket types keeps today's single-price/quantity behaviour untouched — every hook
 * below is a no-op unless the event actually has active types.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'OsFeatureEventTicketTypesHelper' ) ) :

	class OsFeatureEventTicketTypesHelper {

		public static function init_hooks() {
			// Settings
			add_action( 'latepoint_general_settings_section_events_after', [ __CLASS__, 'output_settings' ], 11 );

			// Admin: event form
			add_action( 'latepoint_event_form_after', [ __CLASS__, 'output_types_on_event_form' ] );
			add_filter( 'latepoint_event_edit_form_sticky_section_items', [ __CLASS__, 'add_price_ranges_sticky_nav_item' ] );
			add_action( 'latepoint_event_created', [ __CLASS__, 'save_types_in_event' ] );
			add_action( 'latepoint_event_saved', [ __CLASS__, 'save_types_in_event' ] );
			add_action( 'latepoint_event_deleted', [ __CLASS__, 'delete_types_for_event' ] );
			add_filter( 'latepoint_event_capacity_pricing_readonly', [ __CLASS__, 'is_capacity_pricing_readonly' ], 10, 2 );
			add_action( 'latepoint_event_capacity_pricing_after', [ __CLASS__, 'output_capacity_pricing_notice' ] );

			// Wizard: ticket selector, quantity/capacity overrides
			add_filter( 'latepoint_event_tickets_step_selector_html', [ __CLASS__, 'render_types_selector' ], 10, 2 );
			add_filter( 'latepoint_event_cart_item_data', [ __CLASS__, 'add_types_to_cart_item_data' ], 10, 3 );
			add_filter( 'latepoint_event_step_quantity', [ __CLASS__, 'resolve_quantity_from_types' ], 10, 3 );
			add_filter( 'latepoint_event_skip_capacity_check', [ __CLASS__, 'skip_event_capacity_check' ], 10, 3 );
			add_filter( 'latepoint_event_has_capacity_limit', [ __CLASS__, 'event_has_capacity_limit' ], 10, 2 );
			add_filter( 'latepoint_event_available_capacity', [ __CLASS__, 'event_available_capacity' ], 10, 2 );
			add_filter( 'latepoint_event_total_capacity', [ __CLASS__, 'event_total_capacity' ], 10, 2 );
			add_action( 'latepoint_process_step', [ __CLASS__, 'validate_types_step' ], 9, 3 );

			// Pricing — run after Free's own priority-10 handlers so a tiered breakdown wins.
			add_filter( 'latepoint_cart_item_full_amount_to_charge', [ __CLASS__, 'cart_item_amount' ], 11, 2 );
			add_filter( 'latepoint_cart_item_deposit_amount_to_charge', [ __CLASS__, 'cart_item_amount' ], 11, 2 );
			add_filter( 'latepoint_order_item_full_amount_to_charge', [ __CLASS__, 'order_item_amount' ], 11, 2 );

			// Persistence, once a registration exists — priority 5 so this runs before
			// OsFeatureEventTicketsHelper::issue_tickets_for_registration() (priority 10), which
			// reads these join rows to tag each issued QR ticket with its type.
			add_action( 'latepoint_event_registration_created', [ __CLASS__, 'save_types_for_registration' ], 5 );

			// Notification variable
			add_filter( 'latepoint_prepare_replacement_vars_from_data_objects', [ __CLASS__, 'prepare_replacement_vars' ], 10, 3 );
			add_filter( 'latepoint_replace_all_vars_in_template', [ __CLASS__, 'replace_vars_in_template' ], 10, 3 );
			add_action( 'latepoint_available_vars_event', [ __CLASS__, 'output_available_vars' ] );
		}

		// ─── Settings ───────────────────────────────────────────────────────────

		public static function is_enabled(): bool {
			return OsSettingsHelper::is_on( 'enable_event_ticket_types' );
		}

		/**
		 * Whether THIS event is actually using ticket types right now — the global setting is
		 * on, and the event's own "Enable Ticket Types" toggle is on. This is the authoritative
		 * check for every live wizard/checkout decision below; a saved row existing is not
		 * enough on its own, so switching the toggle off reliably reverts an event to flat
		 * price/capacity even if its rows are still saved (switching back on brings them back
		 * unchanged — this never touches row data).
		 */
		public static function is_enabled_for_event( OsEventModel $event ): bool {
			return self::is_enabled() && OsUtilHelper::is_on( $event->get_meta_by_key( 'use_ticket_types', 'off' ) );
		}

		/**
		 * Whether date-range price rules should actually affect pricing for this event right now —
		 * Ticket Types must be on for the event AND the event's own "Enable tickets price by date range"
		 * toggle must be on. A type can have rules saved while this is off (the admin form never
		 * deletes them, only hides the editor), so this is checked at resolution time
		 * (`OsEventTicketTypeModel::get_active_price_rule()`), not at save time.
		 */
		public static function is_price_range_pricing_enabled_for_event( OsEventModel $event ): bool {
			return self::is_enabled_for_event( $event ) && OsUtilHelper::is_on( $event->get_meta_by_key( 'use_ticket_type_price_ranges', 'off' ) );
		}

		public static function output_settings(): void {
			?>
			<div class="sub-section-row">
				<div class="sub-section-label">
					<h3><?php esc_html_e( 'Ticket Types', 'latepoint-pro-features' ); ?></h3>
				</div>
				<div class="sub-section-content">
					<?php
					echo OsFormHelper::toggler_field(
						'settings[enable_event_ticket_types]',
						__( 'Enable Ticket Types', 'latepoint-pro-features' ),
						self::is_enabled(),
						false,
						false,
						[ 'sub_label' => __( 'Let each event define multiple named, separately-priced ticket types (e.g. General / VIP), each with its own optional capacity, instead of one flat price.', 'latepoint-pro-features' ) ]
					);
					?>
				</div>
			</div>
			<?php
		}

		// ─── Data access ────────────────────────────────────────────────────────

		/**
		 * @return OsEventTicketTypeModel[] Active types for the event, in display order.
		 */
		public static function get_active_types_for_event( int $event_id ): array {
			if ( ! $event_id ) {
				return [];
			}
			$type = new OsEventTicketTypeModel();

			return $type->where(
				[
					'event_id' => $event_id,
					'status'   => LATEPOINT_EVENT_TICKET_TYPE_STATUS_ACTIVE,
				]
			)->order_by( 'order_number asc' )->get_results_as_models();
		}

		/**
		 * @return OsEventTicketTypeModel[] All types for the event (any status), for the admin form.
		 */
		public static function get_types_for_event( int $event_id ): array {
			if ( ! $event_id ) {
				return [];
			}
			$type = new OsEventTicketTypeModel();

			return $type->where( [ 'event_id' => $event_id ] )->order_by( 'order_number asc' )->get_results_as_models();
		}

		/**
		 * Reads the submitted `event_ticket_types[<type_id>]` quantity map, clamped to active types
		 * for this event only (a stale/tampered type id from another event is simply ignored).
		 *
		 * @return array<int,int> type_id => quantity (zeroes omitted)
		 */
		private static function get_submitted_quantities( OsEventModel $event, array $params ): array {
			$submitted = is_array( $params['event_ticket_types'] ?? null ) ? $params['event_ticket_types'] : [];
			if ( empty( $submitted ) ) {
				return [];
			}

			$quantities = [];
			foreach ( self::get_active_types_for_event( $event->id ) as $type ) {
				$qty = max( 0, absint( $submitted[ $type->id ] ?? 0 ) );
				if ( $qty > 0 ) {
					$quantities[ $type->id ] = $qty;
				}
			}

			return $quantities;
		}

		/**
		 * The breakdown already saved on the current active cart item for this event, if any.
		 *
		 * `process_event_step()` (Free) runs on both the info step and the tickets step, and the
		 * info step never submits `event_ticket_types` at all — without this, re-submitting the
		 * info step (e.g. via back-navigation, then Next again) would wipe a selection the customer
		 * already made on the tickets step, since a fresh, empty breakdown would otherwise be
		 * written on every non-tickets-step submission.
		 *
		 * Deliberately re-loads the cart item fresh from the DB by id rather than reading
		 * OsStepsHelper::$active_cart_item directly — OsStepsHelper::set_active_cart_item_object()
		 * (steps_helper.php) unconditionally overwrites that object's item_data with a generic
		 * booking-shaped payload (from the base wizard's own hidden form fields) before any
		 * step-specific processing runs, so by the time this is called it no longer reflects
		 * what's actually persisted for this event registration — only its `id` can be trusted.
		 *
		 * @return array<int,array{name:string,price:float,quantity:int}>
		 */
		public static function get_existing_breakdown_for_event( OsEventModel $event ): array {
			$active_id = OsStepsHelper::$active_cart_item->id ?? 0;
			if ( ! $active_id ) {
				return [];
			}
			$cart_item = new OsCartItemModel( $active_id );
			if ( $cart_item->is_new_record() || $cart_item->variant !== LATEPOINT_ITEM_VARIANT_EVENT_REGISTRATION ) {
				return [];
			}
			$existing_data = OsEventsManagerHelper::decode_item_data( $cart_item->item_data );
			if ( (int) $existing_data['event_id'] !== (int) $event->id ) {
				return [];
			}

			return is_array( $existing_data['ticket_types'] ?? null ) ? $existing_data['ticket_types'] : [];
		}

		// ─── Admin: event form ──────────────────────────────────────────────────

		/**
		 * Renders the "Ticket Types" section on the event form — a disabled-feature notice when
		 * enable_event_ticket_types is off, or the real per-event editor when on.
		 */
		public static function output_types_on_event_form( OsEventModel $event ): void {
			if ( ! self::is_enabled() ) {
				?>
				<div class="white-box section-anchor" id="stickySectionTicketTypes">
					<div class="white-box-header">
						<div class="os-form-sub-header"><h3><?php esc_html_e( 'Ticket Types', 'latepoint-pro-features' ); ?></h3></div>
					</div>
					<div class="white-box-content">
						<div class="latepoint-message latepoint-message-subtle">
							<?php
							echo wp_kses(
								sprintf(
									/* translators: %1$s and %2$s are opening and closing anchor tags */
									__( 'Ticket Types are currently disabled. You can enable them in %1$sGeneral Settings%2$s.', 'latepoint-pro-features' ),
									'<a href="' . esc_url( admin_url( 'admin.php?page=latepoint&route_name=settings__general#stickySectionEvents' ) ) . '">',
									'</a>'
								),
								[ 'a' => [ 'href' => [] ] ]
							);
							?>
						</div>
					</div>
				</div>
				<?php
				return;
			}

			// Only active types are editable here — a type that was disabled because it had already
			// been purchased (see save_types_in_event()) stays out of this list; its history lives
			// on in the registrations/orders that already reference it.
			$types                              = $event->is_new_record() ? [] : self::get_active_types_for_event( $event->id );
			$use_ticket_types_is_on             = OsUtilHelper::is_on( $event->get_meta_by_key( 'use_ticket_types', 'off' ) );
			$use_ticket_type_price_ranges_is_on = OsUtilHelper::is_on( $event->get_meta_by_key( 'use_ticket_type_price_ranges', 'off' ) );
			include LATEPOINT_ADDON_PRO_VIEWS_ABSPATH . 'event_ticket_types/_event_form_section.php';
			include LATEPOINT_ADDON_PRO_VIEWS_ABSPATH . 'event_ticket_types/_price_ranges_section.php';
		}

		/**
		 * Adds the "Tickets price by date range" section's own side-nav entry via Free's extension
		 * point (events_manager/_form.php), spliced in right after Ticket Types' own entry so the
		 * nav order matches the actual section order on the page — the filter receives the full,
		 * already-ordered list, not just an append slot.
		 *
		 * @param array $items Existing ['href' => string, 'label' => string] entries, in order.
		 * @return array
		 */
		public static function add_price_ranges_sticky_nav_item( array $items ): array {
			if ( ! self::is_enabled() ) {
				return $items;
			}

			$price_ranges_item = [
				'href'  => 'stickySectionPriceRanges',
				'label' => __( 'Tickets price by date range', 'latepoint-pro-features' ),
			];

			foreach ( $items as $index => $item ) {
				if ( 'stickySectionTicketTypes' === ( $item['href'] ?? '' ) ) {
					array_splice( $items, $index + 1, 0, [ $price_ranges_item ] );

					return $items;
				}
			}

			// Ticket Types' own nav item wasn't found (e.g. removed by another filter) — still
			// show ours rather than silently dropping it.
			$items[] = $price_ranges_item;

			return $items;
		}

		/**
		 * Cleans up ticket types (and their registration snapshot rows) once the event they
		 * belong to is gone — latepoint_event_deleted otherwise leaves them orphaned, along with
		 * any still-live public ticket URLs that reference them.
		 */
		public static function delete_types_for_event( OsEventModel $event ): void {
			$types = self::get_types_for_event( $event->id );
			if ( ! $types ) {
				return;
			}

			$join  = new OsEventRegistrationTicketTypeModel();
			$rules = new OsEventTicketTypePriceRuleModel();
			foreach ( $types as $type ) {
				$join->delete_where( [ 'ticket_type_id' => $type->id ] );
				$rules->delete_where( [ 'ticket_type_id' => $type->id ] );
			}

			( new OsEventTicketTypeModel() )->delete_where( [ 'event_id' => $event->id ] );
		}

		/**
		 * 3-way diff against the submitted `event[ticket_types][]` rows: updates rows with a
		 * matching id, creates rows without one, and for anything not resubmitted — hard-deletes it
		 * if never purchased, otherwise disables it so history (past orders/registrations, which
		 * store their own name/price snapshot) is never rewritten.
		 *
		 * Reads raw params via OsParamsHelper rather than a hook argument — latepoint_event_created /
		 * latepoint_event_saved only pass the saved $event, not the submitted params (unlike the
		 * Service form's equivalent hook).
		 */
		public static function save_types_in_event( OsEventModel $event ): void {
			if ( ! self::is_enabled() || ! $event->id ) {
				return;
			}

			$event_params = OsParamsHelper::get_param( 'event' );
			if ( ! is_array( $event_params ) ) {
				return;
			}

			// Saved independently of whether any rows are submitted below — an admin can turn this
			// on before adding a single ticket type yet, and the toggle (not row presence) is what
			// every live wizard/checkout check treats as authoritative (see is_enabled_for_event()).
			$event->save_meta_by_key( 'use_ticket_types', ( isset( $event_params['use_ticket_types'] ) && OsUtilHelper::is_on( $event_params['use_ticket_types'] ) ) ? 'on' : 'off' );
			$event->save_meta_by_key( 'use_ticket_type_price_ranges', ( isset( $event_params['use_ticket_type_price_ranges'] ) && OsUtilHelper::is_on( $event_params['use_ticket_type_price_ranges'] ) ) ? 'on' : 'off' );

			if ( ! isset( $event_params['ticket_types'] ) || ! is_array( $event_params['ticket_types'] ) ) {
				return;
			}

			$existing = self::get_types_for_event( $event->id );

			$kept_ids = [];
			$order    = 0;
			foreach ( $event_params['ticket_types'] as $row ) {
				$name = sanitize_text_field( $row['name'] ?? '' );
				if ( $name === '' ) {
					continue; // blank template/unfilled row
				}

				$row_id = ! empty( $row['id'] ) ? absint( $row['id'] ) : 0;
				$type   = new OsEventTicketTypeModel( $row_id );
				// Guard against a submitted id that belongs to a different event.
				if ( $type->id && (int) $type->event_id !== (int) $event->id ) {
					$type = new OsEventTicketTypeModel();
				}

				$type->set_data(
					[
						'event_id'     => $event->id,
						'name'         => $name,
						'price'        => $row['price'] ?? 0,
						'capacity'     => max( 0, absint( $row['capacity'] ?? 0 ) ),
						'order_number' => $order++,
						'status'       => LATEPOINT_EVENT_TICKET_TYPE_STATUS_ACTIVE,
					]
				);
				$type->save();

				self::sync_price_rules_for_type( $type, is_array( $row['price_rules'] ?? null ) ? $row['price_rules'] : [] );

				$kept_ids[] = $type->id;
			}

			foreach ( $existing as $type ) {
				if ( in_array( $type->id, $kept_ids, true ) ) {
					continue;
				}
				if ( $type->get_booked_quantity() > 0 ) {
					$type->update_attributes( [ 'status' => LATEPOINT_EVENT_TICKET_TYPE_STATUS_DISABLED ] );
				} else {
					( new OsEventTicketTypePriceRuleModel() )->delete_where( [ 'ticket_type_id' => $type->id ] );
					$type->delete();
				}
			}
		}

		/**
		 * 3-way diff against the submitted `event[ticket_types][<i>][price_rules][]` rows for one
		 * ticket type, same shape as save_types_in_event() above. Both bounds are required for a
		 * price range (see _price_rule_row.php) — a row missing either one, or with an invalid
		 * window (end not after start), is skipped rather than saved, the same way a blank price is.
		 */
		private static function sync_price_rules_for_type( OsEventTicketTypeModel $type, array $rows ): void {
			$existing = $type->get_price_rules();

			$kept_ids = [];
			$order    = 0;
			foreach ( $rows as $row ) {
				if ( ! is_array( $row ) || '' === ( $row['price'] ?? '' ) ) {
					continue; // blank template/unfilled row
				}

				$row = self::combine_price_rule_datetime_params( $row );

				if ( '' === $row['start_datetime_utc'] || '' === $row['end_datetime_utc'] ) {
					continue; // both a start and an end are required for a price range
				}

				if ( strtotime( $row['end_datetime_utc'] ) <= strtotime( $row['start_datetime_utc'] ) ) {
					continue; // end must be after start
				}

				$row_id = ! empty( $row['id'] ) ? absint( $row['id'] ) : 0;
				$rule   = new OsEventTicketTypePriceRuleModel( $row_id );
				// Guard against a submitted id that belongs to a different ticket type.
				if ( $rule->id && (int) $rule->ticket_type_id !== (int) $type->id ) {
					$rule = new OsEventTicketTypePriceRuleModel();
				}

				$rule->set_data(
					[
						'ticket_type_id'     => $type->id,
						'price'              => $row['price'],
						'start_datetime_utc' => $row['start_datetime_utc'],
						'end_datetime_utc'   => $row['end_datetime_utc'],
						'order_number'       => $order++,
					]
				);
				$rule->save();

				$kept_ids[] = $rule->id;
			}

			foreach ( $existing as $rule ) {
				if ( ! in_array( $rule->id, $kept_ids, true ) ) {
					$rule->delete();
				}
			}
		}

		/**
		 * Merge split date/time picker fields into the combined *_utc columns
		 * OsEventTicketTypePriceRuleModel expects. No "custom date & time" toggle here (unlike
		 * Free's own combine_registration_datetime_params() for the event's registration window) —
		 * a price range's bounds are always on, so the date is trusted whenever it's present.
		 *
		 * @param array $rule_params Raw `price_rules[<j>]` params for one rule.
		 * @return array Params with start_datetime_utc / end_datetime_utc ready for set_data().
		 */
		private static function combine_price_rule_datetime_params( array $rule_params ): array {
			$map = [
				'start_datetime_utc' => [ 'start_date', 'start_time' ],
				'end_datetime_utc'   => [ 'end_date', 'end_time' ],
			];

			foreach ( $map as $target => $parts ) {
				list( $date_key, $time_key ) = $parts;

				$date = isset( $rule_params[ $date_key ] ) ? sanitize_text_field( $rule_params[ $date_key ] ) : '';

				if ( '' === $date ) {
					$rule_params[ $target ] = '';
				} else {
					$time_data = ( isset( $rule_params[ $time_key ] ) && is_array( $rule_params[ $time_key ] ) )
						? $rule_params[ $time_key ]
						: [];
					$formatted = isset( $time_data['formatted_value'] ) ? $time_data['formatted_value'] : '';
					$ampm      = isset( $time_data['ampm'] ) ? $time_data['ampm'] : false;
					$minutes   = OsTimeHelper::convert_time_to_minutes( $formatted, $ampm );

					$rule_params[ $target ] = OsEventsManagerHelper::utc_datetime_from_local( $date, $minutes );
				}

				unset( $rule_params[ $date_key ], $rule_params[ $time_key ] );
			}

			return $rule_params;
		}

		public static function is_capacity_pricing_readonly( bool $readonly, OsEventModel $event ): bool {
			return $readonly || self::is_enabled_for_event( $event );
		}

		public static function output_capacity_pricing_notice( OsEventModel $event ): void {
			// Rendered (hidden if off) rather than skipped entirely, so the admin JS toggling the
			// "Enable Ticket Types" checkbox can show/hide it instantly without a page reload.
			$is_on = self::is_enabled_for_event( $event );
			?>
			<div id="osEventCapacityPricingNotice" class="latepoint-message latepoint-message-subtle"<?php echo $is_on ? '' : ' style="display:none;"'; ?>>
				<?php esc_html_e( 'The total capacity and ticket price are now overridden by Ticket Types. Set the price and capacity for each ticket type in the Ticket Types section below.', 'latepoint-pro-features' ); ?>
			</div>
			<?php
		}

		// ─── Wizard: ticket selector ────────────────────────────────────────────

		public static function render_types_selector( string $html, OsEventModel $event ): string {
			if ( ! self::is_enabled_for_event( $event ) ) {
				return $html;
			}
			$types = self::get_active_types_for_event( $event->id );
			if ( empty( $types ) ) {
				return $html;
			}

			ob_start();
			include LATEPOINT_ADDON_PRO_VIEWS_ABSPATH . 'event_ticket_types/_step_selector.php';

			return (string) ob_get_clean();
		}

		/**
		 * Always writes the `ticket_types` key once the event has active types configured — even
		 * as an empty array when nothing is selected yet — so downstream code (Free's cart summary,
		 * the amount calculator below) can tell "this event uses per-type selection, 0 is a real
		 * state" apart from "flat event, default to 1" via array_key_exists() alone.
		 */
		public static function add_types_to_cart_item_data( array $item_data, OsEventModel $event, array $params ): array {
			if ( ! self::is_enabled_for_event( $event ) ) {
				return $item_data;
			}
			$active_types = self::get_active_types_for_event( $event->id );
			if ( empty( $active_types ) ) {
				return $item_data; // toggle on, but no rows configured yet — behave like a flat event
			}

			if ( ! array_key_exists( 'event_ticket_types', $params ) ) {
				// Not a tickets-step submission (e.g. the info step re-submits on every Next click,
				// including back-navigation) — preserve whatever was already selected instead of
				// wiping it back to empty.
				$item_data['ticket_types'] = self::get_existing_breakdown_for_event( $event );

				return $item_data;
			}

			$quantities = self::get_submitted_quantities( $event, $params );
			$breakdown  = [];
			foreach ( $active_types as $type ) {
				if ( empty( $quantities[ $type->id ] ) ) {
					continue;
				}
				$breakdown[ $type->id ] = [
					'name'     => $type->name,
					'price'    => $type->get_effective_price(),
					'quantity' => $quantities[ $type->id ],
				];
			}

			$item_data['ticket_types'] = $breakdown;

			return $item_data;
		}

		/**
		 * Gated on whether the event HAS active types, not on whether the customer has picked
		 * anything yet — 0 is a valid, real quantity while nothing is selected (see
		 * add_types_to_cart_item_data() above); only an event with no types configured falls back
		 * to Free's flat default.
		 */
		public static function resolve_quantity_from_types( int $quantity, OsEventModel $event, array $params ): int {
			if ( ! self::is_enabled_for_event( $event ) ) {
				return $quantity;
			}
			if ( empty( self::get_active_types_for_event( $event->id ) ) ) {
				return $quantity;
			}

			if ( ! array_key_exists( 'event_ticket_types', $params ) ) {
				// See add_types_to_cart_item_data() — preserve the existing total on a non-tickets-
				// step submission instead of resetting it to 0.
				$existing = self::get_existing_breakdown_for_event( $event );

				return array_sum( array_column( $existing, 'quantity' ) );
			}

			return array_sum( self::get_submitted_quantities( $event, $params ) );
		}

		public static function skip_event_capacity_check( bool $skip, OsEventModel $event, array $params ): bool {
			if ( ! self::is_enabled_for_event( $event ) ) {
				return $skip;
			}

			// Types in play: validate_types_step() below does the (per-type) capacity check instead.
			return empty( self::get_active_types_for_event( $event->id ) ) ? $skip : true;
		}

		/**
		 * The event's own `capacity` column is stale/irrelevant once Ticket Types is on — each
		 * type has its own (or no) cap. Any uncapped active type means a customer can always get
		 * some ticket, so the event as a whole is effectively unlimited; only report a limit when
		 * every active type has one.
		 */
		public static function event_has_capacity_limit( bool $has_limit, OsEventModel $event ): bool {
			if ( ! self::is_enabled_for_event( $event ) ) {
				return $has_limit;
			}
			$types = self::get_active_types_for_event( $event->id );
			if ( empty( $types ) ) {
				return $has_limit;
			}
			foreach ( $types as $type ) {
				if ( ! $type->capacity ) {
					return false;
				}
			}

			return true;
		}

		/**
		 * Sum of remaining capacity across all active types — only meaningful once
		 * event_has_capacity_limit() above confirms every active type has a cap.
		 */
		public static function event_available_capacity( int $available, OsEventModel $event ): int {
			if ( ! self::is_enabled_for_event( $event ) ) {
				return $available;
			}
			$types = self::get_active_types_for_event( $event->id );
			if ( empty( $types ) ) {
				return $available;
			}
			foreach ( $types as $type ) {
				if ( ! $type->capacity ) {
					return PHP_INT_MAX;
				}
			}
			$total = 0;
			foreach ( $types as $type ) {
				$total += $type->get_available_capacity();
			}

			return $total;
		}

		/**
		 * Sum of total capacity across all active types — only meaningful once
		 * event_has_capacity_limit() above confirms every active type has a cap.
		 */
		public static function event_total_capacity( int $total, OsEventModel $event ): int {
			if ( ! self::is_enabled_for_event( $event ) ) {
				return $total;
			}
			$types = self::get_active_types_for_event( $event->id );
			if ( empty( $types ) ) {
				return $total;
			}
			$sum = 0;
			foreach ( $types as $type ) {
				if ( ! $type->capacity ) {
					return 0;
				}
				$sum += (int) $type->capacity;
			}

			return $sum;
		}

		/**
		 * Runs before Free's own process_event_step() (priority 10) so a per-type capacity problem
		 * is caught before Free's aggregate check would otherwise be skipped entirely.
		 */
		public static function validate_types_step( string $step_code, OsBookingModel $booking, array $params ): void {
			if ( ! self::is_enabled() ) {
				return;
			}

			// Any step after Tickets: the customer's selection is already made, so just make sure
			// the snapshotted prices are still correct — a date-range rule's window can open or
			// close while they idle on a later step (e.g. payment).
			if ( $step_code !== OsEventsHooksHelper::$tickets_step_code ) {
				self::revalidate_cart_item_prices( $step_code );

				return;
			}

			$event_id = (int) ( OsStepsHelper::$presets['selected_event_id'] ?? 0 );
			$event    = $event_id ? new OsEventModel( $event_id ) : null;
			if ( ! $event || ! $event->id || ! self::is_enabled_for_event( $event ) ) {
				return;
			}

			$types = self::get_active_types_for_event( $event->id );
			if ( empty( $types ) ) {
				return;
			}

			$quantities = self::get_submitted_quantities( $event, $params );

			if ( empty( $quantities ) ) {
				wp_send_json(
					[
						'status'       => LATEPOINT_STATUS_ERROR,
						'message'      => __( 'Please select at least one ticket.', 'latepoint-pro-features' ),
						'send_to_step' => $step_code,
					]
				);
			}

			// Per-type capacity below only checks each row's own cap — a type with no cap of its
			// own (unlimited) would otherwise let the combined selection exceed the event's overall
			// capacity, since skip_event_capacity_check() suppresses Free's own aggregate check
			// whenever types are in play.
			$total_quantity = array_sum( $quantities );
			if ( $event->capacity && $event->get_available_capacity() < $total_quantity ) {
				wp_send_json(
					[
						'status'       => LATEPOINT_STATUS_ERROR,
						// translators: %d: available capacity.
						'message'      => sprintf( __( 'Only %d spot(s) available for this event.', 'latepoint-pro-features' ), $event->get_available_capacity() ),
						'send_to_step' => $step_code,
					]
				);
			}

			foreach ( $types as $type ) {
				$qty = $quantities[ $type->id ] ?? 0;
				if ( $qty > 0 && $type->capacity && $type->get_available_capacity() < $qty ) {
					wp_send_json(
						[
							'status'       => LATEPOINT_STATUS_ERROR,
							// translators: %1$d: available capacity, %2$s: ticket type name.
							'message'      => sprintf( __( 'Only %1$d spot(s) available for %2$s.', 'latepoint-pro-features' ), $type->get_available_capacity(), $type->name ),
							'send_to_step' => $step_code,
						]
					);
				}
			}
		}

		/**
		 * Re-resolves each selected type's price fresh and refreshes the active cart item's
		 * snapshot if a date-range rule's window opened or closed since the customer selected
		 * tickets — e.g. they idled on a later step past a sale's cutoff. The customer is sent
		 * back to the Tickets step with a clear message rather than silently charged the stale
		 * amount: `calculate_amount_from_item_data()` below trusts this snapshot completely, it
		 * never re-reads the live ticket type.
		 */
		private static function revalidate_cart_item_prices( string $step_code ): void {
			$cart_item_id = OsStepsHelper::$active_cart_item->id ?? 0;
			if ( ! $cart_item_id ) {
				return;
			}
			$cart_item = new OsCartItemModel( $cart_item_id );
			if ( $cart_item->is_new_record() || $cart_item->variant !== LATEPOINT_ITEM_VARIANT_EVENT_REGISTRATION ) {
				return;
			}

			$item_data = OsEventsManagerHelper::decode_item_data( $cart_item->item_data );
			$breakdown = is_array( $item_data['ticket_types'] ?? null ) ? $item_data['ticket_types'] : [];
			if ( empty( $breakdown ) ) {
				return;
			}

			$changed = false;
			foreach ( $breakdown as $type_id => &$row ) {
				$type = new OsEventTicketTypeModel( (int) $type_id );
				if ( ! $type->id ) {
					continue;
				}
				$current_price = $type->get_effective_price();
				if ( abs( $current_price - (float) ( $row['price'] ?? 0 ) ) > 0.0001 ) {
					$row['price'] = $current_price;
					$changed      = true;
				}
			}
			unset( $row );

			if ( ! $changed ) {
				return;
			}

			$item_data['ticket_types'] = $breakdown;
			$cart_item->update_attributes( [ 'item_data' => wp_json_encode( $item_data ) ] );

			wp_send_json(
				[
					'status'       => LATEPOINT_STATUS_ERROR,
					'message'      => __( 'Ticket pricing has changed since you selected your tickets. Please review your updated total before continuing.', 'latepoint-pro-features' ),
					'send_to_step' => OsEventsHooksHelper::$tickets_step_code,
				]
			);
		}

		// ─── Pricing ────────────────────────────────────────────────────────────

		/**
		 * Shared by both cart-item filters (full amount + deposit — events never have a separate
		 * deposit, same as Free's own handler) since the calculation is identical either way.
		 */
		public static function cart_item_amount( float $amount, OsCartItemModel $item ) {
			return self::calculate_amount_from_item_data( $amount, $item->variant, $item->item_data );
		}

		public static function order_item_amount( float $amount, OsOrderItemModel $item ) {
			return self::calculate_amount_from_item_data( $amount, $item->variant, $item->item_data );
		}

		private static function calculate_amount_from_item_data( float $amount, string $variant, string $item_data ) {
			if ( ! self::is_enabled() || $variant !== LATEPOINT_ITEM_VARIANT_EVENT_REGISTRATION ) {
				return $amount;
			}
			$data = OsEventsManagerHelper::decode_item_data( $item_data );
			if ( ! array_key_exists( 'ticket_types', $data ) ) {
				return $amount; // this event isn't using ticket types at all — leave Free's flat price
			}

			$total = 0.0;
			foreach ( (array) $data['ticket_types'] as $row ) {
				$total += (float) ( $row['price'] ?? 0 ) * max( 0, (int) ( $row['quantity'] ?? 0 ) );
			}

			return $total; // 0.0 is correct when nothing is picked yet
		}

		/**
		 * @return array<int,array{name:string,price:float,quantity:int}>
		 */
		public static function get_ticket_types_breakdown( string $item_data ): array {
			$data = OsEventsManagerHelper::decode_item_data( $item_data );

			return is_array( $data['ticket_types'] ?? null ) ? $data['ticket_types'] : [];
		}

		// ─── Persistence: registration ──────────────────────────────────────────

		public static function save_types_for_registration( OsEventRegistrationModel $reg ): void {
			if ( ! self::is_enabled() || ! $reg->order_item_id ) {
				return;
			}
			$order_item = new OsOrderItemModel( $reg->order_item_id );
			if ( ! $order_item->id ) {
				return;
			}

			$breakdown = self::get_ticket_types_breakdown( $order_item->item_data );
			foreach ( $breakdown as $type_id => $row ) {
				$qty = max( 0, (int) ( $row['quantity'] ?? 0 ) );
				if ( $qty < 1 ) {
					continue;
				}
				$join = new OsEventRegistrationTicketTypeModel();
				$join->set_data(
					[
						'registration_id' => $reg->id,
						'ticket_type_id'  => (int) $type_id,
						'name'            => $row['name'] ?? '',
						'quantity'        => $qty,
						'price'           => $row['price'] ?? 0,
					]
				);
				$join->save();
			}
		}

		/**
		 * @return OsEventRegistrationTicketTypeModel[]
		 */
		public static function get_types_for_registration( int $registration_id ): array {
			if ( ! $registration_id ) {
				return [];
			}
			$join = new OsEventRegistrationTicketTypeModel();

			return $join->where( [ 'registration_id' => $registration_id ] )->order_by( 'id asc' )->get_results_as_models();
		}

		// ─── Notification variable: {{event_ticket_types}} ─────────────────────

		/**
		 * $data_objects entries are shaped like ['model' => 'event_registration', 'id' => ...,
		 * 'model_ready' => OsEventRegistrationModel|null] — same convention
		 * OsFeatureEventTicketsHelper::prepare_replacement_vars() reads, kept independent of it
		 * (own $vars key, own detection) so this works whether or not e-tickets are enabled.
		 */
		public static function prepare_replacement_vars( array $vars, array $data_objects, array $other_vars ): array {
			foreach ( $data_objects as $data_object ) {
				if ( ( $data_object['model'] ?? '' ) !== 'event_registration' ) {
					continue;
				}
				$reg                        = $data_object['model_ready'] ?? new OsEventRegistrationModel( $data_object['id'] );
				$vars['event_ticket_types'] = self::get_formatted_breakdown_for_registration( $reg );
				break;
			}

			return $vars;
		}

		public static function replace_vars_in_template( string $text, array $vars, string $original_text ): string {
			if ( isset( $vars['event_ticket_types'] ) ) {
				$text = str_replace( '{{event_ticket_types}}', $vars['event_ticket_types'], $text );
			}

			return $text;
		}

		private static function get_formatted_breakdown_for_registration( OsEventRegistrationModel $reg ): string {
			$rows = self::get_types_for_registration( $reg->id );
			if ( empty( $rows ) ) {
				return '';
			}
			$lines = [];
			foreach ( $rows as $row ) {
				$lines[] = sprintf(
					'%1$s × %2$d — %3$s',
					$row->name,
					$row->quantity,
					$row->get_formatted_line_total()
				);
			}

			return implode( ', ', $lines );
		}

		public static function output_available_vars(): void {
			?>
			<li><span class="var-label"><?php esc_html_e( 'Ticket Types Breakdown', 'latepoint-pro-features' ); ?></span> <span class="var-code os-click-to-copy">{{event_ticket_types}}</span></li>
			<?php
		}
	}

endif;
