<?php 

class OsMessagesHelper {

	// Archived state of a chat. Holds the last message id at the time of archiving, not a boolean, so
	// a newer message automatically makes the conversation active again.
	const ARCHIVED_META_KEY = 'chat_archived_until_message_id';

	// Newest message id of a booking, for use inside a bookings query.
	public static function last_message_id_sql(): string {
		return '(SELECT MAX(' . LATEPOINT_TABLE_MESSAGES . '.id) FROM ' . LATEPOINT_TABLE_MESSAGES . ' WHERE ' . LATEPOINT_TABLE_MESSAGES . '.booking_id = ' . LATEPOINT_TABLE_BOOKINGS . '.id)';
	}

	// Watermark minus newest message id: negative is active, 0 or more is archived. An offset to
	// compare against 0, because the query builder strips comparison operators out of condition keys.
	public static function archived_offset_sql(): string {
		return 'COALESCE((SELECT ' . LATEPOINT_TABLE_BOOKING_META . '.meta_value FROM ' . LATEPOINT_TABLE_BOOKING_META . ' WHERE ' . LATEPOINT_TABLE_BOOKING_META . '.object_id = ' . LATEPOINT_TABLE_BOOKINGS . '.id AND ' . LATEPOINT_TABLE_BOOKING_META . ".meta_key = '" . self::ARCHIVED_META_KEY . "' LIMIT 1), 0) - " . self::last_message_id_sql();
	}

	public static function count_new_messages_for_customer( $customer_id ) {
		$unread_count  = 0;
		$booking_model = new OsBookingModel();
		$booking_ids   = $booking_model->select( 'id' )->where( [ 'customer_id' => $customer_id ] )->get_results();
		if ( $booking_ids ) {
			$booking_ids_arr = array_map(
				function ( $b ) {
					return $b->id;
				},
				$booking_ids 
			);
			if ( empty( $booking_ids_arr ) ) {
				return 0;
			}
			$message_model = new OsMessageModel();
			$unread_count  = $message_model->where(
				[
					'booking_id'      => $booking_ids_arr,
					'is_read'         => false,
					'author_type != ' => 'customer',
				] 
			)->count();
		} else {
			$booking_ids = false;
		}
		return $unread_count;
	}

	public static function count_new_messages_for_logged_in_backend_user() {
		$message_model = new OsMessageModel();
		$unread_count  = $message_model->filter_allowed_records()->where(
			[
				'is_read'     => false,
				'author_type' => 'customer',
			] 
		)->count();
		return $unread_count;
	}

	public static function set_messages_as_read( $booking_id ) {
		$messages = new OsMessageModel();
		global $wpdb;
		$wpdb->query( $wpdb->prepare( 'UPDATE ' . $messages->table_name . ' SET is_read = true WHERE is_read != true AND booking_id = %d', $booking_id ) );
	}

	public static function get_messages_for_booking_id( $booking_id ) {
		$message_model = new OsMessageModel();
		$messages      = $message_model->where( [ 'booking_id' => $booking_id ] )->order_by( 'created_at asc' )->get_results_as_models();
		return $messages;
	}

	public static function get_message_attachment_link( $message_id ) {
		return OsRouterHelper::build_admin_post_link( [ 'messages', 'view_attachment' ], [ 'message_id' => $message_id ] );
	}

	// Conversations sidebar list, bulk loaded so the query count does not grow with the row count.
	public static function get_conversations_list( $for_customer = false, $archived = false ) {
		$conversations = [];
		$message_model = new OsMessageModel();

		if ( $for_customer ) {
			$customer_id = OsAuthHelper::get_logged_in_customer_id();
			if ( ! $customer_id ) {
				return $conversations;
			}
			$message_model->join( LATEPOINT_TABLE_BOOKINGS, [ 'id' => LATEPOINT_TABLE_MESSAGES . '.booking_id' ] )->where( [ LATEPOINT_TABLE_BOOKINGS . '.customer_id' => $customer_id ] );
		} else {
			$message_model->filter_allowed_records();
		}

		// filter_allowed_records adds bookings columns that are not in the GROUP BY.
		$rows = $message_model->clear_select()
			->select( LATEPOINT_TABLE_MESSAGES . '.booking_id' )
			->select( 'MAX(' . LATEPOINT_TABLE_MESSAGES . '.id) as last_message_id' )
			->group_by( LATEPOINT_TABLE_MESSAGES . '.booking_id' )
			->order_by( 'last_message_id desc' )
			->get_results();

		if ( empty( $rows ) ) {
			return $conversations;
		}

		$last_message_ids_by_booking = [];
		foreach ( $rows as $row ) {
			$last_message_ids_by_booking[ intval( $row->booking_id ) ] = intval( $row->last_message_id );
		}

		// A conversation is archived only while the watermark still covers its newest message.
		$watermarks = self::get_archived_watermarks( array_keys( $last_message_ids_by_booking ) );
		foreach ( $last_message_ids_by_booking as $booking_id => $last_message_id ) {
			$is_archived = isset( $watermarks[ $booking_id ] ) && $watermarks[ $booking_id ] >= $last_message_id;
			if ( $is_archived != $archived ) {
				unset( $last_message_ids_by_booking[ $booking_id ] );
			}
		}

		if ( empty( $last_message_ids_by_booking ) ) {
			return $conversations;
		}

		$last_messages       = ( new OsMessageModel() )->where( [ 'id' => array_values( $last_message_ids_by_booking ) ] )->get_results_as_models();
		$messages_by_booking = [];
		foreach ( $last_messages as $last_message ) {
			$messages_by_booking[ intval( $last_message->booking_id ) ] = $last_message;
		}

		$bookings_by_id = self::load_bookings_with_customers( array_keys( $last_message_ids_by_booking ) );

		$unread = [];
		$read   = [];
		// $last_message_ids_by_booking is already ordered newest conversation first.
		foreach ( $last_message_ids_by_booking as $booking_id => $last_message_id ) {
			if ( ! isset( $bookings_by_id[ $booking_id ] ) || ! isset( $messages_by_booking[ $booking_id ] ) ) {
				continue;
			}
			$last_message = $messages_by_booking[ $booking_id ];
			if ( $for_customer ) {
				$is_read = ! ( ! $last_message->is_read && $last_message->author_type != 'customer' );
			} else {
				$is_read = ! ( ! $last_message->is_read && $last_message->author_type == 'customer' );
			}
			$conversation = [
				'booking'      => $bookings_by_id[ $booking_id ],
				'last_message' => $last_message,
				'is_read'      => $is_read,
				'is_archived'  => $archived,
			];
			if ( $is_read ) {
				$read[] = $conversation;
			} else {
				$unread[] = $conversation;
			}
		}

		// Unread first, each group still newest first.
		return array_merge( $unread, $read );
	}

	// Bookings keyed by id, customer attached so rendering a row does not run get_customer() per row.
	private static function load_bookings_with_customers( array $booking_ids ): array {
		$bookings_by_id = [];
		$customer_ids   = [];

		$bookings = ( new OsBookingModel() )->where( [ 'id' => $booking_ids ] )->get_results_as_models();
		foreach ( $bookings as $booking ) {
			$bookings_by_id[ intval( $booking->id ) ] = $booking;
			if ( $booking->customer_id ) {
				$customer_ids[] = $booking->customer_id;
			}
		}

		if ( empty( $customer_ids ) ) {
			return $bookings_by_id;
		}

		$customers       = ( new OsCustomerModel() )->where( [ 'id' => array_unique( $customer_ids ) ] )->get_results_as_models();
		$customers_by_id = [];
		foreach ( $customers as $customer ) {
			$customers_by_id[ intval( $customer->id ) ] = $customer;
		}
		foreach ( $bookings_by_id as $booking ) {
			if ( isset( $customers_by_id[ intval( $booking->customer_id ) ] ) ) {
				$booking->customer = $customers_by_id[ intval( $booking->customer_id ) ];
			}
		}

		return $bookings_by_id;
	}

	// Watermarks keyed by booking id, prefetched in one query instead of reading meta in a loop.
	private static function get_archived_watermarks( array $booking_ids ): array {
		$watermarks  = [];
		$booking_ids = array_filter( array_map( 'absint', $booking_ids ) );
		if ( empty( $booking_ids ) ) {
			return $watermarks;
		}

		$rows = ( new OsBookingMetaModel() )->select( 'object_id, meta_value' )->where(
			[
				'meta_key'  => self::ARCHIVED_META_KEY,
				'object_id' => $booking_ids,
			]
		)->get_results();

		if ( $rows ) {
			foreach ( $rows as $row ) {
				$watermarks[ intval( $row->object_id ) ] = intval( $row->meta_value );
			}
		}

		return $watermarks;
	}

	// Newest message id of a booking, 0 when nothing has been exchanged yet.
	private static function get_last_message_id_for_booking( $booking_id ): int {
		$booking_id = absint( $booking_id );
		if ( ! $booking_id ) {
			return 0;
		}
		$row = ( new OsMessageModel() )->select( 'MAX(id) as last_message_id' )->where( [ 'booking_id' => $booking_id ] )->set_limit( 1 )->get_results();

		return ( $row && ! empty( $row->last_message_id ) ) ? intval( $row->last_message_id ) : 0;
	}

	// Archives or restores a conversation. Only hides it - booking and messages are untouched.
	public static function set_conversation_archived( $booking_id, $archived ): bool {
		$booking_id = absint( $booking_id );
		if ( ! $booking_id ) {
			return false;
		}

		if ( ! $archived ) {
			OsMetaHelper::delete_booking_meta( self::ARCHIVED_META_KEY, $booking_id );
			return true;
		}

		$last_message_id = self::get_last_message_id_for_booking( $booking_id );
		if ( ! $last_message_id ) {
			// Nothing exchanged yet - there is no conversation to archive.
			return false;
		}
		OsMetaHelper::save_booking_meta_by_key( self::ARCHIVED_META_KEY, $last_message_id, $booking_id );

		return true;
	}

	// Deletes every message of a conversation. The booking and any media in the library are left
	// alone - media can be referenced outside this conversation.
	public static function delete_conversation( $booking_id ): bool {
		$booking_id = absint( $booking_id );
		if ( ! $booking_id ) {
			return false;
		}

		$message_model = new OsMessageModel();
		$deleted       = $message_model->delete_where( [ 'booking_id' => $booking_id ] );

		// Drop the watermark too, so a future conversation on this booking does not start archived.
		OsMetaHelper::delete_booking_meta( self::ARCHIVED_META_KEY, $booking_id );

		return (bool) $deleted;
	}

	public static function count_unread_messages_for_booking( $booking_id, $for_author_type ) {
		$message_model     = new OsMessageModel();
		$author_type_query = ( $for_author_type == 'customer' ) ? [ 'author_type !=' => 'customer' ] : [ 'author_type' => 'customer' ];
		$unread_count      = $message_model->where( $author_type_query )->where(
			[
				'is_read'    => 0,
				'booking_id' => $booking_id,
			] 
		)->count();
		return $unread_count;
	}


	public static function send_message_notification_to_customer( $message_model ) {
		$booking  = $message_model->booking;
		$agent    = $booking->agent;
		$customer = $booking->customer;
		$order    = $booking->get_order();

		$to = $customer->email;
	
		$subject = self::email_notification_customer_has_new_message_subject();
		$content = self::email_notification_customer_has_new_message_content();

		$subject = OsReplacerHelper::replace_all_vars(
			$subject,
			array(
				'customer' => $customer,
				'agent'    => $agent,
				'booking'  => $booking,
				'order'    => $order,
			) 
		);
		$content = OsReplacerHelper::replace_all_vars(
			$content,
			array(
				'customer' => $customer,
				'agent'    => $agent,
				'booking'  => $booking,
				'order'    => $order,
			) 
		);

		if ( $message_model->content_type == LATEPOINT_MESSAGE_CONTENT_TYPE_ATTACHMENT ) {
			$content = $content = str_replace( '{{message_content}}', __( 'File Attachment', 'latepoint-pro-features' ), $content );
		} else {
			$content = str_replace( '{{message_content}}', $message_model->content, $content );
		}
		$mailer = new OsMailer();

		wp_mail( $to, $subject, $content, $mailer->get_headers() );
	}

	public static function send_message_notification_to_agent( $message_model ) {
		$booking  = $message_model->booking;
		$agent    = $booking->agent;
		$customer = $booking->customer;

		$order = $booking->get_order();

		$to = $agent->email;
		if ( ! empty( $agent->extra_emails ) ) {
			$to .= ', ' . $agent->extra_emails;
		}

		$subject = self::email_notification_agent_has_new_message_subject();
		$content = self::email_notification_agent_has_new_message_content();

		$subject = OsReplacerHelper::replace_all_vars(
			$subject,
			array(
				'customer' => $customer,
				'agent'    => $agent,
				'booking'  => $booking,
				'order'    => $order,
			) 
		);
		$content = OsReplacerHelper::replace_all_vars(
			$content,
			array(
				'customer' => $customer,
				'agent'    => $agent,
				'booking'  => $booking,
				'order'    => $order,
			) 
		);

		if ( $message_model->content_type == LATEPOINT_MESSAGE_CONTENT_TYPE_ATTACHMENT ) {
			$content = $content = str_replace( '{{message_content}}', __( 'File Attachment', 'latepoint-pro-features' ), $content );
		} else {
			$content = str_replace( '{{message_content}}', $message_model->content, $content );
		}

		$mailer = new OsMailer();
		wp_mail( $to, $subject, $content, $mailer->get_headers() );
	}

	public static function email_notification_customer_has_new_message_subject() {
		$default = __( 'You have a new message', 'latepoint-pro-features' );
		return OsSettingsHelper::get_settings_value( 'email_notification_customer_has_new_message_subject', $default );
	}

	public static function email_notification_agent_has_new_message_subject() {
		$default = __( 'You have a new message', 'latepoint-pro-features' );
		return OsSettingsHelper::get_settings_value( 'email_notification_agent_has_new_message_subject', $default );
	}

	public static function email_notification_customer_has_new_message_content() {
		$default = 'You have a new message from {{agent_full_name}} for {{service_name}} on {{start_date}}. Message says: <div style="padding-left:20px;margin:20px 0px;border-left:2px solid #ccc;color:#888">{{message_content}}</div>';
		$content = OsSettingsHelper::get_settings_value( 'email_notification_customer_has_new_message_content', $default );
		return $content;
	}

	public static function email_notification_agent_has_new_message_content() {
		$default = 'You have a new message from {{customer_full_name}} for {{service_name}} on {{start_date}}. Message says: <div style="padding-left:20px;margin:20px 0px;border-left:2px solid #ccc;color:#888">{{message_content}}</div>';
		$content = OsSettingsHelper::get_settings_value( 'email_notification_agent_has_new_message_content', $default );
		return $content;
	}
}
