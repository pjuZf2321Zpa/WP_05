<?php
/*
 * Copyright (c) 2024 LatePoint LLC. All rights reserved.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'OsFeatureEventWaitingListHelper' ) ) :

	/**
	 * Events, Waiting List.
	 *
	 * A queue entry lives in its own table and is NOT an event registration, so a queued person is
	 * never counted as a seat, exported as an attendee or issued a ticket. Nobody is promoted
	 * automatically: the organizer invites somebody when a place frees up.
	 */
	class OsFeatureEventWaitingListHelper {

		/** Per-event meta keys. */
		const META_ENABLED  = 'waiting_list_enabled';
		const META_CAPACITY = 'waiting_list_capacity';

		/**
		 * How many may queue for each ticket type, as a JSON map keyed by type id.
		 *
		 * Kept here rather than as a column on the ticket types table: the queue is this feature's
		 * concern, and a Ticket Types event that never switches the waiting list on should not carry
		 * a column for it.
		 */
		const META_CAPACITY_BY_TYPE = 'waiting_list_capacity_by_type';

		/**
		 * The step that asks which ticket the customer wants to wait for.
		 *
		 * Sits exactly where Free's own tickets step sits, so joining a queue walks the same
		 * event -> ticket -> customer order as buying does. Only shown when Ticket Types is
		 * driving the event; a flat event has nothing to choose between.
		 */
		const TICKET_STEP_CODE = 'event_waiting_list_tickets';

		/**
		 * Field that step posts under, as [ ticket_type_id => places ]. Deliberately the name Ticket
		 * Types' own selector uses, so its pricing and core's summary reload work here untouched.
		 */
		const TICKETS_FIELD = 'event_ticket_types';

		/** The wizard step that creates the queue entry. */
		const STEP_CODE = 'event_waiting_list';

		/**
		 * The step shown once they are in the queue. Exists so that STEP_CODE is not the last
		 * step: core strips the footer, the progress bar and the side panel from whichever step
		 * reports is_last_step (main.js:1874-1879), which is right for a confirmation screen but
		 * makes a mid-flow step look like a different dialog. This mirrors how core's own
		 * booking flow ends on a dedicated `confirmation` step.
		 */
		const CONFIRM_STEP_CODE = 'event_waiting_list_done';

		/** Preset that puts the wizard into waiting list mode. */
		const INTENT_PRESET = 'waiting_list_intent';

		/** Preset carrying the ticket type a Join button was clicked for, or the step chose. */
		const TICKET_TYPE_PRESET = 'waiting_list_ticket_type_id';

		/** Query parameter carrying an invitation token. */
		const CLAIM_PARAM = 'latepoint_event_wl';

		/**
		 * How long an invitation stays claimable. registration_closes_at() clamps it to the event.
		 */
		const INVITE_TTL = 2 * DAY_IN_SECONDS;

		/** Set for the duration of a request that arrived holding a valid invitation. */
		private static $claimed_entry_id = 0;

		/** Loaded entries by id: the capacity hold asks for one per ticket type per render. */
		private static $claimed_entries = [];

		/**
		 * Customer whose paid order is being registered right now, or 0. A redirect or webhook gateway
		 * carries neither the token nor the presets, so the buyer is identified from the order itself.
		 */
		private static $registering_customer_id = 0;

		/** Why a claim link on this request was refused, for the message shown to the customer. */
		private static $claim_error = '';

		/** Whether the query string has already been searched for an invitation token. */
		private static $claim_lookup_done = false;

		/** Per-request memos, keyed by event id. */
		private static $settings_cache          = [];
		private static $queue_cache             = [];
		private static $quantity_cache          = [];
		private static $types_cache             = [];
		private static $uses_ticket_types_cache = [];
		private static $event_cache             = [];

		/** The entry created during this request, handed to the confirmation step. */
		private static $created_entry = null;

		/** Plaintext invitation tokens, alive only for the request that minted them. */
		private static $plaintext_tokens = [];

		/** True once every event's live queue count has been loaded in a single pass. */
		private static $queue_cache_primed = false;

		/** Free seats, memoised for the request, keyed "{event_id}:{ticket_type_id}". */
		private static $seats_cache = [];

		/**
		 * Set while the queue asks a tier what it really has left, so it does not read back its own
		 * hold and conclude there is nothing to give.
		 */
		private static $reading_raw_capacity = false;

		// ─── Bootstrap ──────────────────────────────────────────────────────────

		public static function init_hooks() {
			// An event being deleted takes its queue with it.
			add_action( 'latepoint_event_deleted', [ __CLASS__, 'delete_queue_for_event' ] );

			// Renders in both states: switching off must not remove the control that switches it back on.
			add_action( 'latepoint_general_settings_section_events_after', [ __CLASS__, 'output_settings' ], 20 );

			// Unconditional: init_hooks() runs before settings save, so a gated hook would miss the first enable.
			add_action( 'latepoint_settings_updated', [ __CLASS__, 'maybe_seed_default_workflows' ] );

			// Renders in both states: Free drops its own section as soon as Pro is installed, but its
			// sticky nav still links to this anchor, so switching off would leave that link dead.
			add_action( 'latepoint_event_form_after', [ __CLASS__, 'output_waiting_list_on_event_form' ] );

			if ( ! self::is_enabled() ) {
				return;
			}

			add_action( 'latepoint_event_created', [ __CLASS__, 'save_waiting_list_in_event' ] );
			add_action( 'latepoint_event_saved', [ __CLASS__, 'save_waiting_list_in_event' ] );

			// Admin: its own screen under Events, and its own capability.
			add_filter( 'latepoint_side_menu', [ __CLASS__, 'add_admin_menu_item' ], 20, 2 );
			add_filter( 'latepoint_capabilities_for_controllers', [ __CLASS__, 'add_capabilities' ] );

			// A queue keeps the event closed so a freed place is reserved for the people waiting.
			add_filter( 'latepoint_event_is_sold_out', [ __CLASS__, 'keep_event_full_while_queue_waits' ], 10, 2 );
			add_filter( 'latepoint_event_ticket_type_available_capacity', [ __CLASS__, 'hold_tier_seats_for_queue' ], 10, 2 );

			// Both of that step's gates are about taking a place now, which is not what queuing does.
			add_filter( 'latepoint_event_skip_registration_open_check', [ __CLASS__, 'skip_step_gate_in_waiting_list_mode' ], 10, 3 );
			add_filter( 'latepoint_event_skip_capacity_check', [ __CLASS__, 'skip_step_gate_in_waiting_list_mode' ], 10, 3 );
			add_filter( 'latepoint_event_tickets_step_max_qty', [ __CLASS__, 'bound_quantity_by_queue_capacity' ], 10, 2 );
			// After Ticket Types (10), which resolves the quantity from its own selector.
			add_filter( 'latepoint_event_step_quantity', [ __CLASS__, 'default_quantity_when_tickets_step_skipped' ], 20, 3 );
			add_filter( 'latepoint_can_checkout_multiple_items', [ __CLASS__, 'hide_checkout_in_waiting_list_mode' ], 20 );

			// Front end: offer the queue instead of a dead end, and say how busy it already is.
			add_filter( 'latepoint_event_sold_out_action_html', [ __CLASS__, 'render_join_action' ], 10, 3 );
			add_filter( 'latepoint_event_full_label_html', [ __CLASS__, 'append_queue_count_to_full_label' ], 10, 2 );
			add_action( 'latepoint_event_register_action_after', [ __CLASS__, 'output_tier_join_actions' ] );

			// Wizard: joining is a real step, so core's customer step handles identity.
			add_filter( 'latepoint_get_step_codes_with_rules', [ __CLASS__, 'add_step' ] );
			add_filter( 'latepoint_step_show_next_btn_rules', [ __CLASS__, 'add_step_next_btn_rules' ] );
			add_filter( 'latepoint_settings_for_step_codes', [ __CLASS__, 'add_step_settings' ] );
			add_filter( 'latepoint_step_labels_by_step_codes', [ __CLASS__, 'add_step_label' ] );
			add_filter( 'latepoint_should_step_be_skipped', [ __CLASS__, 'should_step_be_skipped' ], 20, 5 );
			add_action( 'latepoint_load_step', [ __CLASS__, 'load_step' ], 10, 3 );
			add_action( 'latepoint_process_step', [ __CLASS__, 'process_step' ], 10, 3 );
			add_filter( 'latepoint_steps_for_select', [ __CLASS__, 'remove_step_from_select' ] );
			add_filter( 'latepoint_step_codes_for_order_modal', [ __CLASS__, 'remove_step_from_order_modal' ] );

			// Claiming an invitation.
			add_filter( 'latepoint_localized_vars_front', [ __CLASS__, 'localize_front_vars' ] );
			add_filter( 'latepoint_get_default_presets', [ __CLASS__, 'add_default_presets' ] );
			add_filter( 'latepoint_set_presets', [ __CLASS__, 'capture_claim_token' ], 20, 2 );
			add_action( 'latepoint_booking_form_params_presets_after', [ __CLASS__, 'render_claim_preset_field' ] );
			add_action( 'latepoint_booking_form_params_presets_after', [ __CLASS__, 'render_intent_preset_field' ] );
			add_action( 'latepoint_booking_form_params_presets_after', [ __CLASS__, 'render_ticket_type_preset_field' ] );

			// The place was taken. Runs for every gateway, including redirect and webhook ones,
			// because it is keyed off the registration itself rather than request state.
			add_action( 'latepoint_event_registration_created', [ __CLASS__, 'convert_entry_for_registration' ], 20 );

			// Brackets core's priority-10 registration pass, so the hold cannot refuse the buyer it is held for.
			add_action( 'latepoint_order_created', [ __CLASS__, 'begin_registering_order' ], 5 );
			add_action( 'latepoint_order_created', [ __CLASS__, 'finish_registering_order' ], 20 );

			// Notifications
			add_filter( 'latepoint_process_event_types', [ __CLASS__, 'add_process_event_types' ] );
			add_filter( 'latepoint_process_event_names', [ __CLASS__, 'add_process_event_names' ] );
			add_filter( 'latepoint_get_object_model_type_for_process', [ __CLASS__, 'set_object_model_type_for_process' ], 10, 3 );
			add_filter( 'latepoint_get_event_time_utc_for_process', [ __CLASS__, 'set_event_time_utc_for_process' ], 10, 3 );
			add_filter( 'latepoint_prepare_replacement_vars_from_data_objects', [ __CLASS__, 'prepare_replacement_vars' ], 10, 2 );
			add_filter( 'latepoint_replace_all_vars_in_template', [ __CLASS__, 'replace_vars_in_template' ], 10, 3 );
			add_action( 'latepoint_available_vars_event', [ __CLASS__, 'output_available_vars' ] );
			add_filter( 'latepoint_load_templates_for_action_type', [ __CLASS__, 'add_templates' ], 10, 3 );
		}

		// ─── Settings ───────────────────────────────────────────────────────────

		public static function is_enabled(): bool {
			return OsSettingsHelper::is_on( 'enable_event_waiting_list' );
		}

		public static function is_enabled_for_event( OsEventModel $event ): bool {
			return self::is_enabled() && $event->id && self::get_event_settings( $event )['enabled'];
		}

		/**
		 * Both per-event settings in a single meta read, memoized per request. The events list
		 * calls is_sold_out() once per event, so an un-cached read here would be an N+1.
		 */
		private static function get_event_settings( OsEventModel $event ): array {
			$id = (int) $event->id;
			if ( ! $id ) {
				return [
					'enabled'          => false,
					'capacity'         => 0,
					'capacity_by_type' => [],
				];
			}
			if ( ! isset( self::$settings_cache[ $id ] ) ) {
				$meta                        = ( new OsEventMetaModel() )->get_by_object_id( $id, [] );
				self::$settings_cache[ $id ] = [
					'enabled'          => OsUtilHelper::is_on( $meta[ self::META_ENABLED ] ?? 'off' ),
					'capacity'         => absint( $meta[ self::META_CAPACITY ] ?? 0 ),
					'capacity_by_type' => self::decode_capacity_map( $meta[ self::META_CAPACITY_BY_TYPE ] ?? '' ),
				];
			}

			return self::$settings_cache[ $id ];
		}

		public static function get_capacity( OsEventModel $event, ?int $ticket_type_id = null ): int {
			if ( ! $event->id ) {
				return 0;
			}
			$settings = self::get_event_settings( $event );

			if ( null !== $ticket_type_id ) {
				return absint( $settings['capacity_by_type'][ $ticket_type_id ] ?? 0 );
			}

			// Asked about the event while ticket types own the queue: the total anyone may join is
			// the sum of the per-type allowances. 0 anywhere means unlimited, so the total is too.
			if ( self::ticket_types_for( $event ) ) {
				$total = 0;
				foreach ( self::ticket_types_for( $event ) as $type ) {
					$allowed = absint( $settings['capacity_by_type'][ (int) $type->id ] ?? 0 );
					if ( ! $allowed ) {
						return 0;
					}
					$total += $allowed;
				}

				return $total;
			}

			return $settings['capacity'];
		}

		/** The stored per-type allowances, as [ ticket_type_id => places ]. */
		private static function decode_capacity_map( string $raw ): array {
			$decoded = $raw ? json_decode( $raw, true ) : [];
			if ( ! is_array( $decoded ) ) {
				return [];
			}

			$map = [];
			foreach ( $decoded as $type_id => $places ) {
				$map[ absint( $type_id ) ] = absint( $places );
			}

			return $map;
		}

		public static function output_settings(): void {
			?>
			<div class="sub-section-row">
				<div class="sub-section-label">
					<h3><?php esc_html_e( 'Waiting List', 'latepoint-pro-features' ); ?></h3>
				</div>
				<div class="sub-section-content">
					<?php
					echo OsFormHelper::toggler_field(
						'settings[enable_event_waiting_list]',
						__( 'Enable Waiting List for Events', 'latepoint-pro-features' ),
						self::is_enabled(),
						false,
						false,
						[ 'sub_label' => __( 'Lets customers queue for a full event. You then invite them when a place frees up - nobody is given a place automatically.', 'latepoint-pro-features' ) ]
					);
					?>
				</div>
			</div>
			<?php
		}

		public static function output_waiting_list_on_event_form( OsEventModel $event ): void {
			$feature_is_enabled = self::is_enabled();
			$settings           = $feature_is_enabled ? self::get_event_settings( $event ) : [];
			$enabled            = (bool) ( $settings['enabled'] ?? false );
			$flat_capacity      = ( $settings['capacity'] ?? 0 ) ?: '';

			// Both capacity blocks render; the toggle swaps them without a save and each is stored separately.
			$types         = $feature_is_enabled ? self::editable_ticket_types_for( $event ) : [];
			$by_type_is_on = $feature_is_enabled && (bool) self::ticket_types_for( $event );

			$capacity_by_type = [];
			foreach ( $types as $type ) {
				$capacity_by_type[ (int) $type->id ] = self::get_capacity( $event, (int) $type->id ) ?: '';
			}
			$capacity_by_type_name = 'event[' . self::META_CAPACITY_BY_TYPE . ']';

			$show_unlimited_notice = $feature_is_enabled && ! $event->is_new_record() && ! $event->has_capacity_limit() && ! self::has_capped_ticket_type( $event );

			include LATEPOINT_ADDON_PRO_VIEWS_ABSPATH . 'event_waiting_list/_event_form_section.php';
		}

		/**
		 * Reads raw params via OsParamsHelper rather than a hook argument: latepoint_event_created /
		 * latepoint_event_saved only pass the saved $event, not the submitted params. Mirrors
		 * OsFeatureEventTicketTypesHelper::save_types_in_event().
		 */
		public static function save_waiting_list_in_event( OsEventModel $event ): void {
			if ( ! self::is_enabled() || ! $event->id ) {
				return;
			}

			$event_params = OsParamsHelper::get_param( 'event' );
			if ( ! is_array( $event_params ) ) {
				return;
			}

			$event->save_meta_by_key(
				self::META_ENABLED,
				( isset( $event_params[ self::META_ENABLED ] ) && OsUtilHelper::is_on( $event_params[ self::META_ENABLED ] ) ) ? 'on' : 'off'
			);
			$event->save_meta_by_key( self::META_CAPACITY, absint( $event_params[ self::META_CAPACITY ] ?? 0 ) );

			// Ticket Types saves first, so deleted types drop out. Kept for every active type so toggling off and on keeps the values.
			$submitted = $event_params[ self::META_CAPACITY_BY_TYPE ] ?? [];
			if ( is_array( $submitted ) ) {
				$map = [];
				foreach ( self::editable_ticket_types_for( $event ) as $type ) {
					$map[ (int) $type->id ] = absint( $submitted[ $type->id ] ?? 0 );
				}
				$event->save_meta_by_key( self::META_CAPACITY_BY_TYPE, wp_json_encode( $map ) );
			}

			self::flush_cache( (int) $event->id );
		}

		// ─── Admin surface ──────────────────────────────────────────────────────

		/**
		 * Adds "Waiting List" as the last item under Events. The menu is defined once per role, so
		 * every Events entry has to be handled, not just the first.
		 */
		public static function add_admin_menu_item( array $menus, $user_role ): array {
			foreach ( $menus as &$menu ) {
				if ( ! is_array( $menu ) || ( $menu['id'] ?? '' ) !== 'events' || empty( $menu['children'] ) || ! is_array( $menu['children'] ) ) {
					continue;
				}
				foreach ( $menu['children'] as $child ) {
					if ( 'waiting_list' === ( $child['id'] ?? '' ) ) {
						continue 2;
					}
				}

				$menu['children'][] = [
					'id'    => 'waiting_list',
					'label' => __( 'Waiting List', 'latepoint-pro-features' ),
					'icon'  => '',
					'link'  => OsRouterHelper::build_link( [ 'event_waiting_list', 'index' ] ),
				];
			}
			unset( $menu );

			return $menus;
		}

		/**
		 * Managing a queue is managing who gets a place at an event, so it reuses the existing
		 * event-registration capability rather than inventing an object of its own. Without this
		 * the router falls through to its ['settings__edit'] default, which would stop an event
		 * manager who may cancel a registration from inviting anyone off the queue.
		 */
		public static function add_capabilities( array $capabilities ): array {
			// Same shape as core's OsEventRegistrationsController entry: view to read, edit to change who gets in.
			$capabilities['OsEventWaitingListController'] = [
				'default'    => [ 'event_registration__view' ],
				'per_action' => [
					'invite'  => [ 'event_registration__edit' ],
					'promote' => [ 'event_registration__edit' ],
					'remove'  => [ 'event_registration__edit' ],
				],
			];

			return $capabilities;
		}

		// ─── Queue reads ────────────────────────────────────────────────────────

		/**
		 * One event by id, loaded at most once per request.
		 *
		 * The hold runs once per ticket type per render, and only needs the event's id, so loading
		 * a fresh model there cost a query per queued tier on every events list.
		 */
		private static function event( int $event_id ): OsEventModel {
			if ( ! isset( self::$event_cache[ $event_id ] ) ) {
				self::$event_cache[ $event_id ] = new OsEventModel( $event_id );
			}

			return self::$event_cache[ $event_id ];
		}

		private static function flush_cache( int $event_id ): void {
			unset( self::$settings_cache[ $event_id ], self::$types_cache[ $event_id ], self::$event_cache[ $event_id ] );
			// Keyed "{event_id}:{ticket_type_id}", so one event owns several entries.
			foreach ( array_keys( self::$seats_cache ) as $key ) {
				if ( 0 === strpos( (string) $key, $event_id . ':' ) ) {
					unset( self::$seats_cache[ $key ] );
				}
			}
			// The counts are loaded for every event at once, so one write invalidates the batch.
			self::$queue_cache        = [];
			self::$quantity_cache     = [];
			self::$queue_cache_primed = false;
		}

		/**
		 * Number of live entries. A COUNT, not a hydrate, because this runs on the events list and on
		 * every template render.
		 */
		public static function get_queue_count( int $event_id, ?int $ticket_type_id = null ): int {
			if ( ! $event_id ) {
				return 0;
			}
			if ( ! self::$queue_cache_primed ) {
				self::prime_queue_counts();
			}

			// An event with nobody queuing has no row in the grouped result, hence the fallback.
			return self::$queue_cache[ $event_id ][ self::bucket( $ticket_type_id ) ] ?? 0;
		}

		/**
		 * Which slot of the primed maps answers a question: one ticket type, or the event as a whole.
		 * An entry with no type of its own lives in bucket 0.
		 *
		 * @return int|string
		 */
		private static function bucket( ?int $ticket_type_id ) {
			return null === $ticket_type_id ? 'all' : (int) $ticket_type_id;
		}

		/**
		 * Loads every event's live queue count in one grouped query.
		 *
		 * The events list asks for this once per full event on the page, so counting per event
		 * would be a query per card. A queue is bounded by its own capacity, so the whole live
		 * set is small - one grouped read of it costs less than two of the per-event counts.
		 */
		private static function prime_queue_counts(): void {
			global $wpdb;
			$statuses     = OsEventWaitingListModel::live_statuses();
			$placeholders = implode( ',', array_fill( 0, count( $statuses ), '%s' ) );
			// Grouped by tier so the hold needs no query of its own; joined to customers so a deleted customer stops holding a seat.
			$rows = $wpdb->get_results(
				$wpdb->prepare(
					'SELECT w.event_id, w.ticket_type_id, COUNT(*) AS total, COALESCE(SUM(w.quantity), 0) AS places' .
					' FROM ' . LATEPOINT_TABLE_EVENT_WAITING_LIST . ' w' .
					' INNER JOIN ' . LATEPOINT_TABLE_CUSTOMERS . ' c ON c.id = w.customer_id' .
					' WHERE w.status IN (' . $placeholders . ') GROUP BY w.event_id, w.ticket_type_id',
					$statuses
				),
				ARRAY_A
			);

			self::$queue_cache    = [];
			self::$quantity_cache = [];
			foreach ( (array) $rows as $row ) {
				$event_id = (int) $row['event_id'];
				$type_id  = (int) $row['ticket_type_id']; // NULL collapses to 0, the event-level bucket.
				$count    = (int) $row['total'];
				$places   = (int) $row['places'];

				// Both the per-tier figure and the event-wide roll-up, so either can be answered
				// without going back to the database.
				self::$queue_cache[ $event_id ][ $type_id ]    = $count;
				self::$quantity_cache[ $event_id ][ $type_id ] = $places;
				self::$queue_cache[ $event_id ]['all']         = ( self::$queue_cache[ $event_id ]['all'] ?? 0 ) + $count;
				self::$quantity_cache[ $event_id ]['all']      = ( self::$quantity_cache[ $event_id ]['all'] ?? 0 ) + $places;
			}
			self::$queue_cache_primed = true;
		}

		/**
		 * Total places being waited for. Distinct from get_queue_count(): one entry may be
		 * queuing for several places, and the waiting list capacity is measured in places.
		 */
		public static function get_queued_quantity( int $event_id, ?int $ticket_type_id = null ): int {
			if ( ! $event_id ) {
				return 0;
			}
			if ( ! self::$queue_cache_primed ) {
				self::prime_queue_counts();
			}

			return self::$quantity_cache[ $event_id ][ self::bucket( $ticket_type_id ) ] ?? 0;
		}

		/**
		 * Seats actually free on an event, or null when it has no capacity limit at all. Memoised:
		 * the queue table repeats the same event down the page. Calls core's own method rather than
		 * recounting, so "booked" has one definition.
		 */
		public static function get_available_seats( OsEventModel $event, ?int $ticket_type_id = null ): ?int {
			$id = (int) $event->id;
			if ( ! $id ) {
				return null;
			}
			$key = $id . ':' . (int) $ticket_type_id;
			if ( isset( self::$seats_cache[ $key ] ) ) {
				return self::$seats_cache[ $key ];
			}

			if ( null !== $ticket_type_id ) {
				$type = self::find_ticket_type( $event, $ticket_type_id );
				if ( ! $type || ! $type->capacity ) {
					return null; // no such type any more, or an uncapped one that cannot fill up
				}
				self::$seats_cache[ $key ] = max( 0, self::raw_tier_capacity( $type ) );

				return self::$seats_cache[ $key ];
			}

			// has_capacity_limit(), not the column: Ticket Types leaves the event's own capacity at 0.
			if ( ! $event->has_capacity_limit() ) {
				return null;
			}
			self::$seats_cache[ $key ] = max( 0, (int) self::raw_event_capacity( $event ) );

			return self::$seats_cache[ $key ];
		}

		/** One of the event's active ticket types by id, or null if it is gone. */
		private static function find_ticket_type( OsEventModel $event, int $ticket_type_id ): ?OsEventTicketTypeModel {
			foreach ( self::ticket_types_for( $event ) as $type ) {
				if ( (int) $type->id === $ticket_type_id ) {
					return $type;
				}
			}

			return null;
		}

		/**
		 * What a ticket type has left before the queue's own hold is applied.
		 *
		 * @see self::$reading_raw_capacity
		 */
		private static function raw_tier_capacity( OsEventTicketTypeModel $type ): int {
			$was                        = self::$reading_raw_capacity;
			self::$reading_raw_capacity = true;
			try {
				return (int) $type->get_available_capacity();
			} finally {
				self::$reading_raw_capacity = $was;
			}
		}

		/**
		 * What the event has left before the queue's own hold is applied. Ticket Types answers this
		 * by summing its types, so it reaches the hold filter too and needs the same guard.
		 */
		private static function raw_event_capacity( OsEventModel $event ): int {
			$was                        = self::$reading_raw_capacity;
			self::$reading_raw_capacity = true;
			try {
				return (int) $event->get_available_capacity();
			} finally {
				self::$reading_raw_capacity = $was;
			}
		}

		/**
		 * Places already spoken for by invitations that are still claimable, excluding one entry.
		 * get_available_capacity() cannot see them, so without this one freed seat could be offered to
		 * the whole queue at once. $ignore_entry_id is the entry being offered right now.
		 */
		public static function get_seats_held_by_invites( int $event_id, int $ignore_entry_id = 0, ?int $ticket_type_id = null ): int {
			if ( ! $event_id ) {
				return 0;
			}

			$conditions = [
				'event_id' => $event_id,
				'status'   => LATEPOINT_EVENT_WAITING_LIST_STATUS_INVITED,
			];
			// An invitation only holds a seat in the ticket type it was issued for. No condition
			// when none is named: the caller is then asking about the event as a whole.
			if ( null !== $ticket_type_id ) {
				$conditions['ticket_type_id'] = $ticket_type_id;
			}

			$invited = ( new OsEventWaitingListModel() )
				->where( $conditions )
				->get_results_as_models();
			if ( ! $invited ) {
				return 0;
			}

			$held = 0;
			foreach ( ( is_array( $invited ) ? $invited : [ $invited ] ) as $held_entry ) {
				if ( ! $held_entry || (int) $held_entry->id === $ignore_entry_id ) {
					continue;
				}
				// A lapsed row keeps the status `invited` until something touches it, and its
				// link is already dead, so it holds nothing.
				if ( $held_entry->has_live_invite() ) {
					$held += max( 1, (int) $held_entry->quantity );
				}
			}

			return $held;
		}

		/**
		 * Seats this entry could actually be given right now, or null when the event is uncapped.
		 *
		 * Free capacity minus the seats other live invitations are holding.
		 */
		public static function get_offerable_seats( OsEventWaitingListModel $entry, ?OsEventModel $event = null ): ?int {
			// The caller usually has the event already (the admin table batch-loads them) and
			// re-resolving it here would put a query back on every row.
			$event = $event ?? $entry->get_event();
			if ( ! $event || ! $event->id ) {
				return null;
			}
			// The entry's own tier, so a place freed in the front row is not offered to somebody
			// waiting for the back row.
			$tier = $entry->ticket_type_id ? (int) $entry->ticket_type_id : null;

			$free = self::get_available_seats( $event, $tier );
			if ( null === $free ) {
				return null;
			}

			return max( 0, $free - self::get_seats_held_by_invites( (int) $event->id, (int) $entry->id, $tier ) );
		}

		/**
		 * The invitation deadline in the site's own date and time format, or '' if there is none.
		 *
		 * Shown to the customer, so it is rendered in the site timezone rather than the UTC the
		 * column stores - a deadline quoted in the wrong timezone is worse than none.
		 */
		public static function get_formatted_invite_deadline( OsEventWaitingListModel $entry ): string {
			if ( empty( $entry->invite_expires_at ) ) {
				return '';
			}

			return OsTimeHelper::date_from_db(
				$entry->invite_expires_at,
				OsSettingsHelper::get_date_format() . ' ' . get_option( 'time_format', 'g:i a' ),
				OsTimeHelper::get_wp_timezone_name()
			);
		}

		/**
		 * When an invitation issued now should stop being claimable.
		 *
		 * INVITE_TTL, but never past the moment registration closes - an invitation that outlives
		 * its own event is a link that cannot work, and the deadline is quoted to the customer in
		 * the invitation email, so it has to be a time they could actually act on.
		 */
		private static function invite_expiry_stamp( OsEventModel $event ): int {
			$expires   = current_time( 'timestamp', true ) + self::INVITE_TTL;
			$closes_at = self::registration_closes_at( $event );

			return ( $closes_at && $closes_at < $expires ) ? $closes_at : $expires;
		}

		/**
		 * The reason an entry cannot be offered its place, or null when it can.
		 *
		 * Shared by the two write actions and the admin table so the refusal and the explanation
		 * shown next to the disabled button can never drift apart.
		 */
		public static function get_offer_block_reason( OsEventWaitingListModel $entry, ?OsEventModel $event = null ): ?string {
			$event = $event ?? $entry->get_event();
			if ( ! $event || ! $event->id ) {
				return __( 'Event not found.', 'latepoint-pro-features' );
			}

			if ( ! self::is_registration_window_open( $event ) ) {
				return __( 'Registration for this event has closed, so a place can no longer be given.', 'latepoint-pro-features' );
			}

			// A deleted tier leaves the seat maths nothing to measure, which would report unlimited.
			if ( $entry->ticket_type_id && ! $entry->get_ticket_type() ) {
				return __( 'The ticket type this customer was waiting for no longer exists. Remove this entry instead.', 'latepoint-pro-features' );
			}

			$offerable = self::get_offerable_seats( $entry, $event );
			if ( null === $offerable || $offerable >= (int) $entry->quantity ) {
				return null;
			}

			$wanted = max( 1, (int) $entry->quantity );
			// A Ticket Types event keeps its own capacity column at 0, so pointing the organizer
			// at "the event capacity" would name a field that does nothing.
			$by_ticket_type = ! $event->capacity && $event->has_capacity_limit();

			if ( $offerable < 1 ) {
				return $by_ticket_type
					/* translators: %d: number of places the customer is waiting for */
					? sprintf( _n( 'This event is full. Increase a ticket type capacity by at least %d place, then offer it again.', 'This event is full. Increase a ticket type capacity by at least %d places, then offer it again.', $wanted, 'latepoint-pro-features' ), $wanted )
					/* translators: %d: number of places the customer is waiting for */
					: sprintf( _n( 'This event is full. Increase the event capacity by at least %d place, then offer it again.', 'This event is full. Increase the event capacity by at least %d places, then offer it again.', $wanted, 'latepoint-pro-features' ), $wanted );
			}

			return sprintf(
				$by_ticket_type
					/* translators: 1: places free, 2: places the customer is waiting for */
					? _n( 'Only %1$d place free but this customer is waiting for %2$d. Increase a ticket type capacity, then offer it again.', 'Only %1$d places free but this customer is waiting for %2$d. Increase a ticket type capacity, then offer it again.', $offerable, 'latepoint-pro-features' )
					/* translators: 1: places free, 2: places the customer is waiting for */
					: _n( 'Only %1$d place free but this customer is waiting for %2$d. Increase the event capacity, then offer it again.', 'Only %1$d places free but this customer is waiting for %2$d. Increase the event capacity, then offer it again.', $offerable, 'latepoint-pro-features' ),
				$offerable,
				$wanted
			);
		}

		public static function has_queue( int $event_id ): bool {
			return self::get_queue_count( $event_id ) > 0;
		}

		/**
		 * The entry's place in the queue, counted as an ordinal over live entries. One definition,
		 * used by the step, the confirmation and the {{waiting_list_position}} tag alike, so the
		 * customer is never shown two different numbers. A COUNT rather than hydrating the queue.
		 */
		public static function get_position( OsEventWaitingListModel $entry ): int {
			if ( ! $entry->id || ! $entry->is_live() ) {
				return 0;
			}
			global $wpdb;
			$statuses     = OsEventWaitingListModel::live_statuses();
			$placeholders = implode( ',', array_fill( 0, count( $statuses ), '%s' ) );

			// Counted within this entry's own ticket type: being third overall means nothing when
			// the two ahead are waiting for a different ticket that will never free this one.
			$tier_sql    = $entry->ticket_type_id ? ' AND ticket_type_id = %d' : ' AND ticket_type_id IS NULL';
			$tier_values = $entry->ticket_type_id ? [ (int) $entry->ticket_type_id ] : [];

			$ahead = (int) $wpdb->get_var(
				$wpdb->prepare(
					'SELECT COUNT(*) FROM ' . LATEPOINT_TABLE_EVENT_WAITING_LIST .
					' WHERE event_id = %d AND status IN (' . $placeholders . ')' . $tier_sql .
					' AND ( created_at < %s OR ( created_at = %s AND id < %d ) )',
					array_merge(
						[ (int) $entry->event_id ],
						$statuses,
						$tier_values,
						[ $entry->created_at, $entry->created_at, (int) $entry->id ]
					)
				)
			);

			return $ahead + 1;
		}

		public static function find_live_entry( int $event_id, int $customer_id, ?int $ticket_type_id = null ): ?OsEventWaitingListModel {
			if ( ! $event_id || ! $customer_id ) {
				return null;
			}
			// Scoped to one tier: a customer may hold several, and an unscoped lookup closes the wrong one.
			$conditions = [
				'event_id'       => $event_id,
				'customer_id'    => $customer_id,
				// null_condition() compiles to IS NULL; a PHP null would become `= %s`.
				'ticket_type_id' => $ticket_type_id ? (int) $ticket_type_id : OsModel::null_condition(),
			];

			$found = ( new OsEventWaitingListModel() )
				->where( $conditions )
				->where_in( 'status', OsEventWaitingListModel::live_statuses() )
				->order_by( 'created_at asc, id asc' )
				->set_limit( 1 )
				->get_results_as_models();

			return ( $found instanceof OsEventWaitingListModel && $found->id ) ? $found : null;
		}

		// ─── Ticket Types bridge ────────────────────────────────────────────────

		/**
		 * The event's active ticket types, or [] when Ticket Types is not driving this event.
		 *
		 * Memoised because get_active_types_for_event() queries on every call and the capacity hold
		 * asks once per type per render - an events list would otherwise pay for it per card.
		 */
		private static function ticket_types_for( OsEventModel $event ): array {
			$id = (int) $event->id;
			if ( ! $id || ! class_exists( 'OsFeatureEventTicketTypesHelper' ) ) {
				return [];
			}
			if ( ! isset( self::$types_cache[ $id ] ) ) {
				self::$types_cache[ $id ] = OsFeatureEventTicketTypesHelper::is_enabled_for_event( $event )
					? OsFeatureEventTicketTypesHelper::get_active_types_for_event( $id )
					: [];
			}

			return self::$types_cache[ $id ];
		}

		/**
		 * The event's active ticket types whether or not the Enable Ticket Types toggle is on.
		 *
		 * Used by the admin form and by the save, so turning the toggle off does not erase the
		 * per-type allowances the admin will want back when they turn it on again.
		 */
		private static function editable_ticket_types_for( OsEventModel $event ): array {
			if ( ! $event->id || ! class_exists( 'OsFeatureEventTicketTypesHelper' ) || ! OsFeatureEventTicketTypesHelper::is_enabled() ) {
				return [];
			}

			return OsFeatureEventTicketTypesHelper::get_active_types_for_event( (int) $event->id );
		}

		/** Whether at least one active ticket type is capped, and so can fill up. */
		private static function has_capped_ticket_type( OsEventModel $event ): bool {
			foreach ( self::ticket_types_for( $event ) as $type ) {
				if ( $type->capacity ) {
					return true;
				}
			}

			return false;
		}

		/**
		 * Whether taking this place costs money.
		 *
		 * OsEventModel::is_paid() reads the event's own price, which a Ticket Types event leaves at 0
		 * because its types own the pricing - so every such event would look free, and the organizer
		 * would be offered "Give Place", handing out a priced seat for nothing.
		 */
		public static function is_paid_for_entry( OsEventWaitingListModel $entry, ?OsEventModel $event = null ): bool {
			$event = $event ?? $entry->get_event();
			if ( $event && $event->is_paid() ) {
				return true;
			}

			$type = $entry->get_ticket_type();

			return $type && (float) $type->price > 0;
		}

		/**
		 * Whether a queue is a meaningful idea for this event at all: switched on, capped,
		 * published, and still inside its registration window. can_join() adds the one question
		 * this deliberately leaves out, whether there is still room in the queue itself, because
		 * a queue that is full is still a queue worth describing, just not worth offering.
		 */
		private static function queue_applies_to_event( OsEventModel $event ): bool {
			if ( ! $event->id || ! self::is_enabled_for_event( $event ) ) {
				return false;
			}
			// Needs something that can fill up. has_capacity_limit() alone is too strict: false as soon as one tier is uncapped.
			if ( ! $event->has_capacity_limit() && ! self::has_capped_ticket_type( $event ) ) {
				return false;
			}
			if ( $event->status !== LATEPOINT_EVENT_STATUS_PUBLISHED ) {
				return false;
			}

			return self::is_registration_window_open( $event );
		}

		public static function can_join( OsEventModel $event, ?int $ticket_type_id = null ): bool {
			if ( ! self::queue_applies_to_event( $event ) ) {
				return false;
			}

			if ( null !== $ticket_type_id ) {
				// Per ticket type: a sold-out tier offers its queue while the others still sell.
				$type = self::find_ticket_type( $event, $ticket_type_id );
				// An uncapped type can never fill up, so it never has a queue.
				if ( ! $type || ! $type->capacity ) {
					return false;
				}
				// Read raw, not is_sold_out(): that reads back this feature's own hold and would call the tier full the moment one person queued.
				if ( self::raw_tier_capacity( $type ) > self::get_queued_quantity( (int) $event->id, $ticket_type_id ) ) {
					return false;
				}
			} elseif ( ! $event->is_sold_out() ) {
				// A queue is only for an event with nothing left to sell; the Join button not being
				// rendered is not a guard.
				return false;
			}

			$capacity = self::get_capacity( $event, $ticket_type_id );

			return ! $capacity || self::get_queued_quantity( (int) $event->id, $ticket_type_id ) < $capacity;
		}

		/** The ticket types on this event that are full and still have room in their queue. */
		public static function joinable_ticket_types( OsEventModel $event ): array {
			$joinable = [];
			foreach ( self::ticket_types_for( $event ) as $type ) {
				if ( self::can_join( $event, (int) $type->id ) ) {
					$joinable[] = $type;
				}
			}

			return $joinable;
		}

		/**
		 * The registration window on its own, without the sold-out test that
		 * OsEventModel::is_registration_open() folds in. The whole point of a waiting list is that
		 * the event is full, so that test would always fail here.
		 */
		private static function is_registration_window_open( OsEventModel $event ): bool {
			$now = current_time( 'timestamp', true );

			$opens_at = self::event_stamp( $event, 'registration_start_utc' );
			if ( $opens_at && $now < $opens_at ) {
				return false;
			}

			$closes_at = self::registration_closes_at( $event );

			return ! ( $closes_at && $now > $closes_at );
		}

		/**
		 * One event datetime column as a UTC timestamp, or 0 when it is unusable.
		 *
		 * MySQL zero-dates ('0000-00-00 00:00:00') parse to false or a negative number, and every
		 * caller here has to skip them, so the guard lives in one place.
		 */
		private static function event_stamp( OsEventModel $event, string $field ): int {
			if ( empty( $event->$field ) ) {
				return 0;
			}
			$stamp = strtotime( $event->$field . ' UTC' );

			return $stamp > 0 ? (int) $stamp : 0;
		}

		/**
		 * The moment registration for this event closes, or 0 if it never does: whichever comes first
		 * of the registration end date and the event's start. Matches is_registration_open().
		 */
		private static function registration_closes_at( OsEventModel $event ): int {
			$bounds = array_filter(
				[
					self::event_stamp( $event, 'registration_end_utc' ),
					self::event_stamp( $event, 'start_datetime_utc' ),
				]
			);

			return $bounds ? min( $bounds ) : 0;
		}

		/**
		 * Hold a ticket type's freed places for the queue waiting on it, the per-type twin of
		 * keep_event_full_while_queue_waits(). Must never call back into capacity: it runs inside
		 * get_available_capacity().
		 */
		public static function hold_tier_seats_for_queue( int $available, OsEventTicketTypeModel $type ): int {
			// Set while the waiting list is asking what a type really has left; see the property.
			if ( self::$reading_raw_capacity || $available <= 0 || PHP_INT_MAX === $available ) {
				return $available;
			}
			$event_id = (int) $type->event_id;
			$type_id  = (int) $type->id;
			if ( ! $event_id || ! $type_id || ! self::is_enabled() ) {
				return $available;
			}

			$queued = self::get_queued_quantity( $event_id, $type_id );
			if ( $queued < 1 ) {
				return $available;
			}

			// The event is only loaded once there is a queue to hold for, and memoised: this runs
			// once per tier per render, so a fresh load here is a query per queued tier per card.
			$event = self::event( $event_id );
			if ( ! self::is_enabled_for_event( $event ) ) {
				return $available;
			}

			// What this request is entitled to claim right now, if it arrived holding an invitation
			// for this very type.
			$claim = self::claimed_quantity_for_tier( $event, $type_id );

			// Hold what the rest of the queue is waiting for, but never the claimer's own places -
			// otherwise the invitation we just issued would be refused by the hold protecting it.
			$others = max( 0, $queued - $claim );
			$hold   = min( max( 0, $available - $claim ), $others );

			return $available - $hold;
		}

		/**
		 * Diagnostics for the three paths that cannot be reproduced locally: a gateway webhook, an
		 * invitation going out, and an invitation being retired. A token is a credential and is never written here.
		 */
		private static function debug_log( string $message, array $context = [] ): void {
			$on = defined( 'WP_DEBUG' ) && WP_DEBUG;
			/**
			 * Turns waiting list diagnostics on without turning WP_DEBUG on.
			 *
			 * @param {bool} $on Whether to record them.
			 * @returns {bool}
			 *
			 * @since 1.7.3
			 * @hook latepoint_event_waiting_list_debug
			 */
			if ( ! apply_filters( 'latepoint_event_waiting_list_debug', $on ) ) {
				return;
			}
			OsDebugHelper::log( 'Event waiting list: ' . $message, 'event_waiting_list', $context );
		}

		/** Opens the window in which this order's buyer is exempt from their own invitation's hold. */
		public static function begin_registering_order( OsOrderModel $order ): void {
			self::$registering_customer_id = (int) $order->customer_id;
		}

		/** Closes it again, so the exemption cannot leak into anything else this request does. */
		public static function finish_registering_order( OsOrderModel $order ): void {
			self::$registering_customer_id = 0;
		}

		/**
		 * Places that may be taken in this ticket type despite the hold, because they were already
		 * promised to whoever is taking them. 0 for everybody else.
		 */
		private static function claimed_quantity_for_tier( OsEventModel $event, int $ticket_type_id ): int {
			$entry = self::claimed_entry();
			if ( $entry && (int) $entry->event_id === (int) $event->id && (int) $entry->ticket_type_id === $ticket_type_id ) {
				return max( 1, (int) $entry->quantity );
			}

			// Only a live invitation counts; somebody merely waiting has not been offered the seat yet.
			if ( self::$registering_customer_id ) {
				$invited = self::find_live_entry( (int) $event->id, self::$registering_customer_id, $ticket_type_id );
				if ( $invited && $invited->has_live_invite() ) {
					self::debug_log(
						'order is being registered for an invited customer, releasing their own places',
						[
							'event_id'       => (int) $event->id,
							'ticket_type_id' => $ticket_type_id,
							'customer_id'    => self::$registering_customer_id,
							'entry_id'       => (int) $invited->id,
							'places'         => max( 1, (int) $invited->quantity ),
						]
					);

					return max( 1, (int) $invited->quantity );
				}

				self::debug_log(
					'order is being registered but the buyer holds no live invitation for this ticket, the hold still applies',
					[
						'event_id'       => (int) $event->id,
						'ticket_type_id' => $ticket_type_id,
						'customer_id'    => self::$registering_customer_id,
					]
				);
			}

			return 0;
		}

		public static function keep_event_full_while_queue_waits( bool $is_sold_out, OsEventModel $event ): bool {
			if ( $is_sold_out || ! $event->id || ! self::is_enabled_for_event( $event ) ) {
				return $is_sold_out;
			}
			if ( ! self::has_queue( (int) $event->id ) ) {
				return false;
			}
			if ( self::is_claiming_for_event( $event ) ) {
				return false;
			}

			// null when the event has no capacity limit, so there is nothing to hold.
			$free = self::get_available_seats( $event );

			return null !== $free && $free <= self::get_queued_quantity( (int) $event->id );
		}

		/**
		 * "2 people waiting", or an empty string when nobody is.
		 *
		 * Deliberately a count of people rather than of places: it answers "how many are ahead of
		 * me", which is what somebody deciding whether to join is actually asking. Places queued
		 * for is a different number (get_queued_quantity()) and belongs to capacity, not to this.
		 */
		private static function queue_count_label( OsEventModel $event ): string {
			if ( ! self::queue_applies_to_event( $event ) ) {
				return '';
			}
			$count = self::get_queue_count( (int) $event->id );
			if ( $count < 1 ) {
				return '';
			}

			// Leading space so the label reads correctly wherever it is appended, with or without CSS.
			return ' <span class="latepoint-event-queue-count">' . esc_html(
				sprintf(
					/* translators: %d: how many people are already on the waiting list */
					_n( '%d person waiting', '%d people waiting', $count, 'latepoint-pro-features' ),
					$count
				)
			) . '</span>';
		}

		/** Says how busy the queue is next to core's "Full" label, so joining is an informed choice. */
		public static function append_queue_count_to_full_label( string $html, OsEventModel $event ): string {
			return $html . self::queue_count_label( $event );
		}

		public static function render_join_action( string $html, OsEventModel $event, string $context ): string {
			// Inside the wizard a second Join button is a dead end, so state the fact instead.
			if ( 'step' === $context ) {
				if ( ! self::queue_applies_to_event( $event ) ) {
					return $html;
				}

				return '<span class="event-step-meta-value event-sold-out">' . esc_html__( 'Full', 'latepoint-pro-features' ) . '</span>' .
					self::queue_count_label( $event );
			}

			// A tiered event asks which ticket on the step itself, so the button carries no type.
			if ( ! self::can_join( $event ) && ! self::joinable_ticket_types( $event ) ) {
				return $html;
			}

			return self::join_button_html( $event );
		}

		/**
		 * The queue for a ticket type that has sold out while the rest of the event is still on sale.
		 *
		 * latepoint_event_sold_out_action_html never fires here - the event is not sold out - so
		 * without this the one configuration a per-type queue exists for would have no way in.
		 */
		public static function output_tier_join_actions( OsEventModel $event ): void {
			$joinable = self::can_join( $event ) ? [] : self::joinable_ticket_types( $event );
			if ( ! $joinable ) {
				return;
			}

			$buttons = '';
			foreach ( $joinable as $type ) {
				$buttons .= self::join_button_html(
					$event,
					(int) $type->id,
					/* translators: %s: ticket type name */
					sprintf( __( 'Join Waiting List: %s', 'latepoint-pro-features' ), $type->name )
				);
			}

			echo '<div class="latepoint-event-tier-join-w">' . $buttons . '</div>';
		}

		/** The Join button, optionally bound to one ticket type. */
		private static function join_button_html( OsEventModel $event, int $ticket_type_id = 0, string $label = '' ): string {
			return '<button type="button" class="latepoint-event-join-waiting-list-btn latepoint-btn latepoint-btn-primary" data-event-id="' .
				esc_attr( (string) $event->id ) . '"' .
				( $ticket_type_id ? ' data-ticket-type-id="' . esc_attr( (string) $ticket_type_id ) . '"' : '' ) . '>' .
				esc_html( $label ?: __( 'Join Waiting List', 'latepoint-pro-features' ) ) .
				'</button>';
		}

		// ─── Wizard step ────────────────────────────────────────────────────────

		/**
		 * Front-end variables for the feature: which event this request holds an invitation for
		 * (so the claim link opens the wizard on it rather than dropping the customer on a list of
		 * events), and a translated message for the case where the request itself fails.
		 */
		public static function localize_front_vars( array $vars ): array {
			$event_id = self::get_claimed_event_id();
			if ( $event_id ) {
				$vars['waiting_list_claim_event_id'] = $event_id;
			}
			$vars['waiting_list_error'] = __( 'Something went wrong, please try again.', 'latepoint-pro-features' );

			// A link that cannot be used has to say so, or nothing opens and the customer is offered the queue they are already on.
			$claim_error = self::get_claim_error();
			if ( $claim_error ) {
				$vars['waiting_list_claim_error'] = $claim_error;
			}

			return $vars;
		}

		public static function add_default_presets( array $presets ): array {
			$presets[ self::INTENT_PRESET ]      = false;
			$presets[ self::CLAIM_PARAM ]        = false;
			$presets[ self::TICKET_TYPE_PRESET ] = false;

			return $presets;
		}

		public static function is_waiting_list_mode(): bool {
			return ! empty( OsStepsHelper::$presets[ self::INTENT_PRESET ] )
				&& ! empty( OsStepsHelper::$presets['selected_event_id'] );
		}

		/**
		 * Placed after `customer` so the queue entry is only created once core's own customer step
		 * has resolved who this is.
		 */
		public static function add_step( array $steps ): array {
			// Ordering only binds steps sharing a parent (steps_helper.php:184-201); Free's tickets step is a child of `booking`, this one is root level.
			$steps[ self::TICKET_STEP_CODE ]  = [
				'after'  => 'booking',
				'before' => 'customer',
			];
			$steps[ self::STEP_CODE ]         = [ 'after' => 'customer' ];
			$steps[ self::CONFIRM_STEP_CODE ] = [ 'after' => self::STEP_CODE ];

			return $steps;
		}

		/**
		 * The queue step submits with the wizard's own next button (labelled "Submit" because it is
		 * the pre-last step), exactly like every other step. The confirmation step that follows it
		 * has nothing to submit.
		 */
		public static function add_step_next_btn_rules( array $rules ): array {
			$rules[ self::TICKET_STEP_CODE ]  = true;
			$rules[ self::STEP_CODE ]         = true;
			$rules[ self::CONFIRM_STEP_CODE ] = false;

			return $rules;
		}

		/**
		 * Default headings for the three waiting list steps.
		 *
		 * Without these a step renders with a blank header and an empty side panel until somebody
		 * types something into Settings, which is what happens on any fresh install.
		 */
		public static function add_step_settings( array $settings ): array {
			$settings[ self::TICKET_STEP_CODE ]  = [
				'side_panel_heading'     => __( 'Ticket Selection', 'latepoint-pro-features' ),
				'side_panel_description' => __( 'Choose which ticket you would like to wait for', 'latepoint-pro-features' ),
				'main_panel_heading'     => __( 'Select Your Ticket', 'latepoint-pro-features' ),
			];
			$settings[ self::STEP_CODE ]         = [
				'side_panel_heading'     => __( 'Waiting List', 'latepoint-pro-features' ),
				'side_panel_description' => __( 'Confirm the details below to join the queue for this event', 'latepoint-pro-features' ),
				'main_panel_heading'     => __( 'Join the Waiting List', 'latepoint-pro-features' ),
			];
			$settings[ self::CONFIRM_STEP_CODE ] = [
				'side_panel_heading'     => __( 'Waiting List', 'latepoint-pro-features' ),
				'side_panel_description' => __( 'You are in the queue for this event', 'latepoint-pro-features' ),
				'main_panel_heading'     => __( 'You Are on the Waiting List', 'latepoint-pro-features' ),
			];

			return $settings;
		}

		public static function add_step_label( array $labels ): array {
			$labels[ self::TICKET_STEP_CODE ]  = __( 'Select Ticket', 'latepoint-pro-features' );
			$labels[ self::STEP_CODE ]         = __( 'Waiting List', 'latepoint-pro-features' );
			$labels[ self::CONFIRM_STEP_CODE ] = __( 'Waiting List Confirmation', 'latepoint-pro-features' );

			return $labels;
		}

		public static function remove_step_from_select( array $steps_with_labels ): array {
			unset( $steps_with_labels[ self::TICKET_STEP_CODE ], $steps_with_labels[ self::STEP_CODE ], $steps_with_labels[ self::CONFIRM_STEP_CODE ] );

			return $steps_with_labels;
		}

		public static function remove_step_from_order_modal( array $step_codes ): array {
			return array_values( array_diff( $step_codes, [ self::TICKET_STEP_CODE, self::STEP_CODE, self::CONFIRM_STEP_CODE ] ) );
		}

		public static function should_step_be_skipped( bool $skip, string $step_code, OsCartModel $cart, OsCartItemModel $cart_item, OsBookingModel $booking ): bool {
			$waiting_list_mode = self::is_waiting_list_mode();

			if ( self::STEP_CODE === $step_code || self::CONFIRM_STEP_CODE === $step_code ) {
				return ! $waiting_list_mode;
			}
			// Only worth showing when there is actually a choice to make: a flat event has no
			// ticket types, and an event whose queues are all closed has nothing to offer.
			if ( self::TICKET_STEP_CODE === $step_code ) {
				if ( ! $waiting_list_mode ) {
					return true;
				}
				$event_id = (int) ( OsStepsHelper::$presets['selected_event_id'] ?? 0 );

				return ! $event_id || ! self::joinable_ticket_types( new OsEventModel( $event_id ) );
			}
			if ( ! $waiting_list_mode ) {
				return $skip;
			}
			// Nothing is bought when joining a queue.
			if ( 0 === strpos( $step_code, 'payment' ) || in_array( $step_code, [ 'verify', 'confirmation' ], true ) ) {
				return true;
			}
			// Ticket Types' selector offers only tickets still on sale, which is none on a full event.
			if ( OsEventsHooksHelper::$tickets_step_code === $step_code && self::event_uses_ticket_types() ) {
				return true;
			}

			// Free's event steps stay; their gates are lifted in skip_step_gate_in_waiting_list_mode() rather than by skipping them.
			return $skip;
		}

		/**
		 * Keeps the summary panel's Checkout link out of the waiting list.
		 *
		 * The panel itself is wanted - it is where the customer sees which event they are queuing
		 * for - but nothing here is for sale, and that link would drop somebody straight from the
		 * queue into a checkout for a place they have not been offered.
		 */
		public static function hide_checkout_in_waiting_list_mode( bool $can ): bool {
			return self::is_waiting_list_mode() ? false : $can;
		}

		/**
		 * One place when the tickets step was skipped, so the event registration cart item is not
		 * left at zero - core refuses to leave any later step while it is.
		 */
		public static function default_quantity_when_tickets_step_skipped( int $quantity, OsEventModel $event, array $params ): int {
			if ( $quantity > 0 || ! self::is_waiting_list_mode() || ! self::event_uses_ticket_types() ) {
				return $quantity;
			}

			return 1;
		}

		/** Whether Ticket Types is driving the event the wizard is currently on. */
		private static function event_uses_ticket_types(): bool {
			if ( ! class_exists( 'OsFeatureEventTicketTypesHelper' ) ) {
				return false;
			}
			$event_id = (int) ( OsStepsHelper::$presets['selected_event_id'] ?? 0 );
			if ( ! $event_id ) {
				return false;
			}
			// Memoised: this is asked once per step while the wizard builds its list.
			if ( ! isset( self::$uses_ticket_types_cache[ $event_id ] ) ) {
				self::$uses_ticket_types_cache[ $event_id ] = OsFeatureEventTicketTypesHelper::is_enabled_for_event( new OsEventModel( $event_id ) );
			}

			return self::$uses_ticket_types_cache[ $event_id ];
		}

		/**
		 * Lifts the event step's "registration is open" and "there is room" gates in waiting list mode.
		 * Neither applies: the event being full is why the customer is here, and create_entry() bounds
		 * how many places they may ask for.
		 */
		public static function skip_step_gate_in_waiting_list_mode( bool $skip, OsEventModel $event, array $params ): bool {
			// is_waiting_list_mode() reads request presets, so only the server's own view of the event may lift core's gates.
			return ( self::is_waiting_list_mode() && self::queue_applies_to_event( $event ) ) ? true : $skip;
		}

		/**
		 * Bounds the ticket step's quantity by what is left of the waiting list, not by the
		 * event's remaining seats - which are zero, or the customer would not be queuing.
		 */
		public static function bound_quantity_by_queue_capacity( int $max_qty, OsEventModel $event ): int {
			if ( ! self::is_waiting_list_mode() ) {
				return $max_qty;
			}

			// Free's step always offers at least one and never more than its own cap of 10.
			return max( 1, min( 10, self::max_queue_quantity( $event, 0 ) ) );
		}

		/**
		 * Creates the queue entry when the waiting list step is submitted, so the flow uses the
		 * wizard's own next button and step machinery rather than a bespoke panel and route.
		 */
		public static function process_step( string $step_code, OsBookingModel $booking, array $params ): void {
			if ( self::TICKET_STEP_CODE === $step_code ) {
				self::process_ticket_step( $params );

				return;
			}
			if ( self::STEP_CODE !== $step_code ) {
				return;
			}

			$event_id = (int) ( OsStepsHelper::$presets['selected_event_id'] ?? 0 );
			$event    = new OsEventModel( $event_id );
			if ( ! $event->id ) {
				self::send_step_error( __( 'Event not found.', 'latepoint-pro-features' ) );

				return;
			}

			$customer = OsStepsHelper::get_customer_object();
			if ( ! $customer || ! $customer->id ) {
				self::send_step_error( __( 'Please go back and enter your contact details first.', 'latepoint-pro-features' ), 'customer' );

				return;
			}

			$chosen = self::read_ticket_choice();
			$source = (string) OsUtilHelper::get_referrer();

			if ( self::ticket_types_for( $event ) ) {
				if ( ! $chosen ) {
					self::send_step_error( __( 'Please choose at least one ticket to wait for.', 'latepoint-pro-features' ), self::TICKET_STEP_CODE );

					return;
				}

				// One entry per ticket, because each ticket has its own queue and its own place in
				// it. The unique index allows exactly one live entry per customer per ticket.
				$entries = [];
				foreach ( $chosen as $ticket_type_id => $quantity ) {
					// Already queued for this ticket: keep it rather than erroring, so a double
					// submit is idempotent instead of alarming.
					$existing = self::find_live_entry( (int) $event->id, (int) $customer->id, $ticket_type_id );
					if ( $existing ) {
						$entries[] = $existing;
						continue;
					}

					$entry = self::create_entry( $event, $customer, $quantity, $source, $ticket_type_id );
					if ( is_wp_error( $entry ) ) {
						self::send_step_error( $entry->get_error_message(), self::TICKET_STEP_CODE );

						return;
					}
					$entries[] = $entry;
				}

				self::$created_entry = $entries[0] ?? null;
			} else {
				$existing = self::find_live_entry( (int) $event->id, (int) $customer->id );
				if ( $existing ) {
					self::$created_entry = $existing;

					return;
				}

				$entry = self::create_entry( $event, $customer, self::get_selected_quantity(), $source );
				if ( is_wp_error( $entry ) ) {
					self::send_step_error( $entry->get_error_message() );

					return;
				}

				self::$created_entry = $entry;
			}

			// Nothing was bought, so the event step's cart item must not be left behind.
			$active = OsStepsHelper::$active_cart_item ?? null;
			self::discard_cart_item( (int) $event->id, ( $active && ! $active->is_new_record() ) ? (int) $active->id : 0 );
		}

		/** Validates the posted quantities against the event's own open queues, and records them. */
		private static function process_ticket_step( array $params ): void {
			$event_id = (int) ( OsStepsHelper::$presets['selected_event_id'] ?? 0 );
			$event    = $event_id ? new OsEventModel( $event_id ) : null;
			if ( ! $event || ! $event->id ) {
				self::send_step_error( __( 'Event not found.', 'latepoint-pro-features' ) );

				return;
			}

			// $params is raw request data. Only the event's own open queues are read out of it, so
			// an edited or invented id simply does not appear in the result.
			$submitted = is_array( $params[ self::TICKETS_FIELD ] ?? null ) ? $params[ self::TICKETS_FIELD ] : [];
			$chosen    = [];

			foreach ( self::joinable_ticket_types( $event ) as $type ) {
				$quantity = absint( $submitted[ $type->id ] ?? 0 );
				if ( $quantity < 1 ) {
					continue;
				}

				$most = self::max_queue_quantity( $event, (int) $type->id );
				if ( $quantity > $most ) {
					self::send_step_error(
						sprintf(
							/* translators: %1$d: places still free in this queue, %2$s: ticket type name */
							_n( 'Only %1$d place is left on the waiting list for %2$s.', 'Only %1$d places are left on the waiting list for %2$s.', $most, 'latepoint-pro-features' ),
							$most,
							$type->name
						),
						self::TICKET_STEP_CODE
					);

					return;
				}

				$chosen[ (int) $type->id ] = $quantity;
			}

			if ( ! $chosen ) {
				self::send_step_error( __( 'Please choose at least one ticket to wait for.', 'latepoint-pro-features' ), self::TICKET_STEP_CODE );

				return;
			}

			self::store_ticket_choice( $chosen, $event );
		}

		/**
		 * Remembers the ticket and places chosen, on the event's own cart item row.
		 *
		 * Not a preset: core renders the presets footer once when the wizard opens, so a value
		 * chosen on a later step never reaches it. The cart item is written to the database and is
		 * what the steps after this one read back, exactly as get_selected_quantity() already does.
		 */
		private static function store_ticket_choice( array $chosen, OsEventModel $event ): void {
			$cart_item = self::stored_cart_item();
			if ( ! $cart_item ) {
				return;
			}

			$data = json_decode( (string) $cart_item->item_data, true );
			$data = is_array( $data ) ? $data : [];

			// The same breakdown a purchase writes, so the summary prices the queue exactly as it prices a sale.
			$breakdown = [];
			foreach ( $chosen as $ticket_type_id => $quantity ) {
				$type = self::find_ticket_type( $event, (int) $ticket_type_id );
				if ( ! $type ) {
					continue;
				}
				$breakdown[ (int) $type->id ] = [
					'name'     => $type->name,
					'price'    => (float) $type->price,
					'quantity' => $quantity,
				];
			}

			$data['ticket_types'] = $breakdown;
			$data['quantity']     = max( 1, array_sum( $chosen ) );

			$cart_item->item_data = wp_json_encode( $data );
			$cart_item->save();
		}


		/** The places chosen earlier, as [ ticket_type_id => places ]. */
		private static function read_ticket_choice(): array {
			$cart_item = self::stored_cart_item();
			if ( ! $cart_item || ! class_exists( 'OsFeatureEventTicketTypesHelper' ) ) {
				return [];
			}

			$chosen = [];
			foreach ( OsFeatureEventTicketTypesHelper::get_ticket_types_breakdown( (string) $cart_item->item_data ) as $type_id => $row ) {
				$quantity = absint( $row['quantity'] ?? 0 );
				if ( $quantity ) {
					$chosen[ absint( $type_id ) ] = $quantity;
				}
			}

			return $chosen;
		}


		/**
		 * The active cart item as the database has it.
		 *
		 * The wizard carries active_cart_item[item_data] in the DOM as a snapshot taken when that
		 * field was last rendered, so the posted copy is stale by a step.
		 */
		private static function stored_cart_item(): ?OsCartItemModel {
			$cart_item = OsStepsHelper::$active_cart_item ?? null;
			if ( ! $cart_item || $cart_item->is_new_record() ) {
				return null;
			}
			$stored = new OsCartItemModel( $cart_item->id );

			return $stored->id ? $stored : null;
		}

		private static function send_step_error( string $message, string $send_to_step = '' ): void {
			wp_send_json(
				[
					'status'           => LATEPOINT_STATUS_ERROR,
					'message'          => $message,
					'send_to_step'     => $send_to_step,
					'fields_to_update' => OsStepsHelper::$fields_to_update,
				]
			);
		}

		public static function load_step( string $step_code, string $format = 'json', array $params = [] ): void {
			if ( ! in_array( $step_code, [ self::TICKET_STEP_CODE, self::STEP_CODE, self::CONFIRM_STEP_CODE ], true ) ) {
				return;
			}

			$event_id = (int) ( OsStepsHelper::$presets['selected_event_id'] ?? 0 );
			$event    = $event_id ? new OsEventModel( $event_id ) : null;
			$customer = OsStepsHelper::get_customer_object();

			$entry = self::$created_entry;
			if ( ! $entry && $event && $customer->id ) {
				$live  = self::live_entries_for( $event, $customer );
				$entry = $live[0] ?? null;
			}

			$controller                            = new OsEventWaitingListController();
			$controller->vars['event']             = $event;
			$controller->vars['customer']          = $customer;
			$controller->vars['entry']             = $entry;
			$controller->vars['current_step_code'] = $step_code;
			$chosen                                = self::read_ticket_choice();

			$controller->vars['quantity']      = $entry ? (int) $entry->quantity : max( 1, array_sum( $chosen ) ?: self::get_selected_quantity() );
			$controller->vars['tickets_field'] = self::TICKETS_FIELD;

			// The chooser only exists on its own step; the later steps just report what was chosen.
			if ( self::TICKET_STEP_CODE === $step_code ) {
				$rows = [];
				foreach ( $event ? self::joinable_ticket_types( $event ) : [] as $type ) {
					$rows[] = [
						'type'    => $type,
						'max'     => self::max_queue_quantity( $event, (int) $type->id ),
						'waiting' => self::get_queue_count( (int) $event->id, (int) $type->id ),
						// Repopulated on back-navigation, and seeded from the Join button when it
						// named a ticket, so the customer is not asked the same thing twice.
						'chosen'  => $chosen[ (int) $type->id ] ?? ( (int) $type->id === self::joined_from_ticket_type_id() ? 1 : 0 ),
					];
				}
				$controller->vars['ticket_rows'] = $rows;
			}

			// What is being waited for, for the summary and the confirmation.
			$rows                               = self::summarise_standing( $event, $customer, $chosen );
			$controller->vars['chosen_tickets'] = $rows;
			// Drives the wording of the step's notice: everything they picked is already held, so
			// there is nothing left for this step to add.
			$all_queued = (bool) $rows;
			foreach ( $rows as $row ) {
				if ( empty( $row['queued'] ) ) {
					$all_queued = false;
					break;
				}
			}
			$controller->vars['all_already_queued'] = $all_queued;
			$controller->vars['position']           = $entry
				? self::get_position( $entry )
				: ( $event ? ( self::get_queue_count( (int) $event->id, self::pending_position_tier( $event ) ) + 1 ) : 1 );
			$controller->set_layout( 'none' );
			$controller->set_return_format( $format );
			$views = [
				self::TICKET_STEP_CODE  => '_step_tickets',
				self::CONFIRM_STEP_CODE => '_step_joined',
			];

			$controller->format_render(
				$views[ $step_code ] ?? '_step_waiting_list',
				[],
				[
					'fields_to_update' => OsStepsHelper::$fields_to_update,
					'step_code'        => $step_code,
					'show_next_btn'    => OsStepsHelper::can_step_show_next_btn( $step_code ),
					'show_prev_btn'    => OsStepsHelper::can_step_show_prev_btn( $step_code ),
					'is_first_step'    => OsStepsHelper::is_first_step( $step_code ),
					'is_last_step'     => OsStepsHelper::is_last_step( $step_code ),
					'is_pre_last_step' => OsStepsHelper::is_pre_last_step( $step_code ),
				]
			);
		}

		/**
		 * Keeps the waiting-list flag with the form so it survives every step, the same way Free
		 * carries selected_event_id.
		 */
		public static function render_intent_preset_field(): void {
			if ( empty( OsStepsHelper::$presets[ self::INTENT_PRESET ] ) ) {
				return;
			}
			echo OsFormHelper::hidden_field(
				'presets[' . self::INTENT_PRESET . ']',
				LATEPOINT_VALUE_ON,
				[
					'skip_id' => true,
					'class'   => 'clear_for_new_item',
				]
			);
		}

		public static function render_ticket_type_preset_field(): void {
			$type_id = absint( OsStepsHelper::$presets[ self::TICKET_TYPE_PRESET ] ?? 0 );
			if ( ! $type_id ) {
				return;
			}
			echo OsFormHelper::hidden_field(
				'presets[' . self::TICKET_TYPE_PRESET . ']',
				(string) $type_id,
				[
					'skip_id' => true,
					'class'   => 'clear_for_new_item',
				]
			);
		}

		public static function render_claim_preset_field(): void {
			if ( empty( OsStepsHelper::$presets[ self::CLAIM_PARAM ] ) ) {
				return;
			}
			echo OsFormHelper::hidden_field(
				'presets[' . self::CLAIM_PARAM . ']',
				OsStepsHelper::$presets[ self::CLAIM_PARAM ],
				[
					'skip_id' => true,
					'class'   => 'clear_for_new_item',
				]
			);
		}

		/**
		 * The ticket type the "you would be #N" figure should count within, before anything is
		 * chosen. null on a flat event, where the queue is the event's own.
		 */
		private static function pending_position_tier( OsEventModel $event ): ?int {
			$chosen = self::read_ticket_choice();
			if ( $chosen ) {
				return (int) array_key_first( $chosen );
			}
			$named = self::joined_from_ticket_type_id();
			if ( $named ) {
				return $named;
			}
			$joinable = self::joinable_ticket_types( $event );

			return $joinable ? (int) $joinable[0]->id : null;
		}

		/** The ticket a per-ticket Join button named, when the wizard was opened from one. */
		private static function joined_from_ticket_type_id(): int {
			return absint( OsStepsHelper::$presets[ self::TICKET_TYPE_PRESET ] ?? 0 );
		}

		/** Live queue entries this customer holds on this event. */
		private static function live_entries_for( ?OsEventModel $event, ?OsCustomerModel $customer ): array {
			if ( ! $event || ! $event->id || ! $customer || ! $customer->id ) {
				return [];
			}
			$found = ( new OsEventWaitingListModel() )
				->where(
					[
						'event_id'    => (int) $event->id,
						'customer_id' => (int) $customer->id,
					]
				)
				->where_in( 'status', OsEventWaitingListModel::live_statuses() )
				->order_by( 'created_at asc, id asc' )
				->get_results_as_models();

			if ( ! $found ) {
				return [];
			}

			return is_array( $found ) ? $found : [ $found ];
		}

		/**
		 * Entries as the views want them: the ticket, how many places, and where in that ticket's
		 * own queue the customer stands.
		 */
		private static function summarise_entries( array $entries ): array {
			$rows = [];
			foreach ( $entries as $entry ) {
				$rows[] = [
					'type'     => $entry->get_ticket_type(),
					'quantity' => max( 1, (int) $entry->quantity ),
					'position' => self::get_position( $entry ),
				];
			}

			return $rows;
		}

		/**
		 * Every ticket this customer will stand to wait for: the ones they already hold, then the ones
		 * just picked. Entries with no ticket type are left out; a flat event reports a single position.
		 */
		private static function summarise_standing( ?OsEventModel $event, ?OsCustomerModel $customer, array $chosen ): array {
			$rows = [];
			$held = [];
			foreach ( self::summarise_entries( self::live_entries_for( $event, $customer ) ) as $row ) {
				if ( ! $row['type'] ) {
					continue;
				}
				$row['queued']                  = true;
				$rows[]                         = $row;
				$held[ (int) $row['type']->id ] = true;
			}
			foreach ( self::summarise_chosen( $event, $chosen ) as $row ) {
				if ( isset( $held[ (int) $row['type']->id ] ) ) {
					continue;
				}
				$row['queued'] = false;
				$rows[]        = $row;
			}

			return $rows;
		}

		/** The same shape for a choice that has not been written yet. */
		private static function summarise_chosen( ?OsEventModel $event, array $chosen ): array {
			$rows = [];
			foreach ( $chosen as $ticket_type_id => $quantity ) {
				$type = $event ? self::find_ticket_type( $event, (int) $ticket_type_id ) : null;
				if ( ! $type ) {
					continue;
				}
				$rows[] = [
					'type'     => $type,
					'quantity' => $quantity,
					'position' => self::get_queue_count( (int) $event->id, (int) $type->id ) + 1,
				];
			}

			return $rows;
		}

		/**
		 * Most places the step will offer: bounded by what is left in the queue, and never more
		 * than the ticket itself could ever seat.
		 */
		public static function max_queue_quantity( OsEventModel $event, int $ticket_type_id ): int {
			$tier     = $ticket_type_id ?: null;
			$capacity = self::get_capacity( $event, $tier );

			if ( $capacity ) {
				// What the admin allowed for this queue, less the places already taken in it.
				$most = $capacity - self::get_queued_quantity( (int) $event->id, $tier );
			} else {
				// An unlimited queue is still bounded by how many places the ticket could ever seat.
				$type = $ticket_type_id ? self::find_ticket_type( $event, $ticket_type_id ) : null;
				$most = $type && $type->capacity ? (int) $type->capacity : 10;
			}

			return max( 0, $most );
		}

		/**
		 * How many places the customer asked for. The event step writes the resolved quantity into the
		 * cart item's item_data, including the sum across ticket types.
		 */
		public static function get_selected_quantity(): int {
			$cart_item = OsStepsHelper::$active_cart_item ?? null;
			if ( ! $cart_item ) {
				return 1;
			}

			// The posted item_data is a snapshot from when the field was last rendered, so read the row.
			if ( ! $cart_item->is_new_record() ) {
				$stored = new OsCartItemModel( $cart_item->id );
				if ( $stored->id ) {
					$cart_item = $stored;
				}
			}

			return max( 1, absint( $cart_item->get_item_data_value_by_key( 'quantity', 1 ) ) );
		}

		/**
		 * Nothing was bought, so the event step's cart item must not be left behind or the summary
		 * would keep pricing a registration the customer never made.
		 */
		public static function discard_cart_item( int $event_id, int $cart_item_id = 0 ): void {
			// The step rendered the item's id; resolving "the current cart" is unreliable once the params footer is gone.
			if ( $cart_item_id ) {
				$item = new OsCartItemModel( $cart_item_id );
				if ( $item->id && LATEPOINT_ITEM_VARIANT_EVENT_REGISTRATION === $item->variant ) {
					$item->delete();

					return;
				}
			}

			// Fallback for a caller that did not walk the wizard.
			$cart = OsCartsHelper::get_or_create_cart();
			if ( ! $cart || ! $cart->id ) {
				return;
			}
			foreach ( $cart->get_items() as $item ) {
				if ( LATEPOINT_ITEM_VARIANT_EVENT_REGISTRATION !== $item->variant ) {
					continue;
				}
				$data = json_decode( (string) $item->item_data, true );
				if ( is_array( $data ) && (int) ( $data['event_id'] ?? 0 ) !== $event_id ) {
					continue;
				}
				$cart->remove_item( $item );
			}
		}

		// ─── Joining ────────────────────────────────────────────────────────────

		/**
		 * Creates the queue entry.
		 *
		 * The guards below are the friendly path; correctness rests on the UNIQUE index on active_lock,
		 * so two concurrent submissions cannot both succeed.
		 *
		 * @return OsEventWaitingListModel|WP_Error
		 */
		public static function create_entry( OsEventModel $event, OsCustomerModel $customer, int $quantity = 1, string $source_url = '', ?int $ticket_type_id = null ) {
			if ( ! $customer->id ) {
				return new WP_Error( LATEPOINT_STATUS_ERROR, __( 'We could not identify you, please try again.', 'latepoint-pro-features' ) );
			}

			// Never trust the posted id: it has to be one of this event's own active types.
			$types = self::ticket_types_for( $event );
			if ( $types ) {
				if ( ! $ticket_type_id || ! self::find_ticket_type( $event, $ticket_type_id ) ) {
					return new WP_Error( LATEPOINT_STATUS_ERROR, __( 'Please choose which ticket you would like to wait for.', 'latepoint-pro-features' ) );
				}
			} else {
				$ticket_type_id = null;
			}

			if ( ! self::can_join( $event, $ticket_type_id ) ) {
				return new WP_Error( LATEPOINT_STATUS_ERROR, __( 'The waiting list for this event is not open.', 'latepoint-pro-features' ) );
			}
			$existing = self::find_live_entry( (int) $event->id, (int) $customer->id, $ticket_type_id );
			// Retire a lapsed invitation first: it still owns the active lock, and without this
			// the customer it was sent to could never queue for this ticket again.
			if ( $existing && ! $existing->has_live_invite() && self::expire_invite( $existing ) ) {
				$existing = null;
			}
			if ( $existing ) {
				return new WP_Error( LATEPOINT_STATUS_ERROR, __( 'You are already on the waiting list for this ticket.', 'latepoint-pro-features' ) );
			}

			// The only place an absurd posted quantity can be refused, since the step's capacity check is lifted. Guarded on the column: a tiered event is capped but keeps `capacity` at 0.
			if ( $ticket_type_id ) {
				// The tier's own capacity is the ceiling.
				$type     = self::find_ticket_type( $event, $ticket_type_id );
				$quantity = min( $quantity, max( 1, (int) $type->capacity ) );
			} elseif ( $event->capacity ) {
				$quantity = min( $quantity, (int) $event->capacity );
			}
			$quantity = max( 1, $quantity );
			$capacity = self::get_capacity( $event, $ticket_type_id );
			if ( $capacity && ( self::get_queued_quantity( (int) $event->id, $ticket_type_id ) + $quantity ) > $capacity ) {
				return new WP_Error(
					LATEPOINT_STATUS_ERROR,
					$ticket_type_id
						? __( 'The waiting list for this ticket is full.', 'latepoint-pro-features' )
						: __( 'The waiting list for this event is full.', 'latepoint-pro-features' )
				);
			}

			$entry                 = new OsEventWaitingListModel();
			$entry->event_id       = $event->id;
			$entry->customer_id    = $customer->id;
			$entry->ticket_type_id = $ticket_type_id;
			$entry->quantity       = $quantity;
			$entry->status         = LATEPOINT_EVENT_WAITING_LIST_STATUS_WAITING;
			$entry->source_url     = self::sanitize_source_url( $source_url );

			if ( ! $entry->save() ) {
				// The unique index is the likeliest reason a save fails here: somebody else's
				// request for this customer won the race between the read above and this write.
				if ( self::find_live_entry( (int) $event->id, (int) $customer->id, $ticket_type_id ) ) {
					return new WP_Error( LATEPOINT_STATUS_ERROR, __( 'You are already on the waiting list for this ticket.', 'latepoint-pro-features' ) );
				}
				return self::save_error( $entry );
			}

			self::flush_cache( (int) $event->id );

			/**
			 * Fires once a customer has been added to an event's waiting list.
			 *
			 * @param {OsEventWaitingListModel} $entry The queue entry.
			 *
			 * @since 1.7.3
			 * @hook latepoint_event_waiting_list_joined
			 */
			do_action( 'latepoint_event_waiting_list_joined', $entry );
			self::fire_process_event( 'event_waiting_list_joined', $entry );

			return $entry;
		}

		/**
		 * Only ever trust a same-origin URL here. The value originates from the visitor's own
		 * Referer header, and it is later used as the base of the invitation link that gets mailed
		 * out - an off-site value would hand the invitation token to somebody else's domain.
		 */
		private static function sanitize_source_url( string $url ): string {
			$url = trim( $url );
			if ( ! $url ) {
				return '';
			}
			$url  = esc_url_raw( $url );
			$host = wp_parse_url( $url, PHP_URL_HOST );
			$home = wp_parse_url( home_url(), PHP_URL_HOST );
			if ( ! $host || ! $home || strtolower( $host ) !== strtolower( $home ) ) {
				return '';
			}

			return $url;
		}

		// ─── Invitation and promotion ───────────────────────────────────────────

		/**
		 * Offers the place to a queued customer. For a paid event this is the whole of the
		 * organizer's job: the customer follows the link and pays through the normal checkout.
		 *
		 * @return true|WP_Error
		 */
		public static function invite( OsEventWaitingListModel $entry ) {
			if ( ! $entry->id || ! $entry->is_live() ) {
				return new WP_Error( LATEPOINT_STATUS_ERROR, __( 'This waiting list entry is no longer active.', 'latepoint-pro-features' ) );
			}

			$event = $entry->get_event();
			if ( ! $event || ! $event->id ) {
				return new WP_Error( LATEPOINT_STATUS_ERROR, __( 'Event not found.', 'latepoint-pro-features' ) );
			}

			// The admin check only disables a button. Refusing here is what stops a dead link being emailed.
			$blocked = self::get_offer_block_reason( $entry, $event );
			if ( $blocked ) {
				return new WP_Error( LATEPOINT_STATUS_ERROR, $blocked );
			}

			$token                    = wp_generate_password( 32, false, false );
			$entry->status            = LATEPOINT_EVENT_WAITING_LIST_STATUS_INVITED;
			$entry->invite_token_hash = self::hash_token( $token );
			$entry->invited_at        = current_time( 'mysql', true );
			$entry->invite_expires_at = gmdate( 'Y-m-d H:i:s', self::invite_expiry_stamp( $event ) );

			if ( ! $entry->save() ) {
				return self::save_error( $entry );
			}

			self::flush_cache( (int) $entry->event_id );

			// The plaintext token exists only for the duration of this request, long enough to be
			// rendered into the outgoing email. Only its hash is ever stored.
			self::$plaintext_tokens[ (int) $entry->id ] = $token;

			self::debug_log(
				'invitation issued',
				[
					'entry_id'       => (int) $entry->id,
					'event_id'       => (int) $entry->event_id,
					'ticket_type_id' => $entry->ticket_type_id ? (int) $entry->ticket_type_id : null,
					'customer_id'    => (int) $entry->customer_id,
					'places'         => (int) $entry->quantity,
					'expires_at'     => (string) $entry->invite_expires_at,
				]
			);

			do_action( 'latepoint_event_waiting_list_invited', $entry );
			self::fire_process_event( 'event_waiting_list_invited', $entry );

			unset( self::$plaintext_tokens[ (int) $entry->id ] );

			return true;
		}

		/**
		 * Gives the place directly. Free events only; a paid one goes through checkout via invite().
		 * Creates a real registration and fires latepoint_event_registration_created, so e-tickets and
		 * every other listener behave as for an ordinary attendee.
		 *
		 * @return OsEventRegistrationModel|WP_Error
		 */
		public static function promote( OsEventWaitingListModel $entry ) {
			if ( ! $entry->id || ! $entry->is_live() ) {
				return new WP_Error( LATEPOINT_STATUS_ERROR, __( 'This waiting list entry is no longer active.', 'latepoint-pro-features' ) );
			}
			$event = $entry->get_event();
			if ( ! $event || ! $event->id ) {
				return new WP_Error( LATEPOINT_STATUS_ERROR, __( 'Event not found.', 'latepoint-pro-features' ) );
			}
			if ( self::is_paid_for_entry( $entry, $event ) ) {
				return new WP_Error( LATEPOINT_STATUS_ERROR, __( 'This place is paid, so the customer has to be invited to check out rather than given a place directly.', 'latepoint-pro-features' ) );
			}

			// promote() writes a confirmed registration straight away, so without this it is the
			// one path that can put an event over its own capacity.
			$blocked = self::get_offer_block_reason( $entry, $event );
			if ( $blocked ) {
				return new WP_Error( LATEPOINT_STATUS_ERROR, $blocked );
			}

			$registration                 = new OsEventRegistrationModel();
			$registration->event_id       = $entry->event_id;
			$registration->customer_id    = $entry->customer_id;
			$registration->quantity       = $entry->quantity;
			$registration->status         = LATEPOINT_EVENT_REGISTRATION_STATUS_CONFIRMED;
			$registration->payment_status = LATEPOINT_ORDER_PAYMENT_STATUS_NOT_PAID;

			if ( ! $registration->save() ) {
				return self::save_error( $registration );
			}

			// Before the action below, because e-tickets and the type's own booked count both read
			// this row while handling it.
			self::record_ticket_type_for_registration( $entry, $registration );

			// E-tickets, ticket types and core's own workflow all hang off this action.
			do_action( 'latepoint_event_registration_created', $registration );

			self::mark_converted( $entry, $registration );

			return $registration;
		}

		/**
		 * Takes an entry off the queue. Has its own action deliberately: routing it through core's
		 * registration cancel route would fire latepoint_event_registration_cancelled and email a
		 * "your registration has been cancelled" notice to somebody who never held one.
		 *
		 * @return true|WP_Error
		 */
		public static function remove( OsEventWaitingListModel $entry ) {
			if ( ! $entry->id ) {
				return new WP_Error( LATEPOINT_STATUS_ERROR, __( 'Waiting list entry not found.', 'latepoint-pro-features' ) );
			}
			if ( ! $entry->is_live() ) {
				return true;
			}

			$entry->status            = LATEPOINT_EVENT_WAITING_LIST_STATUS_REMOVED;
			$entry->invite_token_hash = null;
			$entry->invite_expires_at = null;

			if ( ! $entry->save() ) {
				return self::save_error( $entry );
			}

			self::flush_cache( (int) $entry->event_id );
			do_action( 'latepoint_event_waiting_list_removed', $entry );

			return true;
		}

		/**
		 * The place was taken. Recorded distinctly from a removal so a success is never reported
		 * as a cancellation, and the invitation is retired at the same moment.
		 */
		private static function mark_converted( OsEventWaitingListModel $entry, OsEventRegistrationModel $registration ): void {
			$entry->status                    = LATEPOINT_EVENT_WAITING_LIST_STATUS_CONVERTED;
			$entry->converted_registration_id = $registration->id;
			$entry->converted_order_id        = $registration->order_id ? $registration->order_id : null;
			$entry->invite_token_hash         = null;
			$entry->invite_expires_at         = null;
			$entry->save();

			self::flush_cache( (int) $entry->event_id );

			do_action( 'latepoint_event_waiting_list_converted', $entry, $registration );
			self::fire_process_event( 'event_waiting_list_converted', $entry );
		}

		/**
		 * Closes the loop when a registration appears for somebody who was queuing. Keyed off the
		 * registration, not request state: gateways create it from a webhook or redirect where no
		 * presets exist, which would leave a live entry pinning the event Full for ever.
		 */
		public static function convert_entry_for_registration( OsEventRegistrationModel $registration ): void {
			if ( ! $registration->id || ! $registration->event_id || ! $registration->customer_id ) {
				return;
			}
			if ( LATEPOINT_EVENT_REGISTRATION_STATUS_CANCELLED === $registration->status ) {
				return;
			}
			// Ticket Types writes these at priority 5, this runs at 20. Closing by customer alone would retire the wrong tier's entry.
			$bought = self::purchased_ticket_type_ids( $registration );

			if ( $bought ) {
				foreach ( $bought as $ticket_type_id ) {
					$entry = self::find_live_entry( (int) $registration->event_id, (int) $registration->customer_id, $ticket_type_id );
					if ( $entry ) {
						self::mark_converted( $entry, $registration );
					}
				}

				return;
			}

			$entry = self::find_live_entry( (int) $registration->event_id, (int) $registration->customer_id );
			if ( ! $entry ) {
				return;
			}

			self::mark_converted( $entry, $registration );
		}

		/** Ticket type ids on a registration, or [] on a flat event. */
		private static function purchased_ticket_type_ids( OsEventRegistrationModel $registration ): array {
			if ( ! class_exists( 'OsFeatureEventTicketTypesHelper' ) ) {
				return [];
			}
			$ids = [];
			foreach ( OsFeatureEventTicketTypesHelper::get_types_for_registration( (int) $registration->id ) as $row ) {
				if ( $row->ticket_type_id ) {
					$ids[] = (int) $row->ticket_type_id;
				}
			}

			return $ids;
		}

		/**
		 * Record which ticket a promoted customer was given.
		 *
		 * A promotion has no order behind it, so Ticket Types' own listener - which reads the order
		 * item - never fires. Without this row the ticket type's booked count would never see the
		 * promoted attendee and would keep selling their seat to somebody else.
		 */
		private static function record_ticket_type_for_registration( OsEventWaitingListModel $entry, OsEventRegistrationModel $registration ): void {
			$type = $entry->get_ticket_type();
			if ( ! $type || ! class_exists( 'OsEventRegistrationTicketTypeModel' ) ) {
				return;
			}

			$row = new OsEventRegistrationTicketTypeModel();
			$row->set_data(
				[
					'registration_id' => $registration->id,
					'ticket_type_id'  => (int) $type->id,
					'name'            => $type->name,
					'quantity'        => max( 1, (int) $entry->quantity ),
					'price'           => $type->price,
				]
			);
			$row->save();
		}

		public static function delete_queue_for_event( $event ): void {
			$event_id = ( $event instanceof OsEventModel ) ? (int) $event->id : (int) $event;
			if ( ! $event_id ) {
				return;
			}
			global $wpdb;
			$wpdb->delete( LATEPOINT_TABLE_EVENT_WAITING_LIST, [ 'event_id' => $event_id ], [ '%d' ] );
			self::flush_cache( $event_id );
		}

		// ─── Invitation tokens ──────────────────────────────────────────────────

		/**
		 * The queue table only ever stores a hash, so a leaked row cannot be turned back into a link.
		 * Note that core's OsEmailHelper::log_email() records every email body in the activities table
		 * ungated, so the plaintext link lands there too. That belongs to core, not here.
		 */
		private static function hash_token( string $token ): string {
			return hash_hmac( 'sha256', $token, wp_salt( 'auth' ) );
		}

		/**
		 * The claim link for an entry. Returns '' unless an invitation was actually issued in this
		 * request. A token is never re-derivable from storage, so a "join confirmation" email can
		 * never accidentally hand somebody a queue-skipping link.
		 */
		public static function get_claim_url( OsEventWaitingListModel $entry ): string {
			$token = self::$plaintext_tokens[ (int) $entry->id ] ?? '';
			if ( ! $token ) {
				return '';
			}
			$base = $entry->source_url ? $entry->source_url : home_url( '/' );

			return add_query_arg( self::CLAIM_PARAM, rawurlencode( $token ), $base );
		}

		/**
		 * Resolves a submitted token to its entry. Rejects anything expired or no longer live, so
		 * a link cannot be replayed after the window closes.
		 *
		 * $reason is filled with a customer-facing explanation whenever a token is refused, so the
		 * claim link can say what happened instead of silently doing nothing.
		 */
		private static function resolve_claim_token( string $token, ?string &$reason = null ): ?OsEventWaitingListModel {
			$reason = null;
			if ( ! $token ) {
				return null;
			}
			$found = ( new OsEventWaitingListModel() )
				->where( [ 'invite_token_hash' => self::hash_token( $token ) ] )
				->set_limit( 1 )
				->get_results_as_models();

			if ( ! ( $found instanceof OsEventWaitingListModel ) || ! $found->id ) {
				// Also the shape a claimed or cancelled invitation takes: both clear the hash.
				$reason = __( 'This invitation link is no longer valid. It may already have been used, or the invitation may have been withdrawn.', 'latepoint-pro-features' );

				return null;
			}

			if ( ! $found->has_live_invite() ) {
				self::expire_invite( $found );
				$reason = __( 'This invitation has expired and the place has been offered to someone else.', 'latepoint-pro-features' );

				return null;
			}

			// The stored deadline is not recalculated when an event moves earlier, so the live window decides.
			$event = $found->get_event();
			if ( ! $event || ! $event->id ) {
				$reason = __( 'The event this invitation was for is no longer available.', 'latepoint-pro-features' );

				return null;
			}
			if ( ! self::is_registration_window_open( $event ) ) {
				self::expire_invite( $found );
				$reason = __( 'Registration for this event has closed, so this invitation can no longer be used.', 'latepoint-pro-features' );

				return null;
			}

			// The seat can go after the invitation is sent, so say so rather than silently offering the queue again.
			$offerable = self::get_offerable_seats( $found, $event );
			if ( null === $offerable || $offerable >= 1 ) {
				return $found;
			}

			$reason = __( 'The place held for you is no longer available. Please contact us and we will help.', 'latepoint-pro-features' );

			return null;
		}

		/**
		 * Reads an invitation token off the claim link (or off the presets it was folded into on a
		 * previous step) and points the wizard at the event it belongs to.
		 */
		public static function capture_claim_token( array $presets, array $raw_presets ): array {
			if ( ! self::is_enabled() ) {
				return $presets;
			}

			// Waiting list mode is requested by the Join button and then carried on every step.
			if ( ! empty( $raw_presets[ self::INTENT_PRESET ] ) && OsUtilHelper::is_on( $raw_presets[ self::INTENT_PRESET ] ) ) {
				$presets[ self::INTENT_PRESET ] = LATEPOINT_VALUE_ON;
			}

			// Which ticket the Join button was clicked for. Validated against the event's own types
			// in create_entry(), so an edited value cannot queue for somebody else's ticket.
			$posted_type = absint( $raw_presets[ self::TICKET_TYPE_PRESET ] ?? 0 );
			if ( $posted_type ) {
				$presets[ self::TICKET_TYPE_PRESET ] = $posted_type;
			}

			$token = (string) ( $raw_presets[ self::CLAIM_PARAM ] ?? $raw_presets['url_params'][ self::CLAIM_PARAM ] ?? '' );
			if ( ! $token ) {
				return $presets;
			}

			$entry = self::resolve_claim_token( $token, $reason );
			if ( ! $entry ) {
				self::$claim_error = (string) $reason;

				return $presets;
			}

			self::$claimed_entry_id  = (int) $entry->id;
			self::$claim_lookup_done = true;

			$presets[ self::CLAIM_PARAM ] = $token;
			$presets['selected_event_id'] = (int) $entry->event_id;
			$presets['booking_intent']    = 'event';
			// Bound the checkout to what was actually queued for, so an invitation for one place
			// cannot be spent on five.
			$presets['selected_total_attendees'] = (int) $entry->quantity;

			return $presets;
		}

		/**
		 * Whether this request is the invited customer coming to take their place. Only they are
		 * exempt from the "stay Full while a queue waits" rule.
		 */
		public static function is_claiming_for_event( OsEventModel $event ): bool {
			$entry = self::claimed_entry();

			return $entry && (int) $event->id && (int) $entry->event_id === (int) $event->id;
		}

		/** The entry this request is claiming with a live invitation, resolved and loaded once. */
		private static function claimed_entry(): ?OsEventWaitingListModel {
			self::resolve_claim_from_request();
			$id = (int) self::$claimed_entry_id;
			if ( ! $id ) {
				return null;
			}
			// Keyed by id rather than one slot, so the memo cannot answer for a different entry.
			if ( ! array_key_exists( $id, self::$claimed_entries ) ) {
				$entry                        = new OsEventWaitingListModel( $id );
				self::$claimed_entries[ $id ] = $entry->id ? $entry : null;
			}

			return self::$claimed_entries[ $id ];
		}

		/**
		 * Reads the invitation token off the query string. Following a claim link is an ordinary page
		 * load, so capture_claim_token() has not run yet. The token is the credential: 32 random
		 * characters, stored hashed, scoped to one entry and expiring.
		 */
		public static function resolve_claim_from_request(): void {
			if ( self::$claim_lookup_done ) {
				return;
			}
			self::$claim_lookup_done = true;
			if ( self::$claimed_entry_id ) {
				return;
			}

			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- the single-use token IS the credential.
			$token = isset( $_GET[ self::CLAIM_PARAM ] ) ? sanitize_text_field( wp_unslash( $_GET[ self::CLAIM_PARAM ] ) ) : '';
			if ( ! $token ) {
				return;
			}

			$entry = self::resolve_claim_token( $token, $reason );
			if ( $entry ) {
				self::$claimed_entry_id = (int) $entry->id;

				return;
			}
			self::$claim_error = (string) $reason;
		}

		/**
		 * The explanation for a claim link that could not be used on this request, or ''.
		 */
		public static function get_claim_error(): string {
			self::resolve_claim_from_request();

			return self::$claim_error;
		}

		/**
		 * The event a valid claim link on this request is for, or 0.
		 */
		public static function get_claimed_event_id(): int {
			$entry = self::claimed_entry();

			return $entry ? (int) $entry->event_id : 0;
		}

		/** A failed save, as the WP_Error a controller can show. get_error_messages() always returns an array. */
		private static function save_error( OsModel $model ): WP_Error {
			return new WP_Error( LATEPOINT_STATUS_ERROR, implode( ', ', $model->get_error_messages() ) );
		}

		/**
		 * Retires one invitation nobody claimed, releasing its active lock and its token.
		 *
		 * The places it held are already free, because the hold reads invite_expires_at rather
		 * than the status. What still needs the write is the lock, which is stored at save time
		 * and would otherwise keep the customer out of the queue for good.
		 */
		private static function expire_invite( OsEventWaitingListModel $entry ): bool {
			if ( ! $entry->id || ! $entry->is_invited() ) {
				return false;
			}

			$entry->status            = LATEPOINT_EVENT_WAITING_LIST_STATUS_EXPIRED;
			$entry->invite_token_hash = null;
			$entry->save();
			self::flush_cache( (int) $entry->event_id );
			self::debug_log( 'retired an unclaimed invitation', [ 'entry_id' => (int) $entry->id ] );
			do_action( 'latepoint_event_waiting_list_invite_expired', $entry );

			return true;
		}

		// ─── Notifications ──────────────────────────────────────────────────────

		private static function process_event_types(): array {
			return [ 'event_waiting_list_joined', 'event_waiting_list_invited', 'event_waiting_list_converted' ];
		}

		private static function fire_process_event( string $event_type, OsEventWaitingListModel $entry ): void {
			if ( ! class_exists( 'OsProcessJobsHelper' ) ) {
				return;
			}
			$objects = [
				[
					'model'       => 'event_waiting_list_entry',
					'id'          => $entry->id,
					'model_ready' => $entry,
				],
			];
			OsProcessJobsHelper::create_jobs_for_event( $event_type, $objects );
		}

		public static function add_process_event_types( array $types ): array {
			return array_merge( $types, self::process_event_types() );
		}

		public static function add_process_event_names( array $names ): array {
			$names['event_waiting_list_joined']    = __( 'Event Waiting List Joined', 'latepoint-pro-features' );
			$names['event_waiting_list_invited']   = __( 'Event Waiting List Invitation Sent', 'latepoint-pro-features' );
			$names['event_waiting_list_converted'] = __( 'Event Waiting List Place Taken', 'latepoint-pro-features' );

			return $names;
		}

		public static function set_object_model_type_for_process( ?string $object_model_type, OsProcessModel $process, array $objects ): ?string {
			if ( in_array( $process->event_type, self::process_event_types(), true ) ) {
				return 'event_waiting_list_entry';
			}

			return $object_model_type;
		}

		/**
		 * The moment the announced thing happened, not when the entry was created. A job whose event
		 * time cannot be resolved, or is over five minutes old, is dropped silently by
		 * OsProcessJobsHelper, which threw invitation emails away with no job and no log line.
		 */
		public static function set_event_time_utc_for_process( ?OsWpDateTime $event_time_utc, OsProcessModel $process, array $objects ): ?OsWpDateTime {
			if ( ! in_array( $process->event_type, self::process_event_types(), true ) ) {
				return $event_time_utc;
			}
			$entry = $objects[0]['model_ready'] ?? null;
			if ( ! ( $entry instanceof OsEventWaitingListModel ) && ! empty( $objects[0]['id'] ) ) {
				$entry = new OsEventWaitingListModel( $objects[0]['id'] );
			}

			$stamp = '';
			if ( $entry instanceof OsEventWaitingListModel ) {
				switch ( $process->event_type ) {
					case 'event_waiting_list_invited':
						$stamp = (string) $entry->invited_at;
						break;
					case 'event_waiting_list_converted':
						// There is no converted_at column; mark_converted() saves the entry at that
						// moment, so updated_at is exactly it.
						$stamp = (string) $entry->updated_at;
						break;
					default:
						$stamp = (string) $entry->created_at;
				}
			}
			if ( ! $stamp ) {
				$stamp = current_time( 'mysql', true );
			}

			return new OsWpDateTime( $stamp, new DateTimeZone( 'UTC' ) );
		}

		/**
		 * Publishes the entry, and the customer and host behind it, so the standard
		 * {{customer_*}} / {{agent_*}} tags resolve in a waiting-list email. Core's own event
		 * pipeline only knows how to do this for an event registration.
		 */
		public static function prepare_replacement_vars( array $vars, array $data_objects ): array {
			foreach ( $data_objects as $data_object ) {
				if ( 'event_waiting_list_entry' !== ( $data_object['model'] ?? '' ) ) {
					continue;
				}
				$entry = $data_object['model_ready'] ?? new OsEventWaitingListModel( $data_object['id'] ?? 0 );
				if ( ! ( $entry instanceof OsEventWaitingListModel ) || ! $entry->id ) {
					continue;
				}
				$vars['event_waiting_list_entry'] = $entry;
				if ( empty( $vars['customer'] ) ) {
					$vars['customer'] = $entry->get_customer();
				}
				$event = $entry->get_event();
				if ( empty( $vars['agent'] ) && $event && $event->agent_id ) {
					$agent = new OsAgentModel( $event->agent_id );
					if ( $agent->id ) {
						$vars['agent'] = $agent;
					}
				}
			}

			return $vars;
		}

		public static function replace_vars_in_template( string $text, array $vars, string $original_text ): string {
			if ( empty( $vars['event_waiting_list_entry'] ) ) {
				return $text;
			}
			$entry = $vars['event_waiting_list_entry'];
			$event = $entry->get_event();

			// A queue entry is not a registration, so core's event tags do not resolve for it.
			$registration = $entry->get_registration();

			$needles      = [
				'{{waiting_list_position}}',
				'{{waiting_list_capacity}}',
				'{{waiting_list_quantity}}',
				'{{waiting_list_claim_url}}',
				'{{waiting_list_expires_at}}',
				'{{event_name}}',
				'{{event_start_date}}',
				'{{event_start_time}}',
				'{{event_location_name}}',
				'{{registration_code}}',
			];
			$replacements = [
				(string) self::get_position( $entry ),
				$event ? (string) self::get_capacity( $event, $entry->ticket_type_id ? (int) $entry->ticket_type_id : null ) : '',
				(string) (int) $entry->quantity,
				esc_url( self::get_claim_url( $entry ) ),
				esc_html( self::get_formatted_invite_deadline( $entry ) ),
				$event ? esc_html( $event->name ) : '',
				$event ? $event->get_formatted_start_date() : '',
				$event ? $event->get_formatted_start_time() : '',
				$event ? esc_html( $event->get_display_location_name() ) : '',
				$registration ? esc_html( (string) $registration->registration_code ) : '',
			];

			return str_replace( $needles, $replacements, $text );
		}

		public static function output_available_vars(): void {
			?>
			<li><span class="var-label"><?php esc_html_e( 'Waiting List Position', 'latepoint-pro-features' ); ?></span> <span class="var-code os-click-to-copy">{{waiting_list_position}}</span></li>
			<li><span class="var-label"><?php esc_html_e( 'Waiting List Capacity', 'latepoint-pro-features' ); ?></span> <span class="var-code os-click-to-copy">{{waiting_list_capacity}}</span></li>
			<li><span class="var-label"><?php esc_html_e( 'Places Requested', 'latepoint-pro-features' ); ?></span> <span class="var-code os-click-to-copy">{{waiting_list_quantity}}</span></li>
			<li><span class="var-label"><?php esc_html_e( 'Waiting List Invitation URL', 'latepoint-pro-features' ); ?></span> <span class="var-code os-click-to-copy">{{waiting_list_claim_url}}</span></li>
			<li><span class="var-label"><?php esc_html_e( 'Invitation Expires', 'latepoint-pro-features' ); ?></span> <span class="var-code os-click-to-copy">{{waiting_list_expires_at}}</span></li>
			<?php
		}

		public static function add_templates( array $templates, string $action_type, $wp_filesystem ): array {
			if ( 'send_email' !== $action_type ) {
				return $templates;
			}
			$defs = [
				[ 'event_waiting_list_joined__to_customer', 'customer', __( 'Event Waiting List Confirmation', 'latepoint-pro-features' ), '{{customer_full_name}} <{{customer_email}}>', __( 'You are on the waiting list', 'latepoint-pro-features' ), 'customer/event_waitlist_joined.html' ],
				[ 'event_waiting_list_joined__to_admin', 'agent', __( 'Event Waiting List - Notify Organizer', 'latepoint-pro-features' ), get_option( 'admin_email' ), __( 'Somebody joined an event waiting list', 'latepoint-pro-features' ), 'agent/event_waitlist_joined.html' ],
				[ 'event_waiting_list_invited__to_customer', 'customer', __( 'Event Waiting List Invitation', 'latepoint-pro-features' ), '{{customer_full_name}} <{{customer_email}}>', __( 'A place has opened up', 'latepoint-pro-features' ), 'customer/event_waitlist_invited.html' ],
				[ 'event_waiting_list_converted__to_customer', 'customer', __( 'Event Waiting List Place Confirmed', 'latepoint-pro-features' ), '{{customer_full_name}} <{{customer_email}}>', __( 'You have a place at the event', 'latepoint-pro-features' ), 'customer/event_waitlist_promoted.html' ],
			];
			foreach ( $defs as $d ) {
				$content = $wp_filesystem->get_contents( LATEPOINT_ADDON_PRO_VIEWS_ABSPATH . 'mailers/' . $d[5] );
				if ( false === $content ) {
					continue;
				}
				$templates[] = [
					'id'           => $d[0],
					'to_user_type' => $d[1],
					'name'         => $d[2],
					'to_email'     => $d[3],
					'subject'      => $d[4],
					'content'      => OsEmailHelper::get_email_layout( $content ),
				];
			}

			return $templates;
		}

		/**
		 * OsDatabaseHelper::seed_initial_data() only runs on a fresh install, so the default
		 * workflows are created the first time the feature is switched on instead.
		 */
		public static function maybe_seed_default_workflows(): void {
			if ( ! self::is_enabled() || OsSettingsHelper::is_on( 'event_waiting_list_workflows_seeded' ) ) {
				return;
			}

			require_once ABSPATH . 'wp-admin/includes/file.php';
			if ( ! WP_Filesystem() ) {
				OsDebugHelper::log( 'Could not initialise WP_Filesystem while seeding event waiting list workflows.', 'event_waiting_list' );

				return;
			}
			global $wp_filesystem;

			// One process per trigger, the shape core uses for booking_created (database_helper.php:116-140).
			$definitions = [
				[
					'event_type' => 'event_waiting_list_joined',
					'name'       => __( 'Event Waiting List Confirmation', 'latepoint-pro-features' ),
					'emails'     => [
						[
							'to_email' => '{{customer_full_name}} <{{customer_email}}>',
							'subject'  => __( 'You are on the waiting list', 'latepoint-pro-features' ),
							'template' => 'customer/event_waitlist_joined.html',
						],
						// Addressed to the site admin because an event need not have a host; swap for {{agent_email}} to notify the host.
						[
							'to_email' => get_option( 'admin_email' ),
							'subject'  => __( 'Somebody joined an event waiting list', 'latepoint-pro-features' ),
							'template' => 'agent/event_waitlist_joined.html',
						],
					],
				],
				[
					'event_type' => 'event_waiting_list_invited',
					'name'       => __( 'Event Waiting List Invitation', 'latepoint-pro-features' ),
					'emails'     => [
						[
							'to_email' => '{{customer_full_name}} <{{customer_email}}>',
							'subject'  => __( 'A place has opened up', 'latepoint-pro-features' ),
							'template' => 'customer/event_waitlist_invited.html',
						],
					],
				],
				[
					'event_type' => 'event_waiting_list_converted',
					'name'       => __( 'Event Waiting List Place Confirmed', 'latepoint-pro-features' ),
					'emails'     => [
						[
							'to_email' => '{{customer_full_name}} <{{customer_email}}>',
							'subject'  => __( 'You have a place at the event', 'latepoint-pro-features' ),
							'template' => 'customer/event_waitlist_promoted.html',
						],
					],
				],
			];

			// Every definition has to end up with a process, or this runs again next save. One
			// readable template is not enough: that would mark the site seeded and leave the
			// trigger whose template failed with no workflow, for good.
			$all_present = true;
			foreach ( $definitions as $definition ) {
				$process             = new OsProcessModel();
				$process->event_type = $definition['event_type'];
				$process->name       = $definition['name'];

				if ( OsProcessesHelper::check_if_process_exists( $process ) ) {
					continue;
				}

				$actions = [];
				foreach ( $definition['emails'] as $email ) {
					$content = $wp_filesystem->get_contents( LATEPOINT_ADDON_PRO_VIEWS_ABSPATH . 'mailers/' . $email['template'] );
					if ( false === $content ) {
						// Otherwise the feature silently ships with no notifications at all.
						OsDebugHelper::log( 'Could not read event waiting list email template: ' . $email['template'], 'event_waiting_list' );
						continue;
					}

					$action                         = [];
					$action['type']                 = 'send_email';
					$action['settings']['to_email'] = $email['to_email'];
					$action['settings']['subject']  = $email['subject'];
					$action['settings']['content']  = OsEmailHelper::get_email_layout( $content );

					$actions[ \LatePoint\Misc\ProcessAction::generate_id() ] = $action;
				}

				if ( count( $actions ) !== count( $definition['emails'] ) ) {
					$all_present = false;
					continue;
				}

				$process_actions                   = OsProcessesHelper::iterate_trigger_conditions( [], $actions );
				$process_actions[0]['time_offset'] = [];
				$process->actions_json             = wp_json_encode( $process_actions );
				$process->save();
			}

			if ( $all_present ) {
				OsSettingsHelper::save_setting_by_name( 'event_waiting_list_workflows_seeded', 'on' );
			}
		}
	}

endif;
