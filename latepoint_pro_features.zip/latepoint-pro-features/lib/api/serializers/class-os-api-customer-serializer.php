<?php
/**
 * Customer serializer — the public REST representation of OsCustomerModel.
 *
 * @package LatePoint\Api
 * @since   5.4.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class OsApiCustomerSerializer extends OsApiSerializer {

	/**
	 * @param OsCustomerModel $model
	 * @param string          $context
	 * @return array
	 */
	public function to_array( $model, string $context = self::CONTEXT_VIEW ): array {
		// Matches the booking serializer's embed_customer() shape, so a customer looks the
		// same whether it's embedded inside a booking response or fetched directly with
		// ?context=embed.
		if ( $context === self::CONTEXT_EMBED ) {
			return [
				'id'         => (int) $model->id,
				'first_name' => (string) $model->first_name,
				'last_name'  => (string) $model->last_name,
				'email'      => (string) $model->email,
				'phone'      => (string) $model->phone,
			];
		}

		$data = [
			'id'         => (int) $model->id,
			'first_name' => (string) $model->first_name,
			'last_name'  => (string) $model->last_name,
			'email'      => (string) $model->email,
			'phone'      => (string) $model->phone,
			'status'     => (string) $model->status,
			'is_guest'   => (bool) $model->is_guest,
			'created_at' => $this->to_rfc3339( $model->created_at ),
			'updated_at' => $this->to_rfc3339( $model->updated_at ),
		];

		if ( $context === self::CONTEXT_EDIT ) {
			$data['notes']             = (string) $model->notes;
			$data['admin_notes']       = (string) $model->admin_notes;
			$data['wordpress_user_id'] = $model->wordpress_user_id ? (int) $model->wordpress_user_id : null;
		}

		if ( $context !== self::CONTEXT_AI ) {
			$data['_links'] = [
				'self'       => [ [ 'href' => rest_url( 'latepoint/v1/customers/' . $model->id ) ] ],
				'collection' => [ [ 'href' => rest_url( 'latepoint/v1/customers' ) ] ],
			];
		}

		return $data;
	}

	public function schema(): array {
		return [
			'title'      => 'customer',
			'type'       => 'object',
			'properties' => [
				'id'         => [
					'type'     => 'integer',
					'readonly' => true,
				],
				'first_name' => [ 'type' => 'string' ],
				'last_name'  => [ 'type' => 'string' ],
				'email'      => [
					'type'   => 'string',
					'format' => 'email',
				],
				'phone'      => [ 'type' => 'string' ],
				'status'     => [ 'type' => 'string' ],
				'is_guest'   => [ 'type' => 'boolean' ],
				'created_at' => [
					'type'     => 'string',
					'format'   => 'date-time',
					'readonly' => true,
				],
				'updated_at' => [
					'type'     => 'string',
					'format'   => 'date-time',
					'readonly' => true,
				],
			],
		];
	}
}
