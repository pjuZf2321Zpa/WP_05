<?php
/**
 * Transaction serializer — the public REST representation of OsTransactionModel, exposed
 * under the "payments" resource name (matching the admin nav label "Payments" and the
 * wplimit competitor's naming — same REST-base-vs-model-name pattern as orders/OsOrderModel).
 *
 * @package LatePoint\Api
 * @since   5.4.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class OsApiTransactionSerializer extends OsApiSerializer {

	/** @var array<int,OsCustomerModel> */
	private $customers = [];

	public function prime( array $models ): void {
		$customer_ids = [];
		foreach ( $models as $transaction ) {
			if ( $transaction->customer_id ) {
				$customer_ids[] = (int) $transaction->customer_id;
			}
		}

		$this->customers = $this->index_by_id( 'OsCustomerModel', $customer_ids );
	}

	/**
	 * @param OsTransactionModel $model
	 * @param string             $context
	 * @return array
	 */
	public function to_array( $model, string $context = self::CONTEXT_VIEW ): array {
		if ( $context === self::CONTEXT_EMBED ) {
			return [
				'id'       => (int) $model->id,
				'order_id' => $model->order_id ? (int) $model->order_id : null,
				'amount'   => (string) $model->amount,
				'status'   => (string) $model->status,
			];
		}

		$data = [
			'id'              => (int) $model->id,
			'order_id'        => $model->order_id ? (int) $model->order_id : null,
			'customer_id'     => $model->customer_id ? (int) $model->customer_id : null,
			'processor'       => (string) $model->processor,
			'payment_method'  => (string) $model->payment_method,
			'kind'            => (string) $model->kind,
			'amount'          => (string) $model->amount,
			'status'          => (string) $model->status,
			'refunded_amount' => (string) $model->get_total_refunded_amount(),
			'can_refund'      => (bool) $model->can_refund(),
			'notes'           => (string) $model->notes,
			'created_at'      => $this->to_rfc3339( $model->created_at ),
			'updated_at'      => $this->to_rfc3339( $model->updated_at ),
		];

		if ( $context !== self::CONTEXT_AI ) {
			$data['customer'] = $this->embed_customer( (int) $model->customer_id );
			$data['_links']   = $this->links( $model );
		}

		return $data;
	}

	private function embed_customer( int $id ): ?array {
		$customer = $this->customers[ $id ] ?? null;
		if ( ! $customer ) {
			return null;
		}

		return [
			'id'         => (int) $customer->id,
			'first_name' => (string) $customer->first_name,
			'last_name'  => (string) $customer->last_name,
			'email'      => (string) $customer->email,
		];
	}

	private function links( OsTransactionModel $model ): array {
		$links = [
			'self'       => [ [ 'href' => rest_url( 'latepoint/v1/payments/' . $model->id ) ] ],
			'collection' => [ [ 'href' => rest_url( 'latepoint/v1/payments' ) ] ],
		];
		if ( $model->order_id ) {
			$links['order'] = [ [ 'href' => rest_url( 'latepoint/v1/orders/' . $model->order_id ) ] ];
		}
		if ( $model->customer_id ) {
			$links['customer'] = [ [ 'href' => rest_url( 'latepoint/v1/customers/' . $model->customer_id ) ] ];
		}

		return $links;
	}

	public function schema(): array {
		return [
			'title'      => 'payment',
			'type'       => 'object',
			'properties' => [
				'id'              => [
					'type'     => 'integer',
					'readonly' => true,
				],
				'order_id'        => [ 'type' => [ 'integer', 'null' ] ],
				'customer_id'     => [ 'type' => [ 'integer', 'null' ] ],
				'processor'       => [ 'type' => 'string' ],
				'payment_method'  => [ 'type' => 'string' ],
				'kind'            => [ 'type' => 'string' ],
				'amount'          => [ 'type' => 'string' ],
				'status'          => [ 'type' => 'string' ],
				'refunded_amount' => [
					'type'     => 'string',
					'readonly' => true,
				],
				'can_refund'      => [
					'type'     => 'boolean',
					'readonly' => true,
				],
				'notes'           => [ 'type' => 'string' ],
				'created_at'      => [
					'type'     => 'string',
					'format'   => 'date-time',
					'readonly' => true,
				],
				'updated_at'      => [
					'type'     => 'string',
					'format'   => 'date-time',
					'readonly' => true,
				],
			],
		];
	}
}
