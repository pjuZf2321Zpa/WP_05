<?php
/**
 * Service category serializer — the public REST representation of OsServiceCategoryModel.
 *
 * @package LatePoint\Api
 * @since   5.4.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class OsApiServiceCategorySerializer extends OsApiSerializer {

	/**
	 * @param OsServiceCategoryModel $model
	 * @param string                 $context
	 * @return array
	 */
	public function to_array( $model, string $context = self::CONTEXT_VIEW ): array {
		if ( $context === self::CONTEXT_EMBED ) {
			return [
				'id'   => (int) $model->id,
				'name' => (string) $model->name,
			];
		}

		$data = [
			'id'                => (int) $model->id,
			'name'              => (string) $model->name,
			'short_description' => (string) $model->short_description,
			'parent_id'         => $model->parent_id ? (int) $model->parent_id : null,
			'order_number'      => (int) $model->order_number,
		];

		if ( $context !== self::CONTEXT_AI ) {
			$data['_links'] = [
				'self'       => [ [ 'href' => rest_url( 'latepoint/v1/service-categories/' . $model->id ) ] ],
				'collection' => [ [ 'href' => rest_url( 'latepoint/v1/service-categories' ) ] ],
			];
		}

		return $data;
	}

	public function schema(): array {
		return [
			'title'      => 'service-category',
			'type'       => 'object',
			'properties' => [
				'id'                => [
					'type'     => 'integer',
					'readonly' => true,
				],
				'name'              => [ 'type' => 'string' ],
				'short_description' => [ 'type' => 'string' ],
				'parent_id'         => [ 'type' => [ 'integer', 'null' ] ],
				'order_number'      => [ 'type' => 'integer' ],
			],
		];
	}
}
