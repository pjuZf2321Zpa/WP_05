<?php
/**
 * Location serializer — the public REST representation of OsLocationModel.
 *
 * OsLocationModel has no description/phone/email fields (see z-claude-memory/852-issue.md
 * and the AI abilities' location module, which learned this the hard way) — do not add
 * them here just because they'd be natural REST fields to expect.
 *
 * @package LatePoint\Api
 * @since   5.4.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class OsApiLocationSerializer extends OsApiSerializer {

	/**
	 * @param OsLocationModel $model
	 * @param string          $context
	 * @return array
	 */
	public function to_array( $model, string $context = self::CONTEXT_VIEW ): array {
		if ( $context === self::CONTEXT_EMBED ) {
			return [
				'id'   => (int) $model->id,
				'name' => (string) $model->name,
			];
		}

		$data = [
			'id'           => (int) $model->id,
			'name'         => (string) $model->name,
			'full_address' => (string) $model->full_address,
			'status'       => (string) $model->status,
			'category_id'  => $model->category_id ? (int) $model->category_id : null,
			'order_number' => (int) $model->order_number,
		];

		if ( $context !== self::CONTEXT_AI ) {
			$data['_links'] = [
				'self'       => [ [ 'href' => rest_url( 'latepoint/v1/locations/' . $model->id ) ] ],
				'collection' => [ [ 'href' => rest_url( 'latepoint/v1/locations' ) ] ],
			];
		}

		return $data;
	}

	public function schema(): array {
		return [
			'title'      => 'location',
			'type'       => 'object',
			'properties' => [
				'id'           => [
					'type'     => 'integer',
					'readonly' => true,
				],
				'name'         => [ 'type' => 'string' ],
				'full_address' => [ 'type' => 'string' ],
				'status'       => [ 'type' => 'string' ],
				'category_id'  => [ 'type' => [ 'integer', 'null' ] ],
				'order_number' => [ 'type' => 'integer' ],
			],
		];
	}
}
