<?php
/**
 * Agent serializer — the public REST representation of OsAgentModel.
 *
 * @package LatePoint\Api
 * @since   5.4.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class OsApiAgentSerializer extends OsApiSerializer {

	/**
	 * @param OsAgentModel $model
	 * @param string       $context
	 * @return array
	 */
	public function to_array( $model, string $context = self::CONTEXT_VIEW ): array {
		if ( $context === self::CONTEXT_EMBED ) {
			return [
				'id'        => (int) $model->id,
				'full_name' => trim( $model->first_name . ' ' . $model->last_name ),
				'email'     => (string) $model->email,
			];
		}

		$data = [
			'id'           => (int) $model->id,
			'first_name'   => (string) $model->first_name,
			'last_name'    => (string) $model->last_name,
			'full_name'    => trim( $model->first_name . ' ' . $model->last_name ),
			'display_name' => (string) $model->display_name,
			'email'        => (string) $model->email,
			'phone'        => (string) $model->phone,
			'title'        => (string) $model->title,
			'bio'          => (string) $model->bio,
			'status'       => (string) $model->status,
		];

		if ( $context !== self::CONTEXT_AI ) {
			$data['_links'] = [
				'self'       => [ [ 'href' => rest_url( 'latepoint/v1/agents/' . $model->id ) ] ],
				'collection' => [ [ 'href' => rest_url( 'latepoint/v1/agents' ) ] ],
			];
		}

		return $data;
	}

	public function schema(): array {
		return [
			'title'      => 'agent',
			'type'       => 'object',
			'properties' => [
				'id'           => [
					'type'     => 'integer',
					'readonly' => true,
				],
				'first_name'   => [ 'type' => 'string' ],
				'last_name'    => [ 'type' => 'string' ],
				'full_name'    => [
					'type'     => 'string',
					'readonly' => true,
				],
				'display_name' => [ 'type' => 'string' ],
				'email'        => [
					'type'   => 'string',
					'format' => 'email',
				],
				'phone'        => [ 'type' => 'string' ],
				'title'        => [ 'type' => 'string' ],
				'bio'          => [ 'type' => 'string' ],
				'status'       => [ 'type' => 'string' ],
			],
		];
	}
}
