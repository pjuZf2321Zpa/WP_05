<?php
/**
 * Booking serializer — the public REST representation of OsBookingModel.
 *
 * Deliberately a full-fidelity superset of the AI Abilities' serialize_booking()
 * (lib/abilities/bookings/abstract-booking-ability.php): includes booking_code, end_date,
 * buffers, total_attendees, and created_at/updated_at (which the abilities schema declares
 * but never actually emits — see docs/rest-api.md for that history). Time is exposed as a
 * structured object rather than raw minutes-from-midnight, with start_datetime_utc treated
 * as the canonical instant that wall-clock fields are derived from.
 *
 * @package LatePoint\Api
 * @since   5.4.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class OsApiBookingSerializer extends OsApiSerializer {

	/** @var array<int,OsCustomerModel> */
	private $customers = [];
	/** @var array<int,OsServiceModel> */
	private $services = [];
	/** @var array<int,OsAgentModel> */
	private $agents = [];
	/** @var array<int,OsLocationModel> */
	private $locations = [];
	/** @var array<int,OsOrderItemModel> */
	private $order_items = [];
	/** @var array<int,OsOrderModel> */
	private $orders = [];

	public function prime( array $models ): void {
		$customer_ids   = [];
		$service_ids    = [];
		$agent_ids      = [];
		$location_ids   = [];
		$order_item_ids = [];

		foreach ( $models as $booking ) {
			if ( $booking->customer_id ) {
				$customer_ids[] = (int) $booking->customer_id;
			}
			if ( $booking->service_id ) {
				$service_ids[] = (int) $booking->service_id;
			}
			if ( $booking->agent_id ) {
				$agent_ids[] = (int) $booking->agent_id;
			}
			if ( $booking->location_id ) {
				$location_ids[] = (int) $booking->location_id;
			}
			if ( $booking->order_item_id ) {
				$order_item_ids[] = (int) $booking->order_item_id;
			}
		}

		$this->customers   = $this->index_by_id( 'OsCustomerModel', $customer_ids );
		$this->services    = $this->index_by_id( 'OsServiceModel', $service_ids );
		$this->agents      = $this->index_by_id( 'OsAgentModel', $agent_ids );
		$this->locations   = $this->index_by_id( 'OsLocationModel', $location_ids );
		$this->order_items = $this->index_by_id( 'OsOrderItemModel', $order_item_ids );

		$order_ids = [];
		foreach ( $this->order_items as $order_item ) {
			if ( $order_item->order_id ) {
				$order_ids[] = (int) $order_item->order_id;
			}
		}
		$this->orders = $this->index_by_id( 'OsOrderModel', $order_ids );
	}

	/**
	 * @param OsBookingModel $model
	 * @param string         $context
	 * @return array
	 */
	public function to_array( $model, string $context = self::CONTEXT_VIEW ): array {
		$order_item = $this->order_items[ (int) $model->order_item_id ] ?? null;
		$order      = $order_item ? ( $this->orders[ (int) $order_item->order_id ] ?? null ) : null;

		$timezone_name = OsTimeHelper::get_wp_timezone_name();

		if ( $context === self::CONTEXT_EMBED ) {
			return [
				'id'           => (int) $model->id,
				'booking_code' => (string) $model->booking_code,
				'status'       => (string) $model->status,
				'start'        => $this->format_datetime_block( $model, true, $timezone_name ),
			];
		}

		$data = [
			'id'               => (int) $model->id,
			'booking_code'     => (string) $model->booking_code,
			'status'           => (string) $model->status,
			'start'            => $this->format_datetime_block( $model, true, $timezone_name ),
			'end'              => $this->format_datetime_block( $model, false, $timezone_name ),
			'duration'         => (int) $model->duration,
			'buffer_before'    => (int) $model->buffer_before,
			'buffer_after'     => (int) $model->buffer_after,
			'total_attendees'  => (int) $model->total_attendees,
			'timezones'        => [
				'server'   => (string) $model->server_timezone ?: $timezone_name,
				'customer' => (string) $model->customer_timezone ?: $timezone_name,
			],
			'customer_id'      => (int) $model->customer_id,
			'service_id'       => (int) $model->service_id,
			'agent_id'         => (int) $model->agent_id,
			'location_id'      => (int) $model->location_id,
			'order_item_id'    => (int) $model->order_item_id,
			'recurrence_id'    => $model->recurrence_id ? (int) $model->recurrence_id : null,
			// this is $order->customer_comment, not a per-booking field — the abilities layer
			// calls it "notes", which is inaccurate; it is the customer's comment on the order.
			'customer_comment' => $order ? (string) $order->customer_comment : '',
			'created_at'       => $this->to_rfc3339( $model->created_at ),
			'updated_at'       => $this->to_rfc3339( $model->updated_at ),
		];

		if ( $context !== self::CONTEXT_AI ) {
			$data['customer'] = $this->embed_customer( (int) $model->customer_id );
			$data['service']  = $this->embed_service( (int) $model->service_id );
			$data['agent']    = $this->embed_agent( (int) $model->agent_id );
			$data['location'] = $this->embed_location( (int) $model->location_id );
			$data['order']    = $this->embed_order( $order );
			$data['_links']   = $this->links( $model );
		}

		return $data;
	}

	private function format_datetime_block( OsBookingModel $model, bool $is_start, string $timezone_name ): array {
		$date        = $is_start ? $model->start_date : $model->end_date;
		$minutes     = $is_start ? $model->start_time : $model->end_time;
		$minutes_int = is_null( $minutes ) || $minutes === '' ? null : (int) $minutes;

		// get_start_datetime()/get_end_datetime() recompute from start_date/start_time
		// (stored in site timezone) rather than depending on start_datetime_utc being
		// populated, so this works correctly even for legacy rows with a NULL UTC column.
		if ( empty( $date ) || is_null( $minutes_int ) ) {
			$datetime_local = '';
			$datetime_utc   = '';
		} else {
			$get_datetime   = $is_start ? 'get_start_datetime' : 'get_end_datetime';
			$datetime_local = $model->$get_datetime( $timezone_name )->format( \DateTime::RFC3339 );
			$datetime_utc   = $model->$get_datetime( 'UTC' )->format( \DateTime::RFC3339 );
		}

		return [
			'date'                  => (string) $date,
			'time'                  => is_null( $minutes_int ) ? null : OsTimeHelper::minutes_to_army_hours_and_minutes( $minutes_int ),
			'minutes_from_midnight' => $minutes_int,
			'datetime'              => $datetime_local,
			'datetime_utc'          => $datetime_utc,
		];
	}

	/**
	 * Delegates to the owning resource's own serializer rather than re-deriving its compact
	 * shape here — keeps the nested object inside a booking response and the equivalent
	 * top-level `?context=embed` response as exactly one definition.
	 */
	private function embed_customer( int $id ): ?array {
		$customer = $this->customers[ $id ] ?? null;

		return $customer ? ( new OsApiCustomerSerializer() )->to_array( $customer, self::CONTEXT_EMBED ) : null;
	}

	private function embed_service( int $id ): ?array {
		$service = $this->services[ $id ] ?? null;

		return $service ? ( new OsApiServiceSerializer() )->to_array( $service, self::CONTEXT_EMBED ) : null;
	}

	private function embed_agent( int $id ): ?array {
		$agent = $this->agents[ $id ] ?? null;

		return $agent ? ( new OsApiAgentSerializer() )->to_array( $agent, self::CONTEXT_EMBED ) : null;
	}

	private function embed_location( int $id ): ?array {
		$location = $this->locations[ $id ] ?? null;

		return $location ? ( new OsApiLocationSerializer() )->to_array( $location, self::CONTEXT_EMBED ) : null;
	}

	private function embed_order( ?OsOrderModel $order ): ?array {
		return $order ? ( new OsApiOrderSerializer() )->to_array( $order, self::CONTEXT_EMBED ) : null;
	}

	private function links( OsBookingModel $model ): array {
		$links = [
			'self'       => [ [ 'href' => rest_url( 'latepoint/v1/bookings/' . $model->id ) ] ],
			'collection' => [ [ 'href' => rest_url( 'latepoint/v1/bookings' ) ] ],
		];
		if ( $model->customer_id ) {
			$links['customer'] = [ [ 'href' => rest_url( 'latepoint/v1/customers/' . $model->customer_id ) ] ];
		}
		if ( $model->service_id ) {
			$links['service'] = [ [ 'href' => rest_url( 'latepoint/v1/services/' . $model->service_id ) ] ];
		}
		if ( $model->agent_id ) {
			$links['agent'] = [ [ 'href' => rest_url( 'latepoint/v1/agents/' . $model->agent_id ) ] ];
		}
		if ( $model->location_id ) {
			$links['location'] = [ [ 'href' => rest_url( 'latepoint/v1/locations/' . $model->location_id ) ] ];
		}

		return $links;
	}

	public function schema(): array {
		$datetime_block_schema = [
			'type'       => 'object',
			'properties' => [
				'date'                  => [
					'type'   => 'string',
					'format' => 'date',
				],
				'time'                  => [
					'type'        => [ 'string', 'null' ],
					'description' => __( '24-hour HH:MM, in site timezone.', 'latepoint' ),
				],
				'minutes_from_midnight' => [ 'type' => [ 'integer', 'null' ] ],
				'datetime'              => [
					'type'   => 'string',
					'format' => 'date-time',
				],
				'datetime_utc'          => [
					'type'   => 'string',
					'format' => 'date-time',
				],
			],
		];

		return [
			'title'      => 'booking',
			'type'       => 'object',
			'properties' => [
				'id'               => [
					'type'     => 'integer',
					'context'  => [ 'view', 'edit', 'embed' ],
					'readonly' => true,
				],
				'booking_code'     => [
					'type'     => 'string',
					'readonly' => true,
				],
				'status'           => [
					'type' => 'string',
					'enum' => [ 'pending', 'approved', 'cancelled', 'no_show', 'completed' ],
				],
				'start'            => $datetime_block_schema,
				'end'              => $datetime_block_schema,
				'duration'         => [ 'type' => 'integer' ],
				'buffer_before'    => [ 'type' => 'integer' ],
				'buffer_after'     => [ 'type' => 'integer' ],
				'total_attendees'  => [ 'type' => 'integer' ],
				'timezones'        => [
					'type'       => 'object',
					'properties' => [
						'server'   => [ 'type' => 'string' ],
						'customer' => [ 'type' => 'string' ],
					],
				],
				'customer_id'      => [ 'type' => 'integer' ],
				'service_id'       => [ 'type' => 'integer' ],
				'agent_id'         => [ 'type' => 'integer' ],
				'location_id'      => [ 'type' => 'integer' ],
				'order_item_id'    => [
					'type'     => 'integer',
					'readonly' => true,
				],
				'recurrence_id'    => [ 'type' => [ 'integer', 'null' ] ],
				'customer_comment' => [ 'type' => 'string' ],
				'created_at'       => [
					'type'     => 'string',
					'format'   => 'date-time',
					'readonly' => true,
				],
				'updated_at'       => [
					'type'     => 'string',
					'format'   => 'date-time',
					'readonly' => true,
				],
			],
		];
	}
}
