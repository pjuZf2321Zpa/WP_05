<?php
/**
 * Coupon serializer — the public REST representation of OsCouponModel.
 *
 * Field shape mirrors LatePointAbstractCouponAbility::serialize_coupon()
 * (lib/abilities/coupons/abstract-coupon-ability.php) — coupons have no sensitive fields
 * to hide between contexts, so view/edit are identical.
 *
 * @package LatePoint\Pro\Api
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class OsApiCouponSerializer extends OsApiSerializer {

	/**
	 * @param OsCouponModel $model
	 * @param string        $context
	 * @return array
	 */
	public function to_array( $model, string $context = self::CONTEXT_VIEW ): array {
		if ( $context === self::CONTEXT_EMBED ) {
			return [
				'id'   => (int) $model->id,
				'code' => (string) $model->code,
				'name' => (string) $model->name,
			];
		}

		$rules = [];
		if ( ! empty( $model->rules ) ) {
			$decoded = json_decode( $model->rules, true );
			if ( is_array( $decoded ) ) {
				$rules = $decoded;
			}
		}

		$data = [
			'id'             => (int) $model->id,
			'code'           => (string) $model->code,
			'name'           => (string) $model->name,
			'description'    => (string) $model->description,
			'discount_type'  => (string) $model->discount_type,
			'discount_value' => (float) $model->discount_value,
			'status'         => (string) $model->status,
			'active_from'    => (string) $model->active_from,
			'active_to'      => (string) $model->active_to,
			'rules'          => empty( $rules ) ? new \stdClass() : $rules,
			'created_at'     => $this->to_rfc3339( $model->created_at ),
			'updated_at'     => $this->to_rfc3339( $model->updated_at ),
		];

		if ( $context !== self::CONTEXT_AI ) {
			$data['_links'] = [
				'self'       => [ [ 'href' => rest_url( 'latepoint/v1/coupons/' . $model->id ) ] ],
				'collection' => [ [ 'href' => rest_url( 'latepoint/v1/coupons' ) ] ],
			];
		}

		return $data;
	}

	public function schema(): array {
		return [
			'title'      => 'coupon',
			'type'       => 'object',
			'properties' => [
				'id'             => [
					'type'     => 'integer',
					'readonly' => true,
				],
				'code'           => [ 'type' => 'string' ],
				'name'           => [ 'type' => 'string' ],
				'description'    => [ 'type' => 'string' ],
				'discount_type'  => [
					'type' => 'string',
					'enum' => [ 'fixed', 'percent' ],
				],
				'discount_value' => [ 'type' => 'number' ],
				'status'         => [
					'type' => 'string',
					'enum' => [ 'active', 'disabled' ],
				],
				'active_from'    => [ 'type' => 'string' ],
				'active_to'      => [ 'type' => 'string' ],
				'rules'          => [ 'type' => 'object' ],
				'created_at'     => [
					'type'     => 'string',
					'format'   => 'date-time',
					'readonly' => true,
				],
				'updated_at'     => [
					'type'     => 'string',
					'format'   => 'date-time',
					'readonly' => true,
				],
			],
		];
	}
}
