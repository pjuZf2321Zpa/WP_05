<?php
/**
 * Order serializer — the public REST representation of OsOrderModel.
 *
 * Deliberately a full-fidelity superset of the AI Abilities' serialize_order()
 * (lib/abilities/orders/abstract-order-ability.php), which only exposes
 * id/status/payment_status/fulfillment_status/customer_id/subtotal/total/notes/
 * created_at/updated_at. This adds confirmation_code, tax_total, coupon_code/discount,
 * an embedded customer stub, and a compact items summary.
 *
 * @package LatePoint\Api
 * @since   5.4.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class OsApiOrderSerializer extends OsApiSerializer {

	/** @var array<int,OsCustomerModel> */
	private $customers = [];
	/** @var array<int,OsOrderItemModel[]> */
	private $items_by_order = [];

	public function prime( array $models ): void {
		$customer_ids = [];
		$order_ids    = [];

		foreach ( $models as $order ) {
			if ( $order->customer_id ) {
				$customer_ids[] = (int) $order->customer_id;
			}
			$order_ids[] = (int) $order->id;
		}

		$this->customers = $this->index_by_id( 'OsCustomerModel', $customer_ids );

		$this->items_by_order = [];
		$order_ids            = array_values( array_unique( array_filter( $order_ids ) ) );
		if ( ! empty( $order_ids ) ) {
			$items = ( new OsOrderItemModel() )->where_in( 'order_id', $order_ids )->get_results_as_models();
			foreach ( OsApiQuery::normalize_to_array( $items ) as $item ) {
				$this->items_by_order[ (int) $item->order_id ][] = $item;
			}
		}
	}

	/**
	 * @param OsOrderModel $model
	 * @param string       $context
	 * @return array
	 */
	public function to_array( $model, string $context = self::CONTEXT_VIEW ): array {
		// Matches the booking serializer's embed_order() shape, so an order looks the same
		// whether it's embedded inside a booking response or fetched directly with
		// ?context=embed.
		if ( $context === self::CONTEXT_EMBED ) {
			return [
				'id'                => (int) $model->id,
				'confirmation_code' => (string) $model->confirmation_code,
				'status'            => (string) $model->status,
				'payment_status'    => (string) $model->payment_status,
				'total'             => (string) $model->total,
				'total_formatted'   => OsMoneyHelper::format_price( $model->total ),
			];
		}

		$data = [
			'id'                 => (int) $model->id,
			'confirmation_code'  => (string) $model->confirmation_code,
			'status'             => (string) $model->status,
			'payment_status'     => (string) $model->payment_status,
			'fulfillment_status' => (string) $model->fulfillment_status,
			'customer_id'        => (int) $model->customer_id,
			'subtotal'           => (string) $model->subtotal,
			'total'              => (string) $model->total,
			'tax_total'          => (string) $model->tax_total,
			'coupon_code'        => (string) $model->coupon_code,
			'coupon_discount'    => (string) $model->coupon_discount,
			'customer_comment'   => (string) $model->customer_comment,
			'created_at'         => $this->to_rfc3339( $model->created_at ),
			'updated_at'         => $this->to_rfc3339( $model->updated_at ),
		];

		if ( $context !== self::CONTEXT_AI ) {
			$data['customer'] = $this->embed_customer( (int) $model->customer_id );
			$data['items']    = $this->embed_items( (int) $model->id );
			$data['_links']   = $this->links( $model );
		}

		return $data;
	}

	private function embed_customer( int $id ): ?array {
		$customer = $this->customers[ $id ] ?? null;

		return $customer ? ( new OsApiCustomerSerializer() )->to_array( $customer, self::CONTEXT_EMBED ) : null;
	}

	private function embed_items( int $order_id ): array {
		$items = $this->items_by_order[ $order_id ] ?? [];

		return array_map(
			function ( OsOrderItemModel $item ) {
				return [
					'id'         => (int) $item->id,
					'variant'    => (string) $item->variant,
					'booking_id' => $this->resolve_booking_id( $item ),
					'subtotal'   => (string) $item->subtotal,
					'total'      => (string) $item->total,
				];
			},
			$items
		);
	}

	/**
	 * item_data carries the originating booking's id for booking-variant items — the same
	 * technique OsOrderModel::get_bookings_from_order_items() uses (order_model.php:135-150).
	 * Bundle/other variants don't carry a single booking id; returns null for those.
	 *
	 * @param OsOrderItemModel $item
	 * @return int|null
	 */
	private function resolve_booking_id( OsOrderItemModel $item ): ?int {
		if ( LATEPOINT_ITEM_VARIANT_BOOKING !== $item->variant ) {
			return null;
		}
		$item_data = json_decode( (string) $item->item_data, true );

		return ! empty( $item_data['id'] ) ? (int) $item_data['id'] : null;
	}

	private function links( OsOrderModel $model ): array {
		$links = [
			'self'       => [ [ 'href' => rest_url( 'latepoint/v1/orders/' . $model->id ) ] ],
			'collection' => [ [ 'href' => rest_url( 'latepoint/v1/orders' ) ] ],
		];
		if ( $model->customer_id ) {
			$links['customer'] = [ [ 'href' => rest_url( 'latepoint/v1/customers/' . $model->customer_id ) ] ];
		}

		return $links;
	}

	public function schema(): array {
		return [
			'title'      => 'order',
			'type'       => 'object',
			'properties' => [
				'id'                 => [
					'type'     => 'integer',
					'readonly' => true,
				],
				'confirmation_code'  => [
					'type'     => 'string',
					'readonly' => true,
				],
				'status'             => [
					'type' => 'string',
					'enum' => [ 'open', 'cancelled', 'completed' ],
				],
				'payment_status'     => [ 'type' => 'string' ],
				'fulfillment_status' => [ 'type' => 'string' ],
				'customer_id'        => [ 'type' => 'integer' ],
				'subtotal'           => [ 'type' => 'string' ],
				'total'              => [ 'type' => 'string' ],
				'tax_total'          => [ 'type' => 'string' ],
				'coupon_code'        => [ 'type' => 'string' ],
				'coupon_discount'    => [ 'type' => 'string' ],
				'customer_comment'   => [ 'type' => 'string' ],
				'created_at'         => [
					'type'     => 'string',
					'format'   => 'date-time',
					'readonly' => true,
				],
				'updated_at'         => [
					'type'     => 'string',
					'format'   => 'date-time',
					'readonly' => true,
				],
			],
		];
	}
}
