<?php
/**
 * Service serializer — the public REST representation of OsServiceModel.
 *
 * Field names follow the actual model, not the AI Abilities' simplified vocabulary
 * (which maps "price" -> price_min and "description" -> short_description internally
 * while accepting the friendlier public names) — see z-claude-memory/852-issue.md.
 *
 * @package LatePoint\Api
 * @since   5.4.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class OsApiServiceSerializer extends OsApiSerializer {

	/**
	 * @param OsServiceModel $model
	 * @param string         $context
	 * @return array
	 */
	public function to_array( $model, string $context = self::CONTEXT_VIEW ): array {
		if ( $context === self::CONTEXT_EMBED ) {
			return [
				'id'   => (int) $model->id,
				'name' => (string) $model->name,
			];
		}

		$data = [
			'id'                  => (int) $model->id,
			'name'                => (string) $model->name,
			'short_description'   => (string) $model->short_description,
			'duration'            => (int) $model->duration,
			'buffer_before'       => (int) $model->buffer_before,
			'buffer_after'        => (int) $model->buffer_after,
			'price_min'           => (string) $model->price_min,
			'price_max'           => (string) $model->price_max,
			'is_price_variable'   => (bool) $model->is_price_variable,
			'deposit_amount'      => (string) $model->deposit_amount,
			'is_deposit_required' => (bool) $model->is_deposit_required,
			'category_id'         => $model->category_id ? (int) $model->category_id : null,
			'status'              => (string) $model->status,
			'visibility'          => (string) $model->visibility,
			'capacity_min'        => (int) $model->capacity_min,
			'capacity_max'        => (int) $model->capacity_max,
			'order_number'        => (int) $model->order_number,
			'bg_color'            => (string) $model->bg_color,
		];

		if ( $context !== self::CONTEXT_AI ) {
			$data['_links'] = [
				'self'       => [ [ 'href' => rest_url( 'latepoint/v1/services/' . $model->id ) ] ],
				'collection' => [ [ 'href' => rest_url( 'latepoint/v1/services' ) ] ],
			];
			if ( $model->category_id ) {
				$data['_links']['category'] = [ [ 'href' => rest_url( 'latepoint/v1/service-categories/' . $model->category_id ) ] ];
			}
		}

		return $data;
	}

	public function schema(): array {
		return [
			'title'      => 'service',
			'type'       => 'object',
			'properties' => [
				'id'                  => [
					'type'     => 'integer',
					'readonly' => true,
				],
				'name'                => [ 'type' => 'string' ],
				'short_description'   => [ 'type' => 'string' ],
				'duration'            => [ 'type' => 'integer' ],
				'buffer_before'       => [ 'type' => 'integer' ],
				'buffer_after'        => [ 'type' => 'integer' ],
				'price_min'           => [ 'type' => 'string' ],
				'price_max'           => [ 'type' => 'string' ],
				'is_price_variable'   => [ 'type' => 'boolean' ],
				'deposit_amount'      => [ 'type' => 'string' ],
				'is_deposit_required' => [ 'type' => 'boolean' ],
				'category_id'         => [ 'type' => [ 'integer', 'null' ] ],
				'status'              => [ 'type' => 'string' ],
				'visibility'          => [ 'type' => 'string' ],
				'capacity_min'        => [ 'type' => 'integer' ],
				'capacity_max'        => [ 'type' => 'integer' ],
				'order_number'        => [ 'type' => 'integer' ],
				'bg_color'            => [ 'type' => 'string' ],
			],
		];
	}
}
