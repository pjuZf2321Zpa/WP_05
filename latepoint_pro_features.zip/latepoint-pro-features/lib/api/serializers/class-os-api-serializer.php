<?php
/**
 * Abstract base for REST resource serializers.
 *
 * One serializer per resource is the single source of truth for that resource's public
 * field names, types and derivation — used by the REST controller directly, and (from
 * Phase 2 onward) by the AI Abilities layer via the 'ai' context, so the two transports
 * never drift into two different representations of the same data.
 *
 * @package LatePoint\Api
 * @since   5.4.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

abstract class OsApiSerializer {

	const CONTEXT_VIEW  = 'view';
	const CONTEXT_EDIT  = 'edit';
	const CONTEXT_EMBED = 'embed';
	const CONTEXT_AI    = 'ai';

	/**
	 * JSON Schema for this resource (the 'view' context; used as the route's item schema).
	 *
	 * @return array
	 */
	abstract public function schema(): array;

	/**
	 * Serialize a single model to its public representation for the given context.
	 *
	 * @param OsModel $model
	 * @param string  $context One of the CONTEXT_* constants.
	 * @return array
	 */
	abstract public function to_array( $model, string $context = self::CONTEXT_VIEW ): array;

	/**
	 * Batch-hydrate relations for a set of models before serializing them.
	 *
	 * Relations are resolved through OsModel::__get() magic, which issues one query per
	 * access — serializing a page of 20+ models naively fires dozens of queries. Override
	 * to where_in() the relevant related tables and stash results for to_array() to reuse.
	 * No-op by default.
	 *
	 * @param array $models
	 * @return void
	 */
	public function prime( array $models ): void {
		// no-op by default; resource serializers override where relations exist.
	}

	/**
	 * Serialize a collection, priming relations first.
	 *
	 * @param array  $models
	 * @param string $context
	 * @return array
	 */
	public function to_array_collection( array $models, string $context = self::CONTEXT_VIEW ): array {
		$this->prime( $models );

		return array_map(
			function ( $model ) use ( $context ) {
				return $this->to_array( $model, $context );
			},
			$models
		);
	}

	/**
	 * Serialize a single model, priming its relations first. Controllers should always call
	 * this (not to_array() directly) outside of a collection loop — prime() is what
	 * populates the relation maps embed_*() methods read from, and get_item()/create_item()/
	 * update_item() each hand back exactly one model, not a collection.
	 *
	 * @param OsModel $model
	 * @param string  $context
	 * @return array
	 */
	public function to_array_single( $model, string $context = self::CONTEXT_VIEW ): array {
		$this->prime( [ $model ] );

		return $this->to_array( $model, $context );
	}

	/**
	 * @param string|null $mysql_datetime
	 * @return string RFC 3339, or '' if $mysql_datetime is empty/unparseable.
	 */
	protected function to_rfc3339( ?string $mysql_datetime ): string {
		if ( empty( $mysql_datetime ) ) {
			return '';
		}
		$date = OsTimeHelper::date_from_db( $mysql_datetime );

		return $date ? $date->format( \DateTime::RFC3339 ) : '';
	}

	/**
	 * Batch-load $model_class rows by id, keyed by id — the shared shape prime()
	 * implementations use to build the maps their embed_*() methods read from. Callers
	 * type-hint the specific model class via their own property's @var, same as before this
	 * was factored out of each serializer.
	 *
	 * @param string $model_class
	 * @param array  $ids
	 * @return array
	 */
	protected function index_by_id( string $model_class, array $ids ): array {
		$ids = array_values( array_unique( array_filter( $ids ) ) );
		if ( empty( $ids ) ) {
			return [];
		}
		$rows = ( new $model_class() )->where_in( 'id', $ids )->get_results_as_models();
		$rows = OsApiQuery::normalize_to_array( $rows );

		$indexed = [];
		foreach ( $rows as $row ) {
			$indexed[ (int) $row->id ] = $row;
		}

		return $indexed;
	}
}
