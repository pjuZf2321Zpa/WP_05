<?php
/**
 * Shared filter/sort/paginate helpers for REST collection endpoints.
 *
 * Centralizes patterns that are otherwise repeated (and inconsistently applied) across
 * the codebase: pagination clamping, the get_results_as_models() single-record collapse
 * (see OsModel::get_results_as_models(), it returns a bare model instead of an array when
 * limit == 1), and the "does this record exist at all vs is it just outside the current
 * user's allowed records" distinction used for scoped single-record lookups.
 *
 * @package LatePoint\Api
 * @since   5.4.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class OsApiQuery {

	const NOT_FOUND = 'not_found';
	const FORBIDDEN = 'forbidden';

	/**
	 * Clamp page/per_page request args to sane bounds.
	 *
	 * @param array $args Raw request args (e.g. from WP_REST_Request::get_params()).
	 * @return array{page:int,per_page:int,offset:int}
	 */
	public static function clamp_pagination( array $args ): array {
		$page     = max( 1, (int) ( $args['page'] ?? 1 ) );
		$per_page = min( 100, max( 1, (int) ( $args['per_page'] ?? 20 ) ) );

		return [
			'page'     => $page,
			'per_page' => $per_page,
			'offset'   => ( $page - 1 ) * $per_page,
		];
	}

	/**
	 * Apply orderby/order to a query using a whitelist map of request keys to DB columns.
	 *
	 * The map prevents arbitrary column injection through ?orderby= and lets a resource
	 * point a friendly key (e.g. "start") at a derived column (e.g. "start_datetime_utc").
	 *
	 * @param OsModel $query
	 * @param array   $args
	 * @param array   $orderby_map Map of allowed orderby => DB column/expression.
	 * @param string  $default_key Key (must exist in $orderby_map) used when none/invalid is requested.
	 * @return OsModel
	 */
	public static function apply_sort( OsModel $query, array $args, array $orderby_map, string $default_key = 'id' ): OsModel {
		$requested = sanitize_key( (string) ( $args['orderby'] ?? '' ) );
		$column    = $orderby_map[ $requested ] ?? ( $orderby_map[ $default_key ] ?? 'id' );
		$direction = ( isset( $args['order'] ) && strtolower( (string) $args['order'] ) === 'asc' ) ? 'ASC' : 'DESC';

		return $query->order_by( $column . ' ' . $direction );
	}

	/**
	 * Run a paginated collection query and return both the page of models and the total count.
	 *
	 * Counts before limit/offset are applied (against a clone, so the count query doesn't
	 * consume the caller's query object).
	 *
	 * @param OsModel $query      Query with where()/filter_allowed_records()/order_by() already applied.
	 * @param array   $pagination Result of clamp_pagination().
	 * @return array{0: OsModel[], 1: int} [$models, $total]
	 */
	public static function fetch_collection( OsModel $query, array $pagination ): array {
		$total = (int) ( clone $query )->count();

		$models = $query->set_limit( $pagination['per_page'] )->set_offset( $pagination['offset'] )->get_results_as_models();
		$models = self::normalize_to_array( $models );

		return [ $models, $total ];
	}

	/**
	 * Normalize get_results_as_models() output to a plain array.
	 *
	 * OsModel::get_results_as_models() collapses its return value to a single bare model
	 * (not wrapped in an array) whenever the query's limit is 1 — every existing call site
	 * works around this individually. Do it once, here.
	 *
	 * @param mixed $models
	 * @return array
	 */
	public static function normalize_to_array( $models ): array {
		if ( empty( $models ) ) {
			return [];
		}

		return is_array( $models ) ? $models : [ $models ];
	}

	/**
	 * Load a single record by ID, scoped to the current user's allowed records.
	 *
	 * Distinguishes "no such record" (404) from "record exists but is outside what this
	 * user is allowed to see" (403) by checking existence unscoped first — mirrors the
	 * pattern orders_controller.php uses for its own "allowed_order" check.
	 *
	 * @param string $model_class Fully qualified OsModel subclass name.
	 * @param int    $id
	 * @return array{0: OsModel|null, 1: string|null} [$model, $error] where $error is
	 *                                                 null, self::NOT_FOUND, or self::FORBIDDEN.
	 */
	public static function find_scoped( string $model_class, int $id ): array {
		$unscoped = new $model_class( $id );
		if ( $unscoped->is_new_record() ) {
			return [ null, self::NOT_FOUND ];
		}

		$scoped_query = new $model_class();
		$scoped       = $scoped_query->where( [ 'id' => $id ] )->filter_allowed_records()->set_limit( 1 )->get_results_as_models();
		if ( empty( $scoped ) ) {
			return [ null, self::FORBIDDEN ];
		}

		return [ $scoped, null ];
	}

	/**
	 * Accepts either an "HH:MM" string or a raw minutes-from-midnight value (int or numeric
	 * string) and returns minutes from midnight — the one place POST /bookings and
	 * GET /agents/availability both parse a start_time value.
	 *
	 * @param mixed $raw
	 * @return int
	 */
	public static function parse_minutes_from_midnight( $raw ): int {
		if ( is_string( $raw ) && strpos( $raw, ':' ) !== false ) {
			list( $hours, $minutes ) = array_map( 'intval', explode( ':', $raw ) );

			return ( $hours * 60 ) + $minutes;
		}

		return absint( $raw );
	}
}
