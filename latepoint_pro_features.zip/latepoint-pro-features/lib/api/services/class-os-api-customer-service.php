<?php
/**
 * Customer write service — mirrors lib/controllers/customers_controller.php create()/update()/
 * destroy() so the REST API fires the same latepoint_customer_created/_updated hooks that
 * OsActivitiesHelper, analytics, and automations already listen for.
 *
 * @package LatePoint\Api
 * @since   5.4.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class OsApiCustomerService {

	/**
	 * @param array $input
	 * @return OsCustomerModel|WP_Error
	 */
	public function create( array $input ) {
		$customer = new OsCustomerModel();
		// wordpress_user_id mass-assignment is never allowed via the API, matching the
		// extra guard orders_controller.php applies on top of the admin params scope
		// (customers_controller.php's own admin scope does allow it — an existing gap
		// this service does not inherit).
		unset( $input['wordpress_user_id'] );
		// id: on create, OsModel::set_data() auto-loads an existing record by id with no
		// ownership check if one is present in $input — stripped to prevent a caller with
		// only customer__create from silently editing an arbitrary customer.
		unset( $input['id'] );
		// password is never hashed or otherwise guarded downstream, so leaving it
		// mass-assignable would let any caller silently overwrite a customer's login.
		unset( $input['password'] );
		$customer->set_data( $input, LATEPOINT_PARAMS_SCOPE_ADMIN );

		if ( ! $customer->save() ) {
			return new WP_Error(
				'latepoint_rest_customer_save_failed',
				implode( ', ', $customer->get_error_messages() ),
				[ 'status' => 422 ]
			);
		}

		/** This action is documented in lib/controllers/customers_controller.php */
		do_action( 'latepoint_customer_created', $customer );

		return new OsCustomerModel( $customer->id );
	}

	/**
	 * @param OsCustomerModel $customer Loaded, scoped record to update.
	 * @param array           $input    Partial update payload.
	 * @return OsCustomerModel|WP_Error
	 */
	public function update( OsCustomerModel $customer, array $input ) {
		$old_customer_data = $customer->get_data_vars();

		unset( $input['wordpress_user_id'] );
		unset( $input['id'] );
		// customer__edit doesn't imply "may silently reset this customer's login" — same
		// guard as create(), see its comment for why.
		unset( $input['password'] );
		$customer->set_data( $input, LATEPOINT_PARAMS_SCOPE_ADMIN );

		if ( ! $customer->save() ) {
			return new WP_Error(
				'latepoint_rest_customer_save_failed',
				implode( ', ', $customer->get_error_messages() ),
				[ 'status' => 422 ]
			);
		}

		/** This action is documented in lib/controllers/customers_controller.php */
		do_action( 'latepoint_customer_updated', $customer, $old_customer_data );

		return new OsCustomerModel( $customer->id );
	}

	/**
	 * @param OsCustomerModel $customer Loaded, scoped record to delete.
	 * @return true|WP_Error
	 */
	public function delete( OsCustomerModel $customer ) {
		// no latepoint_customer_deleted hook exists anywhere in the codebase today (verified
		// by grep) — there is nothing further to fire here.
		if ( ! $customer->delete() ) {
			return new WP_Error(
				'latepoint_rest_customer_delete_failed',
				__( 'Failed to delete customer.', 'latepoint' ),
				[ 'status' => 500 ]
			);
		}

		return true;
	}
}
