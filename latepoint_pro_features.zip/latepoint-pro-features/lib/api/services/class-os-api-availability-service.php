<?php
/**
 * Availability service — shared by the REST availability endpoint and (from Phase 2
 * onward) the AI Abilities calendar module.
 *
 * The logic here is lifted from lib/abilities/calendar/abstract-calendar-ability.php and
 * its two concrete abilities (get-available-slots, check-slot-availability) rather than
 * duplicated — it correctly mirrors OsCalendarHelper::generate_single_month() (agent/
 * location "any" resolution, past-day clamping, capacity checks), which is not something
 * to reimplement independently. Phase 2 will point those ability classes at this service
 * instead of carrying their own copy.
 *
 * @package LatePoint\Api
 * @since   5.4.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class OsApiAvailabilityService {

	/**
	 * Build a BookingRequest from raw args, the same way the booking form would.
	 *
	 * @param array $args {service_id, date, agent_id?, location_id?, duration?, start_time?}
	 * @return \LatePoint\Misc\BookingRequest|WP_Error
	 */
	public function build_booking_request( array $args ) {
		// not absint: zero means ANY service to OsConnectorHelper, and a negative would be flipped into a valid id.
		$service_id = (int) ( $args['service_id'] ?? 0 );
		if ( $service_id <= 0 ) {
			return new WP_Error( 'latepoint_rest_invalid_service_id', __( 'A valid service ID is required.', 'latepoint' ), [ 'status' => 400 ] );
		}

		$requested_date = sanitize_text_field( $args['date'] ?? '' );
		if ( ! OsRestController::validate_date_param( $requested_date ) ) {
			return new WP_Error( 'latepoint_rest_invalid_date', __( 'Date has to be in Y-m-d format.', 'latepoint' ), [ 'status' => 400 ] );
		}

		$booking              = new OsBookingModel();
		$booking->service_id  = $service_id;
		$booking->agent_id    = empty( $args['agent_id'] ) ? LATEPOINT_ANY_AGENT : absint( $args['agent_id'] );
		$booking->location_id = empty( $args['location_id'] ) ? LATEPOINT_ANY_LOCATION : absint( $args['location_id'] );
		$booking->start_date  = $requested_date;
		$booking->start_time  = absint( $args['start_time'] ?? 0 );
		// stays zero when not requested; get_total_duration() then falls back to the service duration.
		$booking->duration = absint( $args['duration'] ?? 0 );
		$booking->set_buffers();
		$booking->calculate_end_date_and_time();

		return \LatePoint\Misc\BookingRequest::create_from_booking_model( $booking );
	}

	/**
	 * Blocked periods are only generated from today onwards — the booking form clamps its
	 * date range to "now" the same way in OsCalendarHelper::generate_single_month().
	 *
	 * @param \LatePoint\Misc\BookingRequest $booking_request
	 * @return bool
	 */
	public function is_requested_day_in_the_past( \LatePoint\Misc\BookingRequest $booking_request ): bool {
		return $booking_request->start_date < OsTimeHelper::now_datetime_object()->format( 'Y-m-d' );
	}

	/**
	 * A hidden service is never bookable through the public booking flow (see
	 * OsBookingModel::is_bookable()) — availability has to agree, since it's documented as
	 * showing "the same information your public booking page already shows to visitors."
	 * Mirrors should_not_be_hidden(), the scope the real booking wizard's own service query
	 * already applies (steps_helper.php, booking_helper.php, shortcodes_helper.php).
	 *
	 * @param \LatePoint\Misc\BookingRequest $booking_request
	 * @return bool
	 */
	public function is_service_hidden( \LatePoint\Misc\BookingRequest $booking_request ): bool {
		if ( ! $booking_request->service_id ) {
			return false;
		}

		return ( new OsServiceModel( $booking_request->service_id ) )->is_hidden();
	}

	/**
	 * Bookable slots for the requested day.
	 *
	 * @param \LatePoint\Misc\BookingRequest $booking_request
	 * @return array
	 */
	public function get_bookable_slots( \LatePoint\Misc\BookingRequest $booking_request ): array {
		if ( $this->is_requested_day_in_the_past( $booking_request ) || $this->is_service_hidden( $booking_request ) ) {
			return [];
		}

		$requested_date = new OsWpDateTime( $booking_request->start_date );
		// clones — get_resources_grouped_by_day() mutates the dates it receives.
		$resources = OsResourceHelper::get_resources_grouped_by_day( $booking_request, clone $requested_date, clone $requested_date );

		$slots_by_time = [];
		foreach ( $resources[ $requested_date->format( 'Y-m-d' ) ] ?? [] as $resource ) {
			foreach ( $resource->slots as $slot ) {
				if ( ! $slot->can_accomodate( $booking_request->total_attendees ) ) {
					continue;
				}
				// an agent has one resource per location; list the slot once.
				$slots_by_time[ $slot->start_time ][ $resource->agent_id ] = [
					'start_time' => (int) $slot->start_time,
					'end_time'   => (int) $slot->start_time + (int) $booking_request->duration,
					'agent_id'   => (int) $resource->agent_id,
				];
			}
		}
		ksort( $slots_by_time, SORT_NUMERIC );

		$slots = [];
		foreach ( $slots_by_time as $slots_for_time ) {
			foreach ( $slots_for_time as $slot_data ) {
				$slots[] = $slot_data;
			}
		}

		return $slots;
	}

	/**
	 * Whether a specific slot is currently bookable.
	 *
	 * @param \LatePoint\Misc\BookingRequest $booking_request
	 * @return bool
	 */
	public function is_slot_available( \LatePoint\Misc\BookingRequest $booking_request ): bool {
		return ! $this->is_requested_day_in_the_past( $booking_request )
			&& ! $this->is_service_hidden( $booking_request )
			&& OsBookingHelper::is_booking_request_available( $booking_request );
	}

	/**
	 * Appointments that overlap the requested slot. Appointment records are only revealed
	 * to callers who can already view bookings — availability itself is public information,
	 * conflicting-booking detail is not.
	 *
	 * @param \LatePoint\Misc\BookingRequest $booking_request
	 * @return array
	 */
	public function get_conflicting_bookings( \LatePoint\Misc\BookingRequest $booking_request ): array {
		if ( ! OsRolesHelper::can_user( 'booking__view' ) ) {
			return [];
		}

		$filter = new \LatePoint\Misc\Filter(
			[
				'date_from'   => $booking_request->start_date,
				'service_id'  => $booking_request->service_id,
				'agent_id'    => $booking_request->agent_id,
				'location_id' => $booking_request->location_id,
				'statuses'    => OsBookingHelper::get_timeslot_blocking_statuses(),
			]
		);
		$filter = OsRolesHelper::filter_allowed_records_from_arguments_or_filter( $filter );

		// same collision window build_bookable_slots() uses — end is derived from duration
		// because calculate_end_time() wraps it around midnight.
		$slot_start_time = $booking_request->get_start_time_with_buffer();
		$slot_end_time   = $booking_request->start_time + $booking_request->duration + $booking_request->buffer_after;

		$conflicts = [];
		foreach ( OsBookingHelper::get_bookings( $filter, true ) as $booking ) {
			$is_overlapping = OsBookingHelper::is_period_overlapping(
				$slot_start_time,
				$slot_end_time,
				(int) $booking->start_time - (int) $booking->buffer_before,
				(int) $booking->end_time + (int) $booking->buffer_after
			);
			if ( $is_overlapping ) {
				$conflicts[] = [
					'id'          => (int) $booking->id,
					'service_id'  => (int) $booking->service_id,
					'agent_id'    => (int) $booking->agent_id,
					'location_id' => (int) $booking->location_id,
					'start_time'  => (int) $booking->start_time,
					'end_time'    => (int) $booking->end_time,
					'status'      => $booking->status,
				];
			}
		}

		return $conflicts;
	}

	/**
	 * "Which agents can take this slot" — as opposed to get_bookable_slots(), which answers
	 * "what slots are open". Used by GET /agents/availability.
	 *
	 * @param array $args {service_id?, location_id?, date?, start_time?, duration?, limit?}
	 * @return array{filters: array, agents: OsAgentModel[], is_available: array<int,bool|null>}
	 *         $is_available is keyed by agent_id; a missing key (or null) means it wasn't computed.
	 */
	public function agents_availability( array $args ): array {
		$service_id  = ! empty( $args['service_id'] ) ? absint( $args['service_id'] ) : false;
		$location_id = ! empty( $args['location_id'] ) ? absint( $args['location_id'] ) : false;
		$limit       = ! empty( $args['limit'] ) ? min( absint( $args['limit'] ), 100 ) : 50;

		// start_time accepts "HH:MM" or raw minutes-from-midnight, same as POST /bookings.
		if ( isset( $args['start_time'] ) ) {
			$args['start_time'] = OsApiQuery::parse_minutes_from_midnight( $args['start_time'] );
		}

		$agent_ids   = OsAgentHelper::get_agent_ids_for_service_and_location( $service_id, $location_id );
		$agent_model = new OsAgentModel();
		$agent_model->filter_allowed_records();
		$agent_model->where( [ 'status' => LATEPOINT_AGENT_STATUS_ACTIVE ] );
		if ( ! empty( $agent_ids ) ) {
			$agent_model->where_in( 'id', $agent_ids );
		} else {
			// no service/location filter and no connections at all — nothing to list.
			$agent_model->where( [ 'id' => 0 ] );
		}
		$agents = OsApiQuery::normalize_to_array(
			$agent_model->order_by( 'first_name asc, last_name asc' )->set_limit( $limit )->get_results_as_models()
		);

		$is_available = [];
		if ( ! empty( $args['date'] ) && $service_id ) {
			// One get_bookable_slots() call across all agents for the day, whether a specific
			// start_time was requested (filter the result down to it) or not (any slot counts) —
			// avoids a per-agent is_slot_available() query for each of up to $limit agents.
			$booking_request = $this->build_booking_request(
				array_merge( $args, [ 'agent_id' => LATEPOINT_ANY_AGENT ] )
			);
			if ( ! is_wp_error( $booking_request ) ) {
				$slots = $this->get_bookable_slots( $booking_request );
				if ( ! empty( $args['start_time'] ) ) {
					$requested_start_time = absint( $args['start_time'] );
					$slots                = array_filter(
						$slots,
						static function ( $slot ) use ( $requested_start_time ) {
							return (int) $slot['start_time'] === $requested_start_time;
						}
					);
				}
				$available_agent_ids = wp_list_pluck( $slots, 'agent_id' );
				foreach ( $agents as $agent ) {
					$is_available[ $agent->id ] = in_array( (int) $agent->id, $available_agent_ids, true );
				}
			}
		}

		return [
			'filters'      => [
				'service_id'  => $service_id ?: null,
				'location_id' => $location_id ?: null,
				'date'        => $args['date'] ?? null,
				'start_time'  => isset( $args['start_time'] ) ? absint( $args['start_time'] ) : null,
				'duration'    => isset( $args['duration'] ) ? absint( $args['duration'] ) : null,
			],
			'agents'       => $agents,
			'is_available' => $is_available,
		];
	}
}
