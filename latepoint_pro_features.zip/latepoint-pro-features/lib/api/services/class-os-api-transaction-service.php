<?php
/**
 * Transaction (payments) write service — create (a manual ledger entry, not a gateway
 * charge), a narrow update, and delete.
 *
 * update() only touches metadata/status fields, never amount/order_id/customer_id/kind/
 * payment_portion — see its own doc-comment for why each is locked. Refunds are explicitly
 * out of scope: they delegate to apply_filters('latepoint_process_refund', ...),
 * gateway-specific logic that silently no-ops without a connected gateway — that needs its
 * own design, not a bolt-on here.
 *
 * @package LatePoint\Api
 * @since   5.4.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class OsApiTransactionService {

	/**
	 * Records a payment that already happened elsewhere (cash, bank transfer, an
	 * off-platform charge) as a ledger entry. Does not call any payment gateway.
	 *
	 * Mirrors the admin's manual-payment path, orders_controller.php::create_or_update()
	 * L317-347 — same force-set of order_id/customer_id/status, same
	 * latepoint_transaction_created hook. Also calls $order->determine_payment_status()
	 * afterward, which that admin path does not — a deliberate improvement, not something
	 * carried over. Leaving payment_status stale is a worse default for a freestanding API
	 * create than it is for the admin form.
	 *
	 * @param array $input
	 * @return OsTransactionModel|WP_Error
	 */
	public function create( array $input ) {
		if ( empty( $input['order_id'] ) ) {
			return new WP_Error(
				'latepoint_rest_missing_order_id',
				__( 'order_id is required.', 'latepoint' ),
				[ 'status' => 400 ]
			);
		}
		list( $order, $error ) = OsApiQuery::find_scoped( 'OsOrderModel', absint( $input['order_id'] ) );
		if ( $error ) {
			return OsApiQuery::NOT_FOUND === $error
				? new WP_Error( 'latepoint_rest_order_not_found', __( 'Order not found.', 'latepoint' ), [ 'status' => 404 ] )
				: new WP_Error( 'latepoint_rest_forbidden', __( 'You cannot access this order.', 'latepoint' ), [ 'status' => 403 ] );
		}
		/** @var OsOrderModel $order find_scoped() only returns null alongside a non-null $error. */

		$amount = isset( $input['amount'] ) ? (float) $input['amount'] : 0;
		if ( $amount <= 0 ) {
			return new WP_Error(
				'latepoint_rest_invalid_amount',
				__( 'amount must be a positive number.', 'latepoint' ),
				[ 'status' => 422 ]
			);
		}

		$payment_portion = ! empty( $input['payment_portion'] ) ? sanitize_text_field( $input['payment_portion'] ) : LATEPOINT_PAYMENT_PORTION_FULL;
		if ( ! array_key_exists( $payment_portion, OsPaymentsHelper::get_payment_portions_list() ) ) {
			return new WP_Error(
				'latepoint_rest_invalid_payment_portion',
				__( 'Invalid payment_portion.', 'latepoint' ),
				[ 'status' => 422 ]
			);
		}

		$kind = ! empty( $input['kind'] ) ? sanitize_text_field( $input['kind'] ) : LATEPOINT_TRANSACTION_KIND_CAPTURE;
		if ( ! in_array( $kind, [ LATEPOINT_TRANSACTION_KIND_CAPTURE, LATEPOINT_TRANSACTION_KIND_AUTHORIZATION, LATEPOINT_TRANSACTION_KIND_VOID ], true ) ) {
			return new WP_Error( 'latepoint_rest_invalid_kind', __( 'Invalid kind.', 'latepoint' ), [ 'status' => 422 ] );
		}

		$status = ! empty( $input['status'] ) ? sanitize_text_field( $input['status'] ) : LATEPOINT_TRANSACTION_STATUS_SUCCEEDED;
		if ( ! in_array( $status, [ LATEPOINT_TRANSACTION_STATUS_SUCCEEDED, LATEPOINT_TRANSACTION_STATUS_PROCESSING ], true ) ) {
			// LATEPOINT_TRANSACTION_STATUS_FAILED is deliberately not creatable: nothing in
			// this codebase filters a transaction's contribution to
			// OsOrderModel::get_total_amount_paid_from_transactions() by status, so a "failed"
			// transaction would still count fully toward payment_status — a logically
			// incoherent state nothing else in the app can currently produce (the only prior
			// write path, orders_controller.php, hardcodes status=succeeded unconditionally).
			// The real fix is filtering that sum by status; that's a model-layer change and
			// out of scope here.
			return new WP_Error( 'latepoint_rest_invalid_status', __( 'Invalid status. Only succeeded/processing may be set on create.', 'latepoint' ), [ 'status' => 422 ] );
		}

		$transaction                  = new OsTransactionModel();
		$transaction->order_id        = $order->id;
		$transaction->customer_id     = $order->customer_id;
		$transaction->processor       = ! empty( $input['processor'] ) ? sanitize_text_field( $input['processor'] ) : 'other';
		$transaction->payment_method  = ! empty( $input['payment_method'] ) ? sanitize_text_field( $input['payment_method'] ) : LATEPOINT_PAYMENT_METHOD_LOCAL;
		$transaction->payment_portion = $payment_portion;
		$transaction->kind            = $kind;
		$transaction->status          = $status;
		$transaction->amount          = $amount;
		$transaction->token           = ! empty( $input['token'] ) ? sanitize_text_field( $input['token'] ) : '';
		$transaction->notes           = ! empty( $input['notes'] ) ? sanitize_textarea_field( $input['notes'] ) : '';
		if ( ! empty( $input['invoice_id'] ) ) {
			$transaction->invoice_id = absint( $input['invoice_id'] );
		}

		if ( ! $transaction->save() ) {
			return new WP_Error(
				'latepoint_rest_payment_create_failed',
				__( 'Failed to create payment.', 'latepoint' ),
				[ 'status' => 500 ]
			);
		}

		/** This filter is documented in lib/controllers/orders_controller.php */
		do_action( 'latepoint_transaction_created', $transaction );
		$order->determine_payment_status();

		return $transaction;
	}

	/**
	 * Fields intentionally NOT editable, and why: amount is already counted into the order's
	 * paid total with no safe recalculation path for changing it after the fact (unlike
	 * create(), which counts it exactly once); order_id/customer_id are identity fields with
	 * no admin precedent for moving a transaction between orders (delete and re-create
	 * instead); kind is sourced from real gateway responses (stripe_connect_helper.php,
	 * paypal_connect_helper.php, razorpay_connect_helper.php all set it from what the gateway
	 * actually returned) — flipping capture/void via the API with no matching gateway-side
	 * action would create a phantom state; payment_portion is tied to order-level
	 * partial-payment reporting and is closed for now as the conservative first pass, not a
	 * hard limit.
	 */
	const LOCKED_FIELDS = [ 'amount', 'order_id', 'customer_id', 'kind', 'payment_portion' ];

	/**
	 * The one real use case for editing a transaction: async gateway confirmation. Create it
	 * as "processing" when a charge is initiated, then flip status to "succeeded"/"failed"
	 * once a webhook/callback confirms — the same lifecycle payments_helper.php's gateway
	 * capture code already models. Everything else editable here is corrective metadata
	 * (token/notes/receipt_number/processor/payment_method), never summed into anything.
	 *
	 * No latepoint_transaction_updated-style hook exists anywhere in the codebase (confirmed
	 * by grep) and none is invented here — same precedent as locations and transaction
	 * delete: only fire hooks that mirror something real.
	 *
	 * @param OsTransactionModel $transaction Loaded, scoped record to update.
	 * @param array               $input
	 * @return OsTransactionModel|WP_Error
	 */
	public function update( OsTransactionModel $transaction, array $input ) {
		$locked_fields_present = array_intersect( self::LOCKED_FIELDS, array_keys( $input ) );
		if ( ! empty( $locked_fields_present ) ) {
			return new WP_Error(
				'latepoint_rest_payment_field_locked',
				sprintf(
					/* translators: %s: comma-separated list of field names */
					__( 'These fields cannot be changed after creation: %s. Delete and create a new payment instead.', 'latepoint' ),
					implode( ', ', $locked_fields_present )
				),
				[ 'status' => 422 ]
			);
		}

		if ( isset( $input['status'] ) ) {
			$status = sanitize_text_field( $input['status'] );
			if ( ! in_array( $status, [ LATEPOINT_TRANSACTION_STATUS_SUCCEEDED, LATEPOINT_TRANSACTION_STATUS_PROCESSING, LATEPOINT_TRANSACTION_STATUS_FAILED ], true ) ) {
				return new WP_Error( 'latepoint_rest_invalid_status', __( 'Invalid status.', 'latepoint' ), [ 'status' => 422 ] );
			}
			$transaction->status = $status;
		}
		if ( isset( $input['processor'] ) ) {
			$transaction->processor = sanitize_text_field( $input['processor'] );
		}
		if ( isset( $input['payment_method'] ) ) {
			$transaction->payment_method = sanitize_text_field( $input['payment_method'] );
		}
		if ( isset( $input['token'] ) ) {
			$transaction->token = sanitize_text_field( $input['token'] );
		}
		if ( isset( $input['notes'] ) ) {
			$transaction->notes = sanitize_textarea_field( $input['notes'] );
		}
		if ( isset( $input['receipt_number'] ) ) {
			$transaction->receipt_number = sanitize_text_field( $input['receipt_number'] );
		}

		if ( ! $transaction->save() ) {
			return new WP_Error(
				'latepoint_rest_payment_update_failed',
				__( 'Failed to update payment.', 'latepoint' ),
				[ 'status' => 500 ]
			);
		}

		// Matches create()'s call. Note: neither this nor the admin's own totals
		// (OsOrderModel::get_total_amount_paid_from_transactions(), order_model.php:153)
		// filter by transaction status today, so flipping status alone doesn't change the
		// counted total yet — a pre-existing gap in the underlying model, not fixed here.
		$order = new OsOrderModel( $transaction->order_id );
		if ( ! $order->is_new_record() ) {
			$order->determine_payment_status();
		}

		return $transaction;
	}

	/**
	 * @param OsTransactionModel $transaction Loaded, scoped record to delete.
	 * @return true|WP_Error
	 */
	public function delete( OsTransactionModel $transaction ) {
		// Mirrors transactions_controller.php::destroy(). OsTransactionModel doesn't override
		// delete(), so this goes through OsModel's own base implementation, which fires the
		// generic latepoint_model_deleted($this, $id) hook (model.php:637-657) — nothing in
		// either plugin currently listens to it (verified by grep), but it's not a no-op hook.
		if ( ! $transaction->delete() ) {
			return new WP_Error(
				'latepoint_rest_payment_delete_failed',
				__( 'Failed to delete payment.', 'latepoint' ),
				[ 'status' => 500 ]
			);
		}

		return true;
	}
}
