<?php
/**
 * Booking write service — the real booking-creation pipeline, for the REST API.
 *
 * This deliberately does NOT reuse lib/abilities/bookings/create-booking.php. That ability
 * fires no lifecycle hooks at all (verified: `grep -rn "do_action" lib/abilities/` returns
 * nothing), never calls is_bookable() (so it allows double-booking and never resolves
 * "any agent"/"any location"), never calls set_utc_datetimes() (so start_datetime_utc is
 * left NULL), and never recalculates order item prices (so its orders total NULL). Exposing
 * that behavior over a public API would make those bugs permanent contract.
 *
 * Instead this mirrors the two pipelines that actually run in production:
 *  - the wizard/order-intent path (lib/models/order_intent_model.php convert_to_order(),
 *    lib/helpers/steps_helper.php) for is_bookable() + set_utc_datetimes() + buffers, and
 *  - the admin quick-order path (lib/controllers/orders_controller.php create_or_update())
 *    for the order-item save-before/save-after sequencing around recalculate_prices().
 *
 * @package LatePoint\Api
 * @since   5.4.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class OsApiBookingService {

	/**
	 * @param array $input Decoded JSON request body.
	 * @return OsBookingModel|WP_Error
	 */
	public function create( array $input ) {
		$booking = new OsBookingModel();
		// A plain int read of a caller-supplied id, not a save — safe to do before resolving
		// the real customer. 0 means a new customer is about to be created (see below).
		$existing_customer_id = ! empty( $input['customer_id'] ) ? absint( $input['customer_id'] ) : 0;
		$booking->customer_id = $existing_customer_id;
		$booking->service_id  = (int) ( $input['service_id'] ?? 0 );
		$booking->agent_id    = $this->parse_resource_id( $input['agent_id'] ?? null, LATEPOINT_ANY_AGENT );
		$booking->location_id = $this->parse_resource_id( $input['location_id'] ?? null, LATEPOINT_ANY_LOCATION );

		list( $start_date, $start_time, $error ) = $this->parse_start( $input );
		if ( $error ) {
			return $error;
		}
		$booking->start_date = $start_date;
		$booking->start_time = $start_time;

		if ( ! empty( $input['duration'] ) ) {
			$booking->duration = absint( $input['duration'] );
		}

		if ( ! empty( $input['timezone'] ) ) {
			// converts start_date/start_time from the given timezone into site timezone,
			// and records it as customer_timezone — same as the public booking wizard does.
			$booking->convert_start_datetime_into_server_timezone( sanitize_text_field( $input['timezone'] ) );
		}

		$booking->set_buffers();
		$booking->calculate_end_date_and_time();

		$force = ! empty( $input['force'] ) && OsAuthHelper::get_current_user()->backend_user_type === LATEPOINT_USER_TYPE_ADMIN;
		if ( $force ) {
			if ( $booking->agent_id == LATEPOINT_ANY_AGENT || $booking->location_id == LATEPOINT_ANY_LOCATION ) {
				return new WP_Error(
					'latepoint_rest_invalid_request',
					__( '"force" requires an explicit agent_id and location_id.', 'latepoint' ),
					[ 'status' => 400 ]
				);
			}
			// force skips the availability/conflict check only — identity and date/time
			// fields are still validated, matching what is_bookable() would otherwise do.
			if ( ! $booking->validate( false, [ 'order_item_id', 'status', 'customer_id' ] ) ) {
				return new WP_Error(
					'latepoint_rest_validation_failed',
					implode( ', ', $booking->get_error_messages() ),
					[ 'status' => 422 ]
				);
			}
		} else {
			// Runs before resolve_customer() on purpose: a brand-new customer (no
			// customer_id given) can never already hold a conflicting booking, so there's
			// nothing to lose by checking availability first — and everything to lose by
			// checking it after, since resolve_customer() would have already saved a new
			// customer row that a 409 here can't roll back. skip_customer_check is only
			// false when there's a real pre-existing customer_id to check against.
			//
			// is_bookable() resolves LATEPOINT_ANY_AGENT/LATEPOINT_ANY_LOCATION, rejects
			// hidden services, and runs conflict detection — see booking_model.php:503.
			if ( ! $booking->is_bookable(
				[
					'skip_customer_check' => empty( $existing_customer_id ),
					'log_errors'          => false,
				]
			) ) {
				return new WP_Error(
					'latepoint_rest_slot_unavailable',
					implode( ', ', $booking->get_error_messages() ) ?: __( 'The requested time slot is not available.', 'latepoint' ),
					[ 'status' => 409 ]
				);
			}
		}

		$scope_error = $this->check_resource_scope( $booking );
		if ( $scope_error ) {
			return $scope_error;
		}

		list( $customer, $error ) = $this->resolve_customer( $input );
		if ( $error ) {
			return $error;
		}
		$booking->customer_id = (int) $customer->id;

		list( $order, $is_new_order, $error ) = $this->resolve_order( $input, $customer );
		if ( $error ) {
			return $error;
		}

		$order_item           = new OsOrderItemModel();
		$order_item->order_id = $order->id;
		$order_item->variant  = LATEPOINT_ITEM_VARIANT_BOOKING;
		if ( ! $order_item->save() ) {
			if ( $is_new_order ) {
				$order->delete();
			}

			return new WP_Error(
				'latepoint_rest_order_item_save_failed',
				implode( ', ', $order_item->get_error_messages() ),
				[ 'status' => 422 ]
			);
		}

		$booking->order_item_id = $order_item->id;
		if ( ! $booking->save() ) {
			$order_item->delete();
			if ( $is_new_order ) {
				$order->delete();
			}

			return new WP_Error(
				'latepoint_rest_booking_save_failed',
				implode( ', ', $booking->get_error_messages() ),
				[ 'status' => 422 ]
			);
		}

		// this is the step the abilities' create-booking omits, and why its orders total NULL.
		$order_item->item_data = $booking->generate_item_data();
		$order_item->recalculate_prices();
		$order_item->save();

		$this->recalculate_order_totals( $order );

		$suppress_notifications = ! empty( $input['suppress_notifications'] );
		if ( $suppress_notifications ) {
			remove_action( 'latepoint_booking_created', [ 'OsProcessJobsHelper', 'handle_booking_created' ], 12 );
		}

		/** This action is documented in lib/controllers/orders_controller.php */
		do_action( 'latepoint_booking_created', $booking );

		if ( $suppress_notifications ) {
			add_action( 'latepoint_booking_created', [ 'OsProcessJobsHelper', 'handle_booking_created' ], 12 );
		}

		if ( $is_new_order ) {
			OsInvoicesHelper::create_invoices_for_new_order( $order );
			/** This action is documented in lib/controllers/orders_controller.php */
			do_action( 'latepoint_order_created', $order );
		}

		$order->determine_payment_status();

		return new OsBookingModel( $booking->id );
	}

	/**
	 * @param OsBookingModel $booking Loaded, scoped record to update.
	 * @param array          $input   Partial update payload.
	 * @return OsBookingModel|WP_Error
	 */
	public function update( OsBookingModel $booking, array $input ) {
		$old_booking = clone $booking;

		$needs_recheck = false;

		if ( isset( $input['service_id'] ) ) {
			$booking->service_id = (int) $input['service_id'];
			$needs_recheck       = true;
		}
		if ( array_key_exists( 'agent_id', $input ) ) {
			$booking->agent_id = $this->parse_resource_id( $input['agent_id'], LATEPOINT_ANY_AGENT );
			$needs_recheck     = true;
		}
		if ( array_key_exists( 'location_id', $input ) ) {
			$booking->location_id = $this->parse_resource_id( $input['location_id'], LATEPOINT_ANY_LOCATION );
			$needs_recheck        = true;
		}
		if ( isset( $input['duration'] ) ) {
			$booking->duration = absint( $input['duration'] );
			$needs_recheck     = true;
		}
		if ( isset( $input['start_date'] ) || isset( $input['start_time'] ) || isset( $input['minutes_from_midnight'] ) ) {
			list( $start_date, $start_time, $error ) = $this->parse_start( array_merge( $booking->get_data_vars(), $input ) );
			if ( $error ) {
				return $error;
			}
			$booking->start_date = $start_date;
			$booking->start_time = $start_time;
			$needs_recheck       = true;
		}
		if ( isset( $input['status'] ) ) {
			$status = sanitize_text_field( $input['status'] );
			if ( ! in_array( $status, array_keys( OsBookingHelper::get_statuses_list() ), true ) ) {
				return new WP_Error( 'latepoint_rest_invalid_status', __( 'Invalid status.', 'latepoint' ), [ 'status' => 422 ] );
			}
			$booking->status = $status;
		}
		if ( isset( $input['customer_comment'] ) ) {
			$order = $booking->get_order();
			if ( $order && ! $order->is_new_record() ) {
				$order->update_attributes( [ 'customer_comment' => sanitize_textarea_field( $input['customer_comment'] ) ] );
			}
		}

		if ( $needs_recheck ) {
			$booking->set_buffers();
			$booking->calculate_end_date_and_time();
			if ( ! $booking->is_bookable(
				[
					'skip_customer_check' => false,
					'log_errors'          => false,
				]
			) ) {
				return new WP_Error(
					'latepoint_rest_slot_unavailable',
					implode( ', ', $booking->get_error_messages() ) ?: __( 'The requested time slot is not available.', 'latepoint' ),
					[ 'status' => 409 ]
				);
			}

			$scope_error = $this->check_resource_scope( $booking );
			if ( $scope_error ) {
				return $scope_error;
			}
		}

		if ( ! $booking->save() ) {
			return new WP_Error(
				'latepoint_rest_booking_save_failed',
				implode( ', ', $booking->get_error_messages() ),
				[ 'status' => 422 ]
			);
		}

		/** This action is documented in lib/controllers/orders_controller.php */
		do_action( 'latepoint_booking_updated', $booking, $old_booking );
		if ( $old_booking->status !== $booking->status ) {
			/** This action is documented in lib/controllers/orders_controller.php */
			do_action( 'latepoint_booking_change_status', $booking, $old_booking );
		}

		$order_item = $booking->get_order_item();
		if ( $order_item && ! $order_item->is_new_record() ) {
			$order_item->item_data = $booking->generate_item_data();
			$order_item->recalculate_prices();
			$order_item->save();
			$order = $booking->get_order();
			if ( $order && ! $order->is_new_record() ) {
				$this->recalculate_order_totals( $order );
			}
		}

		return new OsBookingModel( $booking->id );
	}

	/**
	 * @param OsBookingModel $booking Loaded, scoped record to delete.
	 * @return true|WP_Error
	 */
	public function delete( OsBookingModel $booking ) {
		$booking_id = (int) $booking->id;

		/** This action is documented in lib/controllers/orders_controller.php */
		do_action( 'latepoint_booking_will_be_deleted', $booking_id );

		if ( ! $booking->delete() ) {
			return new WP_Error(
				'latepoint_rest_booking_delete_failed',
				__( 'Failed to delete booking.', 'latepoint' ),
				[ 'status' => 500 ]
			);
		}

		/** This action is documented in lib/controllers/orders_controller.php */
		do_action( 'latepoint_booking_deleted', $booking_id );

		return true;
	}

	// ------------------------------------------------------------------

	/**
	 * @param array $input
	 * @return array{0: OsCustomerModel|null, 1: WP_Error|null}
	 */
	private function resolve_customer( array $input ): array {
		if ( ! empty( $input['customer_id'] ) ) {
			list( $customer, $error ) = OsApiQuery::find_scoped( 'OsCustomerModel', (int) $input['customer_id'] );
			if ( $error ) {
				return [
					null,
					new WP_Error(
						OsApiQuery::FORBIDDEN === $error ? 'latepoint_rest_forbidden' : 'latepoint_rest_customer_not_found',
						OsApiQuery::FORBIDDEN === $error
											? __( 'You do not have permission to book on behalf of this customer.', 'latepoint' )
											: __( 'Customer not found.', 'latepoint' ),
						[ 'status' => OsApiQuery::FORBIDDEN === $error ? 403 : 404 ]
					),
				];
			}

			return [ $customer, null ];
		}

		if ( empty( $input['customer'] ) || ! is_array( $input['customer'] ) ) {
			return [
				null,
				new WP_Error(
					'latepoint_rest_missing_customer',
					__( 'Either customer_id or a customer object is required.', 'latepoint' ),
					[ 'status' => 400 ]
				),
			];
		}

		$customer = new OsCustomerModel();
		// admin scope, matching orders_controller.php: backend/API callers may set any
		// customer-editable field, but wordpress_user_id mass-assignment is never allowed here.
		$customer_params = $input['customer'];
		unset( $customer_params['wordpress_user_id'] );
		// id/password: same guards as OsApiCustomerService::create() — an id would let
		// set_data() silently load and edit an arbitrary existing customer with no ownership
		// check, and password is never hashed downstream.
		unset( $customer_params['id'] );
		unset( $customer_params['password'] );
		$customer->set_data( $customer_params, LATEPOINT_PARAMS_SCOPE_ADMIN );
		if ( ! $customer->save() ) {
			return [
				null,
				new WP_Error(
					'latepoint_rest_customer_save_failed',
					implode( ', ', $customer->get_error_messages() ),
					[ 'status' => 422 ]
				),
			];
		}

		/** This action is documented in lib/controllers/customers_controller.php */
		do_action( 'latepoint_customer_created', $customer );

		return [ $customer, null ];
	}

	/**
	 * @param array           $input
	 * @param OsCustomerModel $customer
	 * @return array{0: OsOrderModel|null, 1: bool, 2: WP_Error|null}
	 */
	private function resolve_order( array $input, OsCustomerModel $customer ): array {
		if ( ! empty( $input['order_id'] ) ) {
			list( $order, $error ) = OsApiQuery::find_scoped( 'OsOrderModel', (int) $input['order_id'] );
			if ( $error ) {
				return [
					null,
					false,
					new WP_Error(
						OsApiQuery::FORBIDDEN === $error ? 'latepoint_rest_forbidden' : 'latepoint_rest_order_not_found',
						OsApiQuery::FORBIDDEN === $error
											? __( 'You do not have permission to add to this order.', 'latepoint' )
											: __( 'Order not found.', 'latepoint' ),
						[ 'status' => OsApiQuery::FORBIDDEN === $error ? 403 : 404 ]
					),
				];
			}

			return [ $order, false, null ];
		}

		$order              = new OsOrderModel();
		$order->customer_id = (int) $customer->id;
		if ( ! empty( $input['customer_comment'] ) ) {
			$order->customer_comment = sanitize_textarea_field( $input['customer_comment'] );
		}
		$order->set_initial_payment_data_value( 'time', LATEPOINT_PAYMENT_TIME_LATER, false );

		if ( ! $order->save() ) {
			return [
				null,
				false,
				new WP_Error(
					'latepoint_rest_order_save_failed',
					implode( ', ', $order->get_error_messages() ),
					[ 'status' => 422 ]
				),
			];
		}

		return [ $order, true, null ];
	}

	/**
	 * is_bookable() resolves LATEPOINT_ANY_AGENT/LATEPOINT_ANY_LOCATION to concrete IDs before
	 * this runs, so a restricted-role caller can't bypass scoping by submitting "any" — the
	 * values checked here are always the resolved, authoritative ones. filter_allowed_records()
	 * (used on every read path in this API) only scopes queries; there is no write-side
	 * equivalent elsewhere in the codebase, including the admin booking form, so this can't
	 * be delegated to is_bookable() itself without also rejecting anonymous public bookings
	 * (an anonymous User has empty allowed_records for all three types).
	 *
	 * @param OsBookingModel $booking Resolved service/agent/location already applied.
	 * @return WP_Error|null
	 */
	private function check_resource_scope( OsBookingModel $booking ): ?WP_Error {
		$user = OsAuthHelper::get_current_user();
		$ids  = [
			'agent'    => $booking->agent_id,
			'service'  => $booking->service_id,
			'location' => $booking->location_id,
		];
		foreach ( $ids as $model_type => $id ) {
			if ( $id && ! $user->check_if_allowed_record_id( $id, $model_type ) ) {
				return new WP_Error(
					'latepoint_rest_forbidden',
					__( 'You do not have permission to book this agent, service, or location.', 'latepoint' ),
					[ 'status' => 403 ]
				);
			}
		}

		return null;
	}

	private function recalculate_order_totals( OsOrderModel $order ): void {
		$order->update_attributes(
			[
				'total'    => $order->recalculate_total(),
				'subtotal' => $order->recalculate_subtotal(),
			]
		);
	}

	/**
	 * LATEPOINT_ANY_AGENT/LATEPOINT_ANY_LOCATION are string sentinels ('any'), not ints —
	 * is_bookable() resolves them to a real numeric ID before the booking is saved.
	 *
	 * @param mixed  $raw
	 * @param string $any_sentinel LATEPOINT_ANY_AGENT or LATEPOINT_ANY_LOCATION.
	 * @return int|string
	 */
	private function parse_resource_id( $raw, string $any_sentinel ) {
		if ( empty( $raw ) || 'any' === $raw || '-1' === (string) $raw ) {
			return $any_sentinel;
		}

		return absint( $raw );
	}

	/**
	 * Accepts either a "time" HH:MM string or a raw minutes_from_midnight integer.
	 *
	 * @param array $input
	 * @return array{0: string|null, 1: int|null, 2: WP_Error|null}
	 */
	private function parse_start( array $input ): array {
		$start_date = sanitize_text_field( $input['start_date'] ?? '' );
		if ( ! OsRestController::validate_date_param( $start_date ) ) {
			return [
				null,
				null,
				new WP_Error(
					'latepoint_rest_invalid_date',
					__( 'start_date must be in Y-m-d format.', 'latepoint' ),
					[ 'status' => 400 ]
				),
			];
		}

		if ( isset( $input['minutes_from_midnight'] ) ) {
			$minutes = absint( $input['minutes_from_midnight'] );
		} elseif ( isset( $input['start_time'] ) ) {
			$minutes = OsApiQuery::parse_minutes_from_midnight( $input['start_time'] );
		} else {
			return [
				null,
				null,
				new WP_Error(
					'latepoint_rest_invalid_request',
					__( 'start_time (HH:MM or minutes from midnight) is required.', 'latepoint' ),
					[ 'status' => 400 ]
				),
			];
		}

		if ( $minutes < 0 || $minutes > 1439 ) {
			return [
				null,
				null,
				new WP_Error(
					'latepoint_rest_invalid_request',
					__( 'start_time must be within a single day (0-1439 minutes).', 'latepoint' ),
					[ 'status' => 400 ]
				),
			];
		}

		return [ $start_date, $minutes, null ];
	}
}
