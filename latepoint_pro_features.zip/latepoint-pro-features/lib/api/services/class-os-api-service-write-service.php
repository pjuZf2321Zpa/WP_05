<?php
/**
 * Service write service — mirrors lib/controllers/services_controller.php::update()
 * (used for both create and update there) so REST writes produce the same activity-log
 * entry and latepoint_service_saved hook a real admin edit does.
 *
 * Deliberately does not touch service_extra/duration/agent-location assignment or custom
 * work-period schedules (save_durations(), save_agents_and_locations(), the custom-schedule
 * save the admin form also does) — this service manages the service record itself, the same
 * "resource shell, not its relations" boundary already applied to orders' items.
 *
 * @package LatePoint\Api
 * @since   5.4.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class OsApiServiceWriteService {

	/**
	 * @param array $input
	 * @return OsServiceModel|WP_Error
	 */
	public function create( array $input ) {
		return $this->save( new OsServiceModel(), $input, true );
	}

	/**
	 * @param OsServiceModel $service Loaded, scoped record to update.
	 * @param array          $input   Partial update payload.
	 * @return OsServiceModel|WP_Error
	 */
	public function update( OsServiceModel $service, array $input ) {
		return $this->save( $service, $input, false );
	}

	/**
	 * @param OsServiceModel $service
	 * @param array          $input
	 * @param bool           $is_new_record
	 * @return OsServiceModel|WP_Error
	 */
	private function save( OsServiceModel $service, array $input, bool $is_new_record ) {
		// id: on create, OsModel::set_data() auto-loads an existing record by id with no
		// ownership check if one is present in $input — stripped to prevent a caller with
		// only service__create from silently editing an arbitrary service.
		unset( $input['id'] );

		if ( isset( $input['status'] ) && ! in_array( $input['status'], [ LATEPOINT_SERVICE_STATUS_ACTIVE, LATEPOINT_SERVICE_STATUS_DISABLED ], true ) ) {
			return new WP_Error( 'latepoint_rest_invalid_status', __( 'Invalid status.', 'latepoint' ), [ 'status' => 422 ] );
		}

		$service->set_data( $input );

		if ( ! $service->save() ) {
			return new WP_Error(
				'latepoint_rest_service_save_failed',
				implode( ', ', $service->get_error_messages() ),
				[ 'status' => 422 ]
			);
		}

		/** This action is documented in lib/controllers/services_controller.php */
		do_action( 'latepoint_service_saved', $service, $is_new_record, $input );
		OsActivitiesHelper::create_activity(
			[
				'code'       => $is_new_record ? 'service_created' : 'service_updated',
				'service_id' => $service->id,
			]
		);

		return new OsServiceModel( $service->id );
	}

	/**
	 * @param OsServiceModel $service Loaded, scoped record to delete.
	 * @return true|WP_Error
	 */
	public function delete( OsServiceModel $service ) {
		// OsServiceModel::delete() already fires latepoint_service_deleted itself
		// (service_model.php:341) — nothing further to fire here.
		if ( ! $service->delete() ) {
			return new WP_Error(
				'latepoint_rest_service_delete_failed',
				__( 'Failed to delete service.', 'latepoint' ),
				[ 'status' => 500 ]
			);
		}

		return true;
	}
}
