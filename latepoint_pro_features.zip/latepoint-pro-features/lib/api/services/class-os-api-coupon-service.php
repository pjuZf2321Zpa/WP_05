<?php
/**
 * Coupon write service — ports the already-correct logic from
 * lib/abilities/coupons/create-coupon.php, update-coupon.php, and
 * lib/controllers/coupons_controller.php::destroy(), rather than duplicating it ad hoc.
 *
 * Unlike the free plugin's booking abilities, the coupon abilities do not have a
 * lifecycle-hook bug — they already fire latepoint_coupon_created/_updated correctly. This
 * service duplicates that logic (rather than calling the ability classes directly) because
 * the two transports intentionally stay decoupled until the abilities-rewrite phase, where
 * this and the ability logic get consolidated into one shared place for both plugins at once.
 *
 * @package LatePoint\Pro\Api
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class OsApiCouponService {

	/** Integer rule inputs mapped to their stored `rules` key (see apply_rules()). */
	private $int_rule_map = [
		'usage_limit'        => 'limit_total',
		'limit_per_customer' => 'limit_per_customer',
		'limit_per_order'    => 'limit_per_order',
		'orders_more'        => 'orders_more',
		'orders_less'        => 'orders_less',
	];

	/**
	 * @param array $input
	 * @return OsCouponModel|WP_Error
	 */
	public function create( array $input ) {
		$discount_type  = isset( $input['discount_type'] ) ? sanitize_text_field( $input['discount_type'] ) : '';
		$discount_value = isset( $input['discount_value'] ) ? (float) $input['discount_value'] : 0;
		$discount_error = $this->validate_discount( $discount_type, $discount_value );
		if ( $discount_error instanceof WP_Error ) {
			return $discount_error;
		}

		$status = ( isset( $input['status'] ) && '' !== $input['status'] ) ? sanitize_text_field( $input['status'] ) : LATEPOINT_COUPON_STATUS_ACTIVE;
		if ( ! in_array( $status, [ LATEPOINT_COUPON_STATUS_ACTIVE, LATEPOINT_COUPON_STATUS_DISABLED ], true ) ) {
			return new WP_Error( 'latepoint_rest_invalid_status', __( 'The status must be either "active" or "disabled".', 'latepoint-pro-features' ), [ 'status' => 422 ] );
		}

		$active_from = $this->normalize_date( $input['active_from'] ?? '' );
		if ( false === $active_from ) {
			return new WP_Error( 'latepoint_rest_invalid_active_from', __( 'The "active_from" date must be in YYYY-MM-DD format.', 'latepoint-pro-features' ), [ 'status' => 422 ] );
		}
		$active_to = $this->normalize_date( $input['active_to'] ?? '' );
		if ( false === $active_to ) {
			return new WP_Error( 'latepoint_rest_invalid_active_to', __( 'The "active_to" date must be in YYYY-MM-DD format.', 'latepoint-pro-features' ), [ 'status' => 422 ] );
		}

		$code = isset( $input['code'] ) ? trim( sanitize_text_field( $input['code'] ) ) : '';
		if ( '' === $code ) {
			$code = $this->generate_unique_code();
		}

		$coupon                 = new OsCouponModel();
		$coupon->code           = $code;
		$coupon->name           = isset( $input['name'] ) ? sanitize_text_field( $input['name'] ) : '';
		$coupon->description    = isset( $input['description'] ) ? sanitize_textarea_field( $input['description'] ) : '';
		$coupon->discount_type  = $discount_type;
		$coupon->discount_value = $discount_value;
		$coupon->status         = $status;
		$coupon->active_from    = $active_from;
		$coupon->active_to      = $active_to;
		$coupon->rules          = wp_json_encode( $this->apply_rules( [], $input ) );

		if ( ! $coupon->save() ) {
			return new WP_Error(
				'latepoint_rest_coupon_save_failed',
				implode( ', ', $coupon->get_error_messages() ),
				[ 'status' => 422 ]
			);
		}

		/** This action is documented in coupons_controller.php */
		do_action( 'latepoint_coupon_created', $coupon );
		OsActivitiesHelper::create_activity(
			[
				'code'      => 'coupon_create',
				'coupon_id' => $coupon->id,
			]
		);

		return new OsCouponModel( $coupon->id );
	}

	/**
	 * @param OsCouponModel $coupon Loaded record to update.
	 * @param array         $input  Partial update payload.
	 * @return OsCouponModel|WP_Error
	 */
	public function update( OsCouponModel $coupon, array $input ) {
		$old_coupon = clone $coupon;

		if ( array_key_exists( 'discount_type', $input ) || array_key_exists( 'discount_value', $input ) ) {
			$discount_type  = array_key_exists( 'discount_type', $input ) ? sanitize_text_field( (string) $input['discount_type'] ) : (string) $coupon->discount_type;
			$discount_value = array_key_exists( 'discount_value', $input ) ? (float) $input['discount_value'] : (float) $coupon->discount_value;
			$discount_error = $this->validate_discount( $discount_type, $discount_value );
			if ( $discount_error instanceof WP_Error ) {
				return $discount_error;
			}
			$coupon->discount_type  = $discount_type;
			$coupon->discount_value = $discount_value;
		}

		if ( array_key_exists( 'status', $input ) ) {
			$status = sanitize_text_field( (string) $input['status'] );
			if ( ! in_array( $status, [ LATEPOINT_COUPON_STATUS_ACTIVE, LATEPOINT_COUPON_STATUS_DISABLED ], true ) ) {
				return new WP_Error( 'latepoint_rest_invalid_status', __( 'The status must be either "active" or "disabled".', 'latepoint-pro-features' ), [ 'status' => 422 ] );
			}
			$coupon->status = $status;
		}

		if ( array_key_exists( 'code', $input ) ) {
			$code = trim( sanitize_text_field( (string) $input['code'] ) );
			if ( '' === $code ) {
				return new WP_Error( 'latepoint_rest_invalid_code', __( 'The coupon code cannot be empty.', 'latepoint-pro-features' ), [ 'status' => 422 ] );
			}
			$coupon->code = $code;
		}

		if ( array_key_exists( 'name', $input ) ) {
			$coupon->name = sanitize_text_field( (string) $input['name'] );
		}
		if ( array_key_exists( 'description', $input ) ) {
			$coupon->description = sanitize_textarea_field( (string) $input['description'] );
		}

		if ( array_key_exists( 'active_from', $input ) ) {
			$active_from = $this->normalize_date( $input['active_from'] );
			if ( false === $active_from ) {
				return new WP_Error( 'latepoint_rest_invalid_active_from', __( 'The "active_from" date must be in YYYY-MM-DD format.', 'latepoint-pro-features' ), [ 'status' => 422 ] );
			}
			$coupon->active_from = $active_from;
		}
		if ( array_key_exists( 'active_to', $input ) ) {
			$active_to = $this->normalize_date( $input['active_to'] );
			if ( false === $active_to ) {
				return new WP_Error( 'latepoint_rest_invalid_active_to', __( 'The "active_to" date must be in YYYY-MM-DD format.', 'latepoint-pro-features' ), [ 'status' => 422 ] );
			}
			$coupon->active_to = $active_to;
		}

		if ( $this->has_rule_args( $input ) ) {
			$existing = [];
			if ( ! empty( $coupon->rules ) ) {
				$decoded = json_decode( $coupon->rules, true );
				if ( is_array( $decoded ) ) {
					$existing = $decoded;
				}
			}
			$coupon->rules = wp_json_encode( $this->apply_rules( $existing, $input ) );
		}

		if ( ! $coupon->save() ) {
			return new WP_Error(
				'latepoint_rest_coupon_save_failed',
				implode( ', ', $coupon->get_error_messages() ),
				[ 'status' => 422 ]
			);
		}

		/** This action is documented in coupons_controller.php */
		do_action( 'latepoint_coupon_updated', $coupon, $old_coupon );
		OsActivitiesHelper::create_activity(
			[
				'code'      => 'coupon_update',
				'coupon_id' => $coupon->id,
			]
		);

		return new OsCouponModel( $coupon->id );
	}

	/**
	 * @param OsCouponModel $coupon Loaded record to delete.
	 * @return true|WP_Error
	 */
	public function delete( OsCouponModel $coupon ) {
		// no latepoint_coupon_deleted hook exists anywhere in the codebase today (verified by
		// grep) — the admin controller's own destroy() doesn't fire one either.
		if ( ! $coupon->delete() ) {
			return new WP_Error(
				'latepoint_rest_coupon_delete_failed',
				__( 'Failed to delete coupon.', 'latepoint-pro-features' ),
				[ 'status' => 500 ]
			);
		}

		return true;
	}

	// ------------------------------------------------------------------

	private function generate_unique_code(): string {
		for ( $i = 0; $i < 5; $i++ ) {
			$code = strtoupper( wp_generate_password( 8, false ) );
			if ( ! ( new OsCouponModel() )->where( [ 'code' => $code ] )->count() ) {
				return $code;
			}
		}

		return strtoupper( wp_generate_password( 12, false ) );
	}

	/**
	 * @param string $type  'fixed' or 'percent'.
	 * @param float  $value Discount amount.
	 * @return WP_Error|null WP_Error (422) when invalid, null when valid.
	 */
	private function validate_discount( string $type, float $value ): ?WP_Error {
		if ( ! in_array( $type, [ 'fixed', 'percent' ], true ) ) {
			return new WP_Error( 'latepoint_rest_invalid_discount_type', __( 'The discount type must be either "fixed" or "percent".', 'latepoint-pro-features' ), [ 'status' => 422 ] );
		}
		// is_finite() rejects INF — (float) overflows a value like "1e400" to INF, which
		// would otherwise pass the "> 0" check below and get persisted uncapped.
		if ( ! is_finite( $value ) || $value <= 0 ) {
			return new WP_Error( 'latepoint_rest_invalid_discount_value', __( 'The discount value must be a finite number greater than zero.', 'latepoint-pro-features' ), [ 'status' => 422 ] );
		}
		if ( 'percent' === $type && $value > 100 ) {
			return new WP_Error( 'latepoint_rest_invalid_discount_value', __( 'A percentage discount cannot exceed 100.', 'latepoint-pro-features' ), [ 'status' => 422 ] );
		}

		return null;
	}

	/**
	 * Validate an optional YYYY-MM-DD date: returns the string, null when empty, or false when invalid.
	 *
	 * @param mixed $value
	 * @return string|null|false
	 */
	private function normalize_date( $value ) {
		$value = trim( (string) $value );
		if ( '' === $value ) {
			return null;
		}
		$date = \DateTime::createFromFormat( 'Y-m-d', $value );
		if ( ! $date || $date->format( 'Y-m-d' ) !== $value ) {
			return false;
		}

		return $value;
	}

	private function has_rule_args( array $args ): bool {
		$rule_keys = array_merge(
			array_keys( $this->int_rule_map ),
			[ 'minimum_order_subtotal', 'service_ids', 'agent_ids', 'bundle_ids', 'customer_ids' ]
		);
		foreach ( $rule_keys as $key ) {
			if ( array_key_exists( $key, $args ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Merge provided rule inputs onto a base set. Empty value clears a rule; omitted leaves it.
	 * ID lists are stored comma-joined (UI format). Create passes []; update the existing rules.
	 *
	 * @param array $base Existing rules to merge onto.
	 * @param array $args Provided input arguments.
	 * @return array
	 */
	private function apply_rules( array $base, array $args ): array {
		$rules = $base;

		foreach ( $this->int_rule_map as $arg_key => $rule_key ) {
			if ( array_key_exists( $arg_key, $args ) ) {
				if ( '' === $args[ $arg_key ] || null === $args[ $arg_key ] ) {
					unset( $rules[ $rule_key ] );
				} else {
					$rules[ $rule_key ] = absint( $args[ $arg_key ] );
				}
			}
		}

		if ( array_key_exists( 'minimum_order_subtotal', $args ) ) {
			if ( '' === $args['minimum_order_subtotal'] || null === $args['minimum_order_subtotal'] ) {
				unset( $rules['minimum_order_subtotal'] );
			} else {
				$rules['minimum_order_subtotal'] = (float) $args['minimum_order_subtotal'];
			}
		}

		foreach ( [ 'service_ids', 'agent_ids', 'bundle_ids', 'customer_ids' ] as $id_key ) {
			if ( array_key_exists( $id_key, $args ) ) {
				$ids = is_array( $args[ $id_key ] ) ? array_filter( array_map( 'absint', $args[ $id_key ] ) ) : [];
				if ( $ids ) {
					$rules[ $id_key ] = implode( ',', $ids );
				} else {
					unset( $rules[ $id_key ] );
				}
			}
		}

		return $rules;
	}
}
