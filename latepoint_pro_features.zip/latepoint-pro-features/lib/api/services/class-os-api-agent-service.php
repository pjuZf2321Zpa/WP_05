<?php
/**
 * Agent write service — mirrors lib/controllers/default_agent_controller.php::update()
 * (used for both create and update there) so REST writes produce the same activity-log
 * entry and latepoint_agent_saved hook a real admin edit does.
 *
 * Deliberately does not touch service/location assignment (save_locations_and_services())
 * or custom work-period schedules — same "resource shell, not its relations" boundary
 * already applied to services and orders' items.
 *
 * delete() has no admin-controller equivalent to mirror — lib/controllers/
 * default_agent_controller.php has no destroy() method at all — so it's built fresh
 * against the existing agent__delete capability and the delete-agent.php ability's intent.
 *
 * @package LatePoint\Api
 * @since   5.4.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class OsApiAgentService {

	/**
	 * @param array $input
	 * @return OsAgentModel|WP_Error
	 */
	public function create( array $input ) {
		return $this->save( new OsAgentModel(), $input, true );
	}

	/**
	 * @param OsAgentModel $agent Loaded, scoped record to update.
	 * @param array        $input Partial update payload.
	 * @return OsAgentModel|WP_Error
	 */
	public function update( OsAgentModel $agent, array $input ) {
		return $this->save( $agent, $input, false );
	}

	/**
	 * @param OsAgentModel $agent
	 * @param array        $input
	 * @param bool         $is_new_record
	 * @return OsAgentModel|WP_Error
	 */
	private function save( OsAgentModel $agent, array $input, bool $is_new_record ) {
		// wp_user_id is never settable via the API — same mass-assignment guard already
		// applied to customers' wordpress_user_id, for the same reason: linking an agent
		// record to an arbitrary WP account is a privilege-adjacent operation that must not
		// be a side effect of an unrelated field update.
		unset( $input['wp_user_id'] );
		// features requires the dedicated set_features() setter (json_encodes the value);
		// set_data() would otherwise write a raw array into a column that must hold a JSON
		// string. Deferred along with the other relation-management fields.
		unset( $input['features'] );
		// id: on create, OsModel::set_data() auto-loads an existing record by id with no
		// ownership check if one is present in $input — this would let a caller with only
		// agent__create silently edit an arbitrary agent instead of creating a new one.
		// Harmless on update (the model is already loaded, never is_new_record()), but
		// stripped unconditionally for simplicity.
		unset( $input['id'] );
		// password has no legitimate reason to be API-settable — never hashed or otherwise
		// guarded downstream, so leaving it mass-assignable would let any caller silently
		// overwrite an agent's login credential.
		unset( $input['password'] );

		if ( isset( $input['status'] ) && ! in_array( $input['status'], [ LATEPOINT_AGENT_STATUS_ACTIVE, LATEPOINT_AGENT_STATUS_DISABLED ], true ) ) {
			return new WP_Error( 'latepoint_rest_invalid_status', __( 'Invalid status.', 'latepoint' ), [ 'status' => 422 ] );
		}

		$agent->set_data( $input );

		if ( ! $agent->save() ) {
			return new WP_Error(
				'latepoint_rest_agent_save_failed',
				implode( ', ', $agent->get_error_messages() ),
				[ 'status' => 422 ]
			);
		}

		/** This action is documented in lib/controllers/default_agent_controller.php */
		do_action( 'latepoint_agent_saved', $agent, $is_new_record, $input );
		OsActivitiesHelper::create_activity(
			[
				'code'     => $is_new_record ? 'agent_create' : 'agent_update',
				'agent_id' => $agent->id,
			]
		);

		return new OsAgentModel( $agent->id );
	}

	/**
	 * @param OsAgentModel $agent Loaded, scoped record to delete.
	 * @return true|WP_Error
	 */
	public function delete( OsAgentModel $agent ) {
		// OsAgentModel::delete() does a raw cascading delete with no hook — nothing to fire.
		if ( ! $agent->delete() ) {
			return new WP_Error(
				'latepoint_rest_agent_delete_failed',
				__( 'Failed to delete agent.', 'latepoint' ),
				[ 'status' => 500 ]
			);
		}

		return true;
	}
}
