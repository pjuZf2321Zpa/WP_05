<?php
/**
 * Location write service.
 *
 * No admin controller write path exists to mirror — confirmed by grep, every write site for
 * OsLocationModel is inside lib/abilities/locations/ or doesn't exist at all. This follows
 * the shape of create-location.php/update-location.php but against the model's real fields
 * only: name, full_address, status, category_id, order_number. Deliberately excludes the
 * fake description/phone/email fields those abilities' input schema still declares —
 * OsLocationModel has no such columns; they are always empty strings when read.
 *
 * No lifecycle hook exists for locations anywhere in the codebase (verified by grep) and
 * none is invented here — OsLocationModel::save()/delete() do a plain save/cascading delete
 * with no do_action of their own.
 *
 * @package LatePoint\Api
 * @since   5.4.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class OsApiLocationService {

	/**
	 * @param array $input
	 * @return OsLocationModel|WP_Error
	 */
	public function create( array $input ) {
		return $this->save( new OsLocationModel(), $input );
	}

	/**
	 * @param OsLocationModel $location Loaded, scoped record to update.
	 * @param array           $input    Partial update payload.
	 * @return OsLocationModel|WP_Error
	 */
	public function update( OsLocationModel $location, array $input ) {
		return $this->save( $location, $input );
	}

	/**
	 * @param OsLocationModel $location
	 * @param array           $input
	 * @return OsLocationModel|WP_Error
	 */
	private function save( OsLocationModel $location, array $input ) {
		// id: on create, OsModel::set_data() auto-loads an existing record by id with no
		// ownership check if one is present in $input — stripped to prevent a caller with
		// only location__create from silently editing an arbitrary location.
		unset( $input['id'] );

		if ( isset( $input['status'] ) && ! in_array( $input['status'], [ LATEPOINT_LOCATION_STATUS_ACTIVE, LATEPOINT_LOCATION_STATUS_DISABLED ], true ) ) {
			return new WP_Error( 'latepoint_rest_invalid_status', __( 'Invalid status.', 'latepoint' ), [ 'status' => 422 ] );
		}

		$location->set_data( $input );

		if ( ! $location->save() ) {
			return new WP_Error(
				'latepoint_rest_location_save_failed',
				implode( ', ', $location->get_error_messages() ),
				[ 'status' => 422 ]
			);
		}

		return new OsLocationModel( $location->id );
	}

	/**
	 * @param OsLocationModel $location Loaded, scoped record to delete.
	 * @return true|WP_Error
	 */
	public function delete( OsLocationModel $location ) {
		if ( ! $location->delete() ) {
			return new WP_Error(
				'latepoint_rest_location_delete_failed',
				__( 'Failed to delete location.', 'latepoint' ),
				[ 'status' => 500 ]
			);
		}

		return true;
	}
}
