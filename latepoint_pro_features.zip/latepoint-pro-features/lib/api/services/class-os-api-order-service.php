<?php
/**
 * Order write service — bare order management (create/update status-and-notes/delete).
 *
 * Built fresh rather than porting lib/abilities/orders/{create,update,change-order-status}.php:
 * verified via `grep -n "do_action"` that none of those abilities fire
 * latepoint_order_created/_updated, so MCP-created/updated orders today silently skip
 * OsActivitiesHelper::log_order_created()/log_order_updated() (self-registered listeners,
 * activities_helper.php:54-55) — the same bug class as the free plugin's booking abilities.
 *
 * Deliberately does not touch order items/pricing — this resource manages the order shell
 * only (status, payment_status, customer_comment). Bookings already create their own order
 * correctly via OsApiBookingService; adding/removing order items via REST is a separate,
 * not-yet-built resource.
 *
 * @package LatePoint\Api
 * @since   5.4.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class OsApiOrderService {

	private $valid_statuses = [ LATEPOINT_ORDER_STATUS_OPEN, LATEPOINT_ORDER_STATUS_CANCELLED, LATEPOINT_ORDER_STATUS_COMPLETED ];

	private $valid_payment_statuses = [
		LATEPOINT_ORDER_PAYMENT_STATUS_NOT_PAID,
		LATEPOINT_ORDER_PAYMENT_STATUS_PARTIALLY_PAID,
		LATEPOINT_ORDER_PAYMENT_STATUS_FULLY_PAID,
		LATEPOINT_ORDER_PAYMENT_STATUS_PROCESSING,
		LATEPOINT_ORDER_PAYMENT_STATUS_REFUNDED,
		LATEPOINT_ORDER_PAYMENT_STATUS_PARTIALLY_REFUNDED,
	];

	/**
	 * @param array $input
	 * @return OsOrderModel|WP_Error
	 */
	public function create( array $input ) {
		if ( empty( $input['customer_id'] ) ) {
			return new WP_Error(
				'latepoint_rest_missing_customer',
				__( 'customer_id is required.', 'latepoint' ),
				[ 'status' => 400 ]
			);
		}

		list( $customer, $error ) = OsApiQuery::find_scoped( 'OsCustomerModel', (int) $input['customer_id'] );
		if ( $error ) {
			return new WP_Error(
				OsApiQuery::FORBIDDEN === $error ? 'latepoint_rest_forbidden' : 'latepoint_rest_customer_not_found',
				OsApiQuery::FORBIDDEN === $error
					? __( 'You do not have permission to create an order for this customer.', 'latepoint' )
					: __( 'Customer not found.', 'latepoint' ),
				[ 'status' => OsApiQuery::FORBIDDEN === $error ? 403 : 404 ]
			);
		}

		$order              = new OsOrderModel();
		$order->customer_id = (int) $customer->id;

		if ( isset( $input['status'] ) ) {
			$status = sanitize_text_field( $input['status'] );
			if ( ! in_array( $status, $this->valid_statuses, true ) ) {
				return $this->invalid_status_error();
			}
			$order->status = $status;
		}
		if ( isset( $input['payment_status'] ) ) {
			$payment_status = sanitize_text_field( $input['payment_status'] );
			if ( ! in_array( $payment_status, $this->valid_payment_statuses, true ) ) {
				return $this->invalid_payment_status_error();
			}
			$order->payment_status = $payment_status;
		}
		if ( isset( $input['customer_comment'] ) ) {
			$order->customer_comment = sanitize_textarea_field( $input['customer_comment'] );
		}

		if ( ! $order->save() ) {
			return new WP_Error(
				'latepoint_rest_order_save_failed',
				implode( ', ', $order->get_error_messages() ),
				[ 'status' => 422 ]
			);
		}

		/** This action is documented in lib/controllers/orders_controller.php */
		do_action( 'latepoint_order_created', $order );

		return new OsOrderModel( $order->id );
	}

	/**
	 * @param OsOrderModel $order Loaded, scoped record to update.
	 * @param array        $input Partial update payload.
	 * @return OsOrderModel|WP_Error
	 */
	public function update( OsOrderModel $order, array $input ) {
		$old_order = clone $order;

		if ( array_key_exists( 'status', $input ) ) {
			$status = sanitize_text_field( (string) $input['status'] );
			if ( ! in_array( $status, $this->valid_statuses, true ) ) {
				return $this->invalid_status_error();
			}
			$order->status = $status;
		}
		if ( array_key_exists( 'payment_status', $input ) ) {
			$payment_status = sanitize_text_field( (string) $input['payment_status'] );
			if ( ! in_array( $payment_status, $this->valid_payment_statuses, true ) ) {
				return $this->invalid_payment_status_error();
			}
			$order->payment_status = $payment_status;
		}
		if ( array_key_exists( 'customer_comment', $input ) ) {
			$order->customer_comment = sanitize_textarea_field( (string) $input['customer_comment'] );
		}

		if ( ! $order->save() ) {
			return new WP_Error(
				'latepoint_rest_order_save_failed',
				implode( ', ', $order->get_error_messages() ),
				[ 'status' => 422 ]
			);
		}

		/** This action is documented in lib/controllers/orders_controller.php */
		do_action( 'latepoint_order_updated', $order, $old_order );

		return new OsOrderModel( $order->id );
	}

	/**
	 * @param OsOrderModel $order Loaded, scoped record to delete.
	 * @return true|WP_Error
	 */
	public function delete( OsOrderModel $order ) {
		// OsOrderModel::delete() already cascades correctly: deletes transactions, fires
		// latepoint_booking_will_be_deleted + deletes each child booking, bulk-deletes order
		// items/metas/process-jobs. No latepoint_order_deleted hook exists anywhere in the
		// codebase (verified by grep) — nothing further to fire here.
		if ( ! $order->delete() ) {
			return new WP_Error(
				'latepoint_rest_order_delete_failed',
				__( 'Failed to delete order.', 'latepoint' ),
				[ 'status' => 500 ]
			);
		}

		return true;
	}

	private function invalid_status_error(): WP_Error {
		return new WP_Error(
			'latepoint_rest_invalid_status',
			__( 'status must be one of: open, cancelled, completed.', 'latepoint' ),
			[ 'status' => 422 ]
		);
	}

	private function invalid_payment_status_error(): WP_Error {
		return new WP_Error(
			'latepoint_rest_invalid_payment_status',
			__( 'payment_status must be one of: not_paid, partially_paid, fully_paid, processing, refunded, partially_refunded.', 'latepoint' ),
			[ 'status' => 422 ]
		);
	}
}
