<?php
/**
 * LatePoint REST API — bootstrap + the custom API-key authentication system.
 *
 * Owned entirely by Pro — this whole framework used to live in the free plugin, gated via
 * the latepoint_rest_api_enabled filter, but that premise (serializers/services "shared with
 * the AI Abilities layer") never actually happened (confirmed: zero references anywhere in
 * the free plugin's lib/abilities/), so there was no reason left for it to live anywhere but
 * here. Both load_dependencies() and init() below are only ever called from
 * latepoint-pro-features.php::core_includes(), gated directly on
 * OsSettingsHelper::is_on('latepoint_rest_api') — no filter indirection needed now that
 * there's no cross-plugin boundary to cross.
 *
 * Also owns resolving a custom API key from an `Authorization: Bearer` header into a WP user
 * for WordPress's own determine_current_user filter chain (previously a separate
 * LatePointProRest class/file — merged in since it had no reason to be split out once both
 * pieces were Pro's own code). latepoint_api_key_authenticate stays a real apply_filters()
 * call (not a direct method call) so a third-party addon could still implement its own key
 * scheme alongside this one.
 *
 * @package LatePoint\Pro\Api
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class OsApiBootstrap {

	/**
	 * Called only from latepoint-pro-features.php::core_includes(), inside the
	 * OsSettingsHelper::is_on('latepoint_rest_api') gate — nothing in here runs at all when
	 * the setting is off.
	 */
	public static function load_dependencies(): void {
		include_once LATEPOINT_ADDON_PRO_LIB_ABSPATH . 'api/class-os-api-query.php';
		include_once LATEPOINT_ADDON_PRO_LIB_ABSPATH . 'api/serializers/class-os-api-serializer.php';
		include_once LATEPOINT_ADDON_PRO_LIB_ABSPATH . 'api/serializers/class-os-api-booking-serializer.php';
		include_once LATEPOINT_ADDON_PRO_LIB_ABSPATH . 'api/serializers/class-os-api-customer-serializer.php';
		include_once LATEPOINT_ADDON_PRO_LIB_ABSPATH . 'api/serializers/class-os-api-order-serializer.php';
		include_once LATEPOINT_ADDON_PRO_LIB_ABSPATH . 'api/serializers/class-os-api-transaction-serializer.php';
		include_once LATEPOINT_ADDON_PRO_LIB_ABSPATH . 'api/serializers/class-os-api-service-serializer.php';
		include_once LATEPOINT_ADDON_PRO_LIB_ABSPATH . 'api/serializers/class-os-api-service-category-serializer.php';
		include_once LATEPOINT_ADDON_PRO_LIB_ABSPATH . 'api/serializers/class-os-api-agent-serializer.php';
		include_once LATEPOINT_ADDON_PRO_LIB_ABSPATH . 'api/serializers/class-os-api-location-serializer.php';
		include_once LATEPOINT_ADDON_PRO_LIB_ABSPATH . 'api/serializers/class-os-api-coupon-serializer.php';
		include_once LATEPOINT_ADDON_PRO_LIB_ABSPATH . 'api/services/class-os-api-availability-service.php';
		include_once LATEPOINT_ADDON_PRO_LIB_ABSPATH . 'api/services/class-os-api-booking-service.php';
		include_once LATEPOINT_ADDON_PRO_LIB_ABSPATH . 'api/services/class-os-api-customer-service.php';
		include_once LATEPOINT_ADDON_PRO_LIB_ABSPATH . 'api/services/class-os-api-order-service.php';
		include_once LATEPOINT_ADDON_PRO_LIB_ABSPATH . 'api/services/class-os-api-transaction-service.php';
		include_once LATEPOINT_ADDON_PRO_LIB_ABSPATH . 'api/services/class-os-api-service-write-service.php';
		include_once LATEPOINT_ADDON_PRO_LIB_ABSPATH . 'api/services/class-os-api-agent-service.php';
		include_once LATEPOINT_ADDON_PRO_LIB_ABSPATH . 'api/services/class-os-api-location-service.php';
		include_once LATEPOINT_ADDON_PRO_LIB_ABSPATH . 'api/services/class-os-api-coupon-service.php';
		include_once LATEPOINT_ADDON_PRO_LIB_ABSPATH . 'api/controllers/class-os-rest-controller.php';
	}

	/**
	 * Whether the current request authenticated via a WordPress Application Password — set
	 * by flag_application_password_authentication(), read (via the
	 * latepoint_rest_api_authenticated_via_application_password filter) by
	 * OsRestController::check_backend_access() to reject it outright. The REST API accepts
	 * only the custom API-key system; Application Passwords keep working everywhere else in
	 * WordPress, just not here.
	 *
	 * @var bool
	 */
	public static $authenticated_via_application_password = false;

	/**
	 * Hooked to WordPress core's application_password_did_authenticate action (fired the
	 * moment one successfully authenticates a request, wp-includes/user.php) — purely a
	 * detection flag for check_backend_access() to act on; does no rejection itself.
	 *
	 * @param WP_User $user
	 * @param array   $item
	 */
	public static function flag_application_password_authentication( $user, $item ) {
		self::$authenticated_via_application_password = true;
	}

	public static function init(): void {
		/**
		 * OsAuthHelper::$current_user (free plugin) is cached for the lifetime of the
		 * request, populated eagerly at init priority 0 (free plugin, LatePoint::init()) —
		 * before WordPress has parsed the request enough to know this is a REST request, so
		 * that very first resolution always misses the custom API-key resolver and caches an
		 * anonymous user. Resetting on every core set_current_user action (fired whenever
		 * wp_set_current_user() runs, including WordPress's own later, correct resolution
		 * once REST dispatch determines the real user) forces the next read to recompute
		 * against the now-correct WP user. Confirmed empirically: removing this breaks
		 * has_backend_access() for valid API-key-authenticated REST requests. Also registered
		 * independently in the free plugin's LatePointAbilities::init() (Abilities-specific,
		 * WP 6.9+ only) — add_action() de-dupes identical callback+priority pairs, so having
		 * both is harmless.
		 */
		add_action( 'set_current_user', [ 'OsAuthHelper', 'reset_current_user' ], 1 );

		add_action( 'application_password_did_authenticate', [ __CLASS__, 'flag_application_password_authentication' ], 10, 2 );

		add_action( 'rest_api_init', [ __CLASS__, 'register_routes' ] );

		// Was unconditional before this merge, registered from a separate always-loaded file —
		// now it's naturally gated the same as everything else here: no reason to listen for
		// Bearer tokens when the REST API setting is off, since no route could ever match
		// anyway (is_latepoint_rest_request() below would always return false regardless).
		add_filter( 'determine_current_user', [ __CLASS__, 'maybe_authenticate_via_api_key' ], 20 );
	}

	public static function register_routes(): void {
		require_once LATEPOINT_ADDON_PRO_LIB_ABSPATH . 'api/class-os-api-registry.php';
		OsApiRegistry::register_routes();
	}

	/**
	 * Resolves a custom API key presented via `Authorization: Bearer <key>` to a WP user id,
	 * for WordPress's own determine_current_user filter chain. Priority 20 (see init()) so
	 * other determine_current_user consumers (e.g. core's own Application Password handling)
	 * get a chance to resolve the user first.
	 *
	 * @param int|false $user_id Whatever a higher-priority determine_current_user filter
	 *                           already resolved, or false if nothing has yet.
	 * @return int|false
	 */
	public static function maybe_authenticate_via_api_key( $user_id ) {
		if ( ! self::is_latepoint_rest_request() ) {
			// determine_current_user fires for every request type (admin, front-end, cron,
			// XML-RPC...) and every REST namespace on the site (core, other plugins); the
			// custom API-key system is scoped to LatePoint's own REST API only.
			return $user_id;
		}

		if ( $user_id ) {
			// something else (e.g. an Application Password) already resolved a user —
			// don't override it.
			return $user_id;
		}

		$auth_header = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
		if ( ! $auth_header && function_exists( 'getallheaders' ) ) {
			// some server configs (e.g. PHP-FPM behind certain proxies) strip
			// HTTP_AUTHORIZATION from $_SERVER — getallheaders() is the documented fallback.
			$headers     = getallheaders();
			$auth_header = $headers['Authorization'] ?? $headers['authorization'] ?? '';
		}

		if ( ! preg_match( '/^Bearer\s+(.+)$/i', trim( $auth_header ), $matches ) ) {
			return $user_id;
		}

		$token = $matches[1];
		if ( substr( $token, 0, 3 ) !== 'lp_' ) {
			// Not one of ours — leave $user_id as-is so another Bearer-token-based auth
			// scheme (e.g. a different plugin's own REST handling) still gets a chance.
			return $user_id;
		}

		return self::resolve_api_key_token( $token ) ?: $user_id;
	}

	/**
	 * Resolves a Bearer token against Pro's own stored key list, then runs the result through
	 * the latepoint_api_key_authenticate extension point. Default is whatever
	 * OsApiKeysHelper::authenticate() resolved — kept as a real apply_filters() call rather
	 * than just returning that value directly, so another addon could still override or
	 * extend key verification if it ever needed to.
	 *
	 * @since 5.4.0
	 * @hook latepoint_api_key_authenticate
	 *
	 * @param string $token The raw bearer token from the Authorization header.
	 * @return int|false A WP user id on a valid key, false otherwise.
	 */
	private static function resolve_api_key_token( string $token ) {
		$user_id = OsApiKeysHelper::authenticate( $token );

		return apply_filters( 'latepoint_api_key_authenticate', $user_id, $token );
	}

	/**
	 * Whether the current request is being dispatched against LatePoint's own REST namespace
	 * (latepoint/v1) — not just any REST request on the site. wp_is_rest_endpoint() alone
	 * would also match core's own routes (wp/v2/...) and every other plugin's namespace,
	 * which would let a LatePoint API key authenticate against them too.
	 *
	 * $GLOBALS['wp']->query_vars['rest_route'] is the same source WordPress core itself reads
	 * in rest_api_loaded() to decide whether to serve a REST request at all, so it is already
	 * populated by the time any permission_callback (and therefore determine_current_user)
	 * runs.
	 *
	 * @return bool
	 */
	private static function is_latepoint_rest_request(): bool {
		if ( ! wp_is_rest_endpoint() ) {
			return false;
		}

		$route = $GLOBALS['wp']->query_vars['rest_route'] ?? '';

		return is_string( $route ) && (bool) preg_match( '#^/?latepoint/v1(/|$)#', $route );
	}
}
