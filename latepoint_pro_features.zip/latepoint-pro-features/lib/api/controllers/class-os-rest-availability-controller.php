<?php
/**
 * Availability REST controller — not model-backed, so it extends WP_REST_Controller
 * directly rather than OsRestController's generic CRUD.
 *
 * Defaults to requiring authentication: checking availability is cheap to call but not
 * free to compute (it walks every agent/location resource for the requested day), so an
 * unauthenticated version is a CPU-DoS and enumeration surface. Site owners can opt in to
 * public access via the latepoint_rest_api_public_availability setting, matching what the
 * booking widget itself already exposes to anonymous visitors.
 *
 * @package LatePoint\Api
 * @since   5.4.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class OsRestAvailabilityController extends WP_REST_Controller {

	protected $namespace = 'latepoint/v1';
	protected $rest_base = 'availability';

	public function register_routes() {
		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base,
			[
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => [ $this, 'get_slots' ],
				'permission_callback' => [ $this, 'permissions_check' ],
				'args'                => [
					'service_id'  => [
						'required' => true,
						'type'     => 'integer',
					],
					'date'        => [
						'required'          => true,
						'type'              => 'string',
						'validate_callback' => [ 'OsRestController', 'validate_date_param' ],
					],
					'agent_id'    => [ 'type' => 'integer' ],
					'location_id' => [ 'type' => 'integer' ],
					'duration'    => [ 'type' => 'integer' ],
				],
			]
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/check',
			[
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => [ $this, 'check_slot' ],
				'permission_callback' => [ $this, 'permissions_check' ],
				'args'                => [
					'service_id'  => [
						'required' => true,
						'type'     => 'integer',
					],
					'date'        => [
						'required'          => true,
						'type'              => 'string',
						'validate_callback' => [ 'OsRestController', 'validate_date_param' ],
					],
					'start_time'  => [
						'required'    => true,
						'type'        => 'integer',
						'description' => __( 'Start time, minutes from midnight.', 'latepoint' ),
					],
					'agent_id'    => [ 'type' => 'integer' ],
					'location_id' => [ 'type' => 'integer' ],
				],
			]
		);
	}

	/**
	 * Checking availability is cheap to call but not free to compute, so it's gated behind
	 * the shared backend-access check (see OsRestController::check_backend_access()) by
	 * default — unless Public Availability Checks is on, in which case this mirrors what the
	 * booking widget itself already exposes to anonymous visitors, and a key must never end
	 * up more restricted than an anonymous caller.
	 */
	public function permissions_check( $request ) {
		if ( OsSettingsHelper::is_on( 'latepoint_rest_api_public_availability' ) ) {
			return true;
		}

		return OsRestController::check_backend_access( 'read' );
	}

	public function get_slots( $request ) {
		$service         = new OsApiAvailabilityService();
		$booking_request = $service->build_booking_request( $request->get_params() );
		if ( is_wp_error( $booking_request ) ) {
			return $booking_request;
		}

		$slots = $service->get_bookable_slots( $booking_request );

		/** This filter is documented in lib/abilities/calendar/get-available-slots.php */
		$slots = apply_filters( 'latepoint_get_available_slots', $slots, $request->get_params() );

		return rest_ensure_response( [ 'slots' => $slots ] );
	}

	public function check_slot( $request ) {
		$service         = new OsApiAvailabilityService();
		$booking_request = $service->build_booking_request( $request->get_params() );
		if ( is_wp_error( $booking_request ) ) {
			return $booking_request;
		}

		return rest_ensure_response(
			[
				'available' => $service->is_slot_available( $booking_request ),
				'conflicts' => $service->get_conflicting_bookings( $booking_request ),
			]
		);
	}
}
