<?php
/**
 * Bookings REST controller — GET /bookings, GET/PATCH/DELETE /bookings/{id}, POST /bookings.
 *
 * Writes are delegated to OsApiBookingService, which runs the real booking-creation
 * pipeline (is_bookable(), order/order-item sequencing, lifecycle hooks) rather than the
 * naive path the AI Abilities' create-booking currently uses.
 *
 * @package LatePoint\Api
 * @since   5.4.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class OsRestBookingsController extends OsRestController {

	protected $rest_base    = 'bookings';
	protected $supports     = [ 'list', 'get', 'create', 'update', 'delete' ];
	protected $capabilities = [
		'read'   => 'booking__view',
		'create' => 'booking__create',
		'update' => 'booking__edit',
		'delete' => 'booking__delete',
	];

	protected function model_class(): string {
		return 'OsBookingModel';
	}

	protected function serializer(): OsApiSerializer {
		return new OsApiBookingSerializer();
	}

	protected function orderby_map(): array {
		return [
			'id'      => LATEPOINT_TABLE_BOOKINGS . '.id',
			// the datetime a booking actually occurs at, not insertion order — correct
			// across DST boundaries, unlike sorting by the raw start_date/start_time pair.
			'start'   => LATEPOINT_TABLE_BOOKINGS . '.start_datetime_utc',
			'created' => LATEPOINT_TABLE_BOOKINGS . '.created_at',
			'updated' => LATEPOINT_TABLE_BOOKINGS . '.updated_at',
			'status'  => LATEPOINT_TABLE_BOOKINGS . '.status',
		];
	}

	protected function default_orderby(): string {
		return 'start';
	}

	protected function resource_collection_params(): array {
		return [
			'status'      => [
				'description' => __( 'Filter by booking status. Repeat the param for multiple statuses.', 'latepoint' ),
				'type'        => [ 'string', 'array' ],
				'items'       => [ 'type' => 'string' ],
			],
			'agent_id'    => [ 'type' => 'integer' ],
			'service_id'  => [ 'type' => 'integer' ],
			'location_id' => [ 'type' => 'integer' ],
			'customer_id' => [ 'type' => 'integer' ],
			'date_after'  => [
				'description'       => __( 'Only bookings on or after this date (Y-m-d).', 'latepoint' ),
				'type'              => 'string',
				'validate_callback' => [ 'OsRestController', 'validate_date_param' ],
			],
			'date_before' => [
				'description'       => __( 'Only bookings on or before this date (Y-m-d).', 'latepoint' ),
				'type'              => 'string',
				'validate_callback' => [ 'OsRestController', 'validate_date_param' ],
			],
		];
	}

	protected function apply_collection_filters( OsModel $query, WP_REST_Request $request ): OsModel {
		$params = $request->get_params();

		if ( ! empty( $params['status'] ) ) {
			$statuses = is_array( $params['status'] ) ? $params['status'] : [ $params['status'] ];
			$query->where( [ 'status' => array_map( 'sanitize_text_field', $statuses ) ] );
		}
		if ( ! empty( $params['agent_id'] ) ) {
			$query->where( [ 'agent_id' => (int) $params['agent_id'] ] );
		}
		if ( ! empty( $params['service_id'] ) ) {
			$query->where( [ 'service_id' => (int) $params['service_id'] ] );
		}
		if ( ! empty( $params['location_id'] ) ) {
			$query->where( [ 'location_id' => (int) $params['location_id'] ] );
		}
		if ( ! empty( $params['customer_id'] ) ) {
			$query->where( [ 'customer_id' => (int) $params['customer_id'] ] );
		}
		if ( ! empty( $params['date_after'] ) ) {
			$query->where( [ 'start_date >=' => sanitize_text_field( $params['date_after'] ) ] );
		}
		if ( ! empty( $params['date_before'] ) ) {
			$query->where( [ 'start_date <=' => sanitize_text_field( $params['date_before'] ) ] );
		}

		return $query;
	}

	public function create_item( $request ) {
		$result = ( new OsApiBookingService() )->create( (array) $request->get_json_params() );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$response = $this->response_from_data( $this->serializer()->to_array_single( $result, 'view' ), $request );
		$response->set_status( 201 );
		$response->header( 'Location', rest_url( 'latepoint/v1/bookings/' . $result->id ) );

		return $response;
	}

	public function update_item( $request ) {
		list( $booking, $error ) = OsApiQuery::find_scoped( 'OsBookingModel', (int) $request['id'] );
		if ( $error ) {
			return $this->not_found_or_forbidden( $error );
		}
		/** @var OsBookingModel $booking find_scoped() only returns null alongside a non-null $error. */
		if ( ! OsRolesHelper::can_user_make_action_on_model_record( $booking, 'edit' ) ) {
			return new WP_Error( 'latepoint_rest_forbidden', __( 'You do not have permission to edit this booking.', 'latepoint' ), [ 'status' => 403 ] );
		}

		$result = ( new OsApiBookingService() )->update( $booking, (array) $request->get_json_params() );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return $this->response_from_data( $this->serializer()->to_array_single( $result, 'view' ), $request );
	}

	public function delete_item( $request ) {
		list( $booking, $error ) = OsApiQuery::find_scoped( 'OsBookingModel', (int) $request['id'] );
		if ( $error ) {
			return $this->not_found_or_forbidden( $error );
		}
		/** @var OsBookingModel $booking find_scoped() only returns null alongside a non-null $error. */
		if ( ! OsRolesHelper::can_user_make_action_on_model_record( $booking, 'delete' ) ) {
			return new WP_Error( 'latepoint_rest_forbidden', __( 'You do not have permission to delete this booking.', 'latepoint' ), [ 'status' => 403 ] );
		}

		$previous = $this->serializer()->to_array_single( $booking, 'view' );
		$result   = ( new OsApiBookingService() )->delete( $booking );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return rest_ensure_response(
			[
				'deleted'  => true,
				'previous' => $previous,
			]
		);
	}
}
