<?php
/**
 * Base class for LatePoint REST resource controllers.
 *
 * Generic list/get/create/update/delete built on top of an OsModel + OsApiSerializer pair,
 * so a concrete controller is mostly configuration (which operations it supports, which
 * LatePoint capability each operation requires, how its collection is filtered/sorted).
 * Bookings and customers override create/update/delete to go through their service classes
 * instead of the generic model set_data()/save() path, because those resources have
 * lifecycle hooks and side effects the generic path does not know about.
 *
 * Stays on WordPress REST conventions throughout: bare objects/arrays (no custom envelope),
 * native WP_Error, WP_REST_Controller's own context/_fields/_embed machinery.
 *
 * @package LatePoint\Api
 * @since   5.4.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

abstract class OsRestController extends WP_REST_Controller {

	/**
	 * Which of list/get/create/update/delete this resource exposes.
	 *
	 * @var string[]
	 */
	protected $supports = [ 'list', 'get' ];

	/**
	 * Operation => LatePoint capability string (e.g. 'booking__view'). An empty string
	 * means "any backend user", used sparingly.
	 *
	 * @var array{read?:string,create?:string,update?:string,delete?:string}
	 */
	protected $capabilities = [];

	public function __construct() {
		$this->namespace = 'latepoint/v1';
	}

	/**
	 * validate_callback for any `Y-m-d` date arg (date, date_after, date_before, etc.).
	 * Schema's own `'format' => 'date'` is not one of the formats WP core's
	 * rest_validate_value_from_schema() recognizes (only date-time/email/ip/uuid/hex-color
	 * are), so without this a malformed date silently passes through to a raw SQL comparison
	 * instead of a 400. Shared by both OsRestController subclasses and the two standalone
	 * availability/agents controllers that don't extend it.
	 *
	 * @param mixed $value
	 * @return bool
	 */
	public static function validate_date_param( $value ): bool {
		$date_object = OsWpDateTime::os_createFromFormat( 'Y-m-d', (string) $value );
		return $date_object && $date_object->format( 'Y-m-d' ) === $value;
	}

	/**
	 * Fully qualified OsModel subclass name for this resource.
	 *
	 * @return string
	 */
	abstract protected function model_class(): string;

	/**
	 * Serializer instance for this resource.
	 *
	 * @return OsApiSerializer
	 */
	abstract protected function serializer(): OsApiSerializer;

	/**
	 * Map of ?orderby= values to real DB columns/expressions, whitelisted per resource.
	 *
	 * @return array
	 */
	protected function orderby_map(): array {
		return [ 'id' => $this->table_column( 'id' ) ];
	}

	protected function default_orderby(): string {
		return 'id';
	}

	private function table_column( string $column ): string {
		$model_class = $this->model_class();
		$model       = new $model_class();

		return $model->table_name . '.' . $column;
	}

	/**
	 * Apply resource-specific collection filters (status, date range, etc) on top of
	 * pagination/sorting, which the base class already applies. No-op by default.
	 *
	 * @param OsModel         $query
	 * @param WP_REST_Request $request
	 * @return OsModel
	 */
	protected function apply_collection_filters( OsModel $query, WP_REST_Request $request ): OsModel {
		return $query;
	}

	public function register_routes() {
		$collection_endpoints = [];
		if ( in_array( 'list', $this->supports, true ) ) {
			$collection_endpoints[] = [
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => [ $this, 'get_items' ],
				'permission_callback' => [ $this, 'get_items_permissions_check' ],
				'args'                => $this->get_collection_params(),
			];
		}
		if ( in_array( 'create', $this->supports, true ) ) {
			$collection_endpoints[] = [
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => [ $this, 'create_item' ],
				'permission_callback' => [ $this, 'create_item_permissions_check' ],
				'args'                => [],
			];
		}
		if ( ! empty( $collection_endpoints ) ) {
			$collection_endpoints['schema'] = [ $this, 'get_public_item_schema' ];
			register_rest_route( $this->namespace, '/' . $this->rest_base, $collection_endpoints );
		}

		$item_endpoints = [];
		if ( in_array( 'get', $this->supports, true ) ) {
			$item_endpoints[] = [
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => [ $this, 'get_item' ],
				'permission_callback' => [ $this, 'get_item_permissions_check' ],
				'args'                => [ 'context' => $this->get_context_param( [ 'default' => 'view' ] ) ],
			];
		}
		if ( in_array( 'update', $this->supports, true ) ) {
			$item_endpoints[] = [
				'methods'             => WP_REST_Server::EDITABLE,
				'callback'            => [ $this, 'update_item' ],
				'permission_callback' => [ $this, 'update_item_permissions_check' ],
				'args'                => [],
			];
		}
		if ( in_array( 'delete', $this->supports, true ) ) {
			$item_endpoints[] = [
				'methods'             => WP_REST_Server::DELETABLE,
				'callback'            => [ $this, 'delete_item' ],
				'permission_callback' => [ $this, 'delete_item_permissions_check' ],
				'args'                => [],
			];
		}
		if ( ! empty( $item_endpoints ) ) {
			$item_endpoints['args']   = [
				'id' => [
					'description' => __( 'Unique identifier for the resource.', 'latepoint' ),
					'type'        => 'integer',
				],
			];
			$item_endpoints['schema'] = [ $this, 'get_public_item_schema' ];
			register_rest_route( $this->namespace, '/' . $this->rest_base . '/(?P<id>[\d]+)', $item_endpoints );
		}
	}

	// ------------------------------------------------------------------
	// Permissions
	// ------------------------------------------------------------------

	public function get_items_permissions_check( $request ) {
		return $this->check_permission( 'read' );
	}

	public function get_item_permissions_check( $request ) {
		return $this->check_permission( 'read' );
	}

	public function create_item_permissions_check( $request ) {
		return $this->check_permission( 'create' );
	}

	public function update_item_permissions_check( $request ) {
		return $this->check_permission( 'update' );
	}

	public function delete_item_permissions_check( $request ) {
		return $this->check_permission( 'delete' );
	}

	/**
	 * The backend-access gate shared by every REST route — resource controllers via
	 * check_permission() below, plus the Availability/System controllers, which aren't
	 * OsRestController subclasses and so call this directly (same cross-class-reuse reason
	 * validate_date_param() above is public static).
	 *
	 * Order matters: authentication first, then the per-key read/write/delete restriction,
	 * then the authenticated user's real LatePoint capabilities. Write/delete access is
	 * governed solely by each credential's own permissions (a key's read/write/delete
	 * toggles, or the authenticated user's real LatePoint capabilities for session auth) —
	 * there is no separate site-wide write/delete kill-switch. Deliberately does not consult
	 * latepoint_abilities_api or any of its related settings — REST and MCP/Abilities must
	 * stay independently enableable. The master on/off toggle itself isn't checked here at
	 * all anymore — this whole class tree only ever loads when
	 * OsSettingsHelper::is_on('latepoint_rest_api') is already true (see
	 * latepoint-pro-features.php::core_includes()), so by the time this method can even run,
	 * the API is already known to be enabled.
	 *
	 * @param string $operation One of read|create|update|delete.
	 * @return true|WP_Error
	 */
	public static function check_backend_access( string $operation ) {
		if ( ! is_user_logged_in() ) {
			return new WP_Error(
				'latepoint_rest_unauthorized',
				__( 'Authentication is required to access the LatePoint REST API.', 'latepoint' ),
				[ 'status' => 401 ]
			);
		}
		/**
		 * Filters whether the current request should be treated as authenticated via a
		 * WordPress Application Password (and therefore rejected below). Default is whatever
		 * OsApiBootstrap::flag_application_password_authentication() detected via core's own
		 * application_password_did_authenticate action.
		 *
		 * Pure extension point — lets another addon override the detected value without
		 * reaching into OsApiBootstrap's static property directly.
		 *
		 * @since 5.4.0
		 * @hook latepoint_rest_api_authenticated_via_application_password
		 *
		 * @param {bool} $authenticated_via_application_password Default: OsApiBootstrap's own detection.
		 * @returns {bool}
		 */
		if ( apply_filters( 'latepoint_rest_api_authenticated_via_application_password', OsApiBootstrap::$authenticated_via_application_password ) ) {
			return new WP_Error(
				'latepoint_rest_application_passwords_not_supported',
				__( 'Application Passwords are not supported for this API. Generate a custom API key instead.', 'latepoint' ),
				[ 'status' => 403 ]
			);
		}
		/**
		 * Filters whether the currently-authenticated request is allowed to perform
		 * $operation, independent of the authenticated user's own LatePoint capabilities.
		 *
		 * Default is OsApiKeysHelper's own determination (true when no key is in use at all —
		 * a plain session-authenticated request — or when the matched key's own
		 * read/write/delete toggles permit it). Kept as a real filter, not a direct call, so
		 * another addon could still narrow this further if it ever needed to. The user's real
		 * capability check later in this method still applies regardless.
		 *
		 * @since 5.4.0
		 * @hook latepoint_rest_api_key_permission
		 *
		 * @param {bool}   $allowed   Default: OsApiKeysHelper::matched_key_allows()'s result.
		 * @param {string} $operation One of read|create|update|delete.
		 * @returns {bool} Whether this specific key permits the operation.
		 */
		if ( ! apply_filters( 'latepoint_rest_api_key_permission', OsApiKeysHelper::matched_key_allows( $operation ), $operation ) ) {
			return new WP_Error(
				'latepoint_rest_api_key_forbidden',
				__( 'This API key does not have permission to perform this action.', 'latepoint' ),
				[ 'status' => 403 ]
			);
		}
		if ( ! OsAuthHelper::get_current_user()->has_backend_access() ) {
			return new WP_Error(
				'latepoint_rest_forbidden',
				__( 'You do not have permission to access the LatePoint REST API.', 'latepoint' ),
				[ 'status' => 403 ]
			);
		}

		return true;
	}

	/**
	 * The single permission gate every resource-controller route runs through: the shared
	 * backend-access gate (see check_backend_access()), then the LatePoint capability for
	 * this specific operation.
	 *
	 * @param string $operation One of read|create|update|delete.
	 * @return true|WP_Error
	 */
	protected function check_permission( string $operation ) {
		$access = self::check_backend_access( $operation );
		if ( is_wp_error( $access ) ) {
			return $access;
		}

		$capability = $this->capabilities[ $operation ] ?? '';
		if ( $capability && ! OsRolesHelper::can_user( $capability ) ) {
			return new WP_Error(
				'latepoint_rest_forbidden',
				__( 'You do not have permission to perform this action.', 'latepoint' ),
				[ 'status' => 403 ]
			);
		}

		return true;
	}

	// ------------------------------------------------------------------
	// Generic list/get. Concrete controllers override create/update/delete
	// where a service class owns the write logic (bookings, customers).
	// ------------------------------------------------------------------

	public function get_items( $request ) {
		$model_class = $this->model_class();
		$query       = new $model_class();
		$query       = $this->apply_collection_filters( $query, $request );
		$query       = OsApiQuery::apply_sort( $query, $request->get_params(), $this->orderby_map(), $this->default_orderby() );
		$query->filter_allowed_records();

		$pagination             = OsApiQuery::clamp_pagination( $request->get_params() );
		list( $models, $total ) = OsApiQuery::fetch_collection( $query, $pagination );

		$context = $this->resolve_context( $request );
		$data    = [];
		foreach ( $this->serializer()->to_array_collection( $models, $context ) as $item ) {
			$data[] = $this->prepare_response_for_collection( $this->response_from_data( $item, $request ) );
		}

		$response = rest_ensure_response( $data );

		return $this->add_pagination_headers( $response, $request, $pagination, $total );
	}

	public function get_item( $request ) {
		list( $model, $error ) = OsApiQuery::find_scoped( $this->model_class(), (int) $request['id'] );
		if ( $error ) {
			return $this->not_found_or_forbidden( $error );
		}

		$context = $this->resolve_context( $request );

		return $this->response_from_data( $this->serializer()->to_array_single( $model, $context ), $request );
	}

	public function create_item( $request ) {
		return new WP_Error(
			'latepoint_rest_not_implemented',
			__( 'This resource does not support creation via the REST API yet.', 'latepoint' ),
			[ 'status' => 501 ]
		);
	}

	public function update_item( $request ) {
		return new WP_Error(
			'latepoint_rest_not_implemented',
			__( 'This resource does not support updates via the REST API yet.', 'latepoint' ),
			[ 'status' => 501 ]
		);
	}

	public function delete_item( $request ) {
		return new WP_Error(
			'latepoint_rest_not_implemented',
			__( 'This resource does not support deletion via the REST API yet.', 'latepoint' ),
			[ 'status' => 501 ]
		);
	}

	// ------------------------------------------------------------------
	// Shared helpers for concrete controllers
	// ------------------------------------------------------------------

	/**
	 * The `context` request param has no enum restriction (WP core's get_context_param()
	 * only adds one if a serializer schema declares one, and ours don't), so any caller who
	 * passes the read-permission check could otherwise request `edit` context and receive
	 * whatever edit-only fields a serializer adds for it (e.g. OsApiCustomerSerializer's
	 * admin_notes/wordpress_user_id) with only read-level capability. Silently downgrades to
	 * `view` rather than erroring — matches the existing pattern in
	 * OsApiAvailabilityService::get_conflicting_bookings(), which omits detail for
	 * lower-privileged callers instead of rejecting the whole request.
	 *
	 * @param WP_REST_Request $request
	 * @return string
	 */
	private function resolve_context( WP_REST_Request $request ): string {
		$context = $request->get_param( 'context' ) ?: 'view';
		if ( 'edit' === $context ) {
			$capability = $this->capabilities['update'] ?? '';
			if ( ! $capability || ! OsRolesHelper::can_user( $capability ) ) {
				return 'view';
			}
		}

		return $context;
	}

	protected function not_found_or_forbidden( string $error ) {
		if ( OsApiQuery::FORBIDDEN === $error ) {
			return new WP_Error(
				'latepoint_rest_forbidden',
				__( 'You do not have permission to access this record.', 'latepoint' ),
				[ 'status' => 403 ]
			);
		}

		return new WP_Error(
			'latepoint_rest_not_found',
			__( 'Resource not found.', 'latepoint' ),
			[ 'status' => 404 ]
		);
	}

	protected function response_from_data( array $data, $request ) {
		/**
		 * Filters a serialized item for this resource before it's returned.
		 *
		 * Dynamic portion of the hook name, `$this->rest_base`, is the resource slug
		 * (e.g. `bookings`, `service-categories`) — lets add-ons attach fields (e.g. Pro's
		 * custom fields or service extras) without forking the serializer.
		 *
		 * @since 5.4.0
		 * @hook latepoint_rest_api_prepare_{resource}
		 *
		 * @param {array}           $data    Serialized item.
		 * @param {WP_REST_Request} $request The current request.
		 * @returns {array} The filtered item.
		 */
		$data = apply_filters( "latepoint_rest_api_prepare_{$this->rest_base}", $data, $request );

		$response = rest_ensure_response( $data );
		$response->add_links( $this->extract_links( $data ) );

		return $response;
	}

	/**
	 * WP_REST_Controller::add_links() expects a specific shape; our serializers already
	 * emit a compatible `_links` array, so just lift it out of the payload the same way
	 * WP_REST_Posts_Controller does internally.
	 *
	 * @param array $data
	 * @return array
	 */
	private function extract_links( array $data ): array {
		return $data['_links'] ?? [];
	}

	public function get_collection_params() {
		return array_merge(
			[
				'context'  => $this->get_context_param( [ 'default' => 'view' ] ),
				'page'     => [
					'description' => __( 'Page number.', 'latepoint' ),
					'type'        => 'integer',
					'default'     => 1,
					'minimum'     => 1,
				],
				'per_page' => [
					'description' => __( 'Items per page.', 'latepoint' ),
					'type'        => 'integer',
					'default'     => 20,
					'minimum'     => 1,
					'maximum'     => 100,
				],
				'orderby'  => [
					'description' => __( 'Sort field.', 'latepoint' ),
					'type'        => 'string',
					'enum'        => array_keys( $this->orderby_map() ),
				],
				'order'    => [
					'description' => __( 'Sort direction.', 'latepoint' ),
					'type'        => 'string',
					'enum'        => [ 'asc', 'desc' ],
					'default'     => 'desc',
				],
			],
			$this->resource_collection_params()
		);
	}

	/**
	 * Resource-specific collection params (filters), merged on top of the base set.
	 *
	 * @return array
	 */
	protected function resource_collection_params(): array {
		return [];
	}

	public function get_item_schema() {
		$this->schema = $this->schema ?: $this->serializer()->schema();

		return $this->add_additional_fields_schema( $this->schema );
	}

	private function add_pagination_headers( WP_REST_Response $response, WP_REST_Request $request, array $pagination, int $total ): WP_REST_Response {
		$total_pages = $pagination['per_page'] > 0 ? (int) ceil( $total / $pagination['per_page'] ) : 0;

		$response->header( 'X-WP-Total', (string) $total );
		$response->header( 'X-WP-TotalPages', (string) $total_pages );

		$base = add_query_arg( $request->get_query_params(), rest_url( sprintf( '%s/%s', $this->namespace, $this->rest_base ) ) );

		if ( $pagination['page'] > 1 ) {
			$response->link_header( 'prev', add_query_arg( 'page', $pagination['page'] - 1, $base ) );
		}
		if ( $pagination['page'] < $total_pages ) {
			$response->link_header( 'next', add_query_arg( 'page', $pagination['page'] + 1, $base ) );
		}

		return $response;
	}
}
