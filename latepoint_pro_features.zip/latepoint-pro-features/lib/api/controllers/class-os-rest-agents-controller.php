<?php
/**
 * Agents REST controller — full CRUD. Writes delegate to OsApiAgentService, which mirrors
 * lib/controllers/default_agent_controller.php::update() (activity log + latepoint_agent_saved
 * hook). Delete has no admin equivalent — built fresh against the existing agent__delete
 * capability and the delete-agent.php ability's intent.
 *
 * @package LatePoint\Api
 * @since   5.4.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class OsRestAgentsController extends OsRestController {

	protected $rest_base    = 'agents';
	protected $supports     = [ 'list', 'get', 'create', 'update', 'delete' ];
	protected $capabilities = [
		'read'   => 'agent__view',
		'create' => 'agent__create',
		'update' => 'agent__edit',
		'delete' => 'agent__delete',
	];

	protected function model_class(): string {
		return 'OsAgentModel';
	}

	protected function serializer(): OsApiSerializer {
		return new OsApiAgentSerializer();
	}

	protected function orderby_map(): array {
		return [
			'id'   => LATEPOINT_TABLE_AGENTS . '.id',
			'name' => LATEPOINT_TABLE_AGENTS . '.first_name',
		];
	}

	protected function resource_collection_params(): array {
		return [
			'status' => [
				'type' => 'string',
				'enum' => [ 'active', 'disabled' ],
			],
		];
	}

	protected function apply_collection_filters( OsModel $query, WP_REST_Request $request ): OsModel {
		$params = $request->get_params();

		if ( ! empty( $params['status'] ) ) {
			$query->where( [ 'status' => sanitize_text_field( $params['status'] ) ] );
		}

		return $query;
	}

	/**
	 * Adds GET /agents/availability on top of the standard CRUD routes. Gated on the
	 * agents' own read capability (agent__view), not the public-availability toggle — this
	 * response carries agent PII (email, phone), unlike the slot-only availability endpoint.
	 */
	public function register_routes() {
		parent::register_routes();

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/availability',
			[
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => [ $this, 'get_agent_availability' ],
				'permission_callback' => [ $this, 'get_items_permissions_check' ],
				'args'                => [
					'service_id'  => [ 'type' => 'integer' ],
					'location_id' => [ 'type' => 'integer' ],
					'date'        => [
						'type'              => 'string',
						'validate_callback' => [ 'OsRestController', 'validate_date_param' ],
					],
					'start_time'  => [ 'description' => __( 'HH:MM or minutes from midnight.', 'latepoint' ) ],
					'duration'    => [ 'type' => 'integer' ],
					'limit'       => [ 'type' => 'integer' ],
				],
			]
		);
	}

	public function get_agent_availability( $request ) {
		$result = ( new OsApiAvailabilityService() )->agents_availability( $request->get_params() );

		$agents = $this->serializer()->to_array_collection( $result['agents'], 'view' );
		foreach ( $agents as $index => $agent_data ) {
			$agent_id                         = $result['agents'][ $index ]->id;
			$agents[ $index ]['is_available'] = $result['is_available'][ $agent_id ] ?? null;
		}

		return rest_ensure_response(
			[
				'filters' => $result['filters'],
				'agents'  => $agents,
			]
		);
	}

	public function create_item( $request ) {
		$result = ( new OsApiAgentService() )->create( (array) $request->get_json_params() );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$response = $this->response_from_data( $this->serializer()->to_array_single( $result, 'view' ), $request );
		$response->set_status( 201 );
		$response->header( 'Location', rest_url( 'latepoint/v1/agents/' . $result->id ) );

		return $response;
	}

	public function update_item( $request ) {
		list( $agent, $error ) = OsApiQuery::find_scoped( 'OsAgentModel', (int) $request['id'] );
		if ( $error ) {
			return $this->not_found_or_forbidden( $error );
		}
		/** @var OsAgentModel $agent find_scoped() only returns null alongside a non-null $error. */

		$result = ( new OsApiAgentService() )->update( $agent, (array) $request->get_json_params() );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return $this->response_from_data( $this->serializer()->to_array_single( $result, 'view' ), $request );
	}

	public function delete_item( $request ) {
		list( $agent, $error ) = OsApiQuery::find_scoped( 'OsAgentModel', (int) $request['id'] );
		if ( $error ) {
			return $this->not_found_or_forbidden( $error );
		}
		/** @var OsAgentModel $agent find_scoped() only returns null alongside a non-null $error. */

		$previous = $this->serializer()->to_array_single( $agent, 'view' );
		$result   = ( new OsApiAgentService() )->delete( $agent );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return rest_ensure_response(
			[
				'deleted'  => true,
				'previous' => $previous,
			]
		);
	}
}
