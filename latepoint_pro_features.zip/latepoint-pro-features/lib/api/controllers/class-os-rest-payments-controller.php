<?php
/**
 * Payments REST controller — GET/POST /payments, GET/PATCH/DELETE /payments/{id}.
 *
 * POST records a manual ledger entry (no gateway call) — real transactions from a
 * connected gateway still only ever land here as a side effect of checkout. PATCH only
 * touches metadata/status (the async-gateway-confirmation use case) — amount/order_id/
 * customer_id/kind/payment_portion are locked, since none of them has a safe way to change
 * after the fact. Refunds delegate to gateway-specific code
 * (apply_filters('latepoint_process_refund', ...)) that needs its own design — out of
 * scope. See OsApiTransactionService for the full reasoning on both.
 *
 * REST base is "payments" (matching the admin nav label and the wplimit competitor's
 * naming) even though the model is OsTransactionModel — same pattern as orders/OsOrderModel.
 *
 * @package LatePoint\Api
 * @since   5.4.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class OsRestPaymentsController extends OsRestController {

	protected $rest_base    = 'payments';
	protected $supports     = [ 'list', 'get', 'create', 'update', 'delete' ];
	protected $capabilities = [
		'read'   => 'transaction__view',
		'create' => 'transaction__create',
		'update' => 'transaction__edit',
		'delete' => 'transaction__delete',
	];

	protected function model_class(): string {
		return 'OsTransactionModel';
	}

	protected function serializer(): OsApiSerializer {
		return new OsApiTransactionSerializer();
	}

	protected function orderby_map(): array {
		return [
			'id'      => LATEPOINT_TABLE_TRANSACTIONS . '.id',
			'created' => LATEPOINT_TABLE_TRANSACTIONS . '.created_at',
			'amount'  => LATEPOINT_TABLE_TRANSACTIONS . '.amount',
		];
	}

	protected function default_orderby(): string {
		return 'created';
	}

	protected function resource_collection_params(): array {
		return [
			'order_id'       => [ 'type' => 'integer' ],
			'customer_id'    => [ 'type' => 'integer' ],
			'processor'      => [ 'type' => 'string' ],
			'payment_method' => [ 'type' => 'string' ],
			'status'         => [ 'type' => 'string' ],
			'kind'           => [ 'type' => 'string' ],
			'date_after'     => [
				'description'       => __( 'Only payments created on or after this date (Y-m-d).', 'latepoint' ),
				'type'              => 'string',
				'validate_callback' => [ 'OsRestController', 'validate_date_param' ],
			],
			'date_before'    => [
				'description'       => __( 'Only payments created on or before this date (Y-m-d).', 'latepoint' ),
				'type'              => 'string',
				'validate_callback' => [ 'OsRestController', 'validate_date_param' ],
			],
		];
	}

	protected function apply_collection_filters( OsModel $query, WP_REST_Request $request ): OsModel {
		$params = $request->get_params();

		if ( ! empty( $params['order_id'] ) ) {
			$query->where( [ 'order_id' => (int) $params['order_id'] ] );
		}
		if ( ! empty( $params['customer_id'] ) ) {
			$query->where( [ 'customer_id' => (int) $params['customer_id'] ] );
		}
		if ( ! empty( $params['processor'] ) ) {
			$query->where( [ 'processor' => sanitize_text_field( $params['processor'] ) ] );
		}
		if ( ! empty( $params['payment_method'] ) ) {
			$query->where( [ 'payment_method' => sanitize_text_field( $params['payment_method'] ) ] );
		}
		if ( ! empty( $params['status'] ) ) {
			$query->where( [ 'status' => sanitize_text_field( $params['status'] ) ] );
		}
		if ( ! empty( $params['kind'] ) ) {
			$query->where( [ 'kind' => sanitize_text_field( $params['kind'] ) ] );
		}
		if ( ! empty( $params['date_after'] ) ) {
			$query->where( [ LATEPOINT_TABLE_TRANSACTIONS . '.created_at >=' => sanitize_text_field( $params['date_after'] ) ] );
		}
		if ( ! empty( $params['date_before'] ) ) {
			$query->where( [ LATEPOINT_TABLE_TRANSACTIONS . '.created_at <=' => sanitize_text_field( $params['date_before'] ) ] );
		}

		return $query;
	}

	public function create_item( $request ) {
		$result = ( new OsApiTransactionService() )->create( (array) $request->get_json_params() );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$response = $this->response_from_data( $this->serializer()->to_array_single( $result, 'view' ), $request );
		$response->set_status( 201 );
		$response->header( 'Location', rest_url( 'latepoint/v1/payments/' . $result->id ) );

		return $response;
	}

	public function update_item( $request ) {
		list( $transaction, $error ) = OsApiQuery::find_scoped( 'OsTransactionModel', (int) $request['id'] );
		if ( $error ) {
			return $this->not_found_or_forbidden( $error );
		}
		/** @var OsTransactionModel $transaction find_scoped() only returns null alongside a non-null $error. */

		$result = ( new OsApiTransactionService() )->update( $transaction, (array) $request->get_json_params() );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return $this->response_from_data( $this->serializer()->to_array_single( $result, 'view' ), $request );
	}

	public function delete_item( $request ) {
		list( $transaction, $error ) = OsApiQuery::find_scoped( 'OsTransactionModel', (int) $request['id'] );
		if ( $error ) {
			return $this->not_found_or_forbidden( $error );
		}
		/** @var OsTransactionModel $transaction find_scoped() only returns null alongside a non-null $error. */

		$previous = $this->serializer()->to_array_single( $transaction, 'view' );
		$result   = ( new OsApiTransactionService() )->delete( $transaction );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return rest_ensure_response(
			[
				'deleted'  => true,
				'previous' => $previous,
			]
		);
	}
}
