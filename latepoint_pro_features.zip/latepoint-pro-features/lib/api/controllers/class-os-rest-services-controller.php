<?php
/**
 * Services REST controller — full CRUD. Writes delegate to OsApiServiceWriteService, which
 * mirrors lib/controllers/services_controller.php::update()/destroy() (activity log +
 * latepoint_service_saved hook, or the model's own latepoint_service_deleted on delete).
 *
 * @package LatePoint\Api
 * @since   5.4.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class OsRestServicesController extends OsRestController {

	protected $rest_base    = 'services';
	protected $supports     = [ 'list', 'get', 'create', 'update', 'delete' ];
	protected $capabilities = [
		'read'   => 'service__view',
		'create' => 'service__create',
		'update' => 'service__edit',
		'delete' => 'service__delete',
	];

	protected function model_class(): string {
		return 'OsServiceModel';
	}

	protected function serializer(): OsApiSerializer {
		return new OsApiServiceSerializer();
	}

	protected function orderby_map(): array {
		return [
			'id'    => LATEPOINT_TABLE_SERVICES . '.id',
			'order' => LATEPOINT_TABLE_SERVICES . '.order_number',
			'name'  => LATEPOINT_TABLE_SERVICES . '.name',
		];
	}

	protected function default_orderby(): string {
		return 'order';
	}

	protected function resource_collection_params(): array {
		return [
			'category_id' => [ 'type' => 'integer' ],
			'status'      => [
				'type' => 'string',
				'enum' => [ 'active', 'disabled' ],
			],
		];
	}

	protected function apply_collection_filters( OsModel $query, WP_REST_Request $request ): OsModel {
		$params = $request->get_params();

		if ( ! empty( $params['category_id'] ) ) {
			$query->where( [ 'category_id' => (int) $params['category_id'] ] );
		}
		if ( ! empty( $params['status'] ) ) {
			$query->where( [ 'status' => sanitize_text_field( $params['status'] ) ] );
		}

		return $query;
	}

	public function create_item( $request ) {
		$result = ( new OsApiServiceWriteService() )->create( (array) $request->get_json_params() );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$response = $this->response_from_data( $this->serializer()->to_array_single( $result, 'view' ), $request );
		$response->set_status( 201 );
		$response->header( 'Location', rest_url( 'latepoint/v1/services/' . $result->id ) );

		return $response;
	}

	public function update_item( $request ) {
		list( $service, $error ) = OsApiQuery::find_scoped( 'OsServiceModel', (int) $request['id'] );
		if ( $error ) {
			return $this->not_found_or_forbidden( $error );
		}
		/** @var OsServiceModel $service find_scoped() only returns null alongside a non-null $error. */

		$result = ( new OsApiServiceWriteService() )->update( $service, (array) $request->get_json_params() );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return $this->response_from_data( $this->serializer()->to_array_single( $result, 'view' ), $request );
	}

	public function delete_item( $request ) {
		list( $service, $error ) = OsApiQuery::find_scoped( 'OsServiceModel', (int) $request['id'] );
		if ( $error ) {
			return $this->not_found_or_forbidden( $error );
		}
		/** @var OsServiceModel $service find_scoped() only returns null alongside a non-null $error. */

		$previous = $this->serializer()->to_array_single( $service, 'view' );
		$result   = ( new OsApiServiceWriteService() )->delete( $service );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return rest_ensure_response(
			[
				'deleted'  => true,
				'previous' => $previous,
			]
		);
	}
}
