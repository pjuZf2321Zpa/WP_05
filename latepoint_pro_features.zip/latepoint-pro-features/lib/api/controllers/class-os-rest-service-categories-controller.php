<?php
/**
 * Service categories REST controller — read-only.
 *
 * @package LatePoint\Api
 * @since   5.4.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class OsRestServiceCategoriesController extends OsRestController {

	protected $rest_base    = 'service-categories';
	protected $supports     = [ 'list', 'get' ];
	protected $capabilities = [
		'read' => 'service__view',
	];

	protected function model_class(): string {
		return 'OsServiceCategoryModel';
	}

	protected function serializer(): OsApiSerializer {
		return new OsApiServiceCategorySerializer();
	}

	protected function orderby_map(): array {
		return [
			'id'    => LATEPOINT_TABLE_SERVICE_CATEGORIES . '.id',
			'order' => LATEPOINT_TABLE_SERVICE_CATEGORIES . '.order_number',
			'name'  => LATEPOINT_TABLE_SERVICE_CATEGORIES . '.name',
		];
	}

	protected function default_orderby(): string {
		return 'order';
	}
}
