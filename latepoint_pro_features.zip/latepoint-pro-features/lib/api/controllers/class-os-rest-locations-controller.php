<?php
/**
 * Locations REST controller — full CRUD. Writes delegate to OsApiLocationService.
 *
 * No admin write controller exists for locations to mirror (confirmed by grep) — writes are
 * built fresh against the model's real fields (name, full_address, status, category_id,
 * order_number), deliberately excluding the fake description/phone/email fields the
 * location abilities' schema still declares.
 *
 * @package LatePoint\Api
 * @since   5.4.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class OsRestLocationsController extends OsRestController {

	protected $rest_base    = 'locations';
	protected $supports     = [ 'list', 'get', 'create', 'update', 'delete' ];
	protected $capabilities = [
		'read'   => 'location__view',
		'create' => 'location__create',
		'update' => 'location__edit',
		'delete' => 'location__delete',
	];

	protected function model_class(): string {
		return 'OsLocationModel';
	}

	protected function serializer(): OsApiSerializer {
		return new OsApiLocationSerializer();
	}

	protected function orderby_map(): array {
		return [
			'id'    => LATEPOINT_TABLE_LOCATIONS . '.id',
			'order' => LATEPOINT_TABLE_LOCATIONS . '.order_number',
			'name'  => LATEPOINT_TABLE_LOCATIONS . '.name',
		];
	}

	protected function default_orderby(): string {
		return 'order';
	}

	protected function resource_collection_params(): array {
		return [
			'category_id' => [ 'type' => 'integer' ],
			'status'      => [
				'type' => 'string',
				'enum' => [ 'active', 'disabled' ],
			],
		];
	}

	protected function apply_collection_filters( OsModel $query, WP_REST_Request $request ): OsModel {
		$params = $request->get_params();

		if ( ! empty( $params['category_id'] ) ) {
			$query->where( [ 'category_id' => (int) $params['category_id'] ] );
		}
		if ( ! empty( $params['status'] ) ) {
			$query->where( [ 'status' => sanitize_text_field( $params['status'] ) ] );
		}

		return $query;
	}

	public function create_item( $request ) {
		$result = ( new OsApiLocationService() )->create( (array) $request->get_json_params() );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$response = $this->response_from_data( $this->serializer()->to_array_single( $result, 'view' ), $request );
		$response->set_status( 201 );
		$response->header( 'Location', rest_url( 'latepoint/v1/locations/' . $result->id ) );

		return $response;
	}

	public function update_item( $request ) {
		list( $location, $error ) = OsApiQuery::find_scoped( 'OsLocationModel', (int) $request['id'] );
		if ( $error ) {
			return $this->not_found_or_forbidden( $error );
		}
		/** @var OsLocationModel $location find_scoped() only returns null alongside a non-null $error. */

		$result = ( new OsApiLocationService() )->update( $location, (array) $request->get_json_params() );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return $this->response_from_data( $this->serializer()->to_array_single( $result, 'view' ), $request );
	}

	public function delete_item( $request ) {
		list( $location, $error ) = OsApiQuery::find_scoped( 'OsLocationModel', (int) $request['id'] );
		if ( $error ) {
			return $this->not_found_or_forbidden( $error );
		}
		/** @var OsLocationModel $location find_scoped() only returns null alongside a non-null $error. */

		$previous = $this->serializer()->to_array_single( $location, 'view' );
		$result   = ( new OsApiLocationService() )->delete( $location );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return rest_ensure_response(
			[
				'deleted'  => true,
				'previous' => $previous,
			]
		);
	}
}
