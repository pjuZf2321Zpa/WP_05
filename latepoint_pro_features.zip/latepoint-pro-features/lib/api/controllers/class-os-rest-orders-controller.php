<?php
/**
 * Orders REST controller — GET /orders, GET/PATCH/DELETE /orders/{id}, POST /orders.
 *
 * Covers bare order management only (status/payment_status/customer_comment) — writes are
 * delegated to OsApiOrderService, which fires the lifecycle hooks the equivalent AI
 * Abilities (lib/abilities/orders/) are missing. Adding/removing order items, invoices,
 * transactions/refunds are separate, not-yet-built resources.
 *
 * @package LatePoint\Api
 * @since   5.4.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class OsRestOrdersController extends OsRestController {

	protected $rest_base = 'orders';
	protected $supports  = [ 'list', 'get', 'create', 'update', 'delete' ];
	// orders are modeled as part of the booking domain throughout this codebase — the admin
	// controller itself uses these same capabilities (lib/config/capabilities_for_controllers.php,
	// OsOrdersController), not an order__* namespace.
	protected $capabilities = [
		'read'   => 'booking__view',
		'create' => 'booking__create',
		'update' => 'booking__edit',
		'delete' => 'booking__delete',
	];

	protected function model_class(): string {
		return 'OsOrderModel';
	}

	protected function serializer(): OsApiSerializer {
		return new OsApiOrderSerializer();
	}

	protected function orderby_map(): array {
		return [
			'id'      => LATEPOINT_TABLE_ORDERS . '.id',
			'created' => LATEPOINT_TABLE_ORDERS . '.created_at',
			'updated' => LATEPOINT_TABLE_ORDERS . '.updated_at',
			'total'   => LATEPOINT_TABLE_ORDERS . '.total',
		];
	}

	protected function default_orderby(): string {
		return 'created';
	}

	protected function resource_collection_params(): array {
		return [
			'status'         => [
				'type' => 'string',
				'enum' => [ 'open', 'cancelled', 'completed' ],
			],
			'payment_status' => [ 'type' => 'string' ],
			'customer_id'    => [ 'type' => 'integer' ],
			'date_after'     => [
				'description'       => __( 'Only orders created on or after this date (Y-m-d).', 'latepoint' ),
				'type'              => 'string',
				'validate_callback' => [ 'OsRestController', 'validate_date_param' ],
			],
			'date_before'    => [
				'description'       => __( 'Only orders created on or before this date (Y-m-d).', 'latepoint' ),
				'type'              => 'string',
				'validate_callback' => [ 'OsRestController', 'validate_date_param' ],
			],
		];
	}

	protected function apply_collection_filters( OsModel $query, WP_REST_Request $request ): OsModel {
		$params = $request->get_params();

		if ( ! empty( $params['status'] ) ) {
			$query->where( [ 'status' => sanitize_text_field( $params['status'] ) ] );
		}
		if ( ! empty( $params['payment_status'] ) ) {
			$query->where( [ 'payment_status' => sanitize_text_field( $params['payment_status'] ) ] );
		}
		if ( ! empty( $params['customer_id'] ) ) {
			$query->where( [ 'customer_id' => (int) $params['customer_id'] ] );
		}
		// filter_allowed_records() (called by the base controller after this) joins
		// order_items + bookings, both of which also have a created_at column — so any
		// date filter here must be table-qualified to avoid an ambiguous-column SQL error,
		// the same gotcha lib/abilities/orders/list-orders.php already documents.
		if ( ! empty( $params['date_after'] ) ) {
			$query->where( [ LATEPOINT_TABLE_ORDERS . '.created_at >=' => sanitize_text_field( $params['date_after'] ) ] );
		}
		if ( ! empty( $params['date_before'] ) ) {
			$query->where( [ LATEPOINT_TABLE_ORDERS . '.created_at <=' => sanitize_text_field( $params['date_before'] ) ] );
		}

		return $query;
	}

	public function create_item( $request ) {
		$result = ( new OsApiOrderService() )->create( (array) $request->get_json_params() );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$response = $this->response_from_data( $this->serializer()->to_array_single( $result, 'view' ), $request );
		$response->set_status( 201 );
		$response->header( 'Location', rest_url( 'latepoint/v1/orders/' . $result->id ) );

		return $response;
	}

	public function update_item( $request ) {
		list( $order, $error ) = OsApiQuery::find_scoped( 'OsOrderModel', (int) $request['id'] );
		if ( $error ) {
			return $this->not_found_or_forbidden( $error );
		}
		/** @var OsOrderModel $order find_scoped() only returns null alongside a non-null $error. */

		$result = ( new OsApiOrderService() )->update( $order, (array) $request->get_json_params() );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return $this->response_from_data( $this->serializer()->to_array_single( $result, 'view' ), $request );
	}

	public function delete_item( $request ) {
		list( $order, $error ) = OsApiQuery::find_scoped( 'OsOrderModel', (int) $request['id'] );
		if ( $error ) {
			return $this->not_found_or_forbidden( $error );
		}
		/** @var OsOrderModel $order find_scoped() only returns null alongside a non-null $error. */

		$previous = $this->serializer()->to_array_single( $order, 'view' );
		$result   = ( new OsApiOrderService() )->delete( $order );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return rest_ensure_response(
			[
				'deleted'  => true,
				'previous' => $previous,
			]
		);
	}
}
