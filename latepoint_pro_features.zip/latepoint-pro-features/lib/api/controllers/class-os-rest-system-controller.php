<?php
/**
 * System REST controller — GET /system, a self-description endpoint for integrators.
 *
 * Deliberately reports whether Application Passwords are available and whether a
 * conflicting third-party "LatePoint API" plugin (which squats the latepoint-api/v1
 * namespace) is active — both are real, otherwise-silent integration failure modes.
 *
 * @package LatePoint\Api
 * @since   5.4.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class OsRestSystemController extends WP_REST_Controller {

	protected $namespace = 'latepoint/v1';
	protected $rest_base = 'system';

	public function register_routes() {
		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base,
			[
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => [ $this, 'get_info' ],
				'permission_callback' => [ $this, 'permissions_check' ],
			]
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/test',
			[
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => [ $this, 'get_test' ],
				'permission_callback' => [ $this, 'test_permissions_check' ],
			]
		);
	}

	/**
	 * Deliberately not authenticated, unlike every other endpoint — the whole point is to be
	 * checkable before you have working credentials. No explicit on/off check needed here:
	 * this whole class only ever loads when OsSettingsHelper::is_on('latepoint_rest_api') is
	 * already true (see latepoint-pro-features.php::core_includes()), so if this route was
	 * even reached, the API is already known to be enabled.
	 */
	public function test_permissions_check( $request ) {
		return true;
	}

	public function get_test( $request ) {
		return rest_ensure_response(
			[
				'status'           => 'ok',
				'rest_api_enabled' => true,
				'plugin_version'   => LATEPOINT_VERSION,
			]
		);
	}

	public function permissions_check( $request ) {
		return OsRestController::check_backend_access( 'read' );
	}

	public function get_info( $request ) {
		$conflicting_namespace_active = in_array( 'latepoint-api/v1', rest_get_server()->get_namespaces(), true );

		return rest_ensure_response(
			[
				'plugin_version'                  => LATEPOINT_VERSION,
				'api_namespace'                   => 'latepoint/v1',
				'timezone'                        => OsTimeHelper::get_wp_timezone_name(),
				'date_format'                     => OsSettingsHelper::get_date_format(),
				'currency'                        => OsSettingsHelper::get_settings_value( 'currency', 'USD' ),
				'public_availability_enabled'     => OsSettingsHelper::is_on( 'latepoint_rest_api_public_availability' ),
				'application_passwords_available' => function_exists( 'wp_is_application_passwords_available' ) && wp_is_application_passwords_available(),
				'conflicting_api_plugin_detected' => $conflicting_namespace_active,
				'current_user'                    => [
					'wp_user_id'   => get_current_user_id(),
					'backend_type' => OsAuthHelper::get_current_user()->backend_user_type,
				],
			]
		);
	}
}
