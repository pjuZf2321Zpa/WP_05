<?php
/**
 * Coupons REST controller — GET /coupons, GET/PATCH/DELETE /coupons/{id}, POST /coupons.
 *
 * Writes are delegated to OsApiCouponService, which ports the already-correct logic from
 * the coupon abilities and coupons_controller.php rather than reimplementing it.
 *
 * Extends the free plugin's OsRestController — available because free's lib/api/* classes
 * load unconditionally before do_action('latepoint_includes') fires (which is what triggers
 * this plugin's own core_includes()).
 *
 * @package LatePoint\Pro\Api
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class OsRestCouponsController extends OsRestController {

	protected $rest_base    = 'coupons';
	protected $supports     = [ 'list', 'get', 'create', 'update', 'delete' ];
	protected $capabilities = [
		'read'   => 'coupon__view',
		'create' => 'coupon__create',
		'update' => 'coupon__edit',
		'delete' => 'coupon__delete',
	];

	protected function model_class(): string {
		return 'OsCouponModel';
	}

	protected function serializer(): OsApiSerializer {
		return new OsApiCouponSerializer();
	}

	protected function orderby_map(): array {
		return [
			'id'      => LATEPOINT_TABLE_COUPONS . '.id',
			'code'    => LATEPOINT_TABLE_COUPONS . '.code',
			'created' => LATEPOINT_TABLE_COUPONS . '.created_at',
			'updated' => LATEPOINT_TABLE_COUPONS . '.updated_at',
		];
	}

	protected function resource_collection_params(): array {
		return [
			'code'          => [
				'description' => __( 'Exact coupon code match (case-insensitive).', 'latepoint-pro-features' ),
				'type'        => 'string',
			],
			'status'        => [
				'type' => 'string',
				'enum' => [ 'active', 'disabled' ],
			],
			'discount_type' => [
				'type' => 'string',
				'enum' => [ 'fixed', 'percent' ],
			],
		];
	}

	protected function apply_collection_filters( OsModel $query, WP_REST_Request $request ): OsModel {
		$params = $request->get_params();

		if ( ! empty( $params['code'] ) ) {
			$query->where( [ 'code' => strtoupper( trim( sanitize_text_field( $params['code'] ) ) ) ] );
		}
		if ( ! empty( $params['status'] ) ) {
			$query->where( [ 'status' => sanitize_text_field( $params['status'] ) ] );
		}
		if ( ! empty( $params['discount_type'] ) ) {
			$query->where( [ 'discount_type' => sanitize_text_field( $params['discount_type'] ) ] );
		}

		return $query;
	}

	public function create_item( $request ) {
		$result = ( new OsApiCouponService() )->create( (array) $request->get_json_params() );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$response = $this->response_from_data( $this->serializer()->to_array_single( $result, 'view' ), $request );
		$response->set_status( 201 );
		$response->header( 'Location', rest_url( 'latepoint/v1/coupons/' . $result->id ) );

		return $response;
	}

	public function update_item( $request ) {
		list( $coupon, $error ) = OsApiQuery::find_scoped( 'OsCouponModel', (int) $request['id'] );
		if ( $error ) {
			return $this->not_found_or_forbidden( $error );
		}

		$result = ( new OsApiCouponService() )->update( $coupon, (array) $request->get_json_params() );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return $this->response_from_data( $this->serializer()->to_array_single( $result, 'view' ), $request );
	}

	public function delete_item( $request ) {
		list( $coupon, $error ) = OsApiQuery::find_scoped( 'OsCouponModel', (int) $request['id'] );
		if ( $error ) {
			return $this->not_found_or_forbidden( $error );
		}

		$previous = $this->serializer()->to_array_single( $coupon, 'view' );
		$result   = ( new OsApiCouponService() )->delete( $coupon );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return rest_ensure_response(
			[
				'deleted'  => true,
				'previous' => $previous,
			]
		);
	}
}
