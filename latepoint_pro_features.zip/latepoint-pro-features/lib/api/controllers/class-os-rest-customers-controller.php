<?php
/**
 * Customers REST controller — full CRUD.
 *
 * @package LatePoint\Api
 * @since   5.4.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class OsRestCustomersController extends OsRestController {

	protected $rest_base    = 'customers';
	protected $supports     = [ 'list', 'get', 'create', 'update', 'delete' ];
	protected $capabilities = [
		'read'   => 'customer__view',
		'create' => 'customer__create',
		'update' => 'customer__edit',
		'delete' => 'customer__delete',
	];

	protected function model_class(): string {
		return 'OsCustomerModel';
	}

	protected function serializer(): OsApiSerializer {
		return new OsApiCustomerSerializer();
	}

	protected function orderby_map(): array {
		return [
			'id'      => LATEPOINT_TABLE_CUSTOMERS . '.id',
			'created' => LATEPOINT_TABLE_CUSTOMERS . '.created_at',
			'updated' => LATEPOINT_TABLE_CUSTOMERS . '.updated_at',
		];
	}

	protected function resource_collection_params(): array {
		return [
			'search' => [
				'description' => __( 'Search by name, email, or phone.', 'latepoint' ),
				'type'        => 'string',
			],
			'email'  => [
				'description' => __( 'Exact email match.', 'latepoint' ),
				'type'        => 'string',
			],
		];
	}

	protected function apply_collection_filters( OsModel $query, WP_REST_Request $request ): OsModel {
		$params = $request->get_params();

		if ( ! empty( $params['email'] ) ) {
			$query->where( [ 'email' => sanitize_email( $params['email'] ) ] );
		}
		if ( ! empty( $params['search'] ) ) {
			$search_term = '%' . sanitize_text_field( $params['search'] ) . '%';
			$query->where(
				[
					'OR' => [
						'CONCAT (first_name, " ", last_name) LIKE ' => $search_term,
						'email LIKE' => $search_term,
						'phone LIKE' => $search_term,
					],
				]
			);
		}

		return $query;
	}

	public function create_item( $request ) {
		$result = ( new OsApiCustomerService() )->create( (array) $request->get_json_params() );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$response = $this->response_from_data( $this->serializer()->to_array_single( $result, 'view' ), $request );
		$response->set_status( 201 );
		$response->header( 'Location', rest_url( 'latepoint/v1/customers/' . $result->id ) );

		return $response;
	}

	public function update_item( $request ) {
		list( $customer, $error ) = OsApiQuery::find_scoped( 'OsCustomerModel', (int) $request['id'] );
		if ( $error ) {
			return $this->not_found_or_forbidden( $error );
		}
		/** @var OsCustomerModel $customer find_scoped() only returns null alongside a non-null $error. */
		if ( ! OsRolesHelper::can_user_make_action_on_model_record( $customer, 'edit' ) ) {
			return new WP_Error( 'latepoint_rest_forbidden', __( 'You do not have permission to edit this customer.', 'latepoint' ), [ 'status' => 403 ] );
		}

		$result = ( new OsApiCustomerService() )->update( $customer, (array) $request->get_json_params() );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return $this->response_from_data( $this->serializer()->to_array_single( $result, 'view' ), $request );
	}

	public function delete_item( $request ) {
		list( $customer, $error ) = OsApiQuery::find_scoped( 'OsCustomerModel', (int) $request['id'] );
		if ( $error ) {
			return $this->not_found_or_forbidden( $error );
		}
		/** @var OsCustomerModel $customer find_scoped() only returns null alongside a non-null $error. */
		if ( ! OsRolesHelper::can_user_make_action_on_model_record( $customer, 'delete' ) ) {
			return new WP_Error( 'latepoint_rest_forbidden', __( 'You do not have permission to delete this customer.', 'latepoint' ), [ 'status' => 403 ] );
		}

		$previous = $this->serializer()->to_array_single( $customer, 'view' );
		$result   = ( new OsApiCustomerService() )->delete( $customer );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return rest_ensure_response(
			[
				'deleted'  => true,
				'previous' => $previous,
			]
		);
	}
}
