<?php
/**
 * Resource controller registry for the LatePoint REST API.
 *
 * Mirrors LatePointAbilities' $config_modules + latepoint_ability_config_modules pattern
 * (free plugin, lib/abilities/class-latepoint-abilities.php) so a third-party add-on can
 * register its own REST resources the same way it already registers its own abilities.
 * Coupons is a native resource in the array below rather than registered via the filter —
 * it used to be added from a separate free-plugin extension point back when this whole
 * framework lived in the free plugin, but now that it's all Pro's own code, there's no
 * cross-plugin boundary left to abstract for Pro's own resources. The filter itself stays,
 * for genuine third-party add-ons.
 *
 * @package LatePoint\Pro\Api
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class OsApiRegistry {

	/**
	 * slug => class name, or ['class' => ..., 'file' => absolute path to require].
	 *
	 * The array form lets an add-on register a controller that lives outside this
	 * plugin's own lib/api/controllers/ directory.
	 *
	 * @var array<string,string|array<string,string>>
	 */
	private static $resources = [
		'bookings'           => 'OsRestBookingsController',
		'customers'          => 'OsRestCustomersController',
		'orders'             => 'OsRestOrdersController',
		'payments'           => 'OsRestPaymentsController',
		'services'           => 'OsRestServicesController',
		'service-categories' => 'OsRestServiceCategoriesController',
		'agents'             => 'OsRestAgentsController',
		'locations'          => 'OsRestLocationsController',
		'availability'       => 'OsRestAvailabilityController',
		'system'             => 'OsRestSystemController',
		'coupons'            => 'OsRestCouponsController',
	];

	/**
	 * @return array<string,string|array<string,string>>
	 */
	private static function get_resources(): array {
		/**
		 * Filters the REST resource controllers registered under the latepoint/v1 namespace.
		 *
		 * Add-ons (e.g. the Pro plugin) hook this to register their own resources, mirroring
		 * how latepoint_ability_config_modules works for AI abilities.
		 *
		 * @since 5.4.0
		 * @hook latepoint_rest_api_controllers
		 *
		 * @param {array} $resources Map of resource slug => controller class name, or
		 *                           ['class' => ..., 'file' => ...] for controllers that
		 *                           live outside this plugin.
		 * @returns {array} The filtered map.
		 */
		return apply_filters( 'latepoint_rest_api_controllers', self::$resources );
	}

	/**
	 * require_once each concrete controller file, lazily — only called from rest_api_init,
	 * never on a page load that doesn't touch the REST API.
	 */
	public static function register_routes(): void {
		foreach ( self::get_resources() as $slug => $resource ) {
			$class = is_array( $resource ) ? ( $resource['class'] ?? '' ) : $resource;
			if ( empty( $class ) ) {
				continue;
			}

			if ( ! class_exists( $class ) ) {
				$file = is_array( $resource ) && ! empty( $resource['file'] )
					? $resource['file']
					: LATEPOINT_ADDON_PRO_LIB_ABSPATH . 'api/controllers/class-os-rest-' . $slug . '-controller.php';
				if ( file_exists( $file ) ) {
					require_once $file;
				}
			}

			if ( ! class_exists( $class ) ) {
				continue;
			}

			( new $class() )->register_routes();
		}
	}
}
