<?php
/*
 * Copyright (c) 2024 LatePoint LLC. All rights reserved.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}


if ( ! class_exists( 'OsRecurringBookingsController' ) ) :


	class OsRecurringBookingsController extends OsController {


		public function __construct() {
			parent::__construct();

			$this->views_folder            = plugin_dir_path( __FILE__ ) . '../views/recurring_bookings/';
			$this->action_access['public'] = array_merge(
				$this->action_access['public'],
				[
					'load_datepicker_month',
					'pick_end_date_on_calendar',
					'recurring_bookings_preview',
					'pick_datetime_on_calendar',
					'reload_recurrence_rules',
				] 
			);
		}


		public function pick_end_date_on_calendar() {

			try {
				$target_datetime = new OsWpDateTime( sanitize_text_field( $this->params['preselected_date'] ?? '+2 months' ) );
			} catch ( Exception $e ) {
				$target_datetime = new OsWpDateTime( '+2 months' );
			}

			$this->vars['target_datetime'] = $target_datetime;

			$this->format_render( __FUNCTION__ );
		}

		public function pick_datetime_on_calendar() {
			OsStepsHelper::set_required_objects( $this->params );

			try {
				$target_datetime = new OsWpDateTime( sanitize_text_field( $this->params['preselected_datetime_utc'] ?? 'now' ), new DateTimeZone( 'UTC' ) );
				$target_datetime->setTimezone( new DateTimeZone( sanitize_text_field( $this->params['timezone_name'] ) ) );
			} catch ( Exception $e ) {
				$target_datetime = new OsWpDateTime( 'now' );
			}

			$this->vars['target_datetime'] = $target_datetime;
			$this->vars['booking']         = OsStepsHelper::$booking_object;

			$this->format_render( __FUNCTION__ );
		}

		public function load_datepicker_month() {
			try {
				$target_datetime = new OsWpDateTime( sanitize_text_field( $this->params['target_date_string'] ?? 'now' ) );
			} catch ( Exception $e ) {
				$target_datetime = new OsWpDateTime( 'now' );
			}

			$this->vars['target_datetime'] = $target_datetime;

			$this->format_render( __FUNCTION__ );
		}

		/**
		 * @param array|null $rules_params Defaults to the booking form's flat "recurrence" params.
		 *
		 * @return array
		 */
		public function recurrence_rules_params( ?array $rules_params = null ): array {
			$allowed_params = array(
				'repeat_unit',
				'repeat_interval',
				'repeat_on_weekdays',
				'repeat_end_operator',
				'repeat_end_date',
				'repeat_end_counter',
				'changed',
			);
			$rules_params   = ( null === $rules_params ) ? ( $this->params['recurrence']['rules'] ?? [] ) : $rules_params;
			$settings       = [];
			foreach ( $allowed_params as $param ) {
				if ( ! empty( $rules_params[ $param ] ) ) {
					$settings[ $param ] = sanitize_text_field( $rules_params[ $param ] );
				}
			}
			return $settings;
		}

		public function reload_recurrence_rules() {
			OsStepsHelper::set_required_objects( $this->params );

			$recurrence_rules = $this->recurrence_rules_params();

			$recurrence_rules['max_repeat_end_counter'] = OsStepsHelper::$booking_object->service->get_meta_by_key( 'maximum_number_of_recurring_bookings', 20 );

			$status        = LATEPOINT_STATUS_SUCCESS;
			$response_html = OsFeatureRecurringBookingsHelper::generate_recurrence_rules_for_booking_form( OsStepsHelper::$booking_object->get_start_datetime_for_customer(), $recurrence_rules, OsStepsHelper::$booking_object );


			if ( $this->get_return_format() == 'json' ) {
				$this->send_json(
					[
						'status'  => $status,
						'message' => $response_html,
					] 
				);
			}
		}


		public function recurring_bookings_preview() {
			OsStepsHelper::set_required_objects( $this->params );
			$recurrence = $this->params['recurrence'];

			$recurrence_rules = $recurrence['rules'] ?? [];
			if ( $recurrence['rules']['changed'] == 'no' ) {
				// reuse selections from booking preview
				$recurrence_overrides = $recurrence['overrides'];
			} else {
				$recurrence_overrides = [];
			}


			try {
				$customer_timezone = new DateTimeZone( sanitize_text_field( $this->params['timezone_name'] ) ) ?? OsTimeHelper::get_timezone_from_session();
			} catch ( Exception $e ) {
				$customer_timezone = OsTimeHelper::get_wp_timezone();
			}

			$recurring_bookings_data_and_errors = OsFeatureRecurringBookingsHelper::generate_recurring_bookings_data( OsStepsHelper::$booking_object, $recurrence_rules, $recurrence_overrides, $customer_timezone );


			$selection_form_fields_html = '';
			foreach ( $recurring_bookings_data_and_errors['bookings_data'] as $original_stamp => $recurring_bookings_datum ) {
				$selection_form_fields_html .= OsFormHelper::hidden_field( 'recurrence[overrides][' . $original_stamp . '][custom_day]', $recurring_bookings_datum['custom_day'] ?? '', [ 'class' => 'recurring_booking_custom_day' ] );
				$selection_form_fields_html .= OsFormHelper::hidden_field( 'recurrence[overrides][' . $original_stamp . '][custom_minutes]', $recurring_bookings_datum['custom_minutes'] ?? '', [ 'class' => 'recurring_booking_custom_minutes' ] );
				$selection_form_fields_html .= OsFormHelper::hidden_field( 'recurrence[overrides][' . $original_stamp . '][unchecked]', $recurring_bookings_datum['unchecked'] ?? 'no' );
			}

			$non_bookable_count = 0;
			foreach ( $recurring_bookings_data_and_errors['bookings_data'] as $original_stamp => $recurring_bookings_datum ) {
				if ( ! $recurring_bookings_datum['is_bookable'] ) {
					$non_bookable_count++;
				}
			}

			$this->vars['non_bookable_count']        = $non_bookable_count;
			$this->vars['recurring_bookings_data']   = $recurring_bookings_data_and_errors['bookings_data'];
			$this->vars['recurring_bookings_errors'] = $recurring_bookings_data_and_errors['errors'];
			$this->vars['price_info']                = OsFeatureRecurringBookingsHelper::generate_price_info_for_recurring_set( $recurring_bookings_data_and_errors['bookings_data'], OsStepsHelper::is_bundle_scheduling() );
			$this->vars['bookings_info']             = OsFeatureRecurringBookingsHelper::generate_bookings_info_for_recurring_set( $recurring_bookings_data_and_errors['bookings_data'] );

			if ( $this->get_return_format() == 'json' ) {
				$preview_html = $this->render( $this->views_folder . __FUNCTION__, 'none' );
				$this->send_json(
					array(
						'status'        => LATEPOINT_STATUS_SUCCESS,
						'preview'       => $preview_html,
						'fields'        => $selection_form_fields_html,
						'price_info'    => $this->vars['price_info'],
						'bookings_info' => $this->vars['bookings_info'],
					) 
				);
			}
		}

		/* --- Recurring appointments in the admin order quick edit form (#396) ---
		 * Not public: capabilities come from OsFeatureRecurringBookingsHelper::add_capabilities_for_controller().
		 * ------------------------------------------------------------------- */

		/**
		 * Nonce and record level access gate shared by every admin recurring action, applying the same order
		 * scoping as OsOrdersController::create_or_update().
		 *
		 * @return OsBookingModel|null The anchor booking, or null when the request could not be honoured.
		 */
		private function admin_recurring_guard(): ?OsBookingModel {
			if ( empty( $this->params['_wpnonce'] ) ) {
				$this->admin_recurring_json_error( __( 'Invalid Request', 'latepoint-pro-features' ) );

				return null;
			}

			$order_id = absint( $this->params['order']['id'] ?? 0 );
			if ( $order_id ) {
				$this->check_nonce( 'edit_order_' . $order_id );
				$allowed_order = ( new OsOrderModel() )->where( [ LATEPOINT_TABLE_ORDERS . '.id' => $order_id ] )->filter_allowed_records()->set_limit( 1 )->get_results_as_models();
				if ( ! $allowed_order ) {
					$this->admin_recurring_json_error( __( 'Not Allowed', 'latepoint-pro-features' ) );

					return null;
				}
			} else {
				$this->check_nonce( 'new_order' );
			}

			return $this->admin_recurring_booking_from_params();
		}

		/**
		 * Rebuilds the anchor booking from the submitted order form.
		 *
		 * @return OsBookingModel|null
		 */
		private function admin_recurring_booking_from_params(): ?OsBookingModel {
			$booking_form_id = OsFeatureRecurringBookingsHelper::admin_sanitize_key( $this->params['booking_form_id'] ?? '' );
			$booking_params  = $this->admin_recurring_posted_booking_params();

			if ( empty( $booking_params ) ) {
				return null;
			}

			$booking = OsOrdersHelper::create_booking_object_from_booking_data_form( $booking_params );
			if ( ! ( $booking instanceof OsBookingModel ) ) {
				return null;
			}

			// The customer drives the grid's timezone and the price context.
			$customer_id = absint( $this->params['order']['customer_id'] ?? 0 );
			if ( $customer_id ) {
				$booking->customer_id = $customer_id;
			}
			$booking->form_id = $booking_form_id;

			return $booking;
		}

		/**
		 * The booking form's own posted params, for the booking form this request is about.
		 *
		 * @return array
		 */
		private function admin_recurring_posted_booking_params(): array {
			$order_item_id   = OsFeatureRecurringBookingsHelper::admin_sanitize_key( $this->params['order_item_id'] ?? '' );
			$booking_form_id = OsFeatureRecurringBookingsHelper::admin_sanitize_key( $this->params['booking_form_id'] ?? '' );

			if ( empty( $order_item_id ) || empty( $booking_form_id ) ) {
				return [];
			}

			$booking_params = $this->params['order_items'][ $order_item_id ]['bookings'][ $booking_form_id ] ?? [];

			return is_array( $booking_params ) ? $booking_params : [];
		}

		/**
		 * Whitelists and clamps the recurrence rules posted for one booking form.
		 *
		 * Clamped here, not in recurrence_rules_params(): the booking form allows a far larger series than one
		 * admin order submission can carry.
		 *
		 * @param OsBookingModel $booking
		 *
		 * @return array
		 */
		private function admin_recurring_rules_from_params( OsBookingModel $booking ): array {
			$posted = $this->admin_recurring_posted_booking_params()['recurrence']['rules'] ?? [];

			$rules     = $this->recurrence_rules_params( is_array( $posted ) ? $posted : [] );
			$defaults  = OsFeatureRecurringBookingsHelper::admin_default_recurrence_rules( $booking );
			$max_limit = OsFeatureRecurringBookingsHelper::admin_recurring_max_limit( $booking );
			$rules     = array_merge( $defaults, $rules );

			if ( ! in_array( $rules['repeat_unit'], [ 'day', 'week', 'month' ], true ) ) {
				$rules['repeat_unit'] = 'week';
			}
			$rules['repeat_interval'] = min( max( absint( $rules['repeat_interval'] ), 1 ), 500 );

			if ( ! in_array( $rules['repeat_end_operator'], [ 'count', 'date' ], true ) ) {
				$rules['repeat_end_operator'] = 'count';
			}
			$rules['repeat_end_counter'] = min( max( absint( $rules['repeat_end_counter'] ), 1 ), $max_limit );

			$weekdays = [];
			foreach ( explode( ',', (string) $rules['repeat_on_weekdays'] ) as $weekday ) {
				$weekday = absint( $weekday );
				if ( $weekday >= 1 && $weekday <= 7 ) {
					$weekdays[ $weekday ] = $weekday;
				}
			}
			$rules['repeat_on_weekdays'] = empty( $weekdays ) ? $defaults['repeat_on_weekdays'] : implode( ',', $weekdays );

			// The anchor moved, so the posted weekdays belong to the old start date - follow the new one.
			if ( ! empty( $this->params['reanchored'] ) ) {
				$rules['repeat_on_weekdays'] = $defaults['repeat_on_weekdays'];
			}

			if ( ! empty( $rules['repeat_end_date'] ) ) {
				$end_date                 = OsWpDateTime::os_createFromFormat( 'Y-m-d', sanitize_text_field( $rules['repeat_end_date'] ) );
				$rules['repeat_end_date'] = $end_date ? $end_date->format( 'Y-m-d' ) : '';
			}

			$rules['max_repeat_end_counter'] = $max_limit;

			return $rules;
		}

		/**
		 * The per occurrence selections posted with the form. Only honoured when the rules did not change: the
		 * map is keyed by each occurrence's original UTC stamp, which re-anchoring invalidates.
		 *
		 * @param array $rules
		 * @param OsBookingModel $booking
		 *
		 * @return array
		 */
		private function admin_recurring_overrides_from_params( array $rules, OsBookingModel $booking ): array {
			if ( ( $rules['changed'] ?? 'yes' ) !== 'no' ) {
				return [];
			}

			$posted = $this->admin_recurring_posted_booking_params()['recurrence']['overrides'] ?? [];

			if ( ! is_array( $posted ) ) {
				return [];
			}

			$overrides = [];
			foreach ( $posted as $stamp => $override ) {
				if ( ! is_array( $override ) ) {
					continue;
				}
				$stamp = OsFeatureRecurringBookingsHelper::admin_sanitize_key( $stamp );
				if ( empty( $stamp ) ) {
					continue;
				}
				$clean = [];
				if ( ! empty( $override['custom_day'] ) ) {
					$custom_day = OsWpDateTime::os_createFromFormat( 'Y-m-d', sanitize_text_field( $override['custom_day'] ) );
					if ( $custom_day ) {
						$clean['custom_day']     = $custom_day->format( 'Y-m-d' );
						$clean['custom_minutes'] = min( max( absint( $override['custom_minutes'] ?? 0 ), 0 ), 1440 );
					}
				}
				$clean['unchecked']  = ( ( $override['unchecked'] ?? 'no' ) === 'yes' ) ? 'yes' : 'no';
				$overrides[ $stamp ] = $clean;
			}

			return $this->admin_apply_reschedule_to_overrides( $overrides, $booking );
		}

		/**
		 * Folds a slot picked from core's availability panel into the override map.
		 *
		 * The panel lists site time, an override is stored in customer time. Without converting, the occurrence
		 * lands at the wrong absolute time whenever those differ. Re-selected too, since it was only deselected
		 * for being unavailable.
		 *
		 * @param array $overrides
		 * @param OsBookingModel $booking
		 *
		 * @return array
		 */
		private function admin_apply_reschedule_to_overrides( array $overrides, OsBookingModel $booking ): array {
			$stamp = OsFeatureRecurringBookingsHelper::admin_sanitize_key( $this->params['reschedule_stamp'] ?? '' );
			$day   = sanitize_text_field( $this->params['reschedule_day'] ?? '' );
			if ( empty( $stamp ) || empty( $day ) ) {
				return $overrides;
			}

			$minutes = min( max( absint( $this->params['reschedule_minutes'] ?? 0 ), 0 ), 1440 );
			$picked  = OsWpDateTime::os_createFromFormat(
				'Y-m-d H:i',
				$day . ' ' . OsTimeHelper::minutes_to_army_hours_and_minutes( $minutes ),
				OsTimeHelper::get_wp_timezone()
			);
			if ( ! $picked ) {
				return $overrides;
			}

			$picked->setTimezone( $booking->get_customer_timezone() );
			$overrides[ $stamp ]['custom_day']     = $picked->format( 'Y-m-d' );
			$overrides[ $stamp ]['custom_minutes'] = OsTimeHelper::convert_datetime_to_minutes( $picked );
			$overrides[ $stamp ]['unchecked']      = 'no';

			return $overrides;
		}

		/**
		 * @param string $message
		 *
		 * @return void
		 */
		private function admin_recurring_json_error( string $message ) {
			$this->send_json(
				[
					'status'  => LATEPOINT_STATUS_ERROR,
					'message' => $message,
				]
			);
		}

		/**
		 * Recomputes the occurrence list, override fields, total and summary for one booking form. Returns a
		 * fresh rules widget when the service changed under it.
		 *
		 * @return void
		 */
		public function admin_recurring_preview() {
			$booking = $this->admin_recurring_guard();
			if ( ! $booking ) {
				$this->admin_recurring_json_error( __( 'Could not read the appointment details.', 'latepoint-pro-features' ) );

				return;
			}

			$field_prefix = OsFeatureRecurringBookingsHelper::admin_recurring_field_prefix(
				(string) ( $this->params['order_item_id'] ?? '' ),
				(string) ( $this->params['booking_form_id'] ?? '' )
			);

			$response = [
				'status'     => LATEPOINT_STATUS_SUCCESS,
				'preview'    => '',
				'fields'     => '',
				'price_info' => '',
			];

			$rules = $this->admin_recurring_rules_from_params( $booking );

			// Re-rendered on a service change, so allowed units and the maximum follow the new service.
			if ( ! empty( $this->params['reload_rules'] ) ) {
				$response['rules'] = OsFeatureRecurringBookingsHelper::admin_service_allows_recurring( absint( $booking->service_id ) )
					? OsFeatureRecurringBookingsHelper::admin_render_recurrence_rules_form( $booking, $rules, $field_prefix )
					: '';
			}

			$response['supported'] = OsFeatureRecurringBookingsHelper::admin_service_allows_recurring( absint( $booking->service_id ) ) ? 'yes' : 'no';

			if ( 'yes' === $response['supported'] && $booking->is_start_date_and_time_set() ) {
				$overrides = $this->admin_recurring_overrides_from_params( $rules, $booking );
				$preview   = OsFeatureRecurringBookingsHelper::admin_compute_recurring_preview( $booking, $rules, $overrides );

				$response['preview']    = OsFeatureRecurringBookingsHelper::admin_render_recurring_slots( $preview, $booking );
				$response['fields']     = OsFeatureRecurringBookingsHelper::admin_render_recurring_override_fields( $preview['bookings_data'], $field_prefix );
				$response['price_info'] = OsFeatureRecurringBookingsHelper::generate_price_info_for_recurring_set( $preview['bookings_data'], false, [ 'ignore_availability' => true ] );

				// Keeps the collapsed pill's count in step with the selection.
				$selected = 0;
				foreach ( $preview['bookings_data'] as $datum ) {
					if ( ( $datum['unchecked'] ?? 'no' ) !== 'yes' ) {
						$selected++;
					}
				}
				$response['pill_summary'] = OsFeatureRecurringBookingsHelper::recurring_pill_summary( $selected );
				$response['pill_dots']    = OsFeatureRecurringBookingsHelper::recurring_pill_dots( $selected );
			}

			$this->send_json( $response );
		}

		/**
		 * Stores one recurrence record and returns every selected occurrence as its own order item block.
		 *
		 * @return void
		 */
		public function admin_recurring_expand() {
			$booking = $this->admin_recurring_guard();
			if ( ! $booking ) {
				$this->admin_recurring_json_error( __( 'Could not read the appointment details.', 'latepoint-pro-features' ) );

				return;
			}

			if ( ! OsFeatureRecurringBookingsHelper::admin_service_allows_recurring( absint( $booking->service_id ) ) ) {
				$this->admin_recurring_json_error( __( 'This service does not support recurring appointments.', 'latepoint-pro-features' ) );

				return;
			}

			if ( ! $booking->is_start_date_and_time_set() ) {
				$this->admin_recurring_json_error( __( 'Pick a date and time for the first appointment.', 'latepoint-pro-features' ) );

				return;
			}

			$rules     = $this->admin_recurring_rules_from_params( $booking );
			$overrides = $this->admin_recurring_overrides_from_params( $rules, $booking );
			$preview   = OsFeatureRecurringBookingsHelper::admin_compute_recurring_preview( $booking, $rules, $overrides );

			$recurrence = $this->admin_recurring_recurrence_record( $rules, $overrides );
			if ( ! $recurrence ) {
				$this->admin_recurring_json_error( __( 'Could not save the recurrence.', 'latepoint-pro-features' ) );

				return;
			}

			$blocks = OsFeatureRecurringBookingsHelper::admin_build_occurrence_blocks( $booking, $preview['bookings_data'], (int) $recurrence->id );

			if ( empty( $blocks['count'] ) ) {
				$this->admin_recurring_json_error( __( 'No additional appointments were selected.', 'latepoint-pro-features' ) );

				return;
			}

			$this->send_json(
				[
					'status'           => LATEPOINT_STATUS_SUCCESS,
					'blocks'           => $blocks['html'],
					'recurrence_id'    => $recurrence->id,
					'recurrence_token' => wp_create_nonce( 'latepoint_admin_recurrence_' . $recurrence->id ),
					'created_count'    => $blocks['count'],
				]
			);
		}

		/**
		 * Creates the recurrence record, or reuses the one this form already made when its token verifies, so
		 * re-expanding does not leave orphan rows.
		 *
		 * @param array $rules
		 * @param array $overrides
		 *
		 * @return OsRecurrenceModel|null
		 */
		private function admin_recurring_recurrence_record( array $rules, array $overrides ): ?OsRecurrenceModel {
			$booking_params = $this->admin_recurring_posted_booking_params();

			$existing_id = absint( $booking_params['recurrence_id'] ?? 0 );
			$token       = $booking_params['recurrence']['token'] ?? '';

			$recurrence = null;
			if ( $existing_id && ! empty( $token ) && wp_verify_nonce( $token, 'latepoint_admin_recurrence_' . $existing_id ) ) {
				$candidate = new OsRecurrenceModel( $existing_id );
				if ( ! $candidate->is_new_record() ) {
					$recurrence = $candidate;
				}
			}
			if ( ! $recurrence ) {
				$recurrence = new OsRecurrenceModel();
			}

			// A rendering hint for the counter field, not a rule - the customer flow never stores it.
			$stored_rules = $rules;
			unset( $stored_rules['max_repeat_end_counter'] );

			// Assigned directly, not via set_data(): OsRecurrenceModel allows "id" as a mass assignable param.
			$recurrence->rules     = wp_json_encode( $stored_rules );
			$recurrence->overrides = wp_json_encode( $overrides );

			if ( ! $recurrence->save() ) {
				OsDebugHelper::log( 'Error saving recurrence record (admin)', 'recurrence_save_error', $recurrence->get_error_messages() );

				return null;
			}

			return $recurrence;
		}

		/**
		 * Builds the order item block for the "Recurring" tile in the New Order picker.
		 *
		 * An ordinary booking data form with the rules panel attached; admin_recurring_expand() then turns it
		 * into one order item per occurrence.
		 *
		 * @return void
		 */
		public function generate_recurring_order_item_block() {
			$order_id = absint( $this->params['order_id'] ?? 0 );
			$this->check_nonce( $order_id ? 'edit_order_' . $order_id : 'new_order' );

			// Same order scoping admin_recurring_guard() applies.
			if ( $order_id ) {
				$allowed_order = ( new OsOrderModel() )->where( [ LATEPOINT_TABLE_ORDERS . '.id' => $order_id ] )->filter_allowed_records()->set_limit( 1 )->get_results_as_models();
				if ( ! $allowed_order ) {
					$this->admin_recurring_json_error( __( 'Not Allowed', 'latepoint-pro-features' ) );

					return;
				}
			}

			$services = OsFeatureRecurringBookingsHelper::get_recurring_enabled_services();
			if ( empty( $services ) ) {
				$this->admin_recurring_json_error( __( 'No service has recurring appointments enabled.', 'latepoint-pro-features' ) );

				return;
			}

			// Fall back to the first recurring enabled one: prepare_new_from_params() would pick the first
			// allowed service, which may not support recurring.
			$requested_service_id = absint( $this->params['service_id'] ?? 0 );
			$service_id           = 0;
			foreach ( $services as $service ) {
				if ( ! $service_id || (int) $service->id === $requested_service_id ) {
					$service_id = (int) $service->id;
				}
			}

			$booking_params               = $this->params;
			$booking_params['service_id'] = $service_id;
			unset( $booking_params['order_item_id'] );

			$booking       = OsBookingHelper::prepare_new_from_params( $booking_params );
			$order_item_id = OsUtilHelper::generate_form_id();

			OsFeatureRecurringBookingsHelper::set_rendering_recurring_form( true );
			$html  = '<div class="order-item order-item-variant-booking order-item-variant-recurring" data-order-item-id="' . esc_attr( $order_item_id ) . '">';
			$html .= OsOrdersHelper::booking_data_form_for_order_item_id( $order_item_id, $booking, LATEPOINT_ITEM_VARIANT_BOOKING, false );
			$html .= '</div>';
			OsFeatureRecurringBookingsHelper::set_rendering_recurring_form( false );

			$this->send_json(
				[
					'status'  => LATEPOINT_STATUS_SUCCESS,
					'message' => $html,
				]
			);
		}
	}

endif;
