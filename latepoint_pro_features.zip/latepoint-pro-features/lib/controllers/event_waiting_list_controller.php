<?php
/*
 * Copyright (c) 2024 LatePoint LLC. All rights reserved.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'OsEventWaitingListController' ) ) :

	/**
	 * Managing an event's waiting list from the admin.
	 *
	 * Joining happens in the booking wizard, not here. Every action on this controller is gated by
	 * the capability map registered in OsFeatureEventWaitingListHelper::add_capabilities().
	 */
	class OsEventWaitingListController extends OsController {

		public function __construct() {
			parent::__construct();

			$this->views_folder = LATEPOINT_ADDON_PRO_VIEWS_ABSPATH . 'event_waiting_list/';

			// Same header treatment core gives its own Events screens, so the Events tab row and
			// breadcrumbs stay on screen here instead of the page losing its chrome.
			$this->vars['page_header']     = OsMenuHelper::get_menu_items_by_id( 'events' );
			$this->vars['pre_page_header'] = OsMenuHelper::get_label_by_id( 'events' );
			$this->vars['breadcrumbs'][]   = [
				'label' => __( 'Waiting List', 'latepoint-pro-features' ),
				'link'  => OsRouterHelper::build_link( OsRouterHelper::build_route_name( 'event_waiting_list', 'index' ) ),
			];

			// Nothing here is public: the entry is created by the wizard's own step processing,
			// behind core's nonce and step machinery. Every action below is capability gated.
		}

		// ─── Admin ──────────────────────────────────────────────────────────

		/**
		 * The queue, newest events first. Capability-gated via add_capabilities().
		 */
		public function index() {
			$page_number = max( 1, absint( $this->params['page_number'] ?? 1 ) );
			$per_page    = OsSettingsHelper::get_number_of_records_per_page();
			$offset      = ( $page_number - 1 ) * $per_page;

			$query      = new OsEventWaitingListModel();
			$conditions = [];

			$filter = $this->params['filter'] ?? [];
			if ( ! empty( $filter['id'] ) && filter_var( $filter['id'], FILTER_VALIDATE_INT ) ) {
				$conditions['id'] = (int) $filter['id'];
			}
			if ( ! empty( $filter['event_id'] ) && filter_var( $filter['event_id'], FILTER_VALIDATE_INT ) ) {
				$conditions['event_id'] = (int) $filter['event_id'];
			}
			if ( ! empty( $filter['ticket_type_id'] ) && filter_var( $filter['ticket_type_id'], FILTER_VALIDATE_INT ) ) {
				$conditions['ticket_type_id'] = (int) $filter['ticket_type_id'];
			}
			$allowed_statuses = [
				LATEPOINT_EVENT_WAITING_LIST_STATUS_WAITING,
				LATEPOINT_EVENT_WAITING_LIST_STATUS_INVITED,
				LATEPOINT_EVENT_WAITING_LIST_STATUS_CONVERTED,
				LATEPOINT_EVENT_WAITING_LIST_STATUS_REMOVED,
				LATEPOINT_EVENT_WAITING_LIST_STATUS_EXPIRED,
			];
			if ( ! empty( $filter['status'] ) && in_array( $filter['status'], $allowed_statuses, true ) ) {
				$conditions['status'] = sanitize_text_field( $filter['status'] );
			}
			if ( ! empty( $filter['joined_date_from'] ) && ! empty( $filter['joined_date_to'] ) ) {
				$conditions['created_at >='] = sanitize_text_field( $filter['joined_date_from'] );
				$conditions['created_at <='] = sanitize_text_field( $filter['joined_date_to'] );
			}

			// Name/email live on the customer, not the queue row, so resolve them to ids first:
			// same approach core takes on the registrations table.
			$customer_query = ! empty( $filter['customer'] ) ? sanitize_text_field( $filter['customer'] ) : '';
			$email_query    = ! empty( $filter['email'] ) ? sanitize_text_field( $filter['email'] ) : '';
			if ( '' !== $customer_query || '' !== $email_query ) {
				$customer_args = [];
				if ( '' !== $customer_query ) {
					$customer_args['CONCAT (first_name, " ", last_name) LIKE '] = '%' . $customer_query . '%';
				}
				if ( '' !== $email_query ) {
					$customer_args['email LIKE'] = '%' . $email_query . '%';
				}
				$matched_ids = ( new OsCustomerModel() )->where( $customer_args )->select( 'id' )->get_results( ARRAY_A );
				$matched_ids = $matched_ids ? array_column( $matched_ids, 'id' ) : [];
				if ( $matched_ids ) {
					$query->where_in( 'customer_id', $matched_ids );
				} else {
					// No customer matches, so the queue cannot match either.
					$conditions['id'] = -1;
				}
			}

			if ( $conditions ) {
				$query->where( $conditions );
			}

			// get_results_as_models() resets conditions, so the count has to run on a clone.
			$count_clone   = clone $query;
			$total_records = $count_clone->count();
			$total_pages   = (int) ceil( $total_records / $per_page );

			$showing_from = ( ( $page_number - 1 ) * $per_page ) ? ( ( $page_number - 1 ) * $per_page ) : ( $total_records ? 1 : 0 );
			$showing_to   = min( $page_number * $per_page, $total_records );

			$entries = $query->order_by( 'created_at desc, id desc' )->set_limit( $per_page )->set_offset( $offset )->get_results_as_models();
			$entries = $entries ? ( is_array( $entries ) ? $entries : [ $entries ] ) : [];

			$events = ( new OsEventModel() )->order_by( 'start_datetime_utc asc' )->get_results_as_models();
			$events = $events ? ( is_array( $events ) ? $events : [ $events ] ) : [];

			// Batch-load the relations so the page costs one query instead of one per row.
			$events_by_id = [];
			foreach ( $events as $event_option ) {
				$events_by_id[ (int) $event_option->id ] = $event_option;
			}

			$customer_ids = [];
			foreach ( $entries as $entry ) {
				$entry_customer_id = (int) $entry->customer_id;
				if ( $entry_customer_id ) {
					$customer_ids[ $entry_customer_id ] = $entry_customer_id;
				}
			}

			$customers_by_id = [];
			if ( $customer_ids ) {
				$loaded_customers = ( new OsCustomerModel() )->where_in( 'id', array_values( $customer_ids ) )->get_results_as_models();
				foreach ( ( is_array( $loaded_customers ) ? $loaded_customers : [ $loaded_customers ] ) as $loaded_customer ) {
					if ( $loaded_customer && $loaded_customer->id ) {
						$customers_by_id[ (int) $loaded_customer->id ] = $loaded_customer;
					}
				}
			}

			$this->vars['entries']             = $entries;
			$this->vars['events']              = $events;
			$this->vars['events_by_id']        = $events_by_id;
			$this->vars['customers_by_id']     = $customers_by_id;
			$this->vars['total_records']       = $total_records;
			$this->vars['total_pages']         = $total_pages;
			$this->vars['current_page_number'] = $page_number;
			$this->vars['showing_from']        = $showing_from;
			$this->vars['showing_to']          = $showing_to;
			$this->vars['total_waiting']       = $this->count_live_entries( $conditions['event_id'] ?? 0 );
			$this->vars['status_filter']       = $conditions['status'] ?? '';
			$this->vars['event_filter']        = $conditions['event_id'] ?? '';
			$this->vars['ticket_type_filter']  = $conditions['ticket_type_id'] ?? '';
			// Only once an event is picked. All statuses: a disabled type can still have people queuing.
			$this->vars['ticket_types']   = ( ! empty( $conditions['event_id'] ) && class_exists( 'OsFeatureEventTicketTypesHelper' ) )
				? OsFeatureEventTicketTypesHelper::get_types_for_event( (int) $conditions['event_id'] )
				: [];
			$this->vars['customer_query'] = $customer_query;
			$this->vars['email_query']    = $email_query;

			// Same split core uses for its own tables: the JSON path returns only the tbody so
			// latepoint_filter_table() can swap it in place.
			$this->format_render(
				[
					'json_view_name' => '_table_body',
					'html_view_name' => __FUNCTION__,
				],
				[],
				[
					'total_pages'   => $total_pages,
					'showing_from'  => $showing_from,
					'showing_to'    => $showing_to,
					'total_records' => $total_records,
				]
			);
		}

		/**
		 * Offers the place to a queued customer and emails them a claim link. Used for paid
		 * events, where the customer has to go through checkout themselves.
		 */
		public function invite() {
			$entry = $this->load_entry_for_write( 'invite_event_waiting_list_' );
			if ( ! $entry ) {
				return;
			}

			$result = OsFeatureEventWaitingListHelper::invite( $entry );
			$this->respond_to_write( $result, __( 'Invitation sent.', 'latepoint-pro-features' ) );
		}

		/**
		 * Gives the place directly. Free events only: a paid event has to go through checkout.
		 */
		public function promote() {
			$entry = $this->load_entry_for_write( 'promote_event_waiting_list_' );
			if ( ! $entry ) {
				return;
			}

			$result = OsFeatureEventWaitingListHelper::promote( $entry );
			$this->respond_to_write( $result, __( 'A place has been given and the customer is now registered.', 'latepoint-pro-features' ) );
		}

		/**
		 * Takes somebody off the queue. Deliberately its own action rather than core's
		 * registration cancel route, which would fire latepoint_event_registration_cancelled and
		 * email a cancellation notice for a registration that never existed.
		 */
		public function remove() {
			$entry = $this->load_entry_for_write( 'remove_event_waiting_list_' );
			if ( ! $entry ) {
				return;
			}

			$result = OsFeatureEventWaitingListHelper::remove( $entry );
			$this->respond_to_write( $result, __( 'Removed from the waiting list.', 'latepoint-pro-features' ) );
		}

		/**
		 * How many people are actually still queuing, across the whole table or one event.
		 * Deliberately a live-status count, not a row count: terminal rows are history.
		 */
		private function count_live_entries( int $event_id = 0 ): int {
			global $wpdb;
			$statuses     = OsEventWaitingListModel::live_statuses();
			$placeholders = implode( ',', array_fill( 0, count( $statuses ), '%s' ) );
			$sql          = 'SELECT COUNT(*) FROM ' . LATEPOINT_TABLE_EVENT_WAITING_LIST . ' WHERE status IN (' . $placeholders . ')';
			$args         = $statuses;
			if ( $event_id ) {
				$sql   .= ' AND event_id = %d';
				$args[] = $event_id;
			}

			return (int) $wpdb->get_var( $wpdb->prepare( $sql, $args ) );
		}

		// ─── Internals ──────────────────────────────────────────────────────

		/**
		 * Shared front door for the three write actions: record-scoped nonce, then load. Kept
		 * private so it can never be reached as a route of its own, because every public method on a
		 * controller is a routable action.
		 *
		 * @return OsEventWaitingListModel|null
		 */
		private function load_entry_for_write( string $nonce_prefix ): ?OsEventWaitingListModel {
			$id = absint( $this->params['id'] ?? 0 );
			$this->check_nonce( $nonce_prefix . $id );

			$entry = $id ? new OsEventWaitingListModel( $id ) : null;
			if ( ! $entry || ! $entry->id ) {
				$this->send_json(
					[
						'status'  => LATEPOINT_STATUS_ERROR,
						'message' => __( 'Waiting list entry not found.', 'latepoint-pro-features' ),
					]
				);

				return null;
			}

			return $entry;
		}

		private function respond_to_write( $result, string $success_message ): void {
			if ( is_wp_error( $result ) ) {
				$this->send_json(
					[
						'status'  => LATEPOINT_STATUS_ERROR,
						'message' => $result->get_error_message(),
					]
				);

				return;
			}

			$this->send_json(
				[
					'status'      => LATEPOINT_STATUS_SUCCESS,
					'message'     => $success_message,
					'reload_page' => true,
				]
			);
		}
	}

endif;
