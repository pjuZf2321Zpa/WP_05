<?php
/*
 * Copyright (c) 2024 LatePoint LLC. All rights reserved.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * LatePoint -> Settings -> API. Mirrors OsWhiteLabelController's shape.
 *
 * The 4 existing master/write/delete/public-availability toggles are saved via the generic
 * settings__update action (OsSettingsController::update(), free plugin) — same option keys
 * as before this page existed, just rendered from here now. The API-key actions
 * (new_key_modal/generate_key/revoke_key/update_key_permissions) are custom to this
 * controller, since those aren't plain settings[name]=value fields. new_key_modal() just
 * renders the "Generate New Key" form inside a lightbox (opened via data-os-action +
 * data-os-output-target="lightbox" on the trigger button in settings.php); generate_key()
 * is the actual mutation, submitted from inside that lightbox.
 *
 */
if ( ! class_exists( 'OsApiSettingsController' ) ) :

	class OsApiSettingsController extends OsSettingsController {

		public function __construct() {
			parent::__construct();

			$this->views_folder          = plugin_dir_path( __FILE__ ) . '../views/api_settings/';
			$this->vars['breadcrumbs'][] = [
				'label' => __( 'API', 'latepoint-pro-features' ),
				'link'  => OsRouterHelper::build_link( [ 'api_settings', 'settings' ] ),
			];
		}

		public function settings() {
			// hashed_key never needs to leave this controller — strip it here rather than at
			// OsApiKeysHelper::get_keys() itself, since every other caller of get_keys()
			// (create_key/revoke_key/update_key_permission) read-modify-writes the full
			// records back via save_keys(), and stripping at the source would wipe every
			// stored hash on the next save.
			$this->vars['keys'] = array_map(
				static function ( $key ) {
					unset( $key['hashed_key'] );
					return $key;
				},
				OsApiKeysHelper::get_keys()
			);

			$this->format_render( __FUNCTION__ );
		}

		/**
		 * Renders the "Generate New Key" form inside a lightbox — opened via
		 * data-os-action + data-os-output-target="lightbox" (see settings.php), the same
		 * declarative pattern used by e.g. OsCustomersController::import_csv_modal(). No
		 * nonce/capability check here: this only renders a form, the actual mutation is
		 * still gated in generate_key() below.
		 */
		public function new_key_modal() {
			$this->format_render( __FUNCTION__ );
		}

		/**
		 * Only admins may create a key. A key always authenticates as the admin who
		 * generated it — not a choice made in the form — so it carries full admin-level
		 * access to every resource, scoped down only by its own read/write/delete toggles.
		 * There's no way to bind a key to a lower-privileged account.
		 */
		public function generate_key() {
			if ( ! current_user_can( 'manage_options' ) ) {
				$this->send_json(
					[
						'status'  => LATEPOINT_STATUS_ERROR,
						'message' => __( 'Only administrators can generate API keys.', 'latepoint-pro-features' ),
					]
				);
				return;
			}

			$this->check_nonce( 'update_settings' );

			$label = sanitize_text_field( $this->params['label'] ?? '' );

			if ( empty( $label ) ) {
				$this->send_json(
					[
						'status'  => LATEPOINT_STATUS_ERROR,
						'message' => __( 'A label is required.', 'latepoint-pro-features' ),
					]
				);
				return;
			}

			$result = OsApiKeysHelper::create_key(
				$label,
				get_current_user_id(),
				! empty( $this->params['can_read'] ),
				! empty( $this->params['can_write'] ),
				! empty( $this->params['can_delete'] )
			);

			$this->send_json(
				[
					'status'  => LATEPOINT_STATUS_SUCCESS,
					'key'     => $result['raw_key'],
					'message' => __( 'Copy this key now — it will not be shown again.', 'latepoint-pro-features' ),
				]
			);
		}

		/**
		 * Renders the "Edit API Key" form inside a lightbox — opened via data-os-action +
		 * data-os-output-target="lightbox" on each row's pencil icon (see settings.php).
		 * Unlike new_key_modal(), this reflects stored key state back to the caller, so it
		 * carries its own capability check instead of relying solely on update_key().
		 */
		public function edit_key_modal() {
			if ( ! current_user_can( 'manage_options' ) ) {
				$this->send_json(
					[
						'status'  => LATEPOINT_STATUS_ERROR,
						'message' => __( 'Only administrators can edit API keys.', 'latepoint-pro-features' ),
					]
				);
				return;
			}

			$id = sanitize_text_field( $this->params['id'] ?? '' );

			$key = null;
			foreach ( OsApiKeysHelper::get_keys() as $candidate ) {
				if ( $candidate['id'] === $id && empty( $candidate['revoked_at'] ) ) {
					$key = $candidate;
					break;
				}
			}

			if ( ! $key ) {
				$this->send_json(
					[
						'status'  => LATEPOINT_STATUS_ERROR,
						'message' => __( 'Key not found or already revoked.', 'latepoint-pro-features' ),
					]
				);
				return;
			}

			unset( $key['hashed_key'] );
			$this->vars['key'] = $key;

			$this->format_render( __FUNCTION__ );
		}

		public function revoke_key() {
			if ( ! current_user_can( 'manage_options' ) ) {
				$this->send_json(
					[
						'status'  => LATEPOINT_STATUS_ERROR,
						'message' => __( 'Only administrators can revoke API keys.', 'latepoint-pro-features' ),
					]
				);
				return;
			}

			$this->check_nonce( 'update_settings' );

			$id = sanitize_text_field( $this->params['id'] ?? '' );

			if ( OsApiKeysHelper::revoke_key( $id ) ) {
				$this->send_json(
					[
						'status'  => LATEPOINT_STATUS_SUCCESS,
						'message' => __( 'API key revoked.', 'latepoint-pro-features' ),
					]
				);
			} else {
				$this->send_json(
					[
						'status'  => LATEPOINT_STATUS_ERROR,
						'message' => __( 'Key not found or already revoked.', 'latepoint-pro-features' ),
					]
				);
			}
		}

		/**
		 * Edits an existing custom key's label and read/write/delete toggles together,
		 * submitted from edit_key_modal.php.
		 */
		public function update_key() {
			if ( ! current_user_can( 'manage_options' ) ) {
				$this->send_json(
					[
						'status'  => LATEPOINT_STATUS_ERROR,
						'message' => __( 'Only administrators can edit API keys.', 'latepoint-pro-features' ),
					]
				);
				return;
			}

			$this->check_nonce( 'update_settings' );

			$type  = sanitize_text_field( $this->params['type'] ?? '' );
			$id    = sanitize_text_field( $this->params['id'] ?? '' );
			$label = sanitize_text_field( $this->params['label'] ?? '' );

			if ( empty( $label ) ) {
				$this->send_json(
					[
						'status'  => LATEPOINT_STATUS_ERROR,
						'message' => __( 'A label is required.', 'latepoint-pro-features' ),
					]
				);
				return;
			}

			// Submitted via the checkbox fields rendered in edit_key_modal.php — their name
			// embeds $id (key_perm_read_<id>, etc.) so each key's three fields stay
			// DOM-unique; value is the string 'on'/'off', not a boolean/'1'.
			$can_read   = 'on' === ( $this->params[ 'key_perm_read_' . $id ] ?? '' );
			$can_write  = 'on' === ( $this->params[ 'key_perm_write_' . $id ] ?? '' );
			$can_delete = 'on' === ( $this->params[ 'key_perm_delete_' . $id ] ?? '' );

			if ( 'custom' === $type ) {
				$updated = OsApiKeysHelper::update_key( $id, $label, $can_read, $can_write, $can_delete );
			} else {
				$updated = false;
			}

			if ( $updated ) {
				$this->send_json(
					[
						'status'  => LATEPOINT_STATUS_SUCCESS,
						'message' => __( 'Key updated.', 'latepoint-pro-features' ),
					]
				);
			} else {
				$this->send_json(
					[
						'status'  => LATEPOINT_STATUS_ERROR,
						'message' => __( 'Credential not found.', 'latepoint-pro-features' ),
					]
				);
			}
		}
	}

endif;
