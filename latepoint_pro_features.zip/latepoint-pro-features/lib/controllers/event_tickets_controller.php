<?php
/*
 * Copyright (c) 2024 LatePoint LLC. All rights reserved.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'OsEventTicketsController' ) ) :

	class OsEventTicketsController extends OsController {

		public function __construct() {
			parent::__construct();

			$this->views_folder            = LATEPOINT_ADDON_PRO_VIEWS_ABSPATH . 'event_tickets/';
			$this->vars['page_header']     = OsMenuHelper::get_menu_items_by_id( 'events' );
			$this->vars['pre_page_header'] = OsMenuHelper::get_label_by_id( 'events' );
			$this->vars['breadcrumbs'][]   = [
				'label' => __( 'Check-In', 'latepoint-pro-features' ),
				'link'  => OsRouterHelper::build_link( OsRouterHelper::build_route_name( 'event_tickets', 'scanner' ) ),
			];

			// The QR is a plain phone-camera-readable URL, and the ticket page itself is the
			// credential check (opaque, random ticket_code) — see OsFeatureEventTicketsHelper.
			$this->action_access['public'] = array_merge(
				$this->action_access['public'],
				[
					'show',
					'qr_image',
					'download_pdf',
				]
			);
		}

		// ─── Admin: scanner page ────────────────────────────────────────────

		public function scanner() {
			$this->vars['events'] = ( new OsEventModel() )->order_by( 'start_datetime_utc desc' )->get_results_as_models();

			$selected_event_id               = isset( $this->params['event_id'] ) ? absint( $this->params['event_id'] ) : 0;
			$this->vars['selected_event_id'] = $selected_event_id;
			$this->vars['tickets']           = $selected_event_id ? OsFeatureEventTicketsHelper::get_tickets_for_event( $selected_event_id ) : [];

			$this->format_render( __FUNCTION__ );
		}

		public function tickets_for_event() {
			$event_id = isset( $this->params['event_id'] ) ? absint( $this->params['event_id'] ) : 0;
			$search   = isset( $this->params['search'] ) ? sanitize_text_field( $this->params['search'] ) : '';

			$this->vars['tickets'] = $event_id ? OsFeatureEventTicketsHelper::get_tickets_for_event( $event_id, $search ) : [];

			$this->format_render(
				[
					'json_view_name' => '_tickets_table_body',
					'html_view_name' => '_tickets_table_body',
				]
			);
		}

		public function validate() {
			if ( $this->events_ticket_scanning_disabled() ) {
				return;
			}
			$this->check_nonce( 'event_tickets_scan' );

			$code = isset( $this->params['code'] ) ? sanitize_text_field( $this->params['code'] ) : '';
			if ( empty( $code ) ) {
				$this->send_json(
					[
						'status'  => LATEPOINT_STATUS_ERROR,
						'message' => __( 'No code provided', 'latepoint-pro-features' ),
					]
				);
				return;
			}

			$verdict = OsFeatureEventTicketsHelper::validate_scan( $code );
			$this->send_json(
				[
					'status'  => 'valid' === $verdict['verdict'] || 'group_partially_scanned' === $verdict['verdict'] ? LATEPOINT_STATUS_SUCCESS : LATEPOINT_STATUS_ERROR,
					'message' => $verdict['message'],
					'verdict' => $verdict,
				]
			);
		}

		public function check_in() {
			if ( $this->events_ticket_scanning_disabled() ) {
				return;
			}
			if ( empty( $this->params['id'] ) || ! filter_var( $this->params['id'], FILTER_VALIDATE_INT ) ) {
				$this->send_json(
					[
						'status'  => LATEPOINT_STATUS_ERROR,
						'message' => __( 'Invalid Ticket ID', 'latepoint-pro-features' ),
					]
				);
				return;
			}

			$this->check_nonce( 'check_in_event_ticket_' . $this->params['id'] );

			$verdict = OsFeatureEventTicketsHelper::check_in_ticket_by_id( (int) $this->params['id'] );
			$this->send_json(
				[
					'status'  => 'valid' === $verdict['verdict'] || 'group_partially_scanned' === $verdict['verdict'] ? LATEPOINT_STATUS_SUCCESS : LATEPOINT_STATUS_ERROR,
					'message' => $verdict['message'],
					'verdict' => $verdict,
				]
			);
		}

		/**
		 * The scanner page notice stops someone from seeing the scanner, but validate()/check_in()
		 * are directly reachable by route name regardless of what any page shows — gate the actual
		 * mutation too, same defense-in-depth Free's own mutating actions already apply.
		 */
		private function events_ticket_scanning_disabled(): bool {
			if ( ! OsSettingsHelper::is_on( 'enable_events_functionality' ) || ! OsFeatureEventTicketsHelper::is_enabled() ) {
				$this->send_json(
					[
						'status'  => LATEPOINT_STATUS_ERROR,
						'message' => __( 'Event E-Tickets are currently disabled.', 'latepoint-pro-features' ),
					]
				);
				return true;
			}
			return false;
		}

		// ─── Public: ticket page / QR image / PDF ──────────────────────────

		public function show() {
			$code   = isset( $this->params['code'] ) ? sanitize_text_field( $this->params['code'] ) : '';
			$ticket = OsFeatureEventTicketsHelper::get_ticket_by_code( $code );

			$this->vars['ticket']     = $ticket;
			$this->vars['is_staff']   = OsAuthHelper::get_current_user()->has_backend_access();
			$this->vars['page_title'] = __( 'Event Ticket', 'latepoint-pro-features' );

			$this->set_layout( 'clean' );
			$this->format_render( 'show' );
		}

		public function qr_image() {
			$code   = isset( $this->params['code'] ) ? sanitize_text_field( $this->params['code'] ) : '';
			$ticket = OsFeatureEventTicketsHelper::get_ticket_by_code( $code );

			header( 'Content-Type: image/png' );
			header( 'Cache-Control: private, no-store' );

			if ( ! $ticket ) {
				// 1x1 transparent PNG — keeps broken-image icons out of already-sent emails for voided/unknown codes.
				echo base64_decode( 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=' );
				return;
			}

			echo OsEventTicketQrHelper::render_png( $ticket->ticket_code );
		}

		public function download_pdf() {
			$code   = isset( $this->params['code'] ) ? sanitize_text_field( $this->params['code'] ) : '';
			$ticket = OsFeatureEventTicketsHelper::get_ticket_by_code( $code );

			if ( ! $ticket ) {
				wp_die( esc_html__( 'Ticket not found', 'latepoint-pro-features' ) );
			}

			$pdf_content = OsEventTicketQrHelper::build_ticket_pdf( $ticket );

			header( 'Content-Type: application/pdf' );
			header( 'Content-Disposition: inline; filename="ticket-' . sanitize_file_name( $ticket->ticket_code ) . '.pdf"' );
			header( 'Cache-Control: private, no-store' );

			echo $pdf_content;
		}
	}

endif;
