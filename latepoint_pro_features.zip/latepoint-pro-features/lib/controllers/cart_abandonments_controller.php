<?php
/*
 * Copyright (c) 2026 LatePoint LLC. All rights reserved.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! class_exists( 'OsCartAbandonmentsController' ) ) :

	class OsCartAbandonmentsController extends OsController {

		public function __construct() {
			parent::__construct();

			$this->action_access['public'] = array_merge( $this->action_access['public'], [ 'continue_cart_abandonment' ] );
		}

		// Mints a real order intent only now, at the moment the visitor actually clicks through -
		// not when the snapshot was captured - then hands off entirely to the existing, unmodified
		// order-intent resume flow. Possession of the opaque abandonment_key is the only auth, same
		// as OsOrdersController::continue_order_intent()'s intent_key.
		public function continue_cart_abandonment() {
			$abandonment_key = sanitize_text_field( $this->params['abandonment_key'] ?? '' );
			$abandonment     = ( is_string( $abandonment_key ) && ctype_alnum( $abandonment_key ) )
				? OsFeatureCartAbandonmentHelper::get_abandonment_by_key( $abandonment_key )
				: new OsCartAbandonmentModel();

			if ( $abandonment->is_new_record() ) {
				http_response_code( 400 );
				OsDebugHelper::log( 'Cart abandonment not found, key:' . $abandonment_key );
				exit();
			}

			$cart_items_data = json_decode( $abandonment->cart_items_data, true );
			$cart            = OsCartsHelper::get_or_create_cart( true );
			// Resuming always mints a fresh cart (no cart cookie yet in this session) - re-point the
			// original abandonment row onto it so a later re-capture (e.g. logging back in mid-resume)
			// updates this same row instead of orphaning it, and conversion tracking can find it.
			if ( $abandonment->cart_id != $cart->id ) {
				$abandonment->update_attributes( [ 'cart_id' => $cart->id ] );
			}
			$cart->clear();
			foreach ( (array) $cart_items_data as $cart_item_data ) {
				OsCartsHelper::add_item_to_cart( OsCartsHelper::create_cart_item_from_item_data( $cart_item_data ) );
			}

			$order_intent = OsOrderIntentHelper::create_or_update_order_intent(
				$cart,
				[],
				[],
				$abandonment->booking_form_page_url,
				$abandonment->customer_id
			);

			nocache_headers();
			wp_redirect( $order_intent->get_page_url_with_intent(), 302 );
			exit;
		}
	}

endif;
