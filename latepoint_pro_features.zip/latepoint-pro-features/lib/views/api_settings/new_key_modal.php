<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<form class="latepoint-lightbox-wrapper-form generate-key-form">
	<?php wp_nonce_field( 'update_settings' ); ?>
	<div class="latepoint-lightbox-heading">
		<h2><?php esc_html_e( 'Generate New Key', 'latepoint-pro-features' ); ?></h2>
	</div>
	<div class="latepoint-lightbox-content">
		<div class="os-row os-mb-3">
			<div class="os-col-lg-12">
				<label for="latepointNewKeyLabel" style="display:block; margin-bottom:6px;"><?php esc_html_e( 'Label', 'latepoint-pro-features' ); ?></label>
				<input type="text" id="latepointNewKeyLabel" class="os-form-control" placeholder="<?php esc_attr_e( 'e.g. "Zapier integration"', 'latepoint-pro-features' ); ?>">
			</div>
		</div>
		<div class="os-row">
			<div class="os-col-lg-12">
				<label style="display:block; margin-bottom:6px;"><?php esc_html_e( 'Permissions', 'latepoint-pro-features' ); ?></label>
				<div style="display:flex; gap:20px; align-items:flex-start;">
					<?php
					echo OsFormHelper::checkbox_field( 'new_key_can_read', __( 'Read', 'latepoint-pro-features' ), 'on', true );
					echo OsFormHelper::checkbox_field( 'new_key_can_write', __( 'Write', 'latepoint-pro-features' ), 'on', false );
					echo OsFormHelper::checkbox_field( 'new_key_can_delete', __( 'Delete', 'latepoint-pro-features' ), 'on', false );
					?>
				</div>
			</div>
		</div>
	</div>
	<div class="latepoint-lightbox-footer">
		<button type="submit" class="latepoint-btn"><?php esc_html_e( 'Generate Key', 'latepoint-pro-features' ); ?></button>
	</div>
</form>
