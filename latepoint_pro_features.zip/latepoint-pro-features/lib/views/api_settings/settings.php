<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<style>
/*
 * De-scoped copies of latepoint/lib/assets/stylesheets/admin/_settings.scss's
 * .latepoint-mcp-connect .latepoint-api-code-w/.latepoint-api-code/.latepoint-api-copy-btn
 * rules -- that CSS only applies inside the MCP "Connect Your AI Client" widget, but this
 * page uses the same code-box + copy-button markup for the API endpoint and the generated
 * key reveal. Kept local to this page rather than de-scoping the free plugin's shared CSS.
 */
.latepoint-api-code-w {
	position: relative;
	margin: 8px 0 16px;
}
.latepoint-api-code {
	margin: 0;
	padding: 16px 48px 16px 16px;
	border-radius: 8px;
	background: #f6f7f9;
	border: 1px solid #e6e8ec;
	overflow-x: auto;
	font-family: 'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace;
	font-size: 13px;
	line-height: 1.6;
	color: #4f5460;
	white-space: pre;
	tab-size: 2;
}
.latepoint-api-copy-btn {
	position: absolute;
	top: 8px;
	right: 8px;
	display: inline-flex;
	align-items: center;
	gap: 4px;
	padding: 6px 8px;
	border: 1px solid #e6e8ec;
	border-radius: 6px;
	background: #ffffff;
	color: #6b7280;
	cursor: pointer;
	line-height: 1;
}
.latepoint-api-copy-btn:hover {
	color: #2c3038;
	border-color: #c9cdd6;
}
.latepoint-api-copy-btn .latepoint-icon {
	font-size: 14px;
}
.latepoint-api-copy-btn .latepoint-api-copied-label {
	display: none;
	font-size: 12px;
}
.latepoint-api-copy-btn.is-copied {
	color: #1a9d5a;
	border-color: #1a9d5a;
}
.latepoint-api-copy-btn.is-copied .latepoint-icon {
	display: none;
}
.latepoint-api-copy-btn.is-copied .latepoint-api-copied-label {
	display: inline;
}
</style>
<form action="" data-os-action="<?php echo esc_attr( OsRouterHelper::build_route_name( 'settings', 'update' ) ); ?>">
<div class="latepoint-page-with-side-nav">
<div class="latepoint-settings-w os-form-w">
	<?php wp_nonce_field( 'update_settings' ); ?>

	<!-- ======================= MASTER TOGGLE ======================= -->
	<div class="white-box section-anchor" id="stickySectionApiToggle">
		<div class="white-box-header">
			<div class="os-form-sub-header">
				<h3><?php esc_html_e( 'API', 'latepoint-pro-features' ); ?></h3>
			</div>
		</div>
		<div class="white-box-content no-padding">
			<div class="sub-section-row">
				<div class="sub-section-label">
					<h3><?php esc_html_e( 'Enable REST API', 'latepoint-pro-features' ); ?></h3>
				</div>
				<div class="sub-section-content">
					<?php
					echo OsFormHelper::toggler_field(
						'settings[latepoint_rest_api]',
						__( 'Enable REST API', 'latepoint-pro-features' ),
						OsSettingsHelper::is_on( 'latepoint_rest_api' ),
						'restApiPermissionsToggle',
						false,
						[ 'sub_label' => __( 'Registers the LatePoint REST API endpoints. This is independent from the AI Abilities/MCP settings — you can enable one without the other.', 'latepoint-pro-features' ) ]
					);
					?>
				</div>
			</div>
			<div id="restApiPermissionsToggle" style="border-top: 1px solid rgb(220, 218, 215); <?php echo OsSettingsHelper::is_on( 'latepoint_rest_api' ) ? '' : 'display: none;'; ?>">
				<div class="sub-section-row">
					<div class="sub-section-label">
						<h3><?php esc_html_e( 'Allow Public Availability Checks', 'latepoint-pro-features' ); ?></h3>
					</div>
					<div class="sub-section-content">
						<?php
						echo OsFormHelper::toggler_field(
							'settings[latepoint_rest_api_public_availability]',
							__( 'Allow Public Availability Checks', 'latepoint-pro-features' ),
							OsSettingsHelper::is_on( 'latepoint_rest_api_public_availability' ),
							false,
							false,
							[ 'sub_label' => __( 'When enabled, the availability endpoints can be called without authentication — the same information your public booking page already shows to visitors.', 'latepoint-pro-features' ) ]
						);
						?>
					</div>
				</div>
				<div class="sub-section-row">
					<div class="sub-section-label">
						<h3><?php esc_html_e( 'API Endpoint', 'latepoint-pro-features' ); ?></h3>
					</div>
					<div class="sub-section-content">
						<?php $rest_api_endpoint = rest_url( 'latepoint/v1' ); ?>
						<div class="latepoint-api-code-w">
							<pre class="latepoint-api-code"><?php echo esc_html( $rest_api_endpoint ); ?></pre>
							<button type="button" class="latepoint-api-copy-btn" aria-label="<?php esc_attr_e( 'Copy to clipboard', 'latepoint-pro-features' ); ?>"><i class="latepoint-icon latepoint-icon-copy"></i><span class="latepoint-api-copied-label"><?php esc_html_e( 'Copied', 'latepoint-pro-features' ); ?></span></button>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- ======================= API KEYS ======================= -->
	<div class="white-box section-anchor" id="stickySectionApiKeys">
		<div class="white-box-header">
			<div class="os-form-sub-header">
				<h3><?php esc_html_e( 'API Keys', 'latepoint-pro-features' ); ?></h3>
			</div>
		</div>
		<div class="white-box-content no-padding">

			<div class="sub-section-row">
				<div class="sub-section-label">
					<h3><?php esc_html_e( 'Generate New Key', 'latepoint-pro-features' ); ?></h3>
				</div>
				<div class="sub-section-content">
					<a href="#"
					   data-os-action="<?php echo esc_attr( OsRouterHelper::build_route_name( 'api_settings', 'new_key_modal' ) ); ?>"
					   data-os-output-target="lightbox"
					   data-os-lightbox-classes="width-500"
					   data-os-after-call="latepoint_init_generate_key_modal"
					   class="latepoint-btn"><?php esc_html_e( 'Generate New Key', 'latepoint-pro-features' ); ?></a>
				</div>
			</div>

			<div class="sub-section-row">
				<div class="sub-section-label">
					<h3><?php esc_html_e( 'Existing Keys', 'latepoint-pro-features' ); ?></h3>
				</div>
				<div class="sub-section-content">
					<?php if ( empty( $keys ) ) : ?>
						<p><?php esc_html_e( 'No API keys yet.', 'latepoint-pro-features' ); ?></p>
					<?php else : ?>
						<div class="os-scrollable-table-w">
						<div class="os-table-w os-table-compact">
						<table class="os-table os-scrollable-table">
							<thead>
								<tr>
									<th><?php esc_html_e( 'Type', 'latepoint-pro-features' ); ?></th>
									<th><?php esc_html_e( 'Label', 'latepoint-pro-features' ); ?></th>
									<th><?php esc_html_e( 'Read', 'latepoint-pro-features' ); ?></th>
									<th><?php esc_html_e( 'Write', 'latepoint-pro-features' ); ?></th>
									<th><?php esc_html_e( 'Delete', 'latepoint-pro-features' ); ?></th>
									<th><?php esc_html_e( 'Last Used', 'latepoint-pro-features' ); ?></th>
									<th><?php esc_html_e( 'Status', 'latepoint-pro-features' ); ?></th>
									<th></th>
								</tr>
							</thead>
							<tbody>
								<?php foreach ( $keys as $key ) : ?>
									<?php $is_revoked = ! empty( $key['revoked_at'] ); ?>
									<tr data-credential-type="custom" data-credential-id="<?php echo esc_attr( $key['id'] ); ?>">
										<td><?php esc_html_e( 'Custom Key', 'latepoint-pro-features' ); ?></td>
										<td><?php echo esc_html( $key['label'] ); ?></td>
										<td>
											<span class="<?php echo $is_revoked ? 'os-column-faded' : ''; ?>"><?php echo ! empty( $key['can_read'] ) ? esc_html__( 'Yes', 'latepoint-pro-features' ) : esc_html__( 'No', 'latepoint-pro-features' ); ?></span>
										</td>
										<td>
											<span class="<?php echo $is_revoked ? 'os-column-faded' : ''; ?>"><?php echo ! empty( $key['can_write'] ) ? esc_html__( 'Yes', 'latepoint-pro-features' ) : esc_html__( 'No', 'latepoint-pro-features' ); ?></span>
										</td>
										<td>
											<span class="<?php echo $is_revoked ? 'os-column-faded' : ''; ?>"><?php echo ! empty( $key['can_delete'] ) ? esc_html__( 'Yes', 'latepoint-pro-features' ) : esc_html__( 'No', 'latepoint-pro-features' ); ?></span>
										</td>
										<td><?php echo esc_html( $key['last_used_at'] ?: __( 'Never', 'latepoint-pro-features' ) ); ?></td>
										<td>
											<?php if ( $is_revoked ) : ?>
												<span class="os-column-status os-column-status-disabled"><?php esc_html_e( 'Revoked', 'latepoint-pro-features' ); ?></span>
											<?php else : ?>
												<span class="os-column-status os-column-status-active"><?php esc_html_e( 'Active', 'latepoint-pro-features' ); ?></span>
											<?php endif; ?>
										</td>
										<td style="white-space: nowrap;">
											<?php if ( ! $is_revoked ) : ?>
												<a href="#"
													title="<?php esc_attr_e( 'Edit Key', 'latepoint-pro-features' ); ?>"
													data-os-action="<?php echo esc_attr( OsRouterHelper::build_route_name( 'api_settings', 'edit_key_modal' ) ); ?>"
													data-os-output-target="lightbox"
													data-os-lightbox-classes="width-500"
													data-os-params="<?php echo esc_attr( 'id=' . rawurlencode( $key['id'] ) ); ?>"
												><i class="latepoint-icon latepoint-icon-edit-3"></i></a>
											<?php endif; ?>
										</td>
									</tr>
								<?php endforeach; ?>
							</tbody>
						</table>
						</div>
						</div>
					<?php endif; ?>
				</div>
			</div>

		</div>
	</div>

	<div class="os-form-buttons">
		<?php echo OsFormHelper::button( 'submit', __( 'Save Settings', 'latepoint-pro-features' ), 'submit', [ 'class' => 'latepoint-btn' ] ); ?>
	</div>

</div>

<div class="latepoint-page-side-nav">
	<div class="side-nav-actions">
		<button type="submit" class="latepoint-btn latepoint-btn-block"><i class="latepoint-icon latepoint-icon-check"></i><span><?php esc_html_e( 'Save Changes', 'latepoint-pro-features' ); ?></span></button>
	</div>
	<div class="side-nav-body">
		<div><a href="#stickySectionApiToggle" class="is-active"><?php esc_html_e( 'Settings', 'latepoint-pro-features' ); ?></a></div>
		<div><a href="#stickySectionApiKeys"><?php esc_html_e( 'API Keys', 'latepoint-pro-features' ); ?></a></div>
	</div>
</div>

</div>
</form>

<script>
/**
 * Bound via data-os-after-call on the "Generate New Key" trigger (settings.php) once the
 * lightbox's form markup (new_key_modal.php) is in the DOM. Submits to the unchanged
 * api_settings__generate_key action, then swaps the lightbox's own content/footer in place
 * to reveal the raw key -- no second server round-trip needed, same pattern as
 * _customers_import.js's "submit then swap .latepoint-lightbox-content" flow.
 */
function latepoint_init_generate_key_modal() {
	var copyLabel        = <?php echo wp_json_encode( __( 'Copy this key now — it will not be shown again:', 'latepoint-pro-features' ) ); ?>;
	var copyToClipboard  = <?php echo wp_json_encode( __( 'Copy to clipboard', 'latepoint-pro-features' ) ); ?>;
	var copiedLabel      = <?php echo wp_json_encode( __( 'Copied', 'latepoint-pro-features' ) ); ?>;
	var doneLabel        = <?php echo wp_json_encode( __( 'Done', 'latepoint-pro-features' ) ); ?>;
	var genericErrorMsg  = <?php echo wp_json_encode( __( 'Something went wrong.', 'latepoint-pro-features' ) ); ?>;

	jQuery( 'body' ).off( 'submit', '.generate-key-form' ).on( 'submit', '.generate-key-form', function ( e ) {
		e.preventDefault();
		var $form = jQuery( this );
		if ( $form.hasClass( 'os-loading' ) ) {
			return false;
		}
		$form.addClass( 'os-loading' );

		var innerParams = new URLSearchParams();
		innerParams.append( '_wpnonce', $form.find( 'input[name="_wpnonce"]' ).val() );
		innerParams.append( 'label', $form.find( '#latepointNewKeyLabel' ).val() );
		innerParams.append( 'can_read', $form.find( '#new_key_can_read' ).prop( 'checked' ) ? '1' : '' );
		innerParams.append( 'can_write', $form.find( '#new_key_can_write' ).prop( 'checked' ) ? '1' : '' );
		innerParams.append( 'can_delete', $form.find( '#new_key_can_delete' ).prop( 'checked' ) ? '1' : '' );

		var body = new FormData();
		body.append( 'action', 'latepoint_route_call' );
		body.append( 'route_name', 'api_settings__generate_key' );
		body.append( 'return_format', 'json' );
		body.append( 'params', innerParams.toString() );

		fetch( ajaxurl, { method: 'POST', body: body, credentials: 'same-origin' } )
			.then( function ( response ) { return response.json(); } )
			.then( function ( data ) {
				$form.removeClass( 'os-loading' );
				if ( data && data.status === 'success' && data.key ) {
					var $content = $form.find( '.latepoint-lightbox-content' );
					$content.empty();
					jQuery( '<p>' ).text( copyLabel ).appendTo( $content );
					var $codeWrap = jQuery( '<div>' ).addClass( 'latepoint-api-code-w' ).appendTo( $content );
					jQuery( '<pre>' ).addClass( 'latepoint-api-code' ).text( data.key ).appendTo( $codeWrap );
					jQuery( '<button>' ).attr( 'type', 'button' ).addClass( 'latepoint-api-copy-btn' ).attr( 'aria-label', copyToClipboard )
						.append( jQuery( '<i>' ).addClass( 'latepoint-icon latepoint-icon-copy' ) )
						.append( jQuery( '<span>' ).addClass( 'latepoint-api-copied-label' ).text( copiedLabel ) )
						.appendTo( $codeWrap );

					$form.find( '.latepoint-lightbox-footer' ).empty().append(
						jQuery( '<button>' ).attr( 'type', 'button' ).addClass( 'latepoint-btn latepoint-generate-key-done-btn' ).text( doneLabel )
					);
				} else {
					alert( ( data && data.message ) ? data.message : genericErrorMsg );
				}
			} )
			.catch( function () {
				$form.removeClass( 'os-loading' );
			} );
	} );

	jQuery( 'body' ).off( 'click', '.latepoint-generate-key-done-btn' ).on( 'click', '.latepoint-generate-key-done-btn', function () {
		location.reload();
	} );
	// Copy-button clicks for the reveal step are handled by the page-wide
	// .latepoint-api-copy-btn delegated handler below -- no modal-specific binding needed.
}

/**
 * Powers every .latepoint-api-code-w / .latepoint-api-copy-btn pair on this page -- the API
 * Endpoint row (static, on page load) and the Generate New Key popup's raw-key reveal
 * (injected later by latepoint_init_generate_key_modal() above). Delegated on body so it
 * covers both regardless of when each one enters the DOM. Mirrors the free plugin's
 * latepoint_init_mcp_client_connect() copy handler (main.js), which only binds inside
 * .latepoint-mcp-connect -- this page's instances live outside that wrapper.
 */
jQuery( 'body' ).on( 'click', '.latepoint-api-copy-btn', function () {
	var $btn = jQuery( this );
	var text = $btn.closest( '.latepoint-api-code-w' ).find( '.latepoint-api-code' ).text();
	if ( text && navigator.clipboard ) {
		navigator.clipboard.writeText( text );
		$btn.addClass( 'is-copied' );
		setTimeout( function () { $btn.removeClass( 'is-copied' ); }, 1200 );
	}
	return false;
} );
</script>
