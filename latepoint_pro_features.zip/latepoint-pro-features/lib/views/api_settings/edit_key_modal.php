<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<form class="latepoint-lightbox-wrapper-form" action="" data-os-success-action="reload"
	data-os-action="<?php echo esc_attr( OsRouterHelper::build_route_name( 'api_settings', 'update_key' ) ); ?>">
	<?php wp_nonce_field( 'update_settings' ); ?>
	<?php echo OsFormHelper::hidden_field( 'type', 'custom', [ 'skip_id' => true ] ); ?>
	<?php echo OsFormHelper::hidden_field( 'id', $key['id'], [ 'skip_id' => true ] ); ?>
	<div class="latepoint-lightbox-heading">
		<h2><?php esc_html_e( 'Edit API Key', 'latepoint-pro-features' ); ?></h2>
	</div>
	<div class="latepoint-lightbox-content">
		<div class="os-row os-mb-3">
			<div class="os-col-lg-12">
				<label for="latepointEditKeyLabel" style="display:block; margin-bottom:6px;"><?php esc_html_e( 'Label', 'latepoint-pro-features' ); ?></label>
				<input type="text" id="latepointEditKeyLabel" name="label" class="os-form-control" value="<?php echo esc_attr( $key['label'] ); ?>" placeholder="<?php esc_attr_e( 'e.g. "Zapier integration"', 'latepoint-pro-features' ); ?>">
			</div>
		</div>
		<div class="os-row">
			<div class="os-col-lg-12">
				<label style="display:block; margin-bottom:6px;"><?php esc_html_e( 'Permissions', 'latepoint-pro-features' ); ?></label>
				<div style="display:flex; gap:20px; align-items:flex-start;">
					<?php
					echo OsFormHelper::checkbox_field( 'key_perm_read_' . $key['id'], __( 'Read', 'latepoint-pro-features' ), 'on', ! empty( $key['can_read'] ) );
					echo OsFormHelper::checkbox_field( 'key_perm_write_' . $key['id'], __( 'Write', 'latepoint-pro-features' ), 'on', ! empty( $key['can_write'] ) );
					echo OsFormHelper::checkbox_field( 'key_perm_delete_' . $key['id'], __( 'Delete', 'latepoint-pro-features' ), 'on', ! empty( $key['can_delete'] ) );
					?>
				</div>
			</div>
		</div>
	</div>
	<div class="latepoint-lightbox-footer" style="display:flex; justify-content:space-between; align-items:center;">
		<a href="#"
			class="latepoint-btn latepoint-btn-link"
			style="color: #7e1010;"
			data-os-action="<?php echo esc_attr( OsRouterHelper::build_route_name( 'api_settings', 'revoke_key' ) ); ?>"
			data-os-prompt="<?php esc_attr_e( 'Revoke this key? Anything using it will stop working immediately.', 'latepoint-pro-features' ); ?>"
			data-os-params="<?php echo esc_attr( 'id=' . rawurlencode( $key['id'] ) . '&_wpnonce=' . wp_create_nonce( 'update_settings' ) ); ?>"
			data-os-success-action="reload"
		><?php esc_html_e( 'Revoke Key', 'latepoint-pro-features' ); ?></a>
		<button type="submit" class="latepoint-btn"><?php esc_html_e( 'Save Changes', 'latepoint-pro-features' ); ?></button>
	</div>
</form>
