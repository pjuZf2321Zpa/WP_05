<div class="os-conversations-wrapper <?php echo $conversations ? '' : 'mobile-show-conversations'; ?>">
	<div class="os-conversations-list-wrapper">
		<h3>
			<div class="latepoint-icon latepoint-icon-message-circle"></div>
			<span><?php _e('Your Conversations', 'latepoint-pro-features'); ?></span>
		</h3>
		<?php $show_archived = !empty($show_archived); ?>
		<div class="os-conversations-tabs">
			<a href="#" class="os-conversations-tab <?php echo $show_archived ? '' : 'is-active'; ?>"
				 data-os-action="<?php echo esc_attr(OsRouterHelper::build_route_name('messages', 'conversations_list')); ?>"
				 data-os-params="<?php echo esc_attr(OsUtilHelper::build_os_params(['show_archived' => 0], 'chat_conversations_list')); ?>"
				 data-show-archived="0"
				 data-os-output-target=".os-conversations-list"
				 data-os-after-call="latepoint_set_conversations_tab"
				 data-os-pass-this="yes"><?php _e('Active', 'latepoint-pro-features'); ?></a>
			<a href="#" class="os-conversations-tab <?php echo $show_archived ? 'is-active' : ''; ?>"
				 data-os-action="<?php echo esc_attr(OsRouterHelper::build_route_name('messages', 'conversations_list')); ?>"
				 data-os-params="<?php echo esc_attr(OsUtilHelper::build_os_params(['show_archived' => 1], 'chat_conversations_list')); ?>"
				 data-show-archived="1"
				 data-os-output-target=".os-conversations-list"
				 data-os-after-call="latepoint_set_conversations_tab"
				 data-os-pass-this="yes"><?php _e('Archived', 'latepoint-pro-features'); ?></a>
		</div>
		<div class="osc-search-wrapper">
			<input class="osc-search-input" data-route="<?php echo esc_attr(OsRouterHelper::build_route_name('messages', 'search_bookings')); ?>" type="text" placeholder="<?php esc_attr_e('Search conversations...', 'latepoint-pro-features'); ?>" />
		</div>
		<div class="os-search-conversations-list" style="display: none;">
		</div>
		<div class="os-conversations-list">
			<?php include_once('conversations.php'); ?>
	  </div>
  </div>
  <div class="os-conversation-content">
  	<?php
	  if($booking){
			include_once(dirname( __FILE__ ).'/messages_with_info_for_booking.php');
	  }else{
			echo '<div class="os-conversations-no-booking"></div>';
	  }
		?>
	</div>
</div>
