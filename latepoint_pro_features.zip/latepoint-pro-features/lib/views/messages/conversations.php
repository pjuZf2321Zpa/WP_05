<?php
// The search renders this too, and does not set these.
$selected_booking_id = isset($selected_booking_id) ? $selected_booking_id : false;
$show_archived = !empty($show_archived);
// Search results get no row actions - those re-render the conversations list, which search hides.
$show_row_actions = !isset($show_row_actions) || $show_row_actions;

if($conversations){
  foreach($conversations as $conversation){
		if(!$conversation['booking']->id) continue;
		$last_message = !empty($conversation['last_message']) ? $conversation['last_message'] : false;
		$is_archived = !empty($conversation['is_archived']);
		$archive_label = $is_archived ? __('Unarchive Conversation', 'latepoint-pro-features') : __('Archive Conversation', 'latepoint-pro-features');
		?>
    <div data-os-after-call="latepoint_init_loaded_coversation"
    			data-os-pass-this="yes"
    			data-booking-id="<?php echo esc_attr($conversation['booking']->id); ?>"
    			data-os-action="<?php echo esc_attr(OsRouterHelper::build_route_name('messages', 'messages_with_info_for_booking')); ?>"
    			data-os-params="<?php echo esc_attr(OsUtilHelper::build_os_params(['selected_booking_id' => $conversation['booking']->id])); ?>"
    			data-os-output-target=".os-conversation-content"
    			class="os-conversation-box <?php echo ($selected_booking_id == $conversation['booking']->id) ? 'is-selected' : ''; ?> <?php echo ($last_message && $last_message->author_type == 'customer' && !$last_message->is_read) ? 'is-new' : 'is-read'; ?>">
      <div class="os-conversation-customer-avatar" style="background-image:url(<?php echo esc_url($conversation['booking']->customer->get_avatar_url());?>)"></div>
      <div class="os-conversation-customer-info">
	      <div class="os-conversation-customer-name"><?php echo esc_html($conversation['booking']->customer->full_name);?></div>
	      <div class="os-conversation-booking-id"><?php echo esc_html(__('ID: ', 'latepoint-pro-features').$conversation['booking']->id);?></div>
	      <div class="os-conversation-last-message"><?php echo ($last_message) ? esc_html($last_message->content) : esc_html__('Start new conversation...', 'latepoint-pro-features');?></div>
      </div>
      <?php if($show_row_actions && $last_message){ ?>
      <div class="os-conversation-actions">
        <a href="#" class="os-conversation-action-btn os-conversation-archive-btn"
           data-os-action="<?php echo esc_attr(OsRouterHelper::build_route_name('messages', 'set_conversation_archived')); ?>"
           data-os-params="<?php echo esc_attr(OsUtilHelper::build_os_params([
                              'booking_id'          => $conversation['booking']->id,
                              'archived'            => $is_archived ? 0 : 1,
                              'show_archived'       => $show_archived ? 1 : 0,
                              'selected_booking_id' => $selected_booking_id ? $selected_booking_id : 0,
                            ], 'set_conversation_archived_'.$conversation['booking']->id)); ?>"
           data-os-output-target=".os-conversations-list"
           title="<?php echo esc_attr($archive_label); ?>"
           aria-label="<?php echo esc_attr($archive_label); ?>"><i class="latepoint-icon latepoint-icon-<?php echo $is_archived ? 'rotate-cw' : 'inbox'; ?>"></i></a>
        <a href="#" class="os-conversation-action-btn os-conversation-delete-btn os-delete-confirm"
           data-os-action="<?php echo esc_attr(OsRouterHelper::build_route_name('messages', 'destroy_conversation')); ?>"
           data-os-params="<?php echo esc_attr(OsUtilHelper::build_os_params([
                              'booking_id'          => $conversation['booking']->id,
                              'show_archived'       => $show_archived ? 1 : 0,
                              'selected_booking_id' => $selected_booking_id ? $selected_booking_id : 0,
                            ], 'destroy_conversation_'.$conversation['booking']->id)); ?>"
           data-os-output-target=".os-conversations-list"
           data-os-confirm-title="<?php esc_attr_e('Delete Conversation', 'latepoint-pro-features'); ?>"
           data-os-prompt="<?php esc_attr_e('This permanently deletes every message in this chat. The appointment itself is not affected. This action cannot be undone.', 'latepoint-pro-features'); ?>"
           title="<?php esc_attr_e('Delete Conversation', 'latepoint-pro-features'); ?>"
           aria-label="<?php esc_attr_e('Delete Conversation', 'latepoint-pro-features'); ?>"><i class="latepoint-icon latepoint-icon-trash-2"></i></a>
      </div>
      <?php } ?>
    </div>
    <?php
  }
}else{
	echo '<div class="no-conversations-found">'.esc_html($show_archived ? __('No archived conversations.', 'latepoint-pro-features') : __('No conversations found.', 'latepoint-pro-features')).'</div>';
}
