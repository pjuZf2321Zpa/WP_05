<?php
/**
 * Waiting list table rows. Rendered on its own for the JSON path, so core's shared
 * latepoint_filter_table() can swap the tbody when a filter or page changes.
 *
 * @var OsEventWaitingListModel[] $entries
 * @var OsEventModel[]                 $events_by_id    Batch-loaded, keyed by id
 * @var OsCustomerModel[]              $customers_by_id Batch-loaded, keyed by id
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$events_by_id    = $events_by_id ?? [];
$customers_by_id = $customers_by_id ?? [];

if ( ! $entries ) {
	?>
	<tr>
		<td colspan="10" class="wl-empty"><?php esc_html_e( 'Nobody is on a waiting list yet.', 'latepoint-pro-features' ); ?></td>
	</tr>
	<?php

	return;
}

foreach ( (array) $entries as $entry ) :
	// From the batch the controller loaded; the fallbacks only fire if this partial is ever
	// rendered without it, and keep the row correct rather than blank.
	$entry_event    = $events_by_id[ (int) $entry->event_id ] ?? $entry->get_event();
	$entry_customer = $customers_by_id[ (int) $entry->customer_id ] ?? $entry->get_customer();
	$position       = OsFeatureEventWaitingListHelper::get_position( $entry );
	// Scoped to the entry's own ticket type: telling the organizer the event has places free is
	// misleading when the places are in a ticket this person is not waiting for.
	$seats_free = $entry_event
		? OsFeatureEventWaitingListHelper::get_available_seats( $entry_event, $entry->ticket_type_id ? (int) $entry->ticket_type_id : null )
		: null;
	// Not $entry_event->is_paid(): a tiered event keeps its own price at 0, so that would offer
	// "Give Place" for a seat that costs money.
	$entry_is_paid = OsFeatureEventWaitingListHelper::is_paid_for_entry( $entry, $entry_event );

	// A veto, not a warning. The same helper backs the server-side refusal, so they cannot disagree.
	$offer_blocked = OsFeatureEventWaitingListHelper::get_offer_block_reason( $entry, $entry_event );
	?>
	<tr>
		<td><?php echo esc_html( (string) $entry->id ); ?></td>
		<td><?php echo esc_html( $entry_event ? $entry_event->name : __( 'n/a', 'latepoint-pro-features' ) ); ?></td>
		<td><?php echo esc_html( $entry_customer ? $entry_customer->full_name : __( 'n/a', 'latepoint-pro-features' ) ); ?></td>
		<td><?php echo esc_html( $entry_customer ? $entry_customer->email : __( 'n/a', 'latepoint-pro-features' ) ); ?></td>
		<td>
			<?php
			$entry_type = $entry->get_ticket_type();
			// Covers both a flat event and a ticket type deleted after somebody queued.
			echo esc_html( $entry_type ? $entry_type->name : __( 'n/a', 'latepoint-pro-features' ) );
			?>
		</td>
		<td><?php echo esc_html( (string) (int) $entry->quantity ); ?></td>
		<td><?php echo $position ? '#' . esc_html( (string) $position ) : esc_html__( 'n/a', 'latepoint-pro-features' ); ?></td>
		<td>
			<span class="wl-status wl-status-<?php echo esc_attr( $entry->status ); ?>"><?php echo esc_html( $entry->get_status_label() ); ?></span>
			<?php if ( $entry->is_invited() && ! $entry->has_live_invite() ) : ?>
				<small class="wl-invite-stale"><?php esc_html_e( 'invitation expired', 'latepoint-pro-features' ); ?></small>
			<?php elseif ( $entry->is_invited() && $entry->invite_expires_at ) : ?>
				<small class="wl-invite-live">
					<?php
					printf(
						/* translators: %s: human readable time difference, e.g. "2 days" */
						esc_html__( 'expires in %s', 'latepoint-pro-features' ),
						esc_html( human_time_diff( strtotime( $entry->invite_expires_at . ' UTC' ), current_time( 'timestamp', true ) ) )
					);
					?>
				</small>
			<?php endif; ?>
		</td>
		<td><small><?php echo esc_html( (string) $entry->created_at ); ?></small></td>
		<td class="wl-actions">
			<?php if ( $entry->is_live() ) : ?>
				<?php if ( $offer_blocked ) : ?>
					<?php // A sentence, so it rides in core's tooltip rather than wrapping inside a cell sized for action links. ?>
					<span class="wl-action-blocked" data-late-tooltip="<?php echo esc_attr( $offer_blocked ); ?>">
						<?php echo $entry_is_paid ? esc_html__( 'Invite', 'latepoint-pro-features' ) : esc_html__( 'Give Place', 'latepoint-pro-features' ); ?>
						<i class="latepoint-icon latepoint-icon-info os-label-tooltip-icon"></i>
					</span>
				<?php else : ?>
					<?php // Same wrapper shape as the blocked span above, so the info icon lands in the same place on every row. ?>
					<span class="wl-action-offer">
						<?php if ( $entry_is_paid ) : ?>
							<a href="#"
							   data-os-action="<?php echo esc_attr( OsRouterHelper::build_route_name( 'event_waiting_list', 'invite' ) ); ?>"
							   data-os-params="<?php echo esc_attr( OsUtilHelper::build_os_params( [ 'id' => $entry->id ], 'invite_event_waiting_list_' . $entry->id ) ); ?>"
							   data-os-success-action="reload"
							   class="wl-action-invite">
								<?php echo $entry->is_invited() ? esc_html__( 'Re-invite', 'latepoint-pro-features' ) : esc_html__( 'Invite', 'latepoint-pro-features' ); ?>
							</a>
						<?php else : ?>
							<a href="#"
							   data-os-prompt="<?php esc_attr_e( 'Give this customer a place at the event?', 'latepoint-pro-features' ); ?>"
							   data-os-action="<?php echo esc_attr( OsRouterHelper::build_route_name( 'event_waiting_list', 'promote' ) ); ?>"
							   data-os-params="<?php echo esc_attr( OsUtilHelper::build_os_params( [ 'id' => $entry->id ], 'promote_event_waiting_list_' . $entry->id ) ); ?>"
							   data-os-success-action="reload"
							   class="wl-action-promote">
								<?php esc_html_e( 'Give Place', 'latepoint-pro-features' ); ?>
							</a>
						<?php endif; ?>
						<?php if ( null !== $seats_free ) : ?>
							<?php
							$seats_free_label = sprintf(
								/* translators: %d: number of places currently free on the event */
								_n( '%d place free', '%d places free', (int) $seats_free, 'latepoint-pro-features' ),
								(int) $seats_free
							);
							?>
							<i class="latepoint-icon latepoint-icon-info os-label-tooltip-icon wl-seats-free" data-late-tooltip="<?php echo esc_attr( $seats_free_label ); ?>"></i>
						<?php endif; ?>
					</span>
				<?php endif; ?>
				<a href="#"
				   data-os-prompt="<?php esc_attr_e( 'Remove this person from the waiting list?', 'latepoint-pro-features' ); ?>"
				   data-os-action="<?php echo esc_attr( OsRouterHelper::build_route_name( 'event_waiting_list', 'remove' ) ); ?>"
				   data-os-params="<?php echo esc_attr( OsUtilHelper::build_os_params( [ 'id' => $entry->id ], 'remove_event_waiting_list_' . $entry->id ) ); ?>"
				   data-os-success-action="reload"
				   class="wl-action-remove">
					<?php esc_html_e( 'Remove', 'latepoint-pro-features' ); ?>
				</a>
			<?php elseif ( $entry->is_converted() && $entry->converted_registration_id ) : ?>
				<span class="wl-converted-note">
					<?php
					printf(
						/* translators: %d: event registration id */
						esc_html__( 'Registration #%d', 'latepoint-pro-features' ),
						(int) $entry->converted_registration_id
					);
					?>
				</span>
			<?php else : ?>
				<span class="wl-no-actions"><?php esc_html_e( 'n/a', 'latepoint-pro-features' ); ?></span>
			<?php endif; ?>
		</td>
	</tr>
	<?php
endforeach;
