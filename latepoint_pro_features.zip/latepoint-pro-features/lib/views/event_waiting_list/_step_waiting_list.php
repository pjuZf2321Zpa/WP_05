<?php
/**
 * Waiting list wizard step.
 *
 * Runs after core's customer step, so identity (guest, login, OTP, password rules) has already
 * been handled by the wizard itself. This step only confirms what is about to happen; the entry is
 * created by OsFeatureEventWaitingListHelper::process_step() when the wizard's own next button is
 * pressed, exactly like every other step.
 *
 * @var OsEventModel|null                  $event
 * @var OsCustomerModel                    $customer
 * @var OsEventWaitingListModel|null  $entry    Their queue entry, when already queued
 * @var string                             $current_step_code
 * @var int                                $position
 * @var int                                $quantity Places chosen on the tickets step
 * @var array                              $chosen_tickets Each: ['type' => OsEventTicketTypeModel, 'quantity' => int, 'position' => int, 'queued' => bool]
 * @var bool                               $all_already_queued Every ticket shown is one they already hold
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<?php // step-event-w is Free's own wrapper for an event wizard step, carried so this step picks up
// the same width and typography as the event and ticket steps before it. ?>
<div class="step-event-waiting-list-w step-event-w latepoint-step-content" data-step-code="<?php echo esc_attr( $current_step_code ); ?>">
	<?php
	do_action( 'latepoint_before_step_content', $current_step_code );
	echo OsStepsHelper::get_formatted_extra_step_content( $current_step_code, 'before' );
	?>

	<?php if ( ! $event || ! $event->id ) : ?>
		<div class="os-error-message">
			<p><?php esc_html_e( 'Event not found. Please go back and try again.', 'latepoint-pro-features' ); ?></p>
		</div>
	<?php else : ?>

		<div class="ewl-step-w">
			<div class="ewl-notice">
				<i class="latepoint-icon latepoint-icon-info"></i>
				<div class="ewl-notice-text">
					<?php if ( $all_already_queued || ( $entry && empty( $chosen_tickets ) ) ) : ?>
						<?php esc_html_e( 'You are already on the waiting list for this event. Continue to see where you stand.', 'latepoint-pro-features' ); ?>
					<?php elseif ( ! empty( $chosen_tickets ) ) : ?>
						<?php // Not "this event is full": only the chosen tickets are, and the step before named them. ?>
						<?php esc_html_e( 'We will contact you if a place becomes available. Joining does not reserve a place and you are not charged anything now.', 'latepoint-pro-features' ); ?>
					<?php else : ?>
						<?php esc_html_e( 'This event is full. Join the waiting list and we will contact you if a place becomes available. Joining does not reserve a place and you are not charged anything now.', 'latepoint-pro-features' ); ?>
					<?php endif; ?>
				</div>
			</div>

			<div class="ewl-summary">
				<div class="ewl-summary-row">
					<span class="ewl-summary-label"><?php esc_html_e( 'Event', 'latepoint-pro-features' ); ?></span>
					<span class="ewl-summary-value"><?php echo esc_html( $event->name ); ?></span>
				</div>
				<?php foreach ( $chosen_tickets as $chosen_ticket ) : ?>
					<div class="ewl-summary-row">
						<?php // Null once a ticket type has been deleted out from under a live entry. ?>
						<span class="ewl-summary-label"><?php echo esc_html( $chosen_ticket['type'] ? $chosen_ticket['type']->name : '' ); ?></span>
						<span class="ewl-summary-value">
							<?php
							if ( ! empty( $chosen_ticket['queued'] ) ) {
								printf(
									/* translators: %1$d: number of places, %2$d: position in that ticket's queue */
									esc_html( _n( 'Already waiting, %1$d place (#%2$d)', 'Already waiting, %1$d places (#%2$d)', (int) $chosen_ticket['quantity'], 'latepoint-pro-features' ) ),
									(int) $chosen_ticket['quantity'],
									(int) $chosen_ticket['position']
								);
							} else {
								printf(
									/* translators: %d: number of places being waited for */
									esc_html( _n( '%d place', '%d places', (int) $chosen_ticket['quantity'], 'latepoint-pro-features' ) ),
									(int) $chosen_ticket['quantity']
								);
							}
							?>
						</span>
					</div>
				<?php endforeach; ?>
				<?php if ( $event->get_formatted_start_date() ) : ?>
					<div class="ewl-summary-row">
						<span class="ewl-summary-label"><?php esc_html_e( 'Date', 'latepoint-pro-features' ); ?></span>
						<span class="ewl-summary-value">
							<?php echo esc_html( $event->get_formatted_start_date() ); ?>
							<?php if ( $event->get_formatted_start_time() ) : ?>
								&middot; <?php echo esc_html( $event->get_formatted_start_time() ); ?>
							<?php endif; ?>
						</span>
					</div>
				<?php endif; ?>
				<?php if ( $customer && $customer->email ) : ?>
					<div class="ewl-summary-row">
						<span class="ewl-summary-label"><?php esc_html_e( 'Contact', 'latepoint-pro-features' ); ?></span>
						<span class="ewl-summary-value"><?php echo esc_html( $customer->email ); ?></span>
					</div>
				<?php endif; ?>
				<?php // A flat event has no ticket rows, so it reports one quantity and one position. ?>
				<?php if ( empty( $chosen_tickets ) ) : ?>
					<?php if ( $quantity > 1 ) : ?>
						<div class="ewl-summary-row">
							<span class="ewl-summary-label"><?php esc_html_e( 'Places requested', 'latepoint-pro-features' ); ?></span>
							<span class="ewl-summary-value"><?php echo esc_html( (string) $quantity ); ?></span>
						</div>
					<?php endif; ?>
					<div class="ewl-summary-row">
						<span class="ewl-summary-label"><?php esc_html_e( 'Your position', 'latepoint-pro-features' ); ?></span>
						<span class="ewl-summary-value ewl-position">#<?php echo esc_html( (string) $position ); ?></span>
					</div>
				<?php endif; ?>
			</div>
		</div>

	<?php endif; ?>

	<?php
	echo OsStepsHelper::get_formatted_extra_step_content( $current_step_code, 'after' );
	do_action( 'latepoint_after_step_content', $current_step_code );
	?>
</div>
