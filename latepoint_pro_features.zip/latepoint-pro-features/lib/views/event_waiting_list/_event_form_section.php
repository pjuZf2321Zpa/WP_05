<?php
/*
 * Copyright (c) 2024 LatePoint LLC. All rights reserved.
 */

/**
 * Inline "Waiting List" section on the event edit form - see
 * OsFeatureEventWaitingListHelper::output_waiting_list_on_event_form(), hooked to
 * `latepoint_event_form_after` after Ticket Types, so the two boxes stack in that order.
 *
 * Fields submit with the rest of the event form and are persisted by
 * OsFeatureEventWaitingListHelper::save_waiting_list_in_event().
 *
 * @var OsEventModel             $event
 * @var bool                     $feature_is_enabled    Whether the waiting list is on site wide
 * @var bool                     $enabled               Whether this event has a queue
 * @var string                   $flat_capacity         Event level queue size, '' when unlimited
 * @var OsEventTicketTypeModel[] $types                 Types that may each have their own queue
 * @var bool                     $by_type_is_on         Whether ticket types own this event's queue
 * @var array                    $capacity_by_type      Queue size keyed by ticket type id
 * @var string                   $capacity_by_type_name Field name prefix for the per type sizes
 * @var bool                     $show_unlimited_notice Whether the event can never fill up
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="white-box section-anchor" id="stickySectionWaitingList">
	<div class="white-box-header">
		<div class="os-form-sub-header"><h3><?php esc_html_e( 'Waiting List', 'latepoint-pro-features' ); ?></h3></div>
	</div>

	<?php if ( ! $feature_is_enabled ) : ?>
		<div class="white-box-content">
			<div class="latepoint-message latepoint-message-subtle">
				<?php
				echo wp_kses(
					sprintf(
						/* translators: %1$s and %2$s are opening and closing anchor tags */
						__( 'The Waiting List is currently disabled. You can enable it in %1$sGeneral Settings%2$s.', 'latepoint-pro-features' ),
						'<a href="' . esc_url( admin_url( 'admin.php?page=latepoint&route_name=settings__general#stickySectionEvents' ) ) . '">',
						'</a>'
					),
					[ 'a' => [ 'href' => [] ] ]
				);
				?>
			</div>
		</div>
	<?php else : ?>
		<div class="white-box-content no-padding">
			<div class="sub-section-row">
				<div class="sub-section-label">
					<h3><?php esc_html_e( 'Queue', 'latepoint-pro-features' ); ?></h3>
				</div>
				<div class="sub-section-content">
					<?php
					echo OsFormHelper::toggler_field(
						'event[waiting_list_enabled]',
						__( 'Enable Waiting List for this event', 'latepoint-pro-features' ),
						$enabled,
						'eventWaitingListSubfields',
						false,
						[ 'sub_label' => __( 'Once the event is full, customers can queue instead of seeing a dead end. You decide who gets a place when someone cancels.', 'latepoint-pro-features' ) ]
					);
					?>
					<div id="eventWaitingListSubfields" <?php echo $enabled ? '' : 'style="display: none;"'; ?>>
						<?php // Both render; the toggle swaps them without a save and each capacity is stored separately. ?>
						<?php if ( $types ) : ?>
							<div id="osEventWaitingListTypeCapacity" <?php echo $by_type_is_on ? '' : 'style="display: none;"'; ?>>
								<div class="os-event-waiting-list-types-w os-mt-1">
									<div class="os-event-waiting-list-type-row os-event-waiting-list-type-row-header">
										<div class="os-event-waiting-list-type-col-name"><?php esc_html_e( 'Ticket Type', 'latepoint-pro-features' ); ?></div>
										<div class="os-event-waiting-list-type-col-spots"><?php esc_html_e( 'Waiting List Capacity', 'latepoint-pro-features' ); ?> <i class="latepoint-icon latepoint-icon-info os-label-tooltip-icon" data-late-tooltip="<?php esc_attr_e( 'Leave blank for an unlimited queue.', 'latepoint-pro-features' ); ?>"></i></div>
									</div>
									<?php foreach ( $types as $type ) : ?>
										<div class="os-event-waiting-list-type-row">
											<div class="os-event-waiting-list-type-col-name"><?php echo esc_html( $type->name ); ?></div>
											<div class="os-event-waiting-list-type-col-spots">
												<?php
												echo OsFormHelper::text_field(
													$capacity_by_type_name . '[' . $type->id . ']',
													false,
													$capacity_by_type[ (int) $type->id ] ?? '',
													[
														'theme'       => 'simple',
														'type'        => 'number',
														'min'         => '0',
														'placeholder' => __( 'e.g. 5', 'latepoint-pro-features' ),
													]
												);
												?>
											</div>
										</div>
									<?php endforeach; ?>
								</div>
								<div class="latepoint-message latepoint-message-subtle os-mt-1">
									<?php esc_html_e( 'Each ticket type keeps its own queue, so somebody shut out of one can wait for it while the others are still on sale. This is separate from the ticket type capacity above.', 'latepoint-pro-features' ); ?>
								</div>
								<div class="latepoint-message latepoint-message-subtle">
									<?php esc_html_e( 'A ticket type you have just added gets its own row here once you save the event.', 'latepoint-pro-features' ); ?>
								</div>
							</div>
						<?php endif; ?>

						<div id="osEventWaitingListFlatCapacity" <?php echo $by_type_is_on ? 'style="display: none;"' : ''; ?>>
							<div class="os-row os-mt-1">
								<div class="os-col-lg-6">
									<?php
									echo OsFormHelper::text_field(
										'event[waiting_list_capacity]',
										__( 'Waiting List Capacity (0 = unlimited)', 'latepoint-pro-features' ),
										$flat_capacity,
										[ 'theme' => 'simple' ]
									);
									?>
								</div>
							</div>
							<div class="latepoint-message latepoint-message-subtle os-mt-1">
								<?php esc_html_e( 'This is separate from the event capacity. An event for 30 people can keep a queue of another 10.', 'latepoint-pro-features' ); ?>
							</div>
						</div>

						<?php if ( $show_unlimited_notice ) : ?>
							<div class="latepoint-message latepoint-message-subtle">
								<?php esc_html_e( 'This event has unlimited capacity, so it can never fill up and the waiting list will never be offered. Set a total capacity above to use it.', 'latepoint-pro-features' ); ?>
							</div>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</div>
	<?php endif; ?>
</div>
