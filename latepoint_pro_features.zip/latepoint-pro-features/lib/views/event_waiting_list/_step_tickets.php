<?php
/**
 * "Which tickets are you waiting for?": the waiting list's stand-in for Free's tickets step.
 *
 * Sits in the same place in the running order and reuses the same per-ticket stepper, so joining a
 * queue looks and behaves like buying: a quantity per ticket, not a single choice. Somebody shut
 * out of two tickets can queue for both in one go. The choice is recorded by
 * OsFeatureEventWaitingListHelper::process_ticket_step() and written after the customer step.
 *
 * @var OsEventModel|null $event
 * @var array             $ticket_rows Each: ['type' => OsEventTicketTypeModel, 'max' => int, 'waiting' => int, 'chosen' => int]
 * @var string            $current_step_code
 * @var string            $tickets_field
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<?php // step-event-w is Free's own wrapper for an event wizard step: it sets nothing itself, and
	// carrying it is what lets the steppers below reuse Free's styling as well as its JS. ?>
<div class="step-event-waiting-list-tickets-w step-event-w latepoint-step-content" data-step-code="<?php echo esc_attr( $current_step_code ); ?>">
	<?php
	do_action( 'latepoint_before_step_content', $current_step_code );
	echo OsStepsHelper::get_formatted_extra_step_content( $current_step_code, 'before' );
	?>

	<?php if ( ! $event || ! $event->id || empty( $ticket_rows ) ) : ?>
		<div class="os-error-message">
			<p><?php esc_html_e( 'There is no waiting list open for this event right now. Please go back and try again.', 'latepoint-pro-features' ); ?></p>
		</div>
	<?php else : ?>

		<div class="ewl-step-w">
			<div class="ewl-notice">
				<i class="latepoint-icon latepoint-icon-info"></i>
				<div class="ewl-notice-text">
					<?php esc_html_e( 'These tickets are sold out. Choose how many places you would like to wait for.', 'latepoint-pro-features' ); ?>
				</div>
			</div>

			<?php // Ticket Types' own selector wrapper: it re-lays Free's hero-sized selector out as a
				// compact row list and pulls the heading back to 18px, so the queue and the sale look
				// the same. Ours only adds what is specific to waiting. ?>
			<div class="os-event-ticket-types-selector-w os-event-waiting-list-tickets-w">
				<?php foreach ( $ticket_rows as $row ) : ?>
					<?php $ticket = $row['type']; ?>
					<div class="event-ticket-selector-w os-event-ticket-type-selector os-event-waiting-list-ticket">
						<div class="event-ticket-selector-label">
							<h4>
								<?php echo esc_html( $ticket->name ); ?>
								<span class="os-event-ticket-type-price"><?php echo esc_html( $ticket->get_formatted_price() ); ?></span>
							</h4>
							<?php if ( $row['waiting'] > 0 ) : ?>
								<div class="event-step-qty-sublabel">
									<?php
									printf(
										/* translators: %d: how many people are already waiting for this ticket */
										esc_html( _n( '%d person waiting', '%d people waiting', (int) $row['waiting'], 'latepoint-pro-features' ) ),
										(int) $row['waiting']
									);
									?>
								</div>
							<?php else : ?>
								<div class="event-step-qty-sublabel"><?php esc_html_e( 'Nobody waiting yet', 'latepoint-pro-features' ); ?></div>
							<?php endif; ?>
						</div>

						<?php // Free's own stepper markup, so its delegated +/- and clamping JS drives this with no script of our own. ?>
						<div class="event-ticket-qty-w"
						     data-min-capacity="0"
						     data-max-capacity="<?php echo esc_attr( (string) $row['max'] ); ?>">
							<div class="event-ticket-qty-btn event-ticket-qty-btn-minus">
								<i class="latepoint-icon latepoint-icon-minus"></i>
							</div>
							<input type="number"
							       min="0"
							       max="<?php echo esc_attr( (string) $row['max'] ); ?>"
							       name="<?php echo esc_attr( $tickets_field ); ?>[<?php echo esc_attr( (string) $ticket->id ); ?>]"
							       class="event-ticket-qty-input"
							       value="<?php echo esc_attr( (string) $row['chosen'] ); ?>"
							       placeholder="<?php esc_attr_e( 'Qty', 'latepoint-pro-features' ); ?>">
							<div class="event-ticket-qty-btn event-ticket-qty-btn-plus">
								<i class="latepoint-icon latepoint-icon-plus"></i>
							</div>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		</div>

	<?php endif; ?>

	<?php
	echo OsStepsHelper::get_formatted_extra_step_content( $current_step_code, 'after' );
	do_action( 'latepoint_after_step_content', $current_step_code );
	?>
</div>
