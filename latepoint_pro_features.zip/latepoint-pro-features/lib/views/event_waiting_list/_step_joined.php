<?php
/**
 * Final step: they are in the queue.
 *
 * This is the last step, so core strips the footer, progress bar and side panel here, the same
 * treatment its own `confirmation` step gets, which is what makes this read as an end state rather
 * than a dialog that lost its chrome mid-flow.
 *
 * @var OsEventModel|null                 $event
 * @var OsEventWaitingListModel|null $entry
 * @var int                               $position
 * @var int                               $quantity
 * @var array                             $chosen_tickets One row per ticket queued for, or [] on a flat event
 * @var string                            $current_step_code
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="step-event-waiting-list-done-w latepoint-step-content" data-step-code="<?php echo esc_attr( $current_step_code ); ?>">
	<?php
	do_action( 'latepoint_before_step_content', $current_step_code );
	echo OsStepsHelper::get_formatted_extra_step_content( $current_step_code, 'before' );
	?>

	<div class="ewl-confirmation">
		<div class="ewl-confirmation-icon">
			<i class="latepoint-icon latepoint-icon-checkmark"></i>
		</div>
		<h3 class="ewl-title"><?php esc_html_e( 'You are on the waiting list', 'latepoint-pro-features' ); ?></h3>

		<?php if ( $event && $event->id ) : ?>
			<div class="ewl-event-name"><?php echo esc_html( $event->name ); ?></div>
		<?php endif; ?>

		<?php if ( ! empty( $chosen_tickets ) ) : ?>
			<?php // One badge per ticket: each queue is its own, so a single position would be meaningless. ?>
			<div class="ewl-position-badges">
				<?php foreach ( $chosen_tickets as $chosen_ticket ) : ?>
					<div class="ewl-position-badge">
						<span class="ewl-position-label">
							<?php
							printf(
								/* translators: %1$s: ticket name, %2$d: number of places */
								esc_html( _n( '%1$s · %2$d place', '%1$s · %2$d places', (int) $chosen_ticket['quantity'], 'latepoint-pro-features' ) ),
								esc_html( $chosen_ticket['type'] ? $chosen_ticket['type']->name : '' ),
								(int) $chosen_ticket['quantity']
							);
							?>
						</span>
						<span class="ewl-position-value">#<?php echo esc_html( (string) $chosen_ticket['position'] ); ?></span>
					</div>
				<?php endforeach; ?>
			</div>
		<?php else : ?>
			<?php if ( $position ) : ?>
				<div class="ewl-position-badge">
					<span class="ewl-position-label"><?php esc_html_e( 'Your position', 'latepoint-pro-features' ); ?></span>
					<span class="ewl-position-value">#<?php echo esc_html( (string) $position ); ?></span>
				</div>
			<?php endif; ?>

			<?php if ( $quantity > 1 ) : ?>
				<div class="ewl-confirmation-meta">
					<?php
					printf(
						/* translators: %d: number of places requested */
						esc_html( _n( 'For %d place', 'For %d places', (int) $quantity, 'latepoint-pro-features' ) ),
						(int) $quantity
					);
					?>
				</div>
			<?php endif; ?>
		<?php endif; ?>

		<div class="ewl-confirmation-note">
			<?php esc_html_e( 'We will email you if a place becomes available. Your position is only a guide. Places are offered by the organizer and are not assigned automatically.', 'latepoint-pro-features' ); ?>
		</div>
	</div>

	<?php
	echo OsStepsHelper::get_formatted_extra_step_content( $current_step_code, 'after' );
	do_action( 'latepoint_after_step_content', $current_step_code );
	?>
</div>
