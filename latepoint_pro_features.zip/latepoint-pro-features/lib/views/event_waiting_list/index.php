<?php
/**
 * Events → Waiting List.
 *
 * The queue gets its own screen rather than living inside Registrations, because a queued person
 * is not a registration: they hold a position, not a place. The markup mirrors core's registrations
 * table so the shared latepoint_filter_table() JS drives the filters and pagination unchanged.
 *
 * @var OsEventWaitingListModel[] $entries
 * @var OsEventModel[]                 $events
 * @var int                            $total_records
 * @var int                            $total_pages
 * @var int                            $current_page_number
 * @var int                            $showing_from
 * @var int                            $showing_to
 * @var int                            $total_waiting
 * @var string                         $status_filter
 * @var string                         $event_filter
 * @var string                         $ticket_type_filter
 * @var OsEventTicketTypeModel[]       $ticket_types Only when an event filter is applied
 * @var string                         $customer_query
 * @var string                         $email_query
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$status_filter_options = [
	''                                            => __( 'All Statuses', 'latepoint-pro-features' ),
	LATEPOINT_EVENT_WAITING_LIST_STATUS_WAITING   => __( 'Waiting', 'latepoint-pro-features' ),
	LATEPOINT_EVENT_WAITING_LIST_STATUS_INVITED   => __( 'Invited', 'latepoint-pro-features' ),
	LATEPOINT_EVENT_WAITING_LIST_STATUS_CONVERTED => __( 'Registered', 'latepoint-pro-features' ),
	LATEPOINT_EVENT_WAITING_LIST_STATUS_REMOVED   => __( 'Removed', 'latepoint-pro-features' ),
	LATEPOINT_EVENT_WAITING_LIST_STATUS_EXPIRED   => __( 'Expired', 'latepoint-pro-features' ),
];

$event_filter_options = [ '' => __( 'All Events', 'latepoint-pro-features' ) ];
foreach ( (array) $events as $event_option ) {
	$event_filter_options[ $event_option->id ] = $event_option->name;
}

$ticket_type_filter_options = [ '' => __( 'All Tickets', 'latepoint-pro-features' ) ];
foreach ( (array) $ticket_types as $ticket_type_option ) {
	$ticket_type_filter_options[ $ticket_type_option->id ] = $ticket_type_option->name;
}
?>
<div class="table-with-pagination-w has-scrollable-table">
	<div class="os-pagination-w">
		<div class="table-heading-w">
			<h2 class="table-heading"><?php esc_html_e( 'Waiting List', 'latepoint-pro-features' ); ?></h2>
			<div class="pagination-info">
				<?php
				echo esc_html__( 'Showing', 'latepoint-pro-features' ) .
					' <span class="os-pagination-from">' . esc_html( (string) $showing_from ) . '</span>&#8211;' .
					'<span class="os-pagination-to">' . esc_html( (string) $showing_to ) . '</span> ' .
					esc_html__( 'of', 'latepoint-pro-features' ) .
					' <span class="os-pagination-total">' . esc_html( (string) $total_records ) . '</span>';
				?>
				&nbsp;&middot;&nbsp;
				<span class="os-pagination-waiting"><?php echo esc_html( (string) $total_waiting ); ?></span> <?php esc_html_e( 'in the queue', 'latepoint-pro-features' ); ?>
			</div>
		</div>
	</div>

	<div class="os-scrollable-table-w">
		<div class="os-table-w os-table-compact">
			<table class="os-table os-scrollable-table" data-route="<?php echo esc_attr( OsRouterHelper::build_route_name( 'event_waiting_list', 'index' ) ); ?>">
				<thead>
					<tr>
						<th><?php esc_html_e( 'ID', 'latepoint-pro-features' ); ?></th>
						<th><?php esc_html_e( 'Event', 'latepoint-pro-features' ); ?></th>
						<th><?php esc_html_e( 'Customer', 'latepoint-pro-features' ); ?></th>
						<th><?php esc_html_e( 'Email', 'latepoint-pro-features' ); ?></th>
						<th><?php esc_html_e( 'Ticket Type', 'latepoint-pro-features' ); ?></th>
						<th><?php esc_html_e( 'Places', 'latepoint-pro-features' ); ?></th>
						<th><?php esc_html_e( 'Position', 'latepoint-pro-features' ); ?></th>
						<th><?php esc_html_e( 'Status', 'latepoint-pro-features' ); ?></th>
						<th><?php esc_html_e( 'Joined', 'latepoint-pro-features' ); ?></th>
						<th><?php esc_html_e( 'Actions', 'latepoint-pro-features' ); ?></th>
					</tr>
					<tr>
						<th><?php echo OsFormHelper::text_field( 'filter[id]', false, '', [ 'style' => 'width: 40px;', 'class' => 'os-table-filter', 'placeholder' => __( 'ID', 'latepoint-pro-features' ) ] ); ?></th>
						<th><?php echo OsFormHelper::select_field( 'filter[event_id]', false, $event_filter_options, $event_filter, [ 'class' => 'os-table-filter' ] ); ?></th>
						<th><?php echo OsFormHelper::text_field( 'filter[customer]', false, $customer_query, [ 'class' => 'os-table-filter', 'placeholder' => __( 'Search by Name', 'latepoint-pro-features' ) ] ); ?></th>
						<th><?php echo OsFormHelper::text_field( 'filter[email]', false, $email_query, [ 'class' => 'os-table-filter', 'placeholder' => __( 'Search by Email', 'latepoint-pro-features' ) ] ); ?></th>
						<th><?php echo OsFormHelper::select_field( 'filter[ticket_type_id]', false, $ticket_type_filter_options, $ticket_type_filter, [ 'class' => 'os-table-filter' ] ); ?></th>
						<th></th>
						<th></th>
						<th><?php echo OsFormHelper::select_field( 'filter[status]', false, $status_filter_options, $status_filter, [ 'class' => 'os-table-filter' ] ); ?></th>
						<th>
							<div class="os-form-group">
								<div class="os-date-range-picker os-table-filter-datepicker"
								     data-can-be-cleared="yes"
								     data-no-value-label="<?php esc_attr_e( 'Filter By Date', 'latepoint-pro-features' ); ?>"
								     data-clear-btn-label="<?php esc_attr_e( 'Reset Date Filtering', 'latepoint-pro-features' ); ?>">
									<span class="range-picker-value"><?php esc_html_e( 'Filter By Date', 'latepoint-pro-features' ); ?></span>
									<i class="latepoint-icon latepoint-icon-chevron-down"></i>
									<input type="hidden" class="os-table-filter os-datepicker-date-from" name="filter[joined_date_from]" value=""/>
									<input type="hidden" class="os-table-filter os-datepicker-date-to" name="filter[joined_date_to]" value=""/>
								</div>
							</div>
						</th>
						<th></th>
					</tr>
				</thead>
				<tbody>
					<?php include( '_table_body.php' ); ?>
				</tbody>
				<tfoot>
					<tr>
						<th><?php esc_html_e( 'ID', 'latepoint-pro-features' ); ?></th>
						<th><?php esc_html_e( 'Event', 'latepoint-pro-features' ); ?></th>
						<th><?php esc_html_e( 'Customer', 'latepoint-pro-features' ); ?></th>
						<th><?php esc_html_e( 'Email', 'latepoint-pro-features' ); ?></th>
						<th><?php esc_html_e( 'Ticket Type', 'latepoint-pro-features' ); ?></th>
						<th><?php esc_html_e( 'Places', 'latepoint-pro-features' ); ?></th>
						<th><?php esc_html_e( 'Position', 'latepoint-pro-features' ); ?></th>
						<th><?php esc_html_e( 'Status', 'latepoint-pro-features' ); ?></th>
						<th><?php esc_html_e( 'Joined', 'latepoint-pro-features' ); ?></th>
						<th><?php esc_html_e( 'Actions', 'latepoint-pro-features' ); ?></th>
					</tr>
				</tfoot>
			</table>
		</div>
	</div>

	<div class="os-pagination-w">
		<div class="pagination-info">
			<?php
			echo esc_html__( 'Showing', 'latepoint-pro-features' ) .
				' <span class="os-pagination-from">' . esc_html( (string) $showing_from ) . '</span>&#8211;' .
				'<span class="os-pagination-to">' . esc_html( (string) $showing_to ) . '</span> ' .
				esc_html__( 'of', 'latepoint-pro-features' ) .
				' <span class="os-pagination-total">' . esc_html( (string) $total_records ) . '</span>';
			?>
		</div>
		<div class="pagination-page-select-w">
			<label for="tablePaginationPageSelector"><?php esc_html_e( 'Page:', 'latepoint-pro-features' ); ?></label>
			<select id="tablePaginationPageSelector" name="page" class="pagination-page-select">
				<?php
				for ( $i = 1; $i <= $total_pages; $i++ ) {
					$selected = ( (int) $current_page_number === $i ) ? 'selected' : '';
					echo '<option ' . esc_html( $selected ) . '>' . esc_html( (string) $i ) . '</option>';
				}
				?>
			</select>
		</div>
	</div>
</div>
