<?php
/*
 * Copyright (c) 2024 LatePoint LLC. All rights reserved.
 */

/**
 * Shared ticket-status card, used by the public ticket page (show.php) and, on the client side,
 * mirrored in JS (event-tickets-admin.js:renderScanResult) for the live scanner result panel.
 *
 * @var OsEventTicketModel|null $ticket
 * @var string                  $verdict Status/verdict code — ticket status (issued|checked_in|void)
 *                                        or a scan verdict (valid|already_scanned|...).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$labels = [
	'valid'                   => __( 'Valid', 'latepoint-pro-features' ),
	'already_scanned'         => __( 'Already Checked In', 'latepoint-pro-features' ),
	'group_partially_scanned' => __( 'Partially Checked In', 'latepoint-pro-features' ),
	'all_already_scanned'     => __( 'All Checked In', 'latepoint-pro-features' ),
	'not_found'               => __( 'Not Found', 'latepoint-pro-features' ),
	'registration_cancelled'  => __( 'Cancelled', 'latepoint-pro-features' ),
	'event_cancelled'         => __( 'Event Cancelled', 'latepoint-pro-features' ),
	'not_valid_for_date'      => __( 'Not Valid Today', 'latepoint-pro-features' ),
	'issued'                  => __( 'Issued', 'latepoint-pro-features' ),
	'checked_in'              => __( 'Checked In', 'latepoint-pro-features' ),
	'void'                    => __( 'Void', 'latepoint-pro-features' ),
];
$good_verdicts = [ 'valid', 'group_partially_scanned', 'issued', 'checked_in' ];
$is_good       = in_array( $verdict, $good_verdicts, true );
?>
<div class="latepoint-message latepoint-message-<?php echo $is_good ? 'success' : 'error'; ?> os-scan-result">
	<div class="os-scan-result-status"><?php echo esc_html( $labels[ $verdict ] ?? ucwords( str_replace( '_', ' ', $verdict ) ) ); ?></div>
	<?php if ( $ticket ) : ?>
		<?php
		$event    = $ticket->get_event();
		$customer = $ticket->get_customer();
		?>
		<div class="os-scan-result-event"><?php echo esc_html( $event ? $event->name : '' ); ?></div>
		<div class="os-scan-result-meta">
			<?php echo esc_html( $ticket->get_display_label() ); ?>
			<?php if ( $customer ) : ?>
				&middot; <?php echo esc_html( $customer->full_name ); ?>
			<?php endif; ?>
		</div>
		<div class="os-scan-result-code"><code><?php echo esc_html( $ticket->ticket_code ); ?></code></div>
	<?php endif; ?>
</div>
