<?php
/*
 * Copyright (c) 2024 LatePoint LLC. All rights reserved.
 */

/**
 * @var OsEventModel[] $events
 * @var OsEventTicketModel[] $tickets
 * @var int $selected_event_id
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! OsSettingsHelper::is_on( 'enable_events_functionality' ) ) : ?>
	<div class="latepoint-message latepoint-message-subtle">
		<?php
		echo wp_kses(
			sprintf(
				/* translators: %1$s and %2$s are opening and closing anchor tags */
				__( 'Events functionality is currently disabled. You can enable it in %1$sGeneral Settings%2$s.', 'latepoint-pro-features' ),
				'<a href="' . esc_url( admin_url( 'admin.php?page=latepoint&route_name=settings__general#stickySectionEvents' ) ) . '">',
				'</a>'
			),
			[ 'a' => [ 'href' => [] ] ]
		);
		?>
	</div>
<?php elseif ( ! OsFeatureEventTicketsHelper::is_enabled() ) : ?>
	<div class="latepoint-message latepoint-message-subtle">
		<?php
		echo wp_kses(
			sprintf(
				/* translators: %1$s and %2$s are opening and closing anchor tags */
				__( 'Event E-Tickets are currently disabled. You can enable them in %1$sGeneral Settings%2$s.', 'latepoint-pro-features' ),
				'<a href="' . esc_url( admin_url( 'admin.php?page=latepoint&route_name=settings__general#stickySectionEvents' ) ) . '">',
				'</a>'
			),
			[ 'a' => [ 'href' => [] ] ]
		);
		?>
	</div>
<?php else : ?>
	<div class="os-event-tickets-scanner-w"
		 data-validate-route="<?php echo esc_attr( OsRouterHelper::build_route_name( 'event_tickets', 'validate' ) ); ?>"
		 data-validate-nonce="<?php echo esc_attr( wp_create_nonce( 'event_tickets_scan' ) ); ?>"
		 data-tickets-route="<?php echo esc_attr( OsRouterHelper::build_route_name( 'event_tickets', 'tickets_for_event' ) ); ?>">

		<div class="table-with-pagination-w has-scrollable-table">
			<div class="os-pagination-w with-actions">
				<div class="table-heading-w">
					<h2 class="table-heading"><?php esc_html_e( 'Tickets', 'latepoint-pro-features' ); ?></h2>
				</div>
				<div class="mobile-table-actions-trigger"><i class="latepoint-icon latepoint-icon-more-horizontal"></i></div>
				<div class="table-actions">
					<button type="button" class="latepoint-btn os-open-scanner-btn">
						<i class="latepoint-icon latepoint-icon-camera"></i>
						<span><?php esc_html_e( 'Scan E-Ticket', 'latepoint-pro-features' ); ?></span>
					</button>
				</div>
			</div>

			<div class="os-pagination-w os-scanner-filters-row">
				<div class="os-scanner-event-select-w">
					<?php
					$event_options = array_map(
						function ( $event ) {
							return [
								'value' => $event->id,
								'label' => $event->name,
							];
						},
						$events
					);
					echo OsFormHelper::select_field( 'scanner_event_id', false, $event_options, $selected_event_id, [ 'theme' => 'simple', 'class' => 'os-scanner-event-select', 'placeholder' => __( 'Select Event...', 'latepoint-pro-features' ) ], [ 'class' => 'os-scanner-toolbar-field' ] );
					?>
				</div>
				<div class="table-actions">
					<?php echo OsFormHelper::text_field( 'scanner_ticket_search', false, '', [ 'theme' => 'simple', 'class' => 'os-scanner-ticket-search', 'placeholder' => __( 'Search by ticket code...', 'latepoint-pro-features' ) ], [ 'class' => 'os-scanner-toolbar-field' ] ); ?>
				</div>
			</div>

			<div class="os-scrollable-table-w">
				<div class="os-table-w os-table-compact">
					<table class="os-table os-scrollable-table">
						<thead>
							<tr>
								<th><?php esc_html_e( 'ID', 'latepoint-pro-features' ); ?></th>
								<th><?php esc_html_e( 'Ticket', 'latepoint-pro-features' ); ?></th>
								<th><?php esc_html_e( 'Event', 'latepoint-pro-features' ); ?></th>
								<th><?php esc_html_e( 'Attendee', 'latepoint-pro-features' ); ?></th>
								<th><?php esc_html_e( 'Status', 'latepoint-pro-features' ); ?></th>
								<th><?php esc_html_e( 'Actions', 'latepoint-pro-features' ); ?></th>
							</tr>
						</thead>
						<tbody class="os-scanner-tickets-list">
							<?php include LATEPOINT_ADDON_PRO_VIEWS_ABSPATH . 'event_tickets/_tickets_table_body.php'; ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>

		<?php
		/**
		 * Styled like a real .latepoint-lightbox-w (same heading/content/close-icon chrome, see
		 * _event-tickets-admin.scss), but deliberately NOT that class: the camera stream is bound to
		 * the <video> element below, and the global lightbox system (admin.js) tears down and
		 * `.remove()`s any `.latepoint-lightbox-w` on every close — which would kill the live stream
		 * and delete this modal from the DOM so it could never be reopened. Kept as a persistent node
		 * with its own open/close handling in _event-tickets-admin.js instead.
		 */
		?>
		<div class="os-scanner-lightbox">
			<div class="latepoint-lightbox-i">
				<div class="latepoint-lightbox-heading">
					<h2><?php esc_html_e( 'Scan E-Ticket', 'latepoint-pro-features' ); ?></h2>
				</div>
				<div class="latepoint-lightbox-content">
					<div class="os-scanner-camera-w">
						<video class="os-scanner-video" playsinline muted autoplay></video>
						<canvas class="os-scanner-canvas" style="display:none;"></canvas>
						<div class="os-scanner-frame"></div>
					</div>
					<div class="os-scanner-camera-error latepoint-message latepoint-message-error" style="display:none;"></div>
					<div class="os-scanner-result"></div>
					<div class="os-scanner-manual-entry">
						<?php echo OsFormHelper::text_field( 'scanner_manual_code', false, '', [ 'theme' => 'simple', 'class' => 'os-scanner-manual-input', 'placeholder' => __( 'Or enter ticket code manually', 'latepoint-pro-features' ) ] ); ?>
						<button type="button" class="latepoint-btn os-scanner-manual-submit"><?php esc_html_e( 'Validate', 'latepoint-pro-features' ); ?></button>
					</div>
				</div>
				<a href="#" class="os-scanner-lightbox-close"><i class="latepoint-icon latepoint-icon-x"></i></a>
			</div>
			<div class="os-scanner-lightbox-shadow"></div>
		</div>
	</div>
<?php endif; ?>
