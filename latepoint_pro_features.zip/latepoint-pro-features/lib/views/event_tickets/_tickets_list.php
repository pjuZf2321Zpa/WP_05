<?php
/*
 * Copyright (c) 2024 LatePoint LLC. All rights reserved.
 */

/**
 * Ticket cards for the customer dashboard's Event Tickets tab
 * (OsFeatureEventTicketsHelper::render_customer_dashboard_tickets()) — read-only, no check-in
 * control. The admin Check-In page has its own table partial, _tickets_table_body.php.
 *
 * @var OsEventTicketModel[] $tickets
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="os-event-tickets-list">
	<?php if ( empty( $tickets ) ) : ?>
		<p class="os-event-tickets-empty"><?php esc_html_e( 'No tickets found.', 'latepoint-pro-features' ); ?></p>
	<?php else : ?>
		<?php foreach ( $tickets as $ticket ) : ?>
			<?php $event = $ticket->get_event(); ?>
			<div class="os-event-ticket-row status-<?php echo esc_attr( $ticket->status ); ?>" data-ticket-id="<?php echo esc_attr( $ticket->id ); ?>">
				<div class="et-qr"><img src="<?php echo esc_url( $ticket->get_qr_image_url() ); ?>" width="56" height="56" alt=""></div>
				<div class="et-info">
					<div class="et-label"><?php echo esc_html( $ticket->get_display_label() ); ?></div>
					<div class="et-meta">
						<?php echo esc_html( $event ? $event->name : '' ); ?>
						<?php if ( $event ) : ?>
							&middot; <?php echo esc_html( $event->get_formatted_start_date() ); ?>
						<?php endif; ?>
					</div>
					<div class="et-code"><code><?php echo esc_html( $ticket->ticket_code ); ?></code></div>
				</div>
				<div class="et-status">
					<span class="lp-order-status lp-order-status-<?php echo esc_attr( $ticket->status ); ?>"><?php echo esc_html( $ticket->get_status_label() ); ?></span>
				</div>
				<div class="et-actions">
					<a href="<?php echo esc_url( $ticket->get_public_url() ); ?>" target="_blank" class="latepoint-btn latepoint-btn-sm latepoint-btn-outline"><?php esc_html_e( 'View', 'latepoint-pro-features' ); ?></a>
					<a href="<?php echo esc_url( $ticket->get_pdf_download_url() ); ?>" target="_blank" class="latepoint-btn latepoint-btn-sm latepoint-btn-outline"><?php esc_html_e( 'PDF', 'latepoint-pro-features' ); ?></a>
				</div>
			</div>
		<?php endforeach; ?>
	<?php endif; ?>
</div>
