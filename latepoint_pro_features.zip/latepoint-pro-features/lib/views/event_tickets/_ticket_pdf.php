<?php
/*
 * Copyright (c) 2024 LatePoint LLC. All rights reserved.
 */

/**
 * Dompdf source HTML for a single ticket — included by OsEventTicketQrHelper::build_ticket_pdf().
 * Dompdf renders a static HTML/CSS snapshot (no JS, no external requests), so the QR here is an
 * embedded data: URI rather than the hosted qr_image URL used in email/web contexts.
 *
 * @var OsEventTicketModel $ticket
 * @var OsEventModel|null  $event
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$qr_data_uri   = OsEventTicketQrHelper::render_data_uri( $ticket->ticket_code );
$reg           = $ticket->get_registration();
$customer      = $ticket->get_customer();
$location_name = $event ? $event->get_display_location_name() : '';
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<style>
	body { font-family: DejaVu Sans, sans-serif; color: #222; }
	.ticket { border: 2px solid #333; border-radius: 8px; padding: 24px; width: 420px; margin: 40px auto; }
	.ticket h1 { font-size: 20px; margin: 0 0 4px; text-align: center; }
	.ticket .sub { color: #666; font-size: 13px; margin-bottom: 16px; text-align: center; }
	.ticket .qr { text-align: center; margin: 16px 0; }
	.ticket .code { text-align: center; font-size: 16px; letter-spacing: 2px; font-weight: bold; margin-top: 8px; }
	.ticket .row { margin-top: 12px; font-size: 13px; }
	.ticket .row .label { color: #888; display: inline-block; width: 120px; }
</style>
</head>
<body>
<div class="ticket">
	<h1><?php echo esc_html( $event ? $event->name : __( 'Event Ticket', 'latepoint-pro-features' ) ); ?></h1>
	<div class="sub"><?php echo esc_html( $ticket->get_display_label() ); ?></div>
	<div class="qr"><img src="<?php echo esc_attr( $qr_data_uri ); ?>" width="200" height="200"></div>
	<div class="code"><?php echo esc_html( $ticket->ticket_code ); ?></div>
	<?php if ( $event ) : ?>
		<div class="row"><span class="label"><?php esc_html_e( 'Date', 'latepoint-pro-features' ); ?>:</span> <?php echo esc_html( $event->get_formatted_start_date() ); ?></div>
		<div class="row"><span class="label"><?php esc_html_e( 'Time', 'latepoint-pro-features' ); ?>:</span> <?php echo esc_html( $event->get_formatted_start_time() ); ?></div>
	<?php endif; ?>
	<?php if ( $location_name ) : ?>
		<div class="row"><span class="label"><?php esc_html_e( 'Location', 'latepoint-pro-features' ); ?>:</span> <?php echo esc_html( $location_name ); ?></div>
	<?php endif; ?>
	<?php if ( $customer ) : ?>
		<div class="row"><span class="label"><?php esc_html_e( 'Attendee', 'latepoint-pro-features' ); ?>:</span> <?php echo esc_html( $customer->full_name ); ?></div>
	<?php endif; ?>
	<?php if ( $reg ) : ?>
		<div class="row"><span class="label"><?php esc_html_e( 'Registration', 'latepoint-pro-features' ); ?>:</span> <?php echo esc_html( $reg->registration_code ); ?></div>
	<?php endif; ?>
</div>
</body>
</html>
