<?php
/*
 * Copyright (c) 2024 LatePoint LLC. All rights reserved.
 */

/**
 * Admin ticket rows for the Check-In scanner table (event_tickets/scanner.php) — the tbody rendered
 * on initial page load and swapped in wholesale by OsEventTicketsController::tickets_for_event() on
 * event-select/search, mirroring how OsEventRegistrationsController::index() re-renders
 * event_registrations/_table_body.php.
 *
 * @var OsEventTicketModel[] $tickets
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( empty( $tickets ) ) : ?>
	<tr>
		<td colspan="6" class="text-center"><?php esc_html_e( 'No tickets found.', 'latepoint-pro-features' ); ?></td>
	</tr>
	<?php
	return;
endif;

foreach ( $tickets as $ticket ) :
	$event    = $ticket->get_event();
	$customer = $ticket->get_customer();
	?>
	<tr data-ticket-id="<?php echo esc_attr( $ticket->id ); ?>">
		<td class="text-center os-column-faded"><?php echo esc_html( (string) $ticket->id ); ?></td>
		<td class="os-scanner-ticket-cell">
			<div class="os-scanner-ticket-label"><?php echo esc_html( $ticket->get_display_label() ); ?></div>
			<code><?php echo esc_html( $ticket->ticket_code ); ?></code>
		</td>
		<td><?php echo esc_html( $event ? $event->name : '' ); ?></td>
		<td><?php echo esc_html( $customer ? $customer->full_name : '' ); ?></td>
		<td>
			<span class="lp-order-status lp-order-status-<?php echo esc_attr( $ticket->status ); ?>"><?php echo esc_html( $ticket->get_status_label() ); ?></span>
		</td>
		<td class="event-reg-actions">
			<a href="<?php echo esc_url( $ticket->get_public_url() ); ?>" target="_blank" class="latepoint-btn latepoint-btn-link"><?php esc_html_e( 'View', 'latepoint-pro-features' ); ?></a>
			<a href="<?php echo esc_url( $ticket->get_pdf_download_url() ); ?>" target="_blank" class="latepoint-btn latepoint-btn-link"><?php esc_html_e( 'PDF', 'latepoint-pro-features' ); ?></a>
			<?php if ( ! $ticket->is_void() && ! $ticket->is_checked_in() ) : ?>
				<a href="#"
				   data-os-action="<?php echo esc_attr( OsRouterHelper::build_route_name( 'event_tickets', 'check_in' ) ); ?>"
				   data-os-params="<?php echo esc_attr( OsUtilHelper::build_os_params( [ 'id' => $ticket->id ], 'check_in_event_ticket_' . $ticket->id ) ); ?>"
				   data-os-success-action="reload"
				   class="latepoint-btn latepoint-btn-link">
					<?php esc_html_e( 'Check In', 'latepoint-pro-features' ); ?>
				</a>
			<?php endif; ?>
		</td>
	</tr>
<?php endforeach; ?>
