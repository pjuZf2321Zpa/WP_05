<?php
/*
 * Copyright (c) 2024 LatePoint LLC. All rights reserved.
 */

/**
 * Public ticket page — the QR encodes this page's URL (OsEventTicketQrHelper::build_qr_payload()),
 * so a plain phone camera opens it directly. Staff (backend users) additionally get a Check In
 * button here; everyone else gets a read-only ticket so a customer can't check themselves in by
 * viewing/forwarding their own QR.
 *
 * @var OsEventTicketModel|null $ticket
 * @var bool                    $is_staff
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="os-public-ticket-page">
	<?php if ( ! $ticket ) : ?>
		<div class="latepoint-message latepoint-message-error"><?php esc_html_e( 'Ticket not found.', 'latepoint-pro-features' ); ?></div>
	<?php else : ?>
		<?php
		$event    = $ticket->get_event();
		$reg      = $ticket->get_registration();
		$location = $event ? $event->get_location() : null;
		?>
		<div class="os-ticket-card">
			<div class="os-ticket-card-header">
				<h2><?php echo esc_html( $event ? $event->name : __( 'Event Ticket', 'latepoint-pro-features' ) ); ?></h2>
			</div>
			<div class="os-ticket-card-qr">
				<img src="<?php echo esc_url( $ticket->get_qr_image_url() ); ?>" width="220" height="220" alt="<?php echo esc_attr( $ticket->ticket_code ); ?>">
			</div>
			<?php
			$verdict = $ticket->status;
			include LATEPOINT_ADDON_PRO_VIEWS_ABSPATH . 'event_tickets/_scan_result.php';
			?>
			<div class="os-ticket-card-details">
				<?php if ( $event ) : ?>
					<div class="os-ticket-detail-row"><span><?php esc_html_e( 'Date', 'latepoint-pro-features' ); ?></span><strong><?php echo esc_html( $event->get_formatted_start_date() ); ?></strong></div>
					<div class="os-ticket-detail-row"><span><?php esc_html_e( 'Time', 'latepoint-pro-features' ); ?></span><strong><?php echo esc_html( $event->get_formatted_start_time() ); ?></strong></div>
				<?php endif; ?>
				<?php if ( $location ) : ?>
					<div class="os-ticket-detail-row"><span><?php esc_html_e( 'Location', 'latepoint-pro-features' ); ?></span><strong><?php echo esc_html( $location->name ); ?></strong></div>
				<?php endif; ?>
				<?php if ( $reg ) : ?>
					<div class="os-ticket-detail-row"><span><?php esc_html_e( 'Registration Code', 'latepoint-pro-features' ); ?></span><strong><?php echo esc_html( $reg->registration_code ); ?></strong></div>
				<?php endif; ?>
			</div>
			<div class="os-ticket-card-actions">
				<a href="<?php echo esc_url( $ticket->get_pdf_download_url() ); ?>" class="latepoint-btn latepoint-btn-outline"><?php esc_html_e( 'Download PDF', 'latepoint-pro-features' ); ?></a>
				<?php if ( $is_staff && ! $ticket->is_void() ) : ?>
					<a href="#" class="latepoint-btn latepoint-btn-primary"
					   data-os-action="<?php echo esc_attr( OsRouterHelper::build_route_name( 'event_tickets', 'check_in' ) ); ?>"
					   data-os-params="<?php echo esc_attr( OsUtilHelper::build_os_params( [ 'id' => $ticket->id ], 'check_in_event_ticket_' . $ticket->id ) ); ?>"
					   data-os-success-action="reload">
						<?php esc_html_e( 'Check In', 'latepoint-pro-features' ); ?>
					</a>
				<?php endif; ?>
			</div>
		</div>
	<?php endif; ?>
</div>
