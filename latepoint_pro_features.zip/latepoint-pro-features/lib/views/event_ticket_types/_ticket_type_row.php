<?php
/*
 * Copyright (c) 2024 LatePoint LLC. All rights reserved.
 */

/**
 * One repeatable row inside the event form's Ticket Types section (_event_form_section.php) —
 * rendered both for existing rows and, with a placeholder index, inside the <template> the
 * "Add Ticket Type" button clones (see _event-ticket-types-admin.js).
 *
 * `data-ticket-type-index` lets the separate "Tickets price by date range" section
 * (_price_ranges_section.php / _price_range_type_block.php) keep its own, duplicate list of types
 * in sync with this one — same index both sides, assigned once and stable for the row's lifetime.
 *
 * @var OsEventTicketTypeModel $type
 * @var int|string             $index
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$field_name = function ( string $suffix ) use ( $index ) {
	return 'event[ticket_types][' . $index . '][' . $suffix . ']';
};
?>
<div class="os-event-ticket-type-row" data-ticket-type-index="<?php echo esc_attr( $index ); ?>">
	<?php echo OsFormHelper::hidden_field( $field_name( 'id' ), $type->id, [ 'class' => 'os-ticket-type-id-input' ] ); ?>
	<div class="os-event-ticket-type-col-name">
		<?php echo OsFormHelper::text_field( $field_name( 'name' ), false, $type->name, [ 'theme' => 'simple', 'placeholder' => __( 'e.g. General', 'latepoint-pro-features' ) ] ); ?>
	</div>
	<div class="os-event-ticket-type-col-price">
		<?php echo OsFormHelper::money_field( $field_name( 'price' ), false, $type->price, [ 'theme' => 'simple' ] ); ?>
	</div>
	<div class="os-event-ticket-type-col-capacity">
		<?php echo OsFormHelper::text_field( $field_name( 'capacity' ), false, $type->capacity ?: '', [ 'theme' => 'simple', 'type' => 'number', 'min' => '0', 'placeholder' => 'e.g. 10' ] ); ?>
	</div>
	<div class="os-event-ticket-type-col-actions">
		<a href="#" class="os-remove-ticket-type-row-btn" title="<?php esc_attr_e( 'Remove', 'latepoint-pro-features' ); ?>">
			<i class="latepoint-icon latepoint-icon-trash-2"></i>
		</a>
	</div>
</div>
