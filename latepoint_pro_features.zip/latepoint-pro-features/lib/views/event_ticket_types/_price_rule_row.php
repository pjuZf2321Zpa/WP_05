<?php
/*
 * Copyright (c) 2024 LatePoint LLC. All rights reserved.
 */

/**
 * One repeatable row inside a ticket type's block in the "Tickets price by date range" section (see
 * _price_range_type_block.php) — a single date-range price override. Rendered both for existing
 * rules and, with placeholder indexes, inside the <template> the "Add Date Range" button clones
 * (see _event-ticket-types-admin.js).
 *
 * Start and end are both always-on and required — a price range with an open-ended bound isn't a
 * meaningful "range", so unlike the event's own Registration Opens/Closes fields there is no
 * "custom date & time" toggle here. A row missing either bound is simply not saved (see
 * OsFeatureEventTicketTypesHelper::sync_price_rules_for_type()), the same way a blank price is.
 *
 * @var int|string                       $index      Parent ticket type's index (real or __INDEX__).
 * @var OsEventTicketTypePriceRuleModel   $rule
 * @var int|string                       $rule_index Real index or the __RULE_INDEX__ placeholder.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$field_name = function ( string $suffix ) use ( $index, $rule_index ) {
	return 'event[ticket_types][' . $index . '][price_rules][' . $rule_index . '][' . $suffix . ']';
};

$start_raw = $rule->start_datetime_utc;
$start_set = ( ! empty( $start_raw ) && 0 !== strpos( $start_raw, '0000-00-00' ) );
if ( $start_set ) {
	$start_parts = OsEventsManagerHelper::local_date_and_minutes_from_utc( $start_raw );
	$start_d     = $start_parts['date'];
	$start_min   = $start_parts['minutes'];
} else {
	$start_d   = '';
	$start_min = '';
}
$start_d_f = $start_set ? OsTimeHelper::get_readable_date_from_string( $start_d ) : __( 'Select date', 'latepoint-pro-features' );

$end_raw = $rule->end_datetime_utc;
$end_set = ( ! empty( $end_raw ) && 0 !== strpos( $end_raw, '0000-00-00' ) );
if ( $end_set ) {
	$end_parts = OsEventsManagerHelper::local_date_and_minutes_from_utc( $end_raw );
	$end_d     = $end_parts['date'];
	$end_min   = $end_parts['minutes'];
} else {
	$end_d   = '';
	$end_min = '';
}
$end_d_f = $end_set ? OsTimeHelper::get_readable_date_from_string( $end_d ) : __( 'Select date', 'latepoint-pro-features' );
?>
<div class="os-price-range-row">
	<?php echo OsFormHelper::hidden_field( $field_name( 'id' ), $rule->id, [ 'class' => 'os-price-rule-id-input' ] ); ?>
	<div class="os-row">
		<div class="os-col-lg-3">
			<div class="os-form-group">
				<label><?php esc_html_e( 'Price', 'latepoint-pro-features' ); ?></label>
				<?php echo OsFormHelper::money_field( $field_name( 'price' ), false, $rule->price, [ 'theme' => 'simple' ] ); ?>
			</div>
		</div>
		<div class="os-col-lg-4">
			<div class="os-form-group">
				<label><?php esc_html_e( 'Starts', 'latepoint-pro-features' ); ?> <span class="os-required-mark">*</span></label>
				<div class="os-datetime-pair">
					<?php echo OsFormHelper::date_picker_field( $field_name( 'start_date' ), $start_d_f, $start_d ); ?>
					<?php echo OsFormHelper::time_field( $field_name( 'start_time' ), '', $start_min ); ?>
				</div>
			</div>
		</div>
		<div class="os-col-lg-4">
			<div class="os-form-group">
				<label><?php esc_html_e( 'Ends', 'latepoint-pro-features' ); ?> <span class="os-required-mark">*</span></label>
				<div class="os-datetime-pair">
					<?php echo OsFormHelper::date_picker_field( $field_name( 'end_date' ), $end_d_f, $end_d ); ?>
					<?php echo OsFormHelper::time_field( $field_name( 'end_time' ), '', $end_min ); ?>
				</div>
			</div>
		</div>
		<div class="os-col-lg-1">
			<a href="#" class="os-remove-price-rule-row-btn" title="<?php esc_attr_e( 'Remove', 'latepoint-pro-features' ); ?>">
				<i class="latepoint-icon latepoint-icon-trash-2"></i>
			</a>
		</div>
	</div>
</div>
