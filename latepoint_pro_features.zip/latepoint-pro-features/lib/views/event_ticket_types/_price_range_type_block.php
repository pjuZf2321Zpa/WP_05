<?php
/*
 * Copyright (c) 2024 LatePoint LLC. All rights reserved.
 */

/**
 * One ticket type's block inside the "Tickets price by date range" section (_price_ranges_section.php) —
 * a read-only mirrored name (the type itself is edited in the Ticket Types section above) plus its
 * repeatable date-range price rows.
 *
 * This is a deliberate duplicate of the ticket type list in Ticket Types, not a second source of
 * truth: kept in sync purely by JS, keyed on the same `event[ticket_types][<i>]` index both
 * sections use (see _event-ticket-types-admin.js) — adding/removing/renaming a row in the Ticket
 * Types section adds/removes/relabels the matching block here.
 *
 * @var OsEventTicketTypeModel $type
 * @var int|string             $index
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$price_rules = $type->get_price_rules();
?>
<div class="os-price-range-type-block" data-ticket-type-index="<?php echo esc_attr( $index ); ?>">
	<div class="os-price-range-type-header">
		<div class="os-price-range-type-label"><?php esc_html_e( 'Ticket Type', 'latepoint-pro-features' ); ?></div>
		<h4 class="os-price-range-type-name"><?php echo esc_html( $type->name ?: __( 'Untitled ticket type', 'latepoint-pro-features' ) ); ?></h4>
	</div>
	<div class="os-price-range-rows">
		<?php
		foreach ( $price_rules as $rule_index => $rule ) {
			include LATEPOINT_ADDON_PRO_VIEWS_ABSPATH . 'event_ticket_types/_price_rule_row.php';
		}
		?>
	</div>
	<template class="os-price-range-row-template">
		<?php
		$rule       = new OsEventTicketTypePriceRuleModel();
		$rule_index = '__RULE_INDEX__';
		include LATEPOINT_ADDON_PRO_VIEWS_ABSPATH . 'event_ticket_types/_price_rule_row.php';
		?>
	</template>
	<button type="button" class="latepoint-btn latepoint-btn-outline latepoint-btn-sm os-add-price-rule-row-btn">
		<i class="latepoint-icon latepoint-icon-plus"></i>
		<span><?php esc_html_e( 'Add Date Range', 'latepoint-pro-features' ); ?></span>
	</button>
</div>
