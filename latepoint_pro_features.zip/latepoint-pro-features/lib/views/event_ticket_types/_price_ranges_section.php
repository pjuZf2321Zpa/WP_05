<?php
/*
 * Copyright (c) 2024 LatePoint LLC. All rights reserved.
 */

/**
 * "Tickets price by date range" section on the event edit form — a separate section from Ticket Types,
 * gated on Ticket Types being enabled for this event. See
 * OsFeatureEventTicketTypesHelper::output_types_on_event_form(), hooked to
 * `latepoint_event_form_after` right after the Ticket Types section itself. Its side-nav entry is
 * added via the `latepoint_event_edit_form_sticky_section_items` filter (events_manager/_form.php
 * in the base plugin) rather than editing that file directly.
 *
 * @var OsEventModel               $event
 * @var OsEventTicketTypeModel[]   $types
 * @var bool                       $use_ticket_types_is_on
 * @var bool                       $use_ticket_type_price_ranges_is_on
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="white-box section-anchor" id="stickySectionPriceRanges">
	<div class="white-box-header">
		<div class="os-form-sub-header"><h3><?php esc_html_e( 'Tickets price by date range', 'latepoint-pro-features' ); ?></h3></div>
	</div>
	<div class="white-box-content">
		<?php if ( $event->is_new_record() ) : ?>
			<div class="latepoint-message latepoint-message-subtle">
				<?php esc_html_e( 'Save this event first, then you can set up date-range pricing.', 'latepoint-pro-features' ); ?>
			</div>
		<?php else : ?>
			<div id="osEventPriceRangesDisabledNotice" class="latepoint-message latepoint-message-subtle"<?php echo $use_ticket_types_is_on ? ' style="display:none;"' : ''; ?>>
				<?php esc_html_e( 'Enable Ticket Types above to set up date-range pricing for them.', 'latepoint-pro-features' ); ?>
			</div>
			<div id="osEventPriceRangesContent"<?php echo $use_ticket_types_is_on ? '' : ' style="display:none;"'; ?>>
				<div id="osEventUseTicketTypePriceRangesToggler">
					<?php
					echo OsFormHelper::toggler_field(
						'event[use_ticket_type_price_ranges]',
						__( 'Enable tickets price by date range', 'latepoint-pro-features' ),
						$use_ticket_type_price_ranges_is_on,
						'osEventPriceRangesRowsWrap',
						false,
						[ 'sub_label' => __( 'Automatically charge a different price for a ticket type while a date range is active — e.g. Early Bird, Last-minute. A start and end date & time are required for each range; outside every range, the ticket type\'s own price above is used.', 'latepoint-pro-features' ) ]
					);
					?>
				</div>
				<div id="osEventPriceRangesRowsWrap"<?php echo $use_ticket_type_price_ranges_is_on ? '' : ' style="display:none;"'; ?>>
					<div class="os-price-range-types-w">
						<?php if ( empty( $types ) ) : ?>
							<p class="description os-price-range-types-empty-notice"><?php esc_html_e( 'Add a ticket type above first.', 'latepoint-pro-features' ); ?></p>
						<?php endif; ?>
						<?php
						foreach ( $types as $index => $type ) {
							include LATEPOINT_ADDON_PRO_VIEWS_ABSPATH . 'event_ticket_types/_price_range_type_block.php';
						}
						?>
						<template class="os-price-range-type-block-template">
							<?php
							$type  = new OsEventTicketTypeModel();
							$index = '__INDEX__';
							include LATEPOINT_ADDON_PRO_VIEWS_ABSPATH . 'event_ticket_types/_price_range_type_block.php';
							?>
						</template>
					</div>
				</div>
			</div>
		<?php endif; ?>
	</div>
</div>
