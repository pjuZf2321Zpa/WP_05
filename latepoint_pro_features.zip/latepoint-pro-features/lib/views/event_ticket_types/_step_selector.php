<?php
/*
 * Copyright (c) 2024 LatePoint LLC. All rights reserved.
 */

/**
 * Replaces the wizard's default single quantity stepper with one priced row per ticket type —
 * rendered into `latepoint_event_tickets_step_selector_html` (see
 * OsFeatureEventTicketTypesHelper::render_types_selector()), on the SAME wizard step Free's
 * default selector would otherwise occupy.
 *
 * Deliberately reuses Free's existing `.event-ticket-qty-w` stepper markup/classes as-is (see
 * events_manager/_step_event_tickets.php and front/_events_manager.js) so the delegated +/-
 * click handler, input clamping, live summary-reload AJAX call, and CSS all work unmodified —
 * only the input's `name` (keyed by ticket type id, instead of the single `event_quantity`) and
 * `data-min-capacity="0"` (a type can be dropped back to zero) differ from the default selector.
 *
 * @var OsEventModel             $event
 * @var OsEventTicketTypeModel[] $types
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$event_available = $event->get_available_capacity(); // PHP_INT_MAX when the event has no overall cap

// Repopulate from the active cart item on back-navigation — this view re-renders from scratch on
// every step re-entry (main.js replaces the step content), so without this every row would reset
// to 0 even though the cart summary still reflects a previously-saved selection.
$existing_quantities = [];
foreach ( OsFeatureEventTicketTypesHelper::get_existing_breakdown_for_event( $event ) as $type_id => $row ) {
	$existing_quantities[ (int) $type_id ] = (int) ( $row['quantity'] ?? 0 );
}
?>
<div class="os-event-ticket-types-selector-w">
	<?php foreach ( $types as $type ) : ?>
		<?php
		$type_available  = $type->get_available_capacity(); // PHP_INT_MAX when this type has no cap
		$is_sold_out     = $type_available <= 0 || $event_available <= 0;
		$max_qty         = $is_sold_out ? 0 : min( $type_available, $event_available, 10 );
		$has_active_sale = (bool) $type->get_active_price_rule();
		?>
		<div class="event-ticket-selector-w os-event-ticket-type-selector<?php echo $is_sold_out ? ' is-sold-out' : ''; ?>">
			<div class="event-ticket-selector-label">
				<h4>
					<?php echo esc_html( $type->name ); ?>
					<?php if ( $has_active_sale ) : ?>
						<span class="os-event-ticket-type-price os-event-ticket-type-price-original"><?php echo esc_html( $type->get_formatted_base_price() ); ?></span>
					<?php endif; ?>
					<span class="os-event-ticket-type-price<?php echo $has_active_sale ? ' os-event-ticket-type-price-sale' : ''; ?>"><?php echo esc_html( $type->get_formatted_price() ); ?></span>
				</h4>
				<?php if ( $is_sold_out ) : ?>
					<div class="event-step-qty-sublabel os-event-ticket-type-sold-out-badge"><?php esc_html_e( 'Sold out', 'latepoint-pro-features' ); ?></div>
				<?php elseif ( $type->capacity ) : ?>
					<div class="event-step-qty-sublabel"><?php printf( esc_html__( 'Maximum %d per order', 'latepoint-pro-features' ), $max_qty ); ?></div>
				<?php endif; ?>
			</div>

			<div class="event-ticket-qty-w"
			     data-min-capacity="0"
			     data-max-capacity="<?php echo esc_attr( (string) $max_qty ); ?>">
				<div class="event-ticket-qty-btn event-ticket-qty-btn-minus">
					<i class="latepoint-icon latepoint-icon-minus"></i>
				</div>
				<input type="number"
				       tabindex="0"
				       min="0"
				       max="<?php echo esc_attr( (string) $max_qty ); ?>"
				       data-summary-singular="<?php esc_attr_e( 'Ticket', 'latepoint-pro-features' ); ?>"
				       data-summary-plural="<?php esc_attr_e( 'Tickets', 'latepoint-pro-features' ); ?>"
				       name="event_ticket_types[<?php echo esc_attr( (string) $type->id ); ?>]"
				       class="event-ticket-qty-input"
				       value="<?php echo esc_attr( (string) ( $existing_quantities[ $type->id ] ?? 0 ) ); ?>"
				       <?php echo $is_sold_out ? 'disabled' : ''; ?>
				       placeholder="<?php esc_attr_e( 'Qty', 'latepoint-pro-features' ); ?>">
				<div class="event-ticket-qty-btn event-ticket-qty-btn-plus">
					<i class="latepoint-icon latepoint-icon-plus"></i>
				</div>
			</div>
		</div><!-- /.event-ticket-selector-w -->
	<?php endforeach; ?>
</div>
