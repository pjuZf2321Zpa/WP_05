<?php
/*
 * Copyright (c) 2024 LatePoint LLC. All rights reserved.
 */

/**
 * Inline "Ticket Types" section on the event edit form — see
 * OsFeatureEventTicketTypesHelper::output_types_on_event_form(), hooked to
 * `latepoint_event_form_after` (mirrors the Service form's own extras section/hook pair).
 *
 * Rows submit together with the rest of the event form (no separate save action) — persisted by
 * OsFeatureEventTicketTypesHelper::save_types_in_event() on `latepoint_event_created`/`_saved`.
 *
 * Date-range pricing for these types lives in its own section — see _price_ranges_section.php.
 *
 * @var OsEventModel               $event
 * @var OsEventTicketTypeModel[]   $types
 * @var bool                       $use_ticket_types_is_on
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="white-box section-anchor" id="stickySectionTicketTypes">
	<div class="white-box-header">
		<div class="os-form-sub-header"><h3><?php esc_html_e( 'Ticket Types', 'latepoint-pro-features' ); ?></h3></div>
	</div>
	<div class="white-box-content">
		<?php if ( $event->is_new_record() ) : ?>
			<div class="latepoint-message latepoint-message-subtle">
				<?php esc_html_e( 'Save this event first, then you can add ticket types.', 'latepoint-pro-features' ); ?>
			</div>
		<?php else : ?>
			<div id="osEventUseTicketTypesToggler">
				<?php
				echo OsFormHelper::toggler_field(
					'event[use_ticket_types]',
					__( 'Enable Ticket Types', 'latepoint-pro-features' ),
					$use_ticket_types_is_on,
					'osEventTicketTypesRowsWrap',
					false,
					[ 'sub_label' => __( "Add ticket types such as Early Bird, Regular, or VIP, each with its own price and capacity. This overrides the Total Capacity and Ticket Price above.", 'latepoint-pro-features' ) ]
				);
				?>
			</div>
			<div id="osEventTicketTypesRowsWrap"<?php echo $use_ticket_types_is_on ? '' : ' style="display:none;"'; ?>>
				<div class="os-event-ticket-types-w">
					<div class="os-event-ticket-type-row os-event-ticket-type-row-header">
						<div class="os-event-ticket-type-col-name"><?php esc_html_e( 'Name', 'latepoint-pro-features' ); ?></div>
						<div class="os-event-ticket-type-col-price"><?php esc_html_e( 'Price', 'latepoint-pro-features' ); ?> <i class="latepoint-icon latepoint-icon-info os-label-tooltip-icon" data-late-tooltip="<?php esc_attr_e( 'Enter 0 for a free ticket.', 'latepoint-pro-features' ); ?>"></i></div>
						<div class="os-event-ticket-type-col-capacity"><?php esc_html_e( 'Capacity', 'latepoint-pro-features' ); ?> <i class="latepoint-icon latepoint-icon-info os-label-tooltip-icon" data-late-tooltip="<?php esc_attr_e( 'Leave blank for unlimited capacity.', 'latepoint-pro-features' ); ?>"></i></div>
						<div class="os-event-ticket-type-col-actions"></div>
					</div>
					<div class="os-event-ticket-types-rows">
						<?php
						foreach ( $types as $index => $type ) {
							include LATEPOINT_ADDON_PRO_VIEWS_ABSPATH . 'event_ticket_types/_ticket_type_row.php';
						}
						?>
					</div>
					<template class="os-event-ticket-type-row-template">
						<?php
						$type  = new OsEventTicketTypeModel();
						$index = '__INDEX__';
						include LATEPOINT_ADDON_PRO_VIEWS_ABSPATH . 'event_ticket_types/_ticket_type_row.php';
						?>
					</template>
					<button type="button" class="latepoint-btn latepoint-btn-outline os-add-ticket-type-row-btn">
						<i class="latepoint-icon latepoint-icon-plus"></i>
						<span><?php esc_html_e( 'Add Ticket Type', 'latepoint-pro-features' ); ?></span>
					</button>
				</div>
			</div>
		<?php endif; ?>
	</div>
</div>
