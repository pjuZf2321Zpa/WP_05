<?php
/**
 * WP JobSearch — Cache Plugin Compatibility
 *
 * Makes the plugin behave correctly when a page cache (WP Rocket, W3 Total
 * Cache, WP Super Cache, LiteSpeed Cache) or an object cache (Redis /
 * Memcached) is installed.
 *
 * Strategy:
 *   - Per-user dynamic pages (dashboard, login, job application, my-resume)
 *     emit `DONOTCACHEPAGE` and `nocache_headers()` so cache plugins skip
 *     them rather than serving one user's view to another.
 *   - Every jobsearch_* AJAX response carries no-cache headers so it is not
 *     stored by browsers, reverse proxies, or page-cache layers.
 *   - A lightweight `jobsearch_refresh_nonce` endpoint returns a fresh
 *     nonce. The companion inline JS calls it whenever a jobsearch AJAX
 *     request returns 403/-1 (the classic "page was served from cache; its
 *     embedded nonce has expired" failure mode) and retries the request.
 *   - Plugin-specific exclusion filters/actions for the major cache plugins
 *     give explicit signals beyond the generic constants.
 *   - Short-lived per-request data is grouped under a non-persistent object
 *     cache group so it does not pollute Redis/Memcached.
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('Jobsearch_Cache_Compat')) {

    class Jobsearch_Cache_Compat
    {

        /**
         * Shortcodes whose presence on a page marks it as per-user dynamic.
         */
        protected $dynamic_shortcodes = array(
            'jobsearch_user_dashboard',
            'jobsearch_login_registration',
            'jobsearch_apply_job_form',
            'jobsearch_user_job',
            'jobsearch_my_resume',
            'jobsearch_my_jobs',
            'jobsearch_user_packages',
            'jobsearch_user_transactions',
        );

        /**
         * Post types whose save/trash/delete should invalidate plugin caches
         * and trigger a page-cache purge.
         */
        protected $invalidating_post_types = array(
            'job',
            'employer',
            'candidate',
            'package',
        );

        /**
         * Plugin-wide aggregate transients that are no longer valid as soon
         * as any post of an invalidating post type changes. Keys ending in
         * `*` are treated as prefixes and matched via SQL DELETE.
         */
        protected $aggregate_transients = array(
            'jobsearch_sectors_realcount_cache',
            'jobsearch_update_emps_totjobs',
            'jobsearch_internal_applics_counts_time',
        );

        public function __construct()
        {
            // Frontend: mark dynamic pages as uncacheable before any output.
            add_action('template_redirect', array($this, 'mark_dynamic_pages_uncacheable'), 1);

            // AJAX: every jobsearch_* response is per-user; never cache it.
            add_action('init', array($this, 'mark_ajax_uncacheable'), 1);

            // Refresh-nonce endpoint (logged-in + nopriv so cached login pages
            // can recover too).
            add_action('wp_ajax_jobsearch_refresh_nonce', array($this, 'refresh_nonce'));
            add_action('wp_ajax_nopriv_jobsearch_refresh_nonce', array($this, 'refresh_nonce'));

            // Inline JS that drives the refresh on 403 / -1.
            add_action('wp_enqueue_scripts', array($this, 'enqueue_nonce_refresh_js'), 99);

            // WP Rocket
            add_filter('rocket_cache_reject_uri', array($this, 'wp_rocket_reject_uris'));
            add_filter('rocket_cache_reject_cookies', array($this, 'wp_rocket_reject_cookies'));

            // LiteSpeed Cache
            add_action('template_redirect', array($this, 'litespeed_mark_private'), 2);

            // W3 Total Cache and WP Super Cache honour `DONOTCACHEPAGE`,
            // already set in mark_dynamic_pages_uncacheable().

            // Object cache groups
            add_action('init', array($this, 'register_object_cache_groups'), 1);

            // Cache invalidation on content change. Fires for create / update /
            // status change / trash / delete on every invalidating post type.
            add_action('save_post', array($this, 'invalidate_on_save'), 20, 3);
            add_action('wp_trash_post', array($this, 'invalidate_on_post_id'), 20);
            add_action('untrash_post', array($this, 'invalidate_on_post_id'), 20);
            add_action('before_delete_post', array($this, 'invalidate_on_post_id'), 20);
            add_action('transition_post_status', array($this, 'invalidate_on_status_transition'), 20, 3);
        }

        /**
         * Apply the no-cache markers to dynamic per-user pages so page-cache
         * plugins do not store or serve them.
         */
        public function mark_dynamic_pages_uncacheable()
        {
            if (is_admin() || (defined('DOING_AJAX') && DOING_AJAX) || (defined('DOING_CRON') && DOING_CRON)) {
                return;
            }
            if (!$this->is_dynamic_page()) {
                return;
            }
            $this->emit_nocache_directives();
        }

        /**
         * Send `nocache_headers()` for every jobsearch_* AJAX call so the
         * response itself is not cached by browsers, CDNs, or reverse proxies.
         */
        public function mark_ajax_uncacheable()
        {
            if (!defined('DOING_AJAX') || !DOING_AJAX) {
                return;
            }
            $action = isset($_REQUEST['action']) ? sanitize_key(wp_unslash($_REQUEST['action'])) : '';
            if ($action !== '' && strpos($action, 'jobsearch_') === 0) {
                nocache_headers();
                if (!defined('DONOTCACHEPAGE')) {
                    define('DONOTCACHEPAGE', true);
                }
            }
        }

        /**
         * Issue a fresh `jobsearch_ajax_nonce`. Called from the JS layer when
         * a cached page's inline nonce stops verifying.
         */
        public function refresh_nonce()
        {
            nocache_headers();
            wp_send_json(array(
                'nonce'     => wp_create_nonce('jobsearch_ajax_nonce'),
                'logged_in' => is_user_logged_in() ? 1 : 0,
                'ts'        => time(),
            ));
        }

        /**
         * Decide whether the current page should be excluded from page cache.
         * Filterable so a theme/child plugin can add more shortcodes.
         */
        protected function is_dynamic_page()
        {
            $is_dynamic = false;

            if (is_user_logged_in()) {
                global $post;
                if (is_singular() && isset($post->post_content) && $post->post_content !== '') {
                    foreach ($this->dynamic_shortcodes as $sc) {
                        if (has_shortcode($post->post_content, $sc)) {
                            $is_dynamic = true;
                            break;
                        }
                    }
                }
                if (!$is_dynamic && is_page()) {
                    $page_template = $post && isset($post->ID) ? get_post_meta($post->ID, '_wp_page_template', true) : '';
                    if ($page_template && strpos($page_template, 'jobsearch') !== false) {
                        $is_dynamic = true;
                    }
                }
            }

            global $post;
            if (!$is_dynamic && isset($post->post_content) && $post->post_content !== '') {
                if (has_shortcode($post->post_content, 'jobsearch_login_registration')
                    || has_shortcode($post->post_content, 'jobsearch_apply_job_form')) {
                    $is_dynamic = true;
                }
            }

            return (bool) apply_filters('jobsearch_cache_compat_is_dynamic_page', $is_dynamic, $post);
        }

        /**
         * Set the canonical DONOTCACHE* constants and send no-cache headers.
         */
        protected function emit_nocache_directives()
        {
            if (!defined('DONOTCACHEPAGE')) {
                define('DONOTCACHEPAGE', true);
            }
            if (!defined('DONOTCACHEDB')) {
                define('DONOTCACHEDB', true);
            }
            if (!defined('DONOTCACHEOBJECT')) {
                define('DONOTCACHEOBJECT', true);
            }
            if (!headers_sent()) {
                nocache_headers();
            }
        }

        /**
         * Inline JS bound to jobsearch-plugin-common: detects cached-page
         * nonce failures, refreshes the nonce, and retries the original
         * jQuery AJAX request once.
         */
        public function enqueue_nonce_refresh_js()
        {
            if (!wp_script_is('jobsearch-plugin-common', 'enqueued') && !wp_script_is('jobsearch-plugin-common', 'registered')) {
                return;
            }
            $endpoint = esc_url_raw(admin_url('admin-ajax.php'));
            $inline = "(function(\$){\n"
                . "if (typeof \$ === 'undefined' || typeof \$.ajaxSetup !== 'function') { return; }\n"
                . "var endpoint = " . wp_json_encode($endpoint) . ";\n"
                . "var refreshing = false;\n"
                . "function refresh(cb){ if (refreshing) { return; } refreshing = true;\n"
                . "  \$.post(endpoint, { action: 'jobsearch_refresh_nonce' }).done(function(r){\n"
                . "    if (r && r.nonce && typeof jobsearch_comon_script_vars === 'object') {\n"
                . "      jobsearch_comon_script_vars.nonce = r.nonce;\n"
                . "    }\n"
                . "  }).always(function(){ refreshing = false; if (typeof cb === 'function') { cb(); } });\n"
                . "}\n"
                . "// Refresh every 30 minutes so long-open tabs never hit a stale nonce.\n"
                . "setInterval(refresh, 30 * 60 * 1000);\n"
                . "// Recover from cached-page nonce mismatches: retry once on -1 / 403.\n"
                . "\$(document).ajaxError(function(event, jqxhr, settings){\n"
                . "  if (!settings || !settings.data || typeof settings.data !== 'string') { return; }\n"
                . "  if (settings.data.indexOf('action=jobsearch_') === -1) { return; }\n"
                . "  if (settings.data.indexOf('action=jobsearch_refresh_nonce') !== -1) { return; }\n"
                . "  if (settings._jobsearch_retried) { return; }\n"
                . "  var status = jqxhr.status, body = jqxhr.responseText || '';\n"
                . "  var looks_like_nonce_failure = (status === 403) || (status === 200 && (body === '-1' || body === '0'));\n"
                . "  if (!looks_like_nonce_failure) { return; }\n"
                . "  refresh(function(){\n"
                . "    var newNonce = (typeof jobsearch_comon_script_vars === 'object') ? jobsearch_comon_script_vars.nonce : '';\n"
                . "    if (!newNonce) { return; }\n"
                . "    settings.data = settings.data.replace(/(_nonce|nonce)=[^&]*/g, function(m){ return m.split('=')[0] + '=' + encodeURIComponent(newNonce); });\n"
                . "    settings._jobsearch_retried = true;\n"
                . "    \$.ajax(settings);\n"
                . "  });\n"
                . "});\n"
                . "})(jQuery);";
            wp_add_inline_script('jobsearch-plugin-common', $inline);
        }

        /**
         * WP Rocket: URL patterns that should never be cached. The
         * DONOTCACHEPAGE constant is the primary gate; this is a belt-and-
         * braces filter for installs whose dashboard slug is well-known.
         */
        public function wp_rocket_reject_uris($urls)
        {
            $urls[] = '/(.+/)?user-dashboard(/.*)?';
            $urls[] = '/(.+/)?my-dashboard(/.*)?';
            $urls[] = '/(.+/)?employer-dashboard(/.*)?';
            $urls[] = '/(.+/)?candidate-dashboard(/.*)?';
            $urls[] = '/(.+/)?apply-job(/.*)?';
            $urls[] = '/(.+/)?my-resume(/.*)?';
            $urls[] = '/(.+/)?login-register(/.*)?';
            return $urls;
        }

        /**
         * WP Rocket: cookies whose presence should bypass page cache. These
         * cookies are set during application/social-login flows; their
         * existence means the visitor is mid-transaction.
         */
        public function wp_rocket_reject_cookies($cookies)
        {
            $cookies[] = 'jobsearch_email_apply_job_';
            $cookies[] = 'jobsearch_apply_';
            $cookies[] = 'jobsearch_google_state';
            $cookies[] = 'jobsearch_fb_state';
            $cookies[] = 'jobsearch_apply_google_jobid';
            $cookies[] = 'jobsearch_apply_fb_jobid';
            return $cookies;
        }

        /**
         * LiteSpeed Cache: mark dynamic jobsearch pages as private (per-user)
         * rather than public, so its page-cache layer keys correctly.
         */
        public function litespeed_mark_private()
        {
            if (is_admin() || (defined('DOING_AJAX') && DOING_AJAX)) {
                return;
            }
            if ($this->is_dynamic_page()) {
                do_action('litespeed_control_set_private', 'wp-jobsearch dynamic page');
                do_action('litespeed_control_set_nocache', 'wp-jobsearch dynamic page');
            }
        }

        /**
         * Register an object-cache group for per-request scratch data so the
         * object-cache layer (Redis/Memcached) does not persist transient
         * helpers across requests.
         */
        public function register_object_cache_groups()
        {
            if (function_exists('wp_cache_add_non_persistent_groups')) {
                wp_cache_add_non_persistent_groups(array(
                    'jobsearch_request',
                ));
            }
        }

        /**
         * save_post handler. Ignores autosaves, revisions, and post types we
         * don't care about, then delegates to invalidate_for_post().
         */
        public function invalidate_on_save($post_id, $post, $update)
        {
            if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
                return;
            }
            if (wp_is_post_revision($post_id) || wp_is_post_autosave($post_id)) {
                return;
            }
            if (!isset($post->post_type) || !in_array($post->post_type, $this->invalidating_post_types, true)) {
                return;
            }
            $this->invalidate_for_post($post_id, $post->post_type);
        }

        /**
         * Hooked on trash / untrash / before_delete. Looks up post type by id.
         */
        public function invalidate_on_post_id($post_id)
        {
            $post_type = get_post_type($post_id);
            if (!$post_type || !in_array($post_type, $this->invalidating_post_types, true)) {
                return;
            }
            $this->invalidate_for_post($post_id, $post_type);
        }

        /**
         * transition_post_status fires for publish/unpublish/draft etc. and
         * is the right signal for listing-cache invalidation even when no
         * post fields changed.
         */
        public function invalidate_on_status_transition($new_status, $old_status, $post)
        {
            if ($new_status === $old_status) {
                return;
            }
            if (!isset($post->post_type) || !in_array($post->post_type, $this->invalidating_post_types, true)) {
                return;
            }
            $this->invalidate_for_post($post->ID, $post->post_type);
        }

        /**
         * Central invalidation routine. Idempotent — safe to call multiple
         * times for the same post during one request.
         *
         * Order:
         *   1. Delete plugin-wide aggregate transients (listing/count caches).
         *   2. Delete the WP core post + post_meta object-cache entries.
         *   3. Purge listings/archives in the major page-cache plugins.
         *   4. Fire `jobsearch_cache_invalidate` for extensions.
         */
        protected function invalidate_for_post($post_id, $post_type)
        {
            $post_id = (int) $post_id;
            if ($post_id <= 0) {
                return;
            }

            // De-dup per request: don't re-run for the same post in one cycle.
            static $done = array();
            $key = $post_type . ':' . $post_id;
            if (isset($done[$key])) {
                return;
            }
            $done[$key] = true;

            // 1. Plugin aggregate transients.
            foreach ($this->aggregate_transients as $name) {
                delete_transient($name);
            }
            // Per-post-type aggregates that may be added later.
            $extra_transients = apply_filters(
                'jobsearch_cache_invalidate_transients',
                array(),
                $post_id,
                $post_type
            );
            foreach ((array) $extra_transients as $name) {
                if (is_string($name) && $name !== '') {
                    delete_transient($name);
                }
            }

            // 2. WP core post/post_meta caches.
            clean_post_cache($post_id);

            // Object-cache: drop any explicit per-post buckets we use.
            wp_cache_delete($post_id, 'jobsearch_post_meta');
            wp_cache_delete($post_type . '_listing', 'jobsearch_listings');

            // 3. Page-cache plugin purges.
            $this->purge_page_cache_for_post($post_id, $post_type);

            // 4. Extension hook.
            do_action('jobsearch_cache_invalidate', $post_id, $post_type);
        }

        /**
         * Tell each supported page-cache plugin to drop its cached HTML for
         * this post and (where supported) the archive/listing pages that
         * reference it. Each call is wrapped in function_exists so missing
         * plugins are no-ops.
         */
        protected function purge_page_cache_for_post($post_id, $post_type)
        {
            // WP Rocket — purge the single post page, plus full cache if the
            // post is a listing-bearing type (job/employer/candidate listings
            // can appear on many pages, so a targeted purge isn't reliable).
            if (function_exists('rocket_clean_post')) {
                rocket_clean_post($post_id);
            }
            if (function_exists('rocket_clean_home')) {
                rocket_clean_home();
            }

            // W3 Total Cache
            if (function_exists('w3tc_pgcache_flush_post')) {
                w3tc_pgcache_flush_post($post_id);
            }
            if (function_exists('w3tc_flush_post')) {
                w3tc_flush_post($post_id);
            }

            // WP Super Cache
            if (function_exists('wp_cache_post_change')) {
                wp_cache_post_change($post_id);
            }
            if (function_exists('wp_cache_post_id_gc')) {
                $permalink = get_permalink($post_id);
                if ($permalink) {
                    wp_cache_post_id_gc($permalink, $post_id);
                }
            }

            // LiteSpeed Cache — public hook signal.
            do_action('litespeed_purge_post', $post_id);
            do_action('litespeed_purge', 'pt_' . $post_type);

            // Cache Enabler
            if (class_exists('Cache_Enabler') && method_exists('Cache_Enabler', 'clear_page_cache_by_post')) {
                call_user_func(array('Cache_Enabler', 'clear_page_cache_by_post'), $post_id);
            }

            // Hummingbird
            do_action('wphb_clear_page_cache', $post_id);

            // SG Optimizer (SiteGround)
            if (function_exists('sg_cachepress_purge_cache')) {
                sg_cachepress_purge_cache(get_permalink($post_id));
            }
        }
    }

    new Jobsearch_Cache_Compat();
}
