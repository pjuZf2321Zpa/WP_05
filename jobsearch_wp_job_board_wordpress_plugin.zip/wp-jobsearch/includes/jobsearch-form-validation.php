<?php
/**
 * Server-side required-field helpers for front-end dashboard forms.
 *
 * Mirrors the client-side jobsearchValidateRequired() helper in
 * js/jobsearch-common.js: each form's PHP handler declares its required
 * fields as `[ post_key => translated_label ]` and calls
 * jobsearch_check_required_post_fields(). Missing fields can then be
 * surfaced through the existing inline-errors UX and a top-right
 * jobsearchAlert toast emitted on the post-back render.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! function_exists( 'jobsearch_check_required_post_fields' ) ) {

    /**
     * Walk a $required_map and return the list of labels whose backing
     * source value is empty (after trimming whitespace).
     *
     * @param array $source        Usually $_POST. Read-only.
     * @param array $required_map  [ 'post_key' => 'Translated Label', ... ]
     *                             A label of '' is skipped (caller opted out).
     * @return string[]            Labels of fields whose source value was empty.
     *                             Empty array means all required fields present.
     */
    function jobsearch_check_required_post_fields( $source, $required_map ) {
        if ( ! is_array( $source ) || ! is_array( $required_map ) ) {
            return array();
        }
        $missing = array();
        foreach ( $required_map as $key => $label ) {
            if ( $label === '' ) {
                continue;
            }
            $val = isset( $source[ $key ] ) ? $source[ $key ] : '';
            if ( is_array( $val ) ) {
                // For multi-value fields (checkbox groups, multi-selects),
                // strip empty entries before deciding.
                $val = array_values( array_filter( $val, function ( $v ) {
                    return $v !== '' && $v !== null;
                } ) );
                if ( empty( $val ) ) {
                    $missing[] = (string) $label;
                }
                continue;
            }
            if ( trim( (string) $val ) === '' ) {
                $missing[] = (string) $label;
            }
        }
        return $missing;
    }
}

if ( ! function_exists( 'jobsearch_queue_required_fields_toast' ) ) {

    /**
     * Queue a "Required fields: A, B, C" toast for the next page render.
     *
     * Settings forms are not AJAX — they POST to the same URL, the PHP
     * handler runs at the top of the page, then the template re-renders.
     * Storing the missing labels in a request-scoped global lets a single
     * wp_footer action emit the inline jobsearchAlert() script at the
     * bottom of the rendered page.
     *
     * @param string[] $missing_labels
     * @return void
     */
    function jobsearch_queue_required_fields_toast( $missing_labels ) {
        if ( empty( $missing_labels ) || ! is_array( $missing_labels ) ) {
            return;
        }
        global $jobsearch_required_fields_toast;
        if ( ! is_array( $jobsearch_required_fields_toast ) ) {
            $jobsearch_required_fields_toast = array();
        }
        foreach ( $missing_labels as $lbl ) {
            $lbl = trim( (string) $lbl );
            if ( $lbl === '' ) {
                continue;
            }
            if ( ! in_array( $lbl, $jobsearch_required_fields_toast, true ) ) {
                $jobsearch_required_fields_toast[] = $lbl;
            }
        }
        if ( ! has_action( 'wp_footer', 'jobsearch_emit_required_fields_toast' ) ) {
            add_action( 'wp_footer', 'jobsearch_emit_required_fields_toast', 99 );
        }
    }
}

if ( ! function_exists( 'jobsearch_emit_required_fields_toast' ) ) {

    /**
     * Emit the inline jobsearchAlert() script at wp_footer if a previous
     * server-side validation failure queued missing labels.
     *
     * @return void
     */
    function jobsearch_emit_required_fields_toast() {
        global $jobsearch_required_fields_toast;
        if ( empty( $jobsearch_required_fields_toast ) || ! is_array( $jobsearch_required_fields_toast ) ) {
            return;
        }
        // PHP-side labels come from each form handler's hardcoded
        // $required_map, so unlike the JS path they're always clean and
        // translated. List them in the toast.
        $cap          = 6;
        $labels       = array_values( array_unique( array_filter( array_map( 'strval', $jobsearch_required_fields_toast ) ) ) );
        if ( empty( $labels ) ) {
            return;
        }
        $shown        = array_slice( $labels, 0, $cap );
        $remainder    = count( $labels ) - count( $shown );
        $prefix       = esc_html__( 'Required fields: ', 'wp-jobsearch' );
        $more_template = esc_html__( ' and %d more', 'wp-jobsearch' );

        $message = $prefix . implode( ', ', array_map( 'esc_html', $shown ) );
        if ( $remainder > 0 ) {
            $message .= sprintf( $more_template, (int) $remainder );
        }

        $message_for_js = wp_json_encode( $message );
        if ( ! is_string( $message_for_js ) ) {
            return;
        }
        ?>
        <script>
        (function () {
            function fire() {
                if (window.jobsearchAlert) {
                    window.jobsearchAlert('error', <?php echo $message_for_js; // phpcs:ignore — already JSON-encoded ?>);
                }
            }
            if (document.readyState === 'complete' || document.readyState === 'interactive') {
                fire();
            } else {
                document.addEventListener('DOMContentLoaded', fire);
            }
        })();
        </script>
        <?php
        $jobsearch_required_fields_toast = array();
    }
}
