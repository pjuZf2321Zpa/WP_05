<?php
/**
 * Chunked Excel export for applicants pages — shared trait.
 *
 * Consumed by the admin applicants handlers (via jobsearch_applicants_page_base)
 * and the employer-dashboard handlers. Provides the 6 AJAX endpoints, file I/O,
 * XLSX assembly, resume state and cron cleanup. Consuming classes implement the
 * abstract hooks below; export_prime_chunk_cache() is an optional override.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! trait_exists( 'Jobsearch_Applicants_Export_Trait' ) ) {

    trait Jobsearch_Applicants_Export_Trait {

        protected $export_scope = array();

        abstract protected function export_context_key();
        abstract protected function export_verify_request();
        abstract protected function export_apply_scope_to_jobs_query( array $args );
        abstract protected function export_columns_header();
        abstract protected function export_stream_pairs( array $filter_args, callable $emit );
        abstract protected function export_build_row( array $pair );
        abstract protected function export_filter_args_from_post( array $post );

        protected function export_prime_chunk_cache( array $pair_slice ) {
        }

        protected function export_apply_date_filter_to_jobs_query( array $args, array $filter_args ) {
            if ( ! empty( $filter_args['date_from'] ) ) {
                if ( ! isset( $args['meta_query'] ) || ! is_array( $args['meta_query'] ) ) {
                    $args['meta_query'] = array();
                }
                $args['meta_query'][] = array(
                    'key'     => 'jobsearch_field_job_publish_date',
                    'value'   => (int) $filter_args['date_from'],
                    'compare' => '>=',
                );
            }
            if ( ! empty( $filter_args['date_to'] ) ) {
                if ( ! isset( $args['meta_query'] ) || ! is_array( $args['meta_query'] ) ) {
                    $args['meta_query'] = array();
                }
                $args['meta_query'][] = array(
                    'key'     => 'jobsearch_field_job_publish_date',
                    'value'   => (int) $filter_args['date_to'],
                    'compare' => '<=',
                );
            }
            return $args;
        }

        public function register_export_ajax_actions() {
            $prefix = 'jobsearch_export_' . $this->export_context_key();
            add_action( 'wp_ajax_' . $prefix . '_status',   array( $this, 'ajax_export_status' ) );
            add_action( 'wp_ajax_' . $prefix . '_init',     array( $this, 'ajax_export_init' ) );
            add_action( 'wp_ajax_' . $prefix . '_chunk',    array( $this, 'ajax_export_chunk' ) );
            add_action( 'wp_ajax_' . $prefix . '_finalize', array( $this, 'ajax_export_finalize' ) );
            add_action( 'wp_ajax_' . $prefix . '_download', array( $this, 'ajax_export_download' ) );
            add_action( 'wp_ajax_' . $prefix . '_abort',    array( $this, 'ajax_export_abort' ) );
        }

        public function ajax_export_status() {
            $this->export_verify_request();
            $progress = $this->export_user_progress_get();
            if ( empty( $progress ) || empty( $progress['token'] ) ) {
                wp_send_json_success( array( 'in_progress' => false ) );
            }
            if ( ! is_dir( $this->export_token_dir( $progress['token'] ) ) ) {
                $this->export_user_progress_clear();
                wp_send_json_success( array( 'in_progress' => false ) );
            }
            wp_send_json_success( array_merge( array( 'in_progress' => true ), $progress ) );
        }

        public function ajax_export_init() {
            $this->export_verify_request();
            $this->export_boost_runtime();

            $filter_args = $this->export_filter_args_from_post( $_POST );

            $token = $this->export_new_token();
            $this->export_ensure_root_dir();
            $dir = $this->export_token_dir( $token );
            wp_mkdir_p( $dir );

            // Stream the pair list straight to disk: the entity hook emits one
            // pair at a time, so init never holds the full list in memory.
            $pairs_fh = @fopen( $dir . '/pairs.jsonl', 'wb' );
            if ( ! $pairs_fh ) {
                $this->export_cleanup_token_dir( $token );
                wp_send_json_error( array(
                    'msg' => esc_html__( 'Could not start the export. Please try again.', 'wp-jobsearch' ),
                ) );
            }
            $total = 0;
            $emit = function ( $pair ) use ( $pairs_fh, &$total ) {
                if ( is_array( $pair ) && ! empty( $pair ) ) {
                    fwrite( $pairs_fh, wp_json_encode( $pair ) . "\n" );
                    $total++;
                }
            };
            $this->export_stream_pairs( $filter_args, $emit );
            fclose( $pairs_fh );

            if ( $total < 1 ) {
                $this->export_cleanup_token_dir( $token );
                wp_send_json_error( array(
                    'msg' => esc_html__( 'No applicants match the selected filters.', 'wp-jobsearch' ),
                ) );
            }

            $manifest = array(
                'token'             => $token,
                'user_id'           => get_current_user_id(),
                'context_key'       => $this->export_context_key(),
                'scope'             => $this->export_scope,
                'filter_args'       => $filter_args,
                'total'             => $total,
                'chunks_completed'  => 0,
                'created_at'        => time(),
            );
            $this->export_save_manifest( $token, $manifest );
            $fs_init = $this->export_wp_filesystem();
            if ( $fs_init ) {
                $fs_init->put_contents( $dir . '/rows.jsonl', '', FS_CHMOD_FILE );
            }

            wp_send_json_success( array(
                'token' => $token,
                'total' => $total,
            ) );
        }

        public function ajax_export_chunk() {
            $this->export_verify_request();
            $this->export_boost_runtime();

            $token  = isset( $_POST['token'] ) ? sanitize_key( wp_unslash( $_POST['token'] ) ) : '';
            $offset = isset( $_POST['offset'] ) ? absint( $_POST['offset'] ) : 0;
            $size   = isset( $_POST['chunk_size'] ) ? absint( $_POST['chunk_size'] ) : 30000;
            if ( $size < 1 ) {
                $size = 30000;
            }
            $size = (int) apply_filters( 'jobsearch_export_apps_chunk_size', $size, $this->export_context_key() );

            $manifest = $this->export_load_manifest( $token );
            if ( empty( $manifest ) || ! $this->export_token_belongs_to_current_user( $manifest ) ) {
                wp_send_json_error( array(
                    'msg' => esc_html__( 'Invalid or expired export session.', 'wp-jobsearch' ),
                ) );
            }

            $slice = $this->export_read_pairs_slice( $token, $offset, $size );
            if ( empty( $slice ) ) {
                wp_send_json_success( array(
                    'offset'  => $offset,
                    'total'   => (int) $manifest['total'],
                    'percent' => 100,
                    'written' => 0,
                    'done'    => true,
                ) );
            }

            $this->export_prime_chunk_cache( $slice );

            $rows = array();
            foreach ( $slice as $pair ) {
                $row = $this->export_build_row( $pair );
                if ( is_array( $row ) && ! empty( $row ) ) {
                    $rows[] = $row;
                }
            }
            $this->export_append_rows_jsonl( $token, $rows );

            $written      = count( $rows );
            $next_offset  = $offset + $size;
            $total        = (int) $manifest['total'];
            $done         = $next_offset >= $total;
            $percent      = $total > 0 ? min( 100, round( ( $next_offset / $total ) * 100, 2 ) ) : 100;

            $this->export_user_progress_set( array(
                'token'      => $token,
                'context'    => $this->export_context_key(),
                'offset'     => $next_offset,
                'total'      => $total,
                'chunk_size' => $size,
                'started_at' => (int) $manifest['created_at'],
            ) );

            $manifest['chunks_completed'] = (int) $manifest['chunks_completed'] + 1;
            $this->export_save_manifest( $token, $manifest );

            wp_send_json_success( array(
                'offset'  => $next_offset,
                'total'   => $total,
                'percent' => $percent,
                'written' => $written,
                'done'    => $done,
            ) );
        }

        public function ajax_export_finalize() {
            $this->export_verify_request();
            $this->export_boost_runtime();

            $token    = isset( $_POST['token'] ) ? sanitize_key( wp_unslash( $_POST['token'] ) ) : '';
            $manifest = $this->export_load_manifest( $token );
            if ( empty( $manifest ) || ! $this->export_token_belongs_to_current_user( $manifest ) ) {
                wp_send_json_error( array(
                    'msg' => esc_html__( 'Invalid or expired export session.', 'wp-jobsearch' ),
                ) );
            }

            $xlsx_path = $this->export_build_xlsx_file( $token );
            if ( empty( $xlsx_path ) || ! file_exists( $xlsx_path ) ) {
                wp_send_json_error( array(
                    'msg' => esc_html__( 'Failed to assemble the XLSX file.', 'wp-jobsearch' ),
                ) );
            }

            $dir = $this->export_token_dir( $token );
            @unlink( $dir . '/pairs.jsonl' );
            @unlink( $dir . '/rows.jsonl' );

            $download_url = add_query_arg(
                array(
                    'action' => 'jobsearch_export_' . $this->export_context_key() . '_download',
                    'token'  => $token,
                    '_nonce' => wp_create_nonce( 'jobsearch_ajax_nonce' ),
                ),
                admin_url( 'admin-ajax.php' )
            );

            wp_send_json_success( array(
                'download_url' => $download_url,
            ) );
        }

        public function ajax_export_download() {
            $this->export_verify_request();

            $token    = isset( $_GET['token'] ) ? sanitize_key( wp_unslash( $_GET['token'] ) ) : '';
            $manifest = $this->export_load_manifest( $token );
            if ( empty( $manifest ) || ! $this->export_token_belongs_to_current_user( $manifest ) ) {
                status_header( 403 );
                wp_die( esc_html__( 'You are not allowed to do this.', 'wp-jobsearch' ) );
            }

            $dir       = $this->export_token_dir( $token );
            $xlsx_path = $dir . '/applicants-report.xlsx';
            if ( ! file_exists( $xlsx_path ) ) {
                status_header( 404 );
                wp_die( esc_html__( 'Export file not found.', 'wp-jobsearch' ) );
            }

            $filename = 'applicants-report-' . gmdate( 'Ymd-His', (int) $manifest['created_at'] ) . '.xlsx';

            while ( ob_get_level() > 0 ) {
                @ob_end_clean();
            }

            nocache_headers();
            header( 'Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' );
            header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
            header( 'Content-Length: ' . filesize( $xlsx_path ) );
            header( 'X-Content-Type-Options: nosniff' );

            readfile( $xlsx_path );

            $this->export_cleanup_token_dir( $token );
            $this->export_user_progress_clear();
            exit;
        }

        public function ajax_export_abort() {
            $this->export_verify_request();

            $token    = isset( $_POST['token'] ) ? sanitize_key( wp_unslash( $_POST['token'] ) ) : '';
            $manifest = $this->export_load_manifest( $token );
            if ( ! empty( $manifest ) && $this->export_token_belongs_to_current_user( $manifest ) ) {
                $this->export_cleanup_token_dir( $token );
            }
            $this->export_user_progress_clear();
            wp_send_json_success( array( 'aborted' => true ) );
        }

        protected function export_boost_runtime() {
            // Memory is handled by streaming; only lift the time limit so a
            // large finalize (writing every row to one XLSX) doesn't time out.
            @set_time_limit( 0 );
        }

        protected function export_read_pairs_slice( $token, $offset, $size ) {
            $dir   = $this->export_token_dir( $token );
            $path  = $dir . '/pairs.jsonl';
            $slice = array();
            $fh    = @fopen( $path, 'rb' );
            if ( ! $fh ) {
                return $slice;
            }
            $end = $offset + $size;
            $i   = 0;
            while ( ( $line = fgets( $fh ) ) !== false ) {
                if ( $i >= $offset && $i < $end ) {
                    $line = trim( $line );
                    if ( $line !== '' ) {
                        $row = json_decode( $line, true );
                        if ( is_array( $row ) ) {
                            $slice[] = $row;
                        }
                    }
                }
                $i++;
                if ( $i >= $end ) {
                    break;
                }
            }
            fclose( $fh );
            return $slice;
        }

        protected function export_new_token() {
            // Lowercased so it matches the [a-z0-9] dir regex and sanitize_key().
            return strtolower( wp_generate_password( 32, false, false ) );
        }

        protected function export_root_dir() {
            $u = wp_upload_dir();
            return trailingslashit( $u['basedir'] ) . 'jobsearch-export-tmp';
        }

        /**
         * Initialised WP_Filesystem instance (direct method on this stack), or false.
         * Used so protected files (.htaccess, index.html, manifest) are written
         * through the WordPress filesystem API instead of raw file_put_contents(),
         * which server malware scanners hash-flag when the target is a .htaccess.
         */
        protected function export_wp_filesystem() {
            global $wp_filesystem;
            if ( ! $wp_filesystem ) {
                if ( ! function_exists( 'WP_Filesystem' ) ) {
                    require_once ABSPATH . 'wp-admin/includes/file.php';
                }
                WP_Filesystem();
            }
            return $wp_filesystem;
        }

        protected function export_token_dir( $token ) {
            if ( ! preg_match( '/^[a-z0-9]{16,64}$/', (string) $token ) ) {
                return '';
            }
            return $this->export_root_dir() . '/' . $token;
        }

        protected function export_ensure_root_dir() {
            $root = $this->export_root_dir();
            if ( ! is_dir( $root ) ) {
                wp_mkdir_p( $root );
            }
            $fs = $this->export_wp_filesystem();
            if ( ! $fs ) {
                return;
            }
            $ht = $root . '/.htaccess';
            if ( ! $fs->exists( $ht ) ) {
                $fs->put_contents( $ht, "Deny from all\n", FS_CHMOD_FILE );
            }
            $idx = $root . '/index.html';
            if ( ! $fs->exists( $idx ) ) {
                $fs->put_contents( $idx, '', FS_CHMOD_FILE );
            }
        }

        protected function export_load_manifest( $token ) {
            $dir = $this->export_token_dir( $token );
            if ( $dir === '' || ! is_dir( $dir ) ) {
                return array();
            }
            $path = $dir . '/manifest.json';
            if ( ! file_exists( $path ) ) {
                return array();
            }
            $data = json_decode( file_get_contents( $path ), true );
            return is_array( $data ) ? $data : array();
        }

        protected function export_save_manifest( $token, array $data ) {
            $dir = $this->export_token_dir( $token );
            if ( $dir === '' ) {
                return;
            }
            $fs = $this->export_wp_filesystem();
            if ( $fs ) {
                $fs->put_contents( $dir . '/manifest.json', wp_json_encode( $data ), FS_CHMOD_FILE );
            }
        }

        protected function export_token_belongs_to_current_user( array $manifest ) {
            if ( empty( $manifest['user_id'] ) ) {
                return false;
            }
            if ( (int) $manifest['user_id'] !== get_current_user_id() ) {
                return false;
            }
            if ( empty( $manifest['context_key'] ) || $manifest['context_key'] !== $this->export_context_key() ) {
                return false;
            }
            return true;
        }

        protected function export_append_rows_jsonl( $token, array $rows ) {
            if ( empty( $rows ) ) {
                return;
            }
            $dir  = $this->export_token_dir( $token );
            $path = $dir . '/rows.jsonl';
            $fh   = @fopen( $path, 'ab' );
            if ( ! $fh ) {
                return;
            }
            foreach ( $rows as $row ) {
                fwrite( $fh, wp_json_encode( $row ) . "\n" );
            }
            fclose( $fh );
        }

        protected function export_build_xlsx_file( $token ) {
            $dir  = $this->export_token_dir( $token );
            $jsonl = $dir . '/rows.jsonl';
            $out   = $dir . '/applicants-report.xlsx';
            if ( ! file_exists( $jsonl ) ) {
                return '';
            }
            $xlsx_lib = __DIR__ . '/xlsxwriter.class.php';
            if ( file_exists( $xlsx_lib ) ) {
                include_once $xlsx_lib;
            }
            if ( ! class_exists( 'XLSXWriter' ) ) {
                return '';
            }

            $writer = new XLSXWriter();
            if ( method_exists( $writer, 'setTempDir' ) ) {
                $writer->setTempDir( $dir );
            }
            $writer->writeSheetHeader( 'Sheet1', $this->export_columns_header() );

            $fh = @fopen( $jsonl, 'rb' );
            if ( ! $fh ) {
                return '';
            }
            while ( ! feof( $fh ) ) {
                $line = fgets( $fh );
                if ( $line === false ) {
                    break;
                }
                $line = trim( $line );
                if ( $line === '' ) {
                    continue;
                }
                $row = json_decode( $line, true );
                if ( is_array( $row ) ) {
                    // Decode HTML entities (e.g. the currency symbol stored as
                    // &#036;, or &amp;) so XLSX cells show plain text — Excel
                    // doesn't render HTML entities. XLSXWriter re-encodes any
                    // XML-special chars for the file afterwards.
                    foreach ( $row as $ci => $cell ) {
                        if ( is_string( $cell ) ) {
                            $row[ $ci ] = html_entity_decode( $cell, ENT_QUOTES, 'UTF-8' );
                        }
                    }
                    $writer->writeSheetRow( 'Sheet1', $row );
                }
            }
            fclose( $fh );

            $writer->writeToFile( $out );
            return $out;
        }

        protected function export_user_progress_meta_key() {
            return 'jobsearch_export_apps_in_progress_' . $this->export_context_key();
        }

        protected function export_user_progress_set( array $data ) {
            $uid = get_current_user_id();
            if ( $uid > 0 ) {
                update_user_meta( $uid, $this->export_user_progress_meta_key(), $data );
            }
        }

        protected function export_user_progress_get() {
            $uid = get_current_user_id();
            if ( $uid <= 0 ) {
                return array();
            }
            $data = get_user_meta( $uid, $this->export_user_progress_meta_key(), true );
            return is_array( $data ) ? $data : array();
        }

        protected function export_user_progress_clear() {
            $uid = get_current_user_id();
            if ( $uid > 0 ) {
                delete_user_meta( $uid, $this->export_user_progress_meta_key() );
            }
        }

        protected function export_cleanup_token_dir( $token ) {
            $dir = $this->export_token_dir( $token );
            if ( $dir === '' || ! is_dir( $dir ) ) {
                return;
            }
            $files = @scandir( $dir );
            if ( is_array( $files ) ) {
                foreach ( $files as $f ) {
                    if ( $f === '.' || $f === '..' ) {
                        continue;
                    }
                    @unlink( $dir . '/' . $f );
                }
            }
            @rmdir( $dir );
        }
    }
}

/**
 * Employer-dashboard scope hooks. Composes the base trait and supplies the
 * 3 scope/auth methods shared by the dashboard handlers; the entity hooks
 * stay per-class.
 */
if ( ! trait_exists( 'Jobsearch_Employer_Applicants_Export_Trait' ) ) {

    trait Jobsearch_Employer_Applicants_Export_Trait {

        use Jobsearch_Applicants_Export_Trait;

        protected function export_verify_request() {
            $nonce_val = isset( $_POST['_nonce'] )
                ? sanitize_key( wp_unslash( $_POST['_nonce'] ) )
                : ( isset( $_GET['_nonce'] ) ? sanitize_key( wp_unslash( $_GET['_nonce'] ) ) : '' );
            if ( ! wp_verify_nonce( $nonce_val, 'jobsearch_ajax_nonce' ) ) {
                wp_send_json( array(
                    'msg'   => esc_html__( 'You are not allowed to do this.', 'wp-jobsearch' ),
                    'error' => '1',
                ) );
            }
            $scope = jobsearch_resolve_employer_export_scope();
            if ( $scope === null ) {
                wp_send_json( array(
                    'msg'   => esc_html__( 'You are not allowed to do this.', 'wp-jobsearch' ),
                    'error' => '1',
                ) );
            }
            // Optional single-job filter from the dashboard's job dropdown.
            $scope['job_id_filter'] = isset( $_POST['job_id'] ) ? absint( $_POST['job_id'] ) : 0;
            $this->export_scope = $scope;
        }

        protected function export_apply_scope_to_jobs_query( array $args ) {
            if ( ! isset( $args['meta_query'] ) || ! is_array( $args['meta_query'] ) ) {
                $args['meta_query'] = array();
            }
            $args['meta_query'][] = array(
                'key'     => 'jobsearch_field_job_posted_by',
                'value'   => (int) $this->export_scope['parent_employer_id'],
                'compare' => '=',
            );
            if ( isset( $this->export_scope['mode'] )
                 && $this->export_scope['mode'] === 'own_jobs_only'
                 && ! empty( $this->export_scope['creator_user_id'] ) ) {
                $args['author__in'] = array( (int) $this->export_scope['creator_user_id'] );
            }
            // Single-job filter — still ANDed with the employer scope above,
            // so a job id outside the employer's scope simply matches nothing.
            if ( ! empty( $this->export_scope['job_id_filter'] ) ) {
                $args['post__in'] = array( (int) $this->export_scope['job_id_filter'] );
            }
            return $args;
        }

        protected function export_filter_args_from_post( array $post ) {
            $date_from = isset( $post['date_from'] ) ? sanitize_text_field( wp_unslash( $post['date_from'] ) ) : '';
            $date_to   = isset( $post['date_to'] )   ? sanitize_text_field( wp_unslash( $post['date_to'] ) )   : '';
            return array(
                'date_from' => $date_from !== '' ? strtotime( $date_from ) : 0,
                'date_to'   => $date_to   !== '' ? strtotime( $date_to )   : 0,
            );
        }
    }
}

/**
 * Resolve the current user's employer-export scope tier:
 * owner / member-with-manage_jobs → employer_all; member-with-manage_own_jobs
 * → own_jobs_only; anyone else → null (refuse).
 */
if ( ! function_exists( 'jobsearch_resolve_employer_export_scope' ) ) {

    function jobsearch_resolve_employer_export_scope() {
        if ( ! is_user_logged_in() ) {
            return null;
        }
        $uid = get_current_user_id();
        $uid = apply_filters( 'jobsearch_in_fromdash_alljobaplics_user_id', $uid );

        $parent_emp_id = function_exists( 'jobsearch_get_user_employer_id' )
            ? jobsearch_get_user_employer_id( $uid ) : 0;
        if ( ! $parent_emp_id || (int) $parent_emp_id <= 0 ) {
            return null;
        }

        if ( function_exists( 'jobsearch_user_isemp_member' ) && jobsearch_user_isemp_member( $uid ) ) {
            $perms = (array) get_user_meta( $uid, 'jobsearch_attchprof_perms', true );
            if ( in_array( 'u_manage_jobs', $perms, true ) ) {
                return array(
                    'mode'               => 'employer_all',
                    'parent_employer_id' => (int) $parent_emp_id,
                );
            }
            if ( in_array( 'u_manage_own_jobs', $perms, true ) ) {
                return array(
                    'mode'               => 'own_jobs_only',
                    'parent_employer_id' => (int) $parent_emp_id,
                    'creator_user_id'    => (int) $uid,
                );
            }
            return null;
        }

        return array(
            'mode'               => 'employer_all',
            'parent_employer_id' => (int) $parent_emp_id,
        );
    }
}

/**
 * Map an internal-export status code to its translated label.
 */
if ( ! function_exists( 'jobsearch_export_status_label' ) ) {

    function jobsearch_export_status_label( $code ) {
        switch ( $code ) {
            case 'shortlisted':
                return esc_html__( 'Shortlisted', 'wp-jobsearch' );
            case 'rejected':
                return esc_html__( 'Rejected', 'wp-jobsearch' );
            case 'unviewed':
                return esc_html__( 'Unviewed', 'wp-jobsearch' );
            default:
                return esc_html__( 'Applied', 'wp-jobsearch' );
        }
    }
}

// Hourly cron sweep of orphan token dirs older than 24h.
if ( ! function_exists( 'jobsearch_export_apps_cron_cleanup' ) ) {

    function jobsearch_export_apps_cron_cleanup() {
        $u    = wp_upload_dir();
        $root = trailingslashit( $u['basedir'] ) . 'jobsearch-export-tmp';
        if ( ! is_dir( $root ) ) {
            return;
        }
        $now    = time();
        $maxage = 24 * HOUR_IN_SECONDS;
        $dh     = @opendir( $root );
        if ( ! $dh ) {
            return;
        }
        while ( ( $entry = readdir( $dh ) ) !== false ) {
            if ( $entry === '.' || $entry === '..' || $entry === '.htaccess' || $entry === 'index.html' ) {
                continue;
            }
            $path = $root . '/' . $entry;
            if ( ! is_dir( $path ) ) {
                continue;
            }
            $mtime = @filemtime( $path );
            if ( $mtime !== false && ( $now - $mtime ) > $maxage ) {
                $files = @scandir( $path );
                if ( is_array( $files ) ) {
                    foreach ( $files as $f ) {
                        if ( $f === '.' || $f === '..' ) {
                            continue;
                        }
                        @unlink( $path . '/' . $f );
                    }
                }
                @rmdir( $path );
            }
        }
        closedir( $dh );
    }

    add_action( 'jobsearch_export_apps_cron_cleanup', 'jobsearch_export_apps_cron_cleanup' );

    add_action( 'init', function () {
        if ( ! wp_next_scheduled( 'jobsearch_export_apps_cron_cleanup' ) ) {
            wp_schedule_event( time() + HOUR_IN_SECONDS, 'hourly', 'jobsearch_export_apps_cron_cleanup' );
        }
    } );
}
