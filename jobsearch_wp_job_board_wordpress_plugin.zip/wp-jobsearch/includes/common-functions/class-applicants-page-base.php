<?php
if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('jobsearch_applicants_page_base')) {

    /**
     * Shared base for the 3 admin "Applicants" admin pages (Internal /
     * Email / External). Centralises the 3 AJAX handlers that were
     * duplicated nearly verbatim across all three classes:
     *
     *   - load_more_apswith_job_apps  (paginated jobs list)
     *   - load_more_apswith_apps_lis  (paginated applicants for one job)
     *   - load_single_apswith_job_inlist (single-job render)
     *
     * Each subclass plugs into 4 small extension points:
     *   - required_capability()      capability gate (default manage_options)
     *   - args_filter_hook()         WP filter name applied to $args
     *   - extra_meta_query()         optional meta_query clauses
     *   - run_jobs_query()           how to materialise jobs from $args
     *
     * Auth (nonce + capability) is enforced in one place so the 3 pages
     * cannot drift apart again. Public method names and AJAX action
     * registrations on the subclasses are unchanged, so any addon that
     * hooks `wp_ajax_jobsearch_*` continues to work.
     */
    abstract class jobsearch_applicants_page_base {

        // ---- extension points --------------------------------------------

        /**
         * Capability that admin AJAX callers must hold. Default matches
         * the Email page's historical gate; subclasses can tighten.
         */
        protected function required_capability() {
            return 'manage_options';
        }

        /**
         * Filter applied to the WP_Query args before the jobs query runs.
         * Existing addons hook `jobsearch_bk_all_emailapplics_queryargs`
         * (Email + External) or `jobsearch_bk_all_applics_queryargs`
         * (Internal). Return whichever your page used historically.
         */
        abstract protected function args_filter_hook();

        /**
         * meta_query rows to merge into the default jobs args. Use this
         * for an EXISTS clause when the page is keyed off a meta key
         * (e.g. External uses `jobsearch_external_job_apply_data`).
         */
        protected function extra_meta_query() {
            return array();
        }

        /**
         * Materialise the page-of-jobs from $args. Default is a plain
         * WP_Query. Override when the page needs JOIN/WHERE filters
         * (Email page) or a hand-built SQL wrapper (Internal page).
         *
         * @return int[] post IDs
         */
        protected function run_jobs_query($args, $page_num) {
            $jobs_query = new WP_Query($args);
            return $jobs_query->posts;
        }

        /**
         * Default: the From/To date pickers map to the job's publish-date
         * meta. Email page overrides this to stash the values in globals
         * its posts_join/posts_where filters read.
         */
        protected function apply_date_filters(&$args, $applied_from, $applied_to) {
            if ($applied_from > 0) {
                $args['meta_query'][] = array(
                    'key' => 'jobsearch_field_job_publish_date',
                    'value' => $applied_from,
                    'compare' => '>=',
                );
            }
            if ($applied_to > 0) {
                $args['meta_query'][] = array(
                    'key' => 'jobsearch_field_job_publish_date',
                    'value' => $applied_to,
                    'compare' => '<=',
                );
            }
        }

        // ---- centralised auth gate ---------------------------------------

        /**
         * Verify the AJAX nonce + capability. On failure, emit the same
         * JSON envelope the legacy handlers used and die. Keeping the
         * envelope shape means the existing admin.js error-handling code
         * does not need to change.
         */
        protected function verify_ajax_request() {
            $nonce_val = isset($_POST['_nonce']) ? sanitize_key(wp_unslash($_POST['_nonce'])) : '';
            if (!wp_verify_nonce($nonce_val, 'jobsearch_ajax_nonce') || !current_user_can($this->required_capability())) {
                wp_send_json(array(
                    'msg' => esc_html__('You are not allowed to do this.', 'wp-jobsearch'),
                    'error' => '1',
                ));
            }
        }

        // ---- renderer dispatch -------------------------------------------

        /**
         * Each subclass historically exposed two static renderers on the
         * concrete class:
         *   - load_wapp_jobs_posts($jobs_posts)
         *   - list_job_all_apps($job_id, $page_num)
         *
         * We dispatch via `get_class($this)` so static::method() lands on
         * the subclass implementation (which lives in the same file as
         * the page-specific HTML). This keeps the per-page chrome intact
         * without requiring abstract static signatures.
         */
        protected function render_wapp_jobs_posts($jobs_posts) {
            $cls = get_class($this);
            call_user_func(array($cls, 'load_wapp_jobs_posts'), $jobs_posts);
        }

        protected function render_list_job_all_apps($_job_id, $page_num) {
            $cls = get_class($this);
            call_user_func(array($cls, 'list_job_all_apps'), $_job_id, $page_num);
        }

        // ---- shared AJAX handlers ----------------------------------------

        public function load_more_apswith_job_apps() {
            $this->verify_ajax_request();

            $page_num = absint(isset($_POST['page_num']) ? $_POST['page_num'] : 1);
            if ($page_num < 1) {
                $page_num = 1;
            }

            $args = array(
                'post_type' => 'job',
                'posts_per_page' => 5,
                'paged' => $page_num,
                'post_status' => array('publish', 'draft'),
                'fields' => 'ids',
                'order' => 'DESC',
                'orderby' => 'ID',
                'no_found_rows' => true,
            );

            $extra_meta = $this->extra_meta_query();
            if (!empty($extra_meta)) {
                $args['meta_query'] = $extra_meta;
            }

            $selcted_emp = isset($_POST['all_emps_wapps_selctor']) ? sanitize_text_field(wp_unslash($_POST['all_emps_wapps_selctor'])) : '';
            $filter_from_date = isset($_POST['alljobs_wafrom_date']) ? sanitize_text_field(wp_unslash($_POST['alljobs_wafrom_date'])) : '';
            $filter_to_date = isset($_POST['alljobs_wato_date']) ? sanitize_text_field(wp_unslash($_POST['alljobs_wato_date'])) : '';

            if ($selcted_emp != '') {
                $args['meta_query'][] = array(
                    'key' => 'jobsearch_field_job_posted_by',
                    'value' => $selcted_emp,
                    'compare' => '=',
                );
            }

            $applied_from = ($filter_from_date != '') ? strtotime($filter_from_date) : 0;
            $applied_to = ($filter_to_date != '') ? strtotime($filter_to_date) : 0;

            $this->apply_date_filters($args, $applied_from, $applied_to);

            $args = apply_filters($this->args_filter_hook(), $args);

            $jobs_posts = $this->run_jobs_query($args, $page_num);

            ob_start();
            $this->render_wapp_jobs_posts($jobs_posts);
            $html = ob_get_clean();
            echo json_encode(array('html' => $html));

            wp_die();
        }

        public function load_more_apswith_apps_lis() {
            $this->verify_ajax_request();

            $page_num = absint(isset($_POST['page_num']) ? $_POST['page_num'] : 0);
            $_job_id = absint(isset($_POST['_job_id']) ? $_POST['_job_id'] : 0);

            ob_start();
            $this->render_list_job_all_apps($_job_id, $page_num);
            $html = ob_get_clean();
            echo json_encode(array('html' => $html));

            wp_die();
        }

        public function load_single_apswith_job_inlist() {
            $this->verify_ajax_request();

            $_job_id = absint(isset($_POST['_job_id']) ? $_POST['_job_id'] : 0);
            $jobs_posts = array($_job_id);

            ob_start();
            $this->render_wapp_jobs_posts($jobs_posts);
            $html = ob_get_clean();
            echo json_encode(array('html' => $html));

            wp_die();
        }

        // Chunked Excel export. Admin-side auth + filter-args + scope hooks;
        // the 3 admin subclasses add the entity-specific hooks.
        use Jobsearch_Applicants_Export_Trait;

        protected function export_verify_request() {
            // Download is a GET navigation (nonce in $_GET); the others POST it.
            $nonce_val = isset($_POST['_nonce'])
                ? sanitize_key(wp_unslash($_POST['_nonce']))
                : (isset($_GET['_nonce']) ? sanitize_key(wp_unslash($_GET['_nonce'])) : '');
            if (!wp_verify_nonce($nonce_val, 'jobsearch_ajax_nonce') || !current_user_can($this->required_capability())) {
                wp_send_json(array(
                    'msg'   => esc_html__('You are not allowed to do this.', 'wp-jobsearch'),
                    'error' => '1',
                ));
            }
            $this->export_scope = array(
                'mode'               => 'admin',
                'employer_id_filter' => isset($_POST['employer_id']) ? absint($_POST['employer_id']) : 0,
                'job_id_filter'      => isset($_POST['job_id']) ? absint($_POST['job_id']) : 0,
            );
        }

        protected function export_apply_scope_to_jobs_query(array $args) {
            $emp_id = isset($this->export_scope['employer_id_filter']) ? (int) $this->export_scope['employer_id_filter'] : 0;
            if ($emp_id > 0) {
                if (!isset($args['meta_query']) || !is_array($args['meta_query'])) {
                    $args['meta_query'] = array();
                }
                $args['meta_query'][] = array(
                    'key'     => 'jobsearch_field_job_posted_by',
                    'value'   => $emp_id,
                    'compare' => '=',
                );
            }
            // Single-job filter: restrict the jobs query to the chosen job.
            $job_id = isset($this->export_scope['job_id_filter']) ? (int) $this->export_scope['job_id_filter'] : 0;
            if ($job_id > 0) {
                $args['post__in'] = array($job_id);
            }
            return $args;
        }

        protected function export_filter_args_from_post(array $post) {
            $date_from = isset($post['date_from']) ? sanitize_text_field(wp_unslash($post['date_from'])) : '';
            $date_to   = isset($post['date_to'])   ? sanitize_text_field(wp_unslash($post['date_to']))   : '';
            return array(
                'date_from'   => $date_from !== '' ? strtotime($date_from) : 0,
                'date_to'     => $date_to   !== '' ? strtotime($date_to)   : 0,
                'employer_id' => isset($post['employer_id']) ? absint($post['employer_id']) : 0,
            );
        }

    }
}
