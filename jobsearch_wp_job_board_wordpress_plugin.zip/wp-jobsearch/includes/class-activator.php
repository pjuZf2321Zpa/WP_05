<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Fired during plugin activation
 *
 * @since      1.0.0
 *
 * @package    JobSearch_plugin
 * @subpackage JobSearch_plugin/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 */
class JobSearch_plugin_Activator {
    
     public function __construct() {
         
     }
    /**
     * Short Description. (use period)
     *
     * Long Description.
     *
     * @since    1.0.0
     */
    public static function activate() {
        update_option('wp_jobsearch_plugin_active', 'yes');
        
        $plugin_activ_val = get_option('wp_jobsearch_plugin_active');
        if ($plugin_activ_val == '') {
            update_option('users_can_register', '1');
        }
        
        do_action('jobsearch_plugin_activator_hook');
        
        //
        $cron_timestamp = wp_next_scheduled('jobsearch_expire_pkgs_alert_cron');
        if (!$cron_timestamp) {
            wp_schedule_event(time(), 'twicedaily', 'jobsearch_expire_pkgs_alert_cron');
        }
        
        //
        $cron_timestamp = wp_next_scheduled('jobsearch_job_feature_expire_cron');
        if (!$cron_timestamp) {
            wp_schedule_event(time(), 'every_half_hourly', 'jobsearch_job_feature_expire_cron');
        }

        //
        $import_schedules_timestamp = wp_next_scheduled('jobsearch_job_import_schedules_cron');
        if (!$import_schedules_timestamp) {
            wp_schedule_event(time(), 'every_five_mins', 'jobsearch_job_import_schedules_cron');
        }
        if (!wp_next_scheduled('jobsearch_half_hour_common_schedule')) {
            wp_schedule_event(time(), 'every_half_hourly', 'jobsearch_half_hour_common_schedule');
        }

        //
        if (!wp_next_scheduled('jobsearch_evry_monthly_common_schedule')) {
            wp_schedule_event(time(), 'do_monthly', 'jobsearch_evry_monthly_common_schedule');
        }
        
        //
        $jobalerts_cron_event = wp_next_scheduled('jobsearch_job_alerts_schedule');
        if (!$jobalerts_cron_event) {
            wp_schedule_event(time(), 'daily', 'jobsearch_job_alerts_schedule');
        }

        // Stamp the DB version for brand-new installs only (no prior settings),
        // so fresh activations skip the forced database-upgrade page. Existing
        // sites (which have jobsearch_plugin_options) are left unstamped so the
        // upgrader runs after a plugin update. See class-jobsearch-upgrader.php.
        if (!get_option('jobsearch_upgrade_state') && !get_option('jobsearch_plugin_options') && class_exists('JobSearch_plugin')) {
            $jobsearch_code_version = JobSearch_plugin::get_version();
            update_option('jobsearch_upgrade_state', array(
                'db_version' => $jobsearch_code_version,
                'flag'       => $jobsearch_code_version,
                'steps'      => array('peruser_options_to_meta' => true),
                'total'      => 0,
            ), false);
        }
    }
}
