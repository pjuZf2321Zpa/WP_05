<?php
/**
 * Centralized source of every translatable string passed to JavaScript via
 * wp_localize_script() across the wp-jobsearch plugin.
 *
 * Why this file exists
 * --------------------
 *  - All JS-facing translations live in one place so translators have a single
 *    POT scan target and contributors can review the i18n surface without
 *    grepping through 30+ enqueue sites.
 *  - Each wp_localize_script() call pulls the strings for its "group" via
 *    jobsearch_js_i18n_strings('<group>') and merges them with whatever dynamic,
 *    non-translatable values it needs (URLs, sizes, etc.).
 *  - Sprintf-style templates with %s / %d placeholders live under the
 *    'templates' group; call sites format them locally with sprintf().
 *
 * Adding a new string
 *  1. Pick the group that matches the wp_localize_script handle it belongs to
 *     (or add a new group below).
 *  2. Add the key + esc_html__() / esc_attr__() entry.
 *  3. At the localize site, merge the group via jobsearch_js_i18n_strings(...).
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! function_exists( 'jobsearch_js_i18n_strings' ) ) {

    /**
     * Returns the translatable strings used by wp_localize_script across the plugin.
     *
     * @param string $group  Optional group name. Empty / 'all' returns the full
     *                       nested array.
     * @return array         Flat array of key => translated string for the group,
     *                       or the full nested array when no group is given.
     */
    function jobsearch_js_i18n_strings( $group = '' ) {

        $all = array(

            // -------------------------------------------------------------
            // 'plugin'  → jobsearch_plugin_vars (frontend, jobsearch-plugin-scripts)
            // -------------------------------------------------------------
            'plugin' => array(
                'com_img_size'              => esc_html__( 'Image size should not greater than 1 MB.', 'wp-jobsearch' ),
                'com_file_size'             => esc_html__( 'File size should not greater than 1 MB.', 'wp-jobsearch' ),
                'cv_file_types'             => esc_html__( 'Suitable files are .doc,.docx,.pdf', 'wp-jobsearch' ),
                'are_you_sure'              => esc_html__( 'Are you sure!', 'wp-jobsearch' ),
                'com_word_title'            => esc_html__( 'Title', 'wp-jobsearch' ),
                'see_less_txt'              => esc_html__( '- see less', 'wp-jobsearch' ),
                'see_more_txt'              => esc_html__( '+ see more', 'wp-jobsearch' ),
                'com_word_description'      => esc_html__( 'Description', 'wp-jobsearch' ),
                'com_word_save'             => esc_html__( 'Save', 'wp-jobsearch' ),
                'error_msg'                 => esc_html__( 'There is some problem.', 'wp-jobsearch' ),
                'select_sector'             => esc_html__( 'Select Sector', 'wp-jobsearch' ),
                'loading'                   => esc_html__( 'Loading...', 'wp-jobsearch' ),
                'accpt_terms_cond'          => esc_html__( 'Please accept our terms and conditions.', 'wp-jobsearch' ),
                'var_address_str'           => esc_html__( 'Address', 'wp-jobsearch' ),
                'var_other_locs_str'        => esc_html__( 'Other Locations', 'wp-jobsearch' ),
                'pass_length_short'         => esc_html__( 'Very Weak', 'wp-jobsearch' ),
                'pass_length_med'           => esc_html__( 'Weak', 'wp-jobsearch' ),
                'pass_length_good'          => esc_html__( 'Medium', 'wp-jobsearch' ),
                'pass_length_strng'         => esc_html__( 'Strong', 'wp-jobsearch' ),
                'totl_applicants'           => esc_html__( 'Total Applicants:', 'wp-jobsearch' ),
                'shortlisted_applicants'    => esc_html__( 'Shortlisted Applicants:', 'wp-jobsearch' ),
                'rejected_applicants'       => esc_html__( 'Rejected Applicants:', 'wp-jobsearch' ),
                'unlock_candidate_name'     => esc_html__( 'You are about to open the name of the candidate. This action will use 1 point of your package credit.', 'wp-jobsearch' ),
                'unlock_candidate_cv'       => esc_html__( 'You are about to download candidate CV. This action will use 1 point of your package credit.', 'wp-jobsearch' ),
                'candidate_job_title'       => esc_html__( '', 'wp-jobsearch' ),
                'candidate_signup_date'     => esc_html__( '', 'wp-jobsearch' ),
                'alert_close_label'         => esc_attr__( 'Close', 'wp-jobsearch' ),
                'confirm_yes'               => esc_html__( 'Yes', 'wp-jobsearch' ),
                'confirm_no'                => esc_html__( 'No', 'wp-jobsearch' ),
                // Used by jobsearchValidateRequired() in jobsearch-common.js
                'required_fields_label'     => esc_html__( 'Required fields: ', 'wp-jobsearch' ),
                'and_n_more'                => esc_html__( ' and %d more', 'wp-jobsearch' ),
                // Generic "Please fill the required fields." toast fallback.
                // Mirrored into dashboard / posting / admin groups so any
                // JS bag exposed on the page can resolve it without us
                // having to query a different bag per-page.
                'fill_nec_fields'           => esc_html__( 'Please fill the required fields.', 'wp-jobsearch' ),
            ),

            // -------------------------------------------------------------
            // 'dashboard' → jobsearch_dashboard_vars (frontend dashboard JS)
            // -------------------------------------------------------------
            'dashboard' => array(
                'com_img_size'              => esc_html__( 'Image size is too high.', 'wp-jobsearch' ),
                'com_file_size'             => esc_html__( 'File size is too high.', 'wp-jobsearch' ),
                'error_msg'                 => esc_html__( 'There is some problem.', 'wp-jobsearch' ),
                'fill_nec_fields'           => esc_html__( 'Please fill the required fields.', 'wp-jobsearch' ),
                'are_you_sure'              => esc_html__( 'Are you sure!', 'wp-jobsearch' ),
                'del_prof_txt'              => esc_html__( 'Are you sure! You want to delete your profile.', 'wp-jobsearch' ),
                'save_img'                  => esc_html__( 'Save Image', 'wp-jobsearch' ),
                'drag_zoom'                 => esc_html__( 'Drag and Zoom to resize image.', 'wp-jobsearch' ),
                'duplicate_suffix'          => esc_html__( '(duplicated)', 'wp-jobsearch' ),
                'duplicate_success'         => esc_html__( 'Job duplicated successfully.', 'wp-jobsearch' ),
                'duplicate_failed'          => esc_html__( 'Could not duplicate this job.', 'wp-jobsearch' ),
                'network_error'             => esc_html__( 'Network error. Please try again.', 'wp-jobsearch' ),
                'zero_applicants'           => esc_html__( '0 Applicants', 'wp-jobsearch' ),
            ),

            // -------------------------------------------------------------
            // 'dashboard_admin' → jobsearch_dashboard_vars in admin context
            // -------------------------------------------------------------
            'dashboard_admin' => array(
                'com_img_size'              => esc_html__( 'Image size should not greater than 1 MB.', 'wp-jobsearch' ),
                'com_file_size'             => esc_html__( 'File size should not greater than 1 MB.', 'wp-jobsearch' ),
                'cv_file_types'             => esc_html__( 'Suitable files are .doc,.docx,.pdf', 'wp-jobsearch' ),
                'error_msg'                 => esc_html__( 'There is some problem.', 'wp-jobsearch' ),
                'fill_nec_fields'           => esc_html__( 'Please fill the required fields.', 'wp-jobsearch' ),
                'del_prof_txt'              => esc_html__( 'Are you sure! You want to delete your profile.', 'wp-jobsearch' ),
            ),

            // -------------------------------------------------------------
            // 'export' → jobsearch_export_i18n (chunked applicants export
            //   popup; localized on jobsearch-plugin-common in BOTH the
            //   frontend dashboard and wp-admin contexts).
            // -------------------------------------------------------------
            'export' => array(
                'loading'           => esc_html__( 'Loading…', 'wp-jobsearch' ),
                'in_progress_title' => esc_html__( 'Export in progress', 'wp-jobsearch' ),
                'resume'            => esc_html__( 'Resume', 'wp-jobsearch' ),
                'start_fresh'       => esc_html__( 'Start Fresh', 'wp-jobsearch' ),
                'export_title'      => esc_html__( 'Export to Excel', 'wp-jobsearch' ),
                'total_applicants'  => esc_html__( 'Total Applicants', 'wp-jobsearch' ),
                'chunk_size'        => esc_html__( 'Chunk size', 'wp-jobsearch' ),
                'start_export'      => esc_html__( 'Start Export', 'wp-jobsearch' ),
                'cancel'            => esc_html__( 'Cancel', 'wp-jobsearch' ),
                'exporting'         => esc_html__( 'Exporting…', 'wp-jobsearch' ),
                'complete'          => esc_html__( 'Export complete', 'wp-jobsearch' ),
                'downloading'       => esc_html__( 'Downloading…', 'wp-jobsearch' ),
                'close'             => esc_html__( 'Close', 'wp-jobsearch' ),
                'no_applicants'     => esc_html__( 'No applicants match the selected filters.', 'wp-jobsearch' ),
                'generic_error'     => esc_html__( 'Something went wrong. Please try again.', 'wp-jobsearch' ),
                // %s = percent complete; %% is an escaped literal percent
                // sign. Keeping it valid printf c-format means gettext /
                // Loco Translate format-validation accepts the catalog
                // string. The JS consumer substitutes %s then unescapes %%.
                'resume_text'       => esc_html__( 'You have an export in progress (%s%% complete).', 'wp-jobsearch' ),
            ),

            // -------------------------------------------------------------
            // 'admin' → jobsearch_plugin_vars in wp-admin
            // -------------------------------------------------------------
            'admin' => array(
                'var_address_str'           => esc_html__( 'Address', 'wp-jobsearch' ),
                'var_other_locs_str'        => esc_html__( 'Other Locations', 'wp-jobsearch' ),
                'are_you_sure'              => __( 'Are you sure!', 'wp-jobsearch' ),
                'require_fields'            => __( 'Please fill the required fields.', 'wp-jobsearch' ),
                'error_msg'                 => esc_html__( 'There is some problem.', 'wp-jobsearch' ),
                'alert_close_label'         => esc_attr__( 'Close', 'wp-jobsearch' ),
                'confirm_yes'               => esc_html__( 'Yes', 'wp-jobsearch' ),
                'confirm_no'                => esc_html__( 'No', 'wp-jobsearch' ),
            ),

            // -------------------------------------------------------------
            // 'posting' → jobsearch_posting_vars (jobsearch-user-job-posting)
            // -------------------------------------------------------------
            'posting' => array(
                'error_msg'                 => esc_html__( 'There is some problem.', 'wp-jobsearch' ),
                'blank_field_msg'           => esc_html__( 'This field should not be blank.', 'wp-jobsearch' ),
                'title_len_less_msg'        => esc_html__( 'Title length should be greater than 1 characters.', 'wp-jobsearch' ),
                'title_txt_cont_msg'        => esc_html__( 'Title field can contain only alphanumeric characters, underscore(_), dash(-) and space.', 'wp-jobsearch' ),
                'file_type_error'           => esc_html__( 'This file format is not allowed.', 'wp-jobsearch' ),
                // Toast strings consumed by jobsearch-job-posting.js +
                // jobsearchValidateRequired() when the post-job form is
                // submitted with missing fields.
                'fill_nec_fields'           => esc_html__( 'Please fill the required fields.', 'wp-jobsearch' ),
                'required_fields_label'     => esc_html__( 'Required fields: ', 'wp-jobsearch' ),
                'and_n_more'                => esc_html__( ' and %d more', 'wp-jobsearch' ),
            ),

            // -------------------------------------------------------------
            // 'imports' → shared by import / integration modules
            //   freelancer, aquent, careerbuilder, careerjet, flexjobs,
            //   indeed, kropjobs, ziprecruiter, ads-management
            // -------------------------------------------------------------
            'imports' => array(
                'error_msg'                 => esc_html__( 'There is some problem.', 'wp-jobsearch' ),
                'submit_txt'                => esc_html__( 'Submit', 'wp-jobsearch' ),
            ),

            // -------------------------------------------------------------
            // 'job_alerts' → jobsearch_jobalerts_vars
            // -------------------------------------------------------------
            'job_alerts' => array(
                'error_msg'                 => esc_html__( 'There is some problem.', 'wp-jobsearch' ),
                'email_field_error'         => esc_html__( 'Please enter a valid email.', 'wp-jobsearch' ),
                'name_field_error'          => esc_html__( 'Please enter an alert name.', 'wp-jobsearch' ),
                'submit_txt'                => esc_html__( 'Create Alert', 'wp-jobsearch' ),
                'save_alert_txt'            => esc_html__( 'Save Jobs Alert', 'wp-jobsearch' ),
            ),

            // -------------------------------------------------------------
            // 'reviews' → jobsearch_reviews_vars
            // -------------------------------------------------------------
            'reviews' => array(
                'error_msg'                 => esc_html__( 'There is some problem.', 'wp-jobsearch' ),
                'loading'                   => esc_html__( 'Loading...', 'wp-jobsearch' ),
            ),

            // -------------------------------------------------------------
            // 'packages' → jobsearch_packages_vars
            // -------------------------------------------------------------
            'packages' => array(
                'error_msg'                 => esc_html__( 'There is some problem.', 'wp-jobsearch' ),
            ),

            // -------------------------------------------------------------
            // 'job_application' → jobsearch_job_application
            // -------------------------------------------------------------
            'job_application' => array(
                'error_msg'                 => esc_html__( 'There is some error.', 'wp-jobsearch' ),
                'confirm_msg'               => esc_html__( 'jobsearch_job_application_conform_msg', 'wp-jobsearch' ),
                'com_img_size'              => esc_html__( 'Image size should not greater than 1 MB.', 'wp-jobsearch' ),
                'com_file_size'             => esc_html__( 'File size should not greater than 1 MB.', 'wp-jobsearch' ),
                'actvcode_fieldlbl'         => esc_html__( 'Activation Code', 'wp-jobsearch' ),
                'verify_btnlbl'             => esc_html__( 'Verify Email', 'wp-jobsearch' ),
            ),

            // -------------------------------------------------------------
            // 'login_register' → jobsearch_login_register_common_vars
            // -------------------------------------------------------------
            'login_register' => array(
                'actvcode_fieldlbl'         => esc_html__( 'Activation Code', 'wp-jobsearch' ),
                'verify_btnlbl'             => esc_html__( 'Verify Email', 'wp-jobsearch' ),
                'activ_notice_msg1'         => esc_html__( 'Before you can login, you must activate your account with the code sent to your email address. If you did not receive this email, please check your junk/spam folder.', 'wp-jobsearch' ),
                'activ_notice_lnk'          => esc_html__( 'Click here', 'wp-jobsearch' ),
                'activ_notice_msg2'         => esc_html__( 'to resend the activation email. If you entered an incorrect email address, you will need to re-register with the correct email address.', 'wp-jobsearch' ),
            ),

            // -------------------------------------------------------------
            // 'location_editor' → jobsearch_location_common_text (admin)
            // -------------------------------------------------------------
            'location_editor' => array(
                'sav_contry'                => esc_html__( 'Save Countries', 'wp-jobsearch' ),
                'save_states'               => esc_html__( 'Save States', 'wp-jobsearch' ),
                'sav_city'                  => esc_html__( 'Save City', 'wp-jobsearch' ),
                'pls_wait'                  => esc_html__( 'Please Wait...', 'wp-jobsearch' ),
                'req_state'                 => esc_html__( 'Please Enter Any State Name', 'wp-jobsearch' ),
                'req_city'                  => esc_html__( 'Please Enter Any City Name', 'wp-jobsearch' ),
                'req_cntry'                 => esc_html__( 'Please Enter Country Code', 'wp-jobsearch' ),
                'req_cntry_code_uppercase'  => esc_html__( 'Country Code should be in uppercase.', 'wp-jobsearch' ),
                'req_num'                   => esc_html__( 'Country Code cannot be numeric.', 'wp-jobsearch' ),
                'req_chars'                 => esc_html__( 'Country code cannot be more than 3 alphabets.', 'wp-jobsearch' ),
                'req_poplation'             => esc_html__( 'Population can only be in numbers.', 'wp-jobsearch' ),
                'cntry_success'             => esc_html__( 'Country Saved Successfully.', 'wp-jobsearch' ),
                'state_success'             => esc_html__( 'State Saved successfully.', 'wp-jobsearch' ),
                'city_success'              => esc_html__( 'City Saved successfully.', 'wp-jobsearch' ),
                'any_state_text'            => esc_html__( 'Enter Any State', 'wp-jobsearch' ),
                'state_text'                => esc_html__( 'Enter States', 'wp-jobsearch' ),
                'state_select'              => esc_html__( 'Select States', 'wp-jobsearch' ),
                'state_city'                => esc_html__( 'Select any city', 'wp-jobsearch' ),
                'reset_data'                => esc_html__( 'Are you sure you want to reset locations data and download again?', 'wp-jobsearch' ),
                'file_ext'                  => esc_html__( 'File of this extension is not allowed. Only XLSX is allowed.', 'wp-jobsearch' ),
            ),

            // -------------------------------------------------------------
            // 'templates' → sprintf templates with %s / %d placeholders.
            // Call sites pull these and run sprintf() to inject dynamic values,
            // then merge the result into the localized array under the right key.
            // -------------------------------------------------------------
            'templates' => array(
                'file_size_max'             => esc_html__( 'File size should not greater than %s.', 'wp-jobsearch' ),
                'image_size_max'            => esc_html__( 'Image size should not greater than %s.', 'wp-jobsearch' ),
                'suitable_files'            => esc_html__( 'Suitable files are %s.', 'wp-jobsearch' ),
                'portfolio_max_msg'         => esc_html__( 'You can upload up to "%s" portfolio files only.', 'wp-jobsearch' ),
                'logo_hw_max'               => esc_html__( 'Logo height and width should not be greater than %sx%s.', 'wp-jobsearch' ),
                'title_len_max'             => esc_html__( 'Title length should not be exceeded from %d characters.', 'wp-jobsearch' ),
                'desc_len_max'              => esc_html__( 'Description length should not be exceeded from %d characters.', 'wp-jobsearch' ),
                'file_too_large'            => esc_html__( 'Your file is too large in size. Max size allowed is %d kb', 'wp-jobsearch' ),
            ),
        );

        /**
         * Filter the central JS i18n table. Themes / child plugins may extend or
         * override individual strings via this filter. Receives the full nested
         * array regardless of the $group argument.
         */
        $all = apply_filters( 'jobsearch_js_i18n_strings', $all );

        if ( $group === '' || $group === 'all' ) {
            return $all;
        }
        return isset( $all[ $group ] ) ? $all[ $group ] : array();
    }
}

if ( ! function_exists( 'jobsearch_js_i18n' ) ) {
    /**
     * Shorthand for jobsearch_js_i18n_strings(). Convenience helper.
     *
     * @param string $group Group name, e.g. 'dashboard', 'plugin', 'imports'.
     * @return array
     */
    function jobsearch_js_i18n( $group = '' ) {
        return jobsearch_js_i18n_strings( $group );
    }
}

if ( ! function_exists( 'jobsearch_js_i18n_tpl' ) ) {
    /**
     * Pull a sprintf-style template from the 'templates' group and apply
     * sprintf() with the supplied arguments.
     *
     *   $msg = jobsearch_js_i18n_tpl( 'file_size_max', $cvfile_size_str );
     */
    function jobsearch_js_i18n_tpl( $key /* , ...$args */ ) {
        $tpls = jobsearch_js_i18n_strings( 'templates' );
        $args = func_get_args();
        array_shift( $args );
        $tpl  = isset( $tpls[ $key ] ) ? $tpls[ $key ] : '';
        if ( $tpl === '' ) {
            return '';
        }
        array_unshift( $args, $tpl );
        return call_user_func_array( 'sprintf', $args );
    }
}

if ( ! function_exists( 'jobsearch_js_i18n_localize' ) ) {
    /**
     * Merge the i18n strings for the given $group with caller-supplied dynamic
     * values and pass them to wp_localize_script().
     *
     *   jobsearch_js_i18n_localize(
     *       'jobsearch-job-alerts-scripts',
     *       'jobsearch_jobalerts_vars',
     *       'job_alerts',
     *       array( 'ajax_url' => $admin_ajax_url, 'plugin_url' => jobsearch_plugin_get_url() )
     *   );
     *
     * @param string $handle      Script handle previously registered/enqueued.
     * @param string $object_name JS variable name on window.
     * @param string $group       Group name from jobsearch_js_i18n_strings().
     * @param array  $extra       Dynamic / non-translatable values to merge in.
     * @return bool               Result of wp_localize_script().
     */
    function jobsearch_js_i18n_localize( $handle, $object_name, $group, $extra = array() ) {
        $strings = jobsearch_js_i18n_strings( $group );
        $data    = array_merge( $strings, (array) $extra );
        return wp_localize_script( $handle, $object_name, $data );
    }
}
