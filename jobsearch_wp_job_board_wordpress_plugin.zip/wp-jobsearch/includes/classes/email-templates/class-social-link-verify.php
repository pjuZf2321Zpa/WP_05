<?php
/**
 * Email template — Social-Login link verification
 *
 * Triggered by JobSearch_Social_Link_Verifier::send_email() when a social
 * sign-in attempt matches an existing WP user by email and we need the real
 * mailbox owner to confirm linking the social account.
 *
 * Trigger:
 *   do_action('jobsearch_social_link_verify_email', $wp_user, $provider, $verify_url);
 *
 * Shortcodes:
 *   {user_name} {user_fname} {user_lname}
 *   {provider_label}
 *   {verify_url} {verify_button}
 *   {originating_ip}
 *   {expiry_minutes}
 *   {site_name}
 */
if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('jobsearch_social_link_verify_template')) {

    class jobsearch_social_link_verify_template {

        public $email_template_type;
        public $codes;
        public $type;
        public $group;
        public $filter;
        public $user;
        public $provider;
        public $verify_url;
        public $is_email_sent;
        public $email_template_prefix;
        public $email_template_group;
        public $default_content;
        public $default_subject;
        public $default_recipients;
        public $switch_label;
        public $email_template_db_id;
        public $default_var;
        public $rand;
        public static $is_email_sent1;

        public function __construct() {

            add_action('init', array($this, 'jobsearch_social_link_verify_template_init'), 1, 0);
            add_filter('jobsearch_social_link_verify_filter', array($this, 'jobsearch_social_link_verify_filter_callback'), 1, 4);
            add_filter('jobsearch_email_template_settings', array($this, 'template_settings_callback'), 12, 1);
            add_action('jobsearch_social_link_verify_email', array($this, 'jobsearch_social_link_verify_callback'), 10, 3);
        }

        public function jobsearch_social_link_verify_template_init() {
            $this->user = array();
            $this->provider = '';
            $this->verify_url = '';
            $this->rand = rand(0, 99999);
            $this->group = 'other';
            $this->type = 'social_link_verify';
            $this->filter = 'social_link_verify';
            $this->email_template_db_id = 'social_link_verify';
            $this->switch_label = esc_html__('To User — Confirm Social Account Link', 'wp-jobsearch');
            $this->default_subject = esc_html__('[{site_name}] Confirm linking your {provider_label} account', 'wp-jobsearch');
            $this->default_recipients = '';
            $default_content = esc_html__('Default Content', 'wp-jobsearch');
            $default_content = apply_filters('jobsearch_social_link_verify_filter', $default_content, 'html', 'social-link-verify', 'email-templates');
            $this->default_content = $default_content;
            $this->email_template_prefix = 'social_link_verify';
            $this->email_template_group = 'other';
            $this->codes = array(
                array(
                    'var' => '{user_name}',
                    'display_text' => esc_html__('User Display Name', 'wp-jobsearch'),
                    'function_callback' => array($this, 'get_user_name'),
                ),
                array(
                    'var' => '{user_fname}',
                    'display_text' => esc_html__('User First Name', 'wp-jobsearch'),
                    'function_callback' => array($this, 'get_user_fname'),
                ),
                array(
                    'var' => '{user_lname}',
                    'display_text' => esc_html__('User Last Name', 'wp-jobsearch'),
                    'function_callback' => array($this, 'get_user_lname'),
                ),
                array(
                    'var' => '{provider_label}',
                    'display_text' => esc_html__('Social Provider (Google / Facebook / Twitter / …)', 'wp-jobsearch'),
                    'function_callback' => array($this, 'get_provider_label'),
                ),
                array(
                    'var' => '{verify_url}',
                    'display_text' => esc_html__('Verification URL (raw)', 'wp-jobsearch'),
                    'function_callback' => array($this, 'get_verify_url'),
                ),
                array(
                    'var' => '{verify_button}',
                    'display_text' => esc_html__('Verification Button (pre-styled HTML)', 'wp-jobsearch'),
                    'function_callback' => array($this, 'get_verify_button'),
                ),
                array(
                    'var' => '{originating_ip}',
                    'display_text' => esc_html__('Originating IP of the social sign-in attempt', 'wp-jobsearch'),
                    'function_callback' => array($this, 'get_originating_ip'),
                ),
                array(
                    'var' => '{expiry_minutes}',
                    'display_text' => esc_html__('Minutes until the verification link expires', 'wp-jobsearch'),
                    'function_callback' => array($this, 'get_expiry_minutes'),
                ),
                array(
                    'var' => '{site_name}',
                    'display_text' => esc_html__('Site Name', 'wp-jobsearch'),
                    'function_callback' => array($this, 'get_site_name'),
                ),
            );

            $this->default_var = array(
                'switch_label' => $this->switch_label,
                'default_subject' => $this->default_subject,
                'default_recipients' => $this->default_recipients,
                'default_content' => $this->default_content,
                'group' => $this->group,
                'type' => $this->type,
                'filter' => $this->filter,
                'codes' => $this->codes,
            );
        }

        public function jobsearch_social_link_verify_callback($user = '', $provider = '', $verify_url = '') {
            global $sitepress;
            $lang_code = '';
            if (function_exists('icl_object_id') && function_exists('wpml_init_language_switcher')) {
                $lang_code = $sitepress->get_current_language();
            }

            $this->user       = $user;
            $this->provider   = $provider;
            $this->verify_url = $verify_url;

            $template = $this->get_template();
            if (isset($template['switch']) && $template['switch'] == 1 && is_object($user) && !empty($user->user_email)) {

                $blogname = get_option('blogname');
                $admin_email = get_option('admin_email');
                $sender_detail_header = '';
                if (isset($template['from']) && $template['from'] != '') {
                    $sender_detail_header = $template['from'];
                    if (isset($template['from_name']) && $template['from_name'] != '') {
                        $sender_detail_header = $template['from_name'] . ' <' . $sender_detail_header . '> ';
                    }
                }

                $subject = (isset($template['subject']) && $template['subject'] != '') ? $template['subject'] : $this->default_subject;
                $subject = JobSearch_plugin::jobsearch_replace_variables($subject, $this->codes);

                $from = (isset($sender_detail_header) && $sender_detail_header != '') ? $sender_detail_header : esc_attr($blogname) . ' <' . $admin_email . '>';
                $recipients = (isset($template['recipients']) && $template['recipients'] != '') ? $template['recipients'] : $user->user_email;
                $email_type = (isset($template['email_type']) && $template['email_type'] != '') ? $template['email_type'] : 'html';

                $email_message = isset($template['email_template']) ? $template['email_template'] : '';

                if (function_exists('icl_object_id') && function_exists('wpml_init_language_switcher')) {
                    $temp_trnaslated = get_option('jobsearch_translate_email_templates');
                    $template_type = $this->type;
                    if (isset($temp_trnaslated[$template_type]['lang_' . $lang_code]['subject'])) {
                        $subject = $temp_trnaslated[$template_type]['lang_' . $lang_code]['subject'];
                        $subject = JobSearch_plugin::jobsearch_replace_variables($subject, $this->codes);
                    }
                    if (isset($temp_trnaslated[$template_type]['lang_' . $lang_code]['content'])) {
                        $email_message = $temp_trnaslated[$template_type]['lang_' . $lang_code]['content'];
                        $email_message = JobSearch_plugin::jobsearch_replace_variables($email_message, $this->codes);
                    }
                }

                $args = array(
                    'to' => $recipients,
                    'subject' => $subject,
                    'from' => $from,
                    'message' => $email_message,
                    'email_type' => $email_type,
                    'class_obj' => $this,
                );
                do_action('jobsearch_send_mail', $args);
                jobsearch_social_link_verify_template::$is_email_sent1 = $this->is_email_sent;
            }
        }

        public static function template_path() {
            return apply_filters('jobsearch_plugin_template_path', 'wp-jobsearch/');
        }

        public function jobsearch_social_link_verify_filter_callback($html, $slug = '', $name = '', $ext_template = '') {
            ob_start();
            $html = '';
            $template = '';
            if ($ext_template != '') {
                $ext_template = trailingslashit($ext_template);
            }
            if ($name) {
                $template = locate_template(array("{$slug}-{$name}.php", self::template_path() . "templates/{$ext_template}/{$slug}-{$name}.php"));
            }
            if (!$template && $name && file_exists(jobsearch_plugin_get_path() . "templates/{$ext_template}/{$slug}-{$name}.php")) {
                $template = jobsearch_plugin_get_path() . "templates/{$ext_template}{$slug}-{$name}.php";
            }
            if (!$template) {
                $template = locate_template(array("{$slug}.php", self::template_path() . "{$ext_template}/{$slug}.php"));
            }
            if ($template) {
                load_template($template, false);
            }
            $html = ob_get_clean();
            return $html;
        }

        public function template_settings_callback($email_template_options) {
            $email_template_options['social_link_verify']['rand'] = $this->rand;
            $email_template_options['social_link_verify']['email_template_prefix'] = $this->email_template_prefix;
            $email_template_options['social_link_verify']['email_template_group'] = $this->email_template_group;
            $email_template_options['social_link_verify']['default_var'] = $this->default_var;
            return $email_template_options;
        }

        public function get_template() {
            return JobSearch_plugin::get_template($this->email_template_db_id, $this->codes, $this->default_content);
        }

        public function get_user_name() {
            if (!is_object($this->user)) {
                return '';
            }
            return !empty($this->user->display_name) ? $this->user->display_name : $this->user->user_login;
        }

        public function get_user_fname() {
            if (!is_object($this->user)) {
                return '';
            }
            $fname = isset($this->user->first_name) ? $this->user->first_name : '';
            return $fname !== '' ? $fname : '-';
        }

        public function get_user_lname() {
            if (!is_object($this->user)) {
                return '';
            }
            $lname = isset($this->user->last_name) ? $this->user->last_name : '';
            return $lname !== '' ? $lname : '-';
        }

        public function get_provider_label() {
            if (class_exists('JobSearch_Social_Link_Verifier')) {
                return JobSearch_Social_Link_Verifier::provider_label($this->provider);
            }
            return ucfirst((string) $this->provider);
        }

        public function get_verify_url() {
            return esc_url($this->verify_url);
        }

        public function get_verify_button() {
            return $this->verify_url;
        }

        public function get_originating_ip() {
            return isset($_SERVER['REMOTE_ADDR']) ? substr((string) $_SERVER['REMOTE_ADDR'], 0, 45) : '';
        }

        public function get_expiry_minutes() {
            if (class_exists('JobSearch_Social_Link_Verifier')) {
                return (string) max(1, (int) (JobSearch_Social_Link_Verifier::TTL / 60));
            }
            return '30';
        }

        public function get_site_name() {
            return wp_specialchars_decode(get_bloginfo('name'), ENT_QUOTES);
        }
    }

    return new jobsearch_social_link_verify_template();
}
