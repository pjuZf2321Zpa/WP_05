<?php
if (!defined('ABSPATH')) {
    die;
}

class jobsearch_count_total_applicants {

    public function __construct() {
        add_action('init', array($this, 'check_and_delete_key'));

        add_action('jobsearch_internal_applics_totalupdate', array($this, 'total_internal_applics_update'), 10, 3);
        add_action('jobsearch_internal_applics_totalcounts', array($this, 'total_internal_applics'));
        
        //
        add_action('jobsearch_job_applic_custom_add', array($this, 'on_apply_internal_applics_count'));
        add_action('jobsearch_job_applying_save_action', array($this, 'on_apply_internal_applics_count'));
        
        add_action('jobsearch_applicant_rejected_for_job', array($this, 'on_reject_internal_applics_count'), 10, 2);
        
        add_action('jobsearch_applicant_shortlisted_for_job', array($this, 'on_shrtlist_internal_applics_count'));
        
        add_action('jobsearch_applicant_undoreject_for_job', array($this, 'on_undoreject_internal_applics_count'));
        
        add_action('jobsearch_applicant_deleted_for_job', array($this, 'applicant_deleted_for_job'), 10, 2);
        
        // before job delete
        add_action('wp_trash_post', array($this, 'on_delete_post_internal_applics_count'), 40);
        add_action('before_delete_post', array($this, 'on_delete_post_internal_applics_count'), 40);

        // Background orphan-id purge (replaces the old manual button). A
        // weekly event kicks off a pass; the batch handler self-reschedules
        // until every job has been cleaned, then recomputes the totals.
        add_filter('cron_schedules', array($this, 'orphan_purge_cron_schedule'));
        add_action('init', array($this, 'schedule_orphan_purge'));
        add_action('jobsearch_purge_orphans_start', array($this, 'orphan_purge_start'));
        add_action('jobsearch_purge_orphans_batch', array($this, 'orphan_purge_batch'));
    }

    public function orphan_purge_cron_schedule($schedules) {
        if (!isset($schedules['jobsearch_weekly'])) {
            $schedules['jobsearch_weekly'] = array(
                'interval' => 7 * DAY_IN_SECONDS,
                'display'  => esc_html__('Once Weekly (JobSearch)', 'wp-jobsearch'),
            );
        }
        return $schedules;
    }

    public function schedule_orphan_purge() {
        if (!wp_next_scheduled('jobsearch_purge_orphans_start')) {
            wp_schedule_event(time() + HOUR_IN_SECONDS, 'jobsearch_weekly', 'jobsearch_purge_orphans_start');
        }
    }

    // Begin a fresh full pass: reset the cursor + tallies and queue batch 1.
    public function orphan_purge_start() {
        update_option('jobsearch_purge_orphans_cursor', 0, false);
        update_option('jobsearch_purge_orphans_acc', array('app' => 0, 'sh' => 0, 'rej' => 0), false);
        if (!wp_next_scheduled('jobsearch_purge_orphans_batch')) {
            wp_schedule_single_event(time() + 10, 'jobsearch_purge_orphans_batch');
        }
    }

    // Clean one bounded page of jobs, then self-reschedule until done. Runs in
    // the background so it never hits a request timeout on large datasets.
    public function orphan_purge_batch() {
        global $wpdb;
        @set_time_limit(0);

        $per_page = (int) apply_filters('jobsearch_purge_orphans_batch_size', 200);
        if ($per_page < 1) {
            $per_page = 200;
        }
        $cursor = (int) get_option('jobsearch_purge_orphans_cursor', 0);

        // Stable pagination over all jobs by ID (cleaning never removes a job
        // from this set, so offsets can't skip rows).
        $job_ids = $wpdb->get_col($wpdb->prepare(
            "SELECT ID FROM {$wpdb->posts} WHERE post_type = 'job' ORDER BY ID DESC LIMIT %d, %d",
            $cursor,
            $per_page
        ));
        $found = is_array($job_ids) ? count($job_ids) : 0;

        $acc = get_option('jobsearch_purge_orphans_acc', array('app' => 0, 'sh' => 0, 'rej' => 0));

        if (!empty($job_ids)) {
            foreach ($job_ids as $job_id) {
                // Clean each list AND tally its valid+unique count, so the
                // totals are computed from the exact same walk the export uses
                // (same job set, same dedup, same validity filter) — no drift.
                $applicants = $this->purge_clean_candidate_list($job_id, 'jobsearch_job_applicants_list');
                $short      = $this->purge_clean_candidate_list($job_id, '_job_short_interview_list');
                $reject     = $this->purge_clean_candidate_list($job_id, '_job_reject_interview_list');
                $this->purge_clean_candidate_list($job_id, 'jobsearch_viewed_candidates');

                $acc['app'] += count(array_unique($applicants));
                $acc['sh']  += count(array_unique($short));
                $acc['rej'] += count(array_unique($reject));
            }
            update_option('jobsearch_purge_orphans_acc', $acc, false);
        }

        if ($found === $per_page) {
            // More jobs remain — advance the cursor and queue the next batch.
            update_option('jobsearch_purge_orphans_cursor', $cursor + $found, false);
            wp_schedule_single_event(time() + 60, 'jobsearch_purge_orphans_batch');
        } else {
            // Pass complete — save the freshly-walked totals (active + rejected,
            // matching the box semantics) so the count equals the export, then
            // clear the run state.
            do_action('jobsearch_internal_applics_totalupdate', $acc['app'] + $acc['rej'], $acc['sh'], $acc['rej']);
            delete_option('jobsearch_purge_orphans_cursor');
            delete_option('jobsearch_purge_orphans_acc');
        }
    }

    /**
     * Filter one job-list meta down to valid candidate ids, writing the
     * cleaned value back in its original storage format (comma-string or
     * array). Only invalid/deleted ids are dropped; duplicates and order are
     * preserved. Returns the valid candidate-id array (with duplicates) so the
     * caller can tally it.
     */
    private function purge_clean_candidate_list($job_id, $meta_key) {
        $raw = get_post_meta($job_id, $meta_key, true);
        if ($raw === '' || $raw === null || (is_array($raw) && empty($raw))) {
            return array();
        }
        $was_array = is_array($raw);
        $orig      = $was_array ? array_values($raw) : explode(',', $raw);
        $valid     = jobsearch_is_post_ids_array($orig, 'candidate');
        if (count($orig) !== count($valid)) {
            $new = $was_array ? array_values($valid) : implode(',', $valid);
            update_post_meta($job_id, $meta_key, $new);
        }
        return $valid;
    }

    public function check_and_delete_key() {
        $cachetime = 86400 * 7; // 7 days
        $transient = 'jobsearch_internal_applics_counts_time';

        $check_transient = get_transient($transient);
        if (empty($check_transient)) {

            delete_option('jobsearch_internal_applics_counts');

            set_transient($transient, true, $cachetime);
        }
    }
    
    public function total_internal_applics_update($appcounts, $shappcounts, $rejappcounts) {
        $total_counts = array(
            'applicants' => $appcounts,
            'shortlisted' => $shappcounts,
            'rejected' => $rejappcounts,
        );
        
        update_option('jobsearch_internal_applics_counts', $total_counts);
    }
    
    public function total_internal_applics() {
        global $wpdb, $table_prefix;

        // $args = array(
        //     'post_type' => 'job',
        //     'posts_per_page' => -1,
        //     'post_status' => array('publish', 'draft'),
        //     'fields' => 'ids',
        //     'meta_query' => array(
        //         array(
        //             'key' => 'jobsearch_job_applicants_list',
        //             'compare' => 'EXISTS',
        //         ),
        //     ),
        // );
        // $jobs_query = new WP_Query($args);
        // $jobs_posts = $jobs_query->posts;
        
        $query = "SELECT post_id FROM {$table_prefix}postmeta p WHERE p.meta_key = '%s'";
        $query .= " GROUP BY p.meta_id ORDER BY p.meta_id DESC";
        $jobs_posts = $wpdb->get_col($wpdb->prepare($query, 'jobsearch_job_applicants_list'));
        
        $appcounts = $shappcounts = $rejappcounts = 0;
        if (!empty($jobs_posts)) {
            foreach ($jobs_posts as $_job_id) {
                $job_applicants_list = get_post_meta($_job_id, 'jobsearch_job_applicants_list', true);
                $job_applicants_list = jobsearch_is_post_ids_array($job_applicants_list, 'candidate');

                if (empty($job_applicants_list)) {
                    $job_applicants_list = array();
                } else {
                    $job_applicants_list = array_unique($job_applicants_list);
                }

                $job_applicants_count = !empty($job_applicants_list) ? count($job_applicants_list) : 0;
                $appcounts += $job_applicants_count;

                //
                $job_short_int_list = get_post_meta($_job_id, '_job_short_interview_list', true);
                $job_short_int_list = $job_short_int_list != '' ? explode(',', $job_short_int_list) : '';
                if (empty($job_short_int_list)) {
                    $job_short_int_list = array();
                } else {
                    $job_short_int_list = array_unique($job_short_int_list);
                }
                $job_short_int_list = jobsearch_is_post_ids_array($job_short_int_list, 'candidate');
                $job_short_int_list_c = !empty($job_short_int_list) ? count($job_short_int_list) : 0;
                $shappcounts += $job_short_int_list_c;

                $job_reject_int_list = get_post_meta($_job_id, '_job_reject_interview_list', true);
                $job_reject_int_list = $job_reject_int_list != '' ? explode(',', $job_reject_int_list) : '';
                if (empty($job_reject_int_list)) {
                    $job_reject_int_list = array();
                } else {
                    $job_reject_int_list = array_unique($job_reject_int_list);
                }
                $job_reject_int_list = jobsearch_is_post_ids_array($job_reject_int_list, 'candidate');
                $job_reject_int_list_c = !empty($job_reject_int_list) ? count($job_reject_int_list) : 0;
                $rejappcounts += $job_reject_int_list_c;
            }
            $appcounts += $rejappcounts;
        }
        
        $this->total_internal_applics_update($appcounts, $shappcounts, $rejappcounts);
    }
    
    public function on_apply_internal_applics_count() {
        $get_tcounts = get_option('jobsearch_internal_applics_counts');
        if (isset($get_tcounts['applicants'])) {

            $appcounts = absint($get_tcounts['applicants']) + 1;
            $shappcounts = $get_tcounts['shortlisted'];
            $rejappcounts = $get_tcounts['rejected'];
            
            $this->total_internal_applics_update($appcounts, $shappcounts, $rejappcounts);
        }
    }
    
    public function on_shrtlist_internal_applics_count() {
        $get_tcounts = get_option('jobsearch_internal_applics_counts');
        if (isset($get_tcounts['applicants'])) {

            $appcounts = $get_tcounts['applicants'];
            $shappcounts = absint($get_tcounts['shortlisted']) + 1;
            $rejappcounts = $get_tcounts['rejected'];
            
            $this->total_internal_applics_update($appcounts, $shappcounts, $rejappcounts);
        }
    }
    
    public function on_reject_internal_applics_count($job_id, $candidate_id) {
        $get_tcounts = get_option('jobsearch_internal_applics_counts');
        if (isset($get_tcounts['applicants'])) {
            
            $minus_from_apliclist = $minus_from_shortlist = false;
            
            $job_applicants_list = get_post_meta($job_id, 'jobsearch_job_applicants_list', true);
            $job_applicants_list = jobsearch_is_post_ids_array($job_applicants_list, 'candidate');
            if (!empty($job_applicants_list) && in_array($candidate_id, $job_applicants_list)) {
                $minus_from_apliclist = true;
            }
            
            $job_short_int_list = get_post_meta($job_id, '_job_short_interview_list', true);
            $job_short_int_list = $job_short_int_list != '' ? explode(',', $job_short_int_list) : '';
            if (!empty($job_short_int_list) && in_array($candidate_id, $job_short_int_list)) {
                $minus_from_shortlist = true;
            }

            $appcounts = $minus_from_apliclist && $get_tcounts['applicants'] > 0 ? (absint($get_tcounts['applicants']) - 1) : $get_tcounts['applicants'];
            $shappcounts = $minus_from_shortlist && $get_tcounts['shortlisted'] > 0 ? (absint($get_tcounts['shortlisted']) - 1) : $get_tcounts['shortlisted'];
            $rejappcounts = absint($get_tcounts['rejected']) + 1;
            
            $this->total_internal_applics_update($appcounts, $shappcounts, $rejappcounts);
        }
    }
    
    public function on_undoreject_internal_applics_count() {
        $get_tcounts = get_option('jobsearch_internal_applics_counts');
        if (isset($get_tcounts['applicants'])) {

            $appcounts = absint($get_tcounts['applicants']) + 1;
            $shappcounts = $get_tcounts['shortlisted'];
            $rejappcounts = $get_tcounts['rejected'] > 0 ? (absint($get_tcounts['rejected']) - 1) : $get_tcounts['rejected'];
            
            $this->total_internal_applics_update($appcounts, $shappcounts, $rejappcounts);
        }
    }
    
    public function applicant_deleted_for_job($job_id, $candidate_id) {
        $get_tcounts = get_option('jobsearch_internal_applics_counts');
        if (isset($get_tcounts['applicants'])) {
            
            $minus_from_apliclist = $minus_from_shortlist = $minus_from_reject = false;
            
            $job_applicants_list = get_post_meta($job_id, 'jobsearch_job_applicants_list', true);
            $job_applicants_list = jobsearch_is_post_ids_array($job_applicants_list, 'candidate');
            if (!empty($job_applicants_list) && in_array($candidate_id, $job_applicants_list)) {
                $minus_from_apliclist = true;
            }
            
            $job_short_int_list = get_post_meta($job_id, '_job_short_interview_list', true);
            $job_short_int_list = $job_short_int_list != '' ? explode(',', $job_short_int_list) : '';
            if (!empty($job_short_int_list) && in_array($candidate_id, $job_short_int_list)) {
                $minus_from_shortlist = true;
            }
            
            $job_reject_int_list = get_post_meta($job_id, '_job_reject_interview_list', true);
            $job_reject_int_list = $job_reject_int_list != '' ? explode(',', $job_reject_int_list) : '';
            if (!empty($job_reject_int_list) && in_array($candidate_id, $job_reject_int_list)) {
                $minus_from_reject = true;
            }

            $appcounts = $minus_from_apliclist && $get_tcounts['applicants'] > 0 ? (absint($get_tcounts['applicants']) - 1) : $get_tcounts['applicants'];
            $shappcounts = $minus_from_shortlist && $get_tcounts['shortlisted'] > 0 ? (absint($get_tcounts['shortlisted']) - 1) : $get_tcounts['shortlisted'];
            $rejappcounts = $minus_from_reject && $get_tcounts['rejected'] > 0 ? (absint($get_tcounts['rejected']) - 1) : $get_tcounts['rejected'];
            
            $this->total_internal_applics_update($appcounts, $shappcounts, $rejappcounts);
        }
    }
    
    public function on_delete_post_internal_applics_count($post_id) {
        if (get_post_type($post_id) == 'job') {
            $job_id = $post_id;
            
            $job_applicants_list = get_post_meta($job_id, 'jobsearch_job_applicants_list', true);
            $job_applicants_list = jobsearch_is_post_ids_array($job_applicants_list, 'candidate');

            if (!empty($job_applicants_list)) {
                foreach ($job_applicants_list as $jobapp_id) {
                    jobsearch_remov_job_applicant_bycid($job_id, $jobapp_id);
                }
            }
            
            $job_reject_int_list = get_post_meta($job_id, '_job_reject_interview_list', true);
            $job_reject_int_list = $job_reject_int_list != '' ? explode(',', $job_reject_int_list) : '';

            if (!empty($job_reject_int_list)) {
                foreach ($job_reject_int_list as $jobapp_id) {
                    jobsearch_remov_job_applicant_bycid($job_id, $jobapp_id);
                }
            }
        }
        if (get_post_type($post_id) == 'candidate') {
            global $wpdb;
            $candidate_id = $post_id;

            $user_id = jobsearch_get_candidate_user_id($candidate_id);

            $cleaned_jobs = array();

            $applied_jobs = get_user_meta($user_id, 'jobsearch-user-jobs-applied-list', true);

            if (!empty($applied_jobs) && is_array($applied_jobs)) {
                foreach ($applied_jobs as $aplied_itm) {
                    $job_id = isset($aplied_itm['post_id']) ? (int) $aplied_itm['post_id'] : 0;

                    if ($job_id > 0) {
                        jobsearch_remov_job_applicant_bycid($job_id, $candidate_id);
                        $cleaned_jobs[$job_id] = true;
                    }
                }
            }

            // Fallback sweep: the applied-list can be incomplete (imported or
            // employer-added candidates, stale meta) or the user id may be
            // unresolved when the candidate is deleted. Find every job that
            // still references this candidate in any of the three lists and
            // clean it too, so no orphan id is left behind. The CONCAT wrap
            // makes ',<id>,' a whole-token match so e.g. 12 can't match 123.
            $ref_jobs = $wpdb->get_col($wpdb->prepare(
                "SELECT DISTINCT post_id FROM {$wpdb->postmeta}
                 WHERE meta_key IN ('jobsearch_job_applicants_list', '_job_short_interview_list', '_job_reject_interview_list')
                 AND CONCAT(',', meta_value, ',') LIKE %s",
                '%,' . absint($candidate_id) . ',%'
            ));

            if (!empty($ref_jobs)) {
                foreach ($ref_jobs as $job_id) {
                    $job_id = (int) $job_id;
                    if ($job_id > 0 && empty($cleaned_jobs[$job_id])) {
                        jobsearch_remov_job_applicant_bycid($job_id, $candidate_id);
                    }
                }
            }
        }
    }

}

new jobsearch_count_total_applicants;
