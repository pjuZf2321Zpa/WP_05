<?php
// Direct access not allowed.
if (!defined('ABSPATH')) {
    exit;
}

/**
 * File Type: JobSearch Email
 */
if (!class_exists('JobSearch_Email')) {

    class JobSearch_Email {

        // Last wp_mail() failure reason captured by jobsearch_dispatch_email().
        // Lets callers (e.g. the admin test-send) report the PHPMailer error even
        // when no email log post exists (logging OFF = no post is created).
        public $last_send_error = '';

        public function __construct() {
            //add_action('wp_ajax_jobsearch_process_emails', array($this, 'jobsearch_process_emails_callback'), 99);
            //add_action('wp_ajax_nopriv_jobsearch_process_emails', array($this, 'jobsearch_process_emails_callback'), 99);
            add_action('jobsearch_send_mail', array($this, 'jobsearch_send_mail_callback'), 20, 1);
            add_action('wp_ajax_jobsearch_email_log_clear_cronjob', array($this, 'jobsearch_email_log_clear_cronjob_callback'));
            // No nopriv binding — handler is admin-only (gated by current_user_can('administrator')).

            // Admin-only test-send: lets admins verify the wp_mail() pipeline works
            // (and surface the PHPMailer error if it doesn't) without waiting for a
            // real flow to trigger an email.
            add_action('wp_ajax_jobsearch_email_test_send', array($this, 'jobsearch_email_test_send_callback'));

            //
            //add_filter('wp_mail_from', array($this, 'sender_email'));
            //add_filter('wp_mail_from_name', array($this, 'sender_name'));
        }

        public function sender_email($original_email_address) {
            $field_db_slug = "jobsearch_email_templates";
            $email_all_templates_saved_data = get_option($field_db_slug);
            $from = isset($email_all_templates_saved_data['jobsearch_email_template_sender_email']) ? $email_all_templates_saved_data['jobsearch_email_template_sender_email'] : '';
            if ($from != '') {
                $original_email_address = $from;
            }
            return $original_email_address;
        }

        // Function to change sender name
        public function sender_name($original_email_from) {
            global $sitepress;
            $lang_code = '';
            if (function_exists('icl_object_id') && function_exists('wpml_init_language_switcher')) {
                $lang_code = $sitepress->get_current_language();
            }
            $field_db_slug = "jobsearch_email_templates";
            $email_all_templates_saved_data = get_option($field_db_slug);
            $from_name = isset($email_all_templates_saved_data['jobsearch_email_template_sender_name']) ? $email_all_templates_saved_data['jobsearch_email_template_sender_name'] : '';

            if (function_exists('icl_object_id') && function_exists('wpml_init_language_switcher')) {
                $temp_trnaslated = get_option('jobsearch_translate_email_templates');
                if (isset($temp_trnaslated['global_settings']['lang_' . $lang_code]['sender_name'])) {
                    $from_name = $temp_trnaslated['global_settings']['lang_' . $lang_code]['sender_name'];
                }
            }

            if ($from_name != '') {
                $original_email_from = $from_name;
            }
            return $original_email_from;
        }

        public function jobsearch_send_mail_callback($args) {
            global $jobsearch_plugin_options;

            $jobsearch__options = get_option('jobsearch_plugin_options');
            $email_logs_switch = isset($jobsearch__options['jobsearch-email-log-switch']) ? $jobsearch__options['jobsearch-email-log-switch'] : 'off'; // by default

            $send_to = (isset($args['to'])) ? $args['to'] : '';
            $subject = (isset($args['subject'])) ? $args['subject'] : '';
            $message = (isset($args['message'])) ? $args['message'] : '';
            // Build headers array WITHOUT a manual `From:` line. The From/From-Name
            // are owned by the wp_mail_from / wp_mail_from_name filters inside
            // jobsearch_process_emails_callback — pushing a manual `From:` here
            // would conflict and silently override the admin-configured sender.
            $headers = array();
            $email_type = 'plain_text';
            if (isset($args['email_type'])) {
                $email_type = $args['email_type'];
            }

            $from_email = '';
            if (isset($args['from_email']) && $args['from_email'] != '') {
                $from_email = $args['from_email'];
            }

            // Preserve any per-template custom headers (Reply-To, BCC, etc.) the
            // caller wanted to add, but never let them override the From line.
            if (isset($args['headers']) && is_array($args['headers'])) {
                foreach ($args['headers'] as $h) {
                    if (is_string($h) && stripos(trim($h), 'from:') === 0) {
                        continue; // skip any From header pushed by a caller
                    }
                    $headers[] = $h;
                }
            }
            $class_obj = ( isset($args['class_obj']) ) ? $args['class_obj'] : '';

            $send_ok = false;
            if ($email_logs_switch == 'on') {
                // Logging ON: create and KEEP the email log post, then send from it.
                $post_id = $this->jobsearch_save_email(array(
                    'sent_to' => $send_to,
                    'from_email' => $from_email,
                    'subject' => $subject,
                    'message' => $message,
                    'headers' => $headers,
                    'email_type' => $email_type,
                ));
                if ($post_id != 0) {
                    $send_ok = (bool) $this->jobsearch_process_emails_callback($post_id, $args);
                }
            } else {
                // Logging OFF: never create a post (no create-then-delete) — send
                // the email directly through the same dispatch path. Content is
                // already resolved by the caller (options-table template, file
                // fallback), so the source priority is unchanged either way.
                $this->jobsearch_register_from_filters($args);
                $send_ok = (bool) $this->jobsearch_dispatch_email(array(
                    'send_to'    => $send_to,
                    'subject'    => html_entity_decode($subject),
                    'message'    => $message,
                    'headers'    => $headers,
                    'email_type' => $email_type,
                ), $args, 0);
            }

            if ($class_obj != '') {
                // Reflect the actual wp_mail() result so verifier-style callers
                // (e.g. JobSearch_Social_Link_Verifier) can detect failures and
                // clean up pending state instead of believing every send succeeds.
                $class_obj->is_email_sent = $send_ok;
            }
        }

        public function jobsearch_save_email($args) {
            // Create post object
            $email_post = array(
                'post_title' => $args['subject'],
                'post_content' => $args['message'],
                'post_status' => 'publish',
                'post_type' => 'email',
            );
            // The email body is a trusted, system-generated HTML document built
            // from the admin-configured templates (full <!DOCTYPE>/<html>/<head>/
            // <style> + MSO conditional comments). wp_insert_post() runs
            // post_content through wp_kses for any user WITHOUT 'unfiltered_html'
            // — i.e. every guest / front-end flow, such as the nopriv "resend
            // activation email" action and ordinary candidate/employer sends.
            // KSES strips <head>/<style>/<!DOCTYPE>, collapses <o:..>/<xml> tags
            // and mangles the MSO comments, which dumps the raw CSS into the email.
            // Admins (who have 'unfiltered_html') were never affected, which is
            // why the admin test-send always looked fine. Suspend the KSES content
            // filters around this internal insert, then restore them immediately.
            $jobsearch_kses_suspended = false;
            if (!current_user_can('unfiltered_html') && function_exists('kses_remove_filters')) {
                kses_remove_filters();
                $jobsearch_kses_suspended = true;
            }
            // Insert the post into the database.
            $id = wp_insert_post($email_post);
            if ($jobsearch_kses_suspended) {
                kses_init_filters();
            }

            if (!is_wp_error($id)) {
                update_post_meta($id, 'email_status', 'new');
                update_post_meta($id, 'email_send_satus', 0);
                update_post_meta($id, 'email_headers', $args['headers']);
                update_post_meta($id, 'email_send_to', $args['sent_to']);
                update_post_meta($id, 'email_from', $args['from_email']);
                update_post_meta($id, 'email_type', $args['email_type']);
                return $id;
            } else {
                return 0;
            }
        }

        /**
         * Register the From / From-Name filters from the admin-configured sender
         * settings. Shared by the post-based send path (jobsearch_process_emails_
         * callback) and the direct, no-log send path so the sender identity is
         * identical regardless of whether an email log post is created.
         */
        public function jobsearch_register_from_filters($mail_args = array()) {

            add_filter('wp_mail_from', function ($original_email_address) use ($mail_args) {
                $field_db_slug = "jobsearch_email_templates";
                $email_all_templates_saved_data = get_option($field_db_slug);
                $from = isset($email_all_templates_saved_data['jobsearch_email_template_sender_email']) ? trim($email_all_templates_saved_data['jobsearch_email_template_sender_email']) : '';

                if ($from !== '' && is_email($from)) {
                    return $from;
                }
                // No admin-configured sender. Do NOT fall back to admin_email —
                // it often lives on a different domain than the site (e.g.
                // client@gmail.com on a site at client-site.com), which causes
                // SPF/DMARC rejections at Gmail/Outlook/Yahoo. WordPress's own
                // default is wordpress@<site-host>, which at least matches the
                // From: domain to the site domain — return that explicitly.
                $home_host = wp_parse_url(home_url(), PHP_URL_HOST);
                if (is_string($home_host) && $home_host !== '') {
                    $home_host = preg_replace('/^www\./i', '', $home_host);
                    return 'wordpress@' . $home_host;
                }
                return $original_email_address;
            });

            add_filter('wp_mail_from_name', function ($original_email_from) use ($mail_args) {
                global $sitepress;
                $lang_code = '';
                if (function_exists('icl_object_id') && function_exists('wpml_init_language_switcher')) {
                    $lang_code = $sitepress->get_current_language();
                }
                $field_db_slug = "jobsearch_email_templates";
                $email_all_templates_saved_data = get_option($field_db_slug);
                $from_name = isset($email_all_templates_saved_data['jobsearch_email_template_sender_name']) ? $email_all_templates_saved_data['jobsearch_email_template_sender_name'] : '';

                if (function_exists('icl_object_id') && function_exists('wpml_init_language_switcher')) {
                    $temp_trnaslated = get_option('jobsearch_translate_email_templates');
                    if (isset($temp_trnaslated['global_settings']['lang_' . $lang_code]['sender_name'])) {
                        $from_name = $temp_trnaslated['global_settings']['lang_' . $lang_code]['sender_name'];
                    }
                }

                $site_name = get_bloginfo('name');
                if ($site_name != '') {
                    $original_email_from = $site_name;
                }

                if ($from_name != '') {
                    $original_email_from = $from_name;
                }
                return $original_email_from;
            });
        }

        /**
         * Send one already-resolved email through wp_mail(). Shared by the
         * post-based path and the direct (no-log) path. When $log_post_id > 0 the
         * send status / error are recorded on that log post; the failure reason is
         * always captured in $this->last_send_error for callers without a post.
         */
        public function jobsearch_dispatch_email($email, $mail_args = array(), $log_post_id = 0) {
            $send_to    = isset($email['send_to']) ? $email['send_to'] : '';
            $subject    = isset($email['subject']) ? $email['subject'] : '';
            $message    = isset($email['message']) ? $email['message'] : '';
            $headers    = (isset($email['headers']) && is_array($email['headers'])) ? $email['headers'] : array();
            $email_type = isset($email['email_type']) ? $email['email_type'] : '';

            if (!empty($email_type)) {
                if ($email_type == 'html') {
                    add_filter('wp_mail_content_type', function () {
                        return 'text/html';
                    });
                } else {
                    add_filter('wp_mail_content_type', function () {
                        return 'text/plain';
                    });
                }
            }

            $email_from_name = isset($mail_args['from_name']) ? html_entity_decode($mail_args['from_name']) : '';
            $email_from_email = isset($mail_args['from_email']) ? $mail_args['from_email'] : '';

            // Reply-To: set if a from_email is provided (with or without name).
            // Strip CR/LF to defend against header injection.
            if ($email_from_email != '' && is_email(trim($email_from_email))) {
                $clean_name = preg_replace('/[\r\n]+/', ' ', (string) $email_from_name);
                $clean_email = trim($email_from_email);
                $headers[] = $clean_name !== ''
                    ? 'Reply-To: ' . $clean_name . ' <' . $clean_email . '>'
                    : 'Reply-To: ' . $clean_email;
            }

            $attachment = '';
            if (isset($mail_args['att_file_path']) && $mail_args['att_file_path'] != '') {
                $attachment = $mail_args['att_file_path'];
            }

            $send_to = str_replace(' ', '', $send_to);
            $send_to_adrs = explode(',', $send_to);

            // Capture PHPMailer's error reason if wp_mail returns false.
            $last_error = '';
            $err_listener = function ($wp_error) use (&$last_error) {
                if (is_wp_error($wp_error)) {
                    $last_error = $wp_error->get_error_message();
                }
            };
            add_action('wp_mail_failed', $err_listener);

            $confirm = false;
            if (!empty($send_to_adrs) && sizeof($send_to_adrs) > 1) {
                // Multi-recipient: track if ALL sends succeeded.
                $confirm = true;
                foreach ($send_to_adrs as $email_to) {
                    $one_ok = wp_mail($email_to, $subject, $message, $headers, $attachment);
                    if (!$one_ok) {
                        $confirm = false;
                    }
                }
            } else {
                $confirm = (bool) wp_mail($send_to, $subject, $message, $headers, $attachment);
            }

            remove_action('wp_mail_failed', $err_listener);

            $this->last_send_error = $last_error;

            if (!$confirm && $last_error !== '') {
                // Persist the error reason on the email log post (if any) and to
                // debug.log so admins can diagnose delivery failures without
                // enabling SMTP just to add visibility.
                if ($log_post_id > 0) {
                    update_post_meta($log_post_id, 'email_error', $last_error);
                }
                if (function_exists('error_log')) {
                    error_log(sprintf(
                        '[jobsearch email] wp_mail FAILED — to=%s subject=%s reason=%s',
                        $send_to,
                        $subject,
                        $last_error
                    ));
                }
            }

            if ($log_post_id > 0) {
                update_post_meta($log_post_id, 'email_status', 'processed');
                update_post_meta($log_post_id, 'email_send_satus', $confirm ? 1 : 0);
            }

            return $confirm;
        }

        public function jobsearch_process_emails_callback($_post_id = 0, $mail_args = array()) {

            $this->jobsearch_register_from_filters($mail_args);

            $args = array(
                'post_type' => 'email',
            );

            if ($_post_id > 0) {
                $post_id = $_post_id;
            } else {
                $post_id = isset($_REQUEST['post_id']) ? $_REQUEST['post_id'] : 0;
            }
            //update_post_meta($post_id, 'email_status', 'new');

            if ($post_id != 0) {
                $args['post__in'] = array(intval($post_id));
            }
            $args['meta_query'] = array(
                array(
                    'key' => 'email_status',
                    'value' => 'new',
                    'compare' => 'LIKE',
                )
            );
            $query = new WP_Query($args);

            if ($query->have_posts()) {
                $confirm = false;
                while ($query->have_posts()) {
                    $query->the_post();
                    $email_log_post_id = get_the_ID();
                    $email_obj = get_post($email_log_post_id);
                    $email_content = $email_obj->post_content;
                    $subject = html_entity_decode(get_the_title());
                    $send_to = get_post_meta($email_log_post_id, 'email_send_to', true);
                    $headers = get_post_meta($email_log_post_id, 'email_headers', true);
                    $email_type = get_post_meta($email_log_post_id, 'email_type', true);
                    $headers = !empty($headers) ? $headers : array();

                    // Same dispatch the no-log path uses; records status/error on
                    // this log post via the $log_post_id argument.
                    $confirm = (bool) $this->jobsearch_dispatch_email(array(
                        'send_to'    => $send_to,
                        'subject'    => $subject,
                        'message'    => $email_content,
                        'headers'    => $headers,
                        'email_type' => $email_type,
                    ), $mail_args, $email_log_post_id);
                }
                wp_reset_postdata();
                return isset($confirm) ? (bool) $confirm : false;
            } else {
                //echo esc_html__('No Posts found', 'wp-jobsearch');
                return false;
            }
            //wp_die();
        }

        public function jobsearch_email_log_clear_cronjob_callback() {
            $nonce_val = isset($_POST['_nonce']) ? sanitize_key(wp_unslash($_POST['_nonce'])) : '';
            if (!wp_verify_nonce($nonce_val, 'jobsearch_ajax_nonce')) {
                wp_send_json(array(
                    'error' => '1',
                    'msg'   => esc_html__('Session expired. Please reload the page and try again.', 'wp-jobsearch'),
                ));
            }
            if (!is_super_admin() && !current_user_can('administrator')) {
                wp_send_json(array(
                    'error' => '1',
                    'msg'   => esc_html__('You are not allowed to do this.', 'wp-jobsearch'),
                ));
            }

            // Iterate the 'email' log posts in pages so a very large table
            // doesn't blow up memory. Use a direct $wpdb->get_col query (not
            // get_posts/WP_Query) so registration flags on the CPT —
            // public=false, publicly_queryable=false, exclude_from_search=true
            // — don't filter the results out. Then wp_delete_post() (force=true)
            // so postmeta is cleaned up by WP core and hooks fire properly.
            global $wpdb;
            $deleted = 0;
            $failed  = 0;
            $batch_size = 500;
            do {
                $ids = $wpdb->get_col($wpdb->prepare(
                    "SELECT ID FROM {$wpdb->posts} WHERE post_type = %s ORDER BY ID ASC LIMIT %d",
                    'email',
                    $batch_size
                ));
                if (empty($ids)) {
                    break;
                }
                foreach ($ids as $id) {
                    $res = wp_delete_post((int) $id, true);
                    if ($res !== false && $res !== null) {
                        $deleted++;
                    } else {
                        $failed++;
                    }
                    // Per-post object-cache invalidation (belt-and-suspenders —
                    // wp_delete_post calls this internally too, but persistent
                    // object-cache drop-ins sometimes hold stale list-query
                    // results that aren't keyed per-post).
                    clean_post_cache((int) $id);
                }
                // If wp_delete_post failed for every row in the batch we'd
                // loop forever; break out in that case.
                if ($failed > 0 && $deleted === 0) {
                    break;
                }
            } while (count($ids) === $batch_size);

            // Bust every cache layer that might still be serving the stale
            // email-log admin list. Each call is a no-op if its plugin isn't
            // active, so this is safe to call unconditionally.
            $this->purge_email_log_caches();

            wp_send_json(array(
                'error'   => '0',
                'msg'     => sprintf(
                    /* translators: %d: number of email log entries deleted */
                    esc_html(_n('%d email log entry was cleared.', '%d email log entries were cleared.', $deleted, 'wp-jobsearch')),
                    $deleted
                ),
                'deleted' => $deleted,
                'failed'  => $failed,
            ));
        }

        /**
         * Bust every cache layer that might still be serving the stale
         * email-log admin list after a bulk delete. Each branch is a no-op
         * when its plugin/backend isn't active.
         *
         *  - Object cache:   wp_cache_flush_group('posts')  (LiteSpeed, Redis,
         *                    Memcached drop-ins all support this since 2022)
         *  - Object cache:   wp_cache_delete_multiple()    (last-resort
         *                    bucket invalidation for the queries-cache)
         *  - LiteSpeed:      do_action('litespeed_purge_posttype', 'email')
         *  - WP Fastest:     wpfc_clear_all_cache()
         *  - WP Rocket:      rocket_clean_domain()
         *  - WP Optimize:    WPO_Page_Cache::instance()->purge()
         *  - WP Super Cache: wp_cache_clean_cache()
         *  - Cache Enabler:  Cache_Enabler::clear_complete_cache()
         */
        protected function purge_email_log_caches() {
            // 1. Object-cache: flush the 'posts' group. LiteSpeed's drop-in
            //    supports group-flush. Avoids the hammer of wp_cache_flush().
            if (function_exists('wp_cache_flush_group')) {
                wp_cache_flush_group('posts');
                wp_cache_flush_group('post_meta');
            }

            // 2. LiteSpeed Cache — page cache + per-post-type tag.
            do_action('litespeed_purge_posttype', 'email');
            do_action('litespeed_purge', 'pt_email');

            // 3. WP Fastest Cache (free + premium).
            if (function_exists('wpfc_clear_all_cache')) {
                wpfc_clear_all_cache(true);
            }

            // 4. WP Rocket.
            if (function_exists('rocket_clean_domain')) {
                rocket_clean_domain();
            }

            // 5. WP Optimize.
            if (class_exists('WPO_Page_Cache') && method_exists('WPO_Page_Cache', 'instance')) {
                $wpo = call_user_func(array('WPO_Page_Cache', 'instance'));
                if (is_object($wpo) && method_exists($wpo, 'purge')) {
                    $wpo->purge();
                }
            }

            // 6. WP Super Cache.
            if (function_exists('wp_cache_clean_cache')) {
                global $file_prefix;
                wp_cache_clean_cache(isset($file_prefix) ? $file_prefix : '', true);
            }

            // 7. Cache Enabler.
            if (class_exists('Cache_Enabler') && method_exists('Cache_Enabler', 'clear_complete_cache')) {
                call_user_func(array('Cache_Enabler', 'clear_complete_cache'));
            }

            // 8. Last-resort hook so addons can clear their own caches.
            do_action('jobsearch_email_log_cleared');
        }

        /**
         * Admin test-send: sends a simple plaintext email through the same
         * wp_mail() pipeline the templates use, captures success and the
         * PHPMailer error if any, and returns a diagnostic JSON payload.
         *
         * Bound to wp_ajax_jobsearch_email_test_send (admin-only, no nopriv).
         */
        public function jobsearch_email_test_send_callback() {
            $nonce_val = isset($_POST['_nonce']) ? sanitize_key(wp_unslash($_POST['_nonce'])) : '';
            if (!current_user_can('administrator') || !wp_verify_nonce($nonce_val, 'jobsearch_ajax_nonce')) {
                wp_send_json(array(
                    'error' => '1',
                    'msg'   => esc_html__('You are not allowed to do this.', 'wp-jobsearch'),
                ));
            }

            $to = isset($_POST['to']) ? sanitize_email(wp_unslash($_POST['to'])) : '';
            if (!is_email($to)) {
                // Default to current admin's email if no override provided.
                $cur = wp_get_current_user();
                $to  = isset($cur->user_email) ? $cur->user_email : get_bloginfo('admin_email');
            }
            if (!is_email($to)) {
                wp_send_json(array(
                    'error' => '1',
                    'msg'   => esc_html__('No valid recipient email available.', 'wp-jobsearch'),
                ));
            }

            $site_name = wp_specialchars_decode(get_bloginfo('name'), ENT_QUOTES);

            // Per-template test send: if the caller passed subject + content,
            // use them (allows admin to verify the actual template's rendered
            // HTML in a real inbox). Shortcodes like {candidate_name} aren't
            // resolved here — they appear literally — but the wp_mail()
            // pipeline, From/Reply-To headers, and HTML rendering are
            // exercised exactly as in production.
            $req_subject = isset($_POST['subject']) ? wp_unslash($_POST['subject']) : '';
            $req_content = isset($_POST['content']) ? wp_unslash($_POST['content']) : '';
            $req_type    = isset($_POST['template_type']) ? sanitize_key(wp_unslash($_POST['template_type'])) : '';

            $req_subject = trim((string) $req_subject);
            $req_content = (string) $req_content;

            if ($req_subject !== '') {
                $subject = '[TEST] ' . $req_subject;
            } else {
                $subject = sprintf(esc_html__('[%s] Test email from JobSearch', 'wp-jobsearch'), $site_name);
            }

            if ($req_content !== '') {
                $message = '<div style="background:#fff3cd; border:1px solid #ffeeba; color:#856404; padding:10px 14px; margin:0 0 16px; border-radius:6px; font:13px/1.5 Arial,sans-serif;">'
                         . esc_html__('This is a TEST send from the email-templates editor. Shortcodes (e.g. {candidate_name}) are NOT resolved in a test — they show as placeholders.', 'wp-jobsearch')
                         . ($req_type !== '' ? ' <strong>' . esc_html__('Template:', 'wp-jobsearch') . '</strong> ' . esc_html($req_type) : '')
                         . '</div>'
                         . $req_content;
            } else {
                $message = '<p>' . esc_html__('This is a test email sent from your JobSearch email-templates settings.', 'wp-jobsearch') . '</p>'
                         . '<p>' . esc_html__('If you received it, your wp_mail() pipeline is reachable. If delivery to public providers (Gmail, Outlook, Yahoo) is still unreliable, the issue is upstream (SPF/DKIM/DMARC on your sending domain) and an SMTP plugin is recommended.', 'wp-jobsearch') . '</p>'
                         . "<p style='color:#888; font-size:12px;'>" . esc_html__('Sent at: ', 'wp-jobsearch') . esc_html(current_time('mysql')) . '</p>';
            }

            // Run the test send through the same dispatch path real emails use,
            // so the result reflects production behaviour. Honour the "Save Email
            // Log" switch the same way: ON → plant a log post (kept + tagged as a
            // manual test); OFF → send directly without ever creating a post.
            $jobsearch__options = get_option('jobsearch_plugin_options');
            $email_logs_switch = isset($jobsearch__options['jobsearch-email-log-switch']) ? $jobsearch__options['jobsearch-email-log-switch'] : 'off';

            $this->last_send_error = '';

            if ($email_logs_switch === 'on') {
                $post_id = $this->jobsearch_save_email(array(
                    'sent_to'    => $to,
                    'from_email' => '',
                    'subject'    => $subject,
                    'message'    => $message,
                    'headers'    => array(),
                    'email_type' => 'html',
                ));

                if (!$post_id) {
                    wp_send_json(array(
                        'error' => '1',
                        'msg'   => esc_html__('Could not create the test email log entry.', 'wp-jobsearch'),
                    ));
                }

                $send_ok = (bool) $this->jobsearch_process_emails_callback($post_id, array(
                    'email_type' => 'html',
                ));
                // Tag the log entry so it's recognisable as a manual test.
                update_post_meta($post_id, 'email_is_test', '1');
            } else {
                $this->jobsearch_register_from_filters(array());
                $send_ok = (bool) $this->jobsearch_dispatch_email(array(
                    'send_to'    => $to,
                    'subject'    => html_entity_decode($subject),
                    'message'    => $message,
                    'headers'    => array(),
                    'email_type' => 'html',
                ), array('email_type' => 'html'), 0);
            }

            // Failure reason captured by dispatch (works with or without a post).
            $err = $this->last_send_error;

            if ($send_ok) {
                wp_send_json(array(
                    'error' => '0',
                    'msg'   => sprintf(esc_html__('Test email sent to %s. Check the inbox (and spam folder) within ~1 minute.', 'wp-jobsearch'), $to),
                ));
            }

            wp_send_json(array(
                'error' => '1',
                'msg'   => $err !== ''
                    ? sprintf(esc_html__('wp_mail() returned false. PHPMailer error: %s', 'wp-jobsearch'), $err)
                    : esc_html__('wp_mail() returned false. PHP mail() likely isn\'t configured on this server — install an SMTP plugin (WP Mail SMTP / FluentSMTP) and connect a transactional provider.', 'wp-jobsearch'),
            ));
        }
    }

    new JobSearch_Email();
}
