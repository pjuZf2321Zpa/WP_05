<?php

/**
 * WP JobSearch — Database Upgrader.
 *
 * Version-controlled database upgrade framework. When the stored DB version is
 * older than the plugin code version (e.g. right after a plugin update), admins
 * are forced to the "Database Update" page until the pending upgrade steps run.
 *
 * @package JobSearch_plugin
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('JobSearch_Upgrader')) {

    class JobSearch_Upgrader {

        // Single consolidated state option (JSON/array) instead of several rows:
        //   array( 'db_version' => '', 'flag' => '', 'steps' => array(), 'total' => 0 )
        const STATE_OPTION = 'jobsearch_upgrade_state';
        const MIN_VERSION = '2.8';                  // upgrade only applies above this version
        const PAGE_SLUG = 'jobsearch-db-upgrade';
        const NONCE_ACTION = 'jobsearch_db_upgrade';

        public function __construct() {
            add_action('admin_menu', array($this, 'register_page'), 99);
            add_action('admin_init', array($this, 'maybe_force_redirect'), 1);
            add_action('in_admin_header', array($this, 'hide_admin_notices'), 1000);
            add_action('wp_ajax_jobsearch_run_db_upgrade', array($this, 'ajax_run_upgrade'));
        }

        /** Strip all admin notices on the Database Update page to keep it clean. */
        public function hide_admin_notices() {
            $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';
            if ($page !== self::PAGE_SLUG) {
                return;
            }
            remove_all_actions('admin_notices');
            remove_all_actions('all_admin_notices');
            remove_all_actions('user_admin_notices');
            remove_all_actions('network_admin_notices');
        }

        /** Plugin code version (from the plugin header via JobSearch_plugin). */
        public static function code_version() {
            if (class_exists('JobSearch_plugin') && method_exists('JobSearch_plugin', 'get_version')) {
                return JobSearch_plugin::get_version();
            }
            return '0';
        }

        /** Whole upgrade state (single option row) merged with defaults. */
        public static function get_state() {
            $defaults = array('db_version' => '', 'flag' => '', 'steps' => array(), 'total' => 0);
            $state = get_option(self::STATE_OPTION, array());
            if (!is_array($state)) {
                $state = array();
            }
            return array_merge($defaults, $state);
        }

        /** Persist the state (not autoloaded — read only on admin upgrade flow). */
        private function save_state($state) {
            update_option(self::STATE_OPTION, $state, false);
        }

        /** Stored database version ('' when never stamped). */
        public static function db_version() {
            $state = self::get_state();
            return $state['db_version'];
        }

        /** Stored upgrade-completion flag ('' when not set). */
        public static function upgrade_flag() {
            $state = self::get_state();
            return $state['flag'];
        }

        /** Version check — the plugin code version is greater than MIN_VERSION (2.8). */
        public function version_gate_passed() {
            return version_compare(self::code_version(), self::MIN_VERSION, '>');
        }

        /** Flag check — the completion flag is not set in the options table. */
        public function flag_missing() {
            return self::upgrade_flag() === '';
        }

        /**
         * Upgrade page is forced ONLY when the plugin version is greater than
         * MIN_VERSION (2.8) AND the completion flag is not set in the options table.
         */
        public function needs_upgrade() {
            return $this->version_gate_passed() && $this->flag_missing();
        }

        /**
         * Version-keyed upgrade step registry. Add a new entry per release that
         * needs a data migration. The 'version' is the code version that
         * introduces the step.
         */
        public function get_steps() {
            return array(
                array(
                    'version' => '3.3.3',
                    'key'     => 'peruser_options_to_meta',
                    'label'   => esc_html__('Move per-user options to user meta', 'wp-jobsearch'),
                    'desc'    => esc_html__('Relocates the per-user "assigned ads" flag and "selected PDF template" rows out of the autoloaded options table into user meta, then removes the option rows. Fixes options-table bloat.', 'wp-jobsearch'),
                ),
                array(
                    'version' => '3.3.3',
                    'key'     => 'postauthors_update',
                    'label'   => esc_html__('Backfill post authors', 'wp-jobsearch'),
                    'desc'    => esc_html__('Sets the correct post_author on job, employer and candidate posts from their stored user-id / posted-by meta.', 'wp-jobsearch'),
                ),
                array(
                    'version' => '3.3.3',
                    'key'     => 'autoload_cleanup',
                    'label'   => esc_html__('Stop autoloading heavy options', 'wp-jobsearch'),
                    'desc'    => esc_html__('Flips the large email-templates option (and autoloaded transients / banner counters) to autoload=no so they are no longer loaded on every page. No data is changed.', 'wp-jobsearch'),
                ),
            );
        }

        /** Steps not yet marked done in the consolidated state. */
        public function pending_steps() {
            $state = self::get_state();
            $done = (isset($state['steps']) && is_array($state['steps'])) ? $state['steps'] : array();
            $pending = array();
            foreach ($this->get_steps() as $step) {
                if (empty($done[$step['key']])) {
                    $pending[] = $step;
                }
            }
            return $pending;
        }

        /** Count option rows still awaiting the per-user migration. */
        private function peruser_remaining() {
            global $wpdb;
            return (int) $wpdb->get_var(
                "SELECT COUNT(*) FROM {$wpdb->options}
                 WHERE option_name LIKE 'jobsearch_user_assign_advs\\_%'
                    OR option_name LIKE 'jobsearch_selected_pdf_template\\_%'"
            );
        }

        public function register_page() {
            add_submenu_page(
                'wp_jobsearch_admin_menu',
                esc_html__('Database Update', 'wp-jobsearch'),
                esc_html__('Database Update', 'wp-jobsearch'),
                'manage_options',
                self::PAGE_SLUG,
                array($this, 'render_page')
            );
        }

        /**
         * Force admins to the upgrade page when an upgrade is pending.
         * Admin area only — front-end stays live. Skips AJAX/cron/CLI and the
         * core/plugin update screens to avoid interrupting updates or looping.
         */
        public function maybe_force_redirect() {
            if (wp_doing_ajax() || (defined('DOING_CRON') && DOING_CRON) || (defined('WP_CLI') && WP_CLI)) {
                return;
            }
            if (!current_user_can('manage_options')) {
                return;
            }
            if (!$this->needs_upgrade()) {
                return;
            }
            $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';
            if ($page === self::PAGE_SLUG) {
                return;
            }
            global $pagenow;
            $skip = array('update.php', 'update-core.php', 'admin-ajax.php', 'async-upload.php', 'plugin-editor.php', 'theme-editor.php', 'plugins.php');
            if (in_array($pagenow, $skip, true)) {
                return;
            }
            wp_safe_redirect(admin_url('admin.php?page=' . self::PAGE_SLUG));
            exit;
        }

        /**
         * AJAX: run one batch of the pending upgrade and report progress.
         * Loops (driven by JS) until no rows remain, then stamps the DB version.
         */
        public function ajax_run_upgrade() {
            $nonce = isset($_POST['_nonce']) ? sanitize_key(wp_unslash($_POST['_nonce'])) : '';
            if (!current_user_can('manage_options') || !wp_verify_nonce($nonce, self::NONCE_ACTION)) {
                wp_send_json(array('error' => 1, 'msg' => esc_html__('You are not allowed to do this.', 'wp-jobsearch')));
            }

            $state     = self::get_state();
            $remaining = $this->peruser_remaining();

            // Record the progress total once (stored inside the single state row).
            $total = (int) $state['total'];
            if ($total <= 0) {
                $total = $remaining;
                $state['total'] = $total;
                $this->save_state($state);
            }

            // Run one batch of the per-user options -> user meta migration.
            $this->run_peruser_migration_batch();

            $remaining = $this->peruser_remaining();
            $migrated  = max(0, $total - $remaining);
            $percent   = $total > 0 ? min(100, (int) round(($migrated / $total) * 100)) : 100;

            if ($remaining > 0) {
                wp_send_json(array(
                    'done'      => 0,
                    'percent'   => $percent,
                    'migrated'  => $migrated,
                    'total'     => $total,
                    'remaining' => $remaining,
                ));
            }

            // Per-user migration drained. Run the remaining (non-batched) steps,
            // then write version, flag, completed steps and clear progress — all
            // in the single consolidated state option.
            $state = self::get_state();
            $state['steps']['peruser_options_to_meta'] = true;

            if (empty($state['steps']['postauthors_update'])) {
                $this->run_postauthors_update();
                $state['steps']['postauthors_update'] = true;
            }

            if (empty($state['steps']['autoload_cleanup'])) {
                $this->run_autoload_cleanup();
                $state['steps']['autoload_cleanup'] = true;
            }

            $this->cleanup_legacy_options();

            $state['db_version'] = self::code_version();
            $state['flag']       = self::code_version();
            $state['total']      = 0;
            $this->save_state($state);

            wp_send_json(array(
                'done'    => 1,
                'percent' => 100,
                'version' => self::code_version(),
                'msg'     => esc_html__('Database updated successfully.', 'wp-jobsearch'),
            ));
        }

        /**
         * Migrate one batch (500 rows) of the per-user options into user meta and
         * delete the source option rows. The AJAX loop drives this until none
         * remain — no separate done-flag option is needed.
         */
        private function run_peruser_migration_batch() {
            global $wpdb;
            $rows = $wpdb->get_results(
                "SELECT option_name, option_value FROM {$wpdb->options}
                 WHERE option_name LIKE 'jobsearch_user_assign_advs\\_%'
                    OR option_name LIKE 'jobsearch_selected_pdf_template\\_%'
                 LIMIT 500"
            );
            if (empty($rows)) {
                return;
            }
            foreach ($rows as $row) {
                if (strpos($row->option_name, 'jobsearch_user_assign_advs_') === 0) {
                    $meta_key = 'jobsearch_user_assign_advs';
                    $user_id  = absint(substr($row->option_name, strlen('jobsearch_user_assign_advs_')));
                } else {
                    $meta_key = 'jobsearch_selected_pdf_template';
                    $user_id  = absint(substr($row->option_name, strlen('jobsearch_selected_pdf_template_')));
                }
                if ($user_id > 0) {
                    update_user_meta($user_id, $meta_key, maybe_unserialize($row->option_value));
                }
                delete_option($row->option_name);
            }
        }

        /**
         * Backfill post_author on job / employer / candidate posts from their
         * stored user-id / posted-by meta (one idempotent UPDATE). Formerly the
         * standalone jobsearch_update_post_authors_from_meta() on admin_init.
         */
        private function run_postauthors_update() {
            global $wpdb;
            $query = "
                UPDATE {$wpdb->posts} p
                LEFT JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
                LEFT JOIN {$wpdb->posts} e ON p.post_type = %s AND pm.meta_key = 'jobsearch_field_job_posted_by' AND e.ID = pm.meta_value AND e.post_type = 'employer'
                SET p.post_author = CASE
                    WHEN p.post_type = 'employer' AND pm.meta_key = 'jobsearch_user_id' AND pm.meta_value REGEXP '^[0-9]+$' THEN pm.meta_value
                    WHEN p.post_type = 'candidate' AND pm.meta_key = 'jobsearch_user_id' AND pm.meta_value REGEXP '^[0-9]+$' THEN pm.meta_value
                    WHEN p.post_type = 'job' AND e.post_author IS NOT NULL THEN e.post_author
                    ELSE p.post_author
                END
                WHERE (p.post_type = 'employer' AND pm.meta_key = 'jobsearch_user_id')
                   OR (p.post_type = 'candidate' AND pm.meta_key = 'jobsearch_user_id')
                   OR (p.post_type = 'job' AND pm.meta_key = 'jobsearch_field_job_posted_by');
            ";
            $result = $wpdb->query($wpdb->prepare($query, 'job'));
            if ($result === false) {
                error_log('JobSearch upgrader: post author backfill failed: ' . $wpdb->last_error);
            }
        }

        /**
         * Stop autoloading heavy / never-needed-on-every-request options. Flips
         * the autoload flag only — no option values are changed. Reversible.
         */
        private function run_autoload_cleanup() {
            global $wpdb;
            // Big email-templates blob (~hundreds of KB) — only needed when
            // sending/managing email. Use core API when available (handles cache).
            if (function_exists('wp_set_option_autoload')) {
                wp_set_option_autoload('jobsearch_email_templates', false);
            } else {
                $wpdb->update($wpdb->options, array('autoload' => 'no'), array('option_name' => 'jobsearch_email_templates'));
            }
            // Transients and per-banner click counters should never autoload.
            $wpdb->query(
                "UPDATE {$wpdb->options} SET autoload = 'no'
                 WHERE autoload NOT IN ('no', 'off', 'auto-off')
                   AND ( option_name LIKE '%\\_transient\\_%'
                      OR option_name LIKE 'banner_click\\_%' )"
            );
            // Rebuild the alloptions cache so the change takes effect immediately.
            wp_cache_delete('alloptions', 'options');
        }

        /**
         * Delete legacy single-purpose option rows now folded into the
         * consolidated jobsearch_upgrade_state. Safe no-op if they don't exist.
         */
        private function cleanup_legacy_options() {
            $legacy = array(
                'jobsearch_postauthors_update',
                'jobsearch_db_version',
                'jobsearch_db_upgrade_flag',
                'jobsearch_peruser_opts_meta_migrated',
            );
            foreach ($legacy as $opt) {
                delete_option($opt);
            }
        }

        public function render_page() {
            if (!current_user_can('manage_options')) {
                return;
            }
            $code_ver  = self::code_version();
            $db_ver    = self::db_version();
            $db_ver_lbl = $db_ver !== '' ? $db_ver : esc_html__('Not set', 'wp-jobsearch');
            $needs     = $this->needs_upgrade();
            $flag_val  = self::upgrade_flag();
            $flag_lbl  = $flag_val !== '' ? $flag_val : esc_html__('Not set', 'wp-jobsearch');
            $ver_ok    = $this->version_gate_passed();
            $flag_ok   = !$this->flag_missing();
            $pending   = $this->pending_steps();
            $nonce     = wp_create_nonce(self::NONCE_ACTION);
            $dash_url  = admin_url('admin.php?page=wp_jobsearch_admin_menu');
            ?>
            <div class="wrap jobsearch-dbup-wrap">
                <div class="jobsearch-dbup-header">
                    <div class="jobsearch-dbup-header-left">
                        <span class="dashicons dashicons-database"></span>
                        <div>
                            <h1><?php esc_html_e('WP JobSearch — Database Update', 'wp-jobsearch'); ?></h1>
                            <p><?php esc_html_e('A new plugin version is installed. Run the database update to finish upgrading.', 'wp-jobsearch'); ?></p>
                        </div>
                    </div>
                    <div class="jobsearch-dbup-badges">
                        <span class="jobsearch-dbup-badge"><?php esc_html_e('Plugin', 'wp-jobsearch'); ?> <strong><?php echo esc_html($code_ver); ?></strong></span>
                        <span class="jobsearch-dbup-badge"><?php esc_html_e('Database', 'wp-jobsearch'); ?> <strong><?php echo esc_html($db_ver_lbl); ?></strong></span>
                        <span class="jobsearch-dbup-badge"><?php esc_html_e('Flag', 'wp-jobsearch'); ?> <strong><?php echo esc_html($flag_lbl); ?></strong></span>
                    </div>
                </div>

                <div class="jobsearch-dbup-card jobsearch-dbup-status <?php echo $needs ? 'is-pending' : 'is-current'; ?>">
                    <span class="jobsearch-dbup-status-icon dashicons <?php echo $needs ? 'dashicons-update' : 'dashicons-yes-alt'; ?>"></span>
                    <div class="jobsearch-dbup-status-text">
                        <h2><?php echo $needs ? esc_html__('Update required', 'wp-jobsearch') : esc_html__('Database is up to date', 'wp-jobsearch'); ?></h2>
                        <p>
                            <?php
                            if ($needs) {
                                printf(
                                    /* translators: 1: plugin version, 2: minimum version */
                                    esc_html__('Plugin version %1$s is newer than %2$s and the database update flag is not set.', 'wp-jobsearch'),
                                    '<code>' . esc_html($code_ver) . '</code>',
                                    '<code>' . esc_html(self::MIN_VERSION) . '</code>'
                                );
                            } else {
                                printf(esc_html__('Everything is running on version %s.', 'wp-jobsearch'), '<code>' . esc_html($code_ver) . '</code>');
                            }
                            ?>
                        </p>
                        <ul class="jobsearch-dbup-checks">
                            <li class="<?php echo $ver_ok ? 'ok' : 'bad'; ?>">
                                <span class="dashicons <?php echo $ver_ok ? 'dashicons-yes' : 'dashicons-no-alt'; ?>"></span>
                                <?php esc_html_e('Version check', 'wp-jobsearch'); ?>:
                                <?php esc_html_e('plugin', 'wp-jobsearch'); ?> <code><?php echo esc_html($code_ver); ?></code> &gt; <code><?php echo esc_html(self::MIN_VERSION); ?></code>
                            </li>
                            <li class="<?php echo $flag_ok ? 'ok' : 'bad'; ?>">
                                <span class="dashicons <?php echo $flag_ok ? 'dashicons-yes' : 'dashicons-no-alt'; ?>"></span>
                                <?php esc_html_e('Flag check', 'wp-jobsearch'); ?>:
                                <code><?php echo esc_html(self::STATE_OPTION); ?>['flag']</code> = <code><?php echo esc_html($flag_lbl); ?></code>
                            </li>
                        </ul>
                    </div>
                </div>

                <?php if ($needs) { ?>
                    <div class="jobsearch-dbup-card">
                        <h3 class="jobsearch-dbup-steps-title"><?php esc_html_e('Pending updates', 'wp-jobsearch'); ?></h3>
                        <ul class="jobsearch-dbup-steps">
                            <?php if (!empty($pending)) {
                                foreach ($pending as $step) { ?>
                                    <li>
                                        <span class="dashicons dashicons-arrow-right-alt2"></span>
                                        <div>
                                            <strong><?php echo esc_html($step['label']); ?></strong>
                                            <span class="jobsearch-dbup-step-ver"><?php echo esc_html($step['version']); ?></span>
                                            <p><?php echo esc_html($step['desc']); ?></p>
                                        </div>
                                    </li>
                                <?php }
                            } else { ?>
                                <li><span class="dashicons dashicons-arrow-right-alt2"></span><div><strong><?php esc_html_e('Version stamp only — no data migration needed.', 'wp-jobsearch'); ?></strong></div></li>
                            <?php } ?>
                        </ul>

                        <div class="jobsearch-dbup-progress" style="display:none;">
                            <div class="jobsearch-dbup-progress-info">
                                <span class="jobsearch-dbup-progress-label"><?php esc_html_e('Updating…', 'wp-jobsearch'); ?></span>
                                <span class="jobsearch-dbup-progress-pct">0%</span>
                            </div>
                            <div class="jobsearch-dbup-progress-bar"><div class="jobsearch-dbup-progress-fill" style="width:0%"></div></div>
                        </div>

                        <div class="jobsearch-dbup-actions">
                            <button type="button" id="jobsearch-dbup-run" class="jobsearch-dbup-btn" data-nonce="<?php echo esc_attr($nonce); ?>">
                                <span class="dashicons dashicons-update"></span>
                                <?php esc_html_e('Run Database Update', 'wp-jobsearch'); ?>
                            </button>
                            <span class="jobsearch-dbup-note"><?php esc_html_e('Keep this tab open until it finishes.', 'wp-jobsearch'); ?></span>
                        </div>
                        <div class="jobsearch-dbup-result" style="display:none;"></div>
                    </div>
                <?php } else { ?>
                    <p><a class="jobsearch-dbup-btn jobsearch-dbup-btn-ghost" href="<?php echo esc_url($dash_url); ?>"><?php esc_html_e('Go to WP JobSearch', 'wp-jobsearch'); ?></a></p>
                <?php } ?>
            </div>

            <style>
                .jobsearch-dbup-wrap { max-width: 860px; margin: 20px auto 40px; }
                .jobsearch-dbup-wrap * { box-sizing: border-box; }
                .jobsearch-dbup-header {
                    background: linear-gradient(135deg, #2271b1 0%, #135e96 100%);
                    color: #fff; border-radius: 12px; padding: 26px 30px; margin-bottom: 22px;
                    display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 16px;
                    box-shadow: 0 6px 22px rgba(34,113,177,.22);
                }
                .jobsearch-dbup-header-left { display: flex; align-items: center; gap: 16px; }
                .jobsearch-dbup-header-left .dashicons { font-size: 38px; width: 38px; height: 38px; opacity: .92; }
                .jobsearch-dbup-header h1 { color: #fff; font-size: 22px; font-weight: 600; margin: 0 0 4px; line-height: 1.2; }
                .jobsearch-dbup-header p { margin: 0; color: rgba(255,255,255,.85); font-size: 13px; }
                .jobsearch-dbup-badges { display: flex; gap: 10px; flex-wrap: wrap; }
                .jobsearch-dbup-badge { background: rgba(255,255,255,.14); border: 1px solid rgba(255,255,255,.32); border-radius: 30px; padding: 7px 14px; font-size: 12px; }
                .jobsearch-dbup-badge strong { font-weight: 700; margin-left: 4px; }
                .jobsearch-dbup-card { background: #fff; border: 1px solid #e0e3e7; border-radius: 12px; padding: 22px 24px; margin-bottom: 18px; box-shadow: 0 1px 3px rgba(0,0,0,.04); }
                .jobsearch-dbup-status { display: flex; align-items: flex-start; gap: 16px; border-left: 5px solid #d63638; }
                .jobsearch-dbup-status.is-current { border-left-color: #2ea043; }
                .jobsearch-dbup-status-icon { font-size: 30px; width: 30px; height: 30px; color: #d63638; }
                .jobsearch-dbup-status.is-current .jobsearch-dbup-status-icon { color: #2ea043; }
                .jobsearch-dbup-status-text h2 { margin: 0 0 4px; font-size: 17px; }
                .jobsearch-dbup-status-text p { margin: 0; color: #5b6270; font-size: 13px; }
                .jobsearch-dbup-status code { background: #f1f3f7; padding: 1px 7px; border-radius: 5px; font-size: 12px; }
                .jobsearch-dbup-checks { margin: 12px 0 0; padding: 0; list-style: none; display: flex; flex-wrap: wrap; gap: 8px 20px; }
                .jobsearch-dbup-checks li { display: flex; align-items: center; gap: 6px; font-size: 12.5px; color: #5b6270; }
                .jobsearch-dbup-checks li .dashicons { font-size: 16px; width: 16px; height: 16px; }
                .jobsearch-dbup-checks li.ok .dashicons { color: #2ea043; }
                .jobsearch-dbup-checks li.bad .dashicons { color: #d63638; }
                .jobsearch-dbup-checks code { background: #f1f3f7; padding: 1px 6px; border-radius: 5px; font-size: 11.5px; }
                .jobsearch-dbup-steps-title { margin: 0 0 14px; font-size: 15px; }
                .jobsearch-dbup-steps { margin: 0 0 6px; padding: 0; list-style: none; }
                .jobsearch-dbup-steps li { display: flex; gap: 10px; padding: 12px 0; border-top: 1px solid #f0f1f4; }
                .jobsearch-dbup-steps li:first-child { border-top: 0; }
                .jobsearch-dbup-steps .dashicons { color: #2271b1; margin-top: 2px; }
                .jobsearch-dbup-steps strong { font-size: 14px; }
                .jobsearch-dbup-step-ver { display: inline-block; margin-left: 8px; background: #eef4fb; color: #2271b1; border-radius: 20px; padding: 1px 9px; font-size: 11px; font-weight: 600; }
                .jobsearch-dbup-steps p { margin: 4px 0 0; color: #6a7180; font-size: 12.5px; }
                .jobsearch-dbup-progress { margin: 18px 0; }
                .jobsearch-dbup-progress-info { display: flex; justify-content: space-between; font-size: 12px; color: #5b6270; margin-bottom: 6px; }
                .jobsearch-dbup-progress-bar { height: 12px; background: #eef0f4; border-radius: 20px; overflow: hidden; }
                .jobsearch-dbup-progress-fill { height: 100%; width: 0; background: linear-gradient(90deg,#2271b1,#34a0e0); border-radius: 20px; transition: width .35s ease; }
                .jobsearch-dbup-actions { display: flex; align-items: center; gap: 14px; margin-top: 18px; flex-wrap: wrap; }
                .jobsearch-dbup-btn {
                    display: inline-flex; align-items: center; gap: 7px; cursor: pointer;
                    background: #2271b1; color: #fff; border: 1px solid #2271b1; border-radius: 8px;
                    padding: 11px 22px; font-size: 14px; font-weight: 600; transition: all .18s ease; text-decoration: none;
                }
                .jobsearch-dbup-btn:hover { background: #135e96; border-color: #135e96; color: #fff; }
                .jobsearch-dbup-btn:disabled { opacity: .6; cursor: default; }
                .jobsearch-dbup-btn .dashicons { font-size: 18px; width: 18px; height: 18px; }
                .jobsearch-dbup-btn.is-running .dashicons { animation: jobsearch-dbup-spin 1s linear infinite; }
                .jobsearch-dbup-btn-ghost { background: #fff; color: #2271b1; }
                .jobsearch-dbup-note { color: #8a90a0; font-size: 12px; }
                .jobsearch-dbup-result { margin-top: 16px; padding: 12px 16px; border-radius: 8px; font-size: 13px; display: none; }
                .jobsearch-dbup-result.ok { background: #edf7ed; color: #1e6b2a; border: 1px solid #b7e0bf; }
                .jobsearch-dbup-result.err { background: #fcebec; color: #a3262a; border: 1px solid #f0b8ba; }
                @keyframes jobsearch-dbup-spin { to { transform: rotate(360deg); } }
            </style>

            <script>
                (function ($) {
                    var $btn = $('#jobsearch-dbup-run');
                    if (!$btn.length) { return; }
                    var nonce = $btn.data('nonce');
                    var $wrap = $('.jobsearch-dbup-wrap');
                    var $progress = $wrap.find('.jobsearch-dbup-progress');
                    var $fill = $wrap.find('.jobsearch-dbup-progress-fill');
                    var $pct = $wrap.find('.jobsearch-dbup-progress-pct');
                    var $label = $wrap.find('.jobsearch-dbup-progress-label');
                    var $result = $wrap.find('.jobsearch-dbup-result');
                    var running = false;

                    function setProgress(r) {
                        var p = (typeof r.percent !== 'undefined') ? r.percent : 0;
                        $fill.css('width', p + '%');
                        $pct.text(p + '%');
                        if (typeof r.total !== 'undefined' && r.total > 0) {
                            $label.text('<?php echo esc_js(__('Migrating', 'wp-jobsearch')); ?> ' + (r.migrated || 0) + ' / ' + r.total);
                        }
                    }

                    function fail(msg) {
                        running = false;
                        $btn.prop('disabled', false).removeClass('is-running');
                        $result.removeClass('ok').addClass('err').text(msg).show();
                    }

                    function runBatch() {
                        $.post(ajaxurl, { action: 'jobsearch_run_db_upgrade', _nonce: nonce }, function (r) {
                            if (!r || r.error) { fail(r && r.msg ? r.msg : '<?php echo esc_js(__('Update failed.', 'wp-jobsearch')); ?>'); return; }
                            setProgress(r);
                            if (parseInt(r.done, 10) === 1) {
                                $result.removeClass('err').addClass('ok').text(r.msg).show();
                                $label.text('<?php echo esc_js(__('Done', 'wp-jobsearch')); ?>');
                                setTimeout(function () { window.location.href = '<?php echo esc_js($dash_url); ?>'; }, 1200);
                            } else {
                                runBatch();
                            }
                        }, 'json').fail(function () { fail('<?php echo esc_js(__('Network error. Please retry.', 'wp-jobsearch')); ?>'); });
                    }

                    $btn.on('click', function (e) {
                        e.preventDefault();
                        if (running) { return; }
                        running = true;
                        $btn.prop('disabled', true).addClass('is-running');
                        $progress.show();
                        $result.hide();
                        runBatch();
                    });
                })(jQuery);
            </script>
            <?php
        }
    }

    new JobSearch_Upgrader();
}
