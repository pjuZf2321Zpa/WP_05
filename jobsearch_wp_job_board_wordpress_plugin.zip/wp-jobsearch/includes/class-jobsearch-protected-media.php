<?php

/**
 * WP JobSearch — Protected media proxy.
 *
 * Candidate profile photo, cover photo and portfolio images live in the
 * "deny from all" uploads folders, so they can't be served by a direct URL.
 * Instead of inlining base64 (heavy, uncacheable), this serves them through a
 * signed, cacheable endpoint:
 *
 *   <img src="/?jobsearch_pmedia={opaque-encrypted-token}">
 *
 * The token is an AES-encrypted, MAC-authenticated blob of (candidate id | type |
 * ident | version). Nothing about the candidate is readable or enumerable from
 * the URL, and it can't be tampered with. The version is derived from the stored
 * file, so the token is stable for caching and auto-busts when the image changes;
 * a changed or deleted image makes the endpoint return 404 on any cache-miss
 * request.
 *
 * Access control (locked vs visible) is enforced at RENDER time by the display
 * functions (they only emit a signed URL when the photo should be shown, and a
 * placeholder otherwise) — a cacheable URL can't be made per-viewer.
 *
 * @package JobSearch_plugin
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('JobSearch_Protected_Media')) {

    class JobSearch_Protected_Media {

        const QV = 'jobsearch_pmedia';
        const TYPES = array('avatar', 'cover', 'portfolio');

        public function __construct() {
            add_action('init', array($this, 'maybe_serve'), 0);
            add_filter('robots_txt', array($this, 'robots_txt'), 10, 2);
        }

        /**
         * Known AI-training / scraper crawlers to hard-block (403) from the media
         * endpoint. These self-identify by User-Agent; blocking here ENFORCES it
         * (unlike robots.txt / noindex which only request compliance). The list is
         * filterable so the site owner can extend it.
         */
        private static function blocked_agents() {
            return apply_filters('jobsearch_pmedia_blocked_agents', array(
                'GPTBot', 'ChatGPT-User', 'OAI-SearchBot', 'ClaudeBot', 'anthropic-ai',
                'Claude-Web', 'Google-Extended', 'CCBot', 'PerplexityBot', 'Bytespider',
                'Amazonbot', 'Applebot-Extended', 'Diffbot', 'ImagesiftBot', 'Omgili',
                'cohere-ai', 'Meta-ExternalAgent', 'FacebookBot', 'YouBot', 'Scrapy',
                'DataForSeoBot', 'magpie-crawler', 'Timpibot', 'PetalBot',
            ));
        }

        private static function is_blocked_agent() {
            $ua = isset($_SERVER['HTTP_USER_AGENT']) ? (string) $_SERVER['HTTP_USER_AGENT'] : '';
            if ($ua === '') {
                return false;
            }
            foreach (self::blocked_agents() as $bot) {
                if (stripos($ua, $bot) !== false) {
                    return true;
                }
            }
            return false;
        }

        /** Append AI/scraper opt-out rules to the virtual robots.txt. */
        public function robots_txt($output, $public) {
            $rules = "\n# WP JobSearch: keep protected candidate media out of AI/scraper crawlers\n";
            foreach (self::blocked_agents() as $bot) {
                $rules .= 'User-agent: ' . $bot . "\n";
            }
            $rules .= "Disallow: /*jobsearch_pmedia=\n";
            return $output . $rules;
        }

        private static function secret() {
            return wp_salt('auth');
        }

        private static function enc_key() {
            return hash('sha256', 'jsmedia-enc|' . wp_salt('auth'), true);
        }

        private static function mac_key() {
            return hash('sha256', 'jsmedia-mac|' . wp_salt('secure_auth'), true);
        }

        private static function b64url_encode($data) {
            return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
        }

        private static function b64url_decode($data) {
            return base64_decode(strtr($data, '-_', '+/'));
        }

        /**
         * Pack (cid|type|ident|version) into a single opaque, tamper-proof token.
         * The fields are AES-encrypted, so nothing about the candidate is readable
         * or enumerable from the URL. Deterministic (same inputs => same token) so
         * the URL stays stable for browser/CDN caching.
         */
        private static function encode_token($cid, $type, $ident, $ver) {
            $payload = $cid . '|' . $type . '|' . $ident . '|' . $ver;

            // Preferred: AES-encrypted so the candidate id is unreadable in the URL.
            // OpenSSL ships with virtually every PHP build (incl. shared hosts); the
            // signed fallback below keeps images working on the rare host without it.
            if (function_exists('openssl_encrypt')) {
                $iv = substr(hash_hmac('sha256', $payload, self::enc_key(), true), 0, 16);
                $cipher = openssl_encrypt($payload, 'aes-256-cbc', self::enc_key(), OPENSSL_RAW_DATA, $iv);
                if ($cipher !== false) {
                    $blob = $iv . $cipher;
                    $tag = substr(hash_hmac('sha256', $blob, self::mac_key()), 0, 24);
                    return 'e.' . self::b64url_encode($blob) . '.' . $tag;
                }
            }

            // Fallback (no OpenSSL): signed — tamper-proof, id only base64-obscured.
            $body = self::b64url_encode($payload);
            $tag = substr(hash_hmac('sha256', $body, self::mac_key()), 0, 24);
            return 's.' . $body . '.' . $tag;
        }

        /** Verify (MAC) + decrypt a token back to its fields, or false if invalid. */
        private static function decode_token($token) {
            $parts = explode('.', $token);
            if (count($parts) !== 3) {
                return false;
            }
            list($scheme, $body, $tag) = $parts;

            if ($scheme === 'e') {
                if (!function_exists('openssl_decrypt')) {
                    return false;
                }
                $blob = self::b64url_decode($body);
                if ($blob === false || strlen($blob) <= 16) {
                    return false;
                }
                if (!hash_equals(substr(hash_hmac('sha256', $blob, self::mac_key()), 0, 24), $tag)) {
                    return false;
                }
                $iv = substr($blob, 0, 16);
                $cipher = substr($blob, 16);
                $payload = openssl_decrypt($cipher, 'aes-256-cbc', self::enc_key(), OPENSSL_RAW_DATA, $iv);
            } elseif ($scheme === 's') {
                if (!hash_equals(substr(hash_hmac('sha256', $body, self::mac_key()), 0, 24), $tag)) {
                    return false;
                }
                $payload = self::b64url_decode($body);
            } else {
                return false;
            }

            if ($payload === false || $payload === '') {
                return false;
            }
            $f = explode('|', $payload, 4);
            if (count($f) !== 4) {
                return false;
            }
            return array('cid' => absint($f[0]), 'type' => $f[1], 'ident' => $f[2], 'ver' => $f[3]);
        }

        /** Version token derived from the stored file URL (changes when the image changes). */
        private static function version_for($stored_url) {
            return substr(sha1((string) $stored_url . '|' . self::secret()), 0, 12);
        }

        /**
         * The stored file URL that identifies a type/ident, or '' if none stored.
         * Used for both the version token and the existence check; `file_url`
         * (avatar/cover) and `orig` (portfolio) are always present when a file
         * is stored, and change when the image is re-uploaded.
         */
        private static function stored_url($candidate_id, $type, $ident) {
            if ($type === 'avatar') {
                $m = get_post_meta($candidate_id, 'jobsearch_user_avatar_url', true);
                return (is_array($m) && !empty($m['file_url'])) ? $m['file_url'] : '';
            }
            if ($type === 'cover') {
                $m = get_post_meta($candidate_id, 'jobsearch_user_cover_imge', true);
                return (is_array($m) && !empty($m['file_url'])) ? $m['file_url'] : '';
            }
            if ($type === 'portfolio') {
                $arr = get_post_meta($candidate_id, 'jobsearch_portfolio_imgs_arr', true);
                return (is_array($arr) && isset($arr[$ident]) && !empty($arr[$ident]['orig'])) ? $arr[$ident]['orig'] : '';
            }
            return '';
        }

        /**
         * Build a signed, cacheable URL for a protected candidate image.
         * Returns '' when there is no stored protected file (caller then keeps
         * using gravatar / placeholder / legacy URL as before).
         *
         * @param int    $candidate_id
         * @param string $type   avatar|cover|portfolio
         * @param string $ident  avatar: size (150|full); portfolio: numeric key; cover: ''
         */
        public static function signed_url($candidate_id, $type, $ident = '') {
            $candidate_id = absint($candidate_id);
            $ident = (string) $ident;
            if ($candidate_id < 1 || !in_array($type, self::TYPES, true)) {
                return '';
            }
            $stored = self::stored_url($candidate_id, $type, $ident);
            if ($stored === '') {
                return '';
            }
            $ver = self::version_for($stored);
            $token = self::encode_token($candidate_id, $type, $ident, $ver);
            if ($token === '') {
                return '';
            }
            return add_query_arg(array(self::QV => $token), home_url('/'));
        }

        /**
         * Resolve the actual file path + extension to stream for a type/ident.
         * This mirrors the exact resolution the old base64 display functions used,
         * so the served file is identical — only the transport changes.
         */
        private static function file_for($candidate_id, $type, $ident) {
            if ($type === 'avatar') {
                $m = get_post_meta($candidate_id, 'jobsearch_user_avatar_url', true);
                if (!is_array($m) || empty($m['file_url'])) {
                    return array('', '');
                }
                $folder_path = $m['file_path'];
                $file_name = isset($m['file_name']) ? $m['file_name'] : '';
                $ext = isset($m['mime_type']['ext']) ? $m['mime_type']['ext'] : 'png';
                if (!$ext) {
                    $ext = 'jpg';
                }
                $orig = isset($m['orig_file_url']) ? jobsearch_url_str_reomve_http($m['orig_file_url']) : '';
                $site_url_str = jobsearch_url_str_reomve_http(get_site_url() . '/');
                if ($ident === 'full') {
                    $file_path = $folder_path . '/' . $file_name;
                    if ($orig != '') {
                        $file_path = str_replace($site_url_str, ABSPATH, $orig);
                    }
                } else {
                    $file_path = $folder_path . '/user-img-150.' . $ext;
                    if (!file_exists($file_path) && $orig != '') {
                        $file_path = str_replace($site_url_str, ABSPATH, $orig);
                    }
                }
                return array($file_path, $ext);
            }
            if ($type === 'cover') {
                $m = get_post_meta($candidate_id, 'jobsearch_user_cover_imge', true);
                if (!is_array($m) || empty($m['file_url'])) {
                    return array('', '');
                }
                $ext = isset($m['mime_type']['ext']) ? $m['mime_type']['ext'] : 'png';
                $file_path = $m['file_path'] . '/' . (isset($m['file_name']) ? $m['file_name'] : '');
                return array($file_path, $ext);
            }
            if ($type === 'portfolio') {
                $arr = get_post_meta($candidate_id, 'jobsearch_portfolio_imgs_arr', true);
                if (!is_array($arr) || !isset($arr[$ident]) || empty($arr[$ident]['path'])) {
                    return array('', '');
                }
                $file_path = $arr[$ident]['path'];
                $file_url = isset($arr[$ident]['orig']) ? $arr[$ident]['orig'] : '';
                $filetype = wp_check_filetype(basename($file_url), null);
                $ext = isset($filetype['ext']) && $filetype['ext'] ? $filetype['ext'] : 'png';
                if (!file_exists($file_path) && $file_url != '') {
                    $file_path = str_replace(get_site_url() . '/', ABSPATH, $file_url);
                }
                return array($file_path, $ext);
            }
            return array('', '');
        }

        /** Serve a protected image when our signed query var is present. */
        public function maybe_serve() {
            if (!isset($_GET[self::QV])) {
                return;
            }

            // 0) Hard-block known AI/scraper crawlers (enforced 403, not a request).
            if (self::is_blocked_agent()) {
                status_header(403);
                exit;
            }

            // 1) Verify + decrypt the opaque token (also the tamper-proof check).
            $token = sanitize_text_field(wp_unslash($_GET[self::QV]));
            $decoded = self::decode_token($token);
            if ($decoded === false) {
                status_header(403);
                exit;
            }
            $cid   = $decoded['cid'];
            $type  = $decoded['type'];
            $ident = $decoded['ident'];
            $ver   = $decoded['ver'];

            if ($cid < 1 || !in_array($type, self::TYPES, true)) {
                status_header(404);
                exit;
            }

            // 2) Version must still match the current stored file (handles change/delete).
            $stored = self::stored_url($cid, $type, $ident);
            if ($stored === '' || self::version_for($stored) !== $ver) {
                status_header(404);
                exit;
            }

            list($path, $ext) = self::file_for($cid, $type, $ident);

            // 3) Containment: the resolved file must live inside the uploads dir.
            $uploads = wp_upload_dir();
            $real_base = realpath(untrailingslashit($uploads['basedir']));
            $real_file = $path !== '' ? realpath($path) : false;
            if ($real_file === false || $real_base === false || strpos($real_file, $real_base) !== 0 || !is_file($real_file)) {
                status_header(404);
                exit;
            }

            $mime = 'image/' . ($ext === 'jpg' ? 'jpeg' : $ext);
            $etag = '"' . md5($real_file . '|' . filemtime($real_file)) . '"';

            // Candidate photos are private: allow Google to fetch (so the page still
            // renders) but keep the image itself out of Google Images / search index.
            header('X-Robots-Tag: noindex, noimageindex, nofollow', true);

            if (isset($_SERVER['HTTP_IF_NONE_MATCH']) && trim(wp_unslash($_SERVER['HTTP_IF_NONE_MATCH'])) === $etag) {
                status_header(304);
                exit;
            }

            // Drop any active output buffering / gzip so binary output isn't
            // corrupted and Content-Length stays accurate (shared-host safe).
            while (ob_get_level() > 0) {
                @ob_end_clean();
            }

            header('Content-Type: ' . $mime);
            header('Content-Length: ' . filesize($real_file));
            header('Cache-Control: private, max-age=' . (6 * HOUR_IN_SECONDS));
            header('Pragma: cache');
            header('ETag: ' . $etag);
            readfile($real_file);
            exit;
        }
    }

    new JobSearch_Protected_Media();
}
