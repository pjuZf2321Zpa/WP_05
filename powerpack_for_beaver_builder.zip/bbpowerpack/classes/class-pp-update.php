<?php

/**
 * Helper class for builder updates.
 *
 * @since 2.32
 */
final class BB_PowerPack_Update {

	/**
	 * Number of rollback versions to request from update server.
	 *
	 * @since 2.42.4
	 * @var int
	 */
	const ROLLBACK_VERSION_LIMIT = 5;

	/**
	 * Initialize hooks.
	 *
	 * @return void
	 */
	static public function init() {
		add_action( 'init', __CLASS__ . '::maybe_run', 11 );
		add_action( 'fl_site_url_changed', array( __CLASS__, 'maybe_reregister_license' ), 10, 2 );
		add_action( 'admin_init', array( __CLASS__, 'maybe_process_rollback' ) );
	}

	static public function maybe_reregister_license( $current, $saved ) {
		if ( ! function_exists( 'bb_powerpack_get_license_key' ) ) {
			return;
		}
		$license = bb_powerpack_get_license_key();
		if ( '' !== $license ) {
			bb_powerpack_delete( 'bb_powerpack_license_status' );
			bb_powerpack_license( 'activate_license', $license );
		}
	}

	/**
	 * Checks to see if an update should be run. If it should,
	 * the appropriate update method is run and the version
	 * number is updated in the database.
	 *
	 * @return void
	 */
	static public function maybe_run() {
		// Make sure the user is logged in.
		if ( ! is_user_logged_in() ) {
			return;
		}

		// Only run on the main site for multisite installs.
		if ( is_multisite() && ! is_main_site() ) {
			return;
		}

		// Get the saved version.
		$saved_version = get_site_option( 'bb_powerpack_version' );

		// No saved version number. This must be a fresh install.
		if ( ! $saved_version ) {
			update_site_option( 'bb_powerpack_version', BB_POWERPACK_VER );
			return;
		} elseif ( ! version_compare( $saved_version, BB_POWERPACK_VER, '=' ) ) {

			if ( is_multisite() ) {
				self::run_multisite( $saved_version );
			} else {
				self::run( $saved_version );
			}

			/**
			 * Fires after cache is cleared.
			 * @see fl_builder_cache_cleared
			 */
			do_action( 'fl_builder_cache_cleared' );

			update_site_option( 'bb_powerpack_version', BB_POWERPACK_VER );

			update_site_option( 'bb_powerpack_update_info', array(
				'from' => $saved_version,
				'to'   => BB_POWERPACK_VER,
			) );
		}
	}

	/**
	 * Runs the update for a specific version.
	 *
	 * @access private
	 * @return void
	 */
	static private function run( $saved_version ) {
		if ( is_callable( 'FLBuilderModel::delete_asset_cache_for_all_posts' ) ) {
			// Clear all asset cache.
			FLBuilderModel::delete_asset_cache_for_all_posts();
		}

		if ( version_compare( $saved_version, '2.44.0', '=' ) ) {
			// Reset saved extensions for this version since 2.44.0 update broke the saved extensions format.
			$extensions = pp_extensions();
			$enabled_extensions = BB_PowerPack_Admin_Settings::get_option( 'bb_powerpack_extensions', array() );
			if ( isset( $enabled_extensions['row'] ) && ! is_array( $enabled_extensions['row'] ) ) {
				$enabled_extensions['row'] = $extensions['row'];
			}
			if ( isset( $enabled_extensions['col'] ) && ! is_array( $enabled_extensions['col'] ) ) {
				$enabled_extensions['col'] = $extensions['col'];
			}
			BB_PowerPack_Admin_Settings::update_option( 'bb_powerpack_extensions', $enabled_extensions );
		}
	}

	/**
	 * Runs the update for all sites on a network install.
	 *
	 * @access private
	 * @return void
	 */
	static private function run_multisite( $saved_version ) {
		global $blog_id;
		global $wpdb;

		// Save the original blog id.
		$original_blog_id = $blog_id;

		// Get all blog ids.
		$blog_ids = $wpdb->get_col( "SELECT blog_id FROM $wpdb->blogs" );

		// Loop through the blog ids and run the update.
		foreach ( $blog_ids as $id ) {
			switch_to_blog( $id );
			self::run( $saved_version );
		}

		// Revert to the original blog.
		switch_to_blog( $original_blog_id );
	}

	/**
	 * Handles rollback form submissions.
	 *
	 * @since 2.42.4
	 * @return void
	 */
	static public function maybe_process_rollback() {
		if ( ! is_admin() || ! isset( $_POST['bb_powerpack_do_rollback'] ) ) {
			return;
		}

		if ( ! current_user_can( 'update_plugins' ) ) {
			wp_die( esc_html__( 'You do not have permission to rollback plugins.', 'bb-powerpack' ) );
		}

		if ( ! isset( $_POST['pp-rollback-settings-nonce'] ) || ! wp_verify_nonce( $_POST['pp-rollback-settings-nonce'], 'pp-rollback-settings' ) ) {
			self::redirect_with_rollback_status( 'security_error', __( 'Security check failed. Please try again.', 'bb-powerpack' ) );
		}

		$selected_file_key = isset( $_POST['bb_powerpack_rollback_file_key'] ) ? sanitize_text_field( wp_unslash( $_POST['bb_powerpack_rollback_file_key'] ) ) : '';
		if ( '' === $selected_file_key ) {
			self::redirect_with_rollback_status( 'package_error', __( 'Please select a rollback package.', 'bb-powerpack' ) );
		}

		$files = self::get_remote_rollback_files( true );
		if ( is_wp_error( $files ) ) {
			self::redirect_with_rollback_status( 'files_error', $files->get_error_message() );
		}

		$selected = null;
		foreach ( $files as $file_data ) {
			if ( isset( $file_data['file_key'] ) && $selected_file_key === (string) $file_data['file_key'] ) {
				$selected = $file_data;
				break;
			}
		}

		if ( empty( $selected ) || empty( $selected['package'] ) ) {
			self::redirect_with_rollback_status( 'package_error', __( 'Selected rollback package is no longer available.', 'bb-powerpack' ) );
		}

		$result = self::perform_rollback( $selected['package'] );

		if ( is_wp_error( $result ) ) {
			self::redirect_with_rollback_status( 'error', $result->get_error_message() );
		}

		$label = isset( $selected['name'] ) ? $selected['name'] : __( 'selected package', 'bb-powerpack' );
		/* translators: %s: rollback package label. */
		self::redirect_with_rollback_status( 'success', sprintf( __( 'PowerPack has been rolled back using %s.', 'bb-powerpack' ), $label ) );
	}

	/**
	 * Get rollback files from the update server.
	 *
	 * @since 2.42.4
	 * @param bool $force Whether to bypass cache.
	 * @return array|WP_Error
	 */
	static public function get_remote_rollback_files( $force = false ) {
		$files = bb_powerpack_get_rollback_versions( self::ROLLBACK_VERSION_LIMIT, $force );

		if ( is_wp_error( $files ) ) {
			return $files;
		}

		return is_array( $files ) ? $files : array();
	}

	/**
	 * Performs rollback using remote package URL and WordPress upgrader.
	 *
	 * @since 2.42.4
	 * @param string $package_url Rollback package URL.
	 * @return true|WP_Error
	 */
	static private function perform_rollback( $package_url ) {
		$package_url = esc_url_raw( $package_url );

		if ( empty( $package_url ) || ! wp_http_validate_url( $package_url ) ) {
			return new WP_Error( 'pp_rollback_invalid_package_url', __( 'Rollback package URL is invalid.', 'bb-powerpack' ) );
		}

		if ( ! function_exists( 'is_plugin_active' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
		require_once ABSPATH . 'wp-admin/includes/class-plugin-upgrader.php';

		$was_active = is_plugin_active( BB_POWERPACK_PATH );
		$upgrader   = new Plugin_Upgrader( new Automatic_Upgrader_Skin() );
		$upgrader->init();
		$upgrader->upgrade_strings();

		$result = $upgrader->run(
			array(
				'package'           => $package_url,
				'destination'       => WP_PLUGIN_DIR,
				'clear_destination' => true,
				'clear_working'     => true,
				'hook_extra'        => array(
					'plugin' => BB_POWERPACK_PATH,
					'type'   => 'plugin',
					'action' => 'update',
				),
			)
		);

		if ( is_wp_error( $result ) ) {
			return self::normalize_rollback_upgrader_error( $result );
		}

		if ( false === $result ) {
			if ( is_wp_error( $upgrader->skin->result ) ) {
				return self::normalize_rollback_upgrader_error( $upgrader->skin->result );
			}

			return new WP_Error( 'pp_rollback_failed', __( 'Rollback failed. WordPress could not install the selected package.', 'bb-powerpack' ) );
		}

		if ( $was_active ) {
			$activate = activate_plugin( BB_POWERPACK_PATH, '', is_multisite() );
			if ( is_wp_error( $activate ) ) {
				return $activate;
			}
		}

		delete_site_transient( 'update_plugins' );
		wp_clean_plugins_cache( true );

		return true;
	}

	/**
	 * Convert generic upgrader errors into clearer rollback errors.
	 *
	 * @since 2.42.4
	 * @param \WP_Error $error Upgrader error.
	 * @return \WP_Error
	 */
	static private function normalize_rollback_upgrader_error( $error ) {
		if ( ! is_wp_error( $error ) ) {
			return $error;
		}

		if ( 'download_failed' !== $error->get_error_code() ) {
			return $error;
		}

		$detail = $error->get_error_data();
		if ( is_string( $detail ) && '' !== trim( $detail ) ) {
			return new WP_Error(
				'pp_rollback_download_failed',
				sprintf(
					/* translators: %s: low-level download error detail. */
					__( 'Rollback download failed: %s', 'bb-powerpack' ),
					$detail
				)
			);
		}

		return new WP_Error( 'pp_rollback_download_failed', __( 'Rollback download failed. Please verify the license is active for this site and try again.', 'bb-powerpack' ) );
	}

	/**
	 * Redirects back to the rollback tab with rollback status message.
	 *
	 * @since 2.42.3
	 * @param string $status  success|error.
	 * @param string $message Human readable message.
	 * @return void
	 */
	static private function redirect_with_rollback_status( $status, $message ) {
		$tab = 'rollback';
		if ( version_compare( BB_POWERPACK_VER, '2.42.4', '<' ) ) {
			$tab = 'general';
		}

		$url = add_query_arg(
			array(
				'tab'         => $tab,
				'pp_rollback' => $status,
				'message'     => wp_strip_all_tags( $message ),
			),
			BB_PowerPack_Admin_Settings::get_form_action()
		);

		wp_safe_redirect( $url );
		exit;
	}
}

BB_PowerPack_Update::init();
