;(function($) {

	<?php if($settings->click_action == 'lightbox') : ?>
	$(window).on('load', function() {
		var gallery_selector = $( '.fl-node-<?php echo $id; ?> .pp-photo-gallery' );
		if( gallery_selector.length && typeof $.fn.magnificPopup !== 'undefined') {
			gallery_selector.magnificPopup({
				delegate: '.pp-gallery-item:visible .pp-photo-gallery-content a',
				closeBtnInside: false,
				allowHTMLInTemplate: true,
				type: 'image',
				gallery: {
					enabled: true,
					navigateByImgClick: true,
				},
				'image': {
					titleSrc: function(item) {
						<?php if ( isset( $settings->lightbox_caption ) && $settings->lightbox_caption == 'yes' ) : ?> 
							return item.el.parents('.pp-gallery-item').find('.pp-photo-gallery-caption').first().html();
						<?php else: ?>
							return '';
						<?php endif; ?>
					}
				},
				mainClass: 'mfp-<?php echo $id; ?>'
			});
		}
	});
	<?php endif; ?>

	var options = {
		id: '<?php echo $id ?>',
		layout: '<?php echo $settings->gallery_layout; ?>',
		captions: '<?php echo $settings->show_captions; ?>',
	};

	$(window).on('load', function() {
		gallery_<?php echo $id; ?> = new PPFilterableGallery(options);
	});

	// expandable row fix.
	var state = 0;
	$(document).on('pp_expandable_row_toggle', function(e, selector) {
		if ( selector.is('.pp-er-open') && state === 0 && selector.parent().find( '.fl-node-<?php echo $id; ?>' ).length > 0 ) {
			gallery_<?php echo $id; ?>._reLayout();
			state = 1;
		}
	});

	// accordion fix
	$(document).on('pp-accordion-toggle-complete', function(e, selector) {
		var node = selector.find('.fl-node-<?php echo $id; ?>');
		if ( node.length > 0 && node.is(':visible') && ! node.hasClass( 'relayout-complete' ) ) {
			gallery_<?php echo $id; ?>._reLayout();
			node.addClass( 'relayout-complete' );
		}
	});

	// tabs fix
	$(document).on('pp-tabs-switched', function(e, selector) {
		var node = selector.find('.fl-node-<?php echo $id; ?>');
		if ( node.length > 0 && node.is(':visible') && ! node.hasClass( 'relayout-complete' ) ) {
			gallery_<?php echo $id; ?>._reLayout();
			node.addClass( 'relayout-complete' );
		}
	});

	// window resize fix
	var resizeTimer;
	$(window).on('resize', function() {
		clearTimeout(resizeTimer);
		resizeTimer = setTimeout(function() {
			gallery_<?php echo $id; ?>._reLayout();
		}, 250);
	});

})(jQuery);
