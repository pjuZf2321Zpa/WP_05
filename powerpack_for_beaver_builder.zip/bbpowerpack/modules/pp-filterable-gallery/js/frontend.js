(function($) {
	PPFilterableGallery = function(settings) {
		this.settings       = settings;
		this.nodeClass      = '.fl-node-' + settings.id;
		this.wrapperClass   = this.nodeClass + ' .pp-photo-gallery';
		this.itemClass      = this.wrapperClass + ' .pp-gallery-item';
		this.masonry		= this.settings.layout === 'masonry' ? true : false;
		this.paginationEl   = $(this.nodeClass).find('.pp-filterable-gallery-pagination');
		this.paginationItems = $();
		this.paginationPerPage = 0;

		if ( this._hasItems() ) {
			this._initLayout();
		}
	};

	PPFilterableGallery.prototype = {
		settings        : {},
		nodeClass       : '',
		wrapperClass    : '',
		itemClass       : '',
		filterData		: {},
		postClass       : '',
		gallery         : null,
		matchHeight		: false,
		masonry			: false,

		_hasItems: function() {
			return $(this.itemClass).length > 0;
		},

		_initLayout: function() {
			this._initFilterData();
			this._gridLayout();
			this._initPagination();

			this._hashChange();

			$( window ).on( 'hashchange', this._hashChange.bind( this ) );
		},

		_reLayout: function() {
			var wrap = $(this.wrapperClass);
			if ( ! wrap.is(':visible') ) {
				return;
			}
			if ( wrap.data('isotope') ) {
				wrap.isotope('layout');
			} else {
				this._gridLayout();
			}
		},

		_hashChange: function() {
			setTimeout(function() {
				var hash = location.hash.split('/')[0].replace('!', '');
				if( hash && $(hash).length > 0 ) {
					if ( $(hash).parent().hasClass('pp-gallery-filters') ) {
						$(hash).trigger('click');
					}
				}
			}, 200);
		},

		_initFilterData: function() {
			var filterData = {
				itemSelector: '.pp-gallery-item',
				percentPosition: true,
				transitionDuration: '0.6s',
				isOriginLeft: ! $('body').hasClass( 'rtl' )
			};

			if ( ! this.masonry ) {
				filterData = $.extend( {}, filterData, {
					layoutMode: 'fitRows',
					fitRows: {
						gutter: '.pp-photo-space'
					  },
				} );
			} else {
				filterData = $.extend( {}, filterData, {
					masonry: {
						columnWidth: '.pp-gallery-item',
						gutter: '.pp-photo-space'
					},
				} );
			}

			this.filterData = filterData;
		},

		_gridLayout: function() {
			var node 			= $(this.nodeClass);
			var wrap 			= $(this.wrapperClass);
			var items 			= $(this.itemClass);
			var filterData 		= this.filterData;
			var filters 		= wrap.isotope(filterData);
			var filtersWrap 	= node.find('.pp-gallery-filters');
			var filterToggle 	= node.find('.pp-gallery-filters-toggle');
			var isMasonry		= this.masonry;
			var self			= this;
			
			wrap.imagesLoaded( function() {

				if ( wrap.find( '.pp-gallery-overlay' ).length > 0 ) {
					var imgW = wrap.find( '.pp-gallery-img' ).outerWidth();
					wrap.find( '.pp-gallery-overlay' ).css('max-width', imgW + 'px');
				}

			} );

			filterToggle.off('click').on('click', function () {
				filtersWrap.toggleClass('pp-gallery-filters-open');
			});

			filtersWrap.on('click', '.pp-gallery-filter-label', function() {
				var filterVal = $(this).attr('data-filter');
				filters.isotope({ filter: filterVal });

				filtersWrap.find('.pp-gallery-filter-label').removeClass('pp-filter-active');
				$(this).addClass('pp-filter-active');
				
				filterToggle.find('span.toggle-text').html($(this).text());
				if (filtersWrap.hasClass('pp-gallery-filters-open')) {
					filtersWrap.removeClass('pp-gallery-filters-open');
				}

				self._ensurePerPageItems( filterVal );

				$(document).trigger( 'pp_filterable_gallery_filter_change', [$(this), node] );
				self._updatePaginationVisibility();
			});

			wrap.imagesLoaded( function() {
				node.find('.pp-filter-active').trigger('click');
				if ( isMasonry ) {
					wrap.isotope('layout');
				}

				items.css('visibility', 'visible');
			} );
		},

		_initPagination: function() {
			if ( ! this.paginationEl.length ) {
				return;
			}

			var self     = this;
			var $items   = $( this.nodeClass ).find( 'script.pp-filterable-gallery-items' );

			if ( ! $items.length ) {
				return;
			}

			this.paginationItems = $( $items.html() );
			this.paginationPerPage = parseInt( this.paginationEl.data( 'per-page' ), 10 ) || 0;

			this._updatePaginationVisibility();

			this.paginationEl.find('a').off( 'click' ).on( 'click', function(e) {
 				e.preventDefault();

				var activeFilter = self._getActiveFilter();
				var $itemsToInsert = self._getPaginationItems( activeFilter ).slice( 0, self.paginationPerPage );

				if ( ! $itemsToInsert.length ) {
					self._updatePaginationVisibility();
					return;
				}

				self._insertPaginationItems( $itemsToInsert );
				self._updatePaginationVisibility();
			} );
		},

		_getActiveFilter: function() {
			var activeFilter = $( this.nodeClass ).find( '.pp-gallery-filter-label.pp-filter-active' ).data( 'filter' );

			return activeFilter || '*';
		},

		_getPaginationItems: function( filterVal ) {
			if ( ! this.paginationItems.length ) {
				return $();
			}

			if ( ! filterVal || '*' === filterVal ) {
				return this.paginationItems;
			}

			return this.paginationItems.filter( filterVal );
		},

		_getRenderedItems: function( filterVal ) {
			var $renderedItems = $( this.wrapperClass ).find( '.pp-gallery-item' );

			if ( ! filterVal || '*' === filterVal ) {
				return $renderedItems;
			}

			return $renderedItems.filter( filterVal );
		},

		_insertPaginationItems: function( $items ) {
			var self = this;

			if ( ! $items.length ) {
				return;
			}

			$items.each( function() {
				$(self.wrapperClass).isotope( 'insert', this );
			} );

			this.paginationItems = this.paginationItems.not( $items );
		},

		_ensurePerPageItems: function( filterVal ) {
			if ( ! this.paginationPerPage ) {
				return;
			}

			var renderedCount = this._getRenderedItems( filterVal ).length;
			var itemsRequired = this.paginationPerPage - renderedCount;

			if ( itemsRequired <= 0 ) {
				return;
			}

			var $itemsToInsert = this._getPaginationItems( filterVal ).slice( 0, itemsRequired );

			this._insertPaginationItems( $itemsToInsert );
		},

		_updatePaginationVisibility: function() {
			if ( ! this.paginationEl.length ) {
				return;
			}

			var activeFilter = this._getActiveFilter();
			var remainingItems = this._getPaginationItems( activeFilter );

			if ( remainingItems.length ) {
				this.paginationEl.show();
			} else {
				this.paginationEl.hide();
			}
		}
	};

})(jQuery);
