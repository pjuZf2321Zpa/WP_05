if ( 'object' !== typeof pp_animated_headlines ) {
	var pp_animated_headlines = {};
}

;(function($) {

	pp_animated_headlines['<?php echo $id; ?>'] = new PPAnimatedHeadlines({
        id: '<?php echo $id; ?>',
        headline_style: '<?php echo $settings->headline_style; ?>',
        headline_shape: '<?php echo $settings->headline_shape; ?>',
        animation_type: '<?php echo $settings->animation_type; ?>',
		loop: <?php echo isset( $settings->loop ) && $settings->loop == 'yes' ? 'true' : 'false'; ?>,
		durations: <?php echo json_encode( $module->get_durations() ); ?>,
		isBuilderActive: '<?php echo pp_is_builder_active(); ?>'
    });

})(jQuery);
