<svg class="pp-twin-curves" width="100%" height="<?php echo $height; ?>" viewBox="0 0 1280 140" preserveAspectRatio="none" xmlns="http://www.w3.org/2000/svg">
	<g fill="currentColor">
	<path d="M320 28C160 28 80 49 0 70V0h1280v70c-80 21-160 42-320 42-320 0-320-84-640-84z"></path>
	</g>
</svg>