<?php
/**
 * Rollback settings page.
 *
 * @package bb-powerpack
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

$files = BB_PowerPack_Update::get_remote_rollback_files();

if ( isset( $_GET['pp_rollback'] ) ) {
	$status  = sanitize_text_field( wp_unslash( $_GET['pp_rollback'] ) );
	$message = isset( $_GET['message'] ) ? sanitize_text_field( wp_unslash( $_GET['message'] ) ) : '';
	if ( ! empty( $message ) ) {
		echo '<div class="alert ' . ( 'success' === $status ? 'alert-success' : 'alert-error' ) . ' floating">' . esc_html( $message ) . '</div>';
	}
}

if ( is_wp_error( $files ) ) {
	echo '<p class="description" style="color:#b32d2e;">' . esc_html( $files->get_error_message() ) . '</p>';
	return;
}

if ( empty( $files ) ) {
	echo '<p class="description">' . esc_html__( 'No rollback packages are available for your license right now.', 'bb-powerpack' ) . '</p>';
	return;
}
?>
<div class="pp-admin-settings-content-head">
	<h3><?php esc_html_e( 'Plugin Rollback', 'bb-powerpack' ); ?></h3>
	<p class="description"><?php esc_html_e( 'Download and restore a previous PowerPack version from the update server. This requires an active license and internet connection.', 'bb-powerpack' ); ?></p>
</div>
<form method="post" id="pp-settings-form" action="<?php echo self::get_form_action( '&tab=' . $current_tab ); ?>">
	<table class="form-table">
		<tbody>
			<tr valign="top">
				<th scope="row" valign="top">
					<label for="bb_powerpack_rollback_file_key"><?php esc_html_e('Rollback Version', 'bb-powerpack'); ?></label>
				</th>
				<td>
					<select id="bb_powerpack_rollback_file_key" name="bb_powerpack_rollback_file_key" style="min-width: 200px;">
						<?php foreach ( $files as $file_data ) :
							if ( ! isset( $file_data['file_key'] ) || empty( $file_data['name'] ) || empty( $file_data['package'] ) ) {
								continue;
							}
							?>
							<option value="<?php echo esc_attr( $file_data['file_key'] ); ?>"><?php echo esc_html( $file_data['name'] ); ?></option>
						<?php endforeach; ?>
					</select>
					<p class="description"><?php _e( 'Select a version to rollback to. Please make sure to backup your site before performing a rollback.', 'bb-powerpack' ); ?></p>
				</td>
			</tr>
		</tbody>
	</table>
	<?php wp_nonce_field( 'pp-rollback-settings', 'pp-rollback-settings-nonce' ); ?>
	<input type="submit" class="button button-secondary" name="bb_powerpack_do_rollback" value="<?php echo esc_attr__( 'Rollback Plugin', 'bb-powerpack' ); ?>" onclick="return confirm('<?php echo esc_js( __( 'This will download and install the selected PowerPack package from the update server. Continue?', 'bb-powerpack' ) ); ?>');" />
	<?php do_action( 'pp_admin_settings_before_form_close', $current_tab ); ?>
</form>
