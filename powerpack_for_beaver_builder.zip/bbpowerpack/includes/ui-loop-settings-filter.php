<?php do_action( 'pp_module_before_ui_setting_sections', $settings ); ?>

<div id="fl-builder-settings-section-general" class="fl-builder-settings-section">
<?php include BB_POWERPACK_DIR . 'includes/ui-setting-fields.php'; ?>
</div>

<div id="fl-builder-settings-section-post_content" class="fl-builder-settings-section">
<?php include BB_POWERPACK_DIR . 'includes/ui-loop-settings-simple.php'; ?>
</div>

<?php if ( 'pp-faq' === $settings->type ) { ?>
<div id="fl-builder-settings-section-items" class="fl-builder-settings-section">
	<div class="fl-builder-settings-section-header">
		<button class="fl-builder-settings-title">
			<?php pp_builder_setting_form_section_icon(); ?>
			<?php _e( 'Items', 'bb-powerpack' ); ?>
		</button>
	</div>
	<div class="fl-builder-settings-section-content">
		<table class="fl-form-table">
			<?php
			FLBuilder::render_settings_field(
				'items',
				array(
					'type'         => 'form',
					'label'        => __( 'FAQ', 'bb-powerpack' ),
					'form'         => 'pp_faq_items_form', // ID from registered form below
					'preview_text' => 'faq_question', // Name of a field to use for the preview text
					'multiple'     => true,
				),
				$settings
			);
			?>
		</table>
	</div>
</div>
<?php } ?>

<?php do_action( 'pp_module_after_ui_setting_sections', $settings ); ?>