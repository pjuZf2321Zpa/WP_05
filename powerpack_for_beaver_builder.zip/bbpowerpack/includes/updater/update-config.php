<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// this is the URL our updater / license checker pings. This should be the URL of the site with EDD installed
define( 'BEAVER_ADDONS_URL', 'https://wpbeaveraddons.com' ); // you should use your own CONSTANT name, and be sure to replace it throughout this file

// the name of your product. This should match the download name in EDD exactly
define( 'BEAVER_ADDONS_ITEM_NAME', 'PowerPack for Beaver Builder' ); // you should use your own CONSTANT name, and be sure to replace it throughout this file

define( 'BEAVER_ADDONS_LICENSE_PAGE', BB_PowerPack_Admin_Settings::get_form_action( '&tab=general' ) );

if( !class_exists( 'PP_Plugin_Updater' ) ) {
	// load our custom updater
	include('class-plugin-updater.php' );
}

function bb_powerpack_get( $key ) {
	if ( is_network_admin() ) {
		return get_site_option( $key );
	} else {
		return get_option( $key );
	}
}

function bb_powerpack_update( $key, $value ) {
	if ( is_network_admin() ) {
		return update_site_option( $key, $value );
	} else {
		return update_option( $key, $value );
	}
}

function bb_powerpack_delete( $key ) {
	if ( is_network_admin() ) {
		return delete_site_option( $key );
	} else {
		return delete_option( $key );
	}
}

function bb_powerpack_get_license_key() {
	if ( defined( 'BB_POWERPACK_LICENSE_KEY' ) ) {
		return BB_POWERPACK_LICENSE_KEY ? trim( BB_POWERPACK_LICENSE_KEY ) : '';
	} else {
		return trim( bb_powerpack_get( 'bb_powerpack_license_key' ) );
	}
}

function bb_powerpack_license( $action = '', $license_key = '' ) {
	$license = trim( $license_key );

	if ( empty( $license ) ) {
		$license = bb_powerpack_get_license_key();
	}

	// data to send in our API request
	$api_params = array(
		'edd_action'=> $action,
		'license' 	=> $license,
		'item_name' => urlencode( BEAVER_ADDONS_ITEM_NAME ), // the name of our product in EDD
		'url'       => network_home_url(),
		'environment' => function_exists( 'wp_get_environment_type' ) ? wp_get_environment_type() : 'production',
	);

	// Call the custom API.
	$response = wp_remote_post(
		BEAVER_ADDONS_URL,
		array(
			'timeout' => 15,
			//'sslverify' => false,
			'body' => $api_params
		) );

	return $response;
}

/**
 * Get rollback files from update server.
 *
 * @since 2.42.4
 * @param int  $limit Number of records to request.
 * @param bool $force Whether to bypass cache.
 * @return array|WP_Error
 */
function bb_powerpack_get_rollback_versions( $limit = 5, $force = false ) {
	$limit      = absint( $limit );
	$limit      = $limit > 0 ? $limit : 5;
	$license    = bb_powerpack_get_license_key();
	$cache_key  = 'bb_powerpack_rollback_files_' . md5( $license . '|' . $limit );
	$cache_ttl  = HOUR_IN_SECONDS;

	if ( empty( $license ) ) {
		return new WP_Error( 'pp_rollback_license_missing', __( 'Please activate your PowerPack license to use plugin rollback.', 'bb-powerpack' ) );
	}

	if ( ! $force ) {
		$cached_files = get_site_transient( $cache_key );
		if ( is_array( $cached_files ) && ! empty( $cached_files ) ) {
			return $cached_files;
		}
	}

	$api_params = array(
		'edd_action'  => 'get_versions',
		'license'     => $license,
		'item_name'   => urlencode( BEAVER_ADDONS_ITEM_NAME ),
		'url'         => network_home_url(),
		'environment' => function_exists( 'wp_get_environment_type' ) ? wp_get_environment_type() : 'production',
		'slug'        => 'powerpack',
		'limit'       => $limit,
	);

	$api_params = apply_filters( 'bb_powerpack_rollback_versions_api_params', $api_params );

	$response = wp_remote_post(
		BEAVER_ADDONS_URL,
		array(
			'timeout'   => 15,
			'sslverify' => (bool) apply_filters( 'bb_powerpack_updater_sl_api_request_verify_ssl', true, null ),
			'body'      => $api_params,
		)
	);

	if ( is_wp_error( $response ) ) {
		return $response;
	}

	if ( 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
		return new WP_Error( 'pp_rollback_versions_http_error', __( 'Could not fetch rollback versions from update server.', 'bb-powerpack' ) );
	}

	$data = json_decode( wp_remote_retrieve_body( $response ), true );
	if ( ! is_array( $data ) ) {
		return new WP_Error( 'pp_rollback_versions_bad_response', __( 'Rollback versions response was invalid.', 'bb-powerpack' ) );
	}

	if ( isset( $data['success'] ) && false === $data['success'] ) {
		$message = isset( $data['message'] ) ? sanitize_text_field( $data['message'] ) : __( 'Unable to fetch rollback versions.', 'bb-powerpack' );
		return new WP_Error( 'pp_rollback_versions_failed', $message );
	}

	$raw_files = isset( $data['files'] ) && is_array( $data['files'] ) ? $data['files'] : array();
	$files     = array();

	// Backward-compatible parser for legacy versions payload.
	if ( empty( $raw_files ) && isset( $data['versions'] ) && is_array( $data['versions'] ) ) {
		foreach ( $data['versions'] as $version_data ) {
			if ( ! is_array( $version_data ) || empty( $version_data['files'] ) || ! is_array( $version_data['files'] ) ) {
				continue;
			}
			$raw_files = array_merge( $raw_files, $version_data['files'] );
		}
	}

	foreach ( $raw_files as $raw_file ) {
		if ( ! is_array( $raw_file ) ) {
			continue;
		}

		$package = isset( $raw_file['package'] ) ? esc_url_raw( $raw_file['package'] ) : '';
		if ( empty( $package ) ) {
			continue;
		}

		$file_key = isset( $raw_file['file_key'] ) ? sanitize_text_field( (string) $raw_file['file_key'] ) : '';
		$name     = isset( $raw_file['name'] ) ? sanitize_text_field( $raw_file['name'] ) : __( 'Rollback package', 'bb-powerpack' );

		if ( '' === $file_key ) {
			$file_key = md5( $name . '|' . $package );
		}

		$files[] = array(
			'file_key' => $file_key,
			'name'     => $name,
			'package'  => $package,
		);
	}

	if ( empty( $files ) ) {
		return new WP_Error( 'pp_rollback_versions_empty', __( 'No rollback versions are currently available for this license.', 'bb-powerpack' ) );
	}

	set_site_transient( $cache_key, $files, $cache_ttl );

	return $files;
}

/**
 * Initialize the updater. Hooked into `init` to work with the
 * wp_version_check cron job, which allows auto-updates.
 */
function bb_powerpack_plugin_updater() {

	// To support auto-updates, this needs to run during the wp_version_check cron job for privileged users.
	$doing_cron = defined( 'DOING_CRON' ) && DOING_CRON;
	if ( ! current_user_can( 'manage_options' ) && ! $doing_cron ) {
		return;
	}

	// retrieve our license key from the DB
	$license_key = bb_powerpack_get_license_key();

	// setup the updater
	$edd_updater = new PP_Plugin_Updater(
		BEAVER_ADDONS_URL,
		BB_POWERPACK_DIR . 'bb-powerpack.php',
		array(
			'version' 	=> BB_POWERPACK_VER, 					// current version number
			'license' 	=> $license_key, 						// license key (used bb_powerpack_get above to retrieve from DB)
			'item_name' => BEAVER_ADDONS_ITEM_NAME, 			// name of this plugin
			'author' 	=> 'IdeaBox Creations' 	// author of this plugin
		)
	);

}
add_action( 'init', 'bb_powerpack_plugin_updater' );

/***********************************************
* Activate license key.
***********************************************/
function bb_powerpack_activate_license() {

	if ( ! isset( $_POST['bb_powerpack_license_activate'] ) ) {
		return;
	}

	// run a quick security check
	if ( ! isset( $_POST['bb_powerpack_nonce'] ) || ! wp_verify_nonce( $_POST['bb_powerpack_nonce'], 'bb_powerpack_nonce' ) ) {
		return; // get out if we didn't click the Activate button
	}

	$license = '';

	if ( isset( $_POST['bb_powerpack_license_key'] ) ) {
		$license = trim( $_POST['bb_powerpack_license_key'] );
	} else {
		$license = bb_powerpack_get_license_key();
	}

	$response = bb_powerpack_license( 'activate_license', $license );

	// make sure the response came back okay
	if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {

		if ( is_wp_error( $response ) ) {
			$message = $response->get_error_message();
		} else {
			$message = __( 'An error occurred, please try again.', 'bb-powerpack' );
		}
	} else {
		// decode the license data
		$license_data = json_decode( wp_remote_retrieve_body( $response ) );

		if ( false === $license_data->success ) {
			$message = bb_powerpack_license_messages( $license_data );
		}
	}

	// Check if anything passed on a message constituting a failure
	if ( ! empty( $message ) ) {
		$base_url = BEAVER_ADDONS_LICENSE_PAGE;
		$redirect = add_query_arg( array(
				'sl_activation' => 'false',
				'message' => urlencode( $message ),
		), $base_url );

		wp_redirect( $redirect );
		exit();
	}

	// $license_data->license will be either "valid" or "invalid"

	bb_powerpack_update( 'bb_powerpack_license_status', $license_data->license );
	bb_powerpack_update( 'bb_powerpack_license_user_action', 'activated' );
	bb_powerpack_update( 'bb_powerpack_license_domain', $_SERVER['HTTP_HOST'] );

	wp_redirect( BEAVER_ADDONS_LICENSE_PAGE );
	exit();
}
add_action( 'admin_init', 'bb_powerpack_activate_license' );

/***********************************************
* Deactivate license key.
***********************************************/
function bb_powerpack_deactivate_license() {

	// listen for our activate button to be clicked
	if ( isset( $_POST['bb_powerpack_license_deactivate'] ) ) {

		// run a quick security check
		if ( ! isset( $_POST['bb_powerpack_nonce'] ) || ! wp_verify_nonce( $_POST['bb_powerpack_nonce'], 'bb_powerpack_nonce' ) ) {
			return; // get out if we didn't click the Activate button
		}

		$license = bb_powerpack_get_license_key();

		$response = bb_powerpack_license( 'deactivate_license', $license );

		// make sure the response came back okay
		if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {

			if ( is_wp_error( $response ) ) {
				$message = $response->get_error_message();
			} else {
				$message = __( 'An error occurred, please try again.', 'bb-powerpack' );
			}

			$redirect = add_query_arg( array(
				'sl_activation' => 'false',
				'message' => urlencode( $message ),
			), BEAVER_ADDONS_LICENSE_PAGE );

			wp_redirect( $redirect );
			exit();
		}

		// decode the license data
		$license_data = json_decode( wp_remote_retrieve_body( $response ) );

		// $license_data->license will be either "deactivated" or "failed"
		if ( 'deactivated' === $license_data->license || 'failed' === $license_data->license ) {
			bb_powerpack_delete( 'bb_powerpack_license_status' );
		}

		bb_powerpack_update( 'bb_powerpack_license_user_action', 'deactivated' );

		$redirect = add_query_arg( array(
			'status' => $license_data->license,
		), BEAVER_ADDONS_LICENSE_PAGE );

		wp_redirect( $redirect );
		exit();
	} // End if().
}
add_action( 'admin_init', 'bb_powerpack_deactivate_license' );

/************************************
* check if
* a license key is still valid
* so this is only needed if we
* want to do something custom
*************************************/

function bb_powerpack_check_license() {
	global $wp_version;

	$license = bb_powerpack_get_license_key();

	if ( empty( $license ) ) {
		return array(
			'message' => __( 'License key is not defined. Activate the license with a valid license key.', 'bb-powerpack' ),
		);
	} else {
		// if the license domain is not set or does not match the current domain, update it
		// this is useful when the site is moved to a new domain or subdomain
		// this will also update the license domain in the database
		// so that the license can be checked against the new domain.
		if ( bb_powerpack_get( 'bb_powerpack_license_domain' ) != $_SERVER['HTTP_HOST'] ) {
			bb_powerpack_update( 'bb_powerpack_license_domain', $_SERVER['HTTP_HOST'] );
			bb_powerpack_delete( 'bb_powerpack_license_status' );
			bb_powerpack_delete( 'bb_powerpack_license_user_action' );
			$response = bb_powerpack_license( 'activate_license', $license );

			// make sure the response came back okay
			if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {

				if ( is_wp_error( $response ) ) {
					$message = $response->get_error_message();
				} else {
					$message = __( 'Please activate the license to enable automatic updates for this plugin.', 'bb-powerpack' );
				}
			} else {
				// decode the license data
				$license_data = json_decode( wp_remote_retrieve_body( $response ) );

				if ( false === $license_data->success ) {
					$message = bb_powerpack_license_messages( $license_data );
				}
			}

			// Check if anything passed on a message constituting a failure
			if ( ! empty( $message ) ) {
				return array(
					'message' => $message,
				);
			}

			if ( 'valid' === $license_data->license ) {
				bb_powerpack_update( 'bb_powerpack_license_status', $license_data->license );
				bb_powerpack_update( 'bb_powerpack_license_user_action', 'activated' );
			}

			return $license_data->license;
		}
	}

	$api_params = array(
		'edd_action'  => 'check_license',
		'license' 	  => $license,
		'item_name'   => urlencode( BEAVER_ADDONS_ITEM_NAME ),
		'url'         => network_home_url(),
		'environment' => function_exists( 'wp_get_environment_type' ) ? wp_get_environment_type() : 'production',
	);

	// Call the custom API.
	$response = wp_remote_post(
		BEAVER_ADDONS_URL,
		array(
			'timeout'   => 15,
			//'sslverify' => false,
			'body'      => $api_params,
		)
	);

	if ( is_wp_error( $response ) ) {
		return array(
			'message' => $response->get_error_message(),
		);
	}

	$license_data = json_decode( wp_remote_retrieve_body( $response ) );

	$license_action = bb_powerpack_get( 'bb_powerpack_license_user_action' );

	if ( 'activated' !== $license_action && 'valid' === $license_data->license ) {
		$response = bb_powerpack_license( 'activate_license' );

		if ( 'valid' === $license_data->license ) {
			bb_powerpack_update( 'bb_powerpack_license_status', $license_data->license );
			bb_powerpack_update( 'bb_powerpack_license_user_action', 'activated' );
		}
	}
	if ( 'valid' !== $license_data->license ) {
		bb_powerpack_delete( 'bb_powerpack_license_status' );
		bb_powerpack_delete( 'bb_powerpack_license_user_action' );
		return array(
			'message' => bb_powerpack_license_messages( $license_data ),
		);
	}
	// Delete the license key if the site is inactive or deactivated from remote.
	if ( 'site_removed' === $license_data->license && ! isset( $_REQUEST['bb_powerpack_license_key'] ) ) { 
		bb_powerpack_delete( 'bb_powerpack_license_key' );
		bb_powerpack_delete( 'bb_powerpack_license_status' );
	}

	// if ( 'valid' === $license_data->license ) {
	// 	return 'valid';
	// 	// this license is still valid.
	// } elseif ( 'deactivated' !== $license_data->license ) {
	// 	// this license is no longer valid
	// 	// delete license status.
	// 	bb_powerpack_delete( 'bb_powerpack_license_status' );

	// 	if ( in_array( $license_data->license, array( 'site_inactive' ) ) ) {
	// 		$response = bb_powerpack_license( 'activate_license' );

	// 		if ( ! is_wp_error( $response ) ) {
	// 			// decode the license data
	// 			$license_data = json_decode( wp_remote_retrieve_body( $response ) );

	// 			if ( 'valid' === $license_data->license ) {
	// 				bb_powerpack_update( 'bb_powerpack_license_status', $license_data->license );
	// 			}
	// 		}
	// 	}
	// }

	if ( 'valid' === $license_data->license ) {
		bb_powerpack_update( 'bb_powerpack_license_check_completed', time() );
	} else {
		bb_powerpack_delete( 'bb_powerpack_license_check_completed' );
	}

	return $license_data->license;
}

 /**
  * Show update message on plugins page
  */
function bb_powerpack_update_message( $plugin_data, $response ) {
	$status = bb_powerpack_check_license();

	if ( is_array( $status ) ) {
		$main_msg = $status['message'];
	} elseif ( 'valid' !== $status ) {
		$main_msg = sprintf( __( 'Please activate the license to enable automatic updates for this plugin. License status: %s', 'bb-powerpack' ), $status );
	}
	if ( ! isset( $main_msg ) ) {
		return;
	}
	$message  = '';
	$message .= '<div style="padding: 5px 10px; margin-top: 10px; background: #d54e21; color: #fff; margin-bottom: 10px;">';
	$message .= __( '<strong>UPDATE UNAVAILABLE!</strong>', 'bb-powerpack' );
	$message .= '&nbsp;&nbsp;&nbsp;';
	$message .= $main_msg;
	$message .= '</div>';
	$message .= '<style>#bb-powerpack-update .notice p:empty {display:none;}</style>';

	echo $message;
}
add_action( 'in_plugin_update_message-' . BB_POWERPACK_PATH, 'bb_powerpack_update_message', 1, 2 );

function bb_powerpack_license_messages( $license_data ) {
	$message = '';
	$status = is_object( $license_data ) ? $license_data->license : $license_data;

	switch ( $status ) {

		case 'expired' :

			$message = sprintf(
				__('Your license key expired on %s.', 'bb-powerpack'),
				date_i18n(get_option('date_format'), strtotime(is_object( $license_data ) ? $license_data->expires : '', current_time('timestamp')))
			);
			break;

		case 'revoked' :
		case 'disabled':

			$message = __('Your license key has been disabled.', 'bb-powerpack');
			break;

		case 'missing' :
		case 'invalid' :

			$message = __('Invalid license.', 'bb-powerpack');
			break;

		case 'site_inactive' :

			$message = __('Your license is not active for this URL.', 'bb-powerpack');
			break;

		case 'item_name_mismatch' :

			$message = sprintf(__('This appears to be an invalid license key for %s.', 'bb-powerpack'), BEAVER_ADDONS_ITEM_NAME);
			break;

		case 'no_activations_left':

			$message = __('Your license key has reached its activation limit.', 'bb-powerpack');
			break;

		default :
			// translators: %s for license status.
			$message = sprintf( __('An error occurred, please try again. Status: %s', 'bb-powerpack'), $status );
			break;
	}

	return $message;
}
