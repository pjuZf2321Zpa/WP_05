<div class="pp-panel">
	<div class="fl-builder-panel-actions">
		<i class="pp-panel-close fa fa-times"></i>

		<?php if ( pp_panel_search() == 1 ) : ?>
		<div class="pp-search-bar">
			<input type="text" class="pp-search-input" value="" placeholder="Search..." />
		</div>
		<?php endif; ?>

	</div>
	<div class="fl-builder-panel-content-wrap fl-nanoscroller">
		<div class="fl-builder-panel-content fl-nanoscroller-content">
			<div class="fl-builder-blocks">
				<?php if ( count( $row_templates['categorized'] ) > 0 ) : ?>
				<?php foreach ( $row_templates['categorized'] as $key => $cat ) : ?>
					<?php if ('PowerPack Templates' != $cat['name'] && 'Uncategorized' != $cat['name'] ) : ?>
					<div class="fl-builder-blocks-section">
						<span class="fl-builder-blocks-section-title">
							<?php echo $cat['name']; ?>
							<i class="fa fa-chevron-down"></i>
						</span>
						<div class="fl-builder-blocks-section-content fl-builder-row-templates">
						<?php foreach ( $cat['templates'] as $template ) : ?>
							<span class="fl-builder-block fl-builder-block-template fl-builder-block-row-template" data-id="<?php echo $template['id']; ?>" data-type="<?php echo $template['type']; ?>">
								<img class="fl-builder-block-template-image" src="<?php echo $template['image']; ?>" />
								<span class="fl-builder-block-title"><?php echo $template['name']; ?></span>
							</span>
						<?php endforeach; ?>
						</div>
					</div>
					<?php endif; ?>
				<?php endforeach; ?>
				<?php endif; ?>
			</div>
		</div>
	</div>
</div>
