<?php

namespace FluentSupportPro\App\Hooks\Handlers;

use FluentSupport\Framework\Support\Arr;
use FluentSupport\App\Models\MailBox;
use FluentSupport\App\Models\Meta;
use FluentSupport\App\Services\Helper;
use FluentSupportPro\App\Services\Integrations\FluentEmailPiping\Api;
use FluentSupportPro\App\Services\Integrations\FluentEmailPiping\ByMailHandler;
use FluentSupportPro\App\Services\ProHelper;

/**
 * Pulls emails the pipe could not push. Some hosts' bot protection rejects the
 * pipe's webhook, so the site fetches the pipe's logs itself on a self-scheduled
 * single action. The handler picks the next run from what the site has seen:
 * webhooks arriving means the pull is only a safety net, a pulled email the
 * webhook never delivered means the webhook is blocked and the pull is the
 * delivery path.
 */
class EmailPipingRetryHandler
{
    const FETCH_HOOK = 'fluent_support_pro/fetch_piped_emails';

    const AS_GROUP = 'fluent-support';

    private $apiUrl = 'https://email-parse-api.wpmanageninja.com/fetch_logs';

    public function register()
    {
        if (defined('FLUENTSUPPORT_ENABLE_CUSTOM_PIPE')) {
            return;
        }

        add_action(self::FETCH_HOOK, [$this, 'runScheduledFetch']);

        // Self-scheduling chains die if a run fatals before rescheduling, so the
        // recurring half-hourly job and admin page loads re-seed a missing one.
        add_action('fluent_support_half_hourly', [$this, 'ensureScheduled'], 1);
        add_action('fluent_support/admin_app_loaded', [$this, 'ensureScheduled']);
    }

    public function runScheduledFetch()
    {
        if (!$this->getRequestConfig()) {
            return; // no piped mailbox; ensureScheduled() restarts the chain once one exists
        }

        try {
            // Fetching is the delivery path on sites whose webhook is blocked, so it
            // goes first: a slow feature service may only ever delay the next run.
            $this->retryEmailLogs();
            $this->syncPipeFeatures();
        } finally {
            $this->scheduleNext();
        }
    }

    /** Seconds one run may spend telling the pipe about mailbox features. */
    const FEATURE_SYNC_BUDGET = 15;

    /**
     * Tell the pipe which features each existing mailbox handles (bounce delivery).
     * New mailboxes opt in on issue and status; this covers ones issued before.
     * Runs until it succeeds, at most once a day per mailbox, and within a time
     * budget per run (each request may block for up to 10 seconds); mailboxes
     * left over wait for the next run, not for tomorrow.
     */
    public function syncPipeFeatures()
    {
        $licenseData = get_option('__fluentsupport_pro_license');
        $licenseKey = ($licenseData && !empty($licenseData['license_key']) && Arr::get($licenseData, 'status') == 'valid')
            ? $licenseData['license_key']
            : '';

        if (!$licenseKey) {
            return;
        }

        $boxes = MailBox::where('box_type', 'email')->whereNotNull('mapped_email')->get();

        /**
         * Filter how many seconds one scheduled run may spend syncing mailbox features.
         *
         * @param int $seconds
         */
        $budget = (float) apply_filters('fluent_support_pro/pipe_feature_sync_budget', self::FEATURE_SYNC_BUDGET);
        $deadline = microtime(true) + $budget;

        foreach ($boxes as $box) {
            if (!$box->mapped_email || Api::featuresSynced($box)) {
                continue;
            }

            $lastTry = (int) $box->getMeta('_pipe_features_tried_at', 0);
            if ($lastTry > time() - DAY_IN_SECONDS) {
                continue;
            }

            // Checked before the attempt is recorded, so a mailbox the budget skips
            // is still due on the next run.
            if (microtime(true) >= $deadline) {
                break;
            }
            $box->saveMeta('_pipe_features_tried_at', time());

            $boxToken = ProHelper::getBoxSecret($box);
            if (is_wp_error($boxToken)) {
                continue;
            }

            $response = (new Api())->syncFeatures([
                'box_token'    => $boxToken,
                'license'      => $licenseKey,
                'mapped_email' => $box->mapped_email,
                'features'     => Api::featuresParam(),
            ]);

            if (!is_wp_error($response)) {
                Api::rememberFeatures($box, $response);
            }
        }
    }

    public function ensureScheduled()
    {
        if (!function_exists('as_schedule_single_action') || $this->hasQueuedFetch()) {
            return;
        }

        if (!$this->getRequestConfig()) {
            return;
        }

        // unique also matches an in-progress run, so this never doubles the chain.
        as_schedule_single_action(time(), self::FETCH_HOOK, [], self::AS_GROUP, true);
    }

    public function retryEmailLogs()
    {
        $payloadConfig = $this->getRequestConfig();

        if (!$payloadConfig) {
            return; // we don't have any email box to process
        }

        $response = wp_remote_post($this->apiUrl, [
            'headers' => [
                'Content-Type' => 'application/json',
            ],
            'body'    => json_encode($payloadConfig),
        ]);

        if (is_wp_error($response)) {
            return; // this is an error
        }

        $responseBody = wp_remote_retrieve_body($response);
        $responseBody = json_decode($responseBody, true);

        if (!$responseBody || Arr::get($responseBody, 'status') !== 'success') {
            return; // this is an error
        }

        $emails = Arr::get($responseBody, 'emails', []);

        $processedMimes = [];
        $missedWebhook = false;

        foreach ($emails as $email) {
            $mime = Arr::get($email, 'mime', '');
            $processedMimes[] = $mime;

            $webHookValue = $this->getBoxByToken($email['box_token']);

            if (!$webHookValue) {
                continue;
            }

            $box = MailBox::find($webHookValue->object_id);

            if (!$box) {
                continue;
            }

            // An email the webhook already handled is marked processed, so an
            // unmarked one here is an email the webhook never delivered.
            if ($mime && !ProHelper::isMimeProcessed($mime)) {
                $missedWebhook = true;
            }

            ByMailHandler::processPayload(Arr::get($email, 'payload', []), $box, $mime);
        }

        if ($missedWebhook) {
            Helper::updateOption('_email_piping_last_missed_at', time());
        }

        Helper::updateOption('_email_piping_retry_config', [
            'last_request_date'    => Arr::get($responseBody, 'to_date', ''),
            'last_processed_mimes' => $processedMimes,
        ]);
    }

    /**
     * Called by the pipe's webhook endpoint once the request authenticates.
     */
    public static function markWebhookReceived()
    {
        $now = time();
        $lastWebhook = (int) Helper::getOption('_email_piping_last_webhook_at', 0);

        // Skip the write on a busy mailbox unless it would flip a degraded site back.
        if ($now - $lastWebhook < MINUTE_IN_SECONDS && $lastWebhook > (int) Helper::getOption('_email_piping_last_missed_at', 0)) {
            return;
        }

        Helper::updateOption('_email_piping_last_webhook_at', $now);
    }

    /**
     * healthy: a webhook arrived after the last email the webhook missed.
     * degraded: the last pull found an email the webhook missed.
     * unknown: no webhook yet; poll like degraded so a site blocked from day one
     * still gets its first emails quickly.
     */
    public static function getWebhookHealth()
    {
        $lastWebhook = (int) Helper::getOption('_email_piping_last_webhook_at', 0);
        $lastMissed = (int) Helper::getOption('_email_piping_last_missed_at', 0);

        if ($lastWebhook && $lastWebhook > $lastMissed) {
            return 'healthy';
        }

        return $lastMissed ? 'degraded' : 'unknown';
    }

    private function scheduleNext()
    {
        if ($this->hasQueuedFetch(true)) {
            return;
        }

        $interval = self::getWebhookHealth() === 'healthy' ? 30 * MINUTE_IN_SECONDS : 5 * MINUTE_IN_SECONDS;
        $interval = (int) apply_filters('fluent_support_pro/email_piping_fetch_interval', $interval, self::getWebhookHealth());

        // Not unique: this run is still in-progress and unique would match it.
        as_schedule_single_action(time() + max($interval, MINUTE_IN_SECONDS), self::FETCH_HOOK, [], self::AS_GROUP);
    }

    private function hasQueuedFetch($pendingOnly = false)
    {
        if ($pendingOnly) {
            return (bool) as_get_scheduled_actions([
                'hook'     => self::FETCH_HOOK,
                'group'    => self::AS_GROUP,
                'status'   => \ActionScheduler_Store::STATUS_PENDING,
                'per_page' => 1,
            ], 'ids');
        }

        return function_exists('as_has_scheduled_action') && as_has_scheduled_action(self::FETCH_HOOK, [], self::AS_GROUP);
    }

    private function getRequestConfig()
    {
        $emailBoxes = MailBox::select(['id', 'mapped_email'])
            ->where('box_type', 'email')
            ->get();

        if (!$emailBoxes) {
            return [];
        }


        $boxConfigs = [];
        foreach ($emailBoxes as $emailBox) {
            $webhookToken = $emailBox->getMeta('_webhook_token');
            if ($webhookToken && $emailBox->mapped_email) {
                $boxConfigs[$webhookToken] = $emailBox->mapped_email;
            }
        }

        if (!$boxConfigs) {
            return [];
        }

        $prevRequestConfig = Helper::getOption('_email_piping_retry_config', []);

        return array_filter([
            'site_config'     => $boxConfigs,
            'from_date'       => Arr::get($prevRequestConfig, 'last_request_date', ''),
            'processed_mimes' => Arr::get($prevRequestConfig, 'last_processed_mimes', []),
        ]);
    }

    private function getBoxByToken($token)
    {
        static $boxes = [];

        if (isset($boxes[$token])) {
            return $boxes[$token];
        }

        $box = Meta::where('key', '_webhook_token')
            ->where('value', $token)
            ->where('object_type', 'FluentSupport\App\Models\MailBox')
            ->first();

        if (!$box) {
            return null;
        }

        $boxes[$token] = $box;

        return $box;
    }

}
