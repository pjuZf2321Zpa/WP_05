<?php

namespace FluentSupportPro\App\Hooks\Handlers;

use FluentSupportPro\App\Modules\ScheduledReplies\ScheduledRepliesModule;

class DeactivationHandler
{
    public function handle()
    {
        wp_clear_scheduled_hook('fluent_support_report_snapshot');

        if (function_exists('as_unschedule_all_actions')) {
            as_unschedule_all_actions(EmailPipingRetryHandler::FETCH_HOOK, [], EmailPipingRetryHandler::AS_GROUP);
        }

        ScheduledRepliesModule::onDeactivation();
    }
}
