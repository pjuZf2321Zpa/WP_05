<?php

namespace FluentSupportPro\App\Hooks\Handlers;

use FluentSupportPro\App\Modules\ScheduledReplies\ScheduledRepliesModule;
use FluentSupportPro\Database\DBMigrator;

class ActivationHandler
{
    public function handle($network_wide = false)
    {
        DBMigrator::run($network_wide);
        $this->scheduleReportSnapshot();
        ScheduledRepliesModule::onActivation();
    }

    public function scheduleReportSnapshot()
    {
        if (!wp_next_scheduled('fluent_support_report_snapshot')) {
            wp_schedule_event(time(), 'fs_every_6_hours', 'fluent_support_report_snapshot');
        }
    }
}
