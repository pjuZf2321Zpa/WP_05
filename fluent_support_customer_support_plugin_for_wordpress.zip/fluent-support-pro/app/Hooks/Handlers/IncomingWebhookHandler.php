<?php

namespace FluentSupportPro\App\Hooks\Handlers;

use FluentSupport\App\Models\MailBox;
use FluentSupport\App\Models\Meta;
use FluentSupport\App\Services\Helper;
use FluentSupport\Framework\Support\Arr;
use FluentSupportPro\App\Services\Integrations\FluentEmailPiping\ByMailHandler;
use FluentSupportPro\App\Services\ProHelper;

class IncomingWebhookHandler extends ByMailHandler
{
    /**
     * fs_meta.object_type for incoming-webhook credentials. Shared with
     * IncomingWebhookController so the two cannot drift.
     */
    const WEBHOOK_OBJECT_TYPE = 'fs_incoming_webhook';

    public function handleIncomingWebhook()
    {
        $request = Helper::FluentSupport('request');

        // getMethod() is the verb WordPress routed on; method() returns
        // $_SERVER['REQUEST_METHOD'] raw, which ?_method= can disagree with.
        if ($request->getMethod() != 'POST') {
            return;
        }

        $postData = $request->get();

        $token = sanitize_text_field(Arr::get($postData, 'token'));

        // Pre-auth limit keyed on IP only, so attackers cannot mint buckets with random tokens.
        $remoteIp = sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'] ?? ''));
        if (!ProHelper::checkRateLimit('webhook_ip_' . $remoteIp, 200, 60)) {
            wp_send_json_error([
                'message' => __('Too many requests. Please slow down.', 'fluent-support-pro'),
                'type'    => 'rate_limit_exceeded'
            ], 429);
        }

        // The token is this route's only credential. Scope the lookup to webhook rows,
        // since other fs_meta rows have predictable keys.
        $webhook = $token ? Meta::where('object_type', self::WEBHOOK_OBJECT_TYPE)
            ->where('key', $token)
            ->first() : null;

        // MySQL's default collation pads on comparison, so `=` also matches a token with
        // trailing whitespace. Re-compare the stored value exactly, in constant time.
        if ($webhook && !hash_equals((string) $webhook->key, $token)) {
            $webhook = null;
        }

        if (!$webhook || !Arr::get($postData, 'sender.email') || !is_email(Arr::get($postData, 'sender.email'))) {
            wp_send_json_error([
                'message' => __('Invalid request.', 'fluent-support-pro')
            ], 423);
        }

        // Post-auth limit keyed on the webhook's DB ID and the IP, not the raw token.
        if (!ProHelper::checkRateLimit('webhook_id_' . $webhook->id . '_' . $remoteIp, 120, 60)) {
            wp_send_json_error([
                'message' => __('Too many requests. Please slow down.', 'fluent-support-pro'),
                'type'    => 'rate_limit_exceeded'
            ], 429);
        }

        // Take the mailbox from the webhook record only, never from the request.
        $webhookData = ProHelper::safeUnserialize($webhook->value);
        $mailboxId = (is_array($webhookData) && isset($webhookData['mailbox'])) ? intval($webhookData['mailbox']) : 0;

        $mailBox = null;
        if($mailboxId) {
            $mailBox = MailBox::where('id', $mailboxId)->first();
        }

        if(!$mailBox) {
            $mailBox = Helper::getDefaultMailBox();
        }

        $postData['sender']['name'] = trim(Arr::get($postData, 'sender.first_name', '') . ' ' . Arr::get($postData, 'sender.last_name', ''));

        $postData['message_id'] = null;

        $postData['subject'] = Arr::get($postData, 'title');

        unset($postData['title']);

        return parent::handleEmailData($postData, $mailBox, 'webhook');
    }
}
