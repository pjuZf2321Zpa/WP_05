<?php

namespace FluentSupportPro\App\Hooks\Handlers;

use FluentSupportPro\App\Modules\Reporting\SnapshotService;

class ReportSnapshotHandler
{
    public function run()
    {
        SnapshotService::takeSnapshot();
        SnapshotService::cleanup();
    }
}
