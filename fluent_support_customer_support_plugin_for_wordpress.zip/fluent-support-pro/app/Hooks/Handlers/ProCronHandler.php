<?php

namespace FluentSupportPro\App\Hooks\Handlers;

use FluentSupport\App\Services\Helper;
use FluentSupportPro\App\Services\ProHelper;

class ProCronHandler
{
    public function maybeUpdateStorageTokens()
    {
        $this->updateDropboxToken();
        $this->updateGoogleDriveToken();
    }

    /**
     * The storage helpers decrypt the token when is_encrypted is 'yes', so a plaintext
     * token stored under that flag decrypts to false and every upload fails.
     */
    protected function withRefreshedToken(array $settings, array $response)
    {
        $token = $response['access_token'];
        if (($settings['is_encrypted'] ?? 'no') === 'yes') {
            $token = ProHelper::encryptKey($token);
        }

        $settings['access_token'] = $token;
        $settings['last_error'] = '';
        if (!empty($response['expires_in'])) {
            $settings['expire_at'] = time() + (int) $response['expires_in'];
        }

        return $settings;
    }

    /**
     * Save a refreshed token onto the settings as they are now, not as they were
     * before the HTTP call: a reconnect or settings change made meanwhile is kept,
     * and the token is dropped when the account changed.
     */
    protected function saveRefreshedToken($optionKey, array $before, array $response)
    {
        $settings = Helper::getIntegrationOption($optionKey, []);

        // Compare plain values: every settings save encrypts the token again with a new IV.
        if (!is_array($settings)
            || $this->plainRefreshToken($settings) !== $this->plainRefreshToken($before)
            || ($settings['client_id'] ?? '') !== ($before['client_id'] ?? '')) {
            return;
        }

        Helper::updateIntegrationOption($optionKey, $this->withRefreshedToken($settings, $response));
    }

    protected function plainRefreshToken(array $settings)
    {
        $raw = (string) ($settings['refresh_token'] ?? '');
        $decrypted = $raw ? ProHelper::decryptKey($raw) : false;

        return $decrypted !== false ? $decrypted : $raw;
    }

    /**
     * Pro 2.4.7+ stores the client secret encrypted (flagged by client_secret_encrypted).
     */
    protected function clientSecret(array $settings)
    {
        $secret = $settings['client_secret'] ?? '';

        if (($settings['client_secret_encrypted'] ?? 'no') === 'yes' && $secret) {
            $decrypted = ProHelper::decryptKey($secret);
            return $decrypted === false ? '' : $decrypted;
        }

        return $secret;
    }

    protected function updateDropboxToken()
    {
        $dropboxSettings = Helper::getIntegrationOption('dropbox_settings', []);
        if (empty($dropboxSettings) || empty($dropboxSettings['refresh_token']) || empty($dropboxSettings['refresh_token'])) {
            return;
        }

        $url = 'https://api.dropboxapi.com/oauth2/token';
        $headers = [
            'Content-Type' => 'application/x-www-form-urlencoded'
        ];
        $refreshToken = $this->plainRefreshToken($dropboxSettings);

        $data = [
            'grant_type'    => 'refresh_token',
            'refresh_token' => $refreshToken,
            'client_id'     => $dropboxSettings['client_id'],
            'client_secret' => $this->clientSecret($dropboxSettings)
        ];

        $request = wp_remote_post($url, [
            'headers' => $headers,
            'body'    => $data
        ]);
        // A failed refresh keeps the current token; the next run tries again.
        if (is_wp_error($request)) {
            return;
        }

        $response = json_decode(wp_remote_retrieve_body($request), true);
        if ($response && isset($response['access_token'])) {
            $this->saveRefreshedToken('dropbox_settings', $dropboxSettings, $response);
        }
    }

    protected function updateGoogleDriveToken()
    {
        $googleDriveSettings = Helper::getIntegrationOption('google_drive_settings', []);
        if (empty($googleDriveSettings) || empty($googleDriveSettings['refresh_token']) || empty($googleDriveSettings['refresh_token'])) {
            return;
        }

        $refreshToken = $this->plainRefreshToken($googleDriveSettings);

        $requestArgs = [
            'headers' => [
                'Content-Type' => 'application/json',
            ],
            'body'    => json_encode([
                'client_id'     => $googleDriveSettings['client_id'],
                'client_secret' => $this->clientSecret($googleDriveSettings),
                'grant_type'    => 'refresh_token',
                'refresh_token' => $refreshToken,
            ]),
        ];

        $request = wp_remote_post('https://accounts.google.com/o/oauth2/token', $requestArgs);

        if (is_wp_error($request)) {
            return false; //
        }

        $response = wp_remote_retrieve_body($request);
        $response = json_decode($response, true);
        if ($response && isset($response['access_token'])) {
            $this->saveRefreshedToken('google_drive_settings', $googleDriveSettings, $response);
        }
    }
}
