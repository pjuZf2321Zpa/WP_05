<?php
/**
 * @var $app FluentSupport\Framework\Foundation\Application
 */

use FluentSupportPro\Database\Migrations\ReportSnapshotsMigrator;
use FluentSupportPro\Database\Migrations\SavedRepliesMigrator;
use FluentSupportPro\Database\Migrations\TicketAuditsMigrator;
use FluentSupportPro\Database\Migrations\TimeTrackMigrator;
use FluentSupportPro\Database\Migrations\WorkflowActionMigrator;
use FluentSupportPro\Database\Migrations\WorkflowMigrator;

add_filter('fluent_support/email_footer_credit', '__return_empty_string');

\FluentSupportPro\App\Modules\CustomFields\CustomFields::register();

add_filter('fluent_support/disabled_ticket_fields', function ($fields) {
    $ticketFormConfig = \FluentSupportPro\App\Services\ProHelper::getTicketFormConfig();
    return $ticketFormConfig['disabled_fields'];
});

add_filter('fluent_support/customer_portal_vars', function ($vars) {
    $customFields = \FluentSupportPro\App\Modules\CustomFields\CustomFields::labels('public');
    $vars['custom_fields'] = $customFields;

    $vars['has_pro'] = true;

    $vars['has_doc_integration'] = \FluentSupportPro\App\Services\ProHelper::hasDocIntegration();

    if ($disabledFields = apply_filters('fluent_support/disabled_ticket_fields', [])) {
        if (in_array('product_services', $disabledFields)) {
            $vars['support_products'] = [];
        }

        if (in_array('priority', $disabledFields)) {
            $vars['customer_ticket_priorities'] = [];
        }

        if (in_array('file_upload', $disabledFields)) {
            $vars['has_file_upload'] = false;
        }
    }

    $ticketFormConfig = \FluentSupportPro\App\Services\ProHelper::getTicketFormConfig();

    if ($ticketFormConfig['disable_rich_text'] == 'yes') {
        $vars['has_rich_text_editor'] = false;
    }

    if (!empty($vars['i18n'])) {
        $vars['i18n'] = wp_parse_args($ticketFormConfig['field_labels'], $vars['i18n']);
    }

    $ajaxFields = apply_filters('fluent_support/custom_field_renders_type', []);
    foreach ($customFields as $customField) {
        if (in_array($customField['type'], $ajaxFields)) {
            $vars['has_custom_ajax_fields'] = true;
            return $vars;
        }
    }

    return $vars;
});

$app->addFilter('fluent_support_app_vars', function ($vars) {

    // Not preloaded: the list is unbounded.
    $vars['fluentcrm_customers'] = [];

    if (
        \FluentSupport\App\Modules\PermissionManager::currentUserCan('fst_run_workflows') ||
        \FluentSupport\App\Modules\PermissionManager::currentUserCan('fst_manage_workflows')
    ) {
        $workflows = \FluentSupportPro\App\Models\Workflow::select(['id', 'title'])
            ->where('trigger_type', 'manual')
            ->where('status', 'published')
            ->get();
        $vars['manual_workflows'] = $workflows;
    }

    $vars['advanced_filter_options'] = \FluentSupportPro\App\Services\ProHelper::getAdvancedFilterOptions();

    $customFields = \FluentSupportPro\App\Modules\CustomFields\CustomFields::labels('admin');
    $ajaxFields = apply_filters('fluent_support/custom_field_renders_type', []);
    foreach ($customFields as $customField) {
        if (in_array($customField['type'], $ajaxFields)) {
            $vars['has_custom_ajax_fields'] = true;
            return $vars;
        }
    }

    return $vars;
});

add_filter('fluent_support/user_portal_access_config', function ($config) {
    $ticketFormConfig = \FluentSupportPro\App\Services\ProHelper::getTicketFormConfig();
    
    if (\FluentSupport\Framework\Support\Arr::get($ticketFormConfig, 'submitter_type') == 'allowed_user_roles') {
        $acceptedRoles = \FluentSupport\Framework\Support\Arr::get($ticketFormConfig, 'allowed_user_roles', []);
        if ($acceptedRoles && get_current_user_id()) {
            $user = wp_get_current_user();
            if (!array_intersect($acceptedRoles, (array)$user->roles)) {
                $config['status'] = false;
            }
        }
    }

    return $config;
}, 10, 1);

$app->addFilter('fluent_support/countries', '\FluentSupport\App\Services\Includes\CountryNames@get');

add_filter('fluent_support/dashboard_notice', function ($messages) {
    if (version_compare(FLUENTSUPPORT_MIN_CORE_VERSION, FLUENT_SUPPORT_VERSION, '>')) {
        $updateUrl = admin_url('plugins.php?s=fluent-support&plugin_status=all');
        $html = '<div class="fs_alert_notification fs_alert_warning" style="border-radius: 8px; margin-bottom: 24px; max-width: 1360px; margin-left: auto; margin-right: auto;">
            <div style="display: flex; gap: 8px; align-items: center; padding: 8px 8px 8px 16px;">
                <span style="font-size: 15px; line-height: 18px; flex-shrink: 0;">⚠️</span>
                <p style="flex: 1; margin: 0; font-size: 14px; line-height: 20px; color: var(--fs-text-primary, #0E121B); letter-spacing: -0.084px;">Fluent Support core plugin needs to be updated for compatibility.</p>
                <a href="'.esc_url($updateUrl).'" style="color: var(--fs-text-primary, #0E121B);font-size: 14px;font-style: normal;font-weight: 500;line-height: 20px;letter-spacing: -0.084px;text-decoration-line: underline;text-decoration-style: solid;">Update Now</a>
            </div>
        </div>';
        $messages .= $html;
    }
    return $messages;
}, 100);


// The same, on every admin page. On an older core only tickets and email piping
// are kept working (FluentSupportPro\App\Services\CoreCompat).
add_action('admin_notices', function () {
    if (!current_user_can('update_plugins') || !version_compare(FLUENTSUPPORT_MIN_CORE_VERSION, FLUENT_SUPPORT_VERSION, '>')) {
        return;
    }

    printf(
        '<div class="notice notice-warning"><p>%s <a href="%s">%s</a></p></div>',
        /* translators: %s is the Fluent Support version this version of Fluent Support Pro needs */
        esc_html(sprintf(__('Please update Fluent Support to %s. Tickets and email piping keep working; other Pro features may not until it is updated.', 'fluent-support-pro'), FLUENTSUPPORT_MIN_CORE_VERSION)),
        esc_url(admin_url('plugins.php?s=fluent-support&plugin_status=all')),
        esc_html__('Update now', 'fluent-support-pro')
    );
});

// System Admin Tools: list Pro's scheduled task and tables next to free's.
add_filter('fluent_support/system_tools_cron_events', function ($jobs) {
    $jobs[] = [
        'hook'     => 'fluent_support_report_snapshot',
        'title'    => __('Advanced Reports Snapshot', 'fluent-support-pro'),
        'interval' => 6 * HOUR_IN_SECONDS,
    ];

    return $jobs;
});

add_filter('fluent_support/system_tools_tables', function ($definitions) {
    $tables = [
        WorkflowMigrator::class        => __('Workflows', 'fluent-support-pro'),
        WorkflowActionMigrator::class  => __('Workflow Actions', 'fluent-support-pro'),
        SavedRepliesMigrator::class    => __('Saved Replies', 'fluent-support-pro'),
        TimeTrackMigrator::class       => __('Time Tracking', 'fluent-support-pro'),
        ReportSnapshotsMigrator::class => __('Advanced Reports Snapshots', 'fluent-support-pro'),
        TicketAuditsMigrator::class    => __('AI Ticket Audits', 'fluent-support-pro'),
    ];

    foreach ($tables as $migrator => $title) {
        $definitions[] = ['name' => $migrator::$tableName, 'title' => $title];
    }

    return $definitions;
});

(new \FluentSupportPro\App\Services\PluginManager\PluginInstaller())->registerCoreUpdater();
