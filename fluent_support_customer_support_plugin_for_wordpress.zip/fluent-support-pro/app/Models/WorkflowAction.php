<?php

namespace FluentSupportPro\App\Models;

use FluentSupport\App\Models\Model;
use FluentSupportPro\App\Services\ProHelper;

class WorkflowAction extends Model
{
    protected $table = 'fs_workflow_actions';

    protected $fillable = ['action_name', 'title', 'workflow_id', 'settings'];

    public function setSettingsAttribute($settings)
    {
        $this->attributes['settings'] = \maybe_serialize($settings);
    }

    public function getSettingsAttribute($value)
    {
        return ProHelper::safeUnserialize($this->attributes['settings']);
    }

    public function workflow()
    {
        $class = __NAMESPACE__ . '\Workflow';

        return $this->belongsTo($class, 'workflow_id', 'id');
    }

}
