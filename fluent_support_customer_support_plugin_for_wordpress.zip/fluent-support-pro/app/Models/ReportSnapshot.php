<?php

namespace FluentSupportPro\App\Models;

use FluentSupport\App\Models\Model;
use FluentSupport\App\Services\Helper;

class ReportSnapshot extends Model
{
    protected $table = 'fs_report_snapshots';

    protected $fillable = ['snapshot_time', 'report_type', 'period', 'data'];

    public static function boot()
    {
        parent::boot();

        static::creating(function ($model) {
            $model->created_at = current_time('mysql');
            $model->updated_at = current_time('mysql');
        });
    }

    public function scopeOfType($query, $reportType)
    {
        return $query->where('report_type', $reportType);
    }

    public function getDataAttribute($value)
    {
        if (!array_key_exists('data', $this->attributes)) {
            return [];
        }

        $decoded = Helper::safeUnserialize($this->attributes['data']);

        return is_array($decoded) ? $decoded : [];
    }

    public function setDataAttribute($value)
    {
        if (!is_array($value)) {
            throw new \Exception('ReportSnapshot data must be an array before it is stored.');
        }

        $this->attributes['data'] = \maybe_serialize($value);
    }
}
