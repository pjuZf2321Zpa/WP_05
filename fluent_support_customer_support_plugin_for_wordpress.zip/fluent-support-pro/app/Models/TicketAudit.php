<?php

namespace FluentSupportPro\App\Models;

use FluentSupport\App\Models\Model;

class TicketAudit extends Model
{
    protected $table = 'fs_ticket_audits';

    protected $fillable = ['ticket_id', 'mood', 'score', 'summary', 'status', 'error', 'audited_at', 'created_at', 'updated_at'];
}
