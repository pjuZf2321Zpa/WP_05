<?php

namespace FluentSupportPro\App\Services\Integrations;

use FluentSupport\App\Services\ProfileInfoService;

class PMPro
{
    public function boot()
    {
        add_filter('fluent_support/customer_extra_widgets', array($this, 'getPmMembershipInfo'), 80, 3);

	    // Custom Fields Support For Paid Membership Pro
	    $this->renderCustomFields();
    }

    public function renderCustomFields()
    {
	    add_filter('fluent_support/custom_field_types', function ($fieldTypes) {
		    $fieldTypes['pmpro_levels'] = [
			    'is_custom'   => true,
			    'is_remote'   => true,
			    'custom_text' => __('Paid Membership Pro\'s levels will be shown at the ticket form', 'fluent-support-pro'),
			    'type'        => 'pmpro_levels',
			    'label'       => __('Paid Membership Pro Levels', 'fluent-support-pro'),
			    'value_type'  => 'number'
		    ];
		    $fieldTypes['pmpro_user_levels'] = [
			    'is_custom'   => true,
			    'is_remote'   => true,
			    'custom_text' => __('Paid Membership Pro\'s User levels will be shown at the ticket form', 'fluent-support-pro'),
			    'type'        => 'pmpro_user_levels',
			    'label'       => __('Paid Membership Pro User Levels', 'fluent-support-pro'),
			    'value_type'  => 'number'
		    ];

		    return $fieldTypes;
	    }, 10, 1);

	    add_filter('fluent_support/render_custom_field_options_pmpro_levels', function ($field, $customer) {
		    $levels = pmpro_getAllLevels();

		    if (!$levels) return $field;

		    $options = [];

		    foreach ($levels as $level) {
			    $options[] = [
				    'id'    => strval($level->id),
				    'title' => $level->name
			    ];
		    }
		    if(!$options) return $field;

		    $field['type'] = 'select';
		    $field['filterable'] = true;
		    $field['rendered'] = true;
		    $field['options'] = $options;

		    return $field;

	    }, 10, 2);

	    add_filter('fluent_support/render_custom_field_options_pmpro_user_levels', function ($field, $customer) {
		    if (!$customer->user_id) return $field;

		    $levels = pmpro_getMembershipLevelsForUser($customer->user_id);

		    if (!$levels) return $field;

		    $options = [];

		    foreach ($levels as $level) {
			    $options[] = [
				    'id'    => strval($level->id),
				    'title' => $level->name
			    ];
		    }
		    if(!$options) return $field;

		    $field['type'] = 'select';
		    $field['filterable'] = true;
		    $field['rendered'] = true;
		    $field['options'] = $options;

		    return $field;

	    }, 10, 2);

	    $hooks = ['pmpro_levels', 'pmpro_user_levels'];

	    foreach ($hooks as $hook) {
		    add_filter('fluent_support/custom_field_render_'. $hook, function ($value){

			    if (!is_numeric($value)) {
				    return $value;
			    }

			    $levelId = absint($value);

			    if (!$levelId) return $value;

			    $level = pmpro_getLevel($levelId);
			    return $level->name;
		    }, 10,1);
	    }

    }

    public function getPmMembershipInfo($widgets, $customer, $context = null)
    {
        // $context is null on Fluent Support versions that don't pass it.
        if ($context && !ProfileInfoService::wantsWidget($context, 'pmpro')) {
            return $widgets;
        }

        // Ensure email exists
        if (empty($customer->email)) {
            return $widgets;
        }

        // Get user by email
        $user = get_user_by('email', $customer->email);
        if (!$user) {
            return $widgets;
        }

        // Get PMPro membership levels for user
        $levels = pmpro_getMembershipLevelsForUser($user->ID);
        if (empty($levels)) {
            return $widgets;
        }

        if ($context && ProfileInfoService::isMcpWidgetRequest($context)) {
            $widgets['pmpro'] = [
                'title' => __('Paid Membership Pro', 'fluent-support-pro'),
                'mcp'   => $this->getMcpData($levels),
            ];
            return $widgets;
        }

        $membershipInfo = [];

        foreach ($levels as $level) {
            $membershipInfo[] = [
                'name'      => esc_html($level->name),
                'startdate' => $level->startdate
                    ? esc_html(wp_date(get_option('date_format'), (int) $level->startdate))
                    : '',
                'enddate'   => $level->enddate
                    ? esc_html(wp_date(get_option('date_format'), (int) $level->enddate))
                    : '',
            ];
        }

        if (empty($membershipInfo)) {
            return $widgets;
        }

        ob_start();
        ?>
        <ul>
            <?php foreach ($membershipInfo as $info): ?>
                <li title="<?php echo esc_attr($info['name']); ?>" class="fs_widget_li">
                    <?php
                    echo '<code>' . __('Level:', 'fluent-support-pro') . '</code> ' . $info['name'] . '<br>';
                    echo '<code>' . __('Membership Start:', 'fluent-support-pro') . '</code> ' . $info['startdate'] . '<br>';
                    if ($info['enddate']) {
                        echo '<code>' . __('Membership End:', 'fluent-support-pro') . '</code> ' . $info['enddate'];
                    }
                    ?>
                </li>
            <?php endforeach; ?>
        </ul>
        <?php
        $content = ob_get_clean();

        $widgets['pmpro'] = [
            'header'    => __('Paid Membership Pro', 'fluent-support-pro'),
            'body_html' => $content,
        ];

        return $widgets;
    }

    /**
     * @param \stdClass[] $levels PMPro level rows.
     */
    private function getMcpData($levels)
    {
        $currency = isset($GLOBALS['pmpro_currency']) ? (string) $GLOBALS['pmpro_currency'] : (string) get_option('pmpro_currency', '');
        $memberships = [];

        foreach ($levels as $level) {
            // pmpro_getMembershipLevelsForUser() returns active levels only.
            $memberships[] = [
                'id'             => (int) $level->id,
                'name'           => (string) $level->name,
                'status'         => 'active',
                'start_date'     => $level->startdate ? gmdate('c', (int) $level->startdate) : null,
                'end_date'       => $level->enddate ? gmdate('c', (int) $level->enddate) : null,
                'billing_amount' => isset($level->billing_amount) ? (float) $level->billing_amount : null,
                'cycle'          => !empty($level->cycle_number) ? (int) $level->cycle_number . ' ' . strtolower((string) $level->cycle_period) : null,
                'currency'       => $currency,
            ];
        }

        return [
            'active_memberships' => count($memberships),
            'memberships'        => $memberships,
        ];
    }

    public function addToWorkflow($customField, $key)
    {
        $options = [];

        $levels = pmpro_getAllLevels();

        foreach ($levels as $level) {
            $options[$level->id] = $level->name;
        }

        return [
            'title'     => $customField['label'],
            'data_type' => 'single_dropdown',
            'group'     => 'Custom Fields',
            'options'   => $options
        ];
    }
}
