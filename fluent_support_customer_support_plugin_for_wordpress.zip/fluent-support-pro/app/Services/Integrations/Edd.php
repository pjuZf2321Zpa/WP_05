<?php

namespace FluentSupportPro\App\Services\Integrations;

use FluentSupport\App\Services\Helper;
use FluentSupport\App\Services\ProfileInfoService;
use FluentSupport\Framework\Support\Arr;
use FluentSupportPro\App\Services\Integrations\Commerce\CommerceProviders;
use FluentSupportPro\App\Services\Integrations\Commerce\EddProvider;

class Edd
{
    public function boot()
    {
        add_filter('fluent_support/customer_extra_widgets', array($this, 'getPurchaseWidgets'), 60, 3);

        // Register the EDD commerce provider (entitlement lookups for the gate + workflow conditions).
        CommerceProviders::add(new EddProvider());

        // Custom Fields Support For EDD Products
        $this->renderCustomFields();
    }

    public function getEddPurchase($widgets, $customer)
    {
        $by = 'email';
        $value = $customer->email;
        if ($customer->user_id) {
            $by = 'ID';
            $value = $customer->user_id;
        }

        $user = get_user_by($by, $value);

        if (!$user) {
            return false;
        }

        $purchases = edd_get_payments([
            'user'   => $user->ID,
            'output' => 'payments'
        ]);

        if(!$purchases) {
            return false;
        }

        return $purchases;
    }

    public function renderCustomFields()
    {
        add_filter('fluent_support/custom_field_types', function ($fieldTypes) {
            $fieldTypes['edd_products'] = [
                'is_custom'   => true,
                'is_remote'   => true,
                'custom_text' => __('EDD products will be shown at the ticket form', 'fluent-support-pro'),
                'type'        => 'edd_products',
                'label'       => __('EDD Products', 'fluent-support-pro'),
                'value_type'  => 'number'
            ];
            $fieldTypes['edd_orders'] = [
                'is_custom'   => true,
                'is_remote'   => true,
                'custom_text' => __('EDD orders will be shown at the ticket form', 'fluent-support-pro'),
                'type'        => 'edd_orders',
                'label'       => __('EDD Orders', 'fluent-support-pro'),
                'value_type'  => 'number'
            ];

            return $fieldTypes;
        }, 10, 1);

        add_filter('fluent_support/render_custom_field_options_edd_orders', function ($field, $customer) {

            $orders = $this->getEddPurchase($field, $customer);

            if (!$orders) {
                return $field;
            }

            $options = [];

            foreach ($orders as $order) {

                $options[] = [
                    'id'    => strval($order->ID),
                    'title' => sprintf(__('Order #%d - %s', 'fluent-support-pro'), $order->ID, date_i18n(get_option('date_format'), strtotime($order->completed_date)))
                ];

            }
            if (!$options) return $field;

            $field['type'] = 'select';
            $field['filterable'] = true;
            $field['rendered'] = true;
            $field['options'] = $options;

            return $field;

        }, 10, 2);

        add_filter('fluent_support/custom_field_render_edd_orders', function ($value, $scope) {
            if (!is_numeric($value)) {
                return $value;
            }

            $orderId = absint($value);

            if ($scope == 'admin') {

                return '<a href="' . admin_url('edit.php?post_type=download&page=edd-payment-history&view=view-order-details&id=' . $orderId) . '">' . sprintf(__('Order #%d', 'fluent-support-pro'), $orderId) . '</a>';
            }

            global $edd_options;

            if (class_exists('\EDD_Payment')) {
                $edd = new \EDD_Payment($orderId);

                $url = get_permalink($edd_options['success_page']) . '?payment_key=' . $edd->key;

                return '<a target="_blank" rel="nofollow" href="' . $url . '">' . sprintf(__('Order #%d', 'fluent-support-pro'), $orderId) . '</a>';
            }

        }, 10, 2);

        add_filter('fluent_support/render_custom_field_options_edd_products', function ($field, $customer) {

            $products = $this->getEddProducts();

            if (!$products) {
                return false;
            }

            $options = [];

            foreach ($products as $product) {
                $options[] = [
                    'id'    => strval($product->ID),
                    'title' => (new \EDD_Download($product->ID))->post_title
                ];
            }
            if (!$options) return $field;

            $field['type'] = 'select';
            $field['rendered'] = true;
            $field['filterable'] = true;
            $field['options'] = $options;
            return $field;

        }, 10, 2);

        add_filter('fluent_support/custom_field_render_edd_products', function ($value) {
            if (!is_numeric($value)) {
                return $value;
            }

            $productId = absint($value);
            $product = get_post($productId);
            if (!$product) {
                return $value;
            }

            return '<a target="_blank" rel="nofollow" href="' . esc_url(get_permalink($product)) . '">' . esc_html($product->post_title) . '</a>';

        }, 10, 1);
    }

    public function getPurchaseWidgets($widgets, $customer, $context = null)
    {
        if ($context && !ProfileInfoService::wantsWidget($context, 'edd_purchases')) {
            return $widgets;
        }

        $payments = $this->getEddPurchase($widgets, $customer);

        if (!$payments) return $widgets;

        $licensesByPayment = [];
        foreach ($payments as $payment) {
            $licensesByPayment[$payment->ID] = $this->getLicenses($payment);
        }

        if ($context && ProfileInfoService::isMcpWidgetRequest($context)) {
            $widgets['edd_purchases'] = [
                'title' => __('EDD Purchases', 'fluent-support-pro'),
                'mcp'   => $this->getMcpData($payments, $licensesByPayment)
            ];

            return $widgets;
        }

        $widgets['edd_purchases'] = array_merge(
            ['title' => __('EDD Purchases', 'fluent-support-pro')],
            $this->getWidgetData($payments, $licensesByPayment)
        );

        return $widgets;
    }

    /**
     * Stats and recent purchases for the agent sidebar (see ProfileInfoService).
     *
     * @param array $payments The customer's latest \EDD_Payment objects, newest first.
     * @param array $licensesByPayment [payment_id => [download_id => license row]]
     * @return array
     */
    private function getWidgetData($payments, $licensesByPayment)
    {
        // Not edd_get_complete_order_statuses(): on EDD 3 it includes refunded and revoked.
        $paidStatuses = ['publish', 'complete', 'completed', 'edd_subscription', 'partially_refunded'];
        $voidStatuses = ['refunded', 'revoked', 'failed'];
        $storedInUtc = function_exists('edd_get_order');

        $paid = array_values(array_filter($payments, function ($payment) use ($paidStatuses) {
            return in_array($payment->status, $paidStatuses, true);
        }));

        $currency = $payments[0]->currency;
        $customerId = (int)$payments[0]->customer_id;
        $customer = $customerId && class_exists('\EDD_Customer') ? new \EDD_Customer($customerId) : null;

        // edd_get_payments() returns the latest 20 only; the customer record has the totals,
        // in the store currency.
        if ($customer && $customer->id) {
            $currency = edd_get_currency();
        }
        $lifetimeValue = $customer && $customer->id ? (float)$customer->purchase_value : array_sum(wp_list_pluck($paid, 'total'));
        $purchaseCount = $customer && $customer->id ? (int)$customer->purchase_count : count($paid);

        $firstPaid = $paid ? end($paid) : null;
        if ($customerId && $purchaseCount > count($paid)) {
            $oldest = edd_get_payments([
                'customer' => $customerId,
                'status'   => $paidStatuses,
                'number'   => 1,
                'orderby'  => 'date',
                'order'    => 'ASC',
                'output'   => 'payments',
            ]);
            $firstPaid = $oldest ? $oldest[0] : $firstPaid;
        }

        $stats = [
            [
                'label' => __('Lifetime Value', 'fluent-support-pro'),
                'value' => self::formatAmount($lifetimeValue, $currency),
                'url'   => $customer && $customer->id ? admin_url('edit.php?post_type=download&page=edd-customers&view=overview&id=' . $customer->id) : '',
            ],
            [
                'label' => __('Total Purchases:', 'fluent-support-pro'),
                'value' => (string)$purchaseCount,
            ],
        ];

        if ($paid && $firstPaid) {
            $stats[] = [
                'label' => __('Since', 'fluent-support-pro'),
                'value' => self::completedDateIso($firstPaid->completed_date, $storedInUtc),
                'type'  => 'date',
            ];
            $stats[] = [
                'label' => __('Last Purchase', 'fluent-support-pro'),
                'value' => self::completedDateIso($paid[0]->completed_date, $storedInUtc),
                'type'  => 'date',
            ];
        }

        $items = [];
        foreach ($payments as $payment) {
            $licenses = $licensesByPayment[$payment->ID];
            $isPaid = in_array($payment->status, $paidStatuses, true);
            $url = admin_url('edit.php?post_type=download&page=edd-payment-history&view=view-order-details&id=' . $payment->ID);

            foreach ($payment->cart_details as $cartDetail) {
                $licenseStatus = Arr::get($licenses, Arr::get($cartDetail, 'id') . '.status');

                if ($licenseStatus) {
                    $badge = ['text' => $licenseStatus, 'type' => $licenseStatus === 'active' ? 'success' : ($licenseStatus === 'expired' ? 'danger' : 'info')];
                } elseif (!$isPaid) {
                    $badge = ['text' => $payment->status_nicename, 'type' => in_array($payment->status, $voidStatuses, true) ? 'danger' : 'warning'];
                } else {
                    $badge = null;
                }

                $quantity = (int)Arr::get($cartDetail, 'quantity', 1);
                list($name, $option) = self::getProductAndOption($cartDetail);

                $items[] = [
                    'title'              => $quantity > 1
                        /* translators: 1: product name, 2: quantity */
                        ? sprintf(__('%1$s × %2$d', 'fluent-support-pro'), $name, $quantity)
                        : $name,
                    'meta'               => self::formatAmount(Arr::get($cartDetail, 'price'), $payment->currency),
                    'subtitle'           => $option,
                    'subtitle_meta'      => self::completedDateIso($payment->completed_date ?: $payment->date, $storedInUtc),
                    'subtitle_meta_type' => 'date',
                    'reference'          => ['text' => '#' . $payment->number, 'url' => $url],
                    'url'                => $url,
                    'badge'              => $badge,
                ];
            }
        }

        return [
            'stats_style' => 'summary',
            'stats'    => $stats,
            'sections' => [
                [
                    'label' => __('Recent Purchases', 'fluent-support-pro'),
                    'items' => array_slice($items, 0, 10),
                ],
            ],
        ];
    }

    /**
     * Product name and price option ("5 Sites") for a cart line; the option is '' when the download has none.
     *
     * @param array $cartDetail
     * @return array [name, option]
     */
    private static function getProductAndOption($cartDetail)
    {
        $name = (string)Arr::get($cartDetail, 'name');
        $priceId = Arr::get($cartDetail, 'item_number.options.price_id');

        if ($priceId === null || $priceId === '' || !edd_has_variable_prices(Arr::get($cartDetail, 'id'))) {
            return [$name, ''];
        }

        // EDD 3 stores "Product — Option" as named at purchase; split it so a later option rename doesn't show both.
        $separator = strrpos($name, ' — ');
        if ($separator !== false) {
            return [substr($name, 0, $separator), substr($name, $separator + strlen(' — '))];
        }

        // EDD 2 stored the product name only.
        return [$name, (string)edd_get_price_option_name(Arr::get($cartDetail, 'id'), $priceId)];
    }

    /**
     * An amount with its currency sign, as plain text.
     *
     * @param float|string $amount
     * @param string $currency
     * @return string
     */
    private static function formatAmount($amount, $currency)
    {
        return html_entity_decode(wp_strip_all_tags(edd_currency_filter(edd_format_amount($amount), $currency)), ENT_QUOTES, 'UTF-8');
    }

    /**
     * Plain purchase data for MCP agents.
     *
     * @param array $payments
     * @param array $licensesByPayment [payment_id => [download_id => license row]]
     * @return array
     */
    private function getMcpData($payments, $licensesByPayment)
    {
        $orders = [];
        $activeLicenses = 0;
        $validLicenses = 0;

        foreach ($payments as $payment) {
            $licenses = $licensesByPayment[$payment->ID];
            $items = [];

            foreach ($payment->cart_details as $cartDetail) {
                $items[] = [
                    'product_id'     => (int) Arr::get($cartDetail, 'id'),
                    'name'           => Arr::get($cartDetail, 'name'),
                    'qty'            => (int) Arr::get($cartDetail, 'quantity', 1),
                    'total'          => (float) Arr::get($cartDetail, 'price'),
                    'license_status' => Arr::get($licenses, $cartDetail['id'] . '.status') ?: null,
                ];
            }

            foreach ($licenses as $license) {
                $status = Arr::get($license, 'status');
                if ($status === 'active') {
                    $activeLicenses++;
                }
                // "inactive" is a valid license not activated on a site yet.
                if (in_array($status, ['active', 'inactive'], true)) {
                    $validLicenses++;
                }
            }

            $orders[] = [
                'id'       => (int) $payment->ID,
                'number'   => (string) $payment->number,
                'status'   => $payment->status,
                'total'    => (float) $payment->total,
                'currency' => $payment->currency,
                'date'     => self::completedDateIso($payment->completed_date, function_exists('edd_get_order')),
                'url'      => admin_url('edit.php?post_type=download&page=edd-payment-history&view=view-order-details&id=' . $payment->ID),
                'items'    => $items,
            ];
        }

        // edd_get_payments() returns the latest 20, so counts cover the listed orders only.
        return [
            'active_licenses' => $activeLicenses,
            'valid_licenses'  => $validLicenses,
            'orders'          => $orders,
        ];
    }

    /**
     * A payment's completed date as ISO 8601 in UTC.
     *
     * EDD 3 stores `date_completed` in UTC (EDD()->utils->date() defaults to UTC and EDD
     * itself parses it as UTC), while EDD 2 wrote `_edd_completed_date` with
     * current_time('mysql'), i.e. in the site's timezone.
     *
     * @param string|null $completedDate
     * @param bool $storedInUtc True on EDD 3 (edd_get_order() exists).
     * @return string|null
     */
    public static function completedDateIso($completedDate, $storedInUtc)
    {
        if (!$completedDate) {
            return null;
        }

        if ($storedInUtc) {
            $timestamp = strtotime($completedDate . ' UTC');

            return $timestamp ? gmdate('c', $timestamp) : null;
        }

        return get_gmt_from_date($completedDate, 'c');
    }

    private function getLicenses($payment)
    {
        if (!defined('EDD_SL_VERSION') || !$payment->user_id) {
            return [];
        }

        $licenses = Helper::FluentSupport('db')
            ->table('edd_licenses')
            ->where('user_id', $payment->user_id)
            ->where('payment_id', $payment->ID)
            ->get();

        if(!$licenses) {
            return [];
        }
        $formattedLicenses = [];
        foreach ($licenses as $license) {
            $formattedLicenses[$license->download_id] = (array) $license;
        }
        return $formattedLicenses;
    }

    private function getEddProducts()
    {
        return get_posts(array(
                'post_type'   => 'download',
                'post_status' => 'publish',
            )
        );
    }
    public function addToWorkflow($customField, $key)
    {
        $options = [];

        if('edd_products' == $key){
            $products = $this->getEddProducts();

            foreach ($products as $product) {
                $options[strval($product->ID)] = (new \EDD_Download($product->ID))->post_title;
            }

        } else {
            $orders = edd_get_payments();

            foreach ($orders as $order) {
                $options[strval($order->ID)] = sprintf(__('Order #%d - %s', 'fluent-support-pro'), $order->ID, date_i18n(get_option('date_format'), strtotime($order->completed_date)));
            }
        }

        return [
            'title'     => $customField['label'],
            'data_type' => 'single_dropdown',
            'group'     => 'Custom Fields',
            'options'   => $options
        ];
    }
}
