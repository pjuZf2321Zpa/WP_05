<?php

namespace FluentSupportPro\App\Services\Integrations\AI;

class AIService
{
    private $aiHelper;

    public function __construct(AIHelper $aiHelper)
    {
        $this->aiHelper = $aiHelper;
    }

    public function getPresetPrompts($type): array
    {
        return $this->aiHelper->getPresetPrompts($type);
    }

    public function modifyResponse(string $prompt, $selectedText, $ticketId)
    {
        return $this->aiHelper->modifyResponse($prompt, $selectedText, $ticketId);
    }

    public function generateResponse(string $responseContent, $ticket)
    {
        return $this->aiHelper->generateResponse($responseContent, $ticket);
    }

    public function getTicketSummary($ticket)
    {
        return $this->aiHelper->generateTicketSummary($ticket);
    }

    public function getTicketTone($ticket)
    {
        return $this->aiHelper->generateTicketTone($ticket);
    }
}
