<?php
namespace FluentSupportPro\App\Services\Integrations;

use FluentSupport\App\Services\ProfileInfoService;

class LearnPress
{
    public function boot()
    {
        add_filter('fluent_support/customer_extra_widgets', array($this, 'getLearnPressWidget'), 130, 3);

        // Custom Fields Support For LearnPress
        $this->renderCustomFields();
    }

    public function getLearnPressWidget ( $widgets, $customer, $context = null )
    {
        if ($context && !ProfileInfoService::wantsWidget($context, 'lp_user_data')) {
            return $widgets;
        }

        // getCourses() skips the user filter for an empty id and would list everyone's.
        if (!$customer->user_id) {
            return $widgets;
        }

        $enrolledCourses = $this->getCourses( $customer->user_id );

        if ( !$enrolledCourses ) {
            return $widgets;
        }

        if ($context && ProfileInfoService::isMcpWidgetRequest($context)) {
            $mcpCourses = [];
            foreach ($enrolledCourses as $data) {
                $mcpCourses[] = [
                    'id'          => (int) $data->item_id,
                    'title'       => $data->post_title,
                    'status'      => $data->status,
                    'graduation'  => $data->graduation,
                    'enrolled_at' => $this->toIso8601($data->start_time),
                    'finished_at' => $this->toIso8601(isset($data->end_time) ? $data->end_time : null),
                ];
            }

            $widgets['lp_user_data'] = [
                'title' => __('LearnPress', 'fluent-support-pro'),
                'mcp'   => [
                    'enrolled_courses' => count($mcpCourses),
                    'passed_courses'   => count(array_filter($mcpCourses, function ($course) {
                        return $course['graduation'] === 'passed';
                    })),
                    'courses'          => $mcpCourses,
                ],
            ];

            return $widgets;
        }

        ob_start();
        ?>
        <ul>
            <?php foreach ($enrolledCourses as $data): ?>
                <li title="<?php echo esc_attr(sprintf(__('Course Name: %s', 'fluent-support-pro'), $data->post_title)) ?>" class="fs_widget_li">
                    <?php
                    echo '<code>'. __('Course Name:', 'fluent-support-pro') .'</code> '. esc_html($data->post_title) . '<br>';
                    echo '<code>'. __('Graduation:', 'fluent-support-pro') .'</code> '. esc_html($data->graduation) . '<br>';
                    echo '<code>'. __('Status:', 'fluent-support-pro') .'</code> '. esc_html($data->status) . '<br>';
                    echo '<code>'. __('Started At:', 'fluent-support-pro') .'</code> '. esc_html($data->start_time) . '<br>';
                    ?>
                </li>
            <?php endforeach; ?>
        </ul>

        <?php
        $content = ob_get_clean();

        $widgets['lp_user_data'] = [
            'header' => __('LearnPress', 'fluent-support-pro'),
            'body_html' => $content
        ];

        return $widgets;
    }

    private function toIso8601($datetime)
    {
        if (!$datetime || strpos($datetime, '0000-00-00') === 0) {
            return null;
        }

        $formatted = mysql2date('c', $datetime);

        return $formatted ?: null;
    }

    private function getCourses ( $customerUserId = false )
    {
        $enrollmentsQuery = \FluentSupport\App\App::getInstance('db')->table('learnpress_user_items')
            ->select(['learnpress_user_items.*', 'posts.post_title'])
            ->where('learnpress_user_items.item_type', 'lp_course')
            ->join('posts', 'posts.ID', '=', 'learnpress_user_items.item_id')
            ->orderBy('learnpress_user_items.user_item_id', 'DESC');

        if ( $customerUserId ) {
            $enrollmentsQuery->where('learnpress_user_items.user_id', $customerUserId);
        }

        return $enrollmentsQuery->get();
    }

    public function renderCustomFields ()
    {
        $this->registerCustomFields();

        $this->learnPressCourseOptions();

        $this->learnPressUserCourseOptions();

        $hooks = ['learnpress_courses', 'learnpress_user_courses'];

        foreach ($hooks as $hook) {
            add_filter('fluent_support/custom_field_render_'. $hook, function ($value){
                if (!is_numeric($value)) {
                    return $value;
                }

                $courseId = absint($value);

                if (!$courseId) return $value;

                return '<a target="_blank" rel="nofollow" href="' . get_permalink($courseId) . '">' . get_the_title($courseId) . '</a>';
            }, 10,1);
        }
    }

    private function registerCustomFields ()
    {
        add_filter('fluent_support/custom_field_types', function ($fieldTypes) {
            $fieldTypes['learnpress_courses'] = [
                'is_custom'   => true,
                'is_remote'   => true,
                'custom_text' => __('LearnPress Courses will be shown at the ticket form', 'fluent-support-pro'),
                'type'        => 'learnpress_courses',
                'label'       => __('LearnPress Courses', 'fluent-support-pro'),
                'value_type'  => 'number'
            ];
            $fieldTypes['learnpress_user_courses'] = [
                'is_custom'   => true,
                'is_remote'   => true,
                'custom_text' => __('LearnPress User Courses will be shown at the ticket form', 'fluent-support-pro'),
                'type'        => 'learnpress_user_courses',
                'label'       => __('LearnPress User Courses', 'fluent-support-pro'),
                'value_type'  => 'number'
            ];

            return $fieldTypes;
        }, 10, 1);
    }

    private function learnPressCourseOptions()
    {
        add_filter('fluent_support/render_custom_field_options_learnpress_courses', function ($field, $customer) {
            $courses = $this->getCourses();

            if ( ! $courses ) {
                return $field;
            }

            $options = [];

            foreach ( $courses as $course ) {
                $options[] = [
                    'id'    => strval($course->item_id),
                    'title' => $course->post_title
                ];
            }

            if(!$options) return $field;

            $field['type'] = 'select';
            $field['filterable'] = true;
            $field['rendered'] = true;
            $field['options'] = $options;

            return $field;

        }, 10, 2);
    }

    private function learnPressUserCourseOptions()
    {
        add_filter('fluent_support/render_custom_field_options_learnpress_user_courses', function ($field, $customer) {

            $courses = $this->getCourses( $customer->user_id );

            if(!$courses) return;

            $options = [];

            foreach ($courses as $course) {
                $options[] = [
                    'id'    => strval($course->item_id),
                    'title' => $course->post_title
                ];
            }

            $field['type'] = 'select';
            $field['filterable'] = true;
            $field['rendered'] = true;
            $field['options'] = $options;

            return $field;

        }, 10, 2);
    }

    public function addToWorkflow($customField, $key)
    {
        $options = [];

        $courses = $this->getCourses();

        foreach ($courses as $course) {
            $options[$course->ID] = $course->post_title;
        }

        return [
            'title'     => $customField['label'],
            'data_type' => 'single_dropdown',
            'group'     => 'Custom Fields',
            'options'   => $options
        ];
    }
}
