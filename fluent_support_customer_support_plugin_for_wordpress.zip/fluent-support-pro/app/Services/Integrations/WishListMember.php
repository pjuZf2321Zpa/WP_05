<?php

namespace FluentSupportPro\App\Services\Integrations;

use FluentSupport\App\Services\ProfileInfoService;

class WishListMember
{

    public function boot()
    {
        add_filter('fluent_support/customer_extra_widgets', array($this, 'getWLMembershipInfo'), 110, 3);

        // Custom Fields Support For WishListMember
        $this->renderCustomFields();
    }

    public function renderCustomFields()
    {
	    add_filter('fluent_support/custom_field_types', function ($fieldTypes) {
		    $fieldTypes['wlm_levels'] = [
			    'is_custom'   => true,
			    'is_remote'   => true,
			    'custom_text' => __('WishListMember levels will be shown at the ticket form', 'fluent-support-pro'),
			    'type'        => 'wlm_levels',
			    'label'       => __('WishListMember Levels', 'fluent-support-pro'),
			    'value_type'  => 'number'
		    ];
		    $fieldTypes['wlm_user_levels'] = [
			    'is_custom'   => true,
			    'is_remote'   => true,
			    'custom_text' => __('WishListMember user levels will be shown at the ticket form', 'fluent-support-pro'),
			    'type'        => 'wlm_user_levels',
			    'label'       => __('WishListMember User Levels', 'fluent-support-pro'),
			    'value_type'  => 'number'
		    ];

		    return $fieldTypes;
	    }, 10, 1);

	    add_filter('fluent_support/render_custom_field_options_wlm_levels', function ($field, $customer) {
		    $levelBlocks = wlmapi_get_levels();

		    if (!$levelBlocks) return $field;

		    $levels = $levelBlocks['levels']['level'];

            if(!$levels) return $field;

		    $options = [];

		    foreach ($levels as $level) {
			    $options[] = [
				    'id'    => strval($level['id']),
				    'title' => $level['name']
			    ];
		    }
		    if(!$options) return $field;

		    $field['type'] = 'select';
		    $field['filterable'] = true;
		    $field['rendered'] = true;
		    $field['options'] = $options;

		    return $field;

	    }, 10, 2);

	    add_filter('fluent_support/render_custom_field_options_wlm_user_levels', function ($field, $customer) {
		    $levels = wlmapi_get_member_levels($customer->user_id);

		    if (!$levels) return $field;

		    $options = [];

		    foreach ($levels as $level) {
			    $options[] = [
				    'id'    => strval($level->Level_ID),
				    'title' => $level->Name
			    ];
		    }
		    if(!$options) return $field;

		    $field['type'] = 'select';
		    $field['filterable'] = true;
		    $field['rendered'] = true;
		    $field['options'] = $options;

		    return $field;

	    }, 10, 2);

	    $hooks = ['wlm_levels', 'wlm_user_levels'];

	    foreach ($hooks as $hook) {
		    add_filter('fluent_support/custom_field_render_'. $hook, function ($value){

			    if (!is_numeric($value)) {
				    return $value;
			    }

			    $levelId = absint($value);

			    if (!$levelId) return $value;
                $level = wlmapi_get_level($levelId);

                if (!$level) return;
			    return $level['level']['name'];
		    }, 10,1);
	    }
    }

    public function getWLMembershipInfo($widgets, $customer, $context = null)
    {
        // $context is null on Fluent Support versions that don't pass it.
        if ($context && !ProfileInfoService::wantsWidget($context, 'wlm')) {
            return $widgets;
        }

        // A filter must return $widgets: a bare return drops every other widget.
        if (!$customer->user_id) return $widgets;

        $levels = wlmapi_get_member_levels($customer->user_id);

        if (empty($levels)) return $widgets;

        if ($context && ProfileInfoService::isMcpWidgetRequest($context)) {
            $widgets['wlm'] = [
                'title' => __('WishList Member', 'fluent-support-pro'),
                'mcp'   => $this->getMcpData($levels),
            ];
            return $widgets;
        }

        $membershipInfo = [];
        foreach ($levels as $level) {
            $membershipInfo[] = [
                'level'  => esc_html($level->Name),
                'status' => esc_html($level->Status[0])
            ];
        }

        if (empty($membershipInfo)) return $widgets;

        ob_start();
        ?>

        <ul>
            <?php foreach ($membershipInfo as $info): ?>
                <li title="<?php $info['level'] ?>" class="fs_widget_li">
                    <?php
                    echo '<code>'.__('Level:', 'fluent-support-pro').'</code> '. $info['level'] . '<br>';
                    echo '<code>'. __('Status:', 'fluent-support-pro') .'</code> '. $info['status'] . '<br>';
                    ?>
                </li>
            <?php endforeach; ?>
        </ul>
        <?php
        $content = ob_get_clean();

        $widgets['wlm'] = [
            'header'    => __('WishList Member', 'fluent-support-pro'),
            'body_html' => $content
        ];
        return $widgets;
    }

    /**
     * Status slug from WishList Member's state flags. $level->Status holds translated
     * labels ("Actif"), so it is only a last resort.
     */
    private static function levelStatus($level)
    {
        $flags = ['Cancelled' => 'cancelled', 'Expired' => 'expired', 'Pending' => 'pending', 'UnConfirmed' => 'unconfirmed', 'Active' => 'active'];
        $known = false;

        foreach ($flags as $property => $slug) {
            if (isset($level->{$property})) {
                $known = true;
                if ($level->{$property}) {
                    return $slug;
                }
            }
        }

        if ($known) {
            return 'inactive';
        }

        return !empty($level->Status) ? sanitize_key((string) $level->Status[0]) : '';
    }

    private function getMcpData($levels)
    {
        $memberships = [];
        foreach ($levels as $level) {
            $memberships[] = [
                'id'         => (int) $level->Level_ID,
                'name'       => (string) $level->Name,
                'status'     => self::levelStatus($level),
                'start_date' => !empty($level->Timestamp) ? gmdate('c', (int) $level->Timestamp) : null,
                'end_date'   => !empty($level->ExpiryDate) ? gmdate('c', (int) $level->ExpiryDate) : null,
            ];
        }

        $activeCount = count(array_filter($memberships, function ($item) {
            return $item['status'] === 'active';
        }));

        return [
            'active_memberships' => $activeCount,
            'memberships'        => $memberships,
        ];
    }

    public function addToWorkflow($customField, $key)
    {
        $options = [];

        $levelBlocks = wlmapi_get_levels();

        $levels = $levelBlocks['levels']['level'];

        foreach ($levels as $level) {
            $options[$level['id']] = $level['name'];
        }

        return [
            'title'     => $customField['label'],
            'data_type' => 'single_dropdown',
            'group'     => 'Custom Fields',
            'options'   => $options
        ];
    }
}
