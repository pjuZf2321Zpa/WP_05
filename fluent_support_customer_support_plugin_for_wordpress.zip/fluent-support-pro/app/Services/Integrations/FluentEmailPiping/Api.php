<?php

namespace FluentSupportPro\App\Services\Integrations\FluentEmailPiping;

class Api
{
    protected $apiUrl = 'https://apiv2.wpmanageninja.com/email-piping/';

    /**
     * Pipe features this build handles. The pipe only delivers mailer-daemon
     * bounces to channels that list 'bounce'; older builds would turn them into
     * tickets and loop.
     */
    const FEATURES = ['bounce'];

    /** Mailbox meta holding the feature list the pipe echoed back. */
    const FEATURES_META = '_pipe_features';

    public static function featuresParam()
    {
        return implode(',', self::FEATURES);
    }

    /**
     * Whether the pipe already has this mailbox's full feature list.
     *
     * @param \FluentSupport\App\Models\MailBox $box
     * @return bool
     */
    public static function featuresSynced($box)
    {
        $stored = (array) $box->getMeta(self::FEATURES_META, []);

        return !array_diff(self::FEATURES, $stored);
    }

    /**
     * Remember the list the pipe echoed (what it will honour).
     *
     * @param \FluentSupport\App\Models\MailBox $box
     * @param array $response
     */
    public static function rememberFeatures($box, $response)
    {
        if (is_array($response) && isset($response['features']) && is_array($response['features'])) {
            $box->saveMeta(self::FEATURES_META, array_values(array_map('sanitize_key', $response['features'])));
        }
    }

    public function syncFeatures($data)
    {
        // Runs ahead of the email fetch, so it must not hold it up for long.
        return $this->request('features', $data, 'POST', 10);
    }

    public function issuePipeEmail($data)
    {
        return $this->request('issue', $data, 'POST');
    }

    public function getPipeEmailStatus($data)
    {
        return $this->request('status', $data, 'POST');
    }

    public function removeMailBox($data)
    {
        return $this->request('remove', $data, 'POST');
    }

    /**
     * Every request here carries the site license and the mailbox bearer token, so the
     * certificate must be verified. That is WordPress' default — never set `sslverify`
     * to false on this client, however tempting it looks while chasing a local cert error.
     */
    public function request($route, $data, $method = 'POST', $timeout = 45)
    {

        $response = wp_remote_request($this->apiUrl . $route, [
            'method'    => $method,
            'body'      => $data,
            'timeout'     => (int) $timeout,
            'redirection' => 0,
            'blocking'    => true,
            'headers'     => array(),
            'cookies'     => array()
        ]);

        if (is_wp_error($response)) {
            return $response;
        }

        $responseCode = wp_remote_retrieve_response_code($response);

        $decoded = json_decode(wp_remote_retrieve_body($response), true);

        $responseArray = is_array($decoded) ? $decoded : [];

        if ($responseCode >= 300) {
            $message = isset($responseArray['message'])
                ? $responseArray['message']
                : 'Failed to communicate with API server';

            return new \WP_Error($responseCode, $message, $responseArray);
        }

        // Callers index straight into the result, so a body that is not a JSON object has
        // to fail closed here rather than reach them as null.
        if (!is_array($decoded)) {
            return new \WP_Error(
                'fs_invalid_api_response',
                __('Unexpected response from the email piping service', 'fluent-support-pro')
            );
        }

        return $decoded;
    }

}
