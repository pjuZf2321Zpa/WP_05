<?php

namespace FluentSupportPro\App\Services\Integrations\FluentEmailPiping;

use FluentSupport\App\Models\Conversation;
use FluentSupport\App\Models\Ticket;
use FluentSupport\App\Services\Helper;
use FluentSupport\Framework\Support\Arr;

/**
 * Keeps machine-sent email (out-of-office replies, delivery failures) out of the
 * ticket flow. Such mail must never open a ticket or count as a customer reply: that
 * reopens closed tickets, notifies agents for nothing, and can start a mail loop.
 *
 * Three kinds, following RFC 3834:
 *   - bounce: a delivery failure.
 *   - auto_reply: an automatic answer to a message (out of office, vacation). Kept as
 *     an internal note on the ticket it threads to (signed fst reference), so agents
 *     still see "away until Monday"; otherwise dropped.
 *   - automated: machine mail that answers nothing (Auto-Submitted: auto-generated,
 *     Precedence: bulk/junk/list): payment notices, alerts, form notifications. It may
 *     be real work, so it goes through the normal flow, but no automatic email is sent
 *     back to it (AutoReplyGuard).
 *
 * Only strong signals drop mail: the pipe's `bounce` details, a delivery-status
 * report, auto-reply headers (Auto-Submitted: auto-replied, X-Autoreply,
 * X-Autorespond, Precedence: auto_reply), or a machine header together with an
 * auto-reply marker (Exchange out-of-office: Auto-Submitted: auto-generated plus
 * "Automatic reply:" or X-Auto-Response-Suppress: OOF). Weak signals never drop it, because real
 * customers write "Auto reply not working" or "Undelivered emails": a matching
 * subject, a postmaster@/mailer-daemon@ sender, the pipe's subject-based auto_reply
 * flag and X-Auto-Response-Suppress (a sender asking not to be auto-answered) only
 * make the mail automated: it is handled normally, with no confirmation sent back.
 */
class AutoMailHandler
{
    const NORMAL = 'normal';
    const AUTO_REPLY = 'auto_reply';
    const BOUNCE = 'bounce';
    const AUTOMATED = 'automated';

    const NOTE_EXCERPT_CHARS = 600;

    /**
     * @param array $data Raw pipe payload.
     * @param string $senderEmail
     * @return string One of the class constants.
     */
    public static function classify(array $data, $senderEmail)
    {
        $headers = array_change_key_case((array) Arr::get($data, 'headers', []), CASE_LOWER);
        $subject = (string) Arr::get($data, 'subject', '');
        $localPart = strtolower((string) strstr((string) $senderEmail, '@', true));

        $kind = self::NORMAL;

        // Check bounces first: a Postfix bounce also says Auto-Submitted: auto-replied.
        // The pipe sends `bounce` (possibly {}) on every report and mailer-daemon message.
        if (array_key_exists('bounce', $data) && is_array($data['bounce'])) {
            $kind = self::BOUNCE;
        } elseif (self::headersSayBounce($headers)) {
            $kind = self::BOUNCE;
        } elseif (self::headersSayAutoReply($headers)) {
            $kind = self::AUTO_REPLY;
        } elseif (self::headersSayMachineOrigin($headers)
            && (self::subjectSaysAutoReply($subject) || self::suppressSaysAutoReply($headers))) {
            // Exchange/Outlook out-of-office: Auto-Submitted: auto-generated (not
            // auto-replied) plus "Automatic reply:" or X-Auto-Response-Suppress: OOF.
            // A machine-origin header and an auto-reply marker together are an auto-reply;
            // either alone is still only automated.
            $kind = self::AUTO_REPLY;
        } elseif (self::headersSayAutomated($headers)
            || !empty($data['automated'])
            // The pipe's auto_reply flag also matches subjects; without our header rules
            // agreeing it may be a person, so keep the mail.
            || !empty($data['auto_reply'])
            || self::subjectSaysAutoReply($subject)
            || self::subjectSaysBounce($subject)
            || in_array($localPart, ['mailer-daemon', 'postmaster'], true)) {
            $kind = self::AUTOMATED;
        }

        /**
         * Filter how an incoming email is classified before it reaches the ticket flow.
         *
         * @param string $kind 'normal', 'auto_reply', 'automated' or 'bounce'.
         * @param array $data Raw pipe payload.
         */
        return apply_filters('fluent_support_pro/email_piping_classification', $kind, $data);
    }

    /**
     * Note a classified message on the ticket it belongs to, or drop it.
     *
     * @param string $kind
     * @param array $data Raw pipe payload.
     * @param string $senderEmail
     * @param \FluentSupport\App\Models\MailBox $box
     * @return array Result for the pipe ('confirmed', so it is not retried).
     */
    public static function handle($kind, array $data, $senderEmail, $box)
    {
        $bounce = $kind === self::BOUNCE ? (array) Arr::get($data, 'bounce', []) : [];

        // Delay notices and "delivered"/"relayed" reports are not failures.
        $action = strtolower(trim((string) Arr::get($bounce, 'action', '')));
        if ($kind === self::BOUNCE && $action !== '' && $action !== 'failed') {
            return [
                'type'    => 'confirmed',
                'message' => 'bounce_report_ignored',
            ];
        }

        $ticket = $kind === self::BOUNCE
            ? self::bouncedTicket($data, $bounce)
            : EmailThreading::findTicket(Arr::get($data, 'inReplyTo'), Arr::get($data, 'references'));

        // Like a normal reply, an auto-reply must come from the ticket's customer or a CC.
        // A bounce comes from a mail server; the signed reference alone identifies it.
        if ($ticket && $kind === self::AUTO_REPLY && !self::isParticipant($ticket, $senderEmail)) {
            $ticket = null;
        }

        if (!$ticket) {
            self::dropped($kind, $data, $senderEmail, $box);

            return [
                'type'    => 'confirmed',
                'message' => $kind . '_skipped',
            ];
        }

        $note = $kind === self::BOUNCE
            ? self::bounceNote($bounce, $data)
            : self::autoReplyNote($senderEmail, $data);

        \FluentSupportPro\App\Services\CoreCompat::addActivity($ticket, $ticket->customer_id, $note, ['source' => 'email']);

        if ($kind === self::BOUNCE) {
            /**
             * Fires when an email we sent for this ticket could not be delivered.
             *
             * @param Ticket $ticket
             * @param array $bounce recipient, action, status, diagnostic, reporting_mta, original_* (any may be missing).
             */
            do_action('fluent_support_pro/email_bounced', $ticket, $bounce);
        } else {
            /**
             * Fires when an automatic reply (e.g. out of office) arrives on a ticket.
             *
             * @param Ticket $ticket
             * @param string $senderEmail
             */
            do_action('fluent_support_pro/email_auto_reply_received', $ticket, $senderEmail);
        }

        return [
            'type'      => 'confirmed',
            'message'   => $kind . '_noted',
            'ticket_id' => $ticket->id,
        ];
    }

    /**
     * The ticket whose email bounced: the original message's threading headers first,
     * then a signed reference anywhere in the report (older payloads inline it).
     *
     * @return Ticket|null
     */
    private static function bouncedTicket(array $data, array $bounce)
    {
        $ticket = EmailThreading::findTicket(
            Arr::get($bounce, 'original_in_reply_to'),
            [Arr::get($bounce, 'original_references'), Arr::get($bounce, 'original_message_id')]
        );

        if (!$ticket) {
            $ticket = EmailThreading::findTicket(Arr::get($data, 'inReplyTo'), Arr::get($data, 'references'));
        }

        if (!$ticket) {
            // Bounces without a delivery-status part (Exim, qmail, old sendmail) quote the
            // original's headers in the text. The pipe entity-encodes that text and may
            // linkify the reference as a mailto, so match the bare token, then let
            // findTicket() verify its signature.
            $body = html_entity_decode((string) Arr::get($data, 'body_text', ''), ENT_QUOTES | ENT_HTML5, 'UTF-8');
            if (preg_match_all('/fst\.\d+\.[a-f0-9]{16}@[^\s<>"]+/i', $body, $matches)) {
                $ticket = EmailThreading::findTicket(implode(' ', array_map(function ($token) {
                    return '<' . $token . '>';
                }, array_unique($matches[0]))), null);
            }
        }

        return $ticket;
    }

    const DROPPED_LOG_OPTION = 'fs_pipe_dropped_mail';
    const DROPPED_LOG_SIZE = 50;

    /**
     * A message that reached no ticket is confirmed to the pipe and never replayed,
     * so leave a trace an operator can find: a capped log and a hook.
     *
     * @param string $kind
     * @param array $data Raw pipe payload.
     * @param string $senderEmail
     * @param \FluentSupport\App\Models\MailBox $box
     */
    private static function dropped($kind, array $data, $senderEmail, $box)
    {
        $entry = [
            'time'       => current_time('mysql'),
            'kind'       => $kind,
            'box_id'     => $box ? (int) $box->id : 0,
            'from'       => sanitize_email((string) $senderEmail),
            'subject'    => sanitize_text_field((string) Arr::get($data, 'subject', '')),
            'message_id' => (string) \FluentSupportPro\App\Services\ProHelper::sanitizeMessageId((string) Arr::get($data, 'messageId', '')),
        ];

        $log = get_option(self::DROPPED_LOG_OPTION, []);
        $log = is_array($log) ? $log : [];
        $log[] = $entry;
        update_option(self::DROPPED_LOG_OPTION, array_slice($log, -self::DROPPED_LOG_SIZE), false);

        /**
         * Fires when an incoming email is discarded: an automatic reply or bounce that
         * belongs to no ticket. The pipe will not resend it.
         *
         * @param string $kind 'auto_reply' or 'bounce'.
         * @param array $data Raw pipe payload.
         * @param string $senderEmail
         * @param \FluentSupport\App\Models\MailBox $box
         */
        do_action('fluent_support_pro/email_piping_dropped', $kind, $data, $senderEmail, $box);
    }

    private static function isParticipant(Ticket $ticket, $email)
    {
        $email = strtolower(trim((string) $email));
        $ticket->loadMissing('customer');

        if ($ticket->customer && strtolower(trim($ticket->customer->email)) === $email) {
            return true;
        }

        return in_array($email, array_map('strtolower', (array) $ticket->getSettingsValue('all_cc_email', [])), true);
    }

    private static function bounceNote(array $bounce, array $data)
    {
        $recipient = sanitize_text_field((string) Arr::get($bounce, 'recipient', ''));
        $status = sanitize_text_field((string) Arr::get($bounce, 'status', ''));
        $diagnostic = sanitize_text_field((string) Arr::get($bounce, 'diagnostic', ''));

        if ($recipient) {
            /* translators: %s is the email address that could not be reached */
            $note = sprintf(__('An email to %s could not be delivered.', 'fluent-support-pro'), $recipient);
        } else {
            $note = __('An email for this ticket could not be delivered.', 'fluent-support-pro');
        }

        $details = trim(implode(' ', array_filter([$status, $diagnostic])));
        if ($details === '') {
            $details = self::excerpt((string) Arr::get($data, 'body_text', ''));
        }

        return '<p>' . esc_html($note) . '</p>' . ($details !== '' ? '<p><code>' . esc_html($details) . '</code></p>' : '');
    }

    private static function autoReplyNote($senderEmail, array $data)
    {
        /* translators: %s is the email address that sent the automatic reply */
        $note = sprintf(__('Automatic reply received from %s.', 'fluent-support-pro'), sanitize_email($senderEmail));
        $subject = sanitize_text_field((string) Arr::get($data, 'subject', ''));
        $excerpt = self::excerpt((string) Arr::get($data, 'body_text', ''));

        return '<p>' . esc_html($note) . '</p>'
            . ($subject !== '' ? '<p><strong>' . esc_html($subject) . '</strong></p>' : '')
            . ($excerpt !== '' ? '<blockquote>' . esc_html($excerpt) . '</blockquote>' : '');
    }

    private static function excerpt($html)
    {
        // Decode first: esc_html() would mangle HTML5-only names like &epsi; to &amp;epsi;.
        // Guarded so an older core can't fatal mid-pipe; remove once min core has the helper.
        $text = wp_strip_all_tags($html);
        if (method_exists(Helper::class, 'decodeNonMarkupEntities')) {
            $text = Helper::decodeNonMarkupEntities($text);
        }
        $text = trim(preg_replace('/\s+/u', ' ', $text));

        return mb_strlen($text) > self::NOTE_EXCERPT_CHARS ? mb_substr($text, 0, self::NOTE_EXCERPT_CHARS) . "\u{2026}" : $text;
    }

    private static function headersSayBounce(array $headers)
    {
        if (!empty($headers['x-failed-recipients'])) {
            return true;
        }

        $contentType = strtolower((string) Arr::get($headers, 'content-type', ''));

        return strpos($contentType, 'multipart/report') !== false && strpos($contentType, 'delivery-status') !== false;
    }

    // An automatic answer to a message: the kind that loops.
    private static function headersSayAutoReply(array $headers)
    {
        if (strpos(strtolower((string) Arr::get($headers, 'auto-submitted', '')), 'auto-replied') === 0) {
            return true;
        }

        foreach (['x-autoreply', 'x-autorespond'] as $key) {
            if (isset($headers[$key]) && $headers[$key] !== '') {
                return true;
            }
        }

        return in_array(strtolower(trim((string) Arr::get($headers, 'precedence', ''))), ['auto_reply', 'auto-reply'], true);
    }

    // Machine mail that answers nothing: may be real work, but never auto-answer it.
    private static function headersSayAutomated(array $headers)
    {
        if (self::headersSayMachineOrigin($headers)) {
            return true;
        }

        // The sender asks not to be auto-answered (MS-OXCMAIL); the mail itself may be a
        // person's, so it is kept, only our confirmation is held back.
        return isset($headers['x-auto-response-suppress']) && trim((string) $headers['x-auto-response-suppress']) !== '';
    }

    // The message itself was produced by a machine (RFC 3834 / bulk precedence), as
    // opposed to a person's mail that merely asks not to be auto-answered.
    private static function headersSayMachineOrigin(array $headers)
    {
        $autoSubmitted = strtolower(trim((string) Arr::get($headers, 'auto-submitted', '')));
        if ($autoSubmitted !== '' && $autoSubmitted !== 'no') {
            return true;
        }

        if (isset($headers['x-autogenerated']) && $headers['x-autogenerated'] !== '') {
            return true;
        }

        return in_array(strtolower(trim((string) Arr::get($headers, 'precedence', ''))), ['bulk', 'junk', 'list'], true);
    }

    // X-Auto-Response-Suppress naming OOF or AutoReply (MS-OXCMAIL) on machine mail: an
    // out-of-office reply. 'All' alone is not: bulk senders set it on notices.
    private static function suppressSaysAutoReply(array $headers)
    {
        $tokens = array_map('trim', explode(',', strtolower((string) Arr::get($headers, 'x-auto-response-suppress', ''))));

        return (bool) array_intersect($tokens, ['oof', 'autoreply']);
    }

    private static function subjectSaysAutoReply($subject)
    {
        // Leading [TAG]s are skipped, as the pipe does.
        return (bool) preg_match('/^\s*(\[[^\]]*\]\s*)*(automatic reply|auto[- ]?reply|auto[- ]?response|autosvar|out of (the )?office|abwesenheit|r[ée]ponse automatique|respuesta autom[áa]tica|risposta automatica|automatisch antwoord|resposta autom[áa]tica)\b/iu', $subject);
    }

    private static function subjectSaysBounce($subject)
    {
        return (bool) preg_match('/^\s*(undeliver(able|ed)( mail)?|delivery status notification \((failure|delay)\)|mail delivery (failed|failure|subsystem)|returned mail|failure notice|delivery failure)\b/iu', $subject);
    }
}
