<?php

namespace FluentSupportPro\App\Services\Integrations\FluentEmailPiping;

/**
 * Caps the automatic emails sent back for mail that came in by email: the "ticket
 * created" confirmation, and a reply a workflow adds in response to a customer reply.
 *
 * Two autoresponders can bounce messages off each other: their out-of-office reply
 * opens a ticket, our confirmation triggers another out-of-office reply, and so on.
 * Inbound detection drops most auto-replies, but one that slips through (no headers,
 * unusual subject) must not loop. So, per customer within WINDOW seconds: at most
 * MAX_PER_WINDOW automatic emails, and at most MAX_SAME_SUBJECT for the same subject.
 * A reply an agent writes is never held.
 */
class AutoReplyGuard
{
    const WINDOW = 3 * HOUR_IN_SECONDS;
    const MAX_PER_WINDOW = 10;
    const MAX_SAME_SUBJECT = 2;

    /** Automatic emails sent in response to an incoming email. */
    const GUARDED_TYPES = ['ticket_created_email_to_customer'];

    /** Emails that are automatic only when the response behind them was added by a workflow. */
    const AUTOMATION_GUARDED_TYPES = ['ticket_replied_by_agent_email_to_customer'];

    /** Sender whose mail is being processed as automated: send it nothing automatic. */
    private static $heldFor = null;

    /** Ticket id whose workflow-added reply is being announced right now. */
    private static $automationReplyTicketId = null;

    public static function holdFor($email)
    {
        self::$heldFor = strtolower(trim((string) $email));
    }

    public static function release()
    {
        self::$heldFor = null;
    }

    public static function register()
    {
        add_filter('fluent_support/should_send_notification', [__CLASS__, 'filter'], 999, 5);

        // Bracket the reply email hooks (priority 10) so filter() can tell a
        // workflow's reply from an agent's: the notification filter gets no response.
        add_action('fluent_support/response_added_by_agent', [__CLASS__, 'noteAutomationReply'], 1, 3);
        add_action('fluent_support/response_added_by_agent', [__CLASS__, 'forgetAutomationReply'], PHP_INT_MAX, 3);
    }

    public static function noteAutomationReply($response, $ticket = null, $agent = null)
    {
        if ($response && $response->source === 'automation' && $ticket) {
            self::$automationReplyTicketId = (int) $ticket->id;
        }
    }

    public static function forgetAutomationReply($response = null, $ticket = null, $agent = null)
    {
        self::$automationReplyTicketId = null;
    }

    /**
     * @param \FluentSupport\App\Models\Ticket|null $ticket
     */
    public static function filter($shouldSend, $channel = '', $type = '', $ticket = null, $person = null)
    {
        if (!$shouldSend || $channel !== 'email') {
            return $shouldSend;
        }

        $automationReply = in_array($type, self::AUTOMATION_GUARDED_TYPES, true)
            && $ticket && self::$automationReplyTicketId !== null
            && (int) $ticket->id === self::$automationReplyTicketId;

        if (!$automationReply && !in_array($type, self::GUARDED_TYPES, true)) {
            return $shouldSend;
        }

        if (!$ticket || empty($ticket->customer_id) || $ticket->source !== 'email') {
            return $shouldSend;
        }

        // Automated mail (Auto-Submitted: auto-generated, Precedence: bulk...) gets no
        // automatic answer at all.
        if (self::$heldFor !== null) {
            $ticket->loadMissing('customer');
            if ($ticket->customer && strtolower(trim($ticket->customer->email)) === self::$heldFor) {
                return false;
            }
        }

        return self::allow((int) $ticket->customer_id, (string) $ticket->title);
    }

    /**
     * Record a confirmation for this customer and say whether it may be sent.
     *
     * @param int $customerId
     * @param string $subject
     * @return bool
     */
    public static function allow($customerId, $subject)
    {
        $key = 'fs_pipe_autoreply_' . $customerId;
        $now = time();
        $subjectHash = md5(strtolower(trim($subject)));

        $sent = get_transient($key);
        $sent = array_values(array_filter(is_array($sent) ? $sent : [], function ($entry) use ($now) {
            return is_array($entry) && isset($entry['t']) && $entry['t'] > $now - self::WINDOW;
        }));

        $sameSubject = count(array_filter($sent, function ($entry) use ($subjectHash) {
            return isset($entry['s']) && $entry['s'] === $subjectHash;
        }));

        $maxPerWindow = (int) apply_filters('fluent_support_pro/auto_reply_guard_max', self::MAX_PER_WINDOW, $customerId);
        $maxSameSubject = (int) apply_filters('fluent_support_pro/auto_reply_guard_max_same_subject', self::MAX_SAME_SUBJECT, $customerId);

        if (count($sent) >= $maxPerWindow || $sameSubject >= $maxSameSubject) {
            /**
             * Fires when an automatic confirmation is held back to stop a possible mail loop.
             *
             * @param int $customerId
             * @param string $subject
             */
            do_action('fluent_support_pro/auto_reply_suppressed', $customerId, $subject);

            return false;
        }

        $sent[] = ['t' => $now, 's' => $subjectHash];
        set_transient($key, $sent, self::WINDOW);

        return true;
    }
}
