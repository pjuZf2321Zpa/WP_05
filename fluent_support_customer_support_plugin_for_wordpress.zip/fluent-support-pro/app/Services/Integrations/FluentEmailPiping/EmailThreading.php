<?php

namespace FluentSupportPro\App\Services\Integrations\FluentEmailPiping;

use FluentSupport\App\Models\Ticket;
use FluentSupport\Framework\Support\Arr;

/**
 * Threads piped replies to their ticket by a signed reference in the mail headers.
 *
 * Customer emails carry `<fst.{ticketId}.{sig}@{host}>` as In-Reply-To and References.
 * The sending service (SES and others) may replace Message-ID, but leaves these alone, and
 * a reply keeps the parent's References, so the reference comes back through the pipe.
 * The signature stops a sender from naming a ticket by guessing its ID.
 */
class EmailThreading
{
    /**
     * The ticket whose customer email is being built, taken from the subject filter
     * because the header filter is not given the ticket.
     *
     * @var array|null ['ticket' => Ticket, 'hook_type' => string]
     */
    private static $pendingTicket = null;

    public static function register()
    {
        add_filter('fluent_support/ticket_email_subject', [__CLASS__, 'rememberTicket'], 999, 3);
        add_filter('fluent_support/mail_to_customer_header', [__CLASS__, 'addThreadHeaders'], 20, 2);
    }

    public static function rememberTicket($subject, $ticket = null, $hookType = '')
    {
        self::$pendingTicket = $ticket ? ['ticket' => $ticket, 'hook_type' => $hookType] : null;

        return $subject;
    }

    public static function addThreadHeaders($headers, $data = [])
    {
        $ticket = Arr::get((array) $data, 'ticket');

        // Only trust the remembered ticket for the email whose subject it came from.
        if (!$ticket && self::$pendingTicket && self::$pendingTicket['hook_type'] === Arr::get((array) $data, 'hook_type')) {
            $ticket = self::$pendingTicket['ticket'];
        }

        self::$pendingTicket = null;

        if (!$ticket || empty($ticket->id) || !is_array($headers)) {
            return $headers;
        }

        if (!apply_filters('fluent_support_pro/email_threading_headers', true, $ticket, $data)) {
            return $headers;
        }

        $reference = self::referenceFor($ticket->id);

        // The base plugin sends `In-Reply-To: <from address>`, which is not a message id.
        $headers = array_values(array_filter($headers, function ($header) {
            return !is_string($header) || !preg_match('/^\s*(In-Reply-To|References)\s*:/i', $header);
        }));

        // Reply to the customer's own emails, so ours sits under theirs in Gmail and
        // Outlook. Our signed reference goes last in References: a reply keeps the
        // list, so it routes back to this ticket whatever the client does.
        $customerIds = self::customerMessageIds($ticket);

        $headers[] = 'In-Reply-To: ' . ($customerIds ? end($customerIds) : $reference);
        $headers[] = 'References: ' . self::referencesValue($customerIds, $reference);

        return $headers;
    }

    /** Header lines must stay under 998 characters (RFC 5322). */
    const MAX_REFERENCES_LENGTH = 900;

    /**
     * Message-IDs of the emails the customer sent on this ticket, oldest first.
     *
     * @param Ticket $ticket
     * @return string[]
     */
    public static function customerMessageIds($ticket)
    {
        $ids = [];

        if ($ticket->source === 'email') {
            $ids[] = $ticket->message_id;
        }

        $replyIds = \FluentSupport\App\Models\Conversation::where('ticket_id', $ticket->id)
            ->where('source', 'email')
            ->where('conversation_type', 'response')
            ->whereNotNull('message_id')
            ->orderBy('id', 'asc')
            ->pluck('message_id')
            ->toArray();

        $ids = array_merge($ids, $replyIds);
        $ids = array_map([\FluentSupportPro\App\Services\ProHelper::class, 'normalizeMessageId'], $ids);

        return array_values(array_unique(array_filter($ids)));
    }

    /**
     * The first and the most recent ids that fit, then our reference.
     *
     * @param string[] $customerIds
     * @param string $reference
     * @return string
     */
    private static function referencesValue(array $customerIds, $reference)
    {
        $budget = self::MAX_REFERENCES_LENGTH - strlen($reference) - 1;
        $kept = [];

        if ($customerIds) {
            $first = array_shift($customerIds);
            if (strlen($first) <= $budget) {
                $kept[] = $first;
                $budget -= strlen($first) + 1;
            }

            $recent = [];
            foreach (array_reverse($customerIds) as $id) {
                if (strlen($id) + 1 > $budget) {
                    break;
                }
                array_unshift($recent, $id);
                $budget -= strlen($id) + 1;
            }

            $kept = array_merge($kept, $recent);
        }

        $kept[] = $reference;

        return implode(' ', $kept);
    }

    public static function referenceFor($ticketId)
    {
        $host = wp_parse_url(home_url(), PHP_URL_HOST);
        if (!$host || !preg_match('/^[a-z0-9.-]+$/i', $host)) {
            $host = 'fluent-support.local';
        }

        return sprintf('<fst.%d.%s@%s>', (int) $ticketId, self::sign($ticketId), strtolower($host));
    }

    /**
     * The ticket a reply's In-Reply-To / References point to, if any reference verifies.
     *
     * @param string|array|null $inReplyTo
     * @param string|array|null $references
     * @return Ticket|null
     */
    public static function findTicket($inReplyTo, $references)
    {
        $haystack = implode(' ', array_map(function ($value) {
            return is_array($value) ? implode(' ', array_filter($value, 'is_string')) : (string) $value;
        }, [$inReplyTo, $references]));

        if (!$haystack || !preg_match_all('/<fst\.(\d+)\.([a-f0-9]{16})@[^>\s]+>/i', $haystack, $matches, PREG_SET_ORDER)) {
            return null;
        }

        // In-Reply-To first, then References; every message in a thread names the same ticket.
        foreach ($matches as $match) {
            $ticketId = (int) $match[1];

            if ($ticketId && hash_equals(self::sign($ticketId), strtolower($match[2]))) {
                return Ticket::find($ticketId);
            }
        }

        return null;
    }

    private static function sign($ticketId)
    {
        return substr(hash_hmac('sha256', 'fst-thread|' . (int) $ticketId, wp_salt('auth')), 0, 16);
    }
}
