<?php

namespace FluentSupportPro\App\Services\Integrations\FluentEmailPiping;

use FluentSupportPro\App\Services\CoreCompat;
use FluentSupport\App\Models\Attachment;
use FluentSupport\App\Models\Customer;
use FluentSupport\App\Models\MailBox;
use FluentSupport\App\Models\Conversation;
use FluentSupport\App\Models\Ticket;
use FluentSupport\App\Services\Helper;
use FluentSupport\App\Services\Parser\Parsedown;
use FluentSupport\Framework\Support\Arr;
use FluentSupport\App\Services\Includes\UploadService;
use FluentSupportPro\App\Services\ProHelper;

class ByMailHandler
{
    public static function processPayload(array $data, $box, $mimeId)
    {
        // The pipe's in-request retry and its /fetch_logs replay resend the same email.
        if (ProHelper::isMimeProcessed($mimeId)) {
            return [
                'message' => 'skipped',
                'type'    => 'confirmed',
            ];
        }

        // A retry can arrive while the first delivery is still running; add_option() is
        // atomic on the unique option name, so only one request processes the email.
        $claimKey = $mimeId ? '_fsp_mime_claim_' . md5($mimeId) : '';
        if ($claimKey && !add_option($claimKey, time(), '', 'no')) {
            $claimedAt = (int) get_option($claimKey);
            if ($claimedAt && (time() - $claimedAt) < 10 * MINUTE_IN_SECONDS) {
                return [
                    'message' => 'skipped',
                    'type'    => 'confirmed',
                ];
            }
            // A stale claim from a request that died mid-way; take it over.
            update_option($claimKey, time(), 'no');
        }

        try {
            $result = self::processEmailPayload($data, $box);

            if (!is_wp_error($result)) {
                ProHelper::markMimeProcessed($mimeId);
            }
        } finally {
            if ($claimKey) {
                delete_option($claimKey);
            }
        }

        return $result;
    }

    protected static function processEmailPayload(array $data, $box)
    {
        $formattedData = [
            'subject'     => Arr::get($data, 'subject'),
            // Keep entities: decoding turns a quoted x&lt;5 into a tag that kses then strips.
            'content'     => Arr::get($data, 'body_text'),
            'message_id'  => Arr::get($data, 'messageId'),
            // Threading headers, sent by pipe payloads from 2026-10 on.
            'in_reply_to' => Arr::get($data, 'inReplyTo'),
            'references'  => Arr::get($data, 'references'),
            'attachments' => Arr::get($data, 'attachments', []),
            'isMarkDown'  => !!Arr::get($data, 'isMarkDown')
        ];

        $customerArr = Arr::get($data, 'from.value', []);
        if ($customerArr) {
            if (!count($customerArr)) {
                return new \WP_Error('invalid_sender', 'from.value as an array is required');
            }

            // Only the mailbox's own address may file a forward under the original sender;
            // anyone else could name any customer. The pipe applies the same rule upstream.
            if (!empty($data['forwarded']) && is_email(Arr::get($data, 'forwarded.address')) && self::isMailboxAddress(Arr::get($customerArr, '0.address'), $box)) {
                $customerArr = $data['forwarded'];
            } else {
                $customerArr = $customerArr[0];
            }

            $formattedData['sender'] = [
                'name'  => Arr::get($customerArr, 'name'),
                'email' => Arr::get($customerArr, 'address')
            ];
        } else {
            $formattedData['sender'] = [
                'name'  => Arr::get($data, 'from_name'),
                'email' => Arr::get($data, 'from_email')
            ];
        }

        if (empty($formattedData['sender']['email']) || !is_email($formattedData['sender']['email'])) {
            return new \WP_Error('invalid_sender_email', 'From Email address is not valid');
        }

        // Out-of-office replies and delivery failures never open tickets or count as replies.
        $autoMailKind = AutoMailHandler::classify($data, $formattedData['sender']['email']);
        if (in_array($autoMailKind, [AutoMailHandler::AUTO_REPLY, AutoMailHandler::BOUNCE], true)) {
            return AutoMailHandler::handle($autoMailKind, $data, $formattedData['sender']['email'], $box);
        }

        $CcValueArr = Arr::get($data, 'cc.value', []);
        $receiverArr = Arr::get($data, 'to.value', []);

        if (count($receiverArr) > 1) {
            $CcValueArr = array_merge($CcValueArr, $receiverArr);
        }

        $ccEmails = array_unique(array_column($CcValueArr, 'address'));
        $formattedData['carbon_copy'] = array_diff($ccEmails, [$box->email, $box->mapped_email]);

        $formattedData = apply_filters('fluent_support_pro/email_piping_data', $formattedData, $data, $box);

        // Automated mail (alerts, notices, newsletters) is handled normally, but nothing
        // automatic is sent back to it.
        if ($autoMailKind === AutoMailHandler::AUTOMATED) {
            AutoReplyGuard::holdFor($formattedData['sender']['email']);
            try {
                return self::handleEmailData($formattedData, $box);
            } finally {
                AutoReplyGuard::release();
            }
        }

        return self::handleEmailData($formattedData, $box);
    }

    protected static function isMailboxAddress($address, $box)
    {
        return $box && $box->email && is_string($address)
            && strtolower(trim($address)) === strtolower(trim($box->email));
    }

    public static function handleEmailData($data, $mailBox = false, $source = 'email')
    {
        $rawSubject = (string) Arr::get($data, 'subject', 'Subject not defined');
        $data['subject'] = self::getActualSubject($rawSubject);
        $data['is_reply'] = self::looksLikeReply($rawSubject, $data);

        $onBehalf = Arr::get($data, 'sender');
        $fullName = sanitize_text_field(Arr::get($onBehalf, 'name', ''));
        unset($onBehalf['name']);

        $nameArray = explode(' ', $fullName);

        if (count($nameArray) >= 2) {
            $onBehalf['last_name'] = array_pop($nameArray);
            $onBehalf['first_name'] = implode(' ', $nameArray);
        } else if ($fullName) {
            $onBehalf['first_name'] = $fullName;
        }

        $customer = CoreCompat::findOrCreateCustomer($onBehalf);

        if (!$customer || self::isBlockedCustomer($customer)) {

            if(!$customer) {
                return new \WP_Error(
                    'customer_creation_error',
                    __('Customer could not be created.', 'fluent-support-pro')
                );
            }

            return new \WP_Error(
                'customer_inactive',
                __('Customer is inactive, so no ticket can be created.', 'fluent-support-pro')
            );
        }


        // A signed reference from our own email beats any subject guess.
        $existingTicket = self::threadedTicket($customer, $data);

        if (!$existingTicket && !$customer->wasRecentlyCreated) {
            $existingTicket = self::guessTicket($customer, $data, $mailBox, $source);
        }

        $carbonCopy = Arr::get($data, 'carbon_copy', []);

        // The sender may be a CC participant replying to someone else's ticket.
        if (!$existingTicket && $source == 'email' && !empty($carbonCopy) && $data['is_reply']) {
            $existingTicket = self::mayBeCarbonCopyUser($customer, $data['subject'], $mailBox);
        }

        $responseOrTicketData = [
            'title'      => sanitize_text_field($data['subject']),
            'message_id' => \FluentSupportPro\App\Services\ProHelper::sanitizeMessageId($data['message_id']),
            // Never slashed (piping) or already unslashed (webhook). Sanitize only, to keep backslashes.
            // Guarded so an older core can't fatal and drop the email; remove once min core has the helper.
            'content'    => wp_kses_post(method_exists(Helper::class, 'decodeNonMarkupEntities') ? Helper::decodeNonMarkupEntities($data['content']) : $data['content'])
        ];

        if (empty($responseOrTicketData['message_id']) && $messageId = \FluentSupportPro\App\Services\ProHelper::generateMessageID($customer->email)) {
            $responseOrTicketData['message_id'] = $messageId;
        }

        if (!empty($data['isMarkDown'])) {
            // Not safe mode: it would escape the pipe's own <p>/<a> wrapping into visible
            // text. The output kses is the sanitizer, and it drops unsafe link schemes.
            $markdown = self::unwrapPipedMarkdown($data['content']);
            if (method_exists(Helper::class, 'decodeNonMarkupEntities')) {
                $markdown = Helper::decodeNonMarkupEntities($markdown);
            }

            if ($parsedContent = (new Parsedown())->text($markdown)) {
                $responseOrTicketData['content'] = wp_kses_post($parsedContent);
            }
        }

        if ($existingTicket && !empty($data['message_id']) && empty($existingTicket->message_id)) {
            $existingTicket->message_id = ProHelper::sanitizeMessageId($data['message_id']);
            $existingTicket->save();
        }

        if (!$existingTicket) {
            $responseOrTicketData['customer_id'] = $customer->id;
            $responseOrTicketData['source'] = $source;
            $responseOrTicketData['client_priority'] = sanitize_text_field(Arr::get($data, 'priority', 'normal'));
            $responseOrTicketData['priority'] = sanitize_text_field(Arr::get($data, 'priority', 'normal'));

            if (!$mailBox) {
                $mailBox = MailBox::where('is_default', 'yes')->orderBy('id', 'ASC')->first();
            }

            if ($mailBox) {
                $responseOrTicketData['mailbox_id'] = $mailBox->id;
            }

            if (!empty($data['custom_fields'])) {
                // Same as the body: don't unslash again.
                $responseOrTicketData['custom_fields'] = $data['custom_fields'];
            }

            // One open ticket per piped message: a resent email is not a new ticket.
            if ($mailBox && Ticket::where('content_hash', md5($responseOrTicketData['content']))
                    ->where('customer_id', $customer->id)
                    ->where('status', '!=', 'closed')
                    ->where('mailbox_id', $mailBox->id)
                    ->exists()) {
                return false;
            }

            $canCreateTicket = apply_filters('fluent_support/can_customer_create_ticket', true, $customer, $data);

            if (!$canCreateTicket || is_wp_error($canCreateTicket)) {
                return new \WP_Error(
                    'ticket_creation_error',
                    is_wp_error($canCreateTicket)
                        ? $canCreateTicket->get_error_message()
                        : __('Sorry, you cannot create a ticket.', 'fluent-support-pro')
                );
            }

            /**
             * Fires before a ticket is created from an email.
             * @param array $responseOrTicketData
             * @param object $customer
             */
            do_action('fluent_support/before_ticket_create_from_email', $responseOrTicketData, $customer);

            // The base plugin's create path (create_ticket_data, before_ticket_create,
            // custom fields), silently: ticket_created fires once the CC list and the
            // attachments are saved, so the emails carry them.
            $createdTicket = CoreCompat::storeEmailTicket($responseOrTicketData, $customer);

            if (!empty($carbonCopy)) {
                $createdTicket->updateSettingsValue('cc_email', $carbonCopy);
                $createdTicket->updateSettingsValue('all_cc_email', $carbonCopy);
            }

            self::handleAttachments(Arr::get($data, 'attachments', []), $createdTicket, $customer);

            CoreCompat::fireTicketCreated($createdTicket, $customer);

            /**
             * Fires after a ticket is created from an email.
             * @param object $createdTicket
             * @param object $customer
             */
            do_action('fluent_support/after_ticket_create_from_email', $createdTicket, $customer);

            return [
                'type'      => 'new_ticket',
                'ticket_id' => $createdTicket->id,
                'ticket'    => $createdTicket
            ];
        }

        if (!empty($existingTicket->extra_content)) {
            $responseOrTicketData['content'] = $existingTicket->extra_content . $responseOrTicketData['content'];
            unset($existingTicket->extra_content);
        }

        $canCreateResponse = apply_filters('fluent_support/can_customer_create_response', true, $customer, $existingTicket, $data);


        if (!$canCreateResponse || is_wp_error($canCreateResponse)) {
            return new \WP_Error(
                'response_creation_error',
                is_wp_error($canCreateResponse)
                    ? $canCreateResponse->get_error_message()
                    : __('Sorry, you cannot create a response.', 'fluent-support-pro')
            );
        }


        // Reopen through the shared service, as a portal reply does, so resolved_at is
        // cleared and the reopen hooks (activity log, "On Ticket Reopened" workflows) run.
        if ($existingTicket->status == 'closed') {
            (new \FluentSupport\App\Services\Tickets\TicketService())->reopen($existingTicket, $customer);
        }

        // The base plugin's reply path (counters, CC list, reply filters), silently:
        // the hooks fire once the attachments are saved, so the emails carry them.
        $responses = new \FluentSupport\App\Services\Tickets\ResponseService();
        $result = $responses->createResponse([
            'content'           => CoreCompat::replyContent($responseOrTicketData['content']),
            'conversation_type' => 'response',
            'source'            => $source,
            'message_id'        => $responseOrTicketData['message_id'],
            'cc_emails'         => $carbonCopy,
            // An email with only attachments is still a reply.
            'allow_empty_content' => true,
        ], $customer, $existingTicket, true);
        $createdResponse = $result['response'];
        CoreCompat::keepMessageId($createdResponse, $responseOrTicketData['message_id']);

        if (!empty($data['message_id']) && !$existingTicket->message_id) {
            // sanitize_text_field() strips "<id@host>" as a tag.
            $existingTicket->message_id = ProHelper::sanitizeMessageId($data['message_id']);
            $existingTicket->save();
        }

        self::handleAttachments(Arr::get($data, 'attachments', []), $existingTicket, $customer, $createdResponse);

        $responses->fireResponseHooks($createdResponse, $existingTicket, $customer, $result['closed'], $result['agent_added'], $result['previous_agent_id']);

        return [
            'type'        => 'new_response',
            'ticket_id'   => $existingTicket->id,
            'response_id' => $createdResponse->id,
            'response'    => $createdResponse,
            'customer'    => $customer
        ];
    }

    /**
     * Whether this customer is barred from support.
     *
     * Customer::isBlocked() needs Fluent Support 2.4.1 and Pro can be updated first,
     * so fall back to the same rule: only 'active' (or empty) status is allowed.
     * Drop the fallback once 2.4.1 is the minimum.
     *
     * @param \FluentSupport\App\Models\Customer $customer
     * @return bool
     */
    protected static function isBlockedCustomer($customer)
    {
        if (method_exists($customer, 'isBlocked')) {
            return $customer->isBlocked();
        }

        return ($customer->status ?: 'active') !== 'active';
    }

    /**
     * The pipe sends markdown through mailparser's textToHtml: paragraphs become <p>,
     * line breaks <br/>, and every URL inside `[text](url)` an <a> tag. Parsedown reads
     * a <p> line as a raw HTML block and won't parse markdown inside it, so undo all three.
     *
     * @param string $content
     * @return string
     */
    private static function unwrapPipedMarkdown($content)
    {
        $content = preg_replace('/\]\(<a href="([^"<>\s]+)"[^>]*>[^<]*<\/a>\)/i', ']($1)', (string) $content);
        $content = preg_replace('/<\/p>\s*<p>/i', "\n\n", $content);
        $content = preg_replace('/^\s*<p>|<\/p>\s*$/i', '', $content);

        return preg_replace('/<br\s*\/?>/i', "  \n", $content);
    }

    private static function getActualSubject($string)
    {
        // Every leading Re:/Fwd:/FW:/AW: (stacked ones too), as clients add one per round trip.
        $pattern = '/^\s*(?:(?:re|fwd?|aw)\s*:\s*|request received:\s*)+/i';

        return preg_replace($pattern, '', (string) $string, 1);
    }

    /**
     * Whether the email answers an earlier one: it has a reply prefix or threading headers.
     * A fresh email (or a forward) starts a conversation, so it never joins a ticket by subject.
     */
    private static function looksLikeReply($rawSubject, $data)
    {
        if (Arr::get($data, 'in_reply_to') || Arr::get($data, 'references')) {
            return true;
        }

        // Re: plus common translations (AW: German, SV: Nordic, RES: Portuguese).
        return (bool) preg_match('/^\s*(?:(?:fwd?|request received)\s*:\s*)*(?:re|aw|sv|res)\s*:/i', $rawSubject);
    }

    /**
     * Oldest last activity a ticket may have and still take a reply by subject.
     *
     * @return string MySQL datetime
     */
    private static function subjectMatchSince()
    {
        $days = max(1, (int) apply_filters('fluent_support_pro/email_subject_match_days', 30));

        // Ticket timestamps are in site time.
        return date('Y-m-d H:i:s', strtotime(current_time('mysql')) - $days * DAY_IN_SECONDS);
    }

    /**
     * The ticket the email's In-Reply-To / References name, when the sender belongs to it:
     * its customer, or an address on its saved CC list.
     *
     * @return Ticket|false
     */
    protected static function threadedTicket($customer, $data)
    {
        $ticket = EmailThreading::findTicket(Arr::get($data, 'in_reply_to'), Arr::get($data, 'references'));

        if (!$ticket) {
            return false;
        }

        if ((int) $ticket->customer_id === (int) $customer->id) {
            return $ticket;
        }

        $existingCc = array_map('strtolower', (array) $ticket->getSettingsValue('all_cc_email', []));

        if (in_array(strtolower(trim($customer->email)), $existingCc, true)) {
            return $ticket;
        }

        return false;
    }

    /**
     * One of the customer's tickets by the number in an email subject: the
     * public ticket number first, then the serial number, then the internal id.
     *
     * @param \FluentSupport\App\Models\Customer $customer
     * @param string $reference
     * @return Ticket|null
     */
    protected static function ticketByReference($customer, $reference)
    {
        $tickets = Ticket::where('customer_id', $customer->id);

        $ticket = (clone $tickets)->where('ticket_number', $reference)->first();

        if (!$ticket && ctype_digit($reference)) {
            $ticket = (clone $tickets)->where('serial_number', $reference)->first()
                ?: (clone $tickets)->where('id', $reference)->first();
        }

        return $ticket;
    }

    protected static function guessTicket($customer, $data, $mailBox = false, $source = 'email')
    {
        $subject = $data['subject'];

        if (!Ticket::where('customer_id', $customer->id)->first()) {
            return false;
        }


        if (!empty($data['message_id'])) {
            $ticket = Ticket::where('customer_id', $customer->id)
                ->whereIn('message_id', ProHelper::storedMessageIdForms($data['message_id']))
                ->first();
            if ($ticket) {
                return $ticket;
            }
        }

        // Our subjects carry "#<public ticket number>" (ticket_number, which may
        // have a prefix, or the serial number); older emails carry "#<id>".
        preg_match_all('/#([A-Za-z0-9][A-Za-z0-9_-]*)/', $subject, $matches);

        $reference = count($matches[1]) ? array_pop($matches[1]) : '';

        if ($reference !== '' && preg_match('/[0-9]/', $reference)) {
            $existingTicket = self::ticketByReference($customer, $reference);

            if ($existingTicket) {
                return $existingTicket;
            }

            $subject = str_replace('#' . $reference, '', $subject);
        }

        // A new email that shares a subject with an old ticket ("Invoice", "Question") is a
        // new ticket. Only a reply may be matched by subject from here on.
        if ($source === 'email' && empty($data['is_reply'])) {
            return false;
        }

        $subject = trim(sanitize_text_field($subject));

        // A near-empty subject would match every ticket the customer has.
        if (strlen($subject) < 3) {
            return false;
        }

        // Escape LIKE wildcards so a crafted subject cannot broaden the match.
        global $wpdb;
        $subjectLike = $wpdb->esc_like($subject);

        $existingTicket = false;

        $since = self::subjectMatchSince();

        if (apply_filters('fluent_support/ticket_full_match', true)) {
            // The whole title, not a part of it: our emails' subject is the ticket title,
            // so a real reply's subject equals it once the Re: is gone.
            $query = Ticket::where('customer_id', $customer->id)
                ->where('title', 'like', $subjectLike)
                ->where('updated_at', '>=', $since);

            if ($mailBox) {
                $query->where('mailbox_id', $mailBox->id);
            }

            $existingTicket = $query->orderBy('ID', 'DESC')->first();

            if ($existingTicket) {
                return $existingTicket;
            }
        }

        // Off by default: a few shared words put new questions on old tickets.
        if (apply_filters('fluent_support/ticket_partial_match', false)) {
            $subjectParts = array_values(array_filter(explode(' ', $subject)));

            // Two words of a short subject ("my order") match unrelated tickets, so only
            // long subjects get a partial match, on their middle three words.
            $partCounts = count($subjectParts);
            if ($partCounts < 6) {
                return $existingTicket;
            }

            $middleItem = intval($partCounts / 2);
            $subjectPart = $subjectParts[$middleItem - 1] . ' ' . $subjectParts[$middleItem] . ' ' . $subjectParts[$middleItem + 1];

            // A loose match must not reopen a closed ticket.
            $query = Ticket::where('customer_id', $customer->id)
                ->where('title', 'like', '%%' . $wpdb->esc_like($subjectPart) . '%%')
                ->where('status', '!=', 'closed')
                ->where('updated_at', '>=', $since);

            if ($mailBox) {
                $query->where('mailbox_id', $mailBox->id);
            }

            $existingTicket = $query->orderBy('ID', 'DESC')->first();
        }

        return $existingTicket;
    }

    /**
     * Find the ticket an incoming email is a CC reply to. Only the ticket's saved
     * all_cc_email list proves membership. The incoming CC list is sender-controlled.
     *
     * @param Customer      $customer  The sender, resolved from the From address.
     * @param string        $subject   Raw incoming subject line.
     * @param MailBox|false $mailBox   Mailbox the message was piped into, used to scope the search.
     * @return Ticket|false
     */
    private static function mayBeCarbonCopyUser($customer, $subject, $mailBox = false)
    {
        global $wpdb;

        $subject = sanitize_text_field(self::getActualSubject($subject));

        // A near-empty subject would match every ticket. esc_like() below handles wildcards.
        if (strlen($subject) < 3) {
            return false;
        }

        $senderEmail = strtolower(trim($customer->email));

        $query = Ticket::where('title', 'like', $wpdb->esc_like($subject))
            ->where('updated_at', '>=', self::subjectMatchSince());

        if ($mailBox) {
            $query->where('mailbox_id', $mailBox->id);
        }

        // A newer ticket can share the subject, so check several recent matches, not just the newest.
        $candidates = $query->orderBy('ID', 'DESC')->limit(10)->get();

        foreach ($candidates as $ticket) {
            $existingCc = array_map('strtolower', (array) $ticket->getSettingsValue('all_cc_email', []));

            if (in_array($senderEmail, $existingCc, true)) {
                return $ticket;
            }
        }

        return false;
    }

    private static function handleAttachments($attachments, $ticket, $customer, $convo = false)
    {
        if (!$attachments) {
            return false;
        }

        $modelThatNeedsInlineImages = $convo ? $convo : $ticket;
        $inlineImages = false;

        $storageDriver = 'local';
        if (method_exists(Helper::class, 'getUploadDriverKey')) {
            $storageDriver = Helper::getUploadDriverKey();
        }

        $acceptedMimes = Helper::ticketAcceptedFileMiles();

        foreach ($attachments as $attachment) {
            $fileTicketId = null;
            if ($storageDriver == 'local') {
                $fileTicketId = $ticket->id;
            }

            $upload = UploadService::handleEmailAttachments($attachment, $fileTicketId, $acceptedMimes);

            if (!$upload) {
                continue;
            }

            $filePath = isset($upload['file']) ? $upload['file'] : $upload['file_path'];

            $attachmentData = [
                'status'    => 'active',
                'ticket_id' => $ticket->id,
                'person_id' => $customer->id,
                'file_type' => $upload['type'],
                'file_path' => $filePath,
                'full_url'  => sanitize_url($upload['url']),
                'title'     => sanitize_text_field($upload['name']),
                'settings'  => [
                    'local_temp_path' => $filePath
                ],
                'driver'    => 'local'
            ];

            if ($convo) {
                $attachmentData['conversation_id'] = $convo->id;
            }

            if (Arr::get($attachment, 'contentDisposition') === 'inline') {
                $attachmentData['status'] = 'inline';
            }

            $dbAttachment = Attachment::create($attachmentData);

            // Free 2.4.7+ routes this (background upload, failure tracking); older free uses the hook.
            if (class_exists('\FluentSupport\App\Services\Storage\StorageManager')) {
                \FluentSupport\App\Services\Storage\StorageManager::finalize($dbAttachment, $ticket->id);
            } elseif ($storageDriver != 'local') {
                do_action_ref_array('fluent_support/finalize_file_upload_' . $storageDriver, [&$dbAttachment, $ticket->id]);
            }

            if ($dbAttachment->driver == 'local' && $storageDriver != 'local') {
                // The remote upload failed, so keep the file in the ticket's local folder.
                $newFileInfo = UploadService::copyFileTicketFolder($dbAttachment->file_path, $ticket->id);
                if ($newFileInfo && !empty($newFileInfo['file_path'])) {
                    $dbAttachment->file_path = $newFileInfo['file_path'];
                    $dbAttachment->full_url = $newFileInfo['url'];
                    $dbAttachment->save();
                }
            }


            if ($dbAttachment->status === 'inline') {
                $placeholder = '[image: ' . $attachment['filename'] . ']';
                $pos = strpos($modelThatNeedsInlineImages->content, $placeholder);

                if ($pos !== false) {
                    $safeFilename = sanitize_file_name($attachment['filename']);
                    $inlineImages = true;

                    if ($dbAttachment->driver == 'local') {
                        $referenceUrl = add_query_arg(['fst_file' => $dbAttachment->file_hash], site_url('/index.php'));
                        $imgTag = "<img src='{$referenceUrl}' alt='{$safeFilename}' />";
                    } else {
                        $imgTag = "<img src='{$dbAttachment->secureUrl}' alt='{$safeFilename}' />";
                    }

                    // Replace only the first occurrence so duplicate-filename images each get their own URL.
                    $modelThatNeedsInlineImages->content = substr_replace(
                        $modelThatNeedsInlineImages->content,
                        $imgTag,
                        $pos,
                        strlen($placeholder)
                    );
                } else {
                    // No "[image: filename]" placeholder, common from mobile mail clients.
                    // Show it as a regular attachment so it isn't hidden.
                    $dbAttachment->status = 'active';
                    $dbAttachment->save();
                }
            }
        }

        if ($inlineImages) {
            $modelThatNeedsInlineImages->save();
        }

        return true;
    }

    public static function overWriteUpDir($upload)
    {
        $uploadDir = wp_upload_dir();

        $upload['path'] = $uploadDir['basedir'] . '/' . FLUENT_SUPPORT_UPLOAD_DIR . '/email_attachments';
        $upload['url'] = $uploadDir['baseurl'] . '/' . FLUENT_SUPPORT_UPLOAD_DIR . '/email_attachments';
        $upload['subdir'] = '/email_attachments';
        return $upload;
    }

    public static function isCustomPipeSupported()
    {
        if (defined('FLUENTSUPPORT_ENABLE_CUSTOM_PIPE') && FLUENTSUPPORT_ENABLE_CUSTOM_PIPE) {
            return true;
        }

        return apply_filters('fluent_support/enable_custom_piping', false);
    }
}
