<?php

namespace FluentSupportPro\App\Services\Integrations;

use FluentSupportPro\App\Services\ProHelper;
use FluentSupportPro\App\Services\Integrations\Commerce\CommerceProviders;
use FluentSupportPro\App\Services\Integrations\Commerce\FluentCartProvider;

/**
 * FluentCart product and order custom fields, plus the FluentCart commerce provider.
 */
class FluentCart
{
    public function boot()
    {
        $this->registerCustomFieldTypes();

        $this->setupFieldOptionHandlers();

        $this->setupFieldDisplayHandlers();

        CommerceProviders::add(new FluentCartProvider());
    }

    private function registerCustomFieldTypes()
    {
        add_filter('fluent_support/custom_field_types', function ($fieldTypes) {
            $fieldTypes['fct_products'] = [
                'is_custom'   => true,
                'is_remote'   => true,
                'custom_text' => __('FluentCart products will be shown at the ticket form', 'fluent-support-pro'),
                'type'        => 'fct_products',
                'label'       => __('FluentCart Products', 'fluent-support-pro'),
                'value_type'  => 'number'
            ];

            $fieldTypes['fct_orders'] = [
                'is_custom'   => true,
                'is_remote'   => true,
                'custom_text' => __('FluentCart orders will be shown at the ticket form', 'fluent-support-pro'),
                'type'        => 'fct_orders',
                'label'       => __('FluentCart Orders', 'fluent-support-pro'),
                'value_type'  => 'number'
            ];

            return $fieldTypes;
        });
    }

    private function setupFieldOptionHandlers()
    {
        add_filter('fluent_support/render_custom_field_options_fct_orders', [$this, 'renderOrderOptions'], 10, 2);

        add_filter('fluent_support/render_custom_field_options_fct_products', [$this, 'renderProductOptions'], 10, 2);
    }

    private function setupFieldDisplayHandlers()
    {
        add_filter('fluent_support/custom_field_render_fct_orders', [$this, 'renderOrderValue'], 10, 2);

        add_filter('fluent_support/custom_field_render_fct_products', [$this, 'renderProductValue'], 10, 2);

    }

    /**
     * Turn the field into a select of the customer's orders.
     */
    public function renderOrderOptions($field, $customer)
    {
        $orders = $this->getCustomerOrders($customer);

        if (!$orders || $orders->isEmpty()) {
            return $field;
        }

        $options = [];
        foreach ($orders as $order) {
            $options[] = [
                'id'    => strval($order->id),
                'title' => sprintf(__('Order #%d - %s', 'fluent-support-pro'), $order->id, $order->created_at->format('M d, Y'))
            ];
        }

        $field['type'] = 'select';
        $field['filterable'] = true;
        $field['rendered'] = true;
        $field['options'] = $options;

        return $field;
    }

    /**
     * Turn the field into a select of all published products.
     */
    public function renderProductOptions($field, $customer)
    {
        $products = ProHelper::getFluentCartProducts();

        if (!$products) {
            return false;
        }

        $options = [];
        foreach ($products as $product) {
            $options[] = [
                'id'    => strval($product->ID),
                'title' => $product->post_title
            ];
        }

        $field['type'] = 'select';
        $field['rendered'] = true;
        $field['filterable'] = true;
        $field['options'] = $options;

        return $field;
    }

    /**
     * Link an order id to the FluentCart admin (admin scope) or the customer's order view.
     */
    public function renderOrderValue($value, $scope = 'admin')
    {
        if (!is_numeric($value)) {
            return $value;
        }

        $orderId    = absint($value);
        $orderTitle = sprintf(__('Order #%d', 'fluent-support-pro'), $orderId);
        $order      = null;

        if (class_exists('\FluentCart\App\Models\Order')) {
            try {
                $order = \FluentCart\App\Models\Order::find($orderId);

                if ($order) {
                    $formattedDate = $order->created_at
                        ? $order->created_at->format('M d, Y')
                        : '';

                    $orderTitle = sprintf(
                        __('Order #%d%s', 'fluent-support-pro'),
                        $orderId,
                        $formattedDate ? ' - ' . $formattedDate : ''
                    );
                }
            } catch (\Throwable $e) {
                // Fall back to the plain "Order #id" label.
            }
        }

        if ($scope === 'admin') {
            $adminUrl = admin_url('admin.php?page=fluent-cart#/orders/' . $orderId . '/view');

            return sprintf(
                '<a target="_blank" rel="nofollow" href="%s">%s</a>',
                esc_url($adminUrl),
                esc_html($orderTitle)
            );
        }

        if ($order && method_exists($order, 'getViewUrl')) {
            $customerUrl = $order->getViewUrl('customer');

            return sprintf(
                '<a target="_blank" rel="nofollow" href="%s">%s</a>',
                esc_url($customerUrl),
                esc_html($orderTitle)
            );
        }

        return esc_html($orderTitle);
    }


    /**
     * Link a product id to the FluentCart admin (admin scope) or its frontend page.
     */
    public function renderProductValue($value, $scope = 'admin')
    {
        if (!is_numeric($value)) {
            return $value;
        }

        $productId = absint($value);
        $productTitle = sprintf(__('Product #%d', 'fluent-support-pro'), $productId);
        $product = null;

        if (class_exists('\FluentCart\App\Models\Product')) {
            try {
                $product = \FluentCart\App\Models\Product::find($productId);
                if ($product) {
                    $productTitle = $product->post_title;
                }
            } catch (\Exception $e) {
                // Fallback to WordPress post
                $wpProduct = get_post($productId);
                if ($wpProduct && $wpProduct instanceof \WP_Post) {
                    $product = $wpProduct;
                    $productTitle = $wpProduct->post_title;
                }
            }
        }

        if ($scope == 'admin') {
            $adminUrl = admin_url('admin.php?page=fluent-cart#/products/' . $productId);
            return '<a target="_blank" rel="nofollow" href="' . esc_url($adminUrl) . '">' . esc_html($productTitle) . '</a>';
        }

        if ($product) {
            $customerUrl = get_permalink($productId);
            if ($customerUrl) {
                return '<a target="_blank" rel="nofollow" href="' . esc_url($customerUrl) . '">' . esc_html($productTitle) . '</a>';
            }
        }

        return $productTitle;
    }


    /**
     * Orders by the customer's WP user id, or by email when there is none.
     */
    private function getCustomerOrders($customer)
    {
        if (!class_exists('\FluentCart\App\Models\Order')) {
            return null;
        }

        try {
            if ($customer->user_id) {
                return $this->getOrdersByUserId($customer->user_id);
            }

            return $this->getOrdersByEmail($customer->email);
        } catch (\Exception $e) {
            return null;
        }
    }

    private function getOrdersByUserId($userId)
    {
        return \FluentCart\App\Models\Order::whereHas('customer', function ($query) use ($userId) {
            $query->where('user_id', $userId);
        })
            ->select(['id', 'status', 'created_at', 'total_amount', 'currency'])
            ->orderByDesc('created_at')
            ->get();
    }

    private function getOrdersByEmail($email)
    {
        return \FluentCart\App\Models\Order::whereHas('customer', function ($query) use ($email) {
            $query->where('email', $email);
        })
            ->select(['id', 'status', 'created_at', 'total_amount', 'currency'])
            ->orderByDesc('created_at')
            ->get();
    }

    /**
     * Workflow condition config for a FluentCart custom field.
     */
    public function addToWorkflow($customField, $key)
    {
        $options = [];

        if ($key == 'fct_products') {
            $options = $this->getProductWorkflowOptions();
        } elseif ($key == 'fct_orders') {
            $options = $this->getOrderWorkflowOptions();
        }

        return [
            'title'     => $customField['label'],
            'data_type' => 'single_dropdown',
            'group'     => 'Custom Fields',
            'options'   => $options
        ];
    }

    private function getProductWorkflowOptions()
    {
        $options = [];
        $products = ProHelper::getFluentCartProducts();

        if ($products) {
            foreach ($products as $product) {
                $options[$product->ID] = $product->post_title;
            }
        }

        return $options;
    }

    private function getOrderWorkflowOptions()
    {
        $options = [];

        if (!class_exists('\FluentCart\App\Models\Order')) {
            return $options;
        }

        $orders = \FluentCart\App\Models\Order::orderByDesc('created_at')
            ->get();

        foreach ($orders as $order) {
            $options[$order->id] = sprintf(__('Order #%d - %s', 'fluent-support-pro'), $order->id, $order->created_at->format('M d, Y'));
        }

        return $options;
    }

}
