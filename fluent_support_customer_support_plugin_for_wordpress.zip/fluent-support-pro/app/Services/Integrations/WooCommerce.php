<?php

namespace FluentSupportPro\App\Services\Integrations;

use FluentSupport\App\Services\ProfileInfoService;

class WooCommerce
{
    public function boot()
    {
        add_filter('fluent_support/customer_extra_widgets', array($this, 'getWooCommercePurchaseWidgets'), 120, 3);

        /*
         * Custom Fields Support For products
         */
        add_filter('fluent_support/custom_field_types', function ($fieldTypes) {
            $fieldTypes['woo_products'] = [
                'is_custom'   => true,
                'is_remote'   => true,
                'custom_text' => __('WooCommerce products will be shown at the ticket form', 'fluent-support-pro'),
                'type'        => 'woo_products',
                'label'       => __('WooCommerce Products', 'fluent-support-pro'),
                'value_type'  => 'number'
            ];
            $fieldTypes['woo_orders'] = [
                'is_custom'   => true,
                'is_remote'   => true,
                'custom_text' => __('WooCommerce orders will be shown at the ticket form', 'fluent-support-pro'),
                'type'        => 'woo_orders',
                'label'       => __('WooCommerce Orders', 'fluent-support-pro'),
                'value_type'  => 'number'
            ];
            return $fieldTypes;
        });

        add_filter('fluent_support/render_custom_field_options_woo_orders', function ($field, $customer) {
            // An empty billing_email is skipped by wc_get_orders(), not matched.
            if (empty($customer->email)) {
                return $field;
            }

            $orders = wc_get_orders([
                'billing_email' => $customer->email,
                'limit'         => 1000,
                'offset'        => 0,
                'order'         => 'DESC',
                'paginate'      => false
            ]);

            if (!$orders) {
                return $field;
            }

            $options = [];

            foreach ($orders as $order) {
                $options[] = [
                    'id'    => strval($order->get_id()),
                    'title' => sprintf(__('Order #%d - %s', 'fluent-support-pro'), $order->get_id(), wc_format_datetime($order->get_date_created()))
                ];
            }

            $field['type'] = 'select';
            $field['filterable'] = true;
            $field['rendered'] = true;
            $field['options'] = $options;
            return $field;

        }, 10, 2);

        add_filter('fluent_support/render_custom_field_options_woo_products', function ($field, $customer) {

            $products = $this->getWooProducts();

            if (!$products) {
                return false;
            }

            $options = [];

            foreach ($products as $product) {
                $options[] = [
                    'id'    => strval($product->get_id()),
                    'title' => $product->get_title()
                ];
            }

            $field['type'] = 'select';
            $field['rendered'] = true;
            $field['filterable'] = true;
            $field['options'] = $options;
            return $field;

        }, 10, 2);

        add_filter('fluent_support/custom_field_render_woo_orders', function ($value, $scope) {
            if (!is_numeric($value)) {
                return $value;
            }

            $orderId = absint($value);

            if ($scope == 'admin') {
                return '<a target="_blank" rel="nofollow" href="' . esc_url(get_edit_post_link($orderId)) . '">' . sprintf(esc_html__('Order #%d', 'fluent-support-pro'), $orderId) . '</a>';
            }

            $order = wc_get_order($orderId);

            if (!$order) {
                return 'Order #' . $orderId;
            }

            $url = $order->get_view_order_url();

            return '<a target="_blank" rel="nofollow" href="' . esc_url($url) . '">' . sprintf(esc_html__('Order #%d', 'fluent-support-pro'), $orderId) . '</a>';

        }, 10, 2);

        add_filter('fluent_support/custom_field_render_woo_products', function ($value) {
            if (!is_numeric($value)) {
                return $value;
            }

            $productId = absint($value);
            $product = get_post($productId);
            if (!$product) {
                return $value;
            }

            return '<a target="_blank" rel="nofollow" href="' . esc_url(get_permalink($product)) . '">' . esc_html($product->post_title) . '</a>';

        }, 10, 1);

    }

    public function getWooCommercePurchaseWidgets($widgets, $customer, $context = null)
    {
        if ($context && !ProfileInfoService::wantsWidget($context, 'woo_purchases')) {
            return $widgets;
        }

        // wc_get_orders() skips an empty billing_email rather than matching it, which
        // would list the store's newest orders as this customer's.
        if (empty($customer->email)) {
            return $widgets;
        }

        /** @var \stdClass $customer_orders Paginated result: orders, total, max_num_pages. */
        $customer_orders = wc_get_orders([
            'billing_email' => $customer->email,
            'type'          => 'shop_order',
            'limit'         => 10,
            'orderby'       => 'date',
            'order'         => 'DESC',
            'paginate'      => true
        ]);

        if (empty($customer_orders->orders)) {
            return $widgets;
        }

        // Line items are read from the order itself, not the wc_order_product_lookup
        // analytics table, which WooCommerce fills asynchronously (and only every
        // 12 hours when scheduled analytics import is enabled).
        if ($context && ProfileInfoService::isMcpWidgetRequest($context)) {
            $mcpOrders = [];
            foreach ($customer_orders->orders as $order) {
                $mcpOrders[] = $this->getMcpOrder($order, $this->getOrderProducts($order));
            }

            $widgets['woo_purchases'] = [
                'title' => __('WooCommerce Purchases', 'fluent-support-pro'),
                'mcp'   => [
                    'total_orders' => (int) $customer_orders->total,
                    'orders'       => $mcpOrders,
                ],
            ];

            return $widgets;
        }

        $widgets['woo_purchases'] = array_merge(
            ['title' => __('WooCommerce Purchases', 'fluent-support-pro')],
            $this->getWidgetData($customer->email, $customer_orders->orders)
        );

        return $widgets;
    }

    /**
     * Stats and recent purchases for the agent sidebar (see ProfileInfoService).
     *
     * @param string $email The customer's billing email.
     * @param \WC_Order[] $orders The customer's latest orders, newest first.
     * @return array
     */
    private function getWidgetData($email, $orders)
    {
        // Lifetime value is summed from the latest 100 paid orders.
        $paid = wc_get_orders([
            'billing_email' => $email,
            'type'          => 'shop_order',
            'status'        => wc_get_is_paid_statuses(),
            'limit'         => 100,
            'orderby'       => 'date',
            'order'         => 'DESC',
            'paginate'      => true
        ]);

        $lifetimeValue = 0;
        foreach ($paid->orders as $order) {
            $lifetimeValue += (float) $order->get_total() - (float) $order->get_total_refunded();
        }

        $stats = [
            [
                'label' => __('Lifetime Value', 'fluent-support-pro'),
                'value' => self::formatAmount($lifetimeValue, $orders[0]->get_currency()),
            ],
            [
                'label' => __('Total Purchases:', 'fluent-support-pro'),
                'value' => (string) (int) $paid->total,
            ],
        ];

        if ($paid->orders) {
            $firstPaid = end($paid->orders);
            if ($paid->total > count($paid->orders)) {
                $oldest = wc_get_orders([
                    'billing_email' => $email,
                    'type'          => 'shop_order',
                    'status'        => wc_get_is_paid_statuses(),
                    'limit'         => 1,
                    'orderby'       => 'date',
                    'order'         => 'ASC',
                ]);
                $firstPaid = $oldest ? $oldest[0] : $firstPaid;
            }

            $stats[] = [
                'label' => __('Since', 'fluent-support-pro'),
                'value' => self::dateIso($firstPaid->get_date_created()),
                'type'  => 'date',
            ];
            $stats[] = [
                'label' => __('Last Purchase', 'fluent-support-pro'),
                'value' => self::dateIso($paid->orders[0]->get_date_created()),
                'type'  => 'date',
            ];
        }

        $items = [];
        foreach ($orders as $order) {
            $status = $order->get_status();

            if (in_array($status, ['cancelled', 'failed', 'refunded'], true)) {
                $badge = ['text' => wc_get_order_status_name($status), 'type' => 'danger'];
            } elseif ($status === 'completed') {
                $badge = null;
            } else {
                $badge = ['text' => wc_get_order_status_name($status), 'type' => $status === 'processing' ? 'info' : 'warning'];
            }

            // Works for both HPOS and post-based order storage.
            $url = $order->get_edit_order_url();

            foreach ($order->get_items() as $item) {
                $quantity = (int) $item->get_quantity();
                list($name, $variation) = self::getProductAndVariation($item);

                $items[] = [
                    'title'              => $quantity > 1
                        /* translators: 1: product name, 2: quantity */
                        ? sprintf(__('%1$s × %2$d', 'fluent-support-pro'), $name, $quantity)
                        : $name,
                    'meta'               => self::formatAmount($order->get_line_total($item, true), $order->get_currency()),
                    'subtitle'           => $variation,
                    'subtitle_meta'      => self::dateIso($order->get_date_created()),
                    'subtitle_meta_type' => 'date',
                    'reference'          => ['text' => '#' . $order->get_order_number(), 'url' => $url],
                    'url'                => $url,
                    'badge'              => $badge,
                ];
            }
        }

        return [
            'stats_style' => 'summary',
            'stats'    => $stats,
            'sections' => [
                [
                    'label' => __('Recent Purchases', 'fluent-support-pro'),
                    'items' => array_slice($items, 0, 10),
                ],
            ],
        ];
    }

    /**
     * Product name and variation text ("Blue, Large") for a line; the variation is '' for simple products.
     *
     * @param \WC_Order_Item_Product $item
     * @return array [name, variation]
     */
    private static function getProductAndVariation($item)
    {
        $product = $item->get_product();
        if (!$product || !$product->is_type('variation')) {
            return [$item->get_name(), ''];
        }

        // "Any" attributes are empty on the variation; the chosen value is stored on the line.
        $attributes = [];
        foreach ($product->get_variation_attributes(false) as $attribute => $value) {
            $chosen = $item->get_meta($attribute);
            $attributes[$attribute] = $chosen !== '' ? $chosen : $value;
        }

        // Keep the name from the time of purchase, not the product's current title. A variation's
        // name is its title plus an attribute suffix (" - Large"); drop that suffix from the line's name,
        // since the variation is shown separately. If the attributes changed since, keep the full name.
        $name = $item->get_name();
        $title = $product->get_title();
        $suffix = strpos($product->get_name(), $title) === 0 ? substr($product->get_name(), strlen($title)) : '';
        if ($suffix !== '' && strlen($name) > strlen($suffix) && substr($name, -strlen($suffix)) === $suffix) {
            $name = substr($name, 0, -strlen($suffix));
        }

        return [$name, wc_get_formatted_variation($attributes, true, false)];
    }

    /**
     * An amount with its currency sign, as plain text.
     *
     * @param float|string $amount
     * @param string $currency
     * @return string
     */
    private static function formatAmount($amount, $currency)
    {
        $text = html_entity_decode(wp_strip_all_tags(wc_price($amount, ['currency' => $currency])), ENT_QUOTES, 'UTF-8');

        // Some symbols carry a trailing &nbsp; (BDT is "&#2547;&nbsp;"), which pushes the price off the right edge.
        return preg_replace('/^[\s\x{00A0}]+|[\s\x{00A0}]+$/u', '', $text);
    }

    /**
     * @param \WC_DateTime|null $date
     * @return string|null ISO 8601 UTC.
     */
    private static function dateIso($date)
    {
        return $date ? gmdate('c', $date->getTimestamp()) : null;
    }

    /**
     * Plain order data for MCP agents.
     *
     * @param \WC_Order $order
     * @param array $products From getOrderProducts().
     * @return array
     */
    private function getMcpOrder($order, $products)
    {
        $created = $order->get_date_created();

        return [
            'id'             => $order->get_id(),
            'number'         => (string) $order->get_order_number(),
            'status'         => $order->get_status(),
            'total'          => (float) $order->get_total(),
            'currency'       => $order->get_currency(),
            'date'           => $created ? $created->date('c') : null,
            'payment_method' => $order->get_payment_method_title(),
            // Works for both HPOS and post-based order storage.
            'url'            => $order->get_edit_order_url(),
            'items'          => array_map(function ($product) {
                return [
                    'product_id' => (int) $product->ID,
                    'name'       => $product->post_title,
                    'qty'        => (int) $product->product_qty,
                    'total'      => (float) $product->product_gross_revenue,
                ];
            }, $products),
        ];
    }

    /**
     * @param $order
     * @return array
     */
    private function getOrderProducts($order)
    {
        $products = [];

        foreach ($order->get_items() as $item) {
            $products[] = (object) [
                'ID'                    => $item->get_product_id(),
                'post_title'            => $item->get_name(),
                'product_qty'           => $item->get_quantity(),
                'product_gross_revenue' => $order->get_line_total($item, true),
                'order_id'              => $order->get_id(),
            ];
        }

        return $products;
    }

    private function getWooProducts()
    {
        if(!function_exists('wc_get_products')){
            return [];
        }

        return wc_get_products([
            'limit'   => 1000,
            'orderby' => 'name',
            'order'   => 'ASC',
            'return'  => 'objects',
            'status'  => 'publish'
        ]);
    }

    public function addToWorkflow($customField, $key)
    {
        $options = [];
        if($key=='woo_products'){
            $wooProducts = $this->getWooProducts();

            foreach ($wooProducts as $product) {
                $options[$product->get_id()] = $product->get_name();
            }
        } else{
            if(!function_exists('wc_get_orders')){
                return [];
            }

            $wooOrders = wc_get_orders(['order' => 'DESC']);

            foreach ($wooOrders as $order) {
                $options[$order->get_id()] = sprintf(__('Order #%d - %s', 'fluent-support-pro'), $order->get_id(), wc_format_datetime($order->get_date_created()));
            }
        }

        return [
            'title'     => $customField['label'],
            'data_type' => 'single_dropdown',
            'group'     => 'Custom Fields',
            'options'   => $options
        ];
    }
}
