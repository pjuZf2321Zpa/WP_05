<?php

namespace FluentSupportPro\App\Services\Integrations\Commerce;

/**
 * Registry of commerce providers, keyed by provider key. Filled from each integration's
 * boot(), e.g. FluentCart::boot() and Edd::boot().
 */
class CommerceProviders
{
    /** @var array<string,CommerceProviderBase> */
    private static $providers = [];

    /**
     * @param  CommerceProviderBase $provider
     * @return void
     */
    public static function add(CommerceProviderBase $provider)
    {
        self::$providers[$provider->getKey()] = $provider;
    }

    /**
     * @param  string $key
     * @return CommerceProviderBase|null
     */
    public static function get($key)
    {
        return isset(self::$providers[$key]) ? self::$providers[$key] : null;
    }

    /** @return array<string,CommerceProviderBase> */
    public static function all()
    {
        return self::$providers;
    }

    /**
     * Clear the registry. Intended for test isolation.
     *
     * @return void
     */
    public static function reset()
    {
        self::$providers = [];
    }
}
