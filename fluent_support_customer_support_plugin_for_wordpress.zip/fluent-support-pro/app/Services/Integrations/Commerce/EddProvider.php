<?php

namespace FluentSupportPro\App\Services\Integrations\Commerce;

use FluentSupport\App\Services\Helper;
use FluentSupportPro\App\Services\ProHelper;

/**
 * Easy Digital Downloads commerce provider.
 *
 * - catalog: the `download` post type
 * - purchases: cart items of completed payments
 * - licenses: the EDD Software Licensing `edd_licenses` table, read per user
 */
class EddProvider extends CommerceProviderBase
{
    /** @return string */
    public function getKey()
    {
        return 'edd';
    }

    /** @return string */
    public function getLabel()
    {
        return __('Easy Digital Downloads', 'fluent-support-pro');
    }

    /** @return bool */
    public function supportsLicensing()
    {
        return defined('EDD_SL_VERSION');
    }

    /** @return bool */
    public function supportsVariations()
    {
        return true; // EDD variable prices act as variations
    }

    /**
     * @param  string $search
     * @param  int    $limit
     * @return array<int,array{id:string,title:string}>
     */
    public function searchProducts($search = '', $limit = 50)
    {
        $data = [];
        foreach (ProHelper::getEddProducts($limit, $search) as $post) {
            $data[] = ['id' => (string) $post->ID, 'title' => $post->post_title];
        }

        return $data;
    }

    /**
     * @param  string $search
     * @param  int    $limit
     * @return array<int,array{id:string,title:string}>
     */
    public function searchVariations($search = '', $limit = 50)
    {
        return $this->variationOptionsFor($search, $limit);
    }

    /**
     * Variation options from downloads whose title matches $search. Scans at most $limit
     * downloads to bound the per-download price lookups on large catalogs.
     *
     * @return array<int,array{id:string,title:string}>
     */
    private function variationOptionsFor($search, $limit)
    {
        $options = [];
        try {
            foreach (ProHelper::getEddProducts($limit, $search) as $post) {
                if (!edd_has_variable_prices($post->ID)) {
                    continue;
                }
                // price_id is only unique per download, hence "download:price_id".
                foreach ((array) edd_get_variable_prices($post->ID) as $priceId => $price) {
                    $name = isset($price['name']) ? $price['name'] : ('#' . $priceId);
                    $options[] = [
                        'id'    => $post->ID . ':' . $priceId,
                        'title' => $post->post_title . ' - ' . $name,
                    ];
                }
                if ($limit > 0 && count($options) >= $limit) {
                    break;
                }
            }
        } catch (\Throwable $e) {
            // Return whatever resolved so far.
        }

        return $options;
    }

    /**
     * @param  string[] $ids  composite "download:price_id" ids
     * @return array<int,array{id:string,title:string}>
     */
    public function variationsByIds(array $ids)
    {
        $options = [];
        try {
            foreach ($ids as $id) {
                $parts = explode(':', (string) $id);
                if (count($parts) !== 2) {
                    continue;
                }
                $downloadId = (int) $parts[0];
                $priceId    = $parts[1];

                $post = $downloadId ? get_post($downloadId) : null;
                if (!$post) {
                    continue;
                }

                $prices = (array) edd_get_variable_prices($downloadId);
                $name   = isset($prices[$priceId]['name']) ? $prices[$priceId]['name'] : ('#' . $priceId);
                $options[] = [
                    'id'    => $downloadId . ':' . $priceId,
                    'title' => $post->post_title . ' - ' . $name,
                ];
            }
        } catch (\Throwable $e) {
            // Return whatever resolved so far.
        }

        return $options;
    }

    /**
     * @param  object $customer  FluentSupport customer
     * @return array{product_ids:string[],variation_ids:string[]}|null
     */
    public function purchasedItems($customer)
    {
        if (!$customer || empty($customer->user_id)) {
            return null;
        }

        try {
            $payments = \edd_get_payments([
                'user'   => $customer->user_id,
                'status' => 'complete',
                'number' => -1,
                'output' => 'payments',
            ]);

            $productIds = [];
            $variationIds = [];
            foreach ((array) $payments as $payment) {
                foreach ((array) \edd_get_payment_meta_cart_details($payment->ID) as $item) {
                    if (!isset($item['id'])) {
                        continue;
                    }
                    $downloadId = $item['id'];
                    $productIds[] = (string) $downloadId;

                    // Only variable-priced items carry a price id.
                    $priceId = \edd_get_cart_item_price_id($item);
                    if ($priceId !== false && $priceId !== null && $priceId !== '') {
                        $variationIds[] = $downloadId . ':' . $priceId;
                    }
                }
            }

            return [
                'product_ids'   => array_values(array_unique($productIds)),
                'variation_ids' => array_values(array_unique($variationIds)),
            ];
        } catch (\Throwable $e) {
            return null;
        }
    }

    /**
     * @param  object $customer  FluentSupport customer
     * @return array{active_product_ids:int[]}
     */
    public function licenseStatus($customer)
    {
        $empty = ['active_product_ids' => []];

        if (!defined('EDD_SL_VERSION') || !$customer || empty($customer->user_id)) {
            return $empty;
        }

        try {
            $rows = Helper::FluentSupport('db')->table('edd_licenses')
                ->where('user_id', $customer->user_id)
                ->get();

            $verdicts = [];
            foreach ($rows as $row) {
                $downloadId = (int) $row->download_id;
                if (!$downloadId) {
                    continue;
                }

                // An empty expiration is a lifetime license.
                $isExpired = ($row->status === 'expired')
                    || (!empty($row->expiration) && (int) $row->expiration < time());

                // Disabled and inactive licenses are skipped.
                if ($row->status === 'active' && !$isExpired) {
                    $verdicts[] = ['product_id' => $downloadId, 'expired' => false];
                } elseif ($isExpired) {
                    $verdicts[] = ['product_id' => $downloadId, 'expired' => true];
                }
            }

            return LicenseStatus::fromVerdicts($verdicts);
        } catch (\Throwable $e) {
            return $empty;
        }
    }
}
