<?php

namespace FluentSupportPro\App\Services\Integrations\Commerce;

/**
 * Resolves which products a customer holds an active FluentCart Pro license for. Expiry comes
 * from License::isExpired(), which honours the grace period.
 */
class FluentCartLicenseResolver
{
    /**
     * @param  object $customer  FluentSupport Customer (needs ->user_id)
     * @return array{active_product_ids:int[]}
     */
    public static function statusFor($customer)
    {
        if (!$customer || empty($customer->user_id)) {
            return LicenseStatus::fromVerdicts([]);
        }

        return self::decide(self::fetchLicenseVerdicts($customer));
    }

    /**
     * Reduce license verdicts to active product ids. Kept separate from the DB
     * lookup so unit tests can call it directly.
     *
     * @param  array<int,array{product_id:int,expired:bool}> $licenses
     * @return array{active_product_ids:int[]}
     */
    public static function decide(array $licenses)
    {
        return LicenseStatus::fromVerdicts($licenses);
    }

    /**
     * @param  object $customer  FluentSupport Customer (needs ->user_id)
     * @return array<int,array{product_id:int,expired:bool}>
     */
    protected static function fetchLicenseVerdicts($customer)
    {
        // Licensing lives in fluent-cart-pro.
        if (
            !class_exists('\FluentCartPro\App\Modules\Licensing\Models\License') ||
            !class_exists('\FluentCart\App\Models\Customer')
        ) {
            return [];
        }

        try {
            // fct_licenses.customer_id is the FluentCart Customer id, not the WP user id.
            $fcCustomer = \FluentCart\App\Models\Customer::where('user_id', $customer->user_id)->first();
            if (!$fcCustomer) {
                return [];
            }

            $licenses = \FluentCartPro\App\Modules\Licensing\Models\License::query()
                ->where('customer_id', $fcCustomer->id)
                ->get();

            $verdicts = [];
            foreach ($licenses as $license) {
                $verdicts[] = [
                    'product_id' => (int) $license->product_id,
                    'expired'    => (bool) $license->isExpired(),
                ];
            }

            return $verdicts;
        } catch (\Throwable $e) {
            return []; // A lookup error reads as no active license.
        }
    }
}
