<?php

namespace FluentSupportPro\App\Services\Integrations\Commerce;

/**
 * Shared, pure decision core for license state — reduces per-license verdicts to the products a
 * customer has an active (non-expired) license for. No platform/WordPress dependency; unit-tested.
 * Consumed by the workflow "Has Active License" condition.
 */
class LicenseStatus
{
    /**
     * @param  array<int,array{product_id:int,expired:bool}> $verdicts
     * @return array{active_product_ids:int[]}
     */
    public static function fromVerdicts(array $verdicts)
    {
        $active = [];
        foreach ($verdicts as $verdict) {
            $pid = (int) ($verdict['product_id'] ?? 0);
            if ($pid && empty($verdict['expired'])) {
                $active[$pid] = true;
            }
        }

        return ['active_product_ids' => array_keys($active)];
    }
}
