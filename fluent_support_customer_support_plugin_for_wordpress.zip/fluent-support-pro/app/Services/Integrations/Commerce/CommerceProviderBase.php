<?php

namespace FluentSupportPro\App\Services\Integrations\Commerce;

/**
 * Catalog, purchase and license lookups for one commerce platform, used by the commerce
 * workflow conditions. Implementations register with CommerceProviders.
 */
abstract class CommerceProviderBase
{
    /**
     * Stable key such as 'fluent_cart' or 'edd'. Also used as the workflow condition prefix.
     *
     * @return string
     */
    abstract public function getKey();

    /**
     * Human-readable platform label.
     *
     * @return string
     */
    abstract public function getLabel();

    /**
     * Whether a license source is installed. If not, the "Has Active License" condition is hidden.
     *
     * @return bool
     */
    abstract public function supportsLicensing();

    /**
     * Whether the platform has product variations/packages.
     *
     * @return bool
     */
    public function supportsVariations()
    {
        return false;
    }

    /**
     * Product options for the workflow builder's remote search. A numeric term looks up that id.
     *
     * @param  string $search
     * @param  int    $limit
     * @return array<int,array{id:string,title:string}>
     */
    abstract public function searchProducts($search = '', $limit = 50);

    /**
     * Variation (package) options for the workflow builder's remote search.
     *
     * @param  string $search
     * @param  int    $limit
     * @return array<int,array{id:string,title:string}>
     */
    public function searchVariations($search = '', $limit = 50)
    {
        return [];
    }

    /**
     * Resolve saved product ids to {id,title} to preload labels when editing a workflow.
     * One searchProducts() call per id, which is fine for the small selected sets.
     *
     * @param  string[] $ids
     * @return array<int,array{id:string,title:string}>
     */
    public function productsByIds(array $ids)
    {
        $out = [];
        foreach ($ids as $id) {
            foreach ($this->searchProducts((string) $id, 1) as $option) {
                if ((string) $option['id'] === (string) $id) {
                    $out[] = $option;
                    break;
                }
            }
        }

        return $out;
    }

    /**
     * Resolve saved variation ids to {id,title}. Ids can be composite (EDD uses
     * "download:price_id"), so each platform handles this itself.
     *
     * @param  string[] $ids
     * @return array<int,array{id:string,title:string}>
     */
    public function variationsByIds(array $ids)
    {
        return [];
    }

    /**
     * Purchased product and variation ids. Null means the lookup was unavailable, which callers
     * keep distinct from "bought nothing".
     *
     * @param  object $customer  FluentSupport customer
     * @return array{product_ids:string[],variation_ids:string[]}|null
     */
    abstract public function purchasedItems($customer);

    /**
     * Products the customer holds an active (non-expired) license for.
     *
     * @param  object $customer  FluentSupport customer
     * @return array{active_product_ids:int[]}
     */
    abstract public function licenseStatus($customer);
}
