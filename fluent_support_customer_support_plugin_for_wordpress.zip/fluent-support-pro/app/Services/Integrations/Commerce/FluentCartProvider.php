<?php

namespace FluentSupportPro\App\Services\Integrations\Commerce;

use FluentSupportPro\App\Services\ProHelper;

/**
 * FluentCart commerce provider.
 */
class FluentCartProvider extends CommerceProviderBase
{
    /** @return string */
    public function getKey()
    {
        return 'fluent_cart';
    }

    /** @return string */
    public function getLabel()
    {
        return __('FluentCart', 'fluent-support-pro');
    }

    /** @return bool */
    public function supportsLicensing()
    {
        return defined('FLUENTCART_PRO_PLUGIN_VERSION');
    }

    /** @return bool */
    public function supportsVariations()
    {
        return true;
    }

    /**
     * @param  string $search
     * @param  int    $limit
     * @return array<int,array{id:string,title:string}>
     */
    public function searchProducts($search = '', $limit = 50)
    {
        $data = [];
        foreach (ProHelper::getFluentCartProducts($limit, $search) as $product) {
            $data[] = ['id' => (string) $product->ID, 'title' => $product->post_title];
        }

        return $data;
    }

    /**
     * @param  string $search
     * @param  int    $limit
     * @return array<int,array{id:string,title:string}>
     */
    public function searchVariations($search = '', $limit = 50)
    {
        return $this->mapVariations($this->variationQuery($search, $limit));
    }

    /**
     * @param  string[] $ids
     * @return array<int,array{id:string,title:string}>
     */
    public function variationsByIds(array $ids)
    {
        if (!$ids) {
            return [];
        }

        try {
            $rows = \FluentCart\App\Models\ProductVariation::with('product')
                ->whereIn('id', array_map('intval', $ids))
                ->get();

            return $this->mapVariations($rows);
        } catch (\Throwable $e) {
            return [];
        }
    }

    /**
     * Variation rows, or an empty array on failure. Packages of one product share a post_id,
     * so options use the variation id, which is what purchasedItems() reports.
     *
     * @return iterable
     */
    private function variationQuery($search, $limit)
    {
        try {
            $query = \FluentCart\App\Models\ProductVariation::with('product')
                ->orderBy('post_id', 'ASC')
                ->orderBy('serial_index', 'ASC');

            $search = trim((string) $search);
            if ($search !== '') {
                // Labels read "Product - Package", so match the package or the product title.
                // $limit products are enough, since each has at least one variation.
                $productIds = [];
                foreach (ProHelper::getFluentCartProducts($limit, $search) as $product) {
                    $productIds[] = (int) $product->ID;
                }
                $query->where(function ($q) use ($search, $productIds) {
                    $q->whereLike('variation_title', $search);
                    if (!empty($productIds)) {
                        $q->orWhereIn('post_id', $productIds);
                    }
                });
            }
            if ($limit > 0) {
                $query->limit($limit);
            }

            return $query->get();
        } catch (\Throwable $e) {
            return [];
        }
    }

    /**
     * @param  iterable $variations
     * @return array<int,array{id:string,title:string}>
     */
    private function mapVariations($variations)
    {
        $options = [];
        foreach ($variations as $variation) {
            $productTitle = ($variation->product && $variation->product->post_title)
                ? $variation->product->post_title
                : '#' . $variation->post_id;
            $options[] = [
                'id'    => (string) $variation->id,
                'title' => $productTitle . ' - ' . $variation->variation_title,
            ];
        }

        return $options;
    }

    /**
     * @param  object $customer  FluentSupport customer
     * @return array{product_ids:string[],variation_ids:string[]}|null
     */
    public function purchasedItems($customer)
    {
        if (!$customer || empty($customer->user_id)) {
            return null;
        }

        try {
            $fcCustomer = \FluentCart\App\Models\Customer::where('user_id', $customer->user_id)->first();
            if (!$fcCustomer) {
                return null;
            }

            $items = \FluentCart\App\Models\OrderItem::whereHas('order', function ($q) use ($fcCustomer) {
                $q->where('customer_id', $fcCustomer->id)
                  ->whereIn('status', ['completed', 'processing']);
            })->get(['post_id', 'object_id']);

            // object_id is the purchased variation. It is empty on non-variation line items.
            return [
                'product_ids'   => $this->toStringIds($items->pluck('post_id')),
                'variation_ids' => $this->toStringIds($items->pluck('object_id')->filter()),
            ];
        } catch (\Throwable $e) {
            return null;
        }
    }

    /**
     * Unique ids as strings, because the selected ids they are matched against are strings.
     *
     * @param  object $ids  a WPFluent collection of ids
     * @return string[]
     */
    private function toStringIds($ids)
    {
        return $ids->unique()->map(function ($id) {
            return strval($id);
        })->values()->toArray();
    }

    /**
     * @param  object $customer  FluentSupport customer
     * @return array{active_product_ids:int[]}
     */
    public function licenseStatus($customer)
    {
        return FluentCartLicenseResolver::statusFor($customer);
    }
}
