<?php

namespace FluentSupportPro\App\Services;

use FluentSupport\App\Models\Agent;
use FluentSupport\App\Models\Customer;
use FluentSupport\App\Models\MailBox;
use FluentSupport\App\Models\Meta;
use FluentSupport\App\Models\Product;
use FluentSupport\App\Services\Helper;
use FluentSupport\Framework\Support\Arr;
use FluentSupport\Framework\Database\Orm\Collection;
use FluentSupportPro\App\Models\TimeTrack;
use FluentSupportPro\App\Services\Integrations\FluentEmailPiping\ByMailHandler;

class ProHelper
{
    public static function hasDocIntegration()
    {
        $config = self::getTicketFormConfig();
        return $config['enable_docs'] == 'yes' && !empty($config['docs_post_types']);
    }

    /**
     * Ticket form settings merged over defaults, cached per request.
     * @return mixed
     */
    public static function getTicketFormConfig()
    {
        static $settings;
        if ($settings) {
            return $settings;
        }

        $settings = Helper::getOption('_ticket_form_settings', []);

        $defaults = [
            'enable_docs' => 'no',
            'docs_post_types' => [],
            'docs_post_categories' => [],
            'post_limits' => 5,
            'disable_rich_text' => 'no',
            'disabled_fields' => [],
            'submitter_type' => 'logged_in_users',
            'allowed_user_roles' => [],
            'field_labels' => [
                'subject' => __('Subject', 'fluent-support-pro'),
                'ticket_details' => __('Ticket Details', 'fluent-support-pro'),
                'details_help' => __('Please provide details about your problem', 'fluent-support-pro'),
                'product_services' => __('Related Product/Service', 'fluent-support-pro'),
                'priority' => __('Priority', 'fluent-support-pro'),
                'btn_text' => __('Create Ticket', 'fluent-support-pro'),
                'submit_heading' => __('Submit a Support Ticket', 'fluent-support-pro'),
                'create_ticket_cta' => __('Create Ticket', 'fluent-support-pro')
            ]
        ];

        $settings = wp_parse_args($settings, $defaults);
        return $settings;
    }

    public static function getProducts()
    {
        $products = Product::select(['id', 'title'])
            ->orderBy('title', 'ASC')
            ->get();

        if ($products->isEmpty()) {
            return [];
        }

        return $products->map(function ($product) {
            return [
                'id' => $product->id,
                'title' => $product->title,
            ];
        })->toArray();
    }

    /**
     * Published FluentCart products, shared by workflow conditions, custom fields and
     * product mapping. Returns a Collection, or an empty array without FluentCart.
     *
     * @param int    $limit  Row cap, 0 for none.
     * @param string $search Title search, or a product id when numeric.
     */
    public static function getFluentCartProducts($limit = 0, $search = '')
    {
        if (!class_exists('\FluentCart\App\Models\Product')) {
            return [];
        }

        try {
            $query = \FluentCart\App\Models\Product::published();

            $search = trim((string) $search);
            if ($search !== '') {
                // A numeric term preloads a saved mapping by id.
                if (ctype_digit($search)) {
                    $query->where('ID', (int) $search);
                } else {
                    $query->whereLike('post_title', $search);
                }
            }

            $query->orderBy('post_title', 'ASC');

            if ($limit > 0) {
                $query->limit($limit);
            }

            return $query->get();
        } catch (\Exception $e) {
            return [];
        }
    }

    /**
     * Published EDD downloads, shared by the Edd integration and EddProvider.
     *
     * @param  int    $limit   0 = no limit
     * @param  string $search  numeric = match a download by id; otherwise a title search
     * @return \WP_Post[]
     */
    public static function getEddProducts($limit = 0, $search = '')
    {
        if (!class_exists('\Easy_Digital_Downloads')) {
            return [];
        }

        $args = [
            'post_type'      => 'download',
            'post_status'    => 'publish',
            'posts_per_page' => $limit > 0 ? $limit : -1,
            'orderby'        => 'title',
            'order'          => 'ASC',
        ];

        $search = trim((string) $search);
        if ($search !== '') {
            // A numeric term preloads a saved mapping by id.
            if (ctype_digit($search)) {
                $args['post__in'] = [(int) $search];
            } else {
                $args['s'] = $search;
            }
        }

        try {
            return get_posts($args);
        } catch (\Exception $e) {
            return [];
        }
    }

    public static function getAdvancedFilterOptions()
    {
        $groups = [
            'tickets' => [
                'label' => __('Tickets', 'fluent-support-pro'),
                'value' => 'tickets',
                'children' => [
                    [
                        'label' => __('Title', 'fluent-support-pro'),
                        'value' => 'title',
                    ],
                    [
                        'label' => __('Content', 'fluent-support-pro'),
                        'value' => 'content',
                    ],
                    [
                        'label' => __('Conversation Content', 'fluent-support-pro'),
                        'value' => 'conversation_content',
                    ],
                    [
                        'label' => __('Status', 'fluent-support-pro'),
                        'value' => 'status',
                        'type' => 'selections',
                        'component' => 'options_selector',
                        'option_key' => 'ticket_statuses',
                        'is_multiple' => true,
                        'is_singular_value' => true
                    ],
                    [
                        'label' => __('Client Priority', 'fluent-support-pro'),
                        'value' => 'client_priority',
                        'type' => 'selections',
                        'component' => 'options_selector',
                        'option_key' => 'client_priorities',
                        'is_multiple' => false,
                        'is_singular_value' => true
                    ],
                    [
                        'label' => __('Admin Priority', 'fluent-support-pro'),
                        'value' => 'priority',
                        'type' => 'selections',
                        'component' => 'options_selector',
                        'option_key' => 'admin_priorities',
                        'is_multiple' => true,
                        'is_singular_value' => true
                    ],
                    [
                        'label' => __('Tags', 'fluent-support-pro'),
                        'value' => 'tags',
                        'type' => 'selections',
                        'component' => 'options_selector',
                        'option_key' => 'ticket_tags',
                        'is_multiple' => true,
                    ],
                    [
                        'label' => __('Products', 'fluent-support-pro'),
                        'value' => 'product',
                        'type' => 'selections',
                        'component' => 'options_selector',
                        'option_key' => 'support_products',
                        'is_multiple' => true,
                        'is_singular_value' => true
                    ],
                    [
                        'label' => __('Waiting For Reply', 'fluent-support-pro'),
                        'value' => 'waiting_for_reply',
                        'type' => 'selections',
                        'option_key' => 'waiting_for_reply',
                        'is_singular_value' => true,
                        'options' => [
                            'yes' => __('Yes', 'fluent-support-pro'),
                            'no' => __('No', 'fluent-support-pro')
                        ]
                    ],
                    [
                        'label' => __('Assigned Agent', 'fluent-support-pro'),
                        'value' => 'agent_id',
                        'type' => 'selections',
                        'component' => 'options_selector',
                        'option_key' => 'support_agents',
                        'is_singular_value' => true,
                    ],
                    [
                        'label' => __('Ticket Mailbox', 'fluent-support-pro'),
                        'value' => 'mailbox_id',
                        'type' => 'selections',
                        'component' => 'options_selector',
                        'option_key' => 'mailboxes',
                        'is_singular_value' => true,
                        'is_multiple' => true,
                    ],
                    [
                        'label' => __('Ticket Created', 'fluent-support-pro'),
                        'value' => 'created_at',
                        'type' => 'dates'
                    ],
                    [
                        'label' => __('Last Response', 'fluent-support-pro'),
                        'value' => 'updated_at',
                        'type' => 'dates'
                    ],
                    [
                        'label' => __('Customer Waiting From', 'fluent-support-pro'),
                        'value' => 'waiting_since',
                        'type' => 'dates'
                    ],
                    [
                        'label' => __('Last Agent Response', 'fluent-support-pro'),
                        'value' => 'last_agent_response',
                        'type' => 'dates'
                    ],
                    [
                        'label' => __('Last Customer Response', 'fluent-support-pro'),
                        'value' => 'last_customer_response',
                        'type' => 'dates'
                    ],
                ],
            ],
            'customer' => [
                'label' => __('Customer', 'fluent-support-pro'),
                'value' => 'customer',
                'children' => [
                    [
                        'label' => __('First Name', 'fluent-support-pro'),
                        'value' => 'first_name',
                    ],
                    [
                        'label' => __('Last Name', 'fluent-support-pro'),
                        'value' => 'last_name',
                    ],
                    [
                        'label' => __('Email', 'fluent-support-pro'),
                        'value' => 'email',
                    ],
                    [
                        'label' => __('Address Line 1', 'fluent-support-pro'),
                        'value' => 'address_line_1',
                    ],
                    [
                        'label' => __('Address Line 2', 'fluent-support-pro'),
                        'value' => 'address_line_2',
                    ],
                    [
                        'label' => __('City', 'fluent-support-pro'),
                        'value' => 'city',
                    ],
                    [
                        'label' => __('State', 'fluent-support-pro'),
                        'value' => 'state',
                    ],
                    [
                        'label' => __('Postal Code', 'fluent-support-pro'),
                        'value' => 'postal_code',
                    ],
//                    [
//                        'label'             => __('Country', 'fluent-support-pro'),
//                        'value'             => 'country',
//                        'type'              => 'selections',
//                        'component'         => 'options_selector',
//                        'option_key'        => 'countries',
//                        'is_multiple'       => true,
//                        'is_singular_value' => true
//                    ],
                    [
                        'label' => __('Phone', 'fluent-support-pro'),
                        'value' => 'phone',
                    ],
                ],
            ],
            'agent' => [
                'label' => __('Agent', 'fluent-support-pro'),
                'value' => 'agent',
                'children' => [
                    [
                        'label' => __('First Name', 'fluent-support-pro'),
                        'value' => 'first_name',
                    ],
                    [
                        'label' => __('Last Name', 'fluent-support-pro'),
                        'value' => 'last_name',
                    ],
                    [
                        'label' => __('Email', 'fluent-support-pro'),
                        'value' => 'email',
                    ]
                ],
            ]
        ];

        // Needs the matching free version; older free has no source filter.
        if (method_exists(\FluentSupport\App\Models\Ticket::class, 'sourceFilterOptions')) {
            $groups['tickets']['children'][] = [
                'label'             => __('Source', 'fluent-support-pro'),
                'value'             => 'source',
                'type'              => 'selections',
                'is_multiple'       => true,
                'is_singular_value' => true,
                'options'           => \FluentSupport\App\Models\Ticket::sourceFilterOptions()
            ];
        }

        $groups = apply_filters('fluent_support/advanced_filter_options', $groups);

        return array_values($groups);
    }

    public static function sanitizeMessageId($text)
    {
        if (!$text) {
            return $text;
        }
        // Hide the brackets from the sanitizer, then restore them. Before 2.4.1 '>' was
        // swapped for '}' and never restored, so stored ids may end in '}': see
        // normalizeMessageId().
        $messageId = str_replace(['<', '>'], ['[', ']'], $text);
        $messageId = sanitize_textarea_field($messageId);
        return str_replace(['[', ']'], ['<', '>'], $messageId);
    }

    /** Prefix of ids Pro invents for mail that had none; never sent as a reference. */
    const GENERATED_MESSAGE_ID_PREFIX = '<fsgen.';

    /**
     * A stored Message-ID as a header value, or null when it isn't one we can
     * reference: not an email id (Twilio SIDs, Slack timestamps and the like share
     * the column), or one Pro invented. Repairs the pre-2.4.1 '}' ending.
     *
     * @param string|null $messageId
     * @return string|null
     */
    public static function normalizeMessageId($messageId)
    {
        $messageId = trim((string) $messageId);

        if (!preg_match('/^<[^<>\s]+@[^<>\s]+[>}]$/', $messageId)) {
            return null;
        }

        if (stripos($messageId, self::GENERATED_MESSAGE_ID_PREFIX) === 0) {
            return null;
        }

        return substr($messageId, 0, -1) . '>';
    }

    /**
     * Every stored form of an incoming Message-ID: as received, sanitized, and the
     * pre-2.4.1 sanitized form ending in '}'.
     *
     * @param string $messageId
     * @return string[]
     */
    public static function storedMessageIdForms($messageId)
    {
        $sanitized = self::sanitizeMessageId($messageId);
        $forms = [$messageId, $sanitized];

        if (substr($sanitized, -1) === '>') {
            $forms[] = substr($sanitized, 0, -1) . '}';
        }

        return array_values(array_unique(array_filter($forms)));
    }

    public static function generateMessageID($email)
    {
        $emailParts = explode('@', $email);
        if (count($emailParts) != 2) {
            return false;
        }
        $emailDomain = $emailParts[1];
        try {
            return sprintf(
                "<fsgen.%s.%s@%s>",
                base_convert((int) microtime(true), 10, 36),
                base_convert(bin2hex(openssl_random_pseudo_bytes(8)), 16, 36),
                $emailDomain
            );
        } catch (\Exception $exception) {
            return false;
        }
    }


    /**
     * Raw key material, from FLUENT_SUPPORT_ENCRYPTION_KEY, then LOGGED_IN_KEY, then
     * wp_salt(). Placeholder values are skipped.
     *
     * @param string $keyScheme  wp_salt() scheme for the key fallback.
     * @param string $saltScheme wp_salt() scheme for the salt fallback.
     * @return array{key:string,salt:string}|false
     */
    private static function resolveRawKeys($keyScheme = 'secure_auth', $saltScheme = 'auth')
    {
        $placeholder = 'put your unique phrase here';

        if (defined('FLUENT_SUPPORT_ENCRYPTION_KEY')
            && '' !== FLUENT_SUPPORT_ENCRYPTION_KEY
            && FLUENT_SUPPORT_ENCRYPTION_KEY !== $placeholder
        ) {
            $key = FLUENT_SUPPORT_ENCRYPTION_KEY;
        } elseif (defined('LOGGED_IN_KEY') && '' !== LOGGED_IN_KEY && LOGGED_IN_KEY !== $placeholder) {
            $key = LOGGED_IN_KEY;
        } else {
            $key = wp_salt($keyScheme);
        }

        $salt = (defined('LOGGED_IN_SALT') && '' !== LOGGED_IN_SALT && LOGGED_IN_SALT !== $placeholder)
            ? LOGGED_IN_SALT
            : wp_salt($saltScheme);

        if (empty($key) || empty($salt)) {
            return false;
        }

        return compact('key', 'salt');
    }

    /**
     * Derive a 32-byte binary key and AAD string from raw WordPress key material.
     *
     * HMAC gives a fixed-size key, so OpenSSL never zero-pads a short salt. Separate
     * labels keep the key and AAD distinct.
     *
     * @param array{key:string,salt:string} $raw Output of resolveRawKeys().
     * @return array{key:string,aad:string}
     */
    private static function deriveKeys(array $raw)
    {
        return [
            // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions
            'key' => hash_hmac('sha256', 'fluentsupport-enc-key', $raw['key'] . $raw['salt'], true),
            // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions
            'aad' => hash_hmac('sha256', 'fluentsupport-enc-aad', $raw['salt'] . $raw['key'], true),
        ];
    }

    /**
     * Encrypt a plaintext value with AES-256-GCM (authenticated encryption).
     *
     * Output: "v2:" + base64(iv[12] + tag[16] + ciphertext). The prefix separates
     * it from legacy CTR blobs. Returns false, never the plaintext, on failure.
     *
     * @param string $value Plaintext to encrypt.
     * @return string|false
     */
    public static function encryptKey($value)
    {
        if (!$value) {
            return $value;
        }

        if (!extension_loaded('openssl')) {
            return false;
        }

        $raw = self::resolveRawKeys();
        if (false === $raw) {
            return false;
        }
        $keys = self::deriveKeys($raw);

        try {
            $iv = random_bytes(12); // phpcs:ignore WordPress.WP.AlternativeFunctions.rand_rand
        } catch (\Exception $e) {
            return false;
        }

        $tag    = '';
        $cipher = openssl_encrypt($value, 'aes-256-gcm', $keys['key'], OPENSSL_RAW_DATA, $iv, $tag, $keys['aad'], 16);

        if (false === $cipher || '' === $tag) {
            return false;
        }

        return 'v2:' . base64_encode($iv . $tag . $cipher); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
    }

    /**
     * Decrypt a value produced by encryptKey().
     *
     * "v2:" blobs are GCM; anything else is legacy AES-256-CTR. Returns false on failure.
     *
     * @param string $raw_value Encrypted blob from encryptKey().
     * @return string|false
     */
    public static function decryptKey($raw_value)
    {
        if (!$raw_value) {
            return $raw_value;
        }

        if (!extension_loaded('openssl')) {
            return false;
        }

        if (strncmp($raw_value, 'v2:', 3) === 0) {
            return self::decryptGcm(substr($raw_value, 3));
        }

        return self::decryptLegacyCtr($raw_value);
    }

    /**
     * AES-256-GCM decryption. openssl_decrypt() returns false on a tag mismatch.
     *
     * @param string $encoded Base64 payload (without the "v2:" prefix).
     * @return string|false
     */
    private static function decryptGcm($encoded)
    {
        $raw = self::resolveRawKeys();
        if (false === $raw) {
            return false;
        }
        $keys = self::deriveKeys($raw);

        $blob = base64_decode($encoded, true); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode
        if (false === $blob || strlen($blob) <= 28) { // 12-byte IV + 16-byte tag minimum
            return false;
        }

        $iv     = substr($blob, 0, 12);
        $tag    = substr($blob, 12, 16);
        $cipher = substr($blob, 28);

        $decrypted = openssl_decrypt($cipher, 'aes-256-gcm', $keys['key'], OPENSSL_RAW_DATA, $iv, $tag, $keys['aad']);

        return (false !== $decrypted) ? $decrypted : false;
    }

    /**
     * AES-256-CTR decryption for pre-v2 values. Tries both legacy key schemes.
     *
     * @param string $raw_value Raw (non-prefixed) base64 blob.
     * @return string|false
     */
    private static function decryptLegacyCtr($raw_value)
    {
        $blob = base64_decode($raw_value, true); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode
        if (false === $blob) {
            return false;
        }

        $ivlen = openssl_cipher_iv_length('aes-256-ctr');
        if (strlen($blob) <= $ivlen) {
            return false;
        }

        $iv     = substr($blob, 0, $ivlen);
        $cipher = substr($blob, $ivlen);

        foreach ([ [ 'secure_auth', 'auth' ], [ 'logged_in', 'secure_auth' ] ] as [ $ks, $ss ]) {
            $raw = self::resolveRawKeys($ks, $ss);
            if (false === $raw) {
                continue;
            }

            $decrypted = openssl_decrypt($cipher, 'aes-256-ctr', $raw['key'], 0, $iv);
            if ($decrypted && substr($decrypted, -strlen($raw['salt'])) === $raw['salt']) {
                return substr($decrypted, 0, -strlen($raw['salt']));
            }
        }

        return false;
    }

    /**
     * Fixed-window rate limiter backed by WordPress transients.
     *
     * Increments keep the original expiry so the window cannot slide. Transient
     * reads and writes are not atomic, so concurrent requests can slightly exceed
     * the limit. That is fine for webhook throttling.
     *
     * @param string $identifier  A unique string that scopes the limit (e.g. token+IP).
     * @param int    $maxRequests Maximum allowed requests within the time window.
     * @param int    $windowSecs  Fixed window length in seconds.
     * @return bool True = allowed, false = limit exceeded.
     */
    public static function checkRateLimit(string $identifier, int $maxRequests = 60, int $windowSecs = 60): bool
    {
        $key  = 'fsp_rl_' . md5($identifier);
        $data = get_transient($key);

        if ($data === false) {
            set_transient($key, ['count' => 1, 'expires_at' => time() + $windowSecs], $windowSecs);
            return true;
        }

        // Reset on an unexpected stored shape.
        if (!is_array($data) || !isset($data['count'], $data['expires_at'])) {
            delete_transient($key);
            set_transient($key, ['count' => 1, 'expires_at' => time() + $windowSecs], $windowSecs);
            return true;
        }

        if ((int) $data['count'] >= $maxRequests) {
            return false;
        }

        $remaining = max(1, (int) $data['expires_at'] - time());
        set_transient(
            $key,
            ['count' => (int) $data['count'] + 1, 'expires_at' => (int) $data['expires_at']],
            $remaining
        );

        return true;
    }

    /**
     * Whether the pipe's archive key for this email was already handled.
     *
     * @param string $mime
     * @return bool
     */
    public static function isMimeProcessed($mime)
    {
        if (!$mime) {
            return false;
        }

        if (\FluentSupport\App\Models\Meta::where('object_type', '__processed_mime')->where('key', md5($mime))->exists()) {
            return true;
        }

        // Older versions kept every key in one serialized __processed_mimes row. Read it
        // until markMimeProcessed() prunes it, three days after its last write.
        $legacy = \FluentSupport\App\Models\Meta::where('object_type', '__processed_mimes')->first();

        return $legacy && isset(((array) static::safeUnserialize($legacy->value))[$mime]);
    }

    /**
     * Records a handled email, after it was processed, so a delivery that failed
     * can still be replayed. One row per email, so two emails piped at the same
     * time can't overwrite each other's record. Rows older than three days are pruned.
     *
     * @param string $mime
     */
    public static function markMimeProcessed($mime)
    {
        if (!$mime) {
            return;
        }

        if (!static::isMimeProcessed($mime)) {
            \FluentSupport\App\Models\Meta::create([
                'object_type' => '__processed_mime',
                'key'         => md5($mime),
                'value'       => date('Ymd'),
            ]);
        }

        // created_at / updated_at are written in site time.
        $cutoff = date('Y-m-d H:i:s', current_time('timestamp') - 3 * DAY_IN_SECONDS);
        \FluentSupport\App\Models\Meta::where('object_type', '__processed_mime')->where('created_at', '<', $cutoff)->delete();
        \FluentSupport\App\Models\Meta::where('object_type', '__processed_mimes')->where('updated_at', '<', $cutoff)->delete();
    }

    public static function getBoxSecret($mailBox)
    {
        $token = $mailBox->getMeta('_webhook_token');
        if ($token) {
            return $token;
        }

        $lockKey      = 'fsp_box_token_lock_' . (int) $mailBox->id;
        $existingLock = get_option($lockKey);

        if ($existingLock !== false && (time() - (int) $existingLock) > 30) {
            delete_option($lockKey);
        }

        $lockAcquired = add_option($lockKey, (string) time(), '', 'no');

        if (!$lockAcquired) {
            for ($attempt = 0; $attempt < 10; $attempt++) {
                usleep(100000);

                $token = $mailBox->getMeta('_webhook_token');
                if ($token) {
                    return $token;
                }
            }

            return new \WP_Error('webhook_token_locked', __('Webhook token is being generated. Please retry shortly.', 'fluent-support-pro'));
        }

        try {
            $token = $mailBox->getMeta('_webhook_token');
            if (!$token) {
                $token = bin2hex(random_bytes(16));
                $mailBox->saveMeta('_webhook_token', $token);
            }
        } finally {
            delete_option($lockKey);
        }

        return $token;
    }

    public static function validateLicense()
    {
        $licenseData = get_option('__fluentsupport_pro_license');
        if (empty($licenseData['license_key']) || $licenseData['status'] !== 'valid') {
            return new \WP_Error('invalid_license', 'License is missing or not valid.');
        }
        return $licenseData;
    }

    /**
     * Install and activate a plugin from a direct download URL, outside WordPress.org.
     * Currently unused, kept for installing companion plugins later.
     *
     * @param array  $plugin_to_install Plugin metadata. Must include 'repo-slug'.
     * @param int    $plugin_id         Internal plugin ID reference.
     * @param string $downloadUrl       Direct download URL for the plugin zip.
     */
    public static function backgroundInstallerDirect($plugin_to_install, $plugin_id, $downloadUrl)
    {
        if (!empty($plugin_to_install['repo-slug'])) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
            require_once ABSPATH . 'wp-admin/includes/plugin-install.php';
            require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
            require_once ABSPATH . 'wp-admin/includes/plugin.php';

            \WP_Filesystem();

            $skin = new \Automatic_Upgrader_Skin();
            $upgrader = new \WP_Upgrader($skin);
            $installed_plugins = array_reduce(array_keys(\get_plugins()), array(static::class, 'associate_plugin_file'), array());
            $plugin_slug = $plugin_to_install['repo-slug'];
            $plugin_file = isset($plugin_to_install['file']) ? $plugin_to_install['file'] : $plugin_slug . '.php';
            $installed = false;
            $activate = false;

            if (isset($installed_plugins[$plugin_file])) {
                $installed = true;
                $activate = !is_plugin_active($installed_plugins[$plugin_file]);
            }

            if (!$installed) {
                // Swallow upgrader skin output.
                ob_start();

                try {
                    $package = $downloadUrl;
                    $download = $upgrader->download_package($package);

                    if (is_wp_error($download)) {
                        throw new \Exception($download->get_error_message());
                    }

                    $working_dir = $upgrader->unpack_package($download, true);

                    if (is_wp_error($working_dir)) {
                        throw new \Exception($working_dir->get_error_message());
                    }

                    $result = $upgrader->install_package(
                        array(
                            'source'                      => $working_dir,
                            'destination'                 => WP_PLUGIN_DIR,
                            'clear_destination'           => false,
                            'abort_if_destination_exists' => false,
                            'clear_working'               => true,
                            'hook_extra'                  => array(
                                'type'   => 'plugin',
                                'action' => 'install',
                            ),
                        )
                    );

                    if (is_wp_error($result)) {
                        throw new \Exception($result->get_error_message());
                    }

                    $activate = true;

                } catch (\Exception $e) {
                }

                ob_end_clean();
            }

            wp_clean_plugins_cache();

            if ($activate) {
                try {
                    $result = activate_plugin($installed ? $installed_plugins[$plugin_file] : $plugin_slug . '/' . $plugin_file);

                    if (is_wp_error($result)) {
                        throw new \Exception($result->get_error_message());
                    }
                    wp_redirect(admin_url('admin.php?page='.$plugin_slug.''));
                } catch (\Exception $e) {
                }
            }
        }
    }

    private static function associate_plugin_file($plugins, $key)
    {
        $path = explode('/', $key);
        $filename = end($path);
        $plugins[$filename] = $key;
        return $plugins;
    }

    /**
     * Unserialize without allowing objects.
     *
     * @param string $data The serialized data.
     * @return mixed The unserialized data or the original data if not serialized.
     */
    public static function safeUnserialize($data)
    {
        if (is_serialized($data)) {
            return @unserialize(trim($data), ['allowed_classes' => false]);
        }

        return $data;
    }
}
