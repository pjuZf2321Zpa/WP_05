<?php

namespace FluentSupportPro\App\Services;

use FluentSupport\App\Models\Conversation;
use FluentSupport\App\Models\Customer;
use FluentSupport\App\Models\Ticket;
use FluentSupport\App\Services\Tickets\ResponseService;
use FluentSupport\App\Services\Tickets\TicketService;

/**
 * Email piping on a Fluent Support core older than 2.5.0, for sites that update
 * Pro first. Each method uses the core's 2.5.0 API when it is there and the
 * older one when it is not; the admin notice asks for the core update meanwhile.
 * Other Pro features need the 2.5.0 core.
 *
 * Delete this class once 2.5.0 has been the minimum core for a release or two.
 */
class CoreCompat
{
    /**
     * The core before 2.5.0 (TicketQuery came with it).
     */
    public static function isOldCore()
    {
        return !class_exists('\FluentSupport\App\Services\Tickets\TicketQuery');
    }

    public static function findOrCreateCustomer(array $data)
    {
        if (class_exists('\FluentSupport\App\Modules\Customers\CustomerService')) {
            return \FluentSupport\App\Modules\Customers\CustomerService::findOrCreate($data);
        }

        return Customer::maybeCreateCustomer($data);
    }

    /**
     * Stores a piped ticket without its created hooks; fireTicketCreated() fires
     * them once the CC list and the attachments are saved.
     */
    public static function storeEmailTicket(array $data, $customer)
    {
        $tickets = new TicketService();
        if (method_exists($tickets, 'storeCustomerTicket')) {
            return $tickets->storeCustomerTicket($data, $customer, false, true);
        }

        $customFields = $data['custom_fields'] ?? [];
        unset($data['custom_fields']);

        $data = apply_filters('fluent_support/create_ticket_data', $data, $customer);
        do_action('fluent_support/before_ticket_create', $data, $customer);

        $ticket = Ticket::create($data);
        if ($ticket && $customFields) {
            $ticket->syncCustomFields($customFields);
        }

        return $ticket;
    }

    public static function fireTicketCreated($ticket, $customer)
    {
        $tickets = new TicketService();
        if (method_exists($tickets, 'fireCreatedHooks')) {
            $tickets->fireCreatedHooks($ticket, $customer);
            return;
        }

        do_action('fluent_support/ticket_created', $ticket, $customer);
    }

    /**
     * The older core refuses a reply whose text is empty() (an emailed reply may
     * carry only attachments, or be just "0").
     */
    public static function replyContent($content)
    {
        return (empty($content) && self::isOldCore()) ? '<p>' . $content . '</p>' : $content;
    }

    /**
     * The older core stores the reply's Message-ID through sanitize_text_field(),
     * which strips "<id@host>" as a tag; threading needs it.
     */
    public static function keepMessageId($response, $messageId)
    {
        if ($response && $messageId && $response->message_id !== $messageId && self::isOldCore()) {
            $response->message_id = $messageId;
            $response->save();
        }
    }

    /**
     * An activity line in the ticket thread (an auto-reply or bounce note).
     */
    public static function addActivity($ticket, $personId, $content, array $extra = [])
    {
        if (method_exists(ResponseService::class, 'addActivity')) {
            return ResponseService::addActivity($ticket, $personId, $content, $extra);
        }

        return Conversation::create(array_merge([
            'ticket_id'         => $ticket->id,
            'person_id'         => $personId,
            'conversation_type' => 'internal_info',
            'content'           => $content,
        ], $extra));
    }
}
