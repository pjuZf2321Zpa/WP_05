<?php

namespace FluentSupportPro\App\Services;

use FluentSupport\App\Models\Attachment;
use FluentSupport\App\Models\Conversation;
use FluentSupport\App\Models\Customer;
use FluentSupport\App\Models\Meta;
use FluentSupport\App\Models\Ticket;
use FluentSupport\App\Modules\PermissionManager;
use FluentSupport\App\Services\Helper;
use FluentSupport\App\Services\Tickets\ResponseService;
use FluentSupport\App\Services\Tickets\TicketService;
use FluentSupport\Framework\Support\Arr;
use FluentSupportPro\App\Models\TimeTrack;
use FluentSupportPro\App\Modules\ScheduledReplies\ScheduledReplyService;

class ProTicketService extends TicketService
{
    const MAX_MERGE_TICKETS_PER_REQUEST = 20;

    /** [$ticket, $mergedTicket, $deletedData] awaiting ticket_deleted and ticket_merge, fired only after the batch commits. */
    private $pendingMergeHooks = [];

    public function addNoteOnMerge($ticket, $mergedTicket)
    {
        $message = sprintf(__('Ticket #%s has been merged with this ticket at %s', 'fluent-support-pro'),  $mergedTicket->id, current_time('mysql'));
        ResponseService::addActivity($ticket, Helper::getCurrentAgent(), $message, ['conversation_type' => 'ticket_merge_activity']);

        return $ticket;
    }

    public function mergeCustomerTickets($ticketIDsToMerge, $currentTicketId)
    {
        global $wpdb;

        $sortedTicketIds = array_values(array_unique(Arr::sortRecursive($ticketIDsToMerge)));

        if (in_array((int) $currentTicketId, array_map('intval', $sortedTicketIds), true)) {
            throw new \Exception('The target ticket must not also appear in the list of tickets being merged.');
        }

        if (count($sortedTicketIds) > self::MAX_MERGE_TICKETS_PER_REQUEST) {
            throw new \Exception(sprintf('You can merge a maximum of %d tickets at a time.', self::MAX_MERGE_TICKETS_PER_REQUEST));
        }

        $completedTickets = [];
        $this->pendingMergeHooks = [];

        if ($wpdb->query('START TRANSACTION') === false) {
            throw new \RuntimeException('Could not start database transaction: ' . $wpdb->last_error);
        }

        try {
            foreach ($sortedTicketIds as $ticketId) {
                $completedTickets[] = $this->mergeTicket($ticketId, $currentTicketId);
            }

            $wpdb->query('COMMIT');
        } catch (\Exception $e) {
            $wpdb->query('ROLLBACK');
            $this->pendingMergeHooks = [];
            throw $e;
        }

        $agent = Helper::getCurrentAgent();
        foreach ($this->pendingMergeHooks as list($ticket, $mergedTicket, $deletedData)) {
            $this->fireDeletedHooks($agent, $deletedData);
            do_action('fluent_support/ticket_merge', $ticket, $mergedTicket);
        }
        $this->pendingMergeHooks = [];

        if(count($sortedTicketIds) === count($completedTickets)){
            return [
                'message' => __('Tickets have been merged', 'fluent-support-pro')
            ];
        }
    }

    public function mergeTicket($ticketId, $currentTicketId)
    {
        if ((int) $ticketId === (int) $currentTicketId) {
            throw new \Exception('Cannot merge a ticket into itself.');
        }

        $parentTicket = Ticket::findOrFail($currentTicketId);
        $ticket       = Ticket::findOrFail($ticketId);

        if (!PermissionManager::canAccessTicket($parentTicket) || !PermissionManager::canAccessTicket($ticket)) {
            throw new \Exception(__('Sorry, you do not have permission to access one of these tickets.', 'fluent-support-pro'));
        }

        // The merged ticket's opening message joins the thread as a customer reply.
        $conversation = Conversation::create(
            [
                'ticket_id'         => $currentTicketId,
                'conversation_type' => 'response',
                'content'           => $ticket->content,
                'source'            => $ticket->source,
                'person_id'         => $parentTicket->customer_id
            ]
        );
        $conversation->created_at = $ticket->created_at;
        $conversation->save();

        // Its scheduled reply was written for its own customer, so it must not go out on the target ticket
        (new ScheduledReplyService())->convertForMerge($ticketId);

        Conversation::where('ticket_id', $ticketId)->update(['ticket_id' => $currentTicketId]);

        // Update ticket-level attachments (conversation_id is NULL) to point to the new conversation
        Attachment::where('ticket_id', $ticketId)
            ->whereNull('conversation_id')
            ->update([
                'ticket_id'       => $currentTicketId,
                'conversation_id' => $conversation->id
            ]);

        // Update conversation-level attachments: only change ticket_id, keep their original conversation_id
        Attachment::where('ticket_id', $ticketId)
            ->whereNotNull('conversation_id')
            ->update([
                'ticket_id' => $currentTicketId
            ]);

        // Logged time follows the conversations. Left behind, it points at a
        // deleted ticket and drops out of the timesheets. Moved even when time
        // tracking is off now, so the minutes are still there if it is turned
        // back on; checked by table, since old installs may not have it yet.
        if ($this->hasTimeTrackTable()) {
            TimeTrack::where('ticket_id', $ticketId)->update(['ticket_id' => $currentTicketId]);
        }

        $this->syncCarbonCopyUser($parentTicket, $ticketId);
        $this->addNoteOnMerge($parentTicket, $ticket);
        $this->countMergedReplies($parentTicket, $ticket);
        $this->pendingMergeHooks[] = [$parentTicket, $ticket, $this->deleteTicket($ticket, null, true)];

        return $ticketId;
    }

    /**
     * The target ticket counts the replies it now holds, and its last customer and
     * agent reply times are the later of the two tickets'.
     */
    private function countMergedReplies($parentTicket, $mergedTicket)
    {
        $parentTicket->response_count = Conversation::where('ticket_id', $parentTicket->id)->where('conversation_type', 'response')->count();
        foreach (['last_customer_response', 'last_agent_response'] as $column) {
            if ($mergedTicket->{$column} && (!$parentTicket->{$column} || strtotime($mergedTicket->{$column}) > strtotime($parentTicket->{$column}))) {
                $parentTicket->{$column} = $mergedTicket->{$column};
            }
        }
        $parentTicket->save();
    }

    private function hasTimeTrackTable()
    {
        global $wpdb;
        $table = $wpdb->prefix . 'fs_time_tracks';

        return $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($table))) === $table;
    }

    private function syncCarbonCopyUser($toTicket, $fromTicketId){
        $ticket = Ticket::findOrFail($fromTicketId);
        //TODO: Currently we are only considering email based ticket
        if(!$ticket || 'email' != $ticket->source){
            return;
        }

        $ticketCarbonCopy = Meta::where('object_type', 'customer_cc_info')->where('object_id', $fromTicketId)->first();
        //If there is any carbon copy user then sync it with the current ticket
        if($ticketCarbonCopy){
            $ticketFollowerData = ProHelper::safeUnserialize($ticketCarbonCopy->value);
            $toTicket->syncCarbonCopyCustomer($ticketFollowerData, $toTicket->id);
        }
    }

    /**
     * @deprecated Use the base plugin's TicketService::syncWatchers().
     */
    public function syncTicketWatchers( $watchers, $ticketId )
    {
        $this->syncWatchers(Ticket::findOrFail($ticketId), (array) $watchers, Helper::getCurrentAgent());

        return [
            'message' => __('Watchers have been updated', 'fluent-support-pro')
        ];
    }

    public function splitToNewTicket( $actualTicketId, $data )
    {
        global $wpdb;

        $conversationId = (int) Arr::get($data, 'conversation_id', 0);
        unset($data['conversation_id']);

        $this->checkPermission('fst_split_ticket', __('You do not have permission to split tickets', 'fluent-support-pro'));

        // An unsent scheduled reply isn't part of the thread yet
        $conversation = Conversation::where('id', $conversationId)
            ->where('ticket_id', $actualTicketId)
            ->where('conversation_type', '!=', ScheduledReplyService::TYPE)
            ->firstOrFail();

        if(empty($conversation)){
            throw new \Exception(__('Conversation not found', 'fluent-support-pro'));
        }

        do_action('fluent_support/before_ticket_split', $actualTicketId, $conversationId, $data);

        if ($wpdb->query('START TRANSACTION') === false) {
            throw new \RuntimeException('Could not start database transaction: ' . $wpdb->last_error);
        }

        try {
            $newTicket = $this->handleSplitTicket($conversationId, $data);

            $agent = Helper::getCurrentAgent();

            $this->createInternalInfoForSplit($newTicket->id, $actualTicketId, $conversationId, $agent->id);

            $this->syncCarbonCopyUser($newTicket, $actualTicketId);

            $wpdb->query('COMMIT');
        } catch (\Exception $e) {
            $wpdb->query('ROLLBACK');
            throw $e;
        }

        // Only now, so no listener sees a ticket the rollback would remove.
        $this->fireCreatedHooks($newTicket, $newTicket->customer);

        do_action('fluent_support/after_ticket_split', $actualTicketId, $newTicket);

        return [
            'message'       => __('Ticket has been split to new ticket', 'fluent-support-pro'),
            'new_ticket_id' => $newTicket->id
        ];
    }

    private function createInternalInfoForSplit ( $newTicketId, $oldTicketId, $conversationId, $agentId )
    {
        $type = ['conversation_type' => 'ticket_split_activity'];
        ResponseService::addActivity($newTicketId, $agentId, sprintf(
            /* translators: %1$s: new ticket ID, %2$s: original ticket ID, %3$s: date and time */
            __('Ticket #%1$s has been split from #%2$s at %3$s', 'fluent-support-pro'), $newTicketId, $oldTicketId, current_time('mysql')), $type);
        ResponseService::addActivity($oldTicketId, $agentId, sprintf(
            /* translators: %1$s: conversation ID, %2$s: new ticket ID, %3$s: date and time */
            __('Conversation #%1$s has been split as a new ticket #%2$s at %3$s', 'fluent-support-pro'), $conversationId, $newTicketId, current_time('mysql')), $type);
    }

    private function handleSplitTicket($conversationId, $data)
    {
        $customer = Customer::findOrFail($data['customer_id']);
        $newTicket = $this->storeTicket($data, $customer, true);

        Conversation::where('id', $conversationId)->delete();
        Attachment::where('conversation_id', $conversationId)
            ->update([
                'ticket_id'       => $newTicket->id,
                'conversation_id' => NULL
            ]);

        return $newTicket;
    }

    private function checkPermission ( $permission, $message )
    {
        if ( !PermissionManager::currentUserCan($permission) ) {
            throw new \Exception( $message );
        }
    }
}
