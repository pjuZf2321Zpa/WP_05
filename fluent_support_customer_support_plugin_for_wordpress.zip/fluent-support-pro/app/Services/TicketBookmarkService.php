<?php
namespace FluentSupportPro\App\Services;

use FluentSupport\App\Models\TagPivot;
use FluentSupport\App\Models\Ticket;
use FluentSupport\App\Services\Helper;
use FluentSupport\App\Services\Tickets\TicketService;

/**
 * @deprecated Watchers are written by the base plugin's TicketService
 * (addWatchers(), removeWatchers(), syncWatchers()); these delegate to it.
 */
class TicketBookmarkService
{
    /**
     * Watchers on a ticket (TagPivot rows with source_type 'ticket_watcher').
     */
    public function getExistingBookmarks($ticketId)
    {
        return TagPivot::where('source_type', 'ticket_watcher')
            ->where('source_id', $ticketId)
            ->get(['tag_id']);
    }

    public function addBookmarks($agentIds, $ticketId)
    {
        if ($ticket = Ticket::find($ticketId)) {
            (new TicketService())->addWatchers($ticket, (array) $agentIds, Helper::getCurrentAgent());
        }
    }

    public function removeBookmarks($agentIds, $ticketId)
    {
        if ($ticket = Ticket::find($ticketId)) {
            (new TicketService())->removeWatchers($ticket, (array) $agentIds, Helper::getCurrentAgent());
        }
    }
}
