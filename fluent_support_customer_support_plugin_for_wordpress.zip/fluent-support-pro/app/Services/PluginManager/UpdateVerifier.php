<?php

namespace FluentSupportPro\App\Services\PluginManager;

/**
 * Verifies an update package against a signed release manifest before WordPress
 * unzips it.
 *
 * The manifest is signed with an offline Ed25519 key, so a compromised licensing
 * API or download host cannot ship code. The checks:
 *
 *   signature  a package we never built
 *   slug       a genuine package for another product
 *   version    an older signed release with a known hole
 *   sha256     downloaded bytes that differ from the signed ones
 *
 * The manifest is checked before the download starts.
 */
class UpdateVerifier
{
    /**
     * Release signing keys. Hardcoded because a key read from an option, API
     * response or filter can be replaced by whoever controls that source.
     *
     * With no valid key the download filter steps aside and updates run unsigned.
     *
     * Rotation: ship the new key next to the old one, switch signing once it is
     * adopted, and drop the old key a release later.
     *
     * @var array<string, string> key id => Ed25519 public key, 64 lowercase hex chars
     */
    const TRUSTED_KEYS = [
        'wpmn-pub-key' => '0b0c3b880d064696f2636d8c72d8e4094303fc6b7907b24ea25a1745f23463c0',
    ];

    /** @var string plugin basename, e.g. fluent-support-pro/fluent-support-pro.php */
    private $basename;

    /** @var string slug as it appears in the signed manifest */
    private $slug;

    /** @var string currently installed version */
    private $version;

    /** @var callable|null returns a fresh, uncached update object from the licensing API */
    private $freshFetch;

    /** @var callable|null drops this plugin's cached version info */
    private $flushCache;

    /** @var bool one uncached retry per request, no more */
    private $refetched = false;

    public function __construct($basename, $slug, $version, $freshFetch = null, $flushCache = null)
    {
        $this->basename = $basename;
        $this->slug = $slug;
        $this->version = $version;
        $this->freshFetch = $freshFetch;
        $this->flushCache = $flushCache;
    }

    /**
     * Is there a usable release key compiled in?
     *
     * @return bool
     */
    public static function hasTrustedKeys()
    {
        return (bool) self::trustedKeys();
    }

    /**
     * Can this server check an Ed25519 signature at all?
     *
     * WordPress only loads its sodium_compat polyfill when sodium_crypto_box() is
     * missing, so a host with the extension but this function in disable_functions
     * has neither. Failing open there is safe: it depends on PHP config, not on
     * anything reachable from the network.
     *
     * @return bool
     */
    public static function isSupported()
    {
        return function_exists('sodium_crypto_sign_verify_detached');
    }

    /**
     * Hook the download gate. Not admin-only, because cron and WP-CLI run updates too.
     *
     * @return void
     */
    public function register()
    {
        add_filter('upgrader_pre_download', [$this, 'verifyPackage'], 10, 4);
    }

    /**
     * Verify the manifest, download the package ourselves and hand WordPress the
     * verified file. A WP_Error aborts the update before extraction.
     *
     * @param bool|string|\WP_Error $reply
     * @param string $package The package URL WordPress is about to download.
     * @param \WP_Upgrader|null $upgrader
     * @param array $hookExtra
     * @return bool|string|\WP_Error Path to the verified file, or an error.
     */
    public function verifyPackage($reply, $package, $upgrader = null, $hookExtra = [])
    {
        if (false !== $reply) {
            return $reply; // Another filter already resolved the download.
        }

        if (empty($hookExtra['plugin']) || $hookExtra['plugin'] !== $this->basename) {
            return $reply; // Not this plugin.
        }

        // A local path is a manually uploaded zip. Remote URLs, http included, are verified.
        if (!is_string($package) || !preg_match('#^https?://#i', $package)) {
            return $reply;
        }

        // Without a key or the Ed25519 primitive nothing can be verified. Refusing
        // would block every future update, security fixes included, so step aside.
        // Checked here rather than at registration, which runs on every request.
        if (!self::hasTrustedKeys() || !self::isSupported()) {
            return $reply;
        }

        $manifest = $this->verifyManifest($this->updateEntry());

        // The stored entry may predate signed responses or come from another
        // updater, so ask the API once before refusing.
        if (is_wp_error($manifest) && $this->canRefetch()) {
            $manifest = $this->verifyManifest($this->fetchFresh());
        }

        if (is_wp_error($manifest)) {
            return $manifest;
        }

        require_once ABSPATH . 'wp-admin/includes/file.php';

        // download_package() normally emits this, but we are taking over the download.
        if (is_object($upgrader) && isset($upgrader->skin) && is_object($upgrader->skin)) {
            $upgrader->skin->feedback('downloading_package', $package);
        }

        $file = download_url($package, 300);

        if (is_wp_error($file)) {
            return $file;
        }

        $actual = hash_file('sha256', $file);

        if (is_string($actual) && hash_equals($manifest['sha256'], $actual)) {
            return $file;
        }

        // The download always serves the latest release, so a cached manifest can
        // predate it. Re-check the same file against a fresh manifest.
        if (is_string($actual) && $this->canRefetch()) {
            $current = $this->verifyManifest($this->fetchFresh());

            if (!is_wp_error($current) && hash_equals($current['sha256'], $actual)) {
                // Drop the stale cache so the plugins screen stops advertising the old version.
                if (is_callable($this->flushCache)) {
                    call_user_func($this->flushCache);
                }

                return $file;
            }
        }

        @unlink($file);

        return $this->reject('hash_mismatch', __('The downloaded update does not match its signature, so it was not installed. Please try again, and contact support if this keeps happening.', 'fluent-support-pro'));
    }

    /**
     * Check the signed manifest attached to the update object.
     *
     * @param object|null $update
     * @return array|\WP_Error The decoded manifest, or the reason it was refused.
     */
    private function verifyManifest($update)
    {
        $bytes = $this->proofBytes($update);

        if (is_wp_error($bytes)) {
            return $bytes;
        }

        $manifest = json_decode($bytes['manifest'], true);

        if (!is_array($manifest) || empty($manifest['key_id']) || !is_string($manifest['key_id'])) {
            return $this->reject('manifest_format', __('The update manifest is malformed, so the update was not installed.', 'fluent-support-pro'));
        }

        // Verify the raw bytes. Re-encoding the JSON would change them and break the signature.
        if (!$this->verifySignature($bytes['manifest'], $bytes['signature'], $manifest['key_id'])) {
            return $this->reject('bad_signature', __('This update is not signed by WPManageNinja, so it was not installed. Please contact support before installing it by hand.', 'fluent-support-pro'));
        }

        if (!isset($manifest['slug']) || $manifest['slug'] !== $this->slug) {
            return $this->reject('slug_mismatch', __('This update package is for a different plugin, so it was not installed.', 'fluent-support-pro'));
        }

        if (empty($manifest['version']) || !is_string($manifest['version'])) {
            return $this->reject('manifest_format', __('The update manifest has no version, so the update was not installed.', 'fluent-support-pro'));
        }

        // Stops a compromised API advertising a high version and serving an older
        // signed release that still passes the downgrade check below. Newer than
        // advertised is normal: a cached entry may lag behind the latest release.
        if (!empty($update->new_version) && version_compare($manifest['version'], $update->new_version, '<')) {
            return $this->reject('version_mismatch', __('The offered update is older than the version advertised, so it was not installed.', 'fluent-support-pro'));
        }

        // Equal versions stay installable so reinstall and repair keep working.
        if ($this->version && version_compare($manifest['version'], $this->version, '<')) {
            return $this->reject('downgrade', sprintf(
                /* translators: 1: offered version number, 2: installed version number */
                __('The server offered version %1$s, which is older than the installed %2$s, so it was not installed.', 'fluent-support-pro'),
                $manifest['version'],
                $this->version
            ));
        }

        if (empty($manifest['sha256']) || !is_string($manifest['sha256']) || !preg_match('/^[a-f0-9]{64}$/i', $manifest['sha256'])) {
            return $this->reject('manifest_format', __('The update manifest has no valid checksum, so the update was not installed.', 'fluent-support-pro'));
        }

        $manifest['sha256'] = strtolower($manifest['sha256']);

        return $manifest;
    }

    /**
     * Pull the raw manifest and signature off the update object.
     *
     * @param object|null $update
     * @return array|\WP_Error ['manifest' => raw bytes, 'signature' => base64]
     */
    private function proofBytes($update)
    {
        $manifest = isset($update->manifest) ? $update->manifest : '';
        $signature = isset($update->signature) ? $update->signature : '';

        if (!is_string($manifest) || !is_string($signature) || $manifest === '' || $signature === '') {
            return $this->reject('missing_signature', __('This update was served without a signature, so it was not installed. Please try again later, and contact support if this keeps happening.', 'fluent-support-pro'));
        }

        $decoded = base64_decode($manifest, true);

        if ($decoded === false || $decoded === '') {
            return $this->reject('manifest_encoding', __('The update manifest could not be read, so the update was not installed.', 'fluent-support-pro'));
        }

        return ['manifest' => $decoded, 'signature' => $signature];
    }

    /**
     * Verify a detached Ed25519 signature over the exact bytes given.
     *
     * @param string $message Exact signed bytes.
     * @param string $sigBase64 Base64 of the 64 byte detached signature.
     * @param string $keyId Key id named by the manifest.
     * @return bool
     */
    private function verifySignature($message, $sigBase64, $keyId)
    {
        // verifyPackage() checks this first. Kept as a guard so an unsupported
        // server never reads as "not signed by us".
        if (!self::isSupported()) {
            return false;
        }

        $keys = self::trustedKeys();

        if (!isset($keys[$keyId])) {
            return false;
        }

        $signature = base64_decode($sigBase64, true);

        // Literal 64, not SODIUM_CRYPTO_SIGN_BYTES: the constant can be missing
        // when sodium is partly disabled, which is fatal on PHP 8.
        if ($signature === false || strlen($signature) !== 64) {
            return false;
        }

        // hex2bin() rather than sodium_hex2bin(), which may be unavailable.
        $publicKey = hex2bin($keys[$keyId]);

        if ($publicKey === false || strlen($publicKey) !== 32) {
            return false;
        }

        try {
            return sodium_crypto_sign_verify_detached($signature, $message, $publicKey);
        } catch (\Exception $e) {
            return false;
        } catch (\Error $e) {
            return false;
        }
    }

    /**
     * The trusted keys, minus malformed entries, so a bad key leaves verification
     * off instead of blocking every update.
     *
     * @return array<string, string>
     */
    private static function trustedKeys()
    {
        $keys = [];

        foreach (self::TRUSTED_KEYS as $keyId => $publicKey) {
            if (is_string($publicKey) && preg_match('/^[a-f0-9]{64}$/i', $publicKey)) {
                $keys[$keyId] = strtolower($publicKey);
            }
        }

        return $keys;
    }

    /**
     * The update object our own updater put into the transient.
     *
     * @return object|null
     */
    private function updateEntry()
    {
        $transient = get_site_transient('update_plugins');

        if (is_object($transient) && isset($transient->response[$this->basename]) && is_object($transient->response[$this->basename])) {
            return $transient->response[$this->basename];
        }

        return null;
    }

    /** One uncached call to the licensing API per request, and only if we can. */
    private function canRefetch()
    {
        return !$this->refetched && is_callable($this->freshFetch);
    }

    /**
     * Ask the licensing API directly, bypassing every cache.
     *
     * @return object|null
     */
    private function fetchFresh()
    {
        $this->refetched = true;

        $fresh = call_user_func($this->freshFetch);

        return is_object($fresh) ? $fresh : null;
    }

    /**
     * @param string $code
     * @param string $message
     * @return \WP_Error
     */
    private function reject($code, $message)
    {
        // No stored state needed: the upgrader already shows this message to the user.
        do_action('fluent_support/update_verification_failed', $this->slug, $code, $message);

        return new \WP_Error('fluent_sl_' . $code, $message);
    }
}
