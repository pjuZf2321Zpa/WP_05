<?php

namespace FluentSupportPro\App\Services\PluginManager;

class PluginInstaller
{
    const CORE_BASENAME = 'fluent-support/fluent-support.php';
    const CORE_SLUG = 'fluent-support';

    /**
     * @return void
     */
    public function registerCoreUpdater()
    {
        add_filter('site_transient_update_plugins', [$this, 'maybePushCoreUpdate'], 20);
    }

    /**
     * Offer the required Fluent Support core version straight from its
     * downloads.wordpress.org zip when the installed core is older.
     *
     * After a release, the wp.org update-check API can lag about a day behind the
     * published zip, so without this the update would not show up yet.
     *
     * @param object $transient The update_plugins site transient.
     * @return object
     */
    public function maybePushCoreUpdate($transient)
    {
        if (!is_object($transient)) {
            return $transient;
        }

        $minVersion = FLUENTSUPPORT_MIN_CORE_VERSION;

        if (!defined('FLUENT_SUPPORT_VERSION') || version_compare(FLUENT_SUPPORT_VERSION, $minVersion, '>=')) {
            return $transient;
        }

        $existing = null;
        if (isset($transient->response[self::CORE_BASENAME]) && is_object($transient->response[self::CORE_BASENAME])) {
            $existing = $transient->response[self::CORE_BASENAME];
        } elseif (isset($transient->no_update[self::CORE_BASENAME]) && is_object($transient->no_update[self::CORE_BASENAME])) {
            $existing = $transient->no_update[self::CORE_BASENAME];
        }

        // If WP already surfaced an update at or above the minimum, let it handle it.
        if ($existing && isset($existing->new_version) && version_compare($existing->new_version, $minVersion, '>=')) {
            return $transient;
        }

        $package = 'https://downloads.wordpress.org/plugin/' . self::CORE_SLUG . '.' . $minVersion . '.zip';

        // Reuse WP's entry for its icons, banners and requirements metadata.
        // During the lag it sits in no_update.
        if ($existing) {
            $update = clone $existing;
        } else {
            $update = (object) [
                'id'     => 'w.org/plugins/' . self::CORE_SLUG,
                'slug'   => self::CORE_SLUG,
                'plugin' => self::CORE_BASENAME,
                'url'    => 'https://wordpress.org/plugins/' . self::CORE_SLUG . '/',
            ];
        }

        $update->new_version = $minVersion;
        $update->package     = $package;

        $transient->response[self::CORE_BASENAME] = $update;
        unset($transient->no_update[self::CORE_BASENAME]);

        return $transient;
    }
}
