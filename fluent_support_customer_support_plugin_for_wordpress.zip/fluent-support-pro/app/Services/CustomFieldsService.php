<?php

namespace FluentSupportPro\App\Services;

use FluentSupportPro\App\Modules\CustomFields\CustomFields;

/**
 * @deprecated Use FluentSupportPro\App\Modules\CustomFields\CustomFields.
 */
class CustomFieldsService
{
    public static function getCustomFields()
    {
        return CustomFields::all();
    }

    public static function getFieldLabels($scope = 'public')
    {
        return CustomFields::labels($scope);
    }

    public static function getRenderedPublicFields($customer = false, $scope = 'public')
    {
        return CustomFields::rendered($customer ?: null, $scope);
    }

    public static function getCustomerRenderers()
    {
        return apply_filters('fluent_support/custom_field_renders_type', []);
    }
}
