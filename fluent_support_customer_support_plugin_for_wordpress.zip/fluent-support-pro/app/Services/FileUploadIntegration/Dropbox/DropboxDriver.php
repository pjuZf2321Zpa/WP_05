<?php

namespace FluentSupportPro\App\Services\FileUploadIntegration\Dropbox;

use FluentSupport\Framework\Support\Arr;
use FluentSupportPro\App\Services\FileUploadIntegration\Support\BaseDriver;
use FluentSupportPro\App\Services\FileUploadIntegration\Support\Http;
use FluentSupportPro\App\Services\FileUploadIntegration\Support\OAuthAccounts;

/**
 * Dropbox storage. Files stay private: downloads use a temporary link (valid 4
 * hours) created when someone opens the file, never a public shared link.
 */
class DropboxDriver extends BaseDriver
{
    use OAuthAccounts;

    const MASK = '********';
    const DOCS_URL = 'https://docs.fluentsupport.com/dropbox-integration';

    protected function tokenEndpoint()
    {
        return 'https://api.dropbox.com/oauth2/token';
    }

    protected function defaultTokenLifetime()
    {
        return 14400;
    }

    public function getKey()
    {
        return 'dropbox';
    }

    protected function optionKey()
    {
        return 'dropbox_settings';
    }

    protected function defaults()
    {
        return [
            'access_token'  => '',
            'refresh_token' => '',
            'expire_at'     => '',
            'client_id'     => '',
            'account_id'    => '',
            'client_secret' => '',
            'status'        => 'no',
            'last_error'    => '',
            'is_encrypted'  => 'no',
        ];
    }

    protected function encryptedFields()
    {
        return [
            'access_token'  => 'is_encrypted',
            'refresh_token' => 'is_encrypted',
            'client_secret' => 'client_secret_encrypted',
        ];
    }

    public function register()
    {
        parent::register();
        add_action('fluent_support_pro/verify_dropbox_code', [$this, 'verifyCode']);
    }

    public function isConfigured()
    {
        $settings = $this->getSettings();

        return $settings['status'] === 'yes' && !empty($settings['access_token']) && !empty($settings['refresh_token']);
    }

    public static function getOAuthRedirectUri()
    {
        $redirectUri = rest_url('fluent-support/v2/public/dropbox_auth');

        if (!is_ssl() && !in_array(wp_parse_url($redirectUri, PHP_URL_HOST), ['localhost', '127.0.0.1'], true)) {
            $redirectUri = set_url_scheme($redirectUri, 'https');
        }

        return $redirectUri;
    }

    /**
     * Permissions requested when connecting. They must also be enabled in the
     * app's Permissions tab (see the setup guide).
     *
     * @return string[]
     */
    public static function requiredScopes()
    {
        return ['files.metadata.read', 'files.content.write', 'files.content.read', 'sharing.read', 'sharing.write'];
    }

    /**
     * Dropbox permissions the app needs, with a call that reports a missing scope
     * without touching any file (the paths don't exist).
     */
    private function permissionProbes()
    {
        return [
            'files.content.read' => ['files/get_temporary_link', ['path' => '/fs-permission-check/none.txt']],
            'sharing.read'       => ['sharing/list_shared_links', ['path' => '/fs-permission-check/none.txt', 'direct_only' => true]],
            'sharing.write'      => ['sharing/revoke_shared_link', ['url' => 'https://www.dropbox.com/s/fs-permission-check']],
        ];
    }

    /**
     * Which permissions the connected app is missing. Checked on connect, then at
     * most every 12 hours (or right away when a call reports a missing scope).
     *
     * @param bool $force
     * @return string[] Missing permission names.
     */
    public function missingPermissions($force = false)
    {
        $settings = $this->getSettings();
        $checked = (array) Arr::get($settings, 'permissions', []);

        if (!$force && !empty($checked['checked_at']) && (time() - (int) $checked['checked_at']) < 12 * HOUR_IN_SECONDS) {
            return (array) Arr::get($checked, 'missing', []);
        }

        $token = $this->getAccessToken();
        if (is_wp_error($token)) {
            return (array) Arr::get($checked, 'missing', []);
        }

        $missing = [];
        foreach ($this->permissionProbes() as $scope => $probe) {
            $response = $this->api($probe[0], $probe[1], $token);

            // Can't tell (network): keep what we knew.
            if (is_wp_error($response)) {
                return (array) Arr::get($checked, 'missing', []);
            }

            if (self::scopeError($response)) {
                $missing[] = $scope;
            }
        }

        $fresh = $this->getSettings();
        $fresh['permissions'] = ['missing' => $missing, 'checked_at' => time()];
        $this->updateSettings($fresh);

        return $missing;
    }

    /**
     * @return string The missing scope named by a Dropbox error, or ''.
     */
    private static function scopeError($response)
    {
        $body = (string) $response['body'];

        if (preg_match("/required scope '([a-z._]+)'/", $body, $match)) {
            return $match[1];
        }

        $json = json_decode($body, true);
        $error = is_array($json) && isset($json['error']) && is_array($json['error']) ? $json['error'] : [];
        if (isset($error['.tag']) && $error['.tag'] === 'missing_scope') {
            return !empty($error['required_scope']) ? (string) $error['required_scope'] : 'files.content.read';
        }

        if (strpos($body, 'missing_scope') !== false) {
            return 'files.content.read';
        }

        return '';
    }

    public function getSetupIssue()
    {
        if (!$this->isConfigured()) {
            return [];
        }

        $missing = $this->missingPermissions();

        if (!$missing) {
            return [];
        }

        return [
            'message'  => sprintf(
                /* translators: %s: comma-separated Dropbox permission names */
                __('Your Dropbox app is missing these permissions: %s. Enable them in the Dropbox App Console (Permissions tab), then reconnect Dropbox here.', 'fluent-support-pro'),
                implode(', ', $missing)
            ),
            'help_url' => self::DOCS_URL . '#fix-a-missing-permission',
        ];
    }

    private static function missingScopeError($scope)
    {
        return new \WP_Error('dropbox_missing_scope', sprintf(
            /* translators: %s: Dropbox permission name, e.g. files.content.read */
            __('Your Dropbox app is missing the %s permission. Enable it in the Dropbox App Console (Permissions tab), then reconnect Dropbox here. Files stay on this server until then.', 'fluent-support-pro'),
            $scope
        ));
    }

    public function upload($attachment, $ticketId)
    {
        // Without read access an uploaded file could never be opened or emailed.
        if (in_array('files.content.read', $this->missingPermissions(), true)) {
            return self::missingScopeError('files.content.read');
        }

        $localPath = (string) $attachment->file_path;
        if (!file_exists($localPath)) {
            return new \WP_Error('file_not_found', __('File not found for upload.', 'fluent-support-pro'));
        }

        $token = $this->getAccessToken();
        if (is_wp_error($token)) {
            return $token;
        }

        $path = '/ticket_' . (int) $ticketId . '/' . $this->uniqueFileName($attachment->title);

        $response = Http::sendFile('POST', 'https://content.dropboxapi.com/2/files/upload', [
            'Authorization'   => 'Bearer ' . $token,
            'Content-Type'    => 'application/octet-stream',
            'Dropbox-API-Arg' => self::apiArg([
                'path'       => $path,
                'mode'       => 'add',
                'autorename' => true,
                'mute'       => true,
            ]),
        ], $localPath, 300);

        $data = $this->decode($response, 'id');
        if (is_wp_error($data)) {
            return $data;
        }

        $meta = $this->attachmentSettings($attachment);
        $meta['storage_conn'] = $this->currentAccountKey();
        $meta['dropbox_id'] = $data['id'];
        $meta['dropbox_path'] = Arr::get($data, 'path_display', $path);
        $meta['private'] = 'yes';

        $attachment->settings = $meta;
        $attachment->file_path = 'dropbox://' . $data['id'];
        $attachment->full_url = '';
        $attachment->driver = $this->getKey();
        $attachment->save();

        return true;
    }

    private function fileRef($attachment)
    {
        $meta = $this->attachmentSettings($attachment);
        $id = Arr::get($meta, 'dropbox_id');

        if (!$id && strpos((string) $attachment->file_path, 'dropbox://') === 0) {
            $id = substr($attachment->file_path, strlen('dropbox://'));
        }

        return (string) $id;
    }

    public function delete($attachment)
    {
        $ref = $this->fileRef($attachment);
        $token = $this->getAccessToken($attachment);

        if (!$ref || is_wp_error($token)) {
            return is_wp_error($token) ? $token : new \WP_Error('no_file', 'No Dropbox file reference.');
        }

        $response = $this->api('files/delete_v2', ['path' => $ref], $token);

        if (!is_wp_error($response) && $response['code'] == 409 && strpos($response['body'], 'not_found') !== false) {
            return true;
        }

        $data = $this->decode($response);

        return is_wp_error($data) ? $data : true;
    }

    public function getDownloadUrl($attachment)
    {
        $link = $this->temporaryLink($attachment);

        if (is_wp_error($link) && ($public = $this->legacyPublicUrl($attachment))) {
            return $public;
        }

        return $link;
    }

    /**
     * @return string|\WP_Error A link to the file bytes, valid 4 hours.
     */
    private function temporaryLink($attachment)
    {
        $ref = $this->fileRef($attachment);

        if (!$ref) {
            return new \WP_Error('no_file', 'No Dropbox file reference.');
        }

        $token = $this->getAccessToken($attachment);
        if (is_wp_error($token)) {
            return $token;
        }

        $data = $this->decode($this->api('files/get_temporary_link', ['path' => $ref], $token), 'link');

        // Permissions changed in the App Console: refresh what we know.
        if (is_wp_error($data) && $data->get_error_code() === 'dropbox_missing_scope') {
            $this->missingPermissions(true);
        }

        return is_wp_error($data) ? $data : $data['link'];
    }

    public function getLocalCopy($attachment, $maxBytes = 0)
    {
        $link = $this->temporaryLink($attachment);
        if (is_wp_error($link)) {
            return $link;
        }

        $path = Http::tempFile($attachment->title);
        $result = Http::downloadTo($link, [], $path, 300, $maxBytes);

        return is_wp_error($result) ? $result : $path;
    }

    public function canRevokePublicLinks()
    {
        return !array_intersect(['sharing.read', 'sharing.write'], $this->missingPermissions());
    }

    /**
     * Remove public shared links that Pro 2.4.5 and earlier created for this file.
     *
     * @return true|\WP_Error
     */
    public function revokePublicLinks($attachment)
    {
        $ref = $this->fileRef($attachment);
        $token = $this->getAccessToken($attachment);

        if (!$ref || is_wp_error($token)) {
            return is_wp_error($token) ? $token : new \WP_Error('no_file', 'No Dropbox file reference.');
        }

        $data = $this->decode($this->api('sharing/list_shared_links', ['path' => $ref, 'direct_only' => true], $token), 'links');
        if (is_wp_error($data)) {
            return $data;
        }

        foreach ($data['links'] as $link) {
            if (empty($link['url'])) {
                continue;
            }
            $result = $this->decode($this->api('sharing/revoke_shared_link', ['url' => $link['url']], $token));
            if (is_wp_error($result)) {
                return $result;
            }
        }

        $meta = $this->attachmentSettings($attachment);
        $meta['private'] = 'yes';
        $attachment->settings = $meta;
        $attachment->full_url = '';
        $attachment->save();

        return true;
    }

    private function api($endpoint, array $body, $token)
    {
        return Http::request('POST', 'https://api.dropboxapi.com/2/' . $endpoint, [
            'Authorization' => 'Bearer ' . $token,
            'Content-Type'  => 'application/json',
        ], wp_json_encode($body), 30);
    }

    /**
     * Dropbox-API-Arg must be ASCII; json_encode escapes everything else as \uXXXX.
     */
    private static function apiArg(array $arg)
    {
        return str_replace("\x7f", '\\u007f', (string) wp_json_encode($arg, JSON_UNESCAPED_SLASHES));
    }

    /**
     * @return array|\WP_Error Decoded JSON body.
     */
    private function decode($response, $requiredKey = '')
    {
        if (is_wp_error($response)) {
            return $response;
        }

        $body = json_decode($response['body'], true);

        if ($response['code'] > 299) {
            $summary = is_array($body) ? Arr::get($body, 'error_summary', Arr::get($body, 'error_description', '')) : '';

            $scope = self::scopeError($response);
            if ($scope) {
                return self::missingScopeError($scope);
            }

            return new \WP_Error('dropbox_error', trim(sprintf(__('Dropbox request failed (HTTP %d)', 'fluent-support-pro'), $response['code']) . ' ' . $summary));
        }

        if ($requiredKey && (!is_array($body) || !isset($body[$requiredKey]))) {
            return new \WP_Error('dropbox_error', __('Unexpected response from Dropbox.', 'fluent-support-pro'));
        }

        return is_array($body) ? $body : [];
    }

    public function getSettingsAndFields($data)
    {
        $all = $this->getSettings();
        $settings = Arr::only($all, ['client_id', 'status']);
        $settings['client_secret'] = empty($all['client_secret']) ? '' : self::MASK;

        $configured = $this->isConfigured();

        $fieldConfig = [
            'title'       => __('Dropbox File Upload Settings', 'fluent-support-pro'),
            'component'   => 'DropboxSettings',
            /* translators: %1$s is the opening link tag to the documentation, %2$s is the closing link tag */
            'description' => sprintf(__('Please %1$sread the documentation%2$s first to get the Client ID and Client Secret.', 'fluent-support-pro'), '<a href="' . esc_url(self::DOCS_URL) . '" rel="noopener" target="_blank">', '</a>'),
            'fields'      => [
                'outh_redirect' => [
                    'type' => 'html-viewer',
                    'html' => '<p style="padding: 10px;background: var(--fs-bg-subtle, #222530);border-radius: 5px;">' . sprintf(__('oAuth2 Redirect URL for Your APP: %s', 'fluent-support-pro'), '<code>' . esc_html(self::getOAuthRedirectUri()) . '</code>') . '</p>'
                ],
                'client_id'     => [
                    'type'        => 'input-text',
                    'data_type'   => 'text',
                    'label'       => __('Dropbox Client ID', 'fluent-support-pro'),
                    'placeholder' => __('Dropbox Client ID', 'fluent-support-pro'),
                    'help'        => __('Enter Dropbox Client ID Here', 'fluent-support-pro')
                ],
                'client_secret' => [
                    'type'        => 'input-text',
                    'data_type'   => 'password',
                    'label'       => __('Dropbox Client Secret', 'fluent-support-pro'),
                    'placeholder' => __('Dropbox Client Secret', 'fluent-support-pro'),
                    'help'        => __('Enter Dropbox Client Secret Here', 'fluent-support-pro')
                ],
            ],
            'button_text' => $configured ? __('Save Settings', 'fluent-support-pro') : __('Connect to Dropbox', 'fluent-support-pro'),
            'has_discard' => $configured,
            'last_error'  => Arr::get($all, 'last_error') ?: Arr::get($this->getStatus(), 'last_error'),
            'file_count'  => $this->countFiles(),
        ];

        $issue = $this->getSetupIssue();
        if ($issue) {
            $fieldConfig['last_error'] = $issue['message'];
            $fieldConfig['help_url'] = $issue['help_url'];
        }

        return [
            'settings'     => $settings,
            'fieldsConfig' => $fieldConfig
        ];
    }

    public function saveSettings($response, $input)
    {
        if (!empty($input['disconnect']) || empty($input['client_id']) || empty($input['client_secret'])) {
            // Keep the account so files stored there can still be opened.
            $this->archiveCurrentAccount();
            $this->updateSettings(array_merge($this->defaults(), ['status' => 'no']));
            $this->deactivateIfActive();

            return [
                'message'      => __('Dropbox settings have been disconnected', 'fluent-support-pro'),
                'is_discarded' => true
            ];
        }

        $old = $this->getSettings();
        $secret = $input['client_secret'] === self::MASK ? $old['client_secret'] : sanitize_text_field($input['client_secret']);
        $clientId = sanitize_text_field($input['client_id']);

        $isNew = $old['client_id'] !== $clientId || $old['client_secret'] !== $secret;

        $old['client_id'] = $clientId;
        $old['client_secret'] = $secret;

        if ($isNew || !empty($input['do_reconnect']) || $old['status'] !== 'yes' || !empty($old['last_error'])) {
            $this->archiveCurrentAccount();
            $old['status'] = 'no';
            $old['last_error'] = '';
            $old['oauth_start'] = 'yes';
            $this->updateSettings($old);

            // Random state, prefixed with the user ID so concurrent admins don't clash (CSRF).
            $userId = get_current_user_id();
            $state = $userId . '|' . wp_generate_password(40, false);
            set_transient('fluent_support_dropbox_oauth_state_' . $userId, $state, 600);

            // Ask for exactly what Fluent Support needs and always show the approval
            // screen: without both, Dropbox reuses an earlier approval and its old
            // permissions, so permissions added in the App Console never arrive.
            $redirect = add_query_arg([
                'response_type'     => 'code',
                'token_access_type' => 'offline',
                'client_id'         => rawurlencode($clientId),
                'redirect_uri'      => rawurlencode(self::getOAuthRedirectUri()),
                'state'             => rawurlencode($state),
                'scope'             => rawurlencode(implode(' ', self::requiredScopes())),
                'force_reapprove'   => 'true',
            ], 'https://www.dropbox.com/oauth2/authorize');

            return [
                'message'  => __('Please authorize your Dropbox account', 'fluent-support-pro'),
                'redirect' => $redirect
            ];
        }

        $this->updateSettings($old);

        return [
            'message' => __('Dropbox settings have been saved', 'fluent-support-pro')
        ];
    }

    public function verifyCode($code)
    {
        $settings = $this->getSettings();

        if (!$code || empty($settings['oauth_start'])) {
            return;
        }

        $response = Http::request('POST', 'https://api.dropbox.com/oauth2/token', [
            'Content-Type' => 'application/x-www-form-urlencoded'
        ], [
            'code'          => $code,
            'grant_type'    => 'authorization_code',
            'client_id'     => $settings['client_id'],
            'client_secret' => $settings['client_secret'],
            'redirect_uri'  => self::getOAuthRedirectUri()
        ], 30);

        $data = $this->decode($response, 'access_token');

        if (is_wp_error($data)) {
            $settings['last_error'] = $data->get_error_message();
            $this->updateSettings($settings);
            return;
        }

        $settings['access_token'] = $data['access_token'];
        $settings['refresh_token'] = Arr::get($data, 'refresh_token', '');
        $settings['expire_at'] = time() + (int) Arr::get($data, 'expires_in', 14400);
        $settings['account_id'] = Arr::get($data, 'account_id', '');
        $settings['status'] = 'yes';
        $settings['last_error'] = '';
        unset($settings['oauth_start'], $settings['permissions']);

        $this->updateSettings($settings);
        $this->missingPermissions(true);
        $this->afterConnected();
    }
}
