<?php

namespace FluentSupportPro\App\Services\FileUploadIntegration\AmazonS3;

use FluentSupport\Framework\Support\Arr;
use FluentSupportPro\App\Services\FileUploadIntegration\Support\S3FamilyDriver;

class AmazonS3Driver extends S3FamilyDriver
{
    public function getKey()
    {
        return 'amazon_s3';
    }

    protected function optionKey()
    {
        return 'amazon_s3_settings';
    }

    protected function constantPrefix()
    {
        return 'FLUENT_SUPPORT_S3';
    }

    protected function pathScheme()
    {
        return 's3://';
    }

    protected function legacyObjectKey()
    {
        return 's3_key';
    }

    protected function defaults()
    {
        return [
            'access_key_id'     => '',
            'secret_access_key' => '',
            'bucket_name'       => '',
            'region'            => 'us-east-1',
            'path_prefix'       => 'fluent-support',
            'status'            => 'no',
            'last_error'        => '',
            'is_encrypted'      => 'no',
        ];
    }

    protected function constantMap()
    {
        return array_merge(parent::constantMap(), ['REGION' => 'region']);
    }

    protected function formFields()
    {
        return ['bucket_name', 'region', 'path_prefix'];
    }

    protected function canDetectRegion()
    {
        return true;
    }

    public static function endpointForRegion($region)
    {
        $region = $region ?: 'us-east-1';
        $suffix = strpos($region, 'cn-') === 0 ? 'amazonaws.com.cn' : 'amazonaws.com';

        return "s3.{$region}.{$suffix}";
    }

    protected function connectionFromSettings(array $settings)
    {
        $region = Arr::get($settings, 'region') ?: 'us-east-1';

        return [
            'endpoint'   => self::endpointForRegion($region),
            'bucket'     => (string) Arr::get($settings, 'bucket_name'),
            'region'     => $region,
            'access_key' => (string) Arr::get($settings, 'access_key_id'),
            'secret_key' => (string) Arr::get($settings, 'secret_access_key'),
            'path_style' => false,
        ];
    }

    protected function applyLegacyLocation(array $conn, array $meta)
    {
        if (!empty($meta['s3_bucket'])) {
            $conn['bucket'] = $meta['s3_bucket'];
        }

        if (!empty($meta['s3_region'])) {
            $conn['region'] = $meta['s3_region'];
            $conn['endpoint'] = self::endpointForRegion($meta['s3_region']);
        }

        return $conn;
    }

    protected function addLegacyLocation(array $meta, array $conn)
    {
        $meta['s3_bucket'] = $conn['bucket'];
        $meta['s3_region'] = $conn['region'];

        return $meta;
    }

    protected function publicUrl($key, array $settings)
    {
        $conn = $this->connectionFromSettings($settings);

        return 'https://' . $conn['bucket'] . '.' . $conn['endpoint'] . '/' . ltrim($key, '/');
    }

    protected function fieldsConfig(array $settings)
    {
        return [
            'title'       => __('Amazon S3 File Upload Settings', 'fluent-support-pro'),
            'description' => sprintf(
                /* translators: %1$s: opening link tag, %2$s: closing link tag */
                __('Please %1$sread the documentation%2$s first to get your S3 credentials.', 'fluent-support-pro'),
                '<a href="https://docs.fluentsupport.com/amazon-s3" rel="noopener" target="_blank">',
                '</a>'
            ),
            'fields'      => [
                'access_key_id'     => [
                    'type'        => 'input-text',
                    'data_type'   => 'text',
                    'label'       => __('Amazon S3 Access Key', 'fluent-support-pro'),
                    'placeholder' => __('Amazon S3 Access Key', 'fluent-support-pro'),
                    'help'        => __('Find this in AWS Console > IAM > Security credentials', 'fluent-support-pro'),
                ],
                'secret_access_key' => [
                    'type'        => 'input-text',
                    'data_type'   => 'password',
                    'label'       => __('Amazon S3 Secret Key', 'fluent-support-pro'),
                    'placeholder' => __('Amazon S3 Secret Key', 'fluent-support-pro'),
                    'help'        => __('Only shown once when creating the access key', 'fluent-support-pro'),
                ],
                'bucket_name'       => [
                    'type'        => 'input-text',
                    'data_type'   => 'text',
                    'label'       => __('Amazon S3 Bucket Name', 'fluent-support-pro'),
                    'placeholder' => __('your-bucket-name', 'fluent-support-pro'),
                    'help'        => __('The S3 bucket to store attachments. Keep it private; files are served through short-lived signed links.', 'fluent-support-pro'),
                ],
                'region'            => [
                    'type'        => 'input-options',
                    'label'       => __('AWS Region', 'fluent-support-pro'),
                    'placeholder' => __('Select S3 Region', 'fluent-support-pro'),
                    'help'        => __('The AWS region where your bucket is located. Corrected automatically if it is wrong.', 'fluent-support-pro'),
                    'options'     => self::regionOptions(),
                ],
                'path_prefix'       => [
                    'type'        => 'input-text',
                    'data_type'   => 'text',
                    'label'       => __('Path Prefix', 'fluent-support-pro'),
                    'placeholder' => __('fluent-support', 'fluent-support-pro'),
                    'help'        => __('Optional: Prefix for all uploaded files (default: fluent-support)', 'fluent-support-pro'),
                ],
            ],
        ];
    }

    public static function regionOptions()
    {
        return [
            ['id' => 'us-east-1', 'title' => __('US East (N. Virginia)', 'fluent-support-pro')],
            ['id' => 'us-east-2', 'title' => __('US East (Ohio)', 'fluent-support-pro')],
            ['id' => 'us-west-1', 'title' => __('US West (N. California)', 'fluent-support-pro')],
            ['id' => 'us-west-2', 'title' => __('US West (Oregon)', 'fluent-support-pro')],
            ['id' => 'ca-central-1', 'title' => __('Canada (Central)', 'fluent-support-pro')],
            ['id' => 'eu-west-1', 'title' => __('Europe (Ireland)', 'fluent-support-pro')],
            ['id' => 'eu-west-2', 'title' => __('Europe (London)', 'fluent-support-pro')],
            ['id' => 'eu-west-3', 'title' => __('Europe (Paris)', 'fluent-support-pro')],
            ['id' => 'eu-central-1', 'title' => __('Europe (Frankfurt)', 'fluent-support-pro')],
            ['id' => 'eu-central-2', 'title' => __('Europe (Zurich)', 'fluent-support-pro')],
            ['id' => 'eu-north-1', 'title' => __('Europe (Stockholm)', 'fluent-support-pro')],
            ['id' => 'eu-south-1', 'title' => __('Europe (Milan)', 'fluent-support-pro')],
            ['id' => 'ap-south-1', 'title' => __('Asia Pacific (Mumbai)', 'fluent-support-pro')],
            ['id' => 'ap-southeast-1', 'title' => __('Asia Pacific (Singapore)', 'fluent-support-pro')],
            ['id' => 'ap-southeast-2', 'title' => __('Asia Pacific (Sydney)', 'fluent-support-pro')],
            ['id' => 'ap-northeast-1', 'title' => __('Asia Pacific (Tokyo)', 'fluent-support-pro')],
            ['id' => 'ap-northeast-2', 'title' => __('Asia Pacific (Seoul)', 'fluent-support-pro')],
            ['id' => 'ap-northeast-3', 'title' => __('Asia Pacific (Osaka)', 'fluent-support-pro')],
            ['id' => 'me-central-1', 'title' => __('Middle East (UAE)', 'fluent-support-pro')],
            ['id' => 'sa-east-1', 'title' => __('South America (Sao Paulo)', 'fluent-support-pro')],
            ['id' => 'cn-north-1', 'title' => __('China (Beijing)', 'fluent-support-pro')],
            ['id' => 'cn-northwest-1', 'title' => __('China (Ningxia)', 'fluent-support-pro')],
            ['id' => 'us-gov-west-1', 'title' => __('AWS GovCloud (US-West)', 'fluent-support-pro')],
            ['id' => 'us-gov-east-1', 'title' => __('AWS GovCloud (US-East)', 'fluent-support-pro')],
        ];
    }
}
