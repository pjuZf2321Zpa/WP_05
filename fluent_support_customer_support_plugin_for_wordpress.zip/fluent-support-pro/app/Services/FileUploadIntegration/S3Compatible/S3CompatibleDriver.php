<?php

namespace FluentSupportPro\App\Services\FileUploadIntegration\S3Compatible;

use FluentSupport\Framework\Support\Arr;
use FluentSupportPro\App\Services\FileUploadIntegration\Support\S3FamilyDriver;

/**
 * Any S3-compatible storage: DigitalOcean Spaces, Wasabi, Backblaze B2, MinIO, ...
 */
class S3CompatibleDriver extends S3FamilyDriver
{
    public function getKey()
    {
        return 's3_compatible';
    }

    protected function optionKey()
    {
        return 's3_compatible_settings';
    }

    protected function constantPrefix()
    {
        return 'FLUENT_SUPPORT_S3C';
    }

    protected function pathScheme()
    {
        return 's3c://';
    }

    protected function legacyObjectKey()
    {
        return 'object_key';
    }

    protected function defaults()
    {
        return [
            'endpoint'          => '',
            'region'            => '',
            'access_key_id'     => '',
            'secret_access_key' => '',
            'bucket_name'       => '',
            'path_style'        => 'no',
            'custom_domain'     => '',
            'path_prefix'       => 'fluent-support',
            'status'            => 'no',
            'last_error'        => '',
            'is_encrypted'      => 'no',
        ];
    }

    protected function constantMap()
    {
        return array_merge(parent::constantMap(), [
            'ENDPOINT'      => 'endpoint',
            'REGION'        => 'region',
            'PATH_STYLE'    => 'path_style',
            'CUSTOM_DOMAIN' => 'custom_domain',
        ]);
    }

    protected function formFields()
    {
        return ['endpoint', 'region', 'bucket_name', 'path_style', 'custom_domain', 'path_prefix'];
    }

    protected function requiredFields()
    {
        return ['endpoint'];
    }

    protected function endpointFields()
    {
        return ['endpoint'];
    }

    protected function connectionFromSettings(array $settings)
    {
        $endpoint = preg_replace('#^https?://#i', '', trim((string) Arr::get($settings, 'endpoint')));

        return [
            'endpoint'   => rtrim($endpoint, '/'),
            'bucket'     => (string) Arr::get($settings, 'bucket_name'),
            'region'     => (string) (Arr::get($settings, 'region') ?: self::guessRegion($endpoint)),
            'access_key' => (string) Arr::get($settings, 'access_key_id'),
            'secret_key' => (string) Arr::get($settings, 'secret_access_key'),
            'path_style' => Arr::get($settings, 'path_style') === 'yes',
        ];
    }

    /**
     * The endpoint is user-entered, so every request host is checked again (see
     * S3Client::hostError()), not only when the settings are saved.
     */
    protected function client(array $conn)
    {
        $conn['host_check'] = [self::class, 'validateEndpoint'];

        return parent::client($conn);
    }

    protected function validateLocation(array $settings)
    {
        $error = parent::validateLocation($settings);
        if ($error) {
            return $error;
        }

        return self::validateEndpoint((string) $settings['endpoint']);
    }

    /**
     * The endpoint must be a public host. A private or reserved address (another
     * service on this server or network) is refused unless allowed by filter, e.g.
     * for a MinIO server on the local network.
     *
     * @return string Error message, or '' when valid.
     */
    public static function validateEndpoint($endpoint)
    {
        $host = strtolower((string) wp_parse_url('https://' . $endpoint, PHP_URL_HOST));

        if (!$host || !preg_match('/^[a-z0-9.\-]+$/', $host)) {
            return __('Please enter a valid endpoint host, e.g. nyc3.digitaloceanspaces.com.', 'fluent-support-pro');
        }

        /**
         * Allow an S3-compatible endpoint on a private or local address.
         *
         * @param bool $allow
         * @param string $host
         */
        if (apply_filters('fluent_support_pro/storage_allow_private_endpoint', false, $host)) {
            return '';
        }

        $ips = filter_var($host, FILTER_VALIDATE_IP) ? [$host] : self::resolveHost($host);

        if ($host === 'localhost' || !$ips) {
            return __('The endpoint host could not be found or is not a public address.', 'fluent-support-pro');
        }

        foreach ($ips as $ip) {
            if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                return __('The endpoint host could not be found or is not a public address.', 'fluent-support-pro');
            }
        }

        return '';
    }

    /**
     * IPv4 and IPv6 addresses of a host name. Both are checked, since the request
     * may connect over either.
     *
     * @return string[]
     */
    private static function resolveHost($host)
    {
        $ips = (array) gethostbynamel($host);

        if (function_exists('dns_get_record')) {
            $records = @dns_get_record($host, DNS_AAAA); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- a failed lookup returns false
            foreach ((array) $records as $record) {
                if (!empty($record['ipv6'])) {
                    $ips[] = $record['ipv6'];
                }
            }
        }

        return array_values(array_filter($ips));
    }

    /**
     * Region from hosts like nyc3.digitaloceanspaces.com, s3.eu-central-1.wasabisys.com,
     * s3.us-west-004.backblazeb2.com. Falls back to us-east-1.
     */
    public static function guessRegion($endpoint)
    {
        $host = strtolower((string) $endpoint);

        if (preg_match('/^([a-z0-9-]+)\.digitaloceanspaces\.com/', $host, $m)) {
            return $m[1];
        }

        if (preg_match('/^s3\.([a-z0-9-]+)\.(wasabisys|backblazeb2)\.com/', $host, $m)) {
            return $m[1];
        }

        return 'us-east-1';
    }

    protected function publicUrl($key, array $settings)
    {
        if (!empty($settings['custom_domain'])) {
            return rtrim($settings['custom_domain'], '/') . '/' . ltrim($key, '/');
        }

        $conn = $this->connectionFromSettings($settings);

        if ($conn['path_style']) {
            return 'https://' . $conn['endpoint'] . '/' . $conn['bucket'] . '/' . ltrim($key, '/');
        }

        return 'https://' . $conn['bucket'] . '.' . $conn['endpoint'] . '/' . ltrim($key, '/');
    }

    protected function fieldsConfig(array $settings)
    {
        return [
            'title'       => __('S3-Compatible Storage Settings', 'fluent-support-pro'),
            'description' => sprintf(
                /* translators: %1$s: opening link tag, %2$s: closing link tag */
                __('Store attachments on any S3-compatible service, such as DigitalOcean Spaces, Wasabi, Backblaze B2 or MinIO. %1$sRead the setup guide%2$s.', 'fluent-support-pro'),
                '<a href="https://docs.fluentsupport.com/s3-compatible-storage" rel="noopener" target="_blank">',
                '</a>'
            ),
            'fields'      => [
                'endpoint'          => [
                    'type'        => 'input-text',
                    'data_type'   => 'text',
                    'label'       => __('Endpoint', 'fluent-support-pro'),
                    'placeholder' => 'nyc3.digitaloceanspaces.com',
                    'help'        => __('The S3 API host of your provider, without the bucket name.', 'fluent-support-pro'),
                ],
                'region'            => [
                    'type'        => 'input-text',
                    'data_type'   => 'text',
                    'label'       => __('Region', 'fluent-support-pro'),
                    'placeholder' => 'us-east-1',
                    'help'        => __('Optional: Leave empty to detect it from the endpoint.', 'fluent-support-pro'),
                ],
                'access_key_id'     => [
                    'type'        => 'input-text',
                    'data_type'   => 'text',
                    'label'       => __('Access Key', 'fluent-support-pro'),
                    'placeholder' => __('Access Key', 'fluent-support-pro'),
                ],
                'secret_access_key' => [
                    'type'        => 'input-text',
                    'data_type'   => 'password',
                    'label'       => __('Secret Key', 'fluent-support-pro'),
                    'placeholder' => __('Secret Key', 'fluent-support-pro'),
                ],
                'bucket_name'       => [
                    'type'        => 'input-text',
                    'data_type'   => 'text',
                    'label'       => __('Bucket Name', 'fluent-support-pro'),
                    'placeholder' => __('your-bucket-name', 'fluent-support-pro'),
                    'help'        => __('Keep the bucket private; files are served through short-lived signed links.', 'fluent-support-pro'),
                ],
                'path_style'        => [
                    'type'        => 'input-options',
                    'label'       => __('Addressing Style', 'fluent-support-pro'),
                    'options'     => [
                        ['id' => 'no', 'title' => __('Virtual-hosted (bucket.endpoint)', 'fluent-support-pro')],
                        ['id' => 'yes', 'title' => __('Path-style (endpoint/bucket), e.g. MinIO', 'fluent-support-pro')],
                    ],
                ],
                'custom_domain'     => [
                    'type'        => 'input-text',
                    'data_type'   => 'text',
                    'label'       => __('Custom Domain (Optional)', 'fluent-support-pro'),
                    'placeholder' => __('https://files.yourdomain.com', 'fluent-support-pro'),
                ],
                'path_prefix'       => [
                    'type'        => 'input-text',
                    'data_type'   => 'text',
                    'label'       => __('Path Prefix', 'fluent-support-pro'),
                    'placeholder' => __('fluent-support', 'fluent-support-pro'),
                    'help'        => __('Optional: Prefix for all uploaded files (default: fluent-support)', 'fluent-support-pro'),
                ],
            ],
        ];
    }
}
