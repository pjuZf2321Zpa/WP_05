<?php

namespace FluentSupportPro\App\Services\FileUploadIntegration\GoogleDrive;

use FluentSupport\App\Models\Meta;
use FluentSupport\Framework\Support\Arr;
use FluentSupportPro\App\Services\FileUploadIntegration\Support\BaseDriver;
use FluentSupportPro\App\Services\FileUploadIntegration\Support\Http;
use FluentSupportPro\App\Services\FileUploadIntegration\Support\OAuthAccounts;

/**
 * Google Drive storage. Files stay private to the connected account; the site
 * streams them to people who may see the ticket. No "anyone with the link" sharing.
 */
class GoogleDriveDriver extends BaseDriver
{
    use OAuthAccounts;

    const MASK = '********';
    const API = 'https://www.googleapis.com/';

    public function getKey()
    {
        return 'google_drive';
    }

    protected function optionKey()
    {
        return 'google_drive_settings';
    }

    protected function defaults()
    {
        return [
            'client_id'     => '',
            'client_secret' => '',
            'status'        => 'no',
            'access_token'  => '',
            'refresh_token' => '',
            'expire_at'     => '',
            'folder_id'     => '',
            'last_error'    => '',
            'is_encrypted'  => 'no'
        ];
    }

    protected function encryptedFields()
    {
        return [
            'access_token'  => 'is_encrypted',
            'refresh_token' => 'is_encrypted',
            'client_secret' => 'client_secret_encrypted',
        ];
    }

    public function register()
    {
        parent::register();
        add_action('fluent_support_pro/verify_google_code', [$this, 'verifyCode']);
    }

    public function isConfigured()
    {
        $settings = $this->getSettings();

        return $settings['status'] === 'yes' && !empty($settings['access_token']);
    }

    public static function getRedirectUri()
    {
        return rest_url('fluent-support/v2/public/google_auth');
    }

    protected function tokenEndpoint()
    {
        return 'https://oauth2.googleapis.com/token';
    }

    protected function defaultTokenLifetime()
    {
        return 3600;
    }

    public function upload($attachment, $ticketId)
    {
        $localPath = (string) $attachment->file_path;
        if (!file_exists($localPath)) {
            return new \WP_Error('file_not_found', __('File not found for upload.', 'fluent-support-pro'));
        }

        $token = $this->getAccessToken();
        if (is_wp_error($token)) {
            return $token;
        }

        $mimeType = $attachment->file_type ?: 'application/octet-stream';

        $session = $this->startUploadSession($attachment, $ticketId, $token, $mimeType, $localPath);

        // The cached folder was deleted in Drive: forget it and try once more.
        if (!is_wp_error($session) && $session['code'] == 404) {
            $this->forgetFolders($ticketId, $token);
            $session = $this->startUploadSession($attachment, $ticketId, $token, $mimeType, $localPath);
        }

        if (is_wp_error($session)) {
            return $session;
        }

        $location = $this->header($session['headers'], 'location');
        if ($session['code'] > 299 || !$location) {
            return $this->decode($session, 'id');
        }

        $data = $this->decode(Http::sendFile('PUT', $location, [
            'Content-Type' => $mimeType,
        ], $localPath, 300), 'id');

        if (is_wp_error($data)) {
            return $data;
        }

        $meta = $this->attachmentSettings($attachment);
        $meta['storage_conn'] = $this->currentAccountKey();
        $meta['gdrive_id'] = $data['id'];
        $meta['private'] = 'yes';

        $attachment->settings = $meta;
        $attachment->file_path = 'gdrive://' . $data['id'];
        $attachment->full_url = '';
        $attachment->driver = $this->getKey();
        $attachment->save();

        return true;
    }

    /**
     * Resumable upload: metadata first; the bytes go to the returned location.
     *
     * @return array|\WP_Error
     */
    private function startUploadSession($attachment, $ticketId, $token, $mimeType, $localPath)
    {
        $folderId = $this->ticketFolderId($ticketId, $token);
        if (is_wp_error($folderId)) {
            return $folderId;
        }

        return Http::request('POST', self::API . 'upload/drive/v3/files?uploadType=resumable&fields=id', [
            'Authorization'           => 'Bearer ' . $token,
            'Content-Type'            => 'application/json; charset=UTF-8',
            'X-Upload-Content-Type'   => $mimeType,
            'X-Upload-Content-Length' => (string) filesize($localPath),
        ], wp_json_encode([
            'name'    => 'ticket_' . (int) $ticketId . '__' . $attachment->id . '__' . $attachment->title,
            'parents' => [$folderId],
        ]), 30);
    }

    private function forgetFolders($ticketId, $token)
    {
        Meta::where('object_type', 'ticket_meta')
            ->where('object_id', (int) $ticketId)
            ->where('key', '_gdrive_folder_id')
            ->delete();

        // Recreate the main folder only if it is gone too.
        $settings = $this->getSettings();
        if (!empty($settings['folder_id'])) {
            $root = Http::request('GET', self::API . 'drive/v3/files/' . rawurlencode($settings['folder_id']) . '?fields=id,trashed', [
                'Authorization' => 'Bearer ' . $token,
            ], null, 30);

            $body = is_wp_error($root) ? [] : (array) json_decode($root['body'], true);
            if (!is_wp_error($root) && ($root['code'] == 404 || !empty($body['trashed']))) {
                $settings['folder_id'] = '';
                $this->updateSettings($settings);
            }
        }
    }

    private function fileId($attachment)
    {
        $meta = $this->attachmentSettings($attachment);
        $id = Arr::get($meta, 'gdrive_id');

        if (!$id && strpos((string) $attachment->file_path, 'gdrive://') === 0) {
            $id = substr($attachment->file_path, strlen('gdrive://'));
        }

        return preg_replace('/[^A-Za-z0-9_\-]/', '', (string) $id);
    }

    public function delete($attachment)
    {
        $id = $this->fileId($attachment);
        $token = $this->getAccessToken($attachment);

        if (!$id || is_wp_error($token)) {
            return is_wp_error($token) ? $token : new \WP_Error('no_file', 'No Google Drive file reference.');
        }

        $response = Http::request('DELETE', self::API . 'drive/v3/files/' . $id, [
            'Authorization' => 'Bearer ' . $token,
        ], null, 30);

        if (!is_wp_error($response) && in_array($response['code'], [204, 404], true)) {
            return true;
        }

        $data = $this->decode($response);

        return is_wp_error($data) ? $data : true;
    }

    /**
     * Drive has no short-lived direct link for private files, so the site streams them.
     */
    public function getDownloadUrl($attachment)
    {
        // Pro 2.4.5 files keep their public link while the account can't be reached.
        $public = $this->legacyPublicUrl($attachment);
        if ($public && is_wp_error($this->getAccessToken($attachment))) {
            return $public;
        }

        return null;
    }

    public function getLocalCopy($attachment, $maxBytes = 0)
    {
        $id = $this->fileId($attachment);
        $token = $this->getAccessToken($attachment);

        if (!$id) {
            return new \WP_Error('no_file', 'No Google Drive file reference.');
        }

        if (is_wp_error($token)) {
            return $token;
        }

        $path = Http::tempFile($attachment->title);
        $result = Http::downloadTo(self::API . 'drive/v3/files/' . $id . '?alt=media', [
            'Authorization' => 'Bearer ' . $token,
        ], $path, 300, $maxBytes);

        return is_wp_error($result) ? $result : $path;
    }

    public function canRevokePublicLinks()
    {
        return true;
    }

    /**
     * Remove the "anyone with the link" permission Pro 2.4.5 and earlier added.
     *
     * @return true|\WP_Error
     */
    public function revokePublicLinks($attachment)
    {
        $id = $this->fileId($attachment);
        $token = $this->getAccessToken($attachment);

        if (!$id || is_wp_error($token)) {
            return is_wp_error($token) ? $token : new \WP_Error('no_file', 'No Google Drive file reference.');
        }

        $data = $this->decode(Http::request('GET', self::API . 'drive/v3/files/' . $id . '/permissions?fields=permissions(id,type)', [
            'Authorization' => 'Bearer ' . $token,
        ], null, 30), 'permissions');

        if (is_wp_error($data)) {
            return $data;
        }

        foreach ($data['permissions'] as $permission) {
            if (Arr::get($permission, 'type') !== 'anyone') {
                continue;
            }

            $response = Http::request('DELETE', self::API . 'drive/v3/files/' . $id . '/permissions/' . rawurlencode($permission['id']), [
                'Authorization' => 'Bearer ' . $token,
            ], null, 30);

            if (is_wp_error($response) || !in_array($response['code'], [204, 404], true)) {
                return is_wp_error($response) ? $response : $this->decode($response);
            }
        }

        $meta = $this->attachmentSettings($attachment);
        $meta['private'] = 'yes';
        $attachment->settings = $meta;
        $attachment->full_url = '';
        $attachment->save();

        return true;
    }

    /**
     * The ticket's folder, created on first use and remembered on the ticket.
     *
     * @return string|\WP_Error
     */
    private function ticketFolderId($ticketId, $token)
    {
        $cached = Meta::where('object_type', 'ticket_meta')
            ->where('object_id', (int) $ticketId)
            ->where('key', '_gdrive_folder_id')
            ->value('value');

        if ($cached) {
            return $cached;
        }

        $rootId = $this->rootFolderId($token);
        if (is_wp_error($rootId)) {
            return $rootId;
        }

        $folderId = $this->createFolder('ticket_' . (int) $ticketId, $rootId, $token);
        if (is_wp_error($folderId)) {
            return $folderId;
        }

        Meta::insert([
            'object_type' => 'ticket_meta',
            'object_id'   => (int) $ticketId,
            'key'         => '_gdrive_folder_id',
            'value'       => $folderId,
        ]);

        return $folderId;
    }

    private function rootFolderId($token)
    {
        $settings = $this->getSettings();

        if (!empty($settings['folder_id'])) {
            return $settings['folder_id'];
        }

        $name = 'fs-files-for-' . str_replace(['https://', 'http://', '/'], '', site_url());
        $folderId = $this->createFolder($name, null, $token);

        if (is_wp_error($folderId)) {
            return $folderId;
        }

        $settings['folder_id'] = $folderId;
        $this->updateSettings($settings);

        return $folderId;
    }

    private function createFolder($name, $parentId, $token)
    {
        $body = [
            'name'     => $name,
            'mimeType' => 'application/vnd.google-apps.folder',
        ];

        if ($parentId) {
            $body['parents'] = [$parentId];
        }

        $data = $this->decode(Http::request('POST', self::API . 'drive/v3/files?fields=id', [
            'Authorization' => 'Bearer ' . $token,
            'Content-Type'  => 'application/json',
        ], wp_json_encode($body), 30), 'id');

        return is_wp_error($data) ? $data : $data['id'];
    }

    private function header($headers, $name)
    {
        if (is_object($headers) && method_exists($headers, 'offsetGet')) {
            return (string) $headers[$name];
        }

        return is_array($headers) ? (string) Arr::get(array_change_key_case($headers), $name, '') : '';
    }

    /**
     * @return array|\WP_Error
     */
    private function decode($response, $requiredKey = '')
    {
        if (is_wp_error($response)) {
            return $response;
        }

        $body = json_decode($response['body'], true);

        if ($response['code'] > 299) {
            $message = is_array($body) ? Arr::get($body, 'error.message', Arr::get($body, 'error_description', '')) : '';
            return new \WP_Error('gdrive_error', trim(sprintf(__('Google Drive request failed (HTTP %d)', 'fluent-support-pro'), $response['code']) . ' ' . $message));
        }

        if ($requiredKey && (!is_array($body) || !isset($body[$requiredKey]))) {
            return new \WP_Error('gdrive_error', __('Unexpected response from Google Drive.', 'fluent-support-pro'));
        }

        return is_array($body) ? $body : [];
    }

    public function getSettingsAndFields($data)
    {
        $all = $this->getSettings();
        $settings = Arr::only($all, ['client_id', 'status']);
        $settings['client_secret'] = empty($all['client_secret']) ? '' : self::MASK;
        $settings['redirect_uri'] = self::getRedirectUri();

        $configured = $all['status'] === 'yes';

        $fieldConfig = [
            'title'       => __('Google Drive File Upload Settings', 'fluent-support-pro'),
            'component'   => 'GoogleSettings',
            /* translators: %1$s is the opening link tag to the documentation, %2$s is the closing link tag */
            'description' => sprintf(__('Please %1$sread the documentation%2$s first to get the Client ID and Client Secret.', 'fluent-support-pro'), '<a href="https://docs.fluentsupport.com/google-drive-integration" rel="noopener" target="_blank">', '</a>'),
            'fields'      => [
                'outh_redirect' => [
                    'type' => 'html-viewer',
                    'html' => '<p style="padding: 10px;background: var(--fs-bg-subtle, #222530);border-radius: 5px;">' . sprintf(__('oAuth2 Redirect URL for Your APP: %s', 'fluent-support-pro'), '<code>' . esc_html(self::getRedirectUri()) . '</code>') . '</p>'
                ],
                'client_id'     => [
                    'type'        => 'input-text',
                    'data_type'   => 'text',
                    'label'       => __('Google App Client ID', 'fluent-support-pro'),
                    'placeholder' => __('Google App ID', 'fluent-support-pro'),
                    'help'        => __('Enter Google App Client ID Here', 'fluent-support-pro')
                ],
                'client_secret' => [
                    'type'        => 'input-text',
                    'data_type'   => 'password',
                    'label'       => __('Google App Client Secret', 'fluent-support-pro'),
                    'placeholder' => __('Google App Client Secret', 'fluent-support-pro'),
                    'help'        => __('Enter Google App Client Secret Here', 'fluent-support-pro')
                ],
            ],
            'button_text' => $configured ? __('Save Settings', 'fluent-support-pro') : __('Connect to Google Drive', 'fluent-support-pro'),
            'has_discard' => $configured,
            'last_error'  => Arr::get($all, 'last_error') ?: Arr::get($this->getStatus(), 'last_error'),
            'file_count'  => $this->countFiles(),
        ];

        return [
            'settings'     => $settings,
            'fieldsConfig' => $fieldConfig
        ];
    }

    public function saveSettings($response, $input)
    {
        // Tokens are never accepted from the request; verifyCode() gets them server side.
        if (!empty($input['disconnect']) || empty($input['client_id']) || empty($input['client_secret'])) {
            // Keep the account so files stored there can still be opened.
            $this->archiveCurrentAccount();
            $this->updateSettings(array_merge($this->defaults(), ['status' => 'no']));
            $this->deactivateIfActive();

            return [
                'message'      => __('Google Drive connection has been disconnected', 'fluent-support-pro'),
                'is_discarded' => true
            ];
        }

        $old = $this->getSettings();
        $secret = $input['client_secret'] === self::MASK ? $old['client_secret'] : sanitize_text_field($input['client_secret']);
        $clientId = sanitize_text_field($input['client_id']);

        $isNew = $old['client_id'] !== $clientId || $old['client_secret'] !== $secret;

        $old['client_id'] = $clientId;
        $old['client_secret'] = $secret;

        if ($isNew || !empty($input['do_reconnect']) || $old['status'] !== 'yes' || !empty($old['last_error'])) {
            $this->archiveCurrentAccount();
            $old['status'] = 'no';
            $old['last_error'] = '';
            $old['oauth_start'] = 'yes';
            $this->updateSettings($old);

            $userId = get_current_user_id();
            $state = $userId . '|' . wp_generate_password(40, false);
            set_transient('fluent_support_google_drive_oauth_state_' . $userId, $state, 600);

            $redirect = add_query_arg([
                'client_id'     => rawurlencode($clientId),
                'redirect_uri'  => rawurlencode(self::getRedirectUri()),
                'response_type' => 'code',
                'access_type'   => 'offline',
                'scope'         => rawurlencode('https://www.googleapis.com/auth/drive.file'),
                'prompt'        => 'consent',
                'state'         => rawurlencode($state)
            ], 'https://accounts.google.com/o/oauth2/auth');

            return [
                'message'  => __('Please authorize your Google Drive API', 'fluent-support-pro'),
                'redirect' => $redirect
            ];
        }

        $this->updateSettings($old);

        return [
            'message' => __('Google API settings have been saved', 'fluent-support-pro')
        ];
    }

    public function verifyCode($code)
    {
        $settings = $this->getSettings();

        if (!$code || empty($settings['oauth_start'])) {
            return;
        }

        $response = Http::request('POST', 'https://oauth2.googleapis.com/token', [
            'Content-Type' => 'application/x-www-form-urlencoded'
        ], [
            'code'          => $code,
            'grant_type'    => 'authorization_code',
            'client_id'     => $settings['client_id'],
            'client_secret' => $settings['client_secret'],
            'redirect_uri'  => self::getRedirectUri()
        ], 30);

        $data = $this->decode($response, 'access_token');

        if (is_wp_error($data)) {
            $settings['last_error'] = $data->get_error_message();
            $this->updateSettings($settings);
            return;
        }

        $settings['access_token'] = $data['access_token'];
        $settings['refresh_token'] = Arr::get($data, 'refresh_token', '');
        $settings['expire_at'] = time() + (int) Arr::get($data, 'expires_in', 3600);
        $settings['status'] = 'yes';
        $settings['last_error'] = '';
        $settings['folder_id'] = '';
        unset($settings['oauth_start']);

        $this->updateSettings($settings);

        // Folders of a previous connection may belong to another account.
        Meta::where('object_type', 'ticket_meta')->where('key', '_gdrive_folder_id')->delete();

        $this->afterConnected();
    }
}
