<?php

namespace FluentSupportPro\App\Services\FileUploadIntegration\CloudflareR2;

use FluentSupport\Framework\Support\Arr;
use FluentSupportPro\App\Services\FileUploadIntegration\Support\S3FamilyDriver;

class CloudflareR2Driver extends S3FamilyDriver
{
    public function getKey()
    {
        return 'cloudflare_r2';
    }

    protected function optionKey()
    {
        return 'cloudflare_r2_settings';
    }

    protected function constantPrefix()
    {
        return 'FLUENT_SUPPORT_R2';
    }

    protected function pathScheme()
    {
        return 'r2://';
    }

    protected function legacyObjectKey()
    {
        return 'r2_key';
    }

    protected function defaults()
    {
        return [
            'account_id'        => '',
            'access_key_id'     => '',
            'secret_access_key' => '',
            'bucket_name'       => '',
            'custom_domain'     => '',
            'path_prefix'       => 'fluent-support',
            'status'            => 'no',
            'last_error'        => '',
            'is_encrypted'      => 'no',
        ];
    }

    protected function constantMap()
    {
        return array_merge(parent::constantMap(), [
            'ACCOUNT_ID'    => 'account_id',
            'CUSTOM_DOMAIN' => 'custom_domain',
        ]);
    }

    protected function formFields()
    {
        return ['account_id', 'bucket_name', 'custom_domain', 'path_prefix'];
    }

    protected function requiredFields()
    {
        return ['account_id'];
    }

    protected function endpointFields()
    {
        return ['account_id'];
    }

    protected function connectionFromSettings(array $settings)
    {
        $accountId = preg_replace('/[^A-Za-z0-9]/', '', (string) Arr::get($settings, 'account_id'));

        return [
            'endpoint'   => $accountId ? $accountId . '.r2.cloudflarestorage.com' : '',
            'bucket'     => (string) Arr::get($settings, 'bucket_name'),
            'region'     => 'auto',
            'access_key' => (string) Arr::get($settings, 'access_key_id'),
            'secret_key' => (string) Arr::get($settings, 'secret_access_key'),
            'path_style' => true,
        ];
    }

    protected function applyLegacyLocation(array $conn, array $meta)
    {
        if (!empty($meta['r2_bucket'])) {
            $conn['bucket'] = $meta['r2_bucket'];
        }

        return $conn;
    }

    /**
     * Older Pro stored only the bucket, not the account (the endpoint). Use the first
     * kept connection to that bucket: the account connected when the site upgraded,
     * even after a disconnect or a switch to another account.
     */
    protected function legacyConnection(array $target)
    {
        foreach ($this->storedConnections() as $connection) {
            if (is_array($connection) && Arr::get($connection, 'bucket') === $target['bucket']) {
                return $connection;
            }
        }

        return parent::legacyConnection($target);
    }

    protected function addLegacyLocation(array $meta, array $conn)
    {
        $meta['r2_bucket'] = $conn['bucket'];

        return $meta;
    }

    protected function publicUrl($key, array $settings)
    {
        if (!empty($settings['custom_domain'])) {
            return rtrim($settings['custom_domain'], '/') . '/' . ltrim($key, '/');
        }

        return 'https://' . $settings['bucket_name'] . '.' . $settings['account_id'] . '.r2.dev/' . ltrim($key, '/');
    }

    protected function fieldsConfig(array $settings)
    {
        return [
            'title'       => __('Cloudflare R2 File Upload Settings', 'fluent-support-pro'),
            'description' => sprintf(
                /* translators: %1$s: opening link tag, %2$s: closing link tag */
                __('Please %1$sread the documentation%2$s first to get your R2 credentials. Cloudflare R2 offers S3-compatible storage with zero egress fees.', 'fluent-support-pro'),
                '<a href="https://docs.fluentsupport.com/cloudflare" rel="noopener" target="_blank">',
                '</a>'
            ),
            'fields'      => [
                'account_id'        => [
                    'type'        => 'input-text',
                    'data_type'   => 'text',
                    'label'       => __('Cloudflare Account ID', 'fluent-support-pro'),
                    'placeholder' => __('Your Cloudflare Account ID', 'fluent-support-pro'),
                    'help'        => __('Find this in Cloudflare Dashboard > R2 > Overview', 'fluent-support-pro'),
                ],
                'access_key_id'     => [
                    'type'        => 'input-text',
                    'data_type'   => 'text',
                    'label'       => __('R2 Access Key ID', 'fluent-support-pro'),
                    'placeholder' => __('R2 Access Key ID', 'fluent-support-pro'),
                    'help'        => __('Create an API token in R2 > Manage R2 API Tokens', 'fluent-support-pro'),
                ],
                'secret_access_key' => [
                    'type'        => 'input-text',
                    'data_type'   => 'password',
                    'label'       => __('R2 Secret Access Key', 'fluent-support-pro'),
                    'placeholder' => __('R2 Secret Access Key', 'fluent-support-pro'),
                    'help'        => __('Only shown once when creating the API token', 'fluent-support-pro'),
                ],
                'bucket_name'       => [
                    'type'        => 'input-text',
                    'data_type'   => 'text',
                    'label'       => __('Bucket Name', 'fluent-support-pro'),
                    'placeholder' => __('your-bucket-name', 'fluent-support-pro'),
                    'help'        => __('The R2 bucket to store attachments. Keep it private; files are served through short-lived signed links.', 'fluent-support-pro'),
                ],
                'custom_domain'     => [
                    'type'        => 'input-text',
                    'data_type'   => 'text',
                    'label'       => __('Custom Domain (Optional)', 'fluent-support-pro'),
                    'placeholder' => __('https://files.yourdomain.com', 'fluent-support-pro'),
                    'help'        => __('Optional: Use a custom domain for public URLs', 'fluent-support-pro'),
                ],
                'path_prefix'       => [
                    'type'        => 'input-text',
                    'data_type'   => 'text',
                    'label'       => __('Path Prefix', 'fluent-support-pro'),
                    'placeholder' => __('fluent-support', 'fluent-support-pro'),
                    'help'        => __('Optional: Prefix for all uploaded files (default: fluent-support)', 'fluent-support-pro'),
                ],
            ],
        ];
    }
}
