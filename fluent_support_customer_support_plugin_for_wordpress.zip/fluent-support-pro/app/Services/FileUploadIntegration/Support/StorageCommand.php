<?php

namespace FluentSupportPro\App\Services\FileUploadIntegration\Support;

/**
 * Move ticket attachments between this server and remote storage.
 *
 * ## EXAMPLES
 *
 *     # Copy files stored on this server to Dropbox (see what would happen first)
 *     wp fluent_support storage move-to-remote --driver=dropbox --dry-run
 *     wp fluent_support storage move-to-remote --driver=dropbox
 *
 *     # Bring Amazon S3 files back to this server
 *     wp fluent_support storage move-to-local --driver=amazon_s3
 *
 *     # Remove the public links older versions created on Dropbox files
 *     wp fluent_support storage make-private --driver=dropbox
 */
class StorageCommand
{
    /**
     * Copy attachments stored on this server to remote storage, then remove the local copies.
     *
     * ## OPTIONS
     *
     * --driver=<driver>
     * : amazon_s3, cloudflare_r2, s3_compatible, dropbox or google_drive. Must be connected.
     *
     * [--limit=<number>]
     * : Stop after this many files.
     *
     * [--dry-run]
     * : Only count the files.
     *
     * @subcommand move-to-remote
     */
    public function moveToRemote($args, $assoc)
    {
        $this->runTool('move_to_remote', $assoc);
    }

    /**
     * Copy a driver's attachments back to this server. The remote copies are kept.
     *
     * ## OPTIONS
     *
     * --driver=<driver>
     * : amazon_s3, cloudflare_r2, s3_compatible, dropbox or google_drive. Must be connected.
     *
     * [--limit=<number>]
     * : Stop after this many files.
     *
     * [--dry-run]
     * : Only count the files.
     *
     * @subcommand move-to-local
     */
    public function moveToLocal($args, $assoc)
    {
        $this->runTool('move_to_local', $assoc);
    }

    /**
     * Remove public links older versions created on Dropbox or Google Drive files.
     *
     * Fluent Support Pro 2.4.5 and earlier shared every Dropbox and Drive attachment
     * publicly. The files keep opening from their tickets afterwards.
     *
     * ## OPTIONS
     *
     * --driver=<driver>
     * : dropbox or google_drive. Dropbox needs the sharing.read and sharing.write permissions.
     *
     * [--limit=<number>]
     * : Stop after this many files.
     *
     * [--dry-run]
     * : Only count the files.
     *
     * @subcommand make-private
     */
    public function makePrivate($args, $assoc)
    {
        $this->runTool('make_private', $assoc);
    }

    private function runTool($tool, array $assoc)
    {
        $key = isset($assoc['driver']) ? sanitize_key($assoc['driver']) : '';
        $driver = DriverRegistry::get($key);

        if (!$driver) {
            \WP_CLI::error(sprintf('Unknown driver "%s". Use one of: %s.', $key, implode(', ', array_keys(DriverRegistry::drivers()))));
        }

        if (!$driver->isConfigured()) {
            \WP_CLI::error(sprintf('%s is not connected. Connect it in Fluent Support > Settings > File Upload Integrations first.', $key));
        }

        if ($tool === 'make_private' && !$driver->canRevokePublicLinks()) {
            \WP_CLI::error(sprintf('%s has no public links to remove, or is missing the sharing permissions.', $key));
        }

        $limit = isset($assoc['limit']) ? max(1, (int) $assoc['limit']) : 0;
        $total = StorageTools::query($tool, $key)->count();
        $total = $limit ? min($limit, $total) : $total;

        if (!empty($assoc['dry-run'])) {
            \WP_CLI::success(sprintf('%d file(s) would be processed.', $total));
            return;
        }

        if (!$total) {
            \WP_CLI::success('Nothing to do.');
            return;
        }

        $progress = \WP_CLI\Utils\make_progress_bar('Processing files', $total);
        $done = 0;
        $failed = 0;
        $lastId = 0;

        while ($done + $failed < $total) {
            $rows = StorageTools::query($tool, $key, $lastId)->limit(min(50, $total - $done - $failed))->get();

            if ($rows->isEmpty()) {
                break;
            }

            foreach ($rows as $attachment) {
                $lastId = (int) $attachment->id;
                $result = StorageTools::run($tool, $driver, $attachment);

                if (is_wp_error($result)) {
                    $failed++;
                    \WP_CLI::warning(sprintf('#%d %s: %s', $attachment->id, $attachment->title, $result->get_error_message()));
                } else {
                    $done++;
                }

                $progress->tick();
            }
        }

        $progress->finish();

        $message = sprintf('%d file(s) processed, %d failed.', $done, $failed);
        $failed ? \WP_CLI::warning($message) : \WP_CLI::success($message);
    }
}
