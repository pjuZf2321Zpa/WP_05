<?php

namespace FluentSupportPro\App\Services\FileUploadIntegration\Support;

use FluentSupport\App\Services\Helper;
use FluentSupport\Framework\Support\Arr;
use FluentSupportPro\App\Services\ProHelper;

/**
 * Base for the Pro storage drivers.
 *
 * A driver works with both versions of the free plugin:
 *  - A free plugin with StorageDriverInterface calls it through RegistryDriver.
 *  - An older free plugin fires the per-driver hooks, which register() always
 *    listens to. The newer free plugin never fires those hooks for a registered
 *    driver, so a file is never uploaded twice.
 */
abstract class BaseDriver
{
    /**
     * @return string Value stored in fs_attachments.driver.
     */
    abstract public function getKey();

    /**
     * @return string fs_meta integration_settings key.
     */
    abstract protected function optionKey();

    /**
     * @return array
     */
    abstract protected function defaults();

    abstract public function isConfigured();

    /**
     * @return true|\WP_Error On success the row is updated and saved.
     */
    abstract public function upload($attachment, $ticketId);

    /**
     * @return true|\WP_Error
     */
    abstract public function delete($attachment);

    /**
     * @return string|null|\WP_Error null means stream().
     */
    abstract public function getDownloadUrl($attachment);

    /**
     * @return string|\WP_Error
     */
    abstract public function getLocalCopy($attachment, $maxBytes = 0);

    abstract public function getSettingsAndFields($data);

    abstract public function saveSettings($response, $settings);

    /**
     * Settings fields kept encrypted at rest. `is_encrypted` covers the fields every
     * Pro version has encrypted; fields added later carry their own flag
     * ("{field}_encrypted") so older stored values still read correctly.
     *
     * @return array field => flag key ('is_encrypted' or '{field}_encrypted')
     */
    protected function encryptedFields()
    {
        return [];
    }

    public function register()
    {
        add_action('fluent_support/attachment_uploaded_as_temp_' . $this->getKey(), [$this, 'handleLegacyUpload'], 10, 2);
        add_action('fluent_support/finalize_file_upload_' . $this->getKey(), [$this, 'handleLegacyUpload'], 10, 2);
        add_action('fluent_support/delete_remote_attachment_' . $this->getKey(), [$this, 'handleLegacyDelete'], 10, 1);
        add_filter('fluent_support/external_attachment_url', [$this, 'filterLegacyUrl'], 10, 2);

        add_filter('fluent_support_pro/file_storage_integration_settings_' . $this->settingsKey(), [$this, 'getSettingsAndFields']);
        add_filter('fluent_support_pro/file_storage_integration_settings_save_' . $this->settingsKey(), [$this, 'saveSettings'], 10, 2);
    }

    /**
     * Key used by the settings REST endpoint (integration_key).
     */
    public function settingsKey()
    {
        return $this->getKey();
    }

    public function handleLegacyUpload($attachment, $ticketId)
    {
        if ($attachment->driver !== 'local' || !$ticketId || !file_exists((string) $attachment->file_path)) {
            return;
        }

        $result = $this->upload($attachment, $ticketId);

        if (is_wp_error($result)) {
            $this->setLastError($result->get_error_message());
        } else {
            $this->clearLastError();
        }
    }

    /**
     * Older free plugin: it deletes right away and has no shared-file check, so keep
     * an object another row still points at.
     */
    public function handleLegacyDelete($attachment)
    {
        if ($attachment->driver !== $this->getKey() || !$attachment->file_path) {
            return;
        }

        $stillUsed = \FluentSupport\App\Models\Attachment::where('file_path', $attachment->file_path)
            ->where('id', '!=', (int) $attachment->id)
            ->exists();

        if (!$stillUsed) {
            $this->delete($attachment);
        }
    }

    /**
     * Older free plugin: return the download URL, or stream the file and exit.
     */
    public function filterLegacyUrl($url, $attachment)
    {
        if ($attachment->driver !== $this->getKey()) {
            return $url;
        }

        $downloadUrl = $this->getDownloadUrl($attachment);

        if ($downloadUrl === null) {
            $this->stream($attachment);
            return '';
        }

        return is_wp_error($downloadUrl) ? '' : $downloadUrl;
    }

    /**
     * Send the file to the browser and exit. Drivers without a direct URL override this.
     *
     * @return \WP_Error
     */
    public function stream($attachment)
    {
        $path = $this->getLocalCopy($attachment);

        if (is_wp_error($path)) {
            return $path;
        }

        // Finish and clean up even if the visitor goes away.
        ignore_user_abort(true);
        while (ob_get_level() > 0) {
            ob_end_clean();
        }

        nocache_headers();
        header('Content-Type: ' . ($attachment->file_type ?: 'application/octet-stream'));
        header('Content-Disposition: inline; filename="' . str_replace(['"', "\r", "\n"], '', (string) $attachment->title) . '"');
        header('Content-Length: ' . filesize($path));
        header('X-Content-Type-Options: nosniff');

        readfile($path); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_readfile
        Http::removeTemp($path);
        exit();
    }

    /**
     * A problem the admin has to fix outside Fluent Support, shown on the storage card.
     *
     * @return array ['message' => string, 'help_url' => string] or [] when all is well.
     */
    public function getSetupIssue()
    {
        return [];
    }

    /**
     * Drivers that created public links in older versions override both methods.
     */
    public function canRevokePublicLinks()
    {
        return false;
    }

    /**
     * @return true|\WP_Error
     */
    public function revokePublicLinks($attachment)
    {
        return new \WP_Error('not_supported', 'This storage has no public links to revoke.');
    }

    /**
     * Upload/delete errors live in their own option ({option}_health), so a failing
     * upload never rewrites the settings (and their credentials).
     */
    public function getStatus()
    {
        $health = Helper::getIntegrationOption($this->optionKey() . '_health', []);

        return [
            'last_error'     => (string) Arr::get((array) $health, 'last_error', ''),
            'failed_uploads' => 0,
        ];
    }

    public function getSettings()
    {
        $stored = Helper::getIntegrationOption($this->optionKey(), []);
        $settings = wp_parse_args(is_array($stored) ? $stored : [], $this->defaults());

        foreach ($this->encryptedFields() as $field => $flag) {
            if (!empty($settings[$field]) && Arr::get($settings, $flag) === 'yes') {
                $decrypted = ProHelper::decryptKey($settings[$field]);
                $settings[$field] = $decrypted === false ? '' : $decrypted;
            }
        }

        return $settings;
    }

    /**
     * @param array $settings Plain values.
     */
    public function updateSettings($settings)
    {
        $flags = [];

        foreach ($this->encryptedFields() as $field => $flag) {
            $flags[$flag] = isset($flags[$flag]) ? $flags[$flag] : 'yes';

            if (empty($settings[$field])) {
                continue;
            }

            $encrypted = ProHelper::encryptKey($settings[$field]);

            // No openssl: keep it readable rather than losing it.
            if ($encrypted === false) {
                $flags[$flag] = 'no';
                continue;
            }

            $settings[$field] = $encrypted;
        }

        foreach ($flags as $flag => $value) {
            $settings[$flag] = $value;
        }

        Helper::updateIntegrationOption($this->optionKey(), $settings);
    }

    public function setLastError($message)
    {
        Helper::updateIntegrationOption($this->optionKey() . '_health', [
            'last_error' => sanitize_text_field((string) $message),
            'at'         => time(),
        ]);
    }

    public function clearLastError()
    {
        $health = Helper::getIntegrationOption($this->optionKey() . '_health', []);

        if (!empty($health['last_error'])) {
            Helper::updateIntegrationOption($this->optionKey() . '_health', []);
        }
    }

    /**
     * After a successful connect or save: clear the old error and send files that
     * couldn't be uploaded earlier again (free 2.4.7+ only).
     */
    protected function afterConnected()
    {
        $this->clearLastError();

        if (class_exists('\FluentSupport\App\Services\Storage\StorageManager')
            && method_exists('\FluentSupport\App\Services\Storage\StorageManager', 'retryFailed')) {
            \FluentSupport\App\Services\Storage\StorageManager::retryFailed($this->getKey());
        }
    }

    /**
     * Forget this driver as the active one (after a disconnect).
     */
    protected function deactivateIfActive()
    {
        if (Helper::getOption('file_upload_driver') === $this->getKey()) {
            Helper::updateOption('file_upload_driver', 'local');
        }
    }

    /**
     * How many attachments are stored with this driver.
     *
     * @return int
     */
    public function countFiles()
    {
        return \FluentSupport\App\Models\Attachment::where('driver', $this->getKey())->count();
    }

    protected function attachmentSettings($attachment)
    {
        $settings = $attachment->settings;

        return is_array($settings) ? $settings : [];
    }

    /**
     * 'fs-<random>___name', so object names can't be guessed.
     */
    protected function uniqueFileName($title)
    {
        return 'fs-' . md5(uniqid(bin2hex(random_bytes(4)), true)) . '___' . sanitize_file_name((string) $title);
    }
}
