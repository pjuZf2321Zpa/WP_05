<?php

namespace FluentSupportPro\App\Services\FileUploadIntegration\Support;

use FluentSupport\App\Models\Attachment;
use FluentSupport\App\Services\Includes\UploadService;
use FluentSupport\Framework\Support\Arr;

/**
 * Bulk operations on stored attachments, run from WP-CLI (StorageCommand):
 *  - move_to_remote: copy local files to a remote driver, then remove the local copy
 *  - move_to_local:  bring a driver's files back to this server (remote copies kept)
 *  - make_private:   remove public links Pro 2.4.5 and earlier created (Dropbox, Drive)
 *
 * Rows of deleted tickets (status 'deleting', no ticket) are never touched.
 */
class StorageTools
{
    /**
     * @param string $tool
     * @param string $driverKey
     * @param int $afterId
     * @return \FluentSupport\Framework\Database\Orm\Builder
     */
    public static function query($tool, $driverKey, $afterId = 0)
    {
        $query = Attachment::where('id', '>', (int) $afterId)
            ->where('status', '!=', 'deleting')
            ->whereNotNull('ticket_id')
            ->orderBy('id', 'ASC');

        if ($tool === 'move_to_remote') {
            return $query->where('driver', 'local')
                ->whereIn('status', ['active', 'inline']);
        }

        return $query->where('driver', $driverKey);
    }

    /**
     * @return true|\WP_Error
     */
    public static function run($tool, BaseDriver $driver, $attachment)
    {
        if ($tool === 'make_private') {
            if (Arr::get((array) $attachment->settings, 'private') === 'yes') {
                return true;
            }
            return $driver->revokePublicLinks($attachment);
        }

        if ($tool === 'move_to_remote') {
            $localPath = (string) $attachment->file_path;

            if (!file_exists($localPath)) {
                return new \WP_Error('file_not_found', sprintf(__('File missing on this server: %s', 'fluent-support-pro'), $attachment->title));
            }

            $result = $driver->upload($attachment, $attachment->ticket_id);

            if (!is_wp_error($result) && !Attachment::where('file_path', $localPath)->exists()) {
                wp_delete_file($localPath);
            }

            return $result;
        }

        // move_to_local
        $tempPath = $driver->getLocalCopy($attachment);
        if (is_wp_error($tempPath)) {
            return $tempPath;
        }

        $named = dirname($tempPath) . '/' . 'fs-' . wp_generate_password(16, false) . '___' . basename($tempPath);
        @rename($tempPath, $named);

        $fileInfo = UploadService::copyFileTicketFolder($named, $attachment->ticket_id);
        Http::removeTemp($named);

        if (!$fileInfo || empty($fileInfo['file_path'])) {
            return new \WP_Error('copy_failed', __('Could not save the file on this server.', 'fluent-support-pro'));
        }

        $meta = (array) $attachment->settings;
        $meta['moved_from'] = $driver->getKey();
        $meta['moved_from_path'] = $attachment->file_path;

        $attachment->settings = $meta;
        $attachment->file_path = $fileInfo['file_path'];
        $attachment->full_url = $fileInfo['url'];
        $attachment->driver = 'local';
        $attachment->save();

        return true;
    }
}
