<?php

namespace FluentSupportPro\App\Services\FileUploadIntegration\Support;

use FluentSupport\App\Services\Storage\StorageDriverInterface;

/**
 * Hands a Pro driver to the free plugin's storage registry.
 *
 * Only loaded when the free plugin has StorageDriverInterface (2.4.7+); see
 * DriverRegistry::boot(). Keep it free of logic so older free versions never need it.
 */
class RegistryDriver implements StorageDriverInterface
{
    /**
     * @var BaseDriver
     */
    private $driver;

    public function __construct(BaseDriver $driver)
    {
        $this->driver = $driver;
    }

    public function getKey()
    {
        return $this->driver->getKey();
    }

    public function isConfigured()
    {
        return $this->driver->isConfigured();
    }

    public function upload($attachment, $ticketId)
    {
        $result = $this->driver->upload($attachment, $ticketId);

        if (is_wp_error($result)) {
            $this->driver->setLastError($result->get_error_message());
        } else {
            $this->driver->clearLastError();
        }

        return $result;
    }

    public function delete($attachment)
    {
        return $this->driver->delete($attachment);
    }

    public function getDownloadUrl($attachment)
    {
        return $this->driver->getDownloadUrl($attachment);
    }

    public function stream($attachment)
    {
        return $this->driver->stream($attachment);
    }

    public function getLocalCopy($attachment, $maxBytes = 0)
    {
        return $this->driver->getLocalCopy($attachment, $maxBytes);
    }

    public function getStatus()
    {
        return $this->driver->getStatus();
    }
}
