<?php

namespace FluentSupportPro\App\Services\FileUploadIntegration\Support;

use FluentSupportPro\App\Services\FileUploadIntegration\AmazonS3\AmazonS3Driver;
use FluentSupportPro\App\Services\FileUploadIntegration\CloudflareR2\CloudflareR2Driver;
use FluentSupportPro\App\Services\FileUploadIntegration\Dropbox\DropboxDriver;
use FluentSupportPro\App\Services\FileUploadIntegration\GoogleDrive\GoogleDriveDriver;
use FluentSupportPro\App\Services\FileUploadIntegration\S3Compatible\S3CompatibleDriver;

/**
 * Boots the storage drivers for whichever free plugin version is installed.
 */
class DriverRegistry
{
    /**
     * @var BaseDriver[]|null
     */
    private static $drivers = null;

    /**
     * @return BaseDriver[] keyed by driver key
     */
    public static function drivers()
    {
        if (self::$drivers === null) {
            self::$drivers = [];
            foreach ([new AmazonS3Driver(), new CloudflareR2Driver(), new S3CompatibleDriver(), new DropboxDriver(), new GoogleDriveDriver()] as $driver) {
                self::$drivers[$driver->getKey()] = $driver;
            }
        }

        return self::$drivers;
    }

    /**
     * @return BaseDriver|null
     */
    public static function get($key)
    {
        $drivers = self::drivers();

        return isset($drivers[$key]) ? $drivers[$key] : null;
    }

    public static function freeHasRegistry()
    {
        return interface_exists('\FluentSupport\App\Services\Storage\StorageDriverInterface');
    }

    public static function boot()
    {
        // Always listen to the per-driver hooks: an older free plugin only fires those,
        // and the newer one never fires them for a driver in its registry.
        foreach (self::drivers() as $driver) {
            $driver->register();
        }

        if (self::freeHasRegistry()) {
            add_filter('fluent_support/storage_drivers', function ($drivers) {
                foreach (self::drivers() as $key => $driver) {
                    $drivers[$key] = new RegistryDriver($driver);
                }
                return $drivers;
            });
        } else {
            add_filter('fluent_support/dashboard_notice', [__CLASS__, 'oldFreeNotice'], 120);
        }

        add_filter('fluent_support/storage_drivers_info', [__CLASS__, 'driversInfo']);

        if (defined('WP_CLI') && WP_CLI) {
            \WP_CLI::add_command('fluent_support storage', StorageCommand::class);
        }
    }

    /**
     * Pro decides whether its drivers are connected, and adds the S3-compatible card,
     * on every free version.
     */
    public static function driversInfo($info)
    {
        foreach (self::drivers() as $key => $driver) {
            if (!isset($info[$key]) && $key === 's3_compatible') {
                $info[$key] = [
                    'meta_key'    => 's3_compatible_settings',
                    'title'       => __('S3-Compatible Storage', 'fluent-support-pro'),
                    'has_config'  => true,
                    'require_pro' => false,
                    'description' => __('DigitalOcean Spaces, Wasabi, Backblaze B2, MinIO and other S3-compatible services.', 'fluent-support-pro'),
                    'icon'        => isset($info['amazon_s3']['icon']) ? $info['amazon_s3']['icon'] : '',
                ];
            }

            if (!isset($info[$key])) {
                continue;
            }

            $info[$key]['is_configured'] = $driver->isConfigured();
            $info[$key]['setup_issue'] = $driver->getSetupIssue();
        }

        return $info;
    }

    public static function oldFreeNotice($messages)
    {
        if (!\FluentSupport\App\Modules\PermissionManager::currentUserCan('fst_manage_settings')
            || \FluentSupport\App\Services\Helper::getUploadDriverKey() === 'local') {
            return $messages;
        }

        $html = '<div class="fs_alert_notification fs_alert_warning" style="border-radius: 8px; margin-bottom: 24px; max-width: 1360px; margin-left: auto; margin-right: auto;">
            <div style="display: flex; gap: 8px; align-items: center; padding: 8px 8px 8px 16px;">
                <p class="fs_alert_text">' . esc_html__('Please update Fluent Support to the latest version. Background uploads and the storage health check need it.', 'fluent-support-pro') . '</p>
            </div>
        </div>';

        return $messages . $html;
    }
}
