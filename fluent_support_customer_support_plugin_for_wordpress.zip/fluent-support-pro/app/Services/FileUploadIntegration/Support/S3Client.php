<?php

namespace FluentSupportPro\App\Services\FileUploadIntegration\Support;

/**
 * Minimal S3 API client: put, delete, check bucket, presign, download.
 * Works with Amazon S3 and S3-compatible services.
 */
class S3Client
{
    /**
     * S3 never needs a redirect (a wrong region comes back as an error to read), and
     * following one would let the storage host send this server elsewhere.
     */
    const NO_REDIRECTS = ['redirection' => 0];

    /**
     * @var array
     */
    private $conn;

    /**
     * @param array $conn endpoint (host only, e.g. s3.eu-west-1.amazonaws.com), bucket, region,
     *                    access_key, secret_key, path_style (bool), host_check (optional
     *                    callable: request host => error message, or '' when allowed)
     */
    public function __construct(array $conn)
    {
        $endpoint = preg_replace('#^https?://#i', '', trim((string) ($conn['endpoint'] ?? '')));
        // The Host header omits the default port; the signature must too.
        $endpoint = preg_replace('/:443$/', '', rtrim($endpoint, '/'));

        $this->conn = [
            'endpoint'   => $endpoint,
            'bucket'     => (string) ($conn['bucket'] ?? ''),
            'region'     => (string) (($conn['region'] ?? '') ?: 'us-east-1'),
            'access_key' => (string) ($conn['access_key'] ?? ''),
            'secret_key' => (string) ($conn['secret_key'] ?? ''),
            // Dots break the TLS certificate of a virtual-hosted URL; capitals and
            // underscores (older buckets) aren't valid in a host name.
            'path_style' => !empty($conn['path_style']) || !preg_match('/^[a-z0-9][a-z0-9\-]*[a-z0-9]$/', (string) ($conn['bucket'] ?? '')),
            'host_check' => isset($conn['host_check']) && is_callable($conn['host_check']) ? $conn['host_check'] : null,
        ];
    }

    /**
     * Run the host check on the host this server actually calls (bucket.endpoint in
     * virtual-host mode), each time, so a wildcard or changed DNS record can't point
     * a request at a private address.
     *
     * @return \WP_Error|null
     */
    private function hostError()
    {
        if (!$this->conn['host_check']) {
            return null;
        }

        $message = (string) call_user_func($this->conn['host_check'], $this->host());

        return $message ? new \WP_Error('endpoint_not_allowed', $message) : null;
    }

    public function getRegion()
    {
        return $this->conn['region'];
    }

    private function host()
    {
        return $this->conn['path_style'] ? $this->conn['endpoint'] : $this->conn['bucket'] . '.' . $this->conn['endpoint'];
    }

    private function path($key = '')
    {
        $path = $key === '' ? '/' : SigV4::encodePath($key);

        if ($this->conn['path_style']) {
            return '/' . rawurlencode($this->conn['bucket']) . ($key === '' ? '' : $path);
        }

        return $path;
    }

    private function url($path, array $query = [])
    {
        $url = 'https://' . $this->host() . $path;

        return $query ? $url . '?' . SigV4::canonicalQuery($query) : $url;
    }

    private function signedHeaders($method, $path, array $query, $payloadHash)
    {
        return SigV4::headers(
            $method,
            $this->host(),
            $path,
            $query,
            $payloadHash,
            $this->conn['access_key'],
            $this->conn['secret_key'],
            $this->conn['region']
        );
    }

    /**
     * @return true|\WP_Error
     */
    public function put($localPath, $key, $contentType = '')
    {
        if (!file_exists($localPath)) {
            return new \WP_Error('file_not_found', __('File not found for upload.', 'fluent-support-pro'));
        }

        $error = $this->hostError();
        if ($error) {
            return $error;
        }

        $path = $this->path($key);
        $headers = $this->signedHeaders('PUT', $path, [], hash_file('sha256', $localPath));
        $headers['Content-Type'] = $contentType ?: 'application/octet-stream';

        $response = Http::sendFile('PUT', $this->url($path), $headers, $localPath, 300, self::NO_REDIRECTS);

        if (is_wp_error($response)) {
            return $response;
        }

        if ($response['code'] >= 200 && $response['code'] < 300) {
            return true;
        }

        return new \WP_Error('upload_failed', $this->errorMessage($response, __('Upload failed', 'fluent-support-pro')));
    }

    /**
     * @return true|\WP_Error A missing object counts as deleted.
     */
    public function delete($key)
    {
        $error = $this->hostError();
        if ($error) {
            return $error;
        }

        $path = $this->path($key);
        $headers = $this->signedHeaders('DELETE', $path, [], hash('sha256', ''));
        $response = Http::request('DELETE', $this->url($path), $headers, null, 30, self::NO_REDIRECTS);

        if (is_wp_error($response)) {
            return $response;
        }

        if (in_array($response['code'], [200, 204, 404], true)) {
            return true;
        }

        return new \WP_Error('delete_failed', $this->errorMessage($response, __('Delete failed', 'fluent-support-pro')));
    }

    /**
     * Check the credentials can list the bucket.
     *
     * @return true|\WP_Error On a region mismatch the error data holds ['region' => detected].
     */
    public function verify()
    {
        $error = $this->hostError();
        if ($error) {
            return $error;
        }

        $query = ['list-type' => '2', 'max-keys' => '1'];
        $path = $this->path();
        $headers = $this->signedHeaders('GET', $path, $query, hash('sha256', ''));
        $response = Http::request('GET', $this->url($path, $query), $headers, null, 30, self::NO_REDIRECTS);

        if (is_wp_error($response)) {
            return $response;
        }

        if ($response['code'] >= 200 && $response['code'] < 300) {
            return true;
        }

        $headersList = $response['headers'];
        $detected = '';
        if (is_object($headersList) && method_exists($headersList, 'offsetGet')) {
            $detected = (string) $headersList['x-amz-bucket-region'];
        } elseif (is_array($headersList)) {
            $detected = (string) ($headersList['x-amz-bucket-region'] ?? '');
        }

        if (!$detected) {
            $xml = $this->parseXml($response['body']);
            if ($xml && isset($xml->Region)) {
                $detected = (string) $xml->Region;
            }
        }

        // Amazon answers a wrong region with 301 or 400 and names the right one.
        if ($detected && $detected !== $this->conn['region'] && in_array($response['code'], [301, 400], true)) {
            return new \WP_Error('wrong_region', sprintf(__('The bucket is in region %s.', 'fluent-support-pro'), $detected), ['region' => $detected]);
        }

        $xml = $this->parseXml($response['body']);
        if ($xml && (string) $xml->Code === 'NoSuchBucket') {
            return new \WP_Error('bucket_not_found', sprintf(__('Bucket (%s) does not exist.', 'fluent-support-pro'), $this->conn['bucket']));
        }

        if ($response['code'] == 403 && !($xml && (string) $xml->Message)) {
            return new \WP_Error('access_denied', sprintf(__('Access denied to bucket (%s). Check your credentials and permissions.', 'fluent-support-pro'), $this->conn['bucket']));
        }

        return new \WP_Error('connection_failed', $this->errorMessage($response, __('Could not connect to the storage.', 'fluent-support-pro')));
    }

    /**
     * @param string $key
     * @param int $expires Seconds.
     * @param string $fileName Shown to the browser.
     * @return string
     */
    public function presignedUrl($key, $expires = 300, $fileName = '')
    {
        $path = $this->path($key);
        $extra = [];

        if ($fileName) {
            $ascii = preg_replace('/[^\x20-\x7E]|["\\\\]/', '_', $fileName);
            $extra['response-content-disposition'] = 'inline; filename="' . $ascii . '"; filename*=UTF-8\'\'' . rawurlencode($fileName);
        }

        $query = SigV4::presignQuery(
            $this->host(),
            $path,
            $this->conn['access_key'],
            $this->conn['secret_key'],
            $this->conn['region'],
            $expires,
            $extra
        );

        return 'https://' . $this->host() . $path . '?' . $query;
    }

    /**
     * @return true|\WP_Error
     */
    public function download($key, $toPath, $maxBytes = 0)
    {
        $error = $this->hostError();
        if ($error) {
            return $error;
        }

        return Http::downloadTo($this->presignedUrl($key, 600), [], $toPath, 300, $maxBytes, self::NO_REDIRECTS);
    }

    private function parseXml($body)
    {
        if (!$body || strpos(ltrim($body), '<') !== 0) {
            return null;
        }

        $previous = libxml_use_internal_errors(true);
        $xml = simplexml_load_string($body);
        libxml_use_internal_errors($previous);

        return $xml ?: null;
    }

    private function errorMessage(array $response, $fallback)
    {
        $xml = $this->parseXml($response['body']);

        if ($xml && (string) $xml->Message) {
            return (string) $xml->Message;
        }

        return sprintf('%s (HTTP %d)', $fallback, $response['code']);
    }
}
