<?php

namespace FluentSupportPro\App\Services\FileUploadIntegration\Support;

use FluentSupport\App\Services\Helper;
use FluentSupport\Framework\Support\Arr;
use FluentSupportPro\App\Services\ProHelper;

/**
 * Accounts for OAuth storage (Dropbox, Google Drive).
 *
 * Each upload records the account it went to (`storage_conn`). When the admin
 * disconnects or connects another account, the previous account's tokens are kept
 * (encrypted, in `{option}_accounts`), so files stored there can still be opened,
 * emailed and deleted. Files from before accounts were recorded use the current one.
 */
trait OAuthAccounts
{
    /**
     * @return string Token endpoint for the refresh_token grant.
     */
    abstract protected function tokenEndpoint();

    /**
     * @return int Default token lifetime in seconds when the response has none.
     */
    abstract protected function defaultTokenLifetime();

    protected function accountKeyFrom(array $settings)
    {
        if (!empty($settings['account_id'])) {
            return 'a_' . substr(md5((string) $settings['account_id']), 0, 12);
        }

        if (empty($settings['refresh_token'])) {
            return '';
        }

        return 'r_' . substr(md5($settings['client_id'] . '|' . $settings['refresh_token']), 0, 12);
    }

    public function currentAccountKey()
    {
        $settings = $this->getSettings();

        return $settings['status'] === 'yes' ? $this->accountKeyFrom($settings) : '';
    }

    private function accountFields()
    {
        return ['access_token', 'refresh_token', 'expire_at', 'client_id', 'client_secret', 'account_id', 'folder_id'];
    }

    protected function storedAccounts()
    {
        $accounts = Helper::getIntegrationOption($this->optionKey() . '_accounts', []);

        return is_array($accounts) ? $accounts : [];
    }

    private function saveAccount($key, array $settings)
    {
        $record = Arr::only($settings, $this->accountFields());

        foreach (['access_token', 'refresh_token', 'client_secret'] as $field) {
            if (!empty($record[$field])) {
                $encrypted = ProHelper::encryptKey($record[$field]);
                if ($encrypted !== false) {
                    $record[$field] = $encrypted;
                    $record[$field . '_enc'] = 'yes';
                }
            }
        }

        $accounts = $this->storedAccounts();
        $accounts[$key] = $record;

        // Files from before accounts were recorded belong to the first account kept.
        if (empty($accounts['_legacy'])) {
            $accounts['_legacy'] = $key;
        }

        Helper::updateIntegrationOption($this->optionKey() . '_accounts', $accounts);
    }

    private function loadAccount($key)
    {
        $record = Arr::get($this->storedAccounts(), $key);

        if (!$record || !is_array($record)) {
            return null;
        }

        foreach (['access_token', 'refresh_token', 'client_secret'] as $field) {
            if (!empty($record[$field]) && Arr::get($record, $field . '_enc') === 'yes') {
                $decrypted = ProHelper::decryptKey($record[$field]);
                $record[$field] = $decrypted === false ? '' : $decrypted;
            }
        }

        $record['status'] = 'yes';

        return $record;
    }

    /**
     * Keep the connected account before it is replaced or disconnected.
     */
    public function archiveCurrentAccount()
    {
        $settings = $this->getSettings();
        $key = $this->accountKeyFrom($settings);

        if ($settings['status'] === 'yes' && $key && !empty($settings['refresh_token'])) {
            $this->saveAccount($key, $settings);
        }
    }

    /**
     * The account settings that hold this file, and which record they came from.
     *
     * @return array [array $settings, string $key] $key is '' for the current settings.
     */
    protected function accountFor($attachment = null)
    {
        $current = $this->getSettings();
        $key = $attachment ? (string) Arr::get($this->attachmentSettings($attachment), 'storage_conn') : '';

        // A file from before accounts were recorded: the account connected back then
        // (kept once it is replaced or disconnected), else the current account.
        if (!$key && $attachment) {
            $key = (string) Arr::get($this->storedAccounts(), '_legacy', '');
        }

        if (!$key || ($current['status'] === 'yes' && $this->accountKeyFrom($current) === $key)) {
            return [$current, ''];
        }

        $stored = $this->loadAccount($key);

        return $stored ? [$stored, $key] : [$current, ''];
    }

    /**
     * Access token for the account that holds $attachment (or the current account).
     *
     * @return string|\WP_Error
     */
    public function getAccessToken($attachment = null)
    {
        list($settings, $key) = $this->accountFor($attachment);

        $token = $this->tokenFor($settings, $key);

        // A kept account that no longer works: try the current one. Google has no
        // account id, so reconnecting the same Google account looks like a new
        // account whose old refresh token may have expired.
        if (is_wp_error($token) && $key) {
            $current = $this->getSettings();
            if ($current['status'] === 'yes') {
                return $this->tokenFor($current, '');
            }
        }

        return $token;
    }

    /**
     * @param array $settings Account settings.
     * @param string $key The kept account's key, '' for the current settings.
     * @return string|\WP_Error
     */
    private function tokenFor(array $settings, $key)
    {
        if (empty($settings['access_token']) || $settings['status'] !== 'yes') {
            return new \WP_Error('no_access_token', __('The storage account for this file is not connected.', 'fluent-support-pro'));
        }

        if ((int) $settings['expire_at'] - time() > 60 || empty($settings['refresh_token'])) {
            return $settings['access_token'];
        }

        $response = Http::request('POST', $this->tokenEndpoint(), [
            'Content-Type' => 'application/x-www-form-urlencoded'
        ], [
            'refresh_token' => $settings['refresh_token'],
            'grant_type'    => 'refresh_token',
            'client_id'     => $settings['client_id'],
            'client_secret' => $settings['client_secret'],
        ], 30);

        $data = $this->decode($response, 'access_token');

        if (is_wp_error($data)) {
            // Keep the stored token; the next request or the cron retries.
            if (!$key) {
                $this->setLastError($data->get_error_message());
            }
            return $data;
        }

        $settings['access_token'] = $data['access_token'];
        $settings['expire_at'] = time() + (int) Arr::get($data, 'expires_in', $this->defaultTokenLifetime());

        if ($key) {
            $this->saveAccount($key, $settings);
        } else {
            // Re-read so a concurrent settings change isn't overwritten with stale values.
            $fresh = $this->getSettings();
            if ($this->accountKeyFrom($fresh) === $this->accountKeyFrom($settings)) {
                $fresh['access_token'] = $settings['access_token'];
                $fresh['expire_at'] = $settings['expire_at'];
                $this->updateSettings($fresh);
            }
        }

        return $settings['access_token'];
    }

    /**
     * Files Pro 2.4.5 shared publicly keep their public link as a fallback until
     * the "make old public links private" tool has run.
     *
     * @return string
     */
    protected function legacyPublicUrl($attachment)
    {
        $meta = $this->attachmentSettings($attachment);

        if (Arr::get($meta, 'private') === 'yes') {
            return '';
        }

        $url = (string) $attachment->full_url;

        return wp_http_validate_url($url) ? $url : '';
    }
}
