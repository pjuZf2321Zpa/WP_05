<?php

namespace FluentSupportPro\App\Services\FileUploadIntegration\Support;

use FluentSupport\App\Services\Helper;
use FluentSupport\Framework\Support\Arr;
use FluentSupportPro\App\Services\ProHelper;

/**
 * Shared logic for S3-API storage: Amazon S3, Cloudflare R2 and other S3-compatible services.
 *
 * Every uploaded file records which connection (endpoint + bucket + key) holds it, and
 * past connections are kept, so files keep working after the bucket, region or keys
 * change, or after a disconnect.
 *
 * Settings can come from wp-config constants ({PREFIX}_ACCESS_KEY, ...). While they
 * are defined the settings form is read-only.
 */
abstract class S3FamilyDriver extends BaseDriver
{
    const MASK = '********';

    /**
     * @return string e.g. 'FLUENT_SUPPORT_S3'
     */
    abstract protected function constantPrefix();

    /**
     * @return string e.g. 's3://'
     */
    abstract protected function pathScheme();

    /**
     * @return string Settings key that older Pro versions read the object key from.
     */
    abstract protected function legacyObjectKey();

    /**
     * Connection for the current settings.
     *
     * @return array endpoint, bucket, region, access_key, secret_key, path_style
     */
    abstract protected function connectionFromSettings(array $settings);

    /**
     * Public URL stored in full_url. Not used for downloads (they are presigned).
     */
    abstract protected function publicUrl($key, array $settings);

    /**
     * Fields that, when changed, point the saved secret at a different server.
     *
     * @return string[]
     */
    protected function endpointFields()
    {
        return [];
    }

    /**
     * Driver-specific fields saved from the form (besides the keys).
     *
     * @return string[]
     */
    abstract protected function formFields();

    /**
     * @return array Field config for the settings form.
     */
    abstract protected function fieldsConfig(array $settings);

    protected function encryptedFields()
    {
        return [
            'access_key_id'     => 'is_encrypted',
            'secret_access_key' => 'is_encrypted',
        ];
    }

    /**
     * Map of wp-config constant suffix => settings field.
     */
    protected function constantMap()
    {
        return [
            'ACCESS_KEY'  => 'access_key_id',
            'SECRET_KEY'  => 'secret_access_key',
            'BUCKET'      => 'bucket_name',
            'PATH_PREFIX' => 'path_prefix',
        ];
    }

    public function usesConstants()
    {
        return defined($this->constantPrefix() . '_ACCESS_KEY');
    }

    public function getSettings()
    {
        $settings = parent::getSettings();

        if ($this->usesConstants()) {
            foreach ($this->constantMap() as $suffix => $field) {
                $name = $this->constantPrefix() . '_' . $suffix;
                if (defined($name)) {
                    $settings[$field] = constant($name);
                }
            }
            $settings['status'] = 'yes';
        }

        return $settings;
    }

    public function isConfigured()
    {
        $settings = $this->getSettings();
        $conn = $this->connectionFromSettings($settings);

        return $settings['status'] === 'yes'
            && $conn['endpoint'] && $conn['bucket'] && $conn['access_key'] && $conn['secret_key'];
    }

    protected function client(array $conn)
    {
        return new S3Client($conn);
    }

    /**
     * One connection per endpoint + bucket. Saving new keys for the same bucket
     * replaces the stored keys, so a key rotation reaches every file.
     */
    public function connectionId(array $conn)
    {
        return substr(md5(strtolower($conn['endpoint']) . '|' . $conn['bucket']), 0, 12);
    }

    /**
     * Keep this connection so files stored with it stay reachable after a change.
     * Credentials from wp-config constants are never copied into the database.
     */
    protected function rememberConnection(array $conn, $refresh = false)
    {
        $id = $this->connectionId($conn);
        $connections = $this->storedConnections();

        if (!$refresh && isset($connections[$id])) {
            return $id;
        }

        $record = [
            'endpoint'   => $conn['endpoint'],
            'bucket'     => $conn['bucket'],
            'region'     => $conn['region'],
            'path_style' => !empty($conn['path_style']),
        ];

        if ($this->usesConstants()) {
            $record['from_constants'] = 'yes';
        } else {
            $accessKey = ProHelper::encryptKey($conn['access_key']);
            $secretKey = ProHelper::encryptKey($conn['secret_key']);
            $encrypted = $accessKey !== false && $secretKey !== false;

            $record['access_key'] = $encrypted ? $accessKey : $conn['access_key'];
            $record['secret_key'] = $encrypted ? $secretKey : $conn['secret_key'];
            $record['encrypted'] = $encrypted ? 'yes' : 'no';
        }

        $connections[$id] = $record;
        Helper::updateIntegrationOption($this->optionKey() . '_connections', $connections);

        return $id;
    }

    protected function storedConnections()
    {
        $connections = Helper::getIntegrationOption($this->optionKey() . '_connections', []);

        return is_array($connections) ? $connections : [];
    }

    /**
     * Keep the current connection before the settings change or are cleared, so
     * files uploaded with it (including files from before connections were
     * recorded) can still be read and deleted.
     */
    protected function rememberCurrentConnection()
    {
        $settings = $this->getSettings();
        $conn = $this->connectionFromSettings($settings);

        if ($settings['status'] === 'yes' && $conn['endpoint'] && $conn['bucket'] && $conn['access_key'] && $conn['secret_key']) {
            $this->rememberConnection($conn, true);
        }
    }

    /**
     * The connection that holds this file.
     *
     * @return array|null
     */
    public function connectionForAttachment($attachment)
    {
        $meta = $this->attachmentSettings($attachment);
        $current = $this->connectionFromSettings($this->getSettings());

        // Where the file lives: its recorded connection, or for files from before
        // connections were recorded, the bucket/region an older Pro stored on the row.
        $stored = null;
        $connId = Arr::get($meta, 'storage_conn');
        if ($connId) {
            $stored = Arr::get($this->storedConnections(), $connId);
        }

        $target = $stored ?: $this->applyLegacyLocation($current, $meta);
        if (!$stored) {
            $stored = $this->legacyConnection($target);
            if ($stored) {
                $target = $stored;
            }
        }

        // Same endpoint and bucket as the current settings: use the current keys.
        if ($this->isConfigured()
            && strtolower($current['endpoint']) === strtolower($target['endpoint'])
            && $current['bucket'] === $target['bucket']) {
            return $current;
        }

        // A bucket/account we have no record of (files from before connections were
        // recorded): try the current keys with the file's own bucket and region.
        if (!$stored) {
            return $this->isConfigured() ? $target : null;
        }

        if (Arr::get($stored, 'from_constants') === 'yes') {
            if (!$this->usesConstants()) {
                return null;
            }
            $stored['access_key'] = $current['access_key'];
            $stored['secret_key'] = $current['secret_key'];
        } elseif (Arr::get($stored, 'encrypted') === 'yes') {
            $stored['access_key'] = ProHelper::decryptKey($stored['access_key']);
            $stored['secret_key'] = ProHelper::decryptKey($stored['secret_key']);
        }

        return !empty($stored['access_key']) && !empty($stored['secret_key']) ? $stored : null;
    }

    /**
     * The stored connection for a file from before connections were recorded.
     * Override when the row doesn't say enough to rebuild the endpoint.
     *
     * @param array $target The current connection with the row's legacy location applied.
     * @return array|null
     */
    protected function legacyConnection(array $target)
    {
        return Arr::get($this->storedConnections(), $this->connectionId($target));
    }

    /**
     * Override to read the bucket/region an older Pro stored on the row.
     */
    protected function applyLegacyLocation(array $conn, array $meta)
    {
        return $conn;
    }

    public function objectKey($attachment)
    {
        $meta = $this->attachmentSettings($attachment);
        $key = Arr::get($meta, 'object_key') ?: Arr::get($meta, $this->legacyObjectKey());

        if (!$key && strpos((string) $attachment->file_path, $this->pathScheme()) === 0) {
            $key = substr($attachment->file_path, strlen($this->pathScheme()));
        }

        return (string) $key;
    }

    public function upload($attachment, $ticketId)
    {
        if (!$this->isConfigured()) {
            return new \WP_Error('not_configured', __('Storage is not connected.', 'fluent-support-pro'));
        }

        $localPath = (string) $attachment->file_path;
        if (!file_exists($localPath)) {
            return new \WP_Error('file_not_found', __('File not found for upload.', 'fluent-support-pro'));
        }

        $settings = $this->getSettings();
        $conn = $this->connectionFromSettings($settings);
        $prefix = trim((string) Arr::get($settings, 'path_prefix', 'fluent-support'), '/');
        $key = ($prefix ? $prefix . '/' : '') . 'ticket_' . (int) $ticketId . '/' . $this->uniqueFileName($attachment->title);

        $contentType = $attachment->file_type ?: (wp_check_filetype((string) $attachment->title)['type'] ?: 'application/octet-stream');
        $result = $this->client($conn)->put($localPath, $key, $contentType);

        if (is_wp_error($result)) {
            return $result;
        }

        $meta = $this->attachmentSettings($attachment);
        $meta['object_key'] = $key;
        $meta[$this->legacyObjectKey()] = $key;
        $meta['storage_conn'] = $this->rememberConnection($conn);
        $meta = $this->addLegacyLocation($meta, $conn);

        $attachment->settings = $meta;
        $attachment->file_path = $this->pathScheme() . $key;
        $attachment->full_url = esc_url_raw($this->publicUrl($key, $settings));
        $attachment->driver = $this->getKey();
        $attachment->save();

        return true;
    }

    /**
     * Extra keys older Pro versions read (bucket/region). Additive only.
     */
    protected function addLegacyLocation(array $meta, array $conn)
    {
        return $meta;
    }

    public function delete($attachment)
    {
        $conn = $this->connectionForAttachment($attachment);
        $key = $this->objectKey($attachment);

        if (!$conn || !$key) {
            return new \WP_Error('no_connection', __('The storage this file was saved to is no longer connected.', 'fluent-support-pro'));
        }

        return $this->client($conn)->delete($key);
    }

    public function getDownloadUrl($attachment)
    {
        $conn = $this->connectionForAttachment($attachment);
        $key = $this->objectKey($attachment);

        if (!$conn || !$key) {
            return new \WP_Error('no_connection', __('The storage this file was saved to is no longer connected.', 'fluent-support-pro'));
        }

        return $this->client($conn)->presignedUrl($key, 300, (string) $attachment->title);
    }

    public function getLocalCopy($attachment, $maxBytes = 0)
    {
        $conn = $this->connectionForAttachment($attachment);
        $key = $this->objectKey($attachment);

        if (!$conn || !$key) {
            return new \WP_Error('no_connection', __('The storage this file was saved to is no longer connected.', 'fluent-support-pro'));
        }

        $path = Http::tempFile($attachment->title);
        $result = $this->client($conn)->download($key, $path, $maxBytes);

        return is_wp_error($result) ? $result : $path;
    }

    /**
     * Never store values that come from wp-config constants.
     */
    public function updateSettings($settings)
    {
        if ($this->usesConstants()) {
            foreach ($this->constantMap() as $suffix => $field) {
                if (defined($this->constantPrefix() . '_' . $suffix)) {
                    unset($settings[$field]);
                }
            }
            unset($settings['status']);
        }

        parent::updateSettings($settings);
    }

    public function getSettingsAndFields($data)
    {
        $all = $this->getSettings();
        $settings = Arr::only($all, array_merge($this->formFields(), ['status']));
        $settings['access_key_id'] = empty($all['access_key_id']) ? '' : self::MASK;
        $settings['secret_access_key'] = empty($all['secret_access_key']) ? '' : self::MASK;

        $configured = $all['status'] === 'yes';
        $fieldConfig = $this->fieldsConfig($all);
        $fieldConfig['button_text'] = $configured ? __('Save Settings', 'fluent-support-pro') : __('Save & Connect', 'fluent-support-pro');
        $fieldConfig['has_discard'] = $configured && !$this->usesConstants();
        $fieldConfig['last_error'] = Arr::get($all, 'last_error') ?: Arr::get($this->getStatus(), 'last_error');
        $fieldConfig['locked'] = $this->usesConstants();
        $fieldConfig['file_count'] = $this->countFiles();

        if ($this->usesConstants()) {
            $fieldConfig['description'] .= ' ' . sprintf(
                /* translators: %s: constant name prefix */
                __('These settings are set in wp-config.php (%s_*) and cannot be changed here.', 'fluent-support-pro'),
                $this->constantPrefix()
            );
        }

        return [
            'settings'     => $settings,
            'fieldsConfig' => $fieldConfig,
        ];
    }

    public function saveSettings($response, $input)
    {
        if ($this->usesConstants()) {
            return new \WP_Error('storage_settings', __('These settings are set in wp-config.php and cannot be changed here.', 'fluent-support-pro'));
        }

        // Only an explicit disconnect. The settings screen before 2.4.7 disconnects by
        // blanking client_id, a field S3 forms don't have, so that means disconnect too.
        $isDisconnect = !empty($input['disconnect'])
            || (array_key_exists('client_id', $input) && $input['client_id'] === '');

        if ($isDisconnect) {
            // Keep the connection so stored files stay reachable.
            $this->rememberCurrentConnection();
            $this->updateSettings(array_merge($this->defaults(), ['status' => 'no']));
            $this->deactivateIfActive();

            return [
                'message'      => __('Storage settings have been disconnected', 'fluent-support-pro'),
                'is_discarded' => true,
            ];
        }

        $old = $this->getSettings();
        $new = $old;

        foreach ($this->formFields() as $field) {
            if (array_key_exists($field, $input)) {
                $new[$field] = $this->sanitizeField($field, $input[$field]);
            }
        }

        $newAccessKey = Arr::get($input, 'access_key_id');
        $newSecret = Arr::get($input, 'secret_access_key');
        $secretMasked = !$newSecret || $newSecret === self::MASK;

        if ($newAccessKey && $newAccessKey !== self::MASK) {
            $new['access_key_id'] = sanitize_text_field($newAccessKey);
        }

        if (!$secretMasked) {
            $new['secret_access_key'] = sanitize_text_field($newSecret);
        }

        foreach (array_merge(['access_key_id', 'secret_access_key', 'bucket_name'], $this->requiredFields()) as $field) {
            if (empty($new[$field])) {
                return new \WP_Error('storage_settings', __('Please fill in all required fields.', 'fluent-support-pro'));
            }
        }

        $invalid = $this->validateLocation($new);
        if ($invalid) {
            return new \WP_Error('storage_settings', $invalid);
        }

        // A masked secret must not follow the settings to a different server.
        if ($secretMasked) {
            foreach ($this->endpointFields() as $field) {
                if ((string) Arr::get($old, $field) !== (string) Arr::get($new, $field)) {
                    return new \WP_Error('storage_settings', __('Please enter the secret key again when changing where files are stored.', 'fluent-support-pro'));
                }
            }
        }

        $changed = false;
        foreach (array_merge($this->formFields(), ['access_key_id', 'secret_access_key']) as $field) {
            if ((string) Arr::get($old, $field) !== (string) Arr::get($new, $field)) {
                $changed = true;
            }
        }

        if ($changed || !empty($input['do_reconnect']) || $old['status'] !== 'yes') {
            $conn = $this->connectionFromSettings($new);
            $result = $this->client($conn)->verify();

            // Amazon tells us the bucket's real region; use it instead of failing.
            if (is_wp_error($result) && $result->get_error_code() === 'wrong_region' && $this->canDetectRegion()) {
                $data = (array) $result->get_error_data();
                $region = (string) Arr::get($data, 'region');
                if (preg_match('/^[a-z0-9-]{2,32}$/', $region)) {
                    $new['region'] = $region;
                    $conn = $this->connectionFromSettings($new);
                    $result = $this->client($conn)->verify();
                }
            }

            // Keep the working settings; only remember the error.
            if (is_wp_error($result)) {
                $old['last_error'] = $result->get_error_message();
                parent::updateSettings($old);

                return new \WP_Error('storage_settings', sprintf(__('Connection failed: %s', 'fluent-support-pro'), $result->get_error_message()));
            }
        }

        // Files of the previous bucket/account keep working through their connection.
        $this->rememberCurrentConnection();

        $new['status'] = 'yes';
        $new['last_error'] = '';
        $this->updateSettings($new);
        $this->rememberConnection($this->connectionFromSettings($new), true);
        $this->afterConnected();

        return [
            'message' => __('Storage settings have been saved', 'fluent-support-pro'),
        ];
    }

    /**
     * Reject bucket names, regions and endpoints that could point requests at another host.
     *
     * @return string Error message, or '' when valid.
     */
    protected function validateLocation(array $settings)
    {
        // Letters, numbers, dots, hyphens, underscores (older us-east-1 buckets allow
        // capitals and underscores). Nothing that could change the request host.
        if (!preg_match('/^[A-Za-z0-9][A-Za-z0-9._\-]{1,253}[A-Za-z0-9]$/', (string) $settings['bucket_name'])) {
            return __('Please enter a valid bucket name (letters, numbers, dots, hyphens and underscores).', 'fluent-support-pro');
        }

        if (!empty($settings['region']) && !preg_match('/^[a-z0-9-]{2,32}$/', (string) $settings['region'])) {
            return __('Please enter a valid region.', 'fluent-support-pro');
        }

        return '';
    }

    protected function requiredFields()
    {
        return [];
    }

    protected function canDetectRegion()
    {
        return false;
    }

    protected function sanitizeField($field, $value)
    {
        $value = is_scalar($value) ? (string) $value : '';

        switch ($field) {
            case 'custom_domain':
                return esc_url_raw($value);
            case 'endpoint':
                // Host only: providers like R2 show the endpoint with the bucket path appended
                $value = preg_replace('#^https?://#i', '', trim($value));
                $value = explode('/', $value, 2)[0];
                return preg_replace('/[^A-Za-z0-9.\-:]/', '', $value);
            case 'path_style':
                return $value === 'yes' ? 'yes' : 'no';
            case 'path_prefix':
                return trim(preg_replace('#[^A-Za-z0-9/_\-.]#', '', $value), '/');
            default:
                return sanitize_text_field($value);
        }
    }
}
