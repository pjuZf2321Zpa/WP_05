<?php

namespace FluentSupportPro\App\Services\FileUploadIntegration\Support;

/**
 * HTTP helpers shared by the storage drivers.
 *
 * Small files go through wp_remote_request() so they honour WordPress HTTP settings
 * (and pre_http_request in tests). Files above the stream threshold are sent with
 * cURL straight from disk, so a large upload never sits in memory.
 */
class Http
{
    /**
     * @return int Bytes.
     */
    public static function streamThreshold()
    {
        return (int) apply_filters('fluent_support_pro/storage_stream_threshold', 16 * MB_IN_BYTES);
    }

    /**
     * Send a file as the request body.
     *
     * @param string $method
     * @param string $url
     * @param array $headers
     * @param string $localPath
     * @param int $timeout
     * @param array $extra More wp_remote_request() args for small files (cURL never follows redirects).
     * @return array|\WP_Error ['code' => int, 'body' => string, 'headers' => array]
     */
    public static function sendFile($method, $url, array $headers, $localPath, $timeout = 300, array $extra = [])
    {
        $size = @filesize($localPath);

        if ($size === false) {
            return new \WP_Error('file_not_found', __('File not found for upload.', 'fluent-support-pro'));
        }

        if ($size <= self::streamThreshold() || !function_exists('curl_init')) {
            $content = file_get_contents($localPath); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
            if ($content === false) {
                return new \WP_Error('file_read_error', __('Unable to read file content', 'fluent-support-pro'));
            }

            return self::request($method, $url, $headers, $content, $timeout, $extra);
        }

        return self::curlSendFile($method, $url, $headers, $localPath, $size, $timeout);
    }

    /**
     * @param array $extra More wp_remote_request() args, e.g. ['redirection' => 0].
     * @return array|\WP_Error ['code' => int, 'body' => string, 'headers' => array]
     */
    public static function request($method, $url, array $headers = [], $body = null, $timeout = 30, array $extra = [])
    {
        $args = array_merge($extra, [
            'method'  => $method,
            'headers' => $headers,
            'timeout' => $timeout,
        ]);

        if ($body !== null) {
            $args['body'] = $body;
        }

        $response = wp_remote_request($url, $args);

        if (is_wp_error($response)) {
            return $response;
        }

        return [
            'code'    => (int) wp_remote_retrieve_response_code($response),
            'body'    => (string) wp_remote_retrieve_body($response),
            'headers' => wp_remote_retrieve_headers($response),
        ];
    }

    /**
     * Download a URL to a local file without loading it into memory.
     *
     * @param array $extra More wp_remote_get() args, e.g. ['redirection' => 0].
     * @return true|\WP_Error
     */
    public static function downloadTo($url, array $headers, $toPath, $timeout = 300, $maxBytes = 0, array $extra = [])
    {
        $args = array_merge($extra, [
            'headers'  => $headers,
            'timeout'  => $timeout,
            'stream'   => true,
            'filename' => $toPath,
        ]);

        if ($maxBytes > 0) {
            $args['limit_response_size'] = $maxBytes + 1;
        }

        $response = wp_remote_get($url, $args);

        if (is_wp_error($response)) {
            self::removeTemp($toPath);
            return $response;
        }

        $code = (int) wp_remote_retrieve_response_code($response);

        if ($code < 200 || $code >= 300) {
            self::removeTemp($toPath);
            return new \WP_Error('download_failed', sprintf(__('Download failed with code %d', 'fluent-support-pro'), $code));
        }

        clearstatcache(true, $toPath);
        if ($maxBytes > 0 && file_exists($toPath) && filesize($toPath) > $maxBytes) {
            self::removeTemp($toPath);
            return new \WP_Error('file_too_large', __('The file is larger than allowed here.', 'fluent-support-pro'));
        }

        return true;
    }

    /**
     * Delete a temporary file and the folder tempFile() made for it.
     */
    public static function removeTemp($path)
    {
        if ($path && file_exists($path)) {
            wp_delete_file($path);
        }

        $dir = dirname((string) $path);
        if (strpos(basename($dir), 'fluent-support-') === 0 && is_dir($dir)) {
            @rmdir($dir);
        }
    }

    /**
     * A new empty temporary file named after the attachment, so its extension (and the
     * name mail clients show) is kept.
     *
     * @param string $title
     * @return string
     */
    public static function tempFile($title)
    {
        $dir = trailingslashit(get_temp_dir()) . 'fluent-support-' . wp_generate_password(12, false);
        wp_mkdir_p($dir);

        $name = sanitize_file_name((string) $title) ?: 'attachment';

        return $dir . '/' . $name;
    }

    private static function curlSendFile($method, $url, array $headers, $localPath, $size, $timeout)
    {
        $handle = fopen($localPath, 'rb'); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen
        if (!$handle) {
            return new \WP_Error('file_read_error', __('Unable to read file content', 'fluent-support-pro'));
        }

        $headerLines = ['Content-Length: ' . $size, 'Expect:'];
        // At least 256 KB/s; the low-speed limit below still catches a stalled transfer.
        $timeout = max((int) $timeout, (int) ceil($size / (256 * KB_IN_BYTES)));
        foreach ($headers as $name => $value) {
            $headerLines[] = $name . ': ' . $value;
        }

        $responseHeaders = [];
        $curl = curl_init($url); // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_init
        // phpcs:disable WordPress.WP.AlternativeFunctions.curl_curl_setopt_array
        curl_setopt_array($curl, [
            CURLOPT_CUSTOMREQUEST    => $method,
            CURLOPT_UPLOAD           => true,
            CURLOPT_INFILE           => $handle,
            CURLOPT_INFILESIZE       => $size,
            CURLOPT_HTTPHEADER       => $headerLines,
            CURLOPT_RETURNTRANSFER   => true,
            CURLOPT_TIMEOUT          => $timeout,
            CURLOPT_CONNECTTIMEOUT   => 15,
            CURLOPT_PROTOCOLS        => CURLPROTO_HTTPS,
            CURLOPT_SSL_VERIFYPEER   => true,
            CURLOPT_SSL_VERIFYHOST   => 2,
            CURLOPT_LOW_SPEED_LIMIT  => 1024,
            CURLOPT_LOW_SPEED_TIME   => 60,
            CURLOPT_CAINFO           => ABSPATH . 'wp-includes/certificates/ca-bundle.crt',
            CURLOPT_HEADERFUNCTION   => function ($curl, $line) use (&$responseHeaders) {
                $parts = explode(':', $line, 2);
                if (count($parts) === 2) {
                    $responseHeaders[strtolower(trim($parts[0]))] = trim($parts[1]);
                }
                return strlen($line);
            },
        ]);
        // phpcs:enable

        // Same proxy as the WordPress HTTP API.
        if (class_exists('\WP_HTTP_Proxy')) {
            $proxy = new \WP_HTTP_Proxy();
            if ($proxy->is_enabled() && $proxy->send_through_proxy($url)) {
                // phpcs:disable WordPress.WP.AlternativeFunctions.curl_curl_setopt
                curl_setopt($curl, CURLOPT_PROXY, $proxy->host());
                curl_setopt($curl, CURLOPT_PROXYPORT, (int) $proxy->port());
                if ($proxy->use_authentication()) {
                    curl_setopt($curl, CURLOPT_PROXYUSERPWD, $proxy->authentication());
                }
                // phpcs:enable
            }
        }

        $body = curl_exec($curl); // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_exec
        $error = curl_error($curl); // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_error
        $code = (int) curl_getinfo($curl, CURLINFO_HTTP_CODE); // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_getinfo
        if (PHP_VERSION_ID < 80000) {
            curl_close($curl); // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_close
        }
        fclose($handle); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose

        if ($body === false) {
            return new \WP_Error('http_request_failed', $error);
        }

        return [
            'code'    => $code,
            'body'    => (string) $body,
            'headers' => $responseHeaders,
        ];
    }
}
