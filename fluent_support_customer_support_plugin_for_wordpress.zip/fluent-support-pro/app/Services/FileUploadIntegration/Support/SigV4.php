<?php

namespace FluentSupportPro\App\Services\FileUploadIntegration\Support;

/**
 * AWS Signature Version 4 for S3 and S3-compatible storage (R2, Spaces, Wasabi, ...).
 */
class SigV4
{
    const ALGORITHM = 'AWS4-HMAC-SHA256';

    /**
     * Encode an object key for the request path, segment by segment.
     *
     * @param string $key
     * @return string Starts with '/'.
     */
    public static function encodePath($key)
    {
        return '/' . implode('/', array_map('rawurlencode', explode('/', ltrim((string) $key, '/'))));
    }

    /**
     * @param array $query
     * @return string Sorted, RFC 3986 encoded.
     */
    public static function canonicalQuery(array $query)
    {
        ksort($query);
        $parts = [];

        foreach ($query as $key => $value) {
            $parts[] = rawurlencode($key) . '=' . rawurlencode((string) $value);
        }

        return implode('&', $parts);
    }

    /**
     * Headers that authorize one request.
     *
     * @param string $method
     * @param string $host
     * @param string $path Already encoded (encodePath()).
     * @param array $query
     * @param string $payloadHash sha256 of the body, hex.
     * @param string $accessKey
     * @param string $secretKey
     * @param string $region
     * @param int|null $time For tests.
     * @return array
     */
    public static function headers($method, $host, $path, array $query, $payloadHash, $accessKey, $secretKey, $region, $time = null)
    {
        $time = $time ?: time();
        $timestamp = gmdate('Ymd\THis\Z', $time);
        $date = gmdate('Ymd', $time);

        $canonicalHeaders = "host:{$host}\nx-amz-content-sha256:{$payloadHash}\nx-amz-date:{$timestamp}\n";
        $signedHeaders = 'host;x-amz-content-sha256;x-amz-date';

        $canonicalRequest = implode("\n", [
            strtoupper($method),
            $path,
            self::canonicalQuery($query),
            $canonicalHeaders,
            $signedHeaders,
            $payloadHash
        ]);

        $scope = "{$date}/{$region}/s3/aws4_request";
        $stringToSign = self::ALGORITHM . "\n{$timestamp}\n{$scope}\n" . hash('sha256', $canonicalRequest);
        $signature = hash_hmac('sha256', $stringToSign, self::signingKey($secretKey, $date, $region));

        return [
            'Authorization'        => self::ALGORITHM . " Credential={$accessKey}/{$scope}, SignedHeaders={$signedHeaders}, Signature={$signature}",
            'x-amz-date'           => $timestamp,
            'x-amz-content-sha256' => $payloadHash,
        ];
    }

    /**
     * Query string for a presigned GET URL (without the leading '?').
     *
     * @param string $host
     * @param string $path Already encoded.
     * @param string $accessKey
     * @param string $secretKey
     * @param string $region
     * @param int $expires Seconds, max 604800.
     * @param array $extraQuery e.g. response-content-disposition
     * @param int|null $time For tests.
     * @return string
     */
    public static function presignQuery($host, $path, $accessKey, $secretKey, $region, $expires, array $extraQuery = [], $time = null)
    {
        $time = $time ?: time();
        $timestamp = gmdate('Ymd\THis\Z', $time);
        $date = gmdate('Ymd', $time);
        $scope = "{$date}/{$region}/s3/aws4_request";

        $query = array_merge($extraQuery, [
            'X-Amz-Algorithm'     => self::ALGORITHM,
            'X-Amz-Credential'    => "{$accessKey}/{$scope}",
            'X-Amz-Date'          => $timestamp,
            'X-Amz-Expires'       => (string) min(604800, max(1, (int) $expires)),
            'X-Amz-SignedHeaders' => 'host',
        ]);

        $canonicalQuery = self::canonicalQuery($query);
        $canonicalRequest = "GET\n{$path}\n{$canonicalQuery}\nhost:{$host}\n\nhost\nUNSIGNED-PAYLOAD";
        $stringToSign = self::ALGORITHM . "\n{$timestamp}\n{$scope}\n" . hash('sha256', $canonicalRequest);
        $signature = hash_hmac('sha256', $stringToSign, self::signingKey($secretKey, $date, $region));

        return $canonicalQuery . '&X-Amz-Signature=' . $signature;
    }

    private static function signingKey($secretKey, $date, $region)
    {
        $kDate = hash_hmac('sha256', $date, 'AWS4' . $secretKey, true);
        $kRegion = hash_hmac('sha256', $region, $kDate, true);
        $kService = hash_hmac('sha256', 's3', $kRegion, true);

        return hash_hmac('sha256', 'aws4_request', $kService, true);
    }
}
