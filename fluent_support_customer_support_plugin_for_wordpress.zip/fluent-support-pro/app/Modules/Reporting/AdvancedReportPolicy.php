<?php

namespace FluentSupportPro\App\Modules\Reporting;

use FluentSupport\App\Modules\PermissionManager;
use FluentSupport\Framework\Http\Request\Request;
use FluentSupport\Framework\Foundation\Policy;

class AdvancedReportPolicy extends Policy
{
    /**
     * Check user permission for any method
     * @param Request $request
     * @return Boolean
     */
    public function verifyRequest(Request $request)
    {
        return PermissionManager::currentUserCan('fst_view_all_reports') &&
            PermissionManager::currentUserCan('fst_sensitive_data');
    }
}
