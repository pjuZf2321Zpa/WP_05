<?php

namespace FluentSupportPro\App\Modules\Reporting;

use FluentSupport\App\Exceptions\ApiException;
use FluentSupport\App\Http\Controllers\Controller;
use FluentSupport\App\Modules\PermissionManager;
use FluentSupport\App\Modules\Reports\ReportController as CoreReports;
use FluentSupport\App\Modules\Reports\Reports;
use FluentSupport\Framework\Http\Request\Request;
use FluentSupportPro\App\Models\ReportSnapshot;

/**
 * Pro's report tabs (the free plugin draws them): the agent summary, the
 * weekday-hour grid, the mailbox charts, the Advanced Reports pages and their
 * snapshots. The numbers come from the free plugin's Reports and
 * AdvancedReportService.
 */
class ReportController extends Controller
{
    /**
     * One row per agent for the range (default today).
     */
    public function agentsSummary(Request $request)
    {
        return ['summary' => Reports::agentSummary(CoreReports::date($request->get('from')), CoreReports::date($request->get('to')))];
    }

    /**
     * Tickets, agent replies (optionally one agent's) or customer replies by weekday and hour.
     */
    public function dayTimeStats(Request $request)
    {
        list($from, $to) = CoreReports::dateRange($request);
        $type = $request->getSafe('report_type', 'sanitize_key');

        if (!in_array($type, ['ticket', 'agent_response', 'customer_response'], true)) {
            return ['stats' => []];
        }

        $filters = $type === 'agent_response' ? ['agent_id' => $request->getInt('agent_id')] : [];

        return ['stats' => Reports::weekdayHours($type, $from, $to, $filters)];
    }

    public function mailboxTicketsChart(Request $request)
    {
        return $this->mailboxChart('tickets', $request);
    }

    public function mailboxClosedChart(Request $request)
    {
        return $this->mailboxChart('closed', $request);
    }

    public function mailboxRepliesChart(Request $request)
    {
        return $this->mailboxChart('replies', $request);
    }

    public function ticketOverview(Request $request)
    {
        list($from, $to) = $this->range($request);

        return AdvancedReportService::getTicketOverview($from, $to, $request->getInt('product_id') ?: null);
    }

    public function responseActivity(Request $request)
    {
        list($from, $to) = $this->range($request);

        return AdvancedReportService::getResponseActivity($from, $to);
    }

    public function productInsights(Request $request)
    {
        list($from, $to) = $this->range($request);

        return AdvancedReportService::getProductInsights($from, $to);
    }

    /**
     * Waiting and unassigned tickets now; no date range.
     */
    public function workloadHealth(Request $request)
    {
        return AdvancedReportService::getWorkloadHealth($request->getInt('mailbox_id') ?: null);
    }

    public function performanceFilters()
    {
        return AdvancedReportService::getPerformanceOverviewFilters();
    }

    public function performanceOverview(Request $request)
    {
        list($from, $to) = $this->range($request);
        $agentIds = array_values(array_unique(array_filter(array_map('intval', explode(',', (string) $request->getSafe('agent_ids', 'sanitize_text_field'))))));

        return AdvancedReportService::getPerformanceOverview($from, $to, $agentIds, $request->getInt('page', 1), min(50, max(1, $request->getInt('per_page', 6))));
    }

    /**
     * Snapshot times of one report. Snapshots hold site-wide figures (cron has
     * no user), so a viewer restricted from any mailbox gets none.
     */
    public function snapshots(Request $request)
    {
        $type = $request->getSafe('report_type', 'sanitize_text_field');

        if (!in_array($type, SnapshotService::REPORT_TYPES, true)) {
            throw ApiException::invalid(__('Invalid report type.', 'fluent-support-pro'));
        }
        if (PermissionManager::getRestrictedMailboxIds()) {
            return ['snapshots' => []];
        }

        return [
            'snapshots' => ReportSnapshot::ofType($type)->orderBy('snapshot_time', 'desc')->get(['id', 'snapshot_time'])
                ->map(fn($snapshot) => ['id' => (int) $snapshot->id, 'snapshot_time' => (string) $snapshot->snapshot_time])->all()
        ];
    }

    public function snapshot($id)
    {
        if (PermissionManager::getRestrictedMailboxIds()) {
            throw ApiException::forbidden(__('Snapshots contain site-wide data and are not available to agents with mailbox restrictions.', 'fluent-support-pro'));
        }

        $snapshot = ReportSnapshot::find($id);
        if (!$snapshot) {
            throw ApiException::notFound(__('Snapshot not found.', 'fluent-support-pro'));
        }

        return [
            'id'            => (int) $snapshot->id,
            'snapshot_time' => (string) $snapshot->snapshot_time,
            'report_type'   => $snapshot->report_type,
            'data'          => $snapshot->data,
        ];
    }

    /**
     * A chart for one mailbox, or all mailboxes without mailbox_id.
     */
    private function mailboxChart($metric, Request $request)
    {
        list($from, $to) = CoreReports::dateRange($request);

        return ['stats' => Reports::chart($metric, $from, $to, ['mailbox_id' => $request->getInt('mailbox_id')])];
    }

    /**
     * [from, to]: both Y-m-d, in order, at most a year apart.
     */
    private function range(Request $request)
    {
        $from = CoreReports::date($request->get('from'));
        $to = CoreReports::date($request->get('to'));

        if (!$from || !$to) {
            throw ApiException::invalid(__('from and to must be valid dates in YYYY-MM-DD format', 'fluent-support-pro'));
        }
        if ($from > $to) {
            throw ApiException::invalid(__('The from date must be before the to date', 'fluent-support-pro'));
        }
        if (strtotime($to) - strtotime($from) > YEAR_IN_SECONDS) {
            throw ApiException::invalid(__('The date range cannot exceed 1 year', 'fluent-support-pro'));
        }

        return [$from, $to];
    }
}
