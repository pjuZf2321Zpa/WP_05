<?php

namespace FluentSupportPro\App\Modules\Reporting;

use FluentSupport\App\Models\Agent;
use FluentSupport\App\Models\AgentGroup;
use FluentSupport\App\Models\MailBox;
use FluentSupport\App\Models\Product;
use FluentSupport\App\Models\TagPivot;
use FluentSupport\App\Models\Ticket;
use FluentSupport\App\Modules\PermissionManager;
use FluentSupport\App\Modules\Reports\Reports;
use FluentSupport\App\Services\Helper;
use FluentSupport\Framework\Support\Collection;

/**
 * The Advanced Reports pages: Ticket Overview, Response Activity, Product
 * Insights, Workload Health and Performance Overview. Every count comes from
 * the free plugin's Reports (scoped to the viewer's mailboxes, one meaning per
 * word); this class groups and shapes them. Dates are Y-m-d, both ends included.
 */
class AdvancedReportService
{
    const WAITING_LONGEST_LIMIT = 10;
    const PRODUCT_DISTRIBUTION_LIMIT = 5;
    const NO_PRODUCT = 0;

    public static function getWorkloadHealth($mailboxId = null)
    {
        $waiting = Reports::waitStatsBy('mailbox_id');
        $unassigned = static::countBy(Reports::unassigned(), 'mailbox_id');

        $rows = [];
        foreach (MailBox::whereNotIn('id', PermissionManager::getRestrictedMailboxIds() ?: [0])->orderBy('name')->get() as $mailbox) {
            $id = (int) $mailbox->id;
            $rows[] = [
                'id'             => $id,
                'name'           => $mailbox->name,
                'awaiting_reply' => $waiting[$id]['waiting_tickets'] ?? 0,
                'avg_wait'       => $waiting[$id]['average_waiting'] ?? 0,
                'unassigned'     => $unassigned[$id] ?? 0,
            ];
        }

        $longest = Reports::waiting(Reports::tickets(['mailbox_id' => $mailboxId]))
            ->with(['customer', 'product'])
            ->orderBy('waiting_since', 'asc')
            ->limit(static::WAITING_LONGEST_LIMIT)
            ->get()
            ->map(fn($ticket) => [
                'id'            => (int) $ticket->id,
                'subject'       => $ticket->title,
                'customer'      => $ticket->customer ? $ticket->customer->full_name : '',
                'waiting_since' => $ticket->waiting_since ? (string) $ticket->waiting_since : null,
                'product'       => $ticket->product ? $ticket->product->title : '',
                'mailbox_id'    => $ticket->mailbox_id === null ? null : (int) $ticket->mailbox_id,
            ])->all();

        return [
            'all'             => static::workload(),
            'mailboxes'       => $rows,
            'waiting_tickets' => $longest,
        ];
    }

    /**
     * Waiting tickets and their average wait, and unassigned open tickets, now.
     */
    protected static function workload($productId = null)
    {
        $waiting = Reports::waitStats(['product_id' => $productId]);

        return [
            'awaiting_reply' => $waiting['waiting_tickets'],
            'avg_wait'       => $waiting['average_waiting'],
            'unassigned'     => Reports::unassigned(['product_id' => $productId])->count(),
        ];
    }

    /**
     * One row per product (and "No Product" when it has any): tickets created,
     * open and unanswered among them, closed, agent replies and tickets replied
     * to in the range, and tickets waiting now.
     */
    public static function getProductInsights($from, $to)
    {
        list($start, $end) = static::between($from, $to);

        $created = Reports::tickets()->whereBetween('created_at', [$start, $end]);
        $counts = [
            'volume'       => static::countBy(clone $created, 'product_id'),
            'opens'        => static::countBy((clone $created)->where('status', '!=', 'closed'), 'product_id'),
            'unanswered'   => static::countBy((clone $created)->where('response_count', 0), 'product_id'),
            'closed'       => static::countBy(Reports::tickets()->where('status', 'closed')->whereBetween('resolved_at', [$start, $end]), 'product_id'),
            'waiting'      => static::countBy(Reports::waiting(Reports::tickets()), 'product_id'),
            'responses'    => static::repliesByProduct($start, $end, 'COUNT(*)'),
            'interactions' => static::repliesByProduct($start, $end, 'COUNT(DISTINCT fs_conversations.ticket_id)'),
        ];

        $row = function ($id, $name) use ($counts) {
            $row = ['id' => $id, 'name' => $name];
            foreach (['volume', 'responses', 'unanswered', 'waiting', 'interactions', 'opens', 'closed'] as $key) {
                $row[$key] = $counts[$key][$id] ?? 0;
            }
            return $row;
        };

        $rows = Product::orderBy('title')->get()->map(fn($product) => $row((int) $product->id, $product->title))->all();

        $none = $row(static::NO_PRODUCT, __('No Product', 'fluent-support-pro'));
        if ($none['volume'] || $none['responses'] || $none['unanswered'] || $none['waiting']) {
            $rows[] = $none;
        }

        return ['products' => $rows];
    }

    /**
     * Agent replies per product of their ticket.
     */
    protected static function repliesByProduct($start, $end, $count)
    {
        $p = static::prefix();
        $rows = Reports::replies()
            ->join('fs_tickets', 'fs_tickets.id', '=', 'fs_conversations.ticket_id')
            ->whereBetween('fs_conversations.created_at', [$start, $end])
            ->selectRaw("{$p}fs_tickets.product_id AS group_id, " . str_replace('fs_', $p . 'fs_', $count) . ' AS total')
            ->groupBy('fs_tickets.product_id')
            ->get();

        return static::keyRows($rows);
    }

    /**
     * Tickets created and agent replies per hour (one-day range) or per day.
     */
    public static function getResponseActivity($from, $to, $productId = null)
    {
        $filters = ['product_id' => $productId];

        if ($from === $to) {
            return [
                'granularity'     => 'hour',
                'labels'          => static::hourLabels(),
                'ticket_creation' => static::perHour(Reports::weekdayHours('ticket', $from, $to, $filters)),
                'agent_replies'   => static::perHour(Reports::weekdayHours('agent_response', $from, $to, $filters)),
            ];
        }

        $days = static::days($from, $to);
        list($start, $end) = static::between($from, $to);

        return [
            'granularity'     => 'day',
            'labels'          => $days,
            'ticket_creation' => static::perDay(Reports::tickets($filters)->whereBetween('created_at', [$start, $end]), $days),
            'agent_replies'   => static::perDay(Reports::replies($filters)->whereBetween('created_at', [$start, $end]), $days),
        ];
    }

    // $activityFrom/$activityTo scope just the chart (snapshots use a shorter window).
    public static function getTicketOverview($from, $to, $productId = null, $activityFrom = null, $activityTo = null)
    {
        list($start, $end) = static::between($from, $to);
        $filters = ['product_id' => $productId];
        $created = Reports::tickets($filters)->whereBetween('created_at', [$start, $end]);

        $replies = Reports::replies($filters)->whereBetween('created_at', [$start, $end])
            ->selectRaw('COUNT(*) AS total, COUNT(DISTINCT ticket_id) AS tickets_handled, COUNT(DISTINCT person_id) AS active_agents')
            ->first();
        $total = (int) $replies->total;
        $activeAgents = (int) $replies->active_agents;

        // Was the first agent reply on the day the ticket came in?
        $firstReplies = Reports::replies()->where('created_at', '>=', $start)
            ->selectRaw('ticket_id, MIN(created_at) AS first_at')
            ->groupBy('ticket_id');
        $p = static::prefix();
        $sameDay = (clone $created)
            ->leftJoinSub($firstReplies, 'fr', 'fr.ticket_id', '=', 'fs_tickets.id')
            ->selectRaw("COUNT(*) AS total, SUM(fr.first_at IS NOT NULL AND DATE(fr.first_at) = DATE({$p}fs_tickets.created_at)) AS same_day")
            ->first();

        $volume = static::countBy(clone $created, 'product_id');
        $products = $productId ? Product::where('id', $productId)->get() : Product::orderBy('title')->get();
        $distribution = $products->map(fn($product) => ['id' => (int) $product->id, 'name' => $product->title, 'tickets' => $volume[(int) $product->id] ?? 0])->all();
        if (!$productId) {
            $distribution[] = ['id' => static::NO_PRODUCT, 'name' => __('No Product', 'fluent-support-pro'), 'tickets' => $volume[static::NO_PRODUCT] ?? 0];
            $distribution = array_filter($distribution, fn($row) => $row['tickets'] > 0);
        }
        usort($distribution, fn($a, $b) => $b['tickets'] - $a['tickets']);
        if (!$productId) {
            $distribution = array_slice($distribution, 0, static::PRODUCT_DISTRIBUTION_LIMIT);
        }
        $max = $distribution ? $distribution[0]['tickets'] : 0;
        foreach ($distribution as &$row) {
            $row['percent'] = $max ? round($row['tickets'] / $max * 100) : 0;
        }
        unset($row);

        return [
            'workload'             => static::workload($productId),
            'tickets'              => [
                'new'           => (clone $created)->count(),
                'not_responded' => (clone $created)->where('response_count', 0)->count(),
                'closed'        => Reports::tickets($filters)->where('status', 'closed')->whereBetween('resolved_at', [$start, $end])->count(),
            ],
            'agent_responses'      => [
                'total_responses' => $total,
                'tickets_handled' => (int) $replies->tickets_handled,
                'active_agents'   => $activeAgents,
                'avg_per_agent'   => $activeAgents ? round($total / $activeAgents, 1) : 0,
            ],
            'same_day_response'    => [
                'same_day'     => (int) $sameDay->same_day,
                'not_same_day' => (int) $sameDay->total - (int) $sameDay->same_day,
            ],
            'activity'             => static::getResponseActivity($activityFrom ?? $from, $activityTo ?? $to, $productId),
            'product_distribution' => [
                'total'    => $productId ? ($volume[(int) $productId] ?? 0) : array_sum($volume),
                'products' => $distribution,
            ],
            'products'             => Product::orderBy('title')->get(['id', 'title'])->map(fn($product) => ['id' => (int) $product->id, 'name' => $product->title])->all(),
        ];
    }

    /**
     * The agents and agent groups (teams) to pick from.
     */
    public static function getPerformanceOverviewFilters()
    {
        $members = [];
        foreach (TagPivot::where('source_type', 'agent_group')->get(['tag_id', 'source_id']) as $pivot) {
            $members[(int) $pivot->tag_id][] = (int) $pivot->source_id;
        }

        return [
            'agents' => Agent::orderBy('first_name')->get(['id', 'first_name', 'last_name'])->map(fn($agent) => ['id' => (int) $agent->id, 'name' => $agent->full_name])->all(),
            'teams'  => AgentGroup::orderBy('title')->get()->map(fn($group) => ['id' => (int) $group->id, 'name' => $group->title, 'agent_ids' => $members[(int) $group->id] ?? []])->all(),
        ];
    }

    /**
     * Replies, activity, the tickets they replied to (paged), totals and growth
     * charts for the chosen agents. $activityFrom/$activityTo scope just the
     * activity chart; $includeAvgPerDay=false skips the per-day average.
     */
    public static function getPerformanceOverview($from, $to, array $agentIds, $page = 1, $perPage = 6, $activityFrom = null, $activityTo = null, $includeAvgPerDay = true)
    {
        $activityFrom = $activityFrom ?? $from;
        $activityTo = $activityTo ?? $to;

        if (!$agentIds) {
            return [
                'agents'   => [],
                'activity' => ['granularity' => $activityFrom === $activityTo ? 'hour' : 'day', 'labels' => [], 'series' => []],
                'tickets'  => ['data' => [], 'current_page' => 1, 'last_page' => 1, 'total' => 0],
                'totals'   => ['closed' => 0, 'open' => 0],
                'growth'   => ['tickets' => [], 'resolved' => [], 'responses' => []],
            ];
        }

        list($start, $end) = static::between($from, $to);
        $mine = ['agent_ids' => $agentIds];
        $agents = Agent::whereIn('id', $agentIds)->get(['id', 'first_name', 'last_name'])->keyBy('id');

        $stats = Reports::replies($mine)->whereBetween('created_at', [$start, $end])
            ->selectRaw('person_id, COUNT(*) AS total, MIN(created_at) AS first_at, MAX(created_at) AS last_at')
            ->groupBy('person_id')
            ->get()
            ->keyBy('person_id');
        // Only counted when asked: a cumulative range is thousands of days.
        $dayCount = $includeAvgPerDay ? max(1, count(static::days($from, $to))) : 1;

        $rows = [];
        foreach ($agentIds as $id) {
            if (!$agent = $agents->get($id)) {
                continue;
            }
            $row = $stats->get($id);
            $count = $row ? (int) $row->total : 0;
            $rows[] = [
                'id'             => $id,
                'name'           => $agent->full_name,
                'responses'      => $count,
                'first_response' => $row ? $row->first_at : null,
                'last_response'  => $row ? $row->last_at : null,
            ] + ($includeAvgPerDay ? ['avg_per_day' => $count ? round($count / $dayCount, 1) : 0] : []);
        }

        return [
            'agents'   => $rows,
            'activity' => static::agentActivity($agentIds, $agents, $activityFrom, $activityTo),
            'tickets'  => static::repliedTickets($agentIds, $start, $end, $page, $perPage),
            'totals'   => [
                'closed' => Reports::tickets($mine)->where('status', 'closed')->whereBetween('resolved_at', [$start, $end])->count(),
                'open'   => Reports::tickets($mine)->where('status', '!=', 'closed')->whereBetween('created_at', [$start, $end])->count(),
            ],
            'growth'   => [
                'tickets'   => Reports::chart('tickets', $from, $to, $mine),
                'resolved'  => Reports::chart('closed', $from, $to, $mine),
                'responses' => Reports::chart('replies', $from, $to, $mine),
            ],
        ];
    }

    /**
     * Each agent's replies per hour (one-day range) or per day.
     */
    protected static function agentActivity(array $agentIds, $agents, $from, $to)
    {
        $hourly = $from === $to;
        $labels = $hourly ? static::hourLabels() : static::days($from, $to);
        list($start, $end) = static::between($from, $to);

        $rows = Reports::replies(['agent_ids' => $agentIds])->whereBetween('created_at', [$start, $end])
            ->selectRaw('person_id, ' . ($hourly ? 'HOUR(created_at)' : 'DATE(created_at)') . ' AS bucket, COUNT(*) AS total')
            ->groupBy('person_id', 'bucket')
            ->get();

        $index = array_flip($hourly ? range(0, 23) : $labels);
        $series = array_fill_keys($agentIds, array_fill(0, count($labels), 0));
        foreach ($rows as $row) {
            if (isset($series[(int) $row->person_id], $index[$row->bucket])) {
                $series[(int) $row->person_id][$index[$row->bucket]] = (int) $row->total;
            }
        }

        return [
            'granularity' => $hourly ? 'hour' : 'day',
            'labels'      => $labels,
            'series'      => array_map(fn($id) => [
                'agent_id'   => $id,
                'agent_name' => $agents->get($id) ? $agents->get($id)->full_name : '',
                'data'       => $series[$id],
            ], $agentIds),
        ];
    }

    /**
     * The tickets the agents replied to in the range, newest first, one page:
     * their reply count and the latest of those replies.
     */
    protected static function repliedTickets(array $agentIds, $start, $end, $page, $perPage)
    {
        $replies = fn() => Reports::replies(['agent_ids' => $agentIds])->whereBetween('created_at', [$start, $end]);

        $paged = Reports::tickets()
            ->whereIn('id', $replies()->select('ticket_id'))
            ->with('customer')
            ->orderBy('id', 'desc')
            ->paginate(max(1, (int) $perPage), ['*'], 'page', max(1, (int) $page));

        // Counted in the database: a ticket's whole reply history never loads.
        $ticketIds = $paged->pluck('id')->all();
        $stats = $ticketIds
            ? $replies()->whereIn('ticket_id', $ticketIds)->groupBy('ticket_id')->selectRaw('ticket_id, COUNT(*) AS total, MAX(created_at) AS latest_at')->get()->keyBy('ticket_id')
            : new Collection();

        // The latest reply per ticket: its newest created_at, the highest id on a tie.
        $latestReplies = [];
        if ($stats->count()) {
            $candidates = $replies()->where(function ($query) use ($stats) {
                foreach ($stats as $stat) {
                    $query->orWhere(fn($q) => $q->where('ticket_id', $stat->ticket_id)->where('created_at', $stat->latest_at));
                }
            })->get(['id', 'ticket_id', 'person_id', 'created_at']);
            foreach ($candidates as $reply) {
                $id = (int) $reply->ticket_id;
                if (!isset($latestReplies[$id]) || (int) $reply->id > (int) $latestReplies[$id]->id) {
                    $latestReplies[$id] = $reply;
                }
            }
        }
        $latestAgents = Agent::whereIn('id', array_map(fn($reply) => (int) $reply->person_id, array_values($latestReplies)) ?: [0])->get(['id', 'first_name', 'last_name'])->keyBy('id');

        $statuses = Helper::ticketStatuses();
        $variants = ['new' => 'info', 'active' => 'warning', 'closed' => 'success'];

        return [
            'data'         => array_map(function ($ticket) use ($stats, $latestReplies, $latestAgents, $statuses, $variants) {
                $stat = $stats->get($ticket->id);
                $latest = $latestReplies[(int) $ticket->id] ?? null;
                $agent = $latest ? $latestAgents->get($latest->person_id) : null;

                return [
                    'id'             => (int) $ticket->id,
                    'subject'        => $ticket->title,
                    'customer'       => $ticket->customer ? $ticket->customer->full_name : '',
                    'agent'          => $agent ? $agent->full_name : '',
                    'responses'      => $stat ? (int) $stat->total : 0,
                    'last_reply'     => $latest ? (string) $latest->created_at : null,
                    'status'         => $ticket->status,
                    'status_label'   => $statuses[$ticket->status] ?? $ticket->status,
                    'status_variant' => $variants[$ticket->status] ?? 'info',
                ];
            }, $paged->items()),
            'current_page' => $paged->currentPage(),
            'last_page'    => max(1, $paged->lastPage()),
            'total'        => $paged->total(),
        ];
    }

    /**
     * [group value => count] for a ticket query; NULL groups count as NO_PRODUCT/0.
     */
    protected static function countBy($query, $column)
    {
        return static::keyRows($query->selectRaw("$column AS group_id, COUNT(*) AS total")->groupBy($column)->get());
    }

    protected static function keyRows($rows)
    {
        $counts = [];
        foreach ($rows as $row) {
            $key = (int) $row->group_id;
            $counts[$key] = ($counts[$key] ?? 0) + (int) $row->total;
        }

        return $counts;
    }

    /**
     * Counts per day of $days (Y-m-d labels) from a query on created_at.
     */
    protected static function perDay($query, array $days)
    {
        $counts = $query->selectRaw('DATE(created_at) AS day, COUNT(*) AS total')->groupBy('day')->pluck('total', 'day')->all();

        return array_map(fn($day) => (int) ($counts[$day] ?? 0), $days);
    }

    /**
     * Totals per hour (0-23) from a Reports::weekdayHours() grid.
     */
    protected static function perHour(array $grid)
    {
        $totals = array_fill(0, 24, 0);
        foreach ($grid as $hours) {
            foreach ($hours as $label => $count) {
                $totals[(int) $label] += $count;
            }
        }

        return $totals;
    }

    protected static function hourLabels()
    {
        return array_map(fn($hour) => ($hour % 12 ?: 12) . ($hour < 12 ? ' AM' : ' PM'), range(0, 23));
    }

    /**
     * Every Y-m-d from $from to $to.
     */
    protected static function days($from, $to)
    {
        $days = [];
        for ($day = new \DateTime($from); $day->format('Y-m-d') <= $to; $day->modify('+1 day')) {
            $days[] = $day->format('Y-m-d');
        }

        return $days;
    }

    protected static function between($from, $to)
    {
        return [$from . ' 00:00:00', $to . ' 23:59:59'];
    }

    protected static function prefix()
    {
        global $wpdb;

        return $wpdb->prefix;
    }
}
