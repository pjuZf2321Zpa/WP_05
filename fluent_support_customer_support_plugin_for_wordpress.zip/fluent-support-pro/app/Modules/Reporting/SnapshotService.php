<?php

namespace FluentSupportPro\App\Modules\Reporting;

use FluentSupportPro\App\Models\ReportSnapshot;
use FluentSupport\App\Modules\Reports\Reports;
use FluentSupport\App\Services\EmailNotification\Settings;

class SnapshotService
{
    const REPORT_TYPES = [
        'ticket_overview',
        'performance_overview',
        'workload_health',
        'product_insights',
        'response_activity',
    ];

    const MAX_RETENTION_DAYS = 15;

    // "No lower bound" for cumulative stat cards.
    const CUMULATIVE_START_DATE = '2000-01-01';

    // Charts use a trailing window. Unbounded would mean thousands of empty bars.
    const CHART_WINDOW_DAYS = 7;

    public static function takeSnapshot()
    {
        $snapshotTime = current_time('mysql');

        // Report queries apply the current user's mailbox restrictions, and cron can
        // run as a logged-in user (ALTERNATE_WP_CRON, `wp cron event run --user`).
        // Drop the user so a restricted view is never stored as the site-wide snapshot.
        $userId = get_current_user_id();

        if ($userId) {
            wp_set_current_user(0);
        }

        try {
            foreach (static::REPORT_TYPES as $reportType) {
                try {
                    $data = static::buildPayload($reportType);

                    ReportSnapshot::create([
                        'snapshot_time' => $snapshotTime,
                        'report_type'   => $reportType,
                        'period'        => '6h',
                        'data'          => $data,
                    ]);
                } catch (\Throwable $e) {

                }
            }
        } finally {
            if ($userId) {
                wp_set_current_user($userId);
            }
        }
    }

    // Stat cards are cumulative, charts use a bounded window. Each type stamps the
    // range keys it used (cumulative_range / chart_range).
    protected static function buildPayload($reportType)
    {
        $to = current_time('Y-m-d');
        $statFrom = static::CUMULATIVE_START_DATE;
        // " UTC" matches strtotime() to gmdate(). Without it the default timezone can shift chartFrom a day.
        $chartFrom = gmdate('Y-m-d', strtotime('-' . (static::CHART_WINDOW_DAYS - 1) . ' days', strtotime($to . ' UTC')));

        $cumulativeRange = ['from' => $statFrom, 'to' => $to];
        $chartRange = ['from' => $chartFrom, 'to' => $to];

        switch ($reportType) {
            case 'ticket_overview':
                return AdvancedReportService::getTicketOverview($statFrom, $to, null, $chartFrom, $to)
                    + ['cumulative_range' => $cumulativeRange, 'chart_range' => $chartRange];
            case 'performance_overview':
                $filters = AdvancedReportService::getPerformanceOverviewFilters();
                $agentIds = array_map(function ($agent) {
                    return $agent['id'];
                }, $filters['agents']);
                // No per-day average once responses are cumulative.
                $data = AdvancedReportService::getPerformanceOverview($statFrom, $to, $agentIds, 1, 6, $chartFrom, $to, false);
                return $data + ['cumulative_range' => $cumulativeRange, 'chart_range' => $chartRange];
            case 'workload_health':
                // A live gauge with no date range.
                return AdvancedReportService::getWorkloadHealth();
            case 'product_insights':
                // Per-product totals, not date-bucketed, so cumulative is fine.
                return AdvancedReportService::getProductInsights($statFrom, $to) + ['cumulative_range' => $cumulativeRange];
            case 'response_activity':
                // This report is a chart, so it keeps the bounded window.
                $data = AdvancedReportService::getResponseActivity($chartFrom, $to) + ['chart_range' => $chartRange];
                // The time-of-day heatmap shares this report's Live/Snapshot toggle.
                // Cron has no agent selection, so all three views are unfiltered.
                $data['activity_grid'] = static::buildActivityGrid($chartFrom, $to);
                return $data;
        }

        throw new \Exception('Unknown report type: ' . $reportType);
    }

    protected static function buildActivityGrid($from, $to)
    {
        return [
            'ticket'            => Reports::weekdayHours('ticket', $from, $to),
            'agent_response'    => Reports::weekdayHours('agent_response', $from, $to),
            'customer_response' => Reports::weekdayHours('customer_response', $from, $to),
        ];
    }

    public static function cleanup()
    {
        $settings = (new Settings())->globalBusinessSettings();
        $days = (int) $settings['report_snapshot_retention'];

        if ($days < 1 || $days > static::MAX_RETENTION_DAYS) {
            $days = static::MAX_RETENTION_DAYS;
        }

        $cutoff = gmdate('Y-m-d H:i:s', strtotime('-' . $days . ' days', strtotime(current_time('mysql'))));

        ReportSnapshot::where('snapshot_time', '<', $cutoff)->delete();
    }
}
