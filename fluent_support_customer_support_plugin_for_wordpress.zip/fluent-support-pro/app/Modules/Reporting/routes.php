<?php

defined('ABSPATH') || exit;

/**
 * @var \FluentSupport\Framework\Http\Router $router
 */

use FluentSupportPro\App\Modules\Reporting\ReportController;
use FluentSupportPro\App\Modules\Reporting\AdvancedReportPolicy;

$router->prefix('reports')->withPolicy('FluentSupport\App\Http\Policies\ReportPolicy')->group(function ($router) {
    $router->get('/agents-summary', [ReportController::class, 'agentsSummary']);
    $router->get('/day-time-stats', [ReportController::class, 'dayTimeStats']);
});

$router->prefix('mailbox-reports')->withPolicy('FluentSupport\App\Http\Policies\AdminSensitivePolicy')->group(function ($router) {
    $router->get('/tickets-growth', [ReportController::class, 'mailboxTicketsChart']);
    $router->get('/tickets-resolve-growth', [ReportController::class, 'mailboxClosedChart']);
    $router->get('/response-growth', [ReportController::class, 'mailboxRepliesChart']);
});

$router->prefix('advanced-reports')->withPolicy(AdvancedReportPolicy::class)->group(function ($router) {
    $router->get('/ticket-overview', [ReportController::class, 'ticketOverview']);
    $router->get('/response-activity', [ReportController::class, 'responseActivity']);
    $router->get('/product-insights', [ReportController::class, 'productInsights']);
    $router->get('/workload-health', [ReportController::class, 'workloadHealth']);
    $router->get('/performance-overview/filters', [ReportController::class, 'performanceFilters']);
    $router->get('/performance-overview', [ReportController::class, 'performanceOverview']);
    $router->get('/snapshots', [ReportController::class, 'snapshots']);
    $router->get('/snapshots/{id}', [ReportController::class, 'snapshot'])->int('id');
});
