<?php

namespace FluentSupportPro\App\Modules\SavedReplies;

use FluentSupport\App\Exceptions\ApiException;
use FluentSupport\App\Http\Controllers\Controller;
use FluentSupport\App\Models\SavedReply;
use FluentSupport\App\Modules\PermissionManager;
use FluentSupport\App\Services\Helper;
use FluentSupport\Framework\Http\Request\Request;

/**
 * Saved replies (reply templates): the Saved Replies page and the reply
 * composer's template picker. The author edits their own; fst_manage_settings
 * edits anyone's.
 */
class SavedReplyController extends Controller
{
    public function index(Request $request)
    {
        $page = SavedReply::orderBy('id', 'DESC')
            ->with(['person', 'product'])
            ->searchBy($request->getSafe('search', 'sanitize_text_field'))
            ->productBy($request->getInt('product_id'))
            ->paginate($request->getInt('per_page') ?: 10);

        $data = $page->toArray();
        $data['data'] = array_map([$this, 'format'], $page->items());

        return ['replies' => $data];
    }

    public function show($id)
    {
        return $this->format($this->find($id));
    }

    public function create(Request $request)
    {
        $reply = SavedReply::create($this->input($request) + ['created_by' => Helper::getAgentByUserId()->id]);

        return [
            'reply'   => $this->format($reply),
            'message' => __('Reply Template has been created', 'fluent-support-pro')
        ];
    }

    public function update(Request $request, $id)
    {
        $reply = $this->owned($id, __('You do not have permission to update this reply template', 'fluent-support-pro'));
        $reply->fill($this->input($request))->save();

        return [
            'message' => __('Reply Template has been updated', 'fluent-support-pro'),
            'reply'   => $this->format($reply)
        ];
    }

    public function delete($id)
    {
        $this->owned($id, __('You do not have permission to delete this reply template', 'fluent-support-pro'))->delete();

        return ['message' => __('Selected Reply Template has been deleted', 'fluent-support-pro')];
    }

    private function find($id)
    {
        $reply = SavedReply::find((int) $id);
        if (!$reply) {
            throw ApiException::notFound(__('No reply template found with this id', 'fluent-support-pro'));
        }

        return $reply;
    }

    /**
     * The reply, if the current agent wrote it or manages settings.
     */
    private function owned($id, $refusal)
    {
        $reply = $this->find($id);
        $agent = Helper::getAgentByUserId();

        if ((!$agent || (int) $reply->created_by !== (int) $agent->id) && !PermissionManager::currentUserCan('fst_manage_settings')) {
            throw ApiException::forbidden($refusal);
        }

        return $reply;
    }

    /**
     * Title and content (required), and the product.
     */
    private function input(Request $request)
    {
        $data = [
            'title'      => $request->getSafe('title', 'sanitize_text_field'),
            'content'    => wp_kses_post((string) $request->get('content', '')),
            'product_id' => $request->getInt('product_id') ?: null,
        ];

        if (!$data['title'] || !trim(wp_strip_all_tags($data['content']))) {
            throw ApiException::invalid(__('The title and the content are required.', 'fluent-support-pro'));
        }

        return $data;
    }

    private function format(SavedReply $reply)
    {
        return [
            'id'         => (int) $reply->id,
            'title'      => $reply->title,
            'content'    => $reply->content,
            'product_id' => $reply->product_id ? (int) $reply->product_id : null,
            'created_by' => (int) $reply->created_by,
            'created_at' => (string) $reply->created_at,
            'updated_at' => (string) $reply->updated_at,
            'person'     => $reply->person ? ['id' => (int) $reply->person->id, 'full_name' => $reply->person->full_name, 'photo' => $reply->person->photo] : null,
            'product'    => $reply->product ? ['id' => (int) $reply->product->id, 'title' => $reply->product->title] : null,
        ];
    }
}
