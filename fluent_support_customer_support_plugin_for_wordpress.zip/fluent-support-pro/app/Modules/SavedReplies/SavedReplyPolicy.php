<?php

namespace FluentSupportPro\App\Modules\SavedReplies;

use FluentSupport\App\Modules\PermissionManager;
use FluentSupport\Framework\Http\Request\Request;
use FluentSupport\Framework\Foundation\Policy;

class SavedReplyPolicy extends Policy
{
    /**
     * Changing templates needs the capability that gates the Saved Replies menu.
     * fst_manage_settings is also accepted because SavedReplyController uses it
     * as the "edit anyone's template" override.
     *
     * @param \FluentSupport\Framework\Http\Request\Request $request
     * @return Boolean
     */
    public function verifyRequest(Request $request)
    {
        return PermissionManager::userCan([
            'fst_manage_saved_replies',
            'fst_manage_settings'
        ]);
    }

    /**
     * Open to any agent with ticket access, since the reply composer loads saved
     * replies while answering a ticket.
     *
     * @param \FluentSupport\Framework\Http\Request\Request $request
     * @return Boolean
     */
    public function index(Request $request)
    {
        return PermissionManager::canAccessTicketRoutes();
    }

    /**
     * Same access as index().
     *
     * @param \FluentSupport\Framework\Http\Request\Request $request
     * @return Boolean
     */
    public function show(Request $request)
    {
        return PermissionManager::canAccessTicketRoutes();
    }
}
