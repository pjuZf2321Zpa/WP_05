<?php

defined('ABSPATH') || exit;

/**
 * @var \FluentSupport\Framework\Http\Router $router
 */

use FluentSupportPro\App\Modules\SavedReplies\SavedReplyController;
use FluentSupportPro\App\Modules\SavedReplies\SavedReplyPolicy;

$router->prefix('saved-replies')->withPolicy(SavedReplyPolicy::class)->group(function ($router) {
    $router->get('/', [SavedReplyController::class, 'index']);
    $router->post('/', [SavedReplyController::class, 'create']);
    $router->get('/{id}', [SavedReplyController::class, 'show'])->int('id');
    $router->put('/{id}', [SavedReplyController::class, 'update'])->int('id');
    $router->delete('/{id}', [SavedReplyController::class, 'delete'])->int('id');
});
