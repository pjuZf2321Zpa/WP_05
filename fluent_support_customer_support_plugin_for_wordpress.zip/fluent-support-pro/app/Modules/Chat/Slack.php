<?php

namespace FluentSupportPro\App\Modules\Chat;

use FluentSupport\App\Services\Helper;
use FluentSupport\Framework\Support\Arr;

/**
 * Slack: a new ticket starts a thread in the channel and later events reply
 * in it. Agents reply from the thread (ChatController::slack).
 */
class Slack extends Channel
{
    public $key = 'slack_settings';

    const DEFAULTS = [
        'bot_token'         => '',
        'channel'           => '',
        'channel_id'        => '',
        'signing_secret'    => '',
        'status'            => 'no',
        'ticket_assigned'   => 'no',
        'reply_from_slack'  => 'no',
        'fallback_agent_id' => ''
    ];

    const REQUIRED = ['bot_token', 'channel'];

    protected function channel()
    {
        return 'slack';
    }

    protected function driverInfo()
    {
        return [
            'title'       => __('Slack', 'fluent-support-pro'),
            'description' => __('Send notifications to Slack Channel and keep your support agents more active', 'fluent-support-pro') . '<p><a class="fs_doc_link" href="https://docs.fluentsupport.com/managing-tickets-using-slack" rel="noopener" target="_blank">Please read the documentation before you get started</a></p>'
        ];
    }

    protected function driverPriority()
    {
        return 2;
    }

    public static function token()
    {
        return self::webhookToken('_slack_webhook_token');
    }

    public function getFields()
    {
        return [
            'title'       => __('Slack Notification Settings', 'fluent-support-pro'),
            'fields'      => [
                'bot_token'         => [
                    'type'        => 'input-text',
                    'data_type'   => 'password',
                    'label'       => __('Slack Bot User OAuth Token', 'fluent-support-pro'),
                    'placeholder' => __('Slack Bot User OAuth Token', 'fluent-support-pro'),
                    'help'        => __('Enter your Slack Bot User OAuth Token Here', 'fluent-support-pro')
                ],
                'channel'           => [
                    'type'        => 'input-text',
                    'data_type'   => 'text',
                    'label'       => __('Slack Channel Name', 'fluent-support-pro'),
                    'placeholder' => __('Slack Channel Name', 'fluent-support-pro'),
                    'help'        => __('Input Channel Name', 'fluent-support-pro')
                ],
                'channel_id'        => [
                    'type'        => 'input-text',
                    'data_type'   => 'text',
                    'label'       => __('Slack Channel ID', 'fluent-support-pro'),
                    'placeholder' => __('Slack Channel ID', 'fluent-support-pro'),
                    'help'        => __('Input Channel ID', 'fluent-support-pro')
                ],
                'signing_secret'    => [
                    'type'        => 'input-text',
                    'data_type'   => 'password',
                    'label'       => __('Slack Signing Secret', 'fluent-support-pro'),
                    'placeholder' => __('Slack Signing Secret', 'fluent-support-pro'),
                    'help'        => __('(Optional) Enter the Signing Secret from your Slack App\'s "Basic Information" page. When provided, incoming Slack replies must pass HMAC-SHA256 verification. If this value is incorrect, Slack replies will be rejected.', 'fluent-support-pro')
                ],
                'signing_secret_notice' => [
                    'type'          => 'html-viewer',
                    'wrapper_class' => 'fs_warn_alert_wrapper',
                    'html'          => __('Slack Signing Secret is validated when Slack sends an event to this site. After saving, send a test reply from a Slack ticket thread to confirm the connection. If verification fails, the request will be rejected and a diagnostic reason will be recorded in the site logs.', 'fluent-support-pro'),
                    'dependency'    => [
                        'depends_on' => 'signing_secret',
                        'operator'   => '!=',
                        'value'      => ''
                    ]
                ],
                'status'            => [
                    'type'           => 'inline-checkbox',
                    'true_label'     => 'yes',
                    'false_label'    => 'no',
                    'label'          => '',
                    'checkbox_label' => __('Enable Slack Notifications', 'fluent-support-pro')
                ],
                'ticket_assigned'   => [
                    'type'           => 'inline-checkbox',
                    'true_label'     => 'yes',
                    'false_label'    => 'no',
                    'label'          => '',
                    'checkbox_label' => __('Enable Ticket Assigned Notification', 'fluent-support-pro')
                ],
                'reply_from_slack'  => [
                    'type'           => 'inline-checkbox',
                    'true_label'     => 'yes',
                    'false_label'    => 'no',
                    'label'          => '',
                    'checkbox_label' => __('Enable Reply Ticket From Slack', 'fluent-support-pro')
                ],
                'reply_from_html'   => [
                    'type'          => 'html-viewer',
                    'wrapper_class' => 'fs_highlight',
                    'html'          => '<p>Your support agents can easily reply from slack by replying to slack. </br>Please make sure support agent has slack id set to the profile. <a class="fs_doc_link" href="https://docs.fluentsupport.com/managing-tickets-using-slack" target="_blank">Learn More about this feature</a></p>' . sprintf(
                        /* translators: %1$s: opening <code> tag, %2$s: webhook URL, %3$s: closing </code> tag */
                        __('Please copy this URL %1$s%2$s%3$s to verify your Event Subscriptions in Slack', 'fluent-support-pro'), '<code>', self::webhookUrl('slack_response/' . self::token()), '</code>'),
                    'dependency'    => [
                        'depends_on' => 'reply_from_slack',
                        'operator'   => '=',
                        'value'      => 'yes'
                    ]
                ],
                'fallback_agent_id' => [
                    'type'        => 'agent-selectors',
                    'label'       => __('Fallback Agent for reply from Slack thread', 'fluent-support-pro'),
                    'placeholder' => __('Select Fallback Agent', 'fluent-support-pro'),
                    'dependency'  => [
                        'depends_on' => 'reply_from_slack',
                        'operator'   => '=',
                        'value'      => 'yes'
                    ]
                ]
            ],
            'button_text' => __('Save Slack Settings', 'fluent-support-pro')
        ];
    }

    /**
     * Refuses a signing secret that doesn't look like one (a label, a URL, spaces).
     */
    public function saveSettings($settings)
    {
        $secret = $settings['signing_secret'] = trim((string) Arr::get($settings, 'signing_secret', ''));
        if ($secret && (strlen($secret) < 16 || strlen($secret) > 128 || !preg_match('/^[A-Za-z0-9]+$/', $secret))) {
            return new \WP_Error('invalid_slack_signing_secret', __('Slack Signing Secret format looks invalid. Paste only the Signing Secret value from Slack Basic Information, without labels, spaces, or URLs.', 'fluent-support-pro'));
        }

        return parent::saveSettings($settings);
    }

    /**
     * X-Slack-Signature: 'v0=' . HMAC-SHA256(signing_secret, 'v0:{timestamp}:{body}'), at most
     * 5 minutes old. Without a signing secret only the URL token guards the webhook.
     */
    public function verifySignature($rawBody)
    {
        $secret = trim((string) $this->settings()['signing_secret']);
        if (!$secret) {
            return true;
        }

        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- compared exactly with hash_equals(); sanitizing would change the signed value.
        $signature = (string) ($_SERVER['HTTP_X_SLACK_SIGNATURE'] ?? '');
        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- checked as a 10-digit Unix time below.
        $timestamp = (string) ($_SERVER['HTTP_X_SLACK_REQUEST_TIMESTAMP'] ?? '');

        if (!$signature || !$timestamp) {
            $reason = 'missing_headers';
        } elseif (!preg_match('/^v0=[0-9a-f]{64}$/', $signature)) {
            $reason = 'invalid_signature_format';
        } elseif (!ctype_digit($timestamp) || strlen($timestamp) !== 10) {
            $reason = 'invalid_timestamp';
        } elseif (abs(time() - (int) $timestamp) > 300) {
            $reason = 'stale_timestamp';
        } elseif (!hash_equals('v0=' . hash_hmac('sha256', 'v0:' . $timestamp . ':' . $rawBody, $secret), $signature)) {
            $reason = 'signature_mismatch';
        } else {
            return true;
        }

        /**
         * Fires when Slack signature verification fails. The reason code carries no
         * secret, signature, timestamp or body data.
         *
         * @since 2.1.1
         * @param string $reason Failure reason code.
         */
        do_action('fluent_support/slack_signature_verification_failed', $reason);

        return false;
    }

    /**
     * The new-ticket message starts a thread; the other events reply in it,
     * and are skipped for tickets that have no thread.
     */
    protected function notify($type, array $data)
    {
        $ticket = $data['ticket'];

        if ($type == 'ticket_created') {
            $result = $this->send($this->ticketCreatedMessage($ticket, $data['person']));
            $threadId = is_array($result) ? Arr::get($result, 'ts') : false;
            if (!$threadId) {
                return false;
            }

            Helper::updateTicketMeta($ticket->id, '_slack_thread_id', $threadId);
            return true;
        }

        $threadId = Helper::getTicketMeta($ticket->id, '_slack_thread_id');
        $message = $threadId ? $this->message($type, $data) : false;

        return $message ? $this->send($message, $threadId) : false;
    }

    /**
     * Slack has one switch for assignment messages; the other events are
     * always on while Slack is.
     */
    protected function isEventEnabled($type, $settings)
    {
        return $type != 'ticket_assigned' || Arr::get($settings, 'ticket_assigned') == 'yes';
    }

    public function sendNotification($data, $type = false)
    {
        $message = $type == 'ticket_created' ? $this->ticketCreatedMessage($data['ticket'], $data['person']) : $this->message($type, $data);

        return $message ? $this->send($message) : false;
    }

    /**
     * Posts attachments to the channel, in the thread when given one.
     *
     * @return array|\WP_Error Slack's answer ('ts' is the message's thread id).
     */
    public function send($message, $threadId = false)
    {
        $settings = $this->settings();
        $data = [
            'attachments' => json_encode($message),
            'channel'     => $settings['channel'],
            'token'       => $settings['bot_token']
        ];
        if ($threadId) {
            $data['thread_ts'] = $threadId;
        }

        $data = apply_filters('fluent_support/slack_api_data', $data, $message);

        $response = wp_remote_post('https://slack.com/api/chat.postMessage', ['body' => $data]);
        if (is_wp_error($response)) {
            return $response;
        }

        $response = json_decode(wp_remote_retrieve_body($response), true);
        if (!$response) {
            return new \WP_Error('Slack_Error', __('Slack API Request Failed', 'fluent-support-pro'));
        }
        if (!empty($response['error'])) {
            return new \WP_Error('Slack_Error', $response['error']);
        }

        return $response;
    }

    /**
     * The thread reply for a close, a customer reply or an assignment.
     */
    private function message($type, array $data)
    {
        $ticket = $data['ticket'];
        $link = esc_url_raw($this->ticketLink($ticket));

        if ($type == 'ticket_closed') {
            $title = sprintf(__('Ticket Closed by Customer: %s', 'fluent-support-pro'), $data['person']->full_name);
            return [['fallback' => $title, 'color' => '#36a64f', 'title' => $title, 'title_link' => $link, 'ts' => time()]];
        }

        if ($type == 'response_added_by_customer') {
            $content = $this->plainText($data['response']->content);
            if ($ticket->agent && $slackUserId = $ticket->agent->getMeta('slack_user_id')) {
                $content = trim($content) . PHP_EOL . '<@' . $slackUserId . '>';
            }
            $title = sprintf(__('Replied by Customer: %s', 'fluent-support-pro'), $ticket->customer->full_name);
            return [['mrkdwn_in' => ['text'], 'fallback' => $title, 'color' => '#36a64f', 'title' => $title, 'text' => $content, 'title_link' => $link, 'ts' => time()]];
        }

        if ($type == 'ticket_assigned') {
            $agent = $data['person'];
            $assigner = $data['assigner'] ?? null;
            $agentName = $agent ? $this->name($agent) : '';
            $assignerName = $assigner ? $this->name($assigner) : '';
            if (!$agentName || !$assignerName) {
                return false;
            }

            $text = '(' . $ticket->title . ')' . ' has been assigned to ' . $agentName . ' by ' . $assignerName;
            if (isset($agent->user_id, $assigner->user_id) && $agent->user_id == $assigner->user_id) {
                $text = $assigner->full_name . ' assigned ' . $ticket->title . ' to self';
            }
            return [['fallback' => 'Ticket  Assigned to Agent: ' . $agentName, 'color' => '#36a64f', 'title' => $text, 'title_link' => $link, 'ts' => time()]];
        }

        return false;
    }

    private function ticketCreatedMessage($ticket, $person)
    {
        $fields = [];
        if ($ticket->product) {
            $fields[] = ['title' => __('Product', 'fluent-support-pro'), 'value' => $ticket->product->title, 'short' => true];
        }
        $fields[] = ['title' => __('Priority', 'fluent-support-pro'), 'value' => ucfirst($ticket->client_priority ?? ''), 'short' => true];
        foreach ($this->customFields($ticket) as $label => $value) {
            $fields[] = ['title' => $label, 'value' => strip_tags($value), 'short' => true];
        }

        return [[
            'mrkdwn_in' => ['text', 'pretext'],
            'fallback'  => '*New Ticket Submitted by ' . $person->full_name . ' (#' . $ticket->id . ')*',
            'color'     => '#36a64f',
            'pretext'   => '*New Ticket Submitted by ' . $person->full_name . '  <' . esc_url_raw($this->ticketLink($ticket)) . '|#' . $ticket->id . '>*',
            'title'     => esc_html($ticket->title),
            'text'      => $this->plainText($ticket->content),
            'fields'    => $fields,
            'ts'        => time(),
        ]];
    }

    private function name($person)
    {
        return $person->full_name ?: trim($person->first_name . ' ' . $person->last_name);
    }
}
