<?php

namespace FluentSupportPro\App\Modules\Chat;

use FluentSupport\App\Services\Helper;
use FluentSupport\App\Services\Integrations\NotificationIntegrationBase;
use FluentSupport\Framework\Support\Arr;

/**
 * What the chat channels (Slack, Telegram, Discord, Twilio) share: settings
 * with defaults, the four ticket events they post about, the "is this event
 * on" check and their entry in the integrations list. A channel says how it
 * builds and sends one event's message (sendNotification) and which settings
 * it can't run without (REQUIRED).
 */
abstract class Channel extends NotificationIntegrationBase
{
    /**
     * Integration settings key, e.g. 'slack_settings'.
     *
     * @var string
     */
    public $key = '';

    const DEFAULTS = [];

    /**
     * Settings the channel can't be switched on without.
     */
    const REQUIRED = [];

    /**
     * Name passed to fluent_support/should_send_notification ('slack', ...).
     */
    abstract protected function channel();

    /**
     * The integrations list entry: title, description and filter priority (its place in the list).
     */
    abstract protected function driverInfo();

    abstract protected function driverPriority();

    /**
     * Build and send the message for one event.
     *
     * @param array $data ticket, person, and response or assigner
     * @param string|false $type
     */
    abstract public function sendNotification($data, $type = false);

    /**
     * Listens to the ticket events and adds the channel to the integrations list.
     */
    public function register()
    {
        add_action('fluent_support/ticket_created', function ($ticket, $customer) {
            $this->maybeNotify('ticket_created', $ticket, $customer, ['ticket' => $ticket, 'person' => $customer]);
        }, 20, 2);

        add_action('fluent_support/ticket_closed', function ($ticket, $person) {
            $this->maybeNotify('ticket_closed', $ticket, $person, ['ticket' => $ticket, 'person' => $person]);
        }, 20, 2);

        add_action('fluent_support/response_added_by_customer', function ($response, $ticket, $customer) {
            $this->maybeNotify('response_added_by_customer', $ticket, $customer, ['ticket' => $ticket, 'response' => $response, 'person' => $customer]);
        }, 20, 3);

        add_action('fluent_support/agent_assigned_to_ticket', function ($agent, $ticket, $assigner) {
            $this->maybeNotify('ticket_assigned', $ticket, $agent, ['person' => $agent, 'ticket' => $ticket, 'assigner' => $assigner]);
        }, 20, 3);

        // The title and description are translated, so they're built when the filter runs (after init).
        add_filter('fluent_support/integration_drivers', function ($drivers) {
            $drivers[] = ['key' => $this->key] + $this->driverInfo();
            return $drivers;
        }, $this->driverPriority(), 1);
    }

    public function settings()
    {
        return wp_parse_args(Helper::getIntegrationOption($this->key, []) ?: [], static::DEFAULTS);
    }

    public function getSettings($withFields = false)
    {
        $data = ['settings' => $this->settings()];
        if ($withFields) {
            $data['fields'] = $this->getFields();
        }

        return $data;
    }

    /**
     * Saves the settings, switched off when a required one is empty.
     */
    public function saveSettings($settings)
    {
        foreach (static::REQUIRED as $key) {
            if (empty($settings[$key])) {
                $settings['status'] = 'no';
            }
        }

        return $this->save($settings);
    }

    public function isNotificationActivated($type, $ticket = null, $person = null)
    {
        $settings = $this->get();
        if (!$settings || Arr::get($settings, 'status') != 'yes' || !$this->isEventEnabled($type, $settings)) {
            return false;
        }

        return apply_filters('fluent_support/should_send_notification', true, $this->channel(), $type, $ticket, $person);
    }

    protected function maybeNotify($type, $ticket, $person, array $data)
    {
        if (!$this->isNotificationActivated($type, $ticket, $person)) {
            return false;
        }

        return $this->notify($type, $data);
    }

    /**
     * Sends one event's message. Slack overrides this to keep its thread.
     */
    protected function notify($type, array $data)
    {
        return $this->sendNotification($data, $type);
    }

    /**
     * Default: the event is listed in notification_events.
     */
    protected function isEventEnabled($type, $settings)
    {
        $events = Arr::get($settings, 'notification_events', []);

        return is_array($events) && in_array($type, $events, true);
    }

    /**
     * The ticket's public custom fields as label => value (a removed field shows its key).
     */
    protected function customFields($ticket)
    {
        $labels = apply_filters('fluent_support/ticket_custom_fields', []);
        $fields = [];
        foreach ((array) $ticket->customData('public', true) as $key => $value) {
            $fields[Arr::get($labels, $key . '.label', $key)] = is_array($value) ? implode(',', $value) : $value;
        }

        return $fields;
    }

    protected function ticketLink($ticket)
    {
        return Helper::getPortalAdminBaseUrl() . 'tickets/' . $ticket->id . '/view';
    }

    protected function plainText($html)
    {
        return preg_replace("/\n\s+/", "\n", rtrim(html_entity_decode(strip_tags((string) $html))));
    }

    /**
     * The URL token of an inbound webhook, made on first use.
     */
    public static function webhookToken($optionKey, $length = 12)
    {
        $token = Helper::getIntegrationOption($optionKey, false);
        if (!$token) {
            $token = substr(str_replace('-', '', wp_generate_uuid4()), 0, $length);
            Helper::updateIntegrationOption($optionKey, $token);
        }

        return $token;
    }

    public static function webhookUrl($path)
    {
        $app = Helper::FluentSupport();

        return rest_url($app->config->get('app.rest_namespace') . '/' . $app->config->get('app.rest_version') . '/public/' . $path);
    }
}
