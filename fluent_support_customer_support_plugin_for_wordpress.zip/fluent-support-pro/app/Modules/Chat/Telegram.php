<?php

namespace FluentSupportPro\App\Modules\Chat;

use FluentSupport\App\Services\Helper;
use FluentSupport\Framework\Support\Arr;

/**
 * Telegram: messages go to the assigned agent's chat, or the default chat.
 * Agents reply to a message in Telegram (ChatController::telegram); for that
 * the bot's webhook is registered with Telegram when the settings are saved.
 */
class Telegram extends Channel
{
    public $key = 'telegram_settings';

    const DEFAULTS = [
        'bot_token'           => '',
        'chat_id'             => '',
        'notification_events' => [],
        'test_message'        => '',
        'reply_from_telegram' => 'no',
        'status'              => 'no',
        'webhook_activated'   => 'no'
    ];

    protected function channel()
    {
        return 'telegram';
    }

    protected function driverInfo()
    {
        return [
            'title'       => __('Telegram', 'fluent-support-pro'),
            'description' => __('Send Telegram notifications to Group, Channel or individual person inbox and reply from Telegram inbox', 'fluent-support-pro') . '<p><a class="fs_doc_link" href="https://docs.fluentsupport.com/managing-tickets-using-telegram" rel="noopener" target="_blank">Please read the documentation before you get started</a></p>'
        ];
    }

    protected function driverPriority()
    {
        return 1;
    }

    public static function token()
    {
        return self::webhookToken('_telegram_webhook_token');
    }

    public function getFields()
    {
        return [
            'title'       => __('Telegram Notification Settings', 'fluent-support-pro'),
            'fields'      => [
                'bot_token'            => [
                    'type'        => 'input-text',
                    'data_type'   => 'password',
                    'label'       => __('Bot Token', 'fluent-support-pro'),
                    'placeholder' => __('Bot Token', 'fluent-support-pro'),
                    'help'        => __('Enter your Telegram Bot Token', 'fluent-support-pro')
                ],
                'chat_id'              => [
                    'type'        => 'input-text',
                    'data_type'   => 'text',
                    'placeholder' => __('Chat ID', 'fluent-support-pro'),
                    'label'       => __('Default Group Chat ID', 'fluent-support-pro'),
                    'help'        => __('Enter your Telegram API channel user ID, You can also use message id. Please check documentation for more details.', 'fluent-support-pro')
                ],
                'notification_events'  => [
                    'type'    => 'checkbox-group',
                    'label'   => __('Notification Events', 'fluent-support-pro'),
                    'options' => [
                        'ticket_created'             => __('Ticket Created', 'fluent-support-pro'),
                        'ticket_closed'              => __('Ticket Closed', 'fluent-support-pro'),
                        'response_added_by_customer' => __('Replied By Customer', 'fluent-support-pro'),
                        'ticket_assigned'            => __('Agent Assigned To Ticket', 'fluent-support-pro')
                    ]
                ],
                'test_message'         => [
                    'placeholder' => __('Test Message to send right now', 'fluent-support-pro'),
                    'type'        => 'input-text',
                    'data_type'   => 'textarea',
                    'label'       => __('Test Message (Optional)', 'fluent-support-pro'),
                    'help'        => __('Enter message to send now as test', 'fluent-support-pro')
                ],
                'status'               => [
                    'type'           => 'inline-checkbox',
                    'true_label'     => 'yes',
                    'false_label'    => 'no',
                    'label'          => '',
                    'checkbox_label' => __('Enable Telegram Notifications', 'fluent-support-pro')
                ],
                'reply_from_telegram'  => [
                    'type'           => 'inline-checkbox',
                    'true_label'     => 'yes',
                    'false_label'    => 'no',
                    'label'          => '',
                    'checkbox_label' => __('Enable Reply From Telegram (Agent can directly reply from telegram)', 'fluent-support-pro'),
                    'dependency'     => [
                        'depends_on' => 'status',
                        'operator'   => '=',
                        'value'      => 'yes'
                    ]
                ],
                'reply_from_html'      => [
                    'type'          => 'html-viewer',
                    'wrapper_class' => 'fs_highlight',
                    'html'          => __('Your support agents can easily reply from telegram by replying to telegram. </br>Please make sure support agent has telegram id set to the profile. <a class="fs_doc_link" href="https://docs.fluentsupport.com/managing-tickets-using-telegram" target="_blank">Learn More about this feature</a>', 'fluent-support-pro'),
                    'dependency'    => [
                        'depends_on' => 'reply_from_telegram',
                        'operator'   => '=',
                        'value'      => 'yes'
                    ]
                ],
                'reply_webhook_status' => [
                    'type'       => 'html-viewer',
                    'html'       => __('Webhook is currently activated', 'fluent-support-pro'),
                    'dependency' => [
                        'depends_on' => 'webhook_activated',
                        'operator'   => '=',
                        'value'      => 'yes'
                    ]
                ]
            ],
            'button_text' => __('Save Telegram Settings', 'fluent-support-pro')
        ];
    }

    /**
     * Checks the bot token with Telegram, sends the test message, and keeps the
     * reply webhook registered exactly while replies are on. Any failure saves
     * the settings switched off and answers Telegram's error.
     */
    public function saveSettings($settings)
    {
        $previous = $this->settings();
        $settings['test_message'] = Arr::get($settings, 'test_message', '');
        $complete = !empty($settings['chat_id']) && !empty($settings['bot_token']);
        $wantsWebhook = $complete && Arr::get($settings, 'status') == 'yes' && Arr::get($settings, 'reply_from_telegram') == 'yes';

        // Drop the old webhook when replies go off or the bot changes.
        $settings['webhook_activated'] = $previous['webhook_activated'];
        if ($previous['webhook_activated'] == 'yes' && (!$wantsWebhook || $previous['bot_token'] != Arr::get($settings, 'bot_token'))) {
            $removed = $this->deleteWebhook($previous['bot_token']);
            $settings['webhook_activated'] = is_wp_error($removed) || empty($removed['ok']) ? 'yes' : 'no';
        }

        if (!$complete) {
            return $this->save(['status' => 'no', 'webhook_activated' => 'no'] + $settings);
        }

        $error = $this->api('getMe', [], $settings['bot_token']);
        if (!is_wp_error($error) && $settings['test_message']) {
            $sent = $this->api('sendMessage', ['chat_id' => $settings['chat_id'], 'parse_mode' => 'none', 'text' => $this->plainText($settings['test_message'])], $settings['bot_token']);
            $error = is_wp_error($sent) ? new \WP_Error('telegram_settings_error', __('Your api key is right but, the message could not be sent to the provided chat id. Error: ', 'fluent-support-pro') . $sent->get_error_message()) : $sent;
        }
        if (!is_wp_error($error) && $wantsWebhook) {
            $error = $this->setWebhook($settings);
            if (!is_wp_error($error)) {
                $settings['webhook_activated'] = 'yes';
            }
        }

        $settings['test_message'] = '';
        if (is_wp_error($error)) {
            $this->save(['status' => 'no', 'webhook_activated' => 'no'] + $settings);
            return $error;
        }

        return $this->save($settings);
    }

    public function sendNotification($data, $type = false)
    {
        $ticket = $data['ticket'];
        $link = '<a href="' . esc_url($this->ticketLink($ticket)) . '">';

        if ($type == 'ticket_created') {
            $message = '<b>New Ticket Submitted by ' . esc_html($data['person']->full_name) . ' (#' . absint($ticket->id) . ')</b>' . "\n";
            $message .= '<code>' . esc_html(\mb_substr($ticket->title, 0, 30)) . '</code>' . "\n";
            $message .= esc_html($this->plainText($ticket->content)) . "\n";
            if ($ticket->product) {
                $message .= '<i>#' . esc_html(preg_replace('~[^\pL\d]+~u', '_', $ticket->product->title)) . '</i>' . "\n";
            }
            foreach ($this->customFields($ticket) as $label => $value) {
                $message .= '<i>' . esc_html($label) . ': ' . esc_html($value) . '</i>' . "\n";
            }
            $message .= '<u>' . $link . 'View Ticket</a></u>';
        } elseif ($type == 'response_added_by_customer') {
            $message = '<b>Reply: ' . esc_html(\mb_substr($ticket->title, 0, 30)) . ' #' . absint($ticket->id) . '</b>' . "\n";
            $message .= esc_html($this->plainText($data['response']->content)) . "\n";
            $message .= '<u>' . $link . 'View Reply</a></u>';
        } elseif ($type == 'ticket_closed') {
            $message = '<b>Ticket  Closed by ' . esc_html($data['person']->full_name) . '</b>' . "\n";
            $message .= '<pre>' . esc_html($ticket->title) . '</pre> ' . ' ' . $link . '(#' . absint($ticket->id) . ')</a>';
        } elseif ($type == 'ticket_assigned') {
            $person = $data['person'];
            $assigner = $data['assigner'] ?: $person;
            $message = $person->user_id == $assigner->user_id
                ? '<b>You assign a ticket to yourself</b>' . "\n"
                : '<b>Ticket Assigned to ' . esc_html($person->full_name) . ' by ' . esc_html($assigner->full_name) . '</b>' . "\n";
            $message .= '<pre>' . esc_html($ticket->title) . '</pre> ' . ' ' . $link . '(#' . absint($ticket->id) . ')</a>';
        } else {
            return false;
        }

        // The assigned agent's own chat when they set one, else the default chat.
        $settings = $this->settings();
        $chatId = ($ticket->agent ? $ticket->agent->getMeta('telegram_chat_id') : '') ?: $settings['chat_id'];

        return $this->api('sendMessage', ['chat_id' => $chatId, 'parse_mode' => 'html', 'text' => $message]);
    }

    /**
     * One Bot API call.
     *
     * @return array|\WP_Error Telegram's answer when ok.
     */
    public function api($method, array $args = [], $botToken = '')
    {
        $botToken = $botToken ?: $this->settings()['bot_token'];
        if (!$botToken) {
            return new \WP_Error(300, 'Token is required', []);
        }

        if (isset($args['text'])) {
            $args['text'] = urlencode($args['text']);
        }

        // Sent inside the request that fired the event, so it must never wait long.
        $response = wp_remote_get(add_query_arg($args, 'https://api.telegram.org/bot' . $botToken . '/' . $method), [
            'timeout' => (int) apply_filters('fluent_support/telegram_request_timeout', 10)
        ]);
        if (is_wp_error($response)) {
            return $response;
        }

        $result = \json_decode(wp_remote_retrieve_body($response), true);
        if (!isset($result['ok'])) {
            return new \WP_Error(300, 'Unknown API error from Telegram', $result);
        }
        if (empty($result['ok'])) {
            return new \WP_Error($result['error_code'], $result['description'], $result);
        }

        return $result;
    }

    /**
     * Registers the reply webhook with a secret token, unless Telegram already
     * has this URL and the stored secret.
     */
    private function setWebhook($settings)
    {
        $url = self::webhookUrl('telegram_bot_response/' . self::token());
        if (wp_parse_url($url, PHP_URL_SCHEME) !== 'https') {
            return new \WP_Error('invalid_webhook_url', 'Telegram webhook URL must use HTTPS: ' . preg_replace('~/telegram_bot_response/[^/?#]+~', '/telegram_bot_response/[redacted]', $url));
        }

        $secret = self::secretToken();
        if ($settings['webhook_activated'] == 'yes') {
            $info = $this->api('getWebhookInfo', [], $settings['bot_token']);
            if (!is_wp_error($info) && Arr::get($info, 'result.url') === $url && hash_equals($secret, (string) self::registeredSecret())) {
                return $info;
            }
        }

        $result = $this->api('setWebhook', ['url' => rawurlencode($url), 'secret_token' => rawurlencode($secret)], $settings['bot_token']);
        if (!is_wp_error($result)) {
            Helper::updateIntegrationOption('_telegram_webhook_secret_token_registered', $secret);
        }

        return $result;
    }

    private function deleteWebhook($botToken)
    {
        $result = $this->api('deleteWebhook', ['drop_pending_updates' => 'true'], $botToken);
        Helper::updateIntegrationOption('_telegram_webhook_secret_token_registered', false);

        return $result;
    }

    /**
     * The secret_token given to setWebhook, made on first use. Telegram allows
     * A-Za-z0-9_- (a 64-letter alphabet keeps % 64 unbiased).
     */
    private static function secretToken()
    {
        $token = Helper::getIntegrationOption('_telegram_webhook_secret_token', false);
        if (!$token) {
            $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-';
            $token = '';
            foreach (str_split(random_bytes(64)) as $byte) {
                $token .= $alphabet[ord($byte) % 64];
            }
            Helper::updateIntegrationOption('_telegram_webhook_secret_token', $token);
        }

        return $token;
    }

    /**
     * The secret Telegram was given. Until one is registered, older webhooks
     * keep working on the URL token alone.
     */
    public static function registeredSecret()
    {
        return Helper::getIntegrationOption('_telegram_webhook_secret_token_registered', false);
    }

    /**
     * X-Telegram-Bot-Api-Secret-Token must equal the registered secret.
     */
    public function verifySignature()
    {
        $expected = self::registeredSecret();
        if (!$expected) {
            return true;
        }

        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- checked against Telegram's token format and compared exactly with hash_equals().
        $header = (string) ($_SERVER['HTTP_X_TELEGRAM_BOT_API_SECRET_TOKEN'] ?? '');

        return strlen($header) <= 256 && preg_match('/^[A-Za-z0-9_-]+$/', $header) && hash_equals($expected, $header);
    }

    /**
     * Reads an agent's reply to one of the bot's messages: the ticket id from
     * the replied-to message, the agent from the sender's Telegram id (never the
     * display name, which anyone can set), and a [close] command.
     *
     * @return array|\WP_Error ticket_id, agent_id, response_text, command
     */
    public static function parseReply($payload)
    {
        if (!is_array($payload) || !Arr::get($payload, 'message.text')) {
            return new \WP_Error('invalid', 'Invalid Payload');
        }

        $replyToText = Arr::get($payload, 'message.reply_to_message.text');
        $senderId = Arr::get($payload, 'message.from.id');
        if (!$replyToText) {
            return new \WP_Error('no_reply_found', 'Not a reply to message');
        }

        $agentId = $senderId ? \FluentSupport\App\Models\Meta::where('object_type', 'person_meta')->where('key', 'telegram_chat_id')->where('value', $senderId)->value('object_id') : null;
        if (!$agentId) {
            return new \WP_Error('no_agent', 'No Matched Agent found');
        }

        $ticketId = false;
        if (preg_match('/\(#(\d+)\)/u', $replyToText, $matches)) {
            $ticketId = absint($matches[1]);
        } elseif (preg_match_all('/(?:^|[\s(])#(\d+)\b/u', $replyToText, $matches) && !empty($matches[1])) {
            $ticketId = absint(end($matches[1]));
        }
        if (!$ticketId) {
            return new \WP_Error('no_ticket_id', 'No Ticket ID found from Payload.');
        }

        $text = str_replace('\n', PHP_EOL, (string) Arr::get($payload, 'message.text', ''));
        $command = strpos($text, '[close]') !== false ? 'close_ticket' : '';
        $text = str_replace('[close]', '', $text);
        if ($text) {
            $text = wpautop((new \FluentSupport\App\Services\Parser\Parsedown)->text($text) ?: $text);
        }

        return ['ticket_id' => $ticketId, 'response_text' => $text, 'agent_id' => $agentId, 'command' => $command];
    }
}
