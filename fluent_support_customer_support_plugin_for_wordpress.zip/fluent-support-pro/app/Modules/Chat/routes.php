<?php

defined('ABSPATH') || exit;

/**
 * @var \FluentSupport\Framework\Http\Router $router
 */

use FluentSupportPro\App\Modules\Chat\ChatController;

// Agents' replies from chat. Public: each one checks its URL token and the platform's signature.
$router->prefix('public')->withPolicy('FluentSupport\App\Http\Policies\PublicPolicy')->group(function ($router) {
    $router->post('telegram_bot_response/{token}', [ChatController::class, 'telegram'])->alphaNumDash('token');
    $router->post('slack_response/{token}', [ChatController::class, 'slack'])->alphaNumDash('token');
    $router->post('twilio-response/{token}', [ChatController::class, 'twilio'])->alphaNumDash('token');
});
