<?php

namespace FluentSupportPro\App\Modules\Chat;

use FluentSupport\App\Exceptions\ApiException;
use FluentSupport\App\Http\Controllers\Controller;
use FluentSupport\App\Models\Agent;
use FluentSupport\App\Models\Conversation;
use FluentSupport\App\Models\Meta;
use FluentSupport\App\Models\Ticket;
use FluentSupport\App\Services\Parser\Parsedown;
use FluentSupport\App\Services\Tickets\AgentTicketAccess;
use FluentSupport\App\Services\Tickets\ResponseService;
use FluentSupport\App\Services\Tickets\TicketService;
use FluentSupport\Framework\Http\Request\Request;
use FluentSupport\Framework\Support\Arr;
use FluentSupportPro\App\Services\ProHelper;

/**
 * Agents' replies from Telegram, Slack and WhatsApp (public webhooks). Each one
 * checks the URL token and the platform's signature, needs the channel's reply
 * switch on, maps the sender to an agent (never by display name) and saves the
 * reply only when that agent can open the ticket.
 */
class ChatController extends Controller
{
    /**
     * A reply to one of the bot's messages; [close] closes the ticket.
     * Ignored payloads still answer 200, so Telegram doesn't retry them.
     */
    public function telegram(Request $request, $token)
    {
        $telegram = new Telegram();
        if (!hash_equals(Telegram::token(), (string) $token)) {
            throw new ApiException('Bot Token could not be verified', 403);
        }
        if (!apply_filters('fluent_support/verify_webhook_signature_telegram', $telegram->verifySignature(), $request)) {
            throw new ApiException(__('Invalid request signature.', 'fluent-support-pro'), 403);
        }

        $result = ['message' => __('Response has been successfully recorded', 'fluent-support-pro'), 'status' => true, 'data' => false];
        if ($telegram->settings()['reply_from_telegram'] != 'yes') {
            return $result;
        }

        $payload = $request->all();
        $reply = Telegram::parseReply($payload);
        if (is_wp_error($reply)) {
            /*
             * Fires when a Telegram reply payload can't be parsed.
             *
             * @since v1.0.0
             * @param \WP_Error $reply
             * @param array $payload
             */
            do_action('fluent_support/telegram_payload_error', $reply, $payload);
            return $result;
        }

        $ticket = Ticket::find($reply['ticket_id']);
        $agent = Agent::find($reply['agent_id']);
        // Every mailbox posts to the same chat, so the mailbox restrictions are checked here.
        if (!$ticket || !$agent || !(new AgentTicketAccess())->canAccess($agent, $ticket)) {
            return $result;
        }

        $result['data'] = ['conversation_type' => 'response', 'content' => $reply['response_text'], 'source' => 'telegram'];
        $this->reply($agent, $ticket, $result['data'], $reply['command'] == 'close_ticket');

        return $result;
    }

    /**
     * Slack's Events API: the URL check, then agents' replies in a ticket's
     * thread. #note or #internal saves a note; [close] closes the ticket.
     */
    public function slack(Request $request, $token)
    {
        $slack = new Slack();
        if (!apply_filters('fluent_support/verify_webhook_signature_slack', $slack->verifySignature($request->getContent()), $request)) {
            throw new ApiException(__('Invalid request signature.', 'fluent-support-pro'), 403);
        }

        if ($request->getSafe('type', 'sanitize_text_field') === 'url_verification') {
            return new \WP_REST_Response($request->getSafe('challenge', 'sanitize_text_field'), 200, ['Content-Type' => 'text/plain; charset=utf-8']);
        }

        if (!hash_equals(Slack::token(), (string) $token)) {
            throw new ApiException('Bot Token could not be verified', 403);
        }

        $result = ['message' => 'received', 'result' => false];
        $settings = $slack->settings();
        $event = (array) $request->get('event', []);
        $threadId = (string) Arr::get($event, 'thread_ts');
        if ($settings['reply_from_slack'] != 'yes' || Arr::get($event, 'type') != 'message' || !$threadId || Arr::get($event, 'channel') != $settings['channel_id']) {
            return $result;
        }

        $ticketId = Meta::where('object_type', 'ticket_meta')->where('key', '_slack_thread_id')->where('value', $threadId)->value('object_id');
        $ticket = $ticketId ? Ticket::find($ticketId) : null;
        $messageId = (string) Arr::get($event, 'client_msg_id');
        if (!$ticket || ($messageId && Conversation::where('ticket_id', $ticket->id)->where('message_id', $messageId)->exists())) {
            return $result;
        }

        $slackUserId = Arr::get($event, 'user');
        $agentId = $slackUserId ? (Meta::where('object_type', 'person_meta')->where('key', 'slack_user_id')->where('value', $slackUserId)->value('object_id') ?: absint($settings['fallback_agent_id'])) : 0;
        $agent = $agentId ? Agent::find($agentId) : null;
        // All mailboxes share one channel, so the mailbox restrictions are checked here.
        if (!$agent || !(new AgentTicketAccess())->canAccess($agent, $ticket)) {
            return $result;
        }

        $text = (string) Arr::get($event, 'text', '');
        $type = 'response';
        if (strpos($text, '#note') !== false || strpos($text, '#internal') !== false) {
            $type = 'note';
            $text = str_replace(['#note', '#internal'], '', $text);
        }
        $close = strpos($text, '[close]') !== false;
        $text = str_replace('[close]', '', $text);
        if ($text) {
            $text = (new Parsedown)->text($text) ?: $text;
        }

        $this->reply($agent, $ticket, ['conversation_type' => $type, 'content' => $text, 'source' => 'slack', 'message_id' => $messageId], $close);
        $result['result'] = true;

        return $result;
    }

    /**
     * A WhatsApp message with ##TICKET_ID## in it. Twilio shows the plain-text
     * answer to the agent.
     */
    public function twilio(Request $request, $token)
    {
        $twilio = new Twilio();
        if ($twilio->settings()['reply_from_whatsapp'] !== 'yes') {
            throw ApiException::invalid(__('Reply from WhatsApp is disabled', 'fluent-support-pro'));
        }
        if (!hash_equals(Twilio::token(), (string) $token)) {
            throw ApiException::invalid(__('Invalid webhook token', 'fluent-support-pro'));
        }

        // Keyed on the IP only: keying on the path token would let anyone make unlimited buckets.
        $remoteIp = sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'] ?? ''));
        if (!ProHelper::checkRateLimit('twilio_ip_' . $remoteIp, 60, 60)) {
            throw new ApiException(__('Too many requests.', 'fluent-support-pro'), 429);
        }

        // Only the signed POST body: merged request input could carry unsigned query params.
        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- verified by Twilio's signature below.
        $message = wp_unslash($_POST);
        if (!$twilio->verifySignature($request->header('x-twilio-signature'), $message)) {
            throw new ApiException(__('Invalid Twilio request signature', 'fluent-support-pro'), 403);
        }

        // WhatsApp accepts only text/plain.
        header('Content-Type:text/plain');

        $body = $message['Body'] ?? null;
        $from = $message['From'] ?? null;
        if (!is_string($body)) {
            return 'No message body found';
        }
        if (!preg_match('/^##(\d+)##/', $body, $match)) {
            return 'No ticket id declared to message body, declare ticket id like this: ##TICKET_ID_NUMBER##';
        }
        if (!is_string($from)) {
            return 'No sender number found';
        }

        // Twilio retries slow callbacks and signed requests can be replayed.
        $messageSid = sanitize_text_field($message['MessageSid'] ?? '');
        $existing = $messageSid ? Conversation::where('source', 'whatsapp')->where('message_id', $messageSid)->first() : null;
        if ($existing) {
            return 'Response Already Added To Ticket No. ' . $existing->ticket_id;
        }

        $agent = $twilio->agentFor(str_ireplace('whatsapp:', '', $from));
        if (!$agent) {
            return 'No agent is registered for this number';
        }

        $ticket = Ticket::find((int) $match[1]);
        if (!$ticket) {
            return 'Sorry No Ticket Found With Ticket No. ' . (int) $match[1];
        }
        if (!(new AgentTicketAccess())->canAccess($agent, $ticket)) {
            return 'You do not have permission to reply to Ticket No. ' . $ticket->id;
        }

        $this->reply($agent, $ticket, ['conversation_type' => 'response', 'content' => str_replace($match[0], '', $body), 'source' => 'whatsapp', 'message_id' => $messageSid]);

        return 'Response Added Successfully To Ticket No. ' . $ticket->id;
    }

    /**
     * Saves the reply (when it has text) and closes the ticket when asked.
     */
    private function reply(Agent $agent, Ticket $ticket, array $data, $close = false)
    {
        if (!empty($data['content'])) {
            (new ResponseService())->createResponse($data, $agent, $ticket);
        }
        if ($close) {
            (new TicketService())->close($ticket, $agent);
        }
    }
}
