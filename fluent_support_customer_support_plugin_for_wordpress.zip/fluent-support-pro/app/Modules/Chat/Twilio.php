<?php

namespace FluentSupportPro\App\Modules\Chat;

use FluentSupport\App\Models\Agent;
use FluentSupport\App\Models\Meta;
use FluentSupport\App\Services\Tickets\AgentTicketAccess;

/**
 * Twilio (WhatsApp): messages go to the agents' WhatsApp numbers. Agents
 * reply with ##TICKET_ID## in the message (ChatController::twilio).
 */
class Twilio extends Channel
{
    public $key = 'twilio_settings';

    const DEFAULTS = [
        'account_sid'         => '',
        'auth_token'          => '',
        'from_number'         => '',
        'notification_events' => [],
        'fallback_agent_id'   => '',
        'status'              => 'no',
        'reply_from_whatsapp' => 'no'
    ];

    const REQUIRED = ['account_sid', 'auth_token', 'from_number'];

    protected function channel()
    {
        return 'twilio';
    }

    protected function driverInfo()
    {
        return [
            'title'       => __('Twilio', 'fluent-support-pro'),
            'description' => __('Send notifications to your agents WhatsApp number using twilio and make them more active', 'fluent-support-pro') . '<p><a class="fs_doc_link" href="https://docs.fluentsupport.com/whatsapp-integration-via-twilio" rel="noopener" target="_blank">Please read the documentation before you get started</a></p>'
        ];
    }

    protected function driverPriority()
    {
        return 4;
    }

    /**
     * 32 hex characters: the token travels in the URL, so keep it hard to guess.
     */
    public static function token()
    {
        return self::webhookToken('_twilio_webhook_token', 32);
    }

    public function getFields()
    {
        return [
            'title'       => __('Twilio Settings', 'fluent-support-pro'),
            'fields'      => [
                'account_sid'         => [
                    'type'        => 'input-text',
                    'data_type'   => 'text',
                    'label'       => __('Twilio Account SID', 'fluent-support-pro'),
                    'placeholder' => __('Twilio Account SID', 'fluent-support-pro'),
                    'help'        => __('Enter your Twilio Account SID Here', 'fluent-support-pro')
                ],
                'auth_token'          => [
                    'type'        => 'input-text',
                    'data_type'   => 'password',
                    'label'       => __('Twilio Auth Token', 'fluent-support-pro'),
                    'placeholder' => __('Twilio Auth Token', 'fluent-support-pro'),
                    'help'        => __('Enter your Twilio Auth Token Here', 'fluent-support-pro')
                ],
                'from_number'         => [
                    'type'        => 'input-text',
                    'data_type'   => 'number',
                    'label'       => __('Twilio WhatsApp Number', 'fluent-support-pro'),
                    'placeholder' => __('Twilio WhatsApp Number', 'fluent-support-pro'),
                    'help'        => __('Enter your Twilio WhatsApp Number Here', 'fluent-support-pro')
                ],
                'notification_events' => [
                    'type'    => 'checkbox-group',
                    'label'   => __('Notification Events', 'fluent-support-pro'),
                    'options' => [
                        'ticket_created'             => __('Ticket Created', 'fluent-support-pro'),
                        'ticket_closed'              => __('Ticket Closed', 'fluent-support-pro'),
                        'response_added_by_customer' => __('Replied By Customer', 'fluent-support-pro'),
                        'ticket_assigned'            => __('Ticket Assigned To Agent', 'fluent-support-pro'),
                    ]
                ],
                'status'              => [
                    'type'           => 'inline-checkbox',
                    'true_label'     => 'yes',
                    'false_label'    => 'no',
                    'label'          => '',
                    'checkbox_label' => __('Enable Twilio Integration', 'fluent-support-pro')
                ],
                'reply_from_whatsapp' => [
                    'type'           => 'inline-checkbox',
                    'true_label'     => 'yes',
                    'false_label'    => 'no',
                    'label'          => '',
                    'checkbox_label' => __('Enable Reply From WhatsApp', 'fluent-support-pro'),
                    'dependency'     => [
                        'depends_on' => 'status',
                        'operator'   => '=',
                        'value'      => 'yes'
                    ]
                ],
                'reply_from_html'     => [
                    'type'       => 'html-viewer',
                    'html'       => sprintf(
                        /* translators: %s: the webhook URL */
                        __('%s Copy this URL to make your agent able to reply ticket from WhatsApp.', 'fluent-support-pro'),
                        '<strong><code>' . esc_html(self::webhookUrl('twilio-response/' . self::token())) . '</code></strong>'
                    ),
                    'dependency' => [
                        'depends_on' => 'reply_from_whatsapp',
                        'operator'   => '=',
                        'value'      => 'yes'
                    ]
                ],
                'fallback_agent_id'   => [
                    'type'        => 'agent-selectors',
                    'label'       => __('Fallback Agent for reply from WhatsApp message', 'fluent-support-pro'),
                    'placeholder' => __('Select Fallback Agent', 'fluent-support-pro'),
                    'dependency'  => [
                        'depends_on' => 'status',
                        'operator'   => '=',
                        'value'      => 'yes'
                    ]
                ]
            ],
            'button_text' => __('Save Twilio Settings', 'fluent-support-pro')
        ];
    }

    /**
     * An assignment goes to the assigned agent; every other event to each
     * agent with a number who can open the ticket.
     */
    public function sendNotification($data, $type = false)
    {
        $ticket = $data['ticket'];
        $link = '_' . esc_url_raw($this->ticketLink($ticket)) . '_';

        if ($type == 'ticket_assigned') {
            $person = $data['person'];
            $assigner = $data['assigner'];
            if (!$person || !$assigner) {
                return false;
            }
            $message = $assigner->user_id == $person->user_id
                ? '*You assign (' . $ticket->title . ') to yourself*' . "\n"
                : '*(' . $ticket->title . ') has been assigned to ' . $person->full_name . ' by ' . $assigner->full_name . '*' . "\n";

            return $this->send($message . $link, [$person->getMeta('whatsapp_number')]);
        }

        if ($type == 'ticket_created') {
            $message = '*New Ticket Created By ' . sanitize_text_field($ticket->customer->full_name) . '*' . "\n" . '```' . $ticket->title . '#' . $ticket->id . '```' . "\n" . strip_tags($ticket->content) . "\n" . $link;
        } elseif ($type == 'response_added_by_customer') {
            $message = '*' . sanitize_text_field($ticket->customer->full_name) . ' Added a New Reply To Ticket No. #' . $ticket->id . '*' . "\n" . strip_tags($data['response']->content) . "\n" . $link;
        } elseif ($type == 'ticket_closed') {
            $message = '*' . $data['person']->full_name . ' Closed Ticket No. #' . $ticket->id . '*';
        } else {
            return false;
        }

        $numbers = [];
        $access = new AgentTicketAccess();
        foreach (Meta::where('object_type', 'person_meta')->where('key', 'whatsapp_number')->where('value', '!=', '')->get(['object_id', 'value']) as $row) {
            $agent = Agent::find($row->object_id);
            if ($agent && $access->canAccess($agent, $ticket)) {
                $numbers[] = $row->value;
            }
        }

        return $this->send($message, $numbers);
    }

    /**
     * Sends the message to each number; a failed number doesn't stop the rest.
     *
     * @return array|\WP_Error the last answer, or the last error
     */
    private function send($message, array $numbers)
    {
        $settings = $this->settings();
        $result = false;

        foreach (array_filter($numbers) as $number) {
            $result = wp_remote_post('https://api.twilio.com/2010-04-01/Accounts/' . $settings['account_sid'] . '/Messages.json', [
                'headers' => [
                    'Authorization' => 'Basic ' . base64_encode($settings['account_sid'] . ':' . $settings['auth_token']),
                    'Content-Type'  => 'application/x-www-form-urlencoded',
                ],
                'body'    => [
                    'From' => 'whatsapp:' . $settings['from_number'],
                    'To'   => 'whatsapp:' . $number,
                    'Body' => $message,
                ],
            ]);
        }

        return $result;
    }

    /**
     * The agent with this WhatsApp number, else the fallback agent.
     */
    public function agentFor($number)
    {
        $agentId = Meta::where('object_type', 'person_meta')->where('key', 'whatsapp_number')->where('value', $number)->value('object_id')
            ?: absint($this->settings()['fallback_agent_id']);

        return $agentId ? Agent::find($agentId) : null;
    }

    /**
     * X-Twilio-Signature is a base64 HMAC-SHA1, keyed with the auth token, over
     * the URL plus the sorted POST params. Twilio signs the URL saved in its
     * console, which a proxy or the site URL setting can make differ from ours,
     * so the URL as configured and as requested are tried, with and without
     * the scheme's default port. No auth token: refused.
     */
    public function verifySignature($signature, array $params)
    {
        $authToken = trim((string) $this->settings()['auth_token']);
        if (!$authToken || !$signature || !is_string($signature)) {
            return false;
        }

        $urls = [self::webhookUrl('twilio-response/' . self::token())];
        $host = isset($_SERVER['HTTP_HOST']) ? sanitize_text_field(wp_unslash($_SERVER['HTTP_HOST'])) : '';
        $uri = isset($_SERVER['REQUEST_URI']) ? wp_unslash($_SERVER['REQUEST_URI']) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- part of the signed URL; used only in the HMAC.
        if ($host && $uri) {
            // A TLS-terminating proxy can change the scheme PHP sees.
            $urls[] = 'https://' . $host . $uri;
            $urls[] = 'http://' . $host . $uri;
        }

        ksort($params);
        $signed = '';
        foreach ($params as $key => $value) {
            // Repeated params arrive as an array; Twilio de-duplicates and sorts them.
            $values = is_array($value) ? array_unique($value) : [$value];
            sort($values);
            foreach ($values as $item) {
                $signed .= $key . (is_scalar($item) ? (string) $item : '');
            }
        }

        foreach ($urls as $url) {
            $parts = wp_parse_url($url);
            if (empty($parts['host'])) {
                continue;
            }
            $scheme = $parts['scheme'] ?? 'http';
            $path = ($parts['path'] ?? '') . (isset($parts['query']) ? '?' . $parts['query'] : '');
            $port = $parts['port'] ?? ($scheme === 'https' ? 443 : 80);
            foreach ([$scheme . '://' . $parts['host'] . $path, $scheme . '://' . $parts['host'] . ':' . $port . $path] as $candidate) {
                if (hash_equals(base64_encode(hash_hmac('sha1', $candidate . $signed, $authToken, true)), $signature)) {
                    return true;
                }
            }
        }

        return false;
    }
}
