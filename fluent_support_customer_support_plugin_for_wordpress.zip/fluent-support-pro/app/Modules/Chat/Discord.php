<?php

namespace FluentSupportPro\App\Modules\Chat;

/**
 * Discord: posts to a channel's incoming webhook. Notifications only.
 */
class Discord extends Channel
{
    public $key = 'discord_settings';

    const DEFAULTS = [
        'webhook_url'         => '',
        'notification_events' => [],
        'status'              => 'no'
    ];

    const REQUIRED = ['webhook_url'];

    const COLOR = 6746192;

    protected function channel()
    {
        return 'discord';
    }

    protected function driverInfo()
    {
        return [
            'title'       => __('Discord', 'fluent-support-pro'),
            'description' => __('Send notifications to Discord Channel and keep your support agents more active', 'fluent-support-pro') . '<p><a class="fs_doc_link" href="https://docs.fluentsupport.com/managing-tickets-using-discord" rel="noopener" target="_blank">Please read the documentation before you get started</a></p>'
        ];
    }

    protected function driverPriority()
    {
        return 3;
    }

    public function getFields()
    {
        return [
            'title'       => __('Discord Notification Settings', 'fluent-support-pro'),
            'fields'      => [
                'webhook_url'         => [
                    'type'        => 'input-text',
                    'data_type'   => 'text',
                    'label'       => __('Discord Incoming Webhook URL', 'fluent-support-pro'),
                    'placeholder' => __('Discord Incoming Webhook URL', 'fluent-support-pro'),
                    'help'        => __('Enter your Discord Incoming Webhook URL Here', 'fluent-support-pro')
                ],
                'notification_events' => [
                    'type'    => 'checkbox-group',
                    'label'   => __('Notification Events', 'fluent-support-pro'),
                    'options' => [
                        'ticket_created'             => __('Ticket Created', 'fluent-support-pro'),
                        'ticket_closed'              => __('Ticket Closed', 'fluent-support-pro'),
                        'response_added_by_customer' => __('Replied By Customer', 'fluent-support-pro'),
                        'ticket_assigned'            => __('Ticket Assigned To Agent', 'fluent-support-pro'),
                    ]
                ],
                'status'              => [
                    'type'           => 'inline-checkbox',
                    'true_label'     => 'yes',
                    'false_label'    => 'no',
                    'label'          => '',
                    'checkbox_label' => __('Enable Discord Notifications', 'fluent-support-pro')
                ]
            ],
            'button_text' => __('Save Discord Settings', 'fluent-support-pro')
        ];
    }

    public function sendNotification($data, $type = false)
    {
        $ticket = $data['ticket'];
        $embed = ['title' => esc_html($ticket->title), 'url' => esc_url_raw($this->ticketLink($ticket)), 'color' => self::COLOR];

        if ($type == 'ticket_created' || $type == 'response_added_by_customer') {
            $fields = [['name' => __('Priority', 'fluent-support-pro'), 'value' => ucfirst($ticket->client_priority ?? ''), 'inline' => true]];
            if ($ticket->product) {
                $fields[] = ['name' => __('Product', 'fluent-support-pro'), 'value' => '#' . preg_replace('~[^\pL\d]+~u', '_', $ticket->product->title), 'inline' => true];
            }

            if ($type == 'ticket_created') {
                foreach ($this->customFields($ticket) as $label => $value) {
                    $fields[] = ['name' => $label, 'value' => strip_tags($value), 'inline' => true];
                }
                $content = '*' . sprintf(__('New Ticket Submitted by %s', 'fluent-support-pro'), $data['person']->full_name) . ' (#' . $ticket->id . ')*';
                $embed['description'] = sanitize_text_field($ticket->content);
            } else {
                $content = '*New Reply Added To ' . $ticket->title . ' (#' . $ticket->id . ')*';
                $embed['description'] = sanitize_text_field($data['response']->content);
            }
            $embed = ['fields' => $fields] + $embed;
        } elseif ($type == 'ticket_closed') {
            $content = '*' . $data['person']->full_name . ' Closed ' . $ticket->title . ' (#' . $ticket->id . '*)';
            $embed['title'] = esc_html(\mb_substr($ticket->title, 0, 30));
        } elseif ($type == 'ticket_assigned' && $data['person'] && $data['assigner']) {
            $person = $data['person'];
            $content = $data['assigner']->user_id == $person->user_id
                ? '*' . $person->full_name . ' Assign ' . $ticket->title . ' (#' . $ticket->id . '*) to self'
                : '*' . $person->full_name . ' Assigned to ' . $ticket->title . ' (#' . $ticket->id . '*) by ' . $data['assigner']->full_name;
            $embed['title'] = esc_html(\mb_substr($ticket->title, 0, 30));
        } else {
            return false;
        }

        $response = wp_remote_post($this->settings()['webhook_url'], [
            'body' => ['payload_json' => json_encode(['embeds' => [$embed], 'content' => $content])]
        ]);

        return is_wp_error($response) ? $response : wp_remote_retrieve_body($response);
    }
}
