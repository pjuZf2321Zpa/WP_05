<?php

namespace FluentSupportPro\App\Modules\AutoClose;

use FluentSupport\App\Exceptions\ApiException;
use FluentSupport\App\Http\Controllers\Controller;
use FluentSupport\App\Services\Helper;
use FluentSupport\Framework\Http\Request\Request;
use FluentSupportPro\App\Services\AutoCloseService;

/**
 * The Auto Close settings page. The closing itself runs on cron
 * (AutoCloseService::maybeCloseTickets()).
 */
class AutoCloseController extends Controller
{
    public function show()
    {
        return [
            'settings' => AutoCloseService::getSettings(),
            'fields'   => AutoCloseService::getSettingsFields()
        ];
    }

    /**
     * Saves the known settings. When enabled: the inactive days, no tag both
     * included and excluded, a fallback agent when waiting customers are not
     * skipped, and a body when a closing response is added.
     */
    public function save(Request $request)
    {
        $input = (array) $request->get('settings', []);
        $settings = [];
        foreach (AutoCloseService::getSettings() as $key => $default) {
            $value = $input[$key] ?? $default;
            if ($key === 'close_response_body') {
                $settings[$key] = wp_kses_post(Helper::decodeNonMarkupEntities((string) $value));
            } elseif (is_array($default)) {
                $settings[$key] = array_values(array_filter(array_map('intval', (array) $value)));
            } else {
                $settings[$key] = sanitize_text_field((string) $value);
            }
        }

        if ($settings['enabled'] === 'yes') {
            if ((int) $settings['inactive_days'] < 1) {
                throw ApiException::invalid(__('Inactive days must be at least 1', 'fluent-support-pro'));
            }
            if (array_intersect($settings['include_tags'], $settings['exclude_tags'])) {
                throw ApiException::invalid(__('Please use different tags in include and exclude tags field', 'fluent-support-pro'));
            }
            if ($settings['exclude_if_customer_waiting'] === 'no' && !$settings['closed_by_agent']) {
                throw ApiException::invalid(__('Default fallback agent is required', 'fluent-support-pro'));
            }
            if ($settings['add_close_response'] === 'yes' && !trim(wp_strip_all_tags($settings['close_response_body']))) {
                throw ApiException::invalid(__('Response body is required', 'fluent-support-pro'));
            }
        }

        AutoCloseService::saveSettings($settings);

        return [
            'message'  => __('Settings have been updated', 'fluent-support-pro'),
            'settings' => AutoCloseService::getSettingsFields()
        ];
    }
}
