<?php

defined('ABSPATH') || exit;

/**
 * @var \FluentSupport\Framework\Http\Router $router
 */

use FluentSupportPro\App\Modules\AutoClose\AutoCloseController;

$router->prefix('settings')->withPolicy('FluentSupport\App\Http\Policies\AdminSettingsPolicy')->group(function ($router) {
    $router->get('/auto-close', [AutoCloseController::class, 'show']);
    $router->post('/auto-close', [AutoCloseController::class, 'save']);
});
