<?php

namespace FluentSupportPro\App\Modules\Workflows;

use FluentSupport\App\Models\Activity;
use FluentSupport\App\Models\Ticket;
use FluentSupport\App\Services\Helper;
use FluentSupportPro\App\Models\Workflow;
use FluentSupportPro\App\Models\WorkflowAction;
use FluentSupportPro\App\Modules\Workflows\Actions\BaseAction;
use FluentSupportPro\App\Modules\Workflows\Triggers\BaseTrigger;

/**
 * Runs workflows. Automatic workflows start from their trigger's event
 * (register()); manual ones from WorkflowController::run().
 *
 * Extension points: fluent_support/workflow_trigger_classes and
 * fluent_support/workflow_action_classes add trigger and action classes;
 * fluent_support/run_action_{name} runs an action with no class;
 * fluent_support/workflow_triggered fires after each run.
 *
 * Each run is written to the activity log (fs_activities): event_type
 * fluent_support/workflow_ran or fluent_support/workflow_failed, object_type
 * workflow, object_id the workflow id. It follows the activity log's
 * retention and its "disable logs" setting.
 */
class Runner
{
    /**
     * Workflows started by other workflows stop at this depth.
     */
    const MAX_DEPTH = 3;

    /**
     * Ids of the automatic workflows running in this request. An action can fire
     * the event that started its workflow (a reply fires "agent response"), so a
     * running workflow is never started again.
     *
     * @var int[]
     */
    private static $running = [];

    public static function register()
    {
        foreach (self::triggers() as $trigger) {
            $trigger->listen();
        }
    }

    /**
     * @return BaseTrigger[] by event key, in the editor's order
     */
    public static function triggers()
    {
        $classes = apply_filters('fluent_support/workflow_trigger_classes', [
            Triggers\TicketCreated::class,
            Triggers\CustomerReplied::class,
            Triggers\TicketReopened::class,
            Triggers\AgentReplied::class,
            Triggers\AgentAssigned::class,
            Triggers\FeedbackReceived::class,
            Triggers\TicketClosed::class,
        ]);

        $triggers = [];
        foreach ($classes as $class) {
            $trigger = new $class();
            $triggers[$trigger->key] = $trigger;
        }

        return $triggers;
    }

    /**
     * @return BaseAction[] by action name, in the editor's order
     */
    public static function actions()
    {
        $classes = apply_filters('fluent_support/workflow_action_classes', [
            Actions\AddResponse::class,
            Actions\AssignAgent::class,
            Actions\AssignAgentGroup::class,
            Actions\AddNote::class,
            Actions\CloseTicket::class,
            Actions\AddTags::class,
            Actions\RemoveTags::class,
            Actions\DeleteTicket::class,
            Actions\BlockCustomer::class,
            Actions\OutgoingWebhook::class,
            Actions\AddBookmarks::class,
            Actions\RemoveBookmarks::class,
            Actions\ChangeMailbox::class,
            Actions\AddProduct::class,
            Actions\ChangePriority::class,
            Actions\CrmAddTags::class,
            Actions\CrmAddLists::class,
            Actions\CrmRemoveTags::class,
            Actions\CrmRemoveLists::class,
            Actions\CrmRunAutomation::class,
        ]);

        $actions = [];
        foreach ($classes as $class) {
            $action = new $class();
            if ($action->available()) {
                $actions[$action->name] = $action;
            }
        }

        return $actions;
    }

    /**
     * Runs the published automatic workflows of $trigger whose conditions match.
     */
    public static function runAutomatic(BaseTrigger $trigger, array $context)
    {
        if (count(self::$running) >= self::MAX_DEPTH || empty($context['ticket'])) {
            return;
        }

        $workflows = Workflow::where('status', 'published')
            ->where('trigger_type', 'automatic')
            ->where('trigger_key', $trigger->key)
            ->get();

        foreach ($workflows as $workflow) {
            if (in_array((int) $workflow->id, self::$running, true)) {
                continue;
            }

            self::$running[] = (int) $workflow->id;
            try {
                if (!Conditions::match($workflow, $context)) {
                    continue;
                }
                $failed = self::run($workflow, $context['ticket']);
                if ($failed !== false) {
                    $ticket = Ticket::find($context['ticket']->id) ?: $context['ticket'];
                    self::logRun($workflow, $ticket, $failed, null, $trigger->title());
                    do_action('fluent_support/workflow_triggered', $workflow, $ticket, $context['customer'] ?? null, [
                        'source' => 'automatic',
                        'event'  => $trigger->key
                    ]);
                }
            } catch (\Throwable $e) {
                self::log($workflow, $context['ticket'], 'run', $e);
            } finally {
                array_pop(self::$running);
            }
        }
    }

    /**
     * Runs the workflow's actions on the ticket, in their saved order. A failing
     * action is logged and the next one still runs. The run stops when an
     * action deletes the ticket.
     *
     * @param WorkflowAction[]|null $actions the workflow's actions, when already loaded
     * @return array|false the failed actions as ['action' => name, 'message' => ...],
     *                     or false when there was nothing to run
     */
    public static function run(Workflow $workflow, Ticket $ticket, $actions = null)
    {
        $actions = $actions === null ? $workflow->orderedActions() : $actions;
        if (!$actions) {
            return false;
        }

        $handlers = self::actions();
        $failed = [];

        foreach ($actions as $action) {
            // Fresh for each action: the one before may have changed or deleted it.
            $ticket = Ticket::find($ticket->id);
            if (!$ticket) {
                break;
            }

            try {
                if (isset($handlers[$action->action_name])) {
                    $handlers[$action->action_name]->run($action, $ticket, $workflow);
                } else {
                    do_action('fluent_support/run_action_' . $action->action_name, $action, $workflow, $ticket);
                }
            } catch (\Throwable $e) {
                self::log($workflow, $ticket, 'action "' . $action->action_name . '"', $e);
                $failed[] = ['action' => $action->action_name, 'message' => $e->getMessage()];
            }
        }

        // toBase() skips the updated_at bump: running is not editing.
        Workflow::where('id', $workflow->id)->toBase()->update(['last_ran_at' => current_time('mysql')]);

        return $failed;
    }

    /**
     * Writes one run to the activity log.
     *
     * @param array       $failed from run()
     * @param object|null $person the agent who ran a manual workflow
     * @param string      $how    the trigger's title, or "Manual run"
     */
    public static function logRun(Workflow $workflow, Ticket $ticket, array $failed, $person, $how)
    {
        if (Helper::areLogsDisabled('_activity_settings')) {
            return;
        }

        $workflowLink = '<a class="fs_link_trans" href="#edit_workflow">' . esc_html($workflow->title) . '</a>';
        /* translators: %s is the ticket title */
        $ticketLink = '<a class="fs_link_trans fs_tk" href="#view_ticket" data-ticket-id="' . (int) $ticket->id . '">' . esc_html(sprintf(__('Ticket: %s', 'fluent-support-pro'), $ticket->title)) . '</a>';

        /* translators: 1: workflow name, 2: ticket link, 3: what started it (a trigger name or "Manual run") */
        $description = sprintf(__('Workflow %1$s ran on %2$s (%3$s)', 'fluent-support-pro'), $workflowLink, $ticketLink, esc_html($how));

        if ($failed) {
            $actions = self::actions();
            $lines = array_map(function ($failure) use ($actions) {
                $title = isset($actions[$failure['action']]) ? $actions[$failure['action']]->title() : $failure['action'];
                return esc_html($title . ': ' . $failure['message']);
            }, $failed);
            /* translators: %s is the list of failed actions with their errors */
            $description .= ' ' . sprintf(__('Failed: %s', 'fluent-support-pro'), implode('; ', $lines));
        }

        Activity::create([
            'event_type'  => $failed ? 'fluent_support/workflow_failed' : 'fluent_support/workflow_ran',
            'person_id'   => $person ? $person->id : null,
            'person_type' => $person ? $person->person_type : null,
            'object_id'   => $workflow->id,
            'object_type' => 'workflow',
            'description' => $description,
        ]);
    }

    private static function log($workflow, $ticket, $what, \Throwable $e)
    {
        error_log(sprintf(
            'FluentSupport Workflow: %s (workflow #%d, ticket #%d) failed — %s',
            $what,
            $workflow->id,
            $ticket->id ?? 0,
            $e->getMessage()
        ));
    }
}
