<?php

namespace FluentSupportPro\App\Modules\Workflows\Actions;

use FluentSupport\App\Models\Ticket;
use FluentSupport\App\Services\Helper;
use FluentSupportPro\App\Models\Workflow;
use FluentSupportPro\App\Models\WorkflowAction;

/**
 * Deletes the ticket; no action runs after it.
 */
class DeleteTicket extends BaseAction
{
    public $name = 'fs_delete_ticket';

    public function title()
    {
        return __('Delete Ticket', 'fluent-support-pro');
    }

    public function defaults()
    {
        return ['ticket_delete_html' => ''];
    }

    public function fields(Workflow $workflow)
    {
        return [
            'ticket_delete_html' => [
                'type' => 'html-viewer',
                'html' => '<p><br />' . esc_html__('Ticket will be deleted permanently and no further action will run', 'fluent-support-pro') . '</p>'
            ]
        ];
    }

    public function run(WorkflowAction $action, Ticket $ticket, Workflow $workflow)
    {
        (new \FluentSupport\App\Services\Tickets\TicketService())->deleteTicket($ticket, Helper::getCurrentAgent());
    }
}
