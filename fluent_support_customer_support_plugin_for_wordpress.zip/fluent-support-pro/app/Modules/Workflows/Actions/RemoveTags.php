<?php

namespace FluentSupportPro\App\Modules\Workflows\Actions;

use FluentSupport\App\Models\Ticket;
use FluentSupportPro\App\Models\Workflow;
use FluentSupportPro\App\Models\WorkflowAction;

class RemoveTags extends AddTags
{
    public $name = 'fs_action_remove_tags';

    public function title()
    {
        return __('Remove Tag(s)', 'fluent-support-pro');
    }

    public function run(WorkflowAction $action, Ticket $ticket, Workflow $workflow)
    {
        if ($tagIds = $this->setting($action, 'tag_ids')) {
            (new \FluentSupport\App\Services\Tickets\TicketService())->removeTags($ticket, $tagIds);
        }
    }
}
