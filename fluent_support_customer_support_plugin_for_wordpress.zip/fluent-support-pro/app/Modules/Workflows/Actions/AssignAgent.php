<?php

namespace FluentSupportPro\App\Modules\Workflows\Actions;

use FluentSupport\App\Models\Agent;
use FluentSupport\App\Models\Ticket;
use FluentSupport\App\Services\Helper;
use FluentSupport\App\Services\Tickets\TicketService;
use FluentSupportPro\App\Models\Workflow;
use FluentSupportPro\App\Models\WorkflowAction;

/**
 * Assigns the ticket to an agent, or unassigns it. With skip_if_exist an
 * assigned ticket keeps its agent.
 */
class AssignAgent extends BaseAction
{
    public $name = 'fs_action_assign_agent';

    public function title()
    {
        return __('Assign Agent', 'fluent-support-pro');
    }

    public function defaults()
    {
        return ['agent_id' => '', 'skip_if_exist' => 'yes'];
    }

    public function fields(Workflow $workflow)
    {
        return [
            'agent_id'      => [
                'type'          => 'agent-selectors',
                'label'         => __('Select Agent', 'fluent-support-pro'),
                'extra_options' => [['id' => 'unassigned', 'title' => __('Unassigned', 'fluent-support-pro')]]
            ],
            'skip_if_exist' => [
                'type'           => 'inline-checkbox',
                'true_label'     => 'yes',
                'false_label'    => 'no',
                'checkbox_label' => __('Skip if ticket already have a agent assigned', 'fluent-support-pro')
            ]
        ];
    }

    public function run(WorkflowAction $action, Ticket $ticket, Workflow $workflow)
    {
        $agentId = $this->setting($action, 'agent_id');

        if ($agentId === 'unassigned') {
            (new TicketService())->unassign($ticket, Helper::getCurrentAgent());
            return;
        }

        // Actions saved before skip_if_exist existed have no value and keep reassigning.
        if ($ticket->agent_id && $this->setting($action, 'skip_if_exist') === 'yes') {
            return;
        }

        if ($agent = Agent::find($agentId)) {
            (new TicketService())->assignAgent($ticket, $agent, Helper::getCurrentAgent());
        }
    }
}
