<?php

namespace FluentSupportPro\App\Modules\Workflows\Actions;

use FluentSupport\App\Models\Conversation;
use FluentSupport\App\Models\Person;
use FluentSupport\App\Models\Ticket;
use FluentSupport\Framework\Support\Arr;
use FluentSupportPro\App\Models\Workflow;
use FluentSupportPro\App\Models\WorkflowAction;
use FluentSupportPro\App\Services\Integrations\OutgoingWebhook\OutgoingWebhookApi;

/**
 * Posts the chosen ticket data to a URL. The body passes through
 * fluent_support/outgoing_webhook_data.
 */
class OutgoingWebhook extends BaseAction
{
    public $name = 'fs_trigger_webhook';

    public function title()
    {
        return __('Trigger Outgoing Webhook', 'fluent-support-pro');
    }

    public function defaults()
    {
        return ['content-type' => 'application/json', 'included_data' => ['ticket', 'customer']];
    }

    public function fields(Workflow $workflow)
    {
        return [
            'webhook_url'   => [
                'type'        => 'input-text',
                'label'       => __('Webhook URL', 'fluent-support-pro'),
                'data-type'   => 'url',
                'placeholder' => __('Your webhook URL', 'fluent-support-pro')
            ],
            'content-type'  => [
                'label'       => __('Content Type', 'fluent-support-pro'),
                'type'        => 'input-options',
                'placeholder' => __('Select Content Type', 'fluent-support-pro'),
                'options'     => [
                    ['id' => 'application/x-www-form-urlencoded', 'title' => 'FORM'],
                    ['id' => 'application/json', 'title' => 'JSON'],
                ]
            ],
            'included_data' => [
                'type'    => 'checkbox-group',
                'label'   => __('Included Data', 'fluent-support-pro'),
                'options' => [
                    'ticket'              => __('Ticket Information', 'fluent-support-pro'),
                    'customer'            => __('Customer Information', 'fluent-support-pro'),
                    'agent'               => __('Agent Information', 'fluent-support-pro'),
                    'last_agent_response' => __('Last Response Data From Agent', 'fluent-support-pro'),
                    'last_response'       => __('Last Response From Customer / Agent', 'fluent-support-pro'),
                    'custom_fields'       => __('Custom Fields', 'fluent-support-pro')
                ]
            ]
        ];
    }

    public function run(WorkflowAction $action, Ticket $ticket, Workflow $workflow)
    {
        $url = $this->setting($action, 'webhook_url');
        $included = (array) $this->setting($action, 'included_data', []);
        if (!$url || !$included) {
            return;
        }

        $personKeys = (new Person())->getFillable();
        $replyKeys = array_merge((new Conversation())->getFillable(), ['created_at', 'updated_at']);
        $data = [];

        if (in_array('ticket', $included, true)) {
            $data['ticket'] = Arr::only($ticket->toArray(), array_merge($ticket->getFillable(), ['id', 'created_at', 'updated_at']));
        }
        if (in_array('customer', $included, true)) {
            $data['customer'] = $ticket->customer ? Arr::only($ticket->customer->toArray(), $personKeys) : [];
        }
        if (in_array('agent', $included, true)) {
            $data['agent'] = $ticket->agent ? Arr::only($ticket->agent->toArray(), $personKeys) : [];
        }
        if (in_array('last_agent_response', $included, true)) {
            $reply = $ticket->getLastAgentResponse();
            $data['last_agent_response'] = $reply ? Arr::only((array) $reply, $replyKeys) : [];
        }
        if (in_array('last_response', $included, true)) {
            $reply = $ticket->getLastResponse();
            $data['last_response'] = $reply ? Arr::only((array) $reply, array_merge($replyKeys, ['id'])) : [];
        }
        if (in_array('custom_fields', $included, true)) {
            $data['custom_fields'] = $ticket->customData('admin', false) ?: [];
        }

        if (!$data) {
            return;
        }

        $data = apply_filters('fluent_support/outgoing_webhook_data', $data, $action, $ticket);

        // wp_safe_remote_post() refuses local and private addresses.
        $result = OutgoingWebhookApi::sendData($url, $data, $this->setting($action, 'content-type', 'application/json'), 'POST');
        if (is_wp_error($result)) {
            throw new \Exception($result->get_error_message());
        }
    }
}
