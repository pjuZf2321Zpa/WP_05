<?php

namespace FluentSupportPro\App\Modules\Workflows\Actions;

use FluentSupport\App\Models\Ticket;
use FluentSupport\App\Services\Tickets\TicketService;
use FluentSupportPro\App\Models\Workflow;
use FluentSupportPro\App\Models\WorkflowAction;

/**
 * Closes the ticket without the closing email.
 */
class CloseTicket extends BaseAction
{
    public $name = 'fs_action_close_ticket';

    public function title()
    {
        return __('Close Ticket', 'fluent-support-pro');
    }

    public function defaults()
    {
        return ['agent_id' => '', 'fallback_agent' => ''];
    }

    public function fields(Workflow $workflow)
    {
        return $this->agentFields($workflow, __('Response From', 'fluent-support-pro'));
    }

    public function run(WorkflowAction $action, Ticket $ticket, Workflow $workflow)
    {
        $agent = $this->agentFor($action, $ticket, $workflow);
        if ($agent) {
            /* translators: an activity line shown on its own, without a person's name */
            (new TicketService())->close($ticket, $agent, __('Closed by a workflow', 'fluent-support-pro'), 'no', 'automation');
        }
    }
}
