<?php

namespace FluentSupportPro\App\Modules\Workflows\Actions;

use FluentSupport\App\Models\Ticket;
use FluentSupportPro\App\Models\Workflow;
use FluentSupportPro\App\Models\WorkflowAction;

class AddTags extends BaseAction
{
    public $name = 'fs_action_add_tags';

    public function title()
    {
        return __('Add Tag(s)', 'fluent-support-pro');
    }

    public function defaults()
    {
        return ['tag_ids' => []];
    }

    public function fields(Workflow $workflow)
    {
        return [
            'tag_ids' => [
                'is_multiple' => true,
                'label'       => __('Select Tags', 'fluent-support-pro'),
                'type'        => 'tag-selectors',
                'placeholder' => __('Select Tags', 'fluent-support-pro')
            ]
        ];
    }

    public function run(WorkflowAction $action, Ticket $ticket, Workflow $workflow)
    {
        if ($tagIds = $this->setting($action, 'tag_ids')) {
            (new \FluentSupport\App\Services\Tickets\TicketService())->addTags($ticket, $tagIds);
        }
    }
}
