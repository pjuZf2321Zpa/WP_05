<?php

namespace FluentSupportPro\App\Modules\Workflows\Actions;

use FluentSupport\App\Models\Ticket;
use FluentSupportPro\App\Models\Workflow;
use FluentSupportPro\App\Models\WorkflowAction;

/**
 * Starts FluentCRM automations for the customer, creating the contact when
 * there is none.
 */
class CrmRunAutomation extends BaseAction
{
    public $name = 'fs_action_run_automation';

    public function title()
    {
        return __('Run Automation', 'fluent-support-pro');
    }

    public function available()
    {
        return defined('FLUENTCRM');
    }

    public function defaults()
    {
        return ['automation_ids' => []];
    }

    public function fields(Workflow $workflow)
    {
        return [
            'automation_id' => [
                'is_multiple' => true,
                'label'       => __('Select Automation', 'fluent-support-pro'),
                'type'        => 'input-options',
                'placeholder' => __('Select Automation', 'fluent-support-pro'),
                'options'     => \FluentCrm\App\Models\Funnel::select(['id', 'title'])->where('status', 'published')->oldest('title')->get()->toArray()
            ]
        ];
    }

    public function run(WorkflowAction $action, Ticket $ticket, Workflow $workflow)
    {
        $automations = \FluentCrm\App\Models\Funnel::whereIn('id', (array) $this->setting($action, 'automation_id', []))->get();
        if ($automations->isEmpty() || !$ticket->customer) {
            return;
        }

        $subscriber = \FluentCrm\App\Models\Subscriber::where('email', $ticket->customer->email)->first()
            ?: \FluentCrmApi('contacts')->createOrUpdate($ticket->customer->toArray());
        if (!$subscriber) {
            return;
        }

        foreach ($automations as $automation) {
            (new \FluentCrm\App\Services\Funnel\FunnelProcessor())->startFunnelSequence($automation, [
                'status' => $subscriber->status,
            ], [
                'source_trigger_name' => 'fcrm_manual_attach'
            ], $subscriber);
        }
    }
}
