<?php

namespace FluentSupportPro\App\Modules\Workflows\Actions;

use FluentSupport\App\Models\MailBox;
use FluentSupport\App\Models\Ticket;
use FluentSupport\App\Services\MailerInbox\MailBoxService;
use FluentSupportPro\App\Models\Workflow;
use FluentSupportPro\App\Models\WorkflowAction;

/**
 * Moves the ticket to another mailbox through MailBoxService, so the move
 * hooks fire as for a manual move. A ticket with no mailbox is just given one.
 * MailBoxService refuses a mailbox the running agent is restricted from.
 */
class ChangeMailbox extends BaseAction
{
    public $name = 'fs_action_change_mailbox';

    public function title()
    {
        return __('Change Mailbox', 'fluent-support-pro');
    }

    public function defaults()
    {
        return ['mailbox_id' => ''];
    }

    public function fields(Workflow $workflow)
    {
        return [
            'mailbox_id' => [
                'type'    => 'input-options',
                'label'   => __('Select Mailbox', 'fluent-support-pro'),
                'options' => MailBox::select(['id', 'name'])->get()->map(fn($mailbox) => ['id' => $mailbox->id, 'title' => $mailbox->name])->toArray(),
            ],
        ];
    }

    public function run(WorkflowAction $action, Ticket $ticket, Workflow $workflow)
    {
        $mailboxId = (int) $this->setting($action, 'mailbox_id');
        $currentId = (int) $ticket->mailbox_id;

        if (!$mailboxId || $mailboxId === $currentId || !MailBox::find($mailboxId)) {
            return;
        }

        if (!$currentId) {
            $ticket->mailbox_id = $mailboxId;
            $ticket->save();
            return;
        }

        (new MailBoxService())->moveTickets([
            'new_box_id' => $mailboxId,
            'ticket_ids' => [$ticket->id],
            'move_type'  => 'Custom'
        ], $currentId);
    }
}
