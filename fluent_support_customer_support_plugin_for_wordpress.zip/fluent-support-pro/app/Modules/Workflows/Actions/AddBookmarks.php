<?php

namespace FluentSupportPro\App\Modules\Workflows\Actions;

use FluentSupport\App\Models\Ticket;
use FluentSupportPro\App\Models\Workflow;
use FluentSupportPro\App\Models\WorkflowAction;
use FluentSupportPro\App\Services\TicketBookmarkService;

/**
 * Bookmarks the ticket for the chosen agents (they watch it).
 */
class AddBookmarks extends BaseAction
{
    public $name = 'fs_action_add_bookmarks';

    public function title()
    {
        return __('Add Bookmarks', 'fluent-support-pro');
    }

    public function defaults()
    {
        return ['bookmarks' => []];
    }

    public function fields(Workflow $workflow)
    {
        return [
            'bookmarks' => [
                'type'        => 'agent-selectors',
                'label'       => __('Select Agent(s)', 'fluent-support-pro'),
                'is_multiple' => true,
            ],
        ];
    }

    public function run(WorkflowAction $action, Ticket $ticket, Workflow $workflow)
    {
        if ($agentIds = (array) $this->setting($action, 'bookmarks', [])) {
            (new \FluentSupport\App\Services\Tickets\TicketService())->addWatchers($ticket, (array) $agentIds, \FluentSupport\App\Services\Helper::getCurrentAgent());
        }
    }
}
