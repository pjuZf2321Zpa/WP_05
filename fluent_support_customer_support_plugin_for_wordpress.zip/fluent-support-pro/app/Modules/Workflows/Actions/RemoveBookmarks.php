<?php

namespace FluentSupportPro\App\Modules\Workflows\Actions;

use FluentSupport\App\Models\Ticket;
use FluentSupportPro\App\Models\Workflow;
use FluentSupportPro\App\Models\WorkflowAction;
use FluentSupportPro\App\Services\TicketBookmarkService;

class RemoveBookmarks extends AddBookmarks
{
    public $name = 'fs_action_remove_bookmarks';

    public function title()
    {
        return __('Remove Bookmarks', 'fluent-support-pro');
    }

    public function run(WorkflowAction $action, Ticket $ticket, Workflow $workflow)
    {
        if ($agentIds = (array) $this->setting($action, 'bookmarks', [])) {
            (new \FluentSupport\App\Services\Tickets\TicketService())->removeWatchers($ticket, (array) $agentIds, \FluentSupport\App\Services\Helper::getCurrentAgent());
        }
    }
}
