<?php

namespace FluentSupportPro\App\Modules\Workflows\Actions;

class CrmRemoveTags extends CrmAddTags
{
    public $name = 'fs_action_detach_crm_tags';

    protected $method = 'detachTags';

    public function title()
    {
        return __('Remove From FluentCRM Tag(s)', 'fluent-support-pro');
    }
}
