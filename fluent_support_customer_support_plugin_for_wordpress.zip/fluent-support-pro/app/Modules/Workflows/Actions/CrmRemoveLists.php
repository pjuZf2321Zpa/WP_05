<?php

namespace FluentSupportPro\App\Modules\Workflows\Actions;

class CrmRemoveLists extends CrmAddTags
{
    public $name = 'fs_action_detach_crm_lists';

    protected $type = 'lists';

    protected $method = 'detachLists';

    public function title()
    {
        return __('Remove From FluentCRM List(s)', 'fluent-support-pro');
    }

    protected function label()
    {
        return __('Select FluentCRM Lists', 'fluent-support-pro');
    }
}
