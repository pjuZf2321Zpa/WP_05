<?php

namespace FluentSupportPro\App\Modules\Workflows\Actions;

use FluentSupport\App\Models\Ticket;
use FluentSupport\App\Services\Tickets\ResponseService;
use FluentSupportPro\App\Models\Workflow;
use FluentSupportPro\App\Models\WorkflowAction;

/**
 * Replies to the customer. Smartcodes ({{customer.first_name}}) are filled in.
 */
class AddResponse extends BaseAction
{
    public $name = 'fs_action_create_response';

    protected $type = 'response';

    public function title()
    {
        return __('Add Response', 'fluent-support-pro');
    }

    public function defaults()
    {
        return ['response_body' => ''];
    }

    public function fields(Workflow $workflow)
    {
        return array_merge([
            'response_body' => [
                'type'  => 'wp-editor',
                'label' => __('Response Body', 'fluent-support-pro'),
                'props' => ['show-shortcodes' => true, 'show-saved-replies' => true]
            ],
        ], $this->agentFields($workflow, __('Response From', 'fluent-support-pro')));
    }

    public function run(WorkflowAction $action, Ticket $ticket, Workflow $workflow)
    {
        $agent = $this->agentFor($action, $ticket, $workflow);
        if (!$agent) {
            return;
        }

        $data = [
            'content'           => $this->setting($action, 'response_body', ''),
            'conversation_type' => $this->type,
            'source'            => 'automation'
        ];

        // createResponse() fills the smartcodes for an agent's text.
        (new ResponseService())->createResponse($data, $agent, $ticket);
    }
}
