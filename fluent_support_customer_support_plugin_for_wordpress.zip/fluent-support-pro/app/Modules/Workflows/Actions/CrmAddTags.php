<?php

namespace FluentSupportPro\App\Modules\Workflows\Actions;

use FluentSupport\App\Models\Ticket;
use FluentSupportPro\App\Models\Workflow;
use FluentSupportPro\App\Models\WorkflowAction;
use FluentSupportPro\App\Modules\Workflows\Conditions;

/**
 * Adds the customer's FluentCRM contact to tags. CrmAddLists, CrmRemoveTags
 * and CrmRemoveLists change $setting, $method and the labels.
 */
class CrmAddTags extends BaseAction
{
    public $name = 'fs_action_attach_crm_tags';

    /**
     * @var string 'tags' or 'lists'
     */
    protected $type = 'tags';

    /**
     * @var string The FluentCRM contact method that applies the ids.
     */
    protected $method = 'attachTags';

    public function title()
    {
        return __('Add To FluentCRM Tag(s)', 'fluent-support-pro');
    }

    protected function label()
    {
        return __('Select FluentCRM Tags', 'fluent-support-pro');
    }

    public function available()
    {
        return defined('FLUENTCRM');
    }

    protected function settingKey()
    {
        return $this->type === 'lists' ? 'list_ids' : 'tag_ids';
    }

    public function defaults()
    {
        return [$this->settingKey() => []];
    }

    public function fields(Workflow $workflow)
    {
        $options = [];
        foreach (Conditions::crmOptions($this->type) as $id => $title) {
            $options[] = ['id' => $id, 'title' => $title];
        }

        return [
            $this->settingKey() => [
                'multiple'    => true,
                'label'       => $this->label(),
                'type'        => 'input-options',
                'placeholder' => $this->label(),
                'options'     => $options
            ]
        ];
    }

    public function run(WorkflowAction $action, Ticket $ticket, Workflow $workflow)
    {
        $contact = $ticket->customer ? \FluentCrmApi('contacts')->getContact($ticket->customer->email) : null;

        if ($contact) {
            $contact->{$this->method}((array) $this->setting($action, $this->settingKey(), []));
        }
    }
}
