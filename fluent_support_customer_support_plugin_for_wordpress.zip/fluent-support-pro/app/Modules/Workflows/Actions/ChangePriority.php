<?php

namespace FluentSupportPro\App\Modules\Workflows\Actions;

use FluentSupport\App\Models\Ticket;
use FluentSupport\App\Services\Helper;
use FluentSupport\App\Services\Tickets\TicketService;
use FluentSupportPro\App\Models\Workflow;
use FluentSupportPro\App\Models\WorkflowAction;

/**
 * Sets both the customer and the agent priority.
 */
class ChangePriority extends BaseAction
{
    public $name = 'fs_action_change_priority';

    public function title()
    {
        return __('Change Priority', 'fluent-support-pro');
    }

    public function defaults()
    {
        return ['priority' => ''];
    }

    public function fields(Workflow $workflow)
    {
        $options = [];
        foreach (Helper::customerTicketPriorities() as $id => $title) {
            $options[] = ['id' => $id, 'title' => $title];
        }

        return [
            'priority' => [
                'type'        => 'input-options',
                'label'       => __('Select Priority', 'fluent-support-pro'),
                'placeholder' => __('Select Priority', 'fluent-support-pro'),
                'options'     => $options,
            ],
        ];
    }

    public function run(WorkflowAction $action, Ticket $ticket, Workflow $workflow)
    {
        $priority = $this->setting($action, 'priority');

        if ($priority && array_key_exists($priority, Helper::customerTicketPriorities())) {
            $changes = ['client_priority' => $priority];
            // The two lists match unless a filter changes one of them.
            if (array_key_exists($priority, Helper::adminTicketPriorities())) {
                $changes['priority'] = $priority;
            }
            (new TicketService())->change($ticket, $changes, Helper::getCurrentAgent());
        }
    }
}
