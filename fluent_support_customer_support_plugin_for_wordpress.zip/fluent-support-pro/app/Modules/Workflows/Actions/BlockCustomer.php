<?php

namespace FluentSupportPro\App\Modules\Workflows\Actions;

use FluentSupport\App\Models\Ticket;
use FluentSupportPro\App\Models\Workflow;
use FluentSupportPro\App\Models\WorkflowAction;

/**
 * Blocks the ticket's customer: no new tickets, no access to old ones.
 */
class BlockCustomer extends BaseAction
{
    public $name = 'fs_block_customer';

    public function title()
    {
        return __('Block Ticket Submitter (Customer)', 'fluent-support-pro');
    }

    public function defaults()
    {
        return ['customer_block_html' => ''];
    }

    public function fields(Workflow $workflow)
    {
        return [
            'customer_block_html' => [
                'type' => 'html-viewer',
                'html' => '<p><br />' . esc_html__('Customer will be blocked and can not create new ticket or access to previous tickets', 'fluent-support-pro') . '</p>'
            ]
        ];
    }

    public function run(WorkflowAction $action, Ticket $ticket, Workflow $workflow)
    {
        if ($customer = $ticket->customer) {
            $customer->status = 'inactive';
            $customer->save();
        }
    }
}
