<?php

namespace FluentSupportPro\App\Modules\Workflows\Actions;

use FluentSupportPro\App\Models\Workflow;

/**
 * Adds an internal note. Smartcodes are left as written.
 */
class AddNote extends AddResponse
{
    public $name = 'fs_action_create_note';

    protected $type = 'note';

    public function title()
    {
        return __('Add Internal Note', 'fluent-support-pro');
    }

    public function fields(Workflow $workflow)
    {
        return array_merge([
            'response_body' => [
                'type'  => 'wp-editor',
                'label' => __('Note Body', 'fluent-support-pro'),
                'props' => ['show-shortcodes' => true, 'show-saved-replies' => true]
            ],
        ], $this->agentFields($workflow, __('Note From', 'fluent-support-pro')));
    }
}
