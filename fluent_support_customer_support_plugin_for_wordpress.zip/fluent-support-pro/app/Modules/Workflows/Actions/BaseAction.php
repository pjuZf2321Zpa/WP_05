<?php

namespace FluentSupportPro\App\Modules\Workflows\Actions;

use FluentSupport\App\Models\Agent;
use FluentSupport\App\Models\Ticket;
use FluentSupport\App\Services\Helper;
use FluentSupport\Framework\Support\Arr;
use FluentSupportPro\App\Models\Workflow;
use FluentSupportPro\App\Models\WorkflowAction;

/**
 * A workflow action: what the editor shows (title, fields, defaults) and what
 * it does to a ticket. $name is stored on each saved action, so it never changes.
 *
 * run() gets a fresh ticket and may throw: the runner logs the failure and
 * goes on with the next action. Add-ons register a subclass through
 * fluent_support/workflow_action_classes.
 */
abstract class BaseAction
{
    /**
     * @var string The action_name saved with each workflow action.
     */
    public $name = '';

    abstract public function title();

    /**
     * The editor's form fields, by setting key.
     */
    abstract public function fields(Workflow $workflow);

    abstract public function run(WorkflowAction $action, Ticket $ticket, Workflow $workflow);

    public function defaults()
    {
        return [];
    }

    /**
     * Whether the action can be offered and run here (its plugin is active).
     */
    public function available()
    {
        return true;
    }

    /**
     * The action as the workflow editor reads it.
     */
    public function toArray(Workflow $workflow)
    {
        return [
            'title'             => $this->title(),
            'settings_defaults' => $this->defaults(),
            'fields'            => $this->fields($workflow),
        ];
    }

    protected function setting(WorkflowAction $action, $key, $default = null)
    {
        return Arr::get((array) $action->settings, $key, $default);
    }

    /**
     * The "from" agent fields of reply, note and close. A manual run always acts
     * as the agent who runs it, so a manual workflow has none.
     */
    protected function agentFields(Workflow $workflow, $fromLabel)
    {
        if ($workflow->trigger_type === 'manual') {
            return [];
        }

        return [
            'agent_id'       => [
                'type'          => 'agent-selectors',
                'label'         => $fromLabel,
                'extra_options' => [
                    ['id' => 'ticket_agent_id', 'title' => __('Current Assignee', 'fluent-support-pro')],
                    ['id' => 'last_agent_id', 'title' => __('Last Agent to reply', 'fluent-support-pro')],
                ],
                'inline_help'   => __('Leave empty for manual workflow', 'fluent-support-pro')
            ],
            'fallback_agent' => [
                'type'        => 'agent-selectors',
                'label'       => __('Fallback Agent', 'fluent-support-pro'),
                /* translators: %s is the label of the "from" field, like "Response From" */
                'inline_help' => sprintf(__('If agent could not be found from "%s" selector then this agent will be used. Leave empty for manual Workflow', 'fluent-support-pro'), $fromLabel)
            ]
        ];
    }

    /**
     * The agent a reply, note or close acts as: the running agent for a manual
     * workflow; otherwise the chosen agent, the assignee or the last agent to
     * reply, then the fallback agent.
     *
     * @return Agent|null
     */
    protected function agentFor(WorkflowAction $action, Ticket $ticket, Workflow $workflow)
    {
        if ($workflow->trigger_type === 'manual') {
            return Helper::getCurrentAgent() ?: null;
        }

        $chosen = $this->setting($action, 'agent_id');
        $agentId = null;
        if (is_numeric($chosen)) {
            $agentId = $chosen;
        } elseif ($chosen === 'ticket_agent_id') {
            $agentId = $ticket->agent_id;
        } elseif ($chosen === 'last_agent_id') {
            $lastReply = $ticket->getLastAgentResponse();
            $agentId = $lastReply ? $lastReply->person_id : null;
        }

        $agent = $agentId ? Agent::find($agentId) : null;
        if (!$agent && $fallback = $this->setting($action, 'fallback_agent')) {
            $agent = Agent::find($fallback);
        }

        return $agent;
    }
}
