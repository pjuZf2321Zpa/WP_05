<?php

namespace FluentSupportPro\App\Modules\Workflows\Actions;

use FluentSupport\App\Models\AgentGroup;
use FluentSupport\App\Models\Ticket;
use FluentSupport\App\Services\Helper;
use FluentSupport\App\Services\Tickets\TicketService;
use FluentSupportPro\App\Models\Workflow;
use FluentSupportPro\App\Models\WorkflowAction;

/**
 * Assigns the ticket to the group member with the fewest open tickets who may
 * work in its mailbox (AgentGroup::getLeastLoadedAgent()).
 */
class AssignAgentGroup extends BaseAction
{
    public $name = 'fs_action_assign_agent_group';

    public function title()
    {
        return __('Assign Agent Group', 'fluent-support-pro');
    }

    public function defaults()
    {
        return ['agent_group_id' => '', 'skip_if_exist' => 'yes'];
    }

    public function fields(Workflow $workflow)
    {
        return [
            'agent_group_id' => [
                'type'    => 'input-options',
                'label'   => __('Select Agent Group', 'fluent-support-pro'),
                'options' => AgentGroup::select(['id', 'title'])->orderBy('title', 'ASC')->get()->map(fn($group) => ['id' => $group->id, 'title' => $group->title])->toArray(),
            ],
            'skip_if_exist'  => [
                'type'           => 'inline-checkbox',
                'true_label'     => 'yes',
                'false_label'    => 'no',
                'checkbox_label' => __('Skip if ticket already have an agent assigned', 'fluent-support-pro')
            ]
        ];
    }

    public function run(WorkflowAction $action, Ticket $ticket, Workflow $workflow)
    {
        if ($ticket->agent_id && $this->setting($action, 'skip_if_exist', 'yes') === 'yes') {
            return;
        }

        $group = AgentGroup::find($this->setting($action, 'agent_group_id'));
        $counts = [];
        $agent = $group ? $group->getLeastLoadedAgent($ticket->mailbox_id, $counts) : null;

        if ($agent) {
            (new TicketService())->assignAgent($ticket, $agent, Helper::getCurrentAgent());
        }
    }
}
