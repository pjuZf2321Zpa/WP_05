<?php

namespace FluentSupportPro\App\Modules\Workflows\Actions;

use FluentSupport\App\Models\Product;
use FluentSupport\App\Models\Ticket;
use FluentSupport\App\Services\Helper;
use FluentSupport\App\Services\Tickets\TicketService;
use FluentSupportPro\App\Models\Workflow;
use FluentSupportPro\App\Models\WorkflowAction;
use FluentSupportPro\App\Services\ProHelper;

/**
 * Sets the ticket's product.
 */
class AddProduct extends BaseAction
{
    public $name = 'fs_action_add_product';

    public function title()
    {
        return __('Add Product', 'fluent-support-pro');
    }

    public function defaults()
    {
        return ['product_id' => ''];
    }

    public function fields(Workflow $workflow)
    {
        return [
            'product_id' => [
                'type'    => 'input-options',
                'label'   => __('Select Product', 'fluent-support-pro'),
                'options' => ProHelper::getProducts(),
            ],
        ];
    }

    public function run(WorkflowAction $action, Ticket $ticket, Workflow $workflow)
    {
        $product = Product::find($this->setting($action, 'product_id'));
        if ($product) {
            (new TicketService())->change($ticket, ['product_id' => $product->id], Helper::getCurrentAgent());
        }
    }
}
