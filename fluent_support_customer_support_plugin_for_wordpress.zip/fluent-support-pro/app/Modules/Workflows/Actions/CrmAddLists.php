<?php

namespace FluentSupportPro\App\Modules\Workflows\Actions;

class CrmAddLists extends CrmAddTags
{
    public $name = 'fs_action_attach_crm_lists';

    protected $type = 'lists';

    protected $method = 'attachLists';

    public function title()
    {
        return __('Add To FluentCRM List(s)', 'fluent-support-pro');
    }

    protected function label()
    {
        return __('Select FluentCRM Lists', 'fluent-support-pro');
    }
}
