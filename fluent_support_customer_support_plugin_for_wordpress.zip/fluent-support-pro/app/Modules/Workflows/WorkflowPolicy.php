<?php

namespace FluentSupportPro\App\Modules\Workflows;

use FluentSupport\App\Modules\PermissionManager;
use FluentSupport\Framework\Foundation\Policy;
use FluentSupport\Framework\Http\Request\Request;

/**
 * fst_manage_workflows manages workflows; fst_run_workflows may also list a
 * workflow's actions and run it on tickets.
 */
class WorkflowPolicy extends Policy
{
    public function verifyRequest(Request $request)
    {
        return PermissionManager::currentUserCan('fst_manage_workflows');
    }

    public function actions(Request $request)
    {
        return $this->canRun();
    }

    public function run(Request $request)
    {
        return $this->canRun();
    }

    private function canRun()
    {
        return PermissionManager::currentUserCan('fst_manage_workflows') || PermissionManager::currentUserCan('fst_run_workflows');
    }
}
