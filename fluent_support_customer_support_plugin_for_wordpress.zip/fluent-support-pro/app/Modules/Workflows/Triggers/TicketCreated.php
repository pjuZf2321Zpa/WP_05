<?php

namespace FluentSupportPro\App\Modules\Workflows\Triggers;

class TicketCreated extends BaseTrigger
{
    public $key = 'fluent_support/ticket_created';

    protected $args = 2;

    public function title()
    {
        return __('On Ticket Creation', 'fluent-support-pro');
    }

    public function description()
    {
        return __('This workflow will be initiated on when a new ticket has been submitted by customer', 'fluent-support-pro');
    }

    protected function conditionKeys()
    {
        return [
            'customer.first_name', 'customer.last_name', 'customer.email',
            'message.title', 'message.content', 'message.attachments',
            'ticket.client_priority', 'ticket.mailbox_id', 'ticket.priority', 'ticket.source', 'ticket.tags',
            'message.added_time_range', 'message.added_date_range',
            'ticket.product_id', 'fluent_crm.tags', 'fluent_crm.lists',
        ];
    }

    public function context(...$args)
    {
        list($ticket, $customer) = $args;

        return ['ticket' => $ticket, 'customer' => $customer, 'message' => $ticket];
    }
}
