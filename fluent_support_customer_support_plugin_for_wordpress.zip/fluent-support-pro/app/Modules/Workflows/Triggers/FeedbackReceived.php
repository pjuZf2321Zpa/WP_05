<?php

namespace FluentSupportPro\App\Modules\Workflows\Triggers;

class FeedbackReceived extends BaseTrigger
{
    public $key = 'fluent_support/agent_feedback_received';

    protected $args = 4;

    public function title()
    {
        return __('On Customer Feedback', 'fluent-support-pro');
    }

    public function description()
    {
        return __('This workflow will be initiated when a customer likes or dislikes an agent reply', 'fluent-support-pro');
    }

    protected function conditionKeys()
    {
        return array_merge(['feedback.rating'], $this->customerKeys(), ['ticket.client_priority'], $this->ticketKeys(), $this->crmKeys());
    }

    public function context(...$args)
    {
        list($rating, $conversation, $ticket, $customer) = $args;

        return ['ticket' => $ticket, 'customer' => $customer, 'message' => $conversation, 'rating' => $rating];
    }
}
