<?php

namespace FluentSupportPro\App\Modules\Workflows\Triggers;

use FluentSupport\App\Models\Customer;

class TicketReopened extends BaseTrigger
{
    public $key = 'fluent_support/ticket_reopen';

    public function title()
    {
        return __('On Ticket Reopened', 'fluent-support-pro');
    }

    public function description()
    {
        return __('This workflow will be initiated when a closed ticket is reopened, by the customer or an agent', 'fluent-support-pro');
    }

    protected function conditionKeys()
    {
        return array_merge($this->customerKeys(), ['ticket.client_priority'], $this->ticketKeys(), $this->crmKeys());
    }

    public function context(...$args)
    {
        $ticket = $args[0];

        return ['ticket' => $ticket, 'customer' => Customer::find($ticket->customer_id), 'message' => $ticket];
    }
}
