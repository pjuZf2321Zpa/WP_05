<?php

namespace FluentSupportPro\App\Modules\Workflows\Triggers;

use FluentSupportPro\App\Modules\Workflows\Runner;

/**
 * A workflow trigger: the fluent_support/* event that starts automatic
 * workflows, the conditions the editor offers for it, and how the event's
 * arguments become the run context.
 *
 * The context is ['ticket' => Ticket, 'customer' => Customer|null,
 * 'message' => Ticket|Conversation, 'rating' => string|null]. Conditions read
 * customer.*, ticket.* and message.* from it.
 *
 * Add-ons register a subclass through fluent_support/workflow_trigger_classes.
 */
abstract class BaseTrigger
{
    /**
     * @var string The event, also the workflow's trigger_key.
     */
    public $key = '';

    /**
     * @var int How many arguments the event passes.
     */
    protected $args = 1;

    abstract public function title();

    abstract public function description();

    /**
     * @return string[] condition keys (Conditions::definitions()) the editor offers
     */
    abstract protected function conditionKeys();

    /**
     * @return array|null the run context, or null to skip this event
     */
    abstract public function context(...$args);

    /**
     * Condition keys after the fluent_support/workflow_{event}_supported_conditions filter.
     */
    public function conditions()
    {
        $event = str_replace('fluent_support/', '', $this->key);

        return apply_filters('fluent_support/workflow_' . $event . '_supported_conditions', $this->conditionKeys());
    }

    public function listen()
    {
        add_action($this->key, function (...$args) {
            $context = $this->context(...$args);
            if ($context) {
                Runner::runAutomatic($this, $context);
            }
        }, 10, $this->args);
    }

    /**
     * The trigger as the workflow editor reads it.
     */
    public function toArray()
    {
        return [
            'title'                => $this->title(),
            'description'          => $this->description(),
            'supported_conditions' => $this->conditions(),
        ];
    }

    /**
     * The ticket's customer and contact fields most triggers offer.
     */
    protected function customerKeys()
    {
        return ['customer.first_name', 'customer.last_name', 'customer.email'];
    }

    protected function ticketKeys()
    {
        return ['ticket.mailbox_id', 'ticket.priority', 'ticket.source', 'ticket.tags', 'ticket.product_id', 'ticket.agent_group'];
    }

    protected function crmKeys()
    {
        return ['fluent_crm.tags', 'fluent_crm.lists'];
    }
}
