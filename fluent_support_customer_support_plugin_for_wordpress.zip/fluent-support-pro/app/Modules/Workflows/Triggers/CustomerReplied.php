<?php

namespace FluentSupportPro\App\Modules\Workflows\Triggers;

class CustomerReplied extends BaseTrigger
{
    public $key = 'fluent_support/response_added_by_customer';

    protected $args = 3;

    public function title()
    {
        return __('On Customer Response', 'fluent-support-pro');
    }

    public function description()
    {
        return __('This workflow will be initiated when customer add a response to an existing ticket', 'fluent-support-pro');
    }

    protected function conditionKeys()
    {
        return array_merge($this->customerKeys(), [
            'message.content', 'message.attachments',
            'ticket.agent_id', 'ticket.mailbox_id', 'ticket.priority', 'ticket.source', 'ticket.tags',
            'bookmarks.tag_id', 'message.added_time_range', 'message.added_date_range',
            'ticket.product_id', 'ticket.agent_group',
        ], $this->crmKeys());
    }

    public function context(...$args)
    {
        list($response, $ticket, $customer) = $args;

        return ['ticket' => $ticket, 'customer' => $customer, 'message' => $response];
    }
}
