<?php

namespace FluentSupportPro\App\Modules\Workflows\Triggers;

use FluentSupport\App\Models\Customer;

class AgentReplied extends BaseTrigger
{
    public $key = 'fluent_support/response_added_by_agent';

    protected $args = 2;

    public function title()
    {
        return __('On Agent Response', 'fluent-support-pro');
    }

    public function description()
    {
        return __('This workflow will be initiated when an agent replies to a ticket. Replies added by workflows never start the same workflow again.', 'fluent-support-pro');
    }

    protected function conditionKeys()
    {
        return array_merge($this->customerKeys(), [
            'message.content', 'message.attachments', 'message.added_time_range', 'message.added_date_range',
        ], $this->ticketKeys(), $this->crmKeys());
    }

    public function context(...$args)
    {
        list($response, $ticket) = $args;

        return ['ticket' => $ticket, 'customer' => Customer::find($ticket->customer_id), 'message' => $response];
    }
}
