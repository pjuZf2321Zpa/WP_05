<?php

namespace FluentSupportPro\App\Modules\Workflows\Triggers;

use FluentSupport\App\Models\Customer;

class TicketClosed extends BaseTrigger
{
    public $key = 'fluent_support/ticket_closed';

    public function title()
    {
        return __('On Ticket Closed', 'fluent-support-pro');
    }

    public function description()
    {
        return __('This workflow will be initiated when a ticket is closed', 'fluent-support-pro');
    }

    protected function conditionKeys()
    {
        return array_merge($this->customerKeys(), $this->ticketKeys(), $this->crmKeys());
    }

    public function context(...$args)
    {
        $ticket = $args[0];

        return ['ticket' => $ticket, 'customer' => Customer::find($ticket->customer_id), 'message' => $ticket];
    }
}
