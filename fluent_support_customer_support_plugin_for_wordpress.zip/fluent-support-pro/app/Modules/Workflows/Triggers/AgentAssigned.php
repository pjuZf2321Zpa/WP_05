<?php

namespace FluentSupportPro\App\Modules\Workflows\Triggers;

use FluentSupport\App\Models\Customer;

class AgentAssigned extends BaseTrigger
{
    public $key = 'fluent_support/agent_assigned_to_ticket';

    protected $args = 2;

    public function title()
    {
        return __('On Agent Assigned', 'fluent-support-pro');
    }

    public function description()
    {
        return __('This workflow will be initiated when a ticket is assigned to an agent. Assignments made by workflows never start the same workflow again.', 'fluent-support-pro');
    }

    protected function conditionKeys()
    {
        return array_merge($this->customerKeys(), ['ticket.client_priority'], $this->ticketKeys(), $this->crmKeys());
    }

    public function context(...$args)
    {
        $ticket = $args[1];

        return ['ticket' => $ticket, 'customer' => Customer::find($ticket->customer_id), 'message' => $ticket];
    }
}
