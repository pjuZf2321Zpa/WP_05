<?php

namespace FluentSupportPro\App\Modules\Workflows;

use FluentSupport\App\Models\Agent;
use FluentSupport\App\Models\AgentGroup;
use FluentSupport\App\Models\MailBox;
use FluentSupport\App\Models\Product;
use FluentSupport\App\Models\TagPivot;
use FluentSupport\App\Models\Ticket;
use FluentSupport\App\Models\TicketTag;
use FluentSupport\App\Services\Helper;
use FluentSupportPro\App\Models\Workflow;
use FluentSupportPro\App\Services\Integrations\Commerce\CommerceProviders;

/**
 * Workflow conditions: what the editor offers, and whether a workflow's
 * conditions match a run context (see Triggers\BaseTrigger).
 *
 * A workflow's settings.conditions is a list of groups. Every group must match
 * (AND); inside a group any row may match (OR). A row is
 * ['data_key' => 'provider.property', 'data_operator' => ..., 'data_value' => ...].
 * The editor's blank starter row (no data_key) is not a condition, so a group
 * of only blank rows passes; a filled-in row that is malformed matches nothing.
 */
class Conditions
{
    /**
     * Commerce lookups for one match() call, keyed by provider:user.
     *
     * @var array
     */
    private static $commerce = [];

    public static function match(Workflow $workflow, array $context)
    {
        self::$commerce = [];
        $groups = is_array($workflow->settings) ? ($workflow->settings['conditions'] ?? []) : [];

        foreach ((array) $groups as $group) {
            if (!self::matchGroup((array) $group, $context)) {
                return false;
            }
        }

        return true;
    }

    private static function matchGroup(array $rows, array $context)
    {
        $hasCondition = false;

        foreach ($rows as $row) {
            $key = (string) ($row['data_key'] ?? '');
            if ($key === '') {
                continue;
            }
            $hasCondition = true;

            $parts = explode('.', $key);
            if (count($parts) !== 2 || empty($row['data_operator'])) {
                continue;
            }

            if (self::matchRow($parts[0], $parts[1], $row, $context)) {
                return true;
            }
        }

        return !$hasCondition;
    }

    /**
     * Add-ons may decide a row through fluent_support/workflow_condition_matches
     * (return true or false; null leaves it to the built-in rules).
     */
    private static function matchRow($provider, $property, array $row, array $context)
    {
        $custom = apply_filters('fluent_support/workflow_condition_matches', null, $row, $context);
        if ($custom !== null) {
            return (bool) $custom;
        }

        $operator = $row['data_operator'];
        $value = $row['data_value'] ?? null;
        $ticket = $context['ticket'];
        $customer = $context['customer'] ?? null;

        if (CommerceProviders::get($provider)) {
            return self::matchCommerce($provider, $property, $operator, $value, $customer);
        }

        switch ($provider) {
            case 'fluent_crm':
                $hasAny = self::crmHasAny($property, (array) $value, $customer);
                if ($hasAny === null) {
                    return false;
                }
                return $operator === 'not_includes_in' ? !$hasAny : ($operator === 'includes_in' && $hasAny);
            case 'bookmarks':
                // Bookmarked by every chosen agent.
                $bookmarked = TagPivot::where('source_type', 'ticket_watcher')->where('source_id', $ticket->id)->pluck('tag_id')->toArray();
                $hasAll = count(array_intersect((array) $value, $bookmarked)) === count((array) $value);
                return $operator === 'not_includes_in' ? !$hasAll : ($operator === 'includes_in' && $hasAll);
            case 'custom_fields':
                $target = (object) $ticket->customData();
                break;
            case 'feedback':
                $target = (object) ['rating' => $context['rating'] ?? null];
                break;
            case 'customer':
                $target = $customer;
                break;
            case 'ticket':
                $target = $ticket;
                break;
            default:
                $target = $context[$provider] ?? $context['message'];
        }

        if (!$target) {
            return false;
        }

        if ($provider === 'ticket' && in_array($operator, ['includes_in', 'not_includes_in'], true)) {
            return self::matchTicketList($property, $operator, (array) $value, $ticket);
        }

        return self::compare($target, $provider, $property, $operator, $value, $row);
    }

    private static function compare($target, $provider, $property, $operator, $value, array $row)
    {
        $has = $target instanceof \stdClass ? property_exists($target, $property) : isset($target->{$property});
        $actual = $has ? $target->{$property} : null;

        switch ($operator) {
            case 'contains':
                return $has && mb_stripos((string) $actual, (string) $value) !== false;
            case 'not_contains':
                return $has && mb_stripos((string) $actual, (string) $value) === false;
            case 'equal':
                return $has && $actual == $value;
            case 'not_equal':
                return $has && $actual != $value;
            case 'yes':
                return $target->attachments && $target->attachments->count();
            case 'no':
                return !$target->attachments || !$target->attachments->count();
            case 'range':
                $time = strtotime($target->created_at);
                if ($property === 'added_time_range') {
                    $time = strtotime(date('H:i:s', $time));
                }
                return $time >= strtotime($row['value_1'] ?? '') && $time <= strtotime($row['value_2'] ?? '');
            case '>':
                return strtotime($target->created_at) > strtotime($value);
            case '<':
                return strtotime($target->created_at) < strtotime($value);
            case 'includes_in':
            case 'not_includes_in':
                // Custom field lists: "includes" needs every chosen value.
                if ($provider !== 'custom_fields' || !$has) {
                    return false;
                }
                $hasAll = !array_diff((array) $value, (array) $actual);
                return $operator === 'includes_in' ? $hasAll : !$hasAll;
        }

        return false;
    }

    /**
     * ticket.tags: any of the chosen tags. ticket.agent_group: the assigned
     * agent is in any of the chosen groups (an unassigned ticket matches neither way).
     */
    private static function matchTicketList($property, $operator, array $ids, $ticket)
    {
        $ids = array_filter(array_map('intval', $ids));

        if ($property === 'agent_group') {
            if (!$ticket->agent_id) {
                return false;
            }
            $hasAny = $ids && TagPivot::where('source_type', 'agent_group')->where('source_id', $ticket->agent_id)->whereIn('tag_id', $ids)->exists();
        } elseif ($property === 'tags') {
            $hasAny = $ids && TagPivot::where('source_type', 'ticket_tag')->where('source_id', $ticket->id)->whereIn('tag_id', $ids)->exists();
        } else {
            return false;
        }

        return $operator === 'includes_in' ? $hasAny : !$hasAny;
    }

    /**
     * @return bool|null whether the customer's FluentCRM contact has any of the
     *                   tags or lists, or null without FluentCRM or a contact
     */
    private static function crmHasAny($property, array $ids, $customer)
    {
        if (!$customer || !defined('FLUENTCRM')) {
            return null;
        }

        $contact = \FluentCrmApi('contacts')->getContact($customer->email);
        if (!$contact) {
            return null;
        }

        return $property === 'lists' ? $contact->hasAnyListId($ids) : $contact->hasAnyTagId($ids);
    }

    /**
     * Commerce conditions match the customer's purchases and licenses. When the
     * lookup is unavailable no condition matches, positive or negative.
     */
    private static function matchCommerce($providerKey, $property, $operator, $value, $customer)
    {
        $provider = CommerceProviders::get($providerKey);
        $cacheKey = $providerKey . ':' . (int) ($customer->user_id ?? 0);

        $items = self::purchases($provider, $cacheKey, $customer);
        if ($items === null) {
            return false;
        }

        if ($property === 'customer_has_active_license') {
            if (!array_key_exists($cacheKey . ':license', self::$commerce)) {
                $status = $provider->licenseStatus($customer);
                self::$commerce[$cacheKey . ':license'] = !empty(is_array($status) ? ($status['active_product_ids'] ?? []) : []);
            }
            $has = self::$commerce[$cacheKey . ':license'] ? 'yes' : 'no';
            return $operator === 'not_equal' ? $has != $value : $has == $value;
        }

        $owned = $property === 'customer_variation_id' ? $items['variation_ids'] : $items['product_ids'];
        $hasAny = (bool) array_intersect(array_map('strval', (array) $value), (array) $owned);

        return $operator === 'not_includes_in' ? !$hasAny : $hasAny;
    }

    private static function purchases($provider, $cacheKey, $customer)
    {
        if (!array_key_exists($cacheKey, self::$commerce)) {
            self::$commerce[$cacheKey] = $provider->purchasedItems($customer);
        }

        return self::$commerce[$cacheKey];
    }

    /**
     * Every condition the editor knows, by key. Commerce conditions are added
     * only for the editor ($withCommerce), with their options searched on demand
     * (workflows/commerce-options).
     */
    public static function definitions($withCommerce = false)
    {
        $pairs = function ($rows, $label) {
            $options = [];
            foreach ($rows as $row) {
                $options[strval($row->id)] = $label($row);
            }
            return $options;
        };

        $sources = Ticket::sourceFilterOptions();
        unset($sources[Ticket::SOURCE_NONE]);

        $customer = __('Customer', 'fluent-support-pro');
        $message = __('Message', 'fluent-support-pro');
        $ticket = __('Ticket', 'fluent-support-pro');

        $conditions = [
            'customer.first_name'      => ['title' => __('Customer First Name', 'fluent-support-pro'), 'data_type' => 'string', 'group' => $customer],
            'customer.last_name'       => ['title' => __('Customer Last Name', 'fluent-support-pro'), 'data_type' => 'string', 'group' => $customer],
            'customer.email'           => ['title' => __('Customer Email', 'fluent-support-pro'), 'data_type' => 'string', 'group' => $customer],
            'message.title'            => ['title' => __('Ticket Title', 'fluent-support-pro'), 'data_type' => 'string', 'group' => $message],
            'message.content'          => ['title' => __('Message Content', 'fluent-support-pro'), 'data_type' => 'string', 'group' => $message],
            'message.attachments'      => [
                'title'     => __('Attachments', 'fluent-support-pro'),
                'data_type' => 'yes_no',
                'default'   => 'yes',
                'options'   => [
                    'yes' => __('Has an attachment', 'fluent-support-pro'),
                    'no'  => __('Does not have an attachment', 'fluent-support-pro')
                ],
                'group'     => $message
            ],
            'message.added_time_range' => ['title' => __('Added Time Range', 'fluent-support-pro'), 'data_type' => 'time_range', 'group' => $message],
            'message.added_date_range' => ['title' => __('Added Date Range', 'fluent-support-pro'), 'data_type' => 'date_range', 'group' => $message],
            'ticket.client_priority'   => ['title' => __('Ticket Priority (Client)', 'fluent-support-pro'), 'data_type' => 'single_dropdown', 'options' => Helper::customerTicketPriorities(), 'group' => $ticket],
            'ticket.product_id'        => [
                'title'     => __('Selected Product', 'fluent-support-pro'),
                'data_type' => 'single_dropdown',
                'options'   => $pairs(Product::select(['id', 'title'])->oldest('title')->get(), fn($product) => $product->title),
                'group'     => $ticket
            ],
            'ticket.mailbox_id'        => [
                'title'     => __('Mailbox', 'fluent-support-pro'),
                'data_type' => 'single_dropdown',
                'options'   => $pairs(MailBox::select(['id', 'name'])->oldest('name')->get(), fn($mailbox) => $mailbox->name),
                'group'     => $ticket
            ],
            'ticket.agent_group'       => [
                'title'     => __('Agent Group', 'fluent-support-pro'),
                'data_type' => 'multiple_select',
                'options'   => $pairs(AgentGroup::select(['id', 'title'])->orderBy('title', 'ASC')->get(), fn($group) => $group->title),
                'group'     => $ticket
            ],
            'feedback.rating'          => [
                'title'     => __('Feedback', 'fluent-support-pro'),
                'data_type' => 'single_dropdown',
                'options'   => ['like' => __('Like', 'fluent-support-pro'), 'dislike' => __('Dislike', 'fluent-support-pro')],
                'group'     => __('Feedback', 'fluent-support-pro')
            ],
            'ticket.priority'          => ['title' => __('Ticket Priority (Agent)', 'fluent-support-pro'), 'data_type' => 'single_dropdown', 'options' => Helper::adminTicketPriorities(), 'group' => $ticket],
            'ticket.tags'              => [
                'title'     => __('Ticket Tags', 'fluent-support-pro'),
                'data_type' => 'multiple_select',
                'options'   => $pairs(TicketTag::select(['id', 'title'])->oldest('title')->get(), fn($tag) => $tag->title),
                'group'     => $ticket
            ],
            'bookmarks.tag_id'         => [
                'title'     => __('Bookmarks', 'fluent-support-pro'),
                'data_type' => 'multiple_select',
                'options'   => $pairs(Agent::select(['id', 'first_name', 'last_name'])->oldest()->get(), fn($agent) => $agent->first_name . ' ' . $agent->last_name),
                'group'     => $ticket
            ],
            'ticket.source'            => ['title' => __('Ticket Source', 'fluent-support-pro'), 'data_type' => 'single_dropdown', 'options' => $sources, 'group' => $ticket],
        ];

        $conditions = apply_filters('fluent_support/workflow_conditions', $conditions);

        if (defined('FLUENTCRM')) {
            $crm = __('Fluent CRM', 'fluent-support-pro');
            $conditions['fluent_crm.tags'] = ['title' => __('Customer CRM Tag(s)', 'fluent-support-pro'), 'data_type' => 'multiple_select', 'options' => self::crmOptions('tags'), 'group' => $crm];
            $conditions['fluent_crm.lists'] = ['title' => __('Customer CRM List(s)', 'fluent-support-pro'), 'data_type' => 'multiple_select', 'options' => self::crmOptions('lists'), 'group' => $crm];
        }

        if ($withCommerce) {
            $conditions += self::commerceDefinitions();
        }

        return $conditions;
    }

    /**
     * @return string[] commerce condition keys, offered on every trigger
     */
    public static function commerceKeys()
    {
        return array_keys(self::commerceDefinitions());
    }

    private static function commerceDefinitions()
    {
        $conditions = [];

        foreach (CommerceProviders::all() as $provider) {
            $key = $provider->getKey();
            $group = $provider->getLabel();

            $conditions[$key . '.customer_product_id'] = [
                'title'           => __('Customer Purchased Product', 'fluent-support-pro'),
                'data_type'       => 'remote_select',
                'option_provider' => $key,
                'option_type'     => 'product',
                'group'           => $group,
            ];

            if ($provider->supportsLicensing()) {
                $conditions[$key . '.customer_has_active_license'] = [
                    'title'     => __('Customer Has Active License', 'fluent-support-pro'),
                    'data_type' => 'single_dropdown',
                    'options'   => ['yes' => __('Yes', 'fluent-support-pro'), 'no' => __('No', 'fluent-support-pro')],
                    'group'     => $group,
                ];
            }

            if ($provider->supportsVariations()) {
                $conditions[$key . '.customer_variation_id'] = [
                    'title'           => __('Customer Purchased Package (Variation)', 'fluent-support-pro'),
                    'data_type'       => 'remote_select',
                    'option_provider' => $key,
                    'option_type'     => 'variation',
                    'group'           => $group,
                ];
            }
        }

        return $conditions;
    }

    /**
     * FluentCRM tags or lists as [id => title].
     */
    public static function crmOptions($type)
    {
        $options = [];
        foreach (\FluentCrmApi($type === 'lists' ? 'lists' : 'tags')->all() as $item) {
            $options[$item['id']] = $item['title'];
        }

        return $options;
    }
}
