<?php

namespace FluentSupportPro\App\Modules\Workflows;

use FluentSupport\App\Exceptions\ApiException;
use FluentSupport\App\Http\Controllers\Controller;
use FluentSupport\App\Models\Activity;
use FluentSupport\App\Models\Meta;
use FluentSupport\App\Models\Ticket;
use FluentSupport\App\Modules\PermissionManager;
use FluentSupport\App\Services\Helper;
use FluentSupport\App\Services\Tickets\AgentTicketAccess;
use FluentSupport\Framework\Http\Request\Request;
use FluentSupport\Framework\Support\Arr;
use FluentSupportPro\App\Models\Workflow;
use FluentSupportPro\App\Models\WorkflowAction;
use FluentSupportPro\App\Services\Integrations\Commerce\CommerceProviders;

/**
 * The workflow pages (list, editor) and the ticket "Run workflow" menus. The UI
 * lives in the free plugin (resources/admin/Modules/Workflows/).
 */
class WorkflowController extends Controller
{
    const MAX_RUN_TICKETS = 200;

    public function index(Request $request)
    {
        $workflows = Workflow::orderBy('id', 'DESC')
            ->searchBy($request->getSafe('search', 'sanitize_text_field'))
            ->paginate();

        $triggers = Runner::triggers();
        foreach ($workflows as $workflow) {
            if ($workflow->trigger_type == 'automatic' && isset($triggers[$workflow->trigger_key])) {
                $workflow->trigger_human_name = $triggers[$workflow->trigger_key]->title();
            }
        }

        return ['workflows' => $workflows];
    }

    /**
     * Remote search for the commerce product/variation conditions, so the builder
     * doesn't load the whole catalog. `ids` resolves saved values back to labels.
     */
    public function commerceOptions(Request $request)
    {
        $provider = CommerceProviders::get($request->getSafe('provider', 'sanitize_text_field'));
        if (!$provider) {
            return ['options' => []];
        }

        $isVariation = $request->getSafe('type', 'sanitize_text_field') === 'variation';
        $search = $request->getSafe('search', 'sanitize_text_field');
        // Also caps `ids`, since the *ByIds() lookups run once per id.
        $ids = array_slice(array_filter(array_map('trim', explode(',', (string) $request->get('ids', '')))), 0, 50);

        if ($ids) {
            $options = $isVariation ? $provider->variationsByIds($ids) : $provider->productsByIds($ids);
        } else {
            $options = $isVariation ? $provider->searchVariations($search, 50) : $provider->searchProducts($search, 50);
        }

        return ['options' => array_values($options)];
    }

    public function create(Request $request)
    {
        $title = $this->uniqueTitle($request->getSafe('title', 'sanitize_text_field'));

        // The model makes it a draft owned by the current user.
        $workflow = Workflow::create([
            'title'        => $title,
            'trigger_type' => $request->getSafe('trigger_type', 'sanitize_key'),
            // A hook name like "fluent_support/ticket_created": sanitize_key() would strip the slash.
            'trigger_key'  => $request->getSafe('trigger_key', 'sanitize_text_field'),
        ]);

        return [
            'workflow' => $workflow,
            'message'  => __('Workflow has been created', 'fluent-support-pro')
        ];
    }

    public function get(Request $request, $workflow_id)
    {
        $workflow = $this->find($workflow_id);
        $with = array_map('sanitize_key', (array) $request->get('with', []));

        $data = ['actions' => $workflow->orderedActions()];

        if (in_array('action_fields', $with, true)) {
            $data['action_fields'] = apply_filters('fluent_support/workflow_actions', array_map(fn($action) => $action->toArray($workflow), Runner::actions()), $workflow);
        }
        if (in_array('trigger_fields', $with, true)) {
            // Commerce conditions are offered on every trigger.
            $commerce = Conditions::commerceKeys();
            $data['trigger_fields'] = [
                'triggers'   => array_map(fn($trigger) => array_merge($trigger->toArray(), ['supported_conditions' => array_merge($trigger->conditions(), $commerce)]), Runner::triggers()),
                'conditions' => Conditions::definitions(true),
            ];
        }

        // The editor shows one empty condition group to start from.
        $data['workflow'] = $workflow->toArray();
        if ($workflow->trigger_type == 'automatic' && empty($workflow->settings['conditions'])) {
            $data['workflow']['settings'] = ['conditions' => [[]]] + (is_array($workflow->settings) ? $workflow->settings : []);
        }

        return $data;
    }

    /**
     * Saves the workflow and its actions. Actions are kept in the order sent;
     * actions left out are deleted.
     */
    public function update(Request $request, $workflow_id)
    {
        $workflow = $this->find($workflow_id);
        $input = (array) $request->get('workflow', []);

        $workflow->title = $this->uniqueTitle(sanitize_text_field(Arr::get($input, 'title', '')), $workflow->id);
        if (isset($input['trigger_key'])) {
            $workflow->trigger_key = sanitize_text_field(wp_unslash($input['trigger_key']));
        }
        if (isset($input['trigger_type'])) {
            $workflow->trigger_type = sanitize_key($input['trigger_type']);
        }
        if (isset($input['status'])) {
            $workflow->status = sanitize_key($input['status']);
        }
        // Settings hold plain text and identifiers only, no HTML.
        if (isset($input['settings'])) {
            $workflow->settings = is_array($input['settings']) ? map_deep(wp_unslash($input['settings']), 'sanitize_text_field') : [];
        }
        $workflow->save();

        $actionIds = [];
        foreach ((array) $request->get('actions', []) as $input) {
            $data = array_filter([
                'title'       => sanitize_text_field(Arr::get($input, 'title', '')),
                'action_name' => sanitize_text_field(Arr::get($input, 'action_name', '')),
                'settings'    => Arr::get($input, 'settings'),
            ]);

            // Only this workflow's own actions are updated; any other id makes a new one.
            $action = !empty($input['id']) ? WorkflowAction::where('workflow_id', $workflow->id)->find((int) $input['id']) : null;
            if ($action) {
                $action->fill($data)->save();
            } else {
                $action = WorkflowAction::create($data + ['workflow_id' => $workflow->id]);
            }
            $actionIds[] = (int) $action->id;
        }

        WorkflowAction::where('workflow_id', $workflow->id)->whereNotIn('id', $actionIds ?: [0])->delete();
        $workflow->saveActionOrder($actionIds);

        return [
            'message'  => __('Workflow has been updated', 'fluent-support-pro'),
            'workflow' => $workflow,
            'actions'  => $workflow->orderedActions()
        ];
    }

    public function saveActionOrder(Request $request)
    {
        $this->find($request->getInt('workflow_id'))->saveActionOrder((array) $request->get('action_sequence', []));

        return [
            'message' => __('Action sequence has been updated', 'fluent-support-pro')
        ];
    }

    /**
     * Copies the workflow as a draft named "<title> - Copy" (then "- Copy (1)",
     * "- Copy (2)", ...), with its actions in the same order.
     */
    public function duplicate($workflow_id)
    {
        $workflow = $this->find($workflow_id);

        $base = preg_replace('/ - Copy(?: \(\d+\))?$/i', '', $workflow->title);
        $title = $base . ' - Copy';
        for ($i = 1; Workflow::where('title', $title)->exists(); $i++) {
            $title = $base . ' - Copy (' . $i . ')';
        }

        $copy = $workflow->replicate();
        $copy->title = $title;
        $copy->status = 'draft';
        $copy->last_ran_at = null;
        $copy->save();

        $copy->saveActionOrder(array_map(function ($action) use ($copy) {
            $newAction = $action->replicate();
            $newAction->workflow_id = $copy->id;
            $newAction->save();
            return $newAction->id;
        }, $workflow->orderedActions()));

        return [
            'message' => __('Selected workflow has been duplicated', 'fluent-support-pro')
        ];
    }

    public function delete($workflow_id)
    {
        WorkflowAction::where('workflow_id', $workflow_id)->delete();
        Meta::where('object_type', 'workflow_meta')->where('object_id', $workflow_id)->delete();
        Workflow::where('id', $workflow_id)->delete();

        return [
            'message' => __('Selected workflow has been deleted', 'fluent-support-pro')
        ];
    }

    /**
     * Published manual workflows, for the ticket "Run workflow" menus.
     */
    public function options()
    {
        return [
            'option_key' => 'manual_workflows',
            'options'    => Workflow::select(['id', 'title'])
                ->where('trigger_type', 'manual')
                ->where('status', 'published')
                ->get()
        ];
    }

    public function actions($workflow_id)
    {
        $workflow = $this->find($workflow_id);

        return [
            'actions' => WorkflowAction::select(['id', 'title', 'action_name'])->where('workflow_id', $workflow->id)->get()
        ];
    }

    /**
     * The workflow's latest runs from the activity log (Runner::logRun()).
     */
    public function runs(Request $request, $workflow_id)
    {
        $workflow = $this->find($workflow_id);

        $runs = Activity::where('object_type', 'workflow')
            ->where('object_id', $workflow->id)
            ->whereIn('event_type', ['fluent_support/workflow_ran', 'fluent_support/workflow_failed'])
            ->latest('id')
            ->limit(min(max($request->getInt('limit', 20), 1), 100))
            ->get();

        // Each line names its ticket (data-ticket-id): keep the ones the ticket list would show this agent.
        $ticketId = fn($run) => preg_match('/data-ticket-id="(\d+)"/', (string) $run->description, $m) ? (int) $m[1] : 0;
        $ids = array_filter($runs->map($ticketId)->toArray());
        $query = \FluentSupport\App\Models\Ticket::whereIn('id', $ids ?: [0]);
        (new \FluentSupport\App\Services\Tickets\AgentTicketAccess())->applyListScope($query);
        $visible = array_map('intval', $query->pluck('id')->toArray());
        $runs = $runs->filter(fn($run) => in_array($ticketId($run), $visible, true))->values();

        return [
            'runs' => $runs->map(fn($run) => [
                'id'          => (int) $run->id,
                'failed'      => $run->event_type === 'fluent_support/workflow_failed',
                'description' => $run->description,
                'created_at'  => $run->created_at,
            ])->toArray()
        ];
    }

    /**
     * Runs a published manual workflow on the tickets the agent can see.
     */
    public function run(Request $request, $workflow_id)
    {
        $workflow = $this->find($workflow_id);
        $ticketIds = array_filter(array_map('absint', (array) $request->get('ticket_ids', [])));

        if (!$ticketIds) {
            throw ApiException::invalid(__('No ticket found', 'fluent-support-pro'));
        }
        // Same cap as the ticket bulk actions: every action runs per ticket in this request.
        if (count($ticketIds) > self::MAX_RUN_TICKETS) {
            /* translators: %d is the most tickets one run can change */
            throw ApiException::invalid(sprintf(__('You can change at most %d tickets at a time.', 'fluent-support-pro'), self::MAX_RUN_TICKETS));
        }
        if ($workflow->status != 'published' || $workflow->trigger_type != 'manual') {
            throw ApiException::invalid(__('The selected workflow needs to be published and have trigger type manual', 'fluent-support-pro'));
        }

        $actions = $workflow->orderedActions();
        if (!$actions) {
            throw ApiException::invalid(__('No actions found for this workflow', 'fluent-support-pro'));
        }

        // A Change Mailbox action may not move tickets into a mailbox the agent is
        // restricted from (same rule as MailBoxController::moveTickets()).
        $restricted = array_map('intval', PermissionManager::getRestrictedMailboxIds());
        foreach ($actions as $action) {
            if ($action->action_name === 'fs_action_change_mailbox' && in_array((int) Arr::get($action->settings, 'mailbox_id'), $restricted, true)) {
                throw ApiException::invalid(__('You do not have access to the specified mailbox', 'fluent-support-pro'));
            }
        }

        $query = Ticket::whereIn('id', $ticketIds);
        // Kept for third-party code hooked here. It skips mailbox restrictions, so it is not enough alone.
        do_action_ref_array('fluent_support/tickets_query_by_permission_ref', [&$query, false]);
        // The real check: visibility and mailbox restrictions.
        (new AgentTicketAccess())->applyAccessScope($query);
        $tickets = $query->get();

        if ($tickets->isEmpty()) {
            throw ApiException::invalid(__('No tickets found based on your permission for this workflow', 'fluent-support-pro'));
        }

        $actor = Helper::getAgentByUserId();
        $didRun = false;
        $hadFailures = false;
        foreach ($tickets as $ticket) {
            $failed = Runner::run($workflow, $ticket, $actions);
            if ($failed !== false) {
                $didRun = true;
                $hadFailures = $hadFailures || $failed;
                Runner::logRun($workflow, $ticket, $failed, $actor, __('Manual run', 'fluent-support-pro'));
                do_action('fluent_support/workflow_triggered', $workflow, $ticket, $actor, ['source' => 'manual', 'event' => 'manual_run']);
            }
        }

        if (!$didRun) {
            throw ApiException::invalid(__('Actions could not be executed', 'fluent-support-pro'));
        }

        // 200, not an error: the other actions already ran, and the UI must still close and reload.
        if ($hadFailures) {
            return [
                'message'      => __('Some workflow actions could not be applied. Please check the error log for details.', 'fluent-support-pro'),
                'has_failures' => true
            ];
        }

        return [
            'message' => __('Selected workflow actions have been successfully applied', 'fluent-support-pro')
        ];
    }

    /**
     * @return Workflow
     */
    private function find($workflowId)
    {
        $workflow = Workflow::find($workflowId);

        if (!$workflow) {
            throw ApiException::notFound();
        }

        return $workflow;
    }

    private function uniqueTitle($title, $exceptId = 0)
    {
        if (!$title) {
            throw ApiException::invalid(__('The title field is required.', 'fluent-support-pro'));
        }
        if (Workflow::where('title', $title)->where('id', '!=', $exceptId)->exists()) {
            throw ApiException::invalid(__('Workflow title needs to be unique', 'fluent-support-pro'));
        }

        return $title;
    }
}
