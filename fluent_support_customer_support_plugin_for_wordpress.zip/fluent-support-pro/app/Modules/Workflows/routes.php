<?php

defined('ABSPATH') || exit;

/**
 * @var \FluentSupport\Framework\Http\Router $router
 */

use FluentSupportPro\App\Modules\Workflows\WorkflowController;
use FluentSupportPro\App\Modules\Workflows\WorkflowPolicy;

$router->prefix('workflows')->withPolicy(WorkflowPolicy::class)->group(function ($router) {
    $router->get('/', [WorkflowController::class, 'index']);
    $router->post('/', [WorkflowController::class, 'create']);
    $router->get('/options', [WorkflowController::class, 'options']);
    $router->get('/commerce-options', [WorkflowController::class, 'commerceOptions']);
    $router->post('/action-sequence', [WorkflowController::class, 'saveActionOrder']);
    $router->post('/duplicate/{workflow_id}', [WorkflowController::class, 'duplicate'])->int('workflow_id');
    $router->get('/{workflow_id}', [WorkflowController::class, 'get'])->int('workflow_id');
    $router->post('/{workflow_id}', [WorkflowController::class, 'update'])->int('workflow_id');
    $router->delete('/{workflow_id}', [WorkflowController::class, 'delete'])->int('workflow_id');
    $router->get('/{workflow_id}/actions', [WorkflowController::class, 'actions'])->int('workflow_id');
    $router->get('/{workflow_id}/runs', [WorkflowController::class, 'runs'])->int('workflow_id');
    $router->post('/{workflow_id}/run', [WorkflowController::class, 'run'])->int('workflow_id');
});
