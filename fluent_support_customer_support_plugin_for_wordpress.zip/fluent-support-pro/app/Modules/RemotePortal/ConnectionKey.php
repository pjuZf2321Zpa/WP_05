<?php

namespace FluentSupportPro\App\Modules\RemotePortal;

/**
 * The one-time key an administrator generates here (Settings > Remote Portal)
 * and pastes into the Fluent Support Connector on the main site, together with
 * the username and Application Password of the user the portal acts as.
 *
 * Format: "fsc1." followed by base64url(JSON {site, api, secret}). Only a hash
 * of the secret is stored, and it expires after LIFETIME seconds.
 */
class ConnectionKey
{
    const PREFIX = 'fsc1.';

    const OPTION = 'fluent_support_remote_portal_key';

    // Seconds a key stays valid.
    const LIFETIME = 1800;

    /**
     * Replace any pending key with a new one.
     *
     * @return array ['connection_key' => string, 'expires_at' => int]
     */
    public static function create()
    {
        $secret = bin2hex(random_bytes(32));
        $expiresAt = time() + self::LIFETIME;

        update_option(self::OPTION, [
            'hash'       => hash('sha256', $secret),
            'expires_at' => $expiresAt,
        ], false);

        $payload = wp_json_encode([
            'site'   => untrailingslashit(site_url()),
            'api'    => untrailingslashit(get_rest_url()),
            'secret' => $secret,
        ]);

        return [
            'connection_key' => self::PREFIX . rtrim(strtr(base64_encode($payload), '+/', '-_'), '='),
            'expires_at'     => $expiresAt,
        ];
    }

    /**
     * @param string $secret
     * @return bool
     */
    public static function isValidSecret($secret)
    {
        $pending = get_option(self::OPTION);

        if (!$secret || !is_string($secret) || !is_array($pending) || empty($pending['hash']) || (int)($pending['expires_at'] ?? 0) < time()) {
            return false;
        }

        return hash_equals((string)$pending['hash'], hash('sha256', $secret));
    }

    /**
     * Use up the pending key if it is still the one for $secret. Of two requests
     * with the same key only one gets true, and a key generated meanwhile is left alone.
     *
     * @param string $secret
     * @return bool
     */
    public static function claim($secret)
    {
        global $wpdb;

        if (!self::isValidSecret($secret)) {
            return false;
        }

        $deleted = $wpdb->query($wpdb->prepare(
            "DELETE FROM {$wpdb->options} WHERE option_name = %s AND option_value = %s",
            self::OPTION,
            maybe_serialize(get_option(self::OPTION))
        ));

        wp_cache_delete(self::OPTION, 'options');
        wp_cache_delete('notoptions', 'options');

        return $deleted === 1;
    }

    public static function forget()
    {
        delete_option(self::OPTION);
    }

    /**
     * When the pending key expires, if there is one.
     *
     * @return int
     */
    public static function pendingExpiresAt()
    {
        $pending = get_option(self::OPTION);
        $expiresAt = is_array($pending) ? (int)($pending['expires_at'] ?? 0) : 0;

        return $expiresAt > time() ? $expiresAt : 0;
    }

    /**
     * Format only: the main site may be a local or private host during development.
     *
     * @param string $url
     * @return bool
     */
    public static function isHttpUrl($url)
    {
        return $url
            && filter_var($url, FILTER_VALIDATE_URL)
            && in_array(strtolower((string)wp_parse_url($url, PHP_URL_SCHEME)), ['http', 'https'], true);
    }

    /**
     * Same scheme, host and port.
     *
     * @param string $url
     * @param string $otherUrl
     * @return bool
     */
    public static function isSameOrigin($url, $otherUrl)
    {
        $origin = function ($url) {
            $parts = wp_parse_url($url);

            return strtolower(($parts['scheme'] ?? '') . '://' . ($parts['host'] ?? '') . ':' . ($parts['port'] ?? ''));
        };

        return self::isSameHost($url, $otherUrl) && $origin($url) === $origin($otherUrl);
    }

    /**
     * @param string $url
     * @param string $otherUrl
     * @return bool
     */
    public static function isSameHost($url, $otherUrl)
    {
        $host = strtolower((string)wp_parse_url($url, PHP_URL_HOST));

        return $host && $host === strtolower((string)wp_parse_url($otherUrl, PHP_URL_HOST));
    }
}
