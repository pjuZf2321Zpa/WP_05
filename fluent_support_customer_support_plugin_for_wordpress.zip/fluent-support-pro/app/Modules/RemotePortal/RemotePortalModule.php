<?php

namespace FluentSupportPro\App\Modules\RemotePortal;

/**
 * Remote Portal: customers use a portal on another WordPress site (the main
 * site, running the Fluent Support Connector) while tickets live here.
 *
 * The connector calls this site with an Application Password the owner created
 * for an agent (or admin) of their choice, through the free plugin's
 * customer-portal routes with on_behalf. This module adds the connection
 * routes (see app/Http/routes.php) and pulls customer widgets back from the
 * main site with the API token the connector issued.
 */
class RemotePortalModule
{
    public function init()
    {
        // The standalone Fluent Support Server plugin did the same job; running both would double every widget.
        if (class_exists('\FluentSupportServer')) {
            add_action('admin_notices', [$this, 'legacyPluginNotice']);
            return;
        }

        if (!RemotePortalSettings::isEnabled() || !RemotePortalSettings::isConnected()) {
            return;
        }

        (new RemoteWidgets())->register();
    }

    /**
     * Whether the connector routes may answer at all (RemotePortalPolicy checks it).
     *
     * @return bool
     */
    public static function canServeRemote()
    {
        // canActOnBehalf() arrived in free after 2.4.0; without it every remote request would fatal.
        return !class_exists('\FluentSupportServer')
            && method_exists('\FluentSupport\App\Http\Policies\PortalPolicy', 'canActOnBehalf')
            && RemotePortalSettings::isEnabled();
    }

    public function legacyPluginNotice()
    {
        if (!current_user_can('activate_plugins')) {
            return;
        }

        echo '<div class="notice notice-warning"><p>' . esc_html__('Remote Portal is now part of Fluent Support Pro. Deactivate the Fluent Support Server plugin, then reconnect your main site from Fluent Support > Settings > Remote Portal.', 'fluent-support-pro') . '</p></div>';
    }
}
