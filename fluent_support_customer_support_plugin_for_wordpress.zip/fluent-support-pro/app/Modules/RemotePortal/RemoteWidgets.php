<?php

namespace FluentSupportPro\App\Modules\RemotePortal;

/**
 * Pulls customer widgets (purchases, CRM data) from the connected main site and
 * points customer-facing ticket links at its portal page.
 */
class RemoteWidgets
{
    public function register()
    {
        add_filter('fluent_support/customer_extra_widgets', [$this, 'pushRemoteWidgets'], 1000, 3);
        add_filter('fluent_support/portal_base_url', [$this, 'portalBaseUrl'], 100, 1);
        add_filter('fluent_support/portal_admin_base_url', [$this, 'adminPortalBaseUrl'], 100, 1);
    }

    /**
     * Remote widgets are keyed '<key>_remote', so they never collide with this site's own.
     *
     * @param array $widgets
     * @param object|array $customer
     * @param array $context ['format' => 'html'|'mcp', 'keys' => string[]|null]
     * @return array
     */
    public function pushRemoteWidgets($widgets, $customer, $context = [])
    {
        $customer = (object)$customer;

        if (empty($customer->email)) {
            return $widgets;
        }

        $remoteKeys = [];

        // The caller asked for specific widgets: fetch only the remote ones, if any.
        if (!empty($context['keys']) && is_array($context['keys'])) {
            foreach ($context['keys'] as $key) {
                if (substr((string)$key, -7) === '_remote') {
                    $remoteKeys[] = substr((string)$key, 0, -7);
                }
            }

            if (!$remoteKeys) {
                return $widgets;
            }
        }

        $params = [
            'remote_uid' => isset($customer->remote_uid) ? $customer->remote_uid : '',
            'email'      => $customer->email,
            'format'     => isset($context['format']) && $context['format'] === 'mcp' ? 'mcp' : 'html',
        ];

        if ($remoteKeys) {
            $params['keys'] = implode(',', $remoteKeys);
        }

        $response = (new RemoteSiteClient())->getWidgets($params, 8, true);

        if (is_wp_error($response) || empty($response['widgets']) || !is_array($response['widgets'])) {
            return $widgets;
        }

        foreach ($response['widgets'] as $widgetKey => $widget) {
            $widgets[$widgetKey . '_remote'] = $widget;
        }

        return $widgets;
    }

    public function portalBaseUrl($url)
    {
        $portalUrl = RemotePortalSettings::get()['portal_url'];

        return $portalUrl ? untrailingslashit($portalUrl) : $url;
    }

    public function adminPortalBaseUrl($url)
    {
        if (defined('FLUENT_SUPPORT_ADMIN_PORTAL_BASE_URL') && FLUENT_SUPPORT_ADMIN_PORTAL_BASE_URL) {
            return FLUENT_SUPPORT_ADMIN_PORTAL_BASE_URL;
        }

        return $url;
    }
}
