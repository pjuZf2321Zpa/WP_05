<?php

namespace FluentSupportPro\App\Modules\RemotePortal;

/**
 * Calls the connected main site's widget endpoint. The only credential is the
 * API token the connector issued at connect, sent in X-Fluent-Support-Token.
 */
class RemoteSiteClient
{
    const TOKEN_HEADER = 'X-Fluent-Support-Token';

    // Set for a minute after the main site could not be reached.
    const DOWN_TRANSIENT = 'fluent_support_remote_portal_down';

    /**
     * @param array $params
     * @param int $timeout seconds; short by default because an agent waits on the sidebar
     * @param bool $skipWhenDown don't call a main site that just failed: every ticket
     *                           view would wait the full timeout. Connection tests call it anyway.
     * @return array|\WP_Error decoded response body
     */
    public function getWidgets($params = [], $timeout = 8, $skipWhenDown = false)
    {
        $settings = RemotePortalSettings::get();

        if (empty($settings['widget_endpoint']) || empty($settings['api_token'])) {
            return new \WP_Error('not_connected', __('No main site is connected.', 'fluent-support-pro'));
        }

        if ($skipWhenDown && get_transient(self::DOWN_TRANSIENT)) {
            return new \WP_Error('remote_down', __('The main site could not be reached a moment ago.', 'fluent-support-pro'));
        }

        $response = wp_remote_get(add_query_arg(array_map('rawurlencode', $params), $settings['widget_endpoint']), [
            'timeout'     => $timeout,
            'sslverify'   => self::shouldVerifySsl($settings['widget_endpoint']),
            // A redirect would carry the token header to wherever it points.
            'redirection' => 0,
            'headers'   => [
                self::TOKEN_HEADER => $settings['api_token'],
                'Accept'           => 'application/json',
            ],
        ]);

        if (is_wp_error($response)) {
            RemotePortalSettings::touch('last_outbound_at', ['last_outbound_ok' => 'no']);
            set_transient(self::DOWN_TRANSIENT, 1, MINUTE_IN_SECONDS);
            return $response;
        }

        if (get_transient(self::DOWN_TRANSIENT)) {
            delete_transient(self::DOWN_TRANSIENT);
        }

        $code = (int)wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);

        if ($code > 299 || !is_array($body)) {
            RemotePortalSettings::touch('last_outbound_at', ['last_outbound_ok' => 'no']);

            if ($code === 401 || $code === 403) {
                return new \WP_Error('invalid_token', __('The main site rejected the API token. Reconnect from the main site.', 'fluent-support-pro'), ['status' => $code]);
            }

            return new \WP_Error('remote_error', sprintf(
                /* translators: %d: HTTP status code */
                __('The main site answered with HTTP %d.', 'fluent-support-pro'),
                $code
            ), ['status' => $code]);
        }

        RemotePortalSettings::touch('last_outbound_at', ['last_outbound_ok' => 'yes']);

        return $body;
    }

    /**
     * Always verify the remote certificate, except on a site marked as local or
     * development in wp-config (WP_ENVIRONMENT_TYPE), where certificates are often self-signed.
     *
     * @param string $url
     * @return bool
     */
    public static function shouldVerifySsl($url)
    {
        return (bool)apply_filters('fluent_support/remote_portal_ssl_verify', !self::isDevSite(), $url);
    }

    /**
     * WP_ENVIRONMENT_TYPE is local or development: self-signed certificates and
     * plain HTTP are allowed.
     *
     * @return bool
     */
    public static function isDevSite()
    {
        return in_array(wp_get_environment_type(), ['local', 'development'], true);
    }
}
