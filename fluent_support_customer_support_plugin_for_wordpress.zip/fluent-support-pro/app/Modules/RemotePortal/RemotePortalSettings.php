<?php

namespace FluentSupportPro\App\Modules\RemotePortal;

use FluentSupport\Framework\Support\Arr;

/**
 * Remote Portal connection settings: one main site (running the Fluent Support
 * Connector) files and reads tickets here on behalf of its customers.
 *
 * wp-config constants override the stored values. Setting the portal URL and the
 * token connects the main site without the key flow:
 *   FLUENT_SUPPORT_REMOTE_PORTAL         enable or disable the module
 *   FLUENT_SUPPORT_PORTAL_BASE_URL       customer portal page on the main site; the main site is its origin
 *   FLUENT_SUPPORT_REMOTE_API_TOKEN      token sent on widget calls, the same on both sites
 *   FLUENT_SUPPORT_REMOTE_API_URL        main site REST base, only if it is not /wp-json
 *   FLUENT_SUPPORT_ADMIN_PORTAL_BASE_URL admin portal URL used in links
 */
class RemotePortalSettings
{
    const OPTION = 'fluent_support_remote_portal';

    const WIDGET_ROUTE = '/fluent-support-client/info/widgets';

    public static function defaults()
    {
        return [
            'enabled'           => 'no',
            'user_id'           => 0,
            'remote_url'        => '',
            'widget_endpoint'   => '',
            'portal_url'        => '',
            'api_token'         => '',
            'connector_version' => '',
            'providers'         => [],
            'connected_at'      => '',
            'last_inbound_at'   => '',
            'last_outbound_at'  => '',
            'last_outbound_ok'  => '',
        ];
    }

    /**
     * Stored values with the wp-config constants applied.
     *
     * @return array
     */
    public static function get()
    {
        $settings = wp_parse_args(self::getStored(), self::defaults());

        if (self::isConstantMode()) {
            // The constants are the whole connection: nothing left from a key
            // connection (its user or token) applies, and the module is on.
            $settings = array_merge($settings, self::constantConnection(
                constant('FLUENT_SUPPORT_PORTAL_BASE_URL'),
                defined('FLUENT_SUPPORT_REMOTE_API_URL') ? FLUENT_SUPPORT_REMOTE_API_URL : ''
            ), [
                'enabled'   => 'yes',
                'user_id'   => 0,
                'api_token' => self::constantToken(),
            ]);
        } elseif (self::constantToken()) {
            $settings['api_token'] = self::constantToken();
        }

        if (defined('FLUENT_SUPPORT_REMOTE_PORTAL')) {
            $settings['enabled'] = FLUENT_SUPPORT_REMOTE_PORTAL ? 'yes' : 'no';
        }

        return $settings;
    }

    /**
     * The main site from wp-config: its address is the portal page's origin, and
     * widgets are read from its REST base (/wp-json unless $restUrl is set).
     *
     * @param string $portalUrl
     * @param string $restUrl
     * @return array remote_url, widget_endpoint and portal_url
     */
    public static function constantConnection($portalUrl, $restUrl = '')
    {
        $portalUrl = untrailingslashit((string)$portalUrl);
        $parts = wp_parse_url($portalUrl);
        $remoteUrl = '';

        if (!empty($parts['scheme']) && !empty($parts['host'])) {
            $remoteUrl = $parts['scheme'] . '://' . $parts['host'] . (!empty($parts['port']) ? ':' . $parts['port'] : '');
        }

        $restUrl = $restUrl ? untrailingslashit((string)$restUrl) : ($remoteUrl ? $remoteUrl . '/wp-json' : '');

        // Widget calls carry customer emails: only to the main site itself.
        if (!$remoteUrl || !ConnectionKey::isSameOrigin($restUrl, $remoteUrl)) {
            return ['remote_url' => $remoteUrl, 'widget_endpoint' => '', 'portal_url' => $portalUrl];
        }

        return [
            'remote_url'      => $remoteUrl,
            'widget_endpoint' => $restUrl . self::WIDGET_ROUTE,
            'portal_url'      => $portalUrl,
        ];
    }

    public static function getStored()
    {
        $settings = get_option(self::OPTION, []);

        return is_array($settings) ? $settings : [];
    }

    /**
     * Merge $changes into the stored option. get() applies the wp-config
     * constants on top, so removing a constant falls back to what was saved.
     *
     * @param array $changes
     * @return array the new stored settings
     */
    public static function update($changes)
    {
        $settings = array_merge(wp_parse_args(self::getStored(), self::defaults()), $changes);
        $settings = Arr::only($settings, array_keys(self::defaults()));

        update_option(self::OPTION, $settings, false);

        return $settings;
    }

    /**
     * Forget the connected main site. The switch stays as it was, and the
     * Application Password stays: the site owner created it and revokes it.
     */
    public static function clearConnection()
    {
        return self::update([
            'user_id'           => 0,
            'remote_url'        => '',
            'widget_endpoint'   => '',
            'portal_url'        => '',
            'api_token'         => '',
            'connector_version' => '',
            'providers'         => [],
            'connected_at'      => '',
            'last_inbound_at'   => '',
            'last_outbound_at'  => '',
            'last_outbound_ok'  => '',
        ]);
    }

    /**
     * The widget API token from wp-config.php, if set. It must be the same on both sites.
     *
     * @return string
     */
    public static function constantToken()
    {
        return defined('FLUENT_SUPPORT_REMOTE_API_TOKEN') && FLUENT_SUPPORT_REMOTE_API_TOKEN ? (string)FLUENT_SUPPORT_REMOTE_API_TOKEN : '';
    }

    public static function isEnabled()
    {
        return Arr::get(self::get(), 'enabled') === 'yes';
    }

    /**
     * A main site is connected: either through the connector's connect call,
     * or entirely through wp-config constants. Either way it needs the API
     * token, or widget calls can never succeed.
     *
     * @return bool
     */
    public static function isConnected()
    {
        $settings = self::get();

        return !empty($settings['widget_endpoint'])
            && !empty($settings['api_token'])
            && (!empty($settings['user_id']) || self::isConstantMode());
    }

    /**
     * The connection is defined in wp-config, so no connect call ever names its user.
     *
     * @return bool
     */
    public static function isConstantMode()
    {
        return defined('FLUENT_SUPPORT_PORTAL_BASE_URL') && FLUENT_SUPPORT_PORTAL_BASE_URL;
    }

    /**
     * Names of the constants that are currently set, for the settings page.
     *
     * @return string[]
     */
    public static function definedConstants()
    {
        $names = [
            'FLUENT_SUPPORT_REMOTE_PORTAL',
            'FLUENT_SUPPORT_PORTAL_BASE_URL',
            'FLUENT_SUPPORT_REMOTE_API_TOKEN',
            'FLUENT_SUPPORT_REMOTE_API_URL',
            'FLUENT_SUPPORT_ADMIN_PORTAL_BASE_URL',
        ];

        return array_values(array_filter($names, 'defined'));
    }

    /**
     * Throttled so a busy portal does not write the option on every request.
     *
     * @param string $key last_inbound_at|last_outbound_at
     * @param array $extra
     */
    public static function touch($key, $extra = [])
    {
        $settings = self::getStored();
        $last = Arr::get($settings, $key);
        $unchanged = Arr::only($settings, array_keys($extra)) == $extra;

        if ($unchanged && $last && (current_time('timestamp') - strtotime($last)) < 5 * MINUTE_IN_SECONDS) {
            return;
        }

        self::update(array_merge([$key => current_time('mysql')], $extra));
    }
}
