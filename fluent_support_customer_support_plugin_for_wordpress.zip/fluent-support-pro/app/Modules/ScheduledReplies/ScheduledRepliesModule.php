<?php

namespace FluentSupportPro\App\Modules\ScheduledReplies;

/**
 * Scheduled replies: an agent writes a reply now and it goes out at a time they pick.
 * The reply box UI ships in the free plugin and shows it once `scheduled_replies` is set.
 */
class ScheduledRepliesModule
{
    public function init()
    {
        if (!self::isAvailable()) {
            return;
        }

        add_action(ScheduledReplyService::ACTION_HOOK, function ($conversationId) {
            (new ScheduledReplyService())->publish($conversationId);
        });

        add_action('fluent_support/response_added_by_customer', function ($response, $ticket) {
            (new ScheduledReplyService())->pauseForTicket($ticket, 'customer_replied');
        }, 10, 2);

        add_action('fluent_support/ticket_closed', function ($ticket) {
            (new ScheduledReplyService())->pauseForTicket($ticket, 'ticket_closed');
        });

        add_action('fluent_support/deleting_ticket', function ($ticket) {
            (new ScheduledReplyService())->unqueueForTicket($ticket->id);
        });

        // A job lost any other way (a failed run, Free switched off while Pro stayed on) is queued again or held here
        add_action('fluent_support_hourly_tasks', function () {
            (new ScheduledReplyService())->resync();
        });

        add_filter('fluent_support/schedule_response', function ($responseData, $data, $agent, $ticket, $scheduledAt) {
            // An earlier handler already scheduled it
            if ($responseData) {
                return $responseData;
            }

            return (new ScheduledReplyService())->schedule($data, $agent, $ticket, $scheduledAt);
        }, 10, 5);

        add_filter('fluent_support/tickets_list', function ($tickets) {
            (new ScheduledReplyService())->loadForTickets($tickets);
            return $tickets;
        });

        add_filter('fluent_support/ticket_view_data', [$this, 'addPendingReply'], 10, 3);

        add_filter('fluent_support_app_vars', function ($vars) {
            $vars['scheduled_replies'] = true;
            return $vars;
        });
    }

    /**
     * The free plugin leaves unsent scheduled rows out of the thread; send the pending one as its own key.
     *
     * @param array $data
     * @param \FluentSupport\App\Models\Ticket $ticket
     * @param iterable $scheduledRows Rendered `schedule` conversations of the ticket
     * @return array
     */
    public function addPendingReply($data, $ticket, $scheduledRows)
    {
        $data['scheduled_reply'] = null;

        foreach ($scheduledRows as $row) {
            $row->schedule = (new ScheduledReplyService())->getSchedule($row);
            $data['scheduled_reply'] = $row;
            break;
        }

        return $data;
    }

    /**
     * The free plugin added the filters and publish step this module needs in 2.5.0.
     *
     * @return bool
     */
    public static function isAvailable()
    {
        return method_exists('\FluentSupport\App\Services\Tickets\ResponseService', 'publishPendingConversation')
            && method_exists('\FluentSupport\App\Services\Tickets\ResponseService', 'attachUploads')
            && method_exists('\FluentSupport\App\Services\Tickets\TicketService', 'afterAgentAssigned')
            && function_exists('as_schedule_single_action');
    }

    // Jobs were removed on deactivation; queue them again, or hold the ones whose time passed
    public static function onActivation()
    {
        if (self::isAvailable()) {
            (new ScheduledReplyService())->resync();
        }
    }

    // A job that fires while Pro is off has no handler, so Action Scheduler would drop it
    public static function onDeactivation()
    {
        if (function_exists('as_unschedule_all_actions')) {
            as_unschedule_all_actions(ScheduledReplyService::ACTION_HOOK);
        }
    }
}
