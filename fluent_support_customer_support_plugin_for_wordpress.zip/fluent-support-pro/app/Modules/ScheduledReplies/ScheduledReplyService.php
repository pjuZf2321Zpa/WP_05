<?php

namespace FluentSupportPro\App\Modules\ScheduledReplies;

use FluentSupport\App\Models\Activity;
use FluentSupport\App\Models\Agent;
use FluentSupport\App\Models\Attachment;
use FluentSupport\App\Models\Conversation;
use FluentSupport\App\Models\Meta;
use FluentSupport\App\Models\Ticket;
use FluentSupport\App\Services\Helper;
use FluentSupport\App\Services\Tickets\ResponseService;
use FluentSupport\App\Services\Tickets\TicketService;
use FluentSupport\Framework\Support\Arr;

/**
 * A scheduled reply is a `schedule` conversation: agents see it, customers and notifications don't.
 * Publishing turns it into a normal `response`.
 */
class ScheduledReplyService
{
    const TYPE = 'schedule';

    const ACTION_HOOK = 'fluent_support/send_scheduled_reply';

    const ACTION_GROUP = 'fluent-support';

    // fs_meta key holding the schedule status outside the serialized settings, so SQL can filter on it
    const STATUS_META_KEY = 'schedule_status';

    /**
     * The ticket's pending (scheduled or paused) reply. A ticket holds at most one.
     *
     * @param int $ticketId
     * @return Conversation|null
     */
    public function getPending($ticketId)
    {
        return Conversation::where('ticket_id', $ticketId)
            ->where('conversation_type', self::TYPE)
            ->first();
    }

    /**
     * @param Conversation $conversation
     * @return array
     */
    public function getSchedule($conversation)
    {
        return $this->normalizeSchedule($conversation->getSettingsValue('schedule', []));
    }

    /**
     * @param mixed $schedule
     * @return array
     */
    private function normalizeSchedule($schedule)
    {
        return wp_parse_args(is_array($schedule) ? $schedule : [], [
            'scheduled_at'  => 0,
            'status'        => 'scheduled',
            'paused_reason' => '',
            'close_ticket'  => 'no',
            'informational' => 'no',
            'guard_since'   => '',
            'author_id'     => 0,
        ]);
    }

    /**
     * Set `scheduled_reply` (scheduled_at + status) on each ticket of a list page, for the clock badge.
     *
     * @param iterable $tickets
     * @return void
     */
    public function loadForTickets($tickets)
    {
        $ticketIds = [];
        foreach ($tickets as $ticket) {
            $ticket->scheduled_reply = null;
            $ticketIds[] = $ticket->id;
        }

        if (!$ticketIds) {
            return;
        }

        $conversations = Conversation::whereIn('ticket_id', $ticketIds)
            ->where('conversation_type', self::TYPE)
            ->with('ccinfo')
            ->get(['id', 'ticket_id'])
            ->keyBy('ticket_id');

        if ($conversations->isEmpty()) {
            return;
        }

        foreach ($tickets as $ticket) {
            $conversation = $conversations->get($ticket->id);
            if (!$conversation || !$conversation->ccinfo) {
                continue;
            }

            $settings = Helper::safeUnserialize($conversation->ccinfo->value);
            $schedule = $this->normalizeSchedule(is_array($settings) ? Arr::get($settings, 'schedule') : []);

            $ticket->scheduled_reply = [
                'scheduled_at' => (int) $schedule['scheduled_at'],
                'status'       => $schedule['status'],
            ];
        }
    }

    /**
     * Store the reply now and queue it for $timestamp.
     *
     * @param array $data Same payload as a normal reply (content, attachments, cc_emails...)
     * @param Agent $agent
     * @param Ticket $ticket
     * @param int $timestamp Unix timestamp to send at
     * @return array The ResponseService::createResponse() result
     * @throws \Exception
     */
    public function schedule($data, $agent, $ticket, $timestamp)
    {
        $this->validateTimestamp($timestamp);

        if ($this->getPending($ticket->id)) {
            throw new \Exception(esc_html__('This ticket already has a scheduled reply. Reschedule or cancel it first.', 'fluent-support-pro'));
        }

        $closeTicket = Arr::get($data, 'close_ticket') === 'yes' ? 'yes' : 'no';
        $informational = !empty($data['informational_reply']) ? 'yes' : 'no';

        $ccEmails = (array) Arr::get($data, 'cc_emails', []);

        // These only take effect when the reply goes out; createResponse() would add the Cc to the ticket right away
        unset($data['close_ticket'], $data['informational_reply'], $data['cc_emails']);
        $data['conversation_type'] = self::TYPE;

        // Silently: the reply hooks and notifications fire when it is published, not now
        $result = (new ResponseService())->createResponse($data, $agent, $ticket, true);

        if (!$result) {
            throw new \Exception(esc_html__('Reply content is required', 'fluent-support-pro'));
        }

        $conversation = $result['response'];

        // Two requests can both pass the check above; the oldest scheduled reply wins
        $oldest = Conversation::where('ticket_id', $ticket->id)
            ->where('conversation_type', self::TYPE)
            ->orderBy('id', 'asc')
            ->first();

        if ($oldest && (int) $oldest->id !== (int) $conversation->id) {
            $this->releaseAttachments($conversation);
            $conversation->delete();
            throw new \Exception(esc_html__('This ticket already has a scheduled reply. Reschedule or cancel it first.', 'fluent-support-pro'));
        }

        if ($ccEmails) {
            $conversation->updateSettingsValue('cc_email', $ccEmails);
        }

        $this->saveSchedule($conversation, [
            'scheduled_at'  => $timestamp,
            'status'        => 'scheduled',
            'paused_reason' => '',
            'close_ticket'  => $closeTicket,
            'informational' => $informational,
            'guard_since'   => current_time('mysql'),
            'author_id'     => (int) $agent->id,
        ]);

        try {
            $this->queue($conversation->id, $timestamp);
        } catch (\Exception $e) {
            $this->releaseAttachments($conversation);
            $conversation->delete();
            throw $e;
        }

        /*
         * Fires after an agent schedules a reply.
         *
         * @since 2.5.0
         * @param Conversation $conversation
         * @param Ticket $ticket
         * @param Agent $agent
         */
        do_action('fluent_support/scheduled_reply_created', $conversation, $ticket, $agent);

        return $result;
    }

    /**
     * Edit the content and/or the send time. A new send time also resumes a paused reply.
     *
     * @param Conversation $conversation
     * @param array $data content, scheduled_at, close_ticket, cc_emails, attachments (every file hash the reply keeps)
     * @return Conversation
     * @throws \Exception
     */
    public function update($conversation, $data)
    {
        $schedule = $this->getSchedule($conversation);

        // Validate before saving anything, so a rejected time doesn't leave half the edit stored
        if (!empty($data['scheduled_at'])) {
            $this->validateTimestamp((int) $data['scheduled_at']);
        }

        $content = null;
        if (isset($data['content'])) {
            $content = wp_kses_post($this->parseSmartCodes($data['content'], $conversation));

            if (!trim(wp_strip_all_tags($content)) && strpos($content, '<img') === false) {
                throw new \Exception(esc_html__('Reply content is required', 'fluent-support-pro'));
            }
        }

        if (!empty($data['scheduled_at'])) {
            $timestamp = (int) $data['scheduled_at'];

            // Queue before saving, so a failed reschedule leaves the stored reply untouched
            $this->queue($conversation->id, $timestamp);

            $schedule['scheduled_at'] = $timestamp;
            $schedule['status'] = 'scheduled';
            $schedule['paused_reason'] = '';
            $schedule['guard_since'] = current_time('mysql');
            $schedule['author_id'] = (int) $conversation->person_id;
        }

        if ($content !== null) {
            // Only while it is unsent, so a reply that just went out keeps the text the customer got
            $saved = Conversation::where('id', $conversation->id)
                ->where('conversation_type', self::TYPE)
                ->update(['content' => $content]);

            if (!$saved) {
                throw new \Exception(esc_html__('This scheduled reply was already sent.', 'fluent-support-pro'));
            }

            $conversation->content = $content;

            Helper::tempImageMoveUploadDir($conversation->ticket_id, 'conversation', $conversation->id, $conversation->person_id);
        }

        if (isset($data['close_ticket'])) {
            $schedule['close_ticket'] = $data['close_ticket'] === 'yes' ? 'yes' : 'no';
        }

        // Stored on the reply only; the ticket's Cc list picks it up when the reply is sent
        if (isset($data['cc_emails'])) {
            $conversation->updateSettingsValue('cc_email', array_values((array) $data['cc_emails']));
        }

        if (isset($data['attachments'])) {
            $this->releaseRemovedFiles($conversation, $data['attachments']);

            if ($data['attachments']) {
                (new ResponseService())->attachUploads(Ticket::find($conversation->ticket_id), $conversation, $data['attachments']);
            }
        }

        $this->saveSchedule($conversation, $schedule);

        /*
         * Fires after a scheduled reply's text, time or options change.
         *
         * @since 2.5.0
         * @param Conversation $conversation
         */
        do_action('fluent_support/scheduled_reply_updated', $conversation);

        return $conversation;
    }

    /**
     * Delete the scheduled reply. Returns what the agent wrote so it can go back into the editor.
     *
     * @param Conversation $conversation
     * @param \FluentSupport\App\Models\Person|null $cancelledBy
     * @return array
     * @throws \Exception When the reply was sent in the meantime
     */
    public function cancel($conversation, $cancelledBy = null)
    {
        // Claim it first, so a send that is already running can't have its reply deleted
        $claimed = Conversation::where('id', $conversation->id)
            ->where('conversation_type', self::TYPE)
            ->update(['conversation_type' => 'schedule_cancelled']);

        if (!$claimed) {
            throw new \Exception(esc_html__('This scheduled reply was already sent.', 'fluent-support-pro'));
        }

        $this->unqueue($conversation->id);

        $restore = [
            'content'   => $conversation->content,
            'cc_emails' => $conversation->getSettingsValue('cc_email', []),
        ];

        if ($cancelledBy) {
            Activity::create([
                'event_type'  => 'fluent_support/scheduled_reply_cancelled',
                'person_id'   => $cancelledBy->id,
                'person_type' => $cancelledBy->person_type,
                'object_id'   => $conversation->ticket_id,
                'object_type' => 'ticket',
                'description' => sprintf(
                    /* translators: 1: agent name, 2: ticket id */
                    __('%1$s cancelled a scheduled reply on ticket #%2$d', 'fluent-support-pro'),
                    $cancelledBy->full_name,
                    $conversation->ticket_id
                ),
            ]);
        }

        $restore['attachments'] = $this->releaseAttachments($conversation);

        $conversation->delete();

        /*
         * Fires after a scheduled reply is cancelled. The conversation row is already deleted.
         *
         * @since 2.5.0
         * @param Conversation $conversation
         * @param \FluentSupport\App\Models\Person|null $cancelledBy
         */
        do_action('fluent_support/scheduled_reply_cancelled', $conversation, $cancelledBy);

        return $restore;
    }

    /**
     * Publish right away, ignoring the schedule and any pause.
     *
     * @param Conversation $conversation
     * @return bool
     */
    public function sendNow($conversation)
    {
        $this->unqueue($conversation->id);

        return $this->publish($conversation->id, true);
    }

    /**
     * "Send as planned" on a paused reply: requeue it for its original time, or send it
     * now if that time has already passed.
     *
     * @param Conversation $conversation
     * @return bool True when the reply was sent right away
     * @throws \Exception
     */
    public function resume($conversation)
    {
        $schedule = $this->getSchedule($conversation);

        if ($schedule['scheduled_at'] <= time()) {
            if (!$this->sendNow($conversation)) {
                throw new \Exception(esc_html__('The scheduled reply could not be sent. Please refresh the ticket.', 'fluent-support-pro'));
            }

            return true;
        }

        $this->queue($conversation->id, $schedule['scheduled_at']);

        $schedule['status'] = 'scheduled';
        $schedule['paused_reason'] = '';
        $schedule['guard_since'] = current_time('mysql');
        $schedule['author_id'] = (int) $conversation->person_id;
        $this->saveSchedule($conversation, $schedule);

        return false;
    }

    /**
     * Hold a scheduled reply until an agent reviews it.
     *
     * @param Conversation $conversation
     * @param string $reason customer_replied | ticket_closed | agent_unavailable | missed
     * @return void
     */
    public function pause($conversation, $reason)
    {
        $schedule = $this->getSchedule($conversation);

        if ($schedule['status'] === 'paused') {
            return;
        }

        $this->unqueue($conversation->id);

        $schedule['status'] = 'paused';
        $schedule['paused_reason'] = $reason;
        $this->saveSchedule($conversation, $schedule);

        /*
         * Fires when a scheduled reply is held for an agent to review.
         *
         * @since 2.5.0
         * @param Conversation $conversation
         * @param string $reason customer_replied | ticket_closed | agent_unavailable | missed
         */
        do_action('fluent_support/scheduled_reply_paused', $conversation, $reason);
    }

    /**
     * @param Ticket $ticket
     * @param string $reason
     * @return void
     */
    public function pauseForTicket($ticket, $reason)
    {
        if (!$ticket) {
            return;
        }

        $conversation = $this->getPending($ticket->id);

        if ($conversation) {
            $this->pause($conversation, $reason);
        }
    }

    /**
     * Before a merge moves a ticket's conversations away, turn its scheduled reply into an
     * internal note, so it never goes out to the other ticket's customer.
     *
     * @param int $ticketId The ticket being merged into another
     * @return void
     */
    public function convertForMerge($ticketId)
    {
        $conversations = Conversation::where('ticket_id', $ticketId)
            ->where('conversation_type', self::TYPE)
            ->get();

        foreach ($conversations as $conversation) {
            // Same conditional claim as publish(), so a send already running can't be turned back into a note
            $claimed = Conversation::where('id', $conversation->id)
                ->where('conversation_type', self::TYPE)
                ->update([
                    'conversation_type' => 'note',
                    'content'           => '<p><em>' . esc_html__('This scheduled reply was not sent because its ticket was merged into this one.', 'fluent-support-pro') . '</em></p>' . $conversation->content,
                ]);

            if ($claimed) {
                $this->unqueue($conversation->id);
            }
        }
    }

    /**
     * @param int $ticketId
     * @return void
     */
    public function unqueueForTicket($ticketId)
    {
        $ids = Conversation::where('ticket_id', $ticketId)
            ->where('conversation_type', self::TYPE)
            ->pluck('id');

        foreach ($ids as $id) {
            $this->unqueue($id);
        }
    }

    /**
     * Queue jobs again after Pro was inactive. A reply whose time has passed waits for review.
     *
     * @return void
     */
    public function resync()
    {
        // Runs hourly, so every step works on one batch: paused replies are left out in SQL (a row without
        // the status flag yet is still checked), and jobs and settings are looked up for the batch at once
        $notScheduled = Meta::select('object_id')
            ->where('object_type', 'response')
            ->where('key', self::STATUS_META_KEY)
            ->where('value', '!=', 'scheduled');

        $replies = Conversation::where('conversation_type', self::TYPE)->whereNotIn('id', $notScheduled)->select('id');

        $replies->chunkById(100, function ($conversations) {
            $queued = $this->queuedIds($conversations->pluck('id')->all());

            $ids = array_values(array_filter($conversations->pluck('id')->all(), function ($id) use ($queued) {
                return !isset($queued[(int) $id]);
            }));

            if (!$ids) {
                return;
            }

            $settings = Meta::where('object_type', 'response')
                ->where('key', 'settings')
                ->whereIn('object_id', $ids)
                ->pluck('value', 'object_id');

            foreach ($ids as $id) {
                $schedule = $this->normalizeSchedule(Arr::get((array) Helper::safeUnserialize($settings->get($id, '')), 'schedule'));

                if ($schedule['status'] !== 'scheduled') {
                    continue;
                }

                if ($schedule['scheduled_at'] > time()) {
                    as_schedule_single_action($schedule['scheduled_at'], self::ACTION_HOOK, [(int) $id], self::ACTION_GROUP);
                } else {
                    $this->pause(Conversation::find($id), 'missed');
                }
            }
        });
    }

    /**
     * Send a scheduled reply. Runs from Action Scheduler when the reply is due.
     *
     * @param int $conversationId
     * @param bool $force Skip the pause checks (the agent explicitly asked to send)
     * @return bool Whether the reply was sent
     */
    public function publish($conversationId, $force = false)
    {
        $conversation = Conversation::where('id', (int) $conversationId)
            ->where('conversation_type', self::TYPE)
            ->first();

        // Cancelled, already sent, or its ticket was deleted.
        if (!$conversation) {
            return false;
        }

        $ticket = Ticket::find($conversation->ticket_id);

        if (!$ticket) {
            return false;
        }

        $schedule = $this->getSchedule($conversation);

        if (!$force) {
            if ($schedule['status'] === 'paused') {
                return false;
            }

            // Backstop for a customer reply or a close that did not fire our hooks.
            $reason = $this->getPauseReason($ticket, $schedule);
            if ($reason) {
                $this->pause($conversation, $reason);
                return false;
            }
        }

        $agent = Agent::find($conversation->person_id);

        // Deleting an agent moves their conversations to a fallback agent, who must review before it goes out in their name
        $authorChanged = !$force && $schedule['author_id'] && (int) $schedule['author_id'] !== (int) $conversation->person_id;

        if (!$agent || $authorChanged) {
            $this->pause($conversation, 'agent_unavailable');
            return false;
        }

        // Claim the row first, so a queued run and a manual "Send now" can never both send it.
        $claimed = Conversation::where('id', $conversation->id)
            ->where('conversation_type', self::TYPE)
            ->update(['conversation_type' => 'response']);

        if (!$claimed) {
            return false;
        }

        $previousAgentId = (int) $ticket->agent_id;
        $agentAdded = false;
        if (!$ticket->agent_id) {
            $ticket->agent_id = $agent->id;
            $agentAdded = true;
        }

        $ccEmails = (array) $conversation->getSettingsValue('cc_email', []);
        if ($ccEmails) {
            $ticket->updateSettingsValue('all_cc_email', array_unique(array_merge((array) $ticket->getSettingsValue('all_cc_email', []), $ccEmails)));
        }

        (new ResponseService())->publishPendingConversation($ticket, $conversation, $agent, $schedule['informational'] === 'yes');

        // Same assignment path as a normal reply: the activity line plus the assignment hooks
        if ($agentAdded) {
            (new TicketService())->afterAgentAssigned($ticket, $agent, $previousAgentId);
        }

        if ($schedule['close_ticket'] === 'yes') {
            (new TicketService())->close($ticket, $agent);
        }

        /*
         * Fires after a scheduled reply has been sent to the customer.
         *
         * @since 2.5.0
         * @param Conversation $conversation
         * @param Ticket $ticket
         * @param Agent $agent
         */
        do_action('fluent_support/scheduled_reply_sent', $conversation, $ticket, $agent);

        return true;
    }

    /**
     * @param Ticket $ticket
     * @param array $schedule
     * @return string Empty when the reply may go out
     */
    private function getPauseReason($ticket, $schedule)
    {
        $since = $schedule['guard_since'];

        // A ticket that was already closed when the reply was scheduled doesn't pause it
        $closedSince = !$since || !$ticket->resolved_at || strtotime($ticket->resolved_at) > strtotime($since);

        if ($ticket->status === 'closed' && $closedSince) {
            return 'ticket_closed';
        }

        if ($since && $ticket->last_customer_response && strtotime($ticket->last_customer_response) > strtotime($since)) {
            return 'customer_replied';
        }

        return '';
    }

    // Edited text needs the same smartcode pass createResponse() gave the original
    private function parseSmartCodes($content, $conversation)
    {
        $ticket = Ticket::with('customer')->find($conversation->ticket_id);

        return apply_filters('fluent_support/parse_smartcode_data', $content, [
            'customer' => $ticket ? $ticket->customer : null,
            'agent'    => Agent::find($conversation->person_id),
            'ticket'   => $ticket
        ]);
    }

    /**
     * @param int $timestamp
     * @return void
     * @throws \Exception
     */
    private function validateTimestamp($timestamp)
    {
        if (!$timestamp || $timestamp <= time() + MINUTE_IN_SECONDS) {
            throw new \Exception(esc_html__('Please pick a time at least a minute from now.', 'fluent-support-pro'));
        }

        $maxDays = (int) apply_filters('fluent_support/scheduled_reply_max_days', 90);

        if ($timestamp > time() + $maxDays * DAY_IN_SECONDS) {
            throw new \Exception(sprintf(
                /* translators: %d: number of days */
                esc_html__('A reply can be scheduled at most %d days ahead.', 'fluent-support-pro'),
                (int) $maxDays
            ));
        }
    }

    /**
     * Which of these replies have a pending or running job, in one query.
     * as_next_scheduled_action() is a query per reply and as_get_scheduled_actions() loads each job.
     *
     * @param int[] $conversationIds
     * @return array<int, bool>
     */
    private function queuedIds($conversationIds)
    {
        global $wpdb;

        // Action Scheduler stores a job's args as JSON, e.g. [123]
        $args = array_map(function ($id) {
            return wp_json_encode([(int) $id]);
        }, $conversationIds);

        $placeholders = implode(', ', array_fill(0, count($args), '%s'));

        // phpcs:ignore WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare,WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- placeholders built above
        $found = $wpdb->get_col($wpdb->prepare(
            "SELECT args FROM {$wpdb->prefix}actionscheduler_actions WHERE hook = %s AND status IN ('pending', 'in-progress') AND args IN ({$placeholders})",
            array_merge([self::ACTION_HOOK], $args)
        ));

        $queued = [];
        foreach ($found as $jobArgs) {
            $queued[(int) Arr::get((array) json_decode($jobArgs, true), 0)] = true;
        }

        return $queued;
    }

    private function saveSchedule($conversation, $schedule)
    {
        $conversation->updateSettingsValue('schedule', $schedule);

        Meta::updateOrCreate(
            ['object_type' => 'response', 'object_id' => $conversation->id, 'key' => self::STATUS_META_KEY],
            ['value' => $schedule['status']]
        );
    }

    // Action Scheduler logs a failed enqueue and returns 0 rather than throwing
    private function queue($conversationId, $timestamp)
    {
        $args = [(int) $conversationId];
        $previous = as_next_scheduled_action(self::ACTION_HOOK, $args, self::ACTION_GROUP);

        $this->unqueue($conversationId);

        if (as_schedule_single_action($timestamp, self::ACTION_HOOK, $args, self::ACTION_GROUP)) {
            return;
        }

        // Keep the job it had, so a failed reschedule still sends at the old time
        if (is_int($previous)) {
            as_schedule_single_action($previous, self::ACTION_HOOK, $args, self::ACTION_GROUP);
        }

        throw new \Exception(esc_html__('The reply could not be scheduled. Please try again.', 'fluent-support-pro'));
    }

    /**
     * Detach a scheduled reply's files before the row is deleted, which would otherwise purge them.
     * Uploads go back to in-active, restamped so the abandoned-upload cleanup gives them a fresh window.
     *
     * @param Conversation $conversation
     * @return array The released uploads, for the editor
     */
    private function releaseAttachments($conversation)
    {
        // Inline images stay inline; the restored text still points at them
        Attachment::where('conversation_id', $conversation->id)
            ->where('status', 'inline')
            ->update(['conversation_id' => null]);

        $uploads = Attachment::where('conversation_id', $conversation->id)->get();

        Attachment::where('conversation_id', $conversation->id)
            ->update(['conversation_id' => null, 'status' => 'in-active', 'created_at' => current_time('mysql')]);

        return $uploads->map(function ($attachment) {
            return [
                'file_hash' => $attachment->file_hash,
                'title'     => $attachment->title,
                'file_size' => (int) $attachment->file_size,
                'file_type' => $attachment->file_type,
            ];
        })->values()->all();
    }

    /**
     * Files the agent removed while editing go back to in-active, so the abandoned-upload cleanup deletes them.
     *
     * @param Conversation $conversation
     * @param array $keepHashes
     * @return void
     */
    private function releaseRemovedFiles($conversation, $keepHashes)
    {
        $query = Attachment::where('conversation_id', $conversation->id)->where('status', 'active');

        if ($keepHashes) {
            $query->whereNotIn('file_hash', $keepHashes);
        }

        $query->update(['conversation_id' => null, 'status' => 'in-active', 'created_at' => current_time('mysql')]);
    }

    private function unqueue($conversationId)
    {
        as_unschedule_all_actions(self::ACTION_HOOK, [(int) $conversationId], self::ACTION_GROUP);
    }
}
