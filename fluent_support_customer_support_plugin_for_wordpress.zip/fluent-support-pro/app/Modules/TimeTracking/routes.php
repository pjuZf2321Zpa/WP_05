<?php

defined('ABSPATH') || exit;

/**
 * @var \FluentSupport\Framework\Http\Router $router
 */

use FluentSupportPro\App\Modules\TimeTracking\TimeTrackController;

// On a ticket: any agent who can open it.
$router->prefix('time-tracks')->withPolicy('FluentSupport\App\Http\Policies\AgentTicketPolicy')->group(function ($router) {
    $router->get('/{ticket_id}', [TimeTrackController::class, 'tracks'])->int('ticket_id');
    $router->post('/{ticket_id}', [TimeTrackController::class, 'commit'])->int('ticket_id');
    $router->post('/{ticket_id}/estimated-time', [TimeTrackController::class, 'estimate'])->int('ticket_id');
});

$router->prefix('reports/timesheet')->withPolicy('FluentSupport\App\Http\Policies\ReportPolicy')->group(function ($router) {
    $router->get('/by-tickets', [TimeTrackController::class, 'byTickets']);
    $router->get('/by-agents', [TimeTrackController::class, 'byAgents']);
    $router->get('/by-customers', [TimeTrackController::class, 'byCustomers']);
});
