<?php

namespace FluentSupportPro\App\Modules\TimeTracking;

use FluentSupport\App\Exceptions\ApiException;
use FluentSupport\App\Http\Controllers\Controller;
use FluentSupport\App\Models\Agent;
use FluentSupport\App\Models\Customer;
use FluentSupport\App\Models\MailBox;
use FluentSupport\App\Models\Meta;
use FluentSupport\App\Models\Ticket;
use FluentSupport\App\Modules\PermissionManager;
use FluentSupport\App\Services\Helper;
use FluentSupport\App\Services\Tickets\AgentTicketAccess;
use FluentSupport\Framework\Http\Request\Request;
use FluentSupportPro\App\Models\TimeTrack;
use FluentSupportPro\App\Services\ProHelper;

/**
 * Time tracking on a ticket (the task timer) and the timesheet reports.
 * Timesheets only count tickets in the viewer's mailboxes.
 */
class TimeTrackController extends Controller
{
    /**
     * The ticket's time entries, newest first, and its estimate.
     */
    public function tracks($ticket_id)
    {
        $ticket = $this->ticket($ticket_id);

        return [
            'tracks'            => TimeTrack::where('ticket_id', $ticket->id)->orderBy('updated_at', 'DESC')->with('agent')->get()->map([$this, 'formatTrack'])->all(),
            'estimated_minutes' => $this->estimateOf($ticket->id),
        ];
    }

    /**
     * Records time the current agent worked on the ticket.
     */
    public function commit(Request $request, $ticket_id)
    {
        $ticket = $this->ticket($ticket_id);
        $minutes = $request->getInt('working_minutes');

        if ($minutes <= 0) {
            throw ApiException::invalid(__('Please provide valid hours and minutes', 'fluent-support-pro'));
        }

        $track = TimeTrack::create([
            'status'           => 'committed',
            'agent_id'         => Helper::getAgentByUserId()->id,
            'customer_id'      => (int) $ticket->customer_id,
            'mailbox_id'       => (int) $ticket->mailbox_id,
            'ticket_id'        => (int) $ticket->id,
            'completed_at'     => current_time('mysql'),
            'working_minutes'  => $minutes,
            'billable_minutes' => $minutes,
            'message'          => wp_kses_post(Helper::decodeNonMarkupEntities((string) $request->get('message', ''))),
            'is_manual'        => 1,
        ]);

        return [
            'track'   => $this->formatTrack($track->load('agent')),
            'message' => __('You have successfully submitted your working time', 'fluent-support-pro')
        ];
    }

    public function estimate(Request $request, $ticket_id)
    {
        $ticket = $this->ticket($ticket_id);

        Meta::updateOrCreate(
            ['object_type' => 'ticket_time_tracking', 'object_id' => $ticket->id],
            ['key' => 'estimated_minutes', 'value' => maybe_serialize($request->getInt('estimated_minutes'))]
        );

        return ['message' => __('Estimated time has been updated', 'fluent-support-pro')];
    }

    public function byTickets(Request $request)
    {
        $sheet = $this->timesheet($request, 'mailbox_id', 'ticket_id', ['agent', 'ticket:id,title,slug']);

        return ['tickets' => $sheet['items'], 'mail_boxes' => MailBox::select(['id', 'name', 'box_type'])->orderBy('id')->get()] + array_diff_key($sheet, ['items' => 0]);
    }

    public function byAgents(Request $request)
    {
        $sheet = $this->timesheet($request, 'agent_id', 'agent_id', ['agent', 'ticket:id,title,slug']);

        return ['agents' => $sheet['items'], 'all_agents' => Agent::select(['id', 'first_name', 'last_name'])->orderBy('id')->get()] + array_diff_key($sheet, ['items' => 0]);
    }

    /**
     * The customer filter lists only customers with time entries.
     */
    public function byCustomers(Request $request)
    {
        $sheet = $this->timesheet($request, 'customer_id', 'customer_id', ['customer', 'ticket:id,title,slug']);
        $tracked = TimeTrack::query()->distinct()->pluck('customer_id')->filter()->all();

        return [
            'customers'     => $sheet['items'],
            'all_customers' => $tracked ? Customer::select(['id', 'first_name', 'last_name'])->whereIn('id', $tracked)->orderBy('first_name')->orderBy('last_name')->get() : [],
        ] + array_diff_key($sheet, ['items' => 0]);
    }

    /**
     * Time entries the viewer may count: their ticket exists and is in one of
     * the viewer's mailboxes. The CSV export uses it too.
     */
    public static function visibleTracks()
    {
        return TimeTrack::query()->whereHas('ticket', fn($query) => (new AgentTicketAccess())->applyMailboxRestrictionScope($query));
    }

    /**
     * [start, end] datetimes from a date_range of two dates: the last week by
     * default, and at most 31 days from the start.
     */
    public static function dateRange($range)
    {
        $range = array_values(array_filter((array) $range));
        if (count($range) !== 2 || !strtotime($range[0]) || !strtotime($range[1])) {
            $now = current_time('timestamp');
            return [date('Y-m-d H:i:s', strtotime('-1 week', $now)), date('Y-m-d 23:59:59', $now)];
        }

        $start = strtotime($range[0]);
        $end = min(strtotime($range[1]), strtotime('+31 days', $start));

        return [date('Y-m-d 00:00:00', $start), date('Y-m-d 23:59:59', $end)];
    }

    /**
     * Entries in the range, narrowed to the ids in $filter (an array), grouped
     * by day and by $groupKey: items (the agents, tickets or customers),
     * time_sheets, total_minutes, date_labels, date_range.
     */
    private function timesheet(Request $request, $filter, $groupKey, array $with)
    {
        $range = self::dateRange($request->get('date_range', []));
        $ids = array_filter(array_map('intval', (array) $request->get($filter, [])));

        $tracks = self::visibleTracks()
            ->when($ids, fn($query) => $query->whereIn($filter, $ids))
            ->whereBetween('completed_at', $range)
            ->with($with)
            ->orderBy('updated_at', 'DESC')
            ->get();

        $relation = $groupKey === 'ticket_id' ? 'ticket' : substr($groupKey, 0, -3);
        $items = [];
        $sheets = [];
        foreach ($tracks as $track) {
            $id = $track->{$groupKey};
            if ($id === null) {
                continue;
            }
            if (!isset($items[$id]) && $track->{$relation}) {
                $items[$id] = $relation === 'ticket' ? $track->ticket->toArray() : $this->person($track->{$relation});
            }
            $sheets[date('Y-m-d', strtotime($track->completed_at))][$id][] = $this->formatTrack($track);
        }

        $labels = [];
        for ($day = strtotime($range[0]); $day <= strtotime($range[1]); $day = strtotime('+1 day', $day)) {
            $labels[] = date('Y-m-d', $day);
        }

        return [
            'items'         => array_values($items),
            'time_sheets'   => $sheets,
            'total_minutes' => (int) $tracks->sum('billable_minutes'),
            'date_labels'   => $labels,
            'date_range'    => $range,
        ];
    }

    /**
     * The ticket, if the agent may open it.
     */
    private function ticket($ticketId)
    {
        $ticket = Ticket::find((int) $ticketId);
        if (!$ticket) {
            throw ApiException::notFound(__('Ticket not found', 'fluent-support-pro'));
        }
        if (!PermissionManager::canAccessTicket($ticket)) {
            throw ApiException::forbidden(__('Sorry, You do not have permission to this ticket', 'fluent-support-pro'));
        }

        return $ticket;
    }

    private function estimateOf($ticketId)
    {
        $value = Meta::where('object_type', 'ticket_time_tracking')->where('object_id', $ticketId)->value('value');

        return $value === null ? null : ProHelper::safeUnserialize($value);
    }

    public function formatTrack(TimeTrack $track)
    {
        return [
            'id'               => (int) $track->id,
            'ticket_id'        => (int) $track->ticket_id,
            'created_at'       => (string) $track->created_at,
            'updated_at'       => (string) $track->updated_at,
            'completed_at'     => $track->completed_at,
            'working_minutes'  => (int) $track->working_minutes,
            'billable_minutes' => (int) $track->billable_minutes,
            'message'          => $track->message,
            'is_manual'        => (bool) $track->is_manual,
            'ticket'           => $track->relationLoaded('ticket') && $track->ticket ? $track->ticket->toArray() : null,
            'agent'            => $track->relationLoaded('agent') ? $this->person($track->agent) : null,
            'customer'         => $track->relationLoaded('customer') ? $this->person($track->customer) : null,
        ];
    }

    /**
     * Display fields of an agent or customer.
     */
    private function person($person)
    {
        return $person ? [
            'id'         => (int) $person->id,
            'first_name' => $person->first_name,
            'last_name'  => $person->last_name,
            'full_name'  => $person->full_name,
            'photo'      => $person->photo,
            'user_id'    => (int) $person->user_id,
        ] : null;
    }
}
