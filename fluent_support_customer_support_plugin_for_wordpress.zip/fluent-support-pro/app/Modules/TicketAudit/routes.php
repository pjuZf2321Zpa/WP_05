<?php

defined('ABSPATH') || exit;

/**
 * @var \FluentSupport\Framework\Http\Router $router
 */

use FluentSupportPro\App\Modules\TicketAudit\AuditController;

$router->prefix('advanced-reports/audit')->withPolicy('FluentSupportPro\App\Modules\Reporting\AdvancedReportPolicy')->group(function ($router) {
    $router->post('/run', [AuditController::class, 'run']);
    $router->post('/process-batch', [AuditController::class, 'processBatch']);
    $router->get('/results', [AuditController::class, 'results']);
});
