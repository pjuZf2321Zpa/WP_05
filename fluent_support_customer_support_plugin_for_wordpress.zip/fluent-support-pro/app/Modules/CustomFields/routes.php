<?php

defined('ABSPATH') || exit;

/**
 * @var \FluentSupport\Framework\Http\Router $router
 */

use FluentSupportPro\App\Modules\CustomFields\CustomFieldController;

$router->prefix('ticket-custom-fields')->withPolicy('FluentSupport\App\Http\Policies\AdminSettingsPolicy')->group(function ($router) {
    $router->get('/', [CustomFieldController::class, 'index']);
    $router->post('/', [CustomFieldController::class, 'save']);
});

// The ticket sidebar: agents who can work the ticket.
$router->prefix('ticket-custom-fields')->withPolicy('FluentSupport\App\Http\Policies\AgentTicketPolicy')->group(function ($router) {
    $router->post('/{ticket_id}/sync', [CustomFieldController::class, 'syncTicket'])->int('ticket_id');
});
