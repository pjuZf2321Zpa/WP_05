<?php

namespace FluentSupportPro\App\Modules\CustomFields;

use FluentSupport\App\Exceptions\ApiException;
use FluentSupport\App\Http\Controllers\Controller;
use FluentSupport\App\Models\Meta;
use FluentSupport\App\Models\Ticket;
use FluentSupport\Framework\Http\Request\Request;

/**
 * The Custom Fields settings page and the ticket sidebar's custom data.
 */
class CustomFieldController extends Controller
{
    public function index()
    {
        return [
            'fields'      => CustomFields::all(),
            'field_types' => CustomFields::types()
        ];
    }

    /**
     * Replaces the field list (sent as JSON). Ticket values of removed fields are deleted.
     */
    public function save(Request $request)
    {
        $before = array_column(CustomFields::all(), 'slug');
        $fields = CustomFields::save((array) json_decode((string) $request->get('fields', '[]'), true));

        if ($removed = array_diff($before, array_column($fields, 'slug'))) {
            Meta::where('object_type', 'ticket_meta')->whereIn('key', array_values($removed))->delete();
        }

        return [
            'message' => __('Custom fields are successfully saved', 'fluent-support-pro'),
            'fields'  => $fields
        ];
    }

    /**
     * Saves the ticket's custom data; unknown fields are ignored.
     */
    public function syncTicket(Request $request, $ticket_id)
    {
        $ticket = Ticket::find((int) $ticket_id);
        if (!$ticket) {
            throw ApiException::notFound(__('Ticket not found', 'fluent-support-pro'));
        }
        $this->ensureCanAccessTicket($ticket);

        $ticket->syncCustomFields(map_deep((array) $request->get('custom_fields', []), 'sanitize_text_field'));

        return [
            'message'              => __('Custom Data has been updated', 'fluent-support-pro'),
            'custom_data'          => $ticket->customData('admin', false),
            'custom_data_rendered' => $ticket->customData('admin', true),
        ];
    }
}
