<?php

namespace FluentSupportPro\App\Modules\CustomFields;

use FluentSupport\App\Models\Product;
use FluentSupport\App\Services\Helper;
use FluentSupport\Framework\Support\Arr;

/**
 * Ticket custom fields: their definitions (option _ticket_custom_fields), and
 * what the free plugin and the workflows read through filters (register()).
 * Values live in ticket meta (Ticket::syncCustomFields() / customData()).
 *
 * A definition: slug (cf_...), type, label, admin_label (what agents see),
 * placeholder, options, required, admin_only (never shown to customers),
 * has_logics + match_type + conditions (required only when they match).
 */
class CustomFields
{
    const OPTION = '_ticket_custom_fields';

    /**
     * Field types whose options come from an integration (orders, courses,
     * memberships) and are rendered per customer.
     */
    const REMOTE_TYPES = [
        'woo_orders' => 'WooCommerce', 'woo_products' => 'WooCommerce',
        'edd_orders' => 'Edd', 'edd_products' => 'Edd',
        'fct_orders' => 'FluentCart', 'fct_products' => 'FluentCart',
        'learndash_courses' => 'LearnDash', 'learndash_user_courses' => 'LearnDash',
        'llms_courses' => 'LifterLMS', 'llms_user_courses' => 'LifterLMS',
        'pmpro_levels' => 'PMPro', 'pmpro_user_levels' => 'PMPro',
        'rcpro_levels' => 'RCPro', 'rcpro_user_levels' => 'RCPro',
        'tutorlms_courses' => 'TutorLMS', 'tutorlms_user_courses' => 'TutorLMS',
        'wlm_levels' => 'WishListMember', 'wlm_user_levels' => 'WishListMember',
        'bb_groups' => 'BuddyBoss', 'bb_user_groups' => 'BuddyBoss',
        'learnpress_courses' => 'LearnPress', 'learnpress_user_courses' => 'LearnPress',
        'fcom_courses' => 'FluentCommunity', 'fcom_user_courses' => 'FluentCommunity',
    ];

    const OPERATORS = ['=', '!=', 'gt', 'lt', 'contains', 'not_contains', 'in', 'not_in'];

    public static function register()
    {
        add_filter('fluent_support/ticket_custom_fields', fn() => self::labels('admin'));
        add_filter('fluent_support/custom_field_labels', fn($fields, $scope = 'public') => self::labels($scope), 10, 2);
        add_filter('fluent_support/custom_field_renders_type', fn($types) => array_values(array_unique(array_merge(array_keys(self::REMOTE_TYPES), (array) $types))), 5);
        add_filter('fluent_support/custom_fields_rendered', fn($fields, $customer = null, $scope = 'public') => self::rendered($customer, $scope), 10, 3);
        add_filter('fluent_support/custom_field_required_before_ticket_create', [self::class, 'requiredRules']);
        add_filter('fluent_support/custom_field_required_by_conditions_before_ticket_create', [self::class, 'dropUnmatchedRequired']);
        add_filter('fluent_support/workflow_conditions', [self::class, 'workflowConditions']);
        foreach (['ticket_created', 'response_added_by_customer', 'ticket_closed'] as $event) {
            add_filter('fluent_support/workflow_' . $event . '_supported_conditions', fn($keys) => array_merge((array) $keys, array_map(fn($slug) => 'custom_fields.' . $slug, array_column(self::all(), 'slug'))));
        }
    }

    public static function all()
    {
        return (array) Helper::getOption(self::OPTION, []);
    }

    /**
     * Saves definitions: known types and keys only, a label required, unique
     * cf_ slugs. Returns them.
     */
    public static function save(array $input)
    {
        $types = self::types();
        $fields = [];
        $slugs = [];

        foreach ($input as $field) {
            $label = sanitize_text_field((string) Arr::get($field, 'label', ''));
            $type = (string) Arr::get($field, 'type', '');
            if ($label === '' || !isset($types[$type])) {
                continue;
            }

            $slug = self::slug(Arr::get($field, 'slug'), $label, $slugs);
            $slugs[] = $slug;

            $fields[] = array_filter([
                'slug'        => $slug,
                'type'        => $type,
                'label'       => $label,
                'admin_label' => sanitize_text_field((string) Arr::get($field, 'admin_label', '')),
                'placeholder' => sanitize_text_field((string) Arr::get($field, 'placeholder', '')),
                'options'     => array_values(array_filter(array_map(fn($o) => sanitize_text_field((string) $o), (array) Arr::get($field, 'options', [])), 'strlen')),
                'field_key'   => sanitize_text_field((string) Arr::get($field, 'field_key', '')),
                'match_type'  => Arr::get($field, 'match_type') === 'all' ? 'all' : 'any',
                'conditions'  => self::conditions((array) Arr::get($field, 'conditions', [])),
            ], fn($value) => $value !== '' && $value !== []) + [
                'required'   => Arr::get($field, 'required') === 'yes' ? 'yes' : 'no',
                'admin_only' => Arr::get($field, 'admin_only') === 'yes' ? 'yes' : 'no',
                'has_logics' => Arr::get($field, 'has_logics') === 'yes' ? 'yes' : 'no',
            ];
        }

        Helper::updateOption(self::OPTION, $fields);

        return $fields;
    }

    public static function types()
    {
        $type = fn($type, $label, $valueType) => ['type' => $type, 'label' => $label, 'value_type' => $valueType, 'required' => 'no'];

        return apply_filters('fluent_support/custom_field_types', [
            'text'       => $type('text', __('Single Line Text', 'fluent-support-pro'), 'string'),
            'textarea'   => $type('textarea', __('Multi Line Text', 'fluent-support-pro'), 'string'),
            'number'     => $type('number', __('Numeric Field', 'fluent-support-pro'), 'numeric'),
            'select-one' => $type('select-one', __('Select Choice', 'fluent-support-pro'), 'string'),
            'radio'      => $type('radio', __('Radio Choice', 'fluent-support-pro'), 'string'),
            'checkbox'   => $type('checkbox', __('Checkboxes', 'fluent-support-pro'), 'array'),
            'date-range' => $type('date-range', __('Date Range', 'fluent-support-pro'), 'array'),
        ]);
    }

    /**
     * Definitions by slug. 'admin' uses the admin label; 'public' leaves out
     * admin-only fields.
     */
    public static function labels($scope = 'public')
    {
        $fields = [];
        foreach (self::all() as $field) {
            if ($scope === 'public' && Arr::get($field, 'admin_only') === 'yes') {
                continue;
            }
            if ($scope === 'admin' && !empty($field['admin_label'])) {
                $field['label'] = $field['admin_label'];
            }
            unset($field['admin_label']);
            $fields[$field['slug']] = $field;
        }

        return $fields;
    }

    /**
     * The fields to show a customer (the current one by default): remote
     * types only when their integration renders options for that customer.
     */
    public static function rendered($customer = null, $scope = 'public')
    {
        $customer = $customer ?: Helper::getCurrentCustomer();
        if (!$customer) {
            return [];
        }

        $types = self::types();
        $fields = [];
        foreach (self::labels($scope) as $slug => $field) {
            $type = $types[$field['type']] ?? null;
            if (!$type) {
                continue;
            }
            if (!empty($type['is_remote'])) {
                $field = apply_filters('fluent_support/render_custom_field_options_' . $type['type'], $field, $customer);
                if (!$field || empty($field['rendered'])) {
                    continue;
                }
            }
            $fields[$slug] = $field;
        }

        return $fields;
    }

    /**
     * Adds a required rule for each required field the current customer sees.
     */
    public static function requiredRules($rules)
    {
        foreach (self::rendered() as $slug => $field) {
            if (Arr::get($field, 'required') === 'yes') {
                $rules['required_fields']['custom_data.' . $slug] = 'required';
                /* translators: %s is the field label */
                $rules['error_messages']['custom_data.' . $slug . '.required'] = sprintf(__('%s is required', 'fluent-support-pro'), $field['label']);
            }
        }

        return $rules;
    }

    /**
     * A required field with conditions is only required, and kept, when its
     * conditions match the submitted data.
     */
    public static function dropUnmatchedRequired($data)
    {
        $values = array_merge((array) Arr::get($data, 'custom_data', []), (array) Arr::get($data, 'default_data', []));

        foreach (self::labels() as $slug => $field) {
            if (Arr::get($field, 'required') !== 'yes' || Arr::get($field, 'has_logics') !== 'yes' || self::conditionsMatch($field, $values)) {
                continue;
            }
            unset($data['required_fields']['custom_data.' . $slug], $data['error_messages']['custom_data.' . $slug . '.required'], $data['custom_data'][$slug]);
        }

        return $data;
    }

    /**
     * Custom fields as workflow conditions (custom_fields.{slug}).
     */
    public static function workflowConditions($conditions)
    {
        $dataTypes = ['select-one' => 'single_dropdown', 'radio' => 'single_dropdown', 'checkbox' => 'multiple_select', 'date-range' => 'date_range'];

        foreach (self::all() as $field) {
            $key = 'custom_fields.' . $field['slug'];
            if (isset(self::REMOTE_TYPES[$field['type']])) {
                $class = 'FluentSupportPro\App\Services\Integrations\\' . self::REMOTE_TYPES[$field['type']];
                $conditions[$key] = (new $class())->addToWorkflow($field, $field['type']);
                continue;
            }

            $conditions[$key] = ['title' => $field['label'], 'data_type' => $dataTypes[$field['type']] ?? 'string', 'group' => 'Custom Fields'];
            if (in_array($field['type'], ['select-one', 'radio', 'checkbox'], true)) {
                $options = (array) Arr::get($field, 'options', []);
                $conditions[$key]['options'] = $options ? array_combine($options, $options) : [];
            }
        }

        return $conditions;
    }

    /**
     * Any condition (match_type any) or all of them (all) match.
     */
    private static function conditionsMatch(array $field, array $values)
    {
        $results = [];
        foreach ((array) Arr::get($field, 'conditions', []) as $condition) {
            $item = Arr::get($condition, 'item_key');
            $expected = Arr::get($condition, 'value');
            $actual = Arr::get($values, $item);

            // A product condition stores the product's title.
            if ($item === 'ticket_product_id' && $actual && Product::where('id', $actual)->value('title') === $expected) {
                $expected = $actual;
            }

            $results[] = self::compare(Arr::get($condition, 'operator'), $actual, $expected);
        }

        if (!$results) {
            return true;
        }

        return Arr::get($field, 'match_type') === 'all' ? !in_array(false, $results, true) : in_array(true, $results, true);
    }

    private static function compare($operator, $actual, $expected)
    {
        switch ($operator) {
            case '=':
                return $actual == $expected;
            case '!=':
                return $actual != $expected;
            case 'gt':
                return $actual > $expected;
            case 'lt':
                return $actual < $expected;
            case 'contains':
                return strpos((string) $actual, (string) $expected) !== false;
            case 'not_contains':
                return strpos((string) $actual, (string) $expected) === false;
            case 'in':
                return in_array($actual, explode(',', (string) $expected));
            case 'not_in':
                return !in_array($actual, explode(',', (string) $expected));
        }

        return false;
    }

    private static function conditions(array $conditions)
    {
        $clean = [];
        foreach ($conditions as $condition) {
            $operator = Arr::get($condition, 'operator');
            if (!in_array($operator, self::OPERATORS, true) || !Arr::get($condition, 'item_key')) {
                continue;
            }
            $clean[] = [
                'item_key' => sanitize_text_field((string) $condition['item_key']),
                'operator' => $operator,
                'value'    => sanitize_text_field((string) Arr::get($condition, 'value', '')),
            ];
        }

        return $clean;
    }

    /**
     * cf_ + the given slug or the label, at most 20 characters, made unique
     * among $taken with a number. A slug that already starts with cf_ keeps its
     * length: ticket values are stored under it.
     */
    private static function slug($given, $label, array $taken)
    {
        $given = (string) $given;
        if (is_numeric($given)) {
            $given = 'cf_' . $given;
        }
        $kept = strpos($given, 'cf_') === 0;
        $base = $given !== '' ? ($kept ? $given : 'cf_' . $given) : 'cf_' . str_replace(' ', '_', $label);
        $base = sanitize_title($base, 'cf_custom_field', 'view');
        if (!$kept) {
            $base = substr($base, 0, 20);
        }

        $slug = $base;
        for ($i = 2; in_array($slug, $taken, true); $i++) {
            $slug = ($kept ? $base : substr($base, 0, 20 - strlen((string) $i) - 1)) . '_' . $i;
        }

        return $slug;
    }
}
