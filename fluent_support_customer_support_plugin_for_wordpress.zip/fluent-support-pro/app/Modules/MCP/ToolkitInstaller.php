<?php

namespace FluentSupportPro\App\Modules\MCP;

/**
 * Auto-installs FluentHub, which bundles the WP MCP Adapter the MCP server needs.
 *
 * Implements the shared `fluent_toolkit/*` hooks fired by the free plugin's
 * "Install FluentHub" button. They are not per product, so any active Fluent
 * Pro plugin can handle the install.
 */
class ToolkitInstaller
{
    const TOOLKIT_PLUGIN_FILE = 'fluent-toolkit/fluent-toolkit.php';
    const TOOLKIT_DOWNLOAD_URL = 'https://static.wpmanageninja.com/fluent-toolkit.zip';

    public function init()
    {
        add_filter('fluent_toolkit/can_auto_install', [$this, 'canAutoInstall']);
        add_action('fluent_toolkit/do_auto_install', [$this, 'autoInstall']);
    }

    /**
     * Enables the one-click install button when the user may install plugins.
     */
    public function canAutoInstall($canAutoInstall)
    {
        return $this->userCanInstall() ? true : $canAutoInstall;
    }

    /**
     * Install and activate FluentHub, then boot its MCP adapter so the endpoint
     * works in the same request.
     */
    public function autoInstall()
    {
        if (!$this->userCanInstall()) {
            return;
        }

        // The action may fire more than once.
        if (did_action('fluent_toolkit/toolkit_installing')) {
            return;
        }

        do_action('fluent_toolkit/toolkit_installing');

        // Already installed: activate and boot only.
        if ($this->activateToolkit() && $this->isToolkitAdapterAvailable()) {
            return;
        }

        $installed = $this->installFromZipUrl(self::TOOLKIT_DOWNLOAD_URL);
        if (is_wp_error($installed)) {
            /**
             * Fires when the automatic FluentHub install fails, so the caller can
             * tell the admin why instead of reporting success.
             *
             * @param \WP_Error $installed
             */
            do_action('fluent_toolkit/auto_install_failed', $installed);
            return;
        }

        if (!$this->activateToolkit()) {
            do_action('fluent_toolkit/auto_install_failed', new \WP_Error(
                'toolkit_activation_failed',
                __('FluentHub was installed but could not be activated. Activate it on the Plugins page.', 'fluent-support-pro')
            ));
        }
    }

    /**
     * Needs both install_plugins and activate_plugins, and respects DISALLOW_FILE_MODS.
     */
    private function userCanInstall()
    {
        if (defined('DISALLOW_FILE_MODS') && DISALLOW_FILE_MODS) {
            return false;
        }

        return current_user_can('install_plugins') && current_user_can('activate_plugins');
    }

    private function activateToolkit()
    {
        if (!function_exists('is_plugin_active')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        if (!file_exists(WP_PLUGIN_DIR . '/' . self::TOOLKIT_PLUGIN_FILE)) {
            return false;
        }

        if (is_plugin_active(self::TOOLKIT_PLUGIN_FILE)) {
            $this->bootToolkitAdapter();
            return true;
        }

        $result = activate_plugin(self::TOOLKIT_PLUGIN_FILE);

        if (is_wp_error($result)) {
            return false;
        }

        $this->bootToolkitAdapter();

        return true;
    }

    private function bootToolkitAdapter()
    {
        if (class_exists('\FluentToolkit\Mcp\AdapterBootstrap')) {
            \FluentToolkit\Mcp\AdapterBootstrap::boot();
        }
    }

    private function isToolkitAdapterAvailable()
    {
        if (!class_exists('\FluentToolkit\Mcp\AdapterBootstrap')) {
            return false;
        }

        if (method_exists('\FluentToolkit\Mcp\AdapterBootstrap', 'available')) {
            return (bool) \FluentToolkit\Mcp\AdapterBootstrap::available();
        }

        return class_exists('\WP\MCP\Core\McpAdapter') && function_exists('wp_register_ability');
    }

    /**
     * Download a plugin zip from a direct URL and install it via WP_Upgrader.
     *
     * @param  string $zipUrl
     * @return true|\WP_Error
     */
    private function installFromZipUrl($zipUrl)
    {
        $zipUrl = esc_url_raw((string) $zipUrl);

        if (!$zipUrl || !filter_var($zipUrl, FILTER_VALIDATE_URL)) {
            return new \WP_Error('invalid_plugin_zip_url', __('Invalid plugin zip URL.', 'fluent-support-pro'));
        }

        // Installing over an existing folder could leave stale files, so let the admin remove it.
        $destDir = WP_PLUGIN_DIR . '/' . dirname(self::TOOLKIT_PLUGIN_FILE);
        if (is_dir($destDir)) {
            return new \WP_Error(
                'toolkit_dir_exists',
                sprintf(
                    /* translators: 1: plugin directory path */
                    __('A %1$s folder already exists but is not a valid FluentHub install. Remove it and try again.', 'fluent-support-pro'),
                    'wp-content/plugins/' . dirname(self::TOOLKIT_PLUGIN_FILE)
                )
            );
        }

        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        require_once ABSPATH . 'wp-admin/includes/plugin.php';

        \WP_Filesystem();

        $skin     = new \Automatic_Upgrader_Skin();
        $upgrader = new \WP_Upgrader($skin);

        ob_start();

        try {
            $download = $upgrader->download_package($zipUrl);
            if (is_wp_error($download)) {
                throw new \Exception($download->get_error_message());
            }

            $workingDir = $upgrader->unpack_package($download, true);
            if (is_wp_error($workingDir)) {
                throw new \Exception($workingDir->get_error_message());
            }

            $result = $upgrader->install_package([
                'source'                      => $workingDir,
                'destination'                 => WP_PLUGIN_DIR,
                'clear_destination'           => false,
                'abort_if_destination_exists' => false,
                'clear_working'               => true,
                'hook_extra'                  => [
                    'type'   => 'plugin',
                    'action' => 'install',
                ],
            ]);

            if (!$result || is_wp_error($result)) {
                $message = is_wp_error($result) ? $result->get_error_message() : __('Plugin package installation failed.', 'fluent-support-pro');
                throw new \Exception($message);
            }
        } catch (\Exception $e) {
            ob_end_clean();
            wp_clean_plugins_cache();
            return new \WP_Error('plugin_install_failed', $e->getMessage());
        }

        ob_end_clean();
        wp_clean_plugins_cache();

        return true;
    }
}
