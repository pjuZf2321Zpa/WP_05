<?php

namespace FluentSupportPro\App\Modules\MCP;

/**
 * Wires the FluentHub auto-installer and adds Pro tools to the free
 * `fluent-support` MCP server:
 *   - `fluent_support/mcp_loaded`        → register the abilities
 *   - `fluent_support/mcp_ability_names` → expose them on the server
 */
class MCPInit
{
    public function init()
    {
        (new ToolkitInstaller())->init();

        $this->registerProAbilities();
    }

    /**
     * Hooks are always added so the class_exists() checks run when the hooks
     * fire and all plugins are loaded, not at this early boot point.
     */
    private function registerProAbilities()
    {
        add_action('fluent_support/mcp_loaded', function () {
            AbilitiesRegistrar::register();
        });

        add_filter('fluent_support/mcp_ability_names', function ($names) {
            return array_merge((array) $names, array_keys(AbilitiesRegistrar::getDefinitions()));
        });
    }
}
