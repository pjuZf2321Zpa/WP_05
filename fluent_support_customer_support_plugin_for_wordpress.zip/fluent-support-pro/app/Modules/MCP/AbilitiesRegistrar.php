<?php

namespace FluentSupportPro\App\Modules\MCP;

use FluentSupport\App\Modules\MCP\Helpers\MCPHelper;
use FluentSupport\App\Modules\PermissionManager;

/**
 * Registers Pro MCP abilities on the free plugin's `fluent-support` server,
 * following the free AbilitiesRegistrar's category, meta and error wrapping.
 *
 * Each tool class returns definitions() keyed by ability name, each with:
 *   - label            translatable; people see it in the admin and in clients
 *   - description      plain English, not translatable: the model reads it
 *   - execute_callback
 *   - permissions      ['any_of' => caps, 'all_of' => caps], checked the same way
 *                      as the free tools (AbilityGuard::checkCaps)
 *   - annotations      readonly, destructive, idempotent, openWorldHint
 *   - input_schema     optional
 */
class AbilitiesRegistrar
{
    /**
     * MCP's cautious defaults for a hint a tool leaves out: a write that may
     * destroy data and reach outside the site.
     */
    const DEFAULT_ANNOTATIONS = [
        'readonly'      => false,
        'destructive'   => true,
        'idempotent'    => false,
        'openWorldHint' => true,
    ];

    /** Tool classes that expose a static definitions() method. */
    private static function toolClasses()
    {
        $classes = [
            // Pro tool classes are added here as they are built.
        ];

        /**
         * Filter the classes whose definitions() become Pro MCP tools.
         *
         * @since 2.4.1
         *
         * @param string[] $classes
         */
        return (array) apply_filters('fluent_support_pro/mcp_tool_classes', $classes);
    }

    public static function getDefinitions()
    {
        $defs = [];

        foreach (self::toolClasses() as $class) {
            if (class_exists($class) && method_exists($class, 'definitions')) {
                $defs = array_merge($defs, (array) $class::definitions());
            }
        }

        return $defs;
    }

    public static function register()
    {
        if (!function_exists('wp_register_ability')) {
            return;
        }

        foreach (self::getDefinitions() as $name => $definition) {
            wp_register_ability($name, self::abilityArgs($name, $definition));
        }
    }

    /**
     * The wp_register_ability() arguments for one tool definition.
     *
     * @param string $name
     * @param array  $definition
     * @return array
     */
    public static function abilityArgs($name, array $definition)
    {
        $args = [
            'label'               => $definition['label'],
            'description'         => $definition['description'],
            'category'            => 'fluent-support',
            'execute_callback'    => self::wrapExecuteCallback($name, $definition),
            // Capabilities are checked in the execute wrapper so a denial comes
            // back as a structured error, not the adapter's "Permission denied".
            'permission_callback' => 'is_user_logged_in',
            'meta'                => [
                'show_in_rest' => true,
                'mcp'          => ['public' => true],
                'annotations'  => array_merge(self::DEFAULT_ANNOTATIONS, (array) ($definition['annotations'] ?? [])),
            ],
        ];

        if (!empty($definition['input_schema'])) {
            $args['input_schema'] = $definition['input_schema'];
        }

        return $args;
    }

    /**
     * Whether the current user may run the tool. Uses the free plugin's check when
     * it has one, so both plugins read caps the same way.
     */
    private static function allowed(array $definition)
    {
        $caps = (array) ($definition['permissions'] ?? []);

        if (!$caps) {
            // Deny a tool that declares no permissions rather than open it to every user.
            return false;
        }

        if (method_exists('\FluentSupport\App\Modules\MCP\Support\AbilityGuard', 'checkCaps')) {
            return \FluentSupport\App\Modules\MCP\Support\AbilityGuard::checkCaps($caps);
        }

        if (!empty($caps['any_of']) && !PermissionManager::userCan($caps['any_of'])) {
            return false;
        }

        foreach ((array) ($caps['all_of'] ?? []) as $cap) {
            if (!PermissionManager::currentUserCan($cap)) {
                return false;
            }
        }

        return !empty($caps['any_of']) || !empty($caps['all_of']);
    }

    /**
     * Check permissions, then run the tool. An unhandled \Throwable becomes the same
     * generic error the free tools return; its details go to the exception hook only,
     * never to the client.
     */
    private static function wrapExecuteCallback($toolName, array $definition)
    {
        $callback = $definition['execute_callback'];

        return function ($params) use ($toolName, $definition, $callback) {
            if (!self::allowed($definition)) {
                return MCPHelper::error(
                    'forbidden',
                    __('You do not have permission to perform this action.', 'fluent-support-pro'),
                    ['retryable' => false]
                );
            }

            try {
                return call_user_func($callback, $params);
            } catch (\Throwable $e) {
                do_action('fluent_support/mcp_tool_exception', [
                    'exception' => $e,
                    'tool'      => $toolName,
                    'params'    => $params,
                ]);

                return MCPHelper::error(
                    'internal_error',
                    __('An unexpected error occurred. Please try again or contact support.', 'fluent-support-pro'),
                    ['retryable' => true]
                );
            }
        };
    }
}
