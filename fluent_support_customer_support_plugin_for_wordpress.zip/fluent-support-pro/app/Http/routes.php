<?php

/**
 * @var $app FluentSupport\Framework\Foundation\Application
 * @var $router FluentSupport\Framework\Http\Router
 */

$router->prefix('ticket-tags')->withPolicy('FluentSupport\App\Http\Policies\AdminSettingsPolicy')->group(function ($router) {
    $router->get('/', 'FluentSupportPro\App\Http\Controllers\TicketTagsController@index');
    $router->post('/', 'FluentSupportPro\App\Http\Controllers\TicketTagsController@create');
    $router->get('/options', 'FluentSupportPro\App\Http\Controllers\TicketTagsController@getOptions');
    $router->get('/{tag_id}', 'FluentSupportPro\App\Http\Controllers\TicketTagsController@get')->int('tag_id');
    $router->put('/{tag_id}', 'FluentSupportPro\App\Http\Controllers\TicketTagsController@update')->int('tag_id');
    $router->delete('/{tag_id}', 'FluentSupportPro\App\Http\Controllers\TicketTagsController@delete')->int('tag_id');
});

require FLUENTSUPPORTPRO_PLUGIN_PATH . 'app/Modules/Workflows/routes.php';

$router->prefix('email-box')->withPolicy('FluentSupport\App\Http\Policies\AdminSettingsPolicy')->group(function ($router) {
    $router->get('/{box_id}/status', 'FluentSupportPro\App\Http\Controllers\EmailBoxController@getPipeStatus')->int('box_id');
    $router->post('/{box_id}/issue-email', 'FluentSupportPro\App\Http\Controllers\EmailBoxController@issueMappedEmail')->int('box_id');
});

$router->prefix('mail-piping')->withPolicy('FluentSupport\App\Http\Policies\PublicPolicy')->group(function ($router) {
    $router->any('/{box_id}/push/{token}', 'FluentSupportPro\App\Http\Controllers\EmailBoxController@pipePayload')->int('box_id')->alphaNumDash('token');
});

$router->get('customer-portal/search-doc', 'FluentSupportPro\App\Http\Controllers\DocSuggestionController@index')->withPolicy('FluentSupport\App\Http\Policies\PublicPolicy');

/*
 * Pro EndPoints
 */
$router->prefix('pro')->withPolicy('FluentSupport\App\Http\Policies\AdminSettingsPolicy')->group(function ($router) {

    $router->get('license', 'FluentSupportPro\App\Http\Controllers\LicenseController@getStatus');
    $router->post('license', 'FluentSupportPro\App\Http\Controllers\LicenseController@saveLicense');
    $router->post('remove-license', 'FluentSupportPro\App\Http\Controllers\LicenseController@deactivateLicense');

    $router->get('form-settings', 'FluentSupportPro\App\Http\Controllers\TicketFormController@getSettings');
    $router->post('form-settings', 'FluentSupportPro\App\Http\Controllers\TicketFormController@saveSettings');
});

$router->prefix('settings')->withPolicy('FluentSupport\App\Http\Policies\AdminSettingsPolicy')->group(function ($router) {
    $router->get('/incoming-webhook', 'FluentSupportPro\App\Http\Controllers\IncomingWebhookController@index');
    $router->put('/incoming-webhook', 'FluentSupportPro\App\Http\Controllers\IncomingWebhookController@updateWebhook');


    $router->get('/upload_integration', 'FluentSupportPro\App\Http\Controllers\UploadIntegrationController@getSettings');
    $router->post('/upload_integration', 'FluentSupportPro\App\Http\Controllers\UploadIntegrationController@saveSettings');

    $router->get('/remote-portal', 'FluentSupportPro\App\Http\Controllers\RemotePortalSettingsController@get');
    $router->post('/remote-portal', 'FluentSupportPro\App\Http\Controllers\RemotePortalSettingsController@save');
    $router->post('/remote-portal/connection-key', 'FluentSupportPro\App\Http\Controllers\RemotePortalSettingsController@createConnectionKey');
    $router->post('/remote-portal/disconnect', 'FluentSupportPro\App\Http\Controllers\RemotePortalSettingsController@disconnect');
    $router->post('/remote-portal/test', 'FluentSupportPro\App\Http\Controllers\RemotePortalSettingsController@test');
});

// Called by the Fluent Support Connector on the main site, with the Application Password an
// administrator gave it. The first call (connect) also carries the key from settings/remote-portal/connection-key.
// RemotePortalPolicy refuses every call while Remote Portal is off.
$router->prefix('remote-portal')->withPolicy('FluentSupportPro\App\Http\Policies\RemotePortalPolicy')->group(function ($router) {
    $router->post('connect', 'FluentSupportPro\App\Http\Controllers\RemotePortalController@connect');
    $router->post('rotate-token', 'FluentSupportPro\App\Http\Controllers\RemotePortalController@rotateToken');
    $router->get('ping', 'FluentSupportPro\App\Http\Controllers\RemotePortalController@ping');
    $router->get('portal-config', 'FluentSupportPro\App\Http\Controllers\RemotePortalController@getPortalConfig');
    $router->post('portal-url', 'FluentSupportPro\App\Http\Controllers\RemotePortalController@updatePortalUrl');
    $router->post('test-widgets', 'FluentSupportPro\App\Http\Controllers\RemotePortalController@testWidgets');
    $router->post('disconnect', 'FluentSupportPro\App\Http\Controllers\RemotePortalController@disconnect');
});

$router->prefix('public')->withPolicy('FluentSupport\App\Http\Policies\PublicPolicy')->group(function($router) {

    $router->post('incoming_webhook/{token}', 'FluentSupportPro\App\Hooks\Handlers\IncomingWebhookHandler@handleIncomingWebhook')->alphaNumDash('token');
    $router->get('/dropbox_auth', 'FluentSupportPro\App\Http\Controllers\AuthorizeController@handleAuthorizeDropbox');
    $router->get('/google_auth', 'FluentSupportPro\App\Http\Controllers\AuthorizeController@handleAuthorizeGoogleDrive');

});


$router->prefix('tickets')->withPolicy('FluentSupport\App\Http\Policies\AgentTicketPolicy')->group(function ($router) {
    $router->post('/{ticket_id}/sync-watchers', 'FluentSupportPro\App\Http\Controllers\TicketController@syncTicketWatchers')->int('ticket_id');
    $router->post('/{ticket_id}/add_watchers', 'FluentSupportPro\App\Http\Controllers\TicketController@addTicketWatchers')->int('ticket_id');
    $router->post('/{ticket_id}/merge_tickets', 'FluentSupportPro\App\Http\Controllers\TicketController@mergeCustomerTickets')->int('ticket_id');
    $router->get('customer_tickets/{customer_id}', 'FluentSupportPro\App\Http\Controllers\TicketController@getCustomerTickets')->int('customer_id');
    $router->post('/{ticket_id}/split_ticket', 'FluentSupportPro\App\Http\Controllers\TicketController@splitToNewTicket')->int('ticket_id');
});

// Creating a scheduled reply goes through the free plugin's reply endpoint with `scheduled_at`
$router->prefix('tickets')->withPolicy('FluentSupportPro\App\Http\Policies\ScheduledReplyPolicy')->group(function ($router) {
    $router->put('/{ticket_id}/scheduled_reply/{response_id}', 'FluentSupportPro\App\Http\Controllers\ScheduledReplyController@update')
        ->int('ticket_id')
        ->int('response_id');
    $router->post('/{ticket_id}/scheduled_reply/{response_id}/send_now', 'FluentSupportPro\App\Http\Controllers\ScheduledReplyController@sendNow')
        ->int('ticket_id')
        ->int('response_id');
    $router->post('/{ticket_id}/scheduled_reply/{response_id}/resume', 'FluentSupportPro\App\Http\Controllers\ScheduledReplyController@resume')
        ->int('ticket_id')
        ->int('response_id');
    $router->delete('/{ticket_id}/scheduled_reply/{response_id}', 'FluentSupportPro\App\Http\Controllers\ScheduledReplyController@cancel')
        ->int('ticket_id')
        ->int('response_id');
});

$router->prefix('ai')->withPolicy('FluentSupport\App\Http\Policies\AgentTicketPolicy')->group(function ($router) {
    $router->get('/preset-prompts', 'FluentSupportPro\App\Http\Controllers\AIController@getPresetPrompts');
    $router->post('/{id}/generate-response', 'FluentSupportPro\App\Http\Controllers\AIController@generateResponse')->int('id');
    $router->post('/{id}/get-ticket-summary', 'FluentSupportPro\App\Http\Controllers\AIController@getTicketSummary')->int('id');
    $router->post('/{id}/get-ticket-tone', 'FluentSupportPro\App\Http\Controllers\AIController@getTicketTone')->int('id');
});

require FLUENTSUPPORTPRO_PLUGIN_PATH . 'app/Modules/Reporting/routes.php';
require FLUENTSUPPORTPRO_PLUGIN_PATH . 'app/Modules/SavedReplies/routes.php';
require FLUENTSUPPORTPRO_PLUGIN_PATH . 'app/Modules/TimeTracking/routes.php';
require FLUENTSUPPORTPRO_PLUGIN_PATH . 'app/Modules/AutoClose/routes.php';
require FLUENTSUPPORTPRO_PLUGIN_PATH . 'app/Modules/CustomFields/routes.php';
require FLUENTSUPPORTPRO_PLUGIN_PATH . 'app/Modules/Chat/routes.php';
require FLUENTSUPPORTPRO_PLUGIN_PATH . 'app/Modules/TicketAudit/routes.php';
