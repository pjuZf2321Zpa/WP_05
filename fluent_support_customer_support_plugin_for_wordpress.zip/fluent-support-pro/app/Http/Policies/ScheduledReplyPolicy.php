<?php

namespace FluentSupportPro\App\Http\Policies;

use FluentSupport\App\Modules\PermissionManager;
use FluentSupport\Framework\Foundation\Policy;
use FluentSupport\Framework\Http\Request\Request;
use FluentSupportPro\App\Modules\ScheduledReplies\ScheduledRepliesModule;

/**
 * Every scheduled reply route changes a ticket. Author and per-ticket access are checked in the controller.
 */
class ScheduledReplyPolicy extends Policy
{
    /**
     * @param \FluentSupport\Framework\Http\Request\Request $request
     * @return Boolean
     */
    public function verifyRequest(Request $request)
    {
        $status = ScheduledRepliesModule::isAvailable() && PermissionManager::canManageTickets();

        // Same access filter AgentTicketPolicy applies to every other ticket write route
        return apply_filters('fluent_support/agent_has_access', $status, $request);
    }

    public function update(Request $request)
    {
        return $this->verifyRequest($request);
    }

    public function sendNow(Request $request)
    {
        return $this->verifyRequest($request);
    }

    public function resume(Request $request)
    {
        return $this->verifyRequest($request);
    }

    public function cancel(Request $request)
    {
        return $this->verifyRequest($request);
    }
}
