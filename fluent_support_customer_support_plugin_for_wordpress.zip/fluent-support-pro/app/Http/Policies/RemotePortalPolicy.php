<?php

namespace FluentSupportPro\App\Http\Policies;

use FluentSupport\App\Http\Policies\PortalPolicy;
use FluentSupport\Framework\Foundation\Policy;
use FluentSupport\Framework\Http\Request\Request;
use FluentSupportPro\App\Modules\RemotePortal\RemotePortalModule;
use FluentSupportPro\App\Modules\RemotePortal\RemotePortalSettings;

/**
 * Routes the Fluent Support Connector calls with the Application Password an
 * administrator connected it with (connect: with the key an administrator generated).
 */
class RemotePortalPolicy extends Policy
{
    /**
     * Only the user the administrator connected, so another agent's Application
     * Password cannot read the connection or rewrite where customers are sent.
     *
     * @param Request $request
     * @return bool
     */
    public function verifyRequest(Request $request)
    {
        if (!RemotePortalModule::canServeRemote() || !PortalPolicy::canActOnBehalf()) {
            return false;
        }

        $settings = RemotePortalSettings::get();

        if (RemotePortalSettings::isConstantMode()) {
            // wp-config connection: no connect call named a user.
            $allowed = true;
        } else {
            $allowed = !empty($settings['user_id']) && (int)$settings['user_id'] === get_current_user_id();
        }

        if ($allowed) {
            RemotePortalSettings::touch('last_inbound_at');
        }

        return $allowed;
    }

    /**
     * The first call: no user is connected yet. The controller checks the
     * one-time key and that this user may act for customers.
     *
     * @param Request $request
     * @return bool
     */
    public function connect(Request $request)
    {
        return RemotePortalModule::canServeRemote() && is_user_logged_in();
    }

    /**
     * In wp-config mode no connect call named a user, so any user who may act on
     * behalf of customers passes verifyRequest(). Changes are refused there:
     * the constants own the connection.
     *
     * @param Request $request
     * @return bool
     */
    public function updatePortalUrl(Request $request)
    {
        return !RemotePortalSettings::isConstantMode() && $this->verifyRequest($request);
    }

    /**
     * @param Request $request
     * @return bool
     */
    public function disconnect(Request $request)
    {
        return !RemotePortalSettings::isConstantMode() && $this->verifyRequest($request);
    }

    /**
     * Only the connected user, and not when wp-config.php sets the connection or the token.
     *
     * @param Request $request
     * @return bool
     */
    public function rotateToken(Request $request)
    {
        return !RemotePortalSettings::isConstantMode() && !RemotePortalSettings::constantToken() && $this->verifyRequest($request);
    }
}
