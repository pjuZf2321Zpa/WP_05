<?php

namespace FluentSupportPro\App\Http\Controllers;

use FluentSupport\App\Http\Controllers\Controller;
use FluentSupport\App\Services\Helper;
use FluentSupport\Framework\Request\Request;
use FluentSupportPro\App\Services\ProHelper;

class TicketFormController extends Controller
{

    /**
     * @param Request $request
     * @return array
     */
    public function getSettings(Request $request)
    {
        $settings = ProHelper::getTicketFormConfig();
        $settingsFields = $this->getSettingsFields();

        if (!empty($settings['docs_post_categories'])) {
            $validCategoryIds = wp_list_pluck($settingsFields['docs_post_categories']['options'], 'id');
            $settings['docs_post_categories'] = array_values(
                array_intersect($settings['docs_post_categories'], $validCategoryIds)
            );
        }

        return [
            'settings'        => $settings,
            'settings_fields' => $settingsFields
        ];

    }


    /**
     * @param Request $request
     * @return array
     */
    public function saveSettings(Request $request)
    {
        $settings = $request->get('settings', []);

        foreach ($settings['field_labels'] as $fieldKey => $value) {
            $settings['field_labels'][$fieldKey] = sanitize_text_field($value);
        }

        if (!empty($settings['docs_post_categories']) && in_array('post', (array) ($settings['docs_post_types'] ?? []))) {
            $settings['docs_post_categories'] = array_map('intval', $settings['docs_post_categories']);
        } else {
            $settings['docs_post_categories'] = [];
        }

        Helper::updateOption('_ticket_form_settings', $settings);

        return [
            'message' => __('Settings have been updated', 'fluent-support-pro')
        ];

    }


    /**
     * Field definitions for the ticket form settings screen.
     * @return array
     */
    public function getSettingsFields()
    {
        $postTypes = apply_filters('fluent_support/all_doc_post_types', get_post_types([
            'public'             => true,
            'publicly_queryable' => true
        ]));

        $postCategories = apply_filters('fluent_support/doc_post_categories', $this->getHierarchicalCategoryOptions());


        if (!function_exists('get_editable_roles')) {
            require_once(ABSPATH . '/wp-admin/includes/user.php');
        }

        $roles = \get_editable_roles();

        $formattedRoles = [];

        foreach ($roles as $roleKey => $role) {
            $formattedRoles[$roleKey] = $role['name'];
        }

        unset($formattedRoles['administrator']);

       asort($formattedRoles);

        $fields = [];

        $fields += [
            'enable_docs'       => [
                'label'         => __('Knowledge Base Suggestion', 'fluent-support-pro'),
                'type'          => 'inline-checkbox',
                'checkbox_label'=> __('Enable knowledge base suggestion on ticket creation form', 'fluent-support-pro'),
                'true_label'    => 'yes',
                'false_label'   => 'no'
            ],
            'docs_post_types'   => [
                'type'          => 'checkbox-group',
                'label'         => __('Knowledge Base Post Types', 'fluent-support-pro'),
                'options'       => $postTypes,
                'inline_help'   => __('Select the post types that you want to show articles from', 'fluent-support-pro'),
                'wrapper_class' => '',
                'dependency'    => [
                    'depends_on' => 'enable_docs',
                    'operator'   => '=',
                    'value'      => 'yes'
                ]
            ],
            'docs_post_categories' => [
                'type'          => 'multi-select',
                'label'         => __('Filter by Category', 'fluent-support-pro'),
                'options'       => $postCategories,
                'placeholder'   => __('All Categories', 'fluent-support-pro'),
                'data_type'     => 'number',
                'inline_help'   => __('Only suggest "post" type articles from the selected categories (subcategories are included automatically). Leave empty to include all categories. When other post types are also selected above, matching "post" results are shown first and other post types only fill the remaining slots.', 'fluent-support-pro'),
                'wrapper_class' => '',
                'dependency'    => [
                    'depends_on' => 'docs_post_types',
                    'operator'   => 'contains',
                    'value'      => 'post'
                ]
            ],
            'post_limits'       => [
                'type'          => 'input-text',
                'data_type'     => 'number',
                'label'         => __('Suggested Articles Limit', 'fluent-support-pro'),
                'wrapper_class' => '',
                'dependency'    => [
                    'depends_on' => 'enable_docs',
                    'operator'   => '=',
                    'value'      => 'yes'
                ]
            ],
            'disabled_fields'   => [
                'type'          => 'checkbox-group',
                'label'         => __('Disabled Default Fields', 'fluent-support-pro'),
                'wrapper_class' => '',
                'options'       => [
                    'file_upload'      => __('File Upload', 'fluent-support-pro'),
                    'priority'         => __('Priority', 'fluent-support-pro'),
                    'product_services' => __('Product & Services', 'fluent-support-pro')
                ],
                'inline_help'   => __('Checked fields will not be available on the ticket creation form', 'fluent-support-pro'),
            ],
            'product_required_field' => [
                'label'          => __('Product & Service Field Requirement', 'fluent-support-pro'),
                'type'           => 'inline-checkbox',
                'checkbox_label' => __('Mark product and service fields as required.', 'fluent-support-pro'),
                'true_label'     => 'yes',
                'wrapper_class'  => '',
                'false_label'    => 'no',
                'dependency'     => [
                    'depends_on' => 'disabled_fields',
                    'operator'   => 'not_contains',
                    'value'      => 'product_services'
                ]
            ],
            'disable_rich_text' => [
                'label'          => __('Rich Text Editor Option', 'fluent-support-pro'),
                'type'           => 'inline-checkbox',
                'checkbox_label' => __('Disable Rich Text Editor for Frontend', 'fluent-support-pro'),
                'true_label'     => 'yes',
                'wrapper_class'  => '',
                'false_label'    => 'no'
            ],
            'submitter_type' => [
                'type'  => 'input-radio',
                'label' => __('Who can access the customer portal?', 'fluent-support-pro'),
                'options' => [
                    [
                        'id'    => 'logged_in_users',
                        'label' => __('Any logged-in users', 'fluent-support-pro')
                    ],
                    [
                        'id'    => 'allowed_user_roles',
                        'label' => __('Only selected user roles', 'fluent-support-pro')
                    ]
                ]
            ],
            'allowed_user_roles' => [
                'type'          => 'checkbox-group',
                'label'         => __('Select User Roles for Customer Portal', 'fluent-support-pro'),
                'options'       => $formattedRoles,
                'dependency'    => [
                    'depends_on' => 'submitter_type',
                    'operator'   => '=',
                    'value'      => 'allowed_user_roles'
                ]
            ]
        ];

        $fields['field_labels'] = [
            'label'        => __('Form Labels Customization', 'fluent-support-pro'),
            'source_label' => __('Field', 'fluent-support-pro'),
            'new_label'    => __('Input Label', 'fluent-support-pro'),
            'type'         => 'object-tabular-input',
            'options'      => [
                'subject'           => __('Subject heading', 'fluent-support-pro'),
                'ticket_details'    => __('Form content heading', 'fluent-support-pro'),
                'details_help'      => __('Content help message', 'fluent-support-pro'),
                'product_services'  => __('Product/Service heading', 'fluent-support-pro'),
                'priority'          => __('Priority heading', 'fluent-support-pro'),
                'btn_text'          => __('Create ticket button text', 'fluent-support-pro'),
                'submit_heading'    => __('Create ticket page heading', 'fluent-support-pro'),
                'create_ticket_cta' => __('Ticket Create Call to Action', 'fluent-support-pro')
            ]
        ];

        return $fields;
    }

    /**
     * Categories as id/label pairs, with child terms indented under their parent
     * so the hierarchy shows in a flat select.
     * @return array
     */
    private function getHierarchicalCategoryOptions()
    {
        // The select is not paginated, so cap the load on sites with huge taxonomies.
        $limit = (int) apply_filters('fluent_support/doc_post_categories_limit', 500);

        $terms = get_categories([
            'hide_empty' => false,
            'number'     => $limit
        ]);

        $byParent = [];
        foreach ($terms as $term) {
            $byParent[$term->parent][] = $term;
        }

        $options = [];
        $this->flattenCategoryTree($byParent, 0, 0, $options);

        return $options;
    }

    private function flattenCategoryTree($byParent, $parentId, $depth, &$options)
    {
        if (empty($byParent[$parentId])) {
            return;
        }

        foreach ($byParent[$parentId] as $term) {
            $options[] = [
                'id'    => $term->term_id,
                'label' => str_repeat('— ', $depth) . $term->name
            ];
            $this->flattenCategoryTree($byParent, $term->term_id, $depth + 1, $options);
        }
    }

}
