<?php

namespace FluentSupportPro\App\Http\Controllers;

use FluentSupport\Framework\Support\Arr;
use FluentSupportPro\App\Services\PluginManager\FluentLicensing;
use FluentSupport\App\Http\Controllers\Controller;
use FluentSupport\App\Services\Helper;
use FluentSupport\Framework\Request\Request;

/**
 * Endpoints for the license screen. Display values are resolved here because
 * dates need the site's timezone and locale, and the raw key must not reach
 * the browser.
 *
 * Only add response fields, never rename them: older free plugin versions still
 * read `status`, `expires`, `renew_url` and `purchase_url`.
 */
class LicenseController extends Controller
{
    public function getStatus(Request $request)
    {
        $licenseManager = FluentLicensing::getInstance();

        // Fetch fresh status from the store.
        $data = $licenseManager->getStatus(true);

        if (is_wp_error($data)) {
            return [
                'status'       => 'invalid',
                'error'        => true, // Kept for older clients.
                'message'      => $data->get_error_message(),
                'purchase_url' => $licenseManager->getConfig('purchase_url'),
                'support_url'  => $licenseManager->getConfig('support_url'),
            ];
        }

        return $this->formatLicenseData($data, $licenseManager);
    }

    /**
     * Tag a license URL with core's UTM parameters. Falls back to the plain URL
     * on cores older than 2.3.1, which lack Helper::getUpgradeUrl().
     *
     * @param string $content  utm_content placement.
     * @param string $baseUrl  URL to tag (also the fallback).
     * @param string $campaign utm_campaign override.
     * @return string
     */
    protected function upgradeUrl($content, $baseUrl, $campaign = 'upgrade_pro')
    {
        if (!method_exists(Helper::class, 'getUpgradeUrl')) {
            return $baseUrl;
        }

        return Helper::getUpgradeUrl($content, [
            'campaign' => $campaign,
            'base_url' => $baseUrl
        ]);
    }

    public function saveLicense(Request $request)
    {
        $licenseManager = FluentLicensing::getInstance();
        $licenseKey = $request->getSafe('license_key', 'sanitize_text_field');

        $response = $licenseManager->activate($licenseKey);
        if (is_wp_error($response)) {
            return $this->sendError([
                'message' => $response->get_error_message()
            ]);
        }

        return [
            'license_data' => $this->formatLicenseData($licenseManager->getStatus(), $licenseManager),
            'message'      => __('Your license key has been successfully updated', 'fluent-support-pro')
        ];
    }

    public function deactivateLicense(Request $request)
    {
        $licenseManager = FluentLicensing::getInstance();

        $response = $licenseManager->deactivate();
        if (is_wp_error($response)) {
            return $this->sendError([
                'message' => $response->get_error_message()
            ]);
        }

        return [
            'license_data' => $this->formatLicenseData($licenseManager->getStatus(), $licenseManager),
            'message'      => __('Your license key has been successfully deactivated', 'fluent-support-pro')
        ];
    }

    /**
     * Shape the stored license data for the license screen.
     *
     * @param array $data
     * @param FluentLicensing $licenseManager
     * @return array
     */
    protected function formatLicenseData($data, FluentLicensing $licenseManager)
    {
        $status = Arr::get($data, 'status', 'unregistered');
        $expires = Arr::get($data, 'expires', '');
        $isLifetime = $expires === 'lifetime';

        $data['purchase_url'] = $licenseManager->getConfig('purchase_url');
        $data['account_url'] = $licenseManager->getConfig('account_url');
        $data['support_url'] = $licenseManager->getConfig('support_url');
        $data['license_key_masked'] = $licenseManager->getMaskedLicenseKey();
        $data['product_title'] = !empty($data['product_title']) ? $data['product_title'] : $licenseManager->getConfig('plugin_title');
        $data['is_lifetime'] = $isLifetime;
        $data['expires_human'] = '';
        $data['days_remaining'] = null;
        $data['last_checked_human'] = '';

        $remoteGraceDays = isset($data['grace_period_days']) ? (int)$data['grace_period_days'] : 0;
        $data['in_grace_period'] = false;
        $data['grace_period_days'] = null;

        if (!$isLifetime && $expires && $expiresAt = strtotime($expires)) {
            $data['expires_human'] = wp_date(get_option('date_format'), $expiresAt);
            $data['days_remaining'] = (int)floor(($expiresAt - time()) / DAY_IN_SECONDS);
            $data = $this->attachGraceData($data, $expiresAt, $status, $remoteGraceDays);
        }

        // The renew URL carries the raw key, so only attach it when a renewal is offered.
        if (empty($data['renew_url']) && $this->needsRenewLink($data, $status)) {
            $data['renew_url'] = $licenseManager->getRenewUrl();
        }

        if (!empty($data['last_checked']) && $lastChecked = strtotime($data['last_checked'])) {
            $data['last_checked_human'] = sprintf(
            /* translators: %s: human readable time difference, e.g. "2 mins" */
                __('%s ago', 'fluent-support-pro'),
                human_time_diff($lastChecked)
            );
        }

        // The activation hash is a credential too.
        unset($data['license_key'], $data['activation_hash']);

        return $data;
    }

    /**
     * Offer a renewal when the license has expired, is in its grace window, has a
     * subscription that will not renew on its own, or expires within 30 days.
     *
     * @param array $data
     * @param string $status
     * @return bool
     */
    protected function needsRenewLink($data, $status)
    {
        if ($status === 'expired') {
            return true;
        }

        if ($status !== 'valid' || !empty($data['is_lifetime'])) {
            return false;
        }

        if (!empty($data['in_grace_period'])) {
            return true;
        }

        $subscription = isset($data['subscription_status']) ? $data['subscription_status'] : '';

        if ($subscription && !in_array($subscription, ['active', 'trialing', 'trial'], true)) {
            return true;
        }

        $daysRemaining = isset($data['days_remaining']) ? $data['days_remaining'] : null;

        return $daysRemaining !== null && $daysRemaining <= 30;
    }

    /**
     * The store keeps a license "valid" for a grace window after it expires.
     * Flag that window so the screen can explain a past expiry date. No end date
     * is reported because the fallback length is only a guess at the store's default.
     *
     * @param array $data
     * @param int $expiresAt
     * @param string $status
     * @param int $remoteGraceDays grace length the store reported, 0 when it reported none
     * @return array
     */
    protected function attachGraceData($data, $expiresAt, $status, $remoteGraceDays = 0)
    {
        if ($status !== 'valid' || $expiresAt > time()) {
            return $data;
        }

        $graceDays = $remoteGraceDays;

        if ($graceDays < 1) {
            $graceDays = (int)apply_filters('fluent_support/license_grace_period_days', 15);
        }

        if ($graceDays < 1) {
            return $data;
        }

        $graceEndsAt = $expiresAt + ($graceDays * DAY_IN_SECONDS);

        if ($graceEndsAt <= time()) {
            return $data;
        }

        $data['in_grace_period'] = true;
        $data['grace_period_days'] = $graceDays;

        return $data;
    }
}
