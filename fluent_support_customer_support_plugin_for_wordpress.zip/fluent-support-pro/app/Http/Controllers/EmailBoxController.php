<?php

namespace FluentSupportPro\App\Http\Controllers;

use FluentSupport\App\App;
use FluentSupport\App\Http\Controllers\Controller;
use FluentSupport\App\Models\Customer;
use FluentSupport\App\Models\Meta;
use FluentSupport\App\Models\MailBox;
use FluentSupport\Framework\Request\Request;
use FluentSupport\Framework\Support\Arr;
use FluentSupportPro\App\Hooks\Handlers\EmailPipingRetryHandler;
use FluentSupportPro\App\Services\Integrations\FluentEmailPiping\Api;
use FluentSupportPro\App\Services\Integrations\FluentEmailPiping\ByMailHandler;
use FluentSupportPro\App\Services\ProHelper;

class EmailBoxController extends Controller
{
    public function getPipeStatus(Request $request, $box_id)
    {
        $box = MailBox::findOrFail($box_id);

        if ($box->box_type != 'email') {
            return $this->sendError([
                'message' => __('This is a web type business inbox. No email piping is available', 'fluent-support-pro')
            ]);
        }

        if (!$box->mapped_email) {
            $webhookUrl = $this->getWebhookUrl($box);
            if (is_wp_error($webhookUrl)) {
                return $this->sendError([
                    'message' => $webhookUrl->get_error_message()
                ]);
            }

            return [
                'email_pipe'          => [
                    'status' => 'not_issued',
                ],
                'is_custom_supported' => ByMailHandler::isCustomPipeSupported(),
                'webhook_url'         => $webhookUrl
            ];
        }

        $status = 'unknown';
        $licenseKey = $this->getLicenseKey();

        $errorMessage = '';
        $boxToken = ProHelper::getBoxSecret($box);
        if (is_wp_error($boxToken)) {
            return $this->sendError([
                'message' => $boxToken->get_error_message()
            ]);
        }

        if ($licenseKey) {
            $remoteStatus = (new Api)->getPipeEmailStatus([
                'box_token'    => $boxToken,
                'license'      => $licenseKey,
                'mapped_email' => $box->mapped_email,
                // Replaces the stored list, so always the full list.
                'features'     => Api::featuresParam(),
            ]);

            if (is_wp_error($remoteStatus)) {
                // handle error here
                $errorMessage = $remoteStatus->get_error_message();
            } else {
                $status = isset($remoteStatus['status']) ? $remoteStatus['status'] : 'unknown';
                Api::rememberFeatures($box, $remoteStatus);
            }
        } else {
            $errorMessage = __('License key could not be found. Please activate Fluent Support license first', 'fluent-support-pro');
        }

        return [
            'email_pipe'          => [
                'status'       => $status,
                'mapped_email' => $box->mapped_email,
            ],
            'is_custom_supported' => ByMailHandler::isCustomPipeSupported(),
            'webhook_url'         => $this->getWebhookUrl($box, $boxToken),
            'error_message'       => $errorMessage
        ];

    }

    public function issueMappedEmail(Request $request, $box_id)
    {
        $box = MailBox::findOrFail($box_id);

        if ($box->box_type != 'email') {
            return $this->sendError([
                'message' => __('This is a web type business inbox. No email piping is available', 'fluent-support-pro')
            ]);
        }

        if ($box->mapped_email) {
            return $this->sendError([
                'message' => __('Mapped email has already been issued', 'fluent-support-pro')
            ]);
        }

        $licenseKey = $this->getLicenseKey();


        if ($licenseKey) {
            $boxToken = ProHelper::getBoxSecret($box);
            if (is_wp_error($boxToken)) {
                return $this->sendError([
                    'message' => $boxToken->get_error_message()
                ]);
            }

            // we don't have any mapped email yet. So let's get a new mapped email
            $data = [
                'license'     => $licenseKey,
                'email'       => $box->email,
                'site_url'    => site_url(),
                'webhook_url' => $this->getWebhookUrl($box, $boxToken),
                'box_token'   => $boxToken,
                'features'    => Api::featuresParam(),
            ];

            $response = (new Api())->issuePipeEmail($data);
            if (is_wp_error($response)) {
                return $this->sendError([
                    'message' => $response->get_error_message()
                ]);
            }
        } else {
            return $this->sendError([
                'message' => __('Please activate Fluent Support license', 'fluent-support-pro')
            ]);
        }

        if (isset($response['masked_email_id']) && is_email($response['masked_email_id'])) {
            $box->mapped_email = $response['masked_email_id'];
            $box->save();
            Api::rememberFeatures($box, $response);
            $response['mapped_email'] = $response['masked_email_id'];
        }

        return [
            'message'    => __('Mailbox mapped email has been generated', 'fluent-support-pro'),
            'email_pipe' => $response
        ];
    }

    public function pipePayload(Request $request, $box_id, $token)
    {
        $box = MailBox::find($box_id);

        if (!$box) {
            $box = MailBox::where('box_type', 'email')->first();
        }

        // This route is public, so a missing mailbox has to answer rather than fatal
        // inside getBoxSecret() on a null model.
        if (!$box) {
            return $this->sendError([
                'message' => __('Mailbox could not be found', 'fluent-support-pro')
            ], 404);
        }

        $boxToken = ProHelper::getBoxSecret($box);
        if (is_wp_error($boxToken)) {
            return $this->sendError([
                'message' => $boxToken->get_error_message()
            ]);
        }

        if (!is_string($token) || !hash_equals($boxToken, $token)) {
            return $this->sendError([
                'message' => __('Token mismatch', 'fluent-support-pro')
            ]);
        }

        // An authenticated push got through the host, so the pull can slow down.
        EmailPipingRetryHandler::markWebhookReceived();

        $data = $request->get('payload');

        // Limit payload size to prevent memory exhaustion
        $maxPayloadSize = apply_filters('fluent_support/max_webhook_payload_size', 5 * 1024 * 1024);
        if (is_string($data) && strlen($data) > $maxPayloadSize) {
            return $this->sendError([
                'message' => __('Payload too large', 'fluent-support-pro')
            ], 413);
        }

        $data = json_decode($data, true);

        if (!is_array($data)) {
            return $this->sendError([
                'message' => __('Invalid payload format', 'fluent-support-pro')
            ]);
        }
        // `mime` is the pipe's archive key, sent on push and replay alike. Plugins before
        // this release read only `mime_id`, which the pipe never sends.
        $mimeId = Arr::get($data, 'mime') ?: Arr::get($data, 'mime_id');

        $data = apply_filters('fluent_support_pro/email_piping_raw_data', $data, $box);

        $response = ByMailHandler::processPayload($data, $box, $mimeId);

        if (is_wp_error($response)) {

            $code = $response->get_error_code();

            $internalErrorCodes = [
                'ticket_creation_error',
                'customer_inactive',
                'response_creation_error',
            ];

            if (in_array($code, $internalErrorCodes)) {
                return [
                    'type'    => 'confirmed',
                    'message' => $code
                ];
            }

            return $this->sendError([
                'message' => $response->get_error_message(),
                'type'    => 'error',
                'reason'  => $response->get_error_code()
            ]);
        }

        return $response;
    }


    protected function getWebhookUrl($mailBox, $token = null)
    {
        if ($token === null) {
            $token = ProHelper::getBoxSecret($mailBox);
        }

        if (is_wp_error($token)) {
            return $token;
        }

        $app = App::getInstance();

        $ns = $app->config->get('app.rest_namespace');
        $v = $app->config->get('app.rest_version');

        return rest_url($ns . '/' . $v . '/mail-piping/' . $mailBox->id . '/push/' . $token);
    }

    protected function getLicenseKey()
    {
        $licenseData = get_option('__fluentsupport_pro_license');

        if ($licenseData && !empty($licenseData['license_key']) && $licenseData['status'] == 'valid') {
            return $licenseData['license_key'];
        }

        return false;
    }
}
