<?php

namespace FluentSupportPro\App\Http\Controllers;

use FluentSupport\App\Http\Controllers\Controller;
use FluentSupport\Framework\Request\Request;
use FluentSupportPro\App\Services\ProHelper;

class DocSuggestionController extends Controller
{
    public function index(Request $request)
    {
        $search = sanitize_text_field($request->search);

        $result = [];

        if ($search) {
            $ticketConfig = ProHelper::getTicketFormConfig();
            if ($ticketConfig['enable_docs'] != 'yes' || empty($ticketConfig['docs_post_types'])) {
                return [];
            }

            $search = apply_filters('fluent_support/search_doc_query', $search);
            $postTypes = (array) apply_filters('fluent_support/search_doc_post_types', $ticketConfig['docs_post_types']);
            $categories = !empty($ticketConfig['docs_post_categories']) ? $ticketConfig['docs_post_categories'] : [];

            // Apply the documented filter once, against its documented shape, before any
            // category-split branching - so hooks always see one consistent contract instead
            // of running multiple times with different array shapes per request.
            $baseArgs = apply_filters('fluent_support/doc_search_args', [
                'post_type'   => $postTypes,
                's'           => $search,
                'numberposts' => $ticketConfig['post_limits']
            ]);

            $postTypes = (array) ($baseArgs['post_type'] ?? $postTypes);
            $search = $baseArgs['s'] ?? $search;
            $limit = (int) ($baseArgs['numberposts'] ?? $ticketConfig['post_limits']);
            unset($baseArgs['post_type'], $baseArgs['s'], $baseArgs['numberposts']);

            // The 'category' taxonomy only applies to the 'post' post type, so when a category
            // filter is set it can't be added to a single mixed post_type query - a tax_query on
            // 'category' would wrongly exclude every result from the other selected post types.
            if ($categories && in_array('post', $postTypes, true)) {
                $posts = get_posts(array_merge($baseArgs, [
                    'post_type'   => 'post',
                    's'           => $search,
                    'numberposts' => $limit,
                    'tax_query'   => [
                        [
                            'taxonomy' => 'category',
                            'field'    => 'term_id',
                            'terms'    => $categories
                        ]
                    ]
                ]));

                $otherPostTypes = array_values(array_diff($postTypes, ['post']));

                if ($otherPostTypes && count($posts) < $limit) {
                    // count($posts) < $limit guarantees this stays positive; get_posts() treats
                    // numberposts => -1 as "unlimited", so a negative value here would silently
                    // return every matching post of the other post types.
                    $posts = array_merge($posts, get_posts(array_merge($baseArgs, [
                        'post_type'   => $otherPostTypes,
                        's'           => $search,
                        'numberposts' => $limit - count($posts)
                    ])));
                }
            } else {
                $posts = get_posts(array_merge($baseArgs, [
                    'post_type'   => $postTypes,
                    's'           => $search,
                    'numberposts' => $limit
                ]));
            }

            foreach ($posts as $item) {
                $result[] = [
                    'title' => $item->post_title,
                    'link'  => get_permalink($item)
                ];
            }
        }

        return apply_filters('fluent_support/search_doc_result', $result);
    }
}
