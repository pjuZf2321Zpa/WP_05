<?php

namespace FluentSupportPro\App\Http\Controllers;

use FluentSupport\App\Http\Controllers\Controller;
use FluentSupport\Framework\Request\Request;

class UploadIntegrationController extends Controller
{
    private static $allowedIntegrations = ['amazon_s3', 'dropbox', 'google_drive', 'cloudflare_r2', 's3_compatible'];

    /**
     * getSettings method will fetch the list of integration settings by integration key
     * @param Request $request
     * @return false
     */
    public function getSettings(Request $request)
    {
        $settingsKey = $request->getSafe('integration_key', 'sanitize_text_field');

        if (!in_array($settingsKey, self::$allowedIntegrations, true)) {
            return $this->sendError(['message' => __('Invalid integration key.', 'fluent-support-pro')]);
        }

        $settings = apply_filters('fluent_support_pro/file_storage_integration_settings_' . $settingsKey, [
            'fieldsConfig' => null,
            'settings'     => null
        ]);

        return $settings;
    }

    /**
     * saveSettings method will save the integration settings by integration key
     * @param Request $request
     * @return array
     */
    public function saveSettings(Request $request)
    {
        $settingsKey = $request->getSafe('integration_key', 'sanitize_text_field');

        if (!in_array($settingsKey, self::$allowedIntegrations, true)) {
            return $this->sendError(['message' => __('Invalid integration key.', 'fluent-support-pro')]);
        }

        $settings = $request->get('settings', []);
        $settings = is_array($settings) ? map_deep(wp_unslash($settings), 'sanitize_text_field') : [];

        $response = apply_filters('fluent_support_pro/file_storage_integration_settings_save_' . $settingsKey, [
            'message' => __('Sorry, upload driver not found.', 'fluent-support-pro')
        ], $settings);

        if (is_wp_error($response)) {
            return $this->sendError(['message' => $response->get_error_message()]);
        }

        return $response;
    }
}
