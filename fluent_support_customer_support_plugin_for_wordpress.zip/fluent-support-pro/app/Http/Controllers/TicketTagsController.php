<?php

namespace FluentSupportPro\App\Http\Controllers;

use FluentSupport\App\Http\Controllers\Controller;
use FluentSupport\App\Models\TicketTag;
use FluentSupport\Framework\Request\Request;

/**
 * REST endpoints for ticket tags.
 * @package FluentSupportPro\App\Http\Controllers
 *
 * @version 1.0.0
 */

class TicketTagsController extends Controller
{

    /**
     * Paginated tags with ticket counts.
     * @param Request $request
     * @return array
     */
    public function index(Request $request)
    {
        $tags = TicketTag::withCount('tickets')->orderBy('id', 'DESC')->searchBy($request->getSafe('search', 'sanitize_text_field'))->paginate();

        foreach ($tags as $tag) {
            $tag->count = $tag->tickets_count;
        }

        return [
            'tags' => $tags
        ];
    }

    /**
     * @param Request $request
     * @param $tag_id
     * @return array
     */
    public function get(Request $request, $tag_id)
    {
        $tag = TicketTag::findOrFail($tag_id);
        return [
            'tags' => $tag
        ];
    }

    /**
     * @param Request $request
     * @return array
     */
    public function create(Request $request)
    {
        $data = $request->all();

        $this->validate($data, [
            'title' => 'required'
        ]);

        $data = wp_unslash($data);
        $tag = TicketTag::create($data);

        return [
            'message' => __('Tag has been successfully created', 'fluent-support-pro'),
            'tag' => $tag
        ];
    }

    /**
     * @param Request $request
     * @param $tag_id
     * @return array
     */
    public function update(Request $request, $tag_id)
    {
        $data = $request->all();

        $this->validate($data, [
            'title' => 'required'
        ]);

        $tag = TicketTag::findOrFail($tag_id);
        $tag->fill($data);
        $tag->save();

        return [
            'message' => __('Tag has been updated', 'fluent-support-pro'),
            'tag' => TicketTag::find($tag_id)
        ];
    }

    /**
     * @param Request $request
     * @param $tag_id
     * @return array
     */
    public function delete(Request $request, $tag_id)
    {
        TicketTag::where('id', $tag_id)
            ->delete();

        return [
            'message' => __('Tag has been deleted', 'fluent-support-pro')
        ];
    }

    /**
     * All tags as id/title options, sorted by title.
     * @return array
     */
    public function getOptions()
    {
        return [
            'option_key' => 'ticket_tags',
            'options' => TicketTag::select('id', 'title')->orderBy('title', 'ASC')->get()
        ];
    }

}
