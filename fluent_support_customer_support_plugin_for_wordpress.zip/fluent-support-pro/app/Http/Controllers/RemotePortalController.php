<?php

namespace FluentSupportPro\App\Http\Controllers;

use FluentSupport\App\App;
use FluentSupport\App\Http\Controllers\Controller;
use FluentSupport\App\Http\Policies\PortalPolicy;
use FluentSupport\App\Models\MailBox;
use FluentSupport\App\Models\Product;
use FluentSupport\App\Services\Helper;
use FluentSupport\App\Services\Tickets\AgentTicketAccess;
use FluentSupport\App\Services\TranslationStrings;
use FluentSupport\Framework\Request\Request;
use FluentSupport\Framework\Support\Arr;
use FluentSupportPro\App\Modules\RemotePortal\ConnectionKey;
use FluentSupportPro\App\Modules\RemotePortal\RemotePortalSettings;
use FluentSupportPro\App\Modules\RemotePortal\RemoteSiteClient;

/**
 * Endpoints the Fluent Support Connector (on the main site) calls with the
 * Application Password an administrator gave it. Authorized by RemotePortalPolicy.
 */
class RemotePortalController extends Controller
{
    /**
     * The connector's first call, with the key an administrator generated here
     * (RemotePortalSettingsController::createConnectionKey) and the Application
     * Password of the user the portal will act as. The key works once.
     *
     * @param Request $request
     * @return array|\WP_Error
     */
    public function connect(Request $request)
    {
        if (RemotePortalSettings::isConstantMode()) {
            return $this->sendError(['message' => __('This support site sets its main site in wp-config.php.', 'fluent-support-pro')], 422);
        }

        if (!ConnectionKey::isValidSecret((string)$request->get('connection_secret'))) {
            return $this->sendError(['message' => __('The connection key is not valid, has expired or was used already. Generate a new one in Fluent Support > Settings > Remote Portal.', 'fluent-support-pro')], 401);
        }

        if (!PortalPolicy::canActOnBehalf()) {
            return $this->sendError(['message' => __('This user cannot act for customers. Use an administrator, or an agent with the Sensitive Data, Manage Other Tickets and Manage Settings permissions.', 'fluent-support-pro')], 403);
        }

        $siteUrl = untrailingslashit(esc_url_raw((string)$request->get('site_url')));
        $widgetEndpoint = esc_url_raw((string)$request->get('widget_endpoint'));
        $portalUrl = untrailingslashit(esc_url_raw((string)$request->get('portal_url')));
        $apiToken = (string)$request->get('api_token');

        // Widget calls carry customer emails, so they may only go to the main site itself.
        if (!ConnectionKey::isHttpUrl($siteUrl) || !ConnectionKey::isHttpUrl($widgetEndpoint) || !ConnectionKey::isSameOrigin($widgetEndpoint, $siteUrl)) {
            return $this->sendError(['message' => __('The main site sent an invalid address. Update the Fluent Support Connector and try again.', 'fluent-support-pro')], 422);
        }

        if (!RemoteSiteClient::isDevSite() && strtolower((string)wp_parse_url($siteUrl, PHP_URL_SCHEME)) !== 'https') {
            return $this->sendError(['message' => __('The main site must use HTTPS: this site sends it customer emails.', 'fluent-support-pro')], 422);
        }

        if (!preg_match('/^[A-Za-z0-9]{32,128}$/', $apiToken)) {
            return $this->sendError(['message' => __('The API token is missing or malformed. Update the Fluent Support Connector and try again.', 'fluent-support-pro')], 422);
        }

        // A token set in wp-config.php must be the one the main site checks.
        $constantToken = RemotePortalSettings::constantToken();
        if ($constantToken && !hash_equals($constantToken, $apiToken)) {
            return $this->sendError(['message' => __('FLUENT_SUPPORT_REMOTE_API_TOKEN in wp-config.php differs from the main site. Set the same token on both sites.', 'fluent-support-pro')], 422);
        }

        // Of two requests with the same key, only one gets past here.
        if (!ConnectionKey::claim((string)$request->get('connection_secret'))) {
            return $this->sendError(['message' => __('The connection key was used already. Generate a new one in Fluent Support > Settings > Remote Portal.', 'fluent-support-pro')], 401);
        }

        if ($portalUrl && !ConnectionKey::isSameHost($portalUrl, $siteUrl)) {
            $portalUrl = '';
        }

        RemotePortalSettings::update([
            'user_id'           => get_current_user_id(),
            'remote_url'        => $siteUrl,
            'widget_endpoint'   => $widgetEndpoint,
            'portal_url'        => $portalUrl,
            'api_token'         => $apiToken,
            'connector_version' => sanitize_text_field((string)$request->get('connector_version')),
            'providers'         => self::sanitizeProviders($request->get('providers', [])),
            'connected_at'      => current_time('mysql'),
            'last_inbound_at'   => current_time('mysql'),
            'last_outbound_at'  => '',
            'last_outbound_ok'  => '',
        ]);

        do_action('fluent_support/remote_portal_connected', $siteUrl, get_current_user_id());

        return array_merge([
            'success'     => true,
            'support_url' => untrailingslashit(site_url()),
        ], self::connectionInfo());
    }

    /**
     * Replace the API token this site sends on widget calls.
     *
     * @param Request $request
     * @return array|\WP_Error
     */
    public function rotateToken(Request $request)
    {
        $apiToken = (string)$request->get('api_token');

        if (!preg_match('/^[A-Za-z0-9]{32,128}$/', $apiToken)) {
            return $this->sendError(['message' => __('The API token is missing or malformed. Update the Fluent Support Connector and try again.', 'fluent-support-pro')], 422);
        }

        RemotePortalSettings::update(['api_token' => $apiToken]);

        return ['success' => true];
    }

    /**
     * The connector's health check, also used to refresh mailbox and product lists.
     *
     * @param Request $request
     * @return array
     */
    public function ping(Request $request)
    {
        $providers = $request->get('providers', null);
        $changes = [];

        if (is_array($providers)) {
            $changes['providers'] = self::sanitizeProviders($providers);
        }

        if ($request->get('connector_version')) {
            $changes['connector_version'] = sanitize_text_field((string)$request->get('connector_version'));
        }

        if ($changes) {
            RemotePortalSettings::update($changes);
        }

        return array_merge(['success' => true], self::connectionInfo());
    }

    /**
     * @param Request $request
     * @return array|\WP_Error
     */
    public function updatePortalUrl(Request $request)
    {
        $portalUrl = untrailingslashit(esc_url_raw((string)$request->get('portal_url')));
        $settings = RemotePortalSettings::get();

        if (!$portalUrl || !ConnectionKey::isSameHost($portalUrl, $settings['remote_url'])) {
            return $this->sendError(['message' => __('The portal page must be on the main site.', 'fluent-support-pro')], 422);
        }

        RemotePortalSettings::update(['portal_url' => $portalUrl]);

        return [
            'success'    => true,
            'portal_url' => $portalUrl,
        ];
    }

    /**
     * Ask this site to call the main site's widget endpoint, so the connector can
     * confirm the token works in that direction too.
     *
     * @param Request $request
     * @return array|\WP_Error
     */
    public function testWidgets(Request $request)
    {
        $response = (new RemoteSiteClient())->getWidgets([], 15);

        if (is_wp_error($response)) {
            return $this->sendError(['message' => $response->get_error_message()], 422);
        }

        return ['success' => true];
    }

    /**
     * @param Request $request
     * @return array
     */
    public function disconnect(Request $request)
    {
        RemotePortalSettings::clearConnection();

        do_action('fluent_support/remote_portal_disconnected', get_current_user_id());

        return [
            'success' => true,
            'message' => __('Disconnected', 'fluent-support-pro'),
        ];
    }

    /**
     * Customer portal settings the connector renders its portal with. Built once
     * for all remote customers, so nothing here may depend on a customer.
     *
     * @param Request $request
     * @return array
     */
    public function getPortalConfig(Request $request)
    {
        $app = App::getInstance();

        $i18n = TranslationStrings::getPortalStrings();
        $i18n['allowed_files_and_size'] = Helper::getFileUploadMessage();

        $data = [
            'is_remote'                      => true,
            'ticket_statuses'                => Helper::ticketStatuses(),
            'can_view_private_ticket_number' => false,
            // The connector files tickets through the API, never with a captcha.
            'recaptcha'                      => ['enabled' => false],
            'support_products'               => Product::select(['id', 'title'])->orderedByTitle()->get(),
            'product_field_required'         => Helper::isProductRequired(),
            'customer_ticket_priorities'     => Helper::customerTicketPriorities(),
            'fallback_image'                 => $app['url.assets'] . 'images/icons/file.svg',
            'has_file_upload'                => !!Helper::ticketAcceptedFileMiles(),
            'has_rich_text_editor'           => true,
            'max_file_upload'                => Helper::getBusinessSettings('max_file_upload') ?: 3,
            'agent_feedback_rating'          => Helper::getBusinessSettings('agent_feedback_rating') ?: 'no',
            'upload_ticket_ref'              => 'serial',
            'i18n'                           => $i18n,
        ];

        return [
            'portal_config' => apply_filters('fluent_support/customer_portal_vars', $data),
        ];
    }

    /**
     * Mailboxes, products and the admin portal link for the connector. Mailboxes are
     * limited to those the current (connecting) user can access, so the connector
     * never files tickets its own user could not read back.
     *
     * @return array
     */
    public static function connectionInfo()
    {
        $restricted = (new AgentTicketAccess())->getRestrictedMailboxIds();

        $mailboxes = MailBox::select(['id', 'name', 'is_default'])
            ->when($restricted, function ($query) use ($restricted) {
                return $query->whereNotIn('id', $restricted);
            })
            ->orderBy('id', 'ASC')
            ->get();

        $defaultMailbox = Helper::getDefaultMailBox();
        $defaultId = $defaultMailbox && !in_array((int)$defaultMailbox->id, $restricted, true) ? (int)$defaultMailbox->id : 0;

        if (!$defaultId && count($mailboxes)) {
            $defaultId = (int)$mailboxes[0]->id;
        }

        return [
            'site_name'          => get_bloginfo('name'),
            // The connector links agents here, and reads it on every ping.
            'admin_portal_url'   => Helper::getPortalAdminBaseUrl(),
            'pro_version'        => FLUENTSUPPORTPRO_PLUGIN_VERSION,
            'mailboxes'          => $mailboxes,
            'default_mailbox_id' => $defaultId,
            'products'           => Product::select(['id', 'title'])->orderedByTitle()->get(),
        ];
    }

    /**
     * @param mixed $providers
     * @return string[]
     */
    public static function sanitizeProviders($providers)
    {
        if (!is_array($providers)) {
            return [];
        }

        return array_values(array_filter(array_map('sanitize_key', Arr::flatten($providers))));
    }
}
