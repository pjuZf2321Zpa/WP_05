<?php

namespace FluentSupportPro\App\Http\Controllers;

use FluentSupport\Framework\Request\Request;
use FluentSupport\App\Http\Controllers\Controller;
use FluentSupport\App\Models\Ticket;
use FluentSupportPro\App\Services\Integrations\AI\AIService;

class AIController extends Controller
{
    public function getPresetPrompts(Request $request, AIService $aiService)
    {
        // A missing type gets no presets rather than a TypeError.
        $type   = (string) $request->getSafe('type', 'sanitize_text_field', '');
        $result = $aiService->getPresetPrompts($type);

        if (is_wp_error($result)) {
            return $this->sendError($result->get_error_message());
        }

        return $result;
    }

    public function generateResponse(Request $request, AIService $aiService)
    {
        $ticketId     = $request->getSafe('id', 'intval');
        $prompt       = $request->getSafe('content', 'sanitize_text_field');
        $selectedText = $request->getSafe('selectedText', 'sanitize_text_field', '');
        $type         = $request->getSafe('type', 'sanitize_text_field', 'response');

        if (!$prompt) {
            return $this->sendError(['message' => __('Please enter a prompt.', 'fluent-support-pro')]);
        }

        try {
            $ticket = Ticket::findOrFail($ticketId);
            $this->ensureCanAccessTicket($ticket);
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => $e->getMessage()
            ]);
        }

        if ($type === 'modifyResponse') {
            $result = $aiService->modifyResponse($prompt, $selectedText, $ticketId);
        } else {
            $ticket->load('responses');
            $result = $aiService->generateResponse($prompt, $ticket);
        }

        if (is_wp_error($result)) {
            return $this->sendError($result->get_error_message());
        }

        return $result;
    }

    public function getTicketSummary(Request $request, AIService $aiService)
    {
        $ticketId = $request->getSafe('id', 'intval');

        try {
            $ticket = Ticket::with('responses')->findOrFail($ticketId);
            $this->ensureCanAccessTicket($ticket);
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => $e->getMessage()
            ]);
        }

        $summary = $aiService->getTicketSummary($ticket);

        if (is_wp_error($summary)) {
            return $this->sendError($summary->get_error_message());
        }

        return $summary;
    }

    public function getTicketTone(Request $request, AIService $aiService)
    {
        $ticketId = $request->getSafe('id', 'intval');

        try {
            $ticket = Ticket::with('responses')->findOrFail($ticketId);
            $this->ensureCanAccessTicket($ticket);
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => $e->getMessage()
            ]);
        }

        $tone = $aiService->getTicketTone($ticket);

        if (is_wp_error($tone)) {
            return $this->sendError($tone->get_error_message());
        }

        return $tone;
    }
}
