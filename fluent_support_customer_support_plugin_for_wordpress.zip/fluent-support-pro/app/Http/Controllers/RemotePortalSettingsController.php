<?php

namespace FluentSupportPro\App\Http\Controllers;

use FluentSupport\App\Http\Controllers\Controller;
use FluentSupport\App\Models\MailBox;
use FluentSupport\App\Services\Helper;
use FluentSupport\App\Services\Tickets\AgentTicketAccess;
use FluentSupport\Framework\Request\Request;
use FluentSupportPro\App\Modules\RemotePortal\ConnectionKey;
use FluentSupportPro\App\Modules\RemotePortal\RemotePortalModule;
use FluentSupportPro\App\Modules\RemotePortal\RemotePortalSettings;
use FluentSupportPro\App\Modules\RemotePortal\RemoteSiteClient;

/**
 * Settings > Remote Portal on this (support) site. Authorized by AdminSettingsPolicy.
 */
class RemotePortalSettingsController extends Controller
{
    public function get(Request $request)
    {
        return $this->status();
    }

    public function save(Request $request)
    {
        // The switch decides where customers are sent, like connect and disconnect.
        if (!current_user_can('manage_options')) {
            return $this->sendError(['message' => __('Only an administrator can change Remote Portal.', 'fluent-support-pro')], 403);
        }

        if (defined('FLUENT_SUPPORT_REMOTE_PORTAL')) {
            return $this->sendError(['message' => __('Remote Portal is switched on or off in wp-config.php.', 'fluent-support-pro')], 422);
        }

        RemotePortalSettings::update([
            'enabled' => $request->get('enabled') === 'yes' ? 'yes' : 'no',
        ]);

        return array_merge([
            'message' => __('Settings saved', 'fluent-support-pro'),
        ], $this->status());
    }

    /**
     * A one-time key the administrator pastes into the Fluent Support Connector
     * on the main site, with the username and Application Password of the user
     * the portal acts as. Only an administrator gets one, so no agent can point
     * customers elsewhere.
     *
     * @param Request $request
     * @return array|\WP_Error
     */
    public function createConnectionKey(Request $request)
    {
        if (!current_user_can('manage_options')) {
            return $this->sendError(['message' => __('Only an administrator can connect a main site.', 'fluent-support-pro')], 403);
        }

        if (!RemotePortalModule::canServeRemote()) {
            return $this->sendError(['message' => __('Turn on Remote Portal first.', 'fluent-support-pro')], 422);
        }

        if (RemotePortalSettings::isConstantMode()) {
            return $this->sendError(['message' => __('The main site is set in wp-config.php.', 'fluent-support-pro')], 422);
        }

        return array_merge(ConnectionKey::create(), $this->status());
    }

    public function disconnect(Request $request)
    {
        if (!current_user_can('manage_options')) {
            return $this->sendError(['message' => __('Only an administrator can change Remote Portal.', 'fluent-support-pro')], 403);
        }

        if (RemotePortalSettings::isConstantMode()) {
            return $this->sendError(['message' => __('The main site is set in wp-config.php. Remove the constants there to disconnect.', 'fluent-support-pro')], 422);
        }

        $user = get_user_by('id', (int)RemotePortalSettings::get()['user_id']);

        RemotePortalSettings::clearConnection();
        ConnectionKey::forget();

        do_action('fluent_support/remote_portal_disconnected', get_current_user_id());

        // The main site keeps the Application Password, and with it the portal: only revoking it cuts it off.
        $message = $user
            /* translators: %s: username the main site connected as */
            ? sprintf(__('The main site has been disconnected. Revoke the Application Password of %s on their profile to stop its portal too.', 'fluent-support-pro'), $user->user_login)
            : __('The main site has been disconnected.', 'fluent-support-pro');

        return array_merge([
            'message' => $message,
        ], $this->status());
    }

    /**
     * Call the main site's widget endpoint with the stored token.
     *
     * @param Request $request
     * @return array|\WP_Error
     */
    public function test(Request $request)
    {
        $response = (new RemoteSiteClient())->getWidgets([], 15);

        if (is_wp_error($response)) {
            return $this->sendError(array_merge(['message' => $response->get_error_message()], $this->status()), 422);
        }

        return array_merge([
            'message' => __('The main site answered with a valid token.', 'fluent-support-pro'),
        ], $this->status());
    }

    private function status()
    {
        $settings = RemotePortalSettings::get();
        $connected = RemotePortalSettings::isConnected();

        return [
            'settings'        => [
                'enabled'           => $settings['enabled'],
                'remote_url'        => $settings['remote_url'],
                'portal_url'        => $settings['portal_url'],
                'connector_version' => $settings['connector_version'],
                'providers'         => (array)$settings['providers'],
                'connected_at'      => $settings['connected_at'],
                'last_inbound_at'   => $settings['last_inbound_at'],
                'last_outbound_at'  => $settings['last_outbound_at'],
                'last_outbound_ok'  => $settings['last_outbound_ok'],
                'has_token'         => !empty($settings['api_token']),
            ],
            'connected'       => $connected,
            'connected_user'  => $connected ? $this->describeUser((int)$settings['user_id']) : null,
            'constant_mode'   => RemotePortalSettings::isConstantMode(),
            'constants'       => RemotePortalSettings::definedConstants(),
            'legacy_plugin'   => class_exists('\FluentSupportServer'),
            'support_url'     => untrailingslashit(site_url()),
            'app_passwords'   => function_exists('wp_is_application_passwords_available') && wp_is_application_passwords_available(),
            'https'           => wp_parse_url(site_url(), PHP_URL_SCHEME) === 'https',
            'key_expires_at'  => ConnectionKey::pendingExpiresAt(),
            /*
             * Filter the download link for the connector plugin the main site installs
             *
             * @since 2.4.1
             *
             * @param string $url
             */
            'connector_download_url' => esc_url_raw(apply_filters('fluent_support_pro/remote_portal_connector_download_url', 'https://fluentapi.wpmanageninja.com/addons/download/fluent-support-client/latest.zip')),
            // Connecting, disconnecting and the switch are for site administrators only.
            'can_manage'      => current_user_can('manage_options'),
        ];
    }

    /**
     * Who the connector acts as, and what that user can reach.
     *
     * @param int $userId
     * @return array|null
     */
    private function describeUser($userId)
    {
        $user = $userId ? get_user_by('id', $userId) : null;

        if (!$user) {
            return null;
        }

        $isAdmin = user_can($user, 'manage_options');
        $agent = Helper::getAgentByUserId($userId);
        $mailboxes = __('All mailboxes', 'fluent-support-pro');

        if ($agent) {
            $restricted = (new AgentTicketAccess())->getRestrictedMailboxIds($agent);

            if ($restricted) {
                $mailboxes = implode(', ', MailBox::whereNotIn('id', $restricted)->pluck('name')->toArray());
            }
        }

        return [
            'id'           => $userId,
            'display_name' => $user->display_name,
            'user_login'   => $user->user_login,
            'role'         => $isAdmin ? 'admin' : 'agent',
            'mailboxes'    => $mailboxes,
            'profile_url'  => get_edit_user_link($userId) . '#application-passwords-section',
        ];
    }
}
