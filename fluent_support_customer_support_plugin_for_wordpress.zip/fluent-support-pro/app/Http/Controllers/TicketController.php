<?php

namespace FluentSupportPro\App\Http\Controllers;

use FluentSupport\App\Http\Controllers\Controller;
use FluentSupport\App\Models\Ticket;
use FluentSupport\App\Modules\PermissionManager;
use FluentSupport\App\Services\Helper;
use FluentSupport\App\Services\Tickets\TicketQuery;
use FluentSupport\App\Services\Tickets\TicketService;
use FluentSupport\Framework\Request\Request;
use FluentSupportPro\App\Services\ProTicketService;

class TicketController extends Controller
{
    /**
     * getCustomerTickets method will return customer tickets by customer id
     * @param Request $request
     * @param int $customer_id
     * @return array|array[]
     */
    public function getCustomerTickets(Request $request, $customer_id)
    {
        $tickets = (new TicketQuery([
            'customer_id' => (int) $customer_id,
            'exclude_id'  => (int) $request->get('exclude_ticket_id'),
            'sort_by'     => 'created_at',
        ]))->paginate();

        return [
            'tickets' => $tickets
        ];
    }


    /**
     * mergeCustomerTickets will merge tickets into one
     * @param Request $request
     * @param $ticket_id //ticket id where the tickets will be merged
     * @return array|array[]
     */
    public function mergeCustomerTickets(Request $request, $ticket_id)
    {
        if (!PermissionManager::currentUserCan('fst_merge_tickets')) {
            return $this->sendError([
                'message' => __('You do not have permission to merge tickets', 'fluent-support-pro')
            ]);
        }

        $ticketIDToMerge = $request->get('ticket_to_merge', []);
        $ticketIDToMerge = is_array($ticketIDToMerge) ? array_map('intval', $ticketIDToMerge) : [];
        $ticketIDToMerge = array_filter($ticketIDToMerge);

        try {
            $this->ensureCanAccessTicket(Ticket::findOrFail($ticket_id));

            return (new ProTicketService())->mergeCustomerTickets($ticketIDToMerge, $ticket_id);
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => $e->getMessage()
            ]);
        }
    }

    public function syncTicketWatchers(Request $request, $ticket_id)
    {
        $watchers = $request->get('watchers', []);
        $watchers = is_array($watchers) ? $watchers : [];

        $agentIds = [];
        foreach($watchers as $watcher){
            $agentIds[] = is_array($watcher) ? intval($watcher['id'] ?? 0) : intval($watcher);
        }

        $agentIds = array_filter($agentIds);

        try {
            $ticket = Ticket::findOrFail($ticket_id);
            $this->ensureCanAccessTicket($ticket);
            (new TicketService())->syncWatchers($ticket, $agentIds, Helper::getAgentByUserId());

            return [
                'message' => __('Watchers have been updated', 'fluent-support-pro')
            ];
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => $e->getMessage()
            ]);
        }
    }

    public function addTicketWatchers(Request $request, $ticket_id)
    {
        $watchers = $request->get('watchers', []);
        $watchers = is_array($watchers) ? array_map('intval', $watchers) : [];
        $watchers = array_filter($watchers);

        if( ! $watchers ){
            return $this->sendError([
                'message' => __('Watchers is required', 'fluent-support-pro')
            ]);
        }

        try {
            $ticket = Ticket::findOrFail($ticket_id);
            $this->ensureCanAccessTicket($ticket);
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => $e->getMessage()
            ]);
        }

        (new TicketService())->addWatchers($ticket, $watchers, Helper::getAgentByUserId());

        return [
            'message' => __('Watchers have been added to this ticket', 'fluent-support-pro'),
        ];
    }

    public function splitToNewTicket ( Request $request, ProTicketService $proTicketService, $ticket_id )
    {
        $newTicketData = $request->get('split_ticket', []);
        $sanitizeRules = [
            'conversation_id' => 'intval',
            'customer_id' => 'intval',
            'mailbox_id' => 'intval',
            'title' => 'sanitize_text_field',
            // Guarded so an older core can't fatal; remove once min core has the helper.
            'content' => method_exists(Helper::class, 'sanitizeHtmlContent') ? Helper::class . '::sanitizeHtmlContent' : 'wp_kses_post',
            'client_priority' => 'sanitize_text_field',
            'create_customer' => 'sanitize_text_field',
            'create_wp_user' => 'sanitize_text_field',
        ];

        if( $newTicketData && is_array($newTicketData) ) {
            foreach ($newTicketData as $dataKey => $dataItem) {
                $sanitizeFunc = isset($sanitizeRules[$dataKey]) ? $sanitizeRules[$dataKey]: 'sanitize_text_field';
                if(is_array($dataItem)) {
                    $newTicketData[$dataKey] = map_deep($dataItem, $sanitizeFunc);
                } else {
                    $newTicketData[$dataKey] = $sanitizeFunc($dataItem);
                }
            }
        }

        try {
            $this->ensureCanAccessTicket(Ticket::findOrFail($ticket_id));

            return $proTicketService->splitToNewTicket( $ticket_id, $newTicketData );
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => $e->getMessage()
            ]);
        }
    }
}
