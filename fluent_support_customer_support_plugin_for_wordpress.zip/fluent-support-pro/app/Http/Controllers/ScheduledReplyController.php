<?php

namespace FluentSupportPro\App\Http\Controllers;

use FluentSupport\App\Http\Controllers\Controller;
use FluentSupport\App\Models\Conversation;
use FluentSupport\App\Models\Ticket;
use FluentSupport\App\Modules\PermissionManager;
use FluentSupport\App\Services\Helper;
use FluentSupport\Framework\Http\Request\Request;
use FluentSupportPro\App\Modules\ScheduledReplies\ScheduledReplyService;

/**
 * Manage a reply that was scheduled from the reply box. Creating one goes through the free
 * plugin's reply endpoint with a `scheduled_at` field, so attachments and Cc follow the exact
 * same path as a normal reply.
 */
class ScheduledReplyController extends Controller
{
    public function update(Request $request, $ticket_id, $response_id)
    {
        try {
            $conversation = $this->getScheduledReply($ticket_id, $response_id, true);

            $data = [];

            if ($request->has('content')) {
                $data['content'] = $request->getSafe('content', 'wp_kses_post');
            }

            if ($request->has('scheduled_at')) {
                $data['scheduled_at'] = $request->getSafe('scheduled_at', 'intval');
            }

            if ($request->has('close_ticket')) {
                $data['close_ticket'] = $request->getSafe('close_ticket', 'sanitize_text_field');
            }

            // exists(), not has(): an empty list arrives as '' (jQuery drops empty arrays) and still means "clear the Cc"
            if ($request->exists('cc_emails')) {
                $data['cc_emails'] = array_values(array_filter(array_map('sanitize_email', (array) $request->get('cc_emails', []))));
            }

            // The full list of files the reply keeps; '' removes them all
            if ($request->exists('attachments')) {
                $data['attachments'] = array_values(array_filter(array_map('sanitize_text_field', (array) $request->get('attachments', []))));
            }

            (new ScheduledReplyService())->update($conversation, $data);

            return [
                'message' => __('Scheduled reply has been updated', 'fluent-support-pro')
            ];
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => Helper::getSafeErrorMessage($e)
            ]);
        }
    }

    public function sendNow($ticket_id, $response_id)
    {
        try {
            $conversation = $this->getScheduledReply($ticket_id, $response_id, true);

            if (!(new ScheduledReplyService())->sendNow($conversation)) {
                throw new \Exception(esc_html__('The scheduled reply could not be sent. Please refresh the ticket.', 'fluent-support-pro'));
            }

            return [
                'message' => __('Response has been added', 'fluent-support-pro')
            ];
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => Helper::getSafeErrorMessage($e)
            ]);
        }
    }

    public function resume($ticket_id, $response_id)
    {
        try {
            $conversation = $this->getScheduledReply($ticket_id, $response_id, true);

            $sent = (new ScheduledReplyService())->resume($conversation);

            return [
                'message' => $sent
                    ? __('Response has been added', 'fluent-support-pro')
                    : __('Reply will be sent as planned', 'fluent-support-pro')
            ];
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => Helper::getSafeErrorMessage($e)
            ]);
        }
    }

    public function cancel($ticket_id, $response_id)
    {
        try {
            // Any agent who can reply may cancel; the activity log records who did.
            $conversation = $this->getScheduledReply($ticket_id, $response_id, false);

            $restore = (new ScheduledReplyService())->cancel($conversation, Helper::getAgentByUserId());

            return [
                'message' => __('Scheduled reply has been cancelled', 'fluent-support-pro'),
                'restore' => $restore
            ];
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => Helper::getSafeErrorMessage($e)
            ]);
        }
    }

    /**
     * @param int $ticketId
     * @param int $responseId
     * @param bool $authorOnly Editing or sending another agent's reply needs the manage-others capability
     * @return Conversation
     * @throws \Exception
     */
    private function getScheduledReply($ticketId, $responseId, $authorOnly)
    {
        $this->ensureCanManageTickets();

        $ticket = Ticket::findOrFail($ticketId);
        $this->ensureCanAccessTicket($ticket);

        $conversation = Conversation::where('id', $responseId)
            ->where('ticket_id', $ticket->id)
            ->where('conversation_type', ScheduledReplyService::TYPE)
            ->first();

        if (!$conversation) {
            throw new \Exception(esc_html__('This scheduled reply no longer exists. It may have been sent or cancelled.', 'fluent-support-pro'));
        }

        if ($authorOnly) {
            $agent = Helper::getAgentByUserId();
            $isAuthor = $agent && (int) $agent->id === (int) $conversation->person_id;

            if (!$isAuthor && !PermissionManager::currentUserCan('fst_manage_other_tickets')) {
                throw new \Exception(esc_html__('Only the author can change this scheduled reply.', 'fluent-support-pro'));
            }
        }

        return $conversation;
    }
}
