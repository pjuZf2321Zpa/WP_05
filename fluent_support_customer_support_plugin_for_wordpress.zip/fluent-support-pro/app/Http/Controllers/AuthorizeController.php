<?php

namespace FluentSupportPro\App\Http\Controllers;

use FluentSupport\App\App;
use FluentSupport\Framework\Request\Request;
use FluentSupport\App\Http\Controllers\Controller;

class AuthorizeController extends Controller
{
    public function handleAuthorizeDropbox(Request $request)
    {
        $code = $request->getSafe('code', 'sanitize_text_field');
        $state = $request->getSafe('state', 'sanitize_text_field');

        // Extract user ID from state to look up the correct per-user transient
        $userId = strstr($state, '|', true);
        if ($userId === false || $userId === '') {
            wp_redirect(admin_url('admin.php?page=fluent-support#/settings/upload_integration&error=invalid_state'));
            exit();
        }

        // Verify OAuth state parameter to prevent CSRF
        // Only delete the transient after successful match so invalid requests can't consume it
        $transientKey = 'fluent_support_dropbox_oauth_state_' . intval($userId);
        $storedState = get_transient($transientKey);

        if (!$storedState || !hash_equals($storedState, $state)) {
            wp_redirect(admin_url('admin.php?page=fluent-support#/settings/upload_integration&error=invalid_state'));
            exit();
        }

        delete_transient($transientKey);

        // Verify the code
        do_action('fluent_support_pro/verify_dropbox_code', $code);

        wp_redirect(admin_url('admin.php?page=fluent-support#/settings/upload_integration'));
        exit();
    }

    public function handleAuthorizeGoogleDrive(Request $request)
    {
        $code = $request->getSafe('code', 'sanitize_text_field');
        $state = $request->getSafe('state', 'sanitize_text_field');

        // Extract user ID from state to look up the correct per-user transient
        $userId = strstr($state, '|', true);
        if ($userId === false || $userId === '') {
            wp_redirect(admin_url('admin.php?page=fluent-support#/settings/upload_integration&error=invalid_state'));
            exit();
        }

        // Verify OAuth state parameter to prevent CSRF
        // Only delete the transient after successful match so invalid requests can't consume it
        $transientKey = 'fluent_support_google_drive_oauth_state_' . intval($userId);
        $storedState = get_transient($transientKey);

        if (!$storedState || !hash_equals($storedState, $state)) {
            wp_redirect(admin_url('admin.php?page=fluent-support#/settings/upload_integration&error=invalid_state'));
            exit();
        }

        delete_transient($transientKey);

        // Exchange the code server side. The code is never handed to the browser
        do_action('fluent_support_pro/verify_google_code', $code);

        wp_redirect(admin_url('admin.php?page=fluent-support#/settings/upload_integration'));
        exit();
    }
}
