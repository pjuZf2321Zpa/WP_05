<?php

namespace FluentSupportPro\Database\Migrations;

class TimeTrackMigrator
{
    static $tableName = 'fs_time_tracks';

    public static function migrate()
    {
        global $wpdb;

        $charsetCollate = $wpdb->get_charset_collate();

        $table = $wpdb->prefix . static::$tableName;

        if ($wpdb->get_var("SHOW TABLES LIKE '$table'") != $table) {
            $sql = "CREATE TABLE $table (
                `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                `agent_id` BIGINT UNSIGNED NOT NULL,
                `customer_id` BIGINT UNSIGNED NOT NULL,
                `ticket_id` BIGINT UNSIGNED NOT NULL,
                `mailbox_id` BIGINT UNSIGNED NOT NULL,
                `started_at` TIMESTAMP NULL,
                `completed_at` TIMESTAMP NULL,
                `message` TEXT NULL,
                `status` VARCHAR(50) NULL DEFAULT 'committed',
                `working_minutes` INT UNSIGNED NOT NULL DEFAULT 0,
                `billable_minutes` INT UNSIGNED NOT NULL DEFAULT 0,
                `is_manual` TINYINT(1) NOT NULL DEFAULT 0,
                `created_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
                `updated_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`),
                INDEX `idx_agent_id` (`agent_id`),
                INDEX `idx_ticket_id` (`ticket_id`),
                INDEX `idx_customer_id` (`customer_id`),
                INDEX `idx_mailbox_id` (`mailbox_id`),
                INDEX `idx_status` (`status`),
                INDEX `idx_completed_at` (`completed_at`)
            ) $charsetCollate;";
            $created = dbDelta($sql);
            return $created;
        } else {
            static::alterTable($table);
        }

        return false;
    }

    public static function alterTable($table)
    {
        static::addMissingIndexes($table);
    }

    public static function addMissingIndexes($table)
    {
        global $wpdb;

        $table = esc_sql($table);

        $existing_indexes = $wpdb->get_results("SHOW INDEX FROM `$table`");
        $existing_index_names = [];
        foreach ($existing_indexes as $index) {
            $existing_index_names[] = $index->Key_name;
        }

        $indexes = [
            'idx_agent_id'    => '`agent_id`',
            'idx_ticket_id'   => '`ticket_id`',
            'idx_customer_id' => '`customer_id`',
            'idx_mailbox_id'  => '`mailbox_id`',
            'idx_status'      => '`status`',
            'idx_completed_at'=> '`completed_at`',
        ];

        foreach ($indexes as $index_name => $columns) {
            if (!in_array($index_name, $existing_index_names)) {
                $wpdb->query("ALTER TABLE `$table` ADD INDEX `$index_name` ($columns)");
            }
        }
    }
}
