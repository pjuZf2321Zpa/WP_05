<?php

namespace FluentSupportPro\Database\Migrations;

class TicketAuditsMigrator
{
    static $tableName = 'fs_ticket_audits';

    public static function migrate()
    {
        global $wpdb;

        $charsetCollate = $wpdb->get_charset_collate();

        $table = $wpdb->prefix . static::$tableName;

        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table)) != $table) {
            $sql = "CREATE TABLE $table (
                `id` BIGINT(20) UNSIGNED NOT NULL PRIMARY KEY AUTO_INCREMENT,
                `ticket_id` BIGINT(20) UNSIGNED NOT NULL,
                `mood` VARCHAR(20) NULL,
                `score` DECIMAL(3,1) NULL,
                `summary` TEXT NULL,
                `status` VARCHAR(20) NOT NULL DEFAULT 'failed',
                `error` TEXT NULL,
                `audited_at` DATETIME NULL,
                `created_at` TIMESTAMP NULL,
                `updated_at` TIMESTAMP NULL,
                UNIQUE KEY `idx_ticket_id` (`ticket_id`)
            ) $charsetCollate;";
            $created = dbDelta($sql);
            return $created;
        } else {
            static::alterTable($table);
        }

        return false;
    }

    public static function alterTable($table)
    {
        static::addMissingIndexes($table);
    }

    public static function addMissingIndexes($table)
    {
        global $wpdb;

        $table = esc_sql($table);

        $existing_indexes = $wpdb->get_results("SHOW INDEX FROM `$table`");
        $existing_index_names = [];
        foreach ($existing_indexes as $index) {
            $existing_index_names[] = $index->Key_name;
        }

        $indexes = [
            'idx_ticket_id' => '`ticket_id`',
        ];

        foreach ($indexes as $index_name => $columns) {
            if (!in_array($index_name, $existing_index_names)) {
                $wpdb->query("ALTER TABLE `$table` ADD UNIQUE INDEX `$index_name` ($columns)");
            }
        }
    }
}
