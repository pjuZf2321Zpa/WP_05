<?php

namespace FluentSupportPro\Database\Migrations;

class WorkflowMigrator
{
    static $tableName = 'fs_workflows';

    public static function migrate()
    {
        global $wpdb;

        $charsetCollate = $wpdb->get_charset_collate();

        $table = $wpdb->prefix . static::$tableName;

        if ($wpdb->get_var("SHOW TABLES LIKE '$table'") != $table) {
            $sql = "CREATE TABLE $table (
                `id` BIGINT(20) UNSIGNED NOT NULL PRIMARY KEY AUTO_INCREMENT,
                `created_by` BIGINT(20) NULL,
                `priority` INT(10) NULL DEFAULT 10,
                `title` VARCHAR(192) NULL,
                `trigger_key` VARCHAR(192) NULL,
                `trigger_type` VARCHAR(50) default 'manual',
                `settings` LONGTEXT NULL,
                `status` VARCHAR(50) default 'draft',
                `last_ran_at` TIMESTAMP NULL,
                `created_at` TIMESTAMP NULL,
                `updated_at` TIMESTAMP NULL,
                INDEX `idx_trigger_key` (`trigger_key`(191)),
                INDEX `idx_trigger_type` (`trigger_type`),
                INDEX `idx_status` (`status`)
            ) $charsetCollate;";
            $created = dbDelta($sql);
            return $created;
        } else {
            static::alterTable($table);
        }

        return false;
    }

    public static function alterTable($table)
    {
        static::addMissingColumns($table);
        static::addMissingIndexes($table);
    }

    public static function addMissingColumns($table)
    {
        global $wpdb;

        $table = esc_sql($table);

        $existing_columns = $wpdb->get_col("DESC `$table`", 0);

        if (!in_array('priority', $existing_columns)) {
            $wpdb->query('ALTER TABLE `' . $table . '` ADD `priority` INT(10) NULL DEFAULT 10 AFTER `created_by`');
        }
    }

    public static function addMissingIndexes($table)
    {
        global $wpdb;

        $table = esc_sql($table);

        $existing_indexes = $wpdb->get_results("SHOW INDEX FROM `$table`");
        $existing_index_names = [];
        foreach ($existing_indexes as $index) {
            $existing_index_names[] = $index->Key_name;
        }

        $indexes = [
            'idx_trigger_key'  => '`trigger_key`(191)',
            'idx_trigger_type' => '`trigger_type`',
            'idx_status'       => '`status`',
        ];

        foreach ($indexes as $index_name => $columns) {
            if (!in_array($index_name, $existing_index_names)) {
                $wpdb->query("ALTER TABLE `$table` ADD INDEX `$index_name` ($columns)");
            }
        }
    }
}
