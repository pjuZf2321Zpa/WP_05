<?php

namespace FluentSupportPro\Database\Migrations;

class ReportSnapshotsMigrator
{
    static $tableName = 'fs_report_snapshots';

    public static function migrate()
    {
        global $wpdb;

        $charsetCollate = $wpdb->get_charset_collate();

        $table = $wpdb->prefix . static::$tableName;

        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table)) != $table) {
            $sql = "CREATE TABLE $table (
                `id` BIGINT(20) UNSIGNED NOT NULL PRIMARY KEY AUTO_INCREMENT,
                `snapshot_time` DATETIME NOT NULL,
                `report_type` VARCHAR(50) NOT NULL,
                `period` VARCHAR(20) NOT NULL DEFAULT '6h',
                `data` LONGTEXT NOT NULL,
                `created_at` TIMESTAMP NULL,
                `updated_at` TIMESTAMP NULL,
                INDEX `idx_report_type_snapshot_time` (`report_type`, `snapshot_time`),
                INDEX `idx_snapshot_time` (`snapshot_time`)
            ) $charsetCollate;";
            $created = dbDelta($sql);
            return $created;
        } else {
            static::alterTable($table);
        }

        return false;
    }

    public static function alterTable($table)
    {
        static::addMissingIndexes($table);
    }

    public static function addMissingIndexes($table)
    {
        global $wpdb;

        $table = esc_sql($table);

        $existing_indexes = $wpdb->get_results("SHOW INDEX FROM `$table`");
        $existing_index_names = [];
        foreach ($existing_indexes as $index) {
            $existing_index_names[] = $index->Key_name;
        }

        $indexes = [
            'idx_report_type_snapshot_time' => '`report_type`, `snapshot_time`',
            'idx_snapshot_time'             => '`snapshot_time`',
        ];

        foreach ($indexes as $index_name => $columns) {
            if (!in_array($index_name, $existing_index_names)) {
                $wpdb->query("ALTER TABLE `$table` ADD INDEX `$index_name` ($columns)");
            }
        }
    }
}
