=== Fluent Support Pro - WordPress Helpdesk and Customer Support Ticket Plugin ===
Contributors: techjewel, wpmanageninja, adreastrian
Tags: support, ticketing, fluent support
Requires at least: 5.6
Tested up to: 7.1
Stable tag: 2.5.0
Requires PHP: 7.4

Fluent Support Pro Version

== Installation ==
if you already have Fluent Support plugin then You have to install this plugin to get the additional features.

Installation Steps:
-----
1. Goto  Plugins » Add New
2. Then click on "Upload Plugins"
3. Then Click "Choose File" and then select the fluent-support-pro.zip file
4. Then Click, Install Now after that activate that.
5. You may need to activate the License, and You will get the license at your WPManageninja.com account.

Manual Install:
------------------------
Upload the plugin files to the /wp-content/plugins/ directory, then activate the plugin.

== Changelog ==
= 2.5.0 (Date: November 2, 2026) =
* Added: Scheduled Replies (Pro) — send later, then edit, send now or cancel
* Added: System Admin Tools — Cron Job Monitor, Database Health and Data Cleanup
* Added: Workflow editor shows each workflow as a flow of steps, with a run log (Pro)
* Added: Site admins can edit customer messages to remove sensitive data
* Added: Text/Markdown (.txt, .md) attachments
* Improved: Email replies keep the ticket status, like portal replies (Pro)
* Fixed: Report charts dropped the last day, and some counts were off
* Fixed: Help Scout, Freshdesk and Zendesk migrations shifted afternoon times by 12 hours
* Fixed: Timesheet filters and mailbox restrictions (Pro)
* Fixed: Several workflow conditions and actions (Pro)
* Fixed: Bulk replies lost formatting and links
* Fixed: Emailed replies with only an attachment were rejected (Pro)
* Fixed: UI and Dark Mode issues
* Fixed: Security through ongoing audits and hardening.

= 2.4.7 (Date: October 23, 2026) =
* Added: Ticket list sidebar views with live counts (My Work, Needs Attention, Priority, Status, Saved Filters, Tags)
* Added: Redesigned Customers list and profile with smart search, sorting and bulk block/unblock
* Added: S3-compatible storage: DigitalOcean Spaces, Wasabi, Backblaze B2 and MinIO (Pro)
* Added: "Default" AI model option that follows the recommended model
* Improved: Faster admin; each page loads only its own code (about 73% less to download)
* Improved: Dark Mode reworked across the plugin
* Improved: Admin and Customer Portal now fit phones and tablets
* Improved: Remote storage keeps Dropbox and Google Drive files private and delivers email attachments reliably (Pro)
* Improved: Redesigned ticket activity, sidebar widgets and dashboard cards
* Improved: AI reply drafts are shorter and in the customer's language (Pro)
* Fixed: Piped emails showing raw HTML or entity text for some characters (Pro)
* Fixed: Reply editor issues with saved drafts
* Fixed: Wide images in a ticket getting cut off
* Note: The Customer Portal ticket list is now a plain list (`.fs_ticket_list`, `.fs_ticket_item`) instead of a table, and the logout menu is a button. If your theme or custom CSS styled the old table markup, please review it
* Note: Dropbox users may need to reconnect once to grant the new read permission (Pro)

= 2.4.5 (Date: October 09, 2026) =
* Added: Remote Portal (Pro) — serve the Customer Portal on your main site, connected with a one-time key
* Added: Workflow triggers On Ticket Reopened, On Agent Response, On Agent Assigned and On Customer Feedback, plus Ticket Tags, Ticket Source, Agent Priority and Feedback conditions (Pro)
* Added: Email piping handles auto-replies, bounces and automated mail with a loop guard, and threads replies by signed email references (Pro)
* Added: Bulk actions to change priority or product, reopen tickets and remove tags
* Added: Ticket view shortcuts for next/previous ticket and close, and a Ticket Stats sidebar widget
* Added: Advanced filter by ticket source, and a "Waiting for your reply" badge in the Customer Portal
* Added: Inbox From name can be the inbox name, the replying agent or a custom template
* Added: MCP tools to edit, delete and publish draft replies, bulk reply, and a duplicate-reply guard
* Added: `fluent_support/agent_feedback_received` action when a customer rates a reply
* Improved: An agent reply is held for review when the customer wrote again while it was being typed
* Improved: Agent signatures now come from the {{agent.signature}} smartcode in email templates
* Improved: Customer Portal signup follows the WordPress "Anyone can register" setting and uses FluentAuth forms when available
* Improved: Agent-initiated tickets read like an email from the agent
* Improved: Faster dashboard, agent list and ticket view; all API dates in site time
* Improved: Collapsible settings sidebar and translation coverage across the admin and portal
* Fixed: Approved drafts are sent as their author, not the approver
* Fixed: Importers calculate reply, first response and close times correctly
* Fixed: Activity log cleanup deleted every log when retention was set to 0
* Fixed: Auto-close without a response skipped close emails and workflows (Pro)
* Fixed: Dropbox and Google Drive uploads failing after a token refresh (Pro)
* Fixed: Security through ongoing audits and hardening.

= 2.4.0 (Date: September 15, 2026) =
* Added: Advanced Reports suite (Pro) — Ticket Overview, Agent Performance, Product Insight, Business Boxes and Activity reports with date-range filters and comparison charts
* Added: AI Ticket Audit report (Pro) — audit tickets with OpenAI, Gemini or Anthropic and filter results by mood
* Added: Historical Snapshots for Advanced Reports (Pro) — data captured every 6 hours, with a Live / Snapshot comparison selector
* Added: Growth metrics and activity grid in Agent Performance, plus product interaction counts in Product Insight (Pro)
* Added: Google reCAPTCHA (v2 and v3) for the Customer Portal ticket form
* Added: Date range custom field type (Pro) — one field for start and end dates
* Added: Category(Post) filter for Knowledge Base article suggestions (Pro)
* Added: Customer Portal prompts customers to confirm a changed account email via a signed verification link, and merges any unlinked customer record already collecting tickets at that address
* Added: `fluent_support/merging_customer_records` action so add-ons can move their own data when two customer records merge
* Improved: Keyboard-accessible ticket rows and responsive report tables, charts and toolbars
* Improved: Product dropdowns are alphabetized and searchable; fallback agent is now a searchable dropdown
* Improved: Half-hourly background tasks now run through Action Scheduler and reconcile automatically
* Improved: Per-agent report metrics use grouped queries instead of one query per agent, and mailbox restrictions are resolved once per request
* Improved: Consistent input and select heights in the admin UI; scoped date-range picker styles
* Improved: Report stat numbers now use thousand separators
* Improved: Translation coverage for admin strings — theme modes, ticket sidebar, report tabs, date shortcuts, workflow list and more
* Improved: (MCP) Silent close option for the close-ticket tool
* Fixed: Product filter on the ticket list — cleared filters, filter routing and per-product ticket counts
* Fixed: Business Boxes report showing waiting tickets from the wrong mailbox
* Fixed: Two-factor and login expiry parsed as UTC, expiring early on non-UTC sites
* Fixed: Literal backslashes were stripped from ticket and reply content, including piped emails (Pro)
* Fixed: Duplicate Cc line on the first message of a ticket thread
* Fixed: Agent-initiated outreach email showing the internal log message instead of the agent's reply for {{ticket.content}}
* Fixed: Long ticket titles overflowing instead of wrapping on the ticket view; ticket title typography
* Fixed: Inline attachments without a placeholder are now visible in the ticket thread (Pro)
* Fixed: Ticket category ordering and stale category IDs in custom field options (Pro)
* Fixed: Security through ongoing audits and hardening.

= 2.3.2 (Date: August 19, 2026) =
* Compatibility with WordPress 7.1
* Added checksum-based signed updater.
* Fixed: Security through ongoing audits and hardening.
* Fixed: Missing FluentBoards documentation URL to integration statuses.
* Improved: Updated the Gemini model list in AI Model Setup

= 2.3.0 (Date: July 13, 2026) =
* Added: MCP (Model Context Protocol) server integration — AI agents can now connect directly to Fluent Support tickets, conversations, and customer data via a standards-based MCP interface; configurable from a new MCP Settings page
* Added: Multi-provider AI support — choose between OpenAI, Gemini, and Anthropic as your AI backend from the new AI Model Setup settings page; provider and model are independently configurable
* Added: FluentCart workflow conditions (Pro) — branch automations on customer purchase history with three new conditions: Customer Purchased Product, Customer Purchased Package (Variation), and Customer Has Active License; enables product-tier routing and SLA enforcement automatically
* Added: Easy Digital Downloads workflow conditions (Pro) — same set of commerce conditions (Purchased Product, Purchased Variation, Has Active License) now available for EDD customers
* Added: Change Priority workflow action (Pro) — set a ticket's priority automatically as a workflow action step
* Added: CLI migration support for Zendesk and HelpScout — import tickets, customers, and conversations via WP-CLI
* Added: Load-more pagination for Previous Conversations sidebar widget
* Added: Remote product search in Workflow commerce conditions — searchable product/variation picker for large catalogs
* Improved: AI response content now renders markdown (bold, lists, code blocks) correctly when inserted into the reply editor
* Improved: Workflow trigger fires an internal notification to assigned agents when an automation runs
* Improved: Previous ticket query scoped to agent visibility, preventing data leakage in the sidebar widget
* Improved: Redesign ticket watchers widget with collapsible toggle
* Improved: Redesign customer/agent ticket list thread, label with role icon badge
* Fixed: Agent @mention search failing with large agent lists — search is now server-side
* Fixed: Inline pasted images not appearing correctly in sent email notifications
* Fixed: Email addresses in internal notes being auto-converted to clickable hyperlinks
* Fixed: Repeated replies closing tickets due to sticky close_ticket flag persisting across responses
* Fixed: Attachment limit error message now shows the configured maximum instead of a generic message
* Fixed: Agent signature and shortcode not applied in agent-initiated ticket notification emails
* Fixed: Mailbox Settings error notification not displaying (wrong $notify call signature)
* Fixed: Active navigation link using incorrect background color design token
* Security: Restricted saved reply access and sanitized agent AI guidelines input

= 2.2.1 (Date: May 23, 2026) =
* Added: Grid view layout for the ticket list
* Fixed issue with time tracking where working minutes were showing as null
* Unified and improved dynamic support menu UI structure
* Security: Hardened ticket ID resolution in Customer Portal policy

= 2.2.0 (Date: May 20, 2026) =
* Added: Internal Notifications module — agents now receive real-time in-app notifications for @mentions, ticket assignments and reassignments, customer replies, ticket close/reopen events, and Workflow triggers; fully configurable per event category with a self-notification toggle
* Added: FluentBooking integration — insert available time slots from ticket replies, view upcoming meetings in the ticket sidebar, and log scheduled-meeting notes automatically
* Added: Public ticket numbers with optional prefix support — configurable serial numbers display in email notifications, ticket UI, and Customer Portal; admins can set a minimum ticket number and per-product prefix via the fluent_support/ticket_prefix filter
* Added: FluentCommunity as a global Customer Portal destination, embedding Fluent Support inside a FluentCommunity space
* Improved: Customer portal destination setting — choose where ticket links in email notifications redirect (Customer Portal, WooCommerce My Account, or FluentCommunity)
* Added: fluent_support/ticket_content_before_render, fluent_support/ticket_content_after_render, fluent_support/response_content_before_render, and fluent_support/response_content_after_render filters for developer control over ticket and response content rendering
* Added: Signing Secret support for Slack and Telegram webhooks while maintaining compatibility with existing integrations.
* Improved: attachment handling for agent-created ticket emails and pasted inline images
* Improved: dark mode visibility for filters, switches, radios, tables, and reply controls
* Refined the ticket reply composer UI for a smoother and more intuitive reply-writing experience.
* Fixed: Customer Portal not immediately reflecting ticket status changes applied by a Workflow action (e.g., auto-close on customer reply)
* Fixed: Fluent Support admin font (Inter) leaking into WordPress admin chrome outside Fluent Support pages
* Fixed: Dark mode toggle switch colors in Global Settings
* Fixed: Global Settings page design inconsistencies
* Fixed: Shortcode attribute not normalizing to lowercase

= 2.1.1 (Date: April 10, 2026) =
* Fixed an issue where the global ticket summary was not rendering outside Fluent Support pages
* Fixed Slack notification sending issue (Pro)
* Fixed activity log staff filter dropdown collapsing issue

= 2.1.0 (Date: April 09, 2026) =
* Added Agent Groups to organize support teams and enable smart ticket distribution
* Added Agent Signature option for support agents
* Added Agent-Initiated Tickets (agents can create tickets on behalf of customers)
* Added new email template for Agent-Initiated Tickets
* Added file upload integration with Cloudflare R2 and Amazon S3 (Pro)
* Added Dynamic Sidebar Widgets system (hook-based, supports PHP and Vue components)
* Added fluent_support/should_send_notification filter to control notification delivery across channels
* Improved overall security
* Optimized database queries for better performance
* Fixed Fluent Boards integration action availability in free version when plugin is active
* Fixed portal signup visibility issue when using shortcode attribute
* Fixed “Close Ticket Silently” not suppressing email notifications
* Fixed incorrect syncing of customer status with FluentCRM
* Fixed advanced filter deletion issue in tickets list
* Fixed theme mode toggle visibility issue
* Fixed untranslated strings in advanced filter options

= 2.0.6 (Date: March 05, 2026) =
* Updated: Core PHP framework
* Added: Zendesk migration improvement to collect archived tickets and resume previous migrations
* Fixed: Onboarding dark mode design issue
* Fixed: Bulk option checkbox now visible by default
* Fixed: Ticket list not updating after bulk actions
* Fixed: File upload limit validation issue after deleting previously uploaded files
* Fixed: WordPress admin bar overlapping Fluent Support menu
* Fixed: Agent reply count in reports incorrectly including internal notes
* Fixed: Error when navigating directly to a ticket URL due to window.history.state being null

= 2.0.5 (Date: March 02, 2026) =
* Added: Admin Dashboard Dark Mode
* Added: Support for OpenAI GPT-5.2 & GPT-5.2 Chat models
* Added: View Tickets (Read Only) permission
* Improved: Faster ticket list loading
* Improved: Optimized large-scale Zendesk migration
* Fixed: Draft Reply permission issue
* Fixed: Attachment links during ticket merge
* Fixed: Ticket content unordered list formatting
* Fixed: Integration settings save button visibility
* Fixed: “Waiting Since” tooltip date display
* Fixed: Saved Replies left menu link
* Fixed: Login page styling issue
* Fixed: Date range picker responsive layout

= 2.0.2 (Date: February 09, 2026) =
* Fixed an issue where current ticket watchers were not displaying in the ticket list.
* Fixed an issue where ticket merging could fail from the ticket view page.
* Fixed an issue where reCAPTCHA settings were not saving properly.
* Fixed a responsiveness issue with the bulk actions bar in the ticket list.
* Fixed issues related to ticket migration.
* Fixed a customer profile update issue by treating customer IP fields as strings.
* Fixed a styling issue with the Ticket Merge dialog buttons.

= 2.0.1 (Date: February 06, 2026) =
* Improved onboarding completion UI and post-onboarding navigation
* Improved sanitization and validation handling
* Fixed Saved Replies modal showing stale content when editing

= 2.0.0 (Date: February 05, 2026) =
* Complete admin interface redesign with a modern layout.
* Full RTL (Right-to-Left) language support across the interface.
* Fully mobile-responsive experience across all modules.
* Revamped menu structure with dropdowns for better organization.
* Responsive hamburger menus for Main Menu, Settings, and Reports.
* Drag & Drop Image Upload for tickets.
* Ticket List Display Settings: manage layout and element visibility directly from the Display Settings icon.
* Compact Ticket List Layout for faster scanning and higher information density.
* Keyboard Shortcuts: Enable via Plugin Settings → Global Settings → Enable Keyboard Shortcuts. Click “Keyboard Shortcuts” to view all available commands.
* Improved Frontend Support Portal responsiveness and theme compatibility.
* Refactored Customer Portal SCSS variables for easier dark mode implementation.
* Updated core PHP framework; resolved PHP 8.4 compatibility issues.
* Improved input sanitization and validation.
* Migrated components to Options API and refactored Vue components for better performance.
* Prevented unnecessary API calls in Reports module.
* Separated personal reports from agent performance reports.
* Added Reports Stats API for product/business-specific insights.
* Selected date range persists when switching report tabs.
* Resolved issue where pressing Enter caused page reload instead of submitting forms.
* Fixed Block Editor styles not applying correctly on Customer Portal.
* Fixed WordPress 6.9 admin text editor toolbar compatibility issues.
* Fixed database table error when Activity Log feature was disabled.
* Fixed auto password generation issue for new users with empty password fields.

= 1.10.4 (Date: November 21, 2025) =
- Fixed: Issue with attachments not showing from third-party storage.
- Updated License Server

= 1.10.3 (Date: November 17, 2025) =
* Fixed: Paid Memberships Pro widget was not visible for some customers.

= 1.10.1 (Date: November 03, 2025) =
* Fixed: Fixed undefined safeUnserialize method error

= 1.10.0 (Date: October 23, 2025) =
* Added: Fluent Cart product purchase widget in the ticket sidebar.
* Added: Fluent Cart product and order options in custom fields.
* Added: Workflow trigger based on Fluent Cart product and order from custom fields.
* Added: Option to integrate the customer portal into the Fluent Cart customer dashboard.
* Added: Multi-select option for product filtering in tickets.
* Improved: Refined plugin performance for increased speed and efficiency.

= 1.9.2 (Date: August 20, 2025) =
* Added: Product assignment to tickets in Workflow Actions.
* Added: Support for custom field data in Outgoing Webhooks.
* Improved: Click-to-copy shortcode functionality on the Global Settings page.
* Improved: Smart code selection dropdown in Email Settings with click-to-insert functionality in WP Editor.
* Improved: Dash icon updated.
* Fixed: CSRF issue fixed on Report Export – nonce verification.
* Fixed: Error during AI activity log cleanup.

= 1.9.1 (Date: July 15, 2025) =
* Improved: After selecting the portal page, it now displays the page name along with the page ID.
* Improved: Enhanced data validation when creating a customer through the "Create Ticket on Behalf of Customer" module.
* Improved: Added a filter to control the display of bottom borders in email templates.
* Fixed: Custom field “required” validation not working under certain conditions.
* Fixed: Start date does not display correctly in the Paid Memberships Pro widget.
* Fixed: Design conflict with the Blocksy theme in the customer portal.
* Fixed: Translation issues across various modules.
* Fixed: Agents unable to edit additional data fields.
* Fixed: Custom fields do not render properly in the admin portal when creating a ticket on behalf of a customer.
* Fixed: Selected product displayed as ID instead of name in view ticket module.
* Fixed: Change customer option showed only the current customer ID instead of the full list.
* Fixed: Workflow didn’t work when Fluent Community plugin was inactive.
* Fixed: Attachment access issue on symlinked servers using realpath.

= 1.9.0 (Date: May 28, 2025) =
* Added: Integration with Fluent Community. (Pro)
* Added: Informational replies on admin ticket responses.
* Added: Help Scout, Freshdesk & Zendesk Ticket Migration Now Available in Free Version.
* Improved: Internal note functionality now works for closed tickets.
* Improved: Responses in closed tickets can now be edited.
* Fixed: Error message shown for the Priority field when the Product is required in the customer portal.
* Fixed: Fatal error triggered by the Share Essentials weekly cron job.
* Fixed: Customer responses not displaying in agent response stats within agent reports.
* Fixed: Incorrect ticket response count shown in today's stats.
* Fixed: Broken media upload CSS in the page editor caused by the [fluent_support_admin_portal] shortcode.
* Fixed: "Waiting For Reply" filter not working in advanced filtering.
* Fixed: Responsive issues in the Agent Portal.

= 1.8.8 (Date: Apr 22, 2025) =
* Fixed: Ticket status was not displaying correctly on the ticket view page in the customer portal.
* Fixed: File types, quantity limits, and file sizes were not displaying correctly in the customer portal.
* Fixed: Missing translations in the customer portal.
* Fixed: Changes to ticket form configurations were not reflecting in the customer portal.
* Fixed: Removed unnecessary API call on the customer portal page.
* Fixed: Custom field not updating correctly via REST API.
* Fixed: Issue with Fluent Form and Fluent CRM integration.
* Fixed: Issues with updating actions in the workflow.
* Fixed: Issue with conflicting forms in the customer portal's registration and password reset process.

= 1.8.7 (Date: Mar 20, 2025) =
* Improvement: Enhanced and refined the Customer Portal UI/UX.
* Improvement: New block editor for the updated Customer Portal layout.
* Improvement: Resume options for incomplete Freshdesk ticket migrations.
* Fixed: Images pasted directly are deleted after some time.
* Fixed: Unable to edit customers with no name in the customer list.
* Fixed: Attachment issue when creating a ticket from Fluent Forms.
* Fixed: Issue with unchecking agent permissions.
* Fixed: Missing option to delete custom fields during creation.
* Fixed: Creating an action in a workflow also creates a duplicate action.
* Fixed: Advanced filter does not work when a multi-select option is selected.
* Fixed: Unable to assign users to a new business box if the current one is restricted to agents.
* Fixed: Product not displaying in WooCommerce widget.
* Fixed: Conditional logic for custom fields not working properly when creating a ticket from the admin portal.
* Fixed: Direct copy-paste of images was not functioning properly in multisite.

= 1.8.6 (Date: Feb 28, 2025) =
* Fixed: Textdomain Consistency: Standardized all translation string textdomains across the plugin for better internationalization support.
* Fixed: Enhanced Security: Implemented proper data escaping and improve overall plugin security.
* Fixed: Media Protection: Reinforced security measures for attachment uploads by restricting direct access to image directories and implementing proper file path validation.

= 1.8.5 (Date: Dec 26, 2024) =
* Added: Agent Time Tracking (Pro)
* Added: Saved search (Pro)
* Added: Keyboard Shortcuts
* Fixed: Issue where the Customer Portal's rich text editor reverted to a basic editor upon reload.
* Fixed: Recaptcha functionality issue in the Customer Portal.
* Fixed: WorkFlow action sequence title issue.
* Fixed: Issue where embedded content appeared in preformatted form in the reply message after reloading.
* Fixed: Compatibility issue with the Sequential Order Plugin.
* Fixed: 404 error page not showing when an incorrect ticket number is entered in the ticket view URL.
* Fixed: Error message displaying when the Customer Portal loads.
* Fixed: Notes within a closed ticket becoming non-editable.
* Fixed: Restricted agents being incorrectly assigned to a mailbox through the ticket dashboard's bulk action feature.
* Fixed: Email verification message translation and verification message hooks not functioning properly.

= 1.8.2 (Date: Sep 25, 2024) =
* Added: Workflow action sequence (Pro)
* Added: Direct paste image in WP Editor
* Fixed: Required sign not visible for product options marked as required during ticket creation
* Fixed: Reply button toggle option not working in the admin portal
* Fixed: Issue with the route URL on the All Tickets page
* Fixed: Filter not refreshing in the Customer Portal after clicking the (❌) icon in the search field
* Fixed: OpenAI routing issue resolved
* Fixed: CSS issue related to ticket filter theme in the Customer Portal
* Fixed: Responsive issue on the view ticket page
* Fixed: After importing tickets from another SaaS platform, the agent is imported but not synchronized with the system

= 1.8.1 (Date: Sep 10, 2024) =
* Fixed - Email verification vulnerability issue in signup
* Fixed - Customer portal ticket fetching vulnerability issue

= 1.8.0 (Date: Aug 15, 2024) =
* Added - Integration with OpenAI (Pro)
* Added - Product Filter and sorting option in customer portal
* Added - Email verification in sighup for customer
* Added - Two-FA in signing for customer
* Fixed - Freshdesk ticket migration issue
* Fixed - Response message not being saved correctly in the auto-close settings
* Fixed - Data remaining in the "Create Customer" form after creating a customer in the Customers module
* Fixed - Form not resetting after creating a new ticket on behalf of a customer from the dashboard by support staff
* Fixed - Shortcode always being pasted below the content
* Fixed - Tickets still being deletable even when the "Delete Ticket" permission is unchecked
* Fixed - Workflow issue when the ticket-closing condition is triggered

= 1.7.90 (Date: May 28, 2024) =
* Added - Activity Trends by Time of Day (Pro)
* Added - Integration with Fluent Boards (Pro)
* Added - Integrations Logs
* Added - Upload ticket attachments to their respective ticket folders in Google Drive, organized accordingly (Pro)
* Added - Duplicate or clone workflows (Pro)
* Added - Required option  in product field (Pro)
* Fixed - If the site language is not set to English, the workflow always defaults to manual mode
* Fixed - Inbox identifier css issue in all tickets table
* Fixed - If anyone choose View dashboard and draft_reply then it will not show any tickets
* Fixed - Freshdesk ticket migration issue
* Fixed - Zendesk ticket migration issue
* Fixed - Clicking the "Import Tickets" button in the ticket migration module opens multiple modals simultaneously
* Fixed - Issue with Bookmark
* Fixed - When the file name is too long, the file will not upload during ticket creation or in responses
* Fixed - If a restriction is applied to a specific business box, it still appears on the dashboard
* Fixed - MemberPress integration to show separate lists for recurring and non-recurring subscriptions
* Fixed - The WooCommerce widget is not shown on the 'View Customer' page

= 1.7.80 (Date: April 3, 2024) =
* Added - Restrict business boxes for specific agents
* Added - Ticket search feature in customer portal
* Added - MemberPress Integration
* Added - Option to resume the migration process for the last incomplete ticket in Helpscout (Pro)
* Added - Display the exact time of ticket or response creation upon hovering over it in the admin portal
* Fixed - Attachment download issue in email piping
* Fixed - BetterDocs integration issue
* Fixed - Agent Only field isn't displaying into the ticket
* Fixed - Draft Reply approve button issue with attachment
* Fixed - There is an issue with exporting the agent report time
* Fixed - The Gravatar image link is causing a PHP 8.2 deprecated issue
* Fixed - The issue with the "Enable Reply from Telegram" button in Telegram
* Fixed - The Auto Close Settings are not saving
* Fixed - Helpscout ticket migration issue
* Fixed - When responding to emails in German, create a new ticket instead of replying.

= 1.7.72 (Date: January 10, 2024) =
* Fixed - Notification integration settings issue
* Fixed - Displaying an incorrect assigned agent name
* Fixed - Links open in same tab issue
* Fixed - Telegram reply issue
* Fixed - Required functionality is not working in the conditional field
* Fixed - Ticket status issue

= 1.7.71 (Date: December 23, 2023) =
* Fixed - Email Piping Ticket Created Discord Notification Issue fixed

= 1.7.7 (Date: December 13, 2023) =
* Added - Trigger Fluent CRM automation within workflow (Pro)
* Added - Agent feedback in ticket response (Pro)
* Added - Agent permission for save response as draft
* Added - New shortcode for agent title signature in the inbox settings
* Added - Custom registration field using hooks
* Fixed - Agent can assign ticket without permission
* Fixed - The time duration displayed for ticket creation and response creation is inconsistent
* Fixed - Open a new thread in email for every response created
* Fixed - Translation issue
* MySQL orderby security issue fixed

= 1.7.6 (Date: November 07, 2023) =
* Improved File Upload
* Dropbox and Google Drive File Upload Issues Fixed
* Full Rewrite of the File Upload & Remote Driver System
* Improved UI

= 1.7.5 (Date: November 01, 2023) =
* Fixed - Ticket id not included in outgoing webhook
* Fixed - Update and delete issue in saved reply
* Fixed - Time difference issue in saved reply

= 1.7.4 (Date: October 31, 2023) =
* Fixed - Freshdesk migrator issue
* Fixed - Added a few missing translations
* Fixed - Summary report issue fixing for products and business inbox
* Fixed - File upload and view issue for 3rd party

= 1.7.3 (Date: August 23, 2023) =
* Added - Report by Product(Pro)
* Added - Report by Business Inbox(Pro)
* Fixed - Create ticket issue for required fields is fixed
* Fixed - Custom field not showing in the add field from
* Fixed - Added missing translations

= 1.7.2 (Date: July 17, 2023) =
* Fixed - Create ticket issue for required fields is fixed
* Fixed - Custom field not showing in the add field from

= 1.7.0 (Date: July 14, 2023) =
* Added - Support email cc
* Added - Option to set dedicated mailbox for webhook
* Added - Business box added in the workflow action and condition list
* Added - Support file attachment upload in third party (Google Drive and Dropbox)
* Added - Zendesk migrator
* Fixed - Work action ordering issue
* Fixed - Custom field required in conditional form
* Fixed - Conditional form rendering issue
* Fixed - Ticket create using API endpoint
* Fixed - Freshdesk migrator issue

= 1.6.9 (Date: March 16, 2023) =
* Added - Custom field required or optional
* Added - Custom field in the workflow condition
* Added - Saved replies templates in auto ticket close module
* Added - Saved replies templates in the workflow
* Fixed - Fluent CRM widget missing issue
* Fixed - Ticket merge popup issue
* Fixed - Delete action of manual workflow
* More improvements

= 1.6.8 (Date: February 14, 2023) =
* Added - Migrate Tickets from Freshdesk
* Added - Toggle to stop auto close bookmarked tickets
* Fixed - Issue with telegram reply
* Fixed - Support staff not assigned to ticket via workflow
* Fixed - Frontend agent portal issues
* More Bug Fixes and Improvements

= 1.6.7 (Date: November 24, 2022) =
* Agent Summary Exporter
* Migrate Tickets from Help Scout
* WooCommerce Purchase History Widget Redesigned
* Bug Fixes and Improvements

= 1.6.6 (Date: October, 2022) =
* Activity Log Filters
* Active Tickets for Products
* Waiting Ticket stat on Dashboard
* Hourly Reports for tickets activity
* New Trigger – Ticket Closed on Automation
* Close Ticket Silently (without triggering emails)
* Migrate Tickets from Awesome Support
* Migrate Tickets from SupportCandy
* Bug Fixes and Improvements

= 1.6.5 (Date: August 24, 2022) =
* Added Auto Close Ticket Module based on ticket inactivity days
* Improved Saved Replies. Now you can add more replies
* Fixed File Upload Issues
* Fixed Few minor issues on integrations

= 1.6.2 (Date: August 22, 2022) =
* Fixed fiw minor bugs regarding data sanitizations
* Saved Replied issues Fixed
* All external links are will open in new tab
* Auto Linking linkable contents
* Create new ticket flow improved

= 1.6.0 (Date: August 19, 2022) =
* NEW - Agent portal in frontend
* Added - Shortcode support in workflow
* Added - LearnPress integration
* Added - Split reply to a new ticket
* Added - License status in EDD widget
* Added - Ticket closing feature from Slack and Telegram
* Added - Adding or removing ticket bookmark from workflow
* Improvement - Security
* Improvement - Code Base

= 1.5.7 (Date: July 07, 2022) =
* Added - Global Customer Searching on Ticket Creation on Behalf of Customer
* Added - Template for Ticket Creation on Behalf of Customer
* Fixed - WooCommerce Order Total Issue
* Fixed - Text Encoding Issue on Email Piping

= 1.5.6 (Date: May 26, 2022) =
* Added - Ticket Merge System
* Added - Ticket Watcher System
* Added - Mailbox Check in Workflow
* Added - FluentCRM List & Tag Check in Workflow
* Added - FluentCRM List & Tag Attach & Detach in Workflow
* Fixed - WooCommerce Multi Currency Issue
* Fixed - WooCommerce Draft Product Display in Custom Fields

= 1.5.5 (Date: March 02, 2022) =
* Added - Whatsapp integration via twilio
* Added - Outgoing Webhook Integration in workflow
* Added - Agents report filtering by specific agent
* Added - Today's stats of tickets
* Added - Send notification to 3rd party integrated notification system on agent assign
* Added - Ticket moving feature from one mailbox to another
* Fixed - Ticket created email notification not sending when creating a ticket via incoming webhook

= 1.5.4 (Date: January 19, 2022) =
* Added - Ticket advanced filtering
* Added - Custom fields on Telegram integration
* Added - Incoming Webhook
* Added - Missing translations
* Fixed - Issues related to email piping
* Fixed - Email footer not sending to email notification
* Fixed - Discord Notification issues
* Fixed - Custom fields not saving when creating a ticket from agent dashboard
