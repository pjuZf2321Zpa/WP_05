#!/bin/bash
# Builds a bb-theme-builder ZIP and uploads it to R2.
# Usage: ./scripts/build.sh <pr_number> <version_slug> <dest_prefix> <source_dir>
#   dest_prefix:  "branch" or "changelog"
#   source_dir:   path to the source to zip (defaults to GITHUB_WORKSPACE)
# Required env vars: R2_BUCKET, R2_ENDPOINT, GITHUB_WORKSPACE

set -e

PR_NUMBER=$1
VERSION_SLUG=$2
DEST_PREFIX=$3
SOURCE_DIR=${4:-$GITHUB_WORKSPACE}
SLUG="bb-theme-builder"
WORK_DIR=/tmp/bb-zip-work

# Rsync source to a clean working directory
rm -rf $WORK_DIR
mkdir -p $WORK_DIR/$SLUG

rsync -a $SOURCE_DIR/ $WORK_DIR/$SLUG/ \
  --exclude='.babelrc' \
  --exclude='composer.json' \
  --exclude='composer.lock' \
  --exclude='.DS_Store' \
  --exclude='.editorconfig' \
  --exclude='.eslintignore' \
  --exclude='.eslintrc.json' \
  --exclude='eslint.config.js' \
  --exclude='.git' \
  --exclude='.gitattributes' \
  --exclude='.gitignore' \
  --exclude='.github' \
  --exclude='.npmrc' \
  --exclude='gulpfile.js' \
  --exclude='package.json' \
  --exclude='package-lock.json' \
  --exclude='phpcs.xml' \
  --exclude='phpunit.xml' \
  --exclude='Thumbs.db' \
  --exclude='webpack.config.js' \
  --exclude='yarn.lock' \
  --exclude='CLAUDE.md' \
  --exclude='agents/' \
  --exclude='node_modules/' \
  --exclude='scripts/' \
  --exclude='*.zip'

# Refuse to package a bundle carrying a serialized webpack build error. webpack
# writes a failed loader's error into the bundle as a throwing module instead of
# failing the build, so a poisoned artifact commits and ships looking normal. See #1184.
POISONED=$(grep -rl 'Module build failed' $WORK_DIR/$SLUG --include='*.js' || true)
if [ -n "$POISONED" ]; then
  echo "ERROR: build artifacts contain a webpack build error:" >&2
  echo "$POISONED" >&2
  exit 1
fi

# Token replacements
sed -i "s/{FL_THEME_BUILDER_VERSION}/${VERSION_SLUG}/g" \
  $WORK_DIR/$SLUG/bb-theme-builder.php \
  $WORK_DIR/$SLUG/classes/class-fl-theme-builder-loader.php \
  $WORK_DIR/$SLUG/includes/updater-config.php

# Debug filter
echo "" >> $WORK_DIR/$SLUG/bb-theme-builder.php
echo "add_filter( 'fl_is_debug', '__return_true' );" >> $WORK_DIR/$SLUG/bb-theme-builder.php

# Zip and upload
cd $WORK_DIR
zip -r ${SLUG}.zip $SLUG
aws s3 cp ${SLUG}.zip \
  s3://${R2_BUCKET}/pr-${PR_NUMBER}/${DEST_PREFIX}/${SLUG}.zip \
  --endpoint-url $R2_ENDPOINT

echo "${SLUG} uploaded to R2 (${DEST_PREFIX})"

rm -rf $WORK_DIR
