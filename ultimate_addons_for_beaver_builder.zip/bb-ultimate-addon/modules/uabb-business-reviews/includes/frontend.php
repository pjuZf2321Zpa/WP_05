<?php
/**
 *  Frontend php file for Business Review module.
 *
 *  @package UABB Business Review file Frontend.php file
 */

$uabb_reviews_output = $module->render();
echo ( ! is_null( $uabb_reviews_output ) ? wp_kses_post( $uabb_reviews_output ) : '' );


