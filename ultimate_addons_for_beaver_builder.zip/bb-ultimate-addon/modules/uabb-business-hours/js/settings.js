(function($){
	FLBuilder.registerModuleHelper('uabb-business-hours', {
		init: function() {

			this._hideDocs();
			
		},
		/**
         * Branding is on hide the Docs Tab.
         *
         * @since 1.14.0
        */
        _hideDocs: function() {
            var form            = $('.fl-builder-settings'),
            branding_selector   = form.find('#fl-field-uabb_helpful_information .uabb-docs-list');
            settings_tab        = form.find('.fl-builder-settings-tabs');
            get_anchor          =  settings_tab.find('a');

            $( get_anchor ).each(function() {

                if ( '#fl-builder-settings-tab-uabb_docs' === $(this) .attr('href') ) {

                    if ( 'yes' === branding_selector.data('branding') ) {
                        if ( $( this ).hasClass( 'fl-active' ) ) {
                            settings_tab.find( 'a' ).not( this ).first().trigger( 'click' );
                        }
                        $( this ).hide();
                    } else {
                        $( this ).css( 'display', '' );
                    }
                }
            });
        }
	});
})(jQuery);