<?php
/**
 *  UABB Model Helper
 *
 *  Helper functions, actions & filter hooks etc.
 *
 *  @package UABB Model Helper
 */

if ( ! class_exists( 'UABB_Model_Helper' ) ) {

	/**
	 * This class initializes UABB Model Helper class
	 *
	 * @class UABB_Model_Helper
	 */
	class UABB_Model_Helper {
		/**
		 * Variable for BB global Settings
		 *
		 * @var string $bb_global_settings
		 */
		public static $bb_global_settings;

		/**
		 * Constructor function that initializes required actions and hooks
		 *
		 * @since 1.0
		 */
		public function __construct() {

			// Initialize BB Global Setting static variable.
			self::$bb_global_settings = FLBuilderModel::get_global_settings();
		}

		/**
		 * Whether the current request is a Beaver Builder context (editor page
		 * load or a builder AJAX request such as render_settings_form).
		 *
		 * Module forms are registered on `init`, before the main query runs, so
		 * FLBuilderModel::is_builder_active() cannot resolve yet — the raw
		 * request markers are checked as a fallback.
		 *
		 * @since 1.37.6.1
		 * @return bool
		 */
		public static function is_builder_context() {
			if ( class_exists( 'FLBuilderModel' ) && FLBuilderModel::is_builder_active() ) {
				return true;
			}
			return isset( $_GET['fl_builder'] ) || isset( $_POST['fl_builder_data'] ); // phpcs:ignore WordPress.Security.NonceVerification -- read-only context check, no data is processed.
		}

		/**
		 * Per-request cache of saved templates, keyed by template type.
		 *
		 * @since 1.37.9
		 * @var array
		 */
		private static $post_templates = array();

		/**
		 * Get Templates based on category
		 *
		 * Saved templates carry their full layout data in post meta, so the
		 * meta cache is never primed here; only the global flag is read, in a
		 * single query. Results are cached for the request because several
		 * modules ask for the same lists on every builder request.
		 *
		 * @param string $type gets the type of the layout.
		 */
		public static function get_post_template( $type = 'layout' ) {
			if ( isset( self::$post_templates[ $type ] ) ) {
				return self::$post_templates[ $type ];
			}

			$posts = get_posts(
				array(
					'post_type'              => 'fl-builder-template',
					'orderby'                => 'title',
					'order'                  => 'ASC',
					'posts_per_page'         => '-1',
					'no_found_rows'          => true,
					'update_post_meta_cache' => false,
					'update_post_term_cache' => false,
					'tax_query'              => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
						array(
							'taxonomy' => 'fl-builder-template-type',
							'field'    => 'slug',
							'terms'    => $type,
						),
					),
				)
			);

			$global_flags = array();

			if ( ! empty( $posts ) ) {
				global $wpdb;

				$post_ids     = wp_list_pluck( $posts, 'ID' );
				$placeholders = implode( ',', array_fill( 0, count( $post_ids ), '%d' ) );

				// Read only the global flag; get_post_meta() would load every meta row, including the layout data.
				$global_flags = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
					$wpdb->prepare(
						"SELECT post_id, meta_value FROM {$wpdb->postmeta} WHERE meta_key = %s AND post_id IN ( {$placeholders} )", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
						array_merge( array( '_fl_builder_template_global' ), $post_ids )
					),
					OBJECT_K
				);
			}

			$templates = array();

			foreach ( $posts as $post ) {

				$templates[] = array(
					'id'     => $post->ID,
					'name'   => $post->post_title,
					'global' => isset( $global_flags[ $post->ID ] ) ? maybe_unserialize( $global_flags[ $post->ID ]->meta_value ) : '',
				);
			}

			self::$post_templates[ $type ] = $templates;

			return $templates;
		}


		/**
		 *  Get - Saved row templates
		 *
		 * @return  $option_array
		 * @since   1.1.0.1
		 */
		public static function get_saved_page_template() {
			$options = array();

			if ( self::is_builder_context() && FLBuilderModel::node_templates_enabled() ) {
				$page_templates = self::get_post_template( 'layout' );

				if ( count( $page_templates ) ) {
					foreach ( $page_templates as $page_template ) {
						$options[ $page_template['id'] ] = $page_template['name'];
					}
				} else {
					$options['no_template'] = 'It seems that, you have not saved any template yet.';
				}
			}
			return $options;
		}

		/**
		 *  Get - Saved row templates
		 *
		 * @return  $option_array
		 * @since   1.1.0.1
		 */
		public static function get_saved_row_template() {
			$options = array();

			if ( self::is_builder_context() && FLBuilderModel::node_templates_enabled() ) {
				$saved_rows = self::get_post_template( 'row' );

				if ( count( $saved_rows ) ) {
					foreach ( $saved_rows as $saved_row ) {
						$options[ $saved_row['id'] ] = $saved_row['name'];
					}
				} else {
					$options['no_template'] = 'It seems that, you have not saved any template yet.';
				}
			}
			return $options;
		}

		/**
		 *  Get - Saved module templates
		 *
		 * @return  $option_array
		 * @since   1.1.0.1
		 */
		public static function get_saved_module_template() {
			$options = array();

			if ( self::is_builder_context() && FLBuilderModel::node_templates_enabled() ) {
				$saved_modules = self::get_post_template( 'module' );

				if ( count( $saved_modules ) ) {
					foreach ( $saved_modules as $saved_module ) {
						$options[ $saved_module['id'] ] = $saved_module['name'];
					}
				} else {
					$options['no_template'] = 'It seems that, you have not saved any template yet.';
				}
			}
			return $options;
		}
	}
	new UABB_Model_Helper();
}
