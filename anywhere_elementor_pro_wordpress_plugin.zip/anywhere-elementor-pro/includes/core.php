<?php

if ( ! function_exists( 'aepro_user_can_view_post' ) ) {
	/**
	 * Whether the current visitor is allowed to see a post's content.
	 *
	 * current_user_can( 'read_post', $id ) is NOT enough on its own: logged-out
	 * visitors have no capabilities at all, so it returns false even for a
	 * published public post. Public statuses are therefore checked first (and
	 * password protection honoured); capabilities only decide the non-public
	 * statuses (private, draft, pending, ...).
	 *
	 * @param int|\WP_Post $post Post object or ID.
	 * @return bool
	 */
	function aepro_user_can_view_post( $post ) {
		$post = get_post( $post );
		if ( ! $post ) {
			return false;
		}

		// Anyone who can edit the post can already see it (covers own
		// private/draft posts and password-protected posts in the editor).
		if ( current_user_can( 'edit_post', $post->ID ) ) {
			return true;
		}

		$status = get_post_status_object( get_post_status( $post ) );
		if ( $status && $status->public ) {
			// Published is not enough for types that are not meant to be viewed
			// (reusable blocks, coupons, ACF field groups, presets, ...).
			return is_post_type_viewable( $post->post_type ) && ! post_password_required( $post );
		}

		return current_user_can( 'read_post', $post->ID );
	}
}

if ( ! function_exists( 'aepro_can_render_template' ) ) {
	/**
	 * Whether an Elementor document picked by ID (shortcode, widget setting,
	 * template meta) may be rendered for the current visitor. Anyone who can
	 * edit a post can put any ID there, so it must be a published template
	 * (DA template or Elementor library item) or a post the visitor could
	 * open anyway. An empty ID never falls back to the current post.
	 *
	 * @param int|string|\WP_Post $template Template post or ID.
	 * @return bool
	 */
	function aepro_can_render_template( $template ) {
		if ( $template instanceof \WP_Post ) {
			$template = $template->ID;
		}

		$template_id = is_numeric( $template ) ? (int) $template : 0;
		$template    = $template_id > 0 ? get_post( $template_id ) : null;

		if ( ! $template ) {
			return false;
		}

		if ( 'publish' === $template->post_status && in_array( $template->post_type, [ 'ae_global_templates', 'elementor_library' ], true ) ) {
			return true;
		}

		return aepro_user_can_view_post( $template );
	}
}

if ( ! function_exists( 'aepro_get_template_content' ) ) {
	/**
	 * Elementor's get_builder_content() for a template ID taken from settings
	 * or meta, or '' when the visitor may not see that document.
	 *
	 * @param int|string $template_id Template ID.
	 * @param bool       $with_css    Whether to print the document's CSS.
	 * @return string
	 */
	function aepro_get_template_content( $template_id, $with_css = false ) {
		if ( ! aepro_can_render_template( $template_id ) ) {
			return '';
		}

		return \Elementor\Plugin::instance()->frontend->get_builder_content( (int) $template_id, $with_css );
	}
}

if ( ! function_exists( 'aepro_is_pro_active' ) ) {
	function aepro_is_pro_active() {
		return (bool) apply_filters( 'aepro/is_pro_active', false );
	}
}

if ( ! function_exists( 'aepro_get_locked_render_modes' ) ) {
	function aepro_get_locked_render_modes() {
		if ( aepro_is_pro_active() ) {
			return [];
		}

		return apply_filters(
			'aepro/locked_render_modes',
			[
				'archive_template',
				'post_type_archive_template',
				'block_layout',
				'404',
				'search',
				'author_template',
				'date_template',
				'acf_repeater_layout',
			]
		);
	}
}

if ( ! function_exists( 'aepro_get_upgrade_url' ) ) {
	function aepro_get_upgrade_url() {
		if ( function_exists( 'wpv_ae' ) ) {
			return wpv_ae()->get_upgrade_url();
		}

		return apply_filters( 'aepro/upgrade_url', 'https://www.wpbuilderaddons.com/' );
	}
}

if ( ! function_exists( 'aepro_enqueue_post_css' ) ) {
	/**
	 * Enqueue the Elementor-generated CSS file for a template / inner layout.
	 *
	 * Widgets that render a nested Elementor template (Post Blocks, Post Blocks
	 * Adv skins, etc.) call this during widget render — which also runs on
	 * `wp_ajax_*` requests for pagination / load-more / filter bars. In an AJAX
	 * (or REST) request `wp_enqueue_scripts` never fires, so Elementor never
	 * registers the `elementor-frontend` style handle and WP emits a
	 * "dependencies that are not registered: elementor-frontend" notice from
	 * Elementor's own Post CSS enqueue. Register Elementor's frontend styles
	 * first so the dependency resolves. On a normal frontend page the handle is
	 * already registered, so this is a no-op there.
	 *
	 * @param int|string $post_id Template / layout post ID whose CSS to enqueue.
	 */
	function aepro_enqueue_post_css( $post_id ) {
		if ( empty( $post_id ) || ! class_exists( '\Elementor\Core\Files\CSS\Post' ) ) {
			return;
		}

		static $frontend_styles_registered = false;

		if (
			! $frontend_styles_registered
			&& ! wp_style_is( 'elementor-frontend', 'registered' )
			&& isset( \Elementor\Plugin::$instance->frontend )
			&& method_exists( \Elementor\Plugin::$instance->frontend, 'register_styles' )
		) {
			\Elementor\Plugin::$instance->frontend->register_styles();
			$frontend_styles_registered = true;
		}

		\Elementor\Core\Files\CSS\Post::create( $post_id )->enqueue();
	}
}

// Composer autoload is used for modules and classes. See composer.json.
