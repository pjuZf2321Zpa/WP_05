<?php

namespace Aepro\Classes;

use Aepro\Frontend;
use Aepro\Template;
use Elementor\Modules\AtomicWidgets\Styles\Atomic_Widget_Styles;
use Elementor\Modules\AtomicWidgets\Styles\Styles_Renderer;
use Elementor\Plugin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Elementor 4 (atomic elements) style support for Dynific templates.
 *
 * Atomic elements are not styled by the classic post CSS file. Elementor only
 * prints their styles (local styles + global classes) for post IDs announced
 * through `elementor/post/render` before its style pass runs. Dynific renders
 * templates with get_builder_content(), which announces nothing, so atomic
 * elements inside block layouts, global templates and shortcodes rendered
 * unstyled.
 *
 * This class:
 *  - announces the template Dynific resolved for the request (single, archive,
 *    search, 404, ...), hook-position templates and shortcode templates in the
 *    queried post content, before Elementor's style pass;
 *  - when any post is announced, announces the Dynific templates its elements
 *    reference (block layouts, ACF repeater/flexible templates, ...),
 *    recursively, so nested layouts are covered;
 *  - reports the same references through `elementor/document/related_posts`
 *    (Elementor 4.2+) so global classes used in them are merged too.
 *
 * Template references are detected generically: any numeric setting that is
 * the ID of an `ae_global_templates` post, plus template shortcodes inside
 * string settings. A false positive only loads extra CSS.
 *
 * In the Elementor editor, Elementor deletes every pregenerated
 * `local-{post}-…` stylesheet from the preview and re-renders styles only for
 * the document being edited, so templates rendered inside it (block layouts
 * in listings, …) lost their styles and fell back to the element defaults
 * (e.g. e-flexbox rows). Their local styles are printed inline instead,
 * scoped to the template wrapper so they also win over the base styles the
 * editor injects later: in <head> on preview load, and next to the markup
 * when the editor re-renders a widget over AJAX.
 */
class AtomicStyles {

	const SHORTCODE_PATTERN = '/\[(?:INSERT_ELEMENTOR|dynific_template)\s[^\]]*\bid\s*=\s*["\']?(\d+)/i';

	private static $_instance = null;

	/** @var array<int,int[]> Post ID => referenced template IDs (per request). */
	private $references = [];

	/** @var array<int,true> Post IDs already announced in this request. */
	private $announced = [];

	/** @var array<int,true> Templates whose editor styles were printed in this request. */
	private $editor_printed = [];

	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	private function __construct() {
		// Elementor 4 atomic elements only; nothing to do on older versions.
		if ( ! class_exists( '\Elementor\Modules\AtomicWidgets\Module' ) ) {
			return;
		}

		add_action( 'elementor/post/render', [ $this, 'announce_referenced_templates' ] );
		add_filter( 'elementor/document/related_posts', [ $this, 'add_related_posts' ], 10, 2 );

		// Elementor collects atomic styles at wp_enqueue_scripts priority 20.
		add_action( 'wp_enqueue_scripts', [ $this, 'announce_request_templates' ], 19 );

		add_action( 'wp_head', [ $this, 'print_preview_template_styles' ], 100 );
		add_action( 'elementor/frontend/before_get_builder_content', [ $this, 'print_rerender_template_styles' ] );
	}

	/**
	 * Announces the templates Dynific will render for the current request.
	 */
	public function announce_request_templates() {
		if ( is_admin() ) {
			return;
		}

		$template_ids = [];

		$template = Template::instance()->get_template();
		if ( ! empty( $template['id'] ) ) {
			$template_ids[] = (int) $template['id'];
		}

		$template_ids = array_merge( $template_ids, array_map( 'intval', Frontend::instance()->get_hook_templates() ) );

		$queried = get_queried_object();
		if ( $queried instanceof \WP_Post && is_singular() ) {
			$template_ids = array_merge( $template_ids, $this->get_shortcode_template_ids( $queried->post_content ) );
		}

		$template_ids = $this->filter_template_ids( $template_ids );
		if ( empty( $template_ids ) ) {
			return;
		}

		foreach ( $template_ids as $template_id ) {
			$this->announce( $template_id );
		}

		// Elementor's style pass already ran (it can run before priority 19,
		// e.g. on posts built with Elementor) and never runs twice: build the
		// atomic styles again so the templates announced above get theirs.
		// Already generated styles are reused, and enqueueing is idempotent.
		if ( did_action( 'elementor/frontend/after_enqueue_post_styles' ) ) {
			do_action( 'elementor/frontend/after_enqueue_post_styles' );
			return;
		}

		// Elementor only runs its <head> style pass on singular pages built
		// with Elementor; elsewhere (archives, non-Elementor posts using a
		// Dynific single template) it would wait for wp_footer. Run it now so
		// the template styles land in <head>. It only ever runs once.
		$frontend = \Elementor\Plugin::$instance->frontend;
		if ( $frontend && method_exists( $frontend, 'enqueue_styles' ) ) {
			add_action( 'wp_enqueue_scripts', [ $frontend, 'enqueue_styles' ], 20 );
		}
	}

	/**
	 * Editor preview load: styles of the templates the edited document renders.
	 */
	public function print_preview_template_styles() {
		if ( ! Plugin::$instance->preview->is_preview_mode() ) {
			return;
		}

		foreach ( $this->get_nested_templates( (int) Plugin::$instance->preview->get_post_id() ) as $template_id ) {
			$this->print_editor_styles( $template_id );
		}
	}

	/**
	 * `elementor/frontend/before_get_builder_content`: when the editor
	 * re-renders a widget over AJAX, its HTML replaces the old markup, so the
	 * styles of each template it renders travel with it. Nested templates go
	 * through here too when they are rendered.
	 *
	 * @param \Elementor\Core\Base\Document $document
	 */
	public function print_rerender_template_styles( $document ) {
		if ( ! wp_doing_ajax() || ! Plugin::$instance->editor->is_edit_mode() || ! $document ) {
			return;
		}

		$template_id = (int) $document->get_main_id();

		if ( $this->filter_template_ids( [ $template_id ] ) ) {
			$this->print_editor_styles( $template_id );
		}
	}

	/**
	 * Templates referenced by a post, recursively, without the post itself
	 * (the editor styles the document being edited live).
	 *
	 * @param int $post_id
	 * @return int[]
	 */
	private function get_nested_templates( $post_id ) {
		$found = [];
		$queue = $this->get_referenced_templates( $post_id );

		while ( $queue ) {
			$template_id = array_shift( $queue );

			if ( $template_id === $post_id || isset( $found[ $template_id ] ) ) {
				continue;
			}

			$found[ $template_id ] = true;
			$queue                 = array_merge( $queue, $this->get_referenced_templates( $template_id ) );
		}

		return array_keys( $found );
	}

	/**
	 * Prints a template's local atomic styles once per request, prefixed with
	 * its wrapper (`.elementor.elementor-{id}`) for higher specificity than the
	 * editor's base styles.
	 *
	 * @param int $template_id
	 */
	private function print_editor_styles( $template_id ) {
		if ( isset( $this->editor_printed[ $template_id ] ) ) {
			return;
		}

		$this->editor_printed[ $template_id ] = true;

		$document = Plugin::$instance->documents->get( $template_id );
		if ( ! $document ) {
			return;
		}

		$styles = [];
		Plugin::$instance->db->iterate_data(
			(array) $document->get_elements_data(),
			function( $element ) use ( &$styles ) {
				if ( ! empty( $element['styles'] ) && is_array( $element['styles'] ) ) {
					$styles = array_merge( $styles, $element['styles'] );
				}
				return $element;
			}
		);

		if ( ! $styles ) {
			return;
		}

		try {
			if ( method_exists( Atomic_Widget_Styles::class, 'get_license_based_filtered_styles' ) ) {
				$styles = Atomic_Widget_Styles::get_license_based_filtered_styles( $styles );
			}

			$css = Styles_Renderer::make(
				Plugin::$instance->breakpoints->get_breakpoints_config(),
				'.elementor.elementor-' . $template_id
			)->render( array_values( $styles ) );
		} catch ( \Throwable $e ) {
			return;
		}

		if ( '' === $css ) {
			return;
		}

		// Values can come from dynamic tags: never let them close the style tag.
		$css = str_replace( '<', '\3C ', $css );

		echo '<style id="aepro-editor-local-' . (int) $template_id . '">' . $css . '</style>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- CSS built by Elementor's renderer; '<' neutralised above.
	}

	/**
	 * `elementor/post/render`: announce templates referenced by that post.
	 *
	 * @param int $post_id
	 */
	public function announce_referenced_templates( $post_id ) {
		$post_id = (int) $post_id;
		if ( $post_id <= 0 ) {
			return;
		}

		$this->announced[ $post_id ] = true;

		foreach ( $this->get_referenced_templates( $post_id ) as $template_id ) {
			$this->announce( $template_id );
		}
	}

	/**
	 * `elementor/document/related_posts`: lets Elementor merge global classes
	 * used inside referenced templates. Elementor resolves it transitively.
	 *
	 * @param array $related
	 * @param int   $post_id
	 * @return array
	 */
	public function add_related_posts( $related, $post_id ) {
		$related = is_array( $related ) ? $related : [];

		return array_values( array_unique( array_merge( $related, $this->get_referenced_templates( (int) $post_id ) ) ) );
	}

	private function announce( $template_id ) {
		if ( isset( $this->announced[ $template_id ] ) ) {
			return;
		}

		// Marks it announced (and recurses into its references) via our own
		// `elementor/post/render` listener.
		do_action( 'elementor/post/render', $template_id );
	}

	/**
	 * @param int $post_id
	 * @return int[]
	 */
	public function get_referenced_templates( $post_id ) {
		if ( isset( $this->references[ $post_id ] ) ) {
			return $this->references[ $post_id ];
		}

		$this->references[ $post_id ] = [];

		$document = \Elementor\Plugin::$instance->documents->get( $post_id );
		if ( ! $document ) {
			return [];
		}

		$elements = $document->get_elements_data();
		if ( empty( $elements ) || ! is_array( $elements ) ) {
			return [];
		}

		$candidates = [];
		\Elementor\Plugin::$instance->db->iterate_data(
			$elements,
			function( $element ) use ( &$candidates ) {
				if ( ! empty( $element['settings'] ) && is_array( $element['settings'] ) ) {
					$this->collect_candidates( $element['settings'], $candidates );
				}
				return $element;
			}
		);

		$template_ids = $this->filter_template_ids( $candidates );

		// A template never needs to announce itself.
		$template_ids = array_values( array_diff( $template_ids, [ $post_id ] ) );

		$this->references[ $post_id ] = $template_ids;

		return $template_ids;
	}

	/**
	 * Collects numeric values and shortcode IDs from (nested) settings.
	 */
	private function collect_candidates( $settings, array &$candidates ) {
		foreach ( $settings as $value ) {
			if ( is_array( $value ) ) {
				$this->collect_candidates( $value, $candidates );
			} elseif ( is_int( $value ) || ( is_string( $value ) && ctype_digit( $value ) ) ) {
				if ( (int) $value > 0 ) {
					$candidates[] = (int) $value;
				}
			} elseif ( is_string( $value ) && false !== stripos( $value, '[' ) ) {
				$candidates = array_merge( $candidates, $this->get_shortcode_template_ids( $value ) );
			}
		}
	}

	/**
	 * @param string $content
	 * @return int[]
	 */
	private function get_shortcode_template_ids( $content ) {
		if ( ! is_string( $content ) || ! preg_match_all( self::SHORTCODE_PATTERN, $content, $matches ) ) {
			return [];
		}

		return array_map( 'intval', $matches[1] );
	}

	/**
	 * Keeps only IDs of published Dynific templates.
	 *
	 * @param int[] $ids
	 * @return int[]
	 */
	private function filter_template_ids( array $ids ) {
		$ids = array_values( array_unique( array_filter( array_map( 'intval', $ids ) ) ) );
		if ( empty( $ids ) ) {
			return [];
		}

		$templates = get_posts(
			[
				'post_type'              => 'ae_global_templates',
				'post_status'            => 'publish',
				'post__in'               => $ids,
				'posts_per_page'         => count( $ids ),
				'fields'                 => 'ids',
				'orderby'                => 'post__in',
				'no_found_rows'          => true,
				'update_post_meta_cache' => false,
				'update_post_term_cache' => false,
				'suppress_filters'       => true,
			]
		);

		return array_map( 'intval', $templates );
	}
}
