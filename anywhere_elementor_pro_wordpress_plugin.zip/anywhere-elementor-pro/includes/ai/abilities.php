<?php

namespace Aepro\Ai;

use Aepro\Admin\TemplateSettingsSchema;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers Dynific AI tools with the WordPress Abilities API.
 * Angie and other MCP clients discover them automatically.
 */
class Abilities {

	const CATEGORY = 'dynific';

	private static $_instance = null;

	/**
	 * Ability names registered in this request.
	 *
	 * @var string[]
	 */
	private $registered = [];

	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	private function __construct() {
		add_action( 'wp_abilities_api_categories_init', [ $this, 'register_category' ] );
		add_action( 'wp_abilities_api_init', [ $this, 'register_abilities' ] );

		// Also list them on Elementor's own MCP server.
		add_filter( 'elementor/mcp/server/tools', [ $this, 'add_to_elementor_mcp' ] );
	}

	public function register_category() {
		wp_register_ability_category(
			self::CATEGORY,
			[
				'label'       => __( 'Dynific Addons', 'ae-pro' ),
				'description' => __( 'Create Dynific templates (block layouts, single, archive) with dynamic widgets.', 'ae-pro' ),
			]
		);
	}

	public function register_abilities() {
		$read_only = [
			'readonly'    => true,
			'destructive' => false,
			'idempotent'  => true,
		];
		$can_read  = [ WidgetCatalog::class, 'current_user_can_access' ];

		$this->register(
			'dynific/get-guide',
			[
				'label'               => __( 'Dynific: how to build templates', 'ae-pro' ),
				'description'         => 'READ FIRST before creating any Dynific template, block layout, single post template or archive template. Returns the workflow and rules.',
				'input_schema'        => $this->object_schema(),
				'execute_callback'    => [ $this, 'execute_get_guide' ],
				'permission_callback' => $can_read,
			],
			$read_only
		);

		$this->register(
			'dynific/list-template-types',
			[
				'label'               => __( 'Dynific: list template types', 'ae-pro' ),
				'description'         => 'Lists Dynific template types (block_layout, single, taxonomy_archive …) with the fields each one needs, Pro lock status, and valid post types / page layouts.',
				'input_schema'        => $this->object_schema(),
				'execute_callback'    => [ $this, 'execute_list_template_types' ],
				'permission_callback' => $can_read,
			],
			$read_only
		);

		$this->register(
			'dynific/list-sample-posts',
			[
				'label'               => __( 'Dynific: list sample posts', 'ae-pro' ),
				'description'         => 'Lists recent published posts of a post type, to use as preview_post_id so the template shows real content in the editor.',
				'input_schema'        => $this->object_schema(
					[
						'post_type' => [
							'type'    => 'string',
							'default' => 'post',
						],
						'search'    => [ 'type' => 'string' ],
						'limit'     => [
							'type'    => 'integer',
							'default' => 10,
							'minimum' => 1,
							'maximum' => 50,
						],
					]
				),
				'execute_callback'    => [ $this, 'execute_list_sample_posts' ],
				'permission_callback' => $can_read,
			],
			$read_only
		);

		$this->register(
			'dynific/list-widgets',
			[
				'label'               => __( 'Dynific: list widgets', 'ae-pro' ),
				'description'         => 'Lists Dynific dynamic widgets (ae-post-title, ae-post-image, ae-post-meta …). They render the CURRENT post\'s data inside Dynific templates.',
				'input_schema'        => $this->object_schema(),
				'execute_callback'    => [ $this, 'execute_list_widgets' ],
				'permission_callback' => $can_read,
			],
			$read_only
		);

		$this->register(
			'dynific/get-widget-schema',
			[
				'label'               => __( 'Dynific: get widget schema', 'ae-pro' ),
				'description'         => 'Exact setting keys, types, options and defaults of one Dynific widget. Use these keys verbatim in dynific/set-template-content. Default tab=content; use tab=style for colours/typography and tab=advanced for _margin, _padding, _css_classes. Large tabs return a compact index; then pass keys=[…] for full definitions.',
				'input_schema'        => $this->object_schema(
					[
						'widget' => [
							'type'        => 'string',
							'description' => 'Widget name from dynific/list-widgets, e.g. ae-post-title',
						],
						'tab'    => [
							'type'    => 'string',
							'enum'    => [ 'content', 'style', 'advanced', 'all' ],
							'default' => 'content',
						],
						'keys'   => [
							'type'        => 'array',
							'items'       => [ 'type' => 'string' ],
							'maxItems'    => 50,
							'description' => 'Only these setting keys, with full definitions (e.g. ["_margin","_padding"])',
						],
					],
					[ 'widget' ]
				),
				'execute_callback'    => [ $this, 'execute_get_widget_schema' ],
				'permission_callback' => $can_read,
			],
			$read_only
		);

		$this->register(
			'dynific/create-template',
			[
				'label'               => __( 'Dynific: create template', 'ae-pro' ),
				'description'         => 'Creates a Dynific template with its settings (render mode, post type, preview post, page layout). Block layouts and ACF repeater layouts are PUBLISHED by default so listing widgets can use them at once (they do not change the site on their own); all other types are drafts unless status=publish (only when the user asked). Returns post_id, status and edit_url. Then add widgets with dynific/set-template-content.',
				'input_schema'        => $this->object_schema(
					[
						'template_type'   => [
							'type'        => 'string',
							'description' => 'Key from dynific/list-template-types, e.g. block_layout',
						],
						'template_name'   => [ 'type' => 'string' ],
						'rule_post_type'  => [
							'type'    => 'string',
							'default' => 'post',
						],
						'preview_post_id' => [ 'type' => 'integer' ],
						'page_layout'     => [
							'type'        => 'string',
							'description' => 'Key from page_layouts in dynific/list-template-types; empty for default',
							'default'     => '',
						],
						'rule_taxonomy'   => [ 'type' => 'string' ],
						'preview_term'    => [ 'type' => 'integer' ],
						'apply_global'    => [ 'type' => 'boolean' ],
						'status'          => [
							'type'        => 'string',
							'enum'        => TemplateService::STATUSES,
							'description' => 'Omit for the default: publish for block_layout / acf_blocks, draft for the rest',
						],
					],
					[ 'template_type', 'template_name' ]
				),
				'execute_callback'    => [ $this, 'execute_create_template' ],
				'permission_callback' => [ $this, 'can_create_template' ],
			],
			[
				'readonly'    => false,
				'destructive' => false,
				'idempotent'  => false,
			]
		);

		$this->register(
			'dynific/get-template',
			[
				'label'               => __( 'Dynific: get template settings', 'ae-pro' ),
				'description'         => 'Returns a Dynific template\'s title, status (draft/publish), type and settings (rule_post_type, apply_global, preview post, page layout …) plus notes on whether it is live and which other template may win.',
				'input_schema'        => $this->object_schema(
					[
						'template_id' => [ 'type' => 'integer' ],
					],
					[ 'template_id' ]
				),
				'execute_callback'    => [ $this, 'execute_get_template' ],
				'permission_callback' => [ $this, 'can_edit_template' ],
			],
			$read_only
		);

		$this->register(
			'dynific/update-template',
			[
				'label'               => __( 'Dynific: update template settings or publish', 'ae-pro' ),
				'description'         => 'Changes a SAVED Dynific template: status (publish/draft/pending/private), title, and settings such as rule_post_type (which post type it is for) and apply_global (use it for ALL posts of that type). Send only what changes. Publishing a template with apply_global changes the live site – ask the user first. NEVER use this to publish or save a template that is open in the Elementor editor (the user is editing it): it would publish the old saved version without the editor changes – use dynific-editor-save-document there.',
				'input_schema'        => $this->object_schema(
					[
						'template_id'     => [ 'type' => 'integer' ],
						'title'           => [ 'type' => 'string' ],
						'status'          => [
							'type' => 'string',
							'enum' => TemplateService::STATUSES,
						],
						'template_type'   => [
							'type'        => 'string',
							'description' => 'Change the type (key from dynific/list-template-types). Rarely needed.',
						],
						'rule_post_type'  => [
							'type'        => 'string',
							'description' => 'Post type slug the template is for, e.g. movie',
						],
						'apply_global'    => [
							'type'        => 'boolean',
							'description' => 'true = default template for every post of rule_post_type (single) or every term of rule_taxonomy (archive)',
						],
						'preview_post_id' => [ 'type' => 'integer' ],
						'page_layout'     => [ 'type' => 'string' ],
						'rule_taxonomy'   => [ 'type' => 'string' ],
						'preview_term'    => [ 'type' => 'integer' ],
					],
					[ 'template_id' ]
				),
				'execute_callback'    => [ $this, 'execute_update_template' ],
				'permission_callback' => [ $this, 'can_edit_template' ],
			],
			[
				'readonly'    => false,
				'destructive' => false,
				'idempotent'  => true,
			]
		);

		$this->register(
			'dynific/assign-template-to-post',
			[
				'label'               => __( 'Dynific: assign template to specific posts', 'ae-pro' ),
				'description'         => 'Per-post override, same as the "Select Layout" box on the post edit screen. action=assign uses a PUBLISHED single template (template_type=single) on these posts only; use_global returns them to the global template; disable shows no Dynific template on them. For ALL posts of a type use dynific/update-template with rule_post_type + apply_global=true instead.',
				'input_schema'        => $this->object_schema(
					[
						'post_ids'    => [
							'type'     => 'array',
							'items'    => [ 'type' => 'integer' ],
							'minItems' => 1,
							'maxItems' => TemplateService::MAX_ASSIGN_POSTS,
						],
						'action'      => [
							'type'    => 'string',
							'enum'    => [ 'assign', 'use_global', 'disable' ],
							'default' => 'assign',
						],
						'template_id' => [
							'type'        => 'integer',
							'description' => 'Required for action=assign',
						],
					],
					[ 'post_ids' ]
				),
				'execute_callback'    => [ $this, 'execute_assign_template_to_post' ],
				'permission_callback' => $can_read,
			],
			[
				'readonly'    => false,
				'destructive' => false,
				'idempotent'  => true,
			]
		);

		$this->register(
			'dynific/get-template-content',
			[
				'label'               => __( 'Dynific: get template content', 'ae-pro' ),
				'description'         => 'Returns the saved element tree of a Dynific template (element ids, widget types, settings). Use it before changing a template that is NOT open in the Elementor editor.',
				'input_schema'        => $this->object_schema(
					[
						'template_id' => [ 'type' => 'integer' ],
					],
					[ 'template_id' ]
				),
				'execute_callback'    => [ $this, 'execute_get_template_content' ],
				'permission_callback' => [ $this, 'can_edit_template' ],
			],
			$read_only
		);

		$this->register(
			'dynific/set-template-content',
			[
				'label'               => __( 'Dynific: set template content', 'ae-pro' ),
				'description'         => 'Writes Dynific widgets into a SAVED Dynific template as one vertical stack (do not use while it is open in the Elementor editor). For columns, rows or any other structure use Elementor\'s elementor/build-composition instead. mode=replace overwrites existing content; append adds below. Setting keys, values and ACF fields are validated; nothing is saved if anything is invalid.',
				'input_schema'        => $this->object_schema(
					[
						'template_id' => [ 'type' => 'integer' ],
						'mode'        => [
							'type'    => 'string',
							'enum'    => [ 'replace', 'append' ],
							'default' => 'replace',
						],
						'widgets'     => [
							'type'     => 'array',
							'minItems' => 1,
							'maxItems' => ContentBuilder::MAX_WIDGETS,
							'items'    => [
								'type'       => 'object',
								'properties' => [
									'widget'   => [ 'type' => 'string' ],
									'settings' => [ 'type' => 'object' ],
								],
								'required'   => [ 'widget' ],
							],
						],
					],
					[ 'template_id', 'widgets' ]
				),
				'execute_callback'    => [ $this, 'execute_set_template_content' ],
				'permission_callback' => [ $this, 'can_edit_template' ],
			],
			[
				'readonly'    => false,
				'destructive' => true,
				'idempotent'  => false,
			]
		);

		// Post Blocks is a Pro widget.
		if ( aepro_is_pro_active() ) {
			$this->register(
				'dynific/add-post-blocks-to-page',
				[
					'label'               => __( 'Dynific: add Post Blocks to a page', 'ae-pro' ),
					'description'         => 'Appends a Post Blocks widget (ae-post-blocks) that lists posts using a PUBLISHED Dynific block layout to an Elementor page. Published pages need allow_published=true, only after the user confirms. Extra settings are validated against dynific/get-widget-schema for ae-post-blocks. If the page is open in the Elementor editor, add the widget there with dynific-editor-add-widgets instead.',
					'input_schema'        => $this->object_schema(
						[
							'page_id'         => [ 'type' => 'integer' ],
							'layout_id'       => [
								'type'        => 'integer',
								'description' => 'Block layout template ID (template_type=block_layout)',
							],
							'post_type'       => [
								'type'        => 'string',
								'description' => 'Posts to list. Defaults to the layout\'s post type.',
							],
							'settings'        => [ 'type' => 'object' ],
							'allow_published' => [
								'type'    => 'boolean',
								'default' => false,
							],
						],
						[ 'page_id', 'layout_id' ]
					),
					'execute_callback'    => [ $this, 'execute_add_post_blocks_to_page' ],
					'permission_callback' => [ $this, 'can_edit_page' ],
				],
				[
					'readonly'    => false,
					'destructive' => false,
					'idempotent'  => false,
				]
			);
		}

		if ( function_exists( 'acf_get_field_groups' ) ) {
			$this->register(
				'dynific/list-acf-fields',
				[
					'label'               => __( 'Dynific: list ACF fields', 'ae-pro' ),
					'description'         => 'Lists ACF field groups and their fields (name, type, sub fields). Each field has "use": the exact Dynific widget and settings that display it – add that widget with those settings. Call it BEFORE adding any ACF widget.',
					'input_schema'        => $this->object_schema(
						[
							'template_id' => [
								'type'        => 'integer',
								'description' => 'Only fields for the post type of this Dynific template',
							],
							'post_type'   => [
								'type'        => 'string',
								'description' => 'Only groups shown on this post type',
							],
							'field_type' => [
								'type'        => 'string',
								'description' => 'Only fields of this ACF type, e.g. repeater, gallery, text',
							],
						]
					),
					'execute_callback'    => [ $this, 'execute_list_acf_fields' ],
					'permission_callback' => $can_read,
				],
				$read_only
			);
		}
	}

	/* ---------- Permission callbacks ---------- */

	public function can_create_template( $input = null ) {
		return WidgetCatalog::current_user_can_access( $input ) && current_user_can( TemplateService::get_create_capability() );
	}

	public function can_edit_template( $input = null ) {
		$id = is_array( $input ) && isset( $input['template_id'] ) ? absint( $input['template_id'] ) : 0;

		return WidgetCatalog::current_user_can_access( $input ) && $id && current_user_can( 'edit_post', $id );
	}

	public function can_edit_page( $input = null ) {
		$id = is_array( $input ) && isset( $input['page_id'] ) ? absint( $input['page_id'] ) : 0;

		return WidgetCatalog::current_user_can_access( $input ) && $id && current_user_can( 'edit_post', $id );
	}

	/* ---------- Execute callbacks ---------- */

	public function execute_get_guide() {
		return [ 'guide' => self::get_guide_text() ];
	}

	/**
	 * Workflow + rules for AI clients. Shared by dynific/get-guide and the Angie editor server instructions.
	 *
	 * @return string
	 */
	public static function get_guide_text() {
		$lines = [
			'Dynific templates are posts of type ae_global_templates, edited with Elementor.',
			'Block Layout (template_type=block_layout) = how ONE post looks inside a grid/list; the Post Blocks widget (ae-post-blocks) repeats it for every post.',
			'Workflow for a NEW template:',
			'1. dynific/list-template-types → pick the type, note required_fields and is_locked (locked = needs Pro, do not use).',
			'2. dynific/list-sample-posts for the rule_post_type → choose a post WITH a thumbnail as preview_post_id.',
			'3. dynific/create-template. Block layouts are published straight away (safe: they only show inside a listing widget). Single, archive and other types are drafts unless the user asked to publish (status=publish).',
			'4. dynific/list-widgets, then dynific/get-widget-schema for every widget you will use.',
			'5. dynific/set-template-content with the widgets in visual order, e.g. ae-post-image → ae-post-title → ae-post-meta.',
			'6. Give the user the edit_url to review. Publish a draft template only when the user asks (step below).',
			'CHANGING an existing template:',
			'- If the template is OPEN in the Elementor editor, use the dynific-editor tools (get-open-document, add-widgets, update-widget, move-element, remove-element, save-document). They change the open editor live. Never call dynific/set-template-content for a template that is open in the editor – the editor would overwrite it on the next save.',
			'- Otherwise read it with dynific/get-template-content, then write it with dynific/set-template-content (mode=replace sends the full list).',
			'- The same editor tools work on ANY page or post open in Elementor, not only templates: dynific-editor-add-widgets adds any Dynific widget there, including listings (ae-post-blocks, ae-post-blocks-adv, ae-portfolio …) that show a block layout.',
			'PUBLISHING and WHERE a template applies:',
			'- Check the current state with dynific/get-template (status, settings, notes).',
			'- When the user is in the Elementor editor and says publish, save or update: ALWAYS dynific-editor-save-document (it saves the live changes, then publishes). NEVER dynific/update-template for that – it only changes the status and the page shows the old saved (often empty) content. If the editor tool is not available, ask the user to click Publish/Update.',
			'- Template NOT open in the editor: dynific/update-template status=publish.',
			'- All posts of a post type (e.g. every movie): dynific/update-template with template_type single, rule_post_type=movie, apply_global=true, status=publish. Read its notes – another global template for the same post type may win.',
			'- Only some posts: publish the single template, then dynific/assign-template-to-post with post_ids (action=use_global undoes it).',
			'- Taxonomy archives: rule_taxonomy + apply_global=true. Block layouts never apply by themselves; they are shown by listing widgets (see below).',
			'- Publishing or applying a template changes the live site: confirm with the user first, and never publish without being asked.',
			'Rules: Dynific widgets show the current post\'s data automatically – never put static titles or text in them.',
			'Use only setting keys from get-widget-schema; omit settings to keep defaults.',
			'Settings that take a template or block layout ID (template, layout, alt_template, …) need a PUBLISHED template; a draft shows nothing to visitors.',
			'Prefer Dynific widgets over core Heading/Image widgets inside Dynific templates.',
			'Elementor\'s tools do not check Dynific widget settings: when you place Dynific widgets with elementor/build-composition, use exact keys from dynific/get-widget-schema and, for ACF widgets, the field NAME from dynific/list-acf-fields "use" (never the field key) – otherwise the widget shows nothing.',
		];

		$lines = array_merge( $lines, self::get_layout_lines() );
		$lines = array_merge( $lines, self::get_widget_map_lines() );

		if ( function_exists( 'acf_get_field_groups' ) ) {
			$lines[] = 'ACF and custom-field widgets show NOTHING without their field. Never add ae-acf-fields-v2, ae-acf-gallery, ae-acf-repeater, ae-acf-flexible-content, ae-cf-google-map or ae-custom-field without it.';
			$lines[] = 'To pick the field: call dynific/list-acf-fields (pass template_id) and add the widget with the settings in the field\'s "use". If the user\'s words match exactly one field, use it. If several fields could match (e.g. "the date" with release_date and published_date) or none does, ASK the user which field to show before adding anything.';
			$lines[] = 'Choose a preview post that has a value for the field, so it shows in the editor (dynific/list-sample-posts).';
		}

		if ( aepro_is_pro_active() ) {
			$lines[] = 'To show a block layout on a page: if the page is open in the Elementor editor, call dynific-editor-add-widgets with {widget:"ae-post-blocks", settings:{template:"<layout id>", ae_post_type:"<post type>"}}; otherwise call dynific/add-post-blocks-to-page. Ask the user before changing a published page.';
		}

		return implode( "\n", $lines );
	}

	/**
	 * Structure (columns, rows, boxes) is Elementor's job: its build-composition, manage-elements
	 * and publish-document tools. The guide only explains how Dynific widgets fit into them.
	 *
	 * @return string[]
	 */
	private static function get_layout_lines() {
		if ( ! CompositionService::is_available() ) {
			return [
				'LAYOUTS: Elementor\'s structure tools (elementor/build-composition) need Elementor 4\'s editor, which is off on this site. The dynific tools add widgets as one stack; for columns ask the user to arrange them in the editor, then fill boxes with dynific-editor-add-widgets parent_id.',
			];
		}

		return [
			'LAYOUTS / STRUCTURE (columns, rows, any arrangement) are built by Elementor\'s own tools: elementor/build-composition to create, elementor/manage-elements to change, elementor/publish-document (or dynific/update-template status=publish) to make it live – only when the user asks.',
			'- In xml_structure use Elementor boxes (e-flexbox = children side by side or stacked, e-div-block = a column / box, e-grid) and Dynific widgets by name, e.g. <ae-post-image configuration-id="img"></ae-post-image>. Sizes and spacing go in style as CSS, e.g. {"left": "width: 40%;"}.',
			'- Example (image left 40%, details right 60%): xml_structure <e-flexbox configuration-id="row"><e-div-block configuration-id="left"><ae-post-image configuration-id="img"></ae-post-image></e-div-block><e-div-block configuration-id="right"><ae-post-title configuration-id="title"></ae-post-title><ae-acf-fields-v2 configuration-id="rating"></ae-acf-fields-v2><ae-acf-fields-v2 configuration-id="duration"></ae-acf-fields-v2></e-div-block></e-flexbox>; element_config {"rating": {"field_name": "rating", "field_type": "number"}, "duration": {"field_name": "duration", "field_type": "text"}}; style {"row": "flex-direction: row; gap: 20px;", "left": "width: 40%;", "right": "width: 60%;"}.',
			'- Build structure while the document is NOT open in the Elementor editor: Elementor saves it as a staged draft, an open editor does not show it and its auto-save overwrites it. If it is open, ask the user to save and close (or reload) the editor first.',
			'- Inside the open editor, Dynific widgets can still be added into an existing box with dynific-editor-add-widgets parent_id=<box id>, and moved with dynific-editor-move-element.',
		];
	}

	/**
	 * "Need → widget" map with each widget's data sources and setting keys.
	 * Only widgets registered on this site (enabled, licensed, integration active) are listed.
	 *
	 * @return string[]
	 */
	private static function get_widget_map_lines() {
		$groups = [
			'POST DATA (reads the current post: the preview post in the editor, each post inside a block layout):' => [
				'ae-post-title'      => 'post title. title_type=post_title (current post) or archive_title (current archive/term title, for archive templates). use_link=1 links to the post; title_tag h1–h6/div/span; strip_title=yes + strip_mode (word|letter) + strip_size + strip_append to shorten.',
				'ae-post-image'      => 'featured image of the current post. image_size, enable_image_ratio + image_ratio, links_to (""|post|media), open_lightbox, fallback_image (shown when the post has no thumbnail), show_overlay (hover|always|never).',
				'ae-post-meta'       => 'meta line: switch parts on/off with show_date, show_author, show_category, show_tags, show_comment (each has *_label, *_icon, *_order, disable_*_link). date_type published|modified, date_format; layout_mode horizontal|vertical; only_parent_term for categories.',
				'ae-post-content'    => 'body text. content_type=post_content (current post; show_excerpt=1 + excerpt_size for an excerpt, enable_unfold for "read more" folding) or term_content (term description on archive templates).',
				'ae-post-readmore'   => '"Read more" button linking to the current post (read_more_text, icon).',
				'ae-author'          => 'author of the current post – ONE value per widget: render_data avatar | first_name | last_name | first_last | nickname | description (bio). An author box = several ae-author widgets. add_link none|author (author archive)|post.',
				'ae-post-navigation' => 'previous / next post links (post_title=1 shows their titles; layout_mode layout-1|layout-2). Single post templates only.',
				'ae-post-comments'   => 'comments list + form of the current post (Beta). Single post templates only.',
				'ae-taxonomy'        => 'terms of the CURRENT post for one taxonomy (ae_taxonomy = taxonomy slug), e.g. category badges or tag list. tax_label, tax_separator, tax_vertical, disable_link.',
			],
			'CUSTOM FIELDS (any post meta, no ACF needed):' => [
				'ae-custom-field'     => 'value of a post meta key of the current post: custom-field = meta key (REQUIRED – ask the user if you do not know it). cf_type sets how it renders: text | html | link (link_type default|email|tel) | image | video (youtube|vimeo) | audio | oembed | date. cf_label adds a label.',
				'ae-tax-custom-field' => 'term meta value: source=current_archive (the archive term) or current_post (terms of the current post, pick ae_post_taxonomy). Same cf_type list as ae-custom-field.',
				'ae-cf-google-map'    => 'map for the current post: field_type=acf_google_map (ACF Google Map field) or custom_fields (lat/lng stored in custom fields).',
			],
			'ACF (call dynific/list-acf-fields first; use the field "name"):' => [
				'ae-acf-fields-v2'        => 'REQUIRED widget for any single ACF field – never use the legacy ae-acf for new work. field_name = ACF field name; field_type must match the ACF type: text | textarea | wysiwyg | number | date | select | checkbox | radio | button_group | true_false | url | file | email | image | taxonomy | post_object | relationship. source: post (current post) | term (current archive term) | user (current author) | option (ACF options page). Sub fields: is_sub_field=repeater (repeater_field + repeater_sub_field) or group (group_field + group_sub_field). Links: links_to ""|post|static|custom_field. fallback_type text|template|image when empty.',
				'ae-acf-gallery'          => 'ACF Gallery field. Skin via _skin: grid | carousel | smart_grid | justified; the field name key is prefixed by the skin: grid_field_name, carousel_field_name, smart_grid_field_name, justified_field_name.',
				'ae-acf-repeater'         => 'ACF Repeater rows. acf_repeater_field_name = repeater name. _skin "" (default: each row rendered with a block layout from template, layout_mode grid|carousel|smart_grid|checker_board) | tabs | accordion | list.',
				'ae-acf-flexible-content' => 'ACF Flexible Content field (flexible_content = field name); each layout rendered as grid/list or carousel (_skin grid|carousel).',
			],
			'LISTINGS (on pages or archive templates; they repeat a Block Layout per item):' => [
				'ae-post-blocks'     => 'posts grid/list using a block layout: template = block layout ID; ae_post_type = a post type slug | current_loop (posts of the current archive – use on archive templates) | ae_by_id (manual, ae_post_ids) | related (same terms as current post, related_by + related_match_with) | relation (ACF relationship field) | post_object (ACF post object field). Place it with dynific-editor-add-widgets when the page is open in the editor, otherwise with dynific/add-post-blocks-to-page.',
				'ae-post-blocks-adv' => 'advanced posts listing with skins grid (default|list|smart-grid|checker-board) | carousel | accordion, filters, load more/infinite scroll. layout = block layout ID; source = post type | current_loop | manual_selection | related | relation | post_object | ae_preset (saved Query Preset, ae_preset_query_id).',
				'ae-portfolio'       => 'filterable portfolio grid (filter bar by filter_taxonomy) using a block layout (template); ae_post_type = post type.',
				'ae-taxonomy-blocks' => 'grid/carousel of terms: ae_taxonomy = taxonomy slug or child_of_current; _skin classic | card | list | term_post_loop (each term + its posts with a block layout).',
				'ae-dynamic-map'     => 'Google map of locations: map_source current_post | post_query (many posts) | post_repeater (ACF repeater rows); field_type acf_map_field | custom_field.',
			],
			'OTHER:' => [
				'ae-searchform' => 'search form (input_placeholder_text, button_text, form_align).',
				'ae-trigger'    => 'button/icon that triggers actions such as opening an off-canvas or popup (_skin style1|style2).',
			],
		];

		$available = array_flip( wp_list_pluck( WidgetCatalog::get_widgets(), 'name' ) );
		$lines     = [
			'WIDGET MAP (need -> Dynific widget). Inside Dynific templates use these FIRST; never core Heading/Image/Text with static content. Exact keys and options: dynific/get-widget-schema.',
		];

		foreach ( $groups as $heading => $widgets ) {
			$items = [];

			foreach ( $widgets as $name => $text ) {
				if ( isset( $available[ $name ] ) ) {
					$items[] = '- ' . $name . ': ' . $text;
				}
			}

			if ( $items ) {
				$lines[] = $heading;
				$lines   = array_merge( $lines, $items );
			}
		}

		if ( isset( $available['ae-acf'] ) ) {
			$lines[] = 'Legacy: ae-acf exists only for old templates – always build with ae-acf-fields-v2.';
		}

		return $lines;
	}

	public function execute_list_template_types() {
		$types = [];

		foreach ( TemplateSettingsSchema::get_template_type_options() as $key => $option ) {
			$types[] = [
				'template_type'   => $key,
				'label'           => WidgetCatalog::clean( $option['label'] ),
				'description'     => WidgetCatalog::clean( $option['description'] ),
				'render_mode'     => $option['render_mode'],
				'required_fields' => array_keys( $option['fields'] ),
				'is_locked'       => ! aepro_is_pro_active() && ! in_array( $option['render_mode'], TemplateService::FREE_RENDER_MODES, true ),
			];
		}

		return [
			'template_types' => $types,
			'post_types'     => $this->clean_choices( TemplateSettingsSchema::get_post_type_choices() ),
			'page_layouts'   => $this->clean_choices( TemplateSettingsSchema::get_page_layout_choices() ),
			'is_pro'         => aepro_is_pro_active(),
		];
	}

	public function execute_list_sample_posts( $input = [] ) {
		$input     = (array) $input;
		$post_type = TemplateSettingsSchema::sanitize_post_type( isset( $input['post_type'] ) ? $input['post_type'] : 'post', 'post' );
		$limit     = isset( $input['limit'] ) ? absint( $input['limit'] ) : 10;

		$posts = get_posts(
			[
				'post_type'        => $post_type,
				'post_status'      => 'publish',
				'posts_per_page'   => min( 50, max( 1, $limit ) ), // phpcs:ignore WordPress.WP.PostsPerPage.posts_per_page_posts_per_page -- Capped at 50.
				's'                => isset( $input['search'] ) ? sanitize_text_field( $input['search'] ) : '',
				'no_found_rows'    => true,
				'suppress_filters' => false,
			]
		);

		$items = [];

		foreach ( $posts as $post ) {
			$items[] = [
				'id'            => $post->ID,
				'title'         => WidgetCatalog::clean( get_the_title( $post ) ),
				'has_thumbnail' => has_post_thumbnail( $post ),
			];
		}

		return [
			'post_type' => $post_type,
			'posts'     => $items,
		];
	}

	public function execute_list_widgets() {
		return [ 'widgets' => WidgetCatalog::get_widgets() ];
	}

	public function execute_get_widget_schema( $input = [] ) {
		$input = (array) $input;

		return WidgetCatalog::get_widget_schema(
			isset( $input['widget'] ) ? (string) $input['widget'] : '',
			isset( $input['tab'] ) ? (string) $input['tab'] : 'content',
			isset( $input['keys'] ) ? array_map( 'strval', (array) $input['keys'] ) : []
		);
	}

	public function execute_create_template( $input = [] ) {
		return TemplateService::create( (array) $input, true );
	}

	public function execute_get_template( $input = [] ) {
		$input = (array) $input;

		return TemplateService::get_settings( isset( $input['template_id'] ) ? $input['template_id'] : 0 );
	}

	public function execute_update_template( $input = [] ) {
		$input = (array) $input;

		return TemplateService::update( isset( $input['template_id'] ) ? $input['template_id'] : 0, $input );
	}

	public function execute_assign_template_to_post( $input = [] ) {
		return TemplateService::assign_to_posts( (array) $input );
	}

	public function execute_get_template_content( $input = [] ) {
		$input = (array) $input;

		return ContentBuilder::get_content( isset( $input['template_id'] ) ? $input['template_id'] : 0 );
	}

	public function execute_set_template_content( $input = [] ) {
		$input = (array) $input;

		return ContentBuilder::set_content(
			isset( $input['template_id'] ) ? $input['template_id'] : 0,
			isset( $input['widgets'] ) ? (array) $input['widgets'] : [],
			isset( $input['mode'] ) ? (string) $input['mode'] : 'replace'
		);
	}

	public function execute_add_post_blocks_to_page( $input = [] ) {
		return ContentBuilder::add_post_blocks_to_page( (array) $input );
	}

	public function execute_list_acf_fields( $input = [] ) {
		$input      = (array) $input;
		$post_type  = isset( $input['post_type'] ) ? sanitize_key( $input['post_type'] ) : '';
		$field_type = isset( $input['field_type'] ) ? sanitize_key( $input['field_type'] ) : '';

		if ( ! $post_type && ! empty( $input['template_id'] ) ) {
			$template_id = absint( $input['template_id'] );

			if ( TemplateService::POST_TYPE === get_post_type( $template_id ) && current_user_can( 'edit_post', $template_id ) ) {
				$post_type = sanitize_key( (string) get_post_meta( $template_id, 'ae_rule_post_type', true ) );
			}
		}

		$groups = [];

		foreach ( acf_get_field_groups( $post_type ? [ 'post_type' => $post_type ] : [] ) as $group ) {
			$fields = [];

			foreach ( (array) acf_get_fields( $group ) as $field ) {
				if ( $field_type && $field_type !== $field['type'] ) {
					continue;
				}
				$fields[] = $this->describe_acf_field( $field, true );
			}

			if ( $fields ) {
				$groups[] = [
					'title'  => WidgetCatalog::clean( $group['title'] ),
					'key'    => $group['key'],
					'fields' => $fields,
				];
			}
		}

		return [
			'post_type'    => $post_type,
			'field_groups' => $groups,
		];
	}

	/* ---------- Helpers ---------- */

	public function add_to_elementor_mcp( $slugs ) {
		return array_values( array_unique( array_merge( (array) $slugs, $this->registered ) ) );
	}

	private function register( $name, array $args, array $annotations ) {
		$args['category']      = self::CATEGORY;
		$args['output_schema'] = isset( $args['output_schema'] ) ? $args['output_schema'] : [ 'type' => 'object' ];
		$args['meta']          = [
			'show_in_rest' => true,
			'annotations'  => $annotations,
			'mcp'          => [
				'public' => true,
				'type'   => 'tool',
			],
		];

		if ( wp_register_ability( $name, $args ) ) {
			$this->registered[] = $name;
		}
	}

	/**
	 * Object input schema. The empty default lets read tools run without any input.
	 */
	private function object_schema( array $properties = [], array $required = [] ) {
		$schema = [
			'type'                 => 'object',
			'default'              => new \stdClass(),
			'additionalProperties' => false,
		];

		if ( $properties ) {
			$schema['properties'] = $properties;
		}

		if ( $required ) {
			$schema['required'] = $required;
		}

		return $schema;
	}

	private function clean_choices( $choices ) {
		$clean = [];

		foreach ( (array) $choices as $key => $label ) {
			$clean[ $key ] = WidgetCatalog::clean( is_array( $label ) && isset( $label['label'] ) ? $label['label'] : $label );
		}

		return $clean;
	}

	private function describe_acf_field( array $field, $with_children ) {
		$item = [
			'name'  => $field['name'],
			'label' => WidgetCatalog::clean( $field['label'] ),
			'type'  => $field['type'],
		];

		if ( ! $with_children ) {
			return $item;
		}

		$item['use'] = AcfFieldRules::get_usage( $field );

		if ( ! empty( $field['sub_fields'] ) && is_array( $field['sub_fields'] ) ) {
			foreach ( $field['sub_fields'] as $sub_field ) {
				$sub_item = $this->describe_acf_field( $sub_field, false );

				// Group sub fields are shown directly; repeater sub fields inside the repeater's layout.
				if ( 'group' === $field['type'] ) {
					$sub_item['use'] = AcfFieldRules::get_usage( $sub_field, $field );
				}

				$item['sub_fields'][] = $sub_item;
			}
		}

		if ( ! empty( $field['layouts'] ) && is_array( $field['layouts'] ) ) {
			foreach ( $field['layouts'] as $layout ) {
				$layout_item = [
					'name'  => $layout['name'],
					'label' => WidgetCatalog::clean( $layout['label'] ),
				];

				if ( ! empty( $layout['sub_fields'] ) && is_array( $layout['sub_fields'] ) ) {
					foreach ( $layout['sub_fields'] as $sub_field ) {
						$layout_item['sub_fields'][] = $this->describe_acf_field( $sub_field, false );
					}
				}

				$item['layouts'][] = $layout_item;
			}
		}

		return $item;
	}
}
