<?php

namespace Aepro\Ai;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Structure (columns, rows, boxes) is built by Elementor's own elementor/build-composition,
 * which stages edits on published documents as a draft (autosave). This class only knows
 * whether those tools exist and publishes such a staged draft when a template is published.
 */
class CompositionService {

	const ELEMENTOR_PUBLISH = 'elementor/publish-document';

	/**
	 * Elementor's composition tools exist only with Elementor 4's atomic editor.
	 *
	 * @return bool
	 */
	public static function is_available() {
		$gate = '\Elementor\Modules\Mcp\Utils\Mcp_V4_Gate';

		return class_exists( $gate ) && $gate::is_atomic_editor_active();
	}

	/**
	 * Publish Elementor's staged draft (autosave) of a document, if there is one.
	 *
	 * @param int $post_id Document ID.
	 * @return bool|\WP_Error true when a staged draft was published, false when there was none.
	 */
	public static function publish_staged_draft( $post_id ) {
		$ability = function_exists( 'wp_get_ability' ) ? wp_get_ability( self::ELEMENTOR_PUBLISH ) : null;

		if ( ! $ability || ! wp_get_post_autosave( $post_id, get_current_user_id() ) ) {
			return false;
		}

		$result = $ability->execute( [ 'post_id' => (int) $post_id ] );

		return is_wp_error( $result ) ? $result : true;
	}

}
