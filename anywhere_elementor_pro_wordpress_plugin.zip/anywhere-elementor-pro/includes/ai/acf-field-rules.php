<?php

namespace Aepro\Ai;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Field widgets (ACF, custom field, map) show nothing without their field.
 * Checks that a NEW widget names its field, that the ACF field exists and suits the widget,
 * and tells AI clients which widget + settings show each ACF field.
 */
class AcfFieldRules {

	const ACF_FIELDS_V2 = 'ae-acf-fields-v2';

	/**
	 * Most field names listed in an error message.
	 */
	const MAX_LISTED_FIELDS = 40;

	/**
	 * ACF field type → ae-acf-fields-v2 field_type.
	 */
	const V2_FIELD_TYPES = [
		'text'             => 'text',
		'textarea'         => 'textarea',
		'wysiwyg'          => 'wysiwyg',
		'number'           => 'number',
		'range'            => 'number',
		'date_picker'      => 'date',
		'date_time_picker' => 'date',
		'select'           => 'select',
		'checkbox'         => 'checkbox',
		'radio'            => 'radio',
		'button_group'     => 'button_group',
		'true_false'       => 'true_false',
		'url'              => 'url',
		'page_link'        => 'url',
		'file'             => 'file',
		'email'            => 'email',
		'image'            => 'image',
		'taxonomy'         => 'taxonomy',
		'post_object'      => 'post_object',
		'relationship'     => 'relationship',
	];

	/**
	 * ACF field type → the dedicated widget and the setting that holds the field name.
	 */
	const DEDICATED_WIDGETS = [
		'gallery'          => [ 'ae-acf-gallery', 'grid_field_name' ],
		'repeater'         => [ 'ae-acf-repeater', 'acf_repeater_field_name' ],
		'flexible_content' => [ 'ae-acf-flexible-content', 'flexible_content' ],
		'google_map'       => [ 'ae-cf-google-map', 'acf-google-map-field' ],
	];

	/**
	 * Validate the field settings of a widget being ADDED. May fill in field_type.
	 *
	 * @param string $widget   Widget name.
	 * @param array  $settings Settings, changed in place (field_type auto-fill).
	 * @param int    $index    Position, for error messages.
	 * @return true|\WP_Error
	 */
	public static function validate( $widget, array &$settings, $index ) {
		switch ( $widget ) {
			case self::ACF_FIELDS_V2:
				return self::validate_fields_v2( $settings, $index );

			case 'ae-acf':
				// Legacy widget: the field type is its skin, the source is "field_type".
				return self::require_keys( $widget, $settings, self::sub_field_keys( $settings, isset( $settings['field_type'] ) ? $settings['field_type'] : 'post' ), $index );

			case 'ae-acf-gallery':
				$key = ( isset( $settings['_skin'] ) && '' !== $settings['_skin'] ? sanitize_key( $settings['_skin'] ) : 'grid' ) . '_field_name';
				return self::validate_dedicated( $widget, $settings, $key, 'gallery', $index );

			case 'ae-acf-repeater':
				return self::validate_dedicated( $widget, $settings, 'acf_repeater_field_name', 'repeater', $index );

			case 'ae-acf-flexible-content':
				return self::validate_dedicated( $widget, $settings, 'flexible_content', 'flexible_content', $index );

			case 'ae-cf-google-map':
				if ( isset( $settings['field_type'] ) && 'custom_fields' === $settings['field_type'] ) {
					return self::require_keys( $widget, $settings, [ 'custom-field-lat', 'custom-field-lng' ], $index );
				}
				return self::validate_dedicated( $widget, $settings, 'acf-google-map-field', 'google_map', $index );

			case 'ae-custom-field':
				// The widget's own default "my_key" is a placeholder, not a field.
				if ( isset( $settings['custom-field'] ) && 'my_key' === $settings['custom-field'] ) {
					unset( $settings['custom-field'] );
				}
				return self::require_keys( $widget, $settings, [ 'custom-field' ], $index, __( 'the post meta key', 'ae-pro' ) );
		}

		return true;
	}

	/**
	 * Which Dynific widget and settings show an ACF field (for dynific/list-acf-fields).
	 *
	 * @param array      $field  ACF field.
	 * @param array|null $parent Parent group field, for group sub fields.
	 * @return array [ 'widget' => …, 'settings' => [] ] or [ 'note' => … ].
	 */
	public static function get_usage( array $field, $parent = null ) {
		$type = isset( $field['type'] ) ? $field['type'] : '';

		if ( isset( self::DEDICATED_WIDGETS[ $type ] ) ) {
			list( $widget, $key ) = self::DEDICATED_WIDGETS[ $type ];

			return [
				'widget'   => $widget,
				'settings' => [ $key => $field['name'] ],
			];
		}

		if ( 'group' === $type ) {
			return [ 'note' => 'Group: show each sub field with its own ae-acf-fields-v2 (see sub_fields[].use).' ];
		}

		if ( ! isset( self::V2_FIELD_TYPES[ $type ] ) ) {
			return [ 'note' => 'No Dynific widget shows this field type.' ];
		}

		$settings = [
			'field_name' => $field['name'],
			'field_type' => self::V2_FIELD_TYPES[ $type ],
		];

		if ( $parent ) {
			$settings = [
				'is_sub_field' => 'group',
				'parent_field' => $parent['name'],
			] + $settings;
		}

		return [
			'widget'   => self::ACF_FIELDS_V2,
			'settings' => $settings,
		];
	}

	private static function validate_fields_v2( array &$settings, $index ) {
		$source = isset( $settings['source'] ) && '' !== $settings['source'] ? $settings['source'] : 'post';
		$keys   = self::sub_field_keys( $settings, $source );

		$missing = self::require_keys( self::ACF_FIELDS_V2, $settings, $keys, $index );

		if ( is_wp_error( $missing ) ) {
			return $missing;
		}

		$is_sub_field = isset( $settings['is_sub_field'] ) ? $settings['is_sub_field'] : '';

		// Sub fields are resolved against their parent at render time; only top-level fields are looked up.
		if ( '' !== $is_sub_field || ! self::acf_available() ) {
			return true;
		}

		$name  = (string) $settings['field_name'];
		$field = self::find_field( $name );

		if ( ! $field ) {
			return self::unknown_field( self::ACF_FIELDS_V2, 'field_name', $name, $index );
		}

		if ( isset( self::DEDICATED_WIDGETS[ $field['type'] ] ) ) {
			list( $widget, $key ) = self::DEDICATED_WIDGETS[ $field['type'] ];
			/* translators: 1: widget index, 2: field name, 3: ACF field type, 4: widget name, 5: setting key */
			return new \WP_Error( 'aep_wrong_widget', sprintf( __( 'widgets[%1$d]: ACF field "%2$s" is a %3$s field. Use %4$s with %5$s instead of ae-acf-fields-v2.', 'ae-pro' ), $index, $name, $field['type'], $widget, $key ), [ 'status' => 400 ] );
		}

		if ( 'group' === $field['type'] ) {
			/* translators: 1: widget index, 2: field name */
			return new \WP_Error( 'aep_wrong_widget', sprintf( __( 'widgets[%1$d]: ACF field "%2$s" is a group. Show each sub field with is_sub_field=group, parent_field="%2$s", field_name=<sub field>.', 'ae-pro' ), $index, $name ), [ 'status' => 400 ] );
		}

		if ( ! isset( self::V2_FIELD_TYPES[ $field['type'] ] ) ) {
			/* translators: 1: widget index, 2: field name, 3: ACF field type */
			return new \WP_Error( 'aep_unsupported_field', sprintf( __( 'widgets[%1$d]: ACF field "%2$s" (%3$s) cannot be shown by a Dynific widget.', 'ae-pro' ), $index, $name, $field['type'] ), [ 'status' => 400 ] );
		}

		$expected = self::V2_FIELD_TYPES[ $field['type'] ];

		if ( ! isset( $settings['field_type'] ) || '' === $settings['field_type'] ) {
			$settings['field_type'] = $expected;
		} elseif ( $expected !== $settings['field_type'] ) {
			/* translators: 1: widget index, 2: field name, 3: ACF field type, 4: field_type value */
			return new \WP_Error( 'aep_field_type_mismatch', sprintf( __( 'widgets[%1$d]: ACF field "%2$s" is a %3$s field; set field_type="%4$s" (or omit it).', 'ae-pro' ), $index, $name, $field['type'], $expected ), [ 'status' => 400 ] );
		}

		return true;
	}

	private static function validate_dedicated( $widget, array $settings, $key, $acf_type, $index ) {
		$missing = self::require_keys( $widget, $settings, [ $key ], $index );

		if ( is_wp_error( $missing ) || ! self::acf_available() ) {
			return $missing;
		}

		$name  = (string) $settings[ $key ];
		$field = self::find_field( $name, $acf_type );

		if ( ! $field ) {
			return self::unknown_field( $widget, $key, $name, $index, $acf_type );
		}

		return true;
	}

	/**
	 * Setting keys that name the field, by sub field mode (same logic as get_field_args() in the widget).
	 */
	private static function sub_field_keys( array $settings, $source ) {
		switch ( isset( $settings['is_sub_field'] ) ? $settings['is_sub_field'] : '' ) {
			case 'repeater':
				return [ 'repeater_field', 'repeater_sub_field' ];
			case 'flexible':
				return [ 'flexible_field', 'flex_sub_field' ];
			case 'group':
				return 'term' === $source ? [ 'group_field', 'group_sub_field' ] : [ 'parent_field', 'field_name' ];
		}

		return [ 'field_name' ];
	}

	private static function require_keys( $widget, array $settings, array $keys, $index, $what = '' ) {
		$missing = [];

		foreach ( $keys as $key ) {
			if ( ! isset( $settings[ $key ] ) || ! is_scalar( $settings[ $key ] ) || '' === trim( (string) $settings[ $key ] ) ) {
				$missing[] = $key;
			}
		}

		if ( ! $missing ) {
			return true;
		}

		$what = $what ? $what : __( 'the ACF field', 'ae-pro' );

		return new \WP_Error(
			'aep_missing_field',
			sprintf(
				/* translators: 1: widget index, 2: widget name, 3: what is missing, 4: setting keys */
				__( 'widgets[%1$d]: %2$s shows nothing without %3$s – set %4$s. Find it with dynific/list-acf-fields; if more than one field could match the user\'s request or none does, ASK the user which field to show. Do not add the widget without it.', 'ae-pro' ),
				$index,
				$widget,
				$what,
				implode( ' + ', $missing )
			),
			[ 'status' => 400 ]
		);
	}

	private static function unknown_field( $widget, $key, $name, $index, $acf_type = '' ) {
		$names = [];

		foreach ( self::get_fields() as $field ) {
			if ( ! $acf_type || $acf_type === $field['type'] ) {
				$names[] = $field['name'] . ' (' . $field['type'] . ')';
			}
		}

		$names = array_slice( array_unique( $names ), 0, self::MAX_LISTED_FIELDS );

		return new \WP_Error(
			'aep_unknown_field',
			sprintf(
				/* translators: 1: widget index, 2: setting key, 3: field name, 4: widget name, 5: field list */
				__( 'widgets[%1$d]: %2$s "%3$s" is not a matching ACF field for %4$s. Available: %5$s. If unsure which one the user means, ask.', 'ae-pro' ),
				$index,
				$key,
				WidgetCatalog::clean( $name ),
				$widget,
				$names ? implode( ', ', array_map( [ WidgetCatalog::class, 'clean' ], $names ) ) : __( 'none', 'ae-pro' )
			),
			[ 'status' => 400 ]
		);
	}

	private static function acf_available() {
		return function_exists( 'acf_get_field_groups' ) && function_exists( 'acf_get_fields' );
	}

	/**
	 * Top-level ACF field by name; with $type, the first one of that type (names may repeat across groups).
	 */
	private static function find_field( $name, $type = '' ) {
		$match = null;

		foreach ( self::get_fields() as $field ) {
			if ( $field['name'] !== $name ) {
				continue;
			}

			if ( ! $type || $type === $field['type'] ) {
				return $field;
			}

			$match = $match ? $match : $field;
		}

		return $type ? null : $match;
	}

	/**
	 * All top-level ACF fields of all field groups.
	 */
	private static function get_fields() {
		static $fields = null;

		if ( null === $fields ) {
			$fields = [];

			foreach ( acf_get_field_groups() as $group ) {
				foreach ( (array) acf_get_fields( $group ) as $field ) {
					if ( isset( $field['name'], $field['type'] ) && '' !== $field['name'] ) {
						$fields[] = $field;
					}
				}
			}
		}

		return $fields;
	}
}
