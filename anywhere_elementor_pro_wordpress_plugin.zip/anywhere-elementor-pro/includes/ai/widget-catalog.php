<?php

namespace Aepro\Ai;

use Elementor\Plugin;
use Elementor\User;
use Elementor\Widget_Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Dynific widget discovery for AI tools: identity checks, trimmed control schemas,
 * valid setting keys and prompt-safe strings.
 */
class WidgetCatalog {

	const CATEGORY          = 'ae-template-elements';
	const NAMESPACE_PREFIX  = 'aepro\\';
	const MAX_STRING_LENGTH = 200;
	const MAX_SCHEMA_BYTES  = 24000;

	/**
	 * Control args the AI never needs (CSS/render plumbing) – saves tokens.
	 */
	const STRIP_KEYS = [
		'selectors',
		'selector',
		'render_type',
		'prefix_class',
		'classes',
		'style_transfer',
		'separator',
		'frontend_available',
		'responsive',
		'is_responsive',
		'parent',
		'dynamic',
		'global',
		'label_block',
		'show_label',
		'ai',
		'section',
		'inner_tab',
		'tabs_wrapper',
	];

	/**
	 * Panel-only UI entries that hold no setting value.
	 */
	const SKIP_TYPES = [
		'section',
		'tabs',
		'tab',
		'heading',
		'divider',
		'raw_html',
		'alert',
		'notice',
		'deprecated_notice',
		'button',
	];

	/**
	 * Author+ who is allowed into the Elementor editor.
	 *
	 * @param mixed $input Unused; abilities pass their input here.
	 * @return bool
	 */
	public static function current_user_can_access( $input = null ) {
		$can = current_user_can( 'edit_posts' ) && current_user_can( 'edit_published_posts' );

		// Elementor Role Manager → Exclude Roles (method returns TRUE when the user is NOT excluded).
		if ( $can && class_exists( User::class ) && ! User::is_current_user_in_editing_black_list() ) {
			$can = false;
		}

		return (bool) apply_filters( 'aepro/ai/current_user_can_access', $can, $input );
	}

	/**
	 * @return array
	 */
	public static function get_widgets() {
		self::ensure_full_controls();

		$widgets = [];

		foreach ( Plugin::$instance->widgets_manager->get_widget_types() as $widget ) {
			if ( self::is_dynific_widget( $widget ) ) {
				$widgets[] = [
					'name'     => $widget->get_name(),
					'title'    => self::clean( $widget->get_title() ),
					'keywords' => array_values( array_map( [ __CLASS__, 'clean' ], (array) $widget->get_keywords() ) ),
				];
			}
		}

		return $widgets;
	}

	/**
	 * @param string $name Widget name, e.g. ae-post-title.
	 * @return Widget_Base|null
	 */
	public static function get_widget( $name ) {
		self::ensure_full_controls();

		$widget = Plugin::$instance->widgets_manager->get_widget_types( sanitize_key( $name ) );

		return self::is_dynific_widget( $widget ) ? $widget : null;
	}

	/**
	 * @param string   $name Widget name, or container / section / column.
	 * @param string   $tab  content | style | advanced | all.
	 * @param string[] $keys Optional: return full definitions for these keys only.
	 * @return array|\WP_Error
	 */
	public static function get_widget_schema( $name, $tab = 'content', array $keys = [] ) {
		$widget = self::get_widget( $name );

		if ( ! $widget ) {
			return new \WP_Error( 'aep_unknown_widget', __( 'Unknown Dynific widget. Call dynific/list-widgets first. Layout boxes are Elementor\'s – see elementor/build-composition.', 'ae-pro' ), [ 'status' => 404 ] );
		}

		$tab  = in_array( $tab, [ 'content', 'style', 'advanced', 'all' ], true ) ? $tab : 'content';
		$keys = array_filter( array_map( 'sanitize_key', $keys ) );

		// The shared Advanced-tab controls (_margin, _padding …) come from the common widget.
		$stack    = $widget->get_stack( $keys || in_array( $tab, [ 'advanced', 'all' ], true ) );
		$controls = isset( $stack['controls'] ) ? $stack['controls'] : [];

		if ( $keys ) {
			$controls = array_intersect_key( $controls, array_flip( $keys ) );
			$tab      = 'all';
		}

		$schema = [
			'widget'   => $widget->get_name(),
			'title'    => self::clean( $widget->get_title() ),
			'tab'      => $tab,
			'controls' => self::trim_controls( $controls, $tab ),
			'note'     => 'Responsive controls also accept {key}_tablet and {key}_mobile. Omit a key to keep its default. Tabs: content (default), style (colours, typography), advanced (_margin, _padding, _css_classes …).',
		];

		// Too large for an AI context: send an index and let the client ask for specific keys.
		if ( ! $keys && strlen( (string) wp_json_encode( $schema['controls'] ) ) > self::MAX_SCHEMA_BYTES ) {
			$index = [];

			foreach ( $schema['controls'] as $key => $control ) {
				$index[ $key ] = trim( ( isset( $control['type'] ) ? $control['type'] : '' ) . ': ' . ( isset( $control['label'] ) ? $control['label'] : '' ), ': ' );
			}

			$schema['controls'] = [];
			$schema['index']    = $index;
			$schema['note']     = 'Large tab: "index" lists key => type: label. Call dynific/get-widget-schema again with keys=[…] to get full definitions (options, defaults, units) for the keys you need. ' . $schema['note'];
		}

		return $schema;
	}

	/**
	 * All valid setting keys, including responsive device copies and the
	 * shared Advanced-tab controls (_margin, _padding, _css_classes …).
	 *
	 * @param \Elementor\Controls_Stack $widget Widget or layout element instance.
	 * @return string[]
	 */
	public static function get_setting_keys( \Elementor\Controls_Stack $widget ) {
		$stack    = $widget->get_stack( true );
		$controls = isset( $stack['controls'] ) ? $stack['controls'] : [];
		$keys     = array_keys( $controls );

		// Device values of responsive controls are saved as {key}_{device} but are not registered controls.
		$devices = self::get_devices();

		foreach ( $controls as $key => $control ) {
			// Elementor marks responsive controls with a (often empty) 'responsive' array.
			if ( isset( $control['responsive'] ) ) {
				foreach ( $devices as $device ) {
					$keys[] = $key . '_' . $device;
				}
			}
		}

		return array_values( array_unique( $keys ) );
	}

	/**
	 * The base control of a responsive device key, e.g. flex_direction_mobile → flex_direction.
	 *
	 * @param array  $controls Stack controls.
	 * @param string $key      Setting key.
	 * @return array|null
	 */
	public static function get_responsive_base_control( array $controls, $key ) {
		foreach ( self::get_devices() as $device ) {
			$suffix = '_' . $device;

			if ( substr( $key, -strlen( $suffix ) ) === $suffix ) {
				$base = substr( $key, 0, -strlen( $suffix ) );

				if ( isset( $controls[ $base ]['responsive'] ) ) {
					return $controls[ $base ];
				}
			}
		}

		return null;
	}

	/**
	 * Active breakpoint names (mobile, tablet …), longest first so mobile_extra wins over mobile.
	 *
	 * @return string[]
	 */
	private static function get_devices() {
		$devices = array_keys( (array) Plugin::$instance->breakpoints->get_active_breakpoints() );

		usort(
			$devices,
			function ( $a, $b ) {
				return strlen( $b ) - strlen( $a );
			}
		);

		return $devices;
	}

	/**
	 * Category is self-declared, so identity is proven by namespace AND class file location.
	 *
	 * @param mixed $widget Widget instance.
	 * @return bool
	 */
	public static function is_dynific_widget( $widget ) {
		if ( ! $widget instanceof Widget_Base ) {
			return false;
		}

		if ( ! in_array( self::CATEGORY, (array) $widget->get_categories(), true ) ) {
			return false;
		}

		$class  = get_class( $widget );
		$is_own = 0 === strpos( strtolower( $class ), self::NAMESPACE_PREFIX )
			&& self::class_is_defined_in_plugin( $class );

		return (bool) apply_filters( 'aepro/ai/is_dynific_widget', $is_own, $widget );
	}

	/**
	 * Elementor strips control labels, options and style-only controls outside admin/REST
	 * requests (Performance::should_optimize_controls). AI tools always need the full
	 * definitions – e.g. an MCP client connected through WP-CLI (STDIO) – so switch the
	 * optimisation off before any widget stack is built. Abilities never render pages.
	 */
	public static function ensure_full_controls() {
		$performance = \Elementor\Core\Frontend\Performance::class;

		if ( ! class_exists( $performance ) || ! $performance::should_optimize_controls() ) {
			return;
		}

		try {
			$property = new \ReflectionProperty( $performance, 'is_frontend' );
			$property->setAccessible( true );
			$property->setValue( null, false );
		} catch ( \ReflectionException $e ) {
			// Elementor internals changed – keep the optimised (reduced) controls.
			return;
		}
	}

	/**
	 * Strings flow into an LLM prompt: strip tags/control chars, cap length.
	 *
	 * @param mixed $value Value to clean.
	 * @return string
	 */
	public static function clean( $value ) {
		$value = wp_strip_all_tags( (string) $value );
		$value = preg_replace( '/[\x00-\x1F\x7F]/u', '', $value );

		return mb_substr( trim( (string) $value ), 0, self::MAX_STRING_LENGTH );
	}

	private static function class_is_defined_in_plugin( $class ) {
		try {
			$file = ( new \ReflectionClass( $class ) )->getFileName();
		} catch ( \ReflectionException $e ) {
			return false;
		}

		if ( ! $file ) {
			return false;
		}

		$file = wp_normalize_path( (string) realpath( $file ) );
		$base = trailingslashit( wp_normalize_path( (string) realpath( AE_PRO_PATH ) ) );

		return 0 === strpos( $file, $base );
	}

	private static function trim_controls( array $controls, $tab ) {
		$trimmed = [];

		foreach ( $controls as $key => $control ) {
			if ( ! is_array( $control ) ) {
				continue;
			}

			if ( 'all' !== $tab && isset( $control['tab'] ) && $tab !== $control['tab'] ) {
				continue;
			}

			// Skip UI-only entries and responsive device copies (align_tablet …).
			if ( in_array( isset( $control['type'] ) ? $control['type'] : '', self::SKIP_TYPES, true ) || ! empty( $control['parent'] ) ) {
				continue;
			}

			$is_responsive = ! empty( $control['is_responsive'] ) || isset( $control['responsive'] );

			foreach ( self::STRIP_KEYS as $strip_key ) {
				unset( $control[ $strip_key ] );
			}

			if ( 'all' !== $tab ) {
				unset( $control['tab'] );
			}

			// Name duplicates the array key, except in list-style repeater fields.
			if ( isset( $control['name'] ) && is_string( $key ) && $key === $control['name'] ) {
				unset( $control['name'] );
			}

			if ( $is_responsive ) {
				$control['responsive'] = true;
			}

			foreach ( [ 'label', 'description' ] as $text_key ) {
				if ( isset( $control[ $text_key ] ) ) {
					$control[ $text_key ] = self::clean( $control[ $text_key ] );
					if ( '' === $control[ $text_key ] ) {
						unset( $control[ $text_key ] );
					}
				}
			}

			if ( isset( $control['options'] ) && is_array( $control['options'] ) ) {
				foreach ( $control['options'] as $option_key => $option_label ) {
					if ( is_scalar( $option_label ) ) {
						$control['options'][ $option_key ] = self::clean( $option_label );
					} elseif ( is_array( $option_label ) && isset( $option_label['title'] ) ) {
						$control['options'][ $option_key ] = self::clean( $option_label['title'] );
					}
				}
			}

			if ( isset( $control['fields'] ) && is_array( $control['fields'] ) ) {
				$control['fields'] = self::trim_controls( $control['fields'], 'all' );
			}

			$trimmed[ $key ] = $control;
		}

		return $trimmed;
	}
}
