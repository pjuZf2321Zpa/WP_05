<?php

namespace Aepro\Ai;

use Elementor\Plugin;
use Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Validates AI-provided Dynific widgets and saves them through Elementor's Document API.
 */
class ContentBuilder {

	const MAX_WIDGETS       = 30;
	const POST_BLOCKS       = 'ae-post-blocks';
	const BLOCK_LAYOUT_MODE = 'block_layout';

	/**
	 * Write widgets into a Dynific template.
	 *
	 * @param int    $template_id ae_global_templates post ID.
	 * @param array  $widgets     [ [ 'widget' => 'ae-post-title', 'settings' => [ … ] ], … ].
	 * @param string $mode        replace | append.
	 * @return array|\WP_Error
	 */
	public static function set_content( $template_id, array $widgets, $mode = 'replace' ) {
		$template_id = absint( $template_id );
		$post        = get_post( $template_id );

		if ( ! $post || TemplateService::POST_TYPE !== $post->post_type ) {
			return new \WP_Error( 'aep_not_template', __( 'Template not found.', 'ae-pro' ), [ 'status' => 404 ] );
		}

		if ( ! current_user_can( 'edit_post', $template_id ) ) {
			return new \WP_Error( 'aep_forbidden', __( 'You cannot edit this template.', 'ae-pro' ), [ 'status' => 403 ] );
		}

		$open = TemplateService::check_not_open_in_editor( $template_id );

		if ( is_wp_error( $open ) ) {
			return $open;
		}

		$children = self::validate_widgets( $widgets, $template_id );

		// Nothing is saved if any widget is invalid.
		if ( is_wp_error( $children ) ) {
			return $children;
		}

		$saved = self::save( $template_id, [ self::wrap( $children ) ], 'append' === $mode ? 'append' : 'replace' );

		if ( is_wp_error( $saved ) ) {
			return $saved;
		}

		return [
			'template_id'   => $template_id,
			'mode'          => 'append' === $mode ? 'append' : 'replace',
			'widgets_added' => count( $children ),
			'status'        => get_post_status( $template_id ),
			'edit_url'      => TemplateService::get_edit_url( $template_id ),
		];
	}

	/**
	 * Validate a list of widgets and build their Elementor element data.
	 * Shared by the server-side save and the live editor tools.
	 *
	 * @param array $widgets     [ [ 'widget' => name, 'settings' => [] ], … ].
	 * @param int   $document_id The document the widgets go into (a layout cannot render itself).
	 * @return array|\WP_Error Element data, or the first validation error.
	 */
	public static function validate_widgets( array $widgets, $document_id = 0 ) {
		if ( empty( $widgets ) || count( $widgets ) > self::MAX_WIDGETS ) {
			/* translators: %d: maximum number of widgets */
			return new \WP_Error( 'aep_bad_widgets', sprintf( __( 'Provide between 1 and %d widgets.', 'ae-pro' ), self::MAX_WIDGETS ), [ 'status' => 400 ] );
		}

		$elements = [];

		foreach ( array_values( $widgets ) as $index => $item ) {
			$element = self::build_widget( is_array( $item ) ? $item : [], $index, $document_id );

			if ( is_wp_error( $element ) ) {
				return $element;
			}

			$elements[] = $element;
		}

		return $elements;
	}

	/**
	 * Validate a settings change for one existing widget.
	 *
	 * @param string $widget_name Widget type, e.g. ae-post-title.
	 * @param array  $settings    Changed settings only.
	 * @param int    $document_id The document the widget is in.
	 * @return array|\WP_Error The validated settings.
	 */
	public static function validate_settings( $widget_name, array $settings, $document_id = 0 ) {
		$element = self::build_widget(
			[
				'widget'   => $widget_name,
				'settings' => $settings,
			],
			0,
			$document_id,
			false
		);

		return is_wp_error( $element ) ? $element : $element['settings'];
	}

	/**
	 * Current element tree of a template, compact enough for an AI to read.
	 *
	 * @param int $template_id ae_global_templates post ID.
	 * @return array|\WP_Error
	 */
	public static function get_content( $template_id ) {
		$template_id = absint( $template_id );
		$post        = get_post( $template_id );

		if ( ! $post || TemplateService::POST_TYPE !== $post->post_type ) {
			return new \WP_Error( 'aep_not_template', __( 'Template not found.', 'ae-pro' ), [ 'status' => 404 ] );
		}

		if ( ! current_user_can( 'edit_post', $template_id ) ) {
			return new \WP_Error( 'aep_forbidden', __( 'You cannot edit this template.', 'ae-pro' ), [ 'status' => 403 ] );
		}

		$document = Plugin::$instance->documents->get( $template_id );

		return [
			'template_id' => $template_id,
			'title'       => WidgetCatalog::clean( get_the_title( $post ) ),
			'status'      => $post->post_status,
			'render_mode' => (string) get_post_meta( $template_id, 'ae_render_mode', true ),
			'elements'    => $document ? self::summarize( (array) $document->get_elements_data() ) : [],
			'edit_url'    => TemplateService::get_edit_url( $template_id ),
		];
	}

	/**
	 * @param array $elements Raw Elementor element data.
	 * @return array
	 */
	public static function summarize( array $elements ) {
		$items = [];

		foreach ( $elements as $element ) {
			if ( ! is_array( $element ) ) {
				continue;
			}

			$item = [
				'id'     => isset( $element['id'] ) ? (string) $element['id'] : '',
				'elType' => isset( $element['elType'] ) ? (string) $element['elType'] : '',
			];

			if ( ! empty( $element['widgetType'] ) ) {
				$item['widgetType'] = (string) $element['widgetType'];
				$item['settings']   = isset( $element['settings'] ) && is_array( $element['settings'] ) ? $element['settings'] : [];
			}

			if ( ! empty( $element['elements'] ) && is_array( $element['elements'] ) ) {
				$item['elements'] = self::summarize( $element['elements'] );
			}

			$items[] = $item;
		}

		return $items;
	}

	/**
	 * Append a Post Blocks widget that renders a block layout to an Elementor page.
	 *
	 * @param array $args page_id, layout_id, post_type, settings, allow_published.
	 * @return array|\WP_Error
	 */
	public static function add_post_blocks_to_page( array $args ) {
		$page_id   = isset( $args['page_id'] ) ? absint( $args['page_id'] ) : 0;
		$layout_id = isset( $args['layout_id'] ) ? absint( $args['layout_id'] ) : 0;
		$page      = $page_id ? get_post( $page_id ) : null;
		$layout    = $layout_id ? get_post( $layout_id ) : null;

		if ( ! WidgetCatalog::get_widget( self::POST_BLOCKS ) ) {
			return new \WP_Error( 'aep_pro_required', __( 'The Post Blocks widget requires Dynific Addons Pro and must be enabled.', 'ae-pro' ), [ 'status' => 403 ] );
		}

		if ( ! $layout || TemplateService::POST_TYPE !== $layout->post_type || self::BLOCK_LAYOUT_MODE !== get_post_meta( $layout_id, 'ae_render_mode', true ) ) {
			return new \WP_Error( 'aep_not_block_layout', __( 'layout_id must be a Dynific Block Layout template.', 'ae-pro' ), [ 'status' => 404 ] );
		}

		// The Post Blocks layout dropdown lists published layouts only.
		if ( 'publish' !== $layout->post_status ) {
			return new \WP_Error( 'aep_layout_not_published', __( 'The block layout is not published yet. Ask the user to review and publish it first.', 'ae-pro' ), [ 'status' => 409 ] );
		}

		if ( ! $page || $page_id === $layout_id || in_array( $page->post_type, [ 'revision', 'attachment', 'nav_menu_item' ], true ) ) {
			return new \WP_Error( 'aep_not_page', __( 'Target page not found.', 'ae-pro' ), [ 'status' => 404 ] );
		}

		if ( ! current_user_can( 'edit_post', $page_id ) ) {
			return new \WP_Error( 'aep_forbidden', __( 'You cannot edit this page.', 'ae-pro' ), [ 'status' => 403 ] );
		}

		$open = TemplateService::check_not_open_in_editor( $page_id );

		if ( is_wp_error( $open ) ) {
			return $open;
		}

		// Changes to a published page go live immediately – the user must agree first.
		if ( 'publish' === $page->post_status && empty( $args['allow_published'] ) ) {
			return new \WP_Error( 'aep_page_published', __( 'The page is published and the change would go live. Ask the user to confirm, then retry with allow_published=true.', 'ae-pro' ), [ 'status' => 409 ] );
		}

		$document = Plugin::$instance->documents->get( $page_id );

		if ( ! $document || ! $document::get_property( 'is_editable' ) || ! $document->is_editable_by_current_user() ) {
			return new \WP_Error( 'aep_not_elementor', __( 'This page cannot be edited with Elementor.', 'ae-pro' ), [ 'status' => 400 ] );
		}

		// Do not silently hide existing classic-editor content behind Elementor.
		if ( ! $document->is_built_with_elementor() && '' !== trim( (string) $page->post_content ) ) {
			return new \WP_Error( 'aep_classic_content', __( 'The page has classic editor content. Ask the user to open it with Elementor first.', 'ae-pro' ), [ 'status' => 409 ] );
		}

		$settings = isset( $args['settings'] ) && is_array( $args['settings'] ) ? $args['settings'] : [];

		$settings['template']     = (string) $layout_id;
		$settings['ae_post_type'] = ! empty( $args['post_type'] )
			? sanitize_key( $args['post_type'] )
			: (string) get_post_meta( $layout_id, 'ae_rule_post_type', true );

		$widget = self::build_widget(
			[
				'widget'   => self::POST_BLOCKS,
				'settings' => $settings,
			],
			0,
			$page_id
		);

		if ( is_wp_error( $widget ) ) {
			return $widget;
		}

		$saved = self::save( $page_id, [ self::wrap( [ $widget ] ) ], 'append' );

		if ( is_wp_error( $saved ) ) {
			return $saved;
		}

		return [
			'page_id'   => $page_id,
			'layout_id' => $layout_id,
			'post_type' => $settings['ae_post_type'],
			'status'    => get_post_status( $page_id ),
			'edit_url'  => TemplateService::get_edit_url( $page_id ),
			'view_url'  => get_permalink( $page_id ),
		];
	}

	/**
	 * @param array $item        [ 'widget' => name, 'settings' => [] ].
	 * @param int   $index       Position, for error messages.
	 * @param int   $document_id The document the widget goes into.
	 * @param bool  $is_new      true = a widget being added (its field must be set); false = a partial settings change.
	 * @return array|\WP_Error Elementor element data.
	 */
	private static function build_widget( array $item, $index, $document_id = 0, $is_new = true ) {
		$name   = isset( $item['widget'] ) && is_string( $item['widget'] ) ? sanitize_key( $item['widget'] ) : '';
		$widget = WidgetCatalog::get_widget( $name );

		if ( ! $widget ) {
			/* translators: 1: widget index, 2: widget name */
			return new \WP_Error( 'aep_unknown_widget', sprintf( __( 'widgets[%1$d]: "%2$s" is not a Dynific widget. Call dynific/list-widgets.', 'ae-pro' ), $index, $name ), [ 'status' => 400 ] );
		}

		$settings = isset( $item['settings'] ) && is_array( $item['settings'] ) ? $item['settings'] : [];
		$unknown  = array_diff( array_keys( $settings ), WidgetCatalog::get_setting_keys( $widget ) );

		if ( $unknown ) {
			$unknown = array_map( [ WidgetCatalog::class, 'clean' ], $unknown );
			/* translators: 1: widget index, 2: comma-separated setting keys, 3: widget name */
			return new \WP_Error( 'aep_unknown_settings', sprintf( __( 'widgets[%1$d]: unknown setting keys: %2$s. Call dynific/get-widget-schema for %3$s.', 'ae-pro' ), $index, implode( ', ', $unknown ), $name ), [ 'status' => 400 ] );
		}

		// Field widgets (ACF, custom field, map) show nothing without their field. May fill in field_type.
		if ( $is_new ) {
			$field_error = AcfFieldRules::validate( $name, $settings, $index );

			if ( is_wp_error( $field_error ) ) {
				return $field_error;
			}
		}

		$select_error = self::validate_select_values( $widget, $settings, $index, absint( $document_id ) );

		if ( is_wp_error( $select_error ) ) {
			return $select_error;
		}

		return [
			'id'         => Utils::generate_random_string(),
			'elType'     => 'widget',
			'widgetType' => $name,
			'settings'   => $settings,
			'elements'   => [],
		];
	}

	/**
	 * Values of SELECT / CHOOSE controls with a fixed option list must be one of those options.
	 * Other values are saved as given; Elementor's save runs kses for users without unfiltered_html.
	 */
	private static function validate_select_values( $widget, array $settings, $index, $document_id ) {
		$controls = $widget->get_stack( true )['controls'];

		foreach ( $settings as $key => $value ) {
			$base      = WidgetCatalog::get_responsive_base_control( $controls, $key );
			$is_device = null !== $base;
			$control   = isset( $controls[ $key ] ) ? $controls[ $key ] : $base;
			$control   = $control ? $control : [];
			$type      = isset( $control['type'] ) ? $control['type'] : '';

			// An empty device value means "inherit from the larger screen".
			if ( $is_device && '' === $value ) {
				continue;
			}

			if ( in_array( $type, [ 'select', 'select2' ], true ) ) {
				$reference_error = self::validate_template_reference( $key, $value, $index, $document_id );

				if ( is_wp_error( $reference_error ) ) {
					return $reference_error;
				}

				// A published template: valid even if the dropdown options were built before it existed.
				if ( true === $reference_error ) {
					continue;
				}
			}

			if ( ! in_array( $type, [ 'select', 'choose' ], true ) || empty( $control['options'] ) || ! is_array( $control['options'] ) ) {
				continue;
			}

			if ( ! is_scalar( $value ) || ! array_key_exists( (string) $value, $control['options'] ) ) {
				$allowed = array_map( [ WidgetCatalog::class, 'clean' ], array_slice( array_keys( $control['options'] ), 0, 30 ) );
				/* translators: 1: widget index, 2: setting key, 3: comma-separated allowed values */
				return new \WP_Error( 'aep_invalid_value', sprintf( __( 'widgets[%1$d]: invalid value for %2$s. Allowed: %3$s.', 'ae-pro' ), $index, $key, implode( ', ', $allowed ) ), [ 'status' => 400 ] );
			}
		}

		return true;
	}

	/**
	 * Settings that point at a Dynific template (Post Blocks "template", Post Blocks Adv "layout",
	 * Dynamic Map info window layout, fallback templates …) must reference a PUBLISHED template
	 * other than the document itself: visitors see nothing from a draft, and self-reference loops.
	 *
	 * @return true|false|\WP_Error true = valid template reference, false = not a template reference.
	 */
	private static function validate_template_reference( $key, $value, $index, $document_id ) {
		if ( ! preg_match( '/template|layout/', $key ) || ! is_scalar( $value ) || ! ctype_digit( (string) $value ) || ! (int) $value ) {
			return false;
		}

		$template = get_post( (int) $value );

		if ( ! $template || TemplateService::POST_TYPE !== $template->post_type ) {
			return false;
		}

		if ( $document_id && $template->ID === $document_id ) {
			/* translators: 1: widget index, 2: setting key */
			return new \WP_Error( 'aep_self_reference', sprintf( __( 'widgets[%1$d]: %2$s cannot use the template it is placed in.', 'ae-pro' ), $index, $key ), [ 'status' => 400 ] );
		}

		if ( 'publish' !== $template->post_status ) {
			/* translators: 1: widget index, 2: setting key, 3: template ID, 4: post status */
			return new \WP_Error( 'aep_layout_not_published', sprintf( __( 'widgets[%1$d]: %2$s uses template %3$d, which is %4$s – visitors would see nothing. Publish it first with dynific/update-template status=publish (a block layout does not change the site on its own).', 'ae-pro' ), $index, $key, $template->ID, $template->post_status ), [ 'status' => 409 ] );
		}

		return true;
	}

	/**
	 * Save one top-level element through Elementor (permissions, kses, revisions, CSS, cache).
	 */
	private static function save( $post_id, array $new_elements, $mode ) {
		$document = Plugin::$instance->documents->get( $post_id );

		if ( ! $document ) {
			return new \WP_Error( 'aep_no_document', __( 'Elementor document not available.', 'ae-pro' ), [ 'status' => 500 ] );
		}

		$elements = 'append' === $mode
			? array_merge( (array) $document->get_elements_data(), $new_elements )
			: $new_elements;

		if ( ! $document->save( [ 'elements' => $elements ] ) ) {
			return new \WP_Error( 'aep_save_failed', __( 'Could not save the content.', 'ae-pro' ), [ 'status' => 500 ] );
		}

		$document->set_is_built_with_elementor( true );

		return true;
	}

	/**
	 * Flexbox container when available, otherwise classic section > column.
	 */
	private static function wrap( array $children ) {
		if ( Plugin::$instance->experiments->is_feature_active( 'container' ) ) {
			return [
				'id'       => Utils::generate_random_string(),
				'elType'   => 'container',
				'settings' => [
					'flex_direction' => 'column',
				],
				'elements' => $children,
			];
		}

		return [
			'id'       => Utils::generate_random_string(),
			'elType'   => 'section',
			'settings' => [],
			'elements' => [
				[
					'id'       => Utils::generate_random_string(),
					'elType'   => 'column',
					'settings' => [
						'_column_size' => 100,
					],
					'elements' => $children,
				],
			],
		];
	}
}
