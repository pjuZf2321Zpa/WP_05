<?php

namespace Aepro\Ai;

use Elementor\Plugin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Loads the Angie editor MCP server (build/angie-integration.js) inside the Elementor editor.
 * The browser tools change the OPEN document live through Elementor's $e commands;
 * every widget and setting key is validated here first.
 */
class EditorIntegration {

	const SCRIPT_HANDLE = 'aepro-angie-integration';
	const NONCE_ACTION  = 'aepro_ai_editor';

	private static $_instance = null;

	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	private function __construct() {
		add_action( 'elementor/editor/after_enqueue_scripts', [ $this, 'enqueue_scripts' ] );
		add_action( 'wp_ajax_aepro_ai_validate_widgets', [ $this, 'ajax_validate_widgets' ] );
		add_action( 'wp_ajax_aepro_ai_validate_settings', [ $this, 'ajax_validate_settings' ] );
		add_action( 'wp_ajax_aepro_ai_document_state', [ $this, 'ajax_document_state' ] );
	}

	public function enqueue_scripts() {
		// Angie is the only consumer; without it the bundle would be dead weight.
		if ( ! defined( 'ANGIE_VERSION' ) || ! WidgetCatalog::current_user_can_access() ) {
			return;
		}

		wp_enqueue_script(
			self::SCRIPT_HANDLE,
			AE_PRO_URL . 'build/angie-integration' . AE_PRO_SCRIPT_SUFFIX . '.js',
			[ 'elementor-editor' ],
			AE_PRO_VERSION,
			true
		);

		wp_localize_script(
			self::SCRIPT_HANDLE,
			'aeproAngie',
			[
				'ajaxUrl'      => admin_url( 'admin-ajax.php' ),
				'nonce'        => wp_create_nonce( self::NONCE_ACTION ),
				'version'      => AE_PRO_VERSION,
				'useContainer' => Plugin::$instance->experiments->is_feature_active( 'container' ),
				'instructions' => Abilities::get_guide_text(),
			]
		);
	}

	/**
	 * Validate widgets before the editor inserts them. Returns Elementor models.
	 */
	public function ajax_validate_widgets() {
		$post_id = $this->verify_request();

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Verified in verify_request().
		$widgets = $this->decode( isset( $_POST['widgets'] ) ? wp_unslash( $_POST['widgets'] ) : '' );
		$result  = ContentBuilder::validate_widgets( $widgets, $post_id );

		if ( is_wp_error( $result ) ) {
			$this->send_error( $result );
		}

		wp_send_json_success(
			[
				'post_id'  => $post_id,
				'elements' => $result,
			]
		);
	}

	/**
	 * Validate a settings change for one widget before the editor applies it.
	 */
	public function ajax_validate_settings() {
		$post_id = $this->verify_request();

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Verified in verify_request().
		$widget   = isset( $_POST['widget'] ) ? sanitize_key( wp_unslash( $_POST['widget'] ) ) : '';
		$settings = $this->decode( isset( $_POST['settings'] ) ? wp_unslash( $_POST['settings'] ) : '' );
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		$result = ContentBuilder::validate_settings( $widget, $settings, $post_id );

		if ( is_wp_error( $result ) ) {
			$this->send_error( $result );
		}

		wp_send_json_success( [ 'settings' => $result ] );
	}

	/**
	 * What is SAVED for the open document (status + element counts), so the editor save tool
	 * can confirm that its changes really reached the database.
	 */
	public function ajax_document_state() {
		$post_id  = $this->verify_request();
		$document = Plugin::$instance->documents->get( $post_id, false );
		$elements = $document ? (array) $document->get_elements_data() : [];

		wp_send_json_success(
			[
				'status'   => get_post_status( $post_id ),
				'elements' => self::count_elements( $elements ),
				'widgets'  => self::count_elements( $elements, true ),
			]
		);
	}

	private static function count_elements( array $elements, $widgets_only = false ) {
		$count = 0;

		foreach ( $elements as $element ) {
			if ( ! is_array( $element ) ) {
				continue;
			}

			if ( ! $widgets_only || ( isset( $element['elType'] ) && 'widget' === $element['elType'] ) ) {
				++$count;
			}

			if ( ! empty( $element['elements'] ) && is_array( $element['elements'] ) ) {
				$count += self::count_elements( $element['elements'], $widgets_only );
			}
		}

		return $count;
	}

	/**
	 * Nonce + editor access + edit rights on the open document. Ends the request on failure.
	 *
	 * @return int Document ID.
	 */
	private function verify_request() {
		if ( ! check_ajax_referer( self::NONCE_ACTION, 'nonce', false ) ) {
			wp_send_json_error( [ 'message' => __( 'Invalid or expired nonce. Reload the editor.', 'ae-pro' ) ], 403 );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Verified above.
		$post_id = isset( $_POST['post_id'] ) ? absint( $_POST['post_id'] ) : 0;

		if ( ! WidgetCatalog::current_user_can_access() || ! $post_id || ! current_user_can( 'edit_post', $post_id ) ) {
			wp_send_json_error( [ 'message' => __( 'You cannot edit this document.', 'ae-pro' ) ], 403 );
		}

		return $post_id;
	}

	private function decode( $json ) {
		$data = is_string( $json ) ? json_decode( $json, true ) : null;

		return is_array( $data ) ? $data : [];
	}

	private function send_error( \WP_Error $error ) {
		$data = $error->get_error_data();

		wp_send_json_error(
			[
				'code'    => $error->get_error_code(),
				'message' => $error->get_error_message(),
			],
			isset( $data['status'] ) ? $data['status'] : 400
		);
	}
}
