<?php

namespace Aepro\Admin;

class PostType {

	private static $_instance = null;

	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	private function __construct() {

		add_action( 'init', [ $this, 'register_post_type' ], 0 );
	}

	public function register_post_type() {

		$labels = [
			'name'               => _x( 'Dynific Global Templates', 'Post Type General Name', 'ae-pro' ),
			'singular_name'      => _x( 'Dynific Template', 'Post Type Singular Name', 'ae-pro' ),
			'menu_name'          => __( 'Dynific Templates', 'ae-pro' ),
			'name_admin_bar'     => __( 'Dynific Templates', 'ae-pro' ),
			'archives'           => __( 'List Archives', 'ae-pro' ),
			'parent_item_colon'  => __( 'Parent List:', 'ae-pro' ),
			'all_items'          => __( 'All Dynific Templates', 'ae-pro' ),
			'add_new_item'       => __( 'Add New Dynific Template', 'ae-pro' ),
			'add_new'            => __( 'Add New', 'ae-pro' ),
			'new_item'           => __( 'New Dynific Template', 'ae-pro' ),
			'edit_item'          => __( 'Edit Dynific Template', 'ae-pro' ),
			'update_item'        => __( 'Update Dynific Template', 'ae-pro' ),
			'view_item'          => __( 'View Dynific Template', 'ae-pro' ),
			'search_items'       => __( 'Search Dynific Template', 'ae-pro' ),
			'not_found'          => __( 'Not found', 'ae-pro' ),
			'not_found_in_trash' => __( 'Not found in Trash', 'ae-pro' ),
		];
		$args   = [
			'label'               => __( 'Post List', 'ae-pro' ),
			'labels'              => $labels,
			'supports'            => [ 'title', 'editor' ],
			'public'              => true,
			'rewrite'             => false,
			'show_ui'             => true,
			'show_in_menu'        => true,
			'show_in_nav_menus'   => false,
			'exclude_from_search' => true,
			'capability_type'     => 'post',
			// Global templates can be applied site-wide, so managing them needs more than edit_posts.
			'capabilities'        => $this->get_capabilities(),
			'map_meta_cap'        => true,
			'hierarchical'        => false,
			/* 'menu_icon'           => 'data:image/svg+xml;base64,' . base64_encode(
				'<svg width="640px" height="778px" viewBox="0 0 640 778" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
            <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                <g id="aep-logo" fill-rule="nonzero">
                    <path d="M148,432.6 C148,450.1 153.3,464.1 163.9,474.6 C174.5,485.1 189.1,490.3 207.6,490.3 C232.7,490.3 251.6,479.6 264.4,458.2 L265.1,458.2 L265.1,490.3 L320.8,490.3 L320.8,444.6 C324.6,452.1 329.4,458.8 335.3,464.7 C352.3,481.8 376.2,490.3 407.1,490.3 L475.9,490.3 L475.9,447.8 L420.5,448.5 C387.6,448.5 370.1,434.6 368.1,406.9 L492.6,406.9 L492.6,382.1 C492.6,353.8 485,331.3 469.8,314.8 C454.6,298.3 433.1,290 405.2,290 C378.4,290 355.7,299.3 337.4,317.8 C329.2,326 323,335.6 318.5,346.4 C310.9,308.9 284.5,290 239.3,290 C227.6,290 214.7,291.6 200.4,294.8 C186.2,298 175,301.8 166.8,306 L166.8,350.4 C187.3,336.9 208.9,330.1 231.7,330.1 C254.3,330.1 265.6,340.5 265.6,361.4 L213.8,368.3 C170,374.2 148,395.5 148,432.6 Z M380.5,341.6 C387.4,333.8 395.6,329.9 405,329.9 C427.1,329.9 438.2,343.6 438.2,370.9 L367.9,370.9 C369.4,359.2 373.6,349.4 380.5,341.6 Z M265.7,395.3 L265.7,408.2 C265.7,419.9 262.2,429.5 255.3,437.2 C248.3,444.8 239.3,448.7 228.3,448.7 C220.4,448.7 214,446.6 209.4,442.3 C204.7,438 202.4,432.5 202.4,425.8 C202.4,411 212,402.4 231.1,399.9 L265.7,395.3 Z" id="Shape"></path>
                    <path d="M480.2,85.8 C479.8,85.8 479.5,85.8 479.1,85.8 L161.4,85.8 C72.7,85.8 0.5,157.9 0.5,246.7 L0.5,533.7 L0.5,572.8 L78.3,572.8 L77.8,533.7 L77.8,246.7 C77.8,200.5 115.3,163.1 161.4,163.1 L616.6,163.1 L640,163.1 L480.2,0.7 L480.2,85.8 Z" id="Path"></path>
                    <path d="M562.7,246.7 L562.7,533.7 C562.7,579.9 525.2,617.3 479.1,617.3 L162.8,617.3 L23.9,617.3 L0.5,617.3 L162.9,777.1 L162.9,694.6 L479.1,694.6 C567.8,694.6 640,622.5 640,533.7 L640,246.7 L640,207.6 L562.3,207.6 L562.7,246.7 Z" id="Path"></path>
                </g>
            </g>
        </svg>' */
		'menu_icon'           => 'data:image/svg+xml;base64,' . base64_encode('<svg width="1249" height="1512" viewBox="0 0 1249 1512" fill="none" xmlns="http://www.w3.org/2000/svg">
								<path d="M446.137 495.992C482.213 495.992 515.513 501.419 545.761 512.64C576.172 523.921 602.392 540.876 624.07 563.551H624.069C631.518 571.266 638.337 579.586 644.537 588.489L596.23 707.79L596.644 707.957L580.974 745.224C580.13 720.106 576.778 698.756 571.225 680.918L571.216 680.891L571.208 680.862C564.673 659.672 555.474 643.223 544.108 630.775C532.693 618.273 518.614 608.934 501.463 602.782L501.363 602.747L501.265 602.71C483.762 596.242 463.281 592.785 439.496 592.785H394.758V928.297H426.547C480.967 928.297 518.25 913.352 542.487 886.944C549.121 879.717 554.994 871.401 560.033 861.922C561.111 860.39 564.246 854.808 573 834.499C584.619 807.544 599.693 766.765 601.761 761.148L661.894 618.146C666.174 626.916 669.998 636.108 673.371 645.71L673.913 647.238C685.196 679.394 690.598 715.787 690.598 756.059C690.598 798.856 685.052 837.326 673.471 871.104L673.463 871.127L673.455 871.149C661.911 904.578 644.957 933.245 622.314 956.634L622.273 956.677L622.232 956.719C599.555 979.894 571.83 997.113 539.512 1008.54C507.506 1019.94 471.739 1025.42 432.523 1025.42H289V495.992H446.137Z" fill="white"/>
								<path d="M616.871 1008.83L611.653 1023.42H559.899C560.889 1022.84 561.878 1022.25 562.869 1021.66C572.706 1016.98 584.61 1009.66 596.743 1000.51C612.572 988.558 625.238 976.164 631.921 966.742L616.871 1008.83ZM789.137 506.43L967.77 993.852L978.606 1023.42H868.466L863.283 1008.75L815.341 873.012H665.442L660.936 885.612C645.359 865.615 597.716 873.225 546.771 901.743L691.374 506.442L696.657 492H783.849L789.137 506.43ZM740.108 658.854C739.653 660.193 739.217 661.462 738.796 662.657L700.642 774.227H780.332L741.401 662.695L741.35 662.549L741.301 662.402C740.931 661.294 740.533 660.112 740.108 658.854Z" fill="white"/>
								<path d="M1097.85 479.113V1037.79C1097.85 1127.72 1024.62 1200.53 934.597 1200.53H316.935H45.6949H0L317.13 1511.6V1351H934.597C1107.81 1351 1248.8 1210.65 1248.8 1037.79V479.113V403H1097.07L1097.85 479.113Z" fill="white"/>
								<path d="M936.745 165.657C935.964 165.657 935.378 165.657 934.597 165.657H314.201C140.99 165.657 0 306.007 0 478.867V1037.54V1113.66H151.926L150.949 1037.54V478.867C150.949 388.933 224.178 316.13 314.201 316.13H1203.1H1248.8L936.745 0V165.657Z" fill="white"/>
								</svg>'),
		];
		register_post_type( 'ae_global_templates', $args );
	}

	private function get_capabilities() {
		$capability = apply_filters( 'aepro/global_templates/capability', 'edit_theme_options' );

		return [
			'edit_posts'             => $capability,
			'edit_others_posts'      => $capability,
			'edit_published_posts'   => $capability,
			'edit_private_posts'     => $capability,
			'publish_posts'          => $capability,
			'read_private_posts'     => $capability,
			'delete_posts'           => $capability,
			'delete_others_posts'    => $capability,
			'delete_published_posts' => $capability,
			'delete_private_posts'   => $capability,
			'create_posts'           => $capability,
		];
	}
}
