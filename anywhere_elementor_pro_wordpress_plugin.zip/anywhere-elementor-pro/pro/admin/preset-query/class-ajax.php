<?php
namespace Aepro\Admin\PresetQuery;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Ajax {

	private static $_instance = null;

	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	private function __construct() {
		add_action( 'wp_ajax_ae_pq_preview',       [ $this, 'preview' ] );
		add_action( 'wp_ajax_ae_pq_get_terms',     [ $this, 'get_terms' ] );
		add_action( 'wp_ajax_ae_pq_get_authors',   [ $this, 'get_authors' ] );
		add_action( 'wp_ajax_ae_pq_get_posts',     [ $this, 'get_posts' ] );
		add_action( 'wp_ajax_ae_pq_toggle_status', [ $this, 'toggle_status' ] );
		add_action( 'wp_ajax_ae_pq_bulk_action',   [ $this, 'bulk_action' ] );
	}

	/**
	 * Returns all terms for a given taxonomy (slug + name + count).
	 */
	public function get_terms() {
		check_ajax_referer( 'ae_pq_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [], 403 );
		}

		$taxonomy = sanitize_key( $_POST['taxonomy'] ?? '' );

		if ( ! taxonomy_exists( $taxonomy ) ) {
			wp_send_json_error( [ 'message' => __( 'Invalid taxonomy.', 'ae-pro' ) ] );
		}

		$terms = get_terms( [
			'taxonomy'   => $taxonomy,
			'hide_empty' => false,
			'number'     => 500,
			'orderby'    => 'name',
		] );

		if ( is_wp_error( $terms ) ) {
			wp_send_json_error( [ 'message' => $terms->get_error_message() ] );
		}

		$result = [];
		foreach ( $terms as $term ) {
			$result[] = [
				'slug'  => $term->slug,
				'name'  => $term->name,
				'count' => $term->count,
			];
		}

		wp_send_json_success( $result );
	}

	/**
	 * Returns all users for the author filter dropdown.
	 */
	public function get_authors() {
		check_ajax_referer( 'ae_pq_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [], 403 );
		}

		$users = get_users( [
			'orderby' => 'display_name',
			'order'   => 'ASC',
			'number'  => 500,
			'fields'  => [ 'ID', 'display_name' ],
		] );

		$result = [];
		foreach ( $users as $user ) {
			$result[] = [
				'id'   => (int) $user->ID,
				'name' => $user->display_name,
			];
		}

		wp_send_json_success( $result );
	}

	/**
	 * Returns posts for the Exclude Post IDs Select2 — filtered by post type.
	 */
	public function get_posts() {
		check_ajax_referer( 'ae_pq_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [], 403 );
		}

		$post_type = sanitize_key( $_POST['post_type'] ?? 'post' );
		if ( ! post_type_exists( $post_type ) ) {
			wp_send_json_error( [ 'message' => __( 'Invalid post type.', 'ae-pro' ) ] );
		}

		$posts = get_posts( [
			'post_type'      => $post_type,
			'post_status'    => 'any',
			'posts_per_page' => 200,
			'orderby'        => 'title',
			'order'          => 'ASC',
			'fields'         => 'ids',
		] );

		$result = [];
		foreach ( $posts as $id ) {
			// get_post_field avoids the filter that converts & to &#x26; in get_the_title().
			$raw_title = get_post_field( 'post_title', $id );
			$result[]  = [
				'id'    => (int) $id,
				'title' => $raw_title !== '' ? $raw_title : '(no title) #' . $id,
			];
		}

		wp_send_json_success( $result );
	}

	/**
	 * Toggles a preset between Active (publish) and Inactive (draft).
	 */
	public function toggle_status() {
		check_ajax_referer( 'ae_pq_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [ 'message' => __( 'Insufficient permissions.', 'ae-pro' ) ], 403 );
		}

		$preset_id = absint( $_POST['preset_id'] ?? 0 );
		$post      = get_post( $preset_id );

		if ( ! $post || $post->post_type !== Cpt::POST_TYPE ) {
			wp_send_json_error( [ 'message' => __( 'Preset not found.', 'ae-pro' ) ] );
		}

		$new_status = $post->post_status === 'publish' ? 'draft' : 'publish';

		wp_update_post( [
			'ID'          => $preset_id,
			'post_status' => $new_status,
		] );

		wp_send_json_success( [
			'preset_id'  => $preset_id,
			'new_status' => $new_status,
			'active'     => $new_status === 'publish',
		] );
	}

	/**
	 * Processes a bulk action (activate / deactivate / delete) on multiple presets.
	 */
	public function bulk_action() {
		check_ajax_referer( 'ae_pq_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [ 'message' => __( 'Insufficient permissions.', 'ae-pro' ) ], 403 );
		}

		$action = sanitize_key( $_POST['bulk_action'] ?? '' );
		$ids    = array_map( 'absint', (array) ( $_POST['preset_ids'] ?? [] ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$ids    = array_filter( $ids );

		if ( empty( $ids ) || ! in_array( $action, [ 'activate', 'deactivate', 'delete' ], true ) ) {
			wp_send_json_error( [ 'message' => __( 'Invalid request.', 'ae-pro' ) ] );
		}

		$processed = [];
		foreach ( $ids as $id ) {
			$post = get_post( $id );
			if ( ! $post || $post->post_type !== Cpt::POST_TYPE ) {
				continue;
			}
			if ( $action === 'delete' ) {
				wp_delete_post( $id, true );
			} elseif ( $action === 'activate' ) {
				wp_update_post( [ 'ID' => $id, 'post_status' => 'publish' ] );
			} elseif ( $action === 'deactivate' ) {
				wp_update_post( [ 'ID' => $id, 'post_status' => 'draft' ] );
			}
			$processed[] = $id;
		}

		wp_send_json_success( [ 'processed' => $processed, 'action' => $action ] );
	}

	/**
	 * Returns a count + first 6 post titles for the live preview panel.
	 */
	public function preview() {
		check_ajax_referer( 'ae_pq_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [ 'message' => __( 'Insufficient permissions.', 'ae-pro' ) ], 403 );
		}

		$raw  = isset( $_POST['query_args'] ) ? wp_unslash( $_POST['query_args'] ) : '{}'; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$args = json_decode( $raw, true );

		if ( ! is_array( $args ) ) {
			wp_send_json_error( [ 'message' => __( 'Invalid query args JSON.', 'ae-pro' ) ] );
		}

		// Allowlist of safe WP_Query keys — reject anything not on the list.
		$allowed_query_keys = [
			'post_type', 'post_status', 'posts_per_page', 'offset', 'orderby', 'order',
			'meta_key', 's', 'author', 'author__in', 'author__not_in', 'author_name',
			'post__in', 'post__not_in', 'post_name__in',
			'post_parent', 'post_parent__in', 'post_parent__not_in',
			'tax_query', 'meta_query', 'date_query',
			'ignore_sticky_posts', 'suppress_filters',
			'cache_results', 'update_post_meta_cache', 'update_post_term_cache',
		];
		$args = array_intersect_key( $args, array_flip( $allowed_query_keys ) );

		// Pagination support.
		// Use the form's posts_per_page; treat -1 (show all) as 50 and cap at
		// 50 to keep the preview snappy without ignoring the user's setting.
		$raw_per_page = (int) ( $args['posts_per_page'] ?? 5 );
		$per_page     = $raw_per_page > 0 ? min( 50, $raw_per_page ) : 50;
		$page         = max( 1, absint( $_POST['page'] ?? 1 ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing

		// Force safe values for preview.
		$args['posts_per_page'] = $per_page;
		$args['paged']          = $page;
		$args['fields']         = 'ids';
		$args['no_found_rows']  = false;

		$query = new \WP_Query( $args );

		$posts = [];
		foreach ( $query->posts as $id ) {
			$posts[] = [
				'id'    => (int) $id,
				'title' => get_the_title( $id ),
			];
		}

		$total_pages = $per_page > 0 ? (int) ceil( $query->found_posts / $per_page ) : 1;

		wp_send_json_success( [
			'total'       => $query->found_posts,
			'posts'       => $posts,
			'page'        => $page,
			'per_page'    => $per_page,
			'total_pages' => $total_pages,
		] );
	}
}
