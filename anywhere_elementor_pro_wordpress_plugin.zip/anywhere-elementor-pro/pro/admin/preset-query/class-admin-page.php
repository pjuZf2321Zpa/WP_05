<?php
namespace Aepro\Admin\PresetQuery;

use Aepro\Aepro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Admin_Page {

	private static $_instance = null;

	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	private function __construct() {
		add_action( 'admin_menu',            [ $this, 'register_menu' ], 20 );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_assets' ] );
		add_action( 'admin_post_ae_pq_save',       [ $this, 'handle_save' ] );
		add_action( 'admin_post_ae_pq_delete',     [ $this, 'handle_delete' ] );
		add_action( 'admin_post_ae_pq_duplicate',  [ $this, 'handle_duplicate' ] );
		add_action( 'admin_post_ae_pq_export',     [ $this, 'handle_export' ] );
		add_action( 'admin_post_ae_pq_export_all',   [ $this, 'handle_export_all' ] );
		add_action( 'admin_post_ae_pq_bulk_export',  [ $this, 'handle_bulk_export' ] );
		add_action( 'admin_post_ae_pq_import',       [ $this, 'handle_import' ] );

		// Plugin top bar.
		add_filter( 'aepro/admin/ui/screens',     [ $this, 'register_screens' ] );
		add_filter( 'aepro/admin/ui/header_menu', [ $this, 'add_nav_link' ] );
	}

	// -------------------------------------------------------------------------
	// Menu
	// -------------------------------------------------------------------------

	public function register_menu() {
		add_submenu_page(
			'edit.php?post_type=ae_global_templates',
			__( 'Query Presets', 'ae-pro' ),
			__( 'Presets', 'ae-pro' ),
			'manage_options',
			'ae-preset-query',
			[ $this, 'render_page' ]
		);
	}

	// -------------------------------------------------------------------------
	// Router
	// -------------------------------------------------------------------------

	public function render_page() {
		$action    = sanitize_key( $_GET['action'] ?? 'list' );
		$preset_id = absint( $_GET['preset_id'] ?? 0 );

		if ( $action === 'edit' || $action === 'new' ) {
			$this->render_edit_page( $action === 'new' ? 0 : $preset_id );
		} else {
			$this->render_list_page();
		}
	}

	// -------------------------------------------------------------------------
	// List page
	// -------------------------------------------------------------------------

	private function render_list_page() {
		$notice = $this->get_notice();

		$presets = get_posts( [
			'post_type'      => Cpt::POST_TYPE,
			'post_status'    => [ 'publish', 'draft' ],
			'posts_per_page' => -1,
			'orderby'        => 'title',
			'order'          => 'ASC',
		] );

		$base_url       = admin_url( 'admin.php?page=ae-preset-query' );
		$add_url        = admin_url( 'admin.php?page=ae-preset-query&action=new' );
		$export_all_url = wp_nonce_url( admin_url( 'admin-post.php?action=ae_pq_export_all' ), 'ae_pq_export_all' );
		$tab_query_url  = $base_url;
		$tab_rules_url  = admin_url( 'admin.php?page=ae-preset-rules' );
		?>
		<div class="wrap ae-pq-page ae-pq-list-page">

			<?php echo $notice; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>

			<!-- Page header: h1 inline + actions float-right + wp-header-end so WP notices land below -->
			<h1 class="wp-heading-inline ae-pq-page-title">
				<?php esc_html_e( 'Presets', 'ae-pro' ); ?>
			</h1>

			<div class="ae-pq-list-actions">
				<button type="button" class="button ae-pq-import-trigger-btn" id="ae-pq-import-trigger">
					<?php esc_html_e( 'Import', 'ae-pro' ); ?>
				</button>
				<?php if ( ! empty( $presets ) ) : ?>
				<a href="<?php echo esc_url( $export_all_url ); ?>" class="button ae-pq-export-all-btn">
					<?php esc_html_e( 'Export All', 'ae-pro' ); ?>
				</a>
				<?php endif; ?>
				<a href="<?php echo esc_url( $add_url ); ?>" class="button button-primary button-large ae-pq-add-btn">
					+ <?php esc_html_e( 'Add New Preset', 'ae-pro' ); ?>
				</a>
			</div>

			<!-- Tells WP JS to inject admin_notices after this point, not inside the heading row -->
			<hr class="wp-header-end">

			<!-- Tab bar -->
			<div class="ae-pq-list-tabs">
				<a href="<?php echo esc_url( $tab_query_url ); ?>" class="ae-pq-list-tab ae-pq-list-tab--active">
					<?php esc_html_e( 'Query', 'ae-pro' ); ?>
				</a>
				<a href="<?php echo esc_url( $tab_rules_url ); ?>" class="ae-pq-list-tab">
					<?php esc_html_e( 'Rules', 'ae-pro' ); ?>
				</a>
			</div>

			<!-- Import form (hidden, Query tab only) -->
			<div id="ae-pq-import-wrap" class="ae-pq-import-wrap" style="display:none;">
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"
					enctype="multipart/form-data" class="ae-pq-import-form">
					<input type="hidden" name="action" value="ae_pq_import">
					<?php wp_nonce_field( 'ae_pq_import', 'ae_pq_import_nonce' ); ?>
					<label class="ae-pq-import-label">
						<span class="dashicons dashicons-media-document"></span>
						<?php esc_html_e( 'Choose JSON file', 'ae-pro' ); ?>
						<input type="file" name="ae_pq_import_file" accept=".json" required style="display:none;">
					</label>
					<span class="ae-pq-import-filename" id="ae-pq-import-filename">
						<?php esc_html_e( 'No file chosen', 'ae-pro' ); ?>
					</span>
					<button type="submit" class="button button-primary"><?php esc_html_e( 'Upload & Import', 'ae-pro' ); ?></button>
					<button type="button" class="button" id="ae-pq-import-cancel"><?php esc_html_e( 'Cancel', 'ae-pro' ); ?></button>
				</form>
			</div>

			<?php if ( empty( $presets ) ) : ?>

			<div class="ae-pq-empty-state">
				<div class="ae-pq-empty-icon">
					<svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
						<rect x="6" y="10" width="36" height="28" rx="3" stroke="#c3c4c7" stroke-width="2" fill="none"/>
						<line x1="13" y1="19" x2="35" y2="19" stroke="#c3c4c7" stroke-width="2" stroke-linecap="round"/>
						<line x1="13" y1="25" x2="29" y2="25" stroke="#c3c4c7" stroke-width="2" stroke-linecap="round"/>
						<line x1="13" y1="31" x2="23" y2="31" stroke="#c3c4c7" stroke-width="2" stroke-linecap="round"/>
					</svg>
				</div>
				<h2 class="ae-pq-empty-title"><?php esc_html_e( 'No presets yet', 'ae-pro' ); ?></h2>
				<p class="ae-pq-empty-desc"><?php esc_html_e( 'Build your first query preset to use across Elementor widgets, themes, and plugins.', 'ae-pro' ); ?></p>
				<a href="<?php echo esc_url( $add_url ); ?>" class="button button-primary button-large ae-pq-empty-cta">
					<?php esc_html_e( 'Create your first preset', 'ae-pro' ); ?>
				</a>
			</div>

			<?php else : ?>

			<div class="ae-pq-bulk-bar tablenav top">
				<div class="alignleft actions bulkactions">
					<label for="ae-pq-bulk-action" class="screen-reader-text"><?php esc_html_e( 'Select bulk action', 'ae-pro' ); ?></label>
					<select id="ae-pq-bulk-action">
						<option value=""><?php esc_html_e( '— Bulk Actions —', 'ae-pro' ); ?></option>
						<option value="activate"><?php esc_html_e( 'Activate', 'ae-pro' ); ?></option>
						<option value="deactivate"><?php esc_html_e( 'Deactivate', 'ae-pro' ); ?></option>
						<option value="export"><?php esc_html_e( 'Export', 'ae-pro' ); ?></option>
						<option value="delete"><?php esc_html_e( 'Delete', 'ae-pro' ); ?></option>
					</select>
					<button type="button" class="button action" id="ae-pq-bulk-apply" disabled>
						<?php esc_html_e( 'Apply', 'ae-pro' ); ?>
					</button>
					<span class="ae-pq-bulk-count" id="ae-pq-bulk-count"></span>
				</div>
			</div>

			<form id="ae-pq-bulk-export-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:none">
				<input type="hidden" name="action" value="ae_pq_bulk_export">
				<input type="hidden" name="ae_pq_bulk_nonce" value="<?php echo esc_attr( wp_create_nonce( 'ae_pq_bulk_export' ) ); ?>">
				<div id="ae-pq-bulk-export-ids"></div>
			</form>

			<table class="ae-pq-list-table widefat fixed">
				<thead>
					<tr>
						<th scope="col" class="manage-column column-cb check-column">
							<input type="checkbox" id="ae-pq-select-all">
						</th>
						<th class="ae-pq-col-name"><?php esc_html_e( 'Name', 'ae-pro' ); ?></th>
						<th class="ae-pq-col-status"><?php esc_html_e( 'Status', 'ae-pro' ); ?></th>
						<th class="ae-pq-col-usedin"><?php esc_html_e( 'Used In', 'ae-pro' ); ?></th>
						<th class="ae-pq-col-modified"><?php esc_html_e( 'Last Modified', 'ae-pro' ); ?></th>
						<th class="ae-pq-col-actions"><?php esc_html_e( 'Actions', 'ae-pro' ); ?></th>
					</tr>
				</thead>
				<tbody>
				<?php foreach ( $presets as $preset ) :
						$raw_args   = get_post_meta( $preset->ID, 'ae_preset_query_args', true );
						$args       = $raw_args ? json_decode( $raw_args, true ) : [];
						$is_active  = $preset->post_status === 'publish';
						$edit_url   = admin_url( 'admin.php?page=ae-preset-query&action=edit&preset_id=' . $preset->ID );
						$export_url = wp_nonce_url( admin_url( 'admin-post.php?action=ae_pq_export&preset_id=' . $preset->ID ), 'ae_pq_export_' . $preset->ID );
						$dup_url    = wp_nonce_url( admin_url( 'admin-post.php?action=ae_pq_duplicate&preset_id=' . $preset->ID ), 'ae_pq_duplicate_' . $preset->ID );
						$del_url    = wp_nonce_url( admin_url( 'admin-post.php?action=ae_pq_delete&preset_id=' . $preset->ID ), 'ae_pq_delete_' . $preset->ID );
						$code_args  = ! empty( $args ) ? wp_json_encode( $args, JSON_PRETTY_PRINT ) : '[]';
						$used_in    = $this->get_used_in( $preset->ID );
					?>
					<tr>
						<td class="check-column">
							<input type="checkbox" class="ae-pq-row-cb" value="<?php echo esc_attr( $preset->ID ); ?>">
						</td>
						<td class="ae-pq-col-name">
							<a href="<?php echo esc_url( $edit_url ); ?>" class="ae-pq-preset-name">
								<?php echo esc_html( $preset->post_title ?: __( '(no title)', 'ae-pro' ) ); ?>
							</a>
							<span class="ae-pq-preset-id">ID: <?php echo esc_html( $preset->ID ); ?></span>
						</td>
						<td>
							<button type="button"
								class="ae-pq-status-toggle<?php echo $is_active ? ' ae-pq-status-toggle--active' : ''; ?>"
								data-preset-id="<?php echo esc_attr( $preset->ID ); ?>"
								data-active="<?php echo $is_active ? '1' : '0'; ?>"
								title="<?php echo $is_active ? esc_attr__( 'Click to deactivate', 'ae-pro' ) : esc_attr__( 'Click to activate', 'ae-pro' ); ?>">
								<span class="ae-pq-status-toggle__dot"></span>
								<span class="ae-pq-status-toggle__label">
									<?php echo $is_active ? esc_html__( 'Active', 'ae-pro' ) : esc_html__( 'Inactive', 'ae-pro' ); ?>
								</span>
							</button>
						</td>
						<td class="ae-pq-col-usedin">
							<?php if ( empty( $used_in ) ) : ?>
								<span class="ae-pq-used-in-none">—</span>
							<?php else : ?>
								<?php
								$show = array_slice( $used_in, 0, 3 );
								$more = count( $used_in ) - count( $show );
								foreach ( $show as $item ) :
								?>
									<a href="<?php echo esc_url( $item['edit_url'] ); ?>"
										class="ae-pq-used-in-link" target="_blank">
										<?php echo esc_html( $item['title'] ); ?>
									</a>
								<?php endforeach; ?>
								<?php if ( $more > 0 ) : ?>
									<span class="ae-pq-used-in-more">+<?php echo esc_html( $more ); ?> more</span>
								<?php endif; ?>
							<?php endif; ?>
						</td>
						<td><?php echo esc_html( get_the_modified_date( 'Y-m-d H:i', $preset ) ); ?></td>
						<td class="ae-pq-col-actions">
							<a href="<?php echo esc_url( $edit_url ); ?>"><?php esc_html_e( 'Edit', 'ae-pro' ); ?></a>
							<span class="ae-pq-sep">|</span>
							<a href="<?php echo esc_url( $dup_url ); ?>"><?php esc_html_e( 'Duplicate', 'ae-pro' ); ?></a>
							<span class="ae-pq-sep">|</span>
							<a href="<?php echo esc_url( $export_url ); ?>"><?php esc_html_e( 'Export', 'ae-pro' ); ?></a>
							<span class="ae-pq-sep">|</span>
							<a href="<?php echo esc_url( $del_url ); ?>" class="ae-pq-delete-link"
								onclick="return confirm('<?php echo esc_js( __( 'Delete this preset? This cannot be undone.', 'ae-pro' ) ); ?>')">
								<?php esc_html_e( 'Delete', 'ae-pro' ); ?>
							</a>
						</td>
					</tr>
					<?php endforeach; ?>
				</tbody>
			</table>

			<?php endif; ?>

		</div>
		<?php
	}

	// -------------------------------------------------------------------------
	// Edit page
	// -------------------------------------------------------------------------

	private function render_edit_page( $preset_id ) {
		$post = $preset_id ? get_post( $preset_id ) : null;

		if ( $preset_id && ( ! $post || $post->post_type !== Cpt::POST_TYPE ) ) {
			wp_die( esc_html__( 'Preset not found.', 'ae-pro' ) );
		}

		$raw_args = $preset_id ? get_post_meta( $preset_id, 'ae_preset_query_args', true ) : '';
		$args     = $raw_args ? json_decode( $raw_args, true ) : [];
		if ( ! is_array( $args ) ) {
			$args = [];
		}

		$list_url    = admin_url( 'admin.php?page=ae-preset-query' );
		$export_url  = $preset_id ? wp_nonce_url( admin_url( 'admin-post.php?action=ae_pq_export&preset_id=' . $preset_id ), 'ae_pq_export_' . $preset_id ) : '';
		$notice      = $this->get_notice();

		$code_php_array  = $this->generate_php_array( $args );
		$code_wp_query   = $this->generate_wp_query( $args );
		$code_use_preset = $this->generate_use_preset( $preset_id );
		?>
		<div class="wrap ae-pq-page ae-pq-edit-page">

			<?php echo $notice; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>

			<h1 class="wp-heading-inline ae-pq-page-title">
				<?php echo $preset_id ? esc_html__( 'Edit Preset Query', 'ae-pro' ) : esc_html__( 'Add New Preset Query', 'ae-pro' ); ?>
			</h1>
			<hr class="wp-header-end">

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"
				id="ae-pq-edit-form">

				<input type="hidden" name="action" value="ae_pq_save">
				<input type="hidden" name="preset_id" value="<?php echo esc_attr( $preset_id ); ?>">
				<?php wp_nonce_field( 'ae_pq_save_' . $preset_id, 'ae_pq_save_nonce' ); ?>

				<!-- Header bar -->
				<?php $is_active = $post && $post->post_status === 'publish'; ?>
				<div class="ae-pq-edit-header">
					<div class="ae-pq-edit-header-left">
						<a href="<?php echo esc_url( $list_url ); ?>" class="ae-pq-back-link">
							<span class="dashicons dashicons-arrow-left-alt2"></span>
							<?php esc_html_e( 'All Presets', 'ae-pro' ); ?>
						</a>
						<input type="text" name="preset_title" id="ae-pq-title-input"
							class="ae-pq-title-input"
							value="<?php echo esc_attr( $post ? $post->post_title : '' ); ?>"
							placeholder="<?php esc_attr_e( 'Preset Name…', 'ae-pro' ); ?>">
					</div>
					<div class="ae-pq-edit-header-right">
						<?php if ( $preset_id ) : ?>
						<button type="button"
							class="ae-pq-status-toggle<?php echo $is_active ? ' ae-pq-status-toggle--active' : ''; ?>"
							data-preset-id="<?php echo esc_attr( $preset_id ); ?>"
							data-active="<?php echo $is_active ? '1' : '0'; ?>"
							title="<?php echo $is_active ? esc_attr__( 'Click to deactivate', 'ae-pro' ) : esc_attr__( 'Click to activate', 'ae-pro' ); ?>">
							<span class="ae-pq-status-toggle__dot"></span>
							<span class="ae-pq-status-toggle__label">
								<?php echo $is_active ? esc_html__( 'Active', 'ae-pro' ) : esc_html__( 'Inactive', 'ae-pro' ); ?>
							</span>
						</button>
						<?php endif; ?>
						<?php if ( $preset_id && $export_url ) : ?>
						<a href="<?php echo esc_url( $export_url ); ?>" class="button button-large ae-pq-header-btn">
							<span class="dashicons dashicons-download"></span>
							<?php esc_html_e( 'Export', 'ae-pro' ); ?>
						</a>
						<?php endif; ?>
						<button type="submit" class="button button-primary button-large ae-pq-save-btn">
							<span class="dashicons dashicons-saved"></span>
							<?php esc_html_e( 'Save Preset', 'ae-pro' ); ?>
						</button>
					</div>
				</div>

				<!-- Two-column layout -->
				<div class="ae-pq-edit-columns">

					<div class="ae-pq-edit-main">
						<?php $this->render_accordion_sections( $args ); ?>
					</div>

					<div class="ae-pq-edit-sidebar">
						<?php $this->render_code_sidebar( $preset_id, $code_php_array, $code_wp_query, $code_use_preset ); ?>
					</div>

				</div>

			</form>
		</div>
		<?php
	}

	// -------------------------------------------------------------------------
	// Accordion sections
	// -------------------------------------------------------------------------

	private function render_accordion_sections( $args ) {
		$post_types      = Aepro::$_helper->get_rule_post_types();
		$source          = $args['post_type'] ?? key( $post_types );
		$current_orderby = $args['orderby'] ?? 'date';
		$stored_post_in = array_values( array_filter( array_map( 'intval', (array) ( $args['post__in'] ?? [] ) ) ) );
		$stored_post_not_in = array_values( array_filter( array_map( 'intval', (array) ( $args['post__not_in'] ?? [] ) ) ) );
		$stored_post_parent_in = array_values( array_filter( array_map( 'intval', (array) ( $args['post_parent__in'] ?? [] ) ) ) );
		$stored_post_parent = isset( $args['post_parent'] ) ? (int) $args['post_parent'] : null;
		if ( $stored_post_parent > 0 && ! in_array( $stored_post_parent, $stored_post_parent_in, true ) ) {
			$stored_post_parent_in[] = $stored_post_parent;
		}
		$stored_post_parent_not_in = array_values( array_filter( array_map( 'intval', (array) ( $args['post_parent__not_in'] ?? [] ) ) ) );
		$top_level_only = $stored_post_parent === 0;
		$has_post_page = ! empty( $stored_post_in ) || ! empty( $stored_post_not_in ) || $top_level_only || ! empty( $stored_post_parent_in ) || ! empty( $stored_post_parent_not_in );

		// Meta query — open accordion if any clauses are stored.
		$has_meta = ! empty( $args['meta_query'] ) && is_array( $args['meta_query'] );

		// Date query data.
		$date_query_raw = is_array( $args['date_query'] ?? null ) ? $args['date_query'] : [];
		$date_clause    = [];
		foreach ( $date_query_raw as $item ) {
			if ( is_array( $item ) ) {
				$date_clause = $item;
				break;
			}
		}
		$date_mode      = $args['_ae_date_mode'] ?? ( ! empty( $date_clause ) ? 'static' : '' );
		$date_column    = $date_clause['column']    ?? 'post_date';
		$date_after     = $date_mode !== 'relative' ? ( $date_clause['after'] ?? '' ) : '';
		$date_before    = $date_clause['before']    ?? '';
		$date_relative  = $date_mode === 'relative' ? ( $date_clause['after'] ?? '' ) : '';
		$date_inclusive = isset( $date_clause['inclusive'] ) ? (bool) $date_clause['inclusive'] : true;
		$has_date       = ! empty( $date_clause );
		$relative_opts  = [
			'7 days ago'                     => __( 'Last 7 days', 'ae-pro' ),
			'30 days ago'                    => __( 'Last 30 days', 'ae-pro' ),
			'90 days ago'                    => __( 'Last 90 days', 'ae-pro' ),
			'first day of this month'        => __( 'This month', 'ae-pro' ),
			'first day of last month'        => __( 'Last month', 'ae-pro' ),
			'first day of January this year' => __( 'This year', 'ae-pro' ),
		];
		?>

		<div class="ae-pq-accordion">

			<!-- Basic Query -->
			<div class="ae-pq-section-card">
			<div class="ae-pq-section-header" data-target="ae-pq-section-basic">
				<span class="ae-pq-section-icon">⚙️</span>
				<h3><?php esc_html_e( 'Basic Query', 'ae-pro' ); ?></h3>
				<span class="ae-pq-section-toggle dashicons dashicons-arrow-down-alt2"></span>
			</div>
			<div class="ae-pq-section-body" id="ae-pq-section-basic">
				<div class="ae-pq-row">
					<div class="ae-pq-field">
						<label for="ae_pq_post_type"><?php esc_html_e( 'Post Type', 'ae-pro' ); ?></label>
						<select id="ae_pq_post_type" name="ae_pq_args[post_type]">
							<?php foreach ( $post_types as $pt_key => $pt_label ) : ?>
								<option value="<?php echo esc_attr( $pt_key ); ?>" <?php selected( $source, $pt_key ); ?>>
									<?php echo esc_html( $pt_label ); ?>
								</option>
							<?php endforeach; ?>
						</select>
					</div>
					<div class="ae-pq-field">
						<label for="ae_pq_posts_per_page"><?php esc_html_e( 'Posts Per Page', 'ae-pro' ); ?></label>
						<input type="number" id="ae_pq_posts_per_page" name="ae_pq_args[posts_per_page]"
							value="<?php echo esc_attr( $args['posts_per_page'] ?? 6 ); ?>" min="-1">
						<p class="description"><?php esc_html_e( 'Use -1 for all. The Test Query preview is capped at 50.', 'ae-pro' ); ?></p>
					</div>
					<div class="ae-pq-field">
						<label for="ae_pq_post_status"><?php esc_html_e( 'Post Status', 'ae-pro' ); ?></label>
						<select id="ae_pq_post_status" name="ae_pq_args[post_status]">
							<option value="publish" <?php selected( $args['post_status'] ?? 'publish', 'publish' ); ?>><?php esc_html_e( 'Published', 'ae-pro' ); ?></option>
							<option value="draft"   <?php selected( $args['post_status'] ?? '', 'draft' ); ?>><?php esc_html_e( 'Draft', 'ae-pro' ); ?></option>
							<option value="private" <?php selected( $args['post_status'] ?? '', 'private' ); ?>><?php esc_html_e( 'Private', 'ae-pro' ); ?></option>
							<option value="any"     <?php selected( $args['post_status'] ?? '', 'any' ); ?>><?php esc_html_e( 'Any', 'ae-pro' ); ?></option>
						</select>
					</div>
				</div>
				<div class="ae-pq-row">
					<div class="ae-pq-field">
						<label for="ae_pq_orderby"><?php esc_html_e( 'Order By', 'ae-pro' ); ?></label>
						<select id="ae_pq_orderby" name="ae_pq_args[orderby]">
							<?php
							$orderby_options = [
								'date'           => __( 'Date', 'ae-pro' ),
								'title'          => __( 'Title', 'ae-pro' ),
								'modified'       => __( 'Last Modified', 'ae-pro' ),
								'menu_order'     => __( 'Menu Order', 'ae-pro' ),
								'rand'           => __( 'Random', 'ae-pro' ),
								'comment_count'  => __( 'Comment Count', 'ae-pro' ),
								'meta_value'     => __( 'Meta Value (text)', 'ae-pro' ),
								'meta_value_num' => __( 'Meta Value (numeric)', 'ae-pro' ),
							];
							foreach ( $orderby_options as $val => $label ) :
								?>
								<option value="<?php echo esc_attr( $val ); ?>" <?php selected( $current_orderby, $val ); ?>>
									<?php echo esc_html( $label ); ?>
								</option>
							<?php endforeach; ?>
						</select>
					</div>
					<div class="ae-pq-field">
						<label for="ae_pq_order"><?php esc_html_e( 'Order', 'ae-pro' ); ?></label>
						<select id="ae_pq_order" name="ae_pq_args[order]">
							<option value="DESC" <?php selected( $args['order'] ?? 'DESC', 'DESC' ); ?>><?php esc_html_e( 'Descending', 'ae-pro' ); ?></option>
							<option value="ASC"  <?php selected( $args['order'] ?? '', 'ASC' ); ?>><?php esc_html_e( 'Ascending', 'ae-pro' ); ?></option>
						</select>
					</div>
					<div class="ae-pq-field">
						<label for="ae_pq_offset"><?php esc_html_e( 'Offset', 'ae-pro' ); ?></label>
						<input type="number" id="ae_pq_offset" name="ae_pq_args[offset]"
							value="<?php echo esc_attr( $args['offset'] ?? 0 ); ?>" min="0">
					</div>
					<div class="ae-pq-field ae-pq-field--meta-key js-ae-pq-meta-order"
						style="<?php echo in_array( $current_orderby, [ 'meta_value', 'meta_value_num' ], true ) ? '' : 'display:none'; ?>">
						<label for="ae_pq_meta_key_order"><?php esc_html_e( 'Meta Key', 'ae-pro' ); ?></label>
						<input type="text" id="ae_pq_meta_key_order" name="ae_pq_args[meta_key]"
							value="<?php echo esc_attr( $args['meta_key'] ?? '' ); ?>"
							placeholder="<?php esc_attr_e( 'e.g. _price', 'ae-pro' ); ?>">
					</div>
				</div>
				<div class="ae-pq-row">
					<div class="ae-pq-field ae-pq-field--checkbox">
						<label>
							<input type="checkbox" name="ae_pq_args[ignore_sticky_posts]" value="1"
								<?php checked( ! empty( $args['ignore_sticky_posts'] ) ); ?>>
							<?php esc_html_e( 'Ignore Sticky Posts', 'ae-pro' ); ?>
						</label>
					</div>
					<div class="ae-pq-field ae-pq-field--checkbox">
						<label>
							<input type="checkbox" name="ae_pq_exclude_current" value="1"
								<?php checked( ! empty( $args['_ae_exclude_current'] ) ); ?>>
							<?php esc_html_e( 'Exclude Current Post (runtime)', 'ae-pro' ); ?>
						</label>
					</div>
				</div>
			</div><!-- /Basic Query body -->
			</div><!-- /Basic Query card -->

			<!-- Posts -->
			<div class="ae-pq-section-card">
			<div class="ae-pq-section-header<?php echo $has_post_page ? '' : ' ae-pq-section-header--collapsed'; ?>" data-target="ae-pq-section-post-page">
				<span class="ae-pq-section-icon">📄</span>
				<h3><?php esc_html_e( 'Posts', 'ae-pro' ); ?></h3>
				<span class="ae-pq-section-toggle dashicons dashicons-arrow-down-alt2"></span>
			</div>
			<div class="ae-pq-section-body<?php echo $has_post_page ? '' : ' ae-pq-section-body--collapsed'; ?>" id="ae-pq-section-post-page">
				<div class="ae-pq-row">
					<div class="ae-pq-field">
						<label for="ae_pq_post_in"><?php esc_html_e( 'Include Posts', 'ae-pro' ); ?></label>
						<select id="ae_pq_post_in" name="ae_pq_post_in[]" multiple
							data-stored="<?php echo esc_attr( implode( ',', $stored_post_in ) ); ?>">
						</select>
					</div>
					<div class="ae-pq-field">
						<label for="ae_pq_post_not_in"><?php esc_html_e( 'Exclude Posts', 'ae-pro' ); ?></label>
						<select id="ae_pq_post_not_in" name="ae_pq_post_not_in[]" multiple
							data-stored="<?php echo esc_attr( implode( ',', $stored_post_not_in ) ); ?>">
						</select>
					</div>
				</div>
				<div class="ae-pq-row">
					<div class="ae-pq-field">
						<label for="ae_pq_post_parent_in"><?php esc_html_e( 'Post Parent In', 'ae-pro' ); ?></label>
						<select id="ae_pq_post_parent_in" name="ae_pq_post_parent_in[]" multiple
							data-stored="<?php echo esc_attr( implode( ',', $stored_post_parent_in ) ); ?>">
						</select>
					</div>
					<div class="ae-pq-field">
						<label for="ae_pq_post_parent_not_in"><?php esc_html_e( 'Post Parent Not In', 'ae-pro' ); ?></label>
						<select id="ae_pq_post_parent_not_in" name="ae_pq_post_parent_not_in[]" multiple
							data-stored="<?php echo esc_attr( implode( ',', $stored_post_parent_not_in ) ); ?>">
						</select>
					</div>
				</div>
				<div class="ae-pq-row">
					<div class="ae-pq-field ae-pq-field--checkbox ae-pq-field--top-level-toggle">
						<label>
							<input type="checkbox" id="ae_pq_post_parent_top_level" name="ae_pq_post_parent_top_level" value="1"
								<?php checked( $top_level_only ); ?>>
							<span class="ae-pq-top-level-copy">
								<strong><?php esc_html_e( 'Top-level only', 'ae-pro' ); ?></strong>
								<small><?php esc_html_e( 'Ignore parent include/exclude lists and match only posts with no parent.', 'ae-pro' ); ?></small>
							</span>
						</label>
					</div>
				</div>
			</div><!-- /Post & Page body -->
			</div><!-- /Post & Page card -->

			<!-- Taxonomy Query — nested group builder (JS-rendered) -->
			<?php $has_tax = ! empty( $args['tax_query'] ) && is_array( $args['tax_query'] ); ?>
			<div class="ae-pq-section-card">
			<div class="ae-pq-section-header<?php echo $has_tax ? '' : ' ae-pq-section-header--collapsed'; ?>" data-target="ae-pq-section-taxonomy">
				<span class="ae-pq-section-icon">🏷️</span>
				<h3><?php esc_html_e( 'Taxonomy Query', 'ae-pro' ); ?></h3>
				<span class="ae-pq-section-toggle dashicons dashicons-arrow-down-alt2"></span>
			</div>
			<div class="ae-pq-section-body<?php echo $has_tax ? '' : ' ae-pq-section-body--collapsed'; ?>" id="ae-pq-section-taxonomy">
				<div id="ae-pq-tax-builder"></div>
				<input type="hidden" name="ae_pq_tax_json" id="ae_pq_tax_json" value="">
			</div>
			</div><!-- /Taxonomy Query card -->

			<!-- Meta Query — nested group builder (JS-rendered) -->
			<div class="ae-pq-section-card">
			<div class="ae-pq-section-header<?php echo $has_meta ? '' : ' ae-pq-section-header--collapsed'; ?>" data-target="ae-pq-section-meta">
				<span class="ae-pq-section-icon">🔑</span>
				<h3><?php esc_html_e( 'Meta Query', 'ae-pro' ); ?></h3>
				<span class="ae-pq-section-toggle dashicons dashicons-arrow-down-alt2"></span>
			</div>
			<div class="ae-pq-section-body<?php echo $has_meta ? '' : ' ae-pq-section-body--collapsed'; ?>" id="ae-pq-section-meta">
				<div id="ae-pq-meta-builder"></div>
				<input type="hidden" name="ae_pq_meta_json" id="ae_pq_meta_json" value="">
			</div>
			</div><!-- /Meta Query card -->

			<!-- Date Query -->
			<div class="ae-pq-section-card">
			<div class="ae-pq-section-header<?php echo $has_date ? '' : ' ae-pq-section-header--collapsed'; ?>" data-target="ae-pq-section-dates">
				<span class="ae-pq-section-icon">📅</span>
				<h3><?php esc_html_e( 'Date Query', 'ae-pro' ); ?></h3>
				<span class="ae-pq-section-toggle dashicons dashicons-arrow-down-alt2"></span>
			</div>
			<div class="ae-pq-section-body<?php echo $has_date ? '' : ' ae-pq-section-body--collapsed'; ?>" id="ae-pq-section-dates">
				<div class="ae-pq-row">
					<div class="ae-pq-field" style="max-width:160px;flex:0 0 160px;">
						<label for="ae_pq_date_mode"><?php esc_html_e( 'Mode', 'ae-pro' ); ?></label>
						<select name="ae_pq_date[mode]" id="ae_pq_date_mode">
							<option value="static"   <?php selected( $date_mode, 'static' ); ?>><?php esc_html_e( 'Static Range', 'ae-pro' ); ?></option>
							<option value="relative" <?php selected( $date_mode, 'relative' ); ?>><?php esc_html_e( 'Relative', 'ae-pro' ); ?></option>
						</select>
					</div>
					<div class="ae-pq-field" style="max-width:220px;flex:0 0 220px;">
						<label for="ae_pq_date_column"><?php esc_html_e( 'Column', 'ae-pro' ); ?></label>
						<select name="ae_pq_date[column]" id="ae_pq_date_column">
							<option value="post_date"     <?php selected( $date_column, 'post_date' ); ?>><?php esc_html_e( 'Post Date', 'ae-pro' ); ?></option>
							<option value="post_modified" <?php selected( $date_column, 'post_modified' ); ?>><?php esc_html_e( 'Post Modified', 'ae-pro' ); ?></option>
						</select>
					</div>
				</div>
				<div id="ae-pq-date-static"<?php echo $date_mode === 'relative' ? ' style="display:none"' : ''; ?>>
					<div class="ae-pq-row">
						<div class="ae-pq-field">
							<label for="ae_pq_date_after"><?php esc_html_e( 'After (from)', 'ae-pro' ); ?></label>
							<input type="date" name="ae_pq_date[after]" id="ae_pq_date_after"
								value="<?php echo esc_attr( $date_after ); ?>">
						</div>
						<div class="ae-pq-field">
							<label for="ae_pq_date_before"><?php esc_html_e( 'Before (to)', 'ae-pro' ); ?></label>
							<input type="date" name="ae_pq_date[before]" id="ae_pq_date_before"
								value="<?php echo esc_attr( $date_before ); ?>">
						</div>
					</div>
				</div>
				<div id="ae-pq-date-relative"<?php echo $date_mode !== 'relative' ? ' style="display:none"' : ''; ?>>
					<div class="ae-pq-row">
						<div class="ae-pq-field">
							<label for="ae_pq_date_relative_val"><?php esc_html_e( 'Period', 'ae-pro' ); ?></label>
							<select name="ae_pq_date[relative]" id="ae_pq_date_relative_val">
								<?php foreach ( $relative_opts as $val => $label ) : ?>
									<option value="<?php echo esc_attr( $val ); ?>" <?php selected( $date_relative, $val ); ?>>
										<?php echo esc_html( $label ); ?>
									</option>
								<?php endforeach; ?>
							</select>
						</div>
					</div>
				</div>
				<div class="ae-pq-row">
					<div class="ae-pq-field ae-pq-field--checkbox">
						<label>
							<input type="checkbox" name="ae_pq_date[inclusive]" value="1" <?php checked( $date_inclusive ); ?>>
							<?php esc_html_e( 'Inclusive (include boundary dates)', 'ae-pro' ); ?>
						</label>
					</div>
				</div>
			</div><!-- /Date Query body -->
			</div><!-- /Date Query card -->

			<!-- Author -->
			<div class="ae-pq-section-card">
			<div class="ae-pq-section-header ae-pq-section-header--collapsed" data-target="ae-pq-section-authors">
				<span class="ae-pq-section-icon">👤</span>
				<h3><?php esc_html_e( 'Author', 'ae-pro' ); ?></h3>
				<span class="ae-pq-section-toggle dashicons dashicons-arrow-down-alt2"></span>
			</div>
			<div class="ae-pq-section-body ae-pq-section-body--collapsed" id="ae-pq-section-authors">
				<div class="ae-pq-row">
					<div class="ae-pq-field">
						<label for="ae_pq_author_ids"><?php esc_html_e( 'Authors', 'ae-pro' ); ?></label>
						<select multiple name="ae_pq_author_ids[]" id="ae_pq_author_ids">
							<option disabled><?php esc_html_e( 'Loading…', 'ae-pro' ); ?></option>
						</select>
					</div>
					<div class="ae-pq-field" style="flex:0 0 140px;">
						<label for="ae_pq_author_operator"><?php esc_html_e( 'Operator', 'ae-pro' ); ?></label>
						<select name="ae_pq_author_operator" id="ae_pq_author_operator">
							<option value="in"><?php esc_html_e( 'Include', 'ae-pro' ); ?></option>
							<option value="not_in"><?php esc_html_e( 'Exclude', 'ae-pro' ); ?></option>
						</select>
					</div>
				</div>
			</div><!-- /Author body -->
			</div><!-- /Author card -->

			<!-- Search -->
			<?php $has_search = ! empty( $args['s'] ); ?>
			<div class="ae-pq-section-card">
			<div class="ae-pq-section-header<?php echo $has_search ? '' : ' ae-pq-section-header--collapsed'; ?>" data-target="ae-pq-section-search">
				<span class="ae-pq-section-icon">🔍</span>
				<h3><?php esc_html_e( 'Search', 'ae-pro' ); ?></h3>
				<span class="ae-pq-section-toggle dashicons dashicons-arrow-down-alt2"></span>
			</div>
			<div class="ae-pq-section-body<?php echo $has_search ? '' : ' ae-pq-section-body--collapsed'; ?>" id="ae-pq-section-search">
				<div class="ae-pq-row">
					<div class="ae-pq-field">
						<label for="ae_pq_search"><?php esc_html_e( 'Search Keywords', 'ae-pro' ); ?></label>
						<input type="text" id="ae_pq_search" name="ae_pq_args[s]"
							value="<?php echo esc_attr( $args['s'] ?? '' ); ?>"
							placeholder="<?php esc_attr_e( 'Search term…', 'ae-pro' ); ?>">
					</div>
				</div>
			</div><!-- /Search body -->
			</div><!-- /Search card -->

		</div><!-- /.ae-pq-accordion -->
		<?php
	}

	// -------------------------------------------------------------------------
	// Right sidebar
	// -------------------------------------------------------------------------

	private function render_code_sidebar( $preset_id, $code_php_array, $code_wp_query, $code_use_preset ) {
		?>
		<div class="ae-pq-sidebar-panel">

			<div class="ae-pq-code-panel">
				<div class="ae-pq-code-tabs-bar">
					<div class="ae-pq-code-tabs">
						<button type="button" class="ae-pq-code-tab ae-pq-code-tab--active" data-code-tab="php_array">PHP Array</button>
						<button type="button" class="ae-pq-code-tab" data-code-tab="wp_query">WP_Query</button>
						<button type="button" class="ae-pq-code-tab" data-code-tab="use_preset">Use Preset</button>
					</div>
				</div>
				<div class="ae-pq-code-content">
					<pre id="ae-pq-code-php_array" class="ae-pq-code-block ae-pq-code-block--active"><?php echo esc_html( $code_php_array ); ?></pre>
					<pre id="ae-pq-code-wp_query"  class="ae-pq-code-block" style="display:none"><?php echo esc_html( $code_wp_query ); ?></pre>
					<pre id="ae-pq-code-use_preset" class="ae-pq-code-block" style="display:none"><?php echo esc_html( $code_use_preset ); ?></pre>
				</div>
				<div class="ae-pq-code-footer">
					<button type="button" class="ae-pq-copy-btn" id="ae-pq-copy-code">
						<span class="dashicons dashicons-clipboard"></span>
						<?php esc_html_e( 'Copy', 'ae-pro' ); ?>
					</button>
				</div>
			</div>

			<div class="ae-pq-preview-panel">
				<div class="ae-pq-preview-btn-wrap">
					<button type="button" class="button button-primary button-large ae-pq-run-preview-btn" id="ae-pq-run-preview">
						<?php esc_html_e( '▶ Test Query', 'ae-pro' ); ?>
					</button>
				</div>
				<div id="ae-pq-preview-results" style="display:none">
					<p class="ae-pq-preview-count" id="ae-pq-preview-count-text"></p>
					<ul id="ae-pq-preview-titles" class="ae-pq-preview-list"></ul>
					<div class="ae-pq-preview-pagination" id="ae-pq-preview-pagination" style="display:none">
						<button type="button" class="button" id="ae-pq-prev-page">
							&larr; <?php esc_html_e( 'Previous', 'ae-pro' ); ?>
						</button>
						<span id="ae-pq-page-info"></span>
						<button type="button" class="button ae-pq-next-page-btn" id="ae-pq-next-page">
							<?php esc_html_e( 'Next', 'ae-pro' ); ?> &rarr;
						</button>
					</div>
				</div>
			</div>

		</div>
		<?php
	}

	// -------------------------------------------------------------------------
	// Code generators
	// -------------------------------------------------------------------------

	private function generate_php_array( array $args ) {
		$prefix = '// Generated by Dynific Query Engine' . "\n";
		if ( empty( $args ) ) {
			return $prefix . '$args = [];';
		}
		$export = var_export( $args, true );
		// Convert array() to [] syntax.
		$export = preg_replace( '/array \(/', '[', $export );
		$export = preg_replace( '/\),/', '],', $export );
		$export = preg_replace( '/\)\z/', ']', $export );
		return $prefix . '$args = ' . $export . ';';
	}

	private function generate_wp_query( array $args ) {
		if ( empty( $args ) ) {
			return '$query = new WP_Query( [] );';
		}
		$php_array = $this->generate_php_array( $args );
		$inner     = preg_replace( '/^\$args = /', '', rtrim( $php_array, ';' ) );
		return '$query = new WP_Query( ' . $inner . " );\n\nwhile ( \$query->have_posts() ) {\n\t\$query->the_post();\n\t// ...\n}\nwp_reset_postdata();";
	}

	private function generate_use_preset( $preset_id ) {
		if ( ! $preset_id ) {
			return '// Save this preset first to get its ID.';
		}
		return "// In Elementor: open the Post Blocks (Advanced) widget,\n// set Source → \"Preset Query\", then choose\n// this preset (ID: {$preset_id}).";
	}

	// -------------------------------------------------------------------------
	// Action handlers
	// -------------------------------------------------------------------------

	public function handle_save() {
		$preset_id = absint( $_POST['preset_id'] ?? 0 );
		check_admin_referer( 'ae_pq_save_' . $preset_id, 'ae_pq_save_nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Insufficient permissions.', 'ae-pro' ) );
		}

		$title = sanitize_text_field( wp_unslash( $_POST['preset_title'] ?? '' ) );

		if ( $preset_id ) {
			// Verify the ID belongs to our CPT before touching it.
			$post = get_post( $preset_id );
			if ( ! $post || $post->post_type !== Cpt::POST_TYPE ) {
				wp_die( esc_html__( 'Invalid preset.', 'ae-pro' ) );
			}
			// Preserve the current publish/draft status — never force-publish on save.
			$post_status = $post->post_status === 'draft' ? 'draft' : 'publish';
			wp_update_post( [
				'ID'          => $preset_id,
				'post_title'  => $title ?: __( 'Untitled Preset', 'ae-pro' ),
				'post_status' => $post_status,
			] );
		} else {
			$preset_id = wp_insert_post( [
				'post_type'   => Cpt::POST_TYPE,
				'post_title'  => $title ?: __( 'Untitled Preset', 'ae-pro' ),
				'post_status' => 'publish',
			] );
			if ( is_wp_error( $preset_id ) ) {
				wp_safe_redirect( add_query_arg( 'ae_pq_error', urlencode( $preset_id->get_error_message() ), admin_url( 'admin.php?page=ae-preset-query' ) ) );
				exit;
			}
		}

		$query_args = $this->build_query_args_from_post();

		update_post_meta( $preset_id, 'ae_preset_query_args', wp_json_encode( $query_args ) );
		delete_transient( 'ae_pq_used_in_' . $preset_id );

		wp_safe_redirect( admin_url( 'admin.php?page=ae-preset-query&action=edit&preset_id=' . $preset_id . '&ae_pq_saved=1' ) );
		exit;
	}

	public function handle_delete() {
		$preset_id = absint( $_GET['preset_id'] ?? 0 );
		check_admin_referer( 'ae_pq_delete_' . $preset_id );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Insufficient permissions.', 'ae-pro' ) );
		}

		$post = get_post( $preset_id );
		if ( $post && $post->post_type === Cpt::POST_TYPE ) {
			wp_delete_post( $preset_id, true );
		}

		wp_safe_redirect( admin_url( 'admin.php?page=ae-preset-query&ae_pq_deleted=1' ) );
		exit;
	}

	public function handle_duplicate() {
		$preset_id = absint( $_GET['preset_id'] ?? 0 );
		check_admin_referer( 'ae_pq_duplicate_' . $preset_id );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Insufficient permissions.', 'ae-pro' ) );
		}

		$post = get_post( $preset_id );
		if ( ! $post || $post->post_type !== Cpt::POST_TYPE ) {
			wp_safe_redirect( admin_url( 'admin.php?page=ae-preset-query' ) );
			exit;
		}

		$new_id = wp_insert_post( [
			'post_type'   => Cpt::POST_TYPE,
			'post_title'  => $post->post_title . ' ' . __( '(Copy)', 'ae-pro' ),
			'post_status' => 'draft',
		] );

		if ( ! is_wp_error( $new_id ) ) {
			update_post_meta( $new_id, 'ae_preset_query_args', get_post_meta( $preset_id, 'ae_preset_query_args', true ) );
		}

		wp_safe_redirect( admin_url( 'admin.php?page=ae-preset-query&ae_pq_duplicated=1' ) );
		exit;
	}

	/**
	 * Find all posts/pages whose Elementor data references a given preset ID.
	 *
	 * Searches the _elementor_data JSON meta for the widget setting
	 * ae_preset_query_id matching this preset. Results are cached in a
	 * short-lived transient so the list table stays snappy.
	 *
	 * @param int $preset_id The preset CPT post ID.
	 * @return array[] Each element: [ 'id' => int, 'title' => string, 'edit_url' => string ]
	 */
	private function get_used_in( $preset_id ) {
		$cache_key = 'ae_pq_used_in_' . $preset_id;
		$cached    = get_transient( $cache_key );
		if ( false !== $cached ) {
			return $cached;
		}

		global $wpdb;

		// Elementor may store the ID as a quoted string or bare integer.
		$search_str = $wpdb->esc_like( '"ae_preset_query_id":"' . (int) $preset_id . '"' );
		$search_int = $wpdb->esc_like( '"ae_preset_query_id":' . (int) $preset_id );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$post_ids = $wpdb->get_col( $wpdb->prepare(
			"SELECT DISTINCT pm.post_id
			 FROM {$wpdb->postmeta} pm
			 INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
			 WHERE pm.meta_key = '_elementor_data'
			   AND ( pm.meta_value LIKE %s OR pm.meta_value LIKE %s )
			   AND p.post_status IN ('publish','draft','private','pending','future')
			   AND p.post_type  != 'revision'
			 LIMIT 20",
			'%' . $search_str . '%',
			'%' . $search_int . '%'
		) );

		$results = [];
		foreach ( (array) $post_ids as $pid ) {
			$pid = (int) $pid;
			$results[] = [
				'id'       => $pid,
				'title'    => get_the_title( $pid ) ?: __( '(no title)', 'ae-pro' ),
				'edit_url' => (string) get_edit_post_link( $pid ),
			];
		}

		set_transient( $cache_key, $results, 5 * MINUTE_IN_SECONDS );
		return $results;
	}

	public function handle_export() {
		$preset_id = absint( $_GET['preset_id'] ?? 0 );
		check_admin_referer( 'ae_pq_export_' . $preset_id );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Insufficient permissions.', 'ae-pro' ) );
		}

		$post = get_post( $preset_id );
		if ( ! $post || $post->post_type !== Cpt::POST_TYPE ) {
			wp_die( esc_html__( 'Preset not found.', 'ae-pro' ) );
		}

		$raw_args = get_post_meta( $preset_id, 'ae_preset_query_args', true );
		$export   = [
			'version'    => 1,
			'title'      => $post->post_title,
			'status'     => $post->post_status,
			'query_args' => $raw_args ? json_decode( $raw_args, true ) : [],
		];

		$filename = 'preset-' . sanitize_title( $post->post_title ) . '-' . $preset_id . '.json';
		header( 'Content-Type: application/json' );
		header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
		header( 'Cache-Control: no-cache, no-store, must-revalidate' );
		echo wp_json_encode( $export, JSON_PRETTY_PRINT ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		exit;
	}

	public function handle_export_all() {
		check_admin_referer( 'ae_pq_export_all' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Insufficient permissions.', 'ae-pro' ) );
		}

		$presets = get_posts( [
			'post_type'      => Cpt::POST_TYPE,
			'post_status'    => [ 'publish', 'draft' ],
			'posts_per_page' => -1,
		] );

		$export = [ 'version' => 1, 'presets' => [] ];
		foreach ( $presets as $post ) {
			$raw_args              = get_post_meta( $post->ID, 'ae_preset_query_args', true );
			$export['presets'][]   = [
				'title'      => $post->post_title,
				'status'     => $post->post_status,
				'query_args' => $raw_args ? json_decode( $raw_args, true ) : [],
			];
		}

		// phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped
		header( 'Content-Type: application/json' );
		header( 'Content-Disposition: attachment; filename="preset-queries-' . gmdate( 'Y-m-d' ) . '.json"' );
		header( 'Cache-Control: no-cache, no-store, must-revalidate' );
		echo wp_json_encode( $export, JSON_PRETTY_PRINT );
		// phpcs:enable
		exit;
	}

	public function handle_bulk_export() {
		check_admin_referer( 'ae_pq_bulk_export', 'ae_pq_bulk_nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Insufficient permissions.', 'ae-pro' ) );
		}

		$ids = array_map( 'absint', (array) ( $_POST['preset_ids'] ?? [] ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$ids = array_filter( $ids );

		if ( empty( $ids ) ) {
			wp_safe_redirect( admin_url( 'admin.php?page=ae-preset-query' ) );
			exit;
		}

		$export = [ 'version' => 1, 'presets' => [] ];
		foreach ( $ids as $id ) {
			$post = get_post( $id );
			if ( ! $post || $post->post_type !== Cpt::POST_TYPE ) {
				continue;
			}
			$raw_args            = get_post_meta( $id, 'ae_preset_query_args', true );
			$export['presets'][] = [
				'title'      => $post->post_title,
				'status'     => $post->post_status,
				'query_args' => $raw_args ? json_decode( $raw_args, true ) : [],
			];
		}

		// phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped
		header( 'Content-Type: application/json' );
		header( 'Content-Disposition: attachment; filename="preset-queries-selected-' . gmdate( 'Y-m-d' ) . '.json"' );
		header( 'Cache-Control: no-cache, no-store, must-revalidate' );
		echo wp_json_encode( $export, JSON_PRETTY_PRINT );
		// phpcs:enable
		exit;
	}

	public function handle_import() {
		check_admin_referer( 'ae_pq_import', 'ae_pq_import_nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Insufficient permissions.', 'ae-pro' ) );
		}

		$back = admin_url( 'admin.php?page=ae-preset-query' );

		if ( empty( $_FILES['ae_pq_import_file']['tmp_name'] ) ) {
			wp_safe_redirect( add_query_arg( 'ae_pq_error', urlencode( __( 'No file uploaded.', 'ae-pro' ) ), $back ) );
			exit;
		}

		$content = file_get_contents( $_FILES['ae_pq_import_file']['tmp_name'] ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		$data    = json_decode( $content, true );

		if ( ! is_array( $data ) || empty( $data['version'] ) ) {
			wp_safe_redirect( add_query_arg( 'ae_pq_error', urlencode( __( 'Invalid import file.', 'ae-pro' ) ), $back ) );
			exit;
		}

		// Support single-preset export files.
		if ( isset( $data['title'] ) && isset( $data['query_args'] ) ) {
			$data = [ 'version' => 1, 'presets' => [ $data ] ];
		}

		$imported = 0;
		foreach ( (array) ( $data['presets'] ?? [] ) as $preset ) {
			$title  = sanitize_text_field( $preset['title'] ?? __( 'Imported Preset', 'ae-pro' ) );
			$status = in_array( $preset['status'] ?? '', [ 'publish', 'draft' ], true ) ? $preset['status'] : 'publish';
			$new_id = wp_insert_post( [
				'post_type'   => Cpt::POST_TYPE,
				'post_title'  => $title,
				'post_status' => $status,
			] );
			if ( ! is_wp_error( $new_id ) ) {
				$raw_args   = is_array( $preset['query_args'] ?? null ) ? $preset['query_args'] : [];
				$query_args = $this->sanitize_imported_args( $raw_args );
				update_post_meta( $new_id, 'ae_preset_query_args', wp_json_encode( $query_args ) );
				$imported++;
			}
		}

		wp_safe_redirect( add_query_arg( 'ae_pq_imported', $imported, $back ) );
		exit;
	}

	// -------------------------------------------------------------------------
	// Build query args from $_POST
	// -------------------------------------------------------------------------

	private function build_query_args_from_post() {
		$form_args  = (array) ( $_POST['ae_pq_args'] ?? [] );
		$query_args = $this->sanitize_query_args( $form_args );

		// Post & page filters.
		$post_in_raw = (array) ( $_POST['ae_pq_post_in'] ?? [] );
		$post_in     = array_values( array_filter( array_map( 'absint', $post_in_raw ) ) );
		if ( $post_in ) {
			$query_args['post__in'] = $post_in;
		}

		if ( ! empty( $_POST['ae_pq_post_parent_top_level'] ) ) {
			$query_args['post_parent'] = 0;
		}

		$post_parent_in_raw = (array) ( $_POST['ae_pq_post_parent_in'] ?? [] );
		$post_parent_in     = array_values( array_filter( array_map( 'absint', $post_parent_in_raw ) ) );
		if ( $post_parent_in ) {
			$query_args['post_parent__in'] = $post_parent_in;
		}

		$post_parent_not_in_raw = (array) ( $_POST['ae_pq_post_parent_not_in'] ?? [] );
		$post_parent_not_in     = array_values( array_filter( array_map( 'absint', $post_parent_not_in_raw ) ) );
		if ( $post_parent_not_in ) {
			$query_args['post_parent__not_in'] = $post_parent_not_in;
		}

		// Exclude post IDs — submitted as array from <select multiple>.
		$not_in_raw = (array) ( $_POST['ae_pq_post_not_in'] ?? [] );
		$not_in     = array_values( array_filter( array_map( 'absint', $not_in_raw ) ) );
		if ( $not_in ) {
			$query_args['post__not_in'] = $not_in;
		}
		if ( ! empty( $query_args['post__in'] ) && ! empty( $query_args['post__not_in'] ) ) {
			unset( $query_args['post__not_in'] );
		}

		if ( ! empty( $_POST['ae_pq_exclude_current'] ) ) {
			$query_args['_ae_exclude_current'] = true;
		}

		// Taxonomy filters (nested group builder — JSON submitted by JS).
		$tax_json = wp_unslash( $_POST['ae_pq_tax_json'] ?? '' ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		if ( $tax_json ) {
			$tax_model = json_decode( $tax_json, true );
			if ( is_array( $tax_model ) ) {
				$built = $this->build_tax_query_node( $tax_model );
				if ( is_array( $built ) && count( $built ) > 1 ) {
					$query_args['tax_query'] = $built;
				}
			}
		}

		// Author filters.
		$author_ids = array_values( array_filter( array_map( 'absint', (array) ( $_POST['ae_pq_author_ids'] ?? [] ) ) ) );
		if ( ! empty( $author_ids ) ) {
			$op = sanitize_key( $_POST['ae_pq_author_operator'] ?? 'in' );
			$query_args[ $op === 'not_in' ? 'author__not_in' : 'author__in' ] = $author_ids;
		}

		// Date filters.
		$date_raw  = (array) ( $_POST['ae_pq_date'] ?? [] );
		$date_mode = sanitize_key( $date_raw['mode'] ?? '' );
		if ( $date_mode ) {
			$column = sanitize_key( $date_raw['column'] ?? 'post_date' );
			if ( ! in_array( $column, [ 'post_date', 'post_modified' ], true ) ) {
				$column = 'post_date';
			}
			$clause = [ 'column' => $column ];
			if ( $date_mode === 'relative' ) {
				$relative = sanitize_text_field( wp_unslash( $date_raw['relative'] ?? '' ) );
				if ( $relative ) {
					$clause['after'] = $relative;
				}
			} else {
				$after  = sanitize_text_field( wp_unslash( $date_raw['after']  ?? '' ) );
				$before = sanitize_text_field( wp_unslash( $date_raw['before'] ?? '' ) );
				if ( $after )  { $clause['after']  = $after; }
				if ( $before ) { $clause['before'] = $before; }
			}
			if ( ! empty( $date_raw['inclusive'] ) ) {
				$clause['inclusive'] = true;
			}
			if ( isset( $clause['after'] ) || isset( $clause['before'] ) ) {
				$query_args['date_query']    = [ $clause ];
				$query_args['_ae_date_mode'] = $date_mode;
			}
		}

		// Meta query (nested group builder — JSON submitted by JS).
		$allowed_compare = [ '=', '!=', '>', '>=', '<', '<=', 'LIKE', 'NOT LIKE', 'IN', 'NOT IN', 'BETWEEN', 'NOT BETWEEN', 'EXISTS', 'NOT EXISTS', 'REGEXP', 'NOT REGEXP' ];
		$allowed_type    = [ 'CHAR', 'NUMERIC', 'DECIMAL', 'DATE', 'TIME', 'DATETIME', 'BINARY' ];
		$meta_json       = wp_unslash( $_POST['ae_pq_meta_json'] ?? '' ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		if ( $meta_json ) {
			$meta_model = json_decode( $meta_json, true );
			if ( is_array( $meta_model ) ) {
				$built = $this->build_meta_query_node( $meta_model, $allowed_compare, $allowed_type );
				if ( is_array( $built ) && count( $built ) > 1 ) {
					$query_args['meta_query'] = $built;
				}
			}
		}

		return $query_args;
	}

	/**
	 * Recursively convert a JS tree node to a WP meta_query array.
	 *
	 * @param array $node            JS node (group or clause).
	 * @param array $allowed_compare Allowed compare operators.
	 * @param array $allowed_type    Allowed data types.
	 * @param int   $depth           Current recursion depth (max 2).
	 * @return array|null
	 */
	private function build_meta_query_node( $node, $allowed_compare, $allowed_type, $depth = 0 ) {
		if ( ! is_array( $node ) || $depth > 2 ) {
			return null;
		}

		// Group node.
		if ( ( $node['type'] ?? '' ) === 'group' ) {
			$result = [ 'relation' => ( $node['relation'] ?? 'AND' ) === 'OR' ? 'OR' : 'AND' ];
			foreach ( (array) ( $node['children'] ?? [] ) as $child ) {
				$built = $this->build_meta_query_node( $child, $allowed_compare, $allowed_type, $depth + 1 );
				if ( $built !== null ) {
					$result[] = $built;
				}
			}
			return count( $result ) > 1 ? $result : null;
		}

		// Clause node.
		$key = sanitize_text_field( $node['key'] ?? '' );
		if ( ! $key ) {
			return null;
		}

		$compare = sanitize_text_field( $node['compare'] ?? '=' );
		if ( ! in_array( $compare, $allowed_compare, true ) ) {
			$compare = '=';
		}

		$data_type = sanitize_text_field( $node['dataType'] ?? 'CHAR' );
		if ( ! in_array( $data_type, $allowed_type, true ) ) {
			$data_type = 'CHAR';
		}

		$clause = [ 'key' => $key, 'compare' => $compare, 'type' => $data_type ];

		if ( ! in_array( $compare, [ 'EXISTS', 'NOT EXISTS' ], true ) ) {
			$value_raw = sanitize_text_field( $node['value'] ?? '' );
			if ( in_array( $compare, [ 'IN', 'NOT IN', 'BETWEEN', 'NOT BETWEEN' ], true ) ) {
				$clause['value'] = array_values( array_filter( array_map( 'trim', explode( ',', $value_raw ) ) ) );
			} else {
				$clause['value'] = $value_raw;
			}
		}

		return $clause;
	}

	/**
	 * Recursively convert a JS tax tree node to a WP tax_query array.
	 *
	 * @param array $node  JS node (group or clause).
	 * @param int   $depth Current recursion depth (max 2).
	 * @return array|null
	 */
	private function build_tax_query_node( $node, $depth = 0 ) {
		if ( ! is_array( $node ) || $depth > 2 ) {
			return null;
		}

		$allowed_operators = [ 'IN', 'NOT IN', 'AND', 'EXISTS', 'NOT EXISTS' ];
		$allowed_fields    = [ 'term_id', 'name', 'slug', 'term_taxonomy_id' ];

		// Group node.
		if ( ( $node['type'] ?? '' ) === 'group' ) {
			$result = [ 'relation' => ( $node['relation'] ?? 'AND' ) === 'OR' ? 'OR' : 'AND' ];
			foreach ( (array) ( $node['children'] ?? [] ) as $child ) {
				$built = $this->build_tax_query_node( $child, $depth + 1 );
				if ( $built !== null ) {
					$result[] = $built;
				}
			}
			return count( $result ) > 1 ? $result : null;
		}

		// Clause node.
		$taxonomy = sanitize_key( $node['taxonomy'] ?? '' );
		if ( ! $taxonomy ) {
			return null;
		}

		$operator = sanitize_text_field( $node['operator'] ?? 'IN' );
		if ( ! in_array( $operator, $allowed_operators, true ) ) {
			$operator = 'IN';
		}

		$field = sanitize_key( $node['field'] ?? 'slug' );
		if ( ! in_array( $field, $allowed_fields, true ) ) {
			$field = 'slug';
		}

		$terms = array_values( array_filter( array_map(
			static function ( $t ) { return sanitize_text_field( trim( (string) $t ) ); },
			(array) ( $node['terms'] ?? [] )
		) ) );

		if ( ! $terms && ! in_array( $operator, [ 'EXISTS', 'NOT EXISTS' ], true ) ) {
			return null;
		}

		return [ 'taxonomy' => $taxonomy, 'field' => $field, 'terms' => $terms, 'operator' => $operator ];
	}

	/**
	 * Sanitize query args from an imported JSON file.
	 * Only allows the same keys accepted by the form, so imported files
	 * cannot inject arbitrary WP_Query parameters.
	 */
	private function sanitize_imported_args( array $raw ) {
		$allowed_compare = [ '=', '!=', '>', '>=', '<', '<=', 'LIKE', 'NOT LIKE', 'IN', 'NOT IN', 'BETWEEN', 'NOT BETWEEN', 'EXISTS', 'NOT EXISTS', 'REGEXP', 'NOT REGEXP' ];
		$allowed_type    = [ 'CHAR', 'NUMERIC', 'DECIMAL', 'DATE', 'TIME', 'DATETIME', 'BINARY' ];
		$allowed_scalar  = [ 'post_type', 'post_status', 'orderby', 'order', 'meta_key', 'posts_per_page', 'offset', 's' ];
		$allowed_status  = [ 'publish', 'draft', 'private', 'pending', 'future', 'any' ];
		$allowed_orderby = [ 'date', 'title', 'modified', 'menu_order', 'rand', 'comment_count', 'meta_value', 'meta_value_num' ];

		$clean = $this->sanitize_query_args( $raw );

		// Validate post_type and post_status against known values.
		if ( isset( $clean['post_status'] ) && ! in_array( $clean['post_status'], $allowed_status, true ) ) {
			$clean['post_status'] = 'publish';
		}
		if ( isset( $clean['orderby'] ) && ! in_array( $clean['orderby'], $allowed_orderby, true ) ) {
			unset( $clean['orderby'] );
		}

		// Integer array fields.
		foreach ( [ 'post__in', 'post__not_in', 'post_parent__in', 'post_parent__not_in', 'author__in', 'author__not_in' ] as $key ) {
			if ( ! empty( $raw[ $key ] ) && is_array( $raw[ $key ] ) ) {
				$clean[ $key ] = array_values( array_filter( array_map( 'absint', $raw[ $key ] ) ) );
			}
		}

		// post_parent (0 = top-level only).
		if ( isset( $raw['post_parent'] ) && is_numeric( $raw['post_parent'] ) ) {
			$clean['post_parent'] = absint( $raw['post_parent'] );
		}

		// Internal AE flags.
		if ( ! empty( $raw['_ae_exclude_current'] ) ) {
			$clean['_ae_exclude_current'] = true;
		}
		if ( ! empty( $raw['ignore_sticky_posts'] ) ) {
			$clean['ignore_sticky_posts'] = true;
		}

		// Meta query — sanitize WP-format array (numeric-keyed clauses + relation).
		if ( ! empty( $raw['meta_query'] ) && is_array( $raw['meta_query'] ) ) {
			$built = $this->sanitize_wp_meta_query( $raw['meta_query'], $allowed_compare, $allowed_type );
			if ( $built !== null ) {
				$clean['meta_query'] = $built;
			}
		}

		// Tax query — sanitize WP-format array (numeric-keyed clauses + relation).
		if ( ! empty( $raw['tax_query'] ) && is_array( $raw['tax_query'] ) ) {
			$built = $this->sanitize_wp_tax_query( $raw['tax_query'] );
			if ( $built !== null ) {
				$clean['tax_query'] = $built;
			}
		}

		// Date query — only allow known columns.
		if ( ! empty( $raw['date_query'] ) && is_array( $raw['date_query'] ) ) {
			$allowed_cols = [ 'post_date', 'post_modified' ];
			$sanitized_dq = [];
			foreach ( $raw['date_query'] as $item ) {
				if ( ! is_array( $item ) ) { continue; }
				$col = sanitize_key( $item['column'] ?? 'post_date' );
				if ( ! in_array( $col, $allowed_cols, true ) ) { $col = 'post_date'; }
				$dq = [ 'column' => $col ];
				if ( ! empty( $item['after'] ) )    { $dq['after']     = sanitize_text_field( $item['after'] ); }
				if ( ! empty( $item['before'] ) )   { $dq['before']    = sanitize_text_field( $item['before'] ); }
				if ( ! empty( $item['inclusive'] ) ) { $dq['inclusive'] = true; }
				$sanitized_dq[] = $dq;
			}
			if ( $sanitized_dq ) {
				$clean['date_query'] = $sanitized_dq;
			}
		}
		if ( ! empty( $raw['_ae_date_mode'] ) && in_array( $raw['_ae_date_mode'], [ 'static', 'relative' ], true ) ) {
			$clean['_ae_date_mode'] = $raw['_ae_date_mode'];

			// When mode is relative, validate the stored 'after' value against the allowed set.
			if ( $raw['_ae_date_mode'] === 'relative' && ! empty( $clean['date_query'] ) ) {
				$allowed_relative = [
					'7 days ago',
					'30 days ago',
					'90 days ago',
					'first day of this month',
					'first day of last month',
					'first day of January this year',
				];
				foreach ( $clean['date_query'] as $i => $dq_item ) {
					if ( isset( $dq_item['after'] ) && ! in_array( $dq_item['after'], $allowed_relative, true ) ) {
						unset( $clean['date_query'][ $i ] );
					}
				}
				$clean['date_query'] = array_values( $clean['date_query'] );
				if ( empty( $clean['date_query'] ) ) {
					unset( $clean['date_query'], $clean['_ae_date_mode'] );
				}
			}
		}

		return $clean;
	}

	/**
	 * Sanitize a WP-format meta_query (exported JSON) in-place.
	 *
	 * Exported presets store meta_query in WP format: numerically-keyed clause
	 * arrays with an optional 'relation' key.  build_meta_query_node() expects
	 * the JS tree format (type/children), so we need a dedicated sanitizer here.
	 *
	 * @param array $raw             WP-format meta_query array.
	 * @param array $allowed_compare Allowed compare operators.
	 * @param array $allowed_type    Allowed data types.
	 * @param int   $depth           Recursion depth guard (max 2).
	 * @return array|null Sanitized WP-format meta_query, or null if empty.
	 */
	private function sanitize_wp_meta_query( array $raw, array $allowed_compare, array $allowed_type, $depth = 0 ) {
		if ( $depth > 2 ) {
			return null;
		}

		$relation = ( isset( $raw['relation'] ) && strtoupper( $raw['relation'] ) === 'OR' ) ? 'OR' : 'AND';
		$result   = [];

		foreach ( $raw as $k => $item ) {
			if ( $k === 'relation' || ! is_array( $item ) ) {
				continue;
			}

			if ( isset( $item['key'] ) ) {
				// Leaf clause.
				$key = sanitize_text_field( $item['key'] );
				if ( ! $key ) {
					continue;
				}
				$compare = sanitize_text_field( $item['compare'] ?? '=' );
				if ( ! in_array( $compare, $allowed_compare, true ) ) {
					$compare = '=';
				}
				$type = sanitize_text_field( $item['type'] ?? 'CHAR' );
				if ( ! in_array( $type, $allowed_type, true ) ) {
					$type = 'CHAR';
				}
				$clause = [ 'key' => $key, 'compare' => $compare, 'type' => $type ];
				if ( ! in_array( $compare, [ 'EXISTS', 'NOT EXISTS' ], true ) ) {
					if ( is_array( $item['value'] ?? null ) ) {
						$clause['value'] = array_values( array_filter( array_map( 'sanitize_text_field', $item['value'] ) ) );
					} else {
						$value_raw = sanitize_text_field( $item['value'] ?? '' );
						if ( in_array( $compare, [ 'IN', 'NOT IN', 'BETWEEN', 'NOT BETWEEN' ], true ) ) {
							$clause['value'] = array_values( array_filter( array_map( 'trim', explode( ',', $value_raw ) ) ) );
						} else {
							$clause['value'] = $value_raw;
						}
					}
				}
				$result[] = $clause;
			} else {
				// Sub-group.
				$sub = $this->sanitize_wp_meta_query( $item, $allowed_compare, $allowed_type, $depth + 1 );
				if ( $sub !== null ) {
					$result[] = $sub;
				}
			}
		}

		if ( empty( $result ) ) {
			return null;
		}

		$result['relation'] = $relation;
		return $result;
	}

	/**
	 * Sanitize a WP-format tax_query (exported JSON) in-place.
	 *
	 * @param array $raw   WP-format tax_query array.
	 * @param int   $depth Recursion depth guard (max 2).
	 * @return array|null Sanitized WP-format tax_query, or null if empty.
	 */
	private function sanitize_wp_tax_query( array $raw, $depth = 0 ) {
		if ( $depth > 2 ) {
			return null;
		}

		$allowed_operators = [ 'IN', 'NOT IN', 'AND', 'EXISTS', 'NOT EXISTS' ];
		$allowed_fields    = [ 'term_id', 'name', 'slug', 'term_taxonomy_id' ];
		$relation          = ( isset( $raw['relation'] ) && strtoupper( $raw['relation'] ) === 'OR' ) ? 'OR' : 'AND';
		$result            = [];

		foreach ( $raw as $k => $item ) {
			if ( $k === 'relation' || ! is_array( $item ) ) {
				continue;
			}

			if ( isset( $item['taxonomy'] ) ) {
				// Leaf clause.
				$taxonomy = sanitize_key( $item['taxonomy'] );
				if ( ! $taxonomy ) {
					continue;
				}
				$operator = sanitize_text_field( $item['operator'] ?? 'IN' );
				if ( ! in_array( $operator, $allowed_operators, true ) ) {
					$operator = 'IN';
				}
				$field = sanitize_key( $item['field'] ?? 'slug' );
				if ( ! in_array( $field, $allowed_fields, true ) ) {
					$field = 'slug';
				}
				$terms = array_values( array_filter( array_map(
					static function ( $t ) { return sanitize_text_field( trim( (string) $t ) ); },
					(array) ( $item['terms'] ?? [] )
				) ) );
				if ( ! $terms && ! in_array( $operator, [ 'EXISTS', 'NOT EXISTS' ], true ) ) {
					continue;
				}
				$result[] = [ 'taxonomy' => $taxonomy, 'field' => $field, 'terms' => $terms, 'operator' => $operator ];
			} else {
				// Sub-group.
				$sub = $this->sanitize_wp_tax_query( $item, $depth + 1 );
				if ( $sub !== null ) {
					$result[] = $sub;
				}
			}
		}

		if ( empty( $result ) ) {
			return null;
		}

		$result['relation'] = $relation;
		return $result;
	}

	private function sanitize_query_args( array $raw ) {
		$allowed_scalar = [ 'post_type', 'post_status', 'orderby', 'order', 'meta_key', 'posts_per_page', 'offset', 's' ];
		$clean          = [];
		foreach ( $allowed_scalar as $key ) {
			if ( isset( $raw[ $key ] ) && $raw[ $key ] !== '' ) {
				$clean[ $key ] = sanitize_text_field( $raw[ $key ] );
			}
		}
		if ( isset( $clean['posts_per_page'] ) ) {
			$clean['posts_per_page'] = (int) $clean['posts_per_page'];
		}
		if ( isset( $clean['offset'] ) ) {
			$clean['offset'] = (int) $clean['offset'];
		}
		if ( ! empty( $raw['ignore_sticky_posts'] ) ) {
			$clean['ignore_sticky_posts'] = true;
		}

		// Validate post_type — must exist or be the special 'any' token.
		if ( isset( $clean['post_type'] ) && $clean['post_type'] !== 'any' && ! post_type_exists( $clean['post_type'] ) ) {
			$clean['post_type'] = 'post';
		}

		// Validate post_status against the set WP recognises.
		$allowed_status = [ 'publish', 'draft', 'private', 'pending', 'future', 'any', 'inherit', 'trash' ];
		if ( isset( $clean['post_status'] ) && ! in_array( $clean['post_status'], $allowed_status, true ) ) {
			$clean['post_status'] = 'publish';
		}

		return $clean;
	}

	// -------------------------------------------------------------------------
	// Assets
	// -------------------------------------------------------------------------

	public function enqueue_assets() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( ( $_GET['page'] ?? '' ) !== 'ae-preset-query' ) {
			return;
		}

		wp_enqueue_style(
			'ae-pq-select2',
			AE_PRO_URL . 'pro/admin/preset-query/assets/css/select2.min.css',
			[],
			'4.0.13'
		);
		wp_enqueue_style(
			'ae-preset-query-admin',
			AE_PRO_URL . 'pro/admin/preset-query/assets/css/preset-query-admin.css',
			[ 'ae-pq-select2' ],
			AE_PRO_VERSION
		);
		wp_enqueue_script(
			'ae-pq-select2',
			AE_PRO_URL . 'pro/admin/preset-query/assets/js/select2.min.js',
			[ 'jquery' ],
			'4.0.13',
			true
		);
		wp_enqueue_script(
			'ae-preset-query-admin',
			AE_PRO_URL . 'pro/admin/preset-query/assets/js/preset-query-admin.js',
			[ 'jquery', 'ae-pq-select2' ],
			AE_PRO_VERSION,
			true
		);

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$action    = sanitize_key( $_GET['action'] ?? 'list' );
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$preset_id = absint( $_GET['preset_id'] ?? 0 );

		$post_types = Aepro::$_helper->get_rule_post_types();
		$tax_map    = [];
		foreach ( array_keys( $post_types ) as $pt ) {
			$taxes          = get_object_taxonomies( $pt, 'objects' );
			$tax_map[ $pt ] = [];
			foreach ( $taxes as $tax ) {
				if ( $tax->show_ui ) {
					$tax_map[ $pt ][] = [ 'slug' => $tax->name, 'label' => $tax->label ];
				}
			}
		}

		$stored_tax_query       = null;
		$stored_author_ids      = [];
		$stored_author_operator = 'in';
		$stored_meta_query      = null;

		if ( $action === 'edit' && $preset_id ) {
			$raw  = get_post_meta( $preset_id, 'ae_preset_query_args', true );
			$args = $raw ? json_decode( $raw, true ) : [];
			if ( is_array( $args ) ) {
				if ( ! empty( $args['tax_query'] ) && is_array( $args['tax_query'] ) ) {
					$stored_tax_query = $args['tax_query'];
				}
				if ( ! empty( $args['author__in'] ) ) {
					$stored_author_ids      = array_map( 'intval', (array) $args['author__in'] );
					$stored_author_operator = 'in';
				} elseif ( ! empty( $args['author__not_in'] ) ) {
					$stored_author_ids      = array_map( 'intval', (array) $args['author__not_in'] );
					$stored_author_operator = 'not_in';
				}
				if ( ! empty( $args['meta_query'] ) && is_array( $args['meta_query'] ) ) {
					$stored_meta_query = $args['meta_query'];
				}
			}
		}

		wp_localize_script( 'ae-preset-query-admin', 'aePQ', [
			'ajax_url'               => admin_url( 'admin-ajax.php' ),
			'nonce'                  => wp_create_nonce( 'ae_pq_nonce' ),
			'tax_map'                => $tax_map,
			'stored_tax_query'       => $stored_tax_query,
			'stored_author_ids'      => $stored_author_ids,
			'stored_author_operator' => $stored_author_operator,
			'stored_meta_query'      => $stored_meta_query,
			'is_edit'                => ( $action === 'edit' || $action === 'new' ) ? 1 : 0,
			'i18n'                   => [
				'saving'               => __( 'Saving…', 'ae-pro' ),
				'saved'                => __( 'Saved!', 'ae-pro' ),
				'error'                => __( 'Something went wrong. Please try again.', 'ae-pro' ),
				'no_taxonomy'          => __( 'No taxonomies for this post type', 'ae-pro' ),
				'copied'               => __( 'Copied!', 'ae-pro' ),
				'bulk_select_action'   => __( 'Please select a bulk action.', 'ae-pro' ),
				'bulk_select_items'    => __( 'Please select at least one preset.', 'ae-pro' ),
				'bulk_delete_confirm'  => __( 'Delete the selected presets? This cannot be undone.', 'ae-pro' ),
			],
		] );
	}

	// -------------------------------------------------------------------------
	// Helpers
	// -------------------------------------------------------------------------

	private function get_notice() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		if ( isset( $_GET['ae_pq_saved'] ) ) {
			return '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Preset saved.', 'ae-pro' ) . '</p></div>';
		}
		if ( isset( $_GET['ae_pq_deleted'] ) ) {
			return '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Preset deleted.', 'ae-pro' ) . '</p></div>';
		}
		if ( isset( $_GET['ae_pq_duplicated'] ) ) {
			return '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Preset duplicated.', 'ae-pro' ) . '</p></div>';
		}
		if ( isset( $_GET['ae_pq_imported'] ) ) {
			$n = absint( $_GET['ae_pq_imported'] );
			return '<div class="notice notice-success is-dismissible"><p>' . sprintf( esc_html__( '%d preset(s) imported.', 'ae-pro' ), $n ) . '</p></div>';
		}
		if ( isset( $_GET['ae_pq_bulk_deleted'] ) ) {
			$n = absint( $_GET['ae_pq_bulk_deleted'] );
			return '<div class="notice notice-success is-dismissible"><p>' . sprintf( esc_html__( '%d preset(s) deleted.', 'ae-pro' ), $n ) . '</p></div>';
		}
		if ( isset( $_GET['ae_pq_bulk_activated'] ) ) {
			$n = absint( $_GET['ae_pq_bulk_activated'] );
			return '<div class="notice notice-success is-dismissible"><p>' . sprintf( esc_html__( '%d preset(s) activated.', 'ae-pro' ), $n ) . '</p></div>';
		}
		if ( isset( $_GET['ae_pq_bulk_deactivated'] ) ) {
			$n = absint( $_GET['ae_pq_bulk_deactivated'] );
			return '<div class="notice notice-success is-dismissible"><p>' . sprintf( esc_html__( '%d preset(s) deactivated.', 'ae-pro' ), $n ) . '</p></div>';
		}
		if ( isset( $_GET['ae_pq_error'] ) ) {
			return '<div class="notice notice-error is-dismissible"><p>' . esc_html( wp_unslash( $_GET['ae_pq_error'] ) ) . '</p></div>';
		}
		// phpcs:enable
		return '';
	}

	// -------------------------------------------------------------------------
	// Plugin top bar
	// -------------------------------------------------------------------------

	public function register_screens( $screens ) {
		$screens[] = 'ae_global_templates_page_ae-preset-query';
		return $screens;
	}

	public function add_nav_link( $links ) {
		$links[7] = [
			'id'      => 'ae_global_templates_page_ae-preset-query',
			'screens' => [
				'ae_global_templates_page_ae-preset-query',
				'ae_global_templates_page_ae-preset-rules',
				'ae_preset_query',
				'edit-ae_preset_query',
			],
			'label'   => __( 'Presets', 'ae-pro' ),
			'icon'    => 'eicon-editor-list-ul',
			'link'    => admin_url( 'admin.php?page=ae-preset-query' ),
		];
		return $links;
	}
}
