/* global aePQ, jQuery */
( function ( $ ) {
	'use strict';

	var isEdit = !! ( aePQ && aePQ.is_edit );

	// -------------------------------------------------------------------------
	// List page JS
	// -------------------------------------------------------------------------

	// Import form toggle.
	$( '#ae-pq-import-trigger' ).on( 'click', function () {
		$( '#ae-pq-import-wrap' ).slideDown( 120 );
	} );
	$( '#ae-pq-import-cancel' ).on( 'click', function () {
		$( '#ae-pq-import-wrap' ).slideUp( 120 );
	} );

	// Show filename when file chosen.
	$( document ).on( 'change', 'input[name="ae_pq_import_file"]', function () {
		var name = this.files && this.files[0] ? this.files[0].name : aePQ.i18n.no_file;
		$( '#ae-pq-import-filename' ).text( name || '' );
	} );

	// "Copy Code" button on list page.
	$( document ).on( 'click', '.ae-pq-copy-code-btn', function ( e ) {
		e.preventDefault();
		var code = $( this ).data( 'code' );
		if ( ! code ) { return; }
		copyToClipboard( code, $( this ) );
	} );

	// -------------------------------------------------------------------------
	// Status toggle — list table + edit page header
	// -------------------------------------------------------------------------
	$( document ).on( 'click', '.ae-pq-status-toggle', function () {
		var $btn      = $( this );
		var presetId  = $btn.data( 'preset-id' );
		if ( ! presetId || $btn.hasClass( 'ae-pq-status-toggle--loading' ) ) { return; }

		$btn.addClass( 'ae-pq-status-toggle--loading' );

		$.post( aePQ.ajax_url, {
			action:    'ae_pq_toggle_status',
			nonce:     aePQ.nonce,
			preset_id: presetId,
		} ).done( function ( res ) {
			if ( ! res.success ) { return; }
			var active = res.data.active;
			$btn
				.toggleClass( 'ae-pq-status-toggle--active', active )
				.attr( 'data-active', active ? '1' : '0' )
				.attr( 'title', active ? 'Click to deactivate' : 'Click to activate' );
			$btn.find( '.ae-pq-status-toggle__label' ).text( active ? 'Active' : 'Inactive' );
		} ).always( function () {
			$btn.removeClass( 'ae-pq-status-toggle--loading' );
		} );
	} );

	// -------------------------------------------------------------------------
	// Bulk actions — list page only
	// -------------------------------------------------------------------------

	var $selectAll = $( '#ae-pq-select-all' );
	var $bulkApply = $( '#ae-pq-bulk-apply' );
	var $bulkCount = $( '#ae-pq-bulk-count' );

	function getCheckedIds() {
		return $( '.ae-pq-row-cb:checked' ).map( function () { return $( this ).val(); } ).get();
	}

	function syncBulkBar() {
		var ids   = getCheckedIds();
		var total = $( '.ae-pq-row-cb' ).length;
		$bulkApply.prop( 'disabled', ids.length === 0 );
		$bulkCount.text( ids.length ? ids.length + ' ' + ( ids.length === 1 ? 'item' : 'items' ) + ' selected' : '' );
		$selectAll
			.prop( 'checked', ids.length > 0 && ids.length === total )
			.prop( 'indeterminate', ids.length > 0 && ids.length < total );
	}

	$selectAll.on( 'change', function () {
		var checked = $( this ).is( ':checked' );
		$( '.ae-pq-row-cb' ).prop( 'checked', checked ).each( function () {
			$( this ).closest( 'tr' ).toggleClass( 'ae-pq-row--selected', checked );
		} );
		syncBulkBar();
	} );

	$( document ).on( 'change', '.ae-pq-row-cb', function () {
		$( this ).closest( 'tr' ).toggleClass( 'ae-pq-row--selected', $( this ).is( ':checked' ) );
		syncBulkBar();
	} );

	$bulkApply.on( 'click', function () {
		var action = $( '#ae-pq-bulk-action' ).val();
		var ids    = getCheckedIds();

		if ( ! action ) {
			alert( aePQ.i18n.bulk_select_action );
			return;
		}
		if ( ! ids.length ) {
			alert( aePQ.i18n.bulk_select_items );
			return;
		}

		if ( action === 'export' ) {
			var $wrap = $( '#ae-pq-bulk-export-ids' ).empty();
			$.each( ids, function ( i, id ) {
				$wrap.append( $( '<input>' ).attr( { type: 'hidden', name: 'preset_ids[]', value: parseInt( id, 10 ) } ) );
			} );
			$( '#ae-pq-bulk-export-form' )[0].submit();
			return;
		}

		if ( action === 'delete' && ! confirm( aePQ.i18n.bulk_delete_confirm ) ) {
			return;
		}

		$bulkApply.prop( 'disabled', true );

		$.post( aePQ.ajax_url, {
			action:      'ae_pq_bulk_action',
			nonce:       aePQ.nonce,
			bulk_action: action,
			preset_ids:  ids,
		} ).done( function ( res ) {
			if ( ! res.success ) {
				alert( res.data && res.data.message ? res.data.message : aePQ.i18n.error );
				return;
			}
			var processed = res.data.processed;
			if ( action === 'delete' ) {
				$.each( processed, function ( i, id ) {
					$( '.ae-pq-row-cb[value="' + id + '"]' ).closest( 'tr' ).fadeOut( 200, function () { $( this ).remove(); syncBulkBar(); } );
				} );
			} else {
				var isActive = ( action === 'activate' );
				$.each( processed, function ( i, id ) {
					var $toggle = $( '.ae-pq-status-toggle[data-preset-id="' + id + '"]' );
					$toggle
						.toggleClass( 'ae-pq-status-toggle--active', isActive )
						.attr( 'data-active', isActive ? '1' : '0' )
						.attr( 'title', isActive ? 'Click to deactivate' : 'Click to activate' );
					$toggle.find( '.ae-pq-status-toggle__label' ).text( isActive ? 'Active' : 'Inactive' );
				} );
			}
			$( '.ae-pq-row-cb, #ae-pq-select-all' ).prop( 'checked', false ).prop( 'indeterminate', false );
			$( '#ae-pq-bulk-action' ).val( '' );
			syncBulkBar();
		} ).always( function () {
			$bulkApply.prop( 'disabled', false );
		} );
	} );

	// -------------------------------------------------------------------------
	// Edit page — only runs when is_edit
	// -------------------------------------------------------------------------

	if ( ! isEdit ) { return; }

	// -------------------------------------------------------------------------
	// Save button — disabled until a title is entered
	// -------------------------------------------------------------------------

	var $titleInput = $( '#ae-pq-title-input' );
	var $saveBtn    = $( '.ae-pq-save-btn' );

	function syncSaveBtn() {
		$saveBtn.prop( 'disabled', $titleInput.val().trim() === '' );
	}

	syncSaveBtn();
	$titleInput.on( 'input', syncSaveBtn );

	// -------------------------------------------------------------------------
	// Section toggle (accordion)
	// -------------------------------------------------------------------------
	$( document ).on( 'click', '.ae-pq-section-header', function () {
		var $header = $( this );
		var target  = $header.data( 'target' );
		var $body   = $( '#' + target );
		$header.toggleClass( 'ae-pq-section-header--collapsed' );
		$body.toggleClass( 'ae-pq-section-body--collapsed' );

		// Re-init Select2 fields when the section becomes visible.
		// Select2 computes 0px width while the parent is display:none; reinitialising
		// once the accordion is open ensures dropdowns fill their flex columns correctly.
		if ( ! $header.hasClass( 'ae-pq-section-header--collapsed' ) ) {
			// Taxonomy terms selects (single-select).
			$body.find( '.ae-pq-tax-terms' ).each( function () {
				var $sel = $( this );
				if ( $sel.is( ':visible' ) ) {
					initTermSelect2( $sel );
				}
			} );
		}
	} );

	// -------------------------------------------------------------------------
	// AND / OR relation toggle buttons
	// -------------------------------------------------------------------------
	$( document ).on( 'click', '.ae-pq-relation-btn', function () {
		var $btn    = $( this );
		var target  = $btn.data( 'hidden' );
		var val     = $btn.data( 'val' );

		$btn.closest( '.ae-pq-relation-toggle' ).find( '.ae-pq-relation-btn' )
			.removeClass( 'ae-pq-relation-btn--active' );
		$btn.addClass( 'ae-pq-relation-btn--active' );

		$( '#' + target ).val( val );
		scheduleCodeUpdate();
	} );

	// Sync button state from stored value on load.
	function syncRelationBtn( hiddenId ) {
		var val    = $( '#' + hiddenId ).val();
		var $wrap  = $( '#' + hiddenId ).siblings( '.ae-pq-relation-toggle' );
		$wrap.find( '.ae-pq-relation-btn' ).each( function () {
			$( this ).toggleClass( 'ae-pq-relation-btn--active', $( this ).data( 'val' ) === val );
		} );
	}

	// -------------------------------------------------------------------------
	// Show/hide meta key field when orderby = meta_value*
	// -------------------------------------------------------------------------
	$( '#ae_pq_orderby' ).on( 'change', function () {
		var val = $( this ).val();
		$( '.js-ae-pq-meta-order' ).toggle( val === 'meta_value' || val === 'meta_value_num' );
	} );

	// Serialize nested tax + meta models to hidden fields before submit.
	$( '#ae-pq-edit-form' ).on( 'submit', function () {
		$( '#ae_pq_tax_json' ).val( JSON.stringify( taxModel ) );
		$( '#ae_pq_meta_json' ).val( JSON.stringify( metaModel ) );
	} );

	// -------------------------------------------------------------------------
	// Code panel — tab switching + copy
	// -------------------------------------------------------------------------
	$( document ).on( 'click', '.ae-pq-code-tab', function () {
		var tab = $( this ).data( 'code-tab' );
		$( '.ae-pq-code-tab' ).removeClass( 'ae-pq-code-tab--active' );
		$( this ).addClass( 'ae-pq-code-tab--active' );
		$( '.ae-pq-code-block' ).hide();
		$( '#ae-pq-code-' + tab ).show();
	} );

	$( '#ae-pq-copy-code' ).on( 'click', function () {
		var $active = $( '.ae-pq-code-block:visible' );
		if ( $active.length ) {
			copyToClipboard( $active.text(), $( this ) );
		}
	} );

	function copyToClipboard( text, $trigger ) {
		if ( navigator.clipboard ) {
			navigator.clipboard.writeText( text ).then( function () {
				flashCopied( $trigger );
			} );
		} else {
			var $tmp = $( '<textarea>' ).val( text ).appendTo( 'body' ).select();
			document.execCommand( 'copy' );
			$tmp.remove();
			flashCopied( $trigger );
		}
	}

	function flashCopied( $el ) {
		var orig = $el.html();
		$el.html( '<span class="dashicons dashicons-yes"></span> Copied!' );
		setTimeout( function () { $el.html( orig ); }, 1500 );
	}

	// =========================================================================
	// Real-time code generation
	// =========================================================================

	function repeatStr( s, n ) {
		var o = '';
		for ( var i = 0; i < n; i++ ) { o += s; }
		return o;
	}

	/**
	 * Recursively convert a JS value to PHP syntax string.
	 */
	function phpExport( val, depth ) {
		depth = depth || 0;
		var ind      = repeatStr( '    ', depth );
		var nextInd  = repeatStr( '    ', depth + 1 );

		if ( val === null || val === undefined ) { return 'null'; }
		if ( typeof val === 'boolean' ) { return val ? 'true' : 'false'; }
		if ( typeof val === 'number' )  { return String( val ); }
		if ( typeof val === 'string' ) {
			return "'" + val.replace( /\\/g, '\\\\' ).replace( /'/g, "\\'" ) + "'";
		}

		if ( Array.isArray( val ) ) {
			if ( val.length === 0 ) { return '[]'; }
			var parts = val.map( function ( v ) { return nextInd + phpExport( v, depth + 1 ); } );
			return '[\n' + parts.join( ',\n' ) + ',\n' + ind + ']';
		}

		if ( typeof val === 'object' ) {
			var keys = Object.keys( val );
			if ( keys.length === 0 ) { return '[]'; }
			// Pure sequential numeric array?
			var isSeq = keys.every( function ( k, i ) { return k === String( i ); } );
			if ( isSeq ) {
				var seqParts = keys.map( function ( k ) { return nextInd + phpExport( val[ k ], depth + 1 ); } );
				return '[\n' + seqParts.join( ',\n' ) + ',\n' + ind + ']';
			}
			// Associative / mixed.
			var assocParts = keys.map( function ( k ) {
				var kStr = /^\d+$/.test( k ) ? k : ( "'" + k + "'" );
				return nextInd + kStr + ' => ' + phpExport( val[ k ], depth + 1 );
			} );
			return '[\n' + assocParts.join( ',\n' ) + ',\n' + ind + ']';
		}

		return String( val );
	}

	/**
	 * Build the current query args object from live form state.
	 */
	function buildCurrentArgs() {
		var args = {};

		// Basic.
		var pt = $( '#ae_pq_post_type' ).val();
		if ( pt ) { args.post_type = pt; }

		var ppp = parseInt( $( '#ae_pq_posts_per_page' ).val(), 10 );
		if ( ! isNaN( ppp ) ) { args.posts_per_page = ppp; }

		var status = $( '#ae_pq_post_status' ).val();
		if ( status ) { args.post_status = status; }

		var orderby = $( '#ae_pq_orderby' ).val();
		if ( orderby ) { args.orderby = orderby; }

		var order = $( '#ae_pq_order' ).val();
		if ( order ) { args.order = order; }

		var offset = parseInt( $( '#ae_pq_offset' ).val(), 10 );
		if ( ! isNaN( offset ) && offset > 0 ) { args.offset = offset; }

		var metaKey = $( '#ae_pq_meta_key_order' ).val();
		if ( metaKey && ( orderby === 'meta_value' || orderby === 'meta_value_num' ) ) {
			args.meta_key = metaKey;
		}

		if ( $( 'input[name="ae_pq_args[ignore_sticky_posts]"]' ).is( ':checked' ) ) {
			args.ignore_sticky_posts = true;
		}

		if ( $( 'input[name="ae_pq_exclude_current"]' ).is( ':checked' ) ) {
			args._ae_exclude_current = true;
		}

		// Search.
		var search = $( '#ae_pq_search' ).val();
		if ( search ) { args.s = search; }

		// Post & page parameters.
		var inVals = $( '#ae_pq_post_in' ).val();
		if ( inVals && inVals.length ) {
			var postIn = inVals.map( Number ).filter( function ( x ) { return x > 0; } );
			if ( postIn.length ) { args.post__in = postIn; }
		}

		// Post not in — Select2 multi-select returns array of strings.
		var notInVals = $( '#ae_pq_post_not_in' ).val();
		if ( ! args.post__in && notInVals && notInVals.length ) {
			var notIn = notInVals.map( Number ).filter( function ( x ) { return x > 0; } );
			if ( notIn.length ) { args.post__not_in = notIn; }
		}

		if ( $( '#ae_pq_post_parent_top_level' ).is( ':checked' ) ) {
			args.post_parent = 0;
		}

		var parentInVals = $( '#ae_pq_post_parent_in' ).val();
		if ( parentInVals && parentInVals.length ) {
			var postParentIn = parentInVals.map( Number ).filter( function ( x ) { return x > 0; } );
			if ( postParentIn.length ) { args.post_parent__in = postParentIn; }
		}

		var parentNotInVals = $( '#ae_pq_post_parent_not_in' ).val();
		if ( parentNotInVals && parentNotInVals.length ) {
			var postParentNotIn = parentNotInVals.map( Number ).filter( function ( x ) { return x > 0; } );
			if ( postParentNotIn.length ) { args.post_parent__not_in = postParentNotIn; }
		}

		// Tax query — from nested group builder model.
		var tqBuilt = buildTaxFromModel( taxModel );
		if ( tqBuilt !== null ) {
			args.tax_query = tqBuilt;
		}

		// Meta query — read from nested group builder model.
		var mqBuilt = buildMqFromModel( metaModel );
		if ( mqBuilt !== null ) {
			args.meta_query = mqBuilt;
		}

		// Date query.
		var dateMode = $( '#ae_pq_date_mode' ).val();
		if ( dateMode ) {
			var col    = $( '#ae_pq_date_column' ).val() || 'post_date';
			var dClause = { column: col };
			if ( dateMode === 'relative' ) {
				var rel = $( '#ae_pq_date_relative_val' ).val();
				if ( rel ) { dClause.after = rel; }
			} else {
				var after  = $( '#ae_pq_date_after' ).val();
				var before = $( '#ae_pq_date_before' ).val();
				if ( after )  { dClause.after  = after; }
				if ( before ) { dClause.before = before; }
			}
			if ( $( 'input[name="ae_pq_date[inclusive]"]' ).is( ':checked' ) ) {
				dClause.inclusive = true;
			}
			if ( dClause.after || dClause.before ) {
				args.date_query    = [ dClause ];
				args._ae_date_mode = dateMode;
			}
		}

		// Authors.
		var authorIds = $( '#ae_pq_author_ids' ).val();
		if ( authorIds && authorIds.length ) {
			var ids = authorIds.map( function ( x ) { return parseInt( x, 10 ); } )
				.filter( function ( x ) { return ! isNaN( x ); } );
			if ( ids.length ) {
				var op = $( '#ae_pq_author_operator' ).val() || 'in';
				args[ op === 'not_in' ? 'author__not_in' : 'author__in' ] = ids;
			}
		}

		return args;
	}

	/**
	 * Generate PHP $args code string.
	 */
	function buildPhpArrayCode( args ) {
		var prefix = '// Generated by Dynific Query Engine\n';
		var keys   = Object.keys( args || {} );
		if ( ! keys.length ) { return prefix + '$args = [];'; }
		var lines = keys.map( function ( k ) {
			return "    '" + k + "' => " + phpExport( args[ k ], 1 );
		} );
		return prefix + '$args = [\n' + lines.join( ',\n' ) + ',\n];';
	}

	/**
	 * Generate WP_Query code string.
	 */
	function buildWpQueryCode( args ) {
		var prefix = '// Generated by Dynific Query Engine\n';
		var keys   = Object.keys( args || {} );
		if ( ! keys.length ) {
			return prefix + '$query = new WP_Query( [] );';
		}
		var inner = phpExport( args, 0 );
		return prefix +
			'$query = new WP_Query( ' + inner + " );\n\n" +
			"while ( \$query->have_posts() ) {\n    \$query->the_post();\n    // ...\n}\n" +
			'wp_reset_postdata();';
	}

	/** Debounce timer handle */
	var _codeUpdateTimer = null;

	function scheduleCodeUpdate() {
		clearTimeout( _codeUpdateTimer );
		_codeUpdateTimer = setTimeout( updateCodePanels, 120 );
	}

	function updateCodePanels() {
		var args = buildCurrentArgs();
		$( '#ae-pq-code-php_array' ).text( buildPhpArrayCode( args ) );
		$( '#ae-pq-code-wp_query' ).text( buildWpQueryCode( args ) );
		// "Use Preset" tab is static — no update needed.
	}

	// Bind to every form field change / input for real-time update.
	$( '#ae-pq-edit-form' ).on(
		'change',
		'select, input[type="checkbox"], input[type="radio"], input[type="date"]',
		scheduleCodeUpdate
	);
	$( '#ae-pq-edit-form' ).on(
		'input',
		'input[type="text"], input[type="number"], textarea',
		scheduleCodeUpdate
	);

	// -------------------------------------------------------------------------
	// Taxonomy Filters — Nested Group Builder
	// -------------------------------------------------------------------------

	var taxModel = { type: 'group', relation: 'AND', children: [] };

	function getTaxList( postType ) {
		return ( aePQ.tax_map || {} )[ postType ] || [];
	}

	function buildTaxSelectOptions( taxes, selected ) {
		var out = '<option value="">' + ( taxes.length ? '— select —' : aePQ.i18n.no_taxonomy ) + '</option>';
		$.each( taxes, function ( i, tax ) {
			out += '<option value="' + tax.slug + '"' + ( selected === tax.slug ? ' selected' : '' ) + '>' + tax.label + '</option>';
		} );
		return out;
	}

	function needsTerms( operator ) {
		return operator !== 'EXISTS' && operator !== 'NOT EXISTS';
	}

	function initTermSelect2( $termSelect ) {
		if ( $termSelect.data( 'select2' ) ) { $termSelect.select2( 'destroy' ); }
		$termSelect.select2( {
			placeholder:       'Select terms…',
			allowClear:        false,
			dropdownAutoWidth: true,
			width:             'style',
		} );
	}

	function loadTerms( $termSelect, taxonomy, selected ) {
		selected = selected || [];

		// Init Select2 immediately with empty options so the field always shows
		// the Select2 UI — never the raw native <select multiple> during loading.
		$termSelect.html( '' );
		initTermSelect2( $termSelect );

		$.post( aePQ.ajax_url, {
			action: 'ae_pq_get_terms', nonce: aePQ.nonce, taxonomy: taxonomy,
		} ).done( function ( res ) {
			var html = '';
			if ( res.success && res.data.length ) {
				$.each( res.data, function ( i, term ) {
					var isSel = selected.indexOf( term.slug ) !== -1 ? ' selected' : '';
					html += '<option value="' + term.slug + '"' + isSel + '>' + term.name + ' (' + term.count + ')</option>';
				} );
			}
			if ( $termSelect.data( 'select2' ) ) { $termSelect.select2( 'destroy' ); }
			$termSelect.html( html );
			initTermSelect2( $termSelect );
		} ).fail( function () {
			if ( $termSelect.data( 'select2' ) ) { $termSelect.select2( 'destroy' ); }
			$termSelect.html( '' );
			initTermSelect2( $termSelect );
		} );
	}

	/**
	 * Parse a stored WP tax_query into our tree model format.
	 */
	function parseTaxFromStored( stored ) {
		if ( ! stored || typeof stored !== 'object' ) {
			return { type: 'group', relation: 'AND', children: [] };
		}
		var relation = ( stored.relation === 'OR' ) ? 'OR' : 'AND';
		var children = [];
		var i = 0;
		while ( stored.hasOwnProperty( String( i ) ) ) {
			var item = stored[ String( i ) ];
			if ( item && item.taxonomy ) {
				// Clause.
				children.push( {
					type:     'clause',
					taxonomy: item.taxonomy,
					field:    item.field    || 'slug',
					operator: item.operator || 'IN',
					terms:    Array.isArray( item.terms ) ? item.terms : [],
				} );
			} else if ( item && ( item.relation || item.hasOwnProperty( '0' ) ) ) {
				// Sub-group.
				children.push( parseTaxFromStored( item ) );
			}
			i++;
		}
		return { type: 'group', relation: relation, children: children };
	}

	/**
	 * Convert the tax tree model to a WP-compatible tax_query object.
	 */
	function buildTaxFromModel( groupNode ) {
		if ( ! groupNode || ! groupNode.children || ! groupNode.children.length ) {
			return null;
		}
		var result = {};
		var idx    = 0;

		$.each( groupNode.children, function ( i, child ) {
			if ( child.type === 'clause' ) {
				if ( ! child.taxonomy ) { return; }
				var clause = { taxonomy: child.taxonomy, field: child.field || 'slug', operator: child.operator || 'IN' };
				if ( needsTerms( child.operator ) && child.terms && child.terms.length ) {
					clause.terms = child.terms;
				} else if ( ! needsTerms( child.operator ) ) {
					clause.terms = [];
				} else {
					return; // skip empty clause
				}
				result[ idx++ ] = clause;
			} else if ( child.type === 'group' && child.children && child.children.length ) {
				var sub    = {};
				var subIdx = 0;
				$.each( child.children, function ( j, sc ) {
					if ( sc.type === 'clause' && sc.taxonomy ) {
						var c = { taxonomy: sc.taxonomy, field: sc.field || 'slug', operator: sc.operator || 'IN' };
						if ( needsTerms( sc.operator ) && sc.terms && sc.terms.length ) {
							c.terms = sc.terms;
						} else if ( ! needsTerms( sc.operator ) ) {
							c.terms = [];
						} else {
							return;
						}
						sub[ subIdx++ ] = c;
					}
				} );
				if ( subIdx > 0 ) {
					sub.relation   = child.relation || 'AND';
					result[ idx++ ] = sub;
				}
			}
		} );

		if ( idx === 0 ) { return null; }
		if ( idx > 1 )   { result.relation = groupNode.relation || 'AND'; }
		return result;
	}

	/**
	 * Render a taxonomy clause as a white bordered card with column headers.
	 * Mutates clauseRef on every field change.
	 */
	function renderTaxClause( clauseRef, parentGroup ) {
		var $card    = $( '<div class="ae-pq-tax-clause-card"></div>' );
		var postType = $( '#ae_pq_post_type' ).val();
		var taxes    = getTaxList( postType );

		// Column header row.
		var $headers = $( '<div class="ae-pq-row-headers ae-pq-tax-col-headers"></div>' )
			.append(
				$( '<span class="ae-pq-col-label">Taxonomy</span>' ),
				$( '<span class="ae-pq-col-label">Field</span>' ),
				$( '<span class="ae-pq-col-label ae-pq-col-terms-label">Terms</span>' ),
				$( '<span class="ae-pq-col-label ae-pq-col-op-label">Operator</span>' ),
				$( '<span class="ae-pq-col-spacer"></span>' )
			);

		// Input row.
		var $row = $( '<div class="ae-pq-tax-row"></div>' );

		var $taxSel = $( '<select class="ae-pq-tax-select">' + buildTaxSelectOptions( taxes, clauseRef.taxonomy || '' ) + '</select>' );
		var $fieldSel = $( '<select class="ae-pq-tax-field">' +
			'<option value="slug"'             + ( ( clauseRef.field || 'slug' ) === 'slug'             ? ' selected' : '' ) + '>Slug</option>' +
			'<option value="name"'             + ( clauseRef.field === 'name'             ? ' selected' : '' ) + '>Name</option>' +
			'<option value="term_id"'          + ( clauseRef.field === 'term_id'          ? ' selected' : '' ) + '>ID</option>' +
			'<option value="term_taxonomy_id"' + ( clauseRef.field === 'term_taxonomy_id' ? ' selected' : '' ) + '>Tax ID</option>' +
		'</select>' );

		var $termsSel = $( '<select multiple class="ae-pq-tax-terms"></select>' )
			.toggle( needsTerms( clauseRef.operator || 'IN' ) );

		var $opSel = $( '<select class="ae-pq-tax-operator">' +
			'<option value="IN"'         + ( ( clauseRef.operator || 'IN' ) === 'IN'         ? ' selected' : '' ) + '>IN</option>' +
			'<option value="NOT IN"'     + ( clauseRef.operator === 'NOT IN'     ? ' selected' : '' ) + '>NOT IN</option>' +
			'<option value="AND"'        + ( clauseRef.operator === 'AND'        ? ' selected' : '' ) + '>AND</option>' +
			'<option value="EXISTS"'     + ( clauseRef.operator === 'EXISTS'     ? ' selected' : '' ) + '>EXISTS</option>' +
			'<option value="NOT EXISTS"' + ( clauseRef.operator === 'NOT EXISTS' ? ' selected' : '' ) + '>NOT EXISTS</option>' +
		'</select>' );

		var $remove = $( '<button type="button" class="ae-pq-remove-tax-row">&times;</button>' )
			.on( 'click', function () {
				var idx = parentGroup.children.indexOf( clauseRef );
				if ( idx !== -1 ) { parentGroup.children.splice( idx, 1 ); }
				if ( $termsSel.data( 'select2' ) ) { $termsSel.select2( 'destroy' ); }
				$card.remove();
				scheduleCodeUpdate();
			} );

		$taxSel.on( 'change', function () {
			clauseRef.taxonomy = $( this ).val();
			clauseRef.terms    = [];
			if ( clauseRef.taxonomy && needsTerms( clauseRef.operator ) ) {
				loadTerms( $termsSel, clauseRef.taxonomy, [] );
			}
			scheduleCodeUpdate();
		} );

		$fieldSel.on( 'change', function () { clauseRef.field = $( this ).val(); scheduleCodeUpdate(); } );

		$opSel.on( 'change', function () {
			clauseRef.operator = $( this ).val();
			if ( needsTerms( clauseRef.operator ) ) {
				$termsSel.show();
				if ( clauseRef.taxonomy && ! $termsSel.find( 'option' ).length ) {
					loadTerms( $termsSel, clauseRef.taxonomy, clauseRef.terms || [] );
				}
			} else {
				$termsSel.hide();
			}
			scheduleCodeUpdate();
		} );

		$termsSel.on( 'change', function () {
			clauseRef.terms = $( this ).val() || [];
			scheduleCodeUpdate();
		} );

		$row.append( $taxSel, $fieldSel, $termsSel, $opSel, $remove );
		$card.append( $headers, $row );

		if ( clauseRef.taxonomy && needsTerms( clauseRef.operator || 'IN' ) ) {
			loadTerms( $termsSel, clauseRef.taxonomy, clauseRef.terms || [] );
		} else {
			initTermSelect2( $termsSel );
		}

		return $card;
	}

	/**
	 * Render a taxonomy group.
	 * depth=0 → flat root container with MATCH bar + children + footer buttons.
	 * depth=1 → nested panel with "NESTED GROUP" header + INNER MATCH bar + footer.
	 */
	function renderTaxGroup( groupRef, depth, removeSelf ) {

		// ---- ROOT GROUP (depth = 0) ----------------------------------------
		if ( depth === 0 ) {
			var $root = $( '<div class="ae-pq-tax-root"></div>' );

			// MATCH relation bar.
			var $relBar    = $( '<div class="ae-pq-relation-bar"></div>' );
			var $relLabel  = $( '<span class="ae-pq-relation-label">MATCH:</span>' );
			var $relToggle = $( '<div class="ae-pq-relation-toggle"></div>' );
			var $relAnd    = $( '<button type="button" class="ae-pq-relation-btn">AND</button>' );
			var $relOr     = $( '<button type="button" class="ae-pq-relation-btn">OR</button>' );

			function syncRootRel() {
				$relAnd.toggleClass( 'ae-pq-relation-btn--active', groupRef.relation !== 'OR' );
				$relOr.toggleClass(  'ae-pq-relation-btn--active', groupRef.relation === 'OR' );
			}
			syncRootRel();
			$relAnd.on( 'click', function () { groupRef.relation = 'AND'; syncRootRel(); scheduleCodeUpdate(); } );
			$relOr.on(  'click', function () { groupRef.relation = 'OR';  syncRootRel(); scheduleCodeUpdate(); } );
			$relToggle.append( $relAnd, $relOr );
			$relBar.append( $relLabel, $relToggle );
			$root.append( $relBar );

			// Children area.
			var $clauses = $( '<div class="ae-pq-tax-clauses"></div>' );
			$.each( groupRef.children, function ( i, child ) {
				if ( child.type === 'clause' ) {
					$clauses.append( renderTaxClause( child, groupRef ) );
				} else if ( child.type === 'group' ) {
					( function ( childRef ) {
						var $subEl = renderTaxGroup( childRef, 1, function () {
							var idx = groupRef.children.indexOf( childRef );
							if ( idx !== -1 ) { groupRef.children.splice( idx, 1 ); }
							$subEl.remove();
							scheduleCodeUpdate();
						} );
						$clauses.append( $subEl );
					} )( child );
				}
			} );
			$root.append( $clauses );

			// Footer: "+ Add Taxonomy Clause" + "+ Add Nested Group".
			var $footer    = $( '<div class="ae-pq-mg-footer"></div>' );
			var $addClause = $( '<button type="button" class="button">+ Add Taxonomy Clause</button>' )
				.on( 'click', function () {
					var clause = { type: 'clause', taxonomy: '', field: 'slug', operator: 'IN', terms: [] };
					groupRef.children.push( clause );
					$clauses.append( renderTaxClause( clause, groupRef ) );
					scheduleCodeUpdate();
				} );
			var $addGroup = $( '<button type="button" class="button">+ Add Nested Group</button>' )
				.on( 'click', function () {
					var subGroup = { type: 'group', relation: 'AND', children: [] };
					groupRef.children.push( subGroup );
					var $subEl = renderTaxGroup( subGroup, 1, function () {
						var idx = groupRef.children.indexOf( subGroup );
						if ( idx !== -1 ) { groupRef.children.splice( idx, 1 ); }
						$subEl.remove();
						scheduleCodeUpdate();
					} );
					$clauses.append( $subEl );
					scheduleCodeUpdate();
				} );
			$footer.append( $addClause, $addGroup );
			$root.append( $footer );
			return $root;
		}

		// ---- NESTED GROUP (depth = 1) --------------------------------------
		var $ng = $( '<div class="ae-pq-nested-group"></div>' );

		// Header: "⊕ NESTED GROUP" + red × remove.
		var $ngHeader = $( '<div class="ae-pq-nested-group-header"></div>' );
		var $ngTitle  = $( '<div class="ae-pq-nested-group-title">&#8853; NESTED GROUP</div>' );
		var $ngRemove = $( '<button type="button" class="ae-pq-remove-nested-group">&times;</button>' )
			.on( 'click', function () {
				if ( removeSelf ) { removeSelf(); }
				scheduleCodeUpdate();
			} );
		$ngHeader.append( $ngTitle, $ngRemove );
		$ng.append( $ngHeader );

		// INNER MATCH relation bar.
		var $innerBar    = $( '<div class="ae-pq-nested-relation-bar"></div>' );
		var $innerLabel  = $( '<span class="ae-pq-nested-relation-label">INNER MATCH:</span>' );
		var $innerToggle = $( '<div class="ae-pq-relation-toggle"></div>' );
		var $innerAnd    = $( '<button type="button" class="ae-pq-relation-btn">AND</button>' );
		var $innerOr     = $( '<button type="button" class="ae-pq-relation-btn">OR</button>' );

		function syncInnerRel() {
			$innerAnd.toggleClass( 'ae-pq-relation-btn--active', groupRef.relation !== 'OR' );
			$innerOr.toggleClass(  'ae-pq-relation-btn--active', groupRef.relation === 'OR' );
		}
		syncInnerRel();
		$innerAnd.on( 'click', function () { groupRef.relation = 'AND'; syncInnerRel(); scheduleCodeUpdate(); } );
		$innerOr.on(  'click', function () { groupRef.relation = 'OR';  syncInnerRel(); scheduleCodeUpdate(); } );
		$innerToggle.append( $innerAnd, $innerOr );
		$innerBar.append( $innerLabel, $innerToggle );
		$ng.append( $innerBar );

		// Clause cards.
		var $ngClauses = $( '<div class="ae-pq-nested-children"></div>' );
		$.each( groupRef.children, function ( i, child ) {
			if ( child.type === 'clause' ) {
				$ngClauses.append( renderTaxClause( child, groupRef ) );
			}
		} );
		$ng.append( $ngClauses );

		// Footer: "+ Add to Group".
		var $ngFooter    = $( '<div class="ae-pq-nested-group-footer"></div>' );
		var $ngAddClause = $( '<button type="button" class="button">+ Add to Group</button>' )
			.on( 'click', function () {
				var clause = { type: 'clause', taxonomy: '', field: 'slug', operator: 'IN', terms: [] };
				groupRef.children.push( clause );
				$ngClauses.append( renderTaxClause( clause, groupRef ) );
				scheduleCodeUpdate();
			} );
		$ngFooter.append( $ngAddClause );
		$ng.append( $ngFooter );
		return $ng;
	}

	// Init taxonomy builder.
	( function () {
		taxModel = parseTaxFromStored( aePQ.stored_tax_query || null );
		renderTaxGroup( taxModel, 0, null ).appendTo( '#ae-pq-tax-builder' );

		if ( taxModel.children.length ) {
			$( '[data-target="ae-pq-section-taxonomy"]' ).removeClass( 'ae-pq-section-header--collapsed' );
			$( '#ae-pq-section-taxonomy' ).removeClass( 'ae-pq-section-body--collapsed' );
		}
	} )();

	// When post type changes, rebuild taxonomy selects in all existing clause rows.
	$( '#ae_pq_post_type' ).on( 'change.tax', function () {
		var postType = $( this ).val();
		var taxes    = getTaxList( postType );
		$( '#ae-pq-tax-builder .ae-pq-tax-select' ).each( function () {
			var current = $( this ).val();
			$( this ).html( buildTaxSelectOptions( taxes, current ) );
		} );
	} );

	// -------------------------------------------------------------------------
	// Meta Query — Nested Group Builder
	// -------------------------------------------------------------------------

	// Live tree model — mutated directly by renderClause / renderGroup callbacks.
	var metaModel = { type: 'group', relation: 'AND', children: [] };

	var metaCompareOpts = [
		[ '=',           '= (Equal)'              ],
		[ '!=',          '!= (Not equal)'          ],
		[ '>',           '> (Greater than)'        ],
		[ '>=',          '>= (Greater or equal)'   ],
		[ '<',           '< (Less than)'           ],
		[ '<=',          '<= (Less or equal)'      ],
		[ 'LIKE',        'LIKE'                     ],
		[ 'NOT LIKE',    'NOT LIKE'                 ],
		[ 'IN',          'IN (comma-separated)'     ],
		[ 'NOT IN',      'NOT IN (comma-separated)' ],
		[ 'BETWEEN',     'BETWEEN (two values)'     ],
		[ 'NOT BETWEEN', 'NOT BETWEEN (two values)' ],
		[ 'EXISTS',      'EXISTS'                   ],
		[ 'NOT EXISTS',  'NOT EXISTS'               ],
		[ 'REGEXP',      'REGEXP'                   ],
		[ 'NOT REGEXP',  'NOT REGEXP'               ],
	];

	var metaTypeOpts = [
		[ 'CHAR',     'Text (CHAR)' ],
		[ 'NUMERIC',  'Numeric'     ],
		[ 'DECIMAL',  'Decimal'     ],
		[ 'DATE',     'Date'        ],
		[ 'TIME',     'Time'        ],
		[ 'DATETIME', 'DateTime'    ],
		[ 'BINARY',   'Binary'      ],
	];

	function metaNeedsValue( compare ) {
		return compare !== 'EXISTS' && compare !== 'NOT EXISTS';
	}

	function buildMetaOptions( opts, selected ) {
		var out = '';
		$.each( opts, function ( i, o ) {
			out += '<option value="' + o[0] + '"' + ( selected === o[0] ? ' selected' : '' ) + '>' + o[1] + '</option>';
		} );
		return out;
	}

	// Performance warnings shown for expensive compare operators regardless of field type.
	var metaPerfWarnings = {
		'LIKE':       'LIKE queries scan every row and cannot use database indexes — may be slow on large sites.',
		'NOT LIKE':   'NOT LIKE queries scan every row and cannot use database indexes — may be slow on large sites.',
		'REGEXP':     'REGEXP matching does not use database indexes and is CPU-intensive on large datasets.',
		'NOT REGEXP': 'NOT REGEXP matching does not use database indexes and is CPU-intensive on large datasets.',
		'NOT IN':     'NOT IN can cause a full table scan — consider an alternative if the meta table is large.',
		'NOT EXISTS': 'NOT EXISTS can cause a full table scan — consider an alternative if the meta table is large.',
	};

	// Counter for unique form field id/name attributes (avoids browser accessibility warnings).
	var metaClauseIdx = 0;

	/**
	 * Parse a stored WP meta_query (PHP array → JS object with string numeric keys)
	 * into our tree model format.
	 */
	function parseMqFromStored( stored ) {
		if ( ! stored || typeof stored !== 'object' ) {
			return { type: 'group', relation: 'AND', children: [] };
		}
		var relation = ( stored.relation === 'OR' ) ? 'OR' : 'AND';
		var children = [];
		var i = 0;
		while ( stored.hasOwnProperty( String( i ) ) ) {
			var item = stored[ String( i ) ];
			if ( item && item.key ) {
				// Clause.
				var val = Array.isArray( item.value ) ? item.value.join( ', ' ) : ( item.value || '' );
				children.push( {
					type:     'clause',
					key:      item.key,
					compare:  item.compare  || '=',
					value:    String( val ),
					dataType: item.type     || 'CHAR',
				} );
			} else if ( item && ( item.relation || item.hasOwnProperty( '0' ) ) ) {
				// Sub-group.
				children.push( parseMqFromStored( item ) );
			}
			i++;
		}
		return { type: 'group', relation: relation, children: children };
	}

	/**
	 * Convert the tree model to a WP-compatible meta_query object
	 * (numeric string keys + optional relation key) for the code preview.
	 */
	function buildMqFromModel( groupNode ) {
		if ( ! groupNode || ! groupNode.children || ! groupNode.children.length ) {
			return null;
		}
		var result = {};
		var idx    = 0;

		$.each( groupNode.children, function ( i, child ) {
			if ( child.type === 'clause' ) {
				if ( ! child.key ) { return; }
				var clause = { key: child.key, compare: child.compare || '=', type: child.dataType || 'CHAR' };
				if ( metaNeedsValue( child.compare ) ) {
					if ( [ 'IN', 'NOT IN', 'BETWEEN', 'NOT BETWEEN' ].indexOf( child.compare ) !== -1 ) {
						clause.value = child.value.split( ',' ).map( function ( x ) { return x.trim(); } ).filter( Boolean );
					} else {
						clause.value = child.value || '';
					}
				}
				result[ idx++ ] = clause;
			} else if ( child.type === 'group' && child.children && child.children.length ) {
				var sub    = {};
				var subIdx = 0;
				$.each( child.children, function ( j, sc ) {
					if ( sc.type === 'clause' && sc.key ) {
						var c = { key: sc.key, compare: sc.compare || '=', type: sc.dataType || 'CHAR' };
						if ( metaNeedsValue( sc.compare ) ) {
							if ( [ 'IN', 'NOT IN', 'BETWEEN', 'NOT BETWEEN' ].indexOf( sc.compare ) !== -1 ) {
								c.value = sc.value.split( ',' ).map( function ( x ) { return x.trim(); } ).filter( Boolean );
							} else {
								c.value = sc.value || '';
							}
						}
						sub[ subIdx++ ] = c;
					}
				} );
				if ( subIdx > 0 ) {
					sub.relation   = child.relation || 'AND';
					result[ idx++ ] = sub;
				}
			}
		} );

		if ( idx === 0 ) { return null; }
		if ( idx > 1 )   { result.relation = groupNode.relation || 'AND'; }
		return result;
	}

	/**
	 * Render a meta clause as a white bordered card with column headers.
	 * Mutates clauseRef on every field change.
	 */
	function renderClause( clauseRef, parentGroup ) {
		var cid   = ++metaClauseIdx;
		var $card = $( '<div class="ae-pq-meta-clause-card"></div>' );

		// Column header row.
		var $headers = $( '<div class="ae-pq-row-headers ae-pq-meta-col-headers"></div>' )
			.append(
				$( '<span class="ae-pq-col-label ae-pq-meta-col-key">Key</span>' ),
				$( '<span class="ae-pq-col-label ae-pq-meta-col-compare">Compare</span>' ),
				$( '<span class="ae-pq-col-label ae-pq-meta-col-value">Value</span>' ),
				$( '<span class="ae-pq-col-label ae-pq-meta-col-type">Type</span>' ),
				$( '<span class="ae-pq-col-spacer"></span>' )
			);

		// Performance warning (yellow) — shown for inherently expensive operators.
		var $perfWarning = $( '<p class="ae-pq-perf-warning"></p>' ).hide();

		// Input row.
		var $row = $( '<div class="ae-pq-meta-row"></div>' );

		var $key = $( '<input type="text" class="ae-pq-meta-key-input" name="ae_mk_' + cid + '" id="ae_mk_' + cid + '" placeholder="e.g. _price">' )
			.val( clauseRef.key || '' )
			.on( 'input', function () { clauseRef.key = $( this ).val(); scheduleCodeUpdate(); } );

		var $compare = $( '<select class="ae-pq-meta-compare" name="ae_mc_' + cid + '" id="ae_mc_' + cid + '">' + buildMetaOptions( metaCompareOpts, clauseRef.compare || '=' ) + '</select>' );

		var $val = $( '<input type="text" class="ae-pq-meta-value" name="ae_mv_' + cid + '" id="ae_mv_' + cid + '" placeholder="value">' )
			.val( clauseRef.value || '' )
			.toggle( metaNeedsValue( clauseRef.compare || '=' ) )
			.on( 'input', function () { clauseRef.value = $( this ).val(); scheduleCodeUpdate(); } );

		var $type = $( '<select class="ae-pq-meta-type" name="ae_mt_' + cid + '" id="ae_mt_' + cid + '">' + buildMetaOptions( metaTypeOpts, clauseRef.dataType || 'CHAR' ) + '</select>' )
			.on( 'change', function () { clauseRef.dataType = $( this ).val(); scheduleCodeUpdate(); } );

		var $remove = $( '<button type="button" class="ae-pq-remove-meta-row">&times;</button>' )
			.on( 'click', function () {
				var idx = parentGroup.children.indexOf( clauseRef );
				if ( idx !== -1 ) { parentGroup.children.splice( idx, 1 ); }
				$card.remove();
				scheduleCodeUpdate();
			} );

		/**
		 * Sync performance warning based on the selected compare operator.
		 */
		function syncPerfState() {
			var msg = metaPerfWarnings[ $compare.val() ];
			if ( msg ) {
				$perfWarning.text( '⚠ ' + msg ).show();
			} else {
				$perfWarning.hide();
			}
		}

		$compare.on( 'change', function () {
			clauseRef.compare = $( this ).val();
			metaNeedsValue( clauseRef.compare ) ? $val.show() : $val.hide();
			syncPerfState();
			scheduleCodeUpdate();
		} );

		$row.append( $key, $compare, $val, $type, $remove );
		$card.append( $headers, $row, $perfWarning );

		// Restore performance warning for existing clauses.
		if ( clauseRef.compare ) {
			syncPerfState();
		}

		return $card;
	}

	/**
	 * Render a meta group.
	 * depth=0 → flat root container with MATCH bar + children + footer buttons.
	 * depth=1 → nested panel with "NESTED GROUP" header + INNER MATCH bar + footer.
	 */
	function renderGroup( groupRef, depth, removeSelf ) {

		// ---- ROOT GROUP (depth = 0) ----------------------------------------
		if ( depth === 0 ) {
			var $root = $( '<div class="ae-pq-meta-root"></div>' );

			// MATCH relation bar.
			var $relBar    = $( '<div class="ae-pq-relation-bar"></div>' );
			var $relLabel  = $( '<span class="ae-pq-relation-label">MATCH:</span>' );
			var $relToggle = $( '<div class="ae-pq-relation-toggle"></div>' );
			var $relAnd    = $( '<button type="button" class="ae-pq-relation-btn">AND</button>' );
			var $relOr     = $( '<button type="button" class="ae-pq-relation-btn">OR</button>' );
			var $orWarning = $( '<p class="ae-pq-perf-warning ae-pq-or-warning"></p>' ).hide();

			function syncRootRel() {
				$relAnd.toggleClass( 'ae-pq-relation-btn--active', groupRef.relation !== 'OR' );
				$relOr.toggleClass(  'ae-pq-relation-btn--active', groupRef.relation === 'OR' );
				if ( groupRef.relation === 'OR' && groupRef.children.length > 1 ) {
					$orWarning.text( '⚠ OR relation across multiple meta clauses cannot use combined indexes — may be slow on large sites.' ).show();
				} else {
					$orWarning.hide();
				}
			}
			syncRootRel();
			$relAnd.on( 'click', function () { groupRef.relation = 'AND'; syncRootRel(); scheduleCodeUpdate(); } );
			$relOr.on(  'click', function () { groupRef.relation = 'OR';  syncRootRel(); scheduleCodeUpdate(); } );
			$relToggle.append( $relAnd, $relOr );
			$relBar.append( $relLabel, $relToggle, $orWarning );
			$root.append( $relBar );

			// Children area.
			var $clauses = $( '<div class="ae-pq-meta-clauses"></div>' );
			$.each( groupRef.children, function ( i, child ) {
				if ( child.type === 'clause' ) {
					$clauses.append( renderClause( child, groupRef ) );
				} else if ( child.type === 'group' ) {
					( function ( childRef ) {
						var $subEl = renderGroup( childRef, 1, function () {
							var idx = groupRef.children.indexOf( childRef );
							if ( idx !== -1 ) { groupRef.children.splice( idx, 1 ); }
							$subEl.remove();
							scheduleCodeUpdate();
						} );
						$clauses.append( $subEl );
					} )( child );
				}
			} );
			$root.append( $clauses );

			// Footer: "+ Add Meta Condition" + "+ Add Nested Group".
			var $footer    = $( '<div class="ae-pq-mg-footer"></div>' );
			var $addClause = $( '<button type="button" class="button">+ Add Meta Condition</button>' )
				.on( 'click', function () {
					var clause = { type: 'clause', key: '', compare: '=', value: '', dataType: 'CHAR' };
					groupRef.children.push( clause );
					$clauses.append( renderClause( clause, groupRef ) );
					scheduleCodeUpdate();
				} );
			var $addGroup = $( '<button type="button" class="button">+ Add Nested Group</button>' )
				.on( 'click', function () {
					var subGroup = { type: 'group', relation: 'AND', children: [] };
					groupRef.children.push( subGroup );
					var $subEl = renderGroup( subGroup, 1, function () {
						var idx = groupRef.children.indexOf( subGroup );
						if ( idx !== -1 ) { groupRef.children.splice( idx, 1 ); }
						$subEl.remove();
						scheduleCodeUpdate();
					} );
					$clauses.append( $subEl );
					scheduleCodeUpdate();
				} );
			$footer.append( $addClause, $addGroup );
			$root.append( $footer );
			return $root;
		}

		// ---- NESTED GROUP (depth = 1) --------------------------------------
		var $ng = $( '<div class="ae-pq-nested-group"></div>' );

		// Header: "⊕ NESTED GROUP" + red × remove.
		var $ngHeader = $( '<div class="ae-pq-nested-group-header"></div>' );
		var $ngTitle  = $( '<div class="ae-pq-nested-group-title">&#8853; NESTED GROUP</div>' );
		var $ngRemove = $( '<button type="button" class="ae-pq-remove-nested-group">&times;</button>' )
			.on( 'click', function () {
				if ( removeSelf ) { removeSelf(); }
				scheduleCodeUpdate();
			} );
		$ngHeader.append( $ngTitle, $ngRemove );
		$ng.append( $ngHeader );

		// INNER MATCH relation bar.
		var $innerBar    = $( '<div class="ae-pq-nested-relation-bar"></div>' );
		var $innerLabel  = $( '<span class="ae-pq-nested-relation-label">INNER MATCH:</span>' );
		var $innerToggle = $( '<div class="ae-pq-relation-toggle"></div>' );
		var $innerAnd    = $( '<button type="button" class="ae-pq-relation-btn">AND</button>' );
		var $innerOr     = $( '<button type="button" class="ae-pq-relation-btn">OR</button>' );

		function syncInnerRel() {
			$innerAnd.toggleClass( 'ae-pq-relation-btn--active', groupRef.relation !== 'OR' );
			$innerOr.toggleClass(  'ae-pq-relation-btn--active', groupRef.relation === 'OR' );
		}
		syncInnerRel();
		$innerAnd.on( 'click', function () { groupRef.relation = 'AND'; syncInnerRel(); scheduleCodeUpdate(); } );
		$innerOr.on(  'click', function () { groupRef.relation = 'OR';  syncInnerRel(); scheduleCodeUpdate(); } );
		$innerToggle.append( $innerAnd, $innerOr );
		$innerBar.append( $innerLabel, $innerToggle );
		$ng.append( $innerBar );

		// Clause cards.
		var $ngClauses = $( '<div class="ae-pq-nested-children"></div>' );
		$.each( groupRef.children, function ( i, child ) {
			if ( child.type === 'clause' ) {
				$ngClauses.append( renderClause( child, groupRef ) );
			}
		} );
		$ng.append( $ngClauses );

		// Footer: "+ Add to Group".
		var $ngFooter    = $( '<div class="ae-pq-nested-group-footer"></div>' );
		var $ngAddClause = $( '<button type="button" class="button">+ Add to Group</button>' )
			.on( 'click', function () {
				var clause = { type: 'clause', key: '', compare: '=', value: '', dataType: 'CHAR' };
				groupRef.children.push( clause );
				$ngClauses.append( renderClause( clause, groupRef ) );
				scheduleCodeUpdate();
			} );
		$ngFooter.append( $ngAddClause );
		$ng.append( $ngFooter );
		return $ng;
	}

	// — Init: parse stored data and render —
	( function () {
		metaModel = parseMqFromStored( aePQ.stored_meta_query || null );
		renderGroup( metaModel, 0, null ).appendTo( '#ae-pq-meta-builder' );

		if ( metaModel.children.length ) {
			$( '[data-target="ae-pq-section-meta"]' ).removeClass( 'ae-pq-section-header--collapsed' );
			$( '#ae-pq-section-meta' ).removeClass( 'ae-pq-section-body--collapsed' );
		}

	} )();

	// -------------------------------------------------------------------------
	// Exclude Posts — Select2 multi-select populated by post type
	// -------------------------------------------------------------------------
	function loadPostSelect( selector, postType, config ) {
		var $sel      = $( selector );
		var storedRaw = ( $sel.data( 'stored' ) || '' ).toString();
		var isMultiple = !! config.multiple;
		var stored;

		if ( isMultiple ) {
			stored = storedRaw.split( ',' ).filter( Boolean ).map( Number );
		} else {
			stored = storedRaw === '' ? '' : String( Number( storedRaw ) );
		}

		if ( $sel.data( 'select2' ) ) { $sel.select2( 'destroy' ); }
		$sel.html( '' );

		$.post( aePQ.ajax_url, {
			action: 'ae_pq_get_posts', nonce: aePQ.nonce, post_type: postType,
		} ).done( function ( res ) {
			if ( ! res.success ) { return; }
			var $frag = $( document.createDocumentFragment() );
			if ( ! isMultiple ) {
				$frag.append( $( '<option>' ).val( '' ).text( config.emptyLabel ) );
				if ( config.includeTopLevel ) {
					$frag.append( $( '<option>' ).val( '0' ).text( config.topLevelLabel ) );
				}
			}
			$.each( res.data, function ( i, post ) {
				// Full title in option text — shown as-is in the dropdown list.
				var $opt = $( '<option>' ).val( post.id )
					.text( post.title + ' (#' + post.id + ')' )
					.attr( 'data-raw-title', post.title );
				if ( isMultiple ) {
					if ( stored.indexOf( post.id ) !== -1 ) { $opt.prop( 'selected', true ); }
				} else if ( stored !== '' && stored === String( post.id ) ) {
					$opt.prop( 'selected', true );
				}
				$frag.append( $opt );
			} );
			if ( $sel.data( 'select2' ) ) { $sel.select2( 'destroy' ); }
			$sel.empty().append( $frag );
			$sel.select2( {
				placeholder: config.placeholder,
				allowClear: !! config.allowClear,
				width: '100%',
				// Truncate only in the selected chip, not in the dropdown list.
				templateSelection: function ( state ) {
					if ( ! state.id || state.id === '0' ) { return state.text; }
					var title = $( state.element ).data( 'raw-title' ) || state.text;
					var short = title.length > 15 ? title.substring( 0, 15 ) + '…' : title;
					return short + ' (#' + state.id + ')';
				},
			} );
			if ( ! isMultiple && stored === '0' ) {
				$sel.val( '0' ).trigger( 'change.select2' );
			}
			scheduleCodeUpdate();
		} );
	}

	( function () {
		var postType = $( '#ae_pq_post_type' ).val();
		loadPostSelect( '#ae_pq_post_in', postType, {
			multiple: true,
			placeholder: 'Search posts to include…',
			allowClear: false,
		} );
		loadPostSelect( '#ae_pq_post_not_in', postType, {
			multiple: true,
			placeholder: 'Search posts to exclude…',
			allowClear: false,
		} );
		loadPostSelect( '#ae_pq_post_parent_in', postType, {
			multiple: true,
			placeholder: 'Search parent posts to include…',
			allowClear: false,
		} );
		loadPostSelect( '#ae_pq_post_parent_not_in', postType, {
			multiple: true,
			placeholder: 'Search parent posts to exclude…',
			allowClear: false,
		} );
	} )();

	$( '#ae_pq_post_type' ).on( 'change.postparams', function () {
		// Clear stored selection when post type changes — IDs from old type are irrelevant.
		$( '#ae_pq_post_in, #ae_pq_post_not_in, #ae_pq_post_parent_in, #ae_pq_post_parent_not_in' ).data( 'stored', '' );
		$( '#ae_pq_post_parent_top_level' ).prop( 'checked', false );

		var postType = $( this ).val();
		loadPostSelect( '#ae_pq_post_in', postType, {
			multiple: true,
			placeholder: 'Search posts to include…',
			allowClear: false,
		} );
		loadPostSelect( '#ae_pq_post_not_in', postType, {
			multiple: true,
			placeholder: 'Search posts to exclude…',
			allowClear: false,
		} );
		loadPostSelect( '#ae_pq_post_parent_in', postType, {
			multiple: true,
			placeholder: 'Search parent posts to include…',
			allowClear: false,
		} );
		loadPostSelect( '#ae_pq_post_parent_not_in', postType, {
			multiple: true,
			placeholder: 'Search parent posts to exclude…',
			allowClear: false,
		} );
	} );

	// -------------------------------------------------------------------------
	// Date Filters — mode toggle
	// -------------------------------------------------------------------------
	$( '#ae_pq_date_mode' ).on( 'change', function () {
		if ( $( this ).val() === 'relative' ) {
			$( '#ae-pq-date-static' ).hide();
			$( '#ae-pq-date-relative' ).show();
		} else {
			$( '#ae-pq-date-static' ).show();
			$( '#ae-pq-date-relative' ).hide();
		}
	} );

	// -------------------------------------------------------------------------
	// Author Filters
	// -------------------------------------------------------------------------
	( function () {
		var $select  = $( '#ae_pq_author_ids' );
		var stored   = aePQ.stored_author_ids      || [];
		var operator = aePQ.stored_author_operator || 'in';

		$.post( aePQ.ajax_url, {
			action: 'ae_pq_get_authors', nonce: aePQ.nonce,
		} ).done( function ( res ) {
			if ( ! res.success ) { return; }
			var opts = '';
			$.each( res.data, function ( i, user ) {
				var isSel = stored.indexOf( user.id ) !== -1 ? ' selected' : '';
				opts += '<option value="' + user.id + '"' + isSel + '>' + user.name + '</option>';
			} );
			$select.html( opts );
			$select.select2( { placeholder: 'Select authors…', width: '100%' } );

			if ( stored.length ) {
				$( '#ae_pq_author_operator' ).val( operator );
				$( '[data-target="ae-pq-section-authors"]' ).removeClass( 'ae-pq-section-header--collapsed' );
				$( '#ae-pq-section-authors' ).removeClass( 'ae-pq-section-body--collapsed' );
			}
		} );
	} )();

	// -------------------------------------------------------------------------
	// Live Preview (Test Query) — paginated
	// -------------------------------------------------------------------------
	var previewPage = 1;

	function runPreview() {
		var $btn        = $( '#ae-pq-run-preview' );
		var $panel      = $( '#ae-pq-preview-results' );
		var $countText  = $( '#ae-pq-preview-count-text' );
		var $list       = $( '#ae-pq-preview-titles' );
		var $pagination = $( '#ae-pq-preview-pagination' );
		var $prevBtn    = $( '#ae-pq-prev-page' );
		var $nextBtn    = $( '#ae-pq-next-page' );
		var $pageInfo   = $( '#ae-pq-page-info' );

		$btn.prop( 'disabled', true ).text( '▶ Running…' );

		$.post( aePQ.ajax_url, {
			action:     'ae_pq_preview',
			nonce:      aePQ.nonce,
			query_args: JSON.stringify( buildCurrentArgs() ),
			page:       previewPage,
		} )
		.done( function ( res ) {
			if ( res.success ) {
				var d = res.data;
				var showing = d.posts ? d.posts.length : 0;
				$countText.text(
					'Showing ' + showing + ' of ' + d.total + ' matching post' + ( d.total === 1 ? '' : 's' )
				);
				$list.empty();
				$.each( d.posts, function ( i, post ) {
					$list.append(
						'<li>' +
							'<span class="ae-pq-preview-id">#' + post.id + '</span>' +
							'<span class="ae-pq-preview-title">' + $( '<span>' ).text( post.title ).html() + '</span>' +
						'</li>'
					);
				} );
				if ( d.total_pages > 1 ) {
					$pageInfo.text( 'Page ' + d.page + ' of ' + d.total_pages );
					$prevBtn.prop( 'disabled', d.page <= 1 );
					$nextBtn.prop( 'disabled', d.page >= d.total_pages );
					$pagination.show();
				} else {
					$pagination.hide();
				}
				$panel.show();
			} else {
				alert( aePQ.i18n.error );
			}
		} )
		.fail( function () { alert( aePQ.i18n.error ); } )
		.always( function () {
			$btn.prop( 'disabled', false ).text( '▶ Test Query' );
		} );
	}

	$( document ).on( 'click', '#ae-pq-run-preview', function () {
		previewPage = 1;
		runPreview();
	} );

	$( document ).on( 'click', '#ae-pq-prev-page', function () {
		if ( previewPage > 1 ) {
			previewPage--;
			runPreview();
		}
	} );

	$( document ).on( 'click', '#ae-pq-next-page', function () {
		previewPage++;
		runPreview();
	} );

	// -------------------------------------------------------------------------
	// Initial code panel render
	// -------------------------------------------------------------------------
	updateCodePanels();

} )( jQuery );
