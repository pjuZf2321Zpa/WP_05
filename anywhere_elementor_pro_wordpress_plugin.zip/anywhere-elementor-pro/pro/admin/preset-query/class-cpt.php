<?php
namespace Aepro\Admin\PresetQuery;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Cpt {

	const POST_TYPE = 'ae_preset_query';

	private static $_instance = null;

	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	private function __construct() {
		add_action( 'init', [ $this, 'register' ], 0 );
	}

	public function register() {
		register_post_type(
			self::POST_TYPE,
			[
				'labels' => [
					'name'               => __( 'Preset Queries', 'ae-pro' ),
					'singular_name'      => __( 'Preset Query', 'ae-pro' ),
					'add_new'            => __( 'Add New Preset', 'ae-pro' ),
					'add_new_item'       => __( 'Add New Preset', 'ae-pro' ),
					'edit_item'          => __( 'Edit Preset', 'ae-pro' ),
					'new_item'           => __( 'New Preset', 'ae-pro' ),
					'search_items'       => __( 'Search Presets', 'ae-pro' ),
					'not_found'          => __( 'No presets found.', 'ae-pro' ),
					'not_found_in_trash' => __( 'No presets found in Trash.', 'ae-pro' ),
					'all_items'          => __( 'Preset Queries', 'ae-pro' ),
				],
				'public'              => false,
				'show_ui'             => false,
				'show_in_menu'        => false,
				'show_in_nav_menus'   => false,
				'show_in_admin_bar'   => false,
				'show_in_rest'        => false,
				'exclude_from_search' => true,
				'supports'            => [ 'title' ],
				'capability_type'     => 'post',
				'map_meta_cap'        => true,
			]
		);
	}
}
