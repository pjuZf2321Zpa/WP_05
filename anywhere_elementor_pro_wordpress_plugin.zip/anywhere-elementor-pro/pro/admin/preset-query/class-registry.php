<?php
namespace Aepro\Admin\PresetQuery;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Registry {

	private static $_instance = null;

	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	private function __construct() {}

	/**
	 * Returns [ '' => '— Select Preset —', 42 => 'Blog Posts', ... ]
	 * Only published presets are included (publish = active, draft = inactive).
	 */
	public function get_presets_for_select() {
		$presets = [ '' => __( '— Select Preset —', 'ae-pro' ) ];

		$posts = get_posts( [
			'post_type'      => Cpt::POST_TYPE,
			'post_status'    => 'publish',
			'posts_per_page' => -1,
			'orderby'        => 'title',
			'order'          => 'ASC',
		] );

		foreach ( $posts as $post ) {
			$presets[ $post->ID ] = $post->post_title;
		}

		return $presets;
	}

	/**
	 * Returns true if a preset with the given ID exists and is published.
	 */
	public function preset_exists( $id ) {
		$post = get_post( absint( $id ) );
		return $post && $post->post_type === Cpt::POST_TYPE && $post->post_status === 'publish';
	}

	/**
	 * Returns the stored WP_Query args for a preset.
	 * Reads directly from post meta — no custom caching layer.
	 * Elementor handles widget-level caching as part of its rendering pipeline.
	 */
	public function get_query_args( $id ) {
		$id  = absint( $id );
		$raw = get_post_meta( $id, 'ae_preset_query_args', true );

		$args = $raw ? json_decode( $raw, true ) : [];

		if ( ! is_array( $args ) ) {
			$args = [];
		}

		return apply_filters( 'aepro/preset-query/args', $args, $id );
	}
}
