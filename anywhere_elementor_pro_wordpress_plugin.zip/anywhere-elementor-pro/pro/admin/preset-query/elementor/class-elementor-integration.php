<?php
namespace Aepro\Admin\PresetQuery\Elementor;

use Aepro\Admin\PresetQuery\Registry;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Injects a "Preset Query" selector at the top of Elementor's native Query
 * section for supported query widgets (Posts, Portfolio, Loop Grid,
 * Loop Carousel, WooCommerce Products).
 *
 * When a preset is selected the stored WP_Query args replace the widget's
 * query entirely via the standard `elementor/query/query_args` filter, so
 * Elementor's own pagination handling continues to work normally.
 *
 * No Elementor files are modified — only published hooks and filters are used.
 */
final class Elementor_Integration {

	private static ?self $_instance = null;

	/**
	 * Elementor widget names that have a `section_query` section and run
	 * their query through Elementor_Post_Query (which fires the
	 * `elementor/query/query_args` filter).
	 */
	private const SUPPORTED_WIDGETS = [
		'posts',
		'portfolio',
		'loop-grid',
		'loop-carousel',
		'woocommerce-products',
	];

	public static function instance(): self {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	private function __construct() {
		foreach ( self::SUPPORTED_WIDGETS as $widget_name ) {
			add_action(
				'elementor/element/' . $widget_name . '/section_query/after_section_start',
				[ $this, 'inject_preset_control' ],
				5,   // Priority 5 — before the widget / skin adds its own query controls.
				2
			);
		}

		add_filter( 'elementor/query/query_args', [ $this, 'apply_preset_query' ], 10, 2 );
	}

	// -------------------------------------------------------------------------
	// Control injection
	// -------------------------------------------------------------------------

	/**
	 * Inject the Preset Query SELECT at the very top of Elementor's Query section.
	 *
	 * @param \Elementor\Element_Base $element
	 */
	public function inject_preset_control( $element ): void {
		$presets = Registry::instance()->get_presets_for_select();

		$element->add_control(
			'ae_pq_preset_id',
			[
				'label'   => __( 'Preset Query', 'ae-pro' ),
				'type'    => Controls_Manager::SELECT,
				'options' => $presets,
				'default' => '',
			]
		);

		if ( count( $presets ) <= 1 ) {
			$create_url = admin_url( 'admin.php?page=ae-preset-query&action=new' );
			$element->add_control(
				'ae_pq_empty_notice',
				[
					'type'      => Controls_Manager::RAW_HTML,
					'raw'       => '<p style="font-size:11px;color:#8c8f94;margin:2px 0 6px;">' .
						sprintf(
							/* translators: %s: link to create a preset query */
							esc_html__( 'No query presets found. %s', 'ae-pro' ),
							'<a href="' . esc_url( $create_url ) . '" target="_blank">' .
								esc_html__( 'Create one ↗', 'ae-pro' ) .
							'</a>'
						) .
						'</p>',
					'condition' => [ 'ae_pq_preset_id' => '' ],
				]
			);
		}

		$list_url = admin_url( 'admin.php?page=ae-preset-query' );
		$element->add_control(
			'ae_pq_active_notice',
			[
				'type'      => Controls_Manager::RAW_HTML,
				'raw'       => '<div style="font-size:11px;background:#fff8e1;border:1px solid #ffe082;border-radius:3px;padding:8px 10px;margin:4px 0 6px;color:#5d4037;line-height:1.5;">' .
					'<strong>' . esc_html__( 'Preset Query is active.', 'ae-pro' ) . '</strong> ' .
					esc_html__( 'The query settings below are ignored — this widget uses your saved preset instead.', 'ae-pro' ) .
					' <a href="' . esc_url( $list_url ) . '" target="_blank" style="color:#5d4037;font-weight:600;">' .
						esc_html__( 'Manage Presets ↗', 'ae-pro' ) .
					'</a>' .
				'</div>',
				'condition' => [ 'ae_pq_preset_id!' => '' ],
			]
		);
	}

	// -------------------------------------------------------------------------
	// Query injection
	// -------------------------------------------------------------------------

	/**
	 * Replace the widget's query args with the stored preset args when a preset
	 * is selected. The current page number (`paged`) is preserved so Elementor's
	 * own pagination continues to work.
	 *
	 * @param array                    $query_args Current query args built by Elementor.
	 * @param \Elementor\Widget_Base   $widget     The widget instance.
	 * @return array
	 */
	public function apply_preset_query( array $query_args, $widget ): array {
		$settings  = $widget->get_settings_for_display();
		$preset_id = absint( $settings['ae_pq_preset_id'] ?? 0 );

		if ( ! $preset_id ) {
			return $query_args;
		}

		if ( ! Registry::instance()->preset_exists( $preset_id ) ) {
			return $query_args;
		}

		$args = Registry::instance()->get_query_args( $preset_id );

		if ( empty( $args ) ) {
			return $query_args;
		}

		// Strip internal meta keys used only by AE Pro's own query builder.
		unset( $args['_ae_date_mode'] );

		// Resolve the "exclude current post" runtime flag.
		if ( ! empty( $args['_ae_exclude_current'] ) ) {
			unset( $args['_ae_exclude_current'] );
			$current_id = get_the_ID();
			if ( $current_id ) {
				$not_in               = (array) ( $args['post__not_in'] ?? [] );
				$not_in[]             = $current_id;
				$args['post__not_in'] = array_unique( $not_in );
			}
		}

		// WP_Query treats any set `offset` as authoritative — even 0 — and
		// ignores `paged` entirely. Strip a zero offset so pagination works.
		if ( isset( $args['offset'] ) && (int) $args['offset'] === 0 ) {
			unset( $args['offset'] );
		}

		// Preserve Elementor's current page number so its built-in pagination
		// (load more, numbers, etc.) continues to work correctly.
		$args['paged'] = $query_args['paged'] ?? 1;

		// Always show only published posts on the frontend.
		$args['post_status'] = 'publish';

		return $args;
	}
}
