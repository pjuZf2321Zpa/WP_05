<?php
namespace Aepro\Admin\PresetQuery;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Module {

	private static $_instance = null;

	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	private function __construct() {
		// CPT must be registered on every request (front + admin).
		Cpt::instance();

		if ( is_admin() ) {
			Admin_Page::instance();
			Ajax::instance();
		}

		// Widget source injection — fires on both admin (Elementor editor) and frontend.
		add_filter( 'aepro/post-blocks-adv/custom-source-query', [ $this, 'inject_preset_query' ], 10, 2 );

		// Elementor native widget integration — loads after Elementor is ready.
		add_action( 'elementor/init', static function () {
			Elementor\Elementor_Integration::instance();
		} );

		// Bust Used In transient cache whenever any Elementor document is saved,
		// so the list table reflects new preset assignments immediately.
		add_action( 'elementor/document/after_save', [ $this, 'bust_used_in_cache' ], 10, 1 );
	}

	/**
	 * Delete all ae_pq_used_in_* transients when any Elementor document is saved.
	 *
	 * This ensures the "Used In" column on the presets list page always reflects
	 * the current state immediately after a page/template is saved in Elementor.
	 */
	public function bust_used_in_cache() {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$wpdb->query(
			"DELETE FROM {$wpdb->options}
			 WHERE option_name LIKE '_transient_ae_pq_used_in_%'
			    OR option_name LIKE '_transient_timeout_ae_pq_used_in_%'"
		);
	}

	/**
	 * Swap the query args with the stored preset when source === 'ae_preset'.
	 *
	 * @param array $query_args Current args built by QueryMaster::build_query().
	 * @param array $settings   Widget settings array.
	 * @return array
	 */
	public function inject_preset_query( $query_args, $settings ) {
		if ( ( $settings['source'] ?? '' ) !== 'ae_preset' ) {
			return $query_args;
		}

		$preset_id = absint( $settings['ae_preset_query_id'] ?? 0 );

		if ( ! $preset_id || ! Registry::instance()->preset_exists( $preset_id ) ) {
			return [ 'post__in' => [ 0 ], 'post_type' => 'post' ];
		}

		$args = Registry::instance()->get_query_args( $preset_id );

		// Strip internal meta keys.
		unset( $args['_ae_date_mode'] );

		// Resolve runtime flag: exclude the current post.
		if ( ! empty( $args['_ae_exclude_current'] ) ) {
			unset( $args['_ae_exclude_current'] );
			$current_id = get_the_ID();
			if ( $current_id ) {
				$not_in               = (array) ( $args['post__not_in'] ?? [] );
				$not_in[]             = $current_id;
				$args['post__not_in'] = array_unique( $not_in );
			}
		}

		// Resolve the current page number from the request — same logic as
		// QueryMaster::get_current_page_num(), handling both AJAX (page_num POST)
		// and URL-based (?paged=N / ?page=N on the front page) pagination.
		//phpcs:ignore WordPress.Security.NonceVerification.Missing
		if ( isset( $_POST['page_num'] ) ) {
			//phpcs:ignore WordPress.Security.NonceVerification.Missing
			$current_page = absint( $_POST['page_num'] );
		} elseif ( is_front_page() && ! is_home() ) {
			$current_page = (int) get_query_var( 'page' ) ?: 1;
		} else {
			$current_page = (int) get_query_var( 'paged' ) ?: 1;
		}

		if ( $current_page > 1 ) {
			$per_page      = (int) ( $args['posts_per_page'] ?? get_option( 'posts_per_page' ) );
			$static_offset = (int) ( $args['offset'] ?? 0 );

			if ( $static_offset > 0 ) {
				// WP_Query ignores 'paged' when 'offset' is set, so calculate
				// the combined offset manually.
				$args['offset'] = ( $per_page * ( $current_page - 1 ) ) + $static_offset;
				unset( $args['paged'] );
			} else {
				// WP_Query treats any set `offset` as authoritative — even 0 —
				// overriding `paged`. Remove it so pagination works correctly.
				unset( $args['offset'] );
				$args['paged'] = $current_page;
			}
		}

		return $args;
	}
}
