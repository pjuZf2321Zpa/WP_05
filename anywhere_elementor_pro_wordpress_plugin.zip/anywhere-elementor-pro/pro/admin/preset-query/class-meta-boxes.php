<?php
namespace Aepro\Admin\PresetQuery;

use Aepro\Aepro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Meta_Boxes {

	private static $_instance = null;

	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	private function __construct() {
		add_action( 'add_meta_boxes', [ $this, 'register' ] );
		add_action( 'save_post_' . Cpt::POST_TYPE, [ $this, 'save' ], 10, 2 );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_assets' ] );

		// List table columns.
		add_filter( 'manage_' . Cpt::POST_TYPE . '_posts_columns', [ $this, 'set_columns' ] );
		add_action( 'manage_' . Cpt::POST_TYPE . '_posts_custom_column', [ $this, 'render_column' ], 10, 2 );

		// Duplicate row action.
		add_filter( 'post_row_actions', [ $this, 'row_actions' ], 10, 2 );
		add_action( 'admin_post_ae_pq_duplicate', [ $this, 'handle_duplicate' ] );

		// Plugin top bar.
		add_filter( 'aepro/admin/ui/screens', [ $this, 'register_screens' ] );

	}

	// -------------------------------------------------------------------------
	// Meta box registration
	// -------------------------------------------------------------------------

	public function register() {
		remove_meta_box( 'slugdiv',   Cpt::POST_TYPE, 'normal' );
		remove_meta_box( 'authordiv', Cpt::POST_TYPE, 'normal' );

		add_meta_box(
			'ae_pq_query_builder',
			__( 'Query Builder', 'ae-pro' ),
			[ $this, 'render_query_builder' ],
			Cpt::POST_TYPE,
			'normal',
			'high'
		);

		add_meta_box(
			'ae_pq_description_box',
			__( 'Description', 'ae-pro' ),
			[ $this, 'render_description' ],
			Cpt::POST_TYPE,
			'side',
			'default'
		);

		add_meta_box(
			'ae_pq_json_box',
			__( 'JSON', 'ae-pro' ),
			[ $this, 'render_json' ],
			Cpt::POST_TYPE,
			'side',
			'low'
		);
	}

	// -------------------------------------------------------------------------
	// Meta box renderers
	// -------------------------------------------------------------------------

	public function render_query_builder( $post ) {
		wp_nonce_field( 'ae_pq_meta_save', 'ae_pq_meta_nonce' );

		$raw_args = get_post_meta( $post->ID, 'ae_preset_query_args', true );
		$args     = $raw_args ? json_decode( $raw_args, true ) : [];
		if ( ! is_array( $args ) ) {
			$args = [];
		}

		$post_types      = Aepro::$_helper->get_rule_post_types();
		$source          = $args['post_type'] ?? key( $post_types );
		$current_orderby = $args['orderby'] ?? 'date';
		?>
		<div class="ae-pq-edit-form">

			<!-- Source & Post Type -->
			<div class="ae-pq-section-header" data-target="ae-pq-section-source">
				<span class="ae-pq-section-toggle dashicons dashicons-arrow-down-alt2"></span>
				<h3><?php esc_html_e( 'Source & Post Type', 'ae-pro' ); ?></h3>
			</div>
			<div class="ae-pq-section-body" id="ae-pq-section-source">
				<div class="ae-pq-row">
					<div class="ae-pq-field">
						<label for="ae_pq_post_type"><?php esc_html_e( 'Post Type', 'ae-pro' ); ?></label>
						<select id="ae_pq_post_type" name="ae_pq_args[post_type]">
							<?php foreach ( $post_types as $pt_key => $pt_label ) : ?>
								<option value="<?php echo esc_attr( $pt_key ); ?>" <?php selected( $source, $pt_key ); ?>>
									<?php echo esc_html( $pt_label ); ?>
								</option>
							<?php endforeach; ?>
						</select>
					</div>
					<div class="ae-pq-field">
						<label for="ae_pq_post_status"><?php esc_html_e( 'Post Status', 'ae-pro' ); ?></label>
						<select id="ae_pq_post_status" name="ae_pq_args[post_status]">
							<option value="publish" <?php selected( $args['post_status'] ?? 'publish', 'publish' ); ?>><?php esc_html_e( 'Published', 'ae-pro' ); ?></option>
							<option value="draft"   <?php selected( $args['post_status'] ?? '', 'draft' ); ?>><?php esc_html_e( 'Draft', 'ae-pro' ); ?></option>
							<option value="private" <?php selected( $args['post_status'] ?? '', 'private' ); ?>><?php esc_html_e( 'Private', 'ae-pro' ); ?></option>
							<option value="any"     <?php selected( $args['post_status'] ?? '', 'any' ); ?>><?php esc_html_e( 'Any', 'ae-pro' ); ?></option>
						</select>
					</div>
				</div>
			</div>

			<!-- Ordering & Pagination -->
			<div class="ae-pq-section-header" data-target="ae-pq-section-ordering">
				<span class="ae-pq-section-toggle dashicons dashicons-arrow-down-alt2"></span>
				<h3><?php esc_html_e( 'Ordering & Pagination', 'ae-pro' ); ?></h3>
			</div>
			<div class="ae-pq-section-body" id="ae-pq-section-ordering">
				<div class="ae-pq-row">
					<div class="ae-pq-field">
						<label for="ae_pq_orderby"><?php esc_html_e( 'Order By', 'ae-pro' ); ?></label>
						<select id="ae_pq_orderby" name="ae_pq_args[orderby]">
							<?php
							$orderby_options = [
								'date'           => __( 'Date', 'ae-pro' ),
								'title'          => __( 'Title', 'ae-pro' ),
								'modified'       => __( 'Last Modified', 'ae-pro' ),
								'menu_order'     => __( 'Menu Order', 'ae-pro' ),
								'rand'           => __( 'Random', 'ae-pro' ),
								'comment_count'  => __( 'Comment Count', 'ae-pro' ),
								'meta_value'     => __( 'Meta Value (text)', 'ae-pro' ),
								'meta_value_num' => __( 'Meta Value (numeric)', 'ae-pro' ),
							];
							foreach ( $orderby_options as $val => $label ) :
								?>
								<option value="<?php echo esc_attr( $val ); ?>" <?php selected( $current_orderby, $val ); ?>>
									<?php echo esc_html( $label ); ?>
								</option>
							<?php endforeach; ?>
						</select>
					</div>
					<div class="ae-pq-field">
						<label for="ae_pq_order"><?php esc_html_e( 'Direction', 'ae-pro' ); ?></label>
						<select id="ae_pq_order" name="ae_pq_args[order]">
							<option value="DESC" <?php selected( $args['order'] ?? 'DESC', 'DESC' ); ?>><?php esc_html_e( 'DESC (newest first)', 'ae-pro' ); ?></option>
							<option value="ASC"  <?php selected( $args['order'] ?? '', 'ASC' ); ?>><?php esc_html_e( 'ASC (oldest first)', 'ae-pro' ); ?></option>
						</select>
					</div>
					<div class="ae-pq-field ae-pq-field--meta-key js-ae-pq-meta-order" style="<?php echo in_array( $current_orderby, [ 'meta_value', 'meta_value_num' ], true ) ? '' : 'display:none'; ?>">
						<label for="ae_pq_meta_key_order"><?php esc_html_e( 'Meta Key', 'ae-pro' ); ?></label>
						<input type="text" id="ae_pq_meta_key_order" name="ae_pq_args[meta_key]"
							value="<?php echo esc_attr( $args['meta_key'] ?? '' ); ?>"
							placeholder="<?php esc_attr_e( 'e.g. _price', 'ae-pro' ); ?>">
					</div>
				</div>
				<div class="ae-pq-row">
					<div class="ae-pq-field">
						<label for="ae_pq_posts_per_page"><?php esc_html_e( 'Posts Per Page', 'ae-pro' ); ?></label>
						<input type="number" id="ae_pq_posts_per_page" name="ae_pq_args[posts_per_page]"
							value="<?php echo esc_attr( $args['posts_per_page'] ?? 6 ); ?>" min="-1">
						<p class="description"><?php esc_html_e( 'Use -1 to show all.', 'ae-pro' ); ?></p>
					</div>
					<div class="ae-pq-field">
						<label for="ae_pq_offset"><?php esc_html_e( 'Offset', 'ae-pro' ); ?></label>
						<input type="number" id="ae_pq_offset" name="ae_pq_args[offset]"
							value="<?php echo esc_attr( $args['offset'] ?? 0 ); ?>" min="0">
					</div>
				</div>
			</div>

			<!-- Taxonomy Filters -->
			<div class="ae-pq-section-header ae-pq-section-header--collapsed" data-target="ae-pq-section-taxonomy">
				<span class="ae-pq-section-toggle dashicons dashicons-arrow-down-alt2"></span>
				<h3><?php esc_html_e( 'Taxonomy Filters', 'ae-pro' ); ?></h3>
			</div>
			<div class="ae-pq-section-body ae-pq-section-body--collapsed" id="ae-pq-section-taxonomy">
				<div id="ae-pq-tax-relation-wrap" style="display:none;margin-bottom:10px;">
					<label style="font-weight:600;font-size:13px;"><?php esc_html_e( 'Relation', 'ae-pro' ); ?></label>
					<select name="ae_pq_tax_relation" id="ae_pq_tax_relation" style="margin-left:8px;">
						<option value="AND"><?php esc_html_e( 'AND — post must match all filters', 'ae-pro' ); ?></option>
						<option value="OR"><?php esc_html_e( 'OR — post must match any filter', 'ae-pro' ); ?></option>
					</select>
				</div>
				<div id="ae-pq-tax-rows"></div>
				<button type="button" id="ae-pq-add-tax-row" class="button button-secondary" style="margin-top:8px;">
					+ <?php esc_html_e( 'Add Taxonomy Filter', 'ae-pro' ); ?>
				</button>
				<p class="description" style="margin-top:6px;">
					<?php esc_html_e( 'Rows with no terms are ignored on save.', 'ae-pro' ); ?>
				</p>
			</div>

			<!-- Author Filters -->
			<div class="ae-pq-section-header ae-pq-section-header--collapsed" data-target="ae-pq-section-authors">
				<span class="ae-pq-section-toggle dashicons dashicons-arrow-down-alt2"></span>
				<h3><?php esc_html_e( 'Author Filters', 'ae-pro' ); ?></h3>
			</div>
			<div class="ae-pq-section-body ae-pq-section-body--collapsed" id="ae-pq-section-authors">
				<div class="ae-pq-row">
					<div class="ae-pq-field" style="max-width:160px;flex:0 0 160px;">
						<label for="ae_pq_author_operator"><?php esc_html_e( 'Operator', 'ae-pro' ); ?></label>
						<select name="ae_pq_author_operator" id="ae_pq_author_operator">
							<option value="in"><?php esc_html_e( 'Include', 'ae-pro' ); ?></option>
							<option value="not_in"><?php esc_html_e( 'Exclude', 'ae-pro' ); ?></option>
						</select>
					</div>
					<div class="ae-pq-field">
						<label for="ae_pq_author_ids"><?php esc_html_e( 'Authors', 'ae-pro' ); ?></label>
						<select multiple name="ae_pq_author_ids[]" id="ae_pq_author_ids">
							<option disabled><?php esc_html_e( 'Loading…', 'ae-pro' ); ?></option>
						</select>
					</div>
				</div>
			</div>

			<!-- Date Filters -->
			<?php
			$date_query_raw = is_array( $args['date_query'] ?? null ) ? $args['date_query'] : [];
			$date_clause    = [];
			foreach ( $date_query_raw as $item ) {
				if ( is_array( $item ) ) { $date_clause = $item; break; }
			}
			$date_mode      = $args['_ae_date_mode'] ?? ( ! empty( $date_clause ) ? 'static' : '' );
			$date_column    = $date_clause['column'] ?? 'post_date';
			$date_after     = $date_mode !== 'relative' ? ( $date_clause['after'] ?? '' ) : '';
			$date_before    = $date_clause['before'] ?? '';
			$date_relative  = $date_mode === 'relative' ? ( $date_clause['after'] ?? '' ) : '';
			$date_inclusive = isset( $date_clause['inclusive'] ) ? (bool) $date_clause['inclusive'] : true;
			$has_date       = ! empty( $date_clause );
			$relative_opts  = [
				'7 days ago'                     => __( 'Last 7 days', 'ae-pro' ),
				'30 days ago'                    => __( 'Last 30 days', 'ae-pro' ),
				'90 days ago'                    => __( 'Last 90 days', 'ae-pro' ),
				'first day of this month'        => __( 'This month', 'ae-pro' ),
				'first day of last month'        => __( 'Last month', 'ae-pro' ),
				'first day of January this year' => __( 'This year', 'ae-pro' ),
			];
			?>
			<div class="ae-pq-section-header<?php echo $has_date ? '' : ' ae-pq-section-header--collapsed'; ?>" data-target="ae-pq-section-dates">
				<span class="ae-pq-section-toggle dashicons dashicons-arrow-down-alt2"></span>
				<h3><?php esc_html_e( 'Date Filters', 'ae-pro' ); ?></h3>
			</div>
			<div class="ae-pq-section-body<?php echo $has_date ? '' : ' ae-pq-section-body--collapsed'; ?>" id="ae-pq-section-dates">
				<div class="ae-pq-row">
					<div class="ae-pq-field" style="max-width:160px;flex:0 0 160px;">
						<label for="ae_pq_date_mode"><?php esc_html_e( 'Mode', 'ae-pro' ); ?></label>
						<select name="ae_pq_date[mode]" id="ae_pq_date_mode">
							<option value="static"   <?php selected( $date_mode, 'static' ); ?>><?php esc_html_e( 'Static Range', 'ae-pro' ); ?></option>
							<option value="relative" <?php selected( $date_mode, 'relative' ); ?>><?php esc_html_e( 'Relative', 'ae-pro' ); ?></option>
						</select>
					</div>
					<div class="ae-pq-field" style="max-width:220px;flex:0 0 220px;">
						<label for="ae_pq_date_column"><?php esc_html_e( 'Column', 'ae-pro' ); ?></label>
						<select name="ae_pq_date[column]" id="ae_pq_date_column">
							<option value="post_date"         <?php selected( $date_column, 'post_date' ); ?>><?php esc_html_e( 'Post Date', 'ae-pro' ); ?></option>
							<option value="post_modified"     <?php selected( $date_column, 'post_modified' ); ?>><?php esc_html_e( 'Post Modified', 'ae-pro' ); ?></option>
							<option value="post_date_gmt"     <?php selected( $date_column, 'post_date_gmt' ); ?>><?php esc_html_e( 'Post Date (GMT)', 'ae-pro' ); ?></option>
							<option value="post_modified_gmt" <?php selected( $date_column, 'post_modified_gmt' ); ?>><?php esc_html_e( 'Post Modified (GMT)', 'ae-pro' ); ?></option>
						</select>
					</div>
				</div>

				<div id="ae-pq-date-static"<?php echo $date_mode === 'relative' ? ' style="display:none"' : ''; ?>>
					<div class="ae-pq-row">
						<div class="ae-pq-field">
							<label for="ae_pq_date_after"><?php esc_html_e( 'After (from)', 'ae-pro' ); ?></label>
							<input type="date" name="ae_pq_date[after]" id="ae_pq_date_after"
								value="<?php echo esc_attr( $date_after ); ?>">
						</div>
						<div class="ae-pq-field">
							<label for="ae_pq_date_before"><?php esc_html_e( 'Before (to)', 'ae-pro' ); ?></label>
							<input type="date" name="ae_pq_date[before]" id="ae_pq_date_before"
								value="<?php echo esc_attr( $date_before ); ?>">
						</div>
					</div>
				</div>

				<div id="ae-pq-date-relative"<?php echo $date_mode !== 'relative' ? ' style="display:none"' : ''; ?>>
					<div class="ae-pq-row">
						<div class="ae-pq-field">
							<label for="ae_pq_date_relative_val"><?php esc_html_e( 'Period', 'ae-pro' ); ?></label>
							<select name="ae_pq_date[relative]" id="ae_pq_date_relative_val">
								<?php foreach ( $relative_opts as $val => $label ) : ?>
									<option value="<?php echo esc_attr( $val ); ?>" <?php selected( $date_relative, $val ); ?>>
										<?php echo esc_html( $label ); ?>
									</option>
								<?php endforeach; ?>
							</select>
						</div>
					</div>
				</div>

				<div class="ae-pq-row" style="margin-top:4px;">
					<div class="ae-pq-field ae-pq-field--checkbox">
						<label>
							<input type="checkbox" name="ae_pq_date[inclusive]" value="1" <?php checked( $date_inclusive ); ?>>
							<?php esc_html_e( 'Inclusive (include boundary dates)', 'ae-pro' ); ?>
						</label>
					</div>
				</div>
			</div>

			<!-- Meta Query -->
			<?php
			$meta_query_raw   = is_array( $args['meta_query'] ?? null ) ? $args['meta_query'] : [];
			$meta_relation    = 'AND';
			$meta_clauses     = [];
			foreach ( $meta_query_raw as $k => $item ) {
				if ( $k === 'relation' ) {
					$meta_relation = $item;
				} elseif ( is_array( $item ) && isset( $item['key'] ) ) {
					$val = $item['value'] ?? '';
					$meta_clauses[] = [
						'key'     => $item['key'],
						'value'   => is_array( $val ) ? implode( ', ', $val ) : $val,
						'compare' => $item['compare'] ?? '=',
						'type'    => $item['type'] ?? 'CHAR',
					];
				}
			}
			$has_meta = ! empty( $meta_clauses );
			?>
			<div class="ae-pq-section-header<?php echo $has_meta ? '' : ' ae-pq-section-header--collapsed'; ?>" data-target="ae-pq-section-meta">
				<span class="ae-pq-section-toggle dashicons dashicons-arrow-down-alt2"></span>
				<h3><?php esc_html_e( 'Meta Query', 'ae-pro' ); ?></h3>
			</div>
			<div class="ae-pq-section-body<?php echo $has_meta ? '' : ' ae-pq-section-body--collapsed'; ?>" id="ae-pq-section-meta">
				<datalist id="ae-pq-meta-keys"></datalist>
				<div id="ae-pq-meta-relation-wrap" style="display:<?php echo count( $meta_clauses ) > 1 ? 'flex' : 'none'; ?>;margin-bottom:10px;">
					<label style="font-weight:600;font-size:13px;"><?php esc_html_e( 'Relation', 'ae-pro' ); ?></label>
					<select name="ae_pq_meta_relation" id="ae_pq_meta_relation" style="margin-left:8px;">
						<option value="AND" <?php selected( $meta_relation, 'AND' ); ?>><?php esc_html_e( 'AND — post must match all', 'ae-pro' ); ?></option>
						<option value="OR"  <?php selected( $meta_relation, 'OR' ); ?>><?php esc_html_e( 'OR — post must match any', 'ae-pro' ); ?></option>
					</select>
				</div>
				<div id="ae-pq-meta-rows"></div>
				<button type="button" id="ae-pq-add-meta-row" class="button button-secondary" style="margin-top:8px;">
					+ <?php esc_html_e( 'Add Meta Condition', 'ae-pro' ); ?>
				</button>
			</div>

			<!-- Exclusions -->
			<div class="ae-pq-section-header" data-target="ae-pq-section-exclusions">
				<span class="ae-pq-section-toggle dashicons dashicons-arrow-down-alt2"></span>
				<h3><?php esc_html_e( 'Exclusions', 'ae-pro' ); ?></h3>
			</div>
			<div class="ae-pq-section-body" id="ae-pq-section-exclusions">
				<div class="ae-pq-row">
					<div class="ae-pq-field ae-pq-field--checkbox">
						<label>
							<input type="checkbox" name="ae_pq_args[ignore_sticky_posts]" value="1"
								<?php checked( ! empty( $args['ignore_sticky_posts'] ) ); ?>>
							<?php esc_html_e( 'Ignore Sticky Posts', 'ae-pro' ); ?>
						</label>
					</div>
					<div class="ae-pq-field ae-pq-field--checkbox">
						<label>
							<input type="checkbox" name="ae_pq_exclude_current" value="1"
								<?php checked( ! empty( $args['_ae_exclude_current'] ) ); ?>>
							<?php esc_html_e( 'Exclude Current Post (resolved at runtime)', 'ae-pro' ); ?>
						</label>
					</div>
				</div>
				<div class="ae-pq-row">
					<div class="ae-pq-field">
						<label for="ae_pq_post_not_in"><?php esc_html_e( 'Exclude Post IDs', 'ae-pro' ); ?></label>
						<input type="text" id="ae_pq_post_not_in" name="ae_pq_post_not_in"
							value="<?php echo esc_attr( implode( ', ', (array) ( $args['post__not_in'] ?? [] ) ) ); ?>"
							placeholder="<?php esc_attr_e( 'e.g. 12, 45, 78', 'ae-pro' ); ?>">
						<p class="description"><?php esc_html_e( 'Comma-separated post IDs to exclude.', 'ae-pro' ); ?></p>
					</div>
				</div>
			</div>

		</div><!-- /.ae-pq-edit-form -->
		<?php
	}

	public function render_description( $post ) {
		$description = get_post_meta( $post->ID, 'ae_preset_description', true );
		?>
		<input type="text" name="ae_pq_description"
			value="<?php echo esc_attr( $description ); ?>"
			placeholder="<?php esc_attr_e( 'Optional note for your team', 'ae-pro' ); ?>"
			style="width:100%;">
		<?php
	}

	public function render_json( $post ) {
		$raw_args = get_post_meta( $post->ID, 'ae_preset_query_args', true );
		$args     = $raw_args ? json_decode( $raw_args, true ) : [];
		$json_val = ! empty( $args ) ? wp_json_encode( $args, JSON_PRETTY_PRINT ) : '';
		?>
		<p class="description" style="margin-top:0;margin-bottom:8px;">
			<?php esc_html_e( 'Full WP_Query args as JSON. Form fields take priority — use this to add meta_query, tax_query, date_query, or any extra args.', 'ae-pro' ); ?>
		</p>
		<textarea id="ae_pq_advanced_json" name="ae_pq_advanced_json" rows="10"
			class="ae-pq-json-editor large-text code"
			placeholder='{"meta_query":[{"key":"_price","value":"10","compare":">=","type":"NUMERIC"}]}'><?php echo esc_textarea( $json_val ); ?></textarea>
		<p class="description ae-pq-json-error" id="ae-pq-json-error" style="color:red;display:none;margin-top:6px;">
			<?php esc_html_e( 'Invalid JSON — please fix before saving.', 'ae-pro' ); ?>
		</p>
		<?php
	}

	// -------------------------------------------------------------------------
	// Save handler
	// -------------------------------------------------------------------------

	public function save( $post_id, $post ) {
		if ( ! isset( $_POST['ae_pq_meta_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['ae_pq_meta_nonce'] ), 'ae_pq_meta_save' ) ) {
			return;
		}
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		// Build query args from form fields.
		$form_args  = (array) ( $_POST['ae_pq_args'] ?? [] );
		$query_args = $this->sanitize_query_args( $form_args );

		// Exclude post IDs.
		$not_in_raw = sanitize_text_field( wp_unslash( $_POST['ae_pq_post_not_in'] ?? '' ) );
		if ( $not_in_raw ) {
			$not_in = array_filter( array_map( 'absint', explode( ',', $not_in_raw ) ) );
			if ( $not_in ) {
				$query_args['post__not_in'] = array_values( $not_in );
			}
		}

		// Exclude current post flag.
		if ( ! empty( $_POST['ae_pq_exclude_current'] ) ) {
			$query_args['_ae_exclude_current'] = true;
		}

		// Taxonomy filters → tax_query.
		$tax_filters = isset( $_POST['ae_pq_tax_filters'] ) ? (array) $_POST['ae_pq_tax_filters'] : [];
		$tax_query   = [];
		foreach ( $tax_filters as $filter ) {
			$taxonomy = sanitize_key( $filter['taxonomy'] ?? '' );
			$operator = sanitize_text_field( wp_unslash( $filter['operator'] ?? 'IN' ) );
			if ( ! in_array( $operator, [ 'IN', 'NOT IN', 'AND', 'EXISTS', 'NOT EXISTS' ], true ) ) {
				$operator = 'IN';
			}
			$terms = array_values( array_filter( array_map(
				static function ( $t ) { return sanitize_text_field( trim( wp_unslash( $t ) ) ); },
				(array) ( $filter['terms'] ?? [] )
			) ) );
			// EXISTS / NOT EXISTS don't need terms.
			if ( $taxonomy && ( $terms || in_array( $operator, [ 'EXISTS', 'NOT EXISTS' ], true ) ) ) {
				$tax_query[] = [
					'taxonomy' => $taxonomy,
					'field'    => 'slug',
					'terms'    => $terms,
					'operator' => $operator,
				];
			}
		}
		if ( ! empty( $tax_query ) ) {
			if ( count( $tax_query ) > 1 ) {
				$relation = sanitize_text_field( wp_unslash( $_POST['ae_pq_tax_relation'] ?? 'AND' ) );
				if ( ! in_array( $relation, [ 'AND', 'OR' ], true ) ) {
					$relation = 'AND';
				}
				$query_args['tax_query'] = array_merge( [ 'relation' => $relation ], $tax_query );
			} else {
				$query_args['tax_query'] = $tax_query;
			}
		}

		// Author filters.
		$author_ids = array_values( array_filter( array_map( 'absint', (array) ( $_POST['ae_pq_author_ids'] ?? [] ) ) ) );
		if ( ! empty( $author_ids ) ) {
			$author_operator = sanitize_key( $_POST['ae_pq_author_operator'] ?? 'in' );
			if ( $author_operator === 'not_in' ) {
				$query_args['author__not_in'] = $author_ids;
			} else {
				$query_args['author__in'] = $author_ids;
			}
		}

		// Date filters → date_query.
		$date_raw  = (array) ( $_POST['ae_pq_date'] ?? [] );
		$date_mode = sanitize_key( $date_raw['mode'] ?? '' );
		if ( $date_mode ) {
			$column = sanitize_key( $date_raw['column'] ?? 'post_date' );
			if ( ! in_array( $column, [ 'post_date', 'post_modified', 'post_date_gmt', 'post_modified_gmt' ], true ) ) {
				$column = 'post_date';
			}
			$clause = [ 'column' => $column ];

			if ( $date_mode === 'relative' ) {
				$relative = sanitize_text_field( wp_unslash( $date_raw['relative'] ?? '' ) );
				if ( $relative ) {
					$clause['after'] = $relative;
				}
			} else {
				$after  = sanitize_text_field( wp_unslash( $date_raw['after']  ?? '' ) );
				$before = sanitize_text_field( wp_unslash( $date_raw['before'] ?? '' ) );
				if ( $after )  { $clause['after']  = $after; }
				if ( $before ) { $clause['before'] = $before; }
			}

			if ( ! empty( $date_raw['inclusive'] ) ) {
				$clause['inclusive'] = true;
			}

			if ( isset( $clause['after'] ) || isset( $clause['before'] ) ) {
				$query_args['date_query']    = [ $clause ];
				$query_args['_ae_date_mode'] = $date_mode;
			}
		}

		// Meta query.
		$allowed_compare = [ '=', '!=', '>', '>=', '<', '<=', 'LIKE', 'NOT LIKE', 'IN', 'NOT IN', 'BETWEEN', 'NOT BETWEEN', 'EXISTS', 'NOT EXISTS', 'REGEXP', 'NOT REGEXP' ];
		$allowed_type    = [ 'CHAR', 'NUMERIC', 'DECIMAL', 'DATE', 'TIME', 'DATETIME', 'BINARY' ];
		$meta_rows       = isset( $_POST['ae_pq_meta'] ) ? (array) $_POST['ae_pq_meta'] : [];
		$meta_query      = [];
		foreach ( $meta_rows as $row ) {
			$key = sanitize_text_field( wp_unslash( $row['key'] ?? '' ) );
			if ( ! $key ) {
				continue;
			}
			$compare = sanitize_text_field( wp_unslash( $row['compare'] ?? '=' ) );
			if ( ! in_array( $compare, $allowed_compare, true ) ) {
				$compare = '=';
			}
			$type = sanitize_text_field( wp_unslash( $row['type'] ?? 'CHAR' ) );
			if ( ! in_array( $type, $allowed_type, true ) ) {
				$type = 'CHAR';
			}
			$clause = [ 'key' => $key, 'compare' => $compare, 'type' => $type ];
			if ( ! in_array( $compare, [ 'EXISTS', 'NOT EXISTS' ], true ) ) {
				$value_raw = sanitize_text_field( wp_unslash( $row['value'] ?? '' ) );
				if ( in_array( $compare, [ 'IN', 'NOT IN', 'BETWEEN', 'NOT BETWEEN' ], true ) ) {
					$clause['value'] = array_values( array_filter( array_map( 'trim', explode( ',', $value_raw ) ) ) );
				} else {
					$clause['value'] = $value_raw;
				}
			}
			$meta_query[] = $clause;
		}
		if ( ! empty( $meta_query ) ) {
			if ( count( $meta_query ) > 1 ) {
				$meta_rel = sanitize_text_field( wp_unslash( $_POST['ae_pq_meta_relation'] ?? 'AND' ) );
				if ( ! in_array( $meta_rel, [ 'AND', 'OR' ], true ) ) {
					$meta_rel = 'AND';
				}
				$query_args['meta_query'] = array_merge( [ 'relation' => $meta_rel ], $meta_query );
			} else {
				$query_args['meta_query'] = $meta_query;
			}
		}

		// JSON — form fields take priority over matching keys.
		$advanced_json = wp_unslash( $_POST['ae_pq_advanced_json'] ?? '' );
		if ( $advanced_json ) {
			$advanced = json_decode( $advanced_json, true );
			if ( is_array( $advanced ) ) {
				$query_args = array_merge( $advanced, $query_args );
			}
		}

		update_post_meta( $post_id, 'ae_preset_description', sanitize_text_field( wp_unslash( $_POST['ae_pq_description'] ?? '' ) ) );
		update_post_meta( $post_id, 'ae_preset_query_args', wp_json_encode( $query_args ) );
	}

	private function sanitize_query_args( array $raw ) {
		$allowed_scalar = [
			'post_type', 'post_status', 'orderby', 'order',
			'meta_key', 'posts_per_page', 'offset',
		];

		$clean = [];
		foreach ( $allowed_scalar as $key ) {
			if ( isset( $raw[ $key ] ) && $raw[ $key ] !== '' ) {
				$clean[ $key ] = sanitize_text_field( $raw[ $key ] );
			}
		}

		if ( isset( $clean['posts_per_page'] ) ) {
			$clean['posts_per_page'] = (int) $clean['posts_per_page'];
		}
		if ( isset( $clean['offset'] ) ) {
			$clean['offset'] = (int) $clean['offset'];
			// Don't persist offset=0 — WP_Query treats any set `offset` as
			// authoritative (even 0), which silently overrides `paged` and
			// breaks pagination for all pages after the first.
			if ( $clean['offset'] === 0 ) {
				unset( $clean['offset'] );
			}
		}
		if ( ! empty( $raw['ignore_sticky_posts'] ) ) {
			$clean['ignore_sticky_posts'] = true;
		}

		return $clean;
	}

	// -------------------------------------------------------------------------
	// List table
	// -------------------------------------------------------------------------

	public function set_columns( $columns ) {
		$new = [];
		foreach ( $columns as $key => $label ) {
			$new[ $key ] = $label;
			if ( $key === 'title' ) {
				$new['ae_post_type']   = __( 'Post Type', 'ae-pro' );
				$new['ae_status']      = __( 'Status', 'ae-pro' );
				$new['ae_description'] = __( 'Description', 'ae-pro' );
			}
		}
		return $new;
	}

	public function render_column( $column, $post_id ) {
		switch ( $column ) {
			case 'ae_post_type':
				$raw  = get_post_meta( $post_id, 'ae_preset_query_args', true );
				$args = $raw ? json_decode( $raw, true ) : [];
				echo esc_html( $args['post_type'] ?? '—' );
				break;

			case 'ae_status':
				$badge = get_post_status( $post_id ) === 'publish'
					? '<span class="ae-pq-badge ae-pq-badge--active">'   . esc_html__( 'Active', 'ae-pro' )   . '</span>'
					: '<span class="ae-pq-badge ae-pq-badge--inactive">' . esc_html__( 'Inactive', 'ae-pro' ) . '</span>';
				echo $badge; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				break;

			case 'ae_description':
				echo esc_html( get_post_meta( $post_id, 'ae_preset_description', true ) );
				break;
		}
	}

	public function row_actions( $actions, $post ) {
		if ( $post->post_type !== Cpt::POST_TYPE ) {
			return $actions;
		}

		$url = wp_nonce_url(
			add_query_arg(
				[ 'action' => 'ae_pq_duplicate', 'post_id' => $post->ID ],
				admin_url( 'admin-post.php' )
			),
			'ae_pq_duplicate_' . $post->ID
		);

		$actions['ae_pq_duplicate'] = '<a href="' . esc_url( $url ) . '">' . esc_html__( 'Duplicate', 'ae-pro' ) . '</a>';

		return $actions;
	}

	public function handle_duplicate() {
		$post_id = absint( $_GET['post_id'] ?? 0 );
		check_admin_referer( 'ae_pq_duplicate_' . $post_id );

		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_die( esc_html__( 'Insufficient permissions.', 'ae-pro' ) );
		}

		$post = get_post( $post_id );
		if ( ! $post || $post->post_type !== Cpt::POST_TYPE ) {
			wp_safe_redirect( admin_url( 'edit.php?post_type=' . Cpt::POST_TYPE ) );
			exit;
		}

		$new_id = wp_insert_post( [
			'post_type'   => Cpt::POST_TYPE,
			'post_title'  => $post->post_title . ' ' . __( '(Copy)', 'ae-pro' ),
			'post_status' => 'draft',
		] );

		if ( ! is_wp_error( $new_id ) ) {
			foreach ( [ 'ae_preset_description', 'ae_preset_query_args' ] as $key ) {
				update_post_meta( $new_id, $key, get_post_meta( $post_id, $key, true ) );
			}
		}

		wp_safe_redirect( admin_url( 'edit.php?post_type=' . Cpt::POST_TYPE ) );
		exit;
	}

	// -------------------------------------------------------------------------
	// Assets
	// -------------------------------------------------------------------------

	public function enqueue_assets( $hook ) {
		$screen = get_current_screen();
		if ( ! $screen || $screen->post_type !== Cpt::POST_TYPE ) {
			return;
		}

		wp_enqueue_style(
			'ae-pq-select2',
			AE_PRO_URL . 'pro/admin/preset-query/assets/css/select2.min.css',
			[],
			'4.0.13'
		);

		wp_enqueue_style(
			'ae-preset-query-admin',
			AE_PRO_URL . 'pro/admin/preset-query/assets/css/preset-query-admin.css',
			[ 'ae-pq-select2' ],
			AE_PRO_VERSION
		);

		wp_enqueue_script(
			'ae-pq-select2',
			AE_PRO_URL . 'pro/admin/preset-query/assets/js/select2.min.js',
			[ 'jquery' ],
			'4.0.13',
			true
		);

		wp_enqueue_script(
			'ae-preset-query-admin',
			AE_PRO_URL . 'pro/admin/preset-query/assets/js/preset-query-admin.js',
			[ 'jquery', 'ae-pq-select2' ],
			AE_PRO_VERSION,
			true
		);

		// Build taxonomy map: post_type => [ {slug, label} ].
		$post_types = Aepro::$_helper->get_rule_post_types();
		$tax_map    = [];
		foreach ( array_keys( $post_types ) as $pt ) {
			$taxes          = get_object_taxonomies( $pt, 'objects' );
			$tax_map[ $pt ] = [];
			foreach ( $taxes as $tax ) {
				if ( $tax->show_ui ) {
					$tax_map[ $pt ][] = [ 'slug' => $tax->name, 'label' => $tax->label ];
				}
			}
		}

		// Stored tax + author filters for current post (edit screen only).
		$stored_tax_filters     = [];
		$stored_tax_relation    = 'AND';
		$stored_author_ids      = [];
		$stored_author_operator = 'in';
		$stored_meta_clauses    = [];
		$stored_meta_relation   = 'AND';
		if ( $screen->base === 'post' ) {
			global $post;
			if ( $post && $post->post_type === Cpt::POST_TYPE ) {
				$raw  = get_post_meta( $post->ID, 'ae_preset_query_args', true );
				$args = $raw ? json_decode( $raw, true ) : [];
				if ( ! empty( $args['tax_query'] ) && is_array( $args['tax_query'] ) ) {
					$stored_tax_relation = $args['tax_query']['relation'] ?? 'AND';
					foreach ( $args['tax_query'] as $clause ) {
						if ( is_array( $clause ) && isset( $clause['taxonomy'] ) ) {
							$stored_tax_filters[] = [
								'taxonomy' => $clause['taxonomy'],
								'operator' => $clause['operator'] ?? 'IN',
								'terms'    => array_values( (array) ( $clause['terms'] ?? [] ) ),
							];
						}
					}
				}
				if ( ! empty( $args['author__in'] ) ) {
					$stored_author_ids      = array_map( 'intval', (array) $args['author__in'] );
					$stored_author_operator = 'in';
				} elseif ( ! empty( $args['author__not_in'] ) ) {
					$stored_author_ids      = array_map( 'intval', (array) $args['author__not_in'] );
					$stored_author_operator = 'not_in';
				}

				// Stored meta query.
				if ( ! empty( $args['meta_query'] ) && is_array( $args['meta_query'] ) ) {
					$stored_meta_relation = $args['meta_query']['relation'] ?? 'AND';
					foreach ( $args['meta_query'] as $k => $clause ) {
						if ( is_array( $clause ) && isset( $clause['key'] ) ) {
							$val = $clause['value'] ?? '';
							$stored_meta_clauses[] = [
								'key'     => $clause['key'],
								'value'   => is_array( $val ) ? implode( ', ', $val ) : (string) $val,
								'compare' => $clause['compare'] ?? '=',
								'type'    => $clause['type'] ?? 'CHAR',
							];
						}
					}
				}
			}
		}

		wp_localize_script( 'ae-preset-query-admin', 'aePQ', [
			'ajax_url'           => admin_url( 'admin-ajax.php' ),
			'nonce'              => wp_create_nonce( 'ae_pq_nonce' ),
			'tax_map'            => $tax_map,
			'stored_tax_filters'     => $stored_tax_filters,
			'stored_tax_relation'    => $stored_tax_relation,
			'stored_author_ids'      => $stored_author_ids,
			'stored_author_operator' => $stored_author_operator,
			'stored_meta_clauses'    => $stored_meta_clauses,
			'stored_meta_relation'   => $stored_meta_relation,
			'i18n'               => [
				'saving'      => __( 'Saving…', 'ae-pro' ),
				'saved'       => __( 'Saved!', 'ae-pro' ),
				'error'       => __( 'Something went wrong. Please try again.', 'ae-pro' ),
				'no_taxonomy' => __( 'No taxonomies for this post type', 'ae-pro' ),
			],
		] );
	}

	// -------------------------------------------------------------------------
	// Plugin top bar
	// -------------------------------------------------------------------------

	public function register_screens( $screens ) {
		$screens[] = 'ae_preset_query';       // edit screen
		$screens[] = 'edit-ae_preset_query';  // list screen
		return $screens;
	}

}
