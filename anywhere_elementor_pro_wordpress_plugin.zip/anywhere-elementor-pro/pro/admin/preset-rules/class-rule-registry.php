<?php
namespace Aepro\Admin\PresetRules;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Aepro\Admin\PresetRules\Rules\Rule_Base;

/**
 * Holds registered rule-type classes.
 * Third-party code can call Rule_Registry::instance()->register( $rule_obj )
 * on or after the `aepro/preset-rules/registry/init` action.
 */
class Rule_Registry {

	private static ?self $_instance = null;

	/** @var Rule_Base[] Keyed by rule ID. */
	private array $rules = [];

	public static function instance(): self {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	private function __construct() {}

	public function register( Rule_Base $rule ): void {
		$this->rules[ $rule->get_id() ] = $rule;
	}

	/** @return Rule_Base[] */
	public function get_all(): array {
		return $this->rules;
	}

	public function get( string $id ): ?Rule_Base {
		return $this->rules[ $id ] ?? null;
	}

	/**
	 * Rules grouped by category for the admin dropdown.
	 *
	 * @return array<string, array<string, string>>  [ 'Category' => [ 'id' => 'Label' ] ]
	 */
	public function get_grouped_options(): array {
		$grouped = [];
		foreach ( $this->rules as $rule ) {
			$grouped[ $rule->get_category() ][ $rule->get_id() ] = $rule->get_label();
		}
		return $grouped;
	}

	/** @return array<string, string> [ 'id' => 'Label' ] */
	public function get_flat_options(): array {
		$options = [];
		foreach ( $this->rules as $id => $rule ) {
			$options[ $id ] = $rule->get_label();
		}
		return $options;
	}
}
