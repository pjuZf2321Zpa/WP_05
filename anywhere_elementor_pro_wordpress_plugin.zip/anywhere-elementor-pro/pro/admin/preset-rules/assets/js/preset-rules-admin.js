/* global aePR, jQuery */
( function ( $ ) {
	'use strict';

	// -------------------------------------------------------------------------
	// List page — shared with edit page
	// -------------------------------------------------------------------------

	// Import form toggle.
	$( '#ae-pr-import-trigger' ).on( 'click', function () {
		$( '#ae-pr-import-wrap' ).slideDown( 120 );
	} );
	$( '#ae-pr-import-cancel' ).on( 'click', function () {
		$( '#ae-pr-import-wrap' ).slideUp( 120 );
	} );

	// Show filename when file chosen.
	$( document ).on( 'change', 'input[name="ae_pr_import_file"]', function () {
		var name = this.files && this.files[0] ? this.files[0].name : ( aePR.i18n.no_file || '' );
		$( '#ae-pr-import-filename' ).text( name );
	} );

	// -------------------------------------------------------------------------
	// Status toggle — list table + edit page header
	// -------------------------------------------------------------------------

	$( document ).on( 'click', '.ae-pr-status-toggle', function () {
		var $btn     = $( this );
		var presetId = $btn.data( 'preset-id' );
		if ( ! presetId || $btn.hasClass( 'ae-pr-status-toggle--loading' ) ) { return; }

		$btn.addClass( 'ae-pr-status-toggle--loading' );

		$.post( aePR.ajax_url, {
			action:    'ae_pr_toggle_status',
			nonce:     aePR.nonce,
			preset_id: presetId,
		} ).done( function ( res ) {
			if ( ! res.success ) { return; }
			var active = res.data.active;
			$btn
				.toggleClass( 'ae-pr-status-toggle--active', active )
				.attr( 'data-active', active ? '1' : '0' )
				.attr( 'title', active ? 'Click to deactivate' : 'Click to activate' );
			$btn.find( '.ae-pr-status-toggle__label' ).text( active ? 'Active' : 'Inactive' );
		} ).fail( function ( xhr ) {
			var msg = xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message
				? xhr.responseJSON.data.message
				: 'Something went wrong.';
			alert( msg );
		} ).always( function () {
			$btn.removeClass( 'ae-pr-status-toggle--loading' );
		} );
	} );

	// -------------------------------------------------------------------------
	// Sidebar code panel — tab switching
	// -------------------------------------------------------------------------

	$( document ).on( 'click', '.ae-pr-code-tab', function () {
		var $tab    = $( this );
		var tabId   = $tab.data( 'tab' );
		var $panel  = $tab.closest( '.ae-pr-code-panel' );

		$panel.find( '.ae-pr-code-tab' ).removeClass( 'ae-pr-code-tab--active' );
		$tab.addClass( 'ae-pr-code-tab--active' );

		$panel.find( '.ae-pr-code-pane' ).removeClass( 'ae-pr-code-pane--active' );
		$panel.find( '#ae-pr-pane-' + tabId ).addClass( 'ae-pr-code-pane--active' );

		$panel.find( '.ae-pr-code-footer' ).hide();
		if ( tabId === 'usage' ) {
			$panel.find( '#ae-pr-code-footer-usage' ).show();
		}
	} );

	// -------------------------------------------------------------------------
	// Sidebar code panel — copy button
	// -------------------------------------------------------------------------

	$( document ).on( 'click', '.ae-pr-copy-btn', function () {
		var $btn    = $( this );
		var target  = $btn.data( 'target' );
		var text    = $( '#' + target ).text();
		if ( ! navigator.clipboard ) { return; }
		navigator.clipboard.writeText( text ).then( function () {
			var $label = $btn.find( '.dashicons' );
			$label.removeClass( 'dashicons-clipboard' ).addClass( 'dashicons-yes' );
			setTimeout( function () {
				$label.removeClass( 'dashicons-yes' ).addClass( 'dashicons-clipboard' );
			}, 1500 );
		} );
	} );

	// Match bar (AND / OR) toggle.
	$( document ).on( 'change', '.ae-pr-match-toggle input[type="radio"]', function () {
		$( this ).closest( '.ae-pr-match-toggle' ).find( '.ae-pr-match-option' ).removeClass( 'ae-pr-match-option--active' );
		$( this ).closest( '.ae-pr-match-option' ).addClass( 'ae-pr-match-option--active' );
	} );

	// -------------------------------------------------------------------------
	// Bulk actions — list page only
	// -------------------------------------------------------------------------

	var $selectAll = $( '#ae-pr-select-all' );
	var $bulkApply = $( '#ae-pr-bulk-apply' );
	var $bulkCount = $( '#ae-pr-bulk-count' );

	function getCheckedIds() {
		return $( '.ae-pr-row-cb:checked' ).map( function () { return $( this ).val(); } ).get();
	}

	function syncBulkBar() {
		var ids   = getCheckedIds();
		var total = $( '.ae-pr-row-cb' ).length;
		$bulkApply.prop( 'disabled', ids.length === 0 );
		$bulkCount.text( ids.length ? ids.length + ' ' + ( ids.length === 1 ? 'item' : 'items' ) + ' selected' : '' );
		$selectAll
			.prop( 'checked', ids.length > 0 && ids.length === total )
			.prop( 'indeterminate', ids.length > 0 && ids.length < total );
	}

	$selectAll.on( 'change', function () {
		var checked = $( this ).is( ':checked' );
		$( '.ae-pr-row-cb' ).prop( 'checked', checked ).each( function () {
			$( this ).closest( 'tr' ).toggleClass( 'ae-pr-row--selected', checked );
		} );
		syncBulkBar();
	} );

	$( document ).on( 'change', '.ae-pr-row-cb', function () {
		$( this ).closest( 'tr' ).toggleClass( 'ae-pr-row--selected', $( this ).is( ':checked' ) );
		syncBulkBar();
	} );

	$bulkApply.on( 'click', function () {
		var action = $( '#ae-pr-bulk-action' ).val();
		var ids    = getCheckedIds();

		if ( ! action ) {
			alert( aePR.i18n.bulk_select_action );
			return;
		}
		if ( ! ids.length ) {
			alert( aePR.i18n.bulk_select_items );
			return;
		}

		if ( action === 'export' ) {
			var $wrap = $( '#ae-pr-bulk-export-ids' ).empty();
			$.each( ids, function ( i, id ) {
				$wrap.append( $( '<input>' ).attr( { type: 'hidden', name: 'preset_ids[]', value: parseInt( id, 10 ) } ) );
			} );
			$( '#ae-pr-bulk-export-form' )[0].submit();
			return;
		}

		if ( action === 'delete' && ! confirm( aePR.i18n.bulk_delete_confirm ) ) {
			return;
		}

		$bulkApply.prop( 'disabled', true );

		$.post( aePR.ajax_url, {
			action:      'ae_pr_bulk_action',
			nonce:       aePR.nonce,
			bulk_action: action,
			preset_ids:  ids,
		} ).done( function ( res ) {
			if ( ! res.success ) {
				alert( res.data && res.data.message ? res.data.message : ( aePR.i18n.error || 'Something went wrong.' ) );
				return;
			}
			var processed = res.data.processed;
			if ( action === 'delete' ) {
				$.each( processed, function ( i, id ) {
					$( '.ae-pr-row-cb[value="' + id + '"]' ).closest( 'tr' ).fadeOut( 200, function () { $( this ).remove(); syncBulkBar(); } );
				} );
			} else {
				var isActive = ( action === 'activate' );
				$.each( processed, function ( i, id ) {
					var $toggle = $( '.ae-pr-status-toggle[data-preset-id="' + id + '"]' );
					$toggle
						.toggleClass( 'ae-pr-status-toggle--active', isActive )
						.attr( 'data-active', isActive ? '1' : '0' )
						.attr( 'title', isActive ? 'Click to deactivate' : 'Click to activate' );
					$toggle.find( '.ae-pr-status-toggle__label' ).text( isActive ? 'Active' : 'Inactive' );
				} );
			}
			$( '.ae-pr-row-cb, #ae-pr-select-all' ).prop( 'checked', false ).prop( 'indeterminate', false );
			$( '#ae-pr-bulk-action' ).val( '' );
			syncBulkBar();
		} ).always( function () {
			$bulkApply.prop( 'disabled', false );
		} );
	} );

	// -------------------------------------------------------------------------
	// Edit page — only runs when is_edit
	// -------------------------------------------------------------------------

	if ( ! aePR.is_edit ) { return; }

	// -------------------------------------------------------------------------
	// Save button — disabled until a title is entered
	// -------------------------------------------------------------------------

	var $titleInput = $( '#ae-pr-title-input' );
	var $saveBtn    = $( '.ae-pr-save-btn' );

	function syncSaveBtn() {
		$saveBtn.prop( 'disabled', $titleInput.val().trim() === '' );
	}

	syncSaveBtn();
	$titleInput.on( 'input', syncSaveBtn );

	// -------------------------------------------------------------------------
	// Rules builder
	// -------------------------------------------------------------------------

	var rules      = [];     // In-memory array of rule objects.
	var rowCounter = 0;      // Ensures unique row IDs during the session.

	/** Initialise Select2 on every .ae-pr-multiselect inside $ctx. */
	function initMultiselects( $ctx ) {
		$ctx.find( '.ae-pr-multiselect' ).each( function () {
			var $sel = $( this );
			if ( $sel.data( 'select2' ) ) { $sel.select2( 'destroy' ); }
			$sel.select2( {
				placeholder:       'Select…',
				allowClear:        false,
				dropdownAutoWidth: true,
				width:             '100%',
			} );
		} );
	}

	/** Build a lookup: rule_id → { operators, fields } */
	var ruleTypesMap = {};
	( aePR.rule_types || [] ).forEach( function ( rt ) {
		ruleTypesMap[ rt.id ] = rt;
	} );

	/** Clone the type-select template and return a fresh <select>. */
	function buildTypeSelect( selectedId ) {
		var $tmpl   = $( '#ae-pr-type-template' );
		var $select = $tmpl.clone().removeAttr( 'id' ).css( 'display', '' )
			.addClass( 'ae-pr-rule-type' ).attr( 'data-role', 'type' );
		if ( selectedId ) {
			$select.val( selectedId );
		}
		return $select;
	}

	/** Build an operator <select> for the given rule type config. */
	function buildOperatorSelect( rt, selectedOp ) {
		var $select = $( '<select class="ae-pr-rule-operator"></select>' );
		var ops     = rt ? rt.operators : {};

		if ( ! rt || ! Object.keys( ops ).length ) {
			$select.append( $( '<option></option>' ).val( '' ).text( '—' ) )
				.prop( 'disabled', true )
				.addClass( 'ae-pr-rule-operator--placeholder' );
			return $select;
		}

		$.each( ops, function ( key, label ) {
			var $opt = $( '<option></option>' ).val( key ).text( label );
			if ( key === selectedOp ) { $opt.prop( 'selected', true ); }
			$select.append( $opt );
		} );
		return $select;
	}

	/** Build value field(s) HTML from field definitions. */
	function buildFieldsWrap( rt, storedValue ) {
		var $wrap = $( '<div class="ae-pr-rule-fields-wrap"></div>' );
		if ( ! rt || ! rt.fields || ! rt.fields.length ) {
			$wrap.addClass( 'ae-pr-rule-fields-wrap--no-fields' );
			return $wrap;
		}

		rt.fields.forEach( function ( field ) {
			var fieldName = field.name || 'value';
			var fieldVal  = '';

			// Resolve value from storedValue (may be string or object).
			if ( typeof storedValue === 'object' && storedValue !== null ) {
				fieldVal = storedValue[ fieldName ] || '';
			} else if ( fieldName === 'value' ) {
				fieldVal = storedValue || '';
			}

			var $fieldWrap = $( '<div class="ae-pr-field-wrap"></div>' );
			if ( field.show_for_operators ) {
				$fieldWrap.attr( 'data-show-for', field.show_for_operators.join( ',' ) );
			}
			if ( field.label ) {
				$fieldWrap.append( $( '<span class="ae-pr-field-label"></span>' ).text( field.label ) );
			}

			if ( field.type === 'multiselect' ) {
				var selectedVals = Array.isArray( fieldVal )
					? fieldVal.map( String )
					: ( fieldVal !== '' ? [ String( fieldVal ) ] : [] );
				var $msel = $( '<select multiple></select>' )
					.attr( 'data-field', fieldName )
					.addClass( 'ae-pr-multiselect' );
				$.each( field.options || {}, function ( optVal, optLabel ) {
					var $opt = $( '<option></option>' ).val( optVal ).text( optLabel );
					if ( selectedVals.indexOf( String( optVal ) ) !== -1 ) { $opt.prop( 'selected', true ); }
					$msel.append( $opt );
				} );
				$fieldWrap.append( $msel );
			} else if ( field.type === 'select' ) {
				var $sel = $( '<select></select>' ).attr( 'data-field', fieldName );
				$.each( field.options || {}, function ( optVal, optLabel ) {
					var $opt = $( '<option></option>' ).val( optVal ).text( optLabel );
					if ( String( optVal ) === String( fieldVal ) ) { $opt.prop( 'selected', true ); }
					$sel.append( $opt );
				} );
				$fieldWrap.append( $sel );
			} else {
				var $input = $( '<input type="text" />' )
					.attr( 'data-field', fieldName )
					.attr( 'placeholder', field.placeholder || '' )
					.val( fieldVal );
				$fieldWrap.append( $input );
			}

			$wrap.append( $fieldWrap );
		} );

		return $wrap;
	}

	/** Show/hide fields that have show_for_operators based on the current operator. */
	function syncFieldVisibility( $fieldsWrap, operator ) {
		$fieldsWrap.find( '.ae-pr-field-wrap[data-show-for]' ).each( function () {
			var ops = String( $( this ).attr( 'data-show-for' ) ).split( ',' );
			$( this ).toggle( ops.indexOf( operator ) !== -1 );
		} );
		var visibleCount = $fieldsWrap.find( '.ae-pr-field-wrap:visible' ).length;
		$fieldsWrap.toggleClass( 'ae-pr-rule-fields-wrap--full-row', visibleCount >= 3 );
	}

	/**
	 * Extract current value from the fields wrap.
	 * Returns a string for single-field rules, an object for multi-field rules.
	 */
	function extractValue( $fieldsWrap, rt ) {
		if ( ! rt || ! rt.fields || rt.fields.length === 0 ) {
			return '';
		}

		if ( rt.fields.length === 1 ) {
			var $first = $fieldsWrap.find( '[data-field]' ).first();
			if ( $first.is( 'select[multiple]' ) ) {
				return $first.val() || [];
			}
			return $first.val() || '';
		}

		var obj = {};
		$fieldsWrap.find( '[data-field]' ).each( function () {
			var $el = $( this );
			obj[ $el.data( 'field' ) ] = $el.is( 'select[multiple]' ) ? ( $el.val() || [] ) : ( $el.val() || '' );
		} );
		return obj;
	}

	/** Render a single rule row into #ae-pr-rules-list. */
	function renderRow( rule ) {
		var _id      = rule._id    || ( 'row_' + ( ++rowCounter ) );
		var type     = rule.type   || '';
		var operator = rule.operator || '';
		var value    = rule.value  !== undefined ? rule.value : '';
		var rt       = ruleTypesMap[ type ] || null;

		var $row = $( '<div class="ae-pr-rule-row"></div>' ).attr( 'data-row-id', _id );

		// Type dropdown.
		var $typeWrap = $( '<div class="ae-pr-rule-type-wrap"></div>' );
		$typeWrap.append( $( '<span class="ae-pr-field-label"></span>' ).text( aePR.i18n.label_type || 'Type' ) );
		var $typeSelect = buildTypeSelect( type );
		$typeWrap.append( $typeSelect );
		$row.append( $typeWrap );

		// Operator dropdown.
		var $opWrap = $( '<div class="ae-pr-rule-operator-wrap"></div>' );
		$opWrap.append( $( '<span class="ae-pr-field-label"></span>' ).text( aePR.i18n.label_operator || 'Operator' ) );
		var $opSelect = buildOperatorSelect( rt, operator );
		$opWrap.append( $opSelect );
		$row.append( $opWrap );

		// Value fields.
		var $fieldsWrap = buildFieldsWrap( rt, value );
		syncFieldVisibility( $fieldsWrap, operator );
		$row.append( $fieldsWrap );
		if ( $fieldsWrap.hasClass( 'ae-pr-rule-fields-wrap--no-fields' ) ) {
			$row.addClass( 'ae-pr-rule-row--no-fields' );
		}

		// Hide operator + fields until a type is chosen.
		if ( ! type ) {
			$row.addClass( 'ae-pr-rule-row--empty' );
		}

		// Remove button.
		var $remove = $( '<button type="button" class="ae-pr-rule-remove" title="Remove">×</button>' );
		$row.append( $remove );

		$( '#ae-pr-rules-list' ).append( $row );
		initMultiselects( $row );
		syncNoRules();
	}

	/** Show/hide the "no rules" empty notice. */
	function syncNoRules() {
		var $list = $( '#ae-pr-rules-list' );
		if ( $list.find( '.ae-pr-rule-row' ).length === 0 ) {
			if ( ! $list.find( '.ae-pr-no-rules' ).length ) {
				$list.append(
					$( '<div class="ae-pr-no-rules"></div>' )
						.text( 'No rules yet. Click "+ Add Rule" to begin.' )
				);
			}
		} else {
			$list.find( '.ae-pr-no-rules' ).remove();
		}
	}

	/** Collect all rows into the rules array and write to the hidden input. */
	function serializeRules() {
		var result = [];
		$( '#ae-pr-rules-list .ae-pr-rule-row' ).each( function () {
			var $row    = $( this );
			var _id     = $row.data( 'row-id' ) || '';
			var type    = $row.find( '.ae-pr-rule-type' ).val() || '';
			var operator= $row.find( '.ae-pr-rule-operator' ).val() || '';
			var rt      = ruleTypesMap[ type ] || null;
			var value   = extractValue( $row.find( '.ae-pr-rule-fields-wrap' ), rt );
			if ( type ) {
				result.push( { _id: _id, type: type, operator: operator, value: value } );
			}
		} );
		return result;
	}

	// -------------------------------------------------------------------------
	// Event: Add rule
	// -------------------------------------------------------------------------

	$( '#ae-pr-add-rule' ).on( 'click', function () {
		renderRow( {} );
	} );

	// -------------------------------------------------------------------------
	// Event: Remove rule
	// -------------------------------------------------------------------------

	$( document ).on( 'click', '.ae-pr-rule-remove', function () {
		$( this ).closest( '.ae-pr-rule-row' ).remove();
		syncNoRules();
	} );

	// -------------------------------------------------------------------------
	// Event: Rule type change — reload operator + fields via AJAX
	// -------------------------------------------------------------------------

	$( document ).on( 'change', '.ae-pr-rule-type', function () {
		var $select  = $( this );
		var $row     = $select.closest( '.ae-pr-rule-row' );
		var ruleType = $select.val();
		var rt       = ruleTypesMap[ ruleType ] || null;

		// Show/hide operator + fields based on whether a type is selected.
		$row.toggleClass( 'ae-pr-rule-row--empty', ! ruleType );

		// Rebuild operator dropdown — replace only the select to keep the label.
		var $opWrap = $row.find( '.ae-pr-rule-operator-wrap' );
		$opWrap.find( 'select' ).replaceWith( buildOperatorSelect( rt, '' ) );

		// Rebuild value fields.
		var $newFieldsWrap = buildFieldsWrap( rt, '' );
		syncFieldVisibility( $newFieldsWrap, '' );
		$row.find( '.ae-pr-rule-fields-wrap' ).replaceWith( $newFieldsWrap );
		$row.toggleClass( 'ae-pr-rule-row--no-fields', $newFieldsWrap.hasClass( 'ae-pr-rule-fields-wrap--no-fields' ) );
		initMultiselects( $newFieldsWrap );
	} );

	// -------------------------------------------------------------------------
	// Event: Operator change — update conditional field visibility
	// -------------------------------------------------------------------------

	$( document ).on( 'change', '.ae-pr-rule-operator', function () {
		var $row     = $( this ).closest( '.ae-pr-rule-row' );
		var operator = $( this ).val();
		syncFieldVisibility( $row.find( '.ae-pr-rule-fields-wrap' ), operator );
	} );

	// -------------------------------------------------------------------------
	// Form submit — serialize rules into hidden input before POST
	// -------------------------------------------------------------------------

	$( '#ae-pr-edit-form' ).on( 'submit', function () {
		var relation = $( 'input[name="ae_pr_relation"]:checked' ).val() || 'AND';
		var rules    = serializeRules();

		var config = {
			relation: relation,
			rules:    rules,
		};

		$( '#ae-pr-config-json' ).val( JSON.stringify( config ) );
	} );

	// -------------------------------------------------------------------------
	// Init — render saved rules on page load
	// -------------------------------------------------------------------------

	( aePR.saved_rules || [] ).forEach( function ( rule ) {
		renderRow( rule );
	} );

	syncNoRules();

} )( jQuery );
