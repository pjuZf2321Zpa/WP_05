<?php
namespace Aepro\Admin\PresetRules\Rules;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Search_Rule extends Rule_Base {

	public function get_id(): string {
		return 'search';
	}

	public function get_label(): string {
		return __( 'Search Results', 'ae-pro' );
	}

	public function get_category(): string {
		return __( 'Query Context', 'ae-pro' );
	}

	public function get_operators(): array {
		return [
			'is'     => __( 'Is a Search Page', 'ae-pro' ),
			'is_not' => __( 'Is Not a Search Page', 'ae-pro' ),
		];
	}

	public function get_fields(): array {
		return [];
	}

	public function evaluate( string $operator, $value ): bool {
		$matches = is_search();
		return 'is_not' === $operator ? ! $matches : $matches;
	}
}
