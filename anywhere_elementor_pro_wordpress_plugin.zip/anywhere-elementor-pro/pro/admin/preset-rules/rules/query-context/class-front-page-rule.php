<?php
namespace Aepro\Admin\PresetRules\Rules;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Front_Page_Rule extends Rule_Base {

	public function get_id(): string {
		return 'front_page';
	}

	public function get_label(): string {
		return __( 'Front Page', 'ae-pro' );
	}

	public function get_category(): string {
		return __( 'Query Context', 'ae-pro' );
	}

	public function get_operators(): array {
		return [
			'is'     => __( 'Is the Front Page', 'ae-pro' ),
			'is_not' => __( 'Is Not the Front Page', 'ae-pro' ),
		];
	}

	public function get_fields(): array {
		return [];
	}

	public function evaluate( string $operator, $value ): bool {
		$matches = is_front_page();
		return 'is_not' === $operator ? ! $matches : $matches;
	}
}
