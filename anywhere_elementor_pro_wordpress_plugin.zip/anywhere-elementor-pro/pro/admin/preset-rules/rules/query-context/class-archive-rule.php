<?php
namespace Aepro\Admin\PresetRules\Rules;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Archive_Rule extends Rule_Base {

	public function get_id(): string {
		return 'archive';
	}

	public function get_label(): string {
		return __( 'Archive', 'ae-pro' );
	}

	public function get_category(): string {
		return __( 'Query Context', 'ae-pro' );
	}

	public function get_operators(): array {
		return [
			'is'     => __( 'Is an Archive', 'ae-pro' ),
			'is_not' => __( 'Is Not an Archive', 'ae-pro' ),
		];
	}

	public function get_fields(): array {
		return [];
	}

	public function evaluate( string $operator, $value ): bool {
		$matches = is_archive();
		return 'is_not' === $operator ? ! $matches : $matches;
	}
}
