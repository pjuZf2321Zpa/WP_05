<?php
namespace Aepro\Admin\PresetRules\Rules;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Rule_404 extends Rule_Base {

	public function get_id(): string {
		return '404';
	}

	public function get_label(): string {
		return __( '404 Page', 'ae-pro' );
	}

	public function get_category(): string {
		return __( 'Query Context', 'ae-pro' );
	}

	public function get_operators(): array {
		return [
			'is'     => __( 'Is a 404 Page', 'ae-pro' ),
			'is_not' => __( 'Is Not a 404 Page', 'ae-pro' ),
		];
	}

	public function get_fields(): array {
		return [];
	}

	public function evaluate( string $operator, $value ): bool {
		$matches = is_404();
		return 'is_not' === $operator ? ! $matches : $matches;
	}
}
