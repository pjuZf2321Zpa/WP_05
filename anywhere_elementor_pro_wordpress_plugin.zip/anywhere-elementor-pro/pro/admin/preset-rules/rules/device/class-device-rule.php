<?php
namespace Aepro\Admin\PresetRules\Rules;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Device Type rule — server-side user-agent detection.
 *
 * Limitation: UA detection is inherently imprecise. Tablets commonly
 * include "mobile" in their UA string, so this class checks for tablet
 * patterns first. For pixel-accurate device detection, pair this with
 * client-side breakpoint logic instead.
 */
class Device_Rule extends Rule_Base {

	public function get_id(): string {
		return 'device';
	}

	public function get_label(): string {
		return __( 'Device Type', 'ae-pro' );
	}

	public function get_category(): string {
		return __( 'Device', 'ae-pro' );
	}

	public function get_operators(): array {
		return [
			'is'     => __( 'Is', 'ae-pro' ),
			'is_not' => __( 'Is Not', 'ae-pro' ),
		];
	}

	public function get_fields(): array {
		return [
			[
				'type'    => 'select',
				'name'    => 'value',
				'label'   => __( 'Device', 'ae-pro' ),
				'options' => [
					'desktop' => __( 'Desktop', 'ae-pro' ),
					'tablet'  => __( 'Tablet', 'ae-pro' ),
					'mobile'  => __( 'Mobile', 'ae-pro' ),
				],
			],
		];
	}

	public function evaluate( string $operator, $value ): bool {
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$ua      = isset( $_SERVER['HTTP_USER_AGENT'] ) ? (string) $_SERVER['HTTP_USER_AGENT'] : '';
		$device  = $this->detect( $ua );
		$matches = $device === (string) $value;
		return 'is_not' === $operator ? ! $matches : $matches;
	}

	private function detect( string $ua ): string {
		// Tablet check before mobile — many tablet UAs include the word "mobile".
		if ( preg_match( '/ipad|tablet|kindle|playbook|silk|android(?!.*mobile)/i', $ua ) ) {
			return 'tablet';
		}
		if ( preg_match( '/android|iphone|ipod|windows phone|blackberry|mobile|opera mini|opera mobi/i', $ua ) ) {
			return 'mobile';
		}
		return 'desktop';
	}
}
