<?php
namespace Aepro\Admin\PresetRules\Rules;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * ACF Text-based fields: Text, Textarea, Number, Range, Email, URL,
 * Password, WYSIWYG, oEmbed, Color Picker.
 */
class Acf_Text_Rule extends Rule_Base {

	public static function is_available(): bool {
		return function_exists( 'get_field' );
	}

	public function get_id(): string { return 'acf_text'; }
	public function get_label(): string { return __( 'ACF Text', 'ae-pro' ); }
	public function get_category(): string { return __( 'Advanced Custom Fields', 'ae-pro' ); }

	public function get_operators(): array {
		return [
			'exists'     => __( 'Has Value', 'ae-pro' ),
			'not_exists' => __( 'Has No Value', 'ae-pro' ),
			'equals'     => __( 'Equals', 'ae-pro' ),
			'not_equals' => __( 'Does Not Equal', 'ae-pro' ),
			'contains'   => __( 'Contains', 'ae-pro' ),
		];
	}

	public function get_fields(): array {
		return [
			[
				'type'        => 'text',
				'name'        => 'field_name',
				'label'       => __( 'Field Name', 'ae-pro' ),
				'placeholder' => __( 'e.g. my_text_field', 'ae-pro' ),
			],
			[
				'type'        => 'text',
				'name'        => 'value',
				'label'       => __( 'Value', 'ae-pro' ),
				'placeholder' => __( 'Value to compare', 'ae-pro' ),
			],
		];
	}

	public function sanitize_value( $value ) {
		if ( is_array( $value ) ) {
			return [
				'field_name' => sanitize_key( $value['field_name'] ?? '' ),
				'value'      => sanitize_text_field( $value['value'] ?? '' ),
			];
		}
		return sanitize_text_field( (string) $value );
	}

	public function evaluate( string $operator, $value ): bool {
		[ $field_name, $expected, $post_id ] = $this->unpack( $value );
		if ( ! $field_name || false === $post_id ) { return false; }

		$field_val = get_field( $field_name, $post_id );
		$exists    = ! empty( $field_val );

		switch ( $operator ) {
			case 'exists':     return $exists;
			case 'not_exists': return ! $exists;
			case 'equals':     return $exists && (string) $field_val === $expected;
			case 'not_equals': return ! $exists || (string) $field_val !== $expected;
			case 'contains':   return $exists && str_contains( (string) $field_val, $expected );
			default:           return false;
		}
	}

	protected function unpack( $value ): array {
		$field_name = '';
		$expected   = '';
		if ( is_array( $value ) ) {
			$field_name = sanitize_key( $value['field_name'] ?? '' );
			$expected   = sanitize_text_field( $value['value'] ?? '' );
		}
		return [ $field_name, $expected, $this->resolve_post_id() ];
	}

	/**
	 * @return int|string|false
	 */
	protected function resolve_post_id() {
		if ( is_singular() ) {
			$post = get_queried_object();
			return $post instanceof \WP_Post ? $post->ID : false;
		}
		if ( is_tax() || is_category() || is_tag() ) {
			$term = get_queried_object();
			return $term instanceof \WP_Term ? 'term_' . $term->term_id : false;
		}
		if ( is_author() ) {
			$author = get_queried_object();
			return $author instanceof \WP_User ? 'user_' . $author->ID : false;
		}
		return false;
	}
}
