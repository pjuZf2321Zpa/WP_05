<?php
namespace Aepro\Admin\PresetRules\Rules;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * ACF Taxonomy field. Compares by term ID or slug.
 */
class Acf_Taxonomy_Rule extends Rule_Base {

	public static function is_available(): bool { return function_exists( 'get_field' ); }
	public function get_id(): string { return 'acf_taxonomy'; }
	public function get_label(): string { return __( 'ACF Taxonomy', 'ae-pro' ); }
	public function get_category(): string { return __( 'Advanced Custom Fields', 'ae-pro' ); }

	public function get_operators(): array {
		return [
			'exists'     => __( 'Has Term', 'ae-pro' ),
			'not_exists' => __( 'Has No Term', 'ae-pro' ),
			'equals'     => __( 'Includes Term', 'ae-pro' ),
			'not_equals' => __( 'Does Not Include Term', 'ae-pro' ),
		];
	}

	public function get_fields(): array {
		return [
			[
				'type'        => 'text',
				'name'        => 'field_name',
				'label'       => __( 'Field Name', 'ae-pro' ),
				'placeholder' => __( 'e.g. my_category_field', 'ae-pro' ),
			],
			[
				'type'        => 'text',
				'name'        => 'value',
				'label'       => __( 'Term ID or Slug', 'ae-pro' ),
				'placeholder' => __( 'e.g. 5 or news', 'ae-pro' ),
			],
		];
	}

	public function sanitize_value( $value ) {
		if ( is_array( $value ) ) {
			return [
				'field_name' => sanitize_key( $value['field_name'] ?? '' ),
				'value'      => sanitize_text_field( $value['value'] ?? '' ),
			];
		}
		return sanitize_text_field( (string) $value );
	}

	public function evaluate( string $operator, $value ): bool {
		$field_name = '';
		$term_cmp   = '';
		if ( is_array( $value ) ) {
			$field_name = sanitize_key( $value['field_name'] ?? '' );
			$term_cmp   = sanitize_text_field( $value['value'] ?? '' );
		}
		if ( ! $field_name ) { return false; }

		$post_id = $this->resolve_post_id();
		if ( false === $post_id ) { return false; }

		$field_val = get_field( $field_name, $post_id );
		$exists    = ! empty( $field_val );

		switch ( $operator ) {
			case 'exists':     return $exists;
			case 'not_exists': return ! $exists;
			case 'equals':
				if ( ! $exists ) { return false; }
				return $this->term_in( $field_val, $term_cmp );
			case 'not_equals':
				if ( ! $exists ) { return true; }
				return ! $this->term_in( $field_val, $term_cmp );
			default: return false;
		}
	}

	private function term_in( $field_val, string $compare ): bool {
		$terms = is_array( $field_val ) ? $field_val : [ $field_val ];
		foreach ( $terms as $term ) {
			if ( $term instanceof \WP_Term ) {
				if ( is_numeric( $compare ) && $term->term_id === absint( $compare ) ) { return true; }
				if ( $term->slug === sanitize_title( $compare ) ) { return true; }
			} elseif ( is_numeric( $compare ) && absint( $term ) === absint( $compare ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * @return int|string|false
	 */
	private function resolve_post_id() {
		if ( is_singular() ) {
			$post = get_queried_object();
			return $post instanceof \WP_Post ? $post->ID : false;
		}
		if ( is_tax() || is_category() || is_tag() ) {
			$term = get_queried_object();
			return $term instanceof \WP_Term ? 'term_' . $term->term_id : false;
		}
		if ( is_author() ) {
			$author = get_queried_object();
			return $author instanceof \WP_User ? 'user_' . $author->ID : false;
		}
		return false;
	}
}
