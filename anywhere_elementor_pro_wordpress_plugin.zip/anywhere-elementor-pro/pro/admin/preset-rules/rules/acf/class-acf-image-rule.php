<?php
namespace Aepro\Admin\PresetRules\Rules;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * ACF Image / File fields (and Gallery in ACF Pro).
 * Checks whether a media field is set or empty.
 */
class Acf_Image_Rule extends Rule_Base {

	public static function is_available(): bool { return function_exists( 'get_field' ); }
	public function get_id(): string { return 'acf_image'; }
	public function get_label(): string { return __( 'ACF Image', 'ae-pro' ); }
	public function get_category(): string { return __( 'Advanced Custom Fields', 'ae-pro' ); }

	public function get_operators(): array {
		return [
			'exists'     => __( 'Has Image / File', 'ae-pro' ),
			'not_exists' => __( 'Has No Image / File', 'ae-pro' ),
		];
	}

	public function get_fields(): array {
		return [
			[
				'type'        => 'text',
				'name'        => 'field_name',
				'label'       => __( 'Field Name', 'ae-pro' ),
				'placeholder' => __( 'e.g. featured_image', 'ae-pro' ),
			],
		];
	}

	public function sanitize_value( $value ) {
		if ( is_array( $value ) ) {
			return [ 'field_name' => sanitize_key( $value['field_name'] ?? '' ) ];
		}
		return sanitize_text_field( (string) $value );
	}

	public function evaluate( string $operator, $value ): bool {
		$field_name = is_array( $value ) ? sanitize_key( $value['field_name'] ?? '' ) : '';
		if ( ! $field_name ) { return false; }

		$post_id = $this->resolve_post_id();
		if ( false === $post_id ) { return false; }

		$field_val = get_field( $field_name, $post_id );
		$exists    = ! empty( $field_val );

		return 'not_exists' === $operator ? ! $exists : $exists;
	}

	/**
	 * @return int|string|false
	 */
	private function resolve_post_id() {
		if ( is_singular() ) {
			$post = get_queried_object();
			return $post instanceof \WP_Post ? $post->ID : false;
		}
		if ( is_tax() || is_category() || is_tag() ) {
			$term = get_queried_object();
			return $term instanceof \WP_Term ? 'term_' . $term->term_id : false;
		}
		if ( is_author() ) {
			$author = get_queried_object();
			return $author instanceof \WP_User ? 'user_' . $author->ID : false;
		}
		return false;
	}
}
