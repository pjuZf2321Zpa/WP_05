<?php
namespace Aepro\Admin\PresetRules\Rules;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * ACF Relationship field (returns array of WP_Post objects).
 * Checks whether the relationship contains a specific post.
 */
class Acf_Relationship_Rule extends Rule_Base {

	public static function is_available(): bool { return function_exists( 'get_field' ); }
	public function get_id(): string { return 'acf_relationship'; }
	public function get_label(): string { return __( 'ACF Relationship', 'ae-pro' ); }
	public function get_category(): string { return __( 'Advanced Custom Fields', 'ae-pro' ); }

	public function get_operators(): array {
		return [
			'exists'      => __( 'Has Related Posts', 'ae-pro' ),
			'not_exists'  => __( 'Has No Related Posts', 'ae-pro' ),
			'includes'    => __( 'Includes Post ID', 'ae-pro' ),
			'not_includes'=> __( 'Does Not Include Post ID', 'ae-pro' ),
		];
	}

	public function get_fields(): array {
		return [
			[
				'type'        => 'text',
				'name'        => 'field_name',
				'label'       => __( 'Field Name', 'ae-pro' ),
				'placeholder' => __( 'e.g. related_posts', 'ae-pro' ),
			],
			[
				'type'        => 'text',
				'name'        => 'value',
				'label'       => __( 'Post ID', 'ae-pro' ),
				'placeholder' => __( 'e.g. 42', 'ae-pro' ),
			],
		];
	}

	public function sanitize_value( $value ) {
		if ( is_array( $value ) ) {
			return [
				'field_name' => sanitize_key( $value['field_name'] ?? '' ),
				'value'      => absint( $value['value'] ?? 0 ),
			];
		}
		return sanitize_text_field( (string) $value );
	}

	public function evaluate( string $operator, $value ): bool {
		$field_name  = '';
		$post_id_cmp = 0;
		if ( is_array( $value ) ) {
			$field_name  = sanitize_key( $value['field_name'] ?? '' );
			$post_id_cmp = absint( $value['value'] ?? 0 );
		}
		if ( ! $field_name ) { return false; }

		$post_id = $this->resolve_post_id();
		if ( false === $post_id ) { return false; }

		$field_val = get_field( $field_name, $post_id );
		$items     = is_array( $field_val ) ? $field_val : ( $field_val ? [ $field_val ] : [] );
		$exists    = ! empty( $items );

		switch ( $operator ) {
			case 'exists':       return $exists;
			case 'not_exists':   return ! $exists;
			case 'includes':
				if ( ! $exists || ! $post_id_cmp ) { return false; }
				return in_array( $post_id_cmp, $this->extract_ids( $items ), true );
			case 'not_includes':
				if ( ! $exists || ! $post_id_cmp ) { return true; }
				return ! in_array( $post_id_cmp, $this->extract_ids( $items ), true );
			default: return false;
		}
	}

	private function extract_ids( array $items ): array {
		return array_filter( array_map(
			static fn( $v ) => $v instanceof \WP_Post ? $v->ID : absint( $v ),
			$items
		) );
	}

	/**
	 * @return int|string|false
	 */
	private function resolve_post_id() {
		if ( is_singular() ) {
			$post = get_queried_object();
			return $post instanceof \WP_Post ? $post->ID : false;
		}
		if ( is_tax() || is_category() || is_tag() ) {
			$term = get_queried_object();
			return $term instanceof \WP_Term ? 'term_' . $term->term_id : false;
		}
		if ( is_author() ) {
			$author = get_queried_object();
			return $author instanceof \WP_User ? 'user_' . $author->ID : false;
		}
		return false;
	}
}
