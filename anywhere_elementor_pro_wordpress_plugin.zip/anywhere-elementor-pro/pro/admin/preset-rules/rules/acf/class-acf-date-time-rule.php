<?php
namespace Aepro\Admin\PresetRules\Rules;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * ACF Date/Time fields: Date Picker, Date Time Picker, Time Picker.
 *
 * ACF stores Date Picker values as Ymd (e.g. 20251231) by default.
 * Date Time Picker stores as Y-m-d H:i:s.
 * The compare value should be entered in the same format the field stores.
 */
class Acf_Date_Time_Rule extends Rule_Base {

	public static function is_available(): bool { return function_exists( 'get_field' ); }
	public function get_id(): string { return 'acf_date_time'; }
	public function get_label(): string { return __( 'ACF Date Time', 'ae-pro' ); }
	public function get_category(): string { return __( 'Advanced Custom Fields', 'ae-pro' ); }

	public function get_operators(): array {
		return [
			'exists'     => __( 'Has Date', 'ae-pro' ),
			'not_exists' => __( 'Has No Date', 'ae-pro' ),
			'before'     => __( 'Is Before', 'ae-pro' ),
			'after'      => __( 'Is After', 'ae-pro' ),
			'equals'     => __( 'Equals', 'ae-pro' ),
		];
	}

	public function get_fields(): array {
		return [
			[
				'type'        => 'text',
				'name'        => 'field_name',
				'label'       => __( 'Field Name', 'ae-pro' ),
				'placeholder' => __( 'e.g. event_date', 'ae-pro' ),
			],
			[
				'type'        => 'text',
				'name'        => 'value',
				'label'       => __( 'Compare Date', 'ae-pro' ),
				'placeholder' => __( 'Match ACF storage format', 'ae-pro' ),
			],
		];
	}

	public function sanitize_value( $value ) {
		if ( is_array( $value ) ) {
			return [
				'field_name' => sanitize_key( $value['field_name'] ?? '' ),
				'value'      => sanitize_text_field( $value['value'] ?? '' ),
			];
		}
		return sanitize_text_field( (string) $value );
	}

	public function evaluate( string $operator, $value ): bool {
		$field_name = '';
		$compare    = '';
		if ( is_array( $value ) ) {
			$field_name = sanitize_key( $value['field_name'] ?? '' );
			$compare    = sanitize_text_field( $value['value'] ?? '' );
		}
		if ( ! $field_name ) { return false; }

		$post_id = $this->resolve_post_id();
		if ( false === $post_id ) { return false; }

		// Use raw (stored) value so we compare in ACF's own format.
		$field_val = get_field( $field_name, $post_id, false );
		$exists    = ! empty( $field_val );

		switch ( $operator ) {
			case 'exists':     return $exists;
			case 'not_exists': return ! $exists;
			case 'equals':     return $exists && (string) $field_val === $compare;
			case 'before':     return $exists && strcmp( (string) $field_val, $compare ) < 0;
			case 'after':      return $exists && strcmp( (string) $field_val, $compare ) > 0;
			default:           return false;
		}
	}

	/**
	 * @return int|string|false
	 */
	private function resolve_post_id() {
		if ( is_singular() ) {
			$post = get_queried_object();
			return $post instanceof \WP_Post ? $post->ID : false;
		}
		if ( is_tax() || is_category() || is_tag() ) {
			$term = get_queried_object();
			return $term instanceof \WP_Term ? 'term_' . $term->term_id : false;
		}
		if ( is_author() ) {
			$author = get_queried_object();
			return $author instanceof \WP_User ? 'user_' . $author->ID : false;
		}
		return false;
	}
}
