<?php
namespace Aepro\Admin\PresetRules\Rules;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Evaluates an ACF field value on the current post / queried object.
 *
 * Works with ACF Free and ACF Pro. The `get_field()` function is available
 * in both editions once the plugin is active.
 *
 * --- ACF Free field types and how they evaluate ---
 *
 * Simple scalars (all operators work):
 *   Text, Textarea, Number, Range, Email, URL, Password, Color Picker,
 *   Date Picker, Date Time Picker, Time Picker, oEmbed, WYSIWYG, Page Link.
 *
 * True/False (all operators work; "exists" = is checked/true):
 *   Returns 1 (checked) or '' (unchecked). "exists" is true only when checked.
 *
 * Multi-value — returns array (equals checks membership, contains checks joined string):
 *   Select (multiple), Checkbox.
 *
 * Single-value select (all operators work):
 *   Select (single), Radio, Button Group.
 *
 * Object fields — normalized to ID (Post Object, Relationship, Taxonomy, User):
 *   equals "42" matches post/term/user with ID 42.
 *
 * Media fields — normalized to URL (Image, File):
 *   equals/contains compare against the file URL.
 *
 * Link — normalized to the URL value.
 *
 * Group — normalized to comma-joined sub-field values.
 *
 * --- ACF Pro additional field types ---
 *
 * Repeater, Flexible Content, Clone, Gallery:
 *   Use "exists" / "not_exists" — these return nested arrays that are
 *   difficult to compare as scalars.
 */
class Acf_Field_Rule extends Rule_Base {

	/**
	 * Rule is only available when ACF (free or pro) is active.
	 */
	public static function is_available(): bool {
		return function_exists( 'get_field' );
	}

	public function get_id(): string {
		return 'acf_field';
	}

	public function get_label(): string {
		return __( 'ACF Field', 'ae-pro' );
	}

	public function get_category(): string {
		return __( 'ACF', 'ae-pro' );
	}

	public function get_operators(): array {
		return [
			'exists'     => __( 'Has Value (Exists)', 'ae-pro' ),
			'not_exists' => __( 'Has No Value (Empty)', 'ae-pro' ),
			'equals'     => __( 'Value Equals', 'ae-pro' ),
			'not_equals' => __( 'Value Does Not Equal', 'ae-pro' ),
			'contains'   => __( 'Value Contains', 'ae-pro' ),
		];
	}

	public function get_fields(): array {
		return [
			[
				'type'        => 'text',
				'name'        => 'field_name',
				'label'       => __( 'Field Name', 'ae-pro' ),
				'placeholder' => __( 'Field name, e.g. my_field', 'ae-pro' ),
			],
			[
				'type'        => 'text',
				'name'        => 'value',
				'label'       => __( 'Compare Value', 'ae-pro' ),
				'placeholder' => __( 'Value (for Equals / Contains)', 'ae-pro' ),
			],
		];
	}

	public function sanitize_value( $value ) {
		if ( is_array( $value ) ) {
			return [
				'field_name' => sanitize_key( $value['field_name'] ?? '' ),
				'value'      => sanitize_text_field( $value['value'] ?? '' ),
			];
		}
		return sanitize_text_field( (string) $value );
	}

	public function evaluate( string $operator, $value ): bool {
		$field_name = '';
		$expected   = '';

		if ( is_array( $value ) ) {
			$field_name = sanitize_key( $value['field_name'] ?? '' );
			$expected   = sanitize_text_field( $value['value'] ?? '' );
		}

		if ( empty( $field_name ) ) {
			return false;
		}

		$post_id = $this->resolve_post_id();
		if ( false === $post_id ) {
			return false;
		}

		$field_val = get_field( $field_name, $post_id );

		// exists / not_exists — check truthiness (True/False "off" = not exists).
		$exists = ! empty( $field_val );

		switch ( $operator ) {
			case 'exists':
				return $exists;

			case 'not_exists':
				return ! $exists;

			case 'equals':
				if ( ! $exists ) {
					return false;
				}
				// Multi-value fields (checkbox, select-multiple): check membership.
				if ( is_array( $field_val ) && ! $this->is_associative( $field_val ) ) {
					$normalized = array_map( [ $this, 'normalize' ], $field_val );
					return in_array( $expected, $normalized, true );
				}
				return $this->normalize( $field_val ) === $expected;

			case 'not_equals':
				if ( ! $exists ) {
					return true;
				}
				if ( is_array( $field_val ) && ! $this->is_associative( $field_val ) ) {
					$normalized = array_map( [ $this, 'normalize' ], $field_val );
					return ! in_array( $expected, $normalized, true );
				}
				return $this->normalize( $field_val ) !== $expected;

			case 'contains':
				return $exists && str_contains( $this->normalize( $field_val ), $expected );

			default:
				return false;
		}
	}

	// -------------------------------------------------------------------------
	// Helpers
	// -------------------------------------------------------------------------

	/**
	 * Flatten any ACF field value to a comparable string.
	 *
	 * - bool         → '1' or '0'
	 * - WP_Post      → post ID
	 * - WP_Term      → term ID
	 * - WP_User      → user ID
	 * - Image/File   → URL (associative array with 'url' key)
	 * - Link         → URL (associative array with 'url' key)
	 * - scalar array → comma-joined normalized items
	 * - scalar       → (string) cast
	 */
	private function normalize( $val ): string {
		if ( is_bool( $val ) ) {
			return $val ? '1' : '0';
		}

		if ( $val instanceof \WP_Post ) {
			return (string) $val->ID;
		}

		if ( $val instanceof \WP_Term ) {
			return (string) $val->term_id;
		}

		if ( $val instanceof \WP_User ) {
			return (string) $val->ID;
		}

		if ( is_array( $val ) ) {
			// Image / File / Link return an associative array with a 'url' key.
			if ( isset( $val['url'] ) ) {
				return (string) $val['url'];
			}

			// Everything else (Group, Repeater, Flexible Content, Gallery,
			// indexed arrays of objects) — join normalized items.
			return implode( ',', array_map( [ $this, 'normalize' ], array_values( $val ) ) );
		}

		return (string) $val;
	}

	/**
	 * Returns true when the array is associative (string keys), false when
	 * it is an indexed list of items (checkbox selections, relationships, etc.).
	 */
	private function is_associative( array $arr ): bool {
		if ( [] === $arr ) {
			return false;
		}
		return array_keys( $arr ) !== range( 0, count( $arr ) - 1 );
	}

	/**
	 * Resolves the object ID to pass to get_field().
	 * ACF expects: int for posts, 'term_<id>' for terms, 'user_<id>' for users.
	 *
	 * @return int|string|false
	 */
	private function resolve_post_id() {
		if ( is_singular() ) {
			$post = get_queried_object();
			return $post instanceof \WP_Post ? $post->ID : false;
		}

		if ( is_tax() || is_category() || is_tag() ) {
			$term = get_queried_object();
			if ( $term instanceof \WP_Term ) {
				return 'term_' . $term->term_id;
			}
		}

		if ( is_author() ) {
			$author = get_queried_object();
			if ( $author instanceof \WP_User ) {
				return 'user_' . $author->ID;
			}
		}

		return false;
	}
}
