<?php
namespace Aepro\Admin\PresetRules\Rules;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * ACF Choice fields: Select, Checkbox, Radio Button, Button Group.
 * Supports single and multi-value (equals checks set membership).
 */
class Acf_Choice_Rule extends Rule_Base {

	public static function is_available(): bool { return function_exists( 'get_field' ); }
	public function get_id(): string { return 'acf_choice'; }
	public function get_label(): string { return __( 'ACF Choice', 'ae-pro' ); }
	public function get_category(): string { return __( 'Advanced Custom Fields', 'ae-pro' ); }

	public function get_operators(): array {
		return [
			'exists'     => __( 'Has Selection', 'ae-pro' ),
			'not_exists' => __( 'Has No Selection', 'ae-pro' ),
			'equals'     => __( 'Includes', 'ae-pro' ),
			'not_equals' => __( 'Does Not Include', 'ae-pro' ),
		];
	}

	public function get_fields(): array {
		return [
			[
				'type'        => 'text',
				'name'        => 'field_name',
				'label'       => __( 'Field Name', 'ae-pro' ),
				'placeholder' => __( 'e.g. my_select_field', 'ae-pro' ),
			],
			[
				'type'        => 'text',
				'name'        => 'value',
				'label'       => __( 'Choice Value', 'ae-pro' ),
				'placeholder' => __( 'e.g. option_key', 'ae-pro' ),
			],
		];
	}

	public function sanitize_value( $value ) {
		if ( is_array( $value ) ) {
			return [
				'field_name' => sanitize_key( $value['field_name'] ?? '' ),
				'value'      => sanitize_text_field( $value['value'] ?? '' ),
			];
		}
		return sanitize_text_field( (string) $value );
	}

	public function evaluate( string $operator, $value ): bool {
		$field_name = '';
		$expected   = '';
		if ( is_array( $value ) ) {
			$field_name = sanitize_key( $value['field_name'] ?? '' );
			$expected   = sanitize_text_field( $value['value'] ?? '' );
		}
		if ( ! $field_name ) { return false; }

		$post_id = $this->resolve_post_id();
		if ( false === $post_id ) { return false; }

		$field_val = get_field( $field_name, $post_id );
		$exists    = ! empty( $field_val );

		// Normalise to array for uniform membership check.
		$items = $exists ? (array) $field_val : [];

		switch ( $operator ) {
			case 'exists':     return $exists;
			case 'not_exists': return ! $exists;
			case 'equals':     return in_array( $expected, array_map( 'strval', $items ), true );
			case 'not_equals': return ! in_array( $expected, array_map( 'strval', $items ), true );
			default:           return false;
		}
	}

	/**
	 * @return int|string|false
	 */
	private function resolve_post_id() {
		if ( is_singular() ) {
			$post = get_queried_object();
			return $post instanceof \WP_Post ? $post->ID : false;
		}
		if ( is_tax() || is_category() || is_tag() ) {
			$term = get_queried_object();
			return $term instanceof \WP_Term ? 'term_' . $term->term_id : false;
		}
		if ( is_author() ) {
			$author = get_queried_object();
			return $author instanceof \WP_User ? 'user_' . $author->ID : false;
		}
		return false;
	}
}
