<?php
namespace Aepro\Admin\PresetRules\Rules;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Day_Of_Week_Rule extends Rule_Base {

	public function get_id(): string {
		return 'day_of_week';
	}

	public function get_label(): string {
		return __( 'Day of Week', 'ae-pro' );
	}

	public function get_category(): string {
		return __( 'Date & Time', 'ae-pro' );
	}

	public function get_operators(): array {
		return [
			'is'     => __( 'Is', 'ae-pro' ),
			'is_not' => __( 'Is Not', 'ae-pro' ),
		];
	}

	public function get_fields(): array {
		return [
			[
				'type'    => 'select',
				'name'    => 'value',
				'label'   => __( 'Day', 'ae-pro' ),
				'options' => [
					'1' => __( 'Monday', 'ae-pro' ),
					'2' => __( 'Tuesday', 'ae-pro' ),
					'3' => __( 'Wednesday', 'ae-pro' ),
					'4' => __( 'Thursday', 'ae-pro' ),
					'5' => __( 'Friday', 'ae-pro' ),
					'6' => __( 'Saturday', 'ae-pro' ),
					'7' => __( 'Sunday', 'ae-pro' ),
				],
			],
		];
	}

	public function evaluate( string $operator, $value ): bool {
		$tz      = wp_timezone();
		$now     = new \DateTime( 'now', $tz );
		$today   = (int) $now->format( 'N' ); // 1 = Mon … 7 = Sun (ISO-8601)
		$matches = $today === (int) $value;
		return 'is_not' === $operator ? ! $matches : $matches;
	}
}
