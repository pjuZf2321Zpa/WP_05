<?php
namespace Aepro\Admin\PresetRules\Rules;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Day_Rule extends Rule_Base {

	public function get_id(): string {
		return 'day_of_month';
	}

	public function get_label(): string {
		return __( 'Day of Month', 'ae-pro' );
	}

	public function get_category(): string {
		return __( 'Date & Time', 'ae-pro' );
	}

	public function get_operators(): array {
		return [
			'is'           => __( 'Is', 'ae-pro' ),
			'is_not'       => __( 'Is Not', 'ae-pro' ),
			'greater_than' => __( 'Greater Than', 'ae-pro' ),
			'less_than'    => __( 'Less Than', 'ae-pro' ),
		];
	}

	public function get_fields(): array {
		return [
			[
				'type'        => 'text',
				'name'        => 'value',
				'label'       => __( 'Day (1–31)', 'ae-pro' ),
				'placeholder' => __( 'e.g. 15', 'ae-pro' ),
			],
		];
	}

	public function sanitize_value( $value ) {
		return absint( $value );
	}

	public function evaluate( string $operator, $value ): bool {
		$day     = absint( $value );
		$current = absint( ( new \DateTime( 'now', wp_timezone() ) )->format( 'j' ) );

		switch ( $operator ) {
			case 'is':
				return $current === $day;
			case 'is_not':
				return $current !== $day;
			case 'greater_than':
				return $current > $day;
			case 'less_than':
				return $current < $day;
			default:
				return false;
		}
	}
}
