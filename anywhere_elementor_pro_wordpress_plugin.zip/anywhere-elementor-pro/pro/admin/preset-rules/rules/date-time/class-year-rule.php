<?php
namespace Aepro\Admin\PresetRules\Rules;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Year_Rule extends Rule_Base {

	public function get_id(): string {
		return 'year';
	}

	public function get_label(): string {
		return __( 'Year', 'ae-pro' );
	}

	public function get_category(): string {
		return __( 'Date & Time', 'ae-pro' );
	}

	public function get_operators(): array {
		return [
			'is'           => __( 'Is', 'ae-pro' ),
			'is_not'       => __( 'Is Not', 'ae-pro' ),
			'greater_than' => __( 'Greater Than', 'ae-pro' ),
			'less_than'    => __( 'Less Than', 'ae-pro' ),
		];
	}

	public function get_fields(): array {
		return [
			[
				'type'        => 'text',
				'name'        => 'value',
				'label'       => __( 'Year', 'ae-pro' ),
				'placeholder' => __( 'e.g. 2025', 'ae-pro' ),
			],
		];
	}

	public function sanitize_value( $value ) {
		return absint( $value );
	}

	public function evaluate( string $operator, $value ): bool {
		$year    = absint( $value );
		$current = absint( ( new \DateTime( 'now', wp_timezone() ) )->format( 'Y' ) );

		switch ( $operator ) {
			case 'is':
				return $current === $year;
			case 'is_not':
				return $current !== $year;
			case 'greater_than':
				return $current > $year;
			case 'less_than':
				return $current < $year;
			default:
				return false;
		}
	}
}
