<?php
namespace Aepro\Admin\PresetRules\Rules;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Month_Rule extends Rule_Base {

	public function get_id(): string {
		return 'month';
	}

	public function get_label(): string {
		return __( 'Month', 'ae-pro' );
	}

	public function get_category(): string {
		return __( 'Date & Time', 'ae-pro' );
	}

	public function get_operators(): array {
		return [
			'is'     => __( 'Is', 'ae-pro' ),
			'is_not' => __( 'Is Not', 'ae-pro' ),
		];
	}

	public function get_fields(): array {
		return [
			[
				'type'    => 'select',
				'name'    => 'value',
				'label'   => __( 'Month', 'ae-pro' ),
				'options' => [
					'1'  => __( 'January', 'ae-pro' ),
					'2'  => __( 'February', 'ae-pro' ),
					'3'  => __( 'March', 'ae-pro' ),
					'4'  => __( 'April', 'ae-pro' ),
					'5'  => __( 'May', 'ae-pro' ),
					'6'  => __( 'June', 'ae-pro' ),
					'7'  => __( 'July', 'ae-pro' ),
					'8'  => __( 'August', 'ae-pro' ),
					'9'  => __( 'September', 'ae-pro' ),
					'10' => __( 'October', 'ae-pro' ),
					'11' => __( 'November', 'ae-pro' ),
					'12' => __( 'December', 'ae-pro' ),
				],
			],
		];
	}

	public function sanitize_value( $value ) {
		return absint( $value );
	}

	public function evaluate( string $operator, $value ): bool {
		$month   = absint( $value );
		$current = absint( ( new \DateTime( 'now', wp_timezone() ) )->format( 'n' ) );
		$matches = $current === $month;
		return 'is_not' === $operator ? ! $matches : $matches;
	}
}
