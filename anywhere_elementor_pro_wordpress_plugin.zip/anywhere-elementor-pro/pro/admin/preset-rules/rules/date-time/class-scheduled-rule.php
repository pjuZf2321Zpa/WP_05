<?php
namespace Aepro\Admin\PresetRules\Rules;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Scheduled_Rule extends Rule_Base {

	public function get_id(): string {
		return 'scheduled';
	}

	public function get_label(): string {
		return __( 'Scheduled Visibility', 'ae-pro' );
	}

	public function get_category(): string {
		return __( 'Date & Time', 'ae-pro' );
	}

	public function get_operators(): array {
		return [
			'active'   => __( 'Active (within schedule)', 'ae-pro' ),
			'inactive' => __( 'Inactive (outside schedule)', 'ae-pro' ),
		];
	}

	public function get_fields(): array {
		return [
			[
				'type'        => 'text',
				'name'        => 'start_datetime',
				'label'       => __( 'Start (YYYY-MM-DD HH:MM)', 'ae-pro' ),
				'placeholder' => __( 'e.g. 2025-06-01 09:00', 'ae-pro' ),
			],
			[
				'type'        => 'text',
				'name'        => 'end_datetime',
				'label'       => __( 'End (YYYY-MM-DD HH:MM)', 'ae-pro' ),
				'placeholder' => __( 'e.g. 2025-06-30 17:00', 'ae-pro' ),
			],
		];
	}

	public function sanitize_value( $value ) {
		if ( is_array( $value ) ) {
			return [
				'start_datetime' => sanitize_text_field( $value['start_datetime'] ?? '' ),
				'end_datetime'   => sanitize_text_field( $value['end_datetime'] ?? '' ),
			];
		}
		return sanitize_text_field( (string) $value );
	}

	public function evaluate( string $operator, $value ): bool {
		$start_str = '';
		$end_str   = '';
		if ( is_array( $value ) ) {
			$start_str = sanitize_text_field( $value['start_datetime'] ?? '' );
			$end_str   = sanitize_text_field( $value['end_datetime'] ?? '' );
		}

		$tz  = wp_timezone();
		$now = new \DateTime( 'now', $tz );

		$start = $this->parse_datetime( $start_str, $tz );
		$end   = $this->parse_datetime( $end_str, $tz );

		// Allow open-ended schedules.
		$after_start  = ! $start || $now >= $start;
		$before_end   = ! $end   || $now <= $end;
		$within       = $after_start && $before_end;

		return 'inactive' === $operator ? ! $within : $within;
	}

	private function parse_datetime( string $dt, \DateTimeZone $tz ): ?\DateTime {
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$/', $dt ) ) {
			return null;
		}
		$obj = \DateTime::createFromFormat( 'Y-m-d H:i', $dt, $tz );
		return $obj ?: null;
	}
}
