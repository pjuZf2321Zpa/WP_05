<?php
namespace Aepro\Admin\PresetRules\Rules;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Date_Rule extends Rule_Base {

	public function get_id(): string {
		return 'date';
	}

	public function get_label(): string {
		return __( 'Date', 'ae-pro' );
	}

	public function get_category(): string {
		return __( 'Date & Time', 'ae-pro' );
	}

	public function get_operators(): array {
		return [
			'is'      => __( 'Is', 'ae-pro' ),
			'before'  => __( 'Before', 'ae-pro' ),
			'after'   => __( 'After', 'ae-pro' ),
			'between' => __( 'Between', 'ae-pro' ),
		];
	}

	public function get_fields(): array {
		return [
			[
				'type'        => 'text',
				'name'        => 'date',
				'label'       => __( 'Date', 'ae-pro' ),
				'placeholder' => __( 'YYYY-MM-DD', 'ae-pro' ),
			],
			[
				'type'               => 'text',
				'name'               => 'date_end',
				'label'              => __( 'End Date', 'ae-pro' ),
				'placeholder'        => __( 'YYYY-MM-DD', 'ae-pro' ),
				'show_for_operators' => [ 'between' ],
			],
		];
	}

	public function sanitize_value( $value ) {
		if ( is_array( $value ) ) {
			return [
				'date'     => sanitize_text_field( $value['date'] ?? '' ),
				'date_end' => sanitize_text_field( $value['date_end'] ?? '' ),
			];
		}
		return sanitize_text_field( (string) $value );
	}

	public function evaluate( string $operator, $value ): bool {
		$tz   = wp_timezone();
		$now  = new \DateTime( 'now', $tz );
		$today = new \DateTime( $now->format( 'Y-m-d' ), $tz );

		$date     = '';
		$date_end = '';
		if ( is_array( $value ) ) {
			$date     = sanitize_text_field( $value['date'] ?? '' );
			$date_end = sanitize_text_field( $value['date_end'] ?? '' );
		}

		$start = $this->parse_date( $date, $tz );
		if ( ! $start ) {
			return false;
		}

		switch ( $operator ) {
			case 'is':
				return $today == $start;
			case 'before':
				return $today < $start;
			case 'after':
				return $today > $start;
			case 'between':
				$end = $this->parse_date( $date_end, $tz );
				return $end && $today >= $start && $today <= $end;
			default:
				return false;
		}
	}

	private function parse_date( string $date, \DateTimeZone $tz ): ?\DateTime {
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ) {
			return null;
		}
		[ $y, $m, $d ] = array_map( 'intval', explode( '-', $date ) );
		if ( ! checkdate( $m, $d, $y ) ) {
			return null;
		}
		$dt = \DateTime::createFromFormat( 'Y-m-d', $date, $tz );
		if ( ! $dt ) {
			return null;
		}
		$dt->setTime( 0, 0, 0 );
		return $dt;
	}
}
