<?php
namespace Aepro\Admin\PresetRules\Rules;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Business_Hours_Rule extends Rule_Base {

	public function get_id(): string {
		return 'business_hours';
	}

	public function get_label(): string {
		return __( 'Business Hours', 'ae-pro' );
	}

	public function get_category(): string {
		return __( 'Date & Time', 'ae-pro' );
	}

	public function get_operators(): array {
		return [
			'within'  => __( 'Within Business Hours', 'ae-pro' ),
			'outside' => __( 'Outside Business Hours', 'ae-pro' ),
		];
	}

	public function get_fields(): array {
		return [
			[
				'type'        => 'text',
				'name'        => 'start_time',
				'label'       => __( 'Open Time (HH:MM)', 'ae-pro' ),
				'placeholder' => __( 'e.g. 09:00', 'ae-pro' ),
			],
			[
				'type'        => 'text',
				'name'        => 'end_time',
				'label'       => __( 'Close Time (HH:MM)', 'ae-pro' ),
				'placeholder' => __( 'e.g. 17:00', 'ae-pro' ),
			],
			[
				'type'        => 'text',
				'name'        => 'days',
				'label'       => __( 'Days (ISO 1=Mon … 7=Sun)', 'ae-pro' ),
				'placeholder' => __( 'e.g. 1,2,3,4,5', 'ae-pro' ),
			],
		];
	}

	public function sanitize_value( $value ) {
		if ( is_array( $value ) ) {
			return [
				'start_time' => sanitize_text_field( $value['start_time'] ?? '' ),
				'end_time'   => sanitize_text_field( $value['end_time'] ?? '' ),
				'days'       => sanitize_text_field( $value['days'] ?? '' ),
			];
		}
		return sanitize_text_field( (string) $value );
	}

	public function evaluate( string $operator, $value ): bool {
		$start_str = '';
		$end_str   = '';
		$days_str  = '1,2,3,4,5';

		if ( is_array( $value ) ) {
			$start_str = sanitize_text_field( $value['start_time'] ?? '' );
			$end_str   = sanitize_text_field( $value['end_time'] ?? '' );
			$days_str  = sanitize_text_field( $value['days'] ?? '1,2,3,4,5' );
		}

		$tz      = wp_timezone();
		$now     = new \DateTime( 'now', $tz );
		$current = (int) $now->format( 'Hi' );
		// ISO day: 1=Monday … 7=Sunday.
		$today   = (int) $now->format( 'N' );

		$allowed_days = array_filter( array_map( 'absint', explode( ',', $days_str ) ) );
		if ( ! in_array( $today, $allowed_days, true ) ) {
			return 'outside' === $operator;
		}

		$start = $this->parse_hhmm( $start_str );
		$end   = $this->parse_hhmm( $end_str );

		if ( null === $start || null === $end ) {
			return false;
		}

		$within = $start <= $end
			? $current >= $start && $current <= $end
			: $current >= $start || $current <= $end;

		return 'outside' === $operator ? ! $within : $within;
	}

	private function parse_hhmm( string $time ): ?int {
		if ( ! preg_match( '/^([01]\d|2[0-3]):([0-5]\d)$/', $time, $m ) ) {
			return null;
		}
		return (int) $m[1] * 100 + (int) $m[2];
	}
}
