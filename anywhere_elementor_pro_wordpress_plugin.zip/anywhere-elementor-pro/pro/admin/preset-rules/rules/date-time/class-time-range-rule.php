<?php
namespace Aepro\Admin\PresetRules\Rules;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Time_Range_Rule extends Rule_Base {

	public function get_id(): string {
		return 'time_range';
	}

	public function get_label(): string {
		return __( 'Time Range', 'ae-pro' );
	}

	public function get_category(): string {
		return __( 'Date & Time', 'ae-pro' );
	}

	public function get_operators(): array {
		return [
			'within'  => __( 'Within Range', 'ae-pro' ),
			'outside' => __( 'Outside Range', 'ae-pro' ),
		];
	}

	public function get_fields(): array {
		return [
			[
				'type'        => 'text',
				'name'        => 'start_time',
				'label'       => __( 'Start Time (HH:MM)', 'ae-pro' ),
				'placeholder' => __( 'e.g. 09:00', 'ae-pro' ),
			],
			[
				'type'        => 'text',
				'name'        => 'end_time',
				'label'       => __( 'End Time (HH:MM)', 'ae-pro' ),
				'placeholder' => __( 'e.g. 17:00', 'ae-pro' ),
			],
		];
	}

	public function sanitize_value( $value ) {
		if ( is_array( $value ) ) {
			return [
				'start_time' => sanitize_text_field( $value['start_time'] ?? '' ),
				'end_time'   => sanitize_text_field( $value['end_time'] ?? '' ),
			];
		}
		return sanitize_text_field( (string) $value );
	}

	public function evaluate( string $operator, $value ): bool {
		$start_str = '';
		$end_str   = '';
		if ( is_array( $value ) ) {
			$start_str = sanitize_text_field( $value['start_time'] ?? '' );
			$end_str   = sanitize_text_field( $value['end_time'] ?? '' );
		}

		$tz      = wp_timezone();
		$now     = new \DateTime( 'now', $tz );
		$current = (int) $now->format( 'Hi' ); // e.g. 1430 for 14:30

		$start = $this->parse_hhmm( $start_str );
		$end   = $this->parse_hhmm( $end_str );

		if ( null === $start || null === $end ) {
			return false;
		}

		// Handle overnight ranges (e.g. 22:00 – 06:00).
		if ( $start <= $end ) {
			$within = $current >= $start && $current <= $end;
		} else {
			$within = $current >= $start || $current <= $end;
		}

		return 'outside' === $operator ? ! $within : $within;
	}

	private function parse_hhmm( string $time ): ?int {
		if ( ! preg_match( '/^([01]\d|2[0-3]):([0-5]\d)$/', $time, $m ) ) {
			return null;
		}
		return (int) $m[1] * 100 + (int) $m[2];
	}
}
