<?php
namespace Aepro\Admin\PresetRules\Rules;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Query_String_Rule extends Rule_Base {

	public function get_id(): string {
		return 'query_string';
	}

	public function get_label(): string {
		return __( 'Query String', 'ae-pro' );
	}

	public function get_category(): string {
		return __( 'URL', 'ae-pro' );
	}

	public function get_operators(): array {
		return [
			'exists'     => __( 'Parameter Exists', 'ae-pro' ),
			'not_exists' => __( 'Parameter Does Not Exist', 'ae-pro' ),
			'equals'     => __( 'Value Equals', 'ae-pro' ),
			'not_equals' => __( 'Value Does Not Equal', 'ae-pro' ),
			'contains'   => __( 'Value Contains', 'ae-pro' ),
		];
	}

	public function get_fields(): array {
		return [
			[
				'type'        => 'text',
				'name'        => 'param',
				'label'       => __( 'Parameter Name', 'ae-pro' ),
				'placeholder' => __( 'e.g. ref', 'ae-pro' ),
			],
			[
				'type'        => 'text',
				'name'        => 'value',
				'label'       => __( 'Parameter Value', 'ae-pro' ),
				'placeholder' => __( 'For Equals / Contains operators', 'ae-pro' ),
			],
		];
	}

	public function sanitize_value( $value ) {
		if ( is_array( $value ) ) {
			return [
				'param' => sanitize_key( $value['param'] ?? '' ),
				'value' => sanitize_text_field( $value['value'] ?? '' ),
			];
		}
		return sanitize_text_field( (string) $value );
	}

	public function evaluate( string $operator, $value ): bool {
		$param = '';
		$val   = '';
		if ( is_array( $value ) ) {
			$param = sanitize_key( $value['param'] ?? '' );
			$val   = sanitize_text_field( $value['value'] ?? '' );
		}

		if ( empty( $param ) ) {
			return false;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$param_exists = isset( $_GET[ $param ] );
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$param_val = $param_exists ? sanitize_text_field( wp_unslash( (string) $_GET[ $param ] ) ) : null;

		switch ( $operator ) {
			case 'exists':
				return $param_exists;
			case 'not_exists':
				return ! $param_exists;
			case 'equals':
				return $param_exists && $param_val === $val;
			case 'not_equals':
				return ! $param_exists || $param_val !== $val;
			case 'contains':
				return $param_exists && str_contains( (string) $param_val, $val );
			default:
				return false;
		}
	}
}
