<?php
namespace Aepro\Admin\PresetRules\Rules;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Url_Contains_Rule extends Rule_Base {

	public function get_id(): string {
		return 'url_contains';
	}

	public function get_label(): string {
		return __( 'URL Contains', 'ae-pro' );
	}

	public function get_category(): string {
		return __( 'URL', 'ae-pro' );
	}

	public function get_operators(): array {
		return [
			'contains'     => __( 'Contains', 'ae-pro' ),
			'not_contains' => __( 'Does Not Contain', 'ae-pro' ),
			'equals'       => __( 'Equals', 'ae-pro' ),
			'starts_with'  => __( 'Starts With', 'ae-pro' ),
			'ends_with'    => __( 'Ends With', 'ae-pro' ),
		];
	}

	public function get_fields(): array {
		return [
			[
				'type'        => 'text',
				'name'        => 'value',
				'label'       => __( 'URL String', 'ae-pro' ),
				'placeholder' => __( 'e.g. /shop/ or ?ref=email', 'ae-pro' ),
			],
		];
	}

	public function evaluate( string $operator, $value ): bool {
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$request_uri = isset( $_SERVER['REQUEST_URI'] ) ? esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '';
		$needle      = (string) $value;

		switch ( $operator ) {
			case 'contains':
				return str_contains( $request_uri, $needle );
			case 'not_contains':
				return ! str_contains( $request_uri, $needle );
			case 'equals':
				return $request_uri === $needle;
			case 'starts_with':
				return str_starts_with( $request_uri, $needle );
			case 'ends_with':
				return str_ends_with( $request_uri, $needle );
			default:
				return false;
		}
	}
}
