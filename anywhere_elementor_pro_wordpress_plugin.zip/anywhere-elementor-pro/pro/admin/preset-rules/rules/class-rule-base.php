<?php
namespace Aepro\Admin\PresetRules\Rules;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Abstract base for every Preset Rule type.
 *
 * Extend this class, implement all abstract methods, then register
 * the rule with Rule_Registry on the `aepro/preset-rules/registry/init` action:
 *
 *   add_action( 'aepro/preset-rules/registry/init', function( $registry ) {
 *       $registry->register( new My_Custom_Rule() );
 *   } );
 */
abstract class Rule_Base {

	// -------------------------------------------------------------------------
	// Identity
	// -------------------------------------------------------------------------

	/** Unique machine key, e.g. 'logged_in'. Used in stored data. */
	abstract public function get_id(): string;

	/** Human-readable name shown in the Type dropdown. */
	abstract public function get_label(): string;

	/** Category label for grouping, e.g. 'User', 'Content'. */
	abstract public function get_category(): string;

	// -------------------------------------------------------------------------
	// UI definition
	// -------------------------------------------------------------------------

	/**
	 * Available operators for this rule type.
	 *
	 * @return array<string, string>  [ 'operator_key' => 'Label' ]
	 */
	abstract public function get_operators(): array;

	/**
	 * Field definitions for the rule builder UI.
	 *
	 * Each element is an associative array:
	 *   type    — 'select' | 'text' | 'number' | 'textarea'
	 *   name    — the key used in the stored rule data (typically 'value')
	 *   label   — visible label
	 *   options — (select only) [ 'key' => 'Label' ]
	 *   placeholder — (text/number) optional
	 *
	 * Return an empty array when the rule has no configurable value field
	 * (e.g. a boolean state like is_singular).
	 *
	 * @return array<int, array<string, mixed>>
	 */
	abstract public function get_fields(): array;

	// -------------------------------------------------------------------------
	// Runtime
	// -------------------------------------------------------------------------

	/**
	 * Evaluate the rule against the current WordPress request.
	 *
	 * @param string $operator  Key from get_operators().
	 * @param mixed  $value     Sanitized stored value.
	 * @return bool  true = condition is met.
	 */
	abstract public function evaluate( string $operator, $value ): bool;

	// -------------------------------------------------------------------------
	// Optional overrides
	// -------------------------------------------------------------------------

	/**
	 * Return false to exclude this rule type from the registry
	 * (e.g. when a required plugin is not active).
	 */
	public static function is_available(): bool {
		return true;
	}

	/**
	 * Validate a rule config array before it is saved.
	 *
	 * @return true|\WP_Error
	 */
	public function validate( array $rule_data ) {
		return true;
	}

	/**
	 * Sanitize the stored value before it is written to the database.
	 * Override for custom sanitization (e.g. absint for numeric values).
	 */
	public function sanitize_value( $value ) {
		if ( is_array( $value ) ) {
			return array_map( 'sanitize_text_field', $value );
		}
		return sanitize_text_field( (string) $value );
	}
}
