<?php
namespace Aepro\Admin\PresetRules\Rules;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Current_Term_Rule extends Rule_Base {

	public function get_id(): string {
		return 'current_term';
	}

	public function get_label(): string {
		return __( 'Current Term', 'ae-pro' );
	}

	public function get_category(): string {
		return __( 'Taxonomy', 'ae-pro' );
	}

	public function get_operators(): array {
		return [
			'is'     => __( 'Is', 'ae-pro' ),
			'is_not' => __( 'Is Not', 'ae-pro' ),
		];
	}

	public function get_fields(): array {
		return [
			[
				'type'        => 'text',
				'name'        => 'value',
				'label'       => __( 'Term ID or Slug', 'ae-pro' ),
				'placeholder' => __( 'e.g. 12 or news', 'ae-pro' ),
			],
		];
	}

	public function evaluate( string $operator, $value ): bool {
		if ( ! is_tax() && ! is_category() && ! is_tag() ) {
			return false;
		}
		$term = get_queried_object();
		if ( ! $term instanceof \WP_Term ) {
			return false;
		}
		$compare = trim( (string) $value );
		$matches = is_numeric( $compare )
			? $term->term_id === absint( $compare )
			: $term->slug    === sanitize_title( $compare );
		return 'is_not' === $operator ? ! $matches : $matches;
	}
}
