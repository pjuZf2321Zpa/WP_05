<?php
namespace Aepro\Admin\PresetRules\Rules;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Parent_Term_Rule extends Rule_Base {

	public function get_id(): string {
		return 'parent_term';
	}

	public function get_label(): string {
		return __( 'Parent Term', 'ae-pro' );
	}

	public function get_category(): string {
		return __( 'Taxonomy', 'ae-pro' );
	}

	public function get_operators(): array {
		return [
			'is'     => __( 'Is', 'ae-pro' ),
			'is_not' => __( 'Is Not', 'ae-pro' ),
		];
	}

	public function get_fields(): array {
		return [
			[
				'type'        => 'text',
				'name'        => 'value',
				'label'       => __( 'Parent Term ID', 'ae-pro' ),
				'placeholder' => __( 'e.g. 5', 'ae-pro' ),
			],
		];
	}

	public function sanitize_value( $value ) {
		return absint( $value );
	}

	public function evaluate( string $operator, $value ): bool {
		if ( ! is_tax() && ! is_category() && ! is_tag() ) {
			return false;
		}
		$term = get_queried_object();
		if ( ! $term instanceof \WP_Term ) {
			return false;
		}
		$parent_id = absint( $value );
		$matches   = $parent_id > 0 && absint( $term->parent ) === $parent_id;
		return 'is_not' === $operator ? ! $matches : $matches;
	}
}
