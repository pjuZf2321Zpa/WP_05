<?php
namespace Aepro\Admin\PresetRules\Rules;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Category_Rule extends Rule_Base {

	public function get_id(): string {
		return 'category';
	}

	public function get_label(): string {
		return __( 'Category', 'ae-pro' );
	}

	public function get_category(): string {
		return __( 'Taxonomy', 'ae-pro' );
	}

	public function get_operators(): array {
		return [
			'in'     => __( 'In', 'ae-pro' ),
			'not_in' => __( 'Not In', 'ae-pro' ),
		];
	}

	public function get_fields(): array {
		return [
			[
				'type'        => 'text',
				'name'        => 'value',
				'label'       => __( 'Category ID(s) or Slug(s)', 'ae-pro' ),
				'placeholder' => __( 'e.g. news, 5, 10', 'ae-pro' ),
			],
		];
	}

	public function evaluate( string $operator, $value ): bool {
		if ( ! is_singular() ) {
			return false;
		}
		$post = get_queried_object();
		if ( ! $post instanceof \WP_Post ) {
			return false;
		}
		$items   = array_filter( array_map( 'trim', explode( ',', (string) $value ) ) );
		$matches = false;
		foreach ( $items as $item ) {
			if ( has_category( is_numeric( $item ) ? absint( $item ) : sanitize_title( $item ), $post ) ) {
				$matches = true;
				break;
			}
		}
		return 'not_in' === $operator ? ! $matches : $matches;
	}
}
