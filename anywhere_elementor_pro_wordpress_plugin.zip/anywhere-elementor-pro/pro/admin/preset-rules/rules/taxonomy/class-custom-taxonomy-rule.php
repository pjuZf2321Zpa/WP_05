<?php
namespace Aepro\Admin\PresetRules\Rules;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Custom_Taxonomy_Rule extends Rule_Base {

	public function get_id(): string {
		return 'custom_taxonomy';
	}

	public function get_label(): string {
		return __( 'Custom Taxonomy', 'ae-pro' );
	}

	public function get_category(): string {
		return __( 'Taxonomy', 'ae-pro' );
	}

	public function get_operators(): array {
		return [
			'in'     => __( 'In', 'ae-pro' ),
			'not_in' => __( 'Not In', 'ae-pro' ),
		];
	}

	public function get_fields(): array {
		return [
			[
				'type'        => 'text',
				'name'        => 'taxonomy',
				'label'       => __( 'Taxonomy Slug', 'ae-pro' ),
				'placeholder' => __( 'e.g. genre', 'ae-pro' ),
			],
			[
				'type'        => 'text',
				'name'        => 'value',
				'label'       => __( 'Term ID(s) or Slug(s)', 'ae-pro' ),
				'placeholder' => __( 'e.g. drama, 4, 9', 'ae-pro' ),
			],
		];
	}

	public function sanitize_value( $value ) {
		if ( is_array( $value ) ) {
			return [
				'taxonomy' => sanitize_key( $value['taxonomy'] ?? '' ),
				'value'    => sanitize_text_field( $value['value'] ?? '' ),
			];
		}
		return sanitize_text_field( (string) $value );
	}

	public function evaluate( string $operator, $value ): bool {
		if ( ! is_singular() ) {
			return false;
		}
		$post = get_queried_object();
		if ( ! $post instanceof \WP_Post ) {
			return false;
		}

		$taxonomy = '';
		$terms    = '';
		if ( is_array( $value ) ) {
			$taxonomy = sanitize_key( $value['taxonomy'] ?? '' );
			$terms    = sanitize_text_field( $value['value'] ?? '' );
		}

		if ( empty( $taxonomy ) || ! taxonomy_exists( $taxonomy ) ) {
			return false;
		}

		$items   = array_filter( array_map( 'trim', explode( ',', $terms ) ) );
		$matches = false;
		foreach ( $items as $item ) {
			if ( has_term( is_numeric( $item ) ? absint( $item ) : sanitize_title( $item ), $taxonomy, $post ) ) {
				$matches = true;
				break;
			}
		}
		return 'not_in' === $operator ? ! $matches : $matches;
	}
}
