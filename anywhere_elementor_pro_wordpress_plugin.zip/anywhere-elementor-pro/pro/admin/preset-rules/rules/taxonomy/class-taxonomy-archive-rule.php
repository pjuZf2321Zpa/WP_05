<?php
namespace Aepro\Admin\PresetRules\Rules;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Taxonomy_Archive_Rule extends Rule_Base {

	public function get_id(): string {
		return 'taxonomy_archive';
	}

	public function get_label(): string {
		return __( 'Current Taxonomy Archive', 'ae-pro' );
	}

	public function get_category(): string {
		return __( 'Taxonomy', 'ae-pro' );
	}

	public function get_operators(): array {
		return [
			'is'     => __( 'Is Any Of', 'ae-pro' ),
			'is_not' => __( 'Is None Of', 'ae-pro' ),
		];
	}

	public function get_fields(): array {
		$taxonomies = get_taxonomies( [ 'public' => true ], 'objects' );
		$options    = [];
		foreach ( $taxonomies as $tax ) {
			$options[ $tax->name ] = $tax->label;
		}
		return [
			[
				'type'    => 'multiselect',
				'name'    => 'value',
				'label'   => __( 'Taxonomy', 'ae-pro' ),
				'options' => $options,
			],
		];
	}

	public function sanitize_value( $value ) {
		if ( is_array( $value ) ) {
			return array_values( array_filter( array_map( 'sanitize_key', $value ) ) );
		}
		$single = sanitize_key( (string) $value );
		return $single !== '' ? [ $single ] : [];
	}

	public function evaluate( string $operator, $value ): bool {
		$values = is_array( $value )
			? array_values( array_filter( $value ) )
			: ( (string) $value !== '' ? [ (string) $value ] : [] );

		// Empty selection = match any taxonomy archive (backward compat).
		if ( empty( $values ) ) {
			$matches = is_tax() || is_category() || is_tag();
			return 'is_not' === $operator ? ! $matches : $matches;
		}

		$matches = false;
		foreach ( $values as $tax ) {
			if ( 'category' === $tax ) {
				if ( is_category() ) { $matches = true; break; }
			} elseif ( 'post_tag' === $tax ) {
				if ( is_tag() ) { $matches = true; break; }
			} else {
				if ( is_tax( $tax ) ) { $matches = true; break; }
			}
		}

		return 'is_not' === $operator ? ! $matches : $matches;
	}
}
