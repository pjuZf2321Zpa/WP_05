<?php
namespace Aepro\Admin\PresetRules\Rules;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Specific_User_Rule extends Rule_Base {

	public function get_id(): string {
		return 'specific_user';
	}

	public function get_label(): string {
		return __( 'Specific User', 'ae-pro' );
	}

	public function get_category(): string {
		return __( 'User', 'ae-pro' );
	}

	public function get_operators(): array {
		return [
			'is'     => __( 'Is', 'ae-pro' ),
			'is_not' => __( 'Is Not', 'ae-pro' ),
		];
	}

	public function get_fields(): array {
		return [
			[
				'type'        => 'text',
				'name'        => 'value',
				'label'       => __( 'Username / Login', 'ae-pro' ),
				'placeholder' => __( 'e.g. john_doe', 'ae-pro' ),
			],
		];
	}

	public function evaluate( string $operator, $value ): bool {
		$current = wp_get_current_user();
		if ( ! $current->exists() ) {
			return 'is_not' === $operator;
		}
		$login   = sanitize_user( (string) $value );
		$matches = $current->user_login === $login;
		return 'is_not' === $operator ? ! $matches : $matches;
	}
}
