<?php
namespace Aepro\Admin\PresetRules\Rules;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class User_Role_Rule extends Rule_Base {

	public function get_id(): string {
		return 'user_role';
	}

	public function get_label(): string {
		return __( 'User Role', 'ae-pro' );
	}

	public function get_category(): string {
		return __( 'User', 'ae-pro' );
	}

	public function get_operators(): array {
		return [
			'is'     => __( 'Is', 'ae-pro' ),
			'is_not' => __( 'Is Not', 'ae-pro' ),
		];
	}

	public function get_fields(): array {
		$roles   = wp_roles()->roles;
		$options = [];
		foreach ( $roles as $key => $role ) {
			$options[ $key ] = translate_user_role( $role['name'] );
		}
		return [
			[
				'type'    => 'select',
				'name'    => 'value',
				'label'   => __( 'Role', 'ae-pro' ),
				'options' => $options,
			],
		];
	}

	public function evaluate( string $operator, $value ): bool {
		$user    = wp_get_current_user();
		$matches = $user->exists() && in_array( (string) $value, (array) $user->roles, true );
		return 'is_not' === $operator ? ! $matches : $matches;
	}
}
