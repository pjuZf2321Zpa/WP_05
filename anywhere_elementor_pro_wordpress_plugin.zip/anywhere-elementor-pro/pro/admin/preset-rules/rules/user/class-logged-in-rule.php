<?php
namespace Aepro\Admin\PresetRules\Rules;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Logged_In_Rule extends Rule_Base {

	public function get_id(): string {
		return 'logged_in';
	}

	public function get_label(): string {
		return __( 'Login Status', 'ae-pro' );
	}

	public function get_category(): string {
		return __( 'User', 'ae-pro' );
	}

	public function get_operators(): array {
		return [
			'is'     => __( 'Is', 'ae-pro' ),
			'is_not' => __( 'Is Not', 'ae-pro' ),
		];
	}

	public function get_fields(): array {
		return [
			[
				'type'    => 'select',
				'name'    => 'value',
				'label'   => __( 'Status', 'ae-pro' ),
				'options' => [
					'logged_in'  => __( 'Logged In', 'ae-pro' ),
					'logged_out' => __( 'Logged Out', 'ae-pro' ),
				],
			],
		];
	}

	public function evaluate( string $operator, $value ): bool {
		$is_logged_in    = is_user_logged_in();
		$expects_logged  = 'logged_in' === $value;
		$state_matches   = $is_logged_in === $expects_logged;
		return 'is_not' === $operator ? ! $state_matches : $state_matches;
	}
}
