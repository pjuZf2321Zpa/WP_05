<?php
namespace Aepro\Admin\PresetRules\Rules;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class User_Id_Rule extends Rule_Base {

	public function get_id(): string {
		return 'user_id';
	}

	public function get_label(): string {
		return __( 'User ID', 'ae-pro' );
	}

	public function get_category(): string {
		return __( 'User', 'ae-pro' );
	}

	public function get_operators(): array {
		return [
			'is'     => __( 'Is', 'ae-pro' ),
			'is_not' => __( 'Is Not', 'ae-pro' ),
		];
	}

	public function get_fields(): array {
		return [
			[
				'type'        => 'text',
				'name'        => 'value',
				'label'       => __( 'User ID(s)', 'ae-pro' ),
				'placeholder' => __( 'e.g. 1, 5, 12', 'ae-pro' ),
			],
		];
	}

	public function sanitize_value( $value ) {
		return sanitize_text_field( (string) $value );
	}

	public function evaluate( string $operator, $value ): bool {
		$current_id = get_current_user_id();
		if ( ! $current_id ) {
			return 'is_not' === $operator;
		}
		$ids     = array_filter( array_map( 'absint', explode( ',', (string) $value ) ) );
		$matches = in_array( $current_id, $ids, true );
		return 'is_not' === $operator ? ! $matches : $matches;
	}
}
