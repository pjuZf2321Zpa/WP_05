<?php
namespace Aepro\Admin\PresetRules\Rules;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class User_Meta_Rule extends Rule_Base {

	public function get_id(): string {
		return 'user_meta';
	}

	public function get_label(): string {
		return __( 'User Meta', 'ae-pro' );
	}

	public function get_category(): string {
		return __( 'User', 'ae-pro' );
	}

	public function get_operators(): array {
		return [
			'exists'     => __( 'Exists', 'ae-pro' ),
			'not_exists' => __( 'Does Not Exist', 'ae-pro' ),
			'equals'     => __( 'Value Equals', 'ae-pro' ),
			'not_equals' => __( 'Value Does Not Equal', 'ae-pro' ),
			'contains'   => __( 'Value Contains', 'ae-pro' ),
		];
	}

	public function get_fields(): array {
		return [
			[
				'type'        => 'text',
				'name'        => 'meta_key',
				'label'       => __( 'Meta Key', 'ae-pro' ),
				'placeholder' => __( 'e.g. my_field', 'ae-pro' ),
			],
			[
				'type'        => 'text',
				'name'        => 'value',
				'label'       => __( 'Meta Value', 'ae-pro' ),
				'placeholder' => __( 'For Equals / Contains operators', 'ae-pro' ),
			],
		];
	}

	public function sanitize_value( $value ) {
		if ( is_array( $value ) ) {
			return [
				'meta_key' => sanitize_key( $value['meta_key'] ?? '' ),
				'value'    => sanitize_text_field( $value['value'] ?? '' ),
			];
		}
		return sanitize_text_field( (string) $value );
	}

	public function evaluate( string $operator, $value ): bool {
		$user_id = get_current_user_id();
		if ( ! $user_id ) {
			return false;
		}

		$meta_key = '';
		$expected = '';
		if ( is_array( $value ) ) {
			$meta_key = sanitize_key( $value['meta_key'] ?? '' );
			$expected = sanitize_text_field( $value['value'] ?? '' );
		}

		if ( empty( $meta_key ) ) {
			return false;
		}

		$meta_val = get_user_meta( $user_id, $meta_key, true );
		$exists   = '' !== $meta_val && false !== $meta_val;

		switch ( $operator ) {
			case 'exists':
				return $exists;
			case 'not_exists':
				return ! $exists;
			case 'equals':
				return $exists && (string) $meta_val === $expected;
			case 'not_equals':
				return ! $exists || (string) $meta_val !== $expected;
			case 'contains':
				return $exists && str_contains( (string) $meta_val, $expected );
			default:
				return false;
		}
	}
}
