<?php
namespace Aepro\Admin\PresetRules\Rules;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Author_Of_Post_Rule extends Rule_Base {

	public function get_id(): string {
		return 'author_of_post';
	}

	public function get_label(): string {
		return __( 'Author of Current Post', 'ae-pro' );
	}

	public function get_category(): string {
		return __( 'User', 'ae-pro' );
	}

	public function get_operators(): array {
		return [
			'is'     => __( 'Is the Post Author', 'ae-pro' ),
			'is_not' => __( 'Is Not the Post Author', 'ae-pro' ),
		];
	}

	public function get_fields(): array {
		return [];
	}

	public function evaluate( string $operator, $value ): bool {
		$current_id = get_current_user_id();
		if ( ! $current_id || ! is_singular() ) {
			return 'is_not' === $operator;
		}
		$post    = get_queried_object();
		$matches = $post instanceof \WP_Post && absint( $post->post_author ) === $current_id;
		return 'is_not' === $operator ? ! $matches : $matches;
	}
}
