<?php
namespace Aepro\Admin\PresetRules\Rules;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class User_Capability_Rule extends Rule_Base {

	public function get_id(): string {
		return 'user_capability';
	}

	public function get_label(): string {
		return __( 'User Capability', 'ae-pro' );
	}

	public function get_category(): string {
		return __( 'User', 'ae-pro' );
	}

	public function get_operators(): array {
		return [
			'has'     => __( 'Has', 'ae-pro' ),
			'has_not' => __( 'Does Not Have', 'ae-pro' ),
		];
	}

	public function get_fields(): array {
		return [
			[
				'type'        => 'text',
				'name'        => 'value',
				'label'       => __( 'Capability', 'ae-pro' ),
				'placeholder' => __( 'e.g. manage_options', 'ae-pro' ),
			],
		];
	}

	public function evaluate( string $operator, $value ): bool {
		$cap     = sanitize_key( (string) $value );
		$matches = ! empty( $cap ) && current_user_can( $cap );
		return 'has_not' === $operator ? ! $matches : $matches;
	}
}
