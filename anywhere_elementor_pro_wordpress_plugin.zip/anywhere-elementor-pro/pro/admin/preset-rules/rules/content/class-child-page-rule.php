<?php
namespace Aepro\Admin\PresetRules\Rules;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Child_Page_Rule extends Rule_Base {

	public function get_id(): string {
		return 'child_page';
	}

	public function get_label(): string {
		return __( 'Child Page', 'ae-pro' );
	}

	public function get_category(): string {
		return __( 'Content', 'ae-pro' );
	}

	public function get_operators(): array {
		return [
			'is'     => __( 'Is a Child Page', 'ae-pro' ),
			'is_not' => __( 'Is Not a Child Page', 'ae-pro' ),
		];
	}

	public function get_fields(): array {
		return [];
	}

	public function evaluate( string $operator, $value ): bool {
		if ( ! is_singular() ) {
			return false;
		}
		$post    = get_queried_object();
		$matches = $post instanceof \WP_Post && absint( $post->post_parent ) > 0;
		return 'is_not' === $operator ? ! $matches : $matches;
	}
}
