<?php
namespace Aepro\Admin\PresetRules\Rules;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Current_Post_Rule extends Rule_Base {

	public function get_id(): string {
		return 'current_post';
	}

	public function get_label(): string {
		return __( 'Current Post', 'ae-pro' );
	}

	public function get_category(): string {
		return __( 'Content', 'ae-pro' );
	}

	public function get_operators(): array {
		return [
			'is'     => __( 'Is', 'ae-pro' ),
			'is_not' => __( 'Is Not', 'ae-pro' ),
		];
	}

	public function get_fields(): array {
		return [
			[
				'type'        => 'text',
				'name'        => 'value',
				'label'       => __( 'Post ID(s)', 'ae-pro' ),
				'placeholder' => __( 'e.g. 3, 7, 15', 'ae-pro' ),
			],
		];
	}

	public function evaluate( string $operator, $value ): bool {
		if ( ! is_singular( 'post' ) ) {
			return 'is_not' === $operator;
		}
		$post = get_queried_object();
		if ( ! $post instanceof \WP_Post ) {
			return false;
		}
		$ids     = array_filter( array_map( 'absint', explode( ',', (string) $value ) ) );
		$matches = in_array( $post->ID, $ids, true );
		return 'is_not' === $operator ? ! $matches : $matches;
	}
}
