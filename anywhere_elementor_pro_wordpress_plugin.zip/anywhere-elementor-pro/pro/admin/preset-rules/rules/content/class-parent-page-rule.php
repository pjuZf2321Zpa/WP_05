<?php
namespace Aepro\Admin\PresetRules\Rules;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Parent_Page_Rule extends Rule_Base {

	public function get_id(): string {
		return 'parent_page';
	}

	public function get_label(): string {
		return __( 'Parent Page', 'ae-pro' );
	}

	public function get_category(): string {
		return __( 'Content', 'ae-pro' );
	}

	public function get_operators(): array {
		return [
			'is'     => __( 'Is', 'ae-pro' ),
			'is_not' => __( 'Is Not', 'ae-pro' ),
		];
	}

	public function get_fields(): array {
		return [
			[
				'type'        => 'text',
				'name'        => 'value',
				'label'       => __( 'Parent Page ID', 'ae-pro' ),
				'placeholder' => __( 'e.g. 42', 'ae-pro' ),
			],
		];
	}

	public function sanitize_value( $value ) {
		return absint( $value );
	}

	public function evaluate( string $operator, $value ): bool {
		if ( ! is_singular() ) {
			return false;
		}
		$post = get_queried_object();
		if ( ! $post instanceof \WP_Post ) {
			return false;
		}
		$parent_id = absint( $value );
		$matches   = absint( $post->post_parent ) === $parent_id && $parent_id > 0;
		return 'is_not' === $operator ? ! $matches : $matches;
	}
}
