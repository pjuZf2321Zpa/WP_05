<?php
namespace Aepro\Admin\PresetRules\Rules;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Sticky_Post_Rule extends Rule_Base {

	public function get_id(): string {
		return 'sticky_post';
	}

	public function get_label(): string {
		return __( 'Sticky Post', 'ae-pro' );
	}

	public function get_category(): string {
		return __( 'Content', 'ae-pro' );
	}

	public function get_operators(): array {
		return [
			'is'     => __( 'Is Sticky', 'ae-pro' ),
			'is_not' => __( 'Is Not Sticky', 'ae-pro' ),
		];
	}

	public function get_fields(): array {
		return [];
	}

	public function evaluate( string $operator, $value ): bool {
		if ( ! is_singular() ) {
			return false;
		}
		$post    = get_queried_object();
		$matches = $post instanceof \WP_Post && is_sticky( $post->ID );
		return 'is_not' === $operator ? ! $matches : $matches;
	}
}
