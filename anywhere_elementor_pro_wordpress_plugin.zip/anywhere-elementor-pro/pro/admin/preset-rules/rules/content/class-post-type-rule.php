<?php
namespace Aepro\Admin\PresetRules\Rules;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Post_Type_Rule extends Rule_Base {

	public function get_id(): string {
		return 'post_type';
	}

	public function get_label(): string {
		return __( 'Post Type', 'ae-pro' );
	}

	public function get_category(): string {
		return __( 'Content', 'ae-pro' );
	}

	public function get_operators(): array {
		return [
			'is'     => __( 'Is Any Of', 'ae-pro' ),
			'is_not' => __( 'Is None Of', 'ae-pro' ),
		];
	}

	public function get_fields(): array {
		$post_types = get_post_types( [ 'public' => true ], 'objects' );
		$options    = [];
		foreach ( $post_types as $pt ) {
			$options[ $pt->name ] = sprintf( '%s (%s)', $pt->labels->singular_name, $pt->name );
		}
		return [
			[
				'type'    => 'multiselect',
				'name'    => 'value',
				'label'   => __( 'Post Type', 'ae-pro' ),
				'options' => $options,
			],
		];
	}

	public function sanitize_value( $value ) {
		if ( is_array( $value ) ) {
			return array_values( array_filter( array_map( 'sanitize_key', $value ) ) );
		}
		$single = sanitize_key( (string) $value );
		return $single !== '' ? [ $single ] : [];
	}

	public function evaluate( string $operator, $value ): bool {
		$values = is_array( $value )
			? array_values( array_filter( $value ) )
			: ( (string) $value !== '' ? [ (string) $value ] : [] );

		if ( empty( $values ) ) {
			return 'is_not' === $operator;
		}

		if ( is_singular() ) {
			$current = get_post_type();
		} else {
			$queried = get_queried_object();
			$current = $queried instanceof \WP_Post_Type ? $queried->name : '';
		}

		$matches = in_array( $current, $values, true );
		return 'is_not' === $operator ? ! $matches : $matches;
	}
}
