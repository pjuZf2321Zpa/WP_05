<?php
namespace Aepro\Admin\PresetRules\Rules;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Featured_Post_Rule extends Rule_Base {

	public function get_id(): string {
		return 'featured_post';
	}

	public function get_label(): string {
		return __( 'Featured Image', 'ae-pro' );
	}

	public function get_category(): string {
		return __( 'Content', 'ae-pro' );
	}

	public function get_operators(): array {
		return [
			'has'     => __( 'Has Featured Image', 'ae-pro' ),
			'has_not' => __( 'Has No Featured Image', 'ae-pro' ),
		];
	}

	public function get_fields(): array {
		return [];
	}

	public function evaluate( string $operator, $value ): bool {
		if ( ! is_singular() ) {
			return false;
		}
		$post    = get_queried_object();
		$matches = $post instanceof \WP_Post && has_post_thumbnail( $post->ID );
		return 'has_not' === $operator ? ! $matches : $matches;
	}
}
