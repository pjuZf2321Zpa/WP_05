<?php
namespace Aepro\Admin\PresetRules\Rules;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Post_Slug_Rule extends Rule_Base {

	public function get_id(): string {
		return 'post_slug';
	}

	public function get_label(): string {
		return __( 'Post Slug', 'ae-pro' );
	}

	public function get_category(): string {
		return __( 'Content', 'ae-pro' );
	}

	public function get_operators(): array {
		return [
			'is'       => __( 'Is', 'ae-pro' ),
			'is_not'   => __( 'Is Not', 'ae-pro' ),
			'contains' => __( 'Contains', 'ae-pro' ),
		];
	}

	public function get_fields(): array {
		return [
			[
				'type'        => 'text',
				'name'        => 'value',
				'label'       => __( 'Slug', 'ae-pro' ),
				'placeholder' => __( 'e.g. my-post', 'ae-pro' ),
			],
		];
	}

	public function evaluate( string $operator, $value ): bool {
		if ( ! is_singular() ) {
			return false;
		}
		$post = get_queried_object();
		if ( ! $post instanceof \WP_Post ) {
			return false;
		}
		$slug    = $post->post_name;
		$compare = sanitize_title( (string) $value );

		switch ( $operator ) {
			case 'is':
				return $slug === $compare;
			case 'is_not':
				return $slug !== $compare;
			case 'contains':
				return str_contains( $slug, $compare );
			default:
				return false;
		}
	}
}
