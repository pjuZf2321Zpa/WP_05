<?php
namespace Aepro\Admin\PresetRules\Rules;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Post_Id_Rule extends Rule_Base {

	public function get_id(): string {
		return 'post_id';
	}

	public function get_label(): string {
		return __( 'Post ID', 'ae-pro' );
	}

	public function get_category(): string {
		return __( 'Content', 'ae-pro' );
	}

	public function get_operators(): array {
		return [
			'is'     => __( 'Is', 'ae-pro' ),
			'is_not' => __( 'Is Not', 'ae-pro' ),
		];
	}

	public function get_fields(): array {
		return [
			[
				'type'        => 'text',
				'name'        => 'value',
				'label'       => __( 'Post ID(s)', 'ae-pro' ),
				'placeholder' => __( 'e.g. 42, 57, 91', 'ae-pro' ),
			],
		];
	}

	public function sanitize_value( $value ) {
		$ids = array_filter( array_map( 'absint', explode( ',', (string) $value ) ) );
		return implode( ',', $ids );
	}

	public function evaluate( string $operator, $value ): bool {
		$current = (int) get_the_ID();
		$ids     = array_filter( array_map( 'absint', explode( ',', (string) $value ) ) );
		$matches = $current > 0 && in_array( $current, $ids, true );
		return 'is_not' === $operator ? ! $matches : $matches;
	}
}
