<?php
namespace Aepro\Admin\PresetRules\Rules;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Page_Template_Rule extends Rule_Base {

	public function get_id(): string {
		return 'page_template';
	}

	public function get_label(): string {
		return __( 'Page Template', 'ae-pro' );
	}

	public function get_category(): string {
		return __( 'Content', 'ae-pro' );
	}

	public function get_operators(): array {
		return [
			'is'     => __( 'Is', 'ae-pro' ),
			'is_not' => __( 'Is Not', 'ae-pro' ),
		];
	}

	public function get_fields(): array {
		// Build options from all templates registered by the active theme.
		$templates = get_page_templates();
		$options   = [ '' => __( '— Default Template —', 'ae-pro' ) ];
		foreach ( $templates as $name => $file ) {
			$options[ $file ] = $name;
		}
		return [
			[
				'type'    => 'select',
				'name'    => 'value',
				'label'   => __( 'Template', 'ae-pro' ),
				'options' => $options,
			],
		];
	}

	public function evaluate( string $operator, $value ): bool {
		if ( ! is_singular() ) {
			return false;
		}

		$template = sanitize_text_field( (string) $value );

		// Empty value means "Default Template" (no custom template set).
		$matches = '' === $template
			? ! is_page_template()
			: is_page_template( $template );

		return 'is_not' === $operator ? ! $matches : $matches;
	}
}
