<?php
namespace Aepro\Admin\PresetRules\Rules;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Author_Archive_Rule extends Rule_Base {

	public function get_id(): string {
		return 'author_archive';
	}

	public function get_label(): string {
		return __( 'Author Archive', 'ae-pro' );
	}

	public function get_category(): string {
		return __( 'Author', 'ae-pro' );
	}

	public function get_operators(): array {
		return [
			'is'     => __( 'Is an Author Archive', 'ae-pro' ),
			'is_not' => __( 'Is Not an Author Archive', 'ae-pro' ),
		];
	}

	public function get_fields(): array {
		return [];
	}

	public function evaluate( string $operator, $value ): bool {
		$matches = is_author();
		return 'is_not' === $operator ? ! $matches : $matches;
	}
}
