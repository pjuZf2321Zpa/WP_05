<?php
namespace Aepro\Admin\PresetRules\Rules;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Specific_Author_Rule extends Rule_Base {

	public function get_id(): string {
		return 'specific_author';
	}

	public function get_label(): string {
		return __( 'Specific Author', 'ae-pro' );
	}

	public function get_category(): string {
		return __( 'Author', 'ae-pro' );
	}

	public function get_operators(): array {
		return [
			'is'     => __( 'Is', 'ae-pro' ),
			'is_not' => __( 'Is Not', 'ae-pro' ),
		];
	}

	public function get_fields(): array {
		return [
			[
				'type'        => 'text',
				'name'        => 'value',
				'label'       => __( 'Author ID or Username', 'ae-pro' ),
				'placeholder' => __( 'e.g. 3 or jane_doe', 'ae-pro' ),
			],
		];
	}

	public function evaluate( string $operator, $value ): bool {
		$compare = trim( (string) $value );
		if ( '' === $compare ) {
			return false;
		}

		// Resolve to user ID.
		if ( is_numeric( $compare ) ) {
			$target_id = absint( $compare );
		} else {
			$user = get_user_by( 'login', sanitize_user( $compare ) );
			if ( ! $user ) {
				return false;
			}
			$target_id = $user->ID;
		}

		// On singular posts check the post author.
		if ( is_singular() ) {
			$post    = get_queried_object();
			$matches = $post instanceof \WP_Post && absint( $post->post_author ) === $target_id;
			return 'is_not' === $operator ? ! $matches : $matches;
		}

		// On author archives check the queried author.
		if ( is_author() ) {
			$author  = get_queried_object();
			$matches = $author instanceof \WP_User && $author->ID === $target_id;
			return 'is_not' === $operator ? ! $matches : $matches;
		}

		return 'is_not' === $operator;
	}
}
