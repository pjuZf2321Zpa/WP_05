<?php
namespace Aepro\Admin\PresetRules\Rules;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Current_Author_Rule extends Rule_Base {

	public function get_id(): string {
		return 'current_author';
	}

	public function get_label(): string {
		return __( 'Current Author (logged-in user)', 'ae-pro' );
	}

	public function get_category(): string {
		return __( 'Author', 'ae-pro' );
	}

	public function get_operators(): array {
		return [
			'is'     => __( 'Is the Author', 'ae-pro' ),
			'is_not' => __( 'Is Not the Author', 'ae-pro' ),
		];
	}

	public function get_fields(): array {
		return [];
	}

	public function evaluate( string $operator, $value ): bool {
		$current_id = get_current_user_id();
		if ( ! $current_id ) {
			return 'is_not' === $operator;
		}

		// Singular: compare current user to post author.
		if ( is_singular() ) {
			$post    = get_queried_object();
			$matches = $post instanceof \WP_Post && absint( $post->post_author ) === $current_id;
			return 'is_not' === $operator ? ! $matches : $matches;
		}

		// Author archive: compare current user to queried author.
		if ( is_author() ) {
			$author  = get_queried_object();
			$matches = $author instanceof \WP_User && $author->ID === $current_id;
			return 'is_not' === $operator ? ! $matches : $matches;
		}

		return 'is_not' === $operator;
	}
}
