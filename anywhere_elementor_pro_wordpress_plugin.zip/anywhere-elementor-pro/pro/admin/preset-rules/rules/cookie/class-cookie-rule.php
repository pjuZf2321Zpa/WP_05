<?php
namespace Aepro\Admin\PresetRules\Rules;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Cookie_Rule extends Rule_Base {

	public function get_id(): string {
		return 'cookie';
	}

	public function get_label(): string {
		return __( 'Cookie', 'ae-pro' );
	}

	public function get_category(): string {
		return __( 'Cookie / Session', 'ae-pro' );
	}

	public function get_operators(): array {
		return [
			'exists'     => __( 'Exists', 'ae-pro' ),
			'not_exists' => __( 'Does Not Exist', 'ae-pro' ),
			'equals'     => __( 'Value Equals', 'ae-pro' ),
			'not_equals' => __( 'Value Does Not Equal', 'ae-pro' ),
			'contains'   => __( 'Value Contains', 'ae-pro' ),
		];
	}

	public function get_fields(): array {
		return [
			[
				'type'        => 'text',
				'name'        => 'cookie_name',
				'label'       => __( 'Cookie Name', 'ae-pro' ),
				'placeholder' => __( 'e.g. my_cookie', 'ae-pro' ),
			],
			[
				'type'        => 'text',
				'name'        => 'value',
				'label'       => __( 'Cookie Value', 'ae-pro' ),
				'placeholder' => __( 'For Equals / Contains operators', 'ae-pro' ),
			],
		];
	}

	public function sanitize_value( $value ) {
		if ( is_array( $value ) ) {
			return [
				'cookie_name' => sanitize_key( $value['cookie_name'] ?? '' ),
				'value'       => sanitize_text_field( $value['value'] ?? '' ),
			];
		}
		return sanitize_text_field( (string) $value );
	}

	public function evaluate( string $operator, $value ): bool {
		$name  = '';
		$cval  = '';
		if ( is_array( $value ) ) {
			$name = sanitize_key( $value['cookie_name'] ?? '' );
			$cval = sanitize_text_field( $value['value'] ?? '' );
		}

		if ( empty( $name ) ) {
			return false;
		}

		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$cookie_raw   = isset( $_COOKIE[ $name ] ) ? sanitize_text_field( wp_unslash( (string) $_COOKIE[ $name ] ) ) : null;
		$cookie_exists = null !== $cookie_raw;

		switch ( $operator ) {
			case 'exists':
				return $cookie_exists;
			case 'not_exists':
				return ! $cookie_exists;
			case 'equals':
				return $cookie_exists && $cookie_raw === $cval;
			case 'not_equals':
				return ! $cookie_exists || $cookie_raw !== $cval;
			case 'contains':
				return $cookie_exists && str_contains( $cookie_raw, $cval );
			default:
				return false;
		}
	}
}
