<?php
namespace Aepro\Admin\PresetRules;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Aepro\Admin\PresetRules\Rules\{
	Acf_Text_Rule,
	Acf_Choice_Rule,
	Acf_True_False_Rule,
	Acf_Post_Rule,
	Acf_Taxonomy_Rule,
	Acf_Date_Time_Rule,
	Acf_Image_Rule,
	Acf_Relationship_Rule,
	Logged_In_Rule,
	User_Role_Rule,
	User_Capability_Rule,
	Specific_User_Rule,
	User_Id_Rule,
	Author_Of_Post_Rule,
	User_Meta_Rule,
	Post_Type_Rule,
	Post_Id_Rule,
	Page_Template_Rule,
	Post_Meta_Rule,
	Post_Slug_Rule,
	Parent_Page_Rule,
	Child_Page_Rule,
	Current_Page_Rule,
	Current_Post_Rule,
	Sticky_Post_Rule,
	Featured_Post_Rule,
	Singular_Rule,
	Archive_Rule,
	Search_Rule,
	Rule_404,
	Front_Page_Rule,
	Category_Rule,
	Tag_Rule,
	Custom_Taxonomy_Rule,
	Taxonomy_Archive_Rule,
	Current_Term_Rule,
	Parent_Term_Rule,
	Term_Meta_Rule,
	Author_Archive_Rule,
	Specific_Author_Rule,
	Current_Author_Rule,
	Device_Rule,
	Cookie_Rule,
	Url_Contains_Rule,
	Query_String_Rule,
	Day_Of_Week_Rule,
	Date_Rule,
	Day_Rule,
	Month_Rule,
	Year_Rule,
	Time_Range_Rule,
	Business_Hours_Rule,
	Scheduled_Rule
};

/**
 * Bootstrap class for the Preset Rules feature.
 * Instantiated once in pro/aepro.php via plugins_loaded.
 */
class Module {

	private static ?self $_instance = null;

	public static function instance(): self {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	private function __construct() {
		// CPT must be registered on every request (front + admin).
		Cpt::instance();

		// Register built-in rule types.
		add_action( 'init', [ $this, 'register_rules' ], 5 );

		if ( is_admin() ) {
			Admin_Page::instance();
			Ajax::instance();
		}
	}

	// -------------------------------------------------------------------------
	// Rule registration
	// -------------------------------------------------------------------------

	public function register_rules(): void {
		$registry = Rule_Registry::instance();

		// User rules.
		$registry->register( new Logged_In_Rule() );
		$registry->register( new User_Role_Rule() );
		$registry->register( new User_Capability_Rule() );
		$registry->register( new Specific_User_Rule() );
		$registry->register( new User_Id_Rule() );
		$registry->register( new Author_Of_Post_Rule() );
		$registry->register( new User_Meta_Rule() );

		// Content rules.
		$registry->register( new Post_Type_Rule() );
		$registry->register( new Post_Id_Rule() );
		$registry->register( new Post_Slug_Rule() );
		$registry->register( new Post_Meta_Rule() );
		$registry->register( new Page_Template_Rule() );
		$registry->register( new Parent_Page_Rule() );
		$registry->register( new Child_Page_Rule() );
		$registry->register( new Current_Page_Rule() );
		$registry->register( new Current_Post_Rule() );
		$registry->register( new Sticky_Post_Rule() );
		$registry->register( new Featured_Post_Rule() );

		// Query context rules.
		$registry->register( new Singular_Rule() );
		$registry->register( new Archive_Rule() );
		$registry->register( new Search_Rule() );
		$registry->register( new Rule_404() );
		$registry->register( new Front_Page_Rule() );

		// Taxonomy rules.
		$registry->register( new Category_Rule() );
		$registry->register( new Tag_Rule() );
		$registry->register( new Custom_Taxonomy_Rule() );
		$registry->register( new Taxonomy_Archive_Rule() );
		$registry->register( new Current_Term_Rule() );
		$registry->register( new Parent_Term_Rule() );
		$registry->register( new Term_Meta_Rule() );

		// Author rules.
		$registry->register( new Author_Archive_Rule() );
		$registry->register( new Specific_Author_Rule() );
		$registry->register( new Current_Author_Rule() );

		// Device rules.
		$registry->register( new Device_Rule() );

		// Date & time rules.
		$registry->register( new Day_Of_Week_Rule() );
		$registry->register( new Date_Rule() );
		$registry->register( new Day_Rule() );
		$registry->register( new Month_Rule() );
		$registry->register( new Year_Rule() );
		$registry->register( new Time_Range_Rule() );
		$registry->register( new Business_Hours_Rule() );
		$registry->register( new Scheduled_Rule() );

		// Cookie / Session rules.
		$registry->register( new Cookie_Rule() );

		// URL rules.
		$registry->register( new Url_Contains_Rule() );
		$registry->register( new Query_String_Rule() );

		// ACF rules — only registered when ACF (free or pro) is active.
		if ( Acf_Text_Rule::is_available() ) {
			$registry->register( new Acf_Text_Rule() );
			$registry->register( new Acf_Choice_Rule() );
			$registry->register( new Acf_True_False_Rule() );
			$registry->register( new Acf_Post_Rule() );
			$registry->register( new Acf_Taxonomy_Rule() );
			$registry->register( new Acf_Date_Time_Rule() );
			$registry->register( new Acf_Image_Rule() );
			$registry->register( new Acf_Relationship_Rule() );
		}

		/**
		 * Third-party hook — register additional rule types here.
		 *
		 * @param Rule_Registry $registry
		 */
		do_action( 'aepro/preset-rules/registry/init', $registry );
	}
}
