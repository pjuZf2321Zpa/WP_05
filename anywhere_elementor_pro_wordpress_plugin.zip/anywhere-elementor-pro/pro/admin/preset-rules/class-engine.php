<?php
namespace Aepro\Admin\PresetRules;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Evaluates a Preset Rule and returns whether the conditions matched.
 *
 * Returns true  → rules matched.
 * Returns false → rules did not match.
 * Returns null  → preset not found or inactive; caller should fall through.
 *
 * Show/Hide, Render HTML, and Fallback are handled by the Dynamic Rules
 * Elementor controls — the Engine only answers "did the rules match?".
 *
 * No caching: all rules evaluate live on every request.
 */
class Engine {

	private static ?self $_instance = null;

	public static function instance(): self {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	private function __construct() {}

	public function evaluate( int $preset_id ): ?bool {
		if ( ! Registry::instance()->preset_exists( $preset_id ) ) {
			return null;
		}

		$config = Registry::instance()->get_config( $preset_id );

		// Allow third parties to short-circuit the entire evaluation.
		$override = apply_filters( 'aepro/preset-rules/evaluate/override', null, $preset_id, $config );
		if ( null !== $override ) {
			return (bool) $override;
		}

		$relation = isset( $config['relation'] ) && 'OR' === $config['relation'] ? 'OR' : 'AND';
		$rules    = is_array( $config['rules'] ?? null ) ? $config['rules'] : [];

		// No rules → always match.
		if ( empty( $rules ) ) {
			return true;
		}

		$registry = Rule_Registry::instance();
		$results  = [];

		foreach ( $rules as $rule_data ) {
			if ( ! is_array( $rule_data ) ) {
				continue;
			}

			$type     = sanitize_key( $rule_data['type']     ?? '' );
			$operator = sanitize_key( $rule_data['operator'] ?? '' );
			$value    = $rule_data['value'] ?? '';

			$rule_obj = $registry->get( $type );
			if ( ! $rule_obj ) {
				continue;
			}

			$result = $rule_obj->evaluate( $operator, $value );

			// Allow per-rule override.
			$result = apply_filters( "aepro/preset-rules/rule_result/{$type}", $result, $rule_data, $preset_id );

			$results[] = (bool) $result;
		}

		if ( empty( $results ) ) {
			return true;
		}

		return 'OR' === $relation
			? in_array( true,  $results, true )
			: ! in_array( false, $results, true );
	}
}
