<?php
namespace Aepro\Admin\PresetRules;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Ajax {

	private static ?self $_instance = null;

	public static function instance(): self {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	private function __construct() {
		add_action( 'wp_ajax_ae_pr_toggle_status',   [ $this, 'toggle_status' ] );
		add_action( 'wp_ajax_ae_pr_get_rule_fields', [ $this, 'get_rule_fields' ] );
		add_action( 'wp_ajax_ae_pr_bulk_action',     [ $this, 'bulk_action' ] );
	}

	// -------------------------------------------------------------------------
	// Handlers
	// -------------------------------------------------------------------------

	public function toggle_status(): void {
		check_ajax_referer( 'ae_pr_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [ 'message' => __( 'Insufficient permissions.', 'ae-pro' ) ], 403 );
			return;
		}

		$preset_id = absint( $_POST['preset_id'] ?? 0 );
		$post      = get_post( $preset_id );

		if ( ! $post || $post->post_type !== Cpt::POST_TYPE ) {
			wp_send_json_error( [ 'message' => __( 'Preset not found.', 'ae-pro' ) ], 404 );
			return;
		}

		$new_status = 'publish' === $post->post_status ? 'draft' : 'publish';

		wp_update_post( [
			'ID'          => $preset_id,
			'post_status' => $new_status,
		] );

		wp_send_json_success( [
			'preset_id'  => $preset_id,
			'new_status' => $new_status,
			'active'     => 'publish' === $new_status,
		] );
	}

	public function bulk_action(): void {
		check_ajax_referer( 'ae_pr_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [ 'message' => __( 'Insufficient permissions.', 'ae-pro' ) ], 403 );
			return;
		}

		$action = sanitize_key( $_POST['bulk_action'] ?? '' );
		$ids    = array_filter( array_map( 'absint', (array) ( $_POST['preset_ids'] ?? [] ) ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput

		if ( empty( $ids ) || ! in_array( $action, [ 'activate', 'deactivate', 'delete' ], true ) ) {
			wp_send_json_error( [ 'message' => __( 'Invalid request.', 'ae-pro' ) ] );
			return;
		}

		$processed = [];
		foreach ( $ids as $id ) {
			$post = get_post( $id );
			if ( ! $post || $post->post_type !== Cpt::POST_TYPE ) {
				continue;
			}
			if ( 'delete' === $action ) {
				wp_delete_post( $id, true );
			} elseif ( 'activate' === $action ) {
				wp_update_post( [ 'ID' => $id, 'post_status' => 'publish' ] );
			} elseif ( 'deactivate' === $action ) {
				wp_update_post( [ 'ID' => $id, 'post_status' => 'draft' ] );
			}
			$processed[] = $id;
		}

		wp_send_json_success( [ 'processed' => $processed, 'action' => $action ] );
	}

	/**
	 * Returns operator options and field definitions for a given rule type.
	 * Used by the JS rules builder to repopulate controls when the type changes.
	 */
	public function get_rule_fields(): void {
		check_ajax_referer( 'ae_pr_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [ 'message' => __( 'Insufficient permissions.', 'ae-pro' ) ], 403 );
			return;
		}

		$rule_id = sanitize_key( $_POST['rule_type'] ?? '' );
		$rule    = Rule_Registry::instance()->get( $rule_id );

		if ( ! $rule ) {
			wp_send_json_error( [ 'message' => __( 'Unknown rule type.', 'ae-pro' ) ], 400 );
			return;
		}

		wp_send_json_success( [
			'operators' => $rule->get_operators(),
			'fields'    => $rule->get_fields(),
		] );
	}
}
