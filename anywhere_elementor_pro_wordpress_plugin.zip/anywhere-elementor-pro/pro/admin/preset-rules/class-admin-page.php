<?php
namespace Aepro\Admin\PresetRules;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Admin_Page {

	const PAGE_SLUG   = 'ae-preset-rules';
	const PARENT_SLUG = 'edit.php?post_type=ae_global_templates';
	const META_KEY    = '_ae_preset_rule_config';
	const SCHEMA_VER  = '1.0';

	private static ?self $_instance = null;

	public static function instance(): self {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	private function __construct() {
		add_action( 'admin_menu', [ $this, 'register_menu' ], 25 );
		add_action( 'admin_head', [ $this, 'hide_menu_css' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_assets' ] );

		add_action( 'admin_post_ae_pr_save',       [ $this, 'handle_save' ] );
		add_action( 'admin_post_ae_pr_delete',     [ $this, 'handle_delete' ] );
		add_action( 'admin_post_ae_pr_duplicate',  [ $this, 'handle_duplicate' ] );
		add_action( 'admin_post_ae_pr_export',       [ $this, 'handle_export' ] );
		add_action( 'admin_post_ae_pr_export_all',   [ $this, 'handle_export_all' ] );
		add_action( 'admin_post_ae_pr_import',       [ $this, 'handle_import' ] );
		add_action( 'admin_post_ae_pr_bulk_export',  [ $this, 'handle_bulk_export' ] );

		// Plugin top bar support.
		add_filter( 'aepro/admin/ui/screens', [ $this, 'register_screens' ] );
	}

	// -------------------------------------------------------------------------
	// Menu
	// -------------------------------------------------------------------------

	public function register_menu(): void {
		add_submenu_page(
			'edit.php?post_type=ae_global_templates',
			__( 'Rule Presets', 'ae-pro' ),
			__( 'Rule Presets', 'ae-pro' ),
			'manage_options',
			self::PAGE_SLUG,
			[ $this, 'render_page' ]
		);
	}

	public function hide_menu_css(): void {
		echo '<style>#adminmenu a[href="edit.php?post_type=ae_global_templates&page=' . esc_attr( self::PAGE_SLUG ) . '"]{display:none!important}</style>';
	}

	// -------------------------------------------------------------------------
	// Assets
	// -------------------------------------------------------------------------

	public function enqueue_assets( string $hook ): void {
		if ( ! $this->is_our_page() ) {
			return;
		}

		$ver     = defined( 'AEP_VERSION' ) ? AEP_VERSION : '1.0.0';
		$dir_url = plugin_dir_url( __FILE__ ) . 'assets/';

		wp_enqueue_style(
			'ae-pq-select2',
			AE_PRO_URL . 'pro/admin/preset-query/assets/css/select2.min.css',
			[],
			'4.0.13'
		);

		wp_enqueue_style(
			'ae-pr-admin',
			$dir_url . 'css/preset-rules-admin.css',
			[ 'ae-pq-select2' ],
			$ver
		);

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$is_edit = in_array( sanitize_key( $_GET['action'] ?? '' ), [ 'edit', 'new' ], true );

		wp_enqueue_script(
			'ae-pq-select2',
			AE_PRO_URL . 'pro/admin/preset-query/assets/js/select2.min.js',
			[ 'jquery' ],
			'4.0.13',
			true
		);

		wp_enqueue_script(
			'ae-pr-admin',
			$dir_url . 'js/preset-rules-admin.js',
			[ 'jquery', 'ae-pq-select2' ],
			$ver,
			true
		);

		wp_localize_script( 'ae-pr-admin', 'aePR', [
			'ajax_url'   => admin_url( 'admin-ajax.php' ),
			'nonce'      => wp_create_nonce( 'ae_pr_nonce' ),
			'is_edit'    => $is_edit,
			'saved_rules'=> $is_edit ? $this->get_saved_rules_for_js() : [],
			'rule_types' => $is_edit ? $this->get_rule_types_for_js() : [],
			'i18n'       => [
				'add_rule'            => __( '+ Add Rule', 'ae-pro' ),
				'remove'              => __( 'Remove', 'ae-pro' ),
				'select_type'         => __( '— Select Type —', 'ae-pro' ),
				'select_op'           => __( '— Operator —', 'ae-pro' ),
				'label_type'          => __( 'Type', 'ae-pro' ),
				'label_operator'      => __( 'Operator', 'ae-pro' ),
				'no_file'             => __( 'No file chosen', 'ae-pro' ),
				'confirm_delete'      => __( 'Delete this preset? This cannot be undone.', 'ae-pro' ),
				'loading'             => __( 'Loading…', 'ae-pro' ),
				'bulk_select_action'  => __( 'Please select a bulk action.', 'ae-pro' ),
				'bulk_select_items'   => __( 'Please select at least one preset.', 'ae-pro' ),
				'bulk_delete_confirm' => __( 'Delete the selected presets? This cannot be undone.', 'ae-pro' ),
			],
		] );
	}

	private function is_our_page(): bool {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$page = sanitize_key( $_GET['page'] ?? '' );
		return self::PAGE_SLUG === $page;
	}

	private function get_saved_rules_for_js(): array {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$preset_id = absint( $_GET['preset_id'] ?? 0 );
		if ( ! $preset_id ) {
			return [];
		}
		$config = Registry::instance()->get_config( $preset_id );
		return is_array( $config['rules'] ?? null ) ? $config['rules'] : [];
	}

	private function get_rule_types_for_js(): array {
		$grouped = Rule_Registry::instance()->get_grouped_options();
		$output  = [];
		foreach ( $grouped as $cat => $rules ) {
			foreach ( $rules as $id => $label ) {
				$rule_obj  = Rule_Registry::instance()->get( $id );
				$output[]  = [
					'id'        => $id,
					'label'     => $label,
					'category'  => $cat,
					'operators' => $rule_obj ? $rule_obj->get_operators() : [],
					'fields'    => $rule_obj ? $rule_obj->get_fields() : [],
				];
			}
		}
		return $output;
	}

	// -------------------------------------------------------------------------
	// Top-bar integration
	// -------------------------------------------------------------------------

	public function register_screens( array $screens ): array {
		$screens[] = 'ae_global_templates_page_' . self::PAGE_SLUG;
		return $screens;
	}


	// -------------------------------------------------------------------------
	// Router
	// -------------------------------------------------------------------------

	public function render_page(): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$action    = sanitize_key( $_GET['action'] ?? 'list' );
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$preset_id = absint( $_GET['preset_id'] ?? 0 );

		if ( in_array( $action, [ 'edit', 'new' ], true ) ) {
			$this->render_edit_page( 'new' === $action ? 0 : $preset_id );
		} else {
			$this->render_list_page();
		}
	}

	// -------------------------------------------------------------------------
	// List page
	// -------------------------------------------------------------------------

	private function render_list_page(): void {
		$notice = $this->get_notice();

		$presets = get_posts( [
			'post_type'      => Cpt::POST_TYPE,
			'post_status'    => [ 'publish', 'draft' ],
			'posts_per_page' => 200,
			'orderby'        => 'title',
			'order'          => 'ASC',
		] );

		$add_url        = admin_url( self::PARENT_SLUG . '&page=' . self::PAGE_SLUG . '&action=new' );
		$export_all_url = wp_nonce_url( admin_url( 'admin-post.php?action=ae_pr_export_all' ), 'ae_pr_export_all' );
		$pq_url         = admin_url( self::PARENT_SLUG . '&page=ae-preset-query' );
		?>
		<div class="wrap ae-pr-page ae-pr-list-page">

			<?php echo $notice; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>

			<h1 class="wp-heading-inline ae-pr-page-title">
				<?php esc_html_e( 'Presets', 'ae-pro' ); ?>
			</h1>

			<div class="ae-pr-list-actions">
				<button type="button" class="button ae-pr-import-trigger-btn" id="ae-pr-import-trigger">
					<?php esc_html_e( 'Import', 'ae-pro' ); ?>
				</button>
				<?php if ( ! empty( $presets ) ) : ?>
				<a href="<?php echo esc_url( $export_all_url ); ?>" class="button ae-pr-export-all-btn">
					<?php esc_html_e( 'Export All', 'ae-pro' ); ?>
				</a>
				<?php endif; ?>
				<a href="<?php echo esc_url( $add_url ); ?>" class="button button-primary button-large ae-pr-add-btn">
					+ <?php esc_html_e( 'Add New Preset', 'ae-pro' ); ?>
				</a>
			</div>

			<hr class="wp-header-end">

			<!-- Tab bar — shared with Preset Query page -->
			<div class="ae-pr-list-tabs">
				<a href="<?php echo esc_url( $pq_url ); ?>" class="ae-pr-list-tab">
					<?php esc_html_e( 'Query', 'ae-pro' ); ?>
				</a>
				<a href="#" class="ae-pr-list-tab ae-pr-list-tab--active">
					<?php esc_html_e( 'Rules', 'ae-pro' ); ?>
				</a>
			</div>

			<!-- Import form (hidden) -->
			<div id="ae-pr-import-wrap" class="ae-pr-import-wrap" style="display:none;">
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"
					enctype="multipart/form-data" class="ae-pr-import-form">
					<input type="hidden" name="action" value="ae_pr_import">
					<?php wp_nonce_field( 'ae_pr_import', 'ae_pr_import_nonce' ); ?>
					<label class="ae-pr-import-label">
						<span class="dashicons dashicons-media-document"></span>
						<?php esc_html_e( 'Choose JSON file', 'ae-pro' ); ?>
						<input type="file" name="ae_pr_import_file" accept=".json" required style="display:none;">
					</label>
					<span class="ae-pr-import-filename" id="ae-pr-import-filename">
						<?php esc_html_e( 'No file chosen', 'ae-pro' ); ?>
					</span>
					<button type="submit" class="button button-primary"><?php esc_html_e( 'Upload & Import', 'ae-pro' ); ?></button>
					<button type="button" class="button" id="ae-pr-import-cancel"><?php esc_html_e( 'Cancel', 'ae-pro' ); ?></button>
				</form>
			</div>

			<?php if ( empty( $presets ) ) : ?>

			<div class="ae-pr-empty-state">
				<div class="ae-pr-empty-icon">
					<svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
						<rect x="6" y="10" width="36" height="28" rx="3" stroke="#c3c4c7" stroke-width="2" fill="none"/>
						<path d="M16 20h16M16 26h10M16 32h7" stroke="#c3c4c7" stroke-width="2" stroke-linecap="round"/>
						<circle cx="35" cy="28" r="7" fill="#fff" stroke="#c3c4c7" stroke-width="2"/>
						<path d="M33 28h4M35 26v4" stroke="#c3c4c7" stroke-width="2" stroke-linecap="round"/>
					</svg>
				</div>
				<h2 class="ae-pr-empty-title"><?php esc_html_e( 'No rule presets yet', 'ae-pro' ); ?></h2>
				<p class="ae-pr-empty-desc"><?php esc_html_e( 'Build reusable visibility rule presets and apply them across Elementor sections, containers, and widgets.', 'ae-pro' ); ?></p>
				<a href="<?php echo esc_url( $add_url ); ?>" class="button button-primary button-large ae-pr-empty-cta">
					<?php esc_html_e( 'Create your first preset', 'ae-pro' ); ?>
				</a>
			</div>

			<?php else : ?>

			<div class="ae-pr-bulk-bar tablenav top">
				<div class="alignleft actions bulkactions">
					<label for="ae-pr-bulk-action" class="screen-reader-text"><?php esc_html_e( 'Select bulk action', 'ae-pro' ); ?></label>
					<select id="ae-pr-bulk-action">
						<option value=""><?php esc_html_e( '— Bulk Actions —', 'ae-pro' ); ?></option>
						<option value="activate"><?php esc_html_e( 'Activate', 'ae-pro' ); ?></option>
						<option value="deactivate"><?php esc_html_e( 'Deactivate', 'ae-pro' ); ?></option>
						<option value="export"><?php esc_html_e( 'Export', 'ae-pro' ); ?></option>
						<option value="delete"><?php esc_html_e( 'Delete', 'ae-pro' ); ?></option>
					</select>
					<button type="button" class="button action" id="ae-pr-bulk-apply" disabled>
						<?php esc_html_e( 'Apply', 'ae-pro' ); ?>
					</button>
					<span class="ae-pr-bulk-count" id="ae-pr-bulk-count"></span>
				</div>
			</div>

			<form id="ae-pr-bulk-export-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:none">
				<input type="hidden" name="action" value="ae_pr_bulk_export">
				<input type="hidden" name="ae_pr_bulk_nonce" value="<?php echo esc_attr( wp_create_nonce( 'ae_pr_bulk_export' ) ); ?>">
				<div id="ae-pr-bulk-export-ids"></div>
			</form>

			<table class="ae-pr-list-table widefat fixed">
				<thead>
					<tr>
						<th scope="col" class="manage-column column-cb check-column">
							<input type="checkbox" id="ae-pr-select-all">
						</th>
						<th class="ae-pr-col-name"><?php esc_html_e( 'Name', 'ae-pro' ); ?></th>
						<th class="ae-pr-col-status"><?php esc_html_e( 'Status', 'ae-pro' ); ?></th>
						<th class="ae-pr-col-usedin"><?php esc_html_e( 'Used In', 'ae-pro' ); ?></th>
						<th class="ae-pr-col-modified"><?php esc_html_e( 'Last Modified', 'ae-pro' ); ?></th>
						<th class="ae-pr-col-actions"><?php esc_html_e( 'Actions', 'ae-pro' ); ?></th>
					</tr>
				</thead>
				<tbody>
				<?php foreach ( $presets as $preset ) :
					$is_active  = 'publish' === $preset->post_status;
					$used_in    = $this->get_used_in( $preset->ID );
					$edit_url   = admin_url( self::PARENT_SLUG . '&page=' . self::PAGE_SLUG . '&action=edit&preset_id=' . $preset->ID );
					$export_url = wp_nonce_url( admin_url( 'admin-post.php?action=ae_pr_export&preset_id=' . $preset->ID ), 'ae_pr_export_' . $preset->ID );
					$dup_url    = wp_nonce_url( admin_url( 'admin-post.php?action=ae_pr_duplicate&preset_id=' . $preset->ID ), 'ae_pr_duplicate_' . $preset->ID );
					$del_url    = wp_nonce_url( admin_url( 'admin-post.php?action=ae_pr_delete&preset_id=' . $preset->ID ), 'ae_pr_delete_' . $preset->ID );
				?>
				<tr>
					<td class="check-column">
						<input type="checkbox" class="ae-pr-row-cb" value="<?php echo esc_attr( $preset->ID ); ?>">
					</td>
					<td class="ae-pr-col-name">
						<a href="<?php echo esc_url( $edit_url ); ?>" class="ae-pr-preset-name">
							<?php echo esc_html( $preset->post_title ?: __( '(no title)', 'ae-pro' ) ); ?>
						</a>
						<span class="ae-pr-preset-id">ID: <?php echo esc_html( $preset->ID ); ?></span>
					</td>
					<td>
						<button type="button"
							class="ae-pr-status-toggle<?php echo $is_active ? ' ae-pr-status-toggle--active' : ''; ?>"
							data-preset-id="<?php echo esc_attr( $preset->ID ); ?>"
							data-active="<?php echo $is_active ? '1' : '0'; ?>"
							title="<?php echo $is_active ? esc_attr__( 'Click to deactivate', 'ae-pro' ) : esc_attr__( 'Click to activate', 'ae-pro' ); ?>">
							<span class="ae-pr-status-toggle__dot"></span>
							<span class="ae-pr-status-toggle__label">
								<?php echo $is_active ? esc_html__( 'Active', 'ae-pro' ) : esc_html__( 'Inactive', 'ae-pro' ); ?>
							</span>
						</button>
					</td>
					<td class="ae-pr-col-usedin">
						<?php if ( empty( $used_in ) ) : ?>
							<span class="ae-pr-used-in-none">—</span>
						<?php else : ?>
							<?php
							$show = array_slice( $used_in, 0, 3 );
							$more = count( $used_in ) - count( $show );
							foreach ( $show as $item ) :
							?>
								<a href="<?php echo esc_url( $item['edit_url'] ); ?>"
									class="ae-pr-used-in-link" target="_blank">
									<?php echo esc_html( $item['title'] ); ?>
								</a>
							<?php endforeach; ?>
							<?php if ( $more > 0 ) : ?>
								<span class="ae-pr-used-in-more">+<?php echo esc_html( $more ); ?> more</span>
							<?php endif; ?>
						<?php endif; ?>
					</td>
					<td><?php echo esc_html( get_the_modified_date( 'Y-m-d H:i', $preset ) ); ?></td>
					<td class="ae-pr-col-actions">
						<a href="<?php echo esc_url( $edit_url ); ?>"><?php esc_html_e( 'Edit', 'ae-pro' ); ?></a>
						<span class="ae-pr-sep">|</span>
						<a href="<?php echo esc_url( $dup_url ); ?>"><?php esc_html_e( 'Duplicate', 'ae-pro' ); ?></a>
						<span class="ae-pr-sep">|</span>
						<a href="<?php echo esc_url( $export_url ); ?>"><?php esc_html_e( 'Export', 'ae-pro' ); ?></a>
						<span class="ae-pr-sep">|</span>
						<a href="<?php echo esc_url( $del_url ); ?>" class="ae-pr-delete-link"
							onclick="return confirm('<?php echo esc_js( __( 'Delete this preset? This cannot be undone.', 'ae-pro' ) ); ?>')">
							<?php esc_html_e( 'Delete', 'ae-pro' ); ?>
						</a>
					</td>
				</tr>
				<?php endforeach; ?>
				</tbody>
			</table>

			<?php endif; ?>

		</div>
		<?php
	}

	// -------------------------------------------------------------------------
	// Edit page
	// -------------------------------------------------------------------------

	private function render_edit_page( int $preset_id ): void {
		$post = $preset_id ? get_post( $preset_id ) : null;

		if ( $preset_id && ( ! $post || $post->post_type !== Cpt::POST_TYPE ) ) {
			wp_die( esc_html__( 'Preset not found.', 'ae-pro' ) );
		}

		$raw_config = $preset_id ? get_post_meta( $preset_id, self::META_KEY, true ) : '';
		$config     = $raw_config ? json_decode( $raw_config, true ) : [];
		$config     = is_array( $config ) ? $config : [];

		$relation = $config['relation'] ?? 'AND';

		$list_url = admin_url( self::PARENT_SLUG . '&page=' . self::PAGE_SLUG );
		$export_url = $preset_id
			? wp_nonce_url( admin_url( 'admin-post.php?action=ae_pr_export&preset_id=' . $preset_id ), 'ae_pr_export_' . $preset_id )
			: '';
		$notice     = $this->get_notice();
		$is_active  = $post && 'publish' === $post->post_status;
		?>
		<div class="wrap ae-pr-page ae-pr-edit-page">

			<?php echo $notice; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>

			<h1 class="wp-heading-inline ae-pr-page-title">
				<?php echo $preset_id ? esc_html__( 'Edit Preset Rule', 'ae-pro' ) : esc_html__( 'Add New Preset Rule', 'ae-pro' ); ?>
			</h1>
			<hr class="wp-header-end">

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" id="ae-pr-edit-form">
				<input type="hidden" name="action"    value="ae_pr_save">
				<input type="hidden" name="preset_id" value="<?php echo esc_attr( $preset_id ); ?>">
				<input type="hidden" name="ae_pr_config_json" id="ae-pr-config-json" value="">
				<?php wp_nonce_field( 'ae_pr_save_' . $preset_id, 'ae_pr_save_nonce' ); ?>

				<!-- Header bar -->
				<div class="ae-pr-edit-header">
					<div class="ae-pr-edit-header-left">
						<a href="<?php echo esc_url( $list_url ); ?>" class="ae-pr-back-link">
							<span class="dashicons dashicons-arrow-left-alt2"></span>
							<?php esc_html_e( 'All Presets', 'ae-pro' ); ?>
						</a>
						<input type="text" name="preset_title" id="ae-pr-title-input"
							class="ae-pr-title-input"
							value="<?php echo esc_attr( $post ? $post->post_title : '' ); ?>"
							placeholder="<?php esc_attr_e( 'Preset Name…', 'ae-pro' ); ?>">
					</div>
					<div class="ae-pr-edit-header-actions">
						<?php if ( $preset_id ) : ?>
						<button type="button"
							class="ae-pr-status-toggle<?php echo $is_active ? ' ae-pr-status-toggle--active' : ''; ?>"
							data-preset-id="<?php echo esc_attr( $preset_id ); ?>"
							data-active="<?php echo $is_active ? '1' : '0'; ?>"
							title="<?php echo $is_active ? esc_attr__( 'Click to deactivate', 'ae-pro' ) : esc_attr__( 'Click to activate', 'ae-pro' ); ?>">
							<span class="ae-pr-status-toggle__dot"></span>
							<span class="ae-pr-status-toggle__label">
								<?php echo $is_active ? esc_html__( 'Active', 'ae-pro' ) : esc_html__( 'Inactive', 'ae-pro' ); ?>
							</span>
						</button>
						<?php endif; ?>
						<?php if ( $preset_id && $export_url ) : ?>
						<a href="<?php echo esc_url( $export_url ); ?>" class="button button-large ae-pr-export-btn">
							<span class="dashicons dashicons-download"></span>
							<?php esc_html_e( 'Export', 'ae-pro' ); ?>
						</a>
						<?php endif; ?>
						<button type="submit" class="button button-primary button-large ae-pr-save-btn">
							<span class="dashicons dashicons-yes"></span>
							<?php esc_html_e( 'Save Preset', 'ae-pro' ); ?>
						</button>
					</div>
				</div><!-- /header -->

				<!-- Two-column layout -->
				<div class="ae-pr-edit-columns">

					<div class="ae-pr-edit-main">

						<!-- ── Rules Builder ── -->
						<div class="ae-pr-section-card">
							<div class="ae-pr-section-header">
								<span class="ae-pr-section-icon">📋</span>
								<h3><?php esc_html_e( 'Rules', 'ae-pro' ); ?></h3>
							</div>

							<div class="ae-pr-section-body">

							<div class="ae-pr-match-bar">
								<span class="ae-pr-match-label"><?php esc_html_e( 'RELATION:', 'ae-pro' ); ?></span>
								<div class="ae-pr-match-toggle">
									<label class="ae-pr-match-option<?php echo 'AND' === $relation ? ' ae-pr-match-option--active' : ''; ?>">
										<input type="radio" name="ae_pr_relation" value="AND" <?php checked( $relation, 'AND' ); ?>>
										<?php esc_html_e( 'AND', 'ae-pro' ); ?>
									</label>
									<label class="ae-pr-match-option<?php echo 'OR' === $relation ? ' ae-pr-match-option--active' : ''; ?>">
										<input type="radio" name="ae_pr_relation" value="OR" <?php checked( $relation, 'OR' ); ?>>
										<?php esc_html_e( 'OR', 'ae-pro' ); ?>
									</label>
								</div>
							</div>

								<div id="ae-pr-rules-list" class="ae-pr-rules-list">
									<!-- JS renders rows from aePR.saved_rules -->
								</div>

								<button type="button" class="button ae-pr-add-rule-btn" id="ae-pr-add-rule">
									<?php esc_html_e( '+ Add Rule', 'ae-pro' ); ?>
								</button>

								<!-- Rule type options grouped by category (for type dropdown) -->
								<select id="ae-pr-type-template" class="ae-pr-type-select" style="display:none;">
									<option value=""><?php esc_html_e( '— Select Type —', 'ae-pro' ); ?></option>
									<?php foreach ( Rule_Registry::instance()->get_grouped_options() as $cat => $rules ) : ?>
									<optgroup label="<?php echo esc_attr( $cat ); ?>">
										<?php foreach ( $rules as $rule_id => $rule_label ) : ?>
										<option value="<?php echo esc_attr( $rule_id ); ?>">
											<?php echo esc_html( $rule_label ); ?>
										</option>
										<?php endforeach; ?>
									</optgroup>
									<?php endforeach; ?>
								</select>

							</div>
						</div><!-- /Rules Builder -->

					</div><!-- /main -->

					<!-- Sidebar -->
					<div class="ae-pr-edit-sidebar">
						<div class="ae-pr-code-panel">

							<div class="ae-pr-code-tabs-bar">
								<div class="ae-pr-code-tabs">
									<button type="button" class="ae-pr-code-tab ae-pr-code-tab--active" data-tab="how-it-works">
										<?php esc_html_e( 'How it works', 'ae-pro' ); ?>
									</button>
									<?php if ( $preset_id ) : ?>
									<button type="button" class="ae-pr-code-tab" data-tab="usage">
										<?php esc_html_e( 'Usage', 'ae-pro' ); ?>
									</button>
									<?php endif; ?>
								</div>
							</div>

							<div class="ae-pr-code-content">

								<div class="ae-pr-code-pane ae-pr-code-pane--active" id="ae-pr-pane-how-it-works">
									<ol class="ae-pr-how-it-works">
										<li><?php esc_html_e( 'Add one or more rules below.', 'ae-pro' ); ?></li>
										<li><?php esc_html_e( 'Choose AND (all must match) or OR (any must match).', 'ae-pro' ); ?></li>
										<li><?php esc_html_e( 'Save, then select this preset inside the Elementor Dynamic Rules section.', 'ae-pro' ); ?></li>
										<li><?php esc_html_e( 'Configure Show/Hide, Render HTML, and Fallback directly in the Elementor editor.', 'ae-pro' ); ?></li>
									</ol>
								</div>

								<?php if ( $preset_id ) : ?>
								<div class="ae-pr-code-pane" id="ae-pr-pane-usage">
									<pre class="ae-pr-code-block" id="ae-pr-usage-code"><?php echo esc_html( $this->get_usage_snippet( $preset_id ) ); ?></pre>
								</div>
								<?php endif; ?>

							</div><!-- /code-content -->

							<?php if ( $preset_id ) : ?>
							<div class="ae-pr-code-footer" id="ae-pr-code-footer-usage" style="display:none;">
								<button type="button" class="ae-pr-copy-btn" data-target="ae-pr-usage-code">
									<span class="dashicons dashicons-clipboard"></span>
									<?php esc_html_e( 'Copy', 'ae-pro' ); ?>
								</button>
							</div>
							<?php endif; ?>

						</div><!-- /code-panel -->
					</div><!-- /sidebar -->

				</div><!-- /columns -->

			</form>
		</div>
		<?php
	}

	private function get_usage_snippet( int $preset_id ): string {
		return sprintf(
			"// PHP — evaluate preset in your code:\n" .
			"use Aepro\\Admin\\PresetRules\\Engine;\n" .
			"\$visible = Engine::instance()->evaluate( %d );\n" .
			"if ( \$visible ) {\n" .
			"    // element is visible\n" .
			"}",
			$preset_id
		);
	}

	// -------------------------------------------------------------------------
	// Notice helper
	// -------------------------------------------------------------------------

	private function get_notice(): string {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$msg  = sanitize_key( $_GET['ae_pr_msg'] ?? '' );
		if ( ! $msg ) {
			return '';
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( isset( $_GET['ae_pr_bulk_deleted'] ) ) {
			$n = absint( $_GET['ae_pr_bulk_deleted'] );
			return '<div class="notice notice-success is-dismissible"><p>' . sprintf( esc_html__( '%d preset(s) deleted.', 'ae-pro' ), $n ) . '</p></div>';
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( isset( $_GET['ae_pr_bulk_activated'] ) ) {
			$n = absint( $_GET['ae_pr_bulk_activated'] );
			return '<div class="notice notice-success is-dismissible"><p>' . sprintf( esc_html__( '%d preset(s) activated.', 'ae-pro' ), $n ) . '</p></div>';
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( isset( $_GET['ae_pr_bulk_deactivated'] ) ) {
			$n = absint( $_GET['ae_pr_bulk_deactivated'] );
			return '<div class="notice notice-success is-dismissible"><p>' . sprintf( esc_html__( '%d preset(s) deactivated.', 'ae-pro' ), $n ) . '</p></div>';
		}

		$messages = [
			'saved'      => [ 'success', __( 'Preset saved.', 'ae-pro' ) ],
			'deleted'    => [ 'success', __( 'Preset deleted.', 'ae-pro' ) ],
			'duplicated' => [ 'success', __( 'Preset duplicated.', 'ae-pro' ) ],
			'imported'   => [ 'success', __( 'Preset imported successfully.', 'ae-pro' ) ],
			'no_title'   => [ 'error',   __( 'Please enter a preset name.', 'ae-pro' ) ],
			'invalid'    => [ 'error',   __( 'Invalid preset.', 'ae-pro' ) ],
			'import_err' => [ 'error',   __( 'Import failed — invalid or malformed JSON file.', 'ae-pro' ) ],
		];

		if ( ! isset( $messages[ $msg ] ) ) {
			return '';
		}

		[ $type, $text ] = $messages[ $msg ];
		return sprintf(
			'<div class="notice notice-%s is-dismissible"><p>%s</p></div>',
			esc_attr( $type ),
			esc_html( $text )
		);
	}

	// -------------------------------------------------------------------------
	// Save handler
	// -------------------------------------------------------------------------

	public function handle_save(): void {
		$preset_id = absint( $_POST['preset_id'] ?? 0 );
		check_admin_referer( 'ae_pr_save_' . $preset_id, 'ae_pr_save_nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Insufficient permissions.', 'ae-pro' ) );
		}

		$title = sanitize_text_field( wp_unslash( $_POST['preset_title'] ?? '' ) );
		if ( '' === $title ) {
			wp_safe_redirect( $this->list_url( 'no_title' ) );
			exit;
		}

		// Decode and sanitize the JSON config sent by JS.
		$raw_json = isset( $_POST['ae_pr_config_json'] )
			? wp_unslash( $_POST['ae_pr_config_json'] ) // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			: '{}';
		$config = json_decode( $raw_json, true );
		if ( ! is_array( $config ) ) {
			$config = [];
		}

		$config = $this->sanitize_config( $config );

		// Create or update the CPT post.
		$post_data = [
			'post_title'  => $title,
			'post_type'   => Cpt::POST_TYPE,
			'post_status' => $preset_id ? get_post_status( $preset_id ) : 'draft',
		];

		if ( $preset_id ) {
			$post_data['ID'] = $preset_id;
			wp_update_post( $post_data );
		} else {
			$preset_id = wp_insert_post( $post_data );
		}

		if ( ! $preset_id || is_wp_error( $preset_id ) ) {
			wp_safe_redirect( $this->list_url( 'invalid' ) );
			exit;
		}

		update_post_meta( $preset_id, self::META_KEY, wp_json_encode( $config ) );

		$redirect = add_query_arg( [
			'page'      => self::PAGE_SLUG,
			'action'    => 'edit',
			'preset_id' => $preset_id,
			'ae_pr_msg' => 'saved',
		], admin_url( self::PARENT_SLUG ) );

		wp_safe_redirect( $redirect );
		exit;
	}

	// -------------------------------------------------------------------------
	// Delete handler
	// -------------------------------------------------------------------------

	public function handle_delete(): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$preset_id = absint( $_GET['preset_id'] ?? 0 );
		check_admin_referer( 'ae_pr_delete_' . $preset_id );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Insufficient permissions.', 'ae-pro' ) );
		}

		$post = get_post( $preset_id );
		if ( ! $post || $post->post_type !== Cpt::POST_TYPE ) {
			wp_safe_redirect( $this->list_url( 'invalid' ) );
			exit;
		}

		wp_delete_post( $preset_id, true );
		delete_transient( 'ae_pr_used_in_' . $preset_id );

		wp_safe_redirect( $this->list_url( 'deleted' ) );
		exit;
	}

	// -------------------------------------------------------------------------
	// Duplicate handler
	// -------------------------------------------------------------------------

	public function handle_duplicate(): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$preset_id = absint( $_GET['preset_id'] ?? 0 );
		check_admin_referer( 'ae_pr_duplicate_' . $preset_id );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Insufficient permissions.', 'ae-pro' ) );
		}

		$post = get_post( $preset_id );
		if ( ! $post || $post->post_type !== Cpt::POST_TYPE ) {
			wp_safe_redirect( $this->list_url( 'invalid' ) );
			exit;
		}

		$new_id = wp_insert_post( [
			'post_title'  => $post->post_title . __( ' (Copy)', 'ae-pro' ),
			'post_type'   => Cpt::POST_TYPE,
			'post_status' => 'draft',
		] );

		if ( $new_id && ! is_wp_error( $new_id ) ) {
			$meta = get_post_meta( $preset_id, self::META_KEY, true );
			if ( $meta ) {
				update_post_meta( $new_id, self::META_KEY, $meta );
			}
		}

		wp_safe_redirect( $this->list_url( 'duplicated' ) );
		exit;
	}

	// -------------------------------------------------------------------------
	// Export handler
	// -------------------------------------------------------------------------

	public function handle_export(): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$preset_id = absint( $_GET['preset_id'] ?? 0 );
		check_admin_referer( 'ae_pr_export_' . $preset_id );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Insufficient permissions.', 'ae-pro' ) );
		}

		$post = get_post( $preset_id );
		if ( ! $post || $post->post_type !== Cpt::POST_TYPE ) {
			wp_die( esc_html__( 'Preset not found.', 'ae-pro' ) );
		}

		$raw_config = get_post_meta( $preset_id, self::META_KEY, true );
		$config     = $raw_config ? json_decode( $raw_config, true ) : [];

		$export = [
			'_schema'  => 'ae_preset_rule',
			'_version' => self::SCHEMA_VER,
			'title'    => $post->post_title,
			'config'   => is_array( $config ) ? $config : [],
		];

		$filename = 'ae-rule-preset-' . sanitize_file_name( $post->post_title ) . '-' . $preset_id . '.json';

		header( 'Content-Type: application/json' );
		header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
		header( 'Pragma: no-cache' );

		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo wp_json_encode( $export, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES );
		exit;
	}

	// -------------------------------------------------------------------------
	// Export All handler
	// -------------------------------------------------------------------------

	public function handle_export_all(): void {
		check_admin_referer( 'ae_pr_export_all' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Insufficient permissions.', 'ae-pro' ) );
		}

		$posts = get_posts( [
			'post_type'      => Cpt::POST_TYPE,
			'post_status'    => [ 'publish', 'draft' ],
			'posts_per_page' => 200,
			'orderby'        => 'title',
			'order'          => 'ASC',
		] );

		$export = [
			'_schema'  => 'ae_preset_rule_collection',
			'_version' => self::SCHEMA_VER,
			'presets'  => [],
		];

		foreach ( $posts as $post ) {
			$raw_config = get_post_meta( $post->ID, self::META_KEY, true );
			$config     = $raw_config ? json_decode( $raw_config, true ) : [];
			$export['presets'][] = [
				'title'  => $post->post_title,
				'config' => is_array( $config ) ? $config : [],
			];
		}

		header( 'Content-Type: application/json' );
		header( 'Content-Disposition: attachment; filename="ae-rule-presets-all.json"' );
		header( 'Pragma: no-cache' );

		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo wp_json_encode( $export, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES );
		exit;
	}

	// -------------------------------------------------------------------------
	// Import handler
	// -------------------------------------------------------------------------

	public function handle_import(): void {
		check_admin_referer( 'ae_pr_import', 'ae_pr_import_nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Insufficient permissions.', 'ae-pro' ) );
		}

		if ( empty( $_FILES['ae_pr_import_file']['tmp_name'] ) ) {
			wp_safe_redirect( $this->list_url( 'import_err' ) );
			exit;
		}

		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$content = file_get_contents( sanitize_text_field( wp_unslash( $_FILES['ae_pr_import_file']['tmp_name'] ) ) );
		if ( false === $content ) {
			wp_safe_redirect( $this->list_url( 'import_err' ) );
			exit;
		}

		$data = json_decode( $content, true );
		if ( ! is_array( $data ) ) {
			wp_safe_redirect( $this->list_url( 'import_err' ) );
			exit;
		}

		// Single preset export.
		if ( 'ae_preset_rule' === ( $data['_schema'] ?? '' ) ) {
			$this->import_single( $data );
		} elseif ( 'ae_preset_rule_collection' === ( $data['_schema'] ?? '' ) ) {
			// Collection export.
			foreach ( (array) ( $data['presets'] ?? [] ) as $item ) {
				if ( is_array( $item ) ) {
					$this->import_single( array_merge( [ '_schema' => 'ae_preset_rule' ], $item ) );
				}
			}
		} else {
			wp_safe_redirect( $this->list_url( 'import_err' ) );
			exit;
		}

		wp_safe_redirect( $this->list_url( 'imported' ) );
		exit;
	}

	// -------------------------------------------------------------------------
	// Bulk export handler
	// -------------------------------------------------------------------------

	public function handle_bulk_export(): void {
		check_admin_referer( 'ae_pr_bulk_export', 'ae_pr_bulk_nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Insufficient permissions.', 'ae-pro' ) );
		}

		$ids = array_filter( array_map( 'absint', (array) ( $_POST['preset_ids'] ?? [] ) ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput

		if ( empty( $ids ) ) {
			wp_safe_redirect( $this->list_url() );
			exit;
		}

		$export = [
			'_schema'  => 'ae_preset_rule_collection',
			'_version' => self::SCHEMA_VER,
			'presets'  => [],
		];

		foreach ( $ids as $id ) {
			$post = get_post( $id );
			if ( ! $post || $post->post_type !== Cpt::POST_TYPE ) {
				continue;
			}
			$raw_config          = get_post_meta( $id, self::META_KEY, true );
			$config              = $raw_config ? json_decode( $raw_config, true ) : [];
			$export['presets'][] = [
				'title'  => $post->post_title,
				'config' => is_array( $config ) ? $config : [],
			];
		}

		// phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped
		header( 'Content-Type: application/json' );
		header( 'Content-Disposition: attachment; filename="ae-rule-presets-selected-' . gmdate( 'Y-m-d' ) . '.json"' );
		header( 'Cache-Control: no-cache, no-store, must-revalidate' );
		echo wp_json_encode( $export, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES );
		// phpcs:enable
		exit;
	}

	private function import_single( array $data ): void {
		$title  = sanitize_text_field( $data['title'] ?? __( 'Imported Preset', 'ae-pro' ) );
		$config = is_array( $data['config'] ?? null ) ? $this->sanitize_config( $data['config'] ) : [];

		$new_id = wp_insert_post( [
			'post_title'  => $title,
			'post_type'   => Cpt::POST_TYPE,
			'post_status' => 'draft',
		] );

		if ( $new_id && ! is_wp_error( $new_id ) ) {
			update_post_meta( $new_id, self::META_KEY, wp_json_encode( $config ) );
		}
	}

	// -------------------------------------------------------------------------
	// Config sanitizer
	// -------------------------------------------------------------------------

	private function sanitize_config( array $raw ): array {
		$relation = in_array( $raw['relation'] ?? '', [ 'AND', 'OR' ], true ) ? $raw['relation'] : 'AND';

		$rules    = [];
		$registry = Rule_Registry::instance();

		foreach ( (array) ( $raw['rules'] ?? [] ) as $rule_data ) {
			if ( ! is_array( $rule_data ) ) {
				continue;
			}

			$type     = sanitize_key( $rule_data['type']     ?? '' );
			$operator = sanitize_key( $rule_data['operator'] ?? '' );
			$rule_obj = $registry->get( $type );

			if ( ! $rule_obj ) {
				continue;
			}

			$valid_ops = array_keys( $rule_obj->get_operators() );
			if ( ! in_array( $operator, $valid_ops, true ) ) {
				continue;
			}

			$value  = $rule_obj->sanitize_value( $rule_data['value'] ?? '' );
			$row_id = sanitize_key( $rule_data['_id'] ?? wp_generate_uuid4() );

			$rules[] = [
				'_id'      => $row_id,
				'type'     => $type,
				'operator' => $operator,
				'value'    => $value,
			];
		}

		return compact( 'relation', 'rules' );
	}

	// -------------------------------------------------------------------------
	// Helpers
	// -------------------------------------------------------------------------

	private function list_url( string $msg = '' ): string {
		$args = [ 'page' => self::PAGE_SLUG ];
		if ( $msg ) {
			$args['ae_pr_msg'] = $msg;
		}
		return add_query_arg( $args, admin_url( self::PARENT_SLUG ) );
	}

	private function get_used_in( int $preset_id ): array {
		$cache_key = 'ae_pr_used_in_' . $preset_id;
		$cached    = get_transient( $cache_key );
		if ( false !== $cached ) {
			return $cached;
		}

		global $wpdb;

		$search_str = $wpdb->esc_like( '"ae_preset_rule_id":"' . $preset_id . '"' );
		$search_int = $wpdb->esc_like( '"ae_preset_rule_id":' . $preset_id );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$post_ids = $wpdb->get_col( $wpdb->prepare(
			"SELECT DISTINCT pm.post_id
			 FROM {$wpdb->postmeta} pm
			 INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
			 WHERE pm.meta_key = '_elementor_data'
			   AND ( pm.meta_value LIKE %s OR pm.meta_value LIKE %s )
			   AND p.post_status IN ('publish','draft','private','pending','future')
			   AND p.post_type  != 'revision'
			 LIMIT 20",
			'%' . $search_str . '%',
			'%' . $search_int . '%'
		) );

		$results = [];
		foreach ( (array) $post_ids as $pid ) {
			$pid       = (int) $pid;
			$results[] = [
				'id'       => $pid,
				'title'    => get_the_title( $pid ) ?: __( '(no title)', 'ae-pro' ),
				'edit_url' => (string) get_edit_post_link( $pid ),
			];
		}

		set_transient( $cache_key, $results, 5 * MINUTE_IN_SECONDS );
		return $results;
	}
}
