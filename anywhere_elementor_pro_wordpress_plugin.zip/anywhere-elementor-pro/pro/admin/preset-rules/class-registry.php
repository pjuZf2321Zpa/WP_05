<?php
namespace Aepro\Admin\PresetRules;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Provides CPT preset records for Elementor control selects.
 * Reads directly from post meta — no caching layer.
 */
class Registry {

	private static ?self $_instance = null;

	public static function instance(): self {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	private function __construct() {}

	/**
	 * Returns [ '' => '— Select Preset —', 42 => 'My Rule', ... ]
	 * Only published (active) presets are included.
	 */
	public function get_presets_for_select(): array {
		$presets = [ '' => __( '— Select Preset —', 'ae-pro' ) ];

		$posts = get_posts( [
			'post_type'      => Cpt::POST_TYPE,
			'post_status'    => 'publish',
			'posts_per_page' => 200,
			'orderby'        => 'title',
			'order'          => 'ASC',
		] );

		foreach ( $posts as $post ) {
			$presets[ $post->ID ] = $post->post_title;
		}

		return $presets;
	}

	/**
	 * True if the preset exists and is published (active).
	 */
	public function preset_exists( int $id ): bool {
		$post = get_post( $id );
		return $post
			&& $post->post_type   === Cpt::POST_TYPE
			&& $post->post_status === 'publish';
	}

	/**
	 * Returns the decoded config array for a preset.
	 *
	 * @return array{relation:string,visibility:string,rules:array}
	 */
	public function get_config( int $id ): array {
		$raw    = get_post_meta( absint( $id ), '_ae_preset_rule_config', true );
		$config = $raw ? json_decode( $raw, true ) : [];

		if ( ! is_array( $config ) ) {
			$config = [];
		}

		return apply_filters( 'aepro/preset-rules/config', $config, $id );
	}
}
