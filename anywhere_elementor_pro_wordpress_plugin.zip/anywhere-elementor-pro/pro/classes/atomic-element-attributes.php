<?php

namespace Aepro\Classes;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Adds attributes to the opening tag of Elementor 4 (atomic) elements.
 *
 * Elementor 4.3+ renders v4 Div Block / Flexbox / Grid and v4 widgets from Twig
 * templates that ignore the classic `_wrapper` render attributes. Features call add() from
 * their `elementor/frontend/{type}/before_render` hook (default priority);
 * this class then buffers the element's output once and writes all collected
 * attributes into its opening tag, so several features (Dynamic Background,
 * BG Slider, ...) can decorate the same element without nesting buffers.
 */
class AtomicElementAttributes {

	// v4 containers, and `widget` for v4 widgets (classic widgets never add here).
	const ELEMENT_TYPES = [ 'e-div-block', 'e-flexbox', 'e-grid', 'widget' ];

	private static $_instance = null;

	/** @var array<string,array<string,string>> Element ID => attributes still to apply. */
	private $pending = [];

	/** @var array<string,array<string,string>> Element ID => attributes whose output is being buffered. */
	private $buffering = [];

	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	private function __construct() {
		foreach ( self::ELEMENT_TYPES as $type ) {
			// After the features (priority 10) have added their attributes...
			add_action( "elementor/frontend/{$type}/before_render", [ $this, 'start' ], 100 );
			// ...and before anything else reacts to the finished output.
			add_action( "elementor/frontend/{$type}/after_render", [ $this, 'finish' ], 1 );
		}
	}

	/**
	 * @param string               $element_id
	 * @param array<string,string> $attributes `style` and `class` are appended to; others replace.
	 */
	public function add( $element_id, array $attributes ) {
		foreach ( $attributes as $name => $value ) {
			$value = (string) $value;
			if ( '' === $value ) {
				continue;
			}

			$current = $this->pending[ $element_id ][ $name ] ?? '';

			if ( 'style' === $name ) {
				$value = $this->join_styles( $current, $value );
			} elseif ( 'class' === $name ) {
				$value = trim( $current . ' ' . $value );
			}

			$this->pending[ $element_id ][ $name ] = $value;
		}
	}

	public function start( $element ) {
		$id = $element->get_id();
		if ( empty( $this->pending[ $id ] ) ) {
			return;
		}

		$this->buffering[ $id ] = $this->pending[ $id ];
		unset( $this->pending[ $id ] );
		ob_start();
	}

	public function finish( $element ) {
		$id = $element->get_id();
		if ( ! isset( $this->buffering[ $id ] ) ) {
			return;
		}

		$attributes = $this->buffering[ $id ];
		unset( $this->buffering[ $id ] );

		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Elementor's own markup; added values are escaped below.
		echo $this->inject( (string) ob_get_clean(), $id, $attributes );
	}

	/**
	 * Writes the attributes into the element's own opening tag (the first tag
	 * carrying its data-id), merging `style` and `class` with existing values.
	 */
	public function inject( $html, $id, array $attributes ) {
		$pattern = '/<[a-zA-Z][a-zA-Z0-9-]*\b[^>]*\bdata-id="' . preg_quote( $id, '/' ) . '"[^>]*>/';

		return (string) preg_replace_callback(
			$pattern,
			function ( $match ) use ( $attributes ) {
				$tag = $match[0];

				foreach ( $attributes as $name => $value ) {
					$name = preg_replace( '/[^a-zA-Z0-9_:-]/', '', $name );

					if ( preg_match( '/\s' . preg_quote( $name, '/' ) . '="([^"]*)"/', $tag, $existing ) ) {
						$old = html_entity_decode( $existing[1], ENT_QUOTES );
						if ( 'style' === $name ) {
							$value = $this->join_styles( $old, $value );
						} elseif ( 'class' === $name ) {
							$value = trim( $old . ' ' . $value );
						}
						$tag = str_replace( $existing[0], ' ' . $name . '="' . esc_attr( $value ) . '"', $tag );
					} else {
						// Right after the tag name (by position: values may contain "$1").
						$after = strcspn( $tag, " \t\n\r/>", 1 ) + 1;
						$tag   = substr( $tag, 0, $after ) . ' ' . $name . '="' . esc_attr( $value ) . '"' . substr( $tag, $after );
					}
				}

				return $tag;
			},
			$html,
			1
		);
	}

	private function join_styles( $first, $second ) {
		$first = rtrim( (string) $first, '; ' );
		return ( '' === $first ? '' : $first . ';' ) . ltrim( (string) $second, '; ' );
	}
}
