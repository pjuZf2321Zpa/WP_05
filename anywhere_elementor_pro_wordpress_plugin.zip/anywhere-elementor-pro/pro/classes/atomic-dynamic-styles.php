<?php

namespace Aepro\Classes;

use Elementor\Modules\AtomicWidgets\Styles\Styles_Renderer;
use Elementor\Plugin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Per-item values for dynamic tags used in Elementor 4 (atomic) styles.
 *
 * Elementor 4 writes an element's styles into one cached stylesheet per
 * document and resolves dynamic tags in them once, while writing it. Inside
 * Dynific listings (block layouts, repeater / flexible rows, archives) every
 * item then shows the same value, taken from whichever page generated the
 * file. For elements whose styles use dynamic tags, this resolves those style
 * props again for the item being rendered and prints them as a small rule for
 * a class added to that item only. Breakpoints and states (hover, ...) are
 * kept; static props stay in Elementor's stylesheet.
 */
class AtomicDynamicStyles {

	const CLASS_PREFIX = 'aep-dyn-';

	private static $_instance = null;

	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	public static function is_supported() {
		return class_exists( Styles_Renderer::class );
	}

	private function __construct() {
		// Before AtomicElementAttributes buffers the element (type hook, priority 100).
		add_action( 'elementor/frontend/before_render', [ $this, 'before_render' ], 20 );

		// The rule is per item, so the element's output must not be cached.
		add_filter( 'elementor/element/is_dynamic_content', [ $this, 'is_dynamic_content' ], 10, 2 );

		AtomicElementAttributes::instance();
	}

	public function before_render( $element ) {
		if ( ! method_exists( $element, 'get_atomic_settings' ) || $this->is_editor() ) {
			return;
		}

		$raw    = $element->get_raw_data();
		$styles = isset( $raw['styles'] ) && is_array( $raw['styles'] ) ? $raw['styles'] : [];

		$variants = $this->get_dynamic_variants( $styles );
		if ( ! $variants ) {
			return;
		}

		try {
			$css = $this->render_css( $variants );
		} catch ( \Throwable $e ) {
			return;
		}

		if ( '' === $css ) {
			return;
		}

		// Same values → same class, so repeated items and AJAX-loaded pages
		// never override each other's rules.
		$class = self::CLASS_PREFIX . substr( md5( $element->get_id() . $css ), 0, 10 );
		$css   = str_replace( self::CLASS_PREFIX . 'placeholder', $class, $css );

		// Values come from custom fields: never let them close the style tag.
		$css = str_replace( '<', '\3C ', $css );

		echo '<style>' . $css . '</style>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- CSS built by Elementor's renderer; '<' neutralised above.

		AtomicElementAttributes::instance()->add( $element->get_id(), [ 'class' => $class ] );
	}

	public function is_dynamic_content( $is_dynamic, $raw_data ) {
		if ( $is_dynamic || empty( $raw_data['styles'] ) || ! is_array( $raw_data['styles'] ) ) {
			return $is_dynamic;
		}

		return ! empty( $this->get_dynamic_variants( $raw_data['styles'] ) );
	}

	/**
	 * The variants (breakpoint / state) of the element's local class styles,
	 * reduced to the props that use a dynamic tag.
	 *
	 * @return array[]
	 */
	private function get_dynamic_variants( array $styles ) {
		$variants = [];

		foreach ( $styles as $style ) {
			if ( ! is_array( $style ) || 'class' !== ( $style['type'] ?? '' ) || empty( $style['variants'] ) || ! is_array( $style['variants'] ) ) {
				continue;
			}

			foreach ( $style['variants'] as $variant ) {
				$props = array_filter(
					(array) ( $variant['props'] ?? [] ),
					[ $this, 'has_dynamic_value' ]
				);

				if ( $props ) {
					$variants[] = [
						'meta'       => $variant['meta'] ?? [],
						'props'      => $props,
						'custom_css' => null,
					];
				}
			}
		}

		return $variants;
	}

	private function has_dynamic_value( $value ) {
		if ( ! is_array( $value ) ) {
			return false;
		}

		if ( 'dynamic' === ( $value['$$type'] ?? null ) ) {
			return true;
		}

		foreach ( $value as $child ) {
			if ( $this->has_dynamic_value( $child ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Renders the variants with Elementor's own style renderer (which resolves
	 * the dynamic tags in the current post / row context).
	 */
	private function render_css( array $variants ) {
		return Styles_Renderer::make( Plugin::$instance->breakpoints->get_breakpoints_config() )->render(
			[
				[
					'id'       => self::CLASS_PREFIX . 'placeholder',
					'type'     => 'class',
					'variants' => $variants,
				],
			]
		);
	}

	private function is_editor() {
		return Plugin::$instance->editor->is_edit_mode() || Plugin::$instance->preview->is_preview_mode();
	}
}
