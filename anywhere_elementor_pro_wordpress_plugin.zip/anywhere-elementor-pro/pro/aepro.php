<?php

if ( ! defined( 'AE_PRO_ACTIVE' ) ) {
	define( 'AE_PRO_ACTIVE', true );
}

add_filter( 'aepro/is_pro_active', '__return_true' );

require_once AE_PRO_PATH . 'includes/license-manager/freemius.php';

add_action(
	'plugins_loaded',
	function() {
		if ( class_exists( '\Aepro\Plugin' ) ) {
			\Aepro\Plugin::$_level = 2;
		}
	}
);

// Pro classmap autoload is registered in includes/core.php for early availability.

// Bootstrap Preset Query feature (pro-only admin + widget integration).
add_action( 'plugins_loaded', function() {
	\Aepro\Admin\PresetQuery\Module::instance();
}, 12 );

// Bootstrap Preset Rules feature.
add_action( 'plugins_loaded', function() {
	\Aepro\Admin\PresetRules\Module::instance();
}, 13 );

// Elementor 4: per-item values for dynamic tags used in v4 element styles.
add_action( 'elementor/init', function() {
	if ( \Aepro\Classes\AtomicDynamicStyles::is_supported() ) {
		\Aepro\Classes\AtomicDynamicStyles::instance();
	}
} );

add_filter(
	'aepro/modules',
	function( $modules ) {
		$modules['core'] = [
			'label'   => __( 'General', 'ae-pro' ),
			'modules' => array_merge(
				$modules['core']['modules'],
				[
					'breadcrumb' => [
						'label'   => __( 'Breadcrumb', 'ae-pro' ),
						'type'    => 'widget',
						'enabled' => true,
					],
					'google-map' => [
						'label'   => __( 'CF Google Map', 'ae-pro' ),
						'type'    => 'widget',
						'enabled' => true,
					],
					'custom-field' => [
						'label'   => __( 'Custom Field', 'ae-pro' ),
						'type'    => 'widget',
						'enabled' => true,
					],
					'portfolio' => [
						'label'   => __( 'Portfolio', 'ae-pro' ),
						'type'    => 'widget',
						'enabled' => true,
					],
					'post-blocks' => [
						'label'   => __( 'Post blocks', 'ae-pro' ),
						'type'    => 'widget',
						'enabled' => true,
					],
					'post-blocks-adv' => [
						'label'   => __( 'Post blocks Adv', 'ae-pro' ),
						'type'    => 'widget',
						'enabled' => true,
					],
					'post-readmore' => [
						'label'   => __( 'Post Read-More', 'ae-pro' ),
						'type'    => 'widget',
						'enabled' => true,
					],
					'searchform' => [
						'label'   => __( 'Search Form', 'ae-pro' ),
						'type'    => 'widget',
						'enabled' => true,
					],
					'tax-custom-field' => [
						'label'   => __( 'Taxonomy Custom Field', 'ae-pro' ),
						'type'    => 'widget',
						'enabled' => true,
					],
					'taxonomy' => [
						'label'   => __( 'Taxonomy', 'ae-pro' ),
						'type'    => 'widget',
						'enabled' => true,
					],
					'taxonomy-blocks' => [
						'label'   => __( 'Taxonomy Blocks', 'ae-pro' ),
						'type'    => 'widget',
						'enabled' => true,
					],
					'dynamic-bg' => [
						'label'   => __( 'Dynamic Backgrounds', 'ae-pro' ),
						'type'    => 'feature',
						'enabled' => true,
					],
					'dynamic-rules' => [
						'label'   => __( 'Dynamic Rules', 'ae-pro' ),
						'type'    => 'feature',
						'enabled' => true,
					],
					'bg-slider' => [
						'label'   => __( 'Background Slider', 'ae-pro' ),
						'type'    => 'feature',
						'enabled' => true,
					],
					'trigger' => [
						'label'   => __( 'Trigger', 'ae-pro' ),
						'type'    => 'widget',
						'enabled' => true,
					],
					'dynamic-map' => [
						'label'   => __( 'Dynamic Map', 'ae-pro' ),
						'type'    => 'widget',
						'enabled' => true,
					],
					'import-export' => [
						'label'   => __( 'Import - Export <sup><i>Beta</i></sup>', 'ae-pro' ),
						'type'    => 'feature',
						'enabled' => true,
					],
					'duplicate-template' => [
						'label'   => __( 'Duplicate Template <sup><i>Beta</i></sup>', 'ae-pro' ),
						'type'    => 'feature',
						'enabled' => true,
					],
					'post-dynamic' => [
						'label'   => __( 'Post Dynamic', 'ae-pro' ),
						'type'    => 'feature',
						'hidden'  => true,
						'enabled' => true,
					],
					'query-control' => [
						'label'   => __( 'Query Control', 'ae-pro' ),
						'type'    => 'feature',
						'hidden'  => true,
						'enabled' => true,
					],
					'smart-tokens' => [
						'label'   => __( 'Smart Tokens', 'ae-pro' ),
						'type'    => 'feature',
						'enabled' => true,
					],
				]
			),
		];

		$modules['acf'] = [
			'label'   => __( 'ACF', 'ae-pro' ),
			'modules' => [
				'acf-fields' => [
					'label'         => __( 'ACF Fields', 'ae-pro' ),
					'type'          => 'widget',
					'enabled'       => true,
					'not-available' => __( "Requires 'Advanced Custom Field' or 'Advanced Custom Field Pro' plugin installed and activated", 'ae-pro' ),
				],
				'acf-fields-v2' => [
					'label'         => __( 'ACF Fields V2', 'ae-pro' ),
					'type'          => 'widget',
					'enabled'       => true,
					'not-available' => __( "Requires 'Advanced Custom Field' or 'Advanced Custom Field Pro' plugin installed and activated", 'ae-pro' ),
				],
				'acf-gallery' => [
					'label'         => __( 'ACF Gallery', 'ae-pro' ),
					'type'          => 'widget',
					'enabled'       => true,
					'not-available' => __( "Requires 'Advanced Custom Field Pro' plugin installed and activated", 'ae-pro' ),
				],
				'acf-repeater' => [
					'label'         => __( 'ACF Repeater', 'ae-pro' ),
					'type'          => 'widget',
					'enabled'       => true,
					'not-available' => __( "Requires 'Advanced Custom Field Pro' plugin installed and activated", 'ae-pro' ),
				],
				'acf-flexible-content' => [
					'label'         => __( 'ACF Flexible Content', 'ae-pro' ),
					'type'          => 'widget',
					'enabled'       => true,
					'not-available' => __( "Requires 'Advanced Custom Field Pro' plugin installed and activated", 'ae-pro' ),
				],
				'acf-dynamic' => [
					'label'         => __( 'ACF Dynamic Tag', 'ae-pro' ),
					'type'          => 'feature',
					'enabled'       => true,
					'hidden'        => true,
					'not-available' => __( "Requires 'Advanced Custom Field Pro' plugin installed and activated", 'ae-pro' ),
				],
			],
		];

		$modules['pods'] = [
			'label'   => __( 'Pods', 'ae-pro' ),
			'modules' => [
				'Pods-fields' => [
					'label'         => __( 'Pods Fields', 'ae-pro' ),
					'type'          => 'widget',
					'enabled'       => true,
					'not-available' => __( "Requires 'Pods' plugin installed and activated", 'ae-pro' ),
				],
			],
		];

		$modules['woo'] = [
			'label'   => __( 'WooCommerce Integration', 'ae-pro' ),
			'modules' => [
				'woo' => [
					'label'         => __( 'WooCommerce Widgets', 'ae-pro' ),
					'type'          => 'widget',
					'enabled'       => true,
					'not-available' => __( "Requires 'WooCommerce' plugin installed and activated", 'ae-pro' ),
				],
				'woo-dynamic' => [
					'label'         => __( 'Woo Dynamic Tag', 'ae-pro' ),
					'type'          => 'feature',
					'enabled'       => true,
					'hidden'        => true,
					'not-available' => __( "Requires 'WooCommerce' plugin installed and activated", 'ae-pro' ),
				],
			],
		];

		return $modules;
	},
	20
);
