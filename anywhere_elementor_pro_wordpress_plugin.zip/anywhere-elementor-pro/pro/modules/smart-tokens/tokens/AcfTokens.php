<?php

namespace Aepro\Modules\SmartTokens\Tokens;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Aepro\Modules\SmartTokens\Core\Registry;
use Aepro\Modules\SmartTokens\Core\Context;

/**
 * ACF token group: {{acf.field_name}}
 *
 * Supported field types and their token shapes:
 *
 *   Flat          {{acf.price}}                     text / number / email / textarea / date
 *   Image         {{acf.photo.url}}  .alt  .caption  .title
 *   File          {{acf.doc.url}}
 *   Link          {{acf.cta.url}}  .title  .target
 *   Group         {{acf.address.street}}             recurses into sub-fields
 *   Repeater      {{acf.faq.0.question}}             runtime dot-path; picker shows .0 hint
 *   Flex content  {{acf.sections.0.heading}}         runtime dot-path; picker shows .0 hint
 *   Relationship  {{acf.related.0.title}}  .url  .id  .excerpt  .date
 *   Post object   {{acf.featured.title}}   .url  .id  .excerpt  .date
 *   User          {{acf.author.display_name}}  .email  .first_name  .last_name  .url
 *   Taxonomy      {{acf.category.0.name}}      .url   .description   .slug
 */
final class AcfTokens {

	public function register( Registry $registry ): void {
		if ( ! function_exists( 'get_field' ) ) {
			return;
		}

		$registry->register_group(
			'acf',
			[
				'label'    => __( 'ACF Fields', 'ae-pro' ),
				'icon'     => 'eicon-database',
				'priority' => 70,
			]
		);

		// Dynamic wildcard covers any {{acf.*}} at runtime.
		$registry->register_token(
			'acf.*',
			[
				'label'       => __( 'ACF Field', 'ae-pro' ),
				'group'       => 'acf',
				'description' => __( 'Any ACF field. Usage: {{acf.field_name}}', 'ae-pro' ),
				'resolver'    => [ $this, 'resolve_field' ],
				'type'        => 'text',
				'dynamic'     => true,
			]
		);

		// Concrete tokens for the editor picker (consumed only by
		// EditorIntegration::rest_get_tokens() over REST). Register lazily on
		// `rest_api_init` rather than eagerly on every `is_admin()` page load —
		// walking acf_get_field_groups()/acf_get_fields() for every group on
		// every admin request (including ACF's own Field Group editor) primes
		// ACF's internal field cache before ACF has finished resolving nested
		// sub_fields for the field currently being edited, which makes
		// repeater/flexible-content sub-fields render empty in ACF's own UI.
		add_action(
			'rest_api_init',
			function () use ( $registry ): void {
				$this->register_known_fields( $registry );
			},
			5
		);
	}

	// ── Picker registration ───────────────────────────────────────────────────

	private function register_known_fields( Registry $registry ): void {
		if ( ! function_exists( 'acf_get_field_groups' ) ) {
			return;
		}

		$groups = acf_get_field_groups();
		if ( empty( $groups ) ) {
			return;
		}

		foreach ( $groups as $group ) {
			if ( ! function_exists( 'acf_get_fields' ) ) {
				break;
			}
			$fields = acf_get_fields( $group['key'] );
			if ( empty( $fields ) ) {
				continue;
			}
			foreach ( $fields as $field ) {
				$this->register_field_token( $registry, $field, 'acf' );
			}
		}
	}

	/**
	 * Register a single ACF field (and sub-tokens where appropriate).
	 *
	 * @param string $prefix  Token namespace, e.g. 'acf' or 'acf.address'.
	 */
	private function register_field_token( Registry $registry, array $field, string $prefix ): void {
		$name  = $field['name'] ?? '';
		$type  = $field['type'] ?? 'text';
		$label = $field['label'] ?? $name;

		if ( '' === $name ) {
			return;
		}

		$key = $prefix . '.' . sanitize_key( $name );

		switch ( $type ) {

			// ── Image ─────────────────────────────────────────────────────────
			case 'image':
				foreach ( [ 'url' => 'url', 'alt' => 'text', 'caption' => 'text', 'title' => 'text' ] as $sub => $vtype ) {
					$registry->register_token(
						"$key.$sub",
						$this->make_config( "$label — $sub", 'acf', $vtype, "$name.$sub" )
					);
				}
				break;

			// ── File ──────────────────────────────────────────────────────────
			case 'file':
				$registry->register_token(
					"$key.url",
					$this->make_config( "$label — URL", 'acf', 'url', "$name.url" )
				);
				break;

			// ── Link ──────────────────────────────────────────────────────────
			case 'link':
				foreach ( [ 'url' => 'url', 'title' => 'text', 'target' => 'text' ] as $sub => $vtype ) {
					$registry->register_token(
						"$key.$sub",
						$this->make_config( "$label — $sub", 'acf', $vtype, "$name.$sub" )
					);
				}
				break;

			// ── Group — recurse into sub-fields ───────────────────────────────
			case 'group':
				if ( ! empty( $field['sub_fields'] ) && is_array( $field['sub_fields'] ) ) {
					foreach ( $field['sub_fields'] as $sub ) {
						$this->register_field_token( $registry, $sub, $key );
					}
				}
				break;

			// ── Relationship / Post Object — post property sub-tokens ─────────
			case 'relationship':
			case 'post_object':
				$is_multiple = ( $type === 'relationship' );
				foreach ( [ 'title' => 'text', 'url' => 'url', 'id' => 'text', 'excerpt' => 'text', 'date' => 'text' ] as $sub => $vtype ) {
					$path = $is_multiple ? "$name.0.$sub" : "$name.$sub";
					$suffix = $is_multiple ? "first post — $sub" : $sub;
					$registry->register_token(
						$is_multiple ? "$key.0.$sub" : "$key.$sub",
						$this->make_config( "$label — $suffix", 'acf', $vtype, $path )
					);
				}
				break;

			// ── User ──────────────────────────────────────────────────────────
			case 'user':
				foreach ( [
					'display_name' => 'text',
					'email'        => 'text',
					'first_name'   => 'text',
					'last_name'    => 'text',
					'url'          => 'url',
				] as $sub => $vtype ) {
					$registry->register_token(
						"$key.$sub",
						$this->make_config( "$label — $sub", 'acf', $vtype, "$name.$sub" )
					);
				}
				break;

			// ── Taxonomy ──────────────────────────────────────────────────────
			case 'taxonomy':
				foreach ( [ 'name' => 'text', 'url' => 'url', 'description' => 'text', 'slug' => 'text' ] as $sub => $vtype ) {
					$registry->register_token(
						"$key.0.$sub",
						$this->make_config( "$label — first term $sub", 'acf', $vtype, "$name.0.$sub" )
					);
				}
				break;

			// ── Repeater / Flexible content — hint token only ─────────────────
			// Rows/layouts can't be enumerated; user writes the full path at runtime.
			case 'repeater':
			case 'flexible_content':
				$registry->register_token(
					"$key.0",
					[
						'label'       => sprintf( '%s — first row (example)', esc_html( $label ) ),
						'group'       => 'acf',
						'description' => sprintf(
							/* translators: %s: field name */
							__( 'First row of "%s". Extend with sub-field names: .0.field_name', 'ae-pro' ),
							esc_html( $name )
						),
						'resolver'    => [ $this, 'resolve_field' ],
						'type'        => 'text',
						'dynamic'     => false,
					]
				);
				break;

			// ── Clone — skip (structure depends on source fields) ─────────────
			case 'clone':
				break;

			// ── All other flat field types ─────────────────────────────────────
			default:
				$registry->register_token(
					$key,
					[
						'label'       => sprintf(
							/* translators: %1$s: field label, %2$s: field type */
							__( '%1$s (%2$s)', 'ae-pro' ),
							esc_html( $label ),
							esc_html( $type )
						),
						'group'       => 'acf',
						'description' => sprintf(
							/* translators: %s: field name */
							__( 'ACF field: %s', 'ae-pro' ),
							esc_html( $name )
						),
						'resolver'    => [ $this, 'resolve_field' ],
						'type'        => ( $type === 'url' ) ? 'url' : 'text',
						'dynamic'     => false,
					]
				);
				break;
		}
	}

	private function make_config( string $label, string $group, string $type, string $hint ): array {
		return [
			'label'       => esc_html( $label ),
			'group'       => $group,
			'description' => sprintf(
				/* translators: %s: dot-path hint */
				__( 'ACF path: %s', 'ae-pro' ),
				esc_html( $hint )
			),
			'resolver'    => [ $this, 'resolve_field' ],
			'type'        => $type,
			'dynamic'     => false,
		];
	}

	// ── Runtime resolver ──────────────────────────────────────────────────────

	/**
	 * Resolve any {{acf.*}} token at runtime.
	 *
	 * Splits the path after 'acf.' by dots, fetches the top-level field from ACF,
	 * then traverses nested arrays and objects:
	 *   acf.price            → get_field('price')
	 *   acf.hero.url         → get_field('hero')['url']       (image)
	 *   acf.address.city     → get_field('address')['city']   (group)
	 *   acf.related.0.title  → get_field('related')[0]->post_title  (relationship)
	 *   acf.author.email     → get_field('author')->user_email      (user)
	 *   acf.tags.0.name      → get_field('tags')[0]->name           (taxonomy)
	 */
	public function resolve_field( string $key ): string {
		if ( ! function_exists( 'get_field' ) ) {
			return '';
		}

		$path = substr( $key, 4 ); // strip 'acf.'
		if ( '' === $path ) {
			return '';
		}

		$post    = Context::current_post();
		$post_id = $post ? $post->ID : false;

		$parts      = explode( '.', $path );
		$field_name = array_shift( $parts );

		// Resolve value: current post first, then ACF options page.
		//
		// ACF's behaviour when called with a post_id for an options-page field:
		//   - Older ACF: returns false (no '_field_name' meta key found on the post)
		//   - Newer ACF: returns '' (field found by name, default_value returned)
		// So we catch both cases via metadata_exists: ACF writes '_field_name' into
		// post meta only when a value has actually been saved on that post. Its
		// absence means the field is not a post field — fall through to 'option'.
		$value         = $post_id ? get_field( $field_name, $post_id ) : false;
		$has_post_meta = $post_id && metadata_exists( 'post', $post_id, '_' . $field_name );

		if ( ! $has_post_meta && ( false === $value || null === $value || '' === $value ) ) {
			$opt_value = get_field( $field_name, 'option' );
			if ( false !== $opt_value && null !== $opt_value ) {
				$value = $opt_value;
			}
		}

		foreach ( $parts as $segment ) {
			$value = $this->traverse( $value, $segment );
			if ( null === $value ) {
				return '';
			}
		}

		return $this->stringify( $value );
	}

	/**
	 * Advance one segment into a value that may be an array, a WP_Post,
	 * a WP_User, a WP_Term, or a plain object.
	 *
	 * Special virtual properties are resolved here so tokens like
	 * {{acf.related.0.url}} and {{acf.author.email}} work without
	 * the user knowing internal object property names.
	 */
	private function traverse( $value, string $segment ) {
		if ( null === $value || false === $value ) {
			return null;
		}

		// ── Numeric index — advance into an array ─────────────────────────────
		if ( is_numeric( $segment ) ) {
			$index = (int) $segment;
			if ( is_array( $value ) && array_key_exists( $index, $value ) ) {
				return $value[ $index ];
			}
			return null;
		}

		// ── Array with matching string key ────────────────────────────────────
		if ( is_array( $value ) && array_key_exists( $segment, $value ) ) {
			return $value[ $segment ];
		}

		// ── WP_Post ───────────────────────────────────────────────────────────
		if ( $value instanceof \WP_Post ) {
			switch ( $segment ) {
				case 'title':
				case 'post_title':
					return $value->post_title;
				case 'id':
				case 'ID':
					return (string) $value->ID;
				case 'url':
				case 'permalink':
				case 'link':
					return get_permalink( $value->ID ) ?: '';
				case 'slug':
				case 'post_name':
					return $value->post_name;
				case 'excerpt':
				case 'post_excerpt':
					return $value->post_excerpt;
				case 'date':
				case 'post_date':
					return $value->post_date;
				case 'modified':
				case 'post_modified':
					return $value->post_modified;
				case 'type':
				case 'post_type':
					return $value->post_type;
				case 'status':
				case 'post_status':
					return $value->post_status;
				default:
					return $value->$segment ?? null;
			}
		}

		// ── WP_User ───────────────────────────────────────────────────────────
		if ( $value instanceof \WP_User ) {
			switch ( $segment ) {
				case 'display_name':
					return $value->display_name;
				case 'email':
				case 'user_email':
					return $value->user_email;
				case 'first_name':
					return $value->first_name;
				case 'last_name':
					return $value->last_name;
				case 'login':
				case 'user_login':
					return $value->user_login;
				case 'url':
				case 'user_url':
					return $value->user_url;
				case 'id':
				case 'ID':
					return (string) $value->ID;
				default:
					return $value->$segment ?? null;
			}
		}

		// ── WP_Term ───────────────────────────────────────────────────────────
		if ( $value instanceof \WP_Term ) {
			switch ( $segment ) {
				case 'name':
					return $value->name;
				case 'slug':
					return $value->slug;
				case 'description':
					return $value->description;
				case 'url':
				case 'link':
					return get_term_link( $value ) ?: '';
				case 'count':
					return (string) $value->count;
				case 'id':
				case 'ID':
				case 'term_id':
					return (string) $value->term_id;
				default:
					return $value->$segment ?? null;
			}
		}

		// ── Generic object ────────────────────────────────────────────────────
		if ( is_object( $value ) ) {
			return $value->$segment ?? null;
		}

		return null;
	}

	// ── Value stringification ─────────────────────────────────────────────────

	/**
	 * Convert a resolved ACF value to a plain string.
	 * The traverse() method handles object navigation; stringify() only sees
	 * the leaf value after all segments are consumed.
	 */
	private function stringify( $value ): string {
		if ( null === $value || false === $value ) {
			return '';
		}

		if ( is_string( $value ) ) {
			return $value;
		}

		if ( is_numeric( $value ) ) {
			return (string) $value;
		}

		// WP_Post (post_object field, no sub-key) → post title.
		if ( $value instanceof \WP_Post ) {
			return $value->post_title;
		}

		// WP_User (user field, no sub-key) → display name.
		if ( $value instanceof \WP_User ) {
			return $value->display_name;
		}

		// WP_Term (taxonomy field, no sub-key) → term name.
		if ( $value instanceof \WP_Term ) {
			return $value->name;
		}

		// Image / file field (array with 'url') → URL.
		if ( is_array( $value ) && isset( $value['url'] ) ) {
			return (string) $value['url'];
		}

		// Array of objects (relationship, taxonomy multi) → stringify each, join.
		if ( is_array( $value ) ) {
			$items = array_map( [ $this, 'stringify' ], $value );
			return implode( ', ', array_filter( $items, 'strlen' ) );
		}

		return '';
	}
}
