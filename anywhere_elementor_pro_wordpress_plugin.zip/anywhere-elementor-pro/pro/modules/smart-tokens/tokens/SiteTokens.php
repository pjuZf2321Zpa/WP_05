<?php

namespace Aepro\Modules\SmartTokens\Tokens;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Aepro\Modules\SmartTokens\Core\Registry;

/**
 * Built-in site tokens: {{site.*}}
 */
final class SiteTokens {

	public function register( Registry $registry ): void {
		$registry->register_group(
			'site',
			[
				'label'    => __( 'Site', 'ae-pro' ),
				'icon'     => 'eicon-globe',
				'priority' => 10,
			]
		);

		$registry->register_token(
			'site.title',
			[
				'label'       => __( 'Site Title', 'ae-pro' ),
				'group'       => 'site',
				'description' => __( 'The site name from WordPress settings.', 'ae-pro' ),
				'resolver'    => [ $this, 'resolve_title' ],
				'type'        => 'text',
			]
		);

		$registry->register_token(
			'site.tagline',
			[
				'label'       => __( 'Site Tagline', 'ae-pro' ),
				'group'       => 'site',
				'description' => __( 'The site tagline (description) from WordPress settings.', 'ae-pro' ),
				'resolver'    => [ $this, 'resolve_tagline' ],
				'type'        => 'text',
			]
		);

		$registry->register_token(
			'site.url',
			[
				'label'       => __( 'Site URL', 'ae-pro' ),
				'group'       => 'site',
				'description' => __( 'The home URL of this site.', 'ae-pro' ),
				'resolver'    => [ $this, 'resolve_url' ],
				'type'        => 'url',
			]
		);
	}

	public function resolve_title(): string {
		return get_bloginfo( 'name' );
	}

	public function resolve_tagline(): string {
		return get_bloginfo( 'description' );
	}

	public function resolve_url(): string {
		return home_url( '/' );
	}
}
