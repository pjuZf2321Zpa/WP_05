<?php

namespace Aepro\Modules\SmartTokens\Tokens;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Aepro\Modules\SmartTokens\Core\Registry;

/**
 * Built-in user tokens: {{user.*}}
 *
 * Always resolves against the currently logged-in user.
 * Returns empty string when no user is authenticated.
 */
final class UserTokens {

	public function register( Registry $registry ): void {
		$registry->register_group(
			'user',
			[
				'label'    => __( 'User', 'ae-pro' ),
				'icon'     => 'eicon-user-circle-o',
				'priority' => 30,
			]
		);

		$tokens = [
			'user.id' => [
				'label'       => __( 'User ID', 'ae-pro' ),
				'description' => __( 'The ID of the currently logged-in user.', 'ae-pro' ),
				'resolver'    => [ $this, 'resolve_id' ],
			],
			'user.login' => [
				'label'       => __( 'Username', 'ae-pro' ),
				'description' => __( 'The login username of the current user.', 'ae-pro' ),
				'resolver'    => [ $this, 'resolve_login' ],
			],
			'user.email' => [
				'label'       => __( 'User Email', 'ae-pro' ),
				'description' => __( 'The email address of the current user.', 'ae-pro' ),
				'resolver'    => [ $this, 'resolve_email' ],
			],
			'user.first_name' => [
				'label'       => __( 'First Name', 'ae-pro' ),
				'description' => __( 'The first name of the current user.', 'ae-pro' ),
				'resolver'    => [ $this, 'resolve_first_name' ],
			],
			'user.last_name' => [
				'label'       => __( 'Last Name', 'ae-pro' ),
				'description' => __( 'The last name of the current user.', 'ae-pro' ),
				'resolver'    => [ $this, 'resolve_last_name' ],
			],
			'user.display_name' => [
				'label'       => __( 'Display Name', 'ae-pro' ),
				'description' => __( 'The display name of the current user.', 'ae-pro' ),
				'resolver'    => [ $this, 'resolve_display_name' ],
			],
			'user.role' => [
				'label'       => __( 'User Role', 'ae-pro' ),
				'description' => __( 'The primary role of the current user.', 'ae-pro' ),
				'resolver'    => [ $this, 'resolve_role' ],
			],
			'user.avatar_url' => [
				'label'       => __( 'Avatar URL', 'ae-pro' ),
				'description' => __( 'The Gravatar URL of the current user.', 'ae-pro' ),
				'resolver'    => [ $this, 'resolve_avatar_url' ],
				'type'        => 'url',
			],
		];

		foreach ( $tokens as $key => $config ) {
			$config['group'] = 'user';
			$config['type']  = $config['type'] ?? 'text';
			$registry->register_token( $key, $config );
		}
	}

	private function get_user(): ?\WP_User {
		$user = wp_get_current_user();
		return ( $user instanceof \WP_User && $user->exists() ) ? $user : null;
	}

	public function resolve_id(): string {
		$user = $this->get_user();
		return $user ? (string) $user->ID : '';
	}

	public function resolve_login(): string {
		$user = $this->get_user();
		return $user ? $user->user_login : '';
	}

	public function resolve_email(): string {
		$user = $this->get_user();
		return $user ? $user->user_email : '';
	}

	public function resolve_first_name(): string {
		$user = $this->get_user();
		return $user ? (string) get_user_meta( $user->ID, 'first_name', true ) : '';
	}

	public function resolve_last_name(): string {
		$user = $this->get_user();
		return $user ? (string) get_user_meta( $user->ID, 'last_name', true ) : '';
	}

	public function resolve_display_name(): string {
		$user = $this->get_user();
		return $user ? $user->display_name : '';
	}

	public function resolve_role(): string {
		$user = $this->get_user();
		if ( ! $user ) {
			return '';
		}
		$roles = (array) $user->roles;
		return (string) reset( $roles );
	}

	public function resolve_avatar_url(): string {
		$user = $this->get_user();
		if ( ! $user ) {
			return '';
		}
		$url = get_avatar_url( $user->ID, [ 'size' => 96 ] );
		return $url ?: '';
	}
}
