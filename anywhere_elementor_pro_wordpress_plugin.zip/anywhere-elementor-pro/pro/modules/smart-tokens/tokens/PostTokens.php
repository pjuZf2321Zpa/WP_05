<?php

namespace Aepro\Modules\SmartTokens\Tokens;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Aepro\Modules\SmartTokens\Core\Registry;
use Aepro\Modules\SmartTokens\Core\Context;

/**
 * Built-in post tokens: {{post.*}}
 */
final class PostTokens {

	public function register( Registry $registry ): void {
		$registry->register_group(
			'post',
			[
				'label'    => __( 'Post', 'ae-pro' ),
				'icon'     => 'eicon-post',
				'priority' => 20,
			]
		);

		$tokens = [
			'post.id' => [
				'label'       => __( 'Post ID', 'ae-pro' ),
				'description' => __( 'The numeric ID of the current post.', 'ae-pro' ),
				'resolver'    => [ $this, 'resolve_id' ],
			],
			'post.title' => [
				'label'       => __( 'Post Title', 'ae-pro' ),
				'description' => __( 'The title of the current post.', 'ae-pro' ),
				'resolver'    => [ $this, 'resolve_title' ],
			],
			'post.slug' => [
				'label'       => __( 'Post Slug', 'ae-pro' ),
				'description' => __( 'The URL slug of the current post.', 'ae-pro' ),
				'resolver'    => [ $this, 'resolve_slug' ],
			],
			'post.excerpt' => [
				'label'       => __( 'Post Excerpt', 'ae-pro' ),
				'description' => __( 'The excerpt of the current post.', 'ae-pro' ),
				'resolver'    => [ $this, 'resolve_excerpt' ],
			],
			'post.featured_image' => [
				'label'       => __( 'Featured Image URL', 'ae-pro' ),
				'description' => __( 'The URL of the current post\'s featured image.', 'ae-pro' ),
				'resolver'    => [ $this, 'resolve_featured_image' ],
				'type'        => 'url',
			],
			'post.url' => [
				'label'       => __( 'Post URL', 'ae-pro' ),
				'description' => __( 'The permalink of the current post.', 'ae-pro' ),
				'resolver'    => [ $this, 'resolve_url' ],
				'type'        => 'url',
			],
			'post.type' => [
				'label'       => __( 'Post Type', 'ae-pro' ),
				'description' => __( 'The post type slug of the current post.', 'ae-pro' ),
				'resolver'    => [ $this, 'resolve_type' ],
			],
			'post.status' => [
				'label'       => __( 'Post Status', 'ae-pro' ),
				'description' => __( 'The publication status of the current post.', 'ae-pro' ),
				'resolver'    => [ $this, 'resolve_status' ],
			],
			'post.date' => [
				'label'       => __( 'Post Date', 'ae-pro' ),
				'description' => __( 'The published date of the current post.', 'ae-pro' ),
				'resolver'    => [ $this, 'resolve_date' ],
			],
			'post.modified_date' => [
				'label'       => __( 'Post Modified Date', 'ae-pro' ),
				'description' => __( 'The last modified date of the current post.', 'ae-pro' ),
				'resolver'    => [ $this, 'resolve_modified_date' ],
			],
			'post.author_name' => [
				'label'       => __( 'Post Author Name', 'ae-pro' ),
				'description' => __( 'The display name of the post author.', 'ae-pro' ),
				'resolver'    => [ $this, 'resolve_author_name' ],
			],
		];

		foreach ( $tokens as $key => $config ) {
			$config['group'] = 'post';
			$config['type']  = $config['type'] ?? 'text';
			$registry->register_token( $key, $config );
		}
	}

	private function get_post(): ?\WP_Post {
		return Context::current_post();
	}

	public function resolve_id(): string {
		$post = $this->get_post();
		return $post ? (string) $post->ID : '';
	}

	public function resolve_title(): string {
		$post = $this->get_post();
		return $post ? get_the_title( $post->ID ) : '';
	}

	public function resolve_slug(): string {
		$post = $this->get_post();
		return $post ? $post->post_name : '';
	}

	public function resolve_excerpt(): string {
		$post = $this->get_post();
		if ( ! $post ) {
			return '';
		}
		if ( $post->post_excerpt ) {
			return $post->post_excerpt;
		}
		return wp_trim_words( strip_shortcodes( $post->post_content ), 55 );
	}

	public function resolve_featured_image(): string {
		$post = $this->get_post();
		if ( ! $post ) {
			return '';
		}
		$image = get_the_post_thumbnail_url( $post->ID, 'full' );
		return $image ?: '';
	}

	public function resolve_url(): string {
		$post = $this->get_post();
		return $post ? (string) get_permalink( $post->ID ) : '';
	}

	public function resolve_type(): string {
		$post = $this->get_post();
		return $post ? $post->post_type : '';
	}

	public function resolve_status(): string {
		$post = $this->get_post();
		return $post ? $post->post_status : '';
	}

	public function resolve_date(): string {
		$post = $this->get_post();
		if ( ! $post ) {
			return '';
		}
		return get_the_date( get_option( 'date_format' ), $post->ID );
	}

	public function resolve_modified_date(): string {
		$post = $this->get_post();
		if ( ! $post ) {
			return '';
		}
		return get_the_modified_date( get_option( 'date_format' ), $post->ID );
	}

	public function resolve_author_name(): string {
		$post = $this->get_post();
		if ( ! $post ) {
			return '';
		}
		$author = get_userdata( (int) $post->post_author );
		return $author ? $author->display_name : '';
	}
}
