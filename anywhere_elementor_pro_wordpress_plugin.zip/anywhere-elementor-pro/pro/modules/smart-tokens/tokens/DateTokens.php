<?php

namespace Aepro\Modules\SmartTokens\Tokens;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Aepro\Modules\SmartTokens\Core\Registry;

/**
 * Built-in date/time tokens: {{current.*}}
 *
 * All values use the site's configured timezone and the date/time format
 * settings from WordPress Settings → General.
 */
final class DateTokens {

	public function register( Registry $registry ): void {
		$registry->register_group(
			'current',
			[
				'label'    => __( 'Date & Time', 'ae-pro' ),
				'icon'     => 'eicon-calendar',
				'priority' => 50,
			]
		);

		$tokens = [
			'current.date' => [
				'label'       => __( 'Current Date', 'ae-pro' ),
				'description' => __( 'Today\'s date in the site\'s date format.', 'ae-pro' ),
				'resolver'    => [ $this, 'resolve_date' ],
			],
			'current.time' => [
				'label'       => __( 'Current Time', 'ae-pro' ),
				'description' => __( 'Current time in the site\'s time format.', 'ae-pro' ),
				'resolver'    => [ $this, 'resolve_time' ],
			],
			'current.year' => [
				'label'       => __( 'Current Year', 'ae-pro' ),
				'description' => __( 'The current 4-digit year.', 'ae-pro' ),
				'resolver'    => [ $this, 'resolve_year' ],
			],
			'current.month' => [
				'label'       => __( 'Current Month', 'ae-pro' ),
				'description' => __( 'The current month name.', 'ae-pro' ),
				'resolver'    => [ $this, 'resolve_month' ],
			],
			'current.day' => [
				'label'       => __( 'Current Day', 'ae-pro' ),
				'description' => __( 'The current day of the month (01–31).', 'ae-pro' ),
				'resolver'    => [ $this, 'resolve_day' ],
			],
			'current.day_name' => [
				'label'       => __( 'Current Day Name', 'ae-pro' ),
				'description' => __( 'The full name of the current weekday.', 'ae-pro' ),
				'resolver'    => [ $this, 'resolve_day_name' ],
			],
			'current.timestamp' => [
				'label'       => __( 'Current Timestamp', 'ae-pro' ),
				'description' => __( 'Unix timestamp for the current moment.', 'ae-pro' ),
				'resolver'    => [ $this, 'resolve_timestamp' ],
			],
		];

		foreach ( $tokens as $key => $config ) {
			$config['group'] = 'current';
			$config['type']  = 'text';
			$registry->register_token( $key, $config );
		}
	}

	private function now(): \DateTime {
		return new \DateTime( 'now', wp_timezone() );
	}

	public function resolve_date(): string {
		return wp_date( get_option( 'date_format' ) );
	}

	public function resolve_time(): string {
		return wp_date( get_option( 'time_format' ) );
	}

	public function resolve_year(): string {
		return $this->now()->format( 'Y' );
	}

	public function resolve_month(): string {
		return $this->now()->format( 'F' );
	}

	public function resolve_day(): string {
		return $this->now()->format( 'd' );
	}

	public function resolve_day_name(): string {
		return $this->now()->format( 'l' );
	}

	public function resolve_timestamp(): string {
		return (string) time();
	}
}
