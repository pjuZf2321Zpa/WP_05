<?php

namespace Aepro\Modules\SmartTokens\Tokens;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Aepro\Modules\SmartTokens\Core\Registry;
use Aepro\Modules\SmartTokens\Core\Context;

/**
 * WooCommerce token group: {{woo.*}}
 *
 * All resolvers are null-safe — they return '' when WooCommerce is inactive
 * or when the required data (cart, product) is unavailable.
 *
 * Supported tokens:
 *   Cart:     woo.cart_total, woo.cart_count, woo.cart_subtotal
 *   Product:  woo.product.price, woo.product.sale_price, woo.product.sku,
 *             woo.product.stock_status, woo.product.stock_quantity,
 *             woo.product.name, woo.product.short_description, woo.product.url
 *   Customer: woo.customer.first_name, woo.customer.last_name, woo.customer.email
 */
final class WooTokens {

	public function register( Registry $registry ): void {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return; // WooCommerce not active — skip silently.
		}

		$registry->register_group(
			'woo',
			[
				'label'    => __( 'WooCommerce', 'ae-pro' ),
				'icon'     => 'eicon-cart-medium',
				'priority' => 80,
			]
		);

		$tokens = [
			// Cart
			'woo.cart_total' => [
				'label'       => __( 'Cart Total', 'ae-pro' ),
				'description' => __( 'Formatted cart total including currency symbol.', 'ae-pro' ),
				'resolver'    => [ $this, 'resolve_cart_total' ],
			],
			'woo.cart_subtotal' => [
				'label'       => __( 'Cart Subtotal', 'ae-pro' ),
				'description' => __( 'Formatted cart subtotal (before shipping/tax).', 'ae-pro' ),
				'resolver'    => [ $this, 'resolve_cart_subtotal' ],
			],
			'woo.cart_count' => [
				'label'       => __( 'Cart Item Count', 'ae-pro' ),
				'description' => __( 'Number of items in the cart.', 'ae-pro' ),
				'resolver'    => [ $this, 'resolve_cart_count' ],
			],
			// Product
			'woo.product.name' => [
				'label'       => __( 'Product Name', 'ae-pro' ),
				'description' => __( 'The name of the current product.', 'ae-pro' ),
				'resolver'    => [ $this, 'resolve_product_name' ],
			],
			'woo.product.price' => [
				'label'       => __( 'Product Price', 'ae-pro' ),
				'description' => __( 'Formatted current price (sale or regular).', 'ae-pro' ),
				'resolver'    => [ $this, 'resolve_product_price' ],
			],
			'woo.product.regular_price' => [
				'label'       => __( 'Product Regular Price', 'ae-pro' ),
				'description' => __( 'Formatted regular (non-sale) price.', 'ae-pro' ),
				'resolver'    => [ $this, 'resolve_product_regular_price' ],
			],
			'woo.product.sale_price' => [
				'label'       => __( 'Product Sale Price', 'ae-pro' ),
				'description' => __( 'Formatted sale price, empty if product is not on sale.', 'ae-pro' ),
				'resolver'    => [ $this, 'resolve_product_sale_price' ],
			],
			'woo.product.sku' => [
				'label'       => __( 'Product SKU', 'ae-pro' ),
				'description' => __( 'The SKU of the current product.', 'ae-pro' ),
				'resolver'    => [ $this, 'resolve_product_sku' ],
			],
			'woo.product.stock_status' => [
				'label'       => __( 'Product Stock Status', 'ae-pro' ),
				'description' => __( 'Stock status: instock, outofstock, or onbackorder.', 'ae-pro' ),
				'resolver'    => [ $this, 'resolve_product_stock_status' ],
			],
			'woo.product.stock_quantity' => [
				'label'       => __( 'Product Stock Quantity', 'ae-pro' ),
				'description' => __( 'Number of units in stock.', 'ae-pro' ),
				'resolver'    => [ $this, 'resolve_product_stock_quantity' ],
			],
			'woo.product.short_description' => [
				'label'       => __( 'Product Short Description', 'ae-pro' ),
				'description' => __( 'The short description of the current product.', 'ae-pro' ),
				'resolver'    => [ $this, 'resolve_product_short_description' ],
			],
			'woo.product.url' => [
				'label'       => __( 'Product URL', 'ae-pro' ),
				'description' => __( 'The permalink of the current product.', 'ae-pro' ),
				'resolver'    => [ $this, 'resolve_product_url' ],
				'type'        => 'url',
			],
			// Customer
			'woo.customer.first_name' => [
				'label'       => __( 'Customer First Name', 'ae-pro' ),
				'description' => __( 'The billing first name of the current customer.', 'ae-pro' ),
				'resolver'    => [ $this, 'resolve_customer_first_name' ],
			],
			'woo.customer.last_name' => [
				'label'       => __( 'Customer Last Name', 'ae-pro' ),
				'description' => __( 'The billing last name of the current customer.', 'ae-pro' ),
				'resolver'    => [ $this, 'resolve_customer_last_name' ],
			],
			'woo.customer.email' => [
				'label'       => __( 'Customer Email', 'ae-pro' ),
				'description' => __( 'The billing email of the current customer.', 'ae-pro' ),
				'resolver'    => [ $this, 'resolve_customer_email' ],
			],
		];

		foreach ( $tokens as $key => $config ) {
			$config['group'] = 'woo';
			$config['type']  = $config['type'] ?? 'text';
			$registry->register_token( $key, $config );
		}
	}

	// ── Cart ─────────────────────────────────────────────────────────────────

	private function get_cart(): ?\WC_Cart {
		return function_exists( 'WC' ) && WC()->cart instanceof \WC_Cart ? WC()->cart : null;
	}

	public function resolve_cart_total(): string {
		$cart = $this->get_cart();
		return $cart ? (string) $cart->get_cart_total() : '';
	}

	public function resolve_cart_subtotal(): string {
		$cart = $this->get_cart();
		return $cart ? (string) $cart->get_cart_subtotal() : '';
	}

	public function resolve_cart_count(): string {
		$cart = $this->get_cart();
		return $cart ? (string) $cart->get_cart_contents_count() : '0';
	}

	// ── Product ───────────────────────────────────────────────────────────────

	private function get_product(): ?\WC_Product {
		$post = Context::current_post();
		if ( ! $post ) {
			global $product;
			return $product instanceof \WC_Product ? $product : null;
		}
		$product = wc_get_product( $post->ID );
		return $product instanceof \WC_Product ? $product : null;
	}

	public function resolve_product_name(): string {
		$product = $this->get_product();
		return $product ? $product->get_name() : '';
	}

	public function resolve_product_price(): string {
		$product = $this->get_product();
		return $product ? wc_price( $product->get_price() ) : '';
	}

	public function resolve_product_regular_price(): string {
		$product = $this->get_product();
		return $product ? wc_price( $product->get_regular_price() ) : '';
	}

	public function resolve_product_sale_price(): string {
		$product = $this->get_product();
		if ( ! $product || ! $product->is_on_sale() ) {
			return '';
		}
		return wc_price( $product->get_sale_price() );
	}

	public function resolve_product_sku(): string {
		$product = $this->get_product();
		return $product ? $product->get_sku() : '';
	}

	public function resolve_product_stock_status(): string {
		$product = $this->get_product();
		return $product ? $product->get_stock_status() : '';
	}

	public function resolve_product_stock_quantity(): string {
		$product = $this->get_product();
		if ( ! $product ) {
			return '';
		}
		$qty = $product->get_stock_quantity();
		return null !== $qty ? (string) $qty : '';
	}

	public function resolve_product_short_description(): string {
		$product = $this->get_product();
		return $product ? $product->get_short_description() : '';
	}

	public function resolve_product_url(): string {
		$product = $this->get_product();
		return $product ? (string) get_permalink( $product->get_id() ) : '';
	}

	// ── Customer ──────────────────────────────────────────────────────────────

	private function get_customer(): ?\WC_Customer {
		if ( ! function_exists( 'WC' ) || ! WC()->customer instanceof \WC_Customer ) {
			return null;
		}
		return WC()->customer;
	}

	public function resolve_customer_first_name(): string {
		$customer = $this->get_customer();
		return $customer ? $customer->get_billing_first_name() : '';
	}

	public function resolve_customer_last_name(): string {
		$customer = $this->get_customer();
		return $customer ? $customer->get_billing_last_name() : '';
	}

	public function resolve_customer_email(): string {
		$customer = $this->get_customer();
		return $customer ? $customer->get_billing_email() : '';
	}
}
