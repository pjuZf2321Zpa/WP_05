<?php

namespace Aepro\Modules\SmartTokens\Tokens;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Aepro\Modules\SmartTokens\Core\Registry;

/**
 * Built-in URL tokens: {{url.*}}
 *
 * Supports dynamic query-parameter resolution:
 *   {{url.parameter.product_id}}  → sanitize_key( $_GET['product_id'] )
 */
final class UrlTokens {

	public function register( Registry $registry ): void {
		$registry->register_group(
			'url',
			[
				'label'    => __( 'URL', 'ae-pro' ),
				'icon'     => 'eicon-link',
				'priority' => 40,
			]
		);

		$registry->register_token(
			'url.current',
			[
				'label'       => __( 'Current URL', 'ae-pro' ),
				'group'       => 'url',
				'description' => __( 'The full URL of the current page.', 'ae-pro' ),
				'resolver'    => [ $this, 'resolve_current' ],
				'type'        => 'url',
			]
		);

		$registry->register_token(
			'url.path',
			[
				'label'       => __( 'URL Path', 'ae-pro' ),
				'group'       => 'url',
				'description' => __( 'The path portion of the current URL (without domain).', 'ae-pro' ),
				'resolver'    => [ $this, 'resolve_path' ],
				'type'        => 'text',
			]
		);

		// Dynamic token — matches url.parameter.{anything}
		$registry->register_token(
			'url.parameter.*',
			[
				'label'       => __( 'URL Parameter', 'ae-pro' ),
				'group'       => 'url',
				'description' => __( 'A query string parameter. Usage: {{url.parameter.my_param}}', 'ae-pro' ),
				'resolver'    => [ $this, 'resolve_parameter' ],
				'type'        => 'text',
				'dynamic'     => true,
			]
		);
	}

	public function resolve_current(): string {
		global $wp;
		return home_url( add_query_arg( [], $wp->request ?? '' ) );
	}

	public function resolve_path(): string {
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$request_uri = isset( $_SERVER['REQUEST_URI'] )
			? wp_parse_url( wp_unslash( $_SERVER['REQUEST_URI'] ), PHP_URL_PATH )
			: '';

		return sanitize_text_field( (string) $request_uri );
	}

	/**
	 * @param string $key  Full token key, e.g. 'url.parameter.product_id'
	 */
	public function resolve_parameter( string $key ): string {
		// Strip the 'url.parameter.' prefix to get the param name.
		$param = substr( $key, strlen( 'url.parameter.' ) );
		$param = sanitize_key( $param );

		if ( '' === $param ) {
			return '';
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( ! isset( $_GET[ $param ] ) ) {
			return '';
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return sanitize_text_field( wp_unslash( $_GET[ $param ] ) );
	}
}
