<?php

namespace Aepro\Modules\SmartTokens\Tokens;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Aepro\Modules\SmartTokens\Core\Registry;

/**
 * Built-in query tokens: {{query.*}}
 *
 * Resolves against the main WordPress query ($wp_query).
 */
final class QueryTokens {

	public function register( Registry $registry ): void {
		$registry->register_group(
			'query',
			[
				'label'    => __( 'Query', 'ae-pro' ),
				'icon'     => 'eicon-search',
				'priority' => 60,
			]
		);

		$tokens = [
			'query.id' => [
				'label'       => __( 'Queried Object ID', 'ae-pro' ),
				'description' => __( 'The ID of the current queried object (post, term, user…).', 'ae-pro' ),
				'resolver'    => [ $this, 'resolve_id' ],
			],
			'query.post_count' => [
				'label'       => __( 'Post Count', 'ae-pro' ),
				'description' => __( 'Number of posts found in the current main query.', 'ae-pro' ),
				'resolver'    => [ $this, 'resolve_post_count' ],
			],
			'query.found_posts' => [
				'label'       => __( 'Total Found Posts', 'ae-pro' ),
				'description' => __( 'Total posts matching the main query (before pagination).', 'ae-pro' ),
				'resolver'    => [ $this, 'resolve_found_posts' ],
			],
			'query.max_num_pages' => [
				'label'       => __( 'Max Pages', 'ae-pro' ),
				'description' => __( 'Total number of pages in the main query.', 'ae-pro' ),
				'resolver'    => [ $this, 'resolve_max_pages' ],
			],
			'query.current_page' => [
				'label'       => __( 'Current Page', 'ae-pro' ),
				'description' => __( 'The current pagination page number.', 'ae-pro' ),
				'resolver'    => [ $this, 'resolve_current_page' ],
			],
			'query.is_singular' => [
				'label'       => __( 'Is Singular', 'ae-pro' ),
				'description' => __( 'Returns "1" when viewing a single post/page, "0" otherwise.', 'ae-pro' ),
				'resolver'    => [ $this, 'resolve_is_singular' ],
			],
			'query.is_archive' => [
				'label'       => __( 'Is Archive', 'ae-pro' ),
				'description' => __( 'Returns "1" when viewing an archive, "0" otherwise.', 'ae-pro' ),
				'resolver'    => [ $this, 'resolve_is_archive' ],
			],
			'query.search_query' => [
				'label'       => __( 'Search Query', 'ae-pro' ),
				'description' => __( 'The current search term when on a search results page.', 'ae-pro' ),
				'resolver'    => [ $this, 'resolve_search_query' ],
			],
		];

		foreach ( $tokens as $key => $config ) {
			$config['group'] = 'query';
			$config['type']  = 'text';
			$registry->register_token( $key, $config );
		}
	}

	public function resolve_id(): string {
		$obj = get_queried_object();
		if ( $obj instanceof \WP_Post ) {
			return (string) $obj->ID;
		}
		if ( $obj instanceof \WP_Term ) {
			return (string) $obj->term_id;
		}
		if ( $obj instanceof \WP_User ) {
			return (string) $obj->ID;
		}
		return '';
	}

	public function resolve_post_count(): string {
		global $wp_query;
		return isset( $wp_query->post_count ) ? (string) $wp_query->post_count : '0';
	}

	public function resolve_found_posts(): string {
		global $wp_query;
		return isset( $wp_query->found_posts ) ? (string) $wp_query->found_posts : '0';
	}

	public function resolve_max_pages(): string {
		global $wp_query;
		return isset( $wp_query->max_num_pages ) ? (string) $wp_query->max_num_pages : '1';
	}

	public function resolve_current_page(): string {
		return (string) max( 1, get_query_var( 'paged', 1 ) );
	}

	public function resolve_is_singular(): string {
		return is_singular() ? '1' : '0';
	}

	public function resolve_is_archive(): string {
		return is_archive() ? '1' : '0';
	}

	public function resolve_search_query(): string {
		return sanitize_text_field( get_search_query() );
	}
}
