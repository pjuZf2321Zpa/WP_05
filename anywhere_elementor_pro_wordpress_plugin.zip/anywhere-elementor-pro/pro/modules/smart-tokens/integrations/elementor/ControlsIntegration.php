<?php

namespace Aepro\Modules\SmartTokens\Integrations\Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Aepro\Modules\SmartTokens\Smart_Tokens;
use Aepro\Modules\SmartTokens\Core\Parser;

final class ControlsIntegration {

	const ATOMIC_CONTAINER_TYPES = [ 'e-div-block', 'e-flexbox', 'e-grid' ];

	public function register_hooks(): void {
		if ( ! did_action( 'elementor/loaded' ) ) {
			return;
		}

		add_filter( 'elementor/widget/render_content', [ $this, 'parse_widget_content' ], 20, 2 );

		// css_classes and _element_id must be resolved here — Elementor calls
		// add_render_attributes() immediately after this action, before the
		// type-specific before_render fires, so the type-specific hooks are too late.
		add_action( 'elementor/frontend/before_render', [ $this, 'process_wrapper_tokens' ], 10, 1 );

		add_action( 'elementor/frontend/widget/before_render', [ $this, 'process_widget_before_render' ], 10, 1 );
		add_action( 'elementor/frontend/section/before_render', [ $this, 'process_element_before_render' ], 10, 1 );
		add_action( 'elementor/frontend/column/before_render', [ $this, 'process_element_before_render' ], 10, 1 );
		add_action( 'elementor/frontend/container/before_render', [ $this, 'process_element_before_render' ], 10, 1 );

		// Elementor 4 (atomic) containers: no rendered content passes through
		// the widget filter above, so resolve tokens in their link and custom
		// attributes before they render.
		foreach ( self::ATOMIC_CONTAINER_TYPES as $type ) {
			add_action( "elementor/frontend/{$type}/before_render", [ $this, 'process_atomic_container' ], 10, 1 );
		}

		// Elements whose settings hold tokens render differently per post.
		add_filter( 'elementor/element/is_dynamic_content', [ $this, 'is_dynamic_content' ], 10, 2 );
	}

	public function process_wrapper_tokens( \Elementor\Element_Base $element ): void {
		$settings = $element->get_settings();
		$changed  = false;

		if ( ! empty( $settings['_element_id'] ) && Parser::has_tokens( $settings['_element_id'] ) ) {
			$element->set_settings(
				'_element_id',
				Smart_Tokens::parse( $settings['_element_id'], 'attr' )
			);
			$changed = true;
		}

		// Widgets use '_css_classes'; sections/columns/containers use 'css_classes'.
		foreach ( [ '_css_classes', 'css_classes' ] as $key ) {
			if ( ! empty( $settings[ $key ] ) && Parser::has_tokens( $settings[ $key ] ) ) {
				$element->set_settings( $key, Smart_Tokens::parse( $settings[ $key ], 'attr' ) );
				$changed = true;
			}
		}

		if ( $changed && method_exists( $element, 'reset_render_state' ) ) {
			$element->reset_render_state();
		}
	}

	public function parse_widget_content( string $widget_content, \Elementor\Widget_Base $widget ): string {
		if ( ! Parser::has_tokens( $widget_content ) ) {
			return $widget_content;
		}

		return Smart_Tokens::parse( $widget_content, 'html' );
	}

	public function process_widget_before_render( \Elementor\Widget_Base $widget ): void {
		$this->process_element_settings( $widget );
	}

	public function process_element_before_render( \Elementor\Element_Base $element ): void {
		$this->process_element_settings( $element );
	}

	private function process_element_settings( \Elementor\Element_Base $element ): void {
		$settings = $element->get_settings();
		if ( ! empty( $settings['_attributes'] ) && is_array( $settings['_attributes'] ) ) {
			$changed    = false;
			$attributes = $settings['_attributes'];

			foreach ( $attributes as $index => $attr ) {
				if ( ! empty( $attr['key'] ) && Parser::has_tokens( $attr['key'] ) ) {
					$attributes[ $index ]['key'] = Smart_Tokens::parse( $attr['key'], 'attr' );
					$changed = true;
				}
				if ( ! empty( $attr['value'] ) && Parser::has_tokens( $attr['value'] ) ) {
					$attributes[ $index ]['value'] = Smart_Tokens::parse( $attr['value'], 'attr' );
					$changed = true;
				}
			}

			if ( $changed ) {
				$element->set_settings( '_attributes', $attributes );
			}
		}

		// esc_url() strips {{ and }} — parse link controls before Elementor renders them.
		$link_changed = false;
		foreach ( $settings as $key => $value ) {
			if ( is_array( $value ) && isset( $value['url'] ) && Parser::has_tokens( $value['url'] ) ) {
				$value['url'] = Smart_Tokens::parse( $value['url'], 'url' );
				$element->set_settings( $key, $value );
				$link_changed = true;
			}
		}

		if ( $link_changed && method_exists( $element, 'reset_render_state' ) ) {
			$element->reset_render_state();
		}
	}

	/**
	 * Resolves tokens in an Elementor 4 container's link (`link` →
	 * `destination`) and custom attributes (`attributes` key / value), which
	 * are stored as typed props: { "$$type": "url", "value": "{{post.url}}" }.
	 */
	public function process_atomic_container( \Elementor\Element_Base $element ): void {
		$settings = $element->get_settings();

		foreach ( [ 'link', 'attributes' ] as $key ) {
			if ( empty( $settings[ $key ] ) || ! is_array( $settings[ $key ] ) ) {
				continue;
			}

			$changed = false;
			$value   = $this->parse_atomic_value( $settings[ $key ], $changed );

			if ( $changed ) {
				$element->set_settings( $key, $value );
			}
		}
	}

	/**
	 * Walks a typed prop value and parses every string that holds tokens.
	 * URL-typed strings are parsed in the 'url' context, the rest as 'attr'.
	 */
	private function parse_atomic_value( array $value, bool &$changed ): array {
		$type = $value['$$type'] ?? null;

		foreach ( $value as $key => $child ) {
			if ( is_array( $child ) ) {
				$value[ $key ] = $this->parse_atomic_value( $child, $changed );
			} elseif ( 'value' === $key && is_string( $child ) && Parser::has_tokens( $child ) ) {
				$value[ $key ] = Smart_Tokens::parse( $child, 'url' === $type ? 'url' : 'attr' );
				$changed       = true;
			}
		}

		return $value;
	}

	public function is_dynamic_content( $is_dynamic, $raw_data ) {
		if ( $is_dynamic || empty( $raw_data['settings'] ) ) {
			return $is_dynamic;
		}

		$settings = wp_json_encode( $raw_data['settings'] );

		return is_string( $settings ) && Parser::has_tokens( $settings );
	}

}
