<?php

namespace Aepro\Modules\SmartTokens\Integrations\Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Aepro\Modules\SmartTokens\Smart_Tokens;

/**
 * Elementor Editor Integration.
 *
 * Responsibilities:
 *  - Enqueue the token-picker JS + CSS into the Elementor editor.
 *  - Provide a REST endpoint that serves the full token catalogue as JSON
 *    so the JS UI can render the grouped token browser without a PHP roundtrip.
 *
 * REST endpoint:
 *   GET /wp-json/dynific/v1/smart-tokens/tokens
 *   Permission: edit_posts
 *   Response: { groups: { id: { label, icon, tokens: { key: {label,description,type} } } } }
 */
final class EditorIntegration {

	public function register_hooks(): void {
		add_action( 'rest_api_init', [ $this, 'register_rest_routes' ] );
		add_action( 'elementor/editor/after_enqueue_scripts', [ $this, 'enqueue_editor_assets' ] );
	}

	// ── REST API ─────────────────────────────────────────────────────────────

	public function register_rest_routes(): void {
		register_rest_route(
			'dynific/v1',
			'/smart-tokens/tokens',
			[
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => [ $this, 'rest_get_tokens' ],
				'permission_callback' => [ $this, 'rest_permission' ],
			]
		);

		register_rest_route(
			'dynific/v1',
			'/smart-tokens/preview',
			[
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => [ $this, 'rest_preview_token' ],
				'permission_callback' => [ $this, 'rest_permission' ],
				'args'                => [
					'token' => [
						'required'          => true,
						'sanitize_callback' => 'sanitize_text_field',
						'validate_callback' => static fn( string $v ): bool => (bool) preg_match(
							'/^[a-z][a-z0-9_]*(?:\.[a-z0-9_*]+)+$/',
							$v
						),
					],
					'post_id' => [
						'required'          => false,
						'sanitize_callback' => 'absint',
						'default'           => 0,
					],
				],
			]
		);
	}

	public function rest_permission(): bool {
		return current_user_can( 'edit_posts' );
	}

	public function rest_get_tokens( \WP_REST_Request $request ): \WP_REST_Response {
		$grouped = Smart_Tokens::get_grouped_tokens();
		return rest_ensure_response( [ 'groups' => $grouped ] );
	}

	/**
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function rest_preview_token( \WP_REST_Request $request ) {
		$token   = $request->get_param( 'token' );
		$post_id = $request->get_param( 'post_id' );

		// Optionally scope context to a specific post for preview.
		if ( $post_id > 0 ) {
			$post = get_post( $post_id );
			if ( ! $post ) {
				return new \WP_Error(
					'post_not_found',
					__( 'Post not found.', 'ae-pro' ),
					[ 'status' => 404 ]
				);
			}
			$value = \Aepro\Modules\SmartTokens\Core\Context::with(
				'post',
				$post,
				static fn() => Smart_Tokens::parse( '{{' . $token . '}}', 'raw' )
			);
		} else {
			$value = Smart_Tokens::parse( '{{' . $token . '}}', 'raw' );
		}

		return rest_ensure_response( [ 'value' => $value ] );
	}

	// ── Editor Assets ─────────────────────────────────────────────────────────

	public function enqueue_editor_assets(): void {
		$base_url = AE_PRO_URL . 'pro/modules/smart-tokens/assets/';

		wp_enqueue_style(
			'dynific-smart-tokens-editor',
			$base_url . 'css/smart-tokens-editor.css',
			[],
			AE_PRO_VERSION
		);

		wp_enqueue_script(
			'dynific-smart-tokens-editor',
			$base_url . 'js/smart-tokens-editor.js',
			[ 'jquery' ],
			AE_PRO_VERSION,
			true
		);

		wp_localize_script(
			'dynific-smart-tokens-editor',
			'dynificSmartTokens',
			[
				'restUrl'  => rest_url( 'dynific/v1/smart-tokens/' ),
				'nonce'    => wp_create_nonce( 'wp_rest' ),
				'i18n'     => [
					'searchPlaceholder' => __( 'Search tokens…', 'ae-pro' ),
					'noResults'         => __( 'No tokens found.', 'ae-pro' ),
					'clickToInsert'     => __( 'Click to insert', 'ae-pro' ),
					'panelTitle'        => __( 'Smart Tokens', 'ae-pro' ),
					'loading'           => __( 'Loading tokens…', 'ae-pro' ),
					'insertToken'       => __( 'Insert Token', 'ae-pro' ),
				],
			]
		);
	}
}
