<?php

namespace Aepro\Modules\SmartTokens;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Smart Tokens static facade.
 *
 * Provides a clean, globally accessible API for all plugin systems that need
 * to resolve tokens.  All methods delegate to the Module singleton so there
 * is exactly ONE parser and ONE registry throughout the request.
 *
 * ─────────────────────────────────────────────────
 * CORRECT usage (anywhere in the plugin):
 *   Smart_Tokens::parse( $content );
 *   Smart_Tokens::parse( $url, 'url' );
 *   Smart_Tokens::parse( $class, 'attr' );
 *
 * WRONG (never scatter parsing logic):
 *   preg_replace_callback( '/\{\{(.+?)\}\}/', ... )
 * ─────────────────────────────────────────────────
 */
final class Smart_Tokens {

	/**
	 * Parse all {{tokens}} in $content.
	 *
	 * @param string $content  Text, HTML, URL or attribute value containing tokens.
	 * @param string $escape   Output escaping context:
	 *                           'html' — safe for HTML body (default)
	 *                           'attr' — safe for HTML attributes (esc_attr)
	 *                           'url'  — safe for href/src (esc_url)
	 *                           'raw'  — no escaping; only use in trusted PHP code
	 * @return string          Content with all tokens replaced and output escaped.
	 */
	public static function parse( string $content, string $escape = 'html' ): string {
		return Module::instance()->parse( $content, $escape );
	}

	/**
	 * Register a new token at runtime.
	 *
	 * Shorthand so external code doesn't need to reach into the registry directly:
	 *
	 *   Smart_Tokens::register_token( 'my.value', [
	 *       'label'       => 'My Value',
	 *       'group'       => 'my_group',
	 *       'description' => 'Returns something cool.',
	 *       'resolver'    => fn() => 'Hello world!',
	 *   ] );
	 *
	 * Prefer using the dynific/smart_tokens/register_tokens action hook
	 * when registering during plugin init — use this method only for
	 * runtime registration (e.g. from a shortcode handler or REST callback).
	 */
	public static function register_token( string $key, array $config ): bool {
		return Module::instance()->registry()->register_token( $key, $config );
	}

	/**
	 * Return all tokens grouped and sorted for the editor token browser.
	 *
	 * @return array<string, array{ label: string, icon: string, tokens: array }>
	 */
	public static function get_grouped_tokens(): array {
		return Module::instance()->get_grouped_tokens();
	}

	/**
	 * Detect whether a string contains any token patterns without resolving them.
	 * Use this to skip parse() in hot render paths when there are no tokens.
	 */
	public static function has_tokens( string $content ): bool {
		return Core\Parser::has_tokens( $content );
	}

	/**
	 * Return every token key found in $content (without resolving).
	 * Useful for validation, linting, or editor tooling.
	 *
	 * @return list<string>
	 */
	public static function detect_tokens( string $content ): array {
		return Core\Parser::detect_tokens( $content );
	}

	/**
	 * Access the registry directly for advanced use cases.
	 */
	public static function registry(): Core\Registry {
		return Module::instance()->registry();
	}
}
