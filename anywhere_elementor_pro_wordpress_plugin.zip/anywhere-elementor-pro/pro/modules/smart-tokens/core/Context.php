<?php

namespace Aepro\Modules\SmartTokens\Core;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Scoped context engine.
 *
 * Allows token resolvers to read the current "render context" (which post,
 * which user, etc.) without needing global state.  A stack is maintained so
 * nested loops (e.g. ACF repeaters, WP_Query loops) are isolated.
 *
 * Usage:
 *   Context::push( 'post', get_post( 42 ) );
 *   $value = Context::get( 'post' );   // → WP_Post
 *   Context::pop( 'post' );
 *
 * All public methods are static for convenience inside token resolvers.
 */
final class Context {

	/** @var array<string, list<mixed>> Keyed by context type, value is a stack. */
	private static array $stacks = [];

	/** Push a value onto the named context stack. */
	public static function push( string $type, $value ): void {
		self::$stacks[ $type ][] = $value;
	}

	/**
	 * Pop and return the top value of the named context stack.
	 * Returns null if the stack is empty or missing.
	 */
	public static function pop( string $type ) {
		if ( empty( self::$stacks[ $type ] ) ) {
			return null;
		}
		return array_pop( self::$stacks[ $type ] );
	}

	/**
	 * Peek at the top value without removing it.
	 * Returns null when no value has been pushed for that type.
	 */
	public static function get( string $type ) {
		$stack = self::$stacks[ $type ] ?? [];
		return end( $stack ) ?: null;
	}

	/** Return true when the named context has at least one value. */
	public static function has( string $type ): bool {
		return ! empty( self::$stacks[ $type ] );
	}

	/**
	 * Execute $callback within a push/pop pair so the context is always
	 * cleaned up even if an exception is thrown.
	 *
	 * @template T
	 * @param  callable(): T $callback
	 * @return T
	 */
	public static function with( string $type, $value, callable $callback ) {
		self::push( $type, $value );
		try {
			return $callback();
		} finally {
			self::pop( $type );
		}
	}

	/**
	 * Return the WP_Post object for the current post context.
	 *
	 * Falls back to the Elementor frontend document post, then the global
	 * $post, then get_queried_object() for archive pages.
	 */
	public static function current_post(): ?\WP_Post {
		if ( self::has( 'post' ) ) {
			$post = self::get( 'post' );
			return $post instanceof \WP_Post ? $post : null;
		}

		// Elementor editor / preview context
		if ( class_exists( '\Elementor\Plugin' ) ) {
			$document = \Elementor\Plugin::instance()->documents->get_current();
			if ( $document ) {
				$doc_post = get_post( $document->get_main_id() );
				if ( $doc_post instanceof \WP_Post ) {
					return $doc_post;
				}
			}
		}

		global $post;
		if ( $post instanceof \WP_Post ) {
			return $post;
		}

		$queried = get_queried_object();
		return $queried instanceof \WP_Post ? $queried : null;
	}

	/** Clear all context stacks — useful in unit tests. */
	public static function reset(): void {
		self::$stacks = [];
	}
}
