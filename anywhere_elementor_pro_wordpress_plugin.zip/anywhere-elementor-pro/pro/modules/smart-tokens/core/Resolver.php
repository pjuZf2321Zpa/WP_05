<?php

namespace Aepro\Modules\SmartTokens\Core;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Token resolver service.
 *
 * Routes a token key to the registered resolver callback and returns the
 * raw string value.  Does NOT escape output — escaping is the Parser's job.
 *
 * The resolver callback signature is:
 *   function( string $key ): string
 *
 * The full original key is forwarded so dynamic tokens (url.parameter.*)
 * can inspect the trailing segment.
 */
final class Resolver {

	private Registry $registry;

	public function __construct( Registry $registry ) {
		$this->registry = $registry;
	}

	/**
	 * Resolve a token key to its raw string value.
	 *
	 * Returns an empty string for unknown tokens; never throws.
	 *
	 * @param  string $key  e.g. 'post.title' or 'url.parameter.product_id'
	 * @return string       Raw, unescaped resolved value.
	 */
	public function resolve( string $key ): string {
		$token = $this->registry->get_token( $key );

		if ( null === $token ) {
			return '';
		}

		try {
			$raw = (string) call_user_func( $token['resolver'], $key );
		} catch ( \Throwable $e ) {
			$raw = '';
		}

		/**
		 * Allow last-chance filtering of any resolved token value.
		 *
		 * @param string $raw   Resolved raw value.
		 * @param string $key   Token key.
		 * @param array  $token Token config from the registry.
		 */
		return (string) apply_filters( 'dynific/smart_tokens/resolved', $raw, $key, $token );
	}

	/**
	 * Return the token type ('text'|'url'|'html') for a given key.
	 * Used by the Parser to choose the correct escaping function.
	 */
	public function get_token_type( string $key ): string {
		$token = $this->registry->get_token( $key );
		return $token['type'] ?? 'text';
	}
}
