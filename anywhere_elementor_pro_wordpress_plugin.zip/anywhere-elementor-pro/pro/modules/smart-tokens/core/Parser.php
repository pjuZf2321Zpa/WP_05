<?php

namespace Aepro\Modules\SmartTokens\Core;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Centralized Smart Token parser.
 *
 * This is the single entry point for all token replacement in the plugin.
 * NEVER scatter preg_replace_callback() for {{tokens}} elsewhere in the code.
 *
 * Flow:
 *   Content → Detect Tokens → Resolve Token → Escape Output → Return
 *
 * Supported syntax (Phase 1):
 *   {{post.title}}
 *   {{acf.price}}
 *   {{url.parameter.product_id}}
 *
 * NOT supported (intentional, keep parser stable):
 *   {{user.name ?? "Guest"}}  — fallback expressions
 *   {{post.title | uppercase}} — filters/transformers
 *   {{condition ? a : b}}      — conditionals
 */
final class Parser {

	/**
	 * Matches {{token.key}} and {{token.key.sub}} patterns.
	 * Only lowercase letters, digits, underscores and dots are allowed.
	 */
	private const TOKEN_PATTERN = '/\{\{([a-z][a-z0-9_]*(?:\.[a-z0-9_]+)+)\}\}/';

	/** Maximum recursive parse depth — guards against self-referential content. */
	private const MAX_DEPTH = 3;

	private Resolver $resolver;

	/** Current recursion depth for the active parse call. */
	private int $depth = 0;

	public function __construct( Resolver $resolver ) {
		$this->resolver = $resolver;
	}

	/**
	 * Parse all {{tokens}} in $content and return the replaced string.
	 *
	 * @param string $content   Raw content that may contain {{tokens}}.
	 * @param string $escape    Escaping context: 'html' | 'attr' | 'url' | 'raw'
	 *                          'raw'  — no escaping at all (use only in trusted PHP code)
	 *                          'html' — wp_kses_post() for HTML-capable tokens, esc_html() otherwise
	 *                          'attr' — esc_attr()
	 *                          'url'  — esc_url()
	 * @return string           Content with tokens replaced.
	 */
	public function parse( string $content, string $escape = 'html' ): string {
		if ( '' === $content || ! str_contains( $content, '{{' ) ) {
			return $content;
		}

		if ( $this->depth >= self::MAX_DEPTH ) {
			return $content;
		}

		$this->depth++;

		// For URL context: resolve each token raw first, then esc_url() the full assembled
		// string. Per-token esc_url() would treat bare values like "Red" as a hostname
		// and prepend "http://", breaking composite URLs like {{site.url}}/{{acf.field}}.
		$inner_escape = ( 'url' === $escape ) ? 'raw' : $escape;

		$result = preg_replace_callback(
			self::TOKEN_PATTERN,
			function ( array $matches ) use ( $inner_escape ): string {
				return $this->replace_token( $matches[1], $inner_escape );
			},
			$content
		);

		$this->depth--;

		// preg_replace_callback returns null on PCRE error — fall back to original.
		$result = $result ?? $content;

		return ( 'url' === $escape ) ? esc_url( $result ) : $result;
	}

	/**
	 * Resolve a single token key and escape the value for the given context.
	 */
	private function replace_token( string $key, string $escape ): string {
		$raw  = $this->resolver->resolve( $key );
		$type = $this->resolver->get_token_type( $key );

		if ( 'raw' === $escape ) {
			return $raw;
		}

		return $this->escape( $raw, $escape, $type );
	}

	/**
	 * Escape a raw value for the correct rendering context.
	 *
	 * Priority order:
	 *   1. Caller-forced context ($escape param) overrides token type when
	 *      the caller knows exactly where the value is going (e.g. a URL field).
	 *   2. Token type from the registry ('url' tokens get esc_url() by default).
	 *   3. Default: esc_html() for plain text, wp_kses_post() for html tokens.
	 */
	private function escape( string $value, string $escape, string $token_type ): string {
		// If caller explicitly requested a specific context, honour it.
		if ( 'url' === $escape || ( 'html' === $escape && 'url' === $token_type ) ) {
			return esc_url( $value );
		}

		if ( 'attr' === $escape ) {
			return esc_attr( $value );
		}

		// html escape — respect token type.
		if ( 'html' === $token_type ) {
			return wp_kses_post( $value );
		}

		return esc_html( $value );
	}

	/**
	 * Return whether $content contains at least one token pattern.
	 * Use this before calling parse() in hot render paths.
	 */
	public static function has_tokens( string $content ): bool {
		return str_contains( $content, '{{' ) && str_contains( $content, '}}' );
	}

	/**
	 * Extract all token keys found in $content without resolving them.
	 * Useful for editor tooling and validation.
	 *
	 * @return list<string>
	 */
	public static function detect_tokens( string $content ): array {
		if ( ! self::has_tokens( $content ) ) {
			return [];
		}

		preg_match_all( self::TOKEN_PATTERN, $content, $matches );
		return array_values( array_unique( $matches[1] ?? [] ) );
	}
}
