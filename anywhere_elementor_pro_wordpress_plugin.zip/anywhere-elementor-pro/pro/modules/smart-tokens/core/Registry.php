<?php

namespace Aepro\Modules\SmartTokens\Core;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Central token registry.
 *
 * Stores every registered token definition and its group metadata.
 * Third-party code registers tokens via:
 *   do_action( 'dynific/smart_tokens/register_tokens', $registry );
 *   do_action( 'dynific/smart_tokens/register_groups', $registry );
 */
final class Registry {

	/** @var array<string, array> Keyed by token key, e.g. 'post.title' */
	private array $tokens = [];

	/** @var array<string, array> Keyed by group id, e.g. 'post' */
	private array $groups = [];

	/**
	 * Register a group.
	 *
	 * @param string $id     Unique group identifier (lowercase, no dots).
	 * @param array  $config { label: string, icon?: string, priority?: int }
	 */
	public function register_group( string $id, array $config ): void {
		$this->groups[ sanitize_key( $id ) ] = [
			'label'    => sanitize_text_field( $config['label'] ?? $id ),
			'icon'     => sanitize_text_field( $config['icon'] ?? '' ),
			'priority' => absint( $config['priority'] ?? 10 ),
		];
	}

	/**
	 * Register a token.
	 *
	 * @param string $key    Token key: group.name  or  group.sub.name
	 * @param array  $config {
	 *   label:       string,
	 *   group:       string,
	 *   description: string,
	 *   resolver:    callable,
	 *   type:        'text'|'url'|'html'   (default 'text'),
	 *   dynamic:     bool  (true = key is a prefix, e.g. url.parameter.*)
	 * }
	 * @return bool  False when the key format is invalid.
	 */
	public function register_token( string $key, array $config ): bool {
		if ( ! preg_match( '/^[a-z][a-z0-9_]*(?:\.[a-z0-9_*]+)+$/', $key ) ) {
			return false;
		}

		if ( ! is_callable( $config['resolver'] ?? null ) ) {
			return false;
		}

		$this->tokens[ $key ] = [
			'label'       => sanitize_text_field( $config['label'] ?? $key ),
			'group'       => sanitize_key( $config['group'] ?? 'general' ),
			'description' => sanitize_text_field( $config['description'] ?? '' ),
			'resolver'    => $config['resolver'],
			'type'        => in_array( $config['type'] ?? 'text', [ 'text', 'url', 'html' ], true )
				? $config['type']
				: 'text',
			'dynamic'     => (bool) ( $config['dynamic'] ?? false ),
		];

		return true;
	}

	/**
	 * Look up a registered token by exact key.
	 * For dynamic tokens (e.g. url.parameter.*), also matches prefix patterns.
	 *
	 * @return array|null Token config or null when not found.
	 */
	public function get_token( string $key ): ?array {
		if ( isset( $this->tokens[ $key ] ) ) {
			return $this->tokens[ $key ];
		}

		// Check dynamic prefix patterns (e.g. url.parameter.* matches url.parameter.foo)
		foreach ( $this->tokens as $registered_key => $config ) {
			if ( ! $config['dynamic'] ) {
				continue;
			}
			$prefix = rtrim( $registered_key, '*' );
			if ( str_starts_with( $key, $prefix ) ) {
				return $config;
			}
		}

		return null;
	}

	/**
	 * Return all registered tokens, optionally filtered by group.
	 *
	 * @param string $group_id  Pass '' to return all groups.
	 * @return array<string, array>
	 */
	public function get_all_tokens( string $group_id = '' ): array {
		if ( '' === $group_id ) {
			return $this->tokens;
		}

		return array_filter(
			$this->tokens,
			static fn( array $t ): bool => $t['group'] === $group_id
		);
	}

	/**
	 * Return tokens grouped and sorted for the editor UI.
	 *
	 * @return array<string, array{ label: string, icon: string, tokens: array }>
	 */
	public function get_grouped_tokens(): array {
		$grouped = [];

		foreach ( $this->tokens as $key => $config ) {
			if ( $config['dynamic'] ) {
				continue; // Skip wildcard entries from the UI list
			}
			$gid = $config['group'];
			if ( ! isset( $grouped[ $gid ] ) ) {
				$grouped[ $gid ] = [
					'label'    => $this->groups[ $gid ]['label'] ?? $gid,
					'icon'     => $this->groups[ $gid ]['icon'] ?? '',
					'priority' => $this->groups[ $gid ]['priority'] ?? 10,
					'tokens'   => [],
				];
			}
			$grouped[ $gid ]['tokens'][ $key ] = [
				'key'         => $key,
				'label'       => $config['label'],
				'description' => $config['description'],
				'type'        => $config['type'],
			];
		}

		uasort( $grouped, static fn( $a, $b ) => $a['priority'] <=> $b['priority'] );

		return $grouped;
	}

	/** Return all registered groups. */
	public function get_groups(): array {
		return $this->groups;
	}

	/**
	 * Search tokens by query string (matches key, label, description).
	 *
	 * @return array<string, array>
	 */
	public function search_tokens( string $query ): array {
		$query = strtolower( trim( $query ) );

		if ( '' === $query ) {
			return $this->tokens;
		}

		return array_filter(
			$this->tokens,
			static function ( array $config, string $key ) use ( $query ): bool {
				return str_contains( $key, $query )
					|| str_contains( strtolower( $config['label'] ), $query )
					|| str_contains( strtolower( $config['description'] ), $query );
			},
			ARRAY_FILTER_USE_BOTH
		);
	}
}
