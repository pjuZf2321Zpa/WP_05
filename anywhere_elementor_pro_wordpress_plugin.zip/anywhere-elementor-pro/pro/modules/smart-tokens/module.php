<?php

namespace Aepro\Modules\SmartTokens;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Aepro\Modules\SmartTokens\Core\Registry;
use Aepro\Modules\SmartTokens\Core\Context;
use Aepro\Modules\SmartTokens\Core\Resolver;
use Aepro\Modules\SmartTokens\Core\Parser;
use Aepro\Modules\SmartTokens\Tokens\SiteTokens;
use Aepro\Modules\SmartTokens\Tokens\PostTokens;
use Aepro\Modules\SmartTokens\Tokens\UserTokens;
use Aepro\Modules\SmartTokens\Tokens\UrlTokens;
use Aepro\Modules\SmartTokens\Tokens\DateTokens;
use Aepro\Modules\SmartTokens\Tokens\QueryTokens;
use Aepro\Modules\SmartTokens\Tokens\AcfTokens;
use Aepro\Modules\SmartTokens\Tokens\WooTokens;
use Aepro\Modules\SmartTokens\Integrations\Elementor\ControlsIntegration;
use Aepro\Modules\SmartTokens\Integrations\Elementor\EditorIntegration;

/**
 * Smart Tokens module entry point.
 *
 * Bootstraps the centralized token engine:
 *   Registry → Resolver → Parser
 *
 * Registers all built-in token groups and hooks into Elementor.
 *
 * Public API (via Smart_Tokens facade):
 *   Smart_Tokens::parse( $content )                 — replace tokens in text
 *   Smart_Tokens::parse( $content, 'attr' )         — escape for HTML attributes
 *   Smart_Tokens::parse( $content, 'url' )          — escape for href/src
 *   Smart_Tokens::parse( $content, 'raw' )          — no escaping (trusted PHP use)
 *   Smart_Tokens::get_grouped_tokens()              — all tokens for editor UI
 *   Smart_Tokens::registry()->register_token(...)   — third-party token registration
 */
final class Module {

	private static ?Module $instance = null;

	private Registry $registry;
	private Resolver $resolver;
	private Parser   $parser;

	public static function instance(): self {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		$this->registry = new Registry();
		$this->resolver = new Resolver( $this->registry );
		$this->parser   = new Parser( $this->resolver );

		// Register built-in token groups at priority 5 so third-party code at
		// default priority (10) can override or extend them.
		// Guard: if init already fired (ModuleManager loads on elementor/init which
		// is priority 0 of WordPress init, so our priority-5 hook is still safe),
		// fall back to immediate registration for truly late instantiation.
		if ( did_action( 'init' ) ) {
			$this->register_builtin_tokens();
			$this->fire_registration_hooks();
		} else {
			add_action( 'init', [ $this, 'register_builtin_tokens' ], 5 );
			add_action( 'init', [ $this, 'fire_registration_hooks' ], 15 );
		}

		// Wire Elementor integrations.
		// elementor/loaded fires during plugins_loaded — always before ModuleManager
		// instantiates this class (which happens on elementor/init, a later hook).
		// Guard the same way as the init hooks above.
		if ( did_action( 'elementor/loaded' ) ) {
			$this->boot_elementor_integrations();
		} else {
			add_action( 'elementor/loaded', [ $this, 'boot_elementor_integrations' ] );
		}

		// Flush the per-request cache when the loop post changes so token values
		// are fresh for each item in a posts grid / repeater.
		add_action( 'the_post', [ $this, 'on_loop_post_change' ] );
	}

	// ── Built-in token registration ───────────────────────────────────────────

	public function register_builtin_tokens(): void {
		( new SiteTokens() )->register( $this->registry );
		( new PostTokens() )->register( $this->registry );
		( new UserTokens() )->register( $this->registry );
		( new UrlTokens() )->register( $this->registry );
		( new DateTokens() )->register( $this->registry );
		( new QueryTokens() )->register( $this->registry );
		( new AcfTokens() )->register( $this->registry );
		( new WooTokens() )->register( $this->registry );
	}

	/**
	 * Fire extensibility hooks so third-party plugins can add custom tokens.
	 *
	 * Usage:
	 *   add_action( 'dynific/smart_tokens/register_groups', function( $registry ) {
	 *       $registry->register_group( 'my_plugin', [ 'label' => 'My Plugin' ] );
	 *   } );
	 *
	 *   add_action( 'dynific/smart_tokens/register_tokens', function( $registry ) {
	 *       $registry->register_token( 'my_plugin.value', [
	 *           'label'    => 'My Value',
	 *           'group'    => 'my_plugin',
	 *           'resolver' => fn() => 'Hello!',
	 *       ] );
	 *   } );
	 */
	public function fire_registration_hooks(): void {
		do_action( 'dynific/smart_tokens/register_groups', $this->registry );
		do_action( 'dynific/smart_tokens/register_tokens', $this->registry );
	}

	// ── Elementor integrations ────────────────────────────────────────────────

	public function boot_elementor_integrations(): void {
		( new ControlsIntegration() )->register_hooks();
		( new EditorIntegration() )->register_hooks();
	}

	// ── Loop post context ─────────────────────────────────────────────────────

	/**
	 * When WordPress advances to the next post in a loop, push the new post
	 * onto the context stack so token resolvers pick it up.
	 */
	public function on_loop_post_change( \WP_Post $post ): void {
		Context::push( 'post', $post );

		add_action(
			'loop_end',
			static function () use ( $post ): void {
				Context::pop( 'post' );
			},
			10,
			0
		);
	}

	// ── Service accessors ─────────────────────────────────────────────────────

	public function registry(): Registry {
		return $this->registry;
	}

	public function parser(): Parser {
		return $this->parser;
	}

	// ── Parse API ─────────────────────────────────────────────────────────────

	/**
	 * Parse all {{tokens}} in $content and return the escaped result.
	 *
	 * @param string $content  May contain one or more {{token.key}} patterns.
	 * @param string $escape   'html' | 'attr' | 'url' | 'raw'
	 */
	public function parse( string $content, string $escape = 'html' ): string {
		return $this->parser->parse( $content, $escape );
	}

	/** Return all tokens grouped for the editor UI. */
	public function get_grouped_tokens(): array {
		return $this->registry->get_grouped_tokens();
	}
}
