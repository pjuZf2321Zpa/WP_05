/* global dynificSmartTokens, jQuery */
( function ( $, config ) {
	'use strict';

	if ( ! config ) {
		return;
	}

	// ── State ─────────────────────────────────────────────────────────────────

	var STATE = {
		tokens          : {},
		loaded          : false,
		fetchError      : false,
		activeInput     : null,
		triggerPos      : -1,
		queryLength     : 0,
		savedPos        : null,
		savedRange      : null,
		query           : null,
		highlightedIndex: -1,
		flatList        : [],
	};

	// Text fields that can take a token (the field button and its scan).
	var TEXT_INPUT_SELECTOR = 'input[type="text"], input[type="url"], input[type="search"], input:not([type]), textarea';

	// ── Bootstrap ─────────────────────────────────────────────────────────────

	function init() {
		attachInputListeners();
		initFieldButtons();
		fetchTokens();
	}

	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', init );
	} else {
		init();
	}

	// ── Token Catalogue ───────────────────────────────────────────────────────

	function fetchTokens() {
		$.ajax( {
			url      : config.restUrl + 'tokens',
			method   : 'GET',
			beforeSend: function ( xhr ) {
				xhr.setRequestHeader( 'X-WP-Nonce', config.nonce );
			},
		} )
		.done( function ( response ) {
			if ( response && response.groups ) {
				STATE.tokens     = response.groups;
				STATE.loaded     = true;
				STATE.fetchError = false;
				buildFlatList( '' );
			} else {
				STATE.fetchError = true;
			}
		} )
		.fail( function () {
			STATE.fetchError = true;
		} );
	}

	function buildFlatList( query ) {
		var q = ( query || '' ).toLowerCase();
		STATE.flatList = [];

		Object.keys( STATE.tokens ).forEach( function ( groupId ) {
			var group  = STATE.tokens[ groupId ];
			var tokens = group.tokens || {};

			Object.keys( tokens ).forEach( function ( key ) {
				var token = tokens[ key ];
				if (
					q === '' ||
					key.indexOf( q ) !== -1 ||
					( token.label || '' ).toLowerCase().indexOf( q ) !== -1 ||
					( token.description || '' ).toLowerCase().indexOf( q ) !== -1
				) {
					STATE.flatList.push( {
						key        : key,
						label      : token.label || key,
						description: token.description || '',
						groupLabel : group.label || groupId,
					} );
				}
			} );
		} );
	}

	// ── Per-Field Token Buttons ───────────────────────────────────────────────

	function initFieldButtons() {
		// Inject into any inputs already rendered.
		scanAndInjectButtons( document.body );

		// Watch for controls added later (widget panel opens dynamically).
		// Scan the full panel on each batch rather than individual added nodes,
		// because Elementor adds .elementor-control elements directly (not wrapped),
		// so root.querySelectorAll('.elementor-control') on an added node misses
		// the node itself. The button-already-exists guard prevents duplicates.
		var scanTimer = null;
		var observer = new MutationObserver( function ( mutations ) {
			var needsScan = false;
			mutations.forEach( function ( m ) {
				if ( m.addedNodes.length ) {
					needsScan = true;
				}
			} );
			if ( needsScan ) {
				clearTimeout( scanTimer );
				scanTimer = setTimeout( function () {
					scanAndInjectButtons( document.body );
				}, 50 );
			}
		} );

		observer.observe( document.body, { childList: true, subtree: true } );
	}

	function scanAndInjectButtons( root ) {
		if ( ! root || ! root.querySelectorAll ) {
			return;
		}

		scanV4Fields( root );

		var panel = document.getElementById( 'elementor-panel' );
		if ( ! panel ) {
			return;
		}

		// One button per control, not per input.
		var controls = root.querySelectorAll( '.elementor-control' );

		controls.forEach( function ( control ) {
			// Skip controls already processed.
			if ( control.querySelector( '.dynific-field-token-btn' ) ) {
				return;
			}
			if ( ! panel.contains( control ) ) {
				return;
			}

			// Only inject on controls that have a text/url/textarea input.
			var input = Array.prototype.filter.call( control.querySelectorAll( TEXT_INPUT_SELECTOR ), isTokenField )[ 0 ];
			if ( ! input ) {
				return;
			}

			injectFieldButton( input, control );
		} );
	}

	/**
	 * Elementor 4 panel: each setting is a `[data-type="settings-field"]`
	 * with a `<label>` above its input. Fields with exactly one text input,
	 * textarea or rich-text editor get the button next to the label. The
	 * panel is redrawn by React, so this runs again on every change.
	 */
	function scanV4Fields( root ) {
		var fields = root.querySelectorAll( '[data-type="settings-field"]' );

		fields.forEach( function ( field ) {
			if ( field.querySelector( '.dynific-field-token-btn' ) ) {
				return;
			}

			// Composite controls (rule lists, repeaters) are not one text value.
			if ( field.querySelector( '.MuiPaper-root' ) || 1 !== findV4Inputs( field ).length ) {
				return;
			}

			var label = field.querySelector( 'label' );
			if ( ! label || ! label.parentNode ) {
				return;
			}

			var btn = createFieldButton( function () {
				return findV4Inputs( field )[ 0 ] || null;
			} );
			btn.classList.add( 'dynific-field-token-btn--v4' );
			label.parentNode.insertBefore( btn, label.nextSibling );
		} );
	}

	function findV4Inputs( field ) {
		return Array.prototype.filter.call(
			field.querySelectorAll( TEXT_INPUT_SELECTOR + ', [contenteditable="true"]' ),
			isTokenField
		);
	}

	/**
	 * Fields a person types into. Dropdowns (MUI Select) keep their value in a
	 * hidden, read-only input, which must not count as a text field.
	 */
	function isTokenField( el ) {
		return ! el.classList.contains( 'dynific-browser-search' ) &&
			! el.classList.contains( 'MuiSelect-nativeInput' ) &&
			'true' !== el.getAttribute( 'aria-hidden' ) &&
			! el.readOnly &&
			! el.disabled;
	}

	/**
	 * The token button. `getInput` returns the field's current input (React may
	 * have replaced it since the button was added).
	 */
	function createFieldButton( getInput ) {
		var btn = document.createElement( 'button' );
		btn.type      = 'button';
		btn.className = 'dynific-field-token-btn';
		btn.title     = config.i18n.insertToken;
		btn.setAttribute( 'aria-label', config.i18n.insertToken );
		btn.innerHTML = '<i class="eicon-code" aria-hidden="true"></i>';

		// Remember where the caret was before the button takes focus.
		btn.addEventListener( 'mousedown', function ( e ) {
			e.preventDefault();
			saveCaret( getInput() );
		} );

		btn.addEventListener( 'click', function ( e ) {
			e.preventDefault();
			e.stopPropagation();
			var input = getInput();
			if ( ! input ) {
				return;
			}
			if ( STATE.activeInput !== input ) {
				// Opened from the keyboard: no caret saved for this field.
				STATE.savedPos   = null;
				STATE.savedRange = null;
			}
			STATE.activeInput = input;
			openBrowserPanel();
		} );

		return btn;
	}

	function injectFieldButton( inputEl, control ) {
		var btn = createFieldButton( function () {
			return inputEl;
		} );

		// Preferred target: the right-side icon container in the title row.
		// Elementor puts responsive switchers and AI button inside
		// .elementor-control-title-inner (right side of the flex label row).
		var titleInner = control.querySelector( '.elementor-control-title-inner' );
		if ( titleInner ) {
			titleInner.insertBefore( btn, titleInner.firstChild );
			return;
		}

		// Fallback A: a direct sibling of the AI/sparkle button.
		var aiEl = control.querySelector( '[class*="e-ai"], [class*="ai-button"], [class*="elementor-ai"]' );
		if ( aiEl ) {
			var aiWrapper = aiEl.closest( '[class*="e-ai"], [class*="ai-button"], [class*="elementor-ai"]' ) || aiEl;
			if ( aiWrapper.parentNode ) {
				aiWrapper.parentNode.insertBefore( btn, aiWrapper );
				return;
			}
		}

		// Fallback B: after the label text inside the control field row.
		var label = control.querySelector( 'label.elementor-control-title' );
		if ( label && label.parentNode ) {
			label.parentNode.insertBefore( btn, label.nextSibling );
		}
	}

	// ── Input Listeners (autocomplete on {{ typing) ──────────────────────────

	function attachInputListeners() {
		document.addEventListener( 'input',     onDocInput,    false );
		document.addEventListener( 'keyup',     onDocInput,    false );
		// Capture phase: while the token list is open, its keys must not reach
		// rich-text editors (Elementor 4's Title / Paragraph), which act on
		// Enter / arrows themselves.
		document.addEventListener( 'keydown',   onDocKeydown,  true );
		document.addEventListener( 'mousedown', onDocMousedown, false );
	}

	// Keys that move through or act on the token list (handled in onDocKeydown).
	var NAVIGATION_KEYS = [ 'ArrowUp', 'ArrowDown', 'Enter', 'Tab', 'Escape' ];

	function onDocInput( e ) {
		var el = e.target;

		if ( ! isTextInput( el ) ) {
			return;
		}

		// Releasing a navigation key must not rebuild the list (that reset
		// the highlight to the first item on every arrow key).
		if ( 'keyup' === e.type && NAVIGATION_KEYS.indexOf( e.key ) !== -1 ) {
			return;
		}

		var before   = getTextBeforeCaret( el );
		var lastOpen = before.lastIndexOf( '{{' );

		if ( lastOpen === -1 ) {
			hideDropdown();
			return;
		}

		var afterTrigger = before.substring( lastOpen + 2 );
		if ( afterTrigger.indexOf( '}}' ) !== -1 ) {
			hideDropdown();
			return;
		}

		var dropdownOpen = !! getDropdownEl();

		// Same field, same query and the list already open: nothing changed
		// (e.g. keyup of a modifier or a caret move) — keep the highlight.
		if ( dropdownOpen && STATE.activeInput === el && STATE.query === afterTrigger ) {
			STATE.triggerPos  = lastOpen;
			STATE.queryLength = before.length - lastOpen;
			return;
		}

		STATE.activeInput      = el;
		STATE.triggerPos       = lastOpen;
		STATE.queryLength      = before.length - lastOpen;
		STATE.query            = afterTrigger;
		STATE.highlightedIndex = 0;

		buildFlatList( afterTrigger );
		showDropdown( el );
	}

	function onDocKeydown( e ) {
		var dropdown = getDropdownEl();
		if ( ! dropdown ) {
			return;
		}

		switch ( e.key ) {
			case 'ArrowDown':
				e.preventDefault();
				e.stopPropagation();
				STATE.highlightedIndex = Math.min(
					STATE.highlightedIndex + 1,
					STATE.flatList.length - 1
				);
				renderDropdownItems( dropdown );
				break;

			case 'ArrowUp':
				e.preventDefault();
				e.stopPropagation();
				STATE.highlightedIndex = Math.max( STATE.highlightedIndex - 1, 0 );
				renderDropdownItems( dropdown );
				break;

			case 'Enter':
			case 'Tab':
				if ( STATE.flatList[ STATE.highlightedIndex ] ) {
					e.preventDefault();
					e.stopPropagation();
					var tokenKey = STATE.flatList[ STATE.highlightedIndex ].key;
					// After this key event, so the editor isn't mid-keystroke.
					setTimeout( function () {
						insertToken( tokenKey );
					}, 0 );
				}
				break;

			case 'Escape':
				e.stopPropagation();
				hideDropdown();
				break;
		}
	}

	function onDocMousedown( e ) {
		var dropdown = getDropdownEl();
		if ( ! dropdown ) {
			return;
		}

		if ( dropdown.contains( e.target ) ) {
			// Keep focus and caret in the field while a token is picked.
			e.preventDefault();
			return;
		}

		if ( STATE.activeInput && STATE.activeInput.contains( e.target ) ) {
			return;
		}

		hideDropdown();
	}

	document.addEventListener( 'click', function ( e ) {
		var item = e.target && e.target.closest
			? e.target.closest( '[data-token-key]' )
			: null;
		if ( ! item ) {
			return;
		}
		var dropdown = getDropdownEl();
		if ( dropdown && dropdown.contains( item ) ) {
			insertToken( item.getAttribute( 'data-token-key' ) );
		}
	}, false );

	// ── Autocomplete Dropdown ─────────────────────────────────────────────────

	function getDropdownEl() {
		var el = document.getElementById( 'dynific-token-dropdown' );
		return ( el && ! el.classList.contains( 'dynific-hidden' ) ) ? el : null;
	}

	function showDropdown( inputEl ) {
		var dropdown = document.getElementById( 'dynific-token-dropdown' );

		if ( ! dropdown ) {
			dropdown = document.createElement( 'div' );
			dropdown.id        = 'dynific-token-dropdown';
			dropdown.className = 'dynific-token-dropdown';
			dropdown.setAttribute( 'role', 'listbox' );
			document.body.appendChild( dropdown );
		}

		dropdown.classList.remove( 'dynific-hidden' );
		renderDropdownItems( dropdown );
		positionDropdown( dropdown, inputEl );
	}

	function hideDropdown() {
		var dropdown = document.getElementById( 'dynific-token-dropdown' );
		if ( dropdown ) {
			dropdown.classList.add( 'dynific-hidden' );
			dropdown.innerHTML = '';
		}
		STATE.activeInput      = null;
		STATE.triggerPos       = -1;
		STATE.query            = null;
		STATE.highlightedIndex = -1;
	}

	function renderDropdownItems( dropdown ) {
		if ( ! STATE.loaded && ! STATE.fetchError ) {
			dropdown.innerHTML =
				'<div class="dynific-token-dropdown__loading">' +
				esc( config.i18n.loading ) +
				'</div>';
			return;
		}

		if ( STATE.fetchError ) {
			dropdown.innerHTML =
				'<div class="dynific-token-dropdown__empty">Could not load tokens.</div>';
			return;
		}

		if ( STATE.flatList.length === 0 ) {
			dropdown.innerHTML =
				'<div class="dynific-token-dropdown__empty">' +
				esc( config.i18n.noResults ) +
				'</div>';
			return;
		}

		dropdown.innerHTML = STATE.flatList.map( function ( token, index ) {
			return (
				'<div class="dynific-token-dropdown__item' +
				( index === STATE.highlightedIndex ? ' is-highlighted' : '' ) +
				'" role="option" data-token-key="' + esc( token.key ) + '"' +
				' title="' + esc( token.description ) + '">' +
				'<span class="dynific-token-dropdown__item-label">' + esc( token.label ) + '</span>' +
				'<code class="dynific-token-dropdown__item-key">{{' + esc( token.key ) + '}}</code>' +
				'<span class="dynific-token-dropdown__item-group">' + esc( token.groupLabel ) + '</span>' +
				'</div>'
			);
		} ).join( '' );

		var highlighted = dropdown.querySelector( '.is-highlighted' );
		if ( highlighted ) {
			highlighted.scrollIntoView( { block: 'nearest' } );
		}
	}

	function positionDropdown( dropdown, inputEl ) {
		var rect       = inputEl.getBoundingClientRect();
		var spaceBelow = window.innerHeight - rect.bottom;
		var dropHeight = Math.min( 280, STATE.flatList.length * 44 + 16 );
		var top        = ( spaceBelow >= dropHeight || spaceBelow >= 120 )
			? rect.bottom + 4
			: rect.top - dropHeight - 4;

		dropdown.style.position = 'fixed';
		dropdown.style.top      = Math.max( 4, top ) + 'px';
		dropdown.style.left     = rect.left + 'px';
		dropdown.style.width    = Math.max( 280, rect.width ) + 'px';
		dropdown.style.zIndex   = '999999';
	}

	// ── Token Insertion ───────────────────────────────────────────────────────

	// Autocomplete: replaces the typed "{{query" before the caret.
	function insertToken( tokenKey ) {
		var el = STATE.activeInput;
		if ( ! el ) {
			return;
		}

		replaceBeforeCaret( el, STATE.queryLength, '{{' + tokenKey + '}}' );
		hideDropdown();
	}

	/**
	 * Token browser: back in the field at the remembered caret (or the end),
	 * insert the token, replacing an unfinished "{{query" typed just before.
	 */
	function insertFromBrowser( el, tokenKey ) {
		restoreCaret( el );

		var before   = getTextBeforeCaret( el );
		var lastOpen = before.lastIndexOf( '{{' );
		var count    = ( lastOpen !== -1 && before.substring( lastOpen + 2 ).indexOf( '}}' ) === -1 ) ? before.length - lastOpen : 0;

		replaceBeforeCaret( el, count, '{{' + tokenKey + '}}' );
	}

	function saveCaret( el ) {
		STATE.savedPos   = null;
		STATE.savedRange = null;
		if ( ! el || ( document.activeElement !== el && ! el.contains( document.activeElement ) ) ) {
			return;
		}

		STATE.activeInput = el;
		if ( el.contentEditable === 'true' ) {
			var sel = window.getSelection();
			if ( sel && sel.rangeCount && el.contains( sel.getRangeAt( 0 ).startContainer ) ) {
				STATE.savedRange = sel.getRangeAt( 0 ).cloneRange();
			}
		} else {
			STATE.savedPos = el.selectionStart;
		}
	}

	function restoreCaret( el ) {
		el.focus();

		if ( el.contentEditable === 'true' ) {
			var sel   = window.getSelection();
			var range = STATE.savedRange && el.contains( STATE.savedRange.startContainer ) ? STATE.savedRange : null;
			if ( ! range ) {
				range = document.createRange();
				range.selectNodeContents( el );
				range.collapse( false );
			}
			sel.removeAllRanges();
			sel.addRange( range );
		} else {
			var length = ( el.value || '' ).length;
			var pos    = null === STATE.savedPos ? length : Math.min( STATE.savedPos, length );
			el.setSelectionRange( pos, pos );
		}

		STATE.savedPos   = null;
		STATE.savedRange = null;
	}

	// ── Token Browser Panel ───────────────────────────────────────────────────

	function openBrowserPanel() {
		// Close if already open.
		var existing = document.getElementById( 'dynific-token-browser-panel' );
		if ( existing ) {
			existing.remove();
			return;
		}

		var elementorPanel = document.getElementById( 'elementor-panel' ) || document.body;

		var panel = document.createElement( 'div' );
		panel.id        = 'dynific-token-browser-panel';
		panel.className = 'dynific-token-browser-panel';
		panel.innerHTML =
			'<div class="dynific-browser-header">' +
				'<span class="dynific-browser-title">' + esc( config.i18n.panelTitle ) + '</span>' +
				'<button class="dynific-browser-close" type="button" title="Close" aria-label="Close">&times;</button>' +
			'</div>' +
			'<div class="dynific-browser-search-wrap">' +
				'<input type="search" class="dynific-browser-search" ' +
				'placeholder="' + esc( config.i18n.searchPlaceholder ) + '" />' +
			'</div>' +
			'<div class="dynific-browser-list">' + renderBrowserListHTML() + '</div>';

		elementorPanel.appendChild( panel );

		var searchInput = panel.querySelector( '.dynific-browser-search' );
		if ( searchInput ) {
			searchInput.addEventListener( 'input', function () {
				buildFlatList( this.value );
				var listEl = panel.querySelector( '.dynific-browser-list' );
				if ( listEl ) {
					listEl.innerHTML = renderBrowserListHTML();
				}
			} );
			searchInput.focus();
		}

		panel.addEventListener( 'click', function ( e ) {
			if ( e.target.closest( '.dynific-browser-close' ) ) {
				panel.remove();
				return;
			}

			var item = e.target.closest( '[data-token-key]' );
			if ( ! item ) {
				return;
			}

			var key = item.getAttribute( 'data-token-key' );

			panel.remove();

			if ( STATE.activeInput && document.body.contains( STATE.activeInput ) ) {
				insertFromBrowser( STATE.activeInput, key );
			} else {
				copyToClipboard( '{{' + key + '}}' );
			}
		} );
	}

	function renderBrowserListHTML() {
		if ( ! STATE.loaded && ! STATE.fetchError ) {
			return '<div class="dynific-browser-loading">' + esc( config.i18n.loading ) + '</div>';
		}

		if ( STATE.fetchError ) {
			return '<div class="dynific-browser-empty">Could not load tokens.</div>';
		}

		if ( STATE.flatList.length === 0 ) {
			return '<div class="dynific-browser-empty">' + esc( config.i18n.noResults ) + '</div>';
		}

		var grouped = {};
		var order   = [];

		STATE.flatList.forEach( function ( token ) {
			if ( ! grouped[ token.groupLabel ] ) {
				grouped[ token.groupLabel ] = [];
				order.push( token.groupLabel );
			}
			grouped[ token.groupLabel ].push( token );
		} );

		return order.map( function ( groupLabel ) {
			var items = grouped[ groupLabel ].map( function ( token ) {
				return (
					'<div class="dynific-browser-item" role="option" ' +
					'data-token-key="' + esc( token.key ) + '">' +
						'<div class="dynific-browser-item__top">' +
							'<span class="dynific-browser-item__label">' + esc( token.label ) + '</span>' +
							'<code class="dynific-browser-item__key">{{' + esc( token.key ) + '}}</code>' +
						'</div>' +
						( token.description
							? '<div class="dynific-browser-item__desc">' + esc( token.description ) + '</div>'
							: ''
						) +
					'</div>'
				);
			} ).join( '' );

			return (
				'<div class="dynific-browser-group">' +
					'<div class="dynific-browser-group__label">' + esc( groupLabel ) + '</div>' +
					items +
				'</div>'
			);
		} ).join( '' );
	}

	// ── Helpers ───────────────────────────────────────────────────────────────

	function isTextInput( el ) {
		if ( ! el ) {
			return false;
		}
		var tag  = ( el.tagName || '' ).toLowerCase();
		var type = ( el.type  || '' ).toLowerCase();

		if ( tag === 'textarea' ) {
			return true;
		}
		if ( tag === 'input' ) {
			return type === 'text' || type === 'url' || type === 'search' || type === '';
		}
		if ( el.contentEditable === 'true' ) {
			return true;
		}
		return false;
	}

	/**
	 * Text before the caret: for inputs from their value, for rich-text
	 * editors (Elementor 4's Title / Paragraph fields) from the caret's own
	 * text node, so offsets match what replaceBeforeCaret() selects.
	 */
	function getTextBeforeCaret( el ) {
		if ( el.contentEditable !== 'true' ) {
			return ( el.value || '' ).substring( 0, el.selectionStart || 0 );
		}

		var sel = window.getSelection();
		if ( ! sel || ! sel.rangeCount ) {
			return '';
		}

		var range = sel.getRangeAt( 0 );
		var node  = range.startContainer;
		if ( 3 !== node.nodeType || ! el.contains( node ) ) {
			return '';
		}

		return node.textContent.substring( 0, range.startOffset );
	}

	/**
	 * Replaces the `count` characters before the caret with `text` through the
	 * browser's own text insertion, so rich-text editors and React-controlled
	 * fields (Elementor 4 panel) update their state, as they would on typing.
	 */
	function replaceBeforeCaret( el, count, text ) {
		el.focus();

		if ( el.contentEditable === 'true' ) {
			var sel = window.getSelection();
			if ( sel && sel.rangeCount ) {
				var caret = sel.getRangeAt( 0 );
				var node  = caret.startContainer;
				if ( 3 === node.nodeType && el.contains( node ) && caret.startOffset >= count ) {
					var range = document.createRange();
					range.setStart( node, caret.startOffset - count );
					range.setEnd( node, caret.startOffset );
					sel.removeAllRanges();
					sel.addRange( range );
				}
			}
			document.execCommand( 'insertText', false, text );
			return;
		}

		var end   = el.selectionStart || 0;
		var start = Math.max( 0, end - count );
		el.setSelectionRange( start, end );

		if ( ! document.execCommand( 'insertText', false, text ) ) {
			var value = el.value || '';
			setNativeValue( el, value.substring( 0, start ) + text + value.substring( end ) );
			el.setSelectionRange( start + text.length, start + text.length );
			triggerNativeChange( el );
		}
	}

	// Sets a field's value so React-controlled inputs notice the change.
	function setNativeValue( el, value ) {
		var proto  = 'TEXTAREA' === el.tagName ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
		var setter = Object.getOwnPropertyDescriptor( proto, 'value' );
		if ( setter && setter.set ) {
			setter.set.call( el, value );
		} else {
			el.value = value;
		}
	}

	function triggerNativeChange( el ) {
		el.dispatchEvent( new Event( 'input',  { bubbles: true } ) );
		el.dispatchEvent( new Event( 'change', { bubbles: true } ) );
		$( el ).trigger( 'input' ).trigger( 'change' );
	}

	function copyToClipboard( text ) {
		if ( navigator.clipboard ) {
			navigator.clipboard.writeText( text );
		} else {
			var ta        = document.createElement( 'textarea' );
			ta.value      = text;
			ta.style.position = 'fixed';
			ta.style.opacity  = '0';
			document.body.appendChild( ta );
			ta.select();
			document.execCommand( 'copy' );
			ta.remove();
		}
	}

	function esc( str ) {
		return String( str || '' )
			.replace( /&/g,  '&amp;'  )
			.replace( /</g,  '&lt;'   )
			.replace( />/g,  '&gt;'   )
			.replace( /"/g,  '&quot;' )
			.replace( /'/g,  '&#039;' );
	}

} )( jQuery, window.dynificSmartTokens );
