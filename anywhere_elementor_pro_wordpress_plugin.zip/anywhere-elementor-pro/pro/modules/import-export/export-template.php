<?php
namespace Aepro\Modules\ImportExport;

use Elementor\Plugin;

class ExportTemplate {
	const POST_TYPE    = 'ae_global_templates';
	const NONCE_ACTION = 'ae_export_template';

	private static $_instance;

	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	private function __construct() {
		add_filter( 'post_row_actions', [ $this, 'post_row_actions' ], 10, 2 );
		add_filter( 'bulk_actions-edit-ae_global_templates', [ $this, 'admin_add_bulk_export_action' ] );
		add_filter( 'handle_bulk_actions-edit-ae_global_templates', [ $this, 'admin_export_multiple_templates' ], 10, 3 );
		add_action( 'wp_ajax_ae_export_template', [ $this, 'ae_export_template' ] );
	}

	public function admin_add_bulk_export_action( $actions ) {
		$actions['ae_export_multiple_templates'] = esc_html__( 'Export', 'ae-pro' );
		return $actions;
	}

	public function post_row_actions( $actions, \WP_Post $post ) {
		global $current_screen;

		if ( ! $current_screen ) {
			return $actions;
		}
		if ( 'edit' === $current_screen->base && self::POST_TYPE === $current_screen->post_type && $this->can_export( $post->ID ) ) {
			$document = Plugin::$instance->documents->get( $post->ID );
			if ( $document ) {
				$elementor_data_arr = json_decode( get_post_meta( $post->ID, '_elementor_data', true ) );

				if ( is_array( $elementor_data_arr ) && count( $elementor_data_arr ) ) {
					$actions['export-template'] = sprintf( '<a href="%1$s">%2$s</a>', esc_url( $this->get_export_link( $post->ID ) ), esc_html__( 'Export Template', 'ae-pro' ) );
				}
			}
		}

		return $actions;
	}

	public function get_export_link( $template_id ) {
		return add_query_arg(
			[
				'action'      => 'ae_export_template',
				'_nonce'      => wp_create_nonce( self::NONCE_ACTION ),
				'template_id' => $template_id,
			],
			admin_url( 'admin-ajax.php' )
		);
	}

	/**
	 * Only Dynific templates, and only ones the user may edit.
	 */
	public function can_export( $template_id ) {
		$template_id = absint( $template_id );

		return $template_id && self::POST_TYPE === get_post_type( $template_id ) && current_user_can( 'edit_post', $template_id );
	}

	public function ae_export_template() {
		$nonce = isset( $_REQUEST['_nonce'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['_nonce'] ) ) : '';
		if ( ! wp_verify_nonce( $nonce, self::NONCE_ACTION ) ) {
			wp_die( esc_html__( 'Access Denied', 'ae-pro' ), '', [ 'response' => 403 ] );
		}

		$template_id = isset( $_REQUEST['template_id'] ) ? absint( $_REQUEST['template_id'] ) : 0;
		if ( ! $this->can_export( $template_id ) ) {
			wp_die( esc_html__( 'You are not allowed to export this template.', 'ae-pro' ), '', [ 'response' => 403 ] );
		}

		$file_data = $this->prepare_template_export( $template_id );

		if ( is_wp_error( $file_data ) ) {
			wp_die( esc_html( $file_data->get_error_message() ), '', [ 'response' => 400 ] );
		}

		$this->send_file_headers( $file_data['name'], strlen( $file_data['content'] ) );

		// Clear buffering just in case.
		@ob_end_clean();

		flush();

		// Output file contents.
		// PHPCS - Export widget json

		echo $file_data['content']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		die;
	}

	public function prepare_template_export( $template_id ) {

		$document = Plugin::$instance->documents->get( $template_id );

		if ( ! $document ) {
			return new \WP_Error( 'template_error', __( 'Template not found', 'ae-pro' ) );
		}

		$template_data = $document->get_export_data();

		if ( empty( $template_data['content'] ) ) {
			return new \WP_Error( 'empty_template', __( 'The template is empty', 'ae-pro' ) );
		}

		$export_data = [
			'content'       => $template_data['content'],
			'page_settings' => $template_data['settings'],
			// Only the template's own settings; other post meta stays on this site.
			'meta_data'     => ImportTemplate::filter_meta_keys( (array) $template_data['metadata'] ),
			'version'       => '0.4',
			'title'         => $document->get_main_post()->post_title,
			'type'          => self::POST_TYPE,
		];

		return [
			'name'    => 'aepro-' . $template_id . '-' . gmdate( 'Y-m-d' ) . '.json',
			'content' => wp_json_encode( $export_data ),
		];
	}

	public function send_file_headers( $file_name, $file_size ) {
		header( 'Content-Type: application/octet-stream' );
		header( 'Content-Disposition: attachment; filename="' . $file_name . '"' );
		header( 'Expires: 0' );
		header( 'Cache-Control: must-revalidate' );
		header( 'Pragma: public' );
		header( 'Content-Length: ' . $file_size );
	}

	public function admin_export_multiple_templates( $redirect_to, $action, $post_ids ) {
		if ( 'ae_export_multiple_templates' !== $action ) {
			return $redirect_to;
		}

		$result = $this->export_multiple_templates( (array) $post_ids );

		// If you reach this line, the export failed
		wp_die( esc_html( $result->get_error_message() ) );
	}

	public function export_multiple_templates( array $template_ids ) {
		if ( ! class_exists( '\ZipArchive' ) ) {
			return new \WP_Error( 'zip_unavailable', __( 'Exporting several templates needs the PHP Zip extension.', 'ae-pro' ) );
		}

		$files = [];

		foreach ( array_map( 'absint', $template_ids ) as $template_id ) {
			if ( ! $this->can_export( $template_id ) ) {
				continue;
			}

			$file_data = $this->prepare_template_export( $template_id );

			if ( is_wp_error( $file_data ) ) {
				continue;
			}

			$files[ $file_data['name'] ] = $file_data['content'];
		}

		if ( ! $files ) {
			return new \WP_Error( 'empty_files', __( 'There is no files to export (probably all the requested templates are empty).', 'ae-pro' ) );
		}

		$zip_archive_filename = 'aepro-templates-' . gmdate( 'Y-m-d' ) . '.zip';

		// Build the archive in the server's temp dir, not the public uploads folder.
		$zip_complete_path = wp_tempnam( $zip_archive_filename );

		$zip_archive = new \ZipArchive();

		if ( true !== $zip_archive->open( $zip_complete_path, \ZipArchive::OVERWRITE ) ) {
			@unlink( $zip_complete_path );
			return new \WP_Error( 'zip_error', __( 'Cannot create the export archive.', 'ae-pro' ) );
		}

		foreach ( $files as $name => $content ) {
			$zip_archive->addFromString( $name, $content );
		}

		$zip_archive->close();

		$this->send_file_headers( $zip_archive_filename, filesize( $zip_complete_path ) );

		@ob_end_flush();

		@readfile( $zip_complete_path );

		@unlink( $zip_complete_path );

		die;
	}
}
ExportTemplate::instance();
