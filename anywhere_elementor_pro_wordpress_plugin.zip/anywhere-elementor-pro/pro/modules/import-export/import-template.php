<?php
namespace Aepro\Modules\ImportExport;

use Elementor\Plugin;
use Elementor\Utils;

class ImportTemplate {
	const POST_TYPE    = 'ae_global_templates';
	const NONCE_ACTION = 'ae_import_template';

	private static $_instance;

	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	private function __construct() {
		add_filter( 'views_edit-ae_global_templates', [ $this, 'admin_import_template_form' ] );
		add_action( 'wp_ajax_ae_import_template', [ $this, 'ae_import_template' ] );
	}

	/**
	 * Same capability as creating a template (edit_theme_options unless filtered).
	 */
	public static function get_import_capability() {
		$post_type_object = get_post_type_object( self::POST_TYPE );

		return ( $post_type_object && isset( $post_type_object->cap->create_posts ) ) ? $post_type_object->cap->create_posts : 'edit_theme_options';
	}

	/**
	 * Keeps only the template's own settings (ae_*). Everything else in a file
	 * (core, Elementor or other plugins' meta) is never written.
	 */
	public static function filter_meta_keys( array $meta ) {
		return array_filter(
			$meta,
			function ( $key ) {
				return is_string( $key ) && 1 === preg_match( '/^ae_[a-z0-9_]+$/i', $key );
			},
			ARRAY_FILTER_USE_KEY
		);
	}

	public function admin_import_template_form( $views ) {
		global $current_screen;

		if ( ! $current_screen || 'edit' !== $current_screen->base || self::POST_TYPE !== $current_screen->post_type ) {
			return $views;
		}

		if ( ! current_user_can( self::get_import_capability() ) ) {
			return $views;
		}

		?>
		<div id="elementor-hidden-area" class="ae-import-form">
			<!-- <a id="elementor-import-template-trigger" class="page-title-action ae-import-template-btn"><?php echo esc_html__( 'Import Templates', 'ae-pro' ); ?></a> -->
			<div id="elementor-import-template-area">
				<div id="elementor-import-template-title"><?php echo esc_html__( 'Choose a Dynific Addons for Elementor template JSON file or a .zip archive of DA templates, and add them to the list of templates available in DA Templates.', 'ae-pro' ); ?></div>
				<form id="elementor-import-template-form" method="post" action="<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>" enctype="multipart/form-data">
					<input type="hidden" name="action" value="ae_import_template">
					<input type="hidden" name="_nonce" value="<?php echo esc_attr( wp_create_nonce( self::NONCE_ACTION ) ); ?>">
					<fieldset id="elementor-import-template-form-inputs">
						<input type="file" name="file" accept=".json,application/json,.zip,application/octet-stream,application/zip,application/x-zip,application/x-zip-compressed" required>
						<input id="e-import-template-action" type="submit" class="button" value="<?php echo esc_attr__( 'Import Now', 'ae-pro' ); ?>">
					</fieldset>
				</form>
			</div>
		</div>
		<?php
		return $views;
	}

	public function ae_import_template() {
		if ( ! current_user_can( self::get_import_capability() ) ) {
			wp_die( esc_html__( 'You are not allowed to import templates.', 'ae-pro' ), '', [ 'response' => 403 ] );
		}

		$nonce = isset( $_REQUEST['_nonce'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['_nonce'] ) ) : '';
		if ( ! wp_verify_nonce( $nonce, self::NONCE_ACTION ) ) {
			wp_die( esc_html__( 'Access Denied', 'ae-pro' ), '', [ 'response' => 403 ] );
		}

		$file = isset( $_FILES['file'] ) && is_array( $_FILES['file'] ) ? $_FILES['file'] : []; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		if ( empty( $file['tmp_name'] ) || UPLOAD_ERR_OK !== (int) $file['error'] || ! is_uploaded_file( $file['tmp_name'] ) ) {
			wp_die( esc_html__( 'Please upload a file to import.', 'ae-pro' ), '', [ 'response' => 400 ] );
		}

		$result = $this->import_template( sanitize_file_name( $file['name'] ), $file['tmp_name'] );

		if ( is_wp_error( $result ) ) {
			wp_die( esc_html( $result->get_error_message() . '.' ), '', [ 'response' => 400 ] );
		}

		wp_safe_redirect( admin_url( 'edit.php?post_type=ae_global_templates&post_status=draft' ) );

		die();
	}

	/**
	 * @return int[]|\WP_Error Imported template IDs. Nothing is imported unless every file is valid.
	 */
	public function import_template( $name, $path ) {

		if ( empty( $path ) ) {
			return new \WP_Error( 'file_error', __( 'Please upload a file to import', 'ae-pro' ) );
		}

		$extension = strtolower( pathinfo( $name, PATHINFO_EXTENSION ) );
		$templates = [];

		if ( 'zip' === $extension ) {
			$extracted_files = Plugin::$instance->uploads_manager->extract_and_validate_zip( $path, [ 'json' ] );

			if ( is_wp_error( $extracted_files ) ) {
				return $extracted_files;
			}

			foreach ( isset( $extracted_files['files'] ) ? $extracted_files['files'] : [] as $file_path ) {
				$templates[] = $this->read_template_file( $file_path );
			}

			if ( ! $templates ) {
				$templates[] = new \WP_Error( 'file_error', __( 'No valid template files in the archive', 'ae-pro' ) );
			}

			// Delete the temporary extraction directory, since it's now not necessary.
			Plugin::$instance->uploads_manager->remove_file_or_dir( $extracted_files['extraction_directory'] );
		} elseif ( 'json' === $extension ) {
			$templates[] = $this->read_template_file( $path );
		} else {
			return new \WP_Error( 'file_error', __( 'Please upload a .json or .zip file', 'ae-pro' ) );
		}

		foreach ( $templates as $template ) {
			if ( is_wp_error( $template ) ) {
				return $template;
			}
		}

		$items = [];
		foreach ( $templates as $template ) {
			$template_id = $this->save_item( $template );

			if ( is_wp_error( $template_id ) ) {
				return $template_id;
			}

			$items[] = $template_id;
		}

		return $items;
	}

	/**
	 * Reads and validates one exported template file.
	 *
	 * @return array|\WP_Error
	 */
	public function read_template_file( $path ) {

		$data = json_decode( (string) file_get_contents( $path ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents

		if ( empty( $data ) || ! is_array( $data ) ) {
			return new \WP_Error( 'file_error', __( 'Invalid File', 'ae-pro' ) );
		}

		if ( isset( $data['type'] ) && self::POST_TYPE !== $data['type'] ) {
			return new \WP_Error( 'file_error', __( 'This file is not a Dynific template', 'ae-pro' ) );
		}

		if ( empty( $data['content'] ) || ! is_array( $data['content'] ) ) {
			return new \WP_Error( 'file_error', __( 'Invalid Content In File', 'ae-pro' ) );
		}

		return [
			'content'       => $data['content'],
			'title'         => isset( $data['title'] ) && is_string( $data['title'] ) ? $data['title'] : '',
			'meta_data'     => isset( $data['meta_data'] ) && is_array( $data['meta_data'] ) ? $data['meta_data'] : [],
			'page_settings' => isset( $data['page_settings'] ) && is_array( $data['page_settings'] ) ? $data['page_settings'] : [],
		];
	}

	public function save_item( $template_data ) {

		$title = sanitize_text_field( $template_data['title'] );

		// Always a draft: imported display rules must not go live until someone publishes.
		$post_id = wp_insert_post(
			[
				'post_title'  => '' !== $title ? $title : esc_html__( 'AE Template', 'ae-pro' ),
				'post_status' => 'draft',
				'post_type'   => self::POST_TYPE,
				'meta_input'  => [
					'_elementor_edit_mode'     => 'builder',
					'_elementor_template_type' => 'post',
				],
			],
			true
		);

		if ( is_wp_error( $post_id ) ) {
			return $post_id;
		}

		if ( '' === $title ) {
			wp_update_post(
				[
					'ID'         => $post_id,
					'post_title' => esc_html__( 'AE Template', 'ae-pro' ) . ' #' . $post_id,
				]
			);
		}

		foreach ( self::filter_meta_keys( $template_data['meta_data'] ) as $key => $item ) {
			$item = $this->sanitize_meta_value( $item );
			if ( null !== $item ) {
				update_post_meta( $post_id, $key, $item );
			}
		}

		$document = Plugin::$instance->documents->get( $post_id, false );

		if ( ! $document ) {
			wp_delete_post( $post_id, true );
			return new \WP_Error( 'template_error', __( 'Could not create the template', 'ae-pro' ) );
		}

		$content = Plugin::$instance->db->iterate_data(
			$template_data['content'],
			function( $element ) {
				$element['id'] = Utils::generate_random_string();
				return $element;
			}
		);

		$document->save(
			[
				'elements' => $content,
				'settings' => $template_data['page_settings'],
			]
		);

		return $document->get_main_id();
	}

	/**
	 * Exported meta values are strings; arrays arrive serialized. Objects are
	 * never restored (no PHP object injection) and a value holding one is dropped.
	 *
	 * @return mixed|null Null when the value must not be saved.
	 */
	private function sanitize_meta_value( $value ) {
		if ( is_string( $value ) && is_serialized( $value ) ) {
			$value = @unserialize( trim( $value ), [ 'allowed_classes' => false ] ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.serialize_unserialize, WordPress.PHP.NoSilencedErrors.Discouraged
		}

		if ( is_array( $value ) ) {
			$has_object = false;
			array_walk_recursive(
				$value,
				function ( $item ) use ( &$has_object ) {
					$has_object = $has_object || is_object( $item );
				}
			);

			return $has_object ? null : map_deep( $value, 'sanitize_text_field' );
		}

		if ( is_scalar( $value ) ) {
			return sanitize_text_field( (string) $value );
		}

		return null;
	}
}
ImportTemplate::instance();
