<?php

namespace Aepro\Modules\AcfDynamic\Repeater;

use Aepro\Aepro;
use Elementor;
use Elementor\Controls_Manager;
use Aepro\Frontend;
use function is_a;
use function is_array;

class DynamicHelper {

	public static $_instance = null;

	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	public function ae_get_acf_field_groups() {

		$acf_groups = acf_get_field_groups();
		return $acf_groups;
	}

	public function ae_get_acf_fields( $acf_group = [] ) {
		$group_fields = acf_get_fields( $acf_group );
		return $group_fields;
	}

	public function ae_acf_get_repeater() {
		$groups     = [];
		$acf_groups = $this->ae_get_acf_field_groups();
		$blank      = [
			' ' => __( 'Select', 'ae-pro' ),
		];
		$groups[]   = [
			'label'   => 'Select',
			'options' => $blank,
		];
		foreach ( $acf_groups as $acf_group ) {
			$is_on_option_page = false;
			foreach ( $acf_group['location'] as $locations ) {
				foreach ( $locations as $location ) {
					if ( $location['param'] === 'options_page' ) {
						$is_on_option_page = true;
					}
				}
			}
			$only_on_option_page = '';
			if ( $is_on_option_page === true && ( is_array( $acf_group['location'] ) && 1 === count( $acf_group['location'] ) ) ) {
				$only_on_option_page = true;
			}
			$fields  = $this->ae_get_acf_fields( $acf_group );
			$options = [];
			foreach ( $fields as $field ) {
				if ( $field['type'] === 'repeater' ) {
					$u_id = '';
					if ( ! empty( $field['ID'] ) ) {
						$u_id = $field['ID'];
					} else {
						$u_id = $field['key'];
					}
					if ( $only_on_option_page ) {
						$options[ 'option:' . $u_id . ':' . $field['name'] ] = 'Option:' . $field['label'];
					} else {
						if ( $is_on_option_page === true ) {
							$options[ 'option:' . $u_id . ':' . $field['name'] ] = 'Option:' . $field['label'];
						}

						$options[ 'post:' . $u_id . ':' . $field['name'] ] = $field['label'];
					}
				}
			}
			if ( ! empty( $options ) ) {
				$groups[] = [
					'label'   => $acf_group['title'],
					'options' => $options,
				];
			}
		}
		return $groups;
	}

	public function ae_get_group_fields( $tag, $sup_fields ) {
		global $post;
		if ( ! $post ) {
			return false;
		}
		$post_id   = $post->ID;
		$post_type = $post->post_type;
		if ( $post_type === 'ae_global_templates' ) {
			$rule_type         = get_post_meta( $post_id, 'ae_rule_post_type', true );
			$selected_repeater = get_post_meta( $post_id, 'ae_acf_repeater_name', true );
		}

		$default    = ' ';
		$acf_groups = $this->ae_get_acf_field_groups();
		$repeaters  = $this->ae_acf_get_repeater();
		$tag->add_control(
			'acf_repeater',
			[
				'label'   => __( 'Repeater', 'ae-pro' ),
				'type'    => Controls_Manager::SELECT,
				'groups'  => $repeaters,
				'default' => $default,
			]
		);

		// Elementor 4 (v4) editor only: one Sub Field picker grouped by
		// repeater. v4 turns the per-repeater `condition`s below into
		// "disable", not "hide", so it would show every repeater's picker.
		// See filter_editor_settings() for how each editor gets its pickers.
		$tag->add_control(
			'repeater_sub_field',
			[
				'label'           => __( 'Sub Field', 'ae-pro' ),
				'type'            => Controls_Manager::SELECT,
				'groups'          => $this->get_repeater_sub_field_groups( $sup_fields ),
				'default'         => '',
				'aep_atomic_only' => true,
			]
		);

		foreach ( $acf_groups as $acf_group ) {
			$fields = $this->ae_get_acf_fields( $acf_group );

			foreach ( $fields as $field ) {
				$u_id = '';
				if ( ! empty( $field['ID'] ) ) {
					$u_id = $field['ID'];
				} else {
					$u_id = $field['key'];
				}
				if ( $field['type'] === 'repeater' ) {

					$tag->add_control(
						$u_id . ':' . $field['name'],
						[
							'label'     => __( 'Sub Field', 'ae-pro' ),
							'type'      => Controls_Manager::SELECT,
							'options'   => $this->ae_acf_get_group_fields( $u_id, $sup_fields ),
							'condition' => [
								'acf_repeater' => [
									'post:' . $u_id . ':' . $field['name'],
									'option:' . $u_id . ':' . $field['name'],
								],
							],
							// Classic editor picker; hidden in the v4 editor, which
							// uses `repeater_sub_field` instead.
							'aep_legacy_sub_field' => true,
						]
					);
				}
			}
		}
	}

	/**
	 * Sub fields of every ACF repeater, one option group per repeater,
	 * limited to the field types the tag supports.
	 *
	 * @param string[] $sup_fields Supported ACF field types.
	 * @return array[] Elementor SELECT `groups`.
	 */
	public function get_repeater_sub_field_groups( $sup_fields ) {
		static $cache = [];

		$cache_key = implode( ' ', $sup_fields );
		if ( isset( $cache[ $cache_key ] ) ) {
			return $cache[ $cache_key ];
		}

		$groups = [];
		foreach ( $this->ae_get_acf_field_groups() as $acf_group ) {
			foreach ( $this->ae_get_acf_fields( $acf_group ) ?: [] as $field ) {
				if ( 'repeater' !== $field['type'] ) {
					continue;
				}

				$u_id    = ! empty( $field['ID'] ) ? $field['ID'] : $field['key'];
				$options = $this->ae_acf_get_group_fields( $u_id, $sup_fields );
				unset( $options[''] );

				if ( ! empty( $options ) ) {
					$groups[] = [
						'label'   => $field['label'],
						'options' => $options,
					];
				}
			}
		}

		$cache[ $cache_key ] = $groups;

		return $cache[ $cache_key ];
	}

	/**
	 * The selected sub field: the grouped picker, else the legacy
	 * per-repeater setting (`<field id>:<repeater name>`).
	 *
	 * @param array    $settings      Tag settings.
	 * @param string[] $repeater_data `acf_repeater` split on ':' (location, field id, name).
	 * @return string
	 */
	public function get_sub_field_name( $settings, $repeater_data ) {
		if ( ! empty( $settings['repeater_sub_field'] ) ) {
			return $settings['repeater_sub_field'];
		}

		$legacy_key = $repeater_data[1] . ':' . $repeater_data[2];

		return isset( $settings[ $legacy_key ] ) ? $settings[ $legacy_key ] : '';
	}

	/**
	 * `elementor/editor/localize_settings` (after Elementor 4 adds its v4 tag
	 * config at priority 10): gives each editor its own Sub Field picker.
	 *
	 *  - Classic editor (`dynamicTags`): keeps the per-repeater pickers exactly
	 *    as before and drops the v4-only grouped picker.
	 *  - v4 editor (`atomicDynamicTags`): keeps the grouped picker and drops the
	 *    per-repeater ones.
	 *
	 * Both settings stay registered on the tag, so saved values keep rendering
	 * in either editor.
	 *
	 * @param array $settings Editor settings.
	 * @return array
	 */
	public static function filter_editor_settings( $settings ) {
		if ( empty( $settings['dynamicTags']['tags'] ) || ! is_array( $settings['dynamicTags']['tags'] ) ) {
			return $settings;
		}

		foreach ( $settings['dynamicTags']['tags'] as $tag_name => $tag_config ) {
			if ( empty( $tag_config['controls'] ) || ! is_array( $tag_config['controls'] ) ) {
				continue;
			}

			$legacy_names = [];
			$is_repeater  = false;

			foreach ( $tag_config['controls'] as $control_name => $control ) {
				if ( ! empty( $control['aep_legacy_sub_field'] ) ) {
					$legacy_names[] = $control['name'] ?? $control_name;
					$is_repeater    = true;
				} elseif ( ! empty( $control['aep_atomic_only'] ) ) {
					unset( $settings['dynamicTags']['tags'][ $tag_name ]['controls'][ $control_name ] );
					$is_repeater = true;
				}
			}

			if ( ! $is_repeater || empty( $settings['atomicDynamicTags']['tags'][ $tag_name ]['atomic_controls'] ) ) {
				continue;
			}

			$sections = [];
			foreach ( $settings['atomicDynamicTags']['tags'][ $tag_name ]['atomic_controls'] as $section ) {
				if ( is_object( $section ) && method_exists( $section, 'get_items' ) && method_exists( $section, 'set_items' ) ) {
					// Clone: Elementor caches these objects for later lookups.
					$section = clone $section;
					$section->set_items(
						array_values(
							array_filter(
								$section->get_items(),
								static function ( $item ) use ( $legacy_names ) {
									return ! ( is_object( $item ) && method_exists( $item, 'get_bind' ) && in_array( $item->get_bind(), $legacy_names, true ) );
								}
							)
						)
					);
				}
				$sections[] = $section;
			}

			$settings['atomicDynamicTags']['tags'][ $tag_name ]['atomic_controls'] = $sections;
		}

		return $settings;
	}

	public function ae_acf_get_group_fields( $field_id, $sup_fields ) {
		$options = [
			'' => __( '-- Select --', 'ae-pro' ),
		];
		$field   = acf_get_field( $field_id );
		if ( is_array( $field ) && ! empty( $field['sub_fields'] ) && is_array( $field['sub_fields'] ) ) {
			foreach ( $field['sub_fields'] as $sub_field ) {
				if ( in_array( $sub_field['type'], $sup_fields, true ) ) {
					$options[ $sub_field['name'] ] = $sub_field['label'];
				}
			}
		}
		return $options;
	}

	public function key_name( $settings, $key ) {
		return 'acf_repeater_field_' . $key;
	}

	public function get_repeater_data( $settings ) {
		$value = '';
		if ( ! empty( $settings['acf_repeater'] ) ) {
			$repeater_data = explode( ':', $settings['acf_repeater'] );
		}
		if ( ! empty( $repeater_data[0] ) && ! empty( $repeater_data[1] ) && ! empty( $repeater_data[2] ) ) {
			$repeater_is = $repeater_data[0];
			$repeater    = $repeater_data[2];
			$field_name  = $this->get_sub_field_name( $settings, $repeater_data );
		}

		if ( ! empty( $repeater ) && ! empty( $field_name ) ) {
			if ( ! Frontend::$_in_repeater_block ) {
				if ( $repeater_is === 'option' ) {
					$repeater_field = get_field( $repeater, 'option' );
					if ( is_array( $repeater_field ) && ! empty( $repeater_field[0][ $field_name ] ) ) {
						$value = $repeater_field[0][ $field_name ];
					}
				} else {
					$post_data      = Aepro::$_helper->get_demo_post_data();
					$post_id        = $post_data->ID;
					$repeater_field = get_field( $repeater, $post_id );
					if ( is_array( $repeater_field ) && ! empty( $repeater_field[0][ $field_name ] ) ) {
						$value = $repeater_field[0][ $field_name ];
					}
				}
			} else {
				if ( ! empty( $field_name ) ) {
					$value = get_sub_field( $field_name );
				}
			}
			return $value;
		}
	}
}
