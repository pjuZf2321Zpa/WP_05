<?php

namespace Aepro\Modules\DynamicBg;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Lets v3's Dynamic Background resolver (Module::before_section_render) run
 * on an Elementor 4 element's settings: it offers the get_settings() /
 * add_render_attribute() calls the resolver makes and records the
 * attributes it would have added to the classic wrapper.
 */
class AtomicSettingsAdapter {

	private $settings;

	private $attributes = [];

	public function __construct( array $settings ) {
		$this->settings = $settings;
	}

	public function get_settings( $key = null ) {
		if ( null === $key ) {
			return $this->settings;
		}
		return $this->settings[ $key ] ?? null;
	}

	public function get_settings_for_display( $key = null ) {
		return $this->get_settings( $key );
	}

	public function add_render_attribute( $element, $key = null, $value = null ) {
		if ( is_array( $key ) ) {
			$this->attributes = array_merge( $this->attributes, $key );
		} elseif ( null !== $key ) {
			$this->attributes[ $key ] = $value;
		}
		return $this;
	}

	public function get_render_attribute( $key ) {
		return $this->attributes[ $key ] ?? null;
	}
}
