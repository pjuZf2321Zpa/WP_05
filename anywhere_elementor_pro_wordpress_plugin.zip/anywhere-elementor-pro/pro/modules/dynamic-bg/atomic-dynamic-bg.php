<?php

namespace Aepro\Modules\DynamicBg;

use Aepro\Aepro;
use Aepro\Classes\AtomicElementAttributes;
use Aepro\Modules\AcfDynamic\Flexible\AcfFlexibleDynamicHelper;
use Elementor\Modules\AtomicWidgets\Controls\Section;
use Elementor\Modules\AtomicWidgets\Controls\Types\Image_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Select_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Switch_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Text_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Toggle_Control;
use Elementor\Modules\AtomicWidgets\DynamicTags\Dynamic_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropDependencies\Manager as Dependency_Manager;
use Elementor\Modules\AtomicWidgets\PropTypes\Image_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\Boolean_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\String_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropsResolver\Render_Props_Resolver;
use Elementor\Modules\Components\PropTypes\Overridable_Prop_Type;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Dynamic Background for Elementor 4 (atomic) containers.
 *
 * The classic (v3) Dynamic Background controls only attach to sections,
 * columns and classic containers. v4 Div Block / Flexbox / Grid get the same
 * fields in a "Dynamic Background" settings section: same setting names,
 * options and defaults as v3. At render the v4 values are handed to v3's own
 * resolver (Module::before_section_render) through a small adapter, so both
 * editors resolve post / custom field / term / options page / Group /
 * Flexible / Repeater-row backgrounds exactly the same way.
 *
 * v3 applies the result with JavaScript (data-ae-bg attributes). v4 writes it
 * as an inline style on each element's opening tag instead, so every item in a
 * listing gets its own background without waiting for scripts.
 */
class AtomicDynamicBg {

	const CONTAINER_TYPES = [ 'e-div-block', 'e-flexbox', 'e-grid' ];

	const BOOLEAN_SETTINGS = [
		'show_featured_bg',
		'is_featured_bg_group_field',
		'is_featured_bg_flexible_field',
		'enable_bg_color',
		'is_bg_color_group_field',
		'is_featured_bg_color_flexible_field',
	];

	private static $_instance = null;

	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	public static function is_supported() {
		return class_exists( Image_Prop_Type::class ) && class_exists( Section::class ) && class_exists( Dependency_Manager::class ) && class_exists( Toggle_Control::class );
	}

	private function __construct() {
		add_filter( 'elementor/atomic-widgets/props-schema', [ $this, 'add_props' ] );
		add_filter( 'elementor/atomic-widgets/controls', [ $this, 'add_controls' ], 10, 2 );

		foreach ( self::CONTAINER_TYPES as $type ) {
			add_action( "elementor/frontend/{$type}/before_render", [ $this, 'before_render' ] );
		}

		// Writes the collected style into each container's opening tag.
		AtomicElementAttributes::instance();

		// Editor canvas: Elementor 4 draws v4 containers in the browser, so the
		// render hooks above never run there. A small editor script asks this
		// endpoint for the resolved background and applies it to the canvas.
		add_action( 'elementor/editor/after_enqueue_scripts', [ $this, 'enqueue_editor_script' ] );
		add_action( 'wp_ajax_aep_atomic_dynamic_bg_preview', [ $this, 'ajax_preview' ] );
	}

	// ── Settings (props) ─────────────────────────────────────────────────────

	/**
	 * The props filter receives no element, so the props are added to every
	 * v4 element; only containers get the controls and the output.
	 */
	public function add_props( $schema ) {
		$props = [
			// Background image.
			'show_featured_bg'                           => Boolean_Prop_Type::make()->default( false ),
			'ae_featured_bg_source'                      => $this->choice( $this->image_source_options(), 'post' )
				->set_dependencies( $this->when( [ [ 'show_featured_bg', 'eq', true ] ] ) ),
			'is_featured_bg_group_field'                 => Boolean_Prop_Type::make()->default( false )
				->set_dependencies( $this->when( [ [ 'show_featured_bg', 'eq', true ], [ 'ae_featured_bg_source', 'ne', 'post' ] ] ) ),
			'ae_featured_bg_cf_parent_key'               => $this->text()
				->set_dependencies( $this->when( [ [ 'show_featured_bg', 'eq', true ], [ 'ae_featured_bg_source', 'ne', 'post' ], [ 'is_featured_bg_group_field', 'eq', true ] ] ) ),
			'is_featured_bg_flexible_field'              => Boolean_Prop_Type::make()->default( false )
				->set_dependencies( $this->when( [ [ 'show_featured_bg', 'eq', true ], [ 'ae_featured_bg_source', 'in', [ 'custom_field', 'option_page_custom_field' ] ] ] ) ),
			'ae_featured_bg_cf_field_key'                => $this->text()
				->set_dependencies( $this->when( [ [ 'show_featured_bg', 'eq', true ], [ 'ae_featured_bg_source', 'ne', 'post' ], [ 'is_featured_bg_flexible_field', 'ne', true ] ] ) ),
			'flexible_fields'                            => $this->text()
				->set_dependencies( $this->when( [ [ 'show_featured_bg', 'eq', true ], [ 'is_featured_bg_flexible_field', 'eq', true ] ] ) ),
			'flex-sub-fields'                            => $this->text()
				->set_dependencies( $this->when( [ [ 'show_featured_bg', 'eq', true ], [ 'is_featured_bg_flexible_field', 'eq', true ] ] ) ),
			'ae_featured_fallback_image'                 => $this->static_image()
				->set_dependencies( $this->when( [ [ 'show_featured_bg', 'eq', true ] ] ) ),
			'ae_featured_image_size'                     => $this->choice( $this->image_size_options(), 'large' )
				->set_dependencies( $this->when( [ [ 'show_featured_bg', 'eq', true ] ] ) ),
			'ae_featured_bg_size'                        => $this->choice( $this->bg_size_options(), 'cover' )
				->set_dependencies( $this->when( [ [ 'show_featured_bg', 'eq', true ] ] ) ),
			'ae_featured_bg_position'                    => $this->choice( $this->bg_position_options(), '' )
				->set_dependencies( $this->when( [ [ 'show_featured_bg', 'eq', true ] ] ) ),
			'ae_featured_bg_attachment'                  => $this->choice( $this->bg_attachment_options(), '' )
				->set_dependencies( $this->when( [ [ 'show_featured_bg', 'eq', true ] ] ) ),
			// v3's setting name (sic), kept so the shared resolver and CSS agree.
			'ae_featured_bg_repeatae_featured_bg_repeat' => $this->choice( $this->bg_repeat_options(), '' )
				->set_dependencies( $this->when( [ [ 'show_featured_bg', 'eq', true ] ] ) ),

			// Background colour.
			'enable_bg_color'                            => Boolean_Prop_Type::make()->default( false ),
			'ae_bg_color_source'                         => $this->choice( $this->color_source_options(), 'custom_field' )
				->set_dependencies( $this->when( [ [ 'enable_bg_color', 'eq', true ] ] ) ),
			'is_bg_color_group_field'                    => Boolean_Prop_Type::make()->default( false )
				->set_dependencies( $this->when( [ [ 'enable_bg_color', 'eq', true ] ] ) ),
			'ae_bg_color_cf_parent_key'                  => $this->text()
				->set_dependencies( $this->when( [ [ 'enable_bg_color', 'eq', true ], [ 'is_bg_color_group_field', 'eq', true ] ] ) ),
			'is_featured_bg_color_flexible_field'        => Boolean_Prop_Type::make()->default( false )
				->set_dependencies( $this->when( [ [ 'enable_bg_color', 'eq', true ], [ 'ae_bg_color_source', 'in', [ 'custom_field', 'option_page_custom_field' ] ] ] ) ),
			'ae_bg_color_cf_field_key'                   => $this->text()
				->set_dependencies( $this->when( [ [ 'enable_bg_color', 'eq', true ], [ 'is_featured_bg_color_flexible_field', 'ne', true ] ] ) ),
			'flexible_fields_color'                      => $this->text()
				->set_dependencies( $this->when( [ [ 'enable_bg_color', 'eq', true ], [ 'is_featured_bg_color_flexible_field', 'eq', true ] ] ) ),
			'flex-sub-fields-color'                      => $this->text()
				->set_dependencies( $this->when( [ [ 'enable_bg_color', 'eq', true ], [ 'is_featured_bg_color_flexible_field', 'eq', true ] ] ) ),
		];

		// Keep them out of Elementor 4 Components' overridable properties,
		// as Elementor does for its own `attributes` setting.
		$ignore = class_exists( Overridable_Prop_Type::class ) ? Overridable_Prop_Type::ignore() : null;

		foreach ( $props as $key => $prop ) {
			$schema[ $key ] = $ignore ? $prop->meta( $ignore ) : $prop;
		}

		return $schema;
	}

	// ── Controls ─────────────────────────────────────────────────────────────

	public function add_controls( $controls, $element ) {
		if ( ! is_object( $element ) || ! in_array( $element->get_type(), self::CONTAINER_TYPES, true ) ) {
			return $controls;
		}

		// Same template-dependent choices as v3: Flexible pickers only in ACF
		// Flexible Content templates, Group switches everywhere else.
		$is_flexible_template = $this->is_flexible_template();
		$has_acf              = \Aepro\Plugin::show_acf() || \Aepro\Plugin::show_acf( true );

		$items = [
			Switch_Control::bind_to( 'show_featured_bg' )->set_label( __( 'Background Image', 'ae-pro' ) ),
			$this->select( 'ae_featured_bg_source', __( 'Source', 'ae-pro' ), $this->image_source_options() ),
		];

		if ( $has_acf ) {
			if ( $is_flexible_template ) {
				$items[] = Switch_Control::bind_to( 'is_featured_bg_flexible_field' )->set_label( __( 'Is Flexible Field', 'ae-pro' ) );
			} else {
				$items[] = Switch_Control::bind_to( 'is_featured_bg_group_field' )->set_label( __( 'Is Group Field', 'ae-pro' ) );
				$items[] = Text_Control::bind_to( 'ae_featured_bg_cf_parent_key' )->set_placeholder( __( 'Group Field Key', 'ae-pro' ) )->set_label( __( 'Group Field key', 'ae-pro' ) );
			}

			$items[] = Text_Control::bind_to( 'ae_featured_bg_cf_field_key' )->set_placeholder( __( 'Custom Field Key', 'ae-pro' ) )->set_label( __( 'Field key', 'ae-pro' ) );

			if ( $is_flexible_template ) {
				$items[] = $this->grouped_select( 'flexible_fields', __( 'Parent Field', 'ae-pro' ), $this->flexible_parent_groups() );
				$items[] = $this->grouped_select( 'flex-sub-fields', __( 'Sub Field', 'ae-pro' ), $this->flexible_sub_field_groups( [ 'image' ] ) );
			}
		}

		$items[] = Image_Control::bind_to( 'ae_featured_fallback_image' )->set_label( __( 'Fallback Image', 'ae-pro' ) );
		$items[] = $this->select( 'ae_featured_image_size', __( 'Image Size', 'ae-pro' ), $this->image_size_options() );
		$items[] = $this->select( 'ae_featured_bg_position', __( 'Background Position', 'ae-pro' ), $this->bg_position_options() );
		// Icon buttons, like Elementor 4's own Background control.
		$items[] = $this->toggle(
			'ae_featured_bg_repeatae_featured_bg_repeat',
			__( 'Background Repeat', 'ae-pro' ),
			[
				'repeat'    => 'GridDotsIcon',
				'repeat-x'  => 'DotsHorizontalIcon',
				'repeat-y'  => 'DotsVerticalIcon',
				'no-repeat' => 'XIcon',
			],
			$this->bg_repeat_options(),
			true
		);
		$items[] = $this->toggle(
			'ae_featured_bg_size',
			__( 'Background Size', 'ae-pro' ),
			[
				'auto'    => 'LetterAIcon',
				'cover'   => 'ArrowsMaximizeIcon',
				'contain' => 'ArrowBarBothIcon',
			],
			$this->bg_size_options(),
			false
		);
		$items[] = $this->toggle(
			'ae_featured_bg_attachment',
			__( 'Background Attachment', 'ae-pro' ),
			[
				'fixed'  => 'PinIcon',
				'scroll' => 'PinnedOffIcon',
			],
			$this->bg_attachment_options(),
			true
		);

		if ( $has_acf ) {
			$items[] = Switch_Control::bind_to( 'enable_bg_color' )->set_label( __( 'Background Color', 'ae-pro' ) );
			$items[] = $this->button_group(
				'ae_bg_color_source',
				__( 'Source', 'ae-pro' ),
				[
					'custom_field'             => __( 'Post', 'ae-pro' ),
					'term_custom_field'        => __( 'Term', 'ae-pro' ),
					'option_page_custom_field' => __( 'Options Page', 'ae-pro' ),
				]
			);

			if ( $is_flexible_template ) {
				$items[] = Switch_Control::bind_to( 'is_featured_bg_color_flexible_field' )->set_label( __( 'Is Flexible Field', 'ae-pro' ) );
			} else {
				$items[] = Switch_Control::bind_to( 'is_bg_color_group_field' )->set_label( __( 'Is Group Field', 'ae-pro' ) );
				$items[] = Text_Control::bind_to( 'ae_bg_color_cf_parent_key' )->set_placeholder( __( 'Group Field Key', 'ae-pro' ) )->set_label( __( 'Group Field key', 'ae-pro' ) );
			}

			$items[] = Text_Control::bind_to( 'ae_bg_color_cf_field_key' )->set_placeholder( __( 'Custom Field Key', 'ae-pro' ) )->set_label( __( 'Custom Field key', 'ae-pro' ) );

			if ( $is_flexible_template ) {
				$items[] = $this->grouped_select( 'flexible_fields_color', __( 'Parent Field', 'ae-pro' ), $this->flexible_parent_groups() );
				$items[] = $this->grouped_select( 'flex-sub-fields-color', __( 'Sub Field', 'ae-pro' ), $this->flexible_sub_field_groups( [ 'color_picker' ] ) );
			}
		}

		$controls[] = Section::make()
			->set_label( __( 'Dynamic Background', 'ae-pro' ) )
			->set_id( 'aep-dynamic-background' )
			->set_items( $items );

		return $controls;
	}

	// ── Render ───────────────────────────────────────────────────────────────

	public function before_render( $element ) {
		if ( ! method_exists( $element, 'get_atomic_settings' ) ) {
			return;
		}

		try {
			$settings = $element->get_atomic_settings();
		} catch ( \Throwable $e ) {
			return;
		}

		$styles = $this->build_styles( $settings );

		if ( ! $styles ) {
			return;
		}

		// Written into the element's opening tag (Elementor 4.3+ renders v4
		// containers from Twig templates that ignore `_wrapper` attributes).
		AtomicElementAttributes::instance()->add( $element->get_id(), [ 'style' => implode( ';', $styles ) . ';' ] );
	}

	/**
	 * Resolves the background through v3's resolver and returns CSS
	 * declarations, for the frontend and the editor preview alike.
	 *
	 * @param array $settings Resolved v4 settings (get_atomic_settings()).
	 * @return string[]
	 */
	private function build_styles( array $settings ) {
		if ( empty( $settings['show_featured_bg'] ) && empty( $settings['enable_bg_color'] ) ) {
			return [];
		}

		$adapter = new AtomicSettingsAdapter( $this->to_v3_settings( $settings ) );
		Module::instance()->before_section_render( $adapter );

		$styles = [];

		$image = $adapter->get_render_attribute( 'data-ae-bg' );
		$image = is_string( $image ) ? esc_url_raw( $image ) : '';
		if ( '' !== $image ) {
			$styles[] = 'background-image:url("' . $image . '")';

			foreach (
				[
					'background-size'       => [ 'ae_featured_bg_size', $this->bg_size_options() ],
					'background-position'   => [ 'ae_featured_bg_position', $this->bg_position_options() ],
					'background-attachment' => [ 'ae_featured_bg_attachment', $this->bg_attachment_options() ],
					'background-repeat'     => [ 'ae_featured_bg_repeatae_featured_bg_repeat', $this->bg_repeat_options() ],
				] as $property => list( $key, $options )
			) {
				$value = isset( $settings[ $key ] ) ? (string) $settings[ $key ] : '';
				if ( '' !== $value && isset( $options[ $value ] ) ) {
					$styles[] = $property . ':' . $value;
				}
			}
		}

		$color = $this->sanitize_color( $adapter->get_render_attribute( 'data-ae-bg-color' ) );
		if ( '' !== $color ) {
			$styles[] = 'background-color:' . $color;
		}

		return $styles;
	}

	public function enqueue_editor_script() {
		wp_enqueue_script(
			'aep-atomic-dynamic-bg-editor',
			AE_PRO_URL . 'pro/modules/dynamic-bg/assets/js/atomic-dynamic-bg-editor.js',
			[ 'jquery' ],
			AE_PRO_VERSION,
			true
		);

		wp_localize_script(
			'aep-atomic-dynamic-bg-editor',
			'aepAtomicDynamicBg',
			[
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'aep_atomic_dynamic_bg_preview' ),
				'types'   => self::CONTAINER_TYPES,
				'keys'    => array_keys( $this->add_props( [] ) ),
			]
		);
	}

	/**
	 * Editor preview: resolves one container's Dynamic Background in the
	 * document's preview context (a Dynific template's preview post).
	 */
	public function ajax_preview() {
		check_ajax_referer( 'aep_atomic_dynamic_bg_preview', 'nonce' );

		$post_id = isset( $_POST['post_id'] ) ? absint( $_POST['post_id'] ) : 0;
		if ( ! $post_id || ! current_user_can( 'edit_post', $post_id ) ) {
			wp_send_json_error( [], 403 );
		}

		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- JSON, validated by Elementor's props resolver below.
		$raw = isset( $_POST['settings'] ) ? json_decode( wp_unslash( $_POST['settings'] ), true ) : null;
		if ( ! is_array( $raw ) ) {
			wp_send_json_error( [], 400 );
		}

		$schema = $this->add_props( [] );
		$raw    = array_intersect_key( $raw, $schema );

		$document_post = get_post( $post_id );
		if ( ! $document_post ) {
			wp_send_json_error( [], 404 );
		}

		// Same context the editor previews: the document itself, or for a
		// Dynific template its preview post.
		$GLOBALS['post'] = $document_post; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
		$preview         = Aepro::$_helper ? Aepro::$_helper->get_demo_post_data() : null;
		if ( $preview instanceof \WP_Post && $preview->ID ) {
			$GLOBALS['post'] = $preview; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
		}
		setup_postdata( $GLOBALS['post'] );

		try {
			$settings = Render_Props_Resolver::for_settings()->resolve( $schema, $raw );
			$css      = implode( ';', $this->build_styles( $settings ) );
		} catch ( \Throwable $e ) {
			$css = '';
		}

		wp_reset_postdata();

		wp_send_json_success( [ 'css' => '' === $css ? '' : $css . ';' ] );
	}

	/**
	 * v4 resolved values → the shapes v3's resolver reads: switches as
	 * 'yes' / '', the fallback image as [ 'id', 'url' ].
	 */
	private function to_v3_settings( array $settings ) {
		foreach ( self::BOOLEAN_SETTINGS as $key ) {
			$settings[ $key ] = empty( $settings[ $key ] ) ? '' : 'yes';
		}

		$fallback = isset( $settings['ae_featured_fallback_image'] ) && is_array( $settings['ae_featured_fallback_image'] ) ? $settings['ae_featured_fallback_image'] : [];

		$settings['ae_featured_fallback_image'] = empty( $fallback['src'] ) ? [] : [
			'id'  => isset( $fallback['id'] ) ? (int) $fallback['id'] : 0,
			'url' => $fallback['src'],
		];

		return $settings;
	}

	// ── Helpers ──────────────────────────────────────────────────────────────

	/**
	 * @param array[] $terms [ setting, operator, value ] — all must match.
	 */
	private function when( array $terms ) {
		$manager = Dependency_Manager::make( Dependency_Manager::RELATION_AND );
		foreach ( $terms as list( $path, $operator, $value ) ) {
			$manager->where(
				[
					'operator' => $operator,
					'path'     => [ $path ],
					'value'    => $value,
					'effect'   => 'hide',
				]
			);
		}
		return $manager->get();
	}

	/** A plain text setting, without Elementor 4's automatic dynamic-tag option. */
	private function text() {
		return String_Prop_Type::make()->default( '' )->meta( Dynamic_Prop_Type::META_KEY, false );
	}

	private function choice( array $options, $default ) {
		return String_Prop_Type::make()->enum( array_map( 'strval', array_keys( $options ) ) )->default( (string) $default );
	}

	/**
	 * Optional (see Optional_Image_Prop_Type) and without defaults, so an empty
	 * fallback never fails Elementor's save validation.
	 */
	private function static_image() {
		$image = Optional_Image_Prop_Type::make();
		$image->get_shape_field( 'src' )->meta( Dynamic_Prop_Type::META_KEY, false );
		return $image;
	}

	/**
	 * Full-width text button group (Elementor 4's toggle control), for short
	 * lists of choices.
	 *
	 * @param array<string,string> $options value => button text.
	 */
	private function button_group( $bind, $label, array $options ) {
		$buttons = [];
		foreach ( $options as $value => $text ) {
			$buttons[ $value ] = [ 'title' => $text ];
		}

		return Toggle_Control::bind_to( $bind )
			->add_options( $buttons )
			->set_size( 'tiny' )
			->set_exclusive( true )
			->set_full_width( true )
			->set_convert_options( true )
			->set_label( $label );
	}

	private function select( $bind, $label, array $options ) {
		$select = [];
		foreach ( $options as $value => $option_label ) {
			$select[] = [
				'value' => (string) $value,
				'label' => $option_label,
			];
		}

		return Select_Control::bind_to( $bind )->set_options( $select )->set_label( $label );
	}

	/**
	 * Icon button group. With $allow_empty, clicking the selected button
	 * clears it back to v3's '' (Default).
	 *
	 * @param array<string,string> $icons  value => Elementor icon name.
	 * @param array<string,string> $labels value => label (tooltip).
	 */
	private function toggle( $bind, $label, array $icons, array $labels, $allow_empty ) {
		$options = [];
		foreach ( $icons as $value => $icon ) {
			$options[ $value ] = [
				'title'       => $labels[ $value ] ?? $value,
				'atomic-icon' => $icon,
			];
		}

		$control = Toggle_Control::bind_to( $bind )
			->add_options( $options )
			->set_size( 'tiny' )
			->set_exclusive( true )
			->set_convert_options( true )
			->set_label( $label );

		// Not in Elementor 4.2 and older: there the selected button just stays on.
		if ( method_exists( $control, 'set_allow_empty' ) ) {
			$control->set_allow_empty( (bool) $allow_empty );
		}

		return $control;
	}

	/**
	 * @param array[] $groups [ [ 'label' => ..., 'options' => [ value => label ] ] ]
	 */
	private function grouped_select( $bind, $label, array $groups ) {
		$select_groups = [];
		foreach ( $groups as $group ) {
			$options = [];
			foreach ( (array) ( $group['options'] ?? [] ) as $value => $option_label ) {
				$options[] = [
					'value' => (string) $value,
					'label' => $option_label,
				];
			}
			if ( $options ) {
				$select_groups[] = [
					'label'   => $group['label'] ?? '',
					'options' => $options,
				];
			}
		}

		$control = Select_Control::bind_to( $bind )->set_placeholder( __( 'Select', 'ae-pro' ) )->set_label( $label );

		// Option groups arrived in Elementor 4.3; before that, list the options
		// flat with the group name in front.
		if ( method_exists( $control, 'set_groups' ) ) {
			return $control->set_groups( $select_groups );
		}

		$flat = [];
		foreach ( $select_groups as $group ) {
			foreach ( $group['options'] as $option ) {
				$flat[] = [
					'value' => $option['value'],
					'label' => '' !== $group['label'] ? $group['label'] . ': ' . $option['label'] : $option['label'],
				];
			}
		}

		return $control->set_options( $flat );
	}

	private function is_flexible_template() {
		$post = get_post();
		if ( ! $post || 'ae_global_templates' !== $post->post_type ) {
			return false;
		}

		return 'acf_repeater_layout' === get_post_meta( $post->ID, 'ae_render_mode', true )
			&& 'flexible_content' === get_post_meta( $post->ID, 'ae_acf_field_type', true );
	}

	private function flexible_parent_groups() {
		$groups = Aepro::$_helper ? Aepro::$_helper->ae_get_flexible_content_fields() : [];
		return is_array( $groups ) ? $groups : [];
	}

	private function flexible_sub_field_groups( array $types ) {
		if ( ! class_exists( AcfFlexibleDynamicHelper::class ) || ! function_exists( 'acf_get_field_groups' ) ) {
			return [];
		}
		return AcfFlexibleDynamicHelper::instance()->get_sub_field_groups( $types );
	}

	/**
	 * Colours come from ACF colour fields; allow hex, rgb(a)/hsl(a) and CSS
	 * variables, nothing that can break out of the style attribute.
	 */
	private function sanitize_color( $color ) {
		if ( ! is_string( $color ) ) {
			return '';
		}

		$color = trim( $color );

		return preg_match( '/^(#[0-9a-fA-F]{3,8}|(rgb|rgba|hsl|hsla)\([0-9.,%\s\/]+\)|var\(--[A-Za-z0-9_-]+\))$/', $color ) ? $color : '';
	}

	// ── v3 option lists ──────────────────────────────────────────────────────

	private function image_source_options() {
		$options = [ 'post' => __( 'Post', 'ae-pro' ) ];
		if ( \Aepro\Plugin::show_acf() || \Aepro\Plugin::show_acf( true ) ) {
			$options['custom_field']             = __( 'Post Custom Field', 'ae-pro' );
			$options['term_custom_field']        = __( 'Term Custom Field', 'ae-pro' );
			$options['option_page_custom_field'] = __( 'Option Page Custom Field', 'ae-pro' );
		}
		return $options;
	}

	private function color_source_options() {
		return [
			'custom_field'             => __( 'Post Custom Field', 'ae-pro' ),
			'term_custom_field'        => __( 'Term Custom Field', 'ae-pro' ),
			'option_page_custom_field' => __( 'Option Page Custom Field', 'ae-pro' ),
		];
	}

	private function image_size_options() {
		$sizes = Aepro::$_helper ? Aepro::$_helper->ae_get_intermediate_image_sizes() : [];
		return is_array( $sizes ) && $sizes ? $sizes : [ 'large' => __( 'Large', 'ae-pro' ) ];
	}

	private function bg_size_options() {
		return [
			'auto'    => __( 'Auto', 'ae-pro' ),
			'cover'   => __( 'Cover', 'ae-pro' ),
			'contain' => __( 'Contain', 'ae-pro' ),
		];
	}

	private function bg_position_options() {
		return [
			''              => __( 'Default', 'ae-pro' ),
			'top left'      => __( 'Top Left', 'ae-pro' ),
			'top center'    => __( 'Top Center', 'ae-pro' ),
			'top right'     => __( 'Top Right', 'ae-pro' ),
			'center left'   => __( 'Center Left', 'ae-pro' ),
			'center center' => __( 'Center Center', 'ae-pro' ),
			'center right'  => __( 'Center Right', 'ae-pro' ),
			'bottom left'   => __( 'Bottom Left', 'ae-pro' ),
			'bottom center' => __( 'Bottom Center', 'ae-pro' ),
			'bottom right'  => __( 'Bottom Right', 'ae-pro' ),
		];
	}

	private function bg_attachment_options() {
		return [
			''       => __( 'Default', 'ae-pro' ),
			'scroll' => __( 'Scroll', 'ae-pro' ),
			'fixed'  => __( 'Fixed', 'ae-pro' ),
		];
	}

	private function bg_repeat_options() {
		return [
			''          => __( 'Default', 'ae-pro' ),
			'no-repeat' => __( 'No-repeat', 'ae-pro' ),
			'repeat'    => __( 'Repeat', 'ae-pro' ),
			'repeat-x'  => __( 'Repeat-x', 'ae-pro' ),
			'repeat-y'  => __( 'Repeat-y', 'ae-pro' ),
		];
	}
}
