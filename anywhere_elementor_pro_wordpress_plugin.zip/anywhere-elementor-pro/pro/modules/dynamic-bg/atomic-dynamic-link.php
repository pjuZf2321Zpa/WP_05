<?php

namespace Aepro\Modules\DynamicBg;

use Aepro\Aepro;
use Aepro\Classes\AtomicElementAttributes;
use Aepro\Modules\AcfDynamic\Flexible\AcfFlexibleDynamicHelper;
use Elementor\Modules\AtomicWidgets\Controls\Section;
use Elementor\Modules\AtomicWidgets\Controls\Types\Select_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Switch_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Text_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Toggle_Control;
use Elementor\Modules\AtomicWidgets\DynamicTags\Dynamic_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropDependencies\Manager as Dependency_Manager;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\Boolean_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\String_Prop_Type;
use Elementor\Modules\Components\PropTypes\Overridable_Prop_Type;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Dynamic Link (clickable container) for Elementor 4 (atomic) containers.
 *
 * v4 Div Block / Flexbox / Grid get v3's Dynamic Link fields (same setting
 * names, options and defaults) in a "Dynamic Link" settings section. At render
 * the values go through v3's own resolver (Module::before_section_render) via
 * AtomicSettingsAdapter, so post / custom field / Repeater row / Flexible /
 * static links resolve exactly as on sections and containers.
 *
 * As in v3 the whole container becomes clickable with a small script (it may
 * hold its own links and buttons, which keep working). Like v3, nothing
 * happens in the editor, so the container stays selectable there.
 */
class AtomicDynamicLink {

	const CONTAINER_TYPES = [ 'e-div-block', 'e-flexbox', 'e-grid' ];

	const BOOLEAN_SETTINGS = [
		'enable_link',
		'is_dynamic_link_flexible_field',
		'enable_open_in_new_window',
	];

	private static $_instance = null;

	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	public static function is_supported() {
		return class_exists( Section::class ) && class_exists( Dependency_Manager::class ) && class_exists( Toggle_Control::class );
	}

	private function __construct() {
		add_filter( 'elementor/atomic-widgets/props-schema', [ $this, 'add_props' ] );
		add_filter( 'elementor/atomic-widgets/controls', [ $this, 'add_controls' ], 10, 2 );

		foreach ( self::CONTAINER_TYPES as $type ) {
			add_action( "elementor/frontend/{$type}/before_render", [ $this, 'before_render' ] );
		}

		AtomicElementAttributes::instance();

		add_action( 'wp_enqueue_scripts', [ $this, 'register_script' ] );
	}

	// ── Settings (props) ─────────────────────────────────────────────────────

	public function add_props( $schema ) {
		$props = [
			'enable_link'                    => Boolean_Prop_Type::make()->default( false ),
			'dynamic_link_source'            => $this->choice( $this->source_options(), 'post' )
				->set_dependencies( $this->when( [ [ 'enable_link', 'eq', true ] ] ) ),
			'is_dynamic_link_flexible_field' => Boolean_Prop_Type::make()->default( false )
				->set_dependencies( $this->when( [ [ 'enable_link', 'eq', true ], [ 'dynamic_link_source', 'eq', 'custom_field_url' ] ] ) ),
			'dynamic_link_custom_field'      => $this->text()
				->set_dependencies( $this->when( [ [ 'enable_link', 'eq', true ], [ 'dynamic_link_source', 'eq', 'custom_field_url' ], [ 'is_dynamic_link_flexible_field', 'ne', true ] ] ) ),
			'flexible_fields_link'           => $this->text()
				->set_dependencies( $this->when( [ [ 'enable_link', 'eq', true ], [ 'dynamic_link_source', 'eq', 'custom_field_url' ], [ 'is_dynamic_link_flexible_field', 'eq', true ] ] ) ),
			'flex-sub-fields-link'           => $this->text()
				->set_dependencies( $this->when( [ [ 'enable_link', 'eq', true ], [ 'dynamic_link_source', 'eq', 'custom_field_url' ], [ 'is_dynamic_link_flexible_field', 'eq', true ] ] ) ),
			'static_url'                     => $this->text()
				->set_dependencies( $this->when( [ [ 'enable_link', 'eq', true ], [ 'dynamic_link_source', 'eq', 'static_url' ] ] ) ),
			'enable_open_in_new_window'      => Boolean_Prop_Type::make()->default( false )
				->set_dependencies( $this->when( [ [ 'enable_link', 'eq', true ] ] ) ),
		];

		// Keep them out of Elementor 4 Components' overridable properties.
		$ignore = class_exists( Overridable_Prop_Type::class ) ? Overridable_Prop_Type::ignore() : null;

		foreach ( $props as $key => $prop ) {
			$schema[ $key ] = $ignore ? $prop->meta( $ignore ) : $prop;
		}

		return $schema;
	}

	// ── Controls ─────────────────────────────────────────────────────────────

	public function add_controls( $controls, $element ) {
		if ( ! is_object( $element ) || ! in_array( $element->get_type(), self::CONTAINER_TYPES, true ) ) {
			return $controls;
		}

		$items = [
			Switch_Control::bind_to( 'enable_link' )->set_label( __( 'Enable Link', 'ae-pro' ) ),
			$this->button_group(
				'dynamic_link_source',
				__( 'Links To', 'ae-pro' ),
				array_intersect_key(
					[
						'post'             => __( 'Post', 'ae-pro' ),
						'custom_field_url' => __( 'Custom Field', 'ae-pro' ),
						'static_url'       => __( 'Static URL', 'ae-pro' ),
					],
					$this->source_options()
				)
			),
		];

		if ( isset( $this->source_options()['custom_field_url'] ) ) {
			// As in v3: the Flexible pickers replace the field key in ACF
			// Flexible Content templates.
			if ( $this->is_flexible_template() ) {
				$items[] = Switch_Control::bind_to( 'is_dynamic_link_flexible_field' )->set_label( __( 'Is Flexible Field', 'ae-pro' ) );
			}

			$items[] = Text_Control::bind_to( 'dynamic_link_custom_field' )->set_placeholder( __( 'Custom Field Key', 'ae-pro' ) )->set_label( __( 'Custom Field key', 'ae-pro' ) );

			if ( $this->is_flexible_template() ) {
				$items[] = $this->grouped_select( 'flexible_fields_link', __( 'Flexible Fields', 'ae-pro' ), $this->flexible_parent_groups() );
				$items[] = $this->grouped_select( 'flex-sub-fields-link', __( 'Sub Field', 'ae-pro' ), $this->flexible_sub_field_groups( [ 'url', 'link', 'page_link', 'text' ] ) );
			}
		}

		$items[] = Text_Control::bind_to( 'static_url' )->set_placeholder( 'https://example.com' )->set_label( __( 'Url', 'ae-pro' ) );
		$items[] = Switch_Control::bind_to( 'enable_open_in_new_window' )->set_label( __( 'Open In New Window', 'ae-pro' ) );

		$controls[] = Section::make()
			->set_label( __( 'Dynamic Link', 'ae-pro' ) )
			->set_id( 'aep-dynamic-link' )
			->set_items( $items );

		return $controls;
	}

	// ── Render ───────────────────────────────────────────────────────────────

	public function before_render( $element ) {
		if ( ! method_exists( $element, 'get_atomic_settings' ) ) {
			return;
		}

		try {
			$settings = $element->get_atomic_settings();
		} catch ( \Throwable $e ) {
			return;
		}

		$url = $this->resolve_url( $settings );
		if ( '' === $url ) {
			return;
		}

		$attributes = [
			'class'         => 'aep-v4-link',
			'style'         => 'cursor:pointer',
			'data-aep-link' => $url,
			// Reachable and announced as a link for keyboard / screen reader users.
			'role'          => 'link',
			'tabindex'      => '0',
		];
		if ( ! empty( $settings['enable_open_in_new_window'] ) ) {
			$attributes['data-aep-link-target'] = '_blank';
		}

		AtomicElementAttributes::instance()->add( $element->get_id(), $attributes );

		wp_enqueue_script( 'aep-atomic-dynamic-link' );
	}

	/**
	 * @param array $settings Resolved v4 settings (get_atomic_settings()).
	 */
	public function resolve_url( array $settings ) {
		if ( empty( $settings['enable_link'] ) ) {
			return '';
		}

		$v3 = $settings;
		foreach ( self::BOOLEAN_SETTINGS as $key ) {
			$v3[ $key ] = empty( $settings[ $key ] ) ? '' : 'yes';
		}
		// Only the link part of the shared resolver.
		$v3['show_featured_bg'] = '';
		$v3['enable_bg_color']  = '';

		$adapter = new AtomicSettingsAdapter( $v3 );
		Module::instance()->before_section_render( $adapter );

		return $this->normalize_url( $adapter->get_render_attribute( 'data-ae-url' ) );
	}

	/**
	 * ACF URL fields give a string; Link fields an array with `url`; Page Link
	 * and Post Object fields can give a post ID or object.
	 */
	private function normalize_url( $value ) {
		if ( is_array( $value ) ) {
			$value = $value['url'] ?? '';
		} elseif ( $value instanceof \WP_Post ) {
			$value = get_permalink( $value );
		} elseif ( is_numeric( $value ) && (int) $value > 0 ) {
			$value = get_permalink( (int) $value );
		}

		return is_string( $value ) ? esc_url_raw( trim( $value ) ) : '';
	}

	public function register_script() {
		wp_register_script(
			'aep-atomic-dynamic-link',
			AE_PRO_URL . 'pro/modules/dynamic-bg/assets/js/atomic-dynamic-link.js',
			[],
			AE_PRO_VERSION,
			true
		);
	}

	// ── Helpers ──────────────────────────────────────────────────────────────

	/**
	 * @param array[] $terms [ setting, operator, value ] — all must match.
	 */
	private function when( array $terms ) {
		$manager = Dependency_Manager::make( Dependency_Manager::RELATION_AND );
		foreach ( $terms as list( $path, $operator, $value ) ) {
			$manager->where(
				[
					'operator' => $operator,
					'path'     => [ $path ],
					'value'    => $value,
					'effect'   => 'hide',
				]
			);
		}
		return $manager->get();
	}

	/** A plain text setting, without Elementor 4's automatic dynamic-tag option. */
	private function text() {
		return String_Prop_Type::make()->default( '' )->meta( Dynamic_Prop_Type::META_KEY, false );
	}

	private function choice( array $options, $default ) {
		return String_Prop_Type::make()->enum( array_map( 'strval', array_keys( $options ) ) )->default( (string) $default );
	}

	/**
	 * Full-width text button group (Elementor 4's toggle control), for short
	 * lists of choices.
	 *
	 * @param array<string,string> $options value => button text.
	 */
	private function button_group( $bind, $label, array $options ) {
		$buttons = [];
		foreach ( $options as $value => $text ) {
			$buttons[ $value ] = [ 'title' => $text ];
		}

		return Toggle_Control::bind_to( $bind )
			->add_options( $buttons )
			->set_size( 'tiny' )
			->set_exclusive( true )
			->set_full_width( true )
			->set_convert_options( true )
			->set_label( $label );
	}

	private function select( $bind, $label, array $options ) {
		$select = [];
		foreach ( $options as $value => $option_label ) {
			$select[] = [
				'value' => (string) $value,
				'label' => $option_label,
			];
		}

		return Select_Control::bind_to( $bind )->set_options( $select )->set_label( $label );
	}

	/**
	 * @param array[] $groups [ [ 'label' => ..., 'options' => [ value => label ] ] ]
	 */
	private function grouped_select( $bind, $label, array $groups ) {
		$select_groups = [];
		foreach ( $groups as $group ) {
			$options = [];
			foreach ( (array) ( $group['options'] ?? [] ) as $value => $option_label ) {
				$options[] = [
					'value' => (string) $value,
					'label' => $option_label,
				];
			}
			if ( $options ) {
				$select_groups[] = [
					'label'   => $group['label'] ?? '',
					'options' => $options,
				];
			}
		}

		$control = Select_Control::bind_to( $bind )->set_placeholder( __( 'Select', 'ae-pro' ) )->set_label( $label );

		// Option groups arrived in Elementor 4.3; before that, list the options
		// flat with the group name in front.
		if ( method_exists( $control, 'set_groups' ) ) {
			return $control->set_groups( $select_groups );
		}

		$flat = [];
		foreach ( $select_groups as $group ) {
			foreach ( $group['options'] as $option ) {
				$flat[] = [
					'value' => $option['value'],
					'label' => '' !== $group['label'] ? $group['label'] . ': ' . $option['label'] : $option['label'],
				];
			}
		}

		return $control->set_options( $flat );
	}

	private function is_flexible_template() {
		$post = get_post();
		if ( ! $post || 'ae_global_templates' !== $post->post_type ) {
			return false;
		}

		return 'acf_repeater_layout' === get_post_meta( $post->ID, 'ae_render_mode', true )
			&& 'flexible_content' === get_post_meta( $post->ID, 'ae_acf_field_type', true );
	}

	private function flexible_parent_groups() {
		$groups = Aepro::$_helper ? Aepro::$_helper->ae_get_flexible_content_fields() : [];
		return is_array( $groups ) ? $groups : [];
	}

	private function flexible_sub_field_groups( array $types ) {
		if ( ! class_exists( AcfFlexibleDynamicHelper::class ) || ! function_exists( 'acf_get_field_groups' ) ) {
			return [];
		}
		return AcfFlexibleDynamicHelper::instance()->get_sub_field_groups( $types );
	}

	private function source_options() {
		$options = [ 'post' => __( 'Post', 'ae-pro' ) ];
		if ( \Aepro\Plugin::show_acf() || \Aepro\Plugin::show_acf( true ) ) {
			$options['custom_field_url'] = __( 'Custom Field (URL)', 'ae-pro' );
		}
		$options['static_url'] = __( 'Static Url', 'ae-pro' );
		return $options;
	}
}
