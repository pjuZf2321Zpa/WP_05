<?php

namespace Aepro\Modules\DynamicBg;

use Elementor\Modules\AtomicWidgets\PropTypes\Image_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Image_Src_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\String_Prop_Type;
use Elementor\Modules\AtomicWidgets\Utils\Image\Image_Sizes;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Elementor 4's image setting, but optional.
 *
 * Elementor's Image_Prop_Type requires an image source, and the editor's image
 * control can save { size } with no source when the box is touched but left
 * empty, which fails validation ("invalid_value"). A fallback image is
 * optional, so here neither the source nor the size is required. Same `image`
 * type, so the editor's image control and Elementor's transformers apply.
 */
class Optional_Image_Prop_Type extends Image_Prop_Type {

	protected function define_shape(): array {
		return [
			'src'  => Image_Src_Prop_Type::make(),
			'size' => String_Prop_Type::make()
				->initial_value( Image_Sizes::DEFAULT_SIZE )
				->enum( Image_Sizes::get_keys() ),
		];
	}
}
