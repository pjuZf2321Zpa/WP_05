/**
 * Dynific Dynamic Link on Elementor 4 (v4) Div Block, Flexbox and Grid.
 *
 * AtomicDynamicLink writes the resolved URL into data-aep-link; a click (or
 * Enter) anywhere on the container opens it. Links, buttons and form fields
 * inside the container keep their own behaviour, and the innermost linked
 * container wins when they are nested.
 */
( function () {
	'use strict';

	var INTERACTIVE = 'a[href],button,input,select,textarea,label,summary,[role="button"],[contenteditable="true"]';

	function linkedContainer( event ) {
		var target = event.target;
		if ( ! target || ! target.closest ) {
			return null;
		}

		var container = target.closest( '[data-aep-link]' );
		if ( ! container ) {
			return null;
		}

		var interactive = target.closest( INTERACTIVE );
		if ( interactive && container.contains( interactive ) && interactive !== container ) {
			return null;
		}

		return container;
	}

	function open( container, forceNewWindow ) {
		var url = container.getAttribute( 'data-aep-link' );
		if ( ! url ) {
			return;
		}

		if ( forceNewWindow || '_blank' === container.getAttribute( 'data-aep-link-target' ) ) {
			window.open( url, '_blank', 'noopener' );
		} else {
			window.location.href = url;
		}
	}

	document.addEventListener( 'click', function ( event ) {
		if ( event.defaultPrevented || 0 !== event.button ) {
			return;
		}

		var container = linkedContainer( event );
		if ( ! container ) {
			return;
		}

		// Don't follow the link when the visitor was selecting text.
		var selection = window.getSelection ? window.getSelection() : null;
		if ( selection && ! selection.isCollapsed && container.contains( selection.anchorNode ) ) {
			return;
		}

		open( container, event.ctrlKey || event.metaKey || event.shiftKey );
	} );

	// Middle click opens a new tab, like a normal link.
	document.addEventListener( 'auxclick', function ( event ) {
		var container = 1 === event.button ? linkedContainer( event ) : null;
		if ( container ) {
			open( container, true );
		}
	} );

	document.addEventListener( 'keydown', function ( event ) {
		if ( 'Enter' !== event.key || ! event.target || ! event.target.hasAttribute || ! event.target.hasAttribute( 'data-aep-link' ) ) {
			return;
		}
		open( event.target, event.ctrlKey || event.metaKey || event.shiftKey );
	} );
}() );
