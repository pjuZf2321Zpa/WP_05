/**
 * Dynific Dynamic Background: editor preview for Elementor 4 containers.
 *
 * Elementor 4 draws v4 Div Block / Flexbox / Grid in the editor canvas with
 * JavaScript, so the PHP render that adds the background on the frontend
 * never runs there. This asks the server for the resolved background (same
 * resolver as the frontend, in the document's preview context) and applies it
 * to the element in the canvas, again after every redraw.
 */
( function ( $ ) {
	var cfg = window.aepAtomicDynamicBg || {};
	var TYPES = cfg.types || [ 'e-div-block', 'e-flexbox', 'e-grid' ];
	var KEYS = cfg.keys || [];
	var SELECTOR = TYPES.map( function ( type ) {
		return '[data-e-type="' + type + '"][data-id]';
	} ).join( ',' );
	var PROPS = [ 'background-image', 'background-size', 'background-position', 'background-attachment', 'background-repeat', 'background-color' ];

	var cssBySettings = {}; // settings JSON → resolved CSS
	var cssById = {}; // element id → CSS to show
	var inFlight = {};

	function previewDocument() {
		var frame = window.elementor && elementor.$preview && elementor.$preview[ 0 ];
		return frame ? frame.contentDocument : null;
	}

	function documentId() {
		try {
			return elementor.documents.getCurrent().id;
		} catch ( e ) {
			return elementor.config && elementor.config.document ? elementor.config.document.id : 0;
		}
	}

	function getContainer( id ) {
		try {
			return elementor.getContainer( id );
		} catch ( e ) {
			return null;
		}
	}

	function readSettings( container ) {
		var settings = {};
		KEYS.forEach( function ( key ) {
			var value = container.settings.get( key );
			if ( undefined !== value && null !== value ) {
				settings[ key ] = value && value.toJSON ? value.toJSON() : value;
			}
		} );
		return settings;
	}

	function isOn( value ) {
		return true === value || ( value && true === value.value );
	}

	/**
	 * "a:b;c:url("x;y")" → [ [ 'a', 'b' ], [ 'c', 'url("x;y")' ] ], splitting
	 * only on separators outside quotes and parentheses.
	 */
	function declarations( css ) {
		var result = [];
		var current = '';
		var depth = 0;
		var quote = '';

		( css || '' ).split( '' ).forEach( function ( ch ) {
			if ( quote ) {
				if ( ch === quote ) {
					quote = '';
				}
			} else if ( '"' === ch || "'" === ch ) {
				quote = ch;
			} else if ( '(' === ch ) {
				depth++;
			} else if ( ')' === ch ) {
				depth--;
			} else if ( ';' === ch && 0 === depth ) {
				result.push( current );
				current = '';
				return;
			}
			current += ch;
		} );
		result.push( current );

		return result.map( function ( item ) {
			var colon = item.indexOf( ':' );
			return colon > 0 ? [ item.slice( 0, colon ).trim(), item.slice( colon + 1 ).trim() ] : null;
		} ).filter( function ( pair ) {
			return pair && PROPS.indexOf( pair[ 0 ] ) !== -1 && pair[ 1 ];
		} );
	}

	function apply( id ) {
		var doc = previewDocument();
		var el = doc && doc.querySelector( '[data-id="' + id + '"]' );
		var css = cssById[ id ] || '';

		if ( ! el || el.getAttribute( 'data-aep-dynamic-bg' ) === css ) {
			return;
		}

		PROPS.forEach( function ( prop ) {
			el.style.removeProperty( prop );
		} );

		declarations( css ).forEach( function ( declaration ) {
			el.style.setProperty( declaration[ 0 ], declaration[ 1 ] );
		} );

		el.setAttribute( 'data-aep-dynamic-bg', css );
	}

	function refresh( id ) {
		var container = id && getContainer( id );
		if ( ! container || ! container.model || TYPES.indexOf( container.model.get( 'elType' ) ) === -1 ) {
			return;
		}

		var settings = readSettings( container );
		if ( ! isOn( settings.show_featured_bg ) && ! isOn( settings.enable_bg_color ) ) {
			cssById[ id ] = '';
			apply( id );
			return;
		}

		var key = JSON.stringify( settings );
		if ( undefined !== cssBySettings[ key ] ) {
			cssById[ id ] = cssBySettings[ key ];
			apply( id );
			return;
		}

		( inFlight[ key ] = inFlight[ key ] || [] ).push( id );
		if ( inFlight[ key ].length > 1 ) {
			return;
		}

		$.post( cfg.ajaxUrl, {
			action: 'aep_atomic_dynamic_bg_preview',
			nonce: cfg.nonce,
			post_id: documentId(),
			settings: key,
		} ).done( function ( response ) {
			cssBySettings[ key ] = response && response.success && response.data ? response.data.css || '' : '';
		} ).fail( function () {
			cssBySettings[ key ] = '';
		} ).always( function () {
			( inFlight[ key ] || [] ).forEach( function ( waitingId ) {
				cssById[ waitingId ] = cssBySettings[ key ];
				apply( waitingId );
			} );
			delete inFlight[ key ];
		} );
	}

	function scan( root ) {
		if ( root.matches && root.matches( SELECTOR ) ) {
			refresh( root.getAttribute( 'data-id' ) );
		}
		if ( root.querySelectorAll ) {
			root.querySelectorAll( SELECTOR ).forEach( function ( node ) {
				refresh( node.getAttribute( 'data-id' ) );
			} );
		}
	}

	function watchCanvas() {
		var doc = previewDocument();
		if ( ! doc || ! doc.body ) {
			return;
		}

		scan( doc.body );

		// v4 elements are inserted as empty placeholders and only then get
		// their data-id / data-e-type from the rendered template (copied onto
		// the same node with setAttribute), so watch those attributes as well
		// as added nodes. Work is batched per animation frame.
		var queued = [];
		var scheduled = false;

		function queue( node ) {
			queued.push( node );
			if ( scheduled ) {
				return;
			}
			scheduled = true;
			( doc.defaultView || window ).requestAnimationFrame( function () {
				var nodes = queued;
				queued = [];
				scheduled = false;
				nodes.forEach( function ( queuedNode ) {
					if ( queuedNode.isConnected ) {
						scan( queuedNode );
					}
				} );
			} );
		}

		new MutationObserver( function ( mutations ) {
			mutations.forEach( function ( mutation ) {
				if ( 'attributes' === mutation.type ) {
					queue( mutation.target );
					return;
				}
				mutation.addedNodes.forEach( function ( node ) {
					if ( 1 === node.nodeType ) {
						queue( node );
					}
				} );
			} );
		} ).observe( doc.body, {
			childList: true,
			subtree: true,
			attributes: true,
			attributeFilter: [ 'data-id', 'data-e-type' ],
		} );
	}

	// Settings edits in the panel.
	window.addEventListener( 'elementor/commands/run/after', function ( event ) {
		var detail = event.detail || {};
		if ( ! /^document\/elements\/(set-)?settings$/.test( detail.command || '' ) ) {
			return;
		}

		var args = detail.args || {};
		var containers = args.containers || ( args.container ? [ args.container ] : [] );
		containers.forEach( function ( container ) {
			if ( container && container.id ) {
				setTimeout( function () {
					refresh( container.id );
				}, 0 );
			}
		} );
	} );

	function start() {
		elementor.on( 'preview:loaded', watchCanvas );
		watchCanvas(); // In case the canvas is already loaded.
	}

	if ( window.elementor && typeof elementor.on === 'function' ) {
		start();
	} else {
		$( window ).on( 'elementor:init', start );
	}
}( jQuery ) );
