<?php

namespace Aepro\Modules\BgSlider;

use Elementor\Modules\AtomicWidgets\PropTypes\Base\Array_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Contracts\Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Image_Prop_Type;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A list of images for Elementor 4 settings (Elementor has no gallery
 * setting for v4 elements). Edited with the Repeatable control; resolved with
 * Elementor's Array_Transformer, registered for this key in AtomicBgSlider.
 */
class Atomic_Image_Array_Prop_Type extends Array_Prop_Type {

	public static function get_key(): string {
		return 'aep-image-array';
	}

	protected function define_item_type(): Prop_Type {
		return Image_Prop_Type::make();
	}
}
