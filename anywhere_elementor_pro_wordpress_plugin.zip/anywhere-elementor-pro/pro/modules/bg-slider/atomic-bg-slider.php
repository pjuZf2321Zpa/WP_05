<?php

namespace Aepro\Modules\BgSlider;

use Aepro\Aepro;
use Aepro\Classes\AtomicElementAttributes;
use Elementor\Modules\AtomicWidgets\Controls\Section;
use Elementor\Modules\AtomicWidgets\Controls\Types\Number_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Repeatable_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Select_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Switch_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Text_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Toggle_Control;
use Elementor\Modules\AtomicWidgets\DynamicTags\Dynamic_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropDependencies\Manager as Dependency_Manager;
use Elementor\Modules\AtomicWidgets\PropTypes\Image_Src_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\Boolean_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\Number_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\String_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Url_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropsResolver\Render_Props_Resolver;
use Elementor\Modules\AtomicWidgets\PropsResolver\Transformers\Array_Transformer;
use Elementor\Modules\AtomicWidgets\Utils\Image\Image_Sizes;
use Elementor\Modules\AtomicWidgets\Utils\Image\Placeholder_Image;
use Elementor\Modules\Components\PropTypes\Overridable_Prop_Type;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Background Slider for Elementor 4 (atomic) containers.
 *
 * The classic (v3) Background Slider attaches only to sections, columns and
 * classic containers. v4 Div Block / Flexbox / Grid get a "Background Slider"
 * settings section with the v3 options: images picked in the editor, or an
 * ACF / Pods gallery field of the post, term or options page; image size,
 * transition, animation, overlay, cover, delay and timer.
 *
 * The resolved slides are written to the container as data-aep-bg-slider and
 * started with Vegas by assets/js/atomic-bg-slider.js, which also previews
 * the slider in the editor canvas (via ajax_preview()).
 */
class AtomicBgSlider {

	const CONTAINER_TYPES = [ 'e-div-block', 'e-flexbox', 'e-grid' ];

	const HANDLE = 'aep-atomic-bg-slider';

	const TRANSITIONS = [ 'fade', 'fade2', 'slideLeft', 'slideLeft2', 'slideRight', 'slideRight2', 'slideUp', 'slideUp2', 'slideDown', 'slideDown2', 'zoomIn', 'zoomIn2', 'zoomOut', 'zoomOut2', 'swirlLeft', 'swirlLeft2', 'swirlRight', 'swirlRight2', 'burn', 'burn2', 'blur', 'blur2', 'flash', 'flash2', 'random' ];

	const ANIMATIONS = [ 'kenburns', 'kenburnsUp', 'kenburnsDown', 'kenburnsRight', 'kenburnsLeft', 'kenburnsUpLeft', 'kenburnsUpRight', 'kenburnsDownLeft', 'kenburnsDownRight', 'random', '' ];

	const OVERLAYS = [ '', '01', '02', '03', '04', '05', '06', '07', '08', '09' ];

	private static $_instance = null;

	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	public static function is_supported() {
		foreach ( [ Section::class, Repeatable_Control::class, Number_Control::class, Array_Transformer::class, Dependency_Manager::class, Image_Sizes::class, Toggle_Control::class ] as $class ) {
			if ( ! class_exists( $class ) ) {
				return false;
			}
		}
		return true;
	}

	private function __construct() {
		add_filter( 'elementor/atomic-widgets/props-schema', [ $this, 'add_props' ] );
		add_filter( 'elementor/atomic-widgets/controls', [ $this, 'add_controls' ], 10, 2 );
		add_action( 'elementor/atomic-widgets/settings/transformers/register', [ $this, 'register_transformer' ] );

		foreach ( self::CONTAINER_TYPES as $type ) {
			add_action( "elementor/frontend/{$type}/before_render", [ $this, 'before_render' ] );
		}

		// Writes data-aep-bg-slider into each container's opening tag.
		AtomicElementAttributes::instance();

		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_scripts' ], 20 );
		add_action( 'wp_ajax_aep_atomic_bg_slider_preview', [ $this, 'ajax_preview' ] );
	}

	// ── Settings (props) ─────────────────────────────────────────────────────

	/**
	 * The props filter receives no element, so the props are added to every
	 * v4 element; only containers get the controls and the output.
	 */
	public function add_props( $schema ) {
		$props = [
			'aep_bg_slider_type'       => $this->choice( $this->type_options(), 'default' ),
			'aep_bg_slider_images'     => Atomic_Image_Array_Prop_Type::make()->default( [] )
				->set_dependencies( $this->when( 'aep_bg_slider_type', 'eq', 'default' ) ),
			'aep_bg_slider_source'     => $this->choice( $this->source_options(), 'custom_field' )
				->set_dependencies( $this->when( 'aep_bg_slider_type', 'eq', 'acf' ) ),
			'aep_bg_slider_field'      => String_Prop_Type::make()->default( '' )->meta( Dynamic_Prop_Type::META_KEY, false )
				->set_dependencies( $this->when( 'aep_bg_slider_type', 'ne', 'default' ) ),
			'aep_bg_slider_image_size' => $this->choice( $this->image_size_options(), 'large' ),
			'aep_bg_slider_transition' => $this->choice( array_combine( self::TRANSITIONS, self::TRANSITIONS ), 'fade' ),
			'aep_bg_slider_animation'  => $this->choice( array_combine( self::ANIMATIONS, self::ANIMATIONS ), 'kenburns' ),
			'aep_bg_slider_overlay'    => $this->choice( array_combine( self::OVERLAYS, self::OVERLAYS ), '01' ),
			'aep_bg_slider_cover'      => Boolean_Prop_Type::make()->default( true ),
			'aep_bg_slider_delay'      => Number_Prop_Type::make()->default( 5000 ),
			'aep_bg_slider_timer'      => Boolean_Prop_Type::make()->default( true ),
		];

		// Keep them out of Elementor 4 Components' overridable properties.
		$ignore = class_exists( Overridable_Prop_Type::class ) ? Overridable_Prop_Type::ignore() : null;

		foreach ( $props as $key => $prop ) {
			$schema[ $key ] = $ignore ? $prop->meta( $ignore ) : $prop;
		}

		return $schema;
	}

	public function register_transformer( $transformers ) {
		$transformers->register( Atomic_Image_Array_Prop_Type::get_key(), new Array_Transformer() );
	}

	// ── Controls ─────────────────────────────────────────────────────────────

	public function add_controls( $controls, $element ) {
		if ( ! is_object( $element ) || ! in_array( $element->get_type(), self::CONTAINER_TYPES, true ) ) {
			return $controls;
		}

		$type_buttons = [
			'default' => __( 'Images', 'ae-pro' ),
			'acf'     => __( 'ACF Gallery', 'ae-pro' ),
			'pods'    => __( 'Pods Gallery', 'ae-pro' ),
		];
		$items        = [ $this->button_group( 'aep_bg_slider_type', __( 'Type', 'ae-pro' ), array_intersect_key( $type_buttons, $this->type_options() ) ) ];

		$items[] = Repeatable_Control::bind_to( 'aep_bg_slider_images' )
			->set_repeaterLabel( __( 'Add Images', 'ae-pro' ) )
			->set_child_control_type( 'image' )
			->set_child_control_props( [ 'sizes' => Image_Sizes::get_all() ] )
			->set_initialValues( $this->initial_image() )
			->set_patternLabel( __( 'Image', 'ae-pro' ) )
			->set_placeholder( __( 'Empty image', 'ae-pro' ) )
			->set_prop_key( Atomic_Image_Array_Prop_Type::get_key() );

		if ( count( $this->type_options() ) > 1 ) {
			// Where the ACF gallery field is read from; Pods always uses the current post.
			if ( isset( $this->type_options()['acf'] ) ) {
				$items[] = $this->button_group(
					'aep_bg_slider_source',
					__( 'Source', 'ae-pro' ),
					[
						'custom_field'             => __( 'Post', 'ae-pro' ),
						'term_custom_field'        => __( 'Term', 'ae-pro' ),
						'option_page_custom_field' => __( 'Options Page', 'ae-pro' ),
					]
				);
			}
			$items[] = Text_Control::bind_to( 'aep_bg_slider_field' )->set_placeholder( __( 'Field slug', 'ae-pro' ) )->set_label( __( 'Custom Field Name (field slug)', 'ae-pro' ) );
		}

		$items[] = $this->select( 'aep_bg_slider_image_size', __( 'Image Size', 'ae-pro' ), $this->image_size_options() );
		$items[] = $this->select( 'aep_bg_slider_transition', __( 'Transition', 'ae-pro' ), $this->labelled( self::TRANSITIONS ) );
		$items[] = $this->select( 'aep_bg_slider_animation', __( 'Animation', 'ae-pro' ), $this->labelled( self::ANIMATIONS ) );
		$items[] = $this->select( 'aep_bg_slider_overlay', __( 'Overlay', 'ae-pro' ), $this->overlay_options() );
		$items[] = Switch_Control::bind_to( 'aep_bg_slider_cover' )->set_label( __( 'Cover', 'ae-pro' ) );
		$items[] = Number_Control::bind_to( 'aep_bg_slider_delay' )->set_min( 500 )->set_step( 500 )->set_label( __( 'Delay (ms)', 'ae-pro' ) );
		$items[] = Switch_Control::bind_to( 'aep_bg_slider_timer' )->set_label( __( 'Timer', 'ae-pro' ) );

		$controls[] = Section::make()
			->set_label( __( 'Background Slider', 'ae-pro' ) )
			->set_id( 'aep-bg-slider' )
			->set_items( $items );

		return $controls;
	}

	// ── Render ───────────────────────────────────────────────────────────────

	public function before_render( $element ) {
		if ( ! method_exists( $element, 'get_atomic_settings' ) ) {
			return;
		}

		try {
			$config = $this->build_config( $element->get_atomic_settings() );
		} catch ( \Throwable $e ) {
			return;
		}

		if ( ! $config ) {
			return;
		}

		AtomicElementAttributes::instance()->add(
			$element->get_id(),
			[
				'class'              => 'aep-v4-bg-slider',
				'data-aep-bg-slider' => wp_json_encode( $config ),
			]
		);
	}

	/**
	 * Slides and Vegas options for one container, or null when it has none.
	 *
	 * @param array $settings Resolved v4 settings.
	 * @return array|null
	 */
	private function build_config( array $settings ) {
		$size   = $this->pick( $settings, 'aep_bg_slider_image_size', $this->image_size_options(), 'large' );
		$slides = [];

		foreach ( $this->get_images( $settings ) as $image ) {
			$url = $this->image_url( $image, $size );
			if ( '' !== $url ) {
				$slides[] = [ 'src' => $url ];
			}
		}

		if ( ! $slides ) {
			return null;
		}

		$overlay = $this->pick( $settings, 'aep_bg_slider_overlay', array_flip( self::OVERLAYS ), '01' );
		$delay   = isset( $settings['aep_bg_slider_delay'] ) ? absint( $settings['aep_bg_slider_delay'] ) : 5000;

		return [
			'slides'     => $slides,
			'transition' => $this->pick( $settings, 'aep_bg_slider_transition', array_flip( self::TRANSITIONS ), 'fade' ),
			'animation'  => $this->pick( $settings, 'aep_bg_slider_animation', array_flip( self::ANIMATIONS ), 'kenburns' ),
			'overlay'    => '' === $overlay ? false : AE_PRO_URL . 'includes/assets/lib/vegas/overlays/' . $overlay . '.png',
			'cover'      => ! isset( $settings['aep_bg_slider_cover'] ) || (bool) $settings['aep_bg_slider_cover'],
			'delay'      => max( 500, $delay ? $delay : 5000 ),
			'timer'      => ! isset( $settings['aep_bg_slider_timer'] ) || (bool) $settings['aep_bg_slider_timer'],
		];
	}

	/**
	 * The images to slide, in the same order and from the same places as v3.
	 *
	 * @return array Items: attachment IDs, URLs, or [ 'id' => …, 'src' => … ] arrays.
	 */
	private function get_images( array $settings ) {
		$type = $settings['aep_bg_slider_type'] ?? 'default';

		if ( 'default' === $type ) {
			$images = $settings['aep_bg_slider_images'] ?? [];
			return is_array( $images ) ? $images : [];
		}

		$field = isset( $settings['aep_bg_slider_field'] ) ? trim( (string) $settings['aep_bg_slider_field'] ) : '';
		if ( '' === $field ) {
			return [];
		}

		$post    = Aepro::$_helper ? Aepro::$_helper->get_demo_post_data() : null;
		$post_id = $post instanceof \WP_Post ? $post->ID : get_the_ID();

		if ( 'pods' === $type ) {
			$images = get_post_meta( $post_id, $field );
			return is_array( $images ) ? $images : [];
		}

		if ( ! function_exists( 'get_field' ) ) {
			return [];
		}

		switch ( $settings['aep_bg_slider_source'] ?? 'custom_field' ) {
			case 'term_custom_field':
				$images = get_field( $field, get_queried_object() );
				break;
			case 'option_page_custom_field':
				$images = get_field( $field, 'option', true );
				break;
			default:
				$images = get_field( $field, $post_id );
				if ( empty( $images ) && function_exists( 'acf_photo_gallery' ) ) {
					$images = acf_photo_gallery( $field, $post_id );
				}
		}

		return is_array( $images ) ? $images : [];
	}

	/**
	 * URL of one image at the chosen size. Accepts an attachment ID, a URL, an
	 * ACF / Pods image array, or a resolved v4 image.
	 */
	private function image_url( $image, $size ) {
		$id  = 0;
		$url = '';

		if ( is_numeric( $image ) ) {
			$id = (int) $image;
		} elseif ( is_string( $image ) ) {
			$url = $image;
		} elseif ( is_array( $image ) ) {
			$id  = (int) ( $image['ID'] ?? $image['id'] ?? 0 );
			$url = (string) ( $image['src'] ?? $image['url'] ?? $image['full_image_url'] ?? '' );
		}

		if ( $id ) {
			$src = wp_get_attachment_image_url( $id, $size );
			if ( $src ) {
				return esc_url_raw( $src );
			}
		}

		// Skip the placeholder a new, still empty "Add Images" item starts with.
		if ( '' === $url || ( class_exists( Placeholder_Image::class ) && Placeholder_Image::get_placeholder_image() === $url ) ) {
			return '';
		}

		return esc_url_raw( $url );
	}

	// ── Assets and editor preview ────────────────────────────────────────────

	public function enqueue_scripts() {
		wp_enqueue_style( 'vegas-css' );
		wp_add_inline_style(
			'vegas-css',
			'.aep-v4-bg-slider{position:relative;isolation:isolate}' .
			'.aep-v4-bg-slider>.aepro-section-bs{z-index:-1;overflow:hidden;pointer-events:none}'
		);

		wp_enqueue_script(
			self::HANDLE,
			AE_PRO_URL . 'pro/modules/bg-slider/assets/js/atomic-bg-slider.js',
			[ 'jquery', 'vegas' ],
			AE_PRO_VERSION,
			true
		);

		$is_preview = isset( \Elementor\Plugin::$instance->preview ) && \Elementor\Plugin::$instance->preview->is_preview_mode();

		wp_localize_script(
			self::HANDLE,
			'aepAtomicBgSlider',
			[
				'types'   => self::CONTAINER_TYPES,
				'ajaxUrl' => $is_preview ? admin_url( 'admin-ajax.php' ) : '',
				'nonce'   => $is_preview ? wp_create_nonce( 'aep_atomic_bg_slider_preview' ) : '',
				'keys'    => array_keys( $this->add_props( [] ) ),
			]
		);
	}

	/**
	 * Editor preview: resolves one container's slides in the document's
	 * preview context (a Dynific template's preview post).
	 */
	public function ajax_preview() {
		check_ajax_referer( 'aep_atomic_bg_slider_preview', 'nonce' );

		$post_id = isset( $_POST['post_id'] ) ? absint( $_POST['post_id'] ) : 0;
		if ( ! $post_id || ! current_user_can( 'edit_post', $post_id ) ) {
			wp_send_json_error( [], 403 );
		}

		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- JSON, validated by Elementor's props resolver below.
		$raw = isset( $_POST['settings'] ) ? json_decode( wp_unslash( $_POST['settings'] ), true ) : null;
		if ( ! is_array( $raw ) ) {
			wp_send_json_error( [], 400 );
		}

		$schema = $this->add_props( [] );
		$raw    = array_intersect_key( $raw, $schema );

		$document_post = get_post( $post_id );
		if ( ! $document_post ) {
			wp_send_json_error( [], 404 );
		}

		$GLOBALS['post'] = $document_post; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
		setup_postdata( $document_post );

		try {
			$config = $this->build_config( Render_Props_Resolver::for_settings()->resolve( $schema, $raw ) );
		} catch ( \Throwable $e ) {
			$config = null;
		}

		wp_reset_postdata();

		wp_send_json_success( [ 'config' => $config ] );
	}

	// ── Helpers ──────────────────────────────────────────────────────────────

	private function when( $path, $operator, $value ) {
		return Dependency_Manager::make( Dependency_Manager::RELATION_AND )
			->where(
				[
					'operator' => $operator,
					'path'     => [ $path ],
					'value'    => $value,
					'effect'   => 'hide',
				]
			)
			->get();
	}

	private function choice( array $options, $default ) {
		return String_Prop_Type::make()->enum( array_map( 'strval', array_keys( $options ) ) )->default( (string) $default );
	}

	private function pick( array $settings, $key, array $options, $default ) {
		$value = isset( $settings[ $key ] ) ? (string) $settings[ $key ] : null;
		return ( null !== $value && array_key_exists( $value, $options ) ) ? $value : $default;
	}

	/**
	 * Full-width text button group (Elementor 4's toggle control), for short
	 * lists of choices.
	 *
	 * @param array<string,string> $options value => button text.
	 */
	private function button_group( $bind, $label, array $options ) {
		$buttons = [];
		foreach ( $options as $value => $text ) {
			$buttons[ $value ] = [ 'title' => $text ];
		}

		return Toggle_Control::bind_to( $bind )
			->add_options( $buttons )
			->set_size( 'tiny' )
			->set_exclusive( true )
			->set_full_width( true )
			->set_convert_options( true )
			->set_label( $label );
	}

	private function select( $bind, $label, array $options ) {
		$select = [];
		foreach ( $options as $value => $option_label ) {
			$select[] = [
				'value' => (string) $value,
				'label' => $option_label,
			];
		}
		return Select_Control::bind_to( $bind )->set_options( $select )->set_label( $label );
	}

	private function labelled( array $values ) {
		$options = [];
		foreach ( $values as $value ) {
			$options[ $value ] = '' === $value ? __( 'None', 'ae-pro' ) : ucfirst( preg_replace( '/([a-z])([A-Z0-9])/', '$1 $2', $value ) );
		}
		return $options;
	}

	private function initial_image() {
		return [
			'src'  => Image_Src_Prop_Type::generate(
				[
					'id'  => null,
					'url' => Url_Prop_Type::generate( Placeholder_Image::get_placeholder_image() ),
				]
			),
			'size' => String_Prop_Type::generate( 'full' ),
		];
	}

	private function type_options() {
		$options = [ 'default' => __( 'Default', 'ae-pro' ) ];
		if ( \Aepro\Plugin::show_acf( true ) ) {
			$options['acf'] = __( 'ACF Gallery', 'ae-pro' );
		}
		if ( defined( 'PODS_VERSION' ) ) {
			$options['pods'] = __( 'PODS Gallery', 'ae-pro' );
		}
		return $options;
	}

	private function source_options() {
		return [
			'custom_field'             => __( 'Post Custom Field', 'ae-pro' ),
			'term_custom_field'        => __( 'Term Custom Field', 'ae-pro' ),
			'option_page_custom_field' => __( 'Option Page Custom Field', 'ae-pro' ),
		];
	}

	private function image_size_options() {
		$sizes = Aepro::$_helper ? Aepro::$_helper->ae_get_intermediate_image_sizes() : [];
		return is_array( $sizes ) && $sizes ? $sizes : [ 'large' => __( 'Large', 'ae-pro' ) ];
	}

	private function overlay_options() {
		$options = [];
		foreach ( self::OVERLAYS as $index => $value ) {
			/* translators: %d: overlay style number. */
			$options[ $value ] = '' === $value ? __( 'None', 'ae-pro' ) : sprintf( __( 'Style %d', 'ae-pro' ), $index );
		}
		return $options;
	}
}
