/**
 * Dynific Background Slider on Elementor 4 (v4) Div Block, Flexbox and Grid.
 *
 * Frontend: containers carry their slides in data-aep-bg-slider (written by
 * AtomicBgSlider); this starts Vegas on them, also for ones added later.
 *
 * Editor canvas: Elementor 4 draws v4 containers in the browser, so the
 * attribute is never there. Inside the preview frame this reads each
 * container's slider settings from the editor, asks the server for the slides
 * (ACF / Pods galleries need it) and keeps the slider in sync with edits.
 */
( function ( $ ) {
	'use strict';

	var cfg = window.aepAtomicBgSlider || {};
	var TYPES = cfg.types || [ 'e-div-block', 'e-flexbox', 'e-grid' ];
	var KEYS = cfg.keys || [];
	var CONTAINERS = TYPES.map( function ( type ) {
		return '[data-e-type="' + type + '"][data-id]';
	} ).join( ',' );

	// ── Mounting ─────────────────────────────────────────────────────────────

	var running = []; // Vegas containers started by this script.

	function stop( inner ) {
		try {
			$( inner ).vegas( 'destroy' );
		} catch ( e ) {}
		running = running.filter( function ( item ) {
			return item !== inner;
		} );
	}

	// Stops sliders whose layer the editor removed while redrawing a container.
	function cleanup() {
		running.slice().forEach( function ( inner ) {
			if ( ! inner.isConnected ) {
				stop( inner );
			}
		} );
	}

	function getLayer( el ) {
		for ( var i = 0; i < el.children.length; i++ ) {
			if ( el.children[ i ].classList.contains( 'aepro-section-bs' ) && el.children[ i ].hasAttribute( 'data-aep-v4' ) ) {
				return el.children[ i ];
			}
		}
		return null;
	}

	function unmount( el ) {
		var layer = getLayer( el );
		if ( layer ) {
			stop( layer.firstChild );
			layer.remove();
		}
		el.removeAttribute( 'data-aep-bg-slider-mounted' );
	}

	function mount( el, config, key ) {
		if ( typeof $.fn.vegas !== 'function' || ! config || ! config.slides || ! config.slides.length ) {
			return;
		}

		unmount( el );

		var layer = document.createElement( 'div' );
		var inner = document.createElement( 'div' );
		layer.className = 'aepro-section-bs';
		layer.setAttribute( 'data-aep-v4', '' );
		inner.className = 'aepro-section-bs-inner cover-' + ( config.cover ? 'true' : 'false' );
		layer.appendChild( inner );
		el.classList.add( 'aep-v4-bg-slider' );
		el.insertBefore( layer, el.firstChild );

		$( inner ).vegas( {
			slides: config.slides,
			transition: config.transition,
			animation: config.animation,
			overlay: config.overlay || false,
			cover: config.cover,
			delay: config.delay,
			timer: config.timer,
		} );
		running.push( inner );

		el.setAttribute( 'data-aep-bg-slider-mounted', key );
	}

	// ── Frontend ─────────────────────────────────────────────────────────────

	function mountFrontend( root ) {
		var nodes = root.querySelectorAll ? Array.prototype.slice.call( root.querySelectorAll( '[data-aep-bg-slider]' ) ) : [];
		if ( root.matches && root.matches( '[data-aep-bg-slider]' ) ) {
			nodes.unshift( root );
		}

		nodes.forEach( function ( el ) {
			var raw = el.getAttribute( 'data-aep-bg-slider' );
			if ( el.getAttribute( 'data-aep-bg-slider-mounted' ) === raw && getLayer( el ) ) {
				return;
			}
			try {
				mount( el, JSON.parse( raw ), raw );
			} catch ( e ) {}
		} );
	}

	// ── Editor canvas ────────────────────────────────────────────────────────

	var editorWindow = null;
	var configCache = {};
	var inFlight = {};
	var syncTimer = null;

	function getEditorWindow() {
		try {
			if ( window.parent !== window && window.parent.elementor && window.parent.elementor.getContainer ) {
				return window.parent;
			}
		} catch ( e ) {}
		return null;
	}

	function readSettings( id ) {
		var container;
		try {
			container = editorWindow.elementor.getContainer( id );
		} catch ( e ) {
			return null;
		}
		if ( ! container || ! container.settings || TYPES.indexOf( container.model.get( 'elType' ) ) === -1 ) {
			return null;
		}

		var settings = {};
		KEYS.forEach( function ( key ) {
			var value = container.settings.get( key );
			if ( undefined !== value && null !== value ) {
				settings[ key ] = value && value.toJSON ? value.toJSON() : value;
			}
		} );
		return settings;
	}

	function plain( value ) {
		return value && 'object' === typeof value && 'value' in value ? value.value : value;
	}

	function hasSource( settings ) {
		var type = plain( settings.aep_bg_slider_type ) || 'default';
		if ( 'default' === type ) {
			var images = plain( settings.aep_bg_slider_images );
			return Array.isArray( images ) && images.length > 0;
		}
		return !! plain( settings.aep_bg_slider_field );
	}

	function documentId() {
		try {
			return editorWindow.elementor.documents.getCurrent().id;
		} catch ( e ) {
			return 0;
		}
	}

	function syncElement( el ) {
		var id = el.getAttribute( 'data-id' );
		var settings = readSettings( id );

		if ( ! settings || ! hasSource( settings ) ) {
			if ( el.hasAttribute( 'data-aep-bg-slider-mounted' ) || getLayer( el ) ) {
				unmount( el );
			}
			return;
		}

		var key = JSON.stringify( settings );

		if ( el.getAttribute( 'data-aep-bg-slider-mounted' ) === key && getLayer( el ) ) {
			return;
		}

		if ( configCache.hasOwnProperty( key ) ) {
			if ( configCache[ key ] ) {
				mount( el, configCache[ key ], key );
			} else {
				unmount( el );
			}
			return;
		}

		if ( inFlight[ key ] ) {
			return;
		}
		inFlight[ key ] = true;

		$.post( cfg.ajaxUrl, {
			action: 'aep_atomic_bg_slider_preview',
			nonce: cfg.nonce,
			post_id: documentId(),
			settings: key,
		} ).done( function ( response ) {
			configCache[ key ] = response && response.success && response.data ? response.data.config || null : null;
		} ).fail( function () {
			configCache[ key ] = null;
		} ).always( function () {
			delete inFlight[ key ];
			scheduleSync();
		} );
	}

	function syncEditor() {
		syncTimer = null;
		cleanup();
		document.querySelectorAll( CONTAINERS ).forEach( syncElement );
	}

	function scheduleSync() {
		if ( ! syncTimer ) {
			syncTimer = setTimeout( syncEditor, 150 );
		}
	}

	function startEditor() {
		editorWindow.addEventListener( 'elementor/commands/run/after', function ( event ) {
			var command = ( event.detail && event.detail.command ) || '';
			if ( /^document\/elements\//.test( command ) ) {
				scheduleSync();
			}
		} );

		// v4 elements are inserted as placeholders and get data-id / data-e-type
		// afterwards; redraws replace their children (removing the slider layer).
		new MutationObserver( function ( mutations ) {
			for ( var i = 0; i < mutations.length; i++ ) {
				if ( 'attributes' === mutations[ i ].type || mutations[ i ].addedNodes.length || mutations[ i ].removedNodes.length ) {
					scheduleSync();
					return;
				}
			}
		} ).observe( document.body, {
			childList: true,
			subtree: true,
			attributes: true,
			attributeFilter: [ 'data-id', 'data-e-type' ],
		} );

		scheduleSync();
	}

	// ── Boot ─────────────────────────────────────────────────────────────────

	function boot() {
		editorWindow = cfg.ajaxUrl ? getEditorWindow() : null;

		if ( editorWindow ) {
			startEditor();
			return;
		}

		mountFrontend( document );

		// Containers added later (AJAX pagination, load more, filters).
		new MutationObserver( function ( mutations ) {
			mutations.forEach( function ( mutation ) {
				mutation.addedNodes.forEach( function ( node ) {
					if ( 1 === node.nodeType ) {
						mountFrontend( node );
					}
				} );
			} );
		} ).observe( document.body, { childList: true, subtree: true } );
	}

	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', boot );
	} else {
		boot();
	}
}( jQuery ) );
