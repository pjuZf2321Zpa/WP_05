/**
 * Dynific Dynamic Rules: the "Rules" control in the Elementor 4 (v4) panel.
 *
 * Registers the `aep-dynamic-rules` control type. It edits the same rows as
 * v3's Rules repeater (same keys, defaults and show/hide conditions, sent by
 * AtomicDynamicRules as aepAtomicDynamicRules.fields) and stores them in the
 * element's `ae_dynamic_rules` setting as JSON. The AJAX pickers (posts,
 * users, terms, repeater / group sub-fields) use v3's own query endpoints.
 */
( function () {
	'use strict';

	var cfg = window.aepAtomicDynamicRules || {};
	var FIELDS = cfg.fields || [];
	var I18N = cfg.i18n || {};
	var FIELD_BY_NAME = {};

	FIELDS.forEach( function ( field ) {
		FIELD_BY_NAME[ field.name ] = field;
	} );

	// ── Rows ────────────────────────────────────────────────────────────────

	function newId() {
		return Math.random().toString( 16 ).slice( 2, 9 );
	}

	function parseRows( value ) {
		var rows;
		try {
			rows = JSON.parse( value || '[]' );
		} catch ( e ) {
			rows = [];
		}
		return Array.isArray( rows ) ? rows.filter( function ( row ) {
			return row && 'object' === typeof row;
		} ) : [];
	}

	function getValue( row, name ) {
		if ( Object.prototype.hasOwnProperty.call( row, name ) ) {
			return row[ name ];
		}
		var field = FIELD_BY_NAME[ name ];
		return field ? field.default : '';
	}

	/** v3 condition semantics: { key: value | [values], 'key!': ... } — all must hold. */
	function isShown( field, row ) {
		var condition = field.condition || {};
		return Object.keys( condition ).every( function ( key ) {
			var negate = '!' === key.slice( -1 );
			var name = negate ? key.slice( 0, -1 ) : key;
			var expected = condition[ key ];
			var actual = getValue( row, name );
			var match = Array.isArray( expected )
				? expected.map( String ).indexOf( String( actual ) ) !== -1
				: String( expected ) === String( actual );
			return negate ? ! match : match;
		} );
	}

	function allOptions( field ) {
		if ( field.groups ) {
			return field.groups.reduce( function ( list, group ) {
				return list.concat( group.options );
			}, [] );
		}
		return field.options || [];
	}

	function ruleTitle( row ) {
		var typeField = FIELD_BY_NAME.ae_rule_type;
		var type = getValue( row, 'ae_rule_type' );
		var option = typeField ? allOptions( typeField ).filter( function ( item ) {
			return item.value === type;
		} )[ 0 ] : null;
		return ( I18N.rule || 'Rule' ) + ': ' + ( option ? option.label : type );
	}

	// ── AJAX (v3's aep-query endpoints) ─────────────────────────────────────

	function queryData( field, row, q ) {
		var query = field.query || {};
		var data = {
			q: q,
			query_type: query.type,
			object_type: query.objectType,
		};
		if ( 'repeater-sub-fields' === query.type ) {
			data.repeater_parent_field = getValue( row, query.parentField );
		}
		if ( 'group-sub-fields' === query.type ) {
			data.group_field = getValue( row, query.parentField );
			if ( query.supportedField ) {
				data.supported_field = query.supportedField;
			}
		}
		if ( 'flex-sub-fields' === query.type ) {
			data.flex_parent_field = getValue( row, query.parentField );
		}
		return data;
	}

	function isSubFieldQuery( field ) {
		return /-sub-fields$/.test( ( field.query || {} ).type || '' );
	}

	function search( field, row, q ) {
		return new Promise( function ( resolve ) {
			var ajax = window.elementorCommon && elementorCommon.ajax;
			if ( ! ajax ) {
				resolve( [] );
				return;
			}
			ajax.addRequest( 'aep_query_autocomplete_data', {
				data: queryData( field, row, q ),
				success: function ( response ) {
					resolve( ( ( response && response.results ) || [] ).map( function ( item ) {
						return { value: String( item.id ), label: String( item.text ) };
					} ) );
				},
				error: function () {
					resolve( [] );
				},
			} );
		} );
	}

	function loadTitles( field, row, ids ) {
		return new Promise( function ( resolve ) {
			var ajax = window.elementorCommon && elementorCommon.ajax;
			if ( ! ajax || ! ids.length ) {
				resolve( {} );
				return;
			}
			var data = queryData( field, row, '' );
			delete data.q;
			ajax.loadObjects( {
				action: 'aep_query_value_titles',
				ids: ids,
				data: data,
				success: function ( titles ) {
					resolve( titles || {} );
				},
				error: function () {
					resolve( {} );
				},
			} );
		} );
	}

	// ── Control ─────────────────────────────────────────────────────────────

	function build() {
		var V2 = window.elementorV2;
		var React = window.React;
		var UI = V2.ui;
		var Icons = V2.icons || {};
		var controls = V2.editorControls;
		var h = React.createElement;

		function icon( name ) {
			return Icons[ name ] ? h( Icons[ name ], { fontSize: 'tiny' } ) : null;
		}

		function SelectField( props ) {
			var field = props.field;
			var value = String( props.value === undefined || props.value === null ? '' : props.value );
			var children = [];

			if ( field.groups ) {
				field.groups.forEach( function ( group, index ) {
					children.push( h( UI.ListSubheader, { key: 'g' + index }, group.label ) );
					group.options.forEach( function ( option ) {
						children.push( h( UI.MenuItem, { key: 'o' + index + option.value, value: option.value }, option.label ) );
					} );
				} );
			} else {
				( field.options || [] ).forEach( function ( option ) {
					children.push( h( UI.MenuItem, { key: option.value, value: option.value }, option.label ) );
				} );
			}

			// Keep a saved value that is no longer offered visible.
			var known = allOptions( field ).some( function ( option ) {
				return option.value === value;
			} );
			if ( value && ! known ) {
				children.push( h( UI.MenuItem, { key: '__saved', value: value }, value ) );
			}

			return h( UI.Select, {
				size: 'tiny',
				fullWidth: true,
				displayEmpty: true,
				value: value,
				onChange: function ( event ) {
					props.onChange( event.target.value );
				},
				renderValue: function ( selected ) {
					var option = allOptions( field ).filter( function ( item ) {
						return item.value === selected;
					} )[ 0 ];
					return option ? option.label : ( selected && selected.trim() ? selected : ( I18N.select || 'Select' ) );
				},
				MenuProps: { PaperProps: { sx: { maxHeight: 320 } } },
			}, children );
		}

		function MultiSelectField( props ) {
			var options = allOptions( props.field );
			var values = ( Array.isArray( props.value ) ? props.value : ( props.value ? [ props.value ] : [] ) ).map( String );
			var selected = values.map( function ( value ) {
				return options.filter( function ( option ) {
					return option.value === value;
				} )[ 0 ] || { value: value, label: value };
			} );

			return h( UI.Autocomplete, {
				multiple: true,
				size: 'tiny',
				options: options,
				value: selected,
				disableCloseOnSelect: true,
				getOptionLabel: function ( option ) {
					return option.label;
				},
				isOptionEqualToValue: function ( option, value ) {
					return option.value === value.value;
				},
				onChange: function ( event, list ) {
					props.onChange( list.map( function ( option ) {
						return option.value;
					} ) );
				},
				renderInput: function ( params ) {
					return h( UI.TextField, Object.assign( {}, params, { size: 'tiny', placeholder: values.length ? '' : ( I18N.select || 'Select' ) } ) );
				},
			} );
		}

		function QueryField( props ) {
			var field = props.field;
			var row = props.row;
			var multiple = !! field.multiple;
			var subFields = isSubFieldQuery( field );
			var parentValue = subFields ? String( getValue( row, field.query.parentField ) || '' ) : '';
			var values = ( multiple ? ( Array.isArray( props.value ) ? props.value : ( props.value ? [ props.value ] : [] ) ) : ( props.value ? [ props.value ] : [] ) ).map( String );

			var optionsState = React.useState( [] );
			var options = optionsState[ 0 ];
			var setOptions = optionsState[ 1 ];
			var titlesState = React.useState( {} );
			var titles = titlesState[ 0 ];
			var setTitles = titlesState[ 1 ];
			var loadingState = React.useState( false );
			var loading = loadingState[ 0 ];
			var setLoading = loadingState[ 1 ];
			var inputState = React.useState( '' );
			var input = inputState[ 0 ];
			var setInput = inputState[ 1 ];

			// Sub-field pickers: the whole list for the chosen parent field.
			React.useEffect( function () {
				if ( ! subFields ) {
					return;
				}
				setOptions( [] );
				if ( ! parentValue.trim() ) {
					return;
				}
				var alive = true;
				setLoading( true );
				search( field, row, ' ' ).then( function ( results ) {
					if ( alive ) {
						setOptions( results );
						setLoading( false );
					}
				} );
				return function () {
					alive = false;
				};
			}, [ parentValue ] ); // eslint-disable-line react-hooks/exhaustive-deps

			// Posts / users / terms: titles of the saved IDs.
			var idsKey = values.join( ',' );
			React.useEffect( function () {
				if ( subFields || ! values.length ) {
					return;
				}
				var missing = values.filter( function ( id ) {
					return ! titles[ id ];
				} );
				if ( ! missing.length ) {
					return;
				}
				var alive = true;
				loadTitles( field, row, missing ).then( function ( result ) {
					if ( alive ) {
						setTitles( function ( current ) {
							return Object.assign( {}, current, result );
						} );
					}
				} );
				return function () {
					alive = false;
				};
			}, [ idsKey ] ); // eslint-disable-line react-hooks/exhaustive-deps

			// Posts / users / terms: search as the user types.
			React.useEffect( function () {
				if ( subFields || ! input.trim() ) {
					return;
				}
				var alive = true;
				var timer = setTimeout( function () {
					setLoading( true );
					search( field, row, input ).then( function ( results ) {
						if ( alive ) {
							setOptions( results );
							setLoading( false );
						}
					} );
				}, 300 );
				return function () {
					alive = false;
					clearTimeout( timer );
				};
			}, [ input ] ); // eslint-disable-line react-hooks/exhaustive-deps

			function label( id ) {
				var option = options.filter( function ( item ) {
					return item.value === id;
				} )[ 0 ];
				return option ? option.label : ( titles[ id ] || id );
			}

			var selected = values.map( function ( id ) {
				return { value: id, label: label( id ) };
			} );

			var noOptions = subFields && ! parentValue.trim() ? I18N.pickParent : ( subFields || input.trim() ? I18N.noOptions : I18N.search );

			return h( UI.Autocomplete, {
				multiple: multiple,
				size: 'tiny',
				options: options,
				value: multiple ? selected : ( selected[ 0 ] || null ),
				loading: loading,
				loadingText: I18N.loading,
				noOptionsText: noOptions,
				filterOptions: subFields ? undefined : function ( list ) {
					return list;
				},
				onInputChange: function ( event, text, reason ) {
					if ( 'input' === reason ) {
						setInput( text );
					}
				},
				getOptionLabel: function ( option ) {
					return option.label;
				},
				isOptionEqualToValue: function ( option, value ) {
					return option.value === value.value;
				},
				onChange: function ( event, chosen ) {
					if ( multiple ) {
						props.onChange( ( chosen || [] ).map( function ( option ) {
							return option.value;
						} ) );
					} else {
						props.onChange( chosen ? chosen.value : '' );
					}
				},
				renderInput: function ( params ) {
					return h( UI.TextField, Object.assign( {}, params, { size: 'tiny', placeholder: values.length ? '' : ( subFields ? I18N.select : I18N.search ) } ) );
				},
			} );
		}

		function InputField( props ) {
			var type = props.field.type;
			var inputType = { date: 'date', datetime: 'datetime-local', time: 'time' }[ type ] || 'text';
			return h( UI.TextField, {
				size: 'tiny',
				fullWidth: true,
				type: inputType,
				multiline: 'textarea' === type,
				minRows: 'textarea' === type ? 3 : undefined,
				inputProps: 'time' === type ? { step: 1 } : undefined,
				value: props.value === undefined || props.value === null ? '' : String( props.value ),
				onChange: function ( event ) {
					props.onChange( event.target.value );
				},
			} );
		}

		function Field( props ) {
			var field = props.field;
			var type = field.type;
			var input;

			if ( 'select' === type ) {
				input = h( SelectField, props );
			} else if ( 'multiselect' === type ) {
				input = h( MultiSelectField, props );
			} else if ( 'query' === type ) {
				input = h( QueryField, props );
			} else {
				input = h( InputField, props );
			}

			return h( UI.Stack, { gap: 0.5 },
				h( UI.Typography, { variant: 'caption', color: 'text.secondary' }, field.label ),
				input,
				field.description ? h( UI.FormHelperText, null, field.description ) : null
			);
		}

		function RuleRow( props ) {
			var row = props.row;

			var header = h( UI.Stack, {
				direction: 'row',
				alignItems: 'center',
				gap: 0.5,
				sx: { cursor: 'pointer', px: 1, py: 0.5 },
				onClick: props.onToggle,
			},
			h( UI.Typography, { variant: 'caption', sx: { flexGrow: 1, fontWeight: 500 } }, ruleTitle( row ) ),
			h( UI.Tooltip, { title: I18N.duplicate || 'Duplicate' },
				h( UI.IconButton, { size: 'tiny', 'aria-label': I18N.duplicate, onClick: function ( event ) {
					event.stopPropagation();
					props.onDuplicate();
				} }, icon( 'CopyIcon' ) )
			),
			h( UI.Tooltip, { title: I18N.remove || 'Remove' },
				h( UI.IconButton, { size: 'tiny', 'aria-label': I18N.remove, onClick: function ( event ) {
					event.stopPropagation();
					props.onRemove();
				} }, icon( 'XIcon' ) )
			) );

			var body = props.open ? h( UI.Stack, { gap: 1.5, sx: { px: 1, pt: 0.5, pb: 1.5 } },
				FIELDS.filter( function ( field ) {
					return isShown( field, row );
				} ).map( function ( field ) {
					return h( Field, {
						key: field.name,
						field: field,
						row: row,
						value: getValue( row, field.name ),
						onChange: function ( value ) {
							props.onChange( field.name, value );
						},
					} );
				} )
			) : null;

			return h( UI.Paper, { variant: 'outlined', sx: { overflow: 'hidden' } }, header, body );
		}

		var RulesControl = controls.createControl( function () {
			var bound = controls.useBoundProp( V2.editorProps.stringPropTypeUtil );
			var rows = parseRows( bound.value );
			var openState = React.useState( rows.length === 1 ? 0 : -1 );
			var open = openState[ 0 ];
			var setOpen = openState[ 1 ];

			function save( next ) {
				bound.setValue( JSON.stringify( next ) );
			}

			function update( index, name, value ) {
				save( rows.map( function ( row, i ) {
					if ( i !== index ) {
						return row;
					}
					var copy = Object.assign( {}, row );
					copy[ name ] = value;
					return copy;
				} ) );
			}

			function add() {
				var next = rows.concat( [ { _id: newId(), ae_rule_type: getValue( {}, 'ae_rule_type' ) } ] );
				save( next );
				setOpen( next.length - 1 );
			}

			function duplicate( index ) {
				var copy = Object.assign( {}, rows[ index ], { _id: newId() } );
				var next = rows.slice( 0, index + 1 ).concat( [ copy ], rows.slice( index + 1 ) );
				save( next );
				setOpen( index + 1 );
			}

			function remove( index ) {
				save( rows.filter( function ( row, i ) {
					return i !== index;
				} ) );
				setOpen( -1 );
			}

			return h( UI.Stack, { gap: 1 },
				rows.length ? rows.map( function ( row, index ) {
					return h( RuleRow, {
						key: row._id || index,
						row: row,
						open: open === index,
						onToggle: function () {
							setOpen( open === index ? -1 : index );
						},
						onChange: function ( name, value ) {
							update( index, name, value );
						},
						onDuplicate: function () {
							duplicate( index );
						},
						onRemove: function () {
							remove( index );
						},
					} );
				} ) : h( UI.Typography, { variant: 'caption', color: 'text.secondary' }, I18N.noRules ),
				h( UI.Button, {
					size: 'small',
					variant: 'outlined',
					color: 'secondary',
					startIcon: icon( 'PlusIcon' ),
					onClick: add,
				}, I18N.addRule || 'Add Rule' )
			);
		} );

		return RulesControl;
	}

	// ── Registration ────────────────────────────────────────────────────────

	function register() {
		var V2 = window.elementorV2;
		var panel = V2 && V2.editorEditingPanel;
		if ( ! panel || ! panel.controlsRegistry || ! V2.editorControls || ! V2.ui || ! V2.editorProps || ! window.React ) {
			return false;
		}
		try {
			panel.controlsRegistry.register( 'aep-dynamic-rules', build(), 'full', V2.editorProps.stringPropTypeUtil );
		} catch ( e ) {
			// Already registered (script loaded twice).
		}
		return true;
	}

	if ( ! register() ) {
		var tries = 0;
		var timer = setInterval( function () {
			if ( register() || ++tries > 100 ) {
				clearInterval( timer );
			}
		}, 100 );
	}
}() );
