<?php

namespace Aepro\Modules\DynamicRules;

use Elementor\Modules\AtomicWidgets\Controls\Base\Atomic_Control_Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Elementor 4 panel control for the Dynamic Rules list.
 *
 * Rendered by assets/js/atomic-dynamic-rules-editor.js, which registers the
 * `aep-dynamic-rules` control type. The rule fields it shows per row come from
 * the localized script data (shared by every element), so the control itself
 * carries no props.
 */
class AtomicRulesControl extends Atomic_Control_Base {

	public function get_type(): string {
		return 'aep-dynamic-rules';
	}

	public function get_props(): array {
		return [];
	}
}
