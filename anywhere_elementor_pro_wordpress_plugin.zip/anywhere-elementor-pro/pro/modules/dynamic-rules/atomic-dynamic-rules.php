<?php

namespace Aepro\Modules\DynamicRules;

use Aepro\Classes\AtomicElementAttributes;
use Elementor\Modules\AtomicWidgets\Controls\Section;
use Elementor\Modules\AtomicWidgets\Controls\Types\Select_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Switch_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Text_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Textarea_Control;
use Elementor\Modules\AtomicWidgets\DynamicTags\Dynamic_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropDependencies\Manager as Dependency_Manager;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\Boolean_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\String_Prop_Type;
use Elementor\Modules\Components\PropTypes\Overridable_Prop_Type;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Dynamic Rules (conditional visibility) for Elementor 4 (atomic) elements:
 * v4 Div Block / Flexbox / Grid and v4 widgets.
 *
 * The v4 "Dynamic Rules" settings section has v3's fields under v3's setting
 * names: Enable, Preset Rules, Match (any / all), When rules match (show /
 * hide), the Rules list, Render HTML, Fallback and Rule Filter. The Rules list
 * is a custom panel control (AtomicRulesControl) that edits the same rows as
 * v3's Rules repeater, kept as JSON; at render the rows go to v3's own rule
 * checks (Module::is_element_visible), so every rule type behaves exactly as
 * on classic elements. Like v3, rules are not applied in the editor.
 */
class AtomicDynamicRules {

	const CONTAINER_TYPES = [ 'e-div-block', 'e-flexbox', 'e-grid' ];

	const RULES_DEFAULT = '[{"_id":"aepdef1","ae_rule_type":"validation","ae_rule_validation_operator":"equal","ae_rule_validation_value":"logged_in"}]';

	private static $_instance = null;

	/** @var array<string,bool> Hidden element ID => whether its HTML is still rendered. */
	private $hidden = [];

	/** @var array<string,array>|null v3 rule fields keyed by setting name. */
	private $fields = null;

	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	public static function is_supported() {
		return class_exists( Section::class ) && class_exists( Dependency_Manager::class ) && class_exists( Textarea_Control::class );
	}

	private function __construct() {
		add_filter( 'elementor/atomic-widgets/props-schema', [ $this, 'add_props' ] );
		add_filter( 'elementor/atomic-widgets/controls', [ $this, 'add_controls' ], 10, 2 );

		add_action( 'elementor/frontend/before_render', [ $this, 'before_render' ] );
		foreach ( array_merge( self::CONTAINER_TYPES, [ 'widget' ] ) as $type ) {
			add_filter( "elementor/frontend/{$type}/should_render", [ $this, 'should_render' ], 10, 2 );
		}

		// Rule results depend on the visitor and the page, never cache them.
		add_filter( 'elementor/element/is_dynamic_content', [ $this, 'is_dynamic_content' ], 10, 2 );

		AtomicElementAttributes::instance();

		add_action( 'elementor/editor/after_enqueue_scripts', [ $this, 'enqueue_editor_script' ] );
	}

	// ── Settings (props) ─────────────────────────────────────────────────────

	public function add_props( $schema ) {
		$enabled = [ [ 'enable_dynamic_rules', 'eq', true ] ];
		$manual  = [ [ 'enable_dynamic_rules', 'eq', true ], [ 'ae_preset_rule_id', 'eq', '' ] ];

		$props = [
			'enable_dynamic_rules'            => Boolean_Prop_Type::make()->default( false ),
			'ae_preset_rule_id'               => $this->text()
				->set_dependencies( $this->when( $enabled ) ),
			'rule_relation'                   => $this->choice( [ 'any', 'all' ], 'any' )
				->set_dependencies( $this->when( $manual ) ),
			'ae_show_hide_on_rules'           => $this->choice( [ 'yes', '' ], '' )
				->set_dependencies( $this->when( $enabled ) ),
			'ae_dynamic_rules'                => $this->text( self::RULES_DEFAULT )
				->set_dependencies( $this->when( $manual ) ),
			'ae_render_html'                  => Boolean_Prop_Type::make()->default( true )
				->set_dependencies( $this->when( $enabled ) ),
			'ae_rule_fallback'                => $this->choice( array_keys( $this->fallback_options() ), '' )
				->set_dependencies( $this->when( $enabled ) ),
			'ae_rule_fallback_text'           => $this->text()
				->set_dependencies( $this->when( [ [ 'enable_dynamic_rules', 'eq', true ], [ 'ae_rule_fallback', 'eq', 'text' ] ] ) ),
			'ae_rule_fallback_ae_template'    => $this->text()
				->set_dependencies( $this->when( [ [ 'enable_dynamic_rules', 'eq', true ], [ 'ae_rule_fallback', 'eq', 'ae_template' ] ] ) ),
			'ae_rule_fallback_saved_sections' => $this->text()
				->set_dependencies( $this->when( [ [ 'enable_dynamic_rules', 'eq', true ], [ 'ae_rule_fallback', 'eq', 'saved_section' ] ] ) ),
			'ae_rule_check_filter'            => $this->text()
				->set_dependencies( $this->when( $manual ) ),
		];

		// Keep them out of Elementor 4 Components' overridable properties.
		$ignore = class_exists( Overridable_Prop_Type::class ) ? Overridable_Prop_Type::ignore() : null;

		foreach ( $props as $key => $prop ) {
			$schema[ $key ] = $ignore ? $prop->meta( $ignore ) : $prop;
		}

		return $schema;
	}

	// ── Controls ─────────────────────────────────────────────────────────────

	public function add_controls( $controls, $element ) {
		if ( ! is_object( $element ) || ! method_exists( $element, 'get_atomic_settings' ) ) {
			return $controls;
		}

		$preset_options = [ '' => __( '— None (use rules below) —', 'ae-pro' ) ];
		if ( class_exists( '\Aepro\Admin\PresetRules\Registry' ) ) {
			// + keeps the integer post IDs as keys.
			$preset_options += \Aepro\Admin\PresetRules\Registry::instance()->get_presets_for_select();
		}

		$items = [
			Switch_Control::bind_to( 'enable_dynamic_rules' )->set_label( __( 'Enable', 'ae-pro' ) ),
			$this->select( 'ae_preset_rule_id', __( 'Preset Rules', 'ae-pro' ), $preset_options ),
			$this->select(
				'rule_relation',
				__( 'Match', 'ae-pro' ),
				[
					'any' => __( 'Any rule', 'ae-pro' ),
					'all' => __( 'All rules', 'ae-pro' ),
				]
			),
			$this->select(
				'ae_show_hide_on_rules',
				__( 'When Rules Match', 'ae-pro' ),
				[
					'yes' => __( 'Show the element', 'ae-pro' ),
					''    => __( 'Hide the element', 'ae-pro' ),
				]
			),
			AtomicRulesControl::bind_to( 'ae_dynamic_rules' )->set_label( __( 'Rules', 'ae-pro' ) ),
			Switch_Control::bind_to( 'ae_render_html' )->set_label( __( 'Render HTML', 'ae-pro' ) )
				->set_description( __( "On 'Yes', Renders Html but hide using CSS", 'ae-pro' ) ),
			$this->select( 'ae_rule_fallback', __( 'Fallback', 'ae-pro' ), $this->fallback_options() ),
			Textarea_Control::bind_to( 'ae_rule_fallback_text' )->set_label( __( 'Fallback Text', 'ae-pro' ) ),
			$this->select( 'ae_rule_fallback_ae_template', __( 'AE Template', 'ae-pro' ), [ '' => __( 'Select', 'ae-pro' ) ] + (array) Module::get_ae_templates() ),
			$this->select( 'ae_rule_fallback_saved_sections', __( 'Select Section', 'ae-pro' ), [ '' => __( 'Select Section', 'ae-pro' ) ] + Module::instance()->select_elementor_template( 'section' ) ),
			Text_Control::bind_to( 'ae_rule_check_filter' )->set_label( __( 'Rule Filter', 'ae-pro' ) ),
		];

		$controls[] = Section::make()
			->set_label( __( 'Dynamic Rules', 'ae-pro' ) )
			->set_id( 'aep-dynamic-rules' )
			->set_items( $items );

		return $controls;
	}

	// ── Render ───────────────────────────────────────────────────────────────

	public function before_render( $element ) {
		if ( ! method_exists( $element, 'get_atomic_settings' ) ) {
			return;
		}

		$id = $element->get_id();
		unset( $this->hidden[ $id ] );

		try {
			$settings = $element->get_atomic_settings();
		} catch ( \Throwable $e ) {
			return;
		}

		if ( empty( $settings['enable_dynamic_rules'] ) ) {
			return;
		}

		$v3     = $this->to_v3_settings( $settings );
		$module = Module::instance();

		if ( $module->is_element_visible( $id, $v3 ) ) {
			return;
		}

		$this->hidden[ $id ] = 'yes' === $v3['ae_render_html'];

		if ( $this->hidden[ $id ] ) {
			AtomicElementAttributes::instance()->add(
				$id,
				[
					'class' => 'ae-visibility-hidden',
					'style' => 'display:none!important',
				]
			);
		}

		// Like v3, the fallback is printed in place of the hidden element.
		echo $module->get_element_fallback( $v3 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Template / shortcode output, as in v3.
	}

	public function should_render( $should_render, $element ) {
		$id = is_object( $element ) ? $element->get_id() : '';
		if ( isset( $this->hidden[ $id ] ) && ! $this->hidden[ $id ] ) {
			return false;
		}
		return $should_render;
	}

	public function is_dynamic_content( $is_dynamic, $raw_data ) {
		$enabled = $raw_data['settings']['enable_dynamic_rules'] ?? null;
		if ( is_array( $enabled ) && isset( $enabled['$$type'] ) && true === ( $enabled['value'] ?? null ) ) {
			return true;
		}
		return $is_dynamic;
	}

	/**
	 * v4 resolved values → the settings v3's rule code reads.
	 */
	public function to_v3_settings( array $settings ) {
		return [
			'enable_dynamic_rules'            => empty( $settings['enable_dynamic_rules'] ) ? '' : 'yes',
			'ae_preset_rule_id'               => (string) ( $settings['ae_preset_rule_id'] ?? '' ),
			'rule_relation'                   => 'all' === ( $settings['rule_relation'] ?? '' ) ? 'all' : 'any',
			'ae_show_hide_on_rules'           => 'yes' === ( $settings['ae_show_hide_on_rules'] ?? '' ) ? 'yes' : '',
			'ae_dynamic_rules'                => $this->normalize_rows( $settings['ae_dynamic_rules'] ?? self::RULES_DEFAULT ),
			'ae_render_html'                  => array_key_exists( 'ae_render_html', $settings ) && empty( $settings['ae_render_html'] ) ? '' : 'yes',
			'ae_rule_fallback'                => (string) ( $settings['ae_rule_fallback'] ?? '' ),
			'ae_rule_fallback_text'           => (string) ( $settings['ae_rule_fallback_text'] ?? '' ),
			'ae_rule_fallback_ae_template'    => (string) ( $settings['ae_rule_fallback_ae_template'] ?? '' ),
			'ae_rule_fallback_saved_sections' => (string) ( $settings['ae_rule_fallback_saved_sections'] ?? '' ),
			'ae_rule_check_filter'            => (string) ( $settings['ae_rule_check_filter'] ?? '' ),
		];
	}

	/**
	 * The Rules control's JSON → v3 repeater rows: every field present (with
	 * v3's defaults, as Elementor fills them for classic rows), multi-value
	 * fields as arrays, everything else as strings.
	 *
	 * @param string|array $json
	 * @return array[]
	 */
	public function normalize_rows( $json ) {
		$rows = is_array( $json ) ? $json : json_decode( (string) $json, true );
		if ( ! is_array( $rows ) ) {
			return [];
		}

		$fields = $this->get_fields();
		$result = [];

		foreach ( array_values( $rows ) as $index => $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}

			$clean = [
				'_id' => isset( $row['_id'] ) && is_scalar( $row['_id'] ) ? preg_replace( '/[^A-Za-z0-9_-]/', '', (string) $row['_id'] ) : '',
			];
			if ( '' === $clean['_id'] ) {
				$clean['_id'] = 'aep' . $index;
			}

			foreach ( $fields as $name => $field ) {
				$value = array_key_exists( $name, $row ) ? $row[ $name ] : ( $field['default'] ?? '' );

				if ( ! empty( $field['multiple'] ) ) {
					$value = array_values( array_map( 'strval', array_filter( (array) $value, 'is_scalar' ) ) );
					$value = array_values( array_filter( $value, 'strlen' ) );
				} else {
					$value = is_scalar( $value ) ? (string) $value : '';
				}

				$clean[ $name ] = $value;
			}

			$result[] = $clean;
		}

		return $result;
	}

	// ── Editor ───────────────────────────────────────────────────────────────

	public function enqueue_editor_script() {
		$deps = [ 'jquery' ];
		foreach ( [ 'react', 'elementor-v2-ui', 'elementor-v2-icons', 'elementor-v2-editor-props', 'elementor-v2-editor-controls', 'elementor-v2-editor-editing-panel' ] as $handle ) {
			if ( wp_script_is( $handle, 'registered' ) ) {
				$deps[] = $handle;
			}
		}

		wp_enqueue_script(
			'aep-atomic-dynamic-rules-editor',
			AE_PRO_URL . 'pro/modules/dynamic-rules/assets/js/atomic-dynamic-rules-editor.js',
			$deps,
			AE_PRO_VERSION,
			true
		);

		wp_localize_script(
			'aep-atomic-dynamic-rules-editor',
			'aepAtomicDynamicRules',
			[
				'fields'   => $this->get_editor_fields(),
				'defaults' => json_decode( self::RULES_DEFAULT, true ),
				'i18n'     => [
					'addRule'     => __( 'Add Rule', 'ae-pro' ),
					'rule'        => __( 'Rule', 'ae-pro' ),
					'duplicate'   => __( 'Duplicate', 'ae-pro' ),
					'remove'      => __( 'Remove', 'ae-pro' ),
					'select'      => __( 'Select', 'ae-pro' ),
					'search'      => __( 'Type to search', 'ae-pro' ),
					'noRules'     => __( 'No rules yet.', 'ae-pro' ),
					'noOptions'   => __( 'No options', 'ae-pro' ),
					'pickParent'  => __( 'Choose the parent field first', 'ae-pro' ),
					'loading'     => __( 'Loading…', 'ae-pro' ),
				],
			]
		);
	}

	/**
	 * v3's per-rule fields in a plain shape for the editor control:
	 * name, label, type (select / multiselect / text / textarea / date /
	 * datetime / time / query), options or groups, default, v3 condition,
	 * multiple, and for AJAX pickers the query settings v3 sends.
	 */
	public function get_editor_fields() {
		$fields = [];

		foreach ( $this->get_fields() as $name => $control ) {
			$field = [
				'name'      => $name,
				'label'     => (string) ( $control['label'] ?? $name ),
				'type'      => $this->field_type( $control ),
				'default'   => $control['default'] ?? '',
				'condition' => isset( $control['condition'] ) && is_array( $control['condition'] ) ? $control['condition'] : (object) [],
				'multiple'  => ! empty( $control['multiple'] ),
			];

			if ( ! empty( $control['description'] ) ) {
				$field['description'] = wp_strip_all_tags( (string) $control['description'] );
			}

			if ( isset( $control['groups'] ) && is_array( $control['groups'] ) ) {
				$field['groups'] = $this->normalize_groups( $control['groups'] );
			} elseif ( isset( $control['options'] ) && is_array( $control['options'] ) ) {
				$field['options'] = $this->normalize_options( $control['options'] );
			}

			if ( 'aep-query' === ( $control['type'] ?? '' ) ) {
				$field['query'] = [
					'type'           => (string) ( $control['query_type'] ?? '' ),
					'objectType'     => (string) ( $control['object_type'] ?? '' ),
					'parentField'    => (string) ( $control['parent_field'] ?? '' ),
					'supportedField' => (string) ( $control['supported_field'] ?? '' ),
				];
			}

			$fields[] = $field;
		}

		return $fields;
	}

	private function get_fields() {
		if ( null === $this->fields ) {
			$this->fields = Module::instance()->get_rule_fields();
		}
		return $this->fields;
	}

	private function field_type( array $control ) {
		switch ( $control['type'] ?? '' ) {
			case 'select':
				return 'select';
			case 'select2':
				return empty( $control['multiple'] ) ? 'select' : 'multiselect';
			case 'textarea':
				return 'textarea';
			case 'aep-query':
				return 'query';
			case 'date_time':
				$picker = (array) ( $control['picker_options'] ?? [] );
				if ( ! empty( $picker['noCalendar'] ) ) {
					return 'time';
				}
				return empty( $picker['enableTime'] ) ? 'date' : 'datetime';
			default:
				return 'text';
		}
	}

	/** [ value => label ] → [ [ 'value', 'label' ] ], without v3's " -- " separators. */
	private function normalize_options( array $options ) {
		$result = [];
		foreach ( $options as $value => $label ) {
			if ( '-1' === (string) $value || is_array( $label ) ) {
				continue;
			}
			$result[] = [
				'value' => (string) $value,
				'label' => wp_strip_all_tags( (string) $label ),
			];
		}
		return $result;
	}

	private function normalize_groups( array $groups ) {
		$result = [];
		foreach ( $groups as $group ) {
			if ( ! is_array( $group ) ) {
				continue;
			}
			$options = $this->normalize_options( (array) ( $group['options'] ?? [] ) );
			if ( $options ) {
				$result[] = [
					'label'   => wp_strip_all_tags( (string) ( $group['label'] ?? '' ) ),
					'options' => $options,
				];
			}
		}
		return $result;
	}

	// ── Helpers ──────────────────────────────────────────────────────────────

	private function fallback_options() {
		return [
			''              => __( 'Select', 'ae-pro' ),
			'text'          => __( 'Text', 'ae-pro' ),
			'ae_template'   => __( 'AE Template', 'ae-pro' ),
			'saved_section' => __( 'Saved Section', 'ae-pro' ),
		];
	}

	/**
	 * @param array[] $terms [ setting, operator, value ] — all must match.
	 */
	private function when( array $terms ) {
		$manager = Dependency_Manager::make( Dependency_Manager::RELATION_AND );
		foreach ( $terms as list( $path, $operator, $value ) ) {
			$manager->where(
				[
					'operator' => $operator,
					'path'     => [ $path ],
					'value'    => $value,
					'effect'   => 'hide',
				]
			);
		}
		return $manager->get();
	}

	/** A plain text setting, without Elementor 4's automatic dynamic-tag option. */
	private function text( $default = '' ) {
		return String_Prop_Type::make()->default( $default )->meta( Dynamic_Prop_Type::META_KEY, false );
	}

	private function choice( array $values, $default ) {
		return String_Prop_Type::make()->enum( array_map( 'strval', $values ) )->default( (string) $default );
	}

	private function select( $bind, $label, array $options ) {
		$select = [];
		foreach ( $options as $value => $option_label ) {
			$select[] = [
				'value' => (string) $value,
				'label' => wp_strip_all_tags( (string) $option_label ),
			];
		}

		return Select_Control::bind_to( $bind )->set_options( $select )->set_label( $label );
	}
}
