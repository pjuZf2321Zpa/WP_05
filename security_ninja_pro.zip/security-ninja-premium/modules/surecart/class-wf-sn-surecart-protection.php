<?php
/**
 * SureCart store protection (rate limits, coupons, country-on-login, 2FA gate).
 *
 * Reuses Cloud Firewall woo_* options so WooCommerce and SureCart share one toggle set.
 * Premium-only file (listed in @fs_premium_only).
 *
 * @package Security_Ninja
 */

namespace WPSecurityNinja\Plugin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Wf_Sn_Surecart_Protection
 */
class Wf_Sn_Surecart_Protection {

	/**
	 * Register hooks when SureCart is active and relevant toggles are on.
	 *
	 * @return void
	 */
	public static function init() {
		if ( ! defined( 'SURECART_PLUGIN_FILE' ) ) {
			return;
		}

		$options = Wf_sn_cf::get_options();

		$need_auth = ( Wf_sn_cf::is_active() && ! empty( $options['countryblock_loginonly'] ) )
			|| ! empty( $options['2fa_enabled'] );

		if ( $need_auth ) {
			add_filter( 'authenticate', array( __CLASS__, 'intercept_authenticate' ), 35, 3 );
		}

		if ( self::is_rate_limiting_enabled() || self::is_coupon_protection_enabled() ) {
			add_filter( 'rest_pre_dispatch', array( __CLASS__, 'rest_pre_dispatch' ), 10, 3 );
		}
	}

	/**
	 * Whether shared store rate limiting is enabled.
	 *
	 * @return bool
	 */
	private static function is_rate_limiting_enabled() {
		$firewall_options = Wf_sn_cf::get_options();
		return Wf_sn_cf::is_active() && ! empty( $firewall_options['woo_rate_limiting_enabled'] );
	}

	/**
	 * Whether shared coupon protection is enabled.
	 *
	 * @return bool
	 */
	private static function is_coupon_protection_enabled() {
		$firewall_options = Wf_sn_cf::get_options();
		return Wf_sn_cf::is_active() && ! empty( $firewall_options['woo_coupon_protection_enabled'] );
	}

	/**
	 * Country block + WordPress-native 2FA gate for SureCart REST login.
	 *
	 * Does not render 2FA HTML. Returns WP_Error so the customer must use wp-login.
	 *
	 * @param null|\WP_User|\WP_Error $user     Auth result so far.
	 * @param string                  $username Username.
	 * @param string                  $password Password.
	 * @return null|\WP_User|\WP_Error
	 */
	public static function intercept_authenticate( $user, $username, $password ) {
		if ( is_wp_error( $user ) || empty( $username ) || empty( $password ) ) {
			return $user;
		}

		if ( ! self::is_surecart_login_request() ) {
			return $user;
		}

		$options = Wf_sn_cf::get_options();
		$user_ip = Wf_sn_cf::get_user_ip();

		if ( Wf_sn_cf::is_active() && ! empty( $options['countryblock_loginonly'] ) && $user_ip ) {
			$blocked_country = false;
			if ( secnin_fs()->can_use_premium_code__premium_only() ) {
				$blocked_country = Wf_sn_cf::is_banned_country__premium_only( $user_ip );
			}
			if ( $blocked_country ) {
				if ( class_exists( '\WPSecurityNinja\Plugin\wf_sn_el_modules', false ) ) {
					\WPSecurityNinja\Plugin\wf_sn_el_modules::log_event(
						'security_ninja',
						'surecart_login_blocked',
						'Blocked SureCart login attempt from restricted country',
						array(
							'ip'       => $user_ip,
							'country'  => $blocked_country,
							'username' => $username,
						)
					);
				}
				return new \WP_Error(
					'country_restricted_login',
					esc_html__( 'Login is not allowed from your country.', 'security-ninja' )
				);
			}
		}

		if ( ! ( $user instanceof \WP_User ) ) {
			return $user;
		}

		if ( ! empty( $options['2fa_enabled'] ) && class_exists( __NAMESPACE__ . '\\Wf_Sn_2fa', false ) ) {
			if ( Wf_Sn_2fa::user_requires_2fa_challenge( $user->ID ) ) {
				$login_url = wp_login_url();
				return new \WP_Error(
					'secnin_surecart_2fa_required',
					sprintf(
						/* translators: %s: WordPress login URL */
						esc_html__( 'Two-factor authentication is required. Please sign in at %s first.', 'security-ninja' ),
						esc_url( $login_url )
					)
				);
			}
		}

		return $user;
	}

	/**
	 * Whether the current request is SureCart dashboard REST login.
	 *
	 * @return bool
	 */
	public static function is_surecart_login_request() {
		$uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) $_SERVER['REQUEST_URI'] : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Path detection only.
		$uri_lower = strtolower( $uri );

		if ( false !== strpos( $uri_lower, '/wp-json/surecart/v1/login' )
			|| false !== strpos( $uri_lower, '/surecart/v1/login' ) ) {
			return true;
		}

		$qpos = strpos( $uri, '?' );
		if ( false !== $qpos ) {
			parse_str( (string) substr( $uri, $qpos + 1 ), $qparams );
			if ( isset( $qparams['rest_route'] ) && is_string( $qparams['rest_route'] ) ) {
				$rest = strtolower( $qparams['rest_route'] );
				if ( false !== strpos( $rest, '/surecart/v1/login' ) || false !== strpos( $rest, 'surecart/v1/login' ) ) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * REST pre-dispatch: rate limits and coupon brute-force for SureCart routes.
	 *
	 * @param mixed            $result  Response to replace the request (null to continue).
	 * @param \WP_REST_Server  $server  Server instance.
	 * @param \WP_REST_Request $request Request.
	 * @return mixed
	 */
	public static function rest_pre_dispatch( $result, $server, $request ) {
		if ( null !== $result ) {
			return $result;
		}

		if ( ! ( $request instanceof \WP_REST_Request ) ) {
			return $result;
		}

		$route  = (string) $request->get_route();
		$method = strtoupper( (string) $request->get_method() );

		if ( self::is_rate_limiting_enabled() ) {
			$rate_error = self::maybe_rate_limit_rest( $route, $method );
			if ( is_wp_error( $rate_error ) ) {
				return $rate_error;
			}
		}

		if ( self::is_coupon_protection_enabled() && self::route_is_checkout_mutation( $route, $method ) ) {
			if ( self::request_has_discount_payload( $request ) ) {
				$coupon_error = self::check_coupon_brute_force_rest();
				if ( is_wp_error( $coupon_error ) ) {
					return $coupon_error;
				}
			}
		}

		return $result;
	}

	/**
	 * Apply shared woo_* rate limits to SureCart REST routes.
	 *
	 * @param string $route  REST route.
	 * @param string $method HTTP method.
	 * @return true|\WP_Error
	 */
	private static function maybe_rate_limit_rest( $route, $method ) {
		if ( self::route_is_line_items_create( $route, $method ) ) {
			return self::enforce_rate_limit(
				'add_to_cart',
				'woo_add_to_cart_limit',
				'woo_add_to_cart_window',
				'woo_add_to_cart_ban_time',
				10,
				60,
				300,
				__( 'Too many cart attempts. Please wait before trying again.', 'security-ninja' )
			);
		}

		if ( self::route_is_checkout_create( $route, $method ) ) {
			return self::enforce_rate_limit(
				'checkout',
				'woo_checkout_rate_limit',
				'woo_checkout_window',
				'woo_checkout_ban_time',
				3,
				300,
				600,
				__( 'Too many checkout attempts. Please wait before trying again.', 'security-ninja' )
			);
		}

		if ( self::route_is_checkout_finalize( $route, $method ) ) {
			return self::enforce_rate_limit(
				'order',
				'woo_order_rate_limit',
				'woo_order_window',
				'woo_order_ban_time',
				2,
				600,
				900,
				__( 'Too many order attempts. Please wait before trying again.', 'security-ninja' )
			);
		}

		return true;
	}

	/**
	 * Shared transient rate limit (same keys as WooCommerce protection).
	 *
	 * @param string $bucket         Bucket name: checkout|add_to_cart|order.
	 * @param string $limit_key      Options key for limit.
	 * @param string $window_key     Options key for window seconds.
	 * @param string $ban_key        Options key for ban seconds.
	 * @param int    $default_limit  Default limit.
	 * @param int    $default_window Default window.
	 * @param int    $default_ban    Default ban.
	 * @param string $message        Error message.
	 * @return true|\WP_Error
	 */
	private static function enforce_rate_limit( $bucket, $limit_key, $window_key, $ban_key, $default_limit, $default_window, $default_ban, $message ) {
		$ip = Wf_sn_cf::get_user_ip();
		if ( ! $ip ) {
			return true;
		}

		$firewall_options = Wf_sn_cf::get_options();
		$limit            = isset( $firewall_options[ $limit_key ] ) ? (int) $firewall_options[ $limit_key ] : $default_limit;
		$window           = isset( $firewall_options[ $window_key ] ) ? (int) $firewall_options[ $window_key ] : $default_window;
		$ban_time         = isset( $firewall_options[ $ban_key ] ) ? (int) $firewall_options[ $ban_key ] : $default_ban;

		$ban_transient = 'wf_sn_woo_' . $bucket . '_banned_' . md5( $ip );
		if ( get_transient( $ban_transient ) ) {
			return new \WP_Error(
				'secnin_surecart_rate_limited',
				$message,
				array( 'status' => 429 )
			);
		}

		$count_key = 'wf_sn_woo_' . $bucket . '_' . md5( $ip );
		$count     = (int) get_transient( $count_key );

		if ( $count >= $limit ) {
			set_transient( $ban_transient, 1, $ban_time );
			return new \WP_Error(
				'secnin_surecart_rate_limited',
				$message,
				array( 'status' => 429 )
			);
		}

		++$count;
		set_transient( $count_key, $count, $window );

		return true;
	}

	/**
	 * Coupon brute-force using shared woo coupon transients.
	 *
	 * @return true|\WP_Error
	 */
	public static function check_coupon_brute_force_rest() {
		$ip = Wf_sn_cf::get_user_ip();
		if ( ! $ip ) {
			return true;
		}

		$firewall_options = Wf_sn_cf::get_options();

		if ( get_transient( 'wf_sn_woo_coupon_banned_' . md5( $ip ) ) ) {
			return new \WP_Error(
				'secnin_surecart_coupon_banned',
				__( 'Too many coupon attempts. Please wait before trying again.', 'security-ninja' ),
				array( 'status' => 429 )
			);
		}

		$failed_attempts_limit = isset( $firewall_options['woo_coupon_failed_attempts'] ) ? (int) $firewall_options['woo_coupon_failed_attempts'] : 5;
		$window                = isset( $firewall_options['woo_coupon_window'] ) ? (int) $firewall_options['woo_coupon_window'] : 300;
		$ban_time              = isset( $firewall_options['woo_coupon_ban_time'] ) ? (int) $firewall_options['woo_coupon_ban_time'] : 900;

		$transient_key = 'wf_sn_woo_coupon_failed_' . md5( $ip );
		$count         = (int) get_transient( $transient_key );
		++$count;
		set_transient( $transient_key, $count, $window );

		if ( $count >= $failed_attempts_limit ) {
			set_transient( 'wf_sn_woo_coupon_banned_' . md5( $ip ), 1, $ban_time );
			return new \WP_Error(
				'secnin_surecart_coupon_banned',
				__( 'Too many coupon attempts. Please wait before trying again.', 'security-ninja' ),
				array( 'status' => 429 )
			);
		}

		return true;
	}

	/**
	 * @param string $route  Route.
	 * @param string $method Method.
	 * @return bool
	 */
	private static function route_is_line_items_create( $route, $method ) {
		return 'POST' === $method && (bool) preg_match( '#^/surecart/v1/line_items(?:/|$)#', $route );
	}

	/**
	 * Checkout collection create.
	 *
	 * @param string $route  Route.
	 * @param string $method Method.
	 * @return bool
	 */
	private static function route_is_checkout_create( $route, $method ) {
		return 'POST' === $method && (bool) preg_match( '#^/surecart/v1/checkouts/?$#', $route );
	}

	/**
	 * Checkout finalize / confirm style mutations on a checkout resource.
	 *
	 * @param string $route  Route.
	 * @param string $method Method.
	 * @return bool
	 */
	private static function route_is_checkout_finalize( $route, $method ) {
		if ( ! in_array( $method, array( 'POST', 'PATCH', 'PUT' ), true ) ) {
			return false;
		}
		// Finalize / confirm / complete sub-routes.
		if ( preg_match( '#^/surecart/v1/checkouts/[^/]+/(?:finalize|confirm|complete|pay)(?:/|$)#', $route ) ) {
			return true;
		}
		return false;
	}

	/**
	 * Checkout create or update (coupon apply lives on updates).
	 *
	 * @param string $route  Route.
	 * @param string $method Method.
	 * @return bool
	 */
	private static function route_is_checkout_mutation( $route, $method ) {
		if ( ! in_array( $method, array( 'POST', 'PATCH', 'PUT' ), true ) ) {
			return false;
		}
		return (bool) preg_match( '#^/surecart/v1/checkouts(?:/|$)#', $route );
	}

	/**
	 * Whether the REST body includes a discount / promotion code attempt.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return bool
	 */
	public static function request_has_discount_payload( $request ) {
		$params = $request->get_json_params();
		if ( ! is_array( $params ) || empty( $params ) ) {
			$raw = $request->get_body();
			if ( is_string( $raw ) && '' !== $raw ) {
				$decoded = json_decode( $raw, true );
				$params  = is_array( $decoded ) ? $decoded : array();
			} else {
				$params = array();
			}
		}

		foreach ( array( 'discount', 'promotion_code', 'promotionCode', 'coupon', 'coupon_code' ) as $key ) {
			if ( ! empty( $params[ $key ] ) ) {
				return true;
			}
		}

		if ( isset( $params['discount'] ) && is_array( $params['discount'] ) && ! empty( $params['discount'] ) ) {
			return true;
		}

		return false;
	}
}

add_action( 'init', array( 'WPSecurityNinja\Plugin\Wf_Sn_Surecart_Protection', 'init' ) );
