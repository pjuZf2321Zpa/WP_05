/* globals jQuery:true, wp:true, wf_sn_wl:true */
/**
 * Security Ninja - White label media uploader
 * Handles plugin icon and menu icon selection via WordPress media library.
 *
 * @package Security_Ninja
 */

jQuery(document).ready(function($) {
	var wl = typeof wf_sn_wl !== 'undefined' ? wf_sn_wl : {};

	// Plugin Icon Media Uploader (delegated so it works when tab content is visible)
	$(document).on('click', '#upload_plugin_icon_button', function(e) {
		e.preventDefault();
		var custom_uploader = wp.media({
			title: wl.select_plugin_icon || 'Select Plugin Icon',
			button: {
				text: wl.use_this_image || 'Use this image'
			},
			multiple: false
		});
		custom_uploader.on('select', function() {
			var attachment = custom_uploader.state().get('selection').first().toJSON();
			$('#plugin_icon_url').val(attachment.url);
			$('#plugin_icon_preview').html(
				'<img src="' + attachment.url + '" alt="' + (wl.plugin_icon_alt || 'Plugin Icon') + '" style="max-width: 32px; max-height: 32px;">'
			);
		});
		custom_uploader.open();
	});

	$(document).on('click', '#clear_plugin_icon_button', function(e) {
		e.preventDefault();
		$('#plugin_icon_url').val('');
		$('#plugin_icon_preview').empty();
	});

	// Menu Icon Media Uploader
	$(document).on('click', '#upload_menu_icon_button', function(e) {
		e.preventDefault();
		var custom_uploader = wp.media({
			title: wl.select_menu_icon || 'Select Menu Icon',
			button: {
				text: wl.use_this_image || 'Use this image'
			},
			multiple: false
		});
		custom_uploader.on('select', function() {
			var attachment = custom_uploader.state().get('selection').first().toJSON();
			$('#menu_icon_url').val(attachment.url);
			$('#menu_icon_preview').html(
				'<img src="' + attachment.url + '" alt="' + (wl.menu_icon_alt || 'Menu Icon') + '" style="max-width: 32px; max-height: 32px;">'
			);
		});
		custom_uploader.open();
	});

	$(document).on('click', '#clear_menu_icon_button', function(e) {
		e.preventDefault();
		$('#menu_icon_url').val('');
		$('#menu_icon_preview').empty();
	});
});
