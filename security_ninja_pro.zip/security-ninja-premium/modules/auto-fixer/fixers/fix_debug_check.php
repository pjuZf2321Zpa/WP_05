<?php
namespace WPSecurityNinja\Plugin;

class wf_sn_af_fix_debug_check extends wf_sn_af {
	static function get_label( $label ) {
		$labels = array(
			'title'   => esc_html__( 'Disable debug mode', 'security-ninja' ),
			'fixable' => false,
			'info'    => esc_html__( 'Go to the Fixes page to enable or disable.', 'security-ninja' ),
			'msg_ok'  => esc_html__( 'Fix applied successfully.', 'security-ninja' ),
			'msg_bad' => esc_html__( 'Failed to disable debug mode.', 'security-ninja' ),
		);

		if ( ! array_key_exists( $label, $labels ) ) {
			return '';
		} else {
			return $labels[ $label ];
		}
	}

	static function fix() {
		$backup_timestamp = time();
		if ( ! wf_sn_af::backup_file( wf_sn_af::$wp_config_path, $backup_timestamp, 'debug_check' ) ) {
			return self::get_label( 'msg_bad' );
		}
		wf_sn_af::update_define( wf_sn_af::$wp_config_path, 'WP_DEBUG', false );
		$no_wsod = wf_sn_af::test_wordpress_status();
		if ( ! $no_wsod ) {
			wf_sn_af::backup_file_restore( wf_sn_af::$wp_config_path, $backup_timestamp, 'debug_check' );
			return self::get_label( 'msg_bad' );
		} else {
			return self::get_label( 'msg_ok' );
		}
	}
	/**
	 * Stop enforcing WP_DEBUG=false. Do not force WP_DEBUG to true.
	 *
	 * Turning "Disable debug mode" off must leave wp-config.php alone.
	 * Forcing true here previously flipped production sites into debug mode
	 * whenever Fixes settings were saved with the toggle off (default).
	 *
	 * @since 5.301
	 * @return string
	 */
	static function remove_fix() {
		return self::get_label( 'msg_ok' );
	}
}
