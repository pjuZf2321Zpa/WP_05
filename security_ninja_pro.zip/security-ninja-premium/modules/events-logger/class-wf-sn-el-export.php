<?php
/**
 * Events Logger CSV export (Pro only).
 *
 * Loaded only when Freemius premium code is available. Listed in @fs_premium_only
 * so this file is stripped from the WordPress.org free build.
 *
 * @package Security_Ninja
 */

namespace WPSecurityNinja\Plugin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Streams the Events Logger table as a CSV download for administrators.
 */
class Wf_Sn_El_Export {

	/**
	 * admin-post action name.
	 *
	 * @var string
	 */
	const ACTION = 'sn_el_export_csv';

	/**
	 * Nonce action.
	 *
	 * @var string
	 */
	const NONCE_ACTION = 'sn_el_export_csv';

	/**
	 * Rows per SELECT chunk.
	 *
	 * @var int
	 */
	const CHUNK_SIZE = 500;

	/**
	 * Transient TTL to throttle double-clicks (seconds).
	 *
	 * @var int
	 */
	const THROTTLE_SECONDS = 10;

	/**
	 * Register the admin-post handler.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'admin_post_' . self::ACTION, array( __CLASS__, 'handle_export' ) );
	}

	/**
	 * Build a nonce-protected download URL for the Events tab button.
	 *
	 * @return string
	 */
	public static function get_export_url() {
		return wp_nonce_url(
			admin_url( 'admin-post.php?action=' . self::ACTION ),
			self::NONCE_ACTION
		);
	}

	/**
	 * Stream the full events table as CSV.
	 *
	 * @return void
	 */
	public static function handle_export() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have sufficient permissions.', 'security-ninja' ), 403 );
		}

		if ( ! isset( $_GET['_wpnonce'] ) || ! wp_verify_nonce( sanitize_key( wp_unslash( $_GET['_wpnonce'] ) ), self::NONCE_ACTION ) ) {
			wp_die( esc_html__( 'Security check failed.', 'security-ninja' ), 403 );
		}

		// Runtime license gate: premium ZIP without a valid license must not export.
		// Do not use else / negation on can_use_premium_code__premium_only() (Freemius parser).
		$can_export = false;
		if ( secnin_fs()->can_use_premium_code__premium_only() ) {
			$can_export = true;
		}
		if ( ! $can_export ) {
			wp_die( esc_html__( 'This feature requires an active Security Ninja Pro license.', 'security-ninja' ), 403 );
		}

		$user_id       = get_current_user_id();
		$throttle_key  = 'sn_el_export_' . $user_id;
		if ( get_transient( $throttle_key ) ) {
			wp_die( esc_html__( 'Please wait a few seconds before exporting again.', 'security-ninja' ), 429 );
		}
		set_transient( $throttle_key, 1, self::THROTTLE_SECONDS );

		// Large tables: keep the request alive while streaming chunks.
		if ( function_exists( 'wp_raise_memory_limit' ) ) {
			wp_raise_memory_limit( 'admin' );
		}
		if ( function_exists( 'set_time_limit' ) ) {
			// phpcs:ignore Squiz.PHP.DiscouragedFunctions.Discouraged -- Intentional for long CSV streams.
			@set_time_limit( 300 );
		}
		ignore_user_abort( true );

		self::stream_csv();

		if ( class_exists( __NAMESPACE__ . '\\wf_sn_el_modules' ) ) {
			wf_sn_el_modules::log_event(
				'security_ninja',
				'events_log_exported',
				__( 'Events log exported as CSV by administrator.', 'security-ninja' ),
				array( 'user_id' => $user_id )
			);
		}

		exit;
	}

	/**
	 * Output CSV headers and stream rows in chunks.
	 *
	 * @return void
	 */
	private static function stream_csv() {
		global $wpdb;

		while ( ob_get_level() > 0 ) {
			ob_end_clean();
		}

		// Keep notices/deprecations out of the download body when WP_DEBUG_DISPLAY is on.
		// phpcs:ignore WordPress.PHP.IniSet.display_errors_Disallowed -- Intentional for binary CSV stream.
		@ini_set( 'display_errors', '0' );

		nocache_headers();

		$filename = 'security-ninja-events-' . gmdate( 'Y-m-d' ) . '.csv';

		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
		header( 'X-Content-Type-Options: nosniff' );
		header( 'Pragma: no-cache' );
		header( 'Expires: 0' );

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- Streaming to php://output.
		$out = fopen( 'php://output', 'w' );
		if ( false === $out ) {
			wp_die( esc_html__( 'Unable to start CSV download.', 'security-ninja' ) );
		}

		// UTF-8 BOM for Excel.
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Binary BOM for CSV clients.
		fwrite( $out, "\xEF\xBB\xBF" );

		// Empty $escape (RFC 4180): JSON details contain many backslashes; a "\\" escape
		// corrupts quoting so Excel/Numbers see the whole file as one row. Explicit 5th
		// arg also avoids PHP 8.4+ fputcsv() deprecation notices in the download body.
		fputcsv( $out, self::get_csv_headers(), ',', '"', '' );

		$table     = $wpdb->prefix . 'wf_sn_el';
		$last_id   = 0;
		$usernames = array();

		while ( true ) {
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name uses trusted $wpdb->prefix.
			$rows = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT id, timestamp, ip, user_agent, user_id, module, action, description, raw_data FROM {$table} WHERE id > %d ORDER BY id ASC LIMIT %d",
					$last_id,
					self::CHUNK_SIZE
				)
			);
			if ( empty( $rows ) ) {
				break;
			}
			foreach ( $rows as $row ) {
				$last_id = (int) $row->id;
				fputcsv( $out, self::format_row( $row, $usernames ), ',', '"', '' );
			}
			if ( function_exists( 'fflush' ) ) {
				fflush( $out );
			}
			if ( count( $rows ) < self::CHUNK_SIZE ) {
				break;
			}
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
		fclose( $out );
	}

	/**
	 * CSV column headers.
	 *
	 * @return array<int, string>
	 */
	public static function get_csv_headers() {
		return array(
			'timestamp',
			'module',
			'action',
			'description',
			'user_id',
			'username',
			'ip',
			'user_agent',
			'details',
		);
	}

	/**
	 * Format one DB row as a CSV field array.
	 *
	 * @param object              $row       Database row.
	 * @param array<int, string>  $usernames Username cache keyed by user ID (passed by ref).
	 * @return array<int, string>
	 */
	public static function format_row( $row, array &$usernames = array() ) {
		$user_id  = isset( $row->user_id ) ? (int) $row->user_id : 0;
		$username = '';

		if ( $user_id > 0 ) {
			if ( ! isset( $usernames[ $user_id ] ) ) {
				$user = get_userdata( $user_id );
				$usernames[ $user_id ] = ( $user instanceof \WP_User ) ? $user->user_login : '';
			}
			$username = $usernames[ $user_id ];
		}

		$raw = maybe_unserialize( isset( $row->raw_data ) ? $row->raw_data : '' );
		if ( is_wp_error( $raw ) ) {
			$details = wp_json_encode( array( 'error' => $raw->get_error_message() ) );
		} elseif ( is_object( $raw ) ) {
			$details = wp_json_encode( array( 'class' => get_class( $raw ) ) );
		} elseif ( null === $raw || '' === $raw ) {
			$details = '';
		} else {
			$encoded = wp_json_encode( $raw );
			$details = ( false === $encoded ) ? '' : $encoded;
		}

		return array(
			self::escape_csv_cell( (string) ( $row->timestamp ?? '' ) ),
			self::escape_csv_cell( (string) ( $row->module ?? '' ) ),
			self::escape_csv_cell( (string) ( $row->action ?? '' ) ),
			self::escape_csv_cell( (string) ( $row->description ?? '' ) ),
			self::escape_csv_cell( (string) $user_id ),
			self::escape_csv_cell( $username ),
			self::escape_csv_cell( (string) ( $row->ip ?? '' ) ),
			self::escape_csv_cell( (string) ( $row->user_agent ?? '' ) ),
			self::escape_csv_cell( (string) $details ),
		);
	}

	/**
	 * Prefix formula-like cells so spreadsheet apps do not execute them.
	 *
	 * @param string $value Cell value.
	 * @return string
	 */
	public static function escape_csv_cell( $value ) {
		$value = (string) $value;
		// Keep one physical line per event so simple viewers and Excel do not merge rows.
		$value = str_replace( array( "\r\n", "\r", "\n" ), ' ', $value );
		if ( $value === '' ) {
			return $value;
		}
		$first = $value[0];
		if ( '=' === $first || '+' === $first || '-' === $first || '@' === $first || "\t" === $first ) {
			return "'" . $value;
		}
		return $value;
	}
}
