/* global two_factor_auth, jQuery */

function leave2faScreen(response) {
    var verifyTarget = (response && response.data && response.data.redir_to) || (typeof two_factor_auth !== 'undefined' && two_factor_auth.fallback_admin_url);
    if (verifyTarget) {
        window.location.href = verifyTarget;
    } else {
        window.location.reload();
    }
}

function showBackupCodes(codes, onContinue) {
    var msgs = (typeof two_factor_auth !== 'undefined' && two_factor_auth.messages) ? two_factor_auth.messages : {};
    var list = '';
    jQuery.each(codes, function (_, code) {
        list += '<li><code>' + jQuery('<div>').text(code).html() + '</code></li>';
    });
    var html = '<div class="sn-2fa-backup-once">' +
        '<p><strong>' + (msgs.backup_title || 'Save these backup codes') + '</strong></p>' +
        '<p>' + (msgs.backup_help || 'Each code works once. This is the only time they are shown.') + '</p>' +
        '<ul>' + list + '</ul>' +
        '<p class="sn-2fa-remember"><label for="sn-2fa-backup-saved"><input type="checkbox" id="sn-2fa-backup-saved" /> ' +
        (msgs.backup_saved || 'I have saved these codes') + '</label></p>' +
        '<p class="submit"><button type="button" class="button button-primary button-large" id="sn-2fa-backup-continue" disabled>' +
        (msgs.backup_continue || 'Continue') + '</button></p>' +
        '</div>';
    jQuery('#twofa-form-verify, .qr-code, .email-2fa, .sn-2fa-method-switcher').hide();
    jQuery('#login').append(html);
    jQuery('#sn-2fa-backup-saved').on('change', function () {
        jQuery('#sn-2fa-backup-continue').prop('disabled', !this.checked);
    });
    jQuery('#sn-2fa-backup-continue').on('click', function () {
        if (jQuery('#sn-2fa-backup-saved').is(':checked')) {
            onContinue();
        }
    });
}

// Helper function to restore UI state in case of errors
function restoreUIState() {
    jQuery('#verify-2fa').prop('disabled', false);
    jQuery('#twofa-code').prop('disabled', false);
    jQuery('#generate-qr').prop('disabled', false);
    jQuery('#send-email').prop('disabled', false);
    jQuery('.qr-code .spinner').removeClass('is-active');
}

// Debounce function to prevent rapid clicks
function debounce(func, wait) {
    var timeout;
    return function executedFunction() {
        var later = function() {
            clearTimeout(timeout);
            func.apply(this, arguments);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Create debounced versions of functions
var debouncedSendEmail = debounce(sendEmailCode, 1000);
var debouncedGenerateQR = debounce(generateQRCode, 1000);

/**
 * Generates a new QR code with enhanced error handling.
 */
function generateQRCode() {
    try {
        // Check if two_factor_auth object is available
        if (typeof two_factor_auth === 'undefined' || !two_factor_auth.ajaxurl || !two_factor_auth.temp_token) {
            return;
        }
        
        // Use safe element checking
        var $generateBtn = jQuery('#generate-qr');
        var $spinner = jQuery('.qr-code .spinner');
        var $errorContainer = jQuery('#qr-code-img-err');
        
        if (!$generateBtn.length || !$spinner.length || !$errorContainer.length) {
            return;
        }
        
        $generateBtn.prop('disabled', true);
        $spinner.addClass('is-active');
        
        // Clear any previous errors
        $errorContainer.empty();

        jQuery.ajax({
            url: two_factor_auth.ajaxurl,
            type: 'POST',
            data: {
                action: 'secnin_generate_qr_code',
                temp_token: two_factor_auth.temp_token
            },
            timeout: 30000, // 30 second timeout
            success: function (response) {
                try {
                    $generateBtn.prop('disabled', false);
                    $spinner.removeClass('is-active');
                    
                    if (response && response.success && response.data && response.data.qr_code) {
                        $errorContainer.empty();
                        // The QR code is already base64 encoded, use it directly
                        var $qrImg = jQuery('#qr-code-img');
                        if ($qrImg.length) {
                            $qrImg.attr('src', response.data.qr_code);
                        }
                        
                        // Show and populate the secret key if available
                        if (response.data.secret) {
                            var $secretKey = jQuery('#secret-key');
                            var $secretContainer = jQuery('#secret-container');
                            if ($secretKey.length) {
                                $secretKey.val(response.data.secret);
                            }
                            if ($secretContainer.length) {
                                $secretContainer.show();
                            }
                        }
                    } else {
                        var errorMsg = (response && response.data && response.data.message) ? 
                            response.data.message : 
                            (two_factor_auth.messages && two_factor_auth.messages.qr_error) ? 
                            two_factor_auth.messages.qr_error : 
                            'Error generating QR code. Please try again.';
                        $errorContainer.html('<p class="errmsg">' + errorMsg + '</p>');
                    }
                } catch (e) {
                    $errorContainer.html('<p class="errmsg">Error processing response. Please try again.</p>');
                }
            },
            error: function (xhr, status, error) {
                $generateBtn.prop('disabled', false);
                $spinner.removeClass('is-active');
                var errorMsg = (two_factor_auth.messages && two_factor_auth.messages.network_error) ? 
                    two_factor_auth.messages.network_error : 
                    'Network error. Please check your connection and try again.';
                $errorContainer.html('<p class="errmsg">' + errorMsg + '</p>');
            }
        });
    } catch (e) {
        $errorContainer = jQuery('#qr-code-img-err');
        if ($errorContainer.length) {
            $errorContainer.html('<p class="errmsg">Error generating QR code. Please refresh the page.</p>');
        }
    }
}

/**
 * Sends a new 2FA email code with enhanced error handling.
 */
function sendEmailCode() {
    try {
        // Check if two_factor_auth object is available
        if (typeof two_factor_auth === 'undefined' || !two_factor_auth.ajaxurl || !two_factor_auth.temp_token) {
            return;
        }
        
        // Check if required elements exist
        var $sendBtn = jQuery('#send-email');
        var $status = jQuery('#email-status');
        
        if (!$sendBtn.length || !$status.length) {
            return;
        }
        
        // Check if button is already disabled (prevent rapid clicking)
        if ($sendBtn.prop('disabled')) {
            return;
        }
        
        $sendBtn.prop('disabled', true);
        var sendingMsg = (two_factor_auth.messages && two_factor_auth.messages.sending_email) ? 
            two_factor_auth.messages.sending_email : 
            'Sending email...';
        $status.html('<p class="okmsg">' + sendingMsg + '</p>');

        jQuery.ajax({
            url: two_factor_auth.ajaxurl,
            type: 'POST',
            data: {
                action: 'secnin_send_2fa_email',
                temp_token: two_factor_auth.temp_token
            },
            timeout: 30000, // 30 second timeout
            success: function (response) {
                try {
                    $sendBtn.prop('disabled', false);
                    
                    if (response && response.success) {
                        var successMsg = (response.data && response.data.message) ? 
                            response.data.message : 
                            'Email sent successfully.';
                        $status.html('<p class="okmsg">' + successMsg + '</p>');
                        // Mark that an email has been sent to prevent auto-sending
                        window.sn2faEmailSent = true;
                    } else {
                        var errorMsg = (response && response.data && response.data.message) ? 
                            response.data.message : 
                            (two_factor_auth.messages && two_factor_auth.messages.email_error) ? 
                            two_factor_auth.messages.email_error : 
                            'Error sending email. Please try again.';
                        $status.html('<p class="errmsg">' + errorMsg + '</p>');
                    }
                } catch (e) {
                    $status.html('<p class="errmsg">Error processing response. Please try again.</p>');
                }
            },
            error: function (xhr, status, error) {
                $sendBtn.prop('disabled', false);
                var errorMsg = (two_factor_auth.messages && two_factor_auth.messages.network_error) ? 
                    two_factor_auth.messages.network_error : 
                    'Network error. Please check your connection and try again.';
                $status.html('<p class="errmsg">' + errorMsg + '</p>');
            }
        });
    } catch (e) {
        $status = jQuery('#email-status');
        if ($status.length) {
            $status.html('<p class="errmsg">Error sending email. Please refresh the page.</p>');
        }
    }
}

// Consolidated initialization system to prevent duplicate event handlers
(function() {
    'use strict';

    if (window.sn2faInitialized) {
        return;
    }

    function getSelectedMethod() {
        if (typeof two_factor_auth === 'undefined') {
            return 'app';
        }
        if (two_factor_auth.selected_method) {
            return two_factor_auth.selected_method;
        }
        if (two_factor_auth.allowed_methods && two_factor_auth.allowed_methods.length) {
            return two_factor_auth.allowed_methods[0];
        }
        return 'app';
    }

    window.sn2faGetSelectedMethod = getSelectedMethod;

    function setSelectedMethod(method) {
        if (typeof two_factor_auth !== 'undefined') {
            two_factor_auth.selected_method = method;
        }
    }

    function updateMethodPanels(method) {
        var $appPanel = jQuery('#sn-2fa-app-panel');
        var $emailPanel = jQuery('#sn-2fa-email-panel');
        var $label = jQuery('#twofa-code-label');

        jQuery('.sn-2fa-method-btn').removeClass('is-active');
        jQuery('.sn-2fa-method-btn[data-method="' + method + '"]').addClass('is-active');

        if ($appPanel.length) {
            $appPanel.toggle(method === 'app');
        }
        if ($emailPanel.length) {
            $emailPanel.toggle(method === 'email');
        }
        if ($label.length && typeof two_factor_auth !== 'undefined' && two_factor_auth.messages) {
            $label.text(method === 'email' ? two_factor_auth.messages.code_label_email : two_factor_auth.messages.code_label_app);
        }

        if (method === 'email' && $emailPanel.length && !window.sn2faEmailSent) {
            sendEmailCode();
        }
        if (method === 'app' && $appPanel.length && !two_factor_auth.has_app_secret) {
            generateQRCode();
        }
    }

    window.sn2faSetMethod = function(method) {
        setSelectedMethod(method);
        updateMethodPanels(method);
    };

    function attachEventHandlers() {
        try {
            var $form = jQuery('#twofa-form-verify');
            var $input = jQuery('#twofa-code');
            var $button = jQuery('#verify-2fa');

            // Input validation handler
            $input.on('input', function () {
                var inputValue = jQuery(this).val();
                var useBackup = jQuery('#twofa-code').data('backup') === 1;

                if (useBackup) {
                    inputValue = inputValue.toUpperCase().replace(/[^A-Z0-9-]/g, '').slice(0, 11);
                    jQuery(this).val(inputValue);
                    $button.prop('disabled', inputValue.replace(/[^A-Z0-9]/g, '').length !== 10);
                    return;
                }

                // Remove any non-digit characters
                inputValue = inputValue.replace(/\D/g, '');

                // Limit to 6 digits
                inputValue = inputValue.slice(0, 6);

                // Update input value
                jQuery(this).val(inputValue);

                // Enable/disable submit button based on input validity
                $button.prop('disabled', inputValue.length !== 6);
            });

            jQuery('#sn-2fa-use-backup').on('click', function (e) {
                e.preventDefault();
                var using = jQuery('#twofa-code').data('backup') === 1;
                using = !using;
                jQuery('#twofa-code').data('backup', using ? 1 : 0);
                if (using) {
                    $input.attr({ maxlength: 11, inputmode: 'text', autocomplete: 'off', pattern: '[A-Za-z0-9-]{10,11}' });
                    jQuery('#twofa-code-label').text('Enter one of your backup codes.');
                    jQuery(this).text('Use an authenticator or email code');
                } else {
                    $input.attr({ maxlength: 6, inputmode: 'numeric', pattern: '\\d{6}' });
                    jQuery('#twofa-code-label').text(
                        (typeof two_factor_auth !== 'undefined' && two_factor_auth.messages)
                            ? (getSelectedMethod() === 'email' ? two_factor_auth.messages.code_label_email : two_factor_auth.messages.code_label_app)
                            : 'Enter the 6-digit code.'
                    );
                    jQuery(this).text('Use a backup code');
                }
                $input.val('').trigger('input');
            });

            // Form submission handler
            $form.on('submit', function (e) {
                e.preventDefault();

                try {
                    var twofacode = $input.val();
                    var $verifyMsg = jQuery('#twofa-verify-msg');
                    var useBackup = $input.data('backup') === 1;

                    // Validate input
                    if (!twofacode || (useBackup ? twofacode.replace(/[^A-Za-z0-9]/g, '').length !== 10 : twofacode.length !== 6)) {
                        if ($verifyMsg.length) {
                            $verifyMsg.html('<p class="errmsg">' + (useBackup ? 'Enter a backup code.' : 'Please enter a valid 6-digit code.') + '</p>');
                        }
                        return;
                    }

                    // Check if two_factor_auth object is available
                    if (typeof two_factor_auth === 'undefined' || !two_factor_auth.ajaxurl) {
                        if ($verifyMsg.length) {
                            $verifyMsg.html('<p class="errmsg">Configuration error. Please refresh the page.</p>');
                        }
                        return;
                    }

                    var verifyingMsg = (two_factor_auth.messages && two_factor_auth.messages.verifying) ?
                        two_factor_auth.messages.verifying :
                        'Checking code...';
                    $verifyMsg.html('<p class="okmsg">' + verifyingMsg + '</p>');

                    $button.prop('disabled', true);
                    $input.prop('disabled', true);

                    jQuery.ajax({
                        url: two_factor_auth.ajaxurl,
                        type: 'POST',
                        data: {
                            action: 'secnin_verify_2fa_code',
                            code: twofacode,
                            nonce: two_factor_auth.verify_nonce || '',
                            remember_device: (jQuery('#twofa-code').data('backup') === 1) ? 0 : (jQuery('#sn-2fa-remember').is(':checked') ? 1 : 0),
                            temp_token: two_factor_auth.temp_token,
                            method: getSelectedMethod()
                        },
                        timeout: 30000, // 30 second timeout
                        success: function (response) {
                            try {
                                if (response && response.success) {
                                    var successMsg = (response.data && response.data.message) ?
                                        response.data.message :
                                        'Code verified successfully.';
                                    $verifyMsg.html('<p class="okmsg">' + successMsg + '</p>');

                                    var codes = response.data && response.data.backup_codes;
                                    if (codes && codes.length) {
                                        showBackupCodes(codes, function () {
                                            leave2faScreen(response);
                                        });
                                    } else {
                                        setTimeout(function () {
                                            leave2faScreen(response);
                                        }, 1000);
                                    }
                                } else {
                                    restoreUIState();
                                    var errorMsg = (response && response.data && response.data.message) ?
                                        response.data.message :
                                        'Invalid code. Please try again.';
                                    $verifyMsg.html('<p class="errmsg">' + errorMsg + '</p>');
                                }
                            } catch (e) {
                                restoreUIState();
                                $verifyMsg.html('<p class="errmsg">Error processing response. Please try again.</p>');
                            }
                        },
                        error: function (xhr, status, error) {
                            restoreUIState();
                            var errorMsg = (two_factor_auth.messages && two_factor_auth.messages.network_error) ?
                                two_factor_auth.messages.network_error :
                                'Network error. Please check your connection and try again.';
                            $verifyMsg.html('<p class="errmsg">' + errorMsg + '</p>');
                        }
                    });
                } catch (e) {
                    restoreUIState();
                    $verifyMsg = jQuery('#twofa-verify-msg');
                    if ($verifyMsg.length) {
                        $verifyMsg.html('<p class="errmsg">Error processing request. Please try again.</p>');
                    }
                }
            });

            // Skip 2FA handler
            jQuery('.skip-2fa-link').on('click', function(e) {
                e.preventDefault();

                try {
                    // Check if two_factor_auth object is available
                    if (typeof two_factor_auth === 'undefined' || !two_factor_auth.ajaxurl || !two_factor_auth.temp_token) {
                        SnDialog.alert({ message: 'Configuration error. Please refresh the page.' });
                        return;
                    }

                    // Disable all interactive elements
                    var $skipLink = jQuery('.skip-2fa-link');
                    var $verifyButton = jQuery('#verify-2fa');
                    var $generateQrButton = jQuery('#generate-qr');
                    var $sendEmailButton = jQuery('#send-email');
                    var $twofaInput = jQuery('#twofa-code');

                    $skipLink.css('opacity', '0.5').css('pointer-events', 'none');
                    $verifyButton.prop('disabled', true);
                    $generateQrButton.prop('disabled', true);
                    $sendEmailButton.prop('disabled', true);
                    $twofaInput.prop('disabled', true);

                    jQuery.ajax({
                        url: two_factor_auth.ajaxurl,
                        type: 'POST',
                        data: {
                            action: 'secnin_skip_2fa',
                            temp_token: two_factor_auth.temp_token
                        },
                        timeout: 30000, // 30 second timeout
                        success: function(response) {
                            try {
                                if (response && response.success) {
                                    var skipTarget = (response.data && response.data.redirect_url) || (two_factor_auth && two_factor_auth.fallback_admin_url);
                                    if (skipTarget) {
                                        window.location.href = skipTarget;
                                    } else {
                                        window.location.reload();
                                    }
                                } else {
                                    // Re-enable all interactive elements
                                    restoreUIState();
                                    $skipLink.css('opacity', '').css('pointer-events', '');
                                    var errorMsg = (response && response.data && response.data.message) ?
                                        response.data.message :
                                        (two_factor_auth.messages && two_factor_auth.messages.unknown_error) ?
                                        two_factor_auth.messages.unknown_error :
                                        'An error occurred. Please try again.';
                                    SnDialog.alert({ message: errorMsg });
                                }
                            } catch (e) {
                                // Re-enable all interactive elements
                                restoreUIState();
                                $skipLink.css('opacity', '').css('pointer-events', '');
                                SnDialog.alert({ message: 'Error processing response. Please try again.' });
                            }
                        },
                        error: function(xhr, status, error) {
                            // Re-enable all interactive elements
                            restoreUIState();
                            $skipLink.css('opacity', '').css('pointer-events', '');
                            var errorMsg = (two_factor_auth.messages && two_factor_auth.messages.network_error) ?
                                two_factor_auth.messages.network_error :
                                'Network error. Please check your connection and try again.';
                            SnDialog.alert({ message: errorMsg });
                        }
                    });
                    } catch (e) {
                        SnDialog.alert({ message: 'Error processing request. Please try again.' });
                    }
                });

            // Generate QR button handler (with debouncing)
            jQuery('#generate-qr').on('click', function(e) {
                e.preventDefault();
                debouncedGenerateQR();
            });

            // Send Email button handler (with debouncing)
            jQuery('#send-email').on('click', function(e) {
                e.preventDefault();
                window.sn2faEmailSent = true;
                debouncedSendEmail();
            });

            // Method switcher buttons
            jQuery('.sn-2fa-method-btn').on('click', function(e) {
                e.preventDefault();
                var method = jQuery(this).data('method');
                if (method && typeof window.sn2faSetMethod === 'function') {
                    window.sn2faSetMethod(method);
                }
            });

            // Copy Secret button handler (with modern clipboard API)
            jQuery('#copy-secret').on('click', function(e) {
                e.preventDefault();
                try {
                    var secretInput = document.getElementById('secret-key');
                    if (!secretInput) {
                        return;
                    }

                    // Use modern clipboard API first
                    if (navigator.clipboard && navigator.clipboard.writeText) {
                        navigator.clipboard.writeText(secretInput.value).then(function() {
                            showCopySuccess(jQuery(this));
                        }).catch(function() {
                            // Fallback to deprecated method
                            fallbackCopy(secretInput, jQuery(this));
                        });
                    } else {
                        // Fallback for older browsers
                        fallbackCopy(secretInput, jQuery(this));
                    }
                } catch (err) {
                    SnDialog.alert({ message: 'Error copying secret. Please select and copy manually.' });
                }
            });

        } catch (e) {
            restoreUIState();
        }
    }

    function init2FA() {
        try {
            // Check if jQuery is available
            if (typeof jQuery === 'undefined') {
                return;
            }
            
            // Check if two_factor_auth object is available
            if (typeof two_factor_auth === 'undefined') {
                return;
            }
            
            // Check if required elements exist
            var $form = jQuery('#twofa-form-verify');
            var $input = jQuery('#twofa-code');
            var $button = jQuery('#verify-2fa');

            if (!$form.length || !$input.length || !$button.length) {
                return;
            }
            
            // Mark as initialized immediately to prevent duplicates
            window.sn2faInitialized = true;

            var initialMethod = getSelectedMethod();
            setSelectedMethod(initialMethod);
            updateMethodPanels(initialMethod);

            if (!jQuery('.sn-2fa-method-switcher').length) {
                if (jQuery('.qr-code').length && initialMethod === 'app' && !two_factor_auth.has_app_secret) {
                    setTimeout(function() {
                        generateQRCode();
                    }, 100);
                }

                if (jQuery('.email-2fa').length && initialMethod === 'email') {
                    setTimeout(function() {
                        if (!window.sn2faEmailSent) {
                            sendEmailCode();
                        }
                    }, 1000);
                }
            }

            attachEventHandlers();
            
        } catch (e) {
            restoreUIState();
        }
    }
    
    // Single DOM ready handler
    jQuery(document).ready(function() {
        init2FA();
    });
    
})();

// Helper functions for copy functionality
function fallbackCopy(input, $button) {
    try {
        input.select();
        input.setSelectionRange(0, 99999);
        document.execCommand('copy');
        showCopySuccess($button);
    } catch (err) {
        SnDialog.alert({ message: 'Copy not supported. Please select and copy manually.' });
    }
}

function showCopySuccess($button) {
    var originalText = $button.text();
    $button.text('Copied!');
    setTimeout(function() {
        $button.text(originalText);
    }, 2000);
}
