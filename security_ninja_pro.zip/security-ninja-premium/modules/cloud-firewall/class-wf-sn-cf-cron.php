<?php
/**
 * Cloud Firewall Wf_Sn_Cf_Cron helpers (loaded on demand).
 *
 * @package WPSecurityNinja\Plugin
 */

namespace WPSecurityNinja\Plugin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Wf_Sn_Cf_Cron
 */
class Wf_Sn_Cf_Cron {

	public static function prune_visitor_log( $force = false ) {
		global $wpdb;

		$trackvisits_howlong = absint( wf_sn_cf::$options['trackvisits_howlong'] );

		if ( ! $trackvisits_howlong ) {
			$trackvisits_howlong = 2; // in days
		}

		$table_name = $wpdb->prefix . 'wf_sn_cf_vl';
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table_name ) ) === $table_name ) {
			$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . $wpdb->prefix . 'wf_sn_cf_vl WHERE timestamp < DATE_SUB(NOW(), INTERVAL %d DAY)', $trackvisits_howlong ) );

			$max_records     = 5000; // Sane limit for visitor log entries
			$remaining_count = $wpdb->get_var( "SELECT COUNT(*) FROM {$table_name}" );

			if ( $remaining_count > $max_records ) {
				// Find the timestamp of the record that would be the $max_records-th newest
				$cutoff_data = $wpdb->get_row(
					$wpdb->prepare(
						"SELECT timestamp, id FROM {$table_name} 
					ORDER BY timestamp DESC, id DESC 
					LIMIT 1 OFFSET %d",
						$max_records - 1
					)
				);

				if ( $cutoff_data ) {
					// For records with the same timestamp, delete those with lower IDs
					$wpdb->query(
						$wpdb->prepare(
							"DELETE FROM {$table_name} 
						WHERE timestamp < %s 
						OR (timestamp = %s AND id < %d)",
							$cutoff_data->timestamp,
							$cutoff_data->timestamp,
							$cutoff_data->id
						)
					);
				}

				\WPSecurityNinja\Plugin\wf_sn_el_modules::log_event( 'security_ninja', 'pruned_visitor_log', sprintf( esc_html__( 'Pruned firewall visitors log - %1$s days, then reduced to %2$s entries (was %3$s).', 'security-ninja' ), $trackvisits_howlong, $max_records, $remaining_count ), '' );
			} else {
				\WPSecurityNinja\Plugin\wf_sn_el_modules::log_event( 'security_ninja', 'pruned_visitor_log', sprintf( esc_html__( 'Pruned firewall visitors log - %1$s days.', 'security-ninja' ), $trackvisits_howlong ), '' );
			}
		}

		return true;
	}

	/**
	 * Delete all firewall visitor log entries.
	 *
	 * @return bool
	 */

	public static function action_update_blocked_ips__premium_only( $force = false ) {

			$listips = wf_sn_cf::get_network_listips__premium_only();

		if ( ! $listips ) {
			wf_sn_el_modules::log_event( 'security_ninja', 'update_blocked_ips', 'Error getting blocked IPs from server' );
			return false;
		}

			global $wpdb;
			// Cleaning up
			$table_name = $wpdb->prefix . 'wf_sn_cf_bl_ips';

			$delquery = "DELETE FROM `{$table_name}` WHERE HOUR(TIMEDIFF(NOW(), tid))>24;";
			$delres   = $wpdb->query( $delquery );
		if ( $delres ) {
			wf_sn_el_modules::log_event( 'security_ninja', 'update_blocked_ips', sprintf( esc_html__( 'Removed %1$s IPs from the Blocklist - older than 24 hours.', 'security-ninja' ), intval( $delres ) ), '' );
		} else {
			wf_sn_el_modules::log_event( 'security_ninja', 'update_blocked_ips', 'No old IPs needs to be removed.' );
		}

		$blockedips = json_decode( $listips, true );

		if ( $blockedips && is_array( $blockedips ) && isset( $blockedips['ips'] ) && is_array( $blockedips['ips'] ) ) {

			global $wpdb;
			$current_count = 0;
			$limit         = 15;
			$longquery     = '';
			$totalcount    = 0;
			$timenow       = current_time( 'mysql' );
			foreach ( $blockedips['ips'] as $ip ) {
				if ( 0 === $current_count ) {
					$longquery .= ' INSERT IGNORE INTO `' . $table_name . "` (`ip`) VALUES ('" . esc_sql( $ip ) . "')";
				} else {
					$longquery .= ",('" . esc_sql( $ip ) . "')";
				}
				++$current_count;

				if ( $current_count > $limit ) {
					$longquery .= ';'; // add ending semicolon before executing
					$wpdb->query( $longquery );
					$longquery     = '';
					$current_count = 0;
				}
				++$totalcount;
			}

			// Leftovers?
			if ( $current_count > 0 ) {
				$longquery .= ';'; // add ending semicolon before executing
				$wpdb->query( $longquery );
				$longquery     = '';
				$current_count = 0;
			}
		}
	}

	/**
	 * Prune events log table
	 *
	 * @author  Lars Koudal
	 * @since   v0.0.1
	 * @version v1.0.0  Monday, December 21st, 2020.
	 * @access  public static
	 * @param   boolean $force  Default: false
	 * @return  boolean
	 */

	public static function schedule_cron_jobs() {

		if ( secnin_fs()->can_use_premium_code__premium_only() ) {
			// Update GEOIP database - once a month
			if ( ! wp_next_scheduled( 'secnin_update_geoip' ) ) {
				wp_schedule_event( time() + 30, 'weekly', 'secnin_update_geoip' );
			}

			// Update cloud IPs
			if ( ! wp_next_scheduled( 'secnin_update_cloud_firewall' ) ) {
				wp_schedule_event( time() + 15, 'daily', 'secnin_update_cloud_firewall' );
			}

			// Prune visitor log entries according to retention setting
			if ( ! wp_next_scheduled( 'secnin_prune_visitor_log' ) ) {
				wp_schedule_event( time() + 45, 'daily', 'secnin_prune_visitor_log' );
			}

			// Remove expired local firewall IP bans
			if ( ! wp_next_scheduled( 'secnin_prune_banned' ) ) {
				wp_schedule_event( time() + 60, 'daily', 'secnin_prune_banned' );
			}

			// Download shared Block IP Network list
			if ( ! wp_next_scheduled( 'secnin_update_blocked_ips' ) ) {
				wp_schedule_event( time() + 90, 'daily', 'secnin_update_blocked_ips' );
			}

			// Flush queued Block IP Network reports (batch)
			if ( ! wp_next_scheduled( 'secnin_flush_network_reports' ) ) {
				wp_schedule_event( time() + 120, 'secnin_fifteen_minutes', 'secnin_flush_network_reports' );
			}
		}
	}



	/**
	 * Wrapper method to update GEOIP database via cron.
	 * Loads the SN_Geolocation class only when needed.
	 *
	 * @author  Lars Koudal
	 * @since   v0.0.1
	 * @access  public static
	 * @return  void
	 */

	public static function update_geoip_database__premium_only() {
			// Load the class file if not already loaded
		if ( ! class_exists( __NAMESPACE__ . '\\SN_Geolocation' ) ) {
			require_once WF_SN_PLUGIN_DIR . 'modules/cloud-firewall/class-sn-geolocation.php';
		}

			// Call the actual method
		if ( class_exists( __NAMESPACE__ . '\\SN_Geolocation' ) ) {
			SN_Geolocation::update_database();
		}
	}


	/**
	 * Check if IP is from banned country
	 *
	 * @author  Lars Koudal
	 * @since   v0.0.1
	 * @version v1.0.0  Monday, December 21st, 2020.
	 * @access  public static
	 * @param   boolean $ip User IP - optionals
	 * @return  boolean
	 */

	public static function update_cloud_ips__premium_only() {

		if ( secnin_fs()->can_use_premium_code__premium_only() ) {

			$server_ip = wf_sn_cf::get_server_ip();
			// $options          = wf_sn_cf::$options;

			$local_whitelist = ( isset( wf_sn_cf::$options ) && is_array( wf_sn_cf::$options ) && isset( wf_sn_cf::$options['whitelist'] ) && is_array( wf_sn_cf::$options['whitelist'] ) ) ? wf_sn_cf::$options['whitelist'] : array();

			if ( ! Wf_sn_cf_Utils::is_whitelisted( $server_ip, $local_whitelist ) ) {
				wf_sn_cf::$options['whitelist'][] = trim( $server_ip );
				update_option( WF_SN_CF_OPTIONS_KEY, wf_sn_cf::$options, false );
				wf_sn_el_modules::log_event( 'security_ninja', 'unblocked_ip', 'Added server IP to whitelist ' . $server_ip );
			}

			$firehol = 'https://raw.githubusercontent.com/firehol/blocklist-ipsets/master/firehol_level1.netset';

			$response = wp_remote_get( $firehol );

			if ( ! is_wp_error( $response ) ) {
				$body             = wp_remote_retrieve_body( $response );
				$sn_firewall_data = array(
					'ips'     => array(),
					'subnets' => array(),
				);

				$lines = explode( PHP_EOL, $body );

				foreach ( $lines as $line_num => $line ) {

					if ( strpos( $line, '#' ) !== false ) {
						// Skip comments
						continue;
					} elseif ( strpos( $line, '/' ) !== false ) {

						$nework_array = explode( '.', trim( $line ), 2 );

						if ( ! array_key_exists( $nework_array[0], $sn_firewall_data['subnets'] ) ) {

							$sn_firewall_data['subnets'][ $nework_array[0] ] = array();
						}
						$sn_firewall_data['subnets'][ $nework_array[0] ][] = trim( $line );
					} else {
						$sn_firewall_data['ips'][] = trim( $line );
					}
				}
				$sn_firewall_data['timestamp'] = time();
				$sn_firewall_data['total']     = Wf_sn_cf_Utils::count_cloud_list_addresses( $sn_firewall_data );
				update_option( 'wf_sn_cf_ips', $sn_firewall_data, false );
				wf_sn_cf::clear_cloud_ips_cache();
			} else {
				wf_sn_el_modules::log_event( 'security_ninja', 'geolocation_download', 'Unable to download GeoIP Database: ' . $response->get_error_message(), '' );
			}
		}
	}







	/**
	 * Register module settings.
	 *
	 * @author  Lars Koudal
	 * @since   v0.0.1
	 * @version v1.0.0  Monday, December 21st, 2020.
	 * @access  public static
	 * @return  void
	 */

	public static function prune_banned() {
		$update = false;

		$banned_ips = wf_sn_cf::get_banned_ips();
		if ( $banned_ips ) {
			foreach ( $banned_ips as $ip => $time ) {
				if ( $time < \WPSecurityNinja\Plugin\Secnin_Waf_Ban_Clock::now() ) {
					unset( $banned_ips[ $ip ] );
					$update = true;
				}
			}
		}

		if ( $update ) {
			wf_sn_cf::update_banned_ips( $banned_ips );
			if ( class_exists( __NAMESPACE__ . '\wf_sn_el_modules' ) ) {
				wf_sn_el_modules::log_event( 'security_ninja', 'pruned_banned_ips', 'Pruned Firewall local banned IPs.', '' );
			}
		}
	}





	/**
	 * Handle failed login - basic logging for free, advanced protection for premium
	 *
	 * @author  Lars Koudal
	 * @since   v0.0.1
	 * @version v1.0.0  Monday, December 21st, 2020.
	 * @version v1.0.1  Tuesday, January 14th, 2025 - Consolidated free and premium logic
	 * @access  public static
	 * @param   mixed   $username
	 * @return  void
	 */

}
