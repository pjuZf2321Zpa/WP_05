<?php
/**
 * Early Firewall installer (auto_prepend_file).
 *
 * Pro-only usage; ships for Pro builds via @fs_premium_only or gated UI.
 *
 * @package WPSecurityNinja\Plugin
 */

namespace WPSecurityNinja\Plugin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Secnin_Waf_Installer
 */
class Secnin_Waf_Installer {

	const HTACCESS_BEGIN = '# BEGIN Security Ninja WAF';
	const HTACCESS_END   = '# END Security Ninja WAF';
	const USERINI_BEGIN  = '; BEGIN Security Ninja WAF';
	const USERINI_END    = '; END Security Ninja WAF';

	/**
	 * Detect server profile for prepend install.
	 *
	 * @return string
	 */
	public static function detect_server_profile() {
		return Secnin_Waf_Lifecycle::detect_server_profile();
	}

	/**
	 * Absolute path for root proxy file.
	 *
	 * @return string
	 */
	public static function get_bootstrap_path() {
		return Secnin_Waf_Lifecycle::get_bootstrap_path();
	}

	/**
	 * Label an existing auto_prepend_file path.
	 *
	 * @param string $path Path from ini_get.
	 * @return array
	 */
	public static function label_prepend_path( $path ) {
		return Secnin_Waf_Lifecycle::label_prepend_path( $path );
	}

	/**
	 * Current auto_prepend_file value.
	 *
	 * @return string
	 */
	public static function current_auto_prepend() {
		return Secnin_Waf_Lifecycle::current_auto_prepend();
	}

	/**
	 * Whether prepend appears to come from a host php.ini we cannot rewrite.
	 *
	 * @return bool
	 */
	public static function is_host_ini_prepend() {
		return Secnin_Waf_Lifecycle::is_host_ini_prepend();
	}

	/**
	 * .htaccess path.
	 *
	 * @return string
	 */
	public static function get_htaccess_path() {
		return Secnin_Waf_Lifecycle::get_htaccess_path();
	}

	/**
	 * .user.ini path.
	 *
	 * @return string|false
	 */
	public static function get_user_ini_path() {
		return Secnin_Waf_Lifecycle::get_user_ini_path();
	}

	/**
	 * Generate root proxy PHP content.
	 *
	 * @param string|null $chain_file Prior auto_prepend_file to include.
	 * @return string
	 */
	public static function get_proxy_content( $chain_file = null ) {
		$runtime = trailingslashit( Secnin_Waf_Lifecycle::get_data_dir() ) . 'runtime/bootstrap.php';
		if ( ! is_readable( $runtime ) ) {
			$runtime = null;
		}
		return Secnin_Waf_Lifecycle::get_proxy_content( $chain_file, $runtime );
	}

	/**
	 * Relative path from $from directory to $to file (include-safe).
	 *
	 * @param string $from From dir.
	 * @param string $to   To file.
	 * @return string
	 */
	public static function relative_path( $from, $to ) {
		return Secnin_Fs_Atomic::relative_include_suffix( $from, $to );
	}

	/**
	 * Abort install into failed_safe with a single message.
	 *
	 * @param string $message Error.
	 * @return array{success:bool,message:string}
	 */
	private static function fail_install( $message ) {
		Secnin_Waf_Extended::update(
			array(
				'mode'          => 'legacy',
				'status'        => 'failed_safe',
				'install_error' => $message,
			)
		);
		return array(
			'success' => false,
			'message' => $message,
		);
	}

	/**
	 * Resolve optional chain target for an allowlisted non-WAF prepend.
	 *
	 * @param string $current Current prepend path.
	 * @param array  $label   Classification.
	 * @param string $action  Install action.
	 * @return string|null|array Error array, chain path, or null.
	 */
	private static function resolve_chain_prepend( $current, $label, $action ) {
		if ( '' === $current || ! empty( $label['is_ours'] ) ) {
			return null;
		}
		if ( ! empty( $label['is_competing_waf'] ) || ! empty( $label['is_unknown'] ) ) {
			return array(
				'success' => false,
				'message' => ! empty( $label['is_competing_waf'] )
					? __( 'Another security WAF already owns auto_prepend_file. Guided migration is required; chaining competing WAFs is not supported.', 'security-ninja' )
					: __( 'An unrecognized PHP prepend is already set. Guided migration is required; chaining unknown prepends is not supported.', 'security-ninja' ),
				'data'    => array(
					'current' => $current,
					'label'   => $label,
				),
			);
		}
		if ( empty( $label['is_non_waf'] ) ) {
			return null;
		}
		if ( 'confirm_non_waf' !== $action && 'chain' !== $action ) {
			return array(
				'success' => false,
				'message' => sprintf(
					/* translators: %s: prepend file path */
					__( 'An existing PHP prepend file was found (%s). Confirm chaining only if it is a non-WAF application bootstrap you trust.', 'security-ninja' ),
					$current
				),
				'data'    => array(
					'current' => $current,
					'label'   => $label,
					'needs'   => 'confirm_non_waf',
				),
			);
		}
		if ( ! is_readable( $current ) ) {
			return array(
				'success' => false,
				'message' => __( 'Existing prepend file is not readable. Install aborted.', 'security-ninja' ),
			);
		}
		return $current;
	}

	/**
	 * Install Early Firewall (write proxy + directives, force config sync).
	 *
	 * @param array $args {
	 *   @type string $action chain|abort|confirm_non_waf
	 * }
	 * @return array{success:bool,message:string,data?:array}
	 */
	public static function install( $args = array() ) {
		$action = isset( $args['action'] ) ? (string) $args['action'] : 'abort';
		if ( 'override' === $action ) {
			$action = 'abort';
		}

		$eligibility = Secnin_Waf_Lifecycle::eligibility();
		if ( empty( $eligibility['ok'] ) ) {
			return array(
				'success' => false,
				'message' => isset( $eligibility['message'] ) ? $eligibility['message'] : __( 'Early Firewall is not eligible on this host.', 'security-ninja' ),
				'data'    => $eligibility,
			);
		}
		if ( 'abort' === $action ) {
			return array(
				'success' => false,
				'message' => __( 'Install cancelled.', 'security-ninja' ),
			);
		}

		$profile = $eligibility['profile'];
		$current = Secnin_Waf_Lifecycle::current_auto_prepend();
		$label   = Secnin_Waf_Lifecycle::label_prepend_path( $current );
		$chain   = self::resolve_chain_prepend( $current, $label, $action );
		if ( is_array( $chain ) && isset( $chain['success'] ) ) {
			return $chain;
		}

		$admin_ip = class_exists( __NAMESPACE__ . '\\wf_sn_cf' ) ? wf_sn_cf::get_user_ip() : '';
		if ( ! $admin_ip || ! filter_var( $admin_ip, FILTER_VALIDATE_IP ) ) {
			return self::fail_install( __( 'Could not determine your IP address. Early Firewall was not installed. Whitelist your IP manually, then try again.', 'security-ninja' ) );
		}
		$options   = wf_sn_cf::get_options();
		$whitelist = isset( $options['whitelist'] ) && is_array( $options['whitelist'] ) ? $options['whitelist'] : array();
		if ( ! Wf_sn_cf_Utils::is_whitelisted( $admin_ip, $whitelist ) ) {
			wf_sn_cf::add_ip_to_whitelist( $admin_ip );
		}

		$proxy_path = self::get_bootstrap_path();
		if ( file_exists( $proxy_path ) && ! Secnin_Waf_Lifecycle::proxy_is_owned( $proxy_path ) ) {
			return self::fail_install( __( 'A secnin-waf.php file already exists in the site root and is not owned by Security Ninja. Install aborted.', 'security-ninja' ) );
		}

		$ht_snap  = Secnin_Waf_Lifecycle::snapshot_for_recovery( self::get_htaccess_path(), 'htaccess_pre_install' );
		$ini_path = self::get_user_ini_path();
		$ini_snap = $ini_path ? Secnin_Waf_Lifecycle::snapshot_for_recovery( $ini_path, 'userini_pre_install' ) : array( 'ok' => true );
		$host_ini_at_install = Secnin_Waf_Lifecycle::is_host_ini_prepend();
		Secnin_Waf_Lifecycle::store_recovery(
			array(
				'prior_prepend'        => $current,
				'prior_prepend_label'  => $label,
				'htaccess_snapshot'    => $ht_snap,
				'userini_snapshot'     => $ini_snap,
				'chained_prepend'      => is_string( $chain ) ? $chain : '',
				'installed_at'         => time(),
				'host_ini_at_install'  => $host_ini_at_install ? 1 : 0,
			)
		);

		$data_dir = Secnin_Waf_Lifecycle::get_data_dir();
		Secnin_Fs_Atomic::protect_directory( $data_dir );
		$runtime_dir = trailingslashit( $data_dir ) . 'runtime';
		Secnin_Fs_Atomic::mkdir_p( $runtime_dir, 0755 );

		Secnin_Waf_Extended::update(
			array(
				'mode'           => 'extended',
				'status'         => 'probing',
				'runtime_path'   => $runtime_dir,
				'install_hint'   => __( 'Early Firewall files are being prepared. Click Verify after PHP picks up auto_prepend_file (often up to user_ini.cache_ttl seconds).', 'security-ninja' ),
				'bundle_version' => defined( 'WF_SN_PLUGIN_VERSION' ) ? WF_SN_PLUGIN_VERSION : '',
			)
		);

		if ( ! self::publish_runtime_bundle( $runtime_dir ) ) {
			return self::fail_install( __( 'Could not publish Early Firewall runtime files.', 'security-ninja' ) );
		}

		$synced = Secnin_Waf_Config::sync_all( true );
		$active = Secnin_Waf_Config::get_active_generation_path();
		if ( ! $synced || '' === $active || ! is_readable( $active ) ) {
			return self::fail_install( __( 'Could not write Early Firewall configuration generation. Install aborted.', 'security-ninja' ) );
		}

		$proxy = self::get_proxy_content( is_string( $chain ) ? $chain : null );
		if ( ! Secnin_Fs_Atomic::is_ok( Secnin_Fs_Atomic::write_file( $proxy_path, $proxy, 0644 ) ) ) {
			return self::fail_install( __( 'Could not write secnin-waf.php in the site root.', 'security-ninja' ) );
		}

		$ht_ok        = self::write_htaccess_block( $profile, $proxy_path );
		$ini_ok       = self::write_user_ini_block( $profile, $proxy_path );
		$directive_ok = self::profile_directive_succeeded( $profile, $ht_ok, $ini_ok );
		if ( ! $directive_ok ) {
			Secnin_Waf_Lifecycle::remove_htaccess_block();
			Secnin_Waf_Lifecycle::remove_user_ini_block();
			if ( file_exists( $proxy_path ) && Secnin_Waf_Lifecycle::proxy_is_owned( $proxy_path ) ) {
				@unlink( $proxy_path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged,WordPress.WP.AlternativeFunctions.unlink_unlink
			}
			$msg = __( 'Could not write a functional auto_prepend_file directive for this server profile.', 'security-ninja' );
			if ( in_array( $profile, array( 'cgi', 'nginx', 'litespeed' ), true ) && ! self::get_user_ini_path() ) {
				$msg = __( 'This host has an empty user_ini.filename, so .user.ini cannot set auto_prepend_file. Early Firewall was not enabled.', 'security-ninja' );
			}
			return self::fail_install( $msg );
		}

		$probe = self::http_probe();
		if ( ! empty( $probe['hard_fail'] ) ) {
			Secnin_Waf_Lifecycle::begin_removal( array( 'skip_status' => true ) );
			Secnin_Waf_Extended::update(
				array(
					'mode'          => 'legacy',
					'status'        => 'failed_safe',
					'last_rollback' => $probe['message'],
					'install_error' => $probe['message'],
				)
			);
			return array(
				'success' => false,
				'message' => sprintf(
					/* translators: %s: probe error */
					__( 'Install rolled back after HTTP probe failed: %s', 'security-ninja' ),
					$probe['message']
				),
			);
		}

		$hint = __( 'Early Firewall is ready. Click Verify.', 'security-ninja' );
		if ( $host_ini_at_install ) {
			$hint = __( 'Early Firewall is ready. Click Verify. If this host keeps the previous setting, the normal firewall stays in place.', 'security-ninja' );
		}

		Secnin_Waf_Extended::update(
			array(
				'mode'            => 'extended',
				'status'          => 'pending',
				'prepend_path'    => $proxy_path,
				'chained_prepend' => is_string( $chain ) ? $chain : '',
				'server_profile'  => $profile,
				'install_error'   => '',
				'install_hint'    => $hint,
				'last_verify'     => 0,
				'runtime_path'    => $runtime_dir,
			)
		);

		return array(
			'success' => true,
			'message' => $hint,
			'data'    => array(
				'profile' => $profile,
				'path'    => $proxy_path,
			),
		);
	}

	/**
	 * Copy plugin WAF runtime files into the private data directory.
	 *
	 * @param string $runtime_dir Destination runtime directory.
	 * @return bool
	 */
	public static function publish_runtime_bundle( $runtime_dir ) {
		$src = WF_SN_PLUGIN_DIR . 'modules/cloud-firewall/waf';
		$files = array(
			'bootstrap.php',
			'class-secnin-waf-runner.php',
			'class-secnin-waf-decision.php',
			'class-secnin-waf-decision-engine.php',
			'class-secnin-waf-woo-payment-surface.php',
			'class-secnin-waf-surecart-payment-surface.php',
			'secnin-waf-login-related.php',
			'rules-8g.php',
		);
		$ok = true;
		foreach ( $files as $file ) {
			$from = $src . '/' . $file;
			$to   = trailingslashit( $runtime_dir ) . $file;
			if ( ! is_readable( $from ) ) {
				$ok = false;
				continue;
			}
			$contents = file_get_contents( $from ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
			if ( false === $contents ) {
				$ok = false;
				continue;
			}
			if ( ! Secnin_Fs_Atomic::is_ok( Secnin_Fs_Atomic::write_file( $to, $contents, 0644 ) ) ) {
				$ok = false;
				continue;
			}
			$written = is_readable( $to ) ? (string) file_get_contents( $to ) : ''; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
			if ( ! hash_equals( hash( 'sha256', $contents ), hash( 'sha256', $written ) ) ) {
				$ok = false;
			}
		}
		return $ok;
	}

	/**
	 * Refresh runtime bundle when plugin version mismatches stored bundle version.
	 *
	 * Copies WAF PHP into the private runtime dir, then recompiles the active
	 * generation so baked-in query_rules (from rules-8g.php + filters) match the
	 * new plugin. Decision engine prefers config query_rules over the on-disk
	 * rules file, so a file copy alone is not enough after a rule change.
	 *
	 * @return bool
	 */
	public static function maybe_refresh_runtime_bundle() {
		if ( ! class_exists( __NAMESPACE__ . '\\Secnin_Waf_Extended' ) || ! Secnin_Waf_Extended::is_installed() ) {
			return false;
		}
		$ext     = Secnin_Waf_Extended::get();
		$current = defined( 'WF_SN_PLUGIN_VERSION' ) ? (string) WF_SN_PLUGIN_VERSION : '';
		$stored  = isset( $ext['bundle_version'] ) ? (string) $ext['bundle_version'] : '';
		$runtime = isset( $ext['runtime_path'] ) ? (string) $ext['runtime_path'] : '';
		if ( '' === $runtime ) {
			$runtime = trailingslashit( Secnin_Waf_Lifecycle::get_data_dir() ) . 'runtime';
		}
		if ( '' !== $stored && $stored === $current && is_readable( trailingslashit( $runtime ) . 'bootstrap.php' ) ) {
			return true;
		}
		Secnin_Fs_Atomic::mkdir_p( $runtime, 0755 );
		$ok = self::publish_runtime_bundle( $runtime );
		if ( ! $ok ) {
			Secnin_Waf_Extended::update(
				array(
					'status'        => 'failed_safe',
					'install_error' => __( 'Could not refresh Early Firewall runtime files after a plugin update.', 'security-ninja' ),
				)
			);
			return false;
		}

		$synced = false;
		if ( class_exists( __NAMESPACE__ . '\\Secnin_Waf_Config' ) ) {
			$synced = Secnin_Waf_Config::sync_all( true );
		}
		if ( ! $synced ) {
			Secnin_Waf_Extended::update(
				array(
					'status'        => 'failed_safe',
					'install_error' => __( 'Early Firewall runtime files were updated, but the compiled config could not be rebuilt. Open Firewall, Extended Protection, and click Verify, or save Firewall settings to retry.', 'security-ninja' ),
				)
			);
			return false;
		}

		Secnin_Waf_Extended::update(
			array(
				'bundle_version' => $current,
				'runtime_path'   => $runtime,
				'install_error'  => '',
			)
		);
		return true;
	}

	/**
	 * Verify prepend is active.
	 *
	 * @return array{success:bool,message:string}
	 */
	public static function verify() {
		$ext = Secnin_Waf_Extended::get();
		if ( 'removal_pending' === $ext['status'] ) {
			return Secnin_Waf_Lifecycle::finish_removal_if_safe();
		}

		$status = isset( $ext['status'] ) ? (string) $ext['status'] : 'off';
		if ( ! Secnin_Waf_Extended::is_installed() ) {
			if ( 'off' !== $status ) {
				Secnin_Waf_Extended::update( array( 'status' => 'off' ) );
			}
			return array(
				'success' => false,
				'message' => __( 'Early Firewall is not enabled yet. Use Enable Early Firewall first, then verify after PHP picks up the change.', 'security-ninja' ),
			);
		}

		$current = self::current_auto_prepend();
		$ours    = self::get_bootstrap_path();
		$label   = self::label_prepend_path( $current );
		$ours_on = ! empty( $label['is_ours'] ) || ( $current && realpath( $current ) && realpath( $ours ) && realpath( $current ) === realpath( $ours ) );

		$config_ok = defined( 'SECNIN_WAF_CONFIG_VALID' ) && SECNIN_WAF_CONFIG_VALID;
		$engine_ok = defined( 'SECNIN_WAF_ENGINE_COMPLETE' ) && SECNIN_WAF_ENGINE_COMPLETE;
		$attempted = ( defined( 'SECNIN_WAF_ATTEMPTED' ) && SECNIN_WAF_ATTEMPTED ) || ( defined( 'SECNIN_WAF_AUTO_PREPEND' ) && SECNIN_WAF_AUTO_PREPEND );

		/*
		 * The admin AJAX request can use different per-directory PHP settings than
		 * the public front controller. Probe representative locations every time.
		 */
		$coverage = self::coverage_probe();
		if ( ! empty( $coverage['root_complete'] ) ) {
			$config_ok = true;
			$engine_ok = true;
		}

		if ( $config_ok && $engine_ok && ! empty( $coverage['all_complete'] ) ) {
			Secnin_Waf_Extended::update(
				array(
					'mode'          => 'extended',
					'status'        => 'active',
					'last_verify'   => time(),
					'verify_fails'  => 0,
					'install_error' => '',
					'install_hint'  => '',
				)
			);
			return array(
				'success' => true,
				'message' => __( 'Early Firewall is active.', 'security-ninja' ),
			);
		}

		if ( $config_ok && $engine_ok && ! empty( $coverage['root_complete'] ) ) {
			$message = __( 'Early Firewall is running on regular page views. Other PHP entry points still use the normal firewall.', 'security-ninja' );
			Secnin_Waf_Extended::update(
				array(
					'mode'          => 'extended',
					'status'        => 'partial',
					'last_verify'   => time(),
					'verify_fails'  => 0,
					'install_error' => $message,
					'install_hint'  => '',
				)
			);
			return array(
				'success' => true,
				'message' => $message,
			);
		}

		if ( $ours_on && $attempted && ( ! $config_ok || ! $engine_ok ) ) {
			Secnin_Waf_Extended::update(
				array(
					'status'        => 'failed_safe',
					'install_error' => __( 'PHP prepends Security Ninja, but the Early Firewall runtime has no valid configuration or did not finish. WordPress-hooks protection remains the fallback.', 'security-ninja' ),
				)
			);
			return array(
				'success' => false,
				'message' => __( 'Prepend is present but the Early Firewall runtime is unhealthy. Check configuration sync and try Disable, then Enable again.', 'security-ninja' ),
			);
		}

		$fails = isset( $ext['verify_fails'] ) ? (int) $ext['verify_fails'] + 1 : 1;
		$ttl   = (int) ini_get( 'user_ini.cache_ttl' );
		if ( $ttl <= 0 ) {
			$ttl = 300;
		}
		$recovery            = Secnin_Waf_Lifecycle::get_recovery();
		$installed_at        = ! empty( $recovery['installed_at'] ) ? (int) $recovery['installed_at'] : 0;
		$elapsed             = $installed_at > 0 ? ( time() - $installed_at ) : 0;
		$prior               = isset( $recovery['prior_prepend'] ) ? (string) $recovery['prior_prepend'] : '';
		$host_ini_at_install = ! empty( $recovery['host_ini_at_install'] );
		$still_prior         = ( '' !== $prior && Secnin_Waf_Lifecycle::paths_same_prepend( $current, $prior ) );

		Secnin_Waf_Extended::update( array( 'verify_fails' => $fails ) );

		/*
		 * Host php.ini still owns prepend after we wrote .user.ini/.htaccess.
		 * Some FPM managers keep old per-directory state beyond the advertised TTL
		 * until PHP is reloaded. Allow two TTL windows and two explicit checks before
		 * cleanup; six failed checks still provides an upper bound.
		 */
		$host_lock_deadline = 2 * $ttl;
		$is_installing      = in_array( $status, array( 'pending', 'probing' ), true );
		$failure_threshold  = ( $elapsed > ( 2 * $ttl ) && $fails >= 2 ) || $fails >= 6;
		if ( $is_installing && $still_prior && ( ( $elapsed > $host_lock_deadline && $fails >= 2 ) || $fails >= 6 ) ) {
			return Secnin_Waf_Lifecycle::abort_inert_install(
				__( 'auto_prepend_file is still owned by the host (php.ini / php_admin_value). Site-level .user.ini could not override it. Early Firewall markers were removed. WordPress-hooks protection remains the fallback.', 'security-ninja' )
			);
		}

		if ( $is_installing && $failure_threshold ) {
			$message = __( 'Early Firewall could not be verified consistently. Its files and configuration markers were kept because the loopback result does not prove that PHP stopped using them. WordPress-hooks protection remains active until verification succeeds or removal completes safely.', 'security-ninja' );
			Secnin_Waf_Extended::update(
				array(
					'mode'          => 'extended',
					'status'        => 'failed_safe',
					'install_error' => $message,
				)
			);
			return array(
				'success' => false,
				'message' => $message,
			);
		}

		if ( ! $is_installing && $failure_threshold ) {
			$message = __( 'Early Firewall verification is no longer consistent. Its files were left in place to avoid disrupting a server that may be temporarily unreachable or load balanced. WordPress-hooks protection is active until verification succeeds again.', 'security-ninja' );
			Secnin_Waf_Extended::update(
				array(
					'mode'          => 'extended',
					'status'        => 'failed_safe',
					'install_error' => $message,
				)
			);
			return array(
				'success' => false,
				'message' => $message,
			);
		}

		if ( $is_installing ) {
			if ( $still_prior && $host_ini_at_install ) {
				return array(
					'success' => false,
					'message' => sprintf(
						/* translators: %d: cache TTL seconds */
						__( 'PHP still shows the previous host prepend. Wait up to %d seconds, or reload PHP-FPM / LiteSpeed, then Verify again. If representative requests still miss Early Firewall, Verify will roll back and keep WordPress-hooks protection.', 'security-ninja' ),
						max( 1, ( 2 * $ttl ) - $elapsed )
					),
				);
			}
			return array(
				'success' => false,
				'message' => __( 'Early Firewall is not active yet. Wait a minute, then click Verify again.', 'security-ninja' ),
			);
		}

		return array(
			'success' => false,
			'message' => __( 'Early Firewall is not active on this request. Enable it first, or wait for PHP to reload auto_prepend_file.', 'security-ninja' ),
		);
	}

	/**
	 * Remove Early Firewall files and markers (staged).
	 *
	 * @param array $args Optional.
	 * @return array{success:bool,message:string}
	 */
	public static function uninstall( $args = array() ) {
		$result = Secnin_Waf_Lifecycle::begin_removal( $args );
		$finish = Secnin_Waf_Lifecycle::finish_removal_if_safe();
		if ( ! empty( $finish['success'] ) ) {
			return $finish;
		}
		return $result;
	}

	/**
	 * Whether the profile-specific prepend directive write succeeded.
	 *
	 * Cosmetic deny stanzas alone do not count as success.
	 *
	 * @param string $profile Profile.
	 * @param bool   $ht_ok   .htaccess write result.
	 * @param bool   $ini_ok  .user.ini write result.
	 * @return bool
	 */
	private static function profile_directive_succeeded( $profile, $ht_ok, $ini_ok ) {
		switch ( $profile ) {
			case 'apache-mod_php':
				return (bool) $ht_ok;
			case 'cgi':
			case 'nginx':
				return (bool) $ini_ok;
			case 'litespeed':
				return (bool) $ht_ok || (bool) $ini_ok;
			default:
				return false;
		}
	}

	/**
	 * Write marked .htaccess block when appropriate.
	 *
	 * @param string $profile Server profile.
	 * @param string $proxy   Bootstrap path.
	 * @return bool
	 */
	private static function write_htaccess_block( $profile, $proxy ) {
		$path    = self::get_htaccess_path();
		$escaped = addcslashes( $proxy, "'" );

		$block = '';
		switch ( $profile ) {
			case 'apache-mod_php':
				$block = self::HTACCESS_BEGIN . "\n"
					. "<IfModule mod_php5.c>\n\tphp_value auto_prepend_file '{$escaped}'\n</IfModule>\n"
					. "<IfModule mod_php7.c>\n\tphp_value auto_prepend_file '{$escaped}'\n</IfModule>\n"
					. "<IfModule mod_php.c>\n\tphp_value auto_prepend_file '{$escaped}'\n</IfModule>\n"
					. self::HTACCESS_END . "\n";
				break;
			case 'litespeed':
				$block = self::HTACCESS_BEGIN . "\n"
					. "<IfModule LiteSpeed>\nphp_value auto_prepend_file '{$escaped}'\n</IfModule>\n"
					. "<IfModule lsapi_module>\nphp_value auto_prepend_file '{$escaped}'\n</IfModule>\n"
					. self::HTACCESS_END . "\n";
				break;
			case 'cgi':
			case 'nginx':
				// Apache <Files> deny does not protect .user.ini on nginx; skip cosmetic stanzas.
				return true;
			default:
				return false;
		}

		if ( '' === $block ) {
			return false;
		}

		$existing = is_readable( $path ) ? (string) file_get_contents( $path ) : ''; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		$mode     = is_readable( $path ) ? (int) fileperms( $path ) : 0;
		$regex    = '/' . preg_quote( self::HTACCESS_BEGIN, '/' ) . '.*?' . preg_quote( self::HTACCESS_END, '/' ) . '/is';
		if ( preg_match( $regex, $existing ) ) {
			$existing = preg_replace( $regex, trim( $block ), $existing );
		} else {
			$existing = rtrim( $existing ) . "\n\n" . $block;
		}
		$perms  = $mode ? ( $mode & 0777 ) : 0;
		$result = Secnin_Fs_Atomic::is_ok( Secnin_Fs_Atomic::write_file( $path, (string) $existing, $perms ) );
		if ( $result && 'litespeed' === $profile ) {
			@touch( $path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged,WordPress.WP.AlternativeFunctions.file_system_operations_touch
		}
		return $result;
	}

	/**
	 * Write .user.ini block when needed.
	 *
	 * @param string $profile Profile.
	 * @param string $proxy   Path.
	 * @return bool
	 */
	private static function write_user_ini_block( $profile, $proxy ) {
		if ( 'apache-mod_php' === $profile ) {
			return true;
		}
		if ( ! in_array( $profile, array( 'cgi', 'nginx', 'litespeed' ), true ) ) {
			return false;
		}
		$path = self::get_user_ini_path();
		if ( ! $path ) {
			return false;
		}
		$escaped  = addcslashes( $proxy, "'" );
		$block    = self::USERINI_BEGIN . "\nauto_prepend_file = '{$escaped}'\n" . self::USERINI_END . "\n";
		$existing = is_readable( $path ) ? (string) file_get_contents( $path ) : ''; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		$mode     = is_readable( $path ) ? (int) fileperms( $path ) : 0;
		// Do not comment out foreign prepend lines; competing WAFs are refused earlier.
		// Only replace our marked block.
		$regex = '/' . preg_quote( self::USERINI_BEGIN, '/' ) . '.*?' . preg_quote( self::USERINI_END, '/' ) . '/is';
		if ( preg_match( $regex, $existing ) ) {
			$existing = preg_replace( $regex, trim( $block ), $existing );
		} else {
			$existing = rtrim( $existing ) . "\n\n" . $block;
		}
		$perms = $mode ? ( $mode & 0777 ) : 0;
		return Secnin_Fs_Atomic::is_ok( Secnin_Fs_Atomic::write_file( $path, (string) $existing, $perms ) );
	}

	/**
	 * Detect the mod_proxy_fcgi path mismatch that breaks parent .user.ini scans.
	 *
	 * @return bool
	 */
	private static function has_double_slash_script_filename() {
		$script        = isset( $_SERVER['SCRIPT_FILENAME'] ) ? (string) $_SERVER['SCRIPT_FILENAME'] : '';
		$document_root = isset( $_SERVER['DOCUMENT_ROOT'] ) ? (string) $_SERVER['DOCUMENT_ROOT'] : '';

		return 0 === strpos( $script, '//' )
			&& 0 !== strpos( $document_root, '//' )
			&& '' !== $document_root;
	}

	/**
	 * Probe representative PHP locations for per-directory prepend coverage.
	 *
	 * @return array{root_complete:bool,all_complete:bool,missing:array,results:array}
	 */
	private static function coverage_probe() {
		$targets = array(
			'public front controller' => home_url( '/' ),
			'wp-admin/admin-ajax.php' => admin_url( 'admin-ajax.php' ),
			'wp-login.php'            => site_url( 'wp-login.php' ),
		);

		$xmlrpc_path = trailingslashit( ABSPATH ) . 'xmlrpc.php';
		if ( is_readable( $xmlrpc_path ) ) {
			$targets['xmlrpc.php'] = site_url( 'xmlrpc.php' );
		}

		$content_index = trailingslashit( WP_CONTENT_DIR ) . 'index.php';
		$content_url   = content_url( 'index.php' );
		if ( is_readable( $content_index ) && wp_parse_url( $content_url, PHP_URL_HOST ) === wp_parse_url( home_url( '/' ), PHP_URL_HOST ) ) {
			$targets['wp-content/index.php'] = $content_url;
		}
		$filtered_targets = apply_filters( 'secnin_waf_coverage_probe_targets', $targets );
		if ( is_array( $filtered_targets ) && ! empty( $filtered_targets ) ) {
			$targets = $filtered_targets;
		}
		$attempts = max( 1, min( 3, (int) apply_filters( 'secnin_waf_coverage_probe_attempts', 1 ) ) );

		$results = array();
		$missing = array();
		foreach ( $targets as $label => $url ) {
			$attempt_results = array();
			$target_ok       = true;
			for ( $attempt = 0; $attempt < $attempts; $attempt++ ) {
				$result            = self::http_probe( $url );
				$attempt_results[] = $result;
				if ( empty( $result['ok'] ) || empty( $result['engine_complete'] ) ) {
					$target_ok = false;
				}
			}
			$result['attempts'] = $attempt_results;
			$results[ $label ]  = $result;
			if ( ! $target_ok ) {
				$missing[] = $label;
			}
		}

		return array(
			'root_complete' => ! in_array( 'public front controller', $missing, true ),
			'all_complete'  => empty( $missing ),
			'missing'       => $missing,
			'results'       => $results,
		);
	}

	/**
	 * HTTP probe requiring X-Secnin-Waf marker header when prepend is live.
	 *
	 * @param string $target_url URL to probe. Defaults to home.
	 * @return array{ok:bool,message:string,engine_complete?:bool,hard_fail?:bool}
	 */
	private static function http_probe( $target_url = '' ) {
		$token = function_exists( 'wp_generate_password' ) ? wp_generate_password( 16, false, false ) : uniqid( 'sn', true );
		$key   = Secnin_Waf_Config::ensure_integrity_key();
		if ( '' === $key ) {
			return array(
				'ok'        => false,
				'hard_fail' => true,
				'message'   => __( 'Missing Early Firewall integrity key.', 'security-ninja' ),
			);
		}
		$expected = hash_hmac( 'sha256', $token, $key );

		$url = add_query_arg(
			array(
				'secnin_waf_probe' => rawurlencode( $token ),
				'nocache'          => wp_generate_uuid4(),
			),
			$target_url ? $target_url : home_url( '/' )
		);
		$resp = wp_remote_get(
			$url,
			array(
				'timeout'     => 5,
				'redirection' => 0,
				'sslverify'   => apply_filters( 'https_local_ssl_verify', false ),
				'headers'     => array(
					'Cache-Control' => 'no-cache',
				),
			)
		);

		if ( is_wp_error( $resp ) ) {
			return array(
				'ok'        => false,
				'hard_fail' => true,
				'message'   => $resp->get_error_message(),
			);
		}
		$code = (int) wp_remote_retrieve_response_code( $resp );
		$header = wp_remote_retrieve_header( $resp, 'x-secnin-waf' );
		if ( ! is_string( $header ) || '' === $header || ! hash_equals( $expected, $header ) ) {
			if ( $code >= 500 || 403 === $code ) {
				return array(
					'ok'        => false,
					'hard_fail' => true,
					'message'   => 'HTTP ' . $code,
				);
			}
			// Prepend may not be live yet (user_ini.cache_ttl). Not a hard install failure.
			return array(
				'ok'              => false,
				'hard_fail'       => false,
				'message'         => __( 'Probe response missing Early Firewall marker header (prepend may not be live yet).', 'security-ninja' ),
				'engine_complete' => false,
			);
		}
		$engine   = wp_remote_retrieve_header( $resp, 'x-secnin-waf-engine' );
		$complete = is_string( $engine ) && 'complete' === strtolower( $engine );
		return array(
			'ok'              => true,
			'hard_fail'       => false,
			'message'         => 'HTTP ' . $code,
			'engine_complete' => $complete,
		);
	}
}
