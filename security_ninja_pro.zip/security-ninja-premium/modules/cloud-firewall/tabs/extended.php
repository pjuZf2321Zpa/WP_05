<?php
/**
 * Early Firewall settings UI (Pro only file via @fs_premium_only).
 *
 * @package WPSecurityNinja\Plugin
 */

namespace WPSecurityNinja\Plugin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Human label for Early Firewall mode.
 *
 * @param string $mode Internal mode (legacy|extended).
 * @return string
 */
function wf_sn_cf_early_firewall_mode_label( $mode ) {
	return ( 'extended' === $mode )
		? __( 'Early Firewall', 'security-ninja' )
		: __( 'WordPress hooks', 'security-ninja' );
}

/**
 * Human label for Early Firewall status.
 *
 * @param string $status Internal status.
 * @return string
 */
function wf_sn_cf_early_firewall_status_label( $status ) {
	switch ( $status ) {
		case 'probing':
			return __( 'Probing', 'security-ninja' );
		case 'pending':
			return __( 'Pending', 'security-ninja' );
		case 'partial':
			return __( 'On', 'security-ninja' );
		case 'active':
			return __( 'Active', 'security-ninja' );
		case 'removal_pending':
			return __( 'Removal pending', 'security-ninja' );
		case 'failed_safe':
			return __( 'Failed (safe)', 'security-ninja' );
		case 'failed':
			return __( 'Failed', 'security-ninja' );
		case 'off':
		default:
			return __( 'Off', 'security-ninja' );
	}
}

/**
 * Early Firewall panel UI state (first render + AJAX).
 *
 * @param string|null $message  Override message. Null uses stored hint/status copy.
 * @param bool        $is_error Treat message as an error.
 * @return array<string,mixed>
 */
function wf_sn_cf_early_firewall_panel_ui( $message = null, $is_error = false ) {
	$empty = array(
		'status'           => 'off',
		'mode'             => 'legacy',
		'mode_label'       => wf_sn_cf_early_firewall_mode_label( 'legacy' ),
		'status_label'     => wf_sn_cf_early_firewall_status_label( 'off' ),
		'installed'        => false,
		'show_enable'      => false,
		'show_verify'      => false,
		'show_disable'     => false,
		'verify_label'     => __( 'Verify', 'security-ninja' ),
		'verify_ready'     => true,
		'ready_at'         => 0,
		'message'          => is_string( $message ) ? $message : '',
		'message_is_error' => (bool) $is_error,
		'prepend'          => '',
		'prepend_label'    => '',
		'last_verify'      => '',
		'detail'           => '',
		'detail_label'     => '',
		'eligible'         => false,
		'requires_confirm' => false,
	);

	if ( ! class_exists( __NAMESPACE__ . '\\Secnin_Waf_Extended' ) || ! class_exists( __NAMESPACE__ . '\\Secnin_Waf_Lifecycle' ) ) {
		return $empty;
	}

	$ext         = Secnin_Waf_Extended::get();
	$eligibility = Secnin_Waf_Lifecycle::eligibility();
	$current     = Secnin_Waf_Lifecycle::current_auto_prepend();
	$label       = Secnin_Waf_Lifecycle::label_prepend_path( $current );
	$recovery    = Secnin_Waf_Lifecycle::get_recovery();
	$cf_options  = class_exists( __NAMESPACE__ . '\\wf_sn_cf' ) ? wf_sn_cf::get_options() : array();
	$firewall_on = ! empty( $cf_options['active'] );

	$status             = isset( $ext['status'] ) ? (string) $ext['status'] : 'off';
	$mode               = isset( $ext['mode'] ) ? (string) $ext['mode'] : 'legacy';
	$eligible           = ! empty( $eligibility['ok'] );
	$requires_confirm   = ! empty( $eligibility['requires_confirm_non_waf'] ) || ( ! empty( $label['is_non_waf'] ) && empty( $label['is_ours'] ) );
	$installed          = Secnin_Waf_Extended::is_installed();
	$is_removal_pending = ( 'removal_pending' === $status );
	$is_failed_safe     = ( 'failed_safe' === $status );
	$is_partial         = ( 'partial' === $status );

	$display_status = $status;
	if ( ! $installed && 'legacy' === $mode && 'off' !== $status && 'failed' !== $status && 'failed_safe' !== $status ) {
		$display_status = 'off';
	}

	$status_label = wf_sn_cf_early_firewall_status_label( $display_status );
	if ( 'active' === $display_status && ! $firewall_on ) {
		$status_label = __( 'Installed, firewall disabled', 'security-ninja' );
	}

	$ready_at     = 0;
	$verify_ready = true;
	if ( $is_removal_pending ) {
		$started = ! empty( $recovery['removal_started'] ) ? (int) $recovery['removal_started'] : 0;
		$ttl     = ! empty( $recovery['removal_ttl'] ) ? (int) $recovery['removal_ttl'] : (int) ini_get( 'user_ini.cache_ttl' );
		if ( $ttl <= 0 ) {
			$ttl = 300;
		}
		$ready_at     = $started > 0 ? $started + $ttl : 0;
		$verify_ready = ( 0 === $ready_at ) || time() >= $ready_at;
	}

	$standing = '';
	if ( $is_removal_pending ) {
		$standing = __( 'Early Firewall is turning off. PHP can keep the old setting for a few minutes.', 'security-ninja' );
	} elseif ( $is_partial ) {
		$standing = __( 'Early Firewall is running on regular page views. Other PHP entry points still use the normal firewall.', 'security-ninja' );
	} elseif ( $is_failed_safe && ! empty( $ext['install_error'] ) ) {
		$standing = (string) $ext['install_error'];
		$is_error = true;
	} elseif ( ! empty( $ext['install_hint'] ) ) {
		$standing = (string) $ext['install_hint'];
	}

	if ( null === $message ) {
		$message = $standing;
	} elseif ( $is_removal_pending ) {
		$is_error = false;
	}

	$detail       = '';
	$detail_label = '';
	if ( $is_failed_safe && ! empty( $ext['install_error'] ) ) {
		$detail       = (string) $ext['install_error'];
		$detail_label = __( 'Last error', 'security-ninja' );
	} elseif ( ! $is_partial && ! empty( $ext['last_rollback'] ) ) {
		$detail       = (string) $ext['last_rollback'];
		$detail_label = __( 'Last error', 'security-ninja' );
	}

	$last_verify = '';
	if ( ! empty( $ext['last_verify'] ) ) {
		$last_verify = date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), (int) $ext['last_verify'] );
	}

	return array(
		'status'           => $display_status,
		'mode'             => $mode,
		'mode_label'       => wf_sn_cf_early_firewall_mode_label( $mode ),
		'status_label'     => $status_label,
		'installed'        => $installed,
		'show_enable'      => $eligible && ( ! $installed || $is_failed_safe ) && ! $is_removal_pending,
		'show_verify'      => $installed || $is_removal_pending || $is_failed_safe,
		'show_disable'     => ( $installed || $is_failed_safe ) && ! $is_removal_pending,
		'verify_label'     => $is_removal_pending ? __( 'Verify removal', 'security-ninja' ) : __( 'Verify', 'security-ninja' ),
		'verify_ready'     => $verify_ready,
		'ready_at'         => $ready_at,
		'message'          => (string) $message,
		'message_is_error' => (bool) $is_error,
		'prepend'          => $current ? (string) $current : '',
		'prepend_label'    => ( $current && ! empty( $label['label'] ) ) ? (string) $label['label'] : '',
		'last_verify'      => $last_verify,
		'detail'           => $detail,
		'detail_label'     => $detail_label,
		'eligible'         => $eligible,
		'requires_confirm' => $requires_confirm,
	);
}

/**
 * Render Early Firewall panel.
 *
 * @return void
 */
function wf_sn_cf_render_extended_protection_content() {
	if ( ! class_exists( __NAMESPACE__ . '\\Secnin_Waf_Extended' ) || ! class_exists( __NAMESPACE__ . '\\Secnin_Waf_Lifecycle' ) ) {
		return;
	}

	$ui          = wf_sn_cf_early_firewall_panel_ui();
	$eligibility = Secnin_Waf_Lifecycle::eligibility();
	$current     = $ui['prepend'];
	$label       = Secnin_Waf_Lifecycle::label_prepend_path( $current );
	$profile     = isset( $eligibility['profile'] ) ? $eligibility['profile'] : Secnin_Waf_Lifecycle::detect_server_profile();
	$sapi        = PHP_SAPI;
	$recovery    = Secnin_Waf_Lifecycle::get_recovery();
	$cache_ttl   = (int) ini_get( 'user_ini.cache_ttl' );
	if ( $cache_ttl <= 0 ) {
		$cache_ttl = 300;
	}

	$engine_unhealthy = $ui['installed']
		&& ! empty( $label['is_ours'] )
		&& defined( 'SECNIN_WAF_ATTEMPTED' )
		&& SECNIN_WAF_ATTEMPTED
		&& ( ! defined( 'SECNIN_WAF_ENGINE_COMPLETE' ) || ! SECNIN_WAF_ENGINE_COMPLETE );
	?>
	<tr>
		<td colspan="2">
			<div class="secnin-waf-panel" id="secnin-early-firewall">
			<hr>
			<h3 class="secnin-waf-panel__title"><?php esc_html_e( 'Early Firewall', 'security-ninja' ); ?></h3>
			<p class="description">
				<?php esc_html_e( 'Early Firewall runs before WordPress loads. The normal firewall still covers requests it does not handle.', 'security-ninja' ); ?>
			</p>
			<?php if ( empty( $eligibility['ok'] ) && ! empty( $eligibility['message'] ) ) : ?>
				<div class="notice notice-warning inline"><p><?php echo esc_html( $eligibility['message'] ); ?></p></div>
			<?php elseif ( ! empty( $ui['eligible'] ) && ! empty( $eligibility['message'] ) ) : ?>
				<div class="notice notice-info inline"><p><?php echo esc_html( $eligibility['message'] ); ?></p></div>
			<?php endif; ?>
			<div class="notice notice-error inline" id="secnin-waf-error"<?php echo ( $engine_unhealthy || ( 'failed_safe' === $ui['status'] && '' !== $ui['detail'] ) ) ? '' : ' hidden'; ?>>
				<p>
					<?php
					if ( $engine_unhealthy ) {
						esc_html_e( 'Prepend is present, but the Early Firewall runtime is unhealthy (no valid config or engine did not finish). WordPress-hooks protection remains the fallback.', 'security-ninja' );
					} else {
						echo esc_html( $ui['detail'] );
					}
					?>
				</p>
			</div>

			<table class="secnin-waf-status">
				<tbody>
					<tr>
						<th scope="row"><?php esc_html_e( 'Mode', 'security-ninja' ); ?></th>
						<td>
							<span id="secnin-waf-mode-label"><?php echo esc_html( $ui['mode_label'] ); ?></span>
							<span class="secnin-waf-status__sep">/</span>
							<span id="secnin-waf-status-label"><?php echo esc_html( $ui['status_label'] ); ?></span>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'PHP SAPI', 'security-ninja' ); ?></th>
						<td><code><?php echo esc_html( $sapi ); ?></code> <span class="description">(<?php echo esc_html( $profile ); ?>)</span></td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Admin request prepend', 'security-ninja' ); ?></th>
						<td>
							<code class="secnin-waf-status__path" id="secnin-waf-prepend-path"<?php echo $current ? '' : ' hidden'; ?>><?php echo esc_html( $current ); ?></code>
							<p class="description" id="secnin-waf-prepend-label"<?php echo ( $current && '' !== $ui['prepend_label'] ) ? '' : ' hidden'; ?>><?php echo esc_html( $ui['prepend_label'] ); ?></p>
							<em id="secnin-waf-prepend-empty"<?php echo $current ? ' hidden' : ''; ?>><?php esc_html_e( 'Not set', 'security-ninja' ); ?></em>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'user_ini.cache_ttl', 'security-ninja' ); ?></th>
						<td><?php echo esc_html( (string) $cache_ttl ); ?> <?php esc_html_e( 'seconds', 'security-ninja' ); ?></td>
					</tr>
					<tr id="secnin-waf-last-verify-row"<?php echo '' !== $ui['last_verify'] ? '' : ' hidden'; ?>>
						<th scope="row"><?php esc_html_e( 'Last verify', 'security-ninja' ); ?></th>
						<td id="secnin-waf-last-verify-value"><?php echo esc_html( $ui['last_verify'] ); ?></td>
					</tr>
					<tr id="secnin-waf-detail-row"<?php echo '' !== $ui['detail'] ? '' : ' hidden'; ?>>
						<th scope="row" id="secnin-waf-detail-label"><?php echo esc_html( $ui['detail_label'] ); ?></th>
						<td id="secnin-waf-detail-value"><?php echo esc_html( $ui['detail'] ); ?></td>
					</tr>
					<?php if ( ! empty( $recovery['prior_prepend'] ) ) : ?>
					<tr>
						<th scope="row"><?php esc_html_e( 'Saved prior prepend', 'security-ninja' ); ?></th>
						<td>
							<code class="secnin-waf-status__path"><?php echo esc_html( (string) $recovery['prior_prepend'] ); ?></code>
							<p class="description"><?php esc_html_e( 'Saved for reference in case the previous server configuration needs to be restored.', 'security-ninja' ); ?></p>
						</td>
					</tr>
					<?php endif; ?>
				</tbody>
			</table>

			<p class="secnin-waf-panel__actions">
				<button type="button" class="button sn-cta wf-sn-button" id="secnin-waf-install" data-action="<?php echo $ui['requires_confirm'] ? 'confirm_non_waf' : 'chain'; ?>" data-prepend="<?php echo esc_attr( $current ); ?>"<?php echo $ui['show_enable'] ? '' : ' hidden'; ?>>
					<?php echo $ui['requires_confirm'] ? esc_html__( 'Enable Early Firewall (chain non-WAF prepend)', 'security-ninja' ) : esc_html__( 'Enable Early Firewall', 'security-ninja' ); ?>
				</button>
				<button type="button" class="button button-secondary" id="secnin-waf-verify" data-ready-at="<?php echo esc_attr( (string) (int) $ui['ready_at'] ); ?>"<?php echo $ui['show_verify'] ? '' : ' hidden'; ?><?php echo ( $ui['show_verify'] && ! $ui['verify_ready'] ) ? ' disabled' : ''; ?>>
					<?php echo esc_html( $ui['verify_label'] ); ?>
				</button>
				<button type="button" class="button button-secondary" id="secnin-waf-uninstall"<?php echo $ui['show_disable'] ? '' : ' hidden'; ?>>
					<?php esc_html_e( 'Disable Early Firewall', 'security-ninja' ); ?>
				</button>
				<span class="spinner" id="secnin-waf-spinner" aria-hidden="true"></span>
			</p>
			<?php if ( ! empty( $label['is_competing_waf'] ) || ! empty( $label['is_unknown'] ) ) : ?>
				<p class="description">
					<?php esc_html_e( 'Guided migration: disable the other prepend or security WAF first, confirm auto_prepend_file is clear, then enable Early Firewall here.', 'security-ninja' ); ?>
				</p>
			<?php endif; ?>
			<p class="description" id="secnin-waf-extended-msg" aria-live="polite"<?php echo $ui['message_is_error'] ? ' style="color:#b32d2e"' : ''; ?>><?php echo esc_html( $ui['message'] ); ?></p>
			</div>
		</td>
	</tr>
	<?php
}
