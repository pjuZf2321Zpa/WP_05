<?php
/**
 * Cloud Firewall Settings
 *
 * This file contains the settings form content for the Cloud Firewall module.
 * Extracted from cloud-firewall.php to reduce file size and improve maintainability.
 */

namespace WPSecurityNinja\Plugin;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Ensure we have access to the main class
if ( ! class_exists( 'Wf_sn_cf' ) ) {
	return;
}

/**
 * Render visitor IP source control and preview (free feature).
 *
 * @param array<string,mixed> $options Firewall options.
 * @return void
 */
function wf_sn_cf_render_ip_source_settings( $options ) {
	$ip_source        = isset( $options['ip_source'] ) ? \WPSecurityNinja\Plugin\wf_sn_cf::normalize_ip_source( $options['ip_source'] ) : 'auto';
	$ip_preview       = \WPSecurityNinja\Plugin\wf_sn_cf::get_ip_source_preview();
	$active_ip        = \WPSecurityNinja\Plugin\wf_sn_cf::get_user_ip();
	$ip_source_labels = array(
		'auto'             => array(
			'title' => __( 'Automatic (recommended)', 'security-ninja' ),
			'desc'  => __( 'Use Cloudflare or your trusted proxy headers only when REMOTE_ADDR matches a known proxy range.', 'security-ninja' ),
		),
		'remote_addr'      => array(
			'title' => __( 'REMOTE_ADDR only', 'security-ninja' ),
			'desc'  => __( 'Direct connection. Most secure on origin-only hosts.', 'security-ninja' ),
		),
		'cf_connecting_ip' => array(
			'title' => 'Cloudflare CF-Connecting-IP',
			'desc'  => __( 'Use the Cloudflare visitor header only when REMOTE_ADDR is a Cloudflare IP. Falls back to REMOTE_ADDR otherwise.', 'security-ninja' ),
		),
		'x_forwarded_for'  => array(
			'title' => 'X-Forwarded-For',
			'desc'  => __( 'Uses the first valid IP in X-Forwarded-For (comma-separated lists are parsed safely), only when the connection is from a private/local proxy, Cloudflare, or a Trusted proxy CIDR. Otherwise falls back to REMOTE_ADDR. If a public load balancer shows as every visitor, add its IP under Trusted proxy CIDRs.', 'security-ninja' ),
		),
		'x_real_ip'        => array(
			'title' => 'X-Real-IP',
			'desc'  => __( 'Trust X-Real-IP only when the connection is from a private/local proxy, Cloudflare, or a Trusted proxy CIDR. Falls back to REMOTE_ADDR. If a public load balancer shows as every visitor, add its IP under Trusted proxy CIDRs.', 'security-ninja' ),
		),
	);
	$current_desc     = isset( $ip_source_labels[ $ip_source ]['desc'] ) ? $ip_source_labels[ $ip_source ]['desc'] : '';
	$trusted_cidrs    = isset( $options['trusted_proxy_cidrs'] ) ? \WPSecurityNinja\Plugin\wf_sn_cf::sanitize_trusted_proxy_cidrs( $options['trusted_proxy_cidrs'] ) : array();
	$trusted_max      = \WPSecurityNinja\Plugin\Wf_sn_cf_Utils::MAX_TRUSTED_PROXY_CIDRS;
	$trusted_count    = count( $trusted_cidrs );
	?>
	<tr valign="top">
		<th scope="row">
			<label for="wf_sn_cf_ip_source"><?php esc_html_e( 'Visitor IP detection', 'security-ninja' ); ?></label>
			<p class="description"><?php esc_html_e( 'How the firewall resolves visitor IPs for bans, whitelists, and logging.', 'security-ninja' ); ?></p>
		</th>
		<td class="sn-cf-options sn-cf-ip-source-cell">
			<select id="wf_sn_cf_ip_source" class="regular-text" name="<?php echo esc_attr( WF_SN_CF_OPTIONS_KEY ); ?>[ip_source]">
				<?php foreach ( $ip_source_labels as $mode => $label ) : ?>
					<?php
					$preview_ip   = ! empty( $ip_preview[ $mode ] ) ? (string) $ip_preview[ $mode ] : '';
					$option_label = $label['title'];
					if ( '' !== $preview_ip ) {
						/* translators: 1: IP source label, 2: preview IP for this request */
						$option_label = sprintf( __( '%1$s (%2$s)', 'security-ninja' ), $label['title'], $preview_ip );
					}
					?>
					<option
						value="<?php echo esc_attr( $mode ); ?>"
						data-desc="<?php echo esc_attr( $label['desc'] ); ?>"
						<?php selected( $ip_source, $mode ); ?>
					><?php echo esc_html( $option_label ); ?></option>
				<?php endforeach; ?>
			</select>
			<p class="description sn-cf-ip-source-help" id="wf_sn_cf_ip_source_desc"><?php echo esc_html( $current_desc ); ?></p>
			<p class="description sn-cf-ip-source-current-line">
				<?php esc_html_e( 'Your IP with current setting:', 'security-ninja' ); ?>
				<code><?php echo esc_html( false !== $active_ip ? $active_ip : __( 'unknown', 'security-ninja' ) ); ?></code>
			</p>
			<details class="sn-cf-ip-source-preview-details">
				<summary><?php esc_html_e( 'Preview all methods', 'security-ninja' ); ?></summary>
				<table class="widefat striped sn-cf-ip-source-preview-table">
					<thead>
						<tr>
							<th scope="col"><?php esc_html_e( 'Method', 'security-ninja' ); ?></th>
							<th scope="col"><?php esc_html_e( 'Would resolve to', 'security-ninja' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $ip_source_labels as $mode => $label ) : ?>
							<tr<?php echo $ip_source === $mode ? ' class="is-selected"' : ''; ?>>
								<td><?php echo esc_html( $label['title'] ); ?></td>
								<td><code><?php echo esc_html( ! empty( $ip_preview[ $mode ] ) ? $ip_preview[ $mode ] : '—' ); ?></code></td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</details>
		</td>
	</tr>
	<tr valign="top">
		<th scope="row">
			<label for="wf_sn_cf_trusted_proxy_cidrs"><?php esc_html_e( 'Trusted proxy CIDRs', 'security-ninja' ); ?></label>
			<p class="description"><?php esc_html_e( 'Used in Automatic mode when your site sits behind a load balancer or reverse proxy (not Cloudflare).', 'security-ninja' ); ?></p>
		</th>
		<td class="sn-cf-options">
			<textarea id="wf_sn_cf_trusted_proxy_cidrs" class="large-text code" rows="4" name="<?php echo esc_attr( WF_SN_CF_OPTIONS_KEY ); ?>[trusted_proxy_cidrs]"><?php echo esc_textarea( implode( "\n", $trusted_cidrs ) ); ?></textarea>
			<p class="description">
				<?php
				printf(
					/* translators: 1: current count, 2: maximum allowed */
					esc_html__( 'One CIDR or IP per line. %1$d / %2$d entries. Add only your proxy egress IPs, never public ranges like 0.0.0.0/0.', 'security-ninja' ),
					(int) $trusted_count,
					(int) $trusted_max
				);
				?>
			</p>
		</td>
	</tr>
	<?php
}

/**
 * Render the settings form content
 *
 * @param array $options Current options
 * @param array $ips IP information
 */
function wf_sn_cf_render_settings_content( $options, $ips = array() ) {
	?>

<table class="form-table">
					<tbody>
						<tr>
							<td colspan="2">
								<h2><?php esc_html_e( 'Firewall Settings', 'security-ninja' ); ?></h2>
							</td>
						</tr>
						<?php

						// Free feature: 8G Firewall Rules
						echo '<tr valign="top"><th scope="row"><label for="wf_sn_cf_filterqueries"><h3>' . esc_html__( 'Filter Suspicious Queries', 'security-ninja' ) . '</h3>';
						echo '<p class="description">' . esc_html__( 'Block suspicious page requests and malicious query strings using the proven 8G Firewall rules.', 'security-ninja' ) . '</p>';
						echo '<p class="description">' . esc_html__( 'Based on the excellent 8G Firewall by Jeff Starr from Perishable Press. This protection filters out dangerous requests including SQL injections, XSS attacks, and other malicious patterns.', 'security-ninja' ) . '</p>';
						echo '<p class="description">' . esc_html__( 'Blocks suspicious page requests and malicious query strings using the proven 8G Firewall rules (URI, query string, user agent, and referrer). Hostname reverse-DNS checks are off by default and are not required for this protection.', 'security-ninja' ) . '</p></label></th>';
						echo '</th><td class="sn-cf-options">';

						\WPSecurityNinja\Plugin\Utils::create_toggle_switch(
							WF_SN_CF_OPTIONS_KEY . '_filterqueries',
							array(
								'saved_value' => $options['filterqueries'],
								'option_key'  => WF_SN_CF_OPTIONS_KEY . '[filterqueries]',
							)
						);

						echo '</td></tr>';

						// Pro features - show unified marketing info box for free users (Freemius: do not use negation of can_use_premium_code__premium_only)
						$show_pro_upsell = true;
						if ( secnin_fs()->can_use_premium_code__premium_only() ) {
							$show_pro_upsell = false;
						}
						if ( $show_pro_upsell ) {
							wf_sn_cf_render_ip_source_settings( $options );
						}
						if ( $show_pro_upsell ) :
							?>

						<tr>
							<td colspan="2">
								<div class="sncard infobox">
									<div class="inner">
										<h3>Upgrade to Pro for Advanced Firewall Features</h3>
										<p>The free version provides basic firewall protection with 8G rules. Upgrade to Security Ninja Pro to unlock powerful advanced features:</p>
										<ul style="list-style: disc; margin-left: 20px; margin-top: 10px;">
											<li>Control how banned IPs are handled - block completely or only from login</li>
											<li>Cloud Firewall with 600+ million known bad IPs, automatically updated</li>
											<li>Participate in global IP threat network and share threat intelligence</li>
											<li>Block entire countries from accessing your website</li>
											<li>Customize messages shown to blocked visitors</li>
											<li>Redirect blocked visitors to any URL using 301 redirects</li>
										</ul>
										<p style="margin-top: 15px;">
											<a href="<?php echo esc_url( \WPSecurityNinja\Plugin\Utils::generate_sn_web_link( 'firewall_upgrade', '/upgrade/' ) ); ?>" class="button button-primary button-small" target="_blank" rel="noopener"><?php esc_html_e( 'Upgrade to Pro', 'security-ninja' ); ?></a>
										</p>
									</div>
								</div>
							</td>
						</tr>

							<?php
						endif;
						if ( ! $show_pro_upsell ) {
							// Premium users see full functionality
							$options = \WPSecurityNinja\Plugin\wf_sn_cf::get_options();
							?>

						<tr>
							<td colspan="2"><hr></td>
						</tr>

						<tr valign="top">
							<th scope="row">
								<label for="wf_sn_cf_global">
									<h3><?php esc_html_e( 'Prevent Banned IPs from Accessing the Site', 'security-ninja' ); ?></h3>
									<p class="description"><?php esc_html_e( 'If set to ON cloud and local firewall will prevent banned IPs from accessing the site all together.', 'security-ninja' ); ?></p>
									<p class="description"><?php esc_html_e( 'If set to OFF they will not be able to log in, but will be able to view the site.', 'security-ninja' ); ?></p>
								</label>
							</th>
							<td class="sn-cf-options">
								<?php
								\WPSecurityNinja\Plugin\Utils::create_toggle_switch(
									WF_SN_CF_OPTIONS_KEY . '_global',
									array(
										'saved_value' => $options['global'],
										'option_key'  => WF_SN_CF_OPTIONS_KEY . '[global]',
									)
								);
								?>
							</td>
						</tr>

						<tr valign="top">
							<th scope="row">
								<label for="wf_sn_cf_usecloud">
									<h3><?php esc_html_e( 'Cloud Firewall', 'security-ninja' ); ?></h3>
									<p class="description"><?php esc_html_e( 'The list of 600+ million IPs can sometimes block traffic that should not be blocked. Use this to turn off this feature.', 'security-ninja' ); ?></p>
									<?php
									if ( 1 === wf_sn_cf::is_active() ) {
										if ( isset( $ips['timestamp'] ) ) {
											?>
											<p>
												<?php
												printf(
													/* translators: %s: number of bad IPs blocked (may be wrapped in <strong>) */
													esc_html__( '%s bad IPs blocked from logging in.', 'security-ninja' ),
													'<strong>' . esc_html( number_format_i18n( isset( $ips['total'] ) ? $ips['total'] : 0 ) ) . '</strong>'
												);
												?>
											</p>
											<p><small>
													<?php
													printf(
														/* translators: 1: formatted date/time of last update, 2: human-readable time difference (e.g. "2 hours ago") */
														esc_html__( 'List last updated %1$s (%2$s)', 'security-ninja' ),
														esc_html( date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $ips['timestamp'] ) ),
														esc_html( human_time_diff( $ips['timestamp'], current_time( 'timestamp' ) ) . ' ' . esc_html__( 'ago', 'security-ninja' ) )
													);
													?>
												</small></p>
											<?php
										}
									}
									?>
								</label>
							</th>
							<td class="sn-cf-options">
								<?php
								\WPSecurityNinja\Plugin\Utils::create_toggle_switch(
									WF_SN_CF_OPTIONS_KEY . '_usecloud',
									array(
										'saved_value' => $options['usecloud'],
										'option_key'  => WF_SN_CF_OPTIONS_KEY . '[usecloud]',
									)
								);
								?>
							</td>
						</tr>

						<tr valign="top">
							<th scope="row">
								<label for="wf_sn_cf_globalbannetwork">
									<h3><?php esc_html_e( 'Block IP Network', 'security-ninja' ); ?></h3>
									<p class="description"><?php esc_html_e( 'Participate in the global bad IP network. Submit hack attempts to central database.', 'security-ninja' ); ?></p>
								</label>
							</th>
							<td class="sn-cf-options globalbannetwork">
								<?php
								\WPSecurityNinja\Plugin\Utils::create_toggle_switch(
									WF_SN_CF_OPTIONS_KEY . '_globalbannetwork',
									array(
										'saved_value' => $options['globalbannetwork'],
										'option_key'  => WF_SN_CF_OPTIONS_KEY . '[globalbannetwork]',
									)
								);
								?>
							</td>
						</tr>

						<tr>
							<td colspan="2"><hr></td>
						</tr>

						<?php wf_sn_cf_render_ip_source_settings( $options ); ?>

						<tr>
							<td colspan="2"><hr></td>
						</tr>

							<?php
							echo '<tr valign="top"><th scope="row"><h3>' . esc_html__( 'Block visits from these countries', 'security-ninja' ) . '</h3>';
							?>
						<p class="description"><?php esc_html_e( 'Choose the countries you want to block.', 'security-ninja' ); ?></p>
						<p class="description">
							<?php esc_html_e( 'Be careful not to block USA if you depend on traffic from Google as Google crawls your website from USA.', 'security-ninja' ); ?>
						</p>
							<?php
							echo '</th><td></td></tr>';

							echo '<tr><td class="fullwidth" colspan="2">';

							$geoip_countrylist = \WPSecurityNinja\Plugin\Utils::get_country_list();
							$blocked_countries = \WPSecurityNinja\Plugin\wf_sn_cf::get_blocked_countries();
							// Sentinel: HTML multi-select with zero selections sends no blocked_countries keys; sanitize_settings uses this to persist [].
							// blocked_countries_confirm_all stays 0 until Select All is confirmed in wf-sn-cf.js.
							?>
						<input type="hidden" name="wf_sn_cf[blocked_countries_present]" value="1" />
						<input type="hidden" name="wf_sn_cf[blocked_countries_confirm_all]" id="wf_sn_cf_blocked_countries_confirm_all" value="0" />
						<select name="wf_sn_cf[blocked_countries][]" id="wf_sn_cf_blocked_countries" multiple="multiple" style="width:100%;" class="">
							<?php
							if ( $geoip_countrylist ) {
								foreach ( $geoip_countrylist as $key => $gc ) {
									$selected = in_array( $key, $blocked_countries, true ) ? ' selected="selected" ' : '';
									?>
									<option value="<?php echo esc_attr( $key ); ?>" <?php echo esc_attr( $selected ); ?>><?php echo esc_html( $gc . ' (' . $key . ')' ); ?></option>
									<?php
								}
							}
							?>
						</select>
						<button type="button" id="select_all_countries" class="button button-secondary button-small alignright"><?php esc_html_e( 'Select All', 'security-ninja' ); ?></button>
						<button type="button" id="select_no_countries" class="button button-secondary button-small alignright"><?php esc_html_e( 'Select None', 'security-ninja' ); ?></button>
						</td>
						</tr>
						<tr valign="top">
							<th scope="row">
								<label for="wf_sn_cf_countryblock_loginonly">
								<h3><?php esc_html_e( 'Only block these countries from login functionality', 'security-ninja' ); ?></h3>
									<p class="description"><?php esc_html_e( 'For example, if you block a particular country, users from that country will not be able to log in, but will be able to view the site.', 'security-ninja' ); ?></p>
									<p class="description"><?php esc_html_e( 'Full-site country blocking is controlled by this toggle. The "Prevent Banned IPs from Accessing the Site" setting above applies to IP and cloud bans, not country rules.', 'security-ninja' ); ?></p>
									<p class="description"><?php esc_html_e( 'For more login protection, check out the tab "Login Protection".', 'security-ninja' ); ?></p>
								</label>
							</th>
							<td class="sn-cf-options">
								<?php
								\WPSecurityNinja\Plugin\Utils::create_toggle_switch(
									WF_SN_CF_OPTIONS_KEY . '_countryblock_loginonly',
									array(
										'saved_value' => $options['countryblock_loginonly'],
										'option_key'  => WF_SN_CF_OPTIONS_KEY . '[countryblock_loginonly]',
									)
								);
								?>
							</td>
						</tr>

						<tr>
							<td colspan="2"><hr></td>
						</tr>
						<tr valign="top">
							<th scope="row">
								<label for="wf_sn_cf_satellite_soft_enabled">
									<h3><?php esc_html_e( 'Satellite ISP softening (ASN)', 'security-ninja' ); ?></h3>
									<p class="description"><?php esc_html_e( 'Reduce false blocks on satellite connections (e.g. Starlink) by detecting the ISP autonomous system number (ASN). When matched, country blocking and cloud reputation lists may be softened, not manual blocks, login/brute-force limits, or suspicious-request filtering.', 'security-ninja' ); ?></p>
								</label>
							</th>
							<td class="sn-cf-options">
								<?php
								$satellite_on = isset( $options['satellite_soft_enabled'] ) ? $options['satellite_soft_enabled'] : 1;
								\WPSecurityNinja\Plugin\Utils::create_toggle_switch(
									WF_SN_CF_OPTIONS_KEY . '_satellite_soft_enabled',
									array(
										'saved_value' => $satellite_on,
										'option_key'  => WF_SN_CF_OPTIONS_KEY . '[satellite_soft_enabled]',
									)
								);
								?>
								<p class="description" style="margin-top:10px;">
									<label for="wf_sn_cf_satellite_soft_asns"><?php esc_html_e( 'ASN numbers to treat as satellite/residential (comma or space separated). Default includes Starlink (14593).', 'security-ninja' ); ?></label>
								</p>
								<?php
								$asns = isset( $options['satellite_soft_asns'] ) && is_array( $options['satellite_soft_asns'] ) ? $options['satellite_soft_asns'] : array( '14593' );
								?>
								<input type="text" class="regular-text" id="wf_sn_cf_satellite_soft_asns" name="<?php echo esc_attr( WF_SN_CF_OPTIONS_KEY ); ?>[satellite_soft_asns]" value="<?php echo esc_attr( implode( ', ', array_map( 'strval', $asns ) ) ); ?>" />
								<p class="description"><?php esc_html_e( 'ASN is resolved on demand when a visitor would otherwise be blocked by country or cloud reputation, then cached per IP.', 'security-ninja' ); ?></p>
							</td>
						</tr>

							<?php
							echo '<tr valign="top">
					<th scope="row"><label for="wf_sn_cf_message"><h3>' . esc_html__( 'Message for blocked IPs', 'security-ninja' ) . '</h3>';
							echo '<p class="description">' . esc_html__( 'Message shown to blocked visitors when they try to access the site or log in.', 'security-ninja' ) . '</p>';
							echo '</label></th></tr>';

							echo '<tr><td class="fullwidth" colspan="2"><textarea id="wf_sn_cf_message" name="' . esc_attr( WF_SN_CF_OPTIONS_KEY ) . '[message]" rows="3" cols="50">' . esc_textarea( $options['message'] ) . '</textarea></td></tr>';
							?>
						<tr>
							<td colspan="2"><?php esc_html_e( 'Or you can redirect blocked visitors', 'security-ninja' ); ?>:</td>
						</tr>
							<?php
							echo '<tr valign="top"><th scope="row"><label for="wf-cf-redirect-url"><h3>' . esc_html__( 'Redirect blocked visitors', 'security-ninja' ) . '</h3>';
							echo '<p class="description">' . esc_html__( '301 redirect blocked visitors to any URL. Leave empty to show message instead.', 'security-ninja' ) . '</p>';
							echo '</label></th><td></td></tr>';
							echo '<tr><td class="fullwidth" colspan="2">';
							echo '<input type="text" placeholder="https://" class="regular-text" value="' . esc_attr( $options['redirect_url'] ) . '" id="wf-cf-redirect-url" name="' . esc_attr( WF_SN_CF_OPTIONS_KEY ) . '[redirect_url]">';
							echo '</td></tr>';
							?>
							<?php
						} // End premium content block

						if ( secnin_fs()->can_use_premium_code__premium_only() ) {
							$installer_file = WF_SN_PLUGIN_DIR . 'modules/cloud-firewall/waf/class-secnin-waf-installer.php';
							$extended_file  = WF_SN_PLUGIN_DIR . 'modules/cloud-firewall/tabs/extended.php';
							if ( is_readable( $installer_file ) ) {
								require_once $installer_file;
							}
							if ( is_readable( $extended_file ) ) {
								require_once $extended_file;
								if ( function_exists( __NAMESPACE__ . '\\wf_sn_cf_render_extended_protection_content' ) ) {
									wf_sn_cf_render_extended_protection_content();
								}
							}
						}
						?>
					</tbody>
				</table>
	<?php
}
