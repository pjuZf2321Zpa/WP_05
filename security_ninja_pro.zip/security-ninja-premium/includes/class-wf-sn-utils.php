<?php


namespace WPSecurityNinja\Plugin;

use Wf_Sn;

if ( ! defined( 'ABSPATH' ) ) {
	die;
}

class Utils {



	/**
	 * Filters out any Freemius admin notices
	 *
	 * @author Lars Koudal
	 * @author Unknown
	 * @since v0.0.1
	 * @version v1.0.0 Wednesday, January 13th, 2021.
	 * @version v1.0.1 Thursday, July 10th, 2025.
	 * @access public static
	 * @param mixed $show
	 * @param mixed $msg
	 * @return mixed
	 */
	public static function do_filter_show_admin_notice( $show, $msg ) {
		if ( secnin_fs()->can_use_premium_code__premium_only() ) {
			include_once WF_SN_PLUGIN_DIR . 'modules/whitelabel/class-wf-sn-wl.php';
			if ( class_exists( __NAMESPACE__ . '\Wf_Sn_Wl' ) ) {
				if ( \WPSecurityNinja\Plugin\Wf_Sn_Wl::is_active() ) {
					return false;
				}
			}
		}
		return $show;
	}

	/**
	 * Plugin display name for UI and AI prompts (white label name when active).
	 *
	 * @return string
	 */
	public static function get_branded_plugin_name() {
		$name = 'Security Ninja';
		if ( secnin_fs()->is__premium_only() ) {
			if ( class_exists( __NAMESPACE__ . '\Wf_Sn_Wl' ) ) {
				if ( \WPSecurityNinja\Plugin\Wf_Sn_Wl::is_active() ) {
					$name = \WPSecurityNinja\Plugin\Wf_Sn_Wl::get_new_name();
				}
			}
		}
		return $name;
	}

	/**
	 * Public base URL for malware / vuln definition files (no trailing slash).
	 *
	 * Stable hostname: Cloudflare Worker proxies to the current Spaces CDN origin.
	 *
	 * @return string
	 */
	public static function get_definitions_cdn_base() {
		return 'https://defs.wpsecurityninja.com';
	}

	/**
	 * Absolute URL for a definitions CDN object key.
	 *
	 * @param string $object Object key, e.g. samples.json.
	 * @return string
	 */
	public static function get_definitions_cdn_url( $object ) {
		$object = ltrim( (string) $object, '/' );
		return self::get_definitions_cdn_base() . '/' . $object;
	}

	/**
	 * Whether a PHP ini directive is enabled (on/true/1).
	 *
	 * Handles string values such as "Off" and "On" that are truthy in PHP
	 * but mean disabled/enabled respectively.
	 *
	 * @param string $directive Ini directive name.
	 * @return bool
	 */
	public static function ini_is_enabled( $directive ) {
		$value = ini_get( $directive );

		if ( false === $value || '' === $value ) {
			return false;
		}

		$normalized = strtolower( trim( (string) $value ) );

		if ( in_array( $normalized, array( '0', 'off', 'false', 'no', 'none' ), true ) ) {
			return false;
		}

		if ( in_array( $normalized, array( '1', 'on', 'true', 'yes' ), true ) ) {
			return true;
		}

		// Unknown non-empty value: treat as enabled (conservative for security tests).
		return true;
	}





	/**
	 * Do admin notices
	 *
	 * @author  Lars Koudal
	 * @since   v0.0.1
	 * @version v1.0.0  Tuesday, January 12th, 2021.
	 * @version v1.0.1  Tuesday, March 22nd, 2022.
	 * @access  public static
	 * @return  void
	 */
	public static function do_admin_notices() {
		$is_sn_admin_page = \WPSecurityNinja\Plugin\Wf_Sn::is_plugin_page();
		$current_screen   = get_current_screen();
		if ( ! $is_sn_admin_page ) {
			return;
		}

		$wf_sn_vu_vulns_notice = get_option( 'wf_sn_vu_vulns_notice', false );

		if ( isset( $wf_sn_vu_vulns_notice ) && ( $wf_sn_vu_vulns_notice ) && ( '' !== $wf_sn_vu_vulns_notice ) ) {
			$current_screen = get_current_screen();
			// Lets not show on the wizard page
			if ( strpos( $current_screen->id, 'page_security-ninja-wizard' ) === false ) {
				?>
				<div class="notice notice-info is-dismissible secnin-notice">
					<h3><?php esc_html_e( 'Security Ninja - Vulnerability list updated!', 'security-ninja' ); ?></h3>
					<p><?php echo esc_html( $wf_sn_vu_vulns_notice ); ?></p>
				</div>
				<?php
				delete_option( 'wf_sn_vu_vulns_notice' );
			}
		}

		if ( secnin_fs()->can_use_premium_code__premium_only() ) {
			self::maybe_show_early_firewall_notice();
		}

		$review = get_option( 'wf_sn_review_notice' );
		$time   = time();
		$load   = false;

		if ( ! $review ) {
			$review = array(
				'time'      => $time,
				'dismissed' => false,
			);
			$load   = true;
		} elseif ( ( isset( $review['dismissed'] ) && ! $review['dismissed'] )
			&& ( isset( $review['time'] ) && ( $review['time'] <= $time ) )
		) {
			$load = true;
		}

		// Hvis vi skal vise den igen
		if ( isset( $review['time'] ) ) {
			if ( $time > $review['time'] ) {
				// Vi kan godt vise den igen
				$load = true;
			}
		}

		if ( ! $load ) {
			return;
		}
		// Update the review option now.
		update_option( 'wf_sn_review_notice', $review, false );
		$current_user = wp_get_current_user();
		$fname        = '';
		if ( ! empty( $current_user->user_firstname ) ) {
			$fname = $current_user->user_firstname;
		}

		if ( function_exists( '\\WPSecurityNinja\\Plugin\\secnin_fs' ) ) {
			if ( secnin_fs()->is_registered() ) {
				$get_user = secnin_fs()->get_user();
				$fname    = $get_user->first;
			}
		}

		// We have a candidate! Output a review message.

		$timeused = __( 'a while', 'security-ninja' );

		$options = \WPSecurityNinja\Plugin\Wf_Sn::$options;

		if ( isset( $options['first_install'] ) && is_numeric( $options['first_install'] ) ) {
			$first_install = intval( $options['first_install'] );
			$timeused      = human_time_diff( $first_install, time() );
		}

		$current_screen = get_current_screen();
		// Lets not show on the wizard page
		if ( false !== strpos( $current_screen->id, 'page_security-ninja-wizard' ) ) {
			return;
		}
		?>
		<div class="notice notice-info is-dismissible wfsn-review-notice">
			<p>Hey <?php echo esc_html( $fname ); ?>, I noticed you have been using Security Ninja for
				<?php echo esc_html( $timeused ); ?> - that's awesome!</p>
			<p>Could you please do us a BIG favor and give it a 5-star rating on WordPress to help us spread the word?</p>
			<p>Thank you :-)</p>
			<p><strong>Lars Koudal,</br>wpsecurityninja.com</strong></p>
			<p>
			<ul>
				<li><a href="https://wordpress.org/support/plugin/security-ninja/reviews/?filter=5#new-post" class="wfsn-dismiss-review-notice wfsn-reviewlink button-primary" target="_blank" rel="noopener">Ok, you deserve
						it</a></li>
				<li><span class="dashicons dashicons-calendar"></span><a href="#" class="wfsn-dismiss-review-notice" target="_blank" rel="noopener">Nope, maybe later</a></li>
				<li><span class="dashicons dashicons-smiley"></span><a href="#" class="wfsn-dismiss-review-notice" target="_blank" rel="noopener">I already did</a></li>
			</ul>
			<p><small>This notice is shown every 30 days.</small></p>
		</div>
		<?php
	}


	/**
	 * signup_to_newsletter.
	 *
	 * @author  Lars Koudal
	 * @author  Unknown
	 * @since   v0.0.1
	 * @version v1.0.0  Wednesday, September 1st, 2021.
	 * @version v1.0.1  Thursday, March 3rd, 2022.
	 * @access  public static
	 * @return  void
	 */
	public static function signup_to_newsletter() {
		// Only show on SN pages
		$is_sn_admin_page = \WPSecurityNinja\Plugin\Wf_Sn::is_plugin_page();
		if ( ! $is_sn_admin_page ) {
			return;
		}

		$current_screen = get_current_screen();
		// Lets not show on the wizard page
		if ( false !== strpos( $current_screen->id, 'page_security-ninja-wizard' ) ) {
			return;
		}

		// Check if been dismissed already
		$review = get_option( 'wf_sn_review_notice' );
		if ( $review && isset( $review['dismissed'] ) && ( $review['dismissed'] ) ) {
			return;
		}

		if ( secnin_fs()->can_use_premium_code__premium_only() ) {
			// We do not show for customers
			return;
		}

		$current_user = wp_get_current_user();
		$admin_name   = $current_user->user_firstname;

		if ( $current_user->user_lastname ) {
			$admin_name .= ' ' . $current_user->user_lastname;
		}

		if ( \PAnD::is_admin_notice_active( 'wfs-newsletter-30' ) ) {
			?>
			<div data-dismissible="wfs-newsletter-30" class="secnin-notice sncard is-dismissible snnotice">
				<h3>Get WordPress Security Updates & Exclusive Deals</h3>
				<h4>Join 10,000+ WordPress admins getting critical security alerts, pro tips, and special offers directly in their inbox from wpsecurityninja.com</h4>
				<form class="ml-block-form" action="https://assets.mailerlite.com/jsonp/16490/forms/106309154087372203/subscribe" data-code="" method="post" target="_blank">
					<table>
						<tbody>
							<tr>
								<td>
									<input type="text" class="regular-text" data-inputmask="" name="fields[name]" placeholder="Your name" autocomplete="name" style="width:15em;" value="<?php echo esc_html( $current_user->display_name ); ?>" required="required">
								</td>
								<td>
									<input aria-label="email" aria-required="true" data-inputmask="" type="email" class="regular-text required email" data-inputmask="" name="fields[email]" placeholder="Your email" autocomplete="email" style="width:15em;" value="<?php echo esc_html( $current_user->user_email ); ?>" required="required">
								</td>
								<td>
									<button type="submit" class="button button-primary button-small">Subscribe</button>
								</td>
							</tr>
					</table>
					<input type="hidden" name="fields[signupsource]" value="Security Ninja Plugin <?php echo esc_attr( self::get_plugin_version() ); ?>">
					<input type="hidden" name="ml-submit" value="1">
					<input type="hidden" name="anticsrf" value="true">
				</form>


				<p>You can unsubscribe anytime. For more details, review our <a href="<?php echo esc_url( self::generate_sn_web_link( 'newsletter_signup', '/privacy-policy/' ) ); ?>" target="_blank" rel="noopener">Privacy Policy</a>.</p>
				<p><small>Signup form is shown every 30 days.</small> - <a href="javascript:;" class="dismiss-this">Click here to dismiss</a></p>
			</div>
			<?php
		}
	}

	/**
	 * Dismissible Pro notice: Early Firewall available on existing sites (not auto-install).
	 *
	 * @return void
	 */
	public static function maybe_show_early_firewall_notice() {
		$current_screen = get_current_screen();
		if ( ! $current_screen || false !== strpos( (string) $current_screen->id, 'page_security-ninja-wizard' ) ) {
			return;
		}

		// Existing site only: firewall options already stored (updates), not a brand-new empty install.
		$stored_cf = get_option( 'wf_sn_cf', null );
		if ( null === $stored_cf || false === $stored_cf ) {
			return;
		}

		if ( class_exists( __NAMESPACE__ . '\\Secnin_Waf_Extended' ) && Secnin_Waf_Extended::is_installed() ) {
			return;
		}

		if ( ! class_exists( '\\PAnD' ) || ! \PAnD::is_admin_notice_active( 'secnin-early-firewall-notice-forever' ) ) {
			return;
		}

		$settings_url = admin_url( 'admin.php?page=wf-sn#secnin-early-firewall' );
		?>
		<div data-dismissible="secnin-early-firewall-notice-forever" class="notice notice-info is-dismissible secnin-notice">
			<p>
				<strong><?php esc_html_e( 'Early Firewall is available', 'security-ninja' ); ?></strong>
				<?php esc_html_e( 'It can run the firewall before WordPress loads. Optional, and this setting stays on this site only.', 'security-ninja' ); ?>
				<a href="<?php echo esc_url( $settings_url ); ?>"><?php esc_html_e( 'Open Firewall settings', 'security-ninja' ); ?></a>
			</p>
		</div>
		<?php
	}

	/**
	 * Add last login column
	 *
	 * @author  Unknown
	 * @since   v0.0.1
	 * @version v1.0.0  Tuesday, August 1st, 2023.
	 * @access  public static
	 * @param   mixed $columns
	 * @return  mixed
	 */
	public static function add_user_last_login_column( $columns ) {
		$columns['secnin_last_login'] = __( 'Last Login', 'security-ninja' );
		return $columns;
	}



	/**
	 * return_last_login_column.
	 *
	 * @author  Unknown
	 * @since   v0.0.1
	 * @version v1.0.0  Tuesday, August 1st, 2023.
	 * @access  public static
	 * @param   mixed $output
	 * @param   mixed $column_id
	 * @param   mixed $user_id
	 * @return  mixed
	 */
	public static function return_last_login_column( $output, $column_id, $user_id ) {
		if ( 'secnin_last_login' !== $column_id ) {
			return $output;
		}

		$current_time = current_time( 'timestamp' );

		$last_login = get_user_meta( $user_id, 'sn_last_login', true );
		if ( $last_login ) {
			$last_login_timestamp = strtotime( $last_login );
			if ( $last_login_timestamp <= $current_time ) {
				$human_time    = human_time_diff( $last_login_timestamp, $current_time ) . ' ago';
				$friendly_date = date_i18n( get_option( 'date_format' ) . ' - ' . get_option( 'time_format' ), $last_login_timestamp );
				return $human_time . '<br><small>' . $friendly_date . '</small>';
			}
		} else {
			$session_tokens = get_user_meta( $user_id, 'session_tokens', true );
			if ( $session_tokens && is_array( $session_tokens ) ) {
				foreach ( $session_tokens as $stok ) {
					if ( isset( $stok['login'] ) && is_numeric( $stok['login'] ) && ( $stok['login'] <= $current_time ) ) {
						$human_time    = human_time_diff( $stok['login'], $current_time ) . ' ago';
						$friendly_date = date_i18n( get_option( 'date_format' ) . ' - ' . get_option( 'time_format' ), $stok['login'] );
						return $human_time . '<br><small>' . $friendly_date . '</small>';
					}
				}
			}
		}
		return __( 'No recorded login', 'security-ninja' );
	}

	/**
	 * Run license_key.txt activation on MainWP child requests (not only admin_init).
	 *
	 * @since 5.304
	 * @return void
	 */
	public static function maybe_secnin_fs_license_key_migration_mainwp() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended,WordPress.Security.NonceVerification.Missing -- Detection only.
		if ( ! isset( $_POST['mainwpsignature'] ) && ! isset( $_GET['mainwpsignature'] ) ) {
			return;
		}
		self::secnin_fs_license_key_migration();
	}

	/**
	 * Parse a Freemius license key from license_key.txt (first line).
	 *
	 * Strips a UTF-8 BOM, trims whitespace, requires an sk_ prefix, and uses the
	 * first 32 characters when the line is longer (Freemius migration pattern).
	 *
	 * @since 5.304
	 * @param string $path Absolute path to the license file.
	 * @return string Valid key, or empty string when missing/invalid.
	 */
	public static function parse_license_key_from_file( $path ) {
		if ( empty( $path ) || ! is_string( $path ) || ! is_readable( $path ) ) {
			return '';
		}

		$file_contents = file( $path, FILE_IGNORE_NEW_LINES );
		if ( false === $file_contents || empty( $file_contents[0] ) ) {
			return '';
		}

		$license_key = $file_contents[0];
		// Strip UTF-8 BOM if Notepad or similar saved the file.
		if ( 0 === strpos( $license_key, "\xEF\xBB\xBF" ) ) {
			$license_key = substr( $license_key, 3 );
		}
		$license_key = trim( $license_key );

		if ( empty( $license_key ) || 0 !== strpos( $license_key, 'sk_' ) ) {
			return '';
		}

		if ( strlen( $license_key ) > 32 ) {
			$license_key = substr( $license_key, 0, 32 );
		}

		if ( strlen( $license_key ) !== 32 ) {
			return '';
		}

		return $license_key;
	}

	/**
	 * Whether this request should skip a post-activation redirect.
	 *
	 * MainWP child pings, AJAX, and cron must not receive wp_safe_redirect.
	 *
	 * @since 5.304
	 * @return bool
	 */
	private static function should_skip_license_file_redirect() {
		if ( wp_doing_ajax() || wp_doing_cron() ) {
			return true;
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended,WordPress.Security.NonceVerification.Missing -- Detection only.
		if ( isset( $_POST['mainwpsignature'] ) || isset( $_GET['mainwpsignature'] ) ) {
			return true;
		}
		return false;
	}

	/**
	 * Auto-activate from license_key.txt (deploy ZIP) and legacy Freemius migration.
	 *
	 * From 5.304 the file is read before opt-in / "no_license_key" stamps, so Free
	 * sites upgraded via a custom ZIP (e.g. MainWP) still activate. Empty-key
	 * Freemius calls stay one-shot to avoid opt-in email loops.
	 *
	 * @author  Lars Koudal
	 * @since   v0.0.1
	 * @version v1.0.2  Wednesday, September 9th, 2026.
	 * @access  public static
	 * @return  void
	 */
	public static function secnin_fs_license_key_migration() {
		if ( ! secnin_fs()->has_api_connectivity() ) {
			return;
		}

		$license_file = WF_SN_PLUGIN_DIR . 'license_key.txt';

		// Already licensed: remove leftover deploy file and stop.
		if ( secnin_fs()->can_use_premium_code() ) {
			if ( file_exists( $license_file ) ) {
				wp_delete_file( $license_file );
			}
			return;
		}

		$license_key = self::parse_license_key_from_file( $license_file );

		// No valid file: never call activate_migrated_license() empty (email-loop fix).
		if ( empty( $license_key ) ) {
			if ( 'pending' === get_option( 'secnin_fs_migrated2fs', 'pending' ) ) {
				update_option( 'secnin_fs_migrated2fs', 'no_license_key', false );
			}
			return;
		}

		// Valid file present: ignore prior no_license_key / failed / is_registered.
		if ( get_transient( 'secnin_fs_license_file_attempt' ) ) {
			return;
		}

		$next_page = null;
		try {
			$next_page = secnin_fs()->activate_migrated_license( $license_key );
		} catch ( \Exception $e ) {
			update_option( 'secnin_fs_migrated2fs', 'unexpected_error', false );
			set_transient( 'secnin_fs_license_file_attempt', 1, HOUR_IN_SECONDS );
			return;
		}

		// Freemius-safe: no else/negation on can_use_premium_code__premium_only().
		$migration_failed = true;
		if ( secnin_fs()->can_use_premium_code__premium_only() ) {
			update_option( 'secnin_fs_migrated2fs', 'done', false );
			$migration_failed = false;
			delete_transient( 'secnin_fs_license_file_attempt' );

			if ( file_exists( $license_file ) ) {
				wp_delete_file( $license_file );
			}

			add_action(
				'admin_notices',
				function () {
					echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'License automatically activated!', 'security-ninja' ) . '</p></div>';
				}
			);

			$can_redirect = ! self::should_skip_license_file_redirect();
			if ( $can_redirect && is_array( $next_page ) && isset( $next_page['success'] ) && 1 === $next_page['success'] && isset( $next_page['next_page'] ) ) {
				$next_page_url = wp_validate_redirect( $next_page['next_page'], admin_url() );
				wp_safe_redirect( $next_page_url );
				exit();
			}
		}

		if ( $migration_failed ) {
			update_option( 'secnin_fs_migrated2fs', 'failed', false );
			set_transient( 'secnin_fs_license_file_attempt', 1, HOUR_IN_SECONDS );
		}
	}







	/**
	 * Whether the MainWP Child plugin is active on this site.
	 *
	 * @return bool
	 */
	public static function is_mainwp_child_plugin_active() {
		if ( defined( 'MAINWP_CHILD_URL' ) ) {
			return true;
		}
		return class_exists( 'MainWP\\Child\\MainWP_Child' );
	}

	/**
	 * Whether MainWP may run Security Ninja remote actions on this child site.
	 *
	 * Site owners can disable via the wf_sn_mainwp_disable_remote_actions option (1 = disabled)
	 * or the wf_sn_mainwp_remote_actions_enabled filter.
	 *
	 * @return bool
	 */
	public static function is_mainwp_remote_actions_enabled() {
		if ( ! self::is_mainwp_child_plugin_active() ) {
			return false;
		}
		$default_enabled = ! (bool) get_option( 'wf_sn_mainwp_disable_remote_actions', false );
		return (bool) apply_filters( 'wf_sn_mainwp_remote_actions_enabled', $default_enabled );
	}

	/**
	 * Handles incoming requests from MainWP Master.
	 *
	 * @author  Lars Koudal
	 * @since   v0.0.1
	 * @version v1.0.0  Wednesday, December 6th, 2023.
	 * @access  public static
	 * @param   mixed $information
	 * @param   mixed $data        Default: array()
	 * @return  mixed
	 */
	public static function do_filter_mainwp_site_sync_others_data( $information, $data = array() ) {

		if ( ! self::is_mainwp_child_plugin_active() ) {
			return $information;
		}

		if ( isset( $data['SecNin_get_details'] ) && $data['SecNin_get_details'] ) {
			try {

				global $wpdb;

				$information['SecNin_get_details'] = array(
					'plan' => 'Free',
					'ver'  => self::get_plugin_version(),
				);

				// Check vulnerabilities
				if ( class_exists( __NAMESPACE__ . '\wf_sn_vu' ) ) {
					try {
						$vulns       = \WPSecurityNinja\Plugin\Wf_Sn_Vu::return_vuln_count();
						$vulndetails = \WPSecurityNinja\Plugin\Wf_Sn_Vu::return_vulnerabilities();
					} catch ( \Exception $e ) {
						$vulns       = 0;
						$vulndetails = array();
					}
					$information['SecNin_get_details']['vulns']       = $vulns;
					$information['SecNin_get_details']['vulndetails'] = $vulndetails;
				}

				// Get test scores
				$information['SecNin_get_details']['tests']        = \WPSecurityNinja\Plugin\Wf_Sn::return_test_scores();
				$information['SecNin_get_details']['test_results'] = \WPSecurityNinja\Plugin\Wf_Sn::get_test_results();

				// Core Scanner (free) – sync results for all sites.
				if ( ! class_exists( '\WPSecurityNinja\Plugin\Wf_Sn_Cs_Utils' ) ) {
					require_once WF_SN_PLUGIN_DIR . 'modules/core-scanner/class-wf-sn-cs-utils.php';
				}
				$wf_sn_cs_results                                = \WPSecurityNinja\Plugin\Wf_Sn_Cs_Utils::get_scan_results( array() );
				$information['SecNin_get_details']['cs_results'] = $wf_sn_cs_results;
				if ( is_array( $wf_sn_cs_results ) && ! empty( $wf_sn_cs_results['last_run'] ) && class_exists( '\WPSecurityNinja\Plugin\Wf_Sn_Cs' ) ) {
					$information['SecNin_get_details']['cs_meta'] = \WPSecurityNinja\Plugin\Wf_Sn_Cs::build_meta_strings( $wf_sn_cs_results );
				}

				if ( secnin_fs()->can_use_premium_code__premium_only() ) {

					// Premium part
					$information['SecNin_get_details']['plan'] = 'Pro';

					// Latest events for MainWP (raw_data JSON on newest 50 only).
					$table_name   = $wpdb->prefix . 'wf_sn_el';
					$events_query = $wpdb->prepare(
						"SELECT timestamp, ip, module, action, user_agent, user_id, description FROM `$table_name`
                                WHERE action != %s AND action != %s AND user_agent NOT LIKE %s
                                ORDER BY id DESC
                                LIMIT %d;",
						'mainwp_request',
						'mainwp',
						'%cron%',
						500
					);
					$last_events = $wpdb->get_results( $events_query, ARRAY_A );
					if ( ! is_array( $last_events ) ) {
						$last_events = array();
					}

					$raw_query = $wpdb->prepare(
						"SELECT timestamp, ip, module, action, user_agent, user_id, description, raw_data FROM `$table_name`
                                WHERE action != %s AND action != %s AND user_agent NOT LIKE %s
                                ORDER BY id DESC
                                LIMIT %d;",
						'mainwp_request',
						'mainwp',
						'%cron%',
						50
					);
					$raw_rows   = $wpdb->get_results( $raw_query, ARRAY_A );
					$raw_lookup = array();
					if ( is_array( $raw_rows ) ) {
						foreach ( $raw_rows as $raw_row ) {
							$key = self::mainwp_event_sync_key( $raw_row );
							if ( '' === $key ) {
								continue;
							}
							$decoded = maybe_unserialize( $raw_row['raw_data'] );
							if ( is_array( $decoded ) || is_object( $decoded ) ) {
								$raw_lookup[ $key ] = wp_json_encode( $decoded );
							} elseif ( is_string( $decoded ) && '' !== $decoded ) {
								$raw_lookup[ $key ] = wp_json_encode( array( 'detail' => $decoded ) );
							}
						}
					}

					foreach ( $last_events as $idx => $event_row ) {
						$key = self::mainwp_event_sync_key( $event_row );
						if ( isset( $raw_lookup[ $key ] ) ) {
							$last_events[ $idx ]['raw_data'] = $raw_lookup[ $key ];
						}
					}

					$information['SecNin_get_details']['last_events'] = $last_events;
					$information['SecNin_get_details']['mysql_time_offset'] = get_option( 'gmt_offset' );
					$information['SecNin_get_details']['mysql_time_zone']   = get_option( 'timezone_string' );

					$unblock_url = '';
					if ( class_exists( __NAMESPACE__ . '\Wf_sn_cf' ) ) {
						$unblock_url = esc_url( \WPSecurityNinja\Plugin\Wf_sn_cf::get_unblock_url() );
					}
					$information['SecNin_get_details']['secret_access'] = $unblock_url;

					// hente malware scanner resultater
					$wf_sn_ms_results                                = get_option( 'wf_sn_ms_results' );
					$information['SecNin_get_details']['ms_results'] = $wf_sn_ms_results;

					$globaloptions                                = \WPSecurityNinja\Plugin\Wf_Sn::return_global_options__premium_only();
					$information['SecNin_get_details']['options'] = $globaloptions;

					if ( class_exists( __NAMESPACE__ . '\Wf_Sn_Cf_Ip_Management' ) ) {
						$ip_sync = \WPSecurityNinja\Plugin\Wf_Sn_Cf_Ip_Management::get_ip_entries_for_mainwp_sync( 200 );
						$information['SecNin_get_details']['ip_entries']            = $ip_sync['entries'];
						$information['SecNin_get_details']['ip_entries_truncated'] = $ip_sync['truncated'];
					}

					if ( class_exists( '\WPSecurityNinja\Plugin\AiAdvisor\Wf_Sn_Ai_Advisor_Reports' ) ) {
						$ai_reports = \WPSecurityNinja\Plugin\AiAdvisor\Wf_Sn_Ai_Advisor_Reports::get_reports( 1, 0, 'full_report' );
						if ( ! empty( $ai_reports[0]['report_text'] ) ) {
							$decoded = json_decode( $ai_reports[0]['report_text'], true );
							if ( is_array( $decoded ) && ! empty( $decoded['executive_summary'] ) && is_string( $decoded['executive_summary'] ) ) {
								$information['SecNin_get_details']['ai_executive_summary'] = array(
									'text'         => $decoded['executive_summary'],
									'generated_at' => isset( $ai_reports[0]['created'] ) ? $ai_reports[0]['created'] : '',
								);
							}
						}
					}

					\WPSecurityNinja\Plugin\wf_sn_el_modules::log_event( 'security_ninja', 'mainwp', __( 'Syncing data with MainWP Dashboard', 'security-ninja' ), '' );
				}
			} catch ( \Exception $e ) {
				$information['SecNin_get_details'] = array(
					'error' => $e->getMessage(),
				);
			}
		}

		return $information;
	}





	/**
	 * Integrating with MainWP
	 *
	 * @author  Lars Koudal
	 * @since   v5.139
	 * @version v1.0.0  Thursday, March 24th, 2022.
	 * @version v1.0.1  Saturday, April 2nd, 2022.
	 * @access  public static
	 * @param   mixed $info      – Information
	 *                           to return.
	 * @param   mixed $post_data – Post data array
	 *                           from MainWP.
	 * @return  mixed
	 */
	public static function do_filter_mainwp_child_extra_execution( $info, $post_data ) {

		if ( ! self::is_mainwp_child_plugin_active() ) {
			return $info;
		}

		if ( ! self::is_mainwp_remote_actions_enabled() ) {
			if ( is_array( $info ) && is_array( $post_data ) && ! empty( $post_data['action'] ) ) {
				$info['secnin_remote_actions_disabled'] = true;
			}
			return $info;
		}

		if ( ! is_array( $post_data ) || ! isset( $post_data['action'] ) ) {
			return $info;
		}

		$post_data['action'] = sanitize_key( $post_data['action'] );
		if ( '' === $post_data['action'] ) {
			return $info;
		}

		if ( isset( $post_data['action'] ) ) {

			if ( secnin_fs()->can_use_premium_code__premium_only() ) {
				$request_log = array(
					'source' => 'mainwp',
					'action' => $post_data['action'],
				);
				if ( isset( $post_data['sub_action'] ) ) {
					$request_log['sub_action'] = sanitize_key( $post_data['sub_action'] );
				}
				if ( isset( $post_data['ip'] ) ) {
					$request_log['ip'] = sanitize_text_field( $post_data['ip'] );
				}
				\WPSecurityNinja\Plugin\wf_sn_el_modules::log_event(
					'security_ninja',
					'mainwp_request',
					'Request from MainWP Dashboard (' . esc_attr( $post_data['action'] ) . ')',
					$request_log
				);
			}

			switch ( $post_data['action'] ) {

				// *** Run all tests
				case 'run_all_tests':
					$rate_limit = self::mainwp_rate_limit_action( 'run_all_tests', 60 );
					if ( is_wp_error( $rate_limit ) ) {
						$info['secnin_run_all_tests'] = array(
							'ran'     => false,
							'message' => $rate_limit->get_error_message(),
						);
						break;
					}
					do_action( 'secnin_run_tests_event' );
					$info['secnin_run_all_tests'] = array(
						'ran'     => true,
						'modules' => array( 'tests', 'core' ),
					);
					if ( secnin_fs()->can_use_premium_code__premium_only() ) {
						\WPSecurityNinja\Plugin\wf_sn_el_modules::log_event( 'security_ninja', 'mainwp', 'Got a request from MainWP to run tests.' );
						$info['secnin_run_all_tests']['modules'] = array( 'tests', 'core', 'malware' );
					}
					break;

				// *** Update settings (patch from MainWP Dashboard).
				case 'update_settings':
					if ( secnin_fs()->can_use_premium_code__premium_only() ) {
						$info['secnin_update_settings'] = self::handle_mainwp_update_settings_request( $post_data );
					}
					break;

				// ***  Update white label settings
				case 'update_white_label':
					if ( secnin_fs()->can_use_premium_code__premium_only() ) {
						$info['secnin_update_white_label'] = self::handle_mainwp_update_white_label_request( $post_data );
					}
					break;

				case 'manage_ip':
					if ( secnin_fs()->can_use_premium_code__premium_only() ) {
						if ( class_exists( __NAMESPACE__ . '\Wf_Sn_Cf_Ip_Management' ) ) {
							$info['secnin_manage_ip'] = \WPSecurityNinja\Plugin\Wf_Sn_Cf_Ip_Management::handle_mainwp_manage_ip_request( $post_data );
						}
					}
					break;

				// *** Refresh vulnerability database (free + Pro).
				case 'update_vulnerabilities':
					$info['secnin_update_vulnerabilities'] = self::handle_mainwp_update_vulnerabilities_request();
					break;

				default:
					break;
			}
		}

		return $info;
	}

	/**
	 * Apply white label settings from MainWP Dashboard (Pro only).
	 *
	 * @param array $post_data Request payload from MainWP.
	 * @return array
	 */
	public static function handle_mainwp_update_white_label_request( $post_data ) {
		$response = array(
			'success' => false,
			'message' => __( 'White label update failed.', 'security-ninja' ),
		);

		$incoming = isset( $post_data['white_label_settings'] ) && is_array( $post_data['white_label_settings'] )
			? $post_data['white_label_settings']
			: array();

		$sanitized_settings = array(
			'wl_active'         => isset( $incoming['wl_active'] ) && '1' === $incoming['wl_active'] ? '1' : '0',
			'wl_newname'        => isset( $incoming['wl_newname'] ) ? sanitize_text_field( $incoming['wl_newname'] ) : 'Security Ninja',
			'wl_newdesc'        => isset( $incoming['wl_newdesc'] ) ? sanitize_text_field( $incoming['wl_newdesc'] ) : '',
			'wl_newauthor'      => isset( $incoming['wl_newauthor'] ) ? sanitize_text_field( $incoming['wl_newauthor'] ) : '',
			'wl_newurl'         => isset( $incoming['wl_newurl'] ) ? esc_url_raw( $incoming['wl_newurl'] ) : 'https://wpsecurityninja.com/',
			'wl_newiconurl'     => isset( $incoming['wl_newiconurl'] ) ? esc_url_raw( $incoming['wl_newiconurl'] ) : '',
			'wl_newmenuiconurl' => isset( $incoming['wl_newmenuiconurl'] ) ? esc_url_raw( $incoming['wl_newmenuiconurl'] ) : '',
		);

		$defaults = array(
			'wl_active'         => '0',
			'wl_newname'        => 'Security Ninja',
			'wl_newdesc'        => '',
			'wl_newauthor'      => '',
			'wl_newurl'         => 'https://wpsecurityninja.com/',
			'wl_newiconurl'     => '',
			'wl_newmenuiconurl' => '',
		);

		$final_settings = wp_parse_args( $sanitized_settings, $defaults );
		update_option( 'wf_sn_wl', $final_settings, false );

		\WPSecurityNinja\Plugin\wf_sn_el_modules::log_event( 'security_ninja', 'mainwp', 'Updated white label settings via MainWP Dashboard.' );

		$response['success']  = true;
		$response['message']  = __( 'White label settings updated.', 'security-ninja' );
		$response['settings'] = $final_settings;

		return $response;
	}

	/**
	 * Schedule a one-off vulnerability list refresh from MainWP (free-safe).
	 *
	 * Uses a dedicated cron hook so the request is not skipped when the normal
	 * daily/weekly secnin_update_vuln_list schedule already exists.
	 *
	 * @return array
	 */
	public static function handle_mainwp_update_vulnerabilities_request() {
		$response = array(
			'success' => false,
			'message' => '',
		);

		$rate_limit = self::mainwp_rate_limit_action( 'update_vulnerabilities', 60 );
		if ( is_wp_error( $rate_limit ) ) {
			$response['message'] = $rate_limit->get_error_message();
			return $response;
		}

		if ( ! class_exists( __NAMESPACE__ . '\wf_sn_vu' ) ) {
			$response['message'] = __( 'Vulnerability Scanner is not available on this site.', 'security-ninja' );
			return $response;
		}

		$hook = 'secnin_mainwp_update_vuln_list';

		if ( wp_next_scheduled( $hook ) ) {
			$response['success'] = true;
			$response['message'] = __( 'Vulnerability list update already pending.', 'security-ninja' );
			return $response;
		}

		$scheduled = wp_schedule_single_event( time(), $hook );
		if ( false === $scheduled ) {
			$response['message'] = __( 'Could not schedule the vulnerability list update.', 'security-ninja' );
			return $response;
		}

		$response['success'] = true;
		$response['message'] = __( 'Vulnerability list update scheduled.', 'security-ninja' );

		if ( secnin_fs()->can_use_premium_code__premium_only() ) {
			\WPSecurityNinja\Plugin\wf_sn_el_modules::log_event(
				'security_ninja',
				'mainwp',
				__( 'MainWP requested a vulnerability list update.', 'security-ninja' ),
				array( 'source' => 'mainwp' )
			);
		}

		return $response;
	}

	/**
	 * Modules whose allowlisted key replaces the entire option value (not a nested key).
	 *
	 * @return array<string, string> module => key
	 */
	public static function get_mainwp_whole_option_modules() {
		return array(
			'malware_scanner' => 'whitelist',
			'core_scanner'    => 'user_ignore',
		);
	}

	/**
	 * Apply allowlisted Security Ninja settings from MainWP (changed keys only).
	 *
	 * @param array $post_data Request payload from MainWP.
	 * @return array
	 */
	public static function handle_mainwp_update_settings_request( $post_data ) {
		$response = array(
			'success' => false,
			'applied' => array(),
			'skipped' => array(),
			'errors'  => array(),
			'message' => '',
			'options' => array(),
		);

		if ( ! self::is_mainwp_remote_actions_enabled() ) {
			$response['message'] = __( 'MainWP remote actions are disabled on this site.', 'security-ninja' );
			return $response;
		}

		if ( ! is_array( $post_data ) ) {
			$response['message'] = __( 'Invalid request.', 'security-ninja' );
			return $response;
		}

		$patch = array();
		if ( isset( $post_data['settings_patch'] ) && is_array( $post_data['settings_patch'] ) ) {
			$patch = $post_data['settings_patch'];
		}

		if ( empty( $patch ) ) {
			$response['message'] = __( 'No settings changes to apply.', 'security-ninja' );
			$response['success'] = true;
			return $response;
		}

		$allow        = self::get_mainwp_settings_allowlist();
		$map          = self::get_mainwp_settings_option_map();
		$whole_option = self::get_mainwp_whole_option_modules();

		$fixes_option_key = isset( $map['fixes'] ) ? $map['fixes'] : 'wf_sn_fixes';
		$previous_fixes   = get_option( $fixes_option_key, array() );
		if ( ! is_array( $previous_fixes ) ) {
			$previous_fixes = array();
		}

		foreach ( $patch as $module => $keys ) {
			$module = sanitize_key( $module );
			if ( ! is_array( $keys ) || ! isset( $map[ $module ] ) ) {
				$response['skipped'][] = $module;
				continue;
			}

			$option_key   = $map[ $module ];
			$module_allow = isset( $allow[ $module ] ) ? $allow[ $module ] : array();
			$is_whole     = isset( $whole_option[ $module ] );

			if ( $is_whole ) {
				$expected_key = $whole_option[ $module ];
				foreach ( $keys as $key => $raw_value ) {
					$key = sanitize_key( $key );
					if ( $key !== $expected_key || ! isset( $module_allow[ $key ] ) ) {
						$response['skipped'][] = $module . '.' . $key;
						continue;
					}
					$type  = $module_allow[ $key ];
					$value = self::sanitize_mainwp_setting_value( $type, $raw_value, $module, $key );
					if ( 'malware_scanner' === $module && 'whitelist' === $key ) {
						$value = self::merge_mainwp_malware_whitelist_hashes( $value, get_option( $option_key, array() ) );
					}
					if ( 'core_scanner' === $module && 'user_ignore' === $key ) {
						if ( ! class_exists( '\WPSecurityNinja\Plugin\Wf_Sn_Cs_Utils' ) ) {
							require_once WF_SN_PLUGIN_DIR . 'modules/core-scanner/class-wf-sn-cs-utils.php';
						}
						\WPSecurityNinja\Plugin\Wf_Sn_Cs_Utils::set_user_ignored_files( is_array( $value ) ? $value : array() );
					} else {
						update_option( $option_key, is_array( $value ) ? $value : array(), false );
					}
					$response['applied'][] = $module . '.' . $key;
				}
				continue;
			}

			$existing = get_option( $option_key, array() );
			if ( ! is_array( $existing ) ) {
				$existing = array();
			}

			foreach ( $keys as $key => $raw_value ) {
				$key = sanitize_key( $key );
				if ( ! isset( $module_allow[ $key ] ) ) {
					$response['skipped'][] = $module . '.' . $key;
					continue;
				}

				$type  = $module_allow[ $key ];
				$value = self::sanitize_mainwp_setting_value( $type, $raw_value, $module, $key );

				if ( 'firewall' === $module && in_array( $key, array( 'unblock_url', 'unblock_url_hash', 'firewall_mode', 'firewall_extended_status', 'mode', 'status', 'prepend_path' ), true ) ) {
					$response['skipped'][] = $module . '.' . $key;
					continue;
				}

				$existing[ $key ]     = $value;
				$response['applied'][] = $module . '.' . $key;
			}

			if ( 'firewall' === $module && class_exists( __NAMESPACE__ . '\wf_sn_cf' ) ) {
				$opts = \WPSecurityNinja\Plugin\wf_sn_cf::get_options();
				if ( isset( $opts['unblock_url'] ) ) {
					$existing['unblock_url'] = $opts['unblock_url'];
				}
			}

			update_option( $option_key, $existing, false );
		}

		$applied_count = count( $response['applied'] );
		$response['success'] = $applied_count > 0;
		if ( $applied_count > 0 ) {
			if ( secnin_fs()->is__premium_only() ) {
				self::after_mainwp_settings_apply__premium_only( $response['applied'], $previous_fixes );
			}
		}

		if ( class_exists( __NAMESPACE__ . '\wf_sn' ) && method_exists( __NAMESPACE__ . '\wf_sn', 'return_global_options__premium_only' ) ) {
			$response['options'] = \WPSecurityNinja\Plugin\wf_sn::return_global_options__premium_only();
		}

		if ( $applied_count > 0 ) {
			$response['message'] = sprintf(
				/* translators: %d: number of settings */
				_n(
					'%d setting updated.',
					'%d settings updated.',
					$applied_count,
					'security-ninja'
				),
				$applied_count
			);

			$applied_keys = $response['applied'];

			\WPSecurityNinja\Plugin\wf_sn_el_modules::log_event(
				'security_ninja',
				'mainwp_settings_change',
				sprintf(
					/* translators: %d: number of settings changed */
					_n(
						'MainWP updated %d setting.',
						'MainWP updated %d settings.',
						$applied_count,
						'security-ninja'
					),
					$applied_count
				),
				array(
					'source'        => 'mainwp',
					'changed_count' => $applied_count,
					'applied_keys'  => $applied_keys,
					'skipped_keys'  => isset( $response['skipped'] ) ? $response['skipped'] : array(),
				)
			);
		} else {
			$response['message'] = __( 'No settings were updated.', 'security-ninja' );
		}

		return $response;
	}

	/**
	 * Light rate limit for MainWP remote actions (per site).
	 *
	 * @param string $action Action slug.
	 * @param int    $seconds Window in seconds.
	 * @return true|\WP_Error
	 */
	public static function mainwp_rate_limit_action( $action, $seconds = 60 ) {
		$action = sanitize_key( (string) $action );
		if ( '' === $action ) {
			return true;
		}
		$key = 'secnin_mainwp_rl_' . $action;
		if ( get_transient( $key ) ) {
			return new \WP_Error(
				'secnin_mainwp_rate_limited',
				__( 'This action was requested too recently. Please wait a minute and try again.', 'security-ninja' )
			);
		}
		set_transient( $key, 1, max( 1, (int) $seconds ) );
		return true;
	}

	/**
	 * Run post-apply side effects after a MainWP settings patch (Pro child only).
	 *
	 * @param string[] $applied        Applied module.key strings.
	 * @param array    $previous_fixes Fixes option snapshot from before the patch.
	 * @return void
	 */
	public static function after_mainwp_settings_apply__premium_only( $applied, $previous_fixes ) {
		$applied_modules = array();
		foreach ( (array) $applied as $item ) {
			$parts = explode( '.', (string) $item, 2 );
			if ( '' !== $parts[0] ) {
				$applied_modules[ $parts[0] ] = true;
			}
		}

		if ( isset( $applied_modules['firewall'] ) && class_exists( __NAMESPACE__ . '\wf_sn_cf' ) ) {
			\WPSecurityNinja\Plugin\wf_sn_cf::reset_cached_options();
			do_action( 'security_ninja_firewall_settings_saved' );
		}

		if ( isset( $applied_modules['scheduledscanner'] ) && class_exists( __NAMESPACE__ . '\wf_sn_ss' ) && method_exists( __NAMESPACE__ . '\wf_sn_ss', 'apply_remote_schedule' ) ) {
			\WPSecurityNinja\Plugin\wf_sn_ss::apply_remote_schedule();
		}

		if ( isset( $applied_modules['fixes'] ) && class_exists( __NAMESPACE__ . '\Wf_Sn_Fixes' ) && method_exists( __NAMESPACE__ . '\Wf_Sn_Fixes', 'apply_wpconfig_side_effects' ) ) {
			$fixes_key = defined( 'WF_SN_FIXES_OPTIONS_KEY' ) ? WF_SN_FIXES_OPTIONS_KEY : 'wf_sn_fixes';
			$new_fixes = get_option( $fixes_key, array() );
			if ( ! is_array( $new_fixes ) ) {
				$new_fixes = array();
			}
			if ( ! is_array( $previous_fixes ) ) {
				$previous_fixes = array();
			}
			$patched_fixes = array();
			foreach ( (array) $applied as $item ) {
				if ( 0 !== strpos( (string) $item, 'fixes.' ) ) {
					continue;
				}
				$key = substr( (string) $item, 6 );
				if ( '' !== $key && array_key_exists( $key, $new_fixes ) ) {
					$patched_fixes[ $key ] = $new_fixes[ $key ];
				}
			}
			if ( ! empty( $patched_fixes ) ) {
				\WPSecurityNinja\Plugin\Wf_Sn_Fixes::apply_wpconfig_side_effects( $previous_fixes, $patched_fixes );
			}
		}
	}

	/**
	 * Allowlist: module => key => type (bool|text|email|url|int).
	 *
	 * @return array<string, array<string, string>>
	 */
	public static function get_mainwp_settings_allowlist() {
		$bools = array();
		foreach (
			array(
				'active',
				'trackvisits',
				'globalbannetwork',
				'global',
				'usecloud',
				'protect_login_form',
				'hide_login_errors',
				'blockadminlogin',
				'change_login_url',
				'rename_login_redirect_home',
				'2fa_enabled',
				'2fa_backup_codes_enabled',
				'404guard_enabled',
				'whitelist_managewp',
				'filterqueries',
				'countryblock_loginonly',
				'failed_login_email_warning',
				'whitelist_wprocket',
				'whitelist_uptimia',
				'whitelist_uptimerobot',
				'woo_rate_limiting_enabled',
				'woo_coupon_protection_enabled',
				'satellite_soft_enabled',
			) as $k
		) {
			$bools[ $k ] = 'bool';
		}

		$firewall = $bools;
		$firewall['trackvisits_howlong']     = 'int';
		$firewall['max_login_attempts']      = 'int';
		$firewall['max_login_attempts_time'] = 'int';
		$firewall['bruteforce_ban_time']     = 'int';
		$firewall['login_msg']               = 'text';
		$firewall['login_error_msg']         = 'text';
		$firewall['message']                 = 'text';
		$firewall['redirect_url']            = 'url';
		$firewall['new_login_url']           = 'text';
		$firewall['404guard_threshold']      = 'int';
		$firewall['404guard_window']         = 'int';
		$firewall['404guard_block_time']     = 'int';
		$firewall['blocked_countries']       = 'country_codes';
		$firewall['2fa_grace_period']        = 'int';
		$firewall['2fa_remember_days']       = 'int';
		$firewall['2fa_intro']               = 'text';
		$firewall['2fa_enter_code']          = 'text';
		$firewall['satellite_soft_asns']     = 'asn_list';
		$firewall['woo_checkout_rate_limit'] = 'int';
		$firewall['woo_checkout_window']     = 'int';
		$firewall['woo_add_to_cart_limit']   = 'int';
		$firewall['woo_add_to_cart_window']  = 'int';
		$firewall['woo_order_rate_limit']       = 'int';
		$firewall['woo_order_window']           = 'int';
		$firewall['woo_coupon_failed_attempts'] = 'int';
		$firewall['woo_coupon_window']          = 'int';
		$firewall['woo_coupon_ban_time']        = 'int';
		$firewall['ip_source']                  = 'ip_source';
		$firewall['trusted_proxy_cidrs']        = 'cidr_list';

		$vulns = array(
			'enable_vulns'              => 'bool',
			'enable_admin_notification' => 'bool',
			'enable_outdated'           => 'bool',
			'enable_email_notice'       => 'bool',
			'email_notice_recipient'    => 'email',
			'ignored_plugin_slugs'      => 'text',
		);

		$eventslogger = array(
			'active'                       => 'bool',
			'rest_error_logging'           => 'bool',
			'email_reports'                => 'text',
			'webhook_active'               => 'bool',
			'webhook_firewall_events'      => 'bool',
			'webhook_user_logins'          => 'bool',
			'webhook_updates'              => 'bool',
			'notify_new_admin'             => 'bool',
			'retention'                    => 'text',
			'email_to'                     => 'email',
			'webhook_url'                  => 'url',
			'new_admin_notification_email' => 'email',
		);

		$scheduledscanner = array(
			'main_setting'  => 'text',
			'scan_schedule' => 'text',
			'email_report'  => 'int',
			'email_to'      => 'email',
		);

		$whitelabel = array(
			'wl_active'         => 'bool',
			'wl_newname'        => 'text',
			'wl_newdesc'        => 'text',
			'wl_newauthor'      => 'text',
			'wl_newurl'         => 'url',
			'wl_newiconurl'     => 'url',
			'wl_newmenuiconurl' => 'url',
		);

		$fixes = array(
			'hide_wp'                        => 'bool',
			'hide_wlw'                       => 'bool',
			'hide_php_ver'                   => 'bool',
			'hide_server'                    => 'bool',
			'disable_editors'                => 'bool',
			'disable_wp_debug'               => 'bool',
			'enable_xcto'                    => 'bool',
			'enable_xfo'                     => 'bool',
			'enable_xxp'                     => 'bool',
			'enable_sts'                     => 'bool',
			'enable_rp'                      => 'bool',
			'enable_fp'                      => 'bool',
			'enable_csp'                     => 'bool',
			'disable_wp_sitemaps'            => 'bool',
			'disable_username_enumeration'   => 'bool',
			'hide_wp_debug'                  => 'bool',
			'application_passwords'          => 'bool',
			'remove_unwanted_files'          => 'bool',
			'secure_cookies'                 => 'bool',
			'disable_xmlrpc'                 => 'bool',
			'sechead_xcto'                   => 'text',
			'sechead_xfo'                    => 'text',
			'sechead_sts'                    => 'text',
			'sechead_rp'                     => 'text',
			'sechead_fp'                     => 'text',
			'sechead_csp'                    => 'text',
		);

		return array(
			'firewall'         => $firewall,
			'vulns'            => $vulns,
			'eventslogger'     => $eventslogger,
			'scheduledscanner' => $scheduledscanner,
			'whitelabel'       => $whitelabel,
			'fixes'            => $fixes,
			'malware_scanner'  => array(
				'whitelist' => 'malware_whitelist',
			),
			'core_scanner'     => array(
				'user_ignore' => 'path_list',
			),
		);
	}

	/**
	 * Map synced module slug to WordPress option name.
	 *
	 * @return array<string, string>
	 */
	public static function get_mainwp_settings_option_map() {
		$fixes_key = defined( 'WF_SN_FIXES_OPTIONS_KEY' ) ? WF_SN_FIXES_OPTIONS_KEY : 'wf_sn_fixes';
		$ss_key    = defined( 'WF_SN_SS_OPTIONS_KEY' ) ? WF_SN_SS_OPTIONS_KEY : 'wf_sn_ss';

		return array(
			'firewall'         => 'wf_sn_cf',
			'vulns'            => 'wf_sn_vu_settings_group',
			'eventslogger'     => 'wf_sn_el',
			'scheduledscanner' => $ss_key,
			'whitelabel'       => 'wf_sn_wl',
			'fixes'            => $fixes_key,
			'malware_scanner'  => 'wf_sn_ms_whitelist',
			'core_scanner'     => 'wf_sn_cs_user_ignore',
		);
	}

	/**
	 * Sanitize one setting value for MainWP remote apply.
	 *
	 * @param string $type   Value type.
	 * @param mixed  $value  Raw value.
	 * @param string $module Module slug.
	 * @param string $key    Setting key.
	 * @return mixed
	 */
	public static function sanitize_mainwp_setting_value( $type, $value, $module, $key ) {
		switch ( $type ) {
			case 'bool':
				return self::normalize_flag( $value );
			case 'int':
				$int = max( 0, (int) $value );
				if ( 'firewall' === $module && '2fa_remember_days' === $key ) {
					$int = min( 90, $int );
				}
				return $int;
			case 'email':
				return sanitize_email( (string) $value );
			case 'url':
				return esc_url_raw( (string) $value );
			case 'country_codes':
				return self::sanitize_mainwp_country_codes( $value );
			case 'path_list':
				return self::sanitize_mainwp_path_list( $value );
			case 'malware_whitelist':
				return self::sanitize_mainwp_malware_whitelist( $value );
			case 'asn_list':
				return self::sanitize_mainwp_asn_list( $value );
			case 'ip_source':
				if ( class_exists( __NAMESPACE__ . '\Wf_sn_cf' ) ) {
					return \WPSecurityNinja\Plugin\Wf_sn_cf::normalize_ip_source( $value );
				}
				$source = is_string( $value ) ? sanitize_key( $value ) : 'auto';
				return in_array( $source, array( 'auto', 'remote_addr', 'cf_connecting_ip', 'x_forwarded_for', 'x_real_ip' ), true ) ? $source : 'auto';
			case 'cidr_list':
				if ( class_exists( __NAMESPACE__ . '\Wf_sn_cf' ) ) {
					return \WPSecurityNinja\Plugin\Wf_sn_cf::sanitize_trusted_proxy_cidrs( $value );
				}
				return self::sanitize_mainwp_cidr_list( $value );
			default:
				return sanitize_text_field( (string) $value );
		}
	}

	/**
	 * Sanitize trusted proxy CIDR list for MainWP settings apply.
	 *
	 * @param mixed $value Raw value (array or newline string).
	 * @return string[]
	 */
	public static function sanitize_mainwp_cidr_list( $value ) {
		if ( class_exists( __NAMESPACE__ . '\Wf_sn_cf' ) ) {
			return \WPSecurityNinja\Plugin\Wf_sn_cf::sanitize_trusted_proxy_cidrs( $value );
		}
		if ( is_string( $value ) ) {
			$value = preg_split( '/\r\n|\r|\n/', $value );
		}
		if ( ! is_array( $value ) ) {
			return array();
		}
		return array_values( array_unique( array_map( 'sanitize_text_field', $value ) ) );
	}

	/**
	 * Sanitize satellite/ASN numbers for MainWP settings apply.
	 *
	 * @param mixed $value Raw value (array, comma/space string).
	 * @return string[]
	 */
	public static function sanitize_mainwp_asn_list( $value ) {
		if ( is_string( $value ) ) {
			$value = preg_split( '/[\s,]+/', $value, -1, PREG_SPLIT_NO_EMPTY );
		}
		if ( ! is_array( $value ) ) {
			return array( '14593' );
		}
		$out = array();
		foreach ( $value as $part ) {
			$part = trim( (string) $part );
			if ( preg_match( '/^\d+$/', $part ) ) {
				$out[] = $part;
			}
		}
		if ( empty( $out ) ) {
			return array( '14593' );
		}
		return array_values( array_unique( $out ) );
	}

	/**
	 * Sanitize a list of ISO country codes for MainWP settings apply.
	 *
	 * @param mixed $value Raw value.
	 * @return string[]
	 */
	public static function sanitize_mainwp_country_codes( $value ) {
		if ( is_string( $value ) ) {
			$value = preg_split( '/[\s,]+/', $value );
		}
		if ( ! is_array( $value ) ) {
			return array();
		}
		$out = array();
		foreach ( $value as $code ) {
			$code = strtoupper( sanitize_text_field( (string) $code ) );
			if ( preg_match( '/^[A-Z]{2}$/', $code ) ) {
				$out[] = $code;
			}
		}
		return array_values( array_unique( $out ) );
	}

	/**
	 * Sanitize a list of relative path patterns for MainWP settings apply.
	 *
	 * @param mixed $value Raw value.
	 * @return string[]
	 */
	public static function sanitize_mainwp_path_list( $value ) {
		if ( is_string( $value ) ) {
			$value = preg_split( '/\r\n|\r|\n/', $value );
		}
		if ( ! is_array( $value ) ) {
			return array();
		}
		$out = array();
		foreach ( $value as $path ) {
			if ( is_array( $path ) ) {
				if ( isset( $path['file'] ) ) {
					$path = $path['file'];
				} elseif ( isset( $path['path'] ) ) {
					$path = $path['path'];
				} elseif ( isset( $path['filename'] ) ) {
					$path = $path['filename'];
				} elseif ( isset( $path['pattern'] ) ) {
					$path = $path['pattern'];
				} else {
					continue;
				}
			}
			$path = trim( (string) $path );
			if ( '' === $path ) {
				continue;
			}
			if ( self::is_unsafe_mainwp_relative_path( $path ) ) {
				continue;
			}
			$out[] = sanitize_text_field( $path );
		}
		return array_values( array_unique( $out ) );
	}

	/**
	 * Sanitize Malware Scanner whitelist entries for MainWP settings apply.
	 *
	 * Preserves { filename, hash } and { pattern } objects the scanner expects.
	 * Flat strings (textarea / older MainWP payloads) become pattern entries when
	 * they contain *, otherwise filename entries.
	 *
	 * @param mixed $value Raw value.
	 * @return array<int, array<string, string>>
	 */
	public static function sanitize_mainwp_malware_whitelist( $value ) {
		if ( is_string( $value ) ) {
			$value = preg_split( '/\r\n|\r|\n/', $value );
		}
		if ( ! is_array( $value ) ) {
			return array();
		}

		$out  = array();
		$seen = array();
		foreach ( $value as $item ) {
			$entry = self::sanitize_mainwp_malware_whitelist_item( $item );
			if ( null === $entry ) {
				continue;
			}
			$dedupe_key = wp_json_encode( $entry );
			if ( isset( $seen[ $dedupe_key ] ) ) {
				continue;
			}
			$seen[ $dedupe_key ] = true;
			$out[]               = $entry;
		}

		return $out;
	}

	/**
	 * Copy hashes from an existing whitelist onto incoming filename entries that lack one.
	 *
	 * Textarea and flattened MainWP 2.2.0 payloads omit hashes. Matching filenames
	 * keep the hash already stored on the child so apply does not weaken ignores.
	 *
	 * @param array $incoming Sanitized incoming list.
	 * @param mixed $existing Stored option value.
	 * @return array
	 */
	public static function merge_mainwp_malware_whitelist_hashes( $incoming, $existing ) {
		if ( ! is_array( $incoming ) ) {
			return array();
		}
		if ( ! is_array( $existing ) ) {
			return $incoming;
		}

		$hashes_by_file = array();
		foreach ( $existing as $item ) {
			if ( ! is_array( $item ) || empty( $item['filename'] ) || empty( $item['hash'] ) ) {
				continue;
			}
			$hashes_by_file[ (string) $item['filename'] ] = (string) $item['hash'];
		}

		foreach ( $incoming as $i => $item ) {
			if ( ! is_array( $item ) || empty( $item['filename'] ) || ! empty( $item['hash'] ) ) {
				continue;
			}
			$filename = (string) $item['filename'];
			if ( isset( $hashes_by_file[ $filename ] ) ) {
				$incoming[ $i ]['hash'] = $hashes_by_file[ $filename ];
			}
		}

		return $incoming;
	}

	/**
	 * Sanitize one malware whitelist item.
	 *
	 * @param mixed $item Raw item.
	 * @return array<string, string>|null
	 */
	private static function sanitize_mainwp_malware_whitelist_item( $item ) {
		if ( is_string( $item ) ) {
			$path = trim( $item );
			if ( '' === $path || self::is_unsafe_mainwp_relative_path( $path ) ) {
				return null;
			}
			$path = sanitize_text_field( $path );
			if ( false !== strpos( $path, '*' ) ) {
				return array( 'pattern' => $path );
			}
			return array( 'filename' => $path );
		}

		if ( ! is_array( $item ) ) {
			return null;
		}

		if ( isset( $item['pattern'] ) && '' !== $item['pattern'] ) {
			$pattern = trim( (string) $item['pattern'] );
			if ( '' === $pattern || self::is_unsafe_mainwp_relative_path( $pattern ) ) {
				return null;
			}
			return array( 'pattern' => sanitize_text_field( $pattern ) );
		}

		$filename = '';
		if ( ! empty( $item['filename'] ) ) {
			$filename = (string) $item['filename'];
		} elseif ( ! empty( $item['file'] ) ) {
			$filename = (string) $item['file'];
		} elseif ( ! empty( $item['path'] ) ) {
			$filename = (string) $item['path'];
		}
		$filename = trim( $filename );
		if ( '' === $filename || self::is_unsafe_mainwp_relative_path( $filename ) ) {
			return null;
		}

		$entry = array( 'filename' => sanitize_text_field( $filename ) );
		if ( isset( $item['hash'] ) && '' !== $item['hash'] ) {
			$entry['hash'] = sanitize_text_field( (string) $item['hash'] );
		}

		return $entry;
	}

	/**
	 * Whether a relative path is unsafe for MainWP path settings.
	 *
	 * @param string $path Path or pattern.
	 * @return bool
	 */
	private static function is_unsafe_mainwp_relative_path( $path ) {
		return (bool) preg_match( '#(^/|\\\\|\\.\\.)#', (string) $path );
	}

	/**
	 * Build a stable lookup key for MainWP event sync rows.
	 *
	 * @param array $row Event row.
	 * @return string
	 */
	public static function mainwp_event_sync_key( $row ) {
		if ( ! is_array( $row ) ) {
			return '';
		}
		$parts = array(
			isset( $row['timestamp'] ) ? (string) $row['timestamp'] : '',
			isset( $row['ip'] ) ? (string) $row['ip'] : '',
			isset( $row['module'] ) ? (string) $row['module'] : '',
			isset( $row['action'] ) ? (string) $row['action'] : '',
			isset( $row['user_agent'] ) ? (string) $row['user_agent'] : '',
			isset( $row['user_id'] ) ? (string) $row['user_id'] : '',
			isset( $row['description'] ) ? (string) $row['description'] : '',
		);
		return implode( '|', $parts );
	}





	/**
	 * Create custom select element
	 *
	 * @author  Lars Koudal
	 * @since   v0.0.1
	 * @version v1.0.0  Wednesday, January 13th, 2021.
	 * @version v1.0.1  Thursday, April 11th, 2024.
	 * @access  public static
	 * @param   mixed   $options
	 * @param   boolean $selected   Default: false
	 * @param   boolean $output     Default: true
	 * @return  void
	 */
	public static function create_select_options( $options, $selected = null, $output = true ) {
		$out               = '';
		$is_selected_array = is_array( $selected );

		foreach ( $options as $option ) {
			$value = isset( $option['val'] ) ? $option['val'] : '';
			$label = isset( $option['label'] ) ? $option['label'] : '';

			$is_selected = false;
			if ( $is_selected_array && is_array( $selected ) ) {
				$is_selected = in_array( $value, $selected, true );
			} elseif ( null !== $selected ) {
				$is_selected = ( is_numeric( $value ) && is_numeric( $selected ) )
					? $value == $selected // Loose comparison for numeric values
					: $value === $selected; // Strict comparison for other types
			}

			$value         = esc_attr( $value );
			$label         = esc_html( $label );
			$selected_attr = $is_selected ? ' selected="selected"' : '';

			$out .= sprintf( '<option value="%1$s"%2$s>%3$s</option>', $value, $selected_attr, $label );
		}

		$allowed_html = array(
			'option' => array(
				'value'    => array(),
				'selected' => array(),
			),
		);

		if ( $output ) {
			echo wp_kses( $out, $allowed_html );
		} else {
			return wp_kses( $out, $allowed_html );
		}
	}



	/**
	 * Generate a wpsecurityninja.com URL with UTM parameters.
	 *
	 * utm_source: security_ninja_free | security_ninja_pro (auto)
	 * utm_medium: plugin (default) or email via $params
	 * utm_campaign: security_ninja (stable; version tracked in Freemius)
	 * utm_content: $placement — use a value from the vocabulary below
	 *
	 * Allowed utm_content values:
	 * Upgrades: firewall_upgrade, events_logger_upgrade, malware_upgrade,
	 *   scheduler_upgrade, ai_advisor_upgrade, core_scanner_upgrade, whitelabel_upgrade
	 * Learn more: firewall_learn_more, events_logger_learn_more
	 * Docs: malware_docs, core_scanner_docs, ai_advisor_docs, scheduler_docs,
	 *   security_tests_docs, wizard_docs, wizard_help, sidebar_docs
	 * Sidebar/overview: sidebar_article, sidebar_upgrade, sidebar_trial,
	 *   overview_upgrade, overview_trial
	 * Topbar: topbar_docs, topbar_help
	 * Wizard: wizard_upgrade
	 * Email: email_vuln_footer, email_vuln_upgrade, email_secret_access
	 * Other: newsletter_signup
	 *
	 * @param string $placement utm_content placement key.
	 * @param string $page      Path on wpsecurityninja.com (default home).
	 * @param array  $params    Extra query args (e.g. trial=paid, utm_medium=email).
	 * @return string Full URL with UTM parameters.
	 */
	public static function generate_sn_web_link( $placement = '', $page = '/', $params = array() ) {
		$base_url = 'https://wpsecurityninja.com';
		if ( '/' !== $page ) {
			$page = '/' . trim( $page, '/' ) . '/';
		}
		$utm_source = 'security_ninja_free';

		if ( secnin_fs()->can_use_premium_code__premium_only() ) {
			$utm_source = 'security_ninja_pro';
		}

		$parts = array_merge(
			array(
				'utm_source'   => esc_attr( $utm_source ),
				'utm_medium'   => 'plugin',
				'utm_content'  => esc_attr( $placement ),
				'utm_campaign' => 'security_ninja',
			),
			$params
		);

		$out = $base_url . $page . '?' . http_build_query( $parts, '', '&amp;' );
		return $out;
	}



	/**
	 * add_freemius_extra_permission.
	 *
	 * @author  Lars Koudal
	 * @since   v0.0.1
	 * @version v1.0.0  Saturday, March 5th, 2022.
	 * @access  public static
	 * @param   mixed $permissions
	 * @return  mixed
	 */
	public static function add_freemius_extra_permission( $permissions ) {

		$permissions['newsletter'] = array(
			'id'         => 'security_ninja_newsletter',
			'icon-class' => 'dashicons dashicons-email-alt2',
			'label'      => 'Newsletter',
			'desc'       => 'You are added to our newsletter. Unsubscribe anytime.',
			'priority'   => 18,
		);

		return $permissions;
	}

	/**
	 * Hide Freemius Add-Ons menu/action link until the account is registered.
	 *
	 * Unregistered / skipped opt-in can still surface wf-sn-addons ("Complementos")
	 * while the page fails to load a usable add-ons list.
	 *
	 * @param bool   $is_visible Default Freemius visibility.
	 * @param string $menu_id    Freemius submenu id (e.g. addons, account).
	 * @return bool
	 */
	public static function filter_freemius_addons_submenu_visibility( $is_visible, $menu_id ) {
		if ( 'addons' !== $menu_id ) {
			return $is_visible;
		}

		if ( ! function_exists( '\\WPSecurityNinja\\Plugin\\secnin_fs' ) ) {
			return $is_visible;
		}

		if ( ! secnin_fs()->is_registered() ) {
			return false;
		}

		return $is_visible;
	}




	/**
	 * Add markup for UI overlay.
	 *
	 * @author  Lars Koudal
	 * @since   v0.0.1
	 * @version v1.0.0  Thursday, January 14th, 2021.
	 * @access  public static
	 * @return  void
	 */
	public static function admin_footer() {
		if ( \WPSecurityNinja\Plugin\Wf_Sn::is_plugin_page() ) {
			$current_screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
			if ( $current_screen && false !== strpos( $current_screen->id, 'page_security-ninja-wizard' ) ) {
				return;
			}

			echo '<div id="sn_overlay"><div class="sn-overlay-wrapper">';
			echo '<div class="inner">';
			if ( secnin_fs()->can_use_premium_code__premium_only() ) {
				if ( class_exists( __NAMESPACE__ . '\Wf_Sn_Wl' ) ) {
					if ( ! \WPSecurityNinja\Plugin\Wf_Sn_Wl::is_active() ) {
						echo '<div class="wf-sn-title">
										<h2><img src="' . esc_url( WF_SN_PLUGIN_URL . 'images/security-ninja-logo.png' ) . '" alt="Security Ninja" title="Security Ninja"></h2>
									  </div>';
					}
				}
			}
			// Outer
			echo '<div class="wf-sn-overlay-outer">';

			echo '<div class="wf-sn-overlay-content">';
			echo '<div id="sn-site-scan" style="display: none;">';

			echo '</div>';
			echo '<p><a id="abort-scan" href="#" class="button button-secondary">Cancel</a></p>';
			echo '</div>'; // wf-sn-overlay-content

			echo '</div></div></div></div>';

		}
	}


		/**
		 * Returns icon in SVG format
		 * Thanks Yoast for code.
		 *
		 * @author  Lars Koudal
		 * @since   v0.0.1
		 * @version v1.0.0  Thursday, January 14th, 2021.
		 * @access  public static
		 * @param   boolean $base64 Return SVG in base64 or not
		 * @param   string  $color  Default: '82878c'
		 * @return  mixed
		 */
	public static function get_icon_svg( $base64 = true, $color = '82878c' ) {
		$svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500">
																													<g fill="#' . $color . '">
																													<path d="M171.117 262.277c14.583-.142 25.832 20.664 25.921 35.25.094 15.265-11.418 37.682-26.678 37.227-14.687-.438-23.797-22.605-23.494-37.296.295-14.24 10.095-35.044 24.25-35.181zM322.387 263.03c14.584-.142 25.832 20.664 25.922 35.25.093 15.265-11.419 37.681-26.679 37.227-14.686-.438-23.797-22.606-23.493-37.296.294-14.24 10.094-35.044 24.25-35.182z"/>
																													<path d="M331.348 26.203c0-.107 98.038-7.914 98.038-7.914s-9.219 91.716-10.104 96.592c1.277-3.3 22.717-46.002 22.818-46.002.105 0 53.047 69.799 53.047 69.799l-46.63 42.993c26.6 30.762 41.632 67.951 41.724 107.653.239 103.748-110.253 191.827-245.68 191.091-130.352-.706-239.977-86.977-240.475-188.91-.5-102.38 105.089-191.741 239.663-192.095 38.677-.1 74.34 6.068 105.82 17.154-3.241-16.067-18.22-90.265-18.22-90.36zm-85.421 157.959c-74.098-1.337-161.3 41.627-161.054 105.87.247 63.88 87.825 103.981 160.683 104.125 78.85.154 164.156-41.58 163.722-106.614-.428-64.436-86.566-101.996-163.351-103.381z"/>
																													</g>
																													</svg>';
		if ( $base64 ) {
			return 'data:image/svg+xml;base64,' . base64_encode( $svg );
		}
		return $svg;
	}


	/**
	 * Renders the output for the whitelabel page
	 *
	 * @author  Lars Koudal
	 * @since   v0.0.1
	 * @version v1.0.0  Saturday, March 5th, 2022.
	 * @access  public static
	 * @return  void
	 */
	public static function render_whitelabel_page() {
		?>
		<div class="sncard settings-card">
				<h2><span class="dashicons dashicons-admin-appearance"></span> <?php esc_html_e( 'White label', 'security-ninja' ); ?></h2>
			<p>Customize the plugin branding for your agency or clients.</p>
			<div class="sncard infobox">
				<div class="inner">
					<h3>Upgrade to Pro for White Label</h3>
					<p>Present a fully customized security solution to your clients. Upgrade to Security Ninja Pro (25+ site license) to unlock White Label:</p>
					<ul style="list-style: disc; margin-left: 20px; margin-top: 10px;">
						<li>Hide Security Ninja branding and use your own logo</li>
						<li>Customize the plugin name and add your company URL</li>
						<li>Increase brand visibility with every scan and notification</li>
						<li>Provide a seamless, branded experience for client loyalty</li>
					</ul>
					<p style="margin-top: 15px;">
						<a href="<?php echo esc_url( self::generate_sn_web_link( 'whitelabel_upgrade', '/upgrade/' ) ); ?>" class="button button-primary button-small" target="_blank" rel="noopener"><?php esc_html_e( 'Upgrade to Pro', 'security-ninja' ); ?></a>
					</p>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Safely strips HTML and PHP tags from a string, handling null values.
	 *
	 * @author  Lars Koudal
	 * @since   v0.0.1
	 * @version v1.0.0  Tuesday, December 7th, 2021.
	 * @access  public static
	 * @param   string|null $str The string to strip tags from.
	 * @param   string|null $allowable_tags Optional. Tags to allow.
	 * @return  string The string with tags stripped.
	 */
	public static function safe_strip_tags( $str, $allowable_tags = null ) {
		if ( null === $str ) {
			return '';
		}
		return strip_tags( $str, $allowable_tags );
	}


	public static function extra_modern_checkout_parameters( $parameters ) {
		// You can modify existing parameters in the $parameters array or add new ones.
		$parameters['show_refund_badge']      = true;
		$parameters['show_reviews']           = true;
		$parameters['billing_cycle_selector'] = 'dropdown';

		return $parameters;
	}

	/**
	 * Custom Freemius opt-in (connect) message.
	 *
	 * Keeps the Skip option (enable_anonymous) but gives users a clear,
	 * security-focused reason to opt in, which lifts the opt-in rate without
	 * forcing the connection.
	 *
	 * @since   v5.290
	 * @access  public static
	 * @param   string $message         Default opt-in message (replaced).
	 * @param   string $user_first_name Current user's first name.
	 * @param   string $product_title   Plugin title.
	 * @param   string $user_login      Current user's login.
	 * @param   string $site_link       HTML link to the current site.
	 * @param   string $freemius_link   HTML link to Freemius.
	 * @return  string
	 */
	public static function freemius_connect_message( $message, $user_first_name, $product_title, $user_login, $site_link, $freemius_link ) {
		if ( empty( $user_first_name ) ) {
			$greeting = esc_html__( 'Hi there!', 'security-ninja' );
		} else {
			/* translators: %s: current user's first name. */
			$greeting = sprintf( esc_html__( 'Hi %s!', 'security-ninja' ), esc_html( $user_first_name ) );
		}

		return sprintf(
			/* translators: 1: greeting, 2: plugin title (bold). */
			esc_html__( '%1$s Opt in to keep %2$s working at its best: get critical security alerts, fresh vulnerability data, and important update notices, plus non-sensitive diagnostics that help us fix issues faster. We never collect sensitive data, never share your email, and you can opt out anytime. Not ready? Just click Skip.', 'security-ninja' ),
			$greeting,
			'<strong>' . esc_html( $product_title ) . '</strong>'
		);
	}


		/**
		 * Creates database tables for a specific site.
		 *
		 * @author  Lars Koudal
		 * @since   v0.0.1
		 * @version v1.0.0  Tuesday, December 7th, 2021.
		 * @access  private static
		 * @param   string $charset Database charset.
		 * @return  bool Always returns true to indicate completion.
		 */
	public static function create_tables_for_site( $charset ) {
		global $wpdb;

		// Create main tests table
		$table_name = $wpdb->prefix . 'wf_sn_tests';
		$sql        = "CREATE TABLE {$table_name} (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				testid varchar(30) NOT NULL,
				timestamp datetime NOT NULL,
				title text,
				status tinyint(4) NOT NULL,
				score tinyint(4) NOT NULL,
				runtime float DEFAULT NULL,
				msg text,
				details text,
				PRIMARY KEY  (testid),
				KEY id (id)
			) {$charset};";
		dbDelta( $sql );

		// EVENT LOGS
		$table_name = $wpdb->prefix . 'wf_sn_el';
		$sql        = "CREATE TABLE {$table_name} (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				timestamp datetime NOT NULL,
				ip varchar(39) NOT NULL,
				user_agent varchar(255) NOT NULL,
				user_id int(10) unsigned NOT NULL,
				module varchar(32) NOT NULL,
				action varchar(64) NOT NULL,
				description text NOT NULL,
				raw_data blob NOT NULL,
				PRIMARY KEY  (id)
			) {$charset};";
		dbDelta( $sql );

		// AI Advisor reports (when module is loaded)
		if ( class_exists( '\\WPSecurityNinja\\Plugin\\AiAdvisor\\Wf_Sn_Ai_Advisor_Reports' ) ) {
			\WPSecurityNinja\Plugin\AiAdvisor\Wf_Sn_Ai_Advisor_Reports::ensure_table();
		}

		// Firewall - local list of blocked IPs (free feature)
		$table_name = $wpdb->prefix . 'wf_sn_cf_bl_ips';
		$sql        = "CREATE TABLE {$table_name} (
				tid datetime NOT NULL DEFAULT NOW(),
				ip varchar(46) NOT NULL,
				reason varchar(255) NOT NULL,
				PRIMARY KEY  (ip),
				KEY tid (tid)
			) {$charset};";
		dbDelta( $sql );

		// Set up default settings for Event logger (free feature)
		if ( class_exists( '\\WPSecurityNinja\\Plugin\\Wf_Sn_El' ) ) {
			Wf_Sn_El::default_settings( false );
		}

		if ( secnin_fs()->is__premium_only() ) {
			// keep ->is__premium_only()
			// VISITOR LOG
			$table_name = $wpdb->prefix . 'wf_sn_cf_vl';
			$sql        = "CREATE TABLE {$table_name} (
					id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
					ip varchar(45) NOT NULL,
					timestamp datetime NOT NULL,
					user_agent text,
					country varchar(2),
					banned tinyint(1) DEFAULT 0,
					ban_reason varchar(255),
					description text,
					raw_data text,
					URL text,
					PRIMARY KEY  (id),
					KEY ip (ip),
					KEY timestamp (timestamp),
					KEY banned (banned)
				) {$charset};";
			dbDelta( $sql );

			// SCHEDULED SCANNER
			$table_name = $wpdb->prefix . 'wf_sn_ss_log';
			$sql        = "CREATE TABLE {$table_name} (
					id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
					timestamp datetime NOT NULL,
					runtime float NOT NULL,
					sn_results text,
					cs_results text,
					sn_change tinyint(4) NOT NULL,
					cs_change tinyint(4) NOT NULL,
					ms_results longtext,
					ms_change tinyint(4) NOT NULL DEFAULT 0,
					PRIMARY KEY  (id)
				) {$charset};";
			dbDelta( $sql );

			// Log completion
			if ( class_exists( '\\WPSecurityNinja\\Plugin\\wf_sn_el_modules' ) ) {
				\WPSecurityNinja\Plugin\wf_sn_el_modules::log_event( 'security_ninja', 'installation_routines', 'Completed Pro activation processes for site: ' . get_current_blog_id() );
			}
		}

		return true;
	}


	/**
	 * Safely trims whitespace from the beginning of a string, handling null values.
	 *
	 * @author  Lars Koudal
	 * @since   v0.0.1
	 * @version v1.0.0  Tuesday, December 7th, 2021.
	 * @access  public static
	 * @param   string|null $str The string to trim.
	 * @param   string $character_mask Optional. Characters to trim.
	 * @return  string The trimmed string.
	 */
	public static function safe_ltrim( $str, $character_mask = " \t\n\r\0\x0B" ) {
		if ( null === $str ) {
			return '';
		}
		return ltrim( $str, $character_mask );
	}

	/**
	 * Safely trims whitespace from both ends of a string, handling null values.
	 *
	 * @author  Lars Koudal
	 * @since   v0.0.1
	 * @version v1.0.0  Tuesday, December 7th, 2021.
	 * @access  public static
	 * @param   string|null $str The string to trim.
	 * @param   string $character_mask Optional. Characters to trim.
	 * @return  string The trimmed string.
	 */
	public static function safe_trim( $str, $character_mask = " \t\n\r\0\x0B" ) {
		if ( null === $str ) {
			return '';
		}
		return trim( $str, $character_mask );
	}

	/**
	 * Start timer for performance measurement
	 *
	 * @author  Lars Koudal
	 * @since   v0.0.1
	 * @version v1.0.0  Tuesday, January 12th, 2021.
	 * @access  public static
	 * @param   string $watchname Timer identifier
	 * @return  void
	 */
	public static function timerstart( $watchname ) {
		set_transient( 'security_ninja_' . esc_attr( $watchname ), microtime( true ), 60 * 60 * 1 );
	}

	/**
	 * End timer and return elapsed time
	 *
	 * @author  Lars Koudal
	 * @since   v0.0.1
	 * @version v1.0.0  Tuesday, January 12th, 2021.
	 * @access  public static
	 * @param   string   $watchname Timer identifier
	 * @param   integer  $digits    Number of decimal places (default: 5)
	 * @return  float    Elapsed time in seconds
	 */
	public static function timerstop( $watchname, $digits = 5 ) {
		$return = round( microtime( true ) - get_transient( 'security_ninja_' . esc_attr( $watchname ) ), $digits );
		delete_transient( 'security_ninja_' . esc_attr( $watchname ) );
		return $return;
	}

	/**
	 * Shows the topbar, logo and version
	 *
	 * @author  Unknown
	 * @since   v0.0.1
	 * @version v1.0.0    Monday, March 11th, 2024.
	 * @access  public static
	 * @global
	 * @return  void
	 */
	public static function show_topbar() {
		$icon_url = WF_SN_PLUGIN_URL . 'images/sn-logo.svg';

		$menu_title = 'Security Ninja';
		if ( secnin_fs()->can_use_premium_code__premium_only() ) {
			// If whitelabel enabled
			if ( file_exists( WF_SN_PLUGIN_DIR . 'modules/whitelabel/class-wf-sn-wl.php' ) ) {
				require_once WF_SN_PLUGIN_DIR . 'modules/whitelabel/class-wf-sn-wl.php';
			}
			if ( class_exists( 'WPSecurityNinja\\Plugin\\Wf_Sn_Wl' ) ) {
				if ( \WPSecurityNinja\Plugin\Wf_Sn_Wl::is_active() ) {
					$get_new_icon_url = \WPSecurityNinja\Plugin\Wf_Sn_Wl::get_new_icon_url();
					// $get_new_menu_icon_url = \WPSecurityNinja\Plugin\Wf_Sn_Wl::get_new_menu_icon_url();
					if ( $get_new_icon_url ) {
						$icon_url = $get_new_icon_url;
					} else {
						$icon_url = '';
						// No icon if not set
					}
					$menu_title = \WPSecurityNinja\Plugin\Wf_Sn_Wl::get_new_name();
				}
			}
		}

		$topbar  = '<div id="sntopbar">';
		$topbar .= '<div class="plugname">';
		if ( ! empty( $icon_url ) ) {
			$topbar .= '<img src="' . esc_url( $icon_url ) . '" height="28" alt="' . esc_attr( $menu_title ) . '" class="logoleft">';
		}
		$topbar .= '<div class="name">' . esc_html( $menu_title ) . ' <span>v.' . esc_html( self::get_plugin_version() ) . '</span></div></div>';

		$menu_links = '<a href="https://wordpress.org/support/plugin/security-ninja/" target="_blank" rel="noopener noreferrer" class="extlink">Support Forum</a>';

		if ( secnin_fs()->can_use_premium_code__premium_only() ) {
			// more info for premium users
			$help_link   = self::generate_sn_web_link( 'topbar_help', '/help/' );
			$doc_link    = self::generate_sn_web_link( 'topbar_docs', '/docs/' );
			$menu_links  = '<a href="' . esc_attr( $doc_link ) . '" target="_blank" rel="noopener noreferrer" class="extlink">Documentation</a>';
			$menu_links .= '<a href="' . esc_attr( $help_link ) . '" target="_blank" rel="noopener noreferrer" class="extlink">Support</a>';
		}

		$is_registered = false;
		if ( secnin_fs()->is_registered() ) {
			$is_registered = true;
		}
		$is_tracking_allowed = false;
		if ( secnin_fs()->is_tracking_allowed() ) {
			$is_tracking_allowed = true;
		}
		if ( $is_registered && $is_tracking_allowed ) {
			$menu_links .= '<a href="#" class="productlift-sidebar=caa739c4-554e-4526-9720-a600a6702a8e whatsnew">Updates 🚀</a>';
		}

		if ( secnin_fs()->can_use_premium_code__premium_only() ) {

			// remove details for when white label is enabled
			if ( class_exists( 'WPSecurityNinja\\Plugin\\Wf_Sn_Wl' ) ) {
				if ( \WPSecurityNinja\Plugin\Wf_Sn_Wl::is_active() ) {
					$menu_links = '';
				}
			}
		}

		$topbar .= '<div class="links">' . $menu_links . '</div>';
		$topbar .= '</div>';
		echo wp_kses_post( $topbar );
		// Anchor for core admin notice relocation (common.js). Without this, notices latch onto the first tab h2.
		echo '<hr class="wp-header-end">';
	}

	/**
	 * Creates a toggle switch HTML element
	 *
	 * @author  Lars Koudal
	 * @since   v0.0.1
	 * @version v1.0.0  Tuesday, January 12th, 2021.
	 * @access  public static
	 * @param   string $name    The name/id of the toggle switch
	 * @param   array  $options Options for the toggle switch
	 * @param   bool   $output  Whether to output or return the HTML
	 * @return  string|void     HTML string if $output is false, void otherwise
	 */
	public static function create_toggle_switch( $name, $options = array(), $output = true ) {
		$default_options = array(
			'value'       => 1,
			'saved_value' => 0,
			'option_key'  => '',
		);
		$options         = wp_parse_args( $options, $default_options );
		$value           = (int) $options['value'];
		$saved_value     = ( isset( $options['saved_value'] ) ? (int) $options['saved_value'] : 0 );
		$checked         = ( $value === $saved_value ? ' checked' : '' );

		// When unchecked, checkboxes are omitted from POST. A hidden input with value 0
		// ensures the field is always submitted so "off" persists (e.g. 2FA disable).
		$html = '';
		if ( '' !== (string) $options['option_key'] ) {
			$html .= sprintf(
				'<input type="hidden" name="%1$s" value="0">',
				esc_attr( $options['option_key'] )
			);
		}
		$html .= sprintf(
			'<input type="checkbox" id="%1$s" value="%2$s" class="switch" name="%3$s"%4$s>',
			esc_attr( $name ),
			esc_attr( $options['value'] ),
			esc_attr( $options['option_key'] ),
			$checked
		);

		if ( $output ) {
			echo wp_kses(
				$html,
				array(
					'div'   => array(
						'class' => array(),
					),
					'input' => array(
						'type'    => array(),
						'id'      => array(),
						'value'   => array(),
						'name'    => array(),
						'class'   => array(),
						'checked' => array(),
					),
					'label' => array(
						'for'   => array(),
						'class' => array(),
					),
					'span'  => array(
						'class' => array(),
					),
				)
			);
		} else {
			return $html;
		}
	}

	/**
	 * Returns the ISO country-code => country-name map.
	 *
	 * The data is stored as a JSON data file (rather than an executable PHP
	 * array) so security scanners do not mistake a large static list for
	 * obfuscated/concealed code. The result is cached for the request.
	 *
	 * @author  Lars Koudal
	 * @since   v5.290
	 * @access  public static
	 * @return  array  Associative array of country code => country name (empty on failure).
	 */
	public static function get_country_list() {
		static $country_list = null;
		if ( null !== $country_list ) {
			return $country_list;
		}

		$country_list = array();
		$path         = WF_SN_PLUGIN_DIR . 'modules/cloud-firewall/geoip-countrylist.json';

		if ( is_readable( $path ) ) {
			$contents = file_get_contents( $path );
			if ( false !== $contents && '' !== $contents ) {
				$decoded = json_decode( $contents, true );
				if ( is_array( $decoded ) ) {
					$country_list = $decoded;
				}
			}
		}

		return $country_list;
	}

	/**
	 * Get country flag image URL
	 *
	 * @author  Lars Koudal
	 * @since   v0.0.1
	 * @version v1.0.0  Saturday, March 5th, 2022.
	 * @access  public static
	 * @param   string|bool $country Country code or false
	 * @return  string|bool           Country flag URL or false
	 */
	public static function get_country_img__premium_only( $country = false ) {
		if ( ! $country ) {
			return false;
		}
		$filepath = trailingslashit( WF_SN_PLUGIN_DIR ) . 'images/flags/' . $country . '.png';
		if ( file_exists( $filepath ) ) {
			$fileurl = trailingslashit( WF_SN_PLUGIN_URL ) . 'images/flags/' . $country . '.png';
			return $fileurl;
		}
		return false;
	}

	/**
	 * Get country flag image HTML with country name
	 *
	 * @author  Lars Koudal
	 * @since   v0.0.1
	 * @version v1.0.0  Saturday, March 5th, 2022.
	 * @access  public static
	 * @param   string|bool $country Country code or false
	 * @param   integer     $size    Image size in pixels (default: 32)
	 * @return  string|bool          HTML img tag or false
	 */
	public static function get_country_img_src__premium_only( $country = false, $size = 32 ) {
		if ( ! $country ) {
			return false;
		}
		$return          = false;
		$country_img_url   = self::get_country_img__premium_only( $country );
		$geoip_countrylist = self::get_country_list();
		$country_name      = '';
		if ( isset( $geoip_countrylist[ $country ] ) ) {
			$country_name = $geoip_countrylist[ $country ];
		}
		if ( $country_img_url ) {
			$return = '<img src="' . esc_url( $country_img_url ) . '" width="' . $size . '" height="' . $size . '" class="countryimg" title="' . esc_attr( $country_name ) . '">';
		}
		return $return;
	}

	/**
	 * Fetch plugin version from plugin PHP header
	 *
	 * @author  Lars Koudal
	 * @since   v0.0.1
	 * @version v1.0.0  Wednesday, January 13th, 2021.
	 * @access  public static
	 * @return  string Plugin version
	 */
	public static function get_plugin_version() {
		$plugin_data = get_file_data(
			WF_SN_BASE_FILE,
			array(
				'version' => 'Version',
			),
			'plugin'
		);
		return $plugin_data['version'];
	}

	/**
	 * Fetch plugin name from plugin PHP header
	 *
	 * @author  Lars Koudal
	 * @since   v0.0.1
	 * @version v1.0.0  Wednesday, January 13th, 2021.
	 * @access  public static
	 * @return  string Plugin name
	 */
	public static function get_plugin_name() {
		$plugin_data = get_file_data(
			WF_SN_BASE_FILE,
			array(
				'name' => 'Plugin Name',
			),
			'plugin'
		);
		return $plugin_data['name'];
	}

	/**
	 * Converts a status integer to a button.
	 *
	 * This method takes a status code as an integer and returns a string representing a button with a class indicating the status.
	 * The status codes are mapped to the following buttons:
	 * - 0: Fail (class "sn-error")
	 * - 10: OK (class "sn-success")
	 * - Any other value: Warning (class "sn-warning")
	 *
	 * @author  Lars Koudal
	 * @since   v0.0.1
	 * @version v1.0.0  Tuesday, December 7th, 2021.
	 * @access  public static
	 * @param   int $statuscode The status code to convert.
	 * @return  string The HTML string representing the button.
	 */
	public static function status( $statuscode ) {
		switch ( $statuscode ) {
			case 0:
				$string = '<span class="sn-error">' . __( 'Fail', 'security-ninja' ) . '</span>';
				break;
			case 10:
				$string = '<span class="sn-success">' . __( 'OK', 'security-ninja' ) . '</span>';
				break;
			default:
				$string = '<span class="sn-warning">' . __( 'Warning', 'security-ninja' ) . '</span>';
				break;
		}
		return $string;
	}


	/**
	 * Normalize a boolean-like value to integer 0 or 1
	 *
	 * Converts various boolean representations (true, false, 'true', '1', 1, 0, etc.)
	 * to a consistent integer format (0 or 1) for storage and comparison.
	 *
	 * @author  Lars Koudal
	 * @since   v1.0.0
	 * @version v1.0.0  Monday, January 20th, 2025.
	 * @access  public static
	 * @param   mixed   $value  The value to normalize (can be boolean, string, integer, etc.)
	 * @return  int     Returns 1 if value is truthy, 0 otherwise
	 */
	public static function normalize_flag( $value ) {
		// Handle explicit true/false
		if ( $value === true ) {
			return 1;
		}
		if ( $value === false ) {
			return 0;
		}

		// Handle string representations
		if ( is_string( $value ) ) {
			$value = strtolower( trim( $value ) );
			if ( $value === 'true' || $value === '1' || $value === 'yes' || $value === 'on' ) {
				return 1;
			}
			return 0;
		}

		// Handle numeric values
		if ( is_numeric( $value ) ) {
			return ( (int) $value ) ? 1 : 0;
		}

		// For any other type, use truthiness check
		return $value ? 1 : 0;
	}

	/**
	 * Whether plugin data should be removed during deactivation.
	 *
	 * The main Security Ninja option is the single source of truth for every
	 * module. Deactivation hooks must use this helper before deleting options,
	 * tables, user data, or files.
	 *
	 * @since 5.303
	 * @return bool
	 */
	public static function should_remove_settings_on_deactivate() {
		$options = get_option( 'wf_sn_options', array() );

		return is_array( $options )
			&& isset( $options['remove_settings_deactivate'] )
			&& 1 === self::normalize_flag( $options['remove_settings_deactivate'] );
	}

	/**
	 * Remove Security Ninja data for deactivation or uninstall.
	 *
	 * Deactivation preserves the Freemius license state. Uninstall removes it.
	 * The central option is deleted last so module deactivation callbacks can
	 * still read the user's cleanup preference.
	 *
	 * @since 5.303
	 * @param string $context Either deactivate or uninstall.
	 * @return void
	 */
	public static function remove_plugin_data( $context ) {
		if ( ! in_array( $context, array( 'deactivate', 'uninstall' ), true ) ) {
			return;
		}

		global $wpdb;

		if ( class_exists( '\\WPSecurityNinja\\Plugin\\AiAdvisor\\Wf_Sn_Ai_Advisor', false ) ) {
			\WPSecurityNinja\Plugin\AiAdvisor\Wf_Sn_Ai_Advisor::clear_history();
		}

		$table_names = array(
			$wpdb->prefix . 'wf_sn_tests',
			$wpdb->prefix . 'wf_sn_el',
			$wpdb->prefix . 'wf_sn_cf_bl_ips',
			$wpdb->prefix . 'wf_sn_cf_vl',
			$wpdb->prefix . 'wf_sn_ss_log',
			$wpdb->prefix . 'wf_sn_ai_reports',
		);
		foreach ( $table_names as $table_name ) {
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Names use the trusted WordPress table prefix.
			$wpdb->query( 'DROP TABLE IF EXISTS ' . $table_name );
		}

		$option_names = array(
			'wf_sn_results',
			'wf_sn_active_plugins',
			'wf_sn_review_notice',
			'wf_sn_tests',
			'wf_sn_db_version',
			'wf_sn_cf_ip_lookup_cleanup',
			'wf_sn_settings_migrated',
			'wf_sn_api_allowed_origins',
			'wf_sn_api_access_logs',
			'wf_sn_encryption_key',
			'wf_sn_encryption_key_old',
			'wf_sn_site_id',
			'wf_sn_ai_advisor',
			'wf_sn_ai_reevaluate_pending',
			'wf_sn_cf',
			'wf_sn_cf_ips',
			'wf_sn_cf_vl',
			'wf_sn_cf_bl_ips',
			'wf_sn_cf_blocked_count',
			'wf_sn_cf_blocked_today',
			'wf_sn_banned_ips',
			'wf_sn_cf_validated_crawlers',
			'wf_sn_cf_ai_crawler_ranges',
			'wf_sn_cf_extended',
			'wf_sn_cf_waf_recovery',
			'wf_sn_cf_waf_cookie_key',
			'wf_sn_cf_waf_event_receipts',
			'wf_sn_el',
			'secnin_last_checked_admin_id',
			'secnin_notify_new_admin_since',
			'secnin_admin_notify_baseline_v1',
			'wf_sn_vu_settings_group',
			'wf_sn_vu_vulns',
			'wf_sn_vu_outdated',
			'wf_sn_vu_settings',
			'wf_sn_vu_vulns_notice',
			'wf_sn_vu_last_email',
			'wf_sn_vu_last_email_hash',
			'wf_sn_vulnerabilities_cache',
			'wf_sn_vulnerabilities_cache_timestamp',
			'wf_sn_vuln_count',
			'wf_sn_scan_summary',
			'wf_sn_known_vuln_db_counts',
			'wf_sn_vu_last_update',
			'wf_sn_vu_file_validators_plugins',
			'wf_sn_vu_file_validators_themes',
			'wf_sn_vu_file_validators_wordpress',
			'wf_sn_ms_options',
			'wf_sn_ms_results',
			'wf_sn_ms_integrity_results',
			'wf_sn_ms_cache',
			'wf_sn_ms_whitelist',
			'wf_sn_ms_deletelist',
			'wf_sn_ms_scan_total_time',
			'wf_sn_ms_sk',
			'wf_sn_ms_iv',
			'wf_sn_ms_last_pattern_update',
			'wf_sn_ss',
			'wf_sn_af',
			'wf_sn_fixes',
			'wf_sn_wl',
			'secnin_2fa_passphrase',
			'secnin_activation_redirect',
			'secnin_license_activation_redirect',
			'secnin_fs_migrated2fs',
		);
		foreach ( $option_names as $option_name ) {
			delete_option( $option_name );
		}

		delete_transient( 'wf_sn_ai_advisor_pending_snapshot' );
		delete_transient( 'wf_sn_ai_advisor_pending_meta' );
		delete_transient( 'secnin_vuln_scan_running' );
		delete_transient( 'secnin_vuln_email_retry_scheduled' );

		$user_meta_keys = array(
			'sn_last_login',
			'secnin_2fa_secret',
			'secnin_2fa_setup_complete',
			'secnin_2fa_code_validated',
			'secnin_2fa_session_validated',
			'secnin_2fa_optin',
			'secnin_2fa_method',
		);
		foreach ( $user_meta_keys as $user_meta_key ) {
			delete_metadata( 'user', 0, $user_meta_key, '', true );
		}

		if ( class_exists( __NAMESPACE__ . '\\Wf_sn_cf', false ) ) {
			\WPSecurityNinja\Plugin\Wf_sn_cf::delete_all_ip_lookup_transients();
		}

		if ( class_exists( __NAMESPACE__ . '\\Wf_sn_cs', false ) ) {
			\WPSecurityNinja\Plugin\Wf_sn_cs::load_utils();
			if ( is_multisite() && ! is_main_site() ) {
				delete_option( \WPSecurityNinja\Plugin\Wf_Sn_Cs_Utils::RESULTS_OPTION );
				delete_option( \WPSecurityNinja\Plugin\Wf_Sn_Cs_Utils::USER_IGNORE_OPTION );
			} else {
				\WPSecurityNinja\Plugin\Wf_Sn_Cs_Utils::delete_scan_results();
				\WPSecurityNinja\Plugin\Wf_Sn_Cs_Utils::delete_user_ignored_files();
				if ( is_multisite() ) {
					delete_option( \WPSecurityNinja\Plugin\Wf_Sn_Cs_Utils::RESULTS_OPTION );
					delete_option( \WPSecurityNinja\Plugin\Wf_Sn_Cs_Utils::USER_IGNORE_OPTION );
				}
			}
		}

		if ( ! function_exists( 'WP_Filesystem' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		WP_Filesystem();
		global $wp_filesystem;
		$upload_dir = wp_upload_dir();
		if ( $wp_filesystem && empty( $upload_dir['error'] ) ) {
			$wp_filesystem->delete( trailingslashit( $upload_dir['basedir'] ) . 'security-ninja', true );
		}

		if ( class_exists( __NAMESPACE__ . '\\Secnin_Waf_Lifecycle', false ) ) {
			\WPSecurityNinja\Plugin\Secnin_Waf_Lifecycle::wipe_data_dir_if_safe();
			\WPSecurityNinja\Plugin\Secnin_Waf_Lifecycle::delete_waf_options();
		} else {
			$lifecycle = defined( 'WF_SN_PLUGIN_DIR' ) ? WF_SN_PLUGIN_DIR . 'modules/cloud-firewall/waf/class-secnin-waf-lifecycle.php' : '';
			if ( $lifecycle && is_readable( $lifecycle ) ) {
				require_once $lifecycle;
				if ( class_exists( __NAMESPACE__ . '\\Secnin_Waf_Lifecycle', false ) ) {
					\WPSecurityNinja\Plugin\Secnin_Waf_Lifecycle::wipe_data_dir_if_safe();
					\WPSecurityNinja\Plugin\Secnin_Waf_Lifecycle::delete_waf_options();
				}
			}
		}

		if ( 'uninstall' === $context ) {
			delete_option( 'wfsn_freemius_state' );
		}

		delete_option( 'wf_sn_options' );
	}
}
