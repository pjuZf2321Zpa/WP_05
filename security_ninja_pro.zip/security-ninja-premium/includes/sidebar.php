<?php

namespace WPSecurityNinja\Plugin;

// this is an include only WP file
if ( ! defined( 'ABSPATH' ) ) {
	die;
}

global $secnin_fs;

if ( $secnin_fs->can_use_premium_code__premium_only() ) {
	// Do not load for premium users if whitelabel is activated
	if ( ( class_exists( __NAMESPACE__ . '\Wf_Sn_Wl' ) ) && ( \WPSecurityNinja\Plugin\Wf_Sn_Wl::is_active() ) ) {
		return;
	}
}
?>
<div class="secnin_content_cell" id="sidebar-container">

	<?php
	// Firewall quick numbers - simple, informative and fast.
	if ( ! class_exists( __NAMESPACE__ . '\\Wf_sn_cf' ) ) {
		require_once WF_SN_PLUGIN_DIR . 'modules/cloud-firewall/cloud-firewall.php';
	}

	$firewall_is_active = 0;
	$blocked_today      = 0;

	if ( class_exists( __NAMESPACE__ . '\\Wf_sn_cf' ) ) {
		$firewall_is_active = (int) \WPSecurityNinja\Plugin\Wf_sn_cf::is_active();
		if ( method_exists( __NAMESPACE__ . '\\Wf_sn_cf', 'get_blocked_today_count' ) ) {
			$blocked_today = (int) \WPSecurityNinja\Plugin\Wf_sn_cf::get_blocked_today_count();
		}
	}

	$total_blocked = (int) get_option( 'wf_sn_cf_blocked_count', 0 );
	?>

	<div class="sidebarsection feature">
		<h3><span class="dashicons dashicons-shield-alt"></span> <?php esc_html_e( 'Firewall activity', 'security-ninja' ); ?></h3>
		<ul class="linklist">
			<li><strong><?php esc_html_e( 'Status', 'security-ninja' ); ?>:</strong> <?php echo $firewall_is_active ? esc_html__( 'Enabled', 'security-ninja' ) : esc_html__( 'Disabled', 'security-ninja' ); ?></li>
			<li><strong><?php esc_html_e( 'Blocked today', 'security-ninja' ); ?>:</strong> <?php echo esc_html( number_format_i18n( $blocked_today ) ); ?></li>
			<li><strong><?php esc_html_e( 'Total blocked', 'security-ninja' ); ?>:</strong> <?php echo esc_html( number_format_i18n( $total_blocked ) ); ?></li>
		</ul>
	</div><!-- .sidebarsection -->

	<div class="sidebarsection feature">
		<h3><span class="dashicons dashicons-info-outline"></span> <?php esc_html_e( 'Learn more', 'security-ninja' ); ?></h3>
		<ul class="linklist">
			<li><a href="<?php echo esc_url( Utils::generate_sn_web_link( 'sidebar_article', '/security-tests/' ) ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'About the tests', 'security-ninja' ); ?></a></li>
			<li><a href="<?php echo esc_url( Utils::generate_sn_web_link( 'sidebar_article', '/why-is-insignificant-small-site-attacked-by-hackers/' ) ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Even small sites are attacked by hackers', 'security-ninja' ); ?></a></li>
			<li><a href="<?php echo esc_url( Utils::generate_sn_web_link( 'sidebar_article', '/wordpress-beginner-mistakes/' ) ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'New to WordPress? avoid these beginner mistakes', 'security-ninja' ); ?></a></li>
			<li><a href="<?php echo esc_url( Utils::generate_sn_web_link( 'sidebar_article', '/signs-wordpress-site-is-hacked/' ) ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Signs that your site has been hacked', 'security-ninja' ); ?></a></li>

		</ul>
	</div><!-- .sidebarsection -->


	<?php
	if ( function_exists( 'secnin_fs' ) ) {
		$display_promotion = true;

		if ( $secnin_fs->can_use_premium_code__premium_only() ) {
			$display_promotion = false;
		}

		if ( $display_promotion ) {
			?>
			<div class="snupgradebox sidebarsection feature">
				<h3><span class="dashicons dashicons-star-filled"></span> Security Ninja Pro <span class="dashicons dashicons-star-filled"></span></h3>
				<p><strong><?php esc_html_e( 'Included free', 'security-ninja' ); ?>:</strong> <?php esc_html_e( 'Core Scanner, Security Tests, Vulnerability Scanner', 'security-ninja' ); ?></p>
				<ul class="checkmarks">
					<li><strong><?php esc_html_e( 'Install Wizard', 'security-ninja' ); ?></strong> - <?php esc_html_e( 'get protected in minutes.', 'security-ninja' ); ?></li>
					<li><strong><?php esc_html_e( 'Firewall Protection', 'security-ninja' ); ?></strong> - <?php esc_html_e( 'Protect your website from suspicious visitors.', 'security-ninja' ); ?></li>
					<li><strong><?php esc_html_e( 'Spam Protection', 'security-ninja' ); ?></strong> - <?php esc_html_e( 'The firewall blocks known spammers.', 'security-ninja' ); ?></li>
					<li><strong><?php esc_html_e( 'Login Protection', 'security-ninja' ); ?></strong> - <?php esc_html_e( 'Stop repeated failed logins.', 'security-ninja' ); ?></li>
					<li><strong><?php esc_html_e( 'Rename Login', 'security-ninja' ); ?></strong> - <?php esc_html_e( 'Change the default WordPress login URL.', 'security-ninja' ); ?></li>
					<li><strong><?php esc_html_e( '2FA', 'security-ninja' ); ?></strong> - <?php esc_html_e( 'Add two factor authentication to your WordPress login.', 'security-ninja' ); ?></li>
					<li><strong><?php esc_html_e( 'Country Blocking', 'security-ninja' ); ?></strong> - <?php esc_html_e( 'Block entire countries.', 'security-ninja' ); ?></li>
					<li><strong><?php esc_html_e( 'Plugin Validation', 'security-ninja' ); ?></strong> - <?php esc_html_e( 'Check plugins have not been modified with malware.', 'security-ninja' ); ?></li>
					<li><strong><?php esc_html_e( 'Malware Scanner', 'security-ninja' ); ?></strong> - <?php esc_html_e( 'Find and remove suspicious files.', 'security-ninja' ); ?></li>
					<li><strong><?php esc_html_e( 'Auto Fixer', 'security-ninja' ); ?></strong> - <?php esc_html_e( 'Fix many security issues with a few clicks.', 'security-ninja' ); ?></li>
					<li><strong><?php esc_html_e( 'Events Logger', 'security-ninja' ); ?></strong> - <?php esc_html_e( 'Audit log - Know who did what on your website', 'security-ninja' ); ?></li>
					<li><strong><?php esc_html_e( 'Scheduled Scanner', 'security-ninja' ); ?></strong> - <?php esc_html_e( 'Scan your website for security issues at a specific time.', 'security-ninja' ); ?></li>
				</ul>
				<p><strong><?php esc_html_e( 'Try Pro for 14 days.', 'security-ninja' ); ?></strong> <?php esc_html_e( 'Card or PayPal required. You are not charged today.', 'security-ninja' ); ?></p>
				<a href="<?php echo esc_url( Utils::generate_sn_web_link( 'sidebar_trial', '/upgrade/', array( 'trial' => 'paid' ) ) ); ?>" class="button button-primary trial-button" target="_blank" rel="noopener"><?php esc_html_e( 'Start 14-day trial', 'security-ninja' ); ?></a>
				<div class="wrap-collabsible">
					<input id="collapsible-payment-details" class="toggle" type="checkbox">
					<label for="collapsible-payment-details" class="lbl-toggle">Click to see details</label>
					<div class="collapsible-content">
						<div class="content-inner">

							<ul class="salenotices">
								<li><?php esc_html_e( 'We ask for your payment information to reduce fraud and provide a seamless subscription experience.', 'security-ninja' ); ?></li>
								<li><?php esc_html_e( 'CANCEL ANYTIME before the trial ends to avoid being charged.', 'security-ninja' ); ?></li>
								<li><?php esc_html_e( 'We will send you an email reminder BEFORE your trial ends.', 'security-ninja' ); ?></li>
								<li><?php esc_html_e( 'We accept Visa, Mastercard, American Express and PayPal.', 'security-ninja' ); ?></li>
								<li><?php echo esc_html( 'Upgrade, downgrade or cancel any time.' ); ?></li>
								<li><?php esc_html_e( 'Bulk discounts for more websites.', 'security-ninja' ); ?></li>
							</ul>
							<p><a href="<?php echo esc_url( Utils::generate_sn_web_link( 'sidebar_upgrade', '/upgrade/' ) ); ?>" target="_blank" class="button button-primary" rel="noopener"><?php echo esc_html( 'Read more about the Pro version' ); ?></a></p>

						</div>
					</div>
				</div>
			</div><!-- .snupgradebox -->
			<?php
		}
	}

	if ( $secnin_fs->can_use_premium_code__premium_only() ) {
		$show_pro_ad = false;
	}

	?>
	<div class="sidebarsection feature">
		<h3><span class="dashicons dashicons-info-outline"></span> <?php esc_html_e( 'Plugin help', 'security-ninja' ); ?></h3>
		<ul class="linklist">
			<?php
			global $secnin_fs;

			?>
			<li><a href="<?php echo esc_url( 'https://wordpress.org/support/plugin/security-ninja/' ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Support Forum', 'security-ninja' ); ?></a></li>
			<li><a href="<?php echo esc_url( Utils::generate_sn_web_link( 'sidebar_docs', '/docs/' ) ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Knowledge Base', 'security-ninja' ); ?></a></li>


			<?php

			if ( secnin_fs()->is_not_paying() ) {
				$connect_url = secnin_fs()->connect_again();
				if ( ! empty( $connect_url ) ) {
					?>
				<li><a href="<?php echo esc_url( $connect_url ); ?>"><?php esc_html_e( 'Activate License', 'security-ninja' ); ?></a></li>
					<?php
				}
			}

			?>
			<li><a href="<?php echo esc_url( admin_url( 'admin.php?page=security-ninja-wizard' ) ); ?>" rel="noopener"><?php esc_html_e( 'Restart the setup wizard', 'security-ninja' ); ?></a></li>
			<?php
			?>
		</ul>
	</div><!-- .sidebarsection -->
	<?php
	$show_pro_ad = true;
	if ( $secnin_fs->can_use_premium_code__premium_only() ) {
		$show_pro_ad = false;
	}


	if ( $show_pro_ad ) {
		// Use is_plugin_page() to detect if we're on the main plugin overview page (if available)

		?>
		<div class="sidebarsection feature upgradepro">
			<h3><?php esc_html_e( 'Get even more with WP Security Ninja Pro', 'security-ninja' ); ?></h3>
			<ul>
				<li><strong><?php esc_html_e( 'Get premium protection in minutes', 'security-ninja' ); ?></strong>: <?php esc_html_e( 'Guided wizard, no technical skills needed.', 'security-ninja' ); ?></li>
				<li><strong><?php esc_html_e( 'Stay protected 24/7', 'security-ninja' ); ?></strong>: <?php esc_html_e( 'Real-time firewall and automatic scans.', 'security-ninja' ); ?></li>
				<li><strong><?php esc_html_e( 'Keep spam and bots out', 'security-ninja' ); ?></strong>: <?php esc_html_e( 'Cleaner site, safer visitors.', 'security-ninja' ); ?></li>
				<li><strong><?php esc_html_e( 'Lock down logins', 'security-ninja' ); ?></strong>: <?php esc_html_e( 'Block brute force; add 2FA and hidden login URL.', 'security-ninja' ); ?></li>
				<li><strong><?php esc_html_e( 'Find and fix issues fast', 'security-ninja' ); ?></strong>: <?php esc_html_e( 'Malware &amp; core scans, one-click fixes.', 'security-ninja' ); ?></li>
				<li><strong><?php esc_html_e( 'See who did what', 'security-ninja' ); ?></strong>: <?php esc_html_e( 'Simple audit log of changes.', 'security-ninja' ); ?></li>
				<li><strong><?php esc_html_e( 'Run scans on your schedule', 'security-ninja' ); ?></strong>: <?php esc_html_e( 'Set it and forget it.', 'security-ninja' ); ?></li>
				<li><strong><?php esc_html_e( 'Try risk-free', 'security-ninja' ); ?></strong>: <?php esc_html_e( '30-day money-back guarantee.', 'security-ninja' ); ?></li>
			</ul>
			<p style="margin-top: 10px;text-align: center;">
				<a href="<?php echo esc_url( Utils::generate_sn_web_link( 'sidebar_upgrade', '/upgrade/' ) ); ?>" class="button button-primary button-small" target="_blank" rel="noopener"><?php esc_html_e( 'Read more', 'security-ninja' ); ?></a>
			</p>
		</div>
		<?php
	}
	?>
</div><!-- #sidebar-container -->