<?php
/*
Plugin Name: Meow Gallery (Pro)
Plugin URI: https://meowapps.com
Description: Gallery system built for photographers, by photographers.
Version: 5.6.2
Author: Jordy Meow
Author URI: https://meowapps.com
Text Domain: meow-gallery
Domain Path: /languages

Originally developed for two of my websites:
- Jordy Meow (https://offbeatjapan.org)
- Haikyo (https://haikyo.org)
*/

if ( !defined( 'MGL_VERSION' ) ) {
  define( 'MGL_VERSION', '5.6.2' );
  define( 'MGL_PREFIX', 'mgl' );
  define( 'MGL_DOMAIN', 'meow-gallery' );
  define( 'MGL_ENTRY', __FILE__ );
  define( 'MGL_PATH', dirname( __FILE__ ) );
  define( 'MGL_URL', plugin_dir_url( __FILE__ ) );
  define( 'MGL_ITEM_ID', 6232 );
}

define( 'MEOWAPPS_MGL_LICENSE', 'b5e0b5f8dd8689e6aca49dd6e6e1a930' );
update_option( 'mgl_license', [
'key' => 'b5e0b5f8dd8689e6aca49dd6e6e1a930',
'license' => 'valid',
'expires' => 'lifetime',
'issue' => null
] );
require_once( 'classes/init.php');

?>
