<?php

class Meow_MGL_Migrations {
    private static $db_version = '2.9';

    public function __construct(  ) {

    }

    public static function check_db() {
        global $wpdb;

        $current_db_version = get_option( 'mgl_db_version', '0' );
        $version_outdated = version_compare( $current_db_version, self::$db_version, '<' );
        
        // Also check if tables actually exist
        $tables_exist = true;
        if ( !$version_outdated ) {
            $shortcodes_table = $wpdb->prefix . 'mgl_gallery_shortcodes';
            $collections_table = $wpdb->prefix . 'mgl_collections';
            $tables_exist = $wpdb->get_var( "SHOW TABLES LIKE '$shortcodes_table'" ) === $shortcodes_table
                && $wpdb->get_var( "SHOW TABLES LIKE '$collections_table'" ) === $collections_table;
        }
        
        if ( $version_outdated || !$tables_exist ) {
            self::run_migrations( $current_db_version );
            update_option( 'mgl_db_version', self::$db_version );
        }
    }

    public function check_for_migrations() {
        self::check_db();
    }

    private static function run_migrations( $current_version ) {
        global $wpdb;
        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );

        // Create gallery shortcodes table
        $table_name = $wpdb->prefix . 'mgl_gallery_shortcodes';
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE $table_name (
            id varchar( 20 ) NOT NULL,
            name varchar( 255 ) NOT NULL,
            description text,
            layout varchar( 50 ) NOT NULL,
            medias longtext,
            lead_image_id varchar( 20 ) DEFAULT NULL,
            order_by varchar( 20 ) DEFAULT NULL,
            is_post_mode tinyint( 1 ) DEFAULT 0,
            is_hero_mode tinyint( 1 ) DEFAULT 0,
            posts longtext,
            latest_posts int( 11 ) DEFAULT NULL,
            tags longtext,
            dynamic_source varchar( 50 ) DEFAULT NULL,
            rml varchar( 255 ) DEFAULT NULL,
            pref_rank int( 11 ) DEFAULT 0,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  ( id )
        ) $charset_collate;";

        dbDelta( $sql );

        // Create collections table
        $table_name = $wpdb->prefix . 'mgl_collections';
        $sql = "CREATE TABLE $table_name (
            id varchar( 20 ) NOT NULL,
            name varchar( 255 ) NOT NULL,
            description text,
            layout varchar( 50 ) NOT NULL,
            galleries_ids longtext NOT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  ( id )
        ) $charset_collate;";

        dbDelta( $sql );
        

        // Migrate existing data from options to tables
        if ( version_compare( $current_version, '1.0', '<' ) ) {
            self::migrate_options_to_tables();
        }

    }

    private static function migrate_options_to_tables() {
        global $wpdb;
        
        // Migrate shortcodes
        $shortcodes = get_option( 'mgl_shortcodes', array() );
        $shortcodes_table = $wpdb->prefix . 'mgl_gallery_shortcodes';
        
        foreach ( $shortcodes as $id => $shortcode ) {
            if ( empty( $id ) ) {
                continue;
            }

            $wpdb->insert(
                $shortcodes_table,
                array(
                    'id' => $id,
                    'name' => $shortcode['name'],
                    'description' => $shortcode['description'] ?? '',
                    'layout' => $shortcode['layout'],
                    'medias' => serialize( Meow_MGL_Core::normalize_medias( $shortcode['medias'] ?? null ) ),
                    'lead_image_id' => $shortcode['lead_image_id'] ?? null,
                    'order_by' => $shortcode['order_by'] ?? null,
                    'is_post_mode' => ( isset( $shortcode['is_post_mode'] ) && $shortcode['is_post_mode'] ) ? 1 : 0,
                    'is_hero_mode' => isset( $shortcode['hero'] ) && $shortcode['hero'] ? 1 : 0,
                    'posts' => isset( $shortcode['posts'] ) ? serialize( $shortcode['posts'] ) : null,
                    'latest_posts' => $shortcode['latest_posts'] ?? null,
                    'tags' => isset( $shortcode['tags'] ) ? serialize( $shortcode['tags'] ) : null,
                    'dynamic_source' => $shortcode['dynamic_source'] ?? null,
                    'updated_at' => date( 'Y-m-d H:i:s', $shortcode['updated'] )
                )
            );
        }
        
        // Migrate collections
        $collections = get_option( 'mgl_collections', array() );
        $collections_table = $wpdb->prefix . 'mgl_collections';
        
        foreach ( $collections as $id => $collection ) {
            $wpdb->insert(
                $collections_table,
                array(
                    'id' => $id,
                    'name' => $collection['name'],
                    'description' => $collection['description'] ?? '',
                    'layout' => $collection['layout'],
                    'galleries_ids' => serialize( $collection['galleries_ids'] ),
                    'updated_at' => date( 'Y-m-d H:i:s', $collection['updated'] )
                )
            );
        }
    }
}