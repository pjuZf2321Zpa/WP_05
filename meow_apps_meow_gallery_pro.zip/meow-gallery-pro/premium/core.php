<?php

class MeowPro_MGL_Core {
	private $item = 'Meow Gallery Pro';
	private $core = null;

	private $collection_layout = 'bento';
	// TODO: Would be nice to detect if the collection is actually used on the current page.
	private $is_collection_used = true;

	public function __construct( $core ) {
		$this->core = $core;
		add_action( 'init', array( $this, 'license_enqueue' ) );

		// The assets, Pro stylesheet included, are all handled by Meow_MGL_Run. All that is left
		// to do here is adding the map settings to the gallery bundle, once it is registered.
		add_action( 'mgl_scripts_registered', array( $this, 'localize_map_settings' ), 10, 1 );
		
		add_shortcode( 'meow-collection', array( $this, 'collection' ) );

		// Infinite
		if ( !MeowKit_MGL_Helpers::is_rest() && Meow_MGL_Core::get_plugin_option( 'infinite', false ) ) {
			add_action( 'mgl_gallery_written', array( $this, 'rewrite_for_infinite' ), 10, 2 );
		}
	}

	function license_enqueue() {
		// Common behaviors, license, update system, etc.
		new MeowKitPro_MGL_Licenser( MGL_PREFIX, MGL_ENTRY, MGL_DOMAIN, $this->item, MGL_VERSION );
	}

	// Map configuration, used by the map layout of app/galleries.js.
	function localize_map_settings( $handle ) {
		$options = get_option( Meow_MGL_Core::get_plugin_option_name(), null );
		wp_localize_script( $handle, 'mgl_map',
			array(
				'default_engine' => ( $options['map_engine'] ?? "" ),
				'height' => ( $options['map_height'] ?? 400 ),
				'googlemaps' => array(
					'api_key' => ( $options['googlemaps_token'] ?? '' ),
					'style' => json_decode( ( $options['googlemaps_style'] ?? '' ) )
				),
				'mapbox' => array(
					'api_key' => ( $options['mapbox_token'] ?? '' ),
					'style' => json_decode( ( $options['mapbox_style'] ?? '' ) )
				),
				'maptiler' => array(
					'api_key' => ( $options['maptiler_token'] ?? '' ),
					'style' => json_decode( ( $options['maptiler_style'] ?? '' ) )
				)
			)
		);
	}

	function rewrite_for_infinite( $html, $layout ) {

		// Fix boolean aatributes so XML doesn't get confused
		$html = preg_replace(
			'/\s(autoplay|loop|muted|playsinline|controls|preload)(?!\s*=\s*["\'])/i',
			' $1="$1"',
			$html
		);

		// Ensure <source> tags are self-closing for valid XML
		$html = preg_replace('/<source([^>]*)>/', '<source$1 />', $html);

		if ( $layout == 'masonry' || $layout == 'carousel' )
			return $html;
		$xml = simplexml_load_string( $html );
		if ( empty( $xml ) )
			return $html;
		$subxml = $xml->xpath( '//img' );
		foreach ( $subxml as $s ) {
			$s['mgl-src'] = $s['src'];
			$s['mgl-srcset'] = $s['srcset'];
			$s['srcset'] = '';
			
			// New Lazy
			$s['loading'] = 'lazy';

			// Old Lazy
			//$s['class'] .= ' mgl-lazy';
			//$s['src'] = 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7';
		}
		return $xml->asXml();
	}

	/**
	 * Foreach gallery id, get the the "lead_image_id" to use as the thumbnail.
	 */
	function get_collection_thumbnails( $ids, $atts, $layout ) {
		$ids = explode( ',', $ids );
		$galleries = $this->core->get_galleries_by_ids( $ids );
		
		$thumbnails = array();

		foreach ( $ids as $key => $id ) {

			if ( !isset( $galleries[$id] ) ) {
				$thumbnails[$key]['error'] = "missing";
				$thumbnails[$key]['id'] = $id;
				error_log( "⚠️ Meow Gallery: in collection $atts[id] the gallery $id was not found in the Gallery Manager." );
				continue;
			}

			$shortcode = $galleries[$id];

			$lead_image_id = $shortcode['lead_image_id'] ?? 0;
			// array_search returns false when not found and 0 when the lead is the first item,
			// so we must check !== false (not truthiness).
			$lead_index = array_search( $lead_image_id, $shortcode['medias']['thumbnail_ids'] );
			$thumbnail_id = $lead_index !== false
				? $shortcode['medias']['thumbnail_ids'][$lead_index]
				: ( $shortcode['medias']['thumbnail_ids'][0] ?? 0 );

			// Soft error: if the attachment is gone, still keep the entry so the collection
			// renders with a placeholder (name + description stay clickable).
			$img = wp_get_attachment_image_src( $thumbnail_id, 'large' );
			$thumbnails[$key]['gallery_id'] = $id;
			$thumbnails[$key]['media_id'] = $thumbnail_id;
			if ( $img ) {
				$thumbnails[$key]['img_src'] = $img[0];
				$thumbnails[$key]['img_srcset'] = wp_get_attachment_image_srcset( $thumbnail_id, 'large' );
			} else {
				$thumbnails[$key]['img_src'] = '';
				$thumbnails[$key]['img_srcset'] = '';
				$thumbnails[$key]['missing_image'] = true;
				error_log( "⚠️ Meow Gallery: in collection the thumbnail $thumbnail_id for gallery $id could not be resolved." );
			}
			$thumbnails[$key]['name'] = $shortcode['name'];
			$thumbnails[$key]['description'] = $shortcode['description'] ?? '';
		}

		return $thumbnails;
	}

	function get_wplr_collection_thumbnails( $wplr, $atts, $layout ) {
		$thumbnails = array();
		foreach ( $wplr as $key => $data ) {
			$thumbnails[$key]['wplr_collection_id'] = $data['id'];
			$thumbnails[$key]['media_id'] = $data['thumbnail'];

			// Soft error: wp_get_attachment_image_src returns false when the attachment
			// is gone, so keep the entry with a placeholder instead of crashing.
			$img = wp_get_attachment_image_src( $data['thumbnail'], 'large' );
			if ( $img ) {
				$thumbnails[$key]['img_src'] = $img[0];
				$thumbnails[$key]['img_srcset'] = wp_get_attachment_image_srcset( $data['thumbnail'], 'large' );
			} else {
				$thumbnails[$key]['img_src'] = '';
				$thumbnails[$key]['img_srcset'] = '';
				$thumbnails[$key]['missing_image'] = true;
				error_log( "⚠️ Meow Gallery: in collection $atts[id] the thumbnail $data[thumbnail] could not be resolved." );
			}
			$thumbnails[$key]['name'] = $data['collection']->name;
			$thumbnails[$key]['description'] = '';
		}

		return $thumbnails;
	}

	/**
	 * Builds the collection thumbnails from a list of Real Media Library
	 * sub-galleries (as returned by Meow_MGL_RML::get_collection_galleries).
	 * Each entry uses the 'rml' search slug, whose value is the sub-gallery's
	 * absolute RML path, so clicking a thumbnail renders [gallery rml="..."].
	 */
	function get_rml_collection_thumbnails( $galleries, $atts, $layout ) {
		$thumbnails = array();
		foreach ( $galleries as $key => $gallery ) {
			$thumbnail_id = $gallery['lead_image_id'];
			$thumbnails[$key]['rml'] = $gallery['path'];
			$thumbnails[$key]['media_id'] = $thumbnail_id;

			// Soft error: keep the entry with a placeholder if the attachment is gone.
			$img = wp_get_attachment_image_src( $thumbnail_id, 'large' );
			if ( $img ) {
				$thumbnails[$key]['img_src'] = $img[0];
				$thumbnails[$key]['img_srcset'] = wp_get_attachment_image_srcset( $thumbnail_id, 'large' );
			} else {
				$thumbnails[$key]['img_src'] = '';
				$thumbnails[$key]['img_srcset'] = '';
				$thumbnails[$key]['missing_image'] = true;
			}
			$thumbnails[$key]['name'] = $gallery['name'];
			$thumbnails[$key]['description'] = '';
		}

		return $thumbnails;
	}

	function get_galleries_from_collection( $atts ) {
		$gallery_ids = array();
		$layout = '';

		// Get the IDs
		if ( isset( $atts['id'] ) && isset( $atts['ids'] ) ) {
			error_log( "⚠️ Meow Gallery: in collection $atts[id] both 'id' and 'ids' attributes are used in the same shortcode. 'id' will be ignored." );
		}

		if ( isset( $atts['id'] ) && !isset( $atts['ids'] ) ) {

			$collection = $this->core->get_collection_by_id( $atts['id'] );

			$atts['ids'] = $collection['galleries_ids'];
			$atts['layout'] = $collection['layout'];
		}

		if ( isset( $atts['ids'] ) ) {
			$gallery_ids = $atts['ids'];
			$gallery_ids = str_replace( ' ', '', $gallery_ids );
		}

		if ( !isset( $atts['id'] ) ) {
			$atts['id'] = 'temp__collection__' . uniqid();
		}

		// Filter the IDs
		$ids = is_array( $gallery_ids ) ? $gallery_ids : explode( ',', $gallery_ids );
		$ids = apply_filters( 'mgl_collection_ids', $ids, $atts );
		$gallery_ids = implode( ',', $ids );

		return array( $gallery_ids, $layout );
	}

	function get_thumbnails( $gallery_ids, $atts, $layout ) {
		if ( !empty( $atts['wplr-thumbnails'] ) ) {
			$collection_thumbnails = $this->get_wplr_collection_thumbnails( $atts['wplr-thumbnails'], $atts, $layout );
		}
		else {
			$collection_thumbnails = $this->get_collection_thumbnails( $gallery_ids, $atts, $layout );
		}

		return $collection_thumbnails;
	}

	function collection( $atts, $isPreview = false ) {
		$atts = apply_filters( 'shortcode_atts_collection', $atts, null, $atts );

		$gallery_ids = '';
		$layout = '';
		$rml_galleries = null;

		// Real Media Library folder/collection path (e.g. rml="2025/France").
		// Each direct child of the path becomes a sub-gallery of the collection.
		// The logic lives in Meow_MGL_RML to keep this method clean.
		$has_rml = isset( $atts['rml'] ) && !empty( $atts['rml'] );

		if ( $has_rml ) {
			$rml_galleries = Meow_MGL_RML::get_collection_galleries( $atts['rml'] );
			if ( is_wp_error( $rml_galleries ) ) {
				return "<p class='meow-error'><b>Meow Gallery:</b> " . esc_html( $rml_galleries->get_error_message() ) . "</p>";
			}
			if ( $isPreview ) {
				$rml_galleries = array_slice( $rml_galleries, 0, 5 );
			}
			if ( !isset( $atts['id'] ) ) {
				$atts['id'] = 'temp__collection__' . uniqid();
			}
		}
		else {
			try {
				list( $gallery_ids, $layout ) = $this->get_galleries_from_collection( $atts );	
			} catch (Exception $e) {
				return "<p class='meow-error'><b>Meow Gallery:</b> This ID wasn't found in the Collection Manager. (ID: $atts[id]). " . $e->getMessage() . "</p>";
			}

			if ( empty( $gallery_ids ) && empty( $atts['wplr-thumbnails'] ) ) {
				return "<p class='meow-error'><b>Meow Gallery:</b> The collection is empty.</p>";
			}

			if ( $isPreview ) {
				$check = explode( ',', $gallery_ids );
				$check = array_slice( $check, 0, 5 );
				$gallery_ids = implode( ',', $check );
			}
		}

		if ( isset( $atts['layout'] ) ){
			$layout = $atts['layout'];
		}
			
		if ( $layout === 'none' || $layout === '' ){
			error_log( "⚠️ Meow Gallery: in collection $atts[id] the layout is not defined. Default layout will be used.");
			$layout = 'bento'; //TODO: $this->get_option( 'collection_default_layout', 'bento' );
			$atts['layout'] = $layout;
		}

		$layoutClass = 'Meow_MGL_Builders_Collection_' . ucfirst( $layout );
		if ( !class_exists( $layoutClass ) ) {
			error_log( "Meow Gallery: Class $layoutClass does not exist." );
			return "<p class='meow-error'><b>Meow Gallery:</b> The collection layout $layout is not available in this version.</p>";
		}

		// if ( isset( $atts['titles'] ) && ( $atts['titles'] === false || $atts['titles'] === 'false' ) ) {
		// 	$atts['titles'] = 'none';	
		// }
		// if ( isset( $atts['captions'] ) && ( $atts['captions'] === false || $atts['captions'] === 'false' ) ) {
		// 	$atts['captions'] = 'none';	
		// }

		$this->collection_layout = $layout;
		do_action( 'mgl_collection_created', $atts, explode( ',', $gallery_ids ), $layout );

		$collection_thumbnails = $has_rml
			? $this->get_rml_collection_thumbnails( $rml_galleries, $atts, $layout )
			: $this->get_thumbnails( $gallery_ids, $atts, $layout );

		// Get the class and data attributes
		$class = $this->core->get_mgl_root_class( $atts, ['mgl-collection-root'] );
		$data_atts = $this->core->get_data_as_json( $atts );
		$data_collection_thumbnails = $this->core->get_data_as_json( $collection_thumbnails );
		$html = '<div class="'. $class . '" data-collection-options="' . null . 
		'" data-collection-thumbnails="'. $data_collection_thumbnails .'" data-atts="'. $data_atts . '">';
		$html .= '<div class="mgl-collection-container"></div>';
		$html .= '</div>';
		return $html;
	}

}



