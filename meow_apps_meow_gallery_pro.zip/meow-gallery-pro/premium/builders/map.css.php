<style>

	<?php echo esc_attr( $class_id ) ?> .mgl-item .mgl-icon .mgl-map-container {
		height: <?php echo $map_height; ?>px;
	}

</style>
