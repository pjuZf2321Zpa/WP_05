<?php

class Meow_MGL_Builders_Map extends Meow_MGL_Builders_Core {

	public function __construct( $atts, $infinite, $isPreview = false ) {
		parent::__construct( $atts, false, $isPreview );
		$this->layout = 'map';
	}

	function inline_css() {
		$options = get_option( Meow_MGL_Core::get_plugin_option_name(), null );
		$class_id = '#' . $this->class_id;
		$gutter = isset( $this->atts['gutter'] ) ? $this->atts['gutter'] : ( $options['map_gutter'] ?? 10 );
		$map_height = isset( $this->atts['map_height'] ) ? $this->atts['map_height'] : ( $options['map_height'] ?? 500 );
		$isPreview = $this->isPreview;
		ob_start();
		include dirname( __FILE__ ) . '/map.css.php';
		$html = ob_get_clean();
		return $html;
	}

	function build( $idsStr ) {

		$options = get_option( Meow_MGL_Core::get_plugin_option_name(), null );

		// Generate gallery
		$classes = $this->build_classes();
		$styles = $this->build_styles();
		$out = "<div id='{$this->class_id}' class='{$classes}' style='{$styles}'>";
		$gutter = isset( $this->atts['mgl_map_gutter'] ) ?
		$this->atts['mgl_map_gutter'] : ( $options['map_gutter'] ?? 5 );
		// $arrow_nav_enabled = isset( $this->atts['arrow_nav_enabled'] ) ?
		// 	$this->atts['arrow_nav_enabled'] : ( $options['map_arrow_nav_enabled'] ?? true );
		// $dot_nav_enabled = isset( $this->atts['dot_nav_enabled'] ) ?
		// 	$this->atts['dot_nav_enabled'] : ( $options['map_dot_nav_enabled'] ?? true );
		//$attributes = "data-mgl-gutter=\"${gutter}\" data-mgl-arrow_nav=\"${arrow_nav_enabled}\" data-mgl-dot_nav=\"${dot_nav_enabled}\"";
		$out = '<div id="' . $this->class_id . '"  class="mgl-gallery mgl-' . $this->layout . '">';
		$out .= '<div class="mgl-ui-map"></div>';
		$this->prepare_data( $idsStr );
		$images = array();

		while ( count( $this->ids ) > 0 ) {
			$id = array_pop( $this->ids );
			$data = $this->data[$id];
			$geo_coordinates = MeowPro_MGL_Exif::get_gps_data( $id, $data['meta'] );
			if ( !empty( $geo_coordinates ) ) {
				$callback = function ( &$value, $key ) use ( $id ) {
					$imgsrc = wp_get_attachment_image_src( $id, $key );
					$value = $imgsrc[0];
				};
				array_walk( $data['meta']['sizes'], $callback );
				$file_srcset = wp_get_attachment_image_srcset( $id, 'full' );
				$file_sizes = wp_get_attachment_image_sizes( $id, 'full' );
				array_push( $images, array(
					'file' => $data['meta']['file'],
					'file_srcset' => $file_srcset,
					'file_sizes' => $file_sizes,
					'dimension' => array( 
						'width' => $data['meta']['width'], 
						'height' => $data['meta']['height'] 
					),
					'sizes' => $data['meta']['sizes'],
					'data' => array(
						'caption' => $data['meta']['image_meta']['caption'],
						'gps' => $geo_coordinates
					)
				));
			}
		}
		$images_encoded = json_encode( $images );
		$out .= '<script type="text/javascript">
		window.mgl_map_images = typeof window.mgl_map_images === "undefined" ? [] : window.mgl_map_images;
		window.mgl_map_images[\'' . $this->class_id . '\'] = ' . $images_encoded . ';</script>';
		$out .= '</div>';
		//$out = apply_filters( 'mgl_gallery_written', $out, $this->layout );

		// Generate gallery container
		$container_classes = $this->build_container_classes();
		$inline_css = $this->inline_css();
		$container = "<div class='{$container_classes}'>{$inline_css}{$out}</div>";
		return $container;
	}

}
