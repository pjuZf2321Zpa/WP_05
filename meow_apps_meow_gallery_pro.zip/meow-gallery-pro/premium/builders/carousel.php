<?php

class Meow_MGL_Builders_Carousel extends Meow_MGL_Builders_Core {

	public function __construct( $atts, $infinite, $isPreview = false ) {
		parent::__construct( $atts, false, $isPreview );
		$this->layout = 'carousel';
	}

	function inline_css() {
		$options = get_option( Meow_MGL_Core::get_plugin_option_name(), null );
		$class_id = '#' . $this->class_id;
		$gutter = isset( $this->atts['gutter'] ) ? $this->atts['gutter'] : ( $options['carousel_gutter'] ?? 10 );
		$image_height = isset( $this->atts['image_height'] ) ? $this->atts['image_height'] : ( $options['carousel_image_height'] ?? 500 );
		$isPreview = $this->isPreview;
		ob_start();
		include dirname( __FILE__ ) . '/carousel.css.php';
		$html = ob_get_clean();
		return $html;
	}

	function build( $idsStr ) {

		$options = get_option( Meow_MGL_Core::get_plugin_option_name(), null );

		// Generate gallery
		$classes = $this->build_classes();
		$styles = $this->build_styles();
		$out = "<div id='{$this->class_id}' class='{$classes}' style='{$styles}'>";
		$gutter = isset( $this->atts['mgl_carousel_gutter'] ) ?
			$this->atts['mgl_carousel_gutter'] : ( $options['carousel_gutter'] ?? 5 );
		$arrow_nav_enabled = isset( $this->atts['arrow_nav_enabled'] ) ?
			$this->atts['arrow_nav_enabled'] : ( $options['carousel_arrow_nav_enabled'] ?? true );
		$dot_nav_enabled = isset( $this->atts['dot_nav_enabled'] ) ?
			$this->atts['dot_nav_enabled'] : ( $options['carousel_dot_nav_enabled'] ?? true );
		$keep_aspect_ratio = isset( $this->atts['keep_aspect_ratio'] ) ?
			$this->atts['keep_aspect_ratio'] : ( $options['carousel_keep_aspect_ratio'] ?? true );

		$attributes = "data-mgl-gutter=\"{$gutter}\" data-mgl-arrow_nav=\"{$arrow_nav_enabled}\" data-mgl-dot_nav=\"{$dot_nav_enabled}\" data-mgl-keep_aspect_ratio=\"{$keep_aspect_ratio}\"";
		
		$out = "<div id='{$this->class_id}' class='{$classes}' style='{$styles}' {$attributes}>";
		$out .= '<div class="meow-carousel-track">';
		$this->prepare_data( $idsStr );
		while ( count( $this->ids ) > 0 ) {
			$id = array_pop( $this->ids );
			$out .= $this->build_next_cell( $id, $this->data[$id] );
		}
		$out .= '</div>';
		$out .= '</div>';
		$out = apply_filters( 'mgl_gallery_written', $out, $this->layout );

		// Generate gallery container
		$container_classes = $this->build_container_classes();
		$inline_css = $this->inline_css();
		$container = "<div class='{$container_classes}'>{$inline_css}{$out}</div>";

		return $container;
	}

}

?>
