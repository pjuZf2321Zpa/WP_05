<?php
/**
 * Links count check.
 *
 * @since   3.4.0
 * @package SmartCrawl
 */

namespace SmartCrawl\Checks;

use SmartCrawl\Html;

/**
 * Class instance to check Links_Count
 */
class Links_Count extends Check {

	/**
	 * Holds check state
	 *
	 * @var bool
	 */
	private $state;

	/**
	 * Link count.
	 *
	 * @var int
	 */
	private $link_count;

	/**
	 * Internal link count.
	 *
	 * @var int
	 */
	private $internal_link_count;

	/**
	 * Retrieves the message for the check.
	 *
	 * @since 3.4.0
	 *
	 * @return string
	 */
	public function get_status_msg() {
		return $this->choose_message(
			/* translators: 1, 2: Number of internal/external links */
			__( 'You have %1$d internal and %2$d external links in your content', 'wds' ),
			__( "You haven't added any internal or external links in your content", 'wds' ),
			/* translators: 2: Number of external links */
			__( 'You have 0 internal and %2$d external links in your content', 'wds' )
		);
	}

	/**
	 * Select status message based on density.
	 *
	 * @param string $okay_message Ok message.
	 * @param string $no_links     No links message.
	 * @param string $no_internal  No internal message.
	 *
	 * @return string
	 */
	private function choose_message( $okay_message, $no_links, $no_internal ) {
		$total_count    = (int) $this->link_count;
		$internal_count = (int) $this->internal_link_count;
		$external_count = $total_count - $internal_count;

		if ( $this->state ) {
			$message = $okay_message;
		} elseif ( ! $total_count ) {
			$message = $no_links;
		} elseif ( ! $internal_count ) {
			$message = $no_internal;
		}

		return sprintf( $message, (int) $internal_count, (int) $external_count, (int) $total_count );
	}

	/**
	 * Applies check to the subject.
	 *
	 * @since 3.4.0
	 *
	 * @return bool
	 */
	public function apply() {
		$site_url = untrailingslashit( site_url() );
		$home_url = untrailingslashit( home_url() );

		$this->link_count          = 0;
		$this->internal_link_count = 0;

		foreach ( Html::find( 'a[href]', $this->get_markup() ) as $link ) {
			if ( $this->should_ignore_link( $link ) ) {
				continue;
			}

			$url = trim( Html::get_attribute( $link, 'href' ) );
			if ( '' === $url || '#' === $url[0] ) {
				// Same-page anchors are not SEO internal/external content links.
				continue;
			}

			++$this->link_count;

			if ( $this->is_internal_url( $url, $site_url, $home_url ) ) {
				++$this->internal_link_count;
			}
		}

		$this->state = ! empty( $this->internal_link_count );

		return ! ! $this->state;
	}

	/**
	 * Whether a link should be excluded from content link analysis.
	 *
	 * @param object $link simple_html_dom_node.
	 *
	 * @return bool
	 */
	private function should_ignore_link( $link ) {
		$class = Html::get_attribute( $link, 'class' );
		$id    = Html::get_attribute( $link, 'id' );
		if (
			false !== strpos( $class, 'skip-link' )
			|| false !== strpos( $class, 'post-edit-link' )
			|| 'cancel-comment-reply-link' === $id
		) {
			return true;
		}

		// Walk up a few parents for breadcrumb wrappers.
		$parent = isset( $link->parent ) ? $link->parent : null;
		for ( $i = 0; $i < 5 && $parent; $i++ ) {
			$parent_class = isset( $parent->class ) ? (string) $parent->class : '';
			if ( false !== strpos( $parent_class, 'smartcrawl-breadcrumbs' ) || false !== strpos( $parent_class, 'smartcrawl-breadcrumb' ) ) {
				return true;
			}
			$parent = isset( $parent->parent ) ? $parent->parent : null;
		}

		return false;
	}

	/**
	 * Checks whether a URL points to the current site.
	 *
	 * @param string $url      Link URL.
	 * @param string $site_url Untrailingslashed site URL.
	 * @param string $home_url Untrailingslashed home URL.
	 *
	 * @return bool
	 */
	private function is_internal_url( $url, $site_url, $home_url ) {
		if ( '/' === $url[0] && '/' !== substr( $url, 1, 1 ) ) {
			return true;
		}

		foreach ( array( $site_url, $home_url ) as $base_url ) {
			if ( $base_url && 0 === stripos( $url, $base_url ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Retrieves check result.
	 *
	 * @since 3.6.0
	 *
	 * @return array
	 */
	public function get_result() {
		return array(
			'state'    => $this->state,
			'internal' => $this->internal_link_count,
			'total'    => $this->link_count,
		);
	}
}