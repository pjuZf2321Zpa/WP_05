<?php
/**
 * Abstract class Query for handling sitemap queries in SmartCrawl.
 *
 * @package SmartCrawl
 */

namespace SmartCrawl\Sitemaps;

use SmartCrawl\Work_Unit;

/**
 * Class Query
 *
 * Abstract class for handling sitemap queries.
 */
abstract class Query extends Work_Unit {

	const NO_LIMIT = PHP_INT_MAX;

	/**
	 * Number of extra items injected on the first page outside the query
	 * (e.g. the manually-added home-page URL). Used to adjust LIMIT on
	 * page 1 and OFFSET on subsequent pages so pagination stays gap-free.
	 *
	 * This is a runtime cache, populated per-request from the canonical
	 * per-type method get_first_page_items_offset(). Do not set it
	 * directly outside of build_partial_sitemap(); the per-type override
	 * is the single source of truth for *which* types get injected items.
	 *
	 * @var int
	 */
	protected $first_page_items_offset = 0;

	/**
	 * Retrieves the items for the given type and page number.
	 *
	 * @param string $type The type of items to retrieve.
	 * @param int    $page_number The page number for pagination.
	 *
	 * @return General\Item[] Array of sitemap items.
	 */
	abstract public function get_items( $type = '', $page_number = 0 );

	/**
	 * Retrieves the item count for the given type.
	 *
	 * @param string $type The type of items to count.
	 *
	 * @return int The item count.
	 */
	public function get_item_count( $type = '' ) {
		return count( $this->get_items( $type ) );
	}

	/**
	 * Checks if the type can be handled.
	 *
	 * @param string $type The type to check.
	 *
	 * @return bool True if the type can be handled, false otherwise.
	 */
	public function can_handle_type( $type ) {
		$allowed = $this->get_supported_types();

		return in_array( $type, $allowed, true );
	}

	/**
	 * Retrieves the supported types.
	 *
	 * @return mixed The supported types.
	 */
	abstract public function get_supported_types();

	/**
	 * Sets the number of extra items that are injected on the first sitemap
	 * page outside of the database query (e.g. the home-page URL).
	 *
	 * @param int $count Number of externally-injected first-page items.
	 *
	 * @return $this
	 */
	public function set_first_page_items_offset( $count ) {
		$this->first_page_items_offset = (int) $count;

		return $this;
	}

	/**
	 * The canonical number of items injected on the first sitemap page
	 * outside of the database query (e.g. the home-page URL), per type.
	 *
	 * This is the single source of truth for *which* types receive injected
	 * first-page items. Subclasses that inject first-page items should
	 * override this and return a positive integer for the relevant types.
	 *
	 * Both code paths consult this value:
	 *  - build_partial_sitemap() copies it into the per-request property via
	 *    set_first_page_items_offset() so get_limit()/get_offset() can apply
	 *    it to the DB query.
	 *  - make_index_items() reads it directly to compute the correct number
	 *    of sitemap pages for the index, so partial pages never get orphaned.
	 *
	 * @param string $type The sitemap type.
	 * @return int Injected first-page item count (default 0).
	 */
	public function get_first_page_items_offset( $type ) {
		return 0;
	}

	/**
	 * Retrieves the limit for the given page number.
	 *
	 * @param int $page_number The page number for pagination.
	 *
	 * @return int The limit.
	 */
	protected function get_limit( $page_number ) {
		if ( 0 === $page_number ) {
			return self::NO_LIMIT;
		}

		$limit = Utils::get_items_per_sitemap();

		if ( 1 === $page_number ) {
			$limit -= $this->first_page_items_offset;
		}

		return max( 0, $limit );
	}

	/**
	 * Retrieves the offset for the given page number.
	 *
	 * @param int $page_number The page number for pagination.
	 *
	 * @return int The offset.
	 */
	protected function get_offset( $page_number ) {
		if ( $page_number <= 1 ) {
			return 0;
		}

		return max( 0, ( $page_number - 1 ) * Utils::get_items_per_sitemap() - $this->first_page_items_offset );
	}

	/**
	 * Finds images in the given haystack.
	 *
	 * @param string $haystack The string to search for images.
	 *
	 * @return array The found images.
	 */
	protected function find_images( $haystack ) {
		preg_match_all( '|(<img [^>]+?>)|', $haystack, $matches, PREG_SET_ORDER );
		if ( ! $matches ) {
			return array();
		}

		$images = array();
		foreach ( $matches as $tmp ) {
			$img = $tmp[0];

			$res = preg_match( '/src=(["\'])([^"\']+)(["\'])/', $img, $match );
			$src = $res ? $match[2] : '';
			if ( strpos( $src, 'http' ) !== 0 ) {
				$src = site_url( $src );
			}

			$res   = preg_match( '/title=(["\'])([^"\']+)(["\'])/', $img, $match );
			$title = $res ? str_replace( '-', ' ', str_replace( '_', ' ', $match[2] ) ) : '';

			$res = preg_match( '/alt=(["\'])([^"\']+)(["\'])/', $img, $match );
			$alt = $res ? str_replace( '-', ' ', str_replace( '_', ' ', $match[2] ) ) : '';

			$images[] = array(
				'src'   => $src,
				'title' => $title,
				'alt'   => $alt,
			);
		}

		return $images;
	}

	/**
	 * Retrieves the index items.
	 *
	 * @return Index_Item[] The index items.
	 */
	public function get_index_items() {
		$types       = $this->get_supported_types();
		$index_items = array();
		foreach ( $types as $type ) {
			$index_items_for_type = $this->get_index_items_for_type( $type );

			$index_items = array_merge(
				$index_items,
				$index_items_for_type
			);
		}

		return $index_items;
	}

	/**
	 * Retrieves the index items for the given type.
	 *
	 * @param string $type The type of items.
	 *
	 * @return array The index items.
	 */
	protected function get_index_items_for_type( $type ) {
		return $this->make_index_items( $type );
	}

	/**
	 * Retrieves the index item URL for the given type and sitemap number.
	 *
	 * @param string $type The type of items.
	 * @param int    $sitemap_num The sitemap number.
	 *
	 * @return string The index item URL.
	 */
	protected function get_index_item_url( $type, $sitemap_num ) {
		$suffix = ( $sitemap_num > 1 ) ? (int) $sitemap_num : '';

		return home_url( sprintf( '/%s-sitemap%s.xml', $type, $suffix ) );
	}

	/**
	 * Creates index items for the given type.
	 *
	 * @param string $type The type of items.
	 *
	 * @return array The index items.
	 */
	protected function make_index_items( $type ) {
		$per_sitemap = Utils::get_items_per_sitemap();
		$item_count  = $this->get_item_count( $type );
		if ( empty( $per_sitemap ) ) {
			return array();
		}

		$offset        = $this->get_first_page_items_offset( $type );
		$sitemap_count = $this->get_sitemap_page_count( $item_count, $per_sitemap, $offset );
		$index_items   = array();

		for ( $sitemap_num = 1; $sitemap_num <= $sitemap_count; $sitemap_num++ ) {
			$location = $this->get_index_item_url( $type, $sitemap_num );

			$index_item = new Index_Item();
			$index_item->set_location( $location );

			$index_items[] = $index_item;
		}

		return $index_items;
	}

	/**
	 * Computes the total number of sitemap pages for a type, accounting
	 * for first-page injected items so the index lists every page that
	 * build_partial_sitemap() actually serves.
	 *
	 * Page 1 holds the injected items plus (per_sitemap - offset) DB rows;
	 * every later page holds per_sitemap DB rows.
	 *
	 * When offset is 0 this collapses to the classic ceil() formula, so
	 * unaffected sitemap types (taxonomies, extras, CPTs without injected
	 * items) keep their previous page count exactly.
	 *
	 * @param int $item_count  DB row count for the type.
	 * @param int $per_sitemap Configured links-per-sitemap.
	 * @param int $offset      Injected first-page item count.
	 * @return int Number of sitemap pages (0 when there are no DB items).
	 */
	protected function get_sitemap_page_count( $item_count, $per_sitemap, $offset ) {
		if ( $item_count <= 0 ) {
			return 0;
		}

		if ( $offset <= 0 ) {
			return (int) ceil( $item_count / $per_sitemap );
		}

		$first_page_capacity = max( 0, $per_sitemap - $offset );

		if ( $item_count <= $first_page_capacity ) {
			return 1;
		}

		return 1 + (int) ceil( ( $item_count - $first_page_capacity ) / $per_sitemap );
	}
}