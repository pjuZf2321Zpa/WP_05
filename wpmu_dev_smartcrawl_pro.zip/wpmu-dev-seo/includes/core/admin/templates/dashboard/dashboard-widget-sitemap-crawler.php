<?php
/**
 * Template: Dashboard Sitemap Widget Crawler.
 *
 * @package SmartCrawl
 */

namespace SmartCrawl;

use SmartCrawl\Services\Service;

$sitemap_enabled           = ! empty( $sitemap_enabled );
$sitemap_crawler_available = ! empty( $sitemap_crawler_available );

if ( ! $sitemap_crawler_available ) {
	return;
}

$is_member = Service::get( Service::SERVICE_SITE )->is_member();
?>

<div class="wds-separator-top cf <?php echo $is_member ? 'wds-draw-left-padded' : 'wds-box-blocked-area wds-draw-down wds-draw-left'; ?>">
	<small><strong><?php esc_html_e( 'URL Crawler', 'wds' ); ?></strong></small>
	<?php if ( $is_member ) : ?>
		<?php if ( $sitemap_enabled ) : ?>
			<?php
			$this->render_view(
				'url-crawl-master',
				array(
					'ready_template'    => 'dashboard/dashboard-url-crawl-stats',
					'progress_template' => 'dashboard/dashboard-url-crawl-in-progress',
					'no_data_template'  => 'dashboard/dashboard-url-crawl-no-data-small',
				)
			);
			?>
		<?php else : ?>
			<p>
				<small>
					<?php
					printf(
						/* translators: 1,2: strong tag, 3: plugin title */
						esc_html__( 'Automatically schedule %1$s%3$s%2$s to run check for URLs that are missing from your Sitemap.', 'wds' ),
						'<strong>',
						'</strong>',
						esc_html( \smartcrawl_get_plugin_title() )
					);
					?>
				</small>
			</p>
			<div><span class="sui-tag sui-tag-inactive">
				<?php esc_html_e( 'Sitemaps must be activated', 'wds' ); ?>
			</span></div>
		<?php endif; ?>
	<?php else : ?>
		<a
			href="https://wpmudev.com/project/smartcrawl-wordpress-seo/?utm_source=smartcrawl&utm_medium=plugin&utm_campaign=smartcrawl_dash_crawl_pro_tag"
			target="_blank">
			<span
				class="sui-tag sui-tag-pro sui-tooltip"
				data-tooltip="<?php esc_attr_e( 'Upgrade to SmartCrawl Pro', 'wds' ); ?>">
				<?php esc_html_e( 'Pro', 'wds' ); ?>
			</span>
		</a>
		<p>
			<small>
				<?php
				printf(
					/* translators: 1,2: strong tag, 3: plugin title */
					esc_html__( 'Automatically schedule %1$s%3$s%2$s to run check for URLs that are missing from your Sitemap.', 'wds' ),
					'<strong>',
					'</strong>',
					esc_html( \smartcrawl_get_plugin_title() )
				);
				?>
			</small>
		</p>
	<?php endif; ?>
</div>