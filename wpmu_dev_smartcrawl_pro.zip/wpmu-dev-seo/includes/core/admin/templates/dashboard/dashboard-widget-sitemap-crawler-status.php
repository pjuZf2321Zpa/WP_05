<?php
/**
 * Template: Dashboard Sitemap Widget Crawler Status.
 *
 * @package SmartCrawl
 */

namespace SmartCrawl;

use SmartCrawl\Services\Service;

$sitemap_enabled           = ! empty( $sitemap_enabled );
$sitemap_crawler_available = ! empty( $sitemap_crawler_available );
$is_member                 = Service::get( Service::SERVICE_SITE )->is_member();

if ( ! $sitemap_enabled || ! $is_member || ! $sitemap_crawler_available ) {
	return;
}

$this->render_view(
	'url-crawl-master',
	array(
		'progress_template' => 'dashboard/dashboard-box-title-url-crawl-in-progress',
		'ready_template'    => 'dashboard/dashboard-box-title-url-crawl-stats',
	)
);