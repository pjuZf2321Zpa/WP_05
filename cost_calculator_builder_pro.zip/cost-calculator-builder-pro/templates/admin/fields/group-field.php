<div class="cbb-edit-field-container">
	<div class="ccb-edit-field-header">
		<div class="ccb-edit-field-header-left">
			<span class="ccb-edit-field-title ccb-heading-3 ccb-bold">{{ getFieldTitle(groupField) }}</span>
		</div>
		<div class="ccb-edit-field-header-right">
			<div class="ccb-save-wrapper">
				<button class="ccb-button" @click.prevent="$emit( 'cancel' )"><?php esc_html_e( 'Cancel', 'cost-calculator-builder' ); ?></button>
				<button class="ccb-button success" @click.prevent="save(groupField, id, index, groupField.alias)"><?php esc_html_e( 'Done', 'cost-calculator-builder' ); ?></button>
			</div>
		</div>
	</div>
	<div class="ccb-grid-box">
		<div class="container">
			<div class="row ccb-p-t-15">
				<div class="col-12">
					<div class="ccb-field-name">
						<div class="ccb-field-name__header">
							<div class="ccb-field-name__label"><?php esc_html_e( 'Element name', 'cost-calculator-builder' ); ?></div>
							<div class="ccb-field-name__id">{{ groupField.alias }}</div>
						</div>
						<div class="ccb-field-name__body">
							<input type="text" placeholder="<?php esc_attr_e( 'Enter field name', 'cost-calculator-builder' ); ?>" v-model.trim="groupField.label">
							<div class="ccb-checkbox">
								<input type="checkbox" id="showTitle" v-model="groupField.showTitle">
								<label for="showTitle"><?php esc_html_e( 'Show Name', 'cost-calculator-builder-pro' ); ?></label>
							</div>
						</div>
					</div>
				</div>
			</div>

			<div class="row group-name-input-row">
				<div class="col-12 ccb-p-t-20">
					<div class="list-header">
						<div class="ccb-switch">
							<input type="checkbox" v-model="groupField.collapsible">
							<label></label>
						</div>
						<h6><?php esc_html_e( 'Make this group collapsible', 'cost-calculator-builder-pro' ); ?></h6>
					</div>
				</div>
				<div class="col-12 ccb-p-t-20" v-if="groupField.collapsible">
					<div class="list-header">
						<div class="ccb-switch">
							<input type="checkbox" v-model="groupField.collapse" @change="() => updateCollapse('collapse')">
							<label></label>
						</div>
						<h6><?php esc_html_e( 'Collapse this group by default', 'cost-calculator-builder-pro' ); ?></h6>
					</div>
					<div class="list-header accordion-mode ccb-p-t-20">
						<div class="ccb-switch">
							<input type="checkbox" v-model="groupField.accordion" @change="updateCollapse">
							<label></label>
						</div>
						<div class="switch-extra-text">
							<h6><?php esc_html_e( 'Accordion mode', 'cost-calculator-builder-pro' ); ?></h6>
							<p><?php esc_html_e( 'This makes that only one Group element is open at a time, and it is applied to all Group fields in the calculator.', 'cost-calculator-builder-pro' ); ?></p>
						</div>
					</div>
				</div>
				<div class="col-12 ccb-p-t-20">
					<div class="list-header group-field-setting">
						<div class="ccb-switch">
							<input type="checkbox" v-model="groupField.hidden">
							<label></label>
						</div>
						<div class="switch-extra-text">
							<h6><?php esc_html_e( 'Show this group based on condition', 'cost-calculator-builder-pro' ); ?></h6>
							<p><?php esc_html_e( 'This makes the group hidden by default. Open "Conditions" tab and create a condition with this field so users can reveal it.', 'cost-calculator-builder-pro' ); ?></p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
