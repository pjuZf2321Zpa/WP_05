<div class="cbb-edit-field-container">
	<div class="ccb-edit-field-header">
		<div class="ccb-edit-field-header-left">
			<span class="ccb-edit-field-title ccb-heading-3 ccb-bold">{{ getFieldTitle(repeaterField) }}</span>
		</div>
		<div class="ccb-edit-field-header-right">
			<div class="ccb-save-wrapper">
				<button class="ccb-button" @click.prevent="$emit( 'cancel' )"><?php esc_html_e( 'Cancel', 'cost-calculator-builder' ); ?></button>
				<button class="ccb-button success" @click.prevent="save(repeaterField, id, index, repeaterField.alias)"><?php esc_html_e( 'Done', 'cost-calculator-builder' ); ?></button>
			</div>
		</div>
	</div>
	<div class="ccb-grid-box">
		<div class="container">
			<div class="row ccb-p-t-15">
					<div class="col-12">
						<div class="ccb-field-name">
							<div class="ccb-field-name__header">
								<div class="ccb-field-name__label"><?php esc_html_e( 'Element name', 'cost-calculator-builder' ); ?></div>
								<div class="ccb-field-name__id">{{ repeaterField.alias }}</div>
							</div>
							<div class="ccb-field-name__body">
								<input type="text" placeholder="<?php esc_attr_e( 'Enter field name', 'cost-calculator-builder' ); ?>" v-model.trim="repeaterField.label">
							</div>
						</div>
					</div>
				</div>
			<div class="row ccb-p-t-20">
				<div class="col-6">
					<div class="ccb-input-wrapper">
						<span class="ccb-input-label"><?php esc_html_e( '"Add" Button Label', 'cost-calculator-builder-pro' ); ?></span>
						<input type="text" v-model.trim="repeaterField.addButtonLabel" placeholder="<?php esc_attr_e( 'Enter field name', 'cost-calculator-builder-pro' ); ?>">
					</div>
				</div>
				<div class="col-6">
					<div class="ccb-input-wrapper">
						<span class="ccb-input-label"><?php esc_html_e( '"Remove" Button Label', 'cost-calculator-builder-pro' ); ?></span>
						<input type="text" v-model.trim="repeaterField.removeButtonLabel" placeholder="<?php esc_attr_e( 'Enter field name', 'cost-calculator-builder-pro' ); ?>">
					</div>
				</div>
				<div class="col-6">
					<div class="ccb-input-wrapper number">
						<span class="ccb-input-label"><?php esc_html_e( 'Repeat Limit', 'cost-calculator-builder-pro' ); ?></span>
						<div class="ccb-input-box">
							<input type="text" name="repeatCount" min="0" step="1"  @keypress="repeatMinValue" v-model="repeaterField.repeatCount" placeholder="<?php esc_attr_e( 'Enter field step', 'cost-calculator-builder-pro' ); ?>">
							<span @click="numberCounterAction('repeatCount')" class="input-number-counter up"></span>
							<span @click="numberCounterAction('repeatCount', '-')" class="input-number-counter down"></span>
						</div>
					</div>
				</div>
			</div>
			<div class="row ccb-p-t-20">
				<div class="col-12">
					<div class="list-header">
						<div class="ccb-switch">
							<input type="checkbox" v-model="repeaterField.collapseOnAddAnother" @change="() => toggleHandler('collapseOnAddAnother')">
							<label></label>
						</div>
						<h6><?php esc_html_e( 'Collapse on Add Another', 'cost-calculator-builder-pro' ); ?></h6>
					</div>
				</div>
			</div>
			<div class="row ccb-p-t-20">
				<div class="col-12">
					<div class="list-header">
						<div class="ccb-switch">
							<input type="checkbox" v-model="repeaterField.sumAllAvailable" @change="() => toggleHandler('sumAllAvailable')">
							<label></label>
						</div>
						<h6><?php esc_html_e( 'Sum Up All fields', 'cost-calculator-builder-pro' ); ?></h6>
					</div>
				</div>
			</div>
			<div class="row ccb-p-t-20">
				<div class="col-12">
					<div class="list-header">
						<div class="ccb-switch">
							<input type="checkbox" v-model="repeaterField.enableFormula" @change="() => toggleHandler('enableFormula')">
							<label></label>
						</div>
						<h6><?php esc_html_e( 'Use Formula', 'cost-calculator-builder-pro' ); ?></h6>
					</div>
				</div>
			</div>
			<div class="row ccb-p-t-20" v-if="repeaterField.enableFormula">
				<div class="col-12">
					<div class="list-header">
						<div class="ccb-switch">
							<input type="checkbox" v-model="repeaterField.advancedJsCalculation"/>
							<label></label>
						</div>
						<h6><?php esc_html_e( 'Advanced calculations', 'cost-calculator-builder-pro' ); ?></h6>
						<span class="ccb-options-tooltip">
							<i class="ccb-icon-circle-question"></i>
							<span class="ccb-options-tooltip__text"><?php esc_html_e( 'Enable for advanced calculations using JavaScript-based formulas. With over 9 totals, performance may slow. Disable for faster basic calculations.' ); ?></span>
						</span>
					</div>
				</div>
			</div>
			<div v-if="repeaterField.enableFormula">
				<div class="row ccb-p-t-20" v-if="errorMessage.length > 0">
					<div class="col-12">
						<div class="ccb-formula-message-errors">
							<p class="ccb-formula-error-message" v-for="(item) in errorMessage">
								{{ item.message }}
							</p>
						</div>
					</div>
				</div>
				<div class="row ccb-p-t-20" v-if="openFormula">
					<div class="col-12">
						<formula-field @change="change" @error="setErrors" :id="repeaterField._id" v-model="costCalcLetterFormula" :available_fields="available_fields"/>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
