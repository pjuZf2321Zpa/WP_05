<?php

namespace cBuilder\Classes;

use cBuilder\Helpers\CCBCleanHelper;
use cBuilder\Classes\Database\CalcOrders;
use cBuilder\Classes\Database\OrdersPayments;
use cBuilder\Classes\Database\OrdersStatuses;
use cBuilder\Classes\CCBOrderController;

class CCBPayments {
	public static $total;
	public static $calculatorId     = array();
	public static $promocodes       = array();
	public static $params           = array();
	public static $paymentSettings  = array();
	public static $settings         = array();
	public static $general_settings = array();
	public static $customer         = array();
	public static $order            = array();
	public static $payment          = array();
	public static $uploaded_files   = array();
	public static $errors           = array(
		'no_payment'  => 'No payment method',
		'no_action'   => 'No action',
		'no_nonce'    => 'nonce',
		'no_calc_id'  => 'No calculator id',
		'no_settings' => 'No settings',
		'no_order'    => 'Order not found',
	);
	protected static $paymentMethod = '';
	protected static $actionType    = 'render';

	/** @var \string[][]
	 * CCBWooCheckout not used here for now
	 */
	protected static $availablePayments = array(
		array(
			'name'  => 'paypal',
			'class' => 'cBuilder\Classes\Payments\CCBPayPal',
		),
		array(
			'name'  => 'stripe',
			'class' => 'cBuilder\Classes\Payments\CCBStripe',
		),
		array(
			'name'  => 'cash_payment',
			'class' => 'cBuilder\Classes\Payments\CCBCashPayment',
		),
		array(
			'name'  => 'twoCheckout',
			'class' => 'cBuilder\Classes\Payments\CCBTwoCheckout',
		),
		array(
			'name'  => 'razorpay',
			'class' => 'cBuilder\Classes\Payments\CCBRazorPay',
		),
	);
	protected static $permittedActions  = array( 'ccb_payment' );
	protected static $paymentNonce      = 'ccb_payment';

	/**
	 * return payment class from $availablePayments
	 *
	 * @return string
	 */
	private static function getPaymentClass() {
		$error = array(
			'status'  => 'error',
			'success' => false,
			'message' => self::$errors['no_payment'],
		);

		if ( ! array_key_exists( 'paymentMethod', self::$params ) || ( array_key_exists( 'paymentMethod', self::$params ) && ! in_array( self::$params['paymentMethod'], array_column( self::$availablePayments, 'name' ), true ) ) ) {
			wp_send_json( $error );
		}

		$paymentKey = array_search( self::$params['paymentMethod'], array_column( self::$availablePayments, 'name' ), true );
		if ( false === $paymentKey ) {
			wp_send_json( $error );
		}

		if ( ! class_exists( self::$availablePayments[ $paymentKey ]['class'] ) ) {
			wp_send_json( $error );
		}

		return self::$availablePayments[ $paymentKey ]['class'];
	}

	/** render payment by cls */
	public static function renderPayment( $data, $order_id, $uploaded_files = array() ) {
		self::setPaymentData( $data, $order_id, $uploaded_files );

		$paymentCls = self::getPaymentClass();
		$result     = $paymentCls::{ self::$actionType }();

		wp_send_json( $result );
	}

	public static function renderPaymentNoParams() {
		$data = null;

		if ( isset( $_POST['data'] ) ) {
			$data = ccb_convert_from_btoa( $_POST['data'] );
			if ( ! ccb_is_convert_correct( $data ) ) {
				wp_send_json(
					array(
						'status'  => 'error',
						'success' => false,
						'message' => 'Invalid data',
					)
				);
			}
		}

		$data = CCBCleanHelper::cleanData( (array) json_decode( stripslashes( $data ) ) );

		if ( ! empty( $data['id'] ) && empty( $data['calcId'] ) ) {
			$data['calcId'] = $data['id'];
		}

		$order_id = $data['orderId'] ?? null;
		if ( is_null( $order_id ) ) {
			wp_send_json(
				array(
					'status'  => 'error',
					'success' => false,
					'message' => 'Invalid data',
				)
			);
		}

		self::setPaymentData( $data, $order_id );

		if ( 'stripe' === $data['paymentMethod'] ) {
			$result = \cBuilder\Classes\Payments\CCBStripe::intent_payment( $data, $order_id );
		} else {
			$paymentCls = self::getPaymentClass();
			$result     = $paymentCls::{ self::$actionType }();
		}

		wp_send_json( $result );
	}

	private static function validate( $data, $order_id ) {
		self::$params = $data;
		$order_data   = CalcOrders::get_order_full_data_by_id( $order_id );
		$calc_totals  = ! empty( $order_data['totals'] ) ? $order_data['totals'] : array();
		$otherTotals  = ! empty( $order_data['other_totals'] ) ? $order_data['other_totals'] : array();
		$calc_title   = ! empty( $order_data['calc_title'] ) ? $order_data['calc_title'] : '';
		$fields       = ! empty( $order_data['calculator_fields'] ) ? $order_data['calculator_fields'] : array();

		self::$params['item_name']           = $calc_title;
		self::$params['calcTotals']          = $calc_totals;
		self::$params['calcTotalsConverted'] = $calc_totals;
		self::$params['otherTotals']         = $otherTotals;
		self::$params['fields']              = $fields;
		self::$promocodes                    = ! empty( $order_data['promocodes'] ) ? $order_data['promocodes'] : array();

		/** check payment method */
		if ( ! array_key_exists( 'paymentMethod', self::$params ) || ( array_key_exists( 'paymentMethod', self::$params ) && ! in_array( self::$params['paymentMethod'], array_column( self::$availablePayments, 'name' ), true ) ) ) {
			wp_send_json(
				array(
					'status'  => 'error',
					'success' => false,
					'message' => self::$errors['no_payment'],
				)
			);
		}

		self::$paymentMethod = self::$params['paymentMethod'];

		/** check calculator id */
		if ( ! array_key_exists( 'id', self::$params ) || ! self::$params['id'] ) {
			wp_send_json(
				array(
					'status'  => 'error',
					'success' => false,
					'message' => self::$errors['no_calc_id'],
				)
			);
		}

		if ( array_key_exists( 'action_type', self::$params ) && in_array( self::$params['action_type'], array( 'render', 'intent_payment' ), true ) ) {
			self::$actionType = self::$params['action_type'];
		}
	}

	/** set and validate send data */
	public static function setPaymentData( $data, $order_id, $uploaded_files = array() ) {
		self::validate( $data, $order_id );

		self::$calculatorId    = self::$params['id'];
		self::$settings        = self::getSettings();
		self::$paymentSettings = self::getPaymentSettings();
		self::$total           = self::getTotal();
		self::$uploaded_files  = $uploaded_files;

		if ( ! self::$paymentSettings ) {
			wp_send_json(
				array(
					'status'  => 'error',
					'success' => false,
					'message' => self::$errors['no_settings'],
				)
			);
			wp_die();
		}

		if ( ! is_null( self::$total ) && intval( self::$total ) <= 0 && 'cash_payment' !== self::$params['paymentMethod'] ) {
			wp_send_json(
				array(
					'success' => false,
					'status'  => 'error',
					'message' => __( 'Total must be more then 0', 'cost-calculator-builder-pro' ),
				)
			);
			wp_die();
		}

		if ( ! array_key_exists( 'orderId', self::$params ) || ! self::$params['orderId'] ) {
			wp_send_json(
				array(
					'success' => false,
					'status'  => 'error',
					'message' => self::$errors['no_order'],
				)
			);
			wp_die();
		}

		/** set payment method to order */
		self::$order = CalcOrders::get_order_full_data_by_id( self::$params['orderId'] );
		/** if order id exist, but order not found return error */
		if ( null === self::$order ) {
			wp_send_json(
				array(
					'status'  => 'error',
					'success' => false,
					'message' => self::$errors['no_order'],
				)
			);
		}

		self::$payment = OrdersPayments::get_payment_by_order_id( self::$params['orderId'] );

		if ( empty( self::$params['paymentAfterSubmit'] ) && 'razorpay' !== self::$paymentMethod ) {
			self::sendEmail();
		}

		/** if no payment , create */
		if ( null === self::$payment ) {
			self::createPayment();
		}

		self::$customer = self::getCustomerData();
		self::$payment  = self::updatePayment();

		do_action( 'ccb_payment_data_updated', self::$customer, self::$params, self::$order, self::$payment );
	}

	/** set payment transaction ( id from payment system ) */
	public static function setPaymentTransaction( $orderId, $transaction ) {
		$orderId     = sanitize_text_field( $orderId );
		$transaction = sanitize_text_field( $transaction );
		$paymentData = array(
			'transaction' => sanitize_text_field( $transaction ),
			'updated_at'  => wp_date( 'Y-m-d H:i:s' ),
		);

		OrdersPayments::update_payment( $orderId, $paymentData );
	}

	protected static function getCustomerData() {
		if ( empty( self::$order['order_form_details'] ) ) {
			return array();
		}

		$formDetails = self::$order['order_form_details'];
		$customer    = array();
		foreach ( $formDetails as $detail ) {
			$value      = is_array( $detail['value'] ) ? implode( ', ', $detail['value'] ) : $detail['value'];
			$typeOrName = '';

			if ( ! empty( $detail['name'] ) ) {
				$typeOrName = $detail['name'];
			} elseif ( ! empty( $detail['type'] ) ) {
				$typeOrName = $detail['type'];
			} elseif ( ! empty( $detail['attributes'] ) && isset( $detail['attributes']['type'] ) ) {
				$typeOrName = $detail['attributes']['type'];
			}

			if ( ! empty( $typeOrName ) ) {
				$customer[ $typeOrName ] = $value;
			}
		}

		do_action( 'ccb_get_customer_data', $customer );

		return $customer;
	}

	protected static function getSettings() {
		if ( empty( self::$settings ) ) {
			self::$settings = CCBSettingsData::get_calc_single_settings( self::$calculatorId );
		}
		return self::$settings;
	}

	protected static function getGeneralSettings() {
		if ( empty( self::$general_settings ) ) {
			self::$general_settings = get_option( 'ccb_general_settings', CCBSettingsData::general_settings_data() );
		}
		return self::$general_settings;
	}

	protected static function getPaymentSettings() {
		return self::getPaymentSettingsHandler( self::$paymentMethod );
	}

	protected static function getPaymentSettingsHandler( $slug ) {
		$general_settings = self::getPaymentGeneralSettingsBySlug( $slug );
		$settings         = self::getPaymentSettingsBySlug( $slug );

		if ( ! empty( $general_settings ) && ! empty( $general_settings['use_in_all'] ) && ( 'paypal' === $slug || ! empty( $general_settings['enable'] ) ) ) {
			foreach ( $general_settings as $settings_field_key => $settings_field_value ) {
				if ( ! in_array( $settings_field_key, array( 'enable', 'use_in_all' ), true ) ) {
					$settings[ $settings_field_key ] = $settings_field_value;
				}
			}
		}

		return ! empty( $settings ) ? (array) $settings : array();
	}

	protected static function getPaymentGeneralSettingsBySlug( $slug ) {
		$general_settings = self::getGeneralSettings();
		if ( 'paypal' === $slug && isset( $general_settings['payment_gateway'] ) ) {
			return $general_settings['payment_gateway']['paypal'];
		}

		if ( 'cash_payment' === $slug && isset( $general_settings['payment_gateway'] ) ) {
			return $general_settings['payment_gateway']['cash_payment'];
		}

		if ( 'stripe' === $slug && isset( $general_settings['payment_gateway'] ) ) {
			$stripe_settings               = $general_settings['payment_gateway']['cards']['card_payments']['stripe'];
			$stripe_settings['use_in_all'] = $general_settings['payment_gateway']['cards']['use_in_all'];

			return $stripe_settings;
		}

		if ( 'twoCheckout' === $slug && isset( $general_settings['payment_gateway'] ) ) {
			$twoCheckout_settings               = $general_settings['payment_gateway']['cards']['card_payments']['twoCheckout'];
			$twoCheckout_settings['use_in_all'] = $general_settings['payment_gateway']['cards']['use_in_all'];

			return $twoCheckout_settings;
		}

		if ( 'razorpay' === $slug && isset( $general_settings['payment_gateway'] ) ) {
			$razorpay_settings               = $general_settings['payment_gateway']['cards']['card_payments']['razorpay'];
			$razorpay_settings['use_in_all'] = $general_settings['payment_gateway']['cards']['use_in_all'];

			return $razorpay_settings;
		}

		return $general_settings[ $slug ] ?? array();
	}

	protected static function getPaymentSettingsBySlug( $slug ) {
		$settings       = self::getSettings();
		$inner_settings = array();

		if ( 'paypal' === $slug && isset( $settings['payment_gateway'] ) ) {
			$inner_settings = $settings['payment_gateway']['paypal'];
		}

		if ( 'cash_payment' === $slug && isset( $settings['payment_gateway'] ) ) {
			$inner_settings = $settings['payment_gateway']['cash_payment'];
		}

		if ( 'stripe' === $slug && isset( $settings['payment_gateway'] ) ) {
			$inner_settings = $settings['payment_gateway']['cards']['card_payments']['stripe'];
		}

		if ( 'twoCheckout' === $slug && isset( $settings['payment_gateway'] ) ) {
			$inner_settings = $settings['payment_gateway']['cards']['card_payments']['twoCheckout'];
		}

		if ( 'razorpay' === $slug && isset( $settings['payment_gateway'] ) ) {
			$inner_settings = $settings['payment_gateway']['cards']['card_payments']['razorpay'];
		}

		if ( ! empty( $inner_settings ) ) {
			$inner_settings['formulas'] = $settings['payment_gateway']['formulas'];
			return $inner_settings;
		}

		return $settings[ $slug ] ?? array();
	}

	protected static function getTotal() {
		$total = 0;

		if ( count( self::$params['calcTotals'] ) > 0 ) {
			if ( ! empty( self::$paymentSettings['formulas'] ) ) {
				foreach ( self::$paymentSettings['formulas'] as $formula ) {
					foreach ( self::$params['calcTotals'] as $value ) {
						$total_value = isset( $value['total'] ) ? $value['total'] : ( isset( $value['value'] ) ? $value['value'] : 0 );
						if ( isset( $formula['alias'] ) && isset( $value['alias'] ) && $value['alias'] === $formula['alias'] ) {
							$total += floatval( $total_value );
						} elseif ( 1 === count( self::$paymentSettings['formulas'] ) && ! isset( $formula['alias'] ) ) {
							$total += floatval( $total_value );
						}
					}
				}
			}
		}

		if ( empty( $total ) && ! empty( self::$params['calcTotals'] ) ) {
			if ( ! empty( self::$params['calcTotals'][0]['total'] ) ) {
				$total = self::$params['calcTotals'][0]['total'];
			} elseif ( self::$params['calcTotals'][0]['value'] ) {
				$total = self::$params['calcTotals'][0]['value'];
			}
		}

		return $total;
	}

	protected static function createPayment() {
		$default_status = OrdersStatuses::get_default_status();
		$paymentData    = array(
			'order_id'       => self::$params['orderId'],
			'payment_type'   => self::$paymentMethod,
			'payment_status' => $default_status['id'],
			'total'          => self::$total,
		);
		OrdersPayments::create_payment( self::$params['orderId'], $paymentData );
	}

	protected static function updatePayment() {
		$payment_data = array();
		if ( ! empty( self::$total ) ) {
			$payment_data['total'] = self::$total;
		}
		if ( ! empty( self::$paymentMethod ) ) {
			$payment_data['payment_type'] = self::$paymentMethod;
		}

		OrdersPayments::update_payment( self::$params['orderId'], $payment_data );

		return OrdersPayments::get_payment_by_order_id( self::$params['orderId'] );
	}

	protected static function sendEmail( $data = array(), $orderId = null ) {
		$fields = array();
		if ( ! is_null( $orderId ) ) {
			self::$order = CalcOrders::get_order_full_data_by_id( $orderId );
			$fields      = self::$order['calculator_fields'];
		} elseif ( ! empty( $orderId ) ) {
			$order_data = CalcOrders::get_order_full_data_by_id( $orderId );
			$fields     = $order_data['calculator_fields'];
		} else {
			$fields = self::$params['fields'];
		}

		$formDetails = array();
		if ( ! empty( self::$order ) && ! empty( self::$order['order_form_details'] ) ) {
			$formDetails = self::$order['order_form_details'];
		}

		if ( ! empty( $formDetails ) ) {
			if ( empty( self::$calculatorId ) && ! empty( $data['id'] ) ) {
				self::$calculatorId = $data['id'];
			}

			if ( empty( self::$settings ) && ! empty( $data['id'] ) ) {
				self::$settings = self::getSettings();
			}

			if ( empty( self::$params ) && ! empty( $data['id'] ) ) {
				self::$params = $data;
			}

			$subject       = '';
			$user_email    = '';
			$custom_emails = array();
			$client_email  = '';

			foreach ( $formDetails as $field ) {
				if ( ! empty( $field['type'] ) && 'email' === $field['type'] && ! empty( $field['is_primary'] ) ) {
					$client_email = $field['value'];
				}
			}

			if ( isset( self::$settings['formFields'] ) ) {
				if ( isset( self::$settings['formFields']['emailSubject'] ) ) {
					$subject = self::$settings['formFields']['emailSubject'];
				}

				if ( isset( self::$settings['formFields']['adminEmailAddress'] ) ) {
					$user_email = self::$settings['formFields']['adminEmailAddress'];
				}

				if ( isset( self::$settings['formFields']['customEmailAddresses'] ) ) {
					$custom_emails = self::$settings['formFields']['customEmailAddresses'];
				}
			}

			$subject = apply_filters( 'cbb_email_subject', $subject, self::$params['id'] );

			$general_settings = CCBSettingsData::get_calc_global_settings();
			$attachments      = array();

			/** upload files, get  $file_urls */
			$file_urls = CCBContactForm::add_files( self::$params, self::$uploaded_files );

			if ( count( $file_urls ) > 0 ) {
				foreach ( $file_urls as $file_item ) {
					$attachments = array_merge( $attachments, array_column( $file_item, 'file' ) );
				}
			}

			$attachments = apply_filters( 'ccb_email_attachment', $attachments, self::$params );

			$args = array(
				'fields'         => $fields,
				'send_fields'    => $formDetails,
				'totals'         => self::$params['calcTotals'],
				'other_totals'   => self::$params['otherTotals'],
				'email_settings' => $general_settings['email_templates'],
				'files'          => $file_urls,
				'show_unit'      => self::$params['showUnit'] ?? '',
				'calc_id'        => self::$params['id'],
				'orderId'        => self::$params['orderId'],
				'promocodes'     => self::$promocodes,
			);

			CCBContactForm::sendEmail(
				array(
					'args'          => $args,
					'calcId'        => self::$params['id'],
					'client_email'  => $client_email,
					'subject'       => $subject,
					'attachments'   => $attachments,
					'user_email'    => $user_email,
					'custom_emails' => $custom_emails,
				)
			);
		}
	}
}
