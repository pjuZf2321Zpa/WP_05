<?php

namespace cBuilder\Classes\Payments;

use cBuilder\Classes\CCBPayments;
use cBuilder\Classes\Database\OrdersStatuses;
use cBuilder\Classes\Database\OrdersPayments;
use cBuilder\Classes\Database\CalcOrders;
use Razorpay\Api\Api;

class CCBRazorPay extends CCBPayments {
	public static function render() {
		$api_key    = self::$paymentSettings['keyId'];
		$api_secret = self::$paymentSettings['secretKey'];
		$api        = new Api( $api_key, $api_secret );
		$message    = 'Something went wrong';

		try {
			if ( $api->customer->all() ) {
				$orderData = array(
					'receipt'  => strval( self::$params['orderId'] ),
					'amount'   => intval( self::$total * 100 ),
					'currency' => self::$paymentSettings['currency'],
				);

				$name  = self::$customer['name'] ?? '';
				$email = self::$customer['email'] ?? '';
				$phone = self::$customer['phone'] ?? '';

				$order = CalcOrders::get_order_full_data_by_id( self::$params['orderId'] );

				if ( ! empty( $order ) && ( empty( $name ) || empty( $email ) || empty( $phone ) ) ) {
					$formDetails = $order['order_form_details'];
					if ( isset( $formDetails ) ) {
						foreach ( $formDetails as $detail ) {
							$name = ! empty( $detail['type'] ) ? $detail['type'] : $detail['name'];
							if ( empty( $email ) && in_array( $name, array( 'your-email', 'email' ), true ) ) {
								$email = $detail['value'];
							}

							if ( empty( $phone ) && in_array( $name, array( 'your-phone', 'phone' ), true ) ) {
								$phone = $detail['value'];
							}

							if ( empty( $name ) && in_array( $name, array( 'your-name', 'name' ), true ) ) {
								$name = $detail['value'];
							}
						}
					}
				}

				$razorpayOrder   = $api->order->create( $orderData );
				$razorpayOrderId = $razorpayOrder->id;

				$data = array(
					'amount'   => self::$total * 100,
					'currency' => self::$paymentSettings['currency'],
					'name'     => self::$params['item_name'] ?? '',
					'order_id' => $razorpayOrderId,
					'notes'    => array(
						'ccb_order_id' => self::$params['orderId'],
					),
					'prefill'  => array(
						'name'  => $name,
						'email' => $email,
						'phone' => $phone,
					),
					'theme'    => array(
						'color' => '#1AB163',
					),
				);

				$payment_data = array(
					'payment_type' => 'razorpay',
					'total'        => self::$total,
				);
				OrdersPayments::update_payment( self::$params['orderId'], $payment_data );
				CalcOrders::update_order( self::$params['orderId'], array( 'total_amount' => self::$total ) );

				return array(
					'success' => true,
					'orderId' => self::$params['orderId'],
					'status'  => 'success',
					'message' => esc_html__( 'Payment Received! Thank You for Payment', 'cost-calculator-builder-pro' ),
					'data'    => $data,
				);
			}
		} catch( \Exception $e ){ //phpcs:ignore
			$message = $e->getMessage();
			ccb_write_log( 'Razorpay auth error: ' . $message );
		}

		return array(
			'success' => false,
			'status'  => 'error',
			'message' => $message,
		);
	}

	public static function paymentReceived() {
		check_ajax_referer( 'ccb_razorpay_receive', 'nonce' );

		$result = array(
			'success' => false,
			'message' => 'Something went wrong',
		);

		$data = null;
		if ( isset( $_POST['data'] ) ) {
			$data = ccb_convert_from_btoa( $_POST['data'] );
			if ( ! ccb_is_convert_correct( $data ) ) {
				wp_send_json( $result );
			}
		}

		if ( ! empty( $data ) ) {
			$data = json_decode( stripslashes( $data ), true );
			if ( empty( $data['orderId'] ) ) {
				$result['message'] = 'Order id required';
				wp_send_json( $result );
			}

			$order = CalcOrders::get_order_full_data_by_id( $data['orderId'] );
			if ( ! empty( $order ) ) {
				$data['calcTotalsConverted'] = $order['totals'];
				$data['otherTotals']         = $order['other_totals'];
				$data['calcTotals']          = $order['totals'];
				$data['fields']              = $order['calculator_fields'];

				$result['success'] = true;
				$result['message'] = 'Payment received';

				$complete_status = OrdersStatuses::get_completed_status();
				$payment_data    = array(
					'payment_type'   => 'razorpay',
					'payment_status' => $complete_status['id'],
				);
				OrdersPayments::update_payment( $data['orderId'], $payment_data );

				CCBPayments::sendEmail( $data, $data['orderId'] );
			} else {
				$result['message'] = 'Order not found';
			}
		}

		wp_send_json( $result );

	}
}
