<?php

namespace cBuilder\Classes\Payments;

use cBuilder\Classes\CCBPayments;
use cBuilder\Classes\Database\OrdersStatuses;
use cBuilder\Classes\Database\OrdersPayments;

class CCBCashPayment extends CCBPayments {
	public static function render() {
		$default_status = OrdersStatuses::get_default_status();
		$payment_data   = array(
			'payment_type'   => 'cash_payment',
			'total'          => self::$total,
			'payment_status' => $default_status['id'],
		);

		$payment = OrdersPayments::get_payment_by_order_id( self::$params['orderId'] );
		if ( empty( $payment ) ) {
			OrdersPayments::create_payment( self::$params['orderId'], $payment_data );
		} else {
			$payment_data['updated_at'] = wp_date( 'Y-m-d H:i:s' );
			OrdersPayments::update_payment( self::$params['orderId'], $payment_data );
		}

		return array(
			'success' => true,
			'reload'  => true,
			'status'  => 'success',
			'orderId' => self::$params['orderId'],
			'message' => esc_html__( 'Your order has been placed', 'cost-calculator-builder-pro' ),
		);
	}
}
