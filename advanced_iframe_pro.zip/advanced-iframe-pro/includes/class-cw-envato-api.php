<?php
// not needed anymore because we are now on Freemius
?>