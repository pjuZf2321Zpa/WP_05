/**
 * This is an example how to get infos about the URL of the iframe into 
 * google analytics. So if you like to track URL changes in the iframe in GA 
 * you should continue reading. 
 *
 * Advanced iFrame Pro has the capability to send the URL from the iframe to 
 * the parent and add this to the URL of the browser in different ways. 
 * This feature can be used in combination with this post message converter
 * to trigger google analytics with an info you can extract from the URL.
 * 
 * To configure this you first need to enable the external workaround by 
 * including the ai_external.js to the page in the iframe.
 * then you need to enable the feature "Add iframe URL as param" on the 
 * advanced tab in the section "Url parameter handling" by settings this to 
 * "remote". This configuration is saved to the ai_external.js. 
 * In the shortcode itself you need to set 'add_iframe_url_as_param="false"'
 * that the URL is not modified but only the code of this file is executed.  
 *  
 *  This file has to be stored in the advanced-iframe-custom folder
 *  as: ai_post_message_converter_XXX.js
 *  while XXX is the id of the iframe.
 *
 * Right now is there is a log 
 * console.log("New location: " + newLocation);
 * included so you can check if the method aiConvertPostMessage is called 
 * properly. Please removes this after you have done the full setup.
 */
 /*jshint unused:false*/
var aiLocation = "";

function aiConvertPostMessage(event) {
     try {
       var eventData = JSON.parse(event.data);
	 } catch (e) {
	   // Ignore non json events. 
	   return event;
	 }
     var newLocation = decodeURIComponent(eventData.loc);
     console.log("New location: " + newLocation);
     if (eventData.aitype == "height" && aiLocation != newLocation) {
          if (typeof gtag === 'function') {
              // here you can parse the location of the iframe and call the google analytics gtag function
          }
          aiLocation = newLocation;
     }
     var newData = {
          aitype: eventData.aitype,
          id: eventData.id,
          height: eventData.height,
          width: eventData.width,
          anchor: eventData.anchor

     };
     var newDataJson = JSON.stringify(newData)
     event.data = newDataJson;
     return event;
}