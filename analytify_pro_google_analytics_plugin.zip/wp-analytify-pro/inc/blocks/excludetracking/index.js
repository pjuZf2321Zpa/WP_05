const { registerPlugin } = wp.plugins;
 
// Exclusion_Meta component is used below in JSX
// eslint-disable-next-line no-unused-vars
import Exclusion_Meta from './exclusionMeta';
 
registerPlugin( 'wp-analytify', {
	render() {
		return(<Exclusion_Meta />);
	}
} );
