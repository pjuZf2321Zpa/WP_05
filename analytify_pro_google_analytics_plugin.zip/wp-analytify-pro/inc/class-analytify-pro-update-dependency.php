<?php
/**
 * Pro plugin updates: inactive-license renew notice OR core-first dependency (mutually exclusive).
 *
 * @package WP_Analytify_Pro
 * @since 9.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Analytify_Pro_Update_Dependency', false ) ) {

	/**
	 * Manages Pro update UX on the Plugins screen.
	 *
	 * @since 9.1.0
	 */
	class Analytify_Pro_Update_Dependency {

		/**
		 * Whether hooks have been registered.
		 *
		 * @var bool
		 */
		private static $initialized = false;

		/**
		 * Free plugin basename relative to the plugins directory.
		 *
		 * @var string
		 */
		private static $free_plugin = 'wp-analytify/wp-analytify.php';

		/**
		 * Pro plugin basename relative to the plugins directory.
		 *
		 * @var string
		 */
		private static $pro_plugin = 'wp-analytify-pro/wp-analytify-pro.php';

		/**
		 * Pro plugin slug.
		 *
		 * @var string
		 */
		private static $pro_slug = 'wp-analytify-pro';

		/**
		 * Renew license URL.
		 *
		 * @var string
		 */
		private static $renew_url = 'https://analytify.io/your-account/';

		/**
		 * Changelog URL.
		 *
		 * @var string
		 */
		private static $changelog_url = 'https://analytify.io/changelog/';

		/**
		 * Whether the renew notice markup was already output this request.
		 *
		 * @var bool
		 */
		private static $renew_notice_rendered = false;

		/**
		 * Hook into WordPress.
		 *
		 * @return void
		 */
		public static function init() {
			if ( self::$initialized ) {
				return;
			}

			self::$initialized = true;

			add_action( 'load-plugins.php', array( __CLASS__, 'prime_version_check' ), 19 );

			add_filter( 'site_transient_update_plugins', array( __CLASS__, 'strip_pro_package_if_core_outdated' ), 999, 1 );
			add_filter( 'pre_set_site_transient_update_plugins', array( __CLASS__, 'strip_pro_package_if_core_outdated' ), 9999, 1 );

			add_filter( 'site_transient_update_plugins', array( __CLASS__, 'ensure_pro_update_row_visible' ), 1000, 1 );
			add_filter( 'pre_set_site_transient_update_plugins', array( __CLASS__, 'ensure_pro_update_row_visible' ), 10001, 1 );

			add_action(
				'in_plugin_update_message-' . self::$pro_plugin,
				array( __CLASS__, 'render_pro_update_message' ),
				10,
				2
			);

			add_action( 'admin_print_footer_scripts', array( __CLASS__, 'maybe_disable_pro_bulk_checkbox' ), 99 );
			add_action( 'admin_print_footer_scripts', array( __CLASS__, 'maybe_remove_duplicate_update_rows' ), 100 );
			add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_plugins_screen_styles' ) );
		}

		/**
		 * Fetch latest version from store before WordPress registers update rows.
		 *
		 * @return void
		 */
		public static function prime_version_check() {
			if ( current_user_can( 'update_plugins' ) ) {
				self::resolve_available_pro_version();
			}
		}

		/**
		 * Whether Pro must wait until the free plugin has been updated.
		 *
		 * @since 9.1.0
		 * @param object $transient Update transient.
		 * @return bool
		 */
		private static function should_block_pro_update( $transient ) {
			if ( ! is_object( $transient ) || empty( $transient->response ) || ! is_array( $transient->response ) ) {
				return false;
			}

			return isset( $transient->response[ self::$free_plugin ], $transient->response[ self::$pro_plugin ] );
		}

		/**
		 * Installed Pro version from the plugin header.
		 *
		 * @since 9.1.0
		 * @return string
		 */
		private static function get_installed_version() {
			if ( ! function_exists( 'get_plugin_data' ) ) {
				require_once ABSPATH . 'wp-admin/includes/plugin.php';
			}

			$file = WP_PLUGIN_DIR . '/' . self::$pro_plugin;
			if ( ! file_exists( $file ) ) {
				return defined( 'ANALYTIFY_PRO_VERSION' ) ? ANALYTIFY_PRO_VERSION : '';
			}

			$data = get_plugin_data( $file, false, false );
			return isset( $data['Version'] ) ? (string) $data['Version'] : '';
		}

		/**
		 * One-click upgrade URL for the free Analytify Dashboard plugin.
		 *
		 * @since 9.1.0
		 * @return string
		 */
		private static function get_core_dashboard_upgrade_url() {
			$action = 'upgrade-plugin';
			$plugin = self::$free_plugin;

			return wp_nonce_url(
				add_query_arg(
					array(
						'action' => $action,
						'plugin' => $plugin,
					),
					admin_url( 'update.php' )
				),
				$action . '_' . $plugin
			);
		}

		/**
		 * Whether the Pro license blocks updates (expired, missing, or not valid).
		 *
		 * @since 9.1.0
		 * @return bool
		 */
		private static function is_license_inactive_for_updates() {
			if ( class_exists( 'WP_Analytify_Pro' ) ) {
				$pro = WP_Analytify_Pro::instance();
				if ( $pro && method_exists( $pro, 'is_license_active_for_updates' ) ) {
					return ! $pro->is_license_active_for_updates();
				}
			}

			$key = trim( (string) get_option( 'analytify_license_key', '' ) );
			if ( '' === $key ) {
				return true;
			}

			if ( false === get_option( 'analytify_license_status', false ) ) {
				return true;
			}

			$status = get_option( 'analytify_license_status', '' );
			if ( ! is_string( $status ) ) {
				return true;
			}

			return 'valid' !== strtolower( trim( $status ) );
		}

		/**
		 * Fetch latest Pro version from the Analytify store API.
		 *
		 * @since 9.1.0
		 * @return string Empty string on failure.
		 */
		private static function fetch_latest_version_from_store() {
			$store_url = defined( 'ANALYTIFY_STORE_URL' ) ? ANALYTIFY_STORE_URL : 'https://analytify.io/';
			$item_id   = defined( 'ANALYTIFY_PRO_ID' ) ? ANALYTIFY_PRO_ID : '10';
			$license   = trim( (string) get_option( 'analytify_license_key', '' ) );

			$params = array(
				'edd_action' => 'get_version',
				'item_id'    => $item_id,
				'url'        => home_url(),
			);

			if ( '' !== $license ) {
				$params['license'] = $license;
			}

			$response = wp_remote_get(
				add_query_arg( $params, $store_url ),
				array(
					'timeout'   => 15,
					'sslverify' => false,
				)
			);

			if ( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
				return '';
			}

			$body = json_decode( wp_remote_retrieve_body( $response ) );
			if ( is_object( $body ) && ! empty( $body->new_version ) ) {
				set_site_transient( 'wp_analytify_check_latest_version', $body->new_version, 12 * HOUR_IN_SECONDS );
				return (string) $body->new_version;
			}

			return '';
		}

		/**
		 * Resolve the best-known latest Pro version from transient, cache, or API.
		 *
		 * @since 9.1.0
		 * @param object|null $transient Update transient.
		 * @return string Empty string when unknown.
		 */
		private static function resolve_available_pro_version( $transient = null ) {
			if ( null === $transient ) {
				$transient = get_site_transient( 'update_plugins' );
			}

			if ( is_object( $transient ) ) {
				foreach ( array( 'response', 'no_update' ) as $bucket ) {
					if ( empty( $transient->{$bucket}[ self::$pro_plugin ] ) ) {
						continue;
					}
					$entry = $transient->{$bucket}[ self::$pro_plugin ];
					if ( is_object( $entry ) && ! empty( $entry->new_version ) ) {
						return (string) $entry->new_version;
					}
				}
			}

			$cached = get_site_transient( 'wp_analytify_check_latest_version' );
			if ( is_string( $cached ) && '' !== $cached ) {
				return $cached;
			}

			if ( class_exists( 'WP_Analytify_Pro' ) ) {
				$key = trim( (string) get_option( 'analytify_license_key', '' ) );
				if ( '' !== $key ) {
					$pro = WP_Analytify_Pro::instance();
					if ( $pro && method_exists( $pro, 'get_latest_version' ) ) {
						$latest = (string) $pro->get_latest_version( $key );
						if ( '' !== $latest ) {
							set_site_transient( 'wp_analytify_check_latest_version', $latest, 12 * HOUR_IN_SECONDS );
							return $latest;
						}
					}
				}
			}

			return self::fetch_latest_version_from_store();
		}

		/**
		 * Whether installed Pro is older than the latest known version.
		 *
		 * @param object|null $transient Update transient.
		 * @return bool
		 */
		private static function has_pro_version_update( $transient = null ) {
			$installed = self::get_installed_version();
			$latest    = self::resolve_available_pro_version( $transient );

			return '' !== $installed && '' !== $latest && version_compare( $installed, $latest, '<' );
		}

		/**
		 * Whether Pro can be updated now (newer version exists and core is not blocking).
		 *
		 * @param object|null $transient Update transient.
		 * @return bool
		 */
		private static function has_pro_update_available( $transient = null ) {
			if ( null === $transient ) {
				$transient = get_site_transient( 'update_plugins' );
			}

			if ( self::should_block_pro_update( $transient ) ) {
				return false;
			}

			return self::has_pro_version_update( $transient );
		}

		/**
		 * Whether WordPress will render the default Pro update row from the transient.
		 *
		 * @since 9.1.0
		 * @param object|null $transient Update transient.
		 * @return bool
		 */
		private static function is_pro_update_ready( $transient = null ) {
			if ( null === $transient ) {
				$transient = get_site_transient( 'update_plugins' );
			}

			if ( ! is_object( $transient ) || empty( $transient->response[ self::$pro_plugin ] ) ) {
				return false;
			}

			return ! isset( $transient->response[ self::$free_plugin ] );
		}

		/**
		 * Inject Pro into update_plugins when a newer version is known.
		 *
		 * @param mixed $transient Transient value.
		 * @return mixed
		 */
		public static function ensure_pro_update_row_visible( $transient ) {
			// Still show the Pro update row when license is inactive, even if core is also pending.
			if ( self::should_block_pro_update( $transient ) && ! self::is_license_inactive_for_updates() ) {
				return $transient;
			}

			$installed   = self::get_installed_version();
			$new_version = self::resolve_available_pro_version( $transient );

			if ( '' === $installed || '' === $new_version || ! version_compare( $installed, $new_version, '<' ) ) {
				return $transient;
			}

			if ( ! is_object( $transient ) ) {
				$transient = new stdClass();
			}
			if ( ! isset( $transient->response ) || ! is_array( $transient->response ) ) {
				$transient->response = array();
			}

			if ( ! isset( $transient->response[ self::$pro_plugin ] ) || ! is_object( $transient->response[ self::$pro_plugin ] ) ) {
				$transient->response[ self::$pro_plugin ] = new stdClass();
			}

			$entry              = $transient->response[ self::$pro_plugin ];
			$entry->slug        = self::$pro_slug;
			$entry->plugin      = self::$pro_plugin;
			$entry->id          = self::$pro_plugin;
			$entry->new_version = $new_version;
			$entry->url         = isset( $entry->url ) ? $entry->url : 'https://analytify.io/';

			if ( self::is_license_inactive_for_updates() ) {
				$entry->package       = false;
				$entry->download_link = '';
			}

			return $transient;
		}

		/**
		 * Remove Pro download package while the free plugin still has a pending update.
		 *
		 * @since 9.1.0
		 * @param mixed $transient Transient value.
		 * @return mixed
		 */
		public static function strip_pro_package_if_core_outdated( $transient ) {
			if ( ! self::should_block_pro_update( $transient ) ) {
				return $transient;
			}

			if ( isset( $transient->response[ self::$pro_plugin ] ) && is_object( $transient->response[ self::$pro_plugin ] ) ) {
				$transient->response[ self::$pro_plugin ]->package       = false;
				$transient->response[ self::$pro_plugin ]->download_link = '';
			}

			return $transient;
		}

		/**
		 * Messages inside the WordPress update row.
		 *
		 * @param array  $plugin_data Plugin data.
		 * @param object $response    Update response.
		 * @return void
		 */
		public static function render_pro_update_message( $plugin_data, $response ) {
			if ( ! is_array( $plugin_data ) ) {
				return;
			}

			$pending = get_site_transient( 'update_plugins' );
			$update  = self::normalize_pro_update_response( $response, $pending );

			if ( ! $update ) {
				return;
			}

			$core_blocks  = self::should_block_pro_update( $pending );
			$has_update   = self::has_pro_version_update( $pending );
			$license_dead = self::is_license_inactive_for_updates();

			$new_version = ! empty( $update->new_version ) ? (string) $update->new_version : self::resolve_available_pro_version( $pending );

			// Inactive license: renew only. Core dependency shows after license is active again.
			$show_renew_notice = $license_dead && $has_update && '' !== $new_version;
			$show_core_notice  = $core_blocks && ! $license_dead;

			if ( ! $show_core_notice && ! $show_renew_notice ) {
				return;
			}

			// Replace default WordPress / EDD update copy with our notice stack.
			echo '</p>';

			if ( $show_renew_notice ) {
				self::render_renew_notice_box( $plugin_data, $new_version );
			} elseif ( $show_core_notice ) {
				self::render_core_dependency_notice_box( $plugin_data, $update, $new_version );
			}

			echo '<p class="analytify-pro-plugin-update-notice-dummy">';
		}

		/**
		 * Resolve update metadata (WordPress object or EDD passing plugin array).
		 *
		 * @since 9.1.0
		 * @param mixed       $response Hook second argument.
		 * @param object|null $pending  update_plugins transient.
		 * @return object|null
		 */
		private static function normalize_pro_update_response( $response, $pending ) {
			if ( is_object( $response ) && ! empty( $response->new_version ) ) {
				return $response;
			}

			if ( is_object( $pending ) && isset( $pending->response[ self::$pro_plugin ] ) ) {
				$entry = $pending->response[ self::$pro_plugin ];
				if ( is_object( $entry ) ) {
					return $entry;
				}
			}

			$latest = self::resolve_available_pro_version( $pending );
			if ( '' === $latest ) {
				return null;
			}

			return (object) array(
				'slug'        => self::$pro_slug,
				'plugin'      => self::$pro_plugin,
				'new_version' => $latest,
				'url'         => 'https://analytify.io/',
			);
		}

		/**
		 * Thickbox changelog URL for “View version X details”.
		 *
		 * @since 9.1.0
		 * @param array  $plugin_data Plugin header data.
		 * @param object $response    Update response object.
		 * @return string Empty when unavailable.
		 */
		private static function get_pro_version_details_url( $plugin_data, $response ) {
			if ( ! empty( $response->sections ) && is_object( $response->sections ) && ! empty( $response->sections->changelog ) ) {
				return add_query_arg(
					array(
						'edd_sl_action' => 'view_plugin_changelog',
						'plugin'        => rawurlencode( self::$pro_plugin ),
						'slug'          => rawurlencode( self::$pro_slug ),
						'TB_iframe'     => 'true',
						'width'         => 77,
						'height'        => 911,
					),
					self_admin_url( 'index.php' )
				);
			}

			$plugin_slug = isset( $response->slug ) ? (string) $response->slug : self::$pro_slug;

			if ( isset( $response->slug ) ) {
				$details_url = self_admin_url( 'plugin-install.php?tab=plugin-information&plugin=' . $plugin_slug . '&section=changelog' );
			} elseif ( ! empty( $response->url ) ) {
				$details_url = (string) $response->url;
			} else {
				$details_url = isset( $plugin_data['PluginURI'] ) ? (string) $plugin_data['PluginURI'] : '';
			}

			if ( '' === $details_url ) {
				return '';
			}

			return add_query_arg(
				array(
					'TB_iframe' => 'true',
					'width'     => 600,
					'height'    => 800,
				),
				$details_url
			);
		}

		/**
		 * Styled notice when Analytify Dashboard must be updated before Pro.
		 *
		 * @since 9.1.0
		 * @param array  $plugin_data Plugin data.
		 * @param object $response    Update response.
		 * @param string $new_version Available version.
		 * @return void
		 */
		private static function render_core_dependency_notice_box( $plugin_data, $response, $new_version ) {
			$name = isset( $plugin_data['Name'] ) ? (string) $plugin_data['Name'] : 'Analytify Pro';

			$allowed = array(
				'a'      => array(
					'href'   => array(),
					'target' => array(),
					'rel'    => array(),
					'class'  => array(),
				),
				'em'     => array(),
				'strong' => array(),
				'span'   => array(
					'class' => array(),
				),
			);

			$intro = sprintf(
				/* translators: %s: plugin name. */
				esc_html__( 'There is a new version of %s available.', 'wp-analytify-pro' ),
				esc_html( $name )
			);

			$details_url = self::get_pro_version_details_url( $plugin_data, $response );
			if ( '' !== $details_url && '' !== $new_version ) {
				$details_link = sprintf(
					'<a target="_blank" class="thickbox open-plugin-details-modal" href="%1$s">%2$s</a>',
					esc_url( $details_url ),
					sprintf(
						/* translators: %s: version number. */
						esc_html__( 'View version %s details', 'wp-analytify-pro' ),
						esc_html( $new_version )
					)
				);

				$intro .= ' ' . wp_kses( $details_link, $allowed ) . '.';
			}

			$update_core_link = sprintf(
				'<a href="%1$s">%2$s</a>',
				esc_url( self::get_core_dashboard_upgrade_url() ),
				esc_html__( 'Update Analytify Dashboard', 'wp-analytify-pro' )
			);

			$message = $intro
				. ' <strong>'
				. esc_html__( 'Please update Analytify Dashboard before updating Pro.', 'wp-analytify-pro' )
				. '</strong> '
				. $update_core_link;

			echo '<div class="analytify-pro-plugin-update-notice analytify-pro-core-dependency-notice">';
			echo '<span class="dashicons dashicons-update analytify-pro-plugin-update-notice__icon" aria-hidden="true"></span>';
			echo '<div class="analytify-pro-plugin-update-notice__text">';
			echo wp_kses( $message, $allowed );
			echo '</div></div>';
		}

		/**
		 * WP Rocket-style renew notice when the license is inactive for updates.
		 *
		 * @since 9.1.0
		 * @param array  $plugin_data Plugin data.
		 * @param string $new_version Available version.
		 * @return void
		 */
		private static function render_renew_notice_box( $plugin_data, $new_version ) {
			if ( self::$renew_notice_rendered ) {
				return;
			}

			self::$renew_notice_rendered = true;

			$name = isset( $plugin_data['Name'] ) ? (string) $plugin_data['Name'] : 'Analytify Pro';

			$learn = sprintf(
				'<a href="%1$s" target="_blank" rel="noopener noreferrer">%2$s</a>',
				esc_url( self::$changelog_url ),
				esc_html__( 'Learn more', 'wp-analytify-pro' )
			);

			$renew = sprintf(
				'<a href="%1$s" target="_blank" rel="noopener noreferrer">%2$s</a>',
				esc_url( self::$renew_url ),
				esc_html__( 'Renew Now', 'wp-analytify-pro' )
			);

			$message = sprintf(
				/* translators: 1: plugin name, 2: version, 3: learn more link, 4: renew link. */
				__(
					'<strong>%1$s %2$s</strong> is available. %3$s about the updates and enhancements of this version. You need an active license to use them on your website, don\'t miss out! %4$s',
					'wp-analytify-pro'
				),
				esc_html( $name ),
				esc_html( $new_version ),
				$learn,
				$renew
			);

			echo '<div class="analytify-pro-plugin-update-notice analytify-pro-license-renew-notice">';
			echo '<span class="analytify-pro-plugin-update-notice__icon analytify-pro-plugin-update-notice__icon--warning" aria-hidden="true"></span>';
			echo '<div class="analytify-pro-plugin-update-notice__text">';
			// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built with escaped parts.
			echo $message;
			echo '</div></div>';
		}

		/**
		 * Remove duplicate Pro update rows (multisite can render core + EDD rows).
		 *
		 * @return void
		 */
		public static function maybe_remove_duplicate_update_rows() {
			if ( ! function_exists( 'get_current_screen' ) ) {
				return;
			}

			$screen = get_current_screen();
			if ( ! $screen || 'plugins' !== $screen->id || ! current_user_can( 'update_plugins' ) ) {
				return;
			}

			if ( ! self::is_license_inactive_for_updates() ) {
				return;
			}

			$selector = 'tr.plugin-update-tr[data-slug="' . self::$pro_slug . '"]';

			printf(
				'<script>(function(){var rows=document.querySelectorAll(%1$s);if(rows.length<2){return;}for(var i=1;i<rows.length;i++){rows[i].remove();}})();</script>' . "\n",
				wp_json_encode( $selector )
			);
		}

		/**
		 * Enqueue Plugins screen styles for renew and dependency notices.
		 *
		 * @since 9.1.0
		 * @param string $hook_suffix Admin hook.
		 * @return void
		 */
		public static function enqueue_plugins_screen_styles( $hook_suffix ) {
			if ( 'plugins.php' !== $hook_suffix || ! current_user_can( 'update_plugins' ) ) {
				return;
			}

			$pending = get_site_transient( 'update_plugins' );
			$show    = self::should_block_pro_update( $pending )
				|| ( self::is_license_inactive_for_updates() && self::has_pro_version_update( $pending ) );

			if ( ! $show ) {
				return;
			}

			wp_enqueue_style(
				'analytify-pro-plugin-update',
				plugins_url( 'assets/css/analytify-pro-plugin-update' . analytify_pro_get_asset_suffix() . '.css', dirname( __DIR__ ) . '/wp-analytify-pro.php' ),
				array( 'dashicons' ),
				defined( 'ANALYTIFY_PRO_VERSION' ) ? ANALYTIFY_PRO_VERSION : '1.0.0'
			);
		}

		/**
		 * Disable Pro checkbox on Dashboard > Updates when core is still outdated.
		 *
		 * @since 9.1.0
		 * @return void
		 */
		public static function maybe_disable_pro_bulk_checkbox() {
			if ( ! function_exists( 'get_current_screen' ) ) {
				return;
			}

			$screen = get_current_screen();
			if ( ! $screen || 'update-core' !== $screen->id ) {
				return;
			}

			$transient = get_site_transient( 'update_plugins' );
			if ( ! self::should_block_pro_update( $transient ) ) {
				return;
			}

			$script = sprintf(
				'(function(){document.querySelectorAll('
				. '\'form[name="upgrade-plugins"] input[name="checked[]"]\''
				. ').forEach(function(i){if(i.value!==%1$s){return;}'
				. 'i.disabled=true;i.checked=false;'
				. 'var l=document.querySelector(\'label[for="\'+i.id+\'"]\');'
				. 'if(l){l.setAttribute("aria-disabled","true");}});})();',
				wp_json_encode( self::$pro_plugin )
			);

			// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			echo '<script>' . $script . '</script>' . "\n";
		}
	}
}

if ( class_exists( 'Analytify_Pro_Update_Dependency', false ) ) {
	Analytify_Pro_Update_Dependency::init();
}
