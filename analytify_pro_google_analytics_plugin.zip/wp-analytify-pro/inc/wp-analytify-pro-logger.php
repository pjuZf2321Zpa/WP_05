<?php
/**
 * Shared helpers for WP Analytify Pro error logging via Analytify core.
 *
 * Which helper to use:
 * - {@see wp_analytify_pro_log_error()} / {@see wp_analytify_pro_log_warning()} — local logic, validation, or
 *   non-HTTP failures (no remote response object).
 * - {@see wp_analytify_pro_log_remote_error()} / {@see wp_analytify_pro_log_remote_warning()} — WordPress HTTP API
 *   transport or response issues; appends status/body preview from `$response`.
 * - {@see wp_analytify_pro_log_edd_license_request_issue()} — EDD license endpoint: transport, bad HTTP, or invalid JSON.
 * - {@see wp_analytify_pro_log_edd_license_state_validation_failure()} — HTTP/JSON OK but license payload/state is
 *   unexpected (e.g. deactivation did not return `deactivated`).
 * - {@see wp_analytify_pro_log_measurement_remote_result()} — Google Analytics Measurement Protocol
 *   (`wp_remote_post` to collect/debug); redacts hit payload before logging.
 *
 * @package WP_Analytify_Pro
 * @since 8.1.0
 * @since 9.0.0 EDD state validation helper; stricter measurement and EDD request logging behavior.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( function_exists( 'wp_analytify_pro_log_error' ) ) {
	return;
}

/**
 * Write an error entry through the core Analytify logger when it exists.
 *
 * @since 8.1.0
 *
 * @param string               $message Short, stable summary (no dynamic PII).
 * @param array<string, mixed> $context Structured fields; omit raw license keys and full URLs with query strings where possible.
 * @return void
 */
function wp_analytify_pro_log_error( $message, array $context = array() ) {
	if ( ! function_exists( 'analytify_get_logger' ) ) {
		return;
	}
	$logger = analytify_get_logger();
	if ( $logger && method_exists( $logger, 'error' ) ) {
		$logger->error( $message, $context );
	}
}

/**
 * Write a warning entry through the core Analytify logger when it exists.
 *
 * @since 8.1.0
 *
 * @param string               $message Short, stable summary.
 * @param array<string, mixed> $context Structured fields.
 * @return void
 */
function wp_analytify_pro_log_warning( $message, array $context = array() ) {
	if ( ! function_exists( 'analytify_get_logger' ) ) {
		return;
	}
	$logger = analytify_get_logger();
	if ( $logger && method_exists( $logger, 'warning' ) ) {
		$logger->warning( $message, $context );
	}
}

/**
 * Mask a license or similar secret for log context (never log raw values).
 *
 * @since 8.1.0
 *
 * @param string $value Raw license or token.
 * @return string Masked placeholder safe for logs.
 */
function wp_analytify_pro_mask_license_for_log( $value ) {
	if ( ! is_string( $value ) || '' === $value ) {
		return '(empty)';
	}
	$len = strlen( $value );
	if ( $len <= 8 ) {
		return '****';
	}
	return substr( $value, 0, 4 ) . '…' . substr( $value, -4 );
}

/**
 * Return API argument array safe for logs (license masked, URL normalized).
 *
 * @since 8.1.0
 *
 * @param array<string, mixed> $api_params Request body or query args.
 * @return array<string, mixed>
 */
function wp_analytify_pro_sanitize_license_api_params_for_log( array $api_params ) {
	$out = $api_params;
	if ( isset( $out['license'] ) && $out['license'] && false !== $out['license'] ) {
		$out['license'] = wp_analytify_pro_mask_license_for_log( (string) $out['license'] );
	}
	if ( isset( $out['url'] ) && is_string( $out['url'] ) ) {
		$out['url'] = esc_url_raw( $out['url'] );
	}
	return $out;
}

/**
 * Build diagnostic fields from a WordPress HTTP API response (or WP_Error).
 *
 * @since 8.1.0
 *
 * @param array|\WP_Error $response Response from wp_remote_*.
 * @return array<string, mixed>
 */
function wp_analytify_pro_remote_response_diagnostics( $response ) {
	if ( function_exists( 'is_wp_error' ) && is_wp_error( $response ) ) {
		return array(
			'http_code'     => 0,
			'error_code'    => $response->get_error_code(),
			'error_message' => $response->get_error_message(),
			'body_preview'  => '',
		);
	}
	if ( ! is_array( $response ) ) {
		return array(
			'http_code'    => 0,
			'body_preview' => '',
		);
	}
	$code    = function_exists( 'wp_remote_retrieve_response_code' ) ? wp_remote_retrieve_response_code( $response ) : 0;
	$body    = function_exists( 'wp_remote_retrieve_body' ) ? wp_remote_retrieve_body( $response ) : '';
	$preview = '';
	if ( is_string( $body ) && '' !== $body ) {
		$preview = substr( preg_replace( '/\s+/', ' ', $body ), 0, 500 );
	}
	return array(
		'http_code'    => (int) $code,
		'body_preview' => $preview,
	);
}

/**
 * Log an error with HTTP / WP_Error diagnostics appended.
 *
 * @since 8.1.0
 *
 * @param string               $message   Short summary.
 * @param array<string, mixed> $context   Base context (no raw secrets).
 * @param array|\WP_Error      $response  WordPress HTTP API response or error.
 * @return void
 */
function wp_analytify_pro_log_remote_error( $message, array $context, $response ) {
	wp_analytify_pro_log_error(
		$message,
		array_merge( $context, wp_analytify_pro_remote_response_diagnostics( $response ) )
	);
}

/**
 * Log a warning with HTTP / WP_Error diagnostics appended.
 *
 * @since 8.1.0
 *
 * @param string               $message   Short summary.
 * @param array<string, mixed> $context   Base context.
 * @param array|\WP_Error      $response  WordPress HTTP API response or error.
 * @return void
 */
function wp_analytify_pro_log_remote_warning( $message, array $context, $response ) {
	wp_analytify_pro_log_warning(
		$message,
		array_merge( $context, wp_analytify_pro_remote_response_diagnostics( $response ) )
	);
}

/**
 * Log EDD license remote failure: site URL, masked api_params, and diagnostics.
 *
 * @since 8.1.0
 * @since 9.0.0 Normalizes `$api_params` (non-arrays become empty) and `$source` (default `unknown`).
 *
 * @param string               $message    Short summary.
 * @param string               $source     Stable source identifier (e.g. Class::method).
 * @param mixed                $api_params Request args (license masked in log output); non-arrays are treated as empty.
 * @param array|\WP_Error      $response   WordPress HTTP API response or error.
 * @param array<string, mixed> $extra      Optional extra context keys.
 * @return void
 */
function wp_analytify_pro_log_edd_license_request_issue( $message, $source, $api_params, $response, array $extra = array() ) {
	$api_params = is_array( $api_params ) ? $api_params : array();
	$source     = is_string( $source ) && '' !== $source ? $source : 'unknown';

	wp_analytify_pro_log_remote_error(
		$message,
		array_merge(
			array(
				'source'     => $source,
				'site_url'   => function_exists( 'get_site_url' ) ? (string) get_site_url() : '',
				'api_params' => wp_analytify_pro_sanitize_license_api_params_for_log( $api_params ),
			),
			$extra
		),
		$response
	);
}

/**
 * Log EDD license API logical failure: valid HTTP response and parseable JSON, but license state is not acceptable.
 *
 * Use this instead of {@see wp_analytify_pro_log_edd_license_request_issue()} when there is no transport/HTTP/JSON
 * error — only an unexpected `license` field or similar.
 *
 * @since 9.0.0
 *
 * @param string               $message    Short summary.
 * @param string               $source     Stable source identifier (e.g. Class::method).
 * @param mixed                $api_params Request args (license masked in log output); non-arrays are treated as empty.
 * @param array<string, mixed> $extra      Optional context (e.g. license_status, http_code).
 * @return void
 */
function wp_analytify_pro_log_edd_license_state_validation_failure( $message, $source, $api_params, array $extra = array() ) {
	$api_params = is_array( $api_params ) ? $api_params : array();
	$source     = is_string( $source ) && '' !== $source ? $source : 'unknown';

	wp_analytify_pro_log_error(
		$message,
		array_merge(
			array(
				'source'     => $source,
				'site_url'   => function_exists( 'get_site_url' ) ? (string) get_site_url() : '',
				'api_params' => wp_analytify_pro_sanitize_license_api_params_for_log( $api_params ),
			),
			$extra
		)
	);
}

/**
 * Redact Measurement Protocol hit parameters for debug logs (no IP, UA, raw paths/titles, or full CID).
 *
 * @since 8.1.0
 *
 * @param array<string, mixed> $body Hit payload.
 * @return array<string, mixed>
 */
function wp_analytify_pro_redact_measurement_hit_for_log( array $body ) {
	$redacted = array();
	foreach ( $body as $key => $value ) {
		if ( in_array( $key, array( 'uip', 'ua', 'uid' ), true ) ) {
			continue;
		}
		if ( 'cid' === $key ) {
			$redacted['cid_masked'] = wp_analytify_pro_mask_license_for_log( (string) $value );
			continue;
		}
		// Event fields and custom dimensions often carry commerce or PII — keep only lengths.
		if ( in_array( $key, array( 'ec', 'ea', 'el' ), true ) || ( is_string( $key ) && preg_match( '/^cd\d+$/', $key ) ) ) {
			$redacted[ $key . '_length' ] = is_string( $value ) ? strlen( $value ) : 0;
			continue;
		}
		if ( in_array( $key, array( 'dp', 'dt', 'dl', 'dh' ), true ) ) {
			$redacted[ $key . '_length' ] = is_string( $value ) ? strlen( $value ) : 0;
			continue;
		}
		if ( is_string( $value ) && strlen( $value ) > 120 ) {
			$redacted[ $key ] = substr( $value, 0, 80 ) . '…(truncated)';
			continue;
		}
		$redacted[ $key ] = $value;
	}
	return $redacted;
}

/**
 * Handle Measurement Protocol result: log transport errors and HTTP error responses (redacted body).
 *
 * @since 8.1.0
 * @since 9.0.0 Redacts hit payload only when logging; normalizes `$hit_body` and `$source`.
 *
 * @param string          $error_message   Message when $response is WP_Error.
 * @param string          $warning_message Message when HTTP status is >= 400.
 * @param string          $source          Stable source identifier.
 * @param mixed           $hit_body        Raw hit payload (redacted for the log only when a log line is written).
 * @param array|\WP_Error $response        Result from wp_remote_post().
 * @return void
 */
function wp_analytify_pro_log_measurement_remote_result( $error_message, $warning_message, $source, $hit_body, $response ) {
	$hit_body = is_array( $hit_body ) ? $hit_body : array();
	$source   = is_string( $source ) && '' !== $source ? $source : 'unknown';

	if ( function_exists( 'is_wp_error' ) && is_wp_error( $response ) ) {
		wp_analytify_pro_log_remote_error(
			$error_message,
			array(
				'source'      => $source,
				'hit_summary' => wp_analytify_pro_redact_measurement_hit_for_log( $hit_body ),
			),
			$response
		);
		return;
	}

	if ( ! is_array( $response ) ) {
		return;
	}

	$http_code = function_exists( 'wp_remote_retrieve_response_code' ) ? (int) wp_remote_retrieve_response_code( $response ) : 0;
	if ( $http_code < 400 ) {
		return;
	}

	wp_analytify_pro_log_remote_warning(
		$warning_message,
		array(
			'source'      => $source,
			'hit_summary' => wp_analytify_pro_redact_measurement_hit_for_log( $hit_body ),
		),
		$response
	);
}
