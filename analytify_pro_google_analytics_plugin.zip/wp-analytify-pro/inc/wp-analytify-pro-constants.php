<?php
/**
 * WP Analytify Pro Constants
 *
 * This file contains all constants used throughout the WP Analytify Pro plugin.
 * Centralizing constants here ensures consistency and easier maintenance.
 *
 * @package WP_Analytify_Pro
 * @since 8.0.0
 * @version 9.1.2
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// ============================================================================
// PLUGIN CORE CONSTANTS
// ============================================================================

/**
 * Plugin version
 */
if ( ! defined( 'ANALYTIFY_PRO_VERSION' ) ) {
	define( 'ANALYTIFY_PRO_VERSION', '9.1.2' );
}

if ( ! function_exists( 'analytify_pro_get_asset_version' ) ) {
	/**
	 * Version string for Pro plugin and bundled module assets (cache busting).
	 *
	 * @return string
	 */
	function analytify_pro_get_asset_version() {
		return defined( 'ANALYTIFY_PRO_VERSION' ) ? ANALYTIFY_PRO_VERSION : '9.1.2';
	}
}

if ( ! function_exists( 'analytify_pro_get_asset_suffix' ) ) {
	/**
	 * Filename suffix for choosing minified vs unminified assets.
	 *
	 * @since 9.1.2
	 * @return string '' when SCRIPT_DEBUG is on, '.min' otherwise.
	 */
	function analytify_pro_get_asset_suffix() {
		return ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? '' : '.min';
	}
}

/**
 * Plugin root path
 */
if ( ! defined( 'ANALYTIFY_PRO_ROOT_PATH' ) ) {
	define( 'ANALYTIFY_PRO_ROOT_PATH', dirname( __DIR__ ) );
}

/**
 * Plugin upgrade path
 */
if ( ! defined( 'ANALYTIFY_PRO_UPGRADE_PATH' ) ) {
	define( 'ANALYTIFY_PRO_UPGRADE_PATH', dirname( __DIR__ ) . '/wp-analytify-pro.php' );
}

/**
 * Plugin URL
 */
if ( ! defined( 'ANALYTIFY_PRO_URL' ) ) {
	define( 'ANALYTIFY_PRO_URL', plugin_dir_url( __DIR__ ) );
}

/**
 * Plugin assets URL
 */
if ( ! defined( 'ANALYTIFY_PRO_ASSETS_URL' ) ) {
	define( 'ANALYTIFY_PRO_ASSETS_URL', ANALYTIFY_PRO_URL . 'assets/' );
}

/**
 * Plugin includes path
 */
if ( ! defined( 'ANALYTIFY_PRO_INCLUDES_PATH' ) ) {
	define( 'ANALYTIFY_PRO_INCLUDES_PATH', ANALYTIFY_PRO_ROOT_PATH . '/includes/' );
}

/**
 * Plugin classes path
 */
if ( ! defined( 'ANALYTIFY_PRO_CLASSES_PATH' ) ) {
	define( 'ANALYTIFY_PRO_CLASSES_PATH', ANALYTIFY_PRO_ROOT_PATH . '/classes/' );
}

/**
 * Plugin modules path
 */
if ( ! defined( 'ANALYTIFY_PRO_MODULES_PATH' ) ) {
	define( 'ANALYTIFY_PRO_MODULES_PATH', ANALYTIFY_PRO_ROOT_PATH . '/inc/modules/' );
}

// ============================================================================
// EXTERNAL SERVICES CONSTANTS
// ============================================================================

/**
 * Google Analytics Measurement Protocol URL
 */
if ( ! defined( 'ANALYTIFY_GOOGLE_MEASUREMENT_URL' ) ) {
	define( 'ANALYTIFY_GOOGLE_MEASUREMENT_URL', 'https://www.google-analytics.com/collect' );
}

/**
 * Google Analytics Debug Measurement Protocol URL
 */
if ( ! defined( 'ANALYTIFY_GOOGLE_DEBUG_MEASUREMENT_URL' ) ) {
	define( 'ANALYTIFY_GOOGLE_DEBUG_MEASUREMENT_URL', 'https://www.google-analytics.com/debug/collect' );
}

/**
 * Google Analytics GA4 Measurement Protocol API URL
 */
if ( ! defined( 'ANALYTIFY_GOOGLE_GA4_API_URL' ) ) {
	define( 'ANALYTIFY_GOOGLE_GA4_API_URL', 'https://www.google-analytics.com/mp/collect' );
}

/**
 * Store API URL
 */
if ( ! defined( 'ANALYTIFY_STORE_API_URL' ) ) {
	// Check if ANALYTIFY_STORE_URL is defined, if not use default.
	$store_url = defined( 'ANALYTIFY_STORE_URL' ) ? ANALYTIFY_STORE_URL : 'https://analytify.io';
	define( 'ANALYTIFY_STORE_API_URL', $store_url . 'wp-json/edd/v1/' );
}

// ============================================================================
// ADDON VERSION CONSTANTS
// ============================================================================

/**
 * WooCommerce addon version
 */
if ( ! defined( 'ANALYTIFY_WOOCOMMERCE_VERSION' ) ) {
	define( 'ANALYTIFY_WOOCOMMERCE_VERSION', '6.1.0' );
}

/**
 * Forms addon version
 */
if ( ! defined( 'ANALYTIFY_FORMS_VERSION' ) ) {
	define( 'ANALYTIFY_FORMS_VERSION', '5.0.0' );
}

/**
 * Email addon version
 */
if ( ! defined( 'ANALYTIFY_EMAIL_VERSION' ) ) {
	define( 'ANALYTIFY_EMAIL_VERSION', '4.0.0' );
}

/**
 * Goals addon version
 */
if ( ! defined( 'ANALYTIFY_GOALS_VERSION' ) ) {
	define( 'ANALYTIFY_GOALS_VERSION', '3.0.0' );
}

/**
 * Authors addon version
 */
if ( ! defined( 'ANALYTIFY_AUTHORS_VERSION' ) ) {
	define( 'ANALYTIFY_AUTHORS_VERSION', '2.0.0' );
}

/**
 * Campaigns addon version
 */
if ( ! defined( 'ANALYTIFY_CAMPAIGNS_VERSION' ) ) {
	define( 'ANALYTIFY_CAMPAIGNS_VERSION', '2.0.0' );
}

/**
 * EDD addon version
 */
if ( ! defined( 'ANALYTIFY_EDD_VERSION' ) ) {
	define( 'ANALYTIFY_EDD_VERSION', '2.0.0' );
}

// ============================================================================
// FUNCTIONALITY CONSTANTS
// ============================================================================

/**
 * Default tracking mode
 */
if ( ! defined( 'ANALYTIFY_TRACKING_MODE' ) ) {
	define( 'ANALYTIFY_TRACKING_MODE', 'gtag' );
}

/**
 * Forms addon custom form class
 */
if ( ! defined( 'ANALYTIFY_FORMS_ADDON_CUSTOM_FORM_CLASS' ) ) {
	define( 'ANALYTIFY_FORMS_ADDON_CUSTOM_FORM_CLASS', 'analytify_form_custom' );
}

// ============================================================================
// ADDON SPECIFIC CONSTANTS
// ============================================================================

/**
 * WooCommerce Addon Constants
 */
if ( ! defined( 'WC_ANALYTIFY_PLUGIN_FILE' ) ) {
	define( 'WC_ANALYTIFY_PLUGIN_FILE', ANALYTIFY_PRO_MODULES_PATH . 'wp-analytify-woocommerce/class-wp-analytify-woo.php' );
}

if ( ! defined( 'WC_ANALYTIFY_PLUGIN_BASENAME' ) ) {
	define( 'WC_ANALYTIFY_PLUGIN_BASENAME', plugin_basename( WC_ANALYTIFY_PLUGIN_FILE ) );
}

if ( ! defined( 'WC_ANALYTIFY_PLUGIN_DIR' ) ) {
	define( 'WC_ANALYTIFY_PLUGIN_DIR', dirname( WC_ANALYTIFY_PLUGIN_FILE ) );
}

if ( ! defined( 'WC_ANALYTIFY_PRODUCT_NAME' ) ) {
	define( 'WC_ANALYTIFY_PRODUCT_NAME', 'Enhanced Ecommerce Google Analytics for WooCommerce Addon' );
}

if ( ! defined( 'WC_ANALYTIFY_PRODUCT_ID' ) ) {
	define( 'WC_ANALYTIFY_PRODUCT_ID', 1351 );
}


/**
 * Email Addon Constants
 */
if ( ! defined( 'EMAIL_ANALYTIFY_PLUGIN_FILE' ) ) {
	define( 'EMAIL_ANALYTIFY_PLUGIN_FILE', ANALYTIFY_PRO_MODULES_PATH . 'wp-analytify-email/class-wp-analytify-email.php' );
}

if ( ! defined( 'EMAIL_ANALYTIFY_PLUGIN_BASENAME' ) ) {
	define( 'EMAIL_ANALYTIFY_PLUGIN_BASENAME', plugin_basename( EMAIL_ANALYTIFY_PLUGIN_FILE ) );
}

if ( ! defined( 'EMAIL_ANALYTIFY_PLUGIN_DIR' ) ) {
	define( 'EMAIL_ANALYTIFY_PLUGIN_DIR', dirname( EMAIL_ANALYTIFY_PLUGIN_FILE ) );
}

if ( ! defined( 'EMAIL_ANALYTIFY_PRODUCT_NAME' ) ) {
	define( 'EMAIL_ANALYTIFY_PRODUCT_NAME', 'Google Analytics Email Notifications' );
}

if ( ! defined( 'EMAIL_ANALYTIFY_PRODUCT_ID' ) ) {
	define( 'EMAIL_ANALYTIFY_PRODUCT_ID', 6580 );
}

if ( ! defined( 'EMAIL_ANALYTIFY_STORE_URL' ) ) {
	// Check if ANALYTIFY_STORE_URL is defined, if not use default.
	$store_url = defined( 'ANALYTIFY_STORE_URL' ) ? ANALYTIFY_STORE_URL : 'https://analytify.io';
	define( 'EMAIL_ANALYTIFY_STORE_URL', $store_url );
}

if ( ! defined( 'ANALYTIFY_EMAIL_VIEWS_PATH' ) ) {
	define( 'ANALYTIFY_EMAIL_VIEWS_PATH', EMAIL_ANALYTIFY_PLUGIN_DIR . '/views/' );
}

if ( ! defined( 'ANALYTIFY_IMAGES_PATH' ) ) {
	define( 'ANALYTIFY_IMAGES_PATH', 'https://analytify.io/assets/email/' );
}

/**
 * Forms Addon Constants
 */
if ( ! defined( 'ANALYTIFY_FORMS_ADDON_ROOT_PATH' ) ) {
	define( 'ANALYTIFY_FORMS_ADDON_ROOT_PATH', ANALYTIFY_PRO_MODULES_PATH . 'wp-analytify-forms/' );
}

if ( ! defined( 'ANALYTIFY_FORM_ADDON_MIN_V_ANALYTIFY' ) ) {
	define( 'ANALYTIFY_FORM_ADDON_MIN_V_ANALYTIFY', '4.0.0' );
}

if ( ! defined( 'ANALYTIFY_FORM_ADDON_MIN_V_ANALYTIFY_PRO' ) ) {
	define( 'ANALYTIFY_FORM_ADDON_MIN_V_ANALYTIFY_PRO', '4.0.0' );
}

/**
 * Goals Addon Constants
 */
if ( ! defined( 'GOALS_ANALYTIFY_ADDON_PLUGIN_FILE' ) ) {
	define( 'GOALS_ANALYTIFY_ADDON_PLUGIN_FILE', ANALYTIFY_PRO_MODULES_PATH . 'wp-analytify-goals/class-wp-analytify-goals.php' );
}

if ( ! defined( 'GOALS_ANALYTIFY_ADDON_PLUGIN_BASENAME' ) ) {
	define( 'GOALS_ANALYTIFY_ADDON_PLUGIN_BASENAME', plugin_basename( GOALS_ANALYTIFY_ADDON_PLUGIN_FILE ) );
}

if ( ! defined( 'GOALS_ANALYTIFY_ADDON_PLUGIN_DIR' ) ) {
	define( 'GOALS_ANALYTIFY_ADDON_PLUGIN_DIR', dirname( GOALS_ANALYTIFY_ADDON_PLUGIN_FILE ) );
}

if ( ! defined( 'GOALS_ANALYTIFY_ADDON_PRODUCT_NAME' ) ) {
	define( 'GOALS_ANALYTIFY_ADDON_PRODUCT_NAME', 'Analytify - Goals Addon' );
}

if ( ! defined( 'GOALS_ANALYTIFY_ADDON_PRODUCT_ID' ) ) {
	define( 'GOALS_ANALYTIFY_ADDON_PRODUCT_ID', 14243 );
}

if ( ! defined( 'GOALS_ANALYTIFY_ADDON_STORE_URL' ) ) {
	// Check if ANALYTIFY_STORE_URL is defined, if not use default.
	$store_url = defined( 'ANALYTIFY_STORE_URL' ) ? ANALYTIFY_STORE_URL : 'https://analytify.io';
	define( 'GOALS_ANALYTIFY_ADDON_STORE_URL', $store_url );
}

// ============================================================================
// SECURITY CONSTANTS
// ============================================================================

/**
 * Nonce action for admin operations
 */
if ( ! defined( 'ANALYTIFY_PRO_NONCE_ACTION' ) ) {
	define( 'ANALYTIFY_PRO_NONCE_ACTION', 'analytify_pro_nonce' );
}

/**
 * Capability required for admin operations
 */
if ( ! defined( 'ANALYTIFY_PRO_CAPABILITY' ) ) {
	define( 'ANALYTIFY_PRO_CAPABILITY', 'manage_options' );
}

// ============================================================================
// CACHE AND TRANSIENT CONSTANTS
// ============================================================================

/**
 * Cache expiration time (in seconds)
 */
if ( ! defined( 'ANALYTIFY_PRO_CACHE_EXPIRATION' ) ) {
	define( 'ANALYTIFY_PRO_CACHE_EXPIRATION', 3600 ); // 1 hour
}

/**
 * Transient prefix for caching
 */
if ( ! defined( 'ANALYTIFY_PRO_TRANSIENT_PREFIX' ) ) {
	define( 'ANALYTIFY_PRO_TRANSIENT_PREFIX', 'analytify_pro_' );
}

// ============================================================================
// DEBUG AND DEVELOPMENT CONSTANTS
// ============================================================================

/**
 * Debug mode (set to false in production)
 */
if ( ! defined( 'ANALYTIFY_PRO_DEBUG' ) ) {
	define( 'ANALYTIFY_PRO_DEBUG', false );
}

/**
 * Logging enabled (set to false in production)
 */
if ( ! defined( 'ANALYTIFY_PRO_LOGGING' ) ) {
	define( 'ANALYTIFY_PRO_LOGGING', false );
}

// ============================================================================
// DEPRECATED CONSTANTS (for backward compatibility)
// ============================================================================

/**
 * Deprecated constant.
 *
 * @deprecated Use ANALYTIFY_PRO_VERSION instead
 */

/**
 * Deprecated constant.
 *
 * @deprecated Use ANALYTIFY_PRO_URL instead
 */
if ( ! defined( 'ANALYTIFY_URL' ) ) {
	define( 'ANALYTIFY_URL', ANALYTIFY_PRO_URL );
}

// Shared logging helpers (Analytify core logger + redaction utilities).
require_once ANALYTIFY_PRO_ROOT_PATH . '/inc/wp-analytify-pro-logger.php';
