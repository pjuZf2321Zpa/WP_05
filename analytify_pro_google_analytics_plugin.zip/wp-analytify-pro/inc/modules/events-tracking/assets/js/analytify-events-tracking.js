'use strict';

/**
 * Handles tracking for all events.
 * 
 */

// Wrapping the code in an anonymous function to avoid conflicts.
( function () {

	// Holds previous hash.
	const prevHash = window.location.hash;

	const eventsTrackingMode = analytify_events_tracking.tracking_mode;
	const GAMode = analytify_events_tracking.ga_mode;
	const trackingCode = analytify_events_tracking.tracking_code;

	function trim_link_string(x) {
		return x.replace(/^\s+|\s+$/gm, '');
	}

	/**
	 * Returns the type of link tracking.
	 *
	 * @param {object} el The element to track.
	 * @returns 
	 */
	function get_tracking_type( el ) {

		// Default tracking type.
		let type = 'unknown';

		const link = el.href;
		const {hostname} = el;
		const {protocol} = el;
		const {pathname} = el;

		const {download_extension} = analytify_events_tracking;
		const current_domain = analytify_events_tracking.root_domain;

		const affiliate_links = 'undefined' !== typeof analytify_events_tracking.affiliate_link ? analytify_events_tracking.affiliate_link : {};

		if ( link.match(/^javascript\:/i) ) {

			// if its a JS link, it's internal
			type = 'internal';
		} else if ( 'tel' == trim_link_string(protocol) || 'tel:' == trim_link_string(protocol) ) {

			// Track telephone event.
			type = 'tel';
		} else if ( 'mailto' == trim_link_string(protocol) || 'mailto:' == trim_link_string(protocol) ) {

			// Track mail event.
			type = 'mailto';
		} else if ( 0 < hostname.length && 0 < current_domain.length && ! hostname.endsWith( current_domain ) ) {

			// Track external links.
			type = 'external';
		} else if ( 0 < Object.keys(affiliate_links).length && 0 < pathname.length ) {
			for ( const affiliate_link_index in affiliate_links ) {
				const affiliate_link = affiliate_links[affiliate_link_index];
				if ( affiliate_link.path && pathname.endsWith( affiliate_link.path ) ) {
					type = 'outbound';
					break;
				}
			}
		}

		// Track download files.
		if ( 'unknown' === type && 0 < download_extension.length ) {
			let regExp = '';
		try {
			regExp = new RegExp(`.*\\.(${  download_extension  })(\\?.*)?$`);
		} catch (e) {

			// Silent fail - Invalid RegExp for download tracking
		}

			if ( 'undefined' != typeof regExp && el.href.match( regExp ) ) {
				type = 'download';
			}
		}

		if ( 'unknown' === type ) {
			type = 'internal';
		}

		return type;
	}

	/**
	 * Sends the event call.
	 * 
	 * @param {string} category Event category.
	 * @param {string} action   Event action.
	 * @param {string} label    Event label.
	 */
	function send_event_call(category, action, label) {
		if ('gtag' === eventsTrackingMode) {
			if ('function' !== typeof gtag) {
				return;
			}

			if ( 'ga4' === GAMode ) {
				const eventData = {
					'wpa_link_action': action,
					'wpa_category': category,
					'wpa_link_label': label,
					'wpa_device_category': get_device_category(),
					'wpa_click_hour': new Date().getHours().toString(),
					'wpa_click_day': ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][new Date().getDay()],
					'wpa_traffic_source': get_traffic_source(),
					'wpa_country_code': extract_country_code(action),
				};

				gtag('event', 'analytify_event_tracking', eventData);
			} else {
				gtag('event', action, {
					'event_category': category,
					'event_label': label,
				});
			}
		} else {
			if ('function' === typeof ga) {
				ga('send', 'event', category, action, label);
			}
		}
	}

	/**
	 * Determine device category based on screen size
	 */
	function get_device_category() {
		const width = window.innerWidth;
		if (768 >= width) {return 'mobile';}
		if (1024 >= width) {return 'tablet';}
		return 'desktop';
	}

	/**
	 * True when document.referrer's hostname is host or a subdomain of host (e.g. www.google.com vs google.com).
	 *
	 * @param {string} referrer Full referrer URL
	 * @param {string} host     Bare host, e.g. google.com
	 * @returns {boolean}
	 */
	function referrer_hostname_is_or_subdomain_of(referrer, host) {
		try {
			const h = new URL(referrer).hostname.toLowerCase();
			const b = String(host).toLowerCase();
			return h === b || h.endsWith(`.${  b}`);
		} catch (e) {
			return false;
		}
	}

	/**
	 * Determine traffic source
	 */
	function get_traffic_source() {
		const {referrer} = document;
		const utmSource = get_url_parameter('utm_source');
		
		if (utmSource) {return utmSource;}
		if (!referrer) {return 'direct';}
		if (referrer_hostname_is_or_subdomain_of(referrer, 'google.com')) {return 'google';}
		if (referrer_hostname_is_or_subdomain_of(referrer, 'facebook.com')) {return 'facebook';}
		if (referrer_hostname_is_or_subdomain_of(referrer, 'twitter.com') || referrer_hostname_is_or_subdomain_of(referrer, 'x.com')) {return 'twitter';}
		if (referrer_hostname_is_or_subdomain_of(referrer, 'linkedin.com')) {return 'linkedin';}
		if (referrer_hostname_is_or_subdomain_of(referrer, 'instagram.com')) {return 'instagram';}
		if (referrer_hostname_is_or_subdomain_of(referrer, 'youtube.com')) {return 'youtube';}
		return 'referral';
	}

	/**
	 * Get URL parameter value
	 */
	function get_url_parameter(name) {
		const urlParams = new URLSearchParams(window.location.search);
		return urlParams.get(name) || '';
	}

	/**
	 * Extract country code from tel number
	 */
	function extract_country_code(telHref) {
		if (!telHref || 'string' !== typeof telHref) {
			return 'unknown';
		}

		// Remove 'tel:' and any non-digit characters except '+'
		const cleanNumber = telHref.replace('tel:', '').replace(/[^\d+]/g, '');
		
		if (cleanNumber.startsWith('+')) {

			// Pakistani numbers (+92)
			if (cleanNumber.startsWith('+92')) {
				return '+92';
			}
			
			// North American numbers (+1)
			if (cleanNumber.startsWith('+1')) {
				return '+1';
			}

			// For others, extract up to 3 digits, but check common 2-digit codes first
			// This is a heuristic approach since country codes vary in length
			const threeDigitMatch = cleanNumber.match(/^\+(\d{1,3})/);
			if (threeDigitMatch) {
				const [ , code] = threeDigitMatch;

				// Common 2-digit codes start with these prefixes
				if (3 === code.length && ['20', '27', '30', '31', '32', '33', '34', '36', '39', '40', '41', '43', '44', '45', '46', '47', '48', '49', '51', '52', '53', '54', '55', '56', '57', '58', '60', '61', '62', '63', '64', '65', '66', '81', '82', '84', '86', '90', '91', '92', '93', '94', '95', '98'].some(prefix => code.startsWith(prefix))) {
					return `+${code.substring(0, 2)}`;
				}
				return `+${code}`;
			}
		}
		
		return 'unknown';
	}

	/**
	 * Enhanced tel link tracking with comprehensive data collection
	 * 
	 * @param {object} target The tel link element
	 */
	function track_enhanced_tel_event(target) {

		// console.log('Enhanced tel tracking triggered for:', target.href);
		
		const action = target.getAttribute('data-vars-ga-action') || target.href;
		const label = target.getAttribute('data-vars-ga-label') || target.title || target.innerText || target.href;
		
		send_event_call('tel', action, label);
	}

	/**
	 * Tracks events.
	 * 
	 * @param {object} event Event object.
	 * @returns 
	 */
	function track_event( event ) {

		if ( '1' != analytify_events_tracking.is_track_user ) {
			return;
		}

		event = event || window.event;

		let target = event.target || event.srcElement;

		// If link is not define. Get the parent link.
		while (target && ('undefined' == typeof target.tagName || 'a' != target.tagName.toLowerCase() || !target.href)) {
			target = target.parentNode;
		}

		// if its links
		if ( target && target.href ) {

			let action = '';
			let label = '';

			const tracking_type = get_tracking_type( target );

			switch ( tracking_type ) {
				case 'outbound':
					action = target.getAttribute('data-vars-ga-action') || target.href;
					label = target.getAttribute('data-vars-ga-label') || target.title || target.innerText || target.href;
					send_event_call( 'outbound-link', action, label );
					break;

				case 'download':
					action = target.getAttribute('data-vars-ga-action') || target.href;
					label = target.getAttribute('data-vars-ga-label') || target.title || target.innerText || target.href;
					send_event_call( 'download', action, label );
					break;

				case 'tel':
					track_enhanced_tel_event(target);
					break;

				case 'external':
					action = target.getAttribute('data-vars-ga-action') || target.href;
					label = target.getAttribute('data-vars-ga-label') || target.title || target.innerText || target.href;
					send_event_call( 'external', action, label );
					break;

				case 'mailto':
					action = target.getAttribute('data-vars-ga-action') || target.href;
					label = target.getAttribute('data-vars-ga-label') || target.title || target.innerText || target.href;
					send_event_call( 'mail', action, label );
					break;

				default:
					break;
			}
		}
	}

	/**
	 * Tracks hash change.
	 */
	function track_hash() {

		// If hash tracking is enabled.
		if ( 'on' == analytify_events_tracking.anchor_tracking && prevHash != window.location.hash ) {
			if ('gtag' === eventsTrackingMode) {
				if ('function' === typeof gtag) {
					gtag('config', trackingCode, { 'page_path': location.pathname + location.search + location.hash });
				}
			} else if ('function' === typeof ga) {
				ga('set', 'page', location.pathname + location.search + location.hash);
				ga('send', 'pageview');
			}
		}
	}
	
	// When hash changes.
	window.addEventListener( 'hashchange', track_hash, false );

	// On Click.
	window.addEventListener( "load", () => {
		document.body.addEventListener( "click", track_event, false );
	}, false);

}());
