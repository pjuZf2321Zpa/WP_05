/**
 * Enhanced Tel Link Tracking Dashboard JavaScript
 *
 * @package WP_Analytify_Pro
 * @since 8.0.2
 */

(function($) {
    'use strict';


    // Enhanced Tel Dashboard functionality
    const EnhancedTelDashboard = {
        isInitialized: false,
        isLoading: false,

        /** Last table payload for CSV export */
        lastTelExportData: null,

        /** REST fetch timeout (ms) */
        fetchTimeoutMs: 90000,

        /**
         * Initialize the dashboard
         */
        init() {
            if (this.isInitialized) {return;}

            this.isInitialized = true;
            this.initializeDatePicker();
            this.loadEnhancedTelData();
            this.setupEventListeners();
        },

        /**
         * Initialize date picker with PHP values
         */
        initializeDatePicker() {
            if (window.analytify_dates?.start_date) {
                $('#analytify_date_start').val(window.analytify_dates.start_date);
                if ('undefined' !== typeof moment) {
                    $('#analytify_start').val(moment(window.analytify_dates.start_date).format('MMM DD, YYYY'));
                }
            }

            if (window.analytify_dates?.end_date) {
                $('#analytify_date_end').val(window.analytify_dates.end_date);
                if ('undefined' !== typeof moment) {
                    $('#analytify_end').val(moment(window.analytify_dates.end_date).format('MMM DD, YYYY'));
                }
            }
        },

        /**
         * Setup event listeners
         * Match other Pro dashboards: load after "View Stats" (form submit), not on every date change.
         * This screen does not enqueue stats-core.js, so we handle submit here (stats-core would dispatch analytify_form_date_submitted).
         */
        setupEventListeners() {
            const self = this;
            $(document).on('submit', 'form.analytify_form_date', (e) => {
                const cfg = window.analytify_stats_pro || window.analytify_stats_core;
                if (cfg && cfg.load_via_ajax) {
                    e.preventDefault();
                    self.loadEnhancedTelData();
                }
            });

            $(document).on('click', '.analytify-export-data', (e) => {
                e.preventDefault();
                this.exportData();
            });
        },

        /**
         * Load enhanced tel tracking data from GA4
         */
        /**
         * @param {string} d
         * @returns {boolean}
         */
        isValidDashboardDate(d) {
            return 'string' === typeof d && /^\d{4}-\d{2}-\d{2}$/.test(d);
        },

        loadEnhancedTelData() {
            if (this.isLoading) {return;}
            this.isLoading = true;

            const startDate = $('#analytify_date_start').val() ||
                window.analytify_dates?.start_date ||
                this.getDefaultStartDate();

            const endDate = $('#analytify_date_end').val() ||
                window.analytify_dates?.end_date ||
                this.getDefaultEndDate();

            if (!this.isValidDashboardDate(startDate) || !this.isValidDashboardDate(endDate)) {
                this.isLoading = false;
                this.showError('Invalid date range. Please use YYYY-MM-DD.');
                return;
            }

            this.showLoading();

            this.fetchEnhancedTelData(startDate, endDate)
                .then((data) => {
                    this.displayEnhancedTelData(data);
                    this.displaySummaryCards(data);
                })
                .catch((err) => {

                    // Keep raw message only for known GA4 custom-dimension detection.
                    const rawMsg = err && err.message ? err.message : '';
                    if (this.isUnregisteredGa4CustomDefinitionError(rawMsg)) {
                        const empty = this.formatEnhancedTelData({ rows: [] });
                        this.displayEnhancedTelData(empty);
                        this.displaySummaryCards(empty);
                    } else {

                        // Match other dashboards: never surface raw API/cURL errors.
                        this.showError(this.getGenericErrorMessage());
                    }
                })
                .finally(() => {
                    this.isLoading = false;
                });
        },

        /**
         * Fetch enhanced tel data from REST API
         * Uses analytify_stats_pro (same as stats-pro.js / other Pro dashboards) when available.
         */
        fetchEnhancedTelData(startDate, endDate) {
            return new Promise((resolve, reject) => {

                // Prefer inline REST config from view (fresh nonce per page load); then Pro/localized fallbacks (injected by WordPress)
                const rest = window.analytify_enhanced_tel_rest || window.analytify_stats_pro || window.analytify_stats_core;
                const restConfig = (rest && rest.url) ? rest : null;

                if (restConfig && restConfig.url) {
                    let baseURL = restConfig.url;
                    if (!baseURL.endsWith('/')) { baseURL += '/'; }

                    const params = new URLSearchParams();
                    params.append('sd', startDate);
                    params.append('ed', endDate);
                    params.append('_', String(Date.now()));

                    const delimiter = restConfig.delimiter || '?';
                    const URL = `${baseURL}enhanced-tel-tracking/${delimiter}${params.toString()}`;

                    const controller = new AbortController();
                    const timeoutId = setTimeout(() => controller.abort(), this.fetchTimeoutMs);

                    // Match stats-pro.js: GET + X-WP-Nonce; credentials: same-origin for cookie auth
                    fetch(URL, {
                        method: 'GET',
                        credentials: 'same-origin',
                        signal: controller.signal,
                        headers: {
                            'X-WP-Nonce': restConfig.nonce || '',
                        },
                    })
                        .then((response) => {
                            if (!response.ok) {
                                throw new Error(`API Error: ${response.status}`);
                            }
                            return response.json();
                        })
                        .then((data) => {
                            const errMsg = this.getEnhancedTelApiErrorMessage(data);
                            const probe = `${this.collectTelReportErrorSnippet(data)} ${errMsg || ''}`;
                            if (this.isUnregisteredGa4CustomDefinitionError(probe)) {
                                resolve(this.formatEnhancedTelData({ rows: [] }));
                                return;
                            }
                            if (errMsg) {
                                reject(new Error(errMsg));
                                return;
                            }
                            resolve(this.formatEnhancedTelData(data));
                        })
                        .catch((error) => {
                            if (error && 'AbortError' === error.name) {
                                reject(new Error('Request timed out. Please try again.'));
                            } else {
                                reject(new Error(`Fetch Error: ${  error.message}`));
                            }
                        })
                        .finally(() => {
                            clearTimeout(timeoutId);
                        });
                } else {
                    resolve(this.getMockData());
                }
            });
        },

        /**
         * Human-readable error from REST / GA4 payload (avoids treating string errors as arrays).
         *
         * @param {object} data Parsed JSON from get_pro_report
         * @returns {string|null} Error message or null if OK to render rows
         */
        /**
         * Strip tags and cap length for safe display (defense in depth vs XSS from API text).
         *
         * @param {*} raw
         * @returns {string}
         */
        sanitizeApiErrorText(raw) {
            if (null === raw || undefined === raw) {
                return '';
            }
            const s = String(raw).replace(/<[^>]*>/g, '');
            return 500 < s.length ? `${s.slice(0, 500)  }…` : s;
        },

        getEnhancedTelApiErrorMessage(data) {
            if (!data || 'object' !== typeof data) {
                return this.sanitizeApiErrorText('Invalid response from server.');
            }
            if (data.ga_report_error) {
                const ge = data.ga_report_error;
                if ('string' === typeof ge) {
                    return this.sanitizeApiErrorText(ge) || 'Google Analytics report failed.';
                }
                if (ge && 'string' === typeof ge.message && ge.message.length) {
                    return this.sanitizeApiErrorText(ge.message) || 'Google Analytics report failed.';
                }
                if (ge && ge.status && ge.code) {
                    return this.sanitizeApiErrorText(`${ge.status} (${ge.code})`);
                }
                return 'Google Analytics report failed. Check custom dimensions on your GA4 property.';
            }
            if (data.error) {
                if ('string' === typeof data.error && data.error.length) {
                    return this.sanitizeApiErrorText(data.error) || 'Request failed.';
                }
                if (Array.isArray(data.error) && data.error.length && data.error[0]) {
                    const [first] = data.error;
                    if ('string' === typeof first) {
                        return this.sanitizeApiErrorText(first) || 'Request failed.';
                    }
                    if (first.message) {
                        return this.sanitizeApiErrorText(first.message) || 'Request failed.';
                    }
                }
                if ('object' === typeof data.error && data.error.message) {
                    return this.sanitizeApiErrorText(data.error.message) || 'Request failed.';
                }
            }
            return null;
        },

        /**
         * Concatenate raw GA error snippets from the REST payload (for matching before display).
         *
         * @param {object} data Parsed JSON.
         * @returns {string}
         */
        collectTelReportErrorSnippet(data) {
            if (!data || 'object' !== typeof data) {
                return '';
            }
            const parts = [];
            if (data.ga_report_error) {
                const ge = data.ga_report_error;
                if ('string' === typeof ge) {
                    parts.push(ge);
                } else if (ge && 'string' === typeof ge.message) {
                    parts.push(ge.message);
                }
            }
            if (data.error) {
                if ('string' === typeof data.error) {
                    parts.push(data.error);
                } else if (data.error && 'string' === typeof data.error.message) {
                    parts.push(data.error.message);
                }
            }
            const raw = data.debug && data.debug.raw_response;
            if (raw && raw.error) {
                if ('string' === typeof raw.error) {
                    parts.push(raw.error);
                } else if (raw.error && 'string' === typeof raw.error.message) {
                    parts.push(raw.error.message);
                }
            }
            return parts.join(' ');
        },

        /**
         * True when GA4 rejected a customEvent dimension/metric (not registered on the property).
         *
         * @param {string} text Message or combined probe string.
         * @returns {boolean}
         */
        isUnregisteredGa4CustomDefinitionError(text) {
            if (!text || 'string' !== typeof text) {
                return false;
            }
            const t = text
                .toLowerCase()
                .replace(/\u00a0/g, ' ')
                .replace(/\s+/g, ' ')
                .trim();
            if (-1 !== t.indexOf('not a valid dimension')) {
                return true;
            }
            if (-1 !== t.indexOf('not a valid metric')) {
                return true;
            }
            if (-1 !== t.indexOf('is not a valid dimension')) {
                return true;
            }
            if (-1 !== t.indexOf('is not a valid metric')) {
                return true;
            }
            if (-1 !== t.indexOf('customevent:wpa_')) {
                return true;
            }
            return false;
        },

        /**
         * @param {object} rawResponse debug.raw_response from REST
         * @returns {boolean}
         */
        rawTelResponseHasGaError(rawResponse) {
            if (!rawResponse || !rawResponse.error) {
                return false;
            }
            const e = rawResponse.error;
            if ('string' === typeof e && e.length) {
                return true;
            }
            return !!(e && 'string' === typeof e.message && e.message.length);
        },

        /**
         * @param {object} summary formatEnhancedTelData.summary shape
         * @param {object} row    Normalized row with device, hour, traffic_source, country_code
         * @param {number} clicks
         */
        accumulateRowIntoSummary(summary, row, clicks) {
            if (!summary || !row || 'number' !== typeof clicks || isNaN(clicks)) {
                return;
            }
            if (row.device) {
                summary.device_breakdown[row.device] =
                    (summary.device_breakdown[row.device] || 0) + clicks;
            }
            if (row.hour || 0 === row.hour || '0' === row.hour) {
                summary.peak_hours[row.hour] =
                    (summary.peak_hours[row.hour] || 0) + clicks;
            }
            if (row.traffic_source) {
                summary.traffic_sources[row.traffic_source] =
                    (summary.traffic_sources[row.traffic_source] || 0) + clicks;
            }
            const countryKey = row.country_code;
            if (countryKey) {
                summary.country_codes[countryKey] =
                    (summary.country_codes[countryKey] || 0) + clicks;
            }
        },

        /**
         * Format enhanced tel data
         */
        formatEnhancedTelData(data) {
            const formattedData = {
                rows: [],
                summary: {
                    device_breakdown: {},
                    peak_hours: {},
                    traffic_sources: {},
                    country_codes: {}
                }
            };

            if (0 < data.rows?.length) {
                formattedData.rows = data.rows;
                data.rows.forEach((row) => {
                    const clicks = parseInt(row.clicks || row.eventCount || 0, 10) || 0;
                    this.accumulateRowIntoSummary(formattedData.summary, row, clicks);
                });
            } else if (
                data.debug?.raw_response?.rows &&
                Array.isArray(data.debug.raw_response.rows) &&
                0 < data.debug.raw_response.rows.length &&
                !this.rawTelResponseHasGaError(data.debug.raw_response)
            ) {
                const rawRows = data.debug.raw_response.rows;
                rawRows.forEach((row) => {
                    const processedRow = {
                        phone_number: row['customEvent:wpa_link_action'] || '',
                        label: row['customEvent:wpa_link_label'] || '',
                        clicks: parseInt(row.eventCount || 0, 10) || 0,
                        device: row['customEvent:wpa_device_category'] || '',
                        day: row['customEvent:wpa_click_day'] || '',
                        hour: row.hour || row['customEvent:wpa_click_hour'] || '',
                        traffic_source: row['customEvent:wpa_traffic_source'] || '',
                        country_code: this.formatDialCode(
                            row['customEvent:wpa_country_code'] || ''
                        )
                    };
                    formattedData.rows.push(processedRow);

                    this.accumulateRowIntoSummary(formattedData.summary, processedRow, processedRow.clicks);
                });
            }

            return formattedData;
        },

        /**
         * Get "no activity" message (same as other dashboards)
         */
        getNoActivityMessage() {
            const rest = window.analytify_enhanced_tel_rest || window.analytify_stats_pro || window.analytify_stats_core;
            if (rest && rest.no_stats_message) {
                return rest.no_stats_message;
            }
            return 'No activity during this period.';
        },

        /**
         * Generic error message for failed loads (same as other dashboards).
         * Never expose raw API/cURL/timeout strings on the frontend.
         *
         * @returns {string}
         */
        getGenericErrorMessage() {
            const rest = window.analytify_enhanced_tel_rest || window.analytify_stats_pro || window.analytify_stats_core;
            if (rest && rest.error_message) {
                return rest.error_message;
            }
            return 'Something went wrong. Please try again.';
        },

        /**
         * Styled no-activity markup — same wpb-error-box icon used by the main table.
         * Used inside each analytify_general_status_boxes when there is no data.
         *
         * @param {string} [message]
         * @returns {string} HTML string
         */
        noActivityBoxHtml(message) {
            const msg = this.escapeHtml(message || this.getNoActivityMessage());
            return `<div class="analytify-stats-error-msg">
                        <div class="wpb-error-box">
                            <span class="blk">
                                <span class="line"></span>
                                <span class="dot"></span>
                            </span>
                            <span class="information-txt">${msg}</span>
                        </div>
                    </div>`;
        },

        /**
         * Escape text for safe HTML insertion (GA dimensions can contain arbitrary strings).
         *
         * @param {*} value Raw cell value
         * @returns {string}
         */
        escapeHtml(value) {
            if (null === value || value === undefined) {
                return '';
            }
            return String(value)
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;');
        },

        /**
         * Dial code for display (e.g. "92" -> "+92"); aligns with REST `country_code`.
         *
         * @param {*} value Raw code from GA
         * @returns {string}
         */
        formatDialCode(value) {
            if (null === value || value === undefined) {
                return '';
            }
            const s = String(value).trim();
            if (!s.length) {
                return '';
            }
            if (s.startsWith('+')) {
                return s;
            }
            if (/^\d+$/.test(s)) {
                return `+${s}`;
            }
            return s;
        },

        /**
         * Country code column (custom dimension `wpa_country_code` only).
         *
         * @param {object} row Row from REST
         * @returns {string}
         */
        getCountryCellLabel(row) {
            const code = this.formatDialCode(row.country_code);
            return code.length ? code : 'N/A';
        },

        /**
         * Display enhanced tel data in table
         */
        displayEnhancedTelData(data) {
            const $root = $('.analytify_tel-links');
            const $msg = $root.find('.analytify-tel-table-message');
            const $dataWrap = $root.find('.analytify-tel-datatable');
            const $tbody = $root.find('.enhanced-tel-tbody');

            $tbody.empty();
            $msg.empty();

            const noActivityMsg = this.escapeHtml(this.getNoActivityMessage());

            this.lastTelExportData = null;

            if (!data?.rows?.length) {
                $dataWrap.hide();
                $msg.show().html(`
                    <div class="analytify-stats-error-msg analytify_tel_center_msg">
                        <div class="wpb-error-box">
                            <span class="blk">
                                <span class="line"></span>
                                <span class="dot"></span>
                            </span>
                            <span class="information-txt">${noActivityMsg}</span>
                        </div>
                    </div>
                `);
                this.hideLoading();
                return;
            }

            $msg.hide();
            $dataWrap.show();

            this.lastTelExportData = data;

            data.rows.forEach((row, index) => {
                $tbody.append(
                    $('<tr></tr>').append(
                        $('<td class="analytify_txt_center"></td>').text(index + 1),
                        $('<td></td>').text(row.phone_number !== undefined && null !== row.phone_number && String(row.phone_number).length ? row.phone_number : 'N/A'),
                        $('<td></td>').text(row.label !== undefined && null !== row.label && String(row.label).length ? row.label : 'N/A'),
                        $('<td class="analytify_txt_center analytify_value_row"></td>').text(null != row.clicks ? row.clicks : 0),
                        $('<td></td>').text(row.device !== undefined && null !== row.device && String(row.device).length ? row.device : 'N/A'),
                        $('<td></td>').text(row.day !== undefined && null !== row.day && String(row.day).length ? row.day : 'N/A'),
                        $('<td></td>').text(row.traffic_source !== undefined && null !== row.traffic_source && String(row.traffic_source).length ? row.traffic_source : 'N/A'),
                        $('<td></td>').text(this.getCountryCellLabel(row))
                    )
                );
            });

            this.hideLoading();
        },

        /**
         * Display summary panels
         */
        displaySummaryCards(data) {
            if (!data?.summary) {return;}
            this.displayDeviceBreakdown(data.summary.device_breakdown);
            this.displayPeakHours(data.summary.peak_hours);
            this.displayTrafficSources(data.summary.traffic_sources);
            this.displayCountryCodes(data.summary.country_codes);
        },

        /**
         * Clear summary box content (on error / empty result).
         *
         * @param {string} [message] Optional message; defaults to no-activity text.
         */
        clearSummaryCards(message) {
            const html = this.noActivityBoxHtml(message);
            $('.analytify-tel-device-breakdown, .analytify-tel-peak-hours, .analytify-tel-traffic-sources, .analytify-tel-country-codes').html(html);
        },

        /**
         * Device Breakdown box — top device as the KPI value, full breakdown as sub-lines.
         */
        displayDeviceBreakdown(deviceData) {
            const container = $('.analytify-tel-device-breakdown');
            if (!deviceData || 0 === Object.keys(deviceData).length) {
                container.html(this.noActivityBoxHtml());
                return;
            }

            const total   = Object.values(deviceData).reduce((a, b) => a + b, 0);
            const entries = Object.entries(deviceData).sort((a, b) => b[1] - a[1]);
            const [[topDevice]] = entries;

            let html = `<div class="analytify_general_stats_value">${this.escapeHtml(topDevice)}</div>`;
            entries.forEach(([device, count]) => {
                const pct = ((count / total) * 100).toFixed(0);
                html += `<p>${this.escapeHtml(device)}: ${count} (${pct}%)</p>`;
            });
            container.html(html);
        },

        /**
         * Peak Hour box — busiest hour as the KPI value, total calls as sub-line.
         */
        displayPeakHours(hoursData) {
            const container = $('.analytify-tel-peak-hours');
            if (!hoursData || 0 === Object.keys(hoursData).length) {
                container.html(this.noActivityBoxHtml());
                return;
            }

            const entries   = Object.entries(hoursData).sort((a, b) => b[1] - a[1]);
            const [[peakKey, peakCount]] = entries;
            const peakKeyStr = String(peakKey);
            const peakLabel = /^\d+$/.test(peakKeyStr) ?
                `${this.escapeHtml(peakKeyStr)}:00` :
                this.escapeHtml(peakKey);

            container.html(
                `<div class="analytify_general_stats_value">${peakLabel}</div>` +
                `<p>${this.escapeHtml(String(peakCount))} calls at peak</p>`
            );
        },

        /**
         * Traffic Sources box — top source as the KPI value, full list as sub-lines.
         */
        displayTrafficSources(sourcesData) {
            const container = $('.analytify-tel-traffic-sources');
            if (!sourcesData || 0 === Object.keys(sourcesData).length) {
                container.html(this.noActivityBoxHtml());
                return;
            }

            const entries = Object.entries(sourcesData).sort((a, b) => b[1] - a[1]);
            const [[topSrc]] = entries;

            let html = `<div class="analytify_general_stats_value">${this.escapeHtml(topSrc)}</div>`;
            entries.forEach(([src, count]) => {
                html += `<p>${this.escapeHtml(src)}: ${count}</p>`;
            });
            container.html(html);
        },

        /**
         * Country Codes box — top code as the KPI value, full list as sub-lines.
         */
        displayCountryCodes(countriesData) {
            const container = $('.analytify-tel-country-codes');
            if (!countriesData || 0 === Object.keys(countriesData).length) {
                container.html(this.noActivityBoxHtml());
                return;
            }

            const entries = Object.entries(countriesData).sort((a, b) => b[1] - a[1]);
            const [[topCode]] = entries;

            let html = `<div class="analytify_general_stats_value">${this.escapeHtml(topCode)}</div>`;
            entries.forEach(([code, count]) => {
                html += `<p>${this.escapeHtml(code)}: ${count} calls</p>`;
            });
            container.html(html);
        },

        showLoading() {
            $('.analytify_tel-links .analytify_stats_loading').show();
            $('.analytify_tel-links .analytify_status_body').hide();
            const sk = '<p class="skt-loading light-gray" style="min-height:40px;margin:0;"></p>';
            $('.analytify-tel-device-breakdown, .analytify-tel-peak-hours, .analytify-tel-traffic-sources, .analytify-tel-country-codes').html(sk);
        },

        hideLoading() {
            $('.analytify_tel-links .analytify_stats_loading').hide();
            $('.analytify_tel-links .analytify_status_body').show();
        },

        showError(message) {
            const $root = $('.analytify_tel-links');
            const $msg = $root.find('.analytify-tel-table-message');
            const $dataWrap = $root.find('.analytify-tel-datatable');
            $root.find('.enhanced-tel-tbody').empty();
            $dataWrap.hide();
            const displayMsg = message || this.getGenericErrorMessage();
            const safe = this.escapeHtml(displayMsg);
            $msg.show().html(`
                <div class="analytify-stats-error-msg">
                    <div class="wpb-error-box">
                        <span class="blk">
                            <span class="line"></span>
                            <span class="dot"></span>
                        </span>
                        <span class="information-txt">${safe}</span>
                    </div>
                </div>
            `);
            this.hideLoading();
            this.clearSummaryCards(displayMsg);
        },

        /**
         * Escape a field for CSV (RFC 4180 style).
         *
         * @param {*} val
         * @returns {string}
         */
        csvEscapeField(val) {
            const s = String(null !== val && undefined !== val ? val : '');
            if (/[",\r\n]/.test(s)) {
                return `"${s.replace(/"/g, '""')}"`;
            }
            return s;
        },

        exportData() {
            const data = this.lastTelExportData;
            if (!data?.rows?.length) {
                window.alert('No data to export. Load stats first.');
                return;
            }
            const headers = [
                '#',
                'Phone Number',
                'Label',
                'Clicks',
                'Device',
                'Day',
                'Source',
                'Country code',
            ];
            const lines = [headers.join(',')];
            data.rows.forEach((row, index) => {
                const cells = [
                    index + 1,
                    row.phone_number,
                    row.label,
                    row.clicks,
                    row.device,
                    row.day,
                    row.traffic_source,
                    this.getCountryCellLabel(row),
                ].map((c) => this.csvEscapeField(c));
                lines.push(cells.join(','));
            });
            const blob = new Blob([lines.join('\r\n')], { type: 'text/csv;charset=utf-8;' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'enhanced-tel-links.csv';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        },

        getDefaultStartDate() {
            const date = new Date();
            date.setMonth(date.getMonth() - 1);
            return date.toISOString().split('T')[0];
        },

        getDefaultEndDate() {
            return new Date().toISOString().split('T')[0];
        },

        getMockData() {
            return {
                rows: [],
                summary: {}
            };
        }
    };

    $(document).ready(() => {
        if (
            0 < $('.analytify_tel-links').length ||
            0 < $('h1:contains("Enhanced Tel Link Analytics")').length ||
            window.location.href.includes('analytify-enhanced-tel-tracking')
        ) {
            EnhancedTelDashboard.init();
        }
    });

    window.loadEnhancedTelData = () => EnhancedTelDashboard.loadEnhancedTelData();

}(jQuery));
