<?php
/**
 * Events Tracking Class.
 *
 * @package WP_Analytify_Pro
 */

// phpcs:ignoreFile WordPress.Files.FileName.InvalidClassFileName

/**
 * Class ANALYTIFY_EVENTS_TRACKING
 *
 * Handles events tracking functionality.
 */
class ANALYTIFY_EVENTS_TRACKING extends WP_Analytify_Pro_Base {

	/**
	 * Google Analytics measurement URL.
	 *
	 * @var string
	 */

	/**
	 * Google Analytics debug measurement URL.
	 *
	 * @var string
	 */
	private $google_debug_measurement_url = 'https://www.google-analytics.com/debug/collect';

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'wp_enqueue_scripts', array( $this, 'front_scripts' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_scripts' ) );

		// Extra events being tracked.
		add_action( 'wp_login', array( $this, 'signed_in' ), 10, 2 );
		add_action( 'wp_logout', array( $this, 'signed_out' ) );
		add_action( 'register_form', array( $this, 'viewed_signup' ) );
		add_action( 'user_register', array( $this, 'signed_up' ) );

		add_action( 'analytify_add_submenu', array( $this, 'add_menu' ), 60 );
		add_action( 'analytify_dashboad_dropdown_option', array( $this, 'dashboad_dropdown_option' ) );
		add_action( 'wp_analytify_events_tracking_license_key', array( $this, 'display_license_form' ), 11 );
		add_action( 'analytify_settings_logs', array( $this, 'settings_logs' ) );

		add_filter( 'wp_analytify_pro_setting_tabs', array( $this, 'settings_tab' ), 20, 1 );
		add_filter( 'wp_analytify_pro_setting_fields', array( $this, 'setting_fields' ), 20, 1 );
		add_filter( 'analytify_filter_navigation_items', array( $this, 'wpa_navigation_items' ) );
		add_action( 'admin_head', array( $this, 'hide_enhanced_tel_from_admin_menu' ) );
	}

	/**
	 * Adds the "Events Tracking" page in the wp menu
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function add_menu() {
		add_submenu_page(
			'analytify-dashboard',
			esc_html__( 'Track every Event with Analytify.', 'wp-analytify-pro' ),
			__( 'Events Tracking', 'wp-analytify-pro' ),
			'edit_posts',
			'analytify-events',
			array(
				$this,
				'analytify_page_file_path',
			),
			45
		);

		// Must stay in $submenu so user_can_access_admin_page() can resolve the parent (remove_submenu_page
		// breaks direct admin.php?page=... access). Hide the row visually — Conversions tab still links here.
		add_submenu_page(
			'analytify-dashboard',
			esc_html__( 'Enhanced Tel Analytics', 'wp-analytify-pro' ),
			__( 'Enhanced Tel Analytics', 'wp-analytify-pro' ),
			'edit_posts',
			'analytify-enhanced-tel-tracking',
			array(
				$this,
				'enhanced_tel_dashboard_page',
			)
		);
	}

	/**
	 * Hide Enhanced Tel from the Analytify sidebar without unregistering it (see add_menu()).
	 *
	 * @return void
	 */
	public function hide_enhanced_tel_from_admin_menu() {
		if ( ! is_admin() ) {
			return;
		}
		?>
		<style id="analytify-hide-enhanced-tel-submenu">
			#toplevel_page_analytify-dashboard .wp-submenu li:has(> a[href*="admin.php?page=analytify-enhanced-tel-tracking"]) {
				display: none !important;
			}
		</style>
		<?php
	}

	/**
	 * Add dropdown option for tracking dashboard.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function dashboad_dropdown_option() {
		echo '<li><a href="' . esc_url( admin_url( 'admin.php?page=analytify-events' ) ) . '">' . esc_html( 'Events' ) . '</a></li>';
	}

	/**
	 * Add "Enhanced Tel Analytics" to the Conversions navigation group.
	 *
	 * @param array $nav_items Existing navigation items.
	 * @return array Updated navigation items.
	 */
	public function wpa_navigation_items( $nav_items ) {

		if ( ! empty( $nav_items ) ) {
			foreach ( $nav_items as $key => $item ) {
				if ( 'Conversions' === $item['name'] ) {
					$nav_items[ $key ]['children'][] = array(
						'name'        => 'Enhanced Tel Analytics',
						'sub_name'    => 'Track phone link clicks',
						'page_slug'   => 'analytify-enhanced-tel-tracking',
						'addon_slug'  => 'events-tracking',
						'module_type' => 'pro_feature',
					);
				}
			}
		}
		return $nav_items;
	}

	/**
	 * Get the page file path for events tracking dashboard.
	 *
	 * @return void
	 */
	public function analytify_page_file_path() {

		$screen = get_current_screen();
		$base   = ( $screen && isset( $screen->base ) && is_string( $screen->base ) ) ? $screen->base : '';

		if ( $base !== '' && strpos( $base, 'analytify-events' ) !== false ) {

			$wp_analytify   = $GLOBALS['WP_ANALYTIFY'];
			$selected_stats = $wp_analytify->settings->get_option( 'show_analytics_panels_dashboard', 'wp-analytify-dashboard', array() );

			$dashboard_profile_id = class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_reporting_property' ) ? WPANALYTIFY_Utils::get_reporting_property() : '';
			$access_token         = get_option( 'post_analytics_token' );
			$version              = defined( 'ANALYTIFY_PRO_VERSION' ) ? ANALYTIFY_PRO_VERSION : ANALYTIFY_VERSION;

			// Get the start date and end date from wpa-core-functions
			$start_date = '';
			$end_date   = '';
			if ( function_exists( 'analytify_datepicker_dates' ) ) {
				$dates = analytify_datepicker_dates();
				if ( is_array( $dates ) ) {
					$start_date = isset( $dates['start_date'] ) ? $dates['start_date'] : wp_date( 'Y-m-d', strtotime( '-1 month' ) );
					$end_date   = isset( $dates['end_date'] ) ? $dates['end_date'] : wp_date( 'Y-m-d', strtotime( 'now' ) );
				}
			} else {
				$start_date = wp_date( 'Y-m-d', strtotime( '-1 month' ) );
				$end_date   = wp_date( 'Y-m-d', strtotime( 'now' ) );
			}

			// Get compare dates for legacy version (before v5.0.0).
			$date_diff          = class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'calculate_date_diff' ) ? WPANALYTIFY_Utils::calculate_date_diff( $start_date, $end_date ) : array(
				'start_date' => '',
				'end_date'   => '',
			);
			$compare_start_date = $date_diff['start_date'];
			$compare_end_date   = $date_diff['end_date'];

			/*
			 * Check with roles assigned at dashboard settings.
			 */
			$is_access_level = $wp_analytify->settings->get_option( 'show_analytics_roles_dashboard', 'wp-analytify-dashboard' );

			// Show dashboard to admin incase of empty access roles.
			if ( empty( $is_access_level ) ) {
				$is_access_level = array( 'administrator' );
			}

			if ( $wp_analytify->pa_check_roles( $is_access_level ) ) {
				if ( $access_token ) {
					// Dequeue event calendar js.
					wp_dequeue_script( 'tribe-common' );

					if ( defined( 'ANALYTIFY_PRO_ROOT_PATH' ) ) {
						require_once ANALYTIFY_PRO_ROOT_PATH . '/inc/modules/events-tracking/view/admin-dashboard.php';
					}
				} else {
					esc_html_e( 'You must be authenticated to see the Analytics Dashboard.', 'wp-analytify-pro' );
				}
			} else {
				esc_html_e( 'You don\'t have access to Analytify Dashboard.', 'wp-analytify-pro' );
			}
		}
	}

	/**
	 * Enqueue frontend scripts for events tracking.
	 *
	 * @return void
	 */
	public function front_scripts() {

		// Make sure that the GA tracking code is being included.
		if ( 'on' === $GLOBALS['WP_ANALYTIFY']->settings->get_option( 'install_ga_code', 'wp-analytify-profile', 'off' ) ) {

			global $current_user;

			$roles = $current_user->roles;

			if ( ! isset( $roles[0] ) || ! in_array( $roles[0], $GLOBALS['WP_ANALYTIFY']->settings->get_option( 'exclude_users_tracking', 'wp-analytify-profile', array() ), true ) ) {

				wp_enqueue_script( 'analytify-events-tracking', plugins_url( 'assets/js/analytify-events-tracking' . analytify_pro_get_asset_suffix() . '.js', dirname( __FILE__ ) ), array( 'jquery' ), ANALYTIFY_PRO_VERSION );

				wp_localize_script(
					'analytify-events-tracking',
					'analytify_events_tracking',
					array(
						'ajaxurl'            => admin_url( 'admin-ajax.php' ),
						'tracking_mode'      => ANALYTIFY_TRACKING_MODE,
						'ga_mode'            => class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) ? WPANALYTIFY_Utils::get_ga_mode() : 'ga3',
						'tracking_code'      => class_exists( 'WP_ANALYTIFY_FUNCTIONS' ) && method_exists( 'WP_ANALYTIFY_FUNCTIONS', 'get_UA_code' ) ? WP_ANALYTIFY_FUNCTIONS::get_UA_code() : '',
						'is_track_user'      => function_exists( 'analytify_is_track_user' ) ? analytify_is_track_user() : true,
						'root_domain'        => $this->get_root_domain(),
						'affiliate_link'     => $GLOBALS['WP_ANALYTIFY']->settings->get_option( 'affiliate_link_path', 'wp-analytify-events-tracking', '' ),
						'download_extension' => $GLOBALS['WP_ANALYTIFY']->settings->get_option( 'file_extension', 'wp-analytify-events-tracking', 'zip|mp3*|mpe*g|pdf|docx*|pptx*|xlsx*|rar*' ),
						'anchor_tracking'    => $GLOBALS['WP_ANALYTIFY']->settings->get_option( 'anchor_tracking', 'wp-analytify-events-tracking' ),
					)
				);

			}
		}
	}

	/**
	 * Enqueue admin scripts for events tracking.
	 *
	 * @param string $hook_suffix Current admin page hook suffix (not a WP_Screen object).
	 *
	 * @return void
	 */
	public function admin_scripts( $hook_suffix ) {
		$hook_suffix = is_string( $hook_suffix ) ? $hook_suffix : '';
		$suffix      = analytify_pro_get_asset_suffix();

		if ( 'analytify_page_analytify-settings' === $hook_suffix ) {
			wp_enqueue_style( 'analytify-events-style', plugins_url( "assets/css/analytify-events-tracking{$suffix}.css", __DIR__ ), array(), ANALYTIFY_PRO_VERSION );
			wp_enqueue_script( 'analytify-events-admin', plugins_url( "assets/js/analytify-events-admin{$suffix}.js", __DIR__ ), array( 'jquery' ), ANALYTIFY_PRO_VERSION, false );
		}
		// Only enqueue enhanced tel dashboard scripts on the enhanced tel page.
		$should_enqueue = false !== strpos( $hook_suffix, 'analytify-enhanced-tel-tracking' )
			|| false !== strpos( $hook_suffix, 'enhanced-tel-tracking' );

		if ( isset( $_GET['page'] ) && 'analytify-enhanced-tel-tracking' === sanitize_key( wp_unslash( $_GET['page'] ) ) ) {
			$should_enqueue = true;
		}

		if ( $should_enqueue ) {
			// Enqueue core dashboard scripts as they are required for the datepicker.
			if ( class_exists( 'Analytify_Scripts_Styles' ) ) {
				$wp_analytify = $GLOBALS['WP_ANALYTIFY'];
				$scripts      = new Analytify_Scripts_Styles( $wp_analytify );
				if ( method_exists( $scripts, 'admin_scripts' ) ) {
					$scripts->admin_scripts( 'analytify_page_analytify-events' );
				}
				if ( method_exists( $scripts, 'admin_styles' ) ) {
					$scripts->admin_styles( 'analytify_page_analytify-events' );
				}
			}

			// Enhanced tel dashboard assets; JS depends on analytify-stats-pro for get_pro_report REST config.
			wp_enqueue_style(
				'enhanced-tel-dashboard',
				plugins_url( "assets/css/enhanced-tel-dashboard{$suffix}.css", __DIR__ ),
				array( 'wp-analytify-default-style' ),
				ANALYTIFY_PRO_VERSION
			);
			wp_enqueue_script(
				'enhanced-tel-dashboard',
				plugins_url( "assets/js/enhanced-tel-dashboard{$suffix}.js", dirname( __FILE__ ) ),
				array( 'jquery', 'analytify-dashboard-js', 'analytify-stats-pro' ),
				ANALYTIFY_PRO_VERSION,
				true
			);

			// Localize script for REST API access
			$rest_url = esc_url_raw( get_rest_url() );
			$api_url = $rest_url . 'wp-analytify/v1/get_pro_report/';
			
			wp_localize_script( 'enhanced-tel-dashboard', 'analytify_stats_core', array(
				'url' => $api_url,
				'delimiter' => WPANALYTIFY_Utils::get_delimiter(),
				'ga_mode' => WPANALYTIFY_Utils::get_ga_mode(),
				'ga4_report_url' => WP_ANALYTIFY_FUNCTIONS::get_ga_report_url( WPANALYTIFY_Utils::get_reporting_property() ),
				'nonce' => wp_create_nonce( 'wp_rest' ),
				'load_via_ajax' => true,
				'dist_js_url' => plugins_url( 'assets/js/', dirname( __FILE__ ) ),
				'no_stats_message' => __( 'No activity during this period.', 'wp-analytify' ),
				'error_message' => __( 'Something went wrong. Please try again.', 'wp-analytify' ),
			) );
		}
	}

	/**
	 * Enhanced tel dashboard page callback
	 */
	public function enhanced_tel_dashboard_page() {
		// This callback is only registered for this slug; avoid strpos( null ) when $screen->base is unset (e.g. some WP / hidden submenu edge cases).
		if ( ! isset( $_GET['page'] ) || 'analytify-enhanced-tel-tracking' !== sanitize_key( wp_unslash( $_GET['page'] ) ) ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Full form POST from core date_form; verified below when dates are submitted.
		if ( isset( $_POST['analytify_date_start'], $_POST['analytify_date_end'] ) ) {
			if ( ! isset( $_POST['analytify_enhanced_tel_date_nonce'] )
				|| ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['analytify_enhanced_tel_date_nonce'] ) ), 'analytify_enhanced_tel_date' ) ) {
				wp_die(
					esc_html__( 'Security check failed. Please reload the page and try again.', 'wp-analytify-pro' ),
					esc_html__( 'Error', 'wp-analytify-pro' ),
					array( 'response' => 403 )
				);
			}
		}

		$wp_analytify   = $GLOBALS['WP_ANALYTIFY'];
		$selected_stats = $wp_analytify->settings->get_option( 'show_analytics_panels_dashboard', 'wp-analytify-dashboard', array() );

		$dashboard_profile_id = is_callable( array( 'WPANALYTIFY_Utils', 'get_reporting_property' ) ) ? WPANALYTIFY_Utils::get_reporting_property() : '';
		$access_token         = get_option( 'post_analytics_token' );
		$version              = defined( 'ANALYTIFY_PRO_VERSION' ) ? ANALYTIFY_PRO_VERSION : ANALYTIFY_VERSION;

		// Get the start date and end date from wpa-core-functions
		$start_date = wp_date( 'Y-m-d', strtotime( '-1 month' ) );
		$end_date   = wp_date( 'Y-m-d', strtotime( 'now' ) );
		if ( function_exists( 'analytify_datepicker_dates' ) ) {
			$dates = analytify_datepicker_dates();
			if ( is_array( $dates ) ) {
				$start_date = isset( $dates['start_date'] ) ? $dates['start_date'] : $start_date;
				$end_date   = isset( $dates['end_date'] ) ? $dates['end_date'] : $end_date;
			}
		}

		// Get compare dates for legacy version (before v5.0.0).
		$date_diff          = is_callable( array( 'WPANALYTIFY_Utils', 'calculate_date_diff' ) ) ? WPANALYTIFY_Utils::calculate_date_diff( $start_date, $end_date ) : array(
			'start_date' => '',
			'end_date'   => '',
		);
		$compare_start_date = $date_diff['start_date'];
		$compare_end_date   = $date_diff['end_date'];

		/*
		 * Check with roles assigned at dashboard settings.
		 */
		$is_access_level = $wp_analytify->settings->get_option( 'show_analytics_roles_dashboard', 'wp-analytify-dashboard' );

		// Show dashboard to admin incase of empty access roles.
		if ( empty( $is_access_level ) ) {
			$is_access_level = array( 'administrator' );
		}

		if ( $wp_analytify->pa_check_roles( $is_access_level ) ) {
			if ( $access_token ) {
				// Dequeue event calendar js.
				wp_dequeue_script( 'tribe-common' );

				require_once ANALYTIFY_PRO_ROOT_PATH . '/inc/modules/events-tracking/view/enhanced-tel-dashboard.php';
			} else {
				_e( 'You must be authenticated to see the Analytics Dashboard.', 'wp-analytify-pro' );
			}
		} else {
			_e( 'You don\'t have access to Analytify Dashboard.', 'wp-analytify-pro' );
		}
	}

	/**
	 * License activation key fields/inputs
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function display_license_form() {
		$license_events_tracking = get_option( 'analytify_events_tracking_license_key' );
		$status_events_tracking  = get_option( 'analytify_events_tracking_license_status' ); ?>

		<tr valign="top">
			<th scope="row" valign="top">
				<?php esc_html_e( 'Analytify for Events Tracking (License Key):', 'wp-analytify-pro' ); ?>
			</th>
			<?php if ( 'valid' === $status_events_tracking ) { ?>
				<td class="events-tracking-row">
				<?php echo wp_kses_post( $this->get_formatted_masked_events_tracking_license( $license_events_tracking ) ); ?>
				</td>
			<?php } else { ?>
			<td class="events-tracking-row">
				<input id="analytify_events_tracking_license_key" name="analytify_events_tracking_license_key" type="text" class="regular-text" value="<?php echo esc_attr( $license_events_tracking ); ?>" />
				<input type="submit" class="button-secondary" id="analytify_events_tracking_license_activate" name="analytify_license_activate" value="<?php esc_attr_e( 'Activate License', 'wp-analytify-pro' ); ?>"/>
				<br />
				<p id="google-events-tracking-status">
				<?php
				if ( $status_events_tracking ) {
					echo esc_html( $status_events_tracking );
				}
				?>
				</p>
			</td>
			<?php } ?>
		</tr>
	
		<?php
	}

	/**
	 * Get the root domain from site URL.
	 *
	 * @return string Root domain
	 */
	public function get_root_domain() {
		$url  = site_url();
		$root = explode( '/', $url );
		preg_match( '/(?P<domain>[a-z0-9][a-z0-9\-]{1,63}\.[a-z\.]{2,6})$/i', str_ireplace( 'www', '', isset( $root[2] ) ? $root[2] : $url ), $root );
		if ( isset( $root['domain'] ) ) {
			return $root['domain'];
		} else {
			return '';
		}
	}

	/**
	 * Track user sign up event.
	 *
	 * @param int $user_id User ID.
	 *
	 * @return void
	 */
	public function signed_up( $user_id ) {

		if ( function_exists( 'analytify_mp_ga4' ) && class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {
			if ( ! apply_filters( 'analytify_mics_tracking', true, 'signed_up' ) ) {
				return;
			}

			$event = array(
				'name'   => 'sign_up',
				'params' => array(
					'method'         => 'WP - ' . site_url(),
					'wpa_link_label' => get_user_by( 'id', $user_id ) ? get_user_by( 'id', $user_id )->user_login : '',
					'wpa_user_id'    => $user_id,
				),
			);
			analytify_mp_ga4( array( $event ) );
			return;
		}

		// UA call.
		$attr = array(
			't'  => 'event',
			'ec' => 'Tracking by Analytify', // category
			'ea' => 'Sign Up',
		);

		$this->hit( $attr );
	}

	/**
	 * Track user sign out event.
	 *
	 * @param int $user_id User ID.
	 *
	 * @return void
	 */
	public function signed_out( $user_id ) {

		if ( function_exists( 'analytify_mp_ga4' ) && class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {
			if ( ! apply_filters( 'analytify_mics_tracking', true, 'signed_out' ) ) {
				return;
			}

			$event = array(
				'name'   => 'logout',
				'params' => array(
					'method'         => 'WP - ' . site_url(),
					'wpa_link_label' => get_user_by( 'id', $user_id ) ? get_user_by( 'id', $user_id )->user_login : '',
					'wpa_user_id'    => $user_id,
				),
			);
			analytify_mp_ga4( array( $event ) );
			return;
		}

		// UA call.
		$attr = array(
			't'  => 'event',
			'ec' => 'Tracking by Analytify', // category
			'ea' => 'Logout',
		);

		$this->hit( $attr );
	}

	/**
	 * Track user sign in event.
	 *
	 * @param string  $user_login User login.
	 * @param WP_User $user       User object.
	 *
	 * @return void
	 */
	public function signed_in( $user_login, $user ) {

		if ( function_exists( 'analytify_mp_ga4' ) && class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {
			if ( ! apply_filters( 'analytify_mics_tracking', true, 'signed_in' ) ) {
				return;
			}

			$event = array(
				'name'   => 'login',
				'params' => array(
					'method'         => 'WP - ' . site_url(),
					'wpa_link_label' => $user_login,
					'wpa_user_id'    => $user->ID,
				),
			);
			analytify_mp_ga4( array( $event ) );
			return;
		}

		// UA call.
		$attr = array(
			't'   => 'event',
			'ec'  => 'Tracking by Analytify', // category
			'ea'  => 'Login',
			'el'  => $user_login, // Evnet Label
			'uid' => $user->ID,
		);

		// logged in at checkout
		$this->hit( $attr );
	}

	/**
	 * Track viewed signup form event.
	 *
	 * @return void
	 */
	public function viewed_signup() {

		if ( function_exists( 'analytify_mp_ga4' ) && class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {
			if ( ! apply_filters( 'analytify_mics_tracking', true, 'viewed_signup' ) ) {
				return;
			}

			$event = array(
				'name'   => 'sign_up_form',
				'params' => array(
					'method' => 'WP - ' . site_url(),
				),
			);
			analytify_mp_ga4( array( $event ) );
			return;
		}

		// UA call.
		$attr = array(
			't'  => 'event',
			'ec' => 'Tracking by Analytify', // category
			'ea' => 'View Signup',
		);

		$this->hit( $attr );
	}

	/**
	 * Get client ID from Google Analytics cookie (events-tracking).
	 *
	 * @param int $order_id Optional. Order ID (unused in events-tracking; for parent signature compatibility).
	 * @return string Client ID
	 */
	public function get_events_tracking_cid( $order_id = 0 ) {
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.MissingUnslash
		if ( ! empty( $_COOKIE['_ga'] ) ) {
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.MissingUnslash
			$cookie_parts = preg_split( '/[\.]/', $_COOKIE['_ga'], 4 );
			if ( is_array( $cookie_parts ) && count( $cookie_parts ) >= 4 && isset( $cookie_parts[0], $cookie_parts[1], $cookie_parts[2], $cookie_parts[3] ) ) {
				list($version, $domain_depth, $cid1, $cid2) = $cookie_parts;
				$contents                                   = array(
					'version'      => $version,
					'domain_depth' => $domain_depth,
					'cid'          => $cid1 . '.' . $cid2,
				);
				$cid                                        = $contents['cid'];

				return $cid;
			}
		}
		return $this->generate_uuid();
	}

	/**
	 * Generate UUID v4 function - needed to generate a CID when one isn't available
	 *
	 * @link http://www.stumiller.me/implementing-google-analytics-measurement-protocol-in-php-and-wordpress/
	 *
	 * @since 1.0.0
	 * @return string
	 */
	public function generate_uuid() {
		// phpcs:disable WordPress.WP.AlternativeFunctions.rand_mt_rand
		return sprintf(
			'%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
			// 32 bits for "time_low".
			mt_rand( 0, 0xffff ),
			mt_rand( 0, 0xffff ),
			// 16 bits for "time_mid".
			mt_rand( 0, 0xffff ),
			// 16 bits for "time_hi_and_version".
			// four most significant bits holds version number 4.
			mt_rand( 0, 0x0fff ) | 0x4000,
			// 16 bits, 8 bits for "clk_seq_hi_res".
			// 8 bits for "clk_seq_low".
			// two most significant bits holds zero and one for variant DCE1.1.
			mt_rand( 0, 0x3fff ) | 0x8000,
			// 48 bits for "node".
			mt_rand( 0, 0xffff ),
			mt_rand( 0, 0xffff ),
			mt_rand( 0, 0xffff )
		);
		// phpcs:enable WordPress.WP.AlternativeFunctions.rand_mt_rand
	}

	/**
	 * Send hit to Google Analytics (Universal Analytics / Measurement Protocol).
	 *
	 * On failure, logs via {@see wp_analytify_pro_log_measurement_remote_result()} (redacted hit, HTTP context),
	 * only on `WP_Error` or HTTP status &gt;= 400.
	 *
	 * @since 9.0.0
	 * @param array<string, mixed> $attr  Hit attributes.
	 * @param bool                 $debug Debug mode.
	 *
	 * @return void|false
	 */
	public function hit( $attr, $debug = false ) {
		$default_args = array(
			't'  => 'event', // Required - Hit type
			'ec' => '', // Event category
			'ea' => '', // Event Action
			'el' => '', // Event Label
			'ev' => null, // Event Value
		);

		$body = array_merge( $default_args, $attr );

		// phpcs:disable WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.MissingUnslash
		if ( ! empty( $_SERVER['HTTP_CLIENT_IP'] ) ) {
			$ip = $_SERVER['HTTP_CLIENT_IP'];
		} elseif ( ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
			$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		} elseif ( isset( $_SERVER['REMOTE_ADDR'] ) ) {
			$ip = $_SERVER['REMOTE_ADDR'];
		} else {
			$ip = '';
		}

		$user_language = isset( $_SERVER['HTTP_ACCEPT_LANGUAGE'] ) ? explode( ',', $_SERVER['HTTP_ACCEPT_LANGUAGE'] ) : array();
		$user_language = reset( $user_language );

		$default_body = array(
			'v'   => '1', // Required - Version.
			'tid' => class_exists( 'WP_ANALYTIFY_FUNCTIONS' ) && method_exists( 'WP_ANALYTIFY_FUNCTIONS', 'get_UA_code' ) ? WP_ANALYTIFY_FUNCTIONS::get_UA_code() : '', // Required - UA code.
			'cid' => $this->get_events_tracking_cid(), // Required - Unique (anonymous) visitor ID.
			't'   => 'pageview', // Required - Hit type.
			'ni'  => true, // Non interaction.

			'dh'  => str_replace( array( 'http://', 'https://' ), '', site_url() ),
			'dp'  => isset( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : '',
			'dt'  => get_the_title(),

			// Hits that usually also go with JS.
			'ul'  => $user_language, // Optional - User language.

			'uip' => $ip, // Optional - User IP, to make sure its not the servers'.
			'ua'  => isset( $_SERVER['HTTP_USER_AGENT'] ) ? $_SERVER['HTTP_USER_AGENT'] : '', // Optional - User Agent.

		);
		// phpcs:enable WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.MissingUnslash

		$body = wp_parse_args( $body, $default_body );

		// Requests without ID are ignored by GA.
		if ( false === $body['cid'] ) {
			return false;
		}

		if ( $debug ) {
			$response = wp_remote_post(
				$this->google_debug_measurement_url,
				array(
					'method'   => 'POST',
					'blocking' => true,
					'body'     => array_merge( $body, array( 'z' => time() ) ),
				)
			);

			print '<pre>';
			// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_print_r
			print_r( $response );
			print '</pre>';
		} else {
			$post_body = array_merge( $body, array( 'z' => time() ) );
			$response  = wp_remote_post(
				ANALYTIFY_GOOGLE_MEASUREMENT_URL,
				array(
					'method'   => 'POST',
					'timeout'  => 5,
					'blocking' => false,
					'body'     => $post_body,
				)
			);

			if ( is_wp_error( $response ) ) {
				wp_analytify_pro_log_measurement_remote_result(
					'Failed to send event hit to Google Analytics (UA).',
					'Google Analytics (UA) collect returned an HTTP error for an event hit.',
					'ANALYTIFY_EVENTS_TRACKING::hit',
					$post_body,
					$response
				);
			} elseif ( is_array( $response ) && wp_remote_retrieve_response_code( $response ) >= 400 ) {
				wp_analytify_pro_log_measurement_remote_result(
					'Failed to send event hit to Google Analytics (UA).',
					'Google Analytics (UA) collect returned an HTTP error for an event hit.',
					'ANALYTIFY_EVENTS_TRACKING::hit',
					$post_body,
					$response
				);
			}
		}
	}

	/**
	 * Add settings tab for events tracking.
	 *
	 * @param array<string, mixed> $old_tabs Existing tabs.
	 *
	 * @return array<string, mixed> Updated tabs
	 */
	public function settings_tab( $old_tabs ) {
		$pro_tabs = array(
			array(
				'id'       => 'wp-analytify-events-tracking',
				'title'    => __( 'Events Tracking', 'wp-analytify-pro' ),
				'desc'     => __( 'Track all events including clicks, links, files, extensions, affiliates.', 'wp-analytify-pro' ),
				'priority' => 0,
			),
		);

		return array_merge( $old_tabs, $pro_tabs );
	}

	/**
	 * Add settings fields for events tracking.
	 *
	 * @param array<string, mixed> $old_fields Existing fields.
	 *
	 * @return array<string, mixed> Updated fields
	 */
	public function setting_fields( $old_fields ) {

		$pro_fields = array();

		$pro_fields['wp-analytify-events-tracking'][] = array(
			'name'              => 'file_extension',
			'label'             => __( 'Extensions of files to track as downloads:', 'wp-analytify-pro' ),
			'desc'              => __( 'Add regex for file type.', 'wp-analytify-pro' ),
			'type'              => 'text',
			'default'           => 'zip|mp3*|mpe*g|pdf|docx*|pptx*|xlsx*|rar*',
			'sanitize_callback' => 'sanitize_text_field',
		);

		if ( class_exists( 'WP_Analytify_Settings' ) && method_exists( 'WP_Analytify_Settings', 'callback_affiliates_repeater' ) ) {

			$pro_fields['wp-analytify-events-tracking'][] = array(
				'name'    => 'affiliate_link_path',
				'label'   => __( 'Affiliate Links', 'wp-analytify-pro' ),
				'desc'    => __( 'Setup links of the affiliate you have partnered with for your website to make extra bucks.', 'wp-analytify-pro' ),
				'type'    => 'affiliates_repeater',
				'default' => array(),
			);
		}

		$pro_fields['wp-analytify-events-tracking'][] = array(
			'name'  => 'anchor_tracking',
			'label' => __( 'Turn on anchor tracking', 'wp-analytify-pro' ),
			'desc'  => __( 'Many WordPress \'1-page\' style themes rely on anchor tags for navigation to show virtual pages. The problem is that to Google Analytics, these are all just a single page, and it makes it hard to get meaningful statistics about pages viewed. This feature allows proper tracking in those themes.', 'wp-analytify-pro' ),
			'type'  => 'checkbox',
		);

		return array_merge( $old_fields, $pro_fields );
	}

	/**
	 * Add events tracking settings in diagnostic information.
	 *
	 * @return void
	 */
	public function settings_logs() {

		echo "-- Events Tracking Setting --\r\n \r\n";

		$options = get_option( 'wp-analytify-events-tracking' );

		if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'print_settings_array' ) ) {
			WPANALYTIFY_Utils::print_settings_array( $options );
		}
	}
}

new ANALYTIFY_EVENTS_TRACKING();

