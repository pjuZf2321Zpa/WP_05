<?php
/**
 * Enhanced Tel Dashboard View.
 *
 * @package WP_Analytify_Pro
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$enhanced_tel_rest_url = esc_url_raw( rest_url( 'wp-analytify/v1/get_pro_report/' ) );
$enhanced_tel_nonce    = wp_create_nonce( 'wp_rest' );
$enhanced_tel_delim    = class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_delimiter' )
	? WPANALYTIFY_Utils::get_delimiter()
	: ( strpos( esc_url_raw( get_rest_url() ), '/wp-json/' ) !== false ? '?' : '&' );
?>
<script>
// Pass PHP dates to JavaScript
window.analytify_dates = {
	start_date: '<?php echo esc_js( $start_date ); ?>',
	end_date: '<?php echo esc_js( $end_date ); ?>'
};
// REST config for enhanced-tel (inline so nonce is always fresh for this page load - avoids rest_cookie_invalid_nonce)
window.analytify_enhanced_tel_rest = {
	url: <?php echo wp_json_encode( $enhanced_tel_rest_url ); ?>,
	nonce: <?php echo wp_json_encode( $enhanced_tel_nonce ); ?>,
	delimiter: <?php echo wp_json_encode( $enhanced_tel_delim ); ?>,
	no_stats_message: <?php echo wp_json_encode( esc_html__( 'No activity during this period.', 'wp-analytify-pro' ) ); ?>,
	error_message: <?php echo wp_json_encode( esc_html__( 'Something went wrong. Please try again.', 'wp-analytify-pro' ) ); ?>
};
</script>

<div class="wpanalytify analytify-dashboard-nav">
	<div class="wpb_plugin_wraper">
		<div class="wpb_plugin_header_wraper">
			<div class="graph" aria-hidden="true"></div>
			<div class="wpb_plugin_header">
				<div class="wpb_plugin_header_title"></div>
				<div class="wpb_plugin_header_info">
					<a href="https://analytify.io/changelog/" target="_blank" class="btn"><?php echo esc_html__( 'View Changelog', 'wp-analytify-pro' ); ?></a>
				</div>
				<div class="wpb_plugin_header_logo">
					<img src="<?php echo esc_url( ANALYTIFY_PLUGIN_URL . 'assets/img/logo.svg' ); ?>" alt="Analytify">
				</div>
			</div>
		</div>

		<div class="analytify-dashboard-body-container">
			<div class="wpb_plugin_body_wraper">
					<div class="wpb_plugin_body">
						<div class="wpa-tab-wrapper">
							<?php
							$nav_html = $wp_analytify->dashboard_navigation();
							echo wp_kses_post( $nav_html ? $nav_html : '' );
							?>
						</div>

						<div class="wpb_plugin_tabs_content analytify-dashboard-content">
						<div class="analytify_wraper">
							<div class="analytify_main_title_section">
								<div class="analytify_dashboard_title">
									<h1 class="analytify_pull_left analytify_main_title"><?php esc_html_e( 'Enhanced Tel Link Analytics', 'wp-analytify-pro' ); ?></h1>
									<?php
									if ( ! WP_ANALYTIFY_FUNCTIONS::wpa_check_profile_selection( 'Analytify' ) && $wp_analytify->pa_check_roles( $is_access_level ) && $access_token && method_exists( 'WPANALYTIFY_Utils', 'dashboard_subtitle_section' ) ) {
										WPANALYTIFY_Utils::dashboard_subtitle_section();
									}
									?>
								</div>
								<div class="analytify_main_setting_bar">
									<div class="analytify_pull_right analytify_setting">
										<div class="analytify_select_date">
											<?php
											if ( ! WP_ANALYTIFY_FUNCTIONS::wpa_check_profile_selection( 'Analytify' ) && $wp_analytify->pa_check_roles( $is_access_level ) && $access_token && class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'date_form' ) ) {
												WPANALYTIFY_Utils::date_form(
													$start_date,
													$end_date,
													array(
														'input_before_field_set' => wp_nonce_field( 'analytify_enhanced_tel_date', 'analytify_enhanced_tel_date_nonce', true, false ),
													)
												);
											}
											?>
										</div>
									</div>
								</div>
							</div>

								<!-- Enhanced Tel Tracking Table -->
								<div class="analytify_general_status analytify_status_box_wraper analytify_tel-links">
							<div class="analytify_status_header analytify_header_adj">
								<h3>
									<?php esc_html_e( 'Enhanced Tel Link Analytics', 'wp-analytify-pro' ); ?>
									<a href="#" class="analytify-export-data analytify_tooltip" data-stats-type="enhanced-tel-links">
										<span class="analytify_tooltiptext"><?php esc_html_e( 'Export Enhanced Tel Links', 'wp-analytify-pro' ); ?></span>
									</a>
									<img src="<?php echo esc_url( admin_url( 'images/spinner.gif' ) ); ?>" class='analytify-export-loader' style="display:none">
								</h3>
							</div>
							<div class="analytify_status_body analytify-enhanced-tel-body">
								<?php // Table rows must live in <tbody>, not a div — otherwise browsers strip <tr> and dump cell text. ?>
								<div class="analytify-tel-table-message"></div>
								<div class="analytify-tel-datatable" style="display: none;">
									<table class="analytify_data_tables wp_analytify_paginated enhanced-tel-table analytify-tel-main-table">
										<thead>
											<tr>
												<th class="analytify_num_row" scope="col"><?php esc_html_e( '#', 'wp-analytify-pro' ); ?></th>
												<th class="analytify_txt_left" scope="col"><?php esc_html_e( 'Phone Number', 'wp-analytify-pro' ); ?></th>
												<th class="analytify_txt_left" scope="col"><?php esc_html_e( 'Label', 'wp-analytify-pro' ); ?></th>
												<th class="analytify_value_row" scope="col"><?php esc_html_e( 'Clicks', 'wp-analytify-pro' ); ?></th>
												<th class="analytify_txt_left" scope="col"><?php esc_html_e( 'Device', 'wp-analytify-pro' ); ?></th>
												<th class="analytify_txt_left" scope="col"><?php esc_html_e( 'Day', 'wp-analytify-pro' ); ?></th>
												<th class="analytify_txt_left" scope="col"><?php esc_html_e( 'Source', 'wp-analytify-pro' ); ?></th>
												<th class="analytify_txt_left" scope="col"><?php esc_html_e( 'Country Code', 'wp-analytify-pro' ); ?></th>
											</tr>
										</thead>
										<tbody class="enhanced-tel-tbody"></tbody>
									</table>
								</div>
							</div>
							<div class="analytify_stats_loading">
								<table class="analytify_data_tables wp_analytify_paginated">
									<thead>
										<tr>
											<th class="analytify_num_row"><p class="skt-loading light-gray"></p></th>
											<th class="analytify_txt_left"><p class="skt-loading light-gray"></p></th>
											<th class="analytify_txt_left"><p class="skt-loading light-gray"></p></th>
											<th class="analytify_value_row"><p class="skt-loading light-gray"></p></th>
											<th class="analytify_txt_left"><p class="skt-loading light-gray"></p></th>
											<th class="analytify_txt_left"><p class="skt-loading light-gray"></p></th>
											<th class="analytify_txt_left"><p class="skt-loading light-gray"></p></th>
											<th class="analytify_txt_left"><p class="skt-loading light-gray"></p></th>
										</tr>
									</thead>
									<tbody>
										<?php for ( $i = 0; $i < 5; $i++ ) { ?>
										<tr>
											<td class="analytify_txt_center"><p class="skt-loading"></p></td>
											<td><p class="skt-loading"></p></td>
											<td><p class="skt-loading"></p></td>
											<td class="analytify_txt_center"><p class="skt-loading"></p></td>
											<td><p class="skt-loading"></p></td>
											<td><p class="skt-loading"></p></td>
											<td><p class="skt-loading"></p></td>
											<td><p class="skt-loading"></p></td>
										</tr>
										<?php } ?>
									</tbody>
								</table>
							</div>
						</div>

						<!-- Summary — one panel, four status boxes, matching WooCommerce shopping-analysis pattern -->
						<div class="analytify_general_status analytify_status_box_wraper">
							<div class="analytify_status_header analytify_header_adj">
								<h3><?php esc_html_e( 'Call Analytics Summary', 'wp-analytify-pro' ); ?></h3>
							</div>
							<div class="analytify_status_body">
								<div class="analytify_general_status_boxes_wraper analytify-tel-summary-boxes">

									<div class="analytify_general_status_boxes">
										<h4><?php esc_html_e( 'Device Breakdown', 'wp-analytify-pro' ); ?></h4>
										<div class="analytify-tel-device-breakdown"></div>
									</div>

									<div class="analytify_general_status_boxes">
										<h4><?php esc_html_e( 'Peak Hour', 'wp-analytify-pro' ); ?></h4>
										<div class="analytify-tel-peak-hours"></div>
									</div>

									<div class="analytify_general_status_boxes">
										<h4><?php esc_html_e( 'Top Traffic Source', 'wp-analytify-pro' ); ?></h4>
										<div class="analytify-tel-traffic-sources"></div>
									</div>

									<div class="analytify_general_status_boxes">
										<h4><?php esc_html_e( 'Top Country Code', 'wp-analytify-pro' ); ?></h4>
										<div class="analytify-tel-country-codes"></div>
									</div>

								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
