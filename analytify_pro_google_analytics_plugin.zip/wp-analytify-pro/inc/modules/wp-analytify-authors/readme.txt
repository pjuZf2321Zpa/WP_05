Welcome!

For more help, checkout our YouTube Channel videos and Subscribe at https://www.youtube.com/channel/UCRjDcNZqf-Vo_2Ux_QLyBCA/videos

Our Documentation is available at https://analytify.io/documentation/

Cheers!
Adnan from Analytify LLC

== Installation ==
You should have installed Analytify Free + Pro versions to use this Analytify - Authors Tracking add-on.

If you have any problem, please send an email to us at support@analytify.io


Cheers
Adnan from Analytify LLC


== Changelog ==

= 5.1.0 - 2023-12-02 =
* Enhancement: Responsiveness issues fixed for all sections.
* Enhancement: Author name and uri changed to Analytify.

= 5.0.1 - 2023-05-30 =
* Enhancement: Use main dashboard saved date.
* Enhancement: Changelog button text updated.
* Compatibility: Compatible to WordPress 6.4.1 and PHP 8.2.10

= 5.0.0 - 2023-04-17 =
* New Feature: Google Analytics GA4 integration is added.
* New Feature: Google Search Console (webmasters) Integrated.
* Enhancement: Pageload speed improvement.
* Enhancement: UI Improvements.

= 2.0.2 - 28th February, 2022 =
* New Feature: Download CSV for author stats.

= 2.0.1 - 1st November, 2021 =
* New Feature: Add page views stats in reports.

= 2.0.0 - 21st July, 2021 =
* New Feature: Fetch Authors stats from custom dimensions.

= 1.0.0 - 12th March, 2021 =
* Initial Release


The full changelog is avaialable at https://analytify.io/changelog/
