<?php
/**
 * Author Dashboard View.
 *
 * @package WP_Analytify_Pro
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Initialize variables.
$wp_analytify    = $GLOBALS['WP_ANALYTIFY'] ?? null;
$access_token    = get_option( 'post_analytics_token' );
$is_access_level = array( 'administrator' );
if ( is_object( $wp_analytify ) && isset( $wp_analytify->settings ) ) {
	$is_access_level = $wp_analytify->settings->get_option( 'show_analytics_roles_dashboard', 'wp-analytify-dashboard', array( 'administrator' ) );
	$is_access_level = is_array( $is_access_level ) ? $is_access_level : array( 'administrator' );
}
$current_user_id = get_current_user_id();
if ( ! function_exists( 'get_editable_roles' ) ) {
	require_once ABSPATH . 'wp-admin/includes/user.php';
}
$authors_editable_roles = get_editable_roles();
if ( ! is_array( $authors_editable_roles ) ) {
	$authors_editable_roles = array();
}
$authors_counts     = count_users();
$authors_by_role    = isset( $authors_counts['avail_roles'] ) && is_array( $authors_counts['avail_roles'] )
	? $authors_counts['avail_roles']
	: array();
$authors_role_slugs = array();
foreach ( array_keys( $authors_editable_roles ) as $slug ) {
	$key = sanitize_key( (string) $slug );
	if ( '' !== $key && ! empty( $authors_by_role[ $key ] ) ) {
		$authors_role_slugs[] = $key;
	}
}
$authors_role_slugs = array_values( array_unique( $authors_role_slugs ) );
$authors_priority   = array( 'administrator', 'editor', 'author', 'contributor', 'subscriber' );
$authors_ordered    = array();
foreach ( $authors_priority as $p ) {
	if ( in_array( $p, $authors_role_slugs, true ) ) {
		$authors_ordered[] = $p;
	}
}
$authors_rest = array_diff( $authors_role_slugs, $authors_ordered );
sort( $authors_rest, SORT_STRING );
$authors_ordered = array_merge( $authors_ordered, $authors_rest );

// Max users per role in the select: role_slug => int; 'default' => fallback for other roles.
$authors_role_user_limits = apply_filters(
	'analytify_authors_dashboard_role_user_limits',
	array(
		'default' => 5,
	),
	$authors_ordered
);
if ( ! is_array( $authors_role_user_limits ) ) {
	$authors_role_user_limits = array( 'default' => 5 );
}

// Limit authors list to users who have published content.
$authors_published_post_types = apply_filters(
	'analytify_authors_dashboard_published_post_types',
	array( 'post', 'page' )
);
if ( ! is_array( $authors_published_post_types ) ) {
	$authors_published_post_types = array( 'post', 'page' );
}
$authors_published_post_types = array_values(
	array_filter(
		array_map( 'sanitize_key', $authors_published_post_types )
	)
);
if ( empty( $authors_published_post_types ) ) {
	$authors_published_post_types = array( 'post', 'page' );
}

$wp_current_user = wp_get_current_user();
$is_author_only  = function_exists( 'analytify_authors_is_dashboard_only_user' ) && analytify_authors_is_dashboard_only_user();
$start_date      = wp_date( 'Y-m-d', strtotime( '-1 month' ) );
$end_date        = wp_date( 'Y-m-d', strtotime( 'now' ) );
?>
<div class="wpanalytify analytify-dashboard-nav">
	<div class="wpb_plugin_wraper">
		<div class="wpb_plugin_header_wraper">
			<div class="graph"></div>
			<div class="wpb_plugin_header">
				<div class="wpb_plugin_header_title"></div>
				<div class="wpb_plugin_header_info">
					<a href="https://analytify.io/changelog/" target="_blank" class="btn">
					<?php
					// Translators: %s: Analytify core version.
					echo esc_html__( 'View Changelog', 'wp-analytify-pro' );
					?>
					</a>
				</div>
				<div class="wpb_plugin_header_logo">
					<img src="<?php echo defined( 'ANALYTIFY_PLUGIN_URL' ) ? esc_url( ANALYTIFY_PLUGIN_URL . 'assets/img/logo.svg' ) : ''; ?>" alt="Analytify">
				</div>
			</div>
		</div>

		<div class="analytify-dashboard-body-container">
			<div class="wpb_plugin_body_wraper">
				<div class="wpb_plugin_body">
					<div class="wpa-tab-wrapper">
						<?php
						if ( $is_author_only ) {
							$authors_nav_url = admin_url( 'admin.php?page=analytify-authors' );
							?>
						<div class="analytify_nav_tab_wrapper nav-tab-wrapper">
							<ul class="analytify_nav_tab_wrapper">
								<li class="analytify_nav_tab_parent">
									<a href="<?php echo esc_url( $authors_nav_url ); ?>" class="analytify_nav_tab nav-tab-active">
										<?php esc_html_e( 'Authors Tracking', 'wp-analytify-pro' ); ?>
										<span><?php esc_html_e( 'Your stats', 'wp-analytify-pro' ); ?></span>
									</a>
								</li>
							</ul>
						</div>
							<?php
						} elseif ( is_object( $wp_analytify ) && method_exists( $wp_analytify, 'dashboard_navigation' ) ) {
							$wp_analytify->dashboard_navigation();
						}
						?>
					</div>

					<div class="wpb_plugin_tabs_content analytify-dashboard-content">
						<div class="analytify_wraper">
							<div class="analytify_main_title_section">
								<div class="analytify_dashboard_title">
									<h1 class="analytify_pull_left analytify_main_title"><?php esc_html_e( 'Authors Dashboard', 'wp-analytify-pro' ); ?></h1>
									<?php
									// Show subtitle section for authors or users with proper access.
									$can_show_subtitle = false;
									if ( $is_author_only && $access_token ) {
										// Authors can see subtitle if authenticated.
										$can_show_subtitle = true;
									} elseif ( class_exists( 'WP_ANALYTIFY_FUNCTIONS' ) && method_exists( 'WP_ANALYTIFY_FUNCTIONS', 'wpa_check_profile_selection' ) &&
										! WP_ANALYTIFY_FUNCTIONS::wpa_check_profile_selection( 'Analytify' ) &&
										is_object( $wp_analytify ) && method_exists( $wp_analytify, 'pa_check_roles' ) &&
										$wp_analytify->pa_check_roles( $is_access_level ) &&
										$access_token ) {
										$can_show_subtitle = true;
									}

									if ( $can_show_subtitle && class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'dashboard_subtitle_section' ) ) {
										WPANALYTIFY_Utils::dashboard_subtitle_section();
									}
									?>
								</div>
								<div class="analytify_main_setting_bar">
									<div class="analytify_pull_right analytify_setting">
										<div class="analytify_select_date">
											<?php if ( ! $is_author_only ) : ?>
											<div class="analytify_authors_roles_wrapper">
												<label for="analytify-author-dashboard-select"><?php esc_html_e( 'Choose Author To View Stats:', 'wp-analytify-pro' ); ?></label>
												<select class="analytify_select_date_fields" id="analytify-author-dashboard-select" name="author_id">
													<option value="0"><?php esc_html_e( '- All Authors -', 'wp-analytify-pro' ); ?></option>
													<?php
													foreach ( $authors_ordered as $role_slug ) {
														$authors_cap = isset( $authors_role_user_limits[ $role_slug ] )
															? (int) $authors_role_user_limits[ $role_slug ]
															: (int) ( $authors_role_user_limits['default'] ?? 5 );
														$authors_cap = min( 500, max( 1, $authors_cap ) );
														$role_users  = get_users(
															array(
																'role'                => $role_slug,
																'orderby'             => 'display_name',
																'order'               => 'ASC',
																'number'              => $authors_cap,
																'has_published_posts' => $authors_published_post_types,
															)
														);
														if ( empty( $role_users ) ) {
															continue;
														}
														$role_label = isset( $authors_editable_roles[ $role_slug ]['name'] )
															? translate_user_role( $authors_editable_roles[ $role_slug ]['name'] )
															: $role_slug;
														echo '<optgroup label="' . esc_attr( $role_label ) . '">';
														foreach ( $role_users as $u ) {
															if ( ! is_object( $u ) || ! isset( $u->ID ) ) {
																continue;
															}
															echo '<option value="' . esc_attr( (string) $u->ID ) . '"';
															if ( (int) $u->ID === (int) $current_user_id ) {
																echo ' selected="selected"';
															}
															echo '>' . esc_html( $u->display_name ) . '</option>';
														}
														echo '</optgroup>';
													}
													?>
												</select>
											</div>
											<?php else : ?>
											<!-- Authors can only see their own stats - selection hidden -->
											<input type="hidden" id="analytify-author-dashboard-select" name="author_id" value="<?php echo esc_attr( $current_user_id ); ?>">
											<?php endif; ?>
											<?php
											// Show date form for authors or users with proper access.
											$can_show_date_form = false;
											if ( $is_author_only && $access_token ) {
												// Authors can see date form if authenticated.
												$can_show_date_form = true;
											} elseif ( class_exists( 'WP_ANALYTIFY_FUNCTIONS' ) && method_exists( 'WP_ANALYTIFY_FUNCTIONS', 'wpa_check_profile_selection' ) &&
												! WP_ANALYTIFY_FUNCTIONS::wpa_check_profile_selection( 'Analytify' ) &&
												is_object( $wp_analytify ) && method_exists( $wp_analytify, 'pa_check_roles' ) &&
												$wp_analytify->pa_check_roles( $is_access_level ) &&
												$access_token ) {
												$can_show_date_form = true;
											}

											if ( $can_show_date_form && class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'date_form' ) ) {
												WPANALYTIFY_Utils::date_form( $start_date, $end_date );
											}
											?>
										</div>
									</div>
								</div>
							</div>

							<div class="analytify_author_dashboard analytify_status_box_wraper" data-endpoint-authors="main-dashboard">
								<div class="analytify_status_header analytify_header_adj">
									<h3>
										<?php
										esc_html_e( 'Author Stats', 'wp-analytify-pro' );
										if ( defined( 'ANALYTIFY_PRO_VERSION' ) && version_compare( ANALYTIFY_PRO_VERSION, '6.1.0', '>=' ) ) {
											?>
									<a href="#" class="analytify-export-data analytify_tooltip" data-stats-type="authors-dashboard" data-args="<?php echo esc_attr( $current_user_id ); ?>">
										<span class="analytify_tooltiptext"><?php esc_html_e( 'Export Stats', 'wp-analytify-pro' ); ?></span>
									</a>
									<img src="<?php echo esc_url( admin_url( 'images/spinner.gif' ) ); ?>" class='analytify-export-loader' style="display:none">
										<?php } ?>
									</h3>
								</div>
								<div class="analytify_status_body">
									<div class="stats-wrapper"></div>
								</div>
								<div class="analytify_stats_loading">
									<table class="analytify_data_tables">
										<thead>
											<tr>
											<th class="analytify_num_row"><p class="skt-loading light-gray"></p></th>
											<th class="analytify_txt_left"><p class="skt-loading light-gray"></p></th>
											<th class="analytify_value_row"><p class="skt-loading light-gray"></p></th>
											<th class="analytify_value_row"><p class="skt-loading light-gray"></p></th>
											<th class="analytify_value_row"><p class="skt-loading light-gray"></p></th>
											<th class="analytify_value_row"><p class="skt-loading light-gray"></p></th>
											<th class="analytify_value_row"><p class="skt-loading light-gray"></p></th>
											</tr>
										</thead>
										<tbody>
											<?php for ( $i = 0; $i < 7; $i++ ) { ?>
											<tr>
												<td class="analytify_txt_center"><p class="skt-loading"></p></td>
												<td><p class="skt-loading"></p></td>
												<td class="analytify_txt_center"><p class="skt-loading"></p></td>
												<td class="analytify_txt_center"><p class="skt-loading"></p></td>
												<td class="analytify_txt_center"><p class="skt-loading"></p></td>
												<td class="analytify_txt_center"><p class="skt-loading"></p></td>
												<td class="analytify_txt_center"><p class="skt-loading"></p></td>
											</tr>
											<?php } ?>
										</tbody>
									</table>
								</div>
							</div>

						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
