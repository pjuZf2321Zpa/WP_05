<?php
/**
 * Author Tracking Main Class.
 *
 * @package WP_Analytify_Pro
 */

// phpcs:ignoreFile WordPress.Files.FileName.InvalidClassFileName

/**
 * Class Analytify_Addon_Authors
 *
 * Main class for Author tracking addon.
 */
class Analytify_Addon_Authors extends WP_Analytify_Pro_Base {

	/**
	 * The unique identifier of this plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var string
	 */
	protected $plugin_name = 'wp-analytify-pro';

	/**
	 * The current version of the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var string
	 */
	protected $version;

	/**
	 * Define the core functionality of the plugin.
	 *
	 * Set the plugin name and the plugin version that can be used throughout the plugin.
	 * Load the dependencies, define the locale, and set the hooks for the admin area and
	 * the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function __construct() {

		parent::__construct();

		$this->version = defined( 'ANALYTIFY_AUTHORS_VERSION' ) ? (string) ANALYTIFY_AUTHORS_VERSION : analytify_pro_get_asset_version();

		$this->setup_constants();
		$this->set_locale();
		$this->hooks();
	}

	/**
	 * Register all of the hooks related to the admin area functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @return void
	 */
	private function hooks() {

		add_action( 'admin_enqueue_scripts', array( $this, 'authors_admin_scripts' ), 10, 1 );
		add_action( 'analytify_add_submenu', array( $this, 'add_menu' ), 45 );
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_scripts' ) );
		add_filter( 'plugin_row_meta', array( $this, 'plugin_row_meta' ), 10, 2 );
		add_action( 'analytify_dashboad_dropdown_option', array( $this, 'dashboad_dropdown_option' ) );
		// Late priority: run after Analytify core and addons register submenus.
		add_action( 'admin_menu', array( $this, 'remove_other_submenus_for_authors' ), 99999 );
		add_filter( 'analytify_filter_navigation_items', array( $this, 'filter_navigation_items_for_dashboard_only_users' ), 99999 );
	}

	/**
	 * Replace full horizontal dashboard tabs with Authors only (any screen using dashboard_navigation()).
	 *
	 * @param array<int, array<string, mixed>> $nav_items Default nav items.
	 * @return array<int, array<string, mixed>>
	 */
	public function filter_navigation_items_for_dashboard_only_users( $nav_items ) {
		if ( ! function_exists( 'analytify_authors_is_dashboard_only_user' ) || ! analytify_authors_is_dashboard_only_user() || ! is_array( $nav_items ) ) {
			return $nav_items;
		}

		return array(
			array(
				'name'        => __( 'Authors Tracking', 'wp-analytify-pro' ),
				'sub_name'    => __( 'Your stats', 'wp-analytify-pro' ),
				'page_slug'   => 'analytify-authors',
				'addon_slug'  => 'wp-analytify-authors',
				'module_type' => 'pro_addon',
			),
		);
	}

	/**
	 * Define constant if not already set
	 *
	 * @param  string      $name
	 * @param  string|bool $value
	 * @return void
	 */
	private function define( $name, $value ) {
		if ( ! defined( $name ) ) {
			define( $name, $value );
		}
	}

	/**
	 * Setup plugin constants
	 *
	 * @access      private
	 * @since       1.0.0
	 * @return      void
	 */
	private function setup_constants() {

		$this->define( 'AUTHORS_ANALYTIFY_PLUGIN_FILE', __FILE__ );
		$this->define( 'AUTHORS_ANALYTIFY_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );
		$this->define( 'AUTHORS_ANALYTIFY_ADDON_BASENAME', plugin_basename( dirname( __DIR__ ) . '/wp-analytify-authors.php' ) );
		$this->define( 'AUTHORS_ANALYTIFY_PLUGIN_DIR', __DIR__ );
		$this->define( 'AUTHORS_ANALYTIFY_PRODUCT_NAME', 'Analytify - Authors Tracking Addon' );
		$this->define( 'AUTHORS_ANALYTIFY_PRODUCT_ID', '229554' );
		$this->define( 'AUTHORS_ANALYTIFY_STORE_URL', 'https://analytify.io' );
	}

	/**
	 * Define the locale for this plugin for internationalization.
	 *
	 * Uses the Plugin_Name_i18n class in order to set the domain and to register the hook
	 * with WordPress.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @return void
	 */
	private function set_locale() {
		// Text domain loaded by main Pro plugin.
		// All translations now use 'wp-analytify-pro' text domain.
	}

	/**
	 * Pro plugin version for asset query strings (cache busting).
	 *
	 * @return string
	 */
	private function get_pro_asset_version(): string {
		return analytify_pro_get_asset_version();
	}

	/**
	 * Authors addon version for asset query strings (cache busting).
	 *
	 * @return string
	 */
	private function get_authors_addon_asset_version(): string {
		return defined( 'ANALYTIFY_PRO_AUTHORS_DASHBOARD_VERSION' ) ? (string) ANALYTIFY_PRO_AUTHORS_DASHBOARD_VERSION : analytify_pro_get_asset_version();
	}

	/**
	 * Load Admin Scripts
	 *
	 * @since 1.0
	 * @param string $page Current admin page.
	 * @return void
	 */
	public function admin_scripts( $page ) {
		if ( 'analytify_page_analytify-settings' === $page ) {
			// Script loading will be added here when needed.
		}
	}

	/**
	 * Plugin row meta links.
	 *
	 * @param array<int|string, string> $input Already defined meta links.
	 * @param string                    $file Plugin file path and name being processed.
	 * @return array<int|string, string>
	 */
	public function plugin_row_meta( $input, $file ) {

		if ( ! defined( 'AUTHORS_ANALYTIFY_ADDON_BASENAME' ) || AUTHORS_ANALYTIFY_ADDON_BASENAME !== $file ) {
			return $input;
		}

		// Remove the 'view details' org link.
		if ( isset( $input[2] ) ) {
			unset( $input[2] );
		}

		$input[] = '<a href="' . esc_url( 'https://analytify.io/add-ons/authors-tracking/' ) . '" target="_blank" rel="noopener noreferrer">' . esc_html__( 'Visit plugin site', 'wp-analytify-pro' ) . '</a>';

		return $input;
	}
	/**
	 * Enqueue admin scripts.
	 *
	 * @since     1.0.0
	 * @param string $location Current admin page location.
	 * @return    void
	 */
	public function authors_admin_scripts( $location ) {

		if ( 'analytify_page_analytify-authors' !== $location ) {
			return;
		}

		$pro_version     = $this->get_pro_asset_version();
		$authors_version = $this->get_authors_addon_asset_version();
		$suffix          = analytify_pro_get_asset_suffix();
		wp_enqueue_style( 'analytify_author_css', plugins_url( "/assets/css/main{$suffix}.css", __DIR__ ), array(), $pro_version );
		wp_enqueue_style( 'analytify-dashboard-authors', plugins_url( "assets/css/common-dashboard{$suffix}.css", __DIR__ ), array(), $authors_version );

		wp_enqueue_script( 'analytify-stats-authors', plugins_url( "assets/js/stats-authors{$suffix}.js", __DIR__ ), array( 'jquery' ), $authors_version, true );
		wp_localize_script(
			'analytify-stats-authors',
			'analytify_stats_authors',
			array(
				'url'              => esc_url_raw( rest_url( ANALYTIFY_AUTHOR_REPORT_REST_URL_PATH ) ),
				'nonce'            => wp_create_nonce( 'wp_rest' ),
				'delimiter'        => ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_delimiter' ) ) ? WPANALYTIFY_Utils::get_delimiter() : '?',
				'load_via_ajax'    => true,
				'no_stats_message' => __( 'No activity during this period.', 'wp-analytify-pro' ),
				'error_message'    => __( 'Something went wrong. Please try again.', 'wp-analytify-pro' ),
			),
		);
	}

	/**
	 * Add dropdown option for admin dashboard.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function dashboad_dropdown_option() {

		echo '<li><a href="' . esc_url( admin_url( 'admin.php?page=analytify-authors' ) ) . '">' . esc_html__( 'Authors', 'wp-analytify-pro' ) . '</a></li>';
	}

	/**
	 * The name of the plugin used to uniquely identify it within the context of
	 * WordPress and to define internationalization functionality.
	 *
	 * @since     1.0.0
	 * @return    string    The name of the plugin.
	 */
	public function get_plugin_name() {

		return $this->plugin_name;
	}

	/**
	 * Retrieve the version number of the plugin.
	 *
	 * @since     1.0.0
	 * @return    string    The version number of the plugin.
	 */
	public function get_version() {

		return $this->version;
	}

	/**
	 * Add menu for Author Tracking Dashboard page
	 *
	 * @return void
	 */
	public function add_menu() {

		// Check if authors are in the allowed roles list.
		$wp_analytify   = $GLOBALS['WP_ANALYTIFY'] ?? null;
		$allowed_roles  = $wp_analytify && is_object( $wp_analytify ) && isset( $wp_analytify->settings ) ? $wp_analytify->settings->get_option( 'show_analytics_roles_dashboard', 'wp-analytify-dashboard', array() ) : array();
		$current_user   = wp_get_current_user();
		$is_author_only = $current_user && in_array( 'author', (array) $current_user->roles, true ) && ! in_array( 'administrator', (array) $current_user->roles, true );
		
		// If current user is an author and authors are in allowed roles, use edit_posts capability.
		// Otherwise, use manage_options (for admins and other roles).
		$menu_capability = ( $is_author_only && in_array( 'author', (array) $allowed_roles, true ) ) ? 'edit_posts' : 'manage_options';

		// phpcs:ignore Squiz.PHP.CommentedOutCode.Found -- Function signature reference.
		// add_submenu_page( $parent_slug, $page_title, $menu_title, $capability, $menu_slug, $function = '' ).
		add_submenu_page( 'analytify-dashboard', __( 'Authors Tracking', 'wp-analytify-pro' ), __( 'Authors Tracking', 'wp-analytify-pro' ), $menu_capability, 'analytify-authors', array( __CLASS__, 'authors_dashboard_page' ), 35 );
	}

	/**
	 * Remove other Analytify submenu items for authors (they should only see Authors Tracking).
	 *
	 * @since 7.2.0
	 * @return void
	 */
	public function remove_other_submenus_for_authors() {
		if ( ! function_exists( 'analytify_authors_is_dashboard_only_user' ) || ! analytify_authors_is_dashboard_only_user() ) {
			return;
		}

		$submenus_to_remove = array(
			'analytify-dashboard',
			'analytify-settings',
			'analytify-woocommerce',
			'analytify-campaigns',
			'analytify-forms',
			'analytify-events',
			'analytify-goals',
			'analytify-dimensions',
			'edd-dashboard',
		);

		foreach ( $submenus_to_remove as $submenu ) {
			remove_submenu_page( 'analytify-dashboard', $submenu );
		}

		global $submenu;
		if ( isset( $submenu['analytify-dashboard'] ) && is_array( $submenu['analytify-dashboard'] ) ) {
			$submenu['analytify-dashboard'] = array_values(
				array_filter(
					$submenu['analytify-dashboard'],
					static function ( $item ) {
						return isset( $item[2] ) && 'analytify-authors' === $item[2];
					}
				)
			);
		}
	}

	/**
	 * Authors dashboard page.
	 *
	 * @return void
	 */
	public static function authors_dashboard_page() {

		$screen = get_current_screen();

		if ( $screen && strpos( $screen->base, 'analytify-authors' ) !== false ) {

			$wp_analytify   = $GLOBALS['WP_ANALYTIFY'];
			$selected_stats = $wp_analytify->settings->get_option( 'show_analytics_panels_dashboard', 'wp-analytify-dashboard', array() );

			$dashboard_profile_id = ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_reporting_property' ) ) ? WPANALYTIFY_Utils::get_reporting_property() : '';
			$access_token         = get_option( 'post_analytics_token' );
			$version              = defined( 'ANALYTIFY_PRO_VERSION' ) ? ANALYTIFY_PRO_VERSION : ANALYTIFY_VERSION;

			// Get the start date and end date from wpa-core-functions
			$start_date = '';
			$end_date   = '';
			if ( function_exists( 'analytify_datepicker_dates' ) ) {
				$dates = analytify_datepicker_dates();
				if ( is_array( $dates ) ) {
					$start_date = $dates['start_date'] ?? wp_date( 'Y-m-d', strtotime( '-1 month' ) );
					$end_date   = $dates['end_date'] ?? wp_date( 'Y-m-d', strtotime( 'now' ) );
				} else {
					$start_date = wp_date( 'Y-m-d', strtotime( '-1 month' ) );
					$end_date   = wp_date( 'Y-m-d', strtotime( 'now' ) );
				}
			} else {
				$start_date = wp_date( 'Y-m-d', strtotime( '-1 month' ) );
				$end_date   = wp_date( 'Y-m-d', strtotime( 'now' ) );
			}

			// Get compare dates for legacy version (before v5.0.0).
			$date_diff          = ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'calculate_date_diff' ) ) ? WPANALYTIFY_Utils::calculate_date_diff( $start_date, $end_date ) : array(
				'start_date' => '',
				'end_date'   => '',
			);
			$compare_start_date = $date_diff['start_date'];
			$compare_end_date   = $date_diff['end_date'];

			/*
			 * Check with roles assigned at dashboard settings.
			 */
			$current_user   = wp_get_current_user();
			$is_author_only = $current_user && in_array( 'author', (array) $current_user->roles, true ) && ! in_array( 'administrator', (array) $current_user->roles, true );

			$is_access_level = $wp_analytify->settings->get_option( 'show_analytics_roles_dashboard', 'wp-analytify-dashboard' );

			// Show dashboard to admin incase of empty access roles.
			if ( empty( $is_access_level ) ) {
				$is_access_level = array( 'administrator' );
			}

			if ( $is_author_only ) {
				if ( ! current_user_can( 'edit_posts' ) ) {
					esc_html_e( 'You don\'t have access to Analytify Dashboard.', 'wp-analytify-pro' );
					return;
				}
			} elseif ( ! $wp_analytify->pa_check_roles( $is_access_level ) ) {
				esc_html_e( 'You don\'t have access to Analytify Dashboard.', 'wp-analytify-pro' );
				return;
			}

			if ( $access_token ) {

					// Dequeue event calendar js.
					wp_dequeue_script( 'tribe-common' );

					if ( defined( 'ANALYTIFY_PRO_AUTHORS_ROOT_PATH' ) ) {
						require_once ANALYTIFY_PRO_AUTHORS_ROOT_PATH . '/views/author-dashboard.php';
					}
				} else {
					esc_html_e( 'You must be authenticated to see the Analytics Dashboard.', 'wp-analytify-pro' );
				}
		}
	}
}