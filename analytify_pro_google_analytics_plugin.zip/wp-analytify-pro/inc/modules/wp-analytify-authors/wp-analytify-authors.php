<?php
/**
 * Authors Loader Class.
 *
 * @package WP_Analytify_Pro
 */

// phpcs:ignoreFile WordPress.Files.FileName.InvalidClassFileName

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	die;
}

/**
 * Whether the current user should only see the Authors Tracking experience (no other Analytify dashboard tabs/pages).
 *
 * True for the Author role (non-admin) or for “author-like” capabilities: edit_posts without editing others’ posts.
 *
 * @return bool
 */
function analytify_authors_is_dashboard_only_user() {
	if ( ! is_user_logged_in() || current_user_can( 'manage_options' ) ) {
		return false;
	}

	$user        = wp_get_current_user();
	$author_role = $user && $user->ID
		&& in_array( 'author', (array) $user->roles, true )
		&& ! in_array( 'administrator', (array) $user->roles, true );

	$author_like_caps = current_user_can( 'edit_posts' )
		&& ! current_user_can( 'edit_others_posts' )
		&& ! current_user_can( 'manage_woocommerce' );

	$default = $author_role || $author_like_caps;

	/**
	 * Filter whether the current user is restricted to the Authors dashboard UI.
	 *
	 * @param bool $restricted Default based on role/caps.
	 * @param int  $user_id    Current user ID.
	 */
	return (bool) apply_filters( 'analytify_authors_is_dashboard_only_user', $default, (int) $user->ID );
}

/**
 * Class Analytify_Authors_Loader
 *
 * Loads the Authors addon.
 */
class Analytify_Authors_Loader {

	/**
	 * Singleton instance.
	 *
	 * @var self|null
	 */
	public static $instance;

	/**
	 * Version.
	 *
	 * @var string
	 */
	public $version;

	/**
	 * Get singleton instance.
	 *
	 * @return self
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->define_constants();
		$this->version = defined( 'ANALYTIFY_AUTHORS_VERSION' ) ? ANALYTIFY_AUTHORS_VERSION : analytify_pro_get_asset_version();
		$this->hooks();
		$this->may_be_load_addon();
	}

	/**
	 * Load addon if requirements are met.
	 *
	 * @return void
	 */
	public function may_be_load_addon() {
		if (
			file_exists( WP_PLUGIN_DIR . '/wp-analytify-pro/wp-analytify-pro.php' ) &&
			function_exists( 'wp_analytify_pro_load' ) &&
			class_exists( 'WP_Analytify_Pro_Base' )
		) {
			// The core plugin class.
			require plugin_dir_path( __FILE__ ) . 'classes/analytify-author-tracking.php';
			require plugin_dir_path( __FILE__ ) . 'classes/class-analytify-author-rest-api.php';

			new Analytify_Addon_Authors();
		} else {
			add_action( 'admin_enqueue_scripts', array( $this, 'wpa_authors_dashboard_notices_scripts' ) );
		}
	}

	/**
	 * Define addon constants.
	 *
	 * @return void
	 */
	public function define_constants() {
		if ( ! defined( 'ANALYTIFY_AUTHORS_VERSION' ) ) {
			define( 'ANALYTIFY_AUTHORS_VERSION', analytify_pro_get_asset_version() );
		}
		if ( ! defined( 'ANALYTIFY_PRO_AUTHORS_DASHBOARD_VERSION' ) ) {
			define( 'ANALYTIFY_PRO_AUTHORS_DASHBOARD_VERSION', analytify_pro_get_asset_version() );
		}
		if ( ! defined( 'ANALYTIFY_AUTHOR_REPORT_REST_URL_PATH' ) ) {
			define( 'ANALYTIFY_AUTHOR_REPORT_REST_URL_PATH', 'wp-analytify/v1/get_author_report/' );
		}

		// The URL of the plugin directory.
		define( 'ANALYTIFY_PRO_AUTHORS_ROOT_PATH', __DIR__ );

		// The minimum version of Analytify.
		define( 'ANALYTIFY_PRO_AUTHORS_DASHBOARD_MIN_V_ANALYTIFY', '4.0.0' );

		// The minimum version of Analytify Pro.
		define( 'ANALYTIFY_PRO_AUTHORS_DASHBOARD_MIN_V_ANALYTIFY_PRO', '4.0.0' );
	}

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function hooks() {
		add_action( 'admin_notices', array( $this, 'wpa_authors_dashboard_install_analytify_pro' ) );
		add_action( 'admin_notices', array( $this, 'wpa_authors_dashboard_active_analytify_pro' ) );
		add_action( 'admin_notices', array( $this, 'wpa_authors_dashboard_notice_version_analytify' ) );
		add_action( 'admin_notices', array( $this, 'wpa_authors_dashboard_notice_version_analytify_pro' ) );
		add_action( 'init', array( $this, 'analytify_authors_load_textdomain' ) );
	}

	/**
	 * Check If Analytify Pro is installed.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function wpa_authors_dashboard_install_analytify_pro() {
		if ( ! file_exists( WP_PLUGIN_DIR . '/wp-analytify-pro/wp-analytify-pro.php' ) ) {
			$message = '<strong>' . esc_html__( 'Attention:', 'wp-analytify-pro' ) . '</strong> ' . esc_html__( 'Please Install Analytify Pro to use Analytify Authors Dashboard addon.', 'wp-analytify-pro' );
			$this->wpa_authors_dashboard_notice_markup( $message, 'wp-analytify-danger' );
		}
	}

	/**
	 * Admin notices for the Analytify version.
	 *
	 * @return void
	 */
	public function wpa_authors_dashboard_notice_version_analytify() {
		// Load the main plugin file.
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$plugins = get_plugins();
		// Check for the main plugin version.
		if ( ! isset( $plugins['wp-analytify/wp-analytify.php'] ) || version_compare( $plugins['wp-analytify/wp-analytify.php']['Version'], defined( 'ANALYTIFY_PRO_AUTHORS_DASHBOARD_MIN_V_ANALYTIFY' ) ? ANALYTIFY_PRO_AUTHORS_DASHBOARD_MIN_V_ANALYTIFY : '4.0.0', '<' ) ) {
			// translators: %s: analytify min supported version.
			$message = '<strong>' . esc_html__( 'Attention:', 'wp-analytify-pro' ) . '</strong> ' . sprintf( esc_html__( 'The minimum version of Analytify required for Analytify Authors Dashboard addon is %s. You need to update Analytify Core (Free).', 'wp-analytify-pro' ), defined( 'ANALYTIFY_PRO_AUTHORS_DASHBOARD_MIN_V_ANALYTIFY' ) ? ANALYTIFY_PRO_AUTHORS_DASHBOARD_MIN_V_ANALYTIFY : '4.0.0' );
			$this->wpa_authors_dashboard_notice_markup( $message, 'wp-analytify-danger' );
		}
	}

	/**
	 * Admin notices for the Analytify Pro version.
	 *
	 * @return void
	 */
	public function wpa_authors_dashboard_notice_version_analytify_pro() {
		// Load the main plugin file.
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$plugins = get_plugins();
		// Check for the pro version.
		if ( ! isset( $plugins['wp-analytify-pro/wp-analytify-pro.php'] ) || version_compare( $plugins['wp-analytify-pro/wp-analytify-pro.php']['Version'], defined( 'ANALYTIFY_PRO_AUTHORS_DASHBOARD_MIN_V_ANALYTIFY_PRO' ) ? ANALYTIFY_PRO_AUTHORS_DASHBOARD_MIN_V_ANALYTIFY_PRO : '4.0.0', '<' ) ) {
			// translators: %s: analytify min supported version.
			$message = '<strong>' . esc_html__( 'Attention:', 'wp-analytify-pro' ) . '</strong> ' . sprintf( esc_html__( 'The minimum version of Analytify Pro required for Analytify Authors Dashboard addon is %s. You need to update Analytify Pro.', 'wp-analytify-pro' ), defined( 'ANALYTIFY_PRO_AUTHORS_DASHBOARD_MIN_V_ANALYTIFY' ) ? ANALYTIFY_PRO_AUTHORS_DASHBOARD_MIN_V_ANALYTIFY : '4.0.0' );
			$this->wpa_authors_dashboard_notice_markup( $message, 'wp-analytify-danger' );
		}
	}

	/**
	 * Check if Analytify Pro is activated.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function wpa_authors_dashboard_active_analytify_pro() {
		if ( ! class_exists( 'WP_Analytify_Pro_Base' ) ) {
			$message = '<strong>' . esc_html__( 'Attention: ', 'wp-analytify-pro' ) . '</strong> ' . esc_html__( 'Please activate Analytify Pro to use Analytify Authors Dashboard addon.', 'wp-analytify-pro' );
			$this->wpa_authors_dashboard_notice_markup( $message, 'wp-analytify-danger' );
		}
	}

	/**
	 * Dashboard notices markup.
	 *
	 * @param string $message Message to display.
	 * @param string $class   Class to add to the notice.
	 *
	 * @return void
	 */
	// phpcs:ignore Universal.NamingConventions.NoReservedKeywordParameterNames.classFound
	public function wpa_authors_dashboard_notice_markup( $message, $class = 'wp-analytify-success' ) {
		$notice_id = 'analytify_notice_' . md5( $message );
		if ( ! get_option( $notice_id ) ) {
			echo '<div class="wp-analytify-notification ' . esc_attr( $class ) . '" id="' . esc_attr( $notice_id ) . '">
					<a class="wp-analytify-notice-dismiss" href="#" aria-label="Dismiss the notice" onclick="dismissAnalytifyNotice(\'' . esc_js( $notice_id ) . '\'); return false;">&times;</a>
					<div class="wp-analytify-notice-logo">
						<img src="' . esc_url( plugins_url( 'assets/img/logo.svg', __FILE__ ) ) . '" alt="notice">
					</div>
					<div class="wp-analytify-notice-discription">
						<p>' . wp_kses_post( $message ) . '</p>
					</div>
				</div>';
		}
	}

	/**
	 * @return void
	 */
	public function wp_analytify_authors_notice_script() {
		?>
		<script type="text/javascript">
			function dismissAnalytifyNotice(noticeId) {
				document.getElementById(noticeId).style.display = 'none';
				localStorage.setItem('analytify_stats_refreshed_dismissed', '1');
				var ajaxurl = '<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>';
				var data = {
					'action': 'dismiss_analytify_notice',
					'notice_id': noticeId
				};
				jQuery.post(ajaxurl, data, function(response) {
					// console.log(response);
				});
			}
		</script>
		<?php
	}

	/**
	 * Handle notice dismissal via AJAX.
	 *
	 * @return void
	 */
	public function dismiss_authors_campaigns_notice() {
		// phpcs:disable WordPress.Security.NonceVerification.Missing
		if ( isset( $_POST['notice_id'] ) ) {
			update_option( sanitize_text_field( wp_unslash( $_POST['notice_id'] ) ), true );
			wp_send_json_success();
		} else {
			wp_send_json_error();
		}
		// phpcs:enable WordPress.Security.NonceVerification.Missing
	}

	/**
	 * Enqueue admin notices scripts.
	 *
	 * @return void
	 */
	public function wpa_authors_dashboard_notices_scripts() {
		$version = defined( 'ANALYTIFY_PRO_AUTHORS_DASHBOARD_VERSION' ) ? ANALYTIFY_PRO_AUTHORS_DASHBOARD_VERSION : analytify_pro_get_asset_version();
		wp_enqueue_style( 'analytify_authors_dashboard_notices', plugins_url( 'assets/css/notices' . analytify_pro_get_asset_suffix() . '.css', __FILE__ ), array(), $version );
	}

	/**
	 * Load TextDoamin
	 *
	 * @since 1.0
	 */
	/**
	 * Load text domain.
	 *
	 * @return void
	 */
	public function analytify_authors_load_textdomain() {
		// Text domain loaded by main Pro plugin.
		// All translations now use 'wp-analytify-pro' text domain.
	}
}

Analytify_Authors_Loader::get_instance();
