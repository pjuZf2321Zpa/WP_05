<?php
/**
 * AMP Sanitizer Class.
 *
 * @package WP_Analytify_Pro
 */

// phpcs:ignoreFile WordPress.Files.FileName.InvalidClassFileName

// If file directly access or AMP is not activated.
if ( ! defined( 'ABSPATH' ) || ! defined( 'AMP__FILE__' ) ) {
	die;
}

if ( defined( 'AMP__DIR__' ) ) {
	require_once AMP__DIR__ . '/includes/sanitizers/class-amp-base-sanitizer.php';
}

if ( class_exists( 'AMP_Base_Sanitizer' ) ) {
	/**
	 * Class Analytify_AMP_Sanitizer
	 *
	 * Sanitizes AMP content for Analytify tracking.
	 */
	class Analytify_AMP_Sanitizer extends AMP_Base_Sanitizer {

		/**
		 * Options for the sanitizer.
		 *
		 * @var array<string, mixed>
		 */
		private $options = array();

		/**
		 * Sanitize the HTML contained in the DOMDocument received by the constructor
		 *
		 * @since 1.0.0
		 *
		 * @return void
		 */
		public function sanitize() {
			$this->options = array(
				'outbound_link'       => $this->get_outbound_links(),
				'download_extensions' => $GLOBALS['WP_ANALYTIFY']->settings->get_option( 'file-extension', 'wp-analytify-file-download', 'zip|mp3*|mpe*g|pdf|docx*|pptx*|xlsx*|rar*' ),
			);

			$body = isset( $this->dom ) && $this->dom ? $this->dom->body : null;
			if ( $body ) {
				$this->parse_nodes_recursive( $body );
			}
		}

		/**
		 * Passes through the DOM and removes stuff that shouldn't be there.
		 *
		 * @param DOMNode $node DOM node.
		 *
		 * @since 1.0.0
		 *
		 * @return void
		 */
		private function parse_nodes_recursive( $node ) {
			// phpcs:disable WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
			if ( XML_ELEMENT_NODE !== $node->nodeType ) {
				return;
			}
			if ( 'a' === $node->nodeName ) {
				$node_name = $node->nodeName;
				$this->parse_href( $node );
			}
			foreach ( $node->childNodes as $child_node ) {
				$this->parse_nodes_recursive( $child_node );
			}
			// phpcs:enable WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
		}

		/**
		 * Sanitizes anchor attributes
		 *
		 * @param DOMNode $node DOM node.
		 *
		 * @since 1.0.0
		 *
		 * @return void
		 */
		private function parse_href( $node ) {
			$href     = method_exists( $node, 'getAttribute' ) ? $node->getAttribute( 'href' ) : '';
			$hrefe    = esc_attr( $href );
			$label    = $this->get_label( $node );
			$category = ! empty( method_exists( $node, 'getAttribute' ) ? $node->getAttribute( 'data-vars-ga-category' ) : '' ) ? esc_attr( method_exists( $node, 'getAttribute' ) ? $node->getAttribute( 'data-vars-ga-category' ) : '' ) : '';
			$action   = ! empty( method_exists( $node, 'getAttribute' ) ? $node->getAttribute( 'data-vars-ga-action' ) : '' ) ? esc_attr( method_exists( $node, 'getAttribute' ) ? $node->getAttribute( 'data-vars-ga-action' ) : '' ) : $hrefe;

			// If has Javascript in link.
			if ( substr( $href, 0, strlen( 'javascript:' ) ) === 'javascript:' ) {
				return;
			}

			$title = esc_attr( method_exists( $node, 'getAttribute' ) ? $node->getAttribute( 'title' ) : '' );
			$class = esc_attr( method_exists( $node, 'getAttribute' ) ? $node->getAttribute( 'class' ) : '' );
			if ( ! empty( $class ) ) {
				$class = $class . ' ';
			}

			if ( empty( $title ) ) {
				// phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
				$node_value = property_exists( $node, 'nodeValue' ) ? $node->nodeValue : '';
				$title      = esc_attr( $node_value ? $node_value : '' );
			}

			if ( ! empty( $category ) ) {
				$this->safe_set_attribute( $node, 'class', $class . 'analytify-link' );
				$this->safe_set_attribute( $node, 'data-vars-category', $category ); // type of link
				$action = $action ? $action : 'click';
				$this->safe_set_attribute( $node, 'data-vars-action', $action );  // href
				$label = $label ? $label : $title;
				$this->safe_set_attribute( $node, 'data-vars-label', $label ); // Link text
				return;
			}

			// for telephone.
			if ( substr( $href, 0, strlen( 'tel:' ) ) === 'tel:' ) {
				$this->safe_set_attribute( $node, 'class', $class . 'analytify-amp-tel' );
				$this->safe_set_attribute( $node, 'data-vars-ga-category', 'tel' );
				$this->safe_set_attribute( $node, 'data-vars-ga-action', $hrefe );
				$this->safe_set_attribute( $node, 'data-vars-ga-label', $label );
				return;
			}

			// for mail.
			if ( substr( $href, 0, strlen( 'mailto:' ) ) === 'mailto:' ) {
				$this->safe_set_attribute( $node, 'class', $class . 'analytify-amp-mail' );
				$this->safe_set_attribute( $node, 'data-vars-ga-category', 'mail' );
				$this->safe_set_attribute( $node, 'data-vars-ga-action', $hrefe );
				$this->safe_set_attribute( $node, 'data-vars-ga-label', $label );
				return;
			}

			$url = wp_parse_url( $href );

			// for download.
			if ( ! empty( $url['path'] ) && ! empty( $this->options['download_extensions'] ) ) {
				if ( preg_match( '/' . $this->options['download_extensions'] . '/', $url['path'] ) ) {
					$this->safe_set_attribute( $node, 'class', $class . 'analytify-amp-download' );
					$this->safe_set_attribute( $node, 'data-vars-ga-category', 'download' );
					$this->safe_set_attribute( $node, 'data-vars-ga-action', $hrefe );
					$this->safe_set_attribute( $node, 'data-vars-ga-label', $label );
					return;
				}
			}

			// for internal as outbound
			if ( ! empty( $this->options['outbound_link'] ) ) {
				foreach ( $this->options['outbound_link'] as $path ) {
					if ( isset( $url['path'] ) && $this->_string_starts_with( $url['path'], $path ) ) {
						$this->safe_set_attribute( $node, 'class', $class . 'analytify-internal-as-outbound' );
						$this->safe_set_attribute( $node, 'data-vars-ga-category', 'outbound-link' );
						$this->safe_set_attribute( $node, 'data-vars-ga-action', $hrefe );
						$this->safe_set_attribute( $node, 'data-vars-ga-label', $label );
						return;
					}
				}
			}

			// for external link.
			$current_url = home_url();
			$current_url = str_replace( 'www.', '', $current_url );
			if ( isset( $url['host'] ) && ! $this->_string_ends_with( $url['host'], $current_url ) ) {
				$this->safe_set_attribute( $node, 'class', $class . 'analytify-outbound-link' );
				$this->safe_set_attribute( $node, 'data-vars-category', 'outbound-link' );
				$this->safe_set_attribute( $node, 'data-vars-action', $hrefe );
				$this->safe_set_attribute( $node, 'data-vars-label', $label );
				return;
			}
		}

		/**
		 * Helper function to check external link.
		 *
		 * @since 1.0.0
		 * @param string $string String to check.
		 * @param string $ending Ending to check for.
		 * @return bool
		 */
		// phpcs:ignore PSR2.Methods.MethodDeclaration.Underscore, Universal.NamingConventions.NoReservedKeywordParameterNames.stringFound
		private function _string_ends_with( $string, $ending ) {
			if ( empty( $string ) || empty( $ending ) ) {
				return false;
			}
			$strlen    = strlen( $string );
			$endinglen = strlen( $ending );
			if ( $endinglen > $strlen ) {
				return false;
			}
			return substr_compare( $string, $ending, $strlen - $endinglen, $endinglen ) === 0;
		}

		/**
		 * Helper function to check outbound link.
		 *
		 * @since 1.0.0
		 * @param string $string String to check.
		 * @param string $start Start to check for.
		 * @return bool
		 */
		// phpcs:ignore PSR2.Methods.MethodDeclaration.Underscore, Universal.NamingConventions.NoReservedKeywordParameterNames.stringFound
		private function _string_starts_with( $string, $start ) {
			if ( empty( $string ) || empty( $start ) ) {
				return false;
			}
			return substr( $string, 0, strlen( $start ) ) === $start;
		}

		/**
		 * Return Outbound option.
		 *
		 * @since 1.0.0
		 * @return array<string>
		 */
		private function get_outbound_links() {
			$links = $GLOBALS['WP_ANALYTIFY']->settings->get_option( 'affiliate-link-path', 'wp-analytify-affiliate-link' );
			return explode( ',', $links );
		}

		/**
		 * Safely set attribute on DOM node.
		 *
		 * @param mixed  $node DOM node.
		 * @param string $name Attribute name.
		 * @param string $value Attribute value.
		 * @return void
		 */
		private function safe_set_attribute( $node, $name, $value ) {
			if ( is_object( $node ) && method_exists( $node, 'setAttribute' ) ) {
				$node->setAttribute( $name, $value );
			}
		}

		/**
		 * Get Label from link.
		 *
		 * @since 1.0.0
		 * @param mixed $node DOM node.
		 * @return string
		 */
		private function get_label( $node ) {
			if ( is_object( $node ) && method_exists( $node, 'hasAttribute' ) && $node->hasAttribute( 'data-vars-ga-label' ) ) {
				return method_exists( $node, 'getAttribute' ) ? $node->getAttribute( 'data-vars-ga-label' ) : '';
			} elseif ( is_object( $node ) && method_exists( $node, 'hasAttribute' ) && $node->hasAttribute( 'title' ) ) {
				return method_exists( $node, 'getAttribute' ) ? $node->getAttribute( 'title' ) : '';
			} elseif ( is_object( $node ) && property_exists( $node, 'textContent' ) && $node->textContent ) {
				return $node->textContent;
			} else {
				return is_object( $node ) && method_exists( $node, 'getAttribute' ) ? $node->getAttribute( 'href' ) : '';
			}
		}
	}
}
