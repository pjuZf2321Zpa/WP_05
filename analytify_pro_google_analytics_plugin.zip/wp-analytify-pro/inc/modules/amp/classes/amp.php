<?php
/**
 * AMP Integration Class.
 *
 * @package WP_Analytify_Pro
 */

// phpcs:ignoreFile WordPress.Files.FileName.InvalidClassFileName

/**
 * Class Analytify_AMP
 *
 * Handles AMP integration for Analytify.
 */
class Analytify_AMP {

	/**
	 * Constructor
	 *
	 * @version 7.0.5
	 */
	public function __construct() {

		$this->admin_hooks();
		$this->public_hooks();
		$this->includes();
	}

	/**
	 * Register all of the hooks related to the admin area functionality
	 * of the plugin.
	 *
	 * @version 7.0.5
	 * @since    1.0.0
	 * @access   private
	 *
	 * @return void
	 */
	private function admin_hooks() {

		add_filter( 'analytify_page_path_filter', array( $this, 'add_amp_pagepath' ), 20, 2 );
		add_action( 'admin_notices', array( $this, 'notics_install_active_amp' ) );
	}

	/**
	 * Check if the AMP plugin is installed or not and active or not
	 * exit if not installed/active
	 *
	 * @version 7.0.5
	 * @return void
	 */
	public function notics_install_active_amp() {
		$screen = get_current_screen();
	
		if ( ! $screen ) {
			return;
		}
	
		// Don't show notice on update pages
		if ( 'update' === $screen->base ) {
			return;
		}
	
		// Define allowed screens where notice should appear
		$allowed_parent_bases = array(
			'analytify-dashboard',
			'plugins',
			'analytify-settings',
			'analytify-license',
			'analytify-addons',
			'dashboard',
		);
	
		$allowed_screen_ids = array(
			'plugins',
			'dashboard',
		);
	
		// Check if we're on an allowed page
		$is_allowed = in_array( $screen->parent_base, $allowed_parent_bases, true )
			|| in_array( $screen->id, $allowed_screen_ids, true )
			|| ( isset( $_GET['page'] ) && strpos( $_GET['page'], 'analytify' ) === 0 );
	
		// Don't show notice if not on allowed page
		if ( ! $is_allowed ) {
			return;
		}
	
		// Check user capabilities
		if ( ! current_user_can( 'install_plugins' ) || ! current_user_can( 'activate_plugins' ) ) {
			return;
		}
	
		// Case 1: AMP plugin not installed
		if ( ! file_exists( WP_PLUGIN_DIR . '/amp/amp.php' ) ) {
			$action = 'install-plugin';
			$slug   = 'amp';
			$link   = wp_nonce_url(
				add_query_arg(
					array(
						'action' => $action,
						'plugin' => $slug,
					),
					admin_url( 'update.php' )
				),
				$action . '_' . $slug
			);
	
			$message = sprintf(
				'%1$s <a href="%2$s">%3$s</a>',
				esc_html__( 'Analytify\'s AMP addon requires the AMP plugin to be installed. —', 'wp-analytify-pro' ),
				esc_url( $link ),
				esc_html__( 'Click here to install the official plugin from the AMP project.', 'wp-analytify-pro' )
			);
	
			wp_analytify_pro_notice( $message, 'wp-analytify-danger' );
		}
		// Case 2: AMP plugin installed but not active
		elseif ( ! is_plugin_active( 'amp/amp.php' ) ) {
			$action = 'activate';
			$slug   = 'amp/amp.php';
			$link   = wp_nonce_url(
				add_query_arg(
					array(
						'action' => $action,
						'plugin' => $slug,
					),
					admin_url( 'plugins.php' )
				),
				'activate-plugin_' . $slug
			);
	
			$message = sprintf(
				'%1$s <a href="%2$s">%3$s</a>',
				esc_html__( 'Analytify\'s AMP addon requires the AMP plugin to be active. —', 'wp-analytify-pro' ),
				esc_url( $link ),
				esc_html__( 'Click here to activate the AMP plugin.', 'wp-analytify-pro' )
			);
	
			wp_analytify_pro_notice( $message, 'wp-analytify-danger' );
		}
	}

	/**
	 * Register all of the hooks related to the public-facing functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 *
	 * @return void
	 */
	private function public_hooks() {

		add_filter( 'analytify_tracking_code_create_option', array( $this, 'use_amp_client_id' ) );
		add_action( 'amp_post_template_head', array( $this, 'add_amp_client_id_meta' ), 15 );
		add_filter( 'amp_post_template_analytics', array( $this, 'add_analytics_code' ) );
	}

	/**
	 * Include required files.
	 *
	 * @return void
	 */
	public function includes() {

		require_once defined( 'ANALYTIFY_PRO_ROOT_PATH' ) ? ANALYTIFY_PRO_ROOT_PATH . '/inc/modules/amp/includes/tracking.php' : '';
	}

	/**
	 * Use AMP Client Api in tracking code..
	 *
	 * @since 1.0.0
	 * @param array<string, mixed> $create Create options array.
	 * @return array<string, mixed>
	 */
	public function use_amp_client_id( $create ) {

		$create['useAmpClientId'] = true;
		return $create;
	}

	/**
	 * Add AMP Client ID meta.
	 *
	 * @since 1.0.0
	 * @param mixed $template Template object.
	 * @return void
	 */
	// phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found
	public function add_amp_client_id_meta( $template ) {

		echo '<meta name="analytify-amp-google-client-id-api" content="googleanalytics">';
	}

	/**
	 * Add AMP page path filter.
	 *
	 * @param string               $filter Filter string.
	 * @param array<string, mixed> $u_post Post data array.
	 * @return string
	 */
	public function add_amp_pagepath( $filter, $u_post ) {
		if ( is_string( $filter ) && isset( $u_post['path'] ) ) {
			return $filter . ',ga:pagePath==' . $u_post['path'] . '?amp=1';
		}
		return $filter;
	}

	/**
	 * Add Analytics Code on Footer.
	 *
	 * @since 1.0.0
	 * @param array<string, mixed> $analytics Analytics array.
	 * @return array<string, mixed>
	 */
	public function add_analytics_code( $analytics ) {

		// Check if user tracking is enabled.
		if ( function_exists( 'analytify_is_track_user' ) && false === analytify_is_track_user() ) {
			return $analytics;
		}

		$ua_code = class_exists( 'WP_ANALYTIFY_FUNCTIONS' ) && method_exists( 'WP_ANALYTIFY_FUNCTIONS', 'get_UA_code' ) ? WP_ANALYTIFY_FUNCTIONS::get_UA_code() : '';

		// Check if UA code setup.
		if ( ! $ua_code ) {
			return $analytics;
		}

		$analytics['analytify-googleanalytics'] = array(
			'type'        => 'googleanalytics',
			'attributes'  => array(),
			'config_data' => array(
				'vars'     => array(
					'account' => $ua_code,
				),
				'triggers' => array(
					'trackPageview' => array(
						'on'      => 'visible',
						'request' => 'pageview',
					),
				),
			),
		);

		return $analytics;
	}
}

new Analytify_AMP();
