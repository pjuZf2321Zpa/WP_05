<?php
/**
 * This file is reponsible for initializing ads tracking.
 *
 * @package wp-analytify-pro
 */

// phpcs:ignoreFile WordPress.Files.FileName.NotHyphenatedLowercase, WordPress.Files.FileName.InvalidClassFileName

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Analytify_Ads_WooCommerce
 *
 * This class handles Google Ads conversion tracking integration with WooCommerce.
 */
class Analytify_Ads_WooCommerce {

	/**
	 * The ID of the Google Ads conversion.
	 *
	 * @var string
	 */
	public $ads_conversion_id = '';

	/**
	 * The label of the Google Ads conversion.
	 *
	 * @var string
	 */
	public $ads_conversion_label = '';

	use Analytify_WooCommerce_Conversions_Helpers;

	/**
	 * Analytify_Ads_WooCommerce constructor.
	 *
	 * @param string $ads_conversion_id    The ID of the Google Ads conversion.
	 * @param string $ads_conversion_label The label of the Google Ads conversion.
	 */
	public function __construct( string $ads_conversion_id, string $ads_conversion_label ) {
		$this->ads_conversion_id    = $ads_conversion_id;
		$this->ads_conversion_label = $ads_conversion_label;

		$this->hooks();
	}

	/**
	 * Add conversion related hooks.
	 *
	 * @return void
	 */
	public function hooks() {
		add_action( 'analytify_tracking_code_after_pageview', array( $this, 'gtag_conversion_call' ) );
	}

	/**
	 * Call the Google Ads conversion when conditions are met.
	 *
	 * @return void
	 */
	public function gtag_conversion_call() {
		if ( apply_filters( 'analytify_ads_is_conversion_page', $this->conversion_checks() ) ) {
			// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Inline script built with wp_json_encode only.
			echo $this->conversion_tracking_code();
			$this->set_order_tracked();
		}
	}

	/**
	 * Generate the conversion tracking code.
	 *
	 * @return string The generated conversion tracking code.
	 */
	public function conversion_tracking_code() {
		$code = '';

		if ( ! $this->is_tracked() ) {
			$conversion_info = $this->get_conversion_info();
			if ( empty( $conversion_info['send_to'] ) ) {
				return $code;
			}

			$code = stripslashes(
				sprintf(
					"\ngtag( %s, %s, %s );",
					wp_json_encode( 'event' ),
					wp_json_encode( 'conversion' ),
					wp_json_encode( $conversion_info )
				)
			);
		}

		return $code;
	}

	/**
	 * Get the conversion event information.
	 *
	 * @return array<string, mixed> An array containing conversion event information.
	 */
	public function get_conversion_info() {
		$send_id    = Analytify_Google_Ads_Tracking::sanitize_ads_conversion_id( $this->ads_conversion_id );
		$send_label = Analytify_Google_Ads_Tracking::sanitize_ads_conversion_label( $this->ads_conversion_label );

		if ( false === $send_id || false === $send_label ) {
			return array();
		}

		$conversion_event_info = array(
			'send_to' => $send_id . '/' . $send_label,
		);

		$order_total = $this->get_order_total();
		if ( $order_total ) {
			$conversion_event_info['value'] = (float) $order_total;
		}

		$order_number = $this->get_order_number();
		if ( $order_number ) {
			$conversion_event_info['transaction_id'] = sanitize_text_field( (string) $order_number );
		}

		$currency = $this->get_order_currency();
		if ( $currency ) {
			$currency = strtoupper( preg_replace( '/[^A-Za-z]/', '', (string) $currency ) );
			$conversion_event_info['currency'] = substr( $currency, 0, 3 );
		}

		return $conversion_event_info;
	}
}
