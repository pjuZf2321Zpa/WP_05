<?php
/**
 * WooCommerce Conversions Helpers Trait.
 *
 * @package WP_Analytify_Pro
 */

// phpcs:ignoreFile WordPress.Files.FileName.NotHyphenatedLowercase

/**
 * This trait provides helper methods related to WooCommerce conversions tracking.
 */
trait Analytify_WooCommerce_Conversions_Helpers {

	/**
	 * The WooCommerce order ID associated with the conversion.
	 *
	 * @var int|false|null
	 */
	public $wc_order_id;

	/**
	 * The WooCommerce order object associated with the conversion.
	 *
	 * @var object|false|null
	 */
	public $wc_order;

	/**
	 * Checks if the current page is the order received page.
	 *
	 * @return bool Returns true if the current page is the order received page, false otherwise.
	 */
	public function conversion_checks() {
		if ( function_exists( 'is_order_received_page' ) && is_order_received_page() ) {
			return true;
		}
		return false;
	}

	/**
	 * Checks if the conversion is tracked for the current order.
	 *
	 * @return bool Returns true if the conversion is tracked, false otherwise.
	 */
	public function is_tracked() {
		$order = $this->get_order();
		if ( $order && is_object( $order ) && method_exists( $order, 'get_meta' ) ) {
			$tracked = $order->get_meta( 'analytify_ads_conversion_tracked' );
			return ! empty( $tracked ) && 'yes' === $tracked;
		}
		return false;
	}

	/**
	 * Retrieves the WooCommerce order object associated with the current order number.
	 *
	 * @return object|false Returns the WooCommerce order object if found, otherwise false.
	 */
	public function get_order() {
		if ( ! isset( $this->wc_order ) ) {
			if ( $this->get_order_number() ) {
				$this->wc_order = function_exists( 'wc_get_order' ) ? wc_get_order( $this->get_order_number() ) : false;
			} else {
				$this->wc_order = false;
			}
		}
		return $this->wc_order;
	}

	/**
	 * Retrieves the WooCommerce order number from the query variables.
	 *
	 * @return int|false|null Returns the WooCommerce order number if found, otherwise false.
	 */
	public function get_order_number() {
		if ( ! isset( $this->wc_order_id ) ) {
			$wc_order_id = absint( get_query_var( 'order-received' ) );
			if ( empty( $wc_order_id ) ) {
				$this->wc_order_id = false;
			} else {
				$this->wc_order_id = $wc_order_id;
			}
		}
		return $this->wc_order_id;
	}

	/**
	 * Retrieves the total amount of the current order.
	 *
	 * @return float|false Returns the order total amount if the order is available, otherwise false.
	 */
	public function get_order_total() {
		$order = $this->get_order();
		if ( $order && is_object( $order ) && method_exists( $order, 'get_total' ) ) {
			return (float) $order->get_total();
		}
		return false;
	}

	/**
	 * Retrieves the currency of the current order.
	 *
	 * @return string|false Returns the order currency if the order is available, otherwise false.
	 */
	public function get_order_currency() {
		$order = $this->get_order();
		if ( $order && is_object( $order ) && method_exists( $order, 'get_currency' ) ) {
			return $order->get_currency();
		}
		return false;
	}

	/**
	 * Sets the conversion tracked status for the current order.
	 *
	 * @return void
	 */
	public function set_order_tracked() {
		$order = $this->get_order();
		if ( $order && is_object( $order ) && method_exists( $order, 'add_meta_data' ) && method_exists( $order, 'save_meta_data' ) ) {
			$order->add_meta_data( 'analytify_ads_conversion_tracked', 'yes', true );
			$order->save_meta_data();
		}
	}
}
