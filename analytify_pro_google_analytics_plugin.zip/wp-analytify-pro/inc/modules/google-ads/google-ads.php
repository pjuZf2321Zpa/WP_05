<?php
/**
 * This file is responsible for initializing ads tracking.
 *
 * @package wp-analytify-pro
 */

// phpcs:ignoreFile WordPress.Files.FileName.InvalidClassFileName

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Analytify_Google_Ads_Tracking
 *
 * Handles Google Ads conversion tracking.
 */
class Analytify_Google_Ads_Tracking {

	/**
	 * The tracking ads option.
	 *
	 * @var bool
	 */
	public $track_ads = false;

	/**
	 * The conversion ID.
	 *
	 * @var bool|string
	 */
	public $ads_conversion_id = false;

	/**
	 * The conversion label.
	 *
	 * @var bool|string
	 */
	public $ads_conversion_label = false;

	/**
	 * The Single object of this class.
	 *
	 * @var null|Analytify_Google_Ads_Tracking
	 */
	public static $instance = null;

	/**
	 * Analytify_Google_Ads_Tracking class constructor.
	 */
	public function __construct() {

		$this->set_addon_option_values();
		$this->includes();
		$this->hooks();
		$this->instantiate_ecommerce_conversion_tracking();
	}

	/**
	 * Return the single instance
	 * of the class.
	 *
	 * @return self
	 */
	public static function get_instance() {

		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Set the option values saved for the
	 * module in class properties.
	 *
	 * @return void
	 */
	public function set_addon_option_values() {

		$google_ads_tracking_options = get_option( 'analytify-google-ads-tracking' );

		if ( ! is_array( $google_ads_tracking_options ) ) {
			return;
		}

		$this->track_ads = ! empty( $google_ads_tracking_options['ads_conversion_tracking'] );

		$this->ads_conversion_id = isset( $google_ads_tracking_options['ads_conversion_id'] )
			? self::sanitize_ads_conversion_id( $google_ads_tracking_options['ads_conversion_id'] )
			: false;

		$this->ads_conversion_label = isset( $google_ads_tracking_options['ads_conversion_label'] )
			? self::sanitize_ads_conversion_label( $google_ads_tracking_options['ads_conversion_label'] )
			: false;
	}

	/**
	 * Sanitize Google Ads conversion ID (AW-#########).
	 *
	 * @param mixed $id Raw value from options.
	 * @return string|false Sanitized ID or false if invalid.
	 */
	public static function sanitize_ads_conversion_id( $id ) {
		if ( ! is_string( $id ) && ! is_numeric( $id ) ) {
			return false;
		}

		$id = sanitize_text_field( (string) $id );

		if ( '' === $id || ! preg_match( '/^AW-\d+$/', $id ) ) {
			return false;
		}

		return $id;
	}

	/**
	 * Sanitize Google Ads conversion label for send_to.
	 *
	 * @param mixed $label Raw value from options.
	 * @return string|false Sanitized label or false if invalid.
	 */
	public static function sanitize_ads_conversion_label( $label ) {
		if ( ! is_string( $label ) && ! is_numeric( $label ) ) {
			return false;
		}

		$label = sanitize_text_field( (string) $label );
		$label = preg_replace( '/[^A-Za-z0-9_-]/', '', $label );
		$label = substr( $label, 0, 200 );

		if ( '' === $label ) {
			return false;
		}

		return $label;
	}

	/**
	 * Includes the required files for the module.
	 *
	 * @return void
	 */
	public function includes() {
		if ( defined( 'ANALYTIFY_PRO_ROOT_PATH' ) ) {
			// Including google ads module settings.
			require_once ANALYTIFY_PRO_ROOT_PATH . '/inc/modules/google-ads/ads-module-settings.php';
			require_once ANALYTIFY_PRO_ROOT_PATH . '/inc/modules/google-ads/integrations/traits/Class-WooCommerce-Helpers.php';
			require_once ANALYTIFY_PRO_ROOT_PATH . '/inc/modules/google-ads/integrations/traits/class-edd-helpers.php';
			require_once ANALYTIFY_PRO_ROOT_PATH . '/inc/modules/google-ads/integrations/Class-Analytify-Ads-WooCommerce.php';
			require_once ANALYTIFY_PRO_ROOT_PATH . '/inc/modules/google-ads/integrations/Class-Analytify-Ads-EDD.php';
		}
	}

	/**
	 * Check if WooCommerce or EDD exists and it's the order received page.
	 * After that check for module settings if the ads tracking is on
	 * and user has added some conversion id.
	 *
	 * Instatiate the classes.
	 *
	 * @return void
	 */
	public function instantiate_ecommerce_conversion_tracking() {

		$should_track_ads = $this->track_ads && $this->ads_conversion_id && $this->ads_conversion_label;

		if ( class_exists( 'WooCommerce' ) && $should_track_ads ) {

			new Analytify_Ads_WooCommerce( (string) $this->ads_conversion_id, (string) $this->ads_conversion_label );

		}

		if ( class_exists( 'Easy_Digital_Downloads' ) && $should_track_ads ) {

			new Analytify_Ads_EDD( (string) $this->ads_conversion_id, (string) $this->ads_conversion_label );

		}
	}

	/**
	 * Add conversion related hooks.
	 *
	 * @return void
	 */
	public function hooks() {

		add_action( 'analytify_tracking_code_before_pageview', array( $this, 'analytify_ads_tracking_code_callback' ) );
	}

	/**
	 * Add a gtag config command in the main Analytics script for google
	 * Conversion Id.
	 *
	 * @return void
	 */
	public function analytify_ads_tracking_code_callback() {

		if ( ! empty( $this->ads_conversion_id ) ) {
			// Build the call without literal quotes in the format string (avoids &#039; if markup is escaped).
			printf(
				"gtag( %s, %s );\n",
				wp_json_encode( 'config' ),
				wp_json_encode( (string) $this->ads_conversion_id )
			);
		}
	}
}

Analytify_Google_Ads_Tracking::get_instance();
