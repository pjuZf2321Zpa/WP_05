<?php
/**
 * Load Analytify Modules.
 *
 * @package WP_Analytify_Pro
 */

// Retrieve the `wp_analytify_modules` option.
$analytify_modules = get_option( 'wp_analytify_modules' );

// Ensure it's an array before processing.
if ( is_array( $analytify_modules ) ) {
	// Filter out the 'google-optimize' module.
	$analytify_modules = array_filter(
		$analytify_modules,
		function ( $module ) {
			return 'google-optimize' !== $module['slug'];
		}
	);

	// Save the updated option back to the database.
	update_option( 'wp_analytify_modules', $analytify_modules );

	// Loop through active modules except 'google-ads-tracking'.
	foreach ( $analytify_modules as $module ) {
		if ( 'active' === $module['status'] && 'google-ads-tracking' !== $module['slug'] && 'pixels-tracking' !== $module['slug'] ) {
			if ( defined( 'ANALYTIFY_PRO_ROOT_PATH' ) ) {
				$module_file = ANALYTIFY_PRO_ROOT_PATH . '/inc/modules/' . $module['slug'] . '/classes/' . $module['slug'] . '.php';
				if ( file_exists( $module_file ) ) {
					include_once $module_file;
				}
			}
		}
	}
}

// Including google ads file only if active.
if ( isset( $analytify_modules['google-ads-tracking'] ) && 'active' === $analytify_modules['google-ads-tracking']['status'] ) {
	include_once ANALYTIFY_PRO_ROOT_PATH . '/inc/modules/google-ads/google-ads.php';
}

// Including pixels tracking file only if active.
if ( isset( $analytify_modules['pixels-tracking'] ) && 'active' === $analytify_modules['pixels-tracking']['status'] ) {
	include_once ANALYTIFY_PRO_ROOT_PATH . '/inc/modules/pixels-tracking/class-analytify-pixels-tracking.php';
}
