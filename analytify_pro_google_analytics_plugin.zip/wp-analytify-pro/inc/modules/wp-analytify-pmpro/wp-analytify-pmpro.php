<?php // phpcs:ignore WordPress.Files.FileName.InvalidClassFileName -- Intentionally named for addon system.
/**
 * Paid Memberships Pro integration loader for Analytify.
 *
 * This file is intentionally named wp-analytify-pmpro.php to match the addon naming convention.
 * All public methods use the wpa_ prefix for consistency.
 *
 * @package    WP_Analytify_Pro
 * @subpackage PMPro
 * @since      9.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Analytify PMPro loader class.
 *
 * Bootstraps the PMPro addon, checks dependencies, and registers wpa_ prefixed hooks.
 *
 * @since 9.0.0
 */
class Analytify_PMPro_Loader {

	/**
	 * The one true instance.
	 *
	 * @var Analytify_PMPro_Loader
	 */
	public static $instance;

	/**
	 * Get the singleton instance.
	 *
	 * @return Analytify_PMPro_Loader
	 */
	public static function wpa_pmpro_get_instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->wpa_pmpro_define_constants();
		$this->wpa_pmpro_hooks();
		$this->wpa_pmpro_may_be_load_addon();
	}

	/**
	 * Load the addon if dependencies are met.
	 */
	public function wpa_pmpro_may_be_load_addon() {
		/**
		 * Check for Paid Memberships Pro.
		 */
		if ( ! $this->wpa_pmpro_is_core_loaded() ) {
			return;
		} elseif (
			file_exists( WP_PLUGIN_DIR . '/wp-analytify-pro/wp-analytify-pro.php' )
			&& function_exists( 'wp_analytify_pro_load' )
			&& class_exists( 'WP_Analytify_Pro_Base' )
		) {
			$root = ANALYTIFY_PRO_PMPRO_ADDON_ROOT_PATH;
			require_once $root . '/classes/class-analytify-pmpro-tracking-trait.php';
			require_once $root . '/classes/class-analytify-pmpro-dashboard-data-trait.php';
			require_once $root . '/classes/class-analytify-pmpro-settings-trait.php';
			include_once $root . '/class-wp-analytify-pmpro-addon.php';
			// Global for backwards compatibility.
			$GLOBALS['WPAnalytifyProPMPro'] = WP_Analytify_PMPro_Addon::wpa_pmpro_instance();
		}
	}

	/**
	 * Define constants.
	 */
	public function wpa_pmpro_define_constants() {
		define( 'ANALYTIFY_PRO_PMPRO_ADDON_ROOT_PATH', __DIR__ );
		define( 'ANALYTIFY_PRO_PMPRO_UPGRADE_PATH', __FILE__ );
		// Set to default if tracking mode not set.
		if ( ! defined( 'ANALYTIFY_PRO_TRACKING_MODE' ) ) {
			define( 'ANALYTIFY_PRO_TRACKING_MODE', 'gtag' );
		}
	}

	/**
	 * Setup hooks.
	 */
	public function wpa_pmpro_hooks() {
		add_action( 'admin_notices', array( $this, 'wpa_check_analytify_admin_notice' ) );
		add_action( 'admin_notices', array( $this, 'wpa_check_analytify_pro_admin_notice' ) );
		add_action( 'admin_notices', array( $this, 'wpa_check_pmpro_admin_notice' ) );
		add_action( 'admin_notices', array( $this, 'wpa_install_pmpro' ) );
		add_action( 'init', array( $this, 'wpa_pmpro_load_text_domain' ) );
		add_action( 'admin_footer', array( $this, 'wpa_pmpro_notice_script' ) );
		add_action( 'wp_ajax_dismiss_analytify_notice', array( $this, 'wpa_pmpro_dismiss_notice' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'wpa_pmpro_notices_scripts' ) );

		// Initialize REST API early to ensure routes are registered.
		add_action( 'rest_api_init', array( $this, 'wpa_pmpro_init_rest_api' ) );
	}

	/**
	 * Whether Paid Memberships Pro core is loaded (any plugin directory path).
	 *
	 * @since 9.0.0
	 * @return bool
	 */
	private function wpa_pmpro_is_core_loaded() {
		return function_exists( 'pmpro_getAllLevels' ) || defined( 'PMPRO_VERSION' );
	}

	/**
	 * Default PMPro main file path (wordpress.org package, un-renamed folder).
	 *
	 * @since 9.0.0
	 * @return string
	 */
	private function wpa_pmpro_default_plugin_file() {
		return WP_PLUGIN_DIR . '/paid-memberships-pro/paid-memberships-pro.php';
	}

	/**
	 * Admin notices scripts and notice dismiss inline script.
	 *
	 * @return void
	 */
	public function wpa_pmpro_notices_scripts() {
		wp_enqueue_style( 'analytify-pmpro-notices', plugins_url( 'assets/css/notices' . analytify_pro_get_asset_suffix() . '.css', __FILE__ ), array(), ANALYTIFY_PRO_VERSION );

		$screen = get_current_screen();
		if ( ! $screen ) {
			return;
		}
		$allowed_parent_bases = array( 'analytify-dashboard', 'plugins', 'analytify-settings', 'analytify-license', 'analytify-addons', 'dashboard' );
		$allowed_screen_ids   = array( 'plugins', 'dashboard' );
		$page                 = isset( $_GET['page'] ) ? sanitize_text_field( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$is_allowed           = in_array( $screen->parent_base, $allowed_parent_bases, true )
			|| in_array( $screen->id, $allowed_screen_ids, true )
			|| ( ! empty( $page ) && strpos( $page, 'analytify' ) === 0 );
		if ( ! $is_allowed ) {
			return;
		}
		wp_enqueue_script( 'jquery' );
		$ajaxurl = esc_url( admin_url( 'admin-ajax.php' ) );
		$nonce   = wp_create_nonce( 'analytify_pmpro_dismiss_notice' );
		$js      = sprintf(
			"function dismissAnalytifyNotice(noticeId) {\n\tdocument.getElementById(noticeId).style.display = 'none';\n\tlocalStorage.setItem('analytify_stats_refreshed_dismissed', '1');\n\tvar ajaxurl = %s;\n\tvar data = { 'action': 'dismiss_analytify_notice', 'notice_id': noticeId, 'nonce': %s };\n\tjQuery.post(ajaxurl, data, function(response) {});\n}",
			wp_json_encode( $ajaxurl ),
			wp_json_encode( $nonce )
		);
		wp_add_inline_script( 'jquery', $js, 'after' );
	}

	/**
	 * Initialize REST API routes.
	 */
	public function wpa_pmpro_init_rest_api() {
		$rest_api_file = ANALYTIFY_PRO_PMPRO_ADDON_ROOT_PATH . '/classes/class-analytify-pmpro-rest-api.php';

		if ( file_exists( $rest_api_file ) && ! class_exists( 'Analytify_PMPro_REST_API' ) ) {
			include_once $rest_api_file;
		}
		if ( class_exists( 'Analytify_PMPro_REST_API' ) && method_exists( 'Analytify_PMPro_REST_API', 'wpa_pmpro_register_routes' ) ) {
			Analytify_PMPro_REST_API::wpa_pmpro_register_routes();
		}
	}

	/**
	 * Check Analytify free plugin installation.
	 *
	 * @version 9.1.1
	 * @return void
	 */
	public function wpa_check_analytify_admin_notice() {
		if ( ! class_exists( 'WP_Analytify' ) ) {
			$message = __( '<strong>Attention:</strong> Analytify for PMPro addon works with the Analytify plugin. Please activate Analytify.', 'wp-analytify-pro' );
			$this->wpa_pmpro_notice( $message, 'wp-analytify-danger' );
		}
	}

	/**
	 * Check Analytify pro plugin installation.
	 *
	 * @version 9.1.1
	 * @return void
	 */
	public function wpa_check_analytify_pro_admin_notice() {
		if ( ! class_exists( 'WP_Analytify_Pro' ) ) {
			$message = __( '<strong>Attention:</strong> Analytify for PMPro addon works with the Analytify PRO plugin. Please activate Analytify PRO.', 'wp-analytify-pro' );
			$this->wpa_pmpro_notice( $message, 'wp-analytify-danger' );
		}
	}

	/**
	 * Install PMPro notice.
	 *
	 * @version 9.1.1
	 * @return void
	 */
	public function wpa_install_pmpro() {
		if ( $this->wpa_pmpro_is_core_loaded() ) {
			return;
		}
		if ( ! file_exists( $this->wpa_pmpro_default_plugin_file() ) ) {
			$message = __( '<strong>Attention:</strong> Analytify for PMPro addon works with the Paid Memberships Pro plugin. Please install Paid Memberships Pro.', 'wp-analytify-pro' );
			$this->wpa_pmpro_notice( $message, 'wp-analytify-danger' );
		}
	}

	/**
	 * Check PMPro plugin installation.
	 *
	 * @version 9.1.1
	 * @return void
	 */
	public function wpa_check_pmpro_admin_notice() {
		if ( $this->wpa_pmpro_is_core_loaded() ) {
			return;
		}
		if ( file_exists( $this->wpa_pmpro_default_plugin_file() ) ) {
			$message = __( '<strong>Attention:</strong> Analytify for PMPro addon works with the Paid Memberships Pro plugin. Please activate Paid Memberships Pro.', 'wp-analytify-pro' );
			$this->wpa_pmpro_notice( $message, 'wp-analytify-danger' );
		}
	}


	/**
	 * Load TextDomain.
	 *
	 * @since 1.0.0
	 */
	public function wpa_pmpro_load_text_domain() {
		$plugin_dir = basename( __DIR__ );
		load_plugin_textdomain( 'wp-analytify-pmpro', false, $plugin_dir . '/languages/' );
	}

	/**
	 * Add custom admin notice.
	 *
	 * @param string $message      Custom Message.
	 * @param string $notice_class CSS class for notice.
	 */
	public function wpa_pmpro_notice( $message, $notice_class = 'wp-analytify-success' ) { // phpcs:ignore Universal.NamingConventions.NoReservedKeywordParameterNames.classFound
		// Only show notices on allowed pages.
		$screen = get_current_screen();

		if ( ! $screen ) {
			return;
		}

		$allowed_parent_bases = array(
			'analytify-dashboard',
			'plugins',
			'analytify-settings',
			'analytify-license',
			'analytify-addons',
			'dashboard',
		);

		$allowed_screen_ids = array(
			'plugins',
			'dashboard',
		);

		// Check if we're on an allowed page.
		$page       = isset( $_GET['page'] ) ? sanitize_text_field( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$is_allowed = in_array( $screen->parent_base, $allowed_parent_bases, true )
			|| in_array( $screen->id, $allowed_screen_ids, true )
			|| ( ! empty( $page ) && strpos( $page, 'analytify' ) === 0 );

		// Don't show notice if not on allowed page.
		if ( ! $is_allowed ) {
			return;
		}

		$notice_id = 'analytify_notice_' . md5( $message );
		if ( ! get_option( $notice_id ) ) {
			echo '<div class="wp-analytify-notification ' . esc_attr( $notice_class ) . '" id="' . esc_attr( $notice_id ) . '">
					<a class="wp-analytify-notice-dismiss" href="#" aria-label="Dismiss the notice" onclick="dismissAnalytifyNotice(\'' . esc_js( $notice_id ) . '\'); return false;">&times;</a>
					<div class="wp-analytify-notice-logo">
						<img src="' . esc_url( ANALYTIFY_PLUGIN_URL . 'assets/img/logo.svg' ) . '" alt="notice">
					</div>
					<div class="wp-analytify-notice-discription">
						<p>' . wp_kses_post( $message ) . '</p>
					</div>
				</div>';
		}
	}

	/**
	 * Output notice dismiss script (script is added via wp_add_inline_script in wpa_pmpro_notices_scripts).
	 *
	 * @return void
	 */
	public function wpa_pmpro_notice_script() {
		// Script output moved to wp_add_inline_script( 'jquery', ... ) in wpa_pmpro_notices_scripts().
	}

	/**
	 * Dismiss Analytify notice via AJAX.
	 *
	 * @return void
	 */
	public function wpa_pmpro_dismiss_notice() {
		check_ajax_referer( 'analytify_pmpro_dismiss_notice', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( -1 );
		}

		if ( isset( $_POST['notice_id'] ) ) {
			$notice_id = sanitize_text_field( wp_unslash( $_POST['notice_id'] ) );
			// Only allow our own notice keys (analytify_notice_ + 32-char md5).
			if ( preg_match( '/^analytify_notice_[a-f0-9]{32}$/', $notice_id ) ) {
				update_option( $notice_id, true );
			}
		}
		wp_die();
	}
}

// Initialize the plugin.
Analytify_PMPro_Loader::wpa_pmpro_get_instance();
