<?php
/**
 * PMPro Overview view.
 *
 * @package WP_Analytify_Pro
 * @subpackage PMPro\Views
 * @since 9.0.0
 */

/**
 * Display PMPro overview statistics.
 *
 * @since 9.0.0
 * @param WP_Analytify $current Current object.
 * @param array        $stats   Statistics data.
 * @return void
 */
function wpa_pmpro_overview( $current, $stats ) {

	ob_start();

	$total_revenue             = isset( $stats['total_revenue'] ) ? (float) $stats['total_revenue'] : 0;
	$total_orders              = isset( $stats['total_orders'] ) ? (int) $stats['total_orders'] : 0;
	$average_order_value       = isset( $stats['average_order_value'] ) ? (float) $stats['average_order_value'] : 0;
	$active_members            = isset( $stats['active_members'] ) ? (int) $stats['active_members'] : 0;
	$total_memberships         = isset( $stats['total_memberships'] ) ? (int) $stats['total_memberships'] : 0;
	$conversion_rate           = isset( $stats['conversion_rate'] ) ? (float) $stats['conversion_rate'] : 0.0;
	$first_time_purchaser_rate = isset( $stats['first_time_purchaser_rate'] ) ? (float) $stats['first_time_purchaser_rate'] : 0.0;

	// Get currency code for formatting.
	$currency_code   = isset( $stats['currencyCode'] ) && '(not set)' !== $stats['currencyCode'] ? $stats['currencyCode'] : '';
	$currency_symbol = '';
	if ( function_exists( 'pmpro_getCurrency' ) ) {
		$pmpro_currency  = pmpro_getCurrency();
		$currency_symbol = isset( $pmpro_currency['symbol'] ) ? $pmpro_currency['symbol'] : '';
	}

	$boxes = array(
		'total_orders'              => array(
			'label'       => esc_html__( 'Transactions', 'wp-analytify-pro' ),
			'value'       => number_format( $total_orders ),
			'description' => esc_html__( 'Total number of online membership purchases.', 'wp-analytify-pro' ),
		),
		'total_revenue'             => array(
			'label'       => esc_html__( 'Transaction Revenues', 'wp-analytify-pro' ),
			'value'       => esc_html( $currency_symbol ) . number_format( $total_revenue, 2 ),
			'description' => esc_html__( 'Total revenue from online membership purchases.', 'wp-analytify-pro' ),
		),
		'average_order_value'       => array(
			'label'       => esc_html__( 'Average Order Value', 'wp-analytify-pro' ),
			'value'       => esc_html( $currency_symbol ) . number_format( $average_order_value, 2 ),
			'description' => esc_html__( 'Average Value per transactions.', 'wp-analytify-pro' ),
		),
		'active_members'            => array(
			'label'       => esc_html__( 'All-Time Active Members', 'wp-analytify-pro' ),
			'value'       => number_format( $active_members ),
			'description' => esc_html__( 'Total number of active members from the start.', 'wp-analytify-pro' ),
		),
		'total_memberships'         => array(
			'label'       => esc_html__( 'Active Memberships', 'wp-analytify-pro' ),
			'value'       => number_format( $total_memberships ),
			'description' => esc_html__( 'Active membership entries in PMPro.', 'wp-analytify-pro' ),
		),
		'conversion_rate'           => array(
			'label'       => esc_html__( 'Conversion Rate', 'wp-analytify-pro' ),
			'value'       => number_format( $conversion_rate, 2 ) . '%',
			'description' => esc_html__( 'Percentage of sessions resulting in a transaction.', 'wp-analytify-pro' ),
		),
		'first_time_purchaser_rate' => array(
			'label'       => esc_html__( 'New Customers', 'wp-analytify-pro' ),
			'value'       => number_format( $first_time_purchaser_rate, 2 ) . '%',
			'description' => esc_html__( 'The percentage of first-time purchasers.', 'wp-analytify-pro' ),
		),
	);
	?>
	<div class="analytify_general_status analytify_status_box_wraper">
		<div class="analytify_status_header">
			<h3><?php esc_html_e( 'Overview', 'wp-analytify-pro' ); ?></h3>
		</div>
		<div class="analytify_status_body">
			<div class="analytify_general_status_boxes_wraper">
				<?php foreach ( $boxes as $box ) { ?>
					<div class="analytify_general_status_boxes">
						<h4><?php echo esc_html( $box['label'] ); ?></h4>
						<div class="analytify_general_stats_value"><?php echo esc_html( $box['value'] ); ?></div>
						<p><?php echo esc_html( $box['description'] ); ?></p>
					</div>
				<?php } ?>
			</div>
		</div>
	</div>
	<?php

	wp_send_json(
		array(
			'body' => ob_get_clean(),
		)
	);
}
