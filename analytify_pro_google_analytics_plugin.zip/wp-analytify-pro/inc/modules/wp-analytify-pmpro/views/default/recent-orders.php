<?php
/**
 * PMPro Recent Orders view.
 *
 * @package WP_Analytify_Pro
 * @subpackage PMPro\Views
 * @since 9.0.0
 */

/**
 * Display recent membership orders.
 *
 * @since 9.0.0
 * @param WP_Analytify $current Current object.
 * @param array        $orders  Orders data.
 * @return void
 */
function wpa_pmpro_recent_orders( $current, $orders ) {

	ob_start(); ?>

	<div class="analytify_general_status analytify_status_box_wraper">
		<div class="analytify_status_header">
			<h3><?php esc_html_e( 'Recent Membership Orders', 'wp-analytify-pro' ); ?></h3>
		</div>
		<div class="analytify_status_body">
			<table class="analytify_data_tables wp_analytify_paginated" data-product-per-page="10">
				<thead>
					<tr>
						<th class="analytify_table_header_no_events analytify_txt_center">#</th>
						<th class="analytify_txt_center"><?php esc_html_e( 'Order ID', 'wp-analytify-pro' ); ?></th>
						<th class="analytify_txt_center"><?php esc_html_e( 'Member', 'wp-analytify-pro' ); ?></th>
						<th class="analytify_txt_center"><?php esc_html_e( 'Level', 'wp-analytify-pro' ); ?></th>
						<th class="analytify_txt_center"><?php esc_html_e( 'Total', 'wp-analytify-pro' ); ?></th>
						<th class="analytify_txt_center"><?php esc_html_e( 'Gateway', 'wp-analytify-pro' ); ?></th>
						<th class="analytify_txt_center"><?php esc_html_e( 'Date', 'wp-analytify-pro' ); ?></th>
					</tr>
				</thead>
				<tbody>
				<?php if ( ! empty( $orders ) ) : ?>
					<?php
					$i = 0;
					foreach ( $orders as $order ) :
						++$i;
						?>
						<tr>
							<td class="analytify_txt_center"><?php echo esc_html( $i ); ?></td>
							<td class="analytify_txt_center"><?php echo esc_html( $order->id ); ?></td>
							<td class="analytify_txt_center"><?php echo esc_html( $order->member_name ); ?></td>
							<td class="analytify_txt_center"><?php echo esc_html( $order->level_name ); ?></td>
							<td class="analytify_txt_center"><?php echo esc_html( pmpro_formatPrice( (float) $order->total ) ); ?></td>
							<td class="analytify_txt_center"><?php echo esc_html( $order->gateway ); ?></td>
							<td class="analytify_txt_center"><?php echo esc_html( date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), strtotime( $order->timestamp ) ) ); ?></td>
						</tr>
					<?php endforeach; ?>
				<?php else : ?>
					<tr>
						<td class="analytify_td_error_msg" colspan="7">
							<?php echo $current ? wp_kses_post( $current->no_records() ?? '' ) : esc_html__( 'No data available for the selected date range.', 'wp-analytify-pro' ); ?>
						</td>
					</tr>
				<?php endif; ?>
				</tbody>
			</table>
		</div>
	</div>

	<?php
	wp_send_json(
		array(
			'body' => ob_get_clean(),
		)
	);
}
