<?php
/**
 * PMPro Gateways Performance view.
 *
 * @package WP_Analytify_Pro
 * @subpackage PMPro\Views
 * @since 9.0.0
 */

/**
 * Display payment gateway performance.
 *
 * @since 9.0.0
 * @param object $current Current object.
 * @param array  $stats   Statistics data (rows key with gateway rows).
 * @return void
 */
function wpa_pmpro_gateways_performance( $current, $stats ) {
	ob_start();

	$gateways = is_array( $stats ) && isset( $stats['rows'] ) ? $stats['rows'] : array();
	?>
	<div class="analytify_general_status analytify_status_box_wraper">
		<div class="analytify_status_header">
			<h3><?php esc_html_e( 'Payment Gateway Performance', 'wp-analytify-pro' ); ?></h3>
		</div>
		<div class="analytify_status_body">
			<table class="analytify_data_tables wp_analytify_paginated" data-product-per-page="10">
				<thead>
					<tr>
						<th class="analytify_txt_center"><?php esc_html_e( 'Gateway', 'wp-analytify-pro' ); ?></th>
						<th class="analytify_txt_center"><?php esc_html_e( 'Revenue', 'wp-analytify-pro' ); ?></th>
						<th class="analytify_txt_center"><?php esc_html_e( 'Transactions', 'wp-analytify-pro' ); ?></th>
						<th class="analytify_txt_center"><?php esc_html_e( 'Success Rate', 'wp-analytify-pro' ); ?></th>
					</tr>
				</thead>
				<tbody>
				<?php if ( ! empty( $gateways ) ) : ?>
					<?php
					foreach ( $gateways as $gateway ) :
						$gateway_name = isset( $gateway['paymentGateway'] ) ? $gateway['paymentGateway'] : 'Unknown';
						$revenue      = isset( $gateway['purchaseRevenue'] ) ? (float) $gateway['purchaseRevenue'] : 0;
						$transactions = isset( $gateway['transactions'] ) ? (int) $gateway['transactions'] : 0;
						$success_rate = isset( $gateway['successRate'] ) ? (float) $gateway['successRate'] : 0;
						$currency     = isset( $gateway['currencyCode'] ) && '(not set)' !== $gateway['currencyCode'] ? $gateway['currencyCode'] : '';
						?>
						<tr>
							<td class="analytify_txt_center"><?php echo esc_html( $gateway_name ); ?></td>
							<td class="analytify_txt_center"><?php echo esc_html( pmpro_formatPrice( $revenue ) ); ?></td>
							<td class="analytify_txt_center"><?php echo esc_html( number_format( $transactions ) ); ?></td>
							<td class="analytify_txt_center"><?php echo esc_html( $success_rate ); ?>%</td>
						</tr>
					<?php endforeach; ?>
				<?php else : ?>
					<tr>
						<td class="analytify_td_error_msg" colspan="4">
							<?php
							if ( $current && is_callable( array( $current, 'no_records' ) ) ) {
								// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Method returns escaped HTML.
								echo $current->no_records();
							} else {
								esc_html_e( 'No data available for the selected date range.', 'wp-analytify-pro' );
							}
							?>
						</td>
					</tr>
				<?php endif; ?>
				</tbody>
			</table>
		</div>
	</div>
	<?php
	wp_send_json( array( 'body' => ob_get_clean() ) );
}

