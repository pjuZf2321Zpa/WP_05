<?php
/**
 * PMPro Churn Performance view.
 *
 * @package WP_Analytify_Pro
 * @subpackage PMPro\Views
 * @since 9.0.0
 */

/**
 * Display churn & retention statistics.
 *
 * @since 9.0.0
 * @param object $current Current object.
 * @param object $stats   Statistics data.
 * @return void
 */
function wpa_pmpro_churn_performance( $current, $stats ) {
	ob_start();

	$cancelled      = isset( $stats['cancelled'] ) ? (int) $stats['cancelled'] : 0;
	$expired        = isset( $stats['expired'] ) ? (int) $stats['expired'] : 0;
	$upgrades       = isset( $stats['upgrades'] ) ? (int) $stats['upgrades'] : 0;
	$downgrades     = isset( $stats['downgrades'] ) ? (int) $stats['downgrades'] : 0;
	$refunds        = isset( $stats['refunds'] ) ? (int) $stats['refunds'] : 0;
	$refund_revenue = isset( $stats['refund_revenue'] ) ? (float) $stats['refund_revenue'] : 0.0;
	$churn_rate     = isset( $stats['churn_rate'] ) ? (float) $stats['churn_rate'] : 0.0;
	$retention_rate = isset( $stats['retention_rate'] ) ? (float) $stats['retention_rate'] : 0.0;
	?>
	<div class="analytify_general_status analytify_status_box_wraper">
		<div class="analytify_status_header">
			<h3><?php esc_html_e( 'Churn & Retention Analysis', 'wp-analytify-pro' ); ?></h3>
		</div>
		<div class="analytify_status_body">
			<table class="analytify_data_tables">
				<thead>
					<tr>
						<th class="analytify_txt_center"><?php esc_html_e( 'Metric', 'wp-analytify-pro' ); ?></th>
						<th class="analytify_txt_center"><?php esc_html_e( 'Count', 'wp-analytify-pro' ); ?></th>
						<th class="analytify_txt_center"><?php esc_html_e( 'Rate', 'wp-analytify-pro' ); ?></th>
					</tr>
				</thead>
				<tbody>
				<?php if ( $cancelled > 0 || $expired > 0 || $upgrades > 0 || $downgrades > 0 || $refunds > 0 ) : ?>
					<tr>
						<td class="analytify_txt_center"><?php esc_html_e( 'Churn Rate', 'wp-analytify-pro' ); ?></td>
						<td class="analytify_txt_center"><?php echo esc_html( $cancelled + $expired ); ?></td>
						<td class="analytify_txt_center"><?php echo esc_html( $churn_rate ); ?>%</td>
					</tr>
					<tr>
						<td class="analytify_txt_center"><?php esc_html_e( 'Retention Rate', 'wp-analytify-pro' ); ?></td>
						<td class="analytify_txt_center">-</td>
						<td class="analytify_txt_center"><?php echo esc_html( $retention_rate ); ?>%</td>
					</tr>
					<tr>
						<td class="analytify_txt_center"><?php esc_html_e( 'Memberships Cancelled', 'wp-analytify-pro' ); ?></td>
						<td class="analytify_txt_center"><?php echo esc_html( number_format( $cancelled ) ); ?></td>
						<td class="analytify_txt_center">-</td>
					</tr>
					<tr>
						<td class="analytify_txt_center"><?php esc_html_e( 'Memberships Expired', 'wp-analytify-pro' ); ?></td>
						<td class="analytify_txt_center"><?php echo esc_html( number_format( $expired ) ); ?></td>
						<td class="analytify_txt_center">-</td>
					</tr>
					<tr>
						<td class="analytify_txt_center"><?php esc_html_e( 'Refunds', 'wp-analytify-pro' ); ?></td>
						<td class="analytify_txt_center"><?php echo esc_html( number_format( $refunds ) ); ?></td>
						<td class="analytify_txt_center"><?php echo esc_html( number_format( $refund_revenue, 2 ) ); ?></td>
					</tr>
					<tr>
						<td class="analytify_txt_center"><?php esc_html_e( 'Upgrades', 'wp-analytify-pro' ); ?></td>
						<td class="analytify_txt_center"><?php echo esc_html( number_format( $upgrades ) ); ?></td>
						<td class="analytify_txt_center">-</td>
					</tr>
					<tr>
						<td class="analytify_txt_center"><?php esc_html_e( 'Downgrades', 'wp-analytify-pro' ); ?></td>
						<td class="analytify_txt_center"><?php echo esc_html( number_format( $downgrades ) ); ?></td>
						<td class="analytify_txt_center">-</td>
					</tr>
				<?php else : ?>
					<tr>
						<td class="analytify_td_error_msg" colspan="3">
							<?php echo $current ? wp_kses_post( $current->no_records() ?? '' ) : esc_html__( 'No data available for the selected date range.', 'wp-analytify-pro' ); ?>
						</td>
					</tr>
				<?php endif; ?>
				</tbody>
			</table>
		</div>
	</div>
	<?php
	wp_send_json( array( 'body' => ob_get_clean() ) );
}

