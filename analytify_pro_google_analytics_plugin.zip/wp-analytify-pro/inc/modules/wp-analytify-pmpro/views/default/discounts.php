<?php
/**
 * PMPro Discounts Performance view.
 *
 * @package WP_Analytify_Pro
 * @subpackage PMPro\Views
 * @since 9.0.0
 */

/**
 * Display discount codes performance.
 *
 * @since 9.0.0
 * @param object $current Current object.
 * @param object $stats   Statistics data.
 * @return void
 */
function wpa_pmpro_discounts_performance( $current, $stats ) {
	ob_start();

	$discounts = is_array( $stats ) && isset( $stats['rows'] ) ? $stats['rows'] : array();
	?>
	<div class="analytify_general_status analytify_status_box_wraper">
		<div class="analytify_status_header">
			<h3><?php esc_html_e( 'Discount Codes Performance', 'wp-analytify-pro' ); ?></h3>
		</div>
		<div class="analytify_status_body">
			<table class="analytify_data_tables wp_analytify_paginated" data-product-per-page="10">
				<thead>
					<tr>
						<th class="analytify_txt_center"><?php esc_html_e( 'Discount Code', 'wp-analytify-pro' ); ?></th>
						<th class="analytify_txt_center"><?php esc_html_e( 'Revenue', 'wp-analytify-pro' ); ?></th>
						<th class="analytify_txt_center"><?php esc_html_e( 'Times Used', 'wp-analytify-pro' ); ?></th>
					</tr>
				</thead>
				<tbody>
				<?php if ( ! empty( $discounts ) ) : ?>
					<?php
					foreach ( $discounts as $discount ) :
						$code     = isset( $discount['discountCode'] ) ? $discount['discountCode'] : '';
						$revenue  = isset( $discount['purchaseRevenue'] ) ? (float) $discount['purchaseRevenue'] : 0;
						$usage    = isset( $discount['eventCount'] ) ? (int) $discount['eventCount'] : 0;
						$currency = isset( $discount['currencyCode'] ) && '(not set)' !== $discount['currencyCode'] ? $discount['currencyCode'] : '';
						?>
						<tr>
							<td class="analytify_txt_center"><?php echo esc_html( $code ); ?></td>
							<td class="analytify_txt_center"><?php echo esc_html( pmpro_formatPrice( $revenue ) ); ?></td>
							<td class="analytify_txt_center"><?php echo esc_html( number_format( $usage ) ); ?></td>
						</tr>
					<?php endforeach; ?>
				<?php else : ?>
					<tr>
						<td class="analytify_td_error_msg" colspan="3">
							<?php echo $current ? wp_kses_post( $current->no_records() ?? '' ) : esc_html__( 'No data available for the selected date range.', 'wp-analytify-pro' ); ?>
						</td>
					</tr>
				<?php endif; ?>
				</tbody>
			</table>
		</div>
	</div>
	<?php
	wp_send_json( array( 'body' => ob_get_clean() ) );
}

