<?php
/**
 * PMPro Trials Performance view.
 *
 * @package WP_Analytify_Pro
 * @subpackage PMPro\Views
 * @since 9.0.0
 */

/**
 * Display trial conversion statistics.
 *
 * @since 9.0.0
 * @param object $current Current object.
 * @param object $stats   Statistics data.
 * @return void
 */
function wpa_pmpro_trials_performance( $current, $stats ) {
	ob_start();

	$trial_started   = isset( $stats['trial_started'] ) ? (int) $stats['trial_started'] : 0;
	$trial_converted = isset( $stats['trial_converted'] ) ? (int) $stats['trial_converted'] : 0;
	$trial_expired   = isset( $stats['trial_expired'] ) ? (int) $stats['trial_expired'] : 0;
	$conversion_rate = isset( $stats['conversion_rate'] ) ? (float) $stats['conversion_rate'] : 0.0;
	?>
	<div class="analytify_general_status analytify_status_box_wraper">
		<div class="analytify_status_header">
			<h3><?php esc_html_e( 'Trial Conversion Statistics', 'wp-analytify-pro' ); ?></h3>
		</div>
		<div class="analytify_status_body">
			<table class="analytify_data_tables">
				<thead>
					<tr>
						<th class="analytify_txt_center"><?php esc_html_e( 'Metric', 'wp-analytify-pro' ); ?></th>
						<th class="analytify_txt_center"><?php esc_html_e( 'Count', 'wp-analytify-pro' ); ?></th>
						<th class="analytify_txt_center"><?php esc_html_e( 'Percentage', 'wp-analytify-pro' ); ?></th>
					</tr>
				</thead>
				<tbody>
				<?php if ( $trial_started > 0 || $trial_converted > 0 || $trial_expired > 0 ) : ?>
					<tr>
						<td class="analytify_txt_center"><?php esc_html_e( 'Trials Started', 'wp-analytify-pro' ); ?></td>
						<td class="analytify_txt_center"><?php echo esc_html( number_format( $trial_started ) ); ?></td>
						<td class="analytify_txt_center">100%</td>
					</tr>
					<tr>
						<td class="analytify_txt_center"><?php esc_html_e( 'Trials Converted', 'wp-analytify-pro' ); ?></td>
						<td class="analytify_txt_center"><?php echo esc_html( number_format( $trial_converted ) ); ?></td>
						<td class="analytify_txt_center"><?php echo esc_html( $conversion_rate ); ?>%</td>
					</tr>
					<tr>
						<td class="analytify_txt_center"><?php esc_html_e( 'Trials Expired', 'wp-analytify-pro' ); ?></td>
						<td class="analytify_txt_center"><?php echo esc_html( number_format( $trial_expired ) ); ?></td>
						<td class="analytify_txt_center"><?php echo $trial_started > 0 ? esc_html( round( ( $trial_expired / $trial_started ) * 100, 2 ) ) : '0'; ?>%</td>
					</tr>
				<?php else : ?>
					<tr>
						<td class="analytify_td_error_msg" colspan="3">
							<?php echo $current ? wp_kses_post( $current->no_records() ?? '' ) : esc_html__( 'No data available for the selected date range.', 'wp-analytify-pro' ); ?>
						</td>
					</tr>
				<?php endif; ?>
				</tbody>
			</table>
		</div>
	</div>
	<?php
	wp_send_json( array( 'body' => ob_get_clean() ) );
}

