<?php
/**
 * PMPro Revenue Breakdown view.
 *
 * @package WP_Analytify_Pro
 * @subpackage PMPro\Views
 * @since 9.0.0
 */

/**
 * Display revenue breakdown (recurring vs one-time).
 *
 * @since 9.0.0
 * @param object $current Current object.
 * @param object $stats   Statistics data.
 * @return void
 */
function wpa_pmpro_revenue_breakdown( $current, $stats ) {
	ob_start();

	$recurring_revenue    = isset( $stats['recurring_revenue'] ) ? (float) $stats['recurring_revenue'] : 0.0;
	$one_time_revenue     = isset( $stats['one_time_revenue'] ) ? (float) $stats['one_time_revenue'] : 0.0;
	$total_revenue        = isset( $stats['total_revenue'] ) ? (float) $stats['total_revenue'] : 0.0;
	$recurring_percentage = isset( $stats['recurring_percentage'] ) ? (float) $stats['recurring_percentage'] : 0.0;
	$one_time_percentage  = 100 - $recurring_percentage;
	?>
	<div class="analytify_general_status analytify_status_box_wraper">
		<div class="analytify_status_header">
			<h3><?php esc_html_e( 'Revenue Breakdown', 'wp-analytify-pro' ); ?></h3>
		</div>
		<div class="analytify_status_body">
			<table class="analytify_data_tables">
				<thead>
					<tr>
						<th class="analytify_txt_center"><?php esc_html_e( 'Revenue Type', 'wp-analytify-pro' ); ?></th>
						<th class="analytify_txt_center"><?php esc_html_e( 'Amount', 'wp-analytify-pro' ); ?></th>
						<th class="analytify_txt_center"><?php esc_html_e( 'Percentage', 'wp-analytify-pro' ); ?></th>
					</tr>
				</thead>
				<tbody>
				<?php if ( $total_revenue > 0 ) : ?>
					<tr>
						<td class="analytify_txt_center"><?php esc_html_e( 'Recurring Revenue', 'wp-analytify-pro' ); ?></td>
						<td class="analytify_txt_center"><?php echo esc_html( pmpro_formatPrice( $recurring_revenue ) ); ?></td>
						<td class="analytify_txt_center"><?php echo esc_html( $recurring_percentage ); ?>%</td>
					</tr>
					<tr>
						<td class="analytify_txt_center"><?php esc_html_e( 'One-Time Revenue', 'wp-analytify-pro' ); ?></td>
						<td class="analytify_txt_center"><?php echo esc_html( pmpro_formatPrice( $one_time_revenue ) ); ?></td>
						<td class="analytify_txt_center"><?php echo esc_html( $one_time_percentage ); ?>%</td>
					</tr>
					<tr>
						<td class="analytify_txt_center"><strong><?php esc_html_e( 'Total Revenue', 'wp-analytify-pro' ); ?></strong></td>
						<td class="analytify_txt_center"><strong><?php echo esc_html( pmpro_formatPrice( $total_revenue ) ); ?></strong></td>
						<td class="analytify_txt_center"><strong>100%</strong></td>
					</tr>
				<?php else : ?>
					<tr>
						<td class="analytify_td_error_msg" colspan="3">
							<?php echo $current ? wp_kses_post( $current->no_records() ?? '' ) : esc_html__( 'No data available for the selected date range.', 'wp-analytify-pro' ); ?>
						</td>
					</tr>
				<?php endif; ?>
				</tbody>
			</table>
		</div>
	</div>
	<?php
	wp_send_json( array( 'body' => ob_get_clean() ) );
}

