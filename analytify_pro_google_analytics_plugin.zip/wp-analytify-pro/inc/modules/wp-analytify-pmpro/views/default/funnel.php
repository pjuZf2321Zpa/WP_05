<?php
/**
 * PMPro Funnel Chart view.
 *
 * @package WP_Analytify_Pro
 * @subpackage PMPro\Views
 * @since 9.0.0
 */

/**
 * Display PMPro funnel chart.
 *
 * @since 9.0.0
 * @param object $current Current object (WP_ANALYTIFY).
 * @param array  $stats   Statistics data (e.g. [ 'rows' => [ [ 'pageViews' => n, 'eventCount' => n, 'transactions' => n ] ] ]).
 * @return void
 */
function wpa_pmpro_funnel_chart( $current, $stats ) {

	$viewed    = 0;
	$checkouts = 0;
	$purchased = 0;

	if ( ! empty( $stats['rows'] ) ) {
		foreach ( $stats['rows'] as $stat ) {
			$viewed    = isset( $stat['pageViews'] ) ? (int) $stat['pageViews'] : 0;
			$checkouts = isset( $stat['eventCount'] ) ? (int) $stat['eventCount'] : 0;
			$purchased = isset( $stat['purchaseRevenue'] ) ? (int) $stat['purchaseRevenue'] : 0;

			// Get checkout events count.
			if ( isset( $stat['checkouts'] ) ) {
				$checkouts = (int) $stat['checkouts'];
			}

			// Get purchase events count.
			if ( isset( $stat['transactions'] ) ) {
				$purchased = (int) $stat['transactions'];
			}
		}
	} elseif ( isset( $stats['aggregations'] ) ) {
		// Try to get data from aggregations if available.
		$viewed    = isset( $stats['aggregations']['screenPageViews'] ) ? (int) $stats['aggregations']['screenPageViews'] : 0;
		$checkouts = isset( $stats['aggregations']['eventCount'] ) ? (int) $stats['aggregations']['eventCount'] : 0;
		$purchased = isset( $stats['aggregations']['transactions'] ) ? (int) $stats['aggregations']['transactions'] : 0;
	}

	// Always prepare data for the funnel chart (even with 0 values).
	$data = array(
		array(
			'value'     => 1500,
			'name'      => 'View Level',
			'itemStyle' => array( 'color' => '#f5a623' ),
			'actual'    => $viewed,
		),
		array(
			'value'     => 1000,
			'name'      => 'Checkout',
			'itemStyle' => array( 'color' => '#7ed321' ),
			'actual'    => $checkouts,
		),
		array(
			'value'     => 500,
			'name'      => 'Purchase',
			'itemStyle' => array( 'color' => '#4a90e2' ),
			'actual'    => $purchased,
		),
	);

	// Calculate conversion and abandonment rates by stages.
	$conversion_rates = array(
		'View to Checkout'     => ( $viewed > 0 ) ? round( ( $checkouts / $viewed ) * 100, 2 ) : 0,
		'Checkout to Purchase' => ( $checkouts > 0 ) ? round( ( $purchased / $checkouts ) * 100, 2 ) : 0,
	);

	$abandonment_rates = array(
		'View Abandonment'     => ( $viewed > 0 ) ? round( ( ( $viewed - $checkouts ) / $viewed ) * 100, 2 ) : 0,
		'Checkout Abandonment' => ( $checkouts > 0 ) ? round( ( ( $checkouts - $purchased ) / $checkouts ) * 100, 2 ) : 0,
	);

	?>

	<div class="analytify_general_status analytify_status_box_wraper">
		<div class="analytify_status_header">
			<h3><?php esc_html_e( 'PMPro Funnel', 'wp-analytify-pro' ); ?></h3>
		</div>

		<table class="analytify_data_tables">
			<thead>
				<tr>
					<th class="no-header"></th>
					<th class="right-align header-center">
						<?php esc_html_e( 'Conversion Rate by Stages', 'wp-analytify-pro' ); ?>
					</th>
					<th class="right-align header-center">
						<?php esc_html_e( 'Abandonment Rate', 'wp-analytify-pro' ); ?>
					</th>
				</tr>
			</thead>
		</table>

		<div class="analytify_status_body">
			<div class="funnel-wrapper">
				<div class="analytify-funnel-chart-container">
					<div class="analytify-funnel-chart">
						<div id="analytify-pmpro-funnel-chart"></div>
					</div>

					<div class="conversion-rates">
						<p class="view-conversion"><?php echo esc_html( $conversion_rates['View to Checkout'] ); ?>%</p>
						<p class="cart-conversion"><?php echo esc_html( $conversion_rates['Checkout to Purchase'] ); ?>%</p>
					</div>

					<div class="abandonment-rates">
						<p><?php echo esc_html( $abandonment_rates['View Abandonment'] ); ?>%</p>
						<p><?php echo esc_html( $abandonment_rates['Checkout Abandonment'] ); ?>%</p>
					</div>
				</div>
			</div>
		</div>
	</div>

	<?php
	// Chart init and data are enqueued via wp_add_inline_script and wp_localize_script in the addon.
}

