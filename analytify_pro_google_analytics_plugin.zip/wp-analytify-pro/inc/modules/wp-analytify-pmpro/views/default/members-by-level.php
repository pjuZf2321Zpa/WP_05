<?php
/**
 * PMPro Members by Level view.
 *
 * @package WP_Analytify_Pro
 * @subpackage PMPro\Views
 * @since 9.0.0
 */

/**
 * Display members by membership level.
 *
 * @since 9.0.0
 * @param object $current      Current object.
 * @param array  $member_stats Member statistics.
 * @return void
 */
function wpa_pmpro_members_by_level( $current, $member_stats ) {
	ob_start();

	$levels = is_array( $member_stats ) && isset( $member_stats['members_by_level'] )
		? $member_stats['members_by_level']
		: $member_stats;
	?>
	<div class="analytify_general_status analytify_status_box_wraper">
		<div class="analytify_status_header">
			<h3><?php esc_html_e( 'Members by Level', 'wp-analytify-pro' ); ?></h3>
		</div>
		<div class="analytify_status_body">
			<table class="analytify_data_tables wp_analytify_paginated" data-product-per-page="10">
				<thead>
					<tr>
						<th class="analytify_txt_center"><?php esc_html_e( 'Level', 'wp-analytify-pro' ); ?></th>
						<th class="analytify_txt_center"><?php esc_html_e( 'Members', 'wp-analytify-pro' ); ?></th>
					</tr>
				</thead>
				<tbody>
				<?php if ( ! empty( $levels ) ) : ?>
					<?php
					foreach ( $levels as $level ) :
						$name  = is_array( $level ) ? ( $level['level_name'] ?? '' ) : ( $level->level_name ?? '' );
						$count = is_array( $level ) ? ( $level['member_count'] ?? 0 ) : ( $level->member_count ?? 0 );
						?>
						<tr>
							<td class="analytify_txt_center"><?php echo esc_html( $name ); ?></td>
							<td class="analytify_txt_center"><?php echo esc_html( number_format( (int) $count ) ); ?></td>
						</tr>
					<?php endforeach; ?>
				<?php else : ?>
					<tr>
						<td class="analytify_td_error_msg" colspan="2">
							<?php echo $current ? wp_kses_post( $current->no_records() ?? '' ) : esc_html__( 'No data available for the selected date range.', 'wp-analytify-pro' ); ?>
						</td>
					</tr>
				<?php endif; ?>
				</tbody>
			</table>
		</div>
	</div>
	<?php
	wp_send_json( array( 'body' => ob_get_clean() ) );
}
