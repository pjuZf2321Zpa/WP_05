<?php
/**
 * PMPro Levels Performance view.
 *
 * @package WP_Analytify_Pro
 * @subpackage PMPro\Views
 * @since 9.0.0
 */

/**
 * Display revenue by membership level.
 *
 * @since 9.0.0
 * @param object $current        Current object.
 * @param array  $revenue_stats Revenue statistics.
 * @return void
 */
function wpa_pmpro_levels_performance( $current, $revenue_stats ) {
	ob_start();

	$levels = is_array( $revenue_stats ) && isset( $revenue_stats['revenue_by_level'] )
		? $revenue_stats['revenue_by_level']
		: $revenue_stats;
	?>
	<div class="analytify_general_status analytify_status_box_wraper">
		<div class="analytify_status_header">
			<h3><?php esc_html_e( 'Revenue by Membership Level', 'wp-analytify-pro' ); ?></h3>
		</div>
		<div class="analytify_status_body">
			<table class="analytify_data_tables wp_analytify_paginated" data-product-per-page="10">
				<thead>
					<tr>
						<th class="analytify_txt_center"><?php esc_html_e( 'Level', 'wp-analytify-pro' ); ?></th>
						<th class="analytify_txt_center"><?php esc_html_e( 'Revenue', 'wp-analytify-pro' ); ?></th>
					</tr>
				</thead>
				<tbody>
				<?php if ( ! empty( $levels ) ) : ?>
					<?php
					foreach ( $levels as $level ) :
						$name    = is_array( $level ) ? ( $level['level_name'] ?? '' ) : ( $level->level_name ?? '' );
						$revenue = is_array( $level ) ? ( $level['revenue'] ?? 0 ) : ( $level->revenue ?? 0 );
						?>
						<tr>
							<td class="analytify_txt_center"><?php echo esc_html( $name ); ?></td>
							<td class="analytify_txt_center"><?php echo esc_html( pmpro_formatPrice( (float) $revenue ) ); ?></td>
						</tr>
					<?php endforeach; ?>
				<?php else : ?>
					<tr>
						<td class="analytify_td_error_msg" colspan="2">
							<?php echo $current ? wp_kses_post( $current->no_records() ?? '' ) : esc_html__( 'No data available for the selected date range.', 'wp-analytify-pro' ); ?>
						</td>
					</tr>
				<?php endif; ?>
				</tbody>
			</table>
		</div>
	</div>
	<?php
	wp_send_json( array( 'body' => ob_get_clean() ) );
}
