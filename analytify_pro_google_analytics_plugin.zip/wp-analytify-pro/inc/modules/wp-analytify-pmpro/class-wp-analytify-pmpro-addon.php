<?php
/**
 * Paid Memberships Pro integration for Analytify Pro.
 *
 * Dashboard, tracking, and REST stats for PMPro. Public methods use the wpa_ prefix.
 *
 * @package    WP_Analytify_Pro
 * @subpackage PMPro
 * @since      9.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * WP_Analytify_PMPro_Addon class.
 *
 * Core addon for PMPro analytics: menu, settings, event tracking, and wpa_ prefixed callbacks.
 *
 * @since 9.0.0
 */
class WP_Analytify_PMPro_Addon extends WP_Analytify_Pro_Base {

	use Analytify_PMPro_Tracking_Trait;
	use Analytify_PMPro_Dashboard_Data_Trait;
	use Analytify_PMPro_Settings_Trait;

	/**
	 * The single instance of the class.
	 *
	 * @var WP_Analytify_PMPro_Addon
	 */
	public static $instance;

	/**
	 * Get the singleton instance.
	 *
	 * @since 9.0.0
	 * @return WP_Analytify_PMPro_Addon
	 */
	public static function wpa_pmpro_instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 *
	 * @since 9.0.0
	 */
	public function __construct() {
		$this->wpa_pmpro_define_constants();
		$this->wpa_pmpro_includes();
		$this->wpa_pmpro_hooks();
	}

	/**
	 * Define constants.
	 *
	 * @since 9.0.0
	 */
	public function wpa_pmpro_define_constants() {
		define( 'PMPRO_ANALYTIFY_PLUGIN_DIR', ANALYTIFY_PRO_PMPRO_ADDON_ROOT_PATH );
		define( 'PMPRO_ANALYTIFY_PLUGIN_URL', plugins_url( '', __FILE__ ) );
	}

	/**
	 * Include required files.
	 *
	 * @since 9.0.0
	 */
	public function wpa_pmpro_includes() {
		$dir = PMPRO_ANALYTIFY_PLUGIN_DIR;
		require_once $dir . '/classes/class-analytify-pmpro-tracking-trait.php';
		require_once $dir . '/classes/class-analytify-pmpro-dashboard-data-trait.php';
		require_once $dir . '/classes/class-analytify-pmpro-settings-trait.php';
		if ( file_exists( $dir . '/classes/class-analytify-pmpro-rest-api.php' ) ) {
			include_once $dir . '/classes/class-analytify-pmpro-rest-api.php';
		}
	}

	/**
	 * Setup hooks.
	 *
	 * @since 9.0.0
	 */
	public function wpa_pmpro_hooks() {
		// Add PMPro submenu page.
		add_action( 'analytify_add_submenu', array( $this, 'wpa_add_menu' ), 10 );
		// Add PMPro menu to Analytify dashboard.
		add_filter( 'analytify_dashboard_dropdown_options', array( $this, 'wpa_add_pmpro_menu_option' ) );
		// Add PMPro stats to email reports.
		add_filter( 'analytify_email_stats_options', array( $this, 'wpa_add_pmpro_email_stats' ) );
		// Add PMPro admin bar menu.
		add_action( 'admin_bar_menu', array( $this, 'wpa_add_pmpro_admin_bar_menu' ), 100 );
		// Track PMPro events (GA4 Measurement Protocol).
		add_action( 'pmpro_after_checkout', array( $this, 'wpa_pmpro_after_checkout' ), 10, 2 );
		add_action( 'pmpro_after_change_membership_level', array( $this, 'wpa_pmpro_change_membership_level' ), 10, 3 );
		add_action( 'pmpro_membership_post_membership_expired', array( $this, 'wpa_pmpro_membership_expired' ), 10, 2 );
		add_action( 'pmpro_membership_pre_membership_expiry', array( $this, 'wpa_pmpro_membership_renewal_notice' ), 10, 2 );
		add_action( 'pmpro_after_change_membership_level', array( $this, 'wpa_pmpro_membership_cancelled' ), 10, 3 );
		add_action( 'pmpro_subscription_payment_failed', array( $this, 'wpa_pmpro_payment_failed' ), 10, 2 );
		add_action( 'pmpro_subscription_payment_completed', array( $this, 'wpa_pmpro_subscription_payment_completed' ), 10, 1 );
		add_action( 'pmpro_order_status_refunded', array( $this, 'wpa_pmpro_order_refunded' ), 10, 2 );
		// Track order status changes (for manual payments and status updates).
		add_action( 'pmpro_order_status_success', array( $this, 'wpa_pmpro_order_status_success' ), 10, 2 );
		add_action( 'pmpro_order_status_error', array( $this, 'wpa_pmpro_order_status_error' ), 10, 2 );
		add_action( 'pmpro_order_status_pending', array( $this, 'wpa_pmpro_order_status_pending' ), 10, 2 );
		// Add PMPro reports to dashboard.
		add_action( 'wp_ajax_analytify_get_pmpro_stats', array( $this, 'wpa_get_pmpro_stats' ) );
		// Add PMPro settings.
		add_filter( 'analytify_pro_settings', array( $this, 'wpa_add_pmpro_settings' ) );
		// Handle module activation/deactivation redirects.
		add_action( 'admin_init', array( $this, 'wpa_modules_fallback_page' ) );
		// Admin styles for PMPro dashboard.
		add_action( 'admin_enqueue_scripts', array( $this, 'wpa_enqueue_admin_styles' ) );
		// Admin settings.
		add_filter( 'analytify_settings_addon_tabs', array( $this, 'wpa_pmpro_settings_tab' ) );
		add_action( 'analytify_settings_addon_tab_content', array( $this, 'wpa_pmpro_settings_content' ) );
	}

	/**
	 * Add menu for PMPro dashboard page.
	 *
	 * @since 9.0.0
	 * @return void
	 */
	public static function wpa_add_menu() {
		add_submenu_page(
			'analytify-dashboard',
			__( 'Track everything in Paid Memberships Pro with Analytify.', 'wp-analytify-pro' ),
			__( 'PMPro', 'wp-analytify-pro' ),
			'manage_options',
			'analytify-pmpro',
			array( __CLASS__, 'wpa_pmpro_page_file_path' ),
			15
		);
	}

	/**
	 * Include file for PMPro dashboard page.
	 *
	 * @since 9.0.0
	 * @return void
	 */
	public static function wpa_pmpro_page_file_path() {
		$screen = get_current_screen();

		if ( $screen && strpos( $screen->base, 'analytify-pmpro' ) !== false ) {
			$plugin_dir = defined( 'PMPRO_ANALYTIFY_PLUGIN_DIR' ) ? PMPRO_ANALYTIFY_PLUGIN_DIR : __DIR__;
			include $plugin_dir . '/includes/pmpro-dashboard.php';
		}
	}

	/**
	 * Enqueue admin styles and dashboard script for PMPro dashboard.
	 *
	 * @since 9.0.0
	 * @param string $hook Current admin page hook.
	 * @return void
	 */
	public function wpa_enqueue_admin_styles( $hook ) {
		// Only load on PMPro dashboard page.
		if ( strpos( $hook, 'analytify-pmpro' ) === false ) {
			return;
		}

		$plugin_url = defined( 'PMPRO_ANALYTIFY_PLUGIN_URL' ) ? PMPRO_ANALYTIFY_PLUGIN_URL : plugins_url( '', __FILE__ );

		wp_enqueue_style(
			'analytify-pmpro-funnel',
			$plugin_url . '/assets/css/funnel' . analytify_pro_get_asset_suffix() . '.css',
			array(),
			ANALYTIFY_PRO_VERSION
		);

		// Dashboard report script with localized data and inline fetch logic.
		$start_date = $this->wpa_pmpro_get_dashboard_dates( 'start_date' );
		$end_date   = $this->wpa_pmpro_get_dashboard_dates( 'end_date' );
		$error_msg  = __( 'Something unexpected occurred.', 'wp-analytify-pro' );

		wp_register_script(
			'analytify-pmpro-dashboard',
			false,
			array( 'jquery' ),
			ANALYTIFY_PRO_VERSION,
			true
		);
		wp_localize_script(
			'analytify-pmpro-dashboard',
			'analytify_pmpro_dashboard',
			array(
				'rest_url_stats'             => esc_url_raw( rest_url( 'analytify/v1/pmpro/stats' ) ),
				'rest_url_orders'            => esc_url_raw( rest_url( 'analytify/v1/pmpro/orders' ) ),
				'rest_url_revenue'           => esc_url_raw( rest_url( 'analytify/v1/pmpro/revenue' ) ),
				'rest_url_members'           => esc_url_raw( rest_url( 'analytify/v1/pmpro/members' ) ),
				'rest_url_discounts'         => esc_url_raw( rest_url( 'analytify/v1/pmpro/discounts' ) ),
				'rest_url_trials'            => esc_url_raw( rest_url( 'analytify/v1/pmpro/trials' ) ),
				'rest_url_churn'             => esc_url_raw( rest_url( 'analytify/v1/pmpro/churn' ) ),
				'rest_url_gateways'          => esc_url_raw( rest_url( 'analytify/v1/pmpro/gateways' ) ),
				'rest_url_revenue_breakdown' => esc_url_raw( rest_url( 'analytify/v1/pmpro/revenue-breakdown' ) ),
				'nonce'                      => wp_create_nonce( 'wp_rest' ),
				'start_date'                 => $start_date,
				'end_date'                   => $end_date,
				'error_message'              => $error_msg,
			)
		);
		$inline_js = $this->wpa_pmpro_dashboard_inline_script();
		wp_add_inline_script( 'analytify-pmpro-dashboard', $inline_js, 'after' );
		wp_enqueue_script( 'analytify-pmpro-dashboard' );

		// Funnel chart: enqueue script with localized data and inline init (no inline script in view).
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Display only, no data modification.
		if ( ! isset( $_GET['cn'] ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() && ! empty( $GLOBALS['WP_ANALYTIFY'] ) ) {
			$wp_analytify   = $GLOBALS['WP_ANALYTIFY'];
			$funnel_stats   = $wp_analytify->get_reports(
				'show-pmpro-funnel-chart',
				array( 'screenPageViews', 'eventCount', 'transactions' ),
				array(
					'start' => $start_date,
					'end'   => $end_date,
				),
				array( 'pagePath' ),
				array(
					'type'  => 'metric',
					'name'  => 'screenPageViews',
					'order' => 'desc',
				),
				array(
					'logic'   => 'OR',
					'filters' => array(
						array(
							'type'       => 'dimension',
							'name'       => 'pagePath',
							'match_type' => 4,
							'value'      => '/membership',
						),
						array(
							'type'       => 'dimension',
							'name'       => 'pagePath',
							'match_type' => 4,
							'value'      => '/membership-levels',
						),
					),
				),
				10
			);
			$checkout_stats = $wp_analytify->get_reports(
				'show-pmpro-checkout-events',
				array( 'eventCount' ),
				array(
					'start' => $start_date,
					'end'   => $end_date,
				),
				array( 'eventName' ),
				array(),
				array(
					'logic'   => 'AND',
					'filters' => array(
						array(
							'type'       => 'dimension',
							'name'       => 'eventName',
							'match_type' => 1,
							'value'      => 'wpa_pmpro_checkout',
						),
					),
				),
				10
			);
			$purchase_stats = $wp_analytify->get_reports(
				'show-pmpro-purchase-events',
				array( 'transactions' ),
				array(
					'start' => $start_date,
					'end'   => $end_date,
				),
				array( 'eventName' ),
				array(),
				array(
					'logic'   => 'AND',
					'filters' => array(
						array(
							'type'       => 'dimension',
							'name'       => 'eventName',
							'match_type' => 1,
							'value'      => 'purchase',
						),
					),
				),
				10
			);
			$viewed         = isset( $funnel_stats['aggregations']['screenPageViews'] ) ? (int) $funnel_stats['aggregations']['screenPageViews'] : 0;
			$checkouts      = isset( $checkout_stats['aggregations']['eventCount'] ) ? (int) $checkout_stats['aggregations']['eventCount'] : 0;
			$purchased      = isset( $purchase_stats['aggregations']['transactions'] ) ? (int) $purchase_stats['aggregations']['transactions'] : 0;
			$funnel_data    = array(
				array(
					'value'     => 1500,
					'name'      => 'View Level',
					'itemStyle' => array( 'color' => '#f5a623' ),
					'actual'    => $viewed,
				),
				array(
					'value'     => 1000,
					'name'      => 'Checkout',
					'itemStyle' => array( 'color' => '#7ed321' ),
					'actual'    => $checkouts,
				),
				array(
					'value'     => 500,
					'name'      => 'Purchase',
					'itemStyle' => array( 'color' => '#4a90e2' ),
					'actual'    => $purchased,
				),
			);
			wp_register_script( 'analytify-pmpro-funnel-chart', false, array( 'jquery' ), ANALYTIFY_PRO_VERSION, true );
			wp_localize_script( 'analytify-pmpro-funnel-chart', 'analytify_pmpro_funnel_data', array( 'data' => $funnel_data ) );
			$funnel_inline = "document.addEventListener('DOMContentLoaded', function() {\n\tif (typeof echarts === 'undefined') return;\n\tvar el = document.getElementById('analytify-pmpro-funnel-chart');\n\tif (!el) return;\n\tvar chart = echarts.init(el);\n\tvar funnelData = (typeof analytify_pmpro_funnel_data !== 'undefined' && analytify_pmpro_funnel_data.data) ? analytify_pmpro_funnel_data.data : [];\n\tvar option = { series: [{ name: 'Conversion Rate', type: 'funnel', left: '10%', top: 20, bottom: 20, width: '80%', min: 0, max: 1500, minSize: '0%', maxSize: '100%', sort: 'descending', gap: 10, label: { show: true, position: 'inside', formatter: function(params) { return params.name + '\\n' + (params.data && params.data.actual !== undefined ? params.data.actual : ''); }, color: '#fff', fontSize: 17 }, labelLine: { show: true, length: 30, lineStyle: { type: 'dashed', color: '#aaa' } }, itemStyle: { borderColor: '#fff', borderWidth: 2, borderRadius: 8 }, emphasis: { label: { fontSize: 19 } }, data: funnelData }] };\n\tchart.setOption(option);\n\twindow.addEventListener('resize', function() { chart.resize(); });\n});";
			wp_add_inline_script( 'analytify-pmpro-funnel-chart', $funnel_inline, 'after' );
			wp_enqueue_script( 'analytify-pmpro-funnel-chart' );
		}
	}

	/**
	 * Get start or end date for dashboard (same logic as pmpro-dashboard template).
	 *
	 * @since 9.0.0
	 * @param string $which 'start_date' or 'end_date'.
	 * @return string Y-m-d date.
	 */
	public function wpa_pmpro_get_dashboard_dates( $which = 'start_date' ) {
		if ( function_exists( 'analytify_datepicker_dates' ) ) {
			$date_data = analytify_datepicker_dates();
			$start     = isset( $date_data['start_date'] ) ? sanitize_text_field( $date_data['start_date'] ) : wp_date( 'Y-m-d', strtotime( '-1 month' ) );
			$end       = isset( $date_data['end_date'] ) ? sanitize_text_field( $date_data['end_date'] ) : wp_date( 'Y-m-d', strtotime( 'now' ) );
		} else {
			$start = wp_date( 'Y-m-d', strtotime( '-1 month' ) );
			$end   = wp_date( 'Y-m-d', strtotime( 'now' ) );
		}
		return 'end_date' === $which ? $end : $start;
	}

	/**
	 * Build inline JS for dashboard report fetching (all 9 report blocks).
	 *
	 * @since 9.0.0
	 * @return string JavaScript source.
	 */
	public function wpa_pmpro_dashboard_inline_script() {
		$err = '<table class="analytify_data_tables analytify_no_header_table"><tbody><tr><td class="analytify_td_error_msg"><div class="analytify-stats-error-msg"><div class="wpb-error-box"><span class="blk"><span class="line"></span><span class="dot"></span></span><span class="information-txt">' . esc_html( __( 'Something unexpected occurred.', 'wp-analytify-pro' ) ) . '</span></div></div></td></tr></tbody></table>';
		return sprintf(
			"jQuery(function($) {
				var d = typeof analytify_pmpro_dashboard !== 'undefined' ? analytify_pmpro_dashboard : {};
				var errHtml = %s;
				function fail(sel) { $(sel).html(errHtml).parent().removeClass('stats_loading'); }
				function done(sel, body) { $(sel).append(body).parent().removeClass('stats_loading'); if (typeof wp_analytify_paginated === 'function') wp_analytify_paginated(); }
				function xhrNonce(xhr) { if (d.nonce) xhr.setRequestHeader('X-WP-Nonce', d.nonce); }
				if (d.rest_url_stats) {
					$.ajax({ url: d.rest_url_stats, data: { start_date: d.start_date, end_date: d.end_date }, beforeSend: xhrNonce }).fail(function() { fail('.pmpro-general-stats-report'); }).done(function(r) { done('.pmpro-general-stats-report', r.body); });
				}
				if (d.rest_url_orders) {
					$.ajax({ url: d.rest_url_orders, data: { limit: 10, start_date: d.start_date, end_date: d.end_date }, beforeSend: xhrNonce }).fail(function() { fail('.pmpro-recent-orders-report'); }).done(function(r) { done('.pmpro-recent-orders-report', r.body); });
				}
				if (d.rest_url_revenue) {
					$.ajax({ url: d.rest_url_revenue, data: { start_date: d.start_date, end_date: d.end_date }, beforeSend: xhrNonce }).fail(function() { fail('.pmpro-revenue-by-level-report'); }).done(function(r) { done('.pmpro-revenue-by-level-report', r.body); });
				}
				if (d.rest_url_members) {
					$.ajax({ url: d.rest_url_members, data: { start_date: d.start_date, end_date: d.end_date }, beforeSend: xhrNonce }).fail(function() { fail('.pmpro-members-by-level-report'); }).done(function(r) { done('.pmpro-members-by-level-report', r.body); });
				}
				if (d.rest_url_discounts) {
					$.ajax({ url: d.rest_url_discounts, data: { start_date: d.start_date, end_date: d.end_date }, beforeSend: xhrNonce }).fail(function() { fail('.pmpro-discounts-report'); }).done(function(r) { done('.pmpro-discounts-report', r.body); });
				}
				if (d.rest_url_trials) {
					$.ajax({ url: d.rest_url_trials, data: { start_date: d.start_date, end_date: d.end_date }, beforeSend: xhrNonce }).fail(function() { fail('.pmpro-trials-report'); }).done(function(r) { done('.pmpro-trials-report', r.body); });
				}
				if (d.rest_url_churn) {
					$.ajax({ url: d.rest_url_churn, data: { start_date: d.start_date, end_date: d.end_date }, beforeSend: xhrNonce }).fail(function() { fail('.pmpro-churn-report'); }).done(function(r) { done('.pmpro-churn-report', r.body); });
				}
				if (d.rest_url_gateways) {
					$.ajax({ url: d.rest_url_gateways, data: { start_date: d.start_date, end_date: d.end_date }, beforeSend: xhrNonce }).fail(function() { fail('.pmpro-gateways-report'); }).done(function(r) { done('.pmpro-gateways-report', r.body); });
				}
				if (d.rest_url_revenue_breakdown) {
					$.ajax({ url: d.rest_url_revenue_breakdown, data: { start_date: d.start_date, end_date: d.end_date }, beforeSend: xhrNonce }).fail(function() { fail('.pmpro-revenue-breakdown-report'); }).done(function(r) { done('.pmpro-revenue-breakdown-report', r.body); });
				}
			});",
			wp_json_encode( $err )
		);
	}

	/**
	 * Add PMPro menu option to dashboard dropdown.
	 *
	 * @since 9.0.0
	 * @param array $options Menu options.
	 * @return array
	 */
	public function wpa_add_pmpro_menu_option( $options ) {
		$options['pmpro'] = __( 'Paid Memberships Pro', 'wp-analytify-pro' );
		return $options;
	}

	/**
	 * Add PMPro stats to email reports.
	 *
	 * @since 9.0.0
	 * @param array $options Email stats options.
	 * @return array
	 */
	public function wpa_add_pmpro_email_stats( $options ) {
		$options['pmpro'] = __( 'Paid Memberships Pro Stats', 'wp-analytify-pro' );
		return $options;
	}

	/**
	 * Add PMPro admin bar menu.
	 *
	 * @param WP_Admin_Bar $wp_admin_bar Admin bar object.
	 */
	public function wpa_add_pmpro_admin_bar_menu( $wp_admin_bar ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$wp_admin_bar->add_menu(
			array(
				'id'    => 'analytify-pmpro',
				'title' => __( 'PMPro Analytics', 'wp-analytify-pro' ),
				'href'  => admin_url( 'admin.php?page=analytify-pmpro' ),
			)
		);
	}

	/**
	 * Handle module activation/deactivation redirects.
	 *
	 * @since 9.0.0
	 * @return void
	 */
	public function wpa_modules_fallback_page() {
		$wp_analytify_modules = get_option( 'wp_analytify_modules' );
		$query_string         = isset( $_SERVER['QUERY_STRING'] ) ? sanitize_text_field( wp_unslash( $_SERVER['QUERY_STRING'] ) ) : '';

		if ( $wp_analytify_modules && 'page=analytify-pmpro' === $query_string ) {
			// Check if PMPro module is specifically active.
			$pmpro_module_active = false;
			foreach ( $wp_analytify_modules as $module ) {
				if ( isset( $module['slug'] ) && 'wp-analytify-pmpro' === $module['slug'] && 'active' === $module['status'] ) {
					$pmpro_module_active = true;
					break;
				}
			}

			// Only redirect if PMPro module is NOT active.
			if ( ! $pmpro_module_active ) {
				// If this addon plugin is loaded, do not redirect to promo.
				if ( class_exists( 'WP_Analytify_PMPro_Addon' ) ) {
					return;
				}
				wp_safe_redirect( admin_url( '/admin.php?page=analytify-promo&addon=pmpro' ) );
				exit;
			}
		}
	}
}
