<?php
/**
 * PMPro Dashboard Data trait for addon.
 *
 * @package WP_Analytify_Pro
 * @subpackage PMPro\Classes
 * @since 9.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Trait Analytify_PMPro_Dashboard_Data_Trait
 *
 * @since 9.0.0
 */
trait Analytify_PMPro_Dashboard_Data_Trait {

	/**
	 * Get PMPro stats for dashboard.
	 *
	 * @since 9.0.0
	 * @return void
	 */
	public function wpa_get_pmpro_stats() {
		check_ajax_referer( 'analytify-get-stats', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( -1 );
		}

		$stats = array(
			'total_revenue'      => $this->get_total_revenue_stat(),
			'total_members'      => $this->get_total_members_stat(),
			'active_memberships' => $this->get_active_memberships_stat(),
			'conversion_rate'    => $this->get_conversion_rate_stat(),
			'revenue_by_level'   => $this->get_revenue_by_level_stat(),
			'members_by_level'   => $this->get_members_by_level_stat(),
		);

		wp_send_json_success( $stats );
	}

	/**
	 * Calculate total revenue.
	 *
	 * @since 9.0.0
	 * @return float
	 */
	private function get_total_revenue_stat() {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$revenue = $wpdb->get_var(
			"SELECT SUM(total) FROM {$wpdb->pmpro_membership_orders} WHERE status = 'success'"
		);

		return floatval( $revenue ? $revenue : 0 );
	}

	/**
	 * Get total members count.
	 *
	 * @since 9.0.0
	 * @return int
	 */
	private function get_total_members_stat() {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		return (int) $wpdb->get_var(
			"SELECT COUNT(DISTINCT user_id) FROM {$wpdb->pmpro_memberships_users} WHERE status = 'active'"
		);
	}

	/**
	 * Get active memberships count.
	 *
	 * @since 9.0.0
	 * @return int
	 */
	private function get_active_memberships_stat() {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		return (int) $wpdb->get_var(
			"SELECT COUNT(id) FROM {$wpdb->pmpro_memberships_users} WHERE status = 'active'"
		);
	}

	/**
	 * Calculate conversion rate.
	 *
	 * @since 9.0.0
	 * @return float
	 */
	private function get_conversion_rate_stat() {
		$total_visitors = $this->get_estimated_visitors();
		$total_members  = $this->get_total_members_stat();

		if ( $total_visitors > 0 ) {
			return round( ( $total_members / $total_visitors ) * 100, 2 );
		}

		return 0;
	}

	/**
	 * Estimate total visitors (placeholder - would integrate with Google Analytics).
	 *
	 * @since 9.0.0
	 * @return int
	 */
	private function get_estimated_visitors() {
		return 1000;
	}

	/**
	 * Get revenue by membership level.
	 *
	 * @since 9.0.0
	 * @return array
	 */
	private function get_revenue_by_level_stat() {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		return $wpdb->get_results(
			"SELECT membership_id, SUM(total) as revenue
			 FROM {$wpdb->pmpro_membership_orders}
			 WHERE status = 'success'
			 GROUP BY membership_id"
		);
	}

	/**
	 * Get members count by level.
	 *
	 * @since 9.0.0
	 * @return array
	 */
	private function get_members_by_level_stat() {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		return $wpdb->get_results(
			"SELECT membership_id, COUNT(id) as member_count
			 FROM {$wpdb->pmpro_memberships_users}
			 WHERE status = 'active'
			 GROUP BY membership_id"
		);
	}

	/**
	 * Get PMPro dashboard data.
	 *
	 * @since 9.0.0
	 * @param array $settings Dashboard settings.
	 * @return array
	 */
	public function wpa_get_pmpro_dashboard_data( $settings ) {
		$start_date = isset( $settings['start_date'] ) ? sanitize_text_field( $settings['start_date'] ) : gmdate( 'Y-m-d', strtotime( '-30 days' ) );
		$end_date   = isset( $settings['end_date'] ) ? sanitize_text_field( $settings['end_date'] ) : gmdate( 'Y-m-d' );

		return array(
			'total_revenue'    => $this->get_total_revenue( $start_date, $end_date ),
			'total_members'    => $this->get_total_members( $start_date, $end_date ),
			'active_members'   => $this->get_active_members( $start_date, $end_date ),
			'new_signups'      => $this->get_new_signups( $start_date, $end_date ),
			'churn_rate'       => $this->get_churn_rate( $start_date, $end_date ),
			'conversion_rate'  => $this->get_conversion_rate( $start_date, $end_date ),
			'revenue_by_level' => $this->get_revenue_by_level( $start_date, $end_date ),
			'members_by_level' => $this->get_members_by_level( $start_date, $end_date ),
		);
	}

	/**
	 * Get total revenue.
	 *
	 * @since 9.0.0
	 * @param string $start_date Start date.
	 * @param string $end_date End date.
	 * @return float
	 */
	private function get_total_revenue( $start_date, $end_date ) {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$result = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT SUM(total) FROM {$wpdb->pmpro_membership_orders}
				WHERE timestamp >= %s AND timestamp <= %s AND status = 'success'",
				$start_date . ' 00:00:00',
				$end_date . ' 23:59:59'
			)
		);

		return (float) $result;
	}

	/**
	 * Get total members.
	 *
	 * @since 9.0.0
	 * @param string $start_date Start date.
	 * @param string $end_date End date.
	 * @return int
	 */
	private function get_total_members( $start_date, $end_date ) {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$result = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(DISTINCT user_id) FROM {$wpdb->pmpro_memberships_users}
				WHERE startdate >= %s AND startdate <= %s",
				$start_date,
				$end_date
			)
		);

		return (int) $result;
	}

	/**
	 * Get active members.
	 *
	 * @since 9.0.0
	 * @param string $start_date Start date.
	 * @param string $end_date End date.
	 * @return int
	 */
	private function get_active_members( $start_date, $end_date ) {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$result = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(DISTINCT user_id) FROM {$wpdb->pmpro_memberships_users}
				WHERE status = 'active' AND startdate >= %s AND startdate <= %s",
				$start_date,
				$end_date
			)
		);

		return (int) $result;
	}

	/**
	 * Get new signups.
	 *
	 * @since 9.0.0
	 * @param string $start_date Start date.
	 * @param string $end_date End date.
	 * @return int
	 */
	private function get_new_signups( $start_date, $end_date ) {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$result = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(id) FROM {$wpdb->pmpro_memberships_users}
				WHERE startdate >= %s AND startdate <= %s",
				$start_date,
				$end_date
			)
		);

		return (int) $result;
	}

	/**
	 * Get churn rate.
	 *
	 * @since 9.0.0
	 * @param string $start_date Start date.
	 * @param string $end_date End date.
	 * @return float
	 */
	private function get_churn_rate( $start_date, $end_date ) {
		$expired_members = $this->get_expired_members( $start_date, $end_date );
		$total_members   = $this->get_total_members( $start_date, $end_date );

		return 0 !== $total_members ? round( ( $expired_members / $total_members ) * 100, 2 ) : 0.0;
	}

	/**
	 * Get conversion rate.
	 *
	 * @since 9.0.0
	 * @param string $start_date Start date.
	 * @param string $end_date End date.
	 * @return float
	 */
	private function get_conversion_rate( $start_date, $end_date ) {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$visitors = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(DISTINCT session_id) FROM {$wpdb->prefix}analytify_sessions
				WHERE date >= %s AND date <= %s",
				$start_date,
				$end_date
			)
		);

		$signups = $this->get_new_signups( $start_date, $end_date );

		return 0 !== $visitors ? round( ( $signups / $visitors ) * 100, 2 ) : 0.0;
	}

	/**
	 * Get revenue by level.
	 *
	 * @since 9.0.0
	 * @param string $start_date Start date.
	 * @param string $end_date End date.
	 * @return array
	 */
	private function get_revenue_by_level( $start_date, $end_date ) {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$results = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT ml.name as level_name, SUM(mo.total) as revenue
				FROM {$wpdb->pmpro_membership_orders} mo
				JOIN {$wpdb->pmpro_memberships_users} mu ON mo.user_id = mu.user_id
				JOIN {$wpdb->pmpro_membership_levels} ml ON mu.membership_id = ml.id
				WHERE mo.timestamp >= %s AND mo.timestamp <= %s AND mo.status = 'success'
				GROUP BY ml.id, ml.name
				ORDER BY revenue DESC",
				$start_date . ' 00:00:00',
				$end_date . ' 23:59:59'
			),
			ARRAY_A
		);

		return $results ? $results : array();
	}

	/**
	 * Get members by level.
	 *
	 * @since 9.0.0
	 * @param string $start_date Start date.
	 * @param string $end_date End date.
	 * @return array
	 */
	private function get_members_by_level( $start_date, $end_date ) {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$results = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT ml.name as level_name, COUNT(mu.user_id) as member_count
				FROM {$wpdb->pmpro_memberships_users} mu
				JOIN {$wpdb->pmpro_membership_levels} ml ON mu.membership_id = ml.id
				WHERE mu.startdate >= %s AND mu.startdate <= %s
				GROUP BY ml.id, ml.name
				ORDER BY member_count DESC",
				$start_date,
				$end_date
			),
			ARRAY_A
		);

		return $results ? $results : array();
	}

	/**
	 * Get expired members count.
	 *
	 * @since 9.0.0
	 * @param string $start_date Start date.
	 * @param string $end_date End date.
	 * @return int
	 */
	private function get_expired_members( $start_date, $end_date ) {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$result = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(id) FROM {$wpdb->pmpro_memberships_users}
				WHERE enddate >= %s AND enddate <= %s AND status = 'expired'",
				$start_date,
				$end_date
			)
		);

		return (int) $result;
	}
}
