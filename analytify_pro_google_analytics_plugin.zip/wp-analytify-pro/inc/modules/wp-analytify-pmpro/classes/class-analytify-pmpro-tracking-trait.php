<?php
/**
 * PMPro Tracking trait for addon.
 *
 * @package WP_Analytify_Pro
 * @subpackage PMPro\Classes
 * @since 9.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Trait Analytify_PMPro_Tracking_Trait
 *
 * @since 9.0.0
 */
trait Analytify_PMPro_Tracking_Trait {

	/**
	 * Track checkout completion (GA4 Measurement Protocol).
	 *
	 * @since 9.0.0
	 * @param int   $user_id User ID.
	 * @param mixed $order   Order object.
	 */
	public function wpa_pmpro_after_checkout( $user_id, $order ) {
		if ( ! method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) || 'ga4' !== WPANALYTIFY_Utils::get_ga_mode() ) {
			return;
		}

		$this->ensure_mp_ga4_loaded();

		$tracked_key = 'analytify_pmpro_tracked_' . $order->id;
		if ( 'yes' === get_option( $tracked_key, '' ) ) {
			return;
		}

		$level_obj  = function_exists( 'pmpro_getLevel' ) ? pmpro_getLevel( $order->membership_id ) : null;
		$level_name = ( is_object( $level_obj ) && isset( $level_obj->name ) ) ? $level_obj->name : 'Unknown Level';

		$discount_code    = '';
		$discount_code_id = '';
		if ( method_exists( $order, 'getDiscountCode' ) ) {
			$discount = $order->getDiscountCode();
			if ( $discount ) {
				$discount_code    = isset( $discount->code ) ? $discount->code : '';
				$discount_code_id = isset( $discount->id ) ? $discount->id : '';
			}
		}

		$is_trial     = ( is_object( $level_obj ) && function_exists( 'pmpro_isLevelTrial' ) ) ? pmpro_isLevelTrial( $level_obj ) : false;
		$is_recurring = ( is_object( $level_obj ) && isset( $level_obj->cycle_number ) && $level_obj->cycle_number > 0 );

		$events = array();

		$checkout_params = array(
			'transaction_id'        => (string) $order->id,
			'value'                 => (float) $order->total,
			'currency'              => ! empty( $order->currency ) ? (string) $order->currency : $this->get_pmpro_currency_code(),
			'wpa_category'          => 'pmpro_orders',
			'wpa_label'             => (string) $order->id,
			'membership_level'      => (int) $order->membership_id,
			'membership_level_name' => ! empty( $level_name ) ? $level_name : 'Unknown Level',
			'payment_gateway'       => ! empty( $order->gateway ) ? (string) $order->gateway : 'unknown',
			'wpa_user_id'           => (int) $user_id,
			'is_trial'              => $is_trial ? 'yes' : 'no',
			'is_recurring'          => $is_recurring ? 'yes' : 'no',
		);

		if ( $discount_code ) {
			$checkout_params['discount_code']    = $discount_code;
			$checkout_params['discount_code_id'] = $discount_code_id;
		}

		$events[] = array(
			'name'   => 'wpa_pmpro_checkout',
			'params' => $checkout_params,
		);

		if ( $discount_code ) {
			$events[] = array(
				'name'   => 'wpa_pmpro_discount_used',
				'params' => array(
					'wpa_category'          => 'pmpro_discounts',
					'wpa_label'             => $discount_code,
					'discount_code'         => $discount_code,
					'discount_code_id'      => $discount_code_id,
					'transaction_id'        => (string) $order->id,
					'membership_level'      => (int) $order->membership_id,
					'membership_level_name' => ! empty( $level_name ) ? $level_name : 'Unknown Level',
					'value'                 => (float) $order->total,
					'currency'              => ! empty( $order->currency ) ? (string) $order->currency : $this->get_pmpro_currency_code(),
					'wpa_user_id'           => (int) $user_id,
				),
			);
		}

		if ( $is_trial ) {
			$events[] = array(
				'name'   => 'wpa_pmpro_trial_started',
				'params' => array(
					'wpa_category'          => 'pmpro_trials',
					'wpa_label'             => 'Trial Started',
					'membership_level'      => (int) $order->membership_id,
					'membership_level_name' => ! empty( $level_name ) ? $level_name : 'Unknown Level',
					'trial_amount'          => (float) $order->total,
					'currency'              => ! empty( $order->currency ) ? (string) $order->currency : $this->get_pmpro_currency_code(),
					'wpa_user_id'           => (int) $user_id,
				),
			);
		}

		if ( 'success' === $order->status ) {
			$events[] = array(
				'name'   => 'purchase',
				'params' => array(
					'transaction_id'        => (string) $order->id,
					'value'                 => (float) $order->total,
					'currency'              => ! empty( $order->currency ) ? (string) $order->currency : $this->get_pmpro_currency_code(),
					'items'                 => array(
						array(
							'item_id'       => 'membership_level_' . $order->membership_id,
							'item_name'     => ! empty( $level_name ) ? $level_name : 'Unknown Level',
							'item_category' => 'Membership',
							'price'         => (float) $order->total,
							'quantity'      => 1,
						),
					),
					'membership_level'      => (int) $order->membership_id,
					'membership_level_name' => ! empty( $level_name ) ? $level_name : 'Unknown Level',
					'payment_gateway'       => ! empty( $order->gateway ) ? (string) $order->gateway : 'unknown',
				),
			);
		}

		if ( function_exists( 'analytify_mp_ga4' ) && ! empty( $events ) ) {
			analytify_mp_ga4( $events );
			update_option( $tracked_key, 'yes' );
		}
	}

	/**
	 * Track order status change to success (for manual payments).
	 *
	 * @since 9.0.0
	 * @param mixed  $order             Order object.
	 * @param string $_original_status Original status (unused; required by hook signature).
	 */
	public function wpa_pmpro_order_status_success( $order, $_original_status ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed -- Required by hook signature.
		$tracked_key = 'analytify_pmpro_tracked_' . $order->id;
		if ( 'success' === $order->status && 'yes' !== get_option( $tracked_key, '' ) ) {
			$this->wpa_pmpro_after_checkout( $order->user_id, $order );
		}
	}

	/**
	 * Track order status change to error.
	 *
	 * @since 9.0.0
	 * @param mixed  $order             Order object.
	 * @param string $_original_status  Original status (unused; required by hook signature).
	 */
	public function wpa_pmpro_order_status_error( $order, $_original_status ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed -- Required by hook signature.
		if ( ! method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) || 'ga4' !== WPANALYTIFY_Utils::get_ga_mode() ) {
			return;
		}

		$this->ensure_mp_ga4_loaded();

		$event = array(
			'name'   => 'wpa_pmpro_order_error',
			'params' => array(
				'wpa_category'     => 'pmpro_orders',
				'wpa_label'        => 'Order Error',
				'transaction_id'   => (string) $order->id,
				'value'            => (float) $order->total,
				'currency'         => ! empty( $order->currency ) ? (string) $order->currency : $this->get_pmpro_currency_code(),
				'membership_level' => (int) $order->membership_id,
				'wpa_user_id'      => (int) $order->user_id,
			),
		);

		if ( function_exists( 'analytify_mp_ga4' ) ) {
			analytify_mp_ga4( array( $event ) );
		}
	}

	/**
	 * Track order status change to pending.
	 *
	 * @since 9.0.0
	 * @param mixed  $order             Order object.
	 * @param string $_original_status  Original status (unused; required by hook signature).
	 */
	public function wpa_pmpro_order_status_pending( $order, $_original_status ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed -- Required by hook signature.
		if ( ! method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) || 'ga4' !== WPANALYTIFY_Utils::get_ga_mode() ) {
			return;
		}

		$this->ensure_mp_ga4_loaded();

		$event = array(
			'name'   => 'wpa_pmpro_order_pending',
			'params' => array(
				'wpa_category'     => 'pmpro_orders',
				'wpa_label'        => 'Order Pending',
				'transaction_id'   => (string) $order->id,
				'value'            => (float) $order->total,
				'currency'         => ! empty( $order->currency ) ? (string) $order->currency : $this->get_pmpro_currency_code(),
				'membership_level' => (int) $order->membership_id,
				'wpa_user_id'      => (int) $order->user_id,
			),
		);

		if ( function_exists( 'analytify_mp_ga4' ) ) {
			analytify_mp_ga4( array( $event ) );
		}
	}

	/**
	 * Track membership level changes (detect upgrades/downgrades).
	 *
	 * @since 9.0.0
	 * @param int   $level_id   Level ID.
	 * @param int   $user_id    User ID.
	 * @param array $old_levels Old levels.
	 */
	public function wpa_pmpro_change_membership_level( $level_id, $user_id, $old_levels ) {
		if ( ! method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) || 'ga4' !== WPANALYTIFY_Utils::get_ga_mode() ) {
			return;
		}

		$this->ensure_mp_ga4_loaded();

		$new_level      = function_exists( 'pmpro_getLevel' ) ? pmpro_getLevel( $level_id ) : null;
		$new_level_name = ( is_object( $new_level ) && isset( $new_level->name ) ) ? $new_level->name : 'Unknown';
		$new_initial    = ( is_object( $new_level ) && isset( $new_level->initial_payment ) ) ? (float) $new_level->initial_payment : 0.0;

		$change_type    = 'level_change';
		$old_level_name = '';
		$old_level_id   = 0;
		$old_initial    = 0.0;

		if ( ! empty( $old_levels ) && is_array( $old_levels ) ) {
			$old_level = reset( $old_levels );
			if ( is_object( $old_level ) ) {
				$old_level_id   = isset( $old_level->id ) ? $old_level->id : 0;
				$old_level_name = isset( $old_level->name ) ? $old_level->name : '';
				$old_initial    = isset( $old_level->initial_payment ) ? (float) $old_level->initial_payment : 0.0;

				if ( $new_initial > $old_initial ) {
					$change_type = 'upgrade';
				} elseif ( $new_initial < $old_initial && $new_initial > 0 ) {
					$change_type = 'downgrade';
				}
			}
		}

		$base_params = array(
			'wpa_category'          => 'pmpro_membership',
			'wpa_user_id'           => (int) $user_id,
			'membership_level'      => (int) $level_id,
			'membership_level_name' => $new_level_name,
			'value'                 => $new_initial,
			'currency'              => $this->get_pmpro_currency_code(),
		);

		if ( ! empty( $old_level_name ) ) {
			$base_params['old_membership_level']      = $old_level_id;
			$base_params['old_membership_level_name'] = $old_level_name;
			$base_params['old_value']                 = $old_initial;
		}

		$events = array();

		$events[] = array(
			'name'   => 'wpa_pmpro_level_change',
			'params' => array_merge(
				$base_params,
				array(
					'wpa_label'    => (string) $level_id,
					'event_action' => $change_type,
				)
			),
		);

		if ( 'upgrade' === $change_type ) {
			$events[] = array(
				'name'   => 'wpa_pmpro_upgrade',
				'params' => array_merge(
					$base_params,
					array(
						'wpa_label'      => 'Membership Upgrade',
						'value_increase' => $new_initial - $old_initial,
					)
				),
			);
		} elseif ( 'downgrade' === $change_type ) {
			$events[] = array(
				'name'   => 'wpa_pmpro_downgrade',
				'params' => array_merge(
					$base_params,
					array(
						'wpa_label'      => 'Membership Downgrade',
						'value_decrease' => $old_initial - $new_initial,
					)
				),
			);
		}

		if ( function_exists( 'analytify_mp_ga4' ) && ! empty( $events ) ) {
			analytify_mp_ga4( $events );
		}
	}

	/**
	 * Track membership expiration (including trial expiration).
	 *
	 * @since 9.0.0
	 * @param int $user_id  User ID.
	 * @param int $level_id Level ID.
	 */
	public function wpa_pmpro_membership_expired( $user_id, $level_id ) {
		if ( ! method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) || 'ga4' !== WPANALYTIFY_Utils::get_ga_mode() ) {
			return;
		}

		$this->ensure_mp_ga4_loaded();

		$level      = function_exists( 'pmpro_getLevel' ) ? pmpro_getLevel( $level_id ) : null;
		$level_name = ( is_object( $level ) && isset( $level->name ) ) ? $level->name : 'Unknown';

		$is_trial = ( is_object( $level ) && function_exists( 'pmpro_isLevelTrial' ) ) ? pmpro_isLevelTrial( $level ) : false;

		$events = array();

		$events[] = array(
			'name'   => 'wpa_pmpro_membership_expired',
			'params' => array(
				'wpa_category'          => 'pmpro_membership',
				'wpa_label'             => 'Membership Expired',
				'membership_level'      => (int) $level_id,
				'membership_level_name' => $level_name,
				'wpa_user_id'           => (int) $user_id,
				'was_trial'             => $is_trial ? 'yes' : 'no',
			),
		);

		if ( $is_trial ) {
			$events[] = array(
				'name'   => 'wpa_pmpro_trial_expired',
				'params' => array(
					'wpa_category'          => 'pmpro_trials',
					'wpa_label'             => 'Trial Expired',
					'membership_level'      => (int) $level_id,
					'membership_level_name' => $level_name,
					'wpa_user_id'           => (int) $user_id,
				),
			);
		}

		if ( function_exists( 'analytify_mp_ga4' ) && ! empty( $events ) ) {
			analytify_mp_ga4( $events );
		}
	}

	/**
	 * Track membership renewal notices.
	 *
	 * @since 9.0.0
	 * @param int $user_id  User ID.
	 * @param int $level_id Level ID.
	 */
	public function wpa_pmpro_membership_renewal_notice( $user_id, $level_id ) {
		if ( ! method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) || 'ga4' !== WPANALYTIFY_Utils::get_ga_mode() ) {
			return;
		}

		$this->ensure_mp_ga4_loaded();

		$event = array(
			'name'   => 'wpa_pmpro_renewal_notice',
			'params' => array(
				'wpa_category'     => 'pmpro_membership',
				'wpa_label'        => 'Renewal Notice Sent',
				'membership_level' => (int) $level_id,
				'wpa_user_id'      => (int) $user_id,
			),
		);

		if ( function_exists( 'analytify_mp_ga4' ) ) {
			analytify_mp_ga4( array( $event ) );
		}
	}

	/**
	 * Track membership cancellation (only when user actually cancels, not on upgrade/downgrade).
	 *
	 * PMPro fires this hook as: (0, $user_id, $cancel_level_id) on cancel; ($level_id, $user_id, null) on level change.
	 *
	 * @since 9.0.0
	 * @param int      $level_id     New level ID (0 when user cancelled with no new level).
	 * @param int      $user_id      User ID.
	 * @param int|null $cancel_level ID of the level that was cancelled, or null when changing level.
	 */
	public function wpa_pmpro_membership_cancelled( $level_id, $user_id, $cancel_level ) {
		// Only fire for actual cancellation: level_id is 0 and a level was cancelled (not on upgrade/downgrade where 3rd param is null).
		if ( 0 !== (int) $level_id || empty( $cancel_level ) || 0 >= (int) $cancel_level ) {
			return;
		}

		if ( ! method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) || 'ga4' !== WPANALYTIFY_Utils::get_ga_mode() ) {
			return;
		}

		$this->ensure_mp_ga4_loaded();

		$cancel_level_id = (int) $cancel_level;
		$level_obj       = function_exists( 'pmpro_getLevel' ) ? pmpro_getLevel( $cancel_level_id ) : null;
		$level_name      = ( is_object( $level_obj ) && isset( $level_obj->name ) ) ? $level_obj->name : '';

		$event = array(
			'name'   => 'wpa_pmpro_membership_cancelled',
			'params' => array(
				'wpa_category'          => 'pmpro_membership',
				'wpa_label'             => 'Membership Cancelled',
				'membership_level'      => $cancel_level_id,
				'membership_level_name' => $level_name,
				'wpa_user_id'           => (int) $user_id,
			),
		);

		if ( function_exists( 'analytify_mp_ga4' ) ) {
			analytify_mp_ga4( array( $event ) );
		}
	}

	/**
	 * Track payment failures.
	 *
	 * @since 9.0.0
	 * @param mixed $order      Order object.
	 * @param mixed $_old_order Old order object (unused; required by hook signature).
	 */
	public function wpa_pmpro_payment_failed( $order, $_old_order ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed -- Required by hook signature.
		if ( ! method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) || 'ga4' !== WPANALYTIFY_Utils::get_ga_mode() ) {
			return;
		}

		$this->ensure_mp_ga4_loaded();

		$level_obj  = function_exists( 'pmpro_getLevel' ) ? pmpro_getLevel( $order->membership_id ) : null;
		$level_name = ( is_object( $level_obj ) && isset( $level_obj->name ) ) ? $level_obj->name : 'Unknown Level';

		$event = array(
			'name'   => 'wpa_pmpro_payment_failed',
			'params' => array(
				'wpa_category'          => 'pmpro_orders',
				'wpa_label'             => 'Payment Failed',
				'value'                 => (float) $order->total,
				'currency'              => ! empty( $order->currency ) ? (string) $order->currency : $this->get_pmpro_currency_code(),
				'membership_level'      => (int) $order->membership_id,
				'membership_level_name' => $level_name,
				'payment_gateway'       => ! empty( $order->gateway ) ? (string) $order->gateway : 'unknown',
				'wpa_user_id'           => (int) $order->user_id,
			),
		);

		if ( function_exists( 'analytify_mp_ga4' ) ) {
			analytify_mp_ga4( array( $event ) );
		}
	}

	/**
	 * Track subscription payment completed (for trial conversion).
	 *
	 * @since 9.0.0
	 * @param mixed $order Order object.
	 */
	public function wpa_pmpro_subscription_payment_completed( $order ) {
		if ( ! method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) || 'ga4' !== WPANALYTIFY_Utils::get_ga_mode() ) {
			return;
		}

		$this->ensure_mp_ga4_loaded();

		$level_obj  = function_exists( 'pmpro_getLevel' ) ? pmpro_getLevel( $order->membership_id ) : null;
		$level_name = ( is_object( $level_obj ) && isset( $level_obj->name ) ) ? $level_obj->name : 'Unknown Level';

		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$first_success_order_id = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT MIN(id) FROM {$wpdb->pmpro_membership_orders} WHERE user_id = %d AND membership_id = %d AND status = 'success'",
				$order->user_id,
				$order->membership_id
			)
		);

		// Trial converted = first recurring payment after trial (this order is not the first success order for this user+level).
		$is_trial_conversion = $first_success_order_id && (int) $order->id !== (int) $first_success_order_id;

		if ( $is_trial_conversion ) {
			$events = array();

			$events[] = array(
				'name'   => 'wpa_pmpro_trial_converted',
				'params' => array(
					'wpa_category'          => 'pmpro_trials',
					'wpa_label'             => 'Trial Converted',
					'membership_level'      => (int) $order->membership_id,
					'membership_level_name' => $level_name,
					'value'                 => (float) $order->total,
					'currency'              => ! empty( $order->currency ) ? (string) $order->currency : $this->get_pmpro_currency_code(),
					'payment_gateway'       => ! empty( $order->gateway ) ? (string) $order->gateway : 'unknown',
					'wpa_user_id'           => (int) $order->user_id,
				),
			);

			if ( function_exists( 'analytify_mp_ga4' ) && ! empty( $events ) ) {
				analytify_mp_ga4( $events );
			}
		}
	}

	/**
	 * Track order refunds.
	 *
	 * @since 9.0.0
	 * @param mixed  $order           Order object.
	 * @param string $original_status Original status.
	 */
	public function wpa_pmpro_order_refunded( $order, $original_status ) {
		if ( ! method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) || 'ga4' !== WPANALYTIFY_Utils::get_ga_mode() ) {
			return;
		}

		$this->ensure_mp_ga4_loaded();

		$level_obj  = function_exists( 'pmpro_getLevel' ) ? pmpro_getLevel( $order->membership_id ) : null;
		$level_name = ( is_object( $level_obj ) && isset( $level_obj->name ) ) ? $level_obj->name : 'Unknown Level';

		$event = array(
			'name'   => 'wpa_pmpro_refund',
			'params' => array(
				'wpa_category'          => 'pmpro_orders',
				'wpa_label'             => 'Order Refunded',
				'transaction_id'        => (string) $order->id,
				'value'                 => (float) $order->total,
				'currency'              => ! empty( $order->currency ) ? (string) $order->currency : $this->get_pmpro_currency_code(),
				'membership_level'      => (int) $order->membership_id,
				'membership_level_name' => $level_name,
				'payment_gateway'       => ! empty( $order->gateway ) ? (string) $order->gateway : 'unknown',
				'wpa_user_id'           => (int) $order->user_id,
				'original_status'       => $original_status,
			),
		);

		if ( function_exists( 'analytify_mp_ga4' ) ) {
			analytify_mp_ga4( array( $event ) );
		}
	}

	/**
	 * Helper: PMPro currency code.
	 *
	 * @since 9.0.0
	 * @return string
	 */
	private function get_pmpro_currency_code() {
		if ( isset( $GLOBALS['pmpro_currency'] ) && ! empty( $GLOBALS['pmpro_currency'] ) ) {
			return (string) sanitize_text_field( $GLOBALS['pmpro_currency'] );
		}

		$code = get_option( 'pmpro_currency' );
		if ( ! empty( $code ) ) {
			return (string) sanitize_text_field( $code );
		}

		return 'USD';
	}

	/**
	 * Ensure analytify_mp_ga4 function is available.
	 *
	 * @since 9.0.0
	 * @return void
	 */
	private function ensure_mp_ga4_loaded() {
		if ( ! function_exists( 'analytify_mp_ga4' ) ) {
			$analytify_mp_ga4_file = ( defined( 'WP_ANALYTIFY_PLUGIN_DIR' ) ? WP_ANALYTIFY_PLUGIN_DIR : dirname( dirname( dirname( dirname( __DIR__ ) ) ) ) . '/wp-analytify' ) . '/classes/analytify-mp-ga4.php';
			if ( file_exists( $analytify_mp_ga4_file ) ) {
				require_once $analytify_mp_ga4_file;
			}
		}
	}
}
