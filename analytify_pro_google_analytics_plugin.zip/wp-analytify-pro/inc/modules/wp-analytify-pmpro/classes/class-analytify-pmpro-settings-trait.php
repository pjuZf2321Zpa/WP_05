<?php
/**
 * PMPro Settings trait for addon.
 *
 * @package WP_Analytify_Pro
 * @subpackage PMPro\Classes
 * @since 9.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Trait Analytify_PMPro_Settings_Trait
 *
 * @since 9.0.0
 */
trait Analytify_PMPro_Settings_Trait {

	/**
	 * Add PMPro settings to Analytify Pro.
	 *
	 * @since 9.0.0
	 * @param array $settings Settings array.
	 * @return array
	 */
	public function wpa_add_pmpro_settings( $settings ) {
		$pmpro_settings = array(
			array(
				'name'    => 'pmpro_tracking_enabled',
				'label'   => __( 'Enable PMPro Tracking', 'wp-analytify-pro' ),
				'desc'    => __( 'Track PMPro membership events in Google Analytics', 'wp-analytify-pro' ),
				'type'    => 'checkbox',
				'default' => 'on',
			),
			array(
				'name'    => 'pmpro_email_reports',
				'label'   => __( 'Include in Email Reports', 'wp-analytify-pro' ),
				'desc'    => __( 'Include PMPro stats in automated email reports', 'wp-analytify-pro' ),
				'type'    => 'checkbox',
				'default' => 'on',
			),
		);

		return array_merge( $settings, $pmpro_settings );
	}

	/**
	 * Add PMPro settings tab.
	 *
	 * @since 9.0.0
	 * @param array $tabs Settings tabs.
	 * @return array
	 */
	public function wpa_pmpro_settings_tab( $tabs ) {
		$tabs['pmpro'] = __( 'PMPro Integration', 'wp-analytify-pro' );
		return $tabs;
	}

	/**
	 * PMPro settings content.
	 *
	 * @since 9.0.0
	 * @return void
	 */
	public function wpa_pmpro_settings_content() {
		?>
		<div id="pmpro-settings" class="analytify_addon_settings">
			<h3><?php esc_html_e( 'Paid Memberships Pro Integration Settings', 'wp-analytify-pro' ); ?></h3>
			<p><?php esc_html_e( 'Configure how Analytify tracks Paid Memberships Pro events.', 'wp-analytify-pro' ); ?></p>

			<table class="form-table">
				<tr>
					<th scope="row"><?php esc_html_e( 'Track Membership Events', 'wp-analytify-pro' ); ?></th>
					<td>
						<label>
							<input type="checkbox" name="analytify_pmpro_track_events" value="1" <?php checked( get_option( 'analytify_pmpro_track_events', '1' ), '1' ); ?>>
							<?php esc_html_e( 'Enable tracking of membership signups, cancellations, and expirations', 'wp-analytify-pro' ); ?>
						</label>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Track Purchase Events', 'wp-analytify-pro' ); ?></th>
					<td>
						<label>
							<input type="checkbox" name="analytify_pmpro_track_purchases" value="1" <?php checked( get_option( 'analytify_pmpro_track_purchases', '1' ), '1' ); ?>>
							<?php esc_html_e( 'Enable tracking of membership purchases and renewals', 'wp-analytify-pro' ); ?>
						</label>
					</td>
				</tr>
			</table>
		</div>
		<?php
	}
}
