<?php
/**
 * PMPro REST API class.
 *
 * Handles REST API endpoints for Paid Memberships Pro analytics (stats, revenue, members by level, orders, gateways).
 *
 * @package WP_Analytify_Pro
 * @subpackage PMPro\Classes
 * @since 9.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

require_once __DIR__ . '/class-analytify-pmpro-stats-provider.php';

/**
 * Class Analytify_PMPro_REST_API
 *
 * Handles REST API endpoints for PMPro analytics (wpa_ prefixed routes and callbacks).
 * Routes are registered under the analytify/v1 namespace (route prefix).
 *
 * @since 9.0.0
 */
class Analytify_PMPro_REST_API {
	/**
	 * REST API route prefix (analytify/v1).
	 *
	 * @since 9.0.0
	 */
	const ROUTE_PREFIX = '/analytify';

	/**
	 * Max limit for orders endpoint.
	 *
	 * @since 9.0.0
	 */
	const ORDERS_LIMIT_MAX = 100;

	/**
	 * Initialize the REST API.
	 *
	 * @since 9.0.0
	 * @return void
	 */
	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'wpa_pmpro_register_routes' ) );
	}

	/**
	 * Get shared REST args for date parameters.
	 *
	 * @since 9.0.0
	 * @return array
	 */
	private static function wpa_pmpro_get_rest_date_args() {
		return array(
			'start_date' => array(
				'required'          => false,
				'type'              => 'string',
				'description'       => __( 'Start date for statistics (YYYY-MM-DD)', 'wp-analytify-pro' ),
				'sanitize_callback' => 'sanitize_text_field',
				'validate_callback' => array( __CLASS__, 'wpa_pmpro_validate_date_param' ),
			),
			'end_date'   => array(
				'required'          => false,
				'type'              => 'string',
				'description'       => __( 'End date for statistics (YYYY-MM-DD)', 'wp-analytify-pro' ),
				'sanitize_callback' => 'sanitize_text_field',
				'validate_callback' => array( __CLASS__, 'wpa_pmpro_validate_date_param' ),
			),
		);
	}

	/**
	 * Get REST arg for orders limit parameter.
	 *
	 * @since 9.0.0
	 * @return array
	 */
	private static function wpa_pmpro_get_rest_limit_arg() {
		return array(
			'limit' => array(
				'required'          => false,
				'type'              => 'integer',
				'default'           => 20,
				'description'       => __( 'Number of orders to return.', 'wp-analytify-pro' ),
				'sanitize_callback' => array( __CLASS__, 'wpa_pmpro_sanitize_orders_limit_param' ),
			),
		);
	}

	/**
	 * Sanitize the orders limit parameter (1 to ORDERS_LIMIT_MAX, default 20).
	 *
	 * @since 9.0.0
	 * @param mixed $value Raw value from request.
	 * @return int Sanitized limit.
	 */
	public static function wpa_pmpro_sanitize_orders_limit_param( $value ) {
		$value = absint( $value );
		return $value > 0 ? min( $value, self::ORDERS_LIMIT_MAX ) : 20;
	}

	/**
	 * Validate a date parameter (YYYY-MM-DD). Empty string is valid for optional params.
	 *
	 * @since 9.0.0
	 * @param mixed $value Value to validate.
	 * @return true|WP_Error
	 */
	public static function wpa_pmpro_validate_date_param( $value ) {
		if ( '' === $value || null === $value ) {
			return true;
		}
		$value = is_string( $value ) ? trim( $value ) : '';
		if ( '' === $value ) {
			return true;
		}
		$date_obj = DateTime::createFromFormat( 'Y-m-d', $value );
		if ( $date_obj && $date_obj->format( 'Y-m-d' ) === $value ) {
			return true;
		}
		return new WP_Error( 'invalid_date', __( 'Date must be in YYYY-MM-DD format.', 'wp-analytify-pro' ), array( 'status' => 400 ) );
	}

	/**
	 * Register REST API routes for PMPro stats, revenue, members, orders, discounts, trials, churn, gateways, and revenue breakdown.
	 *
	 * @since 9.0.0
	 * @return void
	 */
	public static function wpa_pmpro_register_routes() {
		register_rest_route(
			'analytify/v1',
			'/pmpro/stats',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'wpa_pmpro_get_stats' ),
				'permission_callback' => array( __CLASS__, 'wpa_pmpro_check_permissions' ),
				'args'                => self::wpa_pmpro_get_rest_date_args(),
			)
		);

		register_rest_route(
			'analytify/v1',
			'/pmpro/revenue',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'wpa_pmpro_get_revenue' ),
				'permission_callback' => array( __CLASS__, 'wpa_pmpro_check_permissions' ),
				'args'                => self::wpa_pmpro_get_rest_date_args(),
			)
		);

		register_rest_route(
			'analytify/v1',
			'/pmpro/members',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'wpa_pmpro_get_members' ),
				'permission_callback' => array( __CLASS__, 'wpa_pmpro_check_permissions' ),
				'args'                => self::wpa_pmpro_get_rest_date_args(),
			)
		);

		register_rest_route(
			'analytify/v1',
			'/pmpro/orders',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'wpa_pmpro_get_orders' ),
				'permission_callback' => array( __CLASS__, 'wpa_pmpro_check_permissions' ),
				'args'                => array_merge( self::wpa_pmpro_get_rest_date_args(), self::wpa_pmpro_get_rest_limit_arg() ),
			)
		);

		register_rest_route(
			'analytify/v1',
			'/pmpro/discounts',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'wpa_pmpro_get_discounts' ),
				'permission_callback' => array( __CLASS__, 'wpa_pmpro_check_permissions' ),
				'args'                => self::wpa_pmpro_get_rest_date_args(),
			)
		);

		register_rest_route(
			'analytify/v1',
			'/pmpro/trials',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'wpa_pmpro_get_trials' ),
				'permission_callback' => array( __CLASS__, 'wpa_pmpro_check_permissions' ),
				'args'                => self::wpa_pmpro_get_rest_date_args(),
			)
		);

		register_rest_route(
			'analytify/v1',
			'/pmpro/churn',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'wpa_pmpro_get_churn' ),
				'permission_callback' => array( __CLASS__, 'wpa_pmpro_check_permissions' ),
				'args'                => self::wpa_pmpro_get_rest_date_args(),
			)
		);

		register_rest_route(
			'analytify/v1',
			'/pmpro/gateways',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'wpa_pmpro_get_gateways' ),
				'permission_callback' => array( __CLASS__, 'wpa_pmpro_check_permissions' ),
				'args'                => self::wpa_pmpro_get_rest_date_args(),
			)
		);

		register_rest_route(
			'analytify/v1',
			'/pmpro/revenue-breakdown',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'wpa_pmpro_get_revenue_breakdown' ),
				'permission_callback' => array( __CLASS__, 'wpa_pmpro_check_permissions' ),
				'args'                => self::wpa_pmpro_get_rest_date_args(),
			)
		);
	}

	/**
	 * Check if user has permission to access PMPro stats.
	 *
	 * @since 9.0.0
	 * @return bool True if user can access, false otherwise.
	 */
	public static function wpa_pmpro_check_permissions() {
		if ( ! isset( $GLOBALS['WP_ANALYTIFY'] ) || ! is_object( $GLOBALS['WP_ANALYTIFY'] ) ) {
			return false;
		}
		$wp_analytify = $GLOBALS['WP_ANALYTIFY'];
		if ( empty( $wp_analytify->settings ) || ! is_object( $wp_analytify->settings ) || ! is_callable( array( $wp_analytify->settings, 'get_option' ) ) ) {
			$is_access_level = array( 'administrator' );
		} else {
			$is_access_level = $wp_analytify->settings->get_option( 'show_analytics_roles_dashboard', 'wp-analytify-dashboard', array( 'administrator' ) );
		}
		if ( ! is_callable( array( $wp_analytify, 'pa_check_roles' ) ) ) {
			return false;
		}
		return (bool) $wp_analytify->pa_check_roles( $is_access_level );
	}

	/**
	 * Get WP_ANALYTIFY instance with defensive guard for REST callbacks.
	 *
	 * @since 9.0.0
	 * @return object|null WP_ANALYTIFY instance or null if not available.
	 */
	private static function wpa_pmpro_get_analytify() {
		if ( ! isset( $GLOBALS['WP_ANALYTIFY'] ) || ! is_object( $GLOBALS['WP_ANALYTIFY'] ) ) {
			return null;
		}
		return $GLOBALS['WP_ANALYTIFY'];
	}

	/**
	 * Sanitize and default date params from request for stats endpoints.
	 *
	 * @since 9.0.0
	 * @param WP_REST_Request $request Request object.
	 * @return array{0: string, 1: string} [ start_date, end_date ] in Y-m-d.
	 */
	private static function wpa_pmpro_get_request_dates( $request ) {
		$start = $request->get_param( 'start_date' );
		$end   = $request->get_param( 'end_date' );
		$start = is_string( $start ) ? sanitize_text_field( $start ) : '';
		$end   = is_string( $end ) ? sanitize_text_field( $end ) : '';
		if ( '' === $start ) {
			$start = gmdate( 'Y-m-d', strtotime( '-30 days' ) );
		}
		if ( '' === $end ) {
			$end = gmdate( 'Y-m-d' );
		}
		return array( $start, $end );
	}

	/**
	 * Get comprehensive PMPro statistics.
	 *
	 * @since 9.0.0
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function wpa_pmpro_get_stats( $request ) {
		$wp_analytify = self::wpa_pmpro_get_analytify();
		if ( ! $wp_analytify ) {
			return new WP_Error( 'analytify_unavailable', __( 'Analytify is not available.', 'wp-analytify-pro' ), array( 'status' => 503 ) );
		}
		list( $start_date, $end_date ) = self::wpa_pmpro_get_request_dates( $request );
		$overview_stats                = Analytify_PMPro_Stats_Provider::wpa_pmpro_get_overview_stats( $start_date, $end_date );
		include PMPRO_ANALYTIFY_PLUGIN_DIR . '/views/default/overview.php';
		return wpa_pmpro_overview( $wp_analytify, $overview_stats );
	}

	/**
	 * Get revenue statistics.
	 *
	 * @since 9.0.0
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function wpa_pmpro_get_revenue( $request ) {
		$wp_analytify = self::wpa_pmpro_get_analytify();
		if ( ! $wp_analytify ) {
			return new WP_Error( 'analytify_unavailable', __( 'Analytify is not available.', 'wp-analytify-pro' ), array( 'status' => 503 ) );
		}
		list( $start_date, $end_date ) = self::wpa_pmpro_get_request_dates( $request );
		$revenue_stats                 = Analytify_PMPro_Stats_Provider::wpa_pmpro_get_revenue_stats( $start_date, $end_date );
		include PMPRO_ANALYTIFY_PLUGIN_DIR . '/views/default/levels-performance.php';
		return wpa_pmpro_levels_performance( $wp_analytify, $revenue_stats );
	}

	/**
	 * Get member statistics.
	 *
	 * @since 9.0.0
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function wpa_pmpro_get_members( $request ) {
		$wp_analytify = self::wpa_pmpro_get_analytify();
		if ( ! $wp_analytify ) {
			return new WP_Error( 'analytify_unavailable', __( 'Analytify is not available.', 'wp-analytify-pro' ), array( 'status' => 503 ) );
		}
		list( $start_date, $end_date ) = self::wpa_pmpro_get_request_dates( $request );
		$member_stats                  = Analytify_PMPro_Stats_Provider::wpa_pmpro_get_member_stats( $start_date, $end_date );
		include PMPRO_ANALYTIFY_PLUGIN_DIR . '/views/default/members-by-level.php';
		return wpa_pmpro_members_by_level( $wp_analytify, $member_stats );
	}

	/**
	 * Get recent orders.
	 *
	 * @since 9.0.0
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function wpa_pmpro_get_orders( $request ) {
		$wp_analytify = self::wpa_pmpro_get_analytify();
		if ( ! $wp_analytify ) {
			return new WP_Error( 'analytify_unavailable', __( 'Analytify is not available.', 'wp-analytify-pro' ), array( 'status' => 503 ) );
		}
		$limit  = $request->get_param( 'limit' );
		$limit  = is_numeric( $limit ) ? min( absint( $limit ), self::ORDERS_LIMIT_MAX ) : 20;
		$limit  = $limit > 0 ? $limit : 20;
		$orders = Analytify_PMPro_Stats_Provider::wpa_pmpro_get_recent_orders( $limit );
		include PMPRO_ANALYTIFY_PLUGIN_DIR . '/views/default/recent-orders.php';
		return wpa_pmpro_recent_orders( $wp_analytify, $orders );
	}

	/**
	 * Get discount codes performance.
	 *
	 * @since 9.0.0
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function wpa_pmpro_get_discounts( $request ) {
		$wp_analytify = self::wpa_pmpro_get_analytify();
		if ( ! $wp_analytify ) {
			return new WP_Error( 'analytify_unavailable', __( 'Analytify is not available.', 'wp-analytify-pro' ), array( 'status' => 503 ) );
		}
		list( $start_date, $end_date ) = self::wpa_pmpro_get_request_dates( $request );
		$discount_stats                = Analytify_PMPro_Stats_Provider::wpa_pmpro_get_discount_stats( $start_date, $end_date );
		include PMPRO_ANALYTIFY_PLUGIN_DIR . '/views/default/discounts.php';
		return wpa_pmpro_discounts_performance( $wp_analytify, $discount_stats );
	}

	/**
	 * Get trial conversion statistics.
	 *
	 * @since 9.0.0
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function wpa_pmpro_get_trials( $request ) {
		$wp_analytify = self::wpa_pmpro_get_analytify();
		if ( ! $wp_analytify ) {
			return new WP_Error( 'analytify_unavailable', __( 'Analytify is not available.', 'wp-analytify-pro' ), array( 'status' => 503 ) );
		}
		list( $start_date, $end_date ) = self::wpa_pmpro_get_request_dates( $request );
		$trial_stats                   = Analytify_PMPro_Stats_Provider::wpa_pmpro_get_trial_stats( $start_date, $end_date );
		include PMPRO_ANALYTIFY_PLUGIN_DIR . '/views/default/trials.php';
		return wpa_pmpro_trials_performance( $wp_analytify, $trial_stats );
	}

	/**
	 * Get churn and retention statistics.
	 *
	 * @since 9.0.0
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function wpa_pmpro_get_churn( $request ) {
		$wp_analytify = self::wpa_pmpro_get_analytify();
		if ( ! $wp_analytify ) {
			return new WP_Error( 'analytify_unavailable', __( 'Analytify is not available.', 'wp-analytify-pro' ), array( 'status' => 503 ) );
		}
		list( $start_date, $end_date ) = self::wpa_pmpro_get_request_dates( $request );
		$churn_stats                   = Analytify_PMPro_Stats_Provider::wpa_pmpro_get_churn_stats( $start_date, $end_date );
		include PMPRO_ANALYTIFY_PLUGIN_DIR . '/views/default/churn.php';
		return wpa_pmpro_churn_performance( $wp_analytify, $churn_stats );
	}

	/**
	 * Get payment gateway performance.
	 *
	 * @since 9.0.0
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function wpa_pmpro_get_gateways( $request ) {
		$wp_analytify = self::wpa_pmpro_get_analytify();
		if ( ! $wp_analytify ) {
			return new WP_Error( 'analytify_unavailable', __( 'Analytify is not available.', 'wp-analytify-pro' ), array( 'status' => 503 ) );
		}
		list( $start_date, $end_date ) = self::wpa_pmpro_get_request_dates( $request );
		$gateway_stats                 = Analytify_PMPro_Stats_Provider::wpa_pmpro_get_gateway_stats( $start_date, $end_date );
		include PMPRO_ANALYTIFY_PLUGIN_DIR . '/views/default/gateways.php';
		return wpa_pmpro_gateways_performance( $wp_analytify, $gateway_stats );
	}

	/**
	 * Get revenue breakdown (recurring vs one-time).
	 *
	 * @since 9.0.0
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function wpa_pmpro_get_revenue_breakdown( $request ) {
		$wp_analytify = self::wpa_pmpro_get_analytify();
		if ( ! $wp_analytify ) {
			return new WP_Error( 'analytify_unavailable', __( 'Analytify is not available.', 'wp-analytify-pro' ), array( 'status' => 503 ) );
		}
		list( $start_date, $end_date ) = self::wpa_pmpro_get_request_dates( $request );
		$breakdown_stats               = Analytify_PMPro_Stats_Provider::wpa_pmpro_get_revenue_breakdown_stats( $start_date, $end_date );
		include PMPRO_ANALYTIFY_PLUGIN_DIR . '/views/default/revenue-breakdown.php';
		return wpa_pmpro_revenue_breakdown( $wp_analytify, $breakdown_stats );
	}
}

// Initialize the REST API.
Analytify_PMPro_REST_API::init();
