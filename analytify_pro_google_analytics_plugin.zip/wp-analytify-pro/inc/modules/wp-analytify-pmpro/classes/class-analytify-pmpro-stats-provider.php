<?php
/**
 * PMPro stats provider for REST API.
 *
 * Provides overview, revenue, members, orders, discounts, trials, churn, gateways,
 * and revenue breakdown statistics. Used by Analytify_PMPro_REST_API.
 *
 * @package WP_Analytify_Pro
 * @subpackage PMPro\Classes
 * @since 9.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Analytify_PMPro_Stats_Provider
 *
 * @since 9.0.0
 */
class Analytify_PMPro_Stats_Provider {

	/**
	 * Get overview statistics from GA4 (like WooCommerce).
	 *
	 * @since 9.0.0
	 * @param string|null $start_date Start date.
	 * @param string|null $end_date   End date.
	 * @return array
	 */
	public static function wpa_pmpro_get_overview_stats( $start_date = null, $end_date = null ) {
		global $wpdb;

		$stats = array();

		// Get active members from database (this is PMPro-specific, not in GA4).
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$active_members = $wpdb->get_var(
			"SELECT COUNT(DISTINCT user_id) FROM {$wpdb->pmpro_memberships_users} WHERE status = 'active'"
		);

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$total_memberships = $wpdb->get_var(
			"SELECT COUNT(id) FROM {$wpdb->pmpro_memberships_users} WHERE status = 'active'"
		);

		// Get GA4 data using aggregations (like WooCommerce).
		if ( method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() && class_exists( 'WP_Analytify' ) && method_exists( WP_Analytify::get_instance(), 'get_reports' ) ) {
			$wp_analytify = WP_Analytify::get_instance();
			$date_range   = array(
				'start' => $start_date ? $start_date : gmdate( 'Y-m-d', strtotime( '-30 days' ) ),
				'end'   => $end_date ? $end_date : gmdate( 'Y-m-d' ),
			);

			// Get purchase events with aggregations (like WooCommerce general stats).
			$ga_stats = $wp_analytify->get_reports(
				'pmpro_overview_stats',
				array(
					'purchaseRevenue',
					'transactions',
					'averagePurchaseRevenue',
					'sessions',
					'ecommercePurchases',
					'firstTimePurchaserRate',
				),
				$date_range,
				array( 'currencyCode' ),
				array(),
				array(
					'logic'   => 'AND',
					'filters' => array(
						array(
							'type'       => 'dimension',
							'name'       => 'eventName',
							'match_type' => 1,
							'value'      => 'purchase',
						),
					),
				),
				10
			);

			// Get total sessions (unfiltered) for conversion rate. Conversion = (orders / all sessions), not (orders / sessions-with-purchase).
			$total_sessions  = 0;
			$sessions_report = $wp_analytify->get_reports(
				'pmpro_overview_sessions',
				array( 'sessions' ),
				$date_range,
				array(),
				array(),
				array(),
				10
			);
			if ( isset( $sessions_report['aggregations']['sessions'] ) ) {
				$total_sessions = (int) $sessions_report['aggregations']['sessions'];
			}

			// Extract aggregations (like WooCommerce does).
			if ( isset( $ga_stats['aggregations'] ) ) {
				$aggregations = $ga_stats['aggregations'];

				$total_revenue       = isset( $aggregations['purchaseRevenue'] ) ? (float) $aggregations['purchaseRevenue'] : 0.0;
				$total_orders        = isset( $aggregations['transactions'] ) ? (int) $aggregations['transactions'] : 0;
				$average_order_value = isset( $aggregations['averagePurchaseRevenue'] ) ? (float) $aggregations['averagePurchaseRevenue'] : 0.0;

				// Get currency code from GA4 response.
				$currency_code = isset( $ga_stats['currencyCode'] ) && '(not set)' !== $ga_stats['currencyCode'] ? $ga_stats['currencyCode'] : '';

				// Calculate average if not provided or if we have orders but no average.
				if ( $average_order_value <= 0 && $total_orders > 0 && $total_revenue > 0 ) {
					$average_order_value = $total_revenue / $total_orders;
				}

				// Conversion rate = % of all sessions that resulted in a transaction (use total site sessions, not purchase-filtered).
				$conversion_rate = $total_sessions > 0 ? round( ( $total_orders / $total_sessions ) * 100, 2 ) : 0.0;

				$stats = array(
					'total_revenue'             => $total_revenue,
					'total_orders'              => $total_orders,
					'average_order_value'       => $average_order_value,
					'active_members'            => intval( $active_members ? $active_members : 0 ),
					'total_memberships'         => intval( $total_memberships ? $total_memberships : 0 ),
					'conversion_rate'           => $conversion_rate,
					'first_time_purchaser_rate' => isset( $aggregations['firstTimePurchaserRate'] ) ? (float) $aggregations['firstTimePurchaserRate'] : 0.0,
					'currencyCode'              => $currency_code,
				);
			} else {
				// GA4 data not available, return zeros (GA4-only approach).
				$stats = array(
					'total_revenue'             => 0.0,
					'total_orders'              => 0,
					'average_order_value'       => 0.0,
					'active_members'            => intval( $active_members ? $active_members : 0 ),
					'total_memberships'         => intval( $total_memberships ? $total_memberships : 0 ),
					'conversion_rate'           => 0.0,
					'first_time_purchaser_rate' => 0.0,
					'currencyCode'              => '',
				);
			}
		} else {
			// GA4 mode not enabled, return zeros (GA4-only approach).
			$stats = array(
				'total_revenue'             => 0.0,
				'total_orders'              => 0,
				'average_order_value'       => 0.0,
				'active_members'            => intval( $active_members ? $active_members : 0 ),
				'total_memberships'         => intval( $total_memberships ? $total_memberships : 0 ),
				'conversion_rate'           => 0.0,
				'first_time_purchaser_rate' => 0.0,
				'currencyCode'              => '',
			);
		}

		return $stats;
	}

	/**
	 * Get revenue statistics.
	 *
	 * @since 9.0.0
	 * @param string|null $start_date Start date.
	 * @param string|null $end_date   End date.
	 * @return array
	 */
	public static function wpa_pmpro_get_revenue_stats( $start_date = null, $end_date = null ) {
		global $wpdb;

		$stats        = array();
		$where_clause = "WHERE status = 'success'";
		if ( $start_date && $end_date ) {
			$where_clause .= $wpdb->prepare( ' AND DATE(timestamp) BETWEEN %s AND %s', $start_date, $end_date );
		}

		// Get GA4 data if available.
		if ( method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() && class_exists( 'WP_Analytify' ) && method_exists( WP_Analytify::get_instance(), 'get_reports' ) ) {
			$wp_analytify = WP_Analytify::get_instance();

			// Revenue by membership level from GA4.
			$revenue_by_level = $wp_analytify->get_reports(
				'pmpro_revenue_by_level',
				array(
					'purchaseRevenue',
				),
				array(
					'start' => $start_date ? $start_date : gmdate( 'Y-m-d', strtotime( '-30 days' ) ),
					'end'   => $end_date ? $end_date : gmdate( 'Y-m-d' ),
				),
				array(
					'membershipLevel',
				),
				array(
					'type' => 'metric',
					'name' => 'purchaseRevenue',
				),
				array(
					'logic'   => 'AND',
					'filters' => array(
						array(
							'type'       => 'dimension',
							'name'       => 'eventName',
							'match_type' => 1,
							'value'      => 'purchase',
						),
						array(
							'type'           => 'dimension',
							'name'           => 'membershipLevel',
							'match_type'     => 4,
							'value'          => '(not set)',
							'not_expression' => true,
						),
					),
				),
				0
			);

			if ( isset( $revenue_by_level['rows'] ) ) {
				$stats['revenue_by_level'] = array();
				foreach ( $revenue_by_level['rows'] as $row ) {
					$level_id                    = $row['membershipLevel'];
					$level                       = function_exists( 'pmpro_getLevel' ) ? pmpro_getLevel( $level_id ) : null;
					$stats['revenue_by_level'][] = array(
						'level_id'   => $level_id,
						'level_name' => $level ? $level->name : 'Level ' . $level_id,
						'revenue'    => isset( $row['purchaseRevenue'] ) ? $row['purchaseRevenue'] : 0,
					);
				}
			}
		}

		// Fallback to database queries if GA4 data is not available.
		if ( empty( $stats['revenue_by_level'] ) ) {
			// The $where_clause is already prepared via $wpdb->prepare() above.
			// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$revenue_by_level = $wpdb->get_results(
				"SELECT membership_id, SUM(total) as revenue
				 FROM {$wpdb->pmpro_membership_orders}
				 {$where_clause}
				 GROUP BY membership_id
				 ORDER BY revenue DESC"
			);
			// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared

			// Add level names.
			foreach ( $revenue_by_level as &$level ) {
				$level_data        = function_exists( 'pmpro_getLevel' ) ? pmpro_getLevel( $level->membership_id ) : null;
				$level->level_name = $level_data ? $level_data->name : __( 'Unknown Level', 'wp-analytify-pro' );
			}
			$stats['revenue_by_level'] = $revenue_by_level;
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$total_revenue_var      = $wpdb->get_var( "SELECT SUM(total) FROM {$wpdb->pmpro_membership_orders} {$where_clause}" );
		$stats['total_revenue'] = floatval( $total_revenue_var ? $total_revenue_var : 0 );

		return $stats;
	}

	/**
	 * Get member statistics.
	 *
	 * @since 9.0.0
	 * @param string|null $start_date Start date.
	 * @param string|null $end_date   End date.
	 * @return array
	 */
	public static function wpa_pmpro_get_member_stats( $start_date = null, $end_date = null ) {
		global $wpdb;

		$where_clause = "WHERE status = 'active'";
		if ( $start_date && $end_date ) {
			$where_clause .= $wpdb->prepare( ' AND DATE(startdate) BETWEEN %s AND %s', $start_date, $end_date );
		}

		// Members by level.
		// The $where_clause is already prepared via $wpdb->prepare() above.
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$members_by_level = $wpdb->get_results(
			"SELECT membership_id, COUNT(id) as member_count
			 FROM {$wpdb->pmpro_memberships_users}
			 {$where_clause}
			 GROUP BY membership_id
			 ORDER BY member_count DESC"
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		// Add level names.
		foreach ( $members_by_level as &$level ) {
			$level_data        = function_exists( 'pmpro_getLevel' ) ? pmpro_getLevel( $level->membership_id ) : null;
			$level->level_name = $level_data ? $level_data->name : __( 'Unknown Level', 'wp-analytify-pro' );
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$total_members_var = $wpdb->get_var( "SELECT COUNT(DISTINCT user_id) FROM {$wpdb->pmpro_memberships_users} {$where_clause}" );
		return array(
			'total_members'    => intval( $total_members_var ? $total_members_var : 0 ),
			'members_by_level' => $members_by_level,
		);
	}

	/**
	 * Get recent orders.
	 *
	 * @since 9.0.0
	 * @param int $limit Number of orders to retrieve.
	 * @return array
	 */
	public static function wpa_pmpro_get_recent_orders( $limit = 20 ) {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$orders = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT o.id, o.user_id, o.membership_id, o.total, o.timestamp, o.gateway,
						u.display_name as member_name, u.user_email,
						l.name as level_name
				 FROM {$wpdb->pmpro_membership_orders} o
				 LEFT JOIN {$wpdb->users} u ON o.user_id = u.ID
				 LEFT JOIN {$wpdb->pmpro_membership_levels} l ON o.membership_id = l.id
				 WHERE o.status = 'success'
				 ORDER BY o.timestamp DESC
				 LIMIT %d",
				$limit
			)
		);

		return $orders;
	}

	/**
	 * Get discount code statistics from GA4.
	 *
	 * @since 9.0.0
	 * @param string|null $start_date Start date.
	 * @param string|null $end_date   End date.
	 * @return array
	 */
	public static function wpa_pmpro_get_discount_stats( $start_date = null, $end_date = null ) {
		global $wpdb;

		$stats = array( 'rows' => array() );

		if ( method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() && class_exists( 'WP_Analytify' ) && method_exists( WP_Analytify::get_instance(), 'get_reports' ) ) {
			$wp_analytify = WP_Analytify::get_instance();

			$discount_stats = $wp_analytify->get_reports(
				'pmpro_discount_stats',
				array(
					'purchaseRevenue',
					'eventCount',
				),
				array(
					'start' => $start_date ? $start_date : gmdate( 'Y-m-d', strtotime( '-30 days' ) ),
					'end'   => $end_date ? $end_date : gmdate( 'Y-m-d' ),
				),
				array(
					'discountCode',
					'currencyCode',
				),
				array(
					'type'  => 'metric',
					'name'  => 'purchaseRevenue',
					'order' => 'desc',
				),
				array(
					'logic'   => 'AND',
					'filters' => array(
						array(
							'type'       => 'dimension',
							'name'       => 'eventName',
							'match_type' => 1,
							'value'      => 'purchase',
						),
						array(
							'type'           => 'dimension',
							'name'           => 'discountCode',
							'match_type'     => 4,
							'value'          => '(not set)',
							'not_expression' => true,
						),
					),
				),
				10
			);

			if ( isset( $discount_stats['rows'] ) ) {
				$stats['rows'] = $discount_stats['rows'];
			}
		}

		// Fallback to database.
		if ( empty( $stats['rows'] ) ) {
			$where_clause = "WHERE o.status = 'success'";
			if ( $start_date && $end_date ) {
				$where_clause .= $wpdb->prepare( ' AND DATE(o.timestamp) BETWEEN %s AND %s', $start_date, $end_date );
			}

			// The $where_clause is already prepared via $wpdb->prepare() above.
			// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$discount_data = $wpdb->get_results(
				"SELECT 
					dc.code as discount_code,
					COUNT(DISTINCT o.id) as usage_count,
					SUM(o.total) as revenue
				FROM {$wpdb->pmpro_membership_orders} o
				LEFT JOIN {$wpdb->pmpro_discount_codes_uses} dcu ON o.id = dcu.order_id
				LEFT JOIN {$wpdb->pmpro_discount_codes} dc ON dcu.code_id = dc.id
				{$where_clause}
				AND dc.code IS NOT NULL
				GROUP BY dc.code
				ORDER BY revenue DESC
				LIMIT 10"
			);
			// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared

			if ( $discount_data ) {
				foreach ( $discount_data as $row ) {
					$stats['rows'][] = array(
						'discountCode'    => $row->discount_code,
						'eventCount'      => (int) $row->usage_count,
						'purchaseRevenue' => (float) $row->revenue,
					);
				}
			}
		}

		return $stats;
	}

	/**
	 * Get trial conversion statistics from GA4.
	 *
	 * @since 9.0.0
	 * @param string|null $start_date Start date.
	 * @param string|null $end_date   End date.
	 * @return array
	 */
	public static function wpa_pmpro_get_trial_stats( $start_date = null, $end_date = null ) {
		$stats = array(
			'trial_started'   => 0,
			'trial_converted' => 0,
			'trial_expired'   => 0,
			'conversion_rate' => 0.0,
		);

		if ( method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() && class_exists( 'WP_Analytify' ) && method_exists( WP_Analytify::get_instance(), 'get_reports' ) ) {
			$wp_analytify = WP_Analytify::get_instance();

			// Get trial started count.
			$trial_started = $wp_analytify->get_reports(
				'pmpro_trial_started',
				array( 'eventCount' ),
				array(
					'start' => $start_date ? $start_date : gmdate( 'Y-m-d', strtotime( '-30 days' ) ),
					'end'   => $end_date ? $end_date : gmdate( 'Y-m-d' ),
				),
				array( 'eventName' ),
				array(),
				array(
					'logic'   => 'AND',
					'filters' => array(
						array(
							'type'       => 'dimension',
							'name'       => 'eventName',
							'match_type' => 1,
							'value'      => 'wpa_pmpro_trial_started',
						),
					),
				),
				1
			);

			// Get trial converted count.
			$trial_converted = $wp_analytify->get_reports(
				'pmpro_trial_converted',
				array( 'eventCount' ),
				array(
					'start' => $start_date ? $start_date : gmdate( 'Y-m-d', strtotime( '-30 days' ) ),
					'end'   => $end_date ? $end_date : gmdate( 'Y-m-d' ),
				),
				array( 'eventName' ),
				array(),
				array(
					'logic'   => 'AND',
					'filters' => array(
						array(
							'type'       => 'dimension',
							'name'       => 'eventName',
							'match_type' => 1,
							'value'      => 'wpa_pmpro_trial_converted',
						),
					),
				),
				1
			);

			// Get trial expired count.
			$trial_expired = $wp_analytify->get_reports(
				'pmpro_trial_expired',
				array( 'eventCount' ),
				array(
					'start' => $start_date ? $start_date : gmdate( 'Y-m-d', strtotime( '-30 days' ) ),
					'end'   => $end_date ? $end_date : gmdate( 'Y-m-d' ),
				),
				array( 'eventName' ),
				array(),
				array(
					'logic'   => 'AND',
					'filters' => array(
						array(
							'type'       => 'dimension',
							'name'       => 'eventName',
							'match_type' => 1,
							'value'      => 'wpa_pmpro_trial_expired',
						),
					),
				),
				1
			);

			$stats['trial_started']   = isset( $trial_started['aggregations']['eventCount'] ) ? (int) $trial_started['aggregations']['eventCount'] : 0;
			$stats['trial_converted'] = isset( $trial_converted['aggregations']['eventCount'] ) ? (int) $trial_converted['aggregations']['eventCount'] : 0;
			$stats['trial_expired']   = isset( $trial_expired['aggregations']['eventCount'] ) ? (int) $trial_expired['aggregations']['eventCount'] : 0;

			if ( $stats['trial_started'] > 0 ) {
				$stats['conversion_rate'] = round( ( $stats['trial_converted'] / $stats['trial_started'] ) * 100, 2 );
			}
		}

		return $stats;
	}

	/**
	 * Get churn and retention statistics from GA4.
	 *
	 * @since 9.0.0
	 * @param string|null $start_date Start date.
	 * @param string|null $end_date   End date.
	 * @return array
	 */
	public static function wpa_pmpro_get_churn_stats( $start_date = null, $end_date = null ) {
		$stats = array(
			'cancelled'      => 0,
			'expired'        => 0,
			'upgrades'       => 0,
			'downgrades'     => 0,
			'refunds'        => 0,
			'refund_revenue' => 0.0,
			'churn_rate'     => 0.0,
			'retention_rate' => 0.0,
		);

		if ( method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() && class_exists( 'WP_Analytify' ) && method_exists( WP_Analytify::get_instance(), 'get_reports' ) ) {
			$wp_analytify = WP_Analytify::get_instance();
			$date_range   = array(
				'start' => $start_date ? $start_date : gmdate( 'Y-m-d', strtotime( '-30 days' ) ),
				'end'   => $end_date ? $end_date : gmdate( 'Y-m-d' ),
			);

			// Get cancelled count.
			$cancelled = $wp_analytify->get_reports(
				'pmpro_cancelled',
				array( 'eventCount' ),
				$date_range,
				array( 'eventName' ),
				array(),
				array(
					'logic'   => 'AND',
					'filters' => array(
						array(
							'type'       => 'dimension',
							'name'       => 'eventName',
							'match_type' => 1,
							'value'      => 'wpa_pmpro_membership_cancelled',
						),
					),
				),
				1
			);

			// Get expired count.
			$expired = $wp_analytify->get_reports(
				'pmpro_expired',
				array( 'eventCount' ),
				$date_range,
				array( 'eventName' ),
				array(),
				array(
					'logic'   => 'AND',
					'filters' => array(
						array(
							'type'       => 'dimension',
							'name'       => 'eventName',
							'match_type' => 1,
							'value'      => 'wpa_pmpro_membership_expired',
						),
					),
				),
				1
			);

			// Get refunds count and revenue.
			$refunds = $wp_analytify->get_reports(
				'pmpro_refunds',
				array(
					'eventCount',
					'eventValue',
				),
				$date_range,
				array( 'eventName' ),
				array(),
				array(
					'logic'   => 'AND',
					'filters' => array(
						array(
							'type'       => 'dimension',
							'name'       => 'eventName',
							'match_type' => 1,
							'value'      => 'wpa_pmpro_refund',
						),
					),
				),
				1
			);

			$stats['cancelled']      = isset( $cancelled['aggregations']['eventCount'] ) ? (int) $cancelled['aggregations']['eventCount'] : 0;
			$stats['expired']        = isset( $expired['aggregations']['eventCount'] ) ? (int) $expired['aggregations']['eventCount'] : 0;
			$stats['refunds']        = isset( $refunds['aggregations']['eventCount'] ) ? (int) $refunds['aggregations']['eventCount'] : 0;
			$stats['refund_revenue'] = isset( $refunds['aggregations']['eventValue'] ) ? (float) $refunds['aggregations']['eventValue'] : 0.0;

			// Calculate churn rate (cancelled + expired) / total active members.
			global $wpdb;
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
			$total_active  = $wpdb->get_var( "SELECT COUNT(DISTINCT user_id) FROM {$wpdb->pmpro_memberships_users} WHERE status = 'active'" );
			$total_churned = $stats['cancelled'] + $stats['expired'];
			if ( $total_active > 0 ) {
				$stats['churn_rate']     = round( ( $total_churned / ( $total_active + $total_churned ) ) * 100, 2 );
				$stats['retention_rate'] = 100 - $stats['churn_rate'];
			}
		}

		return $stats;
	}

	/**
	 * Get payment gateway performance from GA4.
	 *
	 * @since 9.0.0
	 * @param string|null $start_date Start date.
	 * @param string|null $end_date   End date.
	 * @return array
	 */
	public static function wpa_pmpro_get_gateway_stats( $start_date = null, $end_date = null ) {
		global $wpdb;

		$stats = array( 'rows' => array() );

		if ( method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() && class_exists( 'WP_Analytify' ) && method_exists( WP_Analytify::get_instance(), 'get_reports' ) ) {
			$wp_analytify = WP_Analytify::get_instance();

			$gateway_stats = $wp_analytify->get_reports(
				'pmpro_gateway_stats',
				array(
					'purchaseRevenue',
					'transactions',
				),
				array(
					'start' => $start_date ? $start_date : gmdate( 'Y-m-d', strtotime( '-30 days' ) ),
					'end'   => $end_date ? $end_date : gmdate( 'Y-m-d' ),
				),
				array(
					'paymentGateway',
					'currencyCode',
				),
				array(
					'type'  => 'metric',
					'name'  => 'purchaseRevenue',
					'order' => 'desc',
				),
				array(
					'logic'   => 'AND',
					'filters' => array(
						array(
							'type'       => 'dimension',
							'name'       => 'eventName',
							'match_type' => 1,
							'value'      => 'purchase',
						),
						array(
							'type'           => 'dimension',
							'name'           => 'paymentGateway',
							'match_type'     => 4,
							'value'          => '(not set)',
							'not_expression' => true,
						),
					),
				),
				10
			);

			if ( isset( $gateway_stats['rows'] ) ) {
				$stats['rows'] = $gateway_stats['rows'];
			}
		}

		// Fallback to database: include all orders in date range so success rate = successful / total.
		if ( empty( $stats['rows'] ) ) {
			$date_filter = '';
			if ( $start_date && $end_date ) {
				$date_filter = $wpdb->prepare( ' AND DATE(timestamp) BETWEEN %s AND %s', $start_date, $end_date );
			}

			// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$gateway_data = $wpdb->get_results(
				"SELECT
					gateway,
					COUNT(id) as total_transactions,
					SUM(CASE WHEN status = 'success' THEN 1 ELSE 0 END) as successful,
					SUM(CASE WHEN status = 'success' THEN total ELSE 0 END) as revenue
				FROM {$wpdb->pmpro_membership_orders}
				WHERE 1=1 {$date_filter}
				GROUP BY gateway
				ORDER BY revenue DESC"
			);
			// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared

			if ( $gateway_data ) {
				foreach ( $gateway_data as $row ) {
					$total           = (int) $row->total_transactions;
					$success         = (int) $row->successful;
					$success_rate    = $total > 0 ? round( ( $success / $total ) * 100, 2 ) : 0.0;
					$stats['rows'][] = array(
						'paymentGateway'  => $row->gateway ? $row->gateway : __( 'Unknown', 'wp-analytify-pro' ),
						'transactions'    => $success,
						'purchaseRevenue' => (float) $row->revenue,
						'successRate'     => $success_rate,
					);
				}
			}
		}

		return $stats;
	}

	/**
	 * Get revenue breakdown (recurring vs one-time) from GA4.
	 *
	 * @since 9.0.0
	 * @param string|null $start_date Start date.
	 * @param string|null $end_date   End date.
	 * @return array
	 */
	public static function wpa_pmpro_get_revenue_breakdown_stats( $start_date = null, $end_date = null ) {
		$stats = array(
			'recurring_revenue'    => 0.0,
			'one_time_revenue'     => 0.0,
			'total_revenue'        => 0.0,
			'recurring_percentage' => 0.0,
		);

		if ( method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() && class_exists( 'WP_Analytify' ) && method_exists( WP_Analytify::get_instance(), 'get_reports' ) ) {
			$wp_analytify = WP_Analytify::get_instance();
			$date_range   = array(
				'start' => $start_date ? $start_date : gmdate( 'Y-m-d', strtotime( '-30 days' ) ),
				'end'   => $end_date ? $end_date : gmdate( 'Y-m-d' ),
			);

			// Get recurring revenue.
			$recurring = $wp_analytify->get_reports(
				'pmpro_recurring_revenue',
				array( 'purchaseRevenue' ),
				$date_range,
				array( 'isRecurring' ),
				array(),
				array(
					'logic'   => 'AND',
					'filters' => array(
						array(
							'type'       => 'dimension',
							'name'       => 'eventName',
							'match_type' => 1,
							'value'      => 'purchase',
						),
						array(
							'type'       => 'dimension',
							'name'       => 'isRecurring',
							'match_type' => 1,
							'value'      => 'yes',
						),
					),
				),
				1
			);

			// Get one-time revenue.
			$one_time = $wp_analytify->get_reports(
				'pmpro_one_time_revenue',
				array( 'purchaseRevenue' ),
				$date_range,
				array( 'isRecurring' ),
				array(),
				array(
					'logic'   => 'AND',
					'filters' => array(
						array(
							'type'       => 'dimension',
							'name'       => 'eventName',
							'match_type' => 1,
							'value'      => 'purchase',
						),
						array(
							'type'       => 'dimension',
							'name'       => 'isRecurring',
							'match_type' => 1,
							'value'      => 'no',
						),
					),
				),
				1
			);

			$stats['recurring_revenue']    = isset( $recurring['aggregations']['purchaseRevenue'] ) ? (float) $recurring['aggregations']['purchaseRevenue'] : 0.0;
			$stats['one_time_revenue']     = isset( $one_time['aggregations']['purchaseRevenue'] ) ? (float) $one_time['aggregations']['purchaseRevenue'] : 0.0;
			$stats['total_revenue']        = $stats['recurring_revenue'] + $stats['one_time_revenue'];
			$stats['recurring_percentage'] = 0.0;

			if ( $stats['total_revenue'] > 0 ) {
				$stats['recurring_percentage'] = round( ( $stats['recurring_revenue'] / $stats['total_revenue'] ) * 100, 2 );
			}
		}

		return $stats;
	}
}
