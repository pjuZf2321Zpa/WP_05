<?php
/**
 * PMPro Dashboard Template.
 *
 * Prepares dashboard data and renders via Analytify_PMPro_Dashboard_View.
 * Report scripts are enqueued by the addon (wp_add_inline_script).
 *
 * @package WP_Analytify_Pro
 * @subpackage PMPro\Includes
 * @since 9.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! isset( $GLOBALS['WP_ANALYTIFY'] ) || ! is_object( $GLOBALS['WP_ANALYTIFY'] ) ) {
	return;
}

$wp_analytify = $GLOBALS['WP_ANALYTIFY'];

if ( function_exists( 'analytify_datepicker_dates' ) ) {
	$date_data  = analytify_datepicker_dates();
	$start_date = isset( $date_data['start_date'] ) ? sanitize_text_field( $date_data['start_date'] ) : wp_date( 'Y-m-d', strtotime( '-1 month' ) );
	$end_date   = isset( $date_data['end_date'] ) ? sanitize_text_field( $date_data['end_date'] ) : wp_date( 'Y-m-d', strtotime( 'now' ) );
} else {
	$start_date = wp_date( 'Y-m-d', strtotime( '-1 month' ) );
	$end_date   = wp_date( 'Y-m-d', strtotime( 'now' ) );
}

$date1 = date_create( $start_date );
$date2 = date_create( $end_date );
$diff  = date_diff( $date2, $date1 );

$compare_start_date = strtotime( $start_date . $diff->format( '%R%a days' ) );
$compare_start_date = gmdate( 'Y-m-d', $compare_start_date );
$compare_end_date   = $start_date;

$dashboard_profile_id = $wp_analytify->settings->get_option( 'profile_for_dashboard', 'wp-analytify-profile' );
$dashboard_profile_id = method_exists( 'WPANALYTIFY_Utils', 'get_reporting_property' ) ? WPANALYTIFY_Utils::get_reporting_property() : $dashboard_profile_id;

$report_url        = WP_ANALYTIFY_FUNCTIONS::get_ga_report_url( $dashboard_profile_id );
$report_date_range = WP_ANALYTIFY_FUNCTIONS::get_ga_report_range( $start_date, $end_date, $compare_start_date, $compare_end_date );
$version           = defined( 'ANALYTIFY_PRO_VERSION' ) ? ANALYTIFY_PRO_VERSION : ANALYTIFY_VERSION;
$access_token      = get_option( 'post_analytics_token' );
$analytify_profile = get_option( 'wp-analytify-profile' );
$is_access_level   = $wp_analytify->settings->get_option( 'show_analytics_roles_dashboard', 'wp-analytify-dashboard' );

if ( ! class_exists( 'Analytify_PMPro_Dashboard_View' ) ) {
	require_once defined( 'PMPRO_ANALYTIFY_PLUGIN_DIR' ) ? PMPRO_ANALYTIFY_PLUGIN_DIR . '/includes/class-analytify-pmpro-dashboard-view.php' : __DIR__ . '/class-analytify-pmpro-dashboard-view.php';
}

$view = new Analytify_PMPro_Dashboard_View(
	array(
		'start_date'           => $start_date,
		'end_date'             => $end_date,
		'compare_start_date'   => $compare_start_date,
		'compare_end_date'     => $compare_end_date,
		'dashboard_profile_id' => $dashboard_profile_id,
		'report_url'           => $report_url,
		'report_date_range'    => $report_date_range,
		'version'              => $version,
		'access_token'         => $access_token,
		'analytify_profile'    => $analytify_profile,
		'is_access_level'      => $is_access_level,
	)
);
$view->wpa_pmpro_render();
