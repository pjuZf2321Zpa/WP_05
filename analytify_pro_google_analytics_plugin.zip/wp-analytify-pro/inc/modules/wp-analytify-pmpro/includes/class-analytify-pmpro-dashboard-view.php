<?php
/**
 * PMPro Dashboard view class.
 *
 * Renders the PMPro analytics dashboard markup. Data is prepared by the caller;
 * scripts are enqueued separately via the addon.
 *
 * @package WP_Analytify_Pro
 * @subpackage PMPro\Includes
 * @since 9.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Analytify_PMPro_Dashboard_View
 *
 * @since 9.0.0
 */
class Analytify_PMPro_Dashboard_View {

	/**
	 * Start date (Y-m-d).
	 *
	 * @var string
	 */
	public $start_date;

	/**
	 * End date (Y-m-d).
	 *
	 * @var string
	 */
	public $end_date;

	/**
	 * Compare start date (Y-m-d).
	 *
	 * @var string
	 */
	public $compare_start_date;

	/**
	 * Compare end date (Y-m-d).
	 *
	 * @var string
	 */
	public $compare_end_date;

	/**
	 * Dashboard profile ID.
	 *
	 * @var string
	 */
	public $dashboard_profile_id;

	/**
	 * Report URL.
	 *
	 * @var string
	 */
	public $report_url;

	/**
	 * Report date range.
	 *
	 * @var string
	 */
	public $report_date_range;

	/**
	 * Version string.
	 *
	 * @var string
	 */
	public $version;

	/**
	 * Access token.
	 *
	 * @var string|false
	 */
	public $access_token;

	/**
	 * Analytify profile option.
	 *
	 * @var mixed
	 */
	public $analytify_profile;

	/**
	 * Access level option.
	 *
	 * @var mixed
	 */
	public $is_access_level;

	/**
	 * Constructor.
	 *
	 * @since 9.0.0
	 * @param array $args Associative array of view data (start_date, end_date, compare_start_date, compare_end_date, dashboard_profile_id, report_url, report_date_range, version, access_token, analytify_profile, is_access_level).
	 */
	public function __construct( $args = array() ) {
		$defaults = array(
			'start_date'           => '',
			'end_date'             => '',
			'compare_start_date'   => '',
			'compare_end_date'     => '',
			'dashboard_profile_id' => '',
			'report_url'           => '',
			'report_date_range'    => '',
			'version'              => '',
			'access_token'         => false,
			'analytify_profile'    => null,
			'is_access_level'      => null,
		);
		$args     = wp_parse_args( $args, $defaults );
		foreach ( $args as $key => $value ) {
			if ( property_exists( $this, $key ) ) {
				$this->$key = $value;
			}
		}
	}

	/**
	 * Output the dashboard markup (no inline scripts; those are enqueued by the addon).
	 *
	 * @since 9.0.0
	 * @return void
	 */
	public function wpa_pmpro_render() {
		if ( ! isset( $GLOBALS['WP_ANALYTIFY'] ) || ! is_object( $GLOBALS['WP_ANALYTIFY'] ) ) {
			return;
		}
		$wp_analytify      = $GLOBALS['WP_ANALYTIFY'];
		$start_date        = $this->start_date;
		$end_date          = $this->end_date;
		$access_token      = $this->access_token;
		$analytify_profile = $this->analytify_profile;
		$is_access_level   = $this->is_access_level;
		?>
<div class="wpanalytify analytify-dashboard-nav">
	<div class="wpb_plugin_wraper">
		<div class="wpb_plugin_header_wraper">
			<div class="graph"></div>
				<div class="wpb_plugin_header">
					<div class="wpb_plugin_header_title"></div>
					<div class="wpb_plugin_header_info">
							<a href="https://analytify.io/changelog/" target="_blank" class="btn"><?php echo esc_html__( 'View Changelog', 'wp-analytify-pro' ); ?></a>
					</div>
					<div class="wpb_plugin_header_logo">
							<img src="<?php echo esc_url( ANALYTIFY_PLUGIN_URL . '/assets/img/logo.svg' ); ?>" alt="<?php esc_attr_e( 'Analytify', 'wp-analytify-pro' ); ?>">
					</div>
				</div>
			</div>

			<div class="analytify-dashboard-body-container">
				<div class="wpb_plugin_body_wraper">
					<div class="wpb_plugin_body">
						<div class="wpa-tab-wrapper">
							<?php
							if ( method_exists( $GLOBALS['WP_ANALYTIFY'], 'dashboard_navigation' ) ) {
								$GLOBALS['WP_ANALYTIFY']->dashboard_navigation();
							}
							?>
						</div>
						<div class="wpb_plugin_tabs_content analytify-dashboard-content">

							<div class="analytify_wraper">
								<div class="analytify_main_title_section">
									<div class="analytify_dashboard_title">
										<h1 class="analytify_pull_left analytify_main_title"><?php esc_html_e( 'Paid Memberships Pro Dashboard', 'wp-analytify-pro' ); ?></h1>
										<?php
										$analytify_profile = get_option( 'wp-analytify-profile' );
										if ( $access_token && method_exists( 'WPANALYTIFY_Utils', 'dashboard_subtitle_section' ) ) {
											WPANALYTIFY_Utils::dashboard_subtitle_section();
										}
										?>
									</div>

									<div class="analytify_main_setting_bar">
										<div class="analytify_pull_right analytify_setting">
											<div class="analytify_select_date">
												<?php
												if ( method_exists( 'WPANALYTIFY_Utils', 'date_form' ) ) {
													WPANALYTIFY_Utils::date_form( $start_date, $end_date );
												}
												?>
											</div>
										</div>
									</div>
								</div>
								<?php

								if ( ! WP_ANALYTIFY_FUNCTIONS::wpa_check_profile_selection( 'Paid Memberships Pro' ) ) {
									$is_access_level = $wp_analytify->settings->get_option( 'show_analytics_roles_dashboard', 'wp-analytify-dashboard' );

									if ( $wp_analytify->pa_check_roles( $is_access_level ) ) {
										if ( $access_token ) {
											?>

											<div class="analytify_status_body stats_loading">
												<div class="pmpro-general-stats-report"></div>
											</div>

											<?php
											// ECharts Funnel (inline script moved to wp_add_inline_script in funnel view).
											// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Display only.
											if ( ! isset( $_GET['cn'] ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {
												$funnel_stats   = $wp_analytify->get_reports(
													'show-pmpro-funnel-chart',
													array( 'screenPageViews', 'eventCount', 'transactions' ),
													array(
														'start' => $start_date,
														'end' => $end_date,
													),
													array( 'pagePath' ),
													array(
														'type' => 'metric',
														'name' => 'screenPageViews',
														'order' => 'desc',
													),
													array(
														'logic'   => 'OR',
														'filters' => array(
															array(
																'type' => 'dimension',
																'name' => 'pagePath',
																'match_type' => 4,
																'value' => '/membership',
															),
															array(
																'type'       => 'dimension',
																'name'       => 'pagePath',
																'match_type' => 4,
																'value'      => '/membership-levels',
															),
														),
													),
													10
												);
												$checkout_stats = $wp_analytify->get_reports(
													'show-pmpro-checkout-events',
													array( 'eventCount' ),
													array(
														'start' => $start_date,
														'end' => $end_date,
													),
													array( 'eventName' ),
													array(),
													array(
														'logic'   => 'AND',
														'filters' => array(
															array(
																'type' => 'dimension',
																'name' => 'eventName',
																'match_type' => 1,
																'value' => 'wpa_pmpro_checkout',
															),
														),
													),
													10
												);
												$purchase_stats = $wp_analytify->get_reports(
													'show-pmpro-purchase-events',
													array( 'transactions' ),
													array(
														'start' => $start_date,
														'end' => $end_date,
													),
													array( 'eventName' ),
													array(),
													array(
														'logic'   => 'AND',
														'filters' => array(
															array(
																'type' => 'dimension',
																'name' => 'eventName',
																'match_type' => 1,
																'value' => 'purchase',
															),
														),
													),
													10
												);
												$combined_stats = array(
													'rows' => array(
														array(
															'pageViews'    => isset( $funnel_stats['aggregations']['screenPageViews'] ) ? $funnel_stats['aggregations']['screenPageViews'] : 0,
															'checkouts'    => isset( $checkout_stats['aggregations']['eventCount'] ) ? $checkout_stats['aggregations']['eventCount'] : 0,
															'transactions' => isset( $purchase_stats['aggregations']['transactions'] ) ? $purchase_stats['aggregations']['transactions'] : 0,
														),
													),
												);
												include PMPRO_ANALYTIFY_PLUGIN_DIR . '/views/default/funnel.php';
												wpa_pmpro_funnel_chart( $wp_analytify, $combined_stats );
											}
											?>

											<div class="analytify_status_body stats_loading">
												<div class="pmpro-recent-orders-report"></div>
											</div>

											<div class="analytify_status_body stats_loading">
												<div class="pmpro-revenue-by-level-report"></div>
											</div>

											<div class="analytify_status_body stats_loading">
												<div class="pmpro-members-by-level-report"></div>
											</div>

											<div class="analytify_status_body stats_loading">
												<div class="pmpro-discounts-report"></div>
											</div>

											<div class="analytify_status_body stats_loading">
												<div class="pmpro-trials-report"></div>
											</div>

											<div class="analytify_status_body stats_loading">
												<div class="pmpro-churn-report"></div>
											</div>

											<div class="analytify_status_body stats_loading">
												<div class="pmpro-gateways-report"></div>
											</div>

											<div class="analytify_status_body stats_loading">
												<div class="pmpro-revenue-breakdown-report"></div>
											</div>

											<?php
										} else {
											WP_ANALYTIFY_FUNCTIONS::wpa_authenticate_message();
										}
									} else {
										WP_ALYTIFY_FUNCTIONS::wpa_authorize_message();
									}
								}
								?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
		<?php
	}
}
