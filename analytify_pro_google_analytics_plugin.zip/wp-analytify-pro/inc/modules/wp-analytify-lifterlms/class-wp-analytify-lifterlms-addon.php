<?php
/**
 * LifterLMS Integration Main Class for Analytify.
 *
 * @package    Analytify
 * @subpackage LifterLMS
 */

if ( class_exists( 'WP_Analytify_LifterLMS_Addon' ) ) {
	return;
}

/**
 * Analytify LifterLMS Integration Class.
 *
 * @since 9.0.0
 */
class WP_Analytify_LifterLMS_Addon extends WP_Analytify_Pro_Base {

	/**
	 * The one true instance.
	 *
	 * @var WP_Analytify_LifterLMS_Addon
	 * @since 9.0.0
	 */
	private static $instance;

	/**
	 * Google Measurement URL.
	 *
	 * @var string
	 */
	public $google_measurement_url = 'https://ssl.google-analytics.com/collect';

	/**
	 * Google Debug Measurement URL.
	 *
	 * @var string
	 */
	public $google_debug_measurement_url = 'https://www.google-analytics.com/debug/collect';

	/**
	 * Order fully refunded flag.
	 *
	 * @var null|bool
	 */
	public $order_fully_refunded = null;

	/**
	 * Course list for tracking.
	 *
	 * @var array
	 */
	private $course_list = array();

	/**
	 * Tracking scripts to be output in footer.
	 *
	 * @var array
	 */
	private $tracking_scripts = array();

	/**
	 * Get active instance.
	 *
	 * @access      public
	 * @since 9.0.0
	 * @return      object self::$instance The one true WP_Analytify_LifterLMS_Addon
	 */
	public static function instance() {
		if ( ! self::$instance ) {
			self::$instance = new WP_Analytify_LifterLMS_Addon();
			self::$instance->setup_constants();
			self::$instance->includes();
			self::$instance->hooks();
		}

		return self::$instance;
	}

	/**
	 * Format currency value with proper symbol and formatting.
	 *
	 * @param float  $amount The amount to format.
	 * @param string $currency_code The currency code (defaults to LifterLMS currency).
	 *
	 * @since 9.0.0
	 * @return string Formatted currency string.
	 */
	public static function analytify_format_currency( $amount, $currency_code = '' ) {
		if ( empty( $currency_code ) ) {
			$currency_code = get_lifterlms_currency();
		}
		$currency_symbol = get_lifterlms_currency_symbol( $currency_code );
		return $currency_symbol . number_format( (float) $amount, 2 );
	}

	/**
	 * Setup plugin constants.
	 *
	 * @access      private
	 * @since 9.0.0
	 * @return      void
	 */
	private function setup_constants() {
		// Setting Global Values.
		$this->define( 'LLMS_ANALYTIFY_PLUGIN_FILE', __FILE__ );
		$this->define( 'LLMS_ANALYTIFY_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );
		$this->define( 'LLMS_ANALYTIFY_PLUGIN_DIR', __DIR__ );
		$this->define( 'LLMS_ANALYTIFY_PRODUCT_NAME', 'Enhanced E-Commerce Google Analytics for LifterLMS Addon' );
		$this->define( 'LLMS_ANALYTIFY_PRODUCT_ID', 9999 );
		$this->define( 'LLMS_ANALYTIFY_STORE_URL', 'https://analytify.io' );
	}

	/**
	 * Define constant if not already set.
	 *
	 * @param  string      $name Constant name.
	 * @param  string|bool $value Constant value.
	 * @since 9.0.0
	 */
	private function define( $name, $value ) {
		if ( ! defined( $name ) ) {
			define( $name, $value );
		}
	}

	/**
	 * Include necessary files.
	 *
	 * @access      private
	 * @since 9.0.0
	 * @return      void
	 */
	private function includes() {
		// Ensure Measurement Protocol GA4 class is loaded (needed for server-side tracking).
		if ( ! function_exists( 'analytify_mp_ga4' ) ) {
			$analytify_mp_ga4_file = ( defined( 'WP_ANALYTIFY_PLUGIN_DIR' ) ? WP_ANALYTIFY_PLUGIN_DIR : dirname( dirname( dirname( dirname( __DIR__ ) ) ) ) . '/wp-analytify' ) . '/classes/analytify-mp-ga4.php';
			if ( file_exists( $analytify_mp_ga4_file ) ) {
				require_once $analytify_mp_ga4_file;
			}
		}

		// Load REST Handler base class.
		$rest_handler_base = ( defined( 'WP_ANALYTIFY_PLUGIN_DIR' ) ? WP_ANALYTIFY_PLUGIN_DIR : dirname( dirname( dirname( dirname( __DIR__ ) ) ) ) . '/wp-analytify' ) . '/classes/class-analytify-rest-handler-base.php';
		if ( file_exists( $rest_handler_base ) ) {
			require_once $rest_handler_base;
		}

		// Fallback: load base from Pro plugin if not yet loaded.
		if ( ! class_exists( 'Analytify_REST_Handler_Base' ) ) {
			$rest_handler_base_pro = defined( 'ANALYTIFY_PRO_ROOT_PATH' )
				? ANALYTIFY_PRO_ROOT_PATH . '/classes/class-analytify-rest-handler-base.php'
				: dirname( dirname( dirname( __DIR__ ) ) ) . '/classes/class-analytify-rest-handler-base.php';
			if ( file_exists( $rest_handler_base_pro ) ) {
				require_once $rest_handler_base_pro;
			}
		}

		// Rest endpoints.
		include LLMS_ANALYTIFY_PLUGIN_DIR . '/classes/class-analytify-llms-rest-api.php';
	}

	/**
	 * Run action and filter hooks.
	 *
	 * @access      private
	 * @since 9.0.0
	 * @return      void
	 */
	private function hooks() {
		// Add menu for LifterLMS Analytics Dashboard.
		add_action( 'analytify_add_submenu', array( $this, 'wpa_llms_add_menu' ), 10 );

		add_action( 'admin_notices', array( $this, 'wpa_llms_show_admin_notices' ) );
		add_action( 'ga_ecommerce_js', array( $this, 'wpa_llms_add_ga_ecommerce_js' ), 1 );

		// Track course views.
		add_action( 'template_redirect', array( $this, 'wpa_llms_track_course_view' ) );
		add_action( 'template_redirect', array( $this, 'wpa_llms_track_lesson_view' ) );

		// Track enrollments.
		add_action( 'llms_user_enrolled_in_course', array( $this, 'wpa_llms_track_enrollment' ), 10, 2 );

		// Track purchases/orders.
		add_action( 'lifterlms_order_status_completed', array( $this, 'wpa_llms_track_order_complete' ), 10, 1 );
		add_action( 'lifterlms_order_status_active', array( $this, 'wpa_llms_track_order_complete' ), 10, 1 );
		// Track successful transactions (manual payments included).
		add_action( 'lifterlms_transaction_status_succeeded', array( $this, 'wpa_llms_track_purchase' ), 10, 1 );

		// Track refunds.
		add_action( 'lifterlms_order_status_refunded', array( $this, 'wpa_llms_track_refund' ), 10, 1 );
		add_action( 'lifterlms_order_status_cancelled', array( $this, 'wpa_llms_track_cancelled' ), 10, 1 );
		// Also track when a refund transaction is marked refunded manually.
		add_action( 'lifterlms_transaction_status_refunded', array( $this, 'wpa_llms_track_refund_transaction' ), 10, 1 );
		// Fallback: catch generic transaction status transitions (old -> new).
		add_action( 'lifterlms_transaction_status_transition', array( $this, 'wpa_llms_on_transaction_status_transition' ), 10, 3 );

		// Track checkout steps.
		add_action( 'lifterlms_before_checkout_form', array( $this, 'wpa_llms_track_checkout_billing' ) );
		add_action( 'llms_checkout_footer_before', array( $this, 'wpa_llms_track_checkout_payment' ) );

		// Store GA identity in order.
		add_action( 'lifterlms_created_order', array( $this, 'wpa_llms_store_ga_identity' ), 10, 1 );

		// Add dashboard dropdown option.
		add_action( 'analytify_dashboad_dropdown_option', array( $this, 'wpa_llms_dashboad_dropdown_option' ) );

		// Add source/medium meta box and column.
		add_action( 'add_meta_boxes', array( $this, 'wpa_llms_source_meta_box' ) );

		// Course list impressions.
		add_action( 'lifterlms_before_loop_item', array( $this, 'wpa_llms_feed_course_data' ) );
		add_action( 'wp_footer', array( $this, 'wpa_llms_print_course_data' ) );

		// Output tracking scripts.
		add_action( 'wp_footer', array( $this, 'wpa_llms_output_tracking_scripts' ), 999 );

		add_filter( 'analytify_install_ga_text', array( $this, 'wpa_llms_install_ga_text' ) );
		add_filter( 'analytify_admin_bar_menu', array( $this, 'wpa_llms_add_admin_bar_menu' ), 15, 1 );
	}

	/**
	 * Track course view.
	 *
	 * @since 9.0.0
	 * @return void
	 */
	public function wpa_llms_track_course_view() {
		if ( ! is_singular( 'course' ) ) {
			return;
		}

		global $post;
		$course_id = $post->ID;
		$course    = llms_get_post( $course_id );

		if ( ! $course || ! $this->is_track_user() || ! $this->is_ga_enable() ) {
			return;
		}

		// Only support GA4 - UA/GA3 is deprecated.
		$item  = $this->wpa_llms_get_tracked_item_ga4( $course_id );
		$price = isset( $item['price'] ) ? $item['price'] : 0;
		$code  = 'gtag("event", "wpa_view_course", {
			"value": ' . floatval( $price ) . ',
			"currency": "' . get_lifterlms_currency() . '",
			"wpa_label": "' . esc_js( get_the_title( $course_id ) ) . '",
			"items": [ ' . wp_json_encode( $item ) . ' ]
		});';

		$this->add_inline_js_wpa_llms( $code );
	}

	/**
	 * Track lesson view.
	 *
	 * @since 9.0.0
	 * @return void
	 */
	public function wpa_llms_track_lesson_view() {
		if ( ! is_singular( 'lesson' ) ) {
			return;
		}

		global $post;
		$lesson_id = $post->ID;
		$lesson    = llms_get_post( $lesson_id );

		if ( ! $lesson ) {
			return;
		}

		$course_id = $lesson->get( 'parent_course' );

		// Only support GA4 - UA/GA3 is deprecated.
		$session_id = $this->analytify_filter_session_id( $_COOKIE );
		$course     = llms_get_post( $course_id );
		$price      = $course ? $course->get_price( 'price', array(), 'float' ) : 0;
		$price      = is_numeric( $price ) ? floatval( $price ) : 0;

		$event[] = array(
			'name'   => 'wpa_view_lesson',
			'params' => array(
				'lesson_id'          => $lesson_id,
				'lesson_name'        => get_the_title( $lesson_id ),
				'course_id'          => $course_id,
				'course_name'        => get_the_title( $course_id ),
				'wpa_llms_post_type' => 'lesson',
				'wpa_label'          => get_the_title( $lesson_id ),
				'value'              => $price,
				'currency'           => get_lifterlms_currency(),
				'session_id'         => $session_id,
			),
		);

		$this->dispatch_ga4_event( $event );
	}

	/**
	 * Track enrollment.
	 *
	 * @param int $user_id User ID.
	 * @param int $course_id Course ID.
	 * @since 9.0.0
	 * @return void
	 */
	public function wpa_llms_track_enrollment( $user_id, $course_id ) {
		$course = llms_get_post( $course_id );

		if ( ! $course ) {
			return;
		}

		// Only support GA4 - UA/GA3 is deprecated.
		$session_id = $this->analytify_filter_session_id( $_COOKIE );
		$item       = $this->wpa_llms_get_tracked_item_ga4( $course_id );
		$price      = $course->get_price( 'price', array(), 'float' );
		$price      = is_numeric( $price ) ? floatval( $price ) : 0;

		$event[] = array(
			'name'   => 'wpa_course_enrollment',
			'params' => array(
				'currency'           => get_lifterlms_currency(),
				'value'              => $price,
				'items'              => array( $item ),
				'user_id'            => $user_id,
				'wpa_llms_post_type' => 'course',
				'wpa_label'          => get_the_title( $course_id ),
				'session_id'         => $session_id,
			),
		);

		$this->dispatch_ga4_event( $event );
	}

	/**
	 * Track order completion.
	 *
	 * @param object $order Order object.
	 * @since 9.0.0
	 * @return void
	 */
	public function wpa_llms_track_order_complete( $order ) {
		if ( ! is_a( $order, 'LLMS_Order' ) ) {
			$order = llms_get_order( $order );
		}

		if ( ! $order ) {
			return;
		}

		$order_id = $order->get( 'id' );

		// Don't track if already tracked.
		if ( 'yes' === get_post_meta( $order_id, '_analytify_llms_tracked_completed_payment', true ) ) {
			return;
		}

		// Only support GA4 - UA/GA3 is deprecated.
		$session_id = $this->analytify_filter_session_id( $_COOKIE );

		$event[] = array(
			'name'   => 'order_created',
			'params' => array(
				'currency'     => get_lifterlms_currency(),
				'wpa_category' => 'order_id',
				'wpa_label'    => $order_id,
				'session_id'   => $session_id,
			),
		);

		$this->dispatch_ga4_event( $event );
	}

	/**
	 * Track purchase transaction.
	 *
	 * @param object $transaction Transaction object.
	 * @since 9.0.0
	 * @return void
	 */
	public function wpa_llms_track_purchase( $transaction ) {
		// Resolve order from transaction (works for manual payments as well).
		if ( ! is_a( $transaction, 'LLMS_Transaction' ) ) {
			return;
		}
		$order = $transaction->get_order();
		if ( ! $order || ! is_a( $order, 'LLMS_Order' ) ) {
			return;
		}

		$order_id = $order->get( 'id' );

		// Don't track if already tracked.
		if ( 'yes' === get_post_meta( $order_id, '_analytify_llms_tracked_purchase', true ) ) {
			return;
		}

		// Only support GA4 - UA/GA3 is deprecated.
		$product_id = $order->get( 'product_id' );
		// Determine amount: prefer order total; fallback to transaction amount for manual payments.
		$amount = $order->get_price( 'total', array(), 'float' );
		if ( ! is_numeric( $amount ) || $amount <= 0 ) {
			$transaction_amount = method_exists( $transaction, 'get' ) ? $transaction->get( 'amount' ) : 0;
			if ( ! is_numeric( $transaction_amount ) || $transaction_amount <= 0 ) {
				$transaction_amount = method_exists( $transaction, 'get_price' ) ? $transaction->get_price( 'amount', array(), 'float' ) : 0;
			}
			$amount = is_numeric( $transaction_amount ) ? floatval( $transaction_amount ) : 0;
		}

		$item = $this->wpa_llms_get_tracked_item_ga4( $product_id, $amount );

		$session_id = $this->analytify_filter_session_id( $_COOKIE );

		// Get coupon code from order if available.
		$coupon_code = '';
		if ( method_exists( $order, 'get_coupon_codes' ) ) {
			$coupon_codes = $order->get_coupon_codes();
			$coupon_code  = ! empty( $coupon_codes ) ? implode( ',', $coupon_codes ) : '';
		} elseif ( $order->get( 'coupon_code' ) ) {
			$coupon_code = $order->get( 'coupon_code' );
		}

		$event[] = array(
			'name'   => 'purchase',
			'params' => array(
				'transaction_id' => $order->get( 'order_key' ),
				'value'          => $amount,
				'tax'            => 0,
				'shipping'       => 0,
				'currency'       => get_lifterlms_currency(),
				'coupon'         => $coupon_code,
				'user_id'        => $order->get( 'user_id' ),
				'items'          => array( $item ),
				'session_id'     => $session_id,
			),
		);

		$this->dispatch_ga4_event( $event );

		update_post_meta( $order_id, '_analytify_llms_tracked_purchase', 'yes' );
		update_post_meta( $order_id, '_analytify_llms_tracked_completed_payment', 'yes' );
	}

	/**
	 * Track refund.
	 *
	 * @param object $order Order object.
	 * @since 9.0.0
	 * @return void
	 */
	public function wpa_llms_track_refund( $order ) {
		if ( ! is_a( $order, 'LLMS_Order' ) ) {
			$order = llms_get_order( $order );
		}

		if ( ! $order ) {
			return;
		}

		$order_id = $order->get( 'id' );

		// Don't track if already tracked.
		if ( 'yes' === get_post_meta( $order_id, '_analytify_llms_refund_tracked', true ) ) {
			return;
		}

		// Only support GA4 - UA/GA3 is deprecated.
		$session_id = $this->analytify_filter_session_id( $_COOKIE );

		$event[] = array(
			'name'   => 'refund',
			'params' => array(
				'currency'     => get_lifterlms_currency(),
				'wpa_category' => 'transaction_id',
				'wpa_label'    => $order->get( 'order_key' ),
				'user_id'      => $order->get( 'user_id' ),
				'session_id'   => $session_id,
			),
		);

		$this->dispatch_ga4_event( $event );

		update_post_meta( $order_id, '_analytify_llms_refund_tracked', 'yes' );
	}

	/**
	 * Track refund via transaction hook (manual refunds UI).
	 *
	 * @param object $transaction Transaction object.
	 * @since 9.0.0
	 * @return void
	 */
	public function wpa_llms_track_refund_transaction( $transaction ) {
		if ( ! is_a( $transaction, 'LLMS_Transaction' ) ) {
			return;
		}

		$order_id = $transaction->get( 'order_id' );
		$order    = ( class_exists( 'LLMS_Order' ) && $order_id ) ? new LLMS_Order( $order_id ) : null;
		if ( ! $order ) {
			return;
		}
		// Avoid duplicate if order refund already tracked.
		if ( 'yes' === get_post_meta( $order->get( 'id' ), '_analytify_llms_refund_tracked', true ) ) {
			return;
		}

		$this->wpa_llms_track_refund( $order );
	}

	/**
	 * Catch generic transaction status transitions.
	 *
	 * @param string           $status_new   New status slug.
	 * @param string           $status_old   Old status slug.
	 * @param LLMS_Transaction $transaction Transaction object.
	 * @since 9.0.0
	 * @return void
	 */
	public function wpa_llms_on_transaction_status_transition( $status_new, $status_old, $transaction ) {
		if ( 'refunded' === $status_new || 'llms-txn-refunded' === $status_new ) {
			$this->wpa_llms_track_refund_transaction( $transaction );
		}
	}

	/**
	 * Track cancelled order.
	 *
	 * @param object $order Order object.
	 * @since 9.0.0
	 * @return void
	 */
	public function wpa_llms_track_cancelled( $order ) {
		if ( ! is_a( $order, 'LLMS_Order' ) ) {
			$order = llms_get_order( $order );
		}

		if ( ! $order || ! $this->is_track_user() ) {
			return;
		}

		$order_id = $order->get( 'id' );

		// Only support GA4 - UA/GA3 is deprecated.
		$event[] = array(
			'name'   => 'order_cancelled',
			'params' => array(
				'currency'     => get_lifterlms_currency(),
				'wpa_category' => 'order_id',
				'wpa_label'    => $order_id,
			),
		);

		$this->dispatch_ga4_event( $event );
	}

	/**
	 * Get product ID for current checkout (from ?plan= ID).
	 *
	 * @since 9.0.0
	 * @return int Product ID or 0.
	 */
	private function wpa_llms_get_checkout_product_id() {
		// Plan ID from public checkout URL (?plan=123), not a form post; sanitized with absint().
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$plan_id = isset( $_GET['plan'] ) ? absint( $_GET['plan'] ) : 0;
		if ( ! $plan_id || 'llms_access_plan' !== get_post_type( $plan_id ) || 'publish' !== get_post_status( $plan_id ) ) {
			return 0;
		}
		if ( ! class_exists( 'LLMS_Access_Plan' ) ) {
			return 0;
		}
		$plan       = new LLMS_Access_Plan( $plan_id );
		$product_id = $plan->get( 'product_id' );
		return $product_id ? absint( $product_id ) : 0;
	}

	/**
	 * Track checkout billing step.
	 *
	 * @since 9.0.0
	 * @return void
	 */
	public function wpa_llms_track_checkout_billing() {
		if ( ! $this->is_track_user() || ! $this->is_ga_enable() ) {
			return;
		}

		$product_id = $this->wpa_llms_get_checkout_product_id();
		if ( ! $product_id ) {
			return;
		}

		// Only support GA4 - UA/GA3 is deprecated.
		$item       = $this->wpa_llms_get_tracked_item_ga4( $product_id );
		$session_id = $this->analytify_filter_session_id( $_COOKIE );

		$event[] = array(
			'name'   => 'begin_checkout',
			'params' => array(
				'items'      => array( $item ),
				'session_id' => $session_id,
			),
		);

		$this->dispatch_ga4_event( $event );
	}

	/**
	 * Track checkout payment step.
	 *
	 * @since 9.0.0
	 * @return void
	 */
	public function wpa_llms_track_checkout_payment() {
		if ( ! $this->is_track_user() || ! $this->is_ga_enable() ) {
			return;
		}

		$product_id = $this->wpa_llms_get_checkout_product_id();
		if ( ! $product_id ) {
			return;
		}

		// Only support GA4 - UA/GA3 is deprecated.
		$item       = $this->wpa_llms_get_tracked_item_ga4( $product_id );
		$session_id = $this->analytify_filter_session_id( $_COOKIE );

		$event[] = array(
			'name'   => 'add_payment_info',
			'params' => array(
				'items'      => array( $item ),
				'session_id' => $session_id,
			),
		);

		$this->dispatch_ga4_event( $event );
	}

	/**
	 * Get tracked data for a single item for GA4.
	 *
	 * @param int   $product_id Product ID.
	 * @param float $price      Price override.
	 * @since 9.0.0
	 * @return array
	 */
	private function wpa_llms_get_tracked_item_ga4( $product_id, $price = null ) {
		$product = llms_get_post( $product_id );

		if ( ! $product ) {
			return array();
		}

		if ( is_null( $price ) ) {
			$price = $product->get_price( 'price', array(), 'float' );
			// Ensure price is numeric.
			$price = is_numeric( $price ) ? floatval( $price ) : 0;
		}

		$post_type      = get_post_type( $product_id );
		$categories     = get_the_terms( $product_id, 'course_cat' );
		$category_names = is_array( $categories ) ? wp_list_pluck( $categories, 'name' ) : array();
		$first_category = reset( $category_names );

		// Get instructor/author.
		$instructor_name = get_the_author_meta( 'display_name', $product->get( 'author' ) );

		return array(
			'item_id'             => $product_id,
			'item_name'           => get_the_title( $product_id ),
			'item_category'       => $first_category ? $first_category : '',
			'price'               => $price,
			'quantity'            => 1,
			'wpa_llms_post_type'  => $post_type,
			'wpa_llms_instructor' => $instructor_name,
		);
	}

	/**
	 * Get order items.
	 *
	 * @param object $order Order object.
	 * @since 9.0.0
	 * @return array
	 */
	public function wpa_llms_get_items( $order ) {
		$product_id = $order->get( 'product_id' );
		$product    = llms_get_post( $product_id );

		if ( ! $product ) {
			return array();
		}

		$categories         = get_the_terms( $product_id, 'course_cat' );
		$category_names     = is_array( $categories ) ? wp_list_pluck( $categories, 'name' ) : array();
		$category_hierarchy = implode( '/', $category_names );

		$params['pr1id'] = $product_id;
		$params['pr1nm'] = get_the_title( $product_id );
		$params['pr1ca'] = $category_hierarchy;
		$params['pr1br'] = '';
		$params['pr1pr'] = $order->get_price( 'total', array(), 'float' );
		$params['pr1qt'] = 1;
		$params['pr1va'] = '';

		return $params;
	}

	/**
	 * Store GA client ID in order meta.
	 *
	 * @param object $order Order object.
	 * @since 9.0.0
	 * @return string|null Client ID or null when empty.
	 */
	public function wpa_llms_store_ga_identity( $order ) {
		if ( ! is_a( $order, 'LLMS_Order' ) ) {
			return;
		}

		$order_id = $order->get( 'id' );
		$cid      = $this->get_ga_client_id( $order_id );

		// Store client ID in order meta if it is not empty.
		if ( ! empty( $cid ) && is_string( $cid ) ) {
			$cid = trim( $cid );
			update_post_meta( $order_id, 'analytify_llms_cid', $cid );
		}

		return ! is_string( $cid ) || '' === $cid ? null : $cid;
	}

	/**
	 * Send hits via the PHP API.
	 *
	 * @param array $attr  Attributes.
	 * @param bool  $debug Debug mode.
	 * @since 9.0.0
	 * @return void|false False when client ID is missing; otherwise void.
	 */
	public function wpa_llms_hit( $attr, $debug = false ) {
		$default_args = array(
			't'  => 'event',
			'ec' => '',
			'ea' => '',
			'el' => '',
			'ev' => null,
		);

		$body = array_merge( $default_args, $attr );

		$ip = $this->wpa_llms_get_client_ip();

		$user_language = isset( $_SERVER['HTTP_ACCEPT_LANGUAGE'] ) ? explode( ',', sanitize_text_field( wp_unslash( $_SERVER['HTTP_ACCEPT_LANGUAGE'] ) ) ) : array();
		$user_language = reset( $user_language );

		$default_body = array(
			'v'   => '1',
			'tid' => WP_ANALYTIFY_FUNCTIONS::get_UA_code(),
			'cid' => $this->get_ga_client_id(),
			't'   => 'pageview',
			'ni'  => true,
			'dh'  => str_replace( array( 'http://', 'https://' ), '', site_url() ),
			'dp'  => isset( $_SERVER['REQUEST_URI'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '',
			'dt'  => get_the_title(),
			'ul'  => $user_language,
			'uip' => $ip,
			'ua'  => isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '',
		);

		$body = wp_parse_args( $body, $default_body );

		// Requests without ID are ignored by GA.
		if ( false === $body['cid'] ) {
			return false;
		}

		if ( $debug ) {
			$response = wp_remote_post(
				$this->google_debug_measurement_url,
				array(
					'method'   => 'POST',
					'timeout'  => '5',
					'blocking' => true,
					'body'     => array_merge( $body, array( 'z' => time() ) ),
				)
			);

			// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_print_r
			echo '<pre>' . esc_html( print_r( $response, true ) ) . '</pre>';
		} else {
			$response = wp_remote_post(
				$this->google_measurement_url,
				array(
					'method'   => 'POST',
					'timeout'  => '5',
					'blocking' => false,
					'body'     => array_merge( $body, array( 'z' => time() ) ),
				)
			);
		}
	}

	/**
	 * Feed course data for impression tracking.
	 *
	 * @since 9.0.0
	 * @return void
	 */
	public function wpa_llms_feed_course_data() {
		if ( 'gtag' !== ANALYTIFY_PRO_TRACKING_MODE ) {
			return;
		}

		global $post;

		if ( ! is_a( $post, 'WP_Post' ) || 'course' !== get_post_type( $post ) ) {
			return;
		}

		$course_id = $post->ID;
		$course    = llms_get_post( $course_id );

		if ( ! $course ) {
			return;
		}

		$item = $this->wpa_llms_get_tracked_item_ga4( $course_id );

		// Append the item to the list.
		$this->course_list[] = $item;
	}

	/**
	 * Print course list data.
	 *
	 * @since 9.0.0
	 * @return void
	 */
	public function wpa_llms_print_course_data() {
		// Check of all requirements are filled for tracking.
		$is_tracking_available = WPANALYTIFY_Utils::is_tracking_available( true );

		if ( ! $is_tracking_available || empty( $this->course_list ) ) {
			return;
		}

		// Only support GA4 - UA/GA3 is deprecated.
		$select_event = 'wpa_select_course';

		// Build course list.
		$this->add_inline_js_wpa_llms( 'const analytify_llms_course_list = {' );
		foreach ( $this->course_list as $course ) {
			$i_d = isset( $course['item_id'] ) ? $course['item_id'] : $course['id'];
			$this->add_inline_js_wpa_llms( " 'item_" . $i_d . "' : " . wp_json_encode( $course ) . ',' );
		}
		$this->add_inline_js_wpa_llms( '};' );

		foreach ( $this->course_list as $course ) {
			$i_d   = isset( $course['item_id'] ) ? $course['item_id'] : $course['id'];
			$price = isset( $course['price'] ) ? $course['price'] : 0;

			$this->add_inline_js_wpa_llms(
				"
			jQuery( 'body' ).on( 'click', '.llms-loop-item.post-" . $i_d . " a', function() {
				gtag( 'event', '" . $select_event . "', { 
					content_type : 'course', 
					value: " . floatval( $price ) . ",
					currency: '" . get_lifterlms_currency() . "',
					wpa_label: '" . esc_js( get_the_title( $i_d ) ) . "',
					items: analytify_llms_course_list.item_" . $i_d . ' 
				} );
			});
			'
			);
		}

		// Course impression.
		$total_value = 0;
		foreach ( $this->course_list as $course ) {
			$total_value += isset( $course['price'] ) ? floatval( $course['price'] ) : 0;
		}

		$this->add_inline_js_wpa_llms(
			"
			gtag('event', 'wpa_view_course_list', {
				value: " . $total_value . ",
				currency: '" . get_lifterlms_currency() . "',
				wpa_label: 'Course List',
				items: Object.values(analytify_llms_course_list)
			});
		"
		);
	}

	/**
	 * Add inline JS for LifterLMS tracking.
	 *
	 * @param string $code JavaScript code to add.
	 * @since 9.0.0
	 * @return void
	 */
	public function add_inline_js_wpa_llms( $code ) {
		$this->tracking_scripts[] = $code;
	}

	/**
	 * Output tracking scripts in footer.
	 *
	 * @since 9.0.0
	 * @return void
	 */
	public function wpa_llms_output_tracking_scripts() {
		if ( empty( $this->tracking_scripts ) ) {
			return;
		}

		echo '<script type="text/javascript">' . "\n";
		echo '/* Analytify LifterLMS Tracking */' . "\n";
		foreach ( $this->tracking_scripts as $script ) {
			// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Script content is built from trusted plugin code; dynamic values use esc_js/wp_json_encode.
			echo $script . "\n";
		}
		echo '</script>' . "\n";
	}

	/**
	 * Add Metabox on order page.
	 *
	 * @since 9.0.0
	 * @return void
	 */
	public function wpa_llms_source_meta_box() {
		add_meta_box( 'analytify_llms_source', __( 'Source/Medium', 'wp-analytify-pro' ), array( $this, 'wpa_llms_get_source_medium' ), 'llms_order', 'side', 'core' );
	}

	/**
	 * Get Order Source/Medium.
	 *
	 * @since 9.0.0
	 * @return void
	 */
	public function wpa_llms_get_source_medium() {
		global $post;

		$source = get_post_meta( $post->ID, 'analytify_llms_order_source', true );

		if ( ! $source ) {
			$post_date  = get_the_date( 'Y-m-d', $post->ID );
			$start_date = gmdate( 'Y-m-d', strtotime( $post_date . '-5 days' ) );
			$end_date   = gmdate( 'Y-m-d', strtotime( $post_date . '+5 days' ) );

			// Only support GA4 - UA/GA3 is deprecated.
			$stats = $GLOBALS['WP_ANALYTIFY']->get_reports(
				'analytify_llms_order_source',
				array(),
				array(
					'start' => $start_date,
					'end'   => $end_date,
				),
				array(
					'sourceMedium',
					'transactionId',
				),
				array(),
				array(
					'logic'   => 'AND',
					'filters' => array(
						array(
							'type'       => 'dimension',
							'name'       => 'transactionId',
							'match_type' => 1,
							'value'      => $post->ID,
						),
					),
				),
				0,
				false
			);

			if ( ! empty( $stats['rows'][0]['sourceMedium'] ) ) {
				update_post_meta( $post->ID, 'analytify_llms_order_source', $stats['rows'][0]['sourceMedium'] );
			}
		}

		echo esc_html( $source );
	}

	/**
	 * Add dropdown option for llms dashboard.
	 *
	 * @since 9.0.0
	 * @return void
	 */
	public function wpa_llms_dashboad_dropdown_option() {
		echo '<li><a href="' . esc_url( admin_url( 'admin.php?page=analytify-lifterlms' ) ) . '">LifterLMS</a></li>';
	}

	/**
	 * Add menu for LifterLMS dashboard page.
	 *
	 * @access public
	 * @since 9.0.0
	 * @return void
	 */
	public static function wpa_llms_add_menu() {
		add_submenu_page( 'analytify-dashboard', esc_html__( 'Track everything in LifterLMS with Analytify.', 'wp-analytify-pro' ), esc_html__( 'LifterLMS', 'wp-analytify-pro' ), 'edit_posts', 'analytify-lifterlms', array( __CLASS__, 'wpa_llms_analytify_page_file_path' ), 16 );
	}

	/**
	 * Include file for LifterLMS dashboard page.
	 *
	 * @access public
	 * @since 9.0.0
	 * @return void
	 */
	public static function wpa_llms_analytify_page_file_path() {
		$screen = get_current_screen();

		if ( strpos( $screen->base, 'analytify-lifterlms' ) !== false ) {
			include LLMS_ANALYTIFY_PLUGIN_DIR . '/includes/lifterlms-dashboard.php';
		}
	}

	/**
	 * Initialize e-commerce JS.
	 *
	 * @since 9.0.0
	 * @return void
	 */
	public static function wpa_llms_add_ga_ecommerce_js() {
		// Only support GA4 - UA/GA3 is deprecated.
		// Set the currency.
		echo "gtag('set', {currency: '" . esc_js( get_lifterlms_currency() ) . "'});";
	}

	/**
	 * Display notices for LifterLMS users.
	 *
	 * @since 9.0.0
	 * @return void
	 */
	public function wpa_llms_show_admin_notices() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
	}

	/**
	 * Change Install GA text.
	 *
	 * @since 9.0.0
	 * @return string
	 */
	public function wpa_llms_install_ga_text() {
		return __( 'Insert Google Analytics (GA) JavaScript code between the HEADER tags in your website. Check this option if you have installed Analytify E-Commerce add-ons for E-commerce Tracking.', 'wp-analytify-pro' );
	}

	/**
	 * Get IP by using LifterLMS helper.
	 *
	 * @since 9.0.0
	 * @return string
	 */
	private function wpa_llms_get_client_ip() {
		if ( function_exists( 'llms_get_ip_address' ) ) {
			return llms_get_ip_address();
		}
		return isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	}

	/**
	 * Add option in admin bar.
	 *
	 * @param array $menus Menus.
	 * @since 9.0.0
	 * @return array
	 */
	public function wpa_llms_add_admin_bar_menu( $menus ) {
		$menus['analytify-lifterlms'] = __( 'LifterLMS', 'wp-analytify-pro' );
		return $menus;
	}


	/**
	 * Delete transients for LifterLMS dashboard to refresh data.
	 *
	 * @param string $dashboard_profile_id The reporting profile ID.
	 * @param string $start_date The start date of the reporting period.
	 * @param string $end_date The end date of the reporting period.
	 * @since 9.0.0
	 * @return void
	 */
	public static function wpa_llms_delete_transients( $dashboard_profile_id, $start_date, $end_date ) {

		$report_names = array(
			'show-llms-general-stats',
			'show-llms-sessions',
			'show-llms-purchase-journey',
			'show-llms-refunds',
			'show-llms-top-courses',
			'show-llms-traffic-sources',
			'show-llms-user-journeys',
			'show-llms-course-insights',
			'show-llms-coupons',
		);

		// Dynamic event names.
		$event_names = array(
			'wpa_view_course',
			'wpa_view_course_list',
			'wpa_select_course',
			'wpa_view_lesson',
			'wpa_course_enrollment',
		);

		foreach ( $event_names as $event_name ) {
			$report_names[] = 'custom-event-' . $event_name;
			$report_names[] = 'custom-event-total-' . $event_name;
		}

		// Funnel steps.
		$funnel_steps = array(
			'begin_checkout',
			'add_payment_info',
			'purchase',
		);

		foreach ( $funnel_steps as $step ) {
			$report_names[] = 'llms-funnel-' . $step;
		}

		foreach ( $report_names as $name ) {
			$cache_key = 'analytify_transient_' . md5( $name . $dashboard_profile_id . $start_date . $end_date );
			delete_transient( $cache_key );
		}
	}
}
