<?php
/**
 * LifterLMS Integration Loader for Analytify.
 *
 * @package    Analytify
 * @subpackage LifterLMS
 * @since      9.0.0
 */

// phpcs:ignoreFile WordPress.Files.FileName.InvalidClassFileName

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Analytify LifterLMS Loader Class.
 */
class Analytify_LifterLMS_Loader {

	/**
	 * Option key for dismissed LifterLMS addon notices (array of notice IDs).
	 */
	const DISMISSED_NOTICES_OPTION = 'analytify_llms_dismissed_notices';

	/**
	 * Instance of this class.
	 *
	 * @var object
	 */
	public static $instance;

	/**
	 * Whether any admin notice was rendered this request (for conditional script output).
	 *
	 * @var bool
	 */
	private $notice_rendered = false;

	/**
	 * Asset cache-bust string (matches Analytify Pro when loaded as a Pro module).
	 *
	 * @var string
	 */
	public $version;

	/**
	 * Get the singleton instance.
	 *
	 * @since 9.0.0
	 * @return Analytify_LifterLMS_Loader
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 *
	 * @since 9.0.0
	 */
	public function __construct() {
		$this->define_constants();
		$this->version = defined( 'ANALYTIFY_PRO_VERSION' ) ? ANALYTIFY_PRO_VERSION : ( defined( 'ANALYTIFY_VERSION' ) ? ANALYTIFY_VERSION : '1.0.0' );
		$this->hooks();
		$this->may_be_load_addon();
	}

	/**
	 * Load the addon if dependencies are met.
	 *
	 * @since 9.0.0
	 */
	public function may_be_load_addon() {
		if ( ! class_exists( 'LifterLMS' ) ) {
			add_action( 'admin_enqueue_scripts', array( $this, 'wpa_llms_notices_scripts' ) );
			return;
		}
		if ( ! file_exists( WP_PLUGIN_DIR . '/wp-analytify-pro/wp-analytify-pro.php' )
			|| ! function_exists( 'wp_analytify_pro_load' )
			|| ! class_exists( 'WP_Analytify_Pro_Base' ) ) {
			add_action( 'admin_enqueue_scripts', array( $this, 'wpa_llms_notices_scripts' ) );
			return;
		}
		include_once ANALYTIFY_PRO_LIFTERLMS_ADDON_ROOT_PATH . '/class-wp-analytify-lifterlms-addon.php';
		// Global for backwards compatibility.
		$GLOBALS['WPAnalytifyProLifterLMS'] = WP_Analytify_LifterLMS_Addon::instance();
	}

	/**
	 * Define constants.
	 *
	 * @since 9.0.0
	 */
	public function define_constants() {
		if ( ! defined( 'ANALYTIFY_PRO_LIFTERLMS_ADDON_ROOT_PATH' ) ) {
			define( 'ANALYTIFY_PRO_LIFTERLMS_ADDON_ROOT_PATH', __DIR__ );
		}
		if ( ! defined( 'ANALYTIFY_PRO_LIFTERLMS_UPGRADE_PATH' ) ) {
			define( 'ANALYTIFY_PRO_LIFTERLMS_UPGRADE_PATH', __FILE__ );
		}
		// Set to default if tracking mode not set.
		if ( ! defined( 'ANALYTIFY_PRO_TRACKING_MODE' ) ) {
			define( 'ANALYTIFY_PRO_TRACKING_MODE', 'gtag' );
		}
	}

	/**
	 * Setup hooks.
	 *
	 * @since 9.0.0
	 */
	public function hooks() {
		add_action( 'admin_notices', array( $this, 'wpa_llms_admin_notices' ) );
		add_action( 'init', array( $this, 'wpa_llms_load_text_domain' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'wpa_llms_admin_styles' ) );
		add_action( 'admin_footer', array( $this, 'wpa_llms_notice_script' ) );
		add_action( 'wp_ajax_dismiss_analytify_notice', array( $this, 'wpa_llms_dismiss_notice' ) );
	}

	/**
	 * Single admin notices callback: run dependency checks and show one notice if needed.
	 *
	 * @since 9.0.0
	 * @return void
	 */
	public function wpa_llms_admin_notices() {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen || ! is_object( $screen ) ) {
			return;
		}

		$allowed_parent_bases = array(
			'analytify-addons',
			'analytify-dashboard',
			'analytify-license',
			'analytify-settings',
			'dashboard',
			'plugins',
		);

		$allowed_screen_ids = array(
			'dashboard',
			'plugins',
			'plugins-network',
		);

		$page       = isset( $_GET['page'] ) ? sanitize_text_field( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$is_allowed = in_array( $screen->parent_base, $allowed_parent_bases, true )
			|| in_array( $screen->id, $allowed_screen_ids, true )
			|| ( ! empty( $page ) && strpos( $page, 'analytify' ) === 0 );

		if ( ! $is_allowed ) {
			return;
		}
		if ( ! file_exists( WP_PLUGIN_DIR . '/wp-analytify-pro/wp-analytify-pro.php' ) ) {
			$this->wpa_llms_notice( __( '<strong>Attention:</strong> Please install Analytify Pro to use Analytify for LifterLMS addon.', 'wp-analytify-pro' ), 'wp-analytify-danger' );
			return;
		}
		if ( ! class_exists( 'WP_Analytify_Pro_Base' ) ) {
			$this->wpa_llms_notice( __( '<strong>Attention: </strong> Please activate Analytify Pro to use Analytify for LifterLMS addon.', 'wp-analytify-pro' ), 'wp-analytify-danger' );
			return;
		}
		if ( ! file_exists( WP_PLUGIN_DIR . '/lifterlms/lifterlms.php' ) ) {
			$this->wpa_llms_notice( __( '<strong>Attention:</strong> Analytify for LifterLMS addon works with LifterLMS plugin. Please Install LifterLMS plugin.', 'wp-analytify-pro' ), 'wp-analytify-danger' );
			return;
		}
		if ( ! class_exists( 'LifterLMS' ) ) {
			$this->wpa_llms_notice( __( '<strong>Attention:</strong> Analytify for LifterLMS addon works with LifterLMS plugin. Please activate LifterLMS plugin.', 'wp-analytify-pro' ), 'wp-analytify-danger' );
		}
	}

	/**
	 * Admin notices scripts.
	 *
	 * @since 9.0.0
	 * @return void
	 */
	public function wpa_llms_notices_scripts() {
		wp_enqueue_style( 'analytify-llms-notices', plugins_url( 'assets/css/notices' . analytify_pro_get_asset_suffix() . '.css', __FILE__ ), '', $this->version );
	}

	/**
	 * Admin styles and scripts. Sort-tables script only on LifterLMS addon page so dependency analytify-table-sorting is available (enqueued by Pro).
	 *
	 * @since 9.0.0
	 * @param string $hook_suffix Current admin page hook suffix.
	 * @return void
	 */
	public function wpa_llms_admin_styles( $hook_suffix = '' ) {
		wp_enqueue_style( 'wp-analytify-llms-funnel-style', plugins_url( 'assets/css/funnel' . analytify_pro_get_asset_suffix() . '.css', __FILE__ ), false, $this->version );
		// Only enqueue sort-tables on the LifterLMS addon dashboard page where Pro enqueues analytify-table-sorting.
		if ( 'analytify_page_analytify-lifterlms' === $hook_suffix ) {
			wp_enqueue_script(
				'analytify-lifterlms-sort-tables',
				plugins_url( 'assets/js/sort-tables' . analytify_pro_get_asset_suffix() . '.js', __FILE__ ),
				array( 'jquery', 'analytify-table-sorting' ),
				$this->version,
				true
			);
		}
	}

	/**
	 * Load TextDomain.
	 *
	 * @since 9.0.0
	 * @return void
	 */
	public function wpa_llms_load_text_domain() {
		$plugin_dir = basename( __DIR__ );
		load_plugin_textdomain( 'wp-analytify-lifterlms', false, $plugin_dir . '/languages/' );
	}

	/**
	 * Add custom admin notice.
	 *
	 * @param string $message      Custom message.
	 * @param string $notice_class CSS class: wp-analytify-success or wp-analytify-danger.
	 * @since 9.0.0
	 * @return void
	 */
	public function wpa_llms_notice( $message, $notice_class = 'wp-analytify-success' ) {
		$message   = is_string( $message ) ? $message : '';
		$notice_id = 'analytify_llms_notice_' . md5( $message );
		$dismissed  = get_option( self::DISMISSED_NOTICES_OPTION, array() );
		if ( ! is_array( $dismissed ) || ! in_array( $notice_id, $dismissed, true ) ) {
			$this->notice_rendered = true;
			echo '<div class="wp-analytify-notification ' . esc_attr( $notice_class ) . '" id="' . esc_attr( $notice_id ) . '">
					<a class="wp-analytify-notice-dismiss" href="#" aria-label="' . esc_attr__( 'Dismiss the notice', 'wp-analytify-pro' ) . '" onclick="dismissAnalytifyNotice(\'' . esc_js( $notice_id ) . '\'); return false;">&times;</a>
					<div class="wp-analytify-notice-logo">
						<img src="' . esc_url( plugins_url( 'assets/img/logo.svg', __FILE__ ) ) . '" alt="notice">
					</div>
					<div class="wp-analytify-notice-discription">
						<p>' . wp_kses_post( $message ) . '</p>
					</div>
				</div>';
		}
	}

	/**
	 * Notice dismiss script. Only output when a notice was actually rendered.
	 *
	 * @since 9.0.0
	 * @return void
	 */
	public function wpa_llms_notice_script() {
		if ( ! $this->notice_rendered ) {
			return;
		}
		?>
		<script type="text/javascript">
		(function($) {
			"use strict";
			window.dismissAnalytifyNotice = function(noticeId) {
				var el = document.getElementById(noticeId);
				if (el) {
					el.style.display = 'none';
				}
				$.post('<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>', {
					action: 'dismiss_analytify_notice',
					notice_id: noticeId,
					nonce: '<?php echo esc_js( wp_create_nonce( 'dismiss_analytify_notice' ) ); ?>'
				});
			};
		})(jQuery);
		</script>
		<?php
	}

	/**
	 * Dismiss notice handler.
	 *
	 * @since 9.0.0
	 * @return void
	 */
	public function wpa_llms_dismiss_notice() {
		if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'dismiss_analytify_notice' ) ) {
			wp_send_json_error( esc_html__( 'Invalid nonce', 'wp-analytify-pro' ) );
			return;
		}

		if ( isset( $_POST['notice_id'] ) ) {
			$notice_id = sanitize_text_field( wp_unslash( $_POST['notice_id'] ) );
			$dismissed = get_option( self::DISMISSED_NOTICES_OPTION, array() );
			if ( ! is_array( $dismissed ) ) {
				$dismissed = array();
			}
			if ( ! in_array( $notice_id, $dismissed, true ) ) {
				$dismissed[] = $notice_id;
				update_option( self::DISMISSED_NOTICES_OPTION, $dismissed );
			}
			wp_send_json_success();
		} else {
			wp_send_json_error();
		}
	}
}

Analytify_LifterLMS_Loader::get_instance();

