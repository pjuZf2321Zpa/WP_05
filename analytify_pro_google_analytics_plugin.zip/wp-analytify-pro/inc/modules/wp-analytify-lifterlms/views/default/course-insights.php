<?php
/**
 * LifterLMS Course Insights View
 *
 * @package WP_Analytify_Pro
 * @subpackage Modules\LifterLMS\Views
 * @since 9.0.0
 */

/**
 * Course insights report for LifterLMS.
 *
 * @param object $current     WP_Analytify instance.
 * @param array  $raw_stats   Stats from GA4.
 * @since 9.0.0
 * @return void
 */
function llms_analytify_course_insights( $current, $raw_stats ) {

	ob_start();

	?>
	<div class="analytify_general_status analytify_status_box_wraper">

		<div class="analytify_status_header">
			<h3><?php esc_html_e( 'Course Page Insights', 'wp-analytify-pro' ); ?></h3>
		</div>

		<div class="analytify_status_body">
			<?php if ( ! empty( $raw_stats['rows'] ) ) : ?>
				<table class="analytify_data_tables wp_analytify_paginated" data-product-per-page="10">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Page Title', 'wp-analytify-pro' ); ?></th>
							<th><?php esc_html_e( 'Views', 'wp-analytify-pro' ); ?></th>
							<th><?php esc_html_e( 'Bounce Rate', 'wp-analytify-pro' ); ?></th>
							<th><?php esc_html_e( 'Avg. Engagement Time', 'wp-analytify-pro' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $raw_stats['rows'] as $row ) : ?>
							<?php
							$page_title      = isset( $row['pageTitle'] ) ? $row['pageTitle'] : __( '(not set)', 'wp-analytify-pro' );
							$views           = isset( $row['screenPageViews'] ) ? number_format( $row['screenPageViews'] ) : 0;
							$bounce_rate     = isset( $row['bounceRate'] ) ? number_format( $row['bounceRate'] * 100, 2 ) . '%' : '0.00%';
							$engagement_time = isset( $row['userEngagementDuration'] ) ? gmdate( 'i:s', $row['userEngagementDuration'] ) : '00:00';
							?>
							<tr>
								<td><?php echo esc_html( $page_title ); ?></td>
								<td><?php echo esc_html( $views ); ?></td>
								<td><?php echo esc_html( $bounce_rate ); ?></td>
								<td><?php echo esc_html( $engagement_time ); ?></td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			<?php else : ?>
				<div class="analytify-stats-error-msg">
					<div class="wpb-error-box">
						<span class="blk">
							<span class="line"></span>
							<span class="dot"></span>
						</span>
						<span class="information-txt"><?php esc_html_e( 'No Activity During This Period.', 'wp-analytify-pro' ); ?></span>
					</div>
				</div>
			<?php endif; ?>
		</div>

	</div>

	<?php
	wp_send_json(
		array(
			'body' => ob_get_clean(),
		)
	);
}

