<?php
/**
 * LifterLMS Coupons View
 *
 * @package WP_Analytify_Pro
 * @subpackage Modules\LifterLMS\Views
 * @since 9.0.0
 */

/**
 * Coupons report view.
 *
 * @param object $current   WP_Analytify instance.
 * @param array  $raw_stats Stats from GA4.
 * @since 9.0.0
 * @return void
 */
function llms_analytify_coupons( $current, $raw_stats ) {

	ob_start();

	?>
	<div class="analytify_general_status analytify_status_box_wraper">
		<div class="analytify_status_header">
			<h3><?php esc_html_e( 'Top Coupons', 'wp-analytify-pro' ); ?></h3>
		</div>
		<div class="analytify_status_body">
			<table class="analytify_data_tables wp_analytify_paginated" data-product-per-page="10">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Coupon', 'wp-analytify-pro' ); ?></th>
						<th><?php esc_html_e( 'Purchases', 'wp-analytify-pro' ); ?></th>
						<th><?php esc_html_e( 'Revenue', 'wp-analytify-pro' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php
					$not_set_label = __( '(not set)', 'wp-analytify-pro' );
					$coupon_rows   = array();
					if ( ! empty( $raw_stats['rows'] ) ) {
						foreach ( $raw_stats['rows'] as $row ) {
							$code = isset( $row['orderCoupon'] ) ? trim( (string) $row['orderCoupon'] ) : '';
							if ( '' !== $code && $not_set_label !== $code ) {
								$coupon_rows[] = $row;
							}
						}
					}
					if ( ! empty( $coupon_rows ) ) :
						?>
						<?php foreach ( $coupon_rows as $row ) : ?>
							<?php
							$code      = isset( $row['orderCoupon'] ) ? $row['orderCoupon'] : '';
							$purchases = isset( $row['ecommercePurchases'] ) ? (int) $row['ecommercePurchases'] : 0;
							$revenue   = isset( $row['purchaseRevenue'] ) ? (float) $row['purchaseRevenue'] : 0;
							?>
							<tr>
								<td><?php echo esc_html( $code ); ?></td>
								<td><?php echo esc_html( number_format_i18n( $purchases ) ); ?></td>
								<td><?php echo esc_html( number_format_i18n( $revenue, 2 ) ); ?></td>
							</tr>
						<?php endforeach; ?>
					<?php else : ?>
						<tr>
							<td colspan="3" class="analytify_td_error_msg">
								<div class="analytify-stats-error-msg">
									<div class="wpb-error-box">
										<span class="blk">
											<span class="line"></span>
											<span class="dot"></span>
										</span>
										<span class="information-txt"><?php esc_html_e( 'No Activity During This Period.', 'wp-analytify-pro' ); ?></span>
									</div>
								</div>
							</td>
						</tr>
					<?php endif; ?>
				</tbody>
			</table>
		</div>
	</div>
	<?php

	wp_send_json(
		array(
			'body' => ob_get_clean(),
		)
	);
}


