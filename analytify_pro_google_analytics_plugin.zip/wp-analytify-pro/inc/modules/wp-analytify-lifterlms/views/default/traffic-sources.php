<?php
/**
 * LifterLMS Traffic Sources View
 *
 * @package WP_Analytify_Pro
 * @subpackage Modules\LifterLMS\Views
 * @since 9.0.0
 */

/**
 * Traffic sources report for LifterLMS.
 *
 * @param object $current   WP_Analytify instance.
 * @param array  $raw_stats Stats from GA4.
 * @since 9.0.0
 * @return void
 */
function llms_analytify_traffic_sources( $current, $raw_stats ) {

	ob_start();

	$currency_code   = isset( $raw_stats['currencyCode'] ) && '(not set)' !== $raw_stats['currencyCode'] ? $raw_stats['currencyCode'] : get_lifterlms_currency();
	$currency_symbol = get_lifterlms_currency_symbol( $currency_code );

	?>
	<div class="analytify_general_status analytify_status_box_wraper">

		<div class="analytify_status_header">
			<h3><?php esc_html_e( 'Top Traffic Sources', 'wp-analytify-pro' ); ?></h3>
		</div>

		<div class="analytify_status_body">
			<table class="analytify_data_tables wp_analytify_paginated" data-product-per-page="10">
				<thead>
					<tr>
						<th class="analytify_table_header_no_events">#</th>
						<th><?php esc_html_e( 'Source/Medium', 'wp-analytify-pro' ); ?></th>
						<th><?php esc_html_e( 'Sessions', 'wp-analytify-pro' ); ?></th>
						<th><?php esc_html_e( 'Bounce Rate', 'wp-analytify-pro' ); ?></th>
						<th><?php esc_html_e( 'Transactions Revenue', 'wp-analytify-pro' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php if ( ! empty( $raw_stats['rows'] ) ) : ?>
						<?php
						$i = 0;
						foreach ( $raw_stats['rows'] as $row ) :
							++$i;
							$source_medium = isset( $row['sourceMedium'] ) ? $row['sourceMedium'] : __( '(not set)', 'wp-analytify-pro' );
							$sessions      = isset( $row['sessions'] ) ? $row['sessions'] : 0;
							$bounce_rate   = isset( $row['bounceRate'] ) ? $row['bounceRate'] : 0;
							$revenue       = isset( $row['purchaseRevenue'] ) ? $row['purchaseRevenue'] : 0;
							$currency_code = isset( $row['currencyCode'] ) && '(not set)' !== $row['currencyCode'] ? $row['currencyCode'] : get_lifterlms_currency();
							?>
							<tr>
								<td><?php echo esc_html( $i ); ?></td>
								<td><?php echo esc_html( $source_medium ); ?></td>
								<td class="analytify_txt_center"><?php echo esc_html( WPANALYTIFY_Utils::pretty_numbers( $sessions ) ); ?></td>
								<td class="analytify_txt_center"><?php echo esc_html( WPANALYTIFY_Utils::pretty_numbers( $bounce_rate ) . '%' ); ?></td>
								<td class="analytify_txt_center">
									<?php
									$currency_symbol = get_lifterlms_currency_symbol( $currency_code );
									echo esc_html( $currency_symbol . number_format_i18n( $revenue, 2 ) );
									?>
								</td>
							</tr>
						<?php endforeach; ?>
					<?php else : ?>
						<tr>
							<td class='analytify_td_error_msg' colspan='5'>
								<div class="analytify-stats-error-msg">
									<div class="wpb-error-box">
										<span class="blk">
											<span class="line"></span>
											<span class="dot"></span>
										</span>
										<span class="information-txt"><?php esc_html_e( 'No Activity During This Period.', 'wp-analytify-pro' ); ?></span>
									</div>
								</div>
							</td>
						</tr>
					<?php endif; ?>
				</tbody>
			</table>
		</div>

	</div>

	<?php
	wp_send_json(
		array(
			'body' => ob_get_clean(),
		)
	);
}

