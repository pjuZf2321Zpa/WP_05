<?php
/**
 * LifterLMS Funnel View
 *
 * @package WP_Analytify_Pro
 * @subpackage Modules\LifterLMS\Views
 * @since 9.0.0
 */

/**
 * Checkout funnel view.
 *
 * @param object $current WP_Analytify instance.
 * @param array  $steps   Funnel steps counts.
 * @since 9.0.0
 * @return void
 */
function llms_analytify_funnel( $current, $steps ) {

	$begin    = isset( $steps['begin_checkout'] ) ? (int) $steps['begin_checkout'] : 0;
	$payment  = isset( $steps['add_payment_info'] ) ? (int) $steps['add_payment_info'] : 0;
	$purchase = isset( $steps['purchase'] ) ? (int) $steps['purchase'] : 0;

	$conversion_rates = array(
		'checkout_to_payment' => ( $begin > 0 ) ? round( ( $payment / $begin ) * 100, 2 ) : 0,
		'payment_to_purchase' => ( $payment > 0 ) ? round( ( $purchase / $payment ) * 100, 2 ) : 0,
	);

	$data = array(
		array(
			'value'     => 1500,
			'name'      => esc_html__( 'Begin Checkout', 'wp-analytify-pro' ),
			'itemStyle' => array( 'color' => '#f5a623' ),
			'actual'    => $begin,
		),
		array(
			'value'     => 1000,
			'name'      => esc_html__( 'Add Payment Info', 'wp-analytify-pro' ),
			'itemStyle' => array( 'color' => '#7ed321' ),
			'actual'    => $payment,
		),
		array(
			'value'     => 500,
			'name'      => esc_html__( 'Purchase', 'wp-analytify-pro' ),
			'itemStyle' => array( 'color' => '#4a90e2' ),
			'actual'    => $purchase,
		),
	);

	ob_start();
	?>

	<div class="analytify_general_status analytify_status_box_wraper">
		<div class="analytify_status_header">
			<h3><?php esc_html_e( 'LifterLMS Funnel', 'wp-analytify-pro' ); ?></h3>
		</div>

		<table class="analytify_data_tables">
			<thead>
				<tr>
					<th class="no-header"></th>
					<th class="right-align header-center">
						<?php esc_html_e( 'Conversion Rate by Stages', 'wp-analytify-pro' ); ?>
					</th>
				</tr>
			</thead>
		</table>

		<div class="analytify_status_body">
			<?php if ( $begin > 0 || $payment > 0 || $purchase > 0 ) : ?>
				<div class="funnel-wrapper">
					<div class="analytify_funnel-chart-container">
						<div class="analytify_funnel-chart">
							<div id="analytify-llms-funnel-chart"></div>
						</div>

						<div class="conversion-rates">
							<?php
							printf(
								'<p class="checkout-conversion">%s</p>',
								esc_html( number_format_i18n( $conversion_rates['checkout_to_payment'], 2 ) . '%' )
							);
							printf(
								'<p class="payment-conversion">%s</p>',
								esc_html( number_format_i18n( $conversion_rates['payment_to_purchase'], 2 ) . '%' )
							);
							?>
						</div>
					</div>
				</div>
			<?php else : ?>
				<div class="analytify-stats-error-msg">
					<div class="wpb-error-box">
						<span class="blk">
							<span class="line"></span>
							<span class="dot"></span>
						</span>
						<span class="information-txt"><?php esc_html_e( 'No Activity During This Period.', 'wp-analytify-pro' ); ?></span>
					</div>
				</div>
			<?php endif; ?>
		</div>
	</div>

	<script type="text/javascript">
		function initLifterLMSFunnel() {
			// Check if ECharts is available
			if (typeof echarts === 'undefined') {
				setTimeout(initLifterLMSFunnel, 1000);
				return;
			}
			
			var analytify_llms_funnel_chartId = document.getElementById('analytify-llms-funnel-chart');
			if (!analytify_llms_funnel_chartId) {
				return;
			}

			try {
				var analytify_llms_chart = echarts.init(analytify_llms_funnel_chartId);

				// Dynamic data from PHP
				var funnelData = <?php echo wp_json_encode( $data ); ?>;

				var option = {
					series: [
						{
							name: 'Conversion Rate',
							type: 'funnel',
							left: '10%',
							top: 20,
							bottom: 20,
							width: '80%',
							min: 0,
							max: 1500,
							minSize: '0%',
							maxSize: '100%',
							sort: 'descending',
							gap: 10,
							label: {
								show: true,
								position: 'inside',
								formatter: function (params) {
									return `${params.name}\n${params.data.actual}`;
								},
								color: '#fff',
								fontSize: 17
							},
							labelLine: {
								show: true,
								length: 30,
								lineStyle: {
									type: 'dashed',
									color: '#aaa',
								},
							},
							itemStyle: {
								borderColor: '#fff',
								borderWidth: 2,
								borderRadius: 8,
							},
							emphasis: {
								label: {
									fontSize: 19,
								},
							},
							data: funnelData,
						},
					],
				};

				analytify_llms_chart.setOption(option);
				
				window.addEventListener('resize', function () {
					analytify_llms_chart.resize();
				});
			} catch (error) {
				// Silent error handling
			}
		}

		// Try to initialize immediately
		initLifterLMSFunnel();
		
		// Also try after DOM is ready
		document.addEventListener("DOMContentLoaded", function () {
			initLifterLMSFunnel();
		});
	</script>

	<?php

	wp_send_json( array( 'body' => ob_get_clean() ) );
}


