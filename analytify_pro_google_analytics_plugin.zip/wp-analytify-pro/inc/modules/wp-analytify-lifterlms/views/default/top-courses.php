<?php
/**
 * LifterLMS Top Courses View
 *
 * @package WP_Analytify_Pro
 * @subpackage Modules\LifterLMS\Views
 * @since 9.0.0
 */

/**
 * Top courses report for LifterLMS.
 *
 * @param object $current     WP_Analytify instance.
 * @param array  $raw_stats   Stats from GA4.
 * @since 9.0.0
 * @return void
 */
function llms_analytify_top_courses( $current, $raw_stats ) {

	ob_start();

	$currency_code   = isset( $raw_stats['currencyCode'] ) && '(not set)' !== $raw_stats['currencyCode'] ? $raw_stats['currencyCode'] : get_lifterlms_currency();
	$currency_symbol = get_lifterlms_currency_symbol( $currency_code );

	?>
	<div class="analytify_general_status analytify_status_box_wraper">

		<div class="analytify_status_header">
			<h3><?php esc_html_e( 'Top Courses', 'wp-analytify-pro' ); ?></h3>
		</div>

		<div class="analytify_status_body">
			<?php if ( ! empty( $raw_stats['rows'] ) ) : ?>
				<table class="analytify_data_tables wp_analytify_paginated" data-product-per-page="10">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Course Name', 'wp-analytify-pro' ); ?></th>
							<th><?php esc_html_e( 'Revenue', 'wp-analytify-pro' ); ?></th>
							<th><?php esc_html_e( 'Purchases', 'wp-analytify-pro' ); ?></th>
							<th><?php esc_html_e( 'Views', 'wp-analytify-pro' ); ?></th>
							<th><?php esc_html_e( 'Conversion Rate', 'wp-analytify-pro' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $raw_stats['rows'] as $row ) : ?>
							<?php
							$course_name = isset( $row['itemName'] ) ? $row['itemName'] : __( '(not set)', 'wp-analytify-pro' );
							$revenue     = isset( $row['itemRevenue'] ) ? $currency_symbol . number_format_i18n( $row['itemRevenue'], 2 ) : $currency_symbol . '0.00';
							$purchases   = isset( $row['itemsPurchased'] ) ? number_format_i18n( $row['itemsPurchased'] ) : number_format_i18n( 0 );
							$views       = isset( $row['itemsViewed'] ) ? number_format_i18n( $row['itemsViewed'] ) : number_format_i18n( 0 );
							$cart_rate   = isset( $row['cartToViewRate'] ) ? number_format_i18n( $row['cartToViewRate'] * 100, 2 ) . '%' : number_format_i18n( 0, 2 ) . '%';
							?>
							<tr>
								<td><?php echo esc_html( $course_name ); ?></td>
								<td><?php echo esc_html( $revenue ); ?></td>
								<td><?php echo esc_html( $purchases ); ?></td>
								<td><?php echo esc_html( $views ); ?></td>
								<td><?php echo esc_html( $cart_rate ); ?></td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			<?php else : ?>
				<div class="analytify-stats-error-msg">
					<div class="wpb-error-box">
						<span class="blk">
							<span class="line"></span>
							<span class="dot"></span>
						</span>
						<span class="information-txt"><?php esc_html_e( 'No Activity During This Period.', 'wp-analytify-pro' ); ?></span>
					</div>
				</div>
			<?php endif; ?>
		</div>

	</div>

	<?php
	wp_send_json(
		array(
			'body' => ob_get_clean(),
		)
	);
}

