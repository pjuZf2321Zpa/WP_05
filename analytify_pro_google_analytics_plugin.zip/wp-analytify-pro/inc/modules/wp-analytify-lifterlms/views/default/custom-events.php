<?php
/**
 * Custom Events View for LifterLMS.
 *
 * @package Analytify
 * @since 9.0.0
 */

if ( ! function_exists( 'llms_analytify_custom_events' ) ) {

	/**
	 * Display custom events statistics.
	 *
	 * @param object $current   WP_Analytify instance.
	 * @param array  $raw_stats Raw statistics data from GA4.
	 * @since 9.0.0
	 * @return void
	 */
	function llms_analytify_custom_events( $current, $raw_stats ) {

		ob_start();

		if ( empty( $raw_stats ) || ! isset( $raw_stats['rows'] ) ) {
			?>
			<div class="analytify_general_status">
				<div class="analytify_status_header">
					<h3><?php esc_html_e( 'LifterLMS Activity Tracking', 'wp-analytify-pro' ); ?></h3>
				</div>
				<div class="analytify_status_body">
					<div class="analytify-stats-error-msg">
						<div class="wpb-error-box">
							<span class="blk">
								<span class="line"></span>
								<span class="dot"></span>
							</span>
							<span class="information-txt"><?php esc_html_e( 'No Activity During This Period.', 'wp-analytify-pro' ); ?></span>
						</div>
					</div>
				</div>
			</div>
			<?php
			wp_send_json(
				array(
					'body' => ob_get_clean(),
				)
			);
			return;
		}

		?>

		<div class="analytify_general_status analytify_status_box_wraper">
			<div class="analytify_status_header">
				<h3><?php esc_html_e( 'LifterLMS Activity Tracking', 'wp-analytify-pro' ); ?></h3>
			</div>
			<div class="analytify_status_body">
				<table class="analytify_data_tables wp_analytify_paginated" data-product-per-page="10">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Item Name', 'wp-analytify-pro' ); ?></th>
							<th><?php esc_html_e( 'Course Views', 'wp-analytify-pro' ); ?></th>
							<th><?php esc_html_e( 'Course List Views', 'wp-analytify-pro' ); ?></th>
							<th><?php esc_html_e( 'Course Selections', 'wp-analytify-pro' ); ?></th>
							<th><?php esc_html_e( 'Lesson Views', 'wp-analytify-pro' ); ?></th>
							<th><?php esc_html_e( 'Course Enrollments', 'wp-analytify-pro' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php
						// Group data by item name.
						$grouped_data   = array();
						$activity_types = array(
							'wpa_view_course'       => 'Course Views',
							'wpa_view_course_list'  => 'Course List Views',
							'wpa_select_course'     => 'Course Selections',
							'wpa_view_lesson'       => 'Lesson Views',
							'wpa_course_enrollment' => 'Course Enrollments',
						);

						foreach ( $raw_stats['rows'] as $row ) {
							$item_name   = isset( $row['wpa_label'] ) ? $row['wpa_label'] : __( '(not set)', 'wp-analytify-pro' );
							$event_name  = isset( $row['eventName'] ) ? $row['eventName'] : '';
							$event_count = isset( $row['eventCount'] ) ? $row['eventCount'] : 0;

							if ( ! isset( $grouped_data[ $item_name ] ) ) {
								$grouped_data[ $item_name ] = array(
									'Course Views'       => 0,
									'Course List Views'  => 0,
									'Course Selections'  => 0,
									'Lesson Views'       => 0,
									'Course Enrollments' => 0,
								);
							}

							if ( isset( $activity_types[ $event_name ] ) ) {
								$grouped_data[ $item_name ][ $activity_types[ $event_name ] ] = $event_count;
							}
						}

						if ( ! empty( $grouped_data ) ) :
							foreach ( $grouped_data as $item_name => $counts ) :
								?>
								<tr>
									<td>
										<?php echo esc_html( $item_name ); ?>
									</td>
									<td>
										<span class="analytify_xl_f"><?php echo esc_html( number_format_i18n( $counts['Course Views'] ) ); ?></span>
									</td>
									<td>
										<span class="analytify_xl_f"><?php echo esc_html( number_format_i18n( $counts['Course List Views'] ) ); ?></span>
									</td>
									<td>
										<span class="analytify_xl_f"><?php echo esc_html( number_format_i18n( $counts['Course Selections'] ) ); ?></span>
									</td>
									<td>
										<span class="analytify_xl_f"><?php echo esc_html( number_format_i18n( $counts['Lesson Views'] ) ); ?></span>
									</td>
									<td>
										<span class="analytify_xl_f"><?php echo esc_html( number_format_i18n( $counts['Course Enrollments'] ) ); ?></span>
									</td>
								</tr>
								<?php
							endforeach;
						else :
							?>
							<tr>
								<td class='analytify_td_error_msg' colspan='6'>
									<div class="analytify-stats-error-msg">
										<div class="wpb-error-box">
											<span class="blk">
												<span class="line"></span>
												<span class="dot"></span>
											</span>
											<span class="information-txt"><?php esc_html_e( 'No Activity During This Period.', 'wp-analytify-pro' ); ?></span>
										</div>
									</div>
								</td>
							</tr>
						<?php endif; ?>
					</tbody>
				</table>
			</div>
		</div>

		<?php

		wp_send_json(
			array(
				'body' => ob_get_clean(),
			)
		);
	}
}

