<?php
/**
 * Handle Analytify LifterLMS REST end points.
 *
 * @package Analytify
 * @subpackage LifterLMS
 */

if ( ! class_exists( 'Analytify_LLMS_Rest_API' ) ) {

	/**
	 * Analytify LifterLMS REST API Class.
	 *
	 * Handles all REST API requests for the Analytify LifterLMS addon, including
	 * statistics, reports, and data aggregation for GA4.
	 *
	 * @since 9.0.0
	 */
	class Analytify_LLMS_Rest_API extends Analytify_REST_Handler_Base {

		/**
		 * The single instance of the class.
		 *
		 * @var object
		 */
		private static $instance;

		/**
		 * Compare start date.
		 *
		 * @var string
		 */
		private $compare_start_date;

		/**
		 * Compare end date.
		 *
		 * @var string
		 */
		private $compare_end_date;

		/**
		 * Date difference.
		 *
		 * @var int
		 */
		private $date_difference;

		/**
		 * Report URL.
		 *
		 * @var string
		 */
		private $report_url;

		/**
		 * Report date range.
		 *
		 * @var string
		 */
		private $report_date_range;

		/**
		 * REST API namespace.
		 *
		 * @var string
		 */
		const REST_NAMESPACE = 'wp-analytify/v1';

		/**
		 * Map of request_type (URL segment) => method name.
		 *
		 * @var array
		 */
		private static $request_type_map = array(
			'general-stats'   => 'general_stats',
			'top-courses'     => 'top_courses',
			'traffic-sources' => 'traffic_sources',
			'user-journeys'   => 'user_journeys',
			'course-insights' => 'course_insights',
			'custom-events'   => 'custom_events',
			'coupons'         => 'coupons',
			'funnel'          => 'funnel',
		);

		/**
		 * Returns the single instance of the class.
		 *
		 * @since 9.0.0
		 * @return Analytify_LLMS_Rest_API Class instance.
		 */
		public static function get_instance() {

			if ( empty( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		/**
		 * Analytify_LLMS_Rest_API constructor.
		 *
		 * Initializes class properties and registers the REST API hooks.
		 *
		 * @since 9.0.0
		 */
		private function __construct() {
			parent::__construct();
			add_action( 'rest_api_init', array( $this, 'rest_api_init' ) );
		}

		/**
		 * Register the LifterLMS REST API routes.
		 *
		 * Defines the main endpoint for pro LifterLMS reports.
		 *
		 * @since 9.0.0
		 * @return void
		 */
		public function rest_api_init() {

			register_rest_route(
				self::REST_NAMESPACE,
				'/get_pro_llms_report/(?P<profile_id>\d+)/(?P<request_type>[a-zA-Z0-9-]+)',
				array(
					array(
						'methods'             => WP_REST_Server::READABLE,
						'callback'            => array( $this, 'handle_request' ),
						'permission_callback' => array( $this, 'permission_check' ),
						'args'                => $this->get_route_args(),
					),
				)
			);
		}

		/**
		 * Get the route arguments for the REST API endpoint.
		 *
		 * Returns an array of parameter definitions, sanitation, and validation callbacks.
		 *
		 * @since 9.0.0
		 * @return array Map of route arguments.
		 */
		private function get_route_args() {
			return array_merge(
				$this->get_common_route_args(),
				array(
					'profile_id'   => array(
						'type'              => 'integer',
						'required'          => true,
						'sanitize_callback' => 'absint',
						'validate_callback' => function ( $value ) {
							return is_numeric( $value ) && $value > 0;
						},
					),
					'request_type' => array(
						'type'              => 'string',
						'required'          => true,
						'sanitize_callback' => 'sanitize_text_field',
						'validate_callback' => array( $this, 'validate_request_type' ),
					),
					'csd'          => array(
						'type'              => 'string',
						'required'          => false,
						'sanitize_callback' => 'sanitize_text_field',
						'validate_callback' => function ( $value ) {
							return empty( $value ) || $this->validate_date_param( $value );
						},
					),
					'ced'          => array(
						'type'              => 'string',
						'required'          => false,
						'sanitize_callback' => 'sanitize_text_field',
						'validate_callback' => function ( $value ) {
							return empty( $value ) || $this->validate_date_param( $value );
						},
					),
					'dd'           => array(
						'type'              => 'integer',
						'required'          => false,
						'sanitize_callback' => 'absint',
					),
					'ru'           => array(
						'type'              => 'string',
						'required'          => false,
						'sanitize_callback' => 'sanitize_text_field',
					),
					'rdr'          => array(
						'type'              => 'string',
						'required'          => false,
						'sanitize_callback' => 'sanitize_text_field',
					),
				)
			);
		}

		/**
		 * Validate that the request_type parameter is a known report type.
		 *
		 * @since 9.0.0
		 * @param string $value The request_type value from the URL.
		 * @return bool True if valid, false otherwise.
		 */
		public function validate_request_type( $value ) {
			return is_string( $value ) && isset( self::$request_type_map[ $value ] );
		}

		/**
		 * Handles the main REST request.
		 *
		 * Processes the request parameters, validates access, and routes the request
		 * based on the requested report type.
		 *
		 * @since 9.0.0
		 * @param WP_REST_Request $request The current REST API request object.
		 *
		 * @return array|WP_Error Resulting report data or WP_Error on failure.
		 */
		public function handle_request( WP_REST_Request $request ) {

			$is_access_level = $this->wp_analytify->settings->get_option( 'show_analytics_roles_dashboard', 'wp-analytify-dashboard', array( 'administrator' ) );

			// Generate error if unauthorized user send the request.
			if ( ! $this->wp_analytify->pa_check_roles( $is_access_level ) ) {
				return new WP_Error( 'analytify_forbidden', __( 'You are not allowed to access Analytify Dashboard.', 'wp-analytify-pro' ), array( 'status' => 403 ) );
			}

			$request_type = $request->get_param( 'request_type' );

			$this->start_date         = $request->get_param( 'sd' );
			$this->end_date           = $request->get_param( 'ed' );
			$this->compare_start_date = $request->get_param( 'csd' );
			$this->compare_end_date   = $request->get_param( 'ced' );
			$this->date_difference    = $request->get_param( 'dd' );
			$this->report_url         = $request->get_param( 'ru' );
			$this->report_date_range  = $request->get_param( 'rdr' );

			if ( ! isset( self::$request_type_map[ $request_type ] ) ) {
				return new WP_Error( 'analytify_invalid_endpoint', __( 'Invalid endpoint.', 'wp-analytify-pro' ), array( 'status' => 404 ) );
			}

			$method = self::$request_type_map[ $request_type ];
			return call_user_func( array( $this, $method ) );
		}

		/**
		 * Return a filter for the eventName dimension.
		 *
		 * Creates an exact match filter for a specific GA4 event name.
		 *
		 * @since 9.0.0
		 * @param string $event_name The event name value to filter for.
		 * @return array The filter configuration.
		 */
		private function get_event_name_filter( $event_name ) {
			return array(
				'logic'   => 'AND',
				'filters' => array(
					array(
						'type'       => 'dimension',
						'name'       => 'eventName',
						'match_type' => 1,
						'value'      => $event_name,
					),
				),
			);
		}

		/**
		 * Run a callback only when GA4 mode is active.
		 *
		 * Prevents errors when querying GA4 dimensions on a GA3 profile.
		 *
		 * @since 9.0.0
		 * @param callable $callback Anonymous function returning report results.
		 * @return array|WP_Error Report data or WP_Error.
		 */
		private function run_if_ga4( $callback ) {
			if ( 'ga4' !== $this->ga_mode ) {
				return $this->return_no_data_error();
			}
			return $callback();
		}

		/**
		 * Get the general statistics for LifterLMS.
		 *
		 * Aggregates revenue, purchases, views, and calculating session/day averages.
		 *
		 * @since 9.0.0
		 * @return array|WP_Error Response data for general stats.
		 */
		private function general_stats() {

			return $this->run_if_ga4(
				function () {
					$date_range = $this->get_date_range();

					// Get the same data as top courses to calculate totals.
					$top_courses_data = $this->wp_analytify->get_reports(
						'show-llms-general-stats',
						array(
							'itemRevenue',
							'itemsPurchased',
							'itemsViewed',
						),
						$date_range,
						array(
							'itemName',
							'currencyCode',
						),
						array(
							'type'  => 'metric',
							'name'  => 'itemRevenue',
							'order' => 'desc',
						),
						array(),
						50
					);

					// Get sessions and other metrics.
					$sessions_data = $this->wp_analytify->get_reports(
						'show-llms-sessions',
						array(
							'sessions',
							'averagePurchaseRevenue',
						),
						$date_range,
						array(),
						array(),
						array(),
						1
					);

					// Calculate Days to Purchase and Sessions to Purchase manually.
					$purchase_journey_data = $this->wp_analytify->get_reports(
						'show-llms-purchase-journey',
						array(
							'sessions',
							'eventCount',
						),
						$date_range,
						array(
							'date',
							'sessionId',
							'transactionId',
						),
						array(),
						$this->get_event_name_filter( 'purchase' ),
						1000 // Get more data for accurate calculation.
					);

					// Calculate metrics manually.
					$sessions_to_purchase = 0;
					$days_to_purchase     = 0;

					if ( isset( $purchase_journey_data['rows'] ) && is_array( $purchase_journey_data['rows'] ) && ! empty( $purchase_journey_data['rows'] ) ) {
						$total_sessions_before_purchase = 0;
						$total_days_before_purchase     = 0;
						$purchase_count                 = 0;

						// Group by transaction ID to get unique purchases.
						$purchases = array();
						foreach ( $purchase_journey_data['rows'] as $row ) {
							$transaction_id = $row['transactionId'] ?? '';
							if ( ! empty( $transaction_id ) ) {
								if ( ! isset( $purchases[ $transaction_id ] ) ) {
									$purchases[ $transaction_id ] = array(
										'sessions'         => 0,
										'first_visit_date' => null,
										'purchase_date'    => $row['date'] ?? '',
									);
									++$purchase_count;
								}
								// For other metrics, we don't have first_visit_date / purchase_date,
								// so we just sum the sessions that led to this transaction.
								$purchases[ $transaction_id ]['sessions'] += intval( $row['sessions'] ?? 0 );

								// Determine the earliest visit date for this transaction to calculate days before purchase.
								if ( empty( $purchases[ $transaction_id ]['first_visit_date'] ) ||
								$row['date'] < $purchases[ $transaction_id ]['first_visit_date'] ) {
									$purchases[ $transaction_id ]['first_visit_date'] = $row['date'];
								}
							}
						}

						// Calculate global averages from the grouped purchase data.
						foreach ( $purchases as $purchase ) {
							$total_sessions_before_purchase += $purchase['sessions'];

							if ( ! empty( $purchase['first_visit_date'] ) && ! empty( $purchase['purchase_date'] ) ) {
								$first_visit                 = new DateTime( $purchase['first_visit_date'] );
								$purchase_date               = new DateTime( $purchase['purchase_date'] );
								$days_diff                   = $first_visit->diff( $purchase_date )->days;
								$total_days_before_purchase += $days_diff;
							}
						}

						// Find the average sessions and days it takes for a user to complete a purchase.
						if ( $purchase_count > 0 ) {
							$sessions_to_purchase = $total_sessions_before_purchase / $purchase_count;
							$days_to_purchase     = $total_days_before_purchase / $purchase_count;
						}
					}

					// Sum up totals from the courses individual stats.
					$total_revenue   = 0;
					$total_purchases = 0;
					$total_views     = 0;

					if ( isset( $top_courses_data['rows'] ) && is_array( $top_courses_data['rows'] ) ) {
						foreach ( $top_courses_data['rows'] as $row ) {
							$total_revenue   += isset( $row['itemRevenue'] ) ? (float) $row['itemRevenue'] : 0;
							$total_purchases += isset( $row['itemsPurchased'] ) ? (int) $row['itemsPurchased'] : 0;
							$total_views     += isset( $row['itemsViewed'] ) ? (int) $row['itemsViewed'] : 0;
						}
					}

					// Final data structure for the frontend display.
					$general_stats = array(
						'aggregations' => array(
							'transactions'           => $total_purchases,
							'purchaseRevenue'        => $total_revenue,
							'ecommercePurchases'     => $total_purchases,
							'sessions'               => isset( $sessions_data['aggregations']['sessions'] ) ? $sessions_data['aggregations']['sessions'] : 0,
							'averagePurchaseRevenue' => $total_purchases > 0 ? $total_revenue / $total_purchases : 0,
							'sessionsToTransaction'  => $sessions_to_purchase,
							'daysToTransaction'      => $days_to_purchase,
						),
						'currencyCode' => isset( $top_courses_data['currencyCode'] ) ? $top_courses_data['currencyCode'] : 'USD',
					);

					// Fetch refunds count using GA4 events (eventName = refund).
					$refunds_stats = $this->wp_analytify->get_reports(
						'show-llms-refunds',
						array( 'eventCount' ),
						$date_range,
						array(),
						array(),
						$this->get_event_name_filter( 'refund' ),
						1
					);

					$refunds = isset( $refunds_stats['aggregations']['eventCount'] ) ? (int) $refunds_stats['aggregations']['eventCount'] : 0;

					// Append refunds and refund rate to aggregations for the view layer.
					if ( ! isset( $general_stats['aggregations'] ) ) {
						$general_stats['aggregations'] = array();
					}
					$general_stats['aggregations']['refunds']    = $refunds;
					$transactions_for_rate                       = isset( $general_stats['aggregations']['transactions'] ) ? (int) $general_stats['aggregations']['transactions'] : 0;
					$general_stats['aggregations']['refundRate'] = $transactions_for_rate > 0 ? ( $refunds / $transactions_for_rate ) * 100 : 0;

					if ( isset( $general_stats['aggregations'] ) ) {
						include ANALYTIFY_PRO_LIFTERLMS_ADDON_ROOT_PATH . '/views/default/general-stats.php';
						return llms_analytify_general_stats( $this->wp_analytify, $general_stats );
					}
					return $this->return_no_data_error();
				}
			);
		}

		/**
		 * Get the top performing courses.
		 *
		 * Fetches statistics for the most successful courses in LifterLMS.
		 *
		 * @since 9.0.0
		 * @return array|WP_Error Response data for top courses.
		 */
		private function top_courses() {

			return $this->run_if_ga4(
				function () {
					$stats = $this->wp_analytify->get_reports(
						'show-llms-top-courses',
						array(
							'itemRevenue',
							'itemsPurchased',
							'itemsViewed',
							'cartToViewRate',
						),
						$this->get_date_range(),
						array(
							'itemName',
							'currencyCode',
						),
						array(
							'type'  => 'metric',
							'name'  => 'itemRevenue',
							'order' => 'desc',
						),
						array(
							'logic'   => 'AND',
							'filters' => array(
								array(
									'type'           => 'dimension',
									'name'           => 'itemName',
									'match_type'     => 4,
									'value'          => '(not set)',
									'not_expression' => true,
								),
							),
						),
						10
					);

					include ANALYTIFY_PRO_LIFTERLMS_ADDON_ROOT_PATH . '/views/default/top-courses.php';
					return llms_analytify_top_courses( $this->wp_analytify, $stats );
				}
			);
		}

		/**
		 * Get the traffic source statistics.
		 *
		 * Analyzes where the LifterLMS traffic is coming from.
		 *
		 * @since 9.0.0
		 * @return array|WP_Error Response data for traffic sources.
		 */
		private function traffic_sources() {

			return $this->run_if_ga4(
				function () {
					$stats = $this->wp_analytify->get_reports(
						'show-llms-traffic-sources',
						array(
							'sessions',
							'bounceRate',
							'purchaseRevenue',
						),
						$this->get_date_range(),
						array(
							'sourceMedium',
							'currencyCode',
						),
						array(
							'type'  => 'metric',
							'name'  => 'purchaseRevenue',
							'order' => 'desc',
						),
						array(),
						50
					);

					include ANALYTIFY_PRO_LIFTERLMS_ADDON_ROOT_PATH . '/views/default/traffic-sources.php';
					return llms_analytify_traffic_sources( $this->wp_analytify, $stats, $this->report_url, $this->report_date_range );
				}
			);
		}

		/**
		 * Get the user journey patterns.
		 *
		 * Tracks the flow of users through the LifterLMS pages.
		 *
		 * @since 9.0.0
		 * @return array|WP_Error Response data for user journeys.
		 */
		private function user_journeys() {

			return $this->run_if_ga4(
				function () {
					$stats = $this->wp_analytify->get_reports(
						'show-llms-user-journeys',
						array(
							'screenPageViews',
							'sessions',
							'averageSessionDuration',
						),
						$this->get_date_range(),
						array(
							'pageTitle',
							'pagePath',
						),
						array(
							'type'  => 'metric',
							'name'  => 'screenPageViews',
							'order' => 'desc',
						),
						array(),
						50
					);

					include ANALYTIFY_PRO_LIFTERLMS_ADDON_ROOT_PATH . '/views/default/user-journeys.php';
					return llms_analytify_user_journeys( $this->wp_analytify, $stats );
				}
			);
		}

		/**
		 * Get the detailed course insights.
		 *
		 * Provides engagement metrics for individual courses.
		 *
		 * @since 9.0.0
		 * @return array|WP_Error Response data for course insights.
		 */
		private function course_insights() {

			return $this->run_if_ga4(
				function () {
					$stats = $this->wp_analytify->get_reports(
						'show-llms-course-insights',
						array(
							'screenPageViews',
							'bounceRate',
							'averageSessionDuration',
							'userEngagementDuration',
						),
						$this->get_date_range(),
						array(
							'pageTitle',
							'pagePath',
						),
						array(
							'type'  => 'metric',
							'name'  => 'screenPageViews',
							'order' => 'desc',
						),
						array(
							'logic'   => 'AND',
							'filters' => array(
								array(
									'type'       => 'dimension',
									'name'       => 'pagePath',
									'match_type' => 4,
									'value'      => '/courses/',
								),
							),
						),
						10
					);

					include ANALYTIFY_PRO_LIFTERLMS_ADDON_ROOT_PATH . '/views/default/course-insights.php';
					return llms_analytify_course_insights( $this->wp_analytify, $stats );
				}
			);
		}

		/**
		 * Get statistics for the LifterLMS custom events.
		 *
		 * Tracks custom defined events like course views, selections and enrollments.
		 *
		 * @since 9.0.0
		 * @return array|WP_Error Response data for custom events.
		 */
		private function custom_events() {

			return $this->run_if_ga4(
				function () {
					$date_range  = $this->get_date_range();
					$events_data = array();
					$event_names = array(
						'wpa_view_course'       => 'Course Views',
						'wpa_view_course_list'  => 'Course List Views',
						'wpa_select_course'     => 'Course Selections',
						'wpa_view_lesson'       => 'Lesson Views',
						'wpa_course_enrollment' => 'Course Enrollments',
					);

					foreach ( $event_names as $event_name => $display_name ) {
						// Get individual event counts with wpa_label dimension.
						$stats = $this->wp_analytify->get_reports(
							'custom-event-' . $event_name,
							array( 'eventCount' ),
							$date_range,
							array( 'customEvent:wpa_label' ),
							array(
								'type'  => 'metric',
								'name'  => 'eventCount',
								'order' => 'desc',
							),
							$this->get_event_name_filter( $event_name ),
							50
						);

						// Process each item in the results.
						if ( ! empty( $stats['rows'] ) ) {
							foreach ( $stats['rows'] as $row ) {
								$item_name   = isset( $row['customEvent:wpa_label'] ) ? $row['customEvent:wpa_label'] : __( '(not set)', 'wp-analytify-pro' );
								$event_count = isset( $row['eventCount'] ) ? $row['eventCount'] : 0;

								// Skip rows without a meaningful item label.
								if ( empty( $item_name ) || '(not set)' === $item_name ) {
									continue;
								}

								if ( $event_count > 0 ) {
									$events_data[] = array(
										'eventName'   => $event_name,
										'displayName' => $display_name,
										'wpa_label'   => $item_name,
										'eventCount'  => $event_count,
									);
								}
							}
						} else {
							// Fallback: if no rows, try to get total count.
							$total_stats = $this->wp_analytify->get_reports(
								'custom-event-total-' . $event_name,
								array( 'eventCount' ),
								$date_range,
								array(),
								array(),
								$this->get_event_name_filter( $event_name ),
								1
							);

							$event_count = isset( $total_stats['aggregations']['eventCount'] ) ? $total_stats['aggregations']['eventCount'] : 0;

							if ( $event_count > 0 ) {
								$events_data[] = array(
									'eventName'   => $event_name,
									'displayName' => $display_name,
									'wpa_label'   => $display_name, // Fallback to display name.
									'eventCount'  => $event_count,
								);
							}
						}
					}

					// Create mock stats structure for the view.
					$stats = array(
						'rows'         => $events_data,
						'headers'      => array(),
						'error'        => array(),
						'aggregations' => array(),
					);

					include ANALYTIFY_PRO_LIFTERLMS_ADDON_ROOT_PATH . '/views/default/custom-events.php';
					return llms_analytify_custom_events( $this->wp_analytify, $stats );
				}
			);
		}

		/**
		 * Get the coupons performance report.
		 *
		 * Fetches usage statistics and revenue for LifterLMS discount coupons.
		 *
		 * @since 9.0.0
		 * @return array|WP_Error Response data for coupons.
		 */
		private function coupons() {

			return $this->run_if_ga4(
				function () {
					$stats = $this->wp_analytify->get_reports(
						'show-llms-coupons',
						array(
							'purchaseRevenue',
							'ecommercePurchases',
						),
						$this->get_date_range(),
						array(
							'orderCoupon',
						),
						array(
							'type'  => 'metric',
							'name'  => 'purchaseRevenue',
							'order' => 'desc',
						),
						array(
							'logic'   => 'AND',
							'filters' => array(
								array(
									'type'           => 'dimension',
									'name'           => 'orderCoupon',
									'match_type'     => 4,
									'value'          => '(not set)',
									'not_expression' => true,
								),
							),
						),
						25
					);

					include ANALYTIFY_PRO_LIFTERLMS_ADDON_ROOT_PATH . '/views/default/coupons.php';
					return llms_analytify_coupons( $this->wp_analytify, $stats );
				}
			);
		}

		/**
		 * Get the checkout funnel statistics.
		 *
		 * Tracks the conversion flow from checkout start to purchase completion.
		 *
		 * @since 9.0.0
		 * @return array|WP_Error Response data for funnel stats.
		 */
		private function funnel() {

			return $this->run_if_ga4(
				function () {
					$steps = array(
						'begin_checkout'   => 0,
						'add_payment_info' => 0,
						'purchase'         => 0,
					);

					foreach ( array_keys( $steps ) as $event_name ) {
						$stats = $this->wp_analytify->get_reports(
							'llms-funnel-' . $event_name,
							array( 'eventCount' ),
							$this->get_date_range(),
							array(),
							array(),
							$this->get_event_name_filter( $event_name ),
							1
						);

						$event_count          = isset( $stats['aggregations']['eventCount'] ) ? (int) $stats['aggregations']['eventCount'] : 0;
						$steps[ $event_name ] = $event_count;
					}

					include ANALYTIFY_PRO_LIFTERLMS_ADDON_ROOT_PATH . '/views/default/funnel.php';
					return llms_analytify_funnel( $this->wp_analytify, $steps );
				}
			);
		}
	}
}

// Initialize the instance.
Analytify_LLMS_Rest_API::get_instance();
