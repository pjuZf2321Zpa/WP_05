<?php
/**
 * LifterLMS Dashboard Template
 *
 * @package WP_Analytify_Pro
 * @subpackage Modules\LifterLMS\Includes
 * @since 9.0.0
 */

$w_p_analytify = $GLOBALS['WP_ANALYTIFY'];

// Get the start date and end date from wpa-core-functions.
if ( function_exists( 'analytify_datepicker_dates' ) ) {
	$date_data  = analytify_datepicker_dates();
	$start_date = $date_data['start_date'];
	$end_date   = $date_data['end_date'];
} else {
	$start_date = wp_date( 'Y-m-d', strtotime( '-1 month' ) );
	$end_date   = wp_date( 'Y-m-d', strtotime( 'now' ) );
}

$date1 = date_create( $start_date );
$date2 = date_create( $end_date );
$diff  = date_diff( $date2, $date1 );

$compare_start_date = strtotime( $start_date . $diff->format( '%R%a days' ) );
$compare_start_date = gmdate( 'Y-m-d', $compare_start_date );
$compare_end_date   = $start_date;

// Fetch Dashboard Profile ID.
$dashboard_profile_id = $w_p_analytify->settings->get_option( 'profile_for_dashboard', 'wp-analytify-profile' );
$dashboard_profile_id = method_exists( 'WPANALYTIFY_Utils', 'get_reporting_property' ) ? WPANALYTIFY_Utils::get_reporting_property() : $dashboard_profile_id;

// Remove cache if delete cache is enabled.
if ( 'on' === $w_p_analytify->settings->get_option( 'delete_dashboard_cache', 'wp-analytify-dashboard' ) ) {
	if ( class_exists( 'WP_Analytify_LifterLMS_Addon' ) && method_exists( 'WP_Analytify_LifterLMS_Addon', 'wpa_llms_delete_transients' ) ) {
		WP_Analytify_LifterLMS_Addon::wpa_llms_delete_transients( $dashboard_profile_id, $start_date, $end_date );
	}
}

$report_url         = WP_ANALYTIFY_FUNCTIONS::get_ga_report_url( $dashboard_profile_id );
$report_date_range  = WP_ANALYTIFY_FUNCTIONS::get_ga_report_range( $start_date, $end_date, $compare_start_date, $compare_end_date );
$version            = defined( 'ANALYTIFY_PRO_VERSION' ) ? ANALYTIFY_PRO_VERSION : ANALYTIFY_VERSION;
$access_token       = get_option( 'post_analytics_token' );
$_analytify_profile = get_option( 'wp-analytify-profile' );
$is_access_level    = $w_p_analytify->settings->get_option( 'show_analytics_roles_dashboard', 'wp-analytify-dashboard' );
?>

<div class="wpanalytify analytify-dashboard-nav">
	<div class="wpb_plugin_wraper">
		<div class="wpb_plugin_header_wraper">
			<div class="graph"></div>
			<div class="wpb_plugin_header">
				<div class="wpb_plugin_header_title"></div>
				<div class="wpb_plugin_header_info">
					<a href="https://analytify.io/changelog/" target="_blank" class="btn"><?php echo esc_html__( 'View Changelog', 'wp-analytify-pro' ); ?></a>
				</div>
				<div class="wpb_plugin_header_logo">
					<img src="<?php echo esc_url( ANALYTIFY_PLUGIN_URL . '/assets/img/logo.svg' ); ?>" alt="Analytify">
				</div>
			</div>
		</div>

		<div class="analytify-dashboard-body-container">
			<div class="wpb_plugin_body_wraper">
				<div class="wpb_plugin_body">
					<div class="wpa-tab-wrapper">
						<?php
						if ( method_exists( $GLOBALS['WP_ANALYTIFY'], 'dashboard_navigation' ) ) {
							$navigation = $GLOBALS['WP_ANALYTIFY']->dashboard_navigation();
							if ( null !== $navigation ) {
								echo wp_kses_post( $navigation );
							}
						}
						?>
					</div>
					<div class="wpb_plugin_tabs_content analytify-dashboard-content">

						<div class="analytify_wraper">
							<div class="analytify_main_title_section">
								<div class="analytify_dashboard_title">
									<h1 class="analytify_pull_left analytify_main_title"><?php esc_html_e( 'LifterLMS Dashboard', 'wp-analytify-pro' ); ?></h1>
									<?php
									$_analytify_profile = get_option( 'wp-analytify-profile' );
									if ( $access_token && method_exists( 'WPANALYTIFY_Utils', 'dashboard_subtitle_section' ) ) {
										$subtitle = WPANALYTIFY_Utils::dashboard_subtitle_section();
										if ( null !== $subtitle ) {
											echo wp_kses_post( $subtitle );
										}
									}
									?>
								</div>

								<div class="analytify_main_setting_bar">
									<div class="analytify_pull_right analytify_setting">
										<div class="analytify_select_date">
											<?php
											if ( method_exists( 'WPANALYTIFY_Utils', 'date_form' ) ) {
												WPANALYTIFY_Utils::date_form( $start_date, $end_date );
											}
											?>
										</div>
									</div>
								</div>
							</div>
							<?php

							if ( ! WP_ANALYTIFY_FUNCTIONS::wpa_check_profile_selection( 'LifterLMS' ) ) {
								/*
								 * Check with roles assigned at dashboard settings.
								 */
								$is_access_level = $w_p_analytify->settings->get_option( 'show_analytics_roles_dashboard', 'wp-analytify-dashboard' );

								if ( $w_p_analytify->pa_check_roles( $is_access_level ) ) {
									if ( $access_token ) {
										$famous = '';
										?>

										<!-- General Stats -->
										<div class="analytify_status_body stats_loading">
											<div class="general-stats-report"></div>
										</div>

										<script>
										//<![CDATA[
										jQuery( function($) {
											$.ajax({
											url:  <?php echo wp_json_encode( esc_url_raw( rest_url( "wp-analytify/v1/get_pro_llms_report/$dashboard_profile_id/general-stats" ) ) ); ?>,
											data: {
												sd : '<?php echo esc_js( $start_date ); ?>',
												ed : '<?php echo esc_js( $end_date ); ?>',
											},
											beforeSend: function ( xhr ) {
												xhr.setRequestHeader('X-WP-Nonce', '<?php echo esc_js( wp_create_nonce( 'wp_rest' ) ); ?>');
											},
											})
											.fail(function(data) {
												var _html = '<table class="analytify_data_tables analytify_no_header_table"><tbody><tr><td class="analytify_td_error_msg"><div class="analytify-stats-error-msg"><div class="wpb-error-box"><span class="blk"><span class="line"></span><span class="dot"></span></span><span class="information-txt">Something Unexpected Occurred.</span></div></div></td></tr></tbody></table>'
												$('.general-stats-report').html(_html).parent().removeClass("stats_loading");
											})
											.done(function(data) {
												$(".general-stats-report").append(data.body).parent().removeClass("stats_loading");
												wp_analytify_paginated();
												enableAnalytifyTableSorting();
											}); 
										});
										//]]>
										</script>

										<!-- Top Courses -->
										<div class="analytify_status_body stats_loading">
											<div class="top-courses-report"></div>
										</div>

										<script>
										//<![CDATA[
										jQuery( function($) {
											$.ajax({
											url:  <?php echo wp_json_encode( esc_url_raw( rest_url( "wp-analytify/v1/get_pro_llms_report/$dashboard_profile_id/top-courses" ) ) ); ?>,
											data: {
												sd : '<?php echo esc_js( $start_date ); ?>',
												ed : '<?php echo esc_js( $end_date ); ?>',
											},
											beforeSend: function ( xhr ) {
												xhr.setRequestHeader('X-WP-Nonce', '<?php echo esc_js( wp_create_nonce( 'wp_rest' ) ); ?>');
											},
											})
											.fail(function(data) {
												var _html = '<table class="analytify_data_tables analytify_no_header_table"><tbody><tr><td class="analytify_td_error_msg"><div class="analytify-stats-error-msg"><div class="wpb-error-box"><span class="blk"><span class="line"></span><span class="dot"></span></span><span class="information-txt">Something Unexpected Occurred.</span></div></div></td></tr></tbody></table>'
												$('.top-courses-report').html(_html).parent().removeClass("stats_loading");
											})
											.done(function(data) {
												$(".top-courses-report").append(data.body).parent().removeClass("stats_loading");
												wp_analytify_paginated();
												enableAnalytifyTableSorting();
											}); 
										});
										//]]>
										</script>

										<!-- Checkout Funnel -->
										<div class="analytify_status_body stats_loading">
											<div class="funnel-report"></div>
										</div>

										<script>
										//<![CDATA[
										jQuery( function($) {
											$.ajax({
											url:  <?php echo wp_json_encode( esc_url_raw( rest_url( "wp-analytify/v1/get_pro_llms_report/$dashboard_profile_id/funnel" ) ) ); ?>,
											data: {
												sd : '<?php echo esc_js( $start_date ); ?>',
												ed : '<?php echo esc_js( $end_date ); ?>',
											},
											beforeSend: function ( xhr ) {
												xhr.setRequestHeader('X-WP-Nonce', '<?php echo esc_js( wp_create_nonce( 'wp_rest' ) ); ?>');
											},
											})
											.fail(function(xhr, status, error) {
												var _html = '<table class="analytify_data_tables analytify_no_header_table"><tbody><tr><td class="analytify_td_error_msg"><div class="analytify-stats-error-msg"><div class="wpb-error-box"><span class="blk"><span class="line"></span><span class="dot"></span></span><span class="information-txt">Something Unexpected Occurred.</span></div></div></td></tr></tbody></table>'
												$('.funnel-report').html(_html).parent().removeClass("stats_loading");
											})
											.done(function(data) {
												$(".funnel-report").append(data.body).parent().removeClass("stats_loading");
												wp_analytify_paginated();
												enableAnalytifyTableSorting();
											}); 
										});
										//]]>
										</script>

										<!-- Traffic Sources -->
										<div class="analytify_status_body stats_loading">
											<div class="traffic-sources-report"></div>
										</div>

										<script>
										//<![CDATA[
										jQuery( function($) {
											$.ajax({
											url:  <?php echo wp_json_encode( esc_url_raw( rest_url( "wp-analytify/v1/get_pro_llms_report/$dashboard_profile_id/traffic-sources" ) ) ); ?>,
											data: {
												sd : '<?php echo esc_js( $start_date ); ?>',
												ed : '<?php echo esc_js( $end_date ); ?>',
												ru : <?php echo wp_json_encode( $report_url ); ?>,
												rdr: <?php echo wp_json_encode( $report_date_range ); ?>,
											},
											beforeSend: function ( xhr ) {
												xhr.setRequestHeader('X-WP-Nonce', '<?php echo esc_js( wp_create_nonce( 'wp_rest' ) ); ?>');
											},
											})
											.fail(function(data) {
												var _html = '<table class="analytify_data_tables analytify_no_header_table"><tbody><tr><td class="analytify_td_error_msg"><div class="analytify-stats-error-msg"><div class="wpb-error-box"><span class="blk"><span class="line"></span><span class="dot"></span></span><span class="information-txt">Something Unexpected Occurred.</span></div></div></td></tr></tbody></table>'
												$('.traffic-sources-report').html(_html).parent().removeClass("stats_loading");
											})
											.done(function(data) {
												$(".traffic-sources-report").append(data.body).parent().removeClass("stats_loading");
												wp_analytify_paginated();
												enableAnalytifyTableSorting();
											}); 
										});
										//]]>
										</script>

										<!-- User Journeys -->
										<div class="analytify_status_body stats_loading">
											<div class="user-journeys-report"></div>
										</div>

										<script>
										//<![CDATA[
										jQuery( function($) {
											$.ajax({
											url:  <?php echo wp_json_encode( esc_url_raw( rest_url( "wp-analytify/v1/get_pro_llms_report/$dashboard_profile_id/user-journeys" ) ) ); ?>,
											data: {
												sd : '<?php echo esc_js( $start_date ); ?>',
												ed : '<?php echo esc_js( $end_date ); ?>',
											},
											beforeSend: function ( xhr ) {
												xhr.setRequestHeader('X-WP-Nonce', '<?php echo esc_js( wp_create_nonce( 'wp_rest' ) ); ?>');
											},
											})
											.fail(function(data) {
												var _html = '<table class="analytify_data_tables analytify_no_header_table"><tbody><tr><td class="analytify_td_error_msg"><div class="analytify-stats-error-msg"><div class="wpb-error-box"><span class="blk"><span class="line"></span><span class="dot"></span></span><span class="information-txt">Something Unexpected Occurred.</span></div></div></td></tr></tbody></table>'
												$('.user-journeys-report').html(_html).parent().removeClass("stats_loading");
											})
											.done(function(data) {
												$(".user-journeys-report").append(data.body).parent().removeClass("stats_loading");
												wp_analytify_paginated();
												enableAnalytifyTableSorting();
											}); 
										});
										//]]>
										</script>

										<!-- Course Insights -->
										<div class="analytify_status_body stats_loading">
											<div class="course-insights-report"></div>
										</div>

										<script>
										//<![CDATA[
										jQuery( function($) {
											$.ajax({
											url:  <?php echo wp_json_encode( esc_url_raw( rest_url( "wp-analytify/v1/get_pro_llms_report/$dashboard_profile_id/course-insights" ) ) ); ?>,
											data: {
												sd : '<?php echo esc_js( $start_date ); ?>',
												ed : '<?php echo esc_js( $end_date ); ?>',
											},
											beforeSend: function ( xhr ) {
												xhr.setRequestHeader('X-WP-Nonce', '<?php echo esc_js( wp_create_nonce( 'wp_rest' ) ); ?>');
											},
											})
											.fail(function(data) {
												var _html = '<table class="analytify_data_tables analytify_no_header_table"><tbody><tr><td class="analytify_td_error_msg"><div class="analytify-stats-error-msg"><div class="wpb-error-box"><span class="blk"><span class="line"></span><span class="dot"></span></span><span class="information-txt">Something Unexpected Occurred.</span></div></div></td></tr></tbody></table>'
												$('.course-insights-report').html(_html).parent().removeClass("stats_loading");
											})
											.done(function(data) {
												$(".course-insights-report").append(data.body).parent().removeClass("stats_loading");
												wp_analytify_paginated();
												enableAnalytifyTableSorting();
											}); 
										});
										//]]>
										</script>

										<!-- Custom Events -->
										<div class="analytify_status_body stats_loading">
											<div class="custom-events-report"></div>
										</div>

										<script>
										//<![CDATA[
										jQuery( function($) {
											$.ajax({
											url:  <?php echo wp_json_encode( esc_url_raw( rest_url( "wp-analytify/v1/get_pro_llms_report/$dashboard_profile_id/custom-events" ) ) ); ?>,
											data: {
												sd : '<?php echo esc_js( $start_date ); ?>',
												ed : '<?php echo esc_js( $end_date ); ?>',
											},
											beforeSend: function ( xhr ) {
												xhr.setRequestHeader('X-WP-Nonce', '<?php echo esc_js( wp_create_nonce( 'wp_rest' ) ); ?>');
											},
											})
											.fail(function(data) {
												var _html = '<table class="analytify_data_tables analytify_no_header_table"><tbody><tr><td class="analytify_td_error_msg"><div class="analytify-stats-error-msg"><div class="wpb-error-box"><span class="blk"><span class="line"></span><span class="dot"></span></span><span class="information-txt">Something Unexpected Occurred.</span></div></div></td></tr></tbody></table>'
												$('.custom-events-report').html(_html).parent().removeClass("stats_loading");
											})
						.done(function(data) {
							$(".custom-events-report").append(data.body).parent().removeClass("stats_loading");
							wp_analytify_paginated();
							enableAnalytifyTableSorting();
						});
										});
										//]]>
										</script>

										<!-- Top Coupons -->
										<div class="analytify_status_body stats_loading">
											<div class="coupons-report"></div>
										</div>

										<script>
										//<![CDATA[
										jQuery( function($) {
											$.ajax({
											url:  <?php echo wp_json_encode( esc_url_raw( rest_url( "wp-analytify/v1/get_pro_llms_report/$dashboard_profile_id/coupons" ) ) ); ?>,
											data: {
												sd : '<?php echo esc_js( $start_date ); ?>',
												ed : '<?php echo esc_js( $end_date ); ?>',
											},
											beforeSend: function ( xhr ) {
												xhr.setRequestHeader('X-WP-Nonce', '<?php echo esc_js( wp_create_nonce( 'wp_rest' ) ); ?>');
											},
											})
											.fail(function(data) {
												var _html = '<table class="analytify_data_tables analytify_no_header_table"><tbody><tr><td class="analytify_td_error_msg"><div class="analytify-stats-error-msg"><div class="wpb-error-box"><span class="blk"><span class="line"></span><span class="dot"></span></span><span class="information-txt">Something Unexpected Occurred.</span></div></div></td></tr></tbody></table>'
												$('.coupons-report').html(_html).parent().removeClass("stats_loading");
											})
											.done(function(data) {
												$(".coupons-report").append(data.body).parent().removeClass("stats_loading");
												wp_analytify_paginated();
												enableAnalytifyTableSorting();
											}); 
										});
										//]]>
										</script>

										<?php
									}
								}
							}
							?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

