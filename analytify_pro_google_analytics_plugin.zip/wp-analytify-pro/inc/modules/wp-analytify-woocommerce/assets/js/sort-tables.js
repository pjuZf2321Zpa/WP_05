jQuery(document).ready(() => {
    if ('function' === typeof enableAnalytifyTableSorting) {
        enableAnalytifyTableSorting();
    }
}); 
