<?php
/**
 * WooCommerce Addon Main Class.
 *
 * @package WP_Analytify_Pro
 */

// phpcs:ignoreFile WordPress.Files.FileName.InvalidClassFileName

if ( class_exists( 'WP_Analytify_WooCommerce_Addon' ) ) {
	return;
}

/**
 * Class WP_Analytify_WooCommerce_Addon
 *
 * Main WooCommerce integration class.
 */
class WP_Analytify_WooCommerce_Addon extends WP_Analytify_Pro_Base {


	/**
	 * Singleton instance.
	 *
	 * @var WP_Analytify_WooCommerce_Addon $instance The one true WP_Analytify_WooCommerce_Addon
	 * @since 1.0.0
	 */
	private static $instance;

	/**
	 * Category page JSON data.
	 *
	 * @var array<string, mixed>
	 */
	public $catpage_json = array();

	/**
	 * Category page add to cart links.
	 *
	 * @var array<string, mixed>
	 */
	// phpcs:ignore WordPress.NamingConventions.ValidVariableName.PropertyNotSnakeCase
	public $catpage_json_ATC_link = array();

	/**
	 * Order fully refunded flag.
	 *
	 * @var mixed
	 */
	public $order_fully_refunded = null;

	/**
	 * Product list data container.
	 *
	 * @var array<int|string, mixed>
	 */
	public $product_list = array();

	/**
	 * Cart handler instance
	 *
	 * @var WP_Analytify_WooCommerce_Cart_Handler
	 */
	public $cart_handler;

	/**
	 * Checkout handler instance
	 *
	 * @var WP_Analytify_WooCommerce_Checkout_Handler
	 */
	public $checkout_handler;

	/**
	 * Product handler instance
	 *
	 * @var WP_Analytify_WooCommerce_Product_Handler
	 */
	public $product_handler;

	/**
	 * Order handler instance
	 *
	 * @var WP_Analytify_WooCommerce_Order_Handler
	 */
	public $order_handler;

	/**
	 * Coupon handler instance
	 *
	 * @var WP_Analytify_WooCommerce_Coupon_Handler
	 */
	public $coupon_handler;

	/**
	 * Core tracking handler instance
	 *
	 * @var WP_Analytify_WooCommerce_Core_Tracking_Handler
	 */
	public $core_tracking_handler;

	/**
	 * Constructor
	 *
	 * @version 7.0.5
	 */
	public function __construct() {
		// Initialize handlers will be done after includes are loaded
	}

	/**
	 * Get active instance
	 *
	 * @version 7.0.5
	 * @access      public
	 * @since       1.0.0
	 * @return      object self::$instance The one true WP_Analytify_WooCommerce_Addon
	 */
	public static function instance() {

		if ( self::$instance === null ) {
			self::$instance = new WP_Analytify_WooCommerce_Addon();
			self::$instance->setup_constants();
			self::$instance->includes();
			self::$instance->init_handlers();
			self::$instance->hooks();
		}

		return self::$instance;
	}

	/**
	 * Format currency value with proper symbol and formatting
	 *
	 * @version 7.0.5
	 * @param float  $amount The amount to format
	 * @param string $currency_code The currency code (defaults to WooCommerce currency)
	 *
	 * @since 7.0.0
	 * @return string Formatted currency string
	 */
	public static function analytify_format_currency( $amount, $currency_code = '' ) {
		if ( empty( $currency_code ) ) {
			$currency_code = function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : 'USD';
		}
		$currency_symbol = function_exists( 'get_woocommerce_currency_symbol' ) ? get_woocommerce_currency_symbol( $currency_code ) : '$';
		return $currency_symbol . number_format( (float) $amount, 2 );
	}

	/**
	 * Whether WooCommerce email open tracking is allowed for this customer.
	 *
	 * Honors Analytify Profile → “Exclude these user roles from tracking”
	 * ({@see WP_Analytify_WooCommerce_Core_Tracking_Handler::is_track_user()} uses the same option for the current user).
	 *
	 * @since 9.0.1
	 * @param int $user_id WordPress / WooCommerce customer user ID.
	 * @return bool True when the tracking pixel may be output; false when the user’s role is excluded.
	 */
	public function analytify_is_tracking_enabled_for_user( $user_id ) {
		$uid = (int) $user_id;
		if ( $uid <= 0 ) {
			return true;
		}

		if ( ! isset( $GLOBALS['WP_ANALYTIFY'] ) || ! is_object( $GLOBALS['WP_ANALYTIFY'] ) ) {
			return true;
		}

		$user = get_userdata( $uid );
		if ( ! $user || empty( $user->roles ) || ! is_array( $user->roles ) ) {
			return true;
		}

		$exclude_roles = $GLOBALS['WP_ANALYTIFY']->settings->get_option( 'exclude_users_tracking', 'wp-analytify-profile', array() );
		if ( empty( $exclude_roles ) || ! is_array( $exclude_roles ) ) {
			return true;
		}

		foreach ( array_keys( $user->roles ) as $role ) {
			if ( in_array( $role, $exclude_roles, true ) ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Setup plugin constants
	 *
	 * @version 7.0.5
	 * @access      private
	 * @since       1.0.0
	 * @return      void
	 */
	private function setup_constants() {

		// Setting Global Values.
		$this->define( 'WC_ANALYTIFY_PLUGIN_FILE', __FILE__ );
		$this->define( 'WC_ANALYTIFY_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );
		$this->define( 'WC_ANALYTIFY_PLUGIN_DIR', __DIR__ );
		$this->define( 'WC_ANALYTIFY_PRODUCT_NAME', 'Enhanced Ecommerce Google Analytics for WooCommerce Addon' );
		$this->define( 'WC_ANALYTIFY_PRODUCT_ID', '1351' );
		$this->define( 'WC_ANALYTIFY_STORE_URL', 'https://analytify.io' );
	}

	/**
	 * Define constant if not already set
	 *
	 * @param  string      $name
	 * @param  string|bool $value
	 * @return void
	 */
	private function define( string $name, $value ) {

		if ( ! defined( $name ) ) {
			define( $name, $value );
		}
	}

	/**
	 * Include necessary files
	 *
	 * @access      private
	 * @since       1.0.0
	 * @return      void
	 */
	private function includes() {

		// Ensure Measurement Protocol GA4 class is loaded (needed for refund/cancellation tracking).
		if ( ! function_exists( 'analytify_mp_ga4' ) ) {
			$analytify_mp_ga4_file = ( defined( 'WP_ANALYTIFY_PLUGIN_DIR' ) ? WP_ANALYTIFY_PLUGIN_DIR : dirname( dirname( dirname( dirname( __DIR__ ) ) ) ) . '/wp-analytify' ) . '/classes/analytify-mp-ga4.php';
			if ( file_exists( $analytify_mp_ga4_file ) ) {
				require_once $analytify_mp_ga4_file;
			}
		}

		// Include the new specialized handler classes
		$plugin_dir = defined( 'WC_ANALYTIFY_PLUGIN_DIR' ) ? WC_ANALYTIFY_PLUGIN_DIR : __DIR__;
		include $plugin_dir . '/classes/class-woo-cart-handler.php';
		include $plugin_dir . '/classes/class-woo-checkout-handler.php';
		include $plugin_dir . '/classes/class-woo-product-handler.php';
		include $plugin_dir . '/classes/class-woo-order-handler.php';
		include $plugin_dir . '/classes/class-woo-coupon-handler.php';
		include $plugin_dir . '/classes/class-woo-core-tracking-handler.php';

		// Track WooCommerce Subscription tracking.
		if ( class_exists( 'WC_Subscriptions' ) ) {
			include $plugin_dir . '/classes/woocommerce-subscription.php';
		}

		// Track WooCommerce Emails.
		include $plugin_dir . '/classes/email-tracking.php';

		// Rest endpoints.
		include $plugin_dir . '/classes/analytify-woo-rest-api.php';
	}

	/**
	 * Initialize handler instances after includes are loaded
	 *
	 * @access      private
	 * @since       1.0.0
	 * @return      void
	 */
	private function init_handlers() {
		$this->cart_handler          = new WP_Analytify_WooCommerce_Cart_Handler();
		$this->checkout_handler      = new WP_Analytify_WooCommerce_Checkout_Handler();
		$this->product_handler       = new WP_Analytify_WooCommerce_Product_Handler();
		$this->order_handler         = new WP_Analytify_WooCommerce_Order_Handler();
		$this->coupon_handler        = new WP_Analytify_WooCommerce_Coupon_Handler();
		$this->core_tracking_handler = new WP_Analytify_WooCommerce_Core_Tracking_Handler();
	}

	/**
	 * Run action and filter hooks
	 *
	 * @access      private
	 * @since       1.0.0
	 * @return      void
	 */
	private function hooks() {
		// Add menu for WooCommerce Analytics Dashboard.
		add_action( 'analytify_add_submenu', array( $this, 'add_menu' ), 10 );

		// Add WooCommerce navigation bar.
		add_action( 'admin_menu', array( $this, 'woo_navigation_bar' ), 10 );

		add_action( 'admin_notices', array( $this, 'show_admin_notices' ) );
		add_action( 'ga_ecommerce_js', array( $this, 'add_ga_ecommerce_js' ), 1 );

		// Output tracking JavaScript via wp_footer since template hooks aren't firing.
		// This ensures tracking code is always output even with WooCommerce Blocks.
		add_action( 'wp_footer', array( $this, 'output_tracking_scripts' ), 15 );

		// Feeds product data from hits.
		add_action( 'woocommerce_before_shop_loop_item', array( $this, 'feed_product_data' ) );
		add_action( 'wp_footer', array( $this, 'print_product_data' ) );

		// Register hooks with explicit priorities to ensure they fire.
		add_action( 'woocommerce_after_add_to_cart_button', array( $this->cart_handler, 'add_to_cart' ), 10 );
		add_action( 'woocommerce_after_cart', array( $this->cart_handler, 'remove_from_cart' ), 10 );
		add_action( 'woocommerce_before_single_product', array( $this->product_handler, 'view_product_detail' ), 10 );
		if ( $this->product_handler && is_object( $this->product_handler ) ) {
			add_action( 'woocommerce_before_shop_loop_item', array( $this, 'bind_product_metadata' ) );
		}

		// Coupons tracking.
		add_action( 'woocommerce_applied_coupon', array( $this->coupon_handler, 'applied_coupon' ) );
		if ( isset( $_GET['remove_coupon'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$remove_coupon = function_exists( 'wc_sanitize_coupon_code' )
				? wc_sanitize_coupon_code( wp_unslash( $_GET['remove_coupon'] ) )
				: sanitize_text_field( wp_unslash( $_GET['remove_coupon'] ) );
			if ( '' !== $remove_coupon ) {
				add_action( 'woocommerce_init', array( $this->coupon_handler, 'removed_coupon' ) );
			}
		}

		// Order tracking process.
		// CRITICAL FIX: product_review_cart_step1 is in cart_handler, not checkout_handler!
		if ( $this->cart_handler ) {
			add_action( 'woocommerce_after_cart_totals', array( $this->cart_handler, 'product_review_cart_step1' ), 10 );
		}
		if ( $this->checkout_handler ) {
			add_action( 'woocommerce_after_checkout_billing_form', array( $this->checkout_handler, 'product_checkout_step2' ), 10 );
			add_action( 'woocommerce_after_checkout_shipping_form', array( $this->checkout_handler, 'product_checkout_step3' ), 10 );
			add_action( 'woocommerce_after_checkout_form', array( $this->checkout_handler, 'product_checkout_step4' ), 10 );
		}
		add_action( 'woocommerce_checkout_order_created', array( $this->order_handler, 'order_created' ) );
		add_action( 'woocommerce_cancelled_order', array( $this->order_handler, 'cancelled_order' ) );

		add_action( 'woocommerce_order_status_on-hold', array( $this->order_handler, 'purchase_on_hold' ) );
		add_action( 'woocommerce_payment_complete', array( $this->order_handler, 'analytify_track_complete_payment' ) );
		add_action( 'woocommerce_order_status_completed', array( $this->order_handler, 'analytify_track_complete_payment' ) );
		add_action( 'woocommerce_order_status_processing', array( $this->order_handler, 'analytify_track_complete_payment' ) );
		add_action( 'woocommerce_thankyou', array( $this->order_handler, 'analytify_track_purchase' ), 2 );

		add_action( 'woocommerce_order_refunded', array( $this->order_handler, 'order_refunded' ), 10, 2 );
		add_action( 'woocommerce_ordered_again', array( $this->order_handler, 'reordered' ) );
		if ( $this->core_tracking_handler && is_object( $this->core_tracking_handler ) ) {
			add_action( 'woocommerce_checkout_update_order_meta', array( $this, 'store_ga_identity' ) );
		}

		add_action( 'analytify_dashboad_dropdown_option', array( $this, 'dashboad_dropdown_option' ) );
		add_action( 'add_meta_boxes', array( $this, 'source_meta_box' ) );

		/**
		 * Filter for Source Medium Column (Heading) at WooCommerce Orders Page
		 */
		add_filter( 'manage_edit-shop_order_columns', array( $this, 'source_medium_column' ) ); // Legacy Mode.
		add_filter( 'manage_woocommerce_page_wc-orders_columns', array( $this, 'source_medium_column' ) ); // HPOS Mode.

		/**
		 * Action for getting Source Medium Column (Values) at WooCommerce Orders Page.
		 */
		add_action( 'manage_shop_order_posts_custom_column', array( $this, 'source_medium_value_order_posts' ) ); // Legacy Mode.
		add_action( 'manage_woocommerce_page_wc-orders_custom_column', array( $this, 'source_medium_value_wc_orders' ), 10, 2 ); // HPOS Mode.

		/**
		 * Add: Fetch source button visible at WooCommerce Orders Page.
		 */
		add_action( 'manage_posts_extra_tablenav', array( $this, 'show_source_fetch_button' ) ); // Legacy Mode.
		add_action( 'woocommerce_order_list_table_extra_tablenav', array( $this, 'show_source_fetch_button' ) ); // HPOS Mode.

		add_filter( 'analytify_install_ga_text', array( $this, 'install_ga_text' ) );

		add_filter( 'analytify_add_ecommerce_report', array( $this, 'analytify_add_woo_report' ), 10, 4 );
		add_filter( 'analytify_email_stats_option', array( $this, 'analytify_email_stats_option' ) );
		add_filter( 'analytify_admin_bar_menu', array( $this, 'add_admin_bar_menu' ), 15, 1 );

		// First landing URL: Set-Cookie on first front request (works even if JS blocked); JS syncs sessionStorage + checkout field.
		add_action( 'template_redirect', array( $this, 'wpa_set_first_landing_cookie' ), 0 );
		// First page visit tracking (footer priority 99: after jQuery; direct script output — not wc_enqueue_js — so it runs on all front pages e.g. catalog).
		add_action( 'wp_footer', array( $this, 'wpa_track_first_page_visit' ), 99 );
		add_action( 'woocommerce_checkout_update_order_meta', array( $this, 'wpa_save_first_page_visit_to_order' ), 10, 2 );
		add_action( 'woocommerce_checkout_order_created', array( $this, 'wpa_save_first_page_visit_to_order_created' ), 10, 1 );
		add_action( 'woocommerce_thankyou', array( $this, 'wpa_save_first_page_visit_on_thankyou' ), 5, 1 );
		add_filter( 'woocommerce_admin_order_preview_get_order_details', array( $this, 'wpa_add_first_page_visit_to_preview' ), 10, 2 );
		add_action( 'admin_footer', array( $this, 'wpa_inject_first_page_visit_script' ) );
	}





	/**
	 * Plugin row meta links
	 *
	 * @param array<int|string, mixed> $input already defined meta links
	 * @param string                   $file plugin file path and name being processed
	 * @return array<int|string, mixed> $input
	 */
	public function plugin_row_meta( array $input, string $file ) {
		// exit if its other plugins
		if ( 'wp-analytify-woocommerce.php' !== $file ) {
			return $input;
		}

		// remove the 'view details' org link
		if ( isset( $input[2] ) ) {
			unset( $input[2] );
		}

		// add the plugin site link
		$input[] = '<a href="https://analytify.io/add-ons/woocommerce/">Visit plugin site</a>';

		return $input;
	}

	/**
	 * Add woocommerce navigation bar in dashboard.
	 *
	 * @return void
	 */
	public function woo_navigation_bar() {

		if ( function_exists( 'wc_admin_connect_page' ) && isset( $_GET['page'] ) && 'analytify-woocommerce' === sanitize_text_field( $_GET['page'] ) ) {

			// wp-element required for woo navigation bar.
			wp_enqueue_script( 'wp-element' );

			// Add woo navigation bar.
			wc_admin_connect_page(
				array(
					'id'        => 'wp-analytify-woocommerce-navigation',
					'screen_id' => 'analytify_page_analytify-woocommerce',
					'title'     => __( 'Analytics', 'wp-analytify-pro' ),
				),
			);
		}
	}

	/**
	 * Add Metabox on order page.
	 *
	 * @since 2.0.6
	 * @return void
	 */
	public function source_meta_box() {
		add_meta_box( 'analytify_woo_source', __( 'Source/Medium', 'wp-analytify-pro' ), array( $this, 'get_source_medium' ), 'shop_order', 'side', 'core' );
	}

	/**
	 * Get Order Source/Medium
	 *
	 * @since 2.0.6
	 * @version 9.0.0
	 * @return string
	 */
	public function get_source_medium() {

		global $post;

		$source_medium_deprecated = get_post_meta( $post->ID, 'analytify_woo_single_source', true );

		if ( $source_medium_deprecated ) {
			return $source_medium_deprecated;
		}

		$source = get_post_meta( $post->ID, 'analytify_woo_order_source', true );

		if ( empty( $source ) ) {
			$post_date       = get_the_date( 'Y-m-d', $post->ID );
			$start_timestamp = strtotime( $post_date . '-5 days' );
			$end_timestamp   = strtotime( $post_date . '+5 days' );
			$start_date      = $start_timestamp !== false ? date( 'Y-m-d', $start_timestamp ) : $post_date;
			$end_date        = $end_timestamp !== false ? date( 'Y-m-d', $end_timestamp ) : $post_date;

			if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {
				// Get order to retrieve order number (what's actually sent to GA4)
				$order = wc_get_order( $post->ID );
				$transaction_id = $order ? $order->get_order_number() : (string) $post->ID;
				
				$stats = $GLOBALS['WP_ANALYTIFY']->get_reports(
					'analytify_woo_order_source',
					array(),
					array(
						'start' => $start_date,
						'end'   => $end_date,
					),
					array(
						'sourceMedium',
						'transactionId',
					),
					array(),
					array(
						'logic'   => 'AND',
						'filters' => array(
							array(
								'type'       => 'dimension',
								'name'       => 'transactionId',
								'match_type' => 'EXACT',
								'value'      => (string) $transaction_id,
							),
						),
					),
					0,
					false
				);

				if ( ! empty( $stats['rows'][0]['sourceMedium'] ) ) {
					update_post_meta( $post->ID, 'analytify_woo_order_source', $stats['rows'][0]['sourceMedium'] );
				}
			} else {
				$stats = $GLOBALS['WP_ANALYTIFY']->pa_get_analytics_dashboard( 'ga:totalEvents', $start_date, $end_date, 'ga:sourceMedium,ga:eventCategory,ga:eventLabel', false, 'ga:eventCategory==analytify_orders;ga:eventAction==order_created;ga:eventLabel==' . $post->ID );
				if ( ! empty( $stats['rows'][0][0] ) ) {
					update_post_meta( $post->ID, 'analytify_woo_order_source', $stats['rows'][0][0] );
				}
			}

			$source = get_post_meta( $post->ID, 'analytify_woo_order_source', true );
		}

		return $source;
	}

	/**
	 * Add Source/Medium column.
	 *
	 * @since 2.0.6
	 * @param array<string, mixed> $columns
	 * @return array<string, mixed>
	 */
	public function source_medium_column( array $columns ) {

		$new_columns                     = $columns;
		$new_columns['analytify_source'] = __( 'Source/Medium', 'wp-analytify-pro' );

		return $new_columns;
	}

	/**
	 * Add Source/Medium value for order.
	 *
	 * For WooCommerce HPOS settings only
	 *
	 * @version 9.0.0
	 * @param string $column
	 * @param mixed  $order
	 * @return void
	 */
	public function source_medium_value_wc_orders( string $column, $order ) {
		if ( $column === 'analytify_source' ) {
			if ( ! $order || ! is_object( $order ) || ! method_exists( $order, 'get_id' ) ) {
				echo '';
				return;
			}

			// Check for the new meta key first
			$source = $order->get_meta( 'analytify_woo_order_source', true );

			if ( $source ) {
				echo esc_html( $source );
				return;
			}

			// If the new meta key is not found, try the deprecated one
			$source_medium_deprecated = $order->get_meta( 'analytify_woo_single_source', true );

			if ( $source_medium_deprecated ) {
				echo esc_html( $source_medium_deprecated );
				return;
			}

			// Fetch source/medium on request (requires valid nonce).
			if ( empty( $source ) && $this->wpa_can_fetch_sale_source_from_request() ) {

				$date_created    = $order->get_date_created()->format( 'Y-m-d' );
				$start_timestamp = strtotime( $date_created . ' - 5 days' );
				$end_timestamp   = strtotime( $date_created . ' + 5 days' );
				$start_date      = $start_timestamp !== false ? date( 'Y-m-d', $start_timestamp ) : $date_created;
				$end_date        = $end_timestamp !== false ? date( 'Y-m-d', $end_timestamp ) : $date_created;

				// Get sources from ga4.
				if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {
					// Use order number first (sent to GA4), then fallback to order ID.
					$order_number           = (string) $order->get_order_number();
					$transaction_ids_to_try = array( $order_number );
					if ( (string) $order->get_id() !== $order_number ) {
						$transaction_ids_to_try[] = (string) $order->get_id();
					}

					foreach ( $transaction_ids_to_try as $transaction_id ) {
						$stats = $GLOBALS['WP_ANALYTIFY']->get_reports(
							'analytify_woo_order_source',
							array(),
							array(
								'start' => $start_date,
								'end'   => $end_date,
							),
							array(
								'sourceMedium',
								'transactionId',
							),
							array(),
							array(
								'logic'   => 'AND',
								'filters' => array(
									array(
										'type'       => 'dimension',
										'name'       => 'transactionId',
										// GA4 Data API expects string match types (e.g. EXACT), not numeric codes.
										'match_type' => 'EXACT',
										'value'      => $transaction_id,
									),
								),
							),
							0,
							false
						);

						$source = $this->wpa_extract_source_medium_from_rows( isset( $stats['rows'] ) ? $stats['rows'] : array() );
						if ( '' !== $source ) {
							$order->update_meta_data( 'analytify_woo_order_source', $source );
							$order->save();
							break;
						}
					}
				} else {
					$stats = $GLOBALS['WP_ANALYTIFY']->pa_get_analytics_dashboard( 'ga:totalEvents', $start_date, $end_date, 'ga:sourceMedium,ga:eventCategory,ga:eventLabel', false, 'ga:eventCategory==analytify_orders;ga:eventAction==order_created;ga:eventLabel==' . $order->get_id() );

					if ( isset( $stats['rows'][0][0] ) ) {
						$source = $stats['rows'][0][0];
						$order->update_meta_data( 'analytify_woo_order_source', $source );
						$order->save();
					}
				}
			}

			// Refresh the source after a verified fetch request.
			if ( $this->wpa_can_fetch_sale_source_from_request() ) {
				$source = $order->get_meta( 'analytify_woo_order_source', true );
			}

			echo esc_html( $source );
		}
	}
	/**
	 * Add Source/Medium value.
	 *
	 * For WooCommerce Legacy Orders Column.
	 *
	 * @since 2.0.6
	 * @version 9.0.0
	 * @param string $column
	 * @return void
	 */
	public function source_medium_value_order_posts( string $column ) {

		global $post;

		if ( $column == 'analytify_source' ) {

			$source_medium_deprecated = get_post_meta( $post->ID, 'analytify_woo_single_source', true );

			if ( $source_medium_deprecated ) {
				echo esc_html( $source_medium_deprecated );
				return;
			}

			$source = get_post_meta( $post->ID, 'analytify_woo_order_source', true );

			// Fetch source/medium on request (requires valid nonce).
			if ( empty( $source ) && $this->wpa_can_fetch_sale_source_from_request() ) {
				$post_date       = get_the_date( 'Y-m-d', $post->ID );
				$start_timestamp = strtotime( $post_date . ' - 5 days' );
				$end_timestamp   = strtotime( $post_date . ' + 5 days' );
				$start_date      = $start_timestamp !== false ? date( 'Y-m-d', $start_timestamp ) : $post_date;
				$end_date        = $end_timestamp !== false ? date( 'Y-m-d', $end_timestamp ) : $post_date;

				// Get sources from ga4.
				if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {
					// Get order to retrieve order number (what's actually sent to GA4)
					$order = wc_get_order( $post->ID );
					$transaction_id = $order ? $order->get_order_number() : (string) $post->ID;
					
					$stats = $GLOBALS['WP_ANALYTIFY']->get_reports(
						'analytify_woo_order_source',
						array(),
						array(
							'start' => $start_date,
							'end'   => $end_date,
						),
						array(
							'sourceMedium',
							'transactionId',
						),
						array(),
						array(
							'logic'   => 'AND',
							'filters' => array(
								array(
									'type'       => 'dimension',
									'name'       => 'transactionId',
									// GA4 Data API expects string match types (e.g. EXACT), not numeric codes.
									'match_type' => 'EXACT',
									'value'      => (string) $transaction_id,
								),
							),
						),
						0,
						false
					);

					$src_from_rows = $this->wpa_extract_source_medium_from_rows( isset( $stats['rows'] ) ? $stats['rows'] : array() );
					if ( '' !== $src_from_rows ) {
						update_post_meta( $post->ID, 'analytify_woo_order_source', $src_from_rows );
					}
				} else {
					$stats = $GLOBALS['WP_ANALYTIFY']->pa_get_analytics_dashboard( 'ga:totalEvents', $start_date, $end_date, 'ga:sourceMedium,ga:eventCategory,ga:eventLabel', false, 'ga:eventCategory==analytify_orders;ga:eventAction==order_created;ga:eventLabel==' . $post->ID );

					if ( isset( $stats['rows'][0][0] ) ) {
						$source = $stats['rows'][0][0];
						update_post_meta( $post->ID, 'analytify_woo_order_source', $source );
					}
				}
			}

			if ( $this->wpa_can_fetch_sale_source_from_request() ) {
				$source = get_post_meta( $post->ID, 'analytify_woo_order_source', true );
			}

			echo esc_html( $source );
		}
	}

	/**
	 * Show Fetch Source Button on Orders List Page.
	 *
	 * Uses a namespaced nonce field so it does not collide with WordPress/WooCommerce
	 * bulk-action `_wpnonce` in the same form (which broke all Orders bulk actions).
	 *
	 * @since 2.0.7
	 * @version 9.1.0
	 * @param string $which Button position (legacy) or order type (HPOS; only 1 arg is passed).
	 * @return void
	 */
	public function show_source_fetch_button( string $which ) {

		global $post_type;

		$screen               = get_current_screen();
		$analytify_plugin_url = defined( 'ANALYTIFY_PLUGIN_URL' ) ? ANALYTIFY_PLUGIN_URL : '';

		if ( 'shop_order' === $post_type && 'top' === $which ) {
			printf( '<input type="hidden" name="analytify_wc_fetch_sources_nonce" value="%s" />', esc_attr( wp_create_nonce( 'analytify_woo_action' ) ) );
			echo '<input style="background: #fff url(' . esc_url( $analytify_plugin_url . 'assets/img/analytify-logo-small.svg' ) . ') no-repeat left 10px center; padding-left: 35px;" type="submit" class="analytify_woo_fetch_sale_source button-secondary" value="Fetch Traffic Sources" name="analytify_woo_fetch_sale_source" style="margin-top:3px">';
		} elseif ( $screen && 'woocommerce_page_wc-orders' === $screen->id ) {
			printf( '<input type="hidden" name="analytify_wc_fetch_sources_nonce" value="%s" />', esc_attr( wp_create_nonce( 'analytify_woo_action' ) ) );
			echo '<input style="background: #fff url(' . esc_url( $analytify_plugin_url . 'assets/img/analytify-logo-small.svg' ) . ') no-repeat left 10px center; padding-left: 35px;" type="submit" class="analytify_woo_fetch_sale_source button-secondary" value="Fetch Traffic Sources" name="analytify_woo_fetch_sale_source" style="margin-top:3px">';
		}
	}

	/**
	 * Whether the WooCommerce orders list "Fetch Traffic Sources" request is allowed (CSRF).
	 *
	 * @since 9.0.0
	 * @version 9.1.0
	 * @return bool
	 */
	private function wpa_can_fetch_sale_source_from_request() {
		$has_action = isset( $_GET['analytify_woo_fetch_sale_source'] ) || isset( $_POST['analytify_woo_fetch_sale_source'] );
		$nonce      = '';

		if ( isset( $_GET['analytify_wc_fetch_sources_nonce'] ) ) {
			$nonce = sanitize_text_field( wp_unslash( $_GET['analytify_wc_fetch_sources_nonce'] ) );
		} elseif ( isset( $_POST['analytify_wc_fetch_sources_nonce'] ) ) {
			$nonce = sanitize_text_field( wp_unslash( $_POST['analytify_wc_fetch_sources_nonce'] ) );
		}

		return $has_action && '' !== $nonce && wp_verify_nonce( $nonce, 'analytify_woo_action' );
	}

	/**
	 * Add dropdown option for woo dashboard.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function dashboad_dropdown_option() {

		echo '<li><a href="' . esc_url( admin_url( 'admin.php?page=analytify-woocommerce' ) ) . '">WooCommerce</a></li>';
	}






	/**
	 * Track purchase event.
	 *
	 * @param int $order_id
	 * @return void
	 */
	public function track_purchase( int $order_id ) {
		$this->order_handler->track_purchase( $order_id );
	}



	/**
	 * Store clint ID into order meta.
	 *
	 * @since 2.1
	 * @param int         $order_id
	 * @param string|null $cid
	 * @return string|null
	 */
	public function store_ga_identity( int $order_id, ?string $cid = null ) {
		$cid = $cid ? $cid : $this->core_tracking_handler->get_woo_cid( (string) $order_id );

		// store clint ID in order meta if it is not empty.
		if ( ! empty( $cid ) && is_string( $cid ) ) {
			$cid = trim( $cid );
			update_post_meta( $order_id, 'analytify_woo_cid', $cid );
		}

		return ! is_string( $cid ) || '' === $cid ? null : $cid;
	}



	/**
	 * Sends hits via the Measurement Protocol (PHP).
	 *
	 * Logs failures with {@see wp_analytify_pro_log_measurement_remote_result()} (redacted hit), only on
	 * `WP_Error` or HTTP status &gt;= 400.
	 *
	 * @since 9.0.0
	 * @param array<string, mixed> $attr  Hit parameters merged into the default body.
	 * @param bool                 $debug When true, uses the GA debug collector and prints the response.
	 * @return void
	 */
	public function hit( array $attr, bool $debug = false ) {
		$cid = $this->core_tracking_handler->get_woo_cid();

		$default_args = array(
			't'  => 'event', // Required - Hit type
			'ec' => '', // Event category
			'ea' => '', // Event Action
			'el' => '', // Event Label
			'ev' => null, // Event Value
		);

		$body = array_merge( $default_args, $attr );

		$ip = $this->get_client_ip();

		$user_language = isset( $_SERVER['HTTP_ACCEPT_LANGUAGE'] ) ? explode( ',', sanitize_text_field( $_SERVER['HTTP_ACCEPT_LANGUAGE'] ) ) : array();
		$user_language = reset( $user_language );

		$default_body = array(
			'v'   => '1', // Required - Version
			'tid' => class_exists( 'WP_ANALYTIFY_FUNCTIONS' ) && method_exists( 'WP_ANALYTIFY_FUNCTIONS', 'get_UA_code' ) ? WP_ANALYTIFY_FUNCTIONS::get_UA_code() : '', // Required - UA code
			'cid' => $cid, // Required - Unique (anonymous) visitor ID
			't'   => 'pageview', // Required - Hit type
			'ni'  => true, // Non interaction

			'dh'  => str_replace( array( 'http://', 'https://' ), '', site_url() ),
			'dp'  => esc_url_raw( $_SERVER['REQUEST_URI'] ),
			'dt'  => get_the_title(),

			// Hits that usually also go with JS
			'ul'  => $user_language, // Optional - User language

			'uip' => $ip, // Optional - User IP, to make sure its not the servers'
			'ua'  => sanitize_text_field( $_SERVER['HTTP_USER_AGENT'] ), // Optional - User Agent
		);

		$body = wp_parse_args( $body, $default_body );

		// Requests without ID are ignored by GA
		if ( false == $body['cid'] ) {
			return;
		}

		$post_body = array_merge( $body, array( 'z' => time() ) );

		if ( $debug ) {

			$response = wp_remote_post(
				ANALYTIFY_GOOGLE_DEBUG_MEASUREMENT_URL,
				array(
					'method'   => 'POST',
					'timeout'  => 5,
					'blocking' => true,
					'body'     => $post_body,
				)
			);

			print '<pre>';
			print_r( $response );
			print '</pre>';
		} else {

			$response = wp_remote_post(
				ANALYTIFY_GOOGLE_MEASUREMENT_URL,
				array(
					'method'   => 'POST',
					'timeout'  => 5,
					'blocking' => false,
					'body'     => $post_body,
				)
			);
		}

		if ( is_wp_error( $response ) ) {
			wp_analytify_pro_log_measurement_remote_result(
				'Failed to send WooCommerce hit via Measurement Protocol.',
				'WooCommerce Measurement Protocol request returned an HTTP error.',
				'WP_Analytify_Woo::hit',
				$post_body,
				$response
			);
			return;
		}

		if ( is_array( $response ) && wp_remote_retrieve_response_code( $response ) >= 400 ) {
			wp_analytify_pro_log_measurement_remote_result(
				'Failed to send WooCommerce hit via Measurement Protocol.',
				'WooCommerce Measurement Protocol request returned an HTTP error.',
				'WP_Analytify_Woo::hit',
				$post_body,
				$response
			);
		}
	}

	/**
	 * Internationalization
	 *
	 * @access      public
	 * @since       1.0.0
	 * @return      void
	 */
	public function load_textdomain() {
		// Text domain loaded by main Pro plugin.
		// All translations now use 'wp-analytify-pro' text domain.
	}

	/**
	 * Add menu for WooCommerce dashboard page
	 *
	 * @access public
	 * @return void
	 */
	public static function add_menu() {

		add_submenu_page( 'analytify-dashboard', __( 'Track everything in WooCommerce with Analytify.', 'wp-analytify-pro' ), __( 'WooCommerce', 'wp-analytify-pro' ), 'edit_posts', 'analytify-woocommerce', array( __CLASS__, 'analytify_page_file_path' ), 15 );
	}

	/**
	 * Include file for WooCommerce dashboard page
	 *
	 * @access public
	 * @return void
	 */
	public static function analytify_page_file_path() {

		$screen = get_current_screen();

		if ( $screen && strpos( $screen->base, 'analytify-woocommerce' ) !== false ) {
			$plugin_dir = defined( 'WC_ANALYTIFY_PLUGIN_DIR' ) ? WC_ANALYTIFY_PLUGIN_DIR : __DIR__;
			include $plugin_dir . '/includes/woocommerce-dashboard.php';
		}
	}

	/**
	 * Initialize e-commerce JS
	 *
	 * @return void
	 */
	public static function add_ga_ecommerce_js() {

		if ( defined( 'ANALYTIFY_PRO_TRACKING_MODE' ) && 'gtag' === ANALYTIFY_PRO_TRACKING_MODE ) {
			// set the currency
			$currency = function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : 'USD';
			echo "\n\t\tgtag('set', {currency: '" . esc_js( $currency ) . "'});";
		} else {
			echo "ga('require', 'ec');";
			$currency = function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : 'USD';
			echo "var ga_currency = '" . esc_js( $currency ) . "';";
			echo 'ga("set", "&cu", ga_currency);';
		}
	}

	/**
	 * Add Inline JS depending on WooCommerce version
	 *
	 * @access public
	 * @return void
	 */




	/**
	 * Feeds product data in an array for hits
	 *
	 * @version 9.0.0
	 * @return void
	 */
	public function feed_product_data() {

		if ( ! $this->core_tracking_handler->is_track_user() || ! $this->core_tracking_handler->is_ga_enable() ) {
			return;
		}

		if ( ! defined( 'ANALYTIFY_PRO_TRACKING_MODE' ) || 'gtag' !== ANALYTIFY_PRO_TRACKING_MODE ) {
			return;
		}

		global $product, $woocommerce_loop;

		// Exclude feeds.
		if ( is_feed() ) {
			return;
		}

		$product_id = defined( 'WC_VERSION' ) && version_compare( WC_VERSION, '3.0', '<' ) ? $product->id : $product->get_id();

		// Generate category list.
		$categories     = (array) get_the_terms( $product_id, 'product_cat' );
		$category_names = wp_list_pluck( $categories, 'name' );

		// Product list name.
		$list_name = $this->core_tracking_handler->get_product_list();

		$item = array();

		if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {

			$item['item_id']       = $product_id;
			$item['item_name']     = get_the_title( $product_id );
			$item['price']         = $product->get_price();
			$item['item_brand']    = '';
			$item['item_category'] = reset( $category_names );
		} else {
			$item['id']            = $product_id;
			$item['name']          = get_the_title( $product_id );
			$item['brand']         = '';
			$item['category']      = implode( ',', $category_names );
			$item['coupon']        = '';
			$item['list_name']     = $list_name;
			$item['list_position'] = isset( $woocommerce_loop['loop'] ) ? $woocommerce_loop['loop'] : 1;
			$item['price']         = $product->get_price();
			$item['quantity']      = 1;
			$item['variant']       = '';
		}

		// Append the item to the list.
		$this->product_list[] = $item;
	}

	/**
	 * print esc_html( the product list as JSON
	 *
	 * @version 9.0.0
	 * @return void
	 */
	public function print_product_data() {

		// Check of all requirements are filled for tracking.
		$is_tracking_available = class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'is_tracking_available' ) ? WPANALYTIFY_Utils::is_tracking_available( true ) : false;

		if ( ! $is_tracking_available || ! $this->core_tracking_handler->is_track_user() || ! $this->core_tracking_handler->is_ga_enable() || empty( $this->product_list ) ) {
			return;
		}

		$select_event = ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) ? 'select_item' : 'select_content';

		// build product list
		$this->core_tracking_handler->add_inline_js_wpa_woo( 'const analytify_wc_product_list = {' );
		foreach ( $this->product_list as $product ) {
			$ID = isset( $product['item_id'] ) ? $product['item_id'] : $product['id'];
			$this->core_tracking_handler->add_inline_js_wpa_woo( " 'item_" . $ID . "' : " . json_encode( $product ) . ',' );
		}
		$this->core_tracking_handler->add_inline_js_wpa_woo( '};' );

		foreach ( $this->product_list as $product ) {

			$ID = isset( $product['item_id'] ) ? $product['item_id'] : $product['id'];

			$this->core_tracking_handler->add_inline_js_wpa_woo(
				"
			jQuery( 'body' ).on( 'click', '.products .post-" . $ID . " a.add_to_wishlist', function() {
				gtag( 'event', 'add_to_wishlist', { items: analytify_wc_product_list.item_" . $ID . " } );
			});
			jQuery( '.products .post-" . $ID . " a:not(.add_to_cart_button.product_type_simple, .add_to_wishlist)' ).on( 'click', function() {
				gtag( 'event', '" . $select_event . "', { content_type : 'product', items: analytify_wc_product_list.item_" . $ID . " } );
			});
			jQuery( '.products .post-" . $ID . " a.add_to_cart_button.product_type_simple' ).on( 'click', function() {
				   gtag( 'event', 'add_to_cart', { items: [{ 'item_id' : analytify_wc_product_list.item_" . $ID . '.item_id }] } );
			});
			'
			);
		}

		// product impression
		$this->core_tracking_handler->add_inline_js_wpa_woo(
			"
			gtag('event', 'view_item_list', {
				items: Object.values(analytify_wc_product_list)
			});
		"
		);
	}



	/**
	 * Bind product data
	 *
	 * @access public
	 * @return void
	 */
	public function bind_product_metadata() {

		global $product, $woocommerce_loop;
		global $catpage_json, $catpage_json_ATC_link;

		$_product_id = $product->get_id();
		$category    = get_the_terms( $_product_id, 'product_cat' );
		$categories  = '';

		if ( $category && ! is_wp_error( $category ) ) {
			foreach ( $category as $term ) {
				$categories .= $term->name . ',';
			}
		}

		// Remove last comma(,) if there are multiple categories.
		$categories = rtrim( $categories, ',' );

		if ( ( function_exists( 'is_product_category' ) && is_product_category() ) || is_search() || ( function_exists( 'is_shop' ) && is_shop() ) ) {
			// cat page link array
			$catpage_json_ATC_link[ $product->add_to_cart_url() ] = array( 'link' => get_permalink( $_product_id ) );

			$catpage_json[ get_permalink( $_product_id ) ] = array(
				'p_ID'       => esc_html( $_product_id ),
				'p_sku'      => esc_html( $product->get_sku() ? $product->get_sku() : $_product_id ),
				'p_name'     => esc_html( $product->get_title() ),
				'p_price'    => esc_html( $product->get_price() ),
				'p_category' => esc_html( $categories ),
				'p_position' => isset( $woocommerce_loop['loop'] ) ? $woocommerce_loop['loop'] : '',
			);
		}
	}





	/**
	 * Returns true if on a page which uses WooCommerce templates (cart and checkout are standard pages with short-codes and which are also included)
	 *
	 * @access public
	 * @return bool
	 */
	public function is_realy_woocommerce_page() {

		if ( ! ( function_exists( 'is_woocommerce' ) && is_woocommerce() ) &&
			! ( function_exists( 'is_shop' ) && is_shop() ) &&
			! ( function_exists( 'is_product_category' ) && is_product_category() ) &&
			! ( function_exists( 'is_product_tag' ) && is_product_tag() ) &&
			! ( function_exists( 'is_product' ) && is_product() ) &&
			! ( function_exists( 'is_cart' ) && is_cart() ) &&
			! ( function_exists( 'is_checkout' ) && is_checkout() ) &&
			! ( function_exists( 'is_account_page' ) && is_account_page() ) ) {
			echo '<script>';
			if ( defined( 'ANALYTIFY_PRO_TRACKING_MODE' ) && 'gtag' === ANALYTIFY_PRO_TRACKING_MODE ) {
				echo "gtag('event', 'page_view');";
			} else {
				echo "ga('send', 'pageview');";
			}
			echo '</script>';
			return false;
		}
		return true;
	}

	/**
	 * Display notices for woocommerce users
	 *
	 * @since 1.0.2
	 * @return void
	 */
	public function show_admin_notices() {

		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
	}





	/**
	 * Change Install GA text.
	 *
	 * @since 2.0.8
	 * @return string
	 */
	public function install_ga_text() {

		return __( 'Insert Google Analytics (GA) JavaScript code between the HEADER tags in your website. Check this option if you have installed Analytify E-Commerce add-ons for E-commerce Tracking.', 'wp-analytify-pro' );
	}

	/**
	 * Check if WooCommerce version is lower than 3
	 *
	 * @since 2.0.8
	 * @return bool
	 */
	public function is_wc_version_lt_3_0() {

		return self::get_wc_version() && version_compare( self::get_wc_version(), '3.0', '<' );
	}

	/**
	 * Get WooCommerce version
	 *
	 *  @since 2.0.8
	 * @return string|null
	 */
	public static function get_wc_version() {

		return defined( 'WC_VERSION' ) && WC_VERSION ? WC_VERSION : null;
	}

	/**
	 * Delete Woo Stats Cache.
	 *
	 * @since 2.0.8
	 * @param string $dashboard_profile_ID
	 * @param string $start_date
	 * @param string $end_date
	 * @return void
	 */
	private static function delete_woo_transients( string $dashboard_profile_ID, string $start_date, string $end_date ) {

		delete_transient( md5( 'show-woo-general-stats' . $dashboard_profile_ID . $start_date . $end_date . apply_filters( 'analytify_enhanced_general_filter', false ) ) );
		delete_transient( md5( 'show-woo-geographical-stats' . $dashboard_profile_ID . $start_date . $end_date . apply_filters( 'analytify_enhanced_geographic_filter', 'ga:country!=(not set);ga:itemQuantity>0' ) ) );
		delete_transient( md5( 'show-woo-roi-stats' . $dashboard_profile_ID . $start_date . $end_date . apply_filters( 'analytify_enhanced_roi_filter', 'ga:transactionRevenue>0' ) ) );
		delete_transient( md5( 'show-woo-product-performance-stats' . $dashboard_profile_ID . $start_date . $end_date ) );
		delete_transient( md5( 'show-woo-product-list-stats' . $dashboard_profile_ID . $start_date . $end_date ) );
		delete_transient( md5( 'show-woo-category-analysis-stats' . $dashboard_profile_ID . $start_date . $end_date ) );
		delete_transient( md5( 'show-woo-coupons-analysis-stats' . $dashboard_profile_ID . $start_date . $end_date . apply_filters( 'analytify_enhanced_coupon_filter', 'ga:orderCouponCode!=(not set)' ) ) );
		delete_transient( md5( 'show-woo-coupons-analysis-stats' . $dashboard_profile_ID . $start_date . $end_date . apply_filters( 'analytify_enhanced_coupon_filter', 'ga:orderCouponCode!=(not set)' ) ) );
	}

	/**
	 * Check if page reload.
	 *
	 * @since 2.0.8
	 * @return bool
	 */
	public function is_page_reload() {

		// Can't be a refresh without having a referrer
		if ( ! isset( $_SERVER['HTTP_REFERER'] ) ) {
			return false;
		}

		// IF the referrer is same to the current page request, then it's a refresh
		return ( parse_url( sanitize_url( $_SERVER['HTTP_REFERER'] ), PHP_URL_PATH ) === parse_url( esc_url_raw( $_SERVER['REQUEST_URI'] ), PHP_URL_PATH ) );
	}

	/**
	 * Add WooCommerce reports in email notification.
	 *
	 * @since 2.0.10
	 * @param string $message
	 * @param mixed  $Analytify_Email
	 * @param string $start_date
	 * @param string $end_date
	 * @return string
	 */
	function analytify_add_woo_report( string $message, $Analytify_Email, string $start_date, string $end_date ) {

		if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {
			$WP_Analytify = $GLOBALS['WP_ANALYTIFY'];
			$stats        = $WP_Analytify->get_reports(
				'analytify-email-woo-general-stats',
				array(
					'transactions',
					'purchaseRevenue',
					// TODO: (missing_ga4) 'revenuePerTransaction',
					'ecommercePurchases',
					// TODO: (missing_ga4) 'transactionsPerSession',
					'addToCarts',
					// TODO: (missing_ga4) 'productRemovesFromCart',
					'checkouts',
					'itemListClicks',
					'itemViews',
				),
				array(
					'start' => $start_date,
					'end'   => $end_date,
				)
			);

			$plugin_dir = defined( 'WC_ANALYTIFY_PLUGIN_DIR' ) ? WC_ANALYTIFY_PLUGIN_DIR : __DIR__;
			include $plugin_dir . '/views/email/woo-general-stats.php';
			ob_start();
			wpa_email_woo_general( $Analytify_Email, $stats );
			$message .= ob_get_clean();
		} else {
			$stats = $Analytify_Email->pa_get_analytics_dashboard( 'ga:transactions,ga:transactionRevenue,ga:revenuePerTransaction,ga:uniquePurchases,ga:transactionsPerSession,ga:productAddsToCart,ga:productRemovesFromCart,ga:productCheckouts,ga:productListClicks,ga:productDetailViews', $start_date, $end_date, false, false, false, false, 'analytify-email-woo-general-stats' );

			$plugin_dir = defined( 'WC_ANALYTIFY_PLUGIN_DIR' ) ? WC_ANALYTIFY_PLUGIN_DIR : __DIR__;
			include $plugin_dir . '/views/email/woo-general-stats-deprecated.php';
			ob_start();
			pa_email_include_woo_general( $Analytify_Email, $stats );
			$message .= ob_get_clean();
		}

		return $message;
	}

	/**
	 * Add WooCommerce stats option.
	 *
	 * @since 2.0.10
	 * @param array<string, mixed> $option
	 * @return array<string, mixed>
	 */
	function analytify_email_stats_option( array $option ) {

		$option['show-woo-stats'] = __( 'Ecommerce Stats', 'wp-analytify-pro' );

		return $option;
	}

	/**
	 * Add option in admin bar.
	 *
	 * @param array<string, mixed> $menus
	 * @return array<string, mixed>
	 * @since 2.0.10
	 */
	function add_admin_bar_menu( array $menus ) {

		$menus['analytify-woocommerce'] = __( 'WooCommerce', 'wp-analytify-pro' );

		return $menus;
	}

	/**
	 * Get IP by using the WooCommercce Geolocation class.
	 *
	 * @since 2.0.11
	 * @return string
	 */
	private function get_client_ip() {

		return class_exists( 'WC_Geolocation' ) && method_exists( 'WC_Geolocation', 'get_ip_address' ) ? WC_Geolocation::get_ip_address() : '';
	}


	/**
	 * Output tracking scripts via wp_footer since template hooks aren't firing
	 * This ensures tracking works even with WooCommerce Blocks or themes that don't call template hooks
	 *
	 * @return void
	 */
	public function output_tracking_scripts() {
		if ( is_admin() ) {
			return;
		}

		// Only output on WooCommerce pages.
		// Include product pages, cart, checkout, and account pages.
		if ( ! function_exists( 'is_woocommerce' ) ) {
			return;
		}
		
		// Check if we're on any WooCommerce page (product, shop, cart, checkout, account).
		$is_wc_page = is_woocommerce() || is_cart() || is_checkout() || is_account_page();
		if ( ! $is_wc_page ) {
			return;
		}

		// Check tracking conditions.
		if ( ! $this->core_tracking_handler->is_track_user() || ! $this->core_tracking_handler->is_ga_enable() ) {
			return;
		}

		// Output product page tracking (add_to_cart).
		// Check both is_product() and global $product (fallback for when is_product() fails).
		global $product;
		$is_product_page = ( function_exists( 'is_product' ) && is_product() ) || ( isset( $product ) && is_a( $product, 'WC_Product' ) );
		
		if ( $is_product_page && $this->cart_handler ) {
			$this->cart_handler->add_to_cart();
		}

		// Output cart page tracking (begin_checkout).
		if ( is_cart() && $this->cart_handler ) {
			$this->cart_handler->product_review_cart_step1();
		}

		// Output checkout page tracking (checkout steps).
		if ( is_checkout() && $this->checkout_handler ) {
			// Output all checkout step tracking code.
			$this->checkout_handler->product_checkout_step2();
			$this->checkout_handler->product_checkout_step3();
			$this->checkout_handler->product_checkout_step4();
		}

		// Output cart removal tracking.
		if ( is_cart() && $this->cart_handler ) {
			$this->cart_handler->remove_from_cart();
		}
	}

	/**
	 * Set first landing URL cookie on the first front-end request (HTTP Set-Cookie).
	 *
	 * Ensures the value exists before any footer JS runs and avoids relying on document.domain
	 * heuristics that can cause browsers to reject cookies.
	 *
	 * @since 9.0.0
	 * @version 9.0.0
	 * @return void
	 */
	public function wpa_set_first_landing_cookie() {
		if ( is_admin() && ! wp_doing_ajax() ) {
			return;
		}
		if ( wp_doing_ajax() || wp_doing_cron() ) {
			return;
		}
		if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
			return;
		}
		if ( is_feed() || is_robots() || is_trackback() ) {
			return;
		}
		if ( function_exists( 'wp_is_json_request' ) && wp_is_json_request() ) {
			return;
		}
		if ( function_exists( 'is_customize_preview' ) && is_customize_preview() ) {
			return;
		}

		if ( isset( $_COOKIE['analytify_first_page_visit'] ) && '' !== trim( (string) $_COOKIE['analytify_first_page_visit'] ) ) {
			return;
		}

		$host = isset( $_SERVER['HTTP_HOST'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_HOST'] ) ) : '';
		$path = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '/';
		if ( ! is_string( $path ) ) {
			$path = '/';
		}

		$scheme      = is_ssl() ? 'https' : 'http';
		$current_url = $scheme . '://' . $host . $path;

		if ( preg_match( '/\.(map|json|xml|txt|ico|png|jpg|jpeg|gif|svg|css|js|woff|woff2|ttf|eot)$/i', $current_url ) ) {
			return;
		}

		$current_url = $this->wpa_sanitize_first_page_visit_url( $current_url );
		if ( '' === $current_url ) {
			return;
		}

		if ( headers_sent() ) {
			return;
		}

		$name   = 'analytify_first_page_visit';
		// Match JS expiry: long enough for multi-day journeys before checkout (2h was too short).
		$expire = time() + ( 30 * DAY_IN_SECONDS );

		if ( PHP_VERSION_ID >= 70300 ) {
			setcookie(
				$name,
				$current_url,
				array(
					'expires'  => $expire,
					'path'     => '/',
					'domain'   => '',
					'secure'   => is_ssl(),
					'httponly' => false,
					'samesite' => 'Lax',
				)
			);
		} else {
			setcookie( $name, $current_url, $expire, '/', '', is_ssl(), false );
		}
	}

	/**
	 * Track first page visit using JavaScript.
	 * Stores the first page URL in sessionStorage and cookie for use at checkout.
	 *
	 * @since 9.0.0
	 * @version 9.0.0
	 * @return void
	 */
	public function wpa_track_first_page_visit() {
		// No is_ga_enable / is_track_user here: first landing is order attribution; must run for all shoppers (and match server-set cookie).
		if ( is_admin() && ! wp_doing_ajax() ) {
			return;
		}

		$host = isset( $_SERVER['HTTP_HOST'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_HOST'] ) ) : '';
		$path = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
		$current_url = ( is_ssl() ? 'https://' : 'http://' ) . $host . ( is_string( $path ) ? $path : '' );
		if ( preg_match( '/\.(map|json|xml|txt|ico|png|jpg|jpeg|gif|svg|css|js|woff|woff2|ttf|eot)$/i', $current_url ) ) {
			return;
		}

		$current_url = $this->wpa_sanitize_first_page_visit_url( $current_url );
		if ( '' === $current_url ) {
			return;
		}

		// Server-built URL only: standard json_encode is enough for script safety; avoid JSON_HEX_* here
		// so invalid UTF-8 in REQUEST_URI cannot make wp_json_encode() return false and break the whole IIFE.
		$json_opts   = JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE;
		if ( defined( 'JSON_INVALID_UTF8_SUBSTITUTE' ) ) {
			$json_opts |= JSON_INVALID_UTF8_SUBSTITUTE;
		}
		$current_url = wp_json_encode( $current_url, $json_opts );
		if ( false === $current_url ) {
			return;
		}

		$code = '
		(function() {
			var firstPageVisit = null;
			var currentUrl = ' . $current_url . ';
			function getCookie(name) {
				var nameEQ = name + "=";
				var ca = document.cookie.split(";");
				for (var i = 0; i < ca.length; i++) {
					var c = ca[i].trim();
					if (c.indexOf(nameEQ) === 0) {
						return decodeURIComponent(c.substring(nameEQ.length));
					}
				}
				return null;
			}
			function setCookie(name, value, hours) {
				try {
					var expires = new Date();
					expires.setTime(expires.getTime() + (hours * 60 * 60 * 1000));
					var cookieString = name + "=" + encodeURIComponent(value) + "; expires=" + expires.toUTCString() + "; path=/; SameSite=Lax";
					if (window.location.protocol === "https:") {
						cookieString += "; Secure";
					}
					document.cookie = cookieString;
				} catch (e) {}
			}
			try {
				if (typeof sessionStorage !== "undefined") {
					firstPageVisit = sessionStorage.getItem("analytify_first_page_visit");
				}
			} catch (e) {
				firstPageVisit = null;
			}
			if (firstPageVisit === null || firstPageVisit === undefined) {
				firstPageVisit = "";
			}
			if (!firstPageVisit) {
				firstPageVisit = getCookie("analytify_first_page_visit");
				if (firstPageVisit) {
					try {
						if (typeof sessionStorage !== "undefined") {
							sessionStorage.setItem("analytify_first_page_visit", firstPageVisit);
						}
					} catch (e) {}
				}
			}
			if (!firstPageVisit) {
				firstPageVisit = currentUrl;
				try {
					if (typeof sessionStorage !== "undefined") {
						sessionStorage.setItem("analytify_first_page_visit", firstPageVisit);
					}
				} catch (e) {}
			}
			// 720 hours = 30 days (keep in sync with wpa_set_first_landing_cookie() PHP expiry).
			setCookie("analytify_first_page_visit", firstPageVisit, 720);

			if (typeof jQuery !== "undefined" && firstPageVisit) {
				function escapeAttr(val) {
					return String(val).replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/\'/g, "&#39;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
				}
				var safeVal = escapeAttr(firstPageVisit);
				var ensureField = function() {
					var $form = jQuery("form.checkout, form.wc-block-checkout__form, #checkout, form[name=\\"checkout\\"]").first();
					var $field = jQuery("#analytify_first_page_visit");
					if ($form.length && $field.length === 0) {
						$form.append(
							jQuery("<input>", {
								type: "hidden",
								id: "analytify_first_page_visit",
								name: "analytify_first_page_visit",
								value: safeVal
							})
						);
					} else if ($field.length) {
						$field.val(firstPageVisit);
					}
				};
				jQuery(function() {
					setTimeout(ensureField, 300);
				});
				jQuery(document).on("updated_checkout wc_fragments_refreshed", ensureField);
				jQuery(document).on("submit", "form.checkout, form.wc-block-checkout__form", ensureField);
				jQuery(document).on("checkout_place_order_success", function(e, data) {
					if (data && data.redirect && firstPageVisit) {
						data.redirect += (data.redirect.indexOf("?") !== -1 ? "&" : "?") + "analytify_first_page_visit=" + encodeURIComponent(firstPageVisit);
					}
				});
			}
		})();
		';

		// Direct <script> output: not wc_enqueue_js(), so the cookie runs on any front page (catalog, LMS, etc.), not only where Woo prints its JS queue.
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Inline JS from server-built URL + fixed template; avoid printf() so "%" in URLs cannot break formatting.
		echo '<script type="text/javascript">' . $code . '</script>' . "\n";
	}

	/**
	 * Sanitize first page visit URL for privacy: strip sensitive query params before storing.
	 * Keeps path and safe query params (e.g. utm_* for attribution); strips token, key, password, etc.
	 *
	 * @since 9.0.0
	 * @version 9.0.0
	 * @param string $url Full URL.
	 * @return string Sanitized URL.
	 */
	private function wpa_sanitize_first_page_visit_url( $url ) {
		if ( ! is_string( $url ) || '' === trim( $url ) ) {
			return '';
		}
		$parsed = wp_parse_url( $url );
		if ( ! $parsed || empty( $parsed['host'] ) ) {
			return esc_url_raw( $url );
		}
		$path   = isset( $parsed['path'] ) ? $parsed['path'] : '/';
		$query  = isset( $parsed['query'] ) ? $parsed['query'] : '';
		$scheme = isset( $parsed['scheme'] ) ? $parsed['scheme'] . '://' : 'https://';
		$host   = $parsed['host'];
		$port   = isset( $parsed['port'] ) ? (int) $parsed['port'] : 0;
		$host_with_port = $host;
		if ( $port > 0 ) {
			$default_port = ( 0 === strpos( $scheme, 'https' ) ) ? 443 : 80;
			if ( $port !== $default_port ) {
				$host_with_port .= ':' . $port;
			}
		}

		$sensitive = array( 'token', 'key', 'password', 'secret', 'nonce', 'auth', 'session', 'sid', 'csrf', 'redirect_uri', 'state', 'code' );
		parse_str( $query, $params );
		$filtered = array();
		foreach ( $params as $k => $v ) {
			$lower = strtolower( $k );
			$drop  = false;
			foreach ( $sensitive as $s ) {
				if ( false !== strpos( $lower, $s ) ) {
					$drop = true;
					break;
				}
			}
			if ( ! $drop ) {
				$filtered[ $k ] = $v;
			}
		}
		$new_query = count( $filtered ) > 0 ? '?' . http_build_query( $filtered ) : '';
		return $scheme . $host_with_port . $path . $new_query;
	}

	/**
	 * Get first page visit URL from current request (POST or cookie).
	 *
	 * @since 9.0.0
	 * @version 9.0.0
	 * @return string Empty string if not set.
	 */
	private function wpa_get_first_page_visit_from_request() {
		$raw = '';
		if ( isset( $_POST['analytify_first_page_visit'] ) ) {
			$raw = wp_unslash( $_POST['analytify_first_page_visit'] );
		} elseif ( isset( $_COOKIE['analytify_first_page_visit'] ) ) {
			$raw = wp_unslash( $_COOKIE['analytify_first_page_visit'] );
		} elseif ( isset( $_GET['analytify_first_page_visit'] ) ) {
			$raw = wp_unslash( $_GET['analytify_first_page_visit'] );
		}
		if ( ! is_string( $raw ) || '' === trim( $raw ) ) {
			return '';
		}
		$sanitized = $this->wpa_sanitize_first_page_visit_url( $raw );
		$scheme    = wp_parse_url( $sanitized, PHP_URL_SCHEME );
		if ( ! in_array( strtolower( (string) $scheme ), array( 'http', 'https' ), true ) ) {
			return '';
		}

		return $sanitized;
	}

	/**
	 * Save first page visit from request to order (used by all checkout/thankyou hooks).
	 *
	 * @since 9.0.0
	 * @version 9.0.0
	 * @param int $order_id Order ID.
	 * @return void
	 */
	private function wpa_maybe_save_first_page_visit_to_order( $order_id ) {
		if ( ! $order_id ) {
			return;
		}
		$this->wpa_save_first_page_visit_meta( $order_id, $this->wpa_get_first_page_visit_from_request() );
	}

	/**
	 * Save first page visit to order meta during checkout.
	 *
	 * @since 9.0.0
	 * @version 9.0.0
	 * @param int   $order_id Order ID.
	 * @param array $data     Checkout data.
	 * @return void
	 */
	public function wpa_save_first_page_visit_to_order( $order_id, $data ) {
		$this->wpa_maybe_save_first_page_visit_to_order( $order_id );
	}

	/**
	 * Save first page visit when order is created (alternative hook).
	 *
	 * @since 9.0.0
	 * @version 9.0.0
	 * @param WC_Order $order Order object.
	 * @return void
	 */
	public function wpa_save_first_page_visit_to_order_created( $order ) {
		$order_id = is_object( $order ) && method_exists( $order, 'get_id' ) ? $order->get_id() : 0;
		$this->wpa_maybe_save_first_page_visit_to_order( $order_id );
	}

	/**
	 * Save first page visit on thank you page (fallback when not set at checkout).
	 *
	 * @since 9.0.0
	 * @version 9.0.0
	 * @param int $order_id Order ID.
	 * @return void
	 */
	public function wpa_save_first_page_visit_on_thankyou( $order_id ) {
		$this->wpa_maybe_save_first_page_visit_to_order( $order_id );
	}

	/**
	 * Save first page visit URL to order meta (only if not already set).
	 *
	 * @since 9.0.0
	 * @version 9.0.0
	 * @param int    $order_id         Order ID.
	 * @param string $first_page_visit First page visit URL.
	 * @return void
	 */
	private function wpa_save_first_page_visit_meta( $order_id, $first_page_visit ) {
		if ( empty( $first_page_visit ) ) {
			return;
		}

		$order = wc_get_order( $order_id );
		if ( $order ) {
			$existing = $order->get_meta( '_analytify_first_page_visit', true );
			if ( empty( $existing ) ) {
				$order->update_meta_data( '_analytify_first_page_visit', $first_page_visit );
				$order->save();
			}
		}
	}

	/**
	 * Add first page visit to WooCommerce admin order preview.
	 *
	 * @since 9.0.0
	 * @version 9.0.0
	 * @param array  $order_details Order details array.
	 * @param object $order         Order object.
	 * @return array Modified order details.
	 */
	public function wpa_add_first_page_visit_to_preview( $order_details, $order ) {
		if ( ! $order || ! is_object( $order ) ) {
			return $order_details;
		}

		$first_page_visit = $order->get_meta( '_analytify_first_page_visit', true );
		if ( ! empty( $first_page_visit ) && is_string( $first_page_visit ) ) {
			$order_details['first_page_visit'] = esc_url_raw( $this->wpa_sanitize_first_page_visit_url( $first_page_visit ) );
		} else {
			$order_details['first_page_visit'] = '';
		}

		return $order_details;
	}

	/**
	 * Inject script to show first page visit in admin order preview modal.
	 *
	 * @since 9.0.0
	 * @version 9.0.0
	 * @return void
	 */
	public function wpa_inject_first_page_visit_script() {
		$screen = get_current_screen();
		if ( ! $screen || ( 'shop_order' !== $screen->post_type && 'woocommerce_page_wc-orders' !== $screen->id ) ) {
			return;
		}
		$json_flags = JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT;
		$label      = wp_json_encode( __( 'First Page Visit', 'wp-analytify-pro' ), $json_flags );
		?>
		<script type="text/javascript">
		jQuery(document).ready(function($) {
			var firstPageVisitLabel = <?php
			// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON from wp_json_encode() with JSON_HEX_* flags.
			echo $label;
			?>;
			var firstPageVisitData = null;
			var lastOrderPreviewButton = null;
			var maxRetries = 8;
			var retryDelay = 150;

			function injectFirstPageVisit(url) {
				if (!url || typeof url !== 'string') {
					return false;
				}
				var $billing = $('.wc-order-preview-addresses .wc-order-preview-address:first, .wc-order-preview-address:first, .wc-backbone-modal .wc-order-preview-addresses .wc-order-preview-address:first').first();
				if ($billing.length === 0) {
					return false;
				}
				var probe = document.createElement('a');
				probe.setAttribute('href', url);
				if (probe.protocol !== 'http:' && probe.protocol !== 'https:') {
					return false;
				}
				var safeHref = probe.href;
				$('.analytify-first-page-visit').remove();
				var $block = $('<div class="analytify-first-page-visit" style="margin-top: 1.5em; padding-top: 1.5em; border-top: 1px solid #ddd;">');
				$block.append($('<strong style="display: block; margin-bottom: 0.5em;">').text(firstPageVisitLabel + ':'));
				$block.append($('<a>', {
					href: safeHref,
					target: '_blank',
					rel: 'noopener noreferrer',
					style: 'word-break: break-all; color: #2271b1;',
					text: url
				}));
				$billing.append($block);
				return true;
			}

			function tryInject(url, attempt) {
				attempt = attempt || 0;
				if (injectFirstPageVisit(url) || attempt >= maxRetries) {
					return;
				}
				setTimeout(function() {
					tryInject(url, attempt + 1);
				}, retryDelay);
			}

			function getOrderPreviewData() {
				if (firstPageVisitData) {
					return firstPageVisitData;
				}
				if (lastOrderPreviewButton && lastOrderPreviewButton.length) {
					var d = lastOrderPreviewButton.data('orderData') || lastOrderPreviewButton.data('order-data') || {};
					return d.first_page_visit || null;
				}
				return null;
			}

			$(document).on('click', '.order-preview', function() {
				lastOrderPreviewButton = $(this);
				var d = lastOrderPreviewButton.data('orderData') || lastOrderPreviewButton.data('order-data') || {};
				firstPageVisitData = d.first_page_visit || null;
			});

			$(document).ajaxSuccess(function(event, xhr, settings, data) {
				if (data && data.data && typeof data.data === 'object' && data.data.first_page_visit) {
					firstPageVisitData = data.data.first_page_visit;
				}
			});

			$(document).on('wc_backbone_modal_loaded', function(e, target) {
				if (target === 'wc-modal-view-order') {
					var url = getOrderPreviewData();
					if (url) {
						setTimeout(function() {
							tryInject(url);
						}, 100);
					}
				}
			});

			if (document.body && typeof MutationObserver !== 'undefined') {
				var observer = new MutationObserver(function() {
					if ($('.wc-backbone-modal-content').length > 0 && $('.analytify-first-page-visit').length === 0) {
						var url = getOrderPreviewData();
						if (url) {
							tryInject(url);
						}
					}
				});
				try {
					observer.observe(document.body, { childList: true, subtree: true });
				} catch (err) {}
			}
		});
		</script>
		<?php
	}

	/**
	 * Extract source/medium value from GA4 report rows.
	 *
	 * @since 9.0.0
	 * @version 9.0.0
	 * @param array<int|string, mixed> $rows Report rows.
	 * @return string
	 */
	private function wpa_extract_source_medium_from_rows( array $rows ) {
		foreach ( $rows as $row ) {
			if ( isset( $row['sourceMedium'] ) && is_string( $row['sourceMedium'] ) ) {
				return $row['sourceMedium'];
			}

			if ( isset( $row[0] ) && is_array( $row[0] ) && isset( $row[0]['sourceMedium'] ) && is_string( $row[0]['sourceMedium'] ) ) {
				return $row[0]['sourceMedium'];
			}
		}

		return '';
	}

	/**
	 * Get client ID for an order.
	 *
	 * Retrieves or generates a Google Analytics Client ID (CID). If an order ID is
	 * provided, it attempts to fetch a cached CID from post meta via the core handler.
	 * Otherwise, the handler extracts a CID from the `_ga` cookie or generates one.
	 *
	 * Wrapper around the core WooCommerce tracking handler so addon code keeps a single
	 * entry point; non-numeric order IDs are rejected here so meta lookup is not done
	 * with values that would coerce to an invalid post ID.
	 *
	 * @param string $order_id Optional WooCommerce order ID used for CID caching.
	 * @return string GA Client ID.
	 * @since 9.0.0
	 */
	public function get_cid( $order_id = '' ) {
		return $this->core_tracking_handler->get_cid( (string) $order_id );
	}

}
