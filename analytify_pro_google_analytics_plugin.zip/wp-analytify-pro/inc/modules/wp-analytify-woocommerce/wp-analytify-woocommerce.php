<?php
/**
 * WooCommerce addon loader.
 *
 * @package WP_Analytify_Pro
 */

// phpcs:ignoreFile WordPress.Files.FileName.InvalidClassFileName

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Class Analytify_WooCommerce_Loader
 *
 * Loads and initializes the WooCommerce addon.
 */
class Analytify_WooCommerce_Loader {

	/**
	 * Instance of this class.
	 *
	 * @var self|null
	 */
	public static $instance;

	/**
	 * Version number.
	 *
	 * @var string
	 */
	public string $version;

	/**
	 * Get singleton instance.
	 *
	 * @return self
	 */
	public static function get_instance(): self {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 *
	 * @return void
	 */
	public function __construct() {
		$this->version = analytify_pro_get_asset_version();
		$this->define_constants();
		$this->hooks();
		$this->may_be_load_addon();
	}

	/**
	 * Maybe load addon if dependencies are met.
	 *
	 * @return void
	 */
	public function may_be_load_addon() {
		/**
		* Check for WooCommerce
		*/
		if ( ! class_exists( 'WooCommerce' ) ) {
			add_action( 'admin_enqueue_scripts', array( $this, 'wpa_woo_notices_scripts' ) );
			add_action( 'admin_notices', array( $this, 'wpa_check_woo_admin_notice' ) );
			return;
		} elseif (
			file_exists( WP_PLUGIN_DIR . '/wp-analytify-pro/wp-analytify-pro.php' )
			&& function_exists( 'wp_analytify_pro_load' )
			&& class_exists( 'WP_Analytify_Pro_Base' )
		) {
			$addon_path = defined( 'ANALYTIFY_PRO_WOOCOMMERCE_ADDON_ROOT_PATH' ) ? ANALYTIFY_PRO_WOOCOMMERCE_ADDON_ROOT_PATH : __DIR__;
			include_once $addon_path . '/class-wp-analytify-woo.php';
			$GLOBALS['WPAnalytifyProWooCommerce'] = WP_Analytify_WooCommerce_Addon::instance();
		}
	}

	/**
	 * Define addon constants.
	 *
	 * @return void
	 */
	public function define_constants() {
		define( 'ANALYTIFY_PRO_WOOCOMMERCE_VERSION', analytify_pro_get_asset_version() );
		define( 'ANALYTIFY_PRO_WOOCOMMERCE_ADDON_ROOT_PATH', __DIR__ );
		define( 'ANALYTIFY_PRO_WOOCOMMERCE_UPGRADE_PATH', __FILE__ );
		if ( ! defined( 'ANALYTIFY_PRO_TRACKING_MODE' ) ) {
			$tracking_mode = defined( 'ANALYTIFY_TRACKING_MODE' ) ? ANALYTIFY_TRACKING_MODE : 'gtag';
			define( 'ANALYTIFY_PRO_TRACKING_MODE', $tracking_mode );
		}
	}

	/**
	 * Register hooks and filters.
	 *
	 * @return void
	 */
	public function hooks() {

		add_action( 'admin_notices', array( $this, 'wpa_check_analytify_admin_notice' ) );
		add_action( 'admin_notices', array( $this, 'wpa_check_analytify_pro_admin_notice' ) );
		add_action( 'admin_notices', array( $this, 'wpa_check_woo_admin_notice' ) );
		add_action( 'admin_notices', array( $this, 'install_woo' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'wpa_woo_notices_scripts' ) );

		/**
		 * Action hook for declaring the WooCommerce HPOS compatibility with Analytify WooCommerce.
		 */
		add_action( 'before_woocommerce_init', array( $this, 'wpa_declare_hpos_compatability' ) );
		add_action( 'init', array( $this, 'wp_analytify_woo_load_text_domain' ) );
		add_action( 'admin_footer', array( $this, 'wp_analytify_woo_notice_script' ) );
		add_action( 'wp_ajax_dismiss_analytify_notice', array( $this, 'dismiss_analytify_woo_notice' ) );
	}

	/**
	 * Check Analytify free plugin installation.
	 *
	 * @return void
	 */
	public function wpa_check_analytify_admin_notice() {
		if ( ! class_exists( 'WP_Analytify' ) ) {
			$message = __( '<strong>Attention:</strong> Analytify for WooCommerce works with the Analytify plugin. Please activate Analytify.', 'wp-analytify-pro' );
			$this->wp_analytify_woo_notice( $message, 'wp-analytify-danger' );
		}
	}

	/**
	 * Check Analytify pro plugin installation.
	 *
	 * @return void
	 */
	public function wpa_check_analytify_pro_admin_notice() {
		if ( ! class_exists( 'WP_Analytify_Pro' ) ) {
			$message = __( '<strong>Attention:</strong> Analytify for WooCommerce works with the Analytify PRO plugin. Please activate Analytify PRO.', 'wp-analytify-pro' );
			$this->wp_analytify_woo_notice( $message, 'wp-analytify-danger' );
		}
	}

	/**
	 * Install WooCommerce notice.
	 *
	 * @return void
	 */
	public function install_woo() {
		if ( ! file_exists( WP_PLUGIN_DIR . '/woocommerce/woocommerce.php' ) ) {
			$message = __( '<strong>Attention:</strong> Analytify for WooCommerce addon works with WooCommerce plugin, Please Install WooCommerce plugin.', 'wp-analytify-pro' );

			$this->wp_analytify_woo_notice( $message, 'wp-analytify-danger' );
		}
	}

	/**
	 * Check WooCommerce plugin installation.
	 *
	 * @return void
	 */
	public function wpa_check_woo_admin_notice() {
		if ( file_exists( WP_PLUGIN_DIR . '/woocommerce/woocommerce.php' ) && ! class_exists( 'WooCommerce' ) ) {
			$message = __( '<strong>Attention:</strong> Analytify for WooCommerce works with WooCommerce plugin, Please activate WooCommerce.', 'wp-analytify-pro' );
			$this->wp_analytify_woo_notice( $message, 'wp-analytify-danger' );
		}
	}

	/**
	 * Provides the compatibility with WooCommerce HPOS
	 *
	 * Before HPOS WC relied on on the post and post-meta table structures to store order information.
	 *
	 * HPOS introduces dedicated tables for data which results in fewer read/write operations and fewer busy tables.
	 *
	 * HPOS enables e-commerce stores of all shapes and sizes to scale to their maximum potential.
	 *
	 * Analytify is Compatible.
	 *
	 * @return void
	 */
	public function wpa_declare_hpos_compatability() {

		if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', ANALYTIFY_PRO_UPGRADE_PATH, true );
		}
	}

	/**
	 * Admin notices scripts.
	 *
	 * @return void
	 */
	public function wpa_woo_notices_scripts() {
		$version = defined( 'ANALYTIFY_PRO_WOOCOMMERCE_VERSION' ) ? ANALYTIFY_PRO_WOOCOMMERCE_VERSION : analytify_pro_get_asset_version();
		$suffix  = analytify_pro_get_asset_suffix();
		wp_enqueue_style( 'wp-analytify-funnel-style', plugins_url( "assets/css/funnel{$suffix}.css", __FILE__ ), array(), $version );
		wp_enqueue_style( 'wpa-woo-notices-css', plugins_url( "assets/css/notices{$suffix}.css", __FILE__ ), array(), $version );
		wp_enqueue_script(
			'analytify-woocommerce-sort-tables',
			plugins_url( "assets/js/sort-tables{$suffix}.js", __FILE__ ),
			array( 'jquery' ),
			$version,
			true
		);
	}

	/**
	 * Load TextDomain.
	 *
	 * @since 1.0.2
	 * @return void
	 */
	public function wp_analytify_woo_load_text_domain() {
		// Text domain loaded by main Pro plugin.
		// All translations now use 'wp-analytify-pro' text domain.
	}

	/**
	 * Add custom admin notice.
	 *
	 * @param  string $message Custom Message.
	 * @param  string $class wp-analytify-success,wp-analytify-danger.
	 * @return void
	 */
	public function wp_analytify_woo_notice( string $message, string $class = 'wp-analytify-success' ) { // phpcs:ignore Universal.NamingConventions.NoReservedKeywordParameterNames.classFound
		// Only show notices on allowed pages
		$screen = get_current_screen();
		
		if ( ! $screen ) {
			return;
		}
		
		$allowed_parent_bases = array(
			'analytify-dashboard',
			'plugins',
			'analytify-settings',
			'analytify-license',
			'analytify-addons',
			'dashboard',
		);
		
		$allowed_screen_ids = array(
			'plugins',
			'dashboard',
		);
		
		// Check if we're on an allowed page.
		$is_allowed = in_array( $screen->parent_base, $allowed_parent_bases, true )
			|| in_array( $screen->id, $allowed_screen_ids, true )
			|| ( isset( $_GET['page'] ) && strpos( $_GET['page'], 'analytify' ) === 0 );
		
		// Don't show notice if not on allowed page
		if ( ! $is_allowed ) {
			return;
		}

		$notice_id = 'analytify_notice_' . md5( $message );
		if ( ! get_option( $notice_id ) ) {
			echo '<div class="wp-analytify-notification ' . esc_attr( $class ) . '" id="' . esc_attr( $notice_id ) . '">
					<a class="wp-analytify-notice-dismiss" href="#" aria-label="Dismiss the notice" onclick="dismissAnalytifyNotice(\'' . esc_js( $notice_id ) . '\'); return false;">&times;</a>
					<div class="wp-analytify-notice-logo">
						<img src="' . esc_url( plugins_url( 'assets/img/logo.svg', __FILE__ ) ) . '" alt="notice">
					</div>
					<div class="wp-analytify-notice-discription">
						<p>' . wp_kses_post( $message ) . '</p>
					</div>
				</div>';
		}
	}

	/**
	 * Output notice dismiss script.
	 *
	 * @return void
	 */
	public function wp_analytify_woo_notice_script() {
		?>
		<script type="text/javascript">
			function dismissAnalytifyNotice(noticeId) {
				document.getElementById(noticeId).style.display = 'none';
				localStorage.setItem('analytify_stats_refreshed_dismissed', '1');
				var ajaxurl = '<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>';
				var data = {
					'action': 'dismiss_analytify_notice',
					'notice_id': noticeId
				};
				jQuery.post(ajaxurl, data, function(response) {
					// console.log(response);
				});
			}
		</script>
		<?php
	}

	/**
	 * Dismiss Analytify notice via AJAX.
	 *
	 * @return void
	 */
	public function dismiss_analytify_woo_notice() {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Nonce verification happens in calling context.
		if ( isset( $_POST['notice_id'] ) ) {
			update_option( sanitize_text_field( wp_unslash( $_POST['notice_id'] ) ), true );
		// phpcs:enable WordPress.Security.NonceVerification.Missing
			wp_send_json_success();
		} else {
			wp_send_json_error();
		}
	}
}
Analytify_WooCommerce_Loader::get_instance();

