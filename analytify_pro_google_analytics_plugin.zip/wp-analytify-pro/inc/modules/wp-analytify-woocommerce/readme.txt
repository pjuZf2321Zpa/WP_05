Hi there,
We at Analytify welcomes you to our premium users family.

== Installation ==
You should have installed Analytify Free + Pro versions to use this Analytify for WooCommerce add-on.

If you have any problem, please send an email to us at support@analytify.io

Cheers
Adnan from Analytify LLC

== Changelog == 

= 5.1.0 - 2024-01-16 =

* Bug Fix: Source/Medium Column for WooCommerce HPOS Database Structure.
* Bug Fix: PHP warnings.
* Bug Fix: Compatibility issues with WooCommerce 8.4.0 
* Enhancement: Responsiveness issues for all sections.
* Compatibility: Compatible to WordPress 6.4.2 and PHP 8.2.10

= 5.0.3 - 2023-06-20 =
* Bug Fix: order source/medium corrected.
* Enhancement: session information added in events.

= 5.0.2 - 2023-05-30 =
* Bug Fix: PHP warnings fixed.
* Enhancement: Use main dashboard saved date.
* Enhancement: Changelog button text updated.
* Enhancement: Removed Google Analytics reports links that are not working.

= 5.0.1 - 2023-05-15 =
* New Feature: Source Medium UTM parameters feature implemented on WooCommerce orders with GA4.
* Enhancement: Purchase event on thank you page moved to gtag for GA4.

= 5.0.0 - 2023-04-16 =
* New Feature: Google Analytics GA4 integration is added.
* New Feature: Google Search Console (webmasters) Integrated.
* Enhancement: Pageload speed improvement.
* Enhancement: UI Improvements.

= 4.1.8 - 2022-07-06 =
* Bug Fix: 'header already sent' error on some dashboards.

= 4.1.7 - 2022-05-18 =
* Bug Fix: WooCommerce email tracking code error was printed in the email.
* Compatibility: Compatible to WordPress 6.0

= 4.1.6 - 2022-02-19 =
* Bug Fix: Checkout behavior thankyou step tracking.
* Compatibility: Compatible to WordPress 5.9

= 4.1.5 - 2021-12-10 =
* Bug Fix: Fix order source/medium.

= 4.1.4 - 2021-11-02 =
* Bug Fix: Version number typo.

= 4.1.3 - 2021-11-01 =
* Bug Fix: List stats tracking in checkout steps.

= 4.1.2 - 2021-08-13 =
* Bug Fix: Coupons are tracking now in gtag.js 
* Enhancement: Fetch Traffic Source button redesign and Source/Medium column is empty now for betting UX.
* Compatibility: Compatible to WordPress 5.8

= 4.1.1 - 2021-07-30 =
* Enhancement: Refactor the check for tracking code enabled.
* Bug Fix: Fix the license field in settings.
* Bug Fix: Fix issues in tracking in the product archive page.

= 4.1.0 - 2021-06-21 =
* New Feature: Add the Global Site Tag (gtag.js) tracking compatibility. 
* Enhancement: Update diagostic information for additional details.

= 4.0.0 - March 12th, 2021 =
* New Feature: New dashboard desgin.
* New Feature: Export csv reports option.
* Enhancement: Update admin submenu ranking.
* Enhancement: Code refactoring.
* Enhancement: Update Admin notices.

= 3.0.3 - January 26th, 2021 =
* Bug Fix: Invalid date format issue while fetching stats from Google Analytics.

= 3.0.2 - August 6th, 2020 =
* New Feature: Add UA code notice.
* Enhancement: Add translatable strings for date ranges.
* Bug Fix: Fix call to a member function get_ID() on bool.

= 3.0.1 - July 8th, 2019 =
* Bug Fix: Fatal error on email tracking with empty $args['order'] variable.

= 3.0.0 - April 14th, 2019 =
* New Feature: WooCommerce Subscription tracking.
* New Feature: WooCommerce Email tracking.
* New Feature: Track Reorder Event.
* Bug Fix: Landing page dimensions missed in some cases.

= 2.0.13 - March 25th, 2019 =
* New Feature: Track order cancellation.

= 2.0.12 - February 21st, 2019 =
* BugFix: Wrong country for  Geographical tracking.

= 2.0.11 - January 21st, 2019 =
* Enhancement: Improve tracking.
* Enhancement: User IP detection for Geographical tracking.
* BugFix: Fix dashboard link in admin bar.

= 2.0.10 - December 31st, 2018 =
* New Feature: Introducing more detailed stats on Google Analytics.
* New Feature: Add General Sales Report in Email Notification addon.
* Enhancement: Improved 10 records per section and paginated for stats.
* Enhancement: French language added.

= 2.0.9 - November 30, 2018 =
* BugFix: Multisite Compatibility issue.

= 2.0.8 - October 26th, 2018 =
* BugFix: WC_Cart::get_remove_url is deprecated.
* Enhancement: Better Cache Algorithm.

= 2.0.7 - March 25th, 2018 =

* New Feature: Add Source/Medium to order list page.
* New Feature: Add zoom on the geographic map.
* BugFix: Strict check for the category page.

The full changelog is available at https://analytify.io/changelog/
