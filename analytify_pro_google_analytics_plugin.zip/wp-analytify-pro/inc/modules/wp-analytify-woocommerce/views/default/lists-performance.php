<?php
/**
 * Lists Performance view.
 *
 * @package WP_Analytify_Pro
 */

/**
 * Display product lists performance statistics.
 *
 * @param mixed                    $current Current object or context.
 * @param array<int|string, mixed> $stats Statistics data.
 * @return void
 */
function wpa_wocommerce_lists_performance( mixed $current, array $stats ) {
	?>

	<div class="analytify_general_status analytify_status_box_wraper">
		<div class="analytify_status_header">
			<h3>
			<?php esc_html_e( 'Product lists Analysis', 'wp-analytify-pro' ); ?>
			<a href="#" class="analytify-export-data analytify_tooltip" data-stats-type="product-lists-analysis">
			<span class="analytify_tooltiptext"><?php esc_html_e( 'Export Product lists Analysis', 'wp-analytify-pro' ); ?></span>
			</a>
			<img src="<?php echo esc_url( admin_url( 'images/spinner.gif' ) ); ?>" class='analytify-export-loader' style="display:none">
		</h3>
		</div>
		<div class="analytify_status_body">

		<table class="analytify_data_tables wp_analytify_paginated" data-product-per-page="10">
			<thead>
			<tr>
				<th class="analytify_table_header_no_events">
				#
				</th>
				<th>
				<?php esc_html_e( 'List Name', 'wp-analytify-pro' ); ?>
				</th>
				<th>
				<?php esc_html_e( 'Items Viewed In List', 'wp-analytify-pro' ); ?>
				</th>
				<th class="">
				<?php esc_html_e( 'Items Clicked In List', 'wp-analytify-pro' ); ?>
				</th>
				<th class="">
				<?php esc_html_e( 'Product List CTR', 'wp-analytify-pro' ); ?>
				</th>
				<th class="">
				<?php esc_html_e( 'Items Added To Cart', 'wp-analytify-pro' ); ?>
				</th>
				<th class="">
				<?php esc_html_e( 'Items Checkouts', 'wp-analytify-pro' ); ?>
				</th>
				<th class="">
				<?php esc_html_e( 'Items Purchases', 'wp-analytify-pro' ); ?>
				</th>
				<th class="">
				<?php esc_html_e( 'Product Revenue', 'wp-analytify-pro' ); ?>
				</th>
			</tr>
			</thead>
			<tbody>

			<?php
			if ( ! empty( $stats['rows'] ) ) {
				$i = 0;
				foreach ( $stats['rows'] as $stat ) {
					++$i;
					?>
				<tr>
					<td>
					<?php echo esc_html( $i ); ?>
					</td>
					<td>
					<?php echo esc_html( $stat['itemListName'] ); ?>
					</td>
					<td class="analytify_txt_center">
					<?php echo esc_html( $stat['itemsViewedInList'] ); ?>
					</td>
					<td class="analytify_txt_center">
					<?php echo esc_html( $stat['itemsClickedInList'] ); ?>
					</td>
					<td>
					<?php $percent_quantity = number_format( $stat['itemListClickThroughRate'], 2 ); ?>
					<?php echo esc_html( $percent_quantity ); ?> %
					<span class="analytify_bar_graph">
						<span style="width: <?php echo esc_attr( $percent_quantity ); ?>%;"></span>
					</span>
					</td>
					<td class="analytify_txt_center">
					<?php echo esc_html( $stat['itemsAddedToCart'] ); ?>
					</td>
					<td class="analytify_txt_center">
					<?php echo esc_html( $stat['itemsCheckedOut'] ); ?>
					</td>
					<td class="analytify_txt_center">
					<?php echo esc_html( $stat['itemsPurchased'] ); ?>
					</td>
					<td class="analytify_txt_center">
					<?php
					$currency_code = ( isset( $stat['currencyCode'] ) && '(not set)' !== $stat['currencyCode'] ) ? $stat['currencyCode'] : '';
					echo esc_html( WP_Analytify_WooCommerce_Addon::analytify_format_currency( $stat['itemRevenue'], $currency_code ) );
					?>
					</td>
				</tr>
					<?php
				}
			} else {
				?>
				<tr>
				<td class="analytify_td_error_msg" colspan="9">
					<?php
					if ( is_object( $current ) && method_exists( $current, 'no_records' ) ) {
						$current->no_records();
					} else {
						echo esc_html( '<p>' . esc_html__( 'No data available', 'wp-analytify-pro' ) . '</p>' );
					}
					?>
				</td>
				</tr>
				<?php
			}
			?>
			</tbody>
			</table>
		</div>
		<div class="analytify_status_footer">

	<?php if ( isset( $stats['rows'][0]['itemListName'] ) ) { ?>
	<span class="analytify_info_stats">
		<?php
		// translators: %1$s is strong opening tag, %2$s is list name, %3$s is strong closing tag.
		printf( esc_html__( 'Did you know the big Revenue generated from Product List in your store is %1$s %2$s %3$s?', 'wp-analytify-pro' ), '<strong>', esc_html( $stats['rows'][0]['itemListName'] ), '</strong>' );
		?>
	</span>
	<?php } ?>
	<div class="wp_analytify_pagination"></div>

	</div>
</div>

<script type="text/javascript">
	jQuery(document).ready(function($) {
		wp_analytify_paginated();
	});
</script>

	<?php
}

