<?php
/**
 * Shopping Analysis view for WooCommerce.
 *
 * @package WP_Analytify_Pro
 */

/**
 * Display shopping analysis statistics for WooCommerce.
 *
 * @param mixed                $current Current data or context.
 * @param array<string, mixed> $raw_stats Raw statistics data.
 * @return void
 */
function pa_ga_include_woocommerce( $current, $raw_stats ) {
	// Note: Output buffering is handled by the REST API caller, so we output directly here.

	$sessions        = isset( $raw_stats['aggregations']['sessions'] ) ? $raw_stats['aggregations']['sessions'] : 0;
	$transactions    = isset( $raw_stats['aggregations']['transactions'] ) ? $raw_stats['aggregations']['transactions'] : 0;
	$conversion_rate = $sessions > 0 ? ( $transactions / $sessions ) * 100 : 0;

	$first_puchaser = isset( $raw_stats['aggregations']['firstTimePurchaserRate'] ) ? $raw_stats['aggregations']['firstTimePurchaserRate'] : 0;

	// Get refund statistics.
	$refund_stats = array(
		'refunded_orders' => 0,
		'total_refunded'  => 0.0,
		'refund_rate'     => 0.0,
	);

	// Get refund stats if WooCommerce REST API class exists (includes refund_rate from API).
	if ( class_exists( 'Analytify_Woo_Rest_API' ) ) {
		$woo_rest_api = Analytify_Woo_Rest_API::get_instance();
		$refund_stats = $woo_rest_api->analytify_get_refund_stats();
	}

	$boxes = array(
		'transactions'        => array(
			'label'       => esc_html__( 'Transactions', 'wp-analytify-pro' ),
			'value'       => isset( $raw_stats['aggregations']['transactions'] ) ? number_format( $raw_stats['aggregations']['transactions'] ) : 0,
			'description' => esc_html__( 'Total number of completed orders.', 'wp-analytify-pro' ),
		),
		'revenue'             => array(
			'label'       => __( 'Transaction Revenues', 'wp-analytify-pro' ),
			'value'       => isset( $raw_stats['aggregations']['totalRevenue'] )
				? WP_Analytify_WooCommerce_Addon::analytify_format_currency(
					$raw_stats['aggregations']['totalRevenue'],
					( isset( $raw_stats['currencyCode'] ) && '(not set)' !== $raw_stats['currencyCode'] ) ? $raw_stats['currencyCode'] : ''
				)
				: WP_Analytify_WooCommerce_Addon::analytify_format_currency( 0 ),
			'description' => __( 'Total revenue from purchases including or excluding shipping and tax.', 'wp-analytify-pro' ),
		),
		'average_order_value' => array(
			'label'       => __( 'Average Order Value', 'wp-analytify-pro' ),
			'value'       => isset( $raw_stats['aggregations']['averagePurchaseRevenue'] )
				? WP_Analytify_WooCommerce_Addon::analytify_format_currency(
					$raw_stats['aggregations']['averagePurchaseRevenue'],
					( isset( $raw_stats['currencyCode'] ) && '(not set)' !== $raw_stats['currencyCode'] ) ? $raw_stats['currencyCode'] : ''
				)
				: WP_Analytify_WooCommerce_Addon::analytify_format_currency( 0 ),
			'description' => __( 'Average Value of transactions.', 'wp-analytify-pro' ),
		),
		'add_to_cart'         => array(
			'label'       => __( 'Product Adds To Cart', 'wp-analytify-pro' ),
			'value'       => isset( $raw_stats['aggregations']['addToCarts'] ) ? $raw_stats['aggregations']['addToCarts'] : 0,
			'description' => __( 'Total number of add to cart items.', 'wp-analytify-pro' ),
		),
		'remove_from_cart'    => array(
			'label'       => __( 'Product Removes From Cart', 'wp-analytify-pro' ),
			'value'       => 0,
			'description' => __( 'Total number of items removed from cart.', 'wp-analytify-pro' ),
		),
		'checkouts'           => array(
			'label'       => __( 'Product Checkouts', 'wp-analytify-pro' ),
			'value'       => isset( $raw_stats['aggregations']['checkouts'] ) ? $raw_stats['aggregations']['checkouts'] : 0,
			'description' => __( 'The total number of checkouts.', 'wp-analytify-pro' ),
		),
		'unique_purchases'    => array(
			'label'       => __( 'Completed Purchases', 'wp-analytify-pro' ),
			'value'       => isset( $raw_stats['aggregations']['ecommercePurchases'] ) ? $raw_stats['aggregations']['ecommercePurchases'] : 0,
			'description' => __( 'The number of times users completed a purchase.', 'wp-analytify-pro' ),
		),
		'view_item'           => array(
			'label'       => __( 'Product Clicks', 'wp-analytify-pro' ),
			'value'       => isset( $raw_stats['aggregations']['itemListClicks'] ) ? $raw_stats['aggregations']['itemListClicks'] : 0,
			'description' => __( 'The total number of user clicks on your products.', 'wp-analytify-pro' ),
		),
		'view_item_list'      => array(
			'label'       => __( 'Product Detail Views', 'wp-analytify-pro' ),
			'value'       => isset( $raw_stats['aggregations']['itemViews'] ) ? $raw_stats['aggregations']['itemViews'] : 0,
			'description' => __( 'Number of times users viewed the product detail page.', 'wp-analytify-pro' ),
		),
		'conversion_rate'     => array(
			'label'       => __( 'Conversion Rate', 'wp-analytify-pro' ),
			'value'       => number_format( $conversion_rate, 2 ) . '%',
			'description' => __( 'The percentage of website sessions resulting in a transaction.', 'wp-analytify-pro' ),
		),
		'new_customers'       => array(
			'label'       => __( 'New Customers', 'wp-analytify-pro' ),
			'value'       => number_format( $first_puchaser, 2 ) . '%',
			'description' => __( 'The percentage of first-time purchasers.', 'wp-analytify-pro' ),
		),
		'refund_rate'         => array(
			'label'       => esc_html__( 'Refund Rate', 'wp-analytify-pro' ),
			'value'       => number_format( (float) $refund_stats['refund_rate'], 2 ) . '%',
			'description' => esc_html__( 'The percentage of orders that were refunded.', 'wp-analytify-pro' ),
		),

		'total_refunded'      => array(
			'label'       => esc_html__( 'Total Refunded', 'wp-analytify-pro' ),
			'value'       => WP_Analytify_WooCommerce_Addon::analytify_format_currency( (float) $refund_stats['total_refunded'] ),
			'description' => esc_html__( 'Total amount refunded to customers.', 'wp-analytify-pro' ),
		),

		'refunded_orders'     => array(
			'label'       => esc_html__( 'Refunded Orders', 'wp-analytify-pro' ),
			'value'       => number_format( (int) $refund_stats['refunded_orders'] ),
			'description' => esc_html__( 'Total number of orders that were refunded.', 'wp-analytify-pro' ),
		),
	);

	if ( isset( $raw_stats['remove_from_cart'] ) ) {
		$boxes['remove_from_cart']['value'] = $raw_stats['remove_from_cart'];
	} else {
		unset( $boxes['remove_from_cart'] );
	}

	?>
	<div class="analytify_general_status analytify_status_box_wraper">

		<div class="analytify_status_header">
			<h3><?php esc_html_e( 'Overview', 'wp-analytify-pro' ); ?></h3>
		</div>

		<div class="analytify_status_body">
			<div class="analytify_general_status_boxes_wraper">

				<?php foreach ( $boxes as $box ) { ?>
				<div class="analytify_general_status_boxes">
					<h4><?php echo esc_html( $box['label'] ); ?></h4>
					<div class="analytify_general_stats_value"><?php echo esc_html( $box['value'] ); ?></div>
					<p><?php echo esc_html( $box['description'] ); ?></p>
				</div>
				<?php } ?>

			</div>
		</div>

		<?php
		/*
		TODO: missing_ga4
		<div class="analytify_status_footer">
			<span class="analytify_info_stats"><?php
			echo sprintf( esc_html__( 'Did you know that the Conversion Rate in your store is %1$s', 'wp-analytify-pro' ), number_format( $stats->totalsForAllResults['ga:transactionsPerSession'], 2) ) . '%?'; ?></span>
		</div>
		*/
		?>

	</div>

	<?php
	// Note: Do not call wp_send_json() here as this function is called from REST API
	// which handles the response format. The output is captured via ob_get_clean() in the caller.
}
