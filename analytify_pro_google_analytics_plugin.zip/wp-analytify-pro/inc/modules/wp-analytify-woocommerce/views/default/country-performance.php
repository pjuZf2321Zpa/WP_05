<?php
/**
 * Country Performance view.
 *
 * @package WP_Analytify_Pro
 */

/**
 * Display country-wise performance statistics.
 *
 * @param mixed                    $wp_analytify Analytify object or context.
 * @param array<int|string, mixed> $country_stats Country statistics data.
 * @param string                   $report_date_range Report date range.
 * @return void
 */
function wpa_country_performance( mixed $wp_analytify, array $country_stats, string $report_date_range ) {

	// Fetch Dashboard Profile ID.
	$dashboard_profile_id = 'wp-analytify-profile';
	if ( $wp_analytify && is_object( $wp_analytify ) && isset( $wp_analytify->settings ) && method_exists( $wp_analytify->settings, 'get_option' ) ) {
		$dashboard_profile_id = $wp_analytify->settings->get_option( 'profile_for_dashboard', 'wp-analytify-profile' );
	}
	$dashboard_profile_id = ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_reporting_property' ) ) ? WPANALYTIFY_Utils::get_reporting_property() : $dashboard_profile_id;

	$report_url = ( class_exists( 'WP_ANALYTIFY_FUNCTIONS' ) && method_exists( 'WP_ANALYTIFY_FUNCTIONS', 'get_ga_report_url' ) ) ? WP_ANALYTIFY_FUNCTIONS::get_ga_report_url( $dashboard_profile_id ) : '#';

	ob_start();
	?>

	<div class="analytify_general_status analytify_status_box_wraper">
		<div class="analytify_status_header">
			<h3>
			<?php esc_html_e( 'Top Countries by Engagement', 'wp-analytify-pro' ); ?>
			<a href="<?php echo esc_url( ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_all_stats_link' ) ) ? WPANALYTIFY_Utils::get_all_stats_link( $report_url, 'top_countries_sales', $report_date_range ) : '#' ); ?>" target="_blank" class="analytify_tooltip"><span class="analytify_tooltiptext"><?php esc_html_e( 'View All Top Countries', 'wp-analytify-pro' ); ?></span><span aria-hidden="true" class="dashicons dashicons-external"></span></a>
			<a href="#" class="analytify-export-data analytify_tooltip" data-stats-type="top-sales-countries">
				<span class="analytify_tooltiptext"><?php esc_html_e( 'Export Top Countries by Engagement', 'wp-analytify-pro' ); ?></span>
			</a>
			<img src="<?php echo esc_url( admin_url( 'images/spinner.gif' ) ); ?>" class='analytify-export-loader' style="display:none">
			</h3>
		</div>
		
		<div class="analytify_status_body">

		<?php
		if ( ! empty( $country_stats['rows'] ) ) :
			$code           = '';
			$highest_number = $country_stats['rows'][0]['itemViews'];
			$lowest_number  = 0;
			?>

			<script>
			jQuery(document).ready(function ($) {

						var geographic_stats_graph = echarts.init( document.getElementById('analytify_geographic_stats_graph' ) );
						var geographic_stats_graph_option = {
						tooltip : {
							trigger: 'item',
							formatter :  function( params, ticket, callback ) {
							var value = (params.value + '').split('.');

							if ( value[0]  != '-' ) {
								value = value[0];
							} else {
								value = 0;
							}
							let revenue = 0;
							if (params.data && params.data.revenue != null) {
								revenue = params.data.revenue;
							}
							return  params.name + '<br />' + 'Product Detail Views : ' + value + '<br /> Add To Carts : '  + revenue  ;
							}
						},
						toolbox: {
							show : false,
							orient : 'horizontal',
							x: 'right',
							y: '10',
							feature : {
							restore : { show: true },
							saveAsImage : { show: true }
							}
						},
						roamController: {
							show: true,
							mapTypeControl: {
							'world': true
							},
							x: 'right',
							y: 'bottom'
						},
						dataRange: {
							min: <?php echo esc_html( $lowest_number ); ?>,
							max: <?php echo esc_html( $highest_number ); ?>,
							text:['High','Low'],
							realtime: true,
							calculable : true,
							color: ['#ff5252','#ffbc00','#448aff']
						},
						series : [
							{
							name: 'Geographic Stats',
							type: 'map',
							mapType: 'world',
							roam: false,
							scaleLimit :{
								min: 1,
								max: 10
							},
							scrollwheel: false,
							mapLocation: {
								y : 60
							},
							itemStyle:{
								emphasis:{label:{show:true}}
							},
							data:[
								<?php foreach ( $country_stats['rows'] as $country ) : ?>
								{name : '<?php echo esc_html( 'United States' === $country['country'] ? 'United States of America' : $country['country'] ); ?>', value : <?php echo esc_html( $country['itemViews'] ); ?>, revenue : '<?php echo esc_html( $country['addToCarts'] ); ?>'},
								<?php endforeach; ?>
							]
							}
						]
						};

						// Load data into the ECharts instance.
						geographic_stats_graph.setOption(geographic_stats_graph_option);

						window.onresize = function () {
						geographic_stats_graph.resize();
						}
				});
			</script>

			<div class="analytify_txt_center analytify_graph_wraper">
				<div id="analytify_geographic_stats_graph" style="height:600px"></div>
			</div>
			<div class="analytify_clearfix">
				<table class="analytify_data_tables analytify_border_th_tp wp_analytify_paginated" data-product-per-page="10">
				<thead>
					<tr>
					<th class="analytify_table_header_no_events">
					#
					</th>
					<th class="analytify_txt_left"><?php esc_html_e( 'Country Name', 'wp-analytify-pro' ); ?></th>
					<th class="analytify_value_row"><?php esc_html_e( 'Product Detail Views', 'wp-analytify-pro' ); ?></th>
					<th class="analytify_value_row"><?php esc_html_e( 'Add To Carts', 'wp-analytify-pro' ); ?></th>
					</tr>
				</thead>
				<tbody>

				<?php $counter = 0; ?>
				<?php foreach ( $country_stats['rows'] as $key => $country ) : ?>
					<?php ++$counter; ?>
					<tr>
						<td>
						<?php echo esc_html( $counter ); ?>
						</td>
						<td><span class="<?php echo esc_attr( function_exists( 'pretty_class' ) ? pretty_class( $country['country'] ) : 'analytify_default_flag' ); ?> analytify_flages"></span> <?php echo esc_html( $country['country'] ); ?></td>
						<td class="analytify_txt_center"> <?php echo esc_html( $country['itemViews'] ); ?></td>
						<td class="analytify_txt_center"> <?php echo esc_html( $country['addToCarts'] ); ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
				</table>
			</div>
			<div class="analytify_status_footer">
				<div class="wp_analytify_pagination"></div>
			</div>
			<?php
			elseif ( is_object( $wp_analytify ) && method_exists( $wp_analytify, 'no_records' ) ) :
					$wp_analytify->no_records();
				else :
					echo '<p>' . esc_html__( 'No data available', 'wp-analytify-pro' ) . '</p>';
			endif;
				?>
		</div>
	</div>

	<?php

	wp_send_json(
		array(
			'body' => ob_get_clean(),
		)
	);
}

