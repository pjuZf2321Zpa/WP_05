<?php
/**
 * Measuring ROI view for WooCommerce.
 *
 * @package WP_Analytify_Pro
 */

/**
 * Display Measuring ROI stats for WooCommerce.
 *
 * @param mixed                    $current Analytify Free object or context.
 * @param array<int|string, mixed> $stats Contains stats that are fetch from google.
 * @param string                   $report_url Report URL.
 * @param string                   $report_date_range Report date range.
 * @return void
 * @since  2.0.6
 */
function wpa_woo_measuring_roi( mixed $current, array $stats, string $report_url, string $report_date_range ) {

	$famous = '';
	if ( isset( $stats['rows'] ) && isset( $stats['rows'][0]['sourceMedium'] ) ) {
		$famous = $stats['rows'][0]['sourceMedium'];
	} ?>

	<div class="analytify_general_status analytify_status_box_wraper">
	<div class="analytify_status_header">
		<h3>
		<?php esc_html_e( 'Measuring ROI', 'wp-analytify-pro' ); ?>
		<a href="<?php echo esc_url( ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_all_stats_link' ) ) ? WPANALYTIFY_Utils::get_all_stats_link( $report_url, 'source_medium', $report_date_range ) : '#' ); ?>" target="_blank" class="analytify_tooltip"><span class="analytify_tooltiptext"><?php esc_html_e( 'View All Top ROI', 'wp-analytify-pro' ); ?></span><span aria-hidden="true" class="dashicons dashicons-external"></span></a>
		<a href="#" class="analytify-export-data analytify_tooltip" data-stats-type="measuring-roi">
			<span class="analytify_tooltiptext"><?php esc_html_e( 'Export Measuring ROI', 'wp-analytify-pro' ); ?></span>
		</a>
		<img src="<?php echo esc_url( admin_url( 'images/spinner.gif' ) ); ?>" class='analytify-export-loader' style="display:none">
		</h3>
	</div>
	<div class="analytify_status_body">

		<table class="analytify_data_tables wp_analytify_paginated" data-product-per-page="10">
		<thead>
			<tr>
			<th class="analytify_table_header_no_events">
				#
			</th>
			<th>
				<?php esc_html_e( 'Source/Medium', 'wp-analytify-pro' ); ?>
			</th>
			<th>
				<?php esc_html_e( 'Session', 'wp-analytify-pro' ); ?>
			</th>
			<th >
				<?php esc_html_e( 'Bounce Rate', 'wp-analytify-pro' ); ?>
			</th>
			<th >
				<?php esc_html_e( 'Transactions Revenue', 'wp-analytify-pro' ); ?>
			</th>
			</tr>
		</thead>
		<tbody>
			<?php
			if ( ! empty( $stats['rows'] ) ) {
				$i = 0;
				foreach ( $stats['rows'] as $stat ) {
					++$i;
					?>
					<tr>
					<td>
						<?php echo esc_html( $i ); ?>
					</td>
					<td>
						<?php echo esc_html( $stat['sourceMedium'] ); ?>
					</td>
					<td class="analytify_txt_center">
						<?php
						if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' ) ) {
							echo esc_html( WPANALYTIFY_Utils::pretty_numbers( $stat['sessions'] ) );
						} else {
							echo esc_html( number_format( $stat['sessions'] ) );
						}
						?>
					</td>
					<td class="analytify_txt_center">
						<?php
						if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' ) ) {
							echo esc_html( WPANALYTIFY_Utils::pretty_numbers( $stat['bounceRate'] ) . '%' );
						} else {
							echo esc_html( number_format( $stat['bounceRate'], 2 ) . '%' );
						}
						?>
					</td>
					<td class="analytify_txt_center">
					<?php
					$currency_code = ( isset( $stat['currencyCode'] ) && '(not set)' !== $stat['currencyCode'] ) ? $stat['currencyCode'] : '';
					echo esc_html( WP_Analytify_WooCommerce_Addon::analytify_format_currency( $stat['purchaseRevenue'], $currency_code ) );
					?>
					</td>
					</tr>
					<?php
				}
			} else {
				?>
			<tr>
				<td class='analytify_td_error_msg' colspan='6'>
				<?php
				if ( is_object( $current ) && method_exists( $current, 'no_records' ) ) {
					$current->no_records();
				} else {
					echo '<p>' . esc_html__( 'No data available', 'wp-analytify-pro' ) . '</p>';
				}
				?>
				</td>
			</tr>
			<?php } ?>
		</tbody>
		</table>
	</div>
	<div class="analytify_status_footer">
		<span class="analytify_info_stats">
		<?php
		if ( isset( $stat['sourceMedium'] ) ) :
			// translators: %1$s is strong opening tag, %2$s is source name, %3$s is strong closing tag.
			printf( esc_html__( 'Did you know the famous Source of Sale is %1$s %2$s %3$s?', 'wp-analytify-pro' ), '<strong>', esc_html( trim( $famous ) ), '</strong>' );
		else :
			esc_html_e( 'List of all the sources of sale.', 'wp-analytify-pro' );
		endif;
		?>
		</span>
			<div class="wp_analytify_pagination"></div>
		</div>
	</div>
		
	<?php
}

