<?php
/**
 * Coupons Performance view.
 *
 * @package WP_Analytify_Pro
 */

/**
 * Display coupons performance statistics.
 *
 * @param mixed                    $wp_analytify Analytify object or context.
 * @param array<int|string, mixed> $stats Statistics data.
 *
 * @return void
 */
function wpa_wocommerce_coupons_performance( mixed $wp_analytify, array $stats ) {
	?>

	<div class="analytify_general_status analytify_status_box_wraper">
		<div class="analytify_status_header">
		<h3>
			<?php esc_html_e( 'Coupons Analysis', 'wp-analytify-pro' ); ?>
			<a href="#" class="analytify-export-data analytify_tooltip" data-stats-type="coupons-analysis">
			<span class="analytify_tooltiptext"><?php esc_html_e( 'Export Coupons Analysis', 'wp-analytify-pro' ); ?></span>
			</a>
			<img src="<?php echo esc_url( admin_url( 'images/spinner.gif' ) ); ?>" class='analytify-export-loader' style="display:none">
		</h3>
		</div>
		<div class="analytify_status_body">
		<table class="analytify_data_tables wp_analytify_paginated" data-product-per-page="10">
			<thead>
			<tr>
				<th class="analytify_table_header_no_events">
				#
				</th>
				<th>
				<?php esc_html_e( 'Coupon Code', 'wp-analytify-pro' ); ?>
				</th>
				<th>
				<?php esc_html_e( 'Revenue', 'wp-analytify-pro' ); ?>
				</th>
				<th >
				<?php esc_html_e( 'Transactions', 'wp-analytify-pro' ); ?>
				</th>
			</tr>
			</thead>
			<tbody>
			<?php
			if ( ! empty( $stats['rows'] ) ) {
				$i = 0;
				foreach ( $stats['rows'] as $stat ) {
					++$i;
					?>
				<tr>
					<td>
					<?php echo esc_html( $i ); ?>
					</td>
					<td>
					<?php echo esc_html( $stat['orderCoupon'] ); ?>
					</td>
					<td class="analytify_txt_center">
					<?php
					$currency_code = ( isset( $stat['currencyCode'] ) && '(not set)' !== $stat['currencyCode'] ) ? $stat['currencyCode'] : '';
					echo esc_html( WP_Analytify_WooCommerce_Addon::analytify_format_currency( $stat['purchaseRevenue'], $currency_code ) );
					?>
					</td>
					<td class="analytify_txt_center">
					<?php echo esc_html( $stat['transactions'] ); ?>
					</td>
				</tr>
					<?php
				}
			} else {
				?>
				<tr>
				<td class="analytify_td_error_msg" colspan="5">
					<?php
					if ( is_object( $wp_analytify ) && method_exists( $wp_analytify, 'no_records' ) ) {
						$wp_analytify->no_records();
					} else {
						echo esc_html( '<p>' . esc_html__( 'No data available', 'wp-analytify-pro' ) . '</p>' );
					}
					?>
				</td>
				</tr>
				<?php
			}
			?>
			</tbody>
		</table>
		</div>
		<div class="analytify_status_footer">
		<span class="analytify_info_stats">
			<?php
			if ( isset( $stats['rows'] ) && isset( $stats['rows'][0]['orderCoupon'] ) ) :
				// translators: %1$s is strong opening tag, %2$s is coupon name, %3$s is strong closing tag.
				printf( esc_html__( 'Did you know the famous Coupon in your store is %1$s %2$s %3$s?', 'wp-analytify-pro' ), '<strong>', esc_html( $stats['rows'][0]['orderCoupon'] ), '</strong>' );
			else :
				esc_html_e( 'List of all the coupons used at store.', 'wp-analytify-pro' );
			endif;
			?>
		</span>
		<div class="wp_analytify_pagination"></div>
	</div>
</div>

<script type="text/javascript">
	jQuery(document).ready(function($) {
		wp_analytify_paginated();
	});
</script>

	<?php
}

