<?php
/**
 * Product Categories Performance view.
 *
 * @package WP_Analytify_Pro
 */

/**
 * Display product categories performance stats.
 *
 * @param mixed                    $current Current object or context.
 * @param array<int|string, mixed> $stats Statistics data.
 * @return void
 */
function wpa_woocommerce_categories_performance( mixed $current, array $stats ) {

	ob_start();
	?>

	<div class="analytify_general_status analytify_status_box_wraper">
		<div class="analytify_status_header">
		<h3>
			<?php esc_html_e( 'Product Categories Analysis', 'wp-analytify-pro' ); ?>
			<a href="#" class="analytify-export-data analytify_tooltip" data-stats-type="product-categories">
				<span class="analytify_tooltiptext"><?php esc_html_e( 'Export Product Categories Analysis', 'wp-analytify-pro' ); ?></span>
			</a>
			<img src="<?php echo esc_url( admin_url( 'images/spinner.gif' ) ); ?>" class='analytify-export-loader' style="display:none">
		</h3>
		</div>
		<div class="analytify_status_body">

		<table class="analytify_data_tables">
			<thead>
			<tr>
				<th class="analytify_table_header_no_events">
				#
				</th>
				<th>
				<?php esc_html_e( 'Name', 'wp-analytify-pro' ); ?>
				</th>
				<th>
				<?php esc_html_e( 'Product Revenue', 'wp-analytify-pro' ); ?>
				</th>
				<th class="">
				<?php esc_html_e( 'Quantity', 'wp-analytify-pro' ); ?>
				</th>
				<th class="">
				<?php esc_html_e( 'Cart-to-Detail Rate', 'wp-analytify-pro' ); ?>
				</th>
			</tr>
			</thead>
			<tbody>
			<?php
			if ( ! empty( $stats['rows'] ) ) {
				$i = 0;
				foreach ( $stats['rows'] as $stat ) {
					++$i;
					?>
				<tr>
					<td data-heading="#">
					<?php echo esc_html( $i ); ?>
					</td>
					<td data-heading="<?php esc_html_e( 'Name', 'wp-analytify-pro' ); ?>">
					<?php echo esc_html( $stat['itemCategory'] ); ?>
					</td>
					<td data-heading="<?php esc_html_e( 'Product Revenue', 'wp-analytify-pro' ); ?>" class="analytify_txt_center">
					<?php
					$currency_code = ( isset( $stat['currencyCode'] ) && '(not set)' !== $stat['currencyCode'] ) ? $stat['currencyCode'] : '';
					echo esc_html( WP_Analytify_WooCommerce_Addon::analytify_format_currency( $stat['itemRevenue'], $currency_code ) );
					?>
					</td>
					<td data-heading="<?php esc_html_e( 'Quantity', 'wp-analytify-pro' ); ?>" class="analytify_txt_center">
					<?php echo esc_html( $stat['itemPurchaseQuantity'] ); ?>
					</td>
					<td data-heading="<?php esc_html_e( 'Cart-to-Detail Rate', 'wp-analytify-pro' ); ?>">
					<?php
					$percent_quantity = 0;
					if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'fraction_to_percentage' ) ) {
						$percent_quantity = WPANALYTIFY_Utils::fraction_to_percentage( $stat['cartToViewRate'] );
					}
					?>
					<?php echo esc_html( $percent_quantity ); ?> %
					<span class="analytify_bar_graph">
						<span style="width: <?php echo esc_html( $percent_quantity ); ?>%;"></span>
					</span>
					</td>
				</tr>
					<?php
				}
			} else {
				?>
				<tr>
				<td  class="analytify_td_error_msg" colspan="7">
					<?php
					if ( is_object( $current ) && method_exists( $current, 'no_records' ) ) {
						$current->no_records();
					} else {
						echo '<p>' . esc_html__( 'No data available', 'wp-analytify-pro' ) . '</p>';
					}
					?>
				</td>
				</tr>
				<?php } ?>
			</tbody>
			</table>
		</div>
		<div class="analytify_status_footer">

			<?php if ( isset( $stats['rows'][0]['itemCategory'] ) ) : ?>
			<span class="analytify_info_stats">
				<?php
				// translators: %1$s is strong opening tag, %2$s is category name, %3$s is strong closing tag.
				printf( esc_html__( 'Did you know the famous Product Category in your store is %1$s %2$s %3$s?', 'wp-analytify-pro' ), '<strong>', esc_html( $stats['rows'][0]['itemCategory'] ), '</strong>' );
				?>
			</span>
			<?php endif; ?>

		</div>
	</div>
	<?php

	wp_send_json(
		array(
			'body' => ob_get_clean(),
		)
	);
}


