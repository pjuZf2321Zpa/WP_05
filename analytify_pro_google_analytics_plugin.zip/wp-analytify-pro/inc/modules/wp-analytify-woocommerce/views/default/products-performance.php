<?php
/**
 * Products Performance view for WooCommerce.
 *
 * @package WP_Analytify_Pro
 */

/**
 * Display Products Performance stats for WooCommerce.
 *
 * @param mixed                    $wp_analytify Analytify object or context.
 * @param array<int|string, mixed> $stats Statistics data.
 * @param string                   $report_url Report URL.
 * @param string                   $report_date_range Report date range.
 * @return void
 */
function wpa_wocommerce_products( mixed $wp_analytify, array $stats, string $report_url, string $report_date_range ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed
	?>

	<div class="analytify_general_status analytify_status_box_wraper">
		<div class="analytify_status_header">
			<h3>
				<?php esc_html_e( 'Products Performance', 'wp-analytify-pro' ); ?>
				<a href="#" class="analytify-export-data analytify_tooltip" data-stats-type="products-performance">
					<span class="analytify_tooltiptext"><?php esc_html_e( 'Export Products Performance', 'wp-analytify-pro' ); ?></span>
				</a>
				<img src="<?php echo esc_url( admin_url( 'images/spinner.gif' ) ); ?>" class='analytify-export-loader' style="display:none">
			</h3>
		</div>
		<div class="analytify_status_body">

			<table class="analytify_data_tables wp_analytify_paginated" data-product-per-page="10">
				<thead>
					<tr>
						<th class="analytify_table_header_no_events" data-heading="#3">
							#
						</th>
						<th>
							<?php esc_html_e( 'Name', 'wp-analytify-pro' ); ?>
						</th>
						<th>
							<?php esc_html_e( 'Product Revenue', 'wp-analytify-pro' ); ?>
						</th>
						<th class="">
							<?php esc_html_e( 'Quantity', 'wp-analytify-pro' ); ?>
						</th>
						<th class="">
							<?php esc_html_e( 'Cart-to-Detail Rate', 'wp-analytify-pro' ); ?>
						</th>
						<th class="">
							<?php esc_html_e( 'Buy-to-Detail Rate', 'wp-analytify-pro' ); ?>
						</th>
					</tr>
				</thead>
				<tbody>

					<?php
					if ( ! empty( $stats['rows'] ) ) {
						$i = 0;
						foreach ( $stats['rows'] as $stat ) {
							++$i;
							?>
							<tr>
								<td>
									<?php echo esc_html( $i ); ?>
								</td>
								<td>
									<?php echo esc_html( $stat['itemName'] ); ?>
								</td>
								<td class="analytify_txt_center">
								<?php
								$currency_code = ( isset( $stat['currencyCode'] ) && '(not set)' !== $stat['currencyCode'] ) ? $stat['currencyCode'] : '';
								echo esc_html( WP_Analytify_WooCommerce_Addon::analytify_format_currency( $stat['itemRevenue'], $currency_code ) );
								?>
								</td>
								<td class="analytify_txt_center">
									<?php echo esc_html( $stat['itemPurchaseQuantity'] ); ?>
								</td>
								<td>
									<?php
									$percent_quantity = 0;
									if ( class_exists( 'WPANALYTIFY_UTILS' ) && method_exists( 'WPANALYTIFY_UTILS', 'fraction_to_percentage' ) ) {
										$percent_quantity = WPANALYTIFY_UTILS::fraction_to_percentage( $stat['cartToViewRate'] );
									}
									?>
									<?php echo esc_html( $percent_quantity ); ?> %
									<span class="analytify_bar_graph">
										<span style="width: <?php echo esc_attr( $percent_quantity ); ?>%;"></span>
									</span>
								</td>
								<td>
									<?php $percent_quantity = number_format( $stat['purchaseToViewRate'], 2 ); ?>
									<?php echo esc_html( $percent_quantity ); ?> %
									<span class="analytify_bar_graph">
										<span style="width: <?php echo esc_attr( $percent_quantity ); ?>%;"></span>
									</span>
								</td>
								<?php // phpcs:disable Squiz.PHP.CommentedOutCode.Found, Squiz.Commenting.InlineComment.InvalidEndChar ?>
								<!-- <td>
									<?php // $percent_quantity = number_format( $stat[5], 2 ); ?>
									<?php // echo esc_html( $percent_quantity ); ?> %
									<span class="analytify_bar_graph">
										<span style="width: <?php // echo $percent_quantity; ?>%;"></span>
									</span>
								</td> -->
								<?php // phpcs:enable Squiz.PHP.CommentedOutCode.Found, Squiz.Commenting.InlineComment.InvalidEndChar ?>
							</tr>
							<?php
						}
					} else {
						?>
						<tr>
							<td class="analytify_td_error_msg" colspan="7">
						<?php
						if ( is_object( $wp_analytify ) && method_exists( $wp_analytify, 'no_records' ) ) {
							$wp_analytify->no_records();
						} else {
							echo esc_html( '<p>' . esc_html__( 'No data available', 'wp-analytify-pro' ) . '</p>' );
						}
						?>
							</td>
						</tr>
						<?php
					}
					?>
				</tbody>
			</table>
		</div>
		<div class="analytify_status_footer">
			<?php if ( isset( $stats['rows'] ) && isset( $stats['rows'][0]['itemName'] ) ) : ?>
				<span class="analytify_info_stats">
					<?php
					// translators: %1$s is strong opening tag, %2$s is product name, %3$s is strong closing tag.
					printf( esc_html__( 'Did you know the most selling product (quantity wise) in your store is %1$s %2$s %3$s?', 'wp-analytify-pro' ), '<strong>', esc_html( $stats['rows'][0]['itemName'] ), '</strong>' );
					?>
				</span>
				<div class="wp_analytify_pagination"></div>
			<?php endif; ?>
		</div>
	</div>
<?php } ?>

<script type="text/javascript">
	jQuery(document).ready(function($) {
		wp_analytify_paginated();
	});
</script>

