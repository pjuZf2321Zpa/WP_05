<?php
/**
 * WooCommerce Subscription Tracking Class.
 *
 * @package WP_Analytify_Pro
 * @since   8.1.1
 */

// phpcs:ignoreFile WordPress.Files.FileName.InvalidClassFileName

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Track WooCommerce Subscriptions, only for the subscriptions plugin built by WooThemes.
 * https://woocommerce.com/products/woocommerce-subscriptions/
 *
 * @since 3.0
 */
if ( ! class_exists( 'Analytify_Woo_Subscription' ) ) {
class Analytify_Woo_Subscription {

	/**
	 * Constructor method.
	 */
	public function __construct() {

		add_filter( 'analytify_do_not_track_completed_purchase', array( $this, 'set_subscription_order_identity' ), 10, 2 );
		add_action( 'subscriptions_activated_for_order', array( $this, 'track_subscription_activate' ), 10, 1 );
		add_action( 'woocommerce_subscription_status_on-hold_to_active', array( $this, 'track_reactivated_subscription' ) );
		add_action( 'woocommerce_subscription_status_on-hold', array( $this, 'track_suspend_subscription' ) );
		add_action( 'woocommerce_subscription_status_cancelled', array( $this, 'track_cancelled_subscription' ) );
		add_action( 'woocommerce_scheduled_subscription_trial_end', array( $this, 'track_trail_ended' ) );
		add_action( 'woocommerce_scheduled_subscription_end_of_prepaid_term', array( $this, 'track_end_of_prepaid' ) );
		add_action( 'woocommerce_scheduled_subscription_expiration', array( $this, 'track_expire_subscription' ) );
	}

	/**
	 * Return WooCommerce addon global if available; otherwise null.
	 *
	 * @return object|null
	 * @since 8.1.1
	 */
	private function analytify_get_woo_global() {
		if ( ! isset( $GLOBALS['WPAnalytifyProWooCommerce'] ) || ! is_object( $GLOBALS['WPAnalytifyProWooCommerce'] ) ) {
			return null;
		}
		$woo = $GLOBALS['WPAnalytifyProWooCommerce'];
		if ( ! isset( $woo->core_tracking_handler ) || ! is_object( $woo->core_tracking_handler ) || ! method_exists( $woo->core_tracking_handler, 'get_cid' ) ) {
			return null;
		}
		return $woo;
	}

	/**
	 * Get subscription identity.
	 *
	 * @param object $track_completed_purchase Tracking object.
	 * @param int    $order_id Order ID.
	 * @return object
	 * @since 8.1.1
	 */
	public function set_subscription_order_identity( $track_completed_purchase, $order_id ) {

		$subscriptions = function_exists( 'wcs_get_subscriptions_for_renewal_order' ) ? wcs_get_subscriptions_for_renewal_order( $order_id ) : array();

		if ( empty( $subscriptions ) ) {
			return $track_completed_purchase;
		}

		$woo = $this->analytify_get_woo_global();
		if ( null === $woo ) {
			return $track_completed_purchase;
		}

		foreach ( $subscriptions as $subscription ) {
			$subscription_id  = $subscription->get_id(); // order id.
			$subscription_cid = get_post_meta( $order_id, 'analytify_woo_cid', true );

			if ( empty( $subscription_cid ) ) {
				$subscription_cid = $woo->core_tracking_handler->get_woo_cid( $order_id );
				$woo->store_ga_identity( $order_id, $subscription_cid );
			}

			$related_orders = $subscription->get_related_orders( 'ids' );

			if ( $subscription_cid && ! empty( $related_orders ) ) {
				foreach ( $related_orders as $related_order_id ) {
					$related_order_cid = get_post_meta( $related_order_id, 'analytify_woo_cid', true );

					if ( empty( $related_order_cid ) ) {
						$subscription_cid = $woo->core_tracking_handler->get_woo_cid( $related_order_id );
						$woo->store_ga_identity( $related_order_id, $subscription_cid );
					}
				}
			}
		}

		return $track_completed_purchase;
	}

	/**
	 * Track when subscription complete.
	 *
	 * @param mixed $order Order object or ID.
	 * @return void
	 * @since 3.0
	 */
	public function track_subscription_activate( mixed $order ) {

		if ( ! class_exists( 'WC_Order' ) || ! $order instanceof WC_Order ) {
			$order = function_exists( 'wc_get_order' ) ? wc_get_order( $order ) : null;
		}

		if ( ! $order ) {
			return;
		}

		$subscriptions = function_exists( 'wcs_get_subscriptions_for_order' ) ? wcs_get_subscriptions_for_order( $order ) : array();

		if ( empty( $subscriptions ) ) {
			return;
		}

		$woo = $this->analytify_get_woo_global();
		if ( null === $woo ) {
			return;
		}

		foreach ( $subscriptions as $subscription ) {

			$cid = $woo->core_tracking_handler->get_woo_cid( $subscription->get_id() );

			if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {

				$event[] = array(
					'name'   => 'subscription_activated',
					'params' => array(
						'wpa_category' => 'subscription_id',
						'wpa_label'    => $subscription->get_id(),
					),
				);

				if ( function_exists( 'analytify_mp_ga4' ) ) {
					analytify_mp_ga4( $event );
				}
			} else {

				$attr = array(
					't'   => 'event',
					'ec'  => 'Tracking by Analytify Woo Subscription', // category.
					'ea'  => 'subscription activated',
					'el'  => $subscription->get_id(),
					'cid' => $cid,
				);

				// Ensure hit method exists.
				if ( method_exists( $woo, 'hit' ) ) {
					$woo->hit( $attr );
				}
			}
		}
	}

	/**
	 * Track when user resubscribe.
	 *
	 * @param mixed $subscription Subscription object.
	 * @return void
	 * @since 3.0
	 */
	public function track_reactivated_subscription( mixed $subscription ) {

		$woo = $this->analytify_get_woo_global();
		if ( null === $woo ) {
			return;
		}

		$cid = $woo->core_tracking_handler->get_woo_cid( $subscription->get_id() );

		if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {

			$event[] = array(
				'name'   => 'subscription_reactivated',
				'params' => array(
					'wpa_category' => 'subscription_id',
					'wpa_label'    => $subscription->get_id(),
					'wpa_user_id'  => $subscription->get_user_id(),
				),
			);

			if ( function_exists( 'analytify_mp_ga4' ) ) {
				analytify_mp_ga4( $event );
			}
		} else {

			$attr = array(
				't'   => 'event',
				'ec'  => 'Tracking by Analytify Woo Subscription', // category
				'ea'  => 'subscription reactivated',
				'el'  => $subscription->get_id(),
				'uid' => $subscription->get_user_id(),
				'ni'  => 1,
				'cid' => $cid,
			);

			if ( method_exists( $woo, 'hit' ) ) {
				$woo->hit( $attr );
			}
		}
	}

	/**
	 * Track when subscription suspend.
	 *
	 * @param mixed $subscription Subscription object.
	 * @return void
	 * @since 3.0
	 */
	public function track_suspend_subscription( mixed $subscription ) {

		$woo = $this->analytify_get_woo_global();
		if ( null === $woo ) {
			return;
		}

		$cid = $woo->core_tracking_handler->get_woo_cid( $subscription->get_id() );

		if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {

			$event[] = array(
				'name'   => 'subscription_suspended',
				'params' => array(
					'wpa_category' => 'subscription_id',
					'wpa_label'    => $subscription->get_id(),
					'wpa_user_id'  => $subscription->get_user_id(),
				),
			);

			if ( function_exists( 'analytify_mp_ga4' ) ) {
				analytify_mp_ga4( $event );
			}
		} else {

			$attr = array(
				't'   => 'event',
				'ec'  => 'Tracking by Analytify Woo Subscription', // category
				'ea'  => 'subscription suspended',
				'el'  => $subscription->get_id(),
				'uid' => $subscription->get_user_id(),
				'ni'  => 1,
				'cid' => $cid,
			);

			if ( method_exists( $woo, 'hit' ) ) {
				$woo->hit( $attr );
			}
		}
	}

	/**
	 * Track when subscription cancelled.
	 *
	 * @param mixed $subscription Subscription object.
	 * @return void
	 * @since 3.0
	 */
	public function track_cancelled_subscription( mixed $subscription ) {

		$woo = $this->analytify_get_woo_global();
		if ( null === $woo ) {
			return;
		}

		$cid = $woo->core_tracking_handler->get_woo_cid( $subscription->get_id() );

		if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {

			$event[] = array(
				'name'   => 'subscription_cancelled',
				'params' => array(
					'wpa_category' => 'subscription_id',
					'wpa_label'    => $subscription->get_id(),
					'wpa_user_id'  => $subscription->get_user_id(),
				),
			);

			if ( function_exists( 'analytify_mp_ga4' ) ) {
				analytify_mp_ga4( $event );
			}
		} else {

			$attr = array(
				't'   => 'event',
				'ec'  => 'Tracking by Analytify Woo Subscription', // category
				'ea'  => 'subscription cancelled',
				'el'  => $subscription->get_id(),
				'uid' => $subscription->get_user_id(),
				'ni'  => 1,
				'cid' => $cid,
			);

			if ( method_exists( $woo, 'hit' ) ) {
				$woo->hit( $attr );
			}
		}
	}

	/**
	 * Track trail conversion.
	 *
	 * @param mixed $subscription_id Subscription ID.
	 * @return void
	 * @since 3.0
	 */
	public function track_trail_ended( mixed $subscription_id ) {

		$subscription = function_exists( 'wcs_get_subscription' ) ? wcs_get_subscription( $subscription_id ) : null;

		if ( ! $subscription ) {
			return;
		}

		$woo = $this->analytify_get_woo_global();
		if ( null === $woo ) {
			return;
		}

		$cid = $woo->core_tracking_handler->get_woo_cid( $subscription_id );

		if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {

			$event[] = array(
				'name'   => 'subscription_trial_ended',
				'params' => array(
					'subscription_id' => $subscription->get_id(),
					'user_id'         => $subscription->get_user_id(),
					'cid'             => $cid,
				),
			);

			$trial_conversion_event_name = ( $subscription->get_completed_payment_count() > 1 ) ? 'subscription_trial_converted' : 'subscription_trial_cancelled';

			$event[] = array(
				'name'   => $trial_conversion_event_name,
				'params' => array(
					'wpa_category' => 'subscription_id',
					'wpa_label'    => $subscription->get_id(),
					'wpa_user_id'  => $subscription->get_user_id(),
				),
			);

			if ( function_exists( 'analytify_mp_ga4' ) ) {
				analytify_mp_ga4( $event );
			}
		} else {
			$attr = array(
				't'   => 'event',
				'ec'  => 'Tracking by Analytify Woo Subscription', // category
				'ea'  => 'subscription trial ended',
				'el'  => $subscription->get_id(),
				'uid' => $subscription->get_user_id(),
				'ni'  => 1,
				'cid' => $cid,
			);

			if ( method_exists( $woo, 'hit' ) ) {
				$woo->hit( $attr );
			}

			// Handle trial conversions - if a subscription has more than a single completed payment, assume it converted.
			if ( $subscription->get_completed_payment_count() > 1 ) {
				$attr = array(
					't'   => 'event',
					'ec'  => 'Tracking by Analytify Woo Subscription', // category.
					'ea'  => 'subscription trial converted',
					'el'  => $subscription->get_id(),
					'uid' => $subscription->get_user_id(),
					'ni'  => 1,
					'cid' => $cid,
				);
				if ( method_exists( $woo, 'hit' ) ) {
					$woo->hit( $attr );
				}
			} else {
				$attr = array(
					't'   => 'event',
					'ec'  => 'Tracking by Analytify Woo Subscription', // category.
					'ea'  => 'subscription trial cancelled',
					'el'  => $subscription->get_id(),
					'uid' => $subscription->get_user_id(),
					'ni'  => 1,
					'cid' => $cid,
				);
				if ( method_exists( $woo, 'hit' ) ) {
					$woo->hit( $attr );
				}
			}
		}
	}

	/**
	 * Track when subscription of prepaid term.
	 *
	 * @param mixed $subscription_id Subscription ID.
	 * @return void
	 * @since 3.0
	 */
	public function track_end_of_prepaid( mixed $subscription_id ) {

		$subscription = function_exists( 'wcs_get_subscription' ) ? wcs_get_subscription( $subscription_id ) : null;

		if ( ! $subscription ) {
			return;
		}

		$woo = $this->analytify_get_woo_global();
		if ( null === $woo ) {
			return;
		}

		$cid = $woo->core_tracking_handler->get_woo_cid( $subscription_id );

		if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {

			$event[] = array(
				'name'   => 'subscription_end_of_prepaid_term',
				'params' => array(
					'wpa_category' => 'subscription_id',
					'wpa_label'    => $subscription->get_id(),
					'wpa_user_id'  => $subscription->get_user_id(),
				),
			);

			if ( function_exists( 'analytify_mp_ga4' ) ) {
				analytify_mp_ga4( $event );
			}
		} else {

			$attr = array(
				't'   => 'event',
				'ec'  => 'Tracking by Analytify Woo Subscription', // category
				'ea'  => 'subscription end of prepaid term',
				'el'  => $subscription->get_id(),
				'uid' => $subscription->get_user_id(),
				'ni'  => 1,
				'cid' => $cid,
			);

			if ( method_exists( $woo, 'hit' ) ) {
				$woo->hit( $attr );
			}
		}
	}

	/**
	 * Track when subscription expired.
	 *
	 * @param mixed $subscription_id Subscription ID.
	 * @return void
	 * @since 3.0
	 */
	public function track_expire_subscription( mixed $subscription_id ) {

		$subscription = function_exists( 'wcs_get_subscription' ) ? wcs_get_subscription( $subscription_id ) : null;

		if ( ! $subscription ) {
			return;
		}

		$woo = $this->analytify_get_woo_global();
		if ( null === $woo ) {
			return;
		}

		$cid = $woo->core_tracking_handler->get_woo_cid( $subscription_id );

		if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {

			$event[] = array(
				'name'   => 'subscription_expired',
				'params' => array(
					'wpa_category' => 'subscription_id',
					'wpa_label'    => $subscription->get_id(),
					'wpa_user_id'  => $subscription->get_user_id(),
				),
			);

			if ( function_exists( 'analytify_mp_ga4' ) ) {
				analytify_mp_ga4( $event );
			}
		} else {

			$attr = array(
				't'   => 'event',
				'ec'  => 'Tracking by Analytify Woo Subscription', // category
				'ea'  => 'subscription expired',
				'el'  => $subscription->get_id(),
				'uid' => $subscription->get_user_id(),
				'ni'  => 1,
				'cid' => $cid,
			);

			if ( method_exists( $woo, 'hit' ) ) {
				$woo->hit( $attr );
			}
		}
	}
}
}

new Analytify_Woo_Subscription();
