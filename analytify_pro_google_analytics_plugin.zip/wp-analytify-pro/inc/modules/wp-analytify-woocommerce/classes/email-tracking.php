<?php
/**
 * WooCommerce Email Tracking Class.
 *
 * @package WP_Analytify_Pro
 */

// phpcs:ignoreFile WordPress.Files.FileName.InvalidClassFileName

// Exit, if access file directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
if ( ! class_exists( 'Analytify_Woo_Email_Tracking' ) ) {
	/**
	 * Track WooCommerce Email Events.
	 *
	 * @since 3.0
	 */
	class Analytify_Woo_Email_Tracking {

		/**
		 * Email instances.
		 *
		 * @var array<string, mixed>|null
		 */
		private $emails;

		/**
		 * Constructor method.
		 */
		public function __construct() {

			add_action( 'woocommerce_after_template_part', array( $this, 'add_track_image' ), 10, 4 );
			add_filter( 'wp_analytify_pro_setting_fields', array( $this, 'add_settings' ), 20, 1 );
		}

		/**
		 *  Add tracking script in email.
		 * @version 8.1.1
		 * @param string               $template_name Template name.
		 * @param string               $template_path Template path.
		 * @param string               $located Located path.
		 * @param array<string, mixed> $args Arguments.
		 * @return void
		 */
		public function add_track_image( $template_name, $template_path, $located, $args = array() ) {

			// Return if template name is empty.
			if ( empty( $template_name ) ) {
				return;
			}

			// Return if not an email template or if it is a plain email template.
			if ( strpos( $template_name, 'emails/' ) === false || strpos( $template_name, 'emails/plain/' ) !== false ) {
				return;
			}

		$is_tracking_enabled = $GLOBALS['WP_ANALYTIFY']->settings->get_option( 'woo_email_tracking', 'wp-analytify-advanced', 'off' );

		// Return, if tracking is not enabled.
		if ( 'off' === $is_tracking_enabled ) {
			return;
		}

			$tracking_id = class_exists( 'WP_ANALYTIFY_FUNCTIONS' ) && method_exists( 'WP_ANALYTIFY_FUNCTIONS', 'get_UA_code' ) ? WP_ANALYTIFY_FUNCTIONS::get_UA_code() : '';

			// Return, if profile is not selected.
			if ( ! $tracking_id ) {
				return;
			}

			$email = $this->get_email_by_template_html_path( $template_name );

			if ( ! $email ) {
				return;
			}

			// Return, if the order is not a type of WC Order.
			if ( ! isset( $args['order'] ) || ! class_exists( 'WC_Order' ) || ! $args['order'] instanceof WC_Order ) {
				return;
			}

			$order = $args['order'];
			$cid   = get_post_meta( $order->get_id(), 'analytify_woo_cid', true );
			$uid   = (int) $order->get_customer_id();

			$woo_addon = isset( $GLOBALS['WPAnalytifyProWooCommerce'] ) && is_object( $GLOBALS['WPAnalytifyProWooCommerce'] )
				? $GLOBALS['WPAnalytifyProWooCommerce']
				: null;

			// Logged-in customers only: skip pixel when their role is in Analytify “exclude from tracking” list.
			if ( $uid > 0 && $woo_addon && method_exists( $woo_addon, 'analytify_is_tracking_enabled_for_user' )
				&& ! $woo_addon->analytify_is_tracking_enabled_for_user( $uid ) ) {
				return;
			}

			$url     = 'https://www.google-analytics.com/g/collect?';
			$payload = array(
				'v'                 => 2,
				'tid'               => $tracking_id,
				'cid'               => $cid,
				'en'                => 'open',
				'ep.event_category' => 'Tracking by Analytify Woo Emails',
				'ep.event_label'    => urlencode( $email->title ),
				'ep.page_path'      => urlencode( '/emails/' . sanitize_title( $email->title ) ),
				'ep.page_title'     => urlencode( $email->title ),
			);

			// Only attach User ID if it's a registered customer.
			if ( $uid > 0 ) {
				$payload['uid'] = $uid;
			}

			// phpcs:disable WordPress.PHP.DiscouragedPHPFunctions.urlencode_urlencode -- Required for Google Analytics API.
			$query = urldecode( http_build_query( $payload, '', '&' ) );
			// phpcs:enable WordPress.PHP.DiscouragedPHPFunctions.urlencode_urlencode

			printf( '<img src="%s" alt="" />', esc_url( $url . $query ) );
		}

		/**
		 * Get the email by path.
		 *
		 * @param string $template_path Template path.
		 * @return mixed|null
		 */
		private function get_email_by_template_html_path( string $template_path ) {

				$found_email = null;

			foreach ( $this->get_emails() as $email ) {

				if ( $template_path === $email->template_html ) {

					$found_email = $email;
					break;
				}
			}

			return $found_email;
		}

		/**
		 * Get all emails thats send to the user.
		 *
		 * @return array<string, mixed>
		 */
		public function get_emails() {

			if ( ! isset( $this->emails ) ) {

				$wc_emails    = class_exists( 'WC_Emails' ) ? WC_Emails::instance() : null;
			$all_emails   = $wc_emails && is_object( $wc_emails ) && method_exists( $wc_emails, 'get_emails' ) ? $wc_emails->get_emails() : array();
			$track_emails = array();

			// only track customer emails.
			if ( ! empty( $all_emails ) ) {
				foreach ( $all_emails as $key => $email ) {

					$pos = strpos( $email->id, 'customer_' );

					if ( false !== $pos && 0 === $pos ) {
							$track_emails[ $key ] = $email;
						}
					}
				}

				$this->emails = $track_emails;
			}

			return $this->emails;
		}


		/**
		 * Add a settings field in the advanced tab.
		 *
		 * @param array<string, mixed> $settings Settings array.
		 * @return array<string, mixed>
		 */
		public function add_settings( array $settings ) {

				$settings['wp-analytify-advanced'][] = array(
					'name'  => 'woo_email_tracking',
					'label' => __( 'WooCommerce Email Tracking', 'wp-analytify-pro' ),
					'desc'  => __( 'Track WooCommerce Email Events.', 'wp-analytify-pro' ),
					'type'  => 'checkbox',
				);

				return $settings;
		}
	}

	new Analytify_Woo_Email_Tracking();
}
