<?php
/**
 * WooCommerce Coupon Handler Class.
 *
 * @package WP_Analytify_Pro
 * @since 8.0.0
 */

// phpcs:ignoreFile WordPress.Files.FileName.InvalidClassFileName

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * ============================================================================
 * WOOCOMMERCE COUPON TRACKING HANDLER
 * ============================================================================
 *
 * PURPOSE: This class handles all coupon-related e-commerce tracking events for
 *          WooCommerce integration with Google Analytics (GA4, gtag, Universal Analytics).
 *
 * RESPONSIBILITIES:
 * - Track coupon application and usage
 * - Monitor coupon effectiveness and conversion impact
 * - Track discount-related user behavior
 *
 * TRACKING EVENTS HANDLED:
 * - applied_coupon: When coupons are applied to orders
 * - removed_coupon: When coupons are removed from orders
 *
 * ANALYTICS INTEGRATION:
 * - Google Analytics 4 (GA4) events
 * - Google Tag Manager (gtag) events
 * - Universal Analytics (ga) events
 *
 * FUNCTIONS INCLUDED:
 * 1. applied_coupon() - Tracks coupon application with GA4/gtag/ga
 * 2. removed_coupon() - Tracks coupon removal with GA4/gtag/ga
 *
 * DEPENDENCIES:
 * - WordPress hooks and filters
 * - WooCommerce coupon functions
 * - Google Analytics tracking functions
 *
 * CREATED: As part of WP Analytify Pro WooCommerce refactoring
 * ============================================================================
 */
if ( ! class_exists( 'WP_Analytify_WooCommerce_Coupon_Handler' ) ) {
class WP_Analytify_WooCommerce_Coupon_Handler {

	/**
	 * Core tracking handler instance
	 *
	 * @var WP_Analytify_WooCommerce_Core_Tracking_Handler
	 */
	private $core_tracking_handler;

	/**
	 * Constructor
	 */
	public function __construct() {
		$this->core_tracking_handler = new WP_Analytify_WooCommerce_Core_Tracking_Handler();
	}

	/**
	 * Track applied coupon
	 * Matches old implementation - uses Measurement Protocol for GA4
	 *
	 * @param string $coupon_code Coupon code.
	 * @return void
	 */
	public function applied_coupon( string $coupon_code ) {
		if ( ! $this->core_tracking_handler->is_track_user() || ! $this->core_tracking_handler->is_ga_enable() ) {
			return;
		}

		// Track coupon application event - matches old implementation.
		if ( defined( 'ANALYTIFY_PRO_TRACKING_MODE' ) && 'gtag' === ANALYTIFY_PRO_TRACKING_MODE ) {
			// For GA4, use Measurement Protocol (matches old implementation).
			if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {
				$event[] = array(
					'name'   => 'coupon_applied',
					'params' => array(
						'event_category' => 'Coupons',
						'event_label'     => esc_html( $coupon_code ),
					),
				);

				if ( function_exists( 'analytify_mp_ga4' ) ) {
					analytify_mp_ga4( $event );
				}
				return;
			} else {
				// For non-GA4 gtag mode.
				$code = 'gtag("event", "coupon_applied", {
					"coupon_code": "' . esc_html( $coupon_code ) . '"
				});';
				$this->core_tracking_handler->add_inline_js_wpa_woo( $code );
			}
		} else {
			// For Universal Analytics.
			$coupon_code_property = array(
				'ID'   => esc_html( $coupon_code ),
				'Name' => esc_html( $coupon_code ),
			);

			$this->core_tracking_handler->add_inline_js_wpa_woo( 'coupon_code=' . wp_json_encode( $coupon_code_property ) . ';' );

			$code = '
			// Enhanced E-commerce Add Coupon Event
			ga("ec:addPromo", {
				"id": coupon_code.ID,
				"name": coupon_code.Name,
			});

			ga("ec:setAction", "promo_click");
			ga("send", "event", "Coupons", "Coupon Applied", coupon_code.Name);
			';
			$this->core_tracking_handler->add_inline_js_wpa_woo( $code );
		}
	}

	/**
	 * Track removed coupon
	 * Matches old implementation - gets coupon code from $_GET['remove_coupon']
	 *
	 * @param string $coupon_code Coupon code (optional, will get from $_GET if not provided).
	 * @return void
	 */
	public function removed_coupon( string $coupon_code = '' ) {
		if ( ! $this->core_tracking_handler->is_track_user() || ! $this->core_tracking_handler->is_ga_enable() ) {
			return;
		}

		// Get coupon code from $_GET if not provided (matches old implementation).
		if ( empty( $coupon_code ) && isset( $_GET['remove_coupon'] ) ) {
			$coupon_code = sanitize_text_field( $_GET['remove_coupon'] );
		}

		if ( empty( $coupon_code ) ) {
			return;
		}

		// Track coupon removal event - matches old implementation.
		if ( defined( 'ANALYTIFY_PRO_TRACKING_MODE' ) && 'gtag' === ANALYTIFY_PRO_TRACKING_MODE ) {
			// For GA4, use client-side gtag (matches old implementation).
			$code = "gtag( 'event', 'Coupon Removed', {
				'event_category': 'Coupons',
				'event_label': '" . esc_html( $coupon_code ) . "',
			});";
			$this->core_tracking_handler->add_inline_js_wpa_woo( $code );
		} else {
			// For Universal Analytics.
			$coupon_code_property = array(
				'ID'   => esc_html( $coupon_code ),
				'Name' => esc_html( $coupon_code ),
			);

			$this->core_tracking_handler->add_inline_js_wpa_woo( 'coupon_code=' . wp_json_encode( $coupon_code_property ) . ';' );

			$code = '
			// Enhanced E-commerce Remove Coupon Event
			ga("ec:addPromo", {
				"id": coupon_code.ID,
				"name": coupon_code.Name,
			});

			ga("ec:setAction", "promo_click");
			ga("send", "event", "Coupons", "Coupon Removed", coupon_code.Name);
			';
			$this->core_tracking_handler->add_inline_js_wpa_woo( $code );
		}
	}
}
}
