<?php
/**
 * WooCommerce Product Handler Class.
 *
 * @package WP_Analytify_Pro
 * @since 8.0.0
 */

// phpcs:ignoreFile WordPress.Files.FileName.InvalidClassFileName

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * ============================================================================
 * WOOCOMMERCE PRODUCT TRACKING HANDLER
 * ============================================================================
 *
 * PURPOSE: This class handles all product-related e-commerce tracking events for
 *          WooCommerce integration with Google Analytics (GA4, gtag, Universal Analytics).
 *
 * RESPONSIBILITIES:
 * - Track product page views and interactions
 * - Monitor product impressions and clicks
 * - Track product engagement and conversion events
 *
 * TRACKING EVENTS HANDLED:
 * - view_product_detail: When users view individual product pages
 * - product_impressions: When products are displayed in lists/catalogs
 * - product_clicks: When users click on product links
 * - products_addToCart: When products are added to cart from product lists
 *
 * ANALYTICS INTEGRATION:
 * - Google Analytics 4 (GA4) events
 * - Google Tag Manager (gtag) events
 * - Universal Analytics (ga) events
 *
 * FUNCTIONS INCLUDED:
 * 1. view_product_detail() - Tracks product page views with GA4/gtag/ga
 * 2. product_impressions() - Tracks product impressions with GA4/gtag/ga
 * 3. product_clicks() - Tracks product clicks with GA4/gtag/ga
 * 4. products_addToCart() - Tracks add to cart from product lists with GA4/gtag/ga
 *
 * DEPENDENCIES:
 * - WordPress hooks and filters
 * - WooCommerce product functions
 * - Google Analytics tracking functions
 *
 * CREATED: As part of WP Analytify Pro WooCommerce refactoring
 * ============================================================================
 */
if ( ! class_exists( 'WP_Analytify_WooCommerce_Product_Handler' ) ) {
class WP_Analytify_WooCommerce_Product_Handler {

	/**
	 * Core tracking handler instance
	 *
	 * @var WP_Analytify_WooCommerce_Core_Tracking_Handler
	 */
	private $core_tracking_handler;

	/**
	 * Constructor
	 */
	public function __construct() {
		$this->core_tracking_handler = new WP_Analytify_WooCommerce_Core_Tracking_Handler();
	}

	/**
	 * Track product detail view
	 *
	 * @return void
	 */
	public function view_product_detail() {
		if ( ! $this->core_tracking_handler->is_track_user() || ! $this->core_tracking_handler->is_ga_enable() ) {
			return;
		}

		global $product;

		$_product_id = $product->get_id();
		$categories  = '';
		$code        = '';

		if ( function_exists( 'is_product' ) && is_product() ) {
			$category = get_the_terms( $_product_id, 'product_cat' );
			if ( $category && ! is_wp_error( $category ) ) {
				foreach ( $category as $term ) {
					$categories .= $term->name . ',';
				}
			}

			$categories = rtrim( $categories, ',' );

			if ( defined( 'ANALYTIFY_PRO_TRACKING_MODE' ) && 'gtag' === ANALYTIFY_PRO_TRACKING_MODE ) {
				if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {
				$item = $this->core_tracking_handler->get_tracked_item_ga4( $_product_id, null, 0, $product->get_price() );
				unset( $item['quantity'] );

				$code = 'gtag("event", "view_item", {
					"items": [ ' . wp_json_encode( $item ) . ' ]
				});';
				} else {
					$code = 'gtag("event", "view_item", {
						"items": [{
							"id": "' . esc_html( $_product_id ) . '",
							"name": "' . esc_html( $product->get_title() ) . '",
							"category": "' . $categories . '",
							"price": "' . $product->get_price() . '",
							"list_name": "",
							"brand": "",
							"variant": "",
						}]
					});';
				}
			} else {
				// product detail view json.
				$p_detail_view_json = array(
					'p_ID'       => esc_html( $_product_id ),
					'p_sku'      => $product->get_sku() ? $product->get_sku() : $_product_id,
					'p_name'     => $product->get_title(),
					'p_category' => $categories,
					'p_price'    => $product->get_price(),
				);

				// $p_detail_view_json is always defined above, no need to check empty.

				// product detail view json.
				$this->core_tracking_handler->add_inline_js_wpa_woo( 'wpa_woo=' . wp_json_encode( $p_detail_view_json ) . ';' );

				$code = '
				ga("ec:addProduct", {
					"id": wpa_woo.p_ID,
					"name": wpa_woo.p_name,
					"category": wpa_woo.p_category,
				});
				ga("ec:setAction", "detail");
				ga("send", "event", "Tracking by Analytify", "detail","product detail view");
				';
			}

			$this->core_tracking_handler->add_inline_js_wpa_woo( $code );
		}
	}

	/**
	 * Track product impressions
	 *
	 * @return void
	 */
	public function product_impressions(){

		if (!$this->is_track_user() || !$this->is_ga_enable()) {
			return;
		}

		global $catpage_json, $catpage_json_ATC_link;
		$code = '';

		$this->add_inline_js_wpa_woo('cat_page_link=' . json_encode($catpage_json_ATC_link) . ';');
		$this->add_inline_js_wpa_woo('cat_page=' . json_encode($catpage_json) . ';');

		$this->js_calls();

		// Track impressions for only Shop Page.
		if (is_shop() and !is_search()) {

			$code .= '
			if( cat_page !== null && cat_page.length !== 0 ){
				product_impressions( cat_page, "Shop Page", "shopPage" );
			}

			// Track Clicks on Products
			jQuery("a:not(.product_type_variable, .product_type_grouped)").on( "click", function() {
				url = jQuery(this).attr("href");
				product_clicks( url, cat_page, "Shop Page", "shopPage" );
			});';
		}

		if (is_product_category()) {

			$code .= '
			if( cat_page !== null && cat_page.length !== 0 ){
				product_impressions( cat_page, "Category Page", "categoryPage" );
			}

			// Track Clicks on Products
			jQuery("a:not(.product_type_variable, .product_type_grouped)").on( "click", function() {
				url = jQuery(this).attr("href");
				product_clicks( url, cat_page, "Category Page", "categoryPage" );
			});';
		}

		if (is_search()) {

			$code .= '
			if( cat_page !== null ) {

				if( cat_page.length !== 0 ) {
					product_impressions( cat_page, "Search Page", "searchPage" );
				}

				// Track Clicks on Products
				jQuery("a:not(.product_type_variable, .product_type_grouped)").on( "click", function() {
					url = jQuery(this).attr("href");
					product_clicks( url, cat_page, "Search Page", "searchPage" );
				});
			}
			';
		}

		if (is_product_category() || is_shop() || is_search()) {

			$code .= '
			jQuery("a[href*=add-to-cart]").on( "click", function() {

				url = jQuery(this).attr("href");
				qty = jQuery(this).parent().find("input[name=quantity]").val();

				if( qty == "" || qty === undefined) {
					qty = "1";
				}

				products_addToCart( url, cat_page_link, cat_page, qty );
			});
			';
		}

		if (is_home() || is_product() || is_product_category() || is_search() || is_shop()) {
			$this->add_inline_js_wpa_woo($code);
		}
	}

	/**
	 * Define JavaScript functions for product tracking
	 *
	 * @return void
	 */
	private function js_calls() {
		$non_interaction = (apply_filters('analytify_non_interaction_impression', false)) ? '{"nonInteraction": 1}' : '';

		if (method_exists('WPANALYTIFY_Utils', 'get_ga_mode') && 'ga4' === WPANALYTIFY_Utils::get_ga_mode()) {
			// GA4 implementation
			$code = '
			function product_impressions(products_list, list_name, label) {
				if (typeof gtag !== "function") return;

				let items = [];
				for (var p_index in products_list) {
					if (products_list.hasOwnProperty(p_index)) {
						items.push({
							"item_id": products_list[p_index].p_ID,
							"item_name": products_list[p_index].p_name,
							"item_category": products_list[p_index].p_category,
							"price": products_list[p_index].p_price,
							"index": products_list[p_index].p_position,
							"item_list_name": list_name
						});
					}
				}

				if (items.length > 0) {
					gtag("event", "view_item_list", {
						"items": items
					});
				}
			}

			function product_clicks(url, products_list, list_name, label) {
				if (typeof gtag !== "function") return false;

				if (products_list.hasOwnProperty(url)) {
					gtag("event", "select_item", {
						"items": [{
							"item_id": products_list[url].p_ID,
							"item_name": products_list[url].p_name,
							"item_category": products_list[url].p_category,
							"price": products_list[url].p_price,
							"index": products_list[url].p_position,
							"item_list_name": list_name
						}]
					});
					return true;
				}
				return false;
			}';
		} else {
			// Universal Analytics (ga) implementation
			$code = '
			function product_impressions(products_list, list_name, label) {
				if (typeof ga !== "function") return;

				let t_json_length = Object.keys(products_list).length;

				for (var p_index in products_list) {
					if (products_list.hasOwnProperty(p_index)) {
						ga("ec:addImpression", {
							"id": products_list[p_index].p_ID,
							"name": products_list[p_index].p_name,
							"category": products_list[p_index].p_category,
							"list": list_name,
							"price": products_list[p_index].p_price,
							"position": products_list[p_index].p_position
						});
					}
				}
				ga("send", "event", "Tracking by Analytify", "onLoad", "productImpression_" + label, ' . $non_interaction . ');
			}

			function product_clicks(url, products_list, list_name, label) {
				if (typeof ga !== "function") return false;

				if (products_list.hasOwnProperty(url)) {
					let t_call_fired = true;

					ga("ec:addProduct", {
						"id": products_list[url].p_ID,
						"name": products_list[url].p_name,
						"category": products_list[url].p_category,
						"price": products_list[url].p_price,
						"position": products_list[url].p_position
					});

					ga("ec:setAction", "click", { "list": list_name });
					ga("send", "event", "Tracking by Analytify", "click", "productClick_" + label);

					return t_call_fired;
				} else {
					return false;
				}
			}';
		}

		$this->add_inline_js_wpa_woo($code);
	}

	/**
	 * Track product impressions with specific parameters
	 *
	 * @param array $products_list List of products.
	 * @param string $list_name Name of the list.
	 * @param string $label Label for tracking.
	 * @return void
	 */
	/**
	 * Product impressions list tracking.
	 *
	 * @param array<int|string, mixed> $products_list Products list.
	 * @param string                   $list_name List name.
	 * @param string                   $label Label.
	 * @return void
	 */
	public function product_impressions_list( array $products_list, string $list_name, string $label ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed
		if ( ! $this->core_tracking_handler->is_track_user() || ! $this->core_tracking_handler->is_ga_enable() ) {
			return;
		}

		if ( defined( 'ANALYTIFY_PRO_TRACKING_MODE' ) && 'gtag' === ANALYTIFY_PRO_TRACKING_MODE ) {
			if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {
				$items = array();
				foreach ( $products_list as $product ) {
					$items[] = $this->core_tracking_handler->get_tracked_item_ga4( $product->get_id(), null, 0, $product->get_price() );
			}
			$code = 'gtag("event", "view_item_list", {
				"item_list_name": "' . esc_html( $list_name ) . '",
				"items": ' . wp_json_encode( $items ) . '
			});';
			} else {
				$code = 'gtag("event", "view_item_list", {
					"item_list_name": "' . esc_html( $list_name ) . '"
				});';
			}
		} else {
			$code = 'ga("ec:setAction", "impression");';
		}

		$this->core_tracking_handler->add_inline_js_wpa_woo( $code );
	}

	/**
	 * Track product clicks
	 *
	 * @param string                   $url URL.
	 * @param array<int|string, mixed> $products_list List of products.
	 * @param string                   $list_name Name of the list.
	 * @param string                   $label Label for tracking.
	 * @return void
	 */
	public function product_clicks( string $url, array $products_list, string $list_name, string $label ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed
		if ( ! $this->core_tracking_handler->is_track_user() || ! $this->core_tracking_handler->is_ga_enable() ) {
			return;
		}

		if ( defined( 'ANALYTIFY_PRO_TRACKING_MODE' ) && 'gtag' === ANALYTIFY_PRO_TRACKING_MODE ) {
			if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {
				$items = array();
				foreach ( $products_list as $product ) {
					$items[] = $this->core_tracking_handler->get_tracked_item_ga4( $product->get_id(), null, 0, $product->get_price() );
			}
			$code = 'gtag("event", "select_item", {
				"item_list_name": "' . esc_html( $list_name ) . '",
				"items": ' . wp_json_encode( $items ) . '
			});';
			} else {
				$code = 'gtag("event", "select_item", {
					"item_list_name": "' . esc_html( $list_name ) . '"
				});';
			}
		} else {
			$code = 'ga("ec:setAction", "click", {"list": "' . esc_html( $list_name ) . '"});';
		}

		$this->core_tracking_handler->add_inline_js_wpa_woo( $code );
	}

	/**
	 * Track products added to cart from product lists
	 *
	 * @param string                   $url URL.
	 * @param string                   $url_addToCart Add to cart URL.
	 * @param array<int|string, mixed> $products_list List of products.
	 * @param int                      $qty Quantity.
	 * @return void
	 */
	// phpcs:ignore WordPress.NamingConventions.ValidFunctionName.MethodNameInvalid
	public function products_addToCart( string $url, string $url_addToCart, array $products_list, int $qty ) { // phpcs:ignore WordPress.NamingConventions.ValidVariableName.VariableNotSnakeCase
		if ( ! $this->core_tracking_handler->is_track_user() || ! $this->core_tracking_handler->is_ga_enable() ) {
			return;
		}

		if ( defined( 'ANALYTIFY_PRO_TRACKING_MODE' ) && 'gtag' === ANALYTIFY_PRO_TRACKING_MODE ) {
			if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {
				$items = array();
				foreach ( $products_list as $product ) {
					$items[] = $this->core_tracking_handler->get_tracked_item_ga4( $product->get_id(), null, $qty, $product->get_price() );
			}
			$code = 'gtag("event", "add_to_cart", {
				"currency": "' . ( function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : 'USD' ) . '",
				"value": ' . array_sum( array_column( $items, 'price' ) ) . ',
				"items": ' . wp_json_encode( $items ) . '
			});';
			} else {
				$code = 'gtag("event", "add_to_cart", {
					"currency": "' . ( function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : 'USD' ) . '"
				});';
			}
		} else {
			$code = 'ga("ec:setAction", "add");';
		}

		$this->core_tracking_handler->add_inline_js_wpa_woo( $code );
	}

}
}
