<?php
/**
 * WooCommerce Checkout Handler Class.
 *
 * @package WP_Analytify_Pro
 * @since 8.0.0
 */

// phpcs:ignoreFile WordPress.Files.FileName.InvalidClassFileName

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * ============================================================================
 * WOOCOMMERCE CHECKOUT TRACKING HANDLER
 * ============================================================================
 *
 * PURPOSE: This class handles all checkout-related e-commerce tracking events for
 *          WooCommerce integration with Google Analytics (GA4, gtag, Universal Analytics).
 *
 * RESPONSIBILITIES:
 * - Track checkout step progression through the funnel
 * - Monitor checkout abandonment and completion rates
 * - Track user behavior during the checkout process
 *
 * TRACKING EVENTS HANDLED:
 * - product_checkout_step2: Billing information step
 * - product_checkout_step3: Shipping information step
 * - product_checkout_step4: Payment method selection step
 *
 * ANALYTICS INTEGRATION:
 * - Google Analytics 4 (GA4) events
 * - Google Tag Manager (gtag) events
 * - Universal Analytics (ga) events
 *
 * FUNCTIONS INCLUDED:
 * 1. product_checkout_step2() - Tracks billing info step with GA4/gtag/ga
 * 2. product_checkout_step3() - Tracks shipping info step with GA4/gtag/ga
 * 3. product_checkout_step4() - Tracks payment method step with GA4/gtag/ga
 *
 * DEPENDENCIES:
 * - WordPress hooks and filters
 * - WooCommerce checkout functions
 * - Google Analytics tracking functions
 *
 * CREATED: As part of WP Analytify Pro WooCommerce refactoring
 * ============================================================================
 */
if ( ! class_exists( 'WP_Analytify_WooCommerce_Checkout_Handler' ) ) {
class WP_Analytify_WooCommerce_Checkout_Handler {

	/**
	 * Core tracking handler instance
	 *
	 * @var WP_Analytify_WooCommerce_Core_Tracking_Handler
	 */
	private $core_tracking_handler;

	/**
	 * Constructor
	 */
	public function __construct() {
		$this->core_tracking_handler = new WP_Analytify_WooCommerce_Core_Tracking_Handler();
	}

	/**
	 * Enhanced E-commerce tracking for checkout step 2
	 *
	 * @access public
	 * @return void
	 */
	public function product_checkout_step2() {
		if ( ! $this->core_tracking_handler->is_track_user() ) {
			return;
		}

		if ( ! $this->core_tracking_handler->is_ga_enable() ) {
			return;
		}

		if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {

			// Get cart contents.
			$cart_contents = function_exists( 'WC' ) ? WC()->cart->get_cart() : array();

			// Check to make sure cart has items.
			if ( empty( $cart_contents ) ) {
				return;
			}

			$items = array();

			foreach ( $cart_contents as $item ) {
				$product_id   = $item['product_id'];
				$variation_id = isset( $item['variation_id'] ) ? $item['variation_id'] : null;

				$items[] = $this->core_tracking_handler->get_tracked_item_ga4( $product_id, $variation_id, $item['quantity'] );
			}

			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.MissingUnslash -- GA cookie contains alphanumeric tracking ID, unslashing would damage it.
			$session_id = $this->core_tracking_handler->analytify_filter_session_id( $_COOKIE );

			$event[] = array(
				'name'   => 'add_payment_info',
				'params' => array(
					'items'      => $items,
					'session_id' => $session_id,
				),
			);

			// For GA4, send via Measurement Protocol (server-side) AND client-side for real-time visibility.
			if ( function_exists( 'analytify_mp_ga4' ) ) {
				analytify_mp_ga4( $event );
			}

			// Also send client-side for real-time visibility in GA4.
			$items_json = wp_json_encode( $items );
			$code       = "
			if (typeof gtag !== 'undefined') {
				gtag('event', 'add_payment_info', {
					'items': {$items_json}
				});
			}
			";
			$this->core_tracking_handler->add_inline_js_wpa_woo( $code );

			return;
		}

		global $woocommerce;

		$cart_products = array();
		$variations    = array();
		$categories    = '';

		// Product list name.
		$list_name = $this->core_tracking_handler->get_product_list();

		foreach ( $woocommerce->cart->cart_contents as $key => $value ) {
			$p = wc_get_product( $value['product_id'] );

			$category = get_the_terms( $value['product_id'], 'product_cat' );

			if ( $category ) {
				foreach ( $category as $term ) {
					$categories .= $term->name . ',';
				}
			}

			if ( isset( $value['variation'] ) ) {
				foreach ( $value['variation'] as $variation => $variation_value ) {
					array_push( $variations, $variation_value );
				}
			}

			$categories = rtrim( $categories, ',' );

			$cart_checkout_products[ get_permalink( $p->get_id() ) ] = array(
				'p_ID'       => esc_html( $p->get_id() ),
				'p_sku'      => esc_html( $p->get_sku() ? $p->get_sku() : $p->get_id() ),
				'p_name'     => esc_html( $p->get_title() ),
				'p_price'    => esc_html( $p->get_price() ),
				'p_category' => esc_html( $categories ),
				'p_quantity' => $value['quantity'],
				'p_variant'  => ! empty( $variations ) ? implode( ',', $variations ) : '',
				'list_name'  => $list_name,
			);
		}

		$this->core_tracking_handler->add_inline_js_wpa_woo( 'cart_checkout_products=' . wp_json_encode( $cart_checkout_products ) . ';' );

		$code = '';

		if ( defined( 'ANALYTIFY_PRO_TRACKING_MODE' ) && 'gtag' === ANALYTIFY_PRO_TRACKING_MODE ) {

			$code .= '
			var cartItems = [];
			for(var item in cart_checkout_products) {
				cartItems.push({
					"id": cart_checkout_products[item].p_ID,
					"name": cart_checkout_products[item].p_name,
					"category": cart_checkout_products[item].p_category,
					"price": cart_checkout_products[item].p_price,
					"quantity": cart_checkout_products[item].p_quantity,
					"variant": cart_checkout_products[item].p_variant,
					"brand": "",
				});
			}
			gtag("event", "checkout_progress", {
				currency: "' . ( function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : 'USD' ) . '",
				checkout_option: "Billing",
				checkout_step: 2,
				value: ' . $woocommerce->cart->get_cart_contents_total() . ',
				items: cartItems
			});
			gtag("event", "set_checkout_option", {
				checkout_step: 2,
				checkout_option: "Billing",
				value: 2
			});
			';
		} else {

			$code .= '
			for(var item in cart_checkout_products) {
				ga("ec:addProduct", {
					"id": cart_checkout_products[item].p_ID,
					"name": cart_checkout_products[item].p_name,
					"category": cart_checkout_products[item].p_category,
					"price": cart_checkout_products[item].p_price,
					"quantity": cart_checkout_products[item].p_quantity
				});
			}';

			$code .= 'ga("ec:setAction","checkout", { "step": 2 });';
			$code .= 'ga( "send", "event", "Tracking by Analytify", "onLoad", "Product Checkout Billing Form" );';
		}

		$this->core_tracking_handler->add_inline_js_wpa_woo( $code );
	}

	/**
	 * Enhanced E-commerce tracking for checkout step 3
	 *
	 * @access public
	 * @return void
	 */
	public function product_checkout_step3() {
		if ( ! $this->core_tracking_handler->is_track_user() || ! $this->core_tracking_handler->is_ga_enable() ) {
			return;
		}

		if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {

			// Get cart contents.
			$cart_contents = function_exists( 'WC' ) ? WC()->cart->get_cart() : array();

			// Check to make sure cart has items.
			if ( empty( $cart_contents ) ) {
				return;
			}

			$items = array();

			foreach ( $cart_contents as $item ) {
				$product_id   = $item['product_id'];
				$variation_id = isset( $item['variation_id'] ) ? $item['variation_id'] : null;

				$items[] = $this->core_tracking_handler->get_tracked_item_ga4( $product_id, $variation_id, $item['quantity'] );
			}

			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.MissingUnslash -- GA cookie contains alphanumeric tracking ID, unslashing would damage it.
			$session_id = $this->core_tracking_handler->analytify_filter_session_id( $_COOKIE );

			$event[] = array(
				'name'   => 'add_shipping_info',
				'params' => array(
					'items'      => $items,
					'session_id' => $session_id,
				),
			);

			// For GA4, send via Measurement Protocol (server-side) AND client-side for real-time visibility.
			if ( function_exists( 'analytify_mp_ga4' ) ) {
				analytify_mp_ga4( $event );
			}

			// Also send client-side for real-time visibility in GA4.
			$items_json = wp_json_encode( $items );
			$code       = "
			if (typeof gtag !== 'undefined') {
				gtag('event', 'add_shipping_info', {
					'items': {$items_json}
				});
			}
			";
			$this->core_tracking_handler->add_inline_js_wpa_woo( $code );

			return;
		}

		global $woocommerce;

		$cart_products = array();
		$variations    = array();
		$categories    = '';

		// Product list name.
		$list_name = $this->core_tracking_handler->get_product_list();

		foreach ( $woocommerce->cart->cart_contents as $key => $value ) {
			$p = wc_get_product( $value['product_id'] );

			$category = get_the_terms( $value['product_id'], 'product_cat' );

			if ( $category ) {
				foreach ( $category as $term ) {
					$categories .= $term->name . ',';
				}
			}

			if ( isset( $value['variation'] ) ) {
				foreach ( $value['variation'] as $variation => $variation_value ) {
					array_push( $variations, $variation_value );
				}
			}

			$categories = rtrim( $categories, ',' );

			$cart_checkout_products[ get_permalink( $p->get_id() ) ] = array(
				'p_ID'       => esc_html( $p->get_id() ),
				'p_sku'      => esc_html( $p->get_sku() ? $p->get_sku() : $p->get_id() ),
				'p_name'     => esc_html( $p->get_title() ),
				'p_price'    => esc_html( $p->get_price() ),
				'p_category' => esc_html( $categories ),
				'p_quantity' => $value['quantity'],
				'p_variant'  => ! empty( $variations ) ? implode( ',', $variations ) : '',
				'list_name'  => $list_name,
			);
		}

		$this->core_tracking_handler->add_inline_js_wpa_woo( 'cart_checkout_products=' . wp_json_encode( $cart_checkout_products ) . ';' );

		$code = '';

		if ( defined( 'ANALYTIFY_PRO_TRACKING_MODE' ) && 'gtag' === ANALYTIFY_PRO_TRACKING_MODE ) {

			$code .= '
			var cartItems = [];
			for(var item in cart_checkout_products) {
				cartItems.push({
					"id": cart_checkout_products[item].p_ID,
					"name": cart_checkout_products[item].p_name,
					"category": cart_checkout_products[item].p_category,
					"price": cart_checkout_products[item].p_price,
					"quantity": cart_checkout_products[item].p_quantity,
					"variant": cart_checkout_products[item].p_variant,
					"brand": "",
				});
			}
			gtag("event", "checkout_progress", {
				currency: "' . ( function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : 'USD' ) . '",
				checkout_option: "Shipping",
				checkout_step: 3,
				value: ' . $woocommerce->cart->get_cart_contents_total() . ',
				items: cartItems
			});
			gtag("event", "set_checkout_option", {
				checkout_step: 3,
				checkout_option: "Shipping",
				value: 3
			});
			';
		} else {

			$code .= '
			for(var item in cart_checkout_products) {
				ga("ec:addProduct", {
					"id": cart_checkout_products[item].p_ID,
					"name": cart_checkout_products[item].p_name,
					"category": cart_checkout_products[item].p_category,
					"price": cart_checkout_products[item].p_price,
					"quantity": cart_checkout_products[item].p_quantity
				});
			}';

			$code .= 'ga("ec:setAction","checkout", { "step": 3 });';
			$code .= 'ga( "send", "event", "Tracking by Analytify", "onLoad", "Product Checkout Shipping Form" );';
		}

		$this->core_tracking_handler->add_inline_js_wpa_woo( $code );
	}

	/**
	 * Enhanced E-commerce tracking for checkout step 4
	 *
	 * @access public
	 * @return void
	 */
	public function product_checkout_step4() {
		if ( ! $this->core_tracking_handler->is_track_user() || ! $this->core_tracking_handler->is_ga_enable() ) {
			return;
		}

		if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {
			// For GA4, purchase events are tracked on the thank you page, not checkout page.
			// This matches the old implementation behavior.
			return;
		}

		global $woocommerce;

		$code = '';

		if ( defined( 'ANALYTIFY_PRO_TRACKING_MODE' ) && 'gtag' === ANALYTIFY_PRO_TRACKING_MODE ) {

			$code .= '
			var cartItems = [];
			for(var item in cart_checkout_products) {
				cartItems.push({
					"id": cart_checkout_products[item].p_ID,
					"name": cart_checkout_products[item].p_name,
					"category": cart_checkout_products[item].p_category,
					"price": cart_checkout_products[item].p_price,
					"quantity": cart_checkout_products[item].p_quantity,
					"variant": cart_checkout_products[item].p_variant,
					"brand": "",
				});
			}
			gtag("event", "purchase", {
				currency: "' . ( function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : 'USD' ) . '",
				transaction_id: "' . $this->core_tracking_handler->get_order_id() . '",
				value: ' . $this->core_tracking_handler->get_order_total() . ',
				items: cartItems
			});
			';
		} else {

			$code .= '
			for(var item in cart_checkout_products) {
				ga("ec:addProduct", {
					"id": cart_checkout_products[item].p_ID,
					"name": cart_checkout_products[item].p_name,
					"category": cart_checkout_products[item].p_category,
					"price": cart_checkout_products[item].p_price,
					"quantity": cart_checkout_products[item].p_quantity
				});
			}';

			$code .= 'ga("ec:setAction","purchase", { "id": "' . $this->core_tracking_handler->get_order_id() . '", "revenue": "' . $this->core_tracking_handler->get_order_total() . '", "tax": "' . $this->core_tracking_handler->get_order_tax() . '", "shipping": "' . $this->core_tracking_handler->get_order_shipping() . '" });';
			$code .= 'ga( "send", "event", "Tracking by Analytify","onLoad","Checkout Step 4" );';
		}

		$this->core_tracking_handler->add_inline_js_wpa_woo( $code );
	}
}
}
