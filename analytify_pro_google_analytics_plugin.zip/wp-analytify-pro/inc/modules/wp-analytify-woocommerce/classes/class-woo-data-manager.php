<?php
/**
 * WooCommerce Data Manager Class.
 *
 * @package WP_Analytify_Pro
 * @since 8.0.0
 */

// phpcs:ignoreFile WordPress.Files.FileName.InvalidClassFileName

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Class WP_Analytify_WooCommerce_Data_Manager
 *
 * Manages WooCommerce data operations.
 */
if ( ! class_exists( 'WP_Analytify_WooCommerce_Data_Manager' ) ) {
class WP_Analytify_WooCommerce_Data_Manager {

	/**
	 * Constructor.
	 *
	 * @return void
	 */
	public function __construct() {
		// Constructor for data manager.
	}

	/**
	 * Add Source/Medium column to orders table.
	 *
	 * @param array<string, mixed> $columns Columns array.
	 * @return array<string, mixed>
	 */
	public function source_medium_column( array $columns ) {

		$new_columns                     = $columns;
		$new_columns['analytify_source'] = __( 'Source/Medium', 'wp-analytify-pro' );

		return $new_columns;
	}

	/**
	 * Add Source/Medium value for order.
	 *
	 * For WooCommerce HPOS settings only
	 *
	 * @param string $column Column name.
	 * @param mixed  $order Order object.
	 * @return void
	 */
	public function source_medium_value_wc_orders( string $column, $order ) {
		if ( 'analytify_source' === $column ) {

			// Check for the new meta key first.
			$source = $order->get_meta( 'analytify_woo_order_source', true );

			if ( $source ) {
				echo esc_html( $source );
				return;
			}

			// If the new meta key is not found, try the deprecated one.
			$source_medium_deprecated = $order->get_meta( 'analytify_woo_single_source', true );

			if ( $source_medium_deprecated ) {
				echo esc_html( $source_medium_deprecated );
				return;
			}

			// Fetch source/medium on request.
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- GET parameter used for admin display only.
			if ( empty( $source ) && isset( $_GET['analytify_woo_fetch_sale_source'] ) ) {

				$date_created    = $order->get_date_created()->format( 'Y-m-d' );
				$start_timestamp = strtotime( $date_created . ' - 5 days' );
				$end_timestamp   = strtotime( $date_created . ' + 5 days' );
				$start_date      = false !== $start_timestamp ? gmdate( 'Y-m-d', $start_timestamp ) : $date_created;
				$end_date        = false !== $end_timestamp ? gmdate( 'Y-m-d', $end_timestamp ) : $date_created;

				// Get sources from ga4.
				if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {
					$stats = $GLOBALS['WP_ANALYTIFY']->get_reports(
						'analytify_woo_order_source',
						array(),
						array(
							'start' => $start_date,
							'end'   => $end_date,
						),
						array(
							'sourceMedium',
							'transactionId',
						),
						array(),
						array(
							'logic'   => 'AND',
							'filters' => array(
								array(
									'type'       => 'dimension',
									'name'       => 'transactionId',
									'match_type' => 1,
									'value'      => $order->get_id(),
								),
							),
						),
						0,
						false
					);

					if ( ! empty( $stats['rows'][0]['sourceMedium'] ) ) {
						$source = $stats['rows'][0]['sourceMedium'];
						$order->update_meta_data( 'analytify_woo_order_source', $source );
						$order->save();
					}
				} else {
					$stats = $GLOBALS['WP_ANALYTIFY']->pa_get_analytics_dashboard( 'ga:totalEvents', $start_date, $end_date, 'ga:sourceMedium,ga:eventCategory,ga:eventLabel', false, 'ga:eventCategory==analytify_orders;ga:eventAction==order_created;ga:eventLabel==' . $order->get_id() );

					if ( isset( $stats['rows'][0][0] ) ) {
						$source = $stats['rows'][0][0];
						$order->update_meta_data( 'analytify_woo_order_source', $source );
						$order->save();
					}
				}
			}
			echo esc_html( $source );
		}
	}

	/**
	 * Add Source/Medium value.
	 *
	 * For WooCommerce Legacy Orders Column.
	 *
	 * @since 2.0.6
	 *
	 * @param string $column Column name.
	 * @return void
	 */
	public function source_medium_value_order_posts( string $column ) {

		global $post;

		if ( 'analytify_source' === $column ) {

			$source_medium_deprecated = get_post_meta( $post->ID, 'analytify_woo_single_source', true );

			if ( $source_medium_deprecated ) {
				echo esc_html( $source_medium_deprecated );
				return;
			}

			$source = get_post_meta( $post->ID, 'analytify_woo_order_source', true );

			// Fetch source/medium on request.
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- GET parameter used for admin display only.
			if ( empty( $source ) && isset( $_GET['analytify_woo_fetch_sale_source'] ) ) {
				$post_date       = get_the_date( 'Y-m-d', $post->ID );
				$start_timestamp = strtotime( $post_date . ' - 5 days' );
				$end_timestamp   = strtotime( $post_date . ' + 5 days' );
				$start_date      = false !== $start_timestamp ? gmdate( 'Y-m-d', $start_timestamp ) : $post_date;
				$end_date        = false !== $end_timestamp ? gmdate( 'Y-m-d', $end_timestamp ) : $post_date;

				// Get sources from ga4.
				if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {
					$stats = $GLOBALS['WP_ANALYTIFY']->get_reports(
						'analytify_woo_order_source',
						array(),
						array(
							'start' => $start_date,
							'end'   => $end_date,
						),
						array(
							'sourceMedium',
							'transactionId',
						),
						array(),
						array(
							'logic'   => 'AND',
							'filters' => array(
								array(
									'type'       => 'dimension',
									'name'       => 'transactionId',
									'match_type' => 1,
									'value'      => $post->ID,
								),
							),
						),
						0,
						false
					);

					if ( ! empty( $stats['rows'][0]['sourceMedium'] ) ) {
						update_post_meta( $post->ID, 'analytify_woo_order_source', $stats['rows'][0]['sourceMedium'] );
					}
				} else {
					$stats = $GLOBALS['WP_ANALYTIFY']->pa_get_analytics_dashboard( 'ga:totalEvents', $start_date, $end_date, 'ga:sourceMedium,ga:eventCategory,ga:eventLabel', false, 'ga:eventCategory==analytify_orders;ga:eventAction==order_created;ga:eventLabel==' . $post->ID );

					if ( isset( $stats['rows'][0][0] ) ) {
						$source = $stats['rows'][0][0];
						update_post_meta( $post->ID, 'analytify_woo_order_source', $source );
					}
				}
			}

			echo esc_html( $source );
		}
	}

	/**
	 * Show Fetch Source Button on Orders List Page.
	 *
	 * @since 2.0.7
	 *
	 * @param string $which Button position.
	 * @return void
	 */
	public function show_source_fetch_button( string $which ) {

		global $post_type;

		$screen = get_current_screen();

		$analytify_plugin_url = defined( 'ANALYTIFY_PLUGIN_URL' ) ? ANALYTIFY_PLUGIN_URL : '';

		if ( 'shop_order' === $post_type && 'top' === $which ) {
			echo '<input style="background: #fff url(' . esc_url( $analytify_plugin_url . 'assets/img/analytify-logo-small.svg' ) . ') no-repeat left 10px center; padding-left: 35px;" type="submit" class="analytify_woo_fetch_sale_source button-secondary" value="Fetch Traffic Sources" name="analytify_woo_fetch_sale_source" style="margin-top:3px">';
		} elseif ( $screen && 'woocommerce_page_wc-orders' === $screen->id ) {
			echo '<input style="background: #fff url(' . esc_url( $analytify_plugin_url . 'assets/img/analytify-logo-small.svg' ) . ') no-repeat left 10px center; padding-left: 35px;" type="submit" class="analytify_woo_fetch_sale_source button-secondary" value="Fetch Traffic Sources" name="analytify_woo_fetch_sale_source" style="margin-top:3px">';
		}
	}

	/**
	 * Add dropdown option for woo dashboard.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function dashboad_dropdown_option() {

		echo '<li><a href="' . esc_url( admin_url( 'admin.php?page=analytify-woocommerce' ) ) . '">WooCommerce</a></li>';
	}

	/**
	 * Add WooCommerce submenu to Analytify dashboard
	 *
	 * @access public
	 * @return void
	 */
	public static function add_menu() {

		add_submenu_page( 'analytify-dashboard', __( 'Track everything in WooCommerce with Analytify.', 'wp-analytify-pro' ), __( 'WooCommerce', 'wp-analytify-pro' ), 'edit_posts', 'analytify-woocommerce', array( __CLASS__, 'analytify_page_file_path' ), 15 );
	}

	/**
	 * Include file for WooCommerce dashboard page
	 *
	 * @access public
	 * @return void
	 */
	public static function analytify_page_file_path() {

		$screen = get_current_screen();

		if ( $screen && false !== strpos( $screen->base, 'analytify-woocommerce' ) ) {
			$plugin_dir = defined( 'WC_ANALYTIFY_PLUGIN_DIR' ) ? WC_ANALYTIFY_PLUGIN_DIR : __DIR__ . '/..';
			// Load WooCommerce dashboard template.
			include $plugin_dir . '/includes/woocommerce-dashboard.php';
		}
	}

	/**
	 * Initialize e-commerce JS
	 * 
	 * Note: This method is no longer used. Currency is handled by WP_Analytify_WooCommerce_Addon::add_ga_ecommerce_js()
	 * to prevent duplicate currency output.
	 *
	 * @return void
	 */
	public static function add_ga_ecommerce_js() {
		// Currency is now handled by the main WooCommerce addon class to prevent duplicates.
		// This method is kept for backward compatibility but does nothing.
		return;
	}
}
}
