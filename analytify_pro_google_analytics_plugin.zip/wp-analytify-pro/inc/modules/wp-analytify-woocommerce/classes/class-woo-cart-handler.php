<?php
/**
 * WooCommerce Cart Handler Class.
 *
 * @package WP_Analytify_Pro
 * @since 8.0.0
 */

// phpcs:ignoreFile WordPress.Files.FileName.InvalidClassFileName

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * ============================================================================
 * WOOCOMMERCE CART TRACKING HANDLER
 * ============================================================================
 *
 * PURPOSE: This class handles all cart-related e-commerce tracking events for
 *          WooCommerce integration with Google Analytics (GA4, gtag, Universal Analytics).
 *
 * RESPONSIBILITIES:
 * - Track products added to cart
 * - Track products removed from cart
 * - Track cart review step in checkout process
 *
 * TRACKING EVENTS HANDLED:
 * - add_to_cart: When products are added to shopping cart
 * - remove_from_cart: When products are removed from shopping cart
 * - product_review_cart_step1: Cart review step in checkout funnel
 *
 * ANALYTICS INTEGRATION:
 * - Google Analytics 4 (GA4) events
 * - Google Tag Manager (gtag) events
 * - Universal Analytics (ga) events
 *
 * FUNCTIONS INCLUDED:
 * 1. add_to_cart() - Tracks products added to cart with GA4/gtag/ga
 * 2. remove_from_cart() - Tracks products removed from cart with GA4/gtag/ga
 * 3. product_review_cart_step1() - Tracks cart review step in checkout with GA4/gtag/ga
 *
 * DEPENDENCIES:
 * - WordPress hooks and filters
 * - WooCommerce cart functions
 * - Google Analytics tracking functions
 *
 * CREATED: As part of WP Analytify Pro WooCommerce refactoring
 * ============================================================================
 */
if ( ! class_exists( 'WP_Analytify_WooCommerce_Cart_Handler' ) ) {
class WP_Analytify_WooCommerce_Cart_Handler {

	/**
	 * Core tracking handler instance
	 *
	 * @var WP_Analytify_WooCommerce_Core_Tracking_Handler
	 */
	private $core_tracking_handler;

	/**
	 * Constructor
	 */
	public function __construct() {
		$this->core_tracking_handler = new WP_Analytify_WooCommerce_Core_Tracking_Handler();
	}

	/**
	 * Enhanced E-commerce tracking for single product add to cart
	 *
	 * @access public
	 * @return void
	 */
	public function add_to_cart() {
		if ( ! $this->core_tracking_handler->is_track_user() ) {
			return;
		}

		if ( ! $this->core_tracking_handler->is_ga_enable() ) {
			return;
		}

		$code = '';

		if ( defined( 'ANALYTIFY_PRO_TRACKING_MODE' ) && 'gtag' === ANALYTIFY_PRO_TRACKING_MODE ) {
			global $product;

			// Match old implementation - only check if product exists, not is_product().
			if ( ! $product ) {
				return;
			}

			if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {

				$item = $this->core_tracking_handler->get_tracked_item_ga4( $product->get_id(), null, 0, $product->get_price() );
				// Match old implementation exactly - simple jQuery on click handler, no document.ready wrapper.
				$code = "
				jQuery( '.single_add_to_cart_button' ).on( 'click', function() {
					gtag('event', 'add_to_cart', {
						'items': [{
							'item_id': '" . $item['item_id'] . "',
							'item_name': '" . esc_js( $item['item_name'] ) . "',
							'item_category': '" . esc_js( $item['item_category'] ) . "',
							'price': '" . $item['price'] . "',
							'quantity': jQuery( 'form.cart input.qty' ).val() ? jQuery( 'input.qty' ).val() : '1'
						}]
					});
				});
				";
			} else {

				// Will hold the categories as comma separated string.
				$categories = '';

				// Get all product categories.
				$all_categories = get_the_terms( $product->get_id(), 'product_cat' );

				if ( $all_categories && ! is_wp_error( $all_categories ) ) {
					foreach ( $all_categories as $term ) {
						$categories .= $term->name . ',';
					}
				}

				$categories = rtrim( $categories, ',' );

				$code = "
				jQuery( '.single_add_to_cart_button' ).on( 'click', function() {
					gtag('event', 'add_to_cart', {
						'items': [
							{
								'id': '" . esc_js( $product->get_id() ) . "',
								'name': '" . esc_js( $product->get_title() ) . "',
								'list_name': 'Single Product Page',
								'category': '" . esc_js( $categories ) . "',
								'brand': '',
								'variant': '',
								'list_position': 1,
								'quantity': jQuery( 'form.cart input.qty' ).val() ? jQuery( 'input.qty' ).val() : '1',
								'price': '" . esc_js( $product->get_price() ) . "'
							}
						]
					});
				});
				";
			}
		} elseif ( defined( 'ANALYTIFY_PRO_TRACKING_MODE' ) && 'gtag' !== ANALYTIFY_PRO_TRACKING_MODE && function_exists( 'is_product' ) && is_product() ) {
			$code = '
			jQuery("button[class*=add_to_cart_button]").click(function(e) {

				// Enhanced E-commerce Add to cart clicks
				ga("ec:addProduct", {
					"id" : wpa_woo.p_ID,
					"name": wpa_woo.p_name,
					"category" :wpa_woo.p_category,
					"price": wpa_woo.p_price,
					"quantity" :jQuery(this).parent().find("input[name=quantity]").val()
				});

				ga("ec:setAction", "add");
				ga("send", "event", "Enhanced-Ecommerce","click", "add_to_cart_click");
				//e.preventDefault();
			});
			';
		}

		if ( ! empty( $code ) ) {
			$this->core_tracking_handler->add_inline_js_wpa_woo( $code );
		}
	}

	/**
	 * Enhanced E-commerce tracking for single product remove from cart
	 *
	 * @access public
	 * @return void
	 */
	public function remove_from_cart() {
		if ( ! $this->core_tracking_handler->is_track_user() || ! $this->core_tracking_handler->is_ga_enable() ) {
			return;
		}

		global $woocommerce;

		$cart_products = array();
		$categories    = '';
		$code          = '';

		if ( defined( 'ANALYTIFY_PRO_TRACKING_MODE' ) && 'gtag' === ANALYTIFY_PRO_TRACKING_MODE ) {

			$k = 1;

			foreach ( $woocommerce->cart->cart_contents as $key => $value ) {

				if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {

					$cart_products[ $value['product_id'] ] = $this->core_tracking_handler->get_tracked_item_ga4( $value['product_id'], null, $woocommerce->cart->cart_contents[ $key ]['quantity'], null );
				} else {
					$product = function_exists( 'wc_get_product' ) ? wc_get_product( $value['product_id'] ) : null;

					$cart_products[ $product->get_id() ]['id']            = esc_js( $product->get_id() );
					$cart_products[ $product->get_id() ]['name']          = esc_js( $product->get_title() );
					$cart_products[ $product->get_id() ]['list_name']     = 'Cart';
					$cart_products[ $product->get_id() ]['brand']         = '';
					$cart_products[ $product->get_id() ]['category']      = esc_js( $categories );
					$cart_products[ $product->get_id() ]['variant']       = '';
					$cart_products[ $product->get_id() ]['list_position'] = $k;
					$cart_products[ $product->get_id() ]['quantity']      = $woocommerce->cart->cart_contents[ $key ]['quantity'];
					$cart_products[ $product->get_id() ]['price']         = esc_js( $product->get_price() );
				}

				++$k;
			}

			if ( ! empty( $cart_products ) ) {
				$this->core_tracking_handler->add_inline_js_wpa_woo( 'const analytify_cart_items =' . wp_json_encode( $cart_products ) . ';' );
				$this->core_tracking_handler->add_inline_js_wpa_woo(
					"$(document).on('click', 'a.remove[data-product_id]', function(e){
					let analytify_remove_cart_item_id = $(this).attr('data-product_id');
					gtag('event', 'remove_from_cart', {
						'items': [ analytify_cart_items[analytify_remove_cart_item_id] ]
					});
				});"
				);
			}
		} else {

			foreach ( $woocommerce->cart->cart_contents as $key => $value ) {
				$p          = function_exists( 'wc_get_product' ) ? wc_get_product( $value['product_id'] ) : null;
				$remove_url = function_exists( 'wc_get_cart_remove_url' ) ? html_entity_decode( wc_get_cart_remove_url( $key ) ) : '';
				$category   = get_the_terms( $value['product_id'], 'product_cat' );

				if ( $category && ! is_wp_error( $category ) ) {
					foreach ( $category as $term ) {
						$categories .= $term->name . ',';
					}
				}

				$categories                   = rtrim( $categories, ',' );
				$cart_products[ $remove_url ] = array(
					'p_ID'       => esc_html( $p->get_ID() ),
					'p_sku'      => esc_html( $p->get_sku() ? $p->get_sku() : $p->get_ID() ),
					'p_name'     => esc_html( $p->get_title() ),
					'p_price'    => esc_html( $p->get_price() ),
					'p_category' => esc_html( $categories ),
					'p_quantity' => $woocommerce->cart->cart_contents[ $key ]['quantity'],
				);
			}

			$this->core_tracking_handler->add_inline_js_wpa_woo( 'cart_products=' . wp_json_encode( $cart_products ) . ';' );

			$code .= "
			$('a[href*=\"?remove_item\"]').click(function(e){

				item = jQuery(this).attr('href');

				ga('ec:addProduct', {
					'id':cart_products[item].p_ID,
					'name': cart_products[item].p_name,
					'category': cart_products[item].p_category,
					'price': cart_products[item].p_price,
					'quantity': cart_products[item].p_quantity
				});

				ga('ec:setAction', 'remove');
				ga('send', 'event', 'Enhanced-Ecommerce', 'click', 'removeFromCartClick');

			});
			";

			$this->core_tracking_handler->add_inline_js_wpa_woo( $code );
		}
	}

	/**
	 * Enhanced E-commerce tracking for cart step 1
	 *
	 * @access public
	 * @return void
	 */
	public function product_review_cart_step1() {
		if ( ! $this->core_tracking_handler->is_track_user() ) {
			return;
		}

		if ( ! $this->core_tracking_handler->is_ga_enable() ) {
			return;
		}

		if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {

			// Get cart contents.
			$cart_contents = function_exists( 'WC' ) ? WC()->cart->get_cart() : array();

			// Check to make sure cart has items.
			if ( empty( $cart_contents ) ) {
				return;
			}

			$items = array();

			foreach ( $cart_contents as $item ) {
				$product_id   = $item['product_id'];
				$variation_id = isset( $item['variation_id'] ) ? $item['variation_id'] : null;

				$items[] = $this->core_tracking_handler->get_tracked_item_ga4( $product_id, $variation_id, $item['quantity'] );
			}

			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.MissingUnslash -- GA cookie contains alphanumeric tracking ID, unslashing would damage it.
			$session_id = $this->core_tracking_handler->analytify_filter_session_id( $_COOKIE );

			$event[] = array(
				'name'   => 'begin_checkout',
				'params' => array(
					'items'      => $items,
					'session_id' => $session_id,
				),
			);

			// For GA4, send via Measurement Protocol (server-side) AND client-side for real-time visibility.
			if ( function_exists( 'analytify_mp_ga4' ) ) {
				analytify_mp_ga4( $event );
			}

			// Also send client-side for real-time visibility in GA4.
			$items_json = wp_json_encode( $items );
			$code       = "
			if (typeof gtag !== 'undefined') {
				gtag('event', 'begin_checkout', {
					'items': {$items_json}
				});
			}
			";
			$this->core_tracking_handler->add_inline_js_wpa_woo( $code );

			return;
		}

		global $woocommerce;

		$cart_products          = array();
		$variations             = array();
		$categories             = '';
		$cart_checkout_products = array();

		// Product list name.
		$list_name = $this->core_tracking_handler->get_product_list();

		foreach ( $woocommerce->cart->cart_contents as $key => $value ) {
			$p = function_exists( 'wc_get_product' ) ? wc_get_product( $value['product_id'] ) : null;

			$category = get_the_terms( $value['product_id'], 'product_cat' );

			if ( $category && ! is_wp_error( $category ) ) {
				foreach ( $category as $term ) {
					$categories .= $term->name . ',';
				}
			}

			if ( isset( $value['variation'] ) ) {
				foreach ( $value['variation'] as $variation => $variation_value ) {
					array_push( $variations, $variation_value );
				}
			}

			$categories = rtrim( $categories, ',' );
			$cart_checkout_products[ get_permalink( $p->get_id() ) ] = array(
				'p_ID'       => esc_html( $p->get_id() ),
				'p_sku'      => esc_html( $p->get_sku() ? $p->get_sku() : $p->get_ID() ),
				'p_name'     => esc_html( $p->get_title() ),
				'p_price'    => esc_html( $p->get_price() ),
				'p_category' => esc_html( $categories ),
				'p_quantity' => $value['quantity'],
				'p_variant'  => ! empty( $variations ) ? implode( ',', $variations ) : '',
				'list_name'  => $list_name,
			);
		}

		$this->core_tracking_handler->add_inline_js_wpa_woo( 'cart_checkout_products=' . wp_json_encode( $cart_checkout_products ) . ';' );

		$code = '';

		if ( defined( 'ANALYTIFY_PRO_TRACKING_MODE' ) && 'gtag' === ANALYTIFY_PRO_TRACKING_MODE ) {

			$code .= '
			var cartItems = [];
			for(var item in cart_checkout_products) {
				cartItems.push({
					"id": cart_checkout_products[item].p_ID,
					"name": cart_checkout_products[item].p_name,
					"category": cart_checkout_products[item].p_category,
					"price": cart_checkout_products[item].p_price,
					"quantity": cart_checkout_products[item].p_quantity,
					"variant": cart_checkout_products[item].p_variant,
					"brand": "",
				});
			}
			gtag("event", "checkout_progress", {
				currency: "' . ( function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : 'USD' ) . '",
				checkout_option: "Review Cart",
				checkout_step: 1,
				value: ' . $woocommerce->cart->get_cart_contents_total() . ',
				items: cartItems
			});
			gtag("event", "set_checkout_option", {
				checkout_step: 1,
				checkout_option: "Review Cart",
				value: 1
			});
			';
		} else {

			$code .= '
			for(var item in cart_checkout_products) {
				ga("ec:addProduct", {
					"id": cart_checkout_products[item].p_ID,
					"name": cart_checkout_products[item].p_name,
					"category": cart_checkout_products[item].p_category,
					"price": cart_checkout_products[item].p_price,
					"quantity": cart_checkout_products[item].p_quantity
				});
			}';

			$code .= 'ga("ec:setAction","checkout", { "step": 1 });';
			$code .= 'ga( "send", "event", "Tracking by Analytify","onLoad","Product Review Cart" );';
		}

		$this->core_tracking_handler->add_inline_js_wpa_woo( $code );
	}
}
}
