<?php
/**
 * WooCommerce Order Handler Class.
 *
 * @package WP_Analytify_Pro
 * @since 8.0.0
 */

// phpcs:ignoreFile WordPress.Files.FileName.InvalidClassFileName

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * ============================================================================
 * WOOCOMMERCE ORDER TRACKING HANDLER
 * ============================================================================
 *
 * PURPOSE: This class handles all order-related e-commerce tracking events for
 *          WooCommerce integration with Google Analytics (GA4, gtag, Universal Analytics).
 *
 * RESPONSIBILITIES:
 * - Track order creation and completion
 * - Monitor order lifecycle events (refunds, cancellations, reorders)
 * - Track purchase funnel completion and revenue
 *
 * TRACKING EVENTS HANDLED:
 * - order_created: When new orders are created
 * - order_refunded: When orders are refunded
 * - reordered: When customers reorder products
 * - cancelled_order: When orders are cancelled
 * - analytify_track_purchase: Purchase tracking wrapper
 * - analytify_track_complete_payment: Payment completion tracking
 * - track_purchase: Purchase tracking with return value
 *
 * ANALYTICS INTEGRATION:
 * - Google Analytics 4 (GA4) events
 * - Google Tag Manager (gtag) events
 * - Universal Analytics (ga) events
 *
 * FUNCTIONS INCLUDED:
 * 1. order_created() - Tracks new order creation with GA4/gtag/ga
 * 2. order_refunded() - Tracks order refunds with GA4/gtag/ga
 * 3. reordered() - Tracks reorder events with GA4/gtag/ga
 * 4. cancelled_order() - Tracks order cancellations with GA4/gtag/ga
 * 5. analytify_track_purchase() - Purchase tracking wrapper function
 * 6. analytify_track_complete_payment() - Payment completion tracking
 * 7. track_purchase() - Purchase tracking with boolean return
 *
 * DEPENDENCIES:
 * - WordPress hooks and filters
 * - WooCommerce order functions
 * - Google Analytics tracking functions
 *
 * CREATED: As part of WP Analytify Pro WooCommerce refactoring
 * ============================================================================
 */
if ( ! class_exists( 'WP_Analytify_WooCommerce_Order_Handler' ) ) {
class WP_Analytify_WooCommerce_Order_Handler {

	/**
	 * Core tracking handler instance
	 *
	 * @var WP_Analytify_WooCommerce_Core_Tracking_Handler
	 */
	private $core_tracking_handler;

	/**
	 * Constructor
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		$this->core_tracking_handler = new WP_Analytify_WooCommerce_Core_Tracking_Handler();
	}

	/**
	 * Track order creation
	 * Uses Measurement Protocol (server-side) for GA4, matches old implementation
	 *
	 * @param object|int $order Order object or Order ID.
	 * @return void
	 */
	public function order_created( $order ) {
		// Handle both order object and order ID (for compatibility).
		if ( is_numeric( $order ) ) {
			$order = function_exists( 'wc_get_order' ) ? wc_get_order( $order ) : null;
		}

		if ( ! $order || ! $order instanceof WC_Order ) {
			return;
		}

		$order_id = $order->get_id();

		if ( ! $this->core_tracking_handler->is_track_user() || ! $this->core_tracking_handler->is_ga_enable() ) {
			return;
		}

		if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {

			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.MissingUnslash -- GA cookie contains alphanumeric tracking ID, unslashing would damage it.
			$session_id = $this->core_tracking_handler->analytify_filter_session_id( $_COOKIE );

			$event[] = array(
				'name'   => 'order_created',
				'params' => array(
					'currency'    => get_woocommerce_currency(),
					'wpa_category' => 'order_id',
					'wpa_label'   => $order_id,
					'session_id'  => $session_id,
				),
			);

			if ( function_exists( 'analytify_mp_ga4' ) ) {
				analytify_mp_ga4( $event );
			}
		} else {
			$attr = array(
				't'  => 'event',
				'ec' => 'analytify_orders', // Category
				'ea' => 'order_created', // Action
				'el' => $order_id, // Label
				'ev' => $order_id, // Value
			);

			// Use hit method if available (old implementation).
			if ( method_exists( $this->core_tracking_handler, 'hit' ) ) {
				$this->core_tracking_handler->hit( $attr );
			}
		}
	}

	/**
	 * Track order refund
	 * Uses Measurement Protocol (server-side) for GA4, matches old implementation
	 *
	 * @param int      $order_id Order ID.
	 * @param int|null $refund_id Refund ID.
	 * @return void
	 */
	public function order_refunded( int $order_id, ?int $refund_id = null ) {
		// Don't track if the refund is already tracked (matches old implementation).
		if ( $refund_id && 'yes' === get_post_meta( $refund_id, 'wpa_woo_refund_already', true ) ) {
			return;
		}

		// Note: Old implementation doesn't check is_track_user() or is_ga_enable() here.
		$order  = function_exists( 'wc_get_order' ) ? wc_get_order( $order_id ) : null;
		$refund = $refund_id ? ( function_exists( 'wc_get_order' ) ? wc_get_order( $refund_id ) : null ) : null;

		if ( ! $order ) {
			return;
		}

		// Ensure analytify_mp_ga4 function is available.
		if ( ! function_exists( 'analytify_mp_ga4' ) ) {
			$analytify_mp_ga4_file = ( defined( 'WP_ANALYTIFY_PLUGIN_DIR' ) ? WP_ANALYTIFY_PLUGIN_DIR : dirname( dirname( dirname( dirname( dirname( __DIR__ ) ) ) ) ) . '/wp-analytify' ) . '/classes/analytify-mp-ga4.php';
			if ( file_exists( $analytify_mp_ga4_file ) ) {
				require_once $analytify_mp_ga4_file;
			}
		}

		if ( method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.MissingUnslash -- GA cookie contains alphanumeric tracking ID, unslashing would damage it.
			$session_id = $this->core_tracking_handler->analytify_filter_session_id( $_COOKIE );

			$event[] = array(
				'name'   => 'refund',
				'params' => array(
					'currency'     => get_woocommerce_currency(),
					'wpa_category' => 'transaction_id',
					'wpa_label'    => $order->get_order_number(),
					'session_id'   => $session_id,
				),
			);

			if ( function_exists( 'analytify_mp_ga4' ) ) {
				analytify_mp_ga4( $event );
			}
		} else {
			$attr = array(
				't'  => 'event',
				'ec' => 'Tracking by Analytify Woo', // Category
				'ea' => 'Refund',
				'ti' => $order->get_order_number(), // Transaction ID
				'tr' => $refund ? $refund->get_refund_amount() : 0,
				'pa' => 'refund',
			);

			// Use hit method if available (old implementation).
			if ( method_exists( $this->core_tracking_handler, 'hit' ) ) {
				$this->core_tracking_handler->hit( $attr );
			}
		}

		if ( $refund_id ) {
			update_post_meta( $refund_id, 'wpa_woo_refund_already', 'yes' );
		}
	}

	/**
	 * Track reorder event
	 *
	 * @param int $order_id Order ID.
	 * @return void
	 */
	public function reordered( int $order_id ) {
		if ( ! $this->core_tracking_handler->is_track_user() || ! $this->core_tracking_handler->is_ga_enable() ) {
			return;
		}

		$order = function_exists( 'wc_get_order' ) ? wc_get_order( $order_id ) : null;
		if ( ! $order ) {
			return;
		}

		// Track reorder event
		if ( defined( 'ANALYTIFY_PRO_TRACKING_MODE' ) && 'gtag' === ANALYTIFY_PRO_TRACKING_MODE ) {
			$code = 'gtag("event", "reorder", {
				"currency": "' . $order->get_currency() . '",
				"value": ' . $order->get_total() . ',
				"transaction_id": "' . $order->get_order_number() . '"
			});';
		} else {
			$code = 'ga("ec:setAction", "purchase");';
		}

		$this->core_tracking_handler->add_inline_js_wpa_woo( $code );
	}

	/**
	 * Track cancelled order
	 * Matches old implementation - uses Measurement Protocol for GA4
	 *
	 * @param int $order_id Order ID.
	 * @return void
	 */
	public function cancelled_order( int $order_id ) {
		// Old implementation only checks is_track_user(), not is_ga_enable().
		if ( false === $this->core_tracking_handler->is_track_user() ) {
			return;
		}

		// Ensure analytify_mp_ga4 function is available.
		if ( ! function_exists( 'analytify_mp_ga4' ) ) {
			$analytify_mp_ga4_file = ( defined( 'WP_ANALYTIFY_PLUGIN_DIR' ) ? WP_ANALYTIFY_PLUGIN_DIR : dirname( dirname( dirname( dirname( dirname( __DIR__ ) ) ) ) ) . '/wp-analytify' ) . '/classes/analytify-mp-ga4.php';
			if ( file_exists( $analytify_mp_ga4_file ) ) {
				require_once $analytify_mp_ga4_file;
			}
		}

		// Track cancellation event - matches old implementation exactly.
		if ( method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {
			$event[] = array(
				'name'   => 'order_cancelled',
				'params' => array(
					'currency'     => get_woocommerce_currency(),
					'wpa_category' => 'order_id',
					'wpa_label'    => $order_id,
				),
			);

			if ( function_exists( 'analytify_mp_ga4' ) ) {
				analytify_mp_ga4( $event );
			}
		} else {
			// For Universal Analytics (matches old implementation).
			$attr = array(
				't'  => 'event',
				'ec' => 'Tracking by Analytify Woo',
				'ea' => 'Order Cancelled',
				'el' => $order_id,
			);

			// Use hit method if available (old implementation).
			if ( method_exists( $this->core_tracking_handler, 'hit' ) ) {
				$this->core_tracking_handler->hit( $attr );
			} else {
				// Fallback to gtag if hit method is not available.
			$code = 'gtag("event", "order_cancelled", {
					"order_id": "' . $order_id . '"
			});';
		$this->core_tracking_handler->add_inline_js_wpa_woo( $code );
			}
		}
	}

	/**
	 * Track purchase completion
	 * Called from woocommerce_thankyou hook - this is the thank you page tracking
	 * Matches old implementation exactly
	 *
	 * @param int $order_id Order ID.
	 * @return void
	 */
	public function analytify_track_purchase( int $order_id ) {
		/**
		 * Filters whether the completed purchase event should be tracked or not.
		 *
		 * @since 2.1
		 * @param bool $do_not_track true to not track the event, false otherwise
		 * @param int $order_id the order ID
		 */
		if ( true === apply_filters( 'analytify_do_not_track_completed_purchase', false, $order_id ) ) {
			return;
		}

		// Don't track if thank you page purchase event already tracked (use separate meta key from server-side tracking).
		// This allows both server-side (analytify_track_complete_payment) and client-side (this method) tracking to run.
		if ( 'yes' === get_post_meta( $order_id, '_analytify_woo_tracked_thankyou_purchase', true ) ) {
			return;
		}

		$order = function_exists( 'wc_get_order' ) ? wc_get_order( $order_id ) : null;

		// Return if order is not type of WC Order.
		if ( ! $order || ! $order instanceof WC_Order ) {
			return;
		}

		// Only track orders with a 'paid' order status.
		if ( ! $order->is_paid() ) {
			return;
		}

		if ( ! $this->core_tracking_handler->is_track_user() || ! $this->core_tracking_handler->is_ga_enable() ) {
			return;
		}

		// For GA4, directly output client-side JavaScript (matches old implementation).
		if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {

			// Get first coupon code only (matches old implementation).
			$discount = '';
			$coupons  = method_exists( $order, 'get_coupon_codes' ) ? $order->get_coupon_codes() : $order->get_used_coupons();
			if ( ! empty( $coupons ) ) {
				foreach ( $coupons as $code ) {
					if ( ! empty( $code ) ) {
						$discount = $code;
						break;
					}
				}
			}

			$order_items = $order->get_items();
			$items       = array();

			foreach ( $order_items as $key => $item ) {
				$variation_id = $item->get_variation_id() ? $item->get_variation_id() : $item->get_product_id();
				$product_id   = $variation_id > 0 ? wp_get_post_parent_id( $variation_id ) : 0;

				$items[] = $this->core_tracking_handler->get_tracked_item_ga4( $product_id, $variation_id, $item->get_quantity(), $order->get_item_total( $item ) );
			}

			$shipping = method_exists( $order, 'get_shipping_total' ) ? $order->get_shipping_total() : $order->get_total_shipping();

			$items_json = wp_json_encode( $items );

			// Directly echo script for thank you page (matches old implementation exactly).
			echo "<script>gtag('event', 'purchase', {
				transaction_id: '{$order->get_order_number()}',
				value: {$order->get_total()},
				tax: {$order->get_total_tax()},
				shipping: {$shipping},
				currency: '{$order->get_currency()}',
				coupon: '{$discount}',
				items: {$items_json}
			});</script>";
			// Use separate meta key for thank you page purchase event (allows both server-side and client-side tracking).
			update_post_meta( $order_id, '_analytify_woo_tracked_thankyou_purchase', 'yes' );
		} else {
			// For non-GA4, use the standard tracking method.
		$this->track_purchase( $order_id );
		}
	}

	/**
	 * Track purchase on hold
	 *
	 * @param int $order_id Order ID.
	 * @return void
	 */
	public function purchase_on_hold( int $order_id ) {
		$this->track_purchase( $order_id );
	}

	/**
	 * Track complete payment
	 * Uses Measurement Protocol (server-side) for GA4, unlike thank you page which uses client-side gtag
	 * This matches the old implementation behavior
	 *
	 * @param int $order_id Order ID.
	 * @return void
	 */
	public function analytify_track_complete_payment( int $order_id ) {
		/**
		 * Filters whether the completed purchase event should be tracked or not.
		 *
		 * @since 2.1
		 * @param bool $do_not_track true to not track the event, false otherwise
		 * @param int $order_id the order ID
		 */
		if ( true === apply_filters( 'analytify_do_not_track_completed_purchase', false, $order_id ) ) {
			return;
		}

		// Don't track if already tracked.
		if ( 'yes' === get_post_meta( $order_id, '_analytify_woo_tracked_completed_payment', true ) ) {
			return;
		}

		$order = function_exists( 'wc_get_order' ) ? wc_get_order( $order_id ) : null;

		// Return if order is not type of WC Order.
		if ( ! $order || ! $order instanceof WC_Order ) {
			return;
		}

		// Only track orders with a 'paid' order status.
		if ( ! $order->is_paid() ) {
			return;
		}

		if ( ! $this->core_tracking_handler->is_track_user() || ! $this->core_tracking_handler->is_ga_enable() ) {
			return;
		}

		if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {

			// Get first coupon code only (matches old implementation).
			$discount = '';
			$coupons  = method_exists( $order, 'get_coupon_codes' ) ? $order->get_coupon_codes() : $order->get_used_coupons();
			if ( ! empty( $coupons ) ) {
				foreach ( $coupons as $code ) {
					if ( ! empty( $code ) ) {
						$discount = $code;
						break;
					}
				}
			}

			$order_items = $order->get_items();
			$items       = array();

			foreach ( $order_items as $key => $item ) {
				$variation_id = $item->get_variation_id() ? $item->get_variation_id() : $item->get_product_id();
				$product_id   = $variation_id > 0 ? wp_get_post_parent_id( $variation_id ) : 0;

				$items[] = $this->core_tracking_handler->get_tracked_item_ga4( $product_id, $variation_id, $item->get_quantity(), $order->get_item_total( $item ) );
			}

			// Use stored GA cookie value if available.
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.MissingUnslash -- GA cookie contains alphanumeric tracking ID, unslashing would damage it.
			$session_id = $this->core_tracking_handler->analytify_filter_session_id( $_COOKIE );

			$event[] = array(
				'name'   => 'purchase',
				'params' => array(
					'transaction_id' => $order->get_order_number(),
					'value'         => $order->get_total(),
					'tax'           => $order->get_total_tax(),
					'shipping'      => method_exists( $order, 'get_shipping_total' ) ? $order->get_shipping_total() : $order->get_total_shipping(),
					'coupon'        => $discount,
					'currency'      => $order->get_currency(),
					'items'         => $items,
					'session_id'    => $session_id,
				),
			);

			if ( function_exists( 'analytify_mp_ga4' ) ) {
				analytify_mp_ga4( $event );
			}

			update_post_meta( $order_id, '_analytify_woo_tracked_completed_payment', 'yes' );
		} else {
			// For non-GA4, use the standard tracking method.
		$this->track_purchase( $order_id );
		}
	}

	/**
	 * Track purchase with return value
	 *
	 * @param int $order_id Order ID.
	 * @return bool
	 */
	public function track_purchase( int $order_id ) {
		if ( ! $this->core_tracking_handler->is_track_user() ) {
			return false;
		}

		if ( ! $this->core_tracking_handler->is_ga_enable() ) {
			return false;
		}

		$order = function_exists( 'wc_get_order' ) ? wc_get_order( $order_id ) : null;
		if ( ! $order || ! $order->is_paid() ) {
			return false;
		}

		// Don't track if already tracked
		if ( 'yes' === get_post_meta( $order_id, '_analytify_woo_tracked_completed_payment', true ) ) {
			return true;
		}

		// Track purchase event
		if ( defined( 'ANALYTIFY_PRO_TRACKING_MODE' ) && 'gtag' === ANALYTIFY_PRO_TRACKING_MODE ) {
			if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {
				$order_items = $order->get_items();
				$items       = array();

				foreach ( $order_items as $item ) {
					$variation_id = $item->get_variation_id() ? $item->get_variation_id() : $item->get_product_id();
					$product_id   = $variation_id > 0 ? wp_get_post_parent_id( $variation_id ) : 0;

					$items[] = $this->core_tracking_handler->get_tracked_item_ga4( (int) $product_id, $variation_id, $item->get_quantity(), $order->get_item_total( $item ) );
				}

				$shipping = is_object( $order ) && method_exists( $order, 'get_shipping_total' ) ? $order->get_shipping_total() : ( is_object( $order ) && method_exists( $order, 'get_total_shipping' ) ? $order->get_total_shipping() : 0 );
				
				// Get first coupon code only (matches old implementation).
				$discount = '';
				$coupons  = method_exists( $order, 'get_coupon_codes' ) ? $order->get_coupon_codes() : $order->get_used_coupons();
				if ( ! empty( $coupons ) ) {
					foreach ( $coupons as $code ) {
						if ( ! empty( $code ) ) {
							$discount = $code;
							break;
						}
					}
				}

				$items_json = wp_json_encode( $items );

				// Directly echo script for thank you page (matches old implementation exactly).
				echo "<script>gtag('event', 'purchase', {
					transaction_id: '{$order->get_order_number()}',
					value: {$order->get_total()},
					tax: {$order->get_total_tax()},
					shipping: {$shipping},
					currency: '{$order->get_currency()}',
					coupon: '{$discount}',
					items: {$items_json}
				});</script>";
			} else {
				$code = "gtag('event', 'purchase', {
					transaction_id: '{$order->get_order_number()}',
					value: {$order->get_total()},
					currency: '{$order->get_currency()}'
				});";
				$this->core_tracking_handler->add_inline_js_wpa_woo( $code );
			}
		} else {
			$code = 'ga("ec:setAction", "purchase");';
			$this->core_tracking_handler->add_inline_js_wpa_woo( $code );
		}

		// Mark as tracked
		update_post_meta( $order_id, '_analytify_woo_tracked_completed_payment', 'yes' );

		return true;
	}
}
}
