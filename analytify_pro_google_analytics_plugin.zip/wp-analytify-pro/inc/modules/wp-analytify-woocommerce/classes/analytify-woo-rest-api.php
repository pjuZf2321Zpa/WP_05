<?php
/**
 * Handle Analytify REST end points.
 *
 * @package WP_Analytify_Pro
 * @since   2.1.23
 * @version 9.0.0
 */

// phpcs:ignoreFile WordPress.Files.FileName.InvalidClassFileName

if ( ! class_exists( 'Analytify_Woo_Rest_API' ) ) {

	/**
	 * Class Analytify_Woo_Rest_API
	 *
	 * Handles WooCommerce REST API endpoints.
	 *
	 * @since 2.1.23
	 * @version 9.0.0
	 */
	class Analytify_Woo_Rest_API {

		/**
		 * The single instance of the class.
		 *
		 * @var self|null
		 */
		private static $instance;

		/**
		 * Analytify instance.
		 *
		 * @var mixed
		 */
		private $wp_analytify;

		/**
		 * GA mode.
		 *
		 * @var string
		 */
		private $ga_mode;

		/**
		 * Start date.
		 *
		 * @var string
		 */
		private $start_date;

		/**
		 * End date.
		 *
		 * @var string
		 */
		private $end_date;

		/**
		 * Compare start date.
		 *
		 * @var string
		 */
		private $compare_start_date;

		/**
		 * Compare end date.
		 *
		 * @var string
		 */
		private $compare_end_date;

		/**
		 * Date difference.
		 *
		 * @var string
		 */
		private $date_difference;

		/**
		 * Report URL.
		 *
		 * @var string
		 */
		private $report_url;

		/**
		 * Report date range.
		 *
		 * @var string
		 */
		private $report_date_range;

		/**
		 * Returns the single instance of the class.
		 *
		 * @since 2.1.23
		 * @version 9.0.0
		 * @return object Class instance
		 */
		public static function get_instance() {

			if ( null === self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		/**
		 * Class constructor.
		 *
		 * @since 2.1.23
		 * @version 9.0.0
		 */
		private function __construct() {

			$this->wp_analytify = $GLOBALS['WP_ANALYTIFY'];
			$this->ga_mode      = class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) ? WPANALYTIFY_Utils::get_ga_mode() : 'ga3';

			add_action( 'rest_api_init', array( $this, 'wpa_rest_api_init' ) );
		}

		/**
		 * Register REST API endpoint for WooCommerce reports.
		 *
		 * @since 2.1.23
		 * @version 9.0.0
		 * @return void
		 */
		public function wpa_rest_api_init() {

			register_rest_route(
				'wp-analytify/v1',
				'/get_pro_woo_report/(?P<profile_id>\d+)/(?P<request_type>[a-zA-Z0-9-]+)',
				array(
					array(
						'methods'             => WP_REST_Server::READABLE,
						'callback'            => array( $this, 'wpa_handle_request' ),
						'permission_callback' => array( $this, 'wpa_permission_check' ),
					),
				)
			);
		}

		/**
		 * Checks access permission for REST requests.
		 * Verifies the user is logged-in and has a role with dashboard access.
		 *
		 * @since 2.1.23
		 * @version 9.0.0
		 * @return bool True if the user has access, false otherwise.
		 */
		public function wpa_permission_check() {

			$is_access_level = $this->wp_analytify->settings->get_option( 'show_analytics_roles_dashboard', 'wp-analytify-dashboard', array( 'administrator' ) );

			return (bool) $this->wp_analytify->pa_check_roles( $is_access_level );
		}

		/**
		 * Handle the REST request and route to the appropriate report method.
		 *
		 * @since 2.1.23
		 * @version 9.0.0
		 * @param WP_REST_Request $request REST request object.
		 * @return array<string, mixed>|WP_Error Response data or error.
		 */
		public function wpa_handle_request( WP_REST_Request $request ) {

			$is_access_level = $this->wp_analytify->settings->get_option( 'show_analytics_roles_dashboard', 'wp-analytify-dashboard', array( 'Administrator' ) );

			if ( ! $this->wp_analytify->pa_check_roles( $is_access_level ) ) {
				return new WP_Error( 'analytify_forbidden', __( 'You are not allowed to access Analytify Dashboard.', 'wp-analytify-pro' ), array( 'status' => 403 ) );
			}

			$request_type = $request->get_param( 'request_type' );

			$this->start_date         = $request->get_param( 'sd' );
			$this->end_date            = $request->get_param( 'ed' );
			$this->compare_start_date  = $request->get_param( 'csd' );
			$this->compare_end_date    = $request->get_param( 'ced' );
			$this->date_difference     = $request->get_param( 'dd' );
			$this->report_url          = $request->get_param( 'ru' );
			$this->report_date_range   = $request->get_param( 'rdr' ) ? $request->get_param( 'rdr' ) : '';

			switch ( $request_type ) {
				case 'general-stats':
					return $this->general_stats();

				case 'categories-performance':
					return $this->categories_performance();

				case 'country-performance':
					return $this->country_performance();

				case 'coupons':
					return $this->coupons();

				case 'list-performance':
					return $this->list_performance();

				case 'measuring-roi':
					return $this->measuring_roi();

				case 'products-performance':
					return $this->products_performance();
			}

			return new WP_Error( 'analytify_invalid_endpoint', __( 'Invalid endpoint.', 'wp-analytify-pro' ), array( 'status' => 404 ) );
		}

		/**
		 * Get categories performance data.
		 *
		 * @since 2.1.23
		 * @version 9.0.0
		 * @return array<string, mixed>
		 */
		private function categories_performance() {

			if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {
				$stats = $this->wp_analytify->get_reports(
					'show-woo-categories-performance-stats',
					array(
						'itemRevenue',
						// 'ecommercePurchases', commented out due to incompatibility.
						'itemPurchaseQuantity',
						'cartToViewRate',
						// TODO: (missing_ga4) buyToDetailRate.
					),
					array(
						'start' => $this->start_date,
						'end' => $this->end_date,
					),
					array(
						'itemCategory',
						'currencyCode',
					),
					array(
						'type' => 'metric',
						'name' => 'itemPurchaseQuantity',
					),
					array(
						'logic' => 'AND',
						'filters' => array(
							array(
								'type' => 'dimension',
								'name' => 'itemCategory',
								'match_type' => 4,
								'value' => '(not set)',
								'not_expression' => true,
							),
						),
					),
					10
				);

				include defined( 'WC_ANALYTIFY_PLUGIN_DIR' ) ? WC_ANALYTIFY_PLUGIN_DIR . '/views/default/categories-performance.php' : __DIR__ . '/../views/default/categories-performance.php';
				ob_start();
				wpa_woocommerce_categories_performance( $this->wp_analytify, $stats );
				$output = ob_get_clean();
				return array( 'html' => $output );
			}

			return array( 'html' => '' );
		}

		/**
		 * Get country performance data.
		 *
		 * @since 2.1.23
		 * @version 9.0.0
		 * @return array<string, mixed>
		 */
		private function country_performance() {

			if ( 'ga4' === $this->ga_mode ) {
				$stats = $this->wp_analytify->get_reports(
					'show-woo-geographical-stats',
					array(
						'addToCarts',
						'itemViews',
					),
					array(
						'start' => $this->start_date,
						'end' => $this->end_date,
					),
					array(
						'country',
					),
					array(
						'type' => 'metric',
						'name' => 'itemViews',
					),
					array(
						'logic' => 'AND',
						'filters' => array(
							array(
								'type' => 'dimension',
								'name' => 'country',
								'match_type' => 4,
								'value' => '(not set)',
								'not_expression' => true,
							),
						),
					),
					10
				);

				include defined( 'WC_ANALYTIFY_PLUGIN_DIR' ) ? WC_ANALYTIFY_PLUGIN_DIR . '/views/default/country-performance.php' : __DIR__ . '/../views/default/country-performance.php';
				ob_start();
				wpa_country_performance( $this->wp_analytify, $stats, $this->report_date_range );
				$output = ob_get_clean();
				return array( 'body' => $output );
			}

			return array( 'body' => '' );
		}

		/**
		 * Get coupons data.
		 *
		 * @since 2.1.23
		 * @version 9.0.0
		 * @return array<string, mixed>
		 */
		private function coupons() {
			return array();
		}

		/**
		 * Get list performance data.
		 *
		 * @since 2.1.23
		 * @version 9.0.0
		 * @return array<string, mixed>
		 */
		private function list_performance() {
			return array();
		}

		/**
		 * Get measuring ROI data.
		 *
		 * @since 2.1.23
		 * @version 9.0.0
		 * @return array<string, mixed>
		 */
		private function measuring_roi() {
			return array();
		}

		/**
		 * Get products performance data.
		 *
		 * @since 2.1.23
		 * @version 9.0.0
		 * @return array<string, mixed>
		 */
		private function products_performance() {
			return array();
		}

		/**
		 * Get general stats data.
		 *
		 * @since 2.1.23
		 * @version 9.0.0
		 * @return array<string, mixed>
		 */
		private function general_stats() {

			$analytify_enhanced_general_filter = apply_filters( 'analytify_enhanced_general_filter', false );

			if ( 'ga4' === $this->ga_mode ) {

				$general_stats = $this->wp_analytify->get_reports(
					'show-woo-general-stats',
					array(
						'transactions',
						'totalRevenue',
						// 'transactionsPerPurchaser', this was being used for average order value which is wrong
						'sessions', // Fetch sessions for conversion rate calculation
						'averagePurchaseRevenue',
						'ecommercePurchases',
						'addToCarts',
						// 'ga:productRemovesFromCart, TODO: missing_ga4
						'checkouts',
						'itemListClicks',
						'itemViews',
						'firstTimePurchaserRate',
					),
					array(
						'start' => $this->start_date,
						'end' => $this->end_date,
					),
					array(
						'currencyCode',
					),
					array(),
					array(),
					10
				);

				$remove_from_cart = $this->wp_analytify->get_reports(
					'remove-from-cart-stats',
					array(
						'eventCount',
					),
					array(
						'start' => $this->start_date,
						'end' => $this->end_date,
					),
					array(
						'eventName',
					),
					array(),
					array(
						'logic' => 'AND',
						'filters' => array(
							array(
								'type' => 'dimension',
								'name' => 'eventName',
								'match_type' => 1,
								'value' => 'remove_from_cart',
							),
						),
					),
					0
				);

				if ( isset( $remove_from_cart['aggregations']['eventCount'] ) ) {
					$general_stats['remove_from_cart'] = $remove_from_cart['aggregations']['eventCount'];
				}

				if ( ! isset( $general_stats['aggregations'] ) ) {
					$general_stats['aggregations'] = array();
				}

				include defined( 'WC_ANALYTIFY_PLUGIN_DIR' ) ? WC_ANALYTIFY_PLUGIN_DIR . '/views/default/shopping-analysis.php' : __DIR__ . '/../views/default/shopping-analysis.php';
				ob_start();
				pa_ga_include_woocommerce( $this->wp_analytify, $general_stats );
				$output = ob_get_clean();
				return array( 'body' => $output );
			}

			return array( 'body' => '' );
		}

		/**
		 * Get refund statistics from GA4.
		 * Refund events are tracked with customEvent:wpa_label set to the WooCommerce order number
		 * (from WC_Order::get_order_number()) at the time the refund was sent to GA4.
		 *
		 * @since 7.0.5
		 * @version 9.0.0
		 * @return array{refunded_orders: int, total_refunded: float, refund_rate: float}
		 */
		public function analytify_get_refund_stats() {

			$wp_analytify = $GLOBALS['WP_ANALYTIFY'];

			$refund_stats = $wp_analytify->get_reports(
				'analytify-woo-refund-stats',
				array( 'eventCount' ),
				array(
					'start' => $this->start_date,
					'end'   => $this->end_date,
				),
				array( 'eventName', 'customEvent:wpa_label' ),
				array(
					'type'  => 'metric',
					'name'  => 'eventCount',
					'order' => 'desc',
				),
				array(
					'logic'   => 'AND',
					'filters' => array(
						array(
							'type'       => 'dimension',
							'name'       => 'eventName',
							'match_type' => '1',
							'value'      => 'refund',
						),
					),
				),
				1000
			);

			if ( ! isset( $refund_stats['rows'] ) || ! is_array( $refund_stats['rows'] ) || empty( $refund_stats['rows'] ) ) {
				return array(
					'refunded_orders' => 0,
					'total_refunded' => 0.0,
					'refund_rate'    => 0.0,
				);
			}

			$refunded_orders = count( $refund_stats['rows'] );
			$total_refunded  = 0.0;

			$transactions = 0;
			if ( ! empty( $this->start_date ) && ! empty( $this->end_date ) ) {
				$transaction_report = $wp_analytify->get_reports(
					'show-woo-general-stats',
					array( 'transactions' ),
					array(
						'start' => $this->start_date,
						'end'   => $this->end_date,
					),
					array( 'currencyCode' ),
					array(),
					array(),
					10
				);
				$transactions = isset( $transaction_report['aggregations']['transactions'] ) ? (int) $transaction_report['aggregations']['transactions'] : 0;
			}

			$refund_rate = ( $transactions > 0 ) ? ( ( $refunded_orders / $transactions ) * 100 ) : 0.0;

			foreach ( $refund_stats['rows'] as $refund ) {
				$order_identifier = isset( $refund['customEvent:wpa_label'] ) ? $refund['customEvent:wpa_label'] : ( isset( $refund['wpa_label'] ) ? $refund['wpa_label'] : null );
				if ( null === $order_identifier || '' === $order_identifier ) {
					continue;
				}
				$order = wc_get_order( $order_identifier );
				if ( ! $order && is_numeric( $order_identifier ) ) {
					$order = wc_get_order( (int) $order_identifier );
				}
				if ( $order && method_exists( $order, 'get_total_refunded' ) ) {
					$refunded_amount = $order->get_total_refunded();
					if ( is_numeric( $refunded_amount ) ) {
						$total_refunded += (float) $refunded_amount;
					}
				}
			}

			return array(
				'refunded_orders' => $refunded_orders,
				'total_refunded'  => $total_refunded,
				'refund_rate'     => round( $refund_rate, 2 ),
			);
		}

	}

	/**
	 * Init the instance.
	 *
	 * @since 2.1.23
	 * @version 9.0.0
	 */
	Analytify_Woo_Rest_API::get_instance();
}
