<?php
/**
 * WooCommerce Core Tracking Handler Class.
 *
 * @package WP_Analytify_Pro
 * @since 8.0.0
 */

// phpcs:ignoreFile WordPress.Files.FileName.InvalidClassFileName

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * ============================================================================
 * WOOCOMMERCE CORE TRACKING HANDLER
 * ============================================================================
 *
 * PURPOSE: This class provides core utility methods and common functionality
 *          for all WooCommerce e-commerce tracking handlers.
 *
 * RESPONSIBILITIES:
 * - Provide utility methods for product tracking
 * - Handle session management and client identification
 * - Manage order data extraction and formatting
 * - Control tracking permissions and GA configuration
 *
 * CORE FUNCTIONS PROVIDED:
 * - Product list identification and categorization
 * - GA4 item formatting and tracking data preparation
 * - Session ID filtering and management
 * - Order data extraction (ID, total, tax, shipping)
 * - User tracking permissions and GA enablement checks
 * - JavaScript injection for tracking code
 * - Order items processing for analytics
 * - Client ID generation and management
 *
 * ANALYTICS INTEGRATION:
 * - Google Analytics 4 (GA4) data formatting
 * - Google Tag Manager (gtag) support
 * - Universal Analytics (ga) support
 *
 * FUNCTIONS INCLUDED:
 * 1. get_product_list() - Identifies current product list context
 * 2. get_tracked_item_ga4() - Formats product data for GA4 tracking
 * 3. analytify_filter_session_id() - Extracts session ID from cookies
 * 4. get_order_id() - Retrieves current order ID
 * 5. get_order_total() - Gets order total amount
 * 6. get_order_tax() - Gets order tax amount
 * 7. get_order_shipping() - Gets order shipping amount
 * 8. is_track_user() - Checks if user should be tracked
 * 9. is_ga_enable() - Checks if GA tracking is enabled
 * 10. add_inline_js_wpa_woo() - Injects tracking JavaScript (wp_add_inline_script)
 * 11. get_items() - Processes order items for tracking
 * 12. get_woo_cid() - Generates/manages client IDs for WooCommerce
 *
 * DEPENDENCIES:
 * - WordPress core functions
 * - WooCommerce functions
 * - Google Analytics integration
 *
 * CREATED: As part of WP Analytify Pro WooCommerce refactoring
 * ============================================================================
 */
if ( ! class_exists( 'WP_Analytify_WooCommerce_Core_Tracking_Handler' ) ) {
class WP_Analytify_WooCommerce_Core_Tracking_Handler {

	/**
	 * Get product list for current context
	 *
	 * @return string
	 * 
	 * @since 1.0.0
	 * @version 8.0.1
	 * 
	 */
	public function get_product_list() {
		$list_name = '';

		if (is_product_category()) {
			$list_name = 'Category';
		} elseif (is_product_tag()) {
			$list_name = 'Tag';
		} elseif (is_search()) {
			$list_name = 'Search Results';
		} elseif (is_cart()) {
			$list_name = 'Cart';
		} elseif (is_product()) {
			$list_name = 'Product';
		} else {
			$list_name = 'Archive';
		}

		return $list_name;
	}

	/**
	 * Get tracked item data for GA4
	 *
	 * @param int        $product_id Product ID.
	 * @param int|null   $variation_id Variation ID.
	 * @param int        $quantity Quantity.
	 * @param float|null $price Price.
	 * 
	 * @return array<string, mixed>
	 * 
	 * @since 1.0.0
	 * @version 8.0.1
	 * 
	 */
	public function get_tracked_item_ga4( int $product_id, ?int $variation_id, int $quantity, float|string|null $price = null ) {
		$variation = '';
		$product   = null;

		if ( ! empty( $variation_id ) ) {
			$product = function_exists( 'wc_get_product' ) ? wc_get_product( $variation_id ) : null;
			if ( $product && is_object( $product ) && method_exists( $product, 'get_name' ) ) {
				$variation = $product->get_name();
			} elseif ( $product && isset( $product->post->post_title ) ) {
				$variation = $product->post->post_title;
			}

			if ( empty( $product_id ) ) {
				$product_id = $variation_id;
			}
		} else {
			$product = function_exists( 'wc_get_product' ) ? wc_get_product( $product_id ) : null;
		}

		// Handle price conversion and fallback logic
		if ( is_null( $price ) ) {
			// No price provided, get from product or fallback
			if ( $product && is_object( $product ) && method_exists( $product, 'get_price' ) ) {
				$price = number_format( (float) $product->get_price(), 2 );
			} elseif ( ! empty( $product_id ) ) {
				$fallback_price = get_post_meta( $product_id, '_regular_price', true );
				$price = $fallback_price ? number_format( (float) $fallback_price, 2 ) : '0.00';
			} else {
				$price = '0.00';
			}
		} else {
			// Price provided, ensure it's properly formatted as string
			$price = number_format( (float) $price, 2 );
		}

		$categories     = get_the_terms( $product_id, 'product_cat' );
		$category_names = is_array( $categories ) ? wp_list_pluck( $categories, 'name' ) : array();
		$first_category = reset( $category_names );

		return array(
			'item_id'       => $product_id,
			'item_name'     => get_the_title( $product_id ),
			'item_category' => $first_category,
			'item_variant'  => $variation,
			'price'         => $price,
			'quantity'      => (int) $quantity,
		);
	}

	/**
	 * Filter session ID from cookies
	 * Matches old implementation: accepts $_COOKIE array and extracts session ID from _ga_ cookies
	 *
	 * @param array|string $value Cookie array or cookie string value.
	 * @return int|string Session ID (int for old format, string for new format).
	 */
	public function analytify_filter_session_id( $value ) {
		if ( empty( $value ) ) {
			return is_array( $value ) ? 0 : '';
		}

		// If array (old format - $_COOKIE), extract from _ga_ cookies.
		if ( is_array( $value ) ) {
			foreach ( $value as $cookieName => $cookieContent ) {
				if ( strpos( $cookieName, '_ga_' ) === 0 ) {
					// Extract the session ID from the cookie content using a regular expression.
					if ( preg_match( '/s(\d+)/', $cookieContent, $matches ) ) {
						return (int) $matches[1]; // Returns the numeric session ID.
		}
				}
			}
			return 0;
		}

		// If string (new format), extract session ID from cookie format.
		if ( is_string( $value ) ) {
		// Extract session ID from cookie format.
			if ( strpos( $value, '_ga=' ) === 0 ) {
				$value = str_replace( '_ga=', '', $value );
		}
			return $value;
		}

		return '';
	}

	/**
	 * Get order ID
	 *
	 * @return int
	 */
	public function get_order_id() {
		global $order;
		
		// Check if $order is an object with get_id() method.
		if ( is_object( $order ) && method_exists( $order, 'get_id' ) ) {
			return $order->get_id();
		}
		
		// Try to get order from WooCommerce session if available.
		if ( function_exists( 'WC' ) && WC()->session ) {
			$order_id = WC()->session->get( 'order_awaiting_payment' );
			if ( $order_id ) {
				return (int) $order_id;
			}
		}
		
		// Try to get order from URL (thank you page).
		if ( is_wc_endpoint_url( 'order-received' ) ) {
			$order_id = get_query_var( 'order-received', 0 );
			if ( $order_id ) {
				return (int) $order_id;
			}
		}
		
		return 0;
	}

	/**
	 * Get order total
	 *
	 * @return float
	 */
	public function get_order_total() {
		global $order;
		return $order ? $order->get_total() : 0;
	}

	/**
	 * Get order tax
	 *
	 * @return float
	 */
	public function get_order_tax() {
		global $order;
		return $order ? $order->get_total_tax() : 0;
	}

	/**
	 * Get order shipping
	 *
	 * @return float
	 */
	public function get_order_shipping() {
		global $order;
		if ( $order && is_object( $order ) && method_exists( $order, 'get_shipping_total' ) ) {
			return $order->get_shipping_total();
		}
		return 0;
	}

	/**
	 * Check if user should be tracked
	 * Matches old implementation exactly
	 *
	 * @return bool
	 */
	public function is_track_user() {
		if ( ! isset( $GLOBALS['WP_ANALYTIFY'] ) || ! is_object( $GLOBALS['WP_ANALYTIFY'] ) ) {
			return true; // Default to tracking if WP_ANALYTIFY is not available.
		}

		global $current_user;
		$roles = $current_user->roles;
		$is_track = $GLOBALS['WP_ANALYTIFY']->settings->get_option( 'exclude_users_tracking', 'wp-analytify-profile', array() );

		if ( is_user_logged_in() && isset( $roles[0] ) && in_array( $roles[0], $is_track, true ) ) {
			return false;
		}

		return true;
	}

	/**
	 * Check if GA tracking is enabled
	 * Matches old implementation - checks install_ga_code option
	 *
	 * @return bool
	 */
	public function is_ga_enable() {
		if ( ! isset( $GLOBALS['WP_ANALYTIFY'] ) || ! is_object( $GLOBALS['WP_ANALYTIFY'] ) ) {
			return true;
		}

		$is_code = $GLOBALS['WP_ANALYTIFY']->settings->get_option( 'install_ga_code', 'wp-analytify-profile' );

		if ( 'on' !== $is_code ) {
			$code = 'console.warn("[Analytify WooCommerce] `Activate Install Google Analytics tracking code` from Analytify Profile Tab Settings");';
			$this->add_inline_js_wpa_woo( $code );
			return false;
		}

		return true;
	}

	/**
	 * Add inline JavaScript for WooCommerce tracking.
	 *
	 * WooCommerce 10.4.0 deprecates wc_enqueue_js() in favor of wp_add_inline_script().
	 * Uses a dedicated handle (no src) so multiple calls append in order, with jQuery as dependency.
	 *
	 * @param string $code JavaScript code.
	 * @return void
	 */
	public function add_inline_js_wpa_woo( string $code ) {
		if ( empty( $code ) ) {
			return;
		}

		$handle = 'analytify-wc-tracking-inline';

		if ( ! wp_script_is( $handle, 'registered' ) ) {
			wp_register_script(
				$handle,
				false,
				array( 'jquery' ),
				defined( 'ANALYTIFY_PRO_VERSION' ) ? ANALYTIFY_PRO_VERSION : '1.0',
				true
			);
		}

		wp_enqueue_script( $handle );
		wp_add_inline_script( $handle, $code );
	}

	/**
	 * Get order items for tracking
	 *
	 * @param mixed $order Order object.
	 * @return array<mixed>
	 */
	public function get_items( $order ) {
		$params = array();
		$c      = 0;

		// Add the purchased products.
		foreach ( $order->get_items() as $item ) {
			++$c;
			$product = function_exists( 'wc_get_product' ) ? wc_get_product( ! empty( $item['variation_id'] ) ? $item['variation_id'] : $item['product_id'] ) : null;

			$variant            = $this->get_product_variation_attributes( $product );
			$product_identifier = $this->get_product_identifier( $product );
			$category_hierarchy = $this->get_category_hierarchy( $product );

			$params[ "pr{$c}id" ] = $product_identifier; // Product ID.
			$params[ "pr{$c}nm" ] = $item['name']; // Product name.
			$params[ "pr{$c}ca" ] = $category_hierarchy; // Product category.
			$params[ "pr{$c}br" ] = ''; // Product brand.
			$params[ "pr{$c}pr" ] = $order->get_item_total( $item ); // Product price.
			$params[ "pr{$c}qt" ] = $item['qty']; // Product Quantity.
			$params[ "pr{$c}va" ] = $variant; // Product variant.
		}

		return $params;
	}

	/**
	 * Get WooCommerce client ID (GA CID for order/payment).
	 *
	 * @param string $payment_id Payment ID.
	 * @return string
	 */
	public function get_woo_cid( string $payment_id = '' ) {
		$saved_cid = get_post_meta( (int) $payment_id, 'analytify_woo_cid', true );

		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.MissingUnslash -- GA cookie contains alphanumeric tracking ID, unslashing would damage it.
		if ( ! empty( $_COOKIE['_ga'] ) ) {
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.MissingUnslash -- GA cookie contains alphanumeric tracking ID, unslashing would damage it.
			$ga_parts = preg_split( '[\.]', isset( $_COOKIE['_ga'] ) ? sanitize_text_field( $_COOKIE['_ga'] ) : '', 4 );
			if ( is_array( $ga_parts ) && count( $ga_parts ) >= 4 && isset( $ga_parts[0], $ga_parts[1], $ga_parts[2], $ga_parts[3] ) ) {
				list($version, $domain_depth, $cid1, $cid2) = $ga_parts;
				$contents                                   = array(
					'version'      => $version,
					'domain_depth' => $domain_depth,
					'cid'          => $cid1 . '.' . $cid2,
				);
				$cid                                        = $contents['cid'];
				return $cid;
			}
		}

		if ( ! empty( $payment_id ) && ! empty( $saved_cid ) ) {
			return $saved_cid;
		}

		return $this->generate_uuid();
	}

	/**
	 * Get product variation attributes
	 *
	 * @param mixed $product Product object or ID.
	 * @return string
	 */
	private function get_product_variation_attributes( $product ) {
		if ( class_exists( 'WC_Product' ) && ! $product instanceof WC_Product ) {
			$product = function_exists( 'wc_get_product' ) ? wc_get_product( $product ) : null;
		}

		if ( ! $product ) {
			return '';
		}

		$variant = '';

		if ( 'variation' === $product->get_type() ) {
			$variant = implode( ',', array_values( $product->get_variation_attributes() ) );
		} elseif ( 'variable' === $product->get_type() ) {
			if ( $this->is_wc_version_lt_3_0() ) {
				$attributes = $product->get_variation_default_attributes();
			} else {
				$attributes = $product->get_default_attributes();
			}
			$variant = implode( ', ', array_values( $attributes ) );
		}

		return $variant;
	}

	/**
	 * Get product identifier
	 *
	 * @param mixed $product Product object or ID.
	 * @return string
	 */
	private function get_product_identifier( $product ) {
		if ( class_exists( 'WC_Product' ) && ! $product instanceof WC_Product ) {
			$product = function_exists( 'wc_get_product' ) ? wc_get_product( $product ) : null;
		}

		if ( ! $product ) {
			return '';
		}

		if ( $product->get_sku() ) {
			$identifier = $product->get_sku();
		} else {
			$identifier = '#' . $product->get_ID();
		}

		return $identifier;
	}

	/**
	 * Get category hierarchy
	 *
	 * @param mixed $product Product object or ID.
	 * @return string
	 */
	private function get_category_hierarchy( $product ) {
		if ( class_exists( 'WC_Product' ) && ! $product instanceof WC_Product ) {
			$product = function_exists( 'wc_get_product' ) ? wc_get_product( $product ) : null;
		}

		if ( ! $product ) {
			return '';
		}

		$categories = function_exists( 'wc_get_product_terms' ) ? wc_get_product_terms(
			$product->get_ID(),
			'product_cat',
			array(
				'orderby' => 'parent',
				'order'   => 'DESC',
			)
		) : array();

		if ( ! is_array( $categories ) || empty( $categories ) ) {
			return '';
		}

		$child_term = $categories[0];
		return trim( $this->get_category_parents( $child_term->term_id ), '/' );
	}

	/**
	 * Get category parents
	 *
	 * @param int        $term_id Term ID.
	 * @param string     $separator Separator.
	 * @param array<int> $visited Visited terms.
	 * @return string
	 */
	private function get_category_parents( int $term_id, string $separator = '/', array $visited = array() ) {
		$chain  = '';
		$parent = get_term( $term_id, 'product_cat' );

		if ( is_wp_error( $parent ) || ! $parent ) {
			return '';
		}

		$name = $parent->name;

		if ( $parent->parent && ( $parent->parent !== $parent->term_id ) && ! in_array( $parent->parent, $visited, true ) && count( $visited ) < 4 ) {
			$visited[] = $parent->parent;
			$chain    .= $this->get_category_parents( $parent->parent, $separator, $visited );
		}

		$chain .= $name . $separator;
		return $chain;
	}

	/**
	 * Check WooCommerce version
	 *
	 * @return bool
	 */
	private function is_wc_version_lt_3_0() {
		return function_exists( 'WC' ) && version_compare( WC()->version, '3.0', '<' );
	}

	/**
	 * Generate UUID for client identification
	 *
	 * @return string
	 */
	private function generate_uuid() {
		// phpcs:disable WordPress.WP.AlternativeFunctions.rand_mt_rand -- UUID generation requires specific hex ranges.
		return sprintf(
			'%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
			mt_rand( 0, 0xffff ),
			mt_rand( 0, 0xffff ),
			mt_rand( 0, 0xffff ),
			mt_rand( 0, 0x0fff ) | 0x4000,
			mt_rand( 0, 0x3fff ) | 0x8000,
			mt_rand( 0, 0xffff ),
			mt_rand( 0, 0xffff ),
			mt_rand( 0, 0xffff )
		);
		// phpcs:enable WordPress.WP.AlternativeFunctions.rand_mt_rand
	}
}
}
