<?php
/**
 * Utility functions for the pixels tracking module.
 *
 * @package wp-analytify-pro
 * @since 9.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Get WooCommerce currency with fallback to USD when WooCommerce is not active.
 *
 * @since 9.0.0
 * @return string Currency code.
 */
function wpa_pixels_get_currency() {
	return function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : 'USD';
}
