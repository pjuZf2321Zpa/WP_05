<?php
/**
 * Snapchat Pixel Platform implementation.
 *
 * @package wp-analytify-pro
 * @since 9.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Snapchat platform class.
 *
 * @since 9.0.0
 */
class Analytify_Pixel_Snapchat extends Analytify_Pixel_Platform {

	/**
	 * Platform key.
	 *
	 * @var string
	 */
	protected $key = 'snapchat';

	/**
	 * Wrap Snap track JS so a missing/conflicting snaptr does not throw (footer events).
	 *
	 * @since 9.0.0
	 * @param string $inner_js JavaScript body that calls snaptr (no trailing semicolon required).
	 * @return string
	 */
	private function wpa_snaptr_safe_js( $inner_js ) {
		return '(function(){if(typeof snaptr!==\'function\'){return;}' . trim( $inner_js ) . '})();';
	}

	/**
	 * Inject base tracking script into head.
	 *
	 * Only skip loading if the official Snap stub is already present (has .queue).
	 * A plain `if (window.snaptr) return` breaks the pixel when another script defines snaptr first.
	 *
	 * @since 9.0.0
	 */
	public function wpa_inject_base_script() {
		$pixel_id = $this->pixel_id;
		if ( empty( $pixel_id ) ) {
			return;
		}
		?>
		<!-- Analytify Snapchat Pixel Code -->
		<script data-pixel-id="<?php echo esc_attr( $pixel_id ); ?>">
		(function(e,t,n){
		if(e.snaptr&&e.snaptr.queue){return;}
		var a=e.snaptr=function(){
		a.handleRequest?a.handleRequest.apply(a,arguments):a.queue.push(arguments)};
		a.queue=[];var s='script';var r=t.createElement(s);r.async=!0;
		r.src=n;var i=t.getElementsByTagName(s)[0];
		i.parentNode.insertBefore(r,i)})(window,document,
		'https://sc-static.net/scevent.min.js');
		snaptr('init','<?php echo esc_js( $pixel_id ); ?>');
		snaptr('track','PAGE_VIEW');
		</script>
		<noscript>
			<img height="1" width="1" style="display:none;" alt="" src="https://tr.snapchat.com/p?pid=<?php echo rawurlencode( (string) $pixel_id ); ?>&amp;ev=PAGE_VIEW" />
		</noscript>
		<!-- End Analytify Snapchat Pixel Code -->
		<?php
	}

	/**
	 * Format standardized product data for Snapchat.
	 *
	 * @since 9.0.0
	 * @param array $data Standardized product data.
	 * @return array
	 */
	public function wpa_format_item( $data ) {
		return array(
			'item_id'       => (string) $data['id'],
			'item_name'     => sanitize_text_field( $data['name'] ),
			'item_category' => sanitize_text_field( $data['category'] ),
			'price'         => (float) $data['price'],
			'quantity'      => (int) $data['quantity'],
			'value'         => (float) $data['value'],
		);
	}

	/**
	 * Generate view_item script.
	 *
	 * @since 9.0.0
	 * @param array  $product_data Standardized product data.
	 * @param string $currency     Currency code.
	 * @return string|null
	 */
	public function wpa_generate_view_item_script( $product_data, $currency ) {
		$item    = $this->wpa_format_item( $product_data );
		$payload = array_merge(
			$item,
			array(
				'currency'     => $currency,
				'item_ids'     => array( (string) $product_data['id'] ),
				'number_items' => max( 1, (int) $product_data['quantity'] ),
			)
		);
		return $this->wpa_snaptr_safe_js( "snaptr('track', 'VIEW_CONTENT', " . wp_json_encode( $payload ) . ');' );
	}

	/**
	 * Generate view_list script.
	 *
	 * @since 9.0.0
	 * @param array $product_list Array of formatted items.
	 * @return string|null
	 */
	public function wpa_generate_view_list_script( $product_list ) {
		if ( empty( $product_list ) ) {
			return null;
		}

		$item_ids = array();
		foreach ( $product_list as $row ) {
			if ( ! empty( $row['item_id'] ) ) {
				$item_ids[] = (string) $row['item_id'];
			}
		}
		if ( empty( $item_ids ) ) {
			return null;
		}

		return $this->wpa_snaptr_safe_js( "snaptr('track', 'LIST_VIEW', " . wp_json_encode( array( 'item_ids' => $item_ids ) ) . ');' );
	}

	/**
	 * Generate add_to_cart script.
	 * Fires on add-to-cart button click (not on page load) for correct attribution.
	 *
	 * @since 9.0.0
	 * @param array  $product_data Standardized product data.
	 * @param string $currency     Currency code.
	 * @return string|null
	 */
	public function wpa_generate_add_to_cart_script( $product_data, $currency ) {
		$item             = $this->wpa_format_item( $product_data );
		$item['currency'] = $currency;
		$payload_js       = wp_json_encode( $item );
		$currency_js      = esc_js( $currency );
		return '
		(function() {
			var payload = ' . $payload_js . ";
			function wpaSnapParseUnitPriceFromDom(form, btn) {
				var scope = (form && form.closest && form.closest('.product')) || (btn && btn.closest && btn.closest('.product')) || document.querySelector('.wp-block-woocommerce-product-summary, .wc-block-product');
				if (!scope) return null;
				var amt = scope.querySelector('.price ins .woocommerce-Price-amount, .price .woocommerce-Price-amount.amount, .price .amount, p.price .woocommerce-Price-amount');
				if (!amt) return null;
				var text = (amt.textContent || '').replace(/\\s/g, '');
				var cleaned = text.replace(/[^0-9.,-]/g, '');
				if (cleaned.indexOf(',') > -1 && cleaned.indexOf('.') > -1) {
					cleaned = cleaned.replace(/\\./g, '').replace(',', '.');
				} else if (cleaned.indexOf(',') > -1 && cleaned.indexOf('.') === -1) {
					cleaned = cleaned.replace(',', '.');
				}
				var v = parseFloat(cleaned);
				return isNaN(v) ? null : v;
			}
			function wpaResolveAddToCartBtn(t) {
				if (!t || !t.closest) return null;
				return t.closest('.single_add_to_cart_button') || t.closest('a.add_to_cart_button') || t.closest('button.add_to_cart_button');
			}
			function fireAddToCart(e) {
				var btn = wpaResolveAddToCartBtn(e.target);
				if (!btn) return;
				var p = JSON.parse(JSON.stringify(payload));
				var form = btn.form || (btn.closest && btn.closest('form'));
				var qtyEl = form && form.querySelector('input.qty, input[name=\"quantity\"]');
				var qty = qtyEl && qtyEl.value ? parseInt(qtyEl.value, 10) : 1;
				if (isNaN(qty) || qty < 1) qty = 1;
				p.quantity = qty;
				p.number_items = qty;
				p.value = (p.price || 0) * qty;
				if (form && form.classList && form.classList.contains('variations_form')) {
					var vidEl = form.querySelector('input[name=variation_id]');
					if (vidEl && vidEl.value) {
						p.item_id = String(vidEl.value);
						var priceEl = form.querySelector('.woocommerce-variation-price .amount');
						if (priceEl && priceEl.textContent) {
							var pt = priceEl.textContent.replace(/[^0-9.,-]+/g, '').replace(',', '.');
							var pv = parseFloat(pt);
							if (!isNaN(pv)) {
								p.price = pv;
								p.value = pv * qty;
							}
						}
					}
				}
				if ((!p.price || p.price === 0) && (!p.value || p.value === 0)) {
					var domUnit = wpaSnapParseUnitPriceFromDom(form, btn);
					if (domUnit != null) {
						p.price = domUnit;
						p.value = domUnit * qty;
					}
				}
				p.item_ids = p.item_id ? [String(p.item_id)] : [];
				p.currency = '" . $currency_js . "';
				if (typeof snaptr !== 'undefined') { snaptr('track', 'ADD_CART', p); }
			}
			document.addEventListener('click', fireAddToCart, true);
		})();
		";
	}

	/**
	 * Add-to-cart on shop/archive pages (uses data-product_id from the button).
	 *
	 * @since 9.0.0
	 * @param string $currency Currency code.
	 * @return string|null
	 */
	public function wpa_generate_add_to_cart_loop_script( $currency ) {
		$currency_js = esc_js( $currency );
		return "
		(function() {
			function parseMoney(text) {
				if (!text) return 0;
				var cleaned = String(text).replace(/\\s/g, '').replace(/[^0-9.,-]/g, '');
				if (cleaned.indexOf(',') > -1 && cleaned.indexOf('.') > -1) {
					cleaned = cleaned.replace(/\\./g, '').replace(',', '.');
				} else if (cleaned.indexOf(',') > -1 && cleaned.indexOf('.') === -1) {
					cleaned = cleaned.replace(',', '.');
				}
				var v = parseFloat(cleaned);
				return isNaN(v) ? 0 : v;
			}
			document.addEventListener('click', function(e) {
				var t = e.target;
				if (!t || !t.closest) return;
				var btn = t.closest('a.add_to_cart_button') || t.closest('button.add_to_cart_button');
				if (!btn || btn.classList.contains('single_add_to_cart_button')) return;
				var pid = btn.getAttribute('data-product_id') || (btn.dataset && btn.dataset.product_id);
				if (!pid || typeof snaptr === 'undefined') return;
				var wrap = btn.closest('.product, li.wc-block-grid__product, .wc-block-product');
				var pval = 0;
				if (wrap) {
					var amt = wrap.querySelector('.price .amount, .woocommerce-Price-amount, .wc-block-components-product-price');
					pval = parseMoney(amt && amt.textContent);
				}
				snaptr('track', 'ADD_CART', { item_ids: [String(pid)], price: pval, currency: '" . $currency_js . "', number_items: 1 });
			}, true);
		})();
		";
	}

	/**
	 * Generate remove_from_cart script.
	 *
	 * @since 9.0.0
	 * @param string $currency Currency code.
	 * @return string|null
	 */
	public function wpa_generate_remove_from_cart_script( $currency ) {
		$currency_js = esc_js( $currency );
		return "
		(function() {
			function wpaFindCartRow(btn) {
				if (!btn || !btn.closest) return null;
				return btn.closest('tr') || btn.closest('.wc-block-cart-items__row') || btn.closest('div.wc-block-cart-item');
			}
			function getRowText(row, selector) {
				if (!row || !row.querySelector) return '';
				var node = row.querySelector(selector);
				return (node && node.textContent) ? node.textContent.trim() : '';
			}
			function parseMoney(text) {
				if (!text) return 0;
				var cleaned = String(text).replace(/\\s/g, '').replace(/[^0-9.,-]/g, '');
				if (cleaned.indexOf(',') > -1 && cleaned.indexOf('.') > -1) {
					cleaned = cleaned.replace(/\\./g, '').replace(',', '.');
				} else if (cleaned.indexOf(',') > -1 && cleaned.indexOf('.') === -1) {
					cleaned = cleaned.replace(',', '.');
				}
				var v = parseFloat(cleaned);
				return isNaN(v) ? 0 : v;
			}
			document.addEventListener('click', function(e) {
				var t = e.target;
				if (!t || !t.closest) return;
				var removeBtn = t.classList && t.classList.contains('remove') ? t : t.closest('.remove');
				if (!removeBtn) removeBtn = t.closest('.wc-block-cart-item__remove-link');
				if (!removeBtn) return;
				var productId = removeBtn.getAttribute && (removeBtn.getAttribute('data-product_id') || removeBtn.getAttribute('data-product-id'));
				var row = wpaFindCartRow(removeBtn);
				var productName = row ? getRowText(row, '.product-name a') : '';
				if (!productName && row) {
					productName = getRowText(row, '.wc-block-components-product-name, .wc-block-cart-item__product-name, .wc-block-cart-item__wrap a');
				}
				var priceText = '';
				if (row) {
					priceText = getRowText(row, '.product-price .amount') || getRowText(row, '.wc-block-cart-item__total .wc-block-formatted-money-amount');
				}
				var productPrice = parseMoney(priceText);
				if (typeof snaptr !== 'undefined' && productId) {
					snaptr('track', 'REMOVE_CART', { item_id: productId, item_name: productName, price: productPrice, currency: '" . $currency_js . "' });
				}
			}, true);
		})();
		";
	}

	/**
	 * Generate view_cart script.
	 *
	 * @since 9.0.0
	 * @param float  $cart_total Cart total value.
	 * @param string $currency   Currency code.
	 * @return string|null
	 */
	public function wpa_generate_view_cart_script( $cart_total, $currency ) {
		$items = array();
		if ( function_exists( 'WC' ) && WC()->cart && ! WC()->cart->is_empty() ) {
			foreach ( WC()->cart->get_cart() as $line ) {
				$product = isset( $line['data'] ) ? $line['data'] : null;
				if ( ! is_a( $product, 'WC_Product' ) ) {
					continue;
				}
				$variation_id = ! empty( $line['variation_id'] ) ? (int) $line['variation_id'] : 0;
				$track_id     = $variation_id ? $variation_id : $product->get_id();
				$qty          = isset( $line['quantity'] ) ? (int) $line['quantity'] : 1;
				$price        = (float) $product->get_price();
				$cat          = '';
				$base_id      = $product->get_parent_id() ? $product->get_parent_id() : $product->get_id();
				$terms        = get_the_terms( $base_id, 'product_cat' );
				if ( is_array( $terms ) && ! empty( $terms ) ) {
					$cat = sanitize_text_field( $terms[0]->name );
				}
				$items[] = array(
					'item_id'       => (string) $track_id,
					'item_name'     => $product->get_name(),
					'item_category' => $cat,
					'price'         => $price,
					'quantity'      => $qty,
					'value'         => $price * $qty,
				);
			}
		}
		$num_in_cart = 0;
		if ( function_exists( 'WC' ) && WC()->cart && ! WC()->cart->is_empty() ) {
			$num_in_cart = WC()->cart->get_cart_contents_count();
		}
		$payload = array(
			'value'        => (float) $cart_total,
			'currency'     => $currency,
			'number_items' => $num_in_cart,
			'items'        => $items,
		);
		return $this->wpa_snaptr_safe_js( 'snaptr("track", "VIEW_CART", ' . wp_json_encode( $payload ) . ');' );
	}

	/**
	 * Generate begin_checkout script.
	 *
	 * @since 9.0.0
	 * @param array  $contents    Formatted cart items.
	 * @param float  $total_value Total cart value.
	 * @param string $currency    Currency code.
	 * @return string|null
	 */
	public function wpa_generate_begin_checkout_script( $contents, $total_value, $currency ) {
		return $this->wpa_snaptr_safe_js(
			"
		snaptr('track', 'START_CHECKOUT', {
			items: " . wp_json_encode( $contents ) . ',
			value: ' . esc_js( $total_value ) . ",
			currency: '" . esc_js( $currency ) . "'
		});
		"
		);
	}

	/**
	 * Generate add_payment_info script.
	 *
	 * @since 9.0.0
	 * @param array  $contents    Formatted cart items.
	 * @param float  $total_value Total cart value.
	 * @param string $currency    Currency code.
	 * @return string|null
	 */
	public function wpa_generate_add_payment_info_script( $contents, $total_value, $currency ) {
		return $this->wpa_snaptr_safe_js(
			"
		snaptr('track', 'ADD_BILLING', {
			items: " . wp_json_encode( $contents ) . ',
			value: ' . esc_js( $total_value ) . ",
			currency: '" . esc_js( $currency ) . "'
		});
		"
		);
	}

	/**
	 * Generate purchase script.
	 *
	 * @since 9.0.0
	 * @param WC_Order $order       The WooCommerce order.
	 * @param array    $contents    Formatted order items.
	 * @param float    $total_value Total order value.
	 * @param string   $currency    Currency code.
	 * @return string|null
	 */
	public function wpa_generate_purchase_script( $order, $contents, $total_value, $currency ) {
		$num_items = 0;
		foreach ( $order->get_items() as $oi ) {
			$num_items += $oi->get_quantity();
		}
		return $this->wpa_snaptr_safe_js(
			'
		snaptr("track", "PURCHASE", {
			number_items: ' . (int) $num_items . ',
			price: ' . esc_js( $order->get_total() ) . ",
			currency: '" . esc_js( $currency ) . "',
			transaction_id: '" . esc_js( $order->get_id() ) . "',
			items: " . wp_json_encode( $contents ) . '
		});
		'
		);
	}

	/**
	 * Generate coupon script.
	 *
	 * @since 9.0.0
	 * @param string $action      Either 'applied' or 'removed'.
	 * @param string $coupon_code The coupon code.
	 * @return string|null
	 */
	public function wpa_generate_coupon_script( $action, $coupon_code ) {
		$snap_event = ( 'applied' === $action ) ? 'COUPON_APPLIED' : 'COUPON_REMOVED';
		$coupon_js  = esc_js( $coupon_code );
		return $this->wpa_snaptr_safe_js( "snaptr('track', '" . $snap_event . "', { coupon_code: '" . $coupon_js . "' });" );
	}

	/**
	 * Generate search script.
	 *
	 * @since 9.0.0
	 * @param string $search_query The search query.
	 * @param string $currency     Currency code.
	 * @return string|null
	 */
	public function wpa_generate_search_script( $search_query, $currency ) {
		unset( $currency );
		return $this->wpa_snaptr_safe_js( "snaptr('track', 'SEARCH', { search_string: '" . esc_js( $search_query ) . "' });" );
	}
}
