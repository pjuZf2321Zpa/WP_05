<?php
/**
 * Twitter (X) Pixel Platform implementation.
 *
 * @package wp-analytify-pro
 * @since 9.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Twitter (X) platform class.
 *
 * Uses twq('event', 'tw-{pixel_id}-{EventName}', payload) after twq('config', pixel_id).
 * (twq('track', …) is legacy UWT and may not report to current Events Manager.)
 *
 * @since 9.0.0
 */
class Analytify_Pixel_Twitter extends Analytify_Pixel_Platform {

	/**
	 * Platform key.
	 *
	 * @var string
	 */
	protected $key = 'twitter';

	/**
	 * JavaScript event id for X Pixel (Events Manager website tag format).
	 *
	 * @since 9.0.0
	 * @param string $standard_event Standard name, e.g. ViewContent, Purchase.
	 * @return string Safe for embedding inside a JS string literal (ASCII).
	 */
	private function wpa_twitter_js_event_id( $standard_event ) {
		return 'tw-' . esc_js( (string) $this->pixel_id ) . '-' . esc_js( $standard_event );
	}

	/**
	 * Inline script: fire twq('event', event_id, payload).
	 *
	 * @since 9.0.0
	 * @param string $standard_event Standard event name.
	 * @param array  $payload        Event parameters.
	 * @return string
	 */
	private function wpa_twitter_js_tw_event( $standard_event, array $payload ) {
		$eid  = $this->wpa_twitter_js_event_id( $standard_event );
		$json = wp_json_encode( $payload );
		return 'if (typeof twq !== "undefined") { twq("event", "' . $eid . '", ' . $json . '); }';
	}

	/**
	 * Inject base tracking script into head.
	 *
	 * @since 9.0.0
	 */
	public function wpa_inject_base_script() {
		static $wpa_twitter_uwt_injected = false;
		if ( $wpa_twitter_uwt_injected ) {
			return;
		}
		$wpa_twitter_uwt_injected = true;
		?>
		<!-- Analytify Twitter(X) Pixel Code -->
		<script>
		!function(e,t,n,s,u,a){e.twq||(s=e.twq=function(){s.exe?s.exe.apply(s,arguments):s.queue.push(arguments);
		},s.version='1.1',s.queue=[],u=t.createElement(n),u.async=!0,u.src='https://static.ads-twitter.com/uwt.js',
		a=t.getElementsByTagName(n)[0],a.parentNode.insertBefore(u,a))}(window,document,'script');
		twq('config','<?php echo esc_js( $this->pixel_id ); ?>');
		</script>
		<?php
	}

	/**
	 * Minimal UWT / Events Manager payload (value, optional currency, conversion_id).
	 * Product fields like content_type, content_name, content_ids, num_items are omitted — not supported on current X web tag.
	 *
	 * @since 9.0.0
	 * @param float  $value    Event value.
	 * @param string $currency Currency code or empty.
	 * @return array
	 */
	private function wpa_twitter_value_currency_payload( $value, $currency ) {
		$event = array( 'value' => (float) $value );
		if ( is_string( $currency ) && '' !== $currency ) {
			$event['currency'] = $currency;
		}
		return $event;
	}

	/**
	 * Back-compat: older code merged cart line rows into the payload. Current X tag only uses value/currency (+ conversion_id on Purchase).
	 *
	 * @since 9.0.0
	 * @param array $base  Payload keys (passed through).
	 * @param array $items Unused; kept for call signature compatibility.
	 * @return array
	 */
	private function wpa_twitter_event_flatten_items( array $base, array $items = array() ) {
		unset( $items );
		return $base;
	}

	/**
	 * Line total for view_list aggregation only (not sent to X).
	 *
	 * @since 9.0.0
	 * @param array $data Standardized product data.
	 * @return array
	 */
	public function wpa_format_item( $data ) {
		$line_value = isset( $data['value'] )
			? (float) $data['value']
			: (float) $data['price'] * max( 1, (int) $data['quantity'] );
		return array(
			'_wpa_line_value' => $line_value,
		);
	}

	/**
	 * Generate view_item script.
	 *
	 * @since 9.0.0
	 * @param array  $product_data Standardized product data.
	 * @param string $currency     Currency code.
	 * @return string|null
	 */
	public function wpa_generate_view_item_script( $product_data, $currency ) {
		$value = isset( $product_data['value'] ) ? (float) $product_data['value'] : (float) $product_data['price'] * max( 1, (int) $product_data['quantity'] );
		$event = $this->wpa_twitter_value_currency_payload( $value, $currency );
		return $this->wpa_twitter_js_tw_event( 'ViewContent', $event );
	}

	/**
	 * Generate view_list script.
	 *
	 * @since 9.0.0
	 * @param array $product_list Array of formatted items.
	 * @return string|null
	 */
	public function wpa_generate_view_list_script( $product_list ) {
		if ( empty( $product_list ) ) {
			return null;
		}

		$sum      = 0.0;
		$currency = function_exists( 'wpa_pixels_get_currency' ) ? wpa_pixels_get_currency() : '';
		foreach ( $product_list as $row ) {
			if ( isset( $row['_wpa_line_value'] ) ) {
				$sum += (float) $row['_wpa_line_value'];
			} elseif ( isset( $row['content_price'], $row['num_items'] ) ) {
				$sum += (float) $row['content_price'] * (int) $row['num_items'];
			}
		}
		$decimals = function_exists( 'wc_get_price_decimals' ) ? wc_get_price_decimals() : 2;
		$event    = $this->wpa_twitter_value_currency_payload( round( $sum, $decimals ), $currency );

		return $this->wpa_twitter_js_tw_event( 'ViewContent', $event );
	}

	/**
	 * Generate add_to_cart script.
	 *
	 * @since 9.0.0
	 * @param array  $product_data Standardized product data.
	 * @param string $currency     Currency code.
	 * @return string|null
	 */
	public function wpa_generate_add_to_cart_script( $product_data, $currency ) {
		$payload_js = wp_json_encode(
			$this->wpa_twitter_value_currency_payload( (float) $product_data['value'], $currency )
		);
		$tw_add     = $this->wpa_twitter_js_event_id( 'AddToCart' );
		return '
		(function() {
			var base = ' . $payload_js . ";
			function wpaTwParseUnitPriceFromDom(form, btn) {
				var scope = (form && form.closest && form.closest('.product')) || (btn && btn.closest && btn.closest('.product')) || document.querySelector('.wp-block-woocommerce-product-summary, .wc-block-product');
				if (!scope) return null;
				var amt = scope.querySelector('.price ins .woocommerce-Price-amount, .price .woocommerce-Price-amount.amount, .price .amount, p.price .woocommerce-Price-amount');
				if (!amt) return null;
				var text = (amt.textContent || '').replace(/\\s/g, '');
				var cleaned = text.replace(/[^0-9.,-]/g, '');
				if (cleaned.indexOf(',') > -1 && cleaned.indexOf('.') > -1) {
					cleaned = cleaned.replace(/\\./g, '').replace(',', '.');
				} else if (cleaned.indexOf(',') > -1 && cleaned.indexOf('.') === -1) {
					cleaned = cleaned.replace(',', '.');
				}
				var v = parseFloat(cleaned);
				return isNaN(v) ? null : v;
			}
			function wpaResolveAddToCartBtn(t) {
				if (!t || !t.closest) return null;
				return t.closest('.single_add_to_cart_button') || t.closest('a.add_to_cart_button') || t.closest('button.add_to_cart_button');
			}
			function fireAddToCart(e) {
				var btn = wpaResolveAddToCartBtn(e.target);
				if (!btn) return;
				var p = JSON.parse(JSON.stringify(base));
				var form = btn.form || (btn.closest && btn.closest('form'));
				var qtyEl = form && form.querySelector('input.qty, input[name=\"quantity\"]');
				var qty = qtyEl && qtyEl.value ? parseInt(qtyEl.value, 10) : 1;
				if (isNaN(qty) || qty < 1) qty = 1;
				if (form && form.classList && form.classList.contains('variations_form')) {
					var vidEl = form.querySelector('input[name=variation_id]');
					if (vidEl && vidEl.value) {
						var priceEl = form.querySelector('.woocommerce-variation-price .amount');
						if (priceEl && priceEl.textContent) {
							var pt = priceEl.textContent.replace(/[^0-9.,-]+/g, '').replace(',', '.');
							var pv = parseFloat(pt);
							if (!isNaN(pv)) {
								p.value = pv * qty;
							}
						}
					}
				}
				if (!p.value || p.value === 0) {
					var domUnit = wpaTwParseUnitPriceFromDom(form, btn);
					if (domUnit != null) {
						p.value = domUnit * qty;
					}
				}
				if (typeof twq !== 'undefined') { twq('event', '" . $tw_add . "', p); }
			}
			document.addEventListener('click', fireAddToCart, true);
		})();
		";
	}

	/**
	 * Add-to-cart on shop/archive pages (uses data-product_id from the button).
	 *
	 * @since 9.0.0
	 * @param string $currency Currency code.
	 * @return string|null
	 */
	public function wpa_generate_add_to_cart_loop_script( $currency ) {
		$currency_js = esc_js( $currency );
		$tw_add      = $this->wpa_twitter_js_event_id( 'AddToCart' );
		return "
		(function() {
			function parseMoney(text) {
				if (!text) return 0;
				var cleaned = String(text).replace(/\\s/g, '').replace(/[^0-9.,-]/g, '');
				if (cleaned.indexOf(',') > -1 && cleaned.indexOf('.') > -1) {
					cleaned = cleaned.replace(/\\./g, '').replace(',', '.');
				} else if (cleaned.indexOf(',') > -1 && cleaned.indexOf('.') === -1) {
					cleaned = cleaned.replace(',', '.');
				}
				var v = parseFloat(cleaned);
				return isNaN(v) ? 0 : v;
			}
			document.addEventListener('click', function(e) {
				var t = e.target;
				if (!t || !t.closest) return;
				var btn = t.closest('a.add_to_cart_button') || t.closest('button.add_to_cart_button');
				if (!btn || btn.classList.contains('single_add_to_cart_button')) return;
				var pid = btn.getAttribute('data-product_id') || (btn.dataset && btn.dataset.product_id);
				if (!pid || typeof twq === 'undefined') return;
				var wrap = btn.closest('.product, li.wc-block-grid__product, .wc-block-product');
				var pval = 0;
				if (wrap) {
					var amt = wrap.querySelector('.price .amount, .woocommerce-Price-amount, .wc-block-components-product-price');
					pval = parseMoney(amt && amt.textContent);
				}
				var pl = { value: pval, currency: '" . $currency_js . "' };
				twq('event', '" . $tw_add . "', pl);
			}, true);
		})();
		";
	}

	/**
	 * Sum cart line totals (WooCommerce).
	 *
	 * @since 9.0.0
	 * @return float
	 */
	private function wpa_twitter_cart_line_total() {
		$total = 0.0;
		if ( ! function_exists( 'WC' ) || ! WC()->cart || WC()->cart->is_empty() ) {
			return $total;
		}
		foreach ( WC()->cart->get_cart() as $line ) {
			$product = isset( $line['data'] ) ? $line['data'] : null;
			if ( ! is_a( $product, 'WC_Product' ) ) {
				continue;
			}
			$qty    = isset( $line['quantity'] ) ? (int) $line['quantity'] : 1;
			$price  = (float) $product->get_price();
			$total += $price * $qty;
		}
		return $total;
	}

	/**
	 * Generate remove_from_cart script.
	 *
	 * @since 9.0.0
	 * @param string $currency Currency code.
	 * @return string|null
	 */
	public function wpa_generate_remove_from_cart_script( $currency ) {
		$currency_js = esc_js( $currency );
		$tw_rm       = $this->wpa_twitter_js_event_id( 'RemoveFromCart' );
		return "
		(function() {
			function wpaFindCartRow(btn) {
				if (!btn || !btn.closest) return null;
				return btn.closest('tr') || btn.closest('.wc-block-cart-items__row') || btn.closest('div.wc-block-cart-item');
			}
			function getRowText(row, selector) {
				if (!row || !row.querySelector) return '';
				var node = row.querySelector(selector);
				return (node && node.textContent) ? node.textContent.trim() : '';
			}
			function parseMoney(text) {
				if (!text) return 0;
				var cleaned = String(text).replace(/\\s/g, '').replace(/[^0-9.,-]/g, '');
				if (cleaned.indexOf(',') > -1 && cleaned.indexOf('.') > -1) {
					cleaned = cleaned.replace(/\\./g, '').replace(',', '.');
				} else if (cleaned.indexOf(',') > -1 && cleaned.indexOf('.') === -1) {
					cleaned = cleaned.replace(',', '.');
				}
				var v = parseFloat(cleaned);
				return isNaN(v) ? 0 : v;
			}
			document.addEventListener('click', function(e) {
				var t = e.target;
				if (!t || !t.closest) return;
				var removeBtn = t.classList && t.classList.contains('remove') ? t : t.closest('.remove');
				if (!removeBtn) removeBtn = t.closest('.wc-block-cart-item__remove-link');
				if (!removeBtn) return;
				var row = wpaFindCartRow(removeBtn);
				var priceText = '';
				if (row) {
					priceText = getRowText(row, '.product-price .amount') || getRowText(row, '.wc-block-cart-item__total .wc-block-formatted-money-amount');
				}
				var productPrice = parseMoney(priceText);
				if (typeof twq === 'undefined') return;
				twq('event', '" . $tw_rm . "', { value: productPrice, currency: '" . $currency_js . "' });
			}, true);
		})();
		";
	}

	/**
	 * Generate view_cart script.
	 *
	 * @since 9.0.0
	 * @param float  $cart_total Cart total value.
	 * @param string $currency   Currency code.
	 * @return string|null
	 */
	public function wpa_generate_view_cart_script( $cart_total, $currency ) {
		$computed = $this->wpa_twitter_cart_line_total();
		$value    = $computed > 0 ? $computed : (float) $cart_total;
		$event    = $this->wpa_twitter_value_currency_payload( $value, $currency );
		return $this->wpa_twitter_js_tw_event( 'ViewContent', $event );
	}

	/**
	 * Generate begin_checkout script.
	 *
	 * @since 9.0.0
	 * @param array  $contents    Formatted cart items.
	 * @param float  $total_value Total cart value.
	 * @param string $currency    Currency code.
	 * @return string|null
	 */
	public function wpa_generate_begin_checkout_script( $contents, $total_value, $currency ) {
		unset( $contents );
		$event = $this->wpa_twitter_value_currency_payload( $total_value, $currency );
		return $this->wpa_twitter_js_tw_event( 'InitiateCheckout', $event );
	}

	/**
	 * Generate add_payment_info script.
	 *
	 * @since 9.0.0
	 * @param array  $contents    Formatted cart items.
	 * @param float  $total_value Total cart value.
	 * @param string $currency    Currency code.
	 * @return string|null
	 */
	public function wpa_generate_add_payment_info_script( $contents, $total_value, $currency ) {
		unset( $contents );
		$event = $this->wpa_twitter_value_currency_payload( $total_value, $currency );
		return $this->wpa_twitter_js_tw_event( 'AddPaymentInfo', $event );
	}

	/**
	 * Generate purchase script.
	 *
	 * @since 9.0.0
	 * @param WC_Order $order       The WooCommerce order.
	 * @param array    $contents    Formatted order items.
	 * @param float    $total_value Total order value.
	 * @param string   $currency    Currency code.
	 * @return string|null
	 */
	public function wpa_generate_purchase_script( $order, $contents, $total_value, $currency ) {
		unset( $contents, $total_value );
		$event                  = $this->wpa_twitter_value_currency_payload( (float) $order->get_total(), $currency );
		$event['conversion_id'] = (string) $order->get_id();
		return $this->wpa_twitter_js_tw_event( 'Purchase', $event );
	}

	/**
	 * Generate coupon script.
	 *
	 * @since 9.0.0
	 * @param string $action      Either 'applied' or 'removed'.
	 * @param string $coupon_code The coupon code.
	 * @return string|null
	 */
	public function wpa_generate_coupon_script( $action, $coupon_code ) {
		unset( $action, $coupon_code );
		$currency = function_exists( 'wpa_pixels_get_currency' ) ? wpa_pixels_get_currency() : '';
		$event    = $this->wpa_twitter_value_currency_payload( 0, $currency );
		return $this->wpa_twitter_js_tw_event( 'ViewContent', $event );
	}

	/**
	 * Generate search script.
	 *
	 * @since 9.0.0
	 * @param string $search_query The search query.
	 * @param string $currency     Currency code.
	 * @return string|null
	 */
	public function wpa_generate_search_script( $search_query, $currency ) {
		unset( $currency );
		$event = array( 'search_string' => $search_query );
		return $this->wpa_twitter_js_tw_event( 'Search', $event );
	}
}
