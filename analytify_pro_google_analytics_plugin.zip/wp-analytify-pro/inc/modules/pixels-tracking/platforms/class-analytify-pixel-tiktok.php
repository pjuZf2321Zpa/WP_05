<?php
/**
 * TikTok Pixel Platform implementation.
 *
 * @package wp-analytify-pro
 * @since 9.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * TikTok platform class.
 *
 * @since 9.0.0
 */
class Analytify_Pixel_TikTok extends Analytify_Pixel_Platform {

	/**
	 * Platform key.
	 *
	 * @var string
	 */
	protected $key = 'tiktok';

	/**
	 * Run ttq.track after the pixel SDK is ready (footer inline often executed before events.js processes the queue).
	 *
	 * @since 9.0.0
	 * @param string $track_call JavaScript including ttq.track(...) and semicolons.
	 * @return string
	 */
	private function wpa_tiktok_track_when_ready( $track_call ) {
		$inner = trim( $track_call );
		return '(function(){if(typeof ttq==="undefined"){return;}function run(){' . $inner . '}if(typeof ttq.ready==="function"){ttq.ready(run);}else{run();}})();';
	}

	/**
	 * Flat list of content_id strings for TikTok content_ids parameter.
	 *
	 * @since 9.0.0
	 * @param array $contents Array of content objects with content_id keys.
	 * @return array
	 */
	private function wpa_tiktok_content_ids_from_contents( $contents ) {
		$ids = array();
		foreach ( (array) $contents as $row ) {
			if ( ! empty( $row['content_id'] ) ) {
				$ids[] = (string) $row['content_id'];
			}
		}
		return $ids;
	}

	/**
	 * Inject base tracking script into head.
	 *
	 * The auto_config option set to false reduces automatic button-click detection noise vs explicit ttq.track calls.
	 *
	 * @since 9.0.0
	 */
	public function wpa_inject_base_script() {
		?>
		<!-- Analytify TikTok Pixel -->
		<script>
		!function (w, d, t) {
			w.TiktokAnalyticsObject=t;var ttq=w[t]=w[t]||[];ttq.methods=["page","track","identify","instances","debug","on","off","once","ready","alias","group","enableCookie","disableCookie"],ttq.setAndDefer=function(t,e){t[e]=function(){t.push([e].concat(Array.prototype.slice.call(arguments,0)))}};for(var i=0;i<ttq.methods.length;i++)ttq.setAndDefer(ttq,ttq.methods[i]);ttq.instance=function(t){for(var e=ttq._i[t]||[],n=0;n<ttq.methods.length;n++)ttq.setAndDefer(e,ttq.methods[n]);return e},ttq.load=function(e,n){var i="https://analytics.tiktok.com/i18n/pixel/events.js";ttq._i=ttq._i||{},ttq._i[e]=[],ttq._i[e]._u=i,ttq._t=ttq._t||{},ttq._t[e]=+new Date,ttq._o=ttq._o||{},ttq._o[e]=n||{};var o=d.createElement("script");o.type="text/javascript",o.async=!0,o.src=i+'?sdkid='+e+'&lib='+t;var a=d.getElementsByTagName("script")[0];a.parentNode.insertBefore(o,a)};
			ttq.load('<?php echo esc_js( $this->pixel_id ); ?>',{auto_config:false});
			ttq.page();
		}(window, document, 'ttq');
		</script>
		<noscript>
			<img height="1" width="1" style="display:none;" src="https://analytics.tiktok.com/i18n/pixel/events.js?sdkid=<?php echo esc_attr( $this->pixel_id ); ?>&lib=ttq" />
		</noscript>
		<?php
	}

	/**
	 * Format standardized product data for TikTok.
	 *
	 * @since 9.0.0
	 * @param array $data Standardized product data.
	 * @return array
	 */
	public function wpa_format_item( $data ) {
		return array(
			'content_id'       => (string) $data['id'],
			'content_name'     => sanitize_text_field( $data['name'] ),
			'content_category' => sanitize_text_field( $data['category'] ),
			'price'            => (float) $data['price'],
			'quantity'         => (int) $data['quantity'],
			'value'            => (float) $data['value'],
			'description'      => sanitize_text_field( $data['description'] ),
			'content_type'     => 'product',
			'currency'         => wpa_pixels_get_currency(),
		);
	}

	/**
	 * Generate view_item script.
	 *
	 * @since 9.0.0
	 * @param array  $product_data Standardized product data.
	 * @param string $currency     Currency code.
	 * @return string|null
	 */
	public function wpa_generate_view_item_script( $product_data, $currency ) {
		$line_value  = isset( $product_data['value'] ) ? (float) $product_data['value'] : (float) $product_data['price'] * max( 1, (int) $product_data['quantity'] );
		$cid         = (string) $product_data['id'];
		$content_one = array(
			'content_id'       => $cid,
			'content_type'     => 'product',
			'content_name'     => sanitize_text_field( $product_data['name'] ),
			'content_category' => isset( $product_data['category'] ) ? sanitize_text_field( $product_data['category'] ) : '',
			'price'            => (float) $product_data['price'],
			'quantity'         => (int) $product_data['quantity'],
		);
		$payload     = array(
			'content_type' => 'product',
			'content_ids'  => array( $cid ),
			'contents'     => array( $content_one ),
			'value'        => $line_value,
			'currency'     => $currency,
		);
		if ( ! empty( $product_data['description'] ) ) {
			$payload['description'] = sanitize_text_field( $product_data['description'] );
		}
		return $this->wpa_tiktok_track_when_ready( 'ttq.track("ViewContent", ' . wp_json_encode( $payload ) . ');' );
	}

	/**
	 * Generate view_list script.
	 *
	 * @since 9.0.0
	 * @param array $product_list Array of formatted items.
	 * @return string|null
	 */
	public function wpa_generate_view_list_script( $product_list ) {
		if ( empty( $product_list ) ) {
			return null;
		}

		$sum      = 0.0;
		$currency = function_exists( 'wpa_pixels_get_currency' ) ? wpa_pixels_get_currency() : '';
		foreach ( $product_list as $row ) {
			if ( isset( $row['price'], $row['quantity'] ) ) {
				$sum += (float) $row['price'] * (int) $row['quantity'];
			}
		}
		$decimals = function_exists( 'wc_get_price_decimals' ) ? wc_get_price_decimals() : 2;
		$payload  = array(
			'content_type' => 'product_group',
			'content_ids'  => $this->wpa_tiktok_content_ids_from_contents( $product_list ),
			'contents'     => $product_list,
			'value'        => round( $sum, $decimals ),
			'currency'     => $currency,
		);

		return $this->wpa_tiktok_track_when_ready( 'ttq.track("ViewContent", ' . wp_json_encode( $payload ) . ');' );
	}

	/**
	 * Generate add_to_cart script.
	 * Fires on add-to-cart button click (not on page load) for correct attribution.
	 *
	 * @since 9.0.0
	 * @param array  $product_data Standardized product data.
	 * @param string $currency     Currency code.
	 * @return string|null
	 */
	public function wpa_generate_add_to_cart_script( $product_data, $currency ) {
		$item             = $this->wpa_format_item( $product_data );
		$item['currency'] = $currency;
		$payload_js       = wp_json_encode( $item );
		$currency_js      = esc_js( $currency );
		return '
		(function() {
			var basePayload = ' . $payload_js . ";
			function wpaTikTokParseUnitPriceFromDom(form, btn) {
				var scope = (form && form.closest && form.closest('.product')) || (btn && btn.closest && btn.closest('.product')) || document.querySelector('.wp-block-woocommerce-product-summary, .wc-block-product');
				if (!scope) return null;
				var amt = scope.querySelector('.price ins .woocommerce-Price-amount, .price .woocommerce-Price-amount.amount, .price .amount, p.price .woocommerce-Price-amount');
				if (!amt) return null;
				var text = (amt.textContent || '').replace(/\\s/g, '');
				var cleaned = text.replace(/[^0-9.,-]/g, '');
				if (cleaned.indexOf(',') > -1 && cleaned.indexOf('.') > -1) {
					cleaned = cleaned.replace(/\\./g, '').replace(',', '.');
				} else if (cleaned.indexOf(',') > -1 && cleaned.indexOf('.') === -1) {
					cleaned = cleaned.replace(',', '.');
				}
				var v = parseFloat(cleaned);
				return isNaN(v) ? null : v;
			}
			function wpaResolveAddToCartBtn(t) {
				if (!t || !t.closest) return null;
				return t.closest('.single_add_to_cart_button') || t.closest('a.add_to_cart_button') || t.closest('button.add_to_cart_button');
			}
			function fireAddToCart(e) {
				var btn = wpaResolveAddToCartBtn(e.target);
				if (!btn) return;
				var p = Object.assign({}, basePayload);
				var form = btn.form || (btn.closest && btn.closest('form'));
				var qtyEl = form && form.querySelector('input.qty, input[name=\"quantity\"]');
				var qty = qtyEl && qtyEl.value ? parseInt(qtyEl.value, 10) : 1;
				if (isNaN(qty) || qty < 1) qty = 1;
				p.quantity = qty;
				if (form && form.classList && form.classList.contains('variations_form')) {
					var vidEl = form.querySelector('input[name=variation_id]');
					if (vidEl && vidEl.value) {
						p.content_id = String(vidEl.value);
						var priceEl = form.querySelector('.woocommerce-variation-price .amount');
						if (priceEl && priceEl.textContent) {
							var pt = priceEl.textContent.replace(/[^0-9.,-]+/g, '').replace(',', '.');
							var pv = parseFloat(pt);
							if (!isNaN(pv)) { p.price = pv; p.value = pv * qty; }
						}
					}
				}
				if ((!p.value || p.value === 0) && p.price) {
					p.value = p.price * qty;
				}
				if (!p.value || p.value === 0) {
					var domUnit = wpaTikTokParseUnitPriceFromDom(form, btn);
					if (domUnit != null) {
						p.price = domUnit;
						p.value = domUnit * qty;
					}
				}
				p.currency = '" . $currency_js . "';
				p.content_type = 'product';
				var cid = p.content_id ? String(p.content_id) : '';
				if (cid) {
					p.content_ids = [cid];
					p.contents = [{ content_id: cid, content_type: 'product', content_name: p.content_name || '', content_category: p.content_category || '', price: p.price || 0, quantity: p.quantity || 1 }];
				}
				if (typeof ttq === 'undefined') return;
				function sendAdd(){ ttq.track('AddToCart', p); }
				if (typeof ttq.ready === 'function') { ttq.ready(sendAdd); } else { sendAdd(); }
			}
			document.addEventListener('click', fireAddToCart, true);
		})();
		";
	}

	/**
	 * Add-to-cart on shop/archive pages (uses data-product_id from the button).
	 *
	 * @since 9.0.0
	 * @param string $currency Currency code.
	 * @return string|null
	 */
	public function wpa_generate_add_to_cart_loop_script( $currency ) {
		$currency_js = esc_js( $currency );
		return "
		(function() {
			function parseMoney(text) {
				if (!text) return 0;
				var cleaned = String(text).replace(/\\s/g, '').replace(/[^0-9.,-]/g, '');
				if (cleaned.indexOf(',') > -1 && cleaned.indexOf('.') > -1) {
					cleaned = cleaned.replace(/\\./g, '').replace(',', '.');
				} else if (cleaned.indexOf(',') > -1 && cleaned.indexOf('.') === -1) {
					cleaned = cleaned.replace(',', '.');
				}
				var v = parseFloat(cleaned);
				return isNaN(v) ? 0 : v;
			}
			document.addEventListener('click', function(e) {
				var t = e.target;
				if (!t || !t.closest) return;
				var btn = t.closest('a.add_to_cart_button') || t.closest('button.add_to_cart_button');
				if (!btn || btn.classList.contains('single_add_to_cart_button')) return;
				var pid = btn.getAttribute('data-product_id') || (btn.dataset && btn.dataset.product_id);
				if (!pid || typeof ttq === 'undefined') return;
				var wrap = btn.closest('.product, li.wc-block-grid__product, .wc-block-product');
				var pval = 0;
				if (wrap) {
					var amt = wrap.querySelector('.price .amount, .woocommerce-Price-amount, .wc-block-components-product-price');
					pval = parseMoney(amt && amt.textContent);
				}
				var pl = { content_type: 'product', content_ids: [String(pid)], contents: [{ content_id: String(pid), content_type: 'product', quantity: 1, price: pval }], value: pval, currency: '" . $currency_js . "' };
				function sendLoop(){ ttq.track('AddToCart', pl); }
				if (typeof ttq.ready === 'function') { ttq.ready(sendLoop); } else { sendLoop(); }
			}, true);
		})();
		";
	}

	/**
	 * Generate remove_from_cart script.
	 *
	 * @since 9.0.0
	 * @param string $currency Currency code.
	 * @return string|null
	 */
	public function wpa_generate_remove_from_cart_script( $currency ) {
		$currency_js = esc_js( $currency );
		return "
		(function() {
			function wpaFindCartRow(btn) {
				if (!btn || !btn.closest) return null;
				return btn.closest('tr') || btn.closest('.wc-block-cart-items__row') || btn.closest('div.wc-block-cart-item');
			}
			function getRowText(row, selector) {
				if (!row || !row.querySelector) return '';
				var node = row.querySelector(selector);
				return (node && node.textContent) ? node.textContent.trim() : '';
			}
			function parseMoney(text) {
				if (!text) return 0;
				var cleaned = String(text).replace(/\\s/g, '').replace(/[^0-9.,-]/g, '');
				if (cleaned.indexOf(',') > -1 && cleaned.indexOf('.') > -1) {
					cleaned = cleaned.replace(/\\./g, '').replace(',', '.');
				} else if (cleaned.indexOf(',') > -1 && cleaned.indexOf('.') === -1) {
					cleaned = cleaned.replace(',', '.');
				}
				var v = parseFloat(cleaned);
				return isNaN(v) ? 0 : v;
			}
			document.addEventListener('click', function(e) {
				var t = e.target;
				if (!t || !t.closest) return;
				var removeBtn = t.classList && t.classList.contains('remove') ? t : t.closest('.remove');
				if (!removeBtn) removeBtn = t.closest('.wc-block-cart-item__remove-link');
				if (!removeBtn) return;
				var productId = removeBtn.getAttribute && (removeBtn.getAttribute('data-product_id') || removeBtn.getAttribute('data-product-id'));
				var row = wpaFindCartRow(removeBtn);
				var productName = row ? getRowText(row, '.product-name a') : '';
				if (!productName && row) {
					productName = getRowText(row, '.wc-block-components-product-name, .wc-block-cart-item__product-name, .wc-block-cart-item__wrap a');
				}
				var priceText = '';
				if (row) {
					priceText = getRowText(row, '.product-price .amount') || getRowText(row, '.wc-block-cart-item__total .wc-block-formatted-money-amount');
				}
				var productPrice = parseMoney(priceText);
				if (typeof ttq !== 'undefined' && productId) {
					var pr = { content_type: 'product', content_ids: [String(productId)], contents: [{ content_id: String(productId), content_name: productName, content_type: 'product', quantity: 1, price: productPrice }], value: productPrice, currency: '" . $currency_js . "' };
					function sendRm(){ ttq.track('RemoveFromCart', pr); }
					if (typeof ttq.ready === 'function') { ttq.ready(sendRm); } else { sendRm(); }
				}
			}, true);
		})();
		";
	}

	/**
	 * Generate view_cart script.
	 *
	 * @since 9.0.0
	 * @param float  $cart_total Cart total value.
	 * @param string $currency   Currency code.
	 * @return string|null
	 */
	public function wpa_generate_view_cart_script( $cart_total, $currency ) {
		$contents = array();
		if ( function_exists( 'WC' ) && WC()->cart && ! WC()->cart->is_empty() ) {
			foreach ( WC()->cart->get_cart() as $line ) {
				$product = isset( $line['data'] ) ? $line['data'] : null;
				if ( ! is_a( $product, 'WC_Product' ) ) {
					continue;
				}
				$variation_id = ! empty( $line['variation_id'] ) ? (int) $line['variation_id'] : 0;
				$track_id     = $variation_id ? $variation_id : $product->get_id();
				$qty          = isset( $line['quantity'] ) ? (int) $line['quantity'] : 1;
				$price        = (float) $product->get_price();
				$base_id      = $product->get_parent_id() ? $product->get_parent_id() : $product->get_id();
				$cat          = '';
				$terms        = get_the_terms( $base_id, 'product_cat' );
				if ( is_array( $terms ) && ! empty( $terms ) ) {
					$cat = sanitize_text_field( $terms[0]->name );
				}
				$contents[] = array(
					'content_id'       => (string) $track_id,
					'content_name'     => $product->get_name(),
					'content_category' => $cat,
					'price'            => $price,
					'quantity'         => $qty,
					'value'            => $price * $qty,
					'content_type'     => 'product',
					'currency'         => $currency,
				);
			}
		}
		$event = array(
			'content_type' => 'product_group',
			'content_ids'  => $this->wpa_tiktok_content_ids_from_contents( $contents ),
			'value'        => (float) $cart_total,
			'currency'     => $currency,
			'contents'     => $contents,
		);
		return $this->wpa_tiktok_track_when_ready( 'ttq.track("ViewContent", ' . wp_json_encode( $event ) . ');' );
	}

	/**
	 * Generate begin_checkout script.
	 *
	 * @since 9.0.0
	 * @param array  $contents    Formatted cart items.
	 * @param float  $total_value Total cart value.
	 * @param string $currency    Currency code.
	 * @return string|null
	 */
	public function wpa_generate_begin_checkout_script( $contents, $total_value, $currency ) {
		$payload = array(
			'content_type' => 'product_group',
			'content_ids'  => $this->wpa_tiktok_content_ids_from_contents( $contents ),
			'contents'     => $contents,
			'value'        => (float) $total_value,
			'currency'     => $currency,
		);
		return $this->wpa_tiktok_track_when_ready( 'ttq.track("InitiateCheckout", ' . wp_json_encode( $payload ) . ');' );
	}

	/**
	 * Generate add_payment_info script.
	 *
	 * @since 9.0.0
	 * @param array  $contents    Formatted cart items.
	 * @param float  $total_value Total cart value.
	 * @param string $currency    Currency code.
	 * @return string|null
	 */
	public function wpa_generate_add_payment_info_script( $contents, $total_value, $currency ) {
		$payload = array(
			'content_type' => 'product_group',
			'content_ids'  => $this->wpa_tiktok_content_ids_from_contents( $contents ),
			'contents'     => $contents,
			'value'        => (float) $total_value,
			'currency'     => $currency,
		);
		return $this->wpa_tiktok_track_when_ready( 'ttq.track("AddPaymentInfo", ' . wp_json_encode( $payload ) . ');' );
	}

	/**
	 * Generate purchase script.
	 *
	 * Single **Purchase** event (CompletePayment is not also sent — that caused duplicate conversions in Pixel Helper).
	 * `event_id` pairs browser + Events API. A window guard prevents double-fire if the inline script runs twice.
	 * Deferred with `load` + `ttq.ready` because order-received pages sometimes run before `events.js` finishes.
	 *
	 * @since 9.0.0
	 * @param WC_Order $order       The WooCommerce order.
	 * @param array    $contents    Formatted order items.
	 * @param float    $total_value Total order value.
	 * @param string   $currency    Currency code.
	 * @return string|null
	 */
	public function wpa_generate_purchase_script( $order, $contents, $total_value, $currency ) {
		$order_id_str = (string) $order->get_id();
		$payload      = array(
			'content_type' => 'product_group',
			'content_ids'  => $this->wpa_tiktok_content_ids_from_contents( $contents ),
			'contents'     => $contents,
			'value'        => (float) $order->get_total(),
			'currency'     => $currency,
			'order_id'     => $order_id_str,
			'event_id'     => 'woo_order_' . $order_id_str,
		);
		$json_flags   = defined( 'JSON_UNESCAPED_UNICODE' ) ? JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES : 0;
		$json         = wp_json_encode( $payload, $json_flags );
		return '(function(){var p=' . $json . ";function runTikTokPurchase(){if(typeof ttq==='undefined'){return;}var d=window.__wpaTikTokPurchaseDone=window.__wpaTikTokPurchaseDone||{};var eid=p.event_id||'';if(eid&&d[eid]){return;}if(eid){d[eid]=1;}function send(){ttq.track('Purchase',p);}if(typeof ttq.ready==='function'){ttq.ready(send);}else{send();}}function start(){runTikTokPurchase();}if(document.readyState==='complete'){start();}else{window.addEventListener('load',start);}})();";
	}

	/**
	 * Generate coupon script.
	 *
	 * @since 9.0.0
	 * @param string $action      Either 'applied' or 'removed'.
	 * @param string $coupon_code The coupon code.
	 * @return string|null
	 */
	public function wpa_generate_coupon_script( $action, $coupon_code ) {
		$event_name = ( 'applied' === $action ) ? 'CouponApplied' : 'CouponRemoved';
		$coupon_js  = esc_js( $coupon_code );
		return $this->wpa_tiktok_track_when_ready(
			'ttq.track("Custom", ' . wp_json_encode(
				array(
					'content_name' => $event_name,
					'coupon_code'  => sanitize_text_field( $coupon_code ),
				)
			) . ');'
		);
	}

	/**
	 * Generate search script.
	 *
	 * @since 9.0.0
	 * @param string $search_query The search query.
	 * @param string $currency     Currency code.
	 * @return string|null
	 */
	public function wpa_generate_search_script( $search_query, $currency ) {
		$payload = array(
			'search_string' => sanitize_text_field( $search_query ),
			'content_type'  => 'product',
			'currency'      => $currency,
		);
		return $this->wpa_tiktok_track_when_ready( 'ttq.track("Search", ' . wp_json_encode( $payload ) . ');' );
	}
}
