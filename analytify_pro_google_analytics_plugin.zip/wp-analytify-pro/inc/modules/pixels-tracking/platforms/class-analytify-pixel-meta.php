<?php
/**
 * Meta (Facebook) Pixel Platform implementation.
 *
 * @package wp-analytify-pro
 * @since 9.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Meta (Facebook) platform class.
 *
 * @since 9.0.0
 */
class Analytify_Pixel_Meta extends Analytify_Pixel_Platform {

	/**
	 * Platform key.
	 *
	 * @var string
	 */
	protected $key = 'meta';

	/**
	 * Inject base tracking script into head.
	 *
	 * @since 9.0.0
	 */
	public function wpa_inject_base_script() {
		?>
		<!-- Analytify Meta Pixel Code -->
		<!-- Facebook Pixel Code -->
		<script data-pixel-id="<?php echo esc_attr( $this->pixel_id ); ?>">
		!function(f,b,e,v,n,t,s)
		{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
		n.callMethod.apply(n,arguments):n.queue.push(arguments)};
		if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
		n.queue=[];t=b.createElement(e);t.async=!0;
		t.src=v;s=b.getElementsByTagName(e)[0];
		s.parentNode.insertBefore(t,s)}(window, document,'script',
		'https://connect.facebook.net/en_US/fbevents.js');
		fbq('init', '<?php echo esc_js( $this->pixel_id ); ?>', {}, { autoConfig: false });
		fbq('track', 'PageView');
		</script>
		<noscript><img height="1" width="1" style="display:none"
		src="https://www.facebook.com/tr?id=<?php echo esc_attr( $this->pixel_id ); ?>&ev=PageView&noscript=1"
		/></noscript>
		<!-- End Facebook Pixel Code -->
		<?php
	}

	/**
	 * Format standardized product data for Meta.
	 *
	 * @since 9.0.0
	 * @param array $data Standardized product data.
	 * @return array
	 */
	public function wpa_format_item( $data ) {
		return array(
			'content_ids'      => array( (string) $data['id'] ),
			'content_name'     => sanitize_text_field( $data['name'] ),
			'content_category' => sanitize_text_field( $data['category'] ),
			'content_type'     => 'product',
			'value'            => (float) $data['value'],
			'currency'         => wpa_pixels_get_currency(),
		);
	}

	/**
	 * Generate view_item script.
	 *
	 * @since 9.0.0
	 * @param array  $product_data Standardized product data.
	 * @param string $currency     Currency code.
	 * @return string|null
	 */
	public function wpa_generate_view_item_script( $product_data, $currency ) {
		$item = $this->wpa_format_item( $product_data );
		return "fbq('track', 'ViewContent', { content_ids: " . wp_json_encode( $item['content_ids'] ) . ", content_name: '" . esc_js( $item['content_name'] ) . "', content_category: '" . esc_js( $item['content_category'] ) . "', content_type: 'product', value: " . esc_js( $item['value'] ) . ", currency: '" . esc_js( $currency ) . "' });";
	}

	/**
	 * Flatten content_ids from formatted items for Meta product_group events.
	 * Meta expects content_ids as a flat array of IDs, not array of arrays.
	 *
	 * @since 9.0.0
	 * @param array $items Array of formatted items (each may have 'content_ids' array).
	 * @return array Flat list of content IDs.
	 */
	private function wpa_flatten_content_ids( $items ) {
		$ids = array();
		foreach ( $items as $item ) {
			if ( ! empty( $item['content_ids'] ) && is_array( $item['content_ids'] ) ) {
				$ids = array_merge( $ids, $item['content_ids'] );
			}
		}
		return $ids;
	}

	/**
	 * Generate view_list script.
	 *
	 * @since 9.0.0
	 * @param array $product_list Array of formatted items.
	 * @return string|null
	 */
	public function wpa_generate_view_list_script( $product_list ) {
		if ( empty( $product_list ) ) {
			return null;
		}

		$content_ids = $this->wpa_flatten_content_ids( $product_list );
		return "
		fbq('track', 'ViewContent', {
			content_type: 'product_group',
			content_ids: " . wp_json_encode( $content_ids ) . '
		});
		';
	}

	/**
	 * Generate add_to_cart script.
	 * Fires on add-to-cart button click (not on page load) for correct attribution.
	 *
	 * @since 9.0.0
	 * @param array  $product_data Standardized product data.
	 * @param string $currency     Currency code.
	 * @return string|null
	 */
	public function wpa_generate_add_to_cart_script( $product_data, $currency ) {
		$item       = $this->wpa_format_item( $product_data );
		$payload    = array(
			'content_ids'      => $item['content_ids'],
			'content_name'     => $item['content_name'],
			'content_category' => $item['content_category'],
			'content_type'     => 'product',
			'value'            => $item['value'],
			'currency'         => $currency,
		);
		$payload_js = wp_json_encode( $payload );
		return '
		(function() {
			var basePayload = ' . $payload_js . ";
			function wpaMetaParseUnitPriceFromDom(form, btn) {
				var scope = (form && form.closest && form.closest('.product')) || (btn && btn.closest && btn.closest('.product')) || document.querySelector('.wp-block-woocommerce-product-summary, .wc-block-product');
				if (!scope) return null;
				var amt = scope.querySelector('.price ins .woocommerce-Price-amount, .price .woocommerce-Price-amount.amount, .price .amount, p.price .woocommerce-Price-amount');
				if (!amt) return null;
				var text = (amt.textContent || '').replace(/\\s/g, '');
				var cleaned = text.replace(/[^0-9.,-]/g, '');
				if (cleaned.indexOf(',') > -1 && cleaned.indexOf('.') > -1) {
					cleaned = cleaned.replace(/\\./g, '').replace(',', '.');
				} else if (cleaned.indexOf(',') > -1 && cleaned.indexOf('.') === -1) {
					cleaned = cleaned.replace(',', '.');
				}
				var v = parseFloat(cleaned);
				return isNaN(v) ? null : v;
			}
			function wpaResolveAddToCartBtn(t) {
				if (!t || !t.closest) return null;
				return t.closest('.single_add_to_cart_button') || t.closest('a.add_to_cart_button') || t.closest('button.add_to_cart_button');
			}
			function fireAddToCart(e) {
				var btn = wpaResolveAddToCartBtn(e.target);
				if (!btn) return;
				var p = Object.assign({}, basePayload);
				var form = btn.form || (btn.closest && btn.closest('form'));
				var qtyEl = form && form.querySelector('input.qty, input[name=\"quantity\"]');
				var qty = qtyEl && qtyEl.value ? parseInt(qtyEl.value, 10) : 1;
				if (isNaN(qty) || qty < 1) qty = 1;
				if (form && form.classList && form.classList.contains('variations_form')) {
					var vidEl = form.querySelector('input[name=variation_id]');
					if (vidEl && vidEl.value) {
						p.content_ids = [String(vidEl.value)];
						var priceEl = form.querySelector('.woocommerce-variation-price .amount');
						if (priceEl && priceEl.textContent) {
							var pt = priceEl.textContent.replace(/[^0-9.,-]+/g, '').replace(',', '.');
							var pv = parseFloat(pt);
							if (!isNaN(pv)) { p.value = pv * qty; }
						}
					}
				}
				if (!p.value || p.value === 0) {
					var domUnit = wpaMetaParseUnitPriceFromDom(form, btn);
					if (domUnit != null) { p.value = domUnit * qty; }
				}
				if (typeof fbq !== 'undefined') { fbq('track', 'AddToCart', p); }
			}
			document.addEventListener('click', fireAddToCart, true);
		})();
		";
	}

	/**
	 * Add-to-cart on shop/archive pages (AJAX add-to-cart links; uses data-product_id from the button).
	 *
	 * @since 9.0.0
	 * @param string $currency Currency code.
	 * @return string|null
	 */
	public function wpa_generate_add_to_cart_loop_script( $currency ) {
		$currency_js = esc_js( $currency );
		return "
		(function() {
			function wpaResolveLoopAtcBtn(t) {
				if (!t || !t.closest) return null;
				var btn = t.closest('a.add_to_cart_button') || t.closest('button.add_to_cart_button');
				if (!btn || btn.classList.contains('single_add_to_cart_button')) return null;
				return btn;
			}
			document.addEventListener('click', function(e) {
				var btn = wpaResolveLoopAtcBtn(e.target);
				if (!btn) return;
				var pid = btn.getAttribute('data-product_id') || (btn.dataset && btn.dataset.product_id);
				if (!pid || typeof fbq === 'undefined') return;
				fbq('track', 'AddToCart', {
					content_ids: [String(pid)],
					content_type: 'product',
					currency: '" . $currency_js . "',
					value: 0
				});
			}, true);
		})();
		";
	}

	/**
	 * Generate remove_from_cart script.
	 *
	 * @since 9.0.0
	 * @param string $currency Currency code.
	 * @return string|null
	 */
	public function wpa_generate_remove_from_cart_script( $currency ) {
		$currency_js = esc_js( $currency );
		return "
		(function() {
			function wpaFindCartRow(btn) {
				if (!btn || !btn.closest) return null;
				return btn.closest('tr') || btn.closest('.wc-block-cart-items__row') || btn.closest('div.wc-block-cart-item');
			}
			function getRowText(row, selector) {
				if (!row || !row.querySelector) return '';
				var node = row.querySelector(selector);
				return (node && node.textContent) ? node.textContent.trim() : '';
			}
			function parseMoney(text) {
				if (!text) return 0;
				var cleaned = text.replace(/\\s/g, '').replace(/[^0-9.,-]/g, '');
				if (cleaned.indexOf(',') > -1 && cleaned.indexOf('.') > -1) {
					cleaned = cleaned.replace(/\\./g, '').replace(',', '.');
				} else if (cleaned.indexOf(',') > -1 && cleaned.indexOf('.') === -1) {
					cleaned = cleaned.replace(',', '.');
				}
				var v = parseFloat(cleaned);
				return isNaN(v) ? 0 : v;
			}
			document.addEventListener('click', function(e) {
				var t = e.target;
				if (!t || !t.closest) return;
				var removeBtn = t.classList && t.classList.contains('remove') ? t : t.closest('.remove');
				if (!removeBtn) removeBtn = t.closest('.wc-block-cart-item__remove-link');
				if (!removeBtn) return;
				var productId = removeBtn.getAttribute && (removeBtn.getAttribute('data-product_id') || removeBtn.getAttribute('data-product-id'));
				var row = wpaFindCartRow(removeBtn);
				var productName = getRowText(row, '.product-name a');
				if (!productName && row) {
					productName = getRowText(row, '.wc-block-components-product-name, .wc-block-cart-item__product-name, .wc-block-cart-item__wrap a');
				}
				var priceText = '';
				if (row) {
					priceText = getRowText(row, '.product-price .amount') || getRowText(row, '.wc-block-cart-item__total .wc-block-formatted-money-amount');
				}
				var productPrice = parseMoney(priceText);
				var ids = productId ? [String(productId)] : [];
				if (typeof fbq !== 'undefined') {
					fbq('track', 'RemoveFromCart', { content_ids: ids, content_name: productName, content_type: 'product', value: productPrice, currency: '" . $currency_js . "' });
				}
			}, true);
		})();
		";
	}

	/**
	 * Generate view_cart script.
	 *
	 * @param float  $cart_total Cart total value.
	 * @param string $currency   Currency code.
	 * @return string|null
	 */
	public function wpa_generate_view_cart_script( $cart_total, $currency ) {
		return "fbq('track', 'ViewContent', { content_type: 'cart', value: " . esc_js( $cart_total ) . ", currency: '" . esc_js( $currency ) . "' });";
	}

	/**
	 * Generate begin_checkout script.
	 *
	 * @since 9.0.0
	 * @param array  $contents    Formatted cart items.
	 * @param float  $total_value Total cart value.
	 * @param string $currency    Currency code.
	 * @return string|null
	 */
	public function wpa_generate_begin_checkout_script( $contents, $total_value, $currency ) {
		$content_ids = $this->wpa_flatten_content_ids( $contents );
		$payload     = wp_json_encode(
			array(
				'content_type' => 'product_group',
				'content_ids'  => $content_ids,
				'value'        => (float) $total_value,
				'currency'     => $currency,
			)
		);
		return '(function(){if(typeof fbq==="undefined")return;var p=' . $payload . ";fbq('track','InitiateCheckout',p);fbq('track','AddPaymentInfo',p);})();";
	}

	/**
	 * AddPaymentInfo is emitted with InitiateCheckout (see wpa_generate_begin_checkout_script).
	 *
	 * @param array  $contents    Unused.
	 * @param float  $total_value Unused.
	 * @param string $currency    Unused.
	 * @return null
	 */
	public function wpa_generate_add_payment_info_script( $contents, $total_value, $currency ) {
		unset( $contents, $total_value, $currency );
		return null;
	}

	/**
	 * Generate purchase script.
	 *
	 * @since 9.0.0
	 * @param WC_Order $order       The WooCommerce order.
	 * @param array    $contents    Formatted order items.
	 * @param float    $total_value Total order value.
	 * @param string   $currency    Currency code.
	 * @return string|null
	 */
	public function wpa_generate_purchase_script( $order, $contents, $total_value, $currency ) {
		$content_ids = $this->wpa_flatten_content_ids( $contents );
		return "
		fbq('track', 'Purchase', {
			content_type: 'product',
			content_ids: " . wp_json_encode( $content_ids ) . ',
			value: ' . esc_js( $order->get_total() ) . ",
			currency: '" . esc_js( $currency ) . "',
			order_id: '" . esc_js( $order->get_id() ) . "'
		});
		";
	}

	/**
	 * Generate coupon script.
	 *
	 * @since 9.0.0
	 * @param string $action      Either 'applied' or 'removed'.
	 * @param string $coupon_code The coupon code.
	 * @return string|null
	 */
	public function wpa_generate_coupon_script( $action, $coupon_code ) {
		$event_suffix = ( 'applied' === $action ) ? 'Applied' : 'Removed';
		return "fbq('trackCustom', 'Coupon{$event_suffix}', { coupon_code: '" . esc_js( $coupon_code ) . "' });";
	}

	/**
	 * Generate search script.
	 *
	 * @since 9.0.0
	 * @param string $search_query The search query.
	 * @param string $currency     Currency code.
	 * @return string|null
	 */
	public function wpa_generate_search_script( $search_query, $currency ) {
		return "fbq('track', 'Search', { search_string: '" . esc_js( $search_query ) . "' });";
	}
}
