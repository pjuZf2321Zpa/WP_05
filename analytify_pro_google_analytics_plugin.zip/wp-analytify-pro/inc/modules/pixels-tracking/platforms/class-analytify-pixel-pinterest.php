<?php
/**
 * Pinterest Pixel Platform implementation.
 *
 * @package wp-analytify-pro
 * @since 9.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Pinterest platform class.
 *
 * @since 9.0.0
 */
class Analytify_Pixel_Pinterest extends Analytify_Pixel_Platform {

	/**
	 * Platform key.
	 *
	 * @var string
	 */
	protected $key = 'pinterest';

	/**
	 * SHA256 hash of normalized email for Pinterest Tag v3 advanced matching (logged-in users only).
	 *
	 * @since 9.0.0
	 * @return string Hex hash or empty string.
	 */
	private function wpa_pinterest_hashed_email() {
		if ( ! is_user_logged_in() ) {
			return '';
		}
		$user = wp_get_current_user();
		if ( ! $user || empty( $user->user_email ) || ! is_email( $user->user_email ) ) {
			return '';
		}
		return hash( 'sha256', strtolower( trim( $user->user_email ) ) );
	}

	/**
	 * Inject Pinterest Tag v3 (core.js) into head.
	 *
	 * @since 9.0.0
	 */
	public function wpa_inject_base_script() {
		$tag_id    = $this->pixel_id;
		$em_hash   = $this->wpa_pinterest_hashed_email();
		$load_json = $em_hash ? wp_json_encode( array( 'em' => $em_hash ) ) : '';
		$nosrc     = 'https://ct.pinterest.com/v3/?event=init&tid=' . rawurlencode( (string) $tag_id ) . '&noscript=1';
		if ( $em_hash ) {
			$nosrc .= '&pd%5Bem%5D=' . rawurlencode( $em_hash );
		}
		?>
		<!-- Analytify Pinterest Tag v3 -->
		<script>
		!function(e){if(!window.pintrk){window.pintrk = function () {
		window.pintrk.queue.push(Array.prototype.slice.call(arguments))};var
		n=window.pintrk;n.queue=[],n.version="3.0";var
		t=document.createElement("script");t.async=!0,t.src=e;var
		r=document.getElementsByTagName("script")[0];
		r.parentNode.insertBefore(t,r)}}("https://s.pinimg.com/ct/core.js");
		pintrk('load', '<?php echo esc_js( $tag_id ); ?>'
		<?php
		if ( $load_json ) {
			echo ', ';
			// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON object from wp_json_encode().
			echo $load_json;
		}
		?>
		);
		pintrk('page');
		</script>
		<noscript>
		<img height="1" width="1" style="display:none;" alt="" src="<?php echo esc_url( $nosrc ); ?>" />
		</noscript>
		<?php
	}

	/**
	 * Format standardized product data for Pinterest.
	 *
	 * @since 9.0.0
	 * @param array $data Standardized product data.
	 * @return array
	 */
	public function wpa_format_item( $data ) {
		$category = isset( $data['category'] ) ? sanitize_text_field( $data['category'] ) : '';
		return array(
			'product_id'       => (string) $data['id'],
			'product_name'     => sanitize_text_field( $data['name'] ),
			'product_category' => $category,
			'product_price'    => (float) $data['price'],
			'product_quantity' => (int) $data['quantity'],
		);
	}

	/**
	 * Generate view_item script.
	 *
	 * @since 9.0.0
	 * @param array  $product_data Standardized product data.
	 * @param string $currency     Currency code.
	 * @return string|null
	 */
	public function wpa_generate_view_item_script( $product_data, $currency ) {
		$item = $this->wpa_format_item( $product_data );
		return "
		if (typeof pintrk !== 'undefined') {
			pintrk('track', 'ViewContent', {
				'value': " . esc_js( $product_data['price'] ) . ",
				'currency': '" . esc_js( $currency ) . "',
				'line_items': [" . wp_json_encode( $item ) . ']
			});
		}
		';
	}

	/**
	 * Generate view_list script.
	 *
	 * @since 9.0.0
	 * @param array $product_list Array of formatted items.
	 * @return string|null
	 */
	public function wpa_generate_view_list_script( $product_list ) {
		if ( empty( $product_list ) ) {
			return null;
		}

		$value    = 0.0;
		$currency = function_exists( 'wpa_pixels_get_currency' ) ? wpa_pixels_get_currency() : '';
		foreach ( $product_list as $row ) {
			if ( isset( $row['product_price'], $row['product_quantity'] ) ) {
				$value += (float) $row['product_price'] * (int) $row['product_quantity'];
			}
		}
		$event = array( 'line_items' => $product_list );
		if ( $value > 0 ) {
			$decimals       = function_exists( 'wc_get_price_decimals' ) ? wc_get_price_decimals() : 2;
			$event['value'] = round( $value, $decimals );
		}
		if ( $currency ) {
			$event['currency'] = $currency;
		}

		return "
		if (typeof pintrk !== 'undefined') {
			pintrk('track', 'ViewCategory', " . wp_json_encode( $event ) . ');
		}
		';
	}

	/**
	 * Generate add_to_cart script.
	 *
	 * @since 9.0.0
	 * @param array  $product_data Standardized product data.
	 * @param string $currency     Currency code.
	 * @return string|null
	 */
	public function wpa_generate_add_to_cart_script( $product_data, $currency ) {
		$fallback_id  = esc_js( $product_data['id'] );
		$fallback_qty = (int) $product_data['quantity'];
		$name_js      = esc_js( $product_data['name'] );
		$cat_js       = esc_js( isset( $product_data['category'] ) ? $product_data['category'] : '' );
		$price_js     = esc_js( $product_data['price'] );
		$currency_js  = esc_js( $currency );
		return "
		(function() {
			function wpaResolveAddToCartBtn(t) {
				if (!t || !t.closest) return null;
				return t.closest('.single_add_to_cart_button') || t.closest('a.add_to_cart_button') || t.closest('button.add_to_cart_button');
			}
			function fireAddToCart(e) {
				var btn = wpaResolveAddToCartBtn(e.target);
				if (!btn) return;
				var form = btn.form || (btn.closest && btn.closest('form'));
				var productId = (form && form.querySelector('[name=\"add-to-cart\"]')) ? form.querySelector('[name=\"add-to-cart\"]').value : '" . $fallback_id . "';
				var qtyEl = form && form.querySelector('input[name=\"quantity\"]');
				var quantity = (qtyEl && qtyEl.value) ? parseInt(qtyEl.value, 10) : " . $fallback_qty . ";
				if (typeof pintrk !== 'undefined') {
					pintrk('track', 'AddToCart', {
						'value': " . $price_js . ",
						'currency': '" . $currency_js . "',
						'line_items': [{'product_id': productId, 'product_name': '" . $name_js . "', 'product_category': '" . $cat_js . "', 'product_price': " . $price_js . ", 'product_quantity': quantity}]
					});
				}
			}
			document.addEventListener('click', fireAddToCart, true);
		})();
		";
	}

	/**
	 * Add-to-cart on shop/archive pages (uses data-product_id from the button).
	 *
	 * @since 9.0.0
	 * @param string $currency Currency code.
	 * @return string|null
	 */
	public function wpa_generate_add_to_cart_loop_script( $currency ) {
		$currency_js = esc_js( $currency );
		return "
		(function() {
			function parseMoney(text) {
				if (!text) return 0;
				var cleaned = String(text).replace(/\\s/g, '').replace(/[^0-9.,-]/g, '');
				if (cleaned.indexOf(',') > -1 && cleaned.indexOf('.') > -1) {
					cleaned = cleaned.replace(/\\./g, '').replace(',', '.');
				} else if (cleaned.indexOf(',') > -1 && cleaned.indexOf('.') === -1) {
					cleaned = cleaned.replace(',', '.');
				}
				var v = parseFloat(cleaned);
				return isNaN(v) ? 0 : v;
			}
			document.addEventListener('click', function(e) {
				var t = e.target;
				if (!t || !t.closest) return;
				var btn = t.closest('a.add_to_cart_button') || t.closest('button.add_to_cart_button');
				if (!btn || btn.classList.contains('single_add_to_cart_button')) return;
				var pid = btn.getAttribute('data-product_id') || (btn.dataset && btn.dataset.product_id);
				if (!pid || typeof pintrk === 'undefined') return;
				var pcat = btn.getAttribute('data-product_category') || (btn.dataset && btn.dataset.product_category) || '';
				var wrap = btn.closest('.product, li.wc-block-grid__product, .wc-block-product');
				var pval = 0;
				if (wrap) {
					var amt = wrap.querySelector('.price .amount, .woocommerce-Price-amount, .wc-block-components-product-price');
					pval = parseMoney(amt && amt.textContent);
				}
				pintrk('track', 'AddToCart', {
					value: pval,
					currency: '" . $currency_js . "',
					line_items: [{ product_id: String(pid), product_category: pcat, product_price: pval, product_quantity: 1 }]
				});
			}, true);
		})();
		";
	}

	/**
	 * Generate remove_from_cart script.
	 *
	 * @since 9.0.0
	 * @param string $currency Currency code.
	 * @return string|null
	 */
	public function wpa_generate_remove_from_cart_script( $currency ) {
		return "
		(function() {
			function wpaFindCartRow(btn) {
				if (!btn || !btn.closest) return null;
				return btn.closest('tr') || btn.closest('.wc-block-cart-items__row') || btn.closest('div.wc-block-cart-item');
			}
			function getRowText(row, selector) {
				if (!row || !row.querySelector) return '';
				var node = row.querySelector(selector);
				return (node && node.textContent) ? node.textContent.trim() : '';
			}
			function parseMoney(text) {
				if (!text) return 0;
				var cleaned = String(text).replace(/\\s/g, '').replace(/[^0-9.,-]/g, '');
				if (cleaned.indexOf(',') > -1 && cleaned.indexOf('.') > -1) {
					cleaned = cleaned.replace(/\\./g, '').replace(',', '.');
				} else if (cleaned.indexOf(',') > -1 && cleaned.indexOf('.') === -1) {
					cleaned = cleaned.replace(',', '.');
				}
				var v = parseFloat(cleaned);
				return isNaN(v) ? 0 : v;
			}
			document.addEventListener('click', function(e) {
				var t = e.target;
				if (!t || !t.closest) return;
				var removeBtn = t.classList && t.classList.contains('remove') ? t : t.closest('.remove');
				if (!removeBtn) removeBtn = t.closest('.wc-block-cart-item__remove-link');
				if (!removeBtn) return;
				var productId = removeBtn.getAttribute && (removeBtn.getAttribute('data-product_id') || removeBtn.getAttribute('data-product-id'));
				var row = wpaFindCartRow(removeBtn);
				var productName = row ? getRowText(row, '.product-name a') : '';
				if (!productName && row) {
					productName = getRowText(row, '.wc-block-components-product-name, .wc-block-cart-item__product-name, .wc-block-cart-item__wrap a');
				}
				var priceText = '';
				if (row) {
					priceText = getRowText(row, '.product-price .amount') || getRowText(row, '.wc-block-cart-item__total .wc-block-formatted-money-amount');
				}
				var productPrice = parseMoney(priceText);
				var pcat = '';
				if (row) {
					pcat = (row.getAttribute && (row.getAttribute('data-product_category') || row.getAttribute('data-product-category'))) || '';
				}
				if (typeof pintrk !== 'undefined' && productId) {
					pintrk('track', 'RemoveFromCart', { line_items: [{ product_id: String(productId), product_name: productName, product_category: pcat, product_price: productPrice }] });
				}
			}, true);
		})();
		";
	}

	/**
	 * Generate view_cart script.
	 *
	 * @since 9.0.0
	 * @param float  $cart_total Cart total value.
	 * @param string $currency   Currency code.
	 * @return string|null
	 */
	public function wpa_generate_view_cart_script( $cart_total, $currency ) {
		$line_items = array();
		if ( function_exists( 'WC' ) && WC()->cart && ! WC()->cart->is_empty() ) {
			foreach ( WC()->cart->get_cart() as $line ) {
				$product = isset( $line['data'] ) ? $line['data'] : null;
				if ( ! is_a( $product, 'WC_Product' ) ) {
					continue;
				}
				$base_id      = $product->get_parent_id() ? $product->get_parent_id() : $product->get_id();
				$variation_id = ! empty( $line['variation_id'] ) ? (int) $line['variation_id'] : 0;
				$track_id     = $variation_id ? $variation_id : $product->get_id();
				$qty          = isset( $line['quantity'] ) ? (int) $line['quantity'] : 1;
				$price        = (float) $product->get_price();
				$cat          = '';
				$terms        = get_the_terms( $base_id, 'product_cat' );
				if ( is_array( $terms ) && ! empty( $terms ) ) {
					$cat = sanitize_text_field( $terms[0]->name );
				}
				$line_items[] = $this->wpa_format_item(
					array(
						'id'       => (string) $track_id,
						'name'     => $product->get_name(),
						'category' => $cat,
						'price'    => $price,
						'quantity' => $qty,
						'value'    => $price * $qty,
					)
				);
			}
		}
		$event = array(
			'value'      => (float) $cart_total,
			'currency'   => $currency,
			'line_items' => $line_items,
		);
		return 'if (typeof pintrk !== "undefined") { pintrk("track", "ViewCart", ' . wp_json_encode( $event ) . '); }';
	}

	/**
	 * Generate begin_checkout script.
	 *
	 * @since 9.0.0
	 * @param array  $contents    Formatted cart items.
	 * @param float  $total_value Total cart value.
	 * @param string $currency    Currency code.
	 * @return string|null
	 */
	public function wpa_generate_begin_checkout_script( $contents, $total_value, $currency ) {
		$event = array(
			'value'      => (float) $total_value,
			'currency'   => $currency,
			'line_items' => $contents,
		);
		return 'if (typeof pintrk !== "undefined") { pintrk("track", "InitiateCheckout", ' . wp_json_encode( $event ) . '); }';
	}

	/**
	 * Generate add_payment_info script.
	 *
	 * @since 9.0.0
	 * @param array  $contents    Formatted cart items.
	 * @param float  $total_value Total cart value.
	 * @param string $currency    Currency code.
	 * @return string|null
	 */
	public function wpa_generate_add_payment_info_script( $contents, $total_value, $currency ) {
		$event = array(
			'value'      => (float) $total_value,
			'currency'   => $currency,
			'line_items' => $contents,
		);
		return 'if (typeof pintrk !== "undefined") { pintrk("track", "AddPaymentInfo", ' . wp_json_encode( $event ) . '); }';
	}

	/**
	 * Generate purchase script.
	 *
	 * @since 9.0.0
	 * @param WC_Order $order       The WooCommerce order.
	 * @param array    $contents    Formatted order items.
	 * @param float    $total_value Total order value.
	 * @param string   $currency    Currency code.
	 * @return string|null
	 */
	public function wpa_generate_purchase_script( $order, $contents, $total_value, $currency ) {
		$order_qty = 0;
		foreach ( $order->get_items() as $oi ) {
			$order_qty += $oi->get_quantity();
		}
		$event = array(
			'value'          => (float) $order->get_total(),
			'currency'       => $currency,
			'order_id'       => (string) $order->get_id(),
			'order_quantity' => (int) $order_qty,
			'line_items'     => $contents,
		);
		return 'if (typeof pintrk !== "undefined") { pintrk("track", "Checkout", ' . wp_json_encode( $event ) . '); }';
	}

	/**
	 * Generate coupon script.
	 *
	 * @since 9.0.0
	 * @param string $action      Either 'applied' or 'removed'.
	 * @param string $coupon_code The coupon code.
	 * @return string|null
	 */
	public function wpa_generate_coupon_script( $action, $coupon_code ) {
		return "if (typeof pintrk !== 'undefined') { pintrk('track', 'Custom', { 'coupon_code': '" . esc_js( $coupon_code ) . "' }); }";
	}

	/**
	 * Generate search script.
	 *
	 * @since 9.0.0
	 * @param string $search_query The search query.
	 * @param string $currency     Currency code.
	 * @return string|null
	 */
	public function wpa_generate_search_script( $search_query, $currency ) {
		return "if (typeof pintrk !== 'undefined') { pintrk('track', 'Search', { 'search_query': '" . esc_js( $search_query ) . "' }); }";
	}
}
