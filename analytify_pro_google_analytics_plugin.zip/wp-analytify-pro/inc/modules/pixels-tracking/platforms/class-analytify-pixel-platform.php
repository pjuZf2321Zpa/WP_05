<?php
/**
 * Abstract class for pixel tracking platforms.
 *
 * @package wp-analytify-pro
 * @since 9.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Abstract platform base class.
 *
 * @since 9.0.0
 */
abstract class Analytify_Pixel_Platform {

	/**
	 * The pixel key/identifier (e.g., 'meta', 'tiktok').
	 *
	 * @var string
	 */
	protected $key;

	/**
	 * The pixel ID/Tag.
	 *
	 * @var string
	 */
	protected $pixel_id;

	/**
	 * Analytify_Pixel_Platform constructor.
	 *
	 * @since 9.0.0
	 * @param string $pixel_id The platform's pixel ID.
	 */
	public function __construct( $pixel_id ) {
		$this->pixel_id = $pixel_id;
	}

	/**
	 * Get the platform key.
	 *
	 * @since 9.0.0
	 * @return string
	 */
	public function get_key() {
		return $this->key;
	}

	/**
	 * Inject base tracking script into head.
	 *
	 * @since 9.0.0
	 */
	abstract public function wpa_inject_base_script();

	/**
	 * Generate view_item script.
	 *
	 * @since 9.0.0
	 * @param array  $product_data Standardized product data.
	 * @param string $currency     Currency code.
	 * @return string|null
	 */
	abstract public function wpa_generate_view_item_script( $product_data, $currency );

	/**
	 * Generate view_list script.
	 *
	 * @since 9.0.0
	 * @param array $product_list Standardized product data.
	 * @return string|null
	 */
	abstract public function wpa_generate_view_list_script( $product_list );

	/**
	 * Generate add_to_cart script.
	 *
	 * @since 9.0.0
	 * @param array  $product_data Standardized product data.
	 * @param string $currency     Currency code.
	 * @return string|null
	 */
	abstract public function wpa_generate_add_to_cart_script( $product_data, $currency );

	/**
	 * Generate remove_from_cart script.
	 *
	 * @since 9.0.0
	 * @param string $currency Currency code.
	 * @return string|null
	 */
	abstract public function wpa_generate_remove_from_cart_script( $currency );

	/**
	 * Generate view_cart script.
	 *
	 * @since 9.0.0
	 * @param float  $cart_total Cart total value.
	 * @param string $currency   Currency code.
	 * @return string|null
	 */
	abstract public function wpa_generate_view_cart_script( $cart_total, $currency );

	/**
	 * Generate begin_checkout script.
	 *
	 * @since 9.0.0
	 * @param array  $contents    Formatted cart items.
	 * @param float  $total_value Total cart value.
	 * @param string $currency    Currency code.
	 * @return string|null
	 */
	abstract public function wpa_generate_begin_checkout_script( $contents, $total_value, $currency );

	/**
	 * Generate add_payment_info script.
	 *
	 * @since 9.0.0
	 * @param array  $contents    Formatted cart items.
	 * @param float  $total_value Total cart value.
	 * @param string $currency    Currency code.
	 * @return string|null
	 */
	abstract public function wpa_generate_add_payment_info_script( $contents, $total_value, $currency );

	/**
	 * Generate purchase script.
	 *
	 * @since 9.0.0
	 * @param WC_Order $order       The WooCommerce order.
	 * @param array    $contents    Formatted order items.
	 * @param float    $total_value Total order value.
	 * @param string   $currency    Currency code.
	 * @return string|null
	 */
	abstract public function wpa_generate_purchase_script( $order, $contents, $total_value, $currency );

	/**
	 * Generate coupon script.
	 *
	 * @since 9.0.0
	 * @param string $action      Either 'applied' or 'removed'.
	 * @param string $coupon_code The coupon code.
	 * @return string|null
	 */
	abstract public function wpa_generate_coupon_script( $action, $coupon_code );

	/**
	 * Generate search script.
	 *
	 * @since 9.0.0
	 * @param string $search_query The search query.
	 * @param string $currency     Currency code.
	 * @return string|null
	 */
	abstract public function wpa_generate_search_script( $search_query, $currency );

	/**
	 * Format standardized product data for the platform.
	 *
	 * @since 9.0.0
	 * @param array $data Standardized product data.
	 * @return array
	 */
	abstract public function wpa_format_item( $data );
}
