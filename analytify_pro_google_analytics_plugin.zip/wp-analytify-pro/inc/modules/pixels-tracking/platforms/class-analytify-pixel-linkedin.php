<?php
/**
 * LinkedIn Pixel (Insight Tag) Platform implementation.
 *
 * @package wp-analytify-pro
 * @since 9.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * LinkedIn platform class.
 *
 * The Insight Tag partner ID (settings: LinkedIn Pixel ID) loads the base tag only.
 * Each `lintrk('track', …)` call must use a numeric conversion rule ID from
 * Campaign Manager → Conversions — not the partner ID. Supported payload fields
 * per LinkedIn’s web tag API: conversion_id, value, currency, orderId (purchase deduplication).
 *
 * @since 9.0.0
 */
class Analytify_Pixel_LinkedIn extends Analytify_Pixel_Platform {

	/**
	 * Platform key.
	 *
	 * @var string
	 */
	protected $key = 'linkedin';

	/**
	 * Cached consolidated pixel options.
	 *
	 * @var array|null
	 */
	private static $wpa_linkedin_options_cache = null;

	/**
	 * Inject base tracking script into head.
	 *
	 * @since 9.0.0
	 */
	public function wpa_inject_base_script() {
		static $wpa_linkedin_insight_injected = false;
		if ( $wpa_linkedin_insight_injected ) {
			return;
		}
		$wpa_linkedin_insight_injected = true;
		?>
		<!-- Analytify LinkedIn Pixel Code -->
		<script type="text/javascript">
		_linkedin_partner_id = "<?php echo esc_js( $this->pixel_id ); ?>";
		window._linkedin_data_partner_ids = window._linkedin_data_partner_ids || [];
		window._linkedin_data_partner_ids.push(_linkedin_partner_id);
		</script>
		<script type="text/javascript">
		(function(l) {
		if (!l){window.lintrk = function(a,b){window.lintrk.q.push([a,b])};
		window.lintrk.q=[]}
		var s = document.getElementsByTagName("script")[0];
		var b = document.createElement("script");
		b.type = "text/javascript";b.async = true;
		b.src = "https://snap.licdn.com/li.lms-analytics/insight.min.js";
		s.parentNode.insertBefore(b, s);})(window.lintrk);
		</script>
		<noscript>
		<img height="1" width="1" style="display:none;" alt="" src="https://px.ads.linkedin.com/collect/?pid=<?php echo esc_attr( $this->pixel_id ); ?>&fmt=gif" />
		</noscript>
		<?php
	}

	/**
	 * Consolidated plugin options (analytify-pixels-tracking).
	 *
	 * @since 9.0.0
	 * @return array
	 */
	private function wpa_linkedin_options() {
		if ( null === self::$wpa_linkedin_options_cache ) {
			$opt                              = get_option( 'analytify-pixels-tracking' );
			self::$wpa_linkedin_options_cache = is_array( $opt ) ? $opt : array();
		}
		return self::$wpa_linkedin_options_cache;
	}

	/**
	 * Digits-only conversion rule ID for general WooCommerce events.
	 *
	 * @since 9.0.0
	 * @return int 0 if not configured.
	 */
	private function wpa_linkedin_general_conversion_id() {
		$opts = $this->wpa_linkedin_options();
		$raw  = isset( $opts['linkedin_conversion_id'] ) ? (string) $opts['linkedin_conversion_id'] : '';
		$d    = preg_replace( '/\D/', '', $raw );
		return ( '' !== $d ) ? (int) $d : 0;
	}

	/**
	 * Conversion ID for purchase (optional override), else general ID.
	 *
	 * @since 9.0.0
	 * @return int 0 if not configured.
	 */
	private function wpa_linkedin_purchase_conversion_id() {
		$opts = $this->wpa_linkedin_options();
		$raw  = isset( $opts['linkedin_conversion_id_purchase'] ) ? (string) $opts['linkedin_conversion_id_purchase'] : '';
		$d    = preg_replace( '/\D/', '', $raw );
		if ( '' !== $d ) {
			return (int) $d;
		}
		return $this->wpa_linkedin_general_conversion_id();
	}

	/**
	 * Build `lintrk('track', payload)` inline script.
	 *
	 * @since 9.0.0
	 * @param bool        $use_purchase_conversion Use purchase-specific conversion ID when set.
	 * @param float|null  $value                 null omits value (e.g. search-only conversion).
	 * @param string      $currency              ISO currency or empty.
	 * @param string|null $order_id              LinkedIn orderId (purchase deduplication).
	 * @return string|null
	 */
	private function wpa_lintrk_track_js( $use_purchase_conversion, $value, $currency = '', $order_id = null ) {
		$cid = $use_purchase_conversion ? $this->wpa_linkedin_purchase_conversion_id() : $this->wpa_linkedin_general_conversion_id();
		if ( ! $cid ) {
			return null;
		}

		$payload = array( 'conversion_id' => $cid );
		if ( null !== $value ) {
			$payload['value'] = (float) $value;
		}
		if ( is_string( $currency ) && '' !== $currency ) {
			$payload['currency'] = $currency;
		}
		if ( null !== $order_id && '' !== (string) $order_id ) {
			$payload['orderId'] = (string) $order_id;
		}

		return 'if (typeof lintrk !== "undefined") { lintrk("track", ' . wp_json_encode( $payload ) . '); }';
	}

	/**
	 * Format standardized product data (internal: view_list line totals).
	 *
	 * @since 9.0.0
	 * @param array $data Standardized product data.
	 * @return array
	 */
	public function wpa_format_item( $data ) {
		$line_value = isset( $data['value'] )
			? (float) $data['value']
			: (float) $data['price'] * max( 1, (int) $data['quantity'] );
		return array(
			'_wpa_line_value' => $line_value,
		);
	}

	/**
	 * Generate view_item script.
	 *
	 * @since 9.0.0
	 * @param array  $product_data Standardized product data.
	 * @param string $currency     Currency code.
	 * @return string|null
	 */
	public function wpa_generate_view_item_script( $product_data, $currency ) {
		$val = isset( $product_data['value'] ) ? (float) $product_data['value'] : (float) $product_data['price'] * max( 1, (int) $product_data['quantity'] );
		return $this->wpa_lintrk_track_js( false, $val, $currency );
	}

	/**
	 * Generate view_list script.
	 *
	 * @since 9.0.0
	 * @param array $product_list Array of formatted items.
	 * @return string|null
	 */
	public function wpa_generate_view_list_script( $product_list ) {
		if ( empty( $product_list ) ) {
			return null;
		}

		$sum      = 0.0;
		$currency = function_exists( 'wpa_pixels_get_currency' ) ? wpa_pixels_get_currency() : '';
		foreach ( $product_list as $row ) {
			if ( isset( $row['_wpa_line_value'] ) ) {
				$sum += (float) $row['_wpa_line_value'];
			} elseif ( isset( $row['value'], $row['quantity'] ) ) {
				$sum += (float) $row['value'] * (int) $row['quantity'];
			}
		}
		$decimals = function_exists( 'wc_get_price_decimals' ) ? wc_get_price_decimals() : 2;
		return $this->wpa_lintrk_track_js( false, round( $sum, $decimals ), $currency );
	}

	/**
	 * Generate add_to_cart script.
	 *
	 * @since 9.0.0
	 * @param array  $product_data Standardized product data.
	 * @param string $currency     Currency code.
	 * @return string|null
	 */
	public function wpa_generate_add_to_cart_script( $product_data, $currency ) {
		$conv_id = $this->wpa_linkedin_general_conversion_id();
		if ( ! $conv_id ) {
			return null;
		}
		$val         = (float) $product_data['value'];
		$currency_js = esc_js( $currency );
		return '
		(function() {
			var WPA_LI_CONV = ' . (int) $conv_id . ";
			function wpaResolveAddToCartBtn(t) {
				if (!t || !t.closest) return null;
				return t.closest('.single_add_to_cart_button') || t.closest('a.add_to_cart_button') || t.closest('button.add_to_cart_button');
			}
			document.addEventListener('click', function(e) {
				var btn = wpaResolveAddToCartBtn(e.target);
				if (!btn) return;
				if (typeof lintrk === 'undefined') return;
				var payload = { conversion_id: WPA_LI_CONV, value: " . wp_json_encode( $val ) . ", currency: '" . $currency_js . "' };
				var form = btn.form || (btn.closest && btn.closest('form'));
				var qtyEl = form && form.querySelector('input.qty, input[name=\"quantity\"]');
				var qty = qtyEl && qtyEl.value ? parseInt(qtyEl.value, 10) : 1;
				if (isNaN(qty) || qty < 1) qty = 1;
				if (form && form.classList && form.classList.contains('variations_form')) {
					var vidEl = form.querySelector('input[name=variation_id]');
					if (vidEl && vidEl.value) {
						var priceEl = form.querySelector('.woocommerce-variation-price .amount');
						if (priceEl && priceEl.textContent) {
							var pt = priceEl.textContent.replace(/[^0-9.,-]+/g, '').replace(',', '.');
							var pv = parseFloat(pt);
							if (!isNaN(pv)) { payload.value = pv * qty; }
						}
					}
				}
				lintrk('track', payload);
			}, true);
		})();
		";
	}

	/**
	 * Add-to-cart on shop/archive pages (uses data-product_id from the button).
	 *
	 * @since 9.0.0
	 * @param string $currency Currency code.
	 * @return string|null
	 */
	public function wpa_generate_add_to_cart_loop_script( $currency ) {
		$conv_id = $this->wpa_linkedin_general_conversion_id();
		if ( ! $conv_id ) {
			return null;
		}
		$currency_js = esc_js( $currency );
		return '
		(function() {
			var WPA_LI_CONV = ' . (int) $conv_id . ";
			function parseMoney(text) {
				if (!text) return 0;
				var cleaned = String(text).replace(/\\s/g, '').replace(/[^0-9.,-]/g, '');
				if (cleaned.indexOf(',') > -1 && cleaned.indexOf('.') > -1) {
					cleaned = cleaned.replace(/\\./g, '').replace(',', '.');
				} else if (cleaned.indexOf(',') > -1 && cleaned.indexOf('.') === -1) {
					cleaned = cleaned.replace(',', '.');
				}
				var v = parseFloat(cleaned);
				return isNaN(v) ? 0 : v;
			}
			document.addEventListener('click', function(e) {
				var t = e.target;
				if (!t || !t.closest) return;
				var btn = t.closest('a.add_to_cart_button') || t.closest('button.add_to_cart_button');
				if (!btn || btn.classList.contains('single_add_to_cart_button')) return;
				var pid = btn.getAttribute('data-product_id') || (btn.dataset && btn.dataset.product_id);
				if (!pid || typeof lintrk === 'undefined') return;
				var wrap = btn.closest('.product, li.wc-block-grid__product, .wc-block-product');
				var pval = 0;
				if (wrap) {
					var amt = wrap.querySelector('.price .amount, .woocommerce-Price-amount, .wc-block-components-product-price');
					pval = parseMoney(amt && amt.textContent);
				}
				lintrk('track', { conversion_id: WPA_LI_CONV, value: pval, currency: '" . $currency_js . "' });
			}, true);
		})();
		";
	}

	/**
	 * Generate remove_from_cart script.
	 *
	 * @since 9.0.0
	 * @param string $currency Currency code.
	 * @return string|null
	 */
	public function wpa_generate_remove_from_cart_script( $currency ) {
		$conv_id = $this->wpa_linkedin_general_conversion_id();
		if ( ! $conv_id ) {
			return null;
		}
		$currency_js = esc_js( $currency );
		return '
		(function() {
			var WPA_LI_CONV = ' . (int) $conv_id . ";
			function wpaFindCartRow(btn) {
				if (!btn || !btn.closest) return null;
				return btn.closest('tr') || btn.closest('.wc-block-cart-items__row') || btn.closest('div.wc-block-cart-item');
			}
			function getRowText(row, selector) {
				if (!row || !row.querySelector) return '';
				var node = row.querySelector(selector);
				return (node && node.textContent) ? node.textContent.trim() : '';
			}
			function parseMoney(text) {
				if (!text) return 0;
				var cleaned = String(text).replace(/\\s/g, '').replace(/[^0-9.,-]/g, '');
				if (cleaned.indexOf(',') > -1 && cleaned.indexOf('.') > -1) {
					cleaned = cleaned.replace(/\\./g, '').replace(',', '.');
				} else if (cleaned.indexOf(',') > -1 && cleaned.indexOf('.') === -1) {
					cleaned = cleaned.replace(',', '.');
				}
				var v = parseFloat(cleaned);
				return isNaN(v) ? 0 : v;
			}
			document.addEventListener('click', function(e) {
				var t = e.target;
				if (!t || !t.closest) return;
				var removeBtn = t.classList && t.classList.contains('remove') ? t : t.closest('.remove');
				if (!removeBtn) removeBtn = t.closest('.wc-block-cart-item__remove-link');
				if (!removeBtn) return;
				var row = wpaFindCartRow(removeBtn);
				var priceText = '';
				if (row) {
					priceText = getRowText(row, '.product-price .amount') || getRowText(row, '.wc-block-cart-item__total .wc-block-formatted-money-amount');
				}
				var productPrice = parseMoney(priceText);
				if (typeof lintrk !== 'undefined') {
					lintrk('track', { conversion_id: WPA_LI_CONV, value: productPrice, currency: '" . $currency_js . "' });
				}
			}, true);
		})();
		";
	}

	/**
	 * Generate view_cart script.
	 *
	 * @since 9.0.0
	 * @param float  $cart_total Cart total value.
	 * @param string $currency   Currency code.
	 * @return string|null
	 */
	public function wpa_generate_view_cart_script( $cart_total, $currency ) {
		return $this->wpa_lintrk_track_js( false, (float) $cart_total, $currency );
	}

	/**
	 * Generate begin_checkout script.
	 *
	 * @since 9.0.0
	 * @param array  $contents    Formatted cart items.
	 * @param float  $total_value Total cart value.
	 * @param string $currency    Currency code.
	 * @return string|null
	 */
	public function wpa_generate_begin_checkout_script( $contents, $total_value, $currency ) {
		unset( $contents );
		return $this->wpa_lintrk_track_js( false, (float) $total_value, $currency );
	}

	/**
	 * Generate add_payment_info script.
	 *
	 * @since 9.0.0
	 * @param array  $contents    Formatted cart items.
	 * @param float  $total_value Total cart value.
	 * @param string $currency    Currency code.
	 * @return string|null
	 */
	public function wpa_generate_add_payment_info_script( $contents, $total_value, $currency ) {
		unset( $contents );
		return $this->wpa_lintrk_track_js( false, (float) $total_value, $currency );
	}

	/**
	 * Generate purchase script.
	 *
	 * @since 9.0.0
	 * @param WC_Order $order       The WooCommerce order.
	 * @param array    $contents    Formatted order items.
	 * @param float    $total_value Total order value.
	 * @param string   $currency    Currency code.
	 * @return string|null
	 */
	public function wpa_generate_purchase_script( $order, $contents, $total_value, $currency ) {
		unset( $contents, $total_value );
		return $this->wpa_lintrk_track_js( true, (float) $order->get_total(), $currency, (string) $order->get_id() );
	}

	/**
	 * Generate coupon script.
	 *
	 * @since 9.0.0
	 * @param string $action      Either 'applied' or 'removed'.
	 * @param string $coupon_code The coupon code.
	 * @return string|null
	 */
	public function wpa_generate_coupon_script( $action, $coupon_code ) {
		unset( $action, $coupon_code );
		$currency = function_exists( 'wpa_pixels_get_currency' ) ? wpa_pixels_get_currency() : '';
		return $this->wpa_lintrk_track_js( false, 0.0, $currency );
	}

	/**
	 * Generate search script.
	 *
	 * @since 9.0.0
	 * @param string $search_query The search query.
	 * @param string $currency     Currency code.
	 * @return string|null
	 */
	public function wpa_generate_search_script( $search_query, $currency ) {
		unset( $currency, $search_query );
		return $this->wpa_lintrk_track_js( false, null, '' );
	}
}
