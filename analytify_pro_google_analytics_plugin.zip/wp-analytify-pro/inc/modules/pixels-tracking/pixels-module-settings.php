<?php
/**
 * This file is responsible for including settings sections and tabs.
 *
 * @package wp-analytify-pro
 * @since 9.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Add pixels tracking settings tab.
 *
 * @since 9.0.0
 * @param array $tabs Array of existing settings tabs.
 * @return array Modified array of settings tabs.
 */
function analytify_pixels_settings_tab( $tabs ) {

	$pixels_accordions = array(
		array(
			'id'        => 'analytify-meta-pixel',
			'title'     => esc_html__( 'Meta (Facebook) Pixel', 'wp-analytify-pro' ),
			'desc'      => esc_html__( 'Connect Meta (Facebook) Pixel to track conversions, user actions, and ad performance across your website.', 'wp-analytify-pro' ),
			'is_active' => true,
		),
		array(
			'id'        => 'analytify-tiktok-pixel',
			'title'     => esc_html__( 'TikTok Pixel', 'wp-analytify-pro' ),
			'desc'      => esc_html__( 'Track conversions and user behavior from TikTok campaigns with accurate pixel tracking and event measurement.', 'wp-analytify-pro' ),
			'is_active' => true,
		),
		array(
			'id'        => 'analytify-linkedin-pixel',
			'title'     => esc_html__( 'LinkedIn Pixel (Insight Tag)', 'wp-analytify-pro' ),
			'desc'      => esc_html__( 'Measure conversions and audience interactions from LinkedIn ads with precise tracking and performance insights.', 'wp-analytify-pro' ),
			'is_active' => true,
		),
		array(
			'id'        => 'analytify-pinterest-pixel',
			'title'     => esc_html__( 'Pinterest Pixel', 'wp-analytify-pro' ),
			'desc'      => esc_html__( 'Track conversions and optimize Pinterest campaigns with accurate visitor and event tracking.', 'wp-analytify-pro' ),
			'is_active' => true,
		),
		array(
			'id'        => 'analytify-twitter-pixel',
			'title'     => esc_html__( 'X (Twitter) Pixel', 'wp-analytify-pro' ),
			'desc'      => esc_html__( 'Measure conversions and campaign performance from X (Twitter) ads with precise tracking.', 'wp-analytify-pro' ),
			'is_active' => true,
		),
		array(
			'id'        => 'analytify-snapchat-pixel',
			'title'     => esc_html__( 'Snapchat Pixel', 'wp-analytify-pro' ),
			'desc'      => esc_html__( 'Track user actions and conversions from Snapchat ads to improve campaign performance and targeting.', 'wp-analytify-pro' ),
			'is_active' => true,
		),
		array(
			'id'        => 'analytify-microsoft-pixel',
			'title'     => esc_html__( 'Microsoft Ads UET', 'wp-analytify-pro' ),
			'desc'      => esc_html__( 'Track conversions and optimize Microsoft Ads campaigns with reliable pixel tracking.', 'wp-analytify-pro' ),
			'is_active' => true,
		),
	);

	foreach ( $tabs as $index => $tab ) {
		if ( isset( $tab['id'] ) && 'wp-analytify-tracking' === $tab['id'] ) {

			// Initialize accordion if not exists.
			if ( ! isset( $tabs[ $index ]['accordion'] ) || ! is_array( $tabs[ $index ]['accordion'] ) ) {
				$tabs[ $index ]['accordion'] = array();
			}

			// Filter out the old consolidated pixel accordion.
			$tabs[ $index ]['accordion'] = array_filter(
				$tabs[ $index ]['accordion'],
				function ( $acc ) {
					return 'analytify-pixels-tracking' !== $acc['id'];
				}
			);

			// Append new individual pixel accordions.
			$tabs[ $index ]['accordion'] = array_merge( $tabs[ $index ]['accordion'], $pixels_accordions );

			break;
		}
	}

	// Also merge them at the top level so they are registered as settings sections.
	return array_merge( $tabs, $pixels_accordions );
}

// Register individual sections as tabs/options but redirect their storage.
add_filter( 'wp_analytify_pro_setting_tabs', 'analytify_pixels_settings_tab', 20, 1 );

/**
 * Handle individual pixel settings redirection to a single option.
 *
 * @since 9.0.0
 */
function analytify_pixels_hooks_redirection() {
	$pixels = array( 'meta', 'tiktok', 'linkedin', 'pinterest', 'twitter', 'snapchat', 'microsoft' );

	foreach ( $pixels as $pixel ) {
		$option_name = ( 'microsoft' === $pixel ) ? 'analytify-microsoft-pixel' : "analytify-{$pixel}-pixel";

		// Redirect loading.
		add_filter( "option_{$option_name}", 'analytify_pixels_get_redirected_option', 10, 1 );

		// Redirect saving.
		add_filter( "pre_update_option_{$option_name}", 'analytify_pixels_save_redirected_option', 10, 2 );
	}
}
add_action( 'init', 'analytify_pixels_hooks_redirection' );

/**
 * Get pixel settings from the consolidated option.
 *
 * @since 9.0.0
 * @param mixed $value The original value.
 * @return mixed The consolidated value (or original if not found).
 */
function analytify_pixels_get_redirected_option( $value ) {
	$consolidated = get_option( 'analytify-pixels-tracking' );

	if ( is_array( $consolidated ) ) {
		return $consolidated;
	}

	return $value;
}

/**
 * Save pixel settings into the consolidated option.
 *
 * @since 9.0.0
 * @param mixed $new_value The new value to be saved.
 * @param mixed $old_value The old value.
 * @return mixed The old value (to prevent saving to individual option).
 */
function analytify_pixels_save_redirected_option( $new_value, $old_value ) {
	if ( is_array( $new_value ) ) {
		$consolidated = get_option( 'analytify-pixels-tracking' );

		if ( ! is_array( $consolidated ) ) {
			$consolidated = array();
		}

		// Merge new values into consolidated option.
		$consolidated = array_merge( $consolidated, $new_value );
		update_option( 'analytify-pixels-tracking', $consolidated );
	}

	// Return old value to prevent WordPress from updating the individual option.
	return $old_value;
}

/**
 * Add pixels tracking settings fields.
 *
 * @since 9.0.0
 * @param array $fields Array of existing settings fields.
 * @return array Modified array of settings fields.
 */
function analytify_pixels_setting_fields( $fields ) {

	$pro_fields = array();

	// Meta Pixel Fields.
	$pro_fields['analytify-meta-pixel'][] = array(
		'name'              => 'enable_meta_pixel',
		'label'             => esc_html__( 'Enable Meta Pixel', 'wp-analytify-pro' ),
		'desc'              => esc_html__( 'Enable Meta Pixel tracking on your website.', 'wp-analytify-pro' ),
		'type'              => 'checkbox',
		'sanitize_callback' => 'sanitize_text_field',
	);

	$pro_fields['analytify-meta-pixel'][] = array(
		'name'              => 'meta_pixel_id',
		'label'             => esc_html__( 'Meta Pixel ID', 'wp-analytify-pro' ),
		'desc'              => __( 'Enter your Meta Pixel ID (e.g. 123456789012345)<br>Format: Numeric ID (15-16 digits)', 'wp-analytify-pro' ),
		'type'              => 'text',
		'sanitize_callback' => 'wpa_pixels_sanitize_meta_pixel_id',
		'input_format'      => 'digits',
		'maxlength'         => 16,
		'tooltip'           => esc_html__( 'You can find your Pixel ID in Meta Events Manager.', 'wp-analytify-pro' ),
	);

	$pro_fields['analytify-meta-pixel'][] = array(
		'name'  => 'meta_pixel_help',
		'label' => '',
		'type'  => 'html',
		'class' => 'analytify-centered-row',
		'desc'  => '<div class="analytify-help-center-box" style="border: 1px solid #00d084; background-color: #f0fff4; padding: 20px; border-radius: 8px; margin-top: 20px;">
						<h3 style="margin-top: 0; margin-bottom: 10px; color: #333; font-weight: 700; font-size: 16px;">' . esc_html__( 'Help Center:', 'wp-analytify-pro' ) . '</h3>
						<p style="margin-bottom: 10px; color: #555; font-size: 14px;">' . esc_html__( 'Follow our step-by-step guide for Meta Pixel:', 'wp-analytify-pro' ) . '</p>
						<a href="' . esc_url( 'https://analytify.io/doc/set-up-meta-pixel-tracking-on-wordpress/' ) . '" target="_blank" style="color: #00d084; text-decoration: none; font-weight: 700; font-size: 14px; display: inline-flex; align-items: center;">
							' . esc_html__( 'How to integrate Meta Pixel with Analytify Pro', 'wp-analytify-pro' ) . ' <span class="dashicons dashicons-external" style="font-size: 16px; margin-left: 5px; vertical-align: middle;"></span>
						</a>
					</div>',
	);

	// TikTok Pixel Fields.
	$pro_fields['analytify-tiktok-pixel'][] = array(
		'name'              => 'enable_tiktok_pixel',
		'label'             => esc_html__( 'Enable TikTok Pixel', 'wp-analytify-pro' ),
		'desc'              => esc_html__( 'Enable TikTok Pixel tracking on your website.', 'wp-analytify-pro' ),
		'type'              => 'checkbox',
		'sanitize_callback' => 'sanitize_text_field',
	);

	$pro_fields['analytify-tiktok-pixel'][] = array(
		'name'              => 'tiktok_pixel_id',
		'label'             => esc_html__( 'TikTok Pixel ID', 'wp-analytify-pro' ),
		'desc'              => __( 'Enter your TikTok Pixel ID (e.g. C1234567890123456789)<br>Format: Alphanumeric (often starts with C, ~19–20 characters)', 'wp-analytify-pro' ),
		'type'              => 'text',
		'sanitize_callback' => 'wpa_pixels_sanitize_tiktok_pixel_id',
		'input_format'      => 'tiktok',
		'maxlength'         => 25,
		'tooltip'           => esc_html__( 'Find your Pixel ID in TikTok Ads Manager.', 'wp-analytify-pro' ),
	);

	$pro_fields['analytify-tiktok-pixel'][] = array(
		'name'  => 'tiktok_pixel_help',
		'label' => '',
		'type'  => 'html',
		'class' => 'analytify-centered-row',
		'desc'  => '<div class="analytify-help-center-box" style="border: 1px solid #00d084; background-color: #f0fff4; padding: 20px; border-radius: 8px; margin-top: 20px; margin-bottom: 20px;">
						<h3 style="margin-top: 0; margin-bottom: 10px; color: #333; font-weight: 700; font-size: 16px;">' . esc_html__( 'Help Center:', 'wp-analytify-pro' ) . '</h3>
						<p style="margin-bottom: 10px; color: #555; font-size: 14px;">' . esc_html__( 'Follow our step-by-step guide for TikTok Pixel:', 'wp-analytify-pro' ) . '</p>
						<a href="' . esc_url( 'https://analytify.io/doc/set-up-tiktok-pixel-tracking-on-wordpress/' ) . '" target="_blank" style="color: #00d084; text-decoration: none; font-weight: 700; font-size: 14px; display: inline-flex; align-items: center;">
							' . esc_html__( 'How to integrate TikTok Pixel with Analytify Pro', 'wp-analytify-pro' ) . ' <span class="dashicons dashicons-external" style="font-size: 16px; margin-left: 5px; vertical-align: middle;"></span>
						</a>
					</div>',
	);

	// LinkedIn Pixel Fields.
	$pro_fields['analytify-linkedin-pixel'][] = array(
		'name'              => 'enable_linkedin_pixel',
		'label'             => esc_html__( 'Enable LinkedIn Pixel', 'wp-analytify-pro' ),
		'desc'              => esc_html__( 'Enable LinkedIn Pixel tracking on your website.', 'wp-analytify-pro' ),
		'type'              => 'checkbox',
		'sanitize_callback' => 'sanitize_text_field',
	);

	$pro_fields['analytify-linkedin-pixel'][] = array(
		'name'              => 'linkedin_pixel_id',
		'label'             => esc_html__( 'LinkedIn Pixel ID', 'wp-analytify-pro' ),
		'desc'              => __( 'Enter your LinkedIn Insight Tag ID (e.g. 1234567)<br>Format: Numeric ID (length varies, commonly 6–8+ digits)', 'wp-analytify-pro' ),
		'type'              => 'text',
		'sanitize_callback' => 'wpa_pixels_sanitize_linkedin_pixel_id',
		'input_format'      => 'digits',
		'maxlength'         => 20,
		'tooltip'           => esc_html__( 'Find your Insight Tag ID in LinkedIn Campaign Manager.', 'wp-analytify-pro' ),
	);

	$pro_fields['analytify-linkedin-pixel'][] = array(
		'name'  => 'linkedin_pixel_help',
		'label' => '',
		'type'  => 'html',
		'class' => 'analytify-centered-row',
		'desc'  => '<div class="analytify-help-center-box" style="border: 1px solid #00d084; background-color: #f0fff4; padding: 20px; border-radius: 8px; margin-top: 20px; margin-bottom: 20px;">
						<h3 style="margin-top: 0; margin-bottom: 10px; color: #333; font-weight: 700; font-size: 16px;">' . esc_html__( 'Help Center:', 'wp-analytify-pro' ) . '</h3>
						<p style="margin-bottom: 10px; color: #555; font-size: 14px;">' . esc_html__( 'Follow our step-by-step guide for LinkedIn Pixel:', 'wp-analytify-pro' ) . '</p>
						<a href="' . esc_url( 'https://analytify.io/doc/set-up-linkedin-insight-tag-tracking-on-wordpress/' ) . '" target="_blank" style="color: #00d084; text-decoration: none; font-weight: 700; font-size: 14px; display: inline-flex; align-items: center;">
							' . esc_html__( 'How to integrate LinkedIn Pixel with Analytify Pro', 'wp-analytify-pro' ) . ' <span class="dashicons dashicons-external" style="font-size: 16px; margin-left: 5px; vertical-align: middle;"></span>
						</a>
					</div>',
	);

	// Pinterest Pixel Fields.
	$pro_fields['analytify-pinterest-pixel'][] = array(
		'name'              => 'enable_pinterest_pixel',
		'label'             => esc_html__( 'Enable Pinterest Pixel', 'wp-analytify-pro' ),
		'desc'              => esc_html__( 'Enable Pinterest Pixel tracking on your website.', 'wp-analytify-pro' ),
		'type'              => 'checkbox',
		'sanitize_callback' => 'sanitize_text_field',
	);

	$pro_fields['analytify-pinterest-pixel'][] = array(
		'name'              => 'pinterest_pixel_id',
		'label'             => esc_html__( 'Pinterest Pixel ID', 'wp-analytify-pro' ),
		'desc'              => __( 'Enter your Pinterest Pixel ID (e.g. 261234567890123)<br>Format: Numeric ID (length varies, commonly 15–17 digits)', 'wp-analytify-pro' ),
		'type'              => 'text',
		'sanitize_callback' => 'wpa_pixels_sanitize_pinterest_pixel_id',
		'input_format'      => 'digits',
		'maxlength'         => 20,
		'tooltip'           => esc_html__( 'Find your Pixel ID in Pinterest Ads Manager.', 'wp-analytify-pro' ),
	);

	$pro_fields['analytify-pinterest-pixel'][] = array(
		'name'  => 'pinterest_pixel_help',
		'label' => '',
		'type'  => 'html',
		'class' => 'analytify-centered-row',
		'desc'  => '<div class="analytify-help-center-box" style="border: 1px solid #00d084; background-color: #f0fff4; padding: 20px; border-radius: 8px; margin-top: 20px; margin-bottom: 20px;">
						<h3 style="margin-top: 0; margin-bottom: 10px; color: #333; font-weight: 700; font-size: 16px;">' . esc_html__( 'Help Center:', 'wp-analytify-pro' ) . '</h3>
						<p style="margin-bottom: 10px; color: #555; font-size: 14px;">' . esc_html__( 'Follow our step-by-step guide for Pinterest Pixel:', 'wp-analytify-pro' ) . '</p>
						<a href="' . esc_url( 'https://analytify.io/doc/set-up-pinterest-pixel-tracking-on-wordpress/' ) . '" target="_blank" style="color: #00d084; text-decoration: none; font-weight: 700; font-size: 14px; display: inline-flex; align-items: center;">
							' . esc_html__( 'How to integrate Pinterest Pixel with Analytify Pro', 'wp-analytify-pro' ) . ' <span class="dashicons dashicons-external" style="font-size: 16px; margin-left: 5px; vertical-align: middle;"></span>
						</a>
					</div>',
	);

	// Twitter Pixel Fields.
	$pro_fields['analytify-twitter-pixel'][] = array(
		'name'              => 'enable_twitter_pixel',
		'label'             => esc_html__( 'Enable X (Twitter) Pixel', 'wp-analytify-pro' ),
		'desc'              => esc_html__( 'Enable X (Twitter) Pixel tracking on your website.', 'wp-analytify-pro' ),
		'type'              => 'checkbox',
		'sanitize_callback' => 'sanitize_text_field',
	);

	$pro_fields['analytify-twitter-pixel'][] = array(
		'name'              => 'twitter_pixel_id',
		'label'             => esc_html__( 'X (Twitter) Pixel ID', 'wp-analytify-pro' ),
		'desc'              => __( 'Enter your X Pixel ID (e.g. o123abcde)<br>Format: Alphanumeric short code (5–20 characters)', 'wp-analytify-pro' ),
		'type'              => 'text',
		'sanitize_callback' => 'wpa_pixels_sanitize_twitter_pixel_id',
		'input_format'      => 'alphanumeric',
		'maxlength'         => 20,
		'tooltip'           => esc_html__( 'Find your Pixel ID in X Ads Manager.', 'wp-analytify-pro' ),
	);

	$pro_fields['analytify-twitter-pixel'][] = array(
		'name'  => 'twitter_pixel_help',
		'label' => '',
		'type'  => 'html',
		'class' => 'analytify-centered-row',
		'desc'  => '<div class="analytify-help-center-box" style="border: 1px solid #00d084; background-color: #f0fff4; padding: 20px; border-radius: 8px; margin-top: 20px; margin-bottom: 20px;">
						<h3 style="margin-top: 0; margin-bottom: 10px; color: #333; font-weight: 700; font-size: 16px;">' . esc_html__( 'Help Center:', 'wp-analytify-pro' ) . '</h3>
						<p style="margin-bottom: 10px; color: #555; font-size: 14px;">' . esc_html__( 'Follow our step-by-step guide for Twitter(X) Pixel:', 'wp-analytify-pro' ) . '</p>
						<a href="' . esc_url( 'https://analytify.io/doc/set-up-x-pixel-tracking-on-wordpress/' ) . '" target="_blank" style="color: #00d084; text-decoration: none; font-weight: 700; font-size: 14px; display: inline-flex; align-items: center;">
							' . esc_html__( 'How to integrate Twitter(X) Pixel with Analytify Pro', 'wp-analytify-pro' ) . ' <span class="dashicons dashicons-external" style="font-size: 16px; margin-left: 5px; vertical-align: middle;"></span>
						</a>
					</div>',
	);

	// Snapchat Pixel Fields.
	$pro_fields['analytify-snapchat-pixel'][] = array(
		'name'              => 'enable_snapchat_pixel',
		'label'             => esc_html__( 'Enable Snapchat Pixel', 'wp-analytify-pro' ),
		'desc'              => esc_html__( 'Enable Snapchat Pixel tracking on your website.', 'wp-analytify-pro' ),
		'type'              => 'checkbox',
		'sanitize_callback' => 'sanitize_text_field',
	);

	$pro_fields['analytify-snapchat-pixel'][] = array(
		'name'              => 'snapchat_pixel_id',
		'label'             => esc_html__( 'Snapchat Pixel ID', 'wp-analytify-pro' ),
		'desc'              => __( 'Enter your Snapchat Pixel ID (e.g. abcdef12-3456-7890-abcd-ef1234567890)<br>Format: UUID format (36 characters, alphanumeric with hyphens)', 'wp-analytify-pro' ),
		'type'              => 'text',
		'sanitize_callback' => 'wpa_pixels_sanitize_snapchat_pixel_id',
		'input_format'      => 'uuid',
		'maxlength'         => 36,
		'tooltip'           => esc_html__( 'Find your Pixel ID in Snapchat Ads Manager.', 'wp-analytify-pro' ),
	);

	$pro_fields['analytify-snapchat-pixel'][] = array(
		'name'  => 'snapchat_pixel_help',
		'label' => '',
		'type'  => 'html',
		'class' => 'analytify-centered-row',
		'desc'  => '<div class="analytify-help-center-box" style="border: 1px solid #00d084; background-color: #f0fff4; padding: 20px; border-radius: 8px; margin-top: 20px; margin-bottom: 20px;">
						<h3 style="margin-top: 0; margin-bottom: 10px; color: #333; font-weight: 700; font-size: 16px;">' . esc_html__( 'Help Center:', 'wp-analytify-pro' ) . '</h3>
						<p style="margin-bottom: 10px; color: #555; font-size: 14px;">' . esc_html__( 'Follow our step-by-step guide for Snapchat Pixel:', 'wp-analytify-pro' ) . '</p>
						<a href="' . esc_url( 'https://analytify.io/doc/set-up-snapchat-pixel-tracking-on-wordpress/' ) . '" target="_blank" style="color: #00d084; text-decoration: none; font-weight: 700; font-size: 14px; display: inline-flex; align-items: center;">
							' . esc_html__( 'How to integrate Snapchat Pixel with Analytify Pro', 'wp-analytify-pro' ) . ' <span class="dashicons dashicons-external" style="font-size: 16px; margin-left: 5px; vertical-align: middle;"></span>
						</a>
					</div>',
	);

	// Microsoft Ads UET Fields.
	$pro_fields['analytify-microsoft-pixel'][] = array(
		'name'              => 'enable_microsoft_uet',
		'label'             => esc_html__( 'Enable Microsoft Pixel', 'wp-analytify-pro' ),
		'desc'              => esc_html__( 'Enable Microsoft Ads UET tracking on your website.', 'wp-analytify-pro' ),
		'type'              => 'checkbox',
		'sanitize_callback' => 'sanitize_text_field',
	);

	$pro_fields['analytify-microsoft-pixel'][] = array(
		'name'              => 'microsoft_uet_id',
		'label'             => esc_html__( 'Microsoft UET Tag ID', 'wp-analytify-pro' ),
		'desc'              => __( 'Enter your Microsoft UET Tag ID (e.g. 12345678)<br>Format: Numeric ID (commonly 8–9 digits, up to 20)', 'wp-analytify-pro' ),
		'type'              => 'text',
		'sanitize_callback' => 'wpa_pixels_sanitize_microsoft_uet_id',
		'input_format'      => 'digits',
		'maxlength'         => 20,
		'tooltip'           => esc_html__( 'Find your UET Tag ID in Microsoft Ads.', 'wp-analytify-pro' ),
	);

	$pro_fields['analytify-microsoft-pixel'][] = array(
		'name'  => 'microsoft_pixel_help',
		'label' => '',
		'type'  => 'html',
		'class' => 'analytify-centered-row',
		'desc'  => '<div class="analytify-help-center-box" style="border: 1px solid #00d084; background-color: #f0fff4; padding: 20px; border-radius: 8px; margin-top: 20px; margin-bottom: 20px;">
						<h3 style="margin-top: 0; margin-bottom: 10px; color: #333; font-weight: 700; font-size: 16px;">' . esc_html__( 'Help Center:', 'wp-analytify-pro' ) . '</h3>
						<p style="margin-bottom: 10px; color: #555; font-size: 14px;">' . esc_html__( 'Follow our step-by-step guide for Microsoft Ads UET:', 'wp-analytify-pro' ) . '</p>
						<a href="' . esc_url( 'https://analytify.io/doc/set-up-microsoft-pixel-tracking-on-wordpress/' ) . '" target="_blank" style="color: #00d084; text-decoration: none; font-weight: 700; font-size: 14px; display: inline-flex; align-items: center;">
							' . esc_html__( 'How to integrate Microsoft Ads UET with Analytify Pro', 'wp-analytify-pro' ) . ' <span class="dashicons dashicons-external" style="font-size: 16px; margin-left: 5px; vertical-align: middle;"></span>
						</a>
					</div>',
	);

	return array_merge( $fields, $pro_fields );
}

/**
 * Strip characters that are not allowed for a pixel ID input format.
 *
 * @param string $value  Submitted value.
 * @param string $format Input format key (digits, alphanumeric, tiktok, uuid).
 * @return string
 */
function wpa_pixels_strip_pixel_value( $value, $format ) {
	switch ( $format ) {
		case 'digits':
			return preg_replace( '/\D/', '', $value );
		case 'alphanumeric':
			return preg_replace( '/[^A-Za-z0-9]/', '', $value );
		case 'tiktok':
			return preg_replace( '/[^A-Za-z0-9-]/i', '', $value );
		case 'uuid':
			return preg_replace( '/[^0-9a-f-]/i', '', $value );
		default:
			return $value;
	}
}

/**
 * Validate a pixel ID field; keep the saved value when input is invalid.
 *
 * @param mixed  $value      Submitted value.
 * @param string $option_key Option key in analytify-pixels-tracking.
 * @param string $pattern    Regex the ID must match.
 * @param string $format     Input format used to strip invalid characters.
 * @return string
 */
function wpa_pixels_sanitize_pixel_field( $value, $option_key, $pattern, $format = '' ) {
	$value = trim( sanitize_text_field( wp_unslash( (string) $value ) ) );

	if ( '' !== $format ) {
		$value = wpa_pixels_strip_pixel_value( $value, $format );
	}

	if ( '' === $value || preg_match( $pattern, $value ) ) {
		return $value;
	}

	add_settings_error(
		'analytify-pixels-tracking',
		'invalid_' . $option_key,
		esc_html__( 'Invalid Pixel ID.', 'wp-analytify-pro' ),
		'error'
	);

	$options = get_option( 'analytify-pixels-tracking', array() );

	return ( is_array( $options ) && isset( $options[ $option_key ] ) )
		? (string) $options[ $option_key ]
		: '';
}

/**
 * Sanitize Meta (Facebook) pixel ID.
 *
 * @param mixed $value Submitted value.
 * @return string
 */
function wpa_pixels_sanitize_meta_pixel_id( $value ) {
	return wpa_pixels_sanitize_pixel_field( $value, 'meta_pixel_id', '/^\d{15,16}$/', 'digits' );
}

/**
 * Sanitize TikTok pixel ID.
 *
 * @param mixed $value Submitted value.
 * @return string
 */
function wpa_pixels_sanitize_tiktok_pixel_id( $value ) {
	return wpa_pixels_sanitize_pixel_field( $value, 'tiktok_pixel_id', '/^[A-Z0-9-]{10,25}$/i', 'tiktok' );
}

/**
 * Sanitize LinkedIn pixel ID.
 *
 * @param mixed $value Submitted value.
 * @return string
 */
function wpa_pixels_sanitize_linkedin_pixel_id( $value ) {
	return wpa_pixels_sanitize_pixel_field( $value, 'linkedin_pixel_id', '/^\d{1,20}$/', 'digits' );
}

/**
 * Sanitize Pinterest pixel ID.
 *
 * @param mixed $value Submitted value.
 * @return string
 */
function wpa_pixels_sanitize_pinterest_pixel_id( $value ) {
	return wpa_pixels_sanitize_pixel_field( $value, 'pinterest_pixel_id', '/^\d{1,20}$/', 'digits' );
}

/**
 * Sanitize Twitter/X pixel ID.
 *
 * @param mixed $value Submitted value.
 * @return string
 */
function wpa_pixels_sanitize_twitter_pixel_id( $value ) {
	return wpa_pixels_sanitize_pixel_field( $value, 'twitter_pixel_id', '/^[A-Za-z0-9]{5,20}$/', 'alphanumeric' );
}

/**
 * Sanitize Snapchat pixel ID.
 *
 * @param mixed $value Submitted value.
 * @return string
 */
function wpa_pixels_sanitize_snapchat_pixel_id( $value ) {
	return wpa_pixels_sanitize_pixel_field( $value, 'snapchat_pixel_id', '/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i', 'uuid' );
}

/**
 * Sanitize Microsoft UET tag ID.
 *
 * @param mixed $value Submitted value.
 * @return string
 */
function wpa_pixels_sanitize_microsoft_uet_id( $value ) {
	return wpa_pixels_sanitize_pixel_field( $value, 'microsoft_uet_id', '/^\d{1,20}$/', 'digits' );
}

/**
 * Enqueue pixel settings input validation as inline script on settings page.
 *
 * @param string $hook_suffix Current admin page hook.
 * @return void
 */
function wpa_pixels_enqueue_settings_scripts( $hook_suffix ) {
	if ( 'analytify_page_analytify-settings' !== $hook_suffix ) {
		return;
	}

	$inline_js = <<<'JS'
jQuery( function ( $ ) {
	var formatFilters = {
		digits: function ( value ) {
			return value.replace( /\D/g, '' );
		},
		alphanumeric: function ( value ) {
			return value.replace( /[^A-Za-z0-9]/g, '' );
		},
		tiktok: function ( value ) {
			return value.replace( /[^A-Za-z0-9-]/gi, '' );
		},
		uuid: function ( value ) {
			return value.replace( /[^0-9a-f-]/gi, '' );
		},
	};

	function filterPixelInput( $input ) {
		var format = $input.data( 'input-format' );
		var filter = formatFilters[ format ];

		if ( ! filter ) {
			return;
		}

		var value = filter( $input.val() );
		var maxLength = parseInt( $input.attr( 'maxlength' ), 10 );

		if ( maxLength && value.length > maxLength ) {
			value = value.slice( 0, maxLength );
		}

		if ( value !== $input.val() ) {
			$input.val( value );
		}
	}

	$( document ).on( 'input', 'input[data-input-format]', function () {
		filterPixelInput( $( this ) );
	} );

	$( 'input[data-input-format]' ).each( function () {
		filterPixelInput( $( this ) );
	} );
} );
JS;

	wp_add_inline_script( 'analytify-settings-js', $inline_js );
}
add_action( 'admin_enqueue_scripts', 'wpa_pixels_enqueue_settings_scripts' );

add_filter( 'wp_analytify_pro_setting_fields', 'analytify_pixels_setting_fields', 20, 1 );
