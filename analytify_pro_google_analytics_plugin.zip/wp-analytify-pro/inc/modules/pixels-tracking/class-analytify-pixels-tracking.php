<?php
/**
 * This file is responsible for initializing pixels tracking.
 *
 * @package wp-analytify-pro
 * @since 9.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Analytify Pixels Tracking Class.
 *
 * Handles tracking integration with various pixel services including Meta (Facebook),
 * TikTok, LinkedIn, Pinterest, Twitter(X), Snapchat, and Microsoft UET.
 *
 * @since 9.0.0
 * @package wp-analytify-pro
 */
class Analytify_Pixels_Tracking {

	/**
	 * Pixel configurations indexed by pixel key.
	 * Each entry: array( 'enabled' => bool, 'id' => string|false ).
	 *
	 * @var array
	 */
	private $pixels = array();

	/**
	 * Product lists for listing page tracking, indexed by pixel key.
	 *
	 * @var array
	 */
	private $product_lists = array();

	/**
	 * List of all supported pixel keys.
	 *
	 * @var array
	 */
	private $pixel_keys = array( 'meta', 'tiktok', 'snapchat', 'microsoft', 'twitter', 'linkedin', 'pinterest' );

	/**
	 * Instances of pixel platform classes.
	 *
	 * @var array
	 */
	private $platforms = array();

	/**
	 * Pixel keys for which view_list was already output from the shop loop (avoids duplicate footer fallback).
	 *
	 * @var array<string, bool>
	 */
	private $wpa_view_list_enqueued = array();

	/**
	 * Single instance of the class.
	 *
	 * @var null|Analytify_Pixels_Tracking The Single object of this class.
	 */
	public static $instance = null;

	/**
	 * Analytify_Pixels_Tracking class constructor.
	 *
	 * @since 9.0.0
	 */
	public function __construct() {
		$this->wpa_analytify_includes();
		$this->wpa_analytify_set_addon_option_values();
		$this->wpa_analytify_hooks();
	}

	/**
	 * Return the single instance of the class.
	 *
	 * @since 9.0.0
	 * @return Analytify_Pixels_Tracking The single instance of the class.
	 */
	public static function get_instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Set the option values saved for the module in class properties.
	 *
	 * @since 9.0.0
	 * @return void
	 */
	public function wpa_analytify_set_addon_option_values() {
		$all_options = get_option( 'analytify-pixels-tracking' );

		if ( ! is_array( $all_options ) ) {
			$all_options = array();
		}

		// Map option keys to pixel keys.
		$option_map = array(
			'meta'      => array(
				'enable' => 'enable_meta_pixel',
				'id'     => 'meta_pixel_id',
			),
			'tiktok'    => array(
				'enable' => 'enable_tiktok_pixel',
				'id'     => 'tiktok_pixel_id',
			),
			'linkedin'  => array(
				'enable' => 'enable_linkedin_pixel',
				'id'     => 'linkedin_pixel_id',
			),
			'pinterest' => array(
				'enable' => 'enable_pinterest_pixel',
				'id'     => 'pinterest_pixel_id',
			),
			'twitter'   => array(
				'enable' => 'enable_twitter_pixel',
				'id'     => 'twitter_pixel_id',
			),
			'snapchat'  => array(
				'enable' => 'enable_snapchat_pixel',
				'id'     => 'snapchat_pixel_id',
			),
			'microsoft' => array(
				'enable' => 'enable_microsoft_uet',
				'id'     => 'microsoft_uet_id',
			),
		);

		foreach ( $option_map as $key => $opt ) {
			$this->pixels[ $key ] = array(
				'enabled' => isset( $all_options[ $opt['enable'] ] ) && 'on' === $all_options[ $opt['enable'] ],
				'id'      => isset( $all_options[ $opt['id'] ] ) ? $all_options[ $opt['id'] ] : false,
			);
		}

		// Map pixel keys to platform class names for clarity and future integrations (e.g. EDD).
		$platform_class_map = array(
			'meta'      => 'Analytify_Pixel_Meta',
			'tiktok'    => 'Analytify_Pixel_TikTok',
			'linkedin'  => 'Analytify_Pixel_LinkedIn',
			'pinterest' => 'Analytify_Pixel_Pinterest',
			'twitter'   => 'Analytify_Pixel_Twitter',
			'snapchat'  => 'Analytify_Pixel_Snapchat',
			'microsoft' => 'Analytify_Pixel_Microsoft',
		);

		// Initialize product lists and platform instances.
		foreach ( $this->pixel_keys as $key ) {
			if ( ! isset( $this->product_lists[ $key ] ) ) {
				$this->product_lists[ $key ] = array();
			}

			if ( $this->wpa_analytify_is_pixel_active( $key ) && ! isset( $this->platforms[ $key ] ) ) {
				$class_name = isset( $platform_class_map[ $key ] ) ? $platform_class_map[ $key ] : 'Analytify_Pixel_' . ucfirst( $key );
				if ( class_exists( $class_name ) ) {
					$this->platforms[ $key ] = new $class_name( $this->wpa_analytify_get_pixel_id( $key ) );
				}
			}
		}
	}

	/**
	 * Check if a specific pixel is active (enabled and has an ID).
	 *
	 * @since 9.0.0
	 * @param string $pixel_key The pixel key.
	 * @return bool
	 */
	private function wpa_analytify_is_pixel_active( $pixel_key ) {
		return isset( $this->pixels[ $pixel_key ] )
			&& $this->pixels[ $pixel_key ]['enabled']
			&& ! empty( $this->pixels[ $pixel_key ]['id'] );
	}

	/**
	 * Get the pixel ID for a specific pixel.
	 *
	 * @since 9.0.0
	 * @param string $pixel_key The pixel key.
	 * @return string|false
	 */
	private function wpa_analytify_get_pixel_id( $pixel_key ) {
		return isset( $this->pixels[ $pixel_key ] ) ? $this->pixels[ $pixel_key ]['id'] : false;
	}

	/**
	 * Check if any pixel is enabled.
	 *
	 * @since 9.0.0
	 * @return bool
	 */
	private function wpa_analytify_has_any_enabled_pixel() {
		foreach ( $this->pixel_keys as $key ) {
			if ( $this->wpa_analytify_is_pixel_active( $key ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Includes the required files for the module.
	 *
	 * @since 9.0.0
	 * @return void
	 */
	public function wpa_analytify_includes() {
		// Including pixels module utilities.
		require_once __DIR__ . '/pixels-tracking-utils.php';

		// Including pixels module settings.
		require_once ANALYTIFY_PRO_ROOT_PATH . '/inc/modules/pixels-tracking/pixels-module-settings.php';

		// Include platform classes.
		require_once __DIR__ . '/platforms/class-analytify-pixel-platform.php';
		foreach ( $this->pixel_keys as $key ) {
			$file = __DIR__ . "/platforms/class-analytify-pixel-{$key}.php";
			if ( file_exists( $file ) ) {
				require_once $file;
			}
		}
	}

	/**
	 * Add pixels tracking hooks.
	 *
	 * @since 9.0.0
	 * @return void
	 */
	public function wpa_analytify_hooks() {
		add_action( 'wp_head', array( $this, 'wpa_analytify_inject_tracking_scripts' ), 1 );

		// Add WooCommerce tracking hooks after WordPress is fully loaded.
		add_action( 'wp_loaded', array( $this, 'wpa_analytify_maybe_add_woocommerce_hooks' ) );
	}

	/**
	 * Inject tracking scripts in head.
	 *
	 * @since 9.0.0
	 * @return void
	 */
	public function wpa_analytify_inject_tracking_scripts() {
		// Don't inject scripts in admin area.
		if ( is_admin() ) {
			return;
		}

		// Ensure platforms are initialized.
		$this->wpa_analytify_set_addon_option_values();

		foreach ( $this->platforms as $platform ) {
			$platform->wpa_inject_base_script();
		}
	}

	/**
	 * Maybe add WooCommerce Pixel tracking hooks.
	 *
	 * @since 9.0.0
	 * @return void
	 */
	public function wpa_analytify_maybe_add_woocommerce_hooks() {
		// Refresh settings to get latest values.
		$this->wpa_analytify_set_addon_option_values();

		if ( ! class_exists( 'WooCommerce' ) || ! $this->wpa_analytify_has_any_enabled_pixel() ) {
			return;
		}

		$this->wpa_analytify_add_woocommerce_hooks();
	}

	/**
	 * Register and enqueue the script handle for pixel event inline scripts (footer, no jQuery dependency).
	 *
	 * @since 9.0.0
	 * @return void
	 */
	public function wpa_analytify_register_pixel_events_handle() {
		$this->wpa_analytify_set_addon_option_values();
		if ( ! $this->wpa_analytify_has_any_enabled_pixel() ) {
			return;
		}
		$handle  = 'analytify-pixels-events';
		$version = defined( 'ANALYTIFY_PRO_VERSION' ) ? ANALYTIFY_PRO_VERSION : null;
		if ( ! wp_script_is( $handle, 'registered' ) ) {
			wp_register_script( $handle, false, array(), $version, true );
		}
		wp_enqueue_script( $handle );
	}

	/**
	 * Register WooCommerce pixel hooks (shop loop, coupons, footer pixels, Pinterest loop attributes).
	 *
	 * @since 9.0.0
	 * @return void
	 */
	private function wpa_analytify_add_woocommerce_hooks() {
		add_action( 'wp_enqueue_scripts', array( $this, 'wpa_analytify_register_pixel_events_handle' ), 1 );

		$hooks = array(
			'woocommerce_before_shop_loop_item' => 'wpa_analytify_feed_item_data',
			'woocommerce_after_shop_loop'       => 'wpa_analytify_view_item_list',
			'woocommerce_applied_coupon'        => 'wpa_analytify_apply_coupon',
			'woocommerce_removed_coupon'        => 'wpa_analytify_remove_coupon',
		);

		foreach ( $hooks as $hook => $method ) {
			add_action( $hook, array( $this, $method ) );
		}

		if ( $this->wpa_analytify_is_pixel_active( 'pinterest' ) ) {
			add_filter( 'woocommerce_loop_add_to_cart_args', array( $this, 'wpa_analytify_loop_add_to_cart_category_data_attr' ), 20, 2 );
		}

		add_action( 'wp_footer', array( $this, 'wpa_analytify_search' ) );
		add_action( 'wp_footer', array( $this, 'wpa_analytify_footer_pixels' ), 5 );
	}

	/**
	 * Formatted product rows for view_list when the classic shop loop hook did not run (e.g. block shop).
	 *
	 * @since 9.0.0
	 * @param string $pixel_key Platform key.
	 * @return array
	 */
	private function wpa_analytify_build_archive_line_items( $pixel_key ) {
		if ( ! isset( $this->platforms[ $pixel_key ] ) ) {
			return array();
		}
		$platform = $this->platforms[ $pixel_key ];
		global $wp_query;
		$items = array();
		foreach ( (array) $wp_query->posts as $post ) {
			if ( ! isset( $post->post_type ) || 'product' !== $post->post_type ) {
				continue;
			}
			$items[] = $platform->wpa_format_item( $this->wpa_analytify_get_product_data( (int) $post->ID ) );
			if ( count( $items ) >= 40 ) {
				break;
			}
		}
		return $items;
	}

	/**
	 * Expose primary product category on loop add-to-cart for Pinterest AddToCart line_items.
	 *
	 * @since 9.0.0
	 * @param array      $args    Add-to-cart link args.
	 * @param WC_Product $product Product object.
	 * @return array
	 */
	public function wpa_analytify_loop_add_to_cart_category_data_attr( $args, $product ) {
		if ( ! is_a( $product, 'WC_Product' ) ) {
			return $args;
		}
		$terms = get_the_terms( $product->get_id(), 'product_cat' );
		$cat   = '';
		if ( is_array( $terms ) && ! empty( $terms ) ) {
			$cat = sanitize_text_field( $terms[0]->name );
		}
		if ( ! isset( $args['attributes'] ) || ! is_array( $args['attributes'] ) ) {
			$args['attributes'] = array();
		}
		$args['attributes']['data-product_category'] = esc_attr( $cat );
		return $args;
	}

	/**
	 * Product, cart, checkout, add-to-cart, and purchase pixels (classic hooks often absent with blocks).
	 *
	 * @since 9.0.0
	 * @return void
	 */
	public function wpa_analytify_footer_pixels() {
		if ( is_admin() || ! class_exists( 'WooCommerce' ) ) {
			return;
		}

		$this->wpa_analytify_set_addon_option_values();
		if ( ! $this->wpa_analytify_has_any_enabled_pixel() ) {
			return;
		}

		$this->wpa_analytify_register_pixel_events_handle();

		$currency = wpa_pixels_get_currency();

		if ( is_product() ) {
			$product = wc_get_product( get_queried_object_id() );
			if ( $product ) {
				$pd = $this->wpa_analytify_get_product_data( $product->get_id() );
				$this->wpa_analytify_execute_pixel_event( 'view_item', array( $pd, $currency ) );
				$this->wpa_analytify_execute_pixel_event( 'add_to_cart', array( $pd, $currency ) );
			}
		} elseif ( is_shop() || is_product_category() || is_product_tag() || is_product_taxonomy() ) {
			foreach ( $this->platforms as $platform ) {
				if ( ! method_exists( $platform, 'wpa_generate_add_to_cart_loop_script' ) ) {
					continue;
				}
				$script = call_user_func( array( $platform, 'wpa_generate_add_to_cart_loop_script' ), $currency );
				if ( $script ) {
					wp_add_inline_script( 'analytify-pixels-events', $script );
				}
			}
			foreach ( $this->platforms as $pixel_key => $platform ) {
				if ( ! empty( $this->wpa_view_list_enqueued[ $pixel_key ] ) ) {
					continue;
				}
				if ( ! method_exists( $platform, 'wpa_generate_view_list_script' ) ) {
					continue;
				}
				$plist = $this->wpa_analytify_build_archive_line_items( $pixel_key );
				if ( empty( $plist ) ) {
					continue;
				}
				$vs = $platform->wpa_generate_view_list_script( $plist );
				if ( $vs ) {
					wp_add_inline_script( 'analytify-pixels-events', $vs );
				}
			}
		}

		if ( is_cart() ) {
			if ( WC()->cart && ! WC()->cart->is_empty() ) {
				$this->wpa_analytify_execute_pixel_event( 'view_cart', array( WC()->cart->get_cart_contents_total(), $currency ) );
			}
			$this->wpa_analytify_execute_pixel_event( 'remove_from_cart', array( $currency ) );
		}

		if ( is_checkout() && ! is_order_received_page() ) {
			$this->wpa_analytify_enqueue_checkout_events();
		}

		if ( is_order_received_page() ) {
			global $wp;
			$order_id = absint( get_query_var( 'order-received' ) );
			if ( ! $order_id && isset( $wp->query_vars['order-received'] ) ) {
				$order_id = absint( $wp->query_vars['order-received'] );
			}
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$order_key = isset( $_GET['key'] ) ? wc_clean( sanitize_text_field( wp_unslash( $_GET['key'] ) ) ) : '';
			$order     = $order_id ? wc_get_order( $order_id ) : false;
			$key_ok    = ( $order && $order_key && hash_equals( $order->get_order_key(), $order_key ) );
			$user_ok   = ( $order && is_user_logged_in() && get_current_user_id() > 0 && (int) $order->get_customer_id() === get_current_user_id() );
			if ( $order && is_a( $order, 'WC_Order' ) && ( $key_ok || $user_ok ) ) {
				$this->wpa_analytify_enqueue_purchase( $order_id );
			}
		}
	}

	/**
	 * InitiateCheckout + AddPaymentInfo for each platform.
	 *
	 * @since 9.0.0
	 * @return void
	 */
	private function wpa_analytify_enqueue_checkout_events() {
		if ( ! WC()->cart ) {
			return;
		}
		$cart     = WC()->cart->get_cart();
		$currency = wpa_pixels_get_currency();
		foreach ( $this->platforms as $pixel_key => $platform ) {
			$data = $this->wpa_analytify_get_formatted_items( $pixel_key, $cart );
			$s    = $platform->wpa_generate_begin_checkout_script( $data['contents'], $data['total_value'], $currency );
			if ( $s ) {
				wp_add_inline_script( 'analytify-pixels-events', $s );
			}
			$s2 = $platform->wpa_generate_add_payment_info_script( $data['contents'], $data['total_value'], $currency );
			if ( $s2 ) {
				wp_add_inline_script( 'analytify-pixels-events', $s2 );
			}
		}
	}

	/**
	 * Purchase pixel on order-received.
	 *
	 * @since 9.0.0
	 * @param int $order_id Order ID.
	 * @return void
	 */
	private function wpa_analytify_enqueue_purchase( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return;
		}
		$currency = $order->get_currency();
		foreach ( $this->platforms as $pixel_key => $platform ) {
			$data   = $this->wpa_analytify_get_formatted_items( $pixel_key, $order->get_items(), true );
			$script = $platform->wpa_generate_purchase_script( $order, $data['contents'], $data['total_value'], $currency );
			if ( $script ) {
				wp_add_inline_script( 'analytify-pixels-events', $script );
			}
		}
	}

	/**
	 * Resolve a positive unit price for a WooCommerce product (handles empty get_price(), sale, meta fallbacks).
	 *
	 * @since 9.0.0
	 * @param WC_Product|null $product Product object.
	 * @return float Unit price, or 0 if unavailable.
	 */
	private function wpa_analytify_resolve_product_unit_price( $product ) {
		if ( ! is_a( $product, 'WC_Product' ) ) {
			return 0.0;
		}

		$candidates = array(
			$product->get_price( 'edit' ),
			$product->get_price(),
			$product->get_sale_price( 'edit' ),
			$product->get_regular_price( 'edit' ),
		);

		foreach ( $candidates as $raw ) {
			if ( null === $raw || false === $raw || '' === $raw ) {
				continue;
			}
			$decimal = function_exists( 'wc_format_decimal' ) ? wc_format_decimal( $raw ) : $raw;
			$float   = (float) $decimal;
			if ( $float > 0 ) {
				return $float;
			}
		}

		$pid = $product->get_id();
		foreach ( array( '_price', '_sale_price', '_regular_price' ) as $meta_key ) {
			$raw = get_post_meta( $pid, $meta_key, true );
			if ( '' === $raw || null === $raw ) {
				continue;
			}
			$decimal = function_exists( 'wc_format_decimal' ) ? wc_format_decimal( $raw ) : $raw;
			$float   = (float) $decimal;
			if ( $float > 0 ) {
				return $float;
			}
		}

		if ( function_exists( 'wc_get_price_to_display' ) ) {
			$display = (float) wc_get_price_to_display( $product, array( 'qty' => 1 ) );
			if ( $display > 0 ) {
				return $display;
			}
		}

		return 0.0;
	}

	/**
	 * Get standardized product data for tracking.
	 *
	 * @since 9.0.0
	 * @param int      $product_id   The product ID.
	 * @param int|null $variation_id The variation ID.
	 * @param int      $quantity     The quantity.
	 * @param float    $price        The price override.
	 * @return array Standardized product data.
	 */
	private function wpa_analytify_get_product_data( $product_id, $variation_id = null, $quantity = 1, $price = null ) {
		$product = wc_get_product( $variation_id ? $variation_id : $product_id );

		$price_missing = ( null === $price || '' === $price || false === $price );

		if ( is_object( $product ) && $price_missing ) {
			$price = $this->wpa_analytify_resolve_product_unit_price( $product );
		} elseif ( $price_missing ) {
			$price = (float) get_post_meta( $product_id, '_price', true );
			if ( $price <= 0 ) {
				$price = (float) get_post_meta( $product_id, '_regular_price', true );
			}
		} else {
			$price = function_exists( 'wc_format_decimal' ) ? (float) wc_format_decimal( $price ) : (float) $price;
		}

		$categories     = get_the_terms( $product_id, 'product_cat' );
		$category_names = is_array( $categories ) ? wp_list_pluck( $categories, 'name' ) : array();

		return array(
			'id'          => (string) $product_id,
			'name'        => sanitize_text_field( get_the_title( $product_id ) ),
			'category'    => sanitize_text_field( reset( $category_names ) ),
			'price'       => $price,
			'quantity'    => (int) $quantity,
			'value'       => $price * $quantity,
			'description' => sanitize_text_field( get_post_field( 'post_excerpt', $product_id ) ),
		);
	}

	/**
	 * DRY helper to get formatted items and total value for a pixel.
	 *
	 * @since 9.0.0
	 * @param string $pixel_key The pixel key.
	 * @param array  $items     The items (cart contents or order items).
	 * @param bool   $is_order  Whether the items are from an order.
	 * @return array Formatted items and total value.
	 */
	private function wpa_analytify_get_formatted_items( $pixel_key, $items, $is_order = false ) {
		$contents    = array();
		$total_value = 0;
		$platform    = isset( $this->platforms[ $pixel_key ] ) ? $this->platforms[ $pixel_key ] : null;

		foreach ( $items as $item ) {
			if ( $is_order ) {
				$product      = $item->get_product();
				$product_id   = $item->get_product_id();
				$variation_id = method_exists( $item, 'get_variation_id' ) ? $item->get_variation_id() : 0;
				$quantity     = $item->get_quantity();
				$price        = $product ? $product->get_price() : 0;
			} else {
				$product      = $item['data'];
				$product_id   = $product->get_id();
				$variation_id = $item['variation_id'];
				$quantity     = $item['quantity'];
				$price        = $product->get_price();
			}

			$item_data    = $this->wpa_analytify_get_product_data( $product_id, $variation_id, $quantity, $price );
			$total_value += $item_data['value'];

			if ( $platform ) {
				$contents[] = $platform->wpa_format_item( $item_data );
			}
		}

		return array(
			'contents'    => $contents,
			'total_value' => $total_value,
		);
	}

	/**
	 * Unified event execution helper.
	 *
	 * @since 9.0.0
	 * @param string $event_name The name of the event.
	 * @param array  $args       Arguments to pass to the generator method.
	 * @return void
	 */
	private function wpa_analytify_execute_pixel_event( $event_name, $args = array() ) {
		$generator = "wpa_generate_{$event_name}_script";

		foreach ( $this->platforms as $platform ) {
			if ( ! method_exists( $platform, $generator ) ) {
				continue;
			}

			try {
				$script = call_user_func_array( array( $platform, $generator ), $args );
				if ( $script ) {
					wp_add_inline_script( 'analytify-pixels-events', $script );
				}
			} catch ( Exception $e ) {
				// Silently fail to prevent breaking the front-end if a platform fails.
				if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
					// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
					error_log( 'Analytify Pixel Error: ' . $e->getMessage() );
				}
			}
		}
	}

	/**
	 * Unified feed item data handler.
	 *
	 * @since 9.0.0
	 * @return void
	 */
	public function wpa_analytify_feed_item_data() {
		global $product;
		if ( ! $product ) {
			return;
		}
		$product_data = $this->wpa_analytify_get_product_data( $product->get_id() );
		foreach ( $this->platforms as $pixel_key => $platform ) {
			$this->product_lists[ $pixel_key ][] = $platform->wpa_format_item( $product_data );
		}
	}

	/**
	 * Unified view item list handler.
	 *
	 * @since 9.0.0
	 * @return void
	 */
	public function wpa_analytify_view_item_list() {
		foreach ( $this->platforms as $pixel_key => $platform ) {
			$script = $platform->wpa_generate_view_list_script( $this->product_lists[ $pixel_key ] );
			if ( $script ) {
				wp_add_inline_script( 'analytify-pixels-events', $script );
				$this->wpa_view_list_enqueued[ $pixel_key ] = true;
			}
		}
	}

	/**
	 * Unified apply coupon handler.
	 *
	 * @since 9.0.0
	 * @return void
	 */
	public function wpa_analytify_apply_coupon() {
		$coupons = WC()->cart->get_applied_coupons();
		$this->wpa_analytify_execute_pixel_event( 'coupon', array( 'applied', end( $coupons ) ) );
	}

	/**
	 * Unified remove coupon handler.
	 *
	 * @since 9.0.0
	 * @return void
	 */
	public function wpa_analytify_remove_coupon() {
		$this->wpa_analytify_execute_pixel_event( 'coupon', array( 'removed', '' ) );
	}

	/**
	 * Unified search handler.
	 *
	 * @since 9.0.0
	 * @return void
	 */
	public function wpa_analytify_search() {
		if ( is_search() && class_exists( 'WooCommerce' ) ) {
			$search_query = sanitize_text_field( get_search_query() );
			$this->wpa_analytify_execute_pixel_event( 'search', array( $search_query, wpa_pixels_get_currency() ) );
		}
	}
}

Analytify_Pixels_Tracking::get_instance();
