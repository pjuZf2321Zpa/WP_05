<?php
/**
 * EDD Dashboard View.
 *
 * @package WP_Analytify_Pro
 */

// phpcs:ignore Squiz.PHP.CommentedOutCode.Found -- Global variable reference.
// global $wpa_edd_currency_symbol.

// phpcs:disable WordPress.NamingConventions.ValidVariableName.VariableNotSnakeCase
$WP_Analytify = $GLOBALS['WP_ANALYTIFY'];

// Get the start date and end date from wpa-core-functions.
$start_date = '';
$end_date   = '';
if ( function_exists( 'analytify_datepicker_dates' ) ) {
	$dates = analytify_datepicker_dates();
	if ( is_array( $dates ) ) {
		$start_date = $dates['start_date'] ?? wp_date( 'Y-m-d', strtotime( '-1 month' ) );
		$end_date   = $dates['end_date'] ?? wp_date( 'Y-m-d', strtotime( 'now' ) );
	} else {
		$start_date = wp_date( 'Y-m-d', strtotime( '-1 month' ) );
		$end_date   = wp_date( 'Y-m-d', strtotime( 'now' ) );
	}
} else {
	$start_date = wp_date( 'Y-m-d', strtotime( '-1 month' ) );
	$end_date   = wp_date( 'Y-m-d', strtotime( 'now' ) );
}

// Fetch Dashboard Profile ID.
$dashboard_profile_ID = $WP_Analytify->settings->get_option( 'profile_for_dashboard', 'wp-analytify-profile' );
$version              = defined( 'ANALYTIFY_PRO_VERSION' ) ? ANALYTIFY_PRO_VERSION : ANALYTIFY_VERSION;
$wp_analytify         = $GLOBALS['WP_ANALYTIFY'];

if ( class_exists( 'WP_ANALYTIFY_FUNCTIONS' ) && method_exists( 'WP_ANALYTIFY_FUNCTIONS', 'wpa_check_profile_selection' ) && ! WP_ANALYTIFY_FUNCTIONS::wpa_check_profile_selection( 'EDD' ) ) {

	/**
	 * Check with roles assigned at dashboard settings.
	 */
	$is_access_level = $WP_Analytify->settings->get_option( 'show_analytics_roles_dashboard', 'wp-analytify-dashboard', array() );

	if ( $WP_Analytify->pa_check_roles( $is_access_level ) ) {

		$acces_token = get_option( 'post_analytics_token' );

		if ( $acces_token ) { ?>

			<div class="wpanalytify analytify-dashboard-nav">
				<div class="wpb_plugin_wraper">
					<div class="wpb_plugin_header_wraper">
						<div class="graph"></div>
						<div class="wpb_plugin_header">
							<div class="wpb_plugin_header_title"></div>
							<div class="wpb_plugin_header_info">
								<a href="https://analytify.io/changelog/" target="_blank" class="btn"><?php echo esc_html__( 'View Changelog', 'wp-analytify-pro' ); ?></a>
							</div>
							<div class="wpb_plugin_header_logo">
								<img src="<?php echo defined( 'ANALYTIFY_PLUGIN_URL' ) ? esc_url( ANALYTIFY_PLUGIN_URL . '/assets/img/logo.svg' ) : ''; ?>" alt="Analytify">
							</div>
						</div>
					</div>

					<div class="analytify-dashboard-body-container">
						<div class="wpb_plugin_body_wraper">
								<div class="wpb_plugin_body">
									<div class="wpa-tab-wrapper">
									<?php
									if ( is_object( $GLOBALS['WP_ANALYTIFY'] ) && method_exists( $GLOBALS['WP_ANALYTIFY'], 'dashboard_navigation' ) ) {
										$nav_output = $GLOBALS['WP_ANALYTIFY']->dashboard_navigation();
										if ( $nav_output ) {
											echo wp_kses_post( $nav_output );
										}
									}
									?>
									</div>
									<div class="wpb_plugin_tabs_content analytify-dashboard-content">
									<div class="analytify_wraper">
										<div class="analytify_main_title_section">
											<div class="analytify_dashboard_title">
												<h1 class="analytify_pull_left analytify_main_title"><?php esc_html_e( 'EDD Dashboard', 'wp-analytify-pro' ); ?></h1>
												<?php
												if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'dashboard_subtitle_section' ) ) {
													WPANALYTIFY_Utils::dashboard_subtitle_section();
												}
												?>
											</div>

											<div class="analytify_main_setting_bar">
												<div class="analytify_pull_right analytify_setting">
													<div class="analytify_select_date">
														<?php
														if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'date_form' ) ) {
															WPANALYTIFY_Utils::date_form( $start_date, $end_date );
														}
														?>
													</div>
												</div>
											</div>
											<?php // phpcs:ignore Squiz.PHP.CommentedOutCode.Found, Squiz.Commenting.InlineComment.InvalidEndChar -- Old dropdown code. ?>
											<!-- <div class="analytify_select_dashboard analytify_pull_right"> <?php // do_action( 'analytify_dashboad_dropdown' ); ?> </div> -->
										</div>

										<?php
										// phpcs:ignore Squiz.PHP.CommentedOutCode.Found -- TODO comments for missing GA4 metrics.
										// Shopping analysis (general stats).
										if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {
											$stats = $WP_Analytify->get_reports(
												'edd-shopping-analysis-stats',
												array(
													'transactions',
													'totalRevenue',
													'averagePurchaseRevenue',
													// phpcs:ignore Squiz.PHP.CommentedOutCode.Found -- TODO: missing GA4 metrics.
													// 'ga:refundAmount, TODO: missing_ga4
													// 'ga:transactionsPerSession, TODO: missing_ga4
													'addToCarts',
													// 'ga:productRemovesFromCart, TODO: missing_ga4
													'checkouts',
													'itemViews',
													'sessions',
													'firstTimePurchaserRate',
													// 'ga:totalRefunds, TODO: missing_ga4
												),
												array(
													'start' => $start_date,
													'end' => $end_date,
												),
												array(),
												array(),
												array(),
												10
											);

											// Get refund events data.
											$refund_stats = $WP_Analytify->get_reports(
												'edd-refund-stats',
												array(
													'eventCount',
													'eventValue',
												),
												array(
													'start' => $start_date,
													'end' => $end_date,
												),
												array(
													'eventName',
												),
												array(
													'type' => 'metric',
													'name' => 'eventCount',
													'order' => 'desc',
												),
												array(
													'logic'   => 'AND',
													'filters' => array(
														array(
															'type'       => 'dimension',
															'name'       => 'eventName',
															'match_type' => 1,
															'value'      => 'refund',
														),
													),
												),
												10
											);

											if ( defined( 'EDD_ANALYTIFY_PRO_PLUGIN_DIR' ) ) {
												include EDD_ANALYTIFY_PRO_PLUGIN_DIR . '/views/default/shopping-analysis.php';
											}
											pa_include_edd( $WP_Analytify, $stats, $refund_stats, $start_date, $end_date );
										}

										// Country Stats.
										if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {
											$stats = $WP_Analytify->get_reports(
												'edd-country-performance-stats',
												array(
													'ecommercePurchases',
													'purchaseRevenue',
													'transactions',
												),
												array(
													'start' => $start_date,
													'end' => $end_date,
												),
												array(
													'country',
													'currencyCode',
												),
												array(
													'type' => 'metric',
													'name' => 'ecommercePurchases',
													'order' => 'desc',
												),
												array(
												// phpcs:disable Squiz.PHP.CommentedOutCode.Found

												/*
												'logic'   => 'AND',
												'filters' => array(
													array(
														'type'           => 'dimension',
														'name'           => 'country',
														'match_type'     => 4,
														'value'          => '(not set)',
														'not_expression' => true,
													),
												),
												*/
												// phpcs:enable Squiz.PHP.CommentedOutCode.Found
												),
												10
											);
											if ( defined( 'EDD_ANALYTIFY_PRO_PLUGIN_DIR' ) ) {
												include EDD_ANALYTIFY_PRO_PLUGIN_DIR . '/views/default/country-performance.php';
											}
											pa_include_country_performance( $WP_Analytify, $stats );
										}
										/**
										*
										* ECharts Funnel.
										*/
										if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {
											$stats = $WP_Analytify->get_reports(
												'show-edd-product-funnel-chart',
												array(
													'itemsAddedToCart',
													'itemsPurchased',
													'itemsViewed',
												),
												array(
													'start' => $start_date,
													'end' => $end_date,
												),
												array(
													'itemListName',
												),
												array(
													'type' => 'metric',
													'name' => 'itemsViewed',
													'order' => 'desc',
												),
												false,
												10
											);

											if ( defined( 'EDD_ANALYTIFY_PRO_PLUGIN_DIR' ) ) {
												include EDD_ANALYTIFY_PRO_PLUGIN_DIR . '/views/default/edd-funnel.php';
											}
												wpa_edd_funnel_chart( $WP_Analytify, $stats );
										}

										if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {
											$stats = $WP_Analytify->get_reports(
												'edd-roi-stats',
												array(
													'sessions',
													'bounceRate',
													'purchaseRevenue',
												),
												array(
													'start' => $start_date,
													'end' => $end_date,
												),
												array(
													'sourceMedium',
													'currencyCode',
												),
												array(
													'type' => 'metric',
													'name' => 'purchaseRevenue',
													'order' => 'desc',
												),
												array(),
												20
											);
											if ( defined( 'EDD_ANALYTIFY_PRO_PLUGIN_DIR' ) ) {
												include EDD_ANALYTIFY_PRO_PLUGIN_DIR . '/views/default/measuring-roi.php';
											}
											pa_include_edd_measuring_roi( $WP_Analytify, $stats );
										}

										if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {
											$stats = $WP_Analytify->get_reports(
												'edd-products-performance-stats',
												array(
													'itemsViewed',
													'itemRevenue',
													'itemsPurchased',
													'cartToViewRate',
													'itemsAddedToCart',
												),
												array(
													'start' => $start_date,
													'end' => $end_date,
												),
												array(
													'itemName',
													'currencyCode',
												),
												array(
													'type' => 'metric',
													'name' => 'itemsPurchased',
													'order' => 'desc',
												),
												array(
													'logic'   => 'AND',
													'filters' => array(
														array(
															'type'           => 'dimension',
															'name'           => 'itemName',
															'match_type'     => 4,
															'value'          => '(not set)',
															'not_expression' => true,
														),
													),
												),
												50
											);

											if ( defined( 'EDD_ANALYTIFY_PRO_PLUGIN_DIR' ) ) {
												include EDD_ANALYTIFY_PRO_PLUGIN_DIR . '/views/default/products-performance.php';
											}
											pa_include_edd_products( $WP_Analytify, $stats );
										}


										if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {
											$stats = $WP_Analytify->get_reports(
												'show-woo-coupons-analysis-stats',
												array(
													'purchaseRevenue',
													'transactions',
													'averagePurchaseRevenue',
												),
												array(
													'start' => $start_date,
													'end' => $end_date,
												),
												array(
													'orderCoupon',
													'currencyCode',
												),
												array(
													'type' => 'dimension',
													'name' => 'orderCoupon',
												),
												array(
													'logic'   => 'AND',
													'filters' => array(
														array(
															'type'           => 'dimension',
															'name'           => 'orderCoupon',
															'match_type'     => 4,
															'value'          => '(not set)',
															'not_expression' => true,
														),
													),
												),
												10
											);

											if ( defined( 'EDD_ANALYTIFY_PRO_PLUGIN_DIR' ) ) {
												include EDD_ANALYTIFY_PRO_PLUGIN_DIR . '/views/default/coupons.php';
											}
											pa_include_edd_coupons_performance( $WP_Analytify, $stats );
										}
		} else {
			esc_html_e( 'You must be logged in to see the Analytics Dashboard.', 'wp-analytify-pro' );
		}
	} else {
		esc_html_e( 'You don\'t have access to EDD Dashboard.', 'wp-analytify-pro' );
	}
}
?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
