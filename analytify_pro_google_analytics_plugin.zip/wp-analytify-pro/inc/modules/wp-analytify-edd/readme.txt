Hi there,

We at Analytify welcomes you to our premium users family.


== Installation ==
You should have installed Analytify Free + Pro versions to use this Analytify for EDD add-on.

If you have any problem, please send an email to us at support@analytify.io


Cheers
Adnan from Analytify LLC


== Changelog ==

= 5.1.0 - 2023-12-02 =
	* Enhancement: We made all the plugin sections responsive.
	* Compatibility: Compatible to WordPress 6.4.1 and PHP 8.2.10

= 5.0.4 - 2023-06-20 =
	* Bug Fix: order source/medium corrected.
	* Enhancement: session information added in events.

= 5.0.3 - 2023-05-30 =
	* Bug Fix: Orders Column messed up because of 5.0.2 release.

= 5.0.2 - 2023-05-30 =
	* New Feature: Order source/medium support added for GA4.
	* Enhancement: Use main dashboard saved date.
	* Enhancement: Changelog button text updated.

= 5.0.1 - 2023-05-08 =
	* Bug Fix: EDD Pro detection fixed.

= 5.0.0 - 2023-04-16 =
	* New Feature: Google Analytics GA4 integration is added.
	* New Feature: Google Search Console (webmasters) Integrated.
	* Enhancement: Pageload speed improvement.
	* Enhancement: UI Improvements.

= 2.0.0 12th March, 2021 =
	* New Feature: New dashboard design.
	* Enhancement: Update admin submenu ranking.
	* Enhancement: Code refactoring.
	* Enhancement: Update admin notices.

= 1.2.0 26th Jan, 2021 =
    * Bug Fix: Invalid date format issue while fetching stats from Google Analytics.

= 1.1.0 15th Nov, 2017 =

 	* [New Feature] WPML Support.
 	* [New Feature] Multilingual Compatible.
 	* [New Feature] Revenue Column in Country Stats
 	* [New Feature] Track Source/Medium for each Sale.
 	* [New Feature] Measuring ROI section gives a list of all the sales channels/sources.
 	* [New Feature] Fetch Traffic source for each sale through EDD Payment History Page.
 	* [Bug Fix] Revenue format
 	* [Bug Fix] BounceRate

= 1.0.0 28th Oct, 2016 =

 	* Initial Release.

The full changelog is available at https://analytify.io/changelog/