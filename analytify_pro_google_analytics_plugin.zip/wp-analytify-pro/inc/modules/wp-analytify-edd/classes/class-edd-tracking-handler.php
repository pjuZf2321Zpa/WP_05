<?php
/**
 * EDD Tracking Handler Class.
 *
 * @package WP_Analytify_Pro
 * @since 8.0.0
 */

// phpcs:ignoreFile WordPress.Files.FileName.InvalidClassFileName

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Class WP_Analytify_EDD_Tracking_Handler
 *
 * Handles EDD eCommerce tracking integration.
 */
class WP_Analytify_EDD_Tracking_Handler {

	/** @var string */

	/**
	 * Google Analytics GA4 API URL.
	 */
	public $google_ga4_api_url = ANALYTIFY_GOOGLE_GA4_API_URL;
	/** @var array<int|string, mixed> */
	private $impressions = array();
	/** @var mixed */
	private $wp_analytify;

	/**
	 * Constructor.
	 */
	public function __construct() {
		global $WP_ANALYTIFY;
		$this->wp_analytify = $WP_ANALYTIFY;

		// Ensure analytify_mp_ga4 function is available (load from free plugin if needed)
		if ( ! function_exists( 'analytify_mp_ga4' ) ) {
			// The free plugin should be at the same level as the pro plugin
			$free_plugin_path = WP_PLUGIN_DIR . '/wp-analytify/classes/analytify-mp-ga4.php';

			if ( file_exists( $free_plugin_path ) ) {
				require_once $free_plugin_path;
			}
		}
		if ( ! function_exists( 'analytify_mp_ga4' ) ) {
			$this->maybe_log_missing_mp_ga4();
		}
	}

	/**
	 * Log once per day when GA4 Measurement Protocol helper is missing (visible in production error logs).
	 *
	 * @return void
	 */
	private function maybe_log_missing_mp_ga4() {
		if ( function_exists( 'analytify_mp_ga4' ) ) {
			return;
		}
		if ( get_transient( 'analytify_edd_mp_ga4_missing_log' ) ) {
			return;
		}
		set_transient( 'analytify_edd_mp_ga4_missing_log', '1', DAY_IN_SECONDS );
		// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- Throttled diagnostic when MP helper is missing.
		error_log( 'Analytify EDD: analytify_mp_ga4() is not available; GA4 Measurement Protocol events will not be sent. Ensure WP Analytify (free) is installed and active.' );
	}

	/**
	 * Send GA4 MP events when the helper exists; otherwise trigger throttled logging.
	 *
	 * @param array<int, array<string, mixed>> $events Events payload.
	 * @return void
	 */
	private function send_analytify_mp_ga4_events( $events ) {
		if ( function_exists( 'analytify_mp_ga4' ) ) {
			analytify_mp_ga4( $events );
			return;
		}
		$this->maybe_log_missing_mp_ga4();
	}

	/**
	 * First coupon code from EDD payment discount meta, or null when none/empty.
	 *
	 * @param mixed $discount Raw payment meta value.
	 * @return string|null
	 */
	public function normalize_edd_discount( $discount ) {
		if ( ! is_string( $discount ) ) {
			return null;
		}
		$discount = trim( $discount );
		if ( '' === $discount || 0 === strcasecmp( $discount, 'none' ) ) {
			return null;
		}
		$parts = explode( ',', $discount );
		$first = isset( $parts[0] ) ? trim( $parts[0] ) : '';
		return '' !== $first ? $first : null;
	}

	/**
	 * Whether the ID refers to an existing EDD download post.
	 *
	 * @param int|string $download_id Download post ID.
	 * @return bool
	 */
	private function is_valid_download_id( $download_id ) {
		$id = absint( $download_id );
		if ( $id <= 0 ) {
			return false;
		}
		return 'download' === get_post_type( $id );
	}

	/**
	 * This function is responsible for filtering the raw ids in cookies
	 * and returning the proper session id for GA4.
	 *
	 * @param mixed $value
	 * @return string
	 */
	public function analytify_filter_session_id( $value ) {
		if ( empty( $value ) ) {
			return '';
		}

		if ( is_array( $value ) ) {
			foreach ( $value as $key => $val ) {
				if ( strpos( $key, '_ga' ) !== false ) {
					$value = $val;
					break;
				}
			}
		}

		if ( is_string( $value ) ) {
			$value = explode( '.', $value );
			if ( count( $value ) >= 4 ) {
				$value = $value[2] . '.' . $value[3];
			}
		}

		return $value;
	}

	/**
	 * Get single item info for GA4.
	 *
	 * @param int                  $download_id
	 * @param array<string, mixed> $item_options
	 * @param int|null             $override_quantity
	 * @param float|null           $override_price
	 * @return array<string, mixed>
	 */
	private function single_item_info_ga4( $download_id, $item_options, $override_quantity = null, $override_price = null ) {
		if ( ! class_exists( 'EDD_Download' ) || ! $this->is_valid_download_id( $download_id ) ) {
			return array();
		}
		$download_id = absint( $download_id );
		$download    = new EDD_Download( $download_id );

		if ( ! $download->ID ) {
			return array();
		}

		$quantity = $override_quantity ? $override_quantity : ( isset( $item_options['quantity'] ) ? $item_options['quantity'] : 1 );
		$price    = $override_price ? $override_price : $this->get_item_price( $download_id, isset( $item_options['options']['price_id'] ) ? $item_options['options']['price_id'] : 0 );

		$first_category = '';
		$categories     = get_the_terms( $download_id, 'download_category' );
		if ( $categories && ! is_wp_error( $categories ) ) {
			$first_category = $categories[0]->name;
		}

		$variation = '';
		if ( isset( $item_options['options']['price_id'] ) && $item_options['options']['price_id'] ) {
			$variation = function_exists( 'edd_get_price_option_name' ) ? edd_get_price_option_name( $download_id, $item_options['options']['price_id'] ) : '';
		}

		return array(
			'item_id'       => $download_id,
			'item_name'     => method_exists( $download, 'get_name' ) ? $download->get_name() : '',
			'item_category' => $first_category,
			'item_variant'  => $variation,
			'price'         => $price,
			'quantity'      => $quantity,
		);
	}

	/**
	 * Get item price.
	 *
	 * @param int $download_id
	 * @param int $variation
	 * @return float
	 */
	private function get_item_price( $download_id = 0, $variation = 0 ) {
		if ( $variation ) {
			$prices = function_exists( 'edd_get_variable_prices' ) ? edd_get_variable_prices( $download_id ) : array();
			return isset( $prices[ $variation ]['amount'] ) ? $prices[ $variation ]['amount'] : 0;
		}

		return function_exists( 'edd_get_download_price' ) ? edd_get_download_price( $download_id ) : 0;
	}

	/**
	 * Build purchase data array for GA4 tracking.
	 *
	 * @param int                  $payment_id Payment ID.
	 * @param array<string, mixed> $items      Array of items.
	 * @param string|null          $discount   Optional discount/coupon code.
	 * @return array<string, mixed>
	 */
	private function analytify_build_purchase_data( $payment_id, $items, $discount = null ) {
		$purchase_amount = function_exists( 'edd_get_payment_amount' ) ? edd_get_payment_amount( $payment_id ) : 0;
		$purchase_tax    = ( function_exists( 'edd_use_taxes' ) && edd_use_taxes() ) ? ( function_exists( 'edd_get_payment_tax' ) ? edd_get_payment_tax( $payment_id ) : 0 ) : 0;
		$currency        = function_exists( 'edd_get_currency' ) ? edd_get_currency() : 'USD';

		$purchase_data = array(
			'transaction_id' => 'EDD_' . $payment_id,
			'value'          => $purchase_amount,
			'currency'       => $currency,
			'items'          => $items,
		);

		// Only add tax if it's not empty.
		if ( ! empty( $purchase_tax ) ) {
			$purchase_data['tax'] = $purchase_tax;
		}

		// Only add coupon if it exists and is not empty.
		if ( ! empty( $discount ) ) {
			$purchase_data['coupon'] = $discount;
		}

		return $purchase_data;
	}

	/**
	 * Refund amount for analytics events: use EDD cumulative refunded total when available so partial refunds track correctly.
	 *
	 * @param int $payment_id Payment / order ID.
	 * @return float
	 */
	private function get_edd_refund_tracking_amount( $payment_id ) {
		$payment_id = absint( $payment_id );
		if ( ! $payment_id ) {
			return 0.0;
		}
		if ( function_exists( 'edd_get_payment' ) ) {
			$payment = edd_get_payment( $payment_id );
			if ( is_object( $payment ) ) {
				foreach ( array( 'get_refunded_amount', 'get_total_refunded', 'get_refund_amount' ) as $method ) {
					if ( method_exists( $payment, $method ) ) {
						$amt = (float) call_user_func( array( $payment, $method ) );
						if ( $amt > 0 ) {
							return $amt;
						}
					}
				}
			}
		}
		return (float) ( function_exists( 'edd_get_payment_amount' ) ? edd_get_payment_amount( $payment_id ) : 0 );
	}

	/**
	 * Remove from cart tracking.
	 *
	 * @param string $cart_key
	 * @return void
	 */
	public function remove_from_cart( $cart_key ) {
		$cart_contents = function_exists( 'edd_get_cart_contents' ) ? edd_get_cart_contents() : array();

		if ( ! isset( $cart_contents[ $cart_key ] ) ) {
			return;
		}

		$item = $cart_contents[ $cart_key ];
		if ( ! is_array( $item ) || empty( $item['id'] ) ) {
			return;
		}

		if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {
			$item_options = isset( $item['options'] ) ? $item['options'] : array();
			$item_quantity = isset( $item['quantity'] ) ? $item['quantity'] : 1;
			$item_info = $this->single_item_info_ga4( $item['id'], $item_options, $item_quantity );
			$session_id = $this->analytify_filter_session_id( $_COOKIE );

			$item_price = isset( $item_info['price'] ) && ! empty( $item_info['price'] ) ? $item_info['price'] : 0;
			$item_quantity_value = isset( $item_info['quantity'] ) && ! empty( $item_info['quantity'] ) ? $item_info['quantity'] : 1;

			$event[] = array(
				'name'   => 'remove_from_cart',
				'params' => array(
					'currency'   => function_exists( 'edd_get_currency' ) ? edd_get_currency() : 'USD',
					'value'      => $item_price * $item_quantity_value,
					'items'      => array( $item_info ),
					'session_id' => $session_id,
				),
			);

			$this->send_analytify_mp_ga4_events( $event );
		} else {
			$attr = array(
				't'  => 'event',
				'ec' => 'Tracking by Analytify EDD',
				'ea' => 'Remove from Cart',
				'el' => $item['name'],
				'ev' => $item['price'],
			);

			$this->hit( $attr );
		}
	}

	/**
	 * Checkout page step tracking.
	 *
	 * @return void
	 */
	public function checkout_page_step() {
		$raw_cart_contents = function_exists( 'edd_get_cart_contents' ) ? edd_get_cart_contents() : array();

		if ( empty( $raw_cart_contents ) || ( ! is_array( $raw_cart_contents ) && ! is_object( $raw_cart_contents ) ) ) {
			return;
		}

		if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {
			$items = array();
			$session_id = $this->analytify_filter_session_id( $_COOKIE );

			foreach ( $raw_cart_contents as $cart_key => $item ) {
				if ( ! is_array( $item ) || empty( $item['id'] ) ) {
					continue;
				}
				$items[] = $this->single_item_info_ga4( $item['id'], $item['options'] ?? array(), $item['quantity'] ?? 1 );
			}

			$event[] = array(
				'name'   => 'begin_checkout',
				'params' => array(
					'currency'   => function_exists( 'edd_get_currency' ) ? edd_get_currency() : 'USD',
					'value'      => function_exists( 'edd_get_cart_total' ) ? edd_get_cart_total() : 0,
					'items'      => $items,
					'session_id' => $session_id,
				),
			);

			$this->send_analytify_mp_ga4_events( $event );
		} else {
			$attr = array(
				't'  => 'event',
				'ec' => 'Tracking by Analytify EDD',
				'ea' => 'Checkout',
				'el' => 'Checkout Page',
			);

			$this->hit( $attr );
		}
	}

	/**
	 * Checkout complete step tracking.
	 *
	 * @param int $payment_id
	 * @return void
	 */
	public function checkout_complete_step( $payment_id ) {
		$cart_contents = function_exists( 'edd_get_payment_meta' ) ? edd_get_payment_meta( $payment_id, 'cart_details' ) : array();

		if ( empty( $cart_contents ) || ! is_array( $cart_contents ) ) {
			return;
		}

		if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {
			$items = array();

			foreach ( $cart_contents as $item ) {
				if ( ! is_array( $item ) || ! isset( $item['id'] ) ) {
					continue;
				}
				$options = isset( $item['item_number']['options'] ) ? $item['item_number']['options'] : array();
				$quantity = isset( $item['quantity'] ) ? $item['quantity'] : 1;
				$price = isset( $item['price'] ) ? $item['price'] : null;

				$items[] = $this->single_item_info_ga4( $item['id'], $options, $quantity, $price );
			}

			$payment_meta = function_exists( 'edd_get_payment_meta' ) ? edd_get_payment_meta( $payment_id ) : array();
			$discount_raw = isset( $payment_meta['user_info']['discount'] ) ? $payment_meta['user_info']['discount'] : '';
			$discount     = $this->normalize_edd_discount( is_string( $discount_raw ) ? $discount_raw : '' );

			$purchase_data = $this->analytify_build_purchase_data( $payment_id, $items, $discount );

			$event[] = array(
				'name'   => 'purchase',
				'params' => $purchase_data,
			);

			$this->send_analytify_mp_ga4_events( $event );
		} else {
			$attr = array(
				't'  => 'event',
				'ec' => 'Tracking by Analytify EDD',
				'ea' => 'Checkout',
				'el' => 'Checkout Complete',
			);

			$this->hit( $attr );
		}
	}

	/**
	 * Track single product view using edd_download_before hook.
	 */
	public function track_single_product_view() {
		$download_id = get_the_ID();

		if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {
			$item_info = $this->single_item_info_ga4( $download_id, array(), 1, $this->get_item_price( $download_id, 0 ) );
			$session_id = $this->analytify_filter_session_id( $_COOKIE );

			$event[] = array(
				'name'   => 'view_item',
				'params' => array(
					'currency'   => function_exists( 'edd_get_currency' ) ? edd_get_currency() : 'USD',
					'value'      => $item_info['price'] ?? 0,
					'items'      => array( $item_info ),
					'session_id' => $session_id,
				),
			);

			$this->send_analytify_mp_ga4_events( $event );
		}
	}

	/**
	 * Alternative add to cart tracking (edd_add_to_cart hook).
	 *
	 * @param int                  $download_id
	 * @param array<string, mixed> $options
	 * @return void
	 */
	public function add_to_cart_alt( $download_id, $options ) {
		$this->add_to_cart( $download_id, $options );
	}

	/**
	 * Post add to cart tracking (edd_post_add_to_cart hook).
	 *
	 * @param int                  $download_id
	 * @param array<string, mixed> $options
	 * @return void
	 */
	public function add_to_cart_post( $download_id, $options ) {
		$this->add_to_cart( $download_id, $options );
	}

	/**
	 * Add to cart tracking.
	 *
	 * @param int                  $download_id
	 * @param array<string, mixed> $options
	 * @return void
	 */
	public function add_to_cart( $download_id, $options ) {
		if ( ! class_exists( 'EDD_Download' ) || ! $this->is_valid_download_id( $download_id ) ) {
			return;
		}
		$download_id = absint( $download_id );
		$download    = new EDD_Download( $download_id );

		if ( ! $download->ID ) {
			return;
		}

		$price    = $this->get_item_price( $download_id, isset( $options['price_id'] ) ? $options['price_id'] : 0 );
		$quantity = isset( $options['quantity'] ) ? $options['quantity'] : 1;

		if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {
			$item = $this->single_item_info_ga4( $download_id, array( 'quantity' => $quantity ), $quantity, $price );
			$session_id = $this->analytify_filter_session_id( $_COOKIE );

			$event[] = array(
				'name'   => 'add_to_cart',
				'params' => array(
					'currency'   => function_exists( 'edd_get_currency' ) ? edd_get_currency() : 'USD',
					'value'      => $item['quantity'] * $item['price'],
					'items'      => array( $item ),
					'session_id' => $session_id
				),
			);

			$this->send_analytify_mp_ga4_events( $event );
		} else {
			$first_category = '';
			$categories     = get_the_terms( $download_id, 'download_category' );
			if ( $categories && ! is_wp_error( $categories ) ) {
				$first_category = $categories[0]->name;
			}

			$variation = '';
			if ( isset( $options['price_id'] ) && $options['price_id'] ) {
				$variation = function_exists( 'edd_get_price_option_name' ) ? edd_get_price_option_name( $download_id, $options['price_id'] ) : '';
			}

			$attr = array(
				't'     => 'event',
				'ec'    => 'Tracking by Analytify EDD',
				'ea'    => 'Add to Cart',
				'el'    => method_exists( $download, 'get_name' ) ? $download->get_name() : '',
				'ev'    => $price,
				'pr1id' => $download_id,
				'pr1nm' => method_exists( $download, 'get_name' ) ? $download->get_name() : '',
				'pr1ca' => $first_category,
				'pr1va' => $variation,
				'pr1pr' => $price,
				'pr1qt' => $quantity,
			);

			$this->hit( $attr );
		}
	}

	/**
	 * Track Transaction when it changes its status.
	 *
	 * @param int    $payment_id
	 * @param string $new_status
	 * @param string $old_status
	 * @return void
	 */
	public function transaction( $payment_id, $new_status, $old_status ) {
		// return if the current status update isn't for completion.
		if ( 'publish' !== $new_status && 'complete' !== $new_status ) {
			return;
		}

		// Bail if payment is already tracked
		if ( 'yes' == get_post_meta( $payment_id, 'track_eega_edd_payment_complete_analytify', true ) ) {
			return;
		}

		if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {
			$payment_meta = function_exists( 'edd_get_payment_meta' ) ? edd_get_payment_meta( $payment_id ) : array();

			if ( empty( $payment_meta['cart_details'] ) || ! is_array( $payment_meta['cart_details'] ) ) {
				return;
			}

			$discount_raw  = isset( $payment_meta['user_info']['discount'] ) ? $payment_meta['user_info']['discount'] : '';
			$discount      = $this->normalize_edd_discount( is_string( $discount_raw ) ? $discount_raw : '' );
			$cart_contents = $payment_meta['cart_details'];

			$items = array();

			foreach ( $cart_contents as $item ) {
				if ( ! is_array( $item ) || ! isset( $item['id'] ) ) {
					continue;
				}
				$options = isset( $item['item_number']['options'] ) ? $item['item_number']['options'] : array();
				$quantity = isset( $item['quantity'] ) ? $item['quantity'] : 1;
				$price = isset( $item['price'] ) ? $item['price'] : null;

				$items[] = $this->single_item_info_ga4( $item['id'], $options, $quantity, $price );
			}

			$session_id = $this->analytify_filter_session_id( $_COOKIE );

			$purchase_data = $this->analytify_build_purchase_data( $payment_id, $items, $discount );


			$event[] = array(
				'name'   => 'purchase',
				'params' => $purchase_data,
			);

			$this->send_analytify_mp_ga4_events( $event );
		} else {
			$payment_meta = function_exists( 'edd_get_payment_meta' ) ? edd_get_payment_meta( $payment_id ) : array();
			$items        = $this->fetch_download_items( $payment_id );
			$discount_raw = isset( $payment_meta['user_info']['discount'] ) ? $payment_meta['user_info']['discount'] : '';
			$discount     = $this->normalize_edd_discount( is_string( $discount_raw ) ? $discount_raw : '' );

			$attr = array_merge(
				array(
					't'   => 'event',
					'ec'  => 'Tracking by Analytify EDD',
					'ea'  => 'Checkout',
					'el'  => 'Transaction',
					'cid' => $this->get_edd_cid( (string) $payment_id ),
					'ti'  => function_exists( 'edd_get_payment_number' ) ? edd_get_payment_number( $payment_id ) : '',
					'ta'  => null,
					'tr'  => function_exists( 'edd_get_payment_amount' ) ? edd_get_payment_amount( $payment_id ) : 0,
					'tt'  => ( function_exists( 'edd_use_taxes' ) && edd_use_taxes() ) ? ( function_exists( 'edd_get_payment_tax' ) ? edd_get_payment_tax( $payment_id ) : null ) : null,
					'ts'  => null,
					'tcc' => null !== $discount ? $discount : '',
					'pa'  => 'purchase',
				),
				$items
			);

			$this->hit( $attr );
		}

		update_post_meta( $payment_id, 'track_eega_edd_payment_complete_analytify', 'yes' );
	}

	/**
	 * Track refunds.
	 *
	 * @param int    $payment_id
	 * @param string $new_status
	 * @param string $old_status
	 * @return void
	 */
	public function refund( $payment_id, $new_status, $old_status ) {
		$normalized_status = strtolower( str_replace( '-', '_', (string) $new_status ) );
		if ( ! in_array( $normalized_status, array( 'refunded', 'partially_refunded' ), true ) ) {
			return;
		}

		$refund_amount = $this->get_edd_refund_tracking_amount( $payment_id );

		if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {
			$event = array(
				array(
					'name'   => 'refund',
					'params' => array(
						'transaction_id' => 'EDD_' . $payment_id,
						'value'          => $refund_amount,
						'currency'       => function_exists( 'edd_get_currency' ) ? edd_get_currency() : 'USD',
					),
				),
			);

			$this->send_analytify_mp_ga4_events( $event );
		} else {
			$attr = array(
				't'   => 'event',
				'ec'  => 'Tracking by Analytify EDD',
				'ea'  => 'Refund',
				'el'  => 'Refund',
				'cid' => $this->get_edd_cid( (string) $payment_id ),
				'ti'  => function_exists( 'edd_get_payment_number' ) ? edd_get_payment_number( $payment_id ) : '',
				'tr'  => $refund_amount,
			);

			$this->hit( $attr );
		}
	}

	/**
	 * Add impression tracking.
	 *
	 * @param int                  $download_id
	 * @param array<string, mixed> $args
	 * @return void
	 */
	public function add_impression( $download_id, $args ) {
		if ( ! class_exists( 'EDD_Download' ) || ! $this->is_valid_download_id( $download_id ) ) {
			return;
		}
		$download_id = absint( $download_id );
		$download    = new EDD_Download( $download_id );

		if ( ! $download->ID ) {
			return;
		}

		$price = $this->get_item_price( $download_id, isset( $args['price_id'] ) ? $args['price_id'] : 0 );

		$this->impressions[] = array(
			'id'    => $download_id,
			'name'  => method_exists( $download, 'get_name' ) ? $download->get_name() : '',
			'price' => $price,
		);
	}

	/**
	 * Track impressions.
	 *
	 * @return void
	 */
	public function track_impressions() {
		if ( empty( $this->impressions ) ) {
			return;
		}

		if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {
			$items = array();
			$session_id = $this->analytify_filter_session_id( $_COOKIE );

			foreach ( $this->impressions as $impression ) {
				if ( ! is_array( $impression ) || ! isset( $impression['id'] ) ) {
					continue;
				}
				$impression_id = absint( $impression['id'] );
				if ( $impression_id <= 0 || ! $this->is_valid_download_id( $impression_id ) ) {
					continue;
				}
				$items[] = array(
					'item_id'   => $impression_id,
					'item_name' => isset( $impression['name'] ) ? $impression['name'] : '',
					'price'     => isset( $impression['price'] ) ? $impression['price'] : 0,
				);
			}

			if ( ! empty( $items ) ) {
				$event[] = array(
					'name'   => 'view_item_list',
					'params' => array(
						'currency'   => function_exists( 'edd_get_currency' ) ? edd_get_currency() : 'USD',
						'items'      => $items,
						'session_id' => $session_id,
					),
				);

				$this->send_analytify_mp_ga4_events( $event );
			}
		} else {
			foreach ( $this->impressions as $impression ) {
				if ( ! is_array( $impression ) || ! isset( $impression['id'] ) ) {
					continue;
				}
				$impression_id = absint( $impression['id'] );
				if ( $impression_id <= 0 || ! $this->is_valid_download_id( $impression_id ) ) {
					continue;
				}
				$impression_name  = isset( $impression['name'] ) ? $impression['name'] : '';
				$impression_price = isset( $impression['price'] ) ? $impression['price'] : 0;
				$attr             = array(
					't'     => 'event',
					'ec'    => 'Tracking by Analytify EDD',
					'ea'    => 'Impression',
					'el'    => $impression_name,
					'ev'    => $impression_price,
					'pr1id' => $impression_id,
					'pr1nm' => $impression_name,
					'pr1pr' => $impression_price,
				);

				$this->hit( $attr );
			}
		}

		$this->impressions = array();
	}

	/**
	 * Save user CID.
	 *
	 * @param int                  $payment_id
	 * @param array<string, mixed> $payment_data
	 * @return void
	 */
	public function save_user_cid( $payment_id, $payment_data ) {
		if ( isset( $_COOKIE['_ga'] ) ) {
			$cid = $this->analytify_filter_session_id( $_COOKIE['_ga'] );
			update_post_meta( $payment_id, 'analytify_edd_cid', $cid );
		}
	}

	/**
	 * Get EDD client ID (GA CID for payment).
	 *
	 * @param string $payment_id
	 * @return string
	 */
	public function get_edd_cid( $payment_id = '' ) {
		if ( $payment_id ) {
			$cid = get_post_meta( (int) $payment_id, 'analytify_edd_cid', true );
			if ( $cid ) {
				return $cid;
			}
		}

		if ( isset( $_COOKIE['_ga'] ) ) {
			return $this->analytify_filter_session_id( $_COOKIE['_ga'] );
		}

		return $this->generate_uuid();
	}

	/**
	 * Fetch download items.
	 *
	 * @param int $payment_id
	 * @return array<string, mixed>
	 */
	public function fetch_download_items( $payment_id ) {
		$cart_details = function_exists( 'edd_get_payment_meta' ) ? edd_get_payment_meta( $payment_id, 'cart_details' ) : array();
		$items        = array();

		if ( empty( $cart_details ) || ! is_array( $cart_details ) ) {
			return $items;
		}

		foreach ( $cart_details as $index => $item ) {
			if ( ! is_array( $item ) || ! isset( $item['id'] ) ) {
				continue;
			}
			$download_id = absint( $item['id'] );
			if ( ! class_exists( 'EDD_Download' ) || ! $this->is_valid_download_id( $download_id ) ) {
				continue;
			}
			$download = new EDD_Download( $download_id );

			if ( ! $download->ID ) {
				continue;
			}

			$price = $this->get_item_price( $download_id, isset( $item['options']['price_id'] ) ? $item['options']['price_id'] : 0 );

			$first_category = '';
			$categories     = get_the_terms( $download_id, 'download_category' );
			if ( $categories && ! is_wp_error( $categories ) ) {
				$first_category = $categories[0]->name;
			}

			$variation = '';
			if ( isset( $item['options']['price_id'] ) && $item['options']['price_id'] ) {
				$variation = function_exists( 'edd_get_price_option_name' ) ? edd_get_price_option_name( $download_id, $item['options']['price_id'] ) : '';
			}

			$items[ 'pr' . ( $index + 1 ) . 'id' ] = $download_id;
			$items[ 'pr' . ( $index + 1 ) . 'nm' ] = method_exists( $download, 'get_name' ) ? $download->get_name() : '';
			$items[ 'pr' . ( $index + 1 ) . 'ca' ] = $first_category;
			$items[ 'pr' . ( $index + 1 ) . 'va' ] = $variation;
			$items[ 'pr' . ( $index + 1 ) . 'pr' ] = $price;
			$items[ 'pr' . ( $index + 1 ) . 'qt' ] = $item['quantity'];
		}

		return $items;
	}

	/**
	 * Get the list of downloads for tracking.
	 *
	 * @return string
	 */
	public function get_the_list() {
		global $wp_query;

		$list = 'Default';

		if ( is_search() ) :
			$list = __( 'Search results', 'wp-analytify-pro' );
		elseif ( true ) :

		endif;

		return urlencode( $list );
	}

	/**
	 * Get cart items.
	 *
	 * @return list<array<string, mixed>>
	 */
	public function get_cart_items() {
		$cart_contents = function_exists( 'edd_get_cart_contents' ) ? edd_get_cart_contents() : array();
		$items         = array();

		if ( empty( $cart_contents ) || ( ! is_array( $cart_contents ) && ! is_object( $cart_contents ) ) ) {
			return $items;
		}

		foreach ( $cart_contents as $cart_key => $item ) {
			// Get item details using EDD's structure
			if ( ! is_array( $item ) || ! isset( $item['id'] ) ) {
				continue;
			}

			$download_id = absint( $item['id'] );
			if ( ! class_exists( 'EDD_Download' ) || ! $this->is_valid_download_id( $download_id ) ) {
				continue;
			}
			$download = new EDD_Download( $download_id );

			if ( ! $download->ID ) {
				continue;
			}

			$item_name = $download->get_name();

			$price_id = isset( $item['options']['price_id'] ) ? $item['options']['price_id'] : 0;
			$item_price = $this->get_item_price( $download_id, $price_id );

			$quantity = isset( $item['quantity'] ) ? $item['quantity'] : 1;

			$items[] = array(
				'id'       => $download_id,
				'name'     => $item_name,
				'price'    => $item_price,
				'quantity' => $quantity,
			);
		}

		return $items;
	}

	/**
	 * Product detail tracking.
	 *
	 * @param int                  $download_id
	 * @param array<string, mixed> $args
	 * @return void
	 */
	public function product_detail( $download_id, $args ) {
		if ( ! class_exists( 'EDD_Download' ) || ! $this->is_valid_download_id( $download_id ) ) {
			return;
		}
		$download_id = absint( $download_id );
		$download    = new EDD_Download( $download_id );

		if ( ! $download->ID ) {
			return;
		}

		$price = $this->get_item_price( $download_id, isset( $args['price_id'] ) ? $args['price_id'] : 0 );

		if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {
			$first_category = '';
			$categories     = get_the_terms( $download_id, 'download_category' );
			if ( $categories && ! is_wp_error( $categories ) ) {
				$first_category = $categories[0]->name;
			}

			$variation = '';
			if ( isset( $args['price_id'] ) && $args['price_id'] ) {
				$variation = function_exists( 'edd_get_price_option_name' ) ? edd_get_price_option_name( $download_id, $args['price_id'] ) : '';
			}

			$event[] = array(
				'name'   => 'view_item',
				'params' => array(
					'currency' => function_exists( 'edd_get_currency' ) ? edd_get_currency() : 'USD',
					'value'    => $price,
					'items'    => array(
						array(
							'item_id'       => $download_id,
							'item_name'     => $download->get_name(),
							'item_category' => $first_category,
							'item_variant'  => $variation,
							'price'         => $price,
						),
					),
				),
			);

			$this->send_analytify_mp_ga4_events( $event );
		} else {
			$first_category = '';
			$categories     = get_the_terms( $download_id, 'download_category' );
			if ( $categories && ! is_wp_error( $categories ) ) {
				$first_category = $categories[0]->name;
			}

			$variation = '';
			if ( isset( $args['price_id'] ) && $args['price_id'] ) {
				$variation = function_exists( 'edd_get_price_option_name' ) ? edd_get_price_option_name( $download_id, $args['price_id'] ) : '';
			}

			$attr = array(
				't'     => 'event',
				'ec'    => 'Tracking by Analytify EDD',
				'ea'    => 'Product Detail',
				'el'    => method_exists( $download, 'get_name' ) ? $download->get_name() : '',
				'ev'    => $price,
				'pr1id' => $download_id,
				'pr1nm' => method_exists( $download, 'get_name' ) ? $download->get_name() : '',
				'pr1ca' => $first_category,
				'pr1va' => $variation,
				'pr1pr' => $price,
			);

			$this->hit( $attr );
		}
	}

	/**
	 * Generate UUID v4 function - needed to generate a CID when one isn't available.
	 *
	 * @return string
	 */
	public function generate_uuid() {
		return sprintf(
			'%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
			mt_rand( 0, 0xffff ),
			mt_rand( 0, 0xffff ),
			mt_rand( 0, 0xffff ),
			mt_rand( 0, 0x0fff ) | 0x4000,
			mt_rand( 0, 0x3fff ) | 0x8000,
			mt_rand( 0, 0xffff ),
			mt_rand( 0, 0xffff ),
			mt_rand( 0, 0xffff )
		);
	}

	/**
	 * Hit method for tracking (Measurement Protocol).
	 *
	 * Logs via {@see wp_analytify_pro_log_measurement_remote_result()} (redacted payload), only on
	 * `WP_Error` or HTTP status &gt;= 400.
	 *
	 * @since 9.0.0
	 * @param array<string, mixed> $attr  Hit parameters.
	 * @param bool                 $debug When true, posts to the debug endpoint.
	 * @return void
	 */
	public function hit( $attr, $debug = false ) {
		if ( ! $this->wp_analytify ) {
			return;
		}

		$UA_id = '';
		if ( class_exists( 'WP_ANALYTIFY_FUNCTIONS' ) && method_exists( 'WP_ANALYTIFY_FUNCTIONS', 'search_profile_info' ) ) {
			$UA_id = WP_ANALYTIFY_FUNCTIONS::search_profile_info( $this->wp_analytify->settings->get_option( 'profile_for_posts', 'wp-analytify-profile' ), 'webPropertyId' );
		}

		if ( ! $UA_id ) {
			return;
		}

		$attr['tid'] = $UA_id;
		$attr['v']   = 1;

		if ( ! isset( $attr['cid'] ) ) {
			$attr['cid'] = $this->get_edd_cid();
		}

		$url = $debug ? ANALYTIFY_GOOGLE_DEBUG_MEASUREMENT_URL : ANALYTIFY_GOOGLE_MEASUREMENT_URL;

		$response = wp_remote_post(
			$url,
			array(
				'body'    => $attr,
				'timeout' => 30,
			)
		);

		if ( is_wp_error( $response ) ) {
			wp_analytify_pro_log_measurement_remote_result(
				'Failed to send EDD hit via Measurement Protocol.',
				'EDD Measurement Protocol request returned an HTTP error.',
				'WP_Analytify_EDD_Tracking_Handler::hit',
				$attr,
				$response
			);
			return;
		}

		if ( wp_remote_retrieve_response_code( $response ) >= 400 ) {
			wp_analytify_pro_log_measurement_remote_result(
				'Failed to send EDD hit via Measurement Protocol.',
				'EDD Measurement Protocol request returned an HTTP error.',
				'WP_Analytify_EDD_Tracking_Handler::hit',
				$attr,
				$response
			);
		}

		$body = wp_remote_retrieve_body( $response );

		if ( $debug ) {
		}
	}
}
