<?php
/**
 * EDD Data Manager Class.
 *
 * @package WP_Analytify_Pro
 * @since 8.0.0
 */

// phpcs:ignoreFile WordPress.Files.FileName.InvalidClassFileName

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Class WP_Analytify_EDD_Data_Manager
 *
 * Manages EDD data integration with Analytics.
 */
class WP_Analytify_EDD_Data_Manager {

	/**
	 * Get the list of downloads for tracking.
	 *
	 * @return string
	 */
	public function get_the_list() {
		global $wp_query;

		$list = 'Default';

		if ( is_search() ) :
			$list = __( 'Search results', 'wp-analytify-pro' );
		elseif ( true ) :
			// Empty condition - kept for future expansion.
		endif;

		// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.urlencode_urlencode
		return urlencode( $list );
	}

	/**
	 * Add new column payment history page.
	 *
	 * @param array<string, mixed> $columns Payment columns.
	 * @return array<string, mixed>
	 */
	public function payment_source_column( $columns ) {
		$columns['analytify_source'] = 'Source/Medium';
		return $columns;
	}

	/**
	 * Show the source/medium value on specific column.
	 *
	 * @param string $value Value to display.
	 * @param string $payment_ID Payment ID.
	 * @param string $column_name Column name.
	 * @return string
	 */
	public function payment_source_value( $value, $payment_ID, $column_name ) {
		// phpcs:ignore WordPress.NamingConventions.ValidVariableName.VariableNotSnakeCase
		if ( 'analytify_source' === $column_name ) {
			$source_medium = get_post_meta( (int) $payment_ID, 'analytify_edd_single_source', true );
			$value         = $source_medium ? $source_medium : 'None';

			// phpcs:ignore WordPress.Security.NonceVerification.Recommended
			if ( isset( $_GET['fetch_sale_source'] ) && ! $source_medium ) {
				$post_date       = get_the_date( 'Y-m-d', (int) $payment_ID );
				$start_timestamp = strtotime( $post_date . ' - 5 days' );
				$end_timestamp   = strtotime( $post_date . ' + 5 days' );
				$start_date      = $start_timestamp ? gmdate( 'Y-m-d', $start_timestamp ) : '';
				$end_date        = $end_timestamp ? gmdate( 'Y-m-d', $end_timestamp ) : '';

				// Get sources from ga4.
				if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {
					// phpcs:ignore WordPress.NamingConventions.ValidVariableName.VariableNotSnakeCase
					global $WP_ANALYTIFY;

					$stats = $WP_ANALYTIFY->get_reports(
						'analytify_edd_order_source',
						array(),
						array(
							'start' => $start_date,
							'end'   => $end_date,
						),
						array(
							'sourceMedium',
							'transactionId',
						),
						array(),
						array(
							'logic'   => 'OR',
							'filters' => array(
								array(
									'type'       => 'dimension',
									'name'       => 'transactionId',
									'match_type' => 1,
									'value'      => function_exists( 'edd_get_payment_number' ) ? edd_get_payment_number( $payment_ID ) : '',
								),
								array(
									'type'       => 'dimension',
									'name'       => 'transactionId',
									'match_type' => 1,
									'value'      => 'EDD_' . ( function_exists( 'edd_get_payment_number' ) ? edd_get_payment_number( $payment_ID ) : '' ),
								),
							),
						),
						0,
						false
					);

					if ( ! empty( $stats['rows'][0]['sourceMedium'] ) ) {
						update_post_meta( (int) $payment_ID, 'analytify_edd_single_source', $stats['rows'][0]['sourceMedium'] );
					}
				}
			}
			return $value;
		}

		return $value;
	}

	/**
	 * Fetch sale source button.
	 *
	 * @param string $which Position of the button.
	 * @return void
	 */
	public function fetch_sale_source( $which ) {
		echo '<input type="submit" class="button-secondary" value="' . esc_attr__( 'Fetch Traffic Sources', 'wp-analytify-pro' ) . '" name="fetch_sale_source" />';
	}

	/**
	 * Add option in admin bar.
	 *
	 * @param array<string, mixed> $menus Admin bar menus.
	 * @return array<string, mixed>
	 */
	public function add_admin_bar_menu( $menus ) {
		$menus['edd-dashboard'] = esc_html__( 'EDD', 'wp-analytify-pro' );
		return $menus;
	}

	/**
	 * Order detail stats display.
	 *
	 * @param int $payment_id
	 * @return void
	 */
	public function order_detail_stats( $payment_id ) {
		$source_medium = get_post_meta( $payment_id, 'analytify_edd_single_source', true );

		if ( $source_medium ) {
			echo esc_html( '<div class="edd-order-stats">' );
			echo '<h3>' . __( 'Analytics Source', 'wp-analytify-pro' ) . '</h3>';
			echo esc_html( '<p><strong>' . __( 'Source/Medium:', 'wp-analytify-pro' ) . '</strong> ' . esc_html( $source_medium ) . '</p>' );
			echo '</div>';
		}
	}
}
