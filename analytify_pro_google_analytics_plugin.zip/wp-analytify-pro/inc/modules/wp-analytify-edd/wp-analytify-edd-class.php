<?php
/**
 * EDD Addon Main Class.
 *
 * @package WP_Analytify_Pro
 */

// phpcs:ignoreFile WordPress.Files.FileName.InvalidClassFileName

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Class WP_Analytify_Edd_Addon
 *
 * Main class for EDD addon integration.
 */
class WP_Analytify_Edd_Addon extends WP_Analytify_Pro_Base {

	/**
	 * Tracking handler instance.
	 *
	 * @var object|null
	 */
	private $tracking_handler;

	/**
	 * Data manager instance.
	 *
	 * @var object|null
	 */
	private $data_manager;

	/**
	 * Track detail view array.
	 *
	 * @var array<string, mixed>
	 */
	public $track_detail_view = array();

	/**
	 * Has cart page flag.
	 *
	 * @var bool
	 */
	public $has_cart_page = false;

	/**
	 * Constructor.
	 */
	public function __construct() {

		parent::__construct();
		$this->includes();
		$this->init_components();
		$this->_hooks();
		$this->setup_constants();
	}

	/**
	 * Initialize component classes
	 *
	 * @return void
	 */
	private function init_components() {
		require_once __DIR__ . '/classes/class-edd-tracking-handler.php';
		require_once __DIR__ . '/classes/class-edd-data-manager.php';

		$this->tracking_handler = new WP_Analytify_EDD_Tracking_Handler();
		$this->data_manager     = new WP_Analytify_EDD_Data_Manager();
	}

	/**
	 * collection of all hooks
	 *
	 * @return void
	 */
	private function _hooks() {

		add_action( 'analytify_add_submenu', array( $this, 'add_menu_edd' ), 20 );
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_scipts' ) );

		// for modifing the meta links
		add_filter( 'plugin_row_meta', array( $this, 'plugin_row_meta' ), 10, 2 );

		$roles = wp_get_current_user()->roles;
		// Suppress return value warning for action callbacks
		$dummy_return = null;

		// if ( ! in_array( @$roles[0], $GLOBALS['WP_ANALYTIFY']->settings->get_option( 'exclude_users_tracking','wp-analytify-profile', array() ) ) ) {

		if ( $this->tracking_handler && is_object( $this->tracking_handler ) ) {
			add_action( 'edd_purchase_link_end', array( $this->tracking_handler, 'product_detail' ), 10, 2 );
			add_action( 'edd_pre_add_to_cart', array( $this->tracking_handler, 'add_to_cart' ), 10, 2 );
			add_action( 'edd_pre_remove_from_cart', array( $this->tracking_handler, 'remove_from_cart' ), 10, 1 );
			// add_action( 'edd_before_cart',                array( $this, 'checkout_cart_step1' ) );
			add_action( 'edd_before_checkout_cart', array( $this->tracking_handler, 'checkout_page_step' ) );
			add_action( 'edd_complete_purchase', array( $this->tracking_handler, 'checkout_complete_step' ) );
			add_action( 'edd_update_payment_status', array( $this->tracking_handler, 'transaction' ), 10, 3 );
			add_action( 'edd_update_payment_status', array( $this->tracking_handler, 'refund' ), 10, 3 );
			add_action( 'edd_insert_payment', array( $this->tracking_handler, 'save_user_cid' ), 10, 2 );
			add_action( 'edd_purchase_link_end', array( $this->tracking_handler, 'add_impression' ), 10, 2 );
			add_action( 'wp_footer', array( $this->tracking_handler, 'track_impressions' ) );
			add_action( 'edd_download_before', array( $this->tracking_handler, 'track_single_product_view' ) );
		}

		// }
			// add_action( 'admin_init',                     array( $this, 'analytify_activate_license' ) );
			// add_action( 'admin_init',                     array( $this, 'analytify_activate_license' ) );
					add_action( 'analytify_dashboad_dropdown_option', array( $this, 'dashboad_dropdown_option' ) );

		if ( $this->data_manager && is_object( $this->data_manager ) ) {
			add_action( 'edd_view_order_details_sidebar_before', array( $this->data_manager, 'order_detail_stats' ) );
			add_filter( 'edd_payments_table_columns', array( $this->data_manager, 'payment_source_column' ) );
			add_filter( 'edd_payments_table_column', array( $this->data_manager, 'payment_source_value' ), 10, 3 );
			add_action( 'edd_payment_advanced_filters_row', array( $this->data_manager, 'fetch_sale_source' ) );
			add_filter( 'analytify_admin_bar_menu', array( $this->data_manager, 'add_admin_bar_menu' ), 20, 1 );
		}
	}

	/**
	 * Plugin row meta links
	 *
	 * @param array<int|string, mixed> $input already defined meta links
	 * @param string                   $file plugin file path and name being processed
	 * @return array<int|string, mixed> $input
	 */
	function plugin_row_meta( array $input, string $file ): array {

		// exit if its other plugins
		if ( 'wp-analytify-edd/wp-analytify-edd.php' !== $file ) {
			return $input; }

		// remove the 'view details' org link
		if ( isset( $input[2] ) ) {
			unset( $input[2] );
		}

		// add the plugin site link
		$input[] = '<a target="_blank" href="https://analytify.io/add-ons/easy-digital-downloads/">Visit plugin site</a>';

		return $input;
	}


	/**
	 * Add dropdown option for edd dashboard.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function dashboad_dropdown_option() {
		echo esc_html( '<li><a href="' . admin_url( 'admin.php?page=edd-dashboard' ) . '">EDD</a></li>' );
	}

	/**
	 * Display EDD Dashboard link in menu under Analytify
	 *
	 * @return void
	 */
	function add_menu_edd() {
		add_submenu_page(
			'analytify-dashboard',
			esc_html__( 'Track everything in EDD with Analytify.', 'wp-analytify-pro' ),
			esc_html__( 'EDD', 'wp-analytify-pro' ),
			'edit_posts',
			'edd-dashboard',
			array(
				__CLASS__,
				'menu_page',
			),
			17
		);
	}

	/**
	 * Include file for EDD dashboard page
	 *
	 * @access public
	 * @return void
	 */
	public static function menu_page() {

		$screen = get_current_screen();

		if ( $screen && strpos( $screen->base, 'edd-dashboard' ) !== false ) {
			$edd_plugin_dir = defined( 'EDD_ANALYTIFY_PRO_PLUGIN_DIR' ) ? EDD_ANALYTIFY_PRO_PLUGIN_DIR : __DIR__;
			include $edd_plugin_dir . '/includes/edd-dashboard.php';
		}
	}


	/**
	 * Include necessary files
	 *
	 * @access      private
	 * @since       1.0.0
	 * @return      void
	 */
	private function includes() {
	}


	/**
	 * Setup plugin constants
	 *
	 * @access      private
	 * @since       1.0.0
	 * @return      void
	 */
	private function setup_constants() {

		// Setting Global Values
		$this->define( 'EDD_ANALYTIFY_PLUGIN_FILE', __FILE__ );
		$this->define( 'EDD_ANALYTIFY_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );
		$this->define( 'EDD_ANALYTIFY_PRO_PLUGIN_DIR', __DIR__ );
		$this->define( 'EDD_ANALYTIFY_PRODUCT_NAME', 'Enhanced Ecommerce Google Analytics for Easy Digital Downloads Addon' );
		$this->define( 'EDD_ANALYTIFY_PRODUCT_ID', '1352' );
		$this->define( 'EDD_ANALYTIFY_STORE_URL', 'https://analytify.io' );
	}

	/**
	 * Define constant if not already set
	 *
	 * @param  string      $name
	 * @param  string|bool $value
	 * @return void
	 */
	private function define( $name, $value ) {
		if ( ! defined( $name ) ) {
			define( $name, $value );
		}
	}


	/**
	 *
	 *  Include admin JS scripts.
	 *
	 *  @since 1.0.0
	 *  @return void
	 */
	function admin_scipts() {
		wp_enqueue_script( 'analytify_edd_main_js', plugins_url( 'assets/js/main' . analytify_pro_get_asset_suffix() . '.js', __FILE__ ), array(), ANALYTIFY_PRO_VERSION, true );
	}

	/**
	 *
	 * Deactivate EDD License.
	 *
	 * @since 1.0.0
	 */
	// function analytify_deactivate_license() {

	// Listen for our activate button to be clicked.
	// if ( isset( $_POST['analytify_woo_license_deactivate'] ) ) {

	// Run a quick security check.
	// if ( ! check_admin_referer( 'analytify_nonce', 'analytify_nonce' ) ) {
	// return; // get out if we didn't click the Activate button
	// }
	// Retrieve the license from the database.
	// $license = trim( get_option( 'analytify_edd_license_key' ) );

	// Data to send in our API request.
	// $api_params = array(
	// 'edd_action' => 'deactivate_license',
	// 'license'   => $license,
	// 'item_id' => EDD_ANALYTIFY_PRODUCT_ID, // The name of our product in EDD.
	// 'url'       => home_url(),
	// );

	// Call the custom API.
	// $response = wp_remote_get( esc_url_raw( add_query_arg( $api_params, EDD_ANALYTIFY_STORE_URL ) ), array( 'timeout' => 30, 'sslverify' => false ) );

	// make sure the response came back okay
	// if ( is_wp_error( $response ) ) {
	// return false; }

	// decode the license data
	// $license_data = json_decode( wp_remote_retrieve_body( $response ) );

	// $license_data->license will be either "deactivated" or "failed"
	// if ( $license_data->license == 'deactivated' ) {

	// delete_option( 'analytify_edd_license_key' );
	// unset( $license );
	// delete_option( 'analytify_edd_license_status' );

	// }
	// }
	// }



	/**
	 *
	 * Activate EDD Addon Licence.
	 *
	 * @since 1.0.0
	 */
	// function analytify_activate_license() {

	// listen for our activate button to be clicked
	// if ( isset( $_POST['analytify_edd_license_activate'] ) ) {

	// run a quick security check
	// if ( ! check_admin_referer( 'analytify_nonce', 'analytify_nonce' ) ) {

	// return; // get out if we didn't click the Activate button
	// }
	// retrieve the license from the database
	// $license = trim( get_option( 'analytify_edd_license_key' ) );

	// data to send in our API request
	// $api_params = array(
	// 'edd_action' => 'activate_license',
	// 'license'    => $license,
	// 'item_id'  => EDD_ANALYTIFY_PRODUCT_ID, // the name of our product in EDD
	// 'url'        => home_url(),
	// );

	// Call the custom API.
	// $response = wp_remote_get( esc_url_raw( add_query_arg( $api_params, EDD_ANALYTIFY_STORE_URL ) ), array( 'timeout' => 15, 'sslverify' => false ) );
	// print_r($response);
	// make sure the response came back okay
	// if ( is_wp_error( $response ) ) {

	// return false; }

	// decode the license data
	// $license_data = json_decode( wp_remote_retrieve_body( $response ) );

	// $license_data->license will be either "valid" or "invalid"
	// update_option( 'analytify_edd_license_status', $license_data->license );

	// }
	// }


	/**
	 * Register EDD options
	 *
	 * @return void
	 */
	function wp_analytify_edd_register_option() {
		// creates our settings in the options table
		register_setting( 'analytify-settings', 'analytify_edd_license_key', array( $this, 'analytify_edd_sanitize_license' ) );
	}



	/**
	 * Formats a given amount with the specified or default currency code.
	 *
	 * This function retrieves the currency symbol based on the provided currency code
	 * or the default currency code set by Easy Digital Downloads (EDD). It then formats
	 * the amount to two decimal places and appends the currency symbol.
	 *
	 * @param float $amount The monetary amount to be formatted.
	 * @param string $currency_code Optional. The currency code to use for formatting. 
	 *                              Defaults to the currency code set by EDD.
	 * @return string The formatted currency string with the symbol and amount.
	 */
	public static function analytify_edd_format_currency($amount, $currency_code = '') {
		if (empty($currency_code)) {
			$currency_code = edd_get_currency();
		}
		$currency_symbol = edd_currency_symbol($currency_code);
		return $currency_symbol . number_format((float) $amount, 2);
	}




	/**
	 * Track Cart Page - Step 1.
	 *
	 * @since 1.0.0
	 */
	// public function checkout_cart_step1() {

	// $items = $this->get_cart_items();

	// $attr = array_merge( array(
	// 't'   => 'event',
	// 'ec'  => 'Tracking by Analytify EDD',
	// 'ea'  => 'Checkout',
	// 'el'  => 'cart',
	// 'pa'  => 'checkout',
	// 'cos' => '1',
	// 'col' => '',
	// ), $items );

	// $this->hit( $attr );

	// }
}//end class
