<?php
/**
 * EDD Addon Loader.
 *
 * @package WP_Analytify_Pro
 */

// phpcs:ignoreFile WordPress.Files.FileName.InvalidClassFileName

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Class Analytify_EDD_Loader
 *
 * Main loader class for EDD addon.
 */
class Analytify_EDD_Loader {

	/**
	 * Singleton instance.
	 *
	 * @var self|null
	 */
	public static $instance;

	/**
	 * Version number.
	 *
	 * @var string
	 */
	public $version;

	/**
	 * Get singleton instance
	 *
	 * @return self
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->version = analytify_pro_get_asset_version();
		$this->define_constants();
		$this->hooks();
		$this->may_be_load_addon();
	}
	/**
	 * Load addon if conditions are met
	 *
	 * @return void
	 */
	public function may_be_load_addon() {
		/**
		* Check for EDD
		*/
		if ( ! class_exists( 'Easy_Digital_Downloads' ) ) {
			add_action( 'admin_enqueue_scripts', array( $this, 'wpa_edd_notices_scripts' ) );
			return;
		} elseif (
			file_exists( WP_PLUGIN_DIR . '/wp-analytify-pro/wp-analytify-pro.php' )
			&& function_exists( 'wp_analytify_pro_load' )
			&& class_exists( 'WP_Analytify_Pro_Base' )
		) {
			$edd_plugin_dir = defined( 'EDD_ANALYTIFY_PRO_PLUGIN_DIR' ) ? EDD_ANALYTIFY_PRO_PLUGIN_DIR : __DIR__;
			include_once $edd_plugin_dir . '/wp-analytify-edd-class.php';
			new WP_Analytify_Edd_Addon();
		} else {
			add_action( 'admin_enqueue_scripts', array( $this, 'wpa_edd_notices_scripts' ) );
		}
	}

	/**
	 * Define constants
	 *
	 * @return void
	 */
	public function define_constants() {
		define( 'EDD_ANALYTIFY_PRO_ADDON_VERSION', analytify_pro_get_asset_version() );
		define( 'EDD_ANALYTIFY_PRO_PLUGIN_DIR', __DIR__ );
	}
	/**
	 * Setup hooks
	 *
	 * @return void
	 */
	public function hooks() {
		add_action( 'admin_notices', array( $this, 'wpa_edd_install_analytify_pro' ) );
		add_action( 'admin_notices', array( $this, 'wpa_edd_active_analytify_pro' ) );
		add_action( 'admin_notices', array( $this, 'install_edd' ) );
		add_action( 'admin_notices', array( $this, 'active_edd' ) );
		add_action( 'init', array( $this, 'wp_analytify_edd_load_text_domain' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'edd_admin_styles' ) );
	}
	/**
	 * Admin notices scripts.
	 *
	 * @return void
	 */
	public function wpa_edd_notices_scripts() {
		wp_enqueue_style( 'analytify-edd-notices', plugins_url( 'assets/css/notices' . analytify_pro_get_asset_suffix() . '.css', __FILE__ ), array(), analytify_pro_get_asset_version() );
	}

	/**
	 * Check if Analytify Pro is installed
	 *
	 * @return void
	 */
	public function wpa_edd_install_analytify_pro() {
		if ( ! file_exists( WP_PLUGIN_DIR . '/wp-analytify-pro/wp-analytify-pro.php' ) ) {
			// $class   = 'notice notice-error is-dismissible';
			// printf( '<div class="%1$s"><p>%2$s</p></div>', $class, $message );
			$message = __( '<strong>Attention:</strong> Please install Analytify Pro to use Analytify for Easy Digital Downloads addon.', 'wp-analytify-pro' );

			$this->wp_analytify_edd_tracking_notice( $message, 'wp-analytify-danger' );
		}
	}

	/**
	 * Check if Analytify Pro is active
	 *
	 * @return void
	 */
	public function wpa_edd_active_analytify_pro() {
		if ( ! class_exists( 'WP_Analytify_Pro_Base' ) ) {
			// $class   = 'notice notice-error is-dismissible';
			// printf( '<div class="%1$s"><p>%2$s</p></div>', $class, $message );
			$message = __( '<strong>Attention:</strong> Please active Analytify Pro to use Analytify for Easy Digital Downloads addon.', 'wp-analytify-pro' );

			$this->wp_analytify_edd_tracking_notice( $message, 'wp-analytify-danger' );
		}
	}

	/**
	 * Check if EDD is installed
	 *
	 * @return void
	 */
	public function install_edd() {
		if ( ! file_exists( WP_PLUGIN_DIR . '/easy-digital-downloads/easy-digital-downloads.php' ) && ! file_exists( WP_PLUGIN_DIR . '/easy-digital-downloads-pro/easy-digital-downloads.php' ) ) {
			$message = __( '<strong>Attention:</strong> Analytify for Easy Digital Downloads addon works with Easy Digital Downloads plugin, Please Install Easy Digital Downloads plugin.', 'wp-analytify-pro' );

			$this->wp_analytify_edd_tracking_notice( $message, 'wp-analytify-danger' );
		}
	}

	/**
	 * Check if EDD is active
	 *
	 * @return void
	 */
	public function active_edd() {
		if ( file_exists( WP_PLUGIN_DIR . '/easy-digital-downloads/easy-digital-downloads.php' ) && ! class_exists( 'Easy_Digital_Downloads' ) ) {
			$message = __( '<strong>Attention:</strong> Analytify for Easy Digital Downloads addon works with Easy Digital Downloads plugin, Please activate Easy Digital Downloads plugin.', 'wp-analytify-pro' );

			$this->wp_analytify_edd_tracking_notice( $message, 'wp-analytify-danger' );
		}
	}

	/**
	 * Add custom admin notice
	 *
	 * @param  string $message Custom Message.
	 * @param  string $class wp-analytify-success,wp-analytify-danger.
	 * @return void
	 */
	// phpcs:ignore Universal.NamingConventions.NoReservedKeywordParameterNames.classFound
	public function wp_analytify_edd_tracking_notice( $message, $class = 'wp-analytify-success' ) {
		// Only show notices on allowed pages.
		$screen = get_current_screen();
		
		if ( ! $screen ) {
			return;
		}
		
		$allowed_parent_bases = array(
			'analytify-dashboard',
			'plugins',
			'analytify-settings',
			'analytify-license',
			'analytify-addons',
			'dashboard',
		);
		
		$allowed_screen_ids = array(
			'plugins',
			'dashboard',
		);
		
		// Check if we're on an allowed page.
		$is_allowed = in_array( $screen->parent_base, $allowed_parent_bases, true )
			|| in_array( $screen->id, $allowed_screen_ids, true )
			|| ( isset( $_GET['page'] ) && strpos( $_GET['page'], 'analytify' ) === 0 );
		
		// Don't show notice if not on allowed page.
		if ( ! $is_allowed ) {
			return;
		}
		
		// Sanitize message to only allow <strong> tags
		$sanitized_message = strip_tags($message, '<strong>');
		$notice_id = 'analytify_notice_' . md5( $sanitized_message );

		?>
		<div class="wp-analytify-notification <?php echo esc_attr( $class ); ?>" id="<?php echo esc_attr( $notice_id ); ?>">
			<a class="wp-analytify-notice-dismiss"
				href="#"
				aria-label="<?php esc_attr_e( 'Dismiss the notice', 'wp-analytify-pro' ); ?>"
				onclick="dismissAnalytifyNotice('<?php echo esc_js( $notice_id ); ?>'); return false;">&times;</a>
			<div class="wp-analytify-notice-logo">
				<img src="<?php echo esc_url( plugins_url( 'assets/img/logo.svg', __FILE__ ) ); ?>"
					alt="<?php esc_attr_e( 'notice', 'wp-analytify-pro' ); ?>">
			</div>
			<div class="wp-analytify-notice-discription">
				<p><?php echo $sanitized_message; ?></p>
			</div>
		</div>
		<?php
	}


	/**
	 * Add notice script
	 *
	 * @return void
	 */
	public function wp_analytify_edd_notice_script() {
		?>
		<script type="text/javascript">
			function dismissAnalytifyNotice(noticeId) {
				document.getElementById(noticeId).style.display = 'none';
				localStorage.setItem('analytify_stats_refreshed_dismissed', '1');
				var ajaxurl = '<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>';
				var data = {
					'action': 'dismiss_analytify_notice',
					'notice_id': noticeId
				};
				jQuery.post(ajaxurl, data, function(response) {
				});
			}
		</script>
		<?php
	}

	/**
	 * Dismiss notice via AJAX
	 *
	 * @return void
	 */
	public function dismiss_analytify_edd_notice() {
		// phpcs:disable WordPress.Security.NonceVerification.Missing
		if ( isset( $_POST['notice_id'] ) ) {
			update_option( sanitize_text_field( wp_unslash( $_POST['notice_id'] ) ), true );
			// phpcs:enable WordPress.Security.NonceVerification.Missing
			wp_send_json_success();
		} else {
			wp_send_json_error();
		}
	}

	/**
	 * Load TextDoamin
	 *
	 * @since 1.0.2
	 * @return void
	 */
	public function wp_analytify_edd_load_text_domain() {
		// Text domain loaded by main Pro plugin.
		// All translations now use 'wp-analytify-pro' text domain.
	}

	/**
	 * Enqueue admin styles
	 *
	 * @return void
	 */
	public function edd_admin_styles() {
		$edd_version = defined( 'EDD_ANALYTIFY_PRO_ADDON_VERSION' ) ? EDD_ANALYTIFY_PRO_ADDON_VERSION : analytify_pro_get_asset_version();
		wp_enqueue_style( 'wp-analytify-edd-funnel-style', plugins_url( 'assets/css/edd-funnel' . analytify_pro_get_asset_suffix() . '.css', __FILE__ ), array(), $edd_version );
		$analytify_plugin_url = plugin_dir_url( 'wp-analytify/wp-analytify.php' );
	}
}
Analytify_EDD_Loader::get_instance();

