<?php
/**
 * Measuring ROI View.
 *
 * @package WP_Analytify_Pro
 */

/**
 *  Show Measuring ROI
 *
 * @param  mixed                $current Analytify Free Object.
 * @param  array<string, mixed> $stats   Contains stats that are fetch from google.
 * @return void
 * @since  1.0.0
 */
function pa_include_edd_measuring_roi( $current, $stats ) {
	// Set famous source from first row for footer message.
	$famous = '';
	if ( is_array( $stats ) && isset( $stats['rows'][0]['sourceMedium'] ) ) {
		$famous = $stats['rows'][0]['sourceMedium'];
	}
	?>
	<div class="analytify_general_status analytify_status_box_wraper">
		<div class="analytify_status_header">
			<h3><?php esc_html_e( 'Measuring ROI', 'wp-analytify-pro' ); ?></h3>
		</div>
		<div class="analytify_status_body">
	
			<div class="analytify_status_body_content">
	
				<table class="analytify_data_tables analytify_edd_roi_stats wp_analytify_paginated" data-product-per-page="10">
					<thead>
						<tr>
							<th class="analytify_table_header_no_events">#</th>
							<th><?php esc_html_e( 'Source/Medium', 'wp-analytify-pro' ); ?></th>
							<th class="analytify_txt_center"><?php esc_html_e( 'Sessions', 'wp-analytify-pro' ); ?></th>
							<th class="analytify_txt_center"><?php esc_html_e( 'Bounce Rate', 'wp-analytify-pro' ); ?></th>
							<th class="analytify_txt_center"><?php esc_html_e( 'Transactions Revenue', 'wp-analytify-pro' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php
						$currency_symbol = edd_currency_symbol();
						$i               = 0;
						if ( is_array( $stats ) && isset( $stats['rows'] ) && ! empty( $stats['rows'] ) ) :
							foreach ( $stats['rows'] as $stat ) :
								?>
								<tr>
									<td><?php echo esc_html( ++$i ); ?></td>
									<td>
										<?php echo isset( $stat['sourceMedium'] ) ? esc_html( $stat['sourceMedium'] ) : ''; ?>
									</td>
									<td class="analytify_txt_center">
										<?php
										echo class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' )
											? esc_html( WPANALYTIFY_Utils::pretty_numbers( $stat['sessions'] ?? 0 ) )
											: esc_html( $stat['sessions'] ?? 0 );
										?>
									</td>
									<td class="analytify_txt_center">
										<?php
										echo class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'fraction_to_percentage' )
											? esc_html( WPANALYTIFY_Utils::fraction_to_percentage( $stat['bounceRate'] ?? 0 ) ) . '%'
											: esc_html( ( $stat['bounceRate'] ?? 0 ) * 100 ) . '%';
										?>
									</td>
									<td class="analytify_txt_center">
									<?php
									$currency_code = ( isset( $stat['currencyCode'] ) && '(not set)' !== $stat['currencyCode'] ) ? $stat['currencyCode'] : '';
										echo esc_html( WP_Analytify_Edd_Addon::analytify_edd_format_currency( $stat['purchaseRevenue'], $currency_code ) );
									?>
									</td>
								</tr>
								<?php
							endforeach;
						else :
							?>
							<tr>
								<td colspan="5" class="analytify_no_data">
								<?php esc_html_e( 'No source data found.', 'wp-analytify-pro' ); ?>
							</td>
							</tr>
							<?php
						endif;
						?>
					</tbody>
				</table>

			</div>
		</div>
		<div class="analytify_status_footer">
			<span class="analytify_info_stats">
			<?php
			if ( ! empty( $famous ) ) :
				printf(
					// translators: %1$s is strong opening tag, %2$s is source name, %3$s is strong closing tag.
					esc_html__( 'Did you know the famous Source of Sale is %1$s %2$s %3$s?', 'wp-analytify-pro' ),
					'<strong>',
					esc_html( trim( $famous ) ),
					'</strong>'
				);
			else :
				esc_html_e( 'List of all the sources of sale.', 'wp-analytify-pro' );
			endif;
			?>
			</span>
			<div class="wp_analytify_pagination"></div>
		</div>
	</div>
	<?php
}
?>

<script type="text/javascript">
	jQuery(document).ready(function($) {
		wp_analytify_paginated();
	});
</script>
