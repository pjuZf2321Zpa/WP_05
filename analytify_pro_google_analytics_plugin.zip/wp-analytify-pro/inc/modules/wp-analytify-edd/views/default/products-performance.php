<?php
/**
 * Products Performance View.
 *
 * @package WP_Analytify_Pro
 */

	/**
	 *  Show Products performance order by sales quantity.
	 *
	 * @param  mixed                $current Analytify Free Object.
	 * @param  array<string, mixed> $stats   Contains stats that are fetch from google.
	 * @return void
	 * @since  1.0.0
	 */
function pa_include_edd_products( $current, $stats ) {

	$famous = '';
	if ( is_array( $stats ) && isset( $stats['rows'] ) && isset( $stats['rows'][0]['itemName'] ) ) {
		$famous = $stats['rows'][0]['itemName'];
	}

	?>
	<div class="analytify_general_status analytify_status_box_wraper">
		<div class="analytify_status_header">
			<h3><?php esc_html_e( 'Products Performance', 'wp-analytify-pro' ); ?></h3>
		</div>
		<div class="analytify_status_body">

			<table class="analytify_data_tables wp_analytify_paginated" data-product-per-page="10">
				<thead>
					<tr>
						<th class="analytify_table_header_no_events">
							#
						</th>
						<th>
							<?php esc_html_e( 'Name', 'wp-analytify-pro' ); ?>
						</th>
						<th>
							<?php esc_html_e( 'Product Revenue', 'wp-analytify-pro' ); ?>
						</th>
						<th class="">
							<?php esc_html_e( 'Product Views', 'wp-analytify-pro' ); ?>
						</th>
						<th class="">
							<?php esc_html_e( 'Unique Purchases', 'wp-analytify-pro' ); ?>
						</th>
						<th class="">
							<?php esc_html_e( 'Items Added To Cart', 'wp-analytify-pro' ); ?>
						</th>
						<th class="">
							<?php esc_html_e( 'Cart-to-Detail Rate', 'wp-analytify-pro' ); ?>
						</th>
					<?php // phpcs:disable Squiz.PHP.CommentedOutCode.Found, Squiz.Commenting.InlineComment.InvalidEndChar ?>
					<!-- <th class="">
						<?php // esc_html_e( 'Buy-to-Detail Rate', 'wp-analytify-pro' ); ?>
					</th> -->
					<?php // phpcs:enable Squiz.PHP.CommentedOutCode.Found, Squiz.Commenting.InlineComment.InvalidEndChar ?>
					</tr>
				</thead>
				<tbody>

					<?php
					if ( is_array( $stats ) && ! empty( $stats['rows'] ) ) {
						$i = 0;
						foreach ( $stats['rows'] as $stat ) {
							++$i;
							?>
							<tr>
								<td  data-heading="#">
									<?php echo esc_html( $i ); ?>
								</td>
								<td data-heading="<?php esc_attr_e( 'Name', 'wp-analytify-pro' ); ?>">
									<?php echo esc_html( $stat['itemName'] ); ?>
								</td>
								<td data-heading="<?php esc_attr_e( 'Product Revenue', 'wp-analytify-pro' ); ?>" class="analytify_txt_center">
								<?php
								$currency_code = ( isset( $stat['currencyCode'] ) && '(not set)' !== $stat['currencyCode'] ) ? $stat['currencyCode'] : '';
									echo esc_html( WP_Analytify_Edd_Addon::analytify_edd_format_currency( $stat['itemRevenue'], $currency_code ) );
								?>
								</td>
								<td data-heading="<?php esc_attr_e( 'Product Views', 'wp-analytify-pro' ); ?>" class="analytify_txt_center">
									<?php echo esc_html( $stat['itemsViewed'] ); ?>
								</td>
								<td data-heading="<?php esc_attr_e( 'Unique Purchases', 'wp-analytify-pro' ); ?>" class="analytify_txt_center">
									<?php echo esc_html( $stat['itemsPurchased'] ); ?>
								</td>
								<td data-heading="<?php esc_attr_e( 'Items Added To Cart', 'wp-analytify-pro' ); ?>" class="analytify_txt_center">
									<?php echo esc_html( $stat['itemsAddedToCart'] ); ?>
								</td>
								<td data-heading="<?php esc_attr_e( 'Cart-to-Detail Rate', 'wp-analytify-pro' ); ?>">
									<?php
										$rate            = isset( $stat['cartToViewRate'] ) ? (float) $stat['cartToViewRate'] : 0;
										$rate_percentage = min( 100, round( $rate * 100, 2 ) );
									?>
									<?php echo esc_html( $rate_percentage ); ?> %
									<span class="analytify_bar_graph">
										<span style="width: <?php echo esc_attr( min( 100, $rate_percentage ) ); ?>%;"></span>
									</span>
								</td>
								<?php // phpcs:disable Squiz.PHP.CommentedOutCode.Found, Squiz.Commenting.InlineComment.InvalidEndChar ?>
								<!-- <td>
									<?php // $percent_quantity = number_format( $stat[5], 2 ); ?>
									<?php // echo esc_html( round( $stat[7], 2 ); ?> %
									<span class="analytify_bar_graph">
										<span style="width: <?php // echo $stat[7] ?>% );"></span>
									</span>
								</td> -->
								<?php // phpcs:enable Squiz.PHP.CommentedOutCode.Found, Squiz.Commenting.InlineComment.InvalidEndChar ?>
							</tr>
							<?php
						}
					} else {
						?>
						<tr>
							<td class="analytify_td_error_msg" colspan="7">
								<?php
								if ( is_object( $current ) && method_exists( $current, 'no_records' ) ) {
									$current->no_records();
								} else {
									esc_html_e( 'No records found', 'wp-analytify-pro' );
								}
								?>
							</td>
						</tr>
						<?php
					}
					?>
				</tbody>
			</table>
		</div>
		<div class="analytify_status_footer">
			<?php if ( isset( $stat['itemName'] ) ) : ?>
				<span class="analytify_info_stats">
					<?php
					// translators: %1$s is strong opening tag, %2$s is product name, %3$s is strong closing tag.
					printf( esc_html__( 'Did you know the most selling product (quantity wise) in your store is %1$s %2$s %3$s', 'wp-analytify-pro' ), '<strong>', esc_html( $famous ), '</strong>' );
					?>
				</span>
			<?php endif; ?>
			<div class="wp_analytify_pagination"></div>
		</div>
	</div>
<?php } ?>

<script type="text/javascript">
	jQuery(document).ready(function($) {
		wp_analytify_paginated();
	});
</script>
