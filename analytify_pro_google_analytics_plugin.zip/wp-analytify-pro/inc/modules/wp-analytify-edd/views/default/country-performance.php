<?php
/**
 * Country Performance View.
 *
 * @package WP_Analytify_Pro
 */

/**
 * Display EDD country performance statistics
 *
 * @param mixed                $current Analytify instance.
 * @param array<string, mixed> $country_stats Country statistics data.
 * @return void
 */
function pa_include_country_performance( $current, $country_stats ) {
	?>
	<div class="analytify_general_status analytify_status_box_wraper">
		<div class="analytify_status_header">
			<h3><?php esc_html_e( 'Top Countries by Sales', 'wp-analytify-pro' ); ?></h3>
		</div>

		<div class="analytify_status_body">
			<?php
			if ( ! empty( $country_stats['rows'] ) ) {
				$code           = '';
				$lowest_number  = 0;
				$highest_number = $country_stats['aggregations']['ecommercePurchases'];

				if ( $highest_number > 0 ) {
					?>
					<script>
					jQuery(document).ready(function ($) {

							// Initialize after dom ready
							const geographic_stats_graph = echarts.init( document.getElementById('analytify_geographic_stats_graph' ) );

							const geographic_stats_graph_option = {
								tooltip : {
									trigger: 'item',
									formatter : function( params, ticket, callback ) {
										let value = (params.value + '').split('.');

										if ( value[0]  != '-' ) {
										value = value[0];
										} else {
										value = 0;
										}
										let revenue = 0;
										if (params.data && params.data.revenue != null) {
											revenue = params.data.revenue;
										}
										return  params.name + '<br />' + 'No of sales : ' + value + '<br /> Revenue : ' + "<?php echo esc_js( function_exists( 'edd_currency_symbol' ) ? edd_currency_symbol() : '$' ); ?>" + ' ' + revenue;
									}
								},
								toolbox: {
									show : false,
									orient : 'horizontal',
									x: 'right',
									y: '10',
									feature : {
										restore : { show: true },
										saveAsImage : { show: true }
									}
								},
								dataRange: {
									min: <?php echo esc_html( $lowest_number ); ?>,
									max: <?php echo esc_html( $highest_number ); ?>,
									text: ['High','Low'],
									realtime: true,
									calculable : true,
									color: ['#ff5252','#ffbc00','#448aff']
								},
								series : [
									{
										name: '<?php esc_html_e( 'Geographic Stats', 'wp-analytify-pro' ); ?>',
										type: 'map',
										mapType: 'world',
										roam: 'move',
										scrollwheel: false,
										mapLocation: {
											y : 60
										},
										itemStyle:{
											emphasis:{label:{show:true}}
										},
										data:[
									<?php foreach ( $country_stats['rows'] as $country ) : ?>
									{name : '<?php echo esc_html( 'United States' === $country['country'] ? 'United States of America' : $country['country'] ); ?>', value : <?php echo esc_html( $country['ecommercePurchases'] ); ?>, revenue : '<?php echo esc_html( number_format( $country['purchaseRevenue'], 2 ) ); ?>'},
									<?php endforeach; ?>
										]
									}
								]
							};

							// Load data into the ECharts instance
							geographic_stats_graph.setOption( geographic_stats_graph_option );

							window.onresize = function () {
								geographic_stats_graph.resize();
							}
						});

					</script>
					<div class="analytify_txt_center analytify_graph_wraper">
						<div id="analytify_geographic_stats_graph" style="height:600px"></div>
					</div>
					<?php
				}
				?>
				<div class="analytify_clearfix">
					<table class="analytify_data_tables analytify_border_th_tp wp_analytify_paginated" data-product-per-page="10">
						<thead>
							<tr>
								<th class="analytify_txt_left"><?php esc_html_e( 'Top Countries', 'wp-analytify-pro' ); ?></th>
								<th class="analytify_value_row"><?php esc_html_e( 'No. of Sales', 'wp-analytify-pro' ); ?></th>
								<th class="analytify_value_row"><?php esc_html_e( 'Revenue', 'wp-analytify-pro' ); ?></th>
							</tr>
						</thead>
						<tbody>
							<?php
							foreach ( $country_stats['rows'] as $row ) {
								?>
									<tr>
										<td><span class="<?php echo esc_attr( function_exists( 'pretty_class' ) ? pretty_class( $row['country'] ) : 'analytify_default_flag' ); ?> analytify_flages"></span> <?php echo esc_html( $row['country'] ); ?></td>
										<td class="analytify_txt_center"><?php echo esc_html( $row['ecommercePurchases'] ); ?></td>
										<td class="analytify_txt_center">
											<?php
												$currency_code = ( isset( $row['currencyCode'] ) && '(not set)' !== $row['currencyCode'] ) ? $row['currencyCode'] : '';
												echo esc_html( WP_Analytify_Edd_Addon::analytify_edd_format_currency( $row['purchaseRevenue'], $currency_code ) );
											?>
										</td>
									</tr>
								<?php
							}
							?>
						</tbody>
					</table>
				</div>
				<div class="analytify_status_footer">
					<div class="wp_analytify_pagination"></div>
				</div>
				<?php
			} elseif ( is_object( $current ) && method_exists( $current, 'no_records' ) ) {
					$current->no_records();
			} else {
				esc_html_e( 'No records found', 'wp-analytify-pro' );
			}
			?>
		</div>
	</div>
	<?php
}
?>

<script type="text/javascript">
	jQuery(document).ready(function($) {
		wp_analytify_paginated();
	});
</script>

