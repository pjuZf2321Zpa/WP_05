<?php
/**
 * Categories Performance View.
 *
 * @package WP_Analytify_Pro
 */

/**
 * Display EDD categories performance statistics
 *
 * @param mixed                $current Analytify instance.
 * @param array<string, mixed> $stats Statistics data.
 * @return void
 */
function pa_include_edd_categories_performance( $current, $stats ) {

	$famous = '';
	if ( is_array( $stats ) && isset( $stats['rows'] ) && isset( $stats['rows'][0][0] ) ) {
		$famous = $stats['rows'][0][0];
	}

	?>
	<div class="analytify_general_status analytify_status_box_wraper">
	<div class="analytify_status_header">
		<h3><?php esc_html_e( 'Product Categories Analysis', 'wp-analytify-pro' ); ?></h3>
	</div>
	<div class="analytify_status_body">

		<table class="analytify_data_tables">
		<thead>
			<tr>
			<th class="analytify_table_header_no_events">
				#
			</th>
			<th>
				<?php esc_html_e( 'Name', 'wp-analytify-pro' ); ?>
			</th>
			<th>
				<?php esc_html_e( 'Product Revenue', 'wp-analytify-pro' ); ?>
			</th>
			<th class="">
				<?php esc_html_e( 'Unique Purchases', 'wp-analytify-pro' ); ?>
			</th>
			<th class="">
				<?php esc_html_e( 'Quantity', 'wp-analytify-pro' ); ?>
			</th>
			<th class="">
				<?php esc_html_e( 'Cart-to-Detail Rate', 'wp-analytify-pro' ); ?>
			</th>
			<th class="">
				<?php esc_html_e( 'Buy-to-Detail Rate', 'wp-analytify-pro' ); ?>
			</th>
			</tr>
		</thead>
		<tbody>
			<?php
			if ( ! empty( $stats['rows'] ) ) {
				$i = 0;
				foreach ( $stats['rows'] as $stat ) {
					++$i;
					?>
				<tr>
				<td data-heading="#">
					<?php echo esc_html( $i ); ?>
				</td>
				<td data-heading="<?php esc_html_e( 'Name', 'wp-analytify-pro' ); ?>">
					<?php echo esc_html( $stat[0] ); ?>
				</td>
				<td data-heading="<?php esc_html_e( 'Product Revenue', 'wp-analytify-pro' ); ?>" class="analytify_txt_center">
					<?php echo esc_html( ( function_exists( 'edd_currency_symbol' ) ? edd_currency_symbol() : '$' ) . number_format( $stat[1], 2 ) ); ?>
				</td>
				<td data-heading="<?php esc_html_e( 'Unique Purchases', 'wp-analytify-pro' ); ?>" class="analytify_txt_center">
					<?php echo esc_html( $stat[2] ); ?>
				</td>
				<td data-heading="<?php esc_html_e( 'Quantity', 'wp-analytify-pro' ); ?>" class="analytify_txt_center">
					<?php echo esc_html( $stat[3] ); ?>
				</td>
			<td data-heading="<?php esc_html_e( 'Cart-to-Detail Rate', 'wp-analytify-pro' ); ?>">
					<?php $percent_quantity = number_format( $stat[4], 2 ); ?>
					<?php echo esc_html( $percent_quantity ); ?> %
				<span class="analytify_bar_graph">
				<span style="width: <?php echo esc_attr( $percent_quantity ); ?>%;"></span>
				</span>
			</td>
			<td data-heading="<?php esc_html_e( 'Buy-to-Detail Rate', 'wp-analytify-pro' ); ?>">
					<?php $percent_quantity = number_format( $stat[5], 2 ); ?>
					<?php echo esc_html( $percent_quantity ); ?> %
				<span class="analytify_bar_graph">
				<span style="width: <?php echo esc_attr( $percent_quantity ); ?>%;"></span>
				</span>
			</td>
				</tr>
					<?php
				}
			} else {
				?>
			<tr>
				<td  class="analytify_td_error_msg" colspan="7">
					<?php
					if ( is_object( $current ) && method_exists( $current, 'no_records' ) ) {
						$current->no_records();
					} else {
						esc_html_e( 'No records found', 'wp-analytify-pro' );
					}
					?>
				</td>
			</tr>
				<?php } ?>
			</tbody>
		</table>
		</div>
		<div class="analytify_status_footer">

		<?php if ( isset( $stat[0] ) ) : ?>
			<span class="analytify_info_stats">
			<?php
			// translators: %1$s is strong opening tag, %2$s is category name, %3$s is strong closing tag.
			printf( esc_html__( 'Did you know the famous Product Category in your store is %1$s %2$s %3$s', 'wp-analytify-pro' ), '<strong>', esc_html( $famous ), '</strong>' );
			?>
			</span>
		<?php endif; ?>

		</div>
	</div>
<?php } ?>
