<?php
/**
 * Coupons Stats View.
 *
 * @package WP_Analytify_Pro
 */

/**
 *  Show Edd Coupons stats
 *
 * @param  mixed                $current Analytify Free Object.
 * @param  array<string, mixed> $stats   Contains stats that are fetch from google.
 * @return void
 * @since  1.0.0
 */
function pa_include_edd_coupons_performance( $current, $stats ) {

		// phpcs:ignore Squiz.PHP.CommentedOutCode.Found, Squiz.Commenting.InlineComment.InvalidEndChar -- Old header include.
		// var_dump($stats['rows']);
	?>
		<div class="analytify_general_status analytify_status_box_wraper">
		<div class="analytify_status_header">
			<h3><?php esc_html_e( 'Coupons Analysis', 'wp-analytify-pro' ); ?></h3>
		</div>
		<div class="analytify_status_body">

			<div class="analytify_status_body_content">

				<table class="analytify_data_tables analytify_coupons_stats wp_analytify_paginated" data-product-per-page="10">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Coupon Code', 'wp-analytify-pro' ); ?></th>
							<th class="analytify_txt_center"><?php esc_html_e( 'Revenue', 'wp-analytify-pro' ); ?></th>
							<th class="analytify_txt_center"><?php esc_html_e( 'Quantity', 'wp-analytify-pro' ); ?></th>
							<th class="analytify_txt_center"><?php esc_html_e( 'Unique Purchases', 'wp-analytify-pro' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php
						$currency_symbol = edd_currency_symbol();

						if ( is_array( $stats ) && isset( $stats['rows'] ) && ! empty( $stats['rows'] ) ) :

							foreach ( $stats['rows'] as $stat ) :
								// Map GA4 API response fields to view fields.
								// API returns: orderCoupon (dimension), purchaseRevenue, transactions (metrics).
								$coupon_code  = isset( $stat['orderCoupon'] ) ? $stat['orderCoupon'] : ( isset( $stat['itemCategory'] ) ? $stat['itemCategory'] : '' );
								$revenue      = isset( $stat['purchaseRevenue'] ) ? (float) $stat['purchaseRevenue'] : ( isset( $stat['itemRevenue'] ) ? (float) $stat['itemRevenue'] : 0.0 );
								$transactions = isset( $stat['transactions'] ) ? (int) $stat['transactions'] : ( isset( $stat['itemsPurchased'] ) ? (int) $stat['itemsPurchased'] : 0 );
								$quantity     = isset( $stat['itemPurchaseQuantity'] ) ? (int) $stat['itemPurchaseQuantity'] : $transactions;
								?>
								<tr>
									<td data-heading="<?php esc_html_e( 'Coupon Code', 'wp-analytify-pro' ); ?>">
										<?php
										if ( ! empty( $coupon_code ) ) {
											echo esc_html( $coupon_code );
										}
										?>
									</td>
									<td data-heading="<?php esc_html_e( 'Revenue', 'wp-analytify-pro' ); ?>" class="analytify_txt_center">
									<?php
									$currency_code = ( isset( $stat['currencyCode'] ) && '(not set)' !== $stat['currencyCode'] ) ? $stat['currencyCode'] : '';
										echo esc_html( WP_Analytify_Edd_Addon::analytify_edd_format_currency( $revenue, $currency_code ) );
									?>
									</td>

									<td data-heading="<?php esc_html_e( 'Quantity', 'wp-analytify-pro' ); ?>" class="analytify_txt_center">
										<?php
										if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' ) ) {
											echo esc_html( WPANALYTIFY_Utils::pretty_numbers( $quantity ) );
										} else {
											echo esc_html( $quantity );
										}
										?>
									</td>

									<td data-heading="<?php esc_html_e( 'Unique Purchases', 'wp-analytify-pro' ); ?>" class="analytify_txt_center">
										<?php
										if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' ) ) {
											echo esc_html( WPANALYTIFY_Utils::pretty_numbers( $transactions ) );
										} else {
											echo esc_html( $transactions );
										}
										?>
									</td>
								</tr>
								<?php
							endforeach;
						else :
							?>
							<tr>
								<td class="analytify_td_error_msg" colspan="4">
									<?php
									if ( is_object( $current ) && method_exists( $current, 'no_records' ) ) {
										$current->no_records();
									} else {
										echo '<p>' . esc_html__( 'No Activity During This Period.', 'wp-analytify-pro' ) . '</p>';
									}
									?>
								</td>
							</tr>
							<?php
						endif;
						?>
					</tbody>
				</table>

			</div>
		</div>
		<div class="analytify_status_footer">
			<span class="analytify_info_stats">
			<?php
			$first_coupon = '';
			if ( is_array( $stats ) && isset( $stats['rows'] ) && ! empty( $stats['rows'] ) ) {
				$first_row    = $stats['rows'][0];
				$first_coupon = isset( $first_row['orderCoupon'] ) ? $first_row['orderCoupon'] : ( isset( $first_row['itemCategory'] ) ? $first_row['itemCategory'] : '' );
			}

			if ( ! empty( $first_coupon ) ) {
				// translators: %1$s is strong opening tag, %2$s is coupon name, %3$s is strong closing tag.
				printf( esc_html__( 'Did you know the famous Coupon in your store is %1$s %2$s %3$s?', 'wp-analytify-pro' ), '<strong>', esc_html( $first_coupon ), '</strong>' );
			} else {
				esc_html_e( 'List of all the coupons used at store.', 'wp-analytify-pro' );
			}
			?>
			</span>
			<div class="wp_analytify_pagination"></div>
		</div>
	</div>
	<?php
}
?>

<script type="text/javascript">
	jQuery(document).ready(function($) {
		wp_analytify_paginated();
	});
</script>
