<?php
/**
 * Lists Performance View.
 *
 * @package WP_Analytify_Pro
 */

/**
 *  View of List Performance.
 *
 * @param  mixed                $current Analytify Free Object.
 * @param  array<string, mixed> $stats   Contains stats that are fetch from google.
 * @return void
 * @since  1.0.0
 */
function pa_include_edd_lists_performance( $current, $stats ) {

	$famous = '';
	if ( is_array( $stats ) && isset( $stats['rows'] ) && isset( $stats['rows'][0]['itemListName'] ) ) {
		$famous = $stats['rows'][0]['itemListName'];
	}

	if ( is_array( $stats ) && isset( $stats['rows'] ) && ! empty( $stats['rows'] ) ) :
		?>
		<div class="analytify_general_status analytify_status_box_wraper">
		<div class="analytify_status_header">
			<h3><?php esc_html_e( 'Lists Performance', 'wp-analytify-pro' ); ?></h3>
		</div>
		<div class="analytify_status_body">

			<div class="analytify_status_body_content">

				<table class="analytify_data_tables analytify_list_performance_stats wp_analytify_paginated" data-product-per-page="10">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Product List Name', 'wp-analytify-pro' ); ?></th>
							<th class="analytify_txt_center"><?php esc_html_e( 'Revenue', 'wp-analytify-pro' ); ?></th>
							<th class="analytify_txt_center"><?php esc_html_e( 'Views', 'wp-analytify-pro' ); ?></th>
							<th class="analytify_txt_center"><?php esc_html_e( 'Purchases', 'wp-analytify-pro' ); ?></th>
						</tr>
					</thead>
					<tbody>

						<?php
						$currency_symbol = edd_currency_symbol();

						$i = 0;
						foreach ( $stats['rows'] as $stat ) :
							++$i;
							?>
							<tr>
								<td data-heading="#">
									<?php
									echo esc_html( $stat['itemListName'] );
									?>
								</td>
								<td data-heading="<?php esc_attr_e( 'Revenue', 'wp-analytify-pro' ); ?>" class="analytify_txt_center">
									<?php echo esc_html( ( function_exists( 'edd_currency_symbol' ) ? edd_currency_symbol() : '$' ) . number_format( $stat['itemRevenue'], 2 ) ); ?>
								</td>
								<td data-heading="<?php esc_attr_e( 'Views', 'wp-analytify-pro' ); ?>" class="analytify_txt_center">
									<?php echo esc_html( $stat['itemsViewed'] ); ?>
								</td>
								<td data-heading="<?php esc_attr_e( 'Purchases', 'wp-analytify-pro' ); ?>" class="analytify_txt_center">
									<?php echo esc_html( $stat['itemsPurchased'] ); ?>
								</td>
							</tr>
							<?php
						endforeach;
						?>
					</tbody>
				</table>

			</div>
		</div>
		<div class="analytify_status_footer">

			<?php if ( isset( $stat[0] ) ) : ?>
			<span class="analytify_info_stats">
				<?php
				// translators: %1$s is strong opening tag, %2$s is revenue amount, %3$s is strong closing tag.
				printf( esc_html__( 'Did you know the big Revenue generated from Product List in your store is %1$s %2$s %3$s', 'wp-analytify-pro' ), '<strong>', esc_html( $famous ), '</strong>' );
				?>
			</span>
			<?php endif; ?>
			<div class="wp_analytify_pagination"></div>
		</div>
	</div>
		<?php
	endif;
}
?>

<script type="text/javascript">
	jQuery(document).ready(function($) {
		wp_analytify_paginated();
	});
</script>
