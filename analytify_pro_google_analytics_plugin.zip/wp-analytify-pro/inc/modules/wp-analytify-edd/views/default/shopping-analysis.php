<?php
/**
 * Shopping Analysis View for Analytify EDD Integration.
 *
 * @package    Analytify
 * @subpackage AnalytifyEDD
 *
 * @since 1.0.0
 */

/**
 * Whether a string is a valid calendar date in Y-m-d for the site timezone.
 *
 * @param mixed $date Candidate value.
 * @return bool
 */
function analytify_edd_is_valid_churn_date_ymd( $date ) {
	if ( ! is_string( $date ) || ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ) {
		return false;
	}
	$timezone = function_exists( 'wp_timezone' ) ? wp_timezone() : new DateTimeZone( 'UTC' );
	$parsed   = DateTimeImmutable::createFromFormat( '!Y-m-d', $date, $timezone );
	return ( $parsed instanceof DateTimeImmutable ) && $parsed->format( 'Y-m-d' ) === $date;
}

/**
 * Calculate EDD recurring subscription churn rate for a date range (site timezone boundaries).
 *
 * Table/column names are chosen only from fixed whitelists after introspection; MySQL does not support
 * bound parameters for identifiers, so they are concatenated into the SQL while values use wpdb->prepare().
 *
 * @param string $start_date Start date (Y-m-d).
 * @param string $end_date   End date (Y-m-d).
 * @return float Churn rate percentage (0–100).
 * @since 1.0.0
 * @version 9.0.0
 */
function analytify_calculate_edd_churn_rate( $start_date, $end_date ) {
	global $wpdb;

	$start_date = is_string( $start_date ) ? $start_date : '';
	$end_date   = is_string( $end_date ) ? $end_date : '';

	if ( '' === $start_date || '' === $end_date ) {
		return 0.0;
	}

	$timezone = function_exists( 'wp_timezone' ) ? wp_timezone() : new DateTimeZone( 'UTC' );

	try {
		$start_dt = new DateTimeImmutable( $start_date . ' 00:00:00', $timezone );
		$end_dt   = new DateTimeImmutable( $end_date . ' 23:59:59', $timezone );
	} catch ( Exception $e ) {
		return 0.0;
	}

	// Ensure start is not after end (inverted range would skew counts).
	if ( $start_dt > $end_dt ) {
		list( $start_date, $end_date ) = array( $end_date, $start_date );
		try {
			$start_dt = new DateTimeImmutable( $start_date . ' 00:00:00', $timezone );
			$end_dt   = new DateTimeImmutable( $end_date . ' 23:59:59', $timezone );
		} catch ( Exception $e ) {
			return 0.0;
		}
	}

	$start_ts = $start_dt->getTimestamp();
	$end_ts   = $end_dt->getTimestamp();
	$gm_start = gmdate( 'Y-m-d H:i:s', $start_ts );
	$gm_end   = gmdate( 'Y-m-d H:i:s', $end_ts );

	$active_at_start = 0;
	$canceled_count  = 0;

	$tables = array(
		$wpdb->prefix . 'edd_subscriptions',
		$wpdb->prefix . 'edd_subscribers',
	);

	$subscription_table_present = false;
	$valid_columns              = array( 'created', 'created_date', 'date_created', 'cancelled_date', 'cancelled', 'date_cancelled', 'status', 'date_modified' );

	foreach ( $tables as $table_name ) {
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table_name ) ) !== $table_name ) {
			continue;
		}

		$subscription_table_present = true;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table_name is from fixed $tables list; DESCRIBE cannot bind identifiers.
		$columns = $wpdb->get_col( "DESCRIBE `{$table_name}`" );
		if ( ! is_array( $columns ) ) {
			$columns = array();
		}

		// First match wins (array_intersect keeps order of the first argument).
		$date_pick    = array_values( array_intersect( array( 'created_date', 'date_created' ), $columns ) );
		$date_column  = isset( $date_pick[0] ) ? $date_pick[0] : 'created';
		$cancel_pick  = array_values( array_intersect( array( 'cancelled_date', 'cancelled', 'date_cancelled' ), $columns ) );
		$cancel_col   = isset( $cancel_pick[0] ) ? $cancel_pick[0] : null;
		$status_col   = in_array( 'status', $columns, true ) ? 'status' : null;
		$modified_col = in_array( 'date_modified', $columns, true ) ? 'date_modified' : null;

		if ( ! in_array( $date_column, $valid_columns, true ) ) {
			continue;
		}

		/*
		 * Identifiers: $table_name and resolved columns are whitelisted; values use prepare().
		 */
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared
		if ( $cancel_col ) {
			$active_sql = $wpdb->prepare(
				"SELECT COUNT(*) FROM `{$table_name}` WHERE `{$date_column}` <= %s AND (`{$cancel_col}` IS NULL OR `{$cancel_col}` = '' OR `{$cancel_col}` > %s)",
				$gm_end,
				$gm_start
			);
		} elseif ( $status_col ) {
			$active_sql = $modified_col
				? $wpdb->prepare(
					"SELECT COUNT(*) FROM `{$table_name}` WHERE `{$date_column}` <= %s AND (`{$status_col}` != 'cancelled' OR `{$modified_col}` > %s OR `{$modified_col}` IS NULL)",
					$gm_end,
					$gm_start
				)
				: $wpdb->prepare(
					"SELECT COUNT(*) FROM `{$table_name}` WHERE `{$date_column}` <= %s AND `{$status_col}` != 'cancelled'",
					$gm_end
				);
		} else {
			$active_sql = $wpdb->prepare(
				"SELECT COUNT(*) FROM `{$table_name}` WHERE `{$date_column}` <= %s",
				$gm_end
			);
		}

		$active_at_start = (int) $wpdb->get_var( $active_sql );

		if ( $cancel_col ) {
			$canceled_sql   = $wpdb->prepare(
				"SELECT COUNT(*) FROM `{$table_name}` WHERE `{$cancel_col}` >= %s AND `{$cancel_col}` <= %s",
				$gm_start,
				$gm_end
			);
			$canceled_count = (int) $wpdb->get_var( $canceled_sql );
		} elseif ( $status_col && $modified_col ) {
			$canceled_sql   = $wpdb->prepare(
				"SELECT COUNT(*) FROM `{$table_name}` WHERE `{$status_col}` = 'cancelled' AND `{$modified_col}` >= %s AND `{$modified_col}` <= %s",
				$gm_start,
				$gm_end
			);
			$canceled_count = (int) $wpdb->get_var( $canceled_sql );
		} else {
			$canceled_count = 0;
		}
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared

		if ( $active_at_start > 0 || $canceled_count > 0 ) {
			break;
		}
	}

	if ( ! $subscription_table_present && defined( 'WP_DEBUG' ) && WP_DEBUG && defined( 'WP_DEBUG_LOG' ) && WP_DEBUG_LOG ) {
		// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- Opt-in diagnostic when both EDD subscription tables are absent.
		error_log( '[Analytify EDD] Churn: no EDD subscription/subscriber tables found; churn rate returned as 0.' );
	}

	$active_at_start = (int) $active_at_start;
	if ( $active_at_start < 1 ) {
		return 0.0;
	}

	return round( ( $canceled_count / $active_at_start ) * 100, 4 );
}

/**
 * Show General Performance of Digital Shop.
 *
 * @param mixed                    $current      Analytify instance (unused in this view; kept for caller signature compatibility).
 * @param array<string,mixed>      $stats        Contains stats that are fetch from google.
 * @param array<string,mixed>|null $refund_stats Refund event stats from GA4 (optional).
 * @param string|null              $start_date   Start date (Y-m-d).
 * @param string|null              $end_date     End date (Y-m-d).
 *
 * @since   1.0.0
 * @version 9.0.0
 */
function pa_include_edd( $current, $stats, $refund_stats = null, $start_date = null, $end_date = null ) {
	// Handle flexible signature: if third parameter is string, treat as start_date (master style).
	if ( is_string( $refund_stats ) && null === $start_date ) {
		$start_date   = $refund_stats;
		$end_date     = $start_date;
		$refund_stats = null;
	}
	if ( is_string( $start_date ) && null === $end_date ) {
		$end_date = $start_date;
	}

	if ( ! is_array( $stats ) ) {
		$stats = array();
	}

	// Determine date range for churn and refund fallback.
	$start_date = ( is_string( $start_date ) && '' !== $start_date ) ? $start_date : wp_date( 'Y-m-d', strtotime( '-1 month' ) );
	$end_date   = ( is_string( $end_date ) && '' !== $end_date ) ? $end_date : wp_date( 'Y-m-d', strtotime( 'now' ) );

	$pretty_metric = static function ( $value ) {
		if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' ) ) {
			return (string) WPANALYTIFY_Utils::pretty_numbers( $value );
		}
		return is_numeric( $value ) ? number_format_i18n( (float) $value ) : '0';
	};

	// Calculate Conversion Rate.
	$sessions        = isset( $stats['aggregations']['sessions'] ) ? $stats['aggregations']['sessions'] : 0;
	$transactions    = isset( $stats['aggregations']['transactions'] ) ? $stats['aggregations']['transactions'] : 0;
	$conversion_rate = $sessions > 0 ? ( $transactions / $sessions ) * 100 : 0;

	// Get New Customer Rate.
	$first_purchaser = isset( $stats['aggregations']['firstTimePurchaserRate'] ) ? $stats['aggregations']['firstTimePurchaserRate'] : 0;

	// ----------------------
	// Refund metrics
	// ----------------------
	$refunds       = 0;
	$refund_amount = 0;

	// Get refund count and amount from dedicated refund stats call (if provided).
	if ( is_array( $refund_stats ) && isset( $refund_stats['aggregations']['eventCount'] ) ) {
		$refunds = $refund_stats['aggregations']['eventCount'];
	}
	if ( is_array( $refund_stats ) && isset( $refund_stats['aggregations']['eventValue'] ) ) {
		$refund_amount = $refund_stats['aggregations']['eventValue'];
	} elseif ( isset( $stats['aggregations']['refundAmount'] ) ) {
		// Fallback to general stats if available.
		$refund_amount = $stats['aggregations']['refundAmount'];
	}

	// Fallback: If GA4 refund count is zero, aggregate from EDD in bounded batches (avoids loading all rows at once).
	if ( 0 === (int) $refunds && function_exists( 'edd_get_payments' ) && function_exists( 'edd_get_payment_amount' ) ) {
		$batch_size  = 200;
		$offset      = 0;
		$db_refunds  = 0;
		$db_amount   = 0;
		$max_batches = 500;
		$batch_i     = 0;
		while ( $batch_i < $max_batches ) {
			++$batch_i;
			$refunded_payments = edd_get_payments(
				array(
					'status'     => 'refunded',
					'start_date' => $start_date,
					'end_date'   => $end_date,
					'number'     => $batch_size,
					'offset'     => $offset,
				)
			);
			if ( empty( $refunded_payments ) ) {
				break;
			}
			$db_refunds += count( $refunded_payments );
			foreach ( $refunded_payments as $payment ) {
				if ( is_object( $payment ) && isset( $payment->ID ) ) {
					$db_amount += edd_get_payment_amount( $payment->ID );
				}
			}
			if ( count( $refunded_payments ) < $batch_size ) {
				break;
			}
			$offset += $batch_size;
		}
		if ( $db_refunds > 0 ) {
			$refunds       = $db_refunds;
			$refund_amount = $db_amount;
		}
	}

	// Refund rate: use GA4 transactions when present; otherwise approximate from EDD completed count for the same window.
	$refund_rate        = 0;
	$total_transactions = (int) $transactions;
	if ( $total_transactions <= 0 && $refunds > 0 && function_exists( 'edd_get_payments' ) ) {
		$batch_size  = 200;
		$offset      = 0;
		$max_batches = 500;
		$batch_i     = 0;
		while ( $batch_i < $max_batches ) {
			++$batch_i;
			$total_payments = edd_get_payments(
				array(
					'status'     => array( 'publish', 'complete' ),
					'start_date' => $start_date,
					'end_date'   => $end_date,
					'number'     => $batch_size,
					'offset'     => $offset,
				)
			);
			if ( empty( $total_payments ) ) {
				break;
			}
			$total_transactions += count( $total_payments );
			if ( count( $total_payments ) < $batch_size ) {
				break;
			}
			$offset += $batch_size;
		}
	}
	if ( $total_transactions > 0 && $refunds > 0 ) {
		$refund_rate = ( $refunds / $total_transactions ) * 100;
	}

	// ----------------------
	// Churn rate
	// ----------------------
	$churn_tz            = function_exists( 'wp_timezone' ) ? wp_timezone() : new DateTimeZone( 'UTC' );
	$churn_default_end   = ( new DateTimeImmutable( 'now', $churn_tz ) )->format( 'Y-m-d' );
	$churn_default_start = ( new DateTimeImmutable( 'now', $churn_tz ) )->modify( '-1 month' )->format( 'Y-m-d' );

	$churn_start = analytify_edd_is_valid_churn_date_ymd( $start_date ) ? $start_date : '';
	$churn_end   = analytify_edd_is_valid_churn_date_ymd( $end_date ) ? $end_date : '';

	if ( '' === $churn_start || '' === $churn_end ) {
		$picker = function_exists( 'analytify_datepicker_dates' ) ? analytify_datepicker_dates() : false;
		if ( ! is_array( $picker ) ) {
			$picker = array();
		}

		$pick_start = isset( $picker['start_date'] ) ? $picker['start_date'] : '';
		$pick_end   = isset( $picker['end_date'] ) ? $picker['end_date'] : '';

		$churn_start = analytify_edd_is_valid_churn_date_ymd( $pick_start ) ? $pick_start : $churn_default_start;
		$churn_end   = analytify_edd_is_valid_churn_date_ymd( $pick_end ) ? $pick_end : $churn_default_end;
	}

	$churn_rate = analytify_calculate_edd_churn_rate( $churn_start, $churn_end );

	// ----------------------
	// Output HTML
	// ----------------------
	?>
	<div class="analytify_general_status analytify_status_box_wraper">
		<div class="analytify_status_header">
			<h3><?php esc_html_e( 'Overview', 'wp-analytify-pro' ); ?></h3>
		</div>
		<div class="analytify_status_body">
			<div class="analytify_general_status_boxes_wraper">
				<!-- Transactions -->
				<div class="analytify_general_status_boxes">
					<h4><?php esc_html_e( 'Transactions', 'wp-analytify-pro' ); ?></h4>
					<div class="analytify_general_stats_value">
						<?php echo esc_html( $pretty_metric( isset( $stats['aggregations']['transactions'] ) ? $stats['aggregations']['transactions'] : 0 ) ); ?>
					</div>
					<p><?php esc_html_e( 'Total number of completed purchases.', 'wp-analytify-pro' ); ?>.</p>
				</div>

				<!-- Transaction Revenues -->
				<div class="analytify_general_status_boxes">
					<h4><?php esc_html_e( 'Transaction Revenues', 'wp-analytify-pro' ); ?></h4>
					<div class="analytify_general_stats_value">
						<?php
						if ( isset( $stats['aggregations']['totalRevenue'] ) && function_exists( 'edd_currency_symbol' ) ) {
							$rev = (float) $stats['aggregations']['totalRevenue'];
							$out = edd_currency_symbol() . ( $rev >= 1000 ? number_format( $rev / 1000, 2 ) . 'k' : number_format( $rev, 2 ) );
							echo esc_html( $out );
						} elseif ( function_exists( 'edd_currency_symbol' ) ) {
							echo esc_html( edd_currency_symbol() . number_format( 0, 2 ) );
						} else {
							echo esc_html( number_format( 0, 2 ) );
						}
						?>
					</div>
					<p><?php esc_html_e( 'Total revenue from purchases including or excluding tax.', 'wp-analytify-pro' ); ?></p>
				</div>

				<!-- Average Order Value -->
				<div class="analytify_general_status_boxes">
					<h4><?php esc_html_e( 'Average Order Value', 'wp-analytify-pro' ); ?></h4>
					<div class="analytify_general_stats_value">
						<?php
						if ( isset( $stats['aggregations']['averagePurchaseRevenue'] ) && function_exists( 'edd_currency_symbol' ) ) {
							echo esc_html( edd_currency_symbol() . number_format( (float) $stats['aggregations']['averagePurchaseRevenue'], 2 ) );
						} else {
							echo esc_html( function_exists( 'edd_currency_symbol' ) ? edd_currency_symbol() . number_format( 0, 2 ) : number_format( 0, 2 ) );
						}
						?>
					</div>
					<p><?php esc_html_e( 'Average value of orders.', 'wp-analytify-pro' ); ?></p>
				</div>

				<!-- Product Adds To Cart -->
				<div class="analytify_general_status_boxes">
					<h4><?php esc_html_e( 'Product Adds To Cart', 'wp-analytify-pro' ); ?></h4>
					<div class="analytify_general_stats_value">
						<?php echo esc_html( $pretty_metric( isset( $stats['aggregations']['addToCarts'] ) ? $stats['aggregations']['addToCarts'] : 0 ) ); ?>
					</div>
					<p><?php esc_html_e( 'Total number of add to cart items.', 'wp-analytify-pro' ); ?></p>
				</div>

				<!-- Product Checkouts -->
				<div class="analytify_general_status_boxes">
					<h4><?php esc_html_e( 'Product Checkouts', 'wp-analytify-pro' ); ?></h4>
					<div class="analytify_general_stats_value">
						<?php echo esc_html( $pretty_metric( isset( $stats['aggregations']['checkouts'] ) ? $stats['aggregations']['checkouts'] : 0 ) ); ?>
					</div>
					<p><?php esc_html_e( 'Total number of checkouts.', 'wp-analytify-pro' ); ?></p>
				</div>

				<!-- Product Detail Views -->
				<div class="analytify_general_status_boxes">
					<h4><?php esc_html_e( 'Product Detail Views', 'wp-analytify-pro' ); ?></h4>
					<div class="analytify_general_stats_value">
						<?php echo esc_html( $pretty_metric( isset( $stats['aggregations']['itemViews'] ) ? $stats['aggregations']['itemViews'] : 0 ) ); ?>
					</div>
					<p><?php esc_html_e( 'Number of times users viewed the product detail page.', 'wp-analytify-pro' ); ?></p>
				</div>

				<!-- Conversion Rate -->
				<div class="analytify_general_status_boxes">
					<h4><?php esc_html_e( 'Conversion Rate', 'wp-analytify-pro' ); ?></h4>
					<div class="analytify_general_stats_value">
						<?php echo esc_html( number_format( (float) $conversion_rate, 2 ) . '%' ); ?>
					</div>
					<p><?php esc_html_e( 'The percentage of website sessions resulting in a transaction.', 'wp-analytify-pro' ); ?></p>
				</div>

				<!-- New Customers -->
				<div class="analytify_general_status_boxes">
					<h4><?php esc_html_e( 'New Customers', 'wp-analytify-pro' ); ?></h4>
					<div class="analytify_general_stats_value">
						<?php echo esc_html( number_format( (float) $first_purchaser, 2 ) . '%' ); ?>
					</div>
					<p><?php esc_html_e( 'The percentage of first-time purchasers.', 'wp-analytify-pro' ); ?></p>
				</div>

				<!-- Refund Rate -->
				<div class="analytify_general_status_boxes refund-rate">
					<h4><?php esc_html_e( 'Refund Rate', 'wp-analytify-pro' ); ?></h4>
					<div class="analytify_general_stats_value">
						<?php echo esc_html( number_format( (float) $refund_rate, 2 ) . '%' ); ?>
					</div>
					<p><?php esc_html_e( 'Percentage of transactions that were refunded.', 'wp-analytify-pro' ); ?></p>
				</div>

				<!-- Total Refunds -->
				<div class="analytify_general_status_boxes total-refunds">
					<h4><?php esc_html_e( 'Total Refunds', 'wp-analytify-pro' ); ?></h4>
					<div class="analytify_general_stats_value">
						<?php echo esc_html( $pretty_metric( $refunds ) ); ?>
					</div>
					<p><?php esc_html_e( 'The total number of refunded transactions.', 'wp-analytify-pro' ); ?></p>
				</div>

				<!-- Refund Amount -->
				<div class="analytify_general_status_boxes refund-amount">
					<h4><?php esc_html_e( 'Refund Amount', 'wp-analytify-pro' ); ?></h4>
					<div class="analytify_general_stats_value">
						<?php
						$ref_amt = (float) $refund_amount;
						if ( function_exists( 'edd_currency_symbol' ) ) {
							$ref_out = edd_currency_symbol() . ( $ref_amt >= 1000 ? number_format( $ref_amt / 1000, 2 ) . 'k' : number_format( $ref_amt, 2 ) );
							echo esc_html( $ref_out );
						} else {
							echo esc_html( number_format( $ref_amt, 2 ) );
						}
						?>
					</div>
					<p><?php esc_html_e( 'The total amount refunded to customers.', 'wp-analytify-pro' ); ?></p>
				</div>

				<!-- Churn Rate -->
				<div class="analytify_general_status_boxes analytify_edd_churn_rate_box">
					<h4><?php esc_html_e( 'Churn Rate', 'wp-analytify-pro' ); ?></h4>
					<div class="analytify_general_stats_value">
						<?php echo esc_html( number_format( $churn_rate, 2 ) . '%' ); ?>
					</div>
					<p><?php esc_html_e( 'The percentage of active subscriptions that were canceled during this period.', 'wp-analytify-pro' ); ?></p>
				</div>
			</div>
		</div>
	</div>
	<?php
}
