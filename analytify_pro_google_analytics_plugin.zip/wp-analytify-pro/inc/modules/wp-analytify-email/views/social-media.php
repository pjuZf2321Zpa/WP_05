<?php
/**
 * Social Media Stats View.
 *
 * @package WP_Analytify_Pro
 */

/**
 * Simplify domain from URL.
 *
 * @param string $url URL to simplify.
 * @return string
 */
function simplify_domain( $url ) {
	// Extract only the main domain from the session source.
	$parsed_url   = wp_parse_url( $url, PHP_URL_HOST ) ? wp_parse_url( $url, PHP_URL_HOST ) : $url; // Handle URLs and non-URL strings.
	$domain_parts = explode( '.', $parsed_url );

	// Remove common subdomains and return the main domain.
	$common_subdomains = array( 'www', 'l', 'en-gb', 'm' ); // Add more subdomains as needed.

	// Filter out common subdomains.
	$domain_parts = array_filter(
		$domain_parts,
		function ( $part ) use ( $common_subdomains ) {
			return ! in_array( $part, $common_subdomains, true );
		}
	);

	// Reindex array after filtering.
	$domain_parts = array_values( $domain_parts );

	if ( count( $domain_parts ) > 1 ) {
		return $domain_parts[ count( $domain_parts ) - 2 ]; // Extract the main domain.
	}

	return $parsed_url; // Return as-is if it's already simplified.
}

/**
 * Generate social stats HTML.
 *
 * @param mixed                $analytify_email Email instance.
 * @param array<string, mixed> $socials Social stats data.
 * @return string
 * @version 8.1.0
 */
function social_stats( $analytify_email, $socials ) {
	// phpcs:ignore WordPress.NamingConventions.ValidVariableName.VariableNotSnakeCase -- Legacy parameter name.
	// Transform the input data into a simpler structure.
	$simplified_socials = array();

	if ( isset( $socials['rows'] ) && is_array( $socials['rows'] ) ) {
		foreach ( $socials['rows'] as $social ) {
			// Simplify the session source.
			$domain = simplify_domain( $social['sessionSource'] );

			// Group sessions by simplified domain.
			if ( ! isset( $simplified_socials[ $domain ] ) ) {
				$simplified_socials[ $domain ] = 0; // Initialize if not already set.
			}
			$simplified_socials[ $domain ] += $social['sessions']; // Sum sessions for the domain.
		}
	}

	// Calculate total sessions.
	$total_stats = array_sum( $simplified_socials );

	ob_start();
	?>
	<!--Start Social Media-->
	<tr>
		<td style="<?php echo esc_attr( analytify_email_section_gap_style() ); ?>">
			<table width="100%" cellspacing="0" cellpadding="0" border="0">
				<tr>
					<td style="border: 1px solid #e2e5e8;" valign="top">
						<table align="center" bgcolor="#f9fafa" border="0" cellpadding="0" cellspacing="0" width="100%">
							<tr>
								<td style="font: normal 16px 'Roboto slab', Arial, Helvetica, sans-serif; padding: 11px 20px;" width="190">
									<font color="#444444"><?php analytify_e( 'Social Media', 'wp-analytify' ); ?></font>
								</td>
								<td align="right" style="font: normal 16px 'Roboto slab', Arial, Helvetica, sans-serif; padding: 11px 20px 11px 0;" width="250">
									<small><font color="#848484"><?php analytify_e( 'Total Visits', 'wp-analytify' ); ?></font></small>
									<font color="#444444"><?php echo esc_html( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' ) ? WPANALYTIFY_Utils::pretty_numbers( $total_stats ) : $total_stats ); ?></font>
								</td>
							</tr>
							<tr>
								<td width="100%" valign="top" colspan="2">
									<table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#ffffff">
										<?php if ( ! empty( $simplified_socials ) ) : ?>
											<?php foreach ( $simplified_socials as $domain => $sessions ) : ?>
												<tr>
													<td style="padding:15px; font: 400 13px 'Roboto', Arial, Helvetica, sans-serif;border-top: 1px solid #e2e5e8;" width="20">
														<?php
														$slug      = strtolower( sanitize_file_name( (string) $domain ) );
														$icon_file = 'analytify_' . $slug . '.png';
														$icon_url  = ANALYTIFY_IMAGES_PATH . $icon_file;
														?>
														<img src="<?php echo esc_url( $icon_url ); ?>" alt=""/>
													</td>
													<td style="padding:15px; font: 400 13px 'Roboto', Arial, Helvetica, sans-serif;border-top: 1px solid #e2e5e8;">
														<!-- Display the simplified domain -->
														<font color="#444444"><?php echo esc_html( ucfirst( $domain ) ); ?></font>
													</td>
													<td style="padding:15px; font: 400 13px 'Roboto', Arial, Helvetica, sans-serif;border-top: 1px solid #e2e5e8;" align="right">
														<font color="#444444"><?php echo esc_html( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' ) ? WPANALYTIFY_Utils::pretty_numbers( $sessions ) : $sessions ); ?></font>
													</td>
												</tr>
											<?php endforeach; ?>
										<?php else : ?>
											<?php analytify_email_render_no_data_row( 3 ); ?>
										<?php endif; ?>
									</table>
								</td>
							</tr>
							<tr>
								<td colspan="2" style="border-top: 1px solid #e2e5e8;">
									<table cellpadding="0" cellspacing="16" border="0" width="100%" bgcolor="#f9fafa">
										<tr>
											<td width="32" style="text-align: right;">
												<img src="<?php echo esc_url( ANALYTIFY_IMAGES_PATH . 'anlytify_about_icon.png' ); ?>" alt=""/>
											</td>
											<td style="font: normal 13px 'Roboto', Arial, Helvetica, sans-serif;">
												<font color="#444444"><?php analytify_e( 'See how many users are coming to your site from Social media', 'wp-analytify' ); ?></font>
											</td>
										</tr>
									</table>
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
	<!--End Social Media-->
	<?php
	$message = ob_get_clean();
	return $message ? $message : '';
}

