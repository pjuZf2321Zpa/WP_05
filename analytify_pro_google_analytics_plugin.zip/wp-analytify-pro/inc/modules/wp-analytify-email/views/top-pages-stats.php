<?php
/**
 * Top Pages Stats View.
 *
 * @package WP_Analytify_Pro
 * @version 8.1.0
 */

/**
 * Include top pages stats HTML.
 *
 * @param mixed                $current Current instance.
 * @param array<string, mixed> $top_page_stats Top pages stats data.
 * @return string
 */
function pa_include_top_pages_stats( $current, $top_page_stats ) {
	ob_start();
	?>
	<!--Top pages by views.-->
					<tr>
						<td valign="top" style="border: 1px solid #e2e5e8;">
							<table width="100%" cellspacing="0" cellpadding="0" border="0" align="center" bgcolor="#f9fafa">
								<tr>
									<td style="font: normal 16px 'Roboto slab', Arial, Helvetica, sans-serif; padding: 11px 20px;"><font color="#444444"><?php analytify_e( 'Top Pages by Views', 'wp-analytify' ); ?></font></td>
								</tr>
							</table>
						</td>
					</tr>
					<tr>
						<td style="border:1px solid #e2e5e8; border-top-width: 0; border-bottom-width: 0;">
							<table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#ffffff">
								<tr>
									<td align="center" style="padding:15px; font: 400 13px 'Roboto', Arial, Helvetica, sans-serif; border-right: 1px solid #e2e5e8; border-bottom: 1px solid #e2e5e8; " bgcolor="#f5f9ff" width="20"><font color="#444444">#</font></td>
									<td style="padding:15px; font: 400 13px 'Roboto', Arial, Helvetica, sans-serif; border-bottom: 1px solid #e2e5e8;" bgcolor="#f5f9ff"><font color="#444444"><?php analytify_e( 'Title', 'wp-analytify' ); ?></font></td>
									<td style="padding:15px; font: 400 13px 'Roboto', Arial, Helvetica, sans-serif;border-left: 1px solid #e2e5e8; border-bottom: 1px solid #e2e5e8;" bgcolor="#f5f9ff" width="50" align="right"><font color="#444444"><?php analytify_e( 'Views', 'wp-analytify' ); ?></font></td>
								</tr>

				<?php if ( analytify_email_has_stat_rows( $top_page_stats ) ) : ?>
					<?php $count = 0; ?>
					<?php foreach ( $top_page_stats['rows'] as $row ) : ?>
					<tr>
						<td style="padding:15px; font: 400 13px 'Roboto', Arial, Helvetica, sans-serif; border-bottom: 1px solid #e2e5e8;" ><font color="#444444"><?php echo esc_html( ++$count ); ?></font></td>
						<td style="padding:15px; font: 400 13px 'Roboto', Arial, Helvetica, sans-serif; border-bottom: 1px solid #e2e5e8;" ><font color="#444444"><?php echo esc_html( isset( $row['pageTitle'] ) ? (string) $row['pageTitle'] : '' ); ?></font></td>
						<td style="padding:15px; font: 400 13px 'Roboto', Arial, Helvetica, sans-serif; border-bottom: 1px solid #e2e5e8;"  align="right"><font color="#444444">
						<?php
						$raw_views = isset( $row['screenPageViews'] ) ? $row['screenPageViews'] : 0;
						$views     = $raw_views ? ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' ) ? WPANALYTIFY_Utils::pretty_numbers( $raw_views ) : $raw_views ) : 0;
						echo esc_html( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' ) ? WPANALYTIFY_Utils::pretty_numbers( $views ) : $views );
						?>
						</font></td>
					</tr>
					<?php endforeach; ?>
				<?php else : ?>
					<?php analytify_email_render_no_data_row( 3 ); ?>
				<?php endif; ?>

							</table>
						</td>
					</tr>
					<tr>
						<td style="border:1px solid #e2e5e8; border-top: 0;">
							<table cellpadding="0" cellspacing="16" border="0" width="100%" bgcolor="#f9fafa">
								<tr>
									<td width="32" style="text-align: right;"><img src="<?php echo esc_url( ANALYTIFY_IMAGES_PATH . 'anlytify_about_icon.png' ); ?>" alt="about icon"/></td>
									<td style="font: normal 13px 'Roboto', Arial, Helvetica, sans-serif;"><font color="#444444"><?php analytify_e( 'List of top pages and posts viewed by your site visitors.', 'wp-analytify' ); ?></font></td>
								</tr>
							</table>
						</td>
					</tr>
					<tr>
						<td style="padding:15px;"></td>
					</tr>
					<!--End pages by views.-->
	<?php

	$message = ob_get_clean();
	return $message ? $message : '';
}

