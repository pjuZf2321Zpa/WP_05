<?php
/**
 * Output EDD Report section in email.
 *
 * @package WP_Analytify_Pro
 * @since 1.2.6
 * @version 8.1.0
 */

/**
 * Include EDD general stats in email.
 *
 * @param mixed                $current Current instance.
 * @param array<string, mixed> $stats EDD stats data.
 * @return string
 */
function pa_email_include_edd_general( $current, $stats ) {

	ob_start();
	?>
	<tr>
		<td valign="top" style="border: 1px solid #e2e5e8;">
			<table width="100%" cellspacing="0" cellpadding="0" border="0" align="center" bgcolor="#f9fafa">
				<tr>
					<td style="font: normal 16px 'Roboto slab', Arial, Helvetica, sans-serif; padding: 11px 20px;"><font color="#444444"><?php analytify_e( 'E-Commerce Statistics', 'wp-analytify' ); ?></font></td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td style="border:1px solid #e2e5e8; border-top: 0;" bgcolor="#ffffff"  class="session-table">
			<table cellspacing="20" cellpadding="0" border="0" align="center" bgcolor="#f9fafa" width="100%" class="box-table">
			<?php if ( ! isset( $stats['error'] ) ) : ?>	
				<tr>
					<td style="border: 1px solid #e2e5e8;" width="33.333%">
						<table width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="#ffffff">
							<tr>
								<td align="center" colspan="3" style="font: 500 14px 'Roboto', Arial, Helvetica, sans-serif;padding: 16px 5px 5px; text-transform: uppercase; letter-spacing: 0.01em;"><font color="#848484"><?php esc_html_e( 'Transactions', 'wp-analytify-pro' ); ?></font></td>
							</tr>
							<tr>
								<td width="45" ></td><td align="center"><hr style="margin:0;border:0;border-top: 1px solid #e5e5e5;"/></td><td width="45"></td>
							</tr>
							<tr>
								<td align="center" colspan="3" style="padding: 13px 5px 10px; font: 400 24px 'Roboto', Arial, Helvetica, sans-serif;"><font color="#444444"><?php echo esc_html( number_format( $stats['aggregations']['transactions'] ) ); ?></font></td>
							</tr>
						</table>
					</td>
					<td  style="border: 1px solid #e2e5e8 );" width="33.333%">
						<table width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="#ffffff">
							<tr>
								<td align="center" colspan="3" style="font: 500 14px 'Roboto', Arial, Helvetica, sans-serif;padding: 16px 5px 5px; text-transform: uppercase; letter-spacing: 0.01em;"><font color="#848484"><?php esc_html_e( 'Transaction Revenues', 'wp-analytify-pro' ); ?></font></td>
							</tr>
							<tr>
								<td width="45"></td><td align="center"><hr style="margin:0;border:0;border-top: 1px solid #e5e5e5;"/></td><td width="45"></td>
							</tr>
							<tr>
								<td align="center" colspan="3" style="padding: 13px 5px 10px; font: 400 24px 'Roboto', Arial, Helvetica, sans-serif;"><font color="#444444"><?php echo esc_html( ( function_exists( 'edd_currency_symbol' ) ? edd_currency_symbol() : '$' ) . number_format( $stats['aggregations']['totalRevenue'], 2 ) ); ?></font></td>
							</tr>
						</table>
					</td>
					<td  style="border: 1px solid #e2e5e8 );" width="33.333%">
						<table width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="#ffffff">
							<tr>
								<td align="center" colspan="3" style="font: 500 14px 'Roboto', Arial, Helvetica, sans-serif;padding: 16px 5px 5px; text-transform: uppercase; letter-spacing: 0.01em;"><font color="#848484"><?php esc_html_e( 'Average Order Value', 'wp-analytify-pro' ); ?></font></td>
							</tr>
							<tr>
								<td width="45"></td><td align="center"><hr style="margin:0;border:0;border-top: 1px solid #e5e5e5;"/></td><td width="45"></td>
							</tr>
							<tr>
								<td align="center" colspan="3" style="padding: 13px 5px 10px; font: 400 24px 'Roboto', Arial, Helvetica, sans-serif;"><font color="#444444"><?php echo esc_html( ( function_exists( 'edd_currency_symbol' ) ? edd_currency_symbol() : '$' ) . number_format( $stats['aggregations']['averagePurchaseRevenue'], 2 ) ); ?></font></td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td  style="border: 1px solid #e2e5e8 );" width="33.333%">
						<table width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="#ffffff">
							<tr>
								<td align="center" colspan="3" style="font: 500 14px 'Roboto', Arial, Helvetica, sans-serif;padding: 16px 5px 5px; text-transform: uppercase; letter-spacing: 0.01em;"><font color="#848484"><?php esc_html_e( 'Product Adds To Cart', 'wp-analytify-pro' ); ?></font></td>
							</tr>
							<tr>
								<td width="45"></td><td align="center"><hr style="margin:0;border:0;border-top: 1px solid #e5e5e5;"/></td><td width="45"></td>
							</tr>
							<tr>
								<td align="center" colspan="3" style="padding: 13px 5px 10px; font: 400 24px 'Roboto', Arial, Helvetica, sans-serif;"><font color="#444444"><?php echo esc_html( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' ) ? WPANALYTIFY_Utils::pretty_numbers( $stats['aggregations']['addToCarts'] ) : $stats['aggregations']['addToCarts'] ); ?></font></td>
							</tr>
						</table>
					</td>
					<td style="border: 1px solid #e2e5e8 );" width="33.333%">
						<table width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="#ffffff">
							<tr>
								<td align="center" colspan="3" style="font: 500 14px 'Roboto', Arial, Helvetica, sans-serif;padding: 16px 5px 5px; text-transform: uppercase; letter-spacing: 0.01em;"><font color="#848484"><?php esc_html_e( 'Product Checkouts', 'wp-analytify-pro' ); ?></font></td>
							</tr>
							<tr>
								<td width="45" ></td><td align="center"><hr style="margin:0;border:0;border-top: 1px solid #e5e5e5;"/></td><td width="45"></td>
							</tr>
							<tr>
								<td align="center" colspan="3" style="padding: 13px 5px 10px; font: 400 24px 'Roboto', Arial, Helvetica, sans-serif;"><font color="#444444"><?php echo esc_html( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' ) ? WPANALYTIFY_Utils::pretty_numbers( $stats['aggregations']['checkouts'] ) : $stats['aggregations']['checkouts'] ); ?></font></td>
							</tr>
						</table>
					</td>
					<td  style="border: 1px solid #e2e5e8 );" width="33.333%">
						<table width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="#ffffff">
							<tr>
								<td align="center" colspan="3" style="font: 500 14px 'Roboto', Arial, Helvetica, sans-serif;padding: 16px 5px 5px; text-transform: uppercase; letter-spacing: 0.01em;"><font color="#848484"><?php esc_html_e( 'Product Detail Views', 'wp-analytify-pro' ); ?></font></td>
							</tr>
							<tr>
								<td width="45"></td><td align="center"><hr style="margin:0;border:0;border-top: 1px solid #e5e5e5;"/></td><td width="45"></td>
							</tr>
							<tr>
								<td align="center" colspan="3" style="padding: 13px 5px 10px; font: 400 24px 'Roboto', Arial, Helvetica, sans-serif;"><font color="#444444"><?php echo esc_html( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' ) ? WPANALYTIFY_Utils::pretty_numbers( $stats['aggregations']['itemViews'] ) : $stats['aggregations']['itemViews'] ); ?></font></td>
							</tr>
						</table>
					</td>
				</tr>
				<?php
				/*
				<tr>
					<td style="border: 1px solid #e2e5e8 );" width="33.333%">
						<table width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="#ffffff">
							<tr>
								<td align="center" colspan="3" style="font: 500 14px 'Roboto', Arial, Helvetica, sans-serif;padding: 16px 5px 5px; text-transform: uppercase; letter-spacing: 0.01em;"><font color="#848484"><?php esc_html_e( 'Product Removes From Cart', 'wp-analytify-woocommerce' ); ?></font></td>
							</tr>
							<tr>
								<td width="45"></td><td align="center"><hr style="margin:0;border:0;border-top: 1px solid #e5e5e5;"/></td><td width="45"></td>
							</tr>
							<tr>
								<td align="center" colspan="3" style="padding: 13px 5px 10px; font: 400 24px 'Roboto', Arial, Helvetica, sans-serif;"><font color="#444444"><?php echo esc_html( $stats->totalsForAllResults['ga:productRemovesFromCart']; ?></font></td>
							</tr>
						</table>
					</td>
					<td style="border: 1px solid #e2e5e8 );" width="33.333%">
						<table width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="#ffffff">
							<tr>
								<td align="center" colspan="3" style="font: 500 14px 'Roboto', Arial, Helvetica, sans-serif;padding: 16px 5px 5px; text-transform: uppercase; letter-spacing: 0.01em;"><font color="#848484"><?php esc_html_e( 'Refund Amount', 'wp-analytify-woocommerce' ); ?></font></td>
							</tr>
							<tr>
								<td width="45" ></td><td align="center"><hr style="margin:0;border:0;border-top: 1px solid #e5e5e5;"/></td><td width="45"></td>
							</tr>
							<tr>
								<td align="center" colspan="3" style="padding: 13px 5px 10px; font: 400 24px 'Roboto', Arial, Helvetica, sans-serif;"><font color=""><?php echo esc_html( edd_currency_symbol() . number_format( $stats->totalsForAllResults['ga:refundAmount'], 2 ); ?></font></td>
							</tr>
						</table>
					</td>
					<td  style="border: 1px solid #e2e5e8 );" width="33.333%">
						<table width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="#ffffff">
							<tr>
								<td align="center" colspan="3" style="font: 500 14px 'Roboto', Arial, Helvetica, sans-serif;padding: 16px 5px 5px; text-transform: uppercase; letter-spacing: 0.01em;"><font color="#848484"><?php esc_html_e( 'Total Refunds', 'wp-analytify-woocommerce' ); ?></font></td>
							</tr>
							<tr>
								<td width="45"></td><td align="center"><hr style="margin:0;border:0;border-top: 1px solid #e5e5e5;"/></td><td width="45"></td>
							</tr>
							<tr>
								<td align="center" colspan="3" style="padding: 13px 5px 10px; font: 400 24px 'Roboto', Arial, Helvetica, sans-serif;"><font color="#444444"><?php echo esc_html( $stats->totalsForAllResults['ga:totalRefunds']; ?></font></td>
							</tr>
						</table>
					</td>
				</tr>
				*/
				?>
				<?php else : ?>
					<tr>
						<td align="center" style="padding:15px; font: 500 13px 'Roboto', Arial, Helvetica, sans-serif; border: 1px solid #e2e5e8;" bgcolor="#f5f9ff" width="33.333%"><font color="#444444"><?php esc_html_e( 'Transactions', 'wp-analytify-pro' ); ?></font></td>
						<td align="center" style="padding:15px; font: 500 13px 'Roboto', Arial, Helvetica, sans-serif; border: 1px solid #e2e5e8;" bgcolor="#f5f9ff" width="33.333%"><font color="#444444"><?php esc_html_e( 'Transaction Revenues', 'wp-analytify-pro' ); ?></font></td>
						<td align="center" style="padding:15px; font: 500 13px 'Roboto', Arial, Helvetica, sans-serif; border: 1px solid #e2e5e8;" bgcolor="#f5f9ff" width="33.333%"><font color="#444444"><?php esc_html_e( 'Average Order Value', 'wp-analytify-pro' ); ?></font></td>
					</tr>
					<?php analytify_email_render_no_data_row( 3 ); ?>
				<?php endif; ?>
			</table>
		</td>
	</tr>
	<tr>
		<td style="border:1px solid #e2e5e8; border-top: 0;">
			<table cellpadding="0" cellspacing="16" border="0" width="100%" bgcolor="#f9fafa">
				<tr>
					<td width="32" style="text-align: right;"><img src="<?php echo esc_url( ANALYTIFY_IMAGES_PATH . 'anlytify_about_icon.png' ); ?>" alt="About icon"></td>
					<td style="font: normal 13px 'Roboto', Arial, Helvetica, sans-serif;"><font color="#444444"><?php esc_html_e( 'Key e-commerce metrics for your Easy Digital Downloads store during the selected period.', 'wp-analytify-pro' ); ?></font></td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td style="padding:15px;"></td>
	</tr>
	<?php
	$message = ob_get_clean();
	return $message ? $message : '';
}

