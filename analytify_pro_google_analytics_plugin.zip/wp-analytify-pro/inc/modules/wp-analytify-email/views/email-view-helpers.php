<?php
/**
 * Shared helpers for Analytify email report view templates.
 *
 * @package WP_Analytify_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'analytify_email_section_gap_style' ) ) {
	/**
	 * Inline styles for vertical separation between email report sections.
	 *
	 * Padding on a wrapper cell is more reliable across clients than empty spacer rows.
	 *
	 * @param string $position Which sides to pad: both, top, or bottom.
	 * @param int    $size     Gap size in pixels.
	 * @return string
	 */
	function analytify_email_section_gap_style( $position = 'both', $size = 24 ) {
		$size  = max( 1, (int) $size );
		$parts = array();

		if ( in_array( $position, array( 'both', 'top' ), true ) ) {
			$parts[] = 'padding-top:' . $size . 'px';
		}
		if ( in_array( $position, array( 'both', 'bottom' ), true ) ) {
			$parts[] = 'padding-bottom:' . $size . 'px';
		}

		return implode( '; ', $parts );
	}
}

if ( ! function_exists( 'analytify_email_render_section_spacer' ) ) {
	/**
	 * Output a reliable vertical gap between email report sections.
	 *
	 * Empty padding-only cells collapse in many clients; height + nbsp is required.
	 *
	 * @param int $height Spacer height in pixels.
	 * @return void
	 */
	function analytify_email_render_section_spacer( $height = 24 ) {
		$height = max( 1, (int) $height );
		?>
		<tr>
			<td bgcolor="#f3f7fa" height="<?php echo esc_attr( (string) $height ); ?>" style="background-color:#f3f7fa;height:<?php echo esc_attr( (string) $height ); ?>px;line-height:<?php echo esc_attr( (string) $height ); ?>px;font-size:1px;mso-line-height-rule:exactly;">&nbsp;</td>
		</tr>
		<?php
	}
}

if ( ! function_exists( 'analytify_email_has_stat_rows' ) ) {
	/**
	 * Whether a GA report payload contains at least one data row.
	 *
	 * @param mixed $data Report data array.
	 * @return bool
	 */
	function analytify_email_has_stat_rows( $data ) {
		return is_array( $data ) && ! empty( $data['rows'] );
	}
}

if ( ! function_exists( 'analytify_email_render_no_data_row' ) ) {
	/**
	 * Output a centered empty-state row for email stat tables.
	 *
	 * @param int    $colspan    Number of columns to span.
	 * @param string $cell_style Optional extra CSS for the table cell.
	 * @return void
	 */
	function analytify_email_render_no_data_row( $colspan, $cell_style = 'border-top: 1px solid #e2e5e8;' ) {
		$colspan    = max( 1, (int) $colspan );
		$cell_style = trim( (string) $cell_style );
		$base_style = 'padding:15px; font: 400 13px \'Roboto\', Arial, Helvetica, sans-serif;';
		$style      = $cell_style ? $base_style . ' ' . $cell_style : $base_style;
		?>
		<tr>
			<td colspan="<?php echo esc_attr( (string) $colspan ); ?>" align="center" style="<?php echo esc_attr( $style ); ?>">
				<font color="#444444"><?php esc_html_e( 'No activity during this period.', 'wp-analytify-pro' ); ?></font>
			</td>
		</tr>
		<?php
	}
}
