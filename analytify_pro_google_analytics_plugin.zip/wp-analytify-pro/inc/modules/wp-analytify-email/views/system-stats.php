<?php
/**
 * System Stats View.
 *
 * @package WP_Analytify_Pro
 * @version 8.1.0
 */

/**
 * Function to display system stats.
 *
 * @param mixed                $analytify_email Email instance.
 * @param array<string, mixed> $browser_stats Browser stats data.
 * @param array<string, mixed> $operating_systems Operating systems data.
 * @param array<string, mixed> $mobile_phones Mobile devices data.
 * @return string
 */
function pa_system_stats( $analytify_email, $browser_stats, $operating_systems, $mobile_phones ) {

	ob_start();
	?>

	<!--Start System Stats.-->
	<tr>
	<td valign="top" style="border: 1px solid #e2e5e8;">
		<table width="100%" cellspacing="0" cellpadding="0" border="0" align="center" bgcolor="#f9fafa">
		<tr>
			<td style="font: normal 16px 'Roboto slab', Arial, Helvetica, sans-serif; padding: 11px 20px;"><font color="#444444"><?php analytify_e( 'System Statistics', 'wp-analytify' ); ?></font></td>
		</tr>
		</table>
	</td>
	</tr>
	<tr>
	<td style="border:1px solid #e2e5e8; border-top-width: 0;">
		<table width="100%" cellpadding="0" cellspacing="0" border="0">
		<tr>
			<td width="100%" style="border-right:1px solid #e2e5e8;" colspan="2">
			<table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#ffffff">
				<tr>
				<td style="padding:15px; font: 400 13px 'Roboto', Arial, Helvetica, sans-serif;" bgcolor="#f5f9ff" colspan="2"><font color="#444444"><?php analytify_e( 'Top Browsers', 'wp-analytify' ); ?></font></td>
				<td style="padding:15px; font: 400 13px 'Roboto', Arial, Helvetica, sans-serif;border-left: 1px solid #e2e5e8;" bgcolor="#f5f9ff" width="50" align="right"><font color="#444444"><?php analytify_e( 'Visits', 'wp-analytify' ); ?></font></td>
				</tr>

				<?php if ( analytify_email_has_stat_rows( $browser_stats ) ) : ?>
					<?php foreach ( $browser_stats['rows'] as $browser ) : ?>
					<tr>
					<td style="padding:15px; font: 400 13px 'Roboto', Arial, Helvetica, sans-serif;border-top: 1px solid #e2e5e8;" width="50"><img src="<?php echo esc_url( ANALYTIFY_IMAGES_PATH . ( function_exists( 'pretty_class' ) ? pretty_class( $browser['browser'] ) : 'default' ) . '.png' ); ?>" alt="" hspace="3"/></td>
					<td style="padding:15px; font: 400 13px 'Roboto', Arial, Helvetica, sans-serif;border-top: 1px solid #e2e5e8;"><font color="#444444"><?php echo esc_html( $browser['browser'] . ' ' . $browser['operatingSystem'] ); ?></font></td>
					<td style="padding:15px; font: 400 13px 'Roboto', Arial, Helvetica, sans-serif;border-top: 1px solid #e2e5e8;" align="right"><font color="#444444"><?php echo esc_html( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' ) ? WPANALYTIFY_Utils::pretty_numbers( $browser['sessions'] ) : $browser['sessions'] ); ?></font></td>
					</tr>
				<?php endforeach; ?>
				<?php else : ?>
					<?php analytify_email_render_no_data_row( 3 ); ?>
				<?php endif; ?>

			</table>
			</td>

		</tr>
		<tr class="os-table">
			<td width="50%" style="border-right:1px solid #e2e5e8; background-color: #ffffff; border-top:1px solid #e2e5e8;" valign="top">
			<table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#ffffff">
				<tr>
				<td style="padding:15px; font: 400 13px 'Roboto', Arial, Helvetica, sans-serif; " bgcolor="#f5f9ff" colspan="2"><font color="#444444"><?php esc_html_e( 'Top Operating Systems', 'wp-analytify-pro' ); ?></font></td>
				<td style="padding:15px; font: 400 13px 'Roboto', Arial, Helvetica, sans-serif;border-left: 1px solid #e2e5e8;" bgcolor="#f5f9ff" width="50" align="right"><font color="#444444"><?php analytify_e( 'Visits', 'wp-analytify' ); ?></font></td>
				</tr>

				<?php if ( analytify_email_has_stat_rows( $operating_systems ) ) : ?>
					<?php foreach ( $operating_systems['rows'] as $operating_system ) : ?>
					<tr>
					<td style="padding:15px; font: 400 13px 'Roboto', Arial, Helvetica, sans-serif;border-top: 1px solid #e2e5e8;" width="20"><img src="<?php echo esc_url( ANALYTIFY_IMAGES_PATH . ( function_exists( 'pretty_class' ) ? pretty_class( $operating_system['operatingSystem'] ) : 'default' ) . '.png' ); ?>" alt=""  /></td>
					<td style="padding:15px; font: 400 13px 'Roboto', Arial, Helvetica, sans-serif;border-top: 1px solid #e2e5e8;"><font color="#444444"><?php echo esc_html( $operating_system['operatingSystemVersion'] ); ?></font></td>
					<td style="padding:15px; font: 400 13px 'Roboto', Arial, Helvetica, sans-serif;border-top: 1px solid #e2e5e8;" align="right"><font color="#444444"><?php echo esc_html( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' ) ? WPANALYTIFY_Utils::pretty_numbers( $operating_system['sessions'] ) : $operating_system['sessions'] ); ?></font></td>
					</tr>
				<?php endforeach; ?>
				<?php else : ?>
					<?php analytify_email_render_no_data_row( 3 ); ?>
				<?php endif; ?>

			</table>
			</td>
			<td width="50%" style="border-right:1px solid #e2e5e8; background-color: #ffffff; border-top:1px solid #e2e5e8;" valign="top">
			<table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#ffffff">
				<tr>
				<td style="padding:15px; font: 400 13px 'Roboto', Arial, Helvetica, sans-serif; " bgcolor="#f5f9ff" colspan="2"><font color="#444444"><?php esc_html_e( 'Top Mobile Devices', 'wp-analytify-pro' ); ?></font></td>
				<td style="padding:15px; font: 400 13px 'Roboto', Arial, Helvetica, sans-serif;border-left: 1px solid #e2e5e8; " bgcolor="#f5f9ff" width="50" align="right"><font color="#444444"><?php analytify_e( 'Visits', 'wp-analytify' ); ?></font></td>
				</tr>

				<?php if ( analytify_email_has_stat_rows( $mobile_phones ) ) : ?>
					<?php foreach ( $mobile_phones['rows'] as $mobile_phone ) : ?>
				<tr>
					<td style="padding:15px; font: 400 13px 'Roboto', Arial, Helvetica, sans-serif;border-top: 1px solid #e2e5e8;" width="20">
						<?php
						$image_file = ANALYTIFY_IMAGES_PATH . ( function_exists( 'pretty_class' ) ? pretty_class( $mobile_phone['mobileDeviceBranding'] ) : 'default' ) . '.png';

					// phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- Error suppression needed for remote image header check.
						$headers = @get_headers( $image_file );
						if ( $headers && strpos( $headers[0], '200' ) ) {
							$image_path = $image_file;
						} else {
							$image_path = plugins_url( 'assets/img/mobile.svg', __DIR__ );
						}

						?>
					<img src="<?php echo esc_url( $image_path ); ?>" alt=""/>
					</td>
					<td style="padding:15px; font: 400 13px 'Roboto', Arial, Helvetica, sans-serif;border-top: 1px solid #e2e5e8;">
					<font color="#444444">
						<?php echo esc_html( ! empty( $mobile_phone['mobileDeviceModel'] ) ? $mobile_phone['mobileDeviceModel'] : 'N/A' ); ?>
					</font>
					</td>
					<td style="padding:15px; font: 400 13px 'Roboto', Arial, Helvetica, sans-serif;border-top: 1px solid #e2e5e8;" align="right">
					<font color="#444444">
						<?php echo esc_html( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' ) ? WPANALYTIFY_Utils::pretty_numbers( $mobile_phone['sessions'] ) : $mobile_phone['sessions'] ); ?>
					</font>
					</td>
				</tr>
				<?php endforeach; ?>
				<?php else : ?>
					<?php analytify_email_render_no_data_row( 3 ); ?>
				<?php endif; ?>

				</table>
			</td>

		</tr>
		</table>
	</td>
	</tr>
	<tr>
	<td style="border:1px solid #e2e5e8; border-top: 0;">
		<table cellpadding="0" cellspacing="16" border="0" width="100%" bgcolor="#f9fafa">
		<tr>
			<td width="32" style="text-align: right;"><img src="<?php echo esc_url( ANALYTIFY_IMAGES_PATH . 'anlytify_about_icon.png' ); ?>" alt="about icon"/></td>
			<td style="font: normal 13px 'Roboto', Arial, Helvetica, sans-serif;"><font color="#444444"><?php analytify_e( 'List of top browsers, operating systems, and mobile devices used by your site visitors.', 'wp-analytify' ); ?></font></td>
		</tr>
		</table>
	</td>
	</tr>
	<tr>
	<td style="padding:15px;"></td>
	</tr>
	<!--End System Stats.-->

	<?php
	$message = ob_get_clean();
	return $message ? $message : '';
}

