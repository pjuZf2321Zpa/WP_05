<?php
/**
 * Forms Tracking Stats View.
 *
 * @package WP_Analytify_Pro
 */

/**
 * Include forms tracking stats HTML.
 *
 * @param mixed                $current Current instance.
 * @param array<string, mixed> $top_page_stats Forms stats data.
 * @return string
 */
function pa_include_forms_tracking_stats( $current, $top_page_stats ) {
	ob_start();
	?>
	<!--Top pages by views.-->
	<tr>
		<td valign="top" style="border: 1px solid #e2e5e8;">
			<table width="100%" cellspacing="0" cellpadding="0" border="0" align="center" bgcolor="#f9fafa">
				<tr>
					<td style="font: normal 16px 'Roboto slab', Arial, Helvetica, sans-serif; padding: 11px 20px;">
						<font color="#444444"><?php analytify_e( 'Forms Tracking Stats', 'wp-analytify' ); ?></font>
					</td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td style="border:1px solid #e2e5e8; border-top-width: 0; border-bottom-width: 0;">
			<table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#ffffff">
				<tr>
					<td align="center" style="padding:15px; font: 400 13px 'Roboto', Arial, Helvetica, sans-serif; border-right: 1px solid #e2e5e8; border-bottom: 1px solid #e2e5e8; " bgcolor="#f5f9ff" width="20">
						<font color="#444444">#</font>
					</td>
					<td style="padding:15px; font: 400 13px 'Roboto', Arial, Helvetica, sans-serif; border-bottom: 1px solid #e2e5e8;" bgcolor="#f5f9ff">
						<font color="#444444"><?php analytify_e( 'Type', 'wp-analytify' ); ?></font>
					</td>
					<td style="padding:15px; font: 400 13px 'Roboto', Arial, Helvetica, sans-serif; border-bottom: 1px solid #e2e5e8;" bgcolor="#f5f9ff">
						<font color="#444444"><?php analytify_e( 'Name', 'wp-analytify' ); ?></font>
					</td>
					<td style="padding:15px; font: 400 13px 'Roboto', Arial, Helvetica, sans-serif;border-left: 1px solid #e2e5e8; border-bottom: 1px solid #e2e5e8;" bgcolor="#f5f9ff" width="50" align="right">
						<font color="#444444"><?php analytify_e( 'Impressions', 'wp-analytify' ); ?></font>
					</td>
					<td style="padding:15px; font: 400 13px 'Roboto', Arial, Helvetica, sans-serif;border-left: 1px solid #e2e5e8; border-bottom: 1px solid #e2e5e8;" bgcolor="#f5f9ff" width="50" align="right">
						<font color="#444444"><?php analytify_e( 'Submissions', 'wp-analytify' ); ?></font>
					</td>
				</tr>

			<?php $count = 0; ?>
			<?php $form_types_exist = false; ?>
			<?php foreach ( array( 'analytify_form_wpcf7', 'analytify_form_custom', 'analytify_form_wpforms', 'analytify_form_ninja_forms', 'analytify_form_gf', 'analytify_form_formidable', 'analytify_form_fluentforms', 'analytify_form_happyforms', 'analytify_form_forminator', 'analytify_form_givewp', 'analytify_form_weforms', 'analytify_form_wsforms', 'analytify_form_hubspot', 'analytify_form_jotform', 'analytify_form_mailpoet', 'analytify_form_elementor' ) as $form_type ) : ?>
				<?php if ( isset( $top_page_stats[ $form_type ]['stats'] ) ) : ?>
					<?php foreach ( $top_page_stats[ $form_type ]['stats'] as $row ) : ?>
						<?php $form_types_exist = true; ?>
							<tr>
								<td style="padding:15px; font: 400 13px 'Roboto', Arial, Helvetica, sans-serif; border-bottom: 1px solid #e2e5e8;">
									<font color="#444444"><?php echo esc_html( ++$count ); ?></font>
								</td>
							<td style="padding:15px; font: 400 13px 'Roboto', Arial, Helvetica, sans-serif; border-bottom: 1px solid #e2e5e8;">
								<font color="#444444">
								<?php
								if ( 'analytify_form_wpcf7' === $form_type ) {
									analytify_e( 'Contact Form 7', 'wp-analytify' );
								} elseif ( 'analytify_form_wpforms' === $form_type ) {
									analytify_e( 'WPForms', 'wp-analytify' );
								} elseif ( 'analytify_form_ninja_forms' === $form_type ) {
									analytify_e( 'Ninja Forms', 'wp-analytify' );
								} elseif ( 'analytify_form_elementor' === $form_type ) {
									analytify_e( 'Elementor Forms', 'wp-analytify' );
								} elseif ( 'analytify_form_hubspot' === $form_type ) {
									analytify_e( 'Hubspot Forms', 'wp-analytify' );
								} elseif ( 'analytify_form_jotform' === $form_type ) {
									analytify_e( 'Jotforms', 'wp-analytify' );
								} elseif ( 'analytify_form_mailpoet' === $form_type ) {
									analytify_e( 'MailPoet', 'wp-analytify' );
								} elseif ( 'analytify_form_gf' === $form_type ) {
									analytify_e( 'Gravity Form', 'wp-analytify' );
								} elseif ( 'analytify_form_formidable' === $form_type ) {
									analytify_e( 'Formidable Form', 'wp-analytify' );
								} elseif ( 'analytify_form_fluentforms' === $form_type ) {
									analytify_e( 'Fluent Forms', 'wp-analytify' );
								} elseif ( 'analytify_form_happyforms' === $form_type ) {
									analytify_e( 'Happyforms', 'wp-analytify' );
								} elseif ( 'analytify_form_forminator' === $form_type ) {
									analytify_e( 'Forminator', 'wp-analytify' );
								} elseif ( 'analytify_form_givewp' === $form_type ) {
									analytify_e( 'GiveWP', 'wp-analytify' );
								} elseif ( 'analytify_form_weforms' === $form_type ) {
									analytify_e( 'weForms', 'wp-analytify' );
								} elseif ( 'analytify_form_wsforms' === $form_type ) {
									analytify_e( 'WS Forms', 'wp-analytify' );
								} else {
									analytify_e( 'Custom Forms', 'wp-analytify' );
								}
								?>
									</font>
								</td>
								<td style="padding:15px; font: 400 13px 'Roboto', Arial, Helvetica, sans-serif; border-bottom: 1px solid #e2e5e8;">
									<font color="#444444"><?php echo esc_html( isset( $row['title'] ) ? (string) $row['title'] : '' ); ?></font>
								</td>
								<?php foreach ( array( 'impression', 'submission' ) as $key ) : ?>
									<td style="padding:15px; font: 400 13px 'Roboto', Arial, Helvetica, sans-serif; border-bottom: 1px solid #e2e5e8;" align="right">
										<font color="#444444">
										<?php
										$cell  = isset( $row[ $key ] ) ? $row[ $key ] : 0;
										$value = $cell ? ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' ) ? WPANALYTIFY_Utils::pretty_numbers( $cell ) : $cell ) : 0;
										echo esc_html( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' ) ? WPANALYTIFY_Utils::pretty_numbers( $value ) : $value );
										?>
																</font>
									</td>
								<?php endforeach; ?>
							</tr>
						<?php endforeach; ?>
					<?php endif; ?>
				<?php endforeach; ?>

				<?php if ( ! $form_types_exist ) : ?>
					<?php analytify_email_render_no_data_row( 5, 'border-bottom: 1px solid #e2e5e8;' ); ?>
				<?php endif; ?>
			</table>
		</td>
	</tr>
	<tr>
		<td style="border:1px solid #e2e5e8; border-top: 0;">
			<table cellpadding="0" cellspacing="16" border="0" width="100%" bgcolor="#f9fafa">
			<tr>
				<td width="32" style="text-align: right;"><img src="<?php echo esc_url( ANALYTIFY_IMAGES_PATH . 'anlytify_about_icon.png' ); ?>" alt="about icon" /></td>
				<td style="font: normal 13px 'Roboto', Arial, Helvetica, sans-serif;">
					<font color="#444444"><?php analytify_e( '\'Impressions\' show how many times a particular form has been viewed.', 'wp-analytify' ); ?></font>
				</td>
			</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td style="padding:15px;"></td>
	</tr>
	<!--End pages by views.-->
	<?php
	$message = ob_get_clean();
	return $message ? $message : '';
}
?>
