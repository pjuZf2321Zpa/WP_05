<?php
/**
 * Keyword and Referral View.
 *
 * @package WP_Analytify_Pro
 * @version 8.1.0
 */

/**
 * Generate keyword and referral HTML.
 *
 * @param mixed                $analytify_email Email instance.
 * @param array<string, mixed> $keywords Keywords data.
 * @param array<string, mixed> $refferals Referrals data.
 * @return string
 */
function pa_keyword_referral( $analytify_email, $keywords, $refferals ) {
	// phpcs:ignore WordPress.NamingConventions.ValidVariableName.VariableNotSnakeCase -- Legacy parameter name.
	$total_keywords_traffic = 0;

	if ( $keywords ) {
		foreach ( $keywords as $keyword ) {
			$total_keywords_traffic = $keyword['impressions'] + $total_keywords_traffic;
		}
	}

	$total_refferals_traffic = $refferals['aggregations']['sessions'] ?? 0;
	ob_start();
	?>
	<!--Start Keywords-->
	<tr>
	<td valign="top" style="<?php echo esc_attr( analytify_email_section_gap_style( 'bottom' ) ); ?>">
	<!--     <table width="100%" cellspacing="0" cellpadding="0" border="0">
		<tr class="keywords-table">
			<td width="50%" valign="top"> -->
			<table width="100%" cellspacing="0" cellpadding="0" border="0">
				<tr>
				<td style="border: 1px solid #e2e5e8; border-right-width:0" valign="top">
					<table align="center" bgcolor="#f9fafa" border="0" cellpadding="0" cellspacing="0" width="100%">
					<tr>
					  
						<?php if ( $keywords ) { ?>
						<td
							<?php
							if ( ! $refferals ) {
								?>
						colspan="2"<?php } ?> style="font: normal 16px 'Roboto slab', Arial, Helvetica, sans-serif; padding: 11px 20px; border-bottom: 1px solid #e2e5e8;"><font color="#444444"><?php esc_html_e( 'Keywords', 'wp-analytify-pro' ); ?></font></td>
						
						<td
							<?php
							if ( ! $refferals ) {
								?>
							colspan="2"<?php } ?> align="right" style="font: normal 16px 'Roboto slab', Arial, Helvetica, sans-serif; padding: 11px 20px 11px 0; border-bottom: 1px solid #e2e5e8;border-right: 1px solid #e2e5e8;" width="100"> <small><font color="#848484"><?php analytify_e( 'Total Visits', 'wp-analytify' ); ?></font></small><br/><font color="#444444"><?php echo esc_html( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' ) ? WPANALYTIFY_Utils::pretty_numbers( $total_keywords_traffic ) : $total_keywords_traffic ); ?></font> </td>
						<?php } ?>

						<?php if ( $refferals ) { ?>
						<td
							<?php
							if ( ! $keywords ) {
								?>
						colspan="2"<?php } ?> style="font: normal 16px 'Roboto slab', Arial, Helvetica, sans-serif; padding: 11px 20px; border-bottom: 1px solid #e2e5e8;"><font color="#444444"><?php esc_html_e( 'Top Referrers', 'wp-analytify-pro' ); ?></font></td>
						
						<td
							<?php
							if ( ! $keywords ) {
								?>
							colspan="2"<?php } ?> align="right" style="font: normal 16px 'Roboto slab', Arial, Helvetica, sans-serif; padding: 11px 20px 11px 0; border-bottom: 1px solid #e2e5e8;border-right: 1px solid #e2e5e8;" width="100"> <small><font color="#848484"><?php analytify_e( 'Total Visits', 'wp-analytify' ); ?></font></small><br/><font color="#444444"><?php echo esc_html( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' ) ? WPANALYTIFY_Utils::pretty_numbers( $total_refferals_traffic ) : $total_refferals_traffic ); ?></font> </td>
						<?php } ?>

					</tr>
					<tr>
					  
						<?php if ( $keywords ) { ?>
						<td colspan="<?php echo $refferals ? 2 : 4; ?>" width="50%" valign="top" style="background-color: #ffffff;border-right: 1px solid #e2e5e8;">
						<table width="100%" cellpadding="0" cellspacing="0" border="0">

							<?php if ( ! empty( $keywords ) ) : ?>
								<?php foreach ( $keywords as $keyword ) : ?>
								<tr>
								<td style="font: normal 13px 'Roboto', Arial, Helvetica, sans-serif; padding: 11px 20px 5px;"><font color="#444444">
									<?php echo esc_html( $keyword['keys'][0] ); ?>
								</font></td>
								<td style="font: normal 13px 'Roboto', Arial, Helvetica, sans-serif; padding: 11px 20px 5px;" align="right"><font color="#444444"><?php echo esc_html( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' ) ? WPANALYTIFY_Utils::pretty_numbers( $keyword['impressions'] ) : $keyword['impressions'] ); ?></font></td>
								</tr>
								<tr>
								<td style="padding:0 20px 9px;" colspan="2">
									<table cellpadding="0" cellspacing="0" border="0" width="100%">
									<tbody><tr>
										<td style="padding-bottom: 2px;" bgcolor="#00c853" width="<?php echo esc_html( ( $keyword['impressions'] / $total_keywords_traffic ) * 100 ); ?>%"></td>
										<td style="padding-bottom: 2px;" bgcolor="#f5f5f5"></td>
									</tr>
									</tbody></table>
								</td>
								</tr>
							<?php endforeach; ?>
							<?php else : ?>
								<?php analytify_email_render_no_data_row( 3 ); ?>
							<?php endif; ?>
						</table>
						</td>
						<?php } ?>
					  
						<?php if ( $refferals ) { ?>
						<td colspan="<?php echo esc_html( ! empty( $keywords ) ? 2 : 4 ); ?>" width="50%" valign="top" style="background-color: #ffffff;border-right: 1px solid #e2e5e8;">
						<table width="100%" cellpadding="0" cellspacing="0" border="0">

							<?php if ( analytify_email_has_stat_rows( $refferals ) ) : ?>
								<?php foreach ( $refferals['rows'] as $refferal ) : ?>
								<tr>
								<td style="font: normal 13px 'Roboto', Arial, Helvetica, sans-serif; padding: 11px 20px 5px;"><font color="#444444"><?php echo esc_html( $refferal['sessionSource'] . ' / ' . $refferal['sessionMedium'] ); ?></font></td>
								<td style="font: normal 13px 'Roboto', Arial, Helvetica, sans-serif; padding: 11px 20px 5px;" align="right"><font color="#444444"><?php echo esc_html( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' ) ? WPANALYTIFY_Utils::pretty_numbers( $refferal['sessions'] ) : $refferal['sessions'] ); ?></font></td>
								</tr>
								<tr>
								<td style="padding:0 20px 9px;" colspan="2">
									<table cellpadding="0" cellspacing="0" border="0" width="100%">
									<tbody><tr>
										<td style="padding-bottom: 2px;" bgcolor="#00c853" width="<?php echo esc_html( ( $refferal['sessions'] / $total_refferals_traffic ) * 100 ); ?>%"></td>
										<td style="padding-bottom: 2px;" bgcolor="#f5f5f5"></td>
									</tr>
									</tbody></table>
								</td>
								</tr>
							<?php endforeach; ?>

							<?php else : ?>
								<?php analytify_email_render_no_data_row( 3 ); ?>
							<?php endif; ?>
							</table>
						</td>
						<?php } ?>

					</tr>

					<tr>

						<?php if ( $keywords ) { ?>
						<td colspan="<?php echo esc_html( $refferals ? 2 : 4 ); ?>" width="50%" valign="top" style="border-top: 1px solid #e2e5e8;border-right: 1px solid #e2e5e8;">
							<table cellpadding="0" cellspacing="16" border="0" width="100%" bgcolor="#f9fafa">
							<tr>
								<td width="32" style="text-align: right;"><img src="<?php echo esc_url( ANALYTIFY_IMAGES_PATH . 'anlytify_about_icon.png' ); ?>" alt="About icon"/></td>
								<td style="font: normal 13px 'Roboto', Arial, Helvetica, sans-serif;"><font color="#444444"><?php esc_html_e( 'Top search keywords.', 'wp-analytify-pro' ); ?></font></td>
							</tr>
							</table>
						</td>
						<?php } ?>

						<?php if ( $refferals ) { ?>
						<td colspan="<?php echo esc_html( ! empty( $keywords ) ? 2 : 4 ); ?>" width="50%" valign="top" style="border-top: 1px solid #e2e5e8;border-right: 1px solid #e2e5e8;">
							<table cellpadding="0" cellspacing="16" border="0" width="100%" bgcolor="#f9fafa">
							<tr>
								<td width="32" style="text-align: right;"><img src="<?php echo esc_url( ANALYTIFY_IMAGES_PATH . 'anlytify_about_icon.png' ); ?>" alt="About icon"/></td>
								<td style="font: normal 13px 'Roboto', Arial, Helvetica, sans-serif;"><font color="#444444"><?php esc_html_e( 'Top referrers to your site.', 'wp-analytify-pro' ); ?></font></td>
							</tr>
							</table>
						</td>
						<?php } ?>

					</tr>

					</table>
				</td>

	<?php
		/*
		<td width="50%" valign="top">
			<table width="100%" cellspacing="0" cellpadding="0" border="0">
				<tr>
				<td style="border: 1px solid #e2e5e8;" valign="top">
					<table align="center" bgcolor="#f9fafa" border="0" cellpadding="0" cellspacing="0" width="100%">
					<tr>
						<td style="font: normal 16px 'Roboto slab', Arial, Helvetica, sans-serif; padding: 11px 20px; border-bottom: 1px solid #e2e5e8;" width="190"><font color="#444444">Top Referres</font></td>
						<td align="right" style="font: normal 16px 'Roboto slab', Arial, Helvetica, sans-serif; padding: 11px 20px 11px 0; border-bottom: 1px solid #e2e5e8;" width="250"> <small><font color="#848484">Total Visits</font></small><br/><font color="#444444"><?php echo esc_html( $total_refferals_traffic ?></font> </td>
					</tr>
					<tr>
						<td colspan="2" style="background-color: #ffffff;">
						<table width="100%" cellpadding="0" cellspacing="0" border="0">

							<?php if ( analytify_email_has_stat_rows( $refferals ) ): ?>
							<?php foreach ( $refferals['rows'] as $refferal ): ?>
								<tr>
								<td style="font: normal 13px 'Roboto', Arial, Helvetica, sans-serif; padding: 11px 20px 5px;"><font color="#444444"><?php echo esc_html( $refferal[0] ." / ". $refferal[1] ?></font></td>
								<td style="font: normal 13px 'Roboto', Arial, Helvetica, sans-serif; padding: 0 20px 11px );" align="right"><font color="#444444"><?php echo esc_html( $refferal[2] ?></font></td>
								</tr>
								<tr>
								<td style="padding:0 20px 9px;" colspan="2">
									<table cellpadding="0" cellspacing="0" border="0" width="100%">
									<tbody><tr>
										<td style="padding-bottom: 2px;" bgcolor="#00c853" width="<?php echo esc_html( ( $refferal[2] / $total_refferals_traffic ) * 100 ?>%"></td>
										<td style="padding-bottom: 2px;" bgcolor="#f5f5f5"></td>
									</tr>
									</tbody></table>
								</td>
								</tr>
							<?php endforeach ); ?>

							<?php else : ?>
							<?php analytify_email_render_no_data_row( 3 ); ?>
							<?php endif; ?>
						</table>
						</td>
					</tr>
					<tr>
						<td colspan="2" style="border-top: 1px solid #e2e5e8;">
						<table cellpadding="0" cellspacing="16" border="0" width="100%" bgcolor="#f9fafa">
							<tr>
							<td width="32" style="text-align: right;"><img src="<?php echo esc_url( ANALYTIFY_IMAGES_PATH . 'anlytify_about_icon.png' ); ?>" alt="about icon"/></td>
							<td style="font: normal 13px 'Roboto', Arial, Helvetica, sans-serif;"><font color="#444444">who are the strong Referrers to your site ?? See above</font></td>
							</tr>
						</table>
						</td>
					</tr>
					</table>
				</td>
				</tr>
			</table>
			</td>
			*/
	?>
		</tr>
		</table>
	</td>
	</tr>
	<!--End Keywords-->

	<?php
	$message = ob_get_clean();
	return $message ? $message : '';
}

