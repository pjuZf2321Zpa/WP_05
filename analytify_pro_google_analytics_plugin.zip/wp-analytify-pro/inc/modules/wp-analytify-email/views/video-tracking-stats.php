<?php
/**
 * Video Tracking Stats View.
 *
 * @package WP_Analytify_Pro
 */

/**
 * Include video tracking stats HTML.
 *
 * @param mixed                $current Current instance.
 * @param array<string, mixed> $video_stats Video tracking stats data.
 * @return string
 */
function pa_include_video_tracking_stats( $current, $video_stats ) {
	$video_limit = (int) apply_filters( 'analytify_api_limit_video_tracking_email', 5 );
	if ( is_array( $video_stats ) && $video_limit > 0 && count( $video_stats ) > $video_limit ) {
		$video_stats = array_slice( $video_stats, 0, $video_limit );
	}

	ob_start();
	?>
	<!--Video tracking stats.-->
	<tr>
		<td style="<?php echo esc_attr( analytify_email_section_gap_style() ); ?>">
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td valign="top" style="border: 1px solid #e2e5e8;">
						<table width="100%" cellspacing="0" cellpadding="0" border="0" align="center" bgcolor="#f9fafa">
							<tr>
								<td style="font: normal 16px 'Roboto slab', Arial, Helvetica, sans-serif; padding: 11px 20px;">
									<font color="#444444"><?php analytify_e( 'Video Tracking Stats', 'wp-analytify-pro' ); ?></font>
								</td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td style="border:1px solid #e2e5e8; border-top-width: 0; border-bottom-width: 0;">
						<table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#ffffff">
							<tr>
								<td align="center" style="padding:15px; font: 400 13px 'Roboto', Arial, Helvetica, sans-serif; border-right: 1px solid #e2e5e8; border-bottom: 1px solid #e2e5e8;" bgcolor="#f5f9ff" width="20">
									<font color="#444444">#</font>
								</td>
								<td style="padding:15px; font: 400 13px 'Roboto', Arial, Helvetica, sans-serif; border-bottom: 1px solid #e2e5e8;" bgcolor="#f5f9ff">
									<font color="#444444"><?php analytify_e( 'Title', 'wp-analytify-pro' ); ?></font>
								</td>
								<td style="padding:15px; font: 400 13px 'Roboto', Arial, Helvetica, sans-serif; border-bottom: 1px solid #e2e5e8;" bgcolor="#f5f9ff">
									<font color="#444444"><?php analytify_e( 'Action', 'wp-analytify-pro' ); ?></font>
								</td>
								<td style="padding:15px; font: 400 13px 'Roboto', Arial, Helvetica, sans-serif; border-bottom: 1px solid #e2e5e8;" bgcolor="#f5f9ff">
									<font color="#444444"><?php analytify_e( 'Provider', 'wp-analytify-pro' ); ?></font>
								</td>
								<td style="padding:15px; font: 400 13px 'Roboto', Arial, Helvetica, sans-serif;border-left: 1px solid #e2e5e8; border-bottom: 1px solid #e2e5e8;" bgcolor="#f5f9ff" width="50" align="right">
									<font color="#444444"><?php analytify_e( 'Duration (s)', 'wp-analytify-pro' ); ?></font>
								</td>
								<td style="padding:15px; font: 400 13px 'Roboto', Arial, Helvetica, sans-serif;border-left: 1px solid #e2e5e8; border-bottom: 1px solid #e2e5e8;" bgcolor="#f5f9ff" width="50" align="right">
									<font color="#444444"><?php analytify_e( 'Event Count', 'wp-analytify-pro' ); ?></font>
								</td>
							</tr>

							<?php $count = 0; ?>
							<?php $has_video_data = false; ?>
							<?php if ( ! empty( $video_stats ) && is_array( $video_stats ) ) : ?>
								<?php foreach ( $video_stats as $stat ) : ?>
									<?php $has_video_data = true; ?>
									<tr>
										<td style="padding:15px; font: 400 13px 'Roboto', Arial, Helvetica, sans-serif; border-bottom: 1px solid #e2e5e8;">
											<font color="#444444"><?php echo esc_html( ++$count ); ?></font>
										</td>
										<td style="padding:15px; font: 400 13px 'Roboto', Arial, Helvetica, sans-serif; border-bottom: 1px solid #e2e5e8;">
											<font color="#444444"><?php echo esc_html( $stat['title'] ?? '' ); ?></font>
										</td>
										<td style="padding:15px; font: 400 13px 'Roboto', Arial, Helvetica, sans-serif; border-bottom: 1px solid #e2e5e8;">
											<font color="#444444"><?php echo esc_html( $stat['action'] ?? '' ); ?></font>
										</td>
										<td style="padding:15px; font: 400 13px 'Roboto', Arial, Helvetica, sans-serif; border-bottom: 1px solid #e2e5e8;">
											<font color="#444444"><?php echo esc_html( $stat['provider'] ?? '' ); ?></font>
										</td>
										<td style="padding:15px; font: 400 13px 'Roboto', Arial, Helvetica, sans-serif; border-bottom: 1px solid #e2e5e8;" align="right">
											<font color="#444444"><?php echo esc_html( $stat['duration'] ?? 0 ); ?></font>
										</td>
										<td style="padding:15px; font: 400 13px 'Roboto', Arial, Helvetica, sans-serif; border-bottom: 1px solid #e2e5e8;" align="right">
											<font color="#444444">
											<?php
											$event_count = $stat['count'] ?? 0;
											echo esc_html( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' ) ? WPANALYTIFY_Utils::pretty_numbers( $event_count ) : $event_count );
											?>
											</font>
										</td>
									</tr>
								<?php endforeach; ?>
							<?php endif; ?>

							<?php if ( ! $has_video_data ) : ?>
								<?php analytify_email_render_no_data_row( 6, 'border-bottom: 1px solid #e2e5e8;' ); ?>
							<?php endif; ?>
						</table>
					</td>
				</tr>
				<tr>
					<td style="border:1px solid #e2e5e8; border-top: 0;">
						<table cellpadding="0" cellspacing="16" border="0" width="100%" bgcolor="#f9fafa">
							<tr>
								<td width="32" style="text-align: right;"><img src="<?php echo esc_url( ANALYTIFY_IMAGES_PATH . 'anlytify_about_icon.png' ); ?>" alt="about icon" /></td>
								<td style="font: normal 13px 'Roboto', Arial, Helvetica, sans-serif;">
									<font color="#444444"><?php analytify_e( 'Video tracking statistics showing video interactions on your website.', 'wp-analytify-pro' ); ?></font>
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
	<!--End video tracking stats.-->
	<?php
	$message = ob_get_clean();
	return $message ? $message : '';
}
