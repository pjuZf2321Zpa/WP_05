<?php
/**
 * What's Happening View.
 *
 * @package WP_Analytify_Pro
 */

/**
 * Generate what's happening HTML.
 *
 * @param mixed                $analytify_email Email instance.
 * @param array<string, mixed> $whats_happens What's happening data.
 * @return string
 */
function whats_happen( $analytify_email, $whats_happens ) {
	// phpcs:ignore WordPress.NamingConventions.ValidVariableName.VariableNotSnakeCase -- Legacy parameter name.

	$top_url      = '';
	$top_entrance = '';
	$images_name  = array( 'analytify_red_bullet.png', 'analytify_yellow_bullet.png', 'analytify_green_bullet.png', 'analytify_blue_bullet.png', 'analytify_gray_bullet.png' );

	ob_start();
	?>
	<tr>
	<td style="<?php echo esc_attr( analytify_email_section_gap_style() ); ?>">
		<table width="100%" cellpadding="0" cellspacing="0" border="0">
			<tr>
				<td style="border: 1px solid #e2e5e8;" valign="top">
		<table align="center" bgcolor="#f9fafa" border="0" cellpadding="0" cellspacing="0" width="100%">
		<tr>
			<td style="font: normal 16px 'Roboto slab', Arial, Helvetica, sans-serif; padding: 11px 20px;"><font color="#444444"><?php analytify_e( 'Visitors Site Behavior', 'wp-analytify' ); ?></font></td>
		</tr>
		<tr>
			<td colspan="2" class="user-data">
			<table width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="#ffffff" align="center">
				<tr>
				<td align="left" style="font: normal 14px 'Roboto', Arial, Helvetica, sans-serif; padding: 11px 20px;border-top: 1px solid #e2e5e8; border-right:1px solid #e2e5e8;"><font color="#848484"><?php analytify_e( 'Title / link', 'wp-analytify' ); ?></font></td>
				<td align="center" style="font: normal 14px 'Roboto', Arial, Helvetica, sans-serif; padding: 11px 20px;border-top: 1px solid #e2e5e8; border-right:1px solid #e2e5e8;"><font color="#848484"><?php analytify_e( 'Engagement Duration', 'wp-analytify' ); ?></font></td>
				<td align="center" style="font: normal 14px 'Roboto', Arial, Helvetica, sans-serif; padding: 11px 20px;border-top: 1px solid #e2e5e8; border-right:1px solid #e2e5e8;"><font color="#848484"><?php analytify_e( 'Engaged Sessions', 'wp-analytify' ); ?></font></td>
				<td align="center" style="font: normal 14px 'Roboto', Arial, Helvetica, sans-serif; padding: 11px 20px;border-top: 1px solid #e2e5e8; border-right:1px solid #e2e5e8;"><font color="#848484"><?php analytify_e( 'Engagement Rate', 'wp-analytify' ); ?></font></td>
				</tr>

				<?php if ( analytify_email_has_stat_rows( $whats_happens ) ) : ?>
					<?php
					$i = 0;
					?>
					<?php foreach ( $whats_happens['rows'] as $whats_happen ) : ?>
					<tr>
					<td align="left" style="font: normal 14px 'Roboto', Arial, Helvetica, sans-serif; padding: 11px 20px;border-top: 1px solid #e2e5e8; border-right:1px solid #e2e5e8;"><img src="<?php echo esc_url( ANALYTIFY_IMAGES_PATH . $images_name[ $i ] ); ?>" alt="" style="margin-right: 5px;" /><font color="#444444"><?php echo esc_html( $whats_happen['pageTitle'] ); ?></font><br/></td>
					<td align="center" style="font: normal 14px 'Roboto', Arial, Helvetica, sans-serif; padding: 11px 20px;border-top: 1px solid #e2e5e8; border-right:1px solid #e2e5e8;"><font color="#444444"><?php echo wp_kses_post( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_time' ) ? WPANALYTIFY_Utils::pretty_time( $whats_happen['userEngagementDuration'] ) : $whats_happen['userEngagementDuration'] ); ?></font></td>
					<td align="center" style="font: normal 14px 'Roboto', Arial, Helvetica, sans-serif; padding: 11px 20px;border-top: 1px solid #e2e5e8; border-right:1px solid #e2e5e8;"><font color="#444444"><?php echo esc_html( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' ) ? WPANALYTIFY_Utils::pretty_numbers( $whats_happen['engagedSessions'] ) : $whats_happen['engagedSessions'] ); ?></font><small></td>
					<td align="center" style="font: normal 14px 'Roboto', Arial, Helvetica, sans-serif; padding: 11px 20px;border-top: 1px solid #e2e5e8; border-right:1px solid #e2e5e8;"><font color="#444444"><?php echo esc_html( round( $whats_happen['engagementRate'], 2 ) ); ?></font><small></td>
					</tr>
						<?php ++$i; ?>
					<?php endforeach; ?>
				<?php else : ?>
					<?php analytify_email_render_no_data_row( 4 ); ?>
				<?php endif; ?>
				<tr>
			<td colspan="4" style="border-top: 1px solid #e2e5e8;">
			<table cellpadding="0" cellspacing="16" border="0" width="100%" bgcolor="#ffffff">
				<tbody><tr>
				<td width="32" style="text-align: right;"><img src="<?php echo esc_url( ANALYTIFY_IMAGES_PATH . 'anlytify_about_icon.png' ); ?>" alt="about icon"/></td>
				<td style="font: normal 13px 'Roboto', Arial, Helvetica, sans-serif;"><font color="#444444"><?php echo esc_html( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' ) ? WPANALYTIFY_Utils::pretty_numbers( $top_entrance ) : $top_entrance ); ?> <?php esc_html_e( ' Number of visitors that landed on (or visited) your site pages.', 'wp-analytify-pro' ); ?> <?php echo esc_html( $top_url ); ?></font></td>
				</tr>
			</tbody></table>
			</td>
		</tr>
		</table>
				</td>
			</tr>
		</table>
	</td>
	</tr>
	<?php
	$message = ob_get_clean();
	return $message ? $message : '';
}

