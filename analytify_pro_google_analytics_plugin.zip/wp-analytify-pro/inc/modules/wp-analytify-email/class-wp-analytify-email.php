<?php
/**
 * Email Addon Main Class.
 *
 * @package WP_Analytify_Pro
 */

// phpcs:ignoreFile WordPress.Files.FileName.InvalidClassFileName

/**
 * WP Analytify Email Addon Class.
 *
 * Main class for Email notifications addon.
 */
class WP_Analytify_Addon_Email extends WP_Analytify_Pro_Base {

	/**
	 * Email report builder instance.
	 *
	 * @var object|null
	 */
	private $email_report_builder = null;

	/**
	 * Single post email handler instance.
	 *
	 * @var object|null
	 */
	private $single_post_handler = null;

	/**
	 * Constructor.
	 */
	public function __construct() {
		parent::__construct();
		$this->setup_constants();
		$this->init_components();
		$this->hooks();
	}

	/**
	 * Initialize component classes
	 *
	 * @return void
	 */
	private function init_components() {
		require_once __DIR__ . '/views/email-view-helpers.php';
		require_once __DIR__ . '/classes/class-email-report-builder.php';
		require_once __DIR__ . '/classes/class-single-post-email-handler.php';

		$this->email_report_builder = new WP_Analytify_Email_Report_Builder();
		$this->single_post_handler  = new WP_Analytify_Single_Post_Email_Handler();
	}

	/**
	 * Register all the hooks.
	 *
	 * @return void
	 */
	private function hooks() {
		add_action( 'admin_init', array( $this, 'save_version' ), 50 );
		add_action( 'admin_init', array( $this, 'update_routine' ), 10 );
		add_action( 'admin_init', array( $this, 'backward_compatibility' ), 10 );
		add_action( 'admin_enqueue_scripts', array( $this, 'wp_analytify_register_date_picker_scripts' ), 5 ); // Register early.
		add_action( 'admin_enqueue_scripts', array( $this, 'wp_analytify_enqueue_date_picker_scripts' ), 20 ); // Enqueue later.

		add_filter( 'wp_analytify_pro_setting_fields', array( $this, 'analytify_email_setting_fields' ), 21, 1 );
		/**
		 * This hooks is called in the Core version.
		 */
		add_filter( 'wp_analytify_email_on_cron_time', array( $this, 'callback_wp_analytify_email_on_cron_time' ), 10, 3 );
		add_filter( 'wp_analytify_single_email', array( $this, 'callback_wp_analytify_single_email' ), 10, 3 );
	}

	/**
	 * Setup plugin constants
	 *
	 * @access      private
	 * @since       1.0.0
	 * @return      void
	 */
	private function setup_constants() {
		// Setting Global Values.
		$this->define( 'EMAIL_ANALYTIFY_PLUGIN_FILE', __FILE__ );
		$this->define( 'EMAIL_ANALYTIFY_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );
		$this->define( 'EMAIL_ANALYTIFY_PLUGIN_DIR', __DIR__ );
		$this->define( 'EMAIL_ANALYTIFY_PRODUCT_NAME', 'Google Analytics Email Notifications' );
		$this->define( 'EMAIL_ANALYTIFY_PRODUCT_ID', '6580' );
		$this->define( 'EMAIL_ANALYTIFY_STORE_URL', 'https://analytify.io' );
	}

	/**
	 * Define constant if not already set.
	 *
	 * @param  string      $name Constant name.
	 * @param  string|bool $value Constant value.
	 * @return void
	 */
	private function define( $name, $value ) {
		if ( ! defined( $name ) ) {
			define( $name, $value );
		}
	}

	/**
	 * Display email success notice.
	 *
	 * @return void
	 */
	public function analytify_email_notics() {
		?>
		<div class="notice notice-success is-dismissible">
			<p><?php esc_html_e( 'Analytify detailed report sent!', 'wp-analytify-pro' ); ?></p>
		</div>
		<?php
	}

	/**
	 * Custom PHPMailer initialization.
	 *
	 * @param \PHPMailer\PHPMailer\PHPMailer $phpmailer PHPMailer instance.
	 * @return void
	 */
	// phpcs:disable WordPress.NamingConventions.ValidVariableName.VariableNotSnakeCase, WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
	public function custom_phpmailer_init( $phpmailer ) {
		$phpmailer->isSMTP();
		$phpmailer->SMTPAuth   = true;
		$phpmailer->SMTPSecure = 'ssl';
		$phpmailer->Host       = 'smtp.gmail.com';
		$phpmailer->Port       = 465;
		$phpmailer->Username   = 'test@gmail.com';
		$phpmailer->Password   = '';
	}
	// phpcs:enable WordPress.NamingConventions.ValidVariableName.VariableNotSnakeCase, WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase

	/**
	 * Add email setting fields.
	 *
	 * @param array<string, mixed> $old_fields Existing fields.
	 * @return array<string, mixed>
	 */
	public function analytify_email_setting_fields( $old_fields ) {

		$stats_option = array(
			'show-overall-general' => __( 'General Stats', 'wp-analytify' ),
			'show-top-pages'       => __( 'Top Pages Stats', 'wp-analytify-pro' ),
			'show-geographics'     => __( 'Geographic Stats', 'wp-analytify' ),
			'show-system'          => __( 'System Stats', 'wp-analytify' ),
			'show-keywords'        => __( 'Keywords and Referrers Stats', 'wp-analytify' ),
			'show-social'          => __( 'Social Media Stats', 'wp-analytify' ),
			'show-whats-happen'    => __( 'Whats Happening Stats', 'wp-analytify-pro' ),
		);

		// check if Analytify Pro and AnalytifyForms is installed.
		if ( class_exists( 'Analytify_Addon_Forms' ) && class_exists( 'WP_Analytify_Pro_Base' ) ) {
			$stats_option['show-forms-tracking'] = __( 'Forms Tracking Stats', 'wp-analytify-pro' );
		}
		// check if WooCommerce or EDD installed.
		if ( class_exists( 'WP_Analytify_WooCommerce_Addon' ) || class_exists( 'WP_Analytify_Edd_Addon' ) ) {
			$stats_option['show-e-commerce-stats'] = __( 'E-Commerce Report', 'wp-analytify-pro' );
		}

		// check if video tracking is enabled.
		$video_tracking = get_option( 'wp-analytify-advanced', array() );
		$video_tracking = isset( $video_tracking['video_tracking'] ) ? $video_tracking['video_tracking'] : 'off';
		if ( 'on' === $video_tracking && class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {
			$stats_option['show-video-tracking'] = __( 'Video Tracking Stats', 'wp-analytify-pro' );
		}

		$free_email_fields = isset( $old_fields['wp-analytify-email'] ) ? $old_fields['wp-analytify-email'] : array();

		// New addon fields.
		$addon_fields = array(
			array(
				'name'    => 'analytif_email_cron_time',
				'label'   => __( 'Set Schedule', 'wp-analytify-pro' ),
				'desc'    => __( 'Schedule weekly, monthly, yesterday, or custom range. With Custom Range set to Date range selected, the report uses the saved From/To dates; otherwise saved dates map to the current month by day.', 'wp-analytify-pro' ),
				'type'    => 'multi_select',
				'default' => 'weekly',
				'options' => array(
					'main'  => array(
						'week'         => __( 'Weekly', 'wp-analytify-pro' ),
						'month'        => __( 'Monthly', 'wp-analytify-pro' ),
						'yesterday'    => __( 'Yesterday', 'wp-analytify-pro' ),
						'custom_range' => __( 'Custom Range', 'wp-analytify-pro' ),
					),
					'value' => array(
						'week'  => array(
						'false'     => __( 'Select Day', 'wp-analytify-pro' ),
						'Sunday'    => __( 'Sunday', 'wp-analytify-pro' ),
						'Monday'    => __( 'Monday', 'wp-analytify-pro' ),
						'Tuesday'   => __( 'Tuesday', 'wp-analytify-pro' ),
						'Wednesday' => __( 'Wednesday', 'wp-analytify-pro' ),
						'Thursday'  => __( 'Thursday', 'wp-analytify-pro' ),
						'Friday'    => __( 'Friday', 'wp-analytify-pro' ),
						'Saturday'  => __( 'Saturday', 'wp-analytify-pro' ),
						),
						'month' => array(
						'false'    => __( 'Select Date', 'wp-analytify-pro' ),
						'1'        => __( '1', 'wp-analytify-pro' ),
						'2'        => __( '2', 'wp-analytify-pro' ),
						'3'        => __( '3', 'wp-analytify-pro' ),
						'4'        => __( '4', 'wp-analytify-pro' ),
						'5'        => __( '5', 'wp-analytify-pro' ),
						'6'        => __( '6', 'wp-analytify-pro' ),
						'7'        => __( '7', 'wp-analytify-pro' ),
						'8'        => __( '8', 'wp-analytify-pro' ),
						'9'        => __( '9', 'wp-analytify-pro' ),
						'10'       => __( '10', 'wp-analytify-pro' ),
						'11'       => __( '11', 'wp-analytify-pro' ),
						'12'       => __( '12', 'wp-analytify-pro' ),
						'13'       => __( '13', 'wp-analytify-pro' ),
						'14'       => __( '14', 'wp-analytify-pro' ),
						'15'       => __( '15', 'wp-analytify-pro' ),
						'16'       => __( '16', 'wp-analytify-pro' ),
						'17'       => __( '17', 'wp-analytify-pro' ),
						'18'       => __( '18', 'wp-analytify-pro' ),
						'19'       => __( '19', 'wp-analytify-pro' ),
						'20'       => __( '20', 'wp-analytify-pro' ),
						'21'       => __( '21', 'wp-analytify-pro' ),
						'22'       => __( '22', 'wp-analytify-pro' ),
						'23'       => __( '23', 'wp-analytify-pro' ),
						'24'       => __( '24', 'wp-analytify-pro' ),
						'25'       => __( '25', 'wp-analytify-pro' ),
						'26'       => __( '26', 'wp-analytify-pro' ),
						'27'       => __( '27', 'wp-analytify-pro' ),
						'28'       => __( '28', 'wp-analytify-pro' ),
						'last_day' => __( 'Last Day', 'wp-analytify-pro' ),
						),
						'yesterday' => array(
						'false'   => __( 'Disabled', 'wp-analytify-pro' ),
						'enabled' => __( 'Enabled', 'wp-analytify-pro' ),
						),
						'custom_range' => array(
						'false'   => __( 'Select Date Range', 'wp-analytify-pro' ),
						'enabled' => __( 'Date range selected', 'wp-analytify-pro' ),
						),
					),
				),
			),
			array(
				'name'              => 'analytify_email_custom_range_start',
				'label'             => '',
				'desc'              => '',
				'type'              => 'text',
				'default'           => '',
				'sanitize_callback' => 'sanitize_text_field',
			),
			array(
				'name'              => 'analytify_email_custom_range_end',
				'label'             => '',
				'desc'              => '',
				'type'              => 'text',
				'default'           => '',
				'sanitize_callback' => 'sanitize_text_field',
			),
			array(
				'name'              => 'analytify_email_subject',
				'label'             => __( 'Subject', 'wp-analytify-pro' ),
				'desc'              => __( 'Add Email Subject', 'wp-analytify-pro' ),
				'type'              => 'text',
				'default'           => '',
				'sanitize_callback' => 'sanitize_text_field',
			),
			array(
				'name'    => 'analytify_email_stats',
				'label'   => __( 'Select Email Stats', 'wp-analytify-pro' ),
				'desc'    => __( 'Select which Stats panels you want to display in Email. ', 'wp-analytify-pro' ),
				'type'    => 'chosen',
				'default' => array(),
				'options' => $stats_option,
			),
			array(
				'name'              => 'analytify_email_logo',
				'label'             => __( 'Your Agency Logo', 'wp-analytify-pro' ),
				'desc'              => __( 'Add your Agency logo in Email Template.<br />Preferred size 150*150 pixel', 'wp-analytify-pro' ),
				'type'              => 'image',
				'default'           => '',
				'sanitize_callback' => '',
			),
			array(
				'name'              => 'analytify_note_text',
				'label'             => __( 'Report Note', 'wp-analytify-pro' ),
				'desc'              => __( 'The welcome message or top notice will be added in the Email Report. Leave it empty to disable it.', 'wp-analytify-pro' ),
				'type'              => 'wysiwyg',
				'default'           => '',
				'options'           => array(
					'tinymce'       => false,
					'media_buttons' => false,
				),
				'sanitize_callback' => 'sanitize_text_field',
			),
			array(
				'name'              => 'analytiy_mail_text',
				'label'             => __( 'Personal Note', 'wp-analytify-pro' ),
				'desc'              => __( 'The personal message will be added in Email Report. Leave it empty to disable it.', 'wp-analytify-pro' ),
				'type'              => 'wysiwyg',
				'default'           => '',
				'options'           => array(
					'tinymce'       => false,
					'media_buttons' => false,
				),
				'sanitize_callback' => 'wp_kses_post',
			),
			array(
				'name'              => 'analytiy_mail_text_additional',
				'label'             => __( 'Additional Note', 'wp-analytify-pro' ),
				'desc'              => __( 'An additional note area at the bottom of the email. Leave it empty to disable it.', 'wp-analytify-pro' ),
				'type'              => 'wysiwyg',
				'options'           => array(
					'tinymce'       => false,
					'media_buttons' => false,
				),
				'default'           => __( 'We hope your weekly Analytics summaries encourage the efforts you are putting in your business. But if you no longer wish to receive Analytify Insights emails, you may change your preferences from plugin settings.', 'wp-analytify-pro' ),
				'sanitize_callback' => 'wp_kses_post',
			),
			array(
				'name'  => 'analytify_go_to_dashboard',
				'label' => __( 'Hide \'Go To Dashboard\' Button', 'wp-analytify-pro' ),
				'desc'  => __( 'Check this if you want to hide the Go To Dashboard button', 'wp-analytify-pro' ),
				'type'  => 'checkbox',
			),
		);

		// Add new addon fields.
		$pro_fields = array_merge( $free_email_fields, $addon_fields );

		// Add sender name option at second position.
		array_splice(
			$pro_fields,
			1,
			0,
			array(
				array(
					'name'              => 'analytiy_from_name',
					'label'             => __( 'From Name', 'wp-analytify-pro' ),
					'desc'              => __( 'Sender Name.', 'wp-analytify-pro' ),
					'type'              => 'text',
					'default'           => '',
					'sanitize_callback' => 'sanitize_text_field',
				),
			)
		);

		$old_fields['wp-analytify-email'] = $pro_fields;

		return $old_fields;
	}

	/**
	 * Save addon version.
	 *
	 * @return void
	 */
	public function save_version() {
		$email_addon_version = defined( 'ANALTYIFY_EMAIL_ADDON_VERSION' ) ? ANALTYIFY_EMAIL_ADDON_VERSION : analytify_pro_get_asset_version();
		if ( $email_addon_version !== get_option( 'ANALTYIFY_EMAIL_ADDON_VERSION' ) ) {
			update_option( 'ANALTYIFY_EMAIL_ADDON_VERSION', $email_addon_version );
		}
	}

	/**
	 * Run update routine for backward compatibility.
	 *
	 * @return void
	 */
	public function update_routine() {
		$old_version  = get_option( 'ANALTYIFY_EMAIL_ADDON_VERSION' );
		$email_option = maybe_unserialize( get_option( 'wp-analytify-email' ) );
		$email_option = $email_option ? $email_option : array();

		// Ensure 'analytif_email_cron_time' key exists.
		$cron_time = $email_option['analytif_email_cron_time'] ?? '';

		if ( ! $old_version && ! is_array( $cron_time ) ) {
			if ( 'weekly' === $cron_time || 'biweekly' === $cron_time ) {
				$email_option['analytif_email_cron_time'] = array(
					'week'  => 'Monday',
					'month' => 'false',
				);
			} elseif ( '4weeks' === $cron_time ) {
				$email_option['analytif_email_cron_time'] = array(
					'week'  => 'false',
					'month' => '1',
				);
			}

			// Update the option and clear old cron.
			update_option( 'wp-analytify-email', $email_option );
			wp_clear_scheduled_hook( 'analytify_email_cron_function' );
		}
	}

	/**
	 * Add pro reports in email message body.
	 *
	 * @param string               $message Email message body.
	 * @param array<string, mixed> $selected_sections Selected report sections.
	 * @param array<string, mixed> $dates Date range for report.
	 * @return string
	 */
	public function callback_wp_analytify_email_on_cron_time( $message, $selected_sections, $dates ) {
		if ( $this->email_report_builder && method_exists( $this->email_report_builder, 'build_email_report' ) ) {
			return $this->email_report_builder->build_email_report( $message, $selected_sections, $dates );
		}
		return $message;
	}

	/**
	 * Add pro reports in single post email message body.
	 *
	 * @param string               $message Email message body.
	 * @param array<string, mixed> $selected_sections Selected report sections.
	 * @param array<string, mixed> $dates Date range for report.
	 * @return string
	 */
	public function callback_wp_analytify_single_email( $message, $selected_sections, $dates ) {
		if ( $this->single_post_handler && method_exists( $this->single_post_handler, 'build_single_post_email' ) ) {
			return $this->single_post_handler->build_single_post_email( $message, $selected_sections, $dates );
		}
		return $message;
	}

	/**
	 * Add Email settings in diagnostic logs.
	 *
	 * @return void
	 */
	public function analytify_settings_logs() {
		echo esc_html( "Analytify Email Setting:\r\n" );

		$analytify_email = get_option( 'wp-analytify-email' );
		// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_print_r -- Debug output for settings logs.
		print_r( $analytify_email );

		echo esc_html( "\r\n" );
	}

	/**
	 * Configure backward compatibility for options tabele.
	 *
	 * @return void
	 */
	public function backward_compatibility() {
		$_analytify_email = get_option( 'wp-analytify-email' );

		if ( empty( $_analytify_email ) ) {
			$default['analytify_email_user_email'] = get_bloginfo( 'admin_email' );
			$default['analytif_email_cron_time']   = array(
				'week'         => 'Monday',
				'month'        => 'false',
				'yesterday'    => 'false',
				'custom_range' => 'false',
			);

			update_option( 'wp-analytify-email', $default );
		} else {
			// Ensure new options exist in existing settings.
			if ( ! isset( $_analytify_email['analytif_email_cron_time']['yesterday'] ) ) {
				$_analytify_email['analytif_email_cron_time']['yesterday'] = 'false';
			}
			if ( ! isset( $_analytify_email['analytif_email_cron_time']['custom_range'] ) ) {
				$_analytify_email['analytif_email_cron_time']['custom_range'] = 'false';
			}
			update_option( 'wp-analytify-email', $_analytify_email );
		}
	}

	/**
	 * Register date picker scripts early (before dependencies are checked).
	 *
	 * @since 9.0.0
	 * @param string $hook Current admin page hook.
	 * @return void
	 */
	public function wp_analytify_register_date_picker_scripts( $hook ) {
		// Only register on Analytify settings page.
		if ( 'analytify_page_analytify-settings' !== $hook ) {
			return;
		}

		// Get free version plugin file path.
		$free_plugin_file = '';
		if ( defined( 'WP_ANALYTIFY_PLUGIN_FILE' ) ) {
			$free_plugin_file = WP_ANALYTIFY_PLUGIN_FILE;
		} elseif ( defined( 'ANALYTIFY_PLUGIN_FILE' ) ) {
			$free_plugin_file = ANALYTIFY_PLUGIN_FILE;
		} else {
			// Fallback: try to find wp-analytify plugin directory.
			$free_plugin_path = WP_PLUGIN_DIR . '/wp-analytify/analytify-general.php';
			if ( file_exists( $free_plugin_path ) ) {
				$free_plugin_file = $free_plugin_path;
			}
		}
		
		if ( ! $free_plugin_file ) {
			return; // Can't find free version.
		}
		
		$free_asset_version = defined( 'ANALYTIFY_VERSION' ) ? ANALYTIFY_VERSION : '1.0.0';

		// Register moment from free version (if not already registered).
		if ( ! wp_script_is( 'moment', 'registered' ) ) {
			wp_register_script( 'moment', plugins_url( 'assets/js/moment.min.js', $free_plugin_file ), array(), $free_asset_version, true );
		}

		// Register Pikaday from free version (if not already registered).
		// Note: Pikaday styles are included in styles.css, not a separate file.
		if ( ! wp_script_is( 'pikaday-js', 'registered' ) ) {
			wp_register_script( 'pikaday-js', plugins_url( 'assets/js/pikaday.js', $free_plugin_file ), array( 'moment' ), $free_asset_version, true );
		}
	}

	/**
	 * Return inline script for email custom range date picker.
	 *
	 * Uses Pikaday with bound: true. Initializes only when the Email settings tab
	 * (#wp-analytify-email) is visible so calendars are not positioned on hidden fields.
	 *
	 * @since 9.0.0
	 * @return string JavaScript source (translated strings JSON-encoded for safe output).
	 */
	private function wp_analytify_get_email_date_range_picker_script() {
		$i18n = wp_json_encode(
			array(
				'from'         => esc_html( __( 'From:', 'wp-analytify-pro' ) ),
				'to'           => esc_html( __( 'To:', 'wp-analytify-pro' ) ),
				'select_date'  => esc_attr( __( 'Select date', 'wp-analytify-pro' ) ),
				'clear'        => esc_html( __( 'Clear', 'wp-analytify-pro' ) ),
				'custom_range' => wp_strip_all_tags( __( 'Custom Range', 'wp-analytify-pro' ) ),
			)
		);

		return '(function($) {
			var wpaEmailRangeI18n = ' . $i18n . ';
			function wpaEmailRangeReset(box) {
				if (!box || !box.length) return;
				var z = box.data(\'wpaDrPk\');
				if (z) { z.forEach(function(p) { p.destroy(); }); box.removeData(\'wpaDrPk\'); }
				box.find(\'.analytify-email-date-range-wrapper\').remove();
			}
			function wpaEmailRangeInit() {
				if (typeof Pikaday === "undefined" || typeof moment === "undefined") { setTimeout(wpaEmailRangeInit, 100); return; }
				var $tab = $(\'#wp-analytify-email\');
				if (!$tab.length) return;
				var sel = $tab.find(\'select[name*="[analytif_email_cron_time][custom_range]"]\');
				if (!sel.length) sel = $tab.find(\'.analytify-multiselect-container\').filter(function() {
					return $(this).find(\'.analytify-multiselect-label\').text().indexOf(wpaEmailRangeI18n.custom_range) !== -1;
				}).find(\'select\');
				var box = sel.closest(\'.analytify-multiselect-container\');
				if (!sel.length || !box.length) return;
				if (!$tab.is(\':visible\')) { wpaEmailRangeReset(box); return; }
				wpaEmailRangeReset(box);
				var startH = $tab.find(\'input[name="wp-analytify-email[analytify_email_custom_range_start]"]\'), endH = $tab.find(\'input[name="wp-analytify-email[analytify_email_custom_range_end]"]\');
				startH.closest(\'tr\').add(endH.closest(\'tr\')).hide();
				sel.hide();
				sel.after(\'<div class="analytify-email-date-range-wrapper" style="display:inline-block;margin-left:10px;"><div style="display:flex;align-items:center;gap:10px;">\' +
					\'<div style="display:flex;align-items:center;gap:5px;"><label style="margin:0;font-weight:normal;">\' + wpaEmailRangeI18n.from + \'</label>\' +
					\'<input type="text" class="analytify-date-range-from" readonly style="width:120px;cursor:pointer;padding:4px 8px;border:1px solid #ddd;border-radius:3px;" placeholder="\' + wpaEmailRangeI18n.select_date + \'" /></div>\' +
					\'<div style="display:flex;align-items:center;gap:5px;"><label style="margin:0;font-weight:normal;">\' + wpaEmailRangeI18n.to + \'</label>\' +
					\'<input type="text" class="analytify-date-range-to" readonly style="width:120px;cursor:pointer;padding:4px 8px;border:1px solid #ddd;border-radius:3px;" placeholder="\' + wpaEmailRangeI18n.select_date + \'" /></div>\' +
					\'<button type="button" class="analytify-clear-date-range button" style="margin-left:5px;padding:0px 20px;font-size:12px;">\' + wpaEmailRangeI18n.clear + \'</button></div></div>\');
				var fromEl = box.find(\'.analytify-date-range-from\')[0], toEl = box.find(\'.analytify-date-range-to\')[0];
				function syncSel() { sel.val(startH.val() && endH.val() ? \'enabled\' : \'false\'); }
				function syncHiddenFromVisible() {
					var fromVal = $.trim($(fromEl).val());
					var toVal = $.trim($(toEl).val());
					if (!fromVal) {
						startH.val(\'\');
					} else {
						var ms = sp.getMoment();
						if (ms && ms.isValid()) {
							startH.val(ms.format(\'YYYY-MM-DD\'));
						}
					}
					if (!toVal) {
						endH.val(\'\');
					} else {
						var me = ep.getMoment();
						if (me && me.isValid()) {
							endH.val(me.format(\'YYYY-MM-DD\'));
						}
					}
					syncSel();
				}
				var sp = new Pikaday({ field: fromEl, format: \'MMM DD, YYYY\', maxDate: new Date(), bound: true, position: \'bottom left\',
					onSelect: function() {
						var m = this.getMoment(); if (!m) return;
						startH.val(m.format(\'YYYY-MM-DD\')); $(fromEl).val(m.format(\'MMM DD, YYYY\')); if (ep) ep.setMinDate(this.getDate()); syncSel();
						if (ep && !$(toEl).val()) setTimeout(function() { ep.show(); }, 80);
					}
				});
				var ep = new Pikaday({ field: toEl, format: \'MMM DD, YYYY\', maxDate: new Date(), bound: true, position: \'bottom right\',
					onSelect: function() {
						var m = this.getMoment(); if (!m) return;
						endH.val(m.format(\'YYYY-MM-DD\')); $(toEl).val(m.format(\'MMM DD, YYYY\')); if (sp) sp.setMaxDate(this.getDate()); syncSel();
					}
				});
				box.data(\'wpaDrPk\', [sp, ep]);
				$(fromEl).on(\'click focus\', function() { ep.hide(); });
				$(toEl).on(\'click focus\', function() { sp.hide(); });
				if (startH.val()) { var s = moment(startH.val(), \'YYYY-MM-DD\'); if (s.isValid()) { $(fromEl).val(s.format(\'MMM DD, YYYY\')); sp.setDate(s.toDate(), true); ep.setMinDate(s.toDate()); } }
				if (endH.val()) { var e = moment(endH.val(), \'YYYY-MM-DD\'); if (e.isValid()) { $(toEl).val(e.format(\'MMM DD, YYYY\')); ep.setDate(e.toDate(), true); sp.setMaxDate(e.toDate()); } }
				sp.hide(); ep.hide(); syncSel();
				box.find(\'.analytify-clear-date-range\').on(\'click\', function() {
					sp.setDate(null); ep.setDate(null); sp.setMaxDate(new Date()); ep.setMinDate(null);
					$(fromEl).val(\'\'); $(toEl).val(\'\'); startH.val(\'\'); endH.val(\'\'); sel.val(\'false\');
				});
				var $form = box.closest(\'form\');
				if ($form.length) $form.off(\'submit.wpaDr\').on(\'submit.wpaDr\', function() {
					sp.hide(); ep.hide();
					// Sync hidden fields only when the visible inputs have a value — after Clear,
					// Pikaday can still expose a moment (often today); without this, a later Save
					// would repopulate From/To with that stale selection.
					if ($(fromEl).val()) {
						var ms = sp.getMoment();
						if (ms && ms.isValid()) startH.val(ms.format(\'YYYY-MM-DD\'));
					} else {
						startH.val(\'\');
					}
					if ($(toEl).val()) {
						var me = ep.getMoment();
						if (me && me.isValid()) endH.val(me.format(\'YYYY-MM-DD\'));
					} else {
						endH.val(\'\');
					}
					syncSel();
				});
			}
			$(wpaEmailRangeInit);
			$(document).on(\'click\', \'.nav-tab, .analytify_nav_tab_wrapper a, .wpa-tab-wrapper a\', function() { setTimeout(wpaEmailRangeInit, 400); });
		})(jQuery);';
	}

	/**
	 * Enqueue date picker scripts for custom range fields.
	 *
	 * @since 9.0.0
	 * @param string $hook Current admin page hook.
	 * @return void
	 */
	public function wp_analytify_enqueue_date_picker_scripts( $hook ) {
		// Only load on Analytify settings page.
		if ( 'analytify_page_analytify-settings' !== $hook ) {
			return;
		}

		$version = analytify_pro_get_asset_version();

		// Enqueue moment and Pikaday (they should be registered by now).
		if ( wp_script_is( 'moment', 'registered' ) && ! wp_script_is( 'moment', 'enqueued' ) ) {
			wp_enqueue_script( 'moment' );
		}
		
		if ( wp_script_is( 'pikaday-js', 'registered' ) && ! wp_script_is( 'pikaday-js', 'enqueued' ) ) {
			wp_enqueue_script( 'pikaday-js' );
			// Pikaday styles are included in wp-analytify-default-style (styles.css), no need to enqueue separately.
		}

		// Inline script: custom range date picker (single visible calendar, close on outside click/save).
		$script = $this->wp_analytify_get_email_date_range_picker_script();

		// Create a custom script handle that depends on pikaday-js and jQuery.
		// Register with empty source, dependencies will ensure proper load order.
		// pikaday-js should already be registered above.
		wp_register_script( 'analytify-email-date-range', '', array( 'jquery', 'pikaday-js' ), $version, true );
		wp_enqueue_script( 'analytify-email-date-range' );
		wp_add_inline_script( 'analytify-email-date-range', $script );
	}
}

