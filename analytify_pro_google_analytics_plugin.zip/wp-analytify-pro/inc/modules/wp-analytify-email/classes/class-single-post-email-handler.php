<?php
/**
 * Single Post Email Handler Class.
 *
 * @package WP_Analytify_Pro
 * @since 8.0.0
 */

// phpcs:ignoreFile WordPress.Files.FileName.InvalidClassFileName

/**
 * Class WP_Analytify_Single_Post_Email_Handler
 *
 * Handles single post email reports.
 */
class WP_Analytify_Single_Post_Email_Handler {

	/**
	 * Constructor.
	 */
	public function __construct() {
		// Constructor for future use.
	}

	/**
	 * Build single post email report.
	 *
	 * @since  8.0.0
	 * @version 9.0.0 Video tracking section uses Analytify_Report_Pro and per-post cache.
	 * @param string               $message Email message body.
	 * @param array<string, mixed> $selected_sections Selected report sections.
	 * @param array<string, mixed> $dates Date range for report.
	 * @return string
	 */
	public function build_single_post_email( $message, $selected_sections, $dates ) {

		if ( empty( $selected_sections ) ) {
			return $message;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Called from core email functionality with nonce verification.
		$post_id  = sanitize_text_field( wp_unslash( $_POST['post_id'] ?? '' ) );
		$post_url = get_the_permalink( (int) $post_id );
		$post_url = $post_url ? $post_url : '';
		if ( '' === $post_url ) {
			return $message;
		}
		$u_post   = wp_parse_url( urldecode( $post_url ) );
		if ( ! is_array( $u_post ) || empty( $u_post['path'] ) ) {
			return $message;
		}
		$filter   = is_array( $u_post ) && isset( $u_post['path'] ) ? $u_post['path'] : '';
		$filter   = apply_filters( 'analytify_page_path_filter', $filter, $u_post );
		// Url have query string incase of WPML.
		if ( isset( $u_post['query'] ) ) {
			$filter .= '?' . $u_post['query'];
		}

		$wp_analytify = $GLOBALS['WP_ANALYTIFY'];
		$ga_mode      = class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) ? WPANALYTIFY_Utils::get_ga_mode() : 'ga3';

		// Geographic Stats.
		if ( in_array( 'show-geographics', $selected_sections, true ) ) {
			if ( 'ga4' === $ga_mode ) {
				$countries_stats = $wp_analytify->get_reports(
					'analytify-email-country-stats',
					array(
						'sessions',
					),
					array(
						'start' => $dates['start_date'],
						'end'   => $dates['end_date'],
					),
					array(
						'country',
						'pagePath',
					),
					array(
						'type'  => 'metric',
						'name'  => 'sessions',
						'order' => 'desc',
					),
					array(
						'logic'   => 'AND',
						'filters' => array(
							array(
								'type'           => 'dimension',
								'name'           => 'country',
								'match_type'     => 4,
								'value'          => '(not set)',
								'not_expression' => true,
							),
							array(
								'type'       => 'dimension',
								'name'       => 'pagePath',
								'match_type' => 1,
								'value'      => $filter,
							),
						),
					),
					5 // This is for stats limit in email
				);

				$cities_stats = $wp_analytify->get_reports(
					'analytify-email-city-stats',
					array(
						'sessions',
					),
					array(
						'start' => $dates['start_date'],
						'end'   => $dates['end_date'],
					),
					array(
						'city',
						'country',
						'pagePath',
					),
					array(
						'type'  => 'metric',
						'name'  => 'sessions',
						'order' => 'desc',
					),
					array(
						'logic'   => 'AND',
						'filters' => array(
							array(
								'type'           => 'dimension',
								'name'           => 'country',
								'match_type'     => 4,
								'value'          => '(not set)',
								'not_expression' => true,
							),
							array(
								'type'           => 'dimension',
								'name'           => 'city',
								'match_type'     => 4,
								'value'          => '(not set)',
								'not_expression' => true,
							),
							array(
								'type'       => 'dimension',
								'name'       => 'pagePath',
								'match_type' => 1,
								'value'      => $filter,
							),
						),
					),
					5 // This is for stats limit in email
				);
				if ( ! function_exists( 'pa_geopgraphic_lisiting' ) ) {
					include ANALYTIFY_EMAIL_VIEWS_PATH . 'geographic.php';
				}
			$geographic_result = pa_geopgraphic_lisiting( $wp_analytify, $countries_stats, $cities_stats );
			$message          .= $geographic_result ? $geographic_result : '';
			}
		}

		// System stats.
		if ( in_array( 'show-system', $selected_sections, true ) ) {
			if ( 'ga4' === $ga_mode ) {
				$browser_stats = $wp_analytify->get_reports(
					'show-default-browser-dashboard',
					array(
						'sessions',
					),
					array(
						'start' => $dates['start_date'],
						'end'   => $dates['end_date'],
					),
					array(
						'browser',
						'operatingSystem',
						'pagePath',
					),
					array(
						'type'  => 'metric',
						'name'  => 'sessions',
						'order' => 'desc',
					),
					array(
						'logic'   => 'AND',
						'filters' => array(
							array(
								'type'           => 'dimension',
								'name'           => 'operatingSystem',
								'match_type'     => 4,
								'value'          => '(not set)',
								'not_expression' => true,
							),
							array(
								'type'       => 'dimension',
								'name'       => 'pagePath',
								'match_type' => 1,
								'value'      => $filter,
							),
						),
					),
					5
				);

				$os_stats = $wp_analytify->get_reports(
					'show-default-os-dashboard',
					array(
						'sessions',
					),
					array(
						'start' => $dates['start_date'],
						'end'   => $dates['end_date'],
					),
					array(
						'operatingSystem',
						'operatingSystemVersion',
						'pagePath',
					),
					array(
						'type'  => 'metric',
						'name'  => 'sessions',
						'order' => 'desc',
					),
					array(
						'logic'   => 'AND',
						'filters' => array(
							array(
								'type'           => 'dimension',
								'name'           => 'operatingSystemVersion',
								'match_type'     => 4,
								'value'          => '(not set)',
								'not_expression' => true,
							),
							array(
								'type'       => 'dimension',
								'name'       => 'pagePath',
								'match_type' => 1,
								'value'      => $filter,
							),
						),
					),
					5
				);

				$mobile_stats = $wp_analytify->get_reports(
					'show-default-mobile-dashboard',
					array(
						'sessions',
					),
					array(
						'start' => $dates['start_date'],
						'end'   => $dates['end_date'],
					),
					array(
						'mobileDeviceBranding',
						'mobileDeviceModel',
						'pagePath',
					),
					array(
						'type'  => 'metric',
						'name'  => 'sessions',
						'order' => 'desc',
					),
					array(
						'logic'   => 'AND',
						'filters' => array(
							array(
								'type'           => 'dimension',
								'name'           => 'deviceCategory',
								'match_type'     => 4,
								'value'          => 'desktop',
								'not_expression' => true,
							),
							array(
								'type'           => 'dimension',
								'name'           => 'mobileDeviceModel',
								'match_type'     => 4,
								'value'          => '(not set)',
								'not_expression' => true,
							),
							array(
								'type'       => 'dimension',
								'name'       => 'pagePath',
								'match_type' => 1,
								'value'      => $filter,
							),
						),
					),
					5
				);

				if ( ! function_exists( 'pa_system_stats' ) ) {
					include ANALYTIFY_EMAIL_VIEWS_PATH . 'system-stats.php';
				}
				$message .= pa_system_stats( $wp_analytify, $browser_stats, $os_stats, $mobile_stats );
			}
		}

		/*
		 * Keywords and/or refferals
		 *
		 */
		// check if the 'keywords' are set
		if ( 'ga4' === $ga_mode ) {
			// TODO: add page URL check.
			$keyword_stats_raw = $wp_analytify->get_search_console_stats(
				'analytify-email-keyword-stats',
				array(
					'start' => $dates['start_date'],
					'end'   => $dates['end_date'],
				),
				5
			);

			$keywords = false;
			if ( isset( $keyword_stats_raw['response']['rows'] ) && $keyword_stats_raw['response']['rows'] > 0 ) {
				$keywords = $keyword_stats_raw['response']['rows'];
			}

			$refferals = $wp_analytify->get_reports(
				'analytify-email-refferal-stats',
				array(
					'sessions',
				),
				array(
					'start' => $dates['start_date'],
					'end'   => $dates['end_date'],
				),
				array(
					'sessionSource',
					'sessionMedium',
					'pagePath',
				),
				array(
					'type'  => 'metric',
					'name'  => 'sessions',
					'order' => 'desc',
				),
				array(
					'logic'   => 'AND',
					'filters' => array(
						array(
							'type'       => 'dimension',
							'name'       => 'pagePath',
							'match_type' => 1,
							'value'      => $filter,
						),
					),
				),
				5
			);

			if ( ! function_exists( 'pa_keyword_referral' ) ) {
				include ANALYTIFY_EMAIL_VIEWS_PATH . 'keyword-referral.php';
			}
			$message .= pa_keyword_referral( $wp_analytify, $keywords, $refferals );
		}

		if ( in_array( 'show-social', $selected_sections, true ) ) {
			if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {
				// GA4 Mode
				$social_stats_raw = $wp_analytify->get_reports(
					'analytify-email-social-media-stats',
					array(
						'sessions',
					),
					array(
						'start' => $dates['start_date'],
						'end'   => $dates['end_date'],
					),
					array(
						'sessionSource',
					),
					array(
						'type'  => 'metric',
						'name'  => 'sessions',
						'order' => 'desc',
					),
					array(
						'logic'   => 'AND',
						'filters' => array(
							array(
								'type'           => 'dimension',
								'name'           => 'sessionSource',
								'match_type'     => 5,
								// Keep strict end-anchor parity with dashboard/email builder social filters.
								'value'          => '^([a-z-]*\.|)(facebook|reddit|youtube|tumblr|quora|instagram|linkedin|yelp|wordpress|pinterest|twitter|t)(\.(com|org|co|)|)$',
								'not_expression' => false,
							),
						),
					),
					15 // You can adjust the limit as needed
				);

				if ( ! function_exists( 'social_stats' ) ) {
					include ANALYTIFY_EMAIL_VIEWS_PATH . 'social-media.php';
				}
				$message .= social_stats( $wp_analytify, $social_stats_raw );
			}
		}

		if ( in_array( 'show-video-tracking', $selected_sections, true ) && 'ga4' === $ga_mode ) {
			// Use report class so single-post video stats use per-post cache (post meta); avoids API on every email send.
			$post_id_int = (int) $post_id;
			if ( $post_id_int > 0 && class_exists( 'Analytify_Report_Pro' ) ) {
				try {
					$report = new Analytify_Report_Pro(
						array(
							'dashboard_type' => 'single_post',
							'start_date'     => $dates['start_date'],
							'end_date'       => $dates['end_date'],
							'post_id'        => $post_id_int,
						)
					);
					$video_result = $report->get_video_tracking_stats();
					$stats_raw    = isset( $video_result['stats'] ) && is_array( $video_result['stats'] ) ? $video_result['stats'] : array();
					$video_stats  = array();
					foreach ( $stats_raw as $row ) {
						$video_stats[] = array(
							'title'    => sanitize_text_field( (string) ( $row['event_label'] ?? '' ) ),
							'action'   => sanitize_text_field( (string) ( $row['video_action'] ?? '' ) ),
							'provider' => sanitize_text_field( (string) ( $row['video_provider'] ?? '' ) ),
							'duration' => absint( $row['video_duration'] ?? 0 ),
							'count'    => absint( $row['event_count'] ?? 0 ),
						);
					}
					$video_limit = (int) apply_filters( 'analytify_api_limit_video_tracking_email', 5, $ga_mode );
					if ( $video_limit > 0 && count( $video_stats ) > $video_limit ) {
						$video_stats = array_slice( $video_stats, 0, $video_limit );
					}
					if ( ! function_exists( 'pa_include_video_tracking_stats' ) ) {
						include ANALYTIFY_EMAIL_VIEWS_PATH . 'video-tracking-stats.php';
					}
					$message .= pa_include_video_tracking_stats( $wp_analytify, $video_stats );
				} catch ( Exception $e ) {
					// Omit video section on error.
				}
			}
		}
		return $message;
	}
}