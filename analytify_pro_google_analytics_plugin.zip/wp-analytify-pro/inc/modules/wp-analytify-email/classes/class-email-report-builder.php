<?php
/**
 * Email Report Builder Class.
 *
 * @package WP_Analytify_Pro
 */

// phpcs:ignoreFile WordPress.Files.FileName.InvalidClassFileName

/**
 * Class WP_Analytify_Email_Report_Builder
 *
 * Builds email reports with analytics data.
 */
class WP_Analytify_Email_Report_Builder {

	/**
	 * Info message for display.
	 *
	 * @var string
	 */
	private $info_message;

	/**
	 * GA mode (ga3 or ga4).
	 *
	 * @var string
	 */
	private $ga_mode;

	/**
	 * WP Analytify instance.
	 *
	 * @var mixed
	 */
	private $wp_analytify;

	/**
	 * Constructor.
	 */
	public function __construct() {
		// phpcs:ignore WordPress.NamingConventions.ValidVariableName.VariableNotSnakeCase
		global $WP_ANALYTIFY;
		// phpcs:ignore WordPress.NamingConventions.ValidVariableName.VariableNotSnakeCase
		$this->wp_analytify = $WP_ANALYTIFY;
		$this->ga_mode      = class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) ? WPANALYTIFY_Utils::get_ga_mode() : 'ga3';
	}

	/**
	 * Build an email report with all selected sections.
	 *
	 * @version 9.0.0
	 * @param string               $message Email message body.
	 * @param array<string, mixed> $selected_sections Selected report sections.
	 * @param array<string, mixed> $dates Date range for report.
	 * @return string
	 */
	public function build_email_report( $message, $selected_sections, $dates ) {

		if ( ! is_array( $selected_sections ) || empty( $selected_sections ) ) {
			return $message;
		}

		$wp_analytify = isset( $GLOBALS['WP_ANALYTIFY'] ) && is_object( $GLOBALS['WP_ANALYTIFY'] ) ? $GLOBALS['WP_ANALYTIFY'] : null;

		// E-commerce.
		if ( in_array( 'show-e-commerce-stats', $selected_sections, true ) ) {

			// WooCommerce.
			if ( class_exists( 'WP_Analytify_WooCommerce_Addon' ) ) {
				if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {

					$general_stats = $wp_analytify->get_reports(
						'analytify-email-woo-general-stats',
						array(
							'transactions',
							'totalRevenue',
							'averagePurchaseRevenue',
							'ecommercePurchases',
							'addToCarts',
							'checkouts',
							'itemListClicks',
							'itemViews',
						),
						array(
							'start' => $dates['start_date'],
							'end'   => $dates['end_date'],
						),
						array(),
						array(),
						array(),
						0
					);

					$remove_from_cart = $wp_analytify->get_reports(
						'analytify-email-woo-remove-from-cart',
						array(
							'eventCount',
						),
						array(
							'start' => $dates['start_date'],
							'end'   => $dates['end_date'],
						),
						array(
							'eventName',
						),
						array(),
						array(
							'logic'   => 'AND',
							'filters' => array(
								array(
									'type'       => 'dimension',
									'name'       => 'eventName',
									'match_type' => 1,
									'value'      => 'remove_from_cart',
								),
							),
						),
						0
					);

					if ( isset( $remove_from_cart['aggregations']['eventCount'] ) ) {
						$general_stats['remove_from_cart'] = $remove_from_cart['aggregations']['eventCount'];
					}
					if ( ! function_exists( 'pa_email_include_woo_general' ) ) {
						include ANALYTIFY_EMAIL_VIEWS_PATH . 'woo-general-stats.php';
					}
					$message .= pa_email_include_woo_general( $this->wp_analytify, $general_stats );
				}
			}

			// EDD.
			if ( class_exists( 'WP_Analytify_Edd_Addon' ) ) {
				if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {

					$stats = $wp_analytify->get_reports(
						'edd-shopping-analysis-stats',
						array(
							'transactions',
							'totalRevenue',
							'averagePurchaseRevenue',
							'addToCarts',
							'checkouts',
							'itemViews',
						),
						array(
							'start' => $dates['start_date'],
							'end'   => $dates['end_date'],
						),
						array(),
						array(),
						array(),
						0
					);

					if ( ! function_exists( 'pa_email_include_edd_general' ) ) {
						include ANALYTIFY_EMAIL_VIEWS_PATH . 'edd-general-stats.php';
					}
					$message .= pa_email_include_edd_general( $wp_analytify, $stats );
				}
			}
		}

		// Forms tracking Stats.
		if ( in_array( 'show-forms-tracking', $selected_sections, true ) ) {

			// API request limit.
			$api_request_limit = apply_filters( 'analytify_api_limit_forms_addon', 100, $this->ga_mode );

			// Data container.
			$stats = array();

			$this->info_message = esc_html__( '\'Impressions\' show how many times a particular form has been viewed.', 'wp-analytify-pro' );

			$report_filter = array();
			if ( class_exists( 'AnalytifyAddonFormHelper' ) ) {
				foreach ( AnalytifyAddonFormHelper::get_forms_for_dashboard() as $form ) {

					// API filter.
					$report_filter[] = array(
						'type'       => 'dimension',
						'name'       => 'customEvent:wpa_category',
						'match_type' => 1,
						'value'      => $form['category'],
					);

					// Stats base.
					$stats[ $form['category'] ] = array(
						'stats'        => array(),
						'info_message' => $this->info_message,
					);
				}
			} else {
				// error_log( 'Analytify Form Addon is deactivated. Skipping form data processing.' );
			}
			if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {

				$st = $wp_analytify->get_reports(
					'show-analytify-forms-dashboard',
					array(
						'eventCount',
					),
					array(
						'start' => $dates['start_date'],
						'end'   => $dates['end_date'],
					),
					array(
						'customEvent:wpa_category',
						'customEvent:wpa_link_action',
						'customEvent:wpa_link_label',
					),
					array(
						'type'  => 'metric',
						'name'  => 'eventCount',
						'order' => 'desc',
					),
					array(
						'logic'   => 'OR',
						'filters' => $report_filter,
					),
					$api_request_limit,
					false,
				);

				// Break the report into separate forms for submission and impression.
				if ( isset( $st['rows'] ) && ! empty( $st['rows'] ) ) {
					foreach ( $st['rows'] as $st ) {

						$_ct   = $st['customEvent:wpa_category'];
						$_lb   = $st['customEvent:wpa_link_label'];
						$_ac   = $st['customEvent:wpa_link_action'];
						$count = $st['eventCount'];

						$stats = apply_filters( 'analytify_forms_row_format', $stats, $_ct, $_lb, $_ac, $count );
					}
				}

				if ( ! function_exists( 'pa_include_forms_tracking_stats' ) ) {
					include ANALYTIFY_EMAIL_VIEWS_PATH . 'forms-tracking-stats.php';
				}
				$message .= pa_include_forms_tracking_stats( $wp_analytify, $stats );
			}
		}

		// Top Pages Stats.
		if ( in_array( 'show-top-pages', $selected_sections, true ) ) {
			if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {

				// API request limit (default 5; increase via analytify_api_limit_top_pages_email).
				$api_request_limit = (int) apply_filters( 'analytify_api_limit_top_pages_email', 5, $this->ga_mode );
				if ( $api_request_limit < 1 ) {
					$api_request_limit = 5;
				}

				$stats = $wp_analytify->get_reports(
					'analytify-email-top-pages-stats',
					array(
						'screenPageViews',
						'userEngagementDuration',
						'bounceRate',
					),
					array(
						'start' => $dates['start_date'],
						'end'   => $dates['end_date'],
					),
					array(
						'pageTitle',
						'pagePath',
					),
					array(
						'type'  => 'metric',
						'name'  => 'screenPageViews',
						'order' => 'desc',
					),
					array(
						'logic'   => 'AND',
						'filters' => array(
							array(
								'type'           => 'dimension',
								'name'           => 'pageTitle',
								'match_type'     => 4,
								'value'          => '(not set)',
								'not_expression' => true,
							),
							array(
								'type'           => 'dimension',
								'name'           => 'pagePath',
								'match_type'     => 4,
								'value'          => '(not set)',
								'not_expression' => true,
							),
						),
					),
					$api_request_limit,
				);

				if ( ! function_exists( 'pa_include_top_pages_stats' ) ) {
					include ANALYTIFY_EMAIL_VIEWS_PATH . 'top-pages-stats.php';
				}
				$message .= pa_include_top_pages_stats( $wp_analytify, $stats );
			}
		}

		// Geographic Stats.
		if ( in_array( 'show-geographics', $selected_sections, true ) ) {
			if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {
				$countries_stats = $wp_analytify->get_reports(
					'analytify-email-country-stats',
					array(
						'sessions',
					),
					array(
						'start' => $dates['start_date'],
						'end'   => $dates['end_date'],
					),
					array(
						'country',
					),
					array(
						'type'  => 'metric',
						'name'  => 'sessions',
						'order' => 'desc',
					),
					array(
						'logic'   => 'AND',
						'filters' => array(
							array(
								'type'           => 'dimension',
								'name'           => 'country',
								'match_type'     => 4,
								'value'          => '(not set)',
								'not_expression' => true,
							),
						),
					),
					10
				);

				$cities_stats = $wp_analytify->get_reports(
					'analytify-email-city-stats',
					array(
						'sessions',
					),
					array(
						'start' => $dates['start_date'],
						'end'   => $dates['end_date'],
					),
					array(
						'city',
						'country',
					),
					array(
						'type'  => 'metric',
						'name'  => 'sessions',
						'order' => 'desc',
					),
					array(
						'logic'   => 'AND',
						'filters' => array(
							array(
								'type'           => 'dimension',
								'name'           => 'country',
								'match_type'     => 4,
								'value'          => '(not set)',
								'not_expression' => true,
							),
							array(
								'type'           => 'dimension',
								'name'           => 'city',
								'match_type'     => 4,
								'value'          => '(not set)',
								'not_expression' => true,
							),
						),
					),
					10
				);

				if ( ! function_exists( 'pa_geopgraphic_lisiting' ) ) {
					include ANALYTIFY_EMAIL_VIEWS_PATH . 'geographic.php';
				}

			$geographic_result = pa_geopgraphic_lisiting( $wp_analytify, $countries_stats, $cities_stats );
			$message          .= $geographic_result ? $geographic_result : '';
			}
		}

		// System stats.
		if ( in_array( 'show-system', $selected_sections, true ) ) {

			if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {
				$browser_stats = $wp_analytify->get_reports(
					'show-default-browser-dashboard',
					array(
						'sessions',
					),
					array(
						'start' => $dates['start_date'],
						'end'   => $dates['end_date'],
					),
					array(
						'browser',
						'operatingSystem',
					),
					array(
						'type'  => 'metric',
						'name'  => 'sessions',
						'order' => 'desc',
					),
					array(
						'logic'   => 'AND',
						'filters' => array(
							array(
								'type'           => 'dimension',
								'name'           => 'operatingSystem',
								'match_type'     => 4,
								'value'          => '(not set)',
								'not_expression' => true,
							),
						),
					),
					5
				);

				$os_stats = $wp_analytify->get_reports(
					'show-default-os-dashboard',
					array(
						'sessions',
					),
					array(
						'start' => $dates['start_date'],
						'end'   => $dates['end_date'],
					),
					array(
						'operatingSystem',
						'operatingSystemVersion',
					),
					array(
						'type'  => 'metric',
						'name'  => 'sessions',
						'order' => 'desc',
					),
					array(
						'logic'   => 'AND',
						'filters' => array(
							array(
								'type'           => 'dimension',
								'name'           => 'operatingSystemVersion',
								'match_type'     => 4,
								'value'          => '(not set)',
								'not_expression' => true,
							),
						),
					),
					5
				);

				$mobile_stats = $wp_analytify->get_reports(
					'show-default-mobile-dashboard',
					array(
						'sessions',
					),
					array(
						'start' => $dates['start_date'],
						'end'   => $dates['end_date'],
					),
					array(
						'mobileDeviceBranding',
						'mobileDeviceModel',
					),
					array(
						'type'  => 'metric',
						'name'  => 'sessions',
						'order' => 'desc',
					),
					array(
						'logic'   => 'AND',
						'filters' => array(
							array(
								'type'           => 'dimension',
								'name'           => 'deviceCategory',
								'match_type'     => 4,
								'value'          => 'desktop',
								'not_expression' => true,
							),
							array(
								'type'           => 'dimension',
								'name'           => 'mobileDeviceModel',
								'match_type'     => 4,
								'value'          => '(not set)',
								'not_expression' => true,
							),
						),
					),
					5
				);

				if ( ! function_exists( 'pa_system_stats' ) ) {
					include ANALYTIFY_EMAIL_VIEWS_PATH . 'system-stats.php';
				}
				$message .= pa_system_stats( $wp_analytify, $browser_stats, $os_stats, $mobile_stats );
			}
		}

		// Keywords stats.
		if ( in_array( 'show-keywords', $selected_sections, true ) ) {

			if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {

				$keyword_stats_raw = $wp_analytify->get_search_console_stats(
					'analytify-email-keyword-stats',
					array(
						'start' => $dates['start_date'],
						'end'   => $dates['end_date'],
					),
					5
				);

				$keywords = false;
				if ( isset( $keyword_stats_raw['response']['rows'] ) && $keyword_stats_raw['response']['rows'] > 0 ) {
					$keywords = $keyword_stats_raw['response']['rows'];
				}

				$referer_stats_raw = $wp_analytify->get_reports(
					'analytify-email-refferal-stats',
					array(
						'sessions',
					),
					array(
						'start' => $dates['start_date'],
						'end'   => $dates['end_date'],
					),
					array(
						'sessionSource',
						'sessionMedium',
					),
					array(
						'type'  => 'metric',
						'name'  => 'sessions',
						'order' => 'desc',
					),
					array(),
					5
				);

				$refferals = false;

				if ( isset( $referer_stats_raw ) ) {
					$refferals = $referer_stats_raw;
				}

				if ( ! function_exists( 'pa_keyword_referral' ) ) {
					include ANALYTIFY_EMAIL_VIEWS_PATH . 'keyword-referral.php';
				}
				$message .= pa_keyword_referral( $wp_analytify, $keywords, $refferals );
			}
		}

		// Social Media.
		if ( in_array( 'show-social', $selected_sections, true ) ) {
			if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {

				$api_stats_limit = apply_filters( 'analytify_api_limit_social_media_stats', 5, 'dashboard' );

				// GA4 Mode
				$social_stats_raw = $wp_analytify->get_reports(
					'show-default-social-dashboard',
					array(
						'sessions',
					),
					array(
						'start' => $dates['start_date'],
						'end'   => $dates['end_date'],
					),
					array(
						'sessionSource',
					),
					array(
						'type'  => 'metric',
						'name'  => 'sessions',
						'order' => 'desc',
					),
					array(
						'logic'   => 'AND',
						'filters' => array(
							array(
								'type'           => 'dimension',
								'name'           => 'sessionSource',
								'match_type'     => 5,
								'value'          => '^([a-z-]*\.|)(facebook|reddit|youtube|tumblr|quora|instagram|linkedin|yelp|wordpress|pinterest|twitter|t)(\.(com|org|co|)|)$',
								'not_expression' => false,
							),
						),
					),
					$api_stats_limit * 3
				);

				if ( ! function_exists( 'social_stats' ) ) {
					include ANALYTIFY_EMAIL_VIEWS_PATH . 'social-media.php';
				}
				$message .= social_stats( $wp_analytify, $social_stats_raw );
			}
		}

		// Whats Happen.
		if ( in_array( 'show-whats-happen', $selected_sections, true ) ) {
			if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {
				// jawad changes this var name from stats to whats_happens finally.
				$whats_happens = $wp_analytify->get_reports(
					'analytify-email-what-happen-stats',
					array(
						'engagedSessions',
						'engagementRate',
						'userEngagementDuration',
					),
					array(
						'start' => $dates['start_date'],
						'end'   => $dates['end_date'],
					),
					array(
						'landingPage',
						'pageTitle',
					),
					array(
						'type'  => 'metric',
						'name'  => 'engagedSessions',
						'order' => 'desc',
					),
					array(),
					5
				);
				if ( ! function_exists( 'whats_happen' ) ) {
					include ANALYTIFY_EMAIL_VIEWS_PATH . 'whats-happen.php';
				}
				$message .= whats_happen( $wp_analytify, $whats_happens );
			}
		}

		// Video Tracking Stats.
		if ( in_array( 'show-video-tracking', $selected_sections, true ) ) {
			if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {
				// API request limit.
				$api_request_limit = (int) apply_filters( 'analytify_api_limit_video_tracking_email', 5, $this->ga_mode );

				$video_stats_raw = $wp_analytify->get_reports(
					'analytify-email-video-tracking-stats',
					array( 'eventCount' ),
					array(
						'start' => $dates['start_date'],
						'end'   => $dates['end_date'],
					),
					array(
						'customEvent:wpa_category',
						'customEvent:wpa_video_title',
						'customEvent:wpa_video_provider',
						'customEvent:wpa_video_action',
						'customEvent:wpa_video_duration',
					),
					array(
						'type'  => 'metric',
						'name'  => 'eventCount',
						'order' => 'desc',
					),
					array(
						'logic'   => 'AND',
						'filters' => array(
							array(
								'type'           => 'dimension',
								'name'           => 'customEvent:wpa_category',
								'match_type'     => 1,
								'value'          => 'Analytify Video Tracking',
								'not_expression' => false,
							),
						),
					),
					$api_request_limit
				);

				// Format video stats.
				$video_stats = array();
				if ( isset( $video_stats_raw['rows'] ) && ! empty( $video_stats_raw['rows'] ) ) {
					foreach ( $video_stats_raw['rows'] as $row ) {
						$video_stats[] = array(
							'title'    => sanitize_text_field( (string) ( $row['customEvent:wpa_video_title'] ?? '' ) ),
							'action'   => sanitize_text_field( (string) ( $row['customEvent:wpa_video_action'] ?? '' ) ),
							'provider' => sanitize_text_field( (string) ( $row['customEvent:wpa_video_provider'] ?? '' ) ),
							'duration' => absint( $row['customEvent:wpa_video_duration'] ?? 0 ),
							'count'    => absint( $row['eventCount'] ?? 0 ),
						);
					}
				}

				if ( ! function_exists( 'pa_include_video_tracking_stats' ) ) {
					include ANALYTIFY_EMAIL_VIEWS_PATH . 'video-tracking-stats.php';
				}
				$message .= pa_include_video_tracking_stats( $wp_analytify, $video_stats );
			}
		}

		if ( $wp_analytify && is_object( $wp_analytify ) && isset( $wp_analytify->settings ) && method_exists( $wp_analytify->settings, 'get_option' ) ) {
			$mail_text = $wp_analytify->settings->get_option( 'analytiy_mail_text', 'wp-analytify-email' );
			if ( '' !== $mail_text ) {
				$message .= '<tr>
				<td style="padding: 40px 20px; text-align:center;padding-bottom: 20px;font: normal 13px \'Roboto\', Arial, Helvetica, sans-serif;"><font color="#444444">' . $mail_text . '</font></td>
				</tr>';
			}
		}

		// Should we add the email note.
		$show_email_note = apply_filters( 'wp_analytify_show_email_note', true );
		$emil_note_text  = '';
		if ( $wp_analytify && is_object( $wp_analytify ) && isset( $wp_analytify->settings ) && method_exists( $wp_analytify->settings, 'get_option' ) ) {
			$emil_note_text = $wp_analytify->settings->get_option( 'analytiy_mail_text_additional', 'wp-analytify-email' );
		}

		if ( '' !== $emil_note_text && $show_email_note ) {
			// Filter the email additional note text.
			$text_email_note = apply_filters( 'wp_analytify_email_note_text', $emil_note_text );

			if ( $show_email_note ) {
				$note_title        = apply_filters( 'wp_analytify_email_note_title', 'Note:' );
				$note_title_string = ! empty( $note_title ) ? '<td valign="top" style="width:100px; font: bold 14px \'Roboto\', Arial, Helvetica, sans-serif; padding: 16px 4px 16px 20px;"><font color="#444444">' . $note_title . ' </font></td>' : '';

				$message .= '
				<tr>
					<td>
						<table cellpadding="0" cellspacing="0" border="0" width="100%">
							<tr>
								<td style="border: 1px solid #e2e5e8;">
									<table cellpadding="0" cellspacing="0" border="0" width="100%" bgcolor="#f9fafa">
										<tr>
											' . $note_title_string . '
											<td style="font: normal 14px \'Roboto\', Arial, Helvetica, sans-serif; padding: 16px 20px;"><font color="#848484">' . $text_email_note . '</font></td>
										</tr>
									</table>
								</td>
							</tr>
						</table>
					</td>
				</tr>';
			}
		}

		$go_to_dashboard = '';
		if ( $wp_analytify && is_object( $wp_analytify ) && isset( $wp_analytify->settings ) && method_exists( $wp_analytify->settings, 'get_option' ) ) {
			$go_to_dashboard = $wp_analytify->settings->get_option( 'analytify_go_to_dashboard', 'wp-analytify-email' );
		}
		if ( 'on' !== $go_to_dashboard ) {
			$dashboard_link = apply_filters( 'analytify_email_dashboard_url', get_admin_url( null, 'admin.php?page=analytify-dashboard' ) );
			$message       .= '<tr>
				<td style="padding-top: 40px; text-align:center;padding-bottom: 40px;"><a href="' . esc_url( $dashboard_link ) . '"><img src="' . ANALYTIFY_IMAGES_PATH . 'analytify_go_to_dashboard.png" alt="go to dashboard"  /></a></td>
			</tr>';
		}

		return $message;
	}
}
