Hi there,
We at Analytify welcomes you to our premium users family.


== Installation ==
You should have installed Analytify Free + Pro versions to use this Analytify for Email Notifications add-on.

If you have any problem, please send an email to us at support@analytify.io


Cheers
Adnan from Analytify LLC


== Changelog ==

= 5.5.1 - 2024-12-09 =
* Bug Fix: Error occurring when no stats are available in the Ecommerce Statistics section.

= 5.5.0 - 2024-11-06 =
* New Feature: Missing Social Media Stats section in Email Report.
* Enhancement: Removing Google Analytics V3 functions from the add-on completely. 
* Compatibility: Compatible to WordPress 6.7

= 5.2.0 - 2024-05-16 =
* New Feature: Add Forms Tracking Stats in Email Notifications.
* Enhancement: A filter is introduced to hide or show Countries/Cities sections in Email Notifications. Link https://analytify.io/doc/analytify-filters/

= 5.1.0 - 2023-08-10 =
* Bug Fix: Non Selected sections emailed in reports fixed.

= 5.0.2 - 2023-06-20 =
* Enhancement: Visitors site behavior section footer text changed.
* Enhancement: Translation files updated.

= 5.0.1 - 2023-05-15 =
* Bug Fix: Multiple Recipients not receiving all stats.

= 5.0.0 - 2023-04-18 =
* New Feature: Google Analytics GA4 integration is added.
* New Feature: Google Search Console (webmasters) Integrated.
* Enhancement: Pageload speed improvement.
* Enhancement: UI Improvements.

= 2.0.3 - September 13th, 2021 =
* Enhancement: Add tinymce editor for email notes option.
* Enhancement: Add filter for email note heading.
* Bug Fix: Send email reports for single post.
* Bug Fix: Fix "GO TO MY DASHBOARD" button position in reports.

= 2.0.2 - July 30th, 2021 =
* New Feature: Add filter for the dashboard button url in the email report.
* Compatibility: Compatible with WordPress 5.8

= 2.0.1 - March 22nd, 2021 =
* New Feature: Add option in settings to modify email note.

= 2.0.0 - March 12th, 2021 =
* Enhancement: Add referrers in email stats option.
* Enhancement: Update admin notices.

= 1.3.1 - August 12th, 2020 =
* Enhancement: Compatibility with new disable reports option.

= 1.3.0 - July 26th, 2020 =
* New Feature: Moved teaser features to free plugin.
* Enhancement: Update admin notices layout.

= 1.2.8 - April 13th, 2019 =
* BugFix: Fix layout issue on Microsoft Outlook.

= 1.2.7 - March 25th, 2019 =
* BugFix: Fix layout issue on Microsoft Outlook.
* BugFix: Fix incorrect "Total time on site" stats.
* BugFix: Comparison images not loaded in some cases.
* Enhancement: Confliction with TranslatePress plugin.
* Enhancement: Update language POT file.
* Enhancement: Fix typos.

= 1.2.6 - December 31st, 2018 =
* New Feature: Add WooCommerce Report.
* New Feature: Add Easy Digital Downloads Report.
* New Feature: Add option to set the custom date for email notification.
* New Feature: Add Personal Message option in email report.
* Enhancement: Format stats number.
* Enhancement: Remove cron instance on plugin uninstall.
* Enhancement: Add Swedish translation.
* Enhancement: Fix typo.

= 1.2.5 - November 30th, 2018 =
* New Feature: Customize Email Subject.

= 1.2.4 - October 26th, 2018 =
* Enhancement: Better Cache Algorithm.

= 1.2.3 - June 28th, 2018 =

* BugFix: Single Page/Post Email stats.
* Improvement: Add 'Avg stats on page' on single page/post email.
* Improvement: Add site URL on Company logo.


The full changelog is available at https://analytify.io/changelog/
