<?php
/**
 * Email Addon Loader.
 *
 * @package WP_Analytify_Pro
 */

// phpcs:ignoreFile WordPress.Files.FileName.InvalidClassFileName, Universal.Files.SeparateFunctionsFromOO.Mixed

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Analytify_Email_Loader
 *
 * Loads the Email addon.
 */
class Analytify_Email_Loader {

	/**
	 * Singleton instance.
	 *
	 * @var self|null
	 */
	public static $instance;

	/**
	 * Version.
	 *
	 * @var string
	 */
	public $version;

	/**
	 * Get singleton instance.
	 *
	 * @return self
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->version = analytify_pro_get_asset_version();
		$this->define_constants();
		$this->hooks();
		$this->may_be_load_addon();
	}

	/**
	 * Load addon if requirements are met.
	 *
	 * @return void
	 */
	public function may_be_load_addon() {
		if (
			file_exists( WP_PLUGIN_DIR . '/wp-analytify-pro/wp-analytify-pro.php' )
			&& function_exists( 'wp_analytify_pro_load' )
			&& class_exists( 'Analytify_Email_Core' )
		) {
			$email_addon_root_path = defined( 'ANALYTIFY_EMAIL_ADDON_ROOT_PATH' ) ? ANALYTIFY_EMAIL_ADDON_ROOT_PATH : __DIR__ . '/';
			include_once $email_addon_root_path . 'class-wp-analytify-email.php';
			$wp_analytify_email_instance = new WP_Analytify_Addon_Email();
		}
	}

	/**
	 * Define constants.
	 *
	 * @return void
	 */
	public function define_constants() {
		$this->define( 'ANALTYIFY_EMAIL_ADDON_VERSION', $this->version );
		$this->define( 'ANALYTIFY_EMAIL_ADDON_ROOT_PATH', __DIR__ . '/' );
		$this->define( 'ANALYTIFY_EMAIL_VIEWS_PATH', __DIR__ . '/views/' );
		$this->define( 'ANALYTIFY_IMAGES_PATH', 'https://analytify.io/assets/email/' );
		$this->define( 'ANALYTIFY_EMAIL_ADDON_UPGRADE_PATH', __FILE__ );
	}

	/**
	 * Setup hooks.
	 *
	 * @return void
	 */
	public function hooks() {
		add_action( 'admin_notices', array( $this, 'wpa_email_update_analytify_free' ) );
		add_action( 'admin_notices', array( $this, 'wpa_email_notices_scripts' ) );
		add_action( 'init', array( $this, 'wp_analytify_email_addon_load_text_domain' ) );
	}

	/**
	 * Show update notice for Analytify Free.
	 *
	 * @return void
	 */
	public function wpa_email_update_analytify_free() {
		if ( ! isset( $_GET['page'] ) || 'analytify-settings' !== $_GET['page'] || class_exists( 'Analytify_Email_Core' ) ) {
			return;
		}
		$message = esc_html__( 'Please Update Analytify Free to use Analytify Email Notifications addon.', 'wp-analytify-pro' );
		$this->wpa_email_notice( $message, 'wp-analytify-danger' );
	}

	/**
	 * Enqueue notice scripts.
	 *
	 * @return void
	 */
	public function wpa_email_notices_scripts() {
		$email_addon_version = defined( 'ANALTYIFY_EMAIL_ADDON_VERSION' ) ? ANALTYIFY_EMAIL_ADDON_VERSION : analytify_pro_get_asset_version();
		wp_enqueue_style( 'wpa-email-notices', plugins_url( 'assets/css/notices' . analytify_pro_get_asset_suffix() . '.css', __FILE__ ), array(), $email_addon_version );
	}

	/**
	 * Add custom admin notice.
	 *
	 * @param  string $message Custom Message.
	 * @param  string $class wp-analytify-success,wp-analytify-danger.
	 * @return void
	 */
	// phpcs:ignore Universal.NamingConventions.NoReservedKeywordParameterNames.classFound
	public function wpa_email_notice( $message, $class ) {
		echo esc_html(
			'<div class="wp-analytify-notification ' . $class . '">
		<a class="" href="#" aria-label="Dismiss the welcome panel"></a>
		<div class="wp-analytify-notice-logo">
		<img src="' . plugins_url( 'assets/img/logo.svg', __FILE__ ) . '" alt="analytify logo">
		</div>
		<div class="wp-analytify-notice-discription">
		<p>' . $message . '</p>
		</div>
		</div>'
		);
	}

	/**
	 * @return void
	 */
	public function wp_analytify_email_addon_load_text_domain() {
		// Text domain loaded by main Pro plugin.
		// All translations now use 'wp-analytify-pro' text domain.
	}

	/**
	 * Define constant.
	 *
	 * @param string $constant Constant name.
	 * @param mixed  $value Constant value.
	 * @return void
	 */
	public function define( $constant, $value ) {
		if ( ! defined( $constant ) ) {
			define( $constant, $value );
		}
	}

	/**
	 * Post activation house-keeping.
	 *
	 * @return void
	 */
	public static function wp_analytify_email_activation() {

		$_analytify_email = get_option( 'wp-analytify-email' );

		if ( empty( $_analytify_email ) || ! isset( $_analytify_email['analytif_email_cron_time'] ) ) {

			$default['analytify_email_stats'] = array(
				'show-overall-general',
				'show-top-pages',
				'show-geographics',
				'show-system',
				'show-system',
				'show-keywords',
				'show-social',
				'show-whats-happen',
				'show-referrer',
			);

			$default['analytify_email_user_email'] = get_bloginfo( 'admin_email' );
			$default['analytif_email_cron_time']   = array(
				'week'         => 'Monday',
				'month'        => 'false',
				'yesterday'    => 'false',
				'custom_range' => 'false',
			);
			
			update_option( 'wp-analytify-email', $default );
		}

		// Set default month option.
		if ( ! isset( $_analytify_email['analytif_email_cron_time']['month'] ) ) {
			$_analytify_email['analytif_email_cron_time']['month'] = 'false';

			update_option( 'wp-analytify-email', $_analytify_email );
		}
		// Set default week option.
		if ( ! isset( $_analytify_email['analytif_email_cron_time']['week'] ) ) {
			$_analytify_email['analytif_email_cron_time']['week'] = 'Monday';

			update_option( 'wp-analytify-email', $_analytify_email );
		}

		// Set default week option.
		if ( ! isset( $_analytify_email['analytif_email_cron_time']['yesterday'] ) ) {
			$_analytify_email['analytif_email_cron_time']['yesterday'] = 'false';

			update_option( 'wp-analytify-email', $_analytify_email );
		}

		// Set default custom_range option.
		if ( ! isset( $_analytify_email['analytif_email_cron_time']['custom_range'] ) ) {
			$_analytify_email['analytif_email_cron_time']['custom_range'] = 'false';

			update_option( 'wp-analytify-email', $_analytify_email );
		}
	}
	/**
	 * Post deactivation house-keeping.
	 *
	 * @return void
	 */
	public static function wp_analytify_email_deactivation() {
		wp_clear_scheduled_hook( 'analytify_email_cron_function' );
	}
}

Analytify_Email_Loader::get_instance();

register_activation_hook( __FILE__, array( 'Analytify_Email_Loader', 'wp_analytify_email_activation' ) );



register_deactivation_hook( __FILE__, array( 'Analytify_Email_Loader', 'wp_analytify_email_deactivation' ) );

/**
 * Helper function for translation.
 */
if ( ! function_exists( 'analytify__' ) ) {
	/**
	 * Wrapper for __() gettext function.
	 *
	 * @param  string $string     Translatable text string
	 * @param  string $textdomain Text domain, default: wp-analytify
	 * @return string
	 */
	function analytify__( $string, $textdomain = 'wp-analytify' ) {
		// phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralText,WordPress.WP.I18n.NonSingularStringLiteralDomain
		return __( $string, $textdomain );
	}
}

if ( ! function_exists( 'analytify_e' ) ) {
	/**
	 * Wrapper for _e() gettext function.
	 *
	 * @param  string $string     Translatable text string
	 * @param  string $textdomain Text domain, default: wp-analytify
	 * @return void
	 */
	function analytify_e( $string, $textdomain = 'wp-analytify' ) {
		// phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralText,WordPress.WP.I18n.NonSingularStringLiteralDomain
		echo esc_html( __( $string, $textdomain ) );
	}
}
