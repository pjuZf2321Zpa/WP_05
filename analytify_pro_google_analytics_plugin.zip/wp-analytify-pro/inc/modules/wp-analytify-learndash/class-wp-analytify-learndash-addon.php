<?php
/**
 * LearnDash Integration Main Class for Analytify.
 *
 * @package    Analytify
 * @subpackage LearnDash
 */

if ( class_exists( 'WP_Analytify_LearnDash_Addon' ) ) {
	return;
}

/**
 * Analytify LearnDash Integration Class.
 */
class WP_Analytify_LearnDash_Addon extends WP_Analytify_Pro_Base {

	/**
	 * The one true instance.
	 *
	 * @var WP_Analytify_LearnDash_Addon
	 * @since 1.0.0
	 */
	private static $instance;

	/**
	 * Google Measurement URL.
	 *
	 * @var string
	 */
	public $google_measurement_url = 'https://ssl.google-analytics.com/collect';

	/**
	 * Google Debug Measurement URL.
	 *
	 * @var string
	 */
	public $google_debug_measurement_url = 'https://www.google-analytics.com/debug/collect';

	/**
	 * Order fully refunded flag.
	 *
	 * @var null|bool
	 */
	public $order_fully_refunded = null;

	/**
	 * Course list for tracking.
	 *
	 * @var array
	 */
	private $course_list = array();

	/**
	 * Same-request dedupe for `wpa_ldlms_course_enrolled` (both `learndash_update_course_access`
	 * and `ld_added_course_access` can call `track_enrollment()` in one request).
	 *
	 * @var array<string, true>
	 */
	private static $enrollment_tracked_this_request = array();

	/**
	 * Tracking scripts to be output in footer.
	 *
	 * @var array
	 */
	private $tracking_scripts = array();

	/**
	 * Get active instance.
	 *
	 * @access      public
	 * @since       1.0.0
	 * @return      object self::$instance The one true WP_Analytify_LearnDash_Addon
	 */
	public static function instance() {
		if ( ! self::$instance ) {
			self::$instance = new WP_Analytify_LearnDash_Addon();
			self::$instance->setup_constants();
			self::$instance->includes();
			self::$instance->hooks();
		}

		return self::$instance;
	}

	/**
	 * Format currency value with proper symbol and formatting.
	 *
	 * @param float  $amount The amount to format.
	 * @param string $currency_code The currency code (defaults to LearnDash currency).
	 *
	 * @since 1.0.0
	 * @return string Formatted currency string.
	 */
	public static function analytify_format_currency( $amount, $currency_code = '' ) {
		if ( empty( $currency_code ) ) {
			if ( function_exists( 'learndash_get_currency_code' ) ) {
				$currency_code = learndash_get_currency_code();
			} elseif ( function_exists( 'get_woocommerce_currency' ) ) {
				$currency_code = get_woocommerce_currency();
			} else {
				$currency_code = 'USD';
			}
		}

		if ( function_exists( 'learndash_get_currency_symbol' ) ) {
			$currency_symbol = learndash_get_currency_symbol( $currency_code );
		} elseif ( function_exists( 'get_woocommerce_currency_symbol' ) ) {
			$currency_symbol = get_woocommerce_currency_symbol( $currency_code );
		} else {
			$currency_symbol = '$';
		}

		return $currency_symbol . number_format( (float) $amount, 2 );
	}

	/**
	 * Setup plugin constants.
	 *
	 * @access      private
	 * @since       1.0.0
	 * @return      void
	 */
	private function setup_constants() {
		// Setting Global Values.
		$this->define( 'LDMS_ANALYTIFY_PLUGIN_FILE', __FILE__ );
		$this->define( 'LDMS_ANALYTIFY_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );
		$this->define( 'LDMS_ANALYTIFY_PLUGIN_DIR', __DIR__ );
		$this->define( 'LDMS_ANALYTIFY_PRODUCT_NAME', 'Enhanced E-Commerce Google Analytics for LearnDash Addon' );
		$this->define( 'LDMS_ANALYTIFY_PRODUCT_ID', 9998 );
		$this->define( 'LDMS_ANALYTIFY_STORE_URL', 'https://analytify.io' );
	}

	/**
	 * Define constant if not already set.
	 *
	 * @param  string      $name Constant name.
	 * @param  string|bool $value Constant value.
	 * @since 9.0.0
	 * @return void
	 */
	private function define( $name, $value ) {
		if ( ! defined( $name ) ) {
			define( $name, $value );
		}
	}

	/**
	 * Include necessary files.
	 *
	 * @access      private
	 * @since       1.0.0
	 * @return      void
	 */
	private function includes() {
		// Core wp-analytify does not autoload `analytify-mp-ga4.php`; load it here for server-side MP.
		$this->maybe_load_mp_ga4();

		// Rest endpoints.
		include LDMS_ANALYTIFY_PLUGIN_DIR . '/classes/class-analytify-ldms-rest-api.php';
	}

	/**
	 * Load the free plugin's Measurement Protocol helper (not part of wp-analytify's main `includes()` list).
	 *
	 * Tries several paths so the LearnDash addon still finds the file if constants or folder layout differ.
	 *
	 * @since 9.0.0
	 * @return bool True if `analytify_mp_ga4()` is available.
	 */
	private function maybe_load_mp_ga4() {
		if ( function_exists( 'analytify_mp_ga4' ) ) {
			return true;
		}

		$candidates = array();
		if ( defined( 'WP_ANALYTIFY_PLUGIN_DIR' ) ) {
			$candidates[] = trailingslashit( WP_ANALYTIFY_PLUGIN_DIR ) . 'classes/analytify-mp-ga4.php';
		}
		if ( defined( 'WP_PLUGIN_DIR' ) ) {
			$candidates[] = WP_PLUGIN_DIR . '/wp-analytify/classes/analytify-mp-ga4.php';
		}
		$candidates[] = dirname( dirname( dirname( dirname( __DIR__ ) ) ) ) . '/wp-analytify/classes/analytify-mp-ga4.php';

		foreach ( array_unique( array_filter( $candidates ) ) as $path ) {
			if ( is_readable( $path ) ) {
				require_once $path;
				break;
			}
		}

		return function_exists( 'analytify_mp_ga4' );
	}

	/**
	 * Send events via GA4 Measurement Protocol (ensures core helper is loaded first).
	 *
	 * @param array<int, array<string, mixed>> $events Event payloads for `analytify_mp_ga4()`.
	 * @since 9.0.0
	 * @return bool False if the core helper could not be loaded.
	 */
	private function send_mp_ga4_events( $events ) {
		if ( ! $this->maybe_load_mp_ga4() ) {
			return false;
		}
		return analytify_mp_ga4( $events );
	}

	/**
	 * Run action and filter hooks.
	 *
	 * @access      private
	 * @since       1.0.0
	 * @return      void
	 */
	private function hooks() {
		// Add menu for LearnDash Analytics Dashboard (static callback; add_menu does not use instance state).
		add_action( 'analytify_add_submenu', array( 'WP_Analytify_LearnDash_Addon', 'add_menu' ), 10 );

		add_action( 'admin_notices', array( $this, 'show_admin_notices' ) );
		add_action( 'ga_ecommerce_js', array( $this, 'add_ga_ecommerce_js' ), 1 );

		// Track course views.
		add_action( 'template_redirect', array( $this, 'track_course_view' ) );
		add_action( 'template_redirect', array( $this, 'track_lesson_view' ) );

		// Track enrollments.
		// Hook into LearnDash's course access update (fires for both add and remove).
		add_action( 'learndash_update_course_access', array( $this, 'track_enrollment_on_access_update' ), 10, 4 );
		// Legacy hook support (some addons may still use this).
		add_action( 'ld_added_course_access', array( $this, 'track_enrollment' ), 10, 2 );

		// Track purchases/orders (WooCommerce integration).
		add_action( 'woocommerce_payment_complete', array( $this, 'track_purchase' ), 10, 1 );
		add_action( 'woocommerce_order_status_completed', array( $this, 'track_order_complete' ), 10, 1 );
		add_action( 'woocommerce_order_status_processing', array( $this, 'track_order_complete' ), 10, 1 );

		// Track refunds.
		add_action( 'woocommerce_order_status_refunded', array( $this, 'track_refund' ), 10, 1 );
		add_action( 'woocommerce_order_refunded', array( $this, 'track_refund' ), 10, 2 ); // For partial refunds.
		add_action( 'woocommerce_order_status_cancelled', array( $this, 'track_cancelled' ), 10, 1 );

		// Track checkout steps.
		add_action( 'woocommerce_after_checkout_form', array( $this, 'track_checkout_billing' ) );
		add_action( 'woocommerce_review_order_before_payment', array( $this, 'track_checkout_payment' ) );

		// Store GA identity in order.
		add_action( 'woocommerce_checkout_create_order', array( $this, 'store_ga_identity' ), 10, 1 );

		// Add dashboard dropdown option.
		add_action( 'analytify_dashboad_dropdown_option', array( $this, 'dashboad_dropdown_option' ) );

		// Add source/medium meta box and column.
		add_action( 'add_meta_boxes', array( $this, 'source_meta_box' ) );

		// Course list impressions (hook into WordPress loop for course archives).
		add_action( 'the_post', array( $this, 'feed_course_data' ) );
		add_action( 'wp_footer', array( $this, 'print_course_data' ) );

		// Output tracking scripts.
		add_action( 'wp_footer', array( $this, 'output_tracking_scripts' ), 999 );

		// LearnDash specific hooks.
		add_action( 'learndash_course_completed', array( $this, 'track_course_completion' ), 10, 1 );
		add_action( 'learndash_lesson_completed', array( $this, 'track_lesson_completion' ), 10, 1 );
		add_action( 'learndash_topic_completed', array( $this, 'track_topic_completion' ), 10, 1 );
		add_action( 'learndash_quiz_completed', array( $this, 'track_quiz_completion' ), 10, 2 );
		add_action( 'learndash_quiz_submitted', array( $this, 'track_quiz_started' ), 10, 2 );
		add_action( 'learndash_assignment_uploaded', array( $this, 'track_assignment_uploaded' ), 10, 2 );

		add_filter( 'analytify_install_ga_text', array( $this, 'install_ga_text' ) );
		add_filter( 'analytify_admin_bar_menu', array( $this, 'add_admin_bar_menu' ), 15, 1 );
	}

	/**
	 * Track course view (single course detail page only).
	 * Must use is_singular() only: on course list/archive, $post can be the first course in the loop,
	 * so fallbacks would incorrectly fire wpa_view_course with that course's label on the list page.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function track_course_view() {
		global $post;

		// Only fire on a true single course page, not on course archive/list (where $post may be a course in the loop).
		if ( ! is_singular( 'sfwd-courses' ) ) {
			return;
		}

		if ( ! $post || get_post_type( $post ) !== 'sfwd-courses' ) {
			return;
		}

		$course_id = $post->ID;

		if ( ! $this->is_track_user() || ! $this->is_ga_enable() ) {
			return;
		}

		// Only support GA4 - UA/GA3 is deprecated.
		$item = $this->get_tracked_item_ga4( $course_id );

		// Event-level value must stay 0 for views: GA4 sums `value` per hit, so using course price here
		// makes "Event Value" look like revenue (sum of list prices × view count). Item price remains in `items` for item-scoped reports.
		$currency = function_exists( 'learndash_get_currency_code' ) ? learndash_get_currency_code() : ( function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : 'USD' );

		$code = '(function() {
			if (typeof gtag !== "undefined") {
				gtag("event", "wpa_view_course", {
					"value": 0,
					"currency": "' . esc_js( $currency ) . '",
					"wpa_label": "' . esc_js( get_the_title( $course_id ) ) . '",
					"items": [ ' . wp_json_encode( $item ) . ' ]
				});
			} else {
				window.addEventListener("load", function() {
					if (typeof gtag !== "undefined") {
						gtag("event", "wpa_view_course", {
							"value": 0,
							"currency": "' . esc_js( $currency ) . '",
							"wpa_label": "' . esc_js( get_the_title( $course_id ) ) . '",
							"items": [ ' . wp_json_encode( $item ) . ' ]
						});
					}
				});
			}
		})();';

		$this->add_inline_js_wpa_ldms( $code );
	}

	/**
	 * Track lesson view.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function track_lesson_view() {
		global $post;

		// Check if this is a lesson or topic page using multiple methods.
		$is_lesson = false;
		if ( is_singular( array( 'sfwd-lessons', 'sfwd-topic' ) ) ) {
			$is_lesson = true;
		} elseif ( $post && in_array( get_post_type( $post ), array( 'sfwd-lessons', 'sfwd-topic' ), true ) ) {
			$is_lesson = true;
		}

		if ( ! $is_lesson ) {
			return;
		}

		$lesson_id = $post->ID;

		if ( ! $this->is_track_user() || ! $this->is_ga_enable() ) {
			return;
		}

		$course_id = learndash_get_course_id( $lesson_id );

		if ( ! $course_id ) {
			return;
		}

		// Only support GA4 - UA/GA3 is deprecated.
		$cookie_data = isset( $_COOKIE ) && is_array( $_COOKIE ) ? $_COOKIE : array();
		$session_id  = $this->analytify_filter_session_id( $cookie_data );

		$event[] = array(
			'name'   => 'wpa_ldlms_lesson_viewed',
			'params' => array(
				'lesson_id'          => $lesson_id,
				'lesson_name'        => get_the_title( $lesson_id ),
				'course_id'          => $course_id,
				'course_name'        => get_the_title( $course_id ),
				'wpa_ldms_post_type' => get_post_type( $lesson_id ),
				'wpa_label'          => get_the_title( $lesson_id ),
				'value'              => 0,
				'currency'           => function_exists( 'learndash_get_currency_code' ) ? learndash_get_currency_code() : ( function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : 'USD' ),
				'session_id'         => $session_id,
			),
		);

		$this->send_mp_ga4_events( $event );
	}

	/**
	 * Track enrollment on LearnDash course access update.
	 *
	 * @param int    $user_id            User ID.
	 * @param int    $course_id          Course ID.
	 * @param string $course_access_list Course access list (legacy).
	 * @param bool   $remove             Whether access is being removed.
	 * @since 1.0.0
	 * @return void
	 */
	public function track_enrollment_on_access_update( $user_id, $course_id, $course_access_list = null, $remove = false ) {
		// Only track enrollments, not unenrollments.
		if ( $remove ) {
			return;
		}

		// Call the main enrollment tracking method.
		$this->track_enrollment( $user_id, $course_id );
	}

	/**
	 * Track enrollment.
	 *
	 * @param int $user_id User ID.
	 * @param int $course_id Course ID.
	 * @since 1.0.0
	 * @return void
	 */
	public function track_enrollment( $user_id, $course_id ) {
		if ( ! $this->is_track_user() || ! $this->is_ga_enable() ) {
			return;
		}

		if ( ! get_post( $course_id ) || 'sfwd-courses' !== get_post_type( $course_id ) ) {
			return;
		}

		// Avoid duplicate `wpa_ldlms_course_enrolled` when LearnDash fires both access hooks in one request.
		$dedupe_key = (int) $user_id . ':' . (int) $course_id;
		if ( isset( self::$enrollment_tracked_this_request[ $dedupe_key ] ) ) {
			return;
		}
		self::$enrollment_tracked_this_request[ $dedupe_key ] = true;

		// Only support GA4 - UA/GA3 is deprecated.
		$cookie_data = isset( $_COOKIE ) && is_array( $_COOKIE ) ? $_COOKIE : array();
		$session_id  = $this->analytify_filter_session_id( $cookie_data );
		$item        = $this->get_tracked_item_ga4( $course_id );
		$price       = 0;
		if ( function_exists( 'learndash_get_course_price' ) ) {
			$price_data = learndash_get_course_price( $course_id );
			if ( is_array( $price_data ) && isset( $price_data['price'] ) && is_numeric( $price_data['price'] ) ) {
				$price = floatval( $price_data['price'] );
			}
		}

		$event[] = array(
			'name'   => 'wpa_ldlms_course_enrolled',
			'params' => array(
				'currency'           => function_exists( 'learndash_get_currency_code' ) ? learndash_get_currency_code() : ( function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : 'USD' ),
				'value'              => $price,
				'items'              => array( $item ),
				'user_id'            => $user_id,
				'course_id'          => (int) $course_id,
				'wpa_ldms_post_type' => 'sfwd-courses',
				'wpa_label'          => get_the_title( $course_id ),
				'session_id'         => $session_id,
			),
		);

		$this->send_mp_ga4_events( $event );
	}

	/**
	 * Track course completion.
	 *
	 * @param array $data Course completion data.
	 * @since 1.0.0
	 * @return void
	 */
	public function track_course_completion( $data ) {
		if ( ! $this->is_track_user() || ! $this->is_ga_enable() ) {
			return;
		}

		if ( ! is_array( $data ) ) {
			return;
		}

		$user_obj   = isset( $data['user'] ) ? $data['user'] : null;
		$course_obj = isset( $data['course'] ) ? $data['course'] : null;
		$user_id    = ( is_object( $user_obj ) && isset( $user_obj->ID ) ) ? (int) $user_obj->ID : 0;
		$course_id  = ( is_object( $course_obj ) && isset( $course_obj->ID ) ) ? (int) $course_obj->ID : 0;

		if ( ! $course_id ) {
			return;
		}

		// Only support GA4 - UA/GA3 is deprecated.
		$cookie_data = isset( $_COOKIE ) && is_array( $_COOKIE ) ? $_COOKIE : array();
		$session_id  = $this->analytify_filter_session_id( $cookie_data );
		$item        = $this->get_tracked_item_ga4( $course_id );

		$event[] = array(
			'name'   => 'wpa_ldlms_course_completed',
			'params' => array(
				'currency'           => function_exists( 'learndash_get_currency_code' ) ? learndash_get_currency_code() : ( function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : 'USD' ),
				'value'              => 0,
				'items'              => array( $item ),
				'user_id'            => $user_id,
				'course_id'          => (int) $course_id,
				'wpa_ldms_post_type' => 'sfwd-courses',
				'wpa_label'          => get_the_title( $course_id ),
				'session_id'         => $session_id,
			),
		);

		$this->send_mp_ga4_events( $event );
	}

	/**
	 * Track lesson completion.
	 *
	 * @param array $data Lesson completion data.
	 * @since 1.0.0
	 * @return void
	 */
	public function track_lesson_completion( $data ) {
		if ( ! is_array( $data ) ) {
			return;
		}

		$user_obj     = isset( $data['user'] ) ? $data['user'] : null;
		$lesson_obj   = isset( $data['lesson'] ) ? $data['lesson'] : null;
		$course_obj   = isset( $data['course'] ) ? $data['course'] : null;
		$user_id      = ( is_object( $user_obj ) && isset( $user_obj->ID ) ) ? (int) $user_obj->ID : 0;
		$lesson_id    = ( is_object( $lesson_obj ) && isset( $lesson_obj->ID ) ) ? (int) $lesson_obj->ID : 0;
		$course_id    = ( is_object( $course_obj ) && isset( $course_obj->ID ) ) ? (int) $course_obj->ID : 0;
		$lesson_title = $lesson_id ? get_the_title( $lesson_id ) : '';
		$course_title = $course_id ? get_the_title( $course_id ) : '';

		if ( ! $lesson_id || ! $course_id ) {
			return;
		}

		if ( ! $this->is_track_user() || ! $this->is_ga_enable() ) {
			return;
		}

		// Only support GA4 - UA/GA3 is deprecated.
		$cookie_data = isset( $_COOKIE ) && is_array( $_COOKIE ) ? $_COOKIE : array();
		$session_id  = $this->analytify_filter_session_id( $cookie_data );

		$event[] = array(
			'name'   => 'wpa_ldlms_lesson_completed',
			'params' => array(
				'lesson_id'          => $lesson_id,
				'lesson_name'        => $lesson_title,
				'course_id'          => $course_id,
				'course_name'        => $course_title,
				'wpa_ldms_post_type' => 'sfwd-lessons',
				'wpa_label'          => $lesson_title,
				'value'              => 0,
				'currency'           => function_exists( 'learndash_get_currency_code' ) ? learndash_get_currency_code() : ( function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : 'USD' ),
				'user_id'            => $user_id,
				'session_id'         => $session_id,
			),
		);

		$this->send_mp_ga4_events( $event );
	}

	/**
	 * Track topic completion.
	 *
	 * @param array $data Topic completion data.
	 * @since 1.0.0
	 * @return void
	 */
	public function track_topic_completion( $data ) {
		if ( ! is_array( $data ) ) {
			return;
		}

		$user_obj     = isset( $data['user'] ) ? $data['user'] : null;
		$topic_obj    = isset( $data['topic'] ) ? $data['topic'] : null;
		$lesson_obj   = isset( $data['lesson'] ) ? $data['lesson'] : null;
		$course_obj   = isset( $data['course'] ) ? $data['course'] : null;
		$user_id      = ( is_object( $user_obj ) && isset( $user_obj->ID ) ) ? (int) $user_obj->ID : 0;
		$topic_id     = ( is_object( $topic_obj ) && isset( $topic_obj->ID ) ) ? (int) $topic_obj->ID : 0;
		$lesson_id    = ( is_object( $lesson_obj ) && isset( $lesson_obj->ID ) ) ? (int) $lesson_obj->ID : 0;
		$course_id    = ( is_object( $course_obj ) && isset( $course_obj->ID ) ) ? (int) $course_obj->ID : 0;
		$topic_title  = $topic_id ? get_the_title( $topic_id ) : '';
		$lesson_title = $lesson_id ? get_the_title( $lesson_id ) : '';
		$course_title = $course_id ? get_the_title( $course_id ) : '';

		if ( ! $topic_id || ! $lesson_id || ! $course_id ) {
			return;
		}

		if ( ! $this->is_track_user() || ! $this->is_ga_enable() ) {
			return;
		}

		// Only support GA4 - UA/GA3 is deprecated.
		$cookie_data = isset( $_COOKIE ) && is_array( $_COOKIE ) ? $_COOKIE : array();
		$session_id  = $this->analytify_filter_session_id( $cookie_data );

		$event[] = array(
			'name'   => 'wpa_ldlms_topic_completed',
			'params' => array(
				'topic_id'           => $topic_id,
				'topic_name'         => $topic_title,
				'lesson_id'          => $lesson_id,
				'lesson_name'        => $lesson_title,
				'course_id'          => $course_id,
				'course_name'        => $course_title,
				'wpa_ldms_post_type' => 'sfwd-topic',
				'wpa_label'          => $topic_title,
				'value'              => 0,
				'currency'           => function_exists( 'learndash_get_currency_code' ) ? learndash_get_currency_code() : ( function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : 'USD' ),
				'user_id'            => $user_id,
				'session_id'         => $session_id,
			),
		);

		$this->send_mp_ga4_events( $event );
	}

	/**
	 * Track quiz started.
	 *
	 * @param array   $quizdata Quiz data array.
	 * @param WP_User $user     User object.
	 * @since 1.0.0
	 * @return void
	 */
	public function track_quiz_started( $quizdata, $user ) {
		if ( ! $this->is_track_user() || ! $this->is_ga_enable() ) {
			return;
		}

		// Extract data from quizdata array.
		$quiz_id   = isset( $quizdata['quiz'] ) ? absint( $quizdata['quiz'] ) : 0;
		$course_id = isset( $quizdata['course'] ) ? ( is_object( $quizdata['course'] ) ? $quizdata['course']->ID : absint( $quizdata['course'] ) ) : 0;
		$user_id   = is_object( $user ) && isset( $user->ID ) ? $user->ID : 0;

		if ( ! $quiz_id || ! $course_id ) {
			return;
		}

		$quiz_title   = get_the_title( $quiz_id );
		$course_title = get_the_title( $course_id );

		$cookie_data = isset( $_COOKIE ) && is_array( $_COOKIE ) ? $_COOKIE : array();
		$session_id  = $this->analytify_filter_session_id( $cookie_data );

		$event[] = array(
			'name'   => 'wpa_ldlms_quiz_started',
			'params' => array(
				'quiz_id'            => $quiz_id,
				'quiz_name'          => $quiz_title,
				'course_id'          => $course_id,
				'course_name'        => $course_title,
				'wpa_ldms_post_type' => 'sfwd-quiz',
				'wpa_label'          => $quiz_title,
				'value'              => 0,
				'currency'           => function_exists( 'learndash_get_currency_code' ) ? learndash_get_currency_code() : ( function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : 'USD' ),
				'user_id'            => $user_id,
				'session_id'         => $session_id,
			),
		);

		$this->send_mp_ga4_events( $event );
	}

	/**
	 * Track quiz completion.
	 *
	 * @param array   $data Quiz completion data.
	 * @param WP_User $user User object.
	 * @since 1.0.0
	 * @return void
	 */
	public function track_quiz_completion( $data, $user ) {
		if ( ! $this->is_track_user() || ! $this->is_ga_enable() ) {
			return;
		}

		$quiz_id   = isset( $data['quiz'] ) ? $data['quiz'] : 0;
		$course_id = isset( $data['course'] ) ? $data['course'] : 0;

		if ( ! $quiz_id || ! $course_id ) {
			return;
		}

		$quiz_title   = get_the_title( $quiz_id );
		$course_title = get_the_title( $course_id );
		$score        = isset( $data['score'] ) ? $data['score'] : 0;
		$pass         = isset( $data['pass'] ) ? $data['pass'] : false;

		$cookie_data = isset( $_COOKIE ) && is_array( $_COOKIE ) ? $_COOKIE : array();
		$session_id  = $this->analytify_filter_session_id( $cookie_data );
		$user_id     = ( is_object( $user ) && isset( $user->ID ) ) ? (int) $user->ID : 0;

		$event[] = array(
			'name'   => 'wpa_ldlms_quiz_completed',
			'params' => array(
				'quiz_id'            => $quiz_id,
				'quiz_name'          => $quiz_title,
				'course_id'          => $course_id,
				'course_name'        => $course_title,
				'wpa_ldms_post_type' => 'sfwd-quiz',
				'wpa_label'          => $quiz_title,
				'value'              => 0,
				'currency'           => function_exists( 'learndash_get_currency_code' ) ? learndash_get_currency_code() : ( function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : 'USD' ),
				'user_id'            => $user_id,
				'score'              => intval( $score ),
				'pass'               => $pass ? 'yes' : 'no',
				'session_id'         => $session_id,
			),
		);

		$this->send_mp_ga4_events( $event );
	}

	/**
	 * Track assignment uploaded.
	 *
	 * @param int   $assignment_id Assignment ID.
	 * @param array $assignment_meta Assignment meta data.
	 * @since 1.0.0
	 * @return void
	 */
	public function track_assignment_uploaded( $assignment_id, $assignment_meta ) {
		if ( ! $this->is_track_user() || ! $this->is_ga_enable() ) {
			return;
		}

		$course_id = isset( $assignment_meta['course_id'] ) ? $assignment_meta['course_id'] : 0;
		$lesson_id = isset( $assignment_meta['lesson_id'] ) ? $assignment_meta['lesson_id'] : 0;
		$user_id   = isset( $assignment_meta['user_id'] ) ? $assignment_meta['user_id'] : 0;

		if ( ! $course_id || ! $lesson_id ) {
			return;
		}

		$assignment_title = get_the_title( $assignment_id );
		$course_title     = get_the_title( $course_id );
		$lesson_title     = get_the_title( $lesson_id );

		$cookie_data = isset( $_COOKIE ) && is_array( $_COOKIE ) ? $_COOKIE : array();
		$session_id  = $this->analytify_filter_session_id( $cookie_data );

		$event[] = array(
			'name'   => 'wpa_ldlms_assignment_uploaded',
			'params' => array(
				'assignment_id'      => $assignment_id,
				'assignment_name'    => $assignment_title,
				'lesson_id'          => $lesson_id,
				'lesson_name'        => $lesson_title,
				'course_id'          => $course_id,
				'course_name'        => $course_title,
				'wpa_ldms_post_type' => 'sfwd-assignment',
				'wpa_label'          => $assignment_title,
				'value'              => 0,
				'currency'           => function_exists( 'learndash_get_currency_code' ) ? learndash_get_currency_code() : ( function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : 'USD' ),
				'user_id'            => $user_id,
				'session_id'         => $session_id,
			),
		);

		$this->send_mp_ga4_events( $event );
	}

	/**
	 * Get tracked data for a single item for GA4.
	 *
	 * @param int   $product_id Product ID.
	 * @param float $price      Price override.
	 * @since 9.0.0
	 * @return array
	 */
	private function get_tracked_item_ga4( $product_id, $price = null ) {
		if ( ! get_post( $product_id ) || 'sfwd-courses' !== get_post_type( $product_id ) ) {
			return array();
		}

		if ( is_null( $price ) ) {
			$price = 0;
			if ( function_exists( 'learndash_get_course_price' ) ) {
				$price_data = learndash_get_course_price( $product_id );
				if ( is_array( $price_data ) && isset( $price_data['price'] ) && is_numeric( $price_data['price'] ) ) {
					$price = floatval( $price_data['price'] );
				}
			}
		}

		$post_type      = get_post_type( $product_id );
		$categories     = get_the_terms( $product_id, 'ld_course_category' );
		$category_names = is_array( $categories ) ? wp_list_pluck( $categories, 'name' ) : array();
		$first_category = reset( $category_names );

		// Get instructor/author.
		$post_obj        = get_post( $product_id );
		$author_id       = ( $post_obj && isset( $post_obj->post_author ) ) ? absint( $post_obj->post_author ) : 0;
		$instructor_name = $author_id ? get_the_author_meta( 'display_name', $author_id ) : '';

		return array(
			'item_id'             => $product_id,
			'item_name'           => get_the_title( $product_id ),
			'item_category'       => $first_category ? $first_category : '',
			'price'               => $price,
			'quantity'            => 1,
			'wpa_ldms_post_type'  => $post_type,
			'wpa_ldms_instructor' => $instructor_name,
		);
	}

	/**
	 * This function is responsible for filtering the raw ids in cookies.
	 * It will return the extracted ids that could be used in mp secret hit.
	 *
	 * @param mixed $value The raw id or cookies array in case of session_id.
	 *
	 * @return string $id
	 *
	 * @since 1.0.0
	 */
	public function analytify_filter_session_id( $value ) {
		if ( ! is_array( $value ) ) {
			return 0;
		}

		foreach ( $value as $cookie_name => $cookie_content ) {
			if ( strpos( $cookie_name, '_ga_' ) === 0 ) {
				// Extract the session ID from the cookie content using a regular expression.
				$sanitized_content = is_string( $cookie_content ) ? sanitize_text_field( $cookie_content ) : '';
				if ( ! empty( $sanitized_content ) && preg_match( '/s(\d+)/', $sanitized_content, $matches ) ) {
					return (int) $matches[1]; // Returns the numeric session ID.
				}
			}
		}

		return 0;
	}

	/**
	 * Ignore tracking if user excluded.
	 *
	 * @since 9.0.0
	 * @return bool True if user should be tracked, false otherwise.
	 */
	public function is_track_user() {
		if ( ! is_user_logged_in() ) {
			return true;
		}

		$user     = wp_get_current_user();
		$roles    = ( $user && isset( $user->roles ) && is_array( $user->roles ) ) ? $user->roles : array();
		$is_track = $GLOBALS['WP_ANALYTIFY']->settings->get_option( 'exclude_users_tracking', 'wp-analytify-profile', array() );

		if ( ! empty( $roles ) && isset( $roles[0] ) && in_array( $roles[0], $is_track, true ) ) {
			return false;
		}

		return true;
	}

	/**
	 * Ignore if analytics code is not added.
	 *
	 * @since 9.0.0
	 * @return bool True if GA code is enabled, false otherwise.
	 */
	public function is_ga_enable() {
		$is_code = $GLOBALS['WP_ANALYTIFY']->settings->get_option( 'install_ga_code', 'wp-analytify-profile' );

		if ( 'on' !== $is_code ) {
			$code = 'console.warn("`Activate Install Google Analytics tracking code` from Analytify Profile Tab Settings")';
			$this->add_inline_js_wpa_ldms( $code );
			return false;
		} else {
			return true;
		}
	}

	/**
	 * Get client ID.
	 *
	 * @param string $order_id Order ID.
	 * @since 1.0.0
	 * @return string
	 */
	public function get_cid( $order_id = '' ) {
		$saved_cid = get_post_meta( $order_id, 'analytify_ldms_cid', true );

		if ( ! empty( $_COOKIE['_ga'] ) ) {
			$ga_cookie = sanitize_text_field( wp_unslash( $_COOKIE['_ga'] ) );
			$parts     = preg_split( '/\./', $ga_cookie, 4 );
			if ( count( $parts ) >= 4 && '' !== $parts[0] && '' !== $parts[1] ) {
				return $parts[2] . '.' . $parts[3];
			}
		}

		if ( ! empty( $order_id ) && ! empty( $saved_cid ) ) {
			return $saved_cid;
		}

		return $this->generate_uuid();
	}

	/**
	 * Generate UUID v4 function - needed to generate a CID when one isn't available.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	public function generate_uuid() {
		return sprintf(
			'%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
			// 32 bits for "time_low".
			wp_rand( 0, 0xffff ),
			wp_rand( 0, 0xffff ),
			// 16 bits for "time_mid".
			wp_rand( 0, 0xffff ),
			// 16 bits for "time_hi_and_version".
			// four most significant bits holds version number 4.
			wp_rand( 0, 0x0fff ) | 0x4000,
			// 16 bits, 8 bits for "clk_seq_hi_res".
			// 8 bits for "clk_seq_low".
			// two most significant bits holds zero and one for variant DCE1.1.
			wp_rand( 0, 0x3fff ) | 0x8000,
			// 48 bits for "node".
			wp_rand( 0, 0xffff ),
			wp_rand( 0, 0xffff ),
			wp_rand( 0, 0xffff )
		);
	}

	/**
	 * Add menu for LearnDash dashboard page.
	 *
	 * @access public
	 * @since 1.0.0
	 * @return void
	 */
	public static function add_menu() {
		add_submenu_page( 'analytify-dashboard', esc_html__( 'Track everything in LearnDash with Analytify.', 'wp-analytify-pro' ), esc_html__( 'LearnDash', 'wp-analytify-pro' ), 'edit_posts', 'analytify-learndash', array( __CLASS__, 'analytify_page_file_path' ), 16 );
	}

	/**
	 * Include file for LearnDash dashboard page.
	 *
	 * @access public
	 * @since 1.0.0
	 * @return void
	 */
	public static function analytify_page_file_path() {
		$screen = get_current_screen();

		if ( strpos( $screen->base, 'analytify-learndash' ) !== false ) {
			include LDMS_ANALYTIFY_PLUGIN_DIR . '/includes/learndash-dashboard.php';
		}
	}

	/**
	 * Add inline JS for LearnDash tracking.
	 *
	 * @param string $code JavaScript code to add.
	 * @since 9.0.0
	 * @return void
	 */
	public function add_inline_js_wpa_ldms( $code ) {
		$this->tracking_scripts[] = $code;
	}

	/**
	 * Output tracking scripts in footer.
	 *
	 * @since 9.0.0
	 * @return void
	 */
	public function output_tracking_scripts() {
		if ( empty( $this->tracking_scripts ) ) {
			return;
		}

		echo '<script type="text/javascript">' . "\n";
		echo '/* Analytify LearnDash Tracking */' . "\n";
		foreach ( $this->tracking_scripts as $script ) {
			// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Script content is built from trusted plugin code; dynamic values use wp_json_encode.
			echo $script . "\n";
		}
		echo '</script>' . "\n";
	}

	/**
	 * Display notices for LearnDash users.
	 *
	 * @since 1.0.0
	 */
	public function show_admin_notices() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
	}

	/**
	 * Initialize e-commerce JS.
	 */
	public static function add_ga_ecommerce_js() {
		// Only support GA4 - UA/GA3 is deprecated.
		// Set the currency.
		if ( function_exists( 'learndash_get_currency_code' ) ) {
			echo "gtag('set', {currency: '" . esc_js( learndash_get_currency_code() ) . "'});";
		} elseif ( function_exists( 'get_woocommerce_currency' ) ) {
			echo "gtag('set', {currency: '" . esc_js( get_woocommerce_currency() ) . "'});";
		}
	}

	/**
	 * Track purchase transaction.
	 *
	 * @param int $order_id Order ID.
	 * @since 1.0.0
	 * @return void
	 */
	public function track_purchase( $order_id ) {
		if ( ! function_exists( 'wc_get_order' ) ) {
			return;
		}

		$order = wc_get_order( $order_id );

		if ( ! $order || ! $order instanceof WC_Order ) {
			return;
		}

		// Don't track if already tracked.
		if ( 'yes' === get_post_meta( $order_id, '_analytify_ldms_tracked_purchase', true ) ) {
			return;
		}

		// Only track if order is paid.
		if ( ! $order->is_paid() ) {
			return;
		}

		// Check if order contains LearnDash courses.
		$has_learndash_product = false;
		$course_items          = array();

		foreach ( $order->get_items() as $item ) {
			$product_id   = $item->get_product_id();
			$variation_id = $item->get_variation_id();

			// Get course IDs - check variation first, then product.
			$course_ids = array();
			if ( ! empty( $variation_id ) ) {
				$course_ids = get_post_meta( $variation_id, '_related_course', true );
			}
			if ( empty( $course_ids ) ) {
				$course_ids = get_post_meta( $product_id, '_related_course', true );
			}
			// Legacy meta key fallback.
			if ( empty( $course_ids ) ) {
				if ( ! empty( $variation_id ) ) {
					$course_ids = get_post_meta( $variation_id, '_learndash_courses', true );
				}
				if ( empty( $course_ids ) ) {
					$course_ids = get_post_meta( $product_id, '_learndash_courses', true );
				}
			}

			if ( ! empty( $course_ids ) ) {
				$has_learndash_product = true;
				if ( ! is_array( $course_ids ) ) {
					$course_ids = array( $course_ids );
				}

				// Filter out empty/invalid course IDs.
				$course_ids = array_filter(
					$course_ids,
					function ( $course_id ) {
						return ! empty( $course_id ) && is_numeric( $course_id ) && 'sfwd-courses' === get_post_type( $course_id );
					}
				);

				// Get item price (subtotal before discounts, per item).
				$item_price = $item->get_subtotal();
				$quantity   = $item->get_quantity();
				if ( $quantity > 0 ) {
					$item_price = $item_price / $quantity; // Price per unit.
				}

				foreach ( $course_ids as $course_id ) {
					$course_items[] = $this->get_tracked_item_ga4( $course_id, $item_price );
				}
			}
		}

		// Only track if order contains LearnDash courses.
		if ( ! $has_learndash_product || empty( $course_items ) ) {
			return;
		}

		// Only support GA4 - UA/GA3 is deprecated.
		$cookie_data = isset( $_COOKIE ) && is_array( $_COOKIE ) ? $_COOKIE : array();
		$session_id  = $this->analytify_filter_session_id( $cookie_data );

		// Get coupon code from order if available.
		$coupon_code = '';
		if ( method_exists( $order, 'get_coupon_codes' ) ) {
			$coupon_codes = $order->get_coupon_codes();
			$coupon_code  = ! empty( $coupon_codes ) ? implode( ',', $coupon_codes ) : '';
		} elseif ( method_exists( $order, 'get_used_coupons' ) ) {
			$coupon_codes = $order->get_used_coupons();
			$coupon_code  = ! empty( $coupon_codes ) ? implode( ',', $coupon_codes ) : '';
		}

		$currency = function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : 'USD';

		$event[] = array(
			'name'   => 'purchase',
			'params' => array(
				'transaction_id' => $order->get_order_number(),
				'value'          => $order->get_total(),
				'tax'            => $order->get_total_tax(),
				'shipping'       => $order->get_shipping_total(),
				'currency'       => $currency,
				'coupon'         => $coupon_code,
				'user_id'        => $order->get_user_id(),
				'items'          => $course_items,
				'session_id'     => $session_id,
			),
		);

		$this->send_mp_ga4_events( $event );

		update_post_meta( $order_id, '_analytify_ldms_tracked_purchase', 'yes' );
		update_post_meta( $order_id, '_analytify_ldms_tracked_completed_payment', 'yes' );
	}

	/**
	 * Track order completion.
	 *
	 * @param int $order_id Order ID.
	 * @since 1.0.0
	 * @return void
	 */
	public function track_order_complete( $order_id ) {
		if ( ! function_exists( 'wc_get_order' ) ) {
			return;
		}

		$order = wc_get_order( $order_id );

		if ( ! $order || ! $this->is_track_user() ) {
			return;
		}

		// Don't track if already tracked.
		if ( 'yes' === get_post_meta( $order_id, '_analytify_ldms_tracked_completed_payment', true ) ) {
			return;
		}

		// Only support GA4 - UA/GA3 is deprecated.
		$cookie_data = isset( $_COOKIE ) && is_array( $_COOKIE ) ? $_COOKIE : array();
		$session_id  = $this->analytify_filter_session_id( $cookie_data );

		$currency = function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : 'USD';

		$event[] = array(
			'name'   => 'order_created',
			'params' => array(
				'currency'     => $currency,
				'wpa_category' => 'order_id',
				'wpa_label'    => $order_id,
				'session_id'   => $session_id,
			),
		);

		$this->send_mp_ga4_events( $event );
	}

	/**
	 * Track refund.
	 *
	 * @param int      $order_id Order ID.
	 * @param int|null $refund_id Refund ID (for partial refunds via woocommerce_order_refunded hook).
	 * @since 1.0.0
	 * @return void
	 */
	public function track_refund( $order_id, $refund_id = null ) {
		if ( ! function_exists( 'wc_get_order' ) ) {
			return;
		}

		$order = wc_get_order( $order_id );

		if ( ! $order ) {
			return;
		}

		// Check if order contains LearnDash courses.
		$has_learndash_product = false;
		foreach ( $order->get_items() as $item ) {
			$product_id   = $item->get_product_id();
			$variation_id = $item->get_variation_id();

			$course_ids = array();
			if ( ! empty( $variation_id ) ) {
				$course_ids = get_post_meta( $variation_id, '_related_course', true );
			}
			if ( empty( $course_ids ) ) {
				$course_ids = get_post_meta( $product_id, '_related_course', true );
			}

			if ( ! empty( $course_ids ) ) {
				$has_learndash_product = true;
				break;
			}
		}

		// Only track refunds for LearnDash course orders.
		if ( ! $has_learndash_product ) {
			return;
		}

		// For partial refunds, check if we should track (only track once per order unless it's a full refund).
		$refund_meta_key = $refund_id ? '_analytify_ldms_refund_tracked_' . $refund_id : '_analytify_ldms_refund_tracked';

		if ( 'yes' === get_post_meta( $order_id, $refund_meta_key, true ) ) {
			return;
		}

		// Only support GA4 - UA/GA3 is deprecated.
		$cookie_data = isset( $_COOKIE ) && is_array( $_COOKIE ) ? $_COOKIE : array();
		$session_id  = $this->analytify_filter_session_id( $cookie_data );

		$currency = function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : 'USD';

		// Get refund amount if available.
		$refund_amount = 0;
		if ( $refund_id && function_exists( 'wc_get_order' ) ) {
			$refund = wc_get_order( $refund_id );
			if ( $refund && is_a( $refund, 'WC_Order_Refund' ) ) {
				$refund_amount = abs( $refund->get_amount() );
			}
		}
		if ( ! $refund_amount ) {
			$refund_amount = $order->get_total(); // Full refund amount.
		}

		$event[] = array(
			'name'   => 'refund',
			'params' => array(
				'transaction_id' => $order->get_order_number(),
				'value'          => $refund_amount,
				'currency'       => $currency,
				'wpa_category'   => 'transaction_id',
				'wpa_label'      => $order->get_order_number(),
				'user_id'        => $order->get_user_id(),
				'session_id'     => $session_id,
			),
		);

		$this->send_mp_ga4_events( $event );

		update_post_meta( $order_id, $refund_meta_key, 'yes' );
	}

	/**
	 * Track cancelled order.
	 *
	 * @param int $order_id Order ID.
	 * @since 9.0.0
	 * @return void
	 */
	public function track_cancelled( $order_id ) {
		if ( ! function_exists( 'wc_get_order' ) ) {
			return;
		}

		$order = wc_get_order( $order_id );

		if ( ! $order || ! $this->is_track_user() ) {
			return;
		}

		$currency = function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : 'USD';

		// Only support GA4 - UA/GA3 is deprecated.
		$event[] = array(
			'name'   => 'order_cancelled',
			'params' => array(
				'currency'     => $currency,
				'wpa_category' => 'order_id',
				'wpa_label'    => $order_id,
			),
		);

		$this->send_mp_ga4_events( $event );
	}

	/**
	 * Track checkout billing step.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function track_checkout_billing() {
		if ( ! $this->is_track_user() || ! $this->is_ga_enable() ) {
			return;
		}

		if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
			return;
		}

		$items = array();
		foreach ( WC()->cart->get_cart() as $cart_item ) {
			$product_id   = $cart_item['product_id'];
			$variation_id = isset( $cart_item['variation_id'] ) ? $cart_item['variation_id'] : 0;

			// Check if this is a LearnDash course product - check variation first.
			$course_ids = array();
			if ( ! empty( $variation_id ) ) {
				$course_ids = get_post_meta( $variation_id, '_related_course', true );
			}
			if ( empty( $course_ids ) ) {
				$course_ids = get_post_meta( $product_id, '_related_course', true );
			}
			if ( empty( $course_ids ) ) {
				if ( ! empty( $variation_id ) ) {
					$course_ids = get_post_meta( $variation_id, '_learndash_courses', true );
				}
				if ( empty( $course_ids ) ) {
					$course_ids = get_post_meta( $product_id, '_learndash_courses', true );
				}
			}

			if ( ! empty( $course_ids ) ) {
				if ( ! is_array( $course_ids ) ) {
					$course_ids = array( $course_ids );
				}

				// Filter valid course IDs.
				$course_ids = array_filter(
					$course_ids,
					function ( $course_id ) {
						return ! empty( $course_id ) && is_numeric( $course_id ) && 'sfwd-courses' === get_post_type( $course_id );
					}
				);

				$line_total = isset( $cart_item['line_total'] ) ? $cart_item['line_total'] : 0;
				$quantity   = isset( $cart_item['quantity'] ) ? $cart_item['quantity'] : 1;
				$item_price = $quantity > 0 ? ( $line_total / $quantity ) : $line_total;

				foreach ( $course_ids as $course_id ) {
					$items[] = $this->get_tracked_item_ga4( $course_id, $item_price );
				}
			}
		}

		if ( empty( $items ) ) {
			return;
		}

		// Only support GA4 - UA/GA3 is deprecated.
		$cookie_data = isset( $_COOKIE ) && is_array( $_COOKIE ) ? $_COOKIE : array();
		$session_id  = $this->analytify_filter_session_id( $cookie_data );

		$event[] = array(
			'name'   => 'begin_checkout',
			'params' => array(
				'items'      => $items,
				'session_id' => $session_id,
			),
		);

		$this->send_mp_ga4_events( $event );
	}

	/**
	 * Track checkout payment step.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function track_checkout_payment() {
		if ( ! $this->is_track_user() || ! $this->is_ga_enable() ) {
			return;
		}

		if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
			return;
		}

		$items = array();
		foreach ( WC()->cart->get_cart() as $cart_item ) {
			$product_id   = $cart_item['product_id'];
			$variation_id = isset( $cart_item['variation_id'] ) ? $cart_item['variation_id'] : 0;

			// Check if this is a LearnDash course product - check variation first.
			$course_ids = array();
			if ( ! empty( $variation_id ) ) {
				$course_ids = get_post_meta( $variation_id, '_related_course', true );
			}
			if ( empty( $course_ids ) ) {
				$course_ids = get_post_meta( $product_id, '_related_course', true );
			}
			if ( empty( $course_ids ) ) {
				if ( ! empty( $variation_id ) ) {
					$course_ids = get_post_meta( $variation_id, '_learndash_courses', true );
				}
				if ( empty( $course_ids ) ) {
					$course_ids = get_post_meta( $product_id, '_learndash_courses', true );
				}
			}

			if ( ! empty( $course_ids ) ) {
				if ( ! is_array( $course_ids ) ) {
					$course_ids = array( $course_ids );
				}

				// Filter valid course IDs.
				$course_ids = array_filter(
					$course_ids,
					function ( $course_id ) {
						return ! empty( $course_id ) && is_numeric( $course_id ) && 'sfwd-courses' === get_post_type( $course_id );
					}
				);

				$line_total = isset( $cart_item['line_total'] ) ? $cart_item['line_total'] : 0;
				$quantity   = isset( $cart_item['quantity'] ) ? $cart_item['quantity'] : 1;
				$item_price = $quantity > 0 ? ( $line_total / $quantity ) : $line_total;

				foreach ( $course_ids as $course_id ) {
					$items[] = $this->get_tracked_item_ga4( $course_id, $item_price );
				}
			}
		}

		if ( empty( $items ) ) {
			return;
		}

		// Only support GA4 - UA/GA3 is deprecated.
		$cookie_data = isset( $_COOKIE ) && is_array( $_COOKIE ) ? $_COOKIE : array();
		$session_id  = $this->analytify_filter_session_id( $cookie_data );

		$event[] = array(
			'name'   => 'add_payment_info',
			'params' => array(
				'items'      => $items,
				'session_id' => $session_id,
			),
		);

		$this->send_mp_ga4_events( $event );
	}

	/**
	 * Store GA client ID in order meta.
	 *
	 * @param object $order Order object.
	 * @since 1.0.0
	 */
	public function store_ga_identity( $order ) {
		if ( ! function_exists( 'wc_get_order' ) ) {
			return;
		}

		if ( ! is_a( $order, 'WC_Order' ) ) {
			if ( is_numeric( $order ) ) {
				$order = wc_get_order( $order );
			} else {
				return;
			}
		}

		if ( ! $order ) {
			return;
		}

		$order_id = $order->get_id();
		$cid      = $this->get_cid( $order_id );

		// Store client ID in order meta if it is not empty.
		if ( ! empty( $cid ) && is_string( $cid ) ) {
			$cid = trim( $cid );
			update_post_meta( $order_id, 'analytify_ldms_cid', $cid );
		}

		return ! is_string( $cid ) || '' === $cid ? null : $cid;
	}

	/**
	 * Add LearnDash option to dashboard dropdown.
	 *
	 * @since 9.0.0
	 * @return void
	 */
	public function dashboad_dropdown_option() {
		echo '<li><a href="' . esc_url( admin_url( 'admin.php?page=analytify-learndash' ) ) . '">LearnDash</a></li>';
	}

	/**
	 * Add Metabox on order page.
	 *
	 * @since 1.0.0
	 */
	public function source_meta_box() {
		if ( function_exists( 'wc_get_order' ) ) {
			add_meta_box( 'analytify_ldms_source', __( 'Source/Medium', 'wp-analytify-pro' ), array( $this, 'get_source_medium' ), 'shop_order', 'side', 'core' );
		}
	}

	/**
	 * Get Order Source/Medium.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function get_source_medium() {
		global $post;

		if ( ! $post ) {
			return;
		}

		$source = get_post_meta( $post->ID, 'analytify_ldms_order_source', true );
		$source = is_string( $source ) ? sanitize_text_field( $source ) : '';

		if ( '' === $source ) {
			$post_date  = get_the_date( 'Y-m-d', $post->ID );
			$start_date = gmdate( 'Y-m-d', strtotime( $post_date . '-5 days' ) );
			$end_date   = gmdate( 'Y-m-d', strtotime( $post_date . '+5 days' ) );

			// Only support GA4 - UA/GA3 is deprecated.
			$stats = $GLOBALS['WP_ANALYTIFY']->get_reports(
				'analytify_ldms_order_source',
				array(),
				array(
					'start' => $start_date,
					'end'   => $end_date,
				),
				array(
					'sourceMedium',
					'transactionId',
				),
				array(),
				array(
					'logic'   => 'AND',
					'filters' => array(
						array(
							'type'       => 'dimension',
							'name'       => 'transactionId',
							'match_type' => 1,
							'value'      => $post->ID,
						),
					),
				),
				0,
				false
			);

			if ( ! empty( $stats['rows'] ) && is_array( $stats['rows'] ) && ! empty( $stats['rows'][0]['sourceMedium'] ) ) {
				$source = sanitize_text_field( (string) $stats['rows'][0]['sourceMedium'] );
				update_post_meta( $post->ID, 'analytify_ldms_order_source', $source );
			}
		}

		echo esc_html( $source );
	}

	/**
	 * Feed course data for impression tracking.
	 * Only runs on course list/archive pages so wpa_view_course_list fires there only;
	 * on single course pages we skip this and only track wpa_view_course via track_course_view().
	 *
	 * @since 9.0.0
	 * @return void
	 */
	public function feed_course_data() {
		if ( 'gtag' !== ANALYTIFY_PRO_TRACKING_MODE ) {
			return;
		}

		// Do not collect course list on a single course detail page (only track wpa_view_course there).
		if ( is_singular( 'sfwd-courses' ) ) {
			return;
		}

		global $post;

		if ( ! is_a( $post, 'WP_Post' ) || 'sfwd-courses' !== get_post_type( $post ) ) {
			return;
		}

		$course_id = $post->ID;

		$item = $this->get_tracked_item_ga4( $course_id );

		// Append the item to the list.
		$this->course_list[] = $item;
	}

	/**
	 * Print course list data.
	 *
	 * @since 9.0.0
	 * @return void
	 */
	public function print_course_data() {
		// Check of all requirements are filled for tracking.
		$is_tracking_available = WPANALYTIFY_Utils::is_tracking_available( true );

		if ( ! $is_tracking_available || empty( $this->course_list ) ) {
			return;
		}

		// Only support GA4 - UA/GA3 is deprecated.
		$select_event = 'wpa_select_course';

		// Build course list.
		$this->add_inline_js_wpa_ldms( 'const analytify_ldms_course_list = {' );
		foreach ( $this->course_list as $course ) {
			$id = isset( $course['item_id'] ) ? $course['item_id'] : ( isset( $course['id'] ) ? $course['id'] : 0 );
			if ( $id ) {
				$this->add_inline_js_wpa_ldms( " 'item_" . $id . "' : " . wp_json_encode( $course ) . ',' );
			}
		}
		$this->add_inline_js_wpa_ldms( '};' );

		foreach ( $this->course_list as $course ) {
			$id = isset( $course['item_id'] ) ? $course['item_id'] : ( isset( $course['id'] ) ? $course['id'] : 0 );
			if ( ! $id ) {
				continue;
			}

			$currency_raw = function_exists( 'learndash_get_currency_code' ) ? learndash_get_currency_code() : ( function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : 'USD' );
			$currency     = sanitize_text_field( $currency_raw );

			$post_name           = get_post_field( 'post_name', $id );
			$sanitized_post_name = ! empty( $post_name ) ? esc_js( $post_name ) : '';
			$this->add_inline_js_wpa_ldms(
				"
			jQuery( 'body' ).on( 'click', '.learndash-course-item.post-" . absint( $id ) . ' a, .course-item.post-' . absint( $id ) . ' a, a[href*="sfwd-courses/' . $sanitized_post_name . "\"]', function() {
				gtag( 'event', '" . $select_event . "', {
					content_type : 'course',
					value: 0,
					currency: '" . $currency . "',
					wpa_label: '" . esc_js( get_the_title( $id ) ) . "',
					items: analytify_ldms_course_list.item_" . $id . '
				} );
			});
			'
			);
		}

		$currency = function_exists( 'learndash_get_currency_code' ) ? learndash_get_currency_code() : ( function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : 'USD' );

		$this->add_inline_js_wpa_ldms(
			"
			gtag('event', 'wpa_view_course_list', {
				value: 0,
				currency: '" . $currency . "',
				wpa_label: 'Course List',
				items: Object.values(analytify_ldms_course_list)
			});
		"
		);
	}

	/**
	 * Change Install GA text.
	 *
	 * @since 1.0.0
	 */
	public function install_ga_text() {
		return __( 'Insert Google Analytics (GA) JavaScript code between the HEADER tags in your website. Check this option if you have installed Analytify E-Commerce add-ons for E-commerce Tracking.', 'wp-analytify-pro' );
	}

	/**
	 * Add option in admin bar.
	 *
	 * @param array $menus Menus.
	 *
	 * @since 1.0.0
	 */
	public function add_admin_bar_menu( $menus ) {
		$menus['analytify-learndash'] = __( 'LearnDash', 'wp-analytify-pro' );
		return $menus;
	}

	/**
	 * Delete LearnDash transients.
	 *
	 * @param string $profile_id Profile ID.
	 * @param string $start_date Start date.
	 * @param string $end_date End date.
	 * @since 9.0.0
	 * @return void
	 */
	public static function delete_learndash_transients( $profile_id, $start_date, $end_date ) {
		$transients = array(
			'analytify_learndash_general_stats_' . $profile_id . '_' . $start_date . '_' . $end_date,
			'analytify_learndash_course_performance_' . $profile_id . '_' . $start_date . '_' . $end_date,
			'analytify_learndash_lesson_performance_' . $profile_id . '_' . $start_date . '_' . $end_date,
			'analytify_learndash_quiz_performance_' . $profile_id . '_' . $start_date . '_' . $end_date,
		);

		foreach ( $transients as $transient ) {
			delete_transient( $transient );
		}
	}
}
