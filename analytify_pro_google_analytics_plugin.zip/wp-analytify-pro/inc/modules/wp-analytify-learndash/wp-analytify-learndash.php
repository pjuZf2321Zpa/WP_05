<?php
/**
 * LearnDash addon loader.
 *
 * @package WP_Analytify_Pro
 */

// phpcs:ignoreFile WordPress.Files.FileName.InvalidClassFileName

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// Load the loader class.
require_once __DIR__ . '/class-analytify-learndash-loader.php';

// Initialize the loader.
Analytify_LearnDash_Loader::get_instance();
