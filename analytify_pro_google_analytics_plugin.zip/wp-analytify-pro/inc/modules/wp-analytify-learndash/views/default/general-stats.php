<?php
/**
 * LearnDash General Stats Report View
 *
 * @package WP_Analytify_Pro
 */

/**
 * General stats for LearnDash.
 *
 * @param object $current     WP_Analytify instance.
 * @param array  $raw_stats   Stats from GA4.
 * @since 9.0.0
 * @return void
 */
function ldms_analytify_general_stats( $current, $raw_stats ) {

	ob_start();

	$sessions        = isset( $raw_stats['aggregations']['sessions'] ) ? $raw_stats['aggregations']['sessions'] : 0;
	$transactions    = isset( $raw_stats['aggregations']['transactions'] ) ? $raw_stats['aggregations']['transactions'] : 0;
	$conversion_rate = $sessions > 0 ? ( $transactions / $sessions ) * 100 : 0;

	if ( isset( $raw_stats['currencyCode'] ) && '(not set)' !== $raw_stats['currencyCode'] ) {
		$currency_code = $raw_stats['currencyCode'];
	} elseif ( function_exists( 'learndash_get_currency_code' ) ) {
		$currency_code = learndash_get_currency_code();
	} elseif ( function_exists( 'get_woocommerce_currency' ) ) {
		$currency_code = get_woocommerce_currency();
	} else {
		$currency_code = 'USD';
	}

	if ( function_exists( 'learndash_get_currency_symbol' ) ) {
		$currency_symbol = learndash_get_currency_symbol( $currency_code );
	} elseif ( function_exists( 'get_woocommerce_currency_symbol' ) ) {
		$currency_symbol = get_woocommerce_currency_symbol( $currency_code );
	} else {
		$currency_symbol = '$';
	}

	$refunds         = isset( $raw_stats['aggregations']['refunds'] ) ? (int) $raw_stats['aggregations']['refunds'] : 0;
	$refund_rate     = isset( $raw_stats['aggregations']['refundRate'] ) ? (float) $raw_stats['aggregations']['refundRate'] : 0;
	$sessions_to_txn = isset( $raw_stats['aggregations']['sessionsToTransaction'] ) ? (float) $raw_stats['aggregations']['sessionsToTransaction'] : 0;
	$days_to_txn     = isset( $raw_stats['aggregations']['daysToTransaction'] ) ? (float) $raw_stats['aggregations']['daysToTransaction'] : 0;

	$boxes = array(
		'transactions'         => array(
			'label'       => esc_html__( 'Transactions', 'wp-analytify-pro' ),
			'value'       => isset( $raw_stats['aggregations']['transactions'] ) ? number_format( $raw_stats['aggregations']['transactions'] ) : 0,
			'description' => esc_html__( 'Total number of completed course purchases.', 'wp-analytify-pro' ),
		),
		'revenue'              => array(
			'label'       => esc_html__( 'Transaction Revenue', 'wp-analytify-pro' ),
			'value'       => isset( $raw_stats['aggregations']['purchaseRevenue'] ) ? $currency_symbol . number_format( $raw_stats['aggregations']['purchaseRevenue'], 2 ) : $currency_symbol . '0.00',
			'description' => esc_html__( 'Total revenue from course purchases.', 'wp-analytify-pro' ),
		),
		'average_order_value'  => array(
			'label'       => esc_html__( 'Average Order Value', 'wp-analytify-pro' ),
			'value'       => isset( $raw_stats['aggregations']['averagePurchaseRevenue'] ) ? $currency_symbol . number_format( $raw_stats['aggregations']['averagePurchaseRevenue'], 2 ) : $currency_symbol . '0.00',
			'description' => esc_html__( 'Average value per transaction.', 'wp-analytify-pro' ),
		),
		'purchases'            => array(
			'label'       => esc_html__( 'Completed Purchases', 'wp-analytify-pro' ),
			'value'       => isset( $raw_stats['aggregations']['ecommercePurchases'] ) ? number_format( $raw_stats['aggregations']['ecommercePurchases'] ) : 0,
			'description' => esc_html__( 'Number of times users completed a purchase.', 'wp-analytify-pro' ),
		),
		'refunds'              => array(
			'label'       => esc_html__( 'Refunds', 'wp-analytify-pro' ),
			'value'       => number_format( $refunds ),
			'description' => esc_html__( 'Total number of refunds.', 'wp-analytify-pro' ),
		),
		'conversion_rate'      => array(
			'label'       => esc_html__( 'Conversion Rate', 'wp-analytify-pro' ),
			'value'       => number_format( $conversion_rate, 2 ) . '%',
			'description' => esc_html__( 'Percentage of sessions resulting in a transaction.', 'wp-analytify-pro' ),
		),
		'refund_rate'          => array(
			'label'       => esc_html__( 'Refund Rate', 'wp-analytify-pro' ),
			'value'       => number_format( $refund_rate, 2 ) . '%',
			'description' => esc_html__( 'Percentage of transactions that were refunded.', 'wp-analytify-pro' ),
		),
		'sessions_to_purchase' => array(
			'label'       => esc_html__( 'Sessions to Purchase', 'wp-analytify-pro' ),
			'value'       => number_format( $sessions_to_txn, 1 ),
			'description' => esc_html__( 'Average sessions per user before purchase.', 'wp-analytify-pro' ),
		),
		'days_to_purchase'     => array(
			'label'       => esc_html__( 'Days to Purchase', 'wp-analytify-pro' ),
			'value'       => number_format( $days_to_txn, 1 ),
			'description' => esc_html__( 'Average days from first visit to purchase.', 'wp-analytify-pro' ),
		),
	);

	?>
	<div class="analytify_general_status analytify_status_box_wraper">

		<div class="analytify_status_header">
			<h3><?php esc_html_e( 'Overview', 'wp-analytify-pro' ); ?></h3>
		</div>

		<div class="analytify_status_body">
			<div class="analytify_general_status_boxes_wraper">

				<?php foreach ( $boxes as $box ) { ?>
				<div class="analytify_general_status_boxes">
					<h4><?php echo esc_html( $box['label'] ); ?></h4>
					<div class="analytify_general_stats_value"><?php echo esc_html( $box['value'] ); ?></div>
					<p><?php echo esc_html( $box['description'] ); ?></p>
				</div>
				<?php } ?>

			</div>
		</div>

	</div>

	<?php
	wp_send_json(
		array(
			'body' => ob_get_clean(),
		)
	);
}
