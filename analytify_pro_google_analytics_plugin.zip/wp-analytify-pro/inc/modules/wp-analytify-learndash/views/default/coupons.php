<?php
/**
 * LearnDash Coupons Report View
 *
 * @package WP_Analytify_Pro
 */

/**
 * Coupons report for LearnDash.
 *
 * @param object $current     WP_Analytify instance.
 * @param array  $raw_stats   Stats from GA4.
 * @since 9.0.0
 * @return void
 */
function ldms_analytify_coupons( $current, $raw_stats ) {

	ob_start();

	if ( isset( $raw_stats['currencyCode'] ) && '(not set)' !== $raw_stats['currencyCode'] ) {
		$currency_code = $raw_stats['currencyCode'];
	} elseif ( function_exists( 'learndash_get_currency_code' ) ) {
		$currency_code = learndash_get_currency_code();
	} elseif ( function_exists( 'get_woocommerce_currency' ) ) {
		$currency_code = get_woocommerce_currency();
	} else {
		$currency_code = 'USD';
	}

	if ( function_exists( 'learndash_get_currency_symbol' ) ) {
		$currency_symbol = learndash_get_currency_symbol( $currency_code );
	} elseif ( function_exists( 'get_woocommerce_currency_symbol' ) ) {
		$currency_symbol = get_woocommerce_currency_symbol( $currency_code );
	} else {
		$currency_symbol = '$';
	}

	?>
	<div class="analytify_general_status analytify_status_box_wraper">

		<div class="analytify_status_header">
			<h3><?php esc_html_e( 'Coupons Performance', 'wp-analytify-pro' ); ?></h3>
		</div>

		<div class="analytify_status_body">
			<table class="analytify_data_tables wp_analytify_paginated" data-product-per-page="10">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Coupon Code', 'wp-analytify-pro' ); ?></th>
						<th><?php esc_html_e( 'Uses', 'wp-analytify-pro' ); ?></th>
						<th><?php esc_html_e( 'Revenue', 'wp-analytify-pro' ); ?></th>
						<th><?php esc_html_e( 'Discount Amount', 'wp-analytify-pro' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php if ( ! empty( $raw_stats['rows'] ) ) : ?>
						<?php foreach ( $raw_stats['rows'] as $row ) : ?>
							<?php
							$coupon_code = isset( $row['couponCode'] ) ? $row['couponCode'] : __( '(not set)', 'wp-analytify-pro' );
							$uses        = isset( $row['couponUses'] ) ? number_format( $row['couponUses'] ) : 0;
							$revenue     = isset( $row['couponRevenue'] ) ? $currency_symbol . number_format( $row['couponRevenue'], 2 ) : $currency_symbol . '0.00';
							$discount    = isset( $row['discountAmount'] ) ? $currency_symbol . number_format( $row['discountAmount'], 2 ) : $currency_symbol . '0.00';
							?>
							<tr>
								<td><?php echo esc_html( $coupon_code ); ?></td>
								<td><?php echo esc_html( $uses ); ?></td>
								<td><?php echo esc_html( $revenue ); ?></td>
								<td><?php echo esc_html( $discount ); ?></td>
							</tr>
						<?php endforeach; ?>
					<?php else : ?>
						<tr>
							<td class="analytify_td_error_msg" colspan="4">
								<?php $current->no_records(); ?>
							</td>
						</tr>
					<?php endif; ?>
				</tbody>
			</table>
		</div>

	</div>

	<?php
	wp_send_json(
		array(
			'body' => ob_get_clean(),
		)
	);
}
