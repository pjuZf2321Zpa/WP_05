<?php
/**
 * LearnDash Checkout Funnel Report View
 *
 * @package WP_Analytify_Pro
 */

/**
 * Checkout funnel view.
 *
 * @param object $current WP_Analytify instance.
 * @param array  $steps   Funnel steps counts.
 * @since 9.0.0
 * @return void
 */
function ldms_analytify_funnel( $current, $steps ) {

	$begin    = isset( $steps['begin_checkout'] ) ? (int) $steps['begin_checkout'] : 0;
	$payment  = isset( $steps['add_payment_info'] ) ? (int) $steps['add_payment_info'] : 0;
	$purchase = isset( $steps['purchase'] ) ? (int) $steps['purchase'] : 0;

	$conversion_rates = array(
		'Checkout to Payment' => ( $begin > 0 ) ? round( ( $payment / $begin ) * 100, 2 ) : 0,
		'Payment to Purchase' => ( $payment > 0 ) ? round( ( $purchase / $payment ) * 100, 2 ) : 0,
	);

	$abandonment_rates = array(
		'Checkout Abandonment' => ( $begin > 0 )
			? max( 0, round( ( ( $begin - $payment ) / $begin ) * 100, 2 ) )
			: 0,
		'Payment Abandonment'  => ( $payment > 0 )
			? max( 0, round( ( ( $payment - $purchase ) / $payment ) * 100, 2 ) )
			: 0,
	);

	$data = array(
		array(
			'value'     => 1500,
			'name'      => 'Begin Checkout',
			'itemStyle' => array( 'color' => '#f5a623' ),
			'actual'    => $begin,
		),
		array(
			'value'     => 1000,
			'name'      => 'Add Payment Info',
			'itemStyle' => array( 'color' => '#7ed321' ),
			'actual'    => $payment,
		),
		array(
			'value'     => 500,
			'name'      => 'Purchase',
			'itemStyle' => array( 'color' => '#4a90e2' ),
			'actual'    => $purchase,
		),
	);

	ob_start();
	?>

	<div class="analytify_general_status analytify_status_box_wraper">
		<div class="analytify_status_header">
			<h3><?php esc_html_e( 'LearnDash Funnel', 'wp-analytify-pro' ); ?></h3>
		</div>

		<table class="analytify_data_tables">
			<thead>
				<tr>
					<th class="no-header"></th>
					<th class="right-align header-center">
						<?php esc_html_e( 'Conversion Rate by Stages', 'wp-analytify-pro' ); ?>
					</th>
					<th class="right-align header-center">
						<?php esc_html_e( 'Abandonment Rate', 'wp-analytify-pro' ); ?>
					</th>
				</tr>
			</thead>
		</table>

		<div class="analytify_status_body">
			<div class="funnel-wrapper">
				<div class="analytify-funnel-chart-container">
					<div class="analytify-funnel-chart">
						<div id="analytify-ldms-funnel-chart"></div>
					</div>

					<div class="conversion-rates">
						<p class="checkout-conversion">
							<?php echo esc_html( number_format_i18n( $conversion_rates['Checkout to Payment'], 2 ) . '%' ); ?>
						</p>
						<p class="payment-conversion">
							<?php echo esc_html( number_format_i18n( $conversion_rates['Payment to Purchase'], 2 ) . '%' ); ?>
						</p>
					</div>

					<div class="abandonment-rates">
						<p class="checkout-abandonment">
							<?php echo esc_html( number_format_i18n( $abandonment_rates['Checkout Abandonment'], 2 ) . '%' ); ?>
						</p>
						<p class="payment-abandonment">
							<?php echo esc_html( number_format_i18n( $abandonment_rates['Payment Abandonment'], 2 ) . '%' ); ?>
						</p>
					</div>
				</div>
			</div>
		</div>
	</div>

	<script type="text/javascript">
		function initLearnDashFunnel() {
			// Check if ECharts is available
			if (typeof echarts === 'undefined') {
				setTimeout(initLearnDashFunnel, 1000);
				return;
			}
			
			var analytify_ldms_funnel_chartId = document.getElementById('analytify-ldms-funnel-chart');
			if (!analytify_ldms_funnel_chartId) {
				return;
			}
			
			try {
				var analytify_ldms_chart = echarts.init(analytify_ldms_funnel_chartId);

				// Dynamic data from PHP
				var funnelData = <?php echo wp_json_encode( $data ); ?>;

				var option = {
					series: [
						{
							name: 'Conversion Rate',
							type: 'funnel',
							left: '10%',
							top: 20,
							bottom: 20,
							width: '80%',
							min: 0,
							max: 1500,
							minSize: '0%',
							maxSize: '100%',
							sort: 'descending',
							gap: 10,
							label: {
								show: true,
								position: 'inside',
								formatter: function (params) {
									return `${params.name}\n${params.data.actual}`;
								},
								color: '#fff',
								fontSize: 17
							},
							labelLine: {
								show: true,
								length: 30,
								lineStyle: {
									type: 'dashed',
									color: '#aaa',
								},
							},
							itemStyle: {
								borderColor: '#fff',
								borderWidth: 2,
								borderRadius: 8,
							},
							emphasis: {
								label: {
									fontSize: 19,
								},
							},
							data: funnelData,
						},
					],
				};

				analytify_ldms_chart.setOption(option);
				
				window.addEventListener('resize', function () {
					analytify_ldms_chart.resize();
				});
			} catch (error) {
				// Silent error handling
			}
		}

		// Try to initialize immediately
		initLearnDashFunnel();
		
		// Also try after DOM is ready
		document.addEventListener("DOMContentLoaded", function () {
			initLearnDashFunnel();
		});
	</script>

	<?php

	wp_send_json( array( 'body' => ob_get_clean() ) );
}
