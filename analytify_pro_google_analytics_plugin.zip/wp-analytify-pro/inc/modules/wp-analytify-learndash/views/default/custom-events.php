<?php
/**
 * Custom Events View for LearnDash.
 *
 * @package Analytify
 */

if ( ! function_exists( 'ldms_analytify_custom_events' ) ) {

	/**
	 * Display custom events statistics.
	 *
	 * @param object $current WP_Analytify instance.
	 * @param array  $raw_stats Raw statistics data from GA4.
	 * @since 9.0.0
	 * @return void
	 */
	function ldms_analytify_custom_events( $current, $raw_stats ) {

		ob_start();

		?>

		<div class="analytify_general_status analytify_status_box_wraper">
			<div class="analytify_status_header">
				<h3><?php esc_html_e( 'LearnDash Activity Tracking', 'wp-analytify-pro' ); ?></h3>
			</div>
			<div class="analytify_status_body">
				<table class="analytify_data_tables wp_analytify_paginated" data-product-per-page="10">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Event Name', 'wp-analytify-pro' ); ?></th>
							<th><?php esc_html_e( 'Event Count', 'wp-analytify-pro' ); ?></th>
							<th><?php esc_html_e( 'Unique Events', 'wp-analytify-pro' ); ?></th>
							<th><?php esc_html_e( 'Event Value', 'wp-analytify-pro' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php if ( ! empty( $raw_stats['rows'] ) ) : ?>
							<?php foreach ( $raw_stats['rows'] as $row ) : ?>
								<?php
								$event_name    = isset( $row['eventName'] ) ? $row['eventName'] : __( '(not set)', 'wp-analytify-pro' );
								$event_count   = isset( $row['eventCount'] ) ? number_format( $row['eventCount'] ) : 0;
								$unique_events = isset( $row['eventCountPerUser'] ) ? number_format( $row['eventCountPerUser'] ) : 0;
								$event_value   = isset( $row['eventValue'] ) ? number_format( $row['eventValue'], 2 ) : '0.00';
								?>
							<tr>
								<td><?php echo esc_html( $event_name ); ?></td>
								<td><?php echo esc_html( $event_count ); ?></td>
								<td><?php echo esc_html( $unique_events ); ?></td>
								<td><?php echo esc_html( $event_value ); ?></td>
							</tr>
							<?php endforeach; ?>
						<?php else : ?>
							<tr>
								<td class="analytify_td_error_msg" colspan="4">
									<?php $current->no_records(); ?>
								</td>
							</tr>
						<?php endif; ?>
					</tbody>
				</table>
			</div>
		</div>

		<?php
		wp_send_json(
			array(
				'body' => ob_get_clean(),
			)
		);
	}
}
