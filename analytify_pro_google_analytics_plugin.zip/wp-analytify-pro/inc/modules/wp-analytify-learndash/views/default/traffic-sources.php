<?php
/**
 * LearnDash Traffic Sources Report View
 *
 * @package WP_Analytify_Pro
 */

/**
 * Traffic sources report for LearnDash.
 *
 * @param object $current          WP_Analytify instance.
 * @param array  $raw_stats        Stats from GA4.
 * @param string $report_url       Report URL.
 * @param string $report_date_range Report date range.
 * @since 9.0.0
 * @return void
 */
function ldms_analytify_traffic_sources( $current, $raw_stats, $report_url = '', $report_date_range = '' ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed

	ob_start();

	if ( isset( $raw_stats['currencyCode'] ) && '(not set)' !== $raw_stats['currencyCode'] ) {
		$currency_code = $raw_stats['currencyCode'];
	} elseif ( function_exists( 'learndash_get_currency_code' ) ) {
		$currency_code = learndash_get_currency_code();
	} elseif ( function_exists( 'get_woocommerce_currency' ) ) {
		$currency_code = get_woocommerce_currency();
	} else {
		$currency_code = 'USD';
	}

	if ( function_exists( 'learndash_get_currency_symbol' ) ) {
		$currency_symbol = learndash_get_currency_symbol( $currency_code );
	} elseif ( function_exists( 'get_woocommerce_currency_symbol' ) ) {
		$currency_symbol = get_woocommerce_currency_symbol( $currency_code );
	} else {
		$currency_symbol = '$';
	}

	?>
	<div class="analytify_general_status analytify_status_box_wraper">

		<div class="analytify_status_header">
			<h3><?php esc_html_e( 'Top Traffic Sources', 'wp-analytify-pro' ); ?></h3>
		</div>

		<div class="analytify_status_body">
			<table class="analytify_data_tables wp_analytify_paginated" data-product-per-page="10">
				<thead>
					<tr>
						<th class="analytify_table_header_no_events">#</th>
						<th><?php esc_html_e( 'Source/Medium', 'wp-analytify-pro' ); ?></th>
						<th><?php esc_html_e( 'Sessions', 'wp-analytify-pro' ); ?></th>
						<th><?php esc_html_e( 'Bounce Rate', 'wp-analytify-pro' ); ?></th>
						<th><?php esc_html_e( 'Transactions Revenue', 'wp-analytify-pro' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php if ( ! empty( $raw_stats['rows'] ) ) : ?>
						<?php
						$i = 0;
						foreach ( $raw_stats['rows'] as $row ) :
								++$i;
								$source_medium = isset( $row['sourceMedium'] ) ? $row['sourceMedium'] : __( '(not set)', 'wp-analytify-pro' );
								$sessions      = isset( $row['sessions'] ) ? $row['sessions'] : 0;
								$bounce_rate   = isset( $row['bounceRate'] ) ? $row['bounceRate'] : 0;
								$revenue       = isset( $row['purchaseRevenue'] ) ? $row['purchaseRevenue'] : 0;
							if ( isset( $row['currencyCode'] ) && '(not set)' !== $row['currencyCode'] ) {
								$row_currency_code = $row['currencyCode'];
							} elseif ( function_exists( 'learndash_get_currency_code' ) ) {
								$row_currency_code = learndash_get_currency_code();
							} elseif ( function_exists( 'get_woocommerce_currency' ) ) {
								$row_currency_code = get_woocommerce_currency();
							} else {
								$row_currency_code = 'USD';
							}
							?>
								<tr>
									<td><?php echo esc_html( $i ); ?></td>
									<td><?php echo esc_html( $source_medium ); ?></td>
									<td class="analytify_txt_center"><?php echo esc_html( WPANALYTIFY_Utils::pretty_numbers( $sessions ) ); ?></td>
									<td class="analytify_txt_center"><?php echo esc_html( WPANALYTIFY_Utils::pretty_numbers( $bounce_rate ) . '%' ); ?></td>
									<td class="analytify_txt_center">
										<?php
										if ( function_exists( 'learndash_get_currency_symbol' ) ) {
											$row_currency_symbol = learndash_get_currency_symbol( $row_currency_code );
										} elseif ( function_exists( 'get_woocommerce_currency_symbol' ) ) {
											$row_currency_symbol = get_woocommerce_currency_symbol( $row_currency_code );
										} else {
											$row_currency_symbol = '$';
										}
										echo esc_html( $row_currency_symbol . number_format( $revenue, 2 ) );
										?>
									</td>
								</tr>
						<?php endforeach; ?>
					<?php else : ?>
						<tr>
							<td class="analytify_td_error_msg" colspan="5">
								<?php $current->no_records(); ?>
							</td>
						</tr>
					<?php endif; ?>
				</tbody>
			</table>
		</div>

	</div>

	<?php
	wp_send_json(
		array(
			'body' => ob_get_clean(),
		)
	);
}
