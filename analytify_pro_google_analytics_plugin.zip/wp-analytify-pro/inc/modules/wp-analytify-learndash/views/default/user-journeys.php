<?php
/**
 * LearnDash User Journeys Report View
 *
 * @package WP_Analytify_Pro
 */

/**
 * User journeys report for LearnDash.
 *
 * @param object $current     WP_Analytify instance.
 * @param array  $raw_stats   Stats from GA4.
 * @since 9.0.0
 * @return void
 */
function ldms_analytify_user_journeys( $current, $raw_stats ) {

	ob_start();

	?>
	<div class="analytify_general_status analytify_status_box_wraper">

		<div class="analytify_status_header">
			<h3><?php esc_html_e( 'User Journeys', 'wp-analytify-pro' ); ?></h3>
		</div>

		<div class="analytify_status_body">
			<table class="analytify_data_tables wp_analytify_paginated" data-product-per-page="10">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Page Title', 'wp-analytify-pro' ); ?></th>
						<th><?php esc_html_e( 'Page Path', 'wp-analytify-pro' ); ?></th>
						<th><?php esc_html_e( 'Pageviews', 'wp-analytify-pro' ); ?></th>
						<th><?php esc_html_e( 'Sessions', 'wp-analytify-pro' ); ?></th>
						<th><?php esc_html_e( 'Avg. Duration', 'wp-analytify-pro' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php if ( ! empty( $raw_stats['rows'] ) ) : ?>
						<?php foreach ( $raw_stats['rows'] as $row ) : ?>
							<?php
							$page_title   = isset( $row['pageTitle'] ) ? $row['pageTitle'] : __( '(not set)', 'wp-analytify-pro' );
							$page_path    = isset( $row['pagePath'] ) ? $row['pagePath'] : '/';
							$pageviews    = isset( $row['screenPageViews'] ) ? number_format( $row['screenPageViews'] ) : 0;
							$sessions     = isset( $row['sessions'] ) ? number_format( $row['sessions'] ) : 0;
							$avg_duration = isset( $row['averageSessionDuration'] ) ? gmdate( 'i:s', (int) $row['averageSessionDuration'] ) : '00:00';
							?>
							<tr>
								<td><?php echo esc_html( $page_title ); ?></td>
								<td><?php echo esc_html( $page_path ); ?></td>
								<td><?php echo esc_html( $pageviews ); ?></td>
								<td><?php echo esc_html( $sessions ); ?></td>
								<td><?php echo esc_html( $avg_duration ); ?></td>
							</tr>
						<?php endforeach; ?>
					<?php else : ?>
						<tr>
							<td class="analytify_td_error_msg" colspan="5">
								<?php $current->no_records(); ?>
							</td>
						</tr>
					<?php endif; ?>
				</tbody>
			</table>
		</div>

	</div>

	<?php
	wp_send_json(
		array(
			'body' => ob_get_clean(),
		)
	);
}
