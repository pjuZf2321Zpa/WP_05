<?php
/**
 * LearnDash Top Courses Report View
 *
 * @package WP_Analytify_Pro
 */

/**
 * Top courses report for LearnDash.
 *
 * @param object $current     WP_Analytify instance.
 * @param array  $raw_stats   Stats from GA4.
 * @since 9.0.0
 * @return void
 */
function ldms_analytify_top_courses( $current, $raw_stats ) {

	ob_start();

	if ( isset( $raw_stats['currencyCode'] ) && '(not set)' !== $raw_stats['currencyCode'] ) {
		$currency_code = $raw_stats['currencyCode'];
	} elseif ( function_exists( 'learndash_get_currency_code' ) ) {
		$currency_code = learndash_get_currency_code();
	} elseif ( function_exists( 'get_woocommerce_currency' ) ) {
		$currency_code = get_woocommerce_currency();
	} else {
		$currency_code = 'USD';
	}

	if ( function_exists( 'learndash_get_currency_symbol' ) ) {
		$currency_symbol = learndash_get_currency_symbol( $currency_code );
	} elseif ( function_exists( 'get_woocommerce_currency_symbol' ) ) {
		$currency_symbol = get_woocommerce_currency_symbol( $currency_code );
	} else {
		$currency_symbol = '$';
	}

	?>
	<div class="analytify_general_status analytify_status_box_wraper">

		<div class="analytify_status_header">
			<h3><?php esc_html_e( 'Top Courses', 'wp-analytify-pro' ); ?></h3>
		</div>

		<div class="analytify_status_body">
			<table class="analytify_data_tables wp_analytify_paginated" data-product-per-page="10">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Course Name', 'wp-analytify-pro' ); ?></th>
						<th><?php esc_html_e( 'Revenue', 'wp-analytify-pro' ); ?></th>
						<th><?php esc_html_e( 'Purchases', 'wp-analytify-pro' ); ?></th>
						<th><?php esc_html_e( 'Views', 'wp-analytify-pro' ); ?></th>
						<th><?php esc_html_e( 'Conversion Rate', 'wp-analytify-pro' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php if ( ! empty( $raw_stats['rows'] ) ) : ?>
						<?php foreach ( $raw_stats['rows'] as $row ) : ?>
							<?php
							$course_name = isset( $row['itemName'] ) ? $row['itemName'] : __( '(not set)', 'wp-analytify-pro' );
							$revenue     = isset( $row['itemRevenue'] ) ? $currency_symbol . number_format( $row['itemRevenue'], 2 ) : $currency_symbol . '0.00';
							$purchases   = isset( $row['itemsPurchased'] ) ? number_format( $row['itemsPurchased'] ) : 0;
							$views       = isset( $row['itemsViewed'] ) ? number_format( $row['itemsViewed'] ) : 0;
							$cart_rate   = isset( $row['cartToViewRate'] ) ? number_format( $row['cartToViewRate'] * 100, 2 ) . '%' : '0.00%';
							?>
							<tr>
								<td><?php echo esc_html( $course_name ); ?></td>
								<td><?php echo esc_html( $revenue ); ?></td>
								<td><?php echo esc_html( $purchases ); ?></td>
								<td><?php echo esc_html( $views ); ?></td>
								<td><?php echo esc_html( $cart_rate ); ?></td>
							</tr>
						<?php endforeach; ?>
					<?php else : ?>
						<tr>
							<td class="analytify_td_error_msg" colspan="5">
								<?php $current->no_records(); ?>
							</td>
						</tr>
					<?php endif; ?>
				</tbody>
			</table>
		</div>

	</div>

	<?php
	wp_send_json(
		array(
			'body' => ob_get_clean(),
		)
	);
}
