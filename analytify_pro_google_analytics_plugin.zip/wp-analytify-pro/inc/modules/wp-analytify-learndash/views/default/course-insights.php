<?php
/**
 * LearnDash Course Insights Report View
 *
 * @package WP_Analytify_Pro
 */

/**
 * Course insights report for LearnDash.
 *
 * @param object $current     WP_Analytify instance.
 * @param array  $raw_stats   Stats from GA4.
 * @since 9.0.0
 * @return void
 */
function ldms_analytify_course_insights( $current, $raw_stats ) {

	ob_start();

	?>
	<div class="analytify_general_status analytify_status_box_wraper">

		<div class="analytify_status_header">
			<h3><?php esc_html_e( 'Course Insights', 'wp-analytify-pro' ); ?></h3>
		</div>

		<div class="analytify_status_body">
			<table class="analytify_data_tables wp_analytify_paginated" data-product-per-page="10">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Course', 'wp-analytify-pro' ); ?></th>
						<th><?php esc_html_e( 'Enrollments', 'wp-analytify-pro' ); ?></th>
						<th><?php esc_html_e( 'Completions', 'wp-analytify-pro' ); ?></th>
						<th><?php esc_html_e( 'Completion Rate', 'wp-analytify-pro' ); ?></th>
						<th><?php esc_html_e( 'Avg. Progress', 'wp-analytify-pro' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php if ( ! empty( $raw_stats['rows'] ) ) : ?>
						<?php foreach ( $raw_stats['rows'] as $row ) : ?>
							<?php
							$course_name     = isset( $row['courseName'] ) ? $row['courseName'] : __( '(not set)', 'wp-analytify-pro' );
							$enrollments     = isset( $row['enrollments'] ) ? number_format( $row['enrollments'] ) : 0;
							$completions     = isset( $row['completions'] ) ? number_format( $row['completions'] ) : 0;
							$completion_rate = isset( $row['completionRate'] ) ? number_format( $row['completionRate'], 2 ) . '%' : '0.00%';
							$avg_progress    = isset( $row['averageProgress'] ) ? number_format( $row['averageProgress'], 1 ) . '%' : '0.0%';
							?>
							<tr>
								<td><?php echo esc_html( $course_name ); ?></td>
								<td><?php echo esc_html( $enrollments ); ?></td>
								<td><?php echo esc_html( $completions ); ?></td>
								<td><?php echo esc_html( $completion_rate ); ?></td>
								<td><?php echo esc_html( $avg_progress ); ?></td>
							</tr>
						<?php endforeach; ?>
					<?php else : ?>
						<tr>
							<td class="analytify_td_error_msg" colspan="5">
								<?php $current->no_records(); ?>
							</td>
						</tr>
					<?php endif; ?>
				</tbody>
			</table>
		</div>

	</div>

	<?php
	wp_send_json(
		array(
			'body' => ob_get_clean(),
		)
	);
}
