<?php
/**
 * LearnDash Integration Loader for Analytify.
 *
 * @package    Analytify
 * @subpackage LearnDash
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Analytify LearnDash Loader Class.
 */
class Analytify_LearnDash_Loader {

	/**
	 * Instance of this class.
	 *
	 * @var object
	 */
	public static $instance;

	/**
	 * Asset cache-bust string (matches Analytify Pro when loaded as a Pro module).
	 *
	 * @var string
	 */
	public $version;

	/**
	 * Get the singleton instance.
	 *
	 * @since 1.0.0
	 * @return Analytify_LearnDash_Loader
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		$this->define_constants();
		$this->version = defined( 'ANALYTIFY_PRO_VERSION' ) ? ANALYTIFY_PRO_VERSION : ( defined( 'ANALYTIFY_VERSION' ) ? ANALYTIFY_VERSION : '1.0.0' );
		$this->hooks();
		$this->may_be_load_addon();
	}

	/**
	 * Load the addon if dependencies are met.
	 *
	 * @since 1.0.0
	 */
	public function may_be_load_addon() {
		/**
		 * Check for LearnDash.
		 */
		if ( ! defined( 'LEARNDASH_VERSION' ) ) {
			add_action( 'admin_enqueue_scripts', array( $this, 'wpa_ldms_notices_scripts' ) );
			return;
		} elseif (
			file_exists( WP_PLUGIN_DIR . '/wp-analytify-pro/wp-analytify-pro.php' )
			&& function_exists( 'wp_analytify_pro_load' )
			&& class_exists( 'WP_Analytify_Pro_Base' )
		) {
			include_once ANALYTIFY_PRO_LEARNDASH_ADDON_ROOT_PATH . '/class-wp-analytify-learndash-addon.php';
			// Global for backwards compatibility.
			$GLOBALS['WPAnalytifyProLearnDash'] = WP_Analytify_LearnDash_Addon::instance();
		} else {
			add_action( 'admin_enqueue_scripts', array( $this, 'wpa_ldms_notices_scripts' ) );
		}
	}

	/**
	 * Define constants.
	 *
	 * @since 1.0.0
	 */
	public function define_constants() {
		define( 'ANALYTIFY_PRO_LEARNDASH_ADDON_ROOT_PATH', __DIR__ );
		define( 'ANALYTIFY_PRO_LEARNDASH_UPGRADE_PATH', __FILE__ );
		// Set to default if tracking mode not set.
		if ( ! defined( 'ANALYTIFY_PRO_TRACKING_MODE' ) ) {
			define( 'ANALYTIFY_PRO_TRACKING_MODE', 'gtag' );
		}
	}

	/**
	 * Setup hooks.
	 *
	 * @since 1.0.0
	 */
	public function hooks() {
		add_action( 'admin_notices', array( $this, 'wpa_ldms_install_analytify_pro' ) );
		add_action( 'admin_notices', array( $this, 'wpa_ldms_active_analytify_pro' ) );
		add_action( 'admin_notices', array( $this, 'install_ldms' ) );
		add_action( 'admin_notices', array( $this, 'active_ldms' ) );
		add_action( 'init', array( $this, 'wp_analytify_ldms_load_text_domain' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'ldms_admin_styles' ) );
		add_action( 'admin_footer', array( $this, 'wp_analytify_ldms_notice_script' ) );
		add_action( 'wp_ajax_dismiss_analytify_notice', array( $this, 'dismiss_analytify_ldms_notice' ) );
	}

	/**
	 * Check Analytify Pro plugin installation.
	 *
	 * @return void
	 */
	public function wpa_ldms_install_analytify_pro() {
		if ( ! file_exists( WP_PLUGIN_DIR . '/wp-analytify-pro/wp-analytify-pro.php' ) ) {
			$message = sprintf(
				'<strong>%s</strong> %s',
				esc_html__( 'Attention:', 'wp-analytify-pro' ),
				esc_html__( 'Please install Analytify Pro to use Analytify for LearnDash addon.', 'wp-analytify-pro' )
			);
			$this->wp_analytify_ldms_notice( $message, 'wp-analytify-danger' );
		}
	}

	/**
	 * Check Analytify Pro plugin activation.
	 *
	 * @return void
	 */
	public function wpa_ldms_active_analytify_pro() {
		if ( ! class_exists( 'WP_Analytify_Pro_Base' ) ) {
			$message = sprintf(
				'<strong>%s</strong> %s',
				esc_html__( 'Attention: ', 'wp-analytify-pro' ),
				esc_html__( 'Please activate Analytify Pro to use Analytify for LearnDash addon.', 'wp-analytify-pro' )
			);
			$this->wp_analytify_ldms_notice( $message, 'wp-analytify-danger' );
		}
	}

	/**
	 * Install LearnDash notice.
	 *
	 * @return void
	 */
	public function install_ldms() {
		if ( ! file_exists( WP_PLUGIN_DIR . '/sfwd-lms/sfwd_lms.php' ) ) {
			$message = sprintf(
				'<strong>%s</strong> %s',
				esc_html__( 'Attention:', 'wp-analytify-pro' ),
				esc_html__( 'Analytify for LearnDash addon works with LearnDash plugin. Please install the LearnDash plugin.', 'wp-analytify-pro' )
			);
			$this->wp_analytify_ldms_notice( $message, 'wp-analytify-danger' );
		}
	}

	/**
	 * Check LearnDash plugin activation.
	 *
	 * @return void
	 */
	public function active_ldms() {
		if ( file_exists( WP_PLUGIN_DIR . '/sfwd-lms/sfwd_lms.php' ) && ! defined( 'LEARNDASH_VERSION' ) ) {
			$message = sprintf(
				'<strong>%s</strong> %s',
				esc_html__( 'Attention:', 'wp-analytify-pro' ),
				esc_html__( 'Analytify for LearnDash addon works with the LearnDash plugin. Please activate LearnDash.', 'wp-analytify-pro' )
			);
			$this->wp_analytify_ldms_notice( $message, 'wp-analytify-danger' );
		}
	}

	/**
	 * Admin notices scripts.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function wpa_ldms_notices_scripts() {
		wp_enqueue_style( 'analytify-ldms-notices', plugins_url( 'assets/css/notices' . analytify_pro_get_asset_suffix() . '.css', __FILE__ ), '', $this->version );
	}

	/**
	 * Admin styles.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function ldms_admin_styles() {
		wp_enqueue_style( 'wp-analytify-ldms-funnel-style', plugins_url( 'assets/css/funnel' . analytify_pro_get_asset_suffix() . '.css', __FILE__ ), false, $this->version );
		// Note: enableAnalytifyTableSorting() is already called in learndash-dashboard.php after AJAX loads data,
		// and the function is defined in wp-analytify-pro/assets/js/analytify-table-sorting.js which is enqueued by core.
	}

	/**
	 * Load TextDomain.
	 *
	 * @since 1.0.0
	 */
	public function wp_analytify_ldms_load_text_domain() {
		$plugin_dir = basename( __DIR__ );
		load_plugin_textdomain( 'wp-analytify-pro', false, $plugin_dir . '/languages/' );
	}

	/**
	 * Add custom admin notice.
	 *
	 * @param  string $message Custom Message.
	 * @param  string $notice_class wp-analytify-success,wp-analytify-danger.
	 * @return void
	 */
	public function wp_analytify_ldms_notice( $message, $notice_class = 'wp-analytify-success' ) {
		// Only show notices on allowed pages.
		$screen = get_current_screen();

		if ( ! $screen ) {
			return;
		}

		$allowed_parent_bases = array(
			'analytify-dashboard',
			'plugins',
			'analytify-settings',
			'analytify-license',
			'analytify-addons',
			'dashboard',
		);

		$allowed_screen_ids = array(
			'plugins',
			'dashboard',
		);

		// Check if we're on an allowed page.
		$page       = isset( $_GET['page'] ) ? sanitize_text_field( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$is_allowed = in_array( $screen->parent_base, $allowed_parent_bases, true )
			|| in_array( $screen->id, $allowed_screen_ids, true )
			|| ( ! empty( $page ) && strpos( $page, 'analytify' ) === 0 );

		// Don't show notice if not on allowed page.
		if ( ! $is_allowed ) {
			return;
		}

		$notice_id = 'analytify_notice_' . md5( is_string( $message ) ? $message : '' );
		if ( ! get_option( $notice_id ) ) {
			// Use __DIR__ to get the addon root directory, same as how constants are defined.
			$logo_url = plugins_url( 'assets/img/logo.svg', __DIR__ . '/wp-analytify-learndash.php' );

			echo '<div class="wp-analytify-notification ' . esc_attr( $notice_class ) . '" id="' . esc_attr( $notice_id ) . '">
					<a class="wp-analytify-notice-dismiss" href="#" aria-label="Dismiss the notice" onclick="dismissAnalytifyNotice(\'' . esc_js( $notice_id ) . '\'); return false;">&times;</a>
					<div class="wp-analytify-notice-logo">
						<img src="' . esc_url( $logo_url ) . '" alt="notice">
					</div>
					<div class="wp-analytify-notice-discription">
						<p>' . wp_kses_post( is_string( $message ) ? $message : '' ) . '</p>
					</div>
				</div>';
		}
	}

	/**
	 * Notice dismiss script.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function wp_analytify_ldms_notice_script() {
		?>
		<script type="text/javascript">
			function dismissAnalytifyNotice(noticeId) {
				document.getElementById(noticeId).style.display = 'none';
				localStorage.setItem('analytify_stats_refreshed_dismissed', '1');
				var ajaxurl = '<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>';
				var data = {
					'action': 'dismiss_analytify_notice',
					'notice_id': noticeId,
					'nonce': '<?php echo esc_js( wp_create_nonce( 'dismiss_analytify_ldms_notice' ) ); ?>'
				};
				jQuery.post(ajaxurl, data, function(response) {
					console.log(response);
				});
			}
		</script>
		<?php
	}

	/**
	 * Dismiss notice handler.
	 *
	 * @return void
	 */
	public function dismiss_analytify_ldms_notice() {
		if ( ! check_ajax_referer( 'dismiss_analytify_ldms_notice', 'nonce', false ) ) {
			wp_send_json_error( array( 'message' => 'bad_nonce' ), 403 );
		}

		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_send_json_error( array( 'message' => 'forbidden' ), 403 );
		}

		$notice_id = isset( $_POST['notice_id'] ) ? sanitize_text_field( wp_unslash( $_POST['notice_id'] ) ) : '';
		if ( ! preg_match( '/^analytify_notice_[a-f0-9]{32}$/', $notice_id ) ) {
			wp_send_json_error( array( 'message' => 'invalid_notice' ), 400 );
		}

		update_option( $notice_id, true );
		wp_send_json_success();
	}
}

