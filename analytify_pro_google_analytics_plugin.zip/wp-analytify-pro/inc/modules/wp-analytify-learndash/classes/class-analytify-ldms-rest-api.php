<?php
/**
 * Handle Analytify LearnDash REST end points.
 *
 * @package Analytify
 * @subpackage LearnDash
 */

if ( ! class_exists( 'Analytify_LDMS_Rest_API' ) ) {

	/**
	 * Analytify LearnDash REST API Class.
	 */
	class Analytify_LDMS_Rest_API {

		/**
		 * The single instance of the class.
		 *
		 * @var object
		 */
		private static $instance;

		/**
		 * WP_Analytify instance.
		 *
		 * @var object
		 */
		private $wp_analytify;

		/**
		 * GA mode.
		 *
		 * @var string
		 */
		private $ga_mode;

		/**
		 * Start date.
		 *
		 * @var string
		 */
		private $start_date;

		/**
		 * End date.
		 *
		 * @var string
		 */
		private $end_date;

		/**
		 * Compare start date.
		 *
		 * @var string
		 */
		private $compare_start_date;

		/**
		 * Compare end date.
		 *
		 * @var string
		 */
		private $compare_end_date;

		/**
		 * Date difference.
		 *
		 * @var int
		 */
		private $date_difference;

		/**
		 * Report URL.
		 *
		 * @var string
		 */
		private $report_url;

		/**
		 * Report date range.
		 *
		 * @var string
		 */
		private $report_date_range;

		/**
		 * Returns the single instance of the class.
		 *
		 * @since 9.0.0
		 * @return object Class instance.
		 */
		public static function get_instance() {

			if ( empty( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		/**
		 * Class constructor.
		 *
		 * @since 9.0.0
		 */
		private function __construct() {

			$this->wp_analytify = $GLOBALS['WP_ANALYTIFY'];
			$this->ga_mode      = method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) ? WPANALYTIFY_Utils::get_ga_mode() : 'ga3';

			add_action( 'rest_api_init', array( $this, 'rest_api_init' ) );
		}

		/**
		 * Register REST API endpoints.
		 *
		 * @since 9.0.0
		 * @return void
		 */
		public function rest_api_init() {

			register_rest_route(
				'wp-analytify/v1',
				'/get_pro_ldms_report/(?P<profile_id>\d+)/(?P<request_type>[a-zA-Z0-9-]+)',
				array(
					array(
						'methods'             => WP_REST_Server::READABLE,
						'callback'            => array( $this, 'handle_request' ),
						'permission_callback' => array( $this, 'permission_check' ),
					),
				)
			);
		}

		/**
		 * Checks access permission.
		 * Checks if the user is logged-in and checks of the user role has access.
		 *
		 * @since 9.0.0
		 * @return bool True if user has permission, false otherwise.
		 */
		public function permission_check() {

			$is_access_level = $this->wp_analytify->settings->get_option( 'show_analytics_roles_dashboard', 'wp-analytify-dashboard', array( 'administrator' ) );

			return (bool) $this->wp_analytify->pa_check_roles( $is_access_level );
		}

		/**
		 * Handle the REST API request.
		 *
		 * @param WP_REST_Request $request Request object.
		 * @since 9.0.0
		 * @return array|WP_Error Response data or error.
		 */
		public function handle_request( WP_REST_Request $request ) {

			$is_access_level = $this->wp_analytify->settings->get_option( 'show_analytics_roles_dashboard', 'wp-analytify-dashboard', array( 'Administrator' ) );

			// Generate error if unauthorized user send the request.
			if ( ! $this->wp_analytify->pa_check_roles( $is_access_level ) ) {
				return new WP_Error( 'analytify_forbidden', __( 'You are not allowed to access Analytify Dashboard.', 'wp-analytify-pro' ), array( 'status' => 403 ) );
			}

			// Sanitize request parameters before use.
			$request_type = sanitize_text_field( (string) $request->get_param( 'request_type' ) );

			$this->start_date         = sanitize_text_field( (string) $request->get_param( 'sd' ) );
			$this->end_date           = sanitize_text_field( (string) $request->get_param( 'ed' ) );
			$this->compare_start_date = sanitize_text_field( (string) $request->get_param( 'csd' ) );
			$this->compare_end_date   = sanitize_text_field( (string) $request->get_param( 'ced' ) );
			$this->date_difference    = absint( $request->get_param( 'dd' ) );
			$this->report_url         = sanitize_text_field( (string) $request->get_param( 'ru' ) );
			$this->report_date_range  = sanitize_text_field( (string) $request->get_param( 'rdr' ) );

			switch ( $request_type ) {
				case 'general-stats':
					return $this->general_stats();

				case 'top-courses':
					return $this->top_courses();

				case 'traffic-sources':
					return $this->traffic_sources();

				case 'user-journeys':
					return $this->user_journeys();

				case 'course-insights':
					return $this->course_insights();

				case 'custom-events':
					return $this->custom_events();

				case 'coupons':
					return $this->coupons();

				case 'funnel':
					return $this->funnel();
			}

			// If no request type match, Return error.
			return new WP_Error( 'analytify_invalid_endpoint', __( 'Invalid endpoint.', 'wp-analytify-pro' ), array( 'status' => 404 ) );
		}

		/**
		 * Get general statistics.
		 *
		 * @since 9.0.0
		 * @return array Response data.
		 */
		private function general_stats() {

			if ( 'ga4' === $this->ga_mode ) {

				$purchase_only = array(
					'logic'   => 'AND',
					'filters' => array(
						array(
							'type'       => 'dimension',
							'name'       => 'eventName',
							'match_type' => 1,
							'value'      => 'purchase',
						),
					),
				);

				$top_courses_data = $this->wp_analytify->get_reports(
					'show-ldms-general-stats',
					array(
						'itemRevenue',
						'itemsPurchased',
						'itemsViewed',
					),
					array(
						'start' => $this->start_date,
						'end'   => $this->end_date,
					),
					array(
						'itemId',
						'itemName',
						'currencyCode',
					),
					array(
						'type'  => 'metric',
						'name'  => 'itemRevenue',
						'order' => 'desc',
					),
					$purchase_only,
					50
				);

				// Get sessions and other metrics.
				$sessions_data = $this->wp_analytify->get_reports(
					'show-ldms-sessions',
					array(
						'sessions',
						'averagePurchaseRevenue',
					),
					array(
						'start' => $this->start_date,
						'end'   => $this->end_date,
					),
					array(),
					array(),
					array(),
					1
				);

				// Calculate Days to Purchase and Sessions to Purchase manually.
				$purchase_journey_data = $this->wp_analytify->get_reports(
					'show-ldms-purchase-journey',
					array(
						'sessions',
						'eventCount',
					),
					array(
						'start' => $this->start_date,
						'end'   => $this->end_date,
					),
					array(
						'date',
						'sessionId',
						'transactionId',
					),
					array(),
					array(
						'logic'   => 'AND',
						'filters' => array(
							array(
								'type'       => 'dimension',
								'name'       => 'eventName',
								'match_type' => 1,
								'value'      => 'purchase',
							),
						),
					),
					1000 // Get more data for accurate calculation.
				);

				// Calculate metrics manually.
				$sessions_to_purchase = 0;
				$days_to_purchase     = 0;

				if ( isset( $purchase_journey_data['rows'] ) && is_array( $purchase_journey_data['rows'] ) && ! empty( $purchase_journey_data['rows'] ) ) {
					$total_sessions_before_purchase = 0;
					$total_days_before_purchase     = 0;
					$purchase_count                 = 0;

					// Group by transaction ID to get unique purchases.
					$purchases = array();
					foreach ( $purchase_journey_data['rows'] as $row ) {
						$transaction_id = $row['transactionId'] ?? '';
						if ( ! empty( $transaction_id ) ) {
							if ( ! isset( $purchases[ $transaction_id ] ) ) {
								$purchases[ $transaction_id ] = array(
									'sessions'         => 0,
									'first_visit_date' => null,
									'purchase_date'    => $row['date'] ?? '',
								);
								++$purchase_count;
							}
							$purchases[ $transaction_id ]['sessions'] += intval( $row['sessions'] ?? 0 );

							// Set first visit date (earliest date for this transaction).
							if ( empty( $purchases[ $transaction_id ]['first_visit_date'] ) ||
								$row['date'] < $purchases[ $transaction_id ]['first_visit_date'] ) {
								$purchases[ $transaction_id ]['first_visit_date'] = $row['date'];
							}
						}
					}

					// Calculate totals.
					foreach ( $purchases as $purchase ) {
						$total_sessions_before_purchase += $purchase['sessions'];

						if ( ! empty( $purchase['first_visit_date'] ) && ! empty( $purchase['purchase_date'] ) ) {
							try {
								$first_visit                 = new DateTime( $purchase['first_visit_date'] );
								$purchase_date               = new DateTime( $purchase['purchase_date'] );
								$days_diff                   = $first_visit->diff( $purchase_date )->days;
								$total_days_before_purchase += $days_diff;
							} catch ( Exception $e ) {
								continue;
							}
						}
					}

					// Calculate averages.
					if ( $purchase_count > 0 ) {
						$sessions_to_purchase = $total_sessions_before_purchase / $purchase_count;
						$days_to_purchase     = $total_days_before_purchase / $purchase_count;
					}
				}

				// Calculate totals from individual course data.
				$total_revenue   = 0;
				$total_purchases = 0;
				$total_views     = 0;

				$top_rows = ( isset( $top_courses_data['rows'] ) && is_array( $top_courses_data['rows'] ) ) ? $top_courses_data['rows'] : array();
				if ( ! empty( $top_rows ) ) {
					foreach ( $top_rows as $row ) {
						$total_revenue   += isset( $row['itemRevenue'] ) ? (float) $row['itemRevenue'] : 0;
						$total_purchases += isset( $row['itemsPurchased'] ) ? (int) $row['itemsPurchased'] : 0;
						$total_views     += isset( $row['itemsViewed'] ) ? (int) $row['itemsViewed'] : 0;
					}
				}

				$enroll_totals = $this->wp_analytify->get_reports(
					'show-ldms-overview-enrollment',
					array( 'eventCount', 'eventValue' ),
					array(
						'start' => $this->start_date,
						'end'   => $this->end_date,
					),
					array(),
					array(),
					array(
						'logic'   => 'OR',
						'filters' => array(
							array(
								'type'       => 'dimension',
								'name'       => 'eventName',
								'match_type' => 1,
								'value'      => 'wpa_ldlms_course_enrolled',
							),
							array(
								'type'       => 'dimension',
								'name'       => 'eventName',
								'match_type' => 1,
								'value'      => 'wpa_ldlms_course_enrollment',
							),
						),
					),
					1
				);
				$enroll_count  = isset( $enroll_totals['aggregations']['eventCount'] ) ? (int) $enroll_totals['aggregations']['eventCount'] : 0;
				$enroll_value  = isset( $enroll_totals['aggregations']['eventValue'] ) ? (float) $enroll_totals['aggregations']['eventValue'] : 0;
				if ( $enroll_count > 0 || $enroll_value > 0 ) {
					$total_purchases = $enroll_count;
					$total_revenue   = $enroll_value;
				}

				$currency_code = 'USD';
				if ( ! empty( $top_rows ) ) {
					foreach ( $top_rows as $crow ) {
						if ( ! empty( $crow['currencyCode'] ) && '(not set)' !== $crow['currencyCode'] ) {
							$currency_code = (string) $crow['currencyCode'];
							break;
						}
					}
				}

				// Create general stats structure.
				$general_stats = array(
					'aggregations' => array(
						'transactions'           => $total_purchases,
						'purchaseRevenue'        => $total_revenue,
						'ecommercePurchases'     => $total_purchases,
						'sessions'               => isset( $sessions_data['aggregations']['sessions'] ) ? $sessions_data['aggregations']['sessions'] : 0,
						'averagePurchaseRevenue' => $total_purchases > 0 ? $total_revenue / $total_purchases : 0,
						'sessionsToTransaction'  => $sessions_to_purchase,
						'daysToTransaction'      => $days_to_purchase,
					),
					'currencyCode' => $currency_code,
				);

				// Fetch refunds count using GA4 events (eventName = refund).
				$refunds_stats = $this->wp_analytify->get_reports(
					'show-ldms-refunds',
					array( 'eventCount' ),
					array(
						'start' => $this->start_date,
						'end'   => $this->end_date,
					),
					array(),
					array(),
					array(
						'logic'   => 'AND',
						'filters' => array(
							array(
								'type'       => 'dimension',
								'name'       => 'eventName',
								'match_type' => 1,
								'value'      => 'refund',
							),
						),
					),
					1
				);

				$refunds = isset( $refunds_stats['aggregations']['eventCount'] ) ? (int) $refunds_stats['aggregations']['eventCount'] : 0;

				// Append refunds and refund rate to aggregations for the view layer.
				if ( ! isset( $general_stats['aggregations'] ) ) {
					$general_stats['aggregations'] = array();
				}
				$general_stats['aggregations']['refunds']    = $refunds;
				$transactions_for_rate                       = isset( $general_stats['aggregations']['transactions'] ) ? (int) $general_stats['aggregations']['transactions'] : 0;
				$general_stats['aggregations']['refundRate'] = $transactions_for_rate > 0 ? ( $refunds / $transactions_for_rate ) * 100 : 0;

				if ( isset( $general_stats['aggregations'] ) ) {
					include LDMS_ANALYTIFY_PLUGIN_DIR . '/views/default/general-stats.php';
					return ldms_analytify_general_stats( $this->wp_analytify, $general_stats );
				}
			}

			return new WP_Error( 'no_data', __( 'No data available.', 'wp-analytify-pro' ), array( 'status' => 404 ) );
		}

		/**
		 * Get top courses.
		 *
		 * @since 9.0.0
		 * @return array Response data.
		 */
		private function top_courses() {

			if ( 'ga4' === $this->ga_mode ) {
				$stats = $this->wp_analytify->get_reports(
					'show-ldms-top-courses',
					array(
						'itemRevenue',
						'itemsPurchased',
						'itemsViewed',
						'cartToViewRate',
					),
					array(
						'start' => $this->start_date,
						'end'   => $this->end_date,
					),
					array(
						'itemId',
						'itemName',
						'currencyCode',
					),
					array(
						'type'  => 'metric',
						'name'  => 'itemRevenue',
						'order' => 'desc',
					),
					array(
						'logic'   => 'AND',
						'filters' => array(
							array(
								'type'       => 'dimension',
								'name'       => 'eventName',
								'match_type' => 1,
								'value'      => 'purchase',
							),
						),
					),
					10
				);

				if ( ! empty( $stats['rows'] ) && is_array( $stats['rows'] ) ) {
					foreach ( $stats['rows'] as &$row ) {
						$name = isset( $row['itemName'] ) ? trim( (string) $row['itemName'] ) : '';
						$raw  = isset( $row['itemId'] ) ? preg_replace( '/\D/', '', (string) $row['itemId'] ) : '';
						$pid  = '' !== $raw ? absint( $raw ) : 0;
						if ( ( '' === $name || '(not set)' === $name ) && $pid && get_post( $pid ) && 'sfwd-courses' === get_post_type( $pid ) ) {
							$row['itemName'] = get_the_title( $pid );
						}
					}
					unset( $row );
				}

				include LDMS_ANALYTIFY_PLUGIN_DIR . '/views/default/top-courses.php';
				return ldms_analytify_top_courses( $this->wp_analytify, $stats );
			}

			return new WP_Error( 'no_data', __( 'No data available.', 'wp-analytify-pro' ), array( 'status' => 404 ) );
		}

		/**
		 * Get traffic sources.
		 *
		 * @since 9.0.0
		 * @return array Response data.
		 */
		private function traffic_sources() {

			if ( 'ga4' === $this->ga_mode ) {
				$stats = $this->wp_analytify->get_reports(
					'show-ldms-traffic-sources',
					array(
						'sessions',
						'bounceRate',
						'purchaseRevenue',
					),
					array(
						'start' => $this->start_date,
						'end'   => $this->end_date,
					),
					array(
						'sourceMedium',
						'currencyCode',
					),
					array(
						'type'  => 'metric',
						'name'  => 'purchaseRevenue',
						'order' => 'desc',
					),
					array(),
					50
				);

				include LDMS_ANALYTIFY_PLUGIN_DIR . '/views/default/traffic-sources.php';
				return ldms_analytify_traffic_sources( $this->wp_analytify, $stats, $this->report_url, $this->report_date_range );
			}

			return new WP_Error( 'no_data', __( 'No data available.', 'wp-analytify-pro' ), array( 'status' => 404 ) );
		}

		/**
		 * Get user journeys.
		 *
		 * @since 9.0.0
		 * @return array Response data.
		 */
		private function user_journeys() {

			if ( 'ga4' === $this->ga_mode ) {
				$stats = $this->wp_analytify->get_reports(
					'show-ldms-user-journeys',
					array(
						'screenPageViews',
						'sessions',
						'averageSessionDuration',
					),
					array(
						'start' => $this->start_date,
						'end'   => $this->end_date,
					),
					array(
						'pageTitle',
						'pagePath',
					),
					array(
						'type'  => 'metric',
						'name'  => 'screenPageViews',
						'order' => 'desc',
					),
					array(),
					50
				);

				include LDMS_ANALYTIFY_PLUGIN_DIR . '/views/default/user-journeys.php';
				return ldms_analytify_user_journeys( $this->wp_analytify, $stats );
			}

			return new WP_Error( 'no_data', __( 'No data available.', 'wp-analytify-pro' ), array( 'status' => 404 ) );
		}

		/**
		 * Get course insights.
		 *
		 * @since 9.0.0
		 * @return array Response data.
		 */
		private function course_insights() {

			if ( 'ga4' === $this->ga_mode ) {
				$dr      = array(
					'start' => $this->start_date,
					'end'   => $this->end_date,
				);
				$by_key  = array();
				$event_f = static function ( $name ) {
					return array(
						'logic'   => 'AND',
						'filters' => array(
							array(
								'type'       => 'dimension',
								'name'       => 'eventName',
								'match_type' => 1,
								'value'      => $name,
							),
						),
					);
				};

				foreach ( array( 'wpa_ldlms_course_enrolled', 'wpa_ldlms_course_enrollment' ) as $ev ) {
					$enr = $this->wp_analytify->get_reports(
						'ldms-ci-enroll-' . $ev,
						array( 'eventCount' ),
						$dr,
						array(
							'customEvent:course_id',
							'customEvent:wpa_label',
						),
						array(
							'type'  => 'metric',
							'name'  => 'eventCount',
							'order' => 'desc',
						),
						$event_f( $ev ),
						250
					);
					if ( empty( $enr['rows'] ) || ! is_array( $enr['rows'] ) ) {
						continue;
					}
					foreach ( $enr['rows'] as $row ) {
						$cid_raw = isset( $row['customEvent:course_id'] ) ? $row['customEvent:course_id'] : '';
						$label   = isset( $row['customEvent:wpa_label'] ) ? trim( (string) $row['customEvent:wpa_label'] ) : '';
						$key     = $this->ldms_course_insights_merge_key( $cid_raw, $label );
						if ( '' === $key ) {
							continue;
						}
						$disp = $this->ldms_course_insights_course_name( $key, $label );
						if ( ! isset( $by_key[ $key ] ) ) {
							$by_key[ $key ] = array(
								'courseName'  => $disp,
								'enrollments' => 0,
								'completions' => 0,
								'lessons'     => 0,
							);
						}
						$by_key[ $key ]['enrollments'] += isset( $row['eventCount'] ) ? (int) $row['eventCount'] : 0;
					}
				}

				$cmp = $this->wp_analytify->get_reports(
					'ldms-ci-complete',
					array( 'eventCount' ),
					$dr,
					array(
						'customEvent:course_id',
						'customEvent:wpa_label',
					),
					array(
						'type'  => 'metric',
						'name'  => 'eventCount',
						'order' => 'desc',
					),
					$event_f( 'wpa_ldlms_course_completed' ),
					250
				);
				if ( ! empty( $cmp['rows'] ) && is_array( $cmp['rows'] ) ) {
					foreach ( $cmp['rows'] as $row ) {
						$cid_raw = isset( $row['customEvent:course_id'] ) ? $row['customEvent:course_id'] : '';
						$label   = isset( $row['customEvent:wpa_label'] ) ? trim( (string) $row['customEvent:wpa_label'] ) : '';
						$key     = $this->ldms_course_insights_merge_key( $cid_raw, $label );
						if ( '' === $key ) {
							continue;
						}
						$disp = $this->ldms_course_insights_course_name( $key, $label );
						if ( ! isset( $by_key[ $key ] ) ) {
							$by_key[ $key ] = array(
								'courseName'  => $disp,
								'enrollments' => 0,
								'completions' => 0,
								'lessons'     => 0,
							);
						}
						$by_key[ $key ]['completions'] += isset( $row['eventCount'] ) ? (int) $row['eventCount'] : 0;
					}
				}

				$les = $this->wp_analytify->get_reports(
					'ldms-ci-lessons',
					array( 'eventCount' ),
					$dr,
					array(
						'customEvent:course_id',
						'customEvent:course_name',
					),
					array(
						'type'  => 'metric',
						'name'  => 'eventCount',
						'order' => 'desc',
					),
					$event_f( 'wpa_ldlms_lesson_completed' ),
					250
				);
				if ( ! empty( $les['rows'] ) && is_array( $les['rows'] ) ) {
					foreach ( $les['rows'] as $row ) {
						$cid_raw = isset( $row['customEvent:course_id'] ) ? $row['customEvent:course_id'] : '';
						$label   = isset( $row['customEvent:course_name'] ) ? trim( (string) $row['customEvent:course_name'] ) : '';
						$key     = $this->ldms_course_insights_merge_key( $cid_raw, $label );
						if ( '' === $key ) {
							continue;
						}
						$disp = $this->ldms_course_insights_course_name( $key, $label );
						if ( ! isset( $by_key[ $key ] ) ) {
							$by_key[ $key ] = array(
								'courseName'  => $disp,
								'enrollments' => 0,
								'completions' => 0,
								'lessons'     => 0,
							);
						}
						$by_key[ $key ]['lessons'] += isset( $row['eventCount'] ) ? (int) $row['eventCount'] : 0;
					}
				}

				$rows = array();
				foreach ( $by_key as $b ) {
					$enr    = (int) $b['enrollments'];
					$cmp    = (int) $b['completions'];
					$ls     = (int) $b['lessons'];
					$rate   = $enr > 0 ? ( $cmp / $enr ) * 100 : 0;
					$prog   = ( $enr > 0 && $ls > 0 ) ? min( 100, ( $ls / $enr ) / 10 * 100 ) : 0;
					$rows[] = array(
						'courseName'      => $b['courseName'],
						'enrollments'     => $enr,
						'completions'     => $cmp,
						'completionRate'  => $rate,
						'averageProgress' => $prog,
					);
				}
				usort(
					$rows,
					static function ( $a, $b ) {
						return (int) $b['enrollments'] <=> (int) $a['enrollments'];
					}
				);

				$stats = array(
					'rows'         => $rows,
					'headers'      => array(),
					'error'        => array(),
					'aggregations' => array(),
				);

				include LDMS_ANALYTIFY_PLUGIN_DIR . '/views/default/course-insights.php';
				return ldms_analytify_course_insights( $this->wp_analytify, $stats );
			}

			return new WP_Error( 'no_data', __( 'No data available.', 'wp-analytify-pro' ), array( 'status' => 404 ) );
		}

		/**
		 * Get custom events statistics.
		 *
		 * @since 9.0.0
		 * @return array Response data.
		 */
		private function custom_events() {

			if ( 'ga4' === $this->ga_mode ) {
				// Get individual event counts for each LearnDash event.
				$events_data = array();
				$event_names = array(
					'wpa_view_course'               => 'Course Views',
					'wpa_view_course_list'          => 'Course List Views',
					'wpa_select_course'             => 'Course Selections',
					'wpa_ldlms_lesson_viewed'       => 'Lesson Views',
					'wpa_ldlms_course_enrolled'     => 'Course Enrollments',
					'wpa_ldlms_course_completed'    => 'Course Completed',
					'wpa_ldlms_lesson_completed'    => 'Lesson Completed',
					'wpa_ldlms_topic_completed'     => 'Topic Completed',
					'wpa_ldlms_quiz_started'        => 'Quiz Started',
					'wpa_ldlms_quiz_completed'      => 'Quiz Completed',
					'wpa_ldlms_assignment_uploaded' => 'Assignment Uploaded',
				);

				// GA4 sums `value` on every hit; we only surface that total for true enrollment value here.
				$ldms_activity_show_event_value = array( 'wpa_ldlms_course_enrolled' );

				foreach ( $event_names as $event_name => $display_name ) {
					$event_filter = array(
						'logic'   => 'AND',
						'filters' => array(
							array(
								'type'       => 'dimension',
								'name'       => 'eventName',
								'match_type' => 1,
								'value'      => $event_name,
							),
						),
					);

					$stats = $this->wp_analytify->get_reports(
						'custom-event-' . $event_name,
						array(
							'eventCount',
							'eventValue',
							'totalUsers',
						),
						array(
							'start' => $this->start_date,
							'end'   => $this->end_date,
						),
						array( 'customEvent:wpa_label' ),
						array(
							'type'  => 'metric',
							'name'  => 'eventCount',
							'order' => 'desc',
						),
						$event_filter,
						250
					);

					$sum_count = 0;
					$sum_value = 0.0;

					if ( ! empty( $stats['rows'] ) && is_array( $stats['rows'] ) ) {
						foreach ( $stats['rows'] as $row ) {
							$sum_count += isset( $row['eventCount'] ) ? (int) $row['eventCount'] : 0;
							$sum_value += isset( $row['eventValue'] ) ? (float) $row['eventValue'] : 0;
						}
					}

					if ( $sum_count <= 0 && isset( $stats['aggregations']['eventCount'] ) ) {
						$sum_count = (int) $stats['aggregations']['eventCount'];
					}
					if ( $sum_value <= 0 && isset( $stats['aggregations']['eventValue'] ) ) {
						$sum_value = (float) $stats['aggregations']['eventValue'];
					}

					$uniq_users = isset( $stats['aggregations']['totalUsers'] ) ? (int) $stats['aggregations']['totalUsers'] : 0;

					if ( $sum_count <= 0 && $sum_value <= 0 ) {
						$total_stats = $this->wp_analytify->get_reports(
							'custom-event-total-' . $event_name,
							array(
								'eventCount',
								'eventValue',
								'totalUsers',
							),
							array(
								'start' => $this->start_date,
								'end'   => $this->end_date,
							),
							array(),
							array(),
							$event_filter,
							1
						);
						$sum_count   = isset( $total_stats['aggregations']['eventCount'] ) ? (int) $total_stats['aggregations']['eventCount'] : 0;
						$sum_value   = isset( $total_stats['aggregations']['eventValue'] ) ? (float) $total_stats['aggregations']['eventValue'] : 0;
						$uniq_users  = isset( $total_stats['aggregations']['totalUsers'] ) ? (int) $total_stats['aggregations']['totalUsers'] : 0;
					} elseif ( $uniq_users <= 0 ) {
						$user_stats = $this->wp_analytify->get_reports(
							'custom-event-users-' . $event_name,
							array( 'totalUsers' ),
							array(
								'start' => $this->start_date,
								'end'   => $this->end_date,
							),
							array(),
							array(),
							$event_filter,
							1
						);
						$uniq_users = isset( $user_stats['aggregations']['totalUsers'] ) ? (int) $user_stats['aggregations']['totalUsers'] : 0;
					}

					if ( ! in_array( $event_name, $ldms_activity_show_event_value, true ) ) {
						$sum_value = 0.0;
					}

					if ( $sum_count > 0 || $sum_value > 0 ) {
						$events_data[] = array(
							'eventName'         => $event_name,
							'displayName'       => $display_name,
							'eventCount'        => $sum_count,
							'eventCountPerUser' => $uniq_users,
							'eventValue'        => $sum_value,
						);
					}
				}

				usort(
					$events_data,
					static function ( $a, $b ) {
						return (int) $b['eventCount'] <=> (int) $a['eventCount'];
					}
				);

				// Create mock stats structure for the view.
				$stats = array(
					'rows'         => $events_data,
					'headers'      => array(),
					'error'        => array(),
					'aggregations' => array(),
				);

				include LDMS_ANALYTIFY_PLUGIN_DIR . '/views/default/custom-events.php';
				return ldms_analytify_custom_events( $this->wp_analytify, $stats );
			}

			return new WP_Error( 'no_data', __( 'No data available.', 'wp-analytify-pro' ), array( 'status' => 404 ) );
		}

		/**
		 * Get coupons performance report.
		 *
		 * @since 9.0.0
		 * @return array|WP_Error Response data or error.
		 */
		private function coupons() {

			if ( 'ga4' === $this->ga_mode ) {
				$stats = $this->wp_analytify->get_reports(
					'show-ldms-coupons',
					array(
						'purchaseRevenue',
						'ecommercePurchases',
					),
					array(
						'start' => $this->start_date,
						'end'   => $this->end_date,
					),
					array(
						'coupon',
					),
					array(
						'type'  => 'metric',
						'name'  => 'purchaseRevenue',
						'order' => 'desc',
					),
					array(),
					25
				);

				include LDMS_ANALYTIFY_PLUGIN_DIR . '/views/default/coupons.php';
				return ldms_analytify_coupons( $this->wp_analytify, $stats );
			}

			return new WP_Error( 'no_data', __( 'No data available.', 'wp-analytify-pro' ), array( 'status' => 404 ) );
		}

		/**
		 * Stable merge key for course insights (prefer WordPress course post ID from GA `course_id` param).
		 *
		 * @param mixed  $course_id_raw `customEvent:course_id` or empty for legacy hits.
		 * @param string $label         Fallback label when ID is missing or invalid.
		 * @return string Empty string to skip the row.
		 */
		private function ldms_course_insights_merge_key( $course_id_raw, $label ) {
			$cid = ( is_numeric( $course_id_raw ) && (int) $course_id_raw > 0 ) ? absint( $course_id_raw ) : 0;
			if ( $cid > 0 && get_post( $cid ) && 'sfwd-courses' === get_post_type( $cid ) ) {
				return 'c:' . $cid;
			}
			$label = trim( (string) $label );
			if ( '' === $label || '(not set)' === $label ) {
				return '';
			}
			return 'l:' . md5( strtolower( $label ) );
		}

		/**
		 * Human-readable course title for a course-insights bucket.
		 *
		 * @param string $key   From ldms_course_insights_merge_key().
		 * @param string $label Fallback from GA when not resolvable from the site.
		 * @return string
		 */
		private function ldms_course_insights_course_name( $key, $label ) {
			if ( strpos( $key, 'c:' ) === 0 ) {
				$cid = absint( substr( $key, 2 ) );
				if ( $cid && get_post( $cid ) ) {
					return get_the_title( $cid );
				}
			}
			return $label;
		}

		/**
		 * GA4 event count for funnel steps.
		 *
		 * Uses the eventName dimension so the Data API returns rows; core get_reports() drops
		 * responses that have no `rows` key even when totals exist.
		 *
		 * @since 9.0.0
		 * @param string $cache_key_suffix Unique cache key fragment.
		 * @param array  $filters          Dimension filters for get_reports().
		 * @return int
		 */
		private function ldms_funnel_event_count( $cache_key_suffix, $filters ) {

			$stats = $this->wp_analytify->get_reports(
				'ldms-funnel-metric-' . $cache_key_suffix,
				array( 'eventCount' ),
				array(
					'start' => $this->start_date,
					'end'   => $this->end_date,
				),
				array( 'eventName' ),
				array(
					'type'  => 'metric',
					'name'  => 'eventCount',
					'order' => 'desc',
				),
				$filters,
				50
			);

			$from_agg = isset( $stats['aggregations']['eventCount'] ) ? (int) $stats['aggregations']['eventCount'] : 0;
			if ( $from_agg > 0 ) {
				return $from_agg;
			}

			$sum = 0;
			if ( ! empty( $stats['rows'] ) && is_array( $stats['rows'] ) ) {
				foreach ( $stats['rows'] as $row ) {
					$sum += isset( $row['eventCount'] ) ? (int) $row['eventCount'] : 0;
				}
			}

			return $sum;
		}

		/**
		 * Get checkout funnel stats (begin_checkout → add_payment_info → purchase).
		 *
		 * Purchase count matches the LearnDash overview when Woo `purchase` is absent but
		 * `wpa_ldlms_course_enrolled` / `wpa_ldlms_course_enrollment` events are present.
		 *
		 * @since 9.0.0
		 * @return array|WP_Error Response data or error.
		 */
		private function funnel() {

			if ( 'ga4' !== $this->ga_mode ) {
				return new WP_Error( 'no_data', __( 'No data available.', 'wp-analytify-pro' ), array( 'status' => 404 ) );
			}

			$steps = array(
				'begin_checkout'   => $this->ldms_funnel_event_count(
					'begin_checkout',
					array(
						'logic'   => 'AND',
						'filters' => array(
							array(
								'type'       => 'dimension',
								'name'       => 'eventName',
								'match_type' => 1,
								'value'      => 'begin_checkout',
							),
						),
					)
				),
				'add_payment_info' => $this->ldms_funnel_event_count(
					'add_payment_info',
					array(
						'logic'   => 'AND',
						'filters' => array(
							array(
								'type'       => 'dimension',
								'name'       => 'eventName',
								'match_type' => 1,
								'value'      => 'add_payment_info',
							),
						),
					)
				),
				'purchase'         => 0,
			);

			$steps['purchase'] = $this->ldms_funnel_event_count(
				'purchase',
				array(
					'logic'   => 'AND',
					'filters' => array(
						array(
							'type'       => 'dimension',
							'name'       => 'eventName',
							'match_type' => 1,
							'value'      => 'purchase',
						),
					),
				)
			);

			if ( $steps['purchase'] <= 0 ) {
				$steps['purchase'] = $this->ldms_funnel_event_count(
					'course-enroll',
					array(
						'logic'   => 'OR',
						'filters' => array(
							array(
								'type'       => 'dimension',
								'name'       => 'eventName',
								'match_type' => 1,
								'value'      => 'wpa_ldlms_course_enrolled',
							),
							array(
								'type'       => 'dimension',
								'name'       => 'eventName',
								'match_type' => 1,
								'value'      => 'wpa_ldlms_course_enrollment',
							),
						),
					)
				);
			}

			include LDMS_ANALYTIFY_PLUGIN_DIR . '/views/default/funnel.php';
			return ldms_analytify_funnel( $this->wp_analytify, $steps );
		}
	}
}

// Initialize the class.
if ( function_exists( 'wp_analytify_pro_load' ) ) {
	Analytify_LDMS_Rest_API::get_instance();
}
