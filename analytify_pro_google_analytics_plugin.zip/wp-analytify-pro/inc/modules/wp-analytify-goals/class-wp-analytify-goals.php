<?php
/**
 * Goals Addon Class.
 *
 * @package WP_Analytify_Pro
 */

if ( ! class_exists( 'WP_Analytify_Goals' ) ) {
	/**
	 * Class WP_Analytify_Goals
	 *
	 * Handles Goals tracking functionality.
	 */
	class WP_Analytify_Goals extends WP_Analytify_Pro_Base {

		/**
		 * Constructor.
		 *
		 * @since 1.0.0
		 */
		public function __construct() {
			parent::__construct();
			$this->hooks();
			$this->setup_constants();
		}

		/**
		 * Hooks used to run the plugin.
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function hooks() {

			add_action( 'analytify_add_submenu', array( $this, 'add_submenu' ), 40 );
			add_action( 'admin_enqueue_scripts', array( $this, 'admin_scripts' ) );
			add_action( 'analytify_dashboad_dropdown_option', array( $this, 'dashboad_dropdown_option' ), 8 );
			// for modifying the meta links.
			add_filter( 'plugin_row_meta', array( $this, 'plugin_row_meta' ), 10, 2 );
		}

		/**
		 * Plugin row meta links.
		 *
		 * @param array<int|string, mixed> $input Already defined meta links.
		 * @param string                   $file Plugin file path and name being processed.
		 * @return array<int|string, mixed> $input
		 */
		public function plugin_row_meta( $input, $file ): array {

			// exit if its other plugins.
			if ( 'wp-analytify-goals/wp-analytify-goals.php' !== $file ) {
				return $input; }

			// remove the 'view details' org link.
			if ( isset( $input[2] ) ) {
				unset( $input[2] );
			}

			// add the plugin site link.
			$input[] = '<a target="_blank" href="https://analytify.io/add-ons/google-analytics-goals-wordpress/">Visit plugin site</a>';

			return $input;
		}

		/**
		 * Define constant if not already set.
		 *
		 * @param  string      $name Constant name.
		 * @param  string|bool $value Constant value.
		 * @return void
		 */
		private function define( $name, $value ) {
			if ( ! defined( $name ) ) {
				define( $name, $value );
			}
		}

		/**
		 * Setup plugin constants
		 *
		 * @access      private
		 * @since       1.0.0
		 * @return      void
		 */
		private function setup_constants() {

			// Setting Global Values.
			$this->define( 'GOALS_ANALYTIFY_ADDON_PLUGIN_FILE', __FILE__ );
			$this->define( 'GOALS_ANALYTIFY_ADDON_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );
			$this->define( 'GOALS_ANALYTIFY_ADDON_PLUGIN_DIR', __DIR__ );
			$this->define( 'GOALS_ANALYTIFY_ADDON_PRODUCT_NAME', 'Analytify - Goals Addon' );
			$this->define( 'GOALS_ANALYTIFY_ADDON_PRODUCT_ID', '14243' );
			$this->define( 'GOALS_ANALYTIFY_ADDON_STORE_URL', 'https://analytify.io' );
		}

		/**
		 * Load Admin Scripts.
		 *
		 * @since 1.0
		 * @param string $page Page identifier.
		 * @return void
		 */
		public function admin_scripts( $page ) {
			if ( 'analytify_page_analytify-settings' === $page ) {
				// Script enqueuing will be added here when needed.
				// Placeholder for future script enqueuing.
				return;
			}
		}

		/**
		 * Create Submenu under Analytify
		 *
		 * @since 1.0
		 * @return void
		 */
		public function add_submenu() {
			$analytify_nick = defined( 'ANALYTIFY_NICK' ) ? ANALYTIFY_NICK : '';
			add_submenu_page( 'analytify-dashboard', $analytify_nick . ' Goals (Key Events)', __( 'Goals (Key Events)', 'wp-analytify-pro' ), 'manage_options', 'analytify-goals', array( $this, 'pa_page_file_path' ), 30 );
		}

		/**
		 * Analytify Goal Page callback.
		 *
		 * @since 1.0
		 * @return void
		 */
		public function pa_page_file_path() {
			$goals_addon_root_path = defined( 'ANALYTIFY_GOALS_ADDON_ROOT_PATH' ) ? ANALYTIFY_GOALS_ADDON_ROOT_PATH : __DIR__;

			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- GET parameter used for navigation only.
			if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {
				// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- GET parameter used for navigation only.
				if ( isset( $_GET['goal_id'] ) && ! empty( sanitize_text_field( wp_unslash( $_GET['goal_id'] ) ) ) ) {
					include_once $goals_addon_root_path . 'includes/analytify-goals-detail-view.php';
				} else {
					include_once $goals_addon_root_path . '/includes/analytify-goals-view.php';
				}
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- GET parameter used for navigation only.
			} elseif ( isset( $_GET['goal_id'] ) && ! empty( sanitize_text_field( wp_unslash( $_GET['goal_id'] ) ) ) ) {
					include_once $goals_addon_root_path . 'includes/analytify-goals-detail-view-deprecated.php';
			} else {
				include_once $goals_addon_root_path . 'includes/analytify-goals-view-deprecated.php';
			}
		}

		/**
		 * Add dropdown option for goals dashboard.
		 *
		 * @return void
		 */
		public function dashboad_dropdown_option() {
			echo '<li><a href="' . esc_url( admin_url( 'admin.php?page=analytify-goals' ) ) . '">' . esc_html__( 'Goals', 'wp-analytify-pro' ) . '</a></li>';
		}
	}


	new WP_Analytify_Goals();
}
