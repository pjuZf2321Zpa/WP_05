<?php
/**
 * Forms Submission Tracking Class.
 *
 * @package WP_Analytify_Pro
 */

// phpcs:ignoreFile WordPress.Files.FileName.InvalidClassFileName

if ( ! class_exists( 'AnalytifyFormsSubmissionTracking' ) ) {
	/**
	 * Class that is used to make 'submission' calls to the Google Analytics API.
	 * Handles both UA and GA4 calls.
	 */
	class AnalytifyFormsSubmissionTracking {

		/**
		 * The single instance of the class.
		 *
		 * @var self|null
		 */
		private static $instance;

		/**
		 * Donation/payment IDs already sent for GiveWP GA4 (avoids duplicate events when both legacy and model hooks run).
		 *
		 * @var array<int, true>
		 */
		private static $givewp_submission_sent = array();

		/**
		 * Supported forms (combined from both feature branches).
		 *
		 * @var array<string>
		 */
		private $can_track = array( 'cf7', 'wpforms', 'ninjaforms', 'gravityforms', 'formidable', 'fluentforms', 'happyforms', 'forminator', 'givewp', 'weforms', 'elementor', 'mailpoet', 'wsforms' );

		/**
		 * Whether to track GA4 events.
		 *
		 * @var bool
		 */
		private $track_ga4 = false;

		/**
		 * Returns the single instance of the class.
		 *
		 * @return self Class instance
		 */
		public static function get_instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		/**
		 * Class constructor.
		 */
		private function __construct() {

			$this->track_ga4 = class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode();

			$this->hooks();
		}

		/**
		 * Register all the hooks for the class.
		 *
		 * @return void
		 */
		private function hooks() {

			// Contact Form 7.
			add_action( 'wpcf7_before_send_mail', array( $this, 'submission_contact_form_7' ), 15, 1 );

			// WPForms.
			add_action( 'wpforms_process_entry_save', array( $this, 'submission_wpforms' ), 10, 4 );

			// Ninja Forms.
			add_action( 'ninja_forms_after_submission', array( $this, 'submission_ninja_forms' ) );

			// Gravity Forms.
			add_action( 'gform_after_submission', array( $this, 'submission_gravityforms' ), 10, 2 );

			// Formidable Forms.
			add_action( 'frm_after_create_entry', array( $this, 'submission_formidable' ), 30, 2 );

			// Fluent Forms (use namespaced hook; old name triggers deprecation during AJAX).
			add_action( 'fluentform/before_submission_confirmation', array( $this, 'submission_fluentforms_save' ), 10, 3 );

			// Happyforms.
			add_action( 'happyforms_submission_success', array( $this, 'submission_happyforms' ), 10, 3 );

			// Forminator (custom forms only; preview AJAX skipped in callback).
			add_action( 'forminator_form_after_save_entry', array( $this, 'submission_forminator' ), 10, 2 );
			add_action( 'forminator_form_after_handle_submit', array( $this, 'submission_forminator' ), 10, 2 );

			// GiveWP: legacy completion hook (still used when status moves to complete via legacy pipeline).
			add_action( 'give_complete_form_donation', array( $this, 'submission_givewp' ), 10, 3 );

			// GiveWP: fires on status change before give_complete_purchase; catches completions when give_complete_form_donation
			// is skipped (e.g. completed_date already set) and aligns with DispatchGiveUpdatePaymentStatus / legacy gateways.
			add_action( 'give_update_payment_status', array( $this, 'submission_givewp_payment_status' ), 5, 3 );

			// GiveWP 2.19+ / 4.x: donation model (covers gateways where legacy completion path is skipped or delayed).
			if ( class_exists( '\Give\Donations\Models\Donation' ) && class_exists( '\Give\Donations\ValueObjects\DonationStatus' ) ) {
				add_action( 'givewp_donation_created', array( $this, 'submission_givewp_donation_created' ), 10, 1 );
				add_action( 'givewp_donation_updated', array( $this, 'submission_givewp_donation_updated' ), 5, 1 );
			}

			// weForms (successful entry saved).
			add_action( 'weforms_entry_submission', array( $this, 'submission_weforms' ), 10, 4 );

			// Elementor Pro.
			add_action( 'elementor_pro/forms/new_record', array( $this, 'submission_elementor' ), 10, 2 );

			// MailPoet.
			add_action( 'mailpoet_subscription_before_subscribe', array( $this, 'submission_mailpoet' ), 10, 3 );

			// WS Forms.
			add_action( 'wsf_submit_post_complete', array( $this, 'submission_wsforms' ), 10, 1 );

			// GiveWP: numeric form ID on .give-embed-form-wrapper for campaign / modal launcher pages.
			add_filter( 'give_donate_form', array( $this, 'give_donate_form_add_data_form_id' ), 10, 2 );

			// GiveWP 3+ block / shortcode: .root-data-givewp-embed (not covered by give_donate_form).
			add_filter( 'render_block', array( $this, 'givewp_donation_form_render_block_add_data_form_id' ), 10, 2 );
			add_filter( 'givewp_form_shortcode_output', array( $this, 'givewp_form_shortcode_output_add_data_form_id' ), 25, 2 );
		}

		/**
		 * Whether GiveWP form tracking is enabled in Analytify settings.
		 *
		 * @return bool
		 */
		private function analytify_forms_tracking_givewp_enabled() {
			if ( ! is_object( $GLOBALS['WP_ANALYTIFY'] ) || ! isset( $GLOBALS['WP_ANALYTIFY']->settings ) || ! is_object( $GLOBALS['WP_ANALYTIFY']->settings ) || ! method_exists( $GLOBALS['WP_ANALYTIFY']->settings, 'get_option' ) ) {
				return false;
			}
			return 'on' === $GLOBALS['WP_ANALYTIFY']->settings->get_option( 'track_givewp', 'wp-analytify-forms' );
		}

		/**
		 * Adds data-analytify-give-form-id on GiveWP 3+ embed root (.root-data-givewp-embed).
		 *
		 * @param string $html    Block or shortcode HTML.
		 * @param int    $form_id Donation form post ID.
		 *
		 * @return string
		 */
		private function inject_givewp_v3_embed_analytify_form_id( $html, $form_id ) {
			if ( ! is_string( $html ) || false === strpos( $html, 'root-data-givewp-embed' ) ) {
				return $html;
			}
			if ( ! $this->analytify_forms_tracking_givewp_enabled() ) {
				return $html;
			}
			$form_id = absint( $form_id );
			if ( $form_id < 1 || false !== strpos( $html, 'data-analytify-give-form-id=' ) ) {
				return $html;
			}
			$fid     = esc_attr( (string) $form_id );
			$updated = preg_replace( '/(<div\s+class=\'root-data-givewp-embed\')/', '$1 data-analytify-give-form-id="' . $fid . '" ', $html, 1 );
			if ( ! is_string( $updated ) || $updated === $html ) {
				$updated = preg_replace( '/(<div\s+class="root-data-givewp-embed")/', '$1 data-analytify-give-form-id="' . $fid . '" ', $html, 1 );
			}

			return is_string( $updated ) ? $updated : $html;
		}

		/**
		 * Gutenberg givewp/donation-form block: expose form ID for parent-page impression JS.
		 *
		 * @param string               $block_content Block HTML.
		 * @param array<string, mixed> $block         Parsed block.
		 *
		 * @return string
		 */
		public function givewp_donation_form_render_block_add_data_form_id( $block_content, $block ) {
			if ( empty( $block['blockName'] ) || 'givewp/donation-form' !== $block['blockName'] ) {
				return $block_content;
			}
			$form_id = isset( $block['attrs']['formId'] ) ? absint( $block['attrs']['formId'] ) : 0;

			return $this->inject_givewp_v3_embed_analytify_form_id( $block_content, $form_id );
		}

		/**
		 * GiveWP v3 [give_form] output: same root markup as the block; add form id for impressions.
		 *
		 * @param string               $html Shortcode HTML after Give filters.
		 * @param array<string, mixed> $atts Shortcode attributes.
		 *
		 * @return string
		 */
		public function givewp_form_shortcode_output_add_data_form_id( $html, $atts ) {
			if ( ! is_array( $atts ) || empty( $atts['id'] ) ) {
				return $html;
			}

			return $this->inject_givewp_v3_embed_analytify_form_id( $html, absint( $atts['id'] ) );
		}

		/**
		 * Adds data-analytify-give-form-id on the embed wrapper so JS can fire an impression on the parent page.
		 *
		 * @param string               $html  Shortcode HTML.
		 * @param array<string, mixed> $atts  Shortcode attributes (includes id = donation form post ID).
		 *
		 * @return string
		 */
		public function give_donate_form_add_data_form_id( $html, $atts ) {
			if ( ! is_string( $html ) || false === strpos( $html, 'give-embed-form-wrapper' ) ) {
				return $html;
			}
			if ( ! $this->analytify_forms_tracking_givewp_enabled() ) {
				return $html;
			}
			if ( ! is_array( $atts ) || empty( $atts['id'] ) ) {
				return $html;
			}
			$form_id = absint( $atts['id'] );
			if ( $form_id < 1 ) {
				return $html;
			}
			$updated = preg_replace(
				'/(<div\s+class="give-embed-form-wrapper[^"]*")/',
				'$1 data-analytify-give-form-id="' . esc_attr( (string) $form_id ) . '"',
				$html,
				1
			);

			return is_string( $updated ) ? $updated : $html;
		}

		/**
		 * Tracks submission of a contact form 7 form.
		 *
		 * @param object $form_data The form data.
		 *
		 * @return void
		 */
		public function submission_contact_form_7( $form_data ) {
			if ( ! $this->should_track( 'cf7' ) ) {
				return;
			}

			$form_id = method_exists( $form_data, 'id' ) ? $form_data->id() : 0;
			$event   = array(
				'category' => 'analytify_form_wpcf7',
				'label'    => (string) $form_id,
			);
			$this->track_form_submission( $event );
		}

		/**
		 * Tracks submission of a WPForms form.
		 *
		 * @param array<string, mixed> $fields    The form fields.
		 * @param array<string, mixed> $entry     The entry data.
		 * @param int                  $form_id   The form ID.
		 * @param array<string, mixed> $form_data The form data.
		 *
		 * @return void
		 */
		// phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed
		public function submission_wpforms( $fields, $entry, $form_id, $form_data ) {
			if ( ! $this->should_track( 'wpforms' ) ) {
				return;
			}

			$event = array(
				'category' => 'analytify_form_wpforms',
				'label'    => (string) $form_id,
			);
			$this->track_form_submission( $event );
		}

		/**
		 * Tracks submission of a Ninja Forms.
		 *
		 * @param array<string, mixed> $data Form data.
		 *
		 * @return void
		 */
		public function submission_ninja_forms( $data ) {
			if ( ! $this->should_track( 'ninjaforms' ) ) {
				return;
			}

			$event = array(
				'category' => 'analytify_form_ninja_forms',
				'label'    => (string) $data['form_id'],
			);
			$this->track_form_submission( $event );
		}

		/**
		 * Tracks submission of a Gravity Forms.
		 *
		 * @param array<string, mixed> $entry The entry data.
		 * @param array<string, mixed> $form  The form data.
		 *
		 * @return void
		 */
		public function submission_gravityforms( $entry, $form ) {
			if ( ! $this->should_track( 'gravityforms' ) ) {
				return;
			}

			// Get form ID from form array or entry array.
			$form_id = '';
			if ( isset( $form['id'] ) && ! empty( $form['id'] ) ) {
				$form_id = $form['id'];
			} elseif ( isset( $entry['form_id'] ) && ! empty( $entry['form_id'] ) ) {
				$form_id = $entry['form_id'];
			} else {
				return; // Don't track if we can't get the form ID.
			}

			$event = array(
				'category' => 'analytify_form_gf',
				'label'    => (string) $form_id,
			);
			$this->track_form_submission( $event );
		}

		/**
		 * Tracks submission of a Formidable Forms.
		 *
		 * @param int $entry_id The entry ID.
		 * @param int $form_id  The form ID.
		 *
		 * @return void
		 */
		public function submission_formidable( $entry_id, $form_id ) {
			if ( ! $this->should_track( 'formidable' ) ) {
				return;
			}

			$event = array(
				'category' => 'analytify_form_formidable',
				'label'    => (string) $form_id,
			);
			$this->track_form_submission( $event );
		}

		/**
		 * Tracks submission of a Fluent Forms.
		 *
		 * @param int    $insertId Form entry insert ID.
		 * @param object $formData Form Entry.
		 * @param object $form     Form Data.
		 * @return void
		 */
		// phpcs:ignore WordPress.NamingConventions.ValidVariableName.VariableNotSnakeCase
		public function submission_fluentforms_save( $insertId, $formData, $form ) {
			if ( ! $this->should_track( 'fluentforms' ) ) {
				return;
			}

			$form_id = isset( $form->id ) ? $form->id : 0;
			$event   = array(
				'category' => 'analytify_form_fluentforms',
				'label'    => (string) $form_id,
			);
			$this->track_form_submission( $event );
		}

		/**
		 * Tracks submission of a Happyforms form.
		 *
		 * @since 9.1.0
		 *
		 * @param array<string, mixed> $submission Submission data.
		 * @param array<string, mixed> $form       Current form data.
		 * @param array<string, mixed> $extra      Extra data from Happyforms.
		 *
		 * @return void
		 */
		// phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found -- Signature matches happyforms_submission_success; only $form is used.
		public function submission_happyforms( $submission, $form, $extra = array() ) {
			if ( ! $this->should_track( 'happyforms' ) ) {
				return;
			}

			if ( empty( $form['ID'] ) ) {
				return;
			}

			$event = array(
				'category' => 'analytify_form_happyforms',
				'label'    => (string) $form['ID'],
			);
			$this->track_form_submission( $event );
		}

		/**
		 * Tracks submission of a Forminator custom form.
		 *
		 * Fires on forminator_form_after_save_entry (AJAX) or forminator_form_after_handle_submit
		 * (non-AJAX). Only one runs per submission.
		 *
		 * @since 9.1.0
		 *
		 * @param int                  $form_id  Forminator form ID.
		 * @param array<string, mixed> $response Submit response from Forminator.
		 *
		 * @return void
		 */
		public function submission_forminator( $form_id, $response ) {
			if ( ! $this->should_track( 'forminator' ) ) {
				return;
			}

			// Skip admin/editor preview submissions (same hook as live saves).
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only check for request context.
			if ( isset( $_REQUEST['action'] ) && is_string( $_REQUEST['action'] ) && false !== strpos( $_REQUEST['action'], 'submit_preview_form' ) ) {
				return;
			}

			if ( ! is_array( $response ) || empty( $response['success'] ) ) {
				return;
			}

			$form_id = (int) $form_id;
			if ( $form_id < 1 ) {
				return;
			}

			$event = array(
				'category' => 'analytify_form_forminator',
				'label'    => (string) $form_id,
			);
			$this->track_form_submission( $event );
		}

		/**
		 * Tracks a completed GiveWP donation (fires once per completed payment).
		 *
		 * @since 9.1.0
		 *
		 * @param int                  $form_id       Give donation form post ID.
		 * @param int                  $payment_id    Donation/payment ID.
		 * @param array<string, mixed> $payment_meta  Payment meta.
		 *
		 * @return void
		 */
		// phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found -- Signature matches give_complete_form_donation; $payment_meta unused.
		public function submission_givewp( $form_id, $payment_id, $payment_meta ) {
			if ( ! $this->should_track( 'givewp' ) ) {
				return;
			}
			$this->send_givewp_submission_event( (int) $form_id, (int) $payment_id );
		}

		/**
		 * GiveWP: track donation when payment status moves to completed (publish/complete).
		 *
		 * Mirrors give_complete_purchase() entry checks. Runs at priority 5 so it fires before
		 * give_complete_purchase (100), including when give_complete_form_donation does not run.
		 *
		 * @since 9.1.0
		 *
		 * @param int    $payment_id Payment / donation post ID.
		 * @param string $new_status New post status.
		 * @param string $old_status Previous post status.
		 *
		 * @return void
		 */
		public function submission_givewp_payment_status( $payment_id, $new_status, $old_status ) {
			if ( ! $this->should_track( 'givewp' ) ) {
				return;
			}

			$new_status = is_string( $new_status ) ? strtolower( $new_status ) : '';
			$old_status = is_string( $old_status ) ? strtolower( $old_status ) : '';

			if ( in_array( $old_status, array( 'publish', 'complete' ), true ) ) {
				return;
			}
			if ( ! in_array( $new_status, array( 'publish', 'complete' ), true ) ) {
				return;
			}

			$payment_id = absint( $payment_id );
			if ( $payment_id < 1 || ! class_exists( 'Give_Payment' ) ) {
				return;
			}

			$payment = new \Give_Payment( $payment_id );
			$form_id = isset( $payment->form_id ) ? absint( $payment->form_id ) : 0;
			if ( $form_id < 1 ) {
				return;
			}

			$this->send_givewp_submission_event( $form_id, $payment_id );
		}

		/**
		 * GiveWP: donation created already in a completed state (e.g. test gateway, instant completion).
		 *
		 * @param \Give\Donations\Models\Donation $donation Donation model.
		 *
		 * @return void
		 */
		public function submission_givewp_donation_created( $donation ) {
			if ( ! $donation instanceof \Give\Donations\Models\Donation ) {
				return;
			}
			if ( ! $this->should_track( 'givewp' ) ) {
				return;
			}
			if ( ! $donation->status->isComplete() ) {
				return;
			}
			$this->send_givewp_submission_event( (int) $donation->formId, (int) $donation->id );
		}

		/**
		 * GiveWP: donation status updated to complete (e.g. after Stripe/PayPal confirms payment).
		 *
		 * @param \Give\Donations\Models\Donation $donation Donation model.
		 *
		 * @return void
		 */
		public function submission_givewp_donation_updated( $donation ) {
			if ( ! $donation instanceof \Give\Donations\Models\Donation ) {
				return;
			}
			if ( ! $this->should_track( 'givewp' ) ) {
				return;
			}
			if ( ! $donation->isDirty( 'status' ) ) {
				return;
			}
			if ( ! $donation->status->isComplete() ) {
				return;
			}
			$original = $donation->getOriginal( 'status' );
			if ( $original instanceof \Give\Donations\ValueObjects\DonationStatus && $original->isComplete() ) {
				return;
			}
			$this->send_givewp_submission_event( (int) $donation->formId, (int) $donation->id );
		}

		/**
		 * Send one GA4 submission per donation ID for GiveWP.
		 *
		 * @param int $form_id     Give donation form post ID.
		 * @param int $donation_id Donation / payment ID for deduplication (0 skips dedupe key).
		 *
		 * @return void
		 */
		private function send_givewp_submission_event( $form_id, $donation_id = 0 ) {
			$form_id = (int) $form_id;
			if ( $form_id < 1 ) {
				return;
			}
			if ( $donation_id > 0 ) {
				if ( isset( self::$givewp_submission_sent[ $donation_id ] ) ) {
					return;
				}
				self::$givewp_submission_sent[ $donation_id ] = true;
			}
			$event = array(
				'category' => 'analytify_form_givewp',
				'label'    => (string) $form_id,
			);
			$this->track_form_submission( $event );
		}

		/**
		 * Tracks a weForms entry after it is stored.
		 *
		 * @since 9.1.0
		 *
		 * @param int                  $entry_id      Entry ID.
		 * @param int                  $form_id       Form ID.
		 * @param int                  $page_id       Page ID where the form was submitted.
		 * @param array<string, mixed> $form_settings Form settings.
		 *
		 * @return void
		 */
		// phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found -- Signature matches weforms_entry_submission; only $form_id is used.
		public function submission_weforms( $entry_id, $form_id, $page_id, $form_settings ) {
			if ( ! $this->should_track( 'weforms' ) ) {
				return;
			}

			$form_id = (int) $form_id;
			if ( $form_id < 1 ) {
				return;
			}

			$event = array(
				'category' => 'analytify_form_weforms',
				'label'    => (string) $form_id,
			);
			$this->track_form_submission( $event );
		}

		/**
		 * Tracks submission of an Elementor Pro form (successful flow only).
		 *
		 * @param object $record       Elementor Form_Record instance.
		 * @param object $ajax_handler Elementor Ajax_Handler instance.
		 * @return void
		 */
		public function submission_elementor( $record, $ajax_handler ) {
			if ( ! $this->should_track( 'elementor' ) ) {
				return;
			}

			if ( ! is_object( $ajax_handler ) || ! property_exists( $ajax_handler, 'is_success' ) || ! $ajax_handler->is_success ) {
				return;
			}

			$form_id = '';
			if ( is_object( $record ) && method_exists( $record, 'get_form_settings' ) ) {
				$fid = $record->get_form_settings( 'id' );
				if ( null !== $fid && '' !== $fid ) {
					$form_id = (string) $fid;
				}
			}
			if ( '' === $form_id ) {
				// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Elementor AJAX submit context.
				$form_id = isset( $_POST['form_id'] ) ? sanitize_text_field( wp_unslash( $_POST['form_id'] ) ) : '';
			}
			if ( '' === $form_id ) {
				return;
			}

			$event = array(
				'category' => 'analytify_form_elementor',
				'label'    => $form_id,
			);
			$this->track_form_submission( $event );
		}

		/**
		 * Tracks submission of a MailPoet form.
		 *
		 * @param array  $data        Subscription data.
		 * @param array  $segment_ids Segment IDs.
		 * @param object $form        MailPoet form entity.
		 * @return void
		 */
		public function submission_mailpoet( $data, $segment_ids, $form ) {
			if ( ! $this->should_track( 'mailpoet' ) ) {
				return;
			}

			$form_id = 0;
			if ( is_object( $form ) && method_exists( $form, 'getId' ) ) {
				$form_id = $form->getId();
			} elseif ( is_object( $form ) && isset( $form->id ) ) {
				$form_id = $form->id;
			}

			$event = array(
				'category' => 'analytify_form_mailpoet',
				'label'    => (string) $form_id,
			);
			$this->track_form_submission( $event );
		}

		/**
		 * Tracks submission of a WS Forms form.
		 * Hook: wsf_submit_post_complete (runs when form has been successfully posted).
		 *
		 * @param object $submit The submit object (WS_Form_Submit).
		 * @return void
		 */
		public function submission_wsforms( $submit ) {
			if ( ! $this->should_track( 'wsforms' ) ) {
				return;
			}

			// Get form ID from submit object (normalize to int for consistent GA labels).
			$form_id = 0;
			if ( is_object( $submit ) && isset( $submit->form_id ) ) {
				$form_id = (int) $submit->form_id;
			} elseif ( is_array( $submit ) && isset( $submit['form_id'] ) ) {
				$form_id = (int) $submit['form_id'];
			} else {
				return; // Don't track if we can't get the form ID.
			}

			$event = array(
				'category' => 'analytify_form_wsforms',
				'label'    => (string) $form_id,
			);
			$this->track_form_submission( $event );
		}

		/**
		 * Checks from the settings, if the form should be tracked or not.
		 *
		 * @param string $form Form name.
		 *
		 * @return boolean
		 */
		private function should_track( $form ) {

			// Should this user be tracked?
			if ( function_exists( 'analytify_is_track_user' ) && false === analytify_is_track_user() ) {
				return false;
			}

			// Form is supported?
			if ( ! in_array( $form, $this->can_track, true ) ) {
				return false;
			}

			// Is this form tracking enabled?
			if ( 'on' !== $GLOBALS['WP_ANALYTIFY']->settings->get_option( 'track_' . $form, 'wp-analytify-forms' ) ) {
				return false;
			}

			return true;
		}

		/**
		 * Track form data.
		 * Checks for GA4 or UA tracking.
		 *
		 * @param array<string, mixed> $event_data The event data.
		 *
		 * @return void
		 */
		private function track_form_submission( $event_data ) {

			$event_data['uid'] = '';

			if ( class_exists( 'WP_Analytify_Settings' ) ) {
				$settings = new WP_Analytify_Settings();
				if ( is_user_logged_in() && method_exists( $settings, 'get_option' ) && $settings->get_option( 'track_user_id', 'wp-analytify-advanced' ) ) {
					$event_data['uid'] = get_current_user_id();
				}
			}

			if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {

				// GA4 Tracking.
				$event = array(
					'name'   => 'analytify_form',
					'params' => array(
						'wpa_link_action' => 'submission',
						'wpa_category'    => $event_data['category'],
						'wpa_link_label'  => $event_data['label'],
					),
				);

				if ( $event_data['uid'] ) {
					$event['params']['uid'] = $event_data['uid'];
				}

				if ( ! function_exists( 'analytify_mp_ga4' ) ) {
					$mp_file = ( defined( 'WP_ANALYTIFY_PLUGIN_DIR' ) ? WP_ANALYTIFY_PLUGIN_DIR : WP_PLUGIN_DIR . '/wp-analytify' ) . '/classes/analytify-mp-ga4.php';
					if ( file_exists( $mp_file ) ) {
						require_once $mp_file;
					}
				}
				if ( function_exists( 'analytify_mp_ga4' ) ) {
					analytify_mp_ga4( array( $event ) );
				}
			}
		}
	}
}

AnalytifyFormsSubmissionTracking::get_instance();