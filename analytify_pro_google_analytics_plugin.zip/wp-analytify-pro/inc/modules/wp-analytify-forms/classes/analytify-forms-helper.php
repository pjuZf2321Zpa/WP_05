<?php
/**
 * Forms Helper Class.
 *
 * @package WP_Analytify_Pro
 */

// phpcs:ignoreFile WordPress.Files.FileName.InvalidClassFileName, Universal.Files.SeparateFunctionsFromOO.Mixed

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A class that contains helper methods for the forms add-on.
 */
class AnalytifyAddonFormHelper {

	/**
	 * Returns the Form Title based on their ID and event category
	 *
	 * @param int    $id             Form ID.
	 * @param string $event_category Event Category.
	 * @return int|string
	 */
	public static function get_form_name( $id, $event_category ) {

		if ( 'analytify_form_wpcf7' === $event_category && class_exists( 'WPCF7_ContactForm' ) && is_callable( 'WPCF7_ContactForm::get_instance' ) ) {

			// For CF7.
			$wpcf7 = WPCF7_ContactForm::get_instance( $id );
			if ( $wpcf7 && $wpcf7->title() ) {
				return $wpcf7->title();
			}
		} elseif ( 'analytify_form_wpforms' === $event_category ) {

			// For WPForms.
			if ( get_post( $id ) ) {
				return get_the_title( $id );
			}
		} elseif ( 'analytify_form_ninja_forms' === $event_category && class_exists( 'Ninja_Forms' ) && method_exists( 'Ninja_Forms', 'get_setting' ) && function_exists( 'Ninja_Forms' ) ) {

			// For Ninja Forms.
			return Ninja_Forms()->form( $id )->get()->get_setting( 'title' );
		} elseif ( 'analytify_form_gf' === $event_category && class_exists( 'GFAPI' ) && is_callable( 'GFAPI::get_form' ) ) {

			// For Gravity Forms.
			$gravity_form = GFAPI::get_form( $id );
			if ( $gravity_form && isset( $gravity_form['title'] ) && ! empty( $gravity_form['title'] ) ) {
				return $gravity_form['title'];
			}
		} elseif ( 'analytify_form_formidable' === $event_category && class_exists( 'FrmForm' ) && is_callable( 'FrmForm::getName' ) ) {

			// FormFormidable Forms.
			$formidable_name = FrmForm::getName( $id );
			if ( isset( $formidable_name ) && ! empty( $formidable_name ) ) {
				return $formidable_name;
			}
		} elseif ( 'analytify_form_fluentforms' === $event_category && function_exists( 'wpFluent' ) ) {

			// Fluent Forms.
			$fluent_form = wpFluent()->table( 'fluentform_forms' )->find( $id );
			if ( $fluent_form && isset( $fluent_form->title ) && ! empty( $fluent_form->title ) ) {
				return $fluent_form->title;
			}
		} elseif ( 'analytify_form_happyforms' === $event_category ) {

			// Happyforms (form posts use post type happyform).
			$happy_post = get_post( (int) $id );
			if ( $happy_post && 'happyform' === $happy_post->post_type ) {
				return get_the_title( $happy_post );
			}
		} elseif ( 'analytify_form_forminator' === $event_category ) {

			// Forminator custom forms (post type forminator_forms).
			$fin_post = get_post( (int) $id );
			if ( $fin_post && 'forminator_forms' === $fin_post->post_type ) {
				if ( class_exists( 'Forminator_Base_Form_Model' ) && class_exists( 'Forminator_Form_Model' ) && method_exists( 'Forminator_Base_Form_Model', 'get_model' ) ) {
					$fin_model = Forminator_Base_Form_Model::get_model( (int) $id );
					if ( $fin_model instanceof Forminator_Form_Model && ! empty( $fin_model->name ) ) {
						return $fin_model->name;
					}
				}

				return get_the_title( $fin_post );
			}
		} elseif ( 'analytify_form_givewp' === $event_category ) {

			// GiveWP donation forms (post type give_forms).
			$give_post = get_post( (int) $id );
			if ( $give_post && 'give_forms' === $give_post->post_type ) {
				return get_the_title( $give_post );
			}
		} elseif ( 'analytify_form_weforms' === $event_category ) {

			// weForms (post type wpuf_contact_form).
			$we_post = get_post( (int) $id );
			if ( $we_post && 'wpuf_contact_form' === $we_post->post_type ) {
				return get_the_title( $we_post );
			}
		} elseif ( 'analytify_form_wsforms' === $event_category && class_exists( 'WS_Form' ) ) {

			// WS Forms: db_read() throws if the form was deleted or ID in GA does not match a form row.
			try {
				if ( function_exists( 'ws_form_form_get_object' ) ) {
					$ws_form = ws_form_form_get_object( $id );
					if ( is_object( $ws_form ) && isset( $ws_form->label ) && ! empty( $ws_form->label ) ) {
						return $ws_form->label;
					}
				} elseif ( class_exists( 'WS_Form_Form' ) && method_exists( 'WS_Form_Form', 'db_read' ) ) {
					$ws_form = new WS_Form_Form();
					$ws_form->id = $id;
					$ws_form->db_read();
					if ( isset( $ws_form->label ) && ! empty( $ws_form->label ) ) {
						return $ws_form->label;
					}
				}
			} catch ( \Throwable $e ) { // phpcs:ignore Generic.CodeAnalysis.EmptyStatement.DetectedCatch -- WS Form throws on missing form; use fallback label.
				unset( $e );
			}
			if ( get_post( $id ) ) {
				return get_the_title( $id );
			}
			// translators: %d: WS Form ID that could not be resolved.
			return sprintf( __( 'WS Form #%d', 'wp-analytify-pro' ), (int) $id );
		} elseif ( 'analytify_form_custom' === $event_category ) {

			// For Custom Forms, the ID is the form name/identifier itself (from name or id attribute).
			// Return it as-is, don't convert to integer.
			return $id;

		} elseif ( 'analytify_form_elementor' === $event_category && class_exists( 'Elementor\Plugin' ) ) {

			// For Elementor Forms.
			$elementor_form = \Elementor\Plugin::$instance->documents->get( $id );
			if ( $elementor_form && $elementor_form->get_title() ) {
				return $elementor_form->get_title();
			}

		} elseif ( 'analytify_form_mailpoet' === $event_category && class_exists( 'MailPoet\Models\Form' ) ) {

			// For MailPoet Forms.
			$mailpoet_form = \MailPoet\Models\Form::findOne( $id );
			if ( $mailpoet_form && $mailpoet_form->name ) {
				return $mailpoet_form->name;
			}

		} elseif ( 'analytify_form_hubspot' === $event_category ) {
			// For HubSpot Forms
			// HubSpot forms are identified by their form ID
			// The form ID is in the format: c0145bda-cfc9-4749-96b4-7bf4896c7d58
			return 'HubSpot Form (' . $id . ')';
		} elseif ( 'analytify_form_jotform' === $event_category ) {
			// For HubSpot Forms
			// HubSpot forms are identified by their form ID
			// The form ID is in the format: c0145bda-cfc9-4749-96b4-7bf4896c7d58
			return 'Jotform Form (' . $id . ')';
		}

		// For other form types that don't match above, return ID as integer (fallback).
		return (int) $id;
	}

	/**
	 * Whether WS Forms (free or PRO) is active.
	 *
	 * Free uses `ws-form/ws-form.php`. PRO-only installs use `ws-form-pro/ws-form.php`
	 * (the free plugin is not active in that case).
	 *
	 * @since 9.0.0
	 * @return bool
	 */
	public static function is_ws_form_plugin_active() {
		if ( ! function_exists( 'is_plugin_active' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		return is_plugin_active( 'ws-form/ws-form.php' ) || is_plugin_active( 'ws-form-pro/ws-form.php' );
	}

	/**
	 * Whether a wp-analytify-forms checkbox option is enabled (matches stored on/bool/1 shapes).
	 *
	 * @param string $option_name Field name under wp-analytify-forms.
	 * @return bool
	 */
	private static function is_forms_tracking_option_on( $option_name ) {
		if ( ! isset( $GLOBALS['WP_ANALYTIFY'] ) || ! is_object( $GLOBALS['WP_ANALYTIFY'] ) || ! isset( $GLOBALS['WP_ANALYTIFY']->settings ) ) {
			return false;
		}
		$v = $GLOBALS['WP_ANALYTIFY']->settings->get_option( $option_name, 'wp-analytify-forms' );
		if ( 'on' === $v ) {
			return true;
		}
		if ( true === $v || 1 === $v || '1' === $v ) {
			return true;
		}
		if ( is_string( $v ) ) {
			$lower = strtolower( trim( $v ) );
			if ( in_array( $lower, array( 'yes', 'true' ), true ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * One dashboard block per event category (prevents duplicate IDs like section-analytify_form_hubspot).
	 *
	 * @param array<int, array<string, mixed>> $list Dashboard form rows.
	 * @return list<array<string, mixed>>
	 */
	private static function dedupe_forms_dashboard_by_category( array $list ) {
		$seen = array();
		$out  = array();
		foreach ( $list as $row ) {
			if ( ! is_array( $row ) || empty( $row['category'] ) || ! is_string( $row['category'] ) ) {
				continue;
			}
			$cat = $row['category'];
			if ( isset( $seen[ $cat ] ) ) {
				continue;
			}
			$seen[ $cat ] = true;
			$out[]         = $row;
		}
		return $out;
	}

	/**
	 * All the supported forms, except custom.
	 *
	 * @return array<int, array<string, string>>
	 */
	public static function get_supported_forms() {
		return array(
			array(
				'title'          => 'Contact Form 7',
				'option_name'    => 'track_cf7',
				'plugin_file'    => 'contact-form-7/wp-contact-form-7.php',
				'event_category' => 'analytify_form_wpcf7',
			),
			array(
				'title'          => 'WPForms',
				'option_name'    => 'track_wpforms',
				'plugin_file'    => 'wpforms-lite/wpforms.php',
				'event_category' => 'analytify_form_wpforms',
			),
			array(
				'title'          => 'Ninja Forms',
				'option_name'    => 'track_ninjaforms',
				'plugin_file'    => 'ninja-forms/ninja-forms.php',
				'event_category' => 'analytify_form_ninja_forms',
			),
			array(
				'title'          => 'Gravity Forms',
				'option_name'    => 'track_gravityforms',
				'plugin_file'    => 'gravityforms/gravityforms.php',
				'event_category' => 'analytify_form_gf',
			),
			array(
				'title'          => 'Formidable Forms',
				'option_name'    => 'track_formidable',
				'plugin_file'    => 'formidable/formidable.php',
				'event_category' => 'analytify_form_formidable',
			),
			array(
				'title'          => 'Fluent Forms',
				'option_name'    => 'track_fluentforms',
				'plugin_file'    => 'fluentform/fluentform.php',
				'event_category' => 'analytify_form_fluentforms',
			),
			array(
				'title'          => 'Happyforms',
				'option_name'    => 'track_happyforms',
				'plugin_file'    => 'happyforms/happyforms.php',
				'event_category' => 'analytify_form_happyforms',
			),
			array(
				'title'          => 'Forminator',
				'option_name'    => 'track_forminator',
				'plugin_file'    => 'forminator/forminator.php',
				'event_category' => 'analytify_form_forminator',
			),
			array(
				'title'          => 'GiveWP',
				'option_name'    => 'track_givewp',
				'plugin_file'    => 'give/give.php',
				'event_category' => 'analytify_form_givewp',
			),
			array(
				'title'          => 'weForms',
				'option_name'    => 'track_weforms',
				'plugin_file'    => 'weforms/weforms.php',
				'event_category' => 'analytify_form_weforms',
			),
			array(
				'title'          => 'Elementor Forms',
				'option_name'    => 'track_elementor',
				'plugin_file'    => 'elementor-pro/elementor-pro.php',
				'event_category' => 'analytify_form_elementor',
			),
			array(
				'title'          => 'Hubspot Forms',
				'option_name'    => 'track_hubspot',
				'plugin_file'    => 'leadin/leadin.php',
				'event_category' => 'analytify_form_hubspot',
			),
			array(
				'title'          => 'Jotforms',
				'option_name'    => 'track_jotform',
				'plugin_file'    => 'jotform-oembed/jotform-oembed.php',
				'event_category' => 'analytify_form_jotform',
			),
			array(
				'title'          => 'Mailpoet Forms',
				'option_name'    => 'track_mailpoet',
				'plugin_file'    => 'mailpoet/mailpoet.php',
				'event_category' => 'analytify_form_mailpoet',
			),
			array(
				'title'          => 'WS Forms',
				'option_name'    => 'track_wsforms',
				// Primary path is free; PRO-only installs use ws-form-pro/ws-form.php (see is_ws_form_plugin_active()).
				'plugin_file'    => 'ws-form/ws-form.php',
				'event_category' => 'analytify_form_wsforms',
			),
		);
	}

	/**
	 * Returns forms that should be displayed in the dashboard.
	 *
	 * @return list<array<string, mixed>>
	 */
	public static function get_forms_for_dashboard() {

		if ( ! function_exists( 'is_plugin_active' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		// Holds all the forms that have tracking enabled from settings and have active corresponding plugins.
		$analytify_tracking_forms = array();

		// All the supported forms, except custom.
		$registered_forms = self::get_supported_forms();

		foreach ( $registered_forms as $form ) {

			// Compatibility check added for wpforms.
			if ( 'WPForms' === $form['title'] && self::is_forms_tracking_option_on( $form['option_name'] ) && ( is_plugin_active( 'wpforms-lite/wpforms.php' ) || is_plugin_active( 'wpforms/wpforms.php' ) ) ) {
				$analytify_tracking_forms[] = array(
					'title'    => $form['title'],
					'category' => $form['event_category'],
				);
				continue;
			}

			// WS Forms: free or PRO (plugin basename differs for PRO-only installs).
			if ( 'WS Forms' === $form['title'] && self::is_forms_tracking_option_on( $form['option_name'] ) && self::is_ws_form_plugin_active() ) {
				$analytify_tracking_forms[] = array(
					'title'    => $form['title'],
					'category' => $form['event_category'],
				);
				continue;
			}

			if ( self::is_forms_tracking_option_on( $form['option_name'] ) && is_plugin_active( $form['plugin_file'] ) ) {
				$analytify_tracking_forms[] = array(
					'title'    => $form['title'],
					'category' => $form['event_category'],
				);
			}
		}

		// Check for custom forms.
		if ( self::is_forms_tracking_option_on( 'custom_form' ) ) {
			$analytify_tracking_forms[] = array(
				'title'    => 'Custom Forms',
				'category' => 'analytify_form_custom',
			);
		}

		return self::dedupe_forms_dashboard_by_category( $analytify_tracking_forms );
	}
}

// Formate stat rows.
add_filter( 'analytify_forms_row_format', 'analytify_forms_addon_row_formatter', 10, 5 );
/**
 * Formats a single api return to the stats array.
 *
 * @param array<string, mixed> $stats The main stats array.
 * @param string               $_ct   Event Category.
 * @param string               $_lb   Event Label.
 * @param string               $_ac   Event Action.
 * @param integer              $count View count.
 *
 * @return array<string, mixed>
 */
function analytify_forms_addon_row_formatter( $stats, $_ct, $_lb, $_ac, $count = 0 ) {
	if ( '(not set)' !== $_lb ) {

		// Add ID.
		if ( ! isset( $stats[ $_ct ]['stats'][ $_lb ]['id'] ) && 'analytify_form_custom' !== $_ct ) {
			$stats[ $_ct ]['stats'][ $_lb ]['id'] = $_lb;
		}

		// Add title, if missing.
		if ( ! isset( $stats[ $_ct ]['stats'][ $_lb ]['title'] ) ) {
			$stats[ $_ct ]['stats'][ $_lb ]['title'] = 'analytify_form_custom' === $_ct ? $_lb : AnalytifyAddonFormHelper::get_form_name( (int) $_lb, $_ct );
		}

		// Add default 'impression' and 'submission'.
		if ( ! isset( $stats[ $_ct ]['stats'][ $_lb ]['impression'] ) ) {
			$stats[ $_ct ]['stats'][ $_lb ]['impression'] = 0;
		}
		if ( ! isset( $stats[ $_ct ]['stats'][ $_lb ]['submission'] ) ) {
			$stats[ $_ct ]['stats'][ $_lb ]['submission'] = 0;
		}

		// Add views for submission and impression.
		$stats[ $_ct ]['stats'][ $_lb ][ $_ac ] = isset( $stats[ $_ct ]['stats'][ $_lb ][ $_ac ] ) ? $stats[ $_ct ]['stats'][ $_lb ][ $_ac ] + $count : $count;
	}
	return $stats;
}
