<?php
/**
 * Forms Loader.
 *
 * @package WP_Analytify_Pro
 */

// phpcs:ignoreFile WordPress.Files.FileName.InvalidClassFileName

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Analytify_Form_Loader
 *
 * Loads the Forms addon.
 */
class Analytify_Form_Loader {

	/**
	 * Singleton instance.
	 *
	 * @var self|null
	 */
	public static $instance;

	/**
	 * Version.
	 *
	 * @var string
	 */
	public $version;

	/**
	 * Get singleton instance.
	 *
	 * @return self
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->version = analytify_pro_get_asset_version();
		$this->define_constants();
		$this->hooks();
		$this->may_be_load_addon();
	}

	/**
	 * Load addon if requirements are met.
	 *
	 * @return void
	 */
	public function may_be_load_addon() {
		if (
			file_exists( WP_PLUGIN_DIR . '/wp-analytify-pro/wp-analytify-pro.php' )
			&& function_exists( 'wp_analytify_pro_load' )
			&& class_exists( 'WP_Analytify_Pro_Base' )
		) {
			$forms_addon_root_path = defined( 'ANALYTIFY_FORMS_ADDON_ROOT_PATH' ) ? ANALYTIFY_FORMS_ADDON_ROOT_PATH : __DIR__ . '/';
			include_once $forms_addon_root_path . '/classes/analytify-forms-dashboard.php';
		} else {
			add_action( 'admin_enqueue_scripts', array( $this, 'wpa_forms_notices_scripts' ) );
		}
	}

	/**
	 * Define constants.
	 *
	 * @return void
	 */
	public function define_constants() {
		$this->define( 'ANALYTIFY_FORMS_ADDON_VERSION', $this->version );
		$this->define( 'ANALYTIFY_FORMS_ADDON_ROOT_PATH', __DIR__ . '/' );
		$this->define( 'ANALYTIFY_FORM_ADDON_MIN_V_ANALYTIFY', '4.0.0' );
		$this->define( 'ANALYTIFY_FORM_ADDON_MIN_V_ANALYTIFY_PRO', '4.0.0' );
		$this->define( 'ANALYTIFY_FORMS_ADDON_CUSTOM_FORM_CLASS', 'analytify_form_custom' );
	}

	/**
	 * Setup hooks.
	 *
	 * @return void
	 */
	public function hooks() {
		add_action( 'admin_notices', array( $this, 'wpa_forms_notice_version_analytify' ) );
		add_action( 'admin_notices', array( $this, 'wpa_forms_notice_version_analytify_pro' ) );
		add_action( 'init', array( $this, 'wpa_forms_load_textdomain' ) );
	}

	/**
	 * Enqueue notice scripts.
	 *
	 * @return void
	 */
	public function wpa_forms_notices_scripts() {
		$forms_addon_version = defined( 'ANALYTIFY_FORMS_ADDON_VERSION' ) ? ANALYTIFY_FORMS_ADDON_VERSION : analytify_pro_get_asset_version();
		wp_enqueue_style( 'wpa-forms-notices-css', plugins_url( 'assets/css/notices' . analytify_pro_get_asset_suffix() . '.css', __FILE__ ), array(), $forms_addon_version );
	}

	/**
	 * Show version notice for Analytify.
	 *
	 * @return void
	 */
	public function wpa_forms_notice_version_analytify() {
		// get all plguins.
		$plugins = get_plugins();

		// check for the main plugin version.
		$min_version = defined( 'ANALYTIFY_FORM_ADDON_MIN_V_ANALYTIFY' ) ? ANALYTIFY_FORM_ADDON_MIN_V_ANALYTIFY : '4.0.0';
		if ( ! isset( $plugins['wp-analytify/wp-analytify.php'] ) || version_compare( $plugins['wp-analytify/wp-analytify.php']['Version'], $min_version, '<' ) ) {
			// translators: %s is the minimum version required
			$text    = sprintf( esc_html__( 'The minimum version of Analytify required for Analytify Forms addon is %s. You need to update Analytify Core (Free)', 'wp-analytify-pro' ), $min_version );
			$message = '<strong>' . esc_html__( 'Attention:', 'wp-analytify-pro' ) . '</strong>' . $text;
			$this->wpa_forms_notice( $message, 'wp-analytify-danger' );
		}
	}

	/**
	 * Show version notice for Analytify Pro.
	 *
	 * @return void
	 */
	public function wpa_forms_notice_version_analytify_pro() {

		$plugins         = get_plugins();
		$min_version_pro = defined( 'ANALYTIFY_FORM_ADDON_MIN_V_ANALYTIFY_PRO' ) ? ANALYTIFY_FORM_ADDON_MIN_V_ANALYTIFY_PRO : '4.0.0';

		if ( ! isset( $plugins['wp-analytify-pro/wp-analytify-pro.php'] ) || version_compare( $plugins['wp-analytify-pro/wp-analytify-pro.php']['Version'], $min_version_pro, '<' ) ) {
			// translators: %s is the minimum version required.
			$text    = sprintf( esc_html__( 'The minimum version of Analytify Pro required for Analytify Forms addon is %s. You need to update Analytify Pro.', 'wp-analytify-pro' ), $min_version_pro );
			$message = '<strong>' . esc_html__( 'Attention:', 'wp-analytify-pro' ) . '</strong>' . $text;
			$this->wpa_forms_notice( $message, 'wp-analytify-danger' );
		}
	}


	/**
	 * Add custom admin notice.
	 *
	 * @param  string $message Custom Message.
	 * @param  string $class wp-analytify-success,wp-analytify-danger.
	 * @return void
	 */
	// phpcs:ignore Universal.NamingConventions.NoReservedKeywordParameterNames.classFound
	public function wpa_forms_notice( $message, $class ) {
		echo '<div class="wp-analytify-notification ' . esc_attr( $class ) . '">
		<a class="" href="#" aria-label="' . esc_attr__( 'Dismiss the welcome panel', 'wp-analytify-pro' ) . '"></a>
		<div class="wp-analytify-notice-logo">
		<img src="' . esc_url( plugins_url( 'assets/img/logo.svg', __FILE__ ) ) . '" alt="analytify logo">
		</div>
		<div class="wp-analytify-notice-discription">
		<p>' . wp_kses_post( $message ) . '</p>
		</div>
		</div>';
	}

	/**
	 * Load text domain.
	 *
	 * @return void
	 */
	public function wpa_forms_load_textdomain() {
		// Text domain loaded by main Pro plugin.
		// All translations now use 'wp-analytify-pro' text domain.
	}

	/**
	 * Define constant.
	 *
	 * @param string $constant Constant name.
	 * @param mixed  $value Constant value.
	 * @return void
	 */
	public function define( $constant, $value ) {
		if ( ! defined( $constant ) ) {
			define( $constant, $value );
		}
	}
}

Analytify_Form_Loader::get_instance();
