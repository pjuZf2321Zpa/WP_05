Welcome!

For more help, checkout our YouTube Channel videos and Subscribe at https://www.youtube.com/channel/UCRjDcNZqf-Vo_2Ux_QLyBCA/videos

Our Documentation is available at https://analytify.io/documentation/

Cheers,
Adnan from Analytify LLC

== Installation ==
You should have installed Analytify Free + Pro versions to use this Analytify - Forms Tracking add-on.

If you have any problem, please send an email to us at support@analytify.io

== Changelog ==

= 5.1.0 - 2023-08-10 =
* Bug Fix: WPforms pro compatibility added.

= 5.0.2 - 2023-06-20 =
* Bug Fix: custom form tracking option on/off state corrected.
* Compatibility: Compatible to WordPress 6.2

= 5.0.1 - 2023-05-29 =
* Enhancement: Use main dashboard saved date.
* Enhancement: Changelog button text updated.

= 5.0.0 - 2023-04-16 =
* New Feature: Google Analytics GA4 integration is added.
* New Feature: Google Search Console (webmasters) Integrated.
* Enhancement: Pageload speed improvement.
* Enhancement: UI Improvements.

= 2.1.0 - 2022-06-14 =
* New Feature: Support for Fluent Forms.
* Compatibility: Compatible to WordPress 6.0

= 2.0.1 - 2022-02-28 =
* Enhancement: Custom forms tracking with class container.
* Enhancement: Kadence Forms Tracking.

= 2.0.0 - 2021-06-21 =
* New Feature: Add the Global Site Tag (gtag.js) tracking compatibility. 
* Enhancement: Update diagostic information for additional details.
* Enhancement: Refactor tracking code.

= 1.0.1 - 2nd April, 2021 =
* Big Fix: Undefined constant notice.
* Big Fix: Fix deprecated method used for contact form 7.

= 1.0.0 - 12th March, 2021 =
* Initial Release


The full changelog is avaialable at https://analytify.io/changelog/
