<?php
/**
 * Forms Dashboard Include File.
 *
 * @package WP_Analytify_Pro
 */

// phpcs:disable WordPress.NamingConventions.ValidVariableName.VariableNotSnakeCase
$Analytify = $GLOBALS['WP_ANALYTIFY'];
// phpcs:enable WordPress.NamingConventions.ValidVariableName.VariableNotSnakeCase
$wp_analytify = $GLOBALS['WP_ANALYTIFY'];
$acces_token  = get_option( 'post_analytics_token' );

// Get the start date and end date from wpa-core-functions.
if ( function_exists( 'analytify_datepicker_dates' ) ) {
	$dates      = analytify_datepicker_dates();
	$start_date = $dates['start_date'] ?? wp_date( 'Y-m-d', strtotime( '-1 month' ) );
	$end_date   = $dates['end_date'] ?? wp_date( 'Y-m-d', strtotime( 'now' ) );
} else {
	$start_date = wp_date( 'Y-m-d', strtotime( '-1 month' ) );
	$end_date   = wp_date( 'Y-m-d', strtotime( 'now' ) );
}

/**
 * Get the title of form from ID.
 *
 * @param string $form_id Form ID.
 * @param string $category Form category.
 * @return void
 */
function analytify_get_form_name( $form_id, $category ) {

	// phpcs:disable WordPress.NamingConventions.ValidVariableName.VariableNotSnakeCase
	switch ( $category ) {

		// for CF7.
		case 'analytify_form_wpcf7':
			if ( class_exists( 'WPCF7_ContactForm' ) && is_callable( 'WPCF7_ContactForm::get_instance' ) ) {
				$WPCF7 = WPCF7_ContactForm::get_instance( $form_id );
				echo esc_html( ( $WPCF7 && $WPCF7->title() ) ? $WPCF7->title() : '-' );
			} else {
				// phpcs:ignore Squiz.PHP.CommentedOutCode.Found -- Placeholder for future use.
				// Form ID fallback placeholder.
				echo '';
			}
			break;

		// for WP Forms.
		case 'analytify_form_wpforms':
			$post = get_post( (int) $form_id );
			if ( $post ) {
				echo esc_html( get_the_title( $post ) );
			} else {
				// phpcs:ignore Squiz.PHP.CommentedOutCode.Found -- Placeholder for future use.
				// Form ID fallback placeholder.
				echo '';
			}
			break;

		// Ninja Forms.
		case 'analytify_form_ninja_forms':
			if ( class_exists( 'Ninja_Forms' ) && method_exists( 'Ninja_Forms', 'get_setting' ) && function_exists( 'Ninja_Forms' ) ) {
				echo esc_html( Ninja_Forms()->form( $form_id )->get()->get_setting( 'title' ) );
			} else {
				// phpcs:ignore Squiz.PHP.CommentedOutCode.Found -- Placeholder for future use.
				// Form ID fallback placeholder.
				echo '';
			}
			break;

		// Gravity Forms.
		case 'analytify_form_gf':
			if ( class_exists( 'GFAPI' ) && is_callable( 'GFAPI::get_form' ) ) {
				$GF = GFAPI::get_form( $form_id );
				echo esc_html( ( $GF && isset( $GF['title'] ) && ! empty( $GF['title'] ) ) ? $GF['title'] : '' );
			} else {
				// phpcs:ignore Squiz.PHP.CommentedOutCode.Found -- Placeholder for future use.
				// Form ID fallback placeholder.
				echo '';
			}
			break;

		// Formidable Forms.
		case 'analytify_form_formidable':
			if ( class_exists( 'FrmForm' ) && is_callable( 'FrmForm::getName' ) ) {
				$formidable_name = FrmForm::getName( $form_id );
				echo esc_html( ( isset( $formidable_name ) && ! empty( $formidable_name ) ) ? $formidable_name : '' );
			} else {
				// phpcs:ignore Squiz.PHP.CommentedOutCode.Found -- Placeholder for future use.
				// Form ID fallback placeholder.
				echo '';
			}
			break;

		// Fluent Forms.
		case 'analytify_form_fluentforms':
			if ( function_exists( 'wpFluent' ) ) {
				$fluent_form = wpFluent()->table( 'fluentform_forms' )->find( $form_id );
				echo esc_html( ( $fluent_form && isset( $fluent_form->title ) && ! empty( $fluent_form->title ) ) ? $fluent_form->title : '' );
			} else {
				// Fluent Forms not available.
				echo '';
			}
			break;

		// Happyforms.
		case 'analytify_form_happyforms':
			$happy_post = get_post( (int) $form_id );
			if ( $happy_post && 'happyform' === $happy_post->post_type ) {
				echo esc_html( get_the_title( $happy_post ) );
			} else {
				echo '';
			}
			break;

		// Forminator.
		case 'analytify_form_forminator':
			$fin_post = get_post( (int) $form_id );
			if ( $fin_post && 'forminator_forms' === $fin_post->post_type ) {
				if ( class_exists( 'Forminator_Base_Form_Model' ) && class_exists( 'Forminator_Form_Model' ) && method_exists( 'Forminator_Base_Form_Model', 'get_model' ) ) {
					$fin_model = Forminator_Base_Form_Model::get_model( (int) $form_id );
					if ( $fin_model instanceof Forminator_Form_Model && ! empty( $fin_model->name ) ) {
						echo esc_html( $fin_model->name );
						break;
					}
				}
				echo esc_html( get_the_title( $fin_post ) );
			} else {
				echo '';
			}
			break;

		// GiveWP.
		case 'analytify_form_givewp':
			$give_post = get_post( (int) $form_id );
			if ( $give_post && 'give_forms' === $give_post->post_type ) {
				echo esc_html( get_the_title( $give_post ) );
			} else {
				echo '';
			}
			break;

		// weForms.
		case 'analytify_form_weforms':
			$we_post = get_post( (int) $form_id );
			if ( $we_post && 'wpuf_contact_form' === $we_post->post_type ) {
				echo esc_html( get_the_title( $we_post ) );
			} else {
				echo '';
			}
			break;

		// Elementor Forms.
		case 'analytify_form_elementor':
			if ( class_exists( '\ElementorPro\Modules\Forms\Module' ) ) {
				$form = get_post( (int) $form_id );
				echo esc_html( ( $form && isset( $form->post_title ) && ! empty( $form->post_title ) ) ? $form->post_title : '' );
			}
			break;

		// MailPoet Forms.
		case 'analytify_form_mailpoet':
			if ( class_exists( 'MailPoet\Form\FormsRepository' ) ) {
				$form = MailPoet\Form\FormsRepository::getInstance()->findOne( (int) $form_id );
				echo esc_html( ( $form && isset( $form->name ) && ! empty( $form->name ) ) ? $form->name : '' );
			}
			break;

		// HubSpot Forms.
		case 'analytify_form_hubspot':
			// HubSpot forms are identified by their form ID.
			echo esc_html( 'HubSpot Form (' . $form_id . ')' );
			break;

		// Jotform Forms.
		case 'analytify_form_jotform':
			// Jotform forms are identified by their form ID.
			echo esc_html( 'Jotform (' . $form_id . ')' );
			break;

		// Custom Forms.
		default:
			echo esc_html( $form_id );
	}
	// phpcs:enable WordPress.NamingConventions.ValidVariableName.VariableNotSnakeCase
}


// phpcs:disable WordPress.NamingConventions.ValidVariableName.VariableNotSnakeCase
// Fetch Dashboard Profile ID.
$dashboard_profile_ID = $Analytify->settings->get_option( 'profile_for_dashboard', 'wp-analytify-profile' );
// phpcs:enable WordPress.NamingConventions.ValidVariableName.VariableNotSnakeCase
$version = defined( 'ANALYTIFY_PRO_VERSION' ) ? ANALYTIFY_PRO_VERSION : ANALYTIFY_VERSION;

/*
* Check with roles assigned at dashboard settings.
*/
// phpcs:disable WordPress.NamingConventions.ValidVariableName.VariableNotSnakeCase
$is_access_level = $Analytify->settings->get_option( 'show_analytics_roles_dashboard', 'wp-analytify-dashboard' );
// phpcs:enable WordPress.NamingConventions.ValidVariableName.VariableNotSnakeCase

$_analytify_profile = get_option( 'wp-analytify-profile' );
?>

<div class="wpanalytify analytify-dashboard-nav">
	<div class="wpb_plugin_wraper">
		<div class="wpb_plugin_header_wraper">
			<div class="graph"></div>
			<div class="wpb_plugin_header">
				<div class="wpb_plugin_header_title"></div>
				<div class="wpb_plugin_header_info">
					<a href="https://analytify.io/changelog/" target="_blank" class="btn">View Changelog</a>
				</div>
			<div class="wpb_plugin_header_logo">
				<img src="<?php echo esc_url( ( defined( 'ANALYTIFY_PLUGIN_URL' ) ? ANALYTIFY_PLUGIN_URL : '' ) . '/assets/images/logo.svg' ); ?>" alt="Analytify">
			</div>
			</div>
		</div>
				
		<div class="analytify-dashboard-body-container">
			<div class="wpb_plugin_body_wraper">
				<div class="wpb_plugin_body">
					<div class="wpa-tab-wrapper">
						
					<?php
					if ( is_object( $GLOBALS['WP_ANALYTIFY'] ) && method_exists( $GLOBALS['WP_ANALYTIFY'], 'dashboard_navigation' ) ) {
						// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Method returns escaped HTML.
						echo $GLOBALS['WP_ANALYTIFY']->dashboard_navigation();
					}
					?>

					</div>
					<div class="wpb_plugin_tabs_content analytify-dashboard-content">
						<div class="analytify_wraper">
							<div class="analytify_main_title_section">
								<div class="analytify_dashboard_title">
									<h1 class="analytify_pull_left analytify_main_title"><?php esc_html_e( 'Forms Tracking Dashboard', 'wp-analytify-pro' ); ?></h1>
																		
								<?php
								// phpcs:disable WordPress.NamingConventions.ValidVariableName.VariableNotSnakeCase
								if ( $dashboard_profile_ID ) {
									if ( $wp_analytify->pa_check_roles( $is_access_level ) ) {
										if ( $acces_token && isset( $_analytify_profile['profile_for_dashboard'] ) && ! empty( $_analytify_profile['profile_for_dashboard'] ) ) {
											?>
											
												<span class="analytify_stats_of"><a href="<?php echo esc_url( class_exists( 'WP_ANALYTIFY_FUNCTIONS' ) && method_exists( 'WP_ANALYTIFY_FUNCTIONS', 'search_profile_info' ) ? WP_ANALYTIFY_FUNCTIONS::search_profile_info( $dashboard_profile_ID, 'websiteUrl' ) : '' ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( class_exists( 'WP_ANALYTIFY_FUNCTIONS' ) && method_exists( 'WP_ANALYTIFY_FUNCTIONS', 'search_profile_info' ) ? WP_ANALYTIFY_FUNCTIONS::search_profile_info( $dashboard_profile_ID, 'websiteUrl' ) : '' ); ?></a> (<?php echo esc_html( class_exists( 'WP_ANALYTIFY_FUNCTIONS' ) && method_exists( 'WP_ANALYTIFY_FUNCTIONS', 'search_profile_info' ) ? WP_ANALYTIFY_FUNCTIONS::search_profile_info( $dashboard_profile_ID, 'name' ) : '' ); ?>)</span>
												
													<?php
										}
									}
								}
									// phpcs:enable WordPress.NamingConventions.ValidVariableName.VariableNotSnakeCase
								?>


								</div>

								<div class="analytify_main_setting_bar">
									<div class="analytify_pull_right analytify_setting">
										<div class="analytify_select_date">

											<?php
											// phpcs:disable WordPress.NamingConventions.ValidVariableName.VariableNotSnakeCase
											if ( $dashboard_profile_ID ) {
												if ( $wp_analytify->pa_check_roles( $is_access_level ) ) {
													if ( $acces_token ) {
														if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'date_form' ) ) {
															WPANALYTIFY_Utils::date_form( $start_date, $end_date );
														}
													}
												}
											}
											// phpcs:enable WordPress.NamingConventions.ValidVariableName.VariableNotSnakeCase
											?>

										</div>
									</div>
								</div>

							</div>
			
							<?php
									// phpcs:disable WordPress.NamingConventions.ValidVariableName.VariableNotSnakeCase
									// Show notice if the user is using UA or hasn't selected any property yet.
							if ( class_exists( 'WP_ANALYTIFY_FUNCTIONS' ) && method_exists( 'WP_ANALYTIFY_FUNCTIONS', 'wpa_check_ga_version' ) && method_exists( 'WP_ANALYTIFY_FUNCTIONS', 'wpa_check_profile_selection' ) && WP_ANALYTIFY_FUNCTIONS::wpa_check_ga_version() && ! WP_ANALYTIFY_FUNCTIONS::wpa_check_profile_selection( 'Forms Tracking' ) ) {
								if ( $Analytify->pa_check_roles( $is_access_level ) ) {
									if ( $acces_token ) {
										// hold all the forms that have tracking enabled from settings and have active plugins.
										$analytify_tracking_forms = array();

										// check for Contact Form 7.
										if ( 'on' === $GLOBALS['WP_ANALYTIFY']->settings->get_option( 'track_cf7', 'wp-analytify-forms' ) && is_plugin_active( 'contact-form-7/wp-contact-form-7.php' ) ) {
											array_push(
												$analytify_tracking_forms,
												array(
													'title'    => 'Contact Form 7',
													'category' => 'analytify_form_wpcf7',
												)
											);
										}

										// check for WPForms.
										if ( 'on' === $GLOBALS['WP_ANALYTIFY']->settings->get_option( 'track_wpforms', 'wp-analytify-forms' ) && ( is_plugin_active( 'wpforms-lite/wpforms.php' ) || is_plugin_active( 'wpforms/wpforms.php' ) ) ) {
											array_push(
												$analytify_tracking_forms,
												array(
													'title'    => 'WPForms',
													'category' => 'analytify_form_wpforms',
												)
											);
										}

										// check for Ninja Forms.
										if ( 'on' === $GLOBALS['WP_ANALYTIFY']->settings->get_option( 'track_ninjaforms', 'wp-analytify-forms' ) && is_plugin_active( 'ninja-forms/ninja-forms.php' ) ) {
											array_push(
												$analytify_tracking_forms,
												array(
													'title'    => 'Ninja Forms',
													'category' => 'analytify_form_ninja_forms',
												)
											);
										}

										// check for Gravity Forms.
										if ( 'on' === $GLOBALS['WP_ANALYTIFY']->settings->get_option( 'track_gravityforms', 'wp-analytify-forms' ) && is_plugin_active( 'gravityforms/gravityforms.php' ) ) {
											array_push(
												$analytify_tracking_forms,
												array(
													'title'    => 'Gravity Forms',
													'category' => 'analytify_form_gf',
												)
											);
										}

										// check for Formidable Forms.
										if ( 'on' === $GLOBALS['WP_ANALYTIFY']->settings->get_option( 'track_formidable', 'wp-analytify-forms' ) && is_plugin_active( 'formidable/formidable.php' ) ) {
											array_push(
												$analytify_tracking_forms,
												array(
													'title'    => 'Formidable Forms',
													'category' => 'analytify_form_formidable',
												)
											);
										}


										// check for Fluent Forms.
										if ( 'on' === $GLOBALS['WP_ANALYTIFY']->settings->get_option( 'track_fluentforms', 'wp-analytify-forms' ) && is_plugin_active( 'fluentform/fluentform.php' ) ) {
											array_push(
												$analytify_tracking_forms,
												array(
													'title'    => 'Fluent Forms',
													'category' => 'analytify_form_fluentforms',
												)
											);
										}

										// check for Happyforms.
										if ( 'on' === $GLOBALS['WP_ANALYTIFY']->settings->get_option( 'track_happyforms', 'wp-analytify-forms' ) && is_plugin_active( 'happyforms/happyforms.php' ) ) {
											array_push(
												$analytify_tracking_forms,
												array(
													'title'    => 'Happyforms',
													'category' => 'analytify_form_happyforms',
												)
											);
										}

										// check for Forminator.
										if ( 'on' === $GLOBALS['WP_ANALYTIFY']->settings->get_option( 'track_forminator', 'wp-analytify-forms' ) && is_plugin_active( 'forminator/forminator.php' ) ) {
											array_push(
												$analytify_tracking_forms,
												array(
													'title'    => 'Forminator',
													'category' => 'analytify_form_forminator',
												)
											);
										}

										// check for GiveWP.
										if ( 'on' === $GLOBALS['WP_ANALYTIFY']->settings->get_option( 'track_givewp', 'wp-analytify-forms' ) && is_plugin_active( 'give/give.php' ) ) {
											array_push(
												$analytify_tracking_forms,
												array(
													'title'    => 'GiveWP',
													'category' => 'analytify_form_givewp',
												)
											);
										}

										// check for weForms.
										if ( 'on' === $GLOBALS['WP_ANALYTIFY']->settings->get_option( 'track_weforms', 'wp-analytify-forms' ) && is_plugin_active( 'weforms/weforms.php' ) ) {
											array_push(
												$analytify_tracking_forms,
												array(
													'title'    => 'weForms',
													'category' => 'analytify_form_weforms',
												)
											);
										}

										// check for WS Forms (free ws-form/ws-form.php or PRO ws-form-pro/ws-form.php).
										if ( 'on' === $GLOBALS['WP_ANALYTIFY']->settings->get_option( 'track_wsforms', 'wp-analytify-forms' ) && class_exists( 'AnalytifyAddonFormHelper' ) && AnalytifyAddonFormHelper::is_ws_form_plugin_active() ) {
											array_push(
												$analytify_tracking_forms,
												array(
													'title'    => 'WS Forms',
													'category' => 'analytify_form_wsforms',
												)
											);
										}

										// check for custom forms.
										if ( 'on' === $GLOBALS['WP_ANALYTIFY']->settings->get_option( 'custom_form', 'wp-analytify-forms' ) ) {
											array_push(
												$analytify_tracking_forms,
												array(
													'title'    => 'Custom Forms',
													'category' => 'analytify_form_custom',
												)
											);
										}

										// Check for elementor forms.
										if ( 'on' === $GLOBALS['WP_ANALYTIFY']->settings->get_option( 'track_elementor', 'wp-analytify-forms' ) && is_plugin_active( 'elementor-pro/elementor-pro.php' ) ) {
											array_push(
												$analytify_tracking_forms,
												array(
													'title'    => 'Elementor Forms',
													'category' => 'analytify_form_elementor',
												)
											);
										}

										// Check for HubSpot forms (HubSpot WordPress plugin basename: leadin/leadin.php).
										if ( 'on' === $GLOBALS['WP_ANALYTIFY']->settings->get_option( 'track_hubspot', 'wp-analytify-forms' ) && is_plugin_active( 'leadin/leadin.php' ) ) {
											array_push(
												$analytify_tracking_forms,
												array(
													'title'    => 'Hubspot Forms',
													'category' => 'analytify_form_hubspot',
												)
											);
										}

										if ( 'on' === $GLOBALS['WP_ANALYTIFY']->settings->get_option( 'track_jotform', 'wp-analytify-forms' ) && is_plugin_active( 'jotform-oembed/jotform-oembed.php' ) ) {
											array_push(
												$analytify_tracking_forms,
												array(
													'title'    => 'Jotforms',
													'category' => 'analytify_form_jotform',
												)
											);
										}

										if ( 'on' === $GLOBALS['WP_ANALYTIFY']->settings->get_option( 'track_mailpoet', 'wp-analytify-forms' ) && is_plugin_active( 'mailpoet/mailpoet.php' ) ) {
											array_push(
												$analytify_tracking_forms,
												array(
													'title'    => 'MailPoet',
													'category' => 'analytify_form_mailpoet',
												)
											);
										}

										// check for the forms active and installed.
										if ( ! empty( $analytify_tracking_forms ) ) {

											foreach ( $analytify_tracking_forms as $form ) {
												?>
											<div id="section-<?php echo esc_attr( $form['category'] ); ?>" class="analytify_general_status analytify_status_box_wraper form-section" data-endpoint-forms="main-dashboard">
												<div class="analytify_status_header">
												<h3>
												<?php
												// translators: %s is the form title.
												printf( esc_html__( "'%s' Stats", 'wp-analytify-pro' ), esc_html( $form['title'] ) );
												?>
												</h3>
												</div>
												<div class="analytify_status_body">
													<div class="stats-wrapper"></div>
													<div class="analytify_stats_loading" style="display: none;">
														<p><?php esc_html_e( 'Loading...', 'wp-analytify-pro' ); ?></p>
													</div>
												</div>
											</div>
												<?php
											}
										} else {

											?>
										<div class="analytify-stats-error-msg">
											<div class="wpb-error-box">
												<span class="blk">
													<span class="line"></span>
													<span class="dot"></span>
												</span>
												<span class="information-txt">No forms installed or activated.</span>
											</div>
										</div>
											<?php

										}
									} else {
										esc_html_e( 'You must be logged in to see the Analytics Dashboard.', 'wp-analytify-pro' );
									}
								} else {
									esc_html_e( 'You don\'t have access to Forms Dashboard.', 'wp-analytify-pro' );
								}
							}
							?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

