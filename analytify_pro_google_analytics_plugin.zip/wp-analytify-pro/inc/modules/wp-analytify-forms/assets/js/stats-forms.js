'use strict';

/**
 * This file handles all the ajax requests for the core dashboard.
 * This also includes generating and charts and populating the data into a view.
 * 
 */

jQuery(document).ready(($) => {

	/**
	 * Handles the ajax request for the dashboard stats.
	 *
	 * @param {string} endpoint The API endpoint.
	 * @param {object} data     The data to send in the request.
	 * 
	 * @returns {object}
	 */
	const fetch_stats = async (endpoint, data = {}) => {

		// start/end dates and date differ.
		if ($('#analytify_date_start').length) {
			data.sd = $('#analytify_date_start').val();
		}
		if ($('#analytify_date_end').length) {
			data.ed = $('#analytify_date_end').val();
		}
		if ($('#analytify_date_diff').length) {
			data.d_diff = $('#analytify_date_diff').val();
		}

		// convert data to url params.
		const params = new URLSearchParams();
		for (const key in data) {
			params.append(key, data[key]);
		}

		const URL = `${`${analytify_stats_forms.url + endpoint}/${analytify_stats_forms.delimiter}`}${params.toString()}`;

		// console.log(URL);

		const request = await fetch(URL, {
			method: "GET",
			headers: {
				"X-WP-Nonce": analytify_stats_forms.nonce,
			},
			credentials: 'include',
		});

		return request.json();
	}

	/**
	 * Sets the target element to 'loading' state.
	 * Also clear the element's contents.
	 * 
	 * @param {element} target The target element.
	 */
	const prepare_section = (target) => {
		target.find('.analytify_stats_loading').show();
		target.find('.analytify_status_body .stats-wrapper').html('');
		target.find('.analytify_status_footer').remove();
		target.find('.empty-on-loading').html('');
	}

	/**
	 * Element should not be loading.
	 * 
	 * @param {element} target The target element.
	 */
	const should_not_be_loading = (target) => {
		target.find('.analytify_stats_loading').hide();
	}

	/**
	 * Sets the content for the element.
	 * Removes the 'loading' state.
	 * 
	 * @param {element} target     The target element.
	 * @param {string}  markup     The markup to be set (should be HTML).
	 * @param {string}  footer     The footer markup to be set.
	 * @param {boolean} pagination Whether to show the pagination or not.
	 */
	const set_section = (target, markup, footer = false, pagination = false) => {
		should_not_be_loading(target);
		target.find('.analytify_status_body .stats-wrapper').html(markup);

		// Remove existing footers only within this section (avoids affecting other UI).
		target.find('.analytify_status_footer').remove();

		if (footer || pagination) {
			const $statusBody = target.find('.analytify_status_body');
			const footer_markup = `<div class="analytify_status_footer">
					${footer ? `<span class="analytify_info_stats">${footer}</span>` : ''}
					${pagination ? `<div class="wp_analytify_pagination"></div>` : ''}
				</div>`;
			$statusBody.after(footer_markup);
		}
		if ('function' === typeof enableAnalytifyTableSorting) {
			enableAnalytifyTableSorting();
		}

	}

	/**
	 * Generates the empty stats message.
	 * 
	 * @param {element} target       The target element.
	 * @param {string}  message      The message to be shown.
	 * @param {object}  table_header The table header, if the message needs to be shown in a table.
	 * @param {string}  table_class  The table class.
	 */
	const stats_message = (target = false, message = false, table_header = false, table_class = '') => {
		let markup = `<div class="analytify-stats-error-msg">
			<div class="wpb-error-box">
				<span class="blk"><span class="line"></span><span class="dot"></span></span>
				<span class="information-txt">${message ? message : analytify_stats_forms.no_stats_message}</span>
			</div>
		</div>`;

		if (table_header) {

			// If the error message is to be shown in a table.
			let thead = '';
			for (const td_key in table_header) {
				const td = table_header[td_key];
				if (td.label) {
					thead += `<th class="${td.th_class ? td.th_class : ``}">${td.label}</th>`;
				}
			}

			markup = `<table class="${table_class}">${'' !== thead ? `<thead><tr>${thead}</tr></thead>` : ''}<tbody><tr><td class="analytify_td_error_msg" colspan="${Object.keys(table_header).length}">${markup}</td></tr></tbody></table>`;
		}

		if (!target) {
			return markup;
		}
		set_section(target, markup, false, false);
	}

	/**
	 * Generates the red message box.
	 * 
	 * @param {element} target       The target element.
	 * @param {string}  message      The message to be shown.
	 * @param {object}  table_header The table header, if the message needs to be shown in a table.
	 * @param {string}  table_class  The table class.
	 */
	// eslint-disable-next-line no-unused-vars
	const red_stats_message = (target = false, message = false, table_header = false, table_class = '') => {
		let markup = `<div class="analytify-email-promo-contianer">
			<div class="analytify-email-premium-overlay">
				<div class="analytify-email-premium-popup">
					${message.title ? `<h3 class="analytify-promo-popup-heading" style="text-align:left;">${message.title}</h3>` : ``}
					${message.content ? message.content : ``}
				</div>
			</div>
		</div>`;

		if (table_header) {

			// If the error message is to be shown in a table.
			let thead = '';
			for (const td_key in table_header) {
				const td = table_header[td_key];
				if (td.label) {
					thead += `<th class="${td.th_class ? td.th_class : ``}">${td.label}</th>`;
				}
			}

			markup = `<table class="${table_class}">${'' !== thead ? `<thead><tr>${thead}</tr></thead>` : ''}<tbody><tr><td class="analytify_td_error_msg" colspan="${Object.keys(table_header).length}">${markup}</td></tr></tbody></table>`;
		}

		if (!target) {
			return markup;
		}
		set_section(target, markup, false, false);
	}

	/**
	 * Generates table from object.
	 * {headers} is to generate <thead> tag and content.
	 * {stats} is to generate <tbody> tag and content.
	 * 
	 * @param {object} headers       The headers.
	 * @param {object} stats         The stats to be shown.
	 * @param {string} table_classes Table classes.
	 * @param {string} attr          Table attributes.
	 * @returns {string}
	 */
	const generate_stats_table = (headers, stats, table_classes = false, attr = '') => {

		let markup = ``;

		markup += `<table class="${table_classes}" ${attr}>`;

		let thead = '';
		for (const td_key in headers) {
			const td = headers[td_key];
			if (td.label) {
				thead += `<th class="${td.th_class ? td.th_class : ``}">${td.label}</th>`;
			}
		}
		if ('' !== thead) {
			markup += `<thead><tr>${thead}</tr></thead>`;
		}

		markup += `<tbody>`;

		let i = 1;
		for (const row_id in stats) {
			const row = stats[row_id];
			markup += `<tr>`;
			for (const td_key in headers) {

				let __label = '';
				const cell_data = row[td_key];

				if (headers[td_key].type && 'counter' === headers[td_key].type) {
					__label = i;
				} else if (cell_data && cell_data.label) {
					__label = cell_data.label;
				} else if (cell_data && cell_data.value) {
					__label = cell_data.value;
				} else if (cell_data !== undefined && null !== cell_data) {
					__label = cell_data;
				}

				let __class = '';
				if (cell_data && cell_data.class) {
					__class = cell_data.class;
				} else if (headers[td_key] && headers[td_key].td_class) {
					__class = headers[td_key].td_class;
				}

				markup += `<td class="${__class}">${__label}</td>`;
			}
			markup += `</tr>`;
			i++;
		}
		markup += `</tbody>`;

		markup += `</table>`;

		return markup;

	}

	/**
	 * Returns the compare start and end date based on given start and end date.
	 * 
	 * @param {string} __start_date Start date.
	 * @param {string} __end_date   End date.
	 * @param {bool}   formatted    If true, returns formatted date to be used in the GA's dashboard url.
	 * @returns {object}
	 */
	const calc_compare_date = (__start_date, __end_date, formatted = true) => {

		const append_zero = (__num) => {
			return (10 > __num) ? `0${__num}` : __num;
		}

		const compare_date = {};

		const start_date = new Date(__start_date);
		const end_date = new Date(__end_date);

		let diff_in_days = end_date.getTime() - start_date.getTime();
		if (0 === diff_in_days) {
			diff_in_days = 1 * 24 * 60 * 60 * 1000;
		}

		const compare_date_start = new Date(start_date.getTime() - diff_in_days);
		const compare_date_end = new Date(end_date.getTime() - diff_in_days);

		compare_date.start = `${compare_date_start.getFullYear()}-${append_zero(compare_date_start.getMonth() + 1)}-${append_zero(compare_date_start.getDate())}`;
		compare_date.end = `${compare_date_end.getFullYear()}-${append_zero(compare_date_end.getMonth() + 1)}-${append_zero(compare_date_end.getDate())}`;

		if (!formatted) {
			return compare_date;
		}

		return `%26_u.date00%3D${__start_date.replaceAll('-', '')}%26_u.date01%3D${__end_date.replaceAll('-', '')}%26_u.date10%3D${compare_date.start.replaceAll('-', '')}%26_u.date11%3D${compare_date.end.replaceAll('-', '')}`;
	}

	/**
	 * Builds the GA dashboard link for sections.
	 * Attaches the data parameter dynamically.
	 */
	const build_ga_dashboard_link = () => {
		const __start_date = $('#analytify_date_start').val();
		const __end_date = $('#analytify_date_end').val();

		const date_parameter = calc_compare_date(__start_date, __end_date, true);

		$('[data-ga-dashboard-forms-link]').each((index, __element) => {
			const link = $(__element).attr('data-ga-dashboard-link') + date_parameter;
			$(__element).attr('href', link);
		});
	}

	/**
	* Fetches the data and build the template for all endpoints.
	* 
	*/
	const build_sections = () => {

		// To trigger same-height js script.
		$(window).trigger('resize');

		$('[data-endpoint-forms]').each((index, __element) => {
			const element = $(__element);
			const type = element.attr('data-endpoint-forms');

			prepare_section(element);

			if ('main-dashboard' === type) {

				// Data is returned by the same api call for these section.
				prepare_section($('.form-section:not([data-endpoint-forms="main-dashboard"])'));
			}

			fetch_stats(type).then((response) => {

				if (response.success) {

					switch (type) {
						case 'main-dashboard':
							{
								const table_classes = 'wp_analytify_paginated analytify_data_tables';

								for (const form_key in response.stats) {
									try {

										// prevent selector errors for keys like "(not set)"
										if (!form_key.match(/^[a-zA-Z0-9_-]+$/)) {
											continue;
										}

										const section = $(`#section-${form_key}`);

										// Clone headers to avoid side effects when deleting keys (like id for custom forms)
										const headers = { ...response.headers };

										if ('analytify_form_custom' === form_key) {
											delete headers.id;
										}

										if (0 < Object.keys(response.stats[form_key].stats).length) {
											const markup = generate_stats_table(headers, response.stats[form_key].stats, table_classes, 'data-product-per-page="7"');
											set_section(section, markup, response.stats[form_key].info_message, true);
										} else {
											stats_message(section, false, headers, table_classes);
										}
									} catch (err) {
										// eslint-disable-next-line no-console
										console.error('Analytify Error generating section:', form_key, err);
									}
								}
							}
							break;

						default:
							break;
					}

					build_ga_dashboard_link();
					wp_analytify_paginated();
					$(window).trigger('resize');

				} else {
					should_not_be_loading(element);
					stats_message(element, analytify_stats_forms.error_message, response.headers);

					should_not_be_loading($('.form-section:not([data-endpoint-forms="main-dashboard"])'));

				}

			}).catch(() => {

				// Silent fail - error handling done elsewhere
			});

		});
	}

	build_sections();

	/**
	 * CSV export for Forms Tracking dashboard.
	 * wp-analytify-pro.js (global export handler) is not enqueued on this screen, so href="#" would scroll to top.
	 *
	 * @returns {{start: string, end: string}}
	 */
	const getFormsExportDateRange = () => {
		let start = $('#analytify_start').val();
		let end = $('#analytify_end').val();
		if (start && end && 'function' === typeof window.moment) {
			start = window.moment(start, 'MMM DD, YYYY').format('YYYY-MM-DD');
			end = window.moment(end, 'MMM DD, YYYY').format('YYYY-MM-DD');
		} else {
			start = $('#analytify_date_start').val() || '';
			end = $('#analytify_date_end').val() || '';
		}
		return { start, end };
	};

	$(document).on('click', '.analytify-export-data', function (e) {
		e.preventDefault();
		if (!analytify_stats_forms.export_nonce || !analytify_stats_forms.export_url || !analytify_stats_forms.export_ajax_url) {
			return;
		}

		const $btn = $(this);
		const formTypeMap = {
			analytify_form_hubspot: 'forms-hubspot',
			analytify_form_jotform: 'forms-jotform',
			analytify_form_wpforms: 'forms-wpform',
			analytify_form_gf: 'forms-gravity',
			analytify_form_wpcf7: 'forms-cf7',
			analytify_form_ninja_forms: 'forms-ninja',
			analytify_form_elementor: 'forms-elementor',
			analytify_form_formidable: 'forms-formidable',
			analytify_form_fluentforms: 'forms-fluentforms',
			analytify_form_custom: 'forms-custom',
			analytify_form_mailpoet: 'forms-mailpoet',
		};

		let statsType = $btn.data('stats-type');
		const formArgs = $btn.data('args');
		if (formTypeMap[formArgs]) {
			statsType = formTypeMap[formArgs];
		}

		const { start, end } = getFormsExportDateRange();
		if (!start || !end) {
			return;
		}

		$.ajax({
			url: analytify_stats_forms.export_ajax_url,
			type: 'POST',
			data: {
				action: 'analytify_export_csv',
				stats_type: statsType,
				start_date: start,
				end_date: end,
				args: formArgs,
				security: analytify_stats_forms.export_nonce,
			},
			beforeSend() {
				$btn.siblings('.analytify-export-loader').show();
			},
		})
			.done(() => {
				$btn.siblings('.analytify-export-loader').hide();
				window.location.href = `${analytify_stats_forms.export_url}&export_type=csv&report_type=${statsType}&security=${analytify_stats_forms.export_nonce}&start_date=${start}&end_date=${end}`;
			})
			.fail(() => {
				$btn.siblings('.analytify-export-loader').hide();
			});
	});

	// Call of submission of date form.
	$('form.analytify_form_date:not(.ecommerce-stats-class,.analytify-events,.analytify-goals,.analytify-dimensions)').on('submit', (e) => {
		if (analytify_stats_forms.load_via_ajax) {
			e.preventDefault();
			build_sections();
			build_ga_dashboard_link();
		}
	});

});
