// Get values localized.
const {
    ANALYTIFY_TRACKING_MODE,
    ANALYTIFY_FORMS_ADDON_CUSTOM_FORM_CLASS,
    custom_form,
    track_cf7,
    track_wpforms,
    track_gravityforms,
    track_formidable,
    track_ninjaforms,
    track_fluentforms,
    track_happyforms,
    track_forminator,
    track_givewp,
    track_weforms,
    track_elementor,
    track_hubspot,
    track_jotform,
    track_mailpoet,
    track_wsforms,
    property_tracking_mode,
    custom_form_default_label
} = FORMS_TRACKING_OBJECT;

const customFormDefaultLabel = custom_form_default_label || 'Custom Form on';

let analytifyFormsMutationTimer = null;

const FORM_SELECTORS = {
    wpcf7: '.wpcf7-form',
    wpforms: '.wpforms-form',
    gform: '.gform_wrapper',
    formidable: '.frm-show-form',
    fluent: '.frm-fluent-form',
    ninja: '.nf-form-cont',
    wsforms: 'form.wsf-form',
};

const tracked_forms_selector = `${FORM_SELECTORS.wpcf7}, ${FORM_SELECTORS.wpforms}, ${FORM_SELECTORS.gform}, ${FORM_SELECTORS.formidable}, ${FORM_SELECTORS.fluent}, ${FORM_SELECTORS.ninja}, ${FORM_SELECTORS.wsforms}, .${ANALYTIFY_FORMS_ADDON_CUSTOM_FORM_CLASS}`;

/** Per-form UI state (current_step is 1-based page index; step_complete GA events still send the completed step as page - 1). */
const formState = new Map();

/** Impression dedupe for this page load only (avoids MutationObserver repeats; do not use sessionStorage before gtag runs). */
const analytifyFormsImpressionDeduped = new Set();

function formStateKey( category, id ) {
    return `${category}\x01${String(id)}`;
}

function ensureFormState( category, id ) {
    const k = formStateKey( category, id );
    if ( ! formState.has( k ) ) {
        formState.set( k, { current_step: 1, has_interacted: false, is_transitioning: false } );
    }
    return formState.get( k );
}

function sessionFormState() {
    const c = sessionStorage.getItem( 'analytify_forms_category' );
    const i = sessionStorage.getItem( 'analytify_forms_id' );
    return ( c && i ) ? ensureFormState( c, i ) : null;
}

/**
 * Session-scoped dedupe key for form events (e.g. HubSpot iframe impressions).
 *
 * @param {string} category Event category.
 * @param {string} id       Form ID.
 * @param {string} action   Event action (impression, start, etc.).
 * @return {string}
 */
function analytify_forms_session_event_key( category, id, action ) {
    return `analytify_form_${action}_${category}_${id}`;
}

/**
 * Whether a form event was already recorded this browser session.
 *
 * @param {string} category Event category.
 * @param {string} id       Form ID.
 * @param {string} action   Event action.
 * @return {boolean}
 */
function analytify_forms_has_session_event( category, id, action ) {
    if ( ! category || ! id || ! action ) {
        return false;
    }
    try {
        return null !== sessionStorage.getItem( analytify_forms_session_event_key( category, id, action ) );
    } catch ( err ) {
        return false;
    }
}

/**
 * Mark a form event as recorded for this browser session.
 *
 * @param {string} category Event category.
 * @param {string} id       Form ID.
 * @param {string} action   Event action.
 * @return {void}
 */
function analytify_forms_set_session_event( category, id, action ) {
    if ( ! category || ! id || ! action ) {
        return;
    }
    try {
        sessionStorage.setItem( analytify_forms_session_event_key( category, id, action ), 'true' );
    } catch ( err ) {

        // sessionStorage may be unavailable (private mode, blocked storage).
    }
}

/**
 * @param {JQuery|Element} el Form or element inside a form.
 * @return {{category: string, id: string}|null}
 */
function getFormCategory( el ) {
    const $el = ( el && el.jquery ) ? el : jQuery( el );
    if ( ! $el.length ) {
        return null;
    }
    const $form = $el.is( 'form' ) ? $el : $el.closest( 'form' );
    if ( ! $form.length ) {
        return null;
    }
    if ( $form.hasClass( 'wpcf7-form' ) ) {
        return { category: 'analytify_form_wpcf7', id: $form.find( 'input[name="_wpcf7"]' ).val() };
    }
    if ( $form.hasClass( 'wpforms-form' ) ) {
        return { category: 'analytify_form_wpforms', id: $form.attr( 'data-formid' ) };
    }
    if ( $form.parent().hasClass( 'gform_wrapper' ) ) {
        const parts = $form.attr( 'id' ) ? $form.attr( 'id' ).split( '_' ) : '';
        const [, gfId] = parts;
        return gfId ? { category: 'analytify_form_gf', id: gfId } : null;
    }
    if ( $form.hasClass( 'frm-show-form' ) ) {
        return { category: 'analytify_form_formidable', id: $form.find( 'input[name="form_id"]' ).val() };
    }
    if ( $form.hasClass( 'frm-fluent-form' ) ) {
        return { category: 'analytify_form_fluentforms', id: $form.attr( 'data-form_id' ) };
    }
    if ( $form.closest( '.nf-form-cont' ).length ) {
        const formIdAttr = $form.attr( 'id' ) || '';
        const formIdMatch = formIdAttr.match( /^nf-form-(\d+)$/ );
        if ( formIdMatch ) {
            const [, nfFormId] = formIdMatch;
            return { category: 'analytify_form_ninja_forms', id: nfFormId };
        }
        const contId = $form.closest( '.nf-form-cont' ).attr( 'id' ) || '';
        const contIdMatch = contId.match( /^nf-form-(\d+)-cont$/ );
        if ( contIdMatch ) {
            const [, nfFormId] = contIdMatch;
            return { category: 'analytify_form_ninja_forms', id: nfFormId };
        }
    }
    return null;
}

function waitForGtag() {
    return new Promise( ( resolve ) => {
        const i = setInterval( () => {
            if ( 'function' === typeof gtag ) {
                clearInterval( i );
                resolve();
            }
        }, 100 );
    } );
}

jQuery(document).ready(() => {

    // simple function that checks if attr is available
    jQuery.fn.hasAttr = function (name) {
        return undefined !== this.attr(name);
    };

    analytify_forms_load( ANALYTIFY_TRACKING_MODE );

    // 1. Instantly retrieve session data into per-form state.
    const stored_step        = sessionStorage.getItem( 'analytify_forms_current_step' );
    const stored_interaction = sessionStorage.getItem( 'analytify_forms_has_interacted' );
    const stored_category    = sessionStorage.getItem( 'analytify_forms_category' );
    const stored_id          = sessionStorage.getItem( 'analytify_forms_id' );

    if ( stored_category && stored_id ) {
        const s0 = ensureFormState( stored_category, stored_id );
        s0.current_step = ( stored_step && ! isNaN( parseInt( stored_step, 10 ) ) ) ? parseInt( stored_step, 10 ) : 1;
        s0.has_interacted = 'true' === stored_interaction;
    }

    // Update current_step (1-based) from visible Gravity Form on load.
    const update_current_step_from_visible_form = () => {
        const $gform = jQuery( `${FORM_SELECTORS.gform} form` );
        if ( 0 < $gform.length ) {

            // Try hidden input first.
            let page = $gform.find( 'input[name^="gform_source_page_number_"]' ).val();

            // Fallback: Check progress bar text if hidden input is missing (based on user screenshot).
            if ( ! page ) {
                const $currentPageSpan = $gform.find( '.gf_step_current_page' );
                if ( 0 < $currentPageSpan.length ) {
                    page = $currentPageSpan.text().trim();
                }
            }

            if ( page ) {
                const meta = getFormCategory( $gform );
                if ( meta && meta.id ) {
                    const s = ensureFormState( meta.category, meta.id );
                    s.current_step = parseInt( page, 10 );
                    sessionStorage.setItem( 'analytify_forms_current_step', s.current_step );
                }
            }
        }
    };

    update_current_step_from_visible_form();

    // 2. Abandonment Check: If we have interaction but NO tracked form on this page, trigger abandonment.
    const check_immediate_abandonment = () => {
        const $visible_forms = jQuery( tracked_forms_selector ).filter( ':visible' );
        const s = sessionFormState();

        if ( s && s.has_interacted && 0 === $visible_forms.length ) {
            const cat = sessionStorage.getItem( 'analytify_forms_category' );
            const sid = sessionStorage.getItem( 'analytify_forms_id' );
            if ( cat && sid ) {
                analytify_forms_send_event( cat, sid, 'abandonment', s.current_step );

                // Wipe session immediately after sending to prevent multiple triggers.
                analytify_forms_clear_session( cat, sid );
                s.has_interacted = false;
            }
        }
    };

    // Trigger abandonment check as soon as possible if we have an active session.
    if ( sessionFormState() && sessionFormState().has_interacted ) {

        // Run once immediately.
        check_immediate_abandonment();

        // Re-check once gtag exists (no arbitrary cut-off).
        waitForGtag().then( () => {
            const s = sessionFormState();
            if ( s && s.has_interacted ) {
                check_immediate_abandonment();
            }
        } );
    }

    // Mark as transitioning when clicking Next/Previous to avoid false abandonment.
    jQuery( document ).on( 'click', '.gform_next_button, .gform_previous_button, .wpforms-page-button, .ff-btn-next, .ff-btn-prev, .frm_next_page, .frm_prev_page', function () {
        const meta = getFormCategory( jQuery( this ).closest( 'form' ) );
        if ( meta && meta.id ) {
            ensureFormState( meta.category, meta.id ).is_transitioning = true;
        }
    } );

    // Track form interaction and update step if needed.
    jQuery( document ).on( 'focus change', 'input, textarea, select', function() {
        const $form = jQuery( this ).closest( 'form' );
        const meta = getFormCategory( $form );
        if ( ! meta || ! meta.id ) {
            return;
        }
        const s = ensureFormState( meta.category, meta.id );

        // If this form was already marked interacted, persist its current step only.
        if ( s.has_interacted ) {
            sessionStorage.setItem( 'analytify_forms_current_step', s.current_step );
            return;
        }

        s.has_interacted = true;
        sessionStorage.setItem( 'analytify_forms_has_interacted', 'true' );
        sessionStorage.setItem( 'analytify_forms_category', meta.category );
        sessionStorage.setItem( 'analytify_forms_id', meta.id );
        sessionStorage.setItem( 'analytify_forms_current_step', s.current_step );
    } );

    // Send abandonment event when user leaves.
    window.addEventListener( 'visibilitychange', () => {
        if ( 'hidden' !== document.visibilityState ) {
            return;
        }
        const $form = jQuery( tracked_forms_selector ).filter( ':visible' ).first();
        let category = '';
        let id       = '';

        if ( 0 < $form.length ) {
            const vis = getFormCategory( $form );
            if ( vis && vis.id ) {
                ( { category, id } = vis );
            }
        } else {

            // Fallback to stored values if no form is visible (cross-page abandonment).
            category = sessionStorage.getItem( 'analytify_forms_category' );
            id       = sessionStorage.getItem( 'analytify_forms_id' );
        }

        if ( ! category || ! id ) {
            return;
        }
        const s = ensureFormState( category, id );
        if ( ! s.has_interacted || s.is_transitioning ) {
            return;
        }

        analytify_forms_send_event( category, id, 'abandonment', s.current_step );

        // Reset interaction and clear storage after abandonment.
        s.has_interacted = false;
        analytify_forms_clear_session( category, id );
    } );

    // Multi-step: current_step stays 1-based; step_complete passes completed index (page - 1).
    jQuery( document ).on( 'gform_page_loaded', ( event, form_id, page ) => {
        const s = ensureFormState( 'analytify_form_gf', String( form_id ) );
        s.current_step = page;
        s.has_interacted = true;
        sessionStorage.setItem( 'analytify_forms_current_step', String( page ) );
        sessionStorage.setItem( 'analytify_forms_has_interacted', 'true' );
        s.is_transitioning = false;
        if ( 'on' === track_gravityforms ) {
            analytify_forms_send_event( 'analytify_form_gf', form_id, 'step_complete', page - 1 );
        }
    } );

    jQuery( document ).on( 'wpformsPageChange', ( event, page, $form ) => {
        const form_id = $form.attr( 'data-formid' );
        if ( ! form_id ) {
            return;
        }
        const s = ensureFormState( 'analytify_form_wpforms', form_id );
        s.current_step = page;
        sessionStorage.setItem( 'analytify_forms_current_step', String( page ) );
        s.is_transitioning = false;
        if ( 'on' === track_wpforms ) {
            analytify_forms_send_event( 'analytify_form_wpforms', form_id, 'step_complete', page - 1 );
        }
    } );

    jQuery( document ).on( 'fluentform_step_completed', ( event, data ) => {
        if ( ! data || ! data.form_id ) {
            return;
        }
        const s = ensureFormState( 'analytify_form_fluentforms', String( data.form_id ) );
        s.current_step = data.step + 1;
        sessionStorage.setItem( 'analytify_forms_current_step', String( s.current_step ) );
        s.is_transitioning = false;
        if ( 'on' === track_fluentforms ) {
            analytify_forms_send_event( 'analytify_form_fluentforms', data.form_id, 'step_complete', data.step );
        }
    } );

    // Reset interaction and clear storage on submission.
    jQuery( document ).on( 'submit', 'form', function() {
        const meta = getFormCategory( jQuery( this ) );
        if ( meta && meta.id ) {
            ensureFormState( meta.category, meta.id ).has_interacted = false;
        }
        analytify_forms_clear_session( meta ? meta.category : '', meta ? meta.id : '' );
    } );

    // submission event for custom forms
    if ( 'on' === custom_form ) {

        // Custom class added in form container.
        jQuery( `.${ANALYTIFY_FORMS_ADDON_CUSTOM_FORM_CLASS} form, form.${ANALYTIFY_FORMS_ADDON_CUSTOM_FORM_CLASS}` ).on( 'submit', function () {
            custom_form_submission( this );
        } );
    }

} );

function custom_form_submission( thisElement ) {

    // Get form name from name attribute, or id attribute, or generate from URL
    let analytify_form_name = '';
    if ( jQuery( thisElement ).hasAttr( 'name' ) ) {
        analytify_form_name = jQuery( thisElement ).attr( 'name' );
    } else if ( jQuery( thisElement ).hasAttr( 'id' ) ) {
        analytify_form_name = jQuery( thisElement ).attr( 'id' );
    } else {
        const defaultLabel = ( 'undefined' !== typeof custom_form_default_label && custom_form_default_label ) ? custom_form_default_label : 'Custom Form on';
        analytify_form_name = `${defaultLabel} ${window.location.href}`;
    }

    if ( 'gtag' === ANALYTIFY_TRACKING_MODE && 'ga4' === property_tracking_mode ) {
        waitForGtag().then( () => {
            gtag( 'event', 'analytify_form', {
                'wpa_link_action': 'submission',
                'wpa_category': 'analytify_form_custom',
                'wpa_link_label': analytify_form_name,
            } );
        } );
    }
}

/**
 * Forminator custom form: <form> often has id forminator-module-{id} and may sit inside .forminator-custom-form.
 * Exclude polls (forminator-poll) and quiz UIs (.forminator-quiz).
 *
 * @param {JQuery} $form jQuery form element
 * @return {boolean}
 */
function analytify_forminator_is_custom_form($form) {
    const id = $form.attr('id') || '';
    if (0 !== id.indexOf('forminator-module-')) {
        return false;
    }
    if ($form.hasClass('forminator-poll')) {
        return false;
    }
    if ($form.closest('.forminator-quiz').length) {
        return false;
    }
    const cls = $form.attr('class') || '';
    if (-1 !== cls.indexOf('forminator-custom-form') || $form.closest('.forminator-custom-form').length) {
        return true;
    }
    return false;
}

/**
 * Resolve Forminator form ID from id="forminator-module-{id}" or hidden form_id.
 *
 * @param {JQuery} $form jQuery form element
 * @return {string}
 */
function analytify_forminator_form_id($form) {
    const modId = $form.attr('id') || '';
    if (0 === modId.indexOf('forminator-module-')) {
        return modId.replace('forminator-module-', '');
    }
    const hid = $form.find('input[name="form_id"]').val();
    return hid ? String(hid) : '';
}

/**
 * weForms: class wpuf-form-add weforms-{id} and hidden form_id; action may be added late so do not rely on it alone.
 *
 * @param {JQuery} $form jQuery form element
 * @return {boolean}
 */
function analytify_weforms_is_form($form) {
    const cls = $form.attr('class') || '';
    if (-1 === cls.indexOf('wpuf-form-add') && -1 === cls.indexOf('weforms-')) {
        return false;
    }
    return /\bweforms-\d+\b/.test(cls) || (0 < $form.find('input[name="form_id"]').length && (
        0 < $form.find('input[name="action"][value="weforms_frontend_submit"]').length ||
        0 < $form.find('input.weforms_submit_btn, input[class*="wpuf_submit_"]').length
    ));
}

/**
 * @param {JQuery} $form jQuery form element
 * @return {string}
 */
function analytify_weforms_form_id($form) {
    const cls = $form.attr('class') || '';
    const m = cls.match(/\bweforms-(\d+)\b/);
    if (m && m[1]) {
        return m[1];
    }
    const hid = $form.find('input[name="form_id"]').val();
    return hid ? String(hid) : '';
}

/**
 * Happyforms: id happyforms-form-{id} and/or hidden happyforms_form_id.
 * Must match only real Happyforms markup so the if/else chain can reach Forminator/weForms/etc.
 *
 * @param {JQuery} $form jQuery form element
 * @return {boolean}
 */
function analytify_happyforms_is_form($form) {
    const id = $form.attr('id') || '';
    if (0 === id.indexOf('happyforms-form-')) {
        return true;
    }
    return 0 < $form.find('input[name="happyforms_form_id"]').length;
}

// Process one form element (used on load + DOM mutations / modals).
function analytify_forms_try_impression_for_form($form) {

    if ('on' === custom_form && ($form.hasClass(ANALYTIFY_FORMS_ADDON_CUSTOM_FORM_CLASS) || $form.parents(`.${ANALYTIFY_FORMS_ADDON_CUSTOM_FORM_CLASS}`).length)) {

        let analytify_form_name = '';
        if ($form.hasAttr('name')) {
            analytify_form_name = $form.attr('name');
        } else if ($form.hasAttr('id')) {
            analytify_form_name = $form.attr('id');
        } else {
            analytify_form_name = `${customFormDefaultLabel} ${window.location.href}`;
        }
        analytify_forms_send_impression('analytify_form_custom', analytify_form_name);

    } else if ('on' === track_cf7 && $form.hasClass('wpcf7-form')) {

        const analytify_form_id = $form.find('input[name="_wpcf7"]').length ? $form.find('input[name="_wpcf7"]').val() : '';
        analytify_forms_send_impression('analytify_form_wpcf7', analytify_form_id);

    } else if ('on' === track_wpforms && $form.hasClass('wpforms-form')) {

        const analytify_form_id = $form.hasAttr('data-formid') ? $form.attr('data-formid') : '';
        analytify_forms_send_impression('analytify_form_wpforms', analytify_form_id);

    } else if ('on' === track_gravityforms && $form.parent().hasClass('gform_wrapper')) {

        const parts = $form.hasAttr('id') ? $form.attr('id').split('_') : '';
        const analytify_form_id = (undefined !== parts[1]) ? parts[1] : '';
        analytify_forms_send_impression('analytify_form_gf', analytify_form_id);

    } else if ('on' === track_formidable && $form.hasClass('frm-show-form')) {

        const analytify_form_id = ($form.find('input[name="form_id"]').length) ? $form.find('input[name="form_id"]').val() : '';
        analytify_forms_send_impression('analytify_form_formidable', analytify_form_id);

    } else if ('on' === track_fluentforms && $form.hasClass('frm-fluent-form')) {

        const analytify_form_id = $form.hasAttr('data-form_id') ? $form.attr('data-form_id') : '';
        analytify_forms_send_impression('analytify_form_fluentforms', analytify_form_id);

    } else if ('on' === track_ninjaforms && $form.closest('.nf-form-cont').length) {

        let analytify_form_id = '';
        const formIdAttr = $form.attr('id') || '';
        const formIdMatch = formIdAttr.match(/^nf-form-(\d+)$/);
        if (formIdMatch) {
            const [, nfFormId] = formIdMatch;
            analytify_form_id = nfFormId;
        } else {
            const contId = $form.closest('.nf-form-cont').attr('id') || '';
            const contIdMatch = contId.match(/^nf-form-(\d+)-cont$/);
            if (contIdMatch) {
                const [, nfFormId] = contIdMatch;
                analytify_form_id = nfFormId;
            }
        }
        if (analytify_form_id) {
            analytify_forms_send_impression('analytify_form_ninja_forms', analytify_form_id);
        }

    } else if ('on' === track_happyforms && analytify_happyforms_is_form($form)) {

        const happyIdAttr = $form.attr('id');
        let analytify_form_id = '';
        if (happyIdAttr && 0 === happyIdAttr.indexOf('happyforms-form-')) {
            analytify_form_id = happyIdAttr.replace('happyforms-form-', '');
        } else if ($form.find('input[name="happyforms_form_id"]').length) {
            analytify_form_id = $form.find('input[name="happyforms_form_id"]').val();
        }
        if (analytify_form_id) {
            analytify_forms_send_impression('analytify_form_happyforms', analytify_form_id);
        }

    } else if ('on' === track_forminator && analytify_forminator_is_custom_form($form)) {

        const analytify_form_id = analytify_forminator_form_id($form);
        if (analytify_form_id) {
            analytify_forms_send_impression('analytify_form_forminator', analytify_form_id);
        }

    } else if ('on' === track_givewp && $form.find('[name="give-form-id"]').length) {

        const giveFormId = $form.find('[name="give-form-id"]').first().val();
        if (giveFormId) {
            analytify_forms_send_impression('analytify_form_givewp', giveFormId);
        }

    } else if ('on' === track_weforms && analytify_weforms_is_form($form)) {

        const weFormId = analytify_weforms_form_id($form);
        if (weFormId) {
            analytify_forms_send_impression('analytify_form_weforms', weFormId);
        }

    } else if ('on' === track_elementor && $form.hasClass('elementor-form')) {

        const analytify_form_id = $form.hasAttr('data-id') ? $form.attr('data-id') : '';
        analytify_forms_send_impression('analytify_form_elementor', analytify_form_id);

    } else if ('on' === track_mailpoet && $form.hasClass('mailpoet_form')) {

        let analytify_form_id = $form.hasAttr('data-id') ? $form.attr('data-id') : '';
        if (!analytify_form_id) {
            analytify_form_id = $form.find('input[name="data[form_id]"]').val() || '';
        }
        analytify_forms_send_impression('analytify_form_mailpoet', analytify_form_id);

    } else if ('on' === track_wsforms && ($form.hasClass('wsf-form') || 0 < $form.closest('.wsf-form').length)) {

        const $wsForm = $form.hasClass('wsf-form') ? $form : $form.closest('.wsf-form');
        const wsRawId = $wsForm.attr('data-id');
        const wsFormId = ( undefined !== wsRawId && null !== wsRawId && '' !== String( wsRawId ) ) ?
            String( wsRawId ) :
            '';
        if (wsFormId) {
            analytify_forms_send_impression('analytify_form_wsforms', wsFormId);
        }
    }
}

/**
 * GiveWP campaign / modal launcher: form lives in iframe later; wrapper is on the parent page with
 * data-analytify-give-form-id (see give_donate_form_add_data_form_id).
 *
 * @return {void}
 */
function analytify_forms_give_parent_page_impressions() {
    if ('on' !== track_givewp) {
        return;
    }
    jQuery(
        '.give-embed-form-wrapper[data-analytify-give-form-id], .root-data-givewp-embed[data-analytify-give-form-id]'
    ).each(function () {
        const fid = jQuery(this).attr('data-analytify-give-form-id');
        if (fid) {
            analytify_forms_send_impression('analytify_form_givewp', fid);
        }
    });

    // GiveWP 3+ block: form id is always in data-form-view-url (form-id=) / data-form-url (p=); use if PHP did not inject.
    jQuery('.root-data-givewp-embed').each(function () {
        const $el = jQuery(this);
        if ($el.attr('data-analytify-give-form-id')) {
            return;
        }
        let fid = '';
        const viewUrl = $el.attr('data-form-view-url') || '';
        const formUrl = $el.attr('data-form-url') || '';
        const mView = viewUrl.match(/[?&]form-id=(\d+)/);
        if (mView) {
            const [, formIdFromView] = mView;
            if (formIdFromView) {
                fid = formIdFromView;
            }
        } else {
            const mP = formUrl.match(/[?&]p=(\d+)/);
            if (mP) {
                const [, formIdFromP] = mP;
                if (formIdFromP) {
                    fid = formIdFromP;
                }
            }
        }
        if (fid) {
            analytify_forms_send_impression('analytify_form_givewp', fid);
        }
    });
}

// tell Google Analytics that a form has been loaded
function analytify_forms_check_impression() {

    jQuery('form').each(function () {
        analytify_forms_try_impression_for_form(jQuery(this));
    });

    analytify_forms_give_parent_page_impressions();
}

function analytify_forms_send_impression( category, id ) {
    analytify_forms_send_event( category, id, 'impression' );
}

/**
 * Sends an event to Google Analytics.
 *
 * @param {string} category The event category.
 * @param {string} id       The form ID.
 * @param {string} action   The action (impression, submission, start, step_complete).
 * @param {number} step     Optional step number for multi-step forms.
 */
function analytify_forms_send_event( category, id, action, step = null ) {

    if ( 'gtag' !== ANALYTIFY_TRACKING_MODE || 'ga4' !== property_tracking_mode ) {
        return;
    }

    waitForGtag().then( () => {
        if ( 'impression' === action && id ) {
            const dedupeKey = formStateKey( category, id );
            if ( analytifyFormsImpressionDeduped.has( dedupeKey ) ) {
                return;
            }
            analytifyFormsImpressionDeduped.add( dedupeKey );
        }

        const event_params = {
            'wpa_link_action': action,
            'wpa_category': category,
            'wpa_link_label': id ? id.toString() : '',
        };

        if ( 'abandonment' === action ) {
            event_params.transport_type = 'beacon';
        }

        gtag( 'event', 'analytify_form', event_params );

        // If we have a step number, send it as a separate 'step' action inside wpa_link_action.
        if ( null !== step ) {
            const step_params = {
                'wpa_link_action': `step ${parseInt( step, 10 )}`,
                'wpa_category': category,
                'wpa_link_label': id ? id.toString() : '',
            };
            if ( 'abandonment' === action ) {
                step_params.transport_type = 'beacon';
            }
            gtag( 'event', 'analytify_form', step_params );
        }
    } );
}

function analytify_forms_schedule_impression_rescan() {
    if (analytifyFormsMutationTimer) {
        clearTimeout(analytifyFormsMutationTimer);
    }
    analytifyFormsMutationTimer = setTimeout(() => {
        analytifyFormsMutationTimer = null;
        analytify_forms_check_impression();
    }, 300);
}

function analytify_forms_setup_dom_observer() {
    if ('undefined' === typeof MutationObserver) {
        return;
    }
    const obs = new MutationObserver(() => {
        analytify_forms_schedule_impression_rescan();
    });
    obs.observe(document.documentElement, {childList: true, subtree: true});
}

function checkHubspotIframes() {
	jQuery( 'iframe[src*="hsforms.net"]' ).each( function () {
		const src = jQuery( this ).attr( 'src' );
		if ( ! src ) {
			return;
		}
		const match = src.match( /_hsFormId=([^&]+)/ );
		if ( ! match ) {
			return;
		}
		const [, formId] = match;
		if ( ! formId ) {
			return;
		}
		if ( analytify_forms_has_session_event( 'analytify_form_hubspot', formId, 'impression' ) ) {
			return;
		}
		analytify_forms_send_impression( 'analytify_form_hubspot', formId );
		analytify_forms_set_session_event( 'analytify_form_hubspot', formId, 'impression' );
	} );
}

function trackJotFormImpressions() {
    jQuery('iframe[src*="jotform.com"]').each(function () {
        const jotFormIframe = jQuery(this);
        const formId = jotFormIframe.attr('id') || jotFormIframe.attr('name') || 'unknown';

        // Impression tracked immediately
        analytify_forms_send_impression('analytify_form_jotform', formId);

        // Track when iframe finishes loading (first load)
        jotFormIframe.on('load', () => {
            analytify_forms_send_impression('analytify_form_jotform', formId);
        });
    });
}

// Run on initial load
jQuery(window).on('load', () => {
    if ('on' == track_hubspot) {
        checkHubspotIframes();

        // Also watch for dynamically loaded iframes
		const observer = new MutationObserver( ( mutations ) => {
			mutations.forEach( ( mutation ) => {
				mutation.addedNodes.forEach( ( node ) => {
					if ( 'IFRAME' !== node.nodeName || ! node.src || ! node.src.includes( 'hsforms.net' ) ) {
						return;
					}
					const match = node.src.match( /_hsFormId=([^&]+)/ );
					if ( ! match ) {
						return;
					}
					const [, formId] = match;
					if ( ! formId ) {
						return;
					}
					if ( analytify_forms_has_session_event( 'analytify_form_hubspot', formId, 'impression' ) ) {
						return;
					}
					analytify_forms_send_impression( 'analytify_form_hubspot', formId );
					analytify_forms_set_session_event( 'analytify_form_hubspot', formId, 'impression' );
				} );
			} );
		} );

        observer.observe(document.body, { childList: true, subtree: true });
    }
});

if ('on' === track_jotform) {
    jQuery(window).on('load', () => {
        trackJotFormImpressions();
    });
}

// Elementor Forms submission (delegated: runs on actual form submit)
if ('on' == track_elementor) {
    jQuery(document).on('submit', 'form.elementor-form', function () {
        const $form = jQuery(this);
        const analytify_form_id = $form.hasAttr('data-id') ? $form.attr('data-id') : '';
        if ('gtag' === ANALYTIFY_TRACKING_MODE && 'ga4' === property_tracking_mode) {
            gtag('event', 'analytify_form', {
                'wpa_link_action': 'submission',
                'wpa_category': 'analytify_form_elementor',
                'wpa_link_label': (analytify_form_id || '').toString(),
            });
        }
    });
}

// MailPoet: no gtag on submit here — MailPoet stops submit from reaching document; submissions use PHP + GA4 MP (analytify-forms-tracking.php).
if ('on' === track_wsforms) {

    // Track WS Forms submission via JavaScript on success (so it persists in GA4 like impression).
    // wsf-submit-success fires after a successful submit; client-side gtag ensures the event
    // is stored in standard reports. Server-side (Measurement Protocol) submissions often
    // show in real-time only and do not persist in event parameter breakdowns.
    if (window.jQuery) {
        // eslint-disable-next-line no-unused-vars
        jQuery(document).on('wsf-submit-success', (event, form_object, form_id, instance_id, form_el, form_canvas_el) => {
            if ('function' === typeof gtag && 'gtag' === ANALYTIFY_TRACKING_MODE && 'ga4' === property_tracking_mode && form_id !== undefined && null !== form_id && '' !== form_id) {
                gtag('event', 'analytify_form', {
                    'wpa_link_action': 'submission',
                    'wpa_category': 'analytify_form_wsforms',
                    'wpa_link_label': String(form_id),
                });
            }
        });
    }
}

/**
 * Clears all Analytify session storage for a specific form.
 *
 * @param {string} category The form category.
 * @param {string} id       The form ID.
 */
function analytify_forms_clear_session( category = '', id = '' ) {
    sessionStorage.removeItem( 'analytify_forms_has_interacted' );
    sessionStorage.removeItem( 'analytify_forms_current_step' );
    sessionStorage.removeItem( 'analytify_forms_category' );
    sessionStorage.removeItem( 'analytify_forms_id' );

    if ( category && id ) {
        sessionStorage.removeItem( `analytify_form_impression_${category}_${id}` );
        sessionStorage.removeItem( `analytify_form_start_${category}_${id}` );
    }
}

/**
 * Poll until the analytics hook is ready, then run impressions (retry cap avoids infinite loop).
 *
 * @param {string} trackingMode The current tracking script used.
 * @param {number} [retries]    Internal retry counter.
 * @return {void}
 */
function analytify_forms_load( trackingMode, retries = 0 ) {
    if ( 50 < retries ) {
        return;
    }
    let repeat = true;

    if ( 'gtag' === trackingMode ) {

        // Must match waitForGtag(): a truthy non-function gtag would skip impressions forever.
        if ( 'function' === typeof gtag ) {
            repeat = false;
        }
    } else if ( 'undefined' !== typeof ga && ga && Object.prototype.hasOwnProperty.call( ga, 'loaded' ) && true === ga.loaded ) {
        repeat = false;
    }

    if ( repeat ) {
        setTimeout( () => analytify_forms_load( trackingMode, retries + 1 ), 200 );
    } else {
        analytify_forms_check_impression();

        // AJAX-loaded Forminator/weForms, dynamic GiveWP parent wrappers, etc. appear after first paint.
        analytify_forms_setup_dom_observer();
    }
}
