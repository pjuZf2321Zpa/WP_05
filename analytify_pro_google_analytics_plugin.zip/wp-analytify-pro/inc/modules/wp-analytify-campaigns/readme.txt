Hi there,
We at Analytify welcomes you to our premium users family.


== Installation ==
You should have installed Analytify Free + Pro versions to use this Analytify for Campaigns add-on.

If you have any problem, please send an email to us at support@analytify.io


Cheers
Adnan from Analytify LLC


== Changelog ==

= 5.1.0 - 2023-08-10 =
* Enhancement: Author name and uri modified.
* Enhancement: Translation files updated.
* Enhancement: No campaigns message and layout changed.

= 5.0.1 - 2023-05-30 =
* Enhancement: Use main dashboard saved date.
* Enhancement: Changelog button text updated.

= 5.0.0 - 2023-04-18 =
* New Feature: Google Analytics GA4 integration is added.
* New Feature: Google Search Console (webmasters) Integrated.
* Enhancement: Pageload speed improvement.
* Enhancement: UI Improvements.

= 2.0.1 8th April, 2021 =
* Bug Fix: Fix datepicker.

= 2.0.0 12th March, 2021 =
* New Feature: New dashboard design.
* Enhancement: Update admin submenu ranking.
* Enhancement: Code refactoring.
* Enhancement: Update admin notices.

= 1.1.2 - January 25th, 2021 =
* Bug Fix: Invalid date format issue while fetching stats from Google Analytics.

= 1.1.1 - January 7th, 2019 =
* Bug Fix: Incorrect values for "AVG session duration" & "page/session"
* Bug Fix: License activation issue.

= 1.1.0 - December 31st, 2018 =
* New Feature: Add detailed campaign stats.
* Enhancement: Format number stats.
* Enhancement: Code Improvement.

= 1.0.4 - October 26th, 2018 =

* New Feature: View sales details of each campaign. You should be using WooCommerce Analytify addon to see that.

The full changelog is available at https://analytify.io/changelog/
