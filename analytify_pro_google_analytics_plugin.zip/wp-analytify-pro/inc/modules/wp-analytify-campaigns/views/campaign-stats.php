<?php
/**
 * Campaign Stats View.
 *
 * @package WP_Analytify_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$i = 0;

if ( ! empty( $stats['rows'] ) ) {
	foreach ( $stats['rows'] as $row ) {
		++$i;
		?>

		<div class="pa_campaigns_statistics">
			<div class="pa-tdo-left">
				<div class="pa_data_text_wraper">
					<span class="large-count"><?php echo esc_html( $row['sessionCampaignName'] ); ?></span>
					<?php
					if ( '(not set)' === $row['sessionCampaignName'] ) {
						?>
						<span class="analytify-campaigns-hint analytify_tooltip" tabindex="0" role="button" aria-label="<?php esc_attr_e( 'Not Set: The \'keyword\' (not set) simply identifies traffic that doesn\'t arrive via a particular keyword and hence may not come via any search at all. This includes traffic coming from email, referral sites, or even things like Google Images.', 'wp-analytify-pro' ); ?>">
							<span class="dashicons dashicons-editor-help" aria-hidden="true"></span>
							<span class="analytify_tooltiptext"><?php esc_html_e( 'Not Set: The \'keyword\' (not set) simply identifies traffic that doesn\'t arrive via a particular keyword and hence may not come via any search at all. This includes traffic coming from email, referral sites, or even things like Google Images.', 'wp-analytify-pro' ); ?></span>
						</span>
						<?php
					}
					?>
					<br /><br />
					<?php
					if ( class_exists( 'WP_Analytify_WooCommerce_Addon' ) && '(not set)' !== $row['sessionCampaignName'] ) {
						?>
						<a href="<?php echo esc_url( admin_url( 'admin.php?page=analytify-woocommerce&cn=' . $row['sessionCampaignName'] ) ); ?>" style="display:block;margin-top:10px;"><?php esc_html_e( 'View Sale Stats', 'wp-analytify-pro' ); ?></a>
						<?php
					}
					?>
					<a href="#" class="analytify-view-detail-campaings" data-source="<?php echo esc_attr( $row['sessionCampaignName'] ); ?>"><?php esc_html_e( 'View Detail Stats', 'wp-analytify-pro' ); ?></a>
				</div>
			</div>
			<div class="pa-tdo-right" id="pa-tdo-right">
				<div class="pa-bigtext">
					<span class="count-visits"><?php echo esc_html( number_format( $row['sessions'] ) ); ?></span>
					<span class="source"><?php esc_html_e( 'Sessions', 'wp-analytify-pro' ); ?></span>
				</div>

				<div class="pa-bigtext">
					<span class="count-visits">
						<?php
						echo esc_html( ! empty( $row['newUsers'] ) && ! empty( $row['sessions'] ) && $row['sessions'] > 0 ? number_format( round( ( $row['newUsers'] / $row['sessions'] ) * 100, 2 ), 2 ) : '0' );
						?>
					</span>
					<span class="source"><?php esc_html_e( '% New Sessions', 'wp-analytify-pro' ); ?></span>
				</div>

				<div class="pa-bigtext">
					<span class="count-visits"><?php echo esc_html( $row['newUsers'] ); ?></span>
					<span class="source"><?php esc_html_e( 'New Users', 'wp-analytify-pro' ); ?></span>
				</div>
			</div>
			<div class="pa-tdo-rights" id="pa-tdo-rights">

				<div class="pa-bigtext">
					<span class="count-visits"><?php echo esc_html( $row['bounceRate'] ? ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' ) ? WPANALYTIFY_Utils::pretty_numbers( $row['bounceRate'] ) : number_format( $row['bounceRate'], 2 ) ) . '%' : '0%' ); ?></span>
					<span class="source"><?php esc_html_e( 'Bounce Rate', 'wp-analytify-pro' ); ?></span>
				</div>

				<div class="pa-bigtext">
					<span class=" count-visits"><?php echo esc_html( ! empty( $row['sessions'] ) ? number_format( round( $row['screenPageViews'] / $row['sessions'], 2 ), 2 ) : '0' ); ?></span>
					<span class="source"><?php esc_html_e( 'Pages / Session', 'wp-analytify-pro' ); ?></span>
				</div>

				<div class="pa-bigtext">
					<span class="count-visits"><?php echo wp_kses_post( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_time' ) ? WPANALYTIFY_Utils::pretty_time( $row['averageSessionDuration'] ) : number_format( $row['averageSessionDuration'], 2 ) ); ?></span>
					<span class="source"><?php esc_html_e( 'Avg. Session duration', 'wp-analytify-pro' ); ?></span>
				</div>
			</div>
			<div class="analytify-detail-campaings-container"></div>
		</div>

		<?php
	}
} else {

	?>
	<div class="analytify-stats-error-msg">
		<div class="wpb-error-box">
			<span class="blk"><span class="line"></span><span class="dot"></span></span>
			<span class="information-txt"><?php esc_html_e( 'No campaigns detected nor defined.', 'wp-analytify-pro' ); ?></span>
		</div>
	</div>
	<?php
}


