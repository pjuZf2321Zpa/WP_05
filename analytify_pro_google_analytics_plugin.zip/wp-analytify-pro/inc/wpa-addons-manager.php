<?php
// phpcs:ignoreFile WordPress.Files.FileName.InvalidClassFileName
/**
 * This class will work as the core class that handles the
 * activation and deactivation of analytify pro addons.
 *
 * @package WP_Analytify_Pro
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Analytify_Addons_Manager' ) ) {

	/**
	 * Class Analytify_Addons_Manager
	 *
	 * Handles the activation and deactivation of Analytify Pro addons.
	 */
	class Analytify_Addons_Manager {

		/**
		 * List of addons.
		 *
		 * @var array<string, array<string, mixed>>
		 */
		public array $addons;

		/**
		 * Addon directory path.
		 *
		 * @var string
		 */
		public string $addon_directory;

		/**
		 * Constructor.
		 *
		 * @return void
		 */
		public function __construct() {
			$this->addons          = $this->get_addons();
			$this->addon_directory = ( defined( 'ANALYTIFY_PRO_ROOT_PATH' ) ? ANALYTIFY_PRO_ROOT_PATH : '' ) . '/inc/modules/';
			$this->hooks();
		}

		/**
		 * Register hooks.
		 *
		 * @return void
		 */
		public function hooks() {
			foreach ( $this->addons as $addon_slug => $data ) {

				if ( 'active' === $data['status'] ) {
					$plugin_base_name = $addon_slug . '/' . $addon_slug . '.php';
					add_action( "activate_{$plugin_base_name}", array( $this, 'prevent_activation' ) );
				}
			}

			// PMPro / LearnDash / LifterLMS are toggled via wp_analytify_modules; still block standalone ZIPs.
			$module_addon_slugs = array( 'wp-analytify-pmpro', 'wp-analytify-learndash', 'wp-analytify-lifterlms' );
			foreach ( $module_addon_slugs as $addon_slug ) {
				$plugin_base_name = $addon_slug . '/' . $addon_slug . '.php';
				add_action( "activate_{$plugin_base_name}", array( $this, 'prevent_activation' ) );
			}

			add_action( 'wp_ajax_set_addon_state', array( $this, 'set_addon_state' ) );
		}

	/**
	 * Prevent activation of standalone addon plugins.
	 *
	 * @return void
	 */
	public function prevent_activation() {
		$plugin_page_url = admin_url( 'plugins.php' );
		wp_die(
			sprintf(
				// translators: %1$s is strong opening tag, %2$s is version number, %3$s is strong closing tag, %4$s is link opening tag, %5$s is link closing tag.
				esc_html__( 'Sorry, This plugin is now activated as a module in Analytify Pro version %1$s%2$s%3$s. It is recommended that you delete it from plugins. %4$sClick here to return to the Dashboard%5$s.', 'wp-analytify-pro' ),
				'<strong>',
				ANALYTIFY_PRO_VERSION, // phpcs:ignore
				'</strong>',
				'<a href="' . esc_url( $plugin_page_url ) . '">',
				'</a>'
			)
		);
	}

	/**
	 * Set addon state via AJAX.
	 *
	 * @return void
	 */
	public function set_addon_state() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die(
				esc_html__( 'Sorry, you are not allowed to do that.', 'wp-analytify-pro' ),
				'',
				array( 'response' => 403 )
			);
		}

		// Do a security check first.
		if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'addons' ) ) {
			wp_die(
				esc_html__( 'Sorry, you are not allowed to do that.', 'wp-analytify-pro' ),
				'',
				array( 'response' => 403 )
			);
		}

		$addon_slug = isset( $_POST['addon_slug'] ) ? sanitize_text_field( wp_unslash( $_POST['addon_slug'] ) ) : '';
		$set_state  = isset( $_POST['set_state'] ) ? sanitize_text_field( wp_unslash( $_POST['set_state'] ) ) : '';

		if ( '' === $addon_slug || ! isset( $this->addons[ $addon_slug ] ) ) {
			wp_die(
				esc_html__( 'Invalid add-on.', 'wp-analytify-pro' ),
				'',
				array( 'response' => 400 )
			);
		}

		if ( 'active' === $set_state ) {
			$this->activate_addon( $addon_slug );
		} else {
			$this->deactivate_addon( $addon_slug );
		}

		$addon_name   = isset( $this->addons[ $addon_slug ]['name'] ) ? (string) $this->addons[ $addon_slug ]['name'] : $addon_slug;
		$addon_status = isset( $this->addons[ $addon_slug ]['status'] ) ? (string) $this->addons[ $addon_slug ]['status'] : '';

		echo esc_html(
			sprintf(
				/* translators: 1: add-on name, 2: new status (active/inactive). */
				__( 'Add-on %1$s state changed to %2$s.', 'wp-analytify-pro' ),
				$addon_name,
				$addon_status
			)
		);
		wp_die();
	}

		/**
		 * Get addons configuration.
		 *
		 * @return array<string, mixed>
		 */
		public function get_addons(): array {

			$addons_saved = get_option( 'wp_analytify_pro_addons' );

			return is_array( $addons_saved ) ? $addons_saved : array();
		}

	/**
	 * Load active addons.
	 *
	 * @return void
	 */
	public function load_addons() {

			if ( ! function_exists( 'is_plugin_active' ) && defined( 'ABSPATH' ) ) {
				$plugin_file = ABSPATH . 'wp-admin/includes/plugin.php';
				if ( file_exists( $plugin_file ) ) {
					include_once $plugin_file;
				}
			}

			$module_addon_slugs = array( 'wp-analytify-pmpro', 'wp-analytify-learndash', 'wp-analytify-lifterlms' );
			$modules_opt        = get_option( 'wp_analytify_modules', array() );
			if ( ! is_array( $modules_opt ) ) {
				$modules_opt = array();
			}

			foreach ( $this->addons as $addon_slug => $data ) {
				if ( in_array( $addon_slug, $module_addon_slugs, true ) ) {
					continue;
				}

				$plugin_file = $addon_slug . '/' . $addon_slug . '.php';
				$addon_file  = $this->addon_directory . $plugin_file;

				if ( 'active' === $data['status'] && file_exists( $addon_file ) && ! is_plugin_active( $plugin_file ) ) {
					require_once $addon_file;
				}
			}

			foreach ( $module_addon_slugs as $addon_slug ) {
				$plugin_file = $addon_slug . '/' . $addon_slug . '.php';
				$addon_file  = $this->addon_directory . $plugin_file;
				$from_pro    = isset( $this->addons[ $addon_slug ] ) && 'active' === $this->addons[ $addon_slug ]['status'];
				$from_module = isset( $modules_opt[ $addon_slug ]['status'] ) && 'active' === $modules_opt[ $addon_slug ]['status'];
				if ( ( $from_pro || $from_module ) && file_exists( $addon_file ) && ! is_plugin_active( $plugin_file ) ) {
					require_once $addon_file;
				}
			}
		}

	/**
	 * Activate an addon.
	 *
	 * @param string $slug Addon slug.
	 * @return void
	 */
	public function activate_addon( string $slug ) {

		$this->addons[ $slug ]['status'] = 'active';

		update_option( 'wp_analytify_pro_addons', $this->addons );
	}

	/**
	 * Deactivate an addon.
	 *
	 * @param string $slug Addon slug.
	 * @return void
	 */
	public function deactivate_addon( string $slug ) {

			$this->addons[ $slug ]['status'] = 'inactive';

			update_option( 'wp_analytify_pro_addons', $this->addons );
		}
	}
}
