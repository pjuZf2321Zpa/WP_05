Welcome!

Analytify Pro works as an add-on of Core version which is Free and available at WordPress.org Plugin Directory: https://wordpress.org/plugins/wp-analytify/
You will install Core version first and then Pro version. Core and Pro versions are necessary to use other add-ons like WooCommerce, EDD, Automated Email notifications etc.

For more help, checkout our YouTube Channel videos and Subscribe at https://www.youtube.com/channel/UCRjDcNZqf-Vo_2Ux_QLyBCA/videos

Our Documentation is available at https://analytify.io/documentation/

Cheers,

Adnan from Analytify LLC.

== Installation ==

You should have installed Analytify Free + Pro versions to use this Analytify for WooCommerce add-on.

If you have any problem, please send an email to us at support@analytify.io


== Changelog ==

= 9.1.2 – 2026-08-17 =
* Enhancement: All CSS/JS assets are now properly minified for faster page loads.
* Enhancement: Limited the WooCommerce, EDD, and LifterLMS admin scripts to their concerning pages.
* Bug Fix: GA4 gtag events no longer get forced into `debug_mode`, so production data isn't routed to GA4 DebugView.

= 9.1.1 – 2026-08-04 =
* Enhancement: CSV exports now show the same number of rows as their corresponding dashboard widgets, keeping exported data consistent with what's displayed on-screen.
* Enhancement: General Stats CSV export now uses cached data for faster exports.
* Enhancement: Clarified add-on activation notices (AMP, PMPro, LearnDash) to specify which add-on requires the dependency.
* Bug Fix: Fixed dashboard table sorting so values with k/m/b suffixes (e.g. "21.2k") sort correctly instead of by their displayed text.
* Bug Fix: Fixed table sorting not working on the Goals, Campaigns, LearnDash, and Paid Memberships Pro dashboard pages.
* Bug Fix: Fixed inconsistent spacing and layout on the Campaigns dashboard stat boxes.
* Bug Fix: Fixed a misaligned Refresh button on the RealTime Stats dashboard widget.
* Bug Fix: Fixed Enhanced Tel Link Analytics summary cards rendering with mismatched heights, and added a proper error message when data fails to load.
* Bug Fix: Fixed minor alignment issues in email report tables and in the Search Console, Search Terms, and Demographics dashboard widget headers.

= 9.1.0 – 2026-07-15 =
* New Feature: Introduced visitor countries and cities in the Realtime dashboard.
* New Feature: Introduced Forms add-on tracking for additional form plugins (Happyforms, Forminator, GiveWP, and WeForms).
* Enhancement: Added table styling options (colors, font size, layout) to the Analytify shortcode and block.
* Enhancement: Added validation for ad-pixel ID fields (Meta, TikTok, LinkedIn, Pinterest, X, Snapchat, Microsoft UET) to prevent invalid values from being saved.
* Enhancement: Refreshed email report icon/logo assets for sharper rendering.
* Enhancement: Improved reliability of license deactivation.
* Enhancement: Clearer update notices for license renewal vs. Core updates, with a direct update link.
* Bug fix: World‑map shortcode now correctly shows geographic data for specific periods using the `[analytify_worldmap]` shortcode.
* Bug fix: Custom‑range logic fixed in email reports for proper date‑range behavior.
* Bug Fix: Fixed an issue where Fluent Forms submissions were sometimes not tracked after a Fluent Forms update.
* Bug Fix: Fixed a JavaScript error that silently broke anchor/hash-based virtual pageview tracking in Events Tracking.
* Bug Fix: Author Stats CSV export now correctly matches GA4 data.
* Bug Fix: Social Media CSV export now actually filters for social referral sources instead of exporting unfiltered top referrers.
* Bug Fix: Email report tables no longer render blank when a reporting period has no activity, now shows a proper "no activity" message.
* Bug Fix: Diagnostic shortcode error messages are now only shown to administrators, not site visitors.
* Bug Fix: Enhanced Tel Link Analytics dashboard table is no longer broken on mobile screens.
* Bug Fix: Fixed 404, JavaScript, and AJAX error stat boxes not displaying on the dashboard.
* Bug Fix: Fixed WooCommerce Orders page bulk actions.
* Bug Fix: Fixed WooCommerce and Paid Memberships Pro dashboard date range filters not applying correctly.
* Compatibility: Compatible with WordPress 7.0.

= 9.0.2 – 2026-05-12 =
* Enhancement: Added `analytify_authors_dashboard_role_user_limits` filter for author dashboard limit (default: 5).
* Enhancement: Refactored and optimized code for improved maintainability and performance.

= 9.0.1 - 2026-05-01 =
* Bug Fix: Improved WooCommerce order tracking to avoid duplicate or missed GA4 transaction hits.
* Security: Hardened WooCommerce and email tracking with improved validation and sanitization.
* Enhancement: Updated WooCommerce module assets, build dependencies, and internal integration code.

= 9.0.0 - 2026-04-29 =
* New Feature: Introduced Pixels Tracking for multi-platform conversion and ad tracking.
* New Feature: Introduced LearnDash event tracking and analytics dashboard.
* New Feature: Introduced LifterLMS event tracking and analytics dashboard.
* New Feature: Introduced Paid Memberships Pro tracking with dedicated reports and funnels.
* New Feature: Introduced Forms add-on tracking for additional form plugins (Elementor, Jotform, HubSpot, MailPoet, and WS Form).
* New Feature: Introduced multi-step form tracking with per-step and abandonment events.
* New Feature: Introduced GA4-powered video statistics in posts, shortcodes, and emails.
* New Feature: Introduced WooCommerce first page before purchase insight.
* New Feature: Introduced WooCommerce refund rate metric to dashboard reports.
* New Feature: Introduced Easy Digital Downloads churn rate metric.
* New Feature: Introduced Easy Digital Downloads refund rate metric.
* New Feature: Introduced Easy Digital Downloads multi-currency reporting support.
* New Feature: Introduced `analytify_api_limit_top_pages_email` filter for email reports.
* New Feature: Added custom dimensions to support enhanced `tel:` link tracking ahead of Enhanced Tel Link Analytics reports.
* Enhancement: Improved author login with author-specific analytics visibility.
* Enhancement: Added structured logging for key Analytify Pro operations.
* Enhancement: Improved email report scheduling and date range selection.
* Enhancement: Improved author dropdown performance and organized authors by role for easier selection when viewing stats.
* Enhancement: Code re-factorization and improvements.
* Bug Fix: Fixed fatal error in WooCommerce integration client ID handling.
* Bug Fix: Fixed forms tracking email footer summary details.
* Compatibility: Compatible with WordPress 7.0

= 8.1.1 - 2026-02-27 =
* Bugfix: Fixed events page reporting issue for translated dashboard.
* Bugfix: Fixed fatal TypeError in WooCommerce email tracking hook.
* Bugfix: Fixed email report stats date issue for cities and countries.
* Bugfix: Fixed custom forms impression tracking, tracking script updates, and help tab email dropdown.
* Enhancement: Resolved WooCommerce subscription plugin conflict.

= 8.1.0 - 2026-02-09 =
* Enhancement: Updated the POT and all supported (DE, ES, FR, IT, nb_NO, NL, RU, and TR) languages.
* Enhancement: Removed the deprecated Enhanced Link Attribution (UA-only) option as part of GA4 cleanup and UI simplification.
* Bugfix: Fixed an UI issue with email formatting in reports.
* Bugfix: Updated the Geolocation REST API to use a dynamic date range in email reports.
* Bugfix: Easy Digital Downloads reports now show correct sales and download data.
* Bugfix: Email reporting notes now support HTML formatting for better customization.

= 8.0.2 - 2026-01-10 =
* Bugfix: WooCommerce checkout failures caused by analytics tracking conflicts.

= 8.0.1 - 2026-01-09 =
* Bugfix: Resolved critical errors that were preventing WooCommerce checkout completion.
* Bugfix: Fixed slow loading issues on product shop pages.
* Bugfix: Restored WooCommerce email tracking functionality.
* Enhancement: Improved GA4 tracking stability and reliability.
* Enhancement: Better error handling for a smoother user experience.

= 8.0.0 - 2026-01-06 =
* Enhancement: Applied coding standards and optimized the codebase for improved performance and faster loading times.
* Enhancement: Added animated loaders and smooth UI feedback for license validation and email notification actions.
* Enhancement: Added a Tools section in the Help tab for improved user experience.
* Enhancement: Improved Analytify notification layout for better readability.
* Bug Fix: Resolved Google Analytics link attribution and WooCommerce tracking issues.
* Compatibility: Compatible with WordPress 6.9

= 7.1.1 - 2025-11-20 =
* Bugfix: Gravity Form table layout.
* Bugfix: Dual script issue.
* Bugfix: Fix Custom Dimensions Reporting.

= 7.1.0 - 2025-11-11 =
* New Feature: Introduced a new dimension for Archives statistics.
* Enhancement: Limited admin notices to Analytify-specific pages only.
* Bugfix: Restricted WooCommerce and Easy Digital Downloads add-ons activation to prevent unauthorized access.
* Bugfix: Resolved Analytify Pro version detection issue flagged by WordFence security scans.
* Bugfix: Email Add-On - Set default city value when location data is not available.

= 7.0.4 - 2025-09-16 =
* Bugfix: Restored Front end affiliate link tracking.
* Bugfix: World Map – Updated filter to fetch post slug instead of title.
* Bugfix: Resolved a vulnerability in the Authors Tracking addon to ensure safer data handling.
* Enhancement: Authors tracking is now based on display name instead of username.

= 7.0.3 - 2025-08-12 =
* Bugfix: Resolved a changelog display issue on the Plugins screen.
* Bugfix: Improved add-on activation logic for Easy Digital Downloads (EDD) and WooCommerce integrations.
* Enhancement: Minor improvements to admin notice behavior.

= 7.0.2 - 2025-07-31 =
* Enhancement: Resolved Analytify Pro version detection issue flagged by WordFence security scans.

= 7.0.1 - 2025-07-24 =
* Bugfix: Resolved PHP warnings and notices throughout the plugin to improve overall stability and WordPress compatibility.
* Bugfix: Improved license validation system reliability and enhanced admin notice display for better user experience.
* Bugfix: Corrected automatic activation behavior for WooCommerce and Easy Digital Downloads add-ons to respect user preferences.

= 7.0.0 - 2025-07-22 =
* Bugfix: Resolved WooCommerce tracking compatibility issues with High-Performance Order Storage (HPOS) for seamless order tracking.
* Bugfix: Hide social media section in email reports when no statistics are available.
* Bugfix: Improved GA4 cookie handling by correctly extracting the session ID, resolving WooCommerce analytics tracking issues.
* Enhancement: Complete migration from Google Analytics 3 (UA) to Google Analytics 4 (GA4) - removed legacy GA3 and GA4 SDK libraries and implemented direct GA4 API integration for improved performance and reliability.
* Enhancement: Added comprehensive multi-currency support for WooCommerce tracking, enabling accurate revenue tracking across different currencies and regions.
* Enhancement: Implemented advanced search and filtering capabilities across all data tables including Interests, Demographics, Search Terms, and Search Console reports for improved data analysis.
* Enhancement: Redesigned pagination layout in the dashboard for better user experience and improved navigation through large datasets.
* Enhancement: Enhanced sorting functionality in the dashboard with improved visual indicators and more intuitive controls.
* Enhancement: Streamlined import functionality in the dashboard with better error handling and user feedback.
* Enhancement: Various bug fixes, performance optimizations, and code improvements for enhanced stability and maintainability.
* Enhancement: Added `page_id` attribute to the `analytify-worldmap` shortcode for displaying page-specific World Map statistics.

= 6.1.0 - 2025-04-24 =
* New Feature: Analytify Paid add-ons (Forms, Goals, and Email) are now merged into Analytify Pro as modules. You can directly activate/deactivate these from the Add-ons page.
* New Feature: Download or export dashboard analytics in PDF format.
* New Feature: Introduces the Pie chart over doughnut chart in Analytify dashboard.
* New Feature: Added Conversion Rate value to the Forms Tracking Dashboard.
* Bug Fix: Added missing icon for Email concerning mobile device stats.
* Enhancement: Code re-factorization and improvements.
* Compatibility: Compatible to WordPress 6.8

= 6.0.0 - 2025-03-05 =
* New Feature: Analytify Paid add-ons (Campaigns, Authors, Easy Digital Downloads, and WooCommerce) are now merged into Analytify Pro as modules. You can directly activate/deactivate these from the Add-ons page.
* New Feature: Introducing a new dashboard for Video Tracking in the Conversions tab. 
* New Feature: Introducing the Google PageSpeed Insights Dashboard in Acquisitions tab to analyze your website's performance.
* New Feature: Added a User Interests Stats in the Demographics Dashboard for deeper audience insights.
* New Feature: Added UTM Term and UTM Content in the Campaigns Dashboard's "View Detail Stats" table. 
* New Feature: Added Conversion Rate stat in WooCommerce and EDD dashboards.  
* New Feature: Added First Purchasers stat in WooCommerce and EDD dashboards. 
* Bug Fix: CSV Export options not working for WooCommerce dashboards. 
* Enhancement: Minor bug fixes and code improvements.

= 5.5.1 - 2025-02-04 =
* New Feature: Google Search Console Report in Acquisition Tab.
* Enhancement: Updated ECharts library to the latest version 5.5.1
* Enhancement: Removed deprecated Google Optimize module.
* Enhancement: Removed Front end Stats Option for GA4. ShortCodes will work though.
* Enhancement: Improved Responsiveness of the World Map for Visitors.
* Enhancement: CSS Improvements for charts.
* Bug Fix: Years section in the Visitors/Views Graph on Overview Dashboard showing no data. 

= 5.5.0 - 2024-11-06 =
* Enhancement: Removing Google Analytics V3 Library from the plugin completely.
* Enhancement: Disable Front end Stats Option for GA4 and will remove in next releases. ShortCodes will work though.
* Compatibility: Compatible to WordPress 6.7

= 5.3.0 - 2024-07-09 =
* New Feature: Social Media GA4 analytics added for gutenberg block editor. [https://analytify.io/doc/add-social-media-stats-with-advance-short-code-on-post-or-page/]
* Enhancement: Social Media analytics shortcode for GA4.
* Bug Fix: World Map analytics script issue fixed and color filter added. [https://analytify.io/doc/analytify-filters/]
* Bug Fix: License key conflict upgrade issue.
* Enhancement: Customize color for World Map analytics.
* Compatibility: Compatible to WordPress 6.6

= 5.2.1 - 2024-04-25 =
* Enhancement: WorldMap display shortcode improved.
* Enhancement: ShortCodes overall improvement.
* Bug Fix: Google Optimize settings error in Console log.
* Bug Fix: Conflict with Yoast SEO score analytics function.
* Compatibility: Compatible to WordPress 6.5

= 5.2.0 - 2024-01-22 =
* New Feature: Introducing Google Ads Addon, You can now track your Google Ads conversions with Analytify Pro.
* New Feature: Custom Gutenberg block for creating Analytify ShortCode.
* New Feature: Filter Added for type of Comparison chart.
* Bug Fix: csv downloads incorrect results fixed.
* Bug Fix: PHP warnings fixed.
* Enhancement: Loads js script only where it's required.
* Enhancement: We made all the plugin sections responsive
* Compatibility: Compatible to WordPress 6.4 and PHP 8.2.10

= 5.1.0 - 2023-08-10 =
* New Feature: License details added under the license tab.
* Bug Fix: PHP 8.2.* deprecation notices removed.
* Enhancement: Comparison graph issues fixed.

= 5.0.4 - 2023-06-20 =
* Bug Fix: Comparison graph 0 index problem fixed.
* Enhancement: Line graph data corrected.
* Enhancement: Top numbers under "visitors" and "views" flipped.
* Enhancement: Events tracking js file minified.
* Enhancement: Correct getting started link added.
* Enhancement: Events tracking settings form save restriction removed.
* Enhancement: translation files updated.

= 5.0.3 - 2023-05-30 =
* Bug Fix: Comparison graph month view position corrected.
* Bug Fix: Comparison graph stats on line points and on bar fixed.
* Bug Fix: World map ShortCode fixed.
* Bug Fix: AMP addon warnings fixed.
* Enhancement: Use main dashboard saved date.

= 5.0.2 - 2023-05-10 =
* Enhancement: Comparison graph modified.
* Enhancement: Error handling added on comparison graph script.

= 5.0.1 - 2023-04-26 =
* Bug Fix: Undefined function wpa_get_analytics on showing single page/post stats at front-end.

= 5.0.0 - 2023-04-18 =
* New Feature: Google Analytics GA4 integration is added.
* New Feature: Google Search Console (webmasters) Integrated.
* Enhancement: Pageload speed improvement.
* Enhancement: UI Improvements.

= 4.1.6 - 2022-06-27 =
* Bug Fix: Link attribution cause multiple page views hit.

= 4.1.5 - 2022-04-19 =
* Bug Fix: Compatibility issues with PHP 8.0+

= 4.1.4 - 2022-04-15 =
* New Feature: Exclude specific post/page from tracking.
* New Feature: Add chat-box for premium customer support.

= 4.1.3 - 2022-02-28 =
* New Feature: Download CSV for events tracking dashboard.
* New Feature: Download CSV for events tracking dashboard.

= 4.1.2 - 2021-12-27 =
* Bug Fix: Exclude Real-time reporting from dashboard settings.

= 4.1.1 - 2021-11-01 =
* Bug Fix: Errors in Real-time reporting dashboard.
* Bug Fix: Undefined error in APM add-on.

= 4.1.0 - 2021-06-21 =
* New Feature: Add the Global Site Tag (gtag.js) tracking compatibility.
* Enhancement: Add email and tel links reporting in Events Tracking.
* Enhancement: Update diagnostic information for additional details.
* Enhancement: Add translatable strings and sanitize date field data.
* Enhancement: Track authors by user name in Custom Dimensions module.
* Bug Fix: Errors in tracking with AMP when Custom Dimensions module is enabled.

= 4.0.2 - 2021-05-17 =
* Enhancement: Enable all modules on installation.
* Enhancement: Add update routine.
* Enhancement: Change addons activation button text.

= 4.0.1 - 2021-04-08 =
* Enhancement: Remove unused assets.
* Bug Fix: Fix text domain in modules.

= 4.0.0 - 2021-03-12 =
* New Feature: New Analytics Dashboard Layout.
* New Feature: Events Tracking.
* New Feature: Authors Tracking and Dashboard.
* New Feature: Custom Dimensions Tracking.
* New Feature: Affiliates Tracking.
* New Feature: Links Tracking.
* New Feature: Clicks Tracking.
* New Feature: Google AMP Support.
* New Feature: Google Optimize Support.
* New Feature: Forms Tracking for Gravity Forms, WPForms, Contact Form 7, Custom Forms, Formidable Forms, Ninja Forms.
* New Feature: New Settings Page Design.
* Enhancement: Upgrade addons page active/deactivate functionality.
* Bug Fix: Post edit page reloading on save.
* Bug Fix: Enfolds Avia builder was not able to edit.
* Compatibility: Compatible with WordPress 5.7

= 2.2.2 - 2021-01-26 =
* New Feature: Turkish translation is added.
* Enhancement: Shortcode now completely supports widget area.
* Bug Fix: Invalid date format issue while fetching stats from Google Analytics.

= 2.2.1 - 2020-08-06 =
* Enhancement: Add translatable strings for graph stats.

= 2.2.0 - 2020-07-26 =
* New Feature: Shortcodes for Gutenberg editor.
* New Feature: Page path filter in shortcodes for site that use domain mapping.
* Enhancement: Update admin notices layout.

= 2.1.2 - 2019-05-05 =
* New Feature: Add 'Entrance Exits stats' on single pages/posts.

= 2.1.1 - 2018-12-31 =
* New Feature: Site Search tracking.
* Enhancement: Fix number format.
* Enhancement: Code Improvement.

= 2.1 - 2018-12-10 =
* Enhancement: Fix translatable stings issue.
* Enhancement: Add filter to change the comparison graph color.

= 2.0.22 - November 30, 2018 =
* BugFix: Plugin dependency issue on Multisite.
* Enhancement: Show shortcode icon, if user have Analytify Dashboard access.
* Enhancement: French language added.

= 2.0.21 - October 26, 2018 =
* Enhancement: Date Selection will effect on Compare Stats.
* Enhancement: Better Cache Algorithm.
* Enhancement: Add cache for single page/post stats.
* Enhancement: Error Handling.
* Enhancement: Add Error logs.
* Enhancement: Code Refactor.
* Enhancement: Better User Experience.
* Enhancement: French language added.
* Enhancement: Settings Text updated.

= 2.0.20 - August 15th, 2018 =
* BugFix: Advance shortcode calendar.
* Enhancement: Add "This Year" & "Last Year" support in shortcode.
* Enhancement: Add "Country" & "Country ISO" dimensions in shortcode.

= 2.0.19 - March 25th, 2018 =

* BugFix: Cache issue for comparison stats on dashboard page.

The full changelog is available at https://analytify.io/changelog/
