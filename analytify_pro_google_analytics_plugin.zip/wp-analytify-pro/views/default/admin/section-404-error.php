<?php
/**
 * Section for 404 Error stats.
 *
 * @package WP_Analytify_Pro
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$report_url        = isset( $report_url ) ? $report_url : '';
$report_date_range = isset( $report_date_range ) ? $report_date_range : '';

$ga_dashboard_link = '';
if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_all_stats_link' ) ) {
	$ga_dashboard_link = WPANALYTIFY_Utils::get_all_stats_link( $report_url, '404-error', false );
}

$fallback_url = 'https://analytics.google.com/analytics/web/#/report/content-event-events/' . $report_url . $report_date_range . '&explorer-segmentExplorer.segmentId=analytics.eventLabel&_r.drilldown=analytics.eventCategory:404%20Error&explorer-table.plotKeys=%5B%5D&explorer-segmentExplorer.segmentId=analytics.eventLabel/';
?>

<div class="analytify_general_status analytify_status_box_wraper analytify_section_404_error_stats" data-endpoint-pro="404-error" data-target=".analytify_section_404_error_stats">
	<div class="analytify_status_header analytify_header_adj">
		<h3>
		<?php esc_html_e( 'Top 404 Pages Errors', 'wp-analytify-pro' ); ?>
		<?php if ( $ga_dashboard_link ) : ?>
		<a href="javascript:return false;" data-ga-dashboard-pro-link="<?php echo esc_attr( $ga_dashboard_link ); ?>" data-ga-dashboard-link="<?php echo esc_attr( $ga_dashboard_link ); ?>" target="_blank" class="analytify_tooltip"><span class="analytify_tooltiptext"><?php esc_html_e( 'View All 404 Errors', 'wp-analytify-pro' ); ?></span><span aria-hidden="true" class="dashicons dashicons-external"></span></a>
		<?php else : ?>
		<a href="<?php echo esc_url( $fallback_url ); ?>" target="_blank" class="analytify_tooltip"><span class="analytify_tooltiptext"><?php esc_html_e( 'View All 404 Errors', 'wp-analytify-pro' ); ?></span><span aria-hidden="true" class="dashicons dashicons-external"></span></a>
		<?php endif; ?>
		<a href="#" class="analytify-export-data analytify_tooltip" data-stats-type="top-404">
			<span class="analytify_tooltiptext"><?php esc_html_e( 'Export Top 404 Errors', 'wp-analytify-pro' ); ?></span>
		</a>
			<img src="<?php echo esc_url( admin_url( 'images/spinner.gif' ) ); ?>" class='analytify-export-loader' style="display:none">
		</h3>
	</div>
	<div class="analytify_status_body">
		<div class="stats-wrapper"></div>
	</div>
	<div class="analytify_stats_loading">
		<table class="analytify_data_tables">
			<thead>
				<tr>
					<th class="analytify_num_row"><p class="skt-loading light-gray"></p></th>
					<th class="analytify_txt_left"><p class="skt-loading light-gray"></p></th>
					<th class="analytify_value_row"><p class="skt-loading light-gray"></p></th>
				</tr>
			</thead>
			<tbody>
				<?php for ( $i = 0; $i < 5; $i++ ) { ?>
				<tr>
					<td class="analytify_txt_center"><p class="skt-loading"></p></td>
					<td><p class="skt-loading"></p></td>
					<td class="analytify_txt_center"><p class="skt-loading"></p></td>
				</tr>
				<?php } ?>
			</tbody>
		</table>
	</div>
</div>
