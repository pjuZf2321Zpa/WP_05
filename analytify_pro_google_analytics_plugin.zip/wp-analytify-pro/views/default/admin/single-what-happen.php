<?php
/**
 * View of Page Entrance/Exit Statistics.
 *
 * @package WP_Analytify_Pro
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
/**
 * Display single page entrance/exit statistics.
 *
 * @param mixed                $wp_analytify WP Analytify instance.
 * @param array<string, mixed> $stats Statistics data.
 * @return string JSON encoded result.
 */
function analytify_single_what_happen( $wp_analytify, $stats ) {

	ob_start();
	?>

	<table class="analytify_data_tables analytify_page_stats_table">
	<thead>
		<tr>
		<th class="analytify_txt_center analytify_compair_value_row"><?php esc_html_e( 'Entrance', 'wp-analytify-pro' ); ?></th>
		<th class="analytify_txt_center analytify_compair_value_row"><?php esc_html_e( 'Exits', 'wp-analytify-pro' ); ?></th>
		<th class="analytify_txt_center analytify_compair_row"><?php esc_html_e( 'Entrance% Exits%', 'wp-analytify-pro' ); ?></th>
		</tr>
	</thead>
	<tbody>

	<?php
	$url          = $stats['rows'][0][1];
	$top_entrance = $stats['rows'][0][2];
	$rows         = $stats['rows'][0];

	if ( $rows > 0 ) {
		$i = 0;

		$dashboard_profile_id = $GLOBALS['WP_ANALYTIFY']->settings->get_option( 'profile_for_dashboard', 'wp-analytify-profile' ); // phpcs:ignore WordPress.NamingConventions.ValidVariableName.VariableNotSnakeCase
		$site_url             = ( class_exists( 'WP_ANALYTIFY_FUNCTIONS' ) && method_exists( 'WP_ANALYTIFY_FUNCTIONS', 'search_profile_info' ) ) ? WP_ANALYTIFY_FUNCTIONS::search_profile_info( $dashboard_profile_id, 'websiteUrl' ) : '';

		foreach ( $rows as $row ) {
			++$i;
			?>
		<tr>
		<td class="analytify_txt_center analytify_w_300 analytify_l_f"><?php echo esc_html( ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' ) ) ? WPANALYTIFY_Utils::pretty_numbers( $row['entrances'] ) : number_format( $row['entrances'] ) ); ?></td>
		<td class="analytify_txt_center analytify_w_300 analytify_l_f"><?php echo esc_html( ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' ) ) ? WPANALYTIFY_Utils::pretty_numbers( $row['exits'] ) : number_format( $row['exits'] ) ); ?></td>
		<td class="analytify_txt_center analytify_w_300 analytify_l_f">

			<div class="analytify_enter_exit_bars analytify_enter">
			<?php echo esc_html( round( $row['entranceRate'], 2 ) . '%' ); ?>
			<span class="analytify_bar_graph"><span style="width: <?php echo esc_html( round( $row['entranceRate'], 2 ) ); ?>%"></span></span>
			</div>
			<div class="analytify_enter_exit_bars">
			<?php echo esc_html( round( $row['exitRate'], 2 ) . '%' ); ?>
			<span class="analytify_bar_graph"><span style="width: <?php echo esc_html( round( $row['exitRate'], 2 ) ); ?>%"></span></span>
			</div>


			</td>
			</tr>
		<?php } ?>

		<?php } else { ?>
		<tr>
			<td class='analytify_td_error_msg' colspan="4" >
			<?php echo esc_html( $wp_analytify->no_records() ); ?>
			</td>
		</tr>
		<?php	} ?>

	</tbody>
	</table>

	<?php

	$body = ob_get_clean();

	$result = wp_json_encode(
		array(
			// translators: %1$s is the number of people, %2$s is the URL.
			'message' => sprintf( esc_html__( 'Did you know that %1$s people landed directly to your site at %2$s?', 'wp-analytify-pro' ), ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' ) ) ? WPANALYTIFY_Utils::pretty_numbers( $top_entrance ) : number_format( $top_entrance ), $url ),
			'body'    => $body,
		)
	);

	return $result ? $result : '';
}

