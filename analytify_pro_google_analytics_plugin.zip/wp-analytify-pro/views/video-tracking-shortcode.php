<?php
/**
 * Video tracking shortcode template.
 *
 * Lightweight table-based markup for front-end shortcode output.
 * Variables: $video_stats (array with 'stats' key), $args (title, show_footer, start_date, end_date, filter_post_id).
 *
 * @package WP_Analytify_Pro
 * @since 9.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$stats           = isset( $video_stats['stats'] ) && is_array( $video_stats['stats'] ) ? $video_stats['stats'] : array();
$shortcode_title = isset( $args['title'] ) ? $args['title'] : '';
$show_footer     = isset( $args['show_footer'] ) ? $args['show_footer'] : 'yes';
$start_date      = isset( $args['start_date'] ) ? $args['start_date'] : '';
$end_date        = isset( $args['end_date'] ) ? $args['end_date'] : '';
$filter_post_id  = isset( $args['filter_post_id'] ) ? (int) $args['filter_post_id'] : 0;
?>
<div class="analytify-video-tracking-shortcode">
	<?php if ( ! empty( $shortcode_title ) ) : ?>
		<h3 class="analytify-video-tracking-title"><?php echo esc_html( $shortcode_title ); ?></h3>
	<?php endif; ?>

	<?php if ( ! empty( $stats ) ) : ?>
		<div class="analytify-video-tracking-table">
			<table class="analytify_data_tables">
				<thead>
					<tr>
						<th class="analytify_txt_left"><?php esc_html_e( 'Title', 'wp-analytify-pro' ); ?></th>
						<th class="analytify_txt_left"><?php esc_html_e( 'Action', 'wp-analytify-pro' ); ?></th>
						<th class="analytify_txt_left"><?php esc_html_e( 'Provider', 'wp-analytify-pro' ); ?></th>
						<th class="analytify_txt_center"><?php esc_html_e( 'Duration (s)', 'wp-analytify-pro' ); ?></th>
						<th class="analytify_value_row analytify_txt_center"><?php esc_html_e( 'Event Count', 'wp-analytify-pro' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $stats as $stat ) : ?>
						<tr>
							<td><?php echo esc_html( $stat['event_label'] ?? '' ); ?></td>
							<td><?php echo esc_html( $stat['video_action'] ?? '' ); ?></td>
							<td><?php echo esc_html( $stat['video_provider'] ?? '' ); ?></td>
							<td class="analytify_txt_center"><?php echo esc_html( $stat['video_duration'] ?? 0 ); ?></td>
							<td class="analytify_txt_center analytify_value_row"><?php echo esc_html( $stat['event_count'] ?? 0 ); ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
	<?php else : ?>
		<div class="analytify-video-tracking-no-data">
			<p class="analytify-no-stats"><?php esc_html_e( 'No video tracking data available for the selected period.', 'wp-analytify-pro' ); ?></p>
			<?php if ( current_user_can( 'manage_options' ) ) : ?>
				<p class="analytify-debug-info" style="font-size: 12px; color: #666; margin-top: 10px;">
					<?php esc_html_e( 'Debug Info: ', 'wp-analytify-pro' ); ?>
					<?php esc_html_e( 'Date Range: ', 'wp-analytify-pro' ); ?><?php echo esc_html( $start_date ); ?> - <?php echo esc_html( $end_date ); ?>
					<?php if ( $filter_post_id > 0 ) : ?>
						| <?php esc_html_e( 'Post ID: ', 'wp-analytify-pro' ); ?><?php echo (int) $filter_post_id; ?>
					<?php endif; ?>
				</p>
			<?php endif; ?>
		</div>
	<?php endif; ?>

	<?php if ( 'yes' === $show_footer ) : ?>
		<div class="analytify-video-tracking-footer">
			<span class="analytify_info_stats">
				<?php esc_html_e( 'Video tracking statistics', 'wp-analytify-pro' ); ?>
				(<?php echo esc_html( wp_date( 'jS F, Y', strtotime( $start_date ) ) ); ?> - <?php echo esc_html( wp_date( 'jS F, Y', strtotime( $end_date ) ) ); ?>)
			</span>
		</div>
	<?php endif; ?>
</div>
