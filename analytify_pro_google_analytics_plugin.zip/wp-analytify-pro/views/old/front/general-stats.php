<?php
/**
 * View of General Statistics.
 *
 * @package WP_Analytify_Pro
 */

/**
 * Display general statistics on front-end.
 *
 * @param mixed $current Current data or context.
 * @param mixed $stats General statistics data.
 * @return void
 */
function pa_include_general( mixed $current, mixed $stats ) {
	?>
<div class="analytify_popup" id="general">
	<div class="analytify_popup_header">
	<h4><?php esc_html_e( 'General Statistics', 'wp-analytify-pro' ); ?></h4>
	<span class="analytify_popup_clsbtn">&times;</span>
	</div>
	<div class="analytify_popup_body">
	<div class="table-responsive">
		<table class="analytify_table analytify_table_hover">
		<tbody>
		<tr>
		<th><?php analytify_e( 'Sessions', 'wp-analytify-pro' ); ?></th>
		<td><?php echo esc_html( number_format( $stats->totalsForAllResults['ga:sessions'] ) ); // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase ?></td>
		</tr>
		<tr>
		<th><?php analytify_e( 'Users', 'wp-analytify-pro' ); ?></th>
		<td><?php echo esc_html( number_format( $stats->totalsForAllResults['ga:users'] ) ); // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase ?></td>
		</tr>
		<tr>
		<th style="min-width: 120px;"><?php analytify_e( 'Bounce rate', 'wp-analytify-pro' ); ?></th>
		<td>
			<?php
			if ( $stats->totalsForAllResults['ga:entrances'] <= 0 ) { // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
				?>
					0.00%
				<?php
			} else {
					echo esc_html( number_format( round( ( $stats->totalsForAllResults['ga:bounces'] / $stats->totalsForAllResults['ga:entrances'] ) * 100, 2 ), 2 ) ); // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
				?>
				%
			<?php } ?>
		</td>
		</tr>
		<tr>
		<th style="min-width: 145px );"><?php analytify_e( 'Avg. time on site', 'wp-analytify-pro' ); ?></th>
		<td>
			<?php
			if ( $stats->totalsForAllResults['ga:sessions'] <= 0 ) { // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
				?>
				00:00:00
				<?php
			} else {
				echo esc_html( $current->pa_pretty_time( $stats->totalsForAllResults['ga:avgTimeOnPage'] ) ); // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
				?>
			<?php } ?>
		</td>
		</tr>
		<tr>
		<th style="min-width: 130px );"><?php esc_html_e( 'AVERAGE PAGES', 'wp-analytify-pro' ); ?></th>
		<td>
			<?php
			if ( $stats->totalsForAllResults['ga:sessions'] <= 0 ) { // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
				?>
				0.00
				<?php
				// phpcs:ignore Squiz.PHP.CommentedOutCode.Found -- Condition check for sessions.
			} else {
				?>
				<?php
				echo esc_html( number_format( round( $stats->totalsForAllResults['ga:pageviews'] / $stats->totalsForAllResults['ga:sessions'], 2 ), 2 ) ); // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
				?>
				<?php } ?>
		</td>
		</tr>
		<tr>
			<th style="min-width: 120px );"><?php analytify_e( 'Page views', 'wp-analytify-pro' ); ?></th>
			<td>
			<?php
			if ( $stats->totalsForAllResults['ga:pageviews'] <= 0 ) { // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
				?>
			0
				<?php
				// phpcs:ignore Squiz.PHP.CommentedOutCode.Found -- Condition check for sessions.
			} else {
				?>
				<?php
				echo esc_html( $current->wpa_number_format( $stats->totalsForAllResults['ga:pageviews'] ) ); // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
				?>
			<?php } ?>
			</td>
		</tr>
		<tr>
		<th style="min-width: 145px );"><?php esc_html_e( 'USER TYPE', 'wp-analytify-pro' ); ?></th>
		<td>
			<?php
			if ( isset( $stats->totalsForAllResults ) ) { // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
				$returning = $stats->totalsForAllResults['ga:sessions'] - $stats->totalsForAllResults['ga:newUsers']; // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
				?>
			New  (<?php echo esc_html( $stats->totalsForAllResults['ga:newUsers'] ); // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase ?>)
			Returning (<?php echo esc_html( $returning ); ?>)
				<?php
			}
			?>
		</td>
	</tr>
		</tbody>
		</table>
	</div>
	</div>
	<div class="analytify_popup_footer">
	<span class="analytify_popup_info"></span> <?php esc_html_e( 'These are the general statistics of this page.', 'wp-analytify-pro' ); ?>
	</div>
</div>
	<?php
}

