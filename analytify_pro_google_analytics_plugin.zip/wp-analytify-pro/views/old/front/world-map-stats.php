<?php
/**
 * Display world map statistics on the front-end.
 *
 * @package WP_Analytify_Pro
 *
 * @since 7.0.0
 * @version 9.1.0
 * 
 * @param mixed                $current        Current data or context.
 * @param array<string, mixed> $worldmap_stats World map statistics data.
 * @return void
 */
function pa_include_worldmap( $current, $worldmap_stats ) {
	$colors = apply_filters( 'analytify_world_map_shortcode_colors', false );

	?>
	<div class="data_boxes">
		<div class="data_boxes_title">
			<?php esc_html_e( 'Top Countries', 'wp-analytify-pro' ); ?>
			<div class="arrow_btn"></div>
		</div>
		<div class="data_container">
			<?php
			if ( ! empty( $worldmap_stats['rows'] ) ) {
				wp_enqueue_script(
					'google-charts-loader',
					'https://www.gstatic.com/charts/loader.js',
					array(),
					null,
					true
				);

				$chart_rows = array();
				foreach ( $worldmap_stats['rows'] as $c_stats ) {
					$country  = isset( $c_stats['country'] ) ? $c_stats['country'] : '';
					$sessions = isset( $c_stats['sessions'] ) ? (float) $c_stats['sessions'] : 0;

					if ( '' === $country || '(not set)' === $country ) {
						continue;
					}

					$chart_rows[] = array( $country, $sessions );
				}

				if ( ! empty( $chart_rows ) ) {
					$chart_id = 'wm_chart_div_' . wp_unique_id();
					?>
					<div id="<?php echo esc_attr( $chart_id ); ?>" class="analytify-worldmap-chart" style="width: 600px; margin:0 auto; aspect-ratio: 4/3; max-width: 100%;"></div>

					<script>
					(function() {
						var chartRows = <?php echo wp_json_encode( $chart_rows ); ?>;
						var chartColors = <?php echo wp_json_encode( $colors ? $colors : false ); ?>;
						var chartId = <?php echo wp_json_encode( $chart_id ); ?>;

						function drawRegionsMap() {
							if ( typeof google === 'undefined' || ! google.visualization ) {
								return;
							}

							var data = new google.visualization.DataTable();
							data.addColumn('string', 'Country');
							data.addColumn('number', 'Visitors');
							data.addRows(chartRows);

							var options = {
								displayMode: 'regions',
								responsive: true
							};

							if ( chartColors && chartColors.length ) {
								options.colorAxis = { colors: chartColors };
							}

							var formatter = new google.visualization.NumberFormat({ fractionDigits: 0 });
							formatter.format(data, 1);

							var chart = new google.visualization.GeoChart(document.getElementById(chartId));
							chart.draw(data, options);
						}

						function initWorldMapChart() {
							google.charts.load('current', {
								packages: ['geochart'],
								callback: drawRegionsMap
							});
						}

						if ( document.readyState === 'loading' ) {
							document.addEventListener('DOMContentLoaded', initWorldMapChart);
						} else {
							initWorldMapChart();
						}
					})();
					</script>
					<?php
				}
			}
			?>
		</div>
	</div>
	<?php
}
