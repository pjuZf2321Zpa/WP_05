<?php
/**
 * Display referrers statistics on front-end.
 *
 * @package WP_Analytify_Pro
 */

/**
 * Display referrers statistics on front-end.
 *
 * @param mixed                $current Current data or context.
 * @param array<string, mixed> $referr_stats Referrers statistics data.
 * @return void
 */
function pa_include_referrers( $current, $referr_stats ) {
	?>
<div class="analytify_popup" id="referrer">
	<div class="analytify_popup_header">
	<h4><?php analytify_e( 'Top Referrers', 'wp-analytify-pro' ); ?></h4>
	<span class="analytify_popup_clsbtn">&times;</span>
	</div>
	<div class="analytify_popup_body">
		<div class="table-responsive">
		<table class="analytify_table analytify_table_hover">
		<thead>
			<tr>
			<th class="num" width="20"><?php esc_html_e( '#', 'wp-analytify-pro' ); ?></th>
			<th><?php esc_html_e( 'Social referrer', 'wp-analytify-pro' ); ?></th>
			<th><?php analytify_e( 'Visits', 'wp-analytify-pro' ); ?></th>
			</tr>
		</thead>
		<tbody>
		<?php
		if ( ! empty( $referr_stats['rows'] ) ) {
			$i = 1;
			?>
			<?php foreach ( $referr_stats['rows'] as $r_stats ) { ?>
			<tr>
			<td class="num"><?php echo esc_html( $i ); ?></td>

		<td>
			<i>
				<?php echo esc_html( $r_stats[0] ); ?> / <?php echo esc_html( $r_stats[1] ); ?>
			</i>
		</td>
		<td><?php echo esc_html( $current->wpa_number_format( $r_stats[2] ) ); ?></td>
			</tr>
				<?php
				++$i;
			}
		}
		?>
		</tbody>
		</table>
		</div>
	</div>
	<div class="analytify_popup_footer">
	<span class="analytify_popup_info"></span><?php esc_html_e( 'These are the top referrers of this page.', 'wp-analytify-pro' ); ?>
	</div>
</div>
	<?php
}

