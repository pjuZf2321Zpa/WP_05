<?php
/**
 * MashAllah!
 */
