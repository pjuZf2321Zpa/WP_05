/*
 * Tinymce plugin for Analytify
 */

/* global analytifyShortcodeI18n */

(function() {
   tinymce.create('tinymce.plugins.analytify', {

      init(editor) {

            editor.addButton( 'analytifystats', {
                  title: 'Analytify Shortcodes',
                  type: 'menubutton',
                  icon: 'icon analytify-shortcodes-icon',
                  menu: [

                         /** Analytify Simple Shortcodes **/
                           {
                              text: 'Simple',
                              onclick() {

                                    editor.windowManager.open( {

                                    title: ('undefined' !== typeof analytifyShortcodeI18n && analytifyShortcodeI18n.simpleShortcodesTitle) ? analytifyShortcodeI18n.simpleShortcodesTitle : 'Analytify Simple Shortcodes: Returns selected data',
                                    body: [
                                       {
                                          type: 'listbox',
                                          name: 'metrics',
                                          label: 'Metrics :',
                                          'values': [
                                             {text: 'Users', value: 'ga:users'},
                                             {text: 'New Users', value: 'ga:newUsers'},
                                             {text: 'Percent New Sessions', value: 'ga:percentNewSessions'},
                                             {text: '----- Session Management -----', value: ''},
                                             {text: 'Sessions', value: 'ga:sessions'},
                                             {text: 'Bounces', value: 'ga:bounces'},
                                             {text: 'BounceRate', value: 'ga:bounceRate'},
                                             {text: 'Session Duration', value: 'ga:sessionDuration'},
                                             {text: 'Avg Session Duration', value: 'ga:avgSessionDuration'},
                                             {text: 'Percent New Sessions', value: 'ga:percentNewSessions'},
                                             {text: '----- Page Tracking -----', value: ''},
                                             {text: 'Page Value', value: 'ga:pageValue'},
                                             {text: 'Entrances', value: 'ga:entrances'},
                                             {text: 'Page views', value: 'ga:pageviews'},
                                             {text: 'Unique Pageviews', value: 'ga:uniquePageviews'},
                                             {text: 'Exits', value: 'ga:exits'},
                                             {text: 'Exit Rate', value: 'ga:exitRate'},
                                             {text: 'Time On Page', value: 'ga:timeOnPage'},
                                             {text: 'Avg Time On Page', value: 'ga:avgTimeOnPage'}
                                          ]
                                       },
                                       {
                                          type: 'listbox',
                                          name: 'permission_view',
                                          label: 'Visible to :',
                                          'values': [
                                             {text: 'Everyone', value: ""},
                                             {text: 'Administrator', value: 'administrator'},
                                             {text: 'Editor', value: 'editor'},
                                             {text: 'Author', value: 'author'},
                                             {text: 'Contributor', value: 'contributor'}
                                          ]
                                       }
                                    ],
                                    onsubmit( e ) {
                                       editor.insertContent( `[analytify-stats metrics="${  e.data.metrics  }" permission_view="${  e.data.permission_view  }"]`);
                                    }
                                 });
                              }
                           },

                           /** Advanced **/
                           {
                              text: ('undefined' !== typeof analytifyShortcodeI18n && analytifyShortcodeI18n.advancedText) ? analytifyShortcodeI18n.advancedText : 'Advanced',
                              onclick() {
                                 tb_show(('undefined' !== typeof analytifyShortcodeI18n && analytifyShortcodeI18n.advancedShortcodesMessage) ? analytifyShortcodeI18n.advancedShortcodesMessage : "Analytify Advanced Shortcodes: Use it according to your needs.", "admin-ajax.php?action=analytify_advanced_shortcode");
                                 tinymce.DOM.setStyle(["TB_overlay", "TB_window", "TB_load"], "z-index", "999999");                              
                                 const thickboxWindow = jQuery("#TB_window");
                              if (thickboxWindow)
                                 {
                                    const thickboxContent = thickboxWindow.find('#TB_ajaxContent');
                                    thickboxContent.css({ width : 'auto', height : 'auto', background : '#efefef' });
                           
                                 }
                              }
                           }
                     ]
            });
      },
      createControl() {
         return null;
      },
      getInfo() {
         return {
            longname : "Analytify Shortcodes - Show selected analytics",
            author : 'Adnan',
            authorurl : 'http://analytify.io/',
            infourl : 'http://analytify.io/',
            version : ('undefined' !== typeof analytifyShortcodeI18n && analytifyShortcodeI18n.version) ? analytifyShortcodeI18n.version : '1.0.0'
         };
      }
   });

   tinymce.PluginManager.add('analytifystats', tinymce.plugins.analytify);
}());
