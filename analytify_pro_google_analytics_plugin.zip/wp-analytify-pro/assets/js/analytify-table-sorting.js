/**
 * Enable table sorting for Analytify tables.
 * Note: Sorting is handled via event delegation, so this function is a no-op.
 * It exists for backward compatibility with code that calls it.
 *
 * @global
 */
// eslint-disable-next-line no-unused-vars
function enableAnalytifyTableSorting() {

	// Sorting is already handled via event delegation below.
	// This function exists to prevent "undefined function" errors.
}

/**
 * Parse display values from Analytify pretty_numbers (e.g. "21.2k", "1,234").
 * Stripping the "k" alone breaks sort order (21.2k → 21.2 vs real 21200).
 *
 * @param {string} text Cell text.
 * @returns {number} Numeric value, or NaN if not parseable.
 */
function parseAnalytifySortableNumber(text) {
	const cleaned = String(text).trim().replace(/,/g, '');
	if ('' === cleaned) {
		return NaN;
	}

	const match = cleaned.match(/^(-?\d*\.?\d+)\s*([kKmMbB%])?$/);
	if (match) {
		let value = parseFloat(match[1]);
		if (isNaN(value) || !isFinite(value)) {
			return NaN;
		}
		const suffix = (match[2] || '').toLowerCase();
		if ('k' === suffix) {
			value *= 1000;
		} else if ('m' === suffix) {
			value *= 1000000;
		} else if ('b' === suffix) {
			value *= 1000000000;
		}
		return value;
	}

	const fallback = parseFloat(cleaned.replace(/[^\d.-]/g, ''));
	return (isNaN(fallback) || !isFinite(fallback)) ? NaN : fallback;
}

// Table sorting via event delegation (works for dynamically added tables)
jQuery(document).on('click', '.analytify_data_tables thead th, .wp_analytify_campaign_paginated thead th', function () {
    const $header = jQuery(this);
    const $table = $header.closest('table');
    const $tbody = $table.find('tbody'); 
    const $rows = $tbody.find('tr');
    const columnIndex = $header.index(); 

    // Skip sorting for the first column if it is labeled '#'
    if (0 === columnIndex && '#' === $table.find('thead th').eq(0).text().trim()) {
        return;
    }

    // Do not sort if the table is empty or has only one row
    if (1 >= $rows.length) {
        return;
    }

    // Determine the sort direction: ascending if not already sorted-asc
    const isCurrentlyAsc = $header.hasClass('sorted-asc');
    const ascending = !isCurrentlyAsc;
    
    // Remove sort classes from all headers and set current header
    $table.find('th').removeClass('sorted-asc sorted-desc');
    $header.addClass(ascending ? 'sorted-asc' : 'sorted-desc');

    // Convert jQuery object to array for sorting
    const rowsArray = $rows.toArray();

    // Perform the actual sorting
    rowsArray.sort((rowA, rowB) => {

        // Get the text content from the clicked column in each row
        const cellA = jQuery(rowA).find('td').eq(columnIndex).text().trim();
        const cellB = jQuery(rowB).find('td').eq(columnIndex).text().trim();

        // Parse pretty numbers (k/m/b) so "21.2k" sorts as 21200, not 21.2
        const numberA = parseAnalytifySortableNumber(cellA);
        const numberB = parseAnalytifySortableNumber(cellB);

        // Check if both values are valid numbers
        const isNumberA = !isNaN(numberA) && isFinite(numberA);
        const isNumberB = !isNaN(numberB) && isFinite(numberB);

        if (isNumberA && isNumberB) {

            // If both cells contain numbers, sort numerically
            return ascending ? numberA - numberB : numberB - numberA;
        } else if (isNumberA !== isNumberB) {

            // If one is number and one is string, numbers come first
            return ascending ? 
                (isNumberA ? -1 : 1) : 
                (isNumberA ? 1 : -1);
        } else {

            // Otherwise, sort as strings (case-insensitive)
            return ascending ?
                cellA.localeCompare(cellB, undefined, { sensitivity: 'base' }) :
                cellB.localeCompare(cellA, undefined, { sensitivity: 'base' });
        }
    });

    // Detach tbody for better performance during DOM manipulation
    const $detachedTbody = $tbody.detach();
    
    // Append sorted rows back into the tbody
    $detachedTbody.append(rowsArray);
    
    // Reattach tbody to table
    $table.append($detachedTbody);

    // If the first column is a row number column (labeled '#'), re-index it
    if ('#' === $table.find('thead th').eq(0).text().trim()) {
        $table.find('tbody tr').each(function (index) {
            jQuery(this).find('td').eq(0).text(index + 1);
        });
    }
});
