/**
 * All JS management for Pro version.
 */
(function ($) {


    let doing_license_registration_ajax = false;
    let checked_license = false;
    let license_information = {};
    const fade_duration = 400;
    const admin_url = ajaxurl.replace('/admin-ajax.php', '');
    let spinner_url = `${admin_url}/images/spinner`;

    if (2 < window.devicePixelRatio) {
        spinner_url += '-2x';
    }
    spinner_url += '.gif';

    $(document).ready(() => {

        if ('undefined' != typeof (localStorage)) {

            activetab = localStorage.getItem("activetab");

            if ('#wp-analytify-license' == activetab) {
                set_license_info();
            }


            if ('#wp-analytify-help' == activetab) {

                if (false === checked_license && '1' === wpanalytify_data.has_license && 'analytify_page_analytify-settings' === pagenow) {
                    check_license();
                }
            }

            $('.nav-tab-wrapper a').click(function () {
                if ('wp-analytify-help-tab' == $(this).attr('id')) {
                    if (false === checked_license && '1' === wpanalytify_data.has_license) {
                        check_license();
                    }
                }

                if ('wp-analytify-license-tab' == $(this).attr('id')) {
                    set_license_info();
                }
            });
        }

        async function set_license_info() {
            if (!$('#pro-license-status').length) { return; }

            const license_info = await check_license_info();
            if (license_info && true === license_info.success) {

                // Normalize payload: server may return { success: true, data: { ... } }
                const payload = license_info.data ? license_info.data : license_info;
                const expires_on = ("lifetime" === payload.expires) ? (payload.expires.charAt(0).toUpperCase() + payload.expires.slice(1)) : (new Date(payload.expires).toLocaleDateString("en-US"));
                const license_status = payload.license ? (payload.license.charAt(0).toUpperCase() + payload.license.slice(1)) : payload.license;
                const licenseStatusLabel = ('undefined' !== typeof Analytify && Analytify.licenseStatus) ? Analytify.licenseStatus : 'License Status:';
                const activationsLeftLabel = ('undefined' !== typeof Analytify && Analytify.activationsLeft) ? Analytify.activationsLeft : 'Activations Left:';
                const licenseLimitLabel = ('undefined' !== typeof Analytify && Analytify.licenseLimit) ? Analytify.licenseLimit : 'License limit:';
                const expirationDateLabel = ('undefined' !== typeof Analytify && Analytify.expirationDate) ? Analytify.expirationDate : 'Expiration Date:';
                const license_info_string =
                    `<b>${licenseStatusLabel}</b> ${license_status}
                 <b>${activationsLeftLabel}</b> ${payload['activations_left']}
                 <b>${licenseLimitLabel}</b> ${payload['license_limit']}
                 <b>${expirationDateLabel}</b> ${expires_on}`;


                $('#pro-license-status').addClass('notification-message success-notice');
                $('#pro-license-status').html(license_info_string).fadeIn(4000);
            } else if (license_info && license_info.error) {
                $('#pro-license-status').removeClass('success-notice').addClass('error-notice');

                // If server says no license key found, prompt instead of a generic error.
                const msg = /No license key found/i.test(license_info.error) ?
                    wpanalytify_strings.enter_license_key :
                    license_info.error;
                $('#pro-license-status').html(msg);
            } else {
                $('#pro-license-status').removeClass('success-notice').addClass('error-notice');
                $('#pro-license-status').html('<span>Problem Encountered</span>');
            }
        }


        async function check_license_info() {

            if (0 !== Object.keys(license_information).length) {
                return license_information;
            }

            $('#pro-license-status').addClass('notification-message success-notice');
            $('#pro-license-status').text('Loading license details...');

            const url = `${ajaxurl}?action=wpanalytifypro_check_license`;

            const formData = new FormData();
            formData.append('context', 'all');
            formData.append('nonce', wpanalytify_data.nonces.check_license);

            try {
                const response = await fetch(url, {
                    method: 'POST',
                    body: formData,
                });

                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }

                license_information = await response.json();

                // Keep stored license_information normalized to the payload object
                license_information = license_information.data ? license_information.data : license_information;

                return license_information;
            } catch (error) {

                // Silent fail - error handling done in UI
            }
        }



        function check_license(license) {

            checked_license = true;

            $('.support-content.full').hide();
            const loaderHtml = '<p>Fetching license details, please wait...</p>' +
                '<div style="text-align: center; margin-top: 20px;">' +
                '<div class="stats_loading"></div></div>';
            $('.support-content.check').show().html(loaderHtml);

            $.ajax({
                url: ajaxurl,
                type: 'POST',
                dataType: 'json',
                cache: false,
                data: {
                    action: 'wpanalytifypro_check_license',
                    license,
                    context: 'all',
                    nonce: wpanalytify_data.nonces.check_license
                },
                error() {

                    alert(wpanalytify_strings.license_check_problem);
                },
                success(data) {

                    const $support_content = $('.support-content.full');
                    const $license_content = $('.support-content.check');
                    let support_msg;

                    // Normalize payload coming from server
                    const payload = data && data.data ? data.data : data;

                    if ('undefined' !== typeof payload.error) {

                        let msg = '';
                        for (const key in data.error) {
                            msg += data.error[key];
                        }
                        support_msg = msg;


                        $license_content.stop().fadeOut(fade_duration, function () {
                            $(this)
                                .empty()
                                .html(support_msg)
                                .stop()
                                .fadeIn(fade_duration);
                        });

                    } else {
                        if ('undefined' !== typeof license) { $('.support-content.full form').attr('action', `https://analytify.io/plugin-support-form/?action=priority-support&product=analytifypro&key=${license}`); }

                        // Add all customer emails to dropdown if available
                        if (payload.customer_emails && Array.isArray(payload.customer_emails)) {
                            payload.customer_emails.forEach((email) => {
                                if (email && '' !== email) {
                                    $('.support-content.full #analytify-support-email').append($('<option></option>').val(email).html(email));
                                }
                            });
                        } else if (payload.customer_email && '' !== payload.customer_email) {

                            // fallback for single email
                            $('.support-content.full #analytify-support-email').append($('<option></option>').val(payload.customer_email).html(payload.customer_email));
                        }
                        $('.support-content.check').stop().fadeOut();
                        $support_content.stop().fadeOut(fade_duration, function () {
                            $(this)
                                .stop()
                                .fadeIn(fade_duration);
                        });

                    }

                }
            });
        }

        function enable_pro_license(data, license_key) {

            // Normalize payload in case server wrapped response in success envelope.
            const payload = data && data.data ? data.data : data;
            license_information = payload;

            $('.analytify-pro-license-actions').remove();
            $('.pro-license-row').prepend(payload.masked_license);
            $('.support-content.check').empty().html(`<p>${wpanalytify_strings.fetching_license}<img src="${spinner_url}" alt="" class="ajax-spinner general-spinner" /></p>`);
            $('.support-content.check').delay(5000).fadeOut(1000).remove();
            $('.support-content.full').show();

            check_license(license_key);

            setTimeout(() => { set_license_info(); }, 3000);

        }

        $(document).on('click', "#analytify_license_activate", (e) => {

            e.preventDefault();

            if (doing_license_registration_ajax) {
                return;
            }

            $('.pro-license-row').append('<div id="pro-license-status"></div>');

            $('#pro-license-status').removeClass('notification-message error-notice');

            const license_key = $.trim($("#analytify_license_key").val());

            if ('' === license_key) {
                $('#pro-license-status').addClass('notification-message error-notice');
                $('#pro-license-status').html(wpanalytify_strings.enter_license_key);
                return;
            }

            $('#pro-license-status').empty().removeClass('success-notice');
            doing_license_registration_ajax = true;
            $('#analytify_license_activate').after(`<img src="${spinner_url}" alt="" class="register-license-ajax-spinner general-spinner" />`);

            $.ajax({
                url: ajaxurl,
                type: 'POST',
                dataType: 'JSON',
                cache: false,
                data: {
                    action: 'wpanalytifypro_activate_license',
                    license_key,
                    nonce: wpanalytify_data.nonces.activate_license,
                    context: 'license'
                },
                error() {
                    doing_license_registration_ajax = false;
                    $('.register-license-ajax-spinner').remove();
                    $('#pro-license-status').html(wpanalytify_strings.register_license_problem);
                },
                success(data) {
                    doing_license_registration_ajax = false;
                    $('.register-license-ajax-spinner').remove();

                    // Normalize payload in case server wrapped response in success envelope.
                    const payload = data && data.data ? data.data : data;

                    if (payload && 'undefined' !== typeof payload.error) {

                        $('#pro-license-status')
                            .removeClass('success-notice')
                            .addClass('notification-message error-notice');

                        let rawMsg = '';

                        if ('object' === typeof payload.error) {
                            rawMsg = (payload.error.message || Object.values(payload.error).join(' ')).trim();
                        } else {
                            rawMsg = String(payload.error).trim();
                        }

                        // EDD uses "missing" when the key is not in the store — not when the field is empty.
                        if ('missing' === rawMsg.toLowerCase()) {
                            rawMsg = 'Invalid license key. Please check your key and try again.';
                        }

                        const finalMsg = 10 > rawMsg.length ?
                            `Error: ${rawMsg}. Please check your license key and try again.` :
                            rawMsg;

                        $('#pro-license-status').html(finalMsg);

                    } else {

                        $('#pro-license-status')
                            .removeClass('error-notice')
                            .addClass('notification-message success-notice')
                            .html(wpanalytify_strings.license_registered);

                        enable_pro_license(data, license_key);
                    }
                }
            });
        });

        $(document).on('click', "#analytify_woo_license_activate", (e) => {

            e.preventDefault();

            if (doing_license_registration_ajax) {
                return;
            }

            $('#woo-license-status').removeClass('notification-message error-notice');

            const license_key = $.trim($("#analytify_woo_license_key").val());

            if ('' === license_key) {
                $('#woo-license-status').addClass('notification-message error-notice');
                $('#woo-license-status').html(wpanalytify_strings.enter_license_key);
                return;
            }

            $('#woo-license-status').empty().removeClass('success-notice');
            doing_license_registration_ajax = true;
            $('#analytify_woo_license_activate').after(`<img src="${spinner_url}" alt="" class="register-license-ajax-spinner general-spinner" />`);

            $.ajax({
                url: ajaxurl,
                type: 'POST',
                dataType: 'JSON',
                cache: false,
                data: {
                    action: 'wpanalytifywoo_activate_license',
                    woo_license_key: license_key,
                    nonce: wpanalytify_data.nonces.activate_license,
                    context: 'license'
                },
                error() {
                    doing_license_registration_ajax = false;
                    $('.register-license-ajax-spinner').remove();
                    $('#woo-license-status').html(wpanalytify_strings.register_license_problem);
                },
                success(data) {
                    doing_license_registration_ajax = false;
                    $('.register-license-ajax-spinner').remove();


                    if ('undefined' !== typeof data.error) {

                        $('#woo-license-status').addClass('notification-message error-notice');
                        $('#woo-license-status').html(data.error);

                    } else if ('0' == data) {

                        $('#woo-license-status').addClass('notification-message error-notice');
                        $('#woo-license-status').html(wpanalytify_strings.register_license_problem);
                    } else {
                        $('#woo-license-status').html(wpanalytify_strings.license_registered).delay(5000).fadeOut(1000);
                        $('#woo-license-status').addClass('notification-message success-notice');
                        $('#analytify_woo_license_key, #analytify_woo_license_activate').remove();
                        $('.woo-license-row').prepend(data.masked_license);

                    }
                }
            });
        });

        /**
         * [Ajax processing on license management]
         */
        $(document).on('click', "#analytify_license_deactivate", (event) => {
            event.preventDefault();

            $.ajax({
                url: Analytify.ajaxurl,
                type: 'POST',
                data: {
                    action: 'analytify_license_deactivate',
                }
            })
                .done(() => {

                    $("#return-message").html(' <span style="color:green;">Deactive</span>');
                    $("#analytify_license_deactivate").attr('id', 'analytify_license_activate').val('Activate License');

                });
        });

    });

    $(document).on('click', '.analytify-export-data', function (e) {
        e.preventDefault();
        const _this = $(this);
        let start_date = $("#analytify_start").val();
        start_date = moment(start_date, 'MMM DD, YYYY').format("YYYY-MM-DD");

        let end_date = $("#analytify_end").val();
        end_date = moment(end_date, 'MMM DD, YYYY').format("YYYY-MM-DD");

        let stats_type = _this.data('stats-type');
        const form_args = _this.data('args');

        // Map form args to their corresponding stats types
        const formTypeMap = {
            'analytify_form_hubspot': 'forms-hubspot',
            'analytify_form_jotform': 'forms-jotform',
            'analytify_form_wpforms': 'forms-wpform',
            'analytify_form_gf': 'forms-gravity',
            'analytify_form_wpcf7': 'forms-cf7',
            'analytify_form_ninja_forms': 'forms-ninja',
            'analytify_form_elementor': 'forms-elementor',
            'analytify_form_formidable': 'forms-formidable',
            'analytify_form_fluentforms': 'forms-fluentforms',
            'analytify_form_custom': 'forms-custom',
            'analytify_form_mailpoet': 'forms-mailpoet'
        };

        if (formTypeMap[form_args]) {
            stats_type = formTypeMap[form_args];
        }

        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'analytify_export_csv',
                stats_type,
                start_date,
                end_date,
                args: form_args,
                security: Analytify.export_nonce
            },
            beforeSend() {
                _this.siblings('.analytify-export-loader').show();
            }
        })
            .done(() => {
                _this.siblings('.analytify-export-loader').hide();
                window.location.href = `${Analytify.exportUrl}&export_type=csv&report_type=${stats_type}&security=${Analytify.export_nonce}&start_date=${start_date}&end_date=${end_date}`;
            });

    });

}(jQuery));
