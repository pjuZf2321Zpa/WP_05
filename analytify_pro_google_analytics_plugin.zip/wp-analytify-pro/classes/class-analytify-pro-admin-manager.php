<?php
// phpcs:ignoreFile WordPress.Files.FileName.InvalidClassFileName
/**
 * WP Analytify Pro Admin Manager Class
 *
 * Provides admin UI, license activation/deactivation, plugin updates, and diagnostics
 * for WP Analytify Pro. License transport/JSON/HTTP issues use
 * {@see wp_analytify_pro_log_edd_license_request_issue()}; unexpected license state uses
 * {@see wp_analytify_pro_log_edd_license_state_validation_failure()} (masked keys).
 *
 * @package WP_Analytify_Pro
 * @since 8.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_Analytify_Pro_Admin_Manager' ) ) {
	/**
	 * WP Analytify Pro Admin Manager Class
	 *
	 * Handles admin-related functionality for WP Analytify Pro including license
	 * management, admin notices, plugin updater, and debug/diagnostic output.
	 * License AJAX handlers log via {@see wp_analytify_pro_log_edd_license_request_issue()} or
	 * {@see wp_analytify_pro_log_edd_license_state_validation_failure()}.
	 *
	 * @since 1.0.0
	 */
	class WP_Analytify_Pro_Admin_Manager {
		/**
		 * Parent class reference.
		 *
		 * @var mixed
		 */
		private $parent;

		/**
		 * Post data.
		 *
		 * @var array<string, mixed>
		 */
		private $post_data = array();

		/**
		 * Constructor
		 *
		 * @since 1.0.0
		 * @version 7.0.5
		 * @param mixed $parent Parent class reference.
		 */
		public function __construct( $parent ) { // phpcs:ignore Universal.NamingConventions.NoReservedKeywordParameterNames.parentFound
			$this->parent = $parent;

			// Hook into core diagnostic output.
			add_action( 'analytify_settings_logs', array( $this, 'add_pro_diagnostic_info' ) );
			add_action( 'analytify_settings_logs', array( $this, 'add_pro_addon_settings_diagnostic' ), 99 );
		}

		/**
		 * Whether the main Pro instance is attached (required for settings/state on parent).
		 *
		 * @since 9.0.0
		 * @return bool
		 */
		private function has_parent_pro(): bool {
			return isset( $this->parent ) && is_object( $this->parent );
		}

		/**
		 * Output admin notices for license, core version, and updates.
		 *
		 * Runs only on Analytify dashboard pages. Shows license activation/expired/invalid
		 * notices, core upgrade notice when core is below 6.1.0, and update available notice.
		 *
		 * @since 1.0.0
		 * @version 7.0.5
		 * @return void
		 */
		public function _admin_notices() { // phpcs:ignore PSR2.Methods.MethodDeclaration.Underscore
			// Return if current page is not analytify page.
			$screen = get_current_screen();
			if ( ! $screen || 'analytify-dashboard' !== $screen->parent_base ) {
				return;
			}

			if ( ! $this->has_parent_pro() ) {
				return;
			}

			$profile_id  = get_option( 'pt_webprofile' );
			$acces_token = get_option( 'post_analytics_token' );

			// Add notices script.
			add_action( 'admin_enqueue_scripts', 'pa_notices_scripts' );

			$license_status = $this->get_license_status();

			if ( ! $this->get_license_key() && '' === $license_status ) {
				// translators: %1$s is bold opening tag, %2$s is bold closing tag, %3$s is link opening tag, %4$s is link closing tag.
				$message = sprintf( esc_html__( '%1$s Activate Your License %2$s &mdash; Please %3$senter your license key%4$s to enable support and plugin updates.', 'wp-analytify-pro' ), '<b>', '</b>', '<a style="text-decoration:none" class="wp-analytify-license-notice" href="' . esc_url( menu_page_url( 'analytify-settings', false ) ) . '#wp-analytify-license">', '</a>' );

				wp_analytify_pro_notice( $message, 'wp-analytify-danger' );
			} elseif ( '' === $license_status ) {
				// translators: %1$s is bold opening tag, %2$s is bold closing tag, %3$s is link opening tag, %4$s is link closing tag.
				$message = sprintf( esc_html__( '%1$s Activate Your License %2$s &mdash; Please click on %3$s Activate License button key%4$s to validate your license.', 'wp-analytify-pro' ), '<b>', '</b>', '<a style="text-decoration:none" class="wp-analytify-license-notice" href="' . esc_url( menu_page_url( 'analytify-settings', false ) ) . '#wp-analytify-license">', '</a>' );

				wp_analytify_pro_notice( $message, 'wp-analytify-danger' );
			} elseif ( $this->is_license_expired() ) {
				// translators: %1$s is bold opening tag, %2$s is bold closing tag, %3$s is link opening tag, %4$s is link closing tag.
				$message = sprintf( esc_html__( '%1$s License Expired %2$s &mdash; Upgrade your license to enable support and plugin updates. Would you please checkout %3$s what we have improved %4$s so far ?', 'wp-analytify-pro' ), '<b>', '</b>', '<a style="text-decoration:none" target="_blank" href="https://analytify.io/changelog/?utm_campaign=WPAnalytifyPro+licensing&utm_medium=link&utm_source=WPAnalytifyPro+LicenseExpired&utm_content=activate-license-notice">', '</a>' );

				wp_analytify_pro_notice( $message, 'wp-analytify-danger' );
			} elseif ( 'invalid' === $license_status ) {
				// translators: %1$s is bold opening tag, %2$s is bold closing tag, %3$s is link opening tag, %4$s is link closing tag.
				$message = sprintf( esc_html__( '%1$s Invalid License %2$s &mdash; Please %3$senter a valid license key%4$s to enable support and plugin updates.', 'wp-analytify-pro' ), '<b>', '</b>', '<a style="text-decoration:none" class="wp-analytify-license-notice" href="' . esc_url( menu_page_url( 'analytify-settings', false ) ) . '#wp-analytify-license">', '</a>' );

				wp_analytify_pro_notice( $message, 'wp-analytify-danger' );
			}

			if ( defined( 'ANALYTIFY_VERSION' ) && version_compare( ANALYTIFY_VERSION, '6.1.0', '<' ) ) {
				$action = 'upgrade-plugin';
				$slug   = 'wp-analytify';
				$link   = wp_nonce_url(
					add_query_arg(
						array(
							'action' => $action,
							'plugin' => $slug,
						),
						admin_url( 'update.php' )
					),
					$action . '_' . $slug
				);

				$message = sprintf( '%1$s <a href="%2$s">%3$s</a>', esc_html__( 'Please update Analytify Core to latest Free version to enable PRO features. &mdash; ', 'wp-analytify-pro' ), $link, esc_html__( 'Update now', 'wp-analytify-pro' ) );

				wp_analytify_pro_notice( $message, 'wp-analytify-danger' );
			}

			if ( 'valid' !== $license_status ) {
				$this->is_update_available();
			}
		}
		/**
		 * AJAX handler for activating a license.
		 *
		 * Verifies nonce, posts to the EDD license endpoint, then either sends JSON
		 * (success or invalid license payload) and exits, or returns false only when
		 * the HTTP transport fails before a response body is available.
		 * Rejects `json_decode()` `null` or non-object responses before using license fields.
		 *
		 * @since 9.0.0
		 * @version 7.0.5
		 * @return false|void False when wp_remote_get returns WP_Error; otherwise terminates via wp_send_json_* / end_ajax.
		 */
		public function ajax_activate_license() {

			if ( ! $this->has_parent_pro() ) {
				wp_send_json_error( array( 'message' => __( 'Unable to process request.', 'wp-analytify-pro' ) ) );
			}

			// Accept either the legacy nonce action or the localized Pro nonce.
			if ( isset( $_POST['nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'wpanalytifypro_activate_license' ) ) {
				// Modern Pro nonce passed.
			} else {
				// Fallback to legacy check which will wp_die() on failure.
				$this->check_ajax_referer( 'activate-license' );
			}

			$key_rules = array(
				'action'      => 'key',
				'license_key' => 'string',
				'context'     => 'key',
				'nonce'       => 'key',
			);
			$this->set_post_data( $key_rules );

			if ( empty( $this->post_data['license_key'] ) ) {
				wp_send_json_error( array( 'message' => __( 'No license key provided.', 'wp-analytify-pro' ) ) );
			}

			$api_params = array(
				'edd_action' 	=> 'activate_license',
				'license'   	=> $this->post_data['license_key'],
				'item_id' 		=> ANALYTIFY_PRO_ID,
				'url'       	=> home_url(),
			);

			$response = wp_remote_get( esc_url_raw( add_query_arg( $api_params, ANALYTIFY_STORE_URL ) ), array( 'timeout' => 15, 'sslverify' => false ) );

			if ( is_wp_error( $response ) ) {
				wp_analytify_pro_log_edd_license_request_issue(
					'License activation request failed (transport error).',
					'WP_Analytify_Pro_Admin_Manager::ajax_activate_license',
					$api_params,
					$response
				);
				return false;
			}

			$license_response = json_decode( wp_remote_retrieve_body( $response ) );

			if ( null === $license_response || ! is_object( $license_response ) || ! isset( $license_response->license ) ) {
				wp_analytify_pro_log_edd_license_request_issue(
					'License activation returned unexpected or invalid JSON.',
					'WP_Analytify_Pro_Admin_Manager::ajax_activate_license',
					$api_params,
					$response
				);
				wp_send_json_error( array( 'message' => __( 'Invalid response from license server.', 'wp-analytify-pro' ) ) );
			}

			if ( 'valid' === $license_response->license ) {

				$this->set_license_key( $this->post_data['license_key'] );
				$license_response->masked_license = $this->get_formatted_masked_license( $this->post_data['license_key'] );

				$this->remove_expiry_transient();

				// Persist only when license is valid.
				update_option( 'analytify_license_status', 'valid' );
				update_option( 'analytify_license_key', $this->post_data['license_key'] );

			} else {

				if ( 'invalid' === $license_response->license ) {

					$timeout = ( $this->has_parent_pro() && isset( $this->parent->transient_timeout ) ) ? (int) $this->parent->transient_timeout : 3600;
					set_site_transient( 'wpanalytify_license_response', $license_response, $timeout );
					$ctx                     = isset( $this->post_data['context'] ) ? $this->post_data['context'] : null;
					$license_response->error = $this->get_license_status_message( $license_response, $ctx );

					// Do not persist invalid license key or status; leave existing saved key/status untouched.
				}
			}

			// Return the response object directly so client-side normalisation works.
			$this->end_ajax( $license_response );
		}
		/**
		 * Remove various license keys via GET request.
		 *
		 * Handles wpanalytify-remove-license and addon-specific remove-license query args
		 * (with nonce). Cleans options, transients, and redirects to license tab.
		 *
		 * @since 1.0.0
		 * @version 7.0.5
		 * @return void
		 */
		public function http_remove_license() {

			if ( ! $this->has_parent_pro() ) {
				return;
			}

			if ( isset( $_GET['wpanalytify-remove-license'], $_GET['nonce'] ) && isset( $_GET['nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['nonce'] ) ), 'wpanalytify-remove-license' ) ) {

				delete_option( 'analytify_license_key' );
				delete_option( 'analytify_license_status' );
				$this->parent->set_license_key( '' );
				// Delete these transients as they contain information only valid for authenticated license holders.
				delete_site_transient( 'update_plugins' );
				delete_site_transient( 'wpanalytify_upgrade_data' );
				delete_site_transient( 'wpanalytify_license_response' );
				
				// Clear any dismissed notice options for license activation - need to match the exact message
				$message = sprintf( esc_html__( '%1$s Activate Your License %2$s &mdash; Please %3$senter your license key%4$s to enable support and plugin updates.', 'wp-analytify-pro' ), '<b>', '</b>', '<a style="text-decoration:none" class="wp-analytify-license-notice" href="' . esc_url( menu_page_url( 'analytify-settings', false ) ) . '#wp-analytify-license">', '</a>' );
				$notice_id = 'analytify_notice_' . md5( $message );
				delete_option( $notice_id );
				
				// Redirect back to the license settings tab.
				wp_safe_redirect( admin_url( 'admin.php?page=analytify-settings#wp-analytify-license' ) );
				exit;
			}

			if ( isset( $_GET['wpanalytify-remove-woo-license'], $_GET['nonce'] ) && isset( $_GET['nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['nonce'] ) ), 'wpanalytify-remove-woo-license' ) ) {

				delete_option( 'analytify_woo_license_key' );
				delete_option( 'analytify_woo_license_status' );
				$this->parent->set_woo_license_key( '' );
				// Delete these transients as they contain information only valid for authenticated license holders.
				delete_site_transient( 'update_plugins' );
				delete_site_transient( 'wpanalytify_upgrade_data' );
				delete_site_transient( 'wpanalytify_woo_license_response' );
				// Redirect back to the license settings tab.
				wp_safe_redirect( admin_url( 'admin.php?page=analytify-settings#wp-analytify-license' ) );
				exit;
			}

			if ( isset( $_GET['wpanalytify-remove-edd-license'] ) && isset( $_GET['nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['nonce'] ) ), 'wpanalytify-remove-edd-license' ) ) {

				delete_option( 'analytify_edd_license_key' );
				delete_option( 'analytify_edd_license_status' );
				$this->parent->set_edd_license_key( '' );
				// Delete these transients as they contain information only valid for authenticated license holders.
				delete_site_transient( 'update_plugins' );
				delete_site_transient( 'wpanalytify_upgrade_data' );
				delete_site_transient( 'wpanalytify_edd_license_response' );
				// Redirect back to the license settings tab.
				wp_safe_redirect( admin_url( 'admin.php?page=analytify-settings#wp-analytify-license' ) );
				exit;
			}

			if ( isset( $_GET['wpanalytify-remove-email-license'] ) && isset( $_GET['nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['nonce'] ) ), 'wpanalytify-remove-email-license' ) ) {

				delete_option( 'analytify_email_license_key' );
				delete_option( 'analytify_email_license_status' );
				$this->parent->set_email_license_key( '' );
				// Delete these transients as they contain information only valid for authenticated license holders.
				delete_site_transient( 'update_plugins' );
				delete_site_transient( 'wpanalytify_upgrade_data' );
				delete_site_transient( 'wpanalytify_email_license_response' );
				// Redirect back to the license settings tab.
				wp_safe_redirect( admin_url( 'admin.php?page=analytify-settings#wp-analytify-license' ) );
				exit;
			}

			if ( isset( $_GET['wpanalytify-remove-campaigns-license'] ) && isset( $_GET['nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['nonce'] ) ), 'wpanalytify-remove-campaigns-license' ) ) {

				delete_option( 'analytify_campaigns_license_key' );
				delete_option( 'analytify_campaigns_license_status' );
				$this->parent->set_campaigns_license_key( '' );
				// Delete these transients as they contain information only valid for authenticated license holders.
				delete_site_transient( 'update_plugins' );
				delete_site_transient( 'wpanalytify_upgrade_data' );
				delete_site_transient( 'wpanalytify_campaigns_license_response' );
				// Redirect back to the license settings tab.
				wp_safe_redirect( admin_url( 'admin.php?page=analytify-settings#wp-analytify-license' ) );
				exit;
			}

			// Removes/Reset Goals addon license key.
			if ( isset( $_GET['wpanalytify-remove-goals-license'] ) && isset( $_GET['nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['nonce'] ) ), 'wpanalytify-remove-goals-license' ) ) {

				delete_option( 'analytify_goals_license_key' );
				delete_option( 'analytify_goals_license_status' );
				$this->parent->set_goals_license_key( '' );
				// Delete these transients as they contain information only valid for authenticated license holders.
				delete_site_transient( 'update_plugins' );
				delete_site_transient( 'wpanalytify_upgrade_data' );
				delete_site_transient( 'wpanalytify_goals_license_response' );
				// Redirect back to the license settings tab.
				wp_safe_redirect( admin_url( 'admin.php?page=analytify-settings#wp-analytify-license' ) );
				exit;
			}

			// Removes/Reset Forms addon license key.
			if ( isset( $_GET['wpanalytify-remove-forms-license'] ) && isset( $_GET['nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['nonce'] ) ), 'wpanalytify-remove-forms-license' ) ) {

				delete_option( 'analytify_forms_license_key' );
				delete_option( 'analytify_forms_license_status' );
				$this->parent->set_forms_license_key( '' );
				// Delete these transients as they contain information only valid for authenticated license holders.
				delete_site_transient( 'update_plugins' );
				delete_site_transient( 'wpanalytify_upgrade_data' );
				delete_site_transient( 'wpanalytify_forms_license_response' );
				// Redirecting here because we don't want to keep the query string in the web browsers address bar.
				wp_safe_redirect( network_admin_url( $this->parent->plugin_settings_base . '#wp-analytify-license' ) );
				exit;
			}

			// Removes/Reset Authors addon license key.
			if ( isset( $_GET['wpanalytify-remove-authors-license'] ) && isset( $_GET['nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['nonce'] ) ), 'wpanalytify-remove-authors-license' ) ) {

				delete_option( 'analytify_authors_license_key' );
				delete_option( 'analytify_authors_license_status' );
				$this->parent->set_authors_license_key( '' );
				// Delete these transients as they contain information only valid for authenticated license holders.
				delete_site_transient( 'update_plugins' );
				delete_site_transient( 'wpanalytify_upgrade_data' );
				delete_site_transient( 'wpanalytify_authors_license_response' );
				// Redirecting here because we don't want to keep the query string in the web browsers address bar.
				wp_safe_redirect( network_admin_url( $this->parent->plugin_settings_base . '#wp-analytify-license' ) );
				exit;
			}
		}
		/**
		 * Tab content in Help Tab for Pro users.
		 *
		 * Outputs the Pro help view (views/help.php) when ANALYTIFY_PRO_ROOT_PATH is defined.
		 *
		 * @since 2.0
		 * @return void
		 */
		public function anlytify_pro_support() {
		include_once ( defined( 'ANALYTIFY_PRO_ROOT_PATH' ) ? ANALYTIFY_PRO_ROOT_PATH . '/views/help.php' : '' );
	}
		/**
		 * Check and dismiss review message.
		 *
		 * Handles GET request with _wpnonce and wp_analytify_review_dismiss; stores
		 * dismissal in site option wp_analytify_review_dismiss.
		 *
		 * @since 1.3
		 * @return void
		 */
		public function review_dismissal() {

			if ( ! is_admin() ||
				! current_user_can( 'manage_options' ) ||
				! isset( $_GET['_wpnonce'] ) ||
				! wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ), 'analytify-review-nonce' ) ||
				! isset( $_GET['wp_analytify_review_dismiss'] ) ) {

				return;
			}

			add_site_option( 'wp_analytify_review_dismiss', 'yes' );
		}

		/**
		 * Show license tab content.
		 *
		 * Renders the License tab form: Premium license key input/status and hooks
		 * for addon license keys (EDD, WooCommerce, Email, Campaigns, Goals, Forms, Authors).
		 *
		 * @since 2.0
		 * @return void
		 */
		public function license_tab_content() {
			$license = $this->get_license_key();
			$status  = $this->get_license_status();
			?>
			<div class="wrap">
			<form method="post" action="">
				<p class="inside"><?php esc_html_e( 'Enter your license key(s). It is important to have a valid license key for automatic plugin updates and support. After adding a license key, press the \'Activate License\' button.', 'wp-analytify-pro' ); ?></p>
					<table class="form-table">
						<tbody>
							<tr valign="top">
								<th scope="row" valign="top">
									<?php esc_html_e( 'Analytify Premium (License Key):', 'wp-analytify-pro' ); ?>
								</th>
								<?php if ( 'valid' === $status ) : ?>
									<td class="pro-license-row">
										<?php echo wp_kses_post( $this->get_formatted_masked_license( $license ) ); ?>
										<br />
										<div id="pro-license-status"></div>
									</td>
								<?php else : ?>
									<td class="pro-license-row">
										<div class="analytify-pro-license-actions">
										<input id="analytify_license_key" name="analytify_license_key" type="text" class="regular-text" value="<?php echo esc_attr( $license ); ?>" />
										<input type="submit" class="button-secondary" id="analytify_license_activate" name="analytify_license_activate" value="<?php esc_html_e( 'Activate License', 'wp-analytify-pro' ); ?>"/>
										</div>
										<?php if ( $status ) { ?>
											<br />
											<div id="pro-license-status"></div>
										<?php } ?>
									</td>
								<?php endif; ?>
							</tr>
							<?php do_action( 'edd_license_key' ); ?>
							<?php do_action( 'woocommerce_license_key' ); ?>
							<?php do_action( 'wp_analytify_email_license_key' ); ?>
							<?php do_action( 'wp_analytify_campaigns_license_key' ); ?>
							<?php do_action( 'wp_analytify_goals_license_key' ); ?>
							<?php do_action( 'wp_analytify_forms_license_key' ); ?>
							<?php do_action( 'wp_analytify_authors_license_key' ); ?>
						</tbody>
					</table>
				</form>
			</div>
			<?php
		}

		/**
		 * Register plugin updater with EDD SL.
		 *
		 * Instantiates EDD_SL_Plugin_Updater when available, using store URL,
		 * plugin path, version, license key, and item ID.
		 *
		 * @since 1.0
		 * @return void
		 */
		public function _plugin_updater() { // phpcs:ignore PSR2.Methods.MethodDeclaration.Underscore
			// Retrieve our license key from the DB.
			$wpa_license_key = trim( get_option( 'analytify_license_key' ) );

			// Setup the updater.
			if ( class_exists( 'EDD_SL_Plugin_Updater' ) ) {
				$edd_updater = new EDD_SL_Plugin_Updater(
					defined( 'ANALYTIFY_STORE_URL' ) ? ANALYTIFY_STORE_URL : '',
					ANALYTIFY_PRO_UPGRADE_PATH,
					array(
						'version' => ANALYTIFY_PRO_VERSION,
						'license' => $wpa_license_key,
						'item_id' => defined( 'ANALYTIFY_PRO_ID' ) ? ANALYTIFY_PRO_ID : 0,
						'author'  => esc_html__( 'Muhammad Adnan', 'wp-analytify-pro' ),
						'beta'    => false,
					)
				);
			}
		}

		/**
		 * Save version number of the plugin and show a custom message for users.
		 *
		 * Updates WP_ANALYTIFY_PRO_PLUGIN_VERSION and stores previous in
		 * WP_ANALYTIFY_PRO_PLUGIN_VERSION_OLD when version constant changes.
		 *
		 * @since 1.3
		 * @return void
		 */
		public function _save_version() { // phpcs:ignore PSR2.Methods.MethodDeclaration.Underscore
			global $current_user;
			$user_id = $current_user->ID;

			if ( defined( 'ANALYTIFY_PRO_VERSION' ) && get_option( 'WP_ANALYTIFY_PRO_PLUGIN_VERSION' ) !== ANALYTIFY_PRO_VERSION ) {
				update_option( 'WP_ANALYTIFY_PRO_PLUGIN_VERSION_OLD', get_option( 'WP_ANALYTIFY_PRO_PLUGIN_VERSION' ), false );
				update_option( 'WP_ANALYTIFY_PRO_PLUGIN_VERSION', defined( 'ANALYTIFY_PRO_VERSION' ) ? ANALYTIFY_PRO_VERSION : '1.0.0' );
			}
		}

		/**
		 * Check license status via AJAX.
		 *
		 * Calls the license server to verify current license; logs failures via
		 * {@see wp_analytify_pro_log_edd_license_request_issue()}.
		 * Rejects `json_decode()` `null` or payloads missing `license`.
		 *
		 * @since 9.0.0
		 * @return void Sends JSON and exits (wp_send_json / wp_send_json_error).
		 */
		public function ajax_check_license() {
			// Check nonce for security.
			if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'wpanalytifypro_check_license' ) ) {
				wp_send_json_error( array( 'message' => __( 'Security check failed.', 'wp-analytify-pro' ) ) );
			}

			$key_rules = array(
				'action'  => 'key',
				'context' => 'key',
				'nonce'   => 'key',
			);
			$this->set_post_data( $key_rules );

			$license = $this->get_license_key();
			$status  = $this->get_license_status();

			if ( empty( $license ) ) {
				wp_send_json_error( array( 'message' => __( 'No license key found.', 'wp-analytify-pro' ) ) );
			}

			$api_params = array(
				'edd_action' => 'check_license',
				'license'    => $license,
				'item_id'    => defined( 'ANALYTIFY_PRO_ID' ) ? ANALYTIFY_PRO_ID : 0,
				'url'        => home_url(),
			);

			$response = wp_remote_get(
				esc_url_raw( add_query_arg( $api_params, defined( 'ANALYTIFY_STORE_URL' ) ? ANALYTIFY_STORE_URL : '' ) ),
				array(
					'timeout'   => 15,
					'sslverify' => false,
				)
			);

			if ( is_wp_error( $response ) ) {
				wp_analytify_pro_log_edd_license_request_issue(
					'License status check failed (transport error).',
					'WP_Analytify_Pro_Admin_Manager::ajax_check_license',
					$api_params,
					$response
				);
				wp_send_json_error( array( 'message' => $response->get_error_message() ) );
			}

		$license_data = json_decode( wp_remote_retrieve_body( $response ) );

		if ( ! $license_data || ! isset( $license_data->license ) ) {
				wp_analytify_pro_log_edd_license_request_issue(
					'License status check returned unexpected or invalid JSON.',
					'WP_Analytify_Pro_Admin_Manager::ajax_check_license',
					$api_params,
					$response
				);
			wp_send_json_error( array( 'message' => __( 'Invalid license data received.', 'wp-analytify-pro' ) ) );
		}

		// Get all customer emails from license data (array or comma-separated), fallback to admin email
		$customer_emails = array();
		if ( isset( $license_data->customer_emails ) && is_array( $license_data->customer_emails ) ) {
			$customer_emails = $license_data->customer_emails;
		} elseif ( isset( $license_data->customer_email ) && !empty( $license_data->customer_email ) ) {
		// Support comma-separated string or single email.
		if ( strpos( $license_data->customer_email, ',' ) !== false ) {
			$customer_emails = array_map( 'sanitize_email', explode( ',', $license_data->customer_email ) );
		} else {
			$customer_emails[] = sanitize_email( $license_data->customer_email );
		}
		}
		if ( empty( $customer_emails ) ) {
			$customer_emails[] = get_option( 'admin_email' );
		}

		// Sanitize customer emails array.
		$customer_emails = array_map( 'sanitize_email', $customer_emails );

		$api_license = isset( $license_data->license ) ? strtolower( sanitize_text_field( $license_data->license ) ) : '';

		$this->persist_license_check_result( $license_data, $api_license );

		// Return data directly without wrapping in 'data' object.
		$response_data = array(
			'success'          => true,
			'license'          => isset( $license_data->license ) ? sanitize_text_field( $license_data->license ) : '',
			'status'           => $api_license ? $api_license : sanitize_text_field( $status ),
			'expires'          => isset( $license_data->expires ) && 'lifetime' !== $license_data->expires ? sanitize_text_field( $license_data->expires ) : $license_data->expires,
			'activations_left' => isset( $license_data->activations_left ) ? absint( $license_data->activations_left ) : 'N/A',
			'license_limit'    => isset( $license_data->license_limit ) ? absint( $license_data->license_limit ) : 'N/A',
			'customer_emails'  => $customer_emails,
		);

		wp_send_json( $response_data );
		}

		/**
		 * Deactivate license via AJAX.
		 *
		 * Sends deactivation request to the license server; logs transport/JSON/state
		 * issues via {@see wp_analytify_pro_log_edd_license_request_issue()} or
		 * {@see wp_analytify_pro_log_edd_license_state_validation_failure()} for unexpected license state.
		 *
		 * @since 9.0.0
		 * @return void Sends JSON and exits (wp_send_json_success / wp_send_json_error).
		 */
		public function analytify_license_deactivate() {
			// Check nonce for security.
			if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'wpanalytifypro_deactivate_license' ) ) {
				wp_send_json_error( array( 'message' => __( 'Security check failed.', 'wp-analytify-pro' ) ) );
			}

			$key_rules = array(
				'action'  => 'key',
				'context' => 'key',
				'nonce'   => 'key',
			);
			$this->set_post_data( $key_rules );

			$license = $this->get_license_key();

			if ( empty( $license ) ) {
				wp_send_json_error( array( 'message' => __( 'No license key found.', 'wp-analytify-pro' ) ) );
			}

			$api_params = array(
				'edd_action' => 'deactivate_license',
				'license'    => $license,
				'item_id'    => defined( 'ANALYTIFY_PRO_ID' ) ? ANALYTIFY_PRO_ID : 0,
				'url'        => home_url(),
			);

			$response = wp_remote_get(
				esc_url_raw( add_query_arg( $api_params, defined( 'ANALYTIFY_STORE_URL' ) ? ANALYTIFY_STORE_URL : '' ) ),
				array(
					'timeout'   => 15,
					'sslverify' => false,
				)
			);

			if ( is_wp_error( $response ) ) {
				wp_analytify_pro_log_edd_license_request_issue(
					'License deactivation failed (transport error).',
					'WP_Analytify_Pro_Admin_Manager::analytify_license_deactivate',
					$api_params,
					$response
				);
				wp_send_json_error( array( 'message' => $response->get_error_message() ) );
			}

			$license_data = json_decode( wp_remote_retrieve_body( $response ) );

			if ( null === $license_data || ! is_object( $license_data ) || ! isset( $license_data->license ) ) {
				wp_analytify_pro_log_edd_license_request_issue(
					'License deactivation returned unexpected or invalid JSON.',
					'WP_Analytify_Pro_Admin_Manager::analytify_license_deactivate',
					$api_params,
					$response
				);
				wp_send_json_error( array( 'message' => __( 'Invalid response from license server.', 'wp-analytify-pro' ) ) );
			}

			if ( 'deactivated' === $license_data->license ) {
				delete_option( 'analytify_license_key' );
				delete_option( 'analytify_license_status' );
				wp_send_json_success( array( 'message' => __( 'License deactivated successfully.', 'wp-analytify-pro' ) ) );
			}

			wp_analytify_pro_log_edd_license_state_validation_failure(
				'License deactivation refused or returned unexpected license state.',
				'WP_Analytify_Pro_Admin_Manager::analytify_license_deactivate',
				$api_params,
				array(
					'license_status' => isset( $license_data->license ) ? (string) $license_data->license : 'unknown',
					'http_code'      => function_exists( 'wp_remote_retrieve_response_code' ) ? (int) wp_remote_retrieve_response_code( $response ) : 0,
				)
			);
			wp_send_json_error( array( 'message' => __( 'Failed to deactivate license.', 'wp-analytify-pro' ) ) );
		}

		/**
		 * Register the Pro license key setting with sanitization callback.
		 *
		 * Registers analytify_license_key with analytify-settings group and
		 * analytify_sanitize_license as the sanitize callback.
		 *
		 * @since 2.0
		 * @return void
		 */
		public function wp_analytify_register_option() {
			// Creates our settings in the options table.
			register_setting( 'analytify-settings', 'analytify_license_key', array( $this, 'analytify_sanitize_license' ) );
		}

		/**
		 * Sanitize and validate license key on save.
		 *
		 * When the key changes, deletes analytify_license_status so status is rechecked.
		 *
		 * @since 1.0.0
		 * @param string $new New license key value from the form.
		 * @return string The new value to store.
		 */
		public function analytify_sanitize_license( $new ) { // phpcs:ignore Universal.NamingConventions.NoReservedKeywordParameterNames.newFound
			$old = get_option( 'analytify_license_key' );
			if ( $old && $old !== $new ) {
				delete_option( 'analytify_license_status' );
			}
			return $new;
		}

		/**
		 * Check if a plugin update is available and output notice markup.
		 *
		 * Uses transient wp_analytify_check_latest_version; fetches latest version
		 * from license server when transient is missing. Echoes update notice HTML when
		 * installed version is lower than latest.
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function is_update_available() {
			$installed_version = defined( 'ANALYTIFY_PRO_VERSION' ) ? ANALYTIFY_PRO_VERSION : '0';

		$latest_version = get_site_transient( 'wp_analytify_check_latest_version' );

		if ( false === $latest_version || empty( $latest_version ) ) {
			// Use user's license key if available, otherwise use empty string for version check.
			$license_key    = $this->get_license_key();
			$latest_version = $this->get_latest_version( $license_key ? $license_key : '' );
			set_site_transient( 'wp_analytify_check_latest_version', $latest_version, 60 * 60 * 24 );
		}

			if ( $latest_version && version_compare( $installed_version, $latest_version, '<' ) ) {
				// translators: %1$s is bold opening tag, %2$s is bold closing tag, %3$s is changelog link opening tag, %4$s is changelog link closing tag, %5$s is plugin name, %6$s is latest version, %7$s is installed version.
				$message = sprintf( esc_html__( '%1$s Update Available %2$s &mdash; %5$s %6$s is now available. You currently have %7$s installed. %3$s Changelog %4$s', 'wp-analytify-pro' ), '<b>', '</b>', '<a style="text-decoration:none" target="_blank" href="https://analytify.io/changelog/?utm_campaign=WPAnalytifyPro+UpdateAvailable&utm_medium=link&utm_source=WPAnalytifyPro+UpdateAvailable&utm_content=update-available-notice">', '</a>', 'WP Analytify Pro', $latest_version, $installed_version );
				wp_analytify_pro_notice( $message, 'wp-analytify-success' );
			}
		}

		/**
		 * Display a license/update message in the plugin list row.
		 *
		 * Shows notice when license is missing, invalid/expired, or when a new version
		 * is available. Invoked by plugin_row_meta / after_plugin_row.
		 *
		 * @since 1.3.3
		 * @param string               $plugin_path Path to the plugin file.
		 * @param array<string, mixed> $plugin_data Plugin data array (Name, Version, etc.).
		 * @return void
		 */
		public function wpa_plugin_row( string $plugin_path, array $plugin_data ) {
			if ( ! $this->has_parent_pro() ) {
				return;
			}

			$plugin_title    = $plugin_data['Name'];
			$plugin_slug     = sanitize_title( $plugin_title );
			$license         = $this->get_license_key();
			$license_trans   = get_site_transient( 'wpanalytify_license_response' );
			$license_problem = is_object( $license_trans ) && isset( $license_trans->error );

			$installed_version = defined( 'ANALYTIFY_PRO_VERSION' ) ? ANALYTIFY_PRO_VERSION : '0';

			$latest_version = $this->get_latest_version( $license );

			$new_version = '';
			if ( $latest_version && version_compare( $installed_version, $latest_version, '<' ) ) {
				// translators: %s is the plugin title.
				$new_version  = sprintf( __( 'There is a new version of %s available.', 'wp-analytify-pro' ), $plugin_title );
				$new_version .= ' <a class="thickbox" title="' . esc_attr( $plugin_title ) . '" href="plugin-install.php?tab=plugin-information&plugin=' . rawurlencode( $plugin_slug ) . '&TB_iframe=true&width=640&height=808">';
				// translators: %s is the latest version.
				$new_version .= sprintf( __( 'View version %s details', 'wp-analytify-pro' ), $latest_version ) . '</a>.';
			}

			if ( ! $new_version && ! empty( $license ) ) {
				return;
			}

			if ( empty( $license ) ) {
				$settings_link = sprintf( '<a href="%s">%s</a>', esc_url( network_admin_url( $this->parent->plugin_base ) . '#settings' ), _x( 'Settings', 'Plugin configuration and preferences', 'wp-analytify-pro' ) );
				if ( $new_version ) {
					// translators: %1$s is the settings link, %2$s is the pricing URL.
					$message = sprintf( __( 'To update, go to %1$s and enter your license key. If you don\'t have a license key, you may <a href="%2$s">purchase one</a>.', 'wp-analytify-pro' ), $settings_link, 'http://analytify.io/pricing/' );
				} else {
					// translators: %1$s is the plugin title, %2$s is the settings link, %3$s is the pricing URL.
					$message = sprintf( __( 'To finish activating %1$s, please go to %2$s and enter your license key. If you don\'t have a license key, you may <a href="%3$s">purchase one</a>.', 'wp-analytify-pro' ), $this->parent->plugin_title, $settings_link, 'http://analytify.io/pricing/' );
				}
			} elseif ( $license_problem ) {
				$err_msg = $this->get_license_status_message( $license_trans )['message'];
				$message = $err_msg . sprintf( ' <a href="#" class="check-my-license-again">%s</a>', __( 'Check my license again', 'wp-analytify-pro' ) );
			} else {
				return;
			}
			?>
			<tr class="plugin-update-tr wpanalytifypro-custom">
				<td colspan="3" class="plugin-update">
					<div class="update-message">
						<span class="wpanalytify-new-version-notice"><?php echo esc_html( $new_version ); ?></span>
						<span class="wpanalytify-license-error-notice"><?php echo esc_html( $message ); ?></span>
					</div>
				</td>
			</tr>
			<?php if ( $new_version ) { ?>
				<script type="text/javascript">
					(function( $ ) {
						var wpanalytify_row = jQuery( '#<?php echo esc_js( $plugin_slug ); ?>' ),
							next_row = wpanalytify_row.next();

						if ( next_row.hasClass( 'plugin-update-tr' ) && !next_row.hasClass( 'wpanalytifypro-custom' ) ) {
							var original = next_row.clone();
							original.addClass( 'wpanalytifypro-custom' );
							next_row.html( next_row.next().html() ).addClass( 'wpanalytifypro-custom-visible' );
							next_row.next().remove();
							next_row.after( original );
							original.addClass( 'wpanalytify-original-update-row' );
						}
					})( jQuery );
				</script>
			<?php } ?>
			<style type="text/css">
				.plugin-update-tr .update-message {
					font-size: 13px;
					font-weight: 400;
					margin: 0 10px 8px 31px;
					padding: 6px 12px 8px 40px;
					background-color: #f7f7f7;
					background-color: rgba(0,0,0,.03);
				}
				.plugin-update .update-message {
					background-color: #fcf3ef;
				}
			</style>
			<?php
		}

		/**
		 * Pro feature box sidebar HTML.
		 *
		 * Returns markup for the "Thank you" and "made with ♥ by WPBrigade" side boxes.
		 *
		 * @since 1.0.0
		 * @param string $inner_html Inner HTML content (may be unused by this implementation).
		 * @return string HTML for the Pro thank-you and credit boxes.
		 */
		public function pro_feature_box( $inner_html ) {
			$inner_html = '
                            <div class="postbox-container side">
                                    <div class="metabox-holder">
                                        <div class="grids_auto_size wpa_side_box" style="width: 100%;">
                                        <div class="grid_title cen"> ' . __( 'Thank you!', 'wp-analytify-pro' ) . ' </div>
                                            <div class="grid_footer cen" style="background-color:white;">
																							' . __( 'We appreciate you to upgrade to Pro version and supporting the development of this product.', 'wp-analytify-pro' ) . '
                                            </div>
                                        </div>
                                        <div class="grids_auto_size wpa_side_box" style=" width: 100%;">
                                            <div class="grid_footer cen">
																						' . __( 'made with ♥ by', 'wp-analytify-pro' ) . '
                                             <a href="http://wpbrigade.com" title="WPBrigade | A Brigade of WordPress Developers." />WPBrigade</a>
                                            </div>
                                        </div>
                                    </div>
							</div>';
			return $inner_html;
		}

		/**
		 * Filter to add Pro-specific localized data for JS.
		 *
		 * Adds has_license flag and nonces for check_license, deactivate_license,
		 * activate_license, refresh_debug_log, and fetch-log.
		 *
		 * @since 1.0.0
		 * @param array<string, mixed> $data Existing localized data array.
		 * @return array<string, mixed> Merged array including Pro nonces and has_license.
		 */
		public function _wpanalytify_data( array $data ): array { // phpcs:ignore PSR2.Methods.MethodDeclaration.Underscore
				$pro_data = array(
					'has_license' => esc_html( '' === $this->get_license_key() ? '0' : '1' ),
					'nonces'      => array(
						'check_license'      => wp_create_nonce( 'wpanalytifypro_check_license' ),
						'deactivate_license' => wp_create_nonce( 'wpanalytifypro_deactivate_license' ),
						'activate_license'   => wp_create_nonce( 'wpanalytifypro_activate_license' ),
						'refresh_debug_log'  => wp_create_nonce( 'wpanalytifypro_refresh_debug_log' ),
						'fetch_log'          => wp_create_nonce( 'fetch-log' ),
					),
				);
					return array_merge( $data, $pro_data );
		}

		/**
		 * Add Pro plugin diagnostic information to core diagnostic output.
		 *
		 * Echoes Pro version, ID, store URL, root path, license key, license status,
		 * and license expired flag. Uses this class's get_license_key(), get_license_status(),
		 * and is_license_expired() for consistency with the rest of the admin manager.
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function add_pro_diagnostic_info() {
			echo "\n-- " . esc_html__( 'Pro Plugin Information', 'wp-analytify-pro' ) . " --\n";
			echo esc_html__( 'Pro Version:', 'wp-analytify-pro' ) . ' ' . esc_html( defined( 'ANALYTIFY_PRO_VERSION' ) ? ANALYTIFY_PRO_VERSION : esc_html__( 'Not defined', 'wp-analytify-pro' ) ) . "\n";
			echo esc_html__( 'Pro ID:', 'wp-analytify-pro' ) . ' ' . esc_html( defined( 'ANALYTIFY_PRO_ID' ) ? ANALYTIFY_PRO_ID : esc_html__( 'Not defined', 'wp-analytify-pro' ) ) . "\n";
			echo esc_html__( 'Store URL:', 'wp-analytify-pro' ) . ' ' . esc_html( defined( 'ANALYTIFY_STORE_URL' ) ? ANALYTIFY_STORE_URL : esc_html__( 'Not defined', 'wp-analytify-pro' ) ) . "\n";
			echo esc_html__( 'Root Path:', 'wp-analytify-pro' ) . ' ' . esc_html( defined( 'ANALYTIFY_PRO_ROOT_PATH' ) ? ANALYTIFY_PRO_ROOT_PATH : esc_html__( 'Not defined', 'wp-analytify-pro' ) ) . "\n";
			echo esc_html__( 'License Key:', 'wp-analytify-pro' ) . ' ' . esc_html( $this->get_license_key() ) . "\n";
			echo esc_html__( 'License Status:', 'wp-analytify-pro' ) . ' ' . esc_html( $this->get_license_status() ) . "\n";
			echo esc_html__( 'License Expired:', 'wp-analytify-pro' ) . ' ' . esc_html( $this->is_license_expired() ? esc_html__( 'Yes', 'wp-analytify-pro' ) : esc_html__( 'No', 'wp-analytify-pro' ) ) . "\n";
		}

		/**
		 * Echo Pixels, Google Ads, and PMPro options in the diagnostic log.
		 *
		 * LearnDash and LifterLMS integrations do not use a dedicated options blob here;
		 * enable/disable follows the Pro modules list (wp_analytify_modules) above.
		 *
		 * @since 9.0.0
		 * @return void
		 */
		public function add_pro_addon_settings_diagnostic() {
			echo "\r\n-- " . esc_html__( 'Pixels Tracking Setting', 'wp-analytify-pro' ) . " --\r\n \r\n";

			$pixels = get_option( 'analytify-pixels-tracking' );
			if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'print_settings_array' ) ) {
				WPANALYTIFY_Utils::print_settings_array( is_array( $pixels ) ? $pixels : array() );
			} else {
				echo esc_html( is_array( $pixels ) ? wp_json_encode( $pixels ) : '' ) . "\r\n";
			}

			echo "\r\n-- " . esc_html__( 'Google Ads Tracking Setting', 'wp-analytify-pro' ) . " --\r\n \r\n";

			$google_ads = get_option( 'analytify-google-ads-tracking' );
			if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'print_settings_array' ) ) {
				WPANALYTIFY_Utils::print_settings_array( is_array( $google_ads ) ? $google_ads : array() );
			} else {
				echo esc_html( is_array( $google_ads ) ? wp_json_encode( $google_ads ) : '' ) . "\r\n";
			}

			echo "\r\n-- " . esc_html__( 'Paid Memberships Pro Addon Options', 'wp-analytify-pro' ) . " --\r\n \r\n";

			$pmpro_opts = array(
				'analytify_pmpro_track_events'    => get_option( 'analytify_pmpro_track_events' ),
				'analytify_pmpro_track_purchases' => get_option( 'analytify_pmpro_track_purchases' ),
			);
			if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'print_settings_array' ) ) {
				WPANALYTIFY_Utils::print_settings_array( $pmpro_opts );
			} else {
				echo esc_html( wp_json_encode( $pmpro_opts ) ) . "\r\n";
			}

			echo "\r\n-- " . esc_html__( 'LearnDash / LifterLMS', 'wp-analytify-pro' ) . " --\r\n \r\n";
			echo esc_html__( 'No separate wp_options blob; tracking is on when the module is active in wp_analytify_modules.', 'wp-analytify-pro' ) . "\r\n";
		}

		/**
		 * Add Pro tabs (Front, License) to settings tabs.
		 *
		 * Inserts 'front' after the second tab and appends 'license' at the end.
		 *
		 * @since 1.0.0
		 * @param array<string, mixed> $tabs Existing tabs array (key => label).
		 * @return array<string, mixed> Modified tabs array including Front and License.
		 */
		public function wp_analytify_pro_tabs( array $tabs ): array {
			$front_tab = array(
				'front' => __( 'Front', 'wp-analytify-pro' ),
			);

			$license_tab = array(
				'license' => __( 'License', 'wp-analytify-pro' ),
			);

			$first_tab  = array_slice( $tabs, 0, 2 );
			$second_tab = array_slice( $tabs, 2 );

			$first_tab = array_merge( $first_tab, $front_tab );

			$second_tab = array_merge( $first_tab, $second_tab );
			$tabs       = array_merge( $second_tab, $license_tab );

			return $tabs;
		}

		/**
		 * Get the stored Pro license key.
		 *
		 * @since 1.0.0
		 * @return string License key or empty string if not set.
		 */
		public function get_license_key() {
			return get_option( 'analytify_license_key', '' );
		}

		/**
		 * Store license check API result and sync the saved status option.
		 *
		 * Keeps `analytify_license_status` aligned with EDD when the user still has a
		 * key saved (e.g. valid at activation, expired after a plugin update).
		 *
		 * @since 9.0.0
		 * @param object $license_data Decoded EDD check_license response.
		 * @param string $api_license  Normalized license field from the API.
		 * @return void
		 */
		private function persist_license_check_result( $license_data, $api_license ) {
			$timeout = ( $this->has_parent_pro() && isset( $this->parent->transient_timeout ) )
				? (int) $this->parent->transient_timeout
				: 3600;

			set_site_transient( 'wpanalytify_license_response', $license_data, $timeout );
			delete_site_transient( 'wp_analytify_check_license_expiration' );

			$persistable = array(
				'valid',
				'expired',
				'inactive',
				'site_inactive',
				'disabled',
				'deactivated',
			);

			if ( in_array( $api_license, $persistable, true ) ) {
				update_option( 'analytify_license_status', $api_license );
			}
		}

		/**
		 * Get the stored Pro license status.
		 *
		 * Returns a normalized EDD-style status string, an empty string when unset, or
		 * `invalid` when the option is missing, corrupt, or not one of the known states
		 * (so callers never receive unexpected scalars such as `2` as a status).
		 *
		 * @since 1.0.0
		 * @return string One of: `valid`, `invalid`, `expired`, `inactive`, `site_inactive`,
		 *                `disabled`, `deactivated`, or empty string when no status is stored.
		 */
		public function get_license_status() {
			$status = get_option( 'analytify_license_status', '' );

			if ( false === $status || null === $status ) {
				return '';
			}

			if ( ! is_string( $status ) ) {
				return 'invalid';
			}

			$status = strtolower( trim( $status ) );
			if ( '' === $status ) {
				return '';
			}

			// Some EDD/API payloads use `success` interchangeably with `valid`.
			if ( 'success' === $status ) {
				return 'valid';
			}

			$known = array(
				'valid',
				'invalid',
				'expired',
				'inactive',
				'site_inactive',
				'disabled',
				'deactivated',
			);

			if ( in_array( $status, $known, true ) ) {
				return $status;
			}

			return 'invalid';
		}

		/**
		 * Check if the Pro license status is expired.
		 *
		 * @since 1.0.0
		 * @return bool True if status is 'expired', false otherwise.
		 */
		public function is_license_expired() {
			$status = $this->get_license_status();
			return 'expired' === $status;
		}

		/**
		 * Whether the Pro license is active enough to receive plugin updates.
		 *
		 * False when the key is missing/empty, the status option is unset, or status is not `valid`.
		 *
		 * @since 9.1.0
		 * @return bool
		 */
		public function is_license_active_for_updates() {
			if ( '' === trim( $this->get_license_key() ) ) {
				return false;
			}

			if ( false === get_option( 'analytify_license_status', false ) ) {
				return false;
			}

			return 'valid' === $this->get_license_status();
		}

		/**
		 * Get human-readable license status message from transaction/response object.
		 *
		 * @since 1.0.0
		 * @param mixed  $trans   License API response object (optional).
		 * @param string $context Context string (optional, reserved for future use).
		 * @return array<string, string> Array with 'message' key; empty message if no error in $trans.
		 */
		public function get_license_status_message( $trans = false, $context = null ): array { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed
			if ( is_object( $trans ) && isset( $trans->error ) ) {
				return array( 'message' => (string) $trans->error );
			}
			return array( 'message' => '' );
		}

		/**
		 * Verify AJAX request with WordPress nonce.
		 *
		 * Wrapper around check_ajax_referer(); dies on failure.
		 *
		 * @since 1.0.0
		 * @param string $action Nonce action name.
		 * @return void
		 */
		public function check_ajax_referer( $action ) {
			check_ajax_referer( $action );
		}

		/**
		 * Refresh debug log via AJAX.
		 *
		 * Verifies nonce (wpanalytifypro_refresh_debug_log), then returns JSON success
		 * with get_debug_log_content() output and a success message.
		 *
		 * @since 1.0.0
		 * @return void Sends JSON and exits.
		 */
		public function ajax_refresh_debug_log() {
			// Check nonce for security.
			if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'wpanalytifypro_refresh_debug_log' ) ) {
				wp_send_json_error( array( 'message' => __( 'Security check failed.', 'wp-analytify-pro' ) ) );
			}

			// Get debug log content.
			$debug_log = $this->get_debug_log_content();

			wp_send_json_success(
				array(
					'debug_log' => $debug_log,
					'message'   => __( 'Debug log refreshed successfully.', 'wp-analytify-pro' ),
				)
			);
		}

		/**
		 * Get debug log content for diagnostics.
		 *
		 * Builds a text report including WordPress environment, Analytify plugin info,
		 * license info, GA config, plugin dependencies, active plugins, theme info,
		 * and the last 50 lines of the PHP error log (if available).
		 *
		 * @since 1.0.0
		 * @return string Full debug report as plain text.
		 */
		public function get_debug_log_content() {
			$debug_content = '';

			// WordPress Environment Information.
			$debug_content .= "=== WordPress ENVIRONMENT ===\n";
			$debug_content .= 'WordPress Version: ' . get_bloginfo( 'version' ) . "\n";
			$debug_content .= 'PHP Version: ' . phpversion() . "\n";
			$debug_content .= 'MySQL Version: ' . $this->get_mysql_version() . "\n";
			$debug_content .= 'Web Server: ' . ( isset( $_SERVER['SERVER_SOFTWARE'] ) ? sanitize_text_field( wp_unslash( $_SERVER['SERVER_SOFTWARE'] ) ) : 'Unknown' ) . "\n";
			$debug_content .= 'Site URL: ' . get_site_url() . "\n";
			$debug_content .= 'Home URL: ' . get_home_url() . "\n";
			$debug_content .= 'Multisite: ' . ( is_multisite() ? 'Yes' : 'No' ) . "\n";
			$debug_content .= 'Debug Mode: ' . ( WP_DEBUG ? 'Enabled' : 'Disabled' ) . "\n";
			$debug_content .= 'Memory Limit: ' . ( defined( 'WP_MEMORY_LIMIT' ) ? WP_MEMORY_LIMIT : 'Not defined' ) . "\n";
			$debug_content .= 'Max Upload Size: ' . size_format( wp_max_upload_size() ) . "\n";
			$debug_content .= "\n";

			// Analytify Plugin Information.
			$debug_content .= "=== ANALYTIFY PLUGIN INFORMATION ===\n";
			$debug_content .= 'Analytify Core Version: ' . ( defined( 'ANALYTIFY_VERSION' ) ? ANALYTIFY_VERSION : 'Not defined' ) . "\n";
			$debug_content .= 'Analytify Pro Version: ' . ( defined( 'ANALYTIFY_PRO_VERSION' ) ? ANALYTIFY_PRO_VERSION : 'Not defined' ) . "\n";
			$debug_content .= 'Analytify Pro ID: ' . ( defined( 'ANALYTIFY_PRO_ID' ) ? ANALYTIFY_PRO_ID : 'Not defined' ) . "\n";
			$debug_content .= 'Analytify Store URL: ' . ( defined( 'ANALYTIFY_STORE_URL' ) ? ANALYTIFY_STORE_URL : 'Not defined' ) . "\n";
			$debug_content .= 'Analytify Pro Root Path: ' . ( defined( 'ANALYTIFY_PRO_ROOT_PATH' ) ? ANALYTIFY_PRO_ROOT_PATH : 'Not defined' ) . "\n";
			$debug_content .= "\n";

			// License Information.
			$debug_content .= "=== LICENSE INFORMATION ===\n";
			$debug_content .= 'License Key: ' . $this->get_license_key() . "\n";
			$debug_content .= 'License Status: ' . $this->get_license_status() . "\n";
			$debug_content .= 'License Expired: ' . ( $this->is_license_expired() ? 'Yes' : 'No' ) . "\n";
			$debug_content .= "\n";

			// Google Analytics Configuration.
			$debug_content .= "=== GOOGLE ANALYTICS CONFIGURATION ===\n";
			$debug_content .= 'Profile ID: ' . get_option( 'pt_webprofile', 'Not set' ) . "\n";
			$debug_content .= 'Access Token: ' . ( get_option( 'post_analytics_token' ) ? 'Set' : 'Not set' ) . "\n";
			$debug_content .= 'GA Mode: ' . ( defined( 'ANALYTIFY_GA_MODE' ) ? ANALYTIFY_GA_MODE : 'Not defined' ) . "\n";
			$debug_content .= "\n";

			// Plugin Dependencies.
			$debug_content .= "=== PLUGIN DEPENDENCIES ===\n";
			$debug_content .= 'EDD SL Plugin Updater: ' . ( class_exists( 'EDD_SL_Plugin_Updater' ) ? 'Available' : 'Not available' ) . "\n";
			$debug_content .= 'WP Analytify Global: ' . ( isset( $GLOBALS['WP_ANALYTIFY'] ) ? 'Available' : 'Not available' ) . "\n";
			$debug_content .= "\n";

			// Active Plugins.
			$debug_content .= "=== ACTIVE PLUGINS ===\n";
			$active_plugins = get_option( 'active_plugins' );
			foreach ( $active_plugins as $plugin ) {
				$plugin_data    = get_plugin_data( WP_PLUGIN_DIR . '/' . $plugin );
				$debug_content .= $plugin_data['Name'] . ' - ' . $plugin_data['Version'] . "\n";
			}
			$debug_content .= "\n";

			// Theme Information.
			$debug_content .= "=== THEME INFORMATION ===\n";
			$theme          = wp_get_theme();
			$debug_content .= 'Theme Name: ' . $theme->get( 'Name' ) . "\n";
			$debug_content .= 'Theme Version: ' . $theme->get( 'Version' ) . "\n";
			$debug_content .= 'Theme Author: ' . $theme->get( 'Author' ) . "\n";
			$debug_content .= "\n";

			// Error Log (if available).
			$debug_content .= "=== ERROR LOG ===\n";
			$error_log_path = ini_get( 'error_log' );
			if ( $error_log_path && file_exists( $error_log_path ) ) {
				// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
				$error_log_content = file_get_contents( $error_log_path );
				if ( $error_log_content ) {
					$debug_content .= "Last 50 lines of error log:\n";
					$lines          = explode( "\n", $error_log_content );
					$last_lines     = array_slice( $lines, -50 );
					$debug_content .= implode( "\n", $last_lines ) . "\n";
				} else {
					$debug_content .= "Error log is empty or not readable\n";
				}
			} else {
				$debug_content .= "Error log not available or not readable\n";
			}

			return $debug_content;
		}

		/**
		 * Get MySQL server version from WordPress database object.
		 *
		 * @since 1.0.0
		 * @return string MySQL version string or 'Unknown' if not available.
		 */
		private function get_mysql_version() {
			global $wpdb;
			if ( isset( $wpdb->db_version ) ) {
				return $wpdb->db_version;
			}
			return 'Unknown';
		}



		/**
		 * Persist the Pro license key to options.
		 *
		 * @since 1.0.0
		 * @param string $key License key to store.
		 * @return void
		 */
		public function set_license_key( $key ) {
			update_option( 'analytify_license_key', $key );
		}

		/**
		 * Get formatted masked license for display (with Remove link when manager available).
		 *
		 * Uses WP_Analytify_Pro_License_Manager::get_formatted_masked_license when available;
		 * otherwise returns a simple first-4 and last-4 character mask.
		 *
		 * @since 1.0.0
		 * @param string $key License key to mask.
		 * @return string Masked display string, or HTML including Remove link from manager.
		 */
		public function get_formatted_masked_license( $key ) {
			// Prefer the dedicated license manager implementation which
					// returns the masked license plus the "Remove" anchor. This
					// ensures consistent masking and link generation across the UI.
					if ( class_exists( 'WP_Analytify_Pro_License_Manager' ) ) {
						$manager = WP_Analytify_Pro_License_Manager::instance();
						if ( $manager && method_exists( $manager, 'get_formatted_masked_license' ) ) {
							// $this->parent->plugin_settings_base is used elsewhere in the codebase
							// to build the settings URL. Fall back to empty string if not available.
							$base = ( $this->has_parent_pro() && isset( $this->parent->plugin_settings_base ) )
								? $this->parent->plugin_settings_base
								: '';
							return $manager->get_formatted_masked_license( $key, $base );
						}
					}

			// Fallback: short simple masking if license manager isn't available.
			if ( strlen( $key ) > 8 ) {
				return substr( $key, 0, 4 ) . '...' . substr( $key, -4 );
			}
			return $key;
		}

		/**
		 * Remove the license expiration check transient.
		 *
		 * Called after successful license activation so the next check fetches fresh data.
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function remove_expiry_transient() {
			delete_site_transient( 'wp_analytify_check_license_expiration' );
		}

		/**
		 * Get latest Pro plugin version from the license server.
		 *
		 * Sends get_version EDD action with license and item_id; returns new_version
		 * from response or empty string on failure or missing license.
		 *
		 * @since 1.0.0
		 * @param string $license License key for the API request.
		 * @return string New version string or empty string.
		 */
		public function get_latest_version( $license ) {
			if ( empty( $license ) ) {
				return '';
			}

			$api_params = array(
				'edd_action' => 'get_version',
				'license'    => $license,
				'item_id'    => defined( 'ANALYTIFY_PRO_ID' ) ? ANALYTIFY_PRO_ID : 0,
				'url'        => home_url(),
			);

			$response = wp_remote_post(
				defined( 'ANALYTIFY_STORE_URL' ) ? ANALYTIFY_STORE_URL : '',
				array(
					'timeout'   => 15,
					'sslverify' => false,
					'body'      => $api_params,
				)
			);

			if ( is_wp_error( $response ) ) {
				return '';
			}

			$license_data = json_decode( wp_remote_retrieve_body( $response ) );

			if ( isset( $license_data->new_version ) ) {
				return $license_data->new_version;
			}

			return '';
		}

		/**
		 * End AJAX request by sending JSON success and optional data.
		 *
		 * @since 1.0.0
		 * @param mixed $return Optional data to send in the success response.
		 * @return void Sends JSON and exits.
		 */
		public function end_ajax( $return = false ) { // phpcs:ignore Universal.NamingConventions.NoReservedKeywordParameterNames.returnFound
			if ( $return ) {
				wp_send_json_success( $return );
			} else {
				wp_send_json_success();
			}
		}

		/**
		 * Populate post data and mirror into parent state_data from $_POST.
		 *
		 * Reads keys from $key_rules, sanitizes with sanitize_text_field (or optional
		 * sanitize rule), stores in $this->post_data and $this->parent->state_data for
		 * legacy callers.
		 *
		 * @since 1.0.0
		 * @param array<string, mixed> $key_rules Map of POST key => rules (e.g. 'key' or 'string'); optional 'sanitize' for text/textarea/email/url/int/float.
		 * @param string               $context  Context string (reserved for future use).
		 * @return void
		 */
		public function set_post_data( array $key_rules = array(), string $context = '' ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed
			if ( empty( $key_rules ) ) {
				return;
			}

			foreach ( $key_rules as $key => $rules ) {
				if ( isset( $_POST[ $key ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
					$value = sanitize_text_field( wp_unslash( $_POST[ $key ] ) );

					// Apply sanitization rules if provided.
					if ( isset( $rules['sanitize'] ) ) {
						switch ( $rules['sanitize'] ) {
							case 'text':
								$value = sanitize_text_field( $value );
								break;
							case 'textarea':
								$value = sanitize_textarea_field( $value );
								break;
							case 'email':
								$value = sanitize_email( $value );
								break;
							case 'url':
								$value = esc_url_raw( $value );
								break;
							case 'int':
								$value = intval( $value );
								break;
							case 'float':
								$value = floatval( $value );
								break;
						}
					}

					// Store the sanitized value.
					$this->post_data[ $key ] = $value;
					// Mirror into parent->state_data for legacy callers that expect it.
					if ( $this->has_parent_pro() ) {
						// Ensure state_data exists and is an array.
						if ( ! isset( $this->parent->state_data ) || ! is_array( $this->parent->state_data ) ) {
							$this->parent->state_data = array();
						}
						$this->parent->state_data[ $key ] = $value;
					}
				}
			}
		}
	}
}
