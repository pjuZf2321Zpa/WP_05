<?php // phpcs:ignore WordPress.Files.FileName.InvalidClassFileName
/**
 * WP Analytify Pro REST API Demographics Endpoints Class
 *
 * This class handles demographics-related REST API endpoints including:
 * - Demographics
 * - Interests
 * - Real-time reporting
 *
 * @package WP_Analytify_Pro
 * @since 1.0.0
 * @version 9.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_Analytify_Pro_REST_Demographics' ) ) {

	/**
	 * WP Analytify Pro REST API Demographics Endpoints Class
	 *
	 * @since 1.0.0
	 */
	class WP_Analytify_Pro_REST_Demographics {

		/**
		 * Singleton instance.
		 *
		 * @var WP_Analytify_Pro_REST_Demographics|null $instance The one true WP_Analytify_Pro_REST_Demographics.
		 * @since 1.0.0
		 */
		private static $instance;

		/**
		 * The main Analytify object.
		 *
		 * @var object|null
		 */
		private $wp_analytify;

		/**
		 * GA version (ga4 or ga3).
		 *
		 * @var string
		 */
		private $ga_mode;

		/**
		 * Selected 'start state'.
		 *
		 * @var string
		 */
		private $start_date;

		/**
		 * Selected 'End state'.
		 *
		 * @var string
		 */
		private $end_date;

		/**
		 * Date difference.
		 *
		 * @var string
		 */
		private $date_differ;


		/**
		 * Type parameter.
		 *
		 * @var string
		 */
		private $type;

		/**
		 * Get active instance
		 *
		 * @version 7.0.5
		 * @access public
		 * @since 1.0.0
		 * @return WP_Analytify_Pro_REST_Demographics
		 */
		public static function instance() {
			if ( ! self::$instance ) {
				self::$instance = new WP_Analytify_Pro_REST_Demographics();
				self::$instance->init();
			}
			return self::$instance;
		}

		/**
		 * Initialize the class
		 *
		 * @version 7.0.5
		 * @access private
		 * @since 1.0.0
		 * @return void
		 */
		private function init() {
			// Don't initialize wp_analytify here - it will be set when set_dates is called.
		}

		/**
		 * Set dates for the reports.
		 *
		 * @version 7.0.5
		 * @param string $start_date Start date.
		 * @param string $end_date End date.
		 * @param string $date_differ Date difference.
		 * @param string $type Type parameter.
		 * @param object $wp_analytify The main Analytify object.
		 * @param string $ga_mode GA mode.
		 * @return void
		 */
		public function set_dates( $start_date, $end_date, $date_differ, $type, $wp_analytify = null, $ga_mode = null ) {
			$this->start_date  = $start_date;
			$this->end_date    = $end_date;
			$this->date_differ = $date_differ;
			$this->type        = $type;

			// Set wp_analytify and ga_mode if provided.
			if ( null !== $wp_analytify ) {
				$this->wp_analytify = $wp_analytify;
			}
			if ( null !== $ga_mode ) {
				$this->ga_mode = $ga_mode;
			}
		}

		/**
		 * Endpoint for 'Demographic' dashboard.
		 *
		 * @version 7.0.5
		 * @return array<string, mixed>
		 */
		public function demographics() {

			// API limit.
			$api_limit = apply_filters( 'analytify_api_limit_demographic_stats', 20, 'dashboard' );

			$stats = array();

			if ( 'ga4' === $this->ga_mode && isset( $this->wp_analytify ) && method_exists( $this->wp_analytify, 'get_reports' ) ) {
				$stats_raw = $this->wp_analytify->get_reports(
					'show-demographic-stats',
					array(
						'sessions',
					),
					$this->get_dates(),
					array(
						'userAgeBracket',
						'userGender',
					),
					array(
						'type'  => 'metric',
						'name'  => 'sessions',
						'order' => 'desc',
					),
					array(),
					$api_limit
				);
				if ( isset( $stats_raw['rows'] ) && $stats_raw['rows'] ) {
					foreach ( $stats_raw['rows'] as $row ) {
						$stats[] = array(
							'no'     => null,
							'age'    => $row['userAgeBracket'],
							'gender' => $row['userGender'],
							'views'  => class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' ) ? WPANALYTIFY_Utils::pretty_numbers( $row['sessions'] ) : $row['sessions'],
						);
					}
				}
			}

			return array(
				'success'    => true,
				'headers'    => array(
					'no'     => array(
						'label'    => esc_html__( '#', 'wp-analytify-pro' ),
						'type'     => 'counter',
						'th_class' => 'analytify_num_row',
						'td_class' => 'analytify_txt_center',
					),
					'age'    => array(
						'label'    => esc_html__( 'Age', 'wp-analytify-pro' ),
						'th_class' => 'analytify_txt_left',
						'td_class' => '',
					),
					'gender' => array(
						'label'    => esc_html__( 'Gender', 'wp-analytify-pro' ),
						'th_class' => 'analytify_txt_left',
						'td_class' => '',
					),
					'views'  => array(
						'label'    => esc_html__( 'Total Views', 'wp-analytify-pro' ),
						'th_class' => 'analytify_value_row',
						'td_class' => 'analytify_txt_center',
					),
				),
				'stats'      => $stats,
				'footer'     => apply_filters( 'analytify_demographic_footer', __( 'Demographic Stats.', 'wp-analytify-pro' ), array( $this->start_date, $this->end_date ) ),
				'pagination' => true,
			);
		}

		/**
		 * Format Interest stats rows from a GA4 report payload.
		 *
		 * Shared by the Demographics REST endpoint and CSV export.
		 *
		 * @since 5.2.0
		 * @param array<string, mixed> $stats_raw Raw GA4 report (rows + aggregations).
		 * @return list<array{category: mixed, percent: string}>
		 */
		public static function format_interest_stats_from_report( $stats_raw ) {
			$stats                 = array();
			$total_user_engagement = 0;

			if ( ! is_array( $stats_raw ) ) {
				return $stats;
			}

			if ( isset( $stats_raw['aggregations']['userEngagementDuration'] ) ) {
				$total_user_engagement = (float) $stats_raw['aggregations']['userEngagementDuration'];
			}

			if ( $total_user_engagement > 0 && ! empty( $stats_raw['rows'] ) && is_array( $stats_raw['rows'] ) ) {
				foreach ( $stats_raw['rows'] as $row ) {
					$percent = ( (float) $row['userEngagementDuration'] / $total_user_engagement ) * 100;

					$stats[] = array(
						'category' => $row['brandingInterest'],
						'percent'  => number_format( $percent, 1 ) . '%',
					);
				}
			}

			return $stats;
		}

		/**
		 * Endpoint for Interest stats in 'Demographic' dashboard.
		 *
		 * @return array<string, mixed>
		 */
		public function interests() {

			// API limit (filterable for customization).
			$api_limit = apply_filters( 'analytify_api_limit_interest_stats', 20, 'dashboard' );

			$stats = array();

			if ( 'ga4' === $this->ga_mode && isset( $this->wp_analytify ) && method_exists( $this->wp_analytify, 'get_reports' ) ) {
				// Fetch data from GA4.
				$stats_raw = $this->wp_analytify->get_reports(
					'show-interest-stats',
					array(
						'userEngagementDuration',
					), // Metric to calculate interest.
					$this->get_dates(),
					array(
						'brandingInterest',
					), // Dimension for Interests.
					array(
						'type'  => 'metric',
						'name'  => 'userEngagementDuration',
						'order' => 'desc',
					),
					array(),
					$api_limit
				);

				$stats = self::format_interest_stats_from_report( $stats_raw );
			}

			// Return processed data.
			return array(
				'success'    => true,
				'headers'    => array(
					'category' => array(
						'label'    => esc_html__( 'Category', 'wp-analytify-pro' ),
						'th_class' => 'analytify_txt_left',
						'td_class' => '',
					),
					'percent'  => array(
						'label'    => esc_html__( '% Interest', 'wp-analytify-pro' ),
						'th_class' => 'analytify_value_row',
						'td_class' => 'analytify_txt_center',
					),
				),
				'stats'      => $stats,
				'footer'     => apply_filters( 'analytify_interest_footer', __( 'Interest Stats.', 'wp-analytify-pro' ), array( $this->start_date, $this->end_date ) ),
				'pagination' => true,
			);
		}

		/**
		 * Real Time reporting.
		 *
		 * @since 1.0.0
		 * @version 9.1.0
		 * @return array<string, mixed>
		 */
		public function real_time() {

			$page_prefix = apply_filters( 'analytify_realtime_page_url_prefix', '' );

			switch ( $this->type ) {
				case 'counter':
					$type = 'counter';
					break;
				default:
					$type = 'all';
					break;
			}
			if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === $this->ga_mode ) {

				$headers = array();
				$rows    = array();
				$counter = array(
					'online'  => 0,
					'desktop' => 0,
					'tablet'  => 0,
					'mobile'  => 0,
				);

				// Initialize geo data arrays.
				$countries_data = array();
				$cities_data    = array();

				if ( 'all' === $type ) {
					$headers = array(
						'no'       => array(
							'label'    => esc_html__( '#', 'wp-analytify-pro' ),
							'type'     => 'counter',
							'th_class' => 'analytify_num_row',
							'td_class' => 'analytify_txt_center',
						),
						'page'     => array(
							'label'    => esc_html__( 'Page', 'wp-analytify-pro' ),
							'th_class' => 'analytify_txt_left',
							'td_class' => '',
						),
						'visitors' => array(
							'label'    => esc_html__( 'Visitors', 'wp-analytify-pro' ),
							'th_class' => 'analytify_value_row',
							'td_class' => 'analytify_txt_center',
						),
					);
				}

				// To get unique visitors added a country dimension to differentiate.
				$online_visitors = isset( $this->wp_analytify ) && method_exists( $this->wp_analytify, 'get_real_time_reports' ) ? $this->wp_analytify->get_real_time_reports(
					array(
						'activeUsers',
					),
					array(
						'deviceCategory',
						'country',
					)
				) : array();

				if ( isset( $online_visitors['rows'] ) && $online_visitors['rows'] ) {
					foreach ( $online_visitors['rows'] as $visitors ) {

						// The API returns dimensionValues and metricValues arrays.
						$active_users    = isset( $visitors['metricValues'][0]['value'] )
							? absint( $visitors['metricValues'][0]['value'] )
							: 0;
						$device_category = isset( $visitors['dimensionValues'][0]['value'] )
							? sanitize_key( $visitors['dimensionValues'][0]['value'] )
							: 'unknown';
						$country         = isset( $visitors['dimensionValues'][1]['value'] )
							? sanitize_text_field( $visitors['dimensionValues'][1]['value'] )
							: '';

						$counter['online'] += $active_users;
						switch ( $device_category ) {
							case 'desktop':
								$counter['desktop'] += $active_users;
								break;
							case 'tablet':
								$counter['tablet'] += $active_users;
								break;
							case 'mobile':
								$counter['mobile'] += $active_users;
								break;
							default:
								break;
						}

						// Aggregate country data from same response.
						if ( ! empty( $country ) && $active_users > 0 ) {
							if ( ! isset( $countries_data[ $country ] ) ) {
								$countries_data[ $country ] = 0;
							}
							$countries_data[ $country ] += $active_users;
						}
					}

					// Sort and limit countries.
					if ( ! empty( $countries_data ) ) {
						arsort( $countries_data );
						$countries_data = array_slice( $countries_data, 0, apply_filters( 'analytify_realtime_limit_countries', 10 ), true );
					}
				}

				$raw_stats = isset( $this->wp_analytify ) && method_exists( $this->wp_analytify, 'get_real_time_reports' )
					? $this->wp_analytify->get_real_time_reports(
						array(
							'activeUsers',
						),
						array(
							'unifiedScreenName',
						)
					) : array();

				if ( isset( $raw_stats['rows'] ) && $raw_stats['rows'] ) {
					foreach ( $raw_stats['rows'] as $row ) {
						if ( 'all' === $type ) {
							// FIX: Access the correct data structure.
							$screen_name = isset( $row['dimensionValues'][0]['value'] )
								? sanitize_text_field( $row['dimensionValues'][0]['value'] )
								: '';

							$active_users = isset( $row['metricValues'][0]['value'] )
								? absint( $row['metricValues'][0]['value'] )
								: 0;

							// Only add rows with actual data.
							if ( ! empty( $screen_name ) && $active_users > 0 ) {
								$rows[] = array(
									'no'       => null,
									'page'     => esc_html( $screen_name ),
									'visitors' => method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' )
										? WPANALYTIFY_Utils::pretty_numbers( $active_users )
										: $active_users,
								);
							}
						}
					}
					// Limit pages.
					$rows = array_slice( $rows, 0, apply_filters( 'analytify_realtime_limit_pages', 20 ) );
				}

				// Get cities.
				$cities_stats = isset( $this->wp_analytify ) && method_exists( $this->wp_analytify, 'get_real_time_reports' )
					? $this->wp_analytify->get_real_time_reports(
						array(
							'activeUsers',
						),
						array(
							'city',
							'country',
						)
					) : array();

				if ( isset( $cities_stats['rows'] ) && $cities_stats['rows'] ) {
					$temp_cities = array();
					foreach ( $cities_stats['rows'] as $row ) {
						$city         = isset( $row['dimensionValues'][0]['value'] )
							? sanitize_text_field( $row['dimensionValues'][0]['value'] )
							: '';
						$country      = isset( $row['dimensionValues'][1]['value'] )
							? sanitize_text_field( $row['dimensionValues'][1]['value'] )
							: '';
						$active_users = isset( $row['metricValues'][0]['value'] )
							? absint( $row['metricValues'][0]['value'] )
							: 0;

						if ( ! empty( $city ) && $active_users > 0 ) {
							$city_key = $city . '|' . $country;
							if ( ! isset( $temp_cities[ $city_key ] ) ) {
								$temp_cities[ $city_key ] = 0;
							}
							$temp_cities[ $city_key ] += $active_users;
						}
					}

					arsort( $temp_cities );
					$temp_cities = array_slice( $temp_cities, 0, apply_filters( 'analytify_realtime_limit_cities', 10 ), true );

					foreach ( $temp_cities as $city_key => $visitors ) {
						$parts   = explode( '|', $city_key, 2 );
						$city    = isset( $parts[0] ) ? sanitize_text_field( $parts[0] ) : '';
						$country = isset( $parts[1] ) ? sanitize_text_field( $parts[1] ) : '';

						$cities_data[] = array(
							'city'     => $city,
							'country'  => $country,
							'visitors' => absint( $visitors ),
						);
					}
				}
			} else {

				$headers = array();
				$rows    = array();
				$counter = array(
					'online'    => 0,
					'referral'  => 0,
					'organic'   => 0,
					'social'    => 0,
					'direct'    => 0,
					'new'       => 0,
					'returning' => 0,
				);

				// Initialize geo data arrays.
				$countries_data = array();
				$cities_data    = array();

				$profile_id = '';
				if ( $this->wp_analytify && is_object( $this->wp_analytify ) && isset( $this->wp_analytify->settings ) && method_exists( $this->wp_analytify->settings, 'get_option' ) ) {
					$profile_id = $this->wp_analytify->settings->get_option( 'profile_for_dashboard', 'wp-analytify-profile' );
				}
				try {
					$raw_stats = array();
					if ( is_object( $this->wp_analytify ) && isset( $this->wp_analytify->service ) && isset( $this->wp_analytify->service->data_realtime ) ) {
						$raw_stats = $this->wp_analytify->service->data_realtime->get(
							'ga:' . $profile_id,
							'ga:activeVisitors',
							array(
								'dimensions' => 'ga:pageTitle,ga:pagePath,ga:trafficType,ga:visitorType',
							)
						);
					}
				} catch ( Exception $e ) {
					return array(
						'success'       => false,
						'error_message' => esc_html( sanitize_text_field( $e->getMessage() ) ),
					);
				}

				if ( 'all' === $type ) {
					$headers = array(
						'no'       => array(
							'label'    => esc_html__( '#', 'wp-analytify-pro' ),
							'type'     => 'counter',
							'th_class' => 'analytify_num_row',
							'td_class' => 'analytify_txt_center',
						),
						'page'     => array(
							'label'    => esc_html__( 'Page', 'wp-analytify-pro' ),
							'th_class' => 'analytify_txt_left',
							'td_class' => '',
						),
						'visitors' => array(
							'label'    => esc_html__( 'Visitors', 'wp-analytify-pro' ),
							'th_class' => 'analytify_value_row',
							'td_class' => 'analytify_txt_center',
						),
					);
				}

				if ( isset( $raw_stats['rows'] ) && $raw_stats['rows'] ) {
					foreach ( $raw_stats['rows'] as $row ) {

						switch ( $row[2] ) {
							case 'REFERRAL':
								++$counter['referral'];
								break;
							case 'ORGANIC':
								++$counter['organic'];
								break;
							case 'SOCIAL':
								++$counter['social'];
								break;
							case 'DIRECT':
								++$counter['direct'];
								break;
							default:
								break;
						}

						if ( 'RETURNING' === $row[3] ) {
							++$counter['returning'];
						} elseif ( 'NEW' === $row[3] ) {
							++$counter['new'];
						}

						if ( 'all' === $type ) {
							$rows[] = array(
								'no'       => null,
								'page'     => '<a href="' . $page_prefix . esc_url_raw( $row[1] ) . '" target="_blank">' . esc_html( $row[0] ) . '</a>',
								'visitors' => absint( $row[4] ),
							);
						}
					}

					$rows = array_slice( $rows, 0, apply_filters( 'analytify_realtime_limit_pages', 20 ) );
				}

				if ( isset( $raw_stats['totalsForAllResults']['ga:activeVisitors'] ) ) {
					$counter['online'] = $raw_stats['totalsForAllResults']['ga:activeVisitors'];
				}
			}

			// Format countries for output.
			$formatted_countries = array();
			foreach ( $countries_data as $country => $visitors ) {
				$country      = sanitize_text_field( $country );
				$country_code = method_exists( 'WPANALYTIFY_Utils', 'get_country_flag_code' )
					? sanitize_html_class( WPANALYTIFY_Utils::get_country_flag_code( $country ) )
					: sanitize_html_class( strtolower( str_replace( ' ', '_', $country ) ) );

				$formatted_countries[] = array(
					'country'  => sprintf(
						'<span role="img" aria-label="%s" class="analytify_%s analytify_flages"></span> %s',
						esc_attr( $country ),
						esc_attr( $country_code ),
						esc_html( $country )
					),
					'sessions' => method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' )
						? WPANALYTIFY_Utils::pretty_numbers( absint( $visitors ) )
						: absint( $visitors ),
				);
			}

			// Format cities for output.
			$formatted_cities = array();
			foreach ( $cities_data as $city_data ) {
				$city         = isset( $city_data['city'] ) ? sanitize_text_field( $city_data['city'] ) : '';
				$country      = isset( $city_data['country'] ) ? sanitize_text_field( $city_data['country'] ) : '';
				$visitors     = isset( $city_data['visitors'] ) ? absint( $city_data['visitors'] ) : 0;
				$country_code = method_exists( 'WPANALYTIFY_Utils', 'get_country_flag_code' )
					? sanitize_html_class( WPANALYTIFY_Utils::get_country_flag_code( $country ) )
					: sanitize_html_class( strtolower( str_replace( ' ', '_', $country ) ) );

				$formatted_cities[] = array(
					'city'     => sprintf(
						'<span role="img" aria-label="%s" class="analytify_%s analytify_flages"></span> %s',
						esc_attr( $country ),
						esc_attr( $country_code ),
						esc_html( $city )
					),
					'sessions' => method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' )
						? WPANALYTIFY_Utils::pretty_numbers( $visitors )
						: $visitors,
				);
			}

			// Build response structures.
			$country_response = array(
				'headers' => array(
					'country'  => array(
						'label'    => esc_html__( 'Top Countries', 'wp-analytify-pro' ),
						'th_class' => 'analytify_txt_left analytify_vt_middle',
						'td_class' => '',
					),
					'sessions' => array(
						'label'    => esc_html__( 'Visitors', 'wp-analytify-pro' ),
						'th_class' => 'analytify_value_row',
						'td_class' => 'analytify_txt_center',
					),
				),
				'stats'   => $formatted_countries,
			);

			$city_response = array(
				'headers' => array(
					'city'     => array(
						'label'    => esc_html__( 'Top Cities', 'wp-analytify-pro' ),
						'th_class' => 'analytify_txt_left analytify_vt_middle analytify_brd_lft',
						'td_class' => 'analytify_boder_left',
					),
					'sessions' => array(
						'label'    => esc_html__( 'Visitors', 'wp-analytify-pro' ),
						'th_class' => 'analytify_value_row',
						'td_class' => 'analytify_txt_center',
					),
				),
				'stats'   => $formatted_cities,
			);

			return array(
				'success' => true,
				'title'   => esc_html__( 'Real Time', 'wp-analytify-pro' ),
				'counter' => $counter,
				'headers' => $headers,
				'stats'   => $rows,
				'country' => $country_response,
				'city'    => $city_response,
				'footer'  => esc_html__( 'Top countries and cities.', 'wp-analytify-pro' ),
			);
		}

		/**
		 * Get dates for comparison.
		 *
		 * @return array<string, string>
		 */
		private function get_dates() {
			return array(
				'start' => $this->start_date,
				'end'   => $this->end_date,
			);
		}
	}
}
