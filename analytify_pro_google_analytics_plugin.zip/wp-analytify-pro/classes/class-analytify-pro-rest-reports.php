<?php // phpcs:ignore WordPress.Files.FileName.InvalidClassFileName
/**
 * WP Analytify Pro REST API Reports Class
 *
 * This class handles REST API report generation including:
 * - Ajax error reports
 * - 404 error reports
 * - JavaScript error reports
 * - Compare stats reports
 *
 * @package WP_Analytify_Pro
 * @since 8.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_Analytify_Pro_REST_Reports' ) ) {

	/**
	 * WP Analytify Pro REST API Reports Class
	 *
	 * @since 1.0.0
	 */
	class WP_Analytify_Pro_REST_Reports {

		/**
		 * Singleton instance.
		 *
		 * @var WP_Analytify_Pro_REST_Reports|null $instance The one true WP_Analytify_Pro_REST_Reports.
		 * @since 1.0.0
		 */
		private static $instance;

		/**
		 * The main Analytify object.
		 *
		 * @var object|null
		 */
		private $wp_analytify;

		/**
		 * GA version (ga4 or ga3).
		 *
		 * @var string
		 */
		private $ga_mode;

		/**
		 * Selected 'start state'.
		 *
		 * @var string
		 */
		private $start_date;

		/**
		 * Selected 'End state'.
		 *
		 * @var string
		 */
		private $end_date;

		/**
		 * Date difference.
		 *
		 * @var string
		 */
		private $date_differ;

		/**
		 * Type parameter.
		 *
		 * @var string
		 */
		private $type;


		/**
		 * Get active instance
		 *
		 * @version 7.0.5
		 * @access public
		 * @since 1.0.0
		 * @return WP_Analytify_Pro_REST_Reports
		 */
		public static function instance() {
			if ( ! self::$instance ) {
				self::$instance = new WP_Analytify_Pro_REST_Reports();
				self::$instance->init();
			}
			return self::$instance;
		}

		/**
		 * Initialize the class
		 *
		 * @version 7.0.5
		 * @access private
		 * @since 1.0.0
		 * @return void
		 */
		private function init() {
			// Don't initialize wp_analytify here - it will be set when set_dates is called.
		}

		/**
		 * Set dates for the reports endpoints.
		 *
		 * @version 7.0.5
		 * @param string $start_date Start date.
		 * @param string $end_date End date.
		 * @param string $date_differ Date difference.
		 * @param string $type Type parameter.
		 * @param object $wp_analytify The main Analytify object.
		 * @param string $ga_mode GA mode.
		 * @return void
		 */
		public function set_dates( $start_date, $end_date, $date_differ, $type, $wp_analytify = null, $ga_mode = null ) {
			$this->start_date  = $start_date;
			$this->end_date    = $end_date;
			$this->date_differ = $date_differ;
			$this->type        = $type;

			// Set wp_analytify and ga_mode if provided.
			if ( null !== $wp_analytify ) {
				$this->wp_analytify = $wp_analytify;
			}
			if ( null !== $ga_mode ) {
				$this->ga_mode = $ga_mode;
			}
		}

		/**
		 * Endpoint for 'Top ajax errors'.
		 *
		 * @version 7.0.5
		 * @return array<string, mixed>
		 */
		public function ajax_error() {

			// API limit.
			$api_limit = apply_filters( 'analytify_api_limit_ajax_error_stats', 5, 'dashboard' );

			$stats = array();

			if ( 'ga4' === $this->ga_mode && isset( $this->wp_analytify ) && method_exists( $this->wp_analytify, 'get_reports' ) ) {
				$stats_raw = $this->wp_analytify->get_reports(
					'show-top-ajax-errors',
					array(
						'eventCount',
					),
					$this->get_dates(),
					array(
						'customEvent:wpa_category',
						'customEvent:wpa_label',
					),
					array(
						'type'  => 'metric',
						'name'  => 'eventCount',
						'order' => 'desc',
					),
					array(
						'logic'   => 'AND',
						'filters' => array(
							array(
								'type'       => 'dimension',
								'name'       => 'customEvent:wpa_category',
								'match_type' => 1,
								'value'      => 'Ajax Error',
							),
						),
					),
					$api_limit
				);

				if ( isset( $stats_raw['rows'] ) && ! empty( $stats_raw['rows'] ) ) {
					foreach ( $stats_raw['rows'] as $row ) {
						$stats[] = array(
							'no'   => null,
							'url'  => $row['customEvent:wpa_label'],
							'hits' => class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' ) ? WPANALYTIFY_Utils::pretty_numbers( $row['eventCount'] ) : $row['eventCount'],
						);
					}
				}
			}

			return array(
				'success' => true,
				'headers' => array(
					'no'   => array(
						'label'    => esc_html__( '#', 'wp-analytify-pro' ),
						'type'     => 'counter',
						'th_class' => 'analytify_num_row',
						'td_class' => 'analytify_txt_center',
					),
					'url'  => array(
						'label'    => esc_html__( 'URL', 'wp-analytify-pro' ),
						'th_class' => 'analytify_txt_left',
						'td_class' => '',
					),
					'hits' => array(
						'label'    => esc_html__( 'Hits', 'wp-analytify-pro' ),
						'th_class' => 'analytify_value_row',
						'td_class' => 'analytify_txt_center',
					),
				),
				'stats'   => $stats,
				'footer'  => apply_filters( 'analytify_ajax_error_footer', __( 'Ajax errors.', 'wp-analytify-pro' ), array( $this->start_date, $this->end_date ) ),
			);
		}

		/**
		 * Endpoint for 'Top 404 errors'.
		 *
		 * @version 7.0.5
		 * @return array<string, mixed>
		 */
		public function not_found_error() {

			// API limit.
			$api_limit = apply_filters( 'analytify_api_limit_404_error_stats', 5, 'dashboard' );

			$stats = array();

			if ( 'ga4' === $this->ga_mode && isset( $this->wp_analytify ) && method_exists( $this->wp_analytify, 'get_reports' ) ) {
				$stats_raw = $this->wp_analytify->get_reports(
					'show-top-404-pages',
					array(
						'eventCount',
					),
					$this->get_dates(),
					array(
						'customEvent:wpa_category',
						'customEvent:wpa_label',
					),
					array(
						'type'  => 'metric',
						'name'  => 'eventCount',
						'order' => 'desc',
					),
					array(
						'logic'   => 'AND',
						'filters' => array(
							array(
								'type'       => 'dimension',
								'name'       => 'customEvent:wpa_category',
								'match_type' => 1,
								'value'      => '404 Error',
							),
						),
					),
					$api_limit
				);

				if ( isset( $stats_raw['rows'] ) && ! empty( $stats_raw['rows'] ) ) {
					foreach ( $stats_raw['rows'] as $row ) {
						$stats[] = array(
							'no'   => null,
							'url'  => $row['customEvent:wpa_label'],
							'hits' => class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' ) ? WPANALYTIFY_Utils::pretty_numbers( $row['eventCount'] ) : $row['eventCount'],
						);
					}
				}
			}

			return array(
				'success' => true,
				'headers' => array(
					'no'   => array(
						'label'    => esc_html__( '#', 'wp-analytify-pro' ),
						'type'     => 'counter',
						'th_class' => 'analytify_num_row',
						'td_class' => 'analytify_txt_center',
					),
					'url'  => array(
						'label'    => esc_html__( 'URL', 'wp-analytify-pro' ),
						'th_class' => 'analytify_txt_left',
						'td_class' => '',
					),
					'hits' => array(
						'label'    => esc_html__( 'Hits', 'wp-analytify-pro' ),
						'th_class' => 'analytify_value_row',
						'td_class' => 'analytify_txt_center',
					),
				),
				'stats'   => $stats,
				'footer'  => apply_filters( 'analytify_404_error_footer', __( '404 errors.', 'wp-analytify-pro' ), array( $this->start_date, $this->end_date ) ),
			);
		}

		/**
		 * Endpoint for 'Top JS errors'.
		 *
		 * @version 7.0.5
		 * @return array<string, mixed>
		 */
		public function js_error() {

			// API limit.
			$api_limit = apply_filters( 'analytify_api_limit_js_error_stats', 5, 'dashboard' );

			$stats = array();

			if ( 'ga4' === $this->ga_mode && isset( $this->wp_analytify ) && method_exists( $this->wp_analytify, 'get_reports' ) ) {
				$stats_raw = $this->wp_analytify->get_reports(
					'show-top-js-errors',
					array(
						'eventCount',
					),
					$this->get_dates(),
					array(
						'customEvent:wpa_action',
						'customEvent:wpa_label',
						'customEvent:wpa_category',
					),
					array(
						'type'  => 'metric',
						'name'  => 'eventCount',
						'order' => 'desc',
					),
					array(
						'logic'   => 'AND',
						'filters' => array(
							array(
								'type'       => 'dimension',
								'name'       => 'customEvent:wpa_category',
								'match_type' => 1,
								'value'      => 'JavaScript Error',
							),
						),
					),
					$api_limit
				);

				if ( isset( $stats_raw['rows'] ) && ! empty( $stats_raw['rows'] ) ) {
					foreach ( $stats_raw['rows'] as $row ) {
						$stats[] = array(
							'no'    => null,
							'error' => $row['customEvent:wpa_action'],
							'url'   => $row['customEvent:wpa_label'],
							'hits'  => class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' ) ? WPANALYTIFY_Utils::pretty_numbers( $row['eventCount'] ) : number_format( $row['eventCount'] ),
						);
					}
				}
			}

			return array(
				'success' => true,
				'headers' => array(
					'no'    => array(
						'label'    => esc_html__( '#', 'wp-analytify-pro' ),
						'type'     => 'counter',
						'th_class' => 'analytify_num_row',
						'td_class' => 'analytify_txt_center',
					),
					'error' => array(
						'label'    => esc_html__( 'Error', 'wp-analytify-pro' ),
						'th_class' => 'analytify_txt_left',
						'td_class' => '',
					),
					'url'   => array(
						'label'    => esc_html__( 'URL', 'wp-analytify-pro' ),
						'th_class' => 'analytify_txt_left',
						'td_class' => '',
					),
					'hits'  => array(
						'label'    => esc_html__( 'Hits', 'wp-analytify-pro' ),
						'th_class' => 'analytify_value_row',
						'td_class' => 'analytify_txt_center',
					),
				),
				'stats'   => $stats,
				'footer'  => apply_filters( 'analytify_404_error_footer', __( 'JavaScript errors.', 'wp-analytify-pro' ), array( $this->start_date, $this->end_date ) ),
			);
		}


		/**
		 * Get dates for comparison.
		 *
		 * @version 7.0.5
		 * @return array<string, string>
		 */
		private function get_dates() {
			return array(
				'start' => $this->start_date,
				'end'   => $this->end_date,
			);
		}
	}
}
