<?php
/**
 * Main WP Analytify Pro class file.
 *
 * @package WP_Analytify_Pro
 */

ob_start();

if ( ! class_exists( 'WP_Analytify_Pro' ) ) {

	/**
	 * Main WP_Analytify class
	 *
	 * @since       1.0.0
	 */
	class WP_Analytify_Pro extends WP_Analytify_Pro_Base {

		/**
		 * The one true WP_Analytify_Pro instance.
		 *
		 * @var         WP_Analytify_Pro|null $instance
		 * @since       1.2.2
		 */
		private static $instance;

		/**
		 * Authentication token.
		 *
		 * @var bool|string
		 */
		public $token = false;

		/**
		 * Google Analytics client.
		 *
		 * @var mixed
		 */
		public $client = null;

		/**
		 * Dashboard manager instance
		 *
		 * @var WP_Analytify_Pro_Dashboard_Manager
		 */
		private $dashboard_manager;

		/**
		 * Shortcodes manager instance
		 *
		 * @var WP_Analytify_Pro_Shortcodes_Manager
		 */
		private $shortcodes_manager;

		/**
		 * Frontend manager instance
		 *
		 * @var WP_Analytify_Pro_Frontend_Manager
		 */
		private $frontend_manager;

		/**
		 * Assets manager instance
		 *
		 * @var WP_Analytify_Pro_Assets_Manager
		 */
		private $assets_manager;

		/**
		 * Settings manager instance
		 *
		 * @var WP_Analytify_Pro_Settings_Manager
		 */
		private $settings_manager;

		/**
		 * Utilities manager instance
		 *
		 * @var WP_Analytify_Pro_Utilities_Manager
		 */
		private $utilities_manager;

		/**
		 * Admin manager instance
		 *
		 * @var WP_Analytify_Pro_Admin_Manager
		 */
		private $admin_manager;

		/**
		 * Constructor
		 *
		 * @version 7.0.5
		 * @since 1.0.0
		 */
		public function __construct() {
			parent::__construct();
			$this->init_split_classes();
		}

		/**
		 * Initialize split classes
		 *
		 * @version 7.0.5
		 * @since 1.0.0
		 *
		 * @return void
		 */
		private function init_split_classes() {
			// Include split class files.
			require_once __DIR__ . '/class-analytify-pro-dashboard-manager.php';
			require_once __DIR__ . '/class-analytify-pro-video-tracking-shortcode.php';
			require_once __DIR__ . '/class-analytify-pro-shortcodes.php';
			require_once __DIR__ . '/class-analytify-pro-frontend-manager.php';
			require_once __DIR__ . '/class-analytify-pro-assets-manager.php';
			require_once __DIR__ . '/class-analytify-pro-settings-manager.php';
			require_once __DIR__ . '/class-analytify-pro-utilities-manager.php';
			require_once __DIR__ . '/class-analytify-pro-admin-manager.php';

			// Initialize split class instances.
			$this->dashboard_manager  = new WP_Analytify_Pro_Dashboard_Manager( $this );
			$this->shortcodes_manager = new WP_Analytify_Pro_Shortcodes_Manager( $this );
			$this->frontend_manager   = new WP_Analytify_Pro_Frontend_Manager();
			$this->assets_manager     = new WP_Analytify_Pro_Assets_Manager( $this );
			$this->settings_manager   = new WP_Analytify_Pro_Settings_Manager();
			$this->utilities_manager  = new WP_Analytify_Pro_Utilities_Manager();
			$this->admin_manager      = new WP_Analytify_Pro_Admin_Manager( $this );
		}

		/**
		 * Get active instance
		 *
		 * @access      public
		 * @since       1.2.2
		 * @return      WP_Analytify_Pro The one true WP_Analytify_Pro
		 */
		public static function instance() {
			if ( ! self::$instance ) {
				self::$instance = new WP_Analytify_Pro();
				self::$instance->setup_constants();
				self::$instance->includes();
				self::$instance->load_textdomain();
				self::$instance->hooks();
			}
			return self::$instance;
		}

		/**
		 * Load plugin textdomain
		 *
		 * @access      private
		 * @since       1.2.2
		 * @return      void
		 */
		private function load_textdomain() {
			load_plugin_textdomain( 'wp-analytify-pro', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
		}

		/**
		 * Setup plugin constants
		 *
		 * @access      private
		 * @since       2.0.16
		 * @return      void
		 */
		private function setup_constants() {

			// Setting Global Values.

			$this->define( 'ANALYTIFY_PRO_ID', '10' );
			$this->define( 'ANALYTIFY_STORE_URL', 'https://analytify.io' );
			$this->define( 'ANALYTIFY_PRO_UPGRADE_PATH', defined( 'ANALYTIFY_PRO_ROOT_PATH' ) ? ANALYTIFY_PRO_ROOT_PATH . '/wp-analytify-pro.php' : '' );
		}

		/**
		 * Define constant if not already set
		 *
		 * @since 1.2.4
		 * @param  string      $name  Constant name.
		 * @param  string|bool $value Constant value.
		 *
		 * @return void
		 */
		private function define( $name, $value ) {
			if ( ! defined( $name ) ) {
				define( $name, $value );
			}
		}


		/**
		 * Include necessary files
		 *
		 * @access      private
		 * @since       1.2.2
		 * @return      void
		 */
		private function includes() {

			if ( ! class_exists( 'EDD_SL_Plugin_Updater' ) && defined( 'ANALYTIFY_PRO_ROOT_PATH' ) ) {
				include_once ANALYTIFY_PRO_ROOT_PATH . '/lib/EDD_SL_Plugin_Updater.php';
			}

			$plugin_dir = defined( 'ANALYTIFY_PRO_ROOT_PATH' ) ? ANALYTIFY_PRO_ROOT_PATH : __DIR__ . '/..';
			if ( $plugin_dir ) {
				$files = array(
					$plugin_dir . '/classes/class.upgrade-pro.php',
					$plugin_dir . '/classes/class-analytify-pro-update-routine.php',
					$plugin_dir . '/classes/class-analytify-csv-export.php',
					$plugin_dir . '/classes/analytifypro_ajax.php',
					$plugin_dir . '/classes/class-analytify-pro-blocks.php',
					$plugin_dir . '/classes/class-analytify-pro-helpscout.php',
					$plugin_dir . '/classes/analytify-report-abstract.php',
					$plugin_dir . '/classes/analytify-report-pro.php',
					$plugin_dir . '/classes/class-analytify-pro-rest-api.php',
					$plugin_dir . '/inc/modules/analytify-modules.php',
					$plugin_dir . '/inc/wpa-core-functions.php',
				);

				foreach ( $files as $file ) {
					if ( file_exists( $file ) ) {
						include_once $file;
					}
				}
			}
		}

		/**
		 * Run action and filter hooks
		 *
		 * @access      private
		 * @since       1.2.2
		 * @return      void
		 */
		private function hooks() {

			add_filter(
				'plugin_action_links_' . plugin_basename( __FILE__ ),
				function ( $links ) {
					return $this->utilities_manager->plugin_action_links( $links );
				},
				10,
				1
			);
			add_filter(
				'network_admin_plugin_action_links_' . plugin_basename( __FILE__ ),
				function ( $links ) {
					return $this->utilities_manager->plugin_action_links( $links );
				},
				10,
				1
			);

			add_filter(
				'plugin_row_meta',
				function ( $links, $file ) {
					return $this->utilities_manager->plugin_row_meta( $links, $file );
				},
				10,
				2
			);
			add_action( 'admin_init', array( $this->admin_manager, '_save_version' ) );

			add_action( 'admin_init', array( $this->admin_manager, '_plugin_updater' ), 0 );
			// Ensure HTTP GET remove license handler runs on admin pages.
			add_action( 'admin_init', array( $this->admin_manager, 'http_remove_license' ), 1 );
			// Hook admin notices directly.
			add_action( 'admin_notices', array( $this->admin_manager, '_admin_notices' ) );

			// Initiating ShortCodes.
			add_action( 'admin_head', array( $this->shortcodes_manager, 'analytify_shortcode_button' ) );

			add_filter( 'mce_css', array( $this->assets_manager, 'analytify_mce_css' ) );

			add_shortcode( 'analytify-stats', array( $this->shortcodes_manager, 'analytify_stats_shortcode' ) );

			add_shortcode( 'analytify-worldmap', array( $this->shortcodes_manager, 'analytify_worldmap_shortcode' ) );

			add_shortcode( 'analytify-video-tracking', array( $this->shortcodes_manager, 'analytify_video_tracking_shortcode' ) );

			add_action( 'init', array( $this, 'maybe_schedule_video_tracking_cache_refresh' ) );
			add_action( 'analytify_refresh_video_tracking_cache', array( $this, 'refresh_video_tracking_cache' ) );

			add_action( 'wp_ajax_analytify_advanced_shortcode', array( $this->shortcodes_manager, 'analytify_shortcode_view' ) );

			add_action( 'admin_init', array( $this->admin_manager, 'wp_analytify_register_option' ) );

			add_action( 'admin_enqueue_scripts', array( $this->assets_manager, 'admin_scripts' ) );

			$_disable_front = $GLOBALS['WP_ANALYTIFY']->settings->get_option( 'disable_front_end', '' );
			if ( ! empty( $_disable_front ) && 'off' === $_disable_front ) {

				add_filter( 'the_content', array( $this->frontend_manager, 'get_single_front_analytics' ) );
			}

			add_action( 'wp_ajax_pa_get_online_data', array( $this->dashboard_manager, 'pa_realtime_data_get' ) );

			/*
			*   Grab online visitors for frontend widget
			*/
			add_action( 'wp_ajax_nopriv_pa_get_online_data', array( $this->dashboard_manager, 'pa_realtime_data_get' ) );

			add_action( 'wp_analytify_load_mobile_stats', array( $this->utilities_manager, 'load_mobile_stats' ), 10, 3 );
			add_filter( 'wp_analytify_tabs', array( $this->admin_manager, 'wp_analytify_pro_tabs' ) );
			add_action( 'wp_analytify_license_tab', array( $this->admin_manager, 'license_tab_content' ) );

			add_filter( 'wp_analytify_pro_setting_tabs', array( $this->settings_manager, 'wp_analytify_pro_setting_tabs' ), 10, 1 );
			add_filter( 'wp_analytify_pro_accordion_setting', array( $this->settings_manager, 'wp_analytify_pro_accordion_setting' ), 10, 1 );
			add_filter( 'wp_analytify_pro_setting_fields', array( $this->settings_manager, 'wp_analytify_pro_setting_fields' ), 10, 1 );
					add_action( 'wp_enqueue_scripts', array( $this->assets_manager, 'front_scripts' ) );
			add_action( 'wp_enqueue_scripts', array( $this->assets_manager, 'pa_front_styles' ) );
			add_action( 'wp_analytify_stats_under_post', array( $this->frontend_manager, 'wp_analytify_stats_under_post' ), 10, 4 );
					add_action( 'wp_ajax_wpanalytifypro_activate_license', array( $this->admin_manager, 'ajax_activate_license' ) );
			add_action( 'wp_ajax_wpanalytifypro_check_license', array( $this->admin_manager, 'ajax_check_license' ) );
			add_action( 'wp_ajax_wpanalytifypro_deactivate_license', array( $this->admin_manager, 'analytify_license_deactivate' ) );
			add_action( 'wp_ajax_wpanalytifypro_refresh_debug_log', array( $this->admin_manager, 'ajax_refresh_debug_log' ) );
			add_action( 'anlytify_pro_support_tab', array( $this->admin_manager, 'anlytify_pro_support' ) );
			add_action( 'load-analytify_page_analytify-settings', array( $this->assets_manager, 'load_pro_settings_assets' ) );
			add_filter( 'wpanalytify_data', array( $this->admin_manager, '_wpanalytify_data' ), 10, 1 );
			add_filter( 'free-pro-features', array( $this->admin_manager, 'pro_feature_box' ), 10, 1 );

					add_action( 'wp_analytify_view_miscellaneous_error', array( $this->dashboard_manager, 'load_error_stats' ), 10, 3 );

			add_action( 'wp_analytify_view_real_time_stats', array( $this->dashboard_manager, 'include_realtime_stats' ) );

			/**
			 * Adds section on the Core's dashboard.
			 */
			add_action( 'wp_analytify_view_compare_stats', array( $this->dashboard_manager, 'include_compare_stats' ), 10, 4 );
			add_action( 'wp_analytify_view_ajax_error', array( $this->dashboard_manager, 'template_section_ajax_error' ), 10, 5 );
			add_action( 'wp_analytify_view_404_error', array( $this->dashboard_manager, 'template_section_404_error' ), 10, 5 );
			add_action( 'wp_analytify_view_javascript_error', array( $this->dashboard_manager, 'template_section_javascript_error' ), 10, 5 );

			add_action( 'show_detail_dashboard_content', array( $this->dashboard_manager, 'get_detail_dashboard_content' ) );
			add_action( 'analytify_dashboad_dropdown', array( $this->dashboard_manager, 'dashboad_dropdown' ) );

					add_filter( 'analytify_admin_bar_menu', array( $this->assets_manager, 'add_admin_bar_menu' ), 10, 1 );
			add_action( 'init', array( $this->utilities_manager, 'generate_csv' ) );
					add_action( 'analytify_after_top_page_text', array( $this->utilities_manager, 'top_page_text' ) );
			add_action( 'analytify_after_top_keyword_text', array( $this->utilities_manager, 'top_keyword_text' ) );
			add_action( 'analytify_after_top_social_media_text', array( $this->utilities_manager, 'top_social_media_text' ) );
			add_action( 'analytify_after_top_reffers_text', array( $this->utilities_manager, 'top_reffers_text' ) );
			add_action( 'analytify_after_top_page_stats_text', array( $this->utilities_manager, 'top_page_stats_text' ) );
			add_action( 'analytify_after_top_country_text', array( $this->utilities_manager, 'after_top_country_text' ) );
			add_action( 'analytify_after_top_city_text', array( $this->utilities_manager, 'after_top_city_text' ) );
			add_action( 'analytify_after_top_browser_text', array( $this->utilities_manager, 'after_top_browser_text' ) );
			add_action( 'analytify_after_top_operating_system_text', array( $this->utilities_manager, 'after_top_operating_system_text' ) );
			add_action( 'analytify_after_top_mobile_device_text', array( $this->utilities_manager, 'after_top_mobile_device_text' ) );
					add_action( 'analytify_pro_exclusion_meta_box', array( $this->utilities_manager, 'exclusion_meta_box' ) );
			add_action( 'init', array( $this->utilities_manager, 'register_exclusion_meta_field' ) );
			add_action( 'save_post', array( $this->utilities_manager, 'save_exclusion_meta_field' ) );

			/**
			 * Add section for the single post stats.
			 * Some are add by the core version.
			 * Filter is called in the core version.
			 */
			add_filter( 'analytify_single_post_sections', array( $this->frontend_manager, 'single_post_sections' ), 20, 3 );
		}






		/**
		 * License key getter - delegated to admin manager
		 *
		 * @since 1.0.0
		 * @return string
		 */
		public function get_license_key(): string {
			return $this->admin_manager->get_license_key();
		}

		/**
		 * License status getter - delegated to admin manager
		 *
		 * @since 1.0.0
		 * @return string
		 */
		public function get_license_status(): string {
			return $this->admin_manager->get_license_status();
		}

		/**
		 * License expiry check - delegated to admin manager
		 *
		 * @since 1.0.0
		 * @return bool
		 */
		public function is_license_expired(): bool {
			return $this->admin_manager->is_license_expired();
		}

		/**
		 * Whether updates are allowed for the current license - delegated to admin manager.
		 *
		 * @since 9.1.0
		 * @return bool
		 */
		public function is_license_active_for_updates(): bool {
			return $this->admin_manager->is_license_active_for_updates();
		}

		/**
		 * License status message - delegated to admin manager
		 *
		 * @since 1.0.0
		 * @param bool   $trans   Whether to translate messages.
		 * @param string $context Context for the message.
		 * @return array<string, string>
		 */
		public function get_license_status_message( $trans = false, $context = null ): array {
			return $this->admin_manager->get_license_status_message( $trans, $context );
		}

		/**
		 * Check AJAX referer - delegated to admin manager
		 *
		 * @since 1.0.0
		 * @param string $action Action name.
		 * @return void
		 */
		public function check_ajax_referer( $action ) {
			$this->admin_manager->check_ajax_referer( $action );
		}

		/**
		 * Set post data - delegated to admin manager
		 *
		 * @since 1.0.0
		 * @param array<string, mixed> $key_rules Key rules array.
		 * @param string               $context Context.
		 * @return void
		 */
		public function set_post_data( $key_rules = array(), $context = '' ) {
			$this->admin_manager->set_post_data( $key_rules, $context );
		}

		/**
		 * Set license key - delegated to admin manager
		 *
		 * @since 1.0.0
		 * @param string $key License key.
		 * @return void
		 */
		public function set_license_key( $key ) {
			$this->admin_manager->set_license_key( $key );
		}

		/**
		 * Get formatted masked license - delegated to admin manager
		 *
		 * @since 1.0.0
		 * @param string $key License key.
		 * @return string
		 */
		public function get_formatted_masked_license( $key ) {
			return $this->admin_manager->get_formatted_masked_license( $key );
		}

		/**
		 * Remove expiry transient - delegated to admin manager
		 *
		 * @since 1.0.0
		 * @param mixed $return Unused parameter for compatibility.
		 * @return void
		 */
		public function remove_expiry_transient( $return = null ) { // phpcs:ignore Universal.NamingConventions.NoReservedKeywordParameterNames.returnFound
			$this->admin_manager->remove_expiry_transient();
		}

		/**
		 * Get latest version - delegated to admin manager
		 *
		 * @since 1.0.0
		 * @param string $license License key.
		 * @return string
		 */
		public function get_latest_version( $license ): string {
			return $this->admin_manager->get_latest_version( $license );
		}

		/**
		 * End AJAX - delegated to admin manager
		 *
		 * @since 1.0.0
		 * @param mixed $return Return value to pass through.
		 * @return mixed
		 */
		public function end_ajax( $return = false ) { // phpcs:ignore Universal.NamingConventions.NoReservedKeywordParameterNames.returnFound
			return $this->admin_manager->end_ajax( $return );
		}

		/**
		 * Schedule daily cron to refresh per-post video tracking cache (background, non-blocking).
		 *
		 * @since 9.0.0
		 * @return void
		 */
		public function maybe_schedule_video_tracking_cache_refresh() {
			if ( ! wp_next_scheduled( 'analytify_refresh_video_tracking_cache' ) ) {
				wp_schedule_event( time(), 'daily', 'analytify_refresh_video_tracking_cache' );
			}
		}

		/**
		 * Refresh video tracking cache for posts that use the shortcode. Runs via cron to avoid blocking page loads.
		 *
		 * Uses prepared statement and limits posts per run to avoid timeouts.
		 *
		 * @since 9.0.0
		 * @version 9.0.0
		 * @return void
		 */
		public function refresh_video_tracking_cache() {
			if ( ! class_exists( 'WPANALYTIFY_Utils' ) || ! method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) || 'ga4' !== WPANALYTIFY_Utils::get_ga_mode() ) {
				return;
			}
			$lock_key = '_analytify_video_tracking_refresh_lock';
			if ( get_transient( $lock_key ) ) {
				return;
			}
			set_transient( $lock_key, 1, 5 * MINUTE_IN_SECONDS );

			try {
				global $wpdb;
				$limit = (int) apply_filters( 'analytify_video_tracking_cache_refresh_batch_size', 50 );
				$limit = $limit > 0 ? $limit : 50;
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Cron needs fresh list of posts containing shortcode; no suitable core API for LIKE on post_content.
				$ids = $wpdb->get_col(
					$wpdb->prepare(
						"SELECT ID FROM {$wpdb->posts} WHERE post_status = 'publish' AND post_content LIKE %s LIMIT %d",
						'%analytify-video-tracking%',
						$limit
					)
				);
				if ( ! is_array( $ids ) || empty( $ids ) ) {
					return;
				}
				$end_date   = gmdate( 'Y-m-d' );
				$start_date = gmdate( 'Y-m-d', strtotime( '-30 days' ) );
				foreach ( $ids as $post_id ) {
					$post_id = (int) $post_id;
					if ( $post_id <= 0 ) {
						continue;
					}
					delete_post_meta( $post_id, '_analytify_video_tracking_cache' );
					try {
						$report = new Analytify_Report_Pro(
							array(
								'dashboard_type' => 'single_post',
								'start_date'     => $start_date,
								'end_date'       => $end_date,
								'post_id'        => $post_id,
							)
						);
						$report->get_video_tracking_stats();
					} catch ( Exception $e ) {
						// Keep cron resilient while exposing failures through an extensible hook.
						do_action( 'analytify_video_cache_refresh_error', $post_id, $e->getMessage(), $e );
						continue;
					}
				}
			} finally {
				delete_transient( $lock_key );
			}
		}

		/**
		 * State data property
		 *
		 * @since 1.0.0
		 * @var array<string, mixed>
		 */
		public $state_data = array();

		/**
		 * Transient timeout property
		 *
		 * @since 1.0.0
		 * @var int
		 */
		public $transient_timeout = 3600;
	}
}

/**
 * Accordions settings callback.
 *
 * @param string $accordion_id Accordion ID.
 * @return void
 */
// phpcs:ignore Universal.Files.SeparateFunctionsFromOO.Mixed, Squiz.Commenting.FunctionComment.Missing -- Function required for settings API.
function wp_analytify_tracking_accordion_options( $accordion_id ) {
	?>
	
	<form method="post" action="options.php">
		
		<?php
		settings_fields( $accordion_id );
		$GLOBALS['WP_ANALYTIFY']->settings->do_settings_sections( $accordion_id );
		?>
		
		<div style="padding-left: 10px">
			<?php submit_button(); ?>
		</div>
	</form>
	
	<?php
}

add_action( 'wp_analytify_tracking_accordion_options', 'wp_analytify_tracking_accordion_options' );

ob_end_flush();
