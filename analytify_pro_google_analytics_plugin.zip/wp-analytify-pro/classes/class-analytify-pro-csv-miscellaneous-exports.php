<?php // phpcs:ignore WordPress.Files.FileName.InvalidClassFileName
/**
 * WP Analytify Pro CSV Miscellaneous Exports Class
 *
 * This class handles miscellaneous CSV export functionality including:
 * - Search terms
 * - Demographics
 * - Interests
 * - Author stats
 *
 * @package WP_Analytify_Pro
 * @since 8.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_Analytify_Pro_CSV_Miscellaneous_Exports' ) ) {

	/**
	 * WP Analytify Pro CSV Miscellaneous Exports Class
	 *
	 * @since 1.0.0
	 */
	class WP_Analytify_Pro_CSV_Miscellaneous_Exports {

		/**
		 * The main Analytify object.
		 *
		 * @var object|null
		 */
		private $wp_analytify;

		/**
		 * GA version (ga4 or ga3).
		 *
		 * @var string
		 */
		private $ga_mode;

		/**
		 * Selected 'start state'.
		 *
		 * @var string
		 */
		private $start_date;

		/**
		 * Selected 'End state'.
		 *
		 * @var string
		 */
		private $end_date;

		/**
		 * Set the main Analytify object and dates
		 *
		 * @param object|null $wp_analytify The main Analytify object.
		 * @param string      $ga_mode GA mode.
		 * @param string      $start_date Start date.
		 * @param string      $end_date End date.
		 * @return void
		 */
		public function set_data( $wp_analytify, $ga_mode, $start_date, $end_date ) {
			$this->wp_analytify = $wp_analytify;
			$this->ga_mode      = $ga_mode;
			$this->start_date   = $start_date;
			$this->end_date     = $end_date;
		}

		/**
		 * Search term dashboard.
		 *
		 * @version 9.1.1
		 * @return list<array<int|string, mixed>>
		 */
		public function export_search_terms() {

			// API limit.
			$api_limit = analytify_pro_csv_api_limit( 'analytify_api_limit_search_term_stats', 50 );

			$stats   = array();
			$columns = array();

			if ( 'ga4' === $this->ga_mode ) {

				$columns = array(
					array(
						'0' => esc_html__( 'Search Term', 'wp-analytify-pro' ),
						'1' => esc_html__( 'Total Search', 'wp-analytify-pro' ),
						'2' => esc_html__( 'Search per Session', 'wp-analytify-pro' ),
						'3' => esc_html__( 'Total Users', 'wp-analytify-pro' ),
					),
				);

				$stats_raw = isset( $this->wp_analytify ) && method_exists( $this->wp_analytify, 'get_reports' ) ? $this->wp_analytify->get_reports(
					'show-search-term',
					array(
						'eventCount',
						'sessions',
						'totalUsers',
					),
					$this->get_dates(),
					array(
						'searchTerm',
					),
					array(
						'type'  => 'metric',
						'name'  => 'eventCount',
						'order' => 'desc',
					),
					array(
						'logic'   => 'AND',
						'filters' => array(
							array(
								'type'           => 'dimension',
								'name'           => 'searchTerm',
								'match_type'     => 1,
								'value'          => '',
								'not_expression' => true,
							),
						),
					),
					$api_limit,
					false
				) : array();

				if ( isset( $stats_raw['rows'] ) && $stats_raw['rows'] ) {
					foreach ( $stats_raw['rows'] as $row ) {
						$stats[] = array(
							'term'    => $row['searchTerm'],
							'total'   => $row['eventCount'],
							'session' => $row['sessions'],
							'users'   => $row['totalUsers'],
						);
					}
				}
			}
			return array_merge( $columns, $stats );
		}

		/**
		 * Demographics dashboard.
		 *
		 * @version 9.1.1
		 * @return list<array<int, mixed>>
		 */
		public function export_demographics() {

			// API limit.
			$api_limit = analytify_pro_csv_api_limit( 'analytify_api_limit_demographic_stats', 20 );

			$stats = array();

			if ( 'ga4' === $this->ga_mode && isset( $this->wp_analytify ) && method_exists( $this->wp_analytify, 'get_reports' ) ) {
				$stats_raw = $this->wp_analytify->get_reports(
					'show-demographic-stats',
					array(
						'sessions',
					),
					$this->get_dates(),
					array(
						'userAgeBracket',
						'userGender',
					),
					array(
						'type'  => 'metric',
						'name'  => 'sessions',
						'order' => 'desc',
					),
					array(),
					$api_limit,
					false
				);
				if ( isset( $stats_raw['rows'] ) && $stats_raw['rows'] ) {
					foreach ( $stats_raw['rows'] as $row ) {
						$stats[] = array(
							'0' => $row['userAgeBracket'],
							'1' => $row['userGender'],
							'2' => class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' ) ? WPANALYTIFY_Utils::pretty_numbers( $row['sessions'] ) : $row['sessions'],
						);
					}
				}
			}

			$columns = array(
				array(
					'0' => esc_html__( 'Age', 'wp-analytify-pro' ),
					'1' => esc_html__( 'Gender', 'wp-analytify-pro' ),
					'2' => esc_html__( 'Views', 'wp-analytify-pro' ),
				),
			);
			return array_merge( $columns, $stats );
		}

		/**
		 * Interest Stats in Demographics dashboard.
		 *
		 * @version 9.1.1
		 * @return list<array<int, mixed>>
		 */
		public function export_interests() {

			$api_limit = analytify_pro_csv_api_limit( 'analytify_api_limit_interest_stats', 20 );

			$stats = array();

			if ( 'ga4' === $this->ga_mode && isset( $this->wp_analytify ) && method_exists( $this->wp_analytify, 'get_reports' ) ) {
				$stats_raw = $this->wp_analytify->get_reports(
					'show-interest-stats',
					array(
						'userEngagementDuration',
					), // Metric to calculate interest.
					$this->get_dates(),
					array(
						'brandingInterest',
					), // Dimension for Interests.
					array(
						'type'  => 'metric',
						'name'  => 'userEngagementDuration',
						'order' => 'desc',
					),
					array(),
					$api_limit,
					false
				);

				$formatted_stats = (
					class_exists( 'WP_Analytify_Pro_REST_Demographics' )
					&& method_exists( 'WP_Analytify_Pro_REST_Demographics', 'format_interest_stats_from_report' )
				)
					? WP_Analytify_Pro_REST_Demographics::format_interest_stats_from_report( $stats_raw )
					: array();

				foreach ( $formatted_stats as $row ) {
					$stats[] = array(
						'0' => $row['category'],
						'1' => $row['percent'],
					);
				}
			}

			$columns = array(
				array(
					'0' => esc_html__( 'Category', 'wp-analytify-pro' ),
					'1' => esc_html__( '% Interest', 'wp-analytify-pro' ),
				),
			);

			return array_merge( $columns, $stats );
		}

		/**
		 * Authors dashboard.
		 *
		 * @param int $id Author ID.
		 * @version 9.1.1
		 * @return list<array<int, mixed>>
		 */
		public function export_author_stats( $id ) {

			$id = (int) $id;

			$wp_user = false;
			if ( 0 !== $id ) {
				$wp_user = function_exists( 'get_user_by' ) ? get_user_by( 'id', $id ) : false;
				if ( ! $wp_user ) {
					return array();
				}
			}

			// API limit.
			$api_limit = analytify_pro_csv_api_limit( 'analytify_api_limit_authors_main_dashboard', 50, $id );

			$stats = array();

			if ( 'ga4' === $this->ga_mode && isset( $this->wp_analytify ) && method_exists( $this->wp_analytify, 'get_reports' ) ) {

				$dimension_filters = array();

				if ( 0 !== $id && $wp_user && is_object( $wp_user ) && ! empty( $wp_user->display_name ) ) {
					$dimension_filters[] = array(
						'type'       => 'dimension',
						'name'       => 'customEvent:wpa_author',
						'match_type' => '4',
						'value'      => $wp_user->display_name,
					);
				} else {
					$dimension_filters[] = array(
						'type'           => 'dimension',
						'name'           => 'customEvent:wpa_author',
						'match_type'     => 4,
						'value'          => '(not set)',
						'not_expression' => true,
					);
				}

				$stats_raw = $this->wp_analytify->get_reports(
					'show-authors-stats-' . $id,
					array(
						'sessions',
						'screenPageViews',
						'totalUsers',
						'userEngagementDuration',
						'bounceRate',
					),
					$this->get_dates(),
					array(
						'customEvent:wpa_author',
						'PageTitle',
						'pagePath',
					),
					array(
						'type'  => 'metric',
						'name'  => 'screenPageViews',
						'order' => 'desc',
					),
					array(
						'logic'   => 'AND',
						'filters' => $dimension_filters,
					),
					$api_limit,
					false
				);

				if ( isset( $stats_raw['rows'] ) && $stats_raw['rows'] ) {
					foreach ( $stats_raw['rows'] as $row ) {
						$stats[] = array(
							'0' => $row['customEvent:wpa_author'],
							'1' => $row['PageTitle'],
							'2' => $row['pagePath'],
							'3' => class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' ) ? WPANALYTIFY_Utils::pretty_numbers( $row['sessions'] ) : $row['sessions'],
							'4' => class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' ) ? WPANALYTIFY_Utils::pretty_numbers( $row['screenPageViews'] ) : $row['screenPageViews'],
							'5' => class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' ) ? WPANALYTIFY_Utils::pretty_numbers( $row['totalUsers'] ) : $row['totalUsers'],
							'6' => class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_time' ) ? wp_strip_all_tags( WPANALYTIFY_Utils::pretty_time( $row['userEngagementDuration'] ) ) : $row['userEngagementDuration'],
							'7' => class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' ) ? WPANALYTIFY_Utils::pretty_numbers( $row['bounceRate'] ) . '%' : $row['bounceRate'] . '%',
						);
					}
				}
			}

			$columns = array(
				array(
					'0' => esc_html__( 'Author', 'wp-analytify-pro' ),
					'1' => esc_html__( 'Post Title', 'wp-analytify-pro' ),
					'2' => esc_html__( 'Post Link', 'wp-analytify-pro' ),
					'3' => esc_html__( 'Sessions', 'wp-analytify-pro' ),
					'4' => esc_html__( 'Page Views', 'wp-analytify-pro' ),
					'5' => esc_html__( 'Visitors', 'wp-analytify-pro' ),
					'6' => esc_html__( 'Avg. Time', 'wp-analytify-pro' ),
					'7' => esc_html__( 'Bounce Rate', 'wp-analytify-pro' ),
				),
			);
			return array_merge( $columns, $stats );
		}

		/**
		 * Returns start and end date as an array to be used for GA4's get_reports()
		 *
		 * @return array<string, string>
		 */
		private function get_dates() {
			return array(
				'start' => $this->start_date,
				'end'   => $this->end_date,
			);
		}
	}
}
