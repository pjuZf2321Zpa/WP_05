<?php // phpcs:ignore WordPress.Files.FileName.InvalidClassFileName
/**
 * WP Analytify Pro REST API Core Class
 *
 * This class handles core REST API functionality including:
 * - Endpoint registration and initialization
 * - Permission checking
 * - Request routing and handling
 *
 * @package WP_Analytify_Pro
 * @since 8.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_Analytify_Pro_REST_Core' ) ) {

	/**
	 * WP Analytify Pro REST API Core Class
	 *
	 * @since 1.0.0
	 */
	class WP_Analytify_Pro_REST_Core {

		/**
		 * Singleton instance.
		 *
		 * @var WP_Analytify_Pro_REST_Core $instance The one true WP_Analytify_Pro_REST_Core.
		 * @since 1.0.0
		 */
		private static $instance;

		/**
		 * The main Analytify object.
		 *
		 * @var object|null
		 */
		private $wp_analytify;

		/**
		 * GA version (ga4 or ga3).
		 *
		 * @var string
		 */
		private $ga_mode;

		/**
		 * Get active instance
		 *
		 * @version 7.0.5
		 * @access public
		 * @since 1.0.0
		 * @return object self::$instance The one true WP_Analytify_Pro_REST_Core
		 */
		public static function instance() {
			if ( ! self::$instance ) {
				self::$instance = new WP_Analytify_Pro_REST_Core();
				self::$instance->init();
			}
			return self::$instance;
		}

		/**
		 * Initialize the class
		 *
		 * @version 7.0.5
		 * @access private
		 * @since 1.0.0
		 * @return void
		 */
		private function init() {
			$this->hooks();
		}

		/**
		 * Run action and filter hooks
		 *
		 * @access private
		 * @since 1.0.0
		 * @return void
		 */
		private function hooks() {
			// Register API endpoints.
			add_action( 'rest_api_init', array( $this, 'rest_api_init' ) );
		}

		/**
		 * Register end point.
		 *
		 * @return void
		 */
		public function rest_api_init() {
			if ( isset( $GLOBALS['WP_ANALYTIFY'] ) ) {
				$this->wp_analytify = $GLOBALS['WP_ANALYTIFY'];
			} else {
				$this->wp_analytify = null;
			}

			$this->ga_mode = class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) ? WPANALYTIFY_Utils::get_ga_mode() : 'ga3';
		}

		/**
		 * Checks access permission.
		 * Checks if the user is logged-in and checks of the user role has access.
		 *
		 * @return boolean
		 */
		public function permission_check() {
			if ( ! $this->wp_analytify || ! is_object( $this->wp_analytify ) || ! isset( $this->wp_analytify->settings ) || ! method_exists( $this->wp_analytify->settings, 'get_option' ) ) {
				return false;
			}

			$is_access_level = array( 'Administrator' );
			if ( $this->wp_analytify && is_object( $this->wp_analytify ) && isset( $this->wp_analytify->settings ) && method_exists( $this->wp_analytify->settings, 'get_option' ) ) {
				$is_access_level = $this->wp_analytify->settings->get_option( 'show_analytics_roles_dashboard', 'wp-analytify-dashboard', array( 'Administrator' ) );
			}

			if ( ! method_exists( $this->wp_analytify, 'pa_check_roles' ) ) {
				return false;
			}

			return (bool) $this->wp_analytify->pa_check_roles( $is_access_level );
		}

		/**
		 * Get GA mode.
		 *
		 * @return string
		 */
		public function get_ga_mode() {
			return $this->ga_mode;
		}

		/**
		 * Get main Analytify object.
		 *
		 * @return object|null
		 */
		public function get_wp_analytify() {
			return $this->wp_analytify;
		}
	}
}
