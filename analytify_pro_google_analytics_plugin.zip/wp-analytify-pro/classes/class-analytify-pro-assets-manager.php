<?php // phpcs:ignore WordPress.Files.FileName.InvalidClassFileName
/**
 * WP Analytify Pro Assets Manager Class
 *
 * @package WP_Analytify_Pro
 * @since 8.0.0
 * @version 9.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_Analytify_Pro_Assets_Manager' ) ) {

	/**
	 * WP Analytify Pro Assets Manager Class
	 *
	 * @since 1.0.0
	 */
	class WP_Analytify_Pro_Assets_Manager {

		/**
		 * Parent class reference.
		 *
		 * @var mixed
		 */
		private $parent;

		/**
		 * Constructor.
		 *
		 * @since 1.0.0
		 * @param mixed $parent Parent class reference.
		 */
		public function __construct( $parent ) { // phpcs:ignore Universal.NamingConventions.NoReservedKeywordParameterNames.parentFound
			$this->parent = $parent;
			add_filter( 'admin_body_class', array( $this, 'admin_body_class' ) );
		}

		/**
		 * Add body class when Pro is active so table sort UI matches sorting script.
		 *
		 * @param string $classes Admin body classes.
		 * @return string
		 */
		public function admin_body_class( $classes ) {
			$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;

			if ( ! $screen ) {
				return $classes;
			}

			if ( false !== strpos( $screen->id, 'analytify' ) || false !== strpos( $screen->base, 'analytify' ) ) {
				$classes .= ' wp-analytify-pro-active';
			}

			return $classes;
		}

		/**
		 * Admin scripts
		 *
		 * @since 1.0.0
		 * @version 9.1.1
		 * @param string $page Page.
		 * @return void
		 */
		public function admin_scripts( $page ) {
			$suffix = analytify_pro_get_asset_suffix();

			// Define Analytify-related pages (core screens plus integration submenus registered with the same hook prefix, e.g. WooCommerce and EDD dashboards).
			$analytify_pages = array(
				'toplevel_page_analytify-dashboard',
				'analytify_page_analytify-settings',
				'analytify_page_analytify-events',
				'analytify_page_analytify-dimensions',
				'analytify_page_analytify-authors',
				'analytify_page_analytify-forms',
				'analytify_page_analytify-enhanced-tel-tracking',
				'analytify_page_analytify-lifterlms',
				'analytify_page_analytify-woocommerce',
				'analytify_page_analytify-goals',
				'analytify_page_analytify-campaigns',
				'analytify_page_analytify-learndash',
				'analytify_page_analytify-pmpro',
				'analytify_page_edd-dashboard',
			);

			// Only enqueue scripts on Analytify-related pages.
			if ( ! in_array( $page, $analytify_pages, true ) ) {
				return;
			}

			// Define dashboard pages.
			// Campaigns uses its own assets (class-campaigns.php); keep it off this list so
			// wp-analytify-main-addons does not collide on analytify_campaigns localization.
			$analytify_pro_dashboard = array( 'toplevel_page_analytify-dashboard', 'analytify_page_analytify-events', 'analytify_page_analytify-dimensions', 'analytify_page_analytify-authors', 'analytify_page_analytify-forms', 'analytify_page_analytify-woocommerce', 'analytify_page_edd-dashboard' );

			// Enqueue jquery-ui-tooltip only on dashboard pages where comp-chart.js is used.
			if ( in_array( $page, $analytify_pro_dashboard, true ) ) {
				wp_enqueue_script( 'jquery-ui-tooltip' );
			}

			// wp-analytify-pro.js: license UI on Settings, and CSV export click handler + Analytify export URL/nonce on dashboards.
			// Audience (core) overview previously never loaded this file, so CSV buttons did nothing. Forms use stats-forms.js instead — do not load both there.
			$analytify_pro_export_pages = array(
				'toplevel_page_analytify-dashboard',
				'analytify_page_analytify-events',
				'analytify_page_analytify-dimensions',
				'analytify_page_analytify-woocommerce',
				'analytify_page_analytify-enhanced-tel-tracking',
				'analytify_page_edd-dashboard',
				'analytify_page_analytify-authors',
			);
			$load_wp_analytify_pro_js   = ( 'analytify_page_analytify-settings' === $page || in_array( $page, $analytify_pro_export_pages, true ) );
			if ( $load_wp_analytify_pro_js ) {
				wp_enqueue_script(
					'wp-analytify-pro',
					plugins_url( "assets/js/wp-analytify-pro{$suffix}.js", __DIR__ ),
					array( 'jquery', 'moment' ),
					defined( 'ANALYTIFY_PRO_VERSION' ) ? ANALYTIFY_PRO_VERSION : '1.0.0',
					true
				);
				wp_localize_script(
					'wp-analytify-pro',
					'Analytify',
					array(
						'ajaxurl'         => admin_url( 'admin-ajax.php' ),
						'exportUrl'       => esc_url_raw( add_query_arg( array( 'action' => 'analytify_export' ), admin_url( 'admin-ajax.php' ) ) ),
						'export_nonce'    => wp_create_nonce( 'analytify_export_nonce' ),
						'licenseStatus'   => __( 'License Status:', 'wp-analytify-pro' ),
						'activationsLeft' => __( 'Activations Left:', 'wp-analytify-pro' ),
						'licenseLimit'    => __( 'License limit:', 'wp-analytify-pro' ),
						'expirationDate'  => __( 'Expiration Date:', 'wp-analytify-pro' ),
					)
				);
			}

			// Enqueue table sorting script on all admin pages as it may be needed by various modules.
			wp_enqueue_script( 'analytify-table-sorting', plugins_url( "assets/js/analytify-table-sorting{$suffix}.js", __DIR__ ), array( 'jquery' ), defined( 'ANALYTIFY_PRO_VERSION' ) ? ANALYTIFY_PRO_VERSION : '1.0.0', true );

			// Enqueue main-addons on Pro dashboard screens (campaigns, authors, dimensions, etc.).
			// Forms Tracking uses stats-forms.js only; main.min.js duplicates that logic and caused twin blocks.
			$pages_needing_main_addons = array_values(
				array_diff(
					array_merge( (array) $analytify_pro_dashboard, array( 'analytify_page_analytify-authors' ) ),
					array( 'analytify_page_analytify-forms' )
				)
			);
			if ( in_array( $page, $pages_needing_main_addons, true ) ) {
				wp_enqueue_script( 'wp-analytify-main-addons', plugins_url( 'assets/js/main.min.js', __DIR__ ), array(), defined( 'ANALYTIFY_PRO_VERSION' ) ? ANALYTIFY_PRO_VERSION : '1.0.0', true );
				// Set JS dimensions object.
				if ( class_exists( 'Analytify_Dimensions_Tracking' ) && class_exists( 'Analytify_Google_Dimensions' ) ) {
					$required_dimensions = Analytify_Google_Dimensions::get_current_dimensions();
					wp_add_inline_script( 'wp-analytify-main-addons', 'var wpAnalytifyDimensionOptions = ' . wp_json_encode( $required_dimensions ) . ';', 'before' );
				} else {
					wp_add_inline_script( 'wp-analytify-main-addons', 'var wpAnalytifyDimensionOptions = {};', 'before' );
				}

				// analytify_campaigns is localized by the Campaigns module script handle only
				// (avoids double-JSON-encoding resturl and overwriting the module localize).

				$author_report_url = defined( 'ANALYTIFY_AUTHOR_REPORT_REST_URL_PATH' ) ? ANALYTIFY_AUTHOR_REPORT_REST_URL_PATH : 'wp-analytify/v1/get_author_report/';
				wp_localize_script(
					'wp-analytify-main-addons',
					'analytify_stats_authors',
					array(
						'url'              => esc_url_raw( rest_url( $author_report_url ) ),
						'nonce'            => wp_create_nonce( 'wp_rest' ),
						'delimiter'        => class_exists( 'WPANALYTIFY_Utils' ) && is_callable( array( 'WPANALYTIFY_Utils', 'get_delimiter' ) ) ? WPANALYTIFY_Utils::get_delimiter() : '?',
						'load_via_ajax'    => true,
						'no_stats_message' => __( 'No activity during this period.', 'wp-analytify-pro' ),
						'error_message'    => __( 'Something went wrong. Please try again.', 'wp-analytify-pro' ),
					),
				);

				wp_localize_script(
					'wp-analytify-main-addons',
					'FORMS_TRACKING_OBJECT',
					array(
						'property_tracking_mode'    => class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) ? WPANALYTIFY_Utils::get_ga_mode( 'profile_for_posts' ) : 'ga3',
						'ANALYTIFY_TRACKING_MODE'   => ANALYTIFY_TRACKING_MODE,
						'ANALYTIFY_FORMS_ADDON_CUSTOM_FORM_CLASS' => ANALYTIFY_FORMS_ADDON_CUSTOM_FORM_CLASS,
						'custom_form'               => $GLOBALS['WP_ANALYTIFY']->settings->get_option( 'custom_form', 'wp-analytify-forms' ),
						'track_cf7'                 => $GLOBALS['WP_ANALYTIFY']->settings->get_option( 'track_cf7', 'wp-analytify-forms' ),
						'track_wpforms'             => $GLOBALS['WP_ANALYTIFY']->settings->get_option( 'track_wpforms', 'wp-analytify-forms' ),
						'track_gravityforms'        => $GLOBALS['WP_ANALYTIFY']->settings->get_option( 'track_gravityforms', 'wp-analytify-forms' ),
						'track_formidable'          => $GLOBALS['WP_ANALYTIFY']->settings->get_option( 'track_formidable', 'wp-analytify-forms' ),
						'track_ninjaforms'          => $GLOBALS['WP_ANALYTIFY']->settings->get_option( 'track_ninjaforms', 'wp-analytify-forms' ),
						'track_fluentforms'         => $GLOBALS['WP_ANALYTIFY']->settings->get_option( 'track_fluentforms', 'wp-analytify-forms' ),
						'track_happyforms'          => $GLOBALS['WP_ANALYTIFY']->settings->get_option( 'track_happyforms', 'wp-analytify-forms' ),
						'track_forminator'          => $GLOBALS['WP_ANALYTIFY']->settings->get_option( 'track_forminator', 'wp-analytify-forms' ),
						'track_givewp'              => $GLOBALS['WP_ANALYTIFY']->settings->get_option( 'track_givewp', 'wp-analytify-forms' ),
						'track_weforms'             => $GLOBALS['WP_ANALYTIFY']->settings->get_option( 'track_weforms', 'wp-analytify-forms' ),
						'track_elementor'           => $GLOBALS['WP_ANALYTIFY']->settings->get_option( 'track_elementor', 'wp-analytify-forms' ),
						'track_hubspot'             => $GLOBALS['WP_ANALYTIFY']->settings->get_option( 'track_hubspot', 'wp-analytify-forms' ),
						'track_jotform'             => $GLOBALS['WP_ANALYTIFY']->settings->get_option( 'track_jotform', 'wp-analytify-forms' ),
						'track_mailpoet'            => $GLOBALS['WP_ANALYTIFY']->settings->get_option( 'track_mailpoet', 'wp-analytify-forms' ),
						'track_wsforms'             => $GLOBALS['WP_ANALYTIFY']->settings->get_option( 'track_wsforms', 'wp-analytify-forms' ),
						'custom_form_default_label' => esc_html__( 'Custom Form on', 'wp-analytify-pro' ),
					)
				);

				wp_localize_script(
					'wp-analytify-main-addons',
					'analytify_stats_forms',
					array(
						'url'              => esc_url_raw( rest_url( 'wp-analytify/v1/get_forms_report/' ) ),
						'delimiter'        => class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_delimiter' ) ? WPANALYTIFY_Utils::get_delimiter() : '?',
						'nonce'            => wp_create_nonce( 'wp_rest' ),
						'load_via_ajax'    => true,
						'no_stats_message' => esc_html__( 'No activity during this period.', 'wp-analytify-pro' ),
						'error_message'    => esc_html__( 'Something went wrong. Please try again.', 'wp-analytify-pro' ),
					)
				);

				wp_localize_script(
					'wp-analytify-main-addons',
					'analytify_events_tracking',
					array(
						'ajaxurl'            => admin_url( 'admin-ajax.php' ),
						'tracking_mode'      => ANALYTIFY_TRACKING_MODE,
						'ga_mode'            => method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) ? WPANALYTIFY_Utils::get_ga_mode() : 'ga3',
						'tracking_code'      => WP_ANALYTIFY_FUNCTIONS::get_UA_code(),
						'is_track_user'      => analytify_is_track_user(),
						'root_domain'        => ( $this->parent && is_object( $this->parent ) && method_exists( $this->parent, 'get_root_domain' ) ) ? $this->parent->get_root_domain() : '',
						'affiliate_link'     => $GLOBALS['WP_ANALYTIFY']->settings->get_option( 'affiliate_link_path', 'wp-analytify-events-tracking', '' ),
						'download_extension' => $GLOBALS['WP_ANALYTIFY']->settings->get_option( 'file_extension', 'wp-analytify-events-tracking', 'zip|mp3*|mpe*g|pdf|docx*|pptx*|xlsx*|rar*' ),
						'anchor_tracking'    => $GLOBALS['WP_ANALYTIFY']->settings->get_option( 'anchor_tracking', 'wp-analytify-events-tracking' ),
					)
				);

				wp_localize_script(
					'wp-analytify-main-addons',
					'analytify_dimension',
					array(
						'reporting_mode' => method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) ? WPANALYTIFY_Utils::get_ga_mode() : 'ga3',
					)
				);
			}

			/**
			 * Pro report pages that need stats-pro.js, dashboard CSS, and REST-driven charts (includes WooCommerce & EDD dashboards).
			 */
			$analytify_pro_reports_pages = array(
				'toplevel_page_analytify-dashboard',
				'analytify_page_analytify-events',
				'analytify_page_analytify-dimensions',
				'analytify_page_analytify-woocommerce',
				'analytify_page_analytify-enhanced-tel-tracking',
				'analytify_page_edd-dashboard',
			);

			if ( in_array( $page, $analytify_pro_reports_pages, true ) ) {

				/**
				 * Tells the script to load the data via an ajax request on date change.
				 * Only load data via ajax if the Core version is 6.1.0 or higher.
				 */
				$analytify_core_dashboard_pages = array(
					'toplevel_page_analytify-dashboard',
					'analytify_page_analytify-events',
					'analytify_page_analytify-dimensions',
				);
				$load_via_ajax                  = true;
				if ( ! in_array( $page, $analytify_core_dashboard_pages, true ) && defined( 'ANALYTIFY_VERSION' ) && version_compare( ANALYTIFY_VERSION, '6.1.0', '<' ) ) {
					$load_via_ajax = false;
				}

				$localize_stats_pro = array(
					'url'                      => esc_url_raw( rest_url( 'wp-analytify/v1/get_pro_report/' ) ),
					'delimiter'                => class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_delimiter' ) ? WPANALYTIFY_Utils::get_delimiter() : '?',
					'nonce'                    => wp_create_nonce( 'wp_rest' ),
					'load_via_ajax'            => $load_via_ajax,
					'dist_js_url'              => plugins_url( 'wp-analytify/assets/js/', dirname( __DIR__ ) ),
					'no_stats_message'         => esc_html__( 'No activity during this period.', 'wp-analytify-pro' ),
					'no_results_message'       => esc_html__( 'No results found.', 'wp-analytify-pro' ),
					'no_cities_message'        => esc_html__( 'No city data available.', 'wp-analytify-pro' ),
					'no_countries_message'     => esc_html__( 'No country data available.', 'wp-analytify-pro' ),
					'error_message'            => esc_html__( 'Something went wrong. Please try again.', 'wp-analytify-pro' ),
					'unexpected_error_message' => esc_html__( 'Something Unexpected Occurred.', 'wp-analytify-pro' ),
					'realtime_dashboard'       => false,
				);

				$localize_data_comp_chart = array(

					'graph_type' => apply_filters( 'analytify_comp_chart_graph', 'line' ),

				);

				if ( isset( $_GET['show'] ) && 'detail-realtime' === sanitize_text_field( wp_unslash( $_GET['show'] ) ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
					$localize_stats_pro['realtime_dashboard']   = true;
					$localize_stats_pro['no_realtime_message']  = esc_html__( 'No activity at this time.', 'wp-analytify-pro' );
					$localize_stats_pro['realtime_chart_label'] = esc_html__( 'Real Time', 'wp-analytify-pro' );
					$localize_stats_pro['realtime_chart_color'] = apply_filters( 'analytify_realtime_chart_color', '#03a1f8' );
				}

				if ( isset( $_GET['show'] ) && 'page-speed' === sanitize_text_field( wp_unslash( $_GET['show'] ) ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
					$localize_stats_pro['page_speed']           = true;
					$localize_stats_pro['no_pagespeed_message'] = esc_html__( 'No activity at this time.', 'wp-analytify-pro' );
				// phpcs:disable Squiz.PHP.CommentedOutCode.Found
					// $localize_stats_pro['realtime_chart_label'] = esc_html__( 'Real Time', 'wp-analytify-pro' );
					// $localize_stats_pro['realtime_chart_color'] = apply_filters( 'analytify_realtime_chart_color', '#03a1f8' );
				// phpcs:enable Squiz.PHP.CommentedOutCode.Found
				}

				wp_enqueue_style( 'analytify-dashboard-pro', plugins_url( "assets/css/common-dashboard{$suffix}.css", __DIR__ ), array(), ANALYTIFY_PRO_VERSION );
				wp_enqueue_script( 'analytify-stats-pro', plugins_url( "assets/js/stats-pro{$suffix}.js", __DIR__ ), array( 'jquery' ), ANALYTIFY_PRO_VERSION, true );

				if ( isset( $_GET['page'] ) && ! isset( $_GET['show'] ) && 'analytify-dashboard' === sanitize_text_field( wp_unslash( $_GET['page'] ) ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended

					wp_enqueue_script( 'analytify-comp-chart', plugins_url( "assets/js/comp-chart{$suffix}.js", __DIR__ ), array( 'jquery' ), ANALYTIFY_PRO_VERSION, true );
					wp_localize_script( 'analytify-comp-chart', 'analytify_comp_chart_data', $localize_data_comp_chart );

				}
				wp_localize_script( 'analytify-stats-pro', 'analytify_stats_pro', $localize_stats_pro );
			}
		}

		/**
		 * Front scripts
		 *
		 * @since 1.0.0
		 * @param string $page Page.
		 * @return void
		 */
		public function front_scripts( $page ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found
			// Google Map Api.
			wp_register_script( 'jsapi', 'https://www.google.com/jsapi', array(), ANALYTIFY_PRO_VERSION, true ); // phpcs:ignore WordPress.WP.EnqueuedResourceParameters.MissingVersion

			if ( 'off' === $GLOBALS['WP_ANALYTIFY']->settings->get_option( 'disable_front_end', '' ) ) {

				wp_enqueue_script( 'jquery' );
				wp_enqueue_script( 'analytify-script', plugins_url( 'assets/js/script' . analytify_pro_get_asset_suffix() . '.js', __DIR__ ), array( 'jquery' ), ANALYTIFY_PRO_VERSION, true );
				wp_localize_script(
					'analytify-script',
					'ajax_object',
					array( 'ajax_url' => admin_url( 'admin-ajax.php' ) )
				);

			}
		}

		/**
		 * Front styles
		 *
		 * @since 1.0.0
		 * @param string $page Page.
		 * @return void
		 */
		public function pa_front_styles( $page ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found
			if ( 'off' === $GLOBALS['WP_ANALYTIFY']->settings->get_option( 'disable_front_end', '' ) ) {
				wp_enqueue_style( 'front-end-style', plugins_url( 'assets/css/frontend_styles' . analytify_pro_get_asset_suffix() . '.css', __DIR__ ), array(), ANALYTIFY_PRO_VERSION );

			}
		}

		/**
		 * Load pro settings assets
		 *
		 * @since 1.0.0
		 * @param string $page Page.
		 * @return void
		 */
		public function load_pro_settings_assets( $page ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found
			// Assets will be enqueued here when needed.
		}

		/**
		 * Add MCE CSS
		 *
		 * @since 1.0.0
		 * @param string $mce_css MCE CSS string.
		 * @return string
		 */
		public function analytify_mce_css( $mce_css ) {
			if ( ! empty( $mce_css ) ) {
				$mce_css .= ',';
			}
			// This CSS file doesn't exist yet, so we'll comment it out to prevent 404 errors.
		// phpcs:ignore Squiz.Commenting.InlineComment.InvalidEndChar, Squiz.PHP.CommentedOutCode.Found -- Commented code: $mce_css .= plugins_url( 'assets/css/mce-style.css', dirname( __FILE__ ) ).
			return $mce_css;
		}

		/**
		 * Add option in admin bar.
		 *
		 * @param array<string, string> $menus Menu items.
		 *
		 * @since 2.0.9
		 */
		public function add_admin_bar_menu( array $menus ): array {

			$menus['analytify-dashboard&show=detail-realtime']       = __( 'Real Time', 'wp-analytify-pro' );
			$menus['analytify-dashboard&show=page-speed']            = __( 'Page Speed', 'wp-analytify-pro' );
			$menus['analytify-dashboard&show=search-terms']          = __( 'Search Terms', 'wp-analytify-pro' );
			$menus['analytify-dashboard&show=detail-demographic']    = __( 'Demographics', 'wp-analytify-pro' );
			$menus['analytify-dashboard&show=search-console-report'] = __( 'Search Console', 'wp-analytify-pro' );

			return $menus;
		}
	}
}
