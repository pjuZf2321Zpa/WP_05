<?php // phpcs:ignore WordPress.Files.FileName.InvalidClassFileName
/**
 * WP Analytify Pro License Manager Class
 *
 * This class handles core license management functionality including:
 * - License key masking and formatting
 * - Core license status checking
 * - License expiration validation
 *
 * @package WP_Analytify_Pro
 * @since 8.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_Analytify_Pro_License_Manager' ) ) {

	/**
	 * WP Analytify Pro License Manager Class
	 *
	 * @since 1.0.0
	 */
	class WP_Analytify_Pro_License_Manager {

		/**
		 * Singleton instance.
		 *
		 * @var WP_Analytify_Pro_License_Manager $instance The one true WP_Analytify_Pro_License_Manager.
		 * @since 1.0.0
		 */
		private static $instance;

		/**
		 * Get active instance.
		 *
		 * @access public
		 * @since 1.0.0
		 * @return WP_Analytify_Pro_License_Manager The one true WP_Analytify_Pro_License_Manager.
		 */
		public static function instance() {
			if ( ! self::$instance ) {
				self::$instance = new WP_Analytify_Pro_License_Manager();
				self::$instance->init();
			}
			return self::$instance;
		}

		/**
		 * Initialize the class
		 *
		 * @access private
		 * @since 1.0.0
		 * @return void
		 */
		private function init() {
			$this->hooks();
		}

		/**
		 * Run action and filter hooks
		 *
		 * @access private
		 * @since 1.0.0
		 * @return void
		 */
		private function hooks() {
			// Add hooks for license management if needed.
		}

		/**
		 * Mask license key for display
		 *
		 * @param string $key License key to mask.
		 * @return string Masked license key.
		 * @since 1.0.0
		 */
		public function mask_license( $key ) {
			$license_parts  = str_split( $key, 4 );
			$i              = count( $license_parts ) - 1;
			$masked_license = '';

			foreach ( $license_parts as $license_part ) {
				if ( 0 === $i ) {
					$masked_license .= $license_part;
					continue;
				}

				$masked_license .= '<span class="bull">';
				$masked_license .= str_repeat( '&bull;', strlen( $license_part ) ) . '</span>&ndash;';
				--$i;
			}

			return $masked_license;
		}

		/**
		 * Get formatted masked license.
		 *
		 * @param string $key License key.
		 * @return string Formatted license HTML.
		 * @since 1.0.0
		 */
		public function get_formatted_masked_license( $key ) {
			return sprintf(
				'<p class="masked-license">%s <a href="%s">%s</a></p>',
				$this->mask_license( $key ),
				admin_url( 'admin.php?page=analytify-settings&nonce=' . wp_create_nonce( 'wpanalytify-remove-license' ) . '&wpanalytify-remove-license=1' ),
				_x( 'Remove', 'Delete license', 'wp-analytify-pro' )
			);
		}

		/**
		 * Check if license is expired
		 *
		 * @param string $license License key.
		 * @return bool True if expired.
		 * @since 1.0.0
		 */
		public function is_license_expired( $license ) {
			if ( ! $license ) {
				return false;
			}

			$response = get_site_transient( 'wp_analytify_check_license_expiration' );

			if ( false === $response || empty( $response ) ) {
				$response = $this->wp_analytify_api_call( 'check_license', $license, defined( 'ANALYTIFY_PRO_ID' ) ? ANALYTIFY_PRO_ID : 0, defined( 'ANALYTIFY_STORE_URL' ) ? ANALYTIFY_STORE_URL : '' );
				set_site_transient( 'wp_analytify_check_license_expiration', $response, 60 * 60 * 48 );
			}

			if ( is_object( $response ) && isset( $response->license ) && 'expired' === $response->license ) {
				return true;
			}

			return false;
		}

		/**
		 * Check if license is defined as constant
		 *
		 * @return bool True if constant defined
		 * @since 1.0.0
		 */
		public function is_license_constant() {
			return defined( 'WPANALYTIFY_LICENSE' );
		}

		/**
		 * Get license key (from constant or option)
		 *
		 * @return string|false License key or false
		 * @since 1.0.0
		 */
		public function get_license_key() {
			$license = trim( get_option( 'analytify_license_key' ) );
			return $this->is_license_constant() && defined( 'WPANALYTIFY_LICENSE' ) ? WPANALYTIFY_LICENSE : $license;
		}

		/**
		 * Get license status
		 *
		 * @return string|false License status or false
		 * @since 1.0.0
		 */
		public function get_license_status() {
			$status = get_option( 'analytify_license_status' ) ? trim( get_option( 'analytify_license_status' ) ) : false;
			return $status;
		}

		/**
		 * Set license key in settings
		 *
		 * @param string               $key License key.
		 * @param array<string, mixed> $load_settings Current settings array.
		 * @return void
		 * @since 1.0.0
		 */
		public function set_license_key( $key, &$load_settings ) {
			$load_settings['license'] = $key;
			update_site_option( 'wpanalytify_settings', $load_settings );
		}

		/**
		 * Check if update is available
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public function is_update_available() {
			$installed_version = defined( 'ANALYTIFY_VERSION' ) ? ANALYTIFY_VERSION : '0';

			$latest_version = get_site_transient( 'wp_analytify_check_latest_version' );

			if ( false === $latest_version ) {
				// Use user's license key if available, otherwise use empty string for version check.
				$license_key    = $this->get_license_key();
				$latest_version = $this->get_latest_version( $license_key ? $license_key : '' );
				set_site_transient( 'wp_analytify_check_latest_version', $latest_version, 60 * 60 * 24 );
			}

			if ( version_compare( $installed_version, $latest_version, '<' ) ) {
				// translators: %1$s div opening, %2$s p opening, %3$s b opening, %4$s b closing, %5$s changelog link opening, %6$s changelog link closing, %7$s update link opening, %8$s update link closing, %9$s plugin name, %10$s version number, %11$s current version.
				printf(
				// translators: %9$s plugin name, %10$s new version, %11$s current version, %5$s and %6$s changelog link tags, %7$s and %8$s update link tags.
					'%1$s %2$s %3$s ' . esc_html__( 'Update Available', 'wp-analytify-pro' ) . ' %4$s &mdash; %9$s %10$s ' . esc_html__( 'is now available. You currently have %11$s installed.  %5$s Changelog %6$s  %7$s %8$s', 'wp-analytify-pro' ),
					'<div class="notice notice-warning">',
					'<p>',
					'<b>',
					'</b>',
					'<a style="text-decoration:none" target="_blank" href="https://analytify.io/changelog/?utm_campaign=WPAnalytifyPro+UpdateAvailable&utm_medium=link&utm_source=WPAnalytifyPro+UpdateAvailable&utm_content=update-available-notice">',
					'</a>',
					'</p>',
					'</div>',
					esc_html( 'WP Analytify Pro' ),
					esc_html( $latest_version ),
					esc_html( $installed_version )
				);
			}
		}

		/**
		 * Get latest version from API
		 *
		 * @param string $license License key.
		 * @return string Latest version or empty string.
		 * @since 1.0.0
		 */
		private function get_latest_version( $license ) {
			$response = $this->wp_analytify_api_call(
				'get_version',
				$license,
				defined( 'ANALYTIFY_PRO_ID' ) ? ANALYTIFY_PRO_ID : 0,
				defined( 'ANALYTIFY_STORE_URL' ) ? ANALYTIFY_STORE_URL : ''
			);

			if ( is_object( $response ) && isset( $response->new_version ) && is_string( $response->new_version ) ) {
				return $response->new_version;
			}

			return '';
		}

		/**
		 * Make API call to the license store.
		 *
		 * Logs transport errors and invalid JSON via
		 * {@see wp_analytify_pro_log_edd_license_request_issue()} (masked license).
		 * Top-level `null` from `json_decode()` is treated as failure.
		 *
		 * @since 9.0.0
		 * @param string $type       EDD action (e.g. check_license, get_version).
		 * @param string $license    License key.
		 * @param int    $product_id Product ID.
		 * @param string $store_url  Store URL.
		 * @return object|false Decoded object on success; false on failure.
		 */
		public function wp_analytify_api_call( $type, $license, $product_id, $store_url ) {
			$api_params = array(
				'edd_action' => $type,
				'license'    => ! empty( $license ) ? $license : false,
				'item_id'    => $product_id,
				'url'        => home_url(),
			);

			$response = wp_remote_get(
				esc_url_raw( add_query_arg( $api_params, $store_url ) ),
				array(
					'timeout'   => 15,
					'sslverify' => false,
				)
			);

			if ( is_wp_error( $response ) ) {
				wp_analytify_pro_log_edd_license_request_issue(
					'License API request failed (transport error).',
					'WP_Analytify_Pro_License_Manager::wp_analytify_api_call',
					$api_params,
					$response,
					array( 'store_url' => $store_url )
				);
				return false;
			}

			$body    = wp_remote_retrieve_body( $response );
			$decoded = json_decode( $body );

			if ( null === $decoded || ! is_object( $decoded ) ) {
				wp_analytify_pro_log_edd_license_request_issue(
					'License API returned unexpected or invalid JSON.',
					'WP_Analytify_Pro_License_Manager::wp_analytify_api_call',
					$api_params,
					$response,
					array( 'store_url' => $store_url )
				);
				return false;
			}

			return $decoded;
		}
	}
}
