<?php // phpcs:ignore WordPress.Files.FileName.InvalidClassFileName
/**
 * WP Analytify Pro REST API Specialized Endpoints Class
 *
 * This class handles specialized REST API endpoints including:
 * - Events tracking
 * - Video tracking
 * - Custom dimensions
 * - Search terms
 * - Demographics
 * - Interests
 * - Real time
 * - Page speed
 * - Keyword stats search console
 *
 * @package WP_Analytify_Pro
 * @since 8.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_Analytify_Pro_REST_Specialized' ) ) {

	/**
	 * WP Analytify Pro REST API Specialized Endpoints Class
	 *
	 * @since 1.0.0
	 */
	class WP_Analytify_Pro_REST_Specialized {

		/**
		 * Singleton instance.
		 *
		 * @var WP_Analytify_Pro_REST_Specialized|null $instance The one true WP_Analytify_Pro_REST_Specialized.
		 * @since 1.0.0
		 */
		private static $instance;


		/**
		 * Date difference.
		 *
		 * @var string
		 */
		private $date_differ;

		/**
		 * Type parameter.
		 *
		 * @var string
		 */
		private $type;

		/**
		 * The main Analytify object.
		 *
		 * @var object|null
		 */
		private $wp_analytify;

		/**
		 * GA version (ga4 or ga3).
		 *
		 * @var string
		 */
		private $ga_mode;

		/**
		 * Selected 'start state'.
		 *
		 * @var string
		 */
		private $start_date;

		/**
		 * Selected 'End state'.
		 *
		 * @var string
		 */
		private $end_date;


		/**
		 * Get active instance.
		 *
		 * @access public
		 * @since 1.0.0
		 * @return WP_Analytify_Pro_REST_Specialized The one true WP_Analytify_Pro_REST_Specialized.
		 */
		public static function instance() {
			if ( ! self::$instance ) {
				self::$instance = new WP_Analytify_Pro_REST_Specialized();
				self::$instance->init();
			}
			return self::$instance;
		}

		/**
		 * Initialize the class.
		 *
		 * @access private
		 * @since 1.0.0
		 * @return void
		 */
		private function init() {
			// Don't initialize wp_analytify here - it will be set when set_dates is called.
		}

		/**
		 * Set dates for the specialized endpoints.
		 *
		 * @param string $start_date Start date.
		 * @param string $end_date End date.
		 * @param string $date_differ Date difference.
		 * @param string $type Type parameter.
		 * @param object $wp_analytify The main Analytify object.
		 * @param string $ga_mode GA mode.
		 * @return void
		 */
		public function set_dates( $start_date, $end_date, $date_differ, $type, $wp_analytify = null, $ga_mode = null ) {
			$this->start_date  = $start_date;
			$this->end_date    = $end_date;
			$this->date_differ = $date_differ;
			$this->type        = $type;

			// Set wp_analytify and ga_mode if provided.
			if ( null !== $wp_analytify ) {
				$this->wp_analytify = $wp_analytify;
			}
			if ( null !== $ga_mode ) {
				$this->ga_mode = $ga_mode;
			}
		}
	}
}
