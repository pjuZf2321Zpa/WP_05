<?php
/**
 * Base class for Analytify REST API handlers.
 *
 * Provides common functionality for report-based REST API endpoints,
 * including permission checks, date validation, and GA mode handling.
 *
 * @package WP_Analytify_Pro
 * @since 9.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Analytify_REST_Handler_Base' ) ) {

	/**
	 * Analytify REST Handler Base Class.
	 */
	abstract class Analytify_REST_Handler_Base {

		/**
		 * WP_Analytify instance.
		 *
		 * @var object
		 */
		protected $wp_analytify;

		/**
		 * GA mode (ga4 or ga3).
		 *
		 * @var string
		 */
		protected $ga_mode;

		/**
		 * Start date for reports.
		 *
		 * @var string
		 */
		protected $start_date;

		/**
		 * End date for reports.
		 *
		 * @var string
		 */
		protected $end_date;

		/**
		 * Constructor.
		 *
		 * Initializes core Analytify properties.
		 *
		 * @since 9.0.0
		 */
		public function __construct() {
			$this->wp_analytify = $GLOBALS['WP_ANALYTIFY'];
			$this->ga_mode      = method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) ? WPANALYTIFY_Utils::get_ga_mode() : 'ga3';
		}

		/**
		 * Checks access permission for the REST request.
		 *
		 * @since 9.0.0
		 * @return boolean True if the user has access.
		 */
		public function permission_check() {
			if ( ! $this->wp_analytify || ! is_object( $this->wp_analytify ) || ! isset( $this->wp_analytify->settings ) ) {
				return false;
			}

			$is_access_level = $this->wp_analytify->settings->get_option( 'show_analytics_roles_dashboard', 'wp-analytify-dashboard', array( 'administrator' ) );

			return (bool) $this->wp_analytify->pa_check_roles( $is_access_level );
		}

		/**
		 * Validate the date parameter format (Y-m-d).
		 *
		 * @since 9.0.0
		 * @param string $value Date string to validate.
		 * @return bool True if valid.
		 */
		public function validate_date_param( $value ) {
			if ( ! is_string( $value ) || empty( $value ) ) {
				return false;
			}
			$date = DateTime::createFromFormat( 'Y-m-d', $value );
			return $date && $date->format( 'Y-m-d' ) === $value;
		}

		/**
		 * Get the date range array for report requests.
		 *
		 * @since 9.0.0
		 * @return array Date range array with 'start' and 'end' keys.
		 */
		protected function get_date_range() {
			return array(
				'start' => $this->start_date,
				'end'   => $this->end_date,
			);
		}

		/**
		 * Return a standard "no data" WP_Error.
		 *
		 * @since 9.0.0
		 * @return WP_Error The 404 No Data error object.
		 */
		protected function return_no_data_error() {
			return new WP_Error( 'no_data', __( 'No data available.', 'wp-analytify-pro' ), array( 'status' => 404 ) );
		}

		/**
		 * Standard route arguments for report endpoints.
		 *
		 * @since 9.0.0
		 * @return array Map of route arguments.
		 */
		protected function get_common_route_args() {
			return array(
				'sd' => array(
					'type'              => 'string',
					'required'          => true,
					'sanitize_callback' => 'sanitize_text_field',
					'validate_callback' => array( $this, 'validate_date_param' ),
				),
				'ed' => array(
					'type'              => 'string',
					'required'          => true,
					'sanitize_callback' => 'sanitize_text_field',
					'validate_callback' => array( $this, 'validate_date_param' ),
				),
			);
		}
	}
}
