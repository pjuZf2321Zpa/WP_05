<?php // phpcs:ignore WordPress.Files.FileName.InvalidClassFileName
/**
 * WP Analytify Pro Frontend Manager Class
 *
 * @package WP_Analytify_Pro
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_Analytify_Pro_Frontend_Manager' ) ) {

	/**
	 * WP Analytify Pro Frontend Manager Class
	 *
	 * @since 1.0.0
	 */
	class WP_Analytify_Pro_Frontend_Manager {


		/**
		 * GA4 mode flag.
		 *
		 * @var bool
		 */
		private $is_ga4;

		/**
		 * Constructor for future use
		 */
		public function __construct() {
			// Constructor for future use.
		}

		/**
		 * Show Analytics at front-end.
		 *
		 * @param string $content Post content.
		 * @return string Modified content.
		 */
		public function get_single_front_analytics( $content ) {
			global $post;

			if ( ! is_single() && ! is_page() ) {
				return $content;
			}

			$post_type = get_post_type();
			if ( 'post' !== $post_type && 'page' !== $post_type ) {
				return $content;
			}

			$post_id   = get_the_ID();
			$permalink = $post_id ? get_permalink( $post_id ) : '';

			// Check if post is excluded.
			$back_exclude_posts = explode( ',', get_option( 'post_analytics_exclude_posts_back' ) );
			if ( in_array( (string) $post_id, $back_exclude_posts, true ) ) {
				return $content;
			}

			// Check if post is excluded for frontend.
			$front_exclude_posts = explode( ',', get_option( 'post_analytics_exclude_posts_front' ) );
			if ( in_array( (string) $post_id, $front_exclude_posts, true ) ) {
				return $content;
			}

			$analytics_content = $this->get_shortcode_front_analytics( (string) $post_id );

			if ( ! empty( $analytics_content ) ) {
				$content .= $analytics_content;
			}

			return $content;
		}

		/**
		 * Get shortcode front analytics.
		 *
		 * @param string $post_id Post ID.
		 * @return string Analytics content.
		 */
		public function get_shortcode_front_analytics( $post_id = '' ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found
			// Implementation will be moved here from main class.
			return '';
		}

		/**
		 * Stats under post
		 *
		 * @param array<string, mixed> $show_settings Show settings.
		 * @param string               $s_date Start date.
		 * @param string               $e_date End date.
		 * @param string               $filter Filter.
		 * @return void
		 */
		public function wp_analytify_stats_under_post( $show_settings, $s_date, $e_date, $filter ) {
			$wp_analytify = $GLOBALS['WP_ANALYTIFY'];

			if ( is_array( $show_settings ) ) {
				if ( in_array( 'show-geographic-dashboard', $show_settings, true ) ) {
					?>
					<div class="analytify_general_status analytify_status_box_wraper">
						<div class="analytify_status_header">
							<h3><?php analytify_e( 'Geographic', 'wp-analytify-pro' ); ?></h3>
						</div>
						<div class="analytify_status_body">
							<?php
							if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {
								$countries_stats = $wp_analytify->get_reports(
									'analytify-single-country-stats',
									array(
										'sessions',
									),
									array(
										'start' => $s_date,
										'end'   => $e_date,
									),
									array(
										'country',
									),
									array(
										'type' => 'dimension',
										'name' => 'country',
									),
									array(
										array(
											'type'       => 'dimension',
											'name'       => 'country',
											'match_type' => 4,
											'value'      => '(not set)',
											'not_expression' => true,
										),
									)
								);

								$cities_stats = $wp_analytify->get_reports(
									'analytify-single-city-stats',
									array(
										'sessions',
									),
									array(
										'start' => $s_date,
										'end'   => $e_date,
									),
									array(
										'city',
										'country',
									),
									array(
										'type' => 'metric',
										'name' => 'sessions',
									),
									array(
										array(
											'type'       => 'dimension',
											'name'       => 'country',
											'match_type' => 4,
											'value'      => '(not set)',
											'not_expression' => true,
										),
										array(
											'type'       => 'dimension',
											'name'       => 'city',
											'match_type' => 4,
											'value'      => '(not set)',
											'not_expression' => true,
										),
									)
								);

								if ( defined( 'WP_ANALYTIFY_ROOT_PATH' ) ) {
									include WP_ANALYTIFY_ROOT_PATH . '/views/default/admin/geographic-stats.php';
								}
								if ( function_exists( 'fetch_ga_geographic_stats' ) ) {
									$report_url        = '';
									$report_date_range = '';
									fetch_ga_geographic_stats( $wp_analytify, $countries_stats, $cities_stats, true, $report_url, $report_date_range );
								}
							} else {
								$country_stats = $wp_analytify->pa_get_analytics( 'ga:sessions', $s_date, $e_date, 'ga:country', '-ga:sessions', 'ga:country!=(not set);' . $filter, false, 'analytify-single-country-stats' );
								$cities_stats  = $wp_analytify->pa_get_analytics( 'ga:sessions', $s_date, $e_date, 'ga:city,ga:country', '-ga:sessions', 'ga:city!=(not set);ga:country!=(not set);' . $filter, 5, 'analytify-single-city-stats' );

								if ( defined( 'WP_ANALYTIFY_ROOT_PATH' ) ) {
									include WP_ANALYTIFY_ROOT_PATH . '/views/default/admin/geographic-stats-deprecated.php';
								}

								if ( function_exists( 'fetch_geographic_stats' ) ) {
									fetch_geographic_stats( $wp_analytify, $country_stats, $cities_stats, false );
								}
							}
							?>
						</div>

						<div class="analytify_status_footer">
							<span class="analytify_info_stats"><?php esc_html_e( 'Listing statistics of top countries and cities.', 'wp-analytify-pro' ); ?></span>
						</div>
					</div>
						<?php
				}
			}

			if ( is_array( $show_settings ) ) {
				if ( in_array( 'show-system-stats', $show_settings, true ) ) {
					?>
					<div class="analytify_general_status analytify_status_box_wraper">
						<div class="analytify_status_header">
							<h3><?php analytify_e( 'System Stats', 'wp-analytify-pro' ); ?></h3>
						</div>
						<div class="">
							<?php
							if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {
								$browser_stats = $wp_analytify->get_reports(
									'show-default-browser-dashboard',
									array(
										'sessions',
									),
									array(
										'start' => $s_date,
										'end'   => $e_date,
									),
									array(
										'browser',
										'operatingSystem',
									),
									array(
										'type' => 'metric',
										'name' => 'sessions',
									),
									array(
										array(
											'type'       => 'dimension',
											'name'       => 'operatingSystem',
											'match_type' => 4,
											'value'      => '(not set)',
											'not_expression' => true,
										),
										array(
											'type'       => 'dimension',
											'name'       => 'browser',
											'match_type' => 4,
											'value'      => '(not set)',
											'not_expression' => true,
										),
									),
									5
								);

								$os_stats = $wp_analytify->get_reports(
									'show-default-os-dashboard',
									array(
										'sessions',
									),
									array(
										'start' => $s_date,
										'end'   => $e_date,
									),
									array(
										'browser',
										'operatingSystemVersion',
									),
									array(
										'type' => 'metric',
										'name' => 'sessions',
									),
									array(
										array(
											'type'       => 'dimension',
											'name'       => 'operatingSystemVersion',
											'match_type' => 4,
											'value'      => '(not set)',
											'not_expression' => true,
										),
									),
									5
								);

								$mobile_stats = $wp_analytify->get_reports(
									'show-default-mobile-dashboard',
									array(
										'sessions',
									),
									array(
										'start' => $s_date,
										'end'   => $e_date,
									),
									array(
										'mobileDeviceBranding',
										'mobileDeviceModel',
									),
									array(
										'type' => 'metric',
										'name' => 'sessions',
									),
									array(
										array(
											'type'       => 'dimension',
											'name'       => 'mobileDeviceBranding',
											'match_type' => 4,
											'value'      => '(not set)',
											'not_expression' => true,
										),
										array(
											'type'       => 'dimension',
											'name'       => 'mobileDeviceModel',
											'match_type' => 4,
											'value'      => '(not set)',
											'not_expression' => true,
										),
									),
									5
								);

								if ( defined( 'WP_ANALYTIFY_ROOT_PATH' ) ) {
									include WP_ANALYTIFY_ROOT_PATH . '/views/default/admin/tech-stats.php';
								}
								if ( function_exists( 'fetch_ga_system_stats' ) ) {
									fetch_ga_system_stats( $wp_analytify, $browser_stats, $os_stats, $mobile_stats );
								}
							}
							?>
						</div>
					</div>
					<?php
				}
			}

			if ( is_array( $show_settings ) ) {
				if ( in_array( 'show-keywords-dashboard', $show_settings, true ) ) {
					?>
					<div class="analytify_general_status analytify_status_box_wraper">
						<div class="analytify_status_header">
							<h3><?php analytify_e( 'How people are finding you (keywords)', 'wp-analytify-pro' ); ?></h3>
							<div class="analytify_status_header_value keywords_total">
								<span class="analytify_medium_f"><?php analytify_e( 'Total Visits', 'wp-analytify-pro' ); ?></span>
							</div>
						</div>
						<div class="analytify_status_body">
							<?php
							if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {
								$keyword_stats = $wp_analytify->get_reports(
									'show-default-keyword-dashboard',
									array(
										'sessions',
									),
									array(
										'start' => $s_date,
										'end'   => $e_date,
									),
									array(
										'keyword',
									),
									array(),
									array(),
									8
								);

								if ( defined( 'WP_ANALYTIFY_ROOT_PATH' ) ) {
									include WP_ANALYTIFY_ROOT_PATH . '/views/default/admin/keywords-stats.php';
								}
								$_keyword_dashboard = array();
								if ( function_exists( 'fetch_ga_keywords_stats' ) ) {
									$_keyword_dashboard = json_decode( fetch_ga_keywords_stats( $wp_analytify, $keyword_stats, true ), true );
								}
							} else {
								$keyword_stats = $wp_analytify->pa_get_analytics( 'ga:sessions', $s_date, $e_date, 'ga:keyword', '-ga:sessions', $filter, 8, 'analytify-single-keyword-stats' );

								if ( defined( 'WP_ANALYTIFY_ROOT_PATH' ) ) {
									include WP_ANALYTIFY_ROOT_PATH . '/views/default/admin/keywords-stats.php';
								}
								if ( function_exists( 'fetch_keywords_stats' ) ) {
									$_keyword_dashboard = json_decode( fetch_keywords_stats( $wp_analytify, $keyword_stats, true ), true );
								}
								echo wp_kses_post( isset( $_keyword_dashboard['body'] ) ? $_keyword_dashboard['body'] : '' );
							}
							?>
						</div>
						<div class="analytify_status_footer">
							<span class="analytify_info_stats"><?php esc_html_e( 'Listing your ranked keywords', 'wp-analytify-pro' ); ?></span>
						</div>
					</div>
					<?php
				}
			}

			if ( is_array( $show_settings ) ) {
				if ( in_array( 'show-social-dashboard', $show_settings, true ) ) {
					?>
					<div class="analytify_general_status analytify_status_box_wraper">
						<div class="analytify_status_header">
							<h3><?php analytify_e( 'Social Media', 'wp-analytify-pro' ); ?></h3>
							<div class="analytify_status_header_value social_total">
								<span class="analytify_medium_f"><?php analytify_e( 'Total Visits', 'wp-analytify-pro' ); ?></span>
							</div>
						</div>
						<div class="analytify_status_body">
							<?php
							// Social media stats implementation commented out.
							?>
						</div>
						<div class="analytify_status_footer">
							<span class="analytify_info_stats"><?php esc_html_e( 'See how many users are coming to your site from Social media', 'wp-analytify-pro' ); ?></span>
						</div>
					</div>
					<?php
				}
			}

			if ( is_array( $show_settings ) ) {
				if ( in_array( 'show-referrer-dashboard', $show_settings, true ) ) {
					?>
					<div class="analytify_general_status analytify_status_box_wraper">
						<div class="analytify_status_header">
							<h3><?php analytify_e( 'Top Referrers', 'wp-analytify-pro' ); ?></h3>
							<div class="analytify_status_header_value  reffers_total">
								<span class="analytify_medium_f"><?php analytify_e( 'Total Visits', 'wp-analytify-pro' ); ?></span>
							</div>
						</div>
						<div class="analytify_status_body">
							<?php
							// Referrer stats implementation commented out.
							?>
						</div>
						<div class="analytify_status_footer">
							<span class="analytify_info_stats"><?php esc_html_e( 'Who are the top Referrers to your site? See above', 'wp-analytify-pro' ); ?></span>
						</div>
					</div>
					<?php
				}
			}

			if ( is_array( $show_settings ) ) {
				if ( in_array( 'show-what-happen-stats', $show_settings, true ) ) {
					?>
					<div class="analytify_general_status analytify_status_box_wraper">
						<div class="analytify_status_header">
							<h3><?php esc_html_e( 'What\'s happening when users come to your page.', 'wp-analytify-pro' ); ?></h3>
						</div>
						<div class="analytify_status_body">
							<?php
							// What happen stats implementation commented out.
							?>
						</div>
						<div class="analytify_status_footer">
						</div>
					</div>
					<?php
				}
			}
		}

		/**
		 * Adds sections for single post stats.
		 *
		 * @param array<string, mixed> $sections Sections.
		 * @param int                  $post_id  Post id.
		 * @param array<int, string>   $date     Start and End date.
		 * @return array<string, mixed>
		 */
		public function single_post_sections( $sections, $post_id, $date ) {

			$wp_analytify = $GLOBALS['WP_ANALYTIFY'];
			$this->is_ga4 = class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) ? 'ga4' === WPANALYTIFY_Utils::get_ga_mode() : false;

			$show_settings = $wp_analytify->settings->get_option( 'show_panels_back_end', 'wp-analytify-admin', array( 'show-overall-dashboard' ) );
			if ( empty( $show_settings ) ) {
				return $sections;
			}

			$report = new Analytify_Report_Pro(
				array(
					'dashboard_type' => 'single_post',
					'start_date'     => $date[0],
					'end_date'       => $date[1],
					'post_id'        => $post_id,
				)
			);

			// Section 'Geographic'.
			if ( in_array( 'show-geographic-dashboard', $show_settings, true ) ) {
				$footer_geographic_stats = esc_html__( 'Listing staticstics of top countries and cities.', 'wp-analytify-pro' );
				$sections['geographic']  = array(
					'title'    => esc_html__( 'Geographic', 'wp-analytify-pro' ),
					'type'     => 'table_column',
					'sections' => array(),
					'footer'   => apply_filters( 'analytify_geographic_stats_single_footer', $footer_geographic_stats, $post_id, $date ),
				);

				// Country.
				$country_stats = $report->get_country_stats();

				$sections['geographic']['sections']['countries'] = array(
					'type'    => 'table',
					'headers' => array(
						'Countries' => array(
							'label'    => esc_html__( 'Top Countries', 'wp-analytify-pro' ),
							'th_class' => 'analytify_txt_left analytify_top_geographic_detials_wraper',
							'td_class' => '',
						),
						'sessions'  => array(
							'label'    => esc_html__( 'Visitors', 'wp-analytify-pro' ),
							'th_class' => 'analytify_value_row',
							'td_class' => 'analytify_txt_center',
						),
					),
					'stats'   => isset( $country_stats['stats'] ) ? $country_stats['stats'] : array(),
				);

				// Cities.
				$city_stats = $report->get_city_stats();

				$sections['geographic']['sections']['cities'] = array(
					'type'    => 'table',
					'headers' => array(
						'Cities'   => array(
							'label'    => esc_html__( 'Top Cities', 'wp-analytify-pro' ),
							'th_class' => 'analytify_txt_left analytify_top_geographic_detials_wraper',
							'td_class' => '',
						),
						'sessions' => array(
							'label'    => esc_html__( 'Visitors', 'wp-analytify-pro' ),
							'th_class' => 'analytify_value_row',
							'td_class' => 'analytify_txt_center',
						),
					),
					'stats'   => isset( $city_stats['stats'] ) ? $city_stats['stats'] : array(),
				);
			}

			// Section 'System Stats'.
			if ( in_array( 'show-system-stats', $show_settings, true ) ) {
				$footer_system_stats      = esc_html__( 'Top Web Browsers, Operating Systems and Mobile Devices for this page.', 'wp-analytify-pro' );
				$sections['system_stats'] = array(
					'title'    => __( 'System Stats', 'wp-analytify-pro' ),
					'type'     => 'table_column',
					'sections' => array(),
					'footer'   => apply_filters( 'analytify_system_stats_single_footer', $footer_system_stats, $post_id, $date ),
				);

				// Browsers.
				$browser_stats = $report->get_browser_stats();

				$sections['system_stats']['sections']['browser'] = array(
					'type'    => 'table',
					'headers' => array(
						'browser'  => array(
							'label'    => esc_html__( 'Browsers Statistics', 'wp-analytify-pro' ),
							'th_class' => 'analytify_txt_left analytify_top_geographic_detials_wraper',
							'td_class' => '',
						),
						'sessions' => array(
							'label'    => esc_html__( 'Visitors', 'wp-analytify-pro' ),
							'th_class' => 'analytify_value_row',
							'td_class' => 'analytify_txt_center',
						),
					),
					'stats'   => isset( $browser_stats['stats'] ) ? $browser_stats['stats'] : array(),
				);

				// OS.
				$os_stats = $report->get_os_stats();

				$sections['system_stats']['sections']['os'] = array(
					'type'    => 'table',
					'headers' => array(
						'os'       => array(
							'label'    => esc_html__( 'Operating System Statistics', 'wp-analytify-pro' ),
							'th_class' => 'analytify_txt_left analytify_top_geographic_detials_wraper',
							'td_class' => '',
						),
						'sessions' => array(
							'label'    => esc_html__( 'Visitors', 'wp-analytify-pro' ),
							'th_class' => 'analytify_value_row',
							'td_class' => 'analytify_txt_center',
						),
					),
					'stats'   => isset( $os_stats['stats'] ) ? $os_stats['stats'] : array(),
				);

				// Mobile Devices.
				$mobile_stats = $report->get_mobile_stats();

				$sections['system_stats']['sections']['mobile'] = array(
					'type'    => 'table',
					'headers' => array(
						'os'       => array(
							'label'    => esc_html__( 'Mobile Devices Statistics', 'wp-analytify-pro' ),
							'th_class' => 'analytify_txt_left analytify_top_geographic_detials_wraper',
							'td_class' => '',
						),
						'sessions' => array(
							'label'    => esc_html__( 'Visitors', 'wp-analytify-pro' ),
							'th_class' => 'analytify_value_row',
							'td_class' => 'analytify_txt_center',
						),
					),
					'stats'   => isset( $mobile_stats['stats'] ) ? $mobile_stats['stats'] : array(),
				);
			}

			// Social Media.
			if ( in_array( 'show-social-dashboard', $show_settings, true ) && ! $this->is_ga4 ) {
				$footer_social_stats = esc_html__( 'See how many users are coming to your site from Social Media.', 'wp-analytify-pro' );
				$social_media_stats  = $report->get_social_media_stats();

				$sections['social_media'] = array(
					'title'   => __( 'Social Media', 'wp-analytify-pro' ),
					'type'    => 'table',
					'headers' => array(
						'network' => array(
							'label'    => esc_html__( 'Network', 'wp-analytify-pro' ),
							'th_class' => 'analytify_txt_left analytify_top_geographic_detials_wraper',
							'td_class' => '',
						),
						'visitor' => array(
							'label'    => esc_html__( 'Visitors', 'wp-analytify-pro' ),
							'th_class' => 'analytify_value_row',
							'td_class' => '',
						),
					),
					'stats'   => isset( $social_media_stats['stats'] ) ? $social_media_stats['stats'] : array(),
					'footer'  => apply_filters( 'analytify_social_footer_single_footer', $footer_social_stats, $post_id, $date ),
				);
			}

			// Section 'Referes'.
			if ( in_array( 'show-referrer-dashboard', $show_settings, true ) ) {
				$footer_referer_stats = esc_html__( 'The top referers of this page.', 'wp-analytify-pro' );
				$referrer_stats       = $report->get_referrer_stats();

				$sections['referer'] = array(
					'title'   => __( 'Top Referrers', 'wp-analytify-pro' ),
					'type'    => 'table',
					'headers' => array(
						'referrer' => array(
							'label'    => esc_html__( 'Referrers', 'wp-analytify-pro' ),
							'th_class' => 'analytify_txt_left analytify_top_geographic_detials_wraper',
							'td_class' => '',
						),
						'visitor'  => array(
							'label'    => esc_html__( 'Visitors', 'wp-analytify-pro' ),
							'th_class' => 'analytify_value_row',
							'td_class' => 'analytify_txt_center',
						),
					),
					'stats'   => isset( $referrer_stats['stats'] ) ? $referrer_stats['stats'] : array(),
					'footer'  => apply_filters( 'analytify_referer_stats_single_footer', $footer_referer_stats, $post_id, $date ),
				);
			}

			/**
			 * What's happening.
			 * Note: This feature is currently only available for Universal Analytics (UA).
			 * GA4 equivalent functionality may be added in a future update.
			 */
			if ( in_array( 'show-what-happen-stats', $show_settings, true ) && ! $this->is_ga4 ) {
				$footer_what_happen_stats = false;
				$whats_happening_stats    = $report->get_whats_happening_stats();

				$sections['referer'] = array(
					'title'   => __( 'What\'s happening when users come to your page', 'wp-analytify-pro' ),
					'type'    => 'table',
					'headers' => array(
						'entrance'   => array(
							'label'    => esc_html__( 'Entrance', 'wp-analytify-pro' ),
							'th_class' => 'analytify_txt_center analytify_compair_value_row',
							'td_class' => 'analytify_txt_center analytify_w_300 analytify_l_f',
						),
						'exits'      => array(
							'label'    => esc_html__( 'Exits', 'wp-analytify-pro' ),
							'th_class' => 'analytify_txt_center analytify_compair_value_row',
							'td_class' => 'analytify_txt_center analytify_w_300 analytify_l_f',
						),
						'percentage' => array(
							'label'    => esc_html__( 'Entrance% Exits%', 'wp-analytify-pro' ),
							'th_class' => 'analytify_txt_center analytify_compair_row',
							'td_class' => 'analytify_txt_center analytify_w_300 analytify_l_f',
						),
					),
					'stats'   => isset( $whats_happening_stats['stats'] ) ? $whats_happening_stats['stats'] : array(),
					'footer'  => apply_filters( 'analytify_what_happen_stats_single_footer', $footer_what_happen_stats, $post_id, $date ),
				);
			}

			// Section 'Video Tracking'.
			if ( in_array( 'show-video-tracking-stats', $show_settings, true ) && $this->is_ga4 ) {
				$footer_video_tracking = esc_html__( 'Video tracking statistics for this page.', 'wp-analytify-pro' );
				$video_tracking_stats  = $report->get_video_tracking_stats();

				$sections['video_tracking'] = array(
					'title'   => esc_html__( 'Video Tracking', 'wp-analytify-pro' ),
					'type'    => 'table',
					'headers' => array(
						'event_label'    => array(
							'label'    => esc_html__( 'Title', 'wp-analytify-pro' ),
							'th_class' => 'analytify_txt_left',
							'td_class' => '',
						),
						'video_action'   => array(
							'label'    => esc_html__( 'Action', 'wp-analytify-pro' ),
							'th_class' => 'analytify_txt_left',
							'td_class' => '',
						),
						'video_provider' => array(
							'label'    => esc_html__( 'Provider', 'wp-analytify-pro' ),
							'th_class' => 'analytify_txt_left',
							'td_class' => '',
						),
						'video_duration' => array(
							'label'    => esc_html__( 'Duration (s)', 'wp-analytify-pro' ),
							'th_class' => 'analytify_txt_center',
							'td_class' => 'analytify_txt_center',
						),
						'event_count'    => array(
							'label'    => esc_html__( 'Event Count', 'wp-analytify-pro' ),
							'th_class' => 'analytify_value_row',
							'td_class' => 'analytify_txt_center',
						),
					),
					'stats'   => isset( $video_tracking_stats['stats'] ) ? $video_tracking_stats['stats'] : array(),
					'footer'  => apply_filters( 'analytify_video_tracking_single_footer', $footer_video_tracking, $post_id, $date ),
				);
			}

			return $sections;
		}

		/**
		 * Exclusion meta box.
		 *
		 * @return void
		 */
		public function exclusion_meta_box() {
			// Implementation will be moved here from main class.
		}

		/**
		 * Register exclusion meta field.
		 *
		 * @return void
		 */
		public function register_exclusion_meta_field() {
			// Implementation will be moved here from main class.
		}

		/**
		 * Save exclusion meta field.
		 *
		 * @param int $post_id Post ID.
		 * @return void
		 */
		public function save_exclusion_meta_field( $post_id ) {
			// Implementation will be moved here from main class.
		}

		/**
		 * Show Analytics of single post/page in wp-admin under EDIT screen.
		 *
		 * @return void
		 */
		public static function show_admin_single_analytics() {
			global $post;

			$back_exclude_posts = explode( ',', get_option( 'post_analytics_exclude_posts_back' ) );

			if ( isset( $post->ID ) ) {
				if ( in_array( $post->ID, $back_exclude_posts, true ) ) {
					analytify_e( 'This post is excluded and will NOT show Analytics.', 'wp-analytify-pro' );
					return;
				}
			}

			$url_post     = ''; // phpcs:ignore WordPress.NamingConventions.ValidVariableName.VariableNotSnakeCase
			$wp_analytify = $GLOBALS['WP_ANALYTIFY'];
			$permalink    = isset( $post->ID ) ? get_permalink( $post->ID ) : false;
			$url_post     = $permalink ? wp_parse_url( $permalink ) : false; // phpcs:ignore WordPress.NamingConventions.ValidVariableName.VariableNotSnakeCase

			if ( isset( $post->ID ) ) {
				if ( get_the_time( 'Y', $post->ID ) < 2005 ) {
					$start_date = '2005-01-01';
				} else {
					$start_date = get_the_time( 'Y-m-d', $post->ID );
				}
			} else {
				$start_date = '2005-01-01';
			}

			$end_date = gmdate( 'Y-m-d' );

			$is_access_level = get_option( 'post_analytics_access_back' );

			if ( $wp_analytify->pa_check_roles( $is_access_level ) ) {
				?>
			<div class="pa-filter">
				<table cellspacing="0" cellpadding="0" width="400">
					<tbody>
						<tr>
							<td width="0">
								<input type="text" id="start_date" name="start_date" value="<?php echo esc_attr( $start_date ); ?>">
							</td>
							<td width="0">
								<input type="text" id="end_date" name="end_date" value="<?php echo esc_attr( $end_date ); ?>">
							</td>
							<input type="hidden" name="urlpost" id="urlpost" value="<?php echo esc_attr( is_array( $url_post ) && isset( $url_post['path'] ) ? $url_post['path'] : '' ); /* phpcs:ignore WordPress.NamingConventions.ValidVariableName.VariableNotSnakeCase */ ?>">
							<td width="0">
								<input type="button" id="view_analytics" name="view_analytics" value="View Stats" class="button button-primary button-large">
							</td>
						</tr>
					</tbody>
				</table>
			</div>
			<div class="loading" style="display:none">
				<img src="<?php echo esc_url( plugins_url( 'images/loading.gif', __FILE__ ) ); ?>">
			</div>
			<div class="show-hide">
				<?php $wp_analytify->get_single_admin_analytics( $start_date, $end_date, $post->ID, 0 ); ?>
			</div>
				<?php
			} else {
				analytify_e( 'You are not allowed to see stats', 'wp-analytify-pro' );
			}
		}
	}
}
