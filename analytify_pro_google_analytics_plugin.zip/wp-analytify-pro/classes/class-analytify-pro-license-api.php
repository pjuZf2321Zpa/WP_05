<?php // phpcs:ignore WordPress.Files.FileName.InvalidClassFileName
/**
 * WP Analytify Pro License API Class
 *
 * This class handles license API functionality including:
 * - License checking and validation
 * - License status message generation
 * - API calls to license store
 *
 * @package WP_Analytify_Pro
 * @since 8.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_Analytify_Pro_License_API' ) ) {

	/**
	 * WP Analytify Pro License API Class
	 *
	 * @since 1.0.0
	 */
	class WP_Analytify_Pro_License_API {

		/**
		 * Singleton instance.
		 *
		 * @var WP_Analytify_Pro_License_API $instance The one true WP_Analytify_Pro_License_API.
		 * @since 1.0.0
		 */
		private static $instance;

		/**
		 * Transient timeout for license responses.
		 *
		 * @var int
		 * @since 1.0.0
		 */
		private $transient_timeout = 60 * 60 * 24; // 24 hours.

		/**
		 * Get active instance.
		 *
		 * @access public
		 * @since 1.0.0
		 * @return WP_Analytify_Pro_License_API The one true WP_Analytify_Pro_License_API.
		 */
		public static function instance() {
			if ( ! self::$instance ) {
				self::$instance = new WP_Analytify_Pro_License_API();
				self::$instance->init();
			}
			return self::$instance;
		}

		/**
		 * Initialize the class
		 *
		 * @access private
		 * @since 1.0.0
		 * @return void
		 */
		private function init() {
			$this->hooks();
		}

		/**
		 * Run action and filter hooks
		 *
		 * @access private
		 * @since 1.0.0
		 * @return void
		 */
		private function hooks() {
			// License API hooks can be added here if needed in the future.
		}

		// ========================================
		// LICENSE CHECKING METHODS
		// ========================================

		/**
		 * Check WooCommerce license
		 *
		 * @param string $license_key License key to validate..
		 * @return mixed API response.
		 * @since 1.0.0
		 */
		public function check_woo_license( $license_key ) {
			if ( empty( $license_key ) ) {
				return false;
			}

			$response = $this->wp_analytify_api_call( 'check_license', $license_key, defined( 'WOO_ANALYTIFY_PRODUCT_ID' ) ? WOO_ANALYTIFY_PRODUCT_ID : 0, defined( 'WOO_ANALYTIFY_STORE_URL' ) ? WOO_ANALYTIFY_STORE_URL : '' );
			set_site_transient( 'wpanalytify_woo_license_response', $response, $this->transient_timeout );

			return $response;
		}

		/**
		 * Check EDD license
		 *
		 * @param string $license_key License key to validate.
		 * @return mixed API response
		 * @since 1.0.0
		 */
		public function check_edd_license( $license_key ) {
			if ( empty( $license_key ) ) {
				return false;
			}

			$response = $this->wp_analytify_api_call( 'check_license', $license_key, defined( 'EDD_ANALYTIFY_PRODUCT_ID' ) ? EDD_ANALYTIFY_PRODUCT_ID : 0, defined( 'EDD_ANALYTIFY_STORE_URL' ) ? EDD_ANALYTIFY_STORE_URL : '' );
			set_site_transient( 'wpanalytify_edd_license_response', $response, $this->transient_timeout );

			return $response;
		}

		/**
		 * Check Email license
		 *
		 * @param string $license_key License key to validate.
		 * @return mixed API response
		 * @since 1.0.0
		 */
		public function check_email_license( $license_key ) {
			if ( empty( $license_key ) ) {
				return false;
			}

			$response = $this->wp_analytify_api_call( 'check_license', $license_key, EMAIL_ANALYTIFY_PRODUCT_ID, EMAIL_ANALYTIFY_STORE_URL );
			set_site_transient( 'wpanalytify_email_license_response', $response, $this->transient_timeout );

			return $response;
		}

		/**
		 * Check Campaigns license
		 *
		 * @param string $license_key License key to validate.
		 * @return mixed API response
		 * @since 1.0.0
		 */
		public function check_campaigns_license( $license_key ) {
			if ( empty( $license_key ) ) {
				return false;
			}

			$response = $this->wp_analytify_api_call( 'check_license', $license_key, defined( 'CAMPAIGNS_ANALYTIFY_PRODUCT_ID' ) ? CAMPAIGNS_ANALYTIFY_PRODUCT_ID : 0, defined( 'CAMPAIGNS_ANALYTIFY_STORE_URL' ) ? CAMPAIGNS_ANALYTIFY_STORE_URL : '' );
			set_site_transient( 'wpanalytify_campaigns_license_response', $response, $this->transient_timeout );

			return $response;
		}

		/**
		 * Check Dimensions license
		 *
		 * @param string $license_key License key to validate.
		 * @return mixed API response
		 * @since 1.0.0
		 */
		public function check_dimensions_license( $license_key ) {
			if ( empty( $license_key ) ) {
				return false;
			}

			$response = $this->wp_analytify_api_call( 'check_license', $license_key, defined( 'DIMENSIONS_ANALYTIFY_PRODUCT_ID' ) ? DIMENSIONS_ANALYTIFY_PRODUCT_ID : 0, defined( 'DIMENSIONS_ANALYTIFY_STORE_URL' ) ? DIMENSIONS_ANALYTIFY_STORE_URL : '' );
			set_site_transient( 'wpanalytify_dimensions_license_response', $response, $this->transient_timeout );

			return $response;
		}

		/**
		 * Check Authors license
		 *
		 * @param string $license_key License key to validate.
		 * @return mixed API response
		 * @since 1.0.0
		 */
		public function check_authors_license( $license_key ) {
			if ( empty( $license_key ) ) {
				return false;
			}

			$response = $this->wp_analytify_api_call( 'check_license', $license_key, defined( 'AUTHORS_ANALYTIFY_PRODUCT_ID' ) ? AUTHORS_ANALYTIFY_PRODUCT_ID : 0, defined( 'AUTHORS_ANALYTIFY_STORE_URL' ) ? AUTHORS_ANALYTIFY_STORE_URL : '' );
			set_site_transient( 'wpanalytify_authors_license_response', $response, $this->transient_timeout );

			return $response;
		}

		/**
		 * Check Forms license
		 *
		 * @param string $license_key License key to validate.
		 * @return mixed API response
		 * @since 1.0.0
		 */
		public function check_forms_license( $license_key ) {
			if ( empty( $license_key ) ) {
				return false;
			}

			$response = $this->wp_analytify_api_call( 'check_license', $license_key, defined( 'FORMS_ANALYTIFY_PRODUCT_ID' ) ? FORMS_ANALYTIFY_PRODUCT_ID : 0, defined( 'FORMS_ANALYTIFY_STORE_URL' ) ? FORMS_ANALYTIFY_STORE_URL : '' );
			set_site_transient( 'wpanalytify_forms_license_response', $response, $this->transient_timeout );

			return $response;
		}

		/**
		 * Check Events Tracking license
		 *
		 * @param string $license_key License key to validate.
		 * @return mixed API response
		 * @since 1.0.0
		 */
		public function check_events_tracking_license( $license_key ) {
			if ( empty( $license_key ) ) {
				return false;
			}

			$response = $this->wp_analytify_api_call( 'check_license', $license_key, defined( 'EVENTS_TRACKING_ANALYTIFY_PRODUCT_ID' ) ? EVENTS_TRACKING_ANALYTIFY_PRODUCT_ID : 0, defined( 'EVENTS_TRACKING_ANALYTIFY_STORE_URL' ) ? EVENTS_TRACKING_ANALYTIFY_STORE_URL : '' );
			set_site_transient( 'wpanalytify_events_tracking_license_response', $response, $this->transient_timeout );

			return $response;
		}

		/**
		 * Check Goals license
		 *
		 * @param string $license_key License key to validate.
		 * @return mixed API response
		 * @since 1.0.0
		 */
		public function check_goals_license( $license_key ) {
			if ( empty( $license_key ) ) {
				return false;
			}

			$response = $this->wp_analytify_api_call( 'check_license', $license_key, defined( 'GOALS_ANALYTIFY_PRODUCT_ID' ) ? GOALS_ANALYTIFY_PRODUCT_ID : 0, defined( 'GOALS_ANALYTIFY_STORE_URL' ) ? GOALS_ANALYTIFY_STORE_URL : '' );
			set_site_transient( 'wpanalytify_goals_license_response', $response, $this->transient_timeout );

			return $response;
		}

		// ========================================
		// LICENSE STATUS MESSAGE METHODS
		// ========================================

		/**
		 * Get WooCommerce license status message
		 *
		 * @param bool   $trans Transient data.
		 * @param string $context Context for message.
		 * @return string|array<string, string> Status message
		 * @since 1.0.0
		 */
		public function get_woo_license_status_message( $trans = false, $context = null ) {
			return $this->get_generic_license_status_message( 'woo', $trans, $context );
		}

		/**
		 * Get EDD license status message
		 *
		 * @param bool   $trans Transient data.
		 * @param string $context Context for message.
		 * @return string|array<string, string> Status message
		 * @since 1.0.0
		 */
		public function get_edd_license_status_message( $trans = false, $context = null ) {
			return $this->get_generic_license_status_message( 'edd', $trans, $context );
		}

		/**
		 * Get Email license status message
		 *
		 * @param bool   $trans Transient data.
		 * @param string $context Context for message.
		 * @return string|array<string, string> Status message
		 * @since 1.0.0
		 */
		public function get_email_license_status_message( $trans = false, $context = null ) {
			return $this->get_generic_license_status_message( 'email', $trans, $context );
		}

		/**
		 * Get Campaigns license status message
		 *
		 * @param bool   $trans Transient data.
		 * @param string $context Context for message.
		 * @return string|array<string, string> Status message
		 * @since 1.0.0
		 */
		public function get_campaigns_license_status_message( $trans = false, $context = null ) {
			return $this->get_generic_license_status_message( 'campaigns', $trans, $context );
		}

		/**
		 * Get Dimensions license status message
		 *
		 * @param bool   $trans Transient data.
		 * @param string $context Context for message.
		 * @return string|array<string, string> Status message
		 * @since 1.0.0
		 */
		public function get_dimensions_license_status_message( $trans = false, $context = null ) {
			return $this->get_generic_license_status_message( 'dimensions', $trans, $context );
		}

		/**
		 * Get Authors license status message
		 *
		 * @param bool   $trans Transient data.
		 * @param string $context Context for message.
		 * @return string|array<string, string> Status message
		 * @since 1.0.0
		 */
		public function get_authors_license_status_message( $trans = false, $context = null ) {
			return $this->get_generic_license_status_message( 'authors', $trans, $context );
		}

		/**
		 * Get Forms license status message
		 *
		 * @param bool   $trans Transient data.
		 * @param string $context Context for message.
		 * @return string|array<string, string> Status message
		 * @since 1.0.0
		 */
		public function get_forms_license_status_message( $trans = false, $context = null ) {
			return $this->get_generic_license_status_message( 'forms', $trans, $context );
		}

		/**
		 * Get Events Tracking license status message
		 *
		 * @param bool   $trans Transient data.
		 * @param string $context Context for message.
		 * @return string|array<string, string> Status message
		 * @since 1.0.0
		 */
		public function get_events_tracking_license_status_message( $trans = false, $context = null ) {
			return $this->get_generic_license_status_message( 'events_tracking', $trans, $context );
		}

		/**
		 * Get Goals license status message
		 *
		 * @param bool   $trans Transient data.
		 * @param string $context Context for message.
		 * @return string|array<string, string> Status message
		 * @since 1.0.0
		 */
		public function get_goals_license_status_message( $trans = false, $context = null ) {
			return $this->get_generic_license_status_message( 'goals', $trans, $context );
		}

		// ========================================
		// HELPER METHODS
		// ========================================

		/**
		 * Generic license status message generator
		 *
		 * @param string $addon_type Addon type.
		 * @param bool   $trans Transient data.
		 * @param string $context Context for message.
		 * @return string|array<string, string> Status message.
		 * @since 1.0.0
		 */
		private function get_generic_license_status_message( $addon_type, $trans = false, $context = null ) {
			$addon_licenses = WP_Analytify_Pro_Addon_Licenses::instance();
			$method_name    = 'get_' . $addon_type . '_license_key';

			if ( ! method_exists( $addon_licenses, $method_name ) ) {
				return '';
			}

			$license               = $addon_licenses->$method_name();
			$api_response_provided = true;

			if ( empty( $license ) && ! $trans ) {
				$message = sprintf(
				// translators: %s is the settings URL.
					__( '<strong>Activate Your License</strong> &mdash; Please <a href="%s" class="">enter your license key</a> to enable priority support and plugin updates.', 'wp-analytify-pro' ),
					network_admin_url( 'admin.php?page=analytify-settings#settings' )
				);
				return $message;
			}

			if ( ! $trans ) {
				$transient_key = 'wpanalytify_' . $addon_type . '_license_response';
				$trans         = get_site_transient( $transient_key );

				if ( false === $trans ) {
					$check_method = 'check_' . $addon_type . '_license';
					if ( method_exists( $this, $check_method ) ) {
						$trans = $this->$check_method( $license );
					}
				}

				$trans                 = json_decode( $trans );
				$api_response_provided = false;
			} elseif ( is_string( $trans ) ) {
				$trans = json_decode( $trans );
			} elseif ( is_array( $trans ) ) {
				$trans = (object) $trans;
			}

			if ( ! is_object( $trans ) || ! isset( $trans->error ) ) {
				return '';
			}

			$errors  = $trans->error;
			$message = '';

			if ( 'expired' === $errors ) {
				$message_base = sprintf( '<strong>%s</strong> &mdash; ', __( 'Your License Has Expired', 'wp-analytify-pro' ) );
				// translators: %s is the account URL.
				$message_end = sprintf( __( 'Login to <a href="%s" target="blank">My Account</a> to renew. ', 'wp-analytify-pro' ), 'https://analytify.io/your-account/' );

				$contextual_messages = array(
					'default' => $message_base . $message_end,
					'update'  => $message_base . __( 'Updates are only available to those with an active license. ', 'wp-analytify-pro' ) . $message_end,
					'support' => $message_base . __( 'Only active licenses can submit support requests. ', 'wp-analytify-pro' ) . $message_end,
					'license' => $message_base . __( "All features will continue to work, but you won't be able to receive updates or email support. ", 'wp-analytify-pro' ) . $message_end,
				);

				if ( empty( $context ) ) {
					$context = 'default';
				}
				if ( ! empty( $contextual_messages[ $context ] ) ) {
					$message = $contextual_messages[ $context ];
				} elseif ( 'all' === $context ) {
					$message = $contextual_messages;
				}
			} elseif ( 'no_activations_left' === $errors ) {
				// translators: %s is the account URL.
				$message = sprintf( __( '<strong>No Activations Left</strong> &mdash; Please visit <a href="%s" target="_blank">My Account</a> to upgrade your license or deactivate a previous activation.', 'wp-analytify-pro' ), 'https://analytify.io/your-account/' );
			} elseif ( 'missing' === $errors ) {
				if ( ! $api_response_provided ) {
					// translators: %s is the account URL.
					$message = sprintf( __( '<strong>Your License Was Not Found</strong> &mdash; Please visit <a href="%s" target="_blank">My Account</a> to double check your license key.', 'wp-analytify-pro' ), 'https://analytify.io/your-account/' );
				} else {
					$error    = $errors; // $errors is already a string 'missing'.
					$message  = __( '<strong>Your License Was Not Found</strong> &mdash; ', 'wp-analytify-pro' );
					$message .= $error;
				}
			} else {
				$error   = is_array( $errors ) ? reset( $errors ) : $errors;
				$message = sprintf(
				// translators: %1$s is the mailto link, %2$s is the email address.
					__( '<strong>An Unexpected Error Occurred</strong> &mdash; Please contact us at <a href="%1$s">%2$s</a> and quote the following:', 'wp-analytify-pro' ),
					'mailto:support@analytify.io',
					'support@analytify.io'
				);
				$message .= sprintf( '<p>%s</p>', $error );
			}

			return $message;
		}

		/**
		 * Make API call to the license store.
		 *
		 * Logs transport errors and invalid JSON via
		 * {@see wp_analytify_pro_log_edd_license_request_issue()} (masked license).
		 * Top-level `null` from `json_decode()` is treated as failure.
		 *
		 * @since 9.0.0
		 * @param string $type       EDD action (e.g. check_license, get_version).
		 * @param string $license    License key.
		 * @param int    $product_id Product ID.
		 * @param string $store_url  Store URL.
		 * @return object|false Decoded object on success; false on failure.
		 */
		public function wp_analytify_api_call( $type, $license, $product_id, $store_url ) {
			$api_params = array(
				'edd_action' => $type,
				'license'    => ! empty( $license ) ? $license : false,
				'item_id'    => $product_id,
				'url'        => home_url(),
			);

			$response = wp_remote_get(
				esc_url_raw( add_query_arg( $api_params, $store_url ) ),
				array(
					'timeout'   => 15,
					'sslverify' => false,
				)
			);

			if ( is_wp_error( $response ) ) {
				wp_analytify_pro_log_edd_license_request_issue(
					'License API request failed (transport error).',
					'WP_Analytify_Pro_License_API::wp_analytify_api_call',
					$api_params,
					$response,
					array( 'store_url' => $store_url )
				);
				return false;
			}

			$body    = wp_remote_retrieve_body( $response );
			$decoded = json_decode( $body );

			if ( null === $decoded || ! is_object( $decoded ) ) {
				wp_analytify_pro_log_edd_license_request_issue(
					'License API returned unexpected or invalid JSON.',
					'WP_Analytify_Pro_License_API::wp_analytify_api_call',
					$api_params,
					$response,
					array( 'store_url' => $store_url )
				);
				return false;
			}

			return $decoded;
		}
	}
}
