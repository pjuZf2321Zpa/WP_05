<?php // phpcs:ignore WordPress.Files.FileName.InvalidClassFileName
/**
 * WP Analytify Pro CSV WooCommerce Exports Class
 *
 * This class handles WooCommerce CSV export functionality including:
 * - Sales countries
 * - ROI measurements
 * - Product performance
 * - Product lists analysis
 * - Product categories
 * - Coupons analysis
 *
 * @package WP_Analytify_Pro
 * @since 8.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_Analytify_Pro_CSV_WooCommerce_Exports' ) ) {

	/**
	 * WP Analytify Pro CSV WooCommerce Exports Class
	 *
	 * @since 1.0.0
	 */
	class WP_Analytify_Pro_CSV_WooCommerce_Exports {

		/**
		 * The main Analytify object.
		 *
		 * @var object|null
		 */
		private $wp_analytify;

		/**
		 * GA version (ga4 or ga3).
		 *
		 * @var string
		 */
		private $ga_mode;

		/**
		 * Selected 'start state'.
		 *
		 * @var string
		 */
		private $start_date;

		/**
		 * Selected 'End state'.
		 *
		 * @var string
		 */
		private $end_date;

		/**
		 * WC's currency symbol.
		 *
		 * @var string
		 */
		private $wc_currency_symbol = null;

		/**
		 * Set the main Analytify object and dates
		 *
		 * @param object $wp_analytify The main Analytify object.
		 * @param string $ga_mode GA mode.
		 * @param string $start_date Start date.
		 * @param string $end_date End date.
		 * @return void
		 */
		public function set_data( $wp_analytify, $ga_mode, $start_date, $end_date ) {
			$this->wp_analytify = $wp_analytify;
			$this->ga_mode      = $ga_mode;
			$this->start_date   = $start_date;
			$this->end_date     = $end_date;
		}

		/**
		 * WC's Top Sales Countries
		 *
		 * @version 9.1.1
		 * @return list<array<int, mixed>>
		 */
		public function export_top_sales_countries() {

			$api_limit = analytify_pro_csv_api_limit( 'analytify_api_limit_sales_countries', 10, 'WC' );

			$stats = array();

			if ( 'ga4' === $this->ga_mode && isset( $this->wp_analytify ) && is_object( $this->wp_analytify ) && method_exists( $this->wp_analytify, 'get_reports' ) ) {

				$stats_raw = $this->wp_analytify->get_reports(
					'show-woo-geographical-stats',
					array(
						'addToCarts',
						'itemViews',
					),
					$this->get_dates(),
					array(
						'country',
					),
					array(
						'type'  => 'metric',
						'name'  => 'itemViews',
						'order' => 'desc',
					),
					array(
						'logic'   => 'AND',
						'filters' => array(
							array(
								'type'           => 'dimension',
								'name'           => 'country',
								'match_type'     => 4,
								'value'          => '(not set)',
								'not_expression' => true,
							),
						),
					),
					$api_limit
				);

				if ( isset( $stats_raw['rows'] ) && $stats_raw['rows'] ) {
					foreach ( $stats_raw['rows'] as $row ) {
						$stats[] = array(
							'0' => $row['country'],
							'1' => $row['itemViews'],
							'2' => $row['addToCarts'],
						);
					}
				}
			}

			$columns = array(
				array(
					'0' => esc_html__( 'Country', 'wp-analytify-pro' ),
					'1' => esc_html__( 'Product Detail Views', 'wp-analytify-pro' ),
					'2' => esc_html__( 'Add To Carts', 'wp-analytify-pro' ),
				),
			);
			return array_merge( $columns, $stats );
		}

		/**
		 * WC's Measuring ROI
		 *
		 * @version 9.1.1
		 * @return list<array<int, mixed>>
		 */
		public function export_measuring_roi() {

			$api_limit = analytify_pro_csv_api_limit( 'analytify_api_limit_measuring_roi', 10, 'WC' );

			$stats = array();

			if ( 'ga4' === $this->ga_mode && isset( $this->wp_analytify ) && is_object( $this->wp_analytify ) && method_exists( $this->wp_analytify, 'get_reports' ) ) {
				$stats_raw = $this->wp_analytify->get_reports(
					'show-woo-roi-stats',
					array(
						'sessions',
						'bounceRate',
						'purchaseRevenue',
					),
					$this->get_dates(),
					array(
						'sourceMedium',
					),
					array(
						'type'  => 'metric',
						'name'  => 'purchaseRevenue',
						'order' => 'desc',
					),
					array(),
					$api_limit
				);

				if ( isset( $stats_raw['rows'] ) && $stats_raw['rows'] ) {
					$k = 0;
					foreach ( $stats_raw['rows'] as $row ) {
						++$k;
						$stats[] = array(
							'0' => $k,
							'1' => $row['sourceMedium'],
							'2' => class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' ) ? WPANALYTIFY_Utils::pretty_numbers( $row['sessions'] ) : $row['sessions'],
							'3' => class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' ) ? WPANALYTIFY_Utils::pretty_numbers( $row['bounceRate'] ) . '%' : $row['bounceRate'] . '%',
							'5' => $this->wc_currency_symbol() . number_format( $row['purchaseRevenue'], 2 ),
						);
					}
				}
			}

			$columns = array(
				array(
					'0' => esc_html__( 'No.', 'wp-analytify-pro' ),
					'1' => esc_html__( 'Source/Medium', 'wp-analytify-pro' ),
					'2' => esc_html__( 'Session', 'wp-analytify-pro' ),
					'3' => esc_html__( 'Bounce Rate', 'wp-analytify-pro' ),
					'5' => esc_html__( 'Transactions Revenue', 'wp-analytify-pro' ),
				),
			);
			return array_merge( $columns, $stats );
		}

		/**
		 * Export WC's product performance.
		 *
		 * @version 9.1.1
		 * @return list<array<int, mixed>>
		 */
		public function export_products_performance() {

			$api_limit = analytify_pro_csv_api_limit( 'analytify_api_limit_products_performance', 10, 'WC' );

			$stats = array();

			if ( 'ga4' === $this->ga_mode && isset( $this->wp_analytify ) && is_object( $this->wp_analytify ) && method_exists( $this->wp_analytify, 'get_reports' ) ) {
				$stats_raw = $this->wp_analytify->get_reports(
					'show-woo-product-performance-stats',
					array(
						'itemRevenue',
						'itemPurchaseQuantity',
						'cartToViewRate',
					),
					$this->get_dates(),
					array(
						'itemName',
					),
					array(
						'type'  => 'metric',
						'name'  => 'itemPurchaseQuantity',
						'order' => 'desc',
					),
					array(
						'logic'   => 'AND',
						'filters' => array(
							array(
								'type'           => 'dimension',
								'name'           => 'itemName',
								'match_type'     => 4,
								'value'          => '(not set)',
								'not_expression' => true,
							),
						),
					),
					$api_limit
				);

				if ( isset( $stats_raw['rows'] ) && $stats_raw['rows'] ) {
					foreach ( $stats_raw['rows'] as $row ) {
						$stats[] = array(
							'0' => $row['itemName'],
							'1' => $this->wc_currency_symbol() . number_format( $row['itemRevenue'], 2 ),
							'3' => $row['itemPurchaseQuantity'],
							'4' => number_format( $row['cartToViewRate'], 2 ) . '%',
							'5' => '',
						);
					}
				}
			}

			$columns = array(
				array(
					'0' => esc_html__( 'Name', 'wp-analytify-pro' ),
					'1' => esc_html__( 'Product Revenue', 'wp-analytify-pro' ),
					'3' => esc_html__( 'Quantity', 'wp-analytify-pro' ),
					'4' => esc_html__( 'Cart-to-Detail Rate', 'wp-analytify-pro' ),
					'5' => esc_html__( 'Buy-to-Detail Rate', 'wp-analytify-pro' ),
				),
			);
			return array_merge( $columns, $stats );
		}

		/**
		 * Export WC's product list.
		 *
		 * @version 9.1.1
		 * @return list<array<int, mixed>>
		 */
		public function export_product_lists_analysis() {

			$api_limit = analytify_pro_csv_api_limit( 'analytify_api_limit_product_lists_analysis', 10, 'WC' );

			$stats = array();

			if ( 'ga4' === $this->ga_mode && isset( $this->wp_analytify ) && is_object( $this->wp_analytify ) && method_exists( $this->wp_analytify, 'get_reports' ) ) {
				$stats_raw = $this->wp_analytify->get_reports(
					'show-woo-product-list-stats',
					array(
						'itemsViewedInList',
						'itemsClickedInList',
						'itemListClickThroughRate',
						'itemsAddedToCart',
						'itemsCheckedOut',
						'itemsPurchased',
						'itemRevenue',
					),
					$this->get_dates(),
					array(
						'itemListName',
					),
					array(
						'type'  => 'metric',
						'name'  => 'itemRevenue',
						'order' => 'desc',
					),
					array(
						'logic'   => 'AND',
						'filters' => array(
							array(
								'type'           => 'dimension',
								'name'           => 'itemListName',
								'match_type'     => 4,
								'value'          => '(not set)',
								'not_expression' => true,
							),
						),
					),
					$api_limit
				);

				if ( isset( $stats_raw['rows'] ) && $stats_raw['rows'] ) {
					$k = 0;
					foreach ( $stats_raw['rows'] as $row ) {
						++$k;
						$stats[] = array(
							'0' => $k,
							'1' => $row['itemListName'],
							'2' => $row['itemsViewedInList'],
							'3' => $row['itemsClickedInList'],
							'4' => number_format( $row['itemListClickThroughRate'], 2 ) . '%',
							'5' => $row['itemsAddedToCart'],
							'6' => $row['itemsCheckedOut'],
							'7' => $row['itemsPurchased'],
							'8' => $this->wc_currency_symbol() . number_format( $row['itemRevenue'], 2 ),
						);
					}
				}
			}

			$columns = array(
				array(
					'0' => esc_html__( 'No.', 'wp-analytify-pro' ),
					'1' => esc_html__( 'List Name', 'wp-analytify-pro' ),
					'2' => esc_html__( 'Product List Views', 'wp-analytify-pro' ),
					'3' => esc_html__( 'Product List Clicks', 'wp-analytify-pro' ),
					'4' => esc_html__( 'Product List CTR', 'wp-analytify-pro' ),
					'5' => esc_html__( 'Product Adds to Cart', 'wp-analytify-pro' ),
					'6' => esc_html__( 'Product Checkouts', 'wp-analytify-pro' ),
					'7' => esc_html__( 'Unique Purchases', 'wp-analytify-pro' ),
					'8' => esc_html__( 'Product Revenue', 'wp-analytify-pro' ),
				),
			);
			return array_merge( $columns, $stats );
		}

		/**
		 * WC's product categories export.
		 *
		 * @version 9.1.1
		 * @return list<array<int, mixed>>
		 */
		public function export_product_categories() {

			$api_limit = analytify_pro_csv_api_limit( 'analytify_api_limit_product_categories', 10, 'WC' );

			$stats = array();

			if ( 'ga4' === $this->ga_mode && isset( $this->wp_analytify ) && is_object( $this->wp_analytify ) && method_exists( $this->wp_analytify, 'get_reports' ) ) {
				$stats_raw = $this->wp_analytify->get_reports(
					'show-woo-categories-performance-stats',
					array(
						'itemRevenue',
						'itemPurchaseQuantity',
						'cartToViewRate',
					),
					$this->get_dates(),
					array(
						'itemCategory',
					),
					array(
						'type'  => 'metric',
						'name'  => 'itemPurchaseQuantity',
						'order' => 'desc',
					),
					array(
						'logic'   => 'AND',
						'filters' => array(
							array(
								'type'           => 'dimension',
								'name'           => 'itemCategory',
								'match_type'     => 4,
								'value'          => '(not set)',
								'not_expression' => true,
							),
						),
					),
					$api_limit
				);

				if ( isset( $stats_raw['rows'] ) && $stats_raw['rows'] ) {
					$k = 0;
					foreach ( $stats_raw['rows'] as $row ) {
						++$k;
						$stats[] = array(
							'0' => $k,
							'1' => $row['itemCategory'],
							'2' => $this->wc_currency_symbol() . number_format( $row['itemRevenue'], 2 ),
							'4' => $row['itemPurchaseQuantity'],
							'5' => number_format( $row['cartToViewRate'], 2 ) . '%',
							'6' => '',
						);
					}
				}
			}

			$columns = array(
				array(
					'0' => esc_html__( 'No.', 'wp-analytify-pro' ),
					'1' => esc_html__( 'Name', 'wp-analytify-pro' ),
					'2' => esc_html__( 'Product Revenue', 'wp-analytify-pro' ),
					'4' => esc_html__( 'Quantity', 'wp-analytify-pro' ),
					'5' => esc_html__( 'Cart-to-Detail Rate', 'wp-analytify-pro' ),
					'6' => esc_html__( 'Buy-to-Detail Rate', 'wp-analytify-pro' ),
				),
			);
			return array_merge( $columns, $stats );
		}

		/**
		 * WC's coupons analysis export.
		 *
		 * @version 9.1.1
		 * @return list<array<int, mixed>>
		 */
		public function export_coupons_analysis() {

			$api_limit = analytify_pro_csv_api_limit( 'analytify_api_limit_coupons_analysis', 10, 'WC' );

			$stats = array();

			if ( 'ga4' === $this->ga_mode && isset( $this->wp_analytify ) && is_object( $this->wp_analytify ) && method_exists( $this->wp_analytify, 'get_reports' ) ) {
				$stats_raw = $this->wp_analytify->get_reports(
					'show-woo-coupons-analysis-stats',
					array(
						'purchaseRevenue',
						'transactions',
					),
					$this->get_dates(),
					array(
						'orderCoupon',
					),
					array(
						'type'  => 'dimension',
						'name'  => 'orderCoupon',
						'order' => 'desc',
					),
					array(
						'logic'   => 'AND',
						'filters' => array(
							array(
								'type'           => 'dimension',
								'name'           => 'orderCoupon',
								'match_type'     => 4,
								'value'          => '(not set)',
								'not_expression' => true,
							),
						),
					),
					$api_limit
				);

				if ( isset( $stats_raw['rows'] ) && $stats_raw['rows'] ) {
					$k = 0;
					foreach ( $stats_raw['rows'] as $row ) {
						++$k;
						$stats[] = array(
							'0' => $k,
							'1' => $row['orderCoupon'],
							'2' => $this->wc_currency_symbol() . number_format( $row['purchaseRevenue'], 2 ),
							'3' => $row['transactions'],
							'4' => '',
						);
					}
				}
			}

			$columns = array(
				array(
					'0' => esc_html__( 'No.', 'wp-analytify-pro' ),
					'1' => esc_html__( 'Coupon Code', 'wp-analytify-pro' ),
					'2' => esc_html__( 'Revenue', 'wp-analytify-pro' ),
					'3' => esc_html__( 'Transactions', 'wp-analytify-pro' ),
					'4' => esc_html__( 'Average Order Value', 'wp-analytify-pro' ),
				),
			);
			return array_merge( $columns, $stats );
		}

		/**
		 * Returns WC currency symbol.
		 *
		 * @return string
		 */
		private function wc_currency_symbol() {

			if ( null === $this->wc_currency_symbol ) {
				$this->wc_currency_symbol = function_exists( 'get_woocommerce_currency_symbol' ) ? html_entity_decode( get_woocommerce_currency_symbol(), ENT_QUOTES, 'utf-8' ) : '';
			}
			return $this->wc_currency_symbol;
		}

		/**
		 * Returns start and end date as an array to be used for GA4's get_reports()
		 *
		 * @return array<string, string>
		 */
		private function get_dates() {
			return array(
				'start' => $this->start_date,
				'end'   => $this->end_date,
			);
		}
	}
}
