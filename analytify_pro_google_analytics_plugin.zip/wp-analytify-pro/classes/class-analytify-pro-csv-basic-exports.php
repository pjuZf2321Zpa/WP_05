<?php // phpcs:ignore WordPress.Files.FileName.InvalidClassFileName
/**
 * WP Analytify Pro CSV Basic Analytics Exports Class
 *
 * This class handles basic analytics CSV export functionality including:
 * - General stats
 * - Top pages
 * - Top countries
 * - Top cities
 * - Top keywords
 *
 * @package WP_Analytify_Pro
 * @since 8.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_Analytify_Pro_CSV_Basic_Exports' ) ) {

	/**
	 * WP Analytify Pro CSV Basic Analytics Exports Class
	 *
	 * @since 1.0.0
	 */
	class WP_Analytify_Pro_CSV_Basic_Exports {

		/**
		 * The main Analytify object.
		 *
		 * @var object
		 */
		private $wp_analytify;

		/**
		 * GA version (ga4 or ga3).
		 *
		 * @var string
		 */
		private $ga_mode;

		/**
		 * Selected 'start state'.
		 *
		 * @var string
		 */
		private $start_date;

		/**
		 * Selected 'End state'.
		 *
		 * @var string
		 */
		private $end_date;


		/**
		 * Set the main Analytify object and dates
		 *
		 * @version 7.0.5
		 * @param object $wp_analytify The main Analytify object.
		 * @param string $ga_mode GA mode.
		 * @param string $start_date Start date.
		 * @param string $end_date End date.
		 * @return void
		 */
		public function set_data( $wp_analytify, $ga_mode, $start_date, $end_date ) {
			$this->wp_analytify = $wp_analytify;
			$this->ga_mode      = $ga_mode;
			$this->start_date   = $start_date;
			$this->end_date     = $end_date;
		}

		/**
		 * Generates 'general-stats'.
		 *
		 * @version 9.1.1
		 * @return array<int, array<int, mixed>>
		 */
		public function export_general_stats() {

			$date_diff = $this->calculate_date_diff( null );

			$stats       = array();
			$device_data = array(
				'mobile'  => 0,
				'tablet'  => 0,
				'desktop' => 0,
			);

			if ( 'ga4' === $this->ga_mode && method_exists( $this->wp_analytify, 'get_reports' ) ) {

				$general_stats_raw = $this->wp_analytify->get_reports(
					'show-default-overall-dashboard',
					array(
						'sessions',
						'totalUsers',
						'screenPageViews',
						'averageSessionDuration',
						'bounceRate',
						'screenPageViewsPerSession',
						'engagedSessions',
						'userEngagementDuration',
						'activeUsers',
					),
					$this->get_dates(),
					array(
						'newVsReturning',
					),
					array(),
					array(),
					0,
					true
				);

				$general_stats = isset( $general_stats_raw['aggregations'] ) ? $general_stats_raw['aggregations'] : array();

				$new_users_count       = 0;
				$returning_users_count = 0;

				if ( ! empty( $general_stats_raw['rows'] ) && is_array( $general_stats_raw['rows'] ) ) {
					foreach ( $general_stats_raw['rows'] as $row ) {
						$type = strtolower( trim( $row['newVsReturning'] ?? '' ) );
						if ( 'new' === $type ) {
							$new_users_count += (int) ( $row['totalUsers'] ?? 0 );
						} elseif ( 'returning' === $type ) {
							$returning_users_count += (int) ( $row['totalUsers'] ?? 0 );
						}
					}
				}

				$device_category_stats = $this->wp_analytify->get_reports(
					'show-default-overall-device-dashboard',
					array(
						'sessions',
					),
					$this->get_dates(),
					array(
						'deviceCategory',
					),
					array(
						'type' => 'dimension',
						'name' => 'deviceCategory',
					),
					array(),
					0,
					true
				);

				if ( ! empty( $device_category_stats['rows'] ) && is_array( $device_category_stats['rows'] ) ) {
					foreach ( $device_category_stats['rows'] as $device ) {
						if ( isset( $device['deviceCategory'], $device_data[ $device['deviceCategory'] ] ) ) {
							$device_data[ $device['deviceCategory'] ] = $device['sessions'];
						}
					}
				}

				$browser_stats_raw = $this->wp_analytify->get_reports(
					'show-default-browser-breakdown-dashboard',
					array( 'sessions' ),
					$this->get_dates(),
					array( 'browser' ),
					array(
						'type'  => 'metric',
						'name'  => 'sessions',
						'order' => 'desc',
					),
					array(
						'logic'   => 'AND',
						'filters' => array(
							array(
								'type'           => 'dimension',
								'name'           => 'browser',
								'match_type'     => 4,
								'value'          => '(not set)',
								'not_expression' => true,
							),
						),
					),
					3,
					true
				);

				$pretty_number = static function ( $num ) {
					return class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' )
						? WPANALYTIFY_Utils::pretty_numbers( $num )
						: $num;
				};

				$stats = array(
					array(
						'Sessions',
						! empty( $general_stats['sessions'] ) ? $pretty_number( $general_stats['sessions'] ) : 0,
					),
					array(
						'Visitors',
						isset( $general_stats['totalUsers'] ) ? $general_stats['totalUsers'] : 0,
					),
					array(
						'Page Views',
						! empty( $general_stats['screenPageViews'] ) ? $pretty_number( $general_stats['screenPageViews'] ) : 0,
					),
					array(
						'Avg. Time On Site',
						! empty( $general_stats['averageSessionDuration'] )
							? wp_strip_all_tags(
								class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_time' )
									? WPANALYTIFY_Utils::pretty_time( $general_stats['averageSessionDuration'] )
									: $general_stats['averageSessionDuration']
							)
							: 0,
					),
					array(
						'Bounce Rate',
						! empty( $general_stats['bounceRate'] )
							? (
								class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'fraction_to_percentage' )
									? WPANALYTIFY_Utils::fraction_to_percentage( $general_stats['bounceRate'] ) . '%'
									: $general_stats['bounceRate'] . '%'
							)
							: '0%',
					),
					array(
						'Pages/Session',
						! empty( $general_stats['screenPageViewsPerSession'] )
							? round( $general_stats['screenPageViewsPerSession'], 2 ) . '%'
							: '0%',
					),
					array(
						'Engaged Sessions',
						isset( $general_stats['engagedSessions'] ) ? $general_stats['engagedSessions'] : 0,
					),
					array(
						'New Users',
						$pretty_number( $new_users_count ),
						'',
					),
					array(
						'Returning Users',
						$pretty_number( $returning_users_count ),
						'',
					),
					array(
						'Mobile Visitors',
						$device_data['mobile'] ? $pretty_number( $device_data['mobile'] ) : 0,
						'',
					),
					array(
						'Tablet Visitors',
						$device_data['tablet'] ? $pretty_number( $device_data['tablet'] ) : 0,
						'',
					),
					array(
						'Desktop Visitors',
						$device_data['desktop'] ? $pretty_number( $device_data['desktop'] ) : 0,
						'',
					),
				);

				if ( ! empty( $browser_stats_raw['rows'] ) && is_array( $browser_stats_raw['rows'] ) ) {
					foreach ( $browser_stats_raw['rows'] as $browser_row ) {
						if ( empty( $browser_row['browser'] ) ) {
							continue;
						}

						$stats[] = array(
							$browser_row['browser'],
							$pretty_number( $browser_row['sessions'] ?? 0 ),
							'',
						);
					}
				}
			}

			$columns = array(
				array(
					'0' => esc_html__( 'Stats Name', 'wp-analytify-pro' ),
					'1' => esc_html__( 'Stats Value', 'wp-analytify-pro' ),
					'2' => esc_html__( 'Conversion Rate', 'wp-analytify-pro' ),
				),
			);
			return array_merge( $columns, $stats );
		}

		/**
		 * Generates 'top-pages'.
		 *
		 * @version 9.1.1
		 * @return list<array<int, mixed>>
		 */
		public function export_top_pages() {

			$api_limit = analytify_pro_csv_api_limit( 'analytify_api_limit_top_pages_stats', 100 );

			$site_url = $this->get_profile_info( 'website_url' );
			if ( empty( $site_url ) ) {
				$site_url = home_url();
			}
			$site_url = untrailingslashit( (string) $site_url );

			$stats = array();

			if ( 'ga4' === $this->ga_mode && method_exists( $this->wp_analytify, 'get_reports' ) ) {

				$stats_raw = $this->wp_analytify->get_reports(
					'show-default-top-pages-dashboard',
					array(
						'screenPageViews',
						'averageSessionDuration',
						'bounceRate',
					),
					$this->get_dates(),
					array(
						'pageTitle',
						'pagePath',
					),
					array(
						'type'  => 'metric',
						'name'  => 'screenPageViews',
						'order' => 'desc',
					),
					array(
						'logic'   => 'AND',
						'filters' => array(
							array(
								'type'           => 'dimension',
								'name'           => 'pageTitle',
								'match_type'     => 4,
								'value'          => '(not set)',
								'not_expression' => true,
							),
							array(
								'type'           => 'dimension',
								'name'           => 'pagePath',
								'match_type'     => 4,
								'value'          => '(not set)',
								'not_expression' => true,
							),
						),
					),
					$api_limit,
					false
				);

				if ( isset( $stats_raw['rows'] ) && $stats_raw['rows'] ) {
					foreach ( $stats_raw['rows'] as $row ) {
						$views = $row['screenPageViews'] ? $row['screenPageViews'] : 0;
						if ( $views < 1 ) {
							continue;
						}
						$page_path = isset( $row['pagePath'] ) ? (string) $row['pagePath'] : '';
						if ( '' !== $page_path && '/' !== $page_path[0] ) {
							$page_path = '/' . $page_path;
						}
						$stats[] = array(
							'0' => $row['pageTitle'],
							'1' => $site_url . $page_path,
							'2' => class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' ) ? WPANALYTIFY_Utils::pretty_numbers( $views ) : $views,
							'3' => $row['averageSessionDuration'] ? wp_strip_all_tags( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_time' ) ? WPANALYTIFY_Utils::pretty_time( $row['averageSessionDuration'] ) : $row['averageSessionDuration'] ) : 0,
							'4' => ( $row['bounceRate'] ? ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'fraction_to_percentage' ) ? WPANALYTIFY_Utils::fraction_to_percentage( $row['bounceRate'] ) : $row['bounceRate'] ) : 0 ) . '%',
						);
					}
				}
			}

			$columns = array(
				array(
					'0' => esc_html__( 'Title', 'wp-analytify-pro' ),
					'1' => esc_html__( 'Link', 'wp-analytify-pro' ),
					'2' => esc_html__( 'Views', 'wp-analytify-pro' ),
					'3' => esc_html__( 'Avg. Time', 'wp-analytify-pro' ),
					'4' => esc_html__( 'Bounce Rate', 'wp-analytify-pro' ),
				),
			);
			return array_merge( $columns, $stats );
		}


		/**
		 * Generates 'top-countries'.
		 *
		 * @version 9.1.1
		 * @return list<array<int, mixed>>
		 */
		public function export_top_countries() {
			// API limit.
			$api_limit = analytify_pro_csv_api_limit( 'analytify_api_limit_country_stats', 5 );

			$stats = array();

			if ( 'ga4' === $this->ga_mode && method_exists( $this->wp_analytify, 'get_reports' ) ) {
				$stats_raw = $this->wp_analytify->get_reports(
					'show-geographic-countries-dashboard',
					array(
						'sessions',
					),
					$this->get_dates(),
					array(
						'country',
					),
					array(
						'type'  => 'dimension',
						'name'  => 'sessions',
						'order' => 'desc',
					),
					array(
						'logic'   => 'AND',
						'filters' => array(
							array(
								'type'           => 'dimension',
								'name'           => 'country',
								'match_type'     => 4,
								'value'          => '(not set)',
								'not_expression' => true,
							),
						),
					),
					$api_limit,
					false
				);

				if ( isset( $stats_raw['rows'] ) && $stats_raw['rows'] ) {
					foreach ( $stats_raw['rows'] as $row ) {
						$stats[] = array(
							'0' => $row['country'],
							'1' => $row['sessions'],
						);
					}
				}
			}

			$columns = array(
				array(
					'0' => esc_html__( 'Country', 'wp-analytify-pro' ),
					'1' => esc_html__( 'Views', 'wp-analytify-pro' ),
				),
			);

			$result = array_merge( $columns, $stats );
			return $result;
		}

		/**
		 * Generates 'top-cities'.
		 *
		 * @version 9.1.1
		 * @return list<array<int, mixed>>
		 */
		public function export_top_cities() {

			// API limit.
			$api_limit = analytify_pro_csv_api_limit( 'analytify_api_limit_city_stats', 5 );

			$stats = array();

			if ( 'ga4' === $this->ga_mode && method_exists( $this->wp_analytify, 'get_reports' ) ) {

				$stats_raw = $this->wp_analytify->get_reports(
					'show-geographic-countries-dashboard',
					array(
						'sessions',
					),
					$this->get_dates(),
					array(
						'city',
						'country',
					),
					array(
						'type'  => 'metric',
						'name'  => 'sessions',
						'order' => 'desc',
					),
					array(
						'logic'   => 'AND',
						'filters' => array(
							array(
								'type'           => 'dimension',
								'name'           => 'city',
								'match_type'     => 4,
								'value'          => '(not set)',
								'not_expression' => true,
							),
							array(
								'type'           => 'dimension',
								'name'           => 'country',
								'match_type'     => 4,
								'value'          => '(not set)',
								'not_expression' => true,
							),
						),
					),
					$api_limit,
					false
				);

				if ( isset( $stats_raw['rows'] ) && $stats_raw['rows'] ) {
					foreach ( $stats_raw['rows'] as $row ) {
						$stats[] = array(
							'0' => $row['city'],
							'1' => $row['country'],
							'2' => $row['sessions'],
						);
					}
				}
			}

			$columns = array(
				array(
					'0' => esc_html__( 'City', 'wp-analytify-pro' ),
					'1' => esc_html__( 'Country', 'wp-analytify-pro' ),
					'2' => esc_html__( 'Views', 'wp-analytify-pro' ),
				),
			);
			return array_merge( $columns, $stats );
		}

		/**
		 * Generates 'top-keywords' CSV rows (Keyword, Clicks, Impressions, CTR, Avg. Position).
		 *
		 * @version 9.1.1
		 * @return non-empty-list<array{mixed, mixed}>|false
		 */
		public function export_top_keywords() {

			// API limit.
			$api_limit = analytify_pro_csv_api_limit( 'analytify_api_limit_keywords_stats', 10 );

			$stats = array();

			if ( 'ga4' === $this->ga_mode && method_exists( $this->wp_analytify, 'get_search_console_stats' ) ) {

				$stats_raw = $this->wp_analytify->get_search_console_stats(
					'show-default-keyword-dashboard',
					$this->get_dates(),
					$api_limit
				);

				if ( isset( $stats_raw['error']['status'] ) && isset( $stats_raw['error']['message'] ) ) {
					return false;
				}

				if ( ! empty( $stats_raw['response']['rows'] ) && is_array( $stats_raw['response']['rows'] ) ) {
					foreach ( $stats_raw['response']['rows'] as $row ) {
						$stats[] = array(
							'0' => isset( $row['keys'][0] ) ? $row['keys'][0] : '',
							'1' => isset( $row['clicks'] ) ? $row['clicks'] : 0,
							'2' => isset( $row['impressions'] ) ? $row['impressions'] : 0,
							'3' => isset( $row['ctr'] ) ? number_format( (float) $row['ctr'] * 100, 1 ) . '%' : '0%',
							'4' => isset( $row['position'] ) ? number_format( (float) $row['position'], 1 ) : 0,
						);
					}
				}
			} else {
				// UA / non-GA4: keyword + sessions only — keep header aligned with row shape.
				$stats_raw = method_exists( $this->wp_analytify, 'pa_get_analytics_dashboard' ) ? $this->wp_analytify->pa_get_analytics_dashboard( 'ga:sessions', $this->start_date, $this->end_date, 'ga:keyword', '-ga:sessions', false, $api_limit ) : array();
				if ( isset( $stats_raw['rows'] ) && is_array( $stats_raw['rows'] ) ) {
					foreach ( $stats_raw['rows'] as $row ) {
						$stats[] = array(
							'0' => isset( $row[0] ) ? $row[0] : '',
							'1' => isset( $row[1] ) ? $row[1] : 0,
						);
					}
				}

				$columns = array(
					array(
						'0' => esc_html__( 'Keyword', 'wp-analytify-pro' ),
						'1' => esc_html__( 'Sessions', 'wp-analytify-pro' ),
					),
				);
				return array_merge( $columns, $stats );
			}

			$columns = array(
				array(
					'0' => esc_html__( 'Keyword', 'wp-analytify-pro' ),
					'1' => esc_html__( 'Clicks', 'wp-analytify-pro' ),
					'2' => esc_html__( 'Impressions', 'wp-analytify-pro' ),
					'3' => esc_html__( 'CTR', 'wp-analytify-pro' ),
					'4' => esc_html__( 'Avg. Position', 'wp-analytify-pro' ),
				),
			);
			return array_merge( $columns, $stats );
		}

		/**
		 * Calculates compare start and end date, also returns the difference in days.
		 *
		 * @version 7.0.5
		 * @param array<string, string>|null $date Start and end dates.
		 * @return array{start_date: string|false, end_date: string, diff_days: string}|false
		 */
		private function calculate_date_diff( $date ) {

			if ( null === $date ) {
				$start_date = $this->start_date;
				$end_date   = $this->end_date;
			} else {
				$start_date = $date['start'];
				$end_date   = $date['end'];
			}

			if ( $start_date === $end_date ) {
				return false;
			}

			$end_date_obj       = date_create( $end_date );
			$start_date_obj     = date_create( $start_date );
			$diff               = ( $end_date_obj && $start_date_obj ) ? date_diff( $end_date_obj, $start_date_obj ) : false;
			$start_timestamp    = $diff ? strtotime( $start_date . $diff->format( ' %R%a days' ) ) : false;
			$compare_start_date = $diff && $start_timestamp ? wp_date( 'Y-m-d', (int) $start_timestamp ) : $start_date;
			$compare_end_date   = $start_date;
			$diff_days          = $diff ? $diff->format( '%a' ) : '0';

			return array(
				'start_date' => $compare_start_date,
				'end_date'   => $compare_end_date,
				'diff_days'  => (string) $diff_days,
			);
		}


		/**
		 * Returns start and end date as an array to be used for GA4's get_reports()
		 *
		 * @version 7.0.5
		 * @return array<string, string>
		 */
		private function get_dates() {
			return array(
				'start' => $this->start_date,
				'end'   => $this->end_date,
			);
		}


		/**
		 * Get profile related data based on the key (option) provided.
		 *
		 * @version 7.0.5
		 * @param string $key Option name.
		 * @return string|null
		 */
		private function get_profile_info( $key ) {
			$dashboard_profile_id = '';
			if ( $this->wp_analytify && is_object( $this->wp_analytify ) && isset( $this->wp_analytify->settings ) && method_exists( $this->wp_analytify->settings, 'get_option' ) ) {
				$dashboard_profile_id = $this->wp_analytify->settings->get_option( 'profile_for_dashboard', 'wp-analytify-profile' );
			}
			switch ( $key ) {
				case 'profile_id':
					return $dashboard_profile_id;
				case 'website_url':
					return class_exists( 'WP_ANALYTIFY_FUNCTIONS' ) && method_exists( 'WP_ANALYTIFY_FUNCTIONS', 'search_profile_info' ) ? WP_ANALYTIFY_FUNCTIONS::search_profile_info( $dashboard_profile_id, 'websiteUrl' ) : '';
				default:
					return null;
			}
		}
	}
}
