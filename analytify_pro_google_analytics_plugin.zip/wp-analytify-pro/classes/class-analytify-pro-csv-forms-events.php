<?php // phpcs:ignore WordPress.Files.FileName.InvalidClassFileName
/**
 * WP Analytify Pro CSV Forms & Events Exports Class
 *
 * This class handles forms and events CSV export functionality including:
 * - Forms dashboard
 * - Event tracking (external links, downloads, tel, affiliate, mail)
 *
 * @package WP_Analytify_Pro
 * @since 8.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_Analytify_Pro_CSV_Forms_Events_Exports' ) ) {

	/**
	 * WP Analytify Pro CSV Forms & Events Exports Class
	 *
	 * @since 1.0.0
	 */
	class WP_Analytify_Pro_CSV_Forms_Events_Exports {

		/**
		 * The main Analytify object.
		 *
		 * @var object|null
		 */
		private $wp_analytify;

		/**
		 * GA version (ga4 or ga3).
		 *
		 * @var string
		 */
		private $ga_mode;

		/**
		 * Selected 'start state'.
		 *
		 * @var string
		 */
		private $start_date;

		/**
		 * Selected 'End state'.
		 *
		 * @var string
		 */
		private $end_date;

		/**
		 * Current export type for event tracking.
		 *
		 * @var string
		 */
		private $type;

		/**
		 * Set the main Analytify object and dates
		 *
		 * @param object|null $wp_analytify The main Analytify object.
		 * @param string      $ga_mode GA mode.
		 * @param string      $start_date Start date.
		 * @param string      $end_date End date.
		 * @param string      $type Export type for event tracking.
		 * @return void
		 */
		public function set_data( $wp_analytify, $ga_mode, $start_date, $end_date, $type = '' ) {
			$this->wp_analytify = $wp_analytify;
			$this->ga_mode      = $ga_mode;
			$this->start_date   = $start_date;
			$this->end_date     = $end_date;
			$this->type         = $type;
		}

		/**
		 * Forms dashboard (individual sections).
		 *
		 * @version 9.1.1
		 *
		 * @param string $form Form category.
		 * @return array<int|string, mixed>
		 */
		public function export_forms_dashboard( $form ) {

			// API limit.
			$api_limit = (int) apply_filters( 'analytify_api_limit_forms_addon', 100, $this->ga_mode );

			$stats = array();

			if ( 'ga4' === $this->ga_mode && isset( $this->wp_analytify ) && method_exists( $this->wp_analytify, 'get_reports' ) ) {
				$raw_report = $this->wp_analytify->get_reports(
					'show-analytify-forms-dashboard',
					array(
						'eventCount',
					),
					$this->get_dates(),
					array(
						'customEvent:wpa_category',
						'customEvent:wpa_link_action',
						'customEvent:wpa_link_label',
					),
					array(
						'type'  => 'metric',
						'name'  => 'eventCount',
						'order' => 'desc',
					),
					array(
						'logic'   => 'AND',
						'filters' => array(
							array(
								'type'       => 'dimension',
								'name'       => 'customEvent:wpa_category',
								'match_type' => 1,
								'value'      => $form,
							),
						),
					),
					$api_limit,
					false,
				);

				// Break the report into separate forms for submission and impression.
				if ( isset( $raw_report['rows'] ) && ! empty( $raw_report['rows'] ) ) {
					foreach ( $raw_report['rows'] as $raw_rows ) {
						$_ct   = $raw_rows['customEvent:wpa_category'];
						$_lb   = $raw_rows['customEvent:wpa_link_label'];
						$_ac   = $raw_rows['customEvent:wpa_link_action'];
						$count = $raw_rows['eventCount'];

						$stats = apply_filters( 'analytify_forms_row_format', $stats, $_ct, $_lb, $_ac, $count );
					}
				}
			} else {
				$raw_report = isset( $this->wp_analytify ) && method_exists( $this->wp_analytify, 'pa_get_analytics_dashboard' ) ? $this->wp_analytify->pa_get_analytics_dashboard( 'ga:totalEvents', $this->start_date, $this->end_date, 'ga:eventCategory,ga:eventAction,ga:eventLabel', '-ga:totalEvents', 'ga:eventCategory=@' . $form, $api_limit ) : array();

				// Break the report into separate forms for submission and impression.
				if ( isset( $raw_report['rows'] ) && ! empty( $raw_report['rows'] ) ) {
					foreach ( $raw_report['rows'] as $raw_rows ) {
						$_ct   = $raw_rows[0];
						$_lb   = $raw_rows[2];
						$_ac   = $raw_rows[1];
						$count = $raw_rows[3];

						$stats = apply_filters( 'analytify_forms_row_format', $stats, $_ct, $_lb, $_ac, $count );
					}
				}
			}

			if ( ! empty( $stats ) ) {
				foreach ( $stats[ $form ]['stats'] as &$item ) {
					$impressions             = isset( $item['impression'] ) ? $item['impression'] : 0;
					$submissions             = isset( $item['submission'] ) ? $item['submission'] : 0;
					$conversion_rate         = ( $impressions > 0 ) ? ( $submissions / $impressions ) * 100 : 0;
					$item['conversion_rate'] = round( $conversion_rate, 2 );
				}

				$stats = array_map(
					function ( $item ) {
						return array(
							isset( $item['id'] ) ? $item['id'] : '', // Form title or name.
							isset( $item['title'] ) ? $item['title'] : '', // Form title or name.
							isset( $item['impression'] ) ? $item['impression'] : 0, // Impressions count.
							isset( $item['submission'] ) ? $item['submission'] : 0, // Submissions count.
							isset( $item['conversion_rate'] ) ? $item['conversion_rate'] : 0, // Conversion rate.
						);
					},
					array_values( $stats[ $form ]['stats'] )
				);
			}

			if ( 'analytify_form_custom' === $form ) {
				$columns = array(
					array(
						esc_html__( 'Name', 'wp-analytify-pro' ),
						esc_html__( 'Impressions', 'wp-analytify-pro' ),
						esc_html__( 'Submissions', 'wp-analytify-pro' ),
						esc_html__( 'Conversion Rate', 'wp-analytify-pro' ),
					),
				);
			} else {
				$columns = array(
					array(
						esc_html__( 'Form ID', 'wp-analytify-pro' ),
						esc_html__( 'Name', 'wp-analytify-pro' ),
						esc_html__( 'Impressions', 'wp-analytify-pro' ),
						esc_html__( 'Submissions', 'wp-analytify-pro' ),
						esc_html__( 'Conversion Rate', 'wp-analytify-pro' ),
					),
				);
			}

			return array_merge( $columns, is_array( $stats ) ? $stats : array() );
		}

		/**
		 * Generates events tracking dashboard (individual sections).
		 *
		 * @version 9.1.1
		 * @return list<array<int, mixed>>|false
		 */
		public function export_event_tracking_section() {

			switch ( $this->type ) {
				case 'external-links':
					$section = 'external';
					break;

				case 'download-links':
					$section = 'download';
					break;

				case 'tel-links':
					$section = 'tel';
					break;

				case 'affiliate-links':
					$section = 'outbound-link';
					break;

				case 'mail-links':
					$section = 'mail';
					break;

				default:
					return false;
			}

			// API limit.
			$api_limit = analytify_pro_csv_api_limit( 'analytify_api_limit_events_tracking_stats', 200 );

			$stats = array();

			$categories = array( 'external', 'download', 'tel', 'outbound-link', 'mail' );
			if ( ! in_array( $section, $categories, true ) ) {
				return $stats;
			}

			if ( 'ga4' === $this->ga_mode && isset( $this->wp_analytify ) && method_exists( $this->wp_analytify, 'get_reports' ) ) {
				$stats_raw = $this->wp_analytify->get_reports(
					'show-default-events-tracking',
					array(
						'eventCount',
					),
					$this->get_dates(),
					array(
						'customEvent:wpa_category',
						'customEvent:wpa_link_label',
						'customEvent:wpa_link_action',
					),
					array(
						'type'  => 'metric',
						'name'  => 'eventCount',
						'order' => 'desc',
					),
					array(
						'logic'   => 'AND',
						'filters' => array(
							array(
								'type'       => 'dimension',
								'name'       => 'customEvent:wpa_category',
								'match_type' => '1',
								'value'      => $section,
							),
						),
					),
					$api_limit,
					false
				);
				if ( isset( $stats_raw['rows'] ) && $stats_raw['rows'] ) {
					foreach ( $stats_raw['rows'] as $row ) {
						$stats[] = array(
							'0' => $row['customEvent:wpa_link_label'],
							'1' => $row['customEvent:wpa_link_action'],
							'2' => class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' ) ? WPANALYTIFY_Utils::pretty_numbers( $row['eventCount'] ) : $row['eventCount'],
						);
					}
				}
			}

			$columns = array(
				array(
					'0' => esc_html__( 'Label', 'wp-analytify-pro' ),
					'1' => esc_html__( 'Link', 'wp-analytify-pro' ),
					'2' => esc_html__( 'Clicks', 'wp-analytify-pro' ),
				),
			);
			return array_merge( $columns, is_array( $stats ) ? $stats : array() );
		}

		/**
		 * Returns start and end date as an array to be used for GA4's get_reports()
		 *
		 * @return array<string, string>
		 */
		private function get_dates() {
			return array(
				'start' => $this->start_date,
				'end'   => $this->end_date,
			);
		}
	}
}
