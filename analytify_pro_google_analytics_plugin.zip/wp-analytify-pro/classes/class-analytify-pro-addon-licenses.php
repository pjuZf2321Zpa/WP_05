<?php
// phpcs:ignoreFile WordPress.Files.FileName.InvalidClassFileName
/**
 * WP Analytify Pro Addon Licenses Class
 *
 * This class handles addon-specific license functionality including:
 * - WooCommerce, EDD, Email, Campaigns, Dimensions, Authors, Forms, Events Tracking, Goals licenses
 * - License key retrieval and status checking for each addon
 *
 * @package WP_Analytify_Pro
 * @since 8.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_Analytify_Pro_Addon_Licenses' ) ) {

	/**
	 * WP Analytify Pro Addon Licenses Class
	 *
	 * Handles addon-specific license functionality.
	 *
	 * @since 1.0.0
	 */
	class WP_Analytify_Pro_Addon_Licenses {

		/**
		 * The one true WP_Analytify_Pro_Addon_Licenses instance.
		 *
		 * @var WP_Analytify_Pro_Addon_Licenses|null $instance
		 * @since 1.0.0
		 */
		private static $instance;

		/**
		 * Get active instance
		 *
		 * @access public
		 * @since 1.0.0
		 * @return WP_Analytify_Pro_Addon_Licenses The one true WP_Analytify_Pro_Addon_Licenses
		 */
		public static function instance() {
			if ( ! self::$instance ) {
				self::$instance = new WP_Analytify_Pro_Addon_Licenses();
				self::$instance->init();
			}
			return self::$instance;
		}

		/**
		 * Initialize the class
		 *
		 * @access private
		 * @since 1.0.0
		 * @return void
		 */
		private function init() {
			$this->hooks();
		}

		/**
		 * Run action and filter hooks
		 *
		 * @access private
		 * @since 1.0.0
		 * @return void
		 */
		private function hooks() {
			// Add hooks for addon license management if needed.
		}

		// ========================================
		// WOOCOMMERCE LICENSE METHODS
		// ========================================

		/**
		 * Check if WooCommerce license is defined as constant
		 *
		 * @return bool True if constant defined.
		 * @since 1.0.0
		 */
		public function is_woo_license_constant() {
			return defined( 'WPANALYTIFY_WOO_LICENSE' );
		}

		/**
		 * Get WooCommerce license key
		 *
		 * @param bool $addon Addon parameter (unused but kept for compatibility).
		 * @return string|false License key or false.
		 * @since 1.0.0
		 */
		public function get_woo_license_key( $addon = false ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found
			$license = trim( get_option( 'analytify_woo_license_key' ) );
			return $this->is_woo_license_constant() ? ( defined( 'WPANALYTIFY_WOO_LICENSE' ) ? WPANALYTIFY_WOO_LICENSE : '' ) : $license;
		}

		/**
		 * Set WooCommerce license key
		 *
		 * @param string               $key License key.
		 * @param array<string, mixed> $load_settings Current settings array.
		 * @return void
		 * @since 1.0.0
		 */
		public function set_woo_license_key( $key, &$load_settings ) {
			$load_settings['woo_license'] = $key;
			update_site_option( 'wpanalytify_settings', $load_settings );
		}

		// ========================================
		// EDD LICENSE METHODS
		// ========================================

		/**
		 * Check if EDD license is defined as constant
		 *
		 * @return bool True if constant defined.
		 * @since 1.0.0
		 */
		public function is_edd_license_constant() {
			return defined( 'WPANALYTIFY_EDD_LICENSE' );
		}

		/**
		 * Get EDD license key
		 *
		 * @param bool $addon Addon parameter (unused but kept for compatibility).
		 * @return string|false License key or false.
		 * @since 1.0.0
		 */
		public function get_edd_license_key( $addon = false ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found
			$license = trim( get_option( 'analytify_edd_license_key' ) );
			return $this->is_edd_license_constant() ? ( defined( 'WPANALYTIFY_EDD_LICENSE' ) ? WPANALYTIFY_EDD_LICENSE : '' ) : $license;
		}

		/**
		 * Set EDD license key
		 *
		 * @param string               $key License key.
		 * @param array<string, mixed> $load_settings Current settings array.
		 * @return void
		 * @since 1.0.0
		 */
		public function set_edd_license_key( $key, &$load_settings ) {
			$load_settings['edd_license'] = $key;
			update_site_option( 'wpanalytify_settings', $load_settings );
		}

		// ========================================
		// EMAIL LICENSE METHODS
		// ========================================

		/**
		 * Check if Email license is defined as constant
		 *
		 * @return bool True if constant defined.
		 * @since 1.0.0
		 */
		public function is_email_license_constant() {
			return defined( 'WPANALYTIFY_EMAIL_LICENSE' );
		}

		/**
		 * Get Email license key
		 *
		 * @param bool $addon Addon parameter (unused but kept for compatibility).
		 * @return string|false License key or false.
		 * @since 1.0.0
		 */
		public function get_email_license_key( $addon = false ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found
			$license = trim( get_option( 'analytify_email_license_key' ) );
			return $this->is_email_license_constant() ? ( defined( 'WPANALYTIFY_EMAIL_LICENSE' ) ? WPANALYTIFY_EMAIL_LICENSE : '' ) : $license;
		}

		/**
		 * Set Email license key
		 *
		 * @param string               $key License key.
		 * @param array<string, mixed> $load_settings Current settings array.
		 * @return void
		 * @since 1.0.0
		 */
		public function set_email_license_key( $key, &$load_settings ) {
			$load_settings['email_license'] = $key;
			update_site_option( 'wpanalytify_settings', $load_settings );
		}

		// ========================================
		// CAMPAIGNS LICENSE METHODS
		// ========================================

		/**
		 * Check if Campaigns license is defined as constant
		 *
		 * @return bool True if constant defined.
		 * @since 1.0.0
		 */
		public function is_campaigns_license_constant() {
			return defined( 'WPANALYTIFY_CAMPAIGNS_LICENSE' );
		}

		/**
		 * Get Campaigns license key
		 *
		 * @param bool $addon Addon parameter (unused but kept for compatibility).
		 * @return string|false License key or false.
		 * @since 1.0.0
		 */
		public function get_campaigns_license_key( $addon = false ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found
			$license = trim( get_option( 'analytify_campaigns_license_key' ) );
			return $this->is_campaigns_license_constant() ? ( defined( 'WPANALYTIFY_CAMPAIGNS_LICENSE' ) ? WPANALYTIFY_CAMPAIGNS_LICENSE : '' ) : $license;
		}

		/**
		 * Set Campaigns license key
		 *
		 * @param string               $key License key.
		 * @param array<string, mixed> $load_settings Current settings array.
		 * @return void
		 * @since 1.0.0
		 */
		public function set_campaigns_license_key( $key, &$load_settings ) {
			$load_settings['campaigns_license'] = $key;
			update_site_option( 'wpanalytify_settings', $load_settings );
		}

		// ========================================
		// DIMENSIONS LICENSE METHODS
		// ========================================

		/**
		 * Check if Dimensions license is defined as constant
		 *
		 * @return bool True if constant defined.
		 * @since 1.0.0
		 */
		public function is_dimensions_license_constant() {
			return defined( 'WPANALYTIFY_DIMENSIONS_LICENSE' );
		}

		/**
		 * Get Dimensions license key
		 *
		 * @param bool $addon Addon parameter (unused but kept for compatibility).
		 * @return string|false License key or false.
		 * @since 1.0.0
		 */
		public function get_dimensions_license_key( $addon = false ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found
			$license = trim( get_option( 'analytify_dimensions_license_key' ) );
			return $this->is_dimensions_license_constant() ? ( defined( 'WPANALYTIFY_DIMENSIONS_LICENSE' ) ? WPANALYTIFY_DIMENSIONS_LICENSE : '' ) : $license;
		}

		/**
		 * Set Dimensions license key
		 *
		 * @param string               $key License key.
		 * @param array<string, mixed> $load_settings Current settings array.
		 * @return void
		 * @since 1.0.0
		 */
		public function set_dimensions_license_key( $key, &$load_settings ) {
			$load_settings['dimensions_license'] = $key;
			update_site_option( 'wpanalytify_settings', $load_settings );
		}

		// ========================================
		// AUTHORS LICENSE METHODS
		// ========================================

		/**
		 * Check if Authors license is defined as constant
		 *
		 * @return bool True if constant defined.
		 * @since 1.0.0
		 */
		public function is_authors_license_constant() {
			return defined( 'WPANALYTIFY_AUTHORS_LICENSE' );
		}

		/**
		 * Get Authors license key
		 *
		 * @param bool $addon Addon parameter (unused but kept for compatibility).
		 * @return string|false License key or false.
		 * @since 1.0.0
		 */
		public function get_authors_license_key( $addon = false ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found
			$license = trim( get_option( 'analytify_authors_license_key' ) );
			return $this->is_authors_license_constant() ? ( defined( 'WPANALYTIFY_AUTHORS_LICENSE' ) ? WPANALYTIFY_AUTHORS_LICENSE : '' ) : $license;
		}

		/**
		 * Set Authors license key
		 *
		 * @param string               $key License key.
		 * @param array<string, mixed> $load_settings Current settings array.
		 * @return void
		 * @since 1.0.0
		 */
		public function set_authors_license_key( $key, &$load_settings ) {
			$load_settings['authors_license'] = $key;
			update_site_option( 'wpanalytify_settings', $load_settings );
		}

		// ========================================
		// FORMS LICENSE METHODS
		// ========================================

		/**
		 * Check if Forms license is defined as constant
		 *
		 * @return bool True if constant defined.
		 * @since 1.0.0
		 */
		public function is_forms_license_constant() {
			return defined( 'WPANALYTIFY_FORMS_LICENSE' );
		}

		/**
		 * Get Forms license key
		 *
		 * @param bool $addon Addon parameter (unused but kept for compatibility).
		 * @return string|false License key or false.
		 * @since 1.0.0
		 */
		public function get_forms_license_key( $addon = false ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found
			$license = trim( get_option( 'analytify_forms_license_key' ) );
			return $this->is_forms_license_constant() ? ( defined( 'WPANALYTIFY_FORMS_LICENSE' ) ? WPANALYTIFY_FORMS_LICENSE : '' ) : $license;
		}

		/**
		 * Set Forms license key
		 *
		 * @param string               $key License key.
		 * @param array<string, mixed> $load_settings Current settings array.
		 * @return void
		 * @since 1.0.0
		 */
		public function set_forms_license_key( $key, &$load_settings ) {
			$load_settings['forms_license'] = $key;
			update_site_option( 'wpanalytify_settings', $load_settings );
		}

		// ========================================
		// EVENTS TRACKING LICENSE METHODS
		// ========================================

		/**
		 * Check if Events Tracking license is defined as constant
		 *
		 * @return bool True if constant defined.
		 * @since 1.0.0
		 */
		public function is_events_tracking_license_constant() {
			return defined( 'WPANALYTIFY_EVENTS_TRACKING_LICENSE' );
		}

		/**
		 * Get Events Tracking license key
		 *
		 * @param bool $addon Addon parameter (unused but kept for compatibility).
		 * @return string|false License key or false.
		 * @since 1.0.0
		 */
		public function get_events_tracking_license_key( $addon = false ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found
			$license = trim( get_option( 'analytify_events_tracking_license_key' ) );
			return $this->is_events_tracking_license_constant() ? ( defined( 'WPANALYTIFY_EVENTS_TRACKING_LICENSE' ) ? WPANALYTIFY_EVENTS_TRACKING_LICENSE : '' ) : $license;
		}

		/**
		 * Set Events Tracking license key
		 *
		 * @param string               $key License key.
		 * @param array<string, mixed> $load_settings Current settings array.
		 * @return void
		 * @since 1.0.0
		 */
		public function set_events_tracking_license_key( $key, &$load_settings ) {
			$load_settings['events_tracking_license'] = $key;
			update_site_option( 'wpanalytify_settings', $load_settings );
		}

		// ========================================
		// GOALS LICENSE METHODS
		// ========================================

		/**
		 * Check if Goals license is defined as constant
		 *
		 * @return bool True if constant defined.
		 * @since 1.0.0
		 */
		public function is_goals_license_constant() {
			return defined( 'WPANALYTIFY_GOALS_LICENSE' );
		}

		/**
		 * Get Goals license key
		 *
		 * @param bool $addon Addon parameter (unused but kept for compatibility).
		 * @return string|false License key or false.
		 * @since 1.0.0
		 */
		public function get_goals_license_key( $addon = false ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found
			$license = trim( get_option( 'analytify_goals_license_key' ) );
			return $this->is_goals_license_constant() ? ( defined( 'WPANALYTIFY_GOALS_LICENSE' ) ? WPANALYTIFY_GOALS_LICENSE : '' ) : $license;
		}

		/**
		 * Set Goals license key
		 *
		 * @param string               $key License key.
		 * @param array<string, mixed> $load_settings Current settings array.
		 * @return void
		 * @since 1.0.0
		 */
		public function set_goals_license_key( $key, &$load_settings ) {
			$load_settings['goals_license'] = $key;
			update_site_option( 'wpanalytify_settings', $load_settings );
		}
	}
}
