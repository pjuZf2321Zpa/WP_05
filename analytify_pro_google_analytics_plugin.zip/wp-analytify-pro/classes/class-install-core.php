<?php // phpcs:ignore WordPress.Files.FileName.InvalidClassFileName
/**
 * Install and activate the core version.
 *
 * @package WP_Analytify_Pro
 */

/**
 * WP Analytify Pro Core Installer class.
 *
 * Optional install/upgrade path for Analytify core; logs WordPress.org API and
 * upgrader failures through {@see wp_analytify_pro_log_remote_error()} when available.
 */
class WP_Analytify_Pro_Core_Installer {

	/**
	 * Constructor - check if core Analytify is available.
	 *
	 * @return void
	 */
	public function __construct() {
		// Check core Analytify is available.
		$plugins = function_exists( 'get_option' ) ? get_option( 'active_plugins' ) : array();

		if ( ! isset( $plugins['wp-analytify/wp-analytify.php'] ) ) {
			$this->ready_analytify_core();
		}
	}

	/**
	 * Prepare Analytify core plugin.
	 *
	 * @return bool
	 */
	protected function ready_analytify_core() {
		$basename            = 'wp-analytify/wp-analytify.php';
		$is_plugin_installed = $this->get_installed_plugin_data( $basename );
		$plugin_data         = $this->get_plugin_data( 'wp-analytify', $basename );

		if ( $is_plugin_installed ) {
			// Upgrade plugin - attempt for once.
			if ( isset( $plugin_data->version ) && $is_plugin_installed['Version'] !== $plugin_data->version ) {
				$this->upgrade_or_install_plugin( $basename );
			}

			if ( function_exists( 'is_plugin_active' ) && ! is_plugin_active( $basename ) ) {
				if ( function_exists( 'activate_plugin' ) ) {
					activate_plugin( $this->safe_path( defined( 'WP_PLUGIN_DIR' ) ? WP_PLUGIN_DIR . DIRECTORY_SEPARATOR . $basename : '' ), '', false, true );
				}
			}
		} else {
			// Install & activate plugin.
			$download_link = isset( $plugin_data->download_link ) ? $plugin_data->download_link : ( defined( 'ANALYTIFY_PRO_ROOT_PATH' ) ? ANALYTIFY_PRO_ROOT_PATH . 'lib/wp-analytify.zip' : '' );

			$this->upgrade_or_install_plugin( $download_link, false );
		}

		return false;
	}

	/**
	 * Get plugin data from WordPress.org API or installed plugins.
	 *
	 * When the remote request fails, logs the error through the core Analytify
	 * logger if it is available.
	 *
	 * @since 9.0.0
	 * @param string $slug     Plugin slug.
	 * @param string $basename Plugin basename.
	 * @return mixed Plugin data object or false.
	 */
	protected function get_plugin_data( $slug = '', $basename = '' ) {
		if ( empty( $slug ) ) {
			return false;
		}

		$installed_plugin = false;

		if ( $basename ) {
			$installed_plugin = $this->get_installed_plugin_data( $basename );
		}

		if ( $installed_plugin ) {
			return $installed_plugin;
		}

		$args = array(
			'slug'   => $slug,
			'fields' => array(
				'version' => false,
			),
		);

		$response = function_exists( 'wp_remote_post' ) ? wp_remote_post(
			'http://api.wordpress.org/plugins/info/1.0/',
			array(
				'body' => array(
					'action'  => 'plugin_information',
					// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.serialize_serialize -- Required by WordPress.org API.
					'request' => serialize( (object) $args ),
				),
			)
		) : false;

		if ( function_exists( 'is_wp_error' ) && is_wp_error( $response ) ) {
			if ( function_exists( 'wp_analytify_pro_log_remote_error' ) ) {
				wp_analytify_pro_log_remote_error(
					'Failed to get plugin information from WordPress.org (transport error).',
					array(
						'source'   => 'WP_Analytify_Pro_Core_Installer::get_plugin_data',
						'slug'     => $slug,
						'site_url' => function_exists( 'get_site_url' ) ? (string) get_site_url() : '',
					),
					$response
				);
			}
			return false;
		}

		$http_response = $response;

		if ( is_array( $http_response ) && function_exists( 'wp_remote_retrieve_response_code' ) ) {
			$http_code = wp_remote_retrieve_response_code( $http_response );
			if ( $http_code >= 400 ) {
				if ( function_exists( 'wp_analytify_pro_log_remote_error' ) ) {
					wp_analytify_pro_log_remote_error(
						'WordPress.org plugins API returned an HTTP error.',
						array(
							'source'   => 'WP_Analytify_Pro_Core_Installer::get_plugin_data',
							'slug'     => $slug,
							'site_url' => function_exists( 'get_site_url' ) ? (string) get_site_url() : '',
						),
						$http_response
					);
				}
				return false;
			}
		}

		// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.serialize_unserialize -- Required by WordPress.org API.
		$payload = function_exists( 'wp_remote_retrieve_body' ) && is_array( $http_response ) ? unserialize( wp_remote_retrieve_body( $http_response ), array( 'allowed_classes' => array( 'stdClass' ) ) ) : false;

		if ( $payload ) {
			return $payload;
		}

		if ( function_exists( 'wp_analytify_pro_log_remote_error' ) && is_array( $http_response ) ) {
			wp_analytify_pro_log_remote_error(
				'WordPress.org plugins API returned empty or invalid payload.',
				array(
					'source'   => 'WP_Analytify_Pro_Core_Installer::get_plugin_data',
					'slug'     => $slug,
					'site_url' => function_exists( 'get_site_url' ) ? (string) get_site_url() : '',
				),
				$http_response
			);
		}
		return false;
	}

	/**
	 * Get installed plugin data.
	 *
	 * @param string $basename Plugin basename.
	 * @return mixed Plugin data array or false.
	 */
	public function get_installed_plugin_data( $basename = '' ) {
		if ( empty( $basename ) ) {
			return false;
		}
		if ( ! function_exists( 'get_plugins' ) ) {
			$plugin_file = defined( 'ABSPATH' ) ? ABSPATH . 'wp-admin/includes/plugin.php' : '';
			if ( $plugin_file && file_exists( $plugin_file ) ) {
				include_once $plugin_file;
			}
		}

		$plugins = function_exists( 'get_plugins' ) ? get_plugins() : array();

		return isset( $plugins[ $basename ] ) ? $plugins[ $basename ] : false;
	}

	/**
	 * Upgrade or install a plugin using Plugin_Upgrader.
	 *
	 * @param string $basename Plugin basename or download URL.
	 * @param bool   $upgrade  Whether to upgrade (true) or install (false).
	 * @return mixed Upgrader skin result, or false when prerequisites are missing.
	 */
	public function upgrade_or_install_plugin( $basename = '', $upgrade = true ) {
		if ( empty( $basename ) ) {
			return false;
		}

		if ( defined( 'ABSPATH' ) ) {
			$file_php     = ABSPATH . 'wp-admin/includes/file.php';
			$upgrader_php = ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
			$skin_php     = ABSPATH . 'wp-admin/includes/class-automatic-upgrader-skin.php';

			if ( file_exists( $file_php ) ) {
				include_once $file_php;
			}
			if ( file_exists( $upgrader_php ) ) {
				include_once $upgrader_php;
			}
			if ( file_exists( $skin_php ) ) {
				include_once $skin_php;
			}
		}

		$skin     = class_exists( 'Automatic_Upgrader_Skin' ) ? new \Automatic_Upgrader_Skin() : null;
		$upgrader = class_exists( 'Plugin_Upgrader' ) ? new \Plugin_Upgrader( $skin ) : null;

		if ( $upgrader && $skin ) {
			if ( true === $upgrade ) {
				$upgrader->upgrade( $basename );
			} else {
				$upgrader->install( $basename );
				if ( function_exists( 'activate_plugin' ) ) {
					$plugin_info = $upgrader->plugin_info();
					if ( $plugin_info ) {
						activate_plugin( $plugin_info, '', false, true );
					}
				}
			}

			if ( isset( $skin->result ) && function_exists( 'is_wp_error' ) && is_wp_error( $skin->result ) && function_exists( 'wp_analytify_pro_log_error' ) ) {
				wp_analytify_pro_log_error(
					'Plugin upgrader reported a failure while installing or upgrading Analytify core.',
					array(
						'source'    => 'WP_Analytify_Pro_Core_Installer::upgrade_or_install_plugin',
						'operation' => true === $upgrade ? 'upgrade' : 'install',
						'target'    => is_string( $basename ) ? $basename : '',
						'site_url'  => function_exists( 'get_site_url' ) ? get_site_url() : '',
						'message'   => $skin->result->get_error_message(),
						'code'      => $skin->result->get_error_code(),
					)
				);
			}
		}

		return $skin ? $skin->result : false;
	}

	/**
	 * Sanitize file path for cross-platform compatibility.
	 *
	 * @param string $path File path to sanitize.
	 * @return string Sanitized file path.
	 */
	public function safe_path( $path ) {
		$path = str_replace( array( '//', '\\\\' ), array( '/', '\\' ), $path );
		return str_replace( array( '/', '\\' ), DIRECTORY_SEPARATOR, $path );
	}
}
