<?php // phpcs:ignore WordPress.Files.FileName.InvalidClassFileName
/**
 * WP Analytify Pro CSV Social & Referral Exports Class
 *
 * This class handles social and referral CSV export functionality including:
 * - Top social media
 * - Top referrer
 * - What is happening
 *
 * @package WP_Analytify_Pro
 * @since 8.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_Analytify_Pro_CSV_Social_Referral_Exports' ) ) {

	/**
	 * WP Analytify Pro CSV Social & Referral Exports Class
	 *
	 * @since 1.0.0
	 */
	class WP_Analytify_Pro_CSV_Social_Referral_Exports {

		/**
		 * The main Analytify object.
		 *
		 * @var object|null
		 */
		private $wp_analytify;

		/**
		 * GA version (ga4 or ga3).
		 *
		 * @var string
		 */
		private $ga_mode;

		/**
		 * Selected 'start state'.
		 *
		 * @var string
		 */
		private $start_date;

		/**
		 * Selected 'End state'.
		 *
		 * @var string
		 */
		private $end_date;

		/**
		 * Set the main Analytify object and dates
		 *
		 * @param object|null $wp_analytify The main Analytify object.
		 * @param string      $ga_mode GA mode.
		 * @param string      $start_date Start date.
		 * @param string      $end_date End date.
		 * @return void
		 */
		public function set_data( $wp_analytify, $ga_mode, $start_date, $end_date ) {
			$this->wp_analytify = $wp_analytify;
			$this->ga_mode      = $ga_mode;
			$this->start_date   = $start_date;
			$this->end_date     = $end_date;
		}

		/**
		 * Generates 'top-social-media'.
		 *
		 * @version 9.1.1
		 * @return list<array<int, mixed>>
		 */
		public function export_top_social_media() {

			// API limit. Fetch limit * 3 (same as dashboard social_stats) so
			// ga4_social_stats() can aggregate subdomain variants (e.g. m.facebook.com)
			// before export — a raw limit of 5 alone drops rows like youtube.
			$api_limit = analytify_pro_csv_api_limit( 'analytify_api_limit_social_media_stats', 5 );

			$stats = array();

			if ( 'ga4' === $this->ga_mode && isset( $this->wp_analytify ) && method_exists( $this->wp_analytify, 'get_reports' ) ) {
				$stats_raw = $this->wp_analytify->get_reports(
					'show-default-social-dashboard',
					array(
						'sessions',
					),
					$this->get_dates(),
					array(
						'sessionSource',
					),
					array(
						'type'  => 'metric',
						'name'  => 'sessions',
						'order' => 'desc',
					),
					array(
						'logic'   => 'AND',
						'filters' => array(
							array(
								'type'           => 'dimension',
								'name'           => 'sessionSource',
								'match_type'     => 5,
								'value'          => '^([a-z-]*\.|)(facebook|reddit|youtube|tumblr|quora|instagram|linkedin|yelp|wordpress|pinterest|twitter|t)(\.(com|org|co|)|)$',
								'not_expression' => false,
							),
						),
					),
					$api_limit * 3,
					false
				);

				if ( isset( $stats_raw['rows'] ) && $stats_raw['rows']
					&& class_exists( 'WPANALYTIFY_Utils' )
					&& method_exists( 'WPANALYTIFY_Utils', 'ga4_social_stats' ) ) {
					$social_stats = WPANALYTIFY_Utils::ga4_social_stats( $stats_raw['rows'] );
					foreach ( $social_stats as $row ) {
						$stats[] = array(
							'0' => $row['sessionSource'],
							'1' => $row['sessions'],
						);
					}
				}
			}

			$columns = array(
				array(
					'0' => esc_html__( 'Social Media', 'wp-analytify-pro' ),
					'1' => esc_html__( 'Views', 'wp-analytify-pro' ),
				),
			);
			return array_merge( $columns, $stats );
		}

		/**
		 * Generates 'top-referrer'.
		 *
		 * @version 9.1.1
		 * @return list<array<int, mixed>>
		 */
		public function export_top_referrer() {

			// API limit.
			$api_limit = analytify_pro_csv_api_limit( 'analytify_api_limit_referer_stats', 30 );

			$stats = array();

			if ( 'ga4' === $this->ga_mode && isset( $this->wp_analytify ) && method_exists( $this->wp_analytify, 'get_reports' ) ) {
				$stats_raw = $this->wp_analytify->get_reports(
					'show-default-refers-dashboard',
					array(
						'sessions',
					),
					$this->get_dates(),
					array(
						'sessionSource',
						'sessionMedium',
					),
					array(
						'type'  => 'metric',
						'name'  => 'sessions',
						'order' => 'desc',
					),
					array(),
					$api_limit,
					false
				);

				if ( isset( $stats_raw['rows'] ) && $stats_raw['rows'] ) {
					foreach ( $stats_raw['rows'] as $row ) {
						$stats[] = array(
							'0' => $row['sessionSource'],
							'1' => $row['sessionMedium'],
							'2' => $row['sessions'],
						);
					}
				}
			}

			$columns = array(
				array(
					'0' => esc_html__( 'Referrers', 'wp-analytify-pro' ),
					'1' => esc_html__( 'Type', 'wp-analytify-pro' ),
					'2' => esc_html__( 'Views', 'wp-analytify-pro' ),
				),
			);
			return array_merge( $columns, $stats );
		}

		/**
		 * Generates 'what-happen'.
		 *
		 * @version 9.1.1
		 * @return list<array<int, mixed>>
		 */
		public function export_what_is_happening() {

			// API limit.
			$api_limit = analytify_pro_csv_api_limit( 'analytify_api_limit_what_happen_stats', 5 );

			// Site URL.
			$site_url = $this->get_profile_info( 'website_url' );

			$stats   = array();
			$columns = array();

			if ( 'ga4' === $this->ga_mode && isset( $this->wp_analytify ) && method_exists( $this->wp_analytify, 'get_reports' ) ) {

				$stats_raw = $this->wp_analytify->get_reports(
					'show-default-what-happen',
					array(
						'engagedSessions',
						'engagementRate',
						'userEngagementDuration',
					),
					$this->get_dates(),
					array(
						'landingPage',
						'pageTitle',
					),
					array(
						'type'  => 'metric',
						'name'  => 'engagedSessions',
						'order' => 'desc',
					),
					array(),
					$api_limit,
					false
				);

				if ( isset( $stats_raw['rows'] ) && $stats_raw['rows'] ) {
					foreach ( $stats_raw['rows'] as $row ) {
						$stats[] = array(
							'0' => $row['pageTitle'],
							'1' => $row['landingPage'],
							'2' => class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_time' ) ? wp_strip_all_tags( WPANALYTIFY_Utils::pretty_time( $row['userEngagementDuration'] ) ) : $row['userEngagementDuration'],
							'3' => class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' ) ? WPANALYTIFY_Utils::pretty_numbers( $row['engagedSessions'] ) : $row['engagedSessions'],
							// phpcs:ignore Squiz.PHP.CommentedOutCode.Found -- Old code: '4' => round( $row['engagementRate'], 2 ) . '%'.
							'4' => ( $row['engagementRate'] && class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'fraction_to_percentage' ) ? WPANALYTIFY_Utils::fraction_to_percentage( ( $row['engagementRate'] ) ) : 0 ) . '%',
						);
					}
				}

				$columns = array(
					array(
						'0' => esc_html__( 'Title', 'wp-analytify-pro' ),
						'1' => esc_html__( 'Link', 'wp-analytify-pro' ),
						'2' => esc_html__( 'User Engagement Duration', 'wp-analytify-pro' ),
						'3' => esc_html__( 'Engaged Sessions', 'wp-analytify-pro' ),
						'4' => esc_html__( 'Engagement Rate', 'wp-analytify-pro' ),
					),
				);

			}

			return array_merge( $columns, $stats );
		}

		/**
		 * Returns start and end date as an array to be used for GA4's get_reports()
		 *
		 * @return array<string, string>
		 */
		private function get_dates() {
			return array(
				'start' => $this->start_date,
				'end'   => $this->end_date,
			);
		}

		/**
		 * Get profile related data based on the key (option) provided.
		 *
		 * @param string $key Option name.
		 * @return string|null
		 */
		private function get_profile_info( $key ) {
			$dashboard_profile_id = '';
			if ( $this->wp_analytify && is_object( $this->wp_analytify ) && isset( $this->wp_analytify->settings ) && method_exists( $this->wp_analytify->settings, 'get_option' ) ) {
				$dashboard_profile_id = $this->wp_analytify->settings->get_option( 'profile_for_dashboard', 'wp-analytify-profile' );
			}
			switch ( $key ) {
				case 'profile_id':
					return $dashboard_profile_id;
				case 'website_url':
					return class_exists( 'WP_ANALYTIFY_FUNCTIONS' ) && method_exists( 'WP_ANALYTIFY_FUNCTIONS', 'search_profile_info' ) ? WP_ANALYTIFY_FUNCTIONS::search_profile_info( $dashboard_profile_id, 'websiteUrl' ) : '';
				default:
					return null;
			}
		}
	}
}
