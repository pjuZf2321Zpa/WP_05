<?php // phpcs:ignore WordPress.Files.FileName.InvalidClassFileName
/**
 * WP Analytify Pro REST API Search Endpoints Class
 *
 * This class handles search-related REST API endpoints including:
 * - Search terms
 *
 * @package WP_Analytify_Pro
 * @since 8.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_Analytify_Pro_REST_Search' ) ) {

	/**
	 * WP Analytify Pro REST API Search Endpoints Class
	 *
	 * @since 1.0.0
	 */
	class WP_Analytify_Pro_REST_Search {

		/**
		 * Singleton instance.
		 *
		 * @var WP_Analytify_Pro_REST_Search|null $instance The one true WP_Analytify_Pro_REST_Search.
		 * @since 1.0.0
		 */
		private static $instance;

		/**
		 * The main Analytify object.
		 *
		 * @var object|null
		 */
		private $wp_analytify;

		/**
		 * GA version (ga4 or ga3).
		 *
		 * @var string
		 */
		private $ga_mode;

		/**
		 * Selected 'start state'.
		 *
		 * @var string
		 */
		private $start_date;

		/**
		 * Selected 'End state'.
		 *
		 * @var string
		 */
		private $end_date;

		/**
		 * Date difference.
		 *
		 * @var string
		 */
		private $date_differ;

		/**
		 * Type parameter.
		 *
		 * @var string
		 */
		private $type;


		/**
		 * Get active instance.
		 *
		 * @access public
		 * @since 1.0.0
		 * @return WP_Analytify_Pro_REST_Search The one true WP_Analytify_Pro_REST_Search.
		 */
		public static function instance() {
			if ( ! self::$instance ) {
				self::$instance = new WP_Analytify_Pro_REST_Search();
				self::$instance->init();
			}
			return self::$instance;
		}

		/**
		 * Initialize the class.
		 *
		 * @access private
		 * @since 1.0.0
		 * @return void
		 */
		private function init() {
			// Don't initialize wp_analytify here - it will be set when set_dates is called.
		}

		/**
		 * Set dates for the reports.
		 *
		 * @param string $start_date Start date.
		 * @param string $end_date End date.
		 * @param string $date_differ Date difference.
		 * @param string $type Type parameter.
		 * @param object $wp_analytify The main Analytify object.
		 * @param string $ga_mode GA mode.
		 * @return void
		 */
		public function set_dates( $start_date, $end_date, $date_differ, $type, $wp_analytify = null, $ga_mode = null ) {
			$this->start_date  = $start_date;
			$this->end_date    = $end_date;
			$this->date_differ = $date_differ;
			$this->type        = $type;

			// Set wp_analytify and ga_mode if provided.
			if ( null !== $wp_analytify ) {
				$this->wp_analytify = $wp_analytify;
			}
			if ( null !== $ga_mode ) {
				$this->ga_mode = $ga_mode;
			}
		}

		/**
		 * Endpoint for 'Search Term' dashboard.
		 *
		 * @return array<string, mixed>
		 */
		public function search_terms() {

			// API limit.
			$api_limit = apply_filters( 'analytify_api_limit_search_term_stats', 50, 'dashboard' );

			$headers = array();
			$stats   = array();

			if ( 'ga4' === $this->ga_mode ) {

				$headers = array(
					'no'      => array(
						'label'    => esc_html__( '#', 'wp-analytify-pro' ),
						'type'     => 'counter',
						'th_class' => 'analytify_num_row',
						'td_class' => 'analytify_txt_center',
					),
					'term'    => array(
						'label'    => esc_html__( 'Search Term', 'wp-analytify-pro' ),
						'th_class' => 'analytify_txt_left',
						'td_class' => '',
					),
					'total'   => array(
						'label'    => esc_html__( 'Total Search', 'wp-analytify-pro' ),
						'th_class' => 'analytify_value_row',
						'td_class' => 'analytify_txt_center',
					),
					'session' => array(
						'label'    => esc_html__( 'Search per Session', 'wp-analytify-pro' ),
						'th_class' => 'analytify_value_row',
						'td_class' => 'analytify_txt_center',
					),
					'users'   => array(
						'label'    => esc_html__( 'Total Users', 'wp-analytify-pro' ),
						'th_class' => 'analytify_value_row',
						'td_class' => 'analytify_txt_center',
					),
				);

				$stats_raw = isset( $this->wp_analytify ) && method_exists( $this->wp_analytify, 'get_reports' ) ? $this->wp_analytify->get_reports(
					'show-search-term',
					array(
						'eventCount',
						'sessions',
						'totalUsers',
					),
					$this->get_dates(),
					array(
						'searchTerm',
					),
					array(
						'type'  => 'metric',
						'name'  => 'eventCount',
						'order' => 'desc',
					),
					array(
						'logic'   => 'AND',
						'filters' => array(
							array(
								'type'           => 'dimension',
								'name'           => 'searchTerm',
								'match_type'     => 1,
								'value'          => '',
								'not_expression' => true,
							),
						),
					),
					$api_limit
				) : array();

				if ( isset( $stats_raw['rows'] ) && $stats_raw['rows'] ) {
					foreach ( $stats_raw['rows'] as $row ) {
						$stats[] = array(
							'no'      => null,
							'term'    => $row['searchTerm'],
							'total'   => $row['eventCount'],
							'session' => $row['sessions'],
							'users'   => $row['totalUsers'],
						);
					}
				}
			}

			return array(
				'success'    => true,
				'headers'    => $headers,
				'stats'      => $stats,
				'footer'     => apply_filters( 'analytify_search_term_footer', __( 'List of the Terms that were searched for on your site.', 'wp-analytify-pro' ), array( $this->start_date, $this->end_date ) ),
				'pagination' => true,
			);
		}

		/**
		 * Get dates for comparison.
		 *
		 * @return array<string, string>
		 */
		private function get_dates() {
			return array(
				'start' => $this->start_date,
				'end'   => $this->end_date,
			);
		}
	}
}
