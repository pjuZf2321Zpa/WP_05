<?php // phpcs:ignore WordPress.Files.FileName.InvalidClassFileName
/**
 * WP Analytify Pro CSV Device Analytics Exports Class
 *
 * This class handles device analytics CSV export functionality including:
 * - Top browsers
 * - Top operating systems
 * - Top mobile devices
 *
 * @package WP_Analytify_Pro
 * @since 8.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_Analytify_Pro_CSV_Device_Analytics_Exports' ) ) {

	/**
	 * WP Analytify Pro CSV Device Analytics Exports Class
	 *
	 * @since 1.0.0
	 */
	class WP_Analytify_Pro_CSV_Device_Analytics_Exports {

		/**
		 * The main Analytify object.
		 *
		 * @var object|null
		 */
		private $wp_analytify;

		/**
		 * GA version (ga4 or ga3).
		 *
		 * @var string
		 */
		private $ga_mode;

		/**
		 * Selected 'start state'.
		 *
		 * @var string
		 */
		private $start_date;

		/**
		 * Selected 'End state'.
		 *
		 * @var string
		 */
		private $end_date;

		/**
		 * Set the main Analytify object and dates
		 *
		 * @param object|null $wp_analytify The main Analytify object.
		 * @param string      $ga_mode GA mode.
		 * @param string      $start_date Start date.
		 * @param string      $end_date End date.
		 * @return void
		 */
		public function set_data( $wp_analytify, $ga_mode, $start_date, $end_date ) {
			$this->wp_analytify = $wp_analytify;
			$this->ga_mode      = $ga_mode;
			$this->start_date   = $start_date;
			$this->end_date     = $end_date;
		}

		/**
		 * Generates 'top-browsers'.
		 *
		 * @version 9.1.1
		 * @return list<array<int, mixed>>
		 */
		public function export_top_browsers() {

			// API limit.
			$api_limit = analytify_pro_csv_api_limit( 'analytify_api_limit_browser_stats', 5 );

			$stats = array();

			if ( 'ga4' === $this->ga_mode && isset( $this->wp_analytify ) && method_exists( $this->wp_analytify, 'get_reports' ) ) {
				$stats_raw = $this->wp_analytify->get_reports(
					'show-default-browser-dashboard',
					array(
						'sessions',
					),
					$this->get_dates(),
					array(
						'browser',
						'operatingSystem',
					),
					array(
						'type'  => 'metric',
						'name'  => 'sessions',
						'order' => 'desc',
					),
					array(
						'logic'   => 'AND',
						'filters' => array(
							array(
								'type'           => 'dimension',
								'name'           => 'operatingSystem',
								'match_type'     => 4,
								'value'          => '(not set)',
								'not_expression' => true,
							),
						),
					),
					$api_limit,
					false
				);

				if ( isset( $stats_raw['rows'] ) && $stats_raw['rows'] ) {
					foreach ( $stats_raw['rows'] as $rows ) {
						$stats[] = array(
							'0' => $rows['browser'],
							'1' => $rows['operatingSystem'],
							'2' => class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' ) ? WPANALYTIFY_Utils::pretty_numbers( $rows['sessions'] ) : $rows['sessions'],
						);
					}
				}
			}

			$columns = array(
				array(
					'0' => esc_html__( 'Browser', 'wp-analytify-pro' ),
					'1' => esc_html__( 'Operating System', 'wp-analytify-pro' ),
					'2' => esc_html__( 'Visits', 'wp-analytify-pro' ),
				),
			);
			return array_merge( $columns, $stats );
		}

		/**
		 * Generates 'top-operating-system'.
		 *
		 * @version 9.1.1
		 * @return list<array<int, mixed>>
		 */
		public function export_top_operating_system() {

			// API limit.
			$api_limit = analytify_pro_csv_api_limit( 'analytify_api_limit_os_stats', 5 );

			$stats = array();

			if ( 'ga4' === $this->ga_mode && isset( $this->wp_analytify ) && method_exists( $this->wp_analytify, 'get_reports' ) ) {
				$stats_raw = $this->wp_analytify->get_reports(
					'show-default-os-dashboard',
					array(
						'sessions',
					),
					$this->get_dates(),
					array(
						'operatingSystem',
						'operatingSystemVersion',
					),
					array(
						'type'  => 'metric',
						'name'  => 'sessions',
						'order' => 'desc',
					),
					array(
						'logic'   => 'AND',
						'filters' => array(
							array(
								'type'           => 'dimension',
								'name'           => 'operatingSystemVersion',
								'match_type'     => 4,
								'value'          => '(not set)',
								'not_expression' => true,
							),
						),
					),
					$api_limit,
					false
				);

				if ( isset( $stats_raw['rows'] ) && $stats_raw['rows'] ) {
					foreach ( $stats_raw['rows'] as $rows ) {
						$stats[] = array(
							'0' => $rows['operatingSystem'],
							'1' => $rows['operatingSystemVersion'],
							'2' => class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' ) ? WPANALYTIFY_Utils::pretty_numbers( $rows['sessions'] ) : $rows['sessions'],
						);
					}
				}
			}

			$columns = array(
				array(
					'0' => esc_html__( 'Operating System', 'wp-analytify-pro' ),
					'1' => esc_html__( 'Version', 'wp-analytify-pro' ),
					'2' => esc_html__( 'Visits', 'wp-analytify-pro' ),
				),
			);
			return array_merge( $columns, $stats );
		}

		/**
		 * Generates 'top-mobile-device'.
		 *
		 * @version 9.1.1
		 * @return list<array<int, mixed>>
		 */
		public function export_top_mobile_device() {

			// API limit.
			$api_limit = analytify_pro_csv_api_limit( 'analytify_api_limit_mobile_stats', 5 );

			$stats = array();

			if ( 'ga4' === $this->ga_mode && isset( $this->wp_analytify ) && method_exists( $this->wp_analytify, 'get_reports' ) ) {
				$stats_raw = $this->wp_analytify->get_reports(
					'show-default-mobile-dashboard',
					array(
						'sessions',
					),
					$this->get_dates(),
					array(
						'mobileDeviceBranding',
						'mobileDeviceModel',
					),
					array(
						'type'  => 'metric',
						'name'  => 'sessions',
						'order' => 'desc',
					),
					array(
						'logic'   => 'AND',
						'filters' => array(
							array(
								'type'           => 'dimension',
								'name'           => 'deviceCategory',
								'match_type'     => 4,
								'value'          => 'desktop',
								'not_expression' => true,
							),
							array(
								'type'           => 'dimension',
								'name'           => 'mobileDeviceModel',
								'match_type'     => 4,
								'value'          => '(not set)',
								'not_expression' => true,
							),
						),
					),
					$api_limit,
					false
				);
				if ( isset( $stats_raw['rows'] ) && $stats_raw['rows'] ) {
					foreach ( $stats_raw['rows'] as $row ) {
						$stats[] = array(
							'0' => $row['mobileDeviceBranding'],
							'1' => $row['mobileDeviceModel'],
							'2' => class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' ) ? WPANALYTIFY_Utils::pretty_numbers( $row['sessions'] ) : $row['sessions'],
						);
					}
				}
			}

			$columns = array(
				array(
					'0' => esc_html__( 'Device', 'wp-analytify-pro' ),
					'1' => esc_html__( 'Model', 'wp-analytify-pro' ),
					'2' => esc_html__( 'Visits', 'wp-analytify-pro' ),
				),
			);
			return array_merge( $columns, $stats );
		}

		/**
		 * Returns start and end date as an array to be used for GA4's get_reports()
		 *
		 * @return array<string, string>
		 */
		private function get_dates() {
			return array(
				'start' => $this->start_date,
				'end'   => $this->end_date,
			);
		}
	}
}
