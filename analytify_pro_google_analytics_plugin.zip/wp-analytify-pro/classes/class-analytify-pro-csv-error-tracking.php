<?php // phpcs:ignore WordPress.Files.FileName.InvalidClassFileName
/**
 * WP Analytify Pro CSV Error Tracking Exports Class
 *
 * This class handles error tracking CSV export functionality including:
 * - AJAX errors
 * - 404 errors
 * - JavaScript errors
 *
 * @package WP_Analytify_Pro
 * @since 8.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_Analytify_Pro_CSV_Error_Tracking_Exports' ) ) {

	/**
	 * WP Analytify Pro CSV Error Tracking Exports Class
	 *
	 * @since 1.0.0
	 */
	class WP_Analytify_Pro_CSV_Error_Tracking_Exports {

		/**
		 * The main Analytify object.
		 *
		 * @var object|null
		 */
		private $wp_analytify;

		/**
		 * GA version (ga4 or ga3).
		 *
		 * @var string
		 */
		private $ga_mode;

		/**
		 * Selected 'start state'.
		 *
		 * @var string
		 */
		private $start_date;

		/**
		 * Selected 'End state'.
		 *
		 * @var string
		 */
		private $end_date;

		/**
		 * Set the main Analytify object and dates
		 *
		 * @param object|null $wp_analytify The main Analytify object.
		 * @param string      $ga_mode GA mode.
		 * @param string      $start_date Start date.
		 * @param string      $end_date End date.
		 * @return void
		 */
		public function set_data( $wp_analytify, $ga_mode, $start_date, $end_date ) {
			$this->wp_analytify = $wp_analytify;
			$this->ga_mode      = $ga_mode;
			$this->start_date   = $start_date;
			$this->end_date     = $end_date;
		}

		/**
		 * Generates 'top-ajax' errors.
		 *
		 * @version 9.1.1
		 * @return list<array<int, mixed>>
		 */
		public function export_top_ajax_errors() {

			// API limit.
			$api_limit = analytify_pro_csv_api_limit( 'analytify_api_limit_ajax_error_stats', 5 );

			$stats = array();

			if ( 'ga4' === $this->ga_mode && isset( $this->wp_analytify ) && method_exists( $this->wp_analytify, 'get_reports' ) ) {
				$stats_raw = $this->wp_analytify->get_reports(
					'show-top-ajax-errors',
					array(
						'eventCount',
					),
					$this->get_dates(),
					array(
						'customEvent:wpa_action',
						'customEvent:wpa_category',
						'customEvent:wpa_label',
					),
					array(
						'type'  => 'metric',
						'name'  => 'eventCount',
						'order' => 'desc',
					),
					array(
						'logic'   => 'AND',
						'filters' => array(
							array(
								'type'       => 'dimension',
								'name'       => 'customEvent:wpa_category',
								'match_type' => 1,
								'value'      => 'Ajax Error',
							),
						),
					),
					$api_limit,
					false
				);

				if ( isset( $stats_raw['rows'] ) && $stats_raw['rows'] ) {
					foreach ( $stats_raw['rows'] as $row ) {
						$stats[] = array(
							'0' => $row['customEvent:wpa_action'],
							'1' => $row['customEvent:wpa_label'],
							'2' => class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' ) ? WPANALYTIFY_Utils::pretty_numbers( $row['eventCount'] ) : $row['eventCount'],
						);
					}
				}
			}

			$columns = array(
				array(
					'0' => esc_html__( 'Error', 'wp-analytify-pro' ),
					'1' => esc_html__( 'Link', 'wp-analytify-pro' ),
					'2' => esc_html__( 'Hits', 'wp-analytify-pro' ),
				),
			);
			return array_merge( $columns, $stats );
		}

		/**
		 * Generates 'top-404' errors.
		 *
		 * @version 9.1.1
		 * @return list<array<int, mixed>>
		 */
		public function export_top_404_errors() {

			// API limit.
			$api_limit = analytify_pro_csv_api_limit( 'analytify_api_limit_404_error_stats', 5 );

			$stats = array();

			if ( 'ga4' === $this->ga_mode && isset( $this->wp_analytify ) && method_exists( $this->wp_analytify, 'get_reports' ) ) {
				$stats_raw = $this->wp_analytify->get_reports(
					'show-top-404-pages',
					array(
						'eventCount',
					),
					$this->get_dates(),
					array(
						'customEvent:wpa_category',
						'customEvent:wpa_label',
					),
					array(
						'type'  => 'metric',
						'name'  => 'eventCount',
						'order' => 'desc',
					),
					array(
						'logic'   => 'AND',
						'filters' => array(
							array(
								'type'       => 'dimension',
								'name'       => 'customEvent:wpa_category',
								'match_type' => 1,
								'value'      => '404 Error',
							),
						),
					),
					$api_limit,
					false
				);

				if ( isset( $stats_raw['rows'] ) && $stats_raw['rows'] ) {
					foreach ( $stats_raw['rows'] as $row ) {
						$stats[] = array(
							'0' => $row['customEvent:wpa_label'],
							'1' => class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' ) ? WPANALYTIFY_Utils::pretty_numbers( $row['eventCount'] ) : $row['eventCount'],
						);
					}
				}
			}

			$columns = array(
				array(
					'0' => esc_html__( 'Link', 'wp-analytify-pro' ),
					'1' => esc_html__( 'Hits', 'wp-analytify-pro' ),
				),
			);
			return array_merge( $columns, $stats );
		}

		/**
		 * Generates 'top-js-error'.
		 *
		 * @version 9.1.1
		 * @return list<array<int, mixed>>
		 */
		public function export_top_js_errors() {

			// API limit.
			$api_limit = analytify_pro_csv_api_limit( 'analytify_api_limit_js_error_stats', 5 );

			$stats = array();

			if ( 'ga4' === $this->ga_mode && isset( $this->wp_analytify ) && method_exists( $this->wp_analytify, 'get_reports' ) ) {
				$stats_raw = $this->wp_analytify->get_reports(
					'show-top-js-errors',
					array(
						'eventCount',
					),
					$this->get_dates(),
					array(
						'customEvent:wpa_action',
						'customEvent:wpa_label',
						'customEvent:wpa_category',
					),
					array(
						'type'  => 'metric',
						'name'  => 'eventCount',
						'order' => 'desc',
					),
					array(
						'logic'   => 'AND',
						'filters' => array(
							array(
								'type'       => 'dimension',
								'name'       => 'customEvent:wpa_category',
								'match_type' => 1,
								'value'      => 'JavaScript Error',
							),
						),
					),
					$api_limit,
					false
				);

				if ( isset( $stats_raw['rows'] ) && $stats_raw['rows'] ) {
					foreach ( $stats_raw['rows'] as $row ) {
						$stats[] = array(
							'0' => $row['customEvent:wpa_action'],
							'1' => $row['customEvent:wpa_label'],
							'2' => class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' ) ? WPANALYTIFY_Utils::pretty_numbers( $row['eventCount'] ) : $row['eventCount'],
						);
					}
				}
			}

			$columns = array(
				array(
					'0' => esc_html__( 'Error', 'wp-analytify-pro' ),
					'1' => esc_html__( 'Link', 'wp-analytify-pro' ),
					'2' => esc_html__( 'Hits', 'wp-analytify-pro' ),
				),
			);
			return array_merge( $columns, $stats );
		}

		/**
		 * Returns start and end date as an array to be used for GA4's get_reports()
		 *
		 * @return array<string, string>
		 */
		private function get_dates() {
			return array(
				'start' => $this->start_date,
				'end'   => $this->end_date,
			);
		}
	}
}
