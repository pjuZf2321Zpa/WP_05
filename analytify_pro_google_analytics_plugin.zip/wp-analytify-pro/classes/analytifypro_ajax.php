<?php
// phpcs:ignoreFile WordPress.Files.FileName.NotHyphenatedLowercase, WordPress.Files.FileName.InvalidClassFileName
/**
 * WP Analytify Pro AJAX Handler
 *
 * @package WP_Analytify_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	// Exit if accessed directly.
	exit;
}

if ( class_exists( 'WPANALYTIFY_AJAX' ) ) {

	if ( ! class_exists( 'WPANALYTIFYPRO_AJAX' ) ) {
		/**
		 * Handling all the AJAX calls in WP Analytify
		 *
		 * @since 1.2.4
		 * @class WPANALYTIFY_AJAX
		 */
		class WPANALYTIFYPRO_AJAX extends WPANALYTIFY_AJAX {

			/**
			 * Show settings array.
			 *
			 * @var array<string, mixed>
			 */
			public static $show_settings = array();

			/**
			 * Initialize AJAX handlers.
			 *
			 * @since 1.0.0
			 * @version 7.0.5
			 * @return void
			 */
			public static function init() {

				// No parent class to call init() on.

				$ajax_calls = array(
					'load_mobile_stats'          => false,
					'load_real_time_stats'       => false,
					'load_online_visitors'       => true,
					'load_detail_realtime_stats' => false,
					'export_csv'                 => false,
				);

				foreach ( $ajax_calls as $ajax_call => $no_priv ) {
					// code...
					if ( function_exists( 'add_action' ) ) {
						add_action(
							'wp_ajax_analytify_' . $ajax_call,
							function () use ( $ajax_call ) {
								self::$ajax_call();
							}
						);
					}

					if ( $no_priv && function_exists( 'add_action' ) ) {
						add_action(
							'wp_ajax_nopriv_analytify_' . $ajax_call,
							function () use ( $ajax_call ) {
								self::$ajax_call();
							}
						);
					}
				}
			}


			/**
			 * Load mobile stats via AJAX.
			 *
			 * @since 1.0.0
			 * @return void
			 */
			public static function load_mobile_stats() {
				// phpcs:ignore WordPress.NamingConventions.ValidVariableName.VariableNotSnakeCase -- $WP_Analytify is a global variable name.
				$WP_Analytify = isset( $GLOBALS['WP_ANALYTIFY'] ) ? $GLOBALS['WP_ANALYTIFY'] : null;

				// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- AJAX call from admin dashboard.
				$dashboard_profile_id = isset( $_GET['dashboard_profile_ID'] ) ? sanitize_text_field( wp_unslash( $_GET['dashboard_profile_ID'] ) ) : '';
				// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- AJAX call from admin dashboard.
				$start_date = isset( $_GET['start_date'] ) ? sanitize_text_field( wp_unslash( $_GET['start_date'] ) ) : '';
				// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- AJAX call from admin dashboard.
				$end_date = isset( $_GET['end_date'] ) ? sanitize_text_field( wp_unslash( $_GET['end_date'] ) ) : '';

				if ( is_array( self::$show_settings ) && in_array( 'show-mobile-dashboard', self::$show_settings, true ) ) {

					$mobile_stats = get_transient( md5( 'show-mobile-dashboard' . $dashboard_profile_id . $start_date . $end_date ) );

					// phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- Property name from Google Analytics API.
					if ( isset( $mobile_stats->totalsForAllResults ) ) {
						if ( defined( 'ANALYTIFY_PRO_ROOT_PATH' ) ) {
							include ANALYTIFY_PRO_ROOT_PATH . '/views/admin/mobile-stats.php';
						}
						// phpcs:ignore WordPress.NamingConventions.ValidVariableName.VariableNotSnakeCase -- $WP_Analytify is a global variable name.
						if ( function_exists( 'pa_include_mobile' ) && $WP_Analytify ) {
							// phpcs:ignore WordPress.NamingConventions.ValidVariableName.VariableNotSnakeCase
							pa_include_mobile( $WP_Analytify, (array) $mobile_stats );
						}
					}
				}

				die();
			}


			/**
			 * Load real time stats
			 *
			 * @since 1.0.0
			 * @return void
			 */
			public static function load_real_time_stats() {
				// phpcs:ignore WordPress.NamingConventions.ValidVariableName.VariableNotSnakeCase -- $WP_Analytify is a global variable name.
				$WP_Analytify = $GLOBALS['WP_ANALYTIFY'];

				if ( is_array( self::$show_settings ) && in_array( 'show-real-time', self::$show_settings, true ) ) {

					if ( defined( 'ANALYTIFY_PRO_ROOT_PATH' ) ) {
						include ANALYTIFY_PRO_ROOT_PATH . '/views/admin/realtime-stats.php';
					}
					if ( function_exists( 'pa_include_realtime' ) ) {
						$instance = new self();
						pa_include_realtime( $instance );
					}
				}

				die();
			}



			/**
			 * Load online visitors via AJAX.
			 *
			 * @return void
			 */
			public static function load_online_visitors() {

				if ( ! isset( $_POST['pa_security'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['pa_security'] ) ), 'pa_get_online_data' ) ) {
					return;
				}

				if ( ! function_exists( 'curl_version' ) ) {
					die( 'cURL not exists.' );
				}

				$data = self::pa_realtime_data();
				if ( false !== $data ) {
					$json_data = wp_json_encode( $data );
					if ( false !== $json_data ) {
						// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_print_r -- Required for AJAX response.
						print_r( stripslashes( $json_data ) );
					}
				}

				die();
			}

			/**
			 * Grab RealTime Data
			 *
			 * @return mixed
			 */
			public static function pa_realtime_data() {

				// revoke, if already quota error.
				if ( get_transient( 'analytify_quota_exception' ) ) {
					return false;
				}

				// phpcs:ignore WordPress.NamingConventions.ValidVariableName.VariableNotSnakeCase -- $WP_Analytify is a global variable name.
				$WP_Analytify = isset( $GLOBALS['WP_ANALYTIFY'] ) ? $GLOBALS['WP_ANALYTIFY'] : null;
				// phpcs:disable WordPress.NamingConventions.ValidVariableName.VariableNotSnakeCase
				if ( ! $WP_Analytify || ! is_object( $WP_Analytify ) || ! isset( $WP_Analytify->settings ) || ! method_exists( $WP_Analytify->settings, 'get_option' ) ) {
					return false;
				}
				$profile_id = '';
				if ( $WP_Analytify && is_object( $WP_Analytify ) && isset( $WP_Analytify->settings ) && method_exists( $WP_Analytify->settings, 'get_option' ) ) {
					$profile_id = $WP_Analytify->settings->get_option( 'profile_for_dashboard', 'wp-analytify-profile' );
				}
				// phpcs:enable WordPress.NamingConventions.ValidVariableName.VariableNotSnakeCase
				$metrics    = 'ga:activeVisitors';
				$dimensions = 'ga:source,ga:keyword,ga:trafficType,ga:visitorType';

				try {
					// phpcs:ignore WordPress.NamingConventions.ValidVariableName.VariableNotSnakeCase
					if ( $WP_Analytify && is_object( $WP_Analytify ) && isset( $WP_Analytify->service ) && isset( $WP_Analytify->service->data_realtime ) && method_exists( $WP_Analytify->service->data_realtime, 'get' ) ) {
						// phpcs:ignore WordPress.NamingConventions.ValidVariableName.VariableNotSnakeCase
						$data_realtime = $WP_Analytify->service->data_realtime;
						$data          = $data_realtime->get(
							'ga:' . $profile_id,
							$metrics,
							array(
								'dimensions' => $dimensions,
							)
						);
					} else {
						return false;
					}
				} catch ( Exception $e ) {
					return false;
				}

				return $data;
			}

			/**
			 * Run on details realtime stats.
			 *
			 * @since 2.0.0
			 * @return void
			 */
			public static function load_detail_realtime_stats() {
				if ( ! isset( $_POST['pa_security'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['pa_security'] ) ), 'pa_get_online_data' ) ) {
					return;
				}

				if ( ! function_exists( 'curl_version' ) ) {
					die( 'cURL not exists.' );
				}

				$data = self::pa_details_realtime_data();
				if ( defined( 'JSON_UNESCAPED_UNICODE' ) ) {
					echo wp_json_encode( $data, JSON_UNESCAPED_UNICODE );
				} else {
					echo wp_json_encode( $data );
				}

				die();
			}

			/**
			 * Grab data for detail realtime stats.
			 *
			 * @since 2.0.0
			 * @return mixed
			 */
			public static function pa_details_realtime_data() {

				if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {
					$wp_analytify = isset( $GLOBALS['WP_ANALYTIFY'] ) ? $GLOBALS['WP_ANALYTIFY'] : null;

					if ( $wp_analytify && is_object( $wp_analytify ) && method_exists( $wp_analytify, 'get_real_time_reports' ) ) {
						$real_time_report = $wp_analytify->get_real_time_reports(
							array(
								'activeUsers',
							),
							array(
								'unifiedScreenName',
							)
						);

						return $real_time_report;
					}

					return false;

				} else {
					// phpcs:ignore WordPress.NamingConventions.ValidVariableName.VariableNotSnakeCase -- $WP_Analytify is a global variable name.
					$WP_Analytify = isset( $GLOBALS['WP_ANALYTIFY'] ) ? $GLOBALS['WP_ANALYTIFY'] : null;
					// phpcs:disable WordPress.NamingConventions.ValidVariableName.VariableNotSnakeCase
					if ( ! $WP_Analytify || ! is_object( $WP_Analytify ) || ! isset( $WP_Analytify->settings ) || ! method_exists( $WP_Analytify->settings, 'get_option' ) ) {
						return false;
					}
					$profile_id = '';
					if ( $WP_Analytify && is_object( $WP_Analytify ) && isset( $WP_Analytify->settings ) && method_exists( $WP_Analytify->settings, 'get_option' ) ) {
							$profile_id = $WP_Analytify->settings->get_option( 'profile_for_dashboard', 'wp-analytify-profile' );
					}
					// phpcs:enable WordPress.NamingConventions.ValidVariableName.VariableNotSnakeCase

					$metrics    = 'ga:activeVisitors';
					$dimensions = 'ga:pagePath,ga:source,ga:keyword,ga:trafficType,ga:visitorType,ga:pageTitle';

					try {
						// phpcs:ignore WordPress.NamingConventions.ValidVariableName.VariableNotSnakeCase
						if ( $WP_Analytify && is_object( $WP_Analytify ) && isset( $WP_Analytify->service ) && isset( $WP_Analytify->service->data_realtime ) && method_exists( $WP_Analytify->service->data_realtime, 'get' ) ) {
							// phpcs:ignore WordPress.NamingConventions.ValidVariableName.VariableNotSnakeCase
							$data_realtime = $WP_Analytify->service->data_realtime;
							$data          = $data_realtime->get(
								'ga:' . $profile_id,
								$metrics,
								array(
									'dimensions' => $dimensions,
								)
							);
						} else {
							return false;
						}
					} catch ( Exception $e ) {
						if ( function_exists( 'update_option' ) && function_exists( 'esc_html' ) ) {
							update_option( 'pa_lasterror_occur', esc_html( $e ) );
						}
						return '';
					}

					return $data;
				}
			}

			/**
			 * Calculate the Stats on Export.
			 *
			 * @since 2.0.17
			 * @return void
			 */
			public static function export_csv() {
				// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Nonce verified in auth_check method below.
				$input = $_REQUEST;

				$type  = sanitize_text_field( wp_unslash( $input['stats_type'] ) );
				$nonce = sanitize_text_field( $input['security'] );
				$args  = isset( $input['args'] ) ? $input['args'] : array();

				$csv_export = new AnalytifyCSVExport();
				if ( $csv_export->auth_check( $nonce, 'analytify_export_nonce' ) ) {

					$date = array(
						'start_date' => sanitize_text_field( $input['start_date'] ),
						'end_date'   => sanitize_text_field( $input['end_date'] ),
					);
					if ( $csv_export->generate_export_data( $type, $date, $args ) ) {
						// Export successful.
						wp_send_json_success( 'Data prepared for export.' );
						return;
					}

					wp_send_json_error( 'Unable to export data.', 400 );
				}

				wp_send_json_error( 'Permission denied.', 403 );
			}
		}

		WPANALYTIFYPRO_AJAX::init();

	}
}
