<?php
// phpcs:ignoreFile WordPress.Files.FileName.NotHyphenatedLowercase, WordPress.Files.FileName.InvalidClassFileName
/**
 * WP Analytify Pro Base Class
 *
 * @package WP_Analytify_Pro
 */

/**
 * WP Analytify Pro Base Class
 *
 * Base class for WP Analytify Pro functionality.
 *
 * @since 1.0.0
 */
class WP_Analytify_Pro_Base {

	/**
	 * License manager instance.
	 *
	 * @var WP_Analytify_Pro_License_Manager|null $license_manager
	 * @since 1.0.0
	 */
	private $license_manager;

	/**
	 * Addon licenses instance.
	 *
	 * @var WP_Analytify_Pro_Addon_Licenses|null $addon_licenses
	 * @since 1.0.0
	 */
	private $addon_licenses;

	/**
	 * License API instance.
	 *
	 * @var WP_Analytify_Pro_License_API|null $license_api
	 * @since 1.0.0
	 */
	private $license_api;

	/**
	 * Tracking helpers instance (GA/tracking logic).
	 *
	 * @var WP_Analytify_Pro_Tracking_Helpers|null $tracking_helpers
	 * @since 9.0.0
	 */
	private $tracking_helpers;

	/**
	 * Plugin settings base URL.
	 *
	 * @var string $plugin_settings_base
	 */
	private $plugin_settings_base = '';

	/**
	 * Load settings array.
	 *
	 * @var array<string, mixed> $load_settings
	 */
	private $load_settings;

	/**
	 * Constructor.
	 *
	 * @since 1.0.0
	 * @version 7.0.5
	 * @return void
	 */
	public function __construct() {
		$this->init_license_classes();
	}

	/**
	 * Initialize license management classes
	 *
	 * @version 7.0.5
	 * @since 1.0.0
	 * @return void
	 */
	private function init_license_classes() {
		// Use plugin root (ANALYTIFY_PRO_CLASSES_PATH), not WP_PLUGIN_DIR: PHPUnit loads Pro from a repo path
		// while WP_PLUGIN_DIR points at the temp WordPress install.
		$classes_path = defined( 'ANALYTIFY_PRO_CLASSES_PATH' ) ? ANALYTIFY_PRO_CLASSES_PATH : WP_PLUGIN_DIR . '/wp-analytify-pro/classes/';
		require_once $classes_path . 'class-analytify-pro-license-manager.php';
		require_once $classes_path . 'class-analytify-pro-addon-licenses.php';
		require_once $classes_path . 'class-analytify-pro-license-api.php';
		require_once $classes_path . 'class-analytify-pro-tracking-helpers.php';

		// Initialize instances.
		if ( class_exists( 'WP_Analytify_Pro_License_Manager' ) ) {
			$this->license_manager = WP_Analytify_Pro_License_Manager::instance();
		}
		if ( class_exists( 'WP_Analytify_Pro_Addon_Licenses' ) ) {
			$this->addon_licenses = WP_Analytify_Pro_Addon_Licenses::instance();
		}
		if ( class_exists( 'WP_Analytify_Pro_License_API' ) ) {
			$this->license_api = WP_Analytify_Pro_License_API::instance();
		}
		if ( class_exists( 'WP_Analytify_Pro_Tracking_Helpers' ) ) {
			$this->tracking_helpers = new WP_Analytify_Pro_Tracking_Helpers();
		}
	}

	/**
	 * Mask license key.
	 *
	 * @param string $key License key.
	 * @return string
	 */
	public function mask_license( $key ) {
		return $this->license_manager && method_exists( $this->license_manager, 'mask_license' ) ? $this->license_manager->mask_license( $key ) : '';
	}

	/**
	 * Get formatted masked license.
	 *
	 * @param string $key License key.
	 * @return string
	 */
	public function get_formatted_masked_license( $key ) {
		return $this->license_manager && method_exists( $this->license_manager, 'get_formatted_masked_license' ) ? $this->license_manager->get_formatted_masked_license( $key, $this->plugin_settings_base ) : '';
	}

	/**
	 * Get formatted masked WooCommerce license.
	 *
	 * @param string $key License key.
	 * @return string
	 */
	public function get_formatted_masked_woo_license( $key ) {
		return sprintf(
			'<p class="masked-license">%s <a href="%s">%s</a></p>',
			$this->mask_license( $key ),
			function_exists( 'admin_url' ) && function_exists( 'wp_create_nonce' ) ? admin_url( 'admin.php?page=analytify-settings&nonce=' . wp_create_nonce( 'wpanalytify-remove-woo-license' ) . '&wpanalytify-remove-woo-license=1' ) : '',
			function_exists( '_x' ) ? _x( 'Remove', 'Delete license', 'wp-analytify-pro' ) : esc_html__( 'Remove', 'wp-analytify-pro' )
		);
	}

	/**
	 * Get formatted masked EDD license.
	 *
	 * @param string $key License key.
	 * @return string
	 */
	public function get_formatted_masked_edd_license( $key ) {
		return sprintf(
			'<p class="masked-license">%s <a href="%s">%s</a></p>',
			$this->mask_license( $key ),
			function_exists( 'admin_url' ) && function_exists( 'wp_create_nonce' ) ? admin_url( 'admin.php?page=analytify-settings&nonce=' . wp_create_nonce( 'wpanalytify-remove-edd-license' ) . '&wpanalytify-remove-edd-license=1' ) : '',
			function_exists( '_x' ) ? _x( 'Remove', 'Delete license', 'wp-analytify-pro' ) : esc_html__( 'Remove', 'wp-analytify-pro' )
		);
	}

	/**
	 * Get formatted masked Email license.
	 *
	 * @param string $key License key.
	 * @return string
	 */
	public function get_formatted_masked_email_license( string $key ): string {
		return sprintf(
			'<p class="masked-license">%s <a href="%s">%s</a></p>',
			$this->mask_license( $key ),
			admin_url( 'admin.php?page=analytify-settings&nonce=' . wp_create_nonce( 'wpanalytify-remove-email-license' ) . '&wpanalytify-remove-email-license=1' ),
			_x( 'Remove', 'Delete license', 'wp-analytify-pro' )
		);
	}

	/**
	 * Get formatted masked Campaigns license.
	 *
	 * @param string $key License key.
	 * @return string
	 */
	public function get_formatted_masked_campaigns_license( string $key ): string {

		return sprintf(
			'<p class="masked-license">%s <a href="%s">%s</a></p>',
			$this->mask_license( $key ),
			admin_url( 'admin.php?page=analytify-settings&nonce=' . wp_create_nonce( 'wpanalytify-remove-campaigns-license' ) . '&wpanalytify-remove-campaigns-license=1' ),
			_x( 'Remove', 'Delete license', 'wp-analytify-pro' )
		);
	}


	/**
	 * Get formatted masked Events Tracking license.
	 *
	 * @param string $key License key.
	 * @return string
	 */
	public function get_formatted_masked_events_tracking_license( string $key ): string {

		return sprintf(
			'<p class="masked-license">%s <a href="%s">%s</a></p>',
			$this->mask_license( $key ),
			admin_url( 'admin.php?page=analytify-settings&nonce=' . wp_create_nonce( 'wpanalytify-remove-events-tracking-license' ) . '&wpanalytify-remove-events-tracking-license=1' ),
			_x( 'Remove', 'Delete license', 'wp-analytify-pro' )
		);
	}

	/**
	 * Get formatted masked Dimensions license.
	 *
	 * @param string $key License key.
	 * @return string
	 */
	public function get_formatted_masked_dimensions_license( string $key ): string {

		return sprintf(
			'<p class="masked-license">%s <a href="%s">%s</a></p>',
			$this->mask_license( $key ),
			admin_url( 'admin.php?page=analytify-settings&nonce=' . wp_create_nonce( 'wpanalytify-remove-dimensions-license' ) . '&wpanalytify-remove-dimensions-license=1' ),
			_x( 'Remove', 'Delete license', 'wp-analytify-pro' )
		);
	}

	/**
	 * Get formatted masked Authors license.
	 *
	 * @param string $key License key.
	 * @return string
	 */
	public function get_formatted_masked_authors_license( string $key ): string {

		return sprintf(
			'<p class="masked-license">%s <a href="%s">%s</a></p>',
			$this->mask_license( $key ),
			admin_url( 'admin.php?page=analytify-settings&nonce=' . wp_create_nonce( 'wpanalytify-remove-authors-license' ) . '&wpanalytify-remove-authors-license=1' ),
			_x( 'Remove', 'Delete license', 'wp-analytify-pro' )
		);
	}

	/**
	 * Get formatted masked Forms license.
	 *
	 * @param string $key License key.
	 * @return string
	 */
	public function get_formatted_masked_forms_license( string $key ): string {

		return sprintf(
			'<p class="masked-license">%s <a href="%s">%s</a></p>',
			$this->mask_license( $key ),
			admin_url( 'admin.php?page=analytify-settings&nonce=' . wp_create_nonce( 'wpanalytify-remove-forms-license' ) . '&wpanalytify-remove-forms-license=1' ),
			_x( 'Remove', 'Delete license', 'wp-analytify-pro' )
		);
	}

	/**
	 * Goals masked license
	 *
	 * @param  string $key License key to apply mask.
	 * @return string Formatted string.
	 *
	 * @since  2.0.16
	 */
	public function get_formatted_masked_goals_license( $key ) {

		return sprintf(
			'<p class="masked-license">%s <a href="%s">%s</a></p>',
			$this->mask_license( $key ),
			admin_url( 'admin.php?page=analytify-settings&nonce=' . wp_create_nonce( 'wpanalytify-remove-goals-license' ) . '&wpanalytify-remove-goals-license=1' ),
			_x( 'Remove', 'Delete license', 'wp-analytify-pro' )
		);
	}


	/**
	 * Check if license is expired
	 *
	 * @return bool
	 */
	public function is_license_expired(): bool {
		$license = $this->get_license_key();
		return $this->license_manager ? $this->license_manager->is_license_expired( $license ) : false;
	}


	/**
	 * Check if license is defined as constant
	 *
	 * @return bool
	 */
	public function is_license_constant(): bool {
		return $this->license_manager ? $this->license_manager->is_license_constant() : false;
	}

	/**
	 * Check if WooCommerce license is defined as constant
	 *
	 * @return bool
	 */
	public function is_woo_license_constant(): bool {
		return $this->addon_licenses ? $this->addon_licenses->is_woo_license_constant() : false;
	}

	/**
	 * Check if EDD license is defined as constant
	 *
	 * @return bool
	 */
	public function is_edd_license_constant(): bool {
		return $this->addon_licenses ? $this->addon_licenses->is_edd_license_constant() : false;
	}

	/**
	 * Check if Email license is defined as constant
	 *
	 * @return bool
	 */
	public function is_email_license_constant(): bool {
		return $this->addon_licenses ? $this->addon_licenses->is_email_license_constant() : false;
	}

	/**
	 * Check if Campaigns license is defined as constant
	 *
	 * @return bool
	 */
	public function is_campaigns_license_constant(): bool {
		return $this->addon_licenses ? $this->addon_licenses->is_campaigns_license_constant() : false;
	}

	/**
	 * Check if Dimensions license is defined as constant
	 *
	 * @return bool
	 */
	public function is_dimensions_license_constant(): bool {
		return $this->addon_licenses ? $this->addon_licenses->is_dimensions_license_constant() : false;
	}

	/**
	 * Check if Authors license is defined as constant
	 *
	 * @return bool
	 */
	public function is_authors_license_constant(): bool {
		return $this->addon_licenses ? $this->addon_licenses->is_authors_license_constant() : false;
	}

	/**
	 * Check if Forms license is defined as constant
	 *
	 * @return bool
	 */
	public function is_forms_license_constant(): bool {
		return $this->addon_licenses ? $this->addon_licenses->is_forms_license_constant() : false;
	}

	/**
	 * Check if Events Tracking license is defined as constant
	 *
	 * @return bool
	 */
	public function is_events_tracking_license_constant(): bool {
		return $this->addon_licenses ? $this->addon_licenses->is_events_tracking_license_constant() : false;
	}

	/**
	 * Check if license is defined manually as a Constant in wp-config.php
	 *
	 * @since  2.0.16
	 * @return boolean License key if exists.
	 */
	public function is_goals_license_constant(): bool {
		return $this->addon_licenses ? $this->addon_licenses->is_goals_license_constant() : false;
	}


	/**
	 * Get license key
	 *
	 * @return string
	 */
	public function get_license_key(): string {
		$key = $this->license_manager ? $this->license_manager->get_license_key() : '';
		return is_string( $key ) ? $key : '';
	}

	/**
	 * Get WooCommerce license key
	 *
	 * @param string $addon Addon name (optional).
	 * @return string
	 */
	public function get_woo_license_key( string $addon = '' ): string {
		$key = $this->addon_licenses ? $this->addon_licenses->get_woo_license_key( (bool) $addon ) : '';
		return is_string( $key ) ? $key : '';
	}

	/**
	 * Get EDD license key
	 *
	 * @param string $addon Addon name (optional).
	 * @return string
	 */
	public function get_edd_license_key( string $addon = '' ): string {
		$key = $this->addon_licenses ? $this->addon_licenses->get_edd_license_key( (bool) $addon ) : '';
		return is_string( $key ) ? $key : '';
	}

	/**
	 * Get Email license key
	 *
	 * @param string $addon Addon name (optional).
	 * @return string
	 */
	public function get_email_license_key( string $addon = '' ): string {
		$key = $this->addon_licenses ? $this->addon_licenses->get_email_license_key( (bool) $addon ) : '';
		return is_string( $key ) ? $key : '';
	}

	/**
	 * Get Campaigns license key
	 *
	 * @param string $addon Addon name (optional).
	 * @return string
	 */
	public function get_campaigns_license_key( string $addon = '' ): string {
		$key = $this->addon_licenses ? $this->addon_licenses->get_campaigns_license_key( (bool) $addon ) : '';
		return is_string( $key ) ? $key : '';
	}

	/**
	 * Get Dimensions license key
	 *
	 * @param string $addon Addon name (optional).
	 * @return string
	 */
	public function get_dimensions_license_key( string $addon = '' ): string {
		$key = $this->addon_licenses ? $this->addon_licenses->get_dimensions_license_key( (bool) $addon ) : '';
		return is_string( $key ) ? $key : '';
	}

	/**
	 * Get Authors license key
	 *
	 * @param string $addon Addon name (optional).
	 * @return string
	 */
	public function get_authors_license_key( string $addon = '' ): string {
		$key = $this->addon_licenses ? $this->addon_licenses->get_authors_license_key( (bool) $addon ) : '';
		return is_string( $key ) ? $key : '';
	}

	/**
	 * Get Forms license key
	 *
	 * @param string $addon Addon name (optional).
	 * @return string
	 */
	public function get_forms_license_key( string $addon = '' ): string {
		$key = $this->addon_licenses ? $this->addon_licenses->get_forms_license_key( (bool) $addon ) : '';
		return is_string( $key ) ? $key : '';
	}

	/**
	 * Get Events Tracking license key
	 *
	 * @param string $addon Addon name (optional).
	 * @return string
	 */
	public function get_events_tracking_license_key( string $addon = '' ): string {
		$key = $this->addon_licenses ? $this->addon_licenses->get_events_tracking_license_key( (bool) $addon ) : '';
		return is_string( $key ) ? $key : '';
	}

	/**
	 *  Get Goals license Key
	 *
	 * @param  string $addon Addon name (optional).
	 * @return string License key.
	 *
	 * @since 2.0.16
	 */
	public function get_goals_license_key( string $addon = '' ): string {
		$key = $this->addon_licenses ? $this->addon_licenses->get_goals_license_key( (bool) $addon ) : '';
		return is_string( $key ) ? $key : '';
	}


	/**
	 * Get license status
	 *
	 * @return string
	 */
	public function get_license_status(): string {
		$status = $this->license_manager ? $this->license_manager->get_license_status() : '';
		return is_string( $status ) ? $status : '';
	}


	/**
	 * Sets the license index in the $load_settings array class property and updates the wpanalytify_settings option.
	 *
	 * @param string $key License key.
	 * @return void
	 */
	public function set_license_key( string $key ) {
		if ( $this->license_manager ) {
			$this->license_manager->set_license_key( $key, $this->load_settings );
		}
	}

	/**
	 * Sets the license index in the $load_settings array class property and updates the wpanalytify_settings option.
	 *
	 * @param string $key License key.
	 * @return void
	 */
	public function set_woo_license_key( string $key ) {
		if ( $this->addon_licenses ) {
			$this->addon_licenses->set_woo_license_key( $key, $this->load_settings );
		}
	}

	/**
	 * Sets the license index in the $load_settings array class property and updates the wpanalytify_settings option.
	 *
	 * @param string $key License key.
	 * @return void
	 */
	public function set_edd_license_key( string $key ) {
		if ( $this->addon_licenses ) {
			$this->addon_licenses->set_edd_license_key( $key, $this->load_settings );
		}
	}

	/**
	 * Sets the license index in the $load_settings array class property and updates the wpanalytify_settings option.
	 *
	 * @param string $key License key.
	 * @return void
	 */
	public function set_email_license_key( string $key ) {
		if ( $this->addon_licenses ) {
			$this->addon_licenses->set_email_license_key( $key, $this->load_settings );
		}
	}

	/**
	 * Sets the license index in the $load_settings array class property and updates the wpanalytify_settings option.
	 *
	 * @param string $key License key.
	 * @return void
	 */
	public function set_campaigns_license_key( string $key ) {
		if ( $this->addon_licenses ) {
			$this->addon_licenses->set_campaigns_license_key( $key, $this->load_settings );
		}
	}


	/**
	 * Sets the license index in the $load_settings array class property and updates the wpanalytify_settings option.
	 *
	 * @param string $key License key.
	 * @return void
	 * @since 2.0.16
	 */
	public function set_goals_license_key( string $key ) {
		if ( $this->addon_licenses ) {
			$this->addon_licenses->set_goals_license_key( $key, $this->load_settings );
		}
	}

	/**
	 * Sets the license index in the $load_settings array class property and updates the wpanalytify_settings option.
	 *
	 * @param string $key License key.
	 * @return void
	 * @since 2.0.16
	 */
	public function set_authors_license_key( string $key ) {
		if ( $this->addon_licenses ) {
			$this->addon_licenses->set_authors_license_key( $key, $this->load_settings );
		}
	}

	/**
	 * Sets the license index in the $load_settings array class property and updates the wpanalytify_settings option.
	 *
	 * @param string $key License key.
	 * @return void
	 * @since 2.0.16
	 */
	public function set_forms_license_key( string $key ) {
		if ( $this->addon_licenses ) {
			$this->addon_licenses->set_forms_license_key( $key, $this->load_settings );
		}
	}

	/**
	 * Get latest version
	 *
	 * @since 2.0
	 * @since 9.0.0 Handles `false`, object, and array shapes from `wp_analytify_api_call()`.
	 *
	 * @param string $license License key.
	 * @return string
	 */
	public function get_latest_version( string $license ): string {

		$response = $this->wp_analytify_api_call( 'get_version', $license, defined( 'ANALYTIFY_PRODUCT_NAME' ) ? ANALYTIFY_PRODUCT_NAME : '', defined( 'ANALYTIFY_STORE_URL' ) ? ANALYTIFY_STORE_URL : '' );
		if ( false === $response ) {
			return '';
		}
		if ( is_object( $response ) && isset( $response->new_version ) && is_string( $response->new_version ) ) {
			return $response->new_version;
		}
		if ( is_array( $response ) && isset( $response['new_version'] ) && is_string( $response['new_version'] ) ) {
			return $response['new_version'];
		}
		return '';
	}

	/**
	 * Returns a formatted message dependant on the status of the license.
	 *
	 * @param bool   $trans Transaction data.
	 * @param string $context Context string.
	 *
	 * @since 2.0
	 * @since 9.0.0 Decodes `check_license()` JSON to an object for consistent property access.
	 * @return array<string, string>
	 */
	public function get_license_status_message( bool $trans = false, $context = null ): array {

		$license               = $this->get_license_key();
		$api_response_provided = true;
		$message               = '';

		if ( empty( $license ) && ! $trans ) {
			// translators: %s is the settings URL.
			$message = sprintf( __( '<strong>Activate Your License</strong> &mdash; Please <a href="%s" class="">enter your license key</a> to enable priority support and plugin updates.', 'wp-analytify-pro' ), admin_url( $this->plugin_settings_base . '#settings' ) );

			return array( 'message' => (string) $message );
		}

		if ( ! $trans ) {
			$trans = get_site_transient( 'wpanalytify_license_response' );

			if ( false === $trans ) {
				$trans = $this->check_license( $license );
			}

			if ( is_string( $trans ) ) {
				$decoded = json_decode( $trans );
				$trans   = is_object( $decoded ) ? $decoded : new \stdClass();
			} elseif ( ! is_object( $trans ) ) {
				$trans = new \stdClass();
			}

			$api_response_provided = false;
		}

		$errors = $trans->error ?? '';

		if ( 'expired' === $errors ) {

			$message_base = sprintf( '<strong>%s</strong> &mdash; ', __( 'Your License Has Expired', 'wp-analytify-pro' ) );
			// translators: %s is the account URL.
			$message_end = sprintf( __( 'Login to <a href="%s" target="blank">My Account</a> to renew. ', 'wp-analytify-pro' ), 'https://analytify.io/your-account/' );

			$contextual_messages = array(
				'default' => $message_base . $message_end,
				'update'  => $message_base . __( 'Updates are only available to those with an active license. ', 'wp-analytify-pro' ) . $message_end,
				'support' => $message_base . __( 'Only active licenses can submit support requests. ', 'wp-analytify-pro' ) . $message_end,
				'license' => $message_base . __( "All features will continue to work, but you won't be able to receive updates or email support. ", 'wp-analytify-pro' ) . $message_end,
			);

			if ( empty( $context ) ) {
				$context = 'default';
			}
			if ( ! empty( $contextual_messages[ $context ] ) ) {
				$message = $contextual_messages[ $context ];
			} elseif ( 'all' === $context ) {
				$message = $contextual_messages;
			}
		} elseif ( 'no_activations_left' === $errors ) {
			// translators: %s is the account URL.
			$message = sprintf( __( '<strong>No Activations Left</strong> &mdash; Please visit <a href="%s" target="_blank">My Account</a> to upgrade your license or deactivate a previous activation.', 'wp-analytify-pro' ), 'https://analytify.io/your-account/' );
		} elseif ( 'missing' === $errors ) {
			if ( ! $api_response_provided ) {
				// translators: %s is the account URL.
				$message = sprintf( __( '<strong>Your License Was Not Found</strong> &mdash; Please visit <a href="%s" target="_blank">My Account</a> to double check your license key.', 'wp-analytify-pro' ), 'https://analytify.io/your-account/' );
			} else {
				$error    = $errors;
				$message  = __( '<strong>Your License Was Not Found</strong> &mdash; ', 'wp-analytify-pro' );
				$message .= $error;
			}
		} else {
			$error = is_array( $errors ) ? reset( $errors ) : $errors;
			// translators: %1$s is the mailto link, %2$s is the email address.
			$message  = sprintf( __( '<strong>An Unexpected Error Occurred</strong> &mdash; Please contact us at <a href="%1$s">%2$s</a> and quote the following:', 'wp-analytify-pro' ), 'mailto:support@analytify.io', 'support@analytify.io' );
			$message .= sprintf( '<p>%s</p>', $error );
		}

		return array( 'message' => is_string( $message ) ? $message : ( is_array( $message ) ? implode( ' ', $message ) : '' ) );
	}


	/**
	 * Returns a formatted message dependant on the status of the WooCommerce add-on license.
	 *
	 * @param bool   $trans Transaction data.
	 * @param string $context Context string.
	 *
	 * @since  2.0
	 * @return array<string, string>
	 */
	public function get_woo_license_status_message( bool $trans = false, $context = null ): array {
		$result = $this->license_api ? $this->license_api->get_woo_license_status_message( $trans, $context ) : array();
		return is_array( $result ) ? $result : array( 'message' => '' );
	}


	/**
	 * Returns a formatted message dependant on the status of the EDD Add-on license.
	 *
	 * @param bool   $trans Transaction data.
	 * @param string $context Context string.
	 *
	 * @since  2.0
	 * @return array<string, string>
	 */
	public function get_edd_license_status_message( bool $trans = false, $context = null ): array {
		$result = $this->license_api ? $this->license_api->get_edd_license_status_message( $trans, $context ) : array();
		return is_array( $result ) ? $result : array( 'message' => '' );
	}

	/**
	 * Returns a formatted message dependant on the status of the Email Add-on license.
	 *
	 * @param bool   $trans Transaction data.
	 * @param string $context Context string.
	 *
	 * @since  2.0
	 * @return array<string, string>
	 */
	public function get_email_license_status_message( bool $trans = false, $context = null ): array {
		$result = $this->license_api ? $this->license_api->get_email_license_status_message( $trans, $context ) : array();
		return is_array( $result ) ? $result : array( 'message' => '' );
	}

	/**
	 * Returns a formatted message dependant on the status of the Campaigns Add-on license.
	 *
	 * @param bool   $trans Transaction data.
	 * @param string $context Context string.
	 *
	 * @since  2.0
	 * @return array<string, string>
	 */
	public function get_campaigns_license_status_message( bool $trans = false, $context = null ): array {
		$result = $this->license_api ? $this->license_api->get_campaigns_license_status_message( $trans, $context ) : array();
		return is_array( $result ) ? $result : array( 'message' => '' );
	}


	/**
	 * Returns a formatted message dependant on the status of the Goals Add-on license.
	 *
	 * @param bool   $trans Transaction data.
	 * @param string $context Context string.
	 *
	 * @since  2.0.16
	 * @return array<string, string>
	 */
	public function get_goals_license_status_message( bool $trans = false, $context = null ): array {
		$result = $this->license_api ? $this->license_api->get_goals_license_status_message( $trans, $context ) : array();
		return is_array( $result ) ? $result : array( 'message' => '' );
	}

	/**
	 * Returns a formatted message dependant on the status of the Dimensions Add-on license.
	 *
	 * @param bool   $trans Transaction data.
	 * @param string $context Context string.
	 *
	 * @since  2.0
	 * @return array<string, string>
	 */
	public function get_dimensions_license_status_message( bool $trans = false, $context = null ): array {
		$result = $this->license_api ? $this->license_api->get_dimensions_license_status_message( $trans, $context ) : array();
		return is_array( $result ) ? $result : array( 'message' => '' );
	}

	/**
	 * Returns a formatted message dependant on the status of the Authors Add-on license.
	 *
	 * @param bool   $trans Transaction data.
	 * @param string $context Context string.
	 *
	 * @since  2.0
	 * @return array<string, string>
	 */
	public function get_authors_license_status_message( bool $trans = false, $context = null ): array {
		$result = $this->license_api ? $this->license_api->get_authors_license_status_message( $trans, $context ) : array();
		return is_array( $result ) ? $result : array( 'message' => '' );
	}


	/**
	 * Returns a formatted message dependant on the status of the Forms Add-on license.
	 *
	 * @param bool   $trans Transaction data.
	 * @param string $context Context string.
	 *
	 * @since  2.0
	 * @return array<string, string>
	 */
	public function get_forms_license_status_message( bool $trans = false, $context = null ): array {
		$result = $this->license_api ? $this->license_api->get_forms_license_status_message( $trans, $context ) : array();
		return is_array( $result ) ? $result : array( 'message' => '' );
	}


	/**
	 * Returns a formatted message dependant on the status of the Events Tracking Add-on license.
	 *
	 * @param bool   $trans Transaction data.
	 * @param string $context Context string.
	 *
	 * @since  2.0
	 * @return array<string, string>
	 */
	public function get_events_tracking_license_status_message( bool $trans = false, $context = null ): array {
		$result = $this->license_api ? $this->license_api->get_events_tracking_license_status_message( $trans, $context ) : array();
		return is_array( $result ) ? $result : array( 'message' => '' );
	}

	/**
	 * Check license
	 *
	 * @since 2.0
	 * @since 9.0.0 Returns JSON for object API responses; empty string when the API returns `false`.
	 *
	 * @param string $license_key License key to be validated.
	 *
	 * @return string Value to be returned as response.
	 */
	public function check_license( string $license_key ): string {
		$result = $this->license_api ? $this->license_api->wp_analytify_api_call( 'check_license', $license_key, defined( 'ANALYTIFY_PRO_ID' ) ? (int) ANALYTIFY_PRO_ID : 0, defined( 'ANALYTIFY_STORE_URL' ) ? ANALYTIFY_STORE_URL : '' ) : false;
		if ( false === $result ) {
			return '';
		}
		if ( is_object( $result ) ) {
			return wp_json_encode( $result );
		}
		return is_string( $result ) ? $result : '';
	}

	/**
	 * Check WooCommerce license
	 *
	 * @param string $license_key License key to be validated.
	 *
	 * @return string Value to be returned as response.
	 */
	public function check_woo_license( string $license_key ): string {
		$result = $this->license_api ? $this->license_api->check_woo_license( $license_key ) : '';
		return is_string( $result ) ? $result : '';
	}

	/**
	 * Check EDD license
	 *
	 * @param string $license_key License key to be validated.
	 *
	 * @return string Value to be returned as response.
	 * @since  2.0
	 */
	public function check_edd_license( string $license_key ): string {
		$result = $this->license_api ? $this->license_api->check_edd_license( $license_key ) : '';
		return is_string( $result ) ? $result : '';
	}

	/**
	 * Check Email license
	 *
	 * @param string $license_key License key to be validated.
	 *
	 * @return string Value to be returned as response.
	 * @since  2.0
	 */
	public function check_email_license( string $license_key ): string {
		$result = $this->license_api ? $this->license_api->check_email_license( $license_key ) : '';
		return is_string( $result ) ? $result : '';
	}

	/**
	 * Check Campaigns license
	 *
	 * @param string $license_key License key to be validated.
	 *
	 * @return string Value to be returned as response.
	 * @since  2.0
	 */
	public function check_campaigns_license( string $license_key ): string {
		$result = $this->license_api ? $this->license_api->check_campaigns_license( $license_key ) : '';
		return is_string( $result ) ? $result : '';
	}

	/**
	 * Check Dimensions license
	 *
	 * @param string $license_key License key to be validated.
	 *
	 * @return string Value to be returned as response.
	 * @since  2.0
	 */
	public function check_dimensions_license( string $license_key ): string {
		$result = $this->license_api ? $this->license_api->check_dimensions_license( $license_key ) : '';
		return is_string( $result ) ? $result : '';
	}

	/**
	 * Check Authors license
	 *
	 * @param string $license_key License key to be validated.
	 *
	 * @return string Value to be returned as response.
	 * @since  2.0
	 */
	public function check_authors_license( string $license_key ): string {
		$result = $this->license_api ? $this->license_api->check_authors_license( $license_key ) : '';
		return is_string( $result ) ? $result : '';
	}

	/**
	 * Check Forms license
	 *
	 * @param string $license_key License key to be validated.
	 *
	 * @return string Value to be returned as response.
	 * @since  2.0
	 */
	public function check_forms_license( string $license_key ): string {
		$result = $this->license_api ? $this->license_api->check_forms_license( $license_key ) : '';
		return is_string( $result ) ? $result : '';
	}

	/**
	 * Check license key for goals addon
	 *
	 * @param string $license_key License key to be validated.
	 *
	 * @return string Value to be returned as response.
	 * @since  2.0.16
	 */
	public function check_goals_license( string $license_key ): string {
		return $this->license_api ? $this->license_api->check_goals_license( $license_key ) : '';
	}

	/**
	 * WP Analytify API call
	 *
	 * @since 2.0
	 * @since 9.0.0 Returns `false` when the license API instance is missing.
	 *
	 * @param string $type API call type.
	 * @param string $license License key.
	 * @param string $product_id Product ID.
	 * @param string $store_url Store URL.
	 * @return mixed
	 */
	public function wp_analytify_api_call( string $type, string $license, string $product_id, string $store_url ): mixed {
		return $this->license_api ? $this->license_api->wp_analytify_api_call( $type, $license, (int) $product_id, $store_url ) : false;
	}

	/**
	 * Check if update is available
	 *
	 * @return bool
	 */
	public function is_update_available(): bool {
		// License manager's is_update_available() is void, so we return false.
		return false;
	}

	/**
	 * Check if the current user should be tracked based on their role.
	 *
	 * @since 9.0.0
	 * @return bool True if the user should be tracked.
	 */
	public function is_track_user() {
		return $this->tracking_helpers ? $this->tracking_helpers->is_track_user() : true;
	}

	/**
	 * Check if Google Analytics tracking is enabled in settings.
	 *
	 * @since 9.0.0
	 * @return bool True if tracking is enabled.
	 */
	public function is_ga_enable() {
		return $this->tracking_helpers ? $this->tracking_helpers->is_ga_enable() : false;
	}

	/**
	 * Get the Google Analytics Client ID from cookie or generate a new one.
	 *
	 * @since 9.0.0
	 * @param int $order_id Optional. Order ID to check for saved CID.
	 * @return string The Client ID.
	 */
	public function get_ga_client_id( $order_id = 0 ) {
		return $this->tracking_helpers ? $this->tracking_helpers->get_ga_client_id( $order_id ) : '';
	}

	/**
	 * Generate a UUID v4 string.
	 *
	 * @since 9.0.0
	 * @return string UUID v4.
	 */
	public function generate_uuid() {
		return $this->tracking_helpers ? $this->tracking_helpers->generate_uuid() : '';
	}

	/**
	 * Extract the GA4 session ID from cookies.
	 *
	 * @since 9.0.0
	 * @param array $cookies The $_COOKIE array or similar.
	 * @return int The session ID or 0 if not found.
	 */
	public function analytify_filter_session_id( $cookies ) {
		return $this->tracking_helpers ? $this->tracking_helpers->analytify_filter_session_id( $cookies ) : 0;
	}

	/**
	 * Dispatch a GA4 event through Measurement Protocol if allowed.
	 *
	 * @since 9.0.0
	 * @param array $event The event data array (name and params).
	 * @return bool True if dispatched, false otherwise.
	 */
	public function dispatch_ga4_event( $event ) {
		return $this->tracking_helpers ? $this->tracking_helpers->dispatch_ga4_event( $event ) : false;
	}
}
