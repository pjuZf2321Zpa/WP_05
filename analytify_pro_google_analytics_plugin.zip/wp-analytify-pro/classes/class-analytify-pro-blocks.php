<?php
/**
 * Analytify Pro Blocks Integration
 *
 * @package WP_Analytify_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Analytify Pro Blocks Class
 *
 * @since 1.0.0
 */
class Analytify_Pro_Blocks {

	/**
	 * Singleton instance.
	 *
	 * @var Analytify_Pro_Blocks|null
	 */
	private static $obj;

	/**
	 * Private constructor for singliton class.
	 */
	final private function __construct() {

		$this->enqueue_scripts();
	}

	/**
	 * Create instance for class.
	 *
	 * @return Analytify_Pro_Blocks
	 */
	public static function get_instance() {

		if ( ! isset( self::$obj ) ) {
			self::$obj = new Analytify_Pro_Blocks();
		}

		return self::$obj;
	}

	/**
	 * Enqueue wp scripts.
	 *
	 * @return void
	 */
	private function enqueue_scripts() {

		// phpcs:ignore Squiz.PHP.CommentedOutCode.Found, Squiz.Commenting.InlineComment.InvalidEndChar -- Commented out action: add_action( 'enqueue_block_editor_assets', array( $this, 'enqueue_block_editor_assets_cb' ) ).
		add_action( 'init', array( $this, 'analytify_shortcode_block_init' ) );
	}

	/**
	 * Initialize shortcode block.
	 *
	 * @return void
	 */
	public function analytify_shortcode_block_init() {
		if ( defined( 'ANALYTIFY_PRO_ROOT_PATH' ) ) {
			register_block_type( ANALYTIFY_PRO_ROOT_PATH . '/assets/blocks' );
		}
	}

	/**
	 * Add transpiled blocks scripts.
	 *
	 * @param mixed $screen Screen object.
	 * @return void
	 */
	public function enqueue_block_editor_assets_cb( $screen ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found

		global $current_screen;

		$allowed_posts_types = array();
		if ( isset( $GLOBALS['WP_ANALYTIFY'] ) && is_object( $GLOBALS['WP_ANALYTIFY'] ) && isset( $GLOBALS['WP_ANALYTIFY']->settings ) && method_exists( $GLOBALS['WP_ANALYTIFY']->settings, 'get_option' ) ) {
			$allowed_posts_types = $GLOBALS['WP_ANALYTIFY']->settings->get_option( 'show_analytics_post_types_back_end', 'wp-analytify-admin', array() );
		}

		// Prevent on post types that are not allowed.
		if ( isset( $current_screen ) && is_object( $current_screen ) && isset( $current_screen->post_type ) && ! in_array( $current_screen->post_type, $allowed_posts_types, true ) ) {
			return;
		}

		if ( function_exists( 'wp_enqueue_script' ) && function_exists( 'plugins_url' ) && defined( 'ANALYTIFY_PRO_VERSION' ) ) {
			wp_enqueue_script(
				'analytify-blocks-editor',
				plugins_url( 'assets/js/blocks.js', __DIR__ ),
				array( 'wp-i18n', 'wp-element', 'wp-blocks', 'wp-components', 'wp-editor', 'wp-edit-post' ),
				ANALYTIFY_PRO_VERSION,
				true
			);
		}

		if ( function_exists( 'wp_localize_script' ) ) {
			wp_localize_script(
				'analytify-blocks-editor',
				'analytify_blocks_editor',
				array(
					'reporting_mod' => class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ? 'ga4' : 'ga3',
				)
			);
		}

		if ( function_exists( 'wp_enqueue_style' ) && function_exists( 'plugins_url' ) && defined( 'ANALYTIFY_PRO_VERSION' ) ) {
			wp_enqueue_style(
				'analytify-blocks-editor',
				plugins_url( 'assets/css/blocks' . analytify_pro_get_asset_suffix() . '.css', __DIR__ ),
				array(),
				ANALYTIFY_PRO_VERSION
			);
		}
	}
}

// Create Analytify_Pro_Blocks Instance.
Analytify_Pro_Blocks::get_instance();
