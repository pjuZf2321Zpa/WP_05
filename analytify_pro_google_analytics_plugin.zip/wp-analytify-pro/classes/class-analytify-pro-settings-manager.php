<?php // phpcs:ignore WordPress.Files.FileName.InvalidClassFileName
/**
 * WP Analytify Pro Settings Manager Class
 *
 * @package WP_Analytify_Pro
 * @since 8.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_Analytify_Pro_Settings_Manager' ) ) {
	/**
	 * WP Analytify Pro Settings Manager Class.
	 *
	 * @since 1.0.0
	 */
	class WP_Analytify_Pro_Settings_Manager {
		/**
		 * Constructor for future use.
		 *
		 * @return void
		 */
		public function __construct() {
		}

		/**
		 * Register plugin options.
		 *
		 * @return void
		 */
		public function wp_analytify_register_option() {
			register_setting(
				'wp-analytify-pro-settings',
				'wp-analytify-pro-options',
				array(
					'type'              => 'array',
					'description'       => 'WP Analytify Pro plugin settings',
					'sanitize_callback' => array( $this, 'sanitize_options' ),
					'default'           => array(),
				)
			);

			add_settings_section(
				'wp-analytify-pro-general',
				__( 'General Settings', 'wp-analytify-pro' ),
				array( $this, 'general_settings_section_callback' ),
				'wp-analytify-pro-settings'
			);

			// Add settings fields.
			add_settings_field(
				'enable_advanced_tracking',
				__( 'Enable Advanced Tracking', 'wp-analytify-pro' ),
				array( $this, 'checkbox_field_callback' ),
				'wp-analytify-pro-settings',
				'wp-analytify-pro-general',
				array(
					'label_for'   => 'enable_advanced_tracking',
					'description' => __( 'Enable advanced analytics tracking features', 'wp-analytify-pro' ),
				)
			);
		}

		/**
		 * Sanitize options
		 *
		 * @param mixed $input Input data to sanitize.
		 * @return array<string, mixed>
		 */
		public function sanitize_options( $input ) {
			$sanitized = array();

			if ( isset( $input['enable_advanced_tracking'] ) ) {
				$sanitized['enable_advanced_tracking'] = (bool) $input['enable_advanced_tracking'];
			}

			return $sanitized;
		}

		/**
		 * General settings section callback
		 *
		 * @return void
		 */
		public function general_settings_section_callback() {
			echo '<p>' . esc_html__( 'Configure general settings for WP Analytify Pro.', 'wp-analytify-pro' ) . '</p>';
		}

		/**
		 * Checkbox field callback
		 *
		 * @param array<string, mixed> $args Field arguments.
		 * @return void
		 */
		public function checkbox_field_callback( $args ) {
			$options  = get_option( 'wp-analytify-pro-options', array() );
			$field_id = $args['label_for'];
			$value    = isset( $options[ $field_id ] ) ? $options[ $field_id ] : false;

			echo '<input type="checkbox" id="' . esc_attr( $field_id ) . '" name="wp-analytify-pro-options[' . esc_attr( $field_id ) . ']" value="1" ' . checked( 1, $value, false ) . ' />';
			echo '<label for="' . esc_attr( $field_id ) . '">' . esc_html( $args['description'] ) . '</label>';
		}
		/**
		 * Add Pro setting tabs
		 *
		 * @param array<string, mixed> $old_tabs Existing tabs.
		 * @return array<int|string, mixed>
		 */
		public function wp_analytify_pro_setting_tabs( $old_tabs ) {

			$pro_tabs = array(
				array(
					'id'       => 'wp-analytify-dashboard',
					'title'    => __( 'Dashboard', 'wp-analytify-pro' ),
					'desc'     => 'Following settings will take effect statistics on Analytify Dashboard(s) reports only.',
					'priority' => '25',
				),
				array(
					'id'       => 'wp-analytify-license',
					'title'    => __( 'License', 'wp-analytify-pro' ),
					'priority' => '40',
				),
			);

			return array_merge( $old_tabs, $pro_tabs );
		}
		/**
		 * Add Pro accordion setting
		 *
		 * @param array<int|string, mixed> $old_tabs Existing tabs.
		 * @return array<int|string, mixed>
		 */
		public function wp_analytify_pro_accordion_setting( $old_tabs ) {

			$setting_tabs = apply_filters( 'wp_analytify_pro_setting_tabs', $old_tabs );
			return $setting_tabs;
		}
		/**
		 * Add Pro setting fields
		 *
		 * @param array<string, mixed> $old_fields Existing fields.
		 * @return array<string, mixed>
		 */
		public function wp_analytify_pro_setting_fields( $old_fields ) {

			$pro_fields = array(
				'wp-analytify-dashboard' => array(
					array(
						'name'  => 'delete_dashboard_cache',
						'label' => __( 'Delete cache', 'wp-analytify-pro' ),
						'desc'  => __( 'The Analytify dashboard (except real-time statistics) saves results for 24 hours. Enable this if you want to retrieve the current statistics.', 'wp-analytify-pro' ),
						'type'  => 'checkbox',
					),
					array(
						'name'    => 'show_analytics_roles_dashboard',
						'label'   => analytify__( 'Show analytics to (roles)', 'wp-analytify' ),
						'desc'    => __( 'Show the Analytify dashboard to the above-selected user roles only.', 'wp-analytify-pro' ),
						'type'    => 'chosen',
						'default' => array(),
						'options' => class_exists( 'WP_Analytify_Settings' ) && method_exists( 'WP_Analytify_Settings', 'get_current_roles' ) ? WP_Analytify_Settings::get_current_roles() : array(),
					),

					array(
						'name'    => 'show_analytics_panels_dashboard',
						'label'   => __( 'Dashboard analytics panels', 'wp-analytify-pro' ),
						'desc'    => __( 'Choose the panels to display in Analytify dashboard.', 'wp-analytify-pro' ),
						'type'    => 'chosen',
						'default' => array(),
						'options' => array(
							// RealTime Stats option.
							'show-compare-stats'        => __( 'Comparison Stats', 'wp-analytify-pro' ),
							'show-overall-dashboard'    => analytify__( 'General Stats', 'wp-analytify' ),
							'show-top-pages-dashboard'  => __( 'Top Pages Stats', 'wp-analytify-pro' ),
							'show-geographic-dashboard' => analytify__( 'Geographic Stats', 'wp-analytify' ),
							'show-system-stats'         => analytify__( 'System Stats', 'wp-analytify' ),
							'show-keywords-dashboard'   => analytify__( 'Keywords Stats', 'wp-analytify' ),
							'show-social-dashboard'     => analytify__( 'Social Media Stats', 'wp-analytify' ),
							'show-referrer-dashboard'   => analytify__( 'Referrers Stats', 'wp-analytify' ),
							'show-page-stats-dashboard' => __( 'Page entrance and exit stats', 'wp-analytify-pro' ),
						),
					),
				),
			);

			return array_merge( $old_fields, $pro_fields );
		}
	}
}
