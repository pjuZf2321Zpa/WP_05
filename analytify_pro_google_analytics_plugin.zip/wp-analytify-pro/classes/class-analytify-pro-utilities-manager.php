<?php // phpcs:ignore WordPress.Files.FileName.InvalidClassFileName -- Legacy file naming.
/**
 * WP Analytify Pro Utilities Manager.
 *
 * @package WP_Analytify_Pro
 * @since 8.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_Analytify_Pro_Utilities_Manager' ) ) {
	/**
	 * WP Analytify Pro Utilities Manager class.
	 */
	class WP_Analytify_Pro_Utilities_Manager {
		/**
		 * Constructor for future use
		 *
		 * @version 7.0.5
		 */
		public function __construct() {
		}

		/**
		 * Plugin action links
		 *
		 * @version 7.0.5
		 * @param array<int|string, string> $links Plugin action links.
		 * @return array<int|string, string>
		 */
		public function plugin_action_links( $links ) {
			return $links;
		}

		/**
		 * Plugin row meta links
		 *
		 * @version 7.0.5
		 * @param array<int|string, string> $input Already defined meta links.
		 * @param string                    $file  Plugin file path and name.
		 * @return array<int|string, string>
		 */
		public function plugin_row_meta( $input, $file ) {

			if ( 'wp-analytify-pro/wp-analytify-pro.php' !== $file ) {
				return $input;
			}

			$links = array(
				// translators: %1$s is the opening link tag, %2$s is the closing link tag.
				sprintf( esc_html__( '%1$s Documentation %2$s', 'wp-analytify-pro' ), '<a target="_blank" href="https://analytify.io/documentation?utm_source=analytify-pro&utm_medium=plugins&utm_campaign=user-guide&utm_content=documentation-link">', '</a>' ),
			);

			$input = array_merge( $input, $links );

			return $input;
		}
		/**
		 * Display warning if profiles are not selected.
		 *
		 * @version 7.0.5
		 * @return void
		 */
		public function pa_check_warnings() {

			if ( function_exists( 'add_action' ) ) {
				add_action(
					'admin_footer',
					array(
						&$this,
						'profile_warning',
					)
				);
			}
		}

		/**
		 * Display warning messages for profile and authentication.
		 *
		 * @return void
		 */
		public function profile_warning() {

			$profile_id  = function_exists( 'get_option' ) ? get_option( 'pt_webprofile' ) : '';
			$acces_token = function_exists( 'get_option' ) ? get_option( 'post_analytics_token' ) : '';

			if ( ! isset( $acces_token ) || empty( $acces_token ) ) {
				// translators: %1$s is the opening link tag, %2$s is the closing link tag.
				echo "<div id='message' class='error'><p><strong>" . ( function_exists( 'esc_html__' ) ? sprintf( esc_html__( 'Analytify is not active. Please %1$sAuthenticate%2$s in order to get started using this plugin.', 'wp-analytify-pro' ), '<a href="' . esc_url( function_exists( 'menu_page_url' ) ? menu_page_url( 'analytify-settings', false ) : '' ) . '">', '</a>' ) : 'Analytify is not active. Please Authenticate in order to get started using this plugin.' ) . '</p></div>';
			} elseif ( ! isset( $profile_id ) || empty( $profile_id ) ) {
				// translators: %1$s is the error div opening tag, %2$s is the profile link opening tag, %3$s is the profile link closing tag and error div closing tag.
				printf( function_exists( 'esc_html__' ) ? esc_html__( '%1$s Google Analytics Profile is not set. Set the %2$s Profile %3$s', 'wp-analytify-pro' ) : '%1$s Google Analytics Profile is not set. Set the %2$s Profile %3$s', '<div class="error"><p><strong>', '<a href="' . esc_url( function_exists( 'menu_page_url' ) ? menu_page_url( 'analytify-settings', false ) : '' ) . '&tab=profile">', '</a></p></div>' );
			}
		}

		/**
		 * Add Top Pages Export Icon.
		 *
		 * @since 2.0.17
		 * @return void
		 */
		public function top_page_text() {
			?>
		<a href="#" class="analytify-export-data analytify_tooltip" data-stats-type="top-pages">
			<span class="analytify_tooltiptext"><?php esc_html_e( 'Export Top Pages', 'wp-analytify-pro' ); ?></span>
		</a>
		<img src="<?php echo esc_url( function_exists( 'admin_url' ) ? admin_url( 'images/spinner.gif' ) : '' ); ?>" class='analytify-export-loader' style="display:none">
			<?php
		}

		/**
		 * Add Top Keywords Export Icon.
		 *
		 * @since 2.0.17
		 * @return void
		 */
		public function top_keyword_text() {
			?>
			<a href="#" class="analytify-export-data analytify_tooltip" data-stats-type="top-keywords">
				<span class="analytify_tooltiptext"><?php esc_html_e( 'Export Top Keywords', 'wp-analytify-pro' ); ?></span>
			</a>
			<img src="<?php echo esc_url( function_exists( 'admin_url' ) ? admin_url( 'images/spinner.gif' ) : '' ); ?>" class='analytify-export-loader' style="display:none">
			<?php
		}

		/**
		 * Add Top Social Media Export Icon.
		 *
		 * @since 2.0.17
		 * @return void
		 */
		public function top_social_media_text() {
			?>
			<a href="#" class="analytify-export-data analytify_tooltip" data-stats-type="top-social-media">
				<span class="analytify_tooltiptext"><?php esc_html_e( 'Export Top Social Media', 'wp-analytify-pro' ); ?></span>
			</a>
			<img src="<?php echo esc_url( function_exists( 'admin_url' ) ? admin_url( 'images/spinner.gif' ) : '' ); ?>" class='analytify-export-loader' style="display:none">
			<?php
		}

		/**
		 * Add Top Reffers Export Icon.
		 *
		 * @since 2.0.17
		 * @return void
		 */
		public function top_reffers_text() {
			?>
			<a href="#" class="analytify-export-data analytify_tooltip" data-stats-type="top-referrer">
				<span class="analytify_tooltiptext"><?php esc_html_e( 'Export Top Reffers', 'wp-analytify-pro' ); ?></span>
			</a>
			<img src="<?php echo esc_url( function_exists( 'admin_url' ) ? admin_url( 'images/spinner.gif' ) : '' ); ?>" class='analytify-export-loader' style="display:none">
			<?php
		}

		/**
		 * Add What Happens Export Icon.
		 *
		 * @since 2.0.17
		 * @return void
		 */
		public function top_page_stats_text() {
			?>
			<a href="#" class="analytify-export-data analytify_tooltip" data-stats-type="what-happen">
				<span class="analytify_tooltiptext"><?php esc_html_e( 'Export Stats', 'wp-analytify-pro' ); ?></span>
			</a>
			<img src="<?php echo esc_url( function_exists( 'admin_url' ) ? admin_url( 'images/spinner.gif' ) : '' ); ?>" class='analytify-export-loader' style="display:none">
			<?php
		}

		/**
		 * Add Top Mobiles Export Icon.
		 *
		 * @since 2.0.17
		 * @return void
		 */
		public function after_top_mobile_device_text() {
			?>
			<span class="analytify_top_geographic_detials analytify_tp_btn">
				<a href="#" class="analytify-export-data analytify_tooltip" data-stats-type="top-mobile-device">
					<span class="analytify_tooltiptext"><?php esc_html_e( 'Export Top Mobile Device', 'wp-analytify-pro' ); ?></span>
				</a>
				<img src="<?php echo esc_url( function_exists( 'admin_url' ) ? admin_url( 'images/spinner.gif' ) : '' ); ?>" class='analytify-export-loader' style="display:none">
			</span>
			<?php
		}

		/**
		 * Add Top Operating System Export Icon.
		 *
		 * @since 2.0.17
		 * @return void
		 */
		public function after_top_operating_system_text() {
			?>
			<span class="analytify_top_geographic_detials analytify_tp_btn">
				<a href="#" class="analytify-export-data analytify_tooltip" data-stats-type="top-operating-system">
					<span class="analytify_tooltiptext"><?php esc_html_e( 'Export Top Operating System', 'wp-analytify-pro' ); ?></span>
				</a>
				<img src="<?php echo esc_url( function_exists( 'admin_url' ) ? admin_url( 'images/spinner.gif' ) : '' ); ?>" class='analytify-export-loader' style="display:none">
			</span>
			<?php
		}

		/**
		 * Add Top Browsers Export Icon.
		 *
		 * @since 2.0.17
		 * @return void
		 */
		public function after_top_browser_text() {
			?>
			<span class="analytify_top_geographic_detials analytify_tp_btn">
				<a href="#" class="analytify-export-data analytify_tooltip" data-stats-type="top-browsers">
					<span class="analytify_tooltiptext"><?php esc_html_e( 'Export Top Browsers', 'wp-analytify-pro' ); ?></span>
				</a>
				<img src="<?php echo esc_url( function_exists( 'admin_url' ) ? admin_url( 'images/spinner.gif' ) : '' ); ?>" class='analytify-export-loader' style="display:none">
			</span>
			<?php
		}

		/**
		 * Add Top Cities Export Icon.
		 *
		 * @since 2.0.17
		 * @return void
		 */
		public function after_top_city_text() {
			?>
			<a href="#" class="analytify-export-data analytify_tooltip" data-stats-type="top-cities">
				<span class="analytify_tooltiptext"><?php esc_html_e( 'Export Top Cities', 'wp-analytify-pro' ); ?></span>
			</a>
			<img src="<?php echo esc_url( function_exists( 'admin_url' ) ? admin_url( 'images/spinner.gif' ) : '' ); ?>" class='analytify-export-loader' style="display:none">
			<?php
		}

		/**
		 * Add Top Countries Export Icon.
		 *
		 * @since 2.0.17
		 * @return void
		 */
		public function after_top_country_text() {
			?>
			<a href="#" class="analytify-export-data analytify_tooltip" data-stats-type="top-countries">
				<span class="analytify_tooltiptext"><?php esc_html_e( 'Export Top Countries', 'wp-analytify-pro' ); ?></span>
			</a>
			<img src="<?php echo esc_url( function_exists( 'admin_url' ) ? admin_url( 'images/spinner.gif' ) : '' ); ?>" class='analytify-export-loader' style="display:none">
			<?php
		}

		/**
		 * Generate CSV export
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function generate_csv() {
			if ( isset( $_GET['security'], $_GET['action'], $_GET['report_type'], $_GET['start_date'], $_GET['end_date'] ) && function_exists( 'wp_verify_nonce' ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['security'] ) ), 'analytify_export_nonce' ) && 'analytify_export' === sanitize_text_field( wp_unslash( $_GET['action'] ) ) ) {

				$report_type = sanitize_text_field( wp_unslash( $_GET['report_type'] ) );
				$start_date  = sanitize_text_field( wp_unslash( $_GET['start_date'] ) );
				$end_date    = sanitize_text_field( wp_unslash( $_GET['end_date'] ) );
				$name        = $report_type . '-' . $start_date . '|' . $end_date . '.csv';

				header( 'Content-type: text/csv' );
				header( 'Content-Disposition: attachment; filename="' . $name . '"' );

				// Do not cache the file.
				header( 'Pragma: no-cache' );
				header( 'Expires: 0' );

				// Create a file pointer connected to the output stream.
				$file = fopen( 'php://output', 'w' );

				$data = function_exists( 'get_option' ) ? get_option( 'analytify_csv_data' ) : array();

				if ( $file && is_array( $data ) ) {
					foreach ( $data as $value ) {
						if ( ! is_array( $value ) ) {
							continue;
						}
						// PHP 8.4+/8.5: $escape must be passed explicitly (default will change).
						fputcsv( $file, $value, ',', '"', '\\' );
					}
				}
				exit();
			}
		}

		/**
		 * Add metabox for excluding single post stats.
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function exclusion_meta_box() {

			if ( function_exists( 'wp_nonce_field' ) ) {
				wp_nonce_field( 'analytify_exclusion_metabox', 'analytify_exclusion_metabox_nonce' );
			}

			global $post;

			$skipped = (bool) ( function_exists( 'get_post_meta' ) && isset( $post ) && is_object( $post ) && isset( $post->ID ) ? get_post_meta( $post->ID, '_analytify_skip_tracking', true ) : false );
			?>

		<div class="analytify-metabox" id="analytify-metabox-skip-tracking">
			<div class="analytify-metabox-input-checkbox">
				<label class="">
					<input type="checkbox" name="_analytify_skip_tracking" value="1" <?php checked( $skipped ); ?>>
					<span class="analytify-metabox-input-checkbox-label"><?php esc_html_e( 'Exclude this page from Google Analytics Tracking.', 'wp-analytify-pro' ); ?></span>
				</label>
			</div>
		</div>

			<?php
		}

		/**
		 * Register exclusion metabox field.
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function register_exclusion_meta_field() {

			if ( function_exists( 'register_post_meta' ) ) {
				register_post_meta(
					'',
					'_analytify_skip_tracking',
					array(
						'show_in_rest'  => true,
						'single'        => true,
						'type'          => 'boolean',
						'auth_callback' => function () {
							return function_exists( 'current_user_can' ) ? current_user_can( 'edit_posts' ) : false;
						},
					)
				);
			}
		}

		/**
		 * Save exclusion metabox value.
		 *
		 * @since 1.0.0
		 * @param int $post_id Post ID.
		 * @return void
		 */
		public function save_exclusion_meta_field( $post_id ) {

			if ( ! isset( $_POST['analytify_exclusion_metabox_nonce'] ) || ! function_exists( 'wp_verify_nonce' ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['analytify_exclusion_metabox_nonce'] ) ), 'analytify_exclusion_metabox' ) ) {
				return;
			}

			$skipped = intval( isset( $_POST['_analytify_skip_tracking'] ) ? $_POST['_analytify_skip_tracking'] : 0 );

			if ( function_exists( 'update_post_meta' ) ) {
				update_post_meta( $post_id, '_analytify_skip_tracking', $skipped );
			}
		}

		/**
		 * GA dimensions callback
		 *
		 * @param array<string, mixed> $args Dimension arguments.
		 * @return array<string, mixed>
		 */
		public function callback_ga_dimensions_repeater( $args ) {
			$available_dimensions = array();

			foreach ( $args['options'] as $key => $value ) {
				if ( true !== $value['is_enable'] ) {
					continue;
				}

				$available_dimensions[ $key ] = $value;
			}

			return $available_dimensions;
		}

		/**
		 * Load mobile stats
		 *
		 * @param string $start_date           Start date.
		 * @param string $end_date             End date.
		 * @param string $dashboard_profile_ID Dashboard profile ID.
		 * @return void
		 */
		public function load_mobile_stats( $start_date, $end_date, $dashboard_profile_ID ) { // phpcs:ignore WordPress.NamingConventions.ValidVariableName.VariableNotSnakeCase
			?>
	<div id="wp-analytify-mobile-stats-box"><img class="dashboard-loader"  class="dashboard-loader" src="<?php echo esc_url( defined( 'ANALYTIFY_PLUGIN_URL' ) ? ANALYTIFY_PLUGIN_URL . 'assets/images/loading.gif' : '' ); ?>"></div>
			<?php
	// phpcs:disable WordPress.NamingConventions.ValidVariableName.VariableNotSnakeCase -- JavaScript parameter name matches backend convention.
			?>
	<script>
	//<![CDATA[
		jQuery( function($) {
			$.get(ajaxurl, { action:'analytify_load_mobile_stats', dashboard_profile_ID:"<?php echo esc_js( $dashboard_profile_ID ); ?>", start_date:"<?php echo esc_js( $start_date ); ?>", end_date: "<?php echo esc_js( $end_date ); ?>" },function(data){
				$('#wp-analytify-mobile-stats-box').html(data);
			});
		});
	//]]>
	</script>
			<?php
	// phpcs:enable WordPress.NamingConventions.ValidVariableName.VariableNotSnakeCase
			?>
			<?php
		}
	}
}
