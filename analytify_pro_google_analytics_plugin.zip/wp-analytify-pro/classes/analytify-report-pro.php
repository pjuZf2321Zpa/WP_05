<?php
// phpcs:ignoreFile WordPress.Files.FileName.InvalidClassFileName
/**
 * Analytify Report Pro Class
 *
 * @package WP_Analytify_Pro
 */

/**
 * Exit if accessed directly.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
/**
 * Generates and returns reports - for pro version.
 */
class Analytify_Report_Pro extends Analytify_Report_Abstract {

	/**
	 * Returns country stats.
	 *
	 * @since 7.0.0
	 * @version 7.0.5
	 * @param string $type Type of stats to retrieve (limited or full).
	 * @return array<string, mixed>
	 */
	public function get_country_stats( $type = 'limited' ) {
		$cache_key = $this->cache_key( 'countries' );

		// API limit.
		$api_limit = apply_filters( 'analytify_api_limit_country_stats', 210, $this->dashboard_type, $this->post_id, $type );

		if ( $this->is_ga4 ) {
			return $this->country_stats_ga4( $api_limit, $cache_key, $type );
		}

		return array();
	}

	/**
	 * Generates country stats - GA4.
	 *
	 * @version 7.0.5
	 * @param int    $api_limit API limit.
	 * @param string $cache_key Cache key.
	 * @param string $type Type of stats to retrieve (limited or full).
	 * @return array<string, mixed>
	 */
	protected function country_stats_ga4( $api_limit, $cache_key, $type ) {

		$stats = array();

		$dimensions = array(
			'country',
		);
		$filters    = array(
			array(
				'type'           => 'dimension',
				'name'           => 'country',
				'match_type'     => 4,
				'value'          => '(not set)',
				'not_expression' => true,
			),
		);

		$raw = isset( $this->wp_analytify ) && is_object( $this->wp_analytify ) && method_exists( $this->wp_analytify, 'get_reports' ) ? $this->wp_analytify->get_reports(
			$cache_key,
			array(
				'sessions',
			),
			$this->get_dates(),
			$this->attach_post_url_dimension( $dimensions ),
			array(
				'type'  => 'metric',
				'name'  => 'sessions',
				'order' => 'desc',
			),
			array(
				'logic'   => 'AND',
				'filters' => $this->attach_post_url_filter( $filters ),
			),
			$api_limit
		) : array();

		if ( isset( $raw['rows'] ) && $raw['rows'] ) {

			if ( 'csv' !== $this->dashboard_type || 'full' !== $type ) {
				$raw['rows'] = array_slice( $raw['rows'], 0, 5 );
			}

			foreach ( $raw['rows'] as $row ) {
				$single_stat['country'] = $row['country'];
				if ( 'csv' !== $this->dashboard_type ) {
					$single_stat['country'] = '<span class="' . ( function_exists( 'pretty_class' ) ? esc_attr( pretty_class( $row['country'] ) ) : '' ) . ' analytify_flages"></span> ' . esc_html( $row['country'] );
				}
				$single_stat['sessions'] = class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' ) ? WPANALYTIFY_Utils::pretty_numbers( $row['sessions'] ) : $row['sessions'];

				$stats[] = $single_stat;
			}
		}

		return array(
			'stats' => $stats,
		);
	}


	/**
	 * Returns city stats.
	 *
	 * @version 7.0.5
	 * @return array<string, mixed>
	 */
	public function get_city_stats() {
		$cache_key = $this->cache_key( 'cities' );

		// API limit.
		$default   = 'csv' === $this->dashboard_type ? 200 : 5;
		$api_limit = apply_filters( 'analytify_api_limit_city_stats', $default, $this->dashboard_type, $this->post_id );

		if ( $this->is_ga4 ) {
			return $this->city_stats_ga4( $api_limit, $cache_key );
		}

		return array();
	}

	/**
	 * Generates city stats - GA4.
	 *
	 * @version 7.0.5
	 * @param int    $api_limit API limit.
	 * @param string $cache_key Cache key.
	 * @return array<string, mixed>
	 */
	protected function city_stats_ga4( $api_limit, $cache_key ) {
		$stats = array();

		$dimensions = array(
			'city',
			'country',
		);
		$filters    = array(
			array(
				'type'           => 'dimension',
				'name'           => 'city',
				'match_type'     => 4,
				'value'          => '(not set)',
				'not_expression' => true,
			),
			array(
				'type'           => 'dimension',
				'name'           => 'country',
				'match_type'     => 4,
				'value'          => '(not set)',
				'not_expression' => true,
			),
		);

		$raw = isset( $this->wp_analytify ) && is_object( $this->wp_analytify ) && method_exists( $this->wp_analytify, 'get_reports' ) ? $this->wp_analytify->get_reports(
			$cache_key,
			array(
				'sessions',
			),
			$this->get_dates(),
			$this->attach_post_url_dimension( $dimensions ),
			array(
				'type'  => 'metric',
				'name'  => 'sessions',
				'order' => 'desc',
			),
			array(
				'logic'   => 'AND',
				'filters' => $this->attach_post_url_filter( $filters ),
			),
			$api_limit
		) : array();

		if ( isset( $raw['rows'] ) && $raw['rows'] ) {
			foreach ( $raw['rows'] as $row ) {
				if ( 'csv' === $this->dashboard_type ) {
					$single_stat['country'] = $row['country'];
					$single_stat['city']    = $row['city'];
				} else {
					$single_stat['city'] = '<span class="' . ( function_exists( 'pretty_class' ) ? esc_attr( pretty_class( $row['country'] ) ) : '' ) . ' analytify_flages"></span> ' . esc_html( $row['city'] );
				}
				$single_stat['sessions'] = $row['sessions'];

				$stats[] = $single_stat;
			}
		}

		return array(
			'stats' => $stats,
		);
	}


	/**
	 * Returns browser stats.
	 *
	 * @version 7.0.5
	 * @return array<string, mixed>
	 */
	public function get_browser_stats() {
		$cache_key = $this->cache_key( 'browsers' );

		// API limit.
		$default   = 'csv' === $this->dashboard_type ? 100 : 5;
		$api_limit = apply_filters( 'analytify_api_limit_browser_stats', $default, $this->dashboard_type, $this->post_id );

		if ( $this->is_ga4 ) {
			return $this->browser_stats_ga4( $api_limit, $cache_key );
		}

		return array();
	}

	/**
	 * Generates browser stats - GA4.
	 *
	 * @version 7.0.5
	 * @param int    $api_limit API limit.
	 * @param string $cache_key Cache key.
	 * @return array<string, mixed>
	 */
	protected function browser_stats_ga4( $api_limit, $cache_key ) {

		$stats = array();

		$dimensions = array(
			'browser',
			'operatingSystem',
		);
		$filters    = array(
			array(
				'type'           => 'dimension',
				'name'           => 'operatingSystem',
				'match_type'     => 4,
				'value'          => '(not set)',
				'not_expression' => true,
			),
		);

		$raw = isset( $this->wp_analytify ) && is_object( $this->wp_analytify ) && method_exists( $this->wp_analytify, 'get_reports' ) ? $this->wp_analytify->get_reports(
			$cache_key,
			array(
				'sessions',
			),
			$this->get_dates(),
			$this->attach_post_url_dimension( $dimensions ),
			array(
				'type'  => 'metric',
				'name'  => 'sessions',
				'order' => 'desc',
			),
			array(
				'logic'   => 'AND',
				'filters' => $this->attach_post_url_filter( $filters ),
			),
			$api_limit
		) : array();

		if ( isset( $raw['rows'] ) && $raw['rows'] ) {
			foreach ( $raw['rows'] as $row ) {

				if ( 'csv' === $this->dashboard_type ) {
					$single_stat['browser'] = $row['browser'];
					$single_stat['os']      = $row['operatingSystem'];
				} else {
					$single_stat['browser'] = '<span role="img" aria-label="' . esc_attr( $row['browser'] ) . '" class="'
					. ( function_exists( 'pretty_class' ) ? esc_attr( pretty_class( $row['browser'] ) ) : '' )
					. ' analytify_social_icons"></span><span class="'
					. ( function_exists( 'pretty_class' ) ? esc_attr( pretty_class( $row['operatingSystem'] ) ) : '' )
					. ' analytify_social_icons"></span>' . esc_html( $row['browser'] ) . ' ' . esc_html( $row['operatingSystem'] );
				}
				$single_stat['sessions'] = class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' ) ? WPANALYTIFY_Utils::pretty_numbers( $row['sessions'] ) : $row['sessions'];

				$stats[] = $single_stat;
			}
		}

		return array(
			'stats' => $stats,
		);
	}


	/**
	 * Returns OS stats.
	 *
	 * @version 7.0.5
	 * @return array<string, mixed>
	 */
	public function get_os_stats() {
		$cache_key = $this->cache_key( 'os' );

		// API limit.
		$default   = 'csv' === $this->dashboard_type ? 100 : 5;
		$api_limit = apply_filters( 'analytify_api_limit_os_stats', $default, $this->dashboard_type, $this->post_id );

		if ( $this->is_ga4 ) {
			return $this->os_stats_ga4( $api_limit, $cache_key );
		}

		return array();
	}

	/**
	 * Generates os stats - GA4.
	 *
	 * @version 7.0.5
	 * @param int    $api_limit API limit.
	 * @param string $cache_key Cache key.
	 * @return array<string, mixed>
	 */
	protected function os_stats_ga4( $api_limit, $cache_key ) {

		$stats = array();

		$dimensions = array(
			'operatingSystem',
			'operatingSystemVersion',
		);
		$filters    = array(
			array(
				'type'           => 'dimension',
				'name'           => 'operatingSystemVersion',
				'match_type'     => 4,
				'value'          => '(not set)',
				'not_expression' => true,
			),
		);

		$raw = isset( $this->wp_analytify ) && is_object( $this->wp_analytify ) && method_exists( $this->wp_analytify, 'get_reports' ) ? $this->wp_analytify->get_reports(
			$cache_key,
			array(
				'sessions',
			),
			$this->get_dates(),
			$this->attach_post_url_dimension( $dimensions ),
			array(
				'type'  => 'metric',
				'name'  => 'sessions',
				'order' => 'desc',
			),
			array(
				'logic'   => 'AND',
				'filters' => $this->attach_post_url_filter( $filters ),
			),
			$api_limit
		) : array();

		if ( isset( $raw['rows'] ) && $raw['rows'] ) {
			foreach ( $raw['rows'] as $row ) {

				if ( 'csv' === $this->dashboard_type ) {
					$single_stat['os']         = $row['operatingSystem'];
					$single_stat['os_version'] = $row['operatingSystemVersion'];
				} else {
					$single_stat['os'] = '<span  role="img" aria-label="' . esc_attr( $row['operatingSystem'] ) . '" class="' . ( function_exists( 'pretty_class' ) ? esc_attr( pretty_class( $row['operatingSystem'] ) ) : '' ) . ' analytify_social_icons"></span> ' . esc_html( $row['operatingSystem'] ) . ' ' . esc_html( $row['operatingSystemVersion'] );
				}
				$single_stat['sessions'] = class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' ) ? WPANALYTIFY_Utils::pretty_numbers( $row['sessions'] ) : $row['sessions'];

				$stats[] = $single_stat;
			}
		}

		return array(
			'stats' => $stats,
		);
	}

	/**
	 * Returns mobile stats.
	 *
	 * @return array<string, mixed>
	 */
	public function get_mobile_stats() {
		$cache_key = $this->cache_key( 'mobile' );

		// API limit.
		$default   = 'csv' === $this->dashboard_type ? 100 : 5;
		$api_limit = apply_filters( 'analytify_api_limit_mobile_stats', $default, $this->dashboard_type, $this->post_id );

		if ( $this->is_ga4 ) {
			return $this->mobile_stats_ga4( $api_limit, $cache_key );
		}

		return array();
	}

	/**
	 * Generates mobile stats - GA4.
	 *
	 * @param int    $api_limit API limit.
	 * @param string $cache_key Cache key.
	 * @return array<string, mixed>
	 */
	protected function mobile_stats_ga4( $api_limit, $cache_key ) {

		$stats = array();

		$dimensions = array(
			'mobileDeviceBranding',
			'mobileDeviceModel',
		);
		$filters    = array(
			array(
				'type'           => 'dimension',
				'name'           => 'deviceCategory',
				'match_type'     => 4,
				'value'          => 'desktop',
				'not_expression' => true,
			),
			array(
				'type'           => 'dimension',
				'name'           => 'mobileDeviceModel',
				'match_type'     => 4,
				'value'          => '(not set)',
				'not_expression' => true,
			),
		);

		$raw = isset( $this->wp_analytify ) && is_object( $this->wp_analytify ) && method_exists( $this->wp_analytify, 'get_reports' ) ? $this->wp_analytify->get_reports(
			$cache_key,
			array(
				'sessions',
			),
			$this->get_dates(),
			$this->attach_post_url_dimension( $dimensions ),
			array(
				'type'  => 'metric',
				'name'  => 'sessions',
				'order' => 'desc',
			),
			array(
				'logic'   => 'AND',
				'filters' => $this->attach_post_url_filter( $filters ),
			),
			$api_limit
		) : array();

		if ( isset( $raw['rows'] ) && $raw['rows'] ) {
			foreach ( $raw['rows'] as $row ) {

				if ( 'csv' === $this->dashboard_type ) {
					$single_stat['mobile'] = $row['mobileDeviceModel'];
					$single_stat['brand']  = $row['mobileDeviceBranding'];
				} else {
					$single_stat['mobile'] = '<span role="img" aria-label="' . esc_attr( $row['mobileDeviceBranding'] ) . '" class="' . ( function_exists( 'pretty_class' ) ? esc_attr( pretty_class( $row['mobileDeviceBranding'] ) ) : '' ) . ' analytify_social_icons"></span> ' . esc_html( $row['mobileDeviceBranding'] ) . ' ' . esc_html( $row['mobileDeviceModel'] );
				}
				$single_stat['sessions'] = class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' ) ? WPANALYTIFY_Utils::pretty_numbers( $row['sessions'] ) : $row['sessions'];

				$stats[] = $single_stat;
			}
		}

		return array(
			'stats' => $stats,
		);
	}

	/**
	 * Returns referer stats.
	 *
	 * @return array<string, mixed>
	 */
	public function get_referrer_stats() {
		$cache_key = $this->cache_key( 'referrer' );

		// API limit.
		$default   = 'csv' === $this->dashboard_type ? 100 : 5;
		$api_limit = apply_filters( 'analytify_api_limit_referrer_stats', $default, $this->dashboard_type, $this->post_id );

		if ( $this->is_ga4 ) {
			return $this->referrer_stats_ga4( $api_limit, $cache_key );
		}

		return array();
	}

	/**
	 * Generates referrer stats - GA4.
	 *
	 * @param int    $api_limit API limit.
	 * @param string $cache_key Cache key.
	 * @return array<string, mixed>
	 */
	protected function referrer_stats_ga4( $api_limit, $cache_key ) {
		$stats = array();

		$dimensions = array(
			'sessionSource',
			'sessionMedium',
		);
		$filters    = array();

		$raw = isset( $this->wp_analytify ) && is_object( $this->wp_analytify ) && method_exists( $this->wp_analytify, 'get_reports' ) ? $this->wp_analytify->get_reports(
			$cache_key,
			array(
				'sessions',
			),
			$this->get_dates(),
			$this->attach_post_url_dimension( $dimensions ),
			array(
				'type'  => 'metric',
				'name'  => 'sessions',
				'order' => 'desc',
			),
			array(
				'logic'   => 'AND',
				'filters' => $this->attach_post_url_filter( $filters ),
			),
			$api_limit
		) : array();

		$total_sessions = 0;
		if ( isset( $raw['aggregations']['sessions'] ) ) {
			$total_sessions = $raw['aggregations']['sessions'];
		}

		if ( isset( $raw['rows'] ) && $raw['rows'] ) {
			foreach ( $raw['rows'] as $row ) {

				if ( 'csv' === $this->dashboard_type ) {
					$single_stat['source'] = $row['sessionSource'];
					$single_stat['medium'] = $row['sessionMedium'];
				} else {
					$single_stat['referer'] = esc_html( $row['sessionSource'] ) . '/' . esc_html( $row['sessionMedium'] );
					if ( $total_sessions && $total_sessions > 0 ) {
						$single_stat['referer'] .= ' <span class="analytify_bar_graph"><span style="width:' . ( $row['sessions'] / $total_sessions ) * 100 . '%"></span></span>';
					}
				}
				$single_stat['sessions'] = class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' ) ? WPANALYTIFY_Utils::pretty_numbers( $row['sessions'] ) : $row['sessions'];

				$stats[] = $single_stat;
			}
		}

		return array(
			'stats' => $stats,
		);
	}


	/**
	 * Returns social media stats.
	 *
	 * @return array<string, mixed>|false
	 */
	public function get_social_media_stats() {
		$cache_key = $this->cache_key( 'social' );

		// API limit.
		$default   = 'csv' === $this->dashboard_type ? 200 : 5;
		$api_limit = apply_filters( 'analytify_api_limit_social_media_stats', $default, $this->dashboard_type, $this->post_id );

		if ( $this->is_ga4 ) {
			// TODO: missing_ga4.
			return false;
		}

		return false;
	}


	/**
	 * Returns what's happening stats.
	 *
	 * @return array<string, mixed>|false
	 */
	public function get_whats_happening_stats() {
		$cache_key = $this->cache_key( 'whats-happening' );

		// API limit.
		switch ( $this->dashboard_type ) {
			case 'single_post':
				$default = 1;
				break;
			case 'csv':
				$default = 100;
				break;
			default:
				$default = 5;
				break;
		}

		$api_limit = apply_filters( 'analytify_api_limit_what_happen_stats', $default, $this->dashboard_type, $this->post_id );

		if ( $this->is_ga4 ) {
			// TODO: missing_ga4.
			return false;
		}

		return false;
	}

	/**
	 * Returns video tracking stats.
	 *
	 * For single-post context, uses per-post meta cache to avoid API calls on every page load.
	 * Cache is refreshed on next request after TTL or via cron (analytify_refresh_video_tracking_cache).
	 *
	 * @since  7.0.0
	 * @version 9.0.0 Added per-post meta cache and cron refresh support.
	 * @return array<string, mixed>
	 */
	public function get_video_tracking_stats() {
		$cache_key = $this->cache_key( 'video-tracking' );

		// API limit.
		$default   = 'csv' === $this->dashboard_type ? 200 : 50;
		$api_limit = apply_filters( 'analytify_api_limit_video_tracking_stats', $default, $this->dashboard_type, $this->post_id );

		if ( ! $this->is_ga4 ) {
			return array( 'stats' => array() );
		}
		$advanced = get_option( 'wp-analytify-advanced', array() );
		if ( 'on' !== ( $advanced['video_tracking'] ?? 'off' ) ) {
			return array( 'stats' => array() );
		}

		// Per-post cache: read from post meta when available to reduce API/DB overhead.
		if ( 'single_post' === $this->dashboard_type && $this->post_id > 0 ) {
			$cached = $this->get_video_tracking_post_meta_cache();
			if ( is_array( $cached ) && ! empty( $cached ) ) {
				return $cached;
			}
		}

		$result = $this->video_tracking_stats_ga4( $api_limit, $cache_key );

		// Store in post meta for single-post so future requests and email reports can use cache.
		if ( 'single_post' === $this->dashboard_type && $this->post_id > 0 && isset( $result['stats'] ) ) {
			$this->set_video_tracking_post_meta_cache( $result );
		}

		return $result;
	}

	/**
	 * Get cached video tracking stats from post meta (single-post only).
	 *
	 * @since 9.0.0
	 * @version 9.0.0
	 * @return array<string, mixed>|null Cached result with 'stats' key, or null if miss/expired.
	 */
	protected function get_video_tracking_post_meta_cache() {
		$post_id = (int) $this->post_id;
		if ( $post_id <= 0 ) {
			return null;
		}
		$stored = get_post_meta( $post_id, '_analytify_video_tracking_cache', true );
		if ( ! is_array( $stored ) || empty( $stored['stats'] ) || empty( $stored['start'] ) || empty( $stored['end'] ) || empty( $stored['updated'] ) ) {
			return null;
		}
		$dates        = $this->get_dates();
		$stored_start = strtotime( (string) $stored['start'] );
		$stored_end   = strtotime( (string) $stored['end'] );
		$dates_start  = strtotime( (string) $dates['start'] );
		$dates_end    = strtotime( (string) $dates['end'] );
		if ( false === $stored_start || false === $stored_end || false === $dates_start || false === $dates_end || $stored_start !== $dates_start || $stored_end !== $dates_end ) {
			return null;
		}
		$default_ttl = 'single_post' === $this->dashboard_type ? 12 * HOUR_IN_SECONDS : 6 * HOUR_IN_SECONDS;
		$ttl         = (int) apply_filters( 'analytify_video_tracking_cache_ttl', $default_ttl, $this->dashboard_type, $post_id );
		if ( ( time() - (int) $stored['updated'] ) > $ttl ) {
			return null;
		}
		return array( 'stats' => $stored['stats'] );
	}

	/**
	 * Store video tracking stats in post meta for single-post cache.
	 *
	 * @since 9.0.0
	 * @version 9.0.0
	 * @param array<string, mixed> $result Result with 'stats' key.
	 */
	protected function set_video_tracking_post_meta_cache( $result ) {
		$post_id = (int) $this->post_id;
		if ( $post_id <= 0 || ! isset( $result['stats'] ) ) {
			return;
		}
		$dates = $this->get_dates();
		$cache = array(
			'stats'   => $result['stats'],
			'start'   => $dates['start'],
			'end'     => $dates['end'],
			'updated' => time(),
		);
		update_post_meta( $post_id, '_analytify_video_tracking_cache', $cache );
	}

	/**
	 * Generates video tracking stats - GA4.
	 *
	 * @since  7.0.0
	 * @version 9.0.0 Used by get_video_tracking_stats() with per-post cache layer.
	 * @param int    $api_limit API limit.
	 * @param string $cache_key Cache key.
	 * @return array<string, mixed>
	 */
	protected function video_tracking_stats_ga4( $api_limit, $cache_key ) {
		$stats = array();

		$dimensions = array(
			'customEvent:wpa_category',
			'customEvent:wpa_video_title',
			'customEvent:wpa_video_provider',
			'customEvent:wpa_video_action',
			'customEvent:wpa_video_duration',
		);

		// For single post, add pagePathPlusQueryString dimension (required for video tracking events).
		if ( 'single_post' === $this->dashboard_type ) {
			$dimensions[] = 'pagePathPlusQueryString';
		}

		$filters = array(
			array(
				'type'           => 'dimension',
				'name'           => 'customEvent:wpa_category',
				'match_type'     => 1,
				'value'          => 'Analytify Video Tracking',
				'not_expression' => false,
			),
		);

		// For single post, add pagePathPlusQueryString filter instead of using attach_post_url_filter.
		if ( 'single_post' === $this->dashboard_type ) {
			$link   = apply_filters( 'analytify_single_stats_permalink', $this->post_url );
			if ( function_exists( 'apply_filters_deprecated' ) ) {
				$link = apply_filters_deprecated( 'analytify_sinlge_stats_permalink', array( $link ), '9.1.1', 'analytify_single_stats_permalink' );
			}
			$link   = is_string( $link ) ? $link : '';
			if ( '' === $link ) {
				return array( 'stats' => array() );
			}
			$u_post = wp_parse_url( urldecode( $link ) );
			if ( ! is_array( $u_post ) || empty( $u_post['path'] ) ) {
				return array( 'stats' => array() );
			}

			// Get clean path directly from parsed URL - don't use analytify_page_path_filter 
			// as it may add extra data that corrupts the filter value.
			$filter = is_array( $u_post ) && isset( $u_post['path'] ) ? $u_post['path'] : '';

			// Ensure path has trailing slash if it doesn't already (matching GA4 format).
			if ( ! empty( $filter ) && '/' !== substr( $filter, -1 ) ) {
				$filter .= '/';
			}

			// Url have query string incase of WPML.
			if ( isset( $u_post['query'] ) && ! empty( $u_post['query'] ) ) {
				$filter .= '?' . $u_post['query'];
			}

			// Ensure we only have the clean path value, nothing else.
			$filter = trim( $filter );

			$filters[] = array(
				'type'       => 'dimension',
				'name'       => 'pagePathPlusQueryString',
				'match_type' => 'EXACT', // Use EXACT match type as string (matches GA4 Query Explorer).
				'value'      => $filter,
			);
		}

		$raw = isset( $this->wp_analytify ) && is_object( $this->wp_analytify ) && method_exists( $this->wp_analytify, 'get_reports' ) ? $this->wp_analytify->get_reports(
			$cache_key,
			array( 'eventCount' ),
			$this->get_dates(),
			$dimensions,
			array(
				'type'  => 'metric',
				'name'  => 'eventCount',
				'order' => 'desc',
			),
			array(
				'logic'   => 'AND',
				'filters' => $filters,
			),
			$api_limit
		) : array();

		if ( isset( $raw['rows'] ) && $raw['rows'] ) {
			foreach ( $raw['rows'] as $row ) {
				$single_stat['event_label']    = $row['customEvent:wpa_video_title'] ?? '';
				$single_stat['video_action']    = $row['customEvent:wpa_video_action'] ?? '';
				$single_stat['video_provider']  = $row['customEvent:wpa_video_provider'] ?? '';
				$single_stat['video_duration']  = $row['customEvent:wpa_video_duration'] ?? 0;
				$single_stat['event_count']    = class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' ) ? WPANALYTIFY_Utils::pretty_numbers( $row['eventCount'] ?? 0 ) : ( $row['eventCount'] ?? 0 );

				$stats[] = $single_stat;
			}
		}

		return array(
			'stats' => $stats,
		);
	}
}
