<?php // phpcs:ignore WordPress.Files.FileName.InvalidClassFileName
/**
 * WP Analytify Pro REST API Tracking Endpoints Class
 *
 * This class handles tracking-related REST API endpoints including:
 * - Events tracking
 * - Video tracking
 * - Custom dimensions
 *
 * @package WP_Analytify_Pro
 * @since 8.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_Analytify_Pro_REST_Tracking' ) ) {

	/**
	 * WP Analytify Pro REST API Tracking Endpoints Class
	 *
	 * @since 1.0.0
	 */
	class WP_Analytify_Pro_REST_Tracking {

		/**
		 * Singleton instance.
		 *
		 * @var WP_Analytify_Pro_REST_Tracking|null $instance The one true WP_Analytify_Pro_REST_Tracking.
		 * @since 1.0.0
		 */
		private static $instance;

		/**
		 * The main Analytify object.
		 *
		 * @var object|null
		 */
		private $wp_analytify;

		/**
		 * GA version (ga4 or ga3).
		 *
		 * @var string
		 */
		private $ga_mode;

		/**
		 * Selected 'start state'.
		 *
		 * @var string
		 */
		private $start_date;

		/**
		 * Selected 'End state'.
		 *
		 * @var string
		 */
		private $end_date;

		/**
		 * Date difference.
		 *
		 * @var string
		 */
		private $date_differ;

		/**
		 * Type parameter.
		 *
		 * @var string
		 */
		private $type;


		/**
		 * Get active instance.
		 *
		 * @access public
		 * @since 1.0.0
		 * @return WP_Analytify_Pro_REST_Tracking The one true WP_Analytify_Pro_REST_Tracking.
		 */
		public static function instance() {
			if ( ! self::$instance ) {
				self::$instance = new WP_Analytify_Pro_REST_Tracking();
				self::$instance->init();
			}
			return self::$instance;
		}

		/**
		 * Initialize the class
		 *
		 * @access private
		 * @since 1.0.0
		 * @return void
		 */
		private function init() {
			// Don't initialize wp_analytify here - it will be set when set_dates is called.
		}

		/**
		 * Set dates for the reports.
		 *
		 * @param string $start_date Start date.
		 * @param string $end_date End date.
		 * @param string $date_differ Date difference.
		 * @param string $type Type parameter.
		 * @param object $wp_analytify The main Analytify object.
		 * @param string $ga_mode GA mode.
		 * @return void
		 */
		public function set_dates( $start_date, $end_date, $date_differ, $type, $wp_analytify = null, $ga_mode = null ) {
			$this->start_date  = $start_date;
			$this->end_date    = $end_date;
			$this->date_differ = $date_differ;
			$this->type        = $type;

			// Set wp_analytify and ga_mode if provided.
			if ( null !== $wp_analytify ) {
				$this->wp_analytify = $wp_analytify;
			}
			if ( null !== $ga_mode ) {
				$this->ga_mode = $ga_mode;
			}
		}

		/**
		 * Endpoint for 'Events tracking'.
		 *
		 * @return array<string, mixed>
		 */
		public function events_tracking() {

			// Debug: Check if wp_analytify is available.
			if ( ! $this->wp_analytify ) {
				return array(
					'success'  => false,
					'error'    => 'wp_analytify object not available',
					'external' => array(
						'headers' => array(),
						'stats'   => array(),
					),
					'download' => array(
						'headers' => array(),
						'stats'   => array(),
					),
					'tel'      => array(
						'headers' => array(),
						'stats'   => array(),
					),
					'outbound' => array(
						'headers' => array(),
						'stats'   => array(),
					),
					'mail'     => array(
						'headers' => array(),
						'stats'   => array(),
					),
				);
			}

			// API limit for events.
			$api_limit = apply_filters( 'analytify_api_limit_events_tracking_stats', 200, 'dashboard' );

			$stats_external = array();
			$stats_download = array();
			$stats_tel      = array();
			$stats_outbound = array();
			$stats_mail     = array();

			if ( 'ga4' === $this->ga_mode && isset( $this->wp_analytify ) && method_exists( $this->wp_analytify, 'get_reports' ) ) {
				// Fetch event tracking stats.
				$stats_raw = $this->wp_analytify->get_reports(
					'show-default-events-tracking',
					array(
						'eventCount',
					),
					$this->get_dates(),
					array(
						'customEvent:wpa_category',
						'customEvent:wpa_link_label',
						'customEvent:wpa_link_action',
					),
					array(
						'type'  => 'metric',
						'name'  => 'eventCount',
						'order' => 'desc',
					),
					array(
						'logic'   => 'OR',
						'filters' => array(
							array(
								'type'       => 'dimension',
								'name'       => 'customEvent:wpa_category',
								'match_type' => '1',
								'value'      => 'external',
							),
							array(
								'type'       => 'dimension',
								'name'       => 'customEvent:wpa_category',
								'match_type' => '1',
								'value'      => 'download',
							),
							array(
								'type'       => 'dimension',
								'name'       => 'customEvent:wpa_category',
								'match_type' => '1',
								'value'      => 'tel',
							),
							array(
								'type'       => 'dimension',
								'name'       => 'customEvent:wpa_category',
								'match_type' => '1',
								'value'      => 'outbound-link',
							),
							array(
								'type'       => 'dimension',
								'name'       => 'customEvent:wpa_category',
								'match_type' => '1',
								'value'      => 'mail',
							),
						),
					),
					$api_limit
				);

			} else {
				$stats_raw = array();
			}

			if ( isset( $stats_raw['rows'] ) && ! empty( $stats_raw['rows'] ) ) {
				// Process the data directly instead of relying on the filter.
				$stats_external = array();
				$stats_download = array();
				$stats_tel      = array();
				$stats_outbound = array();
				$stats_mail     = array();

				foreach ( $stats_raw['rows'] as $row ) {
					$category = $row['customEvent:wpa_category'] ?? '';
					$label    = $row['customEvent:wpa_link_label'] ?? '';
					$action   = $row['customEvent:wpa_link_action'] ?? '';
					$count    = $row['eventCount'] ?? 0;

					$formatted_row = array(
						'no'     => null, // Will be set by frontend.
						'label'  => $label,
						'action' => $action,
						'views'  => $count,
					);

					switch ( $category ) {
						case 'external':
							$stats_external[] = $formatted_row;
							break;
						case 'download':
							$stats_download[] = $formatted_row;
							break;
						case 'tel':
							$stats_tel[] = $formatted_row;
							break;
						case 'outbound-link':
							$stats_outbound[] = $formatted_row;
							break;
						case 'mail':
							$stats_mail[] = $formatted_row;
							break;
						default:
							break;
					}
				}

				// Wrap external links in <a> tags.
				foreach ( $stats_external as $key => $stat ) {
					$stats_external[ $key ]['action'] = '<a href="' . esc_url_raw( $stats_external[ $key ]['action'] ) . '" target="_blank">' . esc_html( $stats_external[ $key ]['action'] ) . '</a>';
				}
			}

			$headers = array(
				'no'     => array(
					'label'    => esc_html__( '#', 'wp-analytify-pro' ),
					'type'     => 'counter',
					'th_class' => 'analytify_table_header_no_events',
					'td_class' => '',
				),
				'label'  => array(
					'label'    => esc_html__( 'Label', 'wp-analytify-pro' ),
					'th_class' => 'analytify_txt_left',
					'td_class' => '',
				),
				'action' => array(
					'label'    => esc_html__( 'Link', 'wp-analytify-pro' ),
					'th_class' => 'analytify_txt_left',
					'td_class' => '',
				),
				'views'  => array(
					'label'    => esc_html__( 'Clicks', 'wp-analytify-pro' ),
					'th_class' => 'analytify_value_row',
					'td_class' => 'analytify_txt_center',
				),
			);

			return array(
				'success'    => true,
				'external'   => array(
					'headers' => $headers,
					'stats'   => $stats_external,
				),
				'download'   => array(
					'headers' => $headers,
					'stats'   => $stats_download,
				),
				'tel'        => array(
					'headers' => $headers,
					'stats'   => $stats_tel,
				),
				'outbound'   => array(
					'headers' => $headers,
					'stats'   => $stats_outbound,
				),
				'mail'       => array(
					'headers' => $headers,
					'stats'   => $stats_mail,
				),
				'pagination' => true,
			);
		}

		/**
		 * Enhanced tel tracking endpoint (GA4).
		 *
		 * Uses the same GA4 `runReport` request contract as core `get_reports()` (metrics,
		 * dates, dimensions, order, filters, limit). Implemented in Pro via
		 * `enhanced_tel_ga4_get_reports()` so HTTP/JSON API errors surface in `ga_report_error`
		 * without changing the free plugin. Override dimensions via
		 * `analytify_enhanced_tel_tracking_dimensions`.
		 *
		 * @since 9.0.0
		 * @return array<string, mixed> rows, summary placeholders, optional ga_report_error, debug.
		 */
		public function enhanced_tel_tracking() {
			// Lower default than 1000 — fewer rows reduces GA4 query time; override via filter.
			$api_limit = apply_filters( 'analytify_api_limit_enhanced_tel_tracking_stats', 200, 'dashboard' );

			$empty_summary = array(
				'device_breakdown' => array(),
				'peak_hours'       => array(),
				'traffic_sources'  => array(),
				'country_codes'    => array(),
			);

			if ( ! $this->wp_analytify || ! is_object( $this->wp_analytify ) || ! method_exists( $this->wp_analytify, 'get_reports' ) ) {
				return array(
					'rows'    => array(),
					'summary' => $empty_summary,
					'error'   => __( 'Google Analytics is not available. Please reconnect your account.', 'wp-analytify-pro' ),
				);
			}

			if ( 'ga4' !== $this->ga_mode ) {
				return array(
					'rows'    => array(),
					'summary' => $empty_summary,
					'error'   => __( 'Enhanced tel tracking requires a GA4 property.', 'wp-analytify-pro' ),
				);
			}

			$reporting_property = class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_reporting_property' )
				? WPANALYTIFY_Utils::get_reporting_property()
				: '';
			if ( ! is_string( $reporting_property ) || '' === trim( $reporting_property ) ) {
				return array(
					'rows'    => array(),
					'summary' => $empty_summary,
					'error'   => __( 'No Google Analytics property is selected. Choose a property in Analytify settings.', 'wp-analytify-pro' ),
				);
			}

			if ( empty( $this->start_date ) || empty( $this->end_date ) ) {
				$logger = function_exists( 'analytify_get_logger' ) ? analytify_get_logger() : null;
				if ( $logger && method_exists( $logger, 'warning' ) ) {
					$logger->warning(
						'Enhanced tel tracking: missing date parameters.',
						array(
							'source'     => 'WP_Analytify_Pro_REST_Tracking::enhanced_tel_tracking',
							'start_date' => $this->start_date,
							'end_date'   => $this->end_date,
						)
					);
				}
				return array(
					'rows'    => array(),
					'summary' => $empty_summary,
					'error'   => __( 'Missing date parameters.', 'wp-analytify-pro' ),
				);
			}

			if (
				! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $this->start_date ) ||
				! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $this->end_date )
			) {
				$logger = function_exists( 'analytify_get_logger' ) ? analytify_get_logger() : null;
				if ( $logger && method_exists( $logger, 'warning' ) ) {
					$logger->warning(
						'Enhanced tel tracking: invalid date format.',
						array(
							'source'     => 'WP_Analytify_Pro_REST_Tracking::enhanced_tel_tracking',
							'start_date' => $this->start_date,
							'end_date'   => $this->end_date,
						)
					);
				}
				return array(
					'rows'    => array(),
					'summary' => $empty_summary,
					'error'   => __( 'Invalid date format.', 'wp-analytify-pro' ),
				);
			}

			/*
			 * GA4: register matching event-scoped custom dimensions (Admin → Custom definitions).
			 * Unknown dimension names produce an API error (surfaced as ga_report_error). Empty rows
			 * with no error usually indicate no tel events in the selected range.
			 */
			$tel_dimensions = apply_filters(
				'analytify_enhanced_tel_tracking_dimensions',
				array(
					'customEvent:wpa_category',
					'customEvent:wpa_click_day',
					'customEvent:wpa_click_hour',
					'customEvent:wpa_country_code',
					'customEvent:wpa_device_category',
					'customEvent:wpa_link_action',
					'customEvent:wpa_link_label',
					'customEvent:wpa_traffic_source',
				),
				$this->get_dates(),
				$api_limit
			);

			$stats_raw = $this->enhanced_tel_ga4_get_reports(
				'show-enhanced-tel-tracking',
				array( 'eventCount' ),
				$this->get_dates(),
				$tel_dimensions,
				array(
					'type'  => 'metric',
					'name'  => 'eventCount',
					'order' => 'desc',
				),
				array(
					'logic'   => 'AND',
					'filters' => array(
						array(
							'type'           => 'dimension',
							'name'           => 'customEvent:wpa_category',
							'match_type'     => '1',
							'value'          => 'tel',
							'not_expression' => false,
						),
					),
				),
				$api_limit
			);

			$processed_rows = array();

			if ( isset( $stats_raw['rows'] ) && ! empty( $stats_raw['rows'] ) ) {
				foreach ( $stats_raw['rows'] as $row ) {
					$country_code     = $this->format_enhanced_tel_country_code( $row['customEvent:wpa_country_code'] ?? '' );
					$processed_rows[] = array(
						'category'       => $row['customEvent:wpa_category'] ?? '',
						'phone_number'   => $row['customEvent:wpa_link_action'] ?? '',
						'label'          => $row['customEvent:wpa_link_label'] ?? '',
						'device'         => $row['customEvent:wpa_device_category'] ?? '',
						'day'            => $row['customEvent:wpa_click_day'] ?? '',
						'hour'           => $row['customEvent:wpa_click_hour'] ?? '',
						'traffic_source' => $row['customEvent:wpa_traffic_source'] ?? '',
						'country_code'   => $country_code,
						'clicks'         => intval( $row['eventCount'] ?? 0 ),
					);
				}
			} elseif ( defined( 'WP_DEBUG' ) && WP_DEBUG && is_array( $stats_raw ) ) {
				$logger = function_exists( 'analytify_get_logger' ) ? analytify_get_logger() : null;
				if ( $logger && method_exists( $logger, 'warning' ) ) {
					$logger->warning(
						'Enhanced tel tracking: no rows in GA4 response.',
						array(
							'source'        => 'WP_Analytify_Pro_REST_Tracking::enhanced_tel_tracking',
							'response_keys' => array_keys( $stats_raw ),
						)
					);
				}
			}

			$ga_err = ( is_array( $stats_raw ) && ! empty( $stats_raw['error'] ) ) ? $stats_raw['error'] : null;

			// Unregistered GA4 custom definitions: API returns "not a valid dimension" — treat as empty report
			// so dashboards show "no activity" instead of raw Google error text.
			if ( $ga_err && $this->enhanced_tel_is_unregistered_ga_dimension_error( $ga_err ) ) {
				$ga_err            = null;
				$processed_rows    = array();
				$stats_raw         = is_array( $stats_raw ) ? $stats_raw : array();
				$stats_raw['rows'] = array();
				if ( isset( $stats_raw['error'] ) ) {
					unset( $stats_raw['error'] );
				}
			}

			return array(
				'rows'            => $processed_rows,
				'summary'         => $empty_summary,
				'ga_report_error' => $ga_err,
				'debug'           => array(
					'raw_response' => $stats_raw,
					'ga_mode'      => $this->ga_mode,
					'start_date'   => $this->start_date,
					'end_date'     => $this->end_date,
				),
			);
		}

		/**
		 * Endpoint for 'Video Tracking' (module).
		 *
		 * @return array<string, mixed>
		 */
		public function video_tracking() {
			// Fetch video tracking data from GA4.
			$video_stats_raw = isset( $this->wp_analytify ) && method_exists( $this->wp_analytify, 'get_reports' ) ? $this->wp_analytify->get_reports(
				'show-video-tracking',
				array( 'eventCount' ),
				$this->get_dates(),
				array(
					'customEvent:wpa_category',
					'customEvent:wpa_video_title',
					'customEvent:wpa_video_provider',
					'customEvent:wpa_video_action',
					'customEvent:wpa_video_duration',
				),
				array(
					'type'  => 'metric',
					'name'  => 'eventCount',
					'order' => 'desc',
				),
				array(
					'logic'   => 'AND',
					'filters' => array(
						array(
							'type'           => 'dimension',
							'name'           => 'customEvent:wpa_category',
							'match_type'     => 1,
							'value'          => 'Analytify Video Tracking',
							'not_expression' => false,
						),
					),
				),
				50
			) : array();

			// Initialize formatted stats array.
			$stats_video = array();
			if ( ! empty( $video_stats_raw['rows'] ) ) {
				foreach ( $video_stats_raw['rows'] as $row ) {
					$stats_video[] = array(
						'event_label'    => $row['customEvent:wpa_video_title'] ?? '',
						'video_action'   => $row['customEvent:wpa_video_action'] ?? '',
						'video_provider' => $row['customEvent:wpa_video_provider'] ?? '',
						'video_duration' => $row['customEvent:wpa_video_duration'] ?? 0,
						'event_count'    => $row['eventCount'] ?? 0,
					);
				}
			}

			return array(
				'success'    => true,
				'headers'    => array(
					'event_label'    => array(
						'label'    => __( 'Title', 'wp-analytify-pro' ),
						'th_class' => 'analytify_txt_left',
						'td_class' => '',
					),
					'video_action'   => array(
						'label'    => __( 'Action', 'wp-analytify-pro' ),
						'th_class' => 'analytify_txt_left',
						'td_class' => '',
					),
					'video_provider' => array(
						'label'    => __( 'Provider', 'wp-analytify-pro' ),
						'th_class' => 'analytify_txt_left',
						'td_class' => '',
					),
					'video_duration' => array(
						'label'    => __( 'Duration (s)', 'wp-analytify-pro' ),
						'th_class' => 'analytify_txt_center',
						'td_class' => 'analytify_txt_center',
					),
					'event_count'    => array(
						'label'    => __( 'Event Count', 'wp-analytify-pro' ),
						'th_class' => 'analytify_value_row',
						'td_class' => 'analytify_txt_center',
					),
				),
				'stats'      => $stats_video,
				'footer'     => apply_filters( 'analytify_video_footer', __( 'Video Tracking', 'wp-analytify-pro' ), array( $this->start_date, $this->end_date ) ),
				'pagination' => true,
			);
		}

		/**
		 * Endpoint for 'Custom Dimensions' (module).
		 *
		 * @return array<string, mixed>
		 */
		public function custom_dimensions() {

			$sections      = array();
			$success       = true;
			$error_message = false;

			if ( ! $this->wp_analytify || ! is_object( $this->wp_analytify ) || ! isset( $this->wp_analytify->settings ) ) {
				return array(
					'success'       => false,
					'error_message' => __( 'Analytics not available.', 'wp-analytify-pro' ),
					'sections'      => array(),
				);
			}

			$dimensions = $this->wp_analytify->settings->get_option( 'analytiy_custom_dimensions', 'wp-analytify-custom-dimensions' );

			$headers = array(
				'label' => array(
					'label'    => null,
					'th_class' => '',
					'td_class' => '',
				),
				'views' => array(
					'label'    => null,
					'th_class' => '',
					'td_class' => 'analytify_txt_center analytify_value_row',
				),
			);

			if ( ! $dimensions ) {
				$error_message = __( 'No dimension is set. Please set dimensions from the settings.', 'wp-analytify-pro' );
			} elseif ( 'ga4' === $this->ga_mode ) {

					$defined_dimensions = Analytify_Google_Dimensions::get_current_dimensions();

				foreach ( $dimensions as $key => $value ) {
					$type       = $value['type'];
					$label      = isset( $defined_dimensions[ $type ]['title'] ) ? $defined_dimensions[ $type ]['title'] : '';
					$identifier = isset( $defined_dimensions[ $type ]['value'] ) ? $defined_dimensions[ $type ]['value'] : '';
					$api_limit  = apply_filters( 'analytify_api_limit_custom_dimensions_' . $type . '_stats', 10, 'dashboard' );
					$raw_hint   = isset( $defined_dimensions[ $type ]['dashboard_hint'] ) ? $defined_dimensions[ $type ]['dashboard_hint'] : '';
					$hint_text  = apply_filters( 'analytify_dimension_dashboard_hint', $raw_hint, $type, 'dashboard' );
					$hint_html  = '';
					if ( is_string( $hint_text ) && '' !== trim( wp_strip_all_tags( $hint_text ) ) ) {
						$hint_plain = sanitize_text_field( wp_strip_all_tags( $hint_text ) );
						$hint_html  = ' <span class="analytify-dimension-hint analytify_tooltip" tabindex="0" role="button" aria-label="' . esc_attr( $hint_plain ) . '"><span class="dashicons dashicons-info" aria-hidden="true"></span><span class="analytify_tooltiptext">' . esc_html( $hint_plain ) . '</span></span>';
					}

					if ( ! $identifier ) {
						continue;
					}

					$dimension_stats = $this->wp_analytify->get_reports(
						'show-sessions-dimensions-stats-' . $type,
						array(
							'sessions',
						),
						$this->get_dates(),
						array(
							'customEvent:' . $identifier,
						),
						array(
							'order' => 'desc',
							'type'  => 'metric',
							'name'  => 'sessions',
						),
						array(
							'logic'   => 'AND',
							'filters' => array(
								array(
									'type'           => 'dimension',
									'name'           => 'customEvent:' . $identifier,
									'match_type'     => 4,
									'value'          => '(not set)',
									'not_expression' => true,
								),
							),
						),
						$api_limit
					);

					$sections[ $type ]['headers'] = $headers;
					$sections[ $type ]['title']   = esc_html( $label ) . $hint_html . ' <a href="#" class="analytify-export-data analytify_tooltip" data-stats-type="custom-dimension-' . $type . '"><span class="analytify_tooltiptext">' . esc_html__( 'Export Stats', 'wp-analytify-pro' ) . '</span></a><img src="' . admin_url( 'images/spinner.gif' ) . '" class="analytify-export-loader" style="display:none">';
					$sections[ $type ]['stats']   = array();

					$total = 0;

					if ( isset( $dimension_stats['rows'] ) && $dimension_stats['rows'] ) {
						foreach ( $dimension_stats['rows'] as $row ) {
							$label_value = $row[ 'customEvent:' . $identifier ];

							// Show "undefined" if label is empty.
							if ( empty( $label_value ) ) {
								$label_value = 'undefined';
							}

							$sections[ $type ]['stats'][] = array(
								'label' => apply_filters( 'analytify_custom_dimension_row_label', $label_value, $type, 'dashboard' ),
								'views' => $row['sessions'],
							);

							$total += $row['sessions'];
						}
					}

					$sections[ $type ]['title_stats'] = $total ? '<span class="analytify_medium_f">' . __( 'Total', 'wp-analytify-pro' ) . '</span> ' . $total : false;
				}
			}

			return array(
				'success'       => $success,
				'error_message' => $error_message,
				'sections'      => $sections,
			);
		}

		/**
		 * Strip tags and normalize text for JSON error payloads (avoids HTML/script in client output).
		 *
		 * @param mixed $text    Message from API or exception.
		 * @param int   $max_len Max character length.
		 * @return string
		 */
		private function sanitize_rest_api_message( $text, $max_len = 500 ) {
			if ( ! is_string( $text ) || '' === $text ) {
				return '';
			}
			$clean = sanitize_text_field( wp_strip_all_tags( $text ) );
			if ( strlen( $clean ) > $max_len ) {
				return substr( $clean, 0, $max_len ) . '…';
			}
			return $clean;
		}

		/**
		 * Detect GA4 Data API errors caused by custom event dimensions not registered on the property.
		 *
		 * @param mixed $ga_error The `error` entry from a GA report payload (string or array with message).
		 * @return bool
		 */
		private function enhanced_tel_is_unregistered_ga_dimension_error( $ga_error ) {
			$text = '';
			if ( is_string( $ga_error ) ) {
				$text = $ga_error;
			} elseif ( is_array( $ga_error ) && isset( $ga_error['message'] ) && is_string( $ga_error['message'] ) ) {
				$text = $ga_error['message'];
			}
			if ( '' === $text ) {
				return false;
			}
			$text = strtolower( str_replace( "\xc2\xa0", ' ', $text ) );
			if ( false !== strpos( $text, 'not a valid dimension' ) || false !== strpos( $text, 'not a valid metric' ) ) {
				return true;
			}
			if ( false !== strpos( $text, 'is not a valid dimension' ) || false !== strpos( $text, 'is not a valid metric' ) ) {
				return true;
			}
			if ( false !== strpos( $text, 'customevent:wpa_' ) ) {
				return true;
			}
			return false;
		}

		/**
		 * Build GA4 Data API `runReport` JSON body — mirrors core `get_reports()` in analytify-general.php.
		 *
		 * @param array<string, mixed> $date_range Start/end keys.
		 * @param array<int, string>   $metrics    Metric API names.
		 * @param array<int, string>   $dimensions Dimension API names.
		 * @param array<string, mixed> $order_by   Metric or dimension order.
		 * @param array<string, mixed> $filters    logic + filters[].
		 * @param int                  $limit    Row limit (0 = none).
		 * @return array<string, mixed>
		 */
		private function enhanced_tel_build_ga4_request_body( $date_range, $metrics, $dimensions, $order_by, $filters, $limit ) {
			$request_body = array(
				'dateRanges'         => array(
					array(
						'startDate' => isset( $date_range['start'] ) ? $date_range['start'] : 'today',
						'endDate'   => isset( $date_range['end'] ) ? $date_range['end'] : 'today',
					),
				),
				'metricAggregations' => array( 1 ),
			);

			if ( $metrics ) {
				$send_metrics = array();
				foreach ( $metrics as $value ) {
					$send_metrics[] = array( 'name' => $value );
				}
				$request_body['metrics'] = $send_metrics;
			}

			if ( $dimensions ) {
				$send_dimensions = array();
				foreach ( $dimensions as $value ) {
					$send_dimensions[] = array( 'name' => $value );
				}
				$request_body['dimensions'] = $send_dimensions;
			}

			if ( $order_by ) {
				$order_by_request = array();
				$is_desc          = ( empty( $order_by['order'] ) || 'desc' !== $order_by['order'] ) ? false : true;

				if ( 'metric' === $order_by['type'] ) {
					$order_by_request = array(
						'metric' => array(
							'metric_name' => isset( $order_by['name'] ) ? $order_by['name'] : '',
						),
						'desc'   => $is_desc,
					);
				} elseif ( 'dimension' === $order_by['type'] ) {
					$order_by_request = array(
						'dimension' => array(
							'dimension_name' => $order_by['name'],
						),
						'desc'      => $is_desc,
					);
				}

				$request_body['orderBys'] = array( $order_by_request );
			}

			if ( $filters ) {
				$dimension_filters = array();

				foreach ( $filters['filters'] as $filter_data ) {
					if ( 'dimension' === $filter_data['type'] ) {
						if ( isset( $filter_data['not_expression'] ) && $filter_data['not_expression'] ) {
							$dimension_filters[] = array(
								'not_expression' => array(
									'filter' => array(
										'field_name'    => $filter_data['name'],
										'string_filter' => array(
											'match_type' => $filter_data['match_type'],
											'value'      => $filter_data['value'],
											'case_sensitive' => true,
										),
									),
								),
							);
						} else {
							$dimension_filters[] = array(
								'filter' => array(
									'field_name'    => $filter_data['name'],
									'string_filter' => array(
										'match_type'     => $filter_data['match_type'],
										'value'          => $filter_data['value'],
										'case_sensitive' => true,
									),
								),
							);
						}
					}
				}

				if ( $dimension_filters ) {
					$group_type = ( isset( $filters['logic'] ) && 'OR' === $filters['logic'] ) ? 'or_group' : 'and_group';

					$request_body['dimensionFilter'] = array(
						$group_type => array(
							'expressions' => $dimension_filters,
						),
					);
				}
			}

			if ( 0 < $limit ) {
				$request_body['limit'] = $limit;
			}

			return $request_body;
		}

		/**
		 * GA4 report for Enhanced Tel only: same return shape as core `get_reports()`, with API errors in `error`.
		 *
		 * Mirrors cache key, advanced-keys bypass, and `analytify_format_ga_reports()` from core.
		 *
		 * @param string                $name        Transient segment (same as core `$name`).
		 * @param array<int, string>    $metrics     Metric names.
		 * @param array<string, string> $date_range Date range.
		 * @param array<int, string>    $dimensions  Dimensions.
		 * @param array<string, mixed>  $order_by    Order by config.
		 * @param array<string, mixed>  $filters     Filters.
		 * @param int                   $limit       Limit.
		 * @throws Exception When `wp_remote_post` returns WP_Error; caught and returned as `error` payload.
		 * @return array<string, mixed> headers, rows, error, aggregations.
		 */
		private function enhanced_tel_ga4_get_reports( $name, $metrics, $date_range, $dimensions, $order_by, $filters, $limit ) {
			if ( ! $this->wp_analytify || ! is_object( $this->wp_analytify ) || ! method_exists( $this->wp_analytify, 'analytify_format_ga_reports' ) ) {
				return method_exists( $this->wp_analytify, 'get_reports' )
					? $this->wp_analytify->get_reports( $name, $metrics, $date_range, $dimensions, $order_by, $filters, $limit )
					: array();
			}

			$property_id = class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_reporting_property' )
				? WPANALYTIFY_Utils::get_reporting_property()
				: '';

			if ( ! is_string( $property_id ) || '' === trim( $property_id ) ) {
				return array(
					'headers'      => array(),
					'rows'         => array(),
					'error'        => array(
						'status'  => 'configuration',
						'message' => __( 'No Google Analytics property is selected.', 'wp-analytify-pro' ),
						'code'    => 'missing_property',
					),
					'aggregations' => array(),
				);
			}

			$cached = true;
			if ( isset( $this->wp_analytify->settings ) && method_exists( $this->wp_analytify->settings, 'get_option' )
				&& 'on' === $this->wp_analytify->settings->get_option( 'user_advanced_keys', 'wp-analytify-advanced' ) ) {
				$cached = false;
			}
			$cached = apply_filters( 'analytify_set_caching_to', $cached );

			$cache_key = 'analytify_transient_' . md5( $name . $property_id . $date_range['start'] . $date_range['end'] );

			if ( $cached ) {
				$report_cache = get_transient( $cache_key );
				if ( $report_cache ) {
					return $report_cache;
				}
			}

			$default_response = array(
				'headers'      => array(),
				'rows'         => array(),
				'error'        => array(),
				'aggregations' => array(),
			);

			try {
				$request_body = $this->enhanced_tel_build_ga4_request_body( $date_range, $metrics, $dimensions, $order_by, $filters, $limit );

				$token = $this->wp_analytify->analytify_get_google_token();

				if ( ! is_array( $token ) || ! isset( $token['access_token'] ) ) {
					return array();
				}

				$access_token = $token['access_token'];
				$url          = 'https://analyticsdata.googleapis.com/v1beta/properties/' . $property_id . ':runReport';

				$response = wp_remote_post(
					$url,
					array(
						'headers' => array(
							'Authorization' => 'Bearer ' . $access_token,
							'Content-Type'  => 'application/json',
						),
						'body'    => wp_json_encode( $request_body ),
					)
				);

				if ( is_wp_error( $response ) ) {
					throw new Exception( $response->get_error_message() );
				}

				$body          = wp_remote_retrieve_body( $response );
				$response_code = wp_remote_retrieve_response_code( $response );
				$reports       = json_decode( $body, true );

				if ( ! is_array( $reports ) ) {
					$default_response['error'] = array(
						'status'  => $response_code,
						'message' => __( 'Invalid or empty response from Google Analytics.', 'wp-analytify-pro' ),
					);
					return $default_response;
				}

				if ( $response_code < 200 || $response_code >= 300 || isset( $reports['error'] ) ) {
					$message = '';
					if ( isset( $reports['error']['message'] ) && is_string( $reports['error']['message'] ) ) {
						$message = $this->sanitize_rest_api_message( $reports['error']['message'], 1000 );
					} elseif ( is_string( $body ) && '' !== $body ) {
						$message = $this->sanitize_rest_api_message( $body, 1000 );
					} else {
						$message = __( 'Google Analytics Data API request failed.', 'wp-analytify-pro' );
					}
					if ( '' === $message ) {
						$message = __( 'Google Analytics Data API request failed.', 'wp-analytify-pro' );
					}
					$default_response['error'] = array(
						'status'  => isset( $reports['error']['status'] ) ? $reports['error']['status'] : $response_code,
						'message' => $message,
						'code'    => isset( $reports['error']['code'] ) ? $reports['error']['code'] : $response_code,
					);
					return $default_response;
				}

				if ( ! isset( $reports['rows'] ) ) {
					$reports['rows'] = array();
				}

				$formatted_reports = $this->wp_analytify->analytify_format_ga_reports( $reports );

				if ( empty( $formatted_reports ) ) {
					return $default_response;
				}

				if ( $cached && method_exists( $this->wp_analytify, 'get_cache_time' ) ) {
					set_transient( $cache_key, $formatted_reports, $this->wp_analytify->get_cache_time() );
				}

				return $formatted_reports;
			} catch ( \Throwable $th ) {
				if ( method_exists( $th, 'getStatus' ) && method_exists( $th, 'getBasicMessage' ) ) {
					$default_response['error'] = array(
						'status'  => $th->getStatus(),
						'message' => $this->sanitize_rest_api_message( $th->getBasicMessage(), 1000 ),
					);
				} elseif ( method_exists( $th, 'getMessage' ) ) {
					$sanitized                 = $this->sanitize_rest_api_message( $th->getMessage(), 1000 );
					$default_response['error'] = array(
						'status'  => 'error',
						'message' => '' !== $sanitized
							? $sanitized
							: __( 'An error occurred while loading analytics data.', 'wp-analytify-pro' ),
					);
				}

				return $default_response;
			}
		}

		/**
		 * Normalize dial code for display (e.g. "92" -> "+92"). Matches core `get_reports` output as-is.
		 *
		 * @since 9.0.0
		 * @param string $raw Value from `customEvent:wpa_country_code`.
		 * @return string
		 */
		private function format_enhanced_tel_country_code( $raw ) {
			$code = is_string( $raw ) ? trim( $raw ) : '';
			if ( '' === $code ) {
				return '';
			}
			if ( preg_match( '/^\+/', $code ) ) {
				return $code;
			}
			if ( preg_match( '/^\d+$/', $code ) ) {
				return '+' . $code;
			}
			return $code;
		}

		/**
		 * Get dates for comparison.
		 *
		 * @return array<string, string>
		 */
		private function get_dates() {
			return array(
				'start' => $this->start_date,
				'end'   => $this->end_date,
			);
		}
	}
}
