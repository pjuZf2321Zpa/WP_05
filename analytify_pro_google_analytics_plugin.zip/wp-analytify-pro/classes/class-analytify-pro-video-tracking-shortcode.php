<?php
/**
 * Video Tracking Shortcode handler.
 *
 * Optimized for performance: runs only on front-end when shortcode is used,
 * supports cached per-post stats, and uses a template part for rendering.
 *
 * @package WP_Analytify_Pro
 * @since   9.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Analytify_Pro_Video_Tracking_Shortcode' ) ) {

	/**
	 * Handles [analytify-video-tracking] shortcode.
	 *
	 * - Runs heavy work only on front-end when is_singular() or post_id provided, and shortcode is present.
	 * - Uses post meta cache when available to avoid API calls on every page load.
	 * - Renders via template part to keep logic and markup separate.
	 *
	 * @since 9.0.0
	 */
	class Analytify_Pro_Video_Tracking_Shortcode {

		/**
		 * Parent plugin instance.
		 *
		 * @var WP_Analytify_Pro
		 */
		private $parent;

		/**
		 * Constructor.
		 *
		 * @since 9.0.0
		 * @param WP_Analytify_Pro $parent Parent plugin instance.
		 */
		public function __construct( $parent ) { // phpcs:ignore Universal.NamingConventions.NoReservedKeywordParameterNames.parentFound
			$this->parent = $parent;
		}

		/**
		 * Render the video tracking shortcode.
		 *
		 * Shortcode attributes control metrics and date range to avoid computing unnecessary values:
		 * - start_date, end_date: date range (defaults: post publish date to today).
		 * - date_type: 'custom'|'today'|'year-to-date'|'- 7 days'|'- 30 days'|etc.
		 * - max_results: limit rows (default 50).
		 * - post_id: specific post when analytics_for='page_id'.
		 * - analytics_for: 'all'|'current'|'page_id'.
		 *
		 * @since 9.0.0
		 * @param array<string, mixed> $atts Shortcode attributes.
		 * @return string HTML output or empty string when not applicable.
		 */
		public function render( $atts ) {
			// Only run on front-end; skip admin and non-singular unless post_id is explicitly set.
			if ( is_admin() ) {
				return '';
			}

			global $post;

			$atts          = is_array( $atts ) ? $atts : array();
			$post_id_attr  = isset( $atts['post_id'] ) ? (int) $atts['post_id'] : 0;
			$analytics_for = isset( $atts['analytics_for'] ) ? $atts['analytics_for'] : 'all';

			// When on a singular request, avoid heavy work if this post doesn't use the shortcode.
			if ( is_singular() && isset( $post ) && is_object( $post ) && ! empty( $post->post_content ) ) {
				if ( ! has_shortcode( $post->post_content, 'analytify-video-tracking' ) ) {
					return '';
				}
			} elseif ( ! is_singular() && 0 === $post_id_attr && 'page_id' !== $analytics_for ) {
				// Not a single post and no specific post requested: no context for "current" post.
				return '';
			}

			$result = $this->build_output( $atts );
			return is_string( $result ) ? $result : '';
		}

		/**
		 * Build shortcode output (validation, report fetch, template).
		 *
		 * @since 9.0.0
		 * @version 9.0.0
		 * @param array<string, mixed> $atts Shortcode attributes.
		 * @return string
		 */
		private function build_output( $atts ) {
			if ( ! class_exists( 'WPANALYTIFY_Utils' ) || ! method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) ) {
				if ( current_user_can( 'manage_options' ) ) {
					return '<p class="analytify-error">' . esc_html__( 'WPANALYTIFY_Utils class not found. Please ensure Analytify is installed and activated.', 'wp-analytify-pro' ) . '</p>';
				}
				return $this->public_unavailable_message();
			}

			$ga_mode = WPANALYTIFY_Utils::get_ga_mode();
			if ( 'ga4' !== $ga_mode ) {
				if ( current_user_can( 'manage_options' ) ) {
					return '<p class="analytify-error">' . esc_html__( 'Video tracking shortcode is only available for GA4. Current mode: ', 'wp-analytify-pro' ) . esc_html( $ga_mode ) . '</p>';
				}
				return $this->public_unavailable_message();
			}

			$wp_analytify = isset( $GLOBALS['WP_ANALYTIFY'] ) ? $GLOBALS['WP_ANALYTIFY'] : null;
			if ( ! is_object( $wp_analytify ) || ! isset( $wp_analytify->settings ) || ! method_exists( $wp_analytify->settings, 'get_option' ) ) {
				if ( $this->parent && is_object( $this->parent ) && isset( $this->parent->settings ) && method_exists( $this->parent->settings, 'get_option' ) ) {
					$wp_analytify = $this->parent;
				} else {
					if ( current_user_can( 'manage_options' ) ) {
						return '<p class="analytify-error">' . esc_html__( 'Analytify settings not available. Please ensure Analytify is properly installed and activated.', 'wp-analytify-pro' ) . '</p>';
					}
					return $this->public_unavailable_message();
				}
			}

			$advanced       = get_option( 'wp-analytify-advanced', array() );
			$video_tracking = isset( $advanced['video_tracking'] ) ? $advanced['video_tracking'] : 'off';
			if ( 'on' !== $video_tracking ) {
				if ( current_user_can( 'manage_options' ) ) {
					return '<p class="analytify-error">' . esc_html__( 'Video tracking is not enabled. Please enable it in Analytify settings (Advanced tab).', 'wp-analytify-pro' ) . '</p>';
				}
				return $this->public_unavailable_message();
			}

			global $post;
			$default_start = '2005-01-01';
			if ( isset( $post ) && is_object( $post ) && isset( $post->ID ) ) {
				$default_start = get_the_time( 'Y-m-d', $post->ID );
			}

			$shortcode_defaults = shortcode_atts(
				array(
					'start_date'      => $default_start,
					'end_date'        => gmdate( 'Y-m-d' ),
					'post_id'         => 0,
					'analytics_for'   => 'all',
					'date_type'       => 'custom',
					'max_results'     => 50,
					'permission_view' => '',
					'title'           => esc_html__( 'Video Tracking', 'wp-analytify-pro' ),
					'show_footer'     => 'yes',
				),
				$atts
			);

			$start_date      = $shortcode_defaults['start_date'];
			$end_date        = $shortcode_defaults['end_date'];
			$post_id         = (int) $shortcode_defaults['post_id'];
			$analytics_for   = $shortcode_defaults['analytics_for'];
			$date_type       = $shortcode_defaults['date_type'];
			$max_results     = (int) $shortcode_defaults['max_results'];
			$permission_view = $shortcode_defaults['permission_view'];
			$title           = $shortcode_defaults['title'];
			$show_footer     = $shortcode_defaults['show_footer'];

			$this->apply_date_type( $date_type, $start_date, $end_date );

			$start_timestamp = strtotime( (string) $start_date );
			if ( $start_timestamp && (int) gmdate( 'Y', $start_timestamp ) < 2005 ) {
				$start_date = '2005-01-01';
			}

			$filter_post_id = 0;
			if ( 'current' === $analytics_for && isset( $post ) && is_object( $post ) && isset( $post->ID ) ) {
				$filter_post_id = $post->ID;
			} elseif ( 'page_id' === $analytics_for && $post_id > 0 ) {
				$filter_post_id = $post_id;
			}

			$current_user = wp_get_current_user();
			$roles        = $current_user->roles;
			$role_to_show = ! empty( $permission_view ) ? array_map( 'trim', explode( ',', $permission_view ) ) : array();
			$current_role = ( 0 === $current_user->ID || empty( $roles ) ) ? 'everyone' : $roles[0];
			if ( ! empty( $role_to_show ) && 'everyone' !== $current_role && ! in_array( $current_role, $role_to_show, true ) ) {
				return '';
			}

			try {
				$report      = new Analytify_Report_Pro(
					array(
						'dashboard_type' => $filter_post_id > 0 ? 'single_post' : 'dashboard',
						'start_date'     => $start_date,
						'end_date'       => $end_date,
						'post_id'        => $filter_post_id > 0 ? $filter_post_id : null,
					)
				);
				$video_stats = $report->get_video_tracking_stats();
			} catch ( Exception $e ) {
				if ( current_user_can( 'manage_options' ) ) {
					return '<p class="analytify-error">' . esc_html__( 'Error loading video tracking data: ', 'wp-analytify-pro' ) . esc_html( $e->getMessage() ) . '</p>';
				}
				return $this->public_unavailable_message();
			}

			return $this->render_template(
				$video_stats,
				array(
					'title'          => $title,
					'show_footer'    => $show_footer,
					'start_date'     => $start_date,
					'end_date'       => $end_date,
					'filter_post_id' => $filter_post_id,
				)
			);
		}

		/**
		 * Apply date_type to start_date and end_date (by reference).
		 *
		 * @since 9.0.0
		 * @param string $date_type   Date type key.
		 * @param string $start_date  Start date (modified).
		 * @param string $end_date    End date (modified).
		 */
		private function apply_date_type( $date_type, &$start_date, &$end_date ) {
			if ( 'custom' === $date_type ) {
				return;
			}
			$today = wp_date( 'Y-m-d' );
			switch ( $date_type ) {
				case 'today':
					$start_date = $today;
					$end_date   = $today;
					break;
				case 'year-to-date':
					$start_date = wp_date( 'Y-m-d', (int) strtotime( gmdate( 'Y' ) . '-01-01' ) );
					$end_date   = $today;
					break;
				case '- 7 days':
				case '- 15 days':
				case '- 30 days':
				case '- 365 days':
					$start_date = wp_date( 'Y-m-d', (int) strtotime( $date_type ) );
					$end_date   = $today;
					break;
				case '- 1 days':
					$start_date = wp_date( 'Y-m-d', (int) strtotime( $date_type ) );
					$end_date   = wp_date( 'Y-m-d', (int) strtotime( $date_type ) );
					break;
			}
		}

		/**
		 * Render output using template part (logic and markup separate).
		 *
		 * @since 9.0.0
		 * @param array<string, mixed> $video_stats Result from get_video_tracking_stats().
		 * @param array<string, mixed> $args        Title, show_footer, start_date, end_date, filter_post_id.
		 * @return string
		 */
		private function render_template( $video_stats, $args ) {
			$template = $this->get_template_path();
			if ( ! $template || ! is_readable( $template ) ) {
				return $this->render_fallback( $video_stats, $args );
			}
			ob_start();
			include $template;
			return ob_get_clean();
		}

		/**
		 * Get path to shortcode template file.
		 *
		 * @since 9.0.0
		 * @return string
		 */
		private function get_template_path() {
			$base = defined( 'ANALYTIFY_PRO_PATH' ) ? ANALYTIFY_PRO_PATH : dirname( __DIR__ );
			return $base . '/views/video-tracking-shortcode.php';
		}

		/**
		 * Fallback inline output if template file is missing.
		 *
		 * @since 9.0.0
		 * @param array<string, mixed> $video_stats Stats array with 'stats' key.
		 * @param array<string, mixed> $args        title, show_footer, start_date, end_date, filter_post_id.
		 * @return string
		 */
		private function render_fallback( $video_stats, $args ) {
			$title          = isset( $args['title'] ) ? $args['title'] : '';
			$show_footer    = isset( $args['show_footer'] ) ? $args['show_footer'] : 'yes';
			$start_date     = isset( $args['start_date'] ) ? $args['start_date'] : '';
			$end_date       = isset( $args['end_date'] ) ? $args['end_date'] : '';
			$filter_post_id = isset( $args['filter_post_id'] ) ? (int) $args['filter_post_id'] : 0;

			$output = '<div class="analytify-video-tracking-shortcode">';
			if ( ! empty( $title ) ) {
				$output .= '<h3 class="analytify-video-tracking-title">' . esc_html( $title ) . '</h3>';
			}
			$stats = isset( $video_stats['stats'] ) && is_array( $video_stats['stats'] ) ? $video_stats['stats'] : array();
			if ( ! empty( $stats ) ) {
				$output .= '<div class="analytify-video-tracking-table"><table class="analytify_data_tables">';
				$output .= '<thead><tr><th class="analytify_txt_left">' . esc_html__( 'Title', 'wp-analytify-pro' ) . '</th><th class="analytify_txt_left">' . esc_html__( 'Action', 'wp-analytify-pro' ) . '</th><th class="analytify_txt_left">' . esc_html__( 'Provider', 'wp-analytify-pro' ) . '</th><th class="analytify_txt_center">' . esc_html__( 'Duration (s)', 'wp-analytify-pro' ) . '</th><th class="analytify_value_row analytify_txt_center">' . esc_html__( 'Event Count', 'wp-analytify-pro' ) . '</th></tr></thead><tbody>';
				foreach ( $stats as $stat ) {
					$output .= '<tr><td>' . esc_html( $stat['event_label'] ?? '' ) . '</td><td>' . esc_html( $stat['video_action'] ?? '' ) . '</td><td>' . esc_html( $stat['video_provider'] ?? '' ) . '</td><td class="analytify_txt_center">' . esc_html( $stat['video_duration'] ?? 0 ) . '</td><td class="analytify_txt_center analytify_value_row">' . esc_html( $stat['event_count'] ?? 0 ) . '</td></tr>';
				}
				$output .= '</tbody></table></div>';
			} else {
				$output .= '<div class="analytify-video-tracking-no-data"><p class="analytify-no-stats">' . esc_html__( 'No video tracking data available for the selected period.', 'wp-analytify-pro' ) . '</p>';
				if ( current_user_can( 'manage_options' ) ) {
					$output .= '<p class="analytify-debug-info" style="font-size: 12px; color: #666; margin-top: 10px;">' . esc_html__( 'Debug Info: ', 'wp-analytify-pro' ) . esc_html__( 'Date Range: ', 'wp-analytify-pro' ) . esc_html( $start_date ) . ' - ' . esc_html( $end_date );
					if ( $filter_post_id > 0 ) {
						$output .= ' | ' . esc_html__( 'Post ID: ', 'wp-analytify-pro' ) . (int) $filter_post_id;
					}
					$output .= '</p>';
				}
				$output .= '</div>';
			}
			if ( 'yes' === $show_footer ) {
				$output .= '<div class="analytify-video-tracking-footer"><span class="analytify_info_stats">' . esc_html__( 'Video tracking statistics', 'wp-analytify-pro' ) . ' (' . esc_html( wp_date( 'jS F, Y', strtotime( $start_date ) ) ) . ' - ' . esc_html( wp_date( 'jS F, Y', strtotime( $end_date ) ) ) . ')</span></div>';
			}
			$output .= '</div>';
			return $output;
		}

		/**
		 * Generic fallback for non-admin users when shortcode cannot be rendered.
		 *
		 * @since 9.0.0
		 * @version 9.0.0
		 * @return string
		 */
		private function public_unavailable_message() {
			return '<p class="analytify-info">' . esc_html__( 'Video tracking statistics are currently unavailable.', 'wp-analytify-pro' ) . '</p>';
		}
	}
}
