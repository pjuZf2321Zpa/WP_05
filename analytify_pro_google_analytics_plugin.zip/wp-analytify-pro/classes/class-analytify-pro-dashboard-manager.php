<?php // phpcs:ignore WordPress.Files.FileName.InvalidClassFileName
/**
 * WP Analytify Pro Dashboard Manager Class
 *
 * This class handles dashboard and analytics display functionality including:
 * - Real-time statistics
 * - Comparison statistics
 * - Dashboard content generation
 * - Error tracking templates
 * - Dashboard dropdown functionality
 *
 * @package WP_Analytify_Pro
 * @since 8.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_Analytify_Pro_Dashboard_Manager' ) ) {

	/**
	 * WP Analytify Pro Dashboard Manager Class
	 *
	 * @since 1.0.0
	 */
	class WP_Analytify_Pro_Dashboard_Manager {

		/**
		 * Reference to the main WP_Analytify_Pro class
		 *
		 * @var WP_Analytify_Pro
		 */
		private $parent;

		/**
		 * Constructor
		 *
		 * @version 7.0.5
		 * @param WP_Analytify_Pro $parent Reference to the main class.
		 */
		public function __construct( $parent ) { // phpcs:ignore Universal.NamingConventions.NoReservedKeywordParameterNames.parentFound
			$this->parent = $parent;
		}

		/**
		 * Include real-time statistics
		 *
		 * @version 7.0.5
		 * @since 1.0.0
		 * @return void
		 */
		public function include_realtime_stats() {
			$wp_analytify = $GLOBALS['WP_ANALYTIFY'];

			if ( defined( 'ANALYTIFY_PRO_ROOT_PATH' ) ) {
				include ANALYTIFY_PRO_ROOT_PATH . '/views/default/admin/realtime-stats.php';
			}
			if ( function_exists( 'fetch_realtime_stats' ) ) {
				fetch_realtime_stats( $wp_analytify );
			}
		}

		/**
		 * Include comparison statistics
		 *
		 * @param string $start_date Start date.
		 * @param string $end_date End date.
		 * @param string $compare_start_date Compare start date.
		 * @param string $compare_end_date Compare end date.
		 * @since 1.0.0
		 * @return void
		 */
		public function include_compare_stats( $start_date, $end_date, $compare_start_date, $compare_end_date ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed
			?>

			<div class="analytify_status_body">
				<div class="compare-stats-report">
					<div class="analytify_stats_loading" style="background: white; margin: 1rem 0;">
						<div class="analytify_clearfix">
						<table class="analytify_data_tables analytify_comp_half analytify_pull_left">
							<thead>
								<tr>
									<th class="analytify_comp_row"><p class="skt-loading light-gray"></p></th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td style="border: none; padding: 20px;"><p class="skt-loading"></p></td>
								</tr>
								<tr>
									<td style="border: none; padding: 20px;"><p class="skt-loading"></p></td>
								</tr>
								<tr>
									<td style="border: none; padding: 20px;"><p class="skt-loading"></p></td>
								</tr>
								<tr>
									<td style="border: none; padding: 20px;"><p class="skt-loading"></p></td>
								</tr>
								<tr>
									<td style="border: none; padding: 20px;"><p class="skt-loading"></p></td>
								</tr>
							</tbody>
						</table>
						<table class="analytify_data_tables analytify_comp_half analytify_pull_left">
							<thead>
								<tr>
									<!-- <th class="analytify_comp_row"><p class="skt-loading light-gray"></p></th> -->
									<th class="analytify_comp_row"><p class="skt-loading light-gray"></p></th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td style="border: none; padding: 20px;"><p class="skt-loading"></p></td>
								</tr>
								<tr>
									<td style="border: none; padding: 20px;"><p class="skt-loading"></p></td>
								</tr>
								<tr>
									<td style="border: none; padding: 20px;"><p class="skt-loading"></p></td>
								</tr>
								<tr>
									<td style="border: none; padding:20px;"><p class="skt-loading"></p></td>
								</tr>
								<tr>
									<td style="border: none; padding: 20px;"><p class="skt-loading"></p></td>
								</tr>
							</tbody>
						</table>
					</div>
					</div>
				</div>
			</div>

			

			<?php
		}

		/**
		 * Get detail dashboard content
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function get_detail_dashboard_content() {

			$wp_analytify = $GLOBALS['WP_ANALYTIFY'] ?? null;
			$version      = defined( 'ANALYTIFY_PRO_VERSION' ) ? ANALYTIFY_PRO_VERSION : ANALYTIFY_VERSION;
			$access_token = get_option( 'post_analytics_token' );

			$start_date = wp_date( 'Y-m-d', strtotime( '-1 month' ) );
			$end_date   = wp_date( 'Y-m-d', strtotime( 'now' ) );
			if ( function_exists( 'analytify_datepicker_dates' ) ) {
				$dates = analytify_datepicker_dates();
				if ( isset( $dates['start_date'] ) ) {
					$start_date = $dates['start_date'];
				}
				if ( isset( $dates['end_date'] ) ) {
					$end_date = $dates['end_date'];
				}
			}

			$dashboard_profile_id = '';
			if ( $wp_analytify && is_object( $wp_analytify ) && isset( $wp_analytify->settings ) && method_exists( $wp_analytify->settings, 'get_option' ) ) {
				$dashboard_profile_id = $wp_analytify->settings->get_option( 'profile_for_dashboard', 'wp-analytify-profile' );
			}
			$dashboard_profile_id = ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_reporting_property' ) ) ? WPANALYTIFY_Utils::get_reporting_property() : $dashboard_profile_id;

			$dashboard = isset( $_GET['show'] ) ? sanitize_text_field( wp_unslash( $_GET['show'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

			switch ( $dashboard ) {
				case 'detail-realtime':
					$heading = 'Real-Time Traffic Dashboard';
					break;
				case 'page-speed':
					$heading = 'PageSpeed Insights';
					break;
				case 'detail-demographic':
					$heading = 'Demographics Dashboard';
					break;
				case 'search-terms':
					$heading = 'Search Terms Dashboard';
					break;
				case 'search-console-report':
					$heading = 'Search Console Dashboard';
					break;
				case 'video-tracking':
					$heading = 'Video Tracking Dashboard';
					break;
				default:
					$heading = '';
					break;
			}
			?>

			<div class="wpanalytify analytify-dashboard-nav">
				<div class="wpb_plugin_wraper">
					<div class="wpb_plugin_header_wraper">
						<div class="graph"></div>
						<div class="wpb_plugin_header">
							<div class="wpb_plugin_header_title"></div>
							<div class="wpb_plugin_header_info">
								<a href="https://analytify.io/changelog/" target="_blank" class="btn"><?php echo esc_html__( 'View Changelog', 'wp-analytify-pro' ); ?></a>
							</div>
							<div class="wpb_plugin_header_logo">
								<img src="<?php echo esc_url( ( defined( 'ANALYTIFY_PLUGIN_URL' ) ? ANALYTIFY_PLUGIN_URL : '' ) . 'assets/img/logo.svg' ); ?>" alt="Analytify">
							</div>
						</div>
					</div>
					<div class="analytify-dashboard-body-container">
						<div class="wpb_plugin_body_wraper">
						<div class="wpb_plugin_body">
							<div class="wpa-tab-wrapper">
							<?php
							if ( is_object( $wp_analytify ) && method_exists( $wp_analytify, 'dashboard_navigation' ) ) {
								$wp_analytify->dashboard_navigation();
							}
							?>
							</div>
							<div class="wpb_plugin_tabs_content analytify-dashboard-content">
								<div class="analytify_wraper">
									<div class="analytify_main_title_section">
										<div class="analytify_dashboard_title">
											<h1 class="analytify_pull_left analytify_main_title"><?php echo esc_html( $heading ); ?> </h1>
											<?php
											if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'dashboard_subtitle_section' ) ) {
												WPANALYTIFY_Utils::dashboard_subtitle_section();
											}
											?>
										</div>
											<?php if ( 'page-speed' === $dashboard ) { ?>
											<div class="header-<?php echo esc_attr( $dashboard ); ?>">
													<div class="view-toggle">
														<button aria-label="mobile view" id="mobileView" onclick="switchView('mobile', event)">
	<svg width="17" height="27" viewBox="0 0 17 27" fill="none" xmlns="http://www.w3.org/2000/svg">
	<g opacity="0.5">
	<path d="M10.9635 2.19449H8.33021C7.96638 2.19449 7.67188 2.48899 7.67188 2.85282C7.67188 3.21665 7.96638 3.51116 8.33021 3.51116H10.9635C11.3274 3.51116 11.6219 3.21665 11.6219 2.85282C11.6219 2.48899 11.3274 2.19449 10.9635 2.19449Z" fill="black"/>
	<path d="M13.8112 0H3.27786C1.82603 0 0.644531 1.1815 0.644531 2.63333V23.7C0.644531 25.1518 1.82603 26.3333 3.27786 26.3333H13.8112C15.263 26.3333 16.4445 25.1518 16.4445 23.7V2.63333C16.4445 1.1815 15.263 0 13.8112 0ZM15.1279 23.7C15.1279 24.4272 14.5385 25.0167 13.8112 25.0167H3.27786C2.55061 25.0167 1.9612 24.4272 1.9612 23.7V2.63333C1.9612 1.90608 2.55061 1.31667 3.27786 1.31667H13.8112C14.5385 1.31667 15.1279 1.90608 15.1279 2.63333V23.7Z" fill="black"/>
	<path d="M8.54714 24.1389C9.27431 24.1389 9.8638 23.5494 9.8638 22.8222C9.8638 22.095 9.27431 21.5056 8.54714 21.5056C7.81996 21.5056 7.23047 22.095 7.23047 22.8222C7.23047 23.5494 7.81996 24.1389 8.54714 24.1389Z" fill="black"/>
	<path d="M6.13099 3.51112C6.49458 3.51112 6.78932 3.21638 6.78932 2.85279C6.78932 2.4892 6.49458 2.19446 6.13099 2.19446C5.7674 2.19446 5.47266 2.4892 5.47266 2.85279C5.47266 3.21638 5.7674 3.51112 6.13099 3.51112Z" fill="black"/>
	</g>
	</svg>
	</button>
														<button class="active" aria-label="desktop view" id="desktopView" onclick="switchView('desktop', event)">

														<svg width="25" height="20" viewBox="0 0 25 20" fill="none" xmlns="http://www.w3.org/2000/svg">
	<path fill-rule="evenodd" clip-rule="evenodd" d="M22.7807 0.427673H1.313C0.616629 0.427673 0.046875 0.997483 0.046875 1.69386V14.3625C0.046875 15.0589 0.616629 15.6287 1.313 15.6287H22.7807C23.4772 15.6287 24.0469 15.0589 24.0469 14.3625V1.69386C24.0469 0.997483 23.4772 0.427673 22.7807 0.427673ZM22.4398 2.03484H1.65399V14.0215H22.4398V2.03484Z" fill="#F7FFFF"/>
	<path fill-rule="evenodd" clip-rule="evenodd" d="M14.4815 15.3608H9.61057C9.57275 16.8759 8.9669 18.7342 7.77734 19.5723H16.3147C15.1252 18.7342 14.5193 16.8759 14.4815 15.3608Z" fill="#F7FFFF"/>
	</svg>

	</button>
													</div>
													<div class="run-button">
														<button id="runButton" onclick="run()">Run Audit</button>
													</div>
												</div>
										<?php } ?>

												<?php if ( 'detail-realtime' !== $dashboard && 'page-speed' !== $dashboard ) { ?>

												<div class="analytify_main_setting_bar">
													<div class="analytify_pull_right analytify_setting">
														<div class="analytify_select_date">
															<?php
															if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'date_form' ) ) {
																WPANALYTIFY_Utils::date_form( $start_date, $end_date );
															}
															?>
														</div>
													</div>
												</div>

											<?php } ?>
											
										</div>

											<?php
											if ( class_exists( 'WP_ANALYTIFY_FUNCTIONS' ) && method_exists( 'WP_ANALYTIFY_FUNCTIONS', 'wpa_check_profile_selection' ) && ! WP_ANALYTIFY_FUNCTIONS::wpa_check_profile_selection( 'Analytify' ) ) {
												$is_access_level = array( 'Administrator' );
												if ( $wp_analytify && is_object( $wp_analytify ) && isset( $wp_analytify->settings ) && method_exists( $wp_analytify->settings, 'get_option' ) ) {
													$is_access_level = $wp_analytify->settings->get_option( 'show_analytics_roles_dashboard', 'wp-analytify-dashboard' );
												}

												// Show dashboard to admin incase of empty access roles.
												if ( empty( $is_access_level ) ) {
													$is_access_level = array( 'administrator' ); }

												if ( $wp_analytify->pa_check_roles( $is_access_level ) ) {
													if ( $access_token ) {
														switch ( $dashboard ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
															case 'detail-realtime':
																if ( defined( 'ANALYTIFY_PRO_ROOT_PATH' ) ) {
																	require_once ANALYTIFY_PRO_ROOT_PATH . '/views/default/admin/dashboard-realtime.php';
																}
																break;
															case 'page-speed':
																if ( defined( 'ANALYTIFY_PRO_ROOT_PATH' ) ) {
																	require_once ANALYTIFY_PRO_ROOT_PATH . '/views/default/admin/dashboard-pagespeed.php';
																}
																break;
															case 'detail-demographic':
																if ( defined( 'ANALYTIFY_PRO_ROOT_PATH' ) ) {
																	require_once ANALYTIFY_PRO_ROOT_PATH . '/views/default/admin/dashboard-demographic.php';
																}
																break;
															case 'search-terms':
																if ( defined( 'ANALYTIFY_PRO_ROOT_PATH' ) ) {
																	require_once ANALYTIFY_PRO_ROOT_PATH . '/views/default/admin/dashboard-search.php';
																}
																break;
															case 'search-console-report':
																if ( defined( 'ANALYTIFY_PRO_ROOT_PATH' ) ) {
																	require_once ANALYTIFY_PRO_ROOT_PATH . '/views/default/admin/dashboard-search-console.php';
																}
																break;
															case 'video-tracking':
																if ( defined( 'ANALYTIFY_PRO_ROOT_PATH' ) ) {
																	require_once ANALYTIFY_PRO_ROOT_PATH . '/views/default/admin/dashboard-video-tracking.php';
																}
																break;
															default:
																esc_html_e( 'This page does not exists.', 'wp-analytify-pro' );
																break;
														}
													} else {
														esc_html_e( 'You must be authenticated to see the Analytics Dashboard.', 'wp-analytify-pro' );
													}
												} else {
													esc_html_e( 'You don\'t have access to Analytify Dashboard.', 'wp-analytify-pro' );
												}
											}
											?>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php
		}

		/**
		 * Real-time detail view
		 *
		 * The following function is not been used.
		 *
		 * @param string $dashboard_profile_id Dashboard profile ID.
		 * @since 1.0.0
		 * @version 9.1.1
		 * @return void
		 */
		public function real_time_detail( $dashboard_profile_id ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found
			?>

			<div class="analytify_general_status analytify_status_box_wraper">
				<div class="analytify_status_body stats_loading">
					<div class="analytify_real_time_boxes_wraper">
					<div class="analytify_real_time_stats analytify_status_box_wraper">
						<div class="analytify_visitors_online analytify_real_time_stats_boxes">
							<div class="analytify_number" id="pa-online">0</div>
							<div class="analytify_label"><?php esc_html_e( 'Visitors online', 'wp-analytify-pro' ); ?></div>
						</div>
						<div class="analytify_referral analytify_real_time_stats_boxes">
							<div class="analytify_number" id="pa-referral">0</div>
							<div class="analytify_label"><?php esc_html_e( 'Referral', 'wp-analytify-pro' ); ?></div>
						</div>
						<div class="analytify_organic analytify_real_time_stats_boxes">
							<div class="analytify_number" id="pa-organic">0</div>
							<div class="analytify_label"><?php esc_html_e( 'ORGANIC', 'wp-analytify-pro' ); ?></div>
						</div>
						<div class="analytify_social analytify_real_time_stats_boxes">
							<div class="analytify_number" id="pa-social">0</div>
							<div class="analytify_label"><?php esc_html_e( 'social', 'wp-analytify-pro' ); ?></div>
						</div>
						<div class="analytify_direct analytify_real_time_stats_boxes">
							<div class="analytify_number" id="pa-direct">0</div>
							<div class="analytify_label"><?php esc_html_e( 'direct', 'wp-analytify-pro' ); ?></div>
						</div>
						<div class="analytify_new analytify_real_time_stats_boxes">
							<div class="analytify_number" id="pa-new">0</div>
							<div class="analytify_label"><?php esc_html_e( 'new', 'wp-analytify-pro' ); ?></div>
						</div>
						<div class="analytify_returning analytify_real_time_stats_boxes">
							<div class="analytify_number" id="pa-returning">0</div>
							<div class="analytify_label"><?php esc_html_e( 'Returning', 'wp-analytify-pro' ); ?></div>
						</div>
					</div>

					<div class="analytify_general_status analytify_status_box_wraper">
						<div class="analytify_status_header">
							<h3>
								<?php esc_html_e( 'RealTime Stats', 'wp-analytify-pro' ); ?>
								<span class="analytify_tp_btn analytify-realtime-refresh-btn">
									<a id="refresh-realtime-stats" class="analytify_tooltip" href="#">
										<span class="analytify_tooltiptext"><?php esc_html_e( 'Refresh Stats', 'wp-analytify-pro' ); ?></span>
									</a>
								</span>
							</h3>
						</div>
						<div class="analytify_status_body">
							<div id="analytify_real_time_visitors" style="height:400px"></div>
						</div>
					</div>

					<div class="analytify_general_status analytify_status_box_wraper">
						<div class="analytify_status_header">
							<h3><?php esc_html_e( 'Top Active posts and pages', 'wp-analytify-pro' ); ?></h3>
						</div>
						<div class="analytify_status_body">
							<div class="analytify_top_pages_boxes_wraper" id="pa-pages"></div>
						</div>
						<div class="analytify_status_footer">
							<span class="analytify_info_stats"><?php esc_html_e( 'Top active pages and posts users are currently at', 'wp-analytify-pro' ); ?>.</span>
						</div>
					</div>
					</div>

					<script>
					//<![CDATA[

					jQuery( function($) {
					var time_data = [];
					var analytics_data = [];

					for (var i = 600; i > -1; i = i - 30) {
						time_data.push(i + 's');
						analytics_data.push(0);
					}

					// configure for module loader
					require.config({
						paths: {
							echarts: 'js/'
						}
					});

					// use
					require(
						[
							'echarts',
							'echarts/chart/bar', // require the specific chart type
							'echarts/chart/line' // require the specific chart type
						],
						function(ec) {
							// Initialize after dom ready
							years_graph_by_visitors = ec.init(document.getElementById('analytify_real_time_visitors'));

							var years_graph_by_visitors_option = {
								tooltip: {

									show: true
								},
								color: [
									'#03a1f8'
								],
								toolbox: {
									show: false,
									color: ["#444444", "#444444", "#444444", "#444444"],
									feature: {
										magicType: {
											show: true,
											type: ['line', 'bar']
										},
										saveAsImage: {
											show: true
										}
									}
								},
								xAxis: [{
									type: 'category',
									boundaryGap: false,
									data: time_data
								}],
								yAxis: [{
									type: 'value'
								}],
								series: [{
										"name": "Real Time",
										"type": "line",
										smooth: true,
										itemStyle: {
											normal: {
												areaStyle: {
													type: 'default'
												}
											}
										},
										"data": analytics_data
									}
								]
							};

							// Load data into the ECharts instance
							years_graph_by_visitors.setOption(years_graph_by_visitors_option);
							
							<?php
							$property_url = ( class_exists( 'WP_ANALYTIFY_FUNCTIONS' ) && method_exists( 'WP_ANALYTIFY_FUNCTIONS', 'ga_reporting_property_info' ) ) ? WP_ANALYTIFY_FUNCTIONS::ga_reporting_property_info( 'url' ) : '';

							echo '
							function onlyUniqueValues(value, index, self) {
								return self.indexOf(value) === index;
							}

							function countvisits(data, searchvalue) {
								var count = 0;
								if(data["rows"]){
								for ( var i = 0; i < data["rows"].length; i = i + 1 ) {
									if (jQuery.inArray(searchvalue, data["rows"][ i ])>-1){
									count += parseInt(data["rows"][ i ][6]);
									}
								}
								}
								return count;
							}

							function pa_generatetooltip(data) {
								var count = 0;
								var table = "";
								for ( var i = 0; i < data.length; i = i + 1 ) {
								count += parseInt(data[ i ].count);
								table += "<td>"+data[i].value+"</td><td class=\'pa-pgdetailsr\'>"+data[ i ].count+"</td></tr>";
								};
								if (count){
								return("<table>"+table+"</table>");
								}else{
								return("");
								}
							}

							function pa_pagedetails(data, searchvalue) {

								var newdata = [];
								
								// Add data to graph
								if( data["rows"].length ) {
									analytics_data.shift();
									analytics_data.push( data["rows"][0]["activeUsers"] );
									years_graph_by_visitors.setOption({
										series: [{
											data: analytics_data
										}]
									});
								}

								var countrfr = 0;
								var countkwd = 0;
								var countdrt = 0;
								var countscl = 0;
								var tablerfr = "";
								var tablekwd = "";
								var tablescl = "";
								var tabledrt = "";

								for ( var i = 0; i < newdata.length; i = i + 1 ) {
									if (newdata[i]["unifiedScreenName"] == searchvalue){
										var pagetitle = newdata[i][5]
									};
								};
								return (pagetitle);
							}

							function online_refresh(){ 
								$.ajax({
									url: ' . wp_json_encode( esc_url_raw( rest_url( 'wp-analytify/v1/get_pro_report/real-time' ) ) ) . ',
										data: {},
										beforeSend: function (xhr) {
											xhr.setRequestHeader( "X-WP-Nonce", "' . esc_js( wp_create_nonce( 'wp_rest' ) ) . '" );
										},
									})
									.fail(function(res) {
										var _html = "<table class=\'analytify_data_tables analytify_no_header_table\'><tbody><tr><td class=\'analytify_td_error_msg\'><div class=\'analytify-stats-error-msg\'><div class=\'wpb-error-box\'><span class=\'blk\'><span class=\'line\'></span><span class=\'dot\'></span></span><span class=\'information-txt\'>Something Unexpected Occurred.</span></div></div></td></tr></tbody></table>"
	
										$(".analytify_real_time_boxes_wraper").html(_html).parent().removeClass("stats_loading");
									})
									.done(function(data) {
										data = data.body

										jQuery("#refresh-realtime-stats").prop("disabled", false);
										if (data == "") return;
	
										if ( data["rows"].length && data["rows"][0]["activeUsers"] !== document.getElementById( "pa-online" ).innerHTML ) {
											jQuery( "#pa-online" ).fadeOut( "slow" );
											jQuery( "#pa-online" ).fadeOut( 500 );
											jQuery( "#pa-online" ).fadeOut( "slow", function() {
											document.getElementById( "pa-online" ).innerHTML = data["rows"][0]["activeUsers"];
											} );
											jQuery( "#pa-online" ).fadeIn( "slow" );
											jQuery( "#pa-online" ).fadeIn( 500 );
											jQuery( "#pa-online" ).fadeIn( "slow", function() {
											});
										};
	
										var pagepath = [];
										for ( var i = 0; i < data["rows"].length; i = i + 1 ) {
											pagepath.push( data["rows"][i]["unifiedScreenName"] );
										}

										var upagepath = pagepath.filter(onlyUniqueValues);
										var upagepathstats = [];
										for ( var i = 0; i < upagepath.length; i = i + 1 ) {
										upagepathstats[i]={"pagepath":upagepath[i],"count":countvisits(data,upagepath[i])};
										}
										upagepathstats.sort( function(a,b){ return b.count - a.count } );

										var pgstatstable = "";
										for ( var i = 0; i < upagepathstats.length; i = i + 1 ) {
											if (i < 10 ){
												pgstatstable += "\
												<tr class=\"pa-pline\">\
													<td class=\"pa-pright\">"+(i+1)+"</td><td class=\"pa-pleft\">"+upagepathstats[i].pagepath+"</td>\
													<td class=\"pa-pright\">"+upagepathstats[i].count+"</td>\
												</tr>";
											}
										}
										document.getElementById("pa-pages").innerHTML="<table class=\"pa-pg analytify_data_tables\"><tr><th class=\"analytify_table_header_no_events analytify_txt_left\">#</th><th>' . esc_html__( 'Page Title', 'wp-analytify-pro' ) . '</th><th class=\"wd_2\">' . esc_html__( 'Visitors', 'wp-analytify-pro' ) . '</th></tr>"+pgstatstable+"</table>";
									});
								};
	
								online_refresh();
								setInterval(online_refresh, 30000);

								// Refresh Stats
								jQuery("#refresh-realtime-stats").on("click", function(e){
								e.preventDefault();
								analytics_data =  [];
							
								for (var i = 600 ; i > -1 ; i = i-30 ) {
									analytics_data.push(0);
								}
								years_graph_by_visitors.setOption({
									series: [{
										data: analytics_data
									}]
								});
								jQuery("#pa-pages").empty();
								jQuery("#pa-online, #pa-referral, #pa-organic, #pa-social, #pa-direct, #pa-new, #pa-returning").html(0);
								online_refresh();
								jQuery("#refresh-realtime-stats").prop("disabled", true);							
							});';
							?>
						});
						});							
					//]]>
					</script>
				</div>
			</div>
						<?php
		}

		/**
		 * Get real time data via AJAX
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function pa_realtime_data_get() {
			$wp_analytify = $GLOBALS['WP_ANALYTIFY'];

			if ( ! $wp_analytify || ! is_object( $wp_analytify ) || ! isset( $wp_analytify->settings ) || ! method_exists( $wp_analytify->settings, 'get_option' ) || ! method_exists( $wp_analytify, 'pa_check_roles' ) ) {
				wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'wp-analytify-pro' ) );
			}

			$access_roles = array( 'Administrator' );
			if ( $wp_analytify && is_object( $wp_analytify ) && isset( $wp_analytify->settings ) && method_exists( $wp_analytify->settings, 'get_option' ) ) {
				$access_roles = $wp_analytify->settings->get_option( 'show_analytics_roles_back_end', 'wp-analytify-admin', array( 'Administrator' ) );
			}
			if ( ! $wp_analytify->pa_check_roles( $access_roles ) ) {
				wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'wp-analytify-pro' ) );
			}

			$profile_id = '';
			if ( $wp_analytify && is_object( $wp_analytify ) && isset( $wp_analytify->settings ) && method_exists( $wp_analytify->settings, 'get_option' ) ) {
				$profile_id = $wp_analytify->settings->get_option( 'profile_for_posts', 'wp-analytify-admin' );
			}

			if ( empty( $profile_id ) ) {
				wp_send_json_error( array( 'message' => __( 'No profile selected.', 'wp-analytify-pro' ) ) );
			}

			try {
				$realtime_data = $wp_analytify && method_exists( $wp_analytify, 'get_reports' ) ? $wp_analytify->get_reports( $profile_id, 'realtime', 'today', 'today' ) : array();
				wp_send_json_success( $realtime_data );
			} catch ( Exception $e ) {
				wp_send_json_error( array( 'message' => $e->getMessage() ) );
			}
		}

		/**
		 * Dashboard dropdown menu
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function dashboad_dropdown() {
			?>

		<div class="analytify_selected_dashboard_field"><?php esc_html_e( 'Dashboards', 'wp-analytify-pro' ); ?></div>
		<ul class="analytify_dashboards_list">

			<li><a href="<?php echo esc_url( admin_url( 'admin.php?page=analytify-dashboard&show=detail-realtime' ) ); ?>"><?php esc_html_e( 'REAL TIME', 'wp-analytify-pro' ); ?></a></li>
			<li><a href="<?php echo esc_url( admin_url( 'admin.php?page=analytify-dashboard&show=page-speed' ) ); ?>"><?php esc_html_e( 'Page Speed', 'wp-analytify-pro' ); ?></a></li>
			<li><a href="<?php echo esc_url( admin_url( 'admin.php?page=analytify-dashboard&show=detail-demographic' ) ); ?>"><?php esc_html_e( 'Demographics', 'wp-analytify-pro' ); ?></a></li>
			<?php do_action( 'analytify_dashboad_dropdown_option' ); ?>
			<li><a href="<?php echo esc_url( admin_url( 'admin.php?page=analytify-dashboard&show=search-terms' ) ); ?>"><?php esc_html_e( 'Search Terms', 'wp-analytify-pro' ); ?></a></li>
			<li><a href="<?php echo esc_url( admin_url( 'admin.php?page=analytify-dashboard&show=search-console-report' ) ); ?>"><?php esc_html_e( 'Search Console Dashboard', 'wp-analytify-pro' ); ?></a></li>

		</ul>

			<?php
		}

		/**
		 * Read an Advanced settings option from core Analytify.
		 *
		 * Dashboard manager parent is WP_Analytify_Pro (no settings API).
		 * Options live on $GLOBALS['WP_ANALYTIFY']->settings.
		 *
		 * @since 9.1.0
		 * @param string $option Option key under wp-analytify-advanced.
		 * @return string|false Option value, or false if settings unavailable.
		 */
		private function wp_analytify_get_advanced_setting( $option ) {
			if (
				empty( $GLOBALS['WP_ANALYTIFY'] )
				|| ! isset( $GLOBALS['WP_ANALYTIFY']->settings )
				|| ! method_exists( $GLOBALS['WP_ANALYTIFY']->settings, 'get_option' )
			) {
				return false;
			}

			return $GLOBALS['WP_ANALYTIFY']->settings->get_option( $option, 'wp-analytify-advanced' );
		}

		/**
		 * Load Errors Stats
		 *
		 * @param string $start_date Start date.
		 * @param string $end_date End date.
		 * @param string $dashboard_profile_ID Dashboard profile ID.
		 * @version 9.1.0
		 * @return void
		 */
		public function load_error_stats( $start_date, $end_date, $dashboard_profile_ID ) { // phpcs:ignore WordPress.NamingConventions.ValidVariableName.VariableNotSnakeCase
			// Show Ajax Error.
			if ( 'on' === $this->wp_analytify_get_advanced_setting( 'ajax_error_track' ) ) {
				?>
		<div id="wp-analytify-ajax-error-stats-box"><img class="dashboard-loader"  class="dashboard-loader" src="<?php echo esc_url( defined( 'ANALYTIFY_PLUGIN_URL' ) ? ANALYTIFY_PLUGIN_URL . 'assets/images/loading.gif' : '' ); ?>"></div>
				<?php
			}

			// 404.
			if ( 'on' === $this->wp_analytify_get_advanced_setting( '404_page_track' ) ) {
				?>
		<div id="wp-analytify-404-page-error-stats-box"><img class="dashboard-loader"  class="dashboard-loader" src="<?php echo esc_url( defined( 'ANALYTIFY_PLUGIN_URL' ) ? ANALYTIFY_PLUGIN_URL . 'assets/images/loading.gif' : '' ); ?>"></div>
			<script>
		//<![CDATA[
			jQuery( function($) {
				$.get(ajaxurl, { action:'analytify_load_404_error', dashboard_profile_ID:"<?php echo esc_js( $dashboard_profile_ID ); /* phpcs:ignore WordPress.NamingConventions.ValidVariableName.VariableNotSnakeCase */ ?>", start_date:"<?php echo esc_js( $start_date ); ?>", end_date: "<?php echo esc_js( $end_date ); ?>" },function(data){
					$('#wp-analytify-404-page-error-stats-box').html(data);
				});
			});
		//]]>
		</script>
				<?php
			}

			// javascript Errors.
			if ( 'on' === $this->wp_analytify_get_advanced_setting( 'javascript_error_track' ) ) {
				?>
		<div id="wp-analytify-javascript-error-stats-box"><img class="dashboard-loader"  class="dashboard-loader" src="<?php echo esc_url( defined( 'ANALYTIFY_PLUGIN_URL' ) ? ANALYTIFY_PLUGIN_URL . 'assets/images/loading.gif' : '' ); ?>"></div>
		<script>
		//<![CDATA[
			jQuery( function($) {
				$.get(ajaxurl, { action:'analytify_load_javascript_error', dashboard_profile_ID:"<?php echo esc_js( $dashboard_profile_ID ); /* phpcs:ignore WordPress.NamingConventions.ValidVariableName.VariableNotSnakeCase */ ?>", start_date:"<?php echo esc_js( $start_date ); ?>", end_date: "<?php echo esc_js( $end_date ); ?>" },function(data){
					$('#wp-analytify-javascript-error-stats-box').html(data);
				});
			});
		//]]>
		</script>
				<?php
			}
		}

		/**
		 * Template section for AJAX errors
		 *
		 * @param string $start_date Start date.
		 * @param string $end_date End date.
		 * @param string $dashboard_profile_id Dashboard profile ID.
		 * @param string $report_url Report URL.
		 * @param string $report_date_range Report date range.
		 * @since 1.0.0
		 * @version 9.1.0
		 * @return void
		 */
		public function template_section_ajax_error( $start_date, $end_date, $dashboard_profile_id, $report_url, $report_date_range ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed
			if ( 'on' !== $this->wp_analytify_get_advanced_setting( 'ajax_error_track' ) ) {
				return;
			}

			if ( defined( 'ANALYTIFY_PRO_ROOT_PATH' ) ) {
				include ANALYTIFY_PRO_ROOT_PATH . '/views/default/admin/section-ajax-error.php';
			}
		}

		/**
		 * Template section for 404 errors
		 *
		 * @param string $start_date Start date.
		 * @param string $end_date End date.
		 * @param string $dashboard_profile_id Dashboard profile ID.
		 * @param string $report_url Report URL.
		 * @param string $report_date_range Report date range.
		 * @since 1.0.0
		 * @version 9.1.0
		 * @return void
		 */
		public function template_section_404_error( $start_date, $end_date, $dashboard_profile_id, $report_url, $report_date_range ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed
			if ( 'on' !== $this->wp_analytify_get_advanced_setting( '404_page_track' ) ) {
				return;
			}

			if ( defined( 'ANALYTIFY_PRO_ROOT_PATH' ) ) {
				include ANALYTIFY_PRO_ROOT_PATH . '/views/default/admin/section-404-error.php';
			}
		}

		/**
		 * Template section for JavaScript errors
		 *
		 * @param string $start_date Start date.
		 * @param string $end_date End date.
		 * @param string $dashboard_profile_id Dashboard profile ID.
		 * @param string $report_url Report URL.
		 * @param string $report_date_range Report date range.
		 * @since 1.0.0
		 * @version 9.1.0
		 * @return void
		 */
		public function template_section_javascript_error( $start_date, $end_date, $dashboard_profile_id, $report_url, $report_date_range ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed
			if ( 'on' !== $this->wp_analytify_get_advanced_setting( 'javascript_error_track' ) ) {
				return;
			}

			if ( defined( 'ANALYTIFY_PRO_ROOT_PATH' ) ) {
				include ANALYTIFY_PRO_ROOT_PATH . '/views/default/admin/section-js-error.php';
			}
		}
	}
}
