<?php // phpcs:ignore WordPress.Files.FileName.InvalidClassFileName
/**
 * WP Analytify Pro REST API Advanced Endpoints Class
 *
 * This class handles advanced REST API endpoints including:
 * - Page speed
 * - Search console
 * - Compare stats
 * - Filter methods
 *
 * @package WP_Analytify_Pro
 * @since 8.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_Analytify_Pro_REST_Advanced' ) ) {

	/**
	 * WP Analytify Pro REST API Advanced Endpoints Class
	 *
	 * @since 1.0.0
	 */
	class WP_Analytify_Pro_REST_Advanced {

		/**
		 * Singleton instance.
		 *
		 * @var WP_Analytify_Pro_REST_Advanced $instance The one true WP_Analytify_Pro_REST_Advanced.
		 * @since 1.0.0
		 */
		private static $instance;

		/**
		 * The main Analytify object.
		 *
		 * @var object|null
		 */
		private $wp_analytify;

		/**
		 * GA version (ga4 or ga3).
		 *
		 * @var string
		 */
		private $ga_mode;

		/**
		 * Selected 'start state'.
		 *
		 * @var string
		 */
		private $start_date;

		/**
		 * Selected 'End state'.
		 *
		 * @var string
		 */
		private $end_date;

		/**
		 * Date difference.
		 *
		 * @var string
		 */
		private $date_differ;

		/**
		 * Type parameter.
		 *
		 * @var string
		 */
		private $type;


		/**
		 * Get active instance.
		 *
		 * @access public
		 * @since 1.0.0
		 * @return WP_Analytify_Pro_REST_Advanced The one true WP_Analytify_Pro_REST_Advanced.
		 */
		public static function instance() {
			if ( ! self::$instance ) {
				self::$instance = new WP_Analytify_Pro_REST_Advanced();
				self::$instance->init();
			}
			return self::$instance;
		}

		/**
		 * Initialize the class.
		 *
		 * @access private
		 * @since 1.0.0
		 * @return void
		 */
		private function init() {
			// Don't initialize wp_analytify here - it will be set when set_dates is called.
		}

		/**
		 * Set dates for the reports.
		 *
		 * @param string $start_date Start date.
		 * @param string $end_date End date.
		 * @param string $date_differ Date difference.
		 * @param string $type Type parameter.
		 * @param object $wp_analytify The main Analytify object.
		 * @param string $ga_mode GA mode.
		 * @return void
		 */
		public function set_dates( $start_date, $end_date, $date_differ, $type, $wp_analytify = null, $ga_mode = null ) {
			$this->start_date  = $start_date;
			$this->end_date    = $end_date;
			$this->date_differ = $date_differ;
			$this->type        = $type;

			// Set wp_analytify and ga_mode if provided.
			if ( null !== $wp_analytify ) {
				$this->wp_analytify = $wp_analytify;
			}
			if ( null !== $ga_mode ) {
				$this->ga_mode = $ga_mode;
			}
		}

		/**
		 * Endpoint for 'Page Speed' dashboard.
		 *
		 * @return array<string, mixed>
		 */
		public function page_speed() {
			// API limit.
			$api_limit = apply_filters( 'analytify_api_limit_page_speed_stats', 10, 'dashboard' );

			$stats = array();

			if ( 'ga4' === $this->ga_mode && isset( $this->wp_analytify ) && is_object( $this->wp_analytify ) && method_exists( $this->wp_analytify, 'get_reports' ) ) {
				$stats_raw = $this->wp_analytify->get_reports(
					'show-page-speed',
					array(
						'averageSessionDuration',
					),
					$this->get_dates(),
					array(
						'pagePath',
					),
					array(
						'type'  => 'metric',
						'name'  => 'averageSessionDuration',
						'order' => 'desc',
					),
					array(),
					$api_limit
				);

				if ( isset( $stats_raw['rows'] ) && $stats_raw['rows'] ) {
					foreach ( $stats_raw['rows'] as $row ) {
						$stats[] = array(
							'label' => $row['pagePath'],
							'value' => $row['averageSessionDuration'],
						);
					}
				}
			} elseif ( isset( $this->wp_analytify ) && method_exists( $this->wp_analytify, 'get_reports' ) ) {
				$stats_raw = $this->wp_analytify->get_reports(
					'show-page-speed',
					array(
						'avgSessionDuration',
					),
					$this->get_dates(),
					array(
						'pagePath',
					),
					array(
						'type'  => 'metric',
						'name'  => 'avgSessionDuration',
						'order' => 'desc',
					),
					array(),
					$api_limit
				);

				if ( isset( $stats_raw['rows'] ) && $stats_raw['rows'] ) {
					foreach ( $stats_raw['rows'] as $row ) {
						$stats[] = array(
							'label' => $row['pagePath'],
							'value' => $row['avgSessionDuration'],
						);
					}
				}
			}

			return array(
				'success' => true,
				'headers' => array(
					'label' => array(
						'label'    => esc_html__( 'Page', 'wp-analytify-pro' ),
						'th_class' => 'analytify_txt_left',
						'td_class' => '',
					),
					'value' => array(
						'label'    => esc_html__( 'Avg Session Duration', 'wp-analytify-pro' ),
						'th_class' => 'analytify_value_row',
						'td_class' => 'analytify_txt_center',
					),
				),
				'stats'   => $stats,
				'footer'  => apply_filters( 'analytify_page_speed_footer', __( 'Page speed stats.', 'wp-analytify-pro' ), array( $this->start_date, $this->end_date ) ),
			);
		}

		/**
		 * Endpoint for 'Keyword Stats Search Console' dashboard.
		 *
		 * @return array<string, mixed>
		 */
		public function keyword_stats_search_console() {

			// API limit.
			$api_stats_limit = apply_filters( 'analytify_api_limit_keywords_stats', 50, 'dashboard' );

			$headers        = true;
			$keywords_stats = array();
			$total_sessions = '0';
			$success        = true;
			$error_message  = false;

			if ( 'ga4' === $this->ga_mode ) {

				$keyword_stats_raw = isset( $this->wp_analytify ) && method_exists( $this->wp_analytify, 'get_search_console_stats' ) ? $this->wp_analytify->get_search_console_stats(
					'show-default-keyword-dashboard',
					$this->get_dates(),
					$api_stats_limit,
				) : array();

				if ( isset( $keyword_stats_raw['error']['status'] ) && isset( $keyword_stats_raw['error']['message'] ) ) {
					return array(
						'success'   => false,
						'error_box' => array(
							'title'   => __( 'Unable To Fetch Reports', 'wp-analytify-pro' ),
							'content' => '<p class="analytify-promo-popup-paragraph analytify-error-popup-paragraph"><strong>' . __( 'Status:', 'wp-analytify-pro' ) . ' </strong> ' . $keyword_stats_raw['error']['status'] . '</p><p class="analytify-promo-popup-paragraph analytify-error-popup-paragraph"><strong>' . __( 'Message:', 'wp-analytify-pro' ) . ' </strong> ' . $keyword_stats_raw['error']['message'] . '</p>',
						),
					);
				}

				if ( isset( $keyword_stats_raw['response']['rows'] ) && $keyword_stats_raw['response']['rows'] > 0 ) {
					foreach ( $keyword_stats_raw['response']['rows'] as $row ) {
						$keywords_stats[] = array(
							'keyword_url'      => $row['keys'][0],
							'impressions'      => $row['impressions'],
							'clicks'           => $row['clicks'],
							'ctr'              => isset( $row['ctr'] ) ? number_format( $row['ctr'] * 100, 1 ) . '%' : '0%', // Fetch CTR.
							'average_position' => isset( $row['position'] ) ? number_format( $row['position'], 1 ) : 0, // Fetch Avg. Position.
						);
					}
					$success = true;
					$headers = array(
						'keyword_url'      => array(
							'label'    => esc_html__( 'Keywords', 'wp-analytify-pro' ),
							'th_class' => 'analytify_txt_left analytify_link_title',
							'td_class' => '',
						),
						'impressions'      => array(
							'label'    => esc_html__( 'Impressions', 'wp-analytify-pro' ),
							'th_class' => 'analytify_value_row',
							'td_class' => 'analytify_txt_center analytify_value_row',
						),
						'clicks'           => array(
							'label'    => esc_html__( 'Clicks', 'wp-analytify-pro' ),
							'th_class' => 'analytify_value_row',
							'td_class' => 'analytify_txt_center analytify_value_row',
						),
						'ctr'              => array(
							'label'    => esc_html__( 'CTR', 'wp-analytify-pro' ),
							'th_class' => 'analytify_value_row',
							'td_class' => 'analytify_txt_center analytify_value_row',
						),
						'average_position' => array(
							'label'    => esc_html__( 'Avg. Position', 'wp-analytify-pro' ),
							'th_class' => 'analytify_value_row',
							'td_class' => 'analytify_txt_center analytify_value_row',
						),
					);
				}
			} else {

				$keyword_stats_raw = isset( $this->wp_analytify ) && method_exists( $this->wp_analytify, 'pa_get_analytics_dashboard' ) ? $this->wp_analytify->pa_get_analytics_dashboard( 'ga:sessions', $this->start_date, $this->end_date, 'ga:keyword', '-ga:sessions', false, $api_stats_limit, 'show-default-keyword-dashboard' ) : array();

				if ( isset( $keyword_stats_raw['totalsForAllResults']['ga:sessions'] ) ) {
					$total_sessions = $keyword_stats_raw['totalsForAllResults']['ga:sessions'];
				}

				if ( isset( $keyword_stats_raw['rows'] ) && $keyword_stats_raw['rows'] ) {
					foreach ( $keyword_stats_raw['rows'] as $row ) {
						$bar = '';
						if ( $total_sessions && $total_sessions > 0 ) {
							$bar = ' <span class="analytify_bar_graph"><span style="width:' . ( $row[1] / $total_sessions ) * 100 . '%"></span></span>';
						}
						$keywords_stats[] = array(
							'keyword'  => $row[0] . $bar,
							'sessions' => $row[1],
						);
					}
				}

				if ( isset( $keyword_stats_raw['rows'] ) || isset( $keyword_stats_raw['totalsForAllResults']['ga:sessions'] ) ) {
					$success = true;
					$headers = array(
						'keyword'  => array(
							'label'    => false,
							'th_class' => 'analytify_txt_left analytify_link_title',
							'td_class' => '',
						),
						'sessions' => array(
							'label'    => false,
							'th_class' => 'analytify_value_row',
							'td_class' => 'analytify_txt_center analytify_value_row',
						),
					);
				}
			}

			return array(
				'success'       => $success,
				'error_message' => $error_message,
				'headers'       => $headers,
				'stats'         => $keywords_stats,
				'title_stats'   => 0 !== $total_sessions ? '<span class="analytify_medium_f">' . __( 'Total Visits', 'wp-analytify-pro' ) . '</span> ' . $total_sessions : false,
				'footer'        => apply_filters( 'analytify_keywords_footer', __( 'Ranked keywords.', 'wp-analytify-pro' ), array( $this->start_date, $this->end_date ) ),
			);
		}

		/**
		 * Endpoint for 'Compare Stats'.
		 *
		 * @return array<string, mixed>|null
		 */
		public function compare_stats() {

			$this_month_start_date = $this->start_date;
			$this_month_end_date   = $this->end_date;

			$this_year_start_date = $this->start_date;
			$this_year_end_data   = $this->end_date;

			$previous_year_start_timestamp = strtotime( $this->start_date . ' -1 year' );
			$previous_year_start_date      = gmdate( 'Y-m-d', $previous_year_start_timestamp ? $previous_year_start_timestamp : time() );
			$previous_year_end_timestamp   = strtotime( $this->end_date . ' -1 year' );
			$previous_year_end_date        = gmdate( 'Y-m-d', $previous_year_end_timestamp ? $previous_year_end_timestamp : time() );

			$date1 = ! empty( $this_year_start_date ) ? date_create( $this_year_start_date ) : false;
			$date2 = ! empty( $this_year_end_data ) ? date_create( $this_year_end_data ) : false;
			$diff  = ( $date1 && $date2 ) ? date_diff( $date2, $date1 ) : false;

			$previous_month_start_timestamp = strtotime( $this->start_date . ' -1 month' );
			$previous_month_start_date      = gmdate( 'Y-m-d', $previous_month_start_timestamp ? $previous_month_start_timestamp : time() );
			$previous_month_end_timestamp   = strtotime( $this->end_date . ' -1 month' );
			$previous_month_end_date        = gmdate( 'Y-m-d', $previous_month_end_timestamp ? $previous_month_end_timestamp : time() );

			$is_three_month = false;

			$this_year_start_timestamp = strtotime( $this_year_start_date );
			if ( '1' === gmdate( 'j', $this_year_start_timestamp ? $this_year_start_timestamp : time() ) ) {
				$previous_year_start_plus_timestamp = strtotime( $previous_year_start_date . ' +1 day' );
				$previous_year_start_date           = gmdate( 'Y-m-d', $previous_year_start_plus_timestamp ? $previous_year_start_plus_timestamp : time() );
				$this_year_start_plus_timestamp     = strtotime( $this_year_start_date . ' +1 day' );
				$this_year_start_date               = gmdate( 'Y-m-d', $this_year_start_plus_timestamp ? $this_year_start_plus_timestamp : time() );
			}

			// $view_data = $this->view_data. // phpcs:ignore Squiz.PHP.CommentedOutCode.Found

			if ( 'ga4' === $this->ga_mode ) {

				$year_dimensions = array( 'year', 'month', 'date' );

				/**
				 * Get 'users' and 'views' for this month, previous month, this year and previous year.
				 */

				$this_month_stats = isset( $this->wp_analytify ) && method_exists( $this->wp_analytify, 'get_reports' ) ? $this->wp_analytify->get_reports(
					'show-this-month-stats',
					array(
						'totalUsers',
						'screenPageViews',
					),
					array(
						'start' => $this_month_start_date,
						'end'   => $this_month_end_date,
					),
					array(
						'date',
					),
					array(
						'type' => 'dimension',
						'name' => 'date',
					),
					array(),
					1000,
				) : array();

				$previous_month_stats = isset( $this->wp_analytify ) && method_exists( $this->wp_analytify, 'get_reports' ) ? $this->wp_analytify->get_reports(
					'show-previous-month-stats',
					array(
						'totalUsers',
						'screenPageViews',
					),
					array(
						'start' => $previous_month_start_date,
						'end'   => $previous_month_end_date,
					),
					array(
						'date',
					),
					array(
						'type' => 'dimension',
						'name' => 'date',
					),
					array(),
					1000,
				) : array();

				if ( ! empty( $previous_month_stats['rows'] ) && gmdate( 'Y-m-d', strtotime( $previous_month_stats['rows'][0]['date'] ) ) !== $previous_month_start_date ) {
					$previous_month_stats['rows'] = array();
				}

				// If difference less than 3 months, get data on date base.
				if ( $diff && $diff->format( '%a' ) < 90 ) {
					$year_dimensions = array( 'date' );
					$is_three_month  = true;
				}

				$this_year_stats = isset( $this->wp_analytify ) && method_exists( $this->wp_analytify, 'get_reports' ) ? $this->wp_analytify->get_reports(
					'show-this-year-stats',
					array(
						'totalUsers',
						'screenPageViews',
					),
					array(
						'start' => $this_year_start_date,
						'end'   => $this_year_end_data,
					),
					$year_dimensions,
					array(
						'type' => 'dimension',
						'name' => 'date',
					),
					array(),
					1000,
				) : array();

				$previous_year_stats = isset( $this->wp_analytify ) && method_exists( $this->wp_analytify, 'get_reports' ) ? $this->wp_analytify->get_reports(
					'show-previous-year-stats',
					array(
						'totalUsers',
						'screenPageViews',
					),
					array(
						'start' => $previous_year_start_date,
						'end'   => $previous_year_end_date,
					),
					$year_dimensions,
					array(
						'type' => 'dimension',
						'name' => 'date',
					),
					array(),
					1000,
				) : array();

				if ( defined( 'ANALYTIFY_PRO_ROOT_PATH' ) ) {
					include ANALYTIFY_PRO_ROOT_PATH . '/views/default/admin/main-comparison-stats.php';
				}
				fetch_visitors_views_comparison( $this->wp_analytify, $this_month_stats, $previous_month_stats, $this_year_stats, $previous_year_stats, $is_three_month, $this_month_start_date, $this_month_end_date, $previous_month_start_date, $previous_month_end_date, $this_year_start_date, $this_year_end_data, $previous_year_start_date, $previous_year_end_date );
				return null;

			}

			// Fallback return for non-GA4 mode.
			return array(
				'success'       => false,
				'error_message' => __( 'GA4 mode is required for comparison stats.', 'wp-analytify-pro' ),
			);
		}

		/**
		 * Filters raw events tracking stats and splits them into separate arrays for each event type.
		 *
		 * @param array<int|string, mixed> $stats_raw Raw events tracking stats.
		 * @param string                   $ga_mode   GA mode.
		 *
		 * @return array<int|string, mixed>
		 */
		public function filter_events_tracking_raw_stats( $stats_raw, $ga_mode ) {
			$stats = array();

			$categories = array( 'external', 'download', 'tel', 'outbound-link', 'mail' );

			if ( 'ga4' === $ga_mode ) {
				foreach ( $stats_raw as $row ) {
					$event_category = $row['customEvent:wpa_category'];

					if ( in_array( $event_category, $categories, true ) ) {
						$stats[ $event_category ][] = array(
							'no'     => null,
							'label'  => $row['customEvent:wpa_link_label'],
							'action' => $row['customEvent:wpa_link_action'],
							'views'  => class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' ) ? WPANALYTIFY_Utils::pretty_numbers( $row['eventCount'] ) : $row['eventCount'],
						);
					}
				}
			} else {
				foreach ( $stats_raw as $row ) {
					$event_category = $row[0];

					if ( in_array( $event_category, $categories, true ) ) {
						$stats[ $event_category ][] = array(
							'no'     => null,
							'label'  => $row[1],
							'action' => $row[2],
							'views'  => class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' ) ? WPANALYTIFY_Utils::pretty_numbers( $row[3] ) : $row[3],
						);
					}
				}
			}

			// Limit all event categories.
			if ( ! empty( $stats ) ) {
				foreach ( array_keys( $stats ) as $key ) {
					$limit         = apply_filters( 'analytify_events_tracking_limit_' . $key . '_stats', 50 );
					$stats[ $key ] = array_slice( $stats[ $key ], 0, $limit, true );
				}
			}

			return $stats;
		}

		/**
		 * Applied as a filter to a single custom dimension row label.
		 *
		 * @param string $label Row label.
		 * @param string $type  Dimension type.
		 *
		 * @return string
		 */
		public function filter_custom_dimension_row_label( $label, $type ) {
			if ( empty( $label ) ) {
				return $type;
			}

			if ( 'published_at' === $type ) {
				$formatted = $this->format_published_at_dimension_label( (string) $label );
				if ( '' !== $formatted ) {
					return $formatted;
				}
				return sanitize_text_field( (string) $label );
			}

			return ucwords( str_replace( array( '-', '_' ), ' ', $label ) );
		}

		/**
		 * Format a "Published at" custom dimension value for display (dashboard / export).
		 *
		 * Accepts ISO 8601 from GA, values mangled by legacy formatting, or site-style dates from tracking.
		 *
		 * @param string $label Raw dimension value.
		 * @return string Formatted date/time, 'undefined' as-is, or empty when nothing usable.
		 */
		private function format_published_at_dimension_label( $label ) {
			if ( '' === $label ) {
				return '';
			}

			if ( 'undefined' === strtolower( $label ) ) {
				return 'undefined';
			}

			$ts = strtotime( $label );
			if ( false === $ts && preg_match( '/^\d{4}\s+\d{2}\s+\d{2}/', $label ) ) {
				$normalized = preg_replace( '/^(\d{4})\s+(\d{2})\s+(\d{2})/', '$1-$2-$3', $label, 1 );
				$ts         = strtotime( $normalized );
			}

			if ( false === $ts ) {
				return '';
			}

			$date_format = get_option( 'date_format' );
			$time_format = get_option( 'time_format' );
			$combined    = trim( $date_format . ' ' . $time_format );

			$formatted = '' !== $combined ? wp_date( $combined, $ts ) : wp_date( 'Y-m-d H:i', $ts );

			return preg_replace_callback(
				'/\b(am|pm)\b/i',
				static function ( $m ) {
					return strtoupper( $m[0] );
				},
				$formatted
			);
		}

		/**
		 * Get dates for comparison.
		 *
		 * @return array<string, string>
		 */
		private function get_dates() {
			return array(
				'start' => $this->start_date,
				'end'   => $this->end_date,
			);
		}
	}
}
