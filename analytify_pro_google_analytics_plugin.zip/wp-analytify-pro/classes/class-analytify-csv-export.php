<?php
// phpcs:ignoreFile WordPress.Files.FileName.InvalidClassFileName
/**
 * This file handles all the CSV export related functionality
 *
 * @package WP_Analytify_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	// Exit if accessed directly.
	exit;
}

if ( ! function_exists( 'analytify_pro_csv_api_limit' ) ) {
	/**
	 * CSV export row limit matching dashboard/frontend defaults.
	 *
	 * Uses the same filter context ('dashboard') and defaults as on-screen widgets
	 * so exported rows match what the admin sees.
	 *
	 * @param string $filter_name   Filter hook name.
	 * @param int    $default_limit Default row limit (same as dashboard widget).
	 * @param mixed  ...$args       Extra filter args after context.
	 * @return int
	 */
	function analytify_pro_csv_api_limit( $filter_name, $default_limit, ...$args ) {
		if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'wp_analytify_get_api_limit' ) ) {
			return WPANALYTIFY_Utils::wp_analytify_get_api_limit( $filter_name, $default_limit, 'dashboard', ...$args );
		}

		return max( 0, (int) apply_filters( $filter_name, $default_limit, 'dashboard', ...$args ) );
	}
}

/**
 * Handles CSV Export
 */
class AnalytifyCSVExport {

	/**
	 * The main Analytify object.
	 *
	 * @var object|null
	 */
	private $wp_analytify;

	/**
	 * GA version (ga4 or ga3).
	 *
	 * @var string
	 */
	private $ga_mode;

	/**
	 * Requested csv type (section).
	 *
	 * @var string
	 */
	private $type;

	/**
	 * Selected 'start state'.
	 *
	 * @var string
	 */
	private $start_date;

	/**
	 * Selected 'End state'.
	 *
	 * @var string
	 */
	private $end_date;

		/**
		 * Basic exports split class.
		 *
		 * @var WP_Analytify_Pro_CSV_Basic_Exports|null
		 */
	private $basic_exports;

		/**
		 * Social and referral exports split class.
		 *
		 * @var WP_Analytify_Pro_CSV_Social_Referral_Exports|null
		 */
	private $social_referral_exports;

		/**
		 * Error tracking exports split class.
		 *
		 * @var WP_Analytify_Pro_CSV_Error_Tracking_Exports|null
		 */
	private $error_tracking_exports;

		/**
		 * Device analytics exports split class.
		 *
		 * @var WP_Analytify_Pro_CSV_Device_Analytics_Exports|null
		 */
	private $device_analytics_exports;

		/**
		 * Forms and events exports split class.
		 *
		 * @var WP_Analytify_Pro_CSV_Forms_Events_Exports|null
		 */
	private $forms_events_exports;

		/**
		 * Miscellaneous exports split class.
		 *
		 * @var WP_Analytify_Pro_CSV_Miscellaneous_Exports|null
		 */
	private $miscellaneous_exports;

		/**
		 * WooCommerce exports split class.
		 *
		 * @var WP_Analytify_Pro_CSV_WooCommerce_Exports|null
		 */
	private $woocommerce_exports;

	/**
	 * Constructor
	 *
	 * @version 7.0.5
	 */
	public function __construct() {
		// Check if the global variable is available.
		if ( ! isset( $GLOBALS['WP_ANALYTIFY'] ) ) {
			// Try to get it from the main plugin.
			if ( class_exists( 'WP_Analytify' ) ) {
				$this->wp_analytify = WP_Analytify::get_instance();
			} else {
				// Fallback - this will be set later when set_data is called.
				$this->wp_analytify = null;
			}
		} else {
			$this->wp_analytify = $GLOBALS['WP_ANALYTIFY'];
		}

		// Set GA mode if possible.
		if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) ) {
			$this->ga_mode = WPANALYTIFY_Utils::get_ga_mode();
		} else {
			$this->ga_mode = 'ga3';
		}

		// Load all split files immediately to ensure they're available.
		$this->load_all_split_files();
	}

	/**
	 * Load all split files immediately
	 *
	 * @version 7.0.5
	 * @return void
	 */
	private function load_all_split_files() {
		$this->init_basic_exports();
		$this->init_social_referral_exports();
		$this->init_error_tracking_exports();
		$this->init_device_analytics_exports();
		$this->init_forms_events_exports();
		$this->init_miscellaneous_exports();
		$this->init_woocommerce_exports();
	}

	/**
	 * Ensure all split files are loaded
	 *
	 * @version 7.0.5
	 * @return void
	 */
	private function ensure_split_files_loaded() {
		if ( ! isset( $this->basic_exports ) ) {
			$this->init_basic_exports();
		}
		if ( ! isset( $this->social_referral_exports ) ) {
			$this->init_social_referral_exports();
		}
		if ( ! isset( $this->error_tracking_exports ) ) {
			$this->init_error_tracking_exports();
		}
		if ( ! isset( $this->device_analytics_exports ) ) {
			$this->init_device_analytics_exports();
		}
		if ( ! isset( $this->forms_events_exports ) ) {
			$this->init_forms_events_exports();
		}
		if ( ! isset( $this->miscellaneous_exports ) ) {
			$this->init_miscellaneous_exports();
		}
		if ( ! isset( $this->woocommerce_exports ) ) {
			$this->init_woocommerce_exports();
		}
	}

	/**
	 * Initialize the basic exports split class
	 *
	 * @version 7.0.5
	 * @return void
	 */
	private function init_basic_exports() {
		$file_path = __DIR__ . '/class-analytify-pro-csv-basic-exports.php';

		if ( ! file_exists( $file_path ) ) {
			return;
		}

		// Include the basic exports split class.
		require_once $file_path;

		// Check if class exists.
		if ( ! class_exists( 'WP_Analytify_Pro_CSV_Basic_Exports' ) ) {
			return;
		}

		// Initialize the basic exports class.
		$this->basic_exports = new WP_Analytify_Pro_CSV_Basic_Exports();
	}

	/**
	 * Initialize the social and referral exports split class
	 *
	 * @version 7.0.5
	 * @return void
	 */
	private function init_social_referral_exports() {
		// Include the social and referral exports split class.
		require_once __DIR__ . '/class-analytify-pro-csv-social-referral-exports.php';

		// Initialize the social and referral exports class.
		$this->social_referral_exports = new WP_Analytify_Pro_CSV_Social_Referral_Exports();
	}

	/**
	 * Initialize the error tracking exports split class
	 *
	 * @version 7.0.5
	 * @return void
	 */
	private function init_error_tracking_exports() {
		// Include the error tracking exports split class.
		require_once __DIR__ . '/class-analytify-pro-csv-error-tracking.php';

		// Initialize the error tracking exports class.
		$this->error_tracking_exports = new WP_Analytify_Pro_CSV_Error_Tracking_Exports();
	}

	/**
	 * Initialize the device analytics exports split class
	 *
	 * @version 7.0.5
	 * @return void
	 */
	private function init_device_analytics_exports() {
		// Include the device analytics exports split class.
		require_once __DIR__ . '/class-analytify-pro-csv-device-analytics.php';

		// Initialize the device analytics exports class.
		$this->device_analytics_exports = new WP_Analytify_Pro_CSV_Device_Analytics_Exports();
	}

	/**
	 * Initialize the forms and events exports split class
	 *
	 * @version 7.0.5
	 * @return void
	 */
	private function init_forms_events_exports() {
		// Include the forms and events exports split class.
		require_once __DIR__ . '/class-analytify-pro-csv-forms-events.php';

		// Initialize the forms and events exports class.
		$this->forms_events_exports = new WP_Analytify_Pro_CSV_Forms_Events_Exports();
	}

	/**
	 * Initialize the miscellaneous exports split class
	 *
	 * @version 7.0.5
	 * @return void
	 */
	private function init_miscellaneous_exports() {
		// Include the miscellaneous exports split class.
		require_once __DIR__ . '/class-analytify-pro-csv-miscellaneous-exports.php';

		// Initialize the miscellaneous exports class.
		$this->miscellaneous_exports = new WP_Analytify_Pro_CSV_Miscellaneous_Exports();
	}

	/**
	 * Initialize the WooCommerce exports split class
	 *
	 * @version 7.0.5
	 * @return void
	 */
	private function init_woocommerce_exports() {
		// Include the WooCommerce exports split class.
		require_once __DIR__ . '/class-analytify-pro-csv-woocommerce-exports.php';

		// Initialize the WooCommerce exports class.
		$this->woocommerce_exports = new WP_Analytify_Pro_CSV_WooCommerce_Exports();
	}

	/**
	 * Verifies nonce.
	 * Also checks for user capabilities.
	 *
	 * @version 7.0.5
	 * @param string $nonce  Nonce.
	 * @param string $action Nonce Action.
	 * @return bool
	 */
	public function auth_check( $nonce, $action ) {
		if ( ! function_exists( 'wp_verify_nonce' ) || ! wp_verify_nonce( $nonce, $action ) ) {
			return false;
		}

		if ( ! isset( $this->wp_analytify ) || ! is_object( $this->wp_analytify ) ) {
			return false;
		}

		$is_access_level = array( 'administrator' );
		if ( $this->wp_analytify && is_object( $this->wp_analytify ) && isset( $this->wp_analytify->settings ) && method_exists( $this->wp_analytify->settings, 'get_option' ) ) {
			$is_access_level = $this->wp_analytify->settings->get_option( 'show_analytics_roles_dashboard', 'wp-analytify-dashboard', array( 'administrator' ) );
		}

		if ( ! method_exists( $this->wp_analytify, 'pa_check_roles' ) || ! $this->wp_analytify->pa_check_roles( $is_access_level ) ) {
			return false;
		}

		return true;
	}

	/**
	 * Generates export data and update the option.
	 *
	 * @version 9.1.1
	 * @param string                $type CSV type.
	 * @param array<string, string> $date Date range (start and end).
	 * @param mixed                 $args Additional arguments.
	 *
	 * @return bool
	 */
	public function generate_export_data( $type, $date, $args ) {
		// Ensure wp_analytify object is available.
		if ( ! isset( $this->wp_analytify ) || ! is_object( $this->wp_analytify ) ) {
			// Try to get it from globals.
			if ( isset( $GLOBALS['WP_ANALYTIFY'] ) ) {
				$this->wp_analytify = $GLOBALS['WP_ANALYTIFY'];
			} else {
				// If still not available, return error.
				return false;
			}
		}

		// Ensure all split files are loaded before proceeding.
		$this->ensure_split_files_loaded();

		$this->type       = $type;
		$this->start_date = $date['start_date'];
		$this->end_date   = $date['end_date'];

		switch ( $type ) {
			case 'general-stats':
				if ( $this->basic_exports && $this->wp_analytify ) {
					$this->basic_exports->set_data( $this->wp_analytify, $this->ga_mode, $this->start_date, $this->end_date );
					$data = $this->basic_exports->export_general_stats();
				} else {
					$data = array();
				}
				break;
			case 'top-pages':
				if ( $this->basic_exports && $this->wp_analytify ) {
					$this->basic_exports->set_data( $this->wp_analytify, $this->ga_mode, $this->start_date, $this->end_date );
					$data = $this->basic_exports->export_top_pages();
				} else {
					$data = array();
				}
				break;
			case 'top-countries':
				if ( ! $this->basic_exports ) {
					return false;
				}

				if ( $this->wp_analytify ) {
					$this->basic_exports->set_data( $this->wp_analytify, $this->ga_mode, $this->start_date, $this->end_date );
				}
				$data = $this->basic_exports->export_top_countries();
				break;
			case 'top-cities':
				if ( $this->wp_analytify ) {
					$this->basic_exports->set_data( $this->wp_analytify, $this->ga_mode, $this->start_date, $this->end_date );
				}
				$data = $this->basic_exports ? $this->basic_exports->export_top_cities() : array();
				break;
			case 'top-keywords':
			case 'top-keywords-with-ctr': // Legacy alias.
				if ( $this->wp_analytify ) {
					$this->basic_exports->set_data( $this->wp_analytify, $this->ga_mode, $this->start_date, $this->end_date );
				}
				$data = $this->basic_exports ? $this->basic_exports->export_top_keywords() : array();
				break;
			case 'top-social-media':
				if ( $this->social_referral_exports && $this->wp_analytify ) {
					$this->social_referral_exports->set_data( $this->wp_analytify, $this->ga_mode, $this->start_date, $this->end_date );
				}
				$data = $this->social_referral_exports ? $this->social_referral_exports->export_top_social_media() : array();
				break;
			case 'top-reffers': // For legacy support.
			case 'top-referrer':
				if ( $this->social_referral_exports && $this->wp_analytify ) {
					$this->social_referral_exports->set_data( $this->wp_analytify, $this->ga_mode, $this->start_date, $this->end_date );
				}
				$data = $this->social_referral_exports ? $this->social_referral_exports->export_top_referrer() : array();
				break;
			case 'what-happen':
				if ( $this->social_referral_exports && $this->wp_analytify ) {
					$this->social_referral_exports->set_data( $this->wp_analytify, $this->ga_mode, $this->start_date, $this->end_date );
				}
				$data = $this->social_referral_exports ? $this->social_referral_exports->export_what_is_happening() : array();
				break;
			case 'top-ajax':
				if ( $this->error_tracking_exports && $this->wp_analytify ) {
					$this->error_tracking_exports->set_data( $this->wp_analytify, $this->ga_mode, $this->start_date, $this->end_date );
				}
				$data = $this->error_tracking_exports ? $this->error_tracking_exports->export_top_ajax_errors() : array();
				break;
			case 'top-404':
				if ( $this->error_tracking_exports && $this->wp_analytify ) {
					$this->error_tracking_exports->set_data( $this->wp_analytify, $this->ga_mode, $this->start_date, $this->end_date );
				}
				$data = $this->error_tracking_exports ? $this->error_tracking_exports->export_top_404_errors() : array();
				break;
			case 'top-js-error':
				if ( $this->error_tracking_exports && $this->wp_analytify ) {
					$this->error_tracking_exports->set_data( $this->wp_analytify, $this->ga_mode, $this->start_date, $this->end_date );
				}
				$data = $this->error_tracking_exports ? $this->error_tracking_exports->export_top_js_errors() : array();
				break;
			case 'video-tracking':
				$data = $this->export_video_tracking();
				break;
			case 'top-browsers':
				if ( $this->device_analytics_exports && $this->wp_analytify ) {
					$this->device_analytics_exports->set_data( $this->wp_analytify, $this->ga_mode, $this->start_date, $this->end_date );
				}
				$data = $this->device_analytics_exports ? $this->device_analytics_exports->export_top_browsers() : array();
				break;
			case 'top-operating-system':
				if ( $this->device_analytics_exports && $this->wp_analytify ) {
					$this->device_analytics_exports->set_data( $this->wp_analytify, $this->ga_mode, $this->start_date, $this->end_date );
				}
				$data = $this->device_analytics_exports ? $this->device_analytics_exports->export_top_operating_system() : array();
				break;
			case 'top-mobile-device':
				if ( $this->device_analytics_exports && $this->wp_analytify ) {
					$this->device_analytics_exports->set_data( $this->wp_analytify, $this->ga_mode, $this->start_date, $this->end_date );
				}
				$data = $this->device_analytics_exports ? $this->device_analytics_exports->export_top_mobile_device() : array();
				break;

			case 'forms-dashboard':
				$form = ! empty( $args ) ? $args : false;
				$data = $this->forms_events_exports ? $this->forms_events_exports->export_forms_dashboard( $form ) : array();
				break;

			case 'forms-hubspot':
				$data = $this->forms_events_exports ? $this->forms_events_exports->export_forms_dashboard( 'analytify_form_hubspot' ) : array();
				break;

			case 'forms-jotform':
				$data = $this->forms_events_exports ? $this->forms_events_exports->export_forms_dashboard( 'analytify_form_jotform' ) : array();
				break;

			case 'forms-wpform':
				$data = $this->forms_events_exports ? $this->forms_events_exports->export_forms_dashboard( 'analytify_form_wpforms' ) : array();
				break;

			case 'forms-gravity':
				$data = $this->forms_events_exports ? $this->forms_events_exports->export_forms_dashboard( 'analytify_form_gf' ) : array();
				break;

			case 'forms-cf7':
				$data = $this->forms_events_exports ? $this->forms_events_exports->export_forms_dashboard( 'analytify_form_wpcf7' ) : array();
				break;

			case 'forms-ninja':
				$data = $this->forms_events_exports ? $this->forms_events_exports->export_forms_dashboard( 'analytify_form_ninja_forms' ) : array();
				break;

			case 'forms-elementor':
				$data = $this->forms_events_exports ? $this->forms_events_exports->export_forms_dashboard( 'analytify_form_elementor' ) : array();
				break;

			case 'forms-formidable':
				$data = $this->forms_events_exports ? $this->forms_events_exports->export_forms_dashboard( 'analytify_form_formidable' ) : array();
				break;

			case 'forms-fluentforms':
				$data = $this->forms_events_exports ? $this->forms_events_exports->export_forms_dashboard( 'analytify_form_fluentforms' ) : array();
				break;

			case 'forms-custom':
				$data = $this->forms_events_exports ? $this->forms_events_exports->export_forms_dashboard( 'analytify_form_custom' ) : array();
				break;

			case 'forms-mailpoet':
				$data = $this->forms_events_exports ? $this->forms_events_exports->export_forms_dashboard( 'analytify_form_mailpoet' ) : array();
				break;

			// Events Tracking sections.
			case 'external-links':
			case 'download-links':
			case 'tel-links':
			case 'affiliate-links':
			case 'mail-links':
				if ( $this->forms_events_exports ) {
					$this->forms_events_exports->set_data( $this->wp_analytify, $this->ga_mode, $this->start_date, $this->end_date, $type );
					$data = $this->forms_events_exports->export_event_tracking_section();
				} else {
					$data = array();
				}
				break;

			// Custom Dimensions sections.
			case 'custom-dimension-author':
			case 'custom-dimension-post_type':
			case 'custom-dimension-published_at':
			case 'custom-dimension-category':
			case 'custom-dimension-tags':
			case 'custom-dimension-user_id':
			case 'custom-dimension-logged_in':
			case 'custom-dimension-seo_score':
			case 'custom-dimension-focus_keyword':
			case 'custom-dimension-archive_type':
				$data = $this->export_custom_dimension_section();
				break;

			case 'search-terms':
				if ( $this->miscellaneous_exports && $this->wp_analytify ) {
					$this->miscellaneous_exports->set_data( $this->wp_analytify, $this->ga_mode, $this->start_date, $this->end_date );
				}
				$data = $this->miscellaneous_exports ? $this->miscellaneous_exports->export_search_terms() : array();
				break;

			case 'demographics':
				if ( $this->miscellaneous_exports && $this->wp_analytify ) {
					$this->miscellaneous_exports->set_data( $this->wp_analytify, $this->ga_mode, $this->start_date, $this->end_date );
				}
				$data = $this->miscellaneous_exports ? $this->miscellaneous_exports->export_demographics() : array();
				break;
			case 'interests':
				if ( $this->miscellaneous_exports && $this->wp_analytify ) {
					$this->miscellaneous_exports->set_data( $this->wp_analytify, $this->ga_mode, $this->start_date, $this->end_date );
				}
				$data = $this->miscellaneous_exports ? $this->miscellaneous_exports->export_interests() : array();
				break;
			case 'author-stats': // For legacy support.
				if ( isset( $args['filter'] ) && 'true' === $args['filter'] ) {
					$author_id = 0;
				} else {
					$dimension = explode( '==', $args['filter'] );
					$user      = get_user_by( 'login', $dimension[1] );
					$author_id = $user ? $user->ID : 0;
				}

				if ( $this->miscellaneous_exports && $this->wp_analytify ) {
					$this->miscellaneous_exports->set_data( $this->wp_analytify, $this->ga_mode, $this->start_date, $this->end_date );
				}
				$data = $this->miscellaneous_exports ? $this->miscellaneous_exports->export_author_stats( $author_id ) : array();
				break;
			case 'authors-dashboard':
				$author_id = isset( $args ) && is_numeric( $args ) ? (int) $args : 0;
				if ( $this->miscellaneous_exports && $this->wp_analytify ) {
					$this->miscellaneous_exports->set_data( $this->wp_analytify, $this->ga_mode, $this->start_date, $this->end_date );
				}
				$data = $this->miscellaneous_exports ? $this->miscellaneous_exports->export_author_stats( $author_id ) : array();
				break;

			case 'top-sales-countries':
				if ( $this->woocommerce_exports && $this->wp_analytify ) {
					$this->woocommerce_exports->set_data( $this->wp_analytify, $this->ga_mode, $this->start_date, $this->end_date );
				}
				$data = $this->woocommerce_exports ? $this->woocommerce_exports->export_top_sales_countries() : array();
				break;

			case 'measuring-roi':
				if ( $this->woocommerce_exports && $this->wp_analytify ) {
					$this->woocommerce_exports->set_data( $this->wp_analytify, $this->ga_mode, $this->start_date, $this->end_date );
				}
				$data = $this->woocommerce_exports ? $this->woocommerce_exports->export_measuring_roi() : array();
				break;

			case 'products-performance':
				if ( $this->woocommerce_exports && $this->wp_analytify ) {
					$this->woocommerce_exports->set_data( $this->wp_analytify, $this->ga_mode, $this->start_date, $this->end_date );
				}
				$data = $this->woocommerce_exports ? $this->woocommerce_exports->export_products_performance() : array();
				break;

			case 'product-lists-analysis':
				if ( $this->woocommerce_exports && $this->wp_analytify ) {
					$this->woocommerce_exports->set_data( $this->wp_analytify, $this->ga_mode, $this->start_date, $this->end_date );
				}
				$data = $this->woocommerce_exports ? $this->woocommerce_exports->export_product_lists_analysis() : array();
				break;

			case 'product-categories':
				if ( $this->woocommerce_exports && $this->wp_analytify ) {
					$this->woocommerce_exports->set_data( $this->wp_analytify, $this->ga_mode, $this->start_date, $this->end_date );
				}
				$data = $this->woocommerce_exports ? $this->woocommerce_exports->export_product_categories() : array();
				break;

			case 'coupons-analysis':
				if ( $this->woocommerce_exports && $this->wp_analytify ) {
					$this->woocommerce_exports->set_data( $this->wp_analytify, $this->ga_mode, $this->start_date, $this->end_date );
				}
				$data = $this->woocommerce_exports ? $this->woocommerce_exports->export_coupons_analysis() : array();
				break;

			default:
				wp_send_json_error( 'Invalid export type.', 404 );
		}

		if ( is_array( $data ) && ! empty( $data ) ) {
			update_option( 'analytify_csv_data', $data );
			return true;
		}

		return false;
	}







	/**
	 * Generates video tracking export.
	 *
	 * @version 9.1.1
	 * @return list<array<int, mixed>>
	 */
	private function export_video_tracking() {

		// API limit.
		$api_limit = analytify_pro_csv_api_limit( 'analytify_api_limit_video_tracking_stats', 50 );

		$stats = array();

		if ( $this->wp_analytify && is_object( $this->wp_analytify ) && isset( $this->wp_analytify->settings ) && method_exists( $this->wp_analytify->settings, 'get_option' ) ) {
			$video_tracking = $this->wp_analytify->settings->get_option( 'video_tracking', 'wp-analytify-advanced' );
			if ( 'on' === $video_tracking ) {
				if ( 'ga4' === $this->ga_mode && method_exists( $this->wp_analytify, 'get_reports' ) ) {
					$video_stats_raw = $this->wp_analytify->get_reports(
						'show-video-tracking',
						array( 'eventCount' ),
						$this->get_dates(),
						array(
							'customEvent:wpa_category',
							'customEvent:wpa_video_title',
							'customEvent:wpa_video_provider',
							'customEvent:wpa_video_action',
							'customEvent:wpa_video_duration',
						),
						array(
							'type'  => 'metric',
							'name'  => 'eventCount',
							'order' => 'desc',
						),
						array(
							'logic'   => 'AND',
							'filters' => array(
								array(
									'type'           => 'dimension',
									'name'           => 'customEvent:wpa_category',
									'match_type'     => 1,
									'value'          => 'Analytify Video Tracking',
									'not_expression' => false,
								),
							),
						),
						$api_limit
					);

					if ( isset( $video_stats_raw['rows'] ) && $video_stats_raw['rows'] ) {
						foreach ( $video_stats_raw['rows'] as $row ) {
							$stats[] = array(
								'0' => $row['customEvent:wpa_video_title'],
								'1' => $row['customEvent:wpa_video_provider'],
								'2' => $row['customEvent:wpa_video_action'],
								'3' => class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' ) ? WPANALYTIFY_Utils::pretty_numbers( $row['customEvent:wpa_video_duration'] ) : $row['customEvent:wpa_video_duration'],
								'4' => class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'pretty_numbers' ) ? WPANALYTIFY_Utils::pretty_numbers( $row['eventCount'] ) : $row['eventCount'],
							);
						}
					}
				}
			}
		}

		$columns = array(
			array(
				'0' => esc_html__( 'Video Title', 'wp-analytify-pro' ),
				'1' => esc_html__( 'Provider', 'wp-analytify-pro' ),
				'2' => esc_html__( 'Action', 'wp-analytify-pro' ),
				'3' => esc_html__( 'Duration (seconds)', 'wp-analytify-pro' ),
				'4' => esc_html__( 'Views', 'wp-analytify-pro' ),
			),
		);

		return array_merge( $columns, $stats );
	}

	/**
	 * Generates custom dimension dashboard (individual sections).
	 *
	 * @version 9.1.1
	 * @return list<array{label: mixed, views: mixed}|array{string, string}>|false
	 */
	private function export_custom_dimension_section() {

		// Get set dimensions from settings.
		$setting_dimensions = array();
		if ( $this->wp_analytify && is_object( $this->wp_analytify ) && isset( $this->wp_analytify->settings ) && method_exists( $this->wp_analytify->settings, 'get_option' ) ) {
			$setting_dimensions = $this->wp_analytify->settings->get_option( 'analytiy_custom_dimensions', 'wp-analytify-custom-dimensions' );
		}

		$set_dimensions = array();
		$stats          = array();

		foreach ( $setting_dimensions as $dimension ) {
			if ( isset( $dimension['id'] ) ) {
				$set_dimensions[ $dimension['id'] ] = $dimension['type'];
			} else {
				$set_dimensions[] = $dimension['type'];
			}
		}

		$dimensions = array(
			'custom-dimension-post_type'     => 'post_type',
			'custom-dimension-author'        => 'author',
			'custom-dimension-published_at'  => 'published_at',
			'custom-dimension-category'      => 'category',
			'custom-dimension-tags'          => 'tags',
			'custom-dimension-user_id'       => 'user_id',
			'custom-dimension-logged_in'     => 'logged_in',
			'custom-dimension-seo_score'     => 'seo_score',
			'custom-dimension-focus_keyword' => 'focus_keyword',
			'custom-dimension-archive_type'  => 'archive_type',
		);

		if ( empty( array_values( $set_dimensions ) ) || ! in_array( $dimensions[ $this->type ], $set_dimensions, true ) ) {
			return false;
		}

		$api_limit = analytify_pro_csv_api_limit( 'analytify_api_limit_custom_dimensions_' . $dimensions[ $this->type ] . '_stats', 10 );

		if ( 'ga4' === $this->ga_mode && class_exists( 'Analytify_Google_Dimensions' ) ) {
			$defined_dimensions = Analytify_Google_Dimensions::get_current_dimensions();
			$identifier         = isset( $defined_dimensions[ $dimensions[ $this->type ] ]['value'] ) ? $defined_dimensions[ $dimensions[ $this->type ] ]['value'] : '';

			$stats_raw = isset( $this->wp_analytify ) && method_exists( $this->wp_analytify, 'get_reports' ) ? $this->wp_analytify->get_reports(
				'show-sessions-dimensions-stats-' . $identifier,
				array(
					'sessions',
				),
				$this->get_dates(),
				array(
					'customEvent:' . $identifier,
				),
				array(
					'order' => 'desc',
					'type'  => 'metric',
					'name'  => 'sessions',
				),
				array(
					'logic'   => 'AND',
					'filters' => array(
						array(
							'type'           => 'dimension',
							'name'           => 'customEvent:' . $identifier,
							'match_type'     => 4,
							'value'          => '(not set)',
							'not_expression' => true,
						),
					),
				),
				$api_limit,
				false
			) : array();

			if ( isset( $stats_raw['rows'] ) && $stats_raw['rows'] ) {
				foreach ( $stats_raw['rows'] as $row ) {
					$stats[] = array(
						'label' => apply_filters( 'analytify_custom_dimension_row_label', $row[ 'customEvent:' . $identifier ], $dimensions[ $this->type ], 'csv_download' ),
						'views' => $row['sessions'],
					);
				}
			}
		}

		$columns = array(
			array(
				'0' => esc_html__( 'Label', 'wp-analytify-pro' ),
				'1' => esc_html__( 'Link', 'wp-analytify-pro' ),
			),
		);
		return array_merge( $columns, $stats );
	}

	/**
	 * Returns start and end date as an array to be used for GA4's get_reports()
	 *
	 * @return array<string, string>
	 */
	private function get_dates() {
		return array(
			'start' => $this->start_date,
			'end'   => $this->end_date,
		);
	}
}
