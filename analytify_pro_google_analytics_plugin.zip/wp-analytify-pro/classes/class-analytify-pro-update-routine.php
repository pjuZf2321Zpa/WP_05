<?php
/**
 * Analytify Pro Update Routine.
 *
 * @package WP_Analytify_Pro
 */

/**
 * Analytify Pro Update Routine class.
 *
 * Persists versioned migration steps; logs via {@see wp_analytify_pro_log_warning()}
 * and {@see wp_analytify_pro_log_error()} when migrations or option updates fail.
 */
class Analytify_Pro_Update_Routine {

	/**
	 * Current version.
	 *
	 * @var string
	 */
	private $current_verison = '';

	/**
	 * Private constructor for singleton class.
	 *
	 * @param string $current_verison Current version.
	 */
	public function __construct( $current_verison ) {

		$this->current_verison = $current_verison;
		$this->run_routines();
	}

	/**
	 * Run update routines.
	 *
	 * @since 9.0.0
	 * @return void
	 */
	public function run_routines() {

		if ( version_compare( $this->current_verison, '4.0.2', '<' ) ) {
			wp_analytify_pro_log_warning(
				'Running Analytify Pro update routine for version 4.0.2.',
				array(
					'source'          => 'Analytify_Pro_Update_Routine::run_routines',
					'current_version' => $this->current_verison,
				)
			);
			$this->update_routine_402();
		}

		update_option( 'analytify_pro_current_version', ANALYTIFY_PRO_VERSION );
		if ( get_option( 'analytify_pro_current_version' ) !== ANALYTIFY_PRO_VERSION ) {
			wp_analytify_pro_log_error(
				'Failed to persist analytify_pro_current_version after update routine.',
				array(
					'source'           => 'Analytify_Pro_Update_Routine::run_routines',
					'expected_version' => ANALYTIFY_PRO_VERSION,
				)
			);
		}
	}

	/**
	 * Update routine for version 4.0.2: activate all pro modules by default except AMP.
	 *
	 * @return void
	 */
	public function update_routine_402() {

		$wp_analytify_modules = get_option( 'wp_analytify_modules' );

		if ( ! $wp_analytify_modules ) {
			wp_analytify_pro_log_warning(
				'Update routine 4.0.2 skipped: wp_analytify_modules option missing.',
				array(
					'source' => 'Analytify_Pro_Update_Routine::update_routine_402',
				)
			);
			return;
		}

		foreach ( $wp_analytify_modules as &$module ) {
			if ( 'amp' !== $module['slug'] ) {
				$module['status'] = 'active';
			}
		}

		update_option( 'wp_analytify_modules', $wp_analytify_modules );
	}
}

// Get current plugin version.
$analytify_pro_current_version = get_option( 'analytify_pro_current_version', '4.0.1' );

// Call update routine if needed.
if ( version_compare( $analytify_pro_current_version, '4.0.2', '<' ) ) {
	new Analytify_Pro_Update_Routine( $analytify_pro_current_version );
}
