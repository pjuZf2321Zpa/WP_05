<?php // phpcs:ignore WordPress.Files.FileName.InvalidClassFileName -- Legacy file naming.
/**
 * WP Analytify Pro Shortcodes Manager Class
 *
 * This class handles shortcode registration and delegates to focused handlers where appropriate:
 * - World map shortcodes
 * - Statistics shortcodes (including GA stats)
 * - Video tracking shortcode (delegated to Analytify_Pro_Video_Tracking_Shortcode for performance)
 * - Shortcode button functionality and MCE editor integration
 *
 * @package WP_Analytify_Pro
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_Analytify_Pro_Shortcodes_Manager' ) ) {

	/**
	 * WP Analytify Pro Shortcodes Manager class.
	 */
	class WP_Analytify_Pro_Shortcodes_Manager {

		/**
		 * Reference to the main WP_Analytify_Pro class
		 *
		 * @var WP_Analytify_Pro
		 */
		private $parent;

		/**
		 * Video tracking shortcode handler (loaded only when shortcode is used).
		 *
		 * @var Analytify_Pro_Video_Tracking_Shortcode
		 */
		private $video_tracking_shortcode;

		/**
		 * Constructor
		 *
		 * @version 7.0.5
		 * @param WP_Analytify_Pro $parent Reference to the main class.
		 */
		public function __construct( $parent ) { // phpcs:ignore Universal.NamingConventions.NoReservedKeywordParameterNames.parentFound
			$this->parent                   = $parent;
			$this->video_tracking_shortcode = new Analytify_Pro_Video_Tracking_Shortcode( $parent );
		}

		/**
		 * Core Analytify instance (GA4 get_reports lives on WP_Analytify, not WP_Analytify_Pro).
		 *
		 * @since 9.1.0
		 * @return WP_Analytify|null
		 */
		private function get_wp_analytify() {
			return ( isset( $GLOBALS['WP_ANALYTIFY'] ) && is_object( $GLOBALS['WP_ANALYTIFY'] ) ) ? $GLOBALS['WP_ANALYTIFY'] : null;
		}

		/**
		 * World map shortcode
		 *
		 * @version 7.0.5
		 * @param array<string, mixed> $atts Shortcode attributes.
		 * @return string
		 */
		public function analytify_worldmap_shortcode( $atts ) {
			if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {
				return $this->analytify_ga_worldmap_shortcode_create( $atts );
			}

			return $this->analytify_worldmap_shortcode_create( $atts );
		}

		/**
		 * GA4 world map shortcode output.
		 *
		 * @since 7.0.0
		 * @version 9.1.0
		 * @param array<string, mixed> $atts Shortcode attributes.
		 * @return string
		 */
		public function analytify_ga_worldmap_shortcode_create( $atts ) {
			global $post;

			$content = '';

			$default_start = '2018-01-01';
			if ( isset( $post ) && is_object( $post ) && isset( $post->ID ) ) {
				$post_year = (int) get_the_time( 'Y', $post->ID );
				if ( $post_year >= 2005 ) {
					$default_start = get_the_time( 'Y-m-d', $post->ID );
				}
			}

			$atts = shortcode_atts(
				array(
					'start_date'    => $default_start,
					'end_date'      => gmdate( 'Y-m-d' ),
					'analytics_for' => 'page_id',
					'page_id'       => '',
				),
				$atts
			);

			$page_id = ! empty( $atts['page_id'] ) ? absint( $atts['page_id'] ) : ( isset( $post ) && is_object( $post ) && isset( $post->ID ) ? absint( $post->ID ) : 0 );

			$transient_name = 'analytify_worldmap_v2_' . md5( $atts['analytics_for'] . '_' . $atts['start_date'] . '_' . $atts['end_date'] . '_' . $page_id );

			$permalink = ( 'page_id' === $atts['analytics_for'] && ! empty( $page_id ) ) ? get_permalink( $page_id ) : get_site_url();

			if ( 'page_id' === $atts['analytics_for'] && empty( $permalink ) ) {
				return esc_html__( 'Error: Invalid page_id or page does not exist.', 'wp-analytify-pro' );
			}

			$filters = array(
				'logic'   => 'AND',
				'filters' => array(
					array(
						'type'           => 'dimension',
						'name'           => 'country',
						'match_type'     => 4,
						'value'          => '(not set)',
						'not_expression' => true,
					),
				),
			);

			if ( 'page_id' === $atts['analytics_for'] && ! empty( $page_id ) ) {
				$parsed_url = wp_parse_url( $permalink );
				$page_path  = isset( $parsed_url['path'] ) ? trailingslashit( $parsed_url['path'] ) : '/';

				$filters['filters'][] = array(
					'type'       => 'dimension',
					'name'       => 'pagePathPlusQueryString',
					'match_type' => 1,
					'value'      => $page_path,
				);
			} elseif ( 'current' === $atts['analytics_for'] && isset( $post ) && is_object( $post ) && isset( $post->ID ) ) {
				$parsed_url = wp_parse_url( get_permalink( $post->ID ) );
				$page_path  = isset( $parsed_url['path'] ) ? $parsed_url['path'] : '';

				if ( '' !== $page_path ) {
					$filters['filters'][] = array(
						'type'       => 'dimension',
						'name'       => 'pagePath',
						'match_type' => 1,
						'value'      => $page_path,
					);
				}
			}

			$worldmap_stats = get_transient( $transient_name );

			$wp_analytify = $this->get_wp_analytify();

			if ( ! $worldmap_stats && $wp_analytify && method_exists( $wp_analytify, 'get_reports' ) ) {
				$worldmap_stats = $wp_analytify->get_reports(
					'show-worldmap-front',
					array( 'sessions' ),
					array(
						'start' => $atts['start_date'],
						'end'   => $atts['end_date'],
					),
					array( 'country' ),
					array(
						'type' => 'metric',
						'name' => 'sessions',
					),
					$filters,
					250,
					false
				);

				if ( ! empty( $worldmap_stats['rows'] ) ) {
					set_transient( $transient_name, $worldmap_stats, DAY_IN_SECONDS );
				}
			}

			if ( ! is_array( $worldmap_stats ) || ! isset( $worldmap_stats['rows'] ) ) {
				$worldmap_stats = array(
					'headers' => array(),
					'rows'    => array(),
					'error'   => array(),
				);
			}

			if ( ! empty( $worldmap_stats['error'] ) ) {
				$error_message = '';
				if ( isset( $worldmap_stats['error']['message'] ) ) {
					$decoded       = json_decode( $worldmap_stats['error']['message'] );
					$error_message = ( is_object( $decoded ) && isset( $decoded->message ) ) ? $decoded->message : $worldmap_stats['error']['message'];
				}

				if ( current_user_can( 'manage_options' ) ) {
					return sprintf(
					/* translators: %s: API error message */
						esc_html__( 'Analytify Shortcode Exception: %s. You might be using GA3 metrics or dimensions with GA4. This message is only visible to admin.', 'wp-analytify-pro' ),
						esc_html( $error_message )
					);
				}

				return '';
			}

			if ( empty( $worldmap_stats['rows'] ) ) {
				if ( current_user_can( 'manage_options' ) ) {
					$message = esc_html__( 'Analytify Shortcode Notice: No data available for the specified criteria. This message is only visible to admin.', 'wp-analytify-pro' );
					return apply_filters( 'analytify_custom_shortcode_message', $message );
				}

				return '';
			}

			if ( ! empty( $worldmap_stats['rows'] ) && defined( 'ANALYTIFY_PRO_ROOT_PATH' ) ) {
				ob_start();
				include_once ANALYTIFY_PRO_ROOT_PATH . '/views/old/front/world-map-stats.php';
				pa_include_worldmap( $this, $worldmap_stats );
				$content .= ob_get_clean();
			}

			return $content;
		}

		/**
		 * Universal Analytics (GA3) world map shortcode output.
		 *
		 * @param array<string, mixed> $atts Shortcode attributes.
		 * @return string
		 */
		public function analytify_worldmap_shortcode_create( $atts ) {
			global $post;

			$content = '';

			if ( ! isset( $post ) || ! is_object( $post ) || ! isset( $post->ID ) || (int) get_the_time( 'Y', $post->ID ) < 2005 ) {
				$default_start_date = '2005-01-01';
			} else {
				$default_start_date = get_the_time( 'Y-m-d', $post->ID );
			}

			$atts = shortcode_atts(
				array(
					'start_date'    => $default_start_date,
					'end_date'      => gmdate( 'Y-m-d' ),
					'analytics_for' => 'current',
				),
				$atts
			);

			$filter = false;
			if ( 'current' === $atts['analytics_for'] && isset( $post ) && is_object( $post ) && isset( $post->ID ) ) {
				$u_post = wp_parse_url( get_permalink( $post->ID ) );
				if ( ! empty( $u_post['path'] ) ) {
					$filter = 'ga:pagePath==' . $u_post['path'];
				}
			}

			$wp_analytify = $this->get_wp_analytify();

			if ( ! $wp_analytify || ! method_exists( $wp_analytify, 'get_reports' ) ) {
				return $content;
			}

			$worldmap_stats = $wp_analytify->get_reports(
				'show-worldmap-front',
				array( 'ga:sessions' ),
				array(
					'start' => $atts['start_date'],
					'end'   => $atts['end_date'],
				),
				array( 'ga:country' ),
				array(
					'type' => 'metric',
					'name' => 'ga:sessions',
				),
				$filter,
				250,
				false
			);

			if ( ! empty( $worldmap_stats['rows'] ) && defined( 'ANALYTIFY_PRO_ROOT_PATH' ) ) {
				ob_start();
				include_once ANALYTIFY_PRO_ROOT_PATH . '/views/old/front/world-map-stats.php';
				pa_include_worldmap( $this, $worldmap_stats );
				$content .= ob_get_clean();
			}

			return $content;
		}

		/**
		 * Statistics shortcode
		 *
		 * @param array<string, mixed> $atts Shortcode attributes.
		 * @param string|null          $content Shortcode content.
		 * @return string
		 */
		public function analytify_stats_shortcode( $atts, $content = null ) {
			if ( class_exists( 'WPANALYTIFY_Utils' ) && method_exists( 'WPANALYTIFY_Utils', 'get_ga_mode' ) && 'ga4' === WPANALYTIFY_Utils::get_ga_mode() ) {
				return $this->analytify_ga_stats_shortcode_create( $atts, $content );
			}

			$atts = shortcode_atts(
				array(
					'profile'    => '',
					'start_date' => '',
					'end_date'   => '',
					'type'       => 'general',
				),
				$atts
			);

			// Get profile ID.
			$profile_id = $atts['profile'];
			if ( empty( $profile_id ) ) {
				$profile_id = '';
				if ( $this->parent && is_object( $this->parent ) && isset( $this->parent->settings ) && method_exists( $this->parent->settings, 'get_option' ) ) {
					$profile_id = $this->parent->settings->get_option( 'profile_for_dashboard', 'wp-analytify-profile' );
				}
			}

			// Get dates.
			$start_date = $atts['start_date'];
			$end_date   = $atts['end_date'];
			if ( empty( $start_date ) || empty( $end_date ) ) {
				if ( function_exists( 'analytify_datepicker_dates' ) ) {
					$dates      = analytify_datepicker_dates();
					$start_date = isset( $dates['start_date'] ) ? $dates['start_date'] : gmdate( 'Y-m-d', strtotime( '-1 month' ) );
					$end_date   = isset( $dates['end_date'] ) ? $dates['end_date'] : gmdate( 'Y-m-d', strtotime( 'now' ) );
				} else {
					$start_date = gmdate( 'Y-m-d', strtotime( '-1 month' ) );
					$end_date   = gmdate( 'Y-m-d', strtotime( 'now' ) );
				}
			}

			$output  = '<div class="analytify_stats_shortcode" data-profile="' . esc_attr( $profile_id ) . '" data-start="' . esc_attr( $start_date ) . '" data-end="' . esc_attr( $end_date ) . '" data-type="' . esc_attr( $atts['type'] ) . '">';
			$output .= '<div class="analytify_loading">Loading statistics...</div>';
			$output .= '</div>';

			return $output;
		}

		/**
		 * Shortcode view
		 *
		 * @since 1.0.0
		 *
		 * @return void
		 */
		public function analytify_shortcode_view() {
			// Add shortcode button to editor.
			add_action( 'admin_footer', array( $this, 'analytify_shortcode_button' ) );

			// Add MCE CSS.
			add_filter( 'mce_css', array( $this, 'analytify_mce_css' ) );
		}

		/**
		 * Get shortcode front analytics
		 *
		 * @param string $post_id Post ID.
		 * @return string
		 */
		public function get_shortcode_front_analytics( $post_id = '' ) {
			if ( empty( $post_id ) ) {
				$post_id = get_the_ID();
			}

			// Check if analytics should be shown for this post.
			if ( ! is_object( $this->parent ) || ! isset( $this->parent->settings ) || ! method_exists( $this->parent->settings, 'get_option' ) || ! $this->parent->settings->get_option( 'show_analytics_posts_front_end', 'wp-analytify-front' ) ) {
				return '';
			}

			// Get post type.
			$post_type  = get_post_type( (int) $post_id );
			$post_types = array();
			if ( is_object( $this->parent ) && isset( $this->parent->settings ) && method_exists( $this->parent->settings, 'get_option' ) ) {
				$post_types = $this->parent->settings->get_option( 'show_analytics_post_types_front_end', 'wp-analytify-front' );
			}

			if ( ! is_array( $post_types ) || ! in_array( $post_type, $post_types, true ) ) {
				return '';
			}

			// Get analytics data.
			$output  = '<div class="analytify_front_analytics" data-post-id="' . esc_attr( (string) $post_id ) . '">';
			$output .= '<h3>' . __( 'Analytics', 'wp-analytify-pro' ) . '</h3>';
			$output .= '<div class="analytify_loading">Loading analytics...</div>';
			$output .= '</div>';

			return $output;
		}

		/**
		 * Add a link to the settings page to the plugins list
		 *
		 * @since 2.0
		 * @param array<int|string, string> $links Plugin action links.
		 * @return array<int|string, string>
		 */
		public function plugin_action_links( $links ) {
			$settings_link = '<a href="' . admin_url( 'admin.php?page=analytify-settings' ) . '">' . __( 'Settings', 'wp-analytify-pro' ) . '</a>';
			array_unshift( $links, $settings_link );
			return $links;
		}

		/**
		 * Shortcode button
		 *
		 * @since 1.0.0
		 *
		 * @return void
		 */
		public function analytify_shortcode_button() {
			if ( ! current_user_can( 'edit_posts' ) && ! current_user_can( 'edit_pages' ) ) {
				return;
			}

			$wp_analytify    = $GLOBALS['WP_ANALYTIFY'];
			$is_access_level = $wp_analytify->settings->get_option( 'show_analytics_roles_dashboard', 'wp-analytify-dashboard', array( 'Administrator' ) );
			// Return, if not have dashboard access.
			if ( ! $wp_analytify->pa_check_roles( $is_access_level ) ) {
				return;
			}

			if ( 'true' === get_user_option( 'rich_editing' ) ) {
				add_filter( 'mce_external_plugins', array( $this, 'analytify_stats_js' ) );
				add_filter( 'mce_buttons', array( $this, 'register_analytify_button' ) );
			}
		}

		/**
		 * Add shortcode JavaScript
		 *
		 * @param array<string, mixed> $plugin_array Plugin array.
		 * @return array<string, mixed>
		 */
		public function analytify_stats_js( $plugin_array ) {
			$plugin_array['analytifystats'] = plugins_url( 'assets/js/shortcode' . analytify_pro_get_asset_suffix() . '.js', __DIR__ );
			return $plugin_array;
		}

		/**
		 * Register shortcode button
		 *
		 * @param array<int|string, string> $buttons Buttons array.
		 * @return array<int|string, string>
		 */
		public function register_analytify_button( $buttons ) {
			array_push( $buttons, '|', 'analytifystats' );
			return $buttons;
		}

		/**
		 * MCE Plugin
		 *
		 * @param array<string, mixed> $plugin_array Plugin array.
		 * @return array<string, mixed>
		 */
		public function analytify_mce_plugin( $plugin_array ) {
			$plugin_array['analytify_shortcode'] = plugins_url( 'assets/js/analytify-shortcode-button.js', __DIR__ );
			return $plugin_array;
		}

		/**
		 * MCE Button
		 *
		 * @param array<int|string, string> $buttons Buttons array.
		 * @return array<int|string, string>
		 */
		public function analytify_mce_button( $buttons ) {
			array_push( $buttons, 'analytify_shortcode' );
			return $buttons;
		}

		/**
		 * MCE CSS
		 *
		 * @param string $mce_css MCE CSS.
		 * @return string
		 */
		public function analytify_mce_css( $mce_css ) {
			if ( ! empty( $mce_css ) ) {
				$mce_css .= ',';
			}
			$mce_css .= plugins_url( 'assets/css/wp-analytify-editor' . analytify_pro_get_asset_suffix() . '.css', __DIR__ );
			return $mce_css;
		}

		/**
		 * GA Stats Shortcode Create
		 *
		 * @since 1.0.0
		 * @version 9.1.0
		 * @param array<string, mixed> $atts Shortcode attributes.
		 * @param string|null          $content Shortcode content.
		 * @return string
		 */
		private function analytify_ga_stats_shortcode_create( $atts, $content ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed
			// Google Analytics release date as default.
			$default_start_date = '2005-01-01';
			global $post;
			$wp_analytify = $GLOBALS['WP_ANALYTIFY'];

			$return = '';

			if ( isset( $post ) && is_object( $post ) && isset( $post->ID ) ) {
				$default_start_date = get_the_time( 'Y-m-d', $post->ID );
			}

			$shortcode_defaults = shortcode_atts(
				array(
					'metrics'               => 'sessions',
					'dimensions'            => '',
					'start_date'            => $default_start_date,
					'end_date'              => gmdate( 'Y-m-d' ),
					'sort'                  => '',
					'max_results'           => 6,
					'analytics_for'         => '',
					'custom_page_id'        => 0,
					'date_type'             => 'custom',
					'permission_view'       => '',
					'front'                 => '',
					'table_head_color'      => '#DBDBDB',
					'table_head_text_color' => '#000000',
					'table_font_size'       => '14px',
					'table_layout'          => 'auto',
				),
				$atts
			);

			$metrics               = $shortcode_defaults['metrics'];
			$dimensions            = $shortcode_defaults['dimensions'];
			$start_date            = $shortcode_defaults['start_date'];
			$end_date              = $shortcode_defaults['end_date'];
			$sort                  = $shortcode_defaults['sort'];
			$max_results           = $shortcode_defaults['max_results'];
			$analytics_for         = $shortcode_defaults['analytics_for'];
			$custom_page_id        = $shortcode_defaults['custom_page_id'];
			$date_type             = $shortcode_defaults['date_type'];
			$permission_view       = $shortcode_defaults['permission_view'];
			$front                 = $shortcode_defaults['front'];
			$table_head_color      = $shortcode_defaults['table_head_color'];
			$table_head_text_color = $shortcode_defaults['table_head_text_color'];
			$table_font_size       = $shortcode_defaults['table_font_size'];
			$table_layout          = $shortcode_defaults['table_layout'];

			// ShortCode to show All stats at frontend [analytify-stats front='all'].
			if ( 'all' === $front ) {
				return is_object( $this->parent ) && method_exists( $this->parent, 'get_shortcode_front_analytics' ) ? $this->parent->get_shortcode_front_analytics( $custom_page_id ) : '';
			}

			/**
			 * Handing ShortCode custom dates.
			 */
			if ( 'custom' !== $date_type ) {

				if ( 'today' === $date_type ) { // Today.
					$start_date = wp_date( 'Y-m-d' );
				}

				if ( 'year-to-date' === $date_type ) { // Year to date.
					$start_date = wp_date( 'Y-m-d', (int) strtotime( gmdate( 'Y' ) . '-01-01' ) );
					$end_date   = wp_date( 'Y-m-d' );
				}

				if ( '- 7 days' === $date_type ) { // Last week.
					$start_date = wp_date( 'Y-m-d', (int) strtotime( $date_type ) );
				}

				if ( '- 15 days' === $date_type ) { // Last 15 days.
					$start_date = wp_date( 'Y-m-d', (int) strtotime( $date_type ) );
				}

				if ( '- 30 days' === $date_type ) { // Last 30 days.
					$start_date = wp_date( 'Y-m-d', (int) strtotime( $date_type ) );
				}

				if ( 'year-to-date' === $date_type ) { // This year.
					$start_date = wp_date( 'Y-01-01' );
				}

				if ( '- 365 days' === $date_type ) { // Last Year.
					$start_date = wp_date( 'Y-m-d', (int) strtotime( $date_type ) );
				}

				if ( '- 1 days' === $date_type ) { // Yesterday.
					$start_date = wp_date( 'Y-m-d', (int) strtotime( $date_type ) );
					$end_date   = wp_date( 'Y-m-d', (int) strtotime( $date_type ) );
				}
			}
			if ( isset( $atts['dimensions'] ) && false !== strpos( $atts['dimensions'], 'socialNetwork' ) ) {
				$dimensions = str_replace( 'socialNetwork', 'sessionSource', $dimensions );
			}
			$filters = array();
			$u_post  = array();
			if ( 'current' === $analytics_for ) {
				global $wp;
				// Default is homepage link as fallback.
				$permalink = get_site_url();
				// Change permalink based on current page.
				if ( is_archive() ) {
					$permalink = get_site_url() . '/' . ( isset( $wp->request ) ? $wp->request : '' );
				} elseif ( isset( $post ) && is_object( $post ) && isset( $post->ID ) ) {
					$permalink = get_permalink( $post->ID );
				}
				// Parse URL.
				$u_post = $permalink ? wp_parse_url( (string) $permalink ) : false;

				// If path not found in parsed array, grab from wp object.
				global $wp;
				$url_path = isset( $u_post['path'] ) ? $u_post['path'] : ( isset( $wp->request ) ? $wp->request : '' );

				$filters = array(
					'logic'   => 'AND',
					'filters' => array(
						array(
							'type'       => 'dimension',
							'name'       => 'pagePath',
							'match_type' => 1,
							'value'      => $url_path,
						),
					),
				);
				if ( false !== strpos( $dimensions, 'sessionSource' ) ) {
					$filters['filters'][] = array(
						'type'       => 'dimension',
						'name'       => 'sessionSource',
						'match_type' => 5,
						'value'      => '^([a-z-]*\.|)(facebook|reddit|youtube|tumblr|quora|instagram|linkedin|yelp|wordpress|pinterest|twitter|t)(\.(com|org|co|)|)$',
					);
				}
			} elseif ( 'page_id' === $analytics_for ) {
				$permalink = get_permalink( (int) $custom_page_id );
				$u_post    = $permalink ? wp_parse_url( (string) $permalink ) : false;

				// If path not found in parsed array, grab from wp object.
				global $wp;
				$url_path = isset( $u_post['path'] ) ? $u_post['path'] : ( isset( $wp->request ) ? $wp->request : '' );

				// Page path filter for site that use domain mapping.
				$filters = array(
					'logic'   => 'AND',
					'filters' => array(
						array(
							'type'       => 'dimension',
							'name'       => 'pagePath',
							'match_type' => 1,
							'value'      => $url_path,
						),
					),
				);
				if ( false !== strpos( $dimensions, 'sessionSource' ) ) {
					$filters['filters'][] = array(
						'type'       => 'dimension',
						'name'       => 'sessionSource',
						'match_type' => 5,
						'value'      => '^([a-z-]*\.|)(facebook|reddit|youtube|tumblr|quora|instagram|linkedin|yelp|wordpress|pinterest|twitter|t)(\.(com|org|co|)|)$',
					);
				}
			}
			if ( 'full' === $analytics_for && false !== strpos( $dimensions, 'sessionSource' ) ) {
				// Add the filter.
				$filters = array(
					'logic'   => 'AND',
					'filters' => array(
						array(
							'type'       => 'dimension',
							'name'       => 'sessionSource',
							'match_type' => 5,
							'value'      => '^([a-z-]*\.|)(facebook|reddit|youtube|tumblr|quora|instagram|linkedin|yelp|wordpress|pinterest|twitter|t)(\.(com|org|co|)|)$',
						),
					),
				);
			}
			$filters = apply_filters( 'analytify_page_path_filter', $filters, $u_post );

			$all_metrics    = explode( ',', $metrics );
			$all_dimensions = ! empty( $dimensions ) ? explode( ',', $dimensions ) : array();
			$sort           = ! empty( $sort ) ? $sort : $all_metrics[0];

			$sort_by = array();
			if ( $all_dimensions ) {
				$sort_by['name']  = $sort;
				$sort_by['order'] = 'desc';

				if ( in_array( $sort, $all_dimensions, true ) ) {
					$sort_by['type'] = 'dimension';
				} elseif ( in_array( $sort, $all_metrics, true ) ) {
					$sort_by['type'] = 'metric';
				}
			}

			if ( 'current' === $analytics_for ) {
				$all_dimensions[] = 'pagePath';
			}

			// If post year is less than 2005, make it to start from 2005.
			$start_timestamp = strtotime( (string) $start_date );
			if ( $start_timestamp && gmdate( 'Y', (int) $start_timestamp ) < 2005 ) {
				$start_date = '2005-01-01';
			}
			/**
			*  Making transient string for cache.
			*/

			$transient_name = $metrics . '_' . $dimensions . '_' . $date_type . '_' . $start_date . '_' . $end_date . '_' . $sort . '_' . $max_results . '_' . $analytics_for . '_' . $permission_view . '_' . $custom_page_id . '_' . ( isset( $post ) && is_object( $post ) && isset( $post->ID ) ? $post->ID : 0 );

			$stats = get_transient( md5( $transient_name ) );

			if ( ! $stats ) {
				$stats = isset( $wp_analytify ) && is_object( $wp_analytify ) && method_exists( $wp_analytify, 'get_reports' ) ? $wp_analytify->get_reports(
					'single',
					$all_metrics,
					array(
						'start' => $start_date,
						'end'   => $end_date,
					),
					$all_dimensions,
					$sort_by,
					$filters,
					$max_results,
					false
				) : array();

				if ( ! empty( $stats['error'] ) ) {
					$error_data    = json_decode( $stats['error']['message'], true );
					$error_message = isset( $error_data['message'] ) ? $error_data['message'] : ( isset( $stats['error']['message'] ) ? $stats['error']['message'] : __( 'Unknown API error.', 'wp-analytify-pro' ) );

					if ( current_user_can( 'manage_options' ) ) {
						$message = sprintf(
							/* translators: %s: error message from API */
							esc_html__( 'Analytify Shortcode Error: %s. (Visible to admins only)', 'wp-analytify-pro' ),
							esc_html( $error_message )
						);
						return apply_filters( 'analytify_custom_shortcode_message', $message );
					}

					return '';
				}

				// Two hour cache.
				set_transient( md5( $transient_name ), $stats, 60 * 60 * 2 );
			} elseif ( ! empty( $stats['error'] ) ) {
				if ( current_user_can( 'manage_options' ) ) {
					$error_message = '';
					if ( isset( $stats['error']['message'] ) ) {
						$decoded       = json_decode( $stats['error']['message'] );
						$error_message = ( is_object( $decoded ) && isset( $decoded->message ) ) ? $decoded->message : $stats['error']['message'];
					}

					$message = sprintf(
					/* translators: %s: API error message */
						__( 'Analytify Shortcode Exception: %s. You might be using GA3 metrics or dimensions with GA4. This message is only visible to admin.', 'wp-analytify-pro' ),
						esc_html( $error_message )
					);
					return apply_filters( 'analytify_custom_shortcode_message', $message );
				}

				return '';
			}

			$current_user = wp_get_current_user();
			$current_role = ( 0 === $current_user->ID ) ? 'everyone' : ( isset( $current_user->roles[0] ) ? $current_user->roles[0] : '' );
			$role_to_show = explode( ',', $permission_view );

			// Check permissions.
			if ( '' !== $permission_view && ! in_array( $current_role, $role_to_show, true ) ) {
				return '';
			}

			if ( ! empty( $stats['rows'] ) ) {
				if ( empty( $dimensions ) ) {
					foreach ( $stats['aggregations'] as $value ) {
						$return .= is_numeric( $value ) ? number_format( (float) $value ) : $value;
					}
				} else {
					// Sanitize styles.
					$table_head_color      = sanitize_hex_color( $table_head_color );
					$table_head_text_color = sanitize_hex_color( $table_head_text_color );
					$table_font_size       = sanitize_text_field( $table_font_size );
					$table_layout          = sanitize_key( $table_layout );

					if ( empty( $table_head_color ) ) {
						$table_head_color = '#DBDBDB';
					}
					if ( empty( $table_head_text_color ) ) {
						$table_head_text_color = '#000000';
					}

					// `responsive` is not a valid CSS table-layout value — use a scroll wrapper instead.
					$is_responsive    = ( 'responsive' === $table_layout );
					$css_table_layout = in_array( $table_layout, array( 'fixed', 'auto' ), true ) ? $table_layout : 'auto';
					$wrapper_class    = $is_responsive ? 'shortcode-table shortcode-table--responsive' : 'shortcode-table';

					// Inline critical styles so theme CSS / caching cannot squash columns on mobile.
					if ( $is_responsive ) {
						$wrapper_style_attr = ' style="display:block;width:100%;max-width:100%;overflow-x:auto;-webkit-overflow-scrolling:touch;"';
						$table_style_attr   = sprintf(
							'style="table-layout:auto;font-size:%s;width:auto;min-width:100%%;border-collapse:collapse;"',
							esc_attr( $table_font_size )
						);
					} else {
						$wrapper_style_attr = '';
						$table_style_attr   = sprintf(
							'style="table-layout:%s;font-size:%s;width:100%%;"',
							esc_attr( $css_table_layout ),
							esc_attr( $table_font_size )
						);
					}

					$return .= sprintf(
						'<div class="%s"%s><table %s>',
						esc_attr( $wrapper_class ),
						$wrapper_style_attr, // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from fixed safe attributes above.
						$table_style_attr
					);

					foreach ( $stats['headers'] as $header ) {
						$header_label = ( 'sessionSource' === $header ? 'Social Networks' : $header );
						$th_extra     = $is_responsive ? ' white-space:nowrap;word-break:normal;' : '';
						$th_style     = sprintf(
							'style="background-color: %s; color: %s;%s"',
							esc_attr( $table_head_color ),
							esc_attr( $table_head_text_color ),
							$th_extra
						);
						$return      .= sprintf( '<th %s>%s</th> ', $th_style, esc_html( $header_label ) );
					}

					foreach ( $stats['rows'] as $stats_values ) {
						$return      .= '<tr>';
						$stats_values = array_values( $stats_values );

						foreach ( $stats_values as $value ) {
							$td_attr = $is_responsive ? ' style="white-space:nowrap;word-break:normal;"' : '';
							$cell    = is_numeric( $value ) ? number_format( (float) $value ) : esc_html( $value );
							$return .= sprintf( '<td%s>%s</td>', $td_attr, $cell );
						}

						$return .= '</tr>';
					}

					$return .= '</table></div>';
				}
			} else {
				$message = esc_html__( 'No activity found during this period.', 'wp-analytify-pro' );
				return apply_filters( 'analytify_custom_shortcode_message', $message );
			}

			return $return;
		}

		/**
		 * Video tracking shortcode. Delegates to dedicated handler for performance and maintainability.
		 *
		 * @since 9.0.0
		 * @param array<string, mixed> $atts Shortcode attributes (start_date, end_date, max_results, etc.).
		 * @return string
		 */
		public function analytify_video_tracking_shortcode( $atts ) {
			return $this->video_tracking_shortcode->render( $atts );
		}
	}
}
