<?php
/**
 * Handle Analytify REST end points
 *
 * @package WP_Analytify_Pro
 * @since 8.0.0
 */

/**
 * Analytify Pro REST API Class.
 *
 * @since 1.0.0
 */
class Analytify_Pro_Rest_API {

	/**
	 * The single instance of the class.
	 *
	 * @var Analytify_Pro_Rest_API|null
	 */
	private static $instance;

	/**
	 * REST Core instance.
	 *
	 * @var WP_Analytify_Pro_REST_Core|null $rest_core
	 * @since 1.0.0
	 */
	private $rest_core;

	/**
	 * REST Reports instance.
	 *
	 * @var WP_Analytify_Pro_REST_Reports $rest_reports
	 * @since 1.0.0
	 */
	private $rest_reports;

	/**
	 * REST Tracking instance.
	 *
	 * @var WP_Analytify_Pro_REST_Tracking $rest_tracking
	 * @since 1.0.0
	 */
	private $rest_tracking;

	/**
	 * REST Demographics instance.
	 *
	 * @var WP_Analytify_Pro_REST_Demographics $rest_demographics
	 * @since 1.0.0
	 */
	private $rest_demographics;

	/**
	 * REST Advanced instance.
	 *
	 * @var WP_Analytify_Pro_REST_Advanced $rest_advanced
	 * @since 1.0.0
	 */
	private $rest_advanced;

	/**
	 * REST Search instance.
	 *
	 * @var WP_Analytify_Pro_REST_Search $rest_search
	 * @since 1.0.0
	 */
	private $rest_search;
	/**
	 * Returns the single instance of the class.
	 *
	 * @version 7.0.5
	 * @return object Class instance
	 */
	public static function get_instance() {
		if ( empty( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Class constructor.
	 *
	 * @version 7.0.5
	 * @return void
	 */
	private function __construct() {
		$this->init_rest_classes();
		$this->hooks();
	}

		/**
		 * Initialize REST API classes
		 *
		 * @since 1.0.0
		 * @return void
		 */
	private function init_rest_classes() {
		$classes_path = defined( 'ANALYTIFY_PRO_CLASSES_PATH' ) ? ANALYTIFY_PRO_CLASSES_PATH : WP_PLUGIN_DIR . '/wp-analytify-pro/classes/';
		$files        = array(
			'class-analytify-pro-rest-core.php',
			'class-analytify-pro-rest-reports.php',
			'class-analytify-pro-rest-tracking.php',
			'class-analytify-pro-rest-demographics.php',
			'class-analytify-pro-rest-advanced.php',
			'class-analytify-pro-rest-search.php',
		);

		foreach ( $files as $file ) {
			$path = $classes_path . $file;
			if ( file_exists( $path ) ) {
				require_once $path;
			}
		}

		$this->rest_core         = class_exists( 'WP_Analytify_Pro_REST_Core' ) ? ( WP_Analytify_Pro_REST_Core::instance() instanceof WP_Analytify_Pro_REST_Core ? WP_Analytify_Pro_REST_Core::instance() : null ) : null;
		$this->rest_reports      = WP_Analytify_Pro_REST_Reports::instance();
		$this->rest_tracking     = WP_Analytify_Pro_REST_Tracking::instance();
		$this->rest_demographics = WP_Analytify_Pro_REST_Demographics::instance();
		$this->rest_advanced     = WP_Analytify_Pro_REST_Advanced::instance();
		$this->rest_search       = WP_Analytify_Pro_REST_Search::instance();
	}

	/**
	 * Run action and filter hooks
	 *
	 * @access private
	 * @since 1.0.0
	 * @return void
	 */
	private function hooks() {
		add_action( 'rest_api_init', array( $this, 'rest_api_init' ) );
		add_action( 'analytify_add_submenu', array( $this, 'add_menu_option' ), 65 );
		add_filter( 'analytify_custom_dimension_row_label', array( $this, 'filter_custom_dimension_row_label' ), 10, 2 );
	}

	/**
	 * Register end point.
	 *
	 * @return void
	 */
	public function rest_api_init() {
		// Initialize the core class first.
		if ( $this->rest_core ) {
			$this->rest_core->rest_api_init();
		}

		// Register the REST route.
		register_rest_route(
			'wp-analytify/v1',
			'/get_pro_report/(?P<request_type>[a-zA-Z0-9-]+)',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'handle_request' ),
					'permission_callback' => array( $this, 'permission_check' ),
				),
			)
		);
	}

	/**
	 * Checks access permission.
	 * Checks if the user is logged-in and checks of the user role has access.
	 *
	 * @return boolean
	 */
	public function permission_check() {
		return $this->rest_core ? $this->rest_core->permission_check() : false;
	}

	/**
	 * Handles the request.
	 *
	 * @param WP_REST_Request $request WP REST request object.
	 *
	 * @return array<string, mixed>|WP_Error
	 */
	public function handle_request( WP_REST_Request $request ) {

		$request_type = $request->get_param( 'request_type' );

		// Get wp_analytify and ga_mode from the core class.
		$wp_analytify = $this->rest_core ? $this->rest_core->get_wp_analytify() : null;
		$ga_mode      = $this->rest_core ? $this->rest_core->get_ga_mode() : null;

		// Set dates for all handlers with wp_analytify and ga_mode.
		$this->rest_reports->set_dates(
			$request->get_param( 'sd' ),
			$request->get_param( 'ed' ),
			$request->get_param( 'd_diff' ),
			$request->get_param( 'type' ),
			$wp_analytify,
			$ga_mode
		);

		$this->rest_tracking->set_dates(
			$request->get_param( 'sd' ),
			$request->get_param( 'ed' ),
			$request->get_param( 'd_diff' ),
			$request->get_param( 'type' ),
			$wp_analytify,
			$ga_mode
		);

		$this->rest_demographics->set_dates(
			$request->get_param( 'sd' ),
			$request->get_param( 'ed' ),
			$request->get_param( 'd_diff' ),
			$request->get_param( 'type' ),
			$wp_analytify,
			$ga_mode
		);

		$this->rest_advanced->set_dates(
			$request->get_param( 'sd' ),
			$request->get_param( 'ed' ),
			$request->get_param( 'd_diff' ),
			$request->get_param( 'type' ),
			$wp_analytify,
			$ga_mode
		);

		$this->rest_search->set_dates(
			$request->get_param( 'sd' ),
			$request->get_param( 'ed' ),
			$request->get_param( 'd_diff' ),
			$request->get_param( 'type' ),
			$wp_analytify,
			$ga_mode
		);

		switch ( $request_type ) {
			case 'ajax-error':
				$result = $this->rest_reports->ajax_error();
				return $result ?? new WP_Error( 'analytify_error', __( 'Failed to get AJAX error data.', 'wp-analytify-pro' ), array( 'status' => 500 ) );
			case '404-error':
				$result = $this->rest_reports->not_found_error();
				return $result ?? new WP_Error( 'analytify_error', __( 'Failed to get 404 error data.', 'wp-analytify-pro' ), array( 'status' => 500 ) );
			case 'js-error':
				$result = $this->rest_reports->js_error();
				return $result ?? new WP_Error( 'analytify_error', __( 'Failed to get JavaScript error data.', 'wp-analytify-pro' ), array( 'status' => 500 ) );
			case 'events-tracking':
				$result = $this->rest_tracking->events_tracking();
				return $result ?? new WP_Error( 'analytify_error', __( 'Failed to get events tracking data.', 'wp-analytify-pro' ), array( 'status' => 500 ) );
			case 'enhanced-tel-tracking':
				$result = $this->rest_tracking->enhanced_tel_tracking();
				return $result ?? new WP_Error( 'analytify_error', __( 'Failed to get enhanced tel tracking data.', 'wp-analytify-pro' ), array( 'status' => 500 ) );
			case 'video-tracking':
				$result = $this->rest_tracking->video_tracking();
				return $result ?? new WP_Error( 'analytify_error', __( 'Failed to get video tracking data.', 'wp-analytify-pro' ), array( 'status' => 500 ) );
			case 'custom-dimensions':
				$result = $this->rest_tracking->custom_dimensions();
				return $result ?? new WP_Error( 'analytify_error', __( 'Failed to get custom dimensions data.', 'wp-analytify-pro' ), array( 'status' => 500 ) );
			case 'search-terms':
				$result = $this->rest_search->search_terms();
				return $result ?? new WP_Error( 'analytify_error', __( 'Failed to get search terms data.', 'wp-analytify-pro' ), array( 'status' => 500 ) );
			case 'demographics':
				$result = $this->rest_demographics->demographics();
				return $result ?? new WP_Error( 'analytify_error', __( 'Failed to get demographics data.', 'wp-analytify-pro' ), array( 'status' => 500 ) );
			case 'interests':
				$result = $this->rest_demographics->interests();
				return $result ?? new WP_Error( 'analytify_error', __( 'Failed to get interests data.', 'wp-analytify-pro' ), array( 'status' => 500 ) );
			case 'real-time':
				$result = $this->rest_demographics->real_time();
				return $result ?? new WP_Error( 'analytify_error', __( 'Failed to get real-time data.', 'wp-analytify-pro' ), array( 'status' => 500 ) );
			case 'page-speed':
				$result = $this->rest_advanced->page_speed();
				return $result ?? new WP_Error( 'analytify_error', __( 'Failed to get page speed data.', 'wp-analytify-pro' ), array( 'status' => 500 ) );
			case 'keyword-stats-search-console':
				$result = $this->rest_advanced->keyword_stats_search_console();
				return $result ?? new WP_Error( 'analytify_error', __( 'Failed to get keyword stats from search console.', 'wp-analytify-pro' ), array( 'status' => 500 ) );
			case 'compare-stats':
				$result = $this->rest_advanced->compare_stats();
				return $result ?? new WP_Error( 'analytify_error', __( 'Failed to get compare stats.', 'wp-analytify-pro' ), array( 'status' => 500 ) );
		}

		// If no request type match, Return error.
		return new WP_Error( 'analytify_invalid_endpoint', __( 'Invalid endpoint.', 'wp-analytify-pro' ), array( 'status' => 404 ) );
	}

	/**
	 * Keyword stats search console method
	 *
	 * @return array<string, mixed>
	 */
	public function keyword_stats_search_console() {
		return $this->rest_advanced->keyword_stats_search_console();
	}

	/**
	 * Add menu option.
	 *
	 * @return void
	 */
	public function add_menu_option() {
		add_submenu_page(
			'analytify-dashboard',
			'Search Console',
			__( 'Search Console', 'wp-analytify-pro' ),
			'manage_options',
			'analytify-dashboard&show=search-console-report',
			function () {
				$this->keyword_stats_search_console(); },
			47
		);
	}

	/**
	 * Applied as a filter to a single custom dimension row label.
	 *
	 * @param string $label Row label.
	 * @param string $type  Dimension type.
	 *
	 * @return string
	 */
	public function filter_custom_dimension_row_label( $label, $type ) {
		return $this->rest_advanced->filter_custom_dimension_row_label( $label, $type );
	}
}

/**
 * Init the instance.
 */
Analytify_Pro_Rest_API::get_instance();
