<?php
// phpcs:ignoreFile WordPress.Files.FileName.NotHyphenatedLowercase, WordPress.Files.FileName.InvalidClassFileName
/**
 * WP Analytify Pro – Tracking helpers
 *
 * User/GA tracking checks, client ID, UUID, session ID, and GA4 event dispatch.
 * Used by WP_Analytify_Pro_Base; load via analytifypro_base.php.
 *
 * @package WP_Analytify_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class WP_Analytify_Pro_Tracking_Helpers
 *
 * @since 9.0.0
 */
class WP_Analytify_Pro_Tracking_Helpers {

	/**
	 * Check if the current user should be tracked based on their role.
	 *
	 * @since 9.0.0
	 * @return bool True if the user should be tracked.
	 */
	public function is_track_user() {
		global $current_user;

		if ( ! is_object( $current_user ) || ! isset( $current_user->roles ) ) {
			return true;
		}

		$roles    = $current_user->roles;
		$is_track = isset( $GLOBALS['WP_ANALYTIFY']->settings ) ? $GLOBALS['WP_ANALYTIFY']->settings->get_option( 'exclude_users_tracking', 'wp-analytify-profile', array() ) : array();

		if ( is_user_logged_in() && isset( $roles[0] ) && in_array( $roles[0], $is_track, true ) ) {
			return false;
		}

		return true;
	}

	/**
	 * Check if Google Analytics tracking is enabled in settings.
	 *
	 * @since 9.0.0
	 * @return bool True if tracking is enabled.
	 */
	public function is_ga_enable() {
		if ( ! isset( $GLOBALS['WP_ANALYTIFY']->settings ) ) {
			return false;
		}
		$is_code = $GLOBALS['WP_ANALYTIFY']->settings->get_option( 'install_ga_code', 'wp-analytify-profile' );
		return 'on' === $is_code;
	}

	/**
	 * Get the Google Analytics Client ID from cookie or generate a new one.
	 *
	 * @since 9.0.0
	 * @param int $order_id Optional. Order ID to check for saved CID.
	 * @return string The Client ID.
	 */
	public function get_ga_client_id( $order_id = 0 ) {
		$saved_cid = $order_id ? get_post_meta( $order_id, 'analytify_cid', true ) : '';

		if ( empty( $saved_cid ) ) {
			$saved_cid = $order_id ? get_post_meta( $order_id, 'analytify_llms_cid', true ) : '';
		}

		$ga_cookie = isset( $_COOKIE['_ga'] ) ? sanitize_text_field( wp_unslash( $_COOKIE['_ga'] ) ) : '';

		if ( ! empty( $ga_cookie ) ) {
			$parts = explode( '.', $ga_cookie );
			if ( count( $parts ) >= 4 && isset( $parts[2], $parts[3] ) ) {
				return $parts[2] . '.' . $parts[3];
			}
		}

		if ( ! empty( $saved_cid ) ) {
			return $saved_cid;
		}

		return $this->generate_uuid();
	}

	/**
	 * Generate a UUID v4 string.
	 *
	 * @since 9.0.0
	 * @return string UUID v4.
	 */
	public function generate_uuid() {
		return sprintf(
			'%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
			wp_rand( 0, 0xffff ),
			wp_rand( 0, 0xffff ),
			wp_rand( 0, 0xffff ),
			wp_rand( 0, 0x0fff ) | 0x4000,
			wp_rand( 0, 0x3fff ) | 0x8000,
			wp_rand( 0, 0xffff ),
			wp_rand( 0, 0xffff ),
			wp_rand( 0, 0xffff )
		);
	}

	/**
	 * Extract the GA4 session ID from cookies.
	 *
	 * @since 9.0.0
	 * @param array $cookies The $_COOKIE array or similar.
	 * @return int The session ID or 0 if not found.
	 */
	public function analytify_filter_session_id( $cookies ) {
		if ( ! is_array( $cookies ) ) {
			return 0;
		}

		foreach ( $cookies as $cookie_name => $cookie_content ) {
			if ( strpos( $cookie_name, '_ga_' ) === 0 ) {
				if ( preg_match( '/s(\d+)/', $cookie_content, $matches ) ) {
					return (int) $matches[1];
				}
			}
		}

		return 0;
	}

	/**
	 * Dispatch a GA4 event through Measurement Protocol if allowed.
	 *
	 * @since 9.0.0
	 * @param array $event The event data array (name and params).
	 * @return bool True if dispatched, false otherwise.
	 */
	public function dispatch_ga4_event( $event ) {
		if ( ! $this->is_track_user() || ! $this->is_ga_enable() ) {
			return false;
		}

		if ( function_exists( 'analytify_mp_ga4' ) ) {
			analytify_mp_ga4( $event );
			return true;
		}

		return false;
	}
}
