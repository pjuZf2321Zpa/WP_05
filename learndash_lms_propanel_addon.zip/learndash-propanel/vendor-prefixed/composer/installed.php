<?php return array (
  'root' => 
  array (
    'name' => 'stellarwp/learndash-reports',
    'pretty_version' => 'dev-main',
    'version' => 'dev-main',
    'reference' => 'd1884fd932b4e25a33c750c93d460dab6b945d75',
    'type' => 'wordpress-plugin',
    'install_path' => __DIR__ . '/../',
    'aliases' => 
    array (
    ),
    'dev' => false,
  ),
  'versions' => 
  array (
    'composer/pcre' => 
    array (
      'pretty_version' => '3.3.2',
      'version' => '3.3.2.0',
      'reference' => 'b2bed4734f0cc156ee1fe9c0da2550420d99a21e',
      'type' => 'library',
      'install_path' => 'phar:///home/runner/work/learndash-propanel/learndash-propanel/dev_scripts/phar/strauss.phar/src/Pipeline/Autoload/./pcre',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'ezyang/htmlpurifier' => 
    array (
      'pretty_version' => 'v4.19.0',
      'version' => '4.19.0.0',
      'reference' => 'b287d2a16aceffbf6e0295559b39662612b77fcf',
      'type' => 'library',
      'install_path' => __DIR__ . '/../ezyang/htmlpurifier',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'maennchen/zipstream-php' => 
    array (
      'pretty_version' => '2.2.6',
      'version' => '2.2.6.0',
      'reference' => '30ad6f93cf3efe4192bc7a4c9cad11ff8f4f237f',
      'type' => 'library',
      'install_path' => __DIR__ . '/../maennchen/zipstream-php',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'markbaker/complex' => 
    array (
      'pretty_version' => '3.0.2',
      'version' => '3.0.2.0',
      'reference' => '95c56caa1cf5c766ad6d65b6344b807c1e8405b9',
      'type' => 'library',
      'install_path' => __DIR__ . '/../markbaker/complex',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'markbaker/matrix' => 
    array (
      'pretty_version' => '3.0.1',
      'version' => '3.0.1.0',
      'reference' => '728434227fe21be27ff6d86621a1b13107a2562c',
      'type' => 'library',
      'install_path' => __DIR__ . '/../markbaker/matrix',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'myclabs/php-enum' => 
    array (
      'pretty_version' => '1.8.5',
      'version' => '1.8.5.0',
      'reference' => 'e7be26966b7398204a234f8673fdad5ac6277802',
      'type' => 'library',
      'install_path' => __DIR__ . '/../myclabs/php-enum',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'phpoffice/phpspreadsheet' => 
    array (
      'pretty_version' => '1.30.5',
      'version' => '1.30.5.0',
      'reference' => '97bcabd32a64924688487dcd64aceaf158affb5c',
      'type' => 'library',
      'install_path' => __DIR__ . '/../phpoffice/phpspreadsheet',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'psr/http-message' => 
    array (
      'pretty_version' => '1.1',
      'version' => '1.1.0.0',
      'reference' => 'cb6ce4845ce34a8ad9e68117c10ee90a29919eba',
      'type' => 'library',
      'install_path' => __DIR__ . '/../psr/http-message',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'psr/simple-cache' => 
    array (
      'pretty_version' => '1.0.1',
      'version' => '1.0.1.0',
      'reference' => '408d5eafb83c57f6365a3ca330ff23aa4a5fa39b',
      'type' => 'library',
      'install_path' => __DIR__ . '/../psr/simple-cache',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'symfony/polyfill-mbstring' => 
    array (
      'pretty_version' => 'v1.38.2',
      'version' => '1.38.2.0',
      'reference' => 'd3d318bad5e7a1bfbd026009c8bfb8d8f99ae6b6',
      'type' => 'library',
      'install_path' => __DIR__ . '/../symfony/polyfill-mbstring',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
  ),
);