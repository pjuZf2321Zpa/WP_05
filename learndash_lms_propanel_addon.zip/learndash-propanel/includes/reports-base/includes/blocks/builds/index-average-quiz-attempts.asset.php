<?php return array('dependencies' => array('moment', 'react', 'wp-element', 'wp-i18n'), 'version' => 'de42829c9c421b3fce94');
