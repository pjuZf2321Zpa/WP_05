<?php return array('dependencies' => array('moment', 'react', 'wp-block-editor', 'wp-blocks', 'wp-element', 'wp-hooks', 'wp-i18n'), 'version' => '0d8cc9e293a2c70e9903');
