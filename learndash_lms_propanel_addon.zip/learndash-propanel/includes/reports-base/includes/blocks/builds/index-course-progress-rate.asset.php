<?php return array('dependencies' => array('moment', 'react', 'react-dom', 'wp-components', 'wp-element', 'wp-i18n'), 'version' => '9ed74652fe86523f1542');
