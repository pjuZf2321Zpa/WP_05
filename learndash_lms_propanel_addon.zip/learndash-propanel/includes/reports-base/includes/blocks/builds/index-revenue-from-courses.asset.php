<?php return array('dependencies' => array('moment', 'react', 'wp-element', 'wp-i18n'), 'version' => 'a97676111a14143b5f2e');
