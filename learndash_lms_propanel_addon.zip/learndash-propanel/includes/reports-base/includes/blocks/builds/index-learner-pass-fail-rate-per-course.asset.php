<?php return array('dependencies' => array('moment', 'react', 'wp-element', 'wp-i18n'), 'version' => 'bb72ec2ccb26791c7d26');
