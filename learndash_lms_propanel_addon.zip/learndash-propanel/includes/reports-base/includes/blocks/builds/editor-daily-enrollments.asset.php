<?php return array('dependencies' => array('moment', 'react', 'wp-block-editor', 'wp-blocks', 'wp-element', 'wp-hooks', 'wp-i18n'), 'version' => '338befc0e3b423e988a3');
