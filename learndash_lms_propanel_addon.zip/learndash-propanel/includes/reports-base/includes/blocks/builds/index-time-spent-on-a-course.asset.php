<?php return array('dependencies' => array('moment', 'react', 'react-dom', 'wp-components', 'wp-element', 'wp-i18n'), 'version' => '28027bf0d61fa660d9e3');
