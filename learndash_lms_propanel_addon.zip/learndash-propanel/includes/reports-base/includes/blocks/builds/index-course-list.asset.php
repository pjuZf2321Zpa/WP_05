<?php return array('dependencies' => array('moment', 'react', 'wp-element', 'wp-hooks', 'wp-i18n'), 'version' => '188473415ef28f021e55');
