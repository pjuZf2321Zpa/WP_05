<?php return array('dependencies' => array('moment', 'react', 'wp-block-editor', 'wp-blocks', 'wp-data', 'wp-element', 'wp-hooks', 'wp-i18n'), 'version' => '5fe63c374c665424f3a6');
