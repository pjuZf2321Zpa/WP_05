<?php return array('dependencies' => array('moment', 'react', 'wp-element', 'wp-i18n'), 'version' => 'ea392f41d897d5c24bce');
