<?php return array('dependencies' => array('moment', 'react', 'wp-block-editor', 'wp-blocks', 'wp-element', 'wp-hooks', 'wp-i18n'), 'version' => 'd91ee361c8597809cf6f');
