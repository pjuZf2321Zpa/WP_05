<?php return array('dependencies' => array('moment', 'react', 'wp-block-editor', 'wp-blocks', 'wp-element', 'wp-hooks', 'wp-i18n'), 'version' => '432c3cd0c8721c169200');
