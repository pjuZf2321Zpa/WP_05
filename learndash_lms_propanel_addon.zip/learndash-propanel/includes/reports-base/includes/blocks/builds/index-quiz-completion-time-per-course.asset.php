<?php return array('dependencies' => array('moment', 'react', 'wp-element', 'wp-i18n'), 'version' => 'fd15941f2cebc5c1be56');
