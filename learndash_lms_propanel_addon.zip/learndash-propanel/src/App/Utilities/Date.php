<?php
/**
 * This file contains a class with static date utilities for resolving mixed
 * start/end date inputs and snapping them to whole-day bounds.
 *
 * @since 3.1.1
 *
 * @package LearnDash\Reports
 */

namespace LearnDash\Reports\Utilities;

use DateTimeImmutable;
use DateTimeZone;
use LearnDash\Core\Utilities\Cast;

/**
 * Reusable date utilities for reporting APIs.
 *
 * @since 3.1.1
 */
class Date {
	/**
	 * Resolves a request-side date value plus a server-side normalized fallback
	 * to an integer Unix timestamp.
	 *
	 * A numeric $primary is trusted as-is and MUST be a genuine Unix timestamp.
	 * The helper deliberately does not try to guess whether a numeric value is
	 * "really" a timestamp, because any integer - including 0, negatives, and
	 * 8-digit values - is a valid Unix time. Passing a date-shaped numeric (e.g.
	 * a Ymd like 20260605) is therefore a caller error, not something this method
	 * second-guesses. When $primary is non-numeric (empty, a date string, a
	 * sanitized "null") the canonical server-normalized $fallback is used instead:
	 * a numeric fallback is trusted as a timestamp, anything else is parsed via
	 * strtotime(). The primary is never strtotime()'d - that would silently drop
	 * the time component on inputs like "2026-05-29".
	 *
	 * @since 3.1.1
	 *
	 * @param mixed $primary  Request-side value. When numeric it is required to be
	 *                        a Unix timestamp; otherwise it is ignored in favor of
	 *                        $fallback.
	 * @param mixed $fallback Server-side normalized value. Used as a Unix timestamp
	 *                        when numeric, otherwise parsed via strtotime().
	 *
	 * @return int Resolved Unix timestamp, or 0 when neither value resolves.
	 */
	public static function resolve_timestamp( $primary, $fallback ): int {
		if ( is_numeric( $primary ) ) {
			return Cast::to_int( $primary );
		}

		if ( is_numeric( $fallback ) ) {
			return Cast::to_int( $fallback );
		}

		return Cast::to_int( strtotime( Cast::to_string( $fallback ) ) );
	}

	/**
	 * Snaps a Unix timestamp to the start of its day (00:00:00) in the given
	 * timezone. Defaults to the site timezone reported by wp_timezone().
	 *
	 * @since 3.1.1
	 *
	 * @param int               $timestamp Unix timestamp to snap.
	 * @param DateTimeZone|null $tz        Optional. Timezone used to interpret the
	 *                                     calendar day. Default: site timezone.
	 *
	 * @return int Unix timestamp at 00:00:00 of the same calendar day.
	 */
	public static function snap_to_day_start( int $timestamp, ?DateTimeZone $tz = null ): int {
		return ( new DateTimeImmutable( '@' . $timestamp ) )
			->setTimezone( $tz ?? wp_timezone() )
			->setTime( 0, 0, 0 )
			->getTimestamp();
	}

	/**
	 * Snaps a Unix timestamp to the end of its day (23:59:59) in the given
	 * timezone. Defaults to the site timezone reported by wp_timezone().
	 *
	 * @since 3.1.1
	 *
	 * @param int               $timestamp Unix timestamp to snap.
	 * @param DateTimeZone|null $tz        Optional. Timezone used to interpret the
	 *                                     calendar day. Default: site timezone.
	 *
	 * @return int Unix timestamp at 23:59:59 of the same calendar day.
	 */
	public static function snap_to_day_end( int $timestamp, ?DateTimeZone $tz = null ): int {
		return ( new DateTimeImmutable( '@' . $timestamp ) )
			->setTimezone( $tz ?? wp_timezone() )
			->setTime( 23, 59, 59 )
			->getTimestamp();
	}
}
