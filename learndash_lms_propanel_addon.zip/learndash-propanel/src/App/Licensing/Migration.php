<?php // phpcs:ignore Squiz.Commenting.FileComment.Missing -- This file is deprecated.
/**
 * Deprecated file.
 *
 * @since 1.8.2
 * @deprecated 3.1.0
 *
 * @package LearnDash\Reports
 */

require_once LDRP_PLUGIN_DIR . 'src/deprecated/Licensing/Migration.php';
