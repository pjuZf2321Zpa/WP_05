<?php
/**
 * Report scope value object.
 *
 * @since 3.1.1
 *
 * @package LearnDash\Reports
 */

namespace LearnDash\Reports\Modules\Reporting;

use LearnDash\Core\Utilities\Cast;

/**
 * Resolves and represents which of a learner's quiz attempts a viewer may see.
 *
 * @since 3.1.1
 */
class Scope {
	/**
	 * Course IDs the report is narrowed to, or null when the report is not filtered by course.
	 *
	 * @since 3.1.1
	 *
	 * @var int[]|null
	 */
	private ?array $course_ids;

	/**
	 * Stores the resolved course-ID restriction (null when the report is not filtered by course).
	 *
	 * @since 3.1.1
	 *
	 * @param int[]|null $course_ids Course IDs to narrow to, or null when not filtered by course.
	 */
	private function __construct( ?array $course_ids ) {
		$this->course_ids = $course_ids;
	}

	/**
	 * Builds the scope for the current viewer looking at a learner's report.
	 *
	 * Not filtered by course (null) for an administrator or a learner viewing their own report;
	 * otherwise narrowed to the deduplicated set of courses the viewer manages (group leader
	 * and/or instructor) — an empty set means they manage nothing.
	 *
	 * @since 3.1.1
	 *
	 * @param int $queried_user_id The learner whose report is being viewed.
	 *
	 * @return self
	 */
	public static function for_viewer( int $queried_user_id ): self {
		if (
			learndash_is_admin_user()
			|| get_current_user_id() === $queried_user_id
		) {
			return new self( null );
		}

		$course_ids = qre_get_user_managed_group_courses();

		$user = wp_get_current_user();
		if (
			function_exists( 'ir_get_instructor_complete_course_list' )
			&& in_array( 'wdm_instructor', $user->roles, true )
		) {
			$course_ids = array_merge(
				$course_ids,
				ir_get_instructor_complete_course_list( $user->ID )
			);
		}

		return new self(
			array_values(
				array_unique(
					array_map( [ Cast::class, 'to_int' ], $course_ids )
				)
			)
		);
	}

	/**
	 * Returns whether the report is narrowed to a specific set of courses.
	 *
	 * True for a group leader / instructor, whose view is restricted to the courses they manage
	 * (an empty managed set still counts as filtered — they then see nothing). False for an
	 * administrator or a learner viewing their own report: they are not filtered by course, so
	 * every attempt of this learner is shown. "Not filtered" here means unrestricted by
	 * managed-course scope — not that they can see every course on the site.
	 *
	 * @since 3.1.1
	 *
	 * @return bool Whether the queried learner's attempts are narrowed to a managed-course set.
	 */
	public function is_filtered_by_courses(): bool {
		return null !== $this->course_ids;
	}

	/**
	 * Gets the course IDs the report is narrowed to.
	 *
	 * Only meaningful when is_filtered_by_courses() is true; an empty array means the viewer
	 * manages no courses, so no attempts are visible.
	 *
	 * @since 3.1.1
	 *
	 * @return int[]
	 */
	public function get_course_ids(): array {
		return $this->course_ids ?? [];
	}
}
