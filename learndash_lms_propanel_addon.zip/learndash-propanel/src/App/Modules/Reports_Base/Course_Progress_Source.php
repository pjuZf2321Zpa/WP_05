<?php
/**
 * Authoritative course progress source for ProPanel reports.
 *
 * Computes enrolled / completed / in-progress learner sets from the same data
 * LearnDash core's Course Dashboard uses (enrollment usermeta + the
 * learndash_user_activity table), so report counts match the dashboard.
 *
 * @since 3.1.1
 *
 * @package LearnDash\Reports
 */

namespace LearnDash\Reports\Modules\Reports_Base;

use LDLMS_DB;
use LearnDash\Core\Utilities\Cast;
use StellarWP\Learndash\StellarWP\DB\DB;
use StellarWP\Learndash\StellarWP\DB\QueryBuilder\WhereQueryBuilder;

/**
 * Authoritative course progress source.
 *
 * @since 3.1.1
 */
class Course_Progress_Source {
	/**
	 * Returns the IDs of users enrolled in a course (direct or via group), matching core.
	 *
	 * @since 3.1.1
	 *
	 * @param int            $course_id        Course ID.
	 * @param int[]|int|null $accessible_users Restrict to these user IDs. null or -1 = no restriction.
	 * @param int|null       $enrolled_since   Optional. Keep only users whose course access is after this unix timestamp.
	 *
	 * @return int[] Enrolled user IDs.
	 */
	public static function get_enrolled_user_ids( $course_id, $accessible_users = null, $enrolled_since = null ) {
		$course_id = Cast::to_int( $course_id );
		if ( $course_id <= 0 ) {
			return [];
		}

		$user_ids = self::query_enrolled_user_ids( $course_id );

		$user_ids = self::apply_accessible_filter( $user_ids, $accessible_users );
		$user_ids = self::apply_enrolled_since_filter( $user_ids, $course_id, $enrolled_since );

		return array_values( $user_ids );
	}

	/**
	 * Returns the IDs of enrolled users who completed the course, matching core.
	 *
	 * @since 3.1.1
	 *
	 * @param int            $course_id        Course ID.
	 * @param int[]|int|null $accessible_users Restrict to these user IDs. null or -1 = no restriction.
	 * @param int|null       $enrolled_since   Optional. Keep only users whose course access is after this unix timestamp.
	 *
	 * @return int[] Completed user IDs.
	 */
	public static function get_completed_user_ids( $course_id, $accessible_users = null, $enrolled_since = null ) {
		$enrolled = self::get_enrolled_user_ids( $course_id, $accessible_users, $enrolled_since );

		return self::filter_completed( $course_id, $enrolled );
	}

	/**
	 * Returns the IDs of enrolled users in progress on the course, matching core.
	 *
	 * @since 3.1.1
	 *
	 * @param int            $course_id        Course ID.
	 * @param int[]|int|null $accessible_users Restrict to these user IDs. null or -1 = no restriction.
	 * @param int|null       $enrolled_since   Optional. Keep only users whose course access is after this unix timestamp.
	 *
	 * @return int[] In-progress user IDs.
	 */
	public static function get_in_progress_user_ids( $course_id, $accessible_users = null, $enrolled_since = null ) {
		$enrolled = self::get_enrolled_user_ids( $course_id, $accessible_users, $enrolled_since );

		return self::filter_in_progress( $course_id, $enrolled );
	}

	/**
	 * Filters an already-known enrolled set down to users who completed the course.
	 *
	 * @since 3.1.1
	 *
	 * @param int   $course_id    Course ID.
	 * @param int[] $enrolled_ids Enrolled user IDs to filter.
	 *
	 * @return int[] Completed user IDs.
	 */
	public static function filter_completed( $course_id, array $enrolled_ids ) {
		return self::filter_by_activity( Cast::to_int( $course_id ), $enrolled_ids, 'completed' );
	}

	/**
	 * Filters an already-known enrolled set down to users in progress on the course.
	 *
	 * @since 3.1.1
	 *
	 * @param int   $course_id    Course ID.
	 * @param int[] $enrolled_ids Enrolled user IDs to filter.
	 *
	 * @return int[] In-progress user IDs.
	 */
	public static function filter_in_progress( $course_id, array $enrolled_ids ) {
		return self::filter_by_activity( Cast::to_int( $course_id ), $enrolled_ids, 'in_progress' );
	}

	/**
	 * Filters an enrolled set down to users with matching course activity.
	 *
	 * @since 3.1.1
	 *
	 * @param int    $course_id Course ID.
	 * @param int[]  $user_ids  Enrolled user IDs to filter.
	 * @param string $status    Either 'completed' or 'in_progress'.
	 *
	 * @return int[] User IDs whose course activity matches the status.
	 */
	private static function filter_by_activity( $course_id, array $user_ids, $status ) {
		if ( empty( $user_ids ) ) {
			return [];
		}

		$query = DB::table( DB::raw( LDLMS_DB::get_table_name( 'user_activity' ) ) )
			->select( 'user_id' )
			->where( 'course_id', Cast::to_string( $course_id ) )
			->where( 'activity_type', 'course' )
			->whereIn( 'user_id', array_map( [ Cast::class, 'to_int' ], $user_ids ) );

		if ( 'completed' === $status ) {
			$query->where( 'activity_completed', '0', '>' );
		} else {
			$query->where( 'activity_started', '0', '>' )
				->where(
					static function ( WhereQueryBuilder $builder ) {
						$builder->where( 'activity_completed', '0' )
							->orWhereIsNull( 'activity_completed' );
					}
				)
				->whereRaw( 'AND activity_updated != activity_started' );
		}

		return array_map( [ Cast::class, 'to_int' ], DB::get_col( $query->groupBy( 'user_id' )->getSQL() ) );
	}

	/**
	 * Queries the IDs of users enrolled in a course directly or via a group, matching core.
	 *
	 * @since 3.1.1
	 *
	 * @param int $course_id Course ID.
	 *
	 * @return int[] Enrolled user IDs.
	 */
	private static function query_enrolled_user_ids( $course_id ) {
		global $wpdb;

		$query = DB::table( DB::raw( $wpdb->usermeta ) )
			->select( 'user_id' )
			->where( 'meta_key', 'course_' . $course_id . '_access_from' );

		$group_ids = array_filter( array_map( [ Cast::class, 'to_int' ], (array) learndash_get_course_groups( $course_id ) ) );
		if ( ! empty( $group_ids ) ) {
			$query->orWhereIn(
				'meta_key',
				array_map(
					static function ( $group_id ) {
						return 'learndash_group_users_' . $group_id;
					},
					$group_ids
				)
			);
		}

		return array_map( [ Cast::class, 'to_int' ], DB::get_col( $query->groupBy( 'user_id' )->getSQL() ) );
	}

	/**
	 * Intersects a user set with the accessible-users restriction.
	 *
	 * @since 3.1.1
	 *
	 * @param int[]          $user_ids         User IDs to filter.
	 * @param int[]|int|null $accessible_users null or -1 = no restriction; int[] = intersect; anything else = empty.
	 *
	 * @return int[] Filtered user IDs.
	 */
	private static function apply_accessible_filter( array $user_ids, $accessible_users ) {
		if ( is_array( $accessible_users ) ) {
			return array_values( array_intersect( $user_ids, array_map( 'intval', $accessible_users ) ) );
		}
		if (
			is_null( $accessible_users )
			|| Cast::to_int( $accessible_users ) === -1
		) {
			return $user_ids;
		}
		return [];
	}

	/**
	 * Keeps only users whose course access started after a threshold.
	 *
	 * @since 3.1.1
	 *
	 * @param int[]    $user_ids       User IDs to filter.
	 * @param int      $course_id      Course ID.
	 * @param int|null $enrolled_since Unix timestamp threshold, or null to skip.
	 *
	 * @return int[] Filtered user IDs.
	 */
	private static function apply_enrolled_since_filter( array $user_ids, $course_id, $enrolled_since ) {
		if ( empty( $enrolled_since ) ) {
			return $user_ids;
		}

		$threshold = Cast::to_int( $enrolled_since );
		$access    = self::resolve_access_dates( Cast::to_int( $course_id ), $user_ids );

		return array_values(
			array_filter(
				$user_ids,
				static function ( $user_id ) use ( $access, $threshold ) {
					return ( $access[ Cast::to_int( $user_id ) ] ?? 0 ) > $threshold;
				}
			)
		);
	}

	/**
	 * Resolves each user's course access timestamp without per-learner database queries.
	 *
	 * Direct enrollment dates come from one set-based usermeta query; group-only learners are
	 * resolved through core's learndash_user_group_enrolled_to_course_from() over a warmed cache,
	 * so group-leader auto-enroll, group validation, hierarchy, the registration-date floor and
	 * the future-date cutoff all stay faithful to core.
	 *
	 * @since 3.1.1
	 *
	 * @param int   $course_id Course ID.
	 * @param int[] $user_ids  Enrolled user IDs to resolve.
	 *
	 * @return array<int, int> Map of user ID to access-from unix timestamp; only users with a date > 0.
	 */
	private static function resolve_access_dates( $course_id, array $user_ids ) {
		global $wpdb;

		$course_id = Cast::to_int( $course_id );
		$user_ids  = array_map( [ Cast::class, 'to_int' ], $user_ids );
		if ( empty( $user_ids ) ) {
			return [];
		}

		cache_users( $user_ids );

		$direct_rows = DB::get_results(
			DB::table( DB::raw( $wpdb->usermeta ) )
				->select( 'user_id', 'meta_value' )
				->where( 'meta_key', 'course_' . $course_id . '_access_from' )
				->whereIn( 'user_id', $user_ids )
				->getSQL(),
			ARRAY_A
		);

		$access = [];
		foreach ( (array) $direct_rows as $row ) {
			$date = Cast::to_int( $row['meta_value'] ?? 0 );
			if ( $date > 0 ) {
				$access[ Cast::to_int( $row['user_id'] ?? 0 ) ] = $date;
			}
		}

		foreach ( $user_ids as $user_id ) {
			if ( isset( $access[ $user_id ] ) ) {
				continue;
			}
			$date = Cast::to_int( learndash_user_group_enrolled_to_course_from( $user_id, $course_id ) );
			if ( $date > 0 ) {
				$access[ $user_id ] = $date;
			}
		}

		return $access;
	}
}
