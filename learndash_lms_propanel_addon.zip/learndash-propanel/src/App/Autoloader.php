<?php
/**
 * Autoloader class for deprecated classes.
 *
 * @since 3.1.0
 *
 * @package LearnDash\Reports
 */

namespace LearnDash\Reports;

use RecursiveDirectoryIterator;
use RecursiveIteratorIterator;
use SplFileInfo;

/**
 * Autoloader class for deprecated classes.
 *
 * @since 3.1.0
 */
class Autoloader {
	/**
	 * Setup the autoloader for extra classes, which are not in the src/App directory.
	 *
	 * @since 3.1.0
	 *
	 * @return void
	 */
	public static function extra_autoloading(): void {
		$class_map = [];

		$deprecated_dir = dirname( __DIR__, 2 ) . '/src/deprecated/';

		if ( ! is_dir( $deprecated_dir ) ) {
			return;
		}

		// Iterate through all files under ./src/deprecated.
		$iterator = new RecursiveDirectoryIterator( $deprecated_dir );
		$files    = new RecursiveIteratorIterator( $iterator, RecursiveIteratorIterator::SELF_FIRST );

		foreach ( $files as $file ) {
			if (
				! $file instanceof SplFileInfo
				|| ! $file->isFile()
				|| $file->getExtension() !== 'php'
			) {
				continue;
			}

			// Construct the proper class name based on the file path.
			$class_name = str_replace(
				'/',
				'\\',
				(string) preg_replace(
					'/.*?src\/deprecated\/(.*?)\.php/',
					'$1',
					$file->getRealPath()
				)
			);

			if ( strpos( $class_name, '\\' ) !== false ) {
				$class_name = 'LearnDash\\Reports\\' . $class_name;
			}

			$class_map[ $class_name ] = $file->getRealPath();
		}

		if ( empty( $class_map ) ) {
			return;
		}

		spl_autoload_register(
			static function ( string $class ) use ( $class_map ): void {
				if ( isset( $class_map[ $class ] ) ) {
					require_once $class_map[ $class ];
				}
			}
		);
	}
}
