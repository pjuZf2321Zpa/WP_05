<?php
/**
 * Handles Plugin Activation logic.
 *
 * @since 1.8.2
 * @since 3.1.0 Removed the licensing check.
 *
 * @package LearnDash\Reports
 */

namespace LearnDash\Reports;

/**
 * Plugin Activation class.
 *
 * @since 1.8.2
 */
class Activation {
	/**
	 * Runs plugin activation tasks.
	 *
	 * @since 1.8.2
	 * @since 3.1.0 Removed the licensing check.
	 *
	 * @return void
	 */
	public static function run(): void {
		// This class and method can be used later, it contained the licensing logic, but it's not used in the plugin anymore.
	}
}
