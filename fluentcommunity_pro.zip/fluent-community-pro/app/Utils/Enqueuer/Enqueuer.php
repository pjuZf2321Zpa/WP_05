<?php

namespace FluentCommunityPro\App\Utils\Enqueuer;

use FluentCommunityPro\App\Core\App;

abstract class Enqueuer
{
    private static string $resourceDirectory = 'resources/';

    public static function getResourceDirectory(){
        return self::$resourceDirectory;
    }
    private function enqueueStyle($handle, $src, $dependency = [], $version = null){}
    private function enqueueStaticStyle($handle, $src, $dependency = [], $version = null){}
    private function enqueueScript($handle, $src, $dependency = [], $version = null, $inFooter = false){}
    private function enqueueStaticScript($handle, $src, $dependency = [], $version = null, $inFooter = false){}

    public static function getEnqueuePath($path = ''){}

    public static function getAssetPath(): string
    {
        return App::getInstance()['url.assets'];
    }

    public static function getProductionFilePath($file)
    {
        return (static::getAssetPath() . $file['file']);
    }
}
