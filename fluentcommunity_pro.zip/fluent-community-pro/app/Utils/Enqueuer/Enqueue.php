<?php

namespace FluentCommunityPro\App\Utils\Enqueuer;

class Enqueue
{

    private static $enqueuer = Vite::class;

    public static function style($handle, $src, $dependency = [], $version = null){
        (self::$enqueuer)::enqueueStyle($handle, $src, $dependency, $version);
    }

    public static function staticStyle($handle, $src, $dependency, $version){
        (self::$enqueuer)::enqueueStaticStyle($handle, $src, $dependency, $version);
    }

    public static function script($handle, $src, $dependency = [], $version = null, $inFooter = false){
        return (self::$enqueuer)::enqueueScript($handle, $src, $dependency, $version, $inFooter);
    }

    public static function staticScript($handle, $src, $dependency = [], $version = null, $inFooter = false){
        return (self::$enqueuer)::enqueueStaticScript($handle, $src, $dependency, $version, $inFooter);
    }

    public static function getStaticFilePath($path){
        return (self::$enqueuer)::getStaticFilePath($path);
    }

}
