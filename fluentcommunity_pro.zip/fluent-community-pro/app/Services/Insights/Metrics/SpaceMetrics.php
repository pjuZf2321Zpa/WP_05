<?php

namespace FluentCommunityPro\App\Services\Insights\Metrics;

use FluentCommunity\App\Services\Insights\Bucketer;
use FluentCommunity\App\Services\Insights\Metrics\SpaceMetrics as BaseSpaceMetrics;
use FluentCommunity\App\Services\Insights\Metrics\Sql;
use FluentCommunity\App\Services\Insights\Range;
use FluentCommunity\App\Services\Insights\Scope;
use FluentCommunity\Database\Migrations\InsightsMigrator;

/**
 * The space comparison table (space.* in free docs/reporting/03). Every
 * figure is computed in SQL for all community spaces at once, so sorting and
 * paging never happen before the ranking value exists.
 */
class SpaceMetrics
{
    /**
     * @param Range $range
     * @param Scope $scope
     * @param Bucketer $bucketer for the per-space trend sparkline
     * @return array rows, one per community space (spaces with no activity included)
     */
    public static function comparison(Range $range, Scope $scope, Bucketer $bucketer)
    {
        $spaces = Sql::rows('SELECT s.id, s.title, s.slug, s.privacy FROM ' . Sql::table('fcom_spaces') . " s WHERE s.type = 'community' ORDER BY s.id");
        if (!$spaces) {
            return [];
        }

        $spaceIds = array_map('intval', array_column($spaces, 'id'));
        $ids = implode(',', $spaceIds);
        $posts = Sql::table('fcom_posts');
        $comments = Sql::table('fcom_post_comments');
        $members = Sql::table('fcom_space_user');
        $excluded = function ($column) use ($scope) {
            return Sql::notExcluded($column, $scope);
        };

        $memberCounts = self::byId("SELECT su.space_id AS id, COUNT(*) AS n FROM {$members} su WHERE su.space_id IN ({$ids}) AND su.status = 'active'" . $excluded('su.user_id') . ' GROUP BY su.space_id');
        $postCounts = self::byId("SELECT p.space_id AS id, COUNT(*) AS n FROM {$posts} p WHERE " . Sql::isPost('p') . ' AND ' . Sql::inRange('p.created_at', $range) . " AND p.space_id IN ({$ids})" . $excluded('p.user_id') . ' GROUP BY p.space_id');
        $commentCounts = self::byId("SELECT p.space_id AS id, COUNT(*) AS n FROM {$comments} c INNER JOIN {$posts} p ON p.id = c.post_id AND p.space_id IN ({$ids}) WHERE " . Sql::isComment('c') . ' AND ' . Sql::inRange('c.created_at', $range) . $excluded('c.user_id') . ' GROUP BY p.space_id');
        $contributors = BaseSpaceMetrics::contributors($range, $scope, $spaceIds);
        $joins = self::joins($range, $scope, $ids);
        $leaves = self::leaves($range, $ids);
        $replyRates = self::replyRates($range, $scope, $ids);
        $trends = self::trends($range, $scope, $bucketer, $ids);

        $rows = [];
        foreach ($spaces as $space) {
            $spaceId = (int)$space['id'];
            $memberCount = isset($memberCounts[$spaceId]) ? $memberCounts[$spaceId] : 0;
            $contributorCount = isset($contributors[$spaceId]) ? $contributors[$spaceId] : 0;

            $rows[] = [
                'space_id'          => $spaceId,
                'title'             => $space['title'],
                'slug'              => $space['slug'],
                'privacy'           => $space['privacy'],
                'members'           => $memberCount,
                'joins'             => isset($joins[$spaceId]) ? $joins[$spaceId] : 0,
                'leaves'            => $leaves === null ? null : (isset($leaves[$spaceId]) ? $leaves[$spaceId] : 0),
                'posts'             => isset($postCounts[$spaceId]) ? $postCounts[$spaceId] : 0,
                'comments'          => isset($commentCounts[$spaceId]) ? $commentCounts[$spaceId] : 0,
                'contributors'      => $contributorCount,
                'contributor_ratio' => $memberCount ? round($contributorCount / $memberCount, 4) : null,
                'reply_rate'        => isset($replyRates[$spaceId]) ? $replyRates[$spaceId] : null,
                'trend'             => $bucketer->fill(isset($trends[$spaceId]) ? $trends[$spaceId] : []),
            ];
        }

        usort($rows, function ($first, $second) {
            if ($first['posts'] !== $second['posts']) {
                return $second['posts'] - $first['posts'];
            }

            return $second['members'] - $first['members'];
        });

        return $rows;
    }

    /**
     * space.joins: memberships created in the range before event tracking
     * started, plus the join counter from then on. One source per day, never
     * both, so a join is never counted twice.
     */
    private static function joins(Range $range, Scope $scope, $ids)
    {
        $since = self::trackingSince();
        $sourceTo = $since && $since <= $range->toDate() ? $since . ' 00:00:00' : $range->sqlToExclusive();

        $joins = [];
        if ($sourceTo > $range->sqlFrom()) {
            $joins = self::byId(
                'SELECT su.space_id AS id, COUNT(*) AS n FROM ' . Sql::table('fcom_space_user') . " su
                 WHERE su.space_id IN ({$ids}) AND " . Sql::between('su.created_at', $range->sqlFrom(), $sourceTo) . Sql::notExcluded('su.user_id', $scope) . ' GROUP BY su.space_id'
            );
        }

        if ($since && $since <= $range->toDate()) {
            $from = max($since, $range->fromDate());
            foreach (self::byId(
                'SELECT ic.object_id AS id, SUM(ic.value) AS n FROM ' . Sql::table('fcom_insight_counters') . " ic
                 WHERE ic.object_type = 'space' AND ic.metric = 'space_joined' AND ic.object_id IN ({$ids})
                 AND ic.stat_date >= '{$from}' AND ic.stat_date <= '" . $range->toDate() . "' GROUP BY ic.object_id"
            ) as $spaceId => $count) {
                $joins[$spaceId] = (isset($joins[$spaceId]) ? $joins[$spaceId] : 0) + $count;
            }
        }

        return $joins;
    }

    /**
     * space.leaves: only known from the event counter, so null when the range
     * starts before tracking did.
     *
     * @return array|null
     */
    private static function leaves(Range $range, $ids)
    {
        $since = self::trackingSince();
        if (!$since || $since > $range->fromDate()) {
            return null;
        }

        return self::byId(
            'SELECT ic.object_id AS id, SUM(ic.value) AS n FROM ' . Sql::table('fcom_insight_counters') . " ic
             WHERE ic.object_type = 'space' AND ic.metric = 'space_left' AND ic.object_id IN ({$ids})
             AND ic.stat_date >= '" . $range->fromDate() . "' AND ic.stat_date <= '" . $range->toDate() . "' GROUP BY ic.object_id"
        );
    }

    /**
     * space.reply_rate, with the same rules as response.reply_rate.
     */
    private static function replyRates(Range $range, Scope $scope, $ids)
    {
        $posts = Sql::table('fcom_posts');
        $comments = Sql::table('fcom_post_comments');
        $cutoff = min($range->sqlToExclusive(), \FluentCommunity\App\Services\Insights\Clock::now()->format('Y-m-d H:i:s'));
        $cutoff = (new \DateTimeImmutable($cutoff, \FluentCommunity\App\Services\Insights\Clock::timezone()))->modify('-24 hours')->format('Y-m-d H:i:s');

        if ($cutoff <= $range->sqlFrom()) {
            return [];
        }

        $rows = Sql::rows(
            "SELECT p.space_id, COUNT(*) AS eligible, SUM(EXISTS (SELECT 1 FROM {$comments} c WHERE c.post_id = p.id AND " . Sql::isComment('c') . " AND NOT (c.user_id <=> p.user_id))) AS replied
             FROM {$posts} p
             WHERE " . Sql::isPost('p') . ' AND p.is_sticky = 0 AND ' . Sql::between('p.created_at', $range->sqlFrom(), $cutoff) . " AND p.space_id IN ({$ids})" . Sql::notExcluded('p.user_id', $scope) . '
             GROUP BY p.space_id'
        );

        $rates = [];
        foreach ($rows as $row) {
            $rates[(int)$row['space_id']] = (int)$row['eligible'] ? round((int)$row['replied'] / (int)$row['eligible'], 4) : null;
        }

        return $rates;
    }

    private static function trends(Range $range, Scope $scope, Bucketer $bucketer, $ids)
    {
        $bucket = $bucketer->sqlExpression('p.created_at');
        $rows = Sql::rows(
            "SELECT p.space_id, {$bucket} AS k, COUNT(*) AS n FROM " . Sql::table('fcom_posts') . ' p
             WHERE ' . Sql::isPost('p') . ' AND ' . Sql::inRange('p.created_at', $range) . " AND p.space_id IN ({$ids})" . Sql::notExcluded('p.user_id', $scope) . '
             GROUP BY p.space_id, k'
        );

        $trends = [];
        foreach ($rows as $row) {
            $trends[(int)$row['space_id']][$row['k']] = (int)$row['n'];
        }

        return $trends;
    }

    /**
     * @return string|null the validated 'Y-m-d' visit/event tracking start
     */
    private static function trackingSince()
    {
        $since = \DateTimeImmutable::createFromFormat('!Y-m-d', (string)get_option(InsightsMigrator::TRACKING_SINCE_OPTION, ''));

        return $since ? $since->format('Y-m-d') : null;
    }

    private static function byId($sql)
    {
        $map = [];
        foreach (Sql::rows($sql) as $row) {
            $map[(int)$row['id']] = (int)$row['n'];
        }

        return $map;
    }
}
