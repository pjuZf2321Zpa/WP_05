<?php

namespace FluentCommunityPro\App\Services\Insights\Metrics;

use FluentCommunity\App\Services\Helper;
use FluentCommunity\App\Services\Insights\Metrics\Sql;
use FluentCommunity\App\Services\Insights\Range;
use FluentCommunity\App\Services\Insights\Scope;

/**
 * content.top_posts, content.topics, content.types, content.bookmarks
 * (free docs/reporting/03). In-range counts come from the source tables,
 * never from the lifetime comments_count / reactions_count columns.
 */
class ContentMetrics
{
    /**
     * Posts created in the range, ranked by comments + reactions they got in
     * the range; ties: more comments first, then newest.
     *
     * @return array rows
     */
    public static function topPosts(Range $range, Scope $scope, $limit = 10)
    {
        $posts = Sql::table('fcom_posts');
        $space = $scope->spaceId() ? ' AND p.space_id = ' . $scope->spaceId() : '';

        $rows = Sql::rows(
            "SELECT p.id, p.title, p.message, p.slug, p.space_id, p.user_id, p.created_at, COALESCE(c.n, 0) AS comments, COALESCE(r.n, 0) AS reactions
             FROM {$posts} p
             LEFT JOIN (SELECT c.post_id, COUNT(*) AS n FROM " . Sql::table('fcom_post_comments') . ' c WHERE ' . Sql::isComment('c') . ' AND ' . Sql::inRange('c.created_at', $range) . Sql::notExcluded('c.user_id', $scope) . ' GROUP BY c.post_id) c ON c.post_id = p.id
             LEFT JOIN (SELECT r.object_id, COUNT(*) AS n FROM ' . Sql::table('fcom_post_reactions') . " r WHERE r.object_type = 'feed' AND r.type = 'like' AND " . Sql::inRange('r.created_at', $range) . Sql::notExcluded('r.user_id', $scope) . ' GROUP BY r.object_id) r ON r.object_id = p.id
             WHERE ' . Sql::isPost('p') . ' AND ' . Sql::inRange('p.created_at', $range) . $space . Sql::notExcluded('p.user_id', $scope) . '
             ORDER BY (COALESCE(c.n, 0) + COALESCE(r.n, 0)) DESC, comments DESC, p.created_at DESC
             LIMIT ' . (int)$limit
        );

        return self::decoratePosts($rows);
    }

    /**
     * content.topics. Driven from posts in the range (STRAIGHT_JOIN), which
     * measured 35x faster than starting from term_feed (11-query-cost).
     *
     * @param string $taxonomy post_topic|hashtag
     * @return array rows: title, posts
     */
    public static function topics(Range $range, Scope $scope, $taxonomy = 'post_topic', $limit = 15)
    {
        $taxonomy = $taxonomy === 'hashtag' ? 'hashtag' : 'post_topic';
        $space = $scope->spaceId() ? ' AND p.space_id = ' . $scope->spaceId() : '';

        return array_map(function ($row) {
            return [ 'term_id' => (int)$row['id'], 'title' => $row['title'], 'posts' => (int)$row['n'] ];
        }, Sql::rows(
            'SELECT STRAIGHT_JOIN t.id, t.title, COUNT(*) AS n
             FROM ' . Sql::table('fcom_posts') . ' p
             INNER JOIN ' . Sql::table('fcom_term_feed') . ' tf ON tf.post_id = p.id
             INNER JOIN ' . Sql::table('fcom_terms') . " t ON t.id = tf.term_id AND t.taxonomy_name = '{$taxonomy}'
             WHERE " . Sql::isPost('p') . ' AND ' . Sql::inRange('p.created_at', $range) . $space . Sql::notExcluded('p.user_id', $scope) . '
             GROUP BY t.id, t.title
             ORDER BY n DESC, t.title ASC
             LIMIT ' . (int)$limit
        ));
    }

    /**
     * content.types: posts by content_type.
     *
     * @return array rows: type, posts
     */
    public static function types(Range $range, Scope $scope)
    {
        $space = $scope->spaceId() ? ' AND p.space_id = ' . $scope->spaceId() : '';

        return array_map(function ($row) {
            return [ 'type' => $row['content_type'] ? $row['content_type'] : 'text', 'posts' => (int)$row['n'] ];
        }, Sql::rows(
            'SELECT p.content_type, COUNT(*) AS n FROM ' . Sql::table('fcom_posts') . ' p
             WHERE ' . Sql::isPost('p') . ' AND ' . Sql::inRange('p.created_at', $range) . $space . Sql::notExcluded('p.user_id', $scope) . '
             GROUP BY p.content_type ORDER BY n DESC'
        ));
    }

    /**
     * content.bookmarks: posts bookmarked most in the range.
     *
     * @return array rows
     */
    public static function bookmarks(Range $range, Scope $scope, $limit = 10)
    {
        $posts = Sql::table('fcom_posts');
        $space = $scope->spaceId() ? ' AND p.space_id = ' . $scope->spaceId() : '';

        $rows = Sql::rows(
            "SELECT p.id, p.title, p.message, p.slug, p.space_id, p.user_id, p.created_at, b.n AS bookmarks
             FROM (SELECT r.object_id, COUNT(*) AS n FROM " . Sql::table('fcom_post_reactions') . " r
                   WHERE r.object_type = 'feed' AND r.type = 'bookmark' AND " . Sql::inRange('r.created_at', $range) . Sql::notExcluded('r.user_id', $scope) . " GROUP BY r.object_id) b
             INNER JOIN {$posts} p ON p.id = b.object_id
             WHERE " . Sql::isPost('p') . $space . '
             ORDER BY b.n DESC, p.id DESC
             LIMIT ' . (int)$limit
        );

        return self::decoratePosts($rows);
    }

    /**
     * Adds a plain-text excerpt, space title, author name and link. Excerpts
     * are text only; the UI never renders them as HTML.
     *
     * @param array $rows
     * @return array
     */
    public static function decoratePosts(array $rows)
    {
        if (!$rows) {
            return [];
        }

        $spaceIds = array_unique(array_filter(array_map('intval', array_column($rows, 'space_id'))));
        $spaces = [];
        if ($spaceIds) {
            foreach (Sql::rows('SELECT id, title, slug, type FROM ' . Sql::table('fcom_spaces') . " WHERE type IN ('community', 'course') AND id IN (" . implode(',', $spaceIds) . ')') as $space) {
                $spaces[(int)$space['id']] = $space;
            }
        }

        $authors = MemberMetrics::publicProfiles(array_unique(array_filter(array_map('intval', array_column($rows, 'user_id')))));

        return array_map(function ($row) use ($spaces, $authors) {
            $space = isset($spaces[(int)$row['space_id']]) ? $spaces[(int)$row['space_id']] : null;
            $path = 'post/' . $row['slug'];
            if ($space) {
                $path = ($space['type'] === 'course' ? 'course/' : 'space/') . $space['slug'] . '/post/' . $row['slug'];
            }
            $author = isset($authors[(int)$row['user_id']]) ? $authors[(int)$row['user_id']] : null;
            $excerpt = Helper::getHumanExcerpt($row['title'] ? $row['title'] : self::messageOf($row), 80);
            unset($row['message']);

            return array_merge($row, [
                'id'           => (int)$row['id'],
                'excerpt'      => $excerpt,
                'link'         => Helper::baseUrl($path),
                'space'        => $space ? $space['title'] : '',
                'author'       => $author ? $author['display_name'] : '',
                'profile_link' => $author ? $author['profile_link'] : '',
                'avatar'       => $author ? $author['avatar'] : '',
            ]);
        }, $rows);
    }

    private static function messageOf($row)
    {
        return isset($row['message']) ? wp_strip_all_tags((string)$row['message']) : '';
    }
}
