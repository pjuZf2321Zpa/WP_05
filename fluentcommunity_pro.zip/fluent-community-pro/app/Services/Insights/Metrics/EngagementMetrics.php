<?php

namespace FluentCommunityPro\App\Services\Insights\Metrics;

use FluentCommunity\App\Services\Insights\Metrics\MemberMetrics as BaseMemberMetrics;
use FluentCommunity\App\Services\Insights\Metrics\ResponseMetrics;
use FluentCommunity\App\Services\Insights\Metrics\Sql;
use FluentCommunity\App\Services\Insights\Range;
use FluentCommunity\App\Services\Insights\Scope;

/**
 * members.dau/wau/mau, members.stickiness, timing.heatmap,
 * participation.tiers, response.buckets (free docs/reporting/03).
 */
class EngagementMetrics
{
    const TIERS = [ '0' => 0, '1-2' => 2, '3-10' => 10, '11-50' => 50, '50+' => PHP_INT_MAX ];

    /**
     * Distinct active members per local day, from contributions and (when
     * visits are tracked for the whole window) visits.
     *
     * @param Range $range the days to report; 29 earlier days are read too, for the rolling windows
     * @param Scope $scope
     * @param bool $withVisits
     * @return array 'Y-m-d' => int[] user ids
     */
    public static function userDays(Range $range, Scope $scope, $withVisits)
    {
        $window = Range::fromDates($range->from()->modify('-29 days')->format('Y-m-d'), $range->toDate());
        $union = BaseMemberMetrics::contributionUnion($window, $scope);

        if ($withVisits && !$scope->spaceId()) {
            $union[] = 'SELECT d.user_id, d.stat_date AS created_at FROM ' . Sql::table('fcom_activity_daily') . " d
                        WHERE d.visits > 0 AND d.stat_date >= '" . $window->fromDate() . "' AND d.stat_date <= '" . $window->toDate() . "'";
        }

        $rows = Sql::rows(
            'SELECT DISTINCT a.user_id, DATE(a.created_at) AS d FROM (' . implode(' UNION ALL ', $union) . ') a
             WHERE a.user_id IS NOT NULL AND a.user_id > 0' . Sql::notExcluded('a.user_id', $scope)
        );

        $days = [];
        foreach ($rows as $row) {
            $days[$row['d']][] = (int)$row['user_id'];
        }

        return $days;
    }

    /**
     * Rolling distinct actives ending on each day of the range: 1, 7 and 30
     * days. A sliding window with per-member counts, so it is linear in the
     * number of user-days rather than days x window x members.
     *
     * @param array $userDays from userDays()
     * @param Range $range
     * @return array ['days' => string[], 'dau' => int[], 'wau' => int[], 'mau' => int[]]
     */
    public static function rolling(array $userDays, Range $range)
    {
        $first = $range->from()->modify('-29 days');
        $dates = [];
        $last = $range->toDate();
        $cursor = $first;
        while ($cursor->format('Y-m-d') <= $last) {
            $dates[] = $cursor->format('Y-m-d');
            $cursor = $cursor->modify('+1 day');
        }

        $result = [ 'days' => [], 'dau' => [], 'wau' => [], 'mau' => [] ];
        $windows = [ 'wau' => 7, 'mau' => 30 ];
        $counts = [ 'wau' => [], 'mau' => [] ];

        foreach ($dates as $index => $date) {
            foreach ($windows as $name => $size) {
                foreach (isset($userDays[$date]) ? $userDays[$date] : [] as $userId) {
                    $counts[$name][$userId] = (isset($counts[$name][$userId]) ? $counts[$name][$userId] : 0) + 1;
                }

                $leaving = $index - $size >= 0 ? $dates[$index - $size] : null;
                if ($leaving && isset($userDays[$leaving])) {
                    foreach ($userDays[$leaving] as $userId) {
                        if (--$counts[$name][$userId] === 0) {
                            unset($counts[$name][$userId]);
                        }
                    }
                }
            }

            if ($date < $range->fromDate()) {
                continue;
            }

            $result['days'][] = $date;
            $result['dau'][] = isset($userDays[$date]) ? count($userDays[$date]) : 0;
            $result['wau'][] = count($counts['wau']);
            $result['mau'][] = count($counts['mau']);
        }

        return $result;
    }

    /**
     * timing.heatmap: contributions by weekday and hour in site time. One
     * GROUP BY per source, merged in PHP (cheaper than a UNION of raw rows).
     *
     * @param Range $range
     * @param Scope $scope
     * @param int $weekStart 0 = Sunday
     * @return array rows (weekday labels from week start), cols, values [7][24], max
     */
    public static function heatmap(Range $range, Scope $scope, $weekStart)
    {
        $grid = array_fill(0, 7, array_fill(0, 24, 0));

        foreach (self::heatmapSources($range, $scope) as $sql) {
            foreach (Sql::rows($sql) as $row) {
                $grid[(int)$row['wd']][(int)$row['h']] += (int)$row['n'];
            }
        }

        // WEEKDAY() is 0 = Monday; start_of_week is 0 = Sunday.
        $order = [];
        for ($i = 0; $i < 7; $i++) {
            $order[] = (($weekStart + $i) % 7 + 6) % 7;
        }

        $names = self::weekdayNames();
        $rows = [];
        $values = [];
        $max = 0;
        foreach ($order as $weekday) {
            $rows[] = $names[$weekday];
            $values[] = $grid[$weekday];
            $max = max($max, max($grid[$weekday]));
        }

        return [ 'rows' => $rows, 'cols' => range(0, 23), 'values' => $values, 'max' => $max ];
    }

    /**
     * participation.tiers: members who existed at the end of the range, by
     * how many posts and comments they wrote in it.
     *
     * @param Range $range
     * @param Scope $scope
     * @return array tier key => count
     */
    public static function participation(Range $range, Scope $scope)
    {
        $posts = Sql::table('fcom_posts');
        $comments = Sql::table('fcom_post_comments');
        $profiles = Sql::table('fcom_xprofile');
        $before = $range->sqlToExclusive();

        if ($scope->spaceId()) {
            $spaceId = $scope->spaceId();
            $members = "SELECT su.user_id FROM " . Sql::table('fcom_space_user') . " su WHERE su.space_id = {$spaceId} AND su.status = 'active' AND su.created_at < '{$before}'";
            $contributions = "SELECT p.user_id FROM {$posts} p WHERE " . Sql::isPost('p') . ' AND ' . Sql::inRange('p.created_at', $range) . " AND p.space_id = {$spaceId}
                UNION ALL SELECT c.user_id FROM {$comments} c INNER JOIN {$posts} p ON p.id = c.post_id AND p.space_id = {$spaceId} WHERE " . Sql::isComment('c') . ' AND ' . Sql::inRange('c.created_at', $range);
        } else {
            $members = "SELECT x.user_id FROM {$profiles} x WHERE x.status = 'active' AND x.created_at < '{$before}'";
            $contributions = "SELECT p.user_id FROM {$posts} p WHERE " . Sql::isPost('p') . ' AND ' . Sql::inRange('p.created_at', $range) . "
                UNION ALL SELECT c.user_id FROM {$comments} c WHERE " . Sql::isComment('c') . ' AND ' . Sql::inRange('c.created_at', $range);
        }

        $rows = Sql::rows(
            "SELECT CASE WHEN n IS NULL THEN '0' WHEN n <= 2 THEN '1-2' WHEN n <= 10 THEN '3-10' WHEN n <= 50 THEN '11-50' ELSE '50+' END AS tier, COUNT(*) AS members
             FROM ({$members}) m
             LEFT JOIN (SELECT u.user_id, COUNT(*) AS n FROM ({$contributions}) u WHERE u.user_id IS NOT NULL GROUP BY u.user_id) t ON t.user_id = m.user_id
             WHERE 1 = 1" . Sql::notExcluded('m.user_id', $scope) . '
             GROUP BY tier'
        );

        $tiers = array_fill_keys(array_keys(self::TIERS), 0);
        foreach ($rows as $row) {
            $tiers[$row['tier']] = (int)$row['members'];
        }

        return $tiers;
    }

    /**
     * response.buckets: posts by time to first reply, plus those never answered.
     *
     * @return array bucket key => count
     */
    public static function replyBuckets(Range $range, Scope $scope)
    {
        $replies = ResponseMetrics::firstReplyMinutes($range, $scope);
        $buckets = [ 'lt_1h' => 0, '1_4h' => 0, '4_24h' => 0, '1_3d' => 0, 'gt_3d' => 0 ];

        foreach ($replies['minutes'] as $minutes) {
            if ($minutes < 60) {
                ++$buckets['lt_1h'];
            } elseif ($minutes < 240) {
                ++$buckets['1_4h'];
            } elseif ($minutes < 1440) {
                ++$buckets['4_24h'];
            } elseif ($minutes < 4320) {
                ++$buckets['1_3d'];
            } else {
                ++$buckets['gt_3d'];
            }
        }

        $buckets['never'] = $replies['eligible'] - count($replies['minutes']);

        return $buckets;
    }

    private static function heatmapSources(Range $range, Scope $scope)
    {
        $posts = Sql::table('fcom_posts');
        $comments = Sql::table('fcom_post_comments');
        $reactions = Sql::table('fcom_post_reactions');
        $excluded = function ($column) use ($scope) {
            return Sql::notExcluded($column, $scope);
        };

        if ($scope->spaceId()) {
            $spaceId = $scope->spaceId();

            return [
                "SELECT WEEKDAY(p.created_at) AS wd, HOUR(p.created_at) AS h, COUNT(*) AS n FROM {$posts} p WHERE " . Sql::isPost('p') . ' AND ' . Sql::inRange('p.created_at', $range) . " AND p.space_id = {$spaceId}" . $excluded('p.user_id') . ' GROUP BY wd, h',
                "SELECT WEEKDAY(c.created_at) AS wd, HOUR(c.created_at) AS h, COUNT(*) AS n FROM {$comments} c INNER JOIN {$posts} p ON p.id = c.post_id AND p.space_id = {$spaceId} WHERE " . Sql::isComment('c') . ' AND ' . Sql::inRange('c.created_at', $range) . $excluded('c.user_id') . ' GROUP BY wd, h',
                "SELECT WEEKDAY(r.created_at) AS wd, HOUR(r.created_at) AS h, COUNT(*) AS n FROM {$reactions} r INNER JOIN {$posts} p ON p.id = " . Sql::reactionPostId('r') . " AND p.space_id = {$spaceId} WHERE " . Sql::isReaction('r') . ' AND ' . Sql::inRange('r.created_at', $range) . $excluded('r.user_id') . ' GROUP BY wd, h',
            ];
        }

        $sources = [
            "SELECT WEEKDAY(p.created_at) AS wd, HOUR(p.created_at) AS h, COUNT(*) AS n FROM {$posts} p WHERE " . Sql::isPost('p') . ' AND ' . Sql::inRange('p.created_at', $range) . $excluded('p.user_id') . ' GROUP BY wd, h',
            "SELECT WEEKDAY(c.created_at) AS wd, HOUR(c.created_at) AS h, COUNT(*) AS n FROM {$comments} c WHERE " . Sql::isComment('c') . ' AND ' . Sql::inRange('c.created_at', $range) . $excluded('c.user_id') . ' GROUP BY wd, h',
            "SELECT WEEKDAY(r.created_at) AS wd, HOUR(r.created_at) AS h, COUNT(*) AS n FROM {$reactions} r WHERE " . Sql::isReaction('r') . ' AND ' . Sql::inRange('r.created_at', $range) . $excluded('r.user_id') . ' GROUP BY wd, h',
        ];

        if (Sql::hasChatTable()) {
            $sources[] = 'SELECT WEEKDAY(m.created_at) AS wd, HOUR(m.created_at) AS h, COUNT(*) AS n FROM ' . Sql::table('fcom_chat_messages') . ' m WHERE ' . Sql::inRange('m.created_at', $range) . $excluded('m.user_id') . ' GROUP BY wd, h';
        }

        return $sources;
    }

    /**
     * Ported from the old AnalyticsService::generateWeekdays(): localised
     * weekday names, 0 = Monday to match WEEKDAY().
     *
     * @return string[]
     */
    private static function weekdayNames()
    {
        global $wp_locale;
        $names = [ 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun' ];

        if (!$wp_locale) {
            return $names;
        }

        // WP_Locale::get_weekday() is 0 = Sunday.
        for ($weekday = 0; $weekday < 7; $weekday++) {
            $names[$weekday] = $wp_locale->get_weekday_abbrev($wp_locale->get_weekday(($weekday + 1) % 7));
        }

        return $names;
    }
}
