<?php

namespace FluentCommunityPro\App\Services\Insights\Metrics;

use FluentCommunity\App\Services\Insights\Metrics\Sql;
use FluentCommunity\App\Services\Insights\Range;
use FluentCommunity\App\Services\Insights\Scope;
use FluentCommunity\Modules\Course\Services\CourseHelper;

/**
 * course.lesson_funnel and the per-student table (free docs/reporting/03).
 */
class CourseMetrics
{
    /**
     * The course to report on: the scope's, or else the one with the most
     * active students.
     *
     * @return array|null id, title, slug
     */
    public static function resolveCourse(Scope $scope)
    {
        $spaces = Sql::table('fcom_spaces');

        if ($scope->courseId()) {
            $rows = Sql::rows("SELECT s.id, s.title, s.slug FROM {$spaces} s WHERE s.type = 'course' AND s.id = " . $scope->courseId());

            return $rows ? $rows[0] : null;
        }

        $rows = Sql::rows(
            "SELECT s.id, s.title, s.slug FROM {$spaces} s
             LEFT JOIN " . Sql::table('fcom_space_user') . " su ON su.space_id = s.id AND su.role = 'student' AND su.status = 'active'
             WHERE s.type = 'course' GROUP BY s.id, s.title, s.slug ORDER BY COUNT(su.id) DESC, s.id ASC LIMIT 1"
        );

        return $rows ? $rows[0] : null;
    }

    /**
     * For each published lesson in curriculum order, the share of the
     * course's active students who completed it.
     *
     * @return array steps[]: key, label, group, value, rate; students
     */
    public static function lessonFunnel($courseId, Scope $scope)
    {
        $courseId = (int)$courseId;
        $posts = Sql::table('fcom_posts');

        $lessons = Sql::rows(
            "SELECT l.id, l.title, sec.title AS section
             FROM {$posts} l
             LEFT JOIN {$posts} sec ON sec.id = l.parent_id AND sec.type = 'course_section'
             WHERE l.type = 'course_lesson' AND l.status = 'published' AND l.space_id = {$courseId}
             ORDER BY COALESCE(sec.priority, 0) ASC, COALESCE(sec.id, 0) ASC, l.priority ASC, l.id ASC"
        );

        $students = (int)Sql::value(
            'SELECT COUNT(*) FROM ' . Sql::table('fcom_space_user') . " su WHERE su.space_id = {$courseId} AND su.role = 'student' AND su.status = 'active'" . Sql::notExcluded('su.user_id', $scope)
        );

        $completed = [];
        foreach (Sql::rows(
            'SELECT r.object_id, COUNT(DISTINCT r.user_id) AS n FROM ' . Sql::table('fcom_post_reactions') . ' r
             INNER JOIN ' . Sql::table('fcom_space_user') . " su ON su.user_id = r.user_id AND su.space_id = {$courseId} AND su.role = 'student' AND su.status = 'active'
             WHERE " . Sql::isLessonCompletion('r') . " AND r.parent_id = {$courseId}" . Sql::notExcluded('r.user_id', $scope) . '
             GROUP BY r.object_id'
        ) as $row) {
            $completed[(int)$row['object_id']] = (int)$row['n'];
        }

        $steps = array_map(function ($lesson) use ($completed, $students) {
            $value = isset($completed[(int)$lesson['id']]) ? $completed[(int)$lesson['id']] : 0;

            return [
                'key'   => 'lesson:' . (int)$lesson['id'],
                'label' => $lesson['title'],
                'group' => (string)$lesson['section'],
                'value' => $value,
                'rate'  => $students ? round($value / $students, 4) : 0,
            ];
        }, $lessons);

        return [ 'steps' => $steps, 'students' => $students ];
    }

    /**
     * @return int active students of the course
     */
    public static function studentCount($courseId, Scope $scope)
    {
        return (int)Sql::value(
            'SELECT COUNT(*) FROM ' . Sql::table('fcom_space_user') . ' su WHERE su.space_id = ' . (int)$courseId . " AND su.role = 'student' AND su.status = 'active'" . Sql::notExcluded('su.user_id', $scope)
        );
    }

    /**
     * One row per active student: progress (the course pages' formula),
     * enrollment date and completion date.
     *
     * @return array rows
     */
    public static function students($courseId, Scope $scope, $limit = 100)
    {
        $courseId = (int)$courseId;
        $rows = Sql::rows(
            'SELECT su.user_id, su.created_at AS enrolled_at,
                (SELECT MAX(a.created_at) FROM ' . Sql::table('fcom_user_activities') . " a WHERE a.action_name = 'course_completed' AND a.feed_id = su.space_id AND a.user_id = su.user_id) AS completed_at
             FROM " . Sql::table('fcom_space_user') . " su
             WHERE su.space_id = {$courseId} AND su.role = 'student' AND su.status = 'active'" . Sql::notExcluded('su.user_id', $scope) . '
             ORDER BY su.created_at DESC
             LIMIT ' . (int)$limit
        );

        if (!$rows) {
            return [];
        }

        $userIds = array_map('intval', array_column($rows, 'user_id'));
        $progress = CourseHelper::getBulkCourseProgress($courseId, $userIds);
        $profiles = MemberMetrics::publicProfiles($userIds);

        $students = array_map(function ($row) use ($progress, $profiles) {
            $userId = (int)$row['user_id'];

            return array_merge(isset($profiles[$userId]) ? $profiles[$userId] : [ 'user_id' => $userId ], [
                'progress'     => isset($progress[$userId]) ? (float)$progress[$userId] : 0.0,
                'enrolled_at'  => $row['enrolled_at'],
                'completed_at' => $row['completed_at'],
            ]);
        }, $rows);

        usort($students, function ($first, $second) {
            return $second['progress'] <=> $first['progress'];
        });

        return $students;
    }
}
