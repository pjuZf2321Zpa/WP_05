<?php

namespace FluentCommunityPro\App\Services\Insights\Metrics;

use FluentCommunity\App\Services\Insights\Bucketer;
use FluentCommunity\App\Services\Insights\Metrics\ResponseMetrics;
use FluentCommunity\App\Services\Insights\Metrics\Sql;
use FluentCommunity\App\Services\Insights\Range;
use FluentCommunity\App\Services\Insights\Scope;

/**
 * mod.* (free docs/reporting/03). Reports are fcom_post_comments rows with
 * type = 'report'; post_id is the reported post.
 */
class ModerationMetrics
{
    const RESOLVED = [ 'ignored', 'unpublished', 'published' ];

    /**
     * mod.reports_received per bucket, by current status.
     *
     * @return array status => [bucket key => count]
     */
    public static function receivedByStatus(Range $range, Scope $scope, Bucketer $bucketer)
    {
        $bucket = $bucketer->sqlExpression('r.created_at');
        $byStatus = [];

        foreach (Sql::rows("SELECT r.status, {$bucket} AS k, COUNT(*) AS n FROM " . self::from($scope) . ' WHERE ' . self::where($range) . ' GROUP BY r.status, k') as $row) {
            $byStatus[$row['status']][$row['k']] = (int)$row['n'];
        }

        return $byStatus;
    }

    /**
     * @return array status => count of reports created in the range
     */
    public static function outcomes(Range $range, Scope $scope)
    {
        $counts = [];
        foreach (Sql::rows('SELECT r.status, COUNT(*) AS n FROM ' . self::from($scope) . ' WHERE ' . self::where($range) . ' GROUP BY r.status') as $row) {
            $counts[$row['status']] = (int)$row['n'];
        }

        return $counts;
    }

    /**
     * mod.open: reports still flagged or pending, now.
     */
    public static function openCount(Scope $scope)
    {
        return (int)Sql::value('SELECT COUNT(*) FROM ' . self::from($scope) . " WHERE r.type = 'report' AND r.status IN ('flagged', 'pending')");
    }

    /**
     * mod.resolution_median (minutes; "time to last action", since the row
     * keeps no separate resolved_at) and mod.actioned_rate.
     *
     * @return array median_minutes, resolved, actioned_rate
     */
    public static function resolution(Range $range, Scope $scope)
    {
        $rows = Sql::rows(
            'SELECT r.status, TIMESTAMPDIFF(MINUTE, r.created_at, r.updated_at) AS m FROM ' . self::from($scope) . '
             WHERE ' . self::where($range) . " AND r.status IN ('" . implode("', '", self::RESOLVED) . "')"
        );

        $minutes = array_map(function ($row) {
            return max(0, (int)$row['m']);
        }, $rows);
        sort($minutes);

        $unpublished = count(array_filter($rows, function ($row) {
            return $row['status'] === 'unpublished';
        }));

        return [
            'median_minutes' => ResponseMetrics::median($minutes),
            'resolved'       => count($rows),
            'actioned_rate'  => $rows ? round($unpublished / count($rows), 4) : null,
        ];
    }

    /**
     * mod.top_reported: authors whose posts were reported most in the range.
     *
     * @return array rows with public member fields + reports
     */
    public static function topReported(Range $range, Scope $scope, $limit = 10)
    {
        // A comment report keeps the comment id in parent_id: blame the
        // commenter, not the author of the post the comment sits on.
        $author = "(CASE WHEN r.content_type = 'comment' THEN rc.user_id ELSE p.user_id END)";
        $rows = Sql::rows(
            "SELECT {$author} AS user_id, COUNT(*) AS n FROM " . self::from($scope, true) . '
             LEFT JOIN ' . Sql::table('fcom_post_comments') . " rc ON r.content_type = 'comment' AND rc.id = r.parent_id
             WHERE " . self::where($range) . " AND {$author} IS NOT NULL" . Sql::notExcluded($author, $scope) . "
             GROUP BY {$author} ORDER BY n DESC, user_id ASC LIMIT " . (int)$limit
        );

        $profiles = MemberMetrics::publicProfiles(array_map('intval', array_column($rows, 'user_id')));

        return array_map(function ($row) use ($profiles) {
            $userId = (int)$row['user_id'];

            return array_merge(isset($profiles[$userId]) ? $profiles[$userId] : [ 'user_id' => $userId ], [ 'reports' => (int)$row['n'] ]);
        }, $rows);
    }

    private static function from(Scope $scope, $joinPosts = false)
    {
        $from = Sql::table('fcom_post_comments') . ' r';

        if ($scope->spaceId() || $joinPosts) {
            $from .= ' INNER JOIN ' . Sql::table('fcom_posts') . ' p ON p.id = r.post_id' . ($scope->spaceId() ? ' AND p.space_id = ' . $scope->spaceId() : '');
        }

        return $from;
    }

    private static function where(Range $range)
    {
        return "r.type = 'report' AND " . Sql::inRange('r.created_at', $range);
    }
}
