<?php

namespace FluentCommunityPro\App\Services\Insights\Metrics;

use FluentCommunity\App\Models\XProfile;
use FluentCommunity\App\Services\Insights\Bucketer;
use FluentCommunity\App\Services\Insights\Metrics\MemberMetrics as BaseMemberMetrics;
use FluentCommunity\App\Services\Insights\Metrics\ResponseMetrics;
use FluentCommunity\App\Services\Insights\Metrics\Sql;
use FluentCommunity\App\Services\Insights\Range;
use FluentCommunity\App\Services\Insights\Scope;

/**
 * Growth, activation, retention cohorts, top contributors and at-risk
 * regulars (free docs/reporting/03).
 */
class MemberMetrics
{
    /**
     * members.total at the end of each bucket (active members only).
     *
     * @return array bucket key => count
     */
    public static function totalByBucket(Range $range, Scope $scope, Bucketer $bucketer)
    {
        $profiles = Sql::table('fcom_xprofile');
        $bucket = $bucketer->sqlExpression('x.created_at');

        $added = Sql::keyed(
            "SELECT {$bucket} AS k, COUNT(*) AS n FROM {$profiles} x
             WHERE x.status = 'active' AND " . Sql::inRange('x.created_at', $range) . Sql::notExcluded('x.user_id', $scope) . '
             GROUP BY k'
        );

        $running = BaseMemberMetrics::totalAt($range->from()->modify('-1 day'), $scope->withSpace(null));
        $totals = [];
        foreach ($bucketer->keys() as $key) {
            $running += isset($added[$key]) ? $added[$key] : 0;
            $totals[$key] = $running;
        }

        return $totals;
    }

    /**
     * activation.first_contrib_7d and activation.time_to_first_post.
     * Members younger than 7 days at the end of the range are not judged yet.
     *
     * @return array eligible, activated, rate, median_days_to_first_post
     */
    public static function activation(Range $range, Scope $scope)
    {
        $profiles = Sql::table('fcom_xprofile');
        $posts = Sql::table('fcom_posts');
        $comments = Sql::table('fcom_post_comments');
        $reactions = Sql::table('fcom_post_reactions');

        $judgedBefore = $range->to()->modify('-7 days')->format('Y-m-d H:i:s');
        $newMembers = Sql::rows(
            "SELECT x.user_id, x.created_at FROM {$profiles} x
             WHERE " . Sql::inRange('x.created_at', $range) . " AND x.created_at <= '{$judgedBefore}'" . Sql::notExcluded('x.user_id', $scope)
        );

        // One grouped MIN() per source over the new members, compared in PHP.
        // A correlated EXISTS per member took 5 s on the sandbox.
        $firstContribution = [];
        if ($newMembers) {
            $ids = implode(',', array_map('intval', array_column($newMembers, 'user_id')));
            $window = Sql::between('s.created_at', $range->sqlFrom(), $range->to()->modify('+8 days')->format('Y-m-d 00:00:00'));
            $sources = [
                "SELECT s.user_id, MIN(s.created_at) AS first_at FROM {$posts} s WHERE " . Sql::isPost('s') . " AND {$window} AND s.user_id IN ({$ids}) GROUP BY s.user_id",
                "SELECT s.user_id, MIN(s.created_at) AS first_at FROM {$comments} s WHERE " . Sql::isComment('s') . " AND {$window} AND s.user_id IN ({$ids}) GROUP BY s.user_id",
                "SELECT s.user_id, MIN(s.created_at) AS first_at FROM {$reactions} s WHERE (" . Sql::isReaction('s') . ' OR ' . Sql::isLessonCompletion('s') . ") AND {$window} AND s.user_id IN ({$ids}) GROUP BY s.user_id",
            ];
            if (Sql::hasChatTable()) {
                $sources[] = 'SELECT s.user_id, MIN(s.created_at) AS first_at FROM ' . Sql::table('fcom_chat_messages') . " s WHERE {$window} AND s.user_id IN ({$ids}) GROUP BY s.user_id";
            }
            foreach ($sources as $sql) {
                foreach (Sql::rows($sql) as $row) {
                    $userId = (int)$row['user_id'];
                    if (!isset($firstContribution[$userId]) || $row['first_at'] < $firstContribution[$userId]) {
                        $firstContribution[$userId] = $row['first_at'];
                    }
                }
            }
        }

        $eligible = count($newMembers);
        $activated = 0;
        foreach ($newMembers as $member) {
            $first = isset($firstContribution[(int)$member['user_id']]) ? $firstContribution[(int)$member['user_id']] : null;
            if ($first && $first >= $member['created_at'] && strtotime($first) - strtotime($member['created_at']) < 7 * DAY_IN_SECONDS) {
                ++$activated;
            }
        }

        $firstPosts = Sql::rows(
            "SELECT TIMESTAMPDIFF(MINUTE, x.created_at, f.first_post) AS m FROM {$profiles} x
             INNER JOIN (SELECT p.user_id, MIN(p.created_at) AS first_post FROM {$posts} p
                         WHERE " . Sql::isPost('p') . " AND p.created_at >= '" . $range->sqlFrom() . "' GROUP BY p.user_id) f ON f.user_id = x.user_id
             WHERE " . Sql::inRange('x.created_at', $range) . ' AND f.first_post >= x.created_at' . Sql::notExcluded('x.user_id', $scope)
        );

        $minutes = array_map('intval', array_column($firstPosts, 'm'));
        sort($minutes);

        return [
            'eligible'                     => $eligible,
            'activated'                    => $activated,
            'rate'                         => $eligible ? round($activated / $eligible, 4) : null,
            'median_minutes_to_first_post' => ResponseMetrics::median($minutes),
        ];
    }

    /**
     * retention.cohorts: monthly signup cohorts (at most 12, from the range),
     * and the share of each that was active (contributed, or visited once
     * visits are tracked) in each later calendar month. Months after the
     * range end are null.
     *
     * @return array cohorts[] (key, size, values[]), periods
     */
    public static function cohorts(Range $range, Scope $scope)
    {
        $profiles = Sql::table('fcom_xprofile');
        $firstMonth = $range->from()->modify('first day of this month');
        $earliest = $range->to()->modify('first day of this month')->modify('-11 months');
        if ($firstMonth < $earliest) {
            $firstMonth = $earliest;
        }

        $activityRange = Range::fromDates($firstMonth->format('Y-m-d'), $range->toDate());
        $union = BaseMemberMetrics::contributionUnion($activityRange, $scope->withSpace(null));
        // Same definition in every cell: visits only when tracking covers all of them.
        $withVisits = BaseMemberMetrics::visitsCover($activityRange);
        if ($withVisits) {
            $union[] = 'SELECT d.user_id, d.stat_date AS created_at FROM ' . Sql::table('fcom_activity_daily') . " d
                        WHERE d.visits > 0 AND d.stat_date >= '" . $activityRange->fromDate() . "' AND d.stat_date <= '" . $activityRange->toDate() . "'";
        }

        $rows = Sql::rows(
            "SELECT coh.cm, PERIOD_DIFF(act.m, coh.cm) AS k, COUNT(DISTINCT act.user_id) AS active
             FROM (SELECT x.user_id, EXTRACT(YEAR_MONTH FROM x.created_at) AS cm FROM {$profiles} x
                   WHERE x.created_at >= '" . $firstMonth->format('Y-m-d 00:00:00') . "' AND x.created_at < '" . $range->sqlToExclusive() . "'" . Sql::notExcluded('x.user_id', $scope) . ") coh
             INNER JOIN (SELECT DISTINCT a.user_id, EXTRACT(YEAR_MONTH FROM a.created_at) AS m FROM (" . implode(' UNION ALL ', $union) . ") a
                         WHERE a.user_id IS NOT NULL) act ON act.user_id = coh.user_id AND act.m >= coh.cm
             GROUP BY coh.cm, k"
        );

        $sizes = Sql::rows(
            "SELECT EXTRACT(YEAR_MONTH FROM x.created_at) AS cm, COUNT(*) AS size FROM {$profiles} x
             WHERE x.created_at >= '" . $firstMonth->format('Y-m-d 00:00:00') . "' AND x.created_at < '" . $range->sqlToExclusive() . "'" . Sql::notExcluded('x.user_id', $scope) . '
             GROUP BY cm ORDER BY cm'
        );

        $active = [];
        foreach ($rows as $row) {
            $active[$row['cm']][(int)$row['k']] = (int)$row['active'];
        }

        $lastMonth = (int)$range->to()->format('Ym');
        $periods = 0;
        $cohorts = [];
        foreach ($sizes as $size) {
            $cohortMonth = (int)$size['cm'];
            $available = self::monthsBetween($cohortMonth, $lastMonth);
            $periods = max($periods, $available + 1);
            $values = [];
            for ($period = 0; $period < 12; $period++) {
                if ($period > $available) {
                    $values[] = null;
                    continue;
                }
                $count = isset($active[$size['cm']][$period]) ? $active[$size['cm']][$period] : 0;
                $values[] = round($count / (int)$size['size'], 4);
            }

            $cohorts[] = [
                'key'    => substr((string)$cohortMonth, 0, 4) . '-' . substr((string)$cohortMonth, 4, 2),
                'size'   => (int)$size['size'],
                'values' => array_slice($values, 0, 12),
            ];
        }

        foreach ($cohorts as &$cohort) {
            $cohort['values'] = array_slice($cohort['values'], 0, max(1, $periods));
        }

        return [ 'cohorts' => $cohorts, 'periods' => max(1, $periods), 'period_unit' => 'month', 'visits_tracked' => $withVisits ];
    }

    // One row per contributor with a score; the ranked rows and the summary share it so they never drift
    private static function contributorsSql(Range $range, Scope $scope)
    {
        /**
         * Score weights for top contributors.
         *
         * @param array $weights posts, comments, reactions
         */
        $weights = apply_filters('fluent_community/insights/contributor_weights', [ 'posts' => 3, 'comments' => 2, 'reactions' => 1 ]);
        $weights = array_map('floatval', array_merge([ 'posts' => 3, 'comments' => 2, 'reactions' => 1 ], (array)$weights));

        $posts = Sql::table('fcom_posts');
        $comments = Sql::table('fcom_post_comments');
        $reactions = Sql::table('fcom_post_reactions');
        $space = $scope->spaceId() ? (int)$scope->spaceId() : 0;

        $postsJoin = $space ? " INNER JOIN {$posts} sp ON sp.id = c.post_id AND sp.space_id = {$space}" : '';
        $reactionsJoin = $space ? " INNER JOIN {$posts} sp ON sp.id = " . Sql::reactionPostId('r') . " AND sp.space_id = {$space}" : '';

        return "SELECT u.user_id, SUM(u.src = 'post') AS posts, SUM(u.src = 'comment') AS comments, SUM(u.src = 'reaction') AS reactions_given,
             (" . sprintf('%F', $weights['posts']) . " * SUM(u.src = 'post') + " . sprintf('%F', $weights['comments']) . " * SUM(u.src = 'comment') + " . sprintf('%F', $weights['reactions']) . " * SUM(u.src = 'reaction')) AS score
             FROM (
                SELECT p.user_id, 'post' AS src FROM {$posts} p WHERE " . Sql::isPost('p') . ' AND ' . Sql::inRange('p.created_at', $range) . ($space ? " AND p.space_id = {$space}" : '') . "
                UNION ALL SELECT c.user_id, 'comment' FROM {$comments} c{$postsJoin} WHERE " . Sql::isComment('c') . ' AND ' . Sql::inRange('c.created_at', $range) . "
                UNION ALL SELECT r.user_id, 'reaction' FROM {$reactions} r{$reactionsJoin} WHERE " . Sql::isReaction('r') . ' AND ' . Sql::inRange('r.created_at', $range) . '
             ) u
             INNER JOIN ' . Sql::table('fcom_xprofile') . " x ON x.user_id = u.user_id AND x.status = 'active'
             WHERE u.user_id IS NOT NULL" . Sql::notExcluded('u.user_id', $scope) . '
             GROUP BY u.user_id';
    }

    /**
     * members.top_contributors: ranked by 3 x posts + 2 x comments + 1 x
     * reactions given in the range, with reactions received alongside.
     *
     * @param string $sort "<column>-asc|desc" for posts, comments, reactions_given or score; empty ranks by score
     * @return array rows with only public member fields
     */
    public static function topContributors(Range $range, Scope $scope, $limit = 10, $offset = 0, $sort = '')
    {
        list($column, $direction) = array_pad(explode('-', (string)$sort, 2), 2, '');
        $orderBy = in_array($column, [ 'posts', 'comments', 'reactions_given', 'score' ], true) ? $column . ($direction === 'asc' ? ' ASC' : ' DESC') : 'score DESC';

        $rows = Sql::rows(self::contributorsSql($range, $scope) . " ORDER BY {$orderBy}, u.user_id ASC LIMIT " . (int)$limit . ' OFFSET ' . (int)$offset);

        if (!$rows) {
            return [];
        }

        $userIds = array_map('intval', array_column($rows, 'user_id'));
        $received = self::reactionsReceived($range, $userIds, $scope->spaceId() ? (int)$scope->spaceId() : 0);
        $profiles = self::publicProfiles($userIds);

        $result = [];
        foreach ($rows as $row) {
            $userId = (int)$row['user_id'];
            $result[] = array_merge(isset($profiles[$userId]) ? $profiles[$userId] : [ 'user_id' => $userId ], [
                'posts'              => (int)$row['posts'],
                'comments'           => (int)$row['comments'],
                'reactions_given'    => (int)$row['reactions_given'],
                'reactions_received' => isset($received[$userId]) ? $received[$userId] : 0,
                'score'              => $row['score'] + 0,
            ]);
        }

        return $result;
    }

    // Ranked members and the top score, so every page scales its bars the same
    public static function contributorsSummary(Range $range, Scope $scope)
    {
        $row = Sql::rows('SELECT COUNT(*) AS total, MAX(t.score) AS max_score FROM (' . self::contributorsSql($range, $scope) . ') t');

        return [
            'total'     => $row ? (int)$row[0]['total'] : 0,
            'max_score' => $row ? (float)$row[0]['max_score'] : 0,
        ];
    }

    /**
     * members.at_risk: 5+ posts and comments in the 60 days before the last
     * 30, and no activity at all in the last 30 days of the range.
     *
     * @return array ['count' => int, 'rows' => public member rows]
     */
    public static function atRisk(Range $range, Scope $scope, $limit = 50)
    {
        $posts = Sql::table('fcom_posts');
        $comments = Sql::table('fcom_post_comments');

        $recentStart = $range->to()->modify('-29 days')->format('Y-m-d');
        $recent = Range::fromDates($recentStart, $range->toDate());
        $before = Range::fromDates($recent->from()->modify('-60 days')->format('Y-m-d'), $recent->from()->modify('-1 day')->format('Y-m-d'));

        $union = BaseMemberMetrics::contributionUnion($recent, $scope->withSpace(null));
        $union[] = 'SELECT d.user_id, d.stat_date AS created_at FROM ' . Sql::table('fcom_activity_daily') . " d
                    WHERE d.visits > 0 AND d.stat_date >= '" . $recent->fromDate() . "' AND d.stat_date <= '" . $recent->toDate() . "'";

        // LEFT JOIN … IS NULL, never NOT IN: NULL user ids would empty the result.
        $sql = "FROM (SELECT u.user_id, COUNT(*) AS n FROM (
                    SELECT p.user_id FROM {$posts} p WHERE " . Sql::isPost('p') . ' AND ' . Sql::inRange('p.created_at', $before) . "
                    UNION ALL SELECT c.user_id FROM {$comments} c WHERE " . Sql::isComment('c') . ' AND ' . Sql::inRange('c.created_at', $before) . '
                ) u WHERE u.user_id IS NOT NULL GROUP BY u.user_id HAVING n >= 5) regular
                LEFT JOIN (SELECT DISTINCT a.user_id FROM (' . implode(' UNION ALL ', $union) . ") a WHERE a.user_id IS NOT NULL) still ON still.user_id = regular.user_id
                INNER JOIN " . Sql::table('fcom_xprofile') . " x ON x.user_id = regular.user_id AND x.status = 'active'
                WHERE still.user_id IS NULL" . Sql::notExcluded('regular.user_id', $scope);

        $count = (int)Sql::value("SELECT COUNT(*) {$sql}");
        $rows = $count ? Sql::rows("SELECT regular.user_id, regular.n {$sql} ORDER BY regular.n DESC, regular.user_id ASC LIMIT " . (int)$limit) : [];

        $profiles = self::publicProfiles(array_map('intval', array_column($rows, 'user_id')));
        $lastSeen = self::lastContribution(array_map('intval', array_column($rows, 'user_id')));

        return [
            'count' => $count,
            'rows'  => array_map(function ($row) use ($profiles, $lastSeen) {
                $userId = (int)$row['user_id'];

                return array_merge(isset($profiles[$userId]) ? $profiles[$userId] : [ 'user_id' => $userId ], [
                    'earlier_contributions' => (int)$row['n'],
                    'last_contribution'     => isset($lastSeen[$userId]) ? $lastSeen[$userId] : null,
                ]);
            }, $rows),
        ];
    }

    /**
     * @return array active, pending, blocked
     */
    public static function statusCounts()
    {
        $rows = Sql::rows('SELECT x.status, COUNT(*) AS n FROM ' . Sql::table('fcom_xprofile') . " x WHERE x.status IN ('active', 'pending', 'blocked') GROUP BY x.status");
        $counts = [ 'active' => 0, 'pending' => 0, 'blocked' => 0 ];
        foreach ($rows as $row) {
            $counts[$row['status']] = (int)$row['n'];
        }

        return $counts;
    }

    /**
     * Display name, username, avatar, verified flag and profile link. Never
     * email or meta (old D19: the analytics returned whole profile rows).
     *
     * @param int[] $userIds
     * @return array user id => row
     */
    public static function publicProfiles(array $userIds)
    {
        if (!$userIds) {
            return [];
        }

        $profiles = [];
        foreach (XProfile::whereIn('user_id', $userIds)->get([ 'user_id', 'display_name', 'username', 'avatar', 'is_verified' ]) as $profile) {
            $profiles[(int)$profile->user_id] = [
                'user_id'      => (int)$profile->user_id,
                'display_name' => $profile->display_name,
                'username'     => $profile->username,
                'avatar'       => $profile->avatar,
                'is_verified'  => (int)$profile->is_verified,
                'profile_link' => $profile->getPermalink(),
            ];
        }

        return $profiles;
    }

    /**
     * Likes received on a member's posts and comments, counted by when the
     * like was given (the leaderboard's join structure).
     *
     * @param Range $range
     * @param int[] $userIds
     * @return array user id => count
     */
    private static function reactionsReceived(Range $range, array $userIds, $spaceId = 0)
    {
        $spaceId = (int)$spaceId;
        $ids = implode(',', array_map('intval', $userIds));
        $reactions = Sql::table('fcom_post_reactions');

        $rows = Sql::rows(
            "SELECT owner.user_id, COUNT(*) AS n FROM (
                SELECT p.user_id FROM {$reactions} r INNER JOIN " . Sql::table('fcom_posts') . " p ON p.id = r.object_id
                WHERE r.object_type = 'feed' AND r.type = 'like' AND " . Sql::inRange('r.created_at', $range) . " AND p.user_id IN ({$ids})" . ($spaceId ? " AND p.space_id = {$spaceId}" : '') . "
                UNION ALL
                SELECT c.user_id FROM {$reactions} r INNER JOIN " . Sql::table('fcom_post_comments') . " c ON c.id = r.object_id
                " . ($spaceId ? 'INNER JOIN ' . Sql::table('fcom_posts') . " cp ON cp.id = c.post_id AND cp.space_id = {$spaceId}" : '') . "
                WHERE r.object_type = 'comment' AND r.type = 'like' AND " . Sql::inRange('r.created_at', $range) . " AND c.user_id IN ({$ids})
             ) owner GROUP BY owner.user_id"
        );

        $map = [];
        foreach ($rows as $row) {
            $map[(int)$row['user_id']] = (int)$row['n'];
        }

        return $map;
    }

    private static function lastContribution(array $userIds)
    {
        if (!$userIds) {
            return [];
        }

        $ids = implode(',', array_map('intval', $userIds));
        $rows = Sql::rows(
            'SELECT d.user_id, MAX(d.stat_date) AS last_day FROM ' . Sql::table('fcom_activity_daily') . " d
             WHERE d.user_id IN ({$ids}) AND (d.posts + d.comments + d.reactions + d.messages + d.lessons) > 0 GROUP BY d.user_id"
        );

        return array_column($rows, 'last_day', 'user_id');
    }

    private static function monthsBetween($fromMonth, $toMonth)
    {
        $fromYear = intdiv($fromMonth, 100);
        $toYear = intdiv($toMonth, 100);

        return ($toYear - $fromYear) * 12 + ($toMonth % 100) - ($fromMonth % 100);
    }
}
