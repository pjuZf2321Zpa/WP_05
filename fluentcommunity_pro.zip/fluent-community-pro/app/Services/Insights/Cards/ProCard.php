<?php

namespace FluentCommunityPro\App\Services\Insights\Cards;

use FluentCommunity\App\Services\Insights\Cards\AbstractCard;

/**
 * Pro cards declare their key, page, type, size and order as properties;
 * free's AbstractCard does the caching, envelope and comparison plumbing.
 */
abstract class ProCard extends AbstractCard
{
    protected $key = '';

    protected $page = '';

    protected $type = 'table';

    protected $size = 'full';

    protected $order = 100;

    protected $supports = [ 'compare', 'space_id', 'export' ];

    public function key()
    {
        return $this->key;
    }

    public function page()
    {
        return $this->page;
    }

    public function type()
    {
        return $this->type;
    }

    public function size()
    {
        return $this->size;
    }

    public function order()
    {
        return $this->order;
    }

    public function supports()
    {
        return $this->supports;
    }

    /**
     * @param array $members rows from MemberMetrics::publicProfiles() + metric columns
     * @param array $columns extra [key, label, type] columns after rank and member
     * @param int $page
     * @param int|null $perPage null when all rows are shown
     * @return array table payload
     */
    protected function memberTable(array $members, array $columns, $total = null, $page = 1, $perPage = null)
    {
        return [
            'columns'  => array_merge([
                [ 'key' => 'rank', 'label' => '#', 'type' => 'rank' ],
                [ 'key' => 'display_name', 'label' => __('Member', 'fluent-community-pro'), 'type' => 'member' ],
            ], $columns),
            'rows'     => array_values($members),
            'total'    => $total === null ? count($members) : (int)$total,
            'page'     => (int)$page,
            'per_page' => $perPage === null ? count($members) : (int)$perPage,
        ];
    }

    protected function table(array $columns, array $rows, $total = null)
    {
        return [
            'columns'  => $columns,
            'rows'     => array_values($rows),
            'total'    => $total === null ? count($rows) : (int)$total,
            'page'     => 1,
            'per_page' => count($rows),
        ];
    }
}
