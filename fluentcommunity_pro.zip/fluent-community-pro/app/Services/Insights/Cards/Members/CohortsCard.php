<?php

namespace FluentCommunityPro\App\Services\Insights\Cards\Members;

use FluentCommunity\App\Services\Insights\Range;
use FluentCommunity\App\Services\Insights\Scope;
use FluentCommunityPro\App\Services\Insights\Cards\ProCard;
use FluentCommunityPro\App\Services\Insights\Metrics\MemberMetrics;

class CohortsCard extends ProCard
{
    protected $key = 'members.cohorts';

    protected $page = 'members';

    protected $type = 'cohort';

    protected $order = 30;

    protected $supports = [];

    public function title()
    {
        return __('Retention Cohorts', 'fluent-community-pro');
    }

    public function description()
    {
        return __('Members grouped by the month they joined (up to 12 months in the range), and the share of each group active in each later month: M0 is the joining month. Active means contributed, or visited once visits are tracked. Metric: retention.cohorts.', 'fluent-community-pro');
    }

    public function compute(Range $range, Scope $scope, array $options)
    {
        return MemberMetrics::cohorts($range, $scope->withSpace(null));
    }
}
