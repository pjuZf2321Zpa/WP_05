<?php

namespace FluentCommunityPro\App\Services\Insights\Cards\Members;

use FluentCommunity\App\Services\Insights\Bucketer;
use FluentCommunity\App\Services\Insights\Metrics\MemberMetrics as BaseMemberMetrics;
use FluentCommunity\App\Services\Insights\Range;
use FluentCommunity\App\Services\Insights\Scope;
use FluentCommunityPro\App\Services\Insights\Cards\ProCard;
use FluentCommunityPro\App\Services\Insights\Metrics\MemberMetrics;

class GrowthCard extends ProCard
{
    protected $key = 'members.growth';

    protected $page = 'members';

    protected $type = 'timeseries';

    protected $order = 10;

    protected $supports = [ 'export' ];

    public function title()
    {
        return __('Growth', 'fluent-community-pro');
    }

    public function description()
    {
        return __('New members per period, and active members at the end of each period, on separate scales. Metrics: members.new, members.total.', 'fluent-community-pro');
    }

    public function compute(Range $range, Scope $scope, array $options)
    {
        $bucketer = new Bucketer($range);
        $scope = $scope->withSpace(null);

        return $this->timeseries($bucketer, [
            [ 'key' => 'members.new', 'label' => __('New Members', 'fluent-community-pro'), 'values' => $bucketer->fill(BaseMemberMetrics::newByBucket($range, $scope, $bucketer)), 'previous' => null ],
            [ 'key' => 'members.total', 'label' => __('Total Members', 'fluent-community-pro'), 'values' => array_values(MemberMetrics::totalByBucket($range, $scope, $bucketer)), 'previous' => null, 'summary' => 'last', 'chart' => 'line' ],
        ], 'count', [ 'chart' => 'column', 'layout' => 'multiples' ]);
    }
}
