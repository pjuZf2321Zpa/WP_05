<?php

namespace FluentCommunityPro\App\Services\Insights\Cards\Members;

use FluentCommunity\App\Services\Insights\Range;
use FluentCommunity\App\Services\Insights\Scope;
use FluentCommunityPro\App\Services\Insights\Cards\ProCard;
use FluentCommunityPro\App\Services\Insights\Metrics\MemberMetrics;

class TopContributorsCard extends ProCard
{
    const EXPORT_ROWS = 5000;

    protected $key = 'members.top_contributors';

    protected $page = 'members';

    protected $order = 20;

    protected $supports = [ 'space_id', 'export', 'paging' ];

    public function title()
    {
        return __('Top Contributors', 'fluent-community-pro');
    }

    public function description()
    {
        return __('Ranked by 3 x posts + 2 x comments + 1 x reactions given in the range. Reactions received are shown alongside. Metric: members.top_contributors.', 'fluent-community-pro');
    }

    public function compute(Range $range, Scope $scope, array $options)
    {
        $page = $options['page'];
        $perPage = $options['per_page'];
        if (!empty($options['export'])) {
            $page = 1;
            $perPage = self::EXPORT_ROWS;
        } elseif (!isset($options['export'])) {
            // An older core has no pager and asks for 20 rows; keep its top 10
            $page = 1;
            $perPage = 10;
        }
        $rows = MemberMetrics::topContributors($range, $scope, $perPage, ($page - 1) * $perPage, $options['sort']);
        // Rows that fit on page 1 already give the total and top score
        $summary = $page === 1 && count($rows) < $perPage
            ? [ 'total' => count($rows), 'max_score' => $rows ? max(array_column($rows, 'score')) : 0 ]
            : MemberMetrics::contributorsSummary($range, $scope);

        return $this->memberTable($rows, [
            [ 'key' => 'posts', 'label' => __('Posts', 'fluent-community-pro'), 'type' => 'number', 'sortable' => true ],
            [ 'key' => 'comments', 'label' => __('Comments', 'fluent-community-pro'), 'type' => 'number', 'sortable' => true ],
            [ 'key' => 'reactions_given', 'label' => __('Reactions Given', 'fluent-community-pro'), 'type' => 'number', 'sortable' => true ],
            [ 'key' => 'reactions_received', 'label' => __('Reactions Received', 'fluent-community-pro'), 'type' => 'number' ],
            [ 'key' => 'score', 'label' => __('Score', 'fluent-community-pro'), 'type' => 'bar', 'sortable' => true, 'max' => $summary['max_score'] ],
        ], $summary['total'], $page, $perPage);
    }
}
