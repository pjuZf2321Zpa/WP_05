<?php

namespace FluentCommunityPro\App\Services\Insights\Cards\Members;

use FluentCommunity\App\Services\Insights\Range;
use FluentCommunity\App\Services\Insights\Scope;
use FluentCommunityPro\App\Services\Insights\Cards\ProCard;
use FluentCommunityPro\App\Services\Insights\Metrics\MemberMetrics;

class HealthCard extends ProCard
{
    protected $key = 'members.activation';

    protected $page = 'members';

    protected $type = 'kpi';

    protected $order = 5;

    protected $supports = [ 'compare', 'export' ];

    public function title()
    {
        return __('Activation and Member Status', 'fluent-community-pro');
    }

    public function description()
    {
        return __('Share of new members who posted, commented or reacted within 7 days of joining (members younger than 7 days are not judged yet), the median time from joining to a first post, and member status now. Metrics: activation.first_contrib_7d, activation.time_to_first_post, members.total, members.pending.', 'fluent-community-pro');
    }

    public function compute(Range $range, Scope $scope, array $options)
    {
        $scope = $scope->withSpace(null);
        $comparison = $this->comparisonRange($range, $options);
        $current = MemberMetrics::activation($range, $scope);
        $previous = $comparison ? MemberMetrics::activation($comparison, $scope) : null;
        $status = MemberMetrics::statusCounts();

        return [
            'items' => [
                $this->kpiItem('activation.first_contrib_7d', __('Activated Within 7 Days', 'fluent-community-pro'), $current['rate'], $previous ? $previous['rate'] : null, 'percent', 'rate'),
                $this->kpiItem('activation.time_to_first_post', __('Time to First Post', 'fluent-community-pro'), $current['median_minutes_to_first_post'], $previous ? $previous['median_minutes_to_first_post'] : null, 'duration', 'duration'),
                $this->kpiItem('members.total', __('Active Members', 'fluent-community-pro'), $status['active'], null),
                $this->kpiItem('members.pending', __('Pending Members', 'fluent-community-pro'), $status['pending'], null),
                $this->kpiItem('members.blocked', __('Blocked Members', 'fluent-community-pro'), $status['blocked'], null),
            ],
        ];
    }
}
