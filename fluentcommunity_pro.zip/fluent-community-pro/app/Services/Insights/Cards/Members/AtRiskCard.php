<?php

namespace FluentCommunityPro\App\Services\Insights\Cards\Members;

use FluentCommunity\App\Services\Insights\Range;
use FluentCommunity\App\Services\Insights\Scope;
use FluentCommunityPro\App\Services\Insights\Cards\ProCard;
use FluentCommunityPro\App\Services\Insights\Metrics\MemberMetrics;

class AtRiskCard extends ProCard
{
    protected $key = 'members.at_risk';

    protected $page = 'members';

    protected $order = 50;

    protected $supports = [ 'export' ];

    public function title()
    {
        return __('At-Risk Regulars', 'fluent-community-pro');
    }

    public function description()
    {
        return __('Members with 5 or more posts and comments in the 60 days before the last 30 days of the range, and no activity at all in those last 30 days. Metric: members.at_risk.', 'fluent-community-pro');
    }

    public function compute(Range $range, Scope $scope, array $options)
    {
        $atRisk = MemberMetrics::atRisk($range, $scope->withSpace(null), 50);

        return $this->memberTable($atRisk['rows'], [
            [ 'key' => 'earlier_contributions', 'label' => __('Earlier Posts and Comments', 'fluent-community-pro'), 'type' => 'number', 'sortable' => true ],
            [ 'key' => 'last_contribution', 'label' => __('Last Contribution', 'fluent-community-pro'), 'type' => 'date', 'sortable' => true ],
        ], $atRisk['count']);
    }
}
