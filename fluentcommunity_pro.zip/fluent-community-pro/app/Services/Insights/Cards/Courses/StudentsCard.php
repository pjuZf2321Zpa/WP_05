<?php

namespace FluentCommunityPro\App\Services\Insights\Cards\Courses;

use FluentCommunity\App\Services\Insights\Range;
use FluentCommunity\App\Services\Insights\Scope;
use FluentCommunityPro\App\Services\Insights\Cards\ProCard;
use FluentCommunityPro\App\Services\Insights\Metrics\CourseMetrics;

class StudentsCard extends ProCard
{
    protected $key = 'courses.students';

    protected $page = 'courses';

    protected $order = 40;

    protected $supports = [ 'course_id', 'export' ];

    public function title()
    {
        return __('Students', 'fluent-community-pro');
    }

    public function description()
    {
        return __('Active students of the selected course (or the one with most students): the 100 most recent enrollments, with progress as the course pages show it, the enrollment date and the completion date.', 'fluent-community-pro');
    }

    public function compute(Range $range, Scope $scope, array $options)
    {
        $course = CourseMetrics::resolveCourse($scope);
        $rows = $course ? CourseMetrics::students($course['id'], $scope, 100) : [];

        return $this->memberTable($rows, [
            [ 'key' => 'progress', 'label' => __('Progress', 'fluent-community-pro'), 'type' => 'progress', 'sortable' => true ],
            [ 'key' => 'enrolled_at', 'label' => __('Enrolled', 'fluent-community-pro'), 'type' => 'date', 'sortable' => true ],
            [ 'key' => 'completed_at', 'label' => __('Completed', 'fluent-community-pro'), 'type' => 'date', 'sortable' => true ],
        ], $course ? CourseMetrics::studentCount($course['id'], $scope) : 0);
    }
}
