<?php

namespace FluentCommunityPro\App\Services\Insights\Cards\Courses;

use FluentCommunity\App\Services\Insights\Range;
use FluentCommunity\App\Services\Insights\Scope;
use FluentCommunityPro\App\Services\Insights\Cards\ProCard;
use FluentCommunityPro\App\Services\Insights\Metrics\CourseMetrics;

class LessonFunnelCard extends ProCard
{
    protected $key = 'courses.lesson_funnel';

    protected $page = 'courses';

    protected $type = 'funnel';

    protected $order = 30;

    protected $supports = [ 'course_id' ];

    public function title()
    {
        return __('Lesson Funnel', 'fluent-community-pro');
    }

    public function description()
    {
        return __('For the selected course (or the one with most students), the share of active students who completed each published lesson, in curriculum order. Metric: course.lesson_funnel.', 'fluent-community-pro');
    }

    public function compute(Range $range, Scope $scope, array $options)
    {
        $course = CourseMetrics::resolveCourse($scope);
        if (!$course) {
            return [ 'steps' => [] ];
        }

        $funnel = CourseMetrics::lessonFunnel($course['id'], $scope);
        /* translators: 1: course title, 2: number of students */
        $funnel['subject'] = sprintf(__('%1$s · %2$d active students', 'fluent-community-pro'), $course['title'], $funnel['students']);

        return $funnel;
    }
}
