<?php

namespace FluentCommunityPro\App\Services\Insights\Cards\Spaces;

use FluentCommunity\App\Services\Helper;
use FluentCommunity\App\Services\Insights\Bucketer;
use FluentCommunity\App\Services\Insights\Range;
use FluentCommunity\App\Services\Insights\Scope;
use FluentCommunityPro\App\Services\Insights\Cards\ProCard;
use FluentCommunityPro\App\Services\Insights\Metrics\SpaceMetrics;

class ComparisonCard extends ProCard
{
    protected $key = 'spaces.comparison';

    protected $page = 'spaces';

    protected $order = 10;

    protected $supports = [ 'export' ];

    public function title()
    {
        return __('Space Comparison', 'fluent-community-pro');
    }

    public function description()
    {
        return __('Every space: members now, joins and leaves in the range (leaves are known from the day tracking started), posts and comments, members who took part, the share of members who took part, the share of posts answered, and the post trend. Metrics: space.members, space.joins, space.leaves, space.posts, space.comments, space.contributors, space.contributor_ratio, space.reply_rate.', 'fluent-community-pro');
    }

    public function compute(Range $range, Scope $scope, array $options)
    {
        $rows = array_map(function ($row) {
            $row['link'] = Helper::baseUrl('space/' . $row['slug'] . '/home');

            return $row;
        }, SpaceMetrics::comparison($range, $scope->withSpace(null), new Bucketer($range)));

        return $this->table([
            [ 'key' => 'title', 'label' => __('Space Name', 'fluent-community-pro'), 'type' => 'link', 'link_key' => 'link' ],
            [ 'key' => 'members', 'label' => __('Members', 'fluent-community-pro'), 'type' => 'number', 'sortable' => true ],
            [ 'key' => 'joins', 'label' => __('Joins', 'fluent-community-pro'), 'type' => 'number', 'sortable' => true ],
            [ 'key' => 'leaves', 'label' => __('Leaves', 'fluent-community-pro'), 'type' => 'number', 'sortable' => true ],
            [ 'key' => 'posts', 'label' => __('Posts', 'fluent-community-pro'), 'type' => 'number', 'sortable' => true ],
            [ 'key' => 'comments', 'label' => __('Comments', 'fluent-community-pro'), 'type' => 'number', 'sortable' => true ],
            [ 'key' => 'contributors', 'label' => __('Contributors', 'fluent-community-pro'), 'type' => 'number', 'sortable' => true ],
            [ 'key' => 'contributor_ratio', 'label' => __('Took Part', 'fluent-community-pro'), 'type' => 'percent', 'sortable' => true ],
            [ 'key' => 'reply_rate', 'label' => __('Posts Answered', 'fluent-community-pro'), 'type' => 'percent', 'sortable' => true ],
            [ 'key' => 'trend', 'label' => __('Trend', 'fluent-community-pro'), 'type' => 'sparkline' ],
        ], $rows);
    }
}
