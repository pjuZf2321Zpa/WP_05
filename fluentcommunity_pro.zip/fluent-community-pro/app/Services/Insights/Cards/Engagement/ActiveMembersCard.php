<?php

namespace FluentCommunityPro\App\Services\Insights\Cards\Engagement;

use FluentCommunity\App\Services\Insights\Bucketer;
use FluentCommunity\App\Services\Insights\Metrics\MemberMetrics as BaseMemberMetrics;
use FluentCommunity\App\Services\Insights\Range;
use FluentCommunity\App\Services\Insights\Scope;
use FluentCommunityPro\App\Services\Insights\Cards\ProCard;
use FluentCommunityPro\App\Services\Insights\Metrics\EngagementMetrics;

class ActiveMembersCard extends ProCard
{
    protected $key = 'engagement.active';

    protected $page = 'engagement';

    protected $type = 'timeseries';

    protected $order = 10;

    protected $supports = [ 'space_id', 'export' ];

    public function title()
    {
        return __('Daily, Weekly and Monthly Active Members', 'fluent-community-pro');
    }

    public function description()
    {
        return __('Members active on the day, in the 7 days and in the 30 days ending on each date (rolling windows, not calendar weeks). For weeks and months the value at the end of the period is shown. Metrics: members.dau, members.wau, members.mau.', 'fluent-community-pro');
    }

    public function compute(Range $range, Scope $scope, array $options)
    {
        $withVisits = !$scope->spaceId() && BaseMemberMetrics::visitsCover(Range::fromDates($range->from()->modify('-29 days')->format('Y-m-d'), $range->toDate()));
        $rolling = EngagementMetrics::rolling(EngagementMetrics::userDays($range, $scope, $withVisits), $range);
        $bucketer = new Bucketer($range);

        // A bucket shows the rolling value on its last day inside the range.
        $series = [];
        $labels = [
            'dau' => __('Daily Active', 'fluent-community-pro'),
            'wau' => __('Weekly Active', 'fluent-community-pro'),
            'mau' => __('Monthly Active', 'fluent-community-pro'),
        ];
        foreach ($labels as $name => $label) {
            $byBucket = [];
            foreach ($rolling['days'] as $index => $day) {
                $byBucket[$bucketer->bucketStart(new \DateTimeImmutable($day, $range->from()->getTimezone()))->format('Y-m-d')] = $rolling[$name][$index];
            }
            $series[] = [ 'key' => 'members.' . $name, 'label' => $label, 'values' => $bucketer->fill($byBucket), 'previous' => null ];
        }

        return $this->timeseries($bucketer, $series, 'count', [ 'chart' => 'line', 'visits_tracked' => $withVisits ]);
    }
}
