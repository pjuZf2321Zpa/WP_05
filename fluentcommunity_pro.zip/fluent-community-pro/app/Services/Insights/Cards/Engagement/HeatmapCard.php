<?php

namespace FluentCommunityPro\App\Services\Insights\Cards\Engagement;

use FluentCommunity\App\Services\Insights\Bucketer;
use FluentCommunity\App\Services\Insights\Range;
use FluentCommunity\App\Services\Insights\Scope;
use FluentCommunityPro\App\Services\Insights\Cards\ProCard;
use FluentCommunityPro\App\Services\Insights\Metrics\EngagementMetrics;

class HeatmapCard extends ProCard
{
    protected $key = 'engagement.heatmap';

    protected $page = 'engagement';

    protected $type = 'heatmap';

    protected $order = 50;

    protected $supports = [ 'space_id' ];

    public function title()
    {
        return __('When Members Are Active', 'fluent-community-pro');
    }

    public function description()
    {
        return __('Posts, comments, reactions and chat messages by weekday and hour, in the site timezone. Sign-ups and space creation are not counted. Metric: timing.heatmap.', 'fluent-community-pro');
    }

    public function compute(Range $range, Scope $scope, array $options)
    {
        return EngagementMetrics::heatmap($range, $scope, Bucketer::siteWeekStart());
    }
}
