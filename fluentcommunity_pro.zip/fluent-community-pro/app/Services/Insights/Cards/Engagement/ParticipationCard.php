<?php

namespace FluentCommunityPro\App\Services\Insights\Cards\Engagement;

use FluentCommunity\App\Services\Insights\Range;
use FluentCommunity\App\Services\Insights\Scope;
use FluentCommunityPro\App\Services\Insights\Cards\ProCard;
use FluentCommunityPro\App\Services\Insights\Metrics\EngagementMetrics;

class ParticipationCard extends ProCard
{
    protected $key = 'engagement.participation';

    protected $page = 'engagement';

    protected $type = 'distribution';

    protected $size = 'half';

    protected $order = 40;

    protected $supports = [ 'space_id', 'export' ];

    public function title()
    {
        return __('Participation Tiers', 'fluent-community-pro');
    }

    public function description()
    {
        return __('Members at the end of the range by how many posts and comments they wrote in it. Most communities follow a 90-9-1 shape: most members read without posting. Metric: participation.tiers.', 'fluent-community-pro');
    }

    public function compute(Range $range, Scope $scope, array $options)
    {
        $tiers = EngagementMetrics::participation($range, $scope);
        $labels = [
            '0'     => __('No posts or comments', 'fluent-community-pro'),
            '1-2'   => __('1 to 2', 'fluent-community-pro'),
            '3-10'  => __('3 to 10', 'fluent-community-pro'),
            '11-50' => __('11 to 50', 'fluent-community-pro'),
            '50+'   => __('More than 50', 'fluent-community-pro'),
        ];

        $buckets = [];
        foreach ($labels as $key => $label) {
            $buckets[] = [ 'key' => (string)$key, 'label' => $label, 'value' => $tiers[$key] ];
        }

        return [ 'buckets' => $buckets, 'total' => array_sum($tiers) ];
    }
}
