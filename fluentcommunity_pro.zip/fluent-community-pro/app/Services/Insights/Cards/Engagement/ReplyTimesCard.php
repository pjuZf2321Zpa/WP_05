<?php

namespace FluentCommunityPro\App\Services\Insights\Cards\Engagement;

use FluentCommunity\App\Services\Insights\Range;
use FluentCommunity\App\Services\Insights\Scope;
use FluentCommunityPro\App\Services\Insights\Cards\ProCard;
use FluentCommunityPro\App\Services\Insights\Metrics\EngagementMetrics;

class ReplyTimesCard extends ProCard
{
    protected $key = 'engagement.reply_times';

    protected $page = 'engagement';

    protected $type = 'distribution';

    protected $size = 'half';

    protected $order = 30;

    protected $supports = [ 'space_id', 'export' ];

    public function title()
    {
        return __('Time to First Reply', 'fluent-community-pro');
    }

    public function description()
    {
        return __('Posts created in the range by how long they waited for a reply from someone else. Metric: response.buckets.', 'fluent-community-pro');
    }

    public function compute(Range $range, Scope $scope, array $options)
    {
        $counts = EngagementMetrics::replyBuckets($range, $scope);
        $labels = [
            'lt_1h' => __('Under 1 hour', 'fluent-community-pro'),
            '1_4h'  => __('1 to 4 hours', 'fluent-community-pro'),
            '4_24h' => __('4 to 24 hours', 'fluent-community-pro'),
            '1_3d'  => __('1 to 3 days', 'fluent-community-pro'),
            'gt_3d' => __('Over 3 days', 'fluent-community-pro'),
            'never' => __('No reply yet', 'fluent-community-pro'),
        ];

        $buckets = [];
        foreach ($labels as $key => $label) {
            $buckets[] = [ 'key' => $key, 'label' => $label, 'value' => $counts[$key] ];
        }

        return [ 'buckets' => $buckets, 'total' => array_sum($counts) ];
    }
}
