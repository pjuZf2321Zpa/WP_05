<?php

namespace FluentCommunityPro\App\Services\Insights\Cards\Engagement;

use FluentCommunity\App\Services\Insights\Metrics\MemberMetrics as BaseMemberMetrics;
use FluentCommunity\App\Services\Insights\Metrics\ResponseMetrics;
use FluentCommunity\App\Services\Insights\Range;
use FluentCommunity\App\Services\Insights\Scope;
use FluentCommunityPro\App\Services\Insights\Cards\ProCard;
use FluentCommunityPro\App\Services\Insights\Metrics\EngagementMetrics;

class ResponsivenessCard extends ProCard
{
    protected $key = 'engagement.responsiveness';

    protected $page = 'engagement';

    protected $type = 'kpi';

    protected $order = 5;

    public function title()
    {
        return __('Stickiness and Responsiveness', 'fluent-community-pro');
    }

    public function description()
    {
        return __('Stickiness is the average daily actives divided by monthly actives (10-25% is typical). Replies are the first comment by someone other than the author; posts younger than 24 hours are not judged yet. Metrics: members.stickiness, response.reply_rate, response.first_reply_median, response.within_24h.', 'fluent-community-pro');
    }

    public function compute(Range $range, Scope $scope, array $options)
    {
        $comparison = $this->comparisonRange($range, $options);
        $current = ResponseMetrics::stats($range, $scope);
        $previous = $comparison ? ResponseMetrics::stats($comparison, $scope) : null;

        return [
            'items' => [
                $this->kpiItem('members.stickiness', __('Stickiness', 'fluent-community-pro'), $this->stickiness($range, $scope), $comparison ? $this->stickiness($comparison, $scope) : null, 'percent', 'rate'),
                $this->kpiItem('response.reply_rate', __('Posts Answered', 'fluent-community-pro'), $current['reply_rate'], $previous ? $previous['reply_rate'] : null, 'percent', 'rate'),
                $this->kpiItem('response.first_reply_median', __('Median Time to First Reply', 'fluent-community-pro'), $current['median_minutes'], $previous ? $previous['median_minutes'] : null, 'duration', 'duration'),
                $this->kpiItem('response.within_24h', __('Answered Within 24 Hours', 'fluent-community-pro'), $current['within_24h_rate'], $previous ? $previous['within_24h_rate'] : null, 'percent', 'rate'),
            ],
        ];
    }

    private function stickiness(Range $range, Scope $scope)
    {
        $withVisits = !$scope->spaceId() && BaseMemberMetrics::visitsCover(Range::fromDates($range->from()->modify('-29 days')->format('Y-m-d'), $range->toDate()));
        $rolling = EngagementMetrics::rolling(EngagementMetrics::userDays($range, $scope, $withVisits), $range);
        $mau = end($rolling['mau']);

        if (!$mau || !$rolling['dau']) {
            return null;
        }

        return round((array_sum($rolling['dau']) / count($rolling['dau'])) / $mau, 4);
    }
}
