<?php

namespace FluentCommunityPro\App\Services\Insights\Cards\Moderation;

use FluentCommunity\App\Services\Insights\Range;
use FluentCommunity\App\Services\Insights\Scope;
use FluentCommunityPro\App\Services\Insights\Cards\ProCard;
use FluentCommunityPro\App\Services\Insights\Metrics\ModerationMetrics;

class TopReportedCard extends ProCard
{
    protected $key = 'moderation.top_reported';

    protected $page = 'moderation';

    protected $order = 40;

    protected $supports = [ 'space_id', 'export' ];

    public function title()
    {
        return __('Most Reported Members', 'fluent-community-pro');
    }

    public function description()
    {
        return __('Authors whose posts were reported most in the range. Metric: mod.top_reported.', 'fluent-community-pro');
    }

    public function compute(Range $range, Scope $scope, array $options)
    {
        return $this->memberTable(ModerationMetrics::topReported($range, $scope, 10), [
            [ 'key' => 'reports', 'label' => __('Reports', 'fluent-community-pro'), 'type' => 'bar', 'sortable' => true ],
        ]);
    }
}
