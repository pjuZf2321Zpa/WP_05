<?php

namespace FluentCommunityPro\App\Services\Insights\Cards\Moderation;

use FluentCommunity\App\Services\Insights\Range;
use FluentCommunity\App\Services\Insights\Scope;
use FluentCommunityPro\App\Services\Insights\Cards\ProCard;
use FluentCommunityPro\App\Services\Insights\Metrics\ModerationMetrics;

class OutcomeCard extends ProCard
{
    protected $key = 'moderation.outcome';

    protected $page = 'moderation';

    protected $type = 'distribution';

    protected $size = 'third';

    protected $order = 30;

    protected $supports = [ 'space_id', 'export' ];

    public function title()
    {
        return __('Outcome', 'fluent-community-pro');
    }

    public function description()
    {
        return __('Reports made in the range by their current status. Metric: mod.reports_received.', 'fluent-community-pro');
    }

    public function compute(Range $range, Scope $scope, array $options)
    {
        $counts = ModerationMetrics::outcomes($range, $scope);
        $labels = [
            'flagged'     => __('Flagged', 'fluent-community-pro'),
            'pending'     => __('Pending', 'fluent-community-pro'),
            'ignored'     => __('Ignored', 'fluent-community-pro'),
            'published'   => __('Restored', 'fluent-community-pro'),
            'unpublished' => __('Removed', 'fluent-community-pro'),
        ];

        $buckets = [];
        foreach ($labels as $key => $label) {
            $buckets[] = [ 'key' => $key, 'label' => $label, 'value' => isset($counts[$key]) ? $counts[$key] : 0 ];
        }

        return [ 'buckets' => $buckets, 'total' => array_sum(array_column($buckets, 'value')) ];
    }
}
