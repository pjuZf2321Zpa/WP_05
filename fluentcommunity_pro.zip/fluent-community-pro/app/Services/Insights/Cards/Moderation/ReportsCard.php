<?php

namespace FluentCommunityPro\App\Services\Insights\Cards\Moderation;

use FluentCommunity\App\Services\Insights\Bucketer;
use FluentCommunity\App\Services\Insights\Range;
use FluentCommunity\App\Services\Insights\Scope;
use FluentCommunityPro\App\Services\Insights\Cards\ProCard;
use FluentCommunityPro\App\Services\Insights\Metrics\ModerationMetrics;

class ReportsCard extends ProCard
{
    protected $key = 'moderation.reports';

    protected $page = 'moderation';

    protected $type = 'timeseries';

    protected $size = 'two_thirds';

    protected $order = 20;

    protected $supports = [ 'space_id', 'export' ];

    public function title()
    {
        return __('Reports Received', 'fluent-community-pro');
    }

    public function description()
    {
        return __('Reports made in each period, by where they stand now: still open, kept after review, or removed. Metric: mod.reports_received.', 'fluent-community-pro');
    }

    public function compute(Range $range, Scope $scope, array $options)
    {
        $bucketer = new Bucketer($range);
        $byStatus = ModerationMetrics::receivedByStatus($range, $scope, $bucketer);
        $groups = [
            'mod.open'    => [ __('Still Open', 'fluent-community-pro'), [ 'flagged', 'pending' ] ],
            'mod.kept'    => [ __('Kept', 'fluent-community-pro'), [ 'ignored', 'published' ] ],
            'mod.removed' => [ __('Removed', 'fluent-community-pro'), [ 'unpublished' ] ],
        ];

        $series = [];
        foreach ($groups as $key => $group) {
            $sum = [];
            foreach ($group[1] as $status) {
                foreach (isset($byStatus[$status]) ? $byStatus[$status] : [] as $bucket => $count) {
                    $sum[$bucket] = (isset($sum[$bucket]) ? $sum[$bucket] : 0) + $count;
                }
            }
            $series[] = [ 'key' => $key, 'label' => $group[0], 'values' => $bucketer->fill($sum), 'previous' => null ];
        }

        return $this->timeseries($bucketer, $series, 'count', [ 'chart' => 'column', 'stacked' => true ]);
    }
}
