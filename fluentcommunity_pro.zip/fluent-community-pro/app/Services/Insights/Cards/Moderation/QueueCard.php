<?php

namespace FluentCommunityPro\App\Services\Insights\Cards\Moderation;

use FluentCommunity\App\Services\Insights\Metrics\AttentionMetrics;
use FluentCommunity\App\Services\Insights\Range;
use FluentCommunity\App\Services\Insights\Scope;
use FluentCommunityPro\App\Services\Insights\Cards\ProCard;
use FluentCommunityPro\App\Services\Insights\Metrics\ModerationMetrics;

class QueueCard extends ProCard
{
    protected $key = 'moderation.queue';

    protected $page = 'moderation';

    protected $type = 'kpi';

    protected $order = 10;

    public function title()
    {
        return __('Is Moderation Keeping Up?', 'fluent-community-pro');
    }

    public function description()
    {
        return __('Reports still open and content waiting for review right now; for reports made in the range, the median time to the last action on them and the share that led to removal. Metrics: mod.open, mod.pending_content, mod.resolution_median, mod.actioned_rate.', 'fluent-community-pro');
    }

    public function compute(Range $range, Scope $scope, array $options)
    {
        $comparison = $this->comparisonRange($range, $options);
        $current = ModerationMetrics::resolution($range, $scope);
        $previous = $comparison ? ModerationMetrics::resolution($comparison, $scope) : null;

        return [
            'items' => [
                $this->kpiItem('mod.open', __('Open Reports', 'fluent-community-pro'), ModerationMetrics::openCount($scope), null),
                $this->kpiItem('mod.pending_content', __('Waiting for Review', 'fluent-community-pro'), AttentionMetrics::pendingContent($scope), null),
                $this->kpiItem('mod.resolution_median', __('Time to Resolve', 'fluent-community-pro'), $current['median_minutes'], $previous ? $previous['median_minutes'] : null, 'duration', 'duration'),
                $this->kpiItem('mod.actioned_rate', __('Removed After Review', 'fluent-community-pro'), $current['actioned_rate'], $previous ? $previous['actioned_rate'] : null, 'percent', 'rate'),
            ],
        ];
    }
}
