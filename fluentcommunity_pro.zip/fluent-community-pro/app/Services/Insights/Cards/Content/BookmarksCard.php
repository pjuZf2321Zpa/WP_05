<?php

namespace FluentCommunityPro\App\Services\Insights\Cards\Content;

use FluentCommunity\App\Services\Insights\Range;
use FluentCommunity\App\Services\Insights\Scope;
use FluentCommunityPro\App\Services\Insights\Cards\ProCard;
use FluentCommunityPro\App\Services\Insights\Metrics\ContentMetrics;

class BookmarksCard extends ProCard
{
    protected $key = 'content.bookmarks';

    protected $page = 'content';

    protected $size = 'half';

    protected $order = 50;

    protected $supports = [ 'space_id', 'export' ];

    public function title()
    {
        return __('Most Bookmarked', 'fluent-community-pro');
    }

    public function description()
    {
        return __('Posts bookmarked most often during the range. Metric: content.bookmarks.', 'fluent-community-pro');
    }

    public function compute(Range $range, Scope $scope, array $options)
    {
        return $this->table([
            [ 'key' => 'excerpt', 'label' => __('Post Title', 'fluent-community-pro'), 'type' => 'link', 'link_key' => 'link' ],
            [ 'key' => 'bookmarks', 'label' => __('Bookmarks', 'fluent-community-pro'), 'type' => 'bar', 'sortable' => true ],
        ], ContentMetrics::bookmarks($range, $scope, 10));
    }
}
