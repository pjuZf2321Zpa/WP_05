<?php

namespace FluentCommunityPro\App\Services\Insights\Cards\Content;

use FluentCommunity\App\Services\Insights\Range;
use FluentCommunity\App\Services\Insights\Scope;
use FluentCommunityPro\App\Services\Insights\Cards\ProCard;
use FluentCommunityPro\App\Services\Insights\Metrics\ContentMetrics;

class TopicsCard extends ProCard
{
    protected $key = 'content.topics';

    protected $page = 'content';

    protected $size = 'half';

    protected $order = 20;

    protected $supports = [ 'space_id', 'export' ];

    /** @var string post_topic|hashtag */
    protected $taxonomy = 'post_topic';

    public function title()
    {
        return __('Topics', 'fluent-community-pro');
    }

    public function description()
    {
        return __('Posts created in the range per topic. A post with two topics counts once for each. Metric: content.topics.', 'fluent-community-pro');
    }

    public function compute(Range $range, Scope $scope, array $options)
    {
        return $this->table([
            [ 'key' => 'title', 'label' => $this->taxonomy === 'hashtag' ? __('Hashtag', 'fluent-community-pro') : __('Topic', 'fluent-community-pro'), 'type' => 'text' ],
            [ 'key' => 'posts', 'label' => __('Posts', 'fluent-community-pro'), 'type' => 'bar', 'sortable' => true ],
        ], ContentMetrics::topics($range, $scope, $this->taxonomy));
    }
}
