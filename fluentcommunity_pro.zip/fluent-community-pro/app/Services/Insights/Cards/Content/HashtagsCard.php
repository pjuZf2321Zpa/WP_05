<?php

namespace FluentCommunityPro\App\Services\Insights\Cards\Content;

class HashtagsCard extends TopicsCard
{
    protected $key = 'content.hashtags';

    protected $order = 30;

    protected $taxonomy = 'hashtag';

    public function title()
    {
        return __('Hashtags', 'fluent-community-pro');
    }

    public function description()
    {
        return __('Posts created in the range per hashtag. Metric: content.topics (hashtags).', 'fluent-community-pro');
    }
}
