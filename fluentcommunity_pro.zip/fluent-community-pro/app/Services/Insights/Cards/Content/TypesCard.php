<?php

namespace FluentCommunityPro\App\Services\Insights\Cards\Content;

use FluentCommunity\App\Services\Insights\Range;
use FluentCommunity\App\Services\Insights\Scope;
use FluentCommunityPro\App\Services\Insights\Cards\ProCard;
use FluentCommunityPro\App\Services\Insights\Metrics\ContentMetrics;

class TypesCard extends ProCard
{
    protected $key = 'content.types';

    protected $page = 'content';

    protected $size = 'half';

    protected $order = 40;

    protected $supports = [ 'space_id', 'export' ];

    public function title()
    {
        return __('Content Types', 'fluent-community-pro');
    }

    public function description()
    {
        return __('Posts created in the range by kind (text, survey, document, video and so on). Metric: content.types.', 'fluent-community-pro');
    }

    public function compute(Range $range, Scope $scope, array $options)
    {
        return $this->table([
            [ 'key' => 'type', 'label' => __('Type', 'fluent-community-pro'), 'type' => 'text' ],
            [ 'key' => 'posts', 'label' => __('Posts', 'fluent-community-pro'), 'type' => 'bar', 'sortable' => true ],
        ], ContentMetrics::types($range, $scope));
    }
}
