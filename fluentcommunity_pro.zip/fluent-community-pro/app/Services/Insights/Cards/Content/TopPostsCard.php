<?php

namespace FluentCommunityPro\App\Services\Insights\Cards\Content;

use FluentCommunity\App\Services\Insights\Range;
use FluentCommunity\App\Services\Insights\Scope;
use FluentCommunityPro\App\Services\Insights\Cards\ProCard;
use FluentCommunityPro\App\Services\Insights\Metrics\ContentMetrics;

class TopPostsCard extends ProCard
{
    protected $key = 'content.top_posts';

    protected $page = 'content';

    protected $order = 10;

    protected $supports = [ 'space_id', 'export' ];

    public function title()
    {
        return __('Popular Posts', 'fluent-community-pro');
    }

    public function description()
    {
        return __('Posts created in the range, ranked by the comments and reactions they got in the range. Metric: content.top_posts.', 'fluent-community-pro');
    }

    public function compute(Range $range, Scope $scope, array $options)
    {
        return $this->table([
            [ 'key' => 'excerpt', 'label' => __('Post Title', 'fluent-community-pro'), 'type' => 'link', 'link_key' => 'link' ],
            [ 'key' => 'space', 'label' => __('Space', 'fluent-community-pro'), 'type' => 'text' ],
            [ 'key' => 'author', 'label' => __('Author', 'fluent-community-pro'), 'type' => 'link', 'link_key' => 'profile_link' ],
            [ 'key' => 'comments', 'label' => __('Comments', 'fluent-community-pro'), 'type' => 'number', 'sortable' => true ],
            [ 'key' => 'reactions', 'label' => __('Reactions', 'fluent-community-pro'), 'type' => 'number', 'sortable' => true ],
        ], ContentMetrics::topPosts($range, $scope, 10));
    }
}
