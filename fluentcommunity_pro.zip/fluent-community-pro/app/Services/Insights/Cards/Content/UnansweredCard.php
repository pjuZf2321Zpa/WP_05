<?php

namespace FluentCommunityPro\App\Services\Insights\Cards\Content;

use FluentCommunity\App\Services\Insights\Metrics\AttentionMetrics;
use FluentCommunity\App\Services\Insights\Range;
use FluentCommunity\App\Services\Insights\Scope;
use FluentCommunityPro\App\Services\Insights\Cards\ProCard;
use FluentCommunityPro\App\Services\Insights\Metrics\ContentMetrics;

class UnansweredCard extends ProCard
{
    protected $key = 'content.unanswered';

    protected $page = 'content';

    protected $order = 15;

    protected $supports = [ 'space_id', 'export' ];

    public function title()
    {
        return __('Unanswered Posts', 'fluent-community-pro');
    }

    public function description()
    {
        return __('Posts from the last 30 days that nobody but the author has replied to after 24 hours, newest first. Not limited to the selected range. Metric: response.unanswered.', 'fluent-community-pro');
    }

    public function compute(Range $range, Scope $scope, array $options)
    {
        $unanswered = AttentionMetrics::unanswered($scope, 50);

        return $this->table([
            [ 'key' => 'excerpt', 'label' => __('Post Title', 'fluent-community-pro'), 'type' => 'link', 'link_key' => 'link' ],
            [ 'key' => 'space', 'label' => __('Space', 'fluent-community-pro'), 'type' => 'text' ],
            [ 'key' => 'author', 'label' => __('Author', 'fluent-community-pro'), 'type' => 'link', 'link_key' => 'profile_link' ],
            [ 'key' => 'created_at', 'label' => __('Posted', 'fluent-community-pro'), 'type' => 'date', 'sortable' => true ],
        ], ContentMetrics::decoratePosts(array_map(function ($post) {
            $post['user_id'] = isset($post['user_id']) ? $post['user_id'] : null;

            return $post;
        }, $unanswered['posts'])), $unanswered['count']);
    }
}
