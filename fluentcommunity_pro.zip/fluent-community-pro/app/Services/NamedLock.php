<?php

namespace FluentCommunityPro\App\Services;

/**
 * MySQL named locks (GET_LOCK), for the few writes that must not interleave and that
 * fcom_posts / fcom_meta have no unique key to protect.
 */
class NamedLock
{
    const TIMEOUT = 10;

    /**
     * Run $callback while holding the lock.
     *
     * @param string   $name
     * @param callable $callback
     * @return mixed the callback's result, or a WP_Error when the lock is busy
     */
    public static function run($name, callable $callback)
    {
        global $wpdb;

        // Lock names are server-wide: prefix them so two sites on one MySQL server do not share them
        $name = substr($wpdb->prefix . $name, 0, 64);

        /**
         * Seconds to wait for a lock another request holds.
         *
         * @param int    $timeout
         * @param string $name
         */
        $timeout = max(0, (int) apply_filters('fluent_community/lock_timeout', self::TIMEOUT, $name));

        $acquired = (bool) $wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s, %d)', $name, $timeout)); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

        if (!$acquired) {
            return new \WP_Error('busy', __('Another request is in progress. Please try again.', 'fluent-community-pro'));
        }

        try {
            return $callback();
        } finally {
            $wpdb->query($wpdb->prepare('SELECT RELEASE_LOCK(%s)', $name)); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        }
    }
}
