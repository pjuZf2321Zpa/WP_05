<?php

/*
 * Require any extra files here. For example::
 * require_once "shortcodes.php";
 * require_once "crontasks.php";
 */

/**
 * @var \WPFluentMicro\Foundation\Application $app
 */
