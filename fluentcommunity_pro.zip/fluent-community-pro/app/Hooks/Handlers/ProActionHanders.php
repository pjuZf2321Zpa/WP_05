<?php

namespace FluentCommunityPro\App\Hooks\Handlers;

use FluentCommunity\App\Functions\Utility;
use FluentCommunity\Framework\Support\Arr;
use FluentCommunity\Modules\Auth\Classes\InvitationService;
use FluentCommunityPro\App\Services\ProHelper;

class ProActionHanders
{
    public function register()
    {
        add_filter('fluent_community/color_schmea_config', function ($config, $context) {
            $existingConfig = \FluentCommunity\App\Functions\Utility::getOption('portal_color_config', $config);
            $config = wp_parse_args($existingConfig, $config);
            return $config;
        }, 10, 2);

        add_action('fluent_community/recache_color_schema', [ $this, 'recacheColors' ]);

        add_filter('fluent_community/create_invitation_link', function ($invitation, $indivatationData) {
            return InvitationService::createLinkInvite($indivatationData);
        }, 1, 2);

        add_action('fluent_community/update_profile_link_providers', function ($config) {
            Utility::updateOption('enabled_profile_link_keys', $config);
        });

        add_filter('fluent_community/course/can_view_lesson', function ($canView, $lesson) {
            if ($lesson->is_free_preview) {
                return true;
            }
            return $canView;
        }, 10, 2);

        add_filter('fluent_community/course/processed', [ $this, 'addWelcomeBannerToCourse' ], 10, 2);

        add_filter('fluent_community/lockscreen_fields', [ $this, 'maybeAddCourseWelcomeBannerField' ], 10, 2);

        /*
         * Custom Snippet handlers
         */
        add_action('fluent_community/portal_head', [ $this, 'addCustomCss' ], 999);
        add_action('fluent_community/template_header', [ $this, 'addCustomCss' ], 999);
        add_action('fluent_community/portal_footer', [ $this, 'addCustomJs' ], 999);
    }

    public function addWelcomeBannerToCourse($course, $ctx)
    {
        $isEnrolled = !empty($ctx['is_enrolled']);

        $course->isEnrolled = $isEnrolled;

        // Enrolled ahead of the open date: the enrolled banner often holds student-only links, and the
        // not-enrolled one asks them to buy what they already hold, so show neither
        if (!empty($ctx['is_scheduled'])) {
            $course->welcome_banner = null;
            return $course;
        }

        $view = $isEnrolled ? 'enrolled' : 'not_enrolled';
        $course->welcome_banner = ProHelper::getCourseWelcomeBannerForView($course, $view);

        return $course;
    }

    public function maybeAddCourseWelcomeBannerField($fields, $space)
    {
        if (!$space->isCourseSpace()) {
            return $fields;
        }

        $bannerField = [
            'hidden' => true,
            'type'   => 'welcome_banner',
            'label'  => __('Welcome Banner', 'fluent-community-pro'),
            'name'   => 'welcome_banner',
            'banner' => ProHelper::getCourseWelcomeBannerForView($space, 'not_enrolled'),
        ];

        $existingNames = array_column($fields, 'name');

        $fieldIndex = array_search('welcome_banner', $existingNames, true);
        if ($fieldIndex !== false) {
            $fields[$fieldIndex]['banner'] = $bannerField['banner'];
            return $fields;
        }

        $anchorIndex = array_search('lesson', $existingNames, true);

        if ($anchorIndex !== false) {
            array_splice($fields, $anchorIndex, 0, [ $bannerField ]);
        } else {
            $fields[] = $bannerField;
        }

        return $fields;
    }

    public function recacheColors()
    {
        Utility::forgetCache('option_portal_color_config');
        $allSchemas = Utility::getColorSchemas();
        $settings = Utility::getOption('portal_color_config');
        $lightSchema = Arr::get($settings, 'light_schema', 'default');
        $darkSchema = Arr::get($settings, 'dark_schema', 'default');
        $lightCss = Utility::generateCss(Arr::get($allSchemas, "lightSkins.$lightSchema.selectors"));
        $darkCss = Utility::generateCss(Arr::get($allSchemas, "darkSkins.$darkSchema.selectors"), 'html.dark');
        $settings['cached_css'] = $lightCss . ' ' . $darkCss;
        $settings['version'] = FLUENT_COMMUNITY_PLUGIN_VERSION;
        Utility::updateOption('portal_color_config', $settings);
        return true;
    }

    public function addCustomCss()
    {
        $snippets = ProHelper::getSnippetsSettings();

        if (!Arr::get($snippets, 'custom_css')) {
            return;
        }

        ?>
        <style id="fcom_custom_css">
            <?php echo ProHelper::sanitizeCSS($snippets['custom_css']); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- sanitizeCSS is the sink. ?>
        </style>
        <?php
    }

    public function addCustomJs()
    {
        if (!ProHelper::canUseCustomJs('output')) {
            return;
        }

        $snippets = ProHelper::getSnippetsSettings();
        // Only users allowed in the 'save' context can store this (see updateSnippetsSettings).
        echo Arr::get($snippets, 'custom_js'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Raw JS by design.
    }
}
