<?php

namespace FluentCommunityPro\App\Hooks\Handlers;

use FluentCommunity\Framework\Support\Arr;
use FluentCommunity\Modules\Course\Model\CourseLesson;
use FluentCommunity\Modules\Course\Model\CourseTopic;
use FluentCommunity\Modules\Course\Services\CourseHelper;

class SequentialLessonLockHandler
{
    private static $gateContextCache = [];

    public function register()
    {
        add_filter('fluent_community/course/lesson_access_info', [ $this, 'applyLessonLock' ], 10, 5);
    }

    public function applyLessonLock($info, $lesson, $course, $user, $ctx = [])
    {
        if (!empty($lesson->is_free_preview)) {
            $info['can_view']  = true;
            $info['lock_type'] = '';
            return $info;
        }

        if (empty($info['can_view'])) {
            return $info;
        }

        if (Arr::get($course->settings, 'sequential_lesson_order') !== 'yes') {
            return $info;
        }

        if (!$user || empty($user->ID)) {
            return $info;
        }

        if (!empty($ctx['is_admin'])) {
            return $info;
        }

        if (empty($ctx['enrollment'])) {
            return $info;
        }

        $gate = $this->getGateContext($course->id, $user->ID);

        // re-watch: completed lessons stay accessible
        if (isset($gate['completed'][$lesson->id])) {
            return $info;
        }

        // every lesson completed → nothing to gate
        if ($gate['firstUncompletedIdx'] === null) {
            return $info;
        }

        $idx = $gate['positions'][$lesson->id] ?? null;
        if ($idx === null) {
            return $info;
        }

        if ($idx > $gate['firstUncompletedIdx']) {
            $info['can_view']  = false;
            $info['lock_type'] = 'sequential';
        }

        return $info;
    }

    private function getGateContext($courseId, $userId)
    {
        $key = $courseId . '_' . $userId;
        if (isset(self::$gateContextCache[$key])) {
            return self::$gateContextCache[$key];
        }

        $orderedIds = $this->getOrderedLessonIds($courseId);
        $completedFlip = array_flip(CourseHelper::getCompletedLessonIds($courseId, $userId));
        $positions = array_flip($orderedIds);

        $firstUncompletedIdx = null;
        foreach ($orderedIds as $i => $lid) {
            if (!isset($completedFlip[$lid])) {
                $firstUncompletedIdx = $i;
                break;
            }
        }

        self::$gateContextCache[$key] = [
            'positions'           => $positions,
            'completed'           => $completedFlip,
            'firstUncompletedIdx' => $firstUncompletedIdx,
        ];

        return self::$gateContextCache[$key];
    }

    private function getOrderedLessonIds($courseId)
    {
        static $cache = [];
        $courseId = (int) $courseId;
        if (isset($cache[$courseId])) {
            return $cache[$courseId];
        }

        $sectionIds = CourseTopic::where('space_id', $courseId)
            ->orderBy('priority', 'ASC')
            ->orderBy('id', 'ASC')
            ->pluck('id')
            ->toArray();

        if (!$sectionIds) {
            $cache[$courseId] = [];

            return [];
        }

        global $wpdb;

        // Read the free-preview flag in SQL instead of loading every lesson's meta, which
        // holds whole quizzes. CourseHelper::sanitizeLessonMeta() always stores it as "yes" or "no".
        $rows = CourseLesson::where('space_id', $courseId)
            ->where('status', 'published')
            ->orderBy('priority', 'ASC')
            ->orderBy('id', 'ASC')
            ->select([ 'id', 'parent_id' ])
            ->selectRaw('(meta LIKE ?) AS free_preview_flag', [ '%' . $wpdb->esc_like('s:19:"free_preview_lesson";s:3:"yes";') . '%' ])
            ->get();

        $bySection = [];
        foreach ($rows as $row) {
            // free-preview lessons are exempt from locking, so they must not
            // hold the sequential gate — exclude them from the ordered sequence.
            if ((int) $row->free_preview_flag) {
                continue;
            }
            $bySection[$row->parent_id][] = (int) $row->id;
        }

        $ids = [];
        foreach ($sectionIds as $sid) {
            if (!empty($bySection[$sid])) {
                foreach ($bySection[$sid] as $lid) {
                    $ids[] = $lid;
                }
            }
        }

        $cache[$courseId] = $ids;

        return $ids;
    }
}
