<?php

namespace FluentCommunityPro\App\Hooks\Handlers;

use FluentCommunityPro\App\Services\Insights\Cards;

/**
 * Registers the Pro Insights cards. Free hides a page whose feature is off
 * (moderation, courses), so no feature checks are needed here.
 */
class InsightsHandler
{
    public function register()
    {
        add_filter('fluent_community/insights/cards', [ $this, 'registerCards' ]);
    }

    public function registerCards($cards)
    {
        return array_merge((array)$cards, [
            new Cards\Engagement\ActiveMembersCard(),
            new Cards\Engagement\ResponsivenessCard(),
            new Cards\Engagement\ReplyTimesCard(),
            new Cards\Engagement\ParticipationCard(),
            new Cards\Engagement\HeatmapCard(),
            new Cards\Members\GrowthCard(),
            new Cards\Members\HealthCard(),
            new Cards\Members\CohortsCard(),
            new Cards\Members\TopContributorsCard(),
            new Cards\Members\AtRiskCard(),
            new Cards\Spaces\ComparisonCard(),
            new Cards\Content\TopPostsCard(),
            new Cards\Content\TopicsCard(),
            new Cards\Content\HashtagsCard(),
            new Cards\Content\TypesCard(),
            new Cards\Content\BookmarksCard(),
            new Cards\Content\UnansweredCard(),
            new Cards\Moderation\QueueCard(),
            new Cards\Moderation\ReportsCard(),
            new Cards\Moderation\OutcomeCard(),
            new Cards\Moderation\TopReportedCard(),
            new Cards\Courses\LessonFunnelCard(),
            new Cards\Courses\StudentsCard(),
        ]);
    }
}
