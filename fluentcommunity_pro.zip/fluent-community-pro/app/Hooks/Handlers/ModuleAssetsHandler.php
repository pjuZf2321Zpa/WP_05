<?php

namespace FluentCommunityPro\App\Hooks\Handlers;

use FluentCommunity\App\Services\Helper;
use FluentCommunity\Framework\Support\Arr;
use FluentCommunityPro\App\Services\ModuleTransStrings;

/**
 * Loads Pro's module bundles (vite.config.js `moduleEntries`) into FluentCommunity's portal
 * and admin app. The bundles import core's Vue, Element Plus and UI kit through the import
 * map core prints (FluentCommunity docs/ai/module-runtime.md), so they carry no copy of
 * their own.
 *
 * A feature module asks for its entry by name and runtime:
 *
 *     add_filter('fluent_community_pro/module_entries', function ($entries) {
 *         $entries['certificates-admin'] = ['runtime' => 'admin'];
 *         return $entries;
 *     });
 */
class ModuleAssetsHandler
{
    private $buildEntries = null;

    private $assetsDir;

    private $assetsUrl;

    /**
     * @param string|null $assetsDir defaults to assets/modules/ in this plugin
     * @param string|null $assetsUrl defaults to the URL of that folder
     */
    public function __construct($assetsDir = null, $assetsUrl = null)
    {
        $this->assetsDir = $assetsDir;
        $this->assetsUrl = $assetsUrl;
    }

    private function assetsDir()
    {
        return $this->assetsDir ? $this->assetsDir : FLUENT_COMMUNITY_PRO_DIR . 'assets/modules/';
    }

    public function register()
    {
        add_filter('fluent_community/module_scripts', [ $this, 'addScripts' ], 10, 2);
        // After core's PortalSettingsHandler (10), which switches module_runtime to 'admin'
        add_filter('fluent_community/portal_data_vars', [ $this, 'addStyles' ], 20);
        add_filter('fluent_community/portal_vars', [ $this, 'addStrings' ]);
    }

    /**
     * The strings our screens pass to $t() (dev/i18n-strings.mjs). Core's own translation
     * wins when both have the same English text.
     *
     * @param array $vars the app's JS vars (window.fluentComAdmin)
     * @return array
     */
    public function addStrings($vars)
    {
        $vars['i18n'] = (array) Arr::get($vars, 'i18n', []) + ModuleTransStrings::getStrings();

        return $vars;
    }

    /**
     * @param array  $scripts handle => ['url' => string]
     * @param string $runtime 'portal' or 'admin'
     * @return array
     */
    public function addScripts($scripts, $runtime)
    {
        $names = $this->requestedEntries($runtime);
        if (!$names) {
            return $scripts;
        }

        $devOrigin = $this->devOrigin();

        if ($devOrigin) {
            // Each dev entry imports the dev server's client itself (see vite.config.js devEntryPlugin)
            foreach ($names as $name) {
                $scripts['fcom_pro_' . $name] = [ 'url' => $devOrigin . '/@fcom-entry/' . $name . '.js' ];
            }
            return $scripts;
        }

        $built = $this->buildEntries();
        foreach ($names as $name) {
            if (!empty($built[$name]['file'])) {
                $scripts['fcom_pro_' . $name] = [ 'url' => $this->assetUrl($built[$name]['file']) ];
            }
        }

        return $scripts;
    }

    /**
     * One entry's script and stylesheets, for a page Pro renders itself (outside the portal
     * app), such as the certificate verification page. The page must also print core's
     * import map before the script.
     *
     * @param string $name entry name in vite.config.js
     * @return array ['script' => string|null, 'styles' => string[]]
     */
    public function entryAssets($name)
    {
        $devOrigin = $this->devOrigin();
        if ($devOrigin) {
            return [ 'script' => $devOrigin . '/@fcom-entry/' . $name . '.js', 'styles' => [] ];
        }

        $built = Arr::get($this->buildEntries(), $name);
        if (empty($built['file'])) {
            return [ 'script' => null, 'styles' => [] ];
        }

        return [
            'script' => $this->assetUrl($built['file']),
            'styles' => array_map([ $this, 'styleUrl' ], (array) Arr::get($built, 'css', [])),
        ];
    }

    /**
     * Entry CSS goes in css_files; in dev mode the JS injects it itself.
     *
     * @param array $vars portal page data
     * @return array
     */
    public function addStyles($vars)
    {
        if ($this->devOrigin()) {
            return $vars;
        }

        $runtime = Arr::get($vars, 'module_runtime', 'portal');
        $built = $this->buildEntries();

        $styles = [];
        foreach ($this->requestedEntries($runtime) as $name) {
            foreach ((array) Arr::get($built, $name . '.css', []) as $index => $css) {
                $styles['fcom_pro_' . $name . '_css_' . $index] = [ 'url' => $this->styleUrl($css) ];
            }
        }

        if ($styles) {
            // First, not last: our bundles repeat the Element Plus rules of the components they use.
            // Loaded after core's stylesheets, those copies undo core's restyling of the same
            // components (icon sizes, button and popover borders). Loaded before, core's own copy
            // and overrides still come last. Our own overrides of .el-* need a scoped selector.
            $vars['css_files'] = $styles + (array) Arr::get($vars, 'css_files', []);
        }

        return $vars;
    }

    /**
     * @param string $runtime
     * @return string[] entry names registered for this runtime
     */
    private function requestedEntries($runtime)
    {
        $entries = apply_filters('fluent_community_pro/module_entries', []);
        if (!$entries || !is_array($entries)) {
            return [];
        }

        $names = [];
        foreach ($entries as $name => $entry) {
            if (Arr::get($entry, 'runtime') === $runtime && preg_match('/^[a-z0-9-]+$/', $name)) {
                $names[] = $name;
            }
        }

        return $names;
    }

    /**
     * entries.json from the last build: name => ['file' => string, 'css' => string[]]
     *
     * @return array
     */
    private function buildEntries()
    {
        if ($this->buildEntries !== null) {
            return $this->buildEntries;
        }

        $file = $this->assetsDir() . 'entries.json';
        $data = is_readable($file) ? json_decode((string) file_get_contents($file), true) : null; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents

        $this->buildEntries = is_array($data) ? $data : [];

        return $this->buildEntries;
    }

    /**
     * The Vite dev server origin while `npm run dev` runs (it writes assets/modules/hot).
     *
     * @return string|null
     */
    private function devOrigin()
    {
        $hot = $this->assetsDir() . 'hot';
        if (!is_readable($hot)) {
            return null;
        }

        $origin = trim((string) file_get_contents($hot)); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents

        // Only ever a local dev server; anything else in that file is ignored
        return preg_match('~^https?://(localhost|127\.0\.0\.1)(:\d+)?$~', $origin) ? $origin : null;
    }

    public function assetUrl($file)
    {
        $base = $this->assetsUrl ? $this->assetsUrl : FLUENT_COMMUNITY_PRO_URL . 'assets/modules/';

        return $base . ltrim($file, '/');
    }

    /**
     * On an RTL portal, the .rtl.css twin dev/rtl-css.mjs writes next to every stylesheet.
     * Core's Helper::isRtl(), not is_rtl(): the fluent_community/is_rtl filter can turn the
     * portal RTL on an LTR locale. Lazy chunks pick it in the browser instead
     * (renderBuiltUrl in vite.config.js).
     */
    public function styleUrl($file)
    {
        if (Helper::isRtl()) {
            $file = preg_replace('/\.css$/', '.rtl.css', $file);
        }

        return $this->assetUrl($file);
    }
}
