<?php

namespace FluentCommunityPro\App\Modules\Certificates;

use FluentCommunity\App\Services\Helper;
use FluentCommunity\Framework\Support\Arr;
use FluentCommunityPro\App\Hooks\Handlers\ModuleAssetsHandler;
use FluentCommunityPro\App\Modules\Certificates\Models\Certificate;
use FluentCommunityPro\App\Modules\Certificates\Services\CertificatePresenter;
use FluentCommunityPro\App\Modules\Certificates\Services\CredentialId;
use FluentCommunityPro\App\Modules\Certificates\Services\OpenBadgeCredential;

/**
 * The public verification page: /{portal}/certificates/{credential_id}.
 *
 * Rendered here, as a standalone document, on core's `rendering_path_ssr_certificates`
 * action, which fires before the portal's login gate. So the page works for anyone with
 * the link or the QR code, also on a private community; its summary and Open Graph tags
 * are server HTML (link previews, crawlers); and no theme or portal stylesheet can change
 * how the certificate looks. Status always comes from the database, never from a file.
 */
class VerificationPage
{
    public function register()
    {
        add_filter('fluent_community/app_route_paths', [ $this, 'addRoutePath' ]);
        add_action('fluent_community/rendering_path_ssr_certificates', [ $this, 'render' ]);
    }

    /**
     * A portal at the site root routes only the paths in this list, so without it every
     * verification link (QR code, email, LinkedIn) is a 404 there.
     *
     * @param string[] $paths
     * @return string[]
     */
    public function addRoutePath($paths)
    {
        $paths[] = 'certificates';

        return $paths;
    }

    /**
     * @param string[] $pathParts the portal path split on '/', e.g. ['certificates', 'FC-...']
     */
    public function render($pathParts)
    {
        $result = $this->resolve($pathParts);

        if (!empty($result['redirect'])) {
            wp_safe_redirect($result['redirect'], 301);
            exit();
        }

        status_header($result['status']);
        nocache_headers(); // a status can change at any time; never serve a cached "valid"
        header('Referrer-Policy: same-origin'); // a holder link must not leak to other sites
        header('X-Robots-Tag: noindex, nofollow');

        echo $this->html($result['view']); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- the view escapes everything it prints
        exit();
    }

    /**
     * What to answer, without sending anything.
     *
     * @param string[] $pathParts
     * @param array    $query     the request's query args
     * @return array ['status' => int, 'view' => array] or ['redirect' => string]
     */
    public function resolve($pathParts, $query = null)
    {
        $query = $query === null ? $_GET : $query; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $requested = sanitize_text_field((string) Arr::get($pathParts, 1, ''));

        // The lookup form submits ?id=..., which always lands on the canonical URL
        $fromQuery = false;
        if (!$requested && !empty($query['id'])) {
            $requested = sanitize_text_field(wp_unslash($query['id']));
            $fromQuery = true;
        }

        if (!$requested) {
            return [ 'status' => 200, 'view' => [ 'mode' => 'lookup' ] ];
        }

        $credentialId = CredentialId::normalize($requested);
        $certificate = $credentialId ? Certificate::byCredential($credentialId)->first() : null;

        if (!$certificate) {
            return [ 'status' => 404, 'view' => [ 'mode' => 'not_found', 'requested' => $requested ] ];
        }

        // One URL per certificate: LinkedIn marks redirecting credential URLs as unverifiable,
        // so only the canonical one is ever handed out, and every other spelling lands on it
        $holderToken = sanitize_key((string) Arr::get($query, 'holder', ''));

        if ($fromQuery || $requested !== $credentialId) {
            $url = CertificatePresenter::verificationUrl($credentialId);

            return [ 'redirect' => $holderToken ? add_query_arg('holder', $holderToken, $url) : $url ];
        }

        // The holder link from the email: a holder without an account has no login to show
        $asHolder = CertificatePresenter::isHolderToken($certificate, $holderToken);
        $view = CertificatePresenter::forVerification($certificate, $asHolder);
        $view['as_holder'] = $asHolder;

        // The holder may have bookmarked this page: give them the LinkedIn button too
        $isHolder = $asHolder || ($certificate->user_id && (int) $certificate->user_id === get_current_user_id());
        if ($isHolder && !$view['is_private'] && $view['status'] === 'valid') {
            $view['linkedin_url'] = CertificatePresenter::linkedInUrl($certificate);

            if ($asHolder && OpenBadgeCredential::isAvailable()) {
                $view['badge_url'] = add_query_arg('token', $holderToken, rest_url('fluent-community/v2/certificates/open-badges/holder/' . $certificate->slug));
            }
        }

        return [
            'status' => 200,
            'view'   => [
                'mode'        => 'certificate',
                'certificate' => $view,
            ],
        ];
    }

    /**
     * @param array $view from resolve()
     * @return string the page
     */
    public function html(array $view)
    {
        $certificate = Arr::get($view, 'certificate');
        $assets = [ 'script' => null, 'styles' => [] ];

        // The script imports @fluentcommunity/vue through core's import map; a core without
        // printModuleImportMap() cannot resolve it, so the page renders without the viewer.
        if ($certificate && !empty($certificate['render']) && method_exists('\FluentCommunity\App\Vite', 'printModuleImportMap')) {
            $assets = (new ModuleAssetsHandler())->entryAssets('certificates-verify');
        }

        $siteName = Arr::get(Helper::generalSettings(), 'site_title');

        $page = array_merge([ 'certificate' => null, 'requested' => '' ], $view, [
            'site_name'   => $siteName ? $siteName : get_bloginfo('name'),
            'portal_url'  => Helper::baseUrl('/'),
            'lookup_url'  => CertificatePresenter::verificationUrl(''),
            'assets'      => $assets,
            'labels'      => $this->labels(),
            'date_format' => get_option('date_format'),
        ]);

        ob_start();
        include __DIR__ . '/Views/verification.php';

        return (string) ob_get_clean();
    }

    /**
     * Labels for the viewer's buttons, translated here because the page has no portal $t().
     */
    private function labels()
    {
        return [
            'certificate' => __('Certificate', 'fluent-community-pro'),
            'png'         => __('Download PNG', 'fluent-community-pro'),
            'pdf'         => __('Download PDF', 'fluent-community-pro'),
            'print'       => __('Print / Save as PDF', 'fluent-community-pro'),
            'preparing'   => __('Preparing…', 'fluent-community-pro'),
            'failed'      => __('The download could not be created.', 'fluent-community-pro'),
            'badge'       => __('Download Open Badge', 'fluent-community-pro'),
        ];
    }
}
