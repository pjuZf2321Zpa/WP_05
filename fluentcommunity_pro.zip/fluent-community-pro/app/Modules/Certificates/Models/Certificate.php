<?php

namespace FluentCommunityPro\App\Modules\Certificates\Models;

use FluentCommunity\App\Functions\Utility;
use FluentCommunity\App\Models\User;
use FluentCommunity\Modules\Course\Model\Course;
use FluentCommunityPro\App\Models\Model;

/**
 * An issued certificate. Stored in the shared fcom_posts table, type = 'course_certificate'.
 *
 * Column use: slug = credential ID (the public lookup key), user_id = holder, space_id = course,
 * parent_id = template, title = course title at issue, privacy = public|private,
 * expired_at = expiry, created_at = issue date, priority = display serial number.
 *
 * Status is never 'published': feed and lesson queries filter on (space_id, status = 'published'),
 * so certificate rows stay off those index paths. Expired is computed from expired_at.
 *
 * Two kinds share the type, told apart by content_type: course certificates ('certificate')
 * and manual certificates ('manual_certificate', ManualCertificates), which an admin issues to
 * any person with or without an account or a course. Course lists and course rules use
 * courseCertificates(); the verification page, the status list and the serial count both.
 * A manual certificate's person is meta.holder (name, email); user_id is set only when it is
 * linked to an account.
 *
 * @property int         $id
 * @property int         $user_id
 * @property int         $space_id
 * @property int         $parent_id
 * @property string      $slug
 * @property string      $title
 * @property string      $status issued|suspended|revoked
 * @property string      $privacy public|private
 * @property int|null    $priority
 * @property string|null $featured_image
 * @property string|null $expired_at
 * @property array       $meta
 * @property string|null $created_at
 * @property string|null $updated_at
 */
class Certificate extends Model
{
    const TYPE = 'course_certificate';

    const STATUS_ISSUED = 'issued';
    const STATUS_SUSPENDED = 'suspended';
    const STATUS_REVOKED = 'revoked';

    const KIND_COURSE = 'certificate';
    const KIND_MANUAL = 'manual_certificate';

    protected $table = 'fcom_posts';

    protected $guarded = [ 'id' ];

    protected $casts = [
        'user_id'   => 'int',
        'space_id'  => 'int',
        'parent_id' => 'int',
        'priority'  => 'int',
    ];

    protected $fillable = [
        'user_id',
        'title',
        'slug',
        'message',
        'type',
        'space_id',
        'privacy',
        'status',
        'featured_image',
        'content_type',
        'meta',
        'priority',
        'parent_id',
        'expired_at',
        'created_at',
    ];

    public static function boot()
    {
        parent::boot();

        static::creating(function ($model) {
            $model->type = self::TYPE;

            if ($model->content_type !== self::KIND_MANUAL) {
                $model->content_type = self::KIND_COURSE;
            }

            if (empty($model->status)) {
                $model->status = self::STATUS_ISSUED;
            }

            if (empty($model->privacy)) {
                $model->privacy = 'public';
            }

            if (empty($model->message)) {
                $model->message = '';
            }
        });

        static::addGlobalScope('type', function ($builder) {
            $builder->where('type', self::TYPE);
        });
    }

    public function setMetaAttribute($value)
    {
        $this->attributes['meta'] = maybe_serialize($value);
    }

    public function getMetaAttribute($value)
    {
        $meta = Utility::safeUnserialize($value);

        return is_array($meta) ? $meta : [];
    }

    public function course()
    {
        return $this->belongsTo(Course::class, 'space_id', 'id');
    }

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id', 'ID');
    }

    public function template()
    {
        return $this->belongsTo(CertificateTemplate::class, 'parent_id', 'id');
    }

    public function scopeCourseCertificates($query)
    {
        return $query->where('content_type', self::KIND_COURSE);
    }

    public function scopeManual($query)
    {
        return $query->where('content_type', self::KIND_MANUAL);
    }

    public function isManual()
    {
        return $this->content_type === self::KIND_MANUAL;
    }

    /**
     * Who the certificate belongs to: the name and email typed on a manual certificate, or
     * the linked account's.
     *
     * @return array ['name' => string, 'email' => string]
     */
    public function getHolder()
    {
        $holder = (array) ($this->meta['holder'] ?? []);

        if (!empty($holder['email'])) {
            return [ 'name' => (string) ($holder['name'] ?? ''), 'email' => (string) $holder['email'] ];
        }

        $user = $this->user_id ? $this->user : null;

        return [
            'name'  => (string) ($this->getData()['student.full_name'] ?? ''),
            'email' => $user ? (string) $user->user_email : '',
        ];
    }

    /**
     * What the certificate is for: the certificate name on a manual certificate (which may
     * have no course), the course title as printed on a course certificate.
     */
    public function getTitle()
    {
        if ($this->isManual()) {
            return (string) $this->title;
        }

        $values = $this->getData();

        return (string) ($values['course.title'] ?? $this->title);
    }

    /**
     * Manual certificates without an account that were issued to this email.
     */
    public function scopeByHolderEmail($query, $email)
    {
        $email = strtolower(trim((string) $email));

        // The exact serialized pair, so "a@x.com" does not match "aa@x.com"
        $pair = 's:12:"holder_email";s:' . strlen($email) . ':"' . $email . '";';

        return $query->where('content_type', self::KIND_MANUAL)
            ->whereNull('user_id')
            ->where('meta', 'LIKE', '%' . self::likeEscape($pair) . '%');
    }

    private static function likeEscape($value)
    {
        global $wpdb;

        return $wpdb->esc_like($value);
    }

    public function scopeByCredential($query, $credentialId)
    {
        return $query->where('slug', $credentialId);
    }

    /**
     * Rows that count as "this user has the course's certificate": a suspended one can be
     * reinstated, so it blocks a second issue too. A revoked one does not.
     */
    public function scopeActive($query)
    {
        return $query->whereIn('status', [ self::STATUS_ISSUED, self::STATUS_SUSPENDED ]);
    }

    public function isExpired()
    {
        return $this->expired_at && strtotime($this->expired_at) <= current_time('timestamp'); // phpcs:ignore WordPress.DateTime.CurrentTimeTimestamp.Requested
    }

    /**
     * @return string valid|expired|suspended|revoked
     */
    public function getVerificationStatus()
    {
        if ($this->status === self::STATUS_REVOKED) {
            return 'revoked';
        }

        if ($this->status === self::STATUS_SUSPENDED) {
            return 'suspended';
        }

        return $this->isExpired() ? 'expired' : 'valid';
    }

    public function getData()
    {
        return (array) ($this->meta['data'] ?? []);
    }
}
