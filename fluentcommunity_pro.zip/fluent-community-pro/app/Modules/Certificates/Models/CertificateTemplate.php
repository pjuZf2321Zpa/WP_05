<?php

namespace FluentCommunityPro\App\Modules\Certificates\Models;

use FluentCommunity\App\Models\Meta;
use FluentCommunity\App\Functions\Utility;
use FluentCommunityPro\App\Models\Model;
use FluentCommunityPro\App\Services\NamedLock;
use FluentCommunityPro\App\Modules\Certificates\Services\TemplateDesign;

/**
 * A certificate design. Stored in the shared fcom_posts table, type = 'certificate_template'.
 *
 * `message` holds the working design (JSON, see TemplateDesign). Publishing copies it into
 * an immutable version row in fcom_meta; issued certificates point at a version, so later
 * edits never change a certificate that was already issued.
 *
 * @property int         $id
 * @property int|null    $user_id
 * @property string|null $title
 * @property string|null $message
 * @property string|null $type
 * @property string|null $status draft|active|archived (see STATUS_ACTIVE)
 * @property array       $meta   ['current_version' => int, 'has_draft_changes' => bool, 'settings' => array]
 * @property string|null $created_at
 * @property string|null $updated_at
 */
class CertificateTemplate extends Model
{
    const TYPE = 'certificate_template';

    /*
     * A published template is 'active', never 'published': core's comment and reaction
     * endpoints accept any fcom_posts row whose status is 'published' or 'unlisted'
     * (FeedsHelper::getViewableByLinkStatuses), and a template must not take comments.
     */
    const STATUS_DRAFT = 'draft';
    const STATUS_ACTIVE = 'active';
    const STATUS_ARCHIVED = 'archived';

    const VERSION_META_TYPE = 'certificate_template';

    protected $table = 'fcom_posts';

    protected $guarded = [ 'id' ];

    protected $fillable = [
        'user_id',
        'title',
        'message',
        'type',
        'status',
        'content_type',
        'meta',
    ];

    public static function boot()
    {
        parent::boot();

        static::creating(function ($model) {
            if (empty($model->user_id)) {
                $model->user_id = get_current_user_id();
            }

            $model->type = self::TYPE;
            $model->content_type = 'certificate_template';

            if (empty($model->status)) {
                $model->status = 'draft';
            }

            if (empty($model->message)) {
                $model->message = wp_json_encode(TemplateDesign::blank());
            }

            if (empty($model->meta)) {
                $model->meta = [ 'current_version' => 0, 'has_draft_changes' => true, 'settings' => [] ];
            }
        });

        static::addGlobalScope('type', function ($builder) {
            $builder->where('type', self::TYPE);
        });
    }

    public function setMetaAttribute($value)
    {
        $this->attributes['meta'] = maybe_serialize($value);
    }

    public function getMetaAttribute($value)
    {
        $meta = Utility::safeUnserialize($value);

        return is_array($meta) ? $meta : [];
    }

    /**
     * @return array the working design
     */
    public function getDesign()
    {
        $design = json_decode((string) $this->message, true);

        return is_array($design) ? $design : TemplateDesign::blank();
    }

    public function getCurrentVersion()
    {
        return (int) ($this->meta['current_version'] ?? 0);
    }

    public function isPublished()
    {
        return $this->status === self::STATUS_ACTIVE && $this->getCurrentVersion() > 0;
    }

    /**
     * Freeze the working design as the next version and make it the one new certificates use.
     *
     * Serialised per template: two publishes (two tabs, a double click) must never write two
     * designs under one version number, since certificates find their design by that number.
     * Inside the lock the template is reloaded and the number comes from the version rows that
     * exist, not from the pointer, so a stale model or an interrupted publish cannot reuse one.
     *
     * @return int|\WP_Error the new version number
     */
    public function publish()
    {
        $result = NamedLock::run($this->lockName(), function () {
            $fresh = static::find($this->id);
            if (!$fresh) {
                return new \WP_Error('not_found', __('The template no longer exists.', 'fluent-community-pro'));
            }

            $version = max($fresh->getCurrentVersion(), $fresh->getLatestStoredVersion()) + 1;

            Meta::create([
                'object_type' => self::VERSION_META_TYPE,
                'object_id'   => $fresh->id,
                'meta_key'    => 'version_' . $version,
                'value'       => $fresh->getDesign(),
            ]);

            $meta = $fresh->meta;
            $meta['current_version'] = $version;
            $meta['has_draft_changes'] = false;

            $fresh->meta = $meta;
            $fresh->status = self::STATUS_ACTIVE;
            $fresh->save();

            return $fresh;
        });

        if (is_wp_error($result)) {
            return $result;
        }

        $this->setRawAttributes($result->getAttributes(), true);

        return $this->getCurrentVersion();
    }

    /**
     * The lock every write to this template's row takes (publish, draft saves): its meta holds
     * the published-version pointer, so writes must not interleave.
     */
    public function lockName()
    {
        return 'fcom_cert_tpl_' . $this->id;
    }

    /**
     * @return int the highest version that has a stored design, 0 when none
     */
    public function getLatestStoredVersion()
    {
        $keys = Meta::where('object_type', self::VERSION_META_TYPE)
            ->where('object_id', $this->id)
            ->where('meta_key', 'LIKE', 'version\_%')
            ->pluck('meta_key')
            ->toArray();

        $versions = array_map(function ($key) {
            return (int) substr($key, strlen('version_'));
        }, $keys);

        return $versions ? max($versions) : 0;
    }

    /**
     * @param int $version
     * @return array|null the design as it was published
     */
    public function getVersionDesign($version)
    {
        $row = Meta::where('object_type', self::VERSION_META_TYPE)
            ->where('object_id', $this->id)
            ->where('meta_key', 'version_' . (int) $version)
            ->first();

        return ($row && is_array($row->value)) ? $row->value : null;
    }

    public function certificates()
    {
        return $this->hasMany(Certificate::class, 'parent_id', 'id');
    }
}
