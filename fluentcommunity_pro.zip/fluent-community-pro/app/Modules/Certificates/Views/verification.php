<?php
/**
 * Certificate verification page (see VerificationPage). A standalone document: no theme, no
 * portal app. Everything printed from the certificate is escaped here.
 *
 * @var array $page mode (lookup|not_found|certificate), certificate, site_name, portal_url,
 *                  lookup_url, assets, labels, date_format, requested
 */

if (!defined('ABSPATH')) {
    exit;
}

$fccCertificate = $page['certificate'] ?? null;
$fccMode = $page['mode'];
$fccFormat = function ($date) use ($page) {
    return $date ? date_i18n($page['date_format'], strtotime($date)) : '';
};

$fccStatus = $fccCertificate ? $fccCertificate['status'] : '';
$fccStatusText = [
    'valid'     => __('This certificate is valid.', 'fluent-community-pro'),
    /* translators: %s: expiry date */
    'expired'   => $fccCertificate && !empty($fccCertificate['expires_at']) ? sprintf(__('This certificate expired on %s.', 'fluent-community-pro'), $fccFormat($fccCertificate['expires_at'])) : __('This certificate has expired.', 'fluent-community-pro'),
    'suspended' => __('This certificate is suspended.', 'fluent-community-pro'),
    'revoked'   => __('This certificate has been revoked.', 'fluent-community-pro'),
    'not_valid' => __('This certificate is not valid.', 'fluent-community-pro'),
];

if ($fccCertificate && !$fccCertificate['is_private']) {
    /* translators: 1: holder name, 2: course title or certificate name */
    $fccTitle = sprintf(__('%1$s – %2$s', 'fluent-community-pro'), $fccCertificate['holder_name'], $fccCertificate['course_title']);
    /* translators: 1: issuer, 2: issue date */
    $fccDescription = sprintf(__('Certificate issued by %1$s on %2$s.', 'fluent-community-pro'), $fccCertificate['issuer'], $fccFormat($fccCertificate['issued_at']));
} else {
    $fccTitle = __('Certificate verification', 'fluent-community-pro');
    /* translators: %s: site name */
    $fccDescription = sprintf(__('Check a certificate issued by %s.', 'fluent-community-pro'), $page['site_name']);
}

$fccCanonical = $fccCertificate ? $fccCertificate['verification_url'] : $page['lookup_url'];
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?><?php echo (\FluentCommunity\App\Services\Helper::isRtl() && !is_rtl()) ? ' dir="rtl"' : ''; ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title><?php echo esc_html($fccTitle . ' · ' . $page['site_name']); ?></title>
    <meta name="robots" content="noindex,nofollow">
    <meta name="description" content="<?php echo esc_attr($fccDescription); ?>">
    <link rel="canonical" href="<?php echo esc_url($fccCanonical); ?>">
    <meta property="og:type" content="website">
    <meta property="og:site_name" content="<?php echo esc_attr($page['site_name']); ?>">
    <meta property="og:title" content="<?php echo esc_attr($fccTitle); ?>">
    <meta property="og:description" content="<?php echo esc_attr($fccDescription); ?>">
    <meta property="og:url" content="<?php echo esc_url($fccCanonical); ?>">
    <meta name="twitter:card" content="summary">
    <?php
    if ($page['assets']['script'] && method_exists('\FluentCommunity\App\Vite', 'printModuleImportMap')) {
        \FluentCommunity\App\Vite::printModuleImportMap('portal');
    }
    foreach ($page['assets']['styles'] as $fccStyle) :
        ?>
        <link rel="stylesheet" href="<?php echo esc_url($fccStyle); ?>"><?php // phpcs:ignore WordPress.WP.EnqueuedResources.NonEnqueuedStylesheet ?>
    <?php endforeach; ?>
    <style>
        :root { --fcc-text: #1d2939; --fcc-muted: #667085; --fcc-line: #eaecf0; --fcc-bg: #f9fafb; }
        * { box-sizing: border-box; }
        body { margin: 0; background: var(--fcc-bg); color: var(--fcc-text); font: 15px/1.5 system-ui, -apple-system, "Segoe UI", Roboto, sans-serif; }
        .fcc-page { max-width: 1008px; margin: 0 auto; padding: 24px 24px 64px; }
        .fcc-top { display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; }
        .fcc-top a { color: var(--fcc-text); text-decoration: none; font-weight: 600; }
        .fcc-status { display: flex; gap: 12px; align-items: center; padding: 14px 16px; border-radius: 10px; margin-bottom: 20px; font-weight: 600; }
        .fcc-status::before { content: ""; width: 10px; height: 10px; border-radius: 50%; background: currentColor; flex: none; }
        .fcc-status--valid { background: #ecfdf3; color: #067647; }
        .fcc-status--expired, .fcc-status--suspended { background: #fffaeb; color: #b54708; }
        .fcc-status--revoked, .fcc-status--not_valid { background: #fef3f2; color: #b42318; }
        .fcc-details { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px 24px; margin: 0 0 24px; padding: 20px; background: #fff; border: 1px solid var(--fcc-line); border-radius: 10px; }
        .fcc-details dt { color: var(--fcc-muted); font-size: 13px; }
        .fcc-details dd { margin: 2px 0 0; font-weight: 600; overflow-wrap: anywhere; }
        .fcc-id { font-family: ui-monospace, SFMono-Regular, Menlo, monospace; }
        .fcc-copy { margin-inline-start: 6px; border: 1px solid var(--fcc-line); background: #fff; border-radius: 8px; padding: 2px 8px; font-size: 12px; cursor: pointer; }
        .fcc-holder { display: flex; gap: 12px; align-items: center; flex-wrap: wrap; margin: -8px 0 24px; font-size: 13px; }
        .fcc-linkedin { display: inline-block; padding: 8px 14px; border-radius: 8px; background: #0a66c2; color: #fff; font-weight: 600; font-size: 14px; text-decoration: none; }
        .fcc-lookup { margin-top: 40px; padding-top: 24px; border-top: 1px solid var(--fcc-line); }
        .fcc-lookup form { display: flex; gap: 8px; flex-wrap: wrap; }
        .fcc-lookup input { flex: 1 1 240px; padding: 10px 12px; border: 1px solid #d0d5dd; border-radius: 8px; font: inherit; }
        .fcc-lookup button { padding: 10px 16px; border: 0; border-radius: 8px; background: var(--fcc-text); color: #fff; font: inherit; cursor: pointer; }
        h1 { font-size: 22px; margin: 0 0 8px; }
        .fcc-muted { color: var(--fcc-muted); }
        @media print { .fcc-top, .fcc-status, .fcc-details, .fcc-holder, .fcc-lookup, .fcc-viewer__actions { display: none !important; } body { background: #fff; } }
    </style>
</head>
<body>
<main class="fcc-page">
    <div class="fcc-top">
        <a href="<?php echo esc_url($page['portal_url']); ?>"><?php echo esc_html($page['site_name']); ?></a>
        <span class="fcc-muted"><?php esc_html_e('Certificate verification', 'fluent-community-pro'); ?></span>
    </div>

    <?php if ($fccMode === 'not_found') : ?>
        <div class="fcc-status fcc-status--not_valid" role="status">
            <?php esc_html_e('No certificate has this ID. Check the ID and try again.', 'fluent-community-pro'); ?>
        </div>
    <?php elseif ($fccMode === 'lookup') : ?>
        <h1><?php esc_html_e('Verify a certificate', 'fluent-community-pro'); ?></h1>
        <p class="fcc-muted"><?php esc_html_e('Enter the credential ID printed on the certificate.', 'fluent-community-pro'); ?></p>
    <?php elseif ($fccCertificate) : ?>
        <div class="fcc-status fcc-status--<?php echo esc_attr($fccStatus); ?>" role="status">
            <?php echo esc_html($fccStatusText[$fccStatus] ?? ''); ?>
            <?php if ($fccCertificate['is_private'] && $fccStatus === 'valid') : ?>
                <span style="font-weight:400"><?php esc_html_e('The holder keeps the details private.', 'fluent-community-pro'); ?></span>
            <?php endif; ?>
        </div>

        <?php if (!$fccCertificate['is_private']) : ?>
            <dl class="fcc-details">
                <div><dt><?php esc_html_e('Awarded to', 'fluent-community-pro'); ?></dt><dd><?php echo esc_html($fccCertificate['holder_name']); ?></dd></div>
                <div><dt><?php echo ($fccCertificate['kind'] ?? '') === 'manual' ? esc_html__('Certificate', 'fluent-community-pro') : esc_html__('Course', 'fluent-community-pro'); ?></dt><dd><?php echo esc_html($fccCertificate['course_title']); ?></dd></div>
                <div><dt><?php esc_html_e('Issued by', 'fluent-community-pro'); ?></dt><dd><?php echo esc_html($fccCertificate['issuer']); ?></dd></div>
                <div><dt><?php esc_html_e('Issued on', 'fluent-community-pro'); ?></dt><dd><?php echo esc_html($fccFormat($fccCertificate['issued_at'])); ?></dd></div>
                <?php if (!empty($fccCertificate['expires_at'])) : ?>
                    <div><dt><?php esc_html_e('Valid until', 'fluent-community-pro'); ?></dt><dd><?php echo esc_html($fccFormat($fccCertificate['expires_at'])); ?></dd></div>
                <?php endif; ?>
                <div>
                    <dt><?php esc_html_e('Credential ID', 'fluent-community-pro'); ?></dt>
                    <dd><span class="fcc-id"><?php echo esc_html($fccCertificate['credential_id']); ?></span><button type="button" class="fcc-copy" data-copy="<?php echo esc_attr($fccCertificate['credential_id']); ?>"><?php esc_html_e('Copy', 'fluent-community-pro'); ?></button></dd>
                </div>
            </dl>

            <?php if (!empty($fccCertificate['as_holder'])) : ?>
                <p class="fcc-muted">
                    <?php esc_html_e('This is your private link from the email. To share the certificate, use its verification link:', 'fluent-community-pro'); ?>
                    <a href="<?php echo esc_url($fccCertificate['verification_url']); ?>"><?php echo esc_html($fccCertificate['verification_url']); ?></a>
                </p>
            <?php endif; ?>

            <?php if (!empty($fccCertificate['linkedin_url'])) : ?>
                <p class="fcc-holder">
                    <a class="fcc-linkedin" href="<?php echo esc_url($fccCertificate['linkedin_url']); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e('Add to LinkedIn', 'fluent-community-pro'); ?></a>
                    <span class="fcc-muted"><?php esc_html_e('Only you see this button.', 'fluent-community-pro'); ?></span>
                </p>
            <?php endif; ?>

            <?php if ($page['assets']['script'] && in_array($fccStatus, [ 'valid', 'expired' ], true)) : ?>
                <div id="fcc-viewer"></div>
            <?php endif; ?>
        <?php endif; ?>
    <?php endif; ?>

    <section class="fcc-lookup">
        <form method="get" action="<?php echo esc_url($page['lookup_url']); ?>">
            <label class="screen-reader-text" for="fcc-lookup-id" style="position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0);white-space:nowrap"><?php esc_html_e('Credential ID', 'fluent-community-pro'); ?></label>
            <input id="fcc-lookup-id" name="id" placeholder="FC-XXXX-XXXX-XXXX" autocomplete="off" value="<?php echo esc_attr($fccMode === 'not_found' ? $page['requested'] : ''); ?>">
            <button type="submit"><?php esc_html_e('Verify', 'fluent-community-pro'); ?></button>
        </form>
    </section>
</main>

<script>
    document.addEventListener('click', function (event) {
        var button = event.target.closest('[data-copy]');
        if (!button || !navigator.clipboard) { return; }
        navigator.clipboard.writeText(button.getAttribute('data-copy')).then(function () {
            button.textContent = <?php echo wp_json_encode(__('Copied', 'fluent-community-pro')); ?>;
        });
    });
</script>
<?php if ($fccCertificate && !$fccCertificate['is_private'] && $page['assets']['script'] && in_array($fccStatus, [ 'valid', 'expired' ], true)) : ?>
    <script>
        window.fcomCertificateVerify = <?php echo wp_json_encode([ 'credential_id' => $fccCertificate['credential_id'], 'render' => $fccCertificate['render'], 'labels' => $page['labels'], 'badge_url' => $fccCertificate['badge_url'] ?? '' ], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
    </script>
    <script type="module" src="<?php echo esc_url($page['assets']['script']); ?>"></script><?php // phpcs:ignore WordPress.WP.EnqueuedResources.NonEnqueuedScript ?>
<?php endif; ?>
</body>
</html>
