<?php

namespace FluentCommunityPro\App\Modules\Certificates;

use FluentCommunityPro\App\Modules\Certificates\Models\Certificate;
use FluentCommunityPro\App\Modules\Certificates\Services\CertificatePresenter;
use FluentCommunityPro\App\Modules\Certificates\Services\OpenBadgeCredential;

/**
 * A certificate stores the holder's name and is public at its verification URL, so it is
 * personal data:
 *  - deleting the WordPress user deletes their certificates (the URL then says "not found")
 *  - Tools -> Export / Erase Personal Data cover them: the account's certificates, and the
 *    manual certificates issued to that email without an account
 *
 * Registered even when the certificates module is switched off: export and erasure must
 * still work.
 */
class CertificatePrivacy
{
    const PAGE_SIZE = 50;

    public function register()
    {
        add_action('deleted_user', [ $this, 'deleteUserCertificates' ]);
        add_filter('wp_privacy_personal_data_exporters', [ $this, 'addExporter' ]);
        add_filter('wp_privacy_personal_data_erasers', [ $this, 'addEraser' ]);
    }

    /**
     * @param int $userId
     * @return int the number of certificates deleted
     */
    public function deleteUserCertificates($userId)
    {
        $userId = (int) $userId;
        if (!$userId) {
            return 0;
        }

        $count = 0;
        foreach (Certificate::where('user_id', $userId)->get() as $certificate) {
            $certificate->delete();
            ++$count;
        }

        if ($count) {
            do_action('fluent_community/certificate/user_certificates_deleted', $userId, $count);
        }

        return $count;
    }

    public function addExporter($exporters)
    {
        $exporters['fluent-community-certificates'] = [
            'exporter_friendly_name' => __('Certificates', 'fluent-community-pro'),
            'callback'               => [ $this, 'export' ],
        ];

        return $exporters;
    }

    public function addEraser($erasers)
    {
        $erasers['fluent-community-certificates'] = [
            'eraser_friendly_name' => __('Certificates', 'fluent-community-pro'),
            'callback'             => [ $this, 'erase' ],
        ];

        return $erasers;
    }

    public function export($email, $page = 1)
    {
        $certificates = $this->query($email)
            ->orderBy('id', 'ASC')
            ->offset(max(0, ((int) $page - 1) * self::PAGE_SIZE))
            ->limit(self::PAGE_SIZE)
            ->get();

        $items = [];
        foreach ($certificates as $certificate) {
            $values = $certificate->getData();
            $items[] = [
                'group_id'    => 'fluent-community-certificates',
                'group_label' => __('Certificates', 'fluent-community-pro'),
                'item_id'     => 'fcom-certificate-' . $certificate->id,
                'data'        => [
                    [ 'name' => __('Credential ID', 'fluent-community-pro'), 'value' => $certificate->slug ],
                    [ 'name' => __('Certificate', 'fluent-community-pro'), 'value' => $certificate->getTitle() ],
                    [ 'name' => __('Name on the certificate', 'fluent-community-pro'), 'value' => (string) ($values['student.full_name'] ?? '') ],
                    [ 'name' => __('Issued on', 'fluent-community-pro'), 'value' => (string) $certificate->created_at ],
                    [ 'name' => __('Status', 'fluent-community-pro'), 'value' => $certificate->status ],
                    [ 'name' => __('Visibility', 'fluent-community-pro'), 'value' => $certificate->privacy ],
                    [ 'name' => __('Verification URL', 'fluent-community-pro'), 'value' => CertificatePresenter::verificationUrl($certificate->slug) ],
                ],
            ];
        }

        return [ 'data' => $items, 'done' => count($certificates) < self::PAGE_SIZE ];
    }

    public function erase($email, $page = 1)
    {
        unset($page); // WordPress pages erasers; one call erases everything
        $user = get_user_by('email', $email);
        $removed = $user ? $this->deleteUserCertificates($user->ID) : 0;

        foreach (Certificate::byHolderEmail($email)->get() as $certificate) {
            $certificate->delete();
            // A badge already downloaded must stop verifying now, not when the cache expires
            OpenBadgeCredential::forgetStatus($certificate);
            ++$removed;
        }

        return [
            'items_removed'  => $removed,
            'items_retained' => false,
            'messages'       => [],
            'done'           => true,
        ];
    }

    /**
     * The account's certificates, and the manual ones issued to the email without an account.
     */
    private function query($email)
    {
        $user = get_user_by('email', $email);
        $userId = $user ? (int) $user->ID : 0;

        return Certificate::where(function ($query) use ($email, $userId) {
            $query->where(function ($query) use ($email) {
                (new Certificate())->scopeByHolderEmail($query, $email);
            });

            if ($userId) {
                $query->orWhere('user_id', $userId);
            }
        });
    }
}
