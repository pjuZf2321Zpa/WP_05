<?php

/**
 * @var \FluentCommunity\Framework\Http\Router $router
 */

use FluentCommunity\Modules\Course\Http\Policies\CourseAdminPolicy;
use FluentCommunityPro\App\Http\Policies\CertificatePolicy;
use FluentCommunityPro\App\Modules\Certificates\Http\Controllers\CertificateAdminController;
use FluentCommunityPro\App\Modules\Certificates\Http\Controllers\CertificateController;
use FluentCommunityPro\App\Modules\Certificates\Http\Controllers\CertificateTemplateController;
use FluentCommunityPro\App\Modules\Certificates\Http\Controllers\ManualCertificateController;
use FluentCommunityPro\App\Modules\Certificates\Http\Controllers\OpenBadgeController;

$router->prefix('admin/certificates')->withPolicy(CertificatePolicy::class)->group(function ($router) {
    $router->get('/templates', [ CertificateTemplateController::class, 'listTemplates' ]);
    $router->post('/templates', [ CertificateTemplateController::class, 'createTemplate' ]);
    $router->get('/templates/{id}', [ CertificateTemplateController::class, 'getTemplate' ])->int('id');
    $router->put('/templates/{id}', [ CertificateTemplateController::class, 'updateTemplate' ])->int('id');
    $router->post('/templates/{id}/publish', [ CertificateTemplateController::class, 'publishTemplate' ])->int('id');
    $router->delete('/templates/{id}', [ CertificateTemplateController::class, 'deleteTemplate' ])->int('id');
    $router->post('/images', [ CertificateTemplateController::class, 'uploadImage' ]);

    $router->get('/issued', [ CertificateAdminController::class, 'listIssued' ]);
    $router->post('/issued/{id}/suspend', [ CertificateAdminController::class, 'suspend' ])->int('id');
    $router->post('/issued/{id}/reinstate', [ CertificateAdminController::class, 'reinstate' ])->int('id');
    $router->post('/issued/{id}/revoke', [ CertificateAdminController::class, 'revoke' ])->int('id');
    $router->post('/issued/{id}/reissue', [ CertificateAdminController::class, 'reissue' ])->int('id');

    // Manual certificates: any person, any template, with or without a course
    $router->get('/manual', [ ManualCertificateController::class, 'listManual' ]);
    $router->get('/manual/fields', [ ManualCertificateController::class, 'manualFields' ]);
    $router->post('/manual', [ ManualCertificateController::class, 'issueManual' ]);
    $router->get('/issued/{id}/manual', [ ManualCertificateController::class, 'getManual' ])->int('id');
    $router->put('/issued/{id}/manual', [ ManualCertificateController::class, 'updateManual' ])->int('id');
    $router->get('/users/lookup', [ ManualCertificateController::class, 'lookupUser' ]);
});

// Course admins (and course creators, for their own courses) set a course's certificate
$router->prefix('admin/courses')->withPolicy(CourseAdminPolicy::class)->group(function ($router) {
    $router->get('/{course_id}/certificate-settings', [ CertificateAdminController::class, 'getCourseSettings' ])->int('course_id');
    $router->post('/{course_id}/certificate-settings', [ CertificateAdminController::class, 'saveCourseSettings' ])->int('course_id');
    $router->get('/{course_id}/certificate-backfill', [ CertificateAdminController::class, 'backfillSummary' ])->int('course_id');
    $router->post('/{course_id}/certificate-backfill', [ CertificateAdminController::class, 'backfill' ])->int('course_id');
});

$router->prefix('certificates')->withPolicy(CertificatePolicy::class)->group(function ($router) {
    $router->get('/mine', [ CertificateController::class, 'mine' ]);
    $router->get('/mine/{credential}', [ CertificateController::class, 'mineDetail' ])->alphaNumDash('credential');
    $router->get('/mine/{credential}/open-badge', [ OpenBadgeController::class, 'credential' ])->alphaNumDash('credential');
    $router->put('/{credential}/visibility', [ CertificateController::class, 'updateVisibility' ])->alphaNumDash('credential');
    $router->get('/verify/{credential}', [ CertificateController::class, 'verify' ])->alphaNumDash('credential');

    // Open Badges 3.0: what wallets and verifiers fetch (OpenBadgeCredential)
    $router->get('/open-badges/issuer', [ OpenBadgeController::class, 'issuer' ]);
    $router->get('/open-badges/keys/{kid}', [ OpenBadgeController::class, 'publicKey' ])->alphaNumDash('kid');
    $router->get('/open-badges/status/{listNumber}', [ OpenBadgeController::class, 'statusList' ])->int('listNumber');
    // The badge for a holder without an account, with the token from their holder link
    $router->get('/open-badges/holder/{credential}', [ OpenBadgeController::class, 'holderCredential' ])->alphaNumDash('credential');
});

// Next to core's profile/{username}/courses: the Certificates tab of a member's profile
$router->prefix('profile')->withPolicy(CertificatePolicy::class)->group(function ($router) {
    $router->get('/{username}/certificates', [ CertificateController::class, 'profileCertificates' ])->alphaNumDash('username');
});
