<?php

namespace FluentCommunityPro\App\Modules\Certificates\Http\Controllers;

use FluentCommunity\App\Http\Controllers\Controller;
use FluentCommunity\App\Models\User;
use FluentCommunity\Framework\Http\Request\Request;
use FluentCommunity\Framework\Support\Arr;
use FluentCommunity\Modules\Course\Model\Course;
use FluentCommunityPro\App\Modules\Certificates\Models\Certificate;
use FluentCommunityPro\App\Modules\Certificates\Models\CertificateTemplate;
use FluentCommunityPro\App\Modules\Certificates\Services\CertificatePresenter;
use FluentCommunityPro\App\Modules\Certificates\Services\CredentialId;
use FluentCommunityPro\App\Modules\Certificates\Services\ManualCertificates;

/**
 * The Manual Certificates tab. Course certificates stay in CertificateAdminController; the
 * row actions (suspend, reinstate, revoke) are shared and live there.
 */
class ManualCertificateController extends Controller
{
    const MAX_ROWS = 25;

    public function listManual(Request $request)
    {
        $query = Certificate::manual()->with([ 'user', 'template' ])->orderBy('id', 'DESC');

        $status = sanitize_key($request->get('status', ''));
        if (in_array($status, [ Certificate::STATUS_ISSUED, Certificate::STATUS_SUSPENDED, Certificate::STATUS_REVOKED ], true)) {
            $query->where('status', $status);
        }

        $templateId = absint($request->get('template_id'));
        if ($templateId) {
            $query->where('parent_id', $templateId);
        }

        $search = sanitize_text_field($request->get('search', ''));
        if ($search) {
            $credentialId = CredentialId::normalize($search);

            $query->where(function ($q) use ($search, $credentialId) {
                global $wpdb;
                $like = '%' . $wpdb->esc_like($search) . '%';

                if ($credentialId) {
                    $q->where('slug', $credentialId);
                }

                // The holder's name and email are in the serialized meta. Manual certificates
                // are few, so a scan of this list is fine.
                $q->orWhere('title', 'LIKE', $like)
                    ->orWhere('meta', 'LIKE', $like);
            });
        }

        $certificates = $query->paginate(min(100, max(1, absint($request->get('per_page', 20)))));

        return [
            'certificates' => [
                'data'         => array_map([ CertificatePresenter::class, 'forAdmin' ], $certificates->items()),
                'total'        => $certificates->total(),
                'current_page' => $certificates->currentPage(),
                'last_page'    => $certificates->lastPage(),
            ],
        ];
    }

    /**
     * The issue form for a template: its fields, pre-filled, and the published design for
     * the preview.
     */
    public function manualFields(Request $request)
    {
        $template = CertificateTemplate::find(absint($request->get('template_id')));
        if (!$template || !$template->isPublished()) {
            return $this->sendError([ 'message' => __('Choose a published certificate template.', 'fluent-community-pro') ]);
        }

        $course = null;
        $courseId = absint($request->get('course_id'));
        if ($courseId) {
            $course = Course::find($courseId);
            if (!$course) {
                return $this->sendError([ 'message' => __('The course could not be found.', 'fluent-community-pro') ]);
            }
        }

        $design = $template->getVersionDesign($template->getCurrentVersion());

        return [
            'fields' => ManualCertificates::fieldsFor($template, $course, sanitize_text_field($request->get('name', ''))),
            'design' => $design ? CertificatePresenter::resolveImages($design) : null,
        ];
    }

    /**
     * Issue to up to 25 people. The options apply to every row; each row has its own result,
     * so one bad row does not stop the others.
     */
    public function issueManual(Request $request)
    {
        $rows = $request->get('rows', []);
        if (!is_array($rows) || !$rows) {
            return $this->sendError([ 'message' => __('Add at least one person.', 'fluent-community-pro') ]);
        }

        if (count($rows) > self::MAX_ROWS) {
            return $this->sendError([
                /* translators: %d: the most people one request can issue to */
                'message' => sprintf(__('Send at most %d people at a time.', 'fluent-community-pro'), self::MAX_ROWS),
            ]);
        }

        $account = sanitize_key($request->get('account', 'none'));

        $options = [
            'template_id'   => absint($request->get('template_id')),
            'course_id'     => absint($request->get('course_id')),
            'account'       => in_array($account, [ 'none', 'link', 'create' ], true) ? $account : 'none',
            'account_email' => $request->get('account_email') === 'yes',
            'notify'        => $request->get('notify') === 'yes',
            'privacy'       => $request->get('privacy') === 'private' ? 'private' : 'public',
            'expires_at'    => $this->date($request->get('expires_at')),
            'issued_at'     => $this->date($request->get('issued_at')),
        ];

        // Today means now, so the list keeps its order
        if ($options['issued_at'] === current_time('Y-m-d')) {
            $options['issued_at'] = '';
        }

        $results = [];
        foreach (array_values($rows) as $index => $row) {
            $row = is_array($row) ? $row : [];

            $certificate = ManualCertificates::issue(array_merge($options, [
                'name'    => Arr::get($row, 'name', ''),
                'email'   => Arr::get($row, 'email', ''),
                'user_id' => absint(Arr::get($row, 'user_id')),
                // Sanitized per value by the service: known tags, plain text
                'values'  => is_array(Arr::get($row, 'values')) ? $row['values'] : [],
            ]), get_current_user_id());

            if (is_wp_error($certificate)) {
                $results[] = [ 'index' => $index, 'status' => 'failed', 'message' => $certificate->get_error_message() ];
                continue;
            }

            $results[] = [
                'index'       => $index,
                'status'      => 'issued',
                'certificate' => CertificatePresenter::forAdmin($certificate),
            ];
        }

        $issued = count(array_filter($results, function ($result) {
            return $result['status'] === 'issued';
        }));

        if (!$issued && count($results) === 1) {
            return $this->sendError([ 'message' => $results[0]['message'] ]);
        }

        return [
            /* translators: %d: number of certificates issued */
            'message' => sprintf(_n('%d certificate has been issued.', '%d certificates have been issued.', $issued, 'fluent-community-pro'), $issued),
            'results' => $results,
        ];
    }

    /**
     * The edit form: the certificate, its fields with the stored values, and its design.
     * With latest=yes, the fields and design of the template's current version instead.
     */
    public function getManual(Request $request, $id)
    {
        $certificate = Certificate::manual()->with([ 'user', 'template' ])->findOrFail($id);
        $template = $certificate->template;

        $version = (int) Arr::get($certificate->meta, 'template_version');
        $currentVersion = $template && $template->isPublished() ? $template->getCurrentVersion() : 0;

        if ($request->get('latest') === 'yes' && $currentVersion) {
            $version = $currentVersion;
        }

        $design = $template ? $template->getVersionDesign($version) : null;
        $values = $certificate->getData();

        return [
            'certificate'    => CertificatePresenter::forAdmin($certificate),
            'fields'         => $template ? ManualCertificates::fieldsFor($template, null, '', $version, $values) : [],
            'design'         => $design ? CertificatePresenter::resolveImages($design) : null,
            'values'         => $values,
            'latest_version' => $currentVersion > (int) Arr::get($certificate->meta, 'template_version') ? $currentVersion : 0,
            'account'        => $certificate->user ? $this->userSummary($certificate->user) : null,
            'history'        => $this->history($certificate),
        ];
    }

    public function updateManual(Request $request, $id)
    {
        $certificate = Certificate::manual()->findOrFail($id);
        $account = sanitize_key($request->get('account', 'none'));

        $result = ManualCertificates::update($certificate, [
            'name'           => $request->get('name', ''),
            'email'          => $request->get('email', ''),
            'account'        => in_array($account, [ 'none', 'link', 'create' ], true) ? $account : 'none',
            'user_id'        => absint($request->get('user_id')),
            'account_email'  => $request->get('account_email') === 'yes',
            // Sanitized per value by the service: known tags, plain text
            'values'         => is_array($request->get('values')) ? $request->get('values') : [],
            'privacy'        => $request->get('privacy') === 'private' ? 'private' : 'public',
            'expires_at'     => $this->date($request->get('expires_at')),
            'latest_version' => $request->get('latest_version') === 'yes',
        ], get_current_user_id());

        if (is_wp_error($result)) {
            return $this->sendError([ 'message' => $result->get_error_message() ]);
        }

        return [
            'message'     => __('The certificate has been updated.', 'fluent-community-pro'),
            'certificate' => CertificatePresenter::forAdmin($result->fresh([ 'user', 'template' ])),
        ];
    }

    /**
     * The account with this email, so the form can offer to link it.
     */
    public function lookupUser(Request $request)
    {
        $email = sanitize_email($request->get('email', ''));
        $user = is_email($email) ? User::where('user_email', $email)->first() : null;

        return [ 'user' => $user ? $this->userSummary($user) : null ];
    }

    private function userSummary(User $user)
    {
        return [
            'id'     => (int) $user->ID,
            'name'   => (string) $user->display_name,
            'email'  => (string) $user->user_email,
            'avatar' => (string) $user->photo,
        ];
    }

    /**
     * The change log, newest first, with the admins' names. The last entry is the issue.
     */
    private function history(Certificate $certificate)
    {
        $entries = array_reverse((array) Arr::get($certificate->meta, 'history', []));
        // The issue itself closes the log
        $entries[] = [ 'by' => Arr::get($certificate->meta, 'issued_by'), 'at' => (string) $certificate->created_at, 'changed' => [ 'issued' ] ];
        $names = [];

        return array_map(function ($entry) use (&$names) {
            $by = (int) Arr::get($entry, 'by');
            if (!isset($names[$by])) {
                $user = $by ? get_user_by('ID', $by) : null;
                $names[$by] = $user ? $user->display_name : '';
            }

            return [
                'by'      => $names[$by],
                'at'      => (string) Arr::get($entry, 'at', ''),
                'changed' => array_values(array_map('strval', (array) Arr::get($entry, 'changed', []))),
            ];
        }, $entries);
    }

    /**
     * @return string 'Y-m-d', or '' when not a date
     */
    private function date($value)
    {
        $value = sanitize_text_field((string) $value);

        return preg_match('/^\d{4}-\d{2}-\d{2}$/', $value) ? $value : '';
    }
}
