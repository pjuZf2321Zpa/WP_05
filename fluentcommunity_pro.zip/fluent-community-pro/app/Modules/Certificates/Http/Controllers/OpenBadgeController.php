<?php

namespace FluentCommunityPro\App\Modules\Certificates\Http\Controllers;

use FluentCommunity\App\Http\Controllers\Controller;
use FluentCommunity\Framework\Http\Request\Request;
use FluentCommunityPro\App\Modules\Certificates\Models\Certificate;
use FluentCommunityPro\App\Modules\Certificates\Services\CertificatePresenter;
use FluentCommunityPro\App\Modules\Certificates\Services\CredentialId;
use FluentCommunityPro\App\Modules\Certificates\Services\OpenBadgeCredential;
use FluentCommunityPro\App\Modules\Certificates\Services\OpenBadgeSigner;

/**
 * Open Badges 3.0 (OpenBadgeCredential). The holder downloads their signed credential (logged
 * in, or with the holder link's token when they have no account); the
 * issuer profile, the public key and the status lists are public, because any wallet or
 * verifier has to fetch them, also on a private community.
 */
class OpenBadgeController extends Controller
{
    /**
     * The holder's certificate as a signed VC-JWT, for the portal to bake into the PNG.
     */
    public function credential(Request $request, $credential)
    {
        $credentialId = CredentialId::normalize($credential);
        $certificate = $credentialId ? Certificate::byCredential($credentialId)->where('user_id', get_current_user_id())->first() : null;

        return $this->signedFor($certificate);
    }

    /**
     * The same, for a manual certificate's holder without an account: the token from their
     * holder link (CertificatePresenter::holderUrl()) stands in for the login.
     */
    public function holderCredential(Request $request, $credential)
    {
        $credentialId = CredentialId::normalize($credential);
        $certificate = $credentialId ? Certificate::byCredential($credentialId)->first() : null;

        if ($certificate && !CertificatePresenter::isHolderToken($certificate, sanitize_key((string) $request->get('token', '')))) {
            $certificate = null;
        }

        return $this->signedFor($certificate);
    }

    private function signedFor($certificate)
    {
        if (!$certificate) {
            return $this->sendError([ 'message' => __('Certificate not found.', 'fluent-community-pro') ], 404);
        }

        if (!OpenBadgeCredential::isAvailable()) {
            return $this->sendError([ 'message' => __('Open Badges are not available on this site.', 'fluent-community-pro') ], 422);
        }

        if ($certificate->getVerificationStatus() !== 'valid') {
            return $this->sendError([ 'message' => __('Only a valid certificate can be downloaded as an Open Badge.', 'fluent-community-pro') ], 422);
        }

        $jwt = OpenBadgeCredential::signed($certificate);

        if (is_wp_error($jwt)) {
            return $this->sendError([ 'message' => $jwt->get_error_message() ], 500);
        }

        return [ 'credential_jwt' => $jwt ];
    }

    public function issuer(Request $request)
    {
        return OpenBadgeCredential::issuerProfile();
    }

    public function publicKey(Request $request, $kid)
    {
        $jwk = OpenBadgeSigner::publicJwk($kid);

        if (!$jwk) {
            return $this->sendError([ 'message' => __('Unknown key.', 'fluent-community-pro') ], 404);
        }

        return $jwk;
    }

    /**
     * The BitstringStatusListCredential as the bare Compact JWS (application/vc+jwt), not as
     * a JSON string: verifiers parse the body as the JWT itself.
     */
    public function statusList(Request $request, $listNumber)
    {
        $jwt = OpenBadgeCredential::signedStatusList((int) $listNumber);

        if (is_wp_error($jwt)) {
            return $this->sendError([ 'message' => $jwt->get_error_message() ], $jwt->get_error_code() === 'not_found' ? 404 : 500);
        }

        status_header(200);
        header('Content-Type: application/vc+jwt; charset=utf-8');
        header('Cache-Control: public, max-age=300');
        echo $jwt; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- a base64url JWS, not HTML
        exit();
    }
}
