<?php

namespace FluentCommunityPro\App\Modules\Certificates\Http\Controllers;

use FluentCommunity\App\Http\Controllers\Controller;
use FluentCommunity\Framework\Http\Request\Request;
use FluentCommunity\Modules\Course\Model\Course;
use FluentCommunityPro\App\Modules\Certificates\Models\Certificate;
use FluentCommunityPro\App\Modules\Certificates\Services\CertificateBackfill;
use FluentCommunityPro\App\Modules\Certificates\Services\CertificateIssuer;
use FluentCommunityPro\App\Modules\Certificates\Services\CertificatePresenter;
use FluentCommunityPro\App\Modules\Certificates\Services\CertificateSettings;
use FluentCommunityPro\App\Modules\Certificates\Services\CredentialId;

class CertificateAdminController extends Controller
{
    public function listIssued(Request $request)
    {
        // The Course Certificates tab; manual certificates have their own list
        $query = Certificate::courseCertificates()->with([ 'user' ])->orderBy('id', 'DESC');

        $courseId = absint($request->get('course_id'));
        if ($courseId) {
            $query->where('space_id', $courseId);
        }

        $status = sanitize_key($request->get('status', ''));
        if (in_array($status, [ Certificate::STATUS_ISSUED, Certificate::STATUS_SUSPENDED, Certificate::STATUS_REVOKED ], true)) {
            $query->where('status', $status);
        }

        $search = sanitize_text_field($request->get('search', ''));
        if ($search) {
            $credentialId = CredentialId::normalize($search);

            $query->where(function ($q) use ($search, $credentialId) {
                if ($credentialId) {
                    $q->where('slug', $credentialId);
                }

                $q->orWhereHas('user', function ($userQuery) use ($search) {
                    global $wpdb;
                    $like = '%' . $wpdb->esc_like($search) . '%';
                    $userQuery->where('display_name', 'LIKE', $like)
                        ->orWhere('user_email', 'LIKE', $like);
                });
            });
        }

        $certificates = $query->paginate(min(100, max(1, absint($request->get('per_page', 20)))));

        return [
            'certificates' => [
                'data'         => array_map([ CertificatePresenter::class, 'forAdmin' ], $certificates->items()),
                'total'        => $certificates->total(),
                'current_page' => $certificates->currentPage(),
                'last_page'    => $certificates->lastPage(),
            ],
        ];
    }

    public function suspend(Request $request, $id)
    {
        return $this->respond(CertificateIssuer::suspend(Certificate::findOrFail($id), $request->get('reason', ''), get_current_user_id()), __('The certificate has been suspended.', 'fluent-community-pro'));
    }

    public function reinstate(Request $request, $id)
    {
        return $this->respond(CertificateIssuer::reinstate(Certificate::findOrFail($id), get_current_user_id()), __('The certificate has been reinstated.', 'fluent-community-pro'));
    }

    public function revoke(Request $request, $id)
    {
        return $this->respond(CertificateIssuer::revoke(Certificate::findOrFail($id), $request->get('reason', ''), get_current_user_id()), __('The certificate has been revoked.', 'fluent-community-pro'));
    }

    public function reissue(Request $request, $id)
    {
        return $this->respond(CertificateIssuer::reissue(Certificate::findOrFail($id), get_current_user_id()), __('The certificate has been reissued with the current details.', 'fluent-community-pro'));
    }

    public function getCourseSettings(Request $request, $course_id)
    {
        $course = Course::findOrFail($course_id);

        return [ 'settings' => CertificateSettings::get($course) ];
    }

    public function saveCourseSettings(Request $request, $course_id)
    {
        $course = Course::findOrFail($course_id);
        $settings = CertificateSettings::save($course, (array) $request->get('settings', []));

        if (is_wp_error($settings)) {
            return $this->sendError([ 'message' => $settings->get_error_message() ]);
        }

        return [
            'message'  => __('Certificate settings have been saved.', 'fluent-community-pro'),
            'settings' => $settings,
        ];
    }

    public function backfillSummary(Request $request, $course_id)
    {
        return [ 'backfill' => CertificateBackfill::summary(Course::findOrFail($course_id)) ];
    }

    /**
     * One batch of certificates for past completions; the screen calls again with the
     * returned cursor until done.
     */
    public function backfill(Request $request, $course_id)
    {
        $result = CertificateBackfill::run(Course::findOrFail($course_id), absint($request->get('cursor', 0)));

        if (is_wp_error($result)) {
            return $this->sendError([ 'message' => $result->get_error_message() ]);
        }

        return [ 'backfill' => $result ];
    }

    private function respond($result, $message)
    {
        if (is_wp_error($result)) {
            return $this->sendError([ 'message' => $result->get_error_message() ]);
        }

        return [
            'message'     => $message,
            'certificate' => CertificatePresenter::forAdmin($result),
        ];
    }
}
