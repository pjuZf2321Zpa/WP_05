<?php

namespace FluentCommunityPro\App\Modules\Certificates\Http\Controllers;

use FluentCommunity\App\Http\Controllers\Controller;
use FluentCommunity\Framework\Http\Request\Request;
use FluentCommunityPro\App\Modules\Certificates\Models\Certificate;
use FluentCommunityPro\App\Modules\Certificates\Models\CertificateTemplate;
use FluentCommunity\App\Models\Meta;
use FluentCommunityPro\App\Modules\Certificates\Services\CertificateIssuer;
use FluentCommunityPro\App\Modules\Certificates\Services\CertificatePresenter;
use FluentCommunityPro\App\Modules\Certificates\Services\CertificateSettings;
use FluentCommunityPro\App\Services\NamedLock;
use FluentCommunityPro\App\Modules\Certificates\Services\TemplateDesign;

class CertificateTemplateController extends Controller
{
    public function listTemplates(Request $request)
    {
        $templates = CertificateTemplate::orderBy('updated_at', 'DESC')->get();
        $withDesign = $request->get('with_design') === 'yes';

        $usage = Certificate::selectRaw('parent_id, COUNT(*) as total')
            ->groupBy('parent_id')
            ->pluck('total', 'parent_id')
            ->toArray();

        return [
            'templates' => $templates->map(function ($template) use ($usage, $withDesign) {
                $item = $this->summary($template, (int) ($usage[$template->id] ?? 0));
                if ($withDesign) {
                    // For the thumbnails. A design is a few KB.
                    $item['design'] = CertificatePresenter::resolveImages($template->getDesign());
                }
                return $item;
            })->values(),
        ];
    }

    public function createTemplate(Request $request)
    {
        $title = sanitize_text_field($request->get('title', ''));

        if (!$title) {
            return $this->sendError([ 'message' => __('Give the template a name.', 'fluent-community-pro') ]);
        }

        $design = $request->get('design') ? TemplateDesign::sanitize($request->get('design')) : TemplateDesign::blank();
        if (is_wp_error($design)) {
            return $this->sendError([ 'message' => $design->get_error_message() ]);
        }

        $template = CertificateTemplate::create([
            'title'   => $title,
            'message' => wp_json_encode($design),
        ]);

        return [
            'message'  => __('The template has been created.', 'fluent-community-pro'),
            'template' => $this->detail($template),
        ];
    }

    public function getTemplate(Request $request, $id)
    {
        $template = CertificateTemplate::findOrFail($id);

        return [ 'template' => $this->detail($template) ];
    }

    public function updateTemplate(Request $request, $id)
    {
        $template = CertificateTemplate::findOrFail($id);

        $title = null;
        if ($request->has('title')) {
            $title = sanitize_text_field($request->get('title'));
            if (!$title) {
                return $this->sendError([ 'message' => __('Give the template a name.', 'fluent-community-pro') ]);
            }
        }

        $design = null;
        if ($request->has('design')) {
            $design = TemplateDesign::sanitize($request->get('design'));
            if (is_wp_error($design)) {
                return $this->sendError([ 'message' => $design->get_error_message() ]);
            }
        }

        $restore = $request->get('restore') === 'yes';

        // Under the template's lock, on a fresh copy: a publish running at the same time moves
        // the version pointer in the same meta, and a stale copy saved here would undo it
        $saved = NamedLock::run($template->lockName(), function () use ($id, $title, $design, $restore) {
            $fresh = CertificateTemplate::find($id);
            if (!$fresh) {
                return new \WP_Error('not_found', __('The template no longer exists.', 'fluent-community-pro'));
            }

            if ($title !== null) {
                $fresh->title = $title;
            }

            if ($restore && $fresh->status === CertificateTemplate::STATUS_ARCHIVED) {
                $fresh->status = $fresh->getCurrentVersion() ? CertificateTemplate::STATUS_ACTIVE : CertificateTemplate::STATUS_DRAFT;
            }

            if ($design !== null) {
                // The working copy changes; issued certificates keep the version they were issued with
                $fresh->message = wp_json_encode($design);
                $meta = $fresh->meta;
                $meta['has_draft_changes'] = true;
                $fresh->meta = $meta;
            }

            $fresh->save();

            return $fresh;
        });

        if (is_wp_error($saved)) {
            return $this->sendError([ 'message' => $saved->get_error_message() ]);
        }

        return [
            'message'  => __('The template has been saved.', 'fluent-community-pro'),
            'template' => $this->detail($saved),
        ];
    }

    public function publishTemplate(Request $request, $id)
    {
        $template = CertificateTemplate::findOrFail($id);

        if ($template->status === CertificateTemplate::STATUS_ARCHIVED) {
            return $this->sendError([ 'message' => __('Restore the template before publishing it.', 'fluent-community-pro') ]);
        }

        $version = $template->publish();
        if (is_wp_error($version)) {
            return $this->sendError([ 'message' => $version->get_error_message() ]);
        }

        return [
            /* translators: %d: version number */
            'message'  => sprintf(__('Version %d is published. New certificates use it.', 'fluent-community-pro'), $version),
            'template' => $this->detail($template->fresh()),
        ];
    }

    /**
     * A template that issued certificates still point at is archived, never deleted. A
     * template a course awards is neither: its students would silently stop getting
     * certificates.
     *
     * Runs under the issuing lock, so neither a certificate (CertificateIssuer::issue) nor a
     * course assignment (CertificateSettings::save) can use the template between the checks
     * and the delete; both re-check the template inside the same lock.
     */
    public function deleteTemplate(Request $request, $id)
    {
        $template = CertificateTemplate::findOrFail($id);

        $result = NamedLock::run(CertificateIssuer::LOCK_NAME, function () use ($template) {
            // Inside the lock: course settings are saved under it too (CertificateSettings::save)
            $courses = CertificateSettings::coursesUsingTemplate($template->id);
            if ($courses) {
                /* translators: %s: comma-separated course titles */
                return new \WP_Error('in_use', sprintf(__('These courses award certificates with this template: %s. Choose another template for them first.', 'fluent-community-pro'), implode(', ', $courses)));
            }

            if (Certificate::where('parent_id', $template->id)->exists()) {
                $template->status = CertificateTemplate::STATUS_ARCHIVED;
                $template->save();

                return __('Certificates were issued from this template, so it has been archived instead of deleted.', 'fluent-community-pro');
            }

            Meta::where('object_type', CertificateTemplate::VERSION_META_TYPE)->where('object_id', $template->id)->delete();
            $template->delete();

            return __('The template has been deleted.', 'fluent-community-pro');
        });

        if (is_wp_error($result)) {
            return $this->sendError([ 'message' => $result->get_error_message() ]);
        }

        return [ 'message' => $result ];
    }

    /**
     * A background, logo or signature image. It goes into the WordPress media library, so the
     * design stores an attachment ID and offload plugins rewrite its URL.
     */
    public function uploadImage(Request $request)
    {
        // media_handle_upload() reads $_FILES itself; the REST router has checked the nonce
        $file = isset($_FILES['file']) && is_array($_FILES['file']) ? $_FILES['file'] : []; // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput

        if (empty($file['tmp_name']) || !empty($file['error'])) {
            return $this->sendError([ 'message' => __('No upload file was received. Please try again.', 'fluent-community-pro') ]);
        }

        $maxBytes = (int) apply_filters('fluent_community/certificate/max_image_bytes', 5 * MB_IN_BYTES);
        if ((int) ($file['size'] ?? 0) > $maxBytes) {
            /* translators: %s: maximum file size, for example 5 MB */
            return $this->sendError([ 'message' => sprintf(__('The image must be smaller than %s.', 'fluent-community-pro'), size_format($maxBytes)) ]);
        }

        // No SVG: it can carry script, and the PNG export draws it into a canvas
        $allowed = [ 'jpg|jpeg|jpe' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp' ];
        $check = wp_check_filetype_and_ext($file['tmp_name'], (string) ($file['name'] ?? ''), $allowed);
        if (empty($check['type'])) {
            return $this->sendError([ 'message' => __('Upload a JPG, PNG or WebP image.', 'fluent-community-pro') ]);
        }

        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';

        $attachmentId = media_handle_upload('file', 0, [], [
            'test_form' => false,
            'mimes'     => $allowed,
        ]);

        if (is_wp_error($attachmentId)) {
            return $this->sendError([ 'message' => $attachmentId->get_error_message() ]);
        }

        return [
            'image' => [
                'id'  => $attachmentId,
                'url' => (string) wp_get_attachment_url($attachmentId),
            ],
        ];
    }

    private function summary(CertificateTemplate $template, $usage = 0)
    {
        return [
            'id'                => $template->id,
            'title'             => $template->title,
            'status'            => $template->status,
            'current_version'   => $template->getCurrentVersion(),
            'has_draft_changes' => !empty($template->meta['has_draft_changes']),
            'issued_count'      => $usage,
            'updated_at'        => (string) $template->updated_at,
        ];
    }

    private function detail(CertificateTemplate $template)
    {
        return array_merge($this->summary($template), [
            'design' => CertificatePresenter::resolveImages($template->getDesign()),
        ]);
    }
}
