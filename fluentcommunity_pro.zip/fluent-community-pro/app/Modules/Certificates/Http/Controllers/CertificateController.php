<?php

namespace FluentCommunityPro\App\Modules\Certificates\Http\Controllers;

use FluentCommunity\App\Http\Controllers\Controller;
use FluentCommunity\App\Models\XProfile;
use FluentCommunity\App\Services\Helper;
use FluentCommunity\App\Services\RateLimiter;
use FluentCommunity\App\Functions\Utility;
use FluentCommunity\Framework\Http\Request\Request;
use FluentCommunityPro\App\Modules\Certificates\Models\Certificate;
use FluentCommunityPro\App\Modules\Certificates\Services\CertificateOptions;
use FluentCommunityPro\App\Modules\Certificates\Services\CertificatePresenter;
use FluentCommunityPro\App\Modules\Certificates\Services\CredentialId;

class CertificateController extends Controller
{
    /**
     * Requests per IP per window on the public lookup. Credential IDs carry 60 random bits,
     * so this is about load, not guessing.
     */
    const VERIFY_LIMIT = 60;
    const VERIFY_WINDOW = 300;

    /**
     * The holder's certificates, a page at a time and without render data: a list never
     * carries designs. The card or viewer asks for one certificate's render data (mineDetail).
     */
    public function mine(Request $request)
    {
        $certificates = Certificate::where('user_id', get_current_user_id())
            ->where('status', '!=', Certificate::STATUS_REVOKED)
            ->orderBy('created_at', 'DESC')
            ->paginate(min(50, max(1, absint($request->get('per_page', 20)))));

        return [
            'certificates' => [
                'data'         => array_map([ CertificatePresenter::class, 'forOwnerSummary' ], $certificates->items()),
                'total'        => $certificates->total(),
                'current_page' => $certificates->currentPage(),
                'last_page'    => $certificates->lastPage(),
            ],
        ];
    }

    /**
     * A member's Certificates tab. The member sees all of theirs (to share them or change
     * their visibility); others, when the site setting allows (CertificateOptions), see the
     * public ones that are currently issued.
     * Each page carries render data for the cards, so a page is small.
     */
    public function profileCertificates(Request $request, $username)
    {
        $xprofile = XProfile::where('username', $username)->first();

        $canView = $xprofile
            && ($xprofile->status === 'active' || Helper::isModerator())
            && Utility::canViewUserProfile($xprofile->user_id)
            && CertificateOptions::canSeeProfileCertificates($xprofile->user_id);

        if (!$canView) {
            return $this->sendError([ 'message' => __('You cannot view this profile.', 'fluent-community-pro') ], 403);
        }

        $isOwner = (int) $xprofile->user_id === get_current_user_id();

        $query = Certificate::where('user_id', $xprofile->user_id)->orderBy('created_at', 'DESC');

        if ($isOwner) {
            $query->where('status', '!=', Certificate::STATUS_REVOKED);
        } else {
            $query->where('status', Certificate::STATUS_ISSUED)->where('privacy', 'public');
        }

        $certificates = $query->paginate(min(12, max(1, absint($request->get('per_page', 12)))));

        return [
            'is_owner'     => $isOwner,
            'certificates' => [
                'data'         => array_map(function ($certificate) use ($isOwner) {
                    return CertificatePresenter::forProfile($certificate, $isOwner);
                }, $certificates->items()),
                'total'        => $certificates->total(),
                'current_page' => $certificates->currentPage(),
                'last_page'    => $certificates->lastPage(),
            ],
        ];
    }

    public function mineDetail(Request $request, $credential)
    {
        $certificate = $this->findOwned($credential);
        if (!$certificate || $certificate->status === Certificate::STATUS_REVOKED) {
            return $this->sendError([ 'message' => __('Certificate not found.', 'fluent-community-pro') ], 404);
        }

        return [ 'certificate' => CertificatePresenter::forOwner($certificate) ];
    }

    public function updateVisibility(Request $request, $credential)
    {
        $certificate = $this->findOwned($credential);
        if (!$certificate) {
            return $this->sendError([ 'message' => __('Certificate not found.', 'fluent-community-pro') ], 404);
        }

        $certificate->privacy = $request->get('privacy') === 'private' ? 'private' : 'public';
        $certificate->save();

        return [
            'message'     => __('The visibility has been updated.', 'fluent-community-pro'),
            'certificate' => CertificatePresenter::forOwnerSummary($certificate),
        ];
    }

    public function verify(Request $request, $credential)
    {
        if ($this->isRateLimited()) {
            return $this->sendError([ 'message' => __('Too many lookups. Please try again in a few minutes.', 'fluent-community-pro') ], 429);
        }

        $credentialId = CredentialId::normalize($credential);
        $certificate = $credentialId ? Certificate::byCredential($credentialId)->first() : null;

        if (!$certificate) {
            return $this->sendError([ 'message' => __('No certificate has this ID.', 'fluent-community-pro') ], 404);
        }

        return [ 'certificate' => CertificatePresenter::forVerification($certificate) ];
    }

    private function findOwned($credential)
    {
        $credentialId = CredentialId::normalize($credential);

        if (!$credentialId) {
            return null;
        }

        return Certificate::byCredential($credentialId)->where('user_id', get_current_user_id())->first();
    }

    private function isRateLimited()
    {
        $key = 'fcom_cert_verify_' . md5((string) Helper::getIp(true));

        // The locked counter holds under parallel lookups. Older cores lack it.
        if (class_exists(RateLimiter::class)) {
            return RateLimiter::hit($key, self::VERIFY_LIMIT, self::VERIFY_WINDOW);
        }

        $count = (int) get_transient($key);

        if ($count >= self::VERIFY_LIMIT) {
            return true;
        }

        set_transient($key, $count + 1, self::VERIFY_WINDOW);

        return false;
    }
}
