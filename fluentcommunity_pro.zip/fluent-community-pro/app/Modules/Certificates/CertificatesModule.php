<?php

namespace FluentCommunityPro\App\Modules\Certificates;

use FluentCommunity\App\Services\Helper;
use FluentCommunityPro\App\Modules\Certificates\Models\Certificate;
use FluentCommunityPro\App\Modules\Certificates\Services\CertificateIssuer;
use FluentCommunityPro\App\Modules\Certificates\Services\CertificateMailer;
use FluentCommunityPro\App\Modules\Certificates\Services\CertificateOptions;
use FluentCommunityPro\App\Modules\Certificates\Services\CertificatePresenter;
use FluentCommunityPro\App\Modules\Certificates\Services\OpenBadgeCredential;

/**
 * Course certificates: templates, issuing on course completion, and public verification.
 * Each course opts in through its certificate settings, so there is no global switch beyond
 * the course module itself.
 *
 * Plan and research: fluent-community docs/certificates/.
 */
class CertificatesModule
{
    public function register($app)
    {
        $app->router->group(function ($router) {
            require_once __DIR__ . '/Http/certificates_api.php';
        });

        // After core's own completion listeners (FluentCRM triggers etc.)
        add_action('fluent_community/course/completed', [ CertificateIssuer::class, 'onCourseCompleted' ], 20, 2);

        // An Open Badge's status list must show a new, changed or erased certificate at once
        foreach ([ 'issued', 'reissued', 'suspended', 'reinstated', 'revoked' ] as $event) {
            add_action('fluent_community/certificate/' . $event, [ OpenBadgeCredential::class, 'forgetStatus' ]);
        }
        add_action('fluent_community/certificate/user_certificates_deleted', [ OpenBadgeCredential::class, 'forgetAllStatus' ]);

        (new VerificationPage())->register();
        (new CertificatePrivacy())->register();
        (new CertificateMailer())->register();

        // Templates, the editor, the issued list and the course "Certificate" tab; in the
        // portal, the profile tab and the congratulations dialog
        add_filter('fluent_community_pro/module_entries', function ($entries) {
            $entries['certificates-admin'] = [ 'runtime' => 'admin' ];
            $entries['certificates-portal'] = [ 'runtime' => 'portal' ];
            return $entries;
        });

        add_filter('fluent_community/profile_view_data', [ $this, 'addProfileTab' ], 10, 2);
        add_filter('fluent_community/course/lesson_completion_response', [ $this, 'addIssuedCertificate' ], 10, 2);
    }

    /**
     * The module is switched off (or the course module is): nothing runs, the verification
     * page included, except the privacy hooks, so a holder's data can still be exported and
     * erased.
     */
    public static function registerPrivacyOnly()
    {
        (new CertificatePrivacy())->register();
    }

    /**
     * "Certificates" on a member's profile: always for the member; for others only when the
     * site's profile_visibility setting allows it and there is a public certificate to show.
     */
    public function addProfileTab($profile, $xprofile)
    {
        if (!empty($profile['is_restricted']) || !CertificateOptions::canSeeProfileCertificates($xprofile->user_id)) {
            return $profile;
        }

        $isOwner = (int) $xprofile->user_id === get_current_user_id();

        if (!$isOwner) {
            $hasPublic = Certificate::where('user_id', $xprofile->user_id)
                ->where('status', Certificate::STATUS_ISSUED)
                ->where('privacy', 'public')
                ->exists();

            if (!$hasPublic) {
                return $profile;
            }
        }

        $profile['profile_navs'][] = [
            'slug'          => 'user_certificates',
            'wrapper_class' => 'fcom_profile_certificates',
            'title'         => __('Certificates', 'fluent-community-pro'),
            'url'           => Helper::baseUrl('u/' . $xprofile->username . '/certificates'),
            'route'         => [ 'name' => 'user_certificates' ],
        ];

        return $profile;
    }

    /**
     * The lesson that completes a course: the certificate was issued on course/completed
     * during this request, so the portal can show it straight away.
     */
    public function addIssuedCertificate($response, $course)
    {
        if (empty($response['is_completed'])) {
            return $response;
        }

        // Only the request that issued it: unmarking and marking a lesson again on a finished
        // course reports is_completed too, and must not congratulate the student again
        $certificate = CertificateIssuer::issuedInThisRequest($course->id, get_current_user_id());

        if ($certificate) {
            $response['certificate'] = CertificatePresenter::forProfile($certificate, true);
        }

        return $response;
    }
}
