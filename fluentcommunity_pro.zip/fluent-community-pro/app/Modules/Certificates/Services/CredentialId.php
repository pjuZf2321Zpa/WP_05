<?php

namespace FluentCommunityPro\App\Modules\Certificates\Services;

/**
 * Credential IDs: FC-XXXX-XXXX-XXXX from an alphabet without 0/O/1/I, so a person can read
 * one off paper. 12 random characters from 32 symbols is 60 bits: not guessable, and the
 * public verification page never accepts anything else as a lookup key.
 */
class CredentialId
{
    const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

    public static function generate()
    {
        $chars = '';
        $max = strlen(self::ALPHABET) - 1;

        for ($i = 0; $i < 12; $i++) {
            $chars .= self::ALPHABET[random_int(0, $max)];
        }

        return 'FC-' . implode('-', str_split($chars, 4));
    }

    /**
     * Normalise what a person typed: case, spaces and missing dashes.
     *
     * @param string $value
     * @return string|null the canonical ID, or null when it cannot be one
     */
    public static function normalize($value)
    {
        $value = strtoupper(preg_replace('/[^A-Za-z0-9]/', '', (string) $value));

        if (strpos($value, 'FC') === 0 && strlen($value) === 14) {
            $value = substr($value, 2);
        }

        if (!preg_match('/^[' . self::ALPHABET . ']{12}$/', $value)) {
            return null;
        }

        return 'FC-' . implode('-', str_split($value, 4));
    }
}
