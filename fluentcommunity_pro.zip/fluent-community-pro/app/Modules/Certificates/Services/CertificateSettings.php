<?php

namespace FluentCommunityPro\App\Modules\Certificates\Services;

use FluentCommunity\App\Models\Meta;
use FluentCommunity\Framework\Support\Arr;
use FluentCommunity\Modules\Course\Model\Course;
use FluentCommunityPro\App\Modules\Certificates\Models\CertificateTemplate;
use FluentCommunityPro\App\Services\NamedLock;

/**
 * Per-course certificate settings, stored as space meta (like the course welcome banner),
 * so core's course settings whitelist needs no change.
 */
class CertificateSettings
{
    const META_KEY = 'course_certificate_settings';

    public static function defaults()
    {
        return [
            'enabled'       => 'no',
            'template_id'   => 0,
            'expiry_months' => 0,
        ];
    }

    /**
     * @param \FluentCommunity\Modules\Course\Model\Course $course
     * @return array
     */
    public static function get($course)
    {
        $stored = (array) $course->getCustomMeta(self::META_KEY, []);

        return wp_parse_args(Arr::only($stored, array_keys(self::defaults())), self::defaults());
    }

    /**
     * @param \FluentCommunity\Modules\Course\Model\Course $course
     * @param array $input
     * @return array|\WP_Error the saved settings
     */
    public static function save($course, $input)
    {
        $settings = [
            'enabled'       => Arr::get($input, 'enabled') === 'yes' ? 'yes' : 'no',
            'template_id'   => absint(Arr::get($input, 'template_id', 0)),
            'expiry_months' => min(600, absint(Arr::get($input, 'expiry_months', 0))),
        ];

        // Under the issuing lock, which template deletion also takes: a template cannot be
        // deleted or archived between the check below and the save
        return NamedLock::run(CertificateIssuer::LOCK_NAME, function () use ($course, $settings) {
            if ($settings['enabled'] === 'yes') {
                $template = $settings['template_id'] ? CertificateTemplate::find($settings['template_id']) : null;

                if (!$template || !$template->isPublished()) {
                    return new \WP_Error('invalid_template', __('Choose a published certificate template.', 'fluent-community-pro'));
                }
            }

            $course->updateCustomMeta(self::META_KEY, $settings);

            return $settings;
        });
    }

    /**
     * Courses that award certificates with this template.
     *
     * @param int $templateId
     * @return string[] course titles, keyed by course ID
     */
    public static function coursesUsingTemplate($templateId)
    {
        $courseIds = [];

        $rows = Meta::where('object_type', 'space')->where('meta_key', self::META_KEY)->get();
        foreach ($rows as $row) {
            $value = (array) $row->value;
            if (Arr::get($value, 'enabled') === 'yes' && (int) Arr::get($value, 'template_id') === (int) $templateId) {
                $courseIds[] = (int) $row->object_id;
            }
        }

        if (!$courseIds) {
            return [];
        }

        return Course::whereIn('id', $courseIds)->pluck('title', 'id')->toArray();
    }
}
