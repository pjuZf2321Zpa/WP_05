<?php

namespace FluentCommunityPro\App\Modules\Certificates\Services;

use FluentCommunity\App\Functions\Utility;
use FluentCommunity\App\Models\User;
use FluentCommunity\App\Services\Helper;
use FluentCommunity\App\Services\Libs\EmailComposer;
use FluentCommunity\App\Services\Libs\Mailer;
use FluentCommunity\Framework\Support\Arr;
use FluentCommunityPro\App\Modules\Certificates\Models\Certificate;

/**
 * Emails the holder when a certificate is issued, so they can find it again after closing the
 * congratulations dialog. Sent from Action Scheduler, not during the issuing request.
 *
 * Whether a certificate is emailed is its own meta.notify: on for course completions and for
 * manual certificates when the admin leaves "Email the certificate" on; off for backfills and
 * imports (those students finished long ago and did not ask for anything). Certificates
 * issued before the flag existed fall back to "only course completions".
 *
 * A manual certificate without an account goes to the holder email and links to the public
 * verification page.
 *
 * Site setting: certificate_issue_email in the Course Module drawer (default yes).
 */
class CertificateMailer
{
    const SEND_ACTION = 'fluent_community/certificate/send_issued_email';

    public function register()
    {
        add_action('fluent_community/certificate/issued', [ $this, 'queue' ], 10, 1);
        add_action(self::SEND_ACTION, [ $this, 'send' ], 10, 1);
    }

    /**
     * @param Certificate $certificate
     */
    public function queue($certificate)
    {
        $notify = Arr::get($certificate->meta, 'notify');
        if ($notify === null) {
            $notify = Arr::get($certificate->meta, 'source') === 'auto';
        }

        if (!self::isEnabled() || !$notify) {
            return;
        }

        as_enqueue_async_action(self::SEND_ACTION, [ (int) $certificate->id ], 'fluent-community');
    }

    public static function isEnabled()
    {
        $features = (array) Utility::getOption(CertificateOptions::FEATURES_KEY, []);

        return ($features['certificate_issue_email'] ?? 'yes') !== 'no';
    }

    /**
     * @param int $certificateId
     * @return bool sent
     */
    public function send($certificateId)
    {
        $certificate = Certificate::find($certificateId);
        if (!$certificate || $certificate->status !== Certificate::STATUS_ISSUED) {
            return false;
        }

        $user = $certificate->user_id ? User::find($certificate->user_id) : null;
        $holder = $certificate->getHolder();
        $toEmail = $certificate->isManual() ? $holder['email'] : ($user ? $user->user_email : '');
        $toName = $certificate->isManual() ? $holder['name'] : ($user ? $user->display_name : '');

        if (!$toEmail || Helper::isUndeliverableEmail($toEmail) || (!$certificate->isManual() && !$user)) {
            return false;
        }

        $values = $certificate->getData();
        $courseTitle = (string) ($values['course.title'] ?? $certificate->title);
        $certificateTitle = (string) ($values['certificate.title'] ?? $certificate->title);
        $firstName = (string) ($values['student.first_name'] ?? '');

        $subject = $certificate->isManual()
            /* translators: %s: certificate title */
            ? sprintf(__('Your certificate: %s', 'fluent-community-pro'), $certificateTitle)
            /* translators: %s: course title */
            : sprintf(__('Your certificate for %s', 'fluent-community-pro'), $courseTitle);

        $greeting = $firstName
            /* translators: %s: student's first name */
            ? sprintf(__('Congratulations, %s!', 'fluent-community-pro'), $firstName)
            : __('Congratulations!', 'fluent-community-pro');

        $composer = new EmailComposer();
        $composer->addBlock('heading', esc_html($greeting));
        $composer->addBlock('paragraph', esc_html($certificate->isManual()
            /* translators: %s: certificate title */
            ? sprintf(__('You have been awarded the certificate %s. You can download it, share it, or add it to your LinkedIn profile.', 'fluent-community-pro'), $certificateTitle)
            /* translators: %s: course title */
            : sprintf(__('You completed %s and earned a certificate. You can download it, share it, or add it to your LinkedIn profile.', 'fluent-community-pro'), $courseTitle)));
        $composer->addBlock('button', esc_html__('View your certificate', 'fluent-community-pro'), [ 'link' => self::certificateUrl($certificate, $user) ]);
        if (CertificatePresenter::holderToken($certificate)) {
            $composer->addBlock('paragraph', esc_html__('This link is only for you: it also lets you download the Open Badge. To share the certificate, use the link on that page.', 'fluent-community-pro'));
        }
        $composer->addBlock('paragraph', esc_html(sprintf(
            /* translators: %s: credential ID */
            __('Credential ID: %s', 'fluent-community-pro'),
            $certificate->slug
        )));
        $composer->setDefaultLogo();
        $composer->setDefaultFooter(false);

        /**
         * Change the certificate email before it is sent. Return an empty subject to skip it.
         *
         * @param array       $email subject, body
         * @param Certificate $certificate
         * @param User|null   $user  null for a manual certificate without an account
         */
        $email = apply_filters('fluent_community/certificate/issued_email', [
            'subject' => $subject,
            'body'    => $composer->getHtml(),
        ], $certificate, $user);

        if (empty($email['subject']) || empty($email['body'])) {
            return false;
        }

        return (bool) (new Mailer('', $email['subject'], $email['body']))
            ->to($toEmail, $toName)
            ->send();
    }

    /**
     * The Certificates tab on the student's own profile, which they can always see; the
     * verification page when they have no community profile yet, or the holder link when
     * there is no account at all.
     */
    private static function certificateUrl(Certificate $certificate, $user)
    {
        $xprofile = $user ? $user->xprofile : null;

        if ($xprofile && $xprofile->username) {
            return Helper::baseUrl('u/' . $xprofile->username . '/certificates');
        }

        return CertificatePresenter::holderUrl($certificate);
    }
}
