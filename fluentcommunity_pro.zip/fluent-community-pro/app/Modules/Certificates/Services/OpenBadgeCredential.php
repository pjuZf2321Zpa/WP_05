<?php

namespace FluentCommunityPro\App\Modules\Certificates\Services;

use FluentCommunity\App\Services\Helper;
use FluentCommunity\Framework\Support\Arr;
use FluentCommunityPro\App\Modules\Certificates\Models\Certificate;

/**
 * A certificate as an Open Badges 3.0 credential (1EdTech OB 3.0, W3C VC Data Model 2.0),
 * signed as a VC-JWT by OpenBadgeSigner. The holder downloads it baked into the
 * certificate PNG (OB 3.0 §5.3.1) and can import it into a badge wallet or Credly.
 *
 * Built on demand, never stored: the verification URL stays the credential's ID, and the
 * live status comes from a status list (W3C Bitstring Status List) that this site serves.
 *
 * Public URLs (all REST, so a private community does not hide them):
 * - issuer Profile:        certificates/open-badges/issuer
 * - public key (JWK):      certificates/open-badges/keys/{kid}
 * - status list (VC-JWT):  certificates/open-badges/status/{list}
 */
class OpenBadgeCredential
{
    const CONTEXT = [
        'https://www.w3.org/ns/credentials/v2',
        'https://purl.imsglobal.org/spec/ob/v3p0/context-3.0.3.json',
    ];

    /**
     * Bitstring Status List's minimum (and our fixed) list size: 16 KB before gzip.
     */
    const LIST_SIZE = 131072;

    const STATUS_CACHE_TTL = 600;

    public static function isAvailable()
    {
        /*
         * Turn off Open Badges downloads (the button and the endpoint). The public issuer,
         * key and status URLs keep answering, so badges already downloaded still verify.
         *
         * @param bool $enabled
         */
        return OpenBadgeSigner::isAvailable() && apply_filters('fluent_community/certificate/open_badges_enabled', true);
    }

    /**
     * @return array the unsigned OpenBadgeCredential
     */
    public static function build(Certificate $certificate)
    {
        $title = $certificate->getTitle();
        $validFrom = self::utc($certificate->created_at);

        $credential = [
            '@context'          => self::CONTEXT,
            // The verification page: a person who follows the ID sees the live status
            'id'                => CertificatePresenter::verificationUrl($certificate->slug),
            'type'              => [ 'VerifiableCredential', 'OpenBadgeCredential' ],
            'issuer'            => self::issuerProfile(false),
            'validFrom'         => $validFrom,
            'name'              => $title,
            'credentialSubject' => [
                'id'          => self::subjectId($certificate),
                'type'        => [ 'AchievementSubject' ],
                'identifier'  => self::identifiers($certificate),
                'achievement' => self::achievement($certificate, $title),
            ],
            'credentialStatus'  => self::statusEntry($certificate),
        ];

        if ($certificate->expired_at) {
            $credential['validUntil'] = self::utc($certificate->expired_at);
        }

        /*
         * Change the Open Badges credential before it is signed, for example to add alignments,
         * credits or evidence. Keep the JWT claims in sync: they are built from the result.
         *
         * @param array       $credential
         * @param Certificate $certificate
         */
        return apply_filters('fluent_community/certificate/open_badge_credential', $credential, $certificate);
    }

    /**
     * @return string|\WP_Error Compact JWS (OB 3.0 §8.2.4: the credential plus JWT claims)
     */
    public static function signed(Certificate $certificate)
    {
        return self::signDocument(self::build($certificate));
    }

    /**
     * @param bool $withContext true for the stand-alone document at the issuer URL
     */
    public static function issuerProfile($withContext = true)
    {
        $settings = Helper::generalSettings();
        $name = Arr::get($settings, 'site_title');

        $profile = [
            'id'   => self::url('issuer'),
            'type' => [ 'Profile' ],
            'name' => (string) ($name ? $name : get_bloginfo('name')),
            'url'  => Helper::baseUrl('/'),
        ];

        $logo = Arr::get($settings, 'logo');
        if ($logo) {
            $profile['image'] = [ 'id' => (string) $logo, 'type' => 'Image' ];
        }

        return $withContext ? array_merge([ '@context' => self::CONTEXT ], $profile) : $profile;
    }

    public static function keyUrl()
    {
        return self::url('keys/' . OpenBadgeSigner::keyId());
    }

    /**
     * The status list a certificate's bit lives in.
     */
    public static function listNumber(Certificate $certificate)
    {
        return intdiv((int) $certificate->id, self::LIST_SIZE);
    }

    /**
     * The signed BitstringStatusListCredential for one list, cached a few minutes and
     * dropped whenever a certificate is issued or changes status.
     *
     * @param int $listNumber
     * @return string|\WP_Error not_found past the last list a certificate can be in, so the
     *                         public URL cannot be used to sign and cache any number of lists
     */
    public static function signedStatusList($listNumber)
    {
        $listNumber = absint($listNumber);

        if ($listNumber > self::lastListNumber()) {
            return new \WP_Error('not_found', __('Unknown status list.', 'fluent-community-pro'));
        }
        $cacheKey = 'fcom_cert_ob_status_' . $listNumber;
        $cached = get_transient($cacheKey);

        if (is_string($cached) && $cached) {
            return $cached;
        }

        $listUrl = self::url('status/' . $listNumber);

        $jwt = self::signDocument([
            '@context'          => [ 'https://www.w3.org/ns/credentials/v2' ],
            'id'                => $listUrl,
            'type'              => [ 'VerifiableCredential', 'BitstringStatusListCredential' ],
            'issuer'            => self::url('issuer'),
            'validFrom'         => gmdate('Y-m-d\TH:i:s\Z'),
            'credentialSubject' => [
                'id'            => $listUrl . '#list',
                'type'          => 'BitstringStatusList',
                'statusPurpose' => 'suspension',
                // Every bit set except the certificates that are currently issued (see issuedIndexes)
                'encodedList'   => self::encodeList(self::issuedIndexes($listNumber), true),
            ],
        ]);

        if (!is_wp_error($jwt)) {
            set_transient($cacheKey, $jwt, self::STATUS_CACHE_TTL);
        }

        return $jwt;
    }

    /**
     * Drop the cached list holding this certificate: on issue, reissue and status changes.
     *
     * @param Certificate|mixed $certificate
     */
    public static function forgetStatus($certificate = null)
    {
        if ($certificate instanceof Certificate && $certificate->id) {
            delete_transient('fcom_cert_ob_status_' . self::listNumber($certificate));
        }
    }

    /**
     * A member's certificates were erased: we do not know which lists held them.
     */
    public static function forgetAllStatus()
    {
        $lastList = self::lastListNumber();

        for ($listNumber = 0; $listNumber <= $lastList; $listNumber++) {
            delete_transient('fcom_cert_ob_status_' . $listNumber);
        }
    }

    private static function lastListNumber()
    {
        return intdiv((int) Certificate::max('id'), self::LIST_SIZE);
    }

    /**
     * Bitstring Status List §3.1: the bits gzip-compressed, then multibase base64url ("u").
     * Index 0 is the left-most bit of the first byte.
     *
     * @param int[] $indexes positions to flip from the starting value
     * @param bool  $allSet  start with every bit set (and clear $indexes) instead of clear
     */
    public static function encodeList(array $indexes, $allSet = false)
    {
        $bytes = str_repeat($allSet ? "\xFF" : "\0", self::LIST_SIZE / 8);

        foreach ($indexes as $index) {
            $index = (int) $index;
            if ($index < 0 || $index >= self::LIST_SIZE) {
                continue;
            }
            $byte = intdiv($index, 8);
            $mask = 0x80 >> ($index % 8);
            $bytes[$byte] = chr($allSet ? ord($bytes[$byte]) & ~$mask & 0xFF : ord($bytes[$byte]) | $mask);
        }

        return 'u' . OpenBadgeSigner::base64Url(gzencode($bytes, 9));
    }

    /**
     * The positions in one list whose certificate is currently issued. Every other bit is
     * set, so a suspended, revoked or deleted certificate (a member erased under GDPR, say)
     * fails a wallet's status check.
     *
     * The purpose is "suspension", not "revocation": a revocation bit must never be cleared,
     * and a suspended certificate can be reinstated. Revoked ones never come back here, so
     * their bit stays set. The verification page still shows the exact status.
     *
     * @return int[]
     */
    private static function issuedIndexes($listNumber)
    {
        $first = $listNumber * self::LIST_SIZE;

        $issued = Certificate::where('status', Certificate::STATUS_ISSUED)
            ->whereBetween('id', [ $first, $first + self::LIST_SIZE - 1 ])
            ->pluck('id')
            ->all();

        return array_map(function ($id) use ($first) {
            return (int) $id - $first;
        }, $issued);
    }

    private static function statusEntry(Certificate $certificate)
    {
        $listUrl = self::url('status/' . self::listNumber($certificate));
        $index = (string) ((int) $certificate->id % self::LIST_SIZE);

        return [
            'id'                   => $listUrl . '#' . $index,
            'type'                 => 'BitstringStatusListEntry',
            'statusPurpose'        => 'suspension',
            'statusListIndex'      => $index,
            'statusListCredential' => $listUrl,
        ];
    }

    private static function achievement(Certificate $certificate, $title)
    {
        $course = $certificate->course;

        if ($certificate->isManual()) {
            return self::manualAchievement($certificate, $title, $course);
        }

        $description = $course ? trim(wp_strip_all_tags((string) $course->description)) : '';
        if ($description === '') {
            /* translators: %s: course title */
            $description = sprintf(__('Awarded for completing the course %s.', 'fluent-community-pro'), $title);
        }

        $achievement = [
            'id'              => $course ? (string) $course->getPermalink() : self::url('achievements/' . (int) $certificate->space_id),
            'type'            => [ 'Achievement' ],
            'achievementType' => 'CertificateOfCompletion',
            'name'            => $title,
            'description'     => Helper::getHumanExcerpt($description, 1000),
            'criteria'        => [
                /* translators: %s: course title */
                'narrative' => sprintf(__('Complete every lesson of %s.', 'fluent-community-pro'), $title),
            ],
        ];

        if ($course && $course->cover_photo) {
            $achievement['image'] = [ 'id' => (string) $course->cover_photo, 'type' => 'Image' ];
        }

        return $achievement;
    }

    /**
     * A manual certificate is for what the admin named it (a workshop, an event), so the
     * achievement is the template plus that name. Holders of the same certificate share it.
     */
    private static function manualAchievement(Certificate $certificate, $title, $course)
    {
        $values = $certificate->getData();

        $description = trim((string) ($values['certificate.description'] ?? ''));
        if ($description === '') {
            /* translators: %s: certificate name */
            $description = sprintf(__('Awarded for %s.', 'fluent-community-pro'), $title);
        }

        $id = $course
            ? (string) $course->getPermalink()
            : self::url('achievements/manual-' . (int) $certificate->parent_id . '-' . sanitize_title($title));

        $achievement = [
            'id'              => $id,
            'type'            => [ 'Achievement' ],
            'achievementType' => 'Certificate',
            'name'            => $title,
            'description'     => Helper::getHumanExcerpt($description, 1000),
            'criteria'        => [ 'narrative' => Helper::getHumanExcerpt($description, 1000) ],
        ];

        if ($course && $course->cover_photo) {
            $achievement['image'] = [ 'id' => (string) $course->cover_photo, 'type' => 'Image' ];
        }

        return $achievement;
    }

    /**
     * A stable URN for the holder on this site. It names no one: the email identifier below
     * is how a verifier who knows the holder's address checks that the badge is theirs.
     */
    private static function subjectId(Certificate $certificate)
    {
        // A holder without an account is known by email; with one, all their badges share the ID
        $key = $certificate->user_id ? (string) (int) $certificate->user_id : 'email|' . $certificate->getHolder()['email'];

        // 32 hex characters, keyed with the site's auth salt
        $hash = wp_hash('fcom-ob-subject|' . $key, 'auth');

        // RFC 4122 layout with the version nibble set to 8 (custom) and the RFC variant
        return 'urn:uuid:' . substr($hash, 0, 8) . '-' . substr($hash, 8, 4) . '-8' . substr($hash, 13, 3)
            . '-' . dechex(8 | (hexdec($hash[16]) & 3)) . substr($hash, 17, 3) . '-' . substr($hash, 20, 12);
    }

    /**
     * OB 3.0 §9.3: a salted SHA-256 of the holder's email, so the badge does not carry the
     * address in plain text.
     */
    private static function identifiers(Certificate $certificate)
    {
        $email = strtolower(trim($certificate->getHolder()['email']));

        if (!$email) {
            return [];
        }

        $salt = substr(wp_hash('fcom-ob-salt|' . (int) $certificate->id, 'auth'), 0, 16);

        return [
            [
                'type'         => 'IdentityObject',
                'identityHash' => 'sha256$' . hash('sha256', $email . $salt),
                'identityType' => 'emailAddress',
                'hashed'       => true,
                'salt'         => $salt,
            ],
        ];
    }

    /**
     * OB 3.0 §8.2.4.1: the JWT payload is the credential itself plus the claims that mirror
     * it (nbf = validFrom, exp = validUntil, iss = issuer.id, jti = id, sub = subject id).
     *
     * @return string|\WP_Error
     */
    private static function signDocument(array $document)
    {
        $issuer = $document['issuer'];

        $claims = [
            'iss' => is_array($issuer) ? $issuer['id'] : $issuer,
            'jti' => $document['id'],
            'sub' => $document['credentialSubject']['id'],
            'nbf' => strtotime($document['validFrom']),
        ];

        if (!empty($document['validUntil'])) {
            $claims['exp'] = strtotime($document['validUntil']);
        }

        return OpenBadgeSigner::sign(array_merge($document, $claims), self::keyUrl());
    }

    private static function url($path)
    {
        return rest_url('fluent-community/v2/certificates/open-badges/' . $path);
    }

    /**
     * Stored dates are in the site's timezone; credentials use UTC with a Z.
     */
    private static function utc($date)
    {
        return get_gmt_from_date((string) $date, 'Y-m-d\TH:i:s\Z');
    }
}
