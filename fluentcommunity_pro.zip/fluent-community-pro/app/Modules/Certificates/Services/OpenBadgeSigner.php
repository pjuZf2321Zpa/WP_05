<?php

namespace FluentCommunityPro\App\Modules\Certificates\Services;

/**
 * The site's Open Badges signing key and VC-JWT signatures (OB 3.0 §8.2): RS256, the only
 * algorithm every verifier must support, with no JSON-LD canonicalization (research.md).
 *
 * One RSA key, made the first time a badge is signed and kept in a non-autoloaded option.
 * Verifiers fetch the public half as a JWK from the URL in each signature's `kid` header
 * (§8.5); the private half never leaves this class.
 */
class OpenBadgeSigner
{
    const OPTION = 'fcom_certificate_open_badge_key';

    const KEY_BITS = 2048;

    /**
     * Signing needs PHP's openssl extension.
     */
    public static function isAvailable()
    {
        return function_exists('openssl_pkey_new') && function_exists('openssl_sign');
    }

    /**
     * @return string RFC 7638 thumbprint of the public key: the key's ID in its URL
     */
    public static function keyId()
    {
        $key = self::key();

        return $key ? $key['kid'] : '';
    }

    /**
     * @param string $kid
     * @return array|null the public JWK; never contains "d"
     */
    public static function publicJwk($kid)
    {
        $key = self::key();

        if (!$key || !hash_equals($key['kid'], (string) $kid)) {
            return null;
        }

        return array_merge($key['jwk'], [ 'kid' => $key['kid'], 'alg' => 'RS256', 'use' => 'sig' ]);
    }

    /**
     * @param string $kidUrl the URL that dereferences to publicJwk() (OB 3.0 §8.2.3)
     * @return string|\WP_Error Compact JWS
     */
    public static function sign(array $payload, $kidUrl)
    {
        $key = self::key();

        if (!$key) {
            return new \WP_Error('open_badge_key', __('This site cannot sign Open Badges: PHP\'s OpenSSL extension is missing or failed.', 'fluent-community-pro'));
        }

        // Exactly these headers: OB 3.0 §8.2.3 does not allow others
        $input = self::encodeJson([ 'alg' => 'RS256', 'kid' => $kidUrl, 'typ' => 'JWT' ]) . '.' . self::encodeJson($payload);

        $signature = '';
        if (!openssl_sign($input, $signature, $key['private'], OPENSSL_ALGO_SHA256)) {
            return new \WP_Error('open_badge_sign', __('The Open Badge could not be signed.', 'fluent-community-pro'));
        }

        return $input . '.' . self::base64Url($signature);
    }

    public static function base64Url($bytes)
    {
        return rtrim(strtr(base64_encode($bytes), '+/', '-_'), '='); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
    }

    private static function encodeJson(array $data)
    {
        return self::base64Url((string) wp_json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
    }

    /**
     * @return array|null ['kid' => string, 'jwk' => ['kty','n','e'], 'private' => string PEM]
     */
    private static function key()
    {
        static $key = null;

        if ($key !== null) {
            return $key ? $key : null;
        }

        $stored = get_option(self::OPTION);

        if (is_array($stored) && !empty($stored['private']) && !empty($stored['kid']) && !empty($stored['jwk'])) {
            $key = $stored;
            return $key;
        }

        $key = self::isAvailable() ? self::generate() : false;

        if ($key) {
            // add_option, not update_option: when two requests race to make the first key,
            // the second one keeps the first one's key instead of replacing it
            if (!add_option(self::OPTION, $key, '', false)) {
                $stored = get_option(self::OPTION);
                $key = is_array($stored) && !empty($stored['private']) ? $stored : $key;
            }
        }

        return $key ? $key : null;
    }

    /**
     * @return array|false
     */
    private static function generate()
    {
        $resource = openssl_pkey_new([
            'private_key_bits' => self::KEY_BITS,
            'private_key_type' => OPENSSL_KEYTYPE_RSA,
            'digest_alg'       => 'sha256',
        ]);

        if (!$resource) {
            return false;
        }

        $private = '';
        $details = openssl_pkey_get_details($resource);

        if (!openssl_pkey_export($resource, $private) || empty($details['rsa']['n']) || empty($details['rsa']['e'])) {
            return false;
        }

        $jwk = [
            'kty' => 'RSA',
            'n'   => self::base64Url($details['rsa']['n']),
            'e'   => self::base64Url($details['rsa']['e']),
        ];

        // RFC 7638: the required members in lexicographic order, no whitespace
        $thumbprint = self::base64Url(hash('sha256', '{"e":"' . $jwk['e'] . '","kty":"RSA","n":"' . $jwk['n'] . '"}', true));

        return [
            'kid'        => $thumbprint,
            'jwk'        => $jwk,
            'private'    => $private,
            'created_at' => gmdate('Y-m-d H:i:s'),
        ];
    }
}
