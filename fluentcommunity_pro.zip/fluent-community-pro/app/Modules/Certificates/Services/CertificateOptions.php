<?php

namespace FluentCommunityPro\App\Modules\Certificates\Services;

use FluentCommunity\App\Functions\Utility;

/**
 * Site-wide certificate settings. They are stored with core's feature flags (option
 * `fluent_community_features`) and edited in Features & Addons -> Course Module, next to
 * the "Enable Course Certificates" switch. Per-course settings live in CertificateSettings.
 *
 * certificate_profile_visibility: who else sees the Certificates tab on a member's profile.
 *  - own:       only the member (the default: certificates show names and courses)
 *  - logged_in: any logged-in member who may view the profile
 *  - everyone:  anyone who may view the profile
 * Others only ever see public certificates, and core's profile visibility applies on top.
 * The verification page is not affected: whoever has a certificate's link or QR code can
 * check it, and a private one only answers whether it is valid.
 */
class CertificateOptions
{
    const FEATURES_KEY = 'fluent_community_features';

    const PROFILE_VISIBILITY = [ 'own', 'logged_in', 'everyone' ];

    /**
     * Read from the option itself, not Utility::getFeaturesConfig(), whose static copy does
     * not see a save made later in the same request.
     *
     * @return array profile_visibility
     */
    public static function get()
    {
        $features = (array) Utility::getOption(self::FEATURES_KEY, []);
        $visibility = (string) ($features['certificate_profile_visibility'] ?? 'own');

        return [
            'profile_visibility' => in_array($visibility, self::PROFILE_VISIBILITY, true) ? $visibility : 'own',
        ];
    }

    /**
     * For code and tests; admins change it on the Features & Addons screen.
     *
     * @param string $visibility own|logged_in|everyone; anything else is stored as own
     */
    public static function saveProfileVisibility($visibility)
    {
        $features = (array) Utility::getOption(self::FEATURES_KEY, []);
        $features['certificate_profile_visibility'] = in_array($visibility, self::PROFILE_VISIBILITY, true) ? $visibility : 'own';

        Utility::updateOption(self::FEATURES_KEY, $features);
    }

    /**
     * May the current visitor see this member's certificates on their profile? The caller
     * still applies core's profile rules (Utility::canViewUserProfile).
     *
     * @param int $ownerId
     * @return bool
     */
    public static function canSeeProfileCertificates($ownerId)
    {
        $currentUserId = get_current_user_id();

        if ($currentUserId && $currentUserId === (int) $ownerId) {
            return true;
        }

        switch (self::get()['profile_visibility']) {
            case 'everyone':
                $allowed = true;
                break;
            case 'logged_in':
                $allowed = (bool) $currentUserId;
                break;
            default:
                $allowed = false;
        }

        /**
         * Last word on whether a visitor sees a member's certificates on their profile.
         *
         * @param bool $allowed
         * @param int  $ownerId
         * @param int  $currentUserId
         */
        return (bool) apply_filters('fluent_community/certificate/can_see_profile_certificates', $allowed, (int) $ownerId, $currentUserId);
    }
}
