<?php

namespace FluentCommunityPro\App\Modules\Certificates\Services;

use FluentCommunity\App\Models\User;
use FluentCommunity\App\Services\Helper;
use FluentCommunity\App\Services\ProfileHelper;
use FluentCommunity\Framework\Support\Arr;
use FluentCommunity\Modules\Course\Model\Course;
use FluentCommunityPro\App\Modules\Certificates\Models\Certificate;
use FluentCommunityPro\App\Modules\Certificates\Models\CertificateTemplate;
use FluentCommunityPro\App\Services\NamedLock;

/**
 * Manual certificates: an admin issues one to any person, with or without an account and
 * with or without a course (a physical workshop, say), on any published template, with the
 * values typed in. Design: fluent-community docs/certificates/manual-certificates.md.
 *
 * Same row type as course certificates (so verification, QR, downloads, Open Badges and
 * status changes all work), kept apart by content_type = manual_certificate. No uniqueness:
 * one person can hold any number. The course rules (the can_issue filter, one per course)
 * do not apply; the admin's decision is final.
 */
class ManualCertificates
{
    /**
     * Set by the system on every certificate, never typed.
     */
    const SYSTEM_TAGS = [
        'certificate.issue_date',
        'certificate.expiry_date',
        'certificate.credential_id',
        'certificate.serial',
    ];

    const MAX_VALUE_LENGTH = 500;

    /**
     * @param array $input name, email, template_id, course_id?, values (tag => text),
     *                     account none|link|create, user_id (link; without it, the account
     *                     with this email if any), privacy public|private,
     *                     expires_at (Y-m-d)?, issued_at (Y-m-d H:i:s)?, notify (bool),
     *                     account_email (bool: send the new account its password email)
     * @param int   $byUserId the admin
     * @return Certificate|\WP_Error
     */
    public static function issue(array $input, $byUserId)
    {
        $holder = self::holder($input);
        if (is_wp_error($holder)) {
            return $holder;
        }
        list($name, $email) = $holder;

        $template = CertificateTemplate::find(absint(Arr::get($input, 'template_id')));
        if (!$template || !$template->isPublished()) {
            return new \WP_Error('no_template', __('Choose a published certificate template.', 'fluent-community-pro'));
        }

        $course = null;
        $courseId = absint(Arr::get($input, 'course_id'));
        if ($courseId) {
            $course = Course::find($courseId);
            if (!$course) {
                return new \WP_Error('invalid_course', __('The course could not be found.', 'fluent-community-pro'));
            }
        }

        $issuedAt = self::dateTime(Arr::get($input, 'issued_at'), current_time('mysql'));
        if (strtotime($issuedAt) > strtotime(current_time('Y-m-d') . ' 23:59:59')) {
            return new \WP_Error('invalid_issue_date', __('The issue date cannot be in the future.', 'fluent-community-pro'));
        }

        $expiresAt = null;
        if (!empty($input['expires_at'])) {
            $expiresAt = self::expiry($input['expires_at'], $issuedAt);
            if (is_wp_error($expiresAt)) {
                return $expiresAt;
            }
        }

        // A new account is created only after the filter below, so a blocked row makes none
        $userId = self::resolveAccount($input, $name, $email, false);
        if (is_wp_error($userId)) {
            return $userId;
        }

        $data = [
            'name'       => $name,
            'email'      => $email,
            'user_id'    => $userId,
            'template'   => $template,
            'course'     => $course,
            'values'     => self::cleanValues((array) Arr::get($input, 'values', [])),
            'privacy'    => Arr::get($input, 'privacy') === 'private' ? 'private' : 'public',
            'issued_at'  => $issuedAt,
            'expires_at' => $expiresAt,
            'notify'     => !empty($input['notify']),
        ];

        /**
         * Change or block a manual certificate before it is created.
         *
         * @param array|\WP_Error $data  name, email, user_id, template, course, values, privacy,
         *                               issued_at, expires_at, notify. user_id is 0 when the
         *                               account is still to be created (account = create).
         * @param array           $input the request
         */
        $data = apply_filters('fluent_community/certificate/before_manual_issue', $data, $input);
        if (is_wp_error($data)) {
            return $data;
        }

        if (!$data['user_id'] && Arr::get($input, 'account') === 'create') {
            $userId = self::resolveAccount($input, $data['name'], $data['email']);
            if (is_wp_error($userId)) {
                return $userId;
            }
            $data['user_id'] = $userId;
        }

        $certificate = NamedLock::run(CertificateIssuer::LOCK_NAME, function () use ($data, $byUserId) {
            // Again inside the lock: deleteTemplate() deletes under this same lock
            $template = CertificateTemplate::find($data['template']->id);
            if (!$template || !$template->isPublished()) {
                return new \WP_Error('no_template', __('Choose a published certificate template.', 'fluent-community-pro'));
            }

            $credentialId = CertificateIssuer::newCredentialId();
            $serial = CertificateIssuer::nextSerial();

            $values = array_merge(
                self::defaultValues($template, $data['course'], $data['name'], $data['issued_at'], $data['user_id']),
                $data['values'],
                [
                    'certificate.issue_date'    => MergeValues::formatDate($data['issued_at']),
                    'certificate.expiry_date'   => $data['expires_at'] ? MergeValues::formatDate($data['expires_at']) : '',
                    'certificate.credential_id' => $credentialId,
                    'certificate.serial'        => MergeValues::serial($data['issued_at'], $serial),
                ]
            );

            $title = self::resolveTitle($values, (string) $template->title);
            $values['certificate.title'] = $title;

            return Certificate::create([
                'user_id'      => $data['user_id'] ? $data['user_id'] : null,
                'space_id'     => $data['course'] ? $data['course']->id : null,
                'parent_id'    => $template->id,
                'slug'         => $credentialId,
                'title'        => mb_substr($title, 0, 192),
                'priority'     => $serial,
                'privacy'      => $data['privacy'],
                'content_type' => Certificate::KIND_MANUAL,
                'expired_at'   => $data['expires_at'],
                'created_at'   => $data['issued_at'],
                'meta'         => [
                    'template_version'  => $template->getCurrentVersion(),
                    'data'              => array_map('strval', $values),
                    'source'            => 'manual',
                    'issued_by'         => (int) $byUserId,
                    'notify'            => $data['notify'],
                    'holder'            => [ 'name' => $data['name'], 'email' => $data['email'] ],
                    // A lookup key of its own, so a LIKE on the serialized meta can match it
                    // exactly (findByHolderEmail)
                    'holder_email'      => $data['email'],
                    'status_list_index' => null,
                ],
            ]);
        });

        if (is_wp_error($certificate)) {
            return $certificate;
        }

        do_action('fluent_community/certificate/issued', $certificate, $data['course'], (int) $data['user_id']);

        return $certificate;
    }

    /**
     * Edit a manual certificate. The credential ID, the serial and the issue date stay, because
     * the QR code and shared links may already be out. Each change is logged in meta.history.
     *
     * @param array $changes name, email, account none|link|create, user_id, account_email,
     *                       values (tag => text, the full set the form shows), privacy,
     *                       expires_at (Y-m-d or ''), latest_version (bool)
     * @return Certificate|\WP_Error
     */
    public static function update(Certificate $certificate, array $changes, $byUserId)
    {
        if (!$certificate->isManual()) {
            return new \WP_Error('not_manual', __('Only manual certificates can be edited.', 'fluent-community-pro'));
        }

        if ($certificate->status === Certificate::STATUS_REVOKED) {
            return new \WP_Error('invalid_status', __('A revoked certificate cannot be edited.', 'fluent-community-pro'));
        }

        $holder = self::holder($changes);
        if (is_wp_error($holder)) {
            return $holder;
        }
        list($name, $email) = $holder;

        $expiresAt = null;
        if (!empty($changes['expires_at'])) {
            $expiresAt = self::expiry($changes['expires_at'], (string) $certificate->created_at);
            if (is_wp_error($expiresAt)) {
                return $expiresAt;
            }
        }

        $userId = self::resolveAccount($changes, $name, $email);
        if (is_wp_error($userId)) {
            return $userId;
        }

        $meta = $certificate->meta;
        $before = [
            'data'             => (array) Arr::get($meta, 'data', []),
            'holder'           => $certificate->getHolder(),
            'user_id'          => (int) $certificate->user_id,
            'privacy'          => $certificate->privacy,
            'expired_at'       => $certificate->expired_at ? (string) $certificate->expired_at : null,
            'template_version' => (int) Arr::get($meta, 'template_version'),
        ];

        $version = $before['template_version'];
        if (!empty($changes['latest_version'])) {
            $template = $certificate->template;
            if (!$template || !$template->isPublished()) {
                return new \WP_Error('no_template', __('The certificate template is no longer published.', 'fluent-community-pro'));
            }
            $version = $template->getCurrentVersion();
        }

        // The form sends every field; an empty one that was never stored is no change
        $typedValues = array_filter(self::cleanValues((array) Arr::get($changes, 'values', [])), function ($value, $tag) use ($before) {
            return $value !== '' || array_key_exists($tag, $before['data']);
        }, ARRAY_FILTER_USE_BOTH);
        $values = array_merge($before['data'], $typedValues);

        // The printed name follows the holder, unless the admin typed it
        if ($name !== $before['holder']['name']) {
            $parts = preg_split('/\s+/', $name, 2);
            $typed = (array) Arr::get($changes, 'values', []);
            $values = array_merge($values, array_diff_key([
                'student.full_name'  => $name,
                'student.first_name' => (string) ($parts[0] ?? ''),
                'student.last_name'  => (string) ($parts[1] ?? ''),
            ], $typed));
        }

        $values['certificate.expiry_date'] = $expiresAt ? MergeValues::formatDate($expiresAt) : '';
        $values['certificate.title'] = self::resolveTitle($values, (string) $certificate->title);
        $values = array_map('strval', $values);

        $changed = [];
        if ($name !== $before['holder']['name']) {
            $changed[] = 'name';
        }
        if ($email !== $before['holder']['email']) {
            $changed[] = 'email';
        }
        if ((int) $userId !== $before['user_id']) {
            $changed[] = 'account';
        }
        $privacy = Arr::get($changes, 'privacy') === 'private' ? 'private' : 'public';
        if ($privacy !== $before['privacy']) {
            $changed[] = 'privacy';
        }
        if ($expiresAt !== $before['expired_at']) {
            $changed[] = 'expiry';
        }
        if ($version !== $before['template_version']) {
            $changed[] = 'template_version';
        }
        if (array_diff_assoc($values, $before['data']) || array_diff_assoc($before['data'], $values)) {
            $changed[] = 'values';
        }

        if (!$changed) {
            return $certificate;
        }

        $history = (array) Arr::get($meta, 'history', []);
        $history[] = [ 'by' => (int) $byUserId, 'at' => current_time('mysql'), 'changed' => $changed ];

        $meta['data'] = $values;
        $meta['holder'] = [ 'name' => $name, 'email' => $email ];
        $meta['holder_email'] = $email;
        $meta['template_version'] = $version;
        // The newest 50 are plenty to answer "who changed this"
        $meta['history'] = array_slice($history, -50);

        $certificate->user_id = $userId ? $userId : null;
        $certificate->privacy = $privacy;
        $certificate->expired_at = $expiresAt;
        $certificate->title = mb_substr($values['certificate.title'], 0, 192);
        $certificate->meta = $meta;
        $certificate->save();

        /**
         * A manual certificate was edited.
         *
         * @param Certificate $certificate
         * @param string[]    $changed name, email, account, privacy, expiry, template_version, values
         * @param int         $byUserId
         */
        do_action('fluent_community/certificate/manual_updated', $certificate, $changed, (int) $byUserId);

        return $certificate;
    }

    /**
     * The issue form for a template: one field per merge tag its visible text prints, in
     * the order they appear, with the value the certificate would get if nothing is typed.
     *
     * @param CertificateTemplate $template
     * @param Course|null         $course
     * @param int|null            $version a published version; the current one by default
     * @param array|null          $values  stored values (editing) instead of the defaults
     * @return array[] tag, value, readonly (set by the system), custom ({{custom.*}})
     */
    public static function fieldsFor(CertificateTemplate $template, $course = null, $holderName = '', $version = null, $values = null)
    {
        // Editing: the certificate's own values; issuing: the defaults
        $defaults = $values !== null ? $values : self::defaultValues($template, $course, $holderName, current_time('mysql'));

        // The title names the certificate on the verification page, the profile and LinkedIn,
        // so it is asked for even when the design does not print it
        $tags = self::printedTags($template, $version);
        if (!in_array('certificate.title', $tags, true)) {
            array_unshift($tags, 'certificate.title');
        }

        return array_map(function ($tag) use ($defaults) {
            return [
                'tag'      => $tag,
                'value'    => in_array($tag, self::SYSTEM_TAGS, true) ? '' : (string) ($defaults[$tag] ?? ''),
                'readonly' => in_array($tag, self::SYSTEM_TAGS, true),
                'custom'   => strpos($tag, 'custom.') === 0,
            ];
        }, $tags);
    }

    /**
     * The certificate's name: the typed title, else the typed course title, else $fallback.
     * Never the template's name by default: that is an admin's working label.
     */
    private static function resolveTitle(array $values, $fallback)
    {
        foreach ([ 'certificate.title', 'course.title' ] as $tag) {
            $title = trim((string) ($values[$tag] ?? ''));
            if ($title !== '') {
                return $title;
            }
        }

        return (string) $fallback;
    }

    /**
     * Merge tags in the template's published, visible text elements.
     *
     * @return string[]
     */
    public static function printedTags(CertificateTemplate $template, $version = null)
    {
        $design = $template->getVersionDesign($version ? $version : $template->getCurrentVersion());
        $tags = [];

        foreach ((array) Arr::get($design, 'elements', []) as $element) {
            if (($element['type'] ?? '') !== 'text' || !empty($element['hidden'])) {
                continue;
            }
            if (preg_match_all('/\{\{\s*([a-z_]+\.[a-z_]+)\s*\}\}/', (string) ($element['content'] ?? ''), $matches)) {
                foreach ($matches[1] as $tag) {
                    if (self::isKnownTag($tag)) {
                        $tags[$tag] = true;
                    }
                }
            }
        }

        return array_keys($tags);
    }

    /**
     * What a field holds before the admin types anything: the holder's name, and the course's
     * details (its title also as the certificate title) when one is chosen.
     */
    private static function defaultValues(CertificateTemplate $template, $course, $name, $issuedAt, $userId = 0)
    {
        $parts = preg_split('/\s+/', trim((string) $name), 2);
        $siteName = Arr::get(Helper::generalSettings(), 'site_title');
        $date = MergeValues::formatDate($issuedAt);

        // A linked member who finished the course keeps their real completion date
        $completedAt = $course && $userId ? MergeValues::completedAt($course->id, $userId) : null;

        return [
            'student.full_name'       => (string) $name,
            'student.first_name'      => (string) ($parts[0] ?? ''),
            'student.last_name'       => (string) ($parts[1] ?? ''),
            'course.title'            => $course ? (string) $course->title : '',
            'course.instructor'       => $course && $course->created_by ? MergeValues::personName($course->created_by)['full'] : '',
            'course.lesson_count'     => $course ? MergeValues::lessonCount($course) : '',
            'course.completion_date'  => $completedAt ? MergeValues::formatDate($completedAt) : $date,
            'certificate.title'       => $course ? (string) $course->title : '',
            'certificate.description' => '',
            'certificate.date'        => $date,
            'site.name'               => (string) ($siteName ? $siteName : get_bloginfo('name')),
        ];
    }

    /**
     * Typed values: known tags only, plain text (line breaks kept), system tags dropped.
     */
    private static function cleanValues(array $values)
    {
        $clean = [];

        foreach ($values as $tag => $value) {
            $tag = (string) $tag;
            if (!self::isKnownTag($tag) || in_array($tag, self::SYSTEM_TAGS, true) || !is_scalar($value)) {
                continue;
            }

            $value = wp_strip_all_tags((string) $value);
            $value = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $value);
            $clean[$tag] = mb_substr(trim($value), 0, self::MAX_VALUE_LENGTH);
        }

        return $clean;
    }

    private static function isKnownTag($tag)
    {
        return in_array($tag, TemplateDesign::MERGE_TAGS, true) || preg_match(TemplateDesign::CUSTOM_TAG_PATTERN, $tag);
    }

    /**
     * @return int|\WP_Error 0 for no account
     */
    /**
     * @param bool $create false: for "create", only find an existing account (0 when none)
     * @return int|\WP_Error the user ID, 0 for no account
     */
    private static function resolveAccount(array $input, $name, $email, $create = true)
    {
        $account = Arr::get($input, 'account', 'none');

        if ($account === 'link') {
            $userId = absint(Arr::get($input, 'user_id'));
            if (!$userId) {
                // No account chosen (a CSV row): the one with this email, if there is one
                $existing = get_user_by('email', $email);
                return $existing ? (int) $existing->ID : 0;
            }
            $user = get_user_by('ID', $userId);
            return $user ? (int) $user->ID : new \WP_Error('invalid_user', __('The account to link could not be found.', 'fluent-community-pro'));
        }

        if ($account !== 'create') {
            return 0;
        }

        // The email already has an account: link it rather than fail or duplicate
        $existing = get_user_by('email', $email);
        if ($existing) {
            return (int) $existing->ID;
        }

        if (!$create) {
            return 0;
        }

        $userId = ProfileHelper::createWpUser([ 'email' => $email, 'full_name' => $name ]);
        if (is_wp_error($userId)) {
            return $userId;
        }

        $user = User::find($userId);
        if ($user) {
            $user->syncXProfile();
        }

        if (!empty($input['account_email'])) {
            wp_new_user_notification($userId, null, 'user');
        }

        return (int) $userId;
    }

    /**
     * @return array|\WP_Error [name, email], the email lower-cased
     */
    private static function holder(array $input)
    {
        $name = trim(sanitize_text_field((string) Arr::get($input, 'name', '')));
        $email = strtolower(trim(sanitize_email((string) Arr::get($input, 'email', ''))));

        if ($name === '' || mb_strlen($name) > 100) {
            return new \WP_Error('invalid_name', __('Enter the person\'s name (at most 100 characters).', 'fluent-community-pro'));
        }

        if (!is_email($email)) {
            return new \WP_Error('invalid_email', __('Enter a valid email address.', 'fluent-community-pro'));
        }

        return [ $name, $email ];
    }

    /**
     * @return string|\WP_Error the end of that day, after the issue date
     */
    private static function expiry($date, $issuedAt)
    {
        $expiresAt = self::dateTime($date . ' 23:59:59', null);

        if (!$expiresAt || strtotime($expiresAt) <= strtotime($issuedAt)) {
            return new \WP_Error('invalid_expiry', __('The expiry date must be after the issue date.', 'fluent-community-pro'));
        }

        return $expiresAt;
    }

    /**
     * @return string|null Y-m-d H:i:s
     */
    private static function dateTime($value, $fallback)
    {
        $time = $value ? strtotime((string) $value) : false;

        return $time ? gmdate('Y-m-d H:i:s', $time) : $fallback;
    }
}
