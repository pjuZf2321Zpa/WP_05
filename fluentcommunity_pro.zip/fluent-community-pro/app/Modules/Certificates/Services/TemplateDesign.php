<?php

namespace FluentCommunityPro\App\Modules\Certificates\Services;

/**
 * The template design document (schema 1): a fixed page and a list of positioned elements.
 * Positions and sizes are in points (pt) relative to the page.
 *
 * sanitize() is the only way a design reaches the database. It keeps known element types and
 * keys, clamps numbers, drops markup from text and stores images as attachment IDs, so the
 * renderer never sees HTML or a URL it did not resolve itself.
 */
class TemplateDesign
{
    const SCHEMA = 1;

    const MAX_ELEMENTS = 100;

    const PAGE_SIZES = [
        'A4'     => [ 842, 595 ],
        'Letter' => [ 792, 612 ],
    ];

    /**
     * Merge tags a text element may use. Values are resolved once, at issue time (MergeValues).
     */
    const MERGE_TAGS = [
        'student.full_name',
        'student.first_name',
        'student.last_name',
        'course.title',
        'course.instructor',
        'course.lesson_count',
        'course.completion_date',
        'certificate.issue_date',
        'certificate.expiry_date',
        'certificate.credential_id',
        'certificate.serial',
        'certificate.title',
        'certificate.description',
        'certificate.date',
        'site.name',
    ];

    /**
     * {{custom.<key>}}: a field the designer names. A manual certificate's issue form shows one
     * input per custom tag its template prints (ManualCertificates::fieldsFor).
     */
    const CUSTOM_TAG_PATTERN = '/^custom\.[a-z_]{1,40}$/';

    public static function blank()
    {
        return [
            'schema'     => self::SCHEMA,
            'page'       => [ 'size' => 'A4', 'orientation' => 'landscape', 'width' => 842, 'height' => 595 ],
            'background' => [ 'color' => '#ffffff', 'image_id' => 0, 'fit' => 'cover' ],
            'elements'   => [],
        ];
    }

    /**
     * @param mixed $design decoded JSON from the editor
     * @return array|\WP_Error
     */
    public static function sanitize($design)
    {
        if (!is_array($design)) {
            return new \WP_Error('invalid_design', __('The certificate design is not valid.', 'fluent-community-pro'));
        }

        $page = self::sanitizePage((array) ($design['page'] ?? []));

        $background = (array) ($design['background'] ?? []);
        $clean = [
            'schema'     => self::SCHEMA,
            'page'       => $page,
            'background' => [
                'color'    => self::color($background['color'] ?? '#ffffff', '#ffffff'),
                'image_id' => absint($background['image_id'] ?? 0),
                'fit'      => self::oneOf($background['fit'] ?? 'cover', [ 'cover', 'contain', 'stretch' ], 'cover'),
            ],
            'elements'   => [],
        ];

        $elements = (array) ($design['elements'] ?? []);

        if (count($elements) > self::MAX_ELEMENTS) {
            /* translators: %d: maximum number of elements */
            return new \WP_Error('too_many_elements', sprintf(__('A certificate can have at most %d elements.', 'fluent-community-pro'), self::MAX_ELEMENTS));
        }

        $ids = [];
        foreach ($elements as $element) {
            $element = self::sanitizeElement((array) $element, $page);

            if (is_wp_error($element)) {
                return $element;
            }

            if (isset($ids[$element['id']])) {
                return new \WP_Error('duplicate_element', __('Two elements have the same ID.', 'fluent-community-pro'));
            }

            $ids[$element['id']] = true;
            $clean['elements'][] = $element;
        }

        return $clean;
    }

    private static function sanitizePage(array $page)
    {
        $size = self::oneOf($page['size'] ?? 'A4', [ 'A4', 'Letter', 'custom' ], 'A4');
        $orientation = self::oneOf($page['orientation'] ?? 'landscape', [ 'landscape', 'portrait' ], 'landscape');

        if ($size === 'custom') {
            $width = self::number($page['width'] ?? 842, 144, 2000);
            $height = self::number($page['height'] ?? 595, 144, 2000);
        } else {
            list($long, $short) = self::PAGE_SIZES[$size];
            $width = $orientation === 'landscape' ? $long : $short;
            $height = $orientation === 'landscape' ? $short : $long;
        }

        return [ 'size' => $size, 'orientation' => $orientation, 'width' => $width, 'height' => $height ];
    }

    /**
     * @return array|\WP_Error
     */
    private static function sanitizeElement(array $element, array $page)
    {
        $type = $element['type'] ?? '';
        $id = (string) ($element['id'] ?? '');

        if (!preg_match('/^[A-Za-z0-9_-]{1,32}$/', $id)) {
            return new \WP_Error('invalid_element', __('An element has an invalid ID.', 'fluent-community-pro'));
        }

        $maxX = $page['width'] * 2;
        $maxY = $page['height'] * 2;

        $clean = [
            'id'     => $id,
            'type'   => $type,
            'x'      => self::number($element['x'] ?? 0, -$page['width'], $maxX),
            'y'      => self::number($element['y'] ?? 0, -$page['height'], $maxY),
            'w'      => self::number($element['w'] ?? 100, 1, $maxX),
            'h'      => self::number($element['h'] ?? 20, 1, $maxY),
            'rotate' => self::number($element['rotate'] ?? 0, -360, 360),
            'locked' => !empty($element['locked']),
            'hidden' => !empty($element['hidden']),
        ];

        switch ($type) {
            case 'text':
                $clean['content'] = self::text($element['content'] ?? '', 500);
                $clean['autofit'] = !empty($element['autofit']);
                $clean['style'] = self::textStyle((array) ($element['style'] ?? []));
                break;

            case 'image':
                $clean['image_id'] = absint($element['image_id'] ?? 0);
                $clean['opacity'] = self::number($element['opacity'] ?? 1, 0, 1);
                break;

            case 'signature':
                $clean['image_id'] = absint($element['image_id'] ?? 0);
                $clean['name'] = self::text($element['name'] ?? '', 100);
                $clean['title'] = self::text($element['title'] ?? '', 100);
                $clean['style'] = self::textStyle((array) ($element['style'] ?? []));
                break;

            case 'qr':
                $clean['color'] = self::color($element['color'] ?? '#111111', '#111111');
                $clean['background'] = self::color($element['background'] ?? 'transparent', 'transparent');
                break;

            case 'rect':
                $clean['fill'] = self::color($element['fill'] ?? 'transparent', 'transparent');
                $clean['stroke'] = self::color($element['stroke'] ?? '#111111', '#111111');
                $clean['stroke_width'] = self::number($element['stroke_width'] ?? 1, 0, 50);
                $clean['radius'] = self::number($element['radius'] ?? 0, 0, 500);
                break;

            case 'line':
                $clean['stroke'] = self::color($element['stroke'] ?? '#111111', '#111111');
                $clean['stroke_width'] = self::number($element['stroke_width'] ?? 1, 0, 50);
                break;

            default:
                return new \WP_Error('invalid_element', __('The design has an unknown element type.', 'fluent-community-pro'));
        }

        return $clean;
    }

    private static function textStyle(array $style)
    {
        $font = (string) ($style['font'] ?? 'inter');

        return [
            'font'           => preg_match('/^[a-z0-9-]{1,40}$/', $font) ? $font : 'inter',
            'size'           => self::number($style['size'] ?? 16, 4, 200),
            'weight'         => (int) self::oneOf((string) ($style['weight'] ?? '400'), [ '100', '200', '300', '400', '500', '600', '700', '800', '900' ], '400'),
            'italic'         => !empty($style['italic']),
            'color'          => self::color($style['color'] ?? '#1d2939', '#1d2939'),
            'align'          => self::oneOf($style['align'] ?? 'center', [ 'start', 'center', 'end' ], 'center'),
            'line_height'    => self::number($style['line_height'] ?? 1.2, 0.5, 3),
            'letter_spacing' => self::number($style['letter_spacing'] ?? 0, -10, 50),
            'transform'      => self::oneOf($style['transform'] ?? 'none', [ 'none', 'uppercase', 'lowercase', 'capitalize' ], 'none'),
            // auto: each line by its first letter (the renderer); rtl/ltr when a line starts
            // with a merge value in another script, e.g. a Latin name in a Hebrew sentence
            'direction'      => self::oneOf($style['direction'] ?? 'auto', [ 'auto', 'rtl', 'ltr' ], 'auto'),
        ];
    }

    /**
     * Plain text only: no markup, no control characters. Merge tags ({{...}}) are kept as typed.
     */
    private static function text($value, $max)
    {
        $value = wp_strip_all_tags((string) $value);
        $value = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $value);

        return mb_substr($value, 0, $max);
    }

    private static function color($value, $fallback)
    {
        $value = trim((string) $value);

        if ($value === 'transparent' || preg_match('/^#([0-9a-fA-F]{3,4}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/', $value)) {
            return $value;
        }

        if (preg_match('/^rgba?\(\s*\d{1,3}\s*,\s*\d{1,3}\s*,\s*\d{1,3}\s*(,\s*(0|1|0?\.\d+)\s*)?\)$/', $value)) {
            return $value;
        }

        return $fallback;
    }

    private static function number($value, $min, $max)
    {
        $value = is_numeric($value) ? (float) $value : (float) $min;

        return round(max($min, min($max, $value)), 2);
    }

    private static function oneOf($value, array $allowed, $fallback)
    {
        return in_array($value, $allowed, true) ? $value : $fallback;
    }
}
