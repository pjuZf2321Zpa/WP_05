<?php

namespace FluentCommunityPro\App\Modules\Certificates\Services;

use FluentCommunity\App\Services\Helper;
use FluentCommunity\Framework\Support\Arr;
use FluentCommunityPro\App\Modules\Certificates\Models\Certificate;
use FluentCommunityPro\App\Modules\Certificates\Models\CertificateTemplate;

/**
 * Shapes certificates for each audience. The verification output is public, so it carries
 * only what the certificate itself prints: no email, no user ID, no internal IDs.
 */
class CertificatePresenter
{
    public static function verificationUrl($credentialId)
    {
        return Helper::baseUrl('certificates/' . $credentialId);
    }

    /**
     * What the browser renderer needs: the design as published (images resolved to URLs)
     * and the merge values stored at issue time.
     *
     * @return array|null null when the template version no longer exists
     */
    public static function renderPayload(Certificate $certificate, $forPublic = false)
    {
        $design = self::versionDesign((int) $certificate->parent_id, (int) Arr::get($certificate->meta, 'template_version'));

        if (!$design) {
            return null;
        }

        $values = $certificate->getData();

        if ($forPublic) {
            list($design, $values) = self::onlyWhatPrints($design, $values);
        }

        return [
            'design'   => $design,
            'values'   => $values,
            'qr_value' => self::verificationUrl($certificate->slug),
        ];
    }

    /**
     * For anyone but the holder: the visible elements, and only the merge values those print.
     * The stored values include more (the instructor's name, the completion date) than a given
     * template shows.
     *
     * @return array [design, values]
     */
    private static function onlyWhatPrints(array $design, array $values)
    {
        $design['elements'] = array_values(array_filter($design['elements'], function ($element) {
            return empty($element['hidden']);
        }));

        $used = [];
        foreach ($design['elements'] as $element) {
            if (($element['type'] ?? '') === 'text' && preg_match_all('/\{\{\s*([a-z_]+\.[a-z_]+)\s*\}\}/', (string) ($element['content'] ?? ''), $matches)) {
                $used = array_merge($used, $matches[1]);
            }
        }

        return [ $design, array_intersect_key($values, array_flip($used)) ];
    }

    /**
     * A published version never changes, so one lookup per (template, version) per request.
     *
     * @return array|null the design with images resolved
     */
    private static function versionDesign($templateId, $version)
    {
        static $cache = [];

        $key = $templateId . ':' . $version;

        if (!array_key_exists($key, $cache)) {
            $template = $templateId ? CertificateTemplate::find($templateId) : null;
            $design = $template ? $template->getVersionDesign($version) : null;
            $cache[$key] = $design ? self::resolveImages($design) : null;
        }

        return $cache[$key];
    }

    /**
     * Attachment IDs become URLs here, server side, so a design never stores a URL.
     */
    public static function resolveImages(array $design)
    {
        $url = function ($id) {
            $id = absint($id);
            return $id ? (string) wp_get_attachment_url($id) : '';
        };

        $design['background']['image_url'] = $url(Arr::get($design, 'background.image_id'));

        foreach ($design['elements'] as $index => $element) {
            if (isset($element['image_id'])) {
                $design['elements'][$index]['image_url'] = $url($element['image_id']);
            }
        }

        return $design;
    }

    private static function dates(Certificate $certificate)
    {
        return [
            'issued_at'  => (string) $certificate->created_at,
            'expires_at' => $certificate->expired_at ? (string) $certificate->expired_at : null,
        ];
    }

    /**
     * For the holder's list: no render data.
     */
    public static function forOwnerSummary(Certificate $certificate)
    {
        return array_merge([
            'credential_id'    => $certificate->slug,
            'course'           => [ 'id' => $certificate->space_id, 'title' => $certificate->title ],
            'status'           => $certificate->getVerificationStatus(),
            'privacy'          => $certificate->privacy,
            'verification_url' => self::verificationUrl($certificate->slug),
        ], self::dates($certificate));
    }

    /**
     * For the holder viewing one certificate, private ones included.
     */
    public static function forOwner(Certificate $certificate)
    {
        return array_merge(self::forOwnerSummary($certificate), [
            'render' => self::renderPayload($certificate),
        ]);
    }

    /**
     * A card on the member's Certificates tab. Only the holder gets the LinkedIn link and
     * the privacy setting.
     */
    public static function forProfile(Certificate $certificate, $isOwner)
    {
        $item = array_merge(self::forOwnerSummary($certificate), [
            'render' => self::renderPayload($certificate, !$isOwner),
        ]);

        if ($isOwner) {
            $item['linkedin_url'] = self::linkedInUrl($certificate);
            $item['open_badge'] = $item['status'] === 'valid' && OpenBadgeCredential::isAvailable();
        } else {
            unset($item['privacy']);
        }

        return $item;
    }

    /**
     * LinkedIn "Add to profile" link (plan 5.8). LinkedIn may ignore the prefilled fields,
     * so the holder also gets copy buttons for the ID and the URL.
     */
    public static function linkedInUrl(Certificate $certificate)
    {
        $values = $certificate->getData();
        $issued = strtotime((string) $certificate->created_at);

        $params = [
            'startTask'        => 'CERTIFICATION_NAME',
            'name'             => $certificate->getTitle(),
            'organizationName' => (string) ($values['site.name'] ?? get_bloginfo('name')),
            'issueYear'        => gmdate('Y', $issued),
            'issueMonth'       => gmdate('n', $issued),
            'certUrl'          => self::verificationUrl($certificate->slug),
            'certId'           => $certificate->slug,
        ];

        if ($certificate->expired_at) {
            $expires = strtotime((string) $certificate->expired_at);
            $params['expirationYear'] = gmdate('Y', $expires);
            $params['expirationMonth'] = gmdate('n', $expires);
        }

        /*
         * Change the LinkedIn parameters, for example to use the company page's numeric
         * organizationId instead of organizationName (send one of the two, never both).
         */
        $params = apply_filters('fluent_community/certificate/linkedin_params', $params, $certificate);

        return add_query_arg(array_map('rawurlencode', $params), 'https://www.linkedin.com/profile/add');
    }

    /**
     * The secret in a holder link (holderUrl()). Only a manual certificate without an
     * account has one: that holder cannot log in to prove the certificate is theirs. The
     * email is part of the hash, so changing it (or linking an account) ends the old link.
     *
     * @return string '' when the certificate has no holder link
     */
    public static function holderToken(Certificate $certificate)
    {
        if (!$certificate->isManual() || $certificate->user_id) {
            return '';
        }

        return wp_hash('fcom-certificate-holder|' . $certificate->id . '|' . $certificate->slug . '|' . $certificate->getHolder()['email'], 'auth');
    }

    public static function isHolderToken(Certificate $certificate, $token)
    {
        $expected = self::holderToken($certificate);

        return $expected !== '' && is_string($token) && hash_equals($expected, $token);
    }

    /**
     * The verification page as the holder sees it, even when private: with the LinkedIn
     * button and the Open Badge download. Sent only in the holder's email.
     */
    public static function holderUrl(Certificate $certificate)
    {
        $token = self::holderToken($certificate);
        $url = self::verificationUrl($certificate->slug);

        return $token ? add_query_arg('holder', $token, $url) : $url;
    }

    /**
     * For anyone with the link. A private certificate only answers whether it is valid,
     * except to its holder.
     */
    public static function forVerification(Certificate $certificate, $asHolder = false)
    {
        $status = $certificate->getVerificationStatus();

        if ($certificate->privacy !== 'public' && !$asHolder) {
            return [
                'credential_id' => $certificate->slug,
                'is_private'    => true,
                'status'        => $status === 'valid' ? 'valid' : 'not_valid',
            ];
        }

        $values = $certificate->getData();

        return array_merge([
            'credential_id'    => $certificate->slug,
            'is_private'       => false,
            'status'           => $status,
            // Merge tag keys contain dots, so no Arr::get() here
            'holder_name'      => (string) ($values['student.full_name'] ?? ''),
            'course_title'     => $certificate->getTitle(),
            // A manual certificate may have no course: the page labels the title "Certificate"
            'kind'             => $certificate->isManual() ? 'manual' : 'course',
            'issuer'           => (string) ($values['site.name'] ?? ''),
            'verification_url' => self::verificationUrl($certificate->slug),
            'render'           => self::renderPayload($certificate, true),
        ], self::dates($certificate));
    }

    /**
     * For admins managing issued certificates.
     */
    public static function forAdmin(Certificate $certificate)
    {
        $meta = $certificate->meta;
        $user = $certificate->user_id ? $certificate->user : null;
        $isManual = $certificate->isManual();
        $holder = $isManual ? $certificate->getHolder() : null;

        return array_merge([
            'id'                => $certificate->id,
            'kind'              => $isManual ? 'manual' : 'course',
            'credential_id'     => $certificate->slug,
            'serial'            => $certificate->priority,
            'status'            => $certificate->status,
            'verification'      => $certificate->getVerificationStatus(),
            'privacy'           => $certificate->privacy,
            'holder'            => [
                'id'     => $certificate->user_id,
                // A manual certificate prints the name the admin typed, not the account's
                'name'   => $holder ? $holder['name'] : (string) ($certificate->getData()['student.full_name'] ?? ''),
                'email'  => $holder ? $holder['email'] : ($user ? $user->user_email : ''),
                'avatar' => $user ? (string) $user->photo : '',
            ],
            'title'             => $certificate->title,
            'course'            => [
                'id'    => $certificate->space_id,
                // On a manual certificate the title is the certificate's name, not the course's
                'title' => $isManual ? (string) ($certificate->getData()['course.title'] ?? '') : $certificate->title,
            ],
            'template_id'       => $certificate->parent_id,
            'template_title'    => $isManual && $certificate->template ? (string) $certificate->template->title : '',
            'template_version'  => (int) Arr::get($meta, 'template_version'),
            'source'            => (string) Arr::get($meta, 'source', ''),
            'status_reason'     => (string) Arr::get($meta, 'status_reason', ''),
            'status_changed_at' => Arr::get($meta, 'status_changed_at'),
            'verification_url'  => self::verificationUrl($certificate->slug),
            // For the admin to hand over when the email is off; '' with an account
            'holder_url'        => self::holderToken($certificate) ? self::holderUrl($certificate) : '',
        ], self::dates($certificate));
    }
}
