<?php

namespace FluentCommunityPro\App\Modules\Certificates\Services;

use FluentCommunity\Framework\Support\Arr;
use FluentCommunityPro\App\Modules\Certificates\Models\Certificate;
use FluentCommunityPro\App\Modules\Certificates\Models\CertificateTemplate;
use FluentCommunityPro\App\Services\NamedLock;

/**
 * Issues certificates and changes their status.
 *
 * Issuing is idempotent per (course, user): core fires fluent_community/course/completed again
 * when a student completes lessons published after their first completion, and two requests
 * can complete the same course at once. A named MySQL lock serialises the check and the insert,
 * since fcom_posts has no unique key to lean on.
 */
class CertificateIssuer
{
    const LOCK_NAME = 'fcom_certificate_issue';

    /**
     * Certificates issued during this request, by "courseId:userId".
     *
     * @var Certificate[]
     */
    private static $issuedNow = [];

    /**
     * The certificate issued for this course and student during the current request, if any:
     * the lesson-completion response shows it once, not on every later completion.
     *
     * @return Certificate|null
     */
    public static function issuedInThisRequest($courseId, $userId)
    {
        return self::$issuedNow[$courseId . ':' . $userId] ?? null;
    }

    /**
     * fluent_community/course/completed
     *
     * @param \FluentCommunity\Modules\Course\Model\Course $course
     * @param int $userId
     */
    public static function onCourseCompleted($course, $userId)
    {
        if (CertificateSettings::get($course)['enabled'] !== 'yes') {
            return;
        }

        $result = self::issue($course, $userId, [ 'source' => 'auto' ]);

        // A revoked certificate is final; completing the course again is not a failure
        if (is_wp_error($result) && $result->get_error_code() !== 'revoked') {
            do_action('fluent_community/certificate/issue_failed', $result, $course, $userId);
        }
    }

    /**
     * @param \FluentCommunity\Modules\Course\Model\Course $course
     * @param int   $userId
     * @param array $args source (auto|manual|backfill|api|crm|learndash), issued_by, issued_at, completed_at
     * @return Certificate|\WP_Error the new certificate, or the one the user already holds
     */
    public static function issue($course, $userId, array $args = [])
    {
        $settings = CertificateSettings::get($course);
        $template = $settings['template_id'] ? CertificateTemplate::find($settings['template_id']) : null;

        if (!$template || !$template->isPublished()) {
            return new \WP_Error('no_template', __('The course has no published certificate template.', 'fluent-community-pro'));
        }

        if (!get_user_by('ID', $userId)) {
            return new \WP_Error('invalid_user', __('The student could not be found.', 'fluent-community-pro'));
        }

        /**
         * Last word on whether a certificate is issued, e.g. to require a minimum quiz score.
         *
         * @param bool  $canIssue
         * @param \FluentCommunity\Modules\Course\Model\Course $course
         * @param int   $userId
         * @param array $args
         */
        if (!apply_filters('fluent_community/certificate/can_issue', true, $course, $userId, $args)) {
            return new \WP_Error('not_allowed', __('A certificate cannot be issued for this student.', 'fluent-community-pro'));
        }

        $result = NamedLock::run(self::LOCK_NAME, function () use ($course, $userId, $args, $settings, $template) {
            // Again inside the lock: deleteTemplate() deletes under this same lock
            $template = CertificateTemplate::find($template->id);
            if (!$template || !$template->isPublished()) {
                return new \WP_Error('no_template', __('The course has no published certificate template.', 'fluent-community-pro'));
            }

            // Manual certificates never count: a workshop certificate pre-filled from this
            // course is not the course's certificate
            $existing = Certificate::courseCertificates()->where('space_id', $course->id)->where('user_id', $userId)->orderBy('id', 'DESC')->first();
            if ($existing && $existing->status !== Certificate::STATUS_REVOKED) {
                return [ 'certificate' => $existing, 'is_new' => false ];
            }

            // Revoking is final. Core fires course/completed again (a lesson published later, a
            // progress reset), and that must not hand the student a new certificate.
            if ($existing) {
                return new \WP_Error('revoked', __('This student\'s certificate for the course was revoked.', 'fluent-community-pro'));
            }

            $issuedAt = Arr::get($args, 'issued_at');
            if (!$issuedAt) {
                $issuedAt = current_time('mysql');
            }
            $expiresAt = $settings['expiry_months']
                ? gmdate('Y-m-d H:i:s', strtotime('+' . (int) $settings['expiry_months'] . ' months', strtotime($issuedAt)))
                : null;

            $credentialId = self::newCredentialId();
            $serial = self::nextSerial();

            $values = MergeValues::resolve($course, $userId, [
                'issued_at'     => $issuedAt,
                'expires_at'    => $expiresAt,
                'completed_at'  => Arr::get($args, 'completed_at'),
                'credential_id' => $credentialId,
                'serial'        => $serial,
            ]);

            $certificate = Certificate::create([
                'user_id'    => $userId,
                'space_id'   => $course->id,
                'parent_id'  => $template->id,
                'slug'       => $credentialId,
                'title'      => $course->title,
                'priority'   => $serial,
                'expired_at' => $expiresAt,
                'created_at' => $issuedAt,
                'meta'       => [
                    'template_version'  => $template->getCurrentVersion(),
                    'data'              => $values,
                    'source'            => sanitize_key(Arr::get($args, 'source', 'auto')),
                    'issued_by'         => (int) Arr::get($args, 'issued_by', 0),
                    // CertificateMailer: completions email the student, backfills and imports do not
                    'notify'            => (bool) Arr::get($args, 'notify', Arr::get($args, 'source', 'auto') === 'auto'),
                    'status_list_index' => null,
                ],
            ]);

            return [ 'certificate' => $certificate, 'is_new' => true ];
        });

        if (is_wp_error($result)) {
            return $result;
        }

        $certificate = $result['certificate'];

        if (!$result['is_new']) {
            return $certificate;
        }

        self::$issuedNow[$course->id . ':' . $userId] = $certificate;

        do_action('fluent_community/certificate/issued', $certificate, $course, $userId);

        return $certificate;
    }

    /**
     * Withdraw a certificate in a way that can be undone (see reinstate).
     *
     * @return Certificate|\WP_Error
     */
    public static function suspend(Certificate $certificate, $reason, $byUserId)
    {
        return self::changeStatus($certificate, Certificate::STATUS_SUSPENDED, $reason, $byUserId, 'suspended', function ($fresh) {
            return $fresh->status === Certificate::STATUS_ISSUED
                ? true
                : new \WP_Error('invalid_status', __('Only an active certificate can be suspended.', 'fluent-community-pro'));
        });
    }

    /**
     * @return Certificate|\WP_Error
     */
    public static function reinstate(Certificate $certificate, $byUserId)
    {
        return self::changeStatus($certificate, Certificate::STATUS_ISSUED, '', $byUserId, 'reinstated', function ($fresh) {
            return $fresh->status === Certificate::STATUS_SUSPENDED
                ? true
                : new \WP_Error('invalid_status', __('Only a suspended certificate can be reinstated.', 'fluent-community-pro'));
        });
    }

    /**
     * Final, like Open Badges status-list revocation: a revoked certificate never comes back,
     * and the student is not issued a new one automatically (see issue()).
     *
     * @return Certificate|\WP_Error
     */
    public static function revoke(Certificate $certificate, $reason, $byUserId)
    {
        return self::changeStatus($certificate, Certificate::STATUS_REVOKED, $reason, $byUserId, 'revoked', function ($fresh) {
            return $fresh->status !== Certificate::STATUS_REVOKED
                ? true
                : new \WP_Error('invalid_status', __('The certificate is already revoked.', 'fluent-community-pro'));
        });
    }

    /**
     * Refresh the merge values (e.g. after a name change) and move the certificate to the
     * template's current version. The credential ID, serial, issue and expiry dates stay, so
     * shared links and LinkedIn entries keep working.
     *
     * @return Certificate|\WP_Error
     */
    public static function reissue(Certificate $certificate, $byUserId)
    {
        // Reissuing rebuilds the values from the course; a manual certificate's values were
        // typed by an admin and are changed by editing it (ManualCertificates)
        if ($certificate->isManual()) {
            return new \WP_Error('manual_certificate', __('Edit a manual certificate to change it.', 'fluent-community-pro'));
        }

        $result = NamedLock::run(self::certificateLock($certificate), function () use ($certificate, $byUserId) {
            $fresh = Certificate::find($certificate->id);

            return $fresh ? self::reissueNow($fresh, $byUserId) : new \WP_Error('not_found', __('Certificate not found.', 'fluent-community-pro'));
        });

        if (!is_wp_error($result)) {
            $certificate->setRawAttributes($result->getAttributes(), true);
            do_action('fluent_community/certificate/reissued', $certificate, $byUserId);
            return $certificate;
        }

        return $result;
    }

    private static function reissueNow(Certificate $certificate, $byUserId)
    {
        if ($certificate->status === Certificate::STATUS_REVOKED) {
            return new \WP_Error('invalid_status', __('A revoked certificate cannot be reissued.', 'fluent-community-pro'));
        }

        $course = $certificate->course;
        $template = $certificate->template;

        if (!$course || !$template || !$template->isPublished()) {
            return new \WP_Error('no_template', __('The certificate template is no longer published.', 'fluent-community-pro'));
        }

        $meta = $certificate->meta;
        $previousData = (array) Arr::get($meta, 'data', []);

        $meta['data'] = MergeValues::resolve($course, $certificate->user_id, [
            'issued_at'     => (string) $certificate->created_at,
            'expires_at'    => $certificate->expired_at,
            'completed_at'  => null,
            'credential_id' => $certificate->slug,
            'serial'        => $certificate->priority,
        ]);

        // Keep the date the student actually completed the course
        if (isset($previousData['course.completion_date'])) {
            $meta['data']['course.completion_date'] = $previousData['course.completion_date'];
        }

        $meta['template_version'] = $template->getCurrentVersion();
        $meta['reissued_at'] = current_time('mysql');
        $meta['reissued_by'] = (int) $byUserId;

        $certificate->meta = $meta;
        $certificate->featured_image = null; // the cached preview no longer matches
        $certificate->save();

        return $certificate;
    }

    /**
     * Status changes run under the certificate's own lock, on a fresh copy, and check the
     * precondition there: a reinstate that loaded the certificate before a revoke saved must
     * not write 'issued' over the revocation.
     *
     * @param callable $allowed fresh certificate => true|\WP_Error
     * @return Certificate|\WP_Error
     */
    private static function changeStatus(Certificate $certificate, $status, $reason, $byUserId, $action, callable $allowed)
    {
        $result = NamedLock::run(self::certificateLock($certificate), function () use ($certificate, $status, $reason, $byUserId, $allowed) {
            $fresh = Certificate::find($certificate->id);
            if (!$fresh) {
                return new \WP_Error('not_found', __('Certificate not found.', 'fluent-community-pro'));
            }

            $check = $allowed($fresh);
            if (is_wp_error($check)) {
                return $check;
            }

            $meta = $fresh->meta;
            $meta['status_reason'] = sanitize_textarea_field((string) $reason);
            $meta['status_changed_at'] = current_time('mysql');
            $meta['status_changed_by'] = (int) $byUserId;

            $fresh->status = $status;
            $fresh->meta = $meta;
            $fresh->save();

            return $fresh;
        });

        if (!is_wp_error($result)) {
            // The caller's copy follows the saved row
            $certificate->setRawAttributes($result->getAttributes(), true);
            do_action('fluent_community/certificate/' . $action, $certificate, $byUserId);
            return $certificate;
        }

        return $result;
    }

    private static function certificateLock(Certificate $certificate)
    {
        return 'fcom_cert_' . $certificate->id;
    }

    /**
     * The next display serial. Course and manual certificates share one sequence. Call it
     * inside LOCK_NAME.
     */
    public static function nextSerial()
    {
        return (int) Certificate::max('priority') + 1;
    }

    /**
     * Call it inside LOCK_NAME.
     */
    public static function newCredentialId()
    {
        for ($i = 0; $i < 5; $i++) {
            $id = CredentialId::generate();
            if (!Certificate::byCredential($id)->exists()) {
                return $id;
            }
        }

        throw new \RuntimeException('Could not generate a unique credential ID.');
    }
}
