<?php

namespace FluentCommunityPro\App\Modules\Certificates\Services;

use FluentCommunity\App\Models\Activity;
use FluentCommunity\App\Models\XProfile;
use FluentCommunity\App\Services\Helper;
use FluentCommunity\Framework\Support\Arr;
use FluentCommunity\Modules\Course\Model\CourseLesson;

/**
 * Resolves the merge tags (TemplateDesign::MERGE_TAGS) once, when a certificate is issued.
 * The values are stored on the certificate, so a later name or title change only reaches it
 * through a deliberate reissue.
 *
 * Every tag has a fallback: a manual or imported certificate may have no completion record,
 * and a user may have no name set. The holder's name is never their login.
 */
class MergeValues
{
    /**
     * @param \FluentCommunity\Modules\Course\Model\Course $course
     * @param int $userId
     * @param array $context issued_at, expires_at (Y-m-d H:i:s or null), credential_id, serial, completed_at (optional)
     * @return array tag => string
     */
    public static function resolve($course, $userId, array $context)
    {
        $name = self::personName($userId);
        $issuedAt = $context['issued_at'];
        $completedAt = Arr::get($context, 'completed_at');
        if (!$completedAt) {
            $completedAt = self::completedAt($course->id, $userId);
        }
        if (!$completedAt) {
            $completedAt = $issuedAt;
        }

        $siteName = Arr::get(Helper::generalSettings(), 'site_title');

        $values = [
            'student.full_name'         => $name['full'],
            'student.first_name'        => $name['first'],
            'student.last_name'         => $name['last'],
            'course.title'              => (string) $course->title,
            'course.instructor'         => $course->created_by ? self::personName($course->created_by)['full'] : '',
            'course.lesson_count'       => self::lessonCount($course),
            'course.completion_date'    => self::formatDate($completedAt),
            'certificate.issue_date'    => self::formatDate($issuedAt),
            'certificate.expiry_date'   => empty($context['expires_at']) ? '' : self::formatDate($context['expires_at']),
            'certificate.credential_id' => (string) $context['credential_id'],
            'certificate.serial'        => self::serial($issuedAt, $context['serial'] ?? 0),
            // The certificate's own name and date; a manual certificate types its own
            'certificate.title'         => (string) $course->title,
            'certificate.description'   => '',
            'certificate.date'          => self::formatDate($completedAt),
            'site.name'                 => (string) ($siteName ? $siteName : get_bloginfo('name')),
        ];

        /**
         * Change or add merge values for a certificate being issued.
         *
         * @param array $values  tag => string
         * @param \FluentCommunity\Modules\Course\Model\Course $course
         * @param int   $userId
         * @param array $context
         */
        $values = apply_filters('fluent_community/certificate/merge_values', $values, $course, $userId, $context);

        return array_map('strval', (array) $values);
    }

    /**
     * Full name from the profile fields, then the community display name, then the WordPress
     * display name. The login is only ever the last resort, when nothing else is set.
     *
     * @return array ['full' => string, 'first' => string, 'last' => string]
     */
    public static function personName($userId)
    {
        $user = get_user_by('ID', $userId);
        if (!$user) {
            return [ 'full' => '', 'first' => '', 'last' => '' ];
        }

        $first = trim((string) get_user_meta($userId, 'first_name', true));
        $last = trim((string) get_user_meta($userId, 'last_name', true));
        $full = trim($first . ' ' . $last);

        if (!$full) {
            $profile = XProfile::where('user_id', $userId)->first();
            $candidates = [ $profile ? $profile->display_name : '', $user->display_name ];

            foreach ($candidates as $candidate) {
                $candidate = trim((string) $candidate);
                if ($candidate && $candidate !== $user->user_login) {
                    $full = $candidate;
                    break;
                }
            }
        }

        if (!$full) {
            $full = (string) ($user->display_name ? $user->display_name : $user->user_login);
        }

        if (!$first) {
            $firstWord = strtok($full, ' ');
            $first = $firstWord ? $firstWord : $full;
        }

        return [ 'full' => $full, 'first' => $first, 'last' => $last ];
    }

    /**
     * The first completion: core moves updated_at when a student completes newly added lessons.
     */
    public static function lessonCount($course)
    {
        return (string) CourseLesson::where('space_id', $course->id)->where('status', 'published')->count();
    }

    public static function completedAt($courseId, $userId)
    {
        $activity = Activity::where('feed_id', $courseId)
            ->where('user_id', $userId)
            ->where('action_name', 'course_completed')
            ->first();

        return $activity ? (string) $activity->created_at : null;
    }

    public static function serial($issuedAt, $serial)
    {
        return $serial ? gmdate('Y', strtotime($issuedAt)) . '-' . str_pad((string) $serial, 5, '0', STR_PAD_LEFT) : '';
    }

    public static function formatDate($mysqlDate)
    {
        return date_i18n(get_option('date_format'), strtotime($mysqlDate));
    }
}
