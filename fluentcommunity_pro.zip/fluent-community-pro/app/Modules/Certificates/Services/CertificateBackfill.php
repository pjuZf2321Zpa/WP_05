<?php

namespace FluentCommunityPro\App\Modules\Certificates\Services;

use FluentCommunity\App\Models\Activity;
use FluentCommunityPro\App\Modules\Certificates\Models\Certificate;

/**
 * Issues certificates for students who completed a course before its certificate was turned
 * on. Core records each completion as a `course_completed` activity (CourseHelper::
 * completeCourse); its created_at is the completion date, and it becomes the issue date, so
 * the expiry counts from the real completion and an old one may already be expired.
 *
 * A student who holds any certificate for the course, a revoked one included, is skipped: a
 * backfill must never undo an admin's revocation.
 *
 * Work goes in batches with a cursor (the activity ID), so a large course is resumable and no
 * request runs long. The admin screen drives the batches; the LearnDash migrator calls run()
 * directly.
 */
class CertificateBackfill
{
    const BATCH = 25;

    /**
     * @param \FluentCommunity\Modules\Course\Model\Course $course
     * @return array completions, pending (completions without any certificate)
     */
    public static function summary($course)
    {
        return [
            'completions' => (int) self::completions($course)->count(),
            'pending'     => (int) self::completions($course)->whereNotIn('user_id', self::holders($course))->count(),
        ];
    }

    /**
     * One batch.
     *
     * @param \FluentCommunity\Modules\Course\Model\Course $course
     * @param int $afterId the cursor from the previous batch; 0 to start
     * @param int $limit
     * @return array|\WP_Error issued, skipped, failed, errors, cursor, done, pending
     */
    public static function run($course, $afterId = 0, $limit = self::BATCH)
    {
        if (CertificateSettings::get($course)['enabled'] !== 'yes') {
            return new \WP_Error('not_enabled', __('Turn on the certificate for this course and save, then issue for past completions.', 'fluent-community-pro'));
        }

        $rows = self::completions($course)
            ->where('id', '>', absint($afterId))
            ->orderBy('id', 'ASC')
            ->limit(max(1, min(100, (int) $limit)))
            ->get();

        $result = [ 'issued' => 0, 'skipped' => 0, 'failed' => 0, 'errors' => [], 'cursor' => (int) $afterId ];

        foreach ($rows as $row) {
            $result['cursor'] = (int) $row->id;

            if (Certificate::courseCertificates()->where('space_id', $course->id)->where('user_id', $row->user_id)->exists()) {
                ++$result['skipped'];
                continue;
            }

            $certificate = CertificateIssuer::issue($course, (int) $row->user_id, [
                'source'       => 'backfill',
                'issued_by'    => get_current_user_id(),
                'issued_at'    => (string) $row->created_at,
                'completed_at' => (string) $row->created_at,
            ]);

            if (is_wp_error($certificate)) {
                ++$result['failed'];
                // A few examples are enough to act on; a broken template fails every row
                if (count($result['errors']) < 5) {
                    $result['errors'][] = [ 'user_id' => (int) $row->user_id, 'message' => $certificate->get_error_message() ];
                }
                continue;
            }

            ++$result['issued'];
        }

        $result['done'] = !self::completions($course)->where('id', '>', $result['cursor'])->exists();
        $result['pending'] = self::summary($course)['pending'];

        return $result;
    }

    private static function completions($course)
    {
        return Activity::where('feed_id', $course->id)->where('action_name', 'course_completed');
    }

    private static function holders($course)
    {
        return function ($query) use ($course) {
            $query->select('user_id')
                ->from('fcom_posts')
                ->where('type', Certificate::TYPE)
                ->where('content_type', Certificate::KIND_COURSE)
                ->where('space_id', $course->id);
        };
    }
}
