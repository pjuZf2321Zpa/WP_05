<?php

namespace FluentCommunityPro\App\Modules\Quiz;

use FluentCommunity\Framework\Support\Arr;

/**
 * Scoring with points per question and instructor-graded written answers.
 * Plan: fluent-community docs/quiz/grading-plan.md.
 *
 * Each question is worth `points` (1-100, default 1, so quizzes made before points score as
 * before). A written answer with grading_mode "manual" earns nothing until an instructor gives
 * it points; until then the result is "pending", which never counts as passed.
 */
class QuizGrading
{
    const STATUS_PENDING = 'pending';

    const MAX_POINTS = 100;

    public static function points($question)
    {
        $points = (int) Arr::get($question, 'points', 1);

        return max(1, min(self::MAX_POINTS, $points));
    }

    /**
     * Rating scale (survey) questions have no right answer and stay out of the score.
     */
    public static function isScored($question)
    {
        return Arr::get($question, 'type') !== 'rating_scale';
    }

    /**
     * A rating scale's settings: lowest 0 or 1, highest 2-10, optional end labels.
     */
    public static function sanitizeScale($question)
    {
        $min = (int) Arr::get($question, 'scale_min', 1) === 0 ? 0 : 1;
        $max = max(2, min(10, (int) Arr::get($question, 'scale_max', 5)));

        return [
            'options'   => [],
            'scale_min' => $min,
            'scale_max' => max($min + 1, $max),
            'min_label' => sanitize_text_field((string) Arr::get($question, 'min_label', '')),
            'max_label' => sanitize_text_field((string) Arr::get($question, 'max_label', '')),
        ];
    }

    public static function isManual($question)
    {
        return Arr::get($question, 'type') === 'written_answer' && Arr::get($question, 'grading_mode') === 'manual';
    }

    /**
     * Score, status and counts from the per-question results.
     *
     * @param array    $questions    the quiz's enabled questions
     * @param array    $results      [slug => is_correct, awarded_points?, needs_review?]
     * @param int|null $passingScore percent; 0 or null when the quiz has no pass mark
     * @return array score, status, points_earned, points_total, correct_answers, total_questions, pending
     */
    public static function summarize(array $questions, array $results, $passingScore)
    {
        $earned = 0;
        $total = 0;
        $correct = 0;
        $pending = 0;

        $scored = 0;
        foreach ($questions as $question) {
            if (!self::isScored($question)) {
                continue;
            }

            ++$scored;
            $points = self::points($question);
            $total += $points;

            $result = Arr::get($results, Arr::get($question, 'slug'));
            if (!$result) {
                continue;
            }

            if (!empty($result['needs_review'])) {
                ++$pending;
                continue;
            }

            if (isset($result['awarded_points'])) {
                $earned += max(0, min($points, (int) $result['awarded_points']));
            } elseif (!empty($result['is_correct'])) {
                $earned += $points;
            }

            if (!empty($result['is_correct'])) {
                ++$correct;
            }
        }

        $score = $total ? (int) round($earned / $total * 100) : 0;

        if ($pending) {
            $status = self::STATUS_PENDING;
        } elseif ($passingScore && $total) {
            $status = $score >= (int) $passingScore ? 'passed' : 'failed';
        } else {
            $status = 'published';
        }

        return [
            'score'           => $score,
            'status'          => $status,
            'points_earned'   => $earned,
            'points_total'    => $total,
            'correct_answers' => $correct,
            'total_questions' => $scored,
            'pending'         => $pending,
        ];
    }

    /**
     * The result of one answered question, as stored in the quiz result.
     */
    public static function questionResult($question, $userAnswer)
    {
        $points = self::points($question);

        if (!self::isScored($question)) {
            $value = is_numeric($userAnswer) ? (int) $userAnswer : null;
            $min = (int) Arr::get($question, 'scale_min', 1);
            $max = (int) Arr::get($question, 'scale_max', 5);

            return [
                'is_correct'  => null,
                'unscored'    => true,
                'user_answer' => ($value !== null && $value >= $min && $value <= $max) ? $value : null,
            ];
        }

        if (self::isManual($question)) {
            return [
                'is_correct'   => null,
                'needs_review' => true,
                'user_answer'  => $userAnswer,
                'points'       => $points,
            ];
        }

        $isCorrect = QuizModel::isCorrectAnswer($question, $userAnswer);

        return [
            'is_correct'  => $isCorrect,
            'user_answer' => $userAnswer,
            'points'      => $points,
        ];
    }

    /**
     * Apply an instructor's grade to one answer.
     *
     * @param array  $result   the stored question result
     * @param array  $question
     * @param mixed  $points   points to award (clamped to 0..question points)
     * @param string $feedback shown to the student
     * @param int    $graderId
     */
    public static function grade(array $result, $question, $points, $feedback, $graderId)
    {
        $max = self::points($question);
        $awarded = max(0, min($max, (int) $points));

        $result['awarded_points'] = $awarded;
        $result['is_correct'] = $awarded >= $max;
        $result['needs_review'] = false;
        $result['feedback'] = sanitize_textarea_field((string) $feedback);
        $result['graded_by'] = (int) $graderId;
        $result['graded_at'] = current_time('mysql');

        return $result;
    }
}
