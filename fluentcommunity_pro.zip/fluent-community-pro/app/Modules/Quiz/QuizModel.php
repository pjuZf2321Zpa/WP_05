<?php

namespace FluentCommunityPro\App\Modules\Quiz;

use FluentCommunity\Framework\Support\Arr;
use FluentCommunityPro\App\Models\Model;
use FluentCommunity\App\Models\User;
use FluentCommunity\App\Models\XProfile;
use FluentCommunity\Modules\Course\Model\CourseLesson;

class QuizModel extends Model
{
    protected $table = 'fcom_post_comments';

    protected $guarded = [ 'id' ];

    protected $fillable = [
        'user_id',
        'post_id',
        'parent_id',
        'meta',
        'type',
        'score',
        'status',
        'message',
        'content_type',
        'created_at',
        'updated_at',
    ];

    protected $attributeMap = [
        'score'   => 'reactions_count',
    ];

    public static function boot()
    {
        parent::boot();

        static::creating(function ($model) {
            $model->type = 'quiz';
            $model->content_type = 'quiz';
            if (empty($model->status)) {
                $model->status = 'published';
            }
        });

        static::addGlobalScope('type', function ($builder) {
            $builder->where('type', 'quiz');
        });

        static::addGlobalScope('defaultSelect', function ($builder) {
            $builder->select([
                'id',
                'user_id',
                'post_id',
                'parent_id',
                'meta',
                'type',
                'status',
                'content_type',
                'message',
                'reactions_count as score',
                'updated_at',
            ]);
        });
    }

    public function getAttribute($key)
    {
        if (array_key_exists($key, $this->attributeMap)) {
            if (array_key_exists($key, $this->attributes)) {
                return parent::getAttribute($key);
            }
            return parent::getAttribute($this->attributeMap[$key]);
        }

        return parent::getAttribute($key);
    }

    public function setAttribute($key, $value)
    {
        if (array_key_exists($key, $this->attributeMap)) {
            return parent::setAttribute($this->attributeMap[$key], $value);
        }

        return parent::setAttribute($key, $value);
    }

    public function setMetaAttribute($value)
    {
        $this->attributes['meta'] = \maybe_serialize($value);
    }

    public function getMetaAttribute($value)
    {
        return \maybe_unserialize($value);
    }

    public function getMessageAttribute($value)
    {
        return \maybe_unserialize($value);
    }

    public function setMessageAttribute($value)
    {
        $this->attributes['message'] = \maybe_serialize($value);
    }

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id', 'ID');
    }

    public function xprofile()
    {
        return $this->belongsTo(XProfile::class, 'user_id', 'user_id');
    }

    public function lesson()
    {
        return $this->belongsTo(CourseLesson::class, 'post_id', 'id');
    }

    public function hideCorrectAnswers()
    {
        return array_map(function ($answer) {
            if (isset($answer['is_correct'])) {
                unset($answer['is_correct']);
            }
            if (isset($answer['explanation_rendered'])) {
                unset($answer['explanation_rendered']);
            }
            if (isset($answer['correct_options'])) {
                unset($answer['correct_options']);
            }
            return $answer;
        }, $this->message);
    }

    public static function isCorrectAnswer($question, $userAnswer)
    {
        $questionType = Arr::get($question, 'type');
        $questionOptions = Arr::get($question, 'options');

        if ($questionType === 'written_answer') {
            if (empty($userAnswer)) {
                return false;
            }
            $gradingMode = Arr::get($question, 'grading_mode', 'open');
            if ($gradingMode === 'exact_match') {
                return static::matchesAnyVariant($userAnswer, Arr::get($question, 'correct_answers', []));
            }
            return true;
        }

        if ($questionType === 'fill_in_the_blank') {
            $blanks = (array) Arr::get($question, 'blanks', []);
            if (!$blanks || !is_array($userAnswer) || count($userAnswer) !== count($blanks)) {
                return false;
            }
            $userAnswer = array_values($userAnswer);
            foreach (array_values($blanks) as $index => $variants) {
                if (!static::matchesAnyVariant($userAnswer[$index], (array) $variants)) {
                    return false;
                }
            }
            return true;
        }

        if (in_array($questionType, [ 'ordering', 'matching', 'image_matching' ], true)) {
            $expected = static::getCorrectAnswer($question);
            if (!$expected || !is_array($userAnswer)) {
                return false;
            }
            return array_map('strval', array_values($userAnswer)) === array_map('strval', $expected);
        }

        if (in_array($questionType, [ 'single_choice', 'true_false' ], true)) {
            foreach ($questionOptions as $option) {
                if (!is_array($userAnswer) && (string) $userAnswer === (string) Arr::get($option, 'label') && Arr::isTrue($option, 'is_correct')) {
                    return true;
                }
            }
            return false;
        }

        if ($questionType === 'multiple_choice') {
            $correctLabels = [];
            foreach ($questionOptions as $option) {
                if (Arr::isTrue($option, 'is_correct')) {
                    $correctLabels[] = Arr::get($option, 'label');
                }
            }
            if (!is_array($userAnswer)) {
                return false;
            }

            // Set comparison, not a count plus a one-way diff. array_diff()
            // compares values and ignores multiplicity, so ['A','A'] diffed
            // against ['A','B'] came out empty while count() saw 2 == 2: a
            // student who knew one of two correct options could submit it twice
            // and be graded fully correct. Deduplicating first and diffing both
            // ways makes a missing selection and a repeated one both wrong.
            $userLabels = array_unique($userAnswer);

            return !array_diff($userLabels, $correctLabels)
                && !array_diff($correctLabels, $userLabels);
        }

        return false;
    }

    public static function normalizeAnswer($value)
    {
        return strtolower(trim((string) $value, " \t\n\r\0\x0B.,!?;:"));
    }

    protected static function matchesAnyVariant($userAnswer, $variants)
    {
        if (!is_scalar($userAnswer)) {
            return false;
        }
        $normalizedUser = static::normalizeAnswer($userAnswer);
        if ($normalizedUser === '') {
            return false;
        }
        foreach ($variants as $accepted) {
            if (static::normalizeAnswer($accepted) === $normalizedUser) {
                return true;
            }
        }
        return false;
    }

    /**
     * The answer key in the shape a student submits: choice labels, the ordering
     * sequence, the match per prompt, or the first accepted variant per blank.
     */
    public static function getCorrectAnswer($question)
    {
        $type = Arr::get($question, 'type');
        $options = (array) Arr::get($question, 'options', []);

        if ($type === 'ordering') {
            return array_values(array_column($options, 'label'));
        }

        if (in_array($type, [ 'matching', 'image_matching' ], true)) {
            return array_values(array_column($options, 'match'));
        }

        if ($type === 'fill_in_the_blank') {
            return array_map(function ($variants) {
                return (string) Arr::get((array) $variants, 0, '');
            }, array_values((array) Arr::get($question, 'blanks', [])));
        }

        $correctLabels = [];
        foreach ($options as $option) {
            if (Arr::isTrue($option, 'is_correct')) {
                $correctLabels[] = Arr::get($option, 'label');
            }
        }
        return $correctLabels;
    }
}
