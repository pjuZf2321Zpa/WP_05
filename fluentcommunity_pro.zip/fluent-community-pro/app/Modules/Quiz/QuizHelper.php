<?php

namespace FluentCommunityPro\App\Modules\Quiz;

use FluentCommunity\App\Services\Helper;
use FluentCommunity\Framework\Support\Arr;

class QuizHelper
{
    const ANSWER_KEY_TYPES = [ 'true_false', 'fill_in_the_blank', 'ordering', 'matching', 'image_matching' ];

    public static function getQuestionTypes()
    {
        return apply_filters('fluent_community/question_types', [
            [
                'value'       => 'single_choice',
                'label'       => __('Single Choice', 'fluent-community-pro'),
                'description' => __('One correct option', 'fluent-community-pro'),
            ],
            [
                'value'       => 'multiple_choice',
                'label'       => __('Multiple Choice', 'fluent-community-pro'),
                'description' => __('Several correct options', 'fluent-community-pro'),
            ],
            [
                'value'       => 'true_false',
                'label'       => __('True / False', 'fluent-community-pro'),
                'description' => __('Judge a statement', 'fluent-community-pro'),
            ],
            [
                'value'       => 'written_answer',
                'label'       => __('Written Answer', 'fluent-community-pro'),
                'description' => __('Open or exact-match text', 'fluent-community-pro'),
            ],
            [
                'value'       => 'fill_in_the_blank',
                'label'       => __('Fill in the Blank', 'fluent-community-pro'),
                'description' => __('Complete the sentence', 'fluent-community-pro'),
            ],
            [
                'value'       => 'ordering',
                'label'       => __('Ordering', 'fluent-community-pro'),
                'description' => __('Put items in sequence', 'fluent-community-pro'),
            ],
            [
                'value'       => 'matching',
                'label'       => __('Matching', 'fluent-community-pro'),
                'description' => __('Pair prompts with answers', 'fluent-community-pro'),
            ],
            [
                'value'       => 'image_matching',
                'label'       => __('Image Matching', 'fluent-community-pro'),
                'description' => __('Pair images with labels', 'fluent-community-pro'),
            ],
            [
                'value'       => 'rating_scale',
                'label'       => __('Rating Scale', 'fluent-community-pro'),
                'description' => __('Survey answer, not scored', 'fluent-community-pro'),
            ],
        ]);
    }

    /**
     * Splits author text like "Capital is [[Paris|paris city]]." into the
     * accepted variants per blank and the text segments around the blanks.
     * segments always has count(blanks) + 1 entries.
     */
    public static function parseBlankText($text)
    {
        $parts = preg_split('/\[\[(.*?)\]\]/s', (string) $text, -1, PREG_SPLIT_DELIM_CAPTURE);

        $segments = [];
        $blanks = [];
        $buffer = '';

        foreach ($parts as $index => $part) {
            if ($index % 2 === 0) {
                $buffer .= $part;
                continue;
            }

            $variants = array_values(array_unique(array_filter(
                array_map('sanitize_text_field', explode('|', $part)),
                function ($value) {
                    return strlen((string) $value) > 0;
                }
            )));

            if (!$variants) {
                $buffer .= '[[' . $part . ']]';
                continue;
            }

            $segments[] = $buffer;
            $blanks[] = $variants;
            $buffer = '';
        }

        $segments[] = $buffer;

        return [
            'blanks'   => $blanks,
            'segments' => $segments,
        ];
    }

    /**
     * Shuffles by a per-user, per-question seed. Uniform, so the correct order can
     * appear like any other and the shown order tells nothing; stable across
     * reloads, so reloading cannot enumerate orders either. Keyed with wp_hash()
     * (site salt): the key includes each item's stored position, so a plain hash
     * of values the student knows would let them brute-force the answer offline.
     */
    public static function seededShuffle($items, $seed)
    {
        $items = array_values($items);
        $keys = [];
        foreach ($items as $index => $item) {
            $keys[$index] = wp_hash($seed . '|' . $index . '|' . wp_json_encode($item));
        }
        uksort($items, function ($first, $second) use ($keys) {
            return strcmp($keys[$first], $keys[$second]);
        });

        return array_values($items);
    }

    /**
     * Minimum structure a new-type question needs before a student can answer it.
     * The modal enforces the same rules; this covers saves that bypass it and
     * option images that fail to resolve on the server.
     */
    public static function isAnswerable($question)
    {
        $type = Arr::get($question, 'type');
        $options = (array) Arr::get($question, 'options', []);
        $filled = function ($option, $key) {
            return trim((string) Arr::get($option, $key, '')) !== '';
        };

        if ($type === 'fill_in_the_blank') {
            return !empty($question['blanks']);
        }

        if ($type === 'rating_scale') {
            return true;
        }

        if ($type === 'ordering') {
            return count($options) >= 2;
        }

        if ($type === 'matching' || $type === 'image_matching') {
            $promptKey = $type === 'matching' ? 'label' : 'image_url';
            foreach ($options as $option) {
                if (!$filled($option, $promptKey) || !$filled($option, 'match')) {
                    return false;
                }
            }
            return count($options) >= 2;
        }

        return true;
    }

    public static function collectOptionImages($questions)
    {
        $urls = [];
        foreach ((array) $questions as $question) {
            if (Arr::get($question, 'type') !== 'image_matching' && empty($question['option_images'])) {
                continue;
            }
            foreach ((array) Arr::get($question, 'options', []) as $option) {
                if (!empty($option['image_url'])) {
                    $urls[] = $option['image_url'];
                }
            }
        }
        return $urls;
    }

    public static function removeDroppedOptionImages($currentQuestions, $sanitizedQuestions, $lessonId)
    {
        $dropped = array_values(array_diff(static::collectOptionImages($currentQuestions), static::collectOptionImages($sanitizedQuestions)));

        if ($dropped) {
            do_action('fluent_community/remove_medias_by_url', $dropped, [
                'sub_object_id' => $lessonId,
            ]);
        }
    }

    /**
     * Removes what would give the answer away before a question reaches a student:
     * the blank answers, the stored ordering order and the prompt-to-match pairs.
     */
    public static function hideAnswerKey($question, $seed)
    {
        $seed .= '|' . Arr::get($question, 'slug');
        $type = Arr::get($question, 'type');

        if ($type === 'fill_in_the_blank') {
            unset($question['blank_text'], $question['blanks']);
            return $question;
        }

        $options = Arr::get($question, 'options', []);
        if (!is_array($options)) {
            return $question;
        }

        if ($type === 'ordering') {
            $question['options'] = static::seededShuffle($options, $seed);
            return $question;
        }

        if (in_array($type, [ 'matching', 'image_matching' ], true)) {
            $choices = array_merge(array_column($options, 'match'), (array) Arr::get($question, 'extra_matches', []));
            $choices = static::seededShuffle(array_unique($choices), $seed);

            $question['options'] = array_map(function ($option) {
                unset($option['match']);
                return $option;
            }, $options);
            $question['match_choices'] = $choices;
            unset($question['extra_matches']);
        }

        return $question;
    }

    public static function getCurrentImage($currentQuestions, $slug)
    {
        foreach ($currentQuestions as $question) {
            if ((string) Arr::get($question, 'slug') === (string) $slug) {
                return Arr::get($question, 'image_url', null);
            }
        }

        return null;
    }

    public static function maybeGenerateQuestionSlug($quizQuestions, $question)
    {
        if (Arr::get($question, 'slug')) {
            return $question['slug'];
        }

        $type = trim(Arr::get($question, 'type', ''));
        $base = sanitize_title($type);

        $existing = [];
        foreach ($quizQuestions as $q) {
            if (!empty($q['slug'])) {
                $existing[$q['slug']] = true;
            }
        }

        $slug = $base;
        $i = 1;
        while (isset($existing[$slug])) {
            $slug = $base . '_' . ($i++);
        }
        return $slug;
    }

    public static function handleMediaUrl($url, $currentImage, $slug, $lessonId)
    {
        $deleteMediaUrls = [];

        if ($url) {
            $media = Helper::getMediaFromUrl($url);
            if (!$media || $media->is_active) {
                return $currentImage;
            }

            $url = $media->public_url;

            $media->update([
                'is_active'     => true,
                'user_id'       => get_current_user_id(),
                'feed_id'       => $lessonId,
                'sub_object_id' => $lessonId,
                'object_source' => 'quiz_question_' . $slug,
            ]);
        }

        if ($currentImage) {
            $deleteMediaUrls[] = $currentImage;
        }

        do_action('fluent_community/remove_medias_by_url', $deleteMediaUrls, [
            'sub_object_id' => $lessonId,
        ]);

        return $url;
    }
}
