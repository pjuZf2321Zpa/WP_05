<?php

namespace FluentCommunityPro\App\Modules\Quiz\Http\Controllers;

use FluentCommunity\App\Http\Controllers\Controller;
use FluentCommunity\Framework\Http\Request\Request;
use FluentCommunity\Modules\Course\Model\Course;
use FluentCommunity\Modules\Course\Model\CourseLesson;
use FluentCommunity\Modules\Course\Services\CourseHelper;
use FluentCommunityPro\App\Services\NamedLock;
use FluentCommunityPro\App\Modules\Quiz\QuizGrading;
use FluentCommunityPro\App\Modules\Quiz\QuizLimits;
use FluentCommunityPro\App\Modules\Quiz\QuizModel;
use FluentCommunity\Framework\Support\Arr;

class QuizController extends Controller
{
    public function getQuizResult(Request $request, $courseId, $lessonId)
    {
        $user = $this->getUser(true);

        $quiz = CourseLesson::where('id', $lessonId)->whereHas('course', function ($query) use ($courseId) {
            $query->where('id', $courseId);
        })->firstOrFail();

        if (!CourseHelper::isEnrolled($courseId, $user->ID)) {
            return $this->sendError([
                'message' => __('You must be enrolled in this course to view the quiz result.', 'fluent-community-pro'),
            ], 403);
        }

        $quizResult = QuizModel::where('user_id', $user->ID)->where('post_id', $quiz->id)->first();

        if ($quizResult && Arr::isTrue($quiz->meta, 'hide_result')) {
            $quizResult->message = $quizResult->hideCorrectAnswers();
        }

        return [
            'result' => $quizResult,
            'timer'  => QuizLimits::runningTimer($user->ID, $quiz),
        ];
    }

    /**
     * Starts the timer on a timed quiz and returns its questions, which the lesson withholds
     * until then. A running timer is returned as it is, so a reload does not reset it.
     */
    public function startQuiz(Request $request, $courseId, $lessonId)
    {
        $user = $this->getUser(true);

        $quiz = CourseLesson::where('id', $lessonId)->whereHas('course', function ($query) use ($courseId) {
            $query->where('id', $courseId);
        })->firstOrFail();

        if (!CourseHelper::isEnrolled($courseId, $user->ID)) {
            return $this->sendError([
                'message' => __('You must be enrolled in this course to take the quiz.', 'fluent-community-pro'),
            ], 403);
        }

        if ($quiz->status !== 'published') {
            return $this->sendError([
                'message' => __('This quiz is not published yet', 'fluent-community-pro'),
            ]);
        }

        $attemptedQuiz = QuizModel::where('user_id', $user->ID)->where('post_id', $quiz->id)->first();
        if (!QuizLimits::hasAttemptsLeft($quiz, $attemptedQuiz)) {
            return $this->sendError([
                'message' => __('You have used all your attempts for this quiz.', 'fluent-community-pro'),
            ], 403);
        }

        $timer = QuizLimits::start($user->ID, $quiz);

        return [
            'timer'     => $timer,
            'questions' => Arr::get($quiz->getPublicLessonMeta(), 'quiz_questions', []),
        ];
    }

    public function getCourseQuizResults(Request $request, $courseId)
    {
        Course::findOrFail($courseId);

        $search = $request->getSafe('search');

        $filterBy = $request->getSafe('filter_by');

        if ($filterBy === 'n/a') {
            $filterBy = 'published';
        }

        $allowedStatuses = [ 'passed', 'failed', 'published', QuizGrading::STATUS_PENDING ];

        $results = QuizModel::where('parent_id', $courseId)
            ->whereHas('lesson')
            ->with('xprofile', 'lesson')
            ->when($search, function ($query, $search) {
                $query->where(function ($q) use ($search) {
                    $q->whereHas('xprofile', function ($q) use ($search) {
                        $q->where('display_name', 'LIKE', "%$search%")
                          ->orWhere('username', 'LIKE', "%$search%");
                    })
                    ->orWhereHas('lesson', function ($q) use ($search) {
                        $q->where('title', 'LIKE', "%$search%");
                    });
                });
            })
            ->when(in_array($filterBy, $allowedStatuses, true), function ($query) use ($filterBy) {
                return $query->where('status', $filterBy);
            })
            ->paginate();

        return [
            'results'       => $results,
            'pending_count' => QuizModel::where('parent_id', $courseId)->where('status', QuizGrading::STATUS_PENDING)->whereHas('lesson')->count(),
        ];
    }

    public function submitQuiz(Request $request, $courseId, $lessonId)
    {        
        $user = $this->getUser(true);

        $answers = $request->get('answers', []);

        $quiz = CourseLesson::where('id', $lessonId)->whereHas('course', function ($query) use ($courseId) {
            $query->where('id', $courseId);
        })->firstOrFail();

        if (!CourseHelper::isEnrolled($courseId, $user->ID)) {
            return $this->sendError([
                'message' => __('You must be enrolled in this course to submit the quiz.', 'fluent-community-pro'),
            ], 403);
        }

        if ($quiz->status !== 'published') {
            return $this->sendError([
                'message' => __('This quiz is not published yet', 'fluent-community-pro'),
            ]);
        }

        $results = [];
        foreach ($quiz->enabled_questions as $question) {
            $slug = Arr::get($question, 'slug');
            $userAnswer = isset($answers[$slug]) ? $answers[$slug] : null;
            if ($userAnswer === null || $userAnswer === '' || $userAnswer === []) {
                continue;
            }

            if (is_array($userAnswer)) {
                if (count($userAnswer) > 100) {
                    return $this->sendError([
                        'message' => __('Invalid answer submitted.', 'fluent-community-pro'),
                    ]);
                }
                $userAnswer = array_map(function ($value) {
                    return is_scalar($value) && mb_strlen((string) $value) <= 500 ? sanitize_text_field($value) : '';
                }, array_values($userAnswer));
            } elseif (Arr::get($question, 'type') === 'written_answer' && Arr::get($question, 'grading_mode') !== 'exact_match') {
                $userAnswer = sanitize_textarea_field($userAnswer);
            } else {
                $userAnswer = sanitize_text_field($userAnswer);
            }

            if (Arr::get($question, 'type') === 'written_answer' && is_string($userAnswer)) {
                $maxLength = Arr::get($question, 'grading_mode') === 'exact_match' ? 500 : 10000;
                if (mb_strlen($userAnswer) > $maxLength) {
                    return $this->sendError([
                        /* translators: %d: maximum number of characters */
                        'message' => sprintf(__('Answer exceeds the %d character limit', 'fluent-community-pro'), $maxLength),
                    ]);
                }
            }

            $results[$slug] = QuizGrading::questionResult($question, $userAnswer);

            $explanationRendered = Arr::get($question, 'explanation_rendered');
            if ($explanationRendered) {
                $results[$slug]['explanation_rendered'] = $explanationRendered;
            }

            $correctOptions = QuizModel::getCorrectAnswer($question);
            if ($correctOptions) {
                $results[$slug]['correct_options'] = $correctOptions;
            }
        }

        $totalQuestions = count($quiz->enabled_questions);
        if ($totalQuestions < 1) {
            return $this->sendError([
                'message' => __('This quiz has no enabled questions yet.', 'fluent-community-pro'),
            ], 422);
        }

        $summary = QuizGrading::summarize($quiz->enabled_questions, $results, $quiz->passing_score);

        $meta = [
            'total_questions' => $summary['total_questions'],
            'correct_answers' => $summary['correct_answers'],
            'points_earned'   => $summary['points_earned'],
            'points_total'    => $summary['points_total'],
            'pending'         => $summary['pending'],
            'passing_score'   => (int) $quiz->passing_score,
        ];

        // Two submits at once must not both pass the attempt check, or both create a result row
        $quizResult = NamedLock::run('fcom_quiz_submit_' . $user->ID . '_' . $quiz->id, function () use ($user, $quiz, $courseId, $meta, $summary, $results) {
            $attemptedQuiz = QuizModel::where('user_id', $user->ID)->where('post_id', $quiz->id)->first();

            if (!QuizLimits::hasAttemptsLeft($quiz, $attemptedQuiz)) {
                return new \WP_Error('no_attempts_left', __('You have used all your attempts for this quiz.', 'fluent-community-pro'));
            }

            $meta['attempts'] = $attemptedQuiz ? $attemptedQuiz->meta['attempts'] + 1 : 1;

            if ($attemptedQuiz && !empty($attemptedQuiz->meta['extra_attempts'])) {
                $meta['extra_attempts'] = (int) $attemptedQuiz->meta['extra_attempts'];
            }

            $timing = QuizLimits::finish($user->ID, $quiz);
            if ($timing) {
                $meta['time_taken'] = $timing['time_taken'];
                $meta['over_time'] = $timing['over_time'];
            }

            $quizData = [
                'user_id'   => $user->ID,
                'post_id'   => $quiz->id,
                'parent_id' => $courseId,
                'meta'      => $meta,
                'score'     => $summary['score'],
                'status'    => $summary['status'],
                'message'   => $results,
            ];

            if ($attemptedQuiz) {
                $attemptedQuiz->fill($quizData);
                $attemptedQuiz->save();
                return QuizModel::find($attemptedQuiz->id);
            }

            $quizResult = QuizModel::create($quizData);
            return QuizModel::find($quizResult->id);
        });

        if (is_wp_error($quizResult)) {
            return $this->sendError([
                'message' => $quizResult->get_error_message(),
            ], $quizResult->get_error_code() === 'busy' ? 409 : 403);
        }

        if ($quizResult && Arr::isTrue($quiz->meta, 'hide_result')) {
            $quizResult->message = $quizResult->hideCorrectAnswers();
        }

        do_action('fluent_community/quiz/submitted', $quizResult, $user, $quiz);

        return [
            'result'  => $quizResult,
            'message' => __('Quiz has been submitted successfully', 'fluent-community-pro'),
        ];
    }

    public function updateQuizResult(Request $request, $courseId, $quizId)
    {
        $quiz = QuizModel::where('id', $quizId)->where('parent_id', $courseId)->firstOrFail();

        $updateData = [];

        $status = strtolower($request->getSafe('status'));

        if (!in_array($status, [ 'passed', 'failed' ], true)) {
            return $this->sendError([
                'message' => __('Invalid status value.', 'fluent-community-pro'),
            ], 422);
        }

        $updateData['status'] = $status;

        $quiz->fill($updateData);
        $quiz->save();

        return [
            'result' => $quiz,
            'message' => __('Quiz result updated successfully', 'fluent-community-pro'),
        ];
    }

    /**
     * An instructor grades the written answers that wait for review: points (0 to the
     * question's points) and an optional comment each. The score and the status follow; when
     * nothing waits any more, the student is told.
     */
    public function gradeQuizResult(Request $request, $courseId, $resultId)
    {
        $result = QuizModel::where('id', $resultId)->where('parent_id', $courseId)->firstOrFail();
        $quiz = CourseLesson::where('id', $result->post_id)->where('space_id', $courseId)->firstOrFail();

        $grades = (array) $request->get('grades', []);
        $answers = (array) $result->message;
        $wasPending = $result->status === QuizGrading::STATUS_PENDING;
        $graded = 0;

        foreach ($quiz->enabled_questions as $question) {
            $slug = Arr::get($question, 'slug');
            if (!QuizGrading::isManual($question) || !isset($answers[$slug], $grades[$slug]) || !is_array($grades[$slug])) {
                continue;
            }

            if (!isset($grades[$slug]['points']) || !is_numeric($grades[$slug]['points'])) {
                continue;
            }

            $answers[$slug] = QuizGrading::grade($answers[$slug], $question, $grades[$slug]['points'], Arr::get($grades[$slug], 'feedback', ''), get_current_user_id());
            ++$graded;
        }

        if (!$graded) {
            return $this->sendError([
                'message' => __('Give points to at least one answer.', 'fluent-community-pro'),
            ], 422);
        }

        $summary = QuizGrading::summarize($quiz->enabled_questions, $answers, $quiz->passing_score);

        $meta = (array) $result->meta;
        foreach ([ 'total_questions', 'correct_answers', 'points_earned', 'points_total', 'pending' ] as $key) {
            $meta[$key] = $summary[$key];
        }
        $meta['passing_score'] = (int) $quiz->passing_score;

        $result->fill([
            'message' => $answers,
            'meta'    => $meta,
            'score'   => $summary['score'],
            'status'  => $summary['status'],
        ]);
        $result->save();
        $result = QuizModel::find($result->id);

        if ($wasPending && $summary['status'] !== QuizGrading::STATUS_PENDING) {
            /**
             * A quiz result's last answer waiting for review was graded.
             *
             * @param QuizModel    $result
             * @param CourseLesson $quiz
             * @param int          $graderId
             */
            do_action('fluent_community/quiz/graded', $result, $quiz, get_current_user_id());
        }

        return [
            'result'  => $result,
            'message' => __('The grades have been saved.', 'fluent-community-pro'),
        ];
    }

    /**
     * Allows a student one attempt beyond the quiz's attempt limit.
     */
    public function allowExtraAttempt(Request $request, $courseId, $resultId)
    {
        $result = QuizModel::where('id', $resultId)->where('parent_id', $courseId)->firstOrFail();

        $meta = (array) $result->meta;
        $meta['extra_attempts'] = (int) Arr::get($meta, 'extra_attempts', 0) + 1;

        $result->meta = $meta;
        $result->save();

        return [
            'result'  => QuizModel::find($result->id),
            'message' => __('The student can take the quiz one more time.', 'fluent-community-pro'),
        ];
    }

    public function getExportableQuizResults(Request $request, $courseId)
    {
        Course::findOrFail($courseId);

        $search = $request->getSafe('search');
        $filterBy = $request->getSafe('filter_by');

        if ($filterBy === 'n/a') {
            $filterBy = 'published';
        }

        $allowedStatuses = [ 'passed', 'failed', 'published', QuizGrading::STATUS_PENDING ];

        $results = QuizModel::where('parent_id', $courseId)
            ->whereHas('lesson')
            ->with('user', 'xprofile', 'lesson')
            ->when($search, function ($query, $search) {
                $query->where(function ($q) use ($search) {
                    $q->whereHas('xprofile', function ($q) use ($search) {
                        $q->where('display_name', 'LIKE', "%$search%")
                          ->orWhere('username', 'LIKE', "%$search%");
                    })
                    ->orWhereHas('lesson', function ($q) use ($search) {
                        $q->where('title', 'LIKE', "%$search%");
                    });
                });
            })
            ->when(in_array($filterBy, $allowedStatuses, true), function ($query) use ($filterBy) {
                return $query->where('status', $filterBy);
            })
            ->limit(5000)
            ->get();

        $rows = [];
        foreach ($results as $result) {
            $xprofile = $result->xprofile;
            $meta = $result->meta ? $result->meta : [];
            $rows[] = apply_filters('fluent_community/quiz/exportable_result_row', [
                'Student Name'   => $xprofile ? $xprofile->display_name : '',
                'Email'          => $result->user ? $result->user->user_email : '',
                'Username'       => $xprofile ? $xprofile->username : '',
                'Quiz'           => $result->lesson ? $result->lesson->title : '',
                'Score'          => ($result->score ? $result->score : 0) . '%',
                'Grade'          => in_array($result->status, [ 'passed', 'failed', QuizGrading::STATUS_PENDING ], true) ? $result->status : 'n/a',
                'Total Attempts' => Arr::get($meta, 'attempts', 0),
                'Submitted At'   => $result->updated_at ? $result->updated_at->format('Y-m-d H:i:s') : '',
            ], $result, $courseId);
        }

        return apply_filters('fluent_community/quiz/exportable_result_rows', [
            'results' => $rows,
        ], $results, $courseId);
    }
}
