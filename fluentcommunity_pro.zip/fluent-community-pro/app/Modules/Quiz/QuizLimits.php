<?php

namespace FluentCommunityPro\App\Modules\Quiz;

use FluentCommunity\Framework\Support\Arr;

/**
 * Attempt and time limits on a quiz. A student's result row counts their attempts; an
 * instructor can allow extra attempts on top of the quiz's limit. A timed quiz starts on the
 * server (user meta holds the start time), so the deadline does not depend on the browser.
 */
class QuizLimits
{
    /**
     * Seconds a submit may arrive after the deadline and still count as on time: the
     * browser submits at zero, and the request needs time to arrive.
     */
    const GRACE_SECONDS = 60;

    /**
     * The attempts the quiz allows, or 0 for unlimited.
     *
     * @param \FluentCommunity\Modules\Course\Model\CourseLesson $quiz
     * @return int
     */
    public static function maxAttempts($quiz)
    {
        $meta = (array) $quiz->meta;
        if (Arr::get($meta, 'limit_attempts') !== 'yes') {
            return 0;
        }

        return min(100, max(1, (int) Arr::get($meta, 'max_attempts', 1)));
    }

    /**
     * @param \FluentCommunity\Modules\Course\Model\CourseLesson $quiz
     * @param QuizModel|null                                     $result The student's result, null before the first attempt
     * @return bool
     */
    public static function hasAttemptsLeft($quiz, $result)
    {
        $max = self::maxAttempts($quiz);
        if (!$max || !$result) {
            return true;
        }

        $meta = (array) $result->meta;

        return (int) Arr::get($meta, 'attempts', 0) < $max + (int) Arr::get($meta, 'extra_attempts', 0);
    }

    /**
     * The quiz's time limit in seconds, or 0 for no limit.
     *
     * @param \FluentCommunity\Modules\Course\Model\CourseLesson $quiz
     * @return int
     */
    public static function timeLimit($quiz)
    {
        $meta = (array) $quiz->meta;
        if (Arr::get($meta, 'enable_time_limit') !== 'yes') {
            return 0;
        }

        return min(600, max(1, (int) Arr::get($meta, 'time_limit', 1))) * MINUTE_IN_SECONDS;
    }

    /**
     * The student's running attempt on a timed quiz, or null when none runs. An attempt
     * whose time and grace ran out no longer runs, but it still counts: the next start
     * returns it, so the browser submits it as over time.
     *
     * @param int                                                $userId
     * @param \FluentCommunity\Modules\Course\Model\CourseLesson $quiz
     * @return array|null started_at, deadline and now, as Unix timestamps
     */
    public static function runningTimer($userId, $quiz)
    {
        $timer = self::timer($userId, $quiz);
        if (!$timer || time() > $timer['deadline'] + self::GRACE_SECONDS) {
            return null;
        }

        return $timer;
    }

    /**
     * Starts the timer, or returns the one already started, so a reload does not reset it.
     * An expired timer is returned as it is: starting again must not give the student
     * new time on questions they have already seen. Only a submit clears it.
     *
     * @return array|null See runningTimer(); null for a quiz without a time limit
     */
    public static function start($userId, $quiz)
    {
        if (!self::timeLimit($quiz)) {
            return null;
        }

        $timer = self::timer($userId, $quiz);
        if ($timer) {
            return $timer;
        }

        update_user_meta($userId, self::startKey($quiz), time());

        return self::timer($userId, $quiz);
    }

    /**
     * The student's started attempt, expired or not.
     *
     * @return array|null
     */
    private static function timer($userId, $quiz)
    {
        $limit = self::timeLimit($quiz);
        $startedAt = $userId ? (int) get_user_meta($userId, self::startKey($quiz), true) : 0;
        if (!$limit || !$startedAt) {
            return null;
        }

        return [
            'started_at' => $startedAt,
            'deadline'   => $startedAt + $limit,
            'now'        => time(),
        ];
    }

    /**
     * Ends the student's attempt on a timed quiz: the time it took, and whether it went past
     * the limit plus the grace. A submit without a start (the browser skipped it) counts as
     * over time, since nothing shows when it began.
     *
     * @return array|null time_taken (seconds, or null without a start) and over_time; null for a quiz without a time limit
     */
    public static function finish($userId, $quiz)
    {
        $limit = self::timeLimit($quiz);
        if (!$limit) {
            return null;
        }

        $startedAt = (int) get_user_meta($userId, self::startKey($quiz), true);
        delete_user_meta($userId, self::startKey($quiz));

        if (!$startedAt) {
            return [ 'time_taken' => null, 'over_time' => true ];
        }

        $timeTaken = max(0, time() - $startedAt);

        return [
            'time_taken' => $timeTaken,
            'over_time'  => $timeTaken > $limit + self::GRACE_SECONDS,
        ];
    }

    private static function startKey($quiz)
    {
        return '_fcom_quiz_started_' . $quiz->id;
    }
}
