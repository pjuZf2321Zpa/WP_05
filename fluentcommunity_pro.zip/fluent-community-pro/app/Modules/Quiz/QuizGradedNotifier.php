<?php

namespace FluentCommunityPro\App\Modules\Quiz;

use FluentCommunity\App\Models\Notification;
use FluentCommunity\App\Models\User;
use FluentCommunity\App\Services\Helper;
use FluentCommunity\App\Services\Libs\EmailComposer;
use FluentCommunity\App\Services\Libs\Mailer;
use FluentCommunity\Modules\Course\Model\CourseLesson;

/**
 * Tells the student when an instructor has finished grading their quiz: a portal notification
 * and an email with the score and a link back to the quiz.
 */
class QuizGradedNotifier
{
    public function register()
    {
        add_action('fluent_community/quiz/graded', [ $this, 'notify' ], 10, 3);
    }

    /**
     * @param QuizModel    $result
     * @param CourseLesson $quiz
     * @param int          $graderId
     */
    public function notify($result, $quiz, $graderId)
    {
        $user = User::find($result->user_id);
        if (!$user) {
            return;
        }

        $course = $quiz->course;
        $route = [
            'name'   => 'view_lesson',
            'params' => [
                'course_slug' => $course ? $course->slug : '',
                'lesson_slug' => $quiz->slug,
            ],
        ];

        $content = sprintf(
            /* translators: 1: quiz title, 2: score in percent */
            __('Your answers in %1$s have been graded. Your score is %2$s.', 'fluent-community-pro'),
            '<b>' . esc_html($quiz->title) . '</b>',
            '<b>' . (int) $result->score . '%</b>'
        );

        $notification = Notification::create([
            'feed_id'         => $quiz->id,
            'object_id'       => $result->id,
            'src_user_id'     => (int) $graderId,
            'src_object_type' => 'quiz_result',
            'action'          => 'quiz/graded',
            'content'         => $content,
            'route'           => $route,
        ]);
        $notification->subscribe([ (int) $result->user_id ]);

        /**
         * Send the "your quiz was graded" email.
         *
         * @param bool      $send
         * @param QuizModel $result
         */
        if (!apply_filters('fluent_community/quiz/send_graded_email', true, $result) || Helper::isUndeliverableEmail($user->user_email)) {
            return;
        }

        $subject = sprintf(
            /* translators: %s: quiz title */
            __('Your quiz has been graded: %s', 'fluent-community-pro'),
            $quiz->title
        );

        $statusLine = '';
        if ($result->status === 'passed') {
            $statusLine = __('You passed.', 'fluent-community-pro');
        } elseif ($result->status === 'failed') {
            $statusLine = __('You did not pass this time. You can take the quiz again.', 'fluent-community-pro');
        }

        $composer = new EmailComposer();
        $composer->addBlock('paragraph', esc_html(sprintf(
            /* translators: 1: quiz title, 2: score in percent */
            __('Your instructor has graded your answers in %1$s. Your score is %2$s%%.', 'fluent-community-pro'),
            $quiz->title,
            (int) $result->score
        )));
        $composer->addBlock('paragraph', esc_html($statusLine));
        $composer->addBlock('button', esc_html__('See your result', 'fluent-community-pro'), [ 'link' => $quiz->getPermalink() ]);
        $composer->setDefaultLogo();
        $composer->setDefaultFooter(false);

        (new Mailer('', $subject, $composer->getHtml()))
            ->to($user->user_email, $user->display_name)
            ->send();
    }
}
