<?php

namespace FluentCommunityPro\App\Modules\Quiz;

use FluentCommunity\Framework\Support\Arr;
use FluentCommunity\App\Services\FeedsHelper;
use FluentCommunity\App\Services\Helper;

class QuizModule
{
    private $savedOptionImages = [];

    private $activatedOptionImages = [];

    public function register($app)
    {
        $app->router->group(function ($router) {
            require_once __DIR__ . '/Http/quiz_api.php';
        });

        (new QuizGradedNotifier())->register();

        add_filter('fluent_community/portal_vars', function ($vars) {
            $vars['question_types'] = QuizHelper::getQuestionTypes();
            return $vars;
        });

        add_filter('fluent_community/lesson/create_data', [ $this, 'handleLessonCreateData' ], 10, 2);

        add_filter('fluent_community/lesson/update_data', [ $this, 'handleLessonUpdateData' ], 10, 2);

        add_filter('fluent_community/lesson/get_public_meta', [ $this, 'handleLessonPublicMeta' ], 10, 2);

        add_filter('fluent_community/lesson/sanitize_meta', [ $this, 'handleLessonSanitizeMeta' ], 10, 2);

        add_filter('fluent_community/course_info', [ $this, 'maybeAddQuizRoute' ], 10, 1);

        add_filter('fluent_community/is_allowed_to_complete_lesson', [ $this, 'isAllowedToCompleteLesson' ], 10, 2);
    }

    public function handleLessonCreateData($data, $request)
    {
        if ($request->getSafe('type') === 'quiz') {
            $data['content_type'] = 'quiz';
        }

        return $data;
    }

    public function handleLessonUpdateData($data, $lesson)
    {
        if (!$lesson->isQuizType() || empty($data['message'])) {
            return $data;
        }

        $data['message_rendered'] = wp_kses_post(FeedsHelper::mdToHtml($data['message']));

        return $data;
    }

    public function handleLessonPublicMeta($meta, $lesson)
    {
        if (!$lesson->isQuizType() || empty($meta['quiz_questions'])) {
            return $meta;
        }

        $userId = get_current_user_id();
        $hasAttempted = $userId && QuizModel::where('user_id', $userId)
            ->where('post_id', $lesson->id)
            ->exists();
        $hideResult = Arr::isTrue($meta, 'hide_result');
        $hideAnswerInfo = !$hasAttempted || $hideResult;

        // A timed quiz shows its questions only once the student starts the timer
        if (!$hasAttempted && QuizLimits::timeLimit($lesson) && !QuizLimits::runningTimer($userId, $lesson)) {
            $meta['question_count'] = count(array_filter($meta['quiz_questions'], function ($question) {
                return Arr::isTrue($question, 'enabled');
            }));
            $meta['quiz_questions'] = [];

            return $meta;
        }

        $filteredQuestions = [];
        foreach ($meta['quiz_questions'] as $question) {
            if (!Arr::isTrue($question, 'enabled')) {
                continue;
            }
            if ($hideAnswerInfo && !empty($question['options']) && is_array($question['options'])) {
                foreach ($question['options'] as &$option) {
                    if (isset($option['is_correct'])) {
                        unset($option['is_correct']);
                    }
                }
                unset($option);
            }
            if (Arr::get($question, 'type') === 'written_answer' && isset($question['correct_answers'])) {
                unset($question['correct_answers']);
            }
            $question = QuizHelper::hideAnswerKey($question, $userId . '|' . $lesson->id);
            if ($hideAnswerInfo) {
                unset($question['explanation']);
                unset($question['explanation_rendered']);
            }
            $filteredQuestions[] = $question;
        }
        $meta['quiz_questions'] = $filteredQuestions;

        return $meta;
    }

    public function handleLessonSanitizeMeta($meta, $lesson)
    {
        if (!$lesson->isQuizType()) {
            return $meta;
        }

        $sanitizedQuestions = [];

        $quizQuestions = Arr::get($meta, 'quiz_questions', []);

        $currentQuestions = Arr::get($lesson->meta, 'quiz_questions', []);

        $this->savedOptionImages = QuizHelper::collectOptionImages($currentQuestions);
        $this->activatedOptionImages = [];

        $textFields = [ 'slug', 'help_text', 'type' ];
        $booleanFields = [ 'enabled', 'image_enabled', 'option_images' ];

        foreach ($quizQuestions as $index => $question) {
            $question['slug'] = QuizHelper::maybeGenerateQuestionSlug($quizQuestions, $question);
            $quizQuestions[$index]['slug'] = $question['slug'];

            $textValues = array_map('sanitize_text_field', Arr::only($question, $textFields));

            $booleanValues = array_map(function ($value) {
                return $value === true || $value === 'true' || $value === 1 || $value === '1';
            }, Arr::only($question, $booleanFields));

            $sanitizedQuestion = array_merge($textValues, $booleanValues);

            // Image options belong to single and multiple choice only
            if (!in_array(Arr::get($question, 'type'), [ 'single_choice', 'multiple_choice' ], true)) {
                unset($sanitizedQuestion['option_images']);
            }

            $sanitizedQuestion['points'] = QuizGrading::points($question);

            $sanitizedQuestion['label'] = wp_kses_post(Arr::get($question, 'label'));

            $sanitizedQuestion['label_rendered'] = wp_kses_post(FeedsHelper::mdToHtml($sanitizedQuestion['label']));

            $sanitizedQuestion['explanation'] = wp_kses_post(Arr::get($question, 'explanation', ''));

            $sanitizedQuestion['explanation_rendered'] = $sanitizedQuestion['explanation']
                ? wp_kses_post(FeedsHelper::mdToHtml($sanitizedQuestion['explanation']))
                : '';

            if (Arr::get($question, 'type') === 'rating_scale') {
                $sanitizedQuestion = array_merge($sanitizedQuestion, QuizGrading::sanitizeScale($question));
            } elseif (Arr::get($question, 'type') === 'written_answer') {
                $sanitizedQuestion['options'] = [];
                $gradingMode = Arr::get($question, 'grading_mode', 'open');
                $sanitizedQuestion['grading_mode'] = in_array($gradingMode, [ 'open', 'exact_match', 'manual' ], true) ? $gradingMode : 'open';
                if ($sanitizedQuestion['grading_mode'] === 'exact_match') {
                    $rawAnswers = Arr::get($question, 'correct_answers', []);
                    if (!is_array($rawAnswers)) {
                        $rawAnswers = [];
                    }
                    $sanitizedQuestion['correct_answers'] = array_values(array_unique(array_filter(
                        array_map('sanitize_text_field', $rawAnswers),
                        function ($value) {
                            return strlen((string) $value) > 0;
                        }
                    )));
                } else {
                    $sanitizedQuestion['correct_answers'] = [];
                }
            } elseif (in_array(Arr::get($question, 'type'), QuizHelper::ANSWER_KEY_TYPES, true)) {
                $sanitizedQuestion = array_merge($sanitizedQuestion, $this->sanitizeAnswerKey($question, $lesson->id));
                // Keep the author's data but take an unanswerable question out of the quiz until it is fixed.
                if (!QuizHelper::isAnswerable($sanitizedQuestion)) {
                    $sanitizedQuestion['enabled'] = false;
                }
            } else {
                $withImages = !empty($sanitizedQuestion['option_images']);
                if (isset($sanitizedQuestion['option_images'])) {
                    $sanitizedQuestion['option_images'] = $withImages;
                }

                $sanitizedQuestion['options'] = array_map(function ($option) use ($withImages, $question, $lesson) {
                    $option['label'] = sanitize_text_field(Arr::get($option, 'label'));
                    $option['is_correct'] = Arr::isTrue($option, 'is_correct');
                    // Image options: the label stays, as the caption, the alt text and the answer key
                    if ($withImages) {
                        $option['image_url'] = $this->resolveOptionImage(Arr::get($option, 'image_url'), $question['slug'], $lesson->id);
                    } else {
                        unset($option['image_url']);
                    }
                    return $option;
                }, Arr::get($question, 'options', []));
            }

            if (Arr::get($question, 'image_url')) {
                $currentImage = QuizHelper::getCurrentImage($currentQuestions, $question['slug']);
                $sanitizedQuestion['image_url'] = QuizHelper::handleMediaUrl($question['image_url'], $currentImage, $question['slug'], $lesson->id);
            }

            $sanitizedQuestions[] = $sanitizedQuestion;
        }

        QuizHelper::removeDroppedOptionImages($currentQuestions, $sanitizedQuestions, $lesson->id);

        $meta['quiz_questions'] = $sanitizedQuestions;

        return $meta;
    }

    private function sanitizeAnswerKey($question, $lessonId)
    {
        $type = Arr::get($question, 'type');
        $options = Arr::get($question, 'options', []);
        if (!is_array($options)) {
            $options = [];
        }

        if ($type === 'true_false') {
            $falseIsCorrect = false;
            foreach ($options as $option) {
                if (Arr::get($option, 'label') === 'False' && Arr::isTrue($option, 'is_correct')) {
                    $falseIsCorrect = true;
                }
            }

            return [
                'options' => [
                    [ 'label' => 'True', 'is_correct' => !$falseIsCorrect ],
                    [ 'label' => 'False', 'is_correct' => $falseIsCorrect ],
                ],
            ];
        }

        if ($type === 'fill_in_the_blank') {
            $blankText = sanitize_textarea_field(Arr::get($question, 'blank_text', ''));
            $parsed = QuizHelper::parseBlankText($blankText);

            return [
                'options'        => [],
                'blank_text'     => $blankText,
                'blanks'         => $parsed['blanks'],
                'blank_segments' => $parsed['segments'],
            ];
        }

        if ($type === 'ordering') {
            $labels = array_filter(array_map(function ($option) {
                return sanitize_text_field(Arr::get($option, 'label'));
            }, $options), function ($value) {
                return strlen((string) $value) > 0;
            });

            return [
                'options' => array_map(function ($label) {
                    return [ 'label' => $label ];
                }, array_values($labels)),
            ];
        }

        $sanitizedOptions = [];
        foreach ($options as $option) {
            $match = sanitize_text_field(Arr::get($option, 'match'));
            if ($match === '') {
                continue;
            }
            if ($type === 'image_matching') {
                $sanitizedOptions[] = [
                    'image_url' => $this->resolveOptionImage(Arr::get($option, 'image_url'), $question['slug'], $lessonId),
                    'match'     => $match,
                ];
            } else {
                $sanitizedOptions[] = [
                    'label' => sanitize_text_field(Arr::get($option, 'label')),
                    'match' => $match,
                ];
            }
        }

        $extraMatches = Arr::get($question, 'extra_matches', []);

        return [
            'options'       => $sanitizedOptions,
            'extra_matches' => is_array($extraMatches) ? array_values(array_unique(array_filter(
                array_map('sanitize_text_field', $extraMatches),
                function ($value) {
                    return strlen((string) $value) > 0;
                }
            ))) : [],
        ];
    }

    private function resolveOptionImage($url, $slug, $lessonId)
    {
        if (!$url || !is_string($url)) {
            return '';
        }

        // Saved URLs carry no media_key, so an unchanged, reordered or duplicated option is recognised by its stored URL.
        if (in_array($url, $this->savedOptionImages, true)) {
            return $url;
        }

        // A duplicated question can carry the same fresh upload twice in one save.
        if (isset($this->activatedOptionImages[$url])) {
            return $this->activatedOptionImages[$url];
        }

        $media = Helper::getMediaFromUrl($url);
        if (!$media || $media->is_active) {
            return '';
        }

        $this->activatedOptionImages[$url] = (string) QuizHelper::handleMediaUrl($url, null, $slug . '_option', $lessonId);

        return $this->activatedOptionImages[$url];
    }

    public function maybeAddQuizRoute($course)
    {
        $quizCount = QuizModel::where('parent_id', $course->id)->count();

        if ($quizCount) {
            $course->quiz_count = $quizCount;
        }

        return $course;
    }

    public function isAllowedToCompleteLesson($isAllowed, $lesson)
    {
        if (!$lesson->isQuizType() || !$lesson->passing_score || !$lesson->is_enforce_pass) {
            return $isAllowed;
        }

        $quizResult = QuizModel::where('post_id', $lesson->id)->where('user_id', get_current_user_id())->first();

        // Answers still waiting for an instructor: not passed yet
        if (!$quizResult || $quizResult->status === QuizGrading::STATUS_PENDING) {
            return false;
        }

        $quizResult = $quizResult->toArray();

        return Arr::get($quizResult, 'score', 0) >= $lesson->passing_score;
    }
}
