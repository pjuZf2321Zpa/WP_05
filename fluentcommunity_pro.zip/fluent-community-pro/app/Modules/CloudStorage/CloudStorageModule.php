<?php

namespace FluentCommunityPro\App\Modules\CloudStorage;

use FluentCommunity\Framework\Support\Arr;
use FluentCommunityPro\App\Modules\CloudStorage\BunnyCDN\BunnyCdnDriver;
use FluentCommunityPro\App\Modules\CloudStorage\S3\CloudFlareDriver;
use FluentCommunityPro\App\Modules\CloudStorage\S3\S3Driver;

class CloudStorageModule
{
    public function register($app)
    {
        add_filter('fluent_community/media_upload_data', [ $this, 'pushUploadedMedia' ]);

        add_action('fluent_community/delete_remote_media_s3', [ $this, 'deleteRemoteMedia' ]);
        add_filter('fluent_community/media_signed_public_url_s3', [ $this, 'maybeGetSignedUrl' ], 10, 4);
    }

    /**
     * Strict mode with the cloud_storage feature off: no file can reach cloud
     * storage, so every upload is rejected and its local copy deleted.
     */
    public static function registerStrictOnly()
    {
        add_filter('fluent_community/media_upload_data', [ new self(), 'rejectUploadedMedia' ]);
    }

    /**
     * @param array $mediaData
     * @return \WP_Error
     */
    public function rejectUploadedMedia($mediaData)
    {
        return $this->failUpload($mediaData['media_path'], new \WP_Error('cloud_storage_unavailable', __('File storage is not available. Please try again later.', 'fluent-community-pro')));
    }

    /**
     * Push a freshly uploaded local file to the remote driver.
     *
     * By default a failed push keeps the file on local disk (driver=local), so a
     * site keeps working while its storage is misconfigured. In strict mode (see
     * StorageHelper::isStrict()) the upload fails instead and the local copy is
     * deleted: on a server fleet with ephemeral disks, a "local" file would live
     * on one server only and vanish at its next restart.
     *
     * @param array $mediaData
     * @return array|\WP_Error
     */
    public function pushUploadedMedia($mediaData)
    {
        $strict = StorageHelper::isStrict();
        $mediaPath = $mediaData['media_path'];

        $remoteDreiver = $this->getDriver();
        if (!$remoteDreiver) {
            if ($strict) {
                return $this->failUpload($mediaPath, new \WP_Error('cloud_storage_not_configured', __('Cloud storage is required but not configured.', 'fluent-community-pro')));
            }
            unset($mediaData['acl']);
            return $mediaData;
        }

        $acl = Arr::get($mediaData, 'acl', 'public-read');

        try {
            $response = $remoteDreiver->putObject($mediaPath, $acl);
        } catch (\Exception $exception) {
            if ($strict) {
                return $this->failUpload($mediaPath, new \WP_Error('cloud_storage_upload_failed', $exception->getMessage()));
            }
            return $mediaData;
        }

        if (!$response || is_wp_error($response)) {
            if (is_wp_error($response)) {
                return $strict ? $this->failUpload($mediaPath, $response) : $response;
            }
            if ($strict) {
                return $this->failUpload($mediaPath, new \WP_Error('cloud_storage_upload_failed', __('The file could not be uploaded to cloud storage.', 'fluent-community-pro')));
            }
            return $mediaData;
        }

        $mediaData['media_path'] = $response['remote_path'];
        $mediaData['media_url'] = $response['public_url'];
        $mediaData['driver'] = 's3';

        unset($mediaData['acl']);

        // unlink the old file now
        wp_delete_file($mediaPath);

        return $mediaData;
    }

    private function failUpload($mediaPath, \WP_Error $error)
    {
        wp_delete_file($mediaPath);
        do_action('fluent_community/cloud_storage_upload_failed', $mediaPath, $error);
        return $error;
    }

    public function deleteRemoteMedia($media)
    {
        $remoteDreiver = $this->getDriver();
        if (!$remoteDreiver) {
            return;
        }

        if (!$this->isStoredBy($remoteDreiver, $media)) {
            $result = new \WP_Error('remote_driver_mismatch', __('The file is stored with a different storage provider or bucket than the one configured now.', 'fluent-community-pro'), []);
            do_action('fluent_community/remote_media_delete_failed', $media, $result);
            return $result;
        }

        try {
            $result = $remoteDreiver->deleteObject($media->media_path);
        } catch (\Exception $exception) {
            $result = new \WP_Error('remote_delete_failed', $exception->getMessage(), []);
        }

        if (is_wp_error($result)) {
            do_action('fluent_community/remote_media_delete_failed', $media, $result);
        }

        return $result;
    }

    /**
     * Every remote file is saved with driver 's3', so the provider and bucket that hold
     * it are known only from its media_path prefix (bunny://, r2://, s3://).
     */
    private function isStoredBy($remoteDriver, $media)
    {
        return strpos((string)$media->media_path, $remoteDriver->getRemotePath('')) === 0;
    }

    public function getDriver()
    {
        return $this->getConnectionDriver();
    }

    public function getConnectionDriver($config = null)
    {
        if (!$config) {
            $config = StorageHelper::getConfig();
        }

        $driver = $config['driver'];
        if (!$driver) {
            return null;
        }


        switch ($driver):
            case 'local':
                return null;
            case 'cloudflare_r2':
                return $this->cloudflareDriver($config);
            case 'amazon_s3':
                return $this->s3Driver($config);
            case 'bunny_cdn':
                return $this->bunnyCdnDriver($config);
            default:
                return null;
        endswitch;
    }

    private function cloudflareDriver($config = null)
    {
        if (!$config) {
            $config = StorageHelper::getConfig();
        }

        $bucket = '';
        $endPoint = '';
        if (!empty($config['endpoint_url'])) {
            $url = explode('/', rtrim($config['endpoint_url'], '/'));
            $len = count($url);
            if (!empty($url[$len - 1])) {
                $bucket = $url[$len - 1];
            }
            if (!empty($url[$len - 2])) {
                $endPoint = $url[$len - 2];
            }
        }

        if (
            empty($config['access_key']) ||
            empty($config['secret_key']) ||
            empty($config['public_url']) ||
            empty($bucket) || empty($endPoint) ||
            $config['driver'] !== 'cloudflare_r2'
        ) {
            return null;
        }

        $driver = (new CloudFlareDriver($config['access_key'], $config['secret_key'], $endPoint, $bucket))
            ->setPublicUrl($config['public_url']);

        if (!empty($config['sub_folder'])) {
            $driver = $driver->setSubFolder($config['sub_folder']);
        }

        return $driver;
    }

    private function bunnyCdnDriver($config = null)
    {
        if (!$config) {
            $config = StorageHelper::getConfig();
        }

        if (
            empty($config['access_key']) ||
            empty($config['s3_endpoint']) ||
            empty($config['bucket']) ||
            $config['driver'] !== 'bunny_cdn'
        ) {
            return null;
        }

        $apiUrl = "https://" . $config['s3_endpoint'] . '/' . $config['bucket'];

        $driver = (new BunnyCdnDriver($config['access_key'], $apiUrl, $config['bucket']))
            ->setPublicUrl(Arr::get($config, 'public_url'));

        return $driver;
    }

    private function s3Driver($config = null)
    {
        if (!$config) {
            $config = StorageHelper::getConfig();
        }

        if (
            empty($config['access_key']) ||
            empty($config['secret_key']) ||
            !isset($config['bucket']) ||
            $config['driver'] !== 'amazon_s3'
        ) {
            return null;
        }

        $endPoint = defined('FLUENT_COMMUNITY_CLOUD_STORAGE_ENDPOINT') ? FLUENT_COMMUNITY_CLOUD_STORAGE_ENDPOINT : '';

        if (!$endPoint) {
            $endPoint = Arr::get($config, 's3_endpoint');
        }

        $region = defined('FLUENT_COMMUNITY_CLOUD_STORAGE_REGION') ? FLUENT_COMMUNITY_CLOUD_STORAGE_REGION : '';

        if (!$endPoint) {
            if ($region) {
                $endPoint = 's3-' . $region . '.amazonaws.com';
            } else {
                $endPoint = 's3.amazonaws.com';
            }
        }

        if (!$region && $endPoint !== 's3.amazonaws.com') {
            $parts = explode('.', $endPoint);
            $region = substr($parts[0], 3);
        }

        $driver = new S3Driver($config['access_key'], $config['secret_key'], $endPoint, $config['bucket'], $region);

        if (!empty($config['sub_folder'])) {
            $driver = $driver->setSubFolder($config['sub_folder']);
        }

        return $driver;
    }

    public function maybeGetSignedUrl($url, $media, $expires = 3600, $args = [])
    {
        $remoteDriver = $this->getDriver();
        if (!$remoteDriver || !$this->isStoredBy($remoteDriver, $media)) {
            return $url;
        }

        $signedUrl = $remoteDriver->getSignedUrl($media->media_path, $expires, $media, $args);

        if (!$signedUrl || is_wp_error($signedUrl)) {
            return $url;
        }

        return $signedUrl;
    }
}
