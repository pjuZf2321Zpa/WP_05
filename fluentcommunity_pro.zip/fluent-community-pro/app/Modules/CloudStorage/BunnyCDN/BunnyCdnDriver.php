<?php

namespace FluentCommunityPro\App\Modules\CloudStorage\BunnyCDN;


use FluentCommunity\Framework\Support\Arr;

class BunnyCdnDriver
{

    protected $accessKey;

    protected $endpoint;

    protected $bucket;

    protected $publicUrl;

    public function __construct($accessKey, $endPoint, $bucket)
    {
        $this->bucket = $bucket;
        $this->accessKey = $accessKey;
        $this->endpoint = $endPoint;
    }

    public function getDriverName()
    {
        return 'bunny_cdn';
    }

    public function getDriver()
    {
        return $this;
    }

    public function setPublicUrl($url)
    {
        $this->publicUrl = $url;
        return $this;
    }

    public function putObject($mediaPath, $acl = 'public-read')
    {
        $fileName = basename($mediaPath);
        $publicUrl = $this->getPublicUrl($fileName);

        if (is_wp_error($publicUrl)) {
            return $publicUrl;
        }

        $response = $this->uploadFileRequest($mediaPath, $fileName);

        if (!$this->isSuccessful($response)) {
            return new \WP_Error('bunnycdn_error', __('Error uploading file to BunnyCDN', 'fluent-community-pro'), $response);
        }

        return [
            'public_url'  => $publicUrl,
            'remote_path' => $this->getRemotePath($fileName),
        ];
    }

    public function getPublicUrl($objectName)
    {
        if (!$this->publicUrl) {
            return new \WP_Error('public_url_not_set', 'Public URL not set', []);
        }

        return $this->publicUrl . '/' . $objectName;
    }

    public function getSignedUrl($path, $ttl = 3600, $media = null)
    {
        return null;
    }

    public function getRemotePath($objectName)
    {
        return 'bunny://' . str_replace('https://', '', $this->endpoint) . '/' . $objectName;
    }

    public function deleteObject($path)
    {
        // check if it stats with r2://
        if (strpos($path, 'bunny://') !== 0) {
            return new \WP_Error('invalid_path', 'Invalid path', []);
        }

        $response = $this->deleteFileReguest($path);

        if (!$this->isSuccessful($response)) {
            return new \WP_Error('bunnycdn_error', 'Error deleting file from BunnyCDN', $response);
        }

        return true;
    }

    public function testConnection()
    {
        $response = $this->listFiles();

        if (!$this->isSuccessful($response)) {
            return new \WP_Error('bunnycdn_error', 'Error connecting to BunnyCDN', $response);
        }

        return true;
    }

    private function isSuccessful($response)
    {
        $code = (int)Arr::get($response, 'code');

        return $code >= 200 && $code < 300;
    }

    private function uploadFileRequest($filePath, $fileName)
    {
        $url = $this->endpoint . '/' . $fileName;

        if (!function_exists('curl_init')) {
            return $this->bufferedUploadRequest($url, $filePath);
        }

        $failed = array(
            'code' => 0,
            'body' => '',
        );

        if (!wp_http_validate_url($url)) {
            return $failed;
        }

        $fileHandle = fopen($filePath, 'rb'); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen

        if (!$fileHandle) {
            return $failed;
        }

        $curl = curl_init($url); // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_init
        curl_setopt_array($curl, array( // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_setopt_array
            CURLOPT_UPLOAD          => true,
            CURLOPT_INFILE          => $fileHandle,
            CURLOPT_INFILESIZE      => filesize($filePath),
            CURLOPT_HTTPHEADER      => array(
                'AccessKey: ' . $this->accessKey,
                'Content-Type: application/octet-stream',
                'Expect:',
            ),
            CURLOPT_RETURNTRANSFER  => true,
            CURLOPT_PROTOCOLS       => CURLPROTO_HTTPS,
            CURLOPT_FOLLOWLOCATION  => false,
            CURLOPT_CONNECTTIMEOUT  => 15,
            CURLOPT_LOW_SPEED_LIMIT => 1024,
            CURLOPT_LOW_SPEED_TIME  => 60,
            CURLOPT_SSL_VERIFYPEER  => (bool)apply_filters('https_ssl_verify', true, $url), // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound
            CURLOPT_CAINFO          => ABSPATH . WPINC . '/certificates/ca-bundle.crt',
        ));

        $body = curl_exec($curl); // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_exec
        $code = (int)curl_getinfo($curl, CURLINFO_RESPONSE_CODE); // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_getinfo

        curl_close($curl); // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_close
        fclose($fileHandle); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose

        return array(
            'code' => $code,
            'body' => is_string($body) ? $body : '',
        );
    }

    private function bufferedUploadRequest($url, $filePath)
    {
        $response = wp_safe_remote_request($url, array(
            'method'  => 'PUT',
            'timeout' => 60,
            'headers' => array(
                'AccessKey'    => $this->accessKey,
                'Content-Type' => 'application/octet-stream',
            ),
            'body'    => file_get_contents($filePath), // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
        ));

        return array(
            'code' => wp_remote_retrieve_response_code($response),
            'body' => wp_remote_retrieve_body($response),
        );
    }

    private function deleteFileReguest($remoteFilePath)
    {
        $remoteFilePath = str_replace('bunny://', 'https://', $remoteFilePath);

        $args = array(
            'method'      => 'DELETE',
            'timeout'     => 60,
            'redirection' => 5,
            'httpversion' => '1.0',
            'blocking'    => true,
            'headers'     => array(
                'AccessKey' => $this->accessKey,
            ),
        );

        $response = wp_safe_remote_request($remoteFilePath, $args);

        $code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);

        return array(
            'code' => $code,
            'body' => $body,
        );
    }

    private function listFiles()
    {
        $url = $this->endpoint . '/';

        $args = array(
            'method'      => 'GET',
            'timeout'     => 60,
            'redirection' => 5,
            'httpversion' => '1.0',
            'blocking'    => true,
            'headers'     => array(
                'AccessKey'    => $this->accessKey,
                'Content-Type' => 'application/json',
            ),
        );

        $response = wp_safe_remote_request($url, $args);

        $code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);

        return array(
            'code' => $code,
            'body' => $body,
        );
    }
}
