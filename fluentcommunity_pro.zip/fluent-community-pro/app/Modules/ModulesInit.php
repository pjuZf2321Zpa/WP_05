<?php

namespace FluentCommunityPro\App\Modules;

use FluentCommunity\App\Functions\Utility;

class ModulesInit
{
    public function register($app)
    {
        add_action('fluent_community/install_messaging_plugin', function () {
            // This is a custom plugin. Need to be handled differently
            \FluentCommunityPro\App\Services\ProHelper::backgroundInstallerDirect([
                'name'      => 'Fluent Messages',
                'repo-slug' => 'fluent-messaging',
                'file'      => 'fluent-messaging.php',
            ], 'fluent-messages', 'https://fluentapi.wpmanageninja.com/addons/download/fluent-messaging/latest.zip');
        });


        add_action('fluent_community/install_fluent_player_plugin', function () {
            // This is a custom plugin. Need to be handled differently
            \FluentCommunityPro\App\Services\ProHelper::backgroundInstallerDirect([
                'name'      => 'FluentPlayer',
                'repo-slug' => 'fluent-player',
                'file'      => 'fluent-player.php',
            ], 'fluent-player', 'https://downloads.wordpress.org/plugin/fluent-player.zip');
        });

        add_action('fluent_community/install_fluent_notify_plugin', function () {
            // This is a custom plugin. Need to be handled differently
            \FluentCommunityPro\App\Services\ProHelper::backgroundInstallerDirect([
                'name'      => 'Fluent Notify',
                'repo-slug' => 'fluent-notify',
                'file'      => 'fluent-notify.php',
            ], 'fluent-notify', 'https://fluentapi.wpmanageninja.com/addons/download/fluent-notify/latest.zip');
        });

        add_action('fluent_community/install_fluent_event_plugin', function () {
            // This is a custom plugin. Need to be handled differently
            \FluentCommunityPro\App\Services\ProHelper::backgroundInstallerDirect([
                'name'      => 'FluentEvent',
                'repo-slug' => 'fluent-event',
                'file'      => 'fluent-event.php',
            ], 'fluent-event', 'https://fluentapi.wpmanageninja.com/addons/download/fluent-event/latest.zip');
        });

        $this->initModules($app);
    }

    private function initModules($app)
    {
        $features = Utility::getFeaturesConfig();

        $this->initCloudStorage($app, $features);

        (new \FluentCommunityPro\App\Modules\LeaderBoard\LeaderBoardModule())->register($app, $features);
        (new \FluentCommunityPro\App\Modules\UserBadge\UserBadgeModule())->register($app, $features);
        (new \FluentCommunityPro\App\Modules\Pwa\PwaModule())->register($app, $features);
        (new \FluentCommunityPro\App\Modules\Integrations\Integrations())->register($app);

        (new \FluentCommunityPro\App\Modules\DocumentLibrary\DocumentModule())->register($app);

        (new \FluentCommunityPro\App\Modules\MediaGallery\MediaGalleryModule())->register($app);

        (new \FluentCommunityPro\App\Modules\SpacePages\SpacePagesModule())->register($app);

        // On by default with the course module; a core without the flag counts as on
        if (isset($features['course_module']) && $features['course_module'] === 'yes' && ($features['certificates_module'] ?? 'yes') !== 'no') {
            (new \FluentCommunityPro\App\Modules\Certificates\CertificatesModule())->register($app);
        } else {
            // Off means off, verification page included; a member's certificate data can
            // still be exported and erased
            \FluentCommunityPro\App\Modules\Certificates\CertificatesModule::registerPrivacyOnly();
        }

        if (isset($features['giphy_module']) && $features['giphy_module'] === 'yes') {
            (new \FluentCommunityPro\App\Modules\Giphy\GiphyModule())->register($app);
        }

        if (isset($features['emoji_module']) && $features['emoji_module'] === 'yes') {
            (new \FluentCommunityPro\App\Modules\Emoji\EmojiModule())->register($app);
        }

        if (isset($features['invitation']) && $features['invitation'] === 'yes') {
            (new \FluentCommunity\Modules\Auth\InvitationModule())->register($app);
        }

        (new \FluentCommunityPro\App\Modules\Webhooks\WebhookModule())->register();

        (new \FluentCommunityPro\App\Modules\SeoSiteMap\SeoSiteMapHandler())->register();

        (new \FluentCommunityPro\App\Modules\Quiz\QuizModule())->register($app);
    }

    /**
     * With the cloud_storage feature off, uploads stay on local disk. In strict mode
     * (StorageHelper::isStrict()) local disk is not a place to keep files, so uploads
     * are rejected instead.
     */
    public function initCloudStorage($app, $features)
    {
        if (isset($features['cloud_storage']) && $features['cloud_storage'] === 'yes') {
            (new \FluentCommunityPro\App\Modules\CloudStorage\CloudStorageModule())->register($app);
        } elseif (\FluentCommunityPro\App\Modules\CloudStorage\StorageHelper::isStrict()) {
            \FluentCommunityPro\App\Modules\CloudStorage\CloudStorageModule::registerStrictOnly();
        }
    }
}
