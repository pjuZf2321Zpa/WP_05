<?php

/**
 * @var \FluentCommunity\Framework\Http\Router $router
 */

$router->prefix('admin/pwa-settings')->namespace('FluentCommunityPro\App\Modules\Pwa\Http\Controllers')->withPolicy(\FluentCommunity\App\Http\Policies\AdminPolicy::class)->group(function ($router) {
    $router->get('/', 'PwaController@getSettings');
    $router->post('/', 'PwaController@saveSettings');
});
