<?php

namespace FluentCommunityPro\App\Modules\Giphy\Http\Controllers;

use FluentCommunity\App\Functions\Utility;
use FluentCommunity\App\Services\Helper;
use FluentCommunity\Framework\Http\Controller;
use FluentCommunity\Framework\Http\Request\Request;
use FluentCommunity\Framework\Support\Arr;
use FluentCommunity\Framework\Support\Collection;
use FluentCommunityPro\App\Modules\Giphy\Services\GiphyService;

class GiphyController extends Controller
{
    const TRENDING_CACHE_KEY = 'fcom_giphy_trending';

    public function index(Request $request)
    {
        $giphyApi = Arr::get( Utility::getOption('fluent_community_features', []), 'giphy_api_key', '');

        if (!$giphyApi) {
            wp_send_json([
                'message' => __(
                    'Giphy API key is not set or invalid. Please set a valid API key in the giphy module.',
                    'fluent-community-pro'
                ),
            ], 400);
        }

        $giphy   = new GiphyService($giphyApi);
        $keyword = sanitize_text_field($request->get('q'));
        $offset  = intval($request->get('offset', 0));

        // The picker opens on the first trending page; it is the same for everyone.
        $isFirstTrendingPage = !$keyword && $offset === 0;
        if ($isFirstTrendingPage) {
            $cachedGifs = get_transient(self::TRENDING_CACHE_KEY);
            if (is_array($cachedGifs) && $cachedGifs) {
                return [
                    'gifs' => $cachedGifs,
                ];
            }
        }

        $user = Helper::getCurrentUser();
        if ($user) {
            try {
                do_action('fluent_community/check_rate_limit/giphy', $user);
            } catch (\Exception $e) {
                return $this->sendError([
                    'message' => $e->getMessage(),
                ], 429);
            }
        }

        $giphy->setOffset($offset);

        if ($keyword) {
            $gifs = $giphy->searchGifs($keyword);
        } else {
            $gifs = $giphy->getTrendingGifs();
        }

        if (!empty($gifs)) {
            $gifs = Collection::make($gifs)->map(function ($gif) {
                return [
                    'images' => [
                        'preview_gif'      => $gif['images']['preview_gif'],
                        'downsized_medium' => $gif['images']['downsized_medium'],
                    ],
                ];
            })->toArray();

            if ($isFirstTrendingPage) {
                set_transient(self::TRENDING_CACHE_KEY, $gifs, HOUR_IN_SECONDS);
            }
        }

        return [
            'gifs' => $gifs,
        ];
    }
}
