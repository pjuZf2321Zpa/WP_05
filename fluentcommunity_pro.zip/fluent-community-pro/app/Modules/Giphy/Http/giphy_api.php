<?php

/**
 * @var \FluentCommunity\Framework\Http\Router $router
 */

$router->prefix('giphy')->namespace('FluentCommunityPro\App\Modules\Giphy\Http\Controllers')->withPolicy(\FluentCommunityPro\App\Http\Policies\GiphyPolicy::class)->group(function ($router) {
    $router->get('/', 'GiphyController@index');
});
