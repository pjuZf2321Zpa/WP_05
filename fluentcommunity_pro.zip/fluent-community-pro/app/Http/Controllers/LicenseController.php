<?php

namespace FluentCommunityPro\App\Http\Controllers;

use FluentCommunity\App\Services\Helper;
use FluentCommunity\Framework\Http\Request\Request;
use FluentCommunityPro\App\Services\PluginManager\FluentLicensing;

class LicenseController extends Controller
{
    public function getStatus(Request $request)
    {
        $licenseManager = FluentLicensing::getInstance();

        $data = $licenseManager->getStatus(true);

        if (is_wp_error($data)) {
            return [
                'status'  => 'invalid',
                'message' => $data->get_error_message(),
            ];
        }

        return $this->formatLicenseData($data, $licenseManager);
    }

    /**
     * Shape the stored license data for the license screen: everything the UI
     * shows is resolved here so the Vue side only has to render it.
     *
     * @param array $data
     * @param FluentLicensing $licenseManager
     * @return array
     */
    protected function formatLicenseData($data, FluentLicensing $licenseManager)
    {
        $status = isset($data['status']) ? $data['status'] : 'unregistered';
        $expires = isset($data['expires']) ? $data['expires'] : '';
        $isLifetime = $expires === 'lifetime';

        // The renew URL carries the full license key. Only super admins can
        // manage the license, so nobody else gets a key-bearing link.
        if (!Helper::isSuperAdmin()) {
            $data['renew_url'] = '';
        } elseif (empty($data['renew_url']) && in_array($status, [ 'expired', 'valid' ], true)) {
            $data['renew_url'] = $licenseManager->getRenewUrl();
        }

        $data['purchase_url'] = $licenseManager->getConfig('purchase_url');
        $data['account_url'] = $licenseManager->getConfig('account_url');
        $data['support_url'] = $licenseManager->getConfig('support_url');
        $data['license_key_masked'] = $licenseManager->getMaskedLicenseKey();
        $data['product_title'] = !empty($data['product_title']) ? $data['product_title'] : $licenseManager->getConfig('plugin_title');
        $data['is_lifetime'] = $isLifetime;
        $data['expires_human'] = '';
        $data['days_remaining'] = null;
        $data['last_checked_human'] = '';

        $remoteGraceDays = isset($data['grace_period_days']) ? (int)$data['grace_period_days'] : 0;
        $data['in_grace_period'] = false;
        $data['grace_period_days'] = null;

        $expiresAt = $expires ? strtotime($expires) : false;
        if (!$isLifetime && $expiresAt) {
            $data['expires_human'] = wp_date(get_option('date_format'), $expiresAt);
            $data['days_remaining'] = (int)floor(($expiresAt - time()) / DAY_IN_SECONDS);
            $data = $this->attachGraceData($data, $expiresAt, $status, $remoteGraceDays);
        }

        $lastChecked = empty($data['last_checked']) ? false : strtotime($data['last_checked']);
        if ($lastChecked) {
            $data['last_checked_human'] = sprintf(
            /* translators: %s: human readable time difference, e.g. "2 mins" */
                __('%s ago', 'fluent-community-pro'),
                human_time_diff($lastChecked)
            );
        }

        unset($data['license_key'], $data['activation_hash']);

        return $data;
    }

    /**
     * The store keeps a license usable for a grace window after its expiry date,
     * so a renewal that lands a few days late never breaks a live site. It
     * reports that window as a plain "valid" status without saying why, which
     * reads as a contradiction on screen: an Active badge sitting next to an
     * expiry date that has already passed. Resolve the window here so the screen
     * can name it.
     *
     * Only the fact of the window is reported, never its end date: the length
     * below is our assumption about the store's default, so a date built on it
     * would be a promise we cannot keep if the store ever filters it.
     *
     * @param array $data
     * @param int $expiresAt
     * @param string $status
     * @param int $remoteGraceDays grace length the store reported, 0 when it reported none
     * @return array
     */
    protected function attachGraceData($data, $expiresAt, $status, $remoteGraceDays = 0)
    {
        if ($status !== 'valid' || $expiresAt > time()) {
            return $data;
        }

        // Prefer the store's own number when it reports one; the fallback below
        // only mirrors its current default, and the store may filter it.
        $graceDays = $remoteGraceDays;

        if ($graceDays < 1) {
            $graceDays = (int)apply_filters('fluent_community/license_grace_period_days', 15);
        }

        if ($graceDays < 1) {
            return $data;
        }

        $graceEndsAt = $expiresAt + ($graceDays * DAY_IN_SECONDS);

        if ($graceEndsAt <= time()) {
            return $data; // Window already closed - the store will report it expired.
        }

        $data['in_grace_period'] = true;
        $data['grace_period_days'] = $graceDays;

        return $data;
    }

    public function saveLicense(Request $request)
    {
        $licenseKey = $request->get('license_key');

        $licenseManager = FluentLicensing::getInstance();

        $response = $licenseManager->activate($licenseKey);

        if (is_wp_error($response)) {
            return $this->sendError([
                'message' => $response->get_error_message(),
                'remote_response' => $response,
            ]);
        }

        return [
            'license_data' => $this->formatLicenseData($licenseManager->getStatus(), $licenseManager),
            'message'      => __('Your license key has been successfully updated', 'fluent-community-pro'),
        ];
    }

    public function deactivateLicense(Request $request)
    {

        $licenseManager = FluentLicensing::getInstance();

        $response = $licenseManager->deactivate();

        if (is_wp_error($response)) {
            return $this->sendError([
                'message' => $response->get_error_message(),
            ]);
        }

        return [
            'license_data' => $this->formatLicenseData($licenseManager->getStatus(), $licenseManager),
            'message'      => __('Your license key has been successfully deactivated', 'fluent-community-pro'),
        ];
    }

}
