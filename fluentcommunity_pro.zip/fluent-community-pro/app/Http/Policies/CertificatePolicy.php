<?php

namespace FluentCommunityPro\App\Http\Policies;

use FluentCommunity\App\Services\Helper;
use FluentCommunity\Framework\Foundation\Policy;
use FluentCommunity\Framework\Http\Request\Request;
use FluentCommunity\Framework\Support\Arr;

/**
 * Course certificates. Every route has its own method; verifyRequest() refuses, so a route
 * added without a method here is closed by default.
 */
class CertificatePolicy extends Policy
{
    public function verifyRequest(Request $request)
    {
        return false;
    }

    // Templates. Course creators may list them (to pick one for their course); only
    // community and course admins design them.

    public function listTemplates(Request $request)
    {
        $user = Helper::getCurrentUser(true);

        return $user && ($user->hasCourseCreatorAccess() || $this->canManage());
    }

    public function getTemplate(Request $request, $id)
    {
        return $this->canManage();
    }

    public function createTemplate(Request $request)
    {
        return $this->canManage();
    }

    public function updateTemplate(Request $request, $id)
    {
        return $this->canManage();
    }

    public function publishTemplate(Request $request, $id)
    {
        return $this->canManage();
    }

    public function deleteTemplate(Request $request, $id)
    {
        return $this->canManage();
    }

    public function uploadImage(Request $request)
    {
        return $this->canManage();
    }

    // Issued certificates

    public function listIssued(Request $request)
    {
        return $this->canManage();
    }

    public function suspend(Request $request, $id)
    {
        return $this->canManage();
    }

    public function reinstate(Request $request, $id)
    {
        return $this->canManage();
    }

    public function revoke(Request $request, $id)
    {
        return $this->canManage();
    }

    public function reissue(Request $request, $id)
    {
        return $this->canManage();
    }

    // Manual certificates. Community and course admins only: without a course there is
    // nothing to scope a course creator to.

    public function listManual(Request $request)
    {
        return $this->canManage();
    }

    public function manualFields(Request $request)
    {
        return $this->canManage();
    }

    public function issueManual(Request $request)
    {
        return $this->canManage();
    }

    public function getManual(Request $request, $id)
    {
        return $this->canManage();
    }

    public function updateManual(Request $request, $id)
    {
        return $this->canManage();
    }

    public function lookupUser(Request $request)
    {
        return $this->canManage();
    }

    // The holder

    public function mine(Request $request)
    {
        return is_user_logged_in() && $this->canUsePortal();
    }

    public function mineDetail(Request $request, $credential)
    {
        return is_user_logged_in() && $this->canUsePortal();
    }

    public function updateVisibility(Request $request, $credential)
    {
        return is_user_logged_in() && $this->canUsePortal();
    }

    /**
     * The holder's own signed Open Badge (the controller checks ownership).
     */
    public function credential(Request $request, $credential)
    {
        return is_user_logged_in() && $this->canUsePortal();
    }

    /**
     * The portal gate here, as on core's profile routes (PortalPolicy); who may see this
     * member's profile and certificates is decided in the controller (core's profile
     * visibility, then CertificateOptions).
     */
    public function profileCertificates(Request $request, $username)
    {
        return $this->canUsePortal();
    }

    /**
     * Public on purpose: anyone holding the link or the QR code can check a certificate,
     * including on a private community. The response carries only what the certificate prints.
     */
    public function verify(Request $request, $credential)
    {
        return true;
    }

    /**
     * Public on purpose, like verify(): Open Badges wallets and verifiers fetch the issuer
     * profile, the public key and the status lists without logging in. None of them carries
     * member data (a status list is bits by certificate ID).
     */
    public function issuer(Request $request)
    {
        return true;
    }

    public function publicKey(Request $request, $kid)
    {
        return true;
    }

    public function statusList(Request $request, $listNumber)
    {
        return true;
    }

    /**
     * Public on purpose: the holder has no account to log in with. The controller checks
     * the holder token, a secret only the holder's email carries.
     */
    public function holderCredential(Request $request, $credential)
    {
        return true;
    }

    /**
     * Core's PortalPolicy::verifyRequest: an inactive (blocked) member, or a visitor on a
     * community they cannot enter, gets nothing.
     */
    private function canUsePortal()
    {
        // Not the cached copy: Helper::getCurrentProfile() keeps the first profile it loads,
        // whoever is current later in the same process
        $profile = Helper::getCurrentProfile(false);
        if ($profile && $profile->status !== 'active') {
            return false;
        }

        return (bool) Helper::canAccessPortal(get_current_user_id());
    }

    private function canManage()
    {
        if (Helper::isSiteAdmin()) {
            return true;
        }

        $user = Helper::getCurrentUser(true);
        if (!$user) {
            return false;
        }

        $permissions = $user->getPermissions(true);

        return Arr::isTrue($permissions, 'community_admin') || Arr::isTrue($permissions, 'course_admin');
    }
}
