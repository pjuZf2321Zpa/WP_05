<?php

namespace FluentCommunityPro\App\Http\Policies;

use FluentCommunity\App\Services\Helper;
use FluentCommunity\Framework\Foundation\Policy;
use FluentCommunity\Framework\Http\Request\Request;

/**
 * GIF search uses the site's Giphy key, so only active members may search.
 */
class GiphyPolicy extends Policy
{
    public function verifyRequest(Request $request)
    {
        return false;
    }

    public function index(Request $request)
    {
        $userId = get_current_user_id();
        if (!$userId) {
            return false;
        }

        $profile = Helper::getCurrentProfile();

        return $profile && $profile->status === 'active' && Helper::canAccessPortal($userId);
    }
}
