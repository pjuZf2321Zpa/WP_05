<?php

/**
 * @var \FluentCommunity\Framework\Http\Router $router
 */

$router->namespace('FluentCommunityPro\App\Http\Controllers')->group(function ($router) {
    require_once __DIR__ . '/api.php';
});
