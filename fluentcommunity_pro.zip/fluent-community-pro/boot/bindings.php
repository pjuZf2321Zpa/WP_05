<?php

/**
 * Add only the plugin specific bindings here.
 * 
 *
 * @var \FluentCommunity\Framework\Foundation\Application $app
 */
