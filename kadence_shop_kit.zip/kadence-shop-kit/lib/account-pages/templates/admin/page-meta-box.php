<?php
/**
 * Metabox template file.
 *
 * @package Iconic_WAP
 *
 * @var array<string, array{name: string}> $system_roles
 * @var array<string> $meta_roles
 */

if ( ! defined( 'ABSPATH' ) ) {
	wp_die();
}

?>
<div class="iconic-wap-metabox">
	<fieldset style="margin-top: 15px;">
		<legend><?php esc_html_e( 'Show this page for the following selected user roles:', 'kadence-shop-kit' ); ?></legend>
		<ul>
			<?php
			foreach ( $system_roles as $role_key => $system_role ) {
				$selected_role = in_array( $role_key, $meta_roles, true );
				printf( '<li><label><input type="checkbox" name="iconic_wap_user_roles[]" value="%s" %s> %s</label></li>', esc_attr( $role_key ), checked( 1, $selected_role, false ), esc_attr( $system_role['name'] ) );
			}
			?>
		</ul>
	</fieldset>
</div>
