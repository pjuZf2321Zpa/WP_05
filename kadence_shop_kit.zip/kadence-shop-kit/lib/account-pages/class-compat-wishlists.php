<?php
/**
 * Compatiblity with Iconic Wishlists plugin.
 *
 * @package Iconic_WAP
 */

if ( ! defined( 'WPINC' ) ) {
	wp_die();
}

/**
 * Class Iconic_WAP_Compat_Wishlists
 */
class Iconic_WAP_Compat_Wishlists {
	/**
	 * Run.
	 */
	public static function run(): void {
		if ( ! is_admin() ) {
			// Priority 2 because we want this function to run after Iconic_WW_Endpoints::set_endpoint() has run.
			add_action( 'template_redirect', array( __CLASS__, 'overwrite_wishlists_endpoint' ), 2 );

			// We want to manually set the 'view' query var because Wishlists expects it in Iconic_WW_Endpoints::redirect function.
			add_action( 'template_redirect', array( __CLASS__, 'maybe_set_view_var' ), 2 );

			// Priority 20 because we want this function to run after Iconic_WW_Endpoints::is_woocommerce() has run.
			add_filter( 'is_woocommerce', array( __CLASS__, 'is_woocommerce' ), 20 );
		}
	}

	/**
	 * Overwrite Wishlist's endpoint.
	 *
	 * @return void
	 */
	public static function overwrite_wishlists_endpoint() {
		if ( ! class_exists( 'Iconic_WW_Endpoints' ) || ! Iconic_WAP_Pages::is_endpoint() ) {
			return;
		}

		$url = (string) filter_input( INPUT_SERVER, 'REQUEST_URI' );

		if ( ! str_contains( $url, (string) Iconic_WW_Wishlists::get_wishlists_base_slug() ) ) {
			return;
		}

		if ( false !== strpos( $url, '/view' ) ) {
			Iconic_WW_Endpoints::$current_endpoint = 'view';
		} elseif ( false !== strpos( $url, '/find' ) ) {
			Iconic_WW_Endpoints::$current_endpoint = 'find';
		} else {
			Iconic_WW_Endpoints::$current_endpoint = 'base';
		}
	}

	/**
	 * Maybe set "View" query var.
	 *
	 * @return void
	 */
	public static function maybe_set_view_var() {
		if ( ! class_exists( 'Iconic_WW_Endpoints' ) || ! Iconic_WAP_Pages::is_endpoint() ) {
			return;
		}

		$url = (string) filter_input( INPUT_SERVER, 'REQUEST_URI' );

		if ( ! str_contains( $url, (string) Iconic_WW_Wishlists::get_wishlists_base_slug() ) ) {
			return;
		}

		$pattern = '/.*\/view\/([a-zA-Z0-9_]*)\/?/';
		$matches = array();

		preg_match( $pattern, $url, $matches );

		$view = is_array( $matches ) && count( $matches ) > 1 ? $matches[1] : false;

		if ( ! $view ) {
			return;
		}

		set_query_var( 'view', $view );
	}

	/**
	 * Don't mark account pages as WooCommerce shop page.
	 *
	 * @param bool $is_woocommerce Is it a WooCommerce shop page.
	 *
	 * @return bool
	 */
	public static function is_woocommerce( $is_woocommerce ) {
		return Iconic_WAP_Pages::is_endpoint() ? false : $is_woocommerce;
	}
}
