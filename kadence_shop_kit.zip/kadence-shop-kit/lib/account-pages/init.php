<?php
/**
 * Account Pages module initialization.
 *
 * @package Iconic_WAP
 */

/**
 * Sync the "Allow Form Tags" setting from Iconic WAP to "Kadence Woo Extras" when the module is enabled the first time.
 */
add_filter(
	'kadence_woo_extras_filter_settings',
	static function ( array $updated, array $old ): array {
		if ( array_key_exists( 'kt_account_pages', $updated ) && ! array_key_exists( 'kt_account_pages', $old ) ) {
			$wap_settings                                = (array) get_option( 'iconic_wap_settings', array() );
			$updated['kt_account_pages_allow_form_tags'] = $wap_settings['general_general_allow_form_tags'] ?? '0';
		}

		return $updated;
	},
	10,
	2
);

require_once __DIR__ . '/class-compat-wishlists.php';
require_once __DIR__ . '/class-helpers.php';
require_once __DIR__ . '/class-page-metabox.php';
require_once __DIR__ . '/class-pages.php';
require_once __DIR__ . '/iconic-woo-account-pages.php';

Iconic_Woo_Account_Pages::instance();
