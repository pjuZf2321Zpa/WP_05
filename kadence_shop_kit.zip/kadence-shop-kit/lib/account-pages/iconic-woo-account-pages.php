<?php
/**
 * Main plugin file for Account Pages module.
 *
 * @package Iconic_WAP
 */

if ( ! defined( 'WPINC' ) ) {
	wp_die();
}

/**
 * Main plugin file for Account Pages module.
 */
class Iconic_Woo_Account_Pages {
	/**
	 * Plugin name.
	 *
	 * @var string
	 */
	public static $name = 'WooCommerce Account Pages';
	/**
	 * Plugin version.
	 *
	 * @var string
	 */
	public static $version = '1.8.0.0';

	/**
	 * The singleton instance of the plugin.
	 *
	 * @var Iconic_Woo_Account_Pages|null
	 */
	private static $instance;

	/**
	 * Construct
	 */
	public function __construct() {

		Iconic_WAP_Page_Metabox::run();
		Iconic_WAP_Compat_Wishlists::run();

		add_action( 'init', array( 'Iconic_WAP_Pages', 'initiate' ) );
		add_action( 'save_post', array( 'Iconic_WAP_Helpers', 'maybe_refresh_permalinks' ) );
	}

	/**
	 * Instantiate a single instance of our plugin.
	 *
	 * @return Iconic_Woo_Account_Pages
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}
}
