<?php
/**
 * Metabox class for account pages.
 *
 * @class   Iconic_WAP_Page_Metabox
 * @package Iconic_WAP
 */

if ( ! defined( 'WPINC' ) ) {
	wp_die();
}

/**
 * Iconic_WAP_Page_Metabox class.
 */
class Iconic_WAP_Page_Metabox {

	/**
	 * Initialize class
	 */
	public static function run(): void {
		add_action( 'add_meta_boxes', array( __CLASS__, 'add_meta_boxes' ) );
		add_action( 'save_post', array( __CLASS__, 'save_meta_boxes' ) );
		add_action( 'pre_get_posts', array( __CLASS__, 'maybe_restrict_access' ) );
	}

	/**
	 * Add metabox.
	 */
	public static function add_meta_boxes(): void {
		global $post;

		$myaccount_page_id = wc_get_page_id( 'myaccount' );

		if ( empty( $post->post_parent ) || $myaccount_page_id !== $post->post_parent ) {
			return;
		}

		add_meta_box(
			'iconic_wap_meta_box',
			__( 'Account Page Settings', 'kadence-shop-kit' ),
			array( __CLASS__, 'user_role_restriction_meta_box_html' ),
			array( 'page' ),
			'side'
		);
	}

	/**
	 * Output HTML for the metabox.
	 *
	 * @param WP_Post $post The post object.
	 *
	 * @return void
	 */
	public static function user_role_restriction_meta_box_html( $post ): void {
		require_once ABSPATH . 'wp-admin/includes/user.php';

		$system_roles = get_editable_roles();
		$meta_roles   = self::get_allowed_user_roles( $post->ID );

		include __DIR__ . '/templates/admin/page-meta-box.php';
	}

	/**
	 * Save meta box.
	 *
	 * @param int $post_id Post ID.
	 *
	 * @return void
	 */
	public static function save_meta_boxes( $post_id ) {
		if ( 'page' !== get_post_type( $post_id ) || ! isset( $_POST['iconic_wap_user_roles'] ) ) {
			return;
		}

		if ( false === check_ajax_referer( 'update-post_' . $post_id, '_wpnonce', false ) ) {
			return;
		}

		$roles = filter_input( INPUT_POST, 'iconic_wap_user_roles', FILTER_DEFAULT, FILTER_REQUIRE_ARRAY );
		update_post_meta( $post_id, 'iconic_wap_user_roles', $roles );
	}

	/**
	 * Get user roles for the page. If pages role is present
	 * in the meta then return it else return all site roles.
	 *
	 * @param int $page_id Page ID.
	 *
	 * @return array<string> $roles User Roles.
	 */
	public static function get_allowed_user_roles( $page_id ) {
		require_once ABSPATH . 'wp-admin/includes/user.php';

		/** @var array<string> $meta_roles */
		$meta_roles = get_post_meta( $page_id, 'iconic_wap_user_roles', true );
		$all_roles  = array_keys( get_editable_roles() );
		return ! empty( $meta_roles ) ? $meta_roles : $all_roles;
	}

	/**
	 * Prevent user roles from accessing the restricted pages.
	 *
	 * @param WP_Query $query WP Query.
	 *
	 * @return void
	 */
	public static function maybe_restrict_access( $query ) {
		if ( ! $query->is_page() || ! $query->is_main_query() ) {
			return;
		}

		/** @var int|numeric-string|string $page_id */
		$page_id = $query->get( 'iconic_wap_endpoint' );

		if ( empty( $page_id ) ) {
			return;
		}

		if ( Iconic_WAP_Pages::is_page_allowed_for_user_role( (int) $page_id ) ) {
			return;
		}

		$query->set_404();
	}
}
