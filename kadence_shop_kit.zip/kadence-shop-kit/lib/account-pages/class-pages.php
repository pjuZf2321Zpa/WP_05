<?php
/**
 * Account pages related functions.
 *
 * @package Iconic_WAP.
 */

if ( ! defined( 'WPINC' ) ) {
	wp_die();
}

/**
 * Class Iconic_WAP_Pages
 */
class Iconic_WAP_Pages {
	/**
	 * Query variable name.
	 *
	 * @var string
	 */
	protected static $query_var = 'iconic_wap_endpoint';

	/**
	 * Run class.
	 */
	public static function initiate(): void {
		$subpages = Iconic_WAP_Helpers::get_account_subpages();

		if ( empty( $subpages ) ) {
			return;
		}

		add_filter( 'woocommerce_account_menu_items', array( __CLASS__, 'account_menu_items' ), 10, 1 );
		add_filter( 'woocommerce_account_menu_item_classes', array( __CLASS__, 'account_menu_item_classes' ), 10, 2 );
		add_filter( 'the_title', array( __CLASS__, 'the_title' ), 10, 2 );
		add_filter( 'query_vars', array( __CLASS__, 'register_query_var' ), 10, 1 );
		add_action( 'woocommerce_account_' . self::$query_var . '_endpoint', array( __CLASS__, 'endpoint_content' ) );
		add_action( 'template_redirect', array( __CLASS__, 'prevent_endpoint_indexing' ) );
		add_action( 'template_redirect', array( __CLASS__, 'restrict_access' ) );
		add_filter( 'woocommerce_get_breadcrumb', array( __CLASS__, 'get_breadcrumb' ) );
		self::add_my_account_endpoints();
	}

	/**
	 * Account menu items.
	 *
	 * @param array<string, string> $items Menu items.
	 *
	 * @return array<string, string>
	 */
	public static function account_menu_items( $items ) {
		$subpages    = Iconic_WAP_Helpers::get_account_subpages();
		$logout_item = isset( $items['customer-logout'] ) ? $items['customer-logout'] : false;

		foreach ( $subpages as $subpage ) {
			if ( ! self::is_visible( $subpage->post_name ) ) {
				continue;
			}

			if ( ! self::is_page_allowed_for_user_role( $subpage->ID ) ) {
				continue;
			}

			$items[ $subpage->post_name ] = $subpage->post_title;
		}

		if ( $logout_item ) {
			unset( $items['customer-logout'] );
			$items['customer-logout'] = $logout_item;
		}

		return $items;
	}

	/**
	 * Account menu item classes.
	 *
	 * @param array<string> $classes Menu item classes.
	 * @param string        $endpoint Endpoint.
	 *
	 * @return array<string>
	 */
	public static function account_menu_item_classes( $classes, $endpoint ) {
		/** @var int|numeric-string $endpoint_id */     $endpoint_id = get_query_var( self::$query_var );

		if ( ! $endpoint_id ) {
			return $classes;
		}

		$endpoint_slug = get_post_field( 'post_name', (int) $endpoint_id );

		if ( $endpoint_slug !== $endpoint ) {
			return $classes;
		}

		$classes[] = 'is-active';

		return $classes;
	}

	/**
	 * Add endpoint.
	 */
	protected static function add_my_account_endpoints(): void {
		$subpages = Iconic_WAP_Helpers::get_account_subpages();
		/** @var int|numeric-string $account_page_id */
		$account_page_id   = get_option( 'woocommerce_myaccount_page_id' );
		$account_page_path = get_page_uri( (int) $account_page_id );

		if ( empty( $subpages ) ) {
			return;
		}

		foreach ( $subpages as $subpage ) {
			$uri      = sprintf( '%s/%s', $account_page_path, $subpage->post_name );
			$redirect = sprintf( 'index.php?page_id=%d&%s=%d', (int) $account_page_id, self::$query_var, $subpage->ID );

			add_rewrite_rule( $uri, $redirect, 'top' );
		}

		/** @var string|false $version */
		$version = get_option( 'iconic_wap_rewrite_rule' );
		if ( version_compare( (string) $version, KADENCE_WOO_EXTRAS_VERSION, '<' ) ) {
			flush_rewrite_rules();
			update_option( 'iconic_wap_rewrite_rule', KADENCE_WOO_EXTRAS_VERSION );
		}
	}

	/**
	 * Register query var.
	 *
	 * @param array<string> $vars Query vars.
	 *
	 * @return array<string>
	 */
	public static function register_query_var( $vars ) {
		$vars[] = self::$query_var;

		return $vars;
	}

	/**
	 * Output endpoint content.
	 */
	public static function endpoint_content(): void {
		$current_endpoint_page = self::get_current_endpoint_page_object();

		if ( ! $current_endpoint_page ) {
			return;
		}

		/**
		 * Whether or not to filter the content HTML.
		 *
		 * Only set this filter to `false` if you understand
		 * the risks associated with outputting unfiltered
		 * HTML on your site, whether added by administrators
		 * or 3rd party plugins.
		 *
		 * @since 1.5.0
		 * @param bool $filter True to filter, false to output unfiltered.
		 *
		 * @return bool
		 */
		$filter_content_html = apply_filters( 'iconic_wap_filter_content_html', true );
		/**
		 * Apply the_content filters to the endpoint page content.
		 *
		 * @since 3.0.0
		 */
		$content = apply_filters( 'the_content', $current_endpoint_page->post_content ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingSinceVersionComment

		if ( $filter_content_html ) {
			$allowed_tags = self::get_allowed_tags();

			echo wp_kses( $content, $allowed_tags ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment
		} else {
			echo $content; //phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
	}

	/**
	 * Get allowed tags.
	 *
	 * @return array<string, array<string, bool>>
	 */
	public static function get_allowed_tags() {
		global $allowedposttags;

		$allowed_tags = array_merge(
			$allowedposttags,
			array(
				'iframe' => array(
					'id'              => true,
					'title'           => true,
					'frameborder'     => true,
					'src'             => true,
					'allow'           => true,
					'allowfullscreen' => true,
					'width'           => true,
					'height'          => true,
				),
				'form'   => array(
					'id'           => true,
					'class'        => true,
					'action'       => true,
					'method'       => true,
					'enctype'      => true,
					'novalidate'   => true,
					'data-options' => true,
					'autocomplete' => true,
					'name'         => true,
				),
				'input'  => array(
					'name'  => true,
					'id'    => true,
					'value' => true,
				),
			)
		);

		if ( KWE_Options::get_instance()->get( 'kt_account_pages_allow_form_tags', false ) ) {
			$form_tags = array(
				'input'    => array(
					'type'         => true,
					'name'         => true,
					'class'        => true,
					'id'           => true,
					'value'        => true,
					'placeholder'  => true,
					'autocomplete' => true,
				),
				'select'   => array(
					'name'         => true,
					'class'        => true,
					'id'           => true,
					'autocomplete' => true,
					'style'        => true,
				),
				'option'   => array(
					'value'    => true,
					'selected' => true,
					'disabled' => true,
				),
				'textarea' => array(
					'name'         => true,
					'class'        => true,
					'id'           => true,
					'placeholder'  => true,
					'autocomplete' => true,
					'style'        => true,
				),
				'button'   => array(
					'type'  => true,
					'name'  => true,
					'class' => true,
					'id'    => true,
					'style' => true,
					'value' => true,
				),
				'script'   => array(
					'type'  => true,
					'src'   => true,
					'async' => true,
					'defer' => true,
				),
				'div'      => array(
					'class' => true,
					'id'    => true,
					'style' => true,
				),
				'style'    => array(
					'type' => true,
				),
			);

			$allowed_tags = array_merge( $allowed_tags, $form_tags );
		}

		/**
		 * Tags allowed in the Account page content.
		 *
		 * @since 1.3.0
		 */
		return apply_filters( 'iconic_wap_content_kses_allowed_tags', $allowed_tags );
	}

	/**
	 * Change endpoint title.
	 *
	 * @param string $title  Title.
	 * @param int    $post_id Post ID.
	 *
	 * @return string
	 */
	public static function the_title( $title, $post_id = null ) {
		if ( ! $post_id ) {
			global $post;

			$post_id = $post->ID;
		}

		$woo_account_page_id = Iconic_WAP_Helpers::get_myaccount_page_id();

		if ( is_admin() || $post_id !== $woo_account_page_id || ! in_the_loop() ) {
			return $title;
		}

		$endpoint = self::get_current_endpoint_page_object();

		if ( ! $endpoint ) {
			return $title;
		}

		return $endpoint->post_title;
	}

	/**
	 * Get current endpoint page object.
	 *
	 * @return false|WP_Post
	 */
	protected static function get_current_endpoint_page_object() {
		$endpoint_id = self::is_endpoint();

		if ( ! $endpoint_id ) {
			return false;
		}

		$endpoint_post = get_post( $endpoint_id );

		if ( is_null( $endpoint_post ) || ! is_a( $endpoint_post, 'WP_Post' ) ) {
			return false;
		}

		return $endpoint_post;
	}

	/**
	 * Is endpoint.
	 *
	 * @return false|int
	 */
	public static function is_endpoint() {
		/** @var int|numeric-string|string $endpoint_id */
		$endpoint_id = get_query_var( self::$query_var );

		if ( ! $endpoint_id ) {
			return false;
		}

		return (int) $endpoint_id;
	}

	/**
	 * No index endpoints.
	 *
	 * @since 1.0.2
	 */
	public static function prevent_endpoint_indexing(): void {
		if ( ! self::is_endpoint() ) {
			return;
		}

		if ( ! headers_sent() ) {
			header( 'X-Robots-Tag: noindex' );
		}
	}

	/**
	 * Restrict access.
	 *
	 * @since 1.0.2
	 */
	public static function restrict_access(): void {
		if ( ! self::is_endpoint() ) {
			return;
		}

		if ( is_user_logged_in() ) {
			return;
		}

		wp_safe_redirect( wc_get_page_permalink( 'myaccount' ) );
		exit;
	}

	/**
	 * Add page to breadcrumbs.
	 *
	 * @param list<array{0: string, 1: string}> $crumbs      Array of crumbs.
	 *
	 * @return list<array{0: string, 1: string}>
	 */
	public static function get_breadcrumb( $crumbs ) {
		$endpoint = self::is_endpoint();

		if ( ! $endpoint ) {
			return $crumbs;
		}

		$title    = get_the_title( $endpoint );
		$crumbs[] = array( $title, '' );

		return $crumbs;
	}

	/**
	 * Is the page visible for the current user?
	 *
	 * @param string $slug Slug.
	 *
	 * @return bool
	 */
	public static function is_visible( $slug ) {
		/**
		 * Filter the list of hidden page slugs.
		 *
		 * @since 3.0.0
		 */
		$hidden = apply_filters( 'iconic_wap_hidden_pages', array() ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingSinceVersionComment

		if ( empty( $hidden ) ) {
			return true;
		}

		return ! in_array( $slug, $hidden, true );
	}

	/**
	 * Checks if the given page is allowed for the logged-in user.
	 *
	 * @param int $page_id Sub-page ID.
	 *
	 * @return boolean $allowed Is allowed or not.
	 */
	public static function is_page_allowed_for_user_role( $page_id ) {
		$user          = wp_get_current_user();
		$allowed_roles = Iconic_WAP_Page_Metabox::get_allowed_user_roles( $page_id );
		$intersect     = array_intersect( $allowed_roles, (array) $user->roles );
		$allowed       = ! empty( $intersect );

		/**
		 * Filter whether the current user is allowed to view the page.
		 *
		 * @since 3.0.0
		 */
		return apply_filters( 'iconic_wap_page_allowed_for_user', $allowed, $page_id, $user, $allowed_roles ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingSinceVersionComment
	}
}
