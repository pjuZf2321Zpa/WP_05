<?php
/**
 * Helper functions for Iconic WooCommerce Account Pages.
 *
 * @package Iconic_WAP.
 */

if ( ! defined( 'WPINC' ) ) {
	wp_die();
}

/**
 * Class Iconic_WAP_Helpers
 */
class Iconic_WAP_Helpers {
	/**
	 * Get subpages of My Account.
	 *
	 * @return array<WP_Post>
	 */
	public static function get_account_subpages() {
		static $subpages = array();

		if ( ! empty( $subpages ) ) {
			return $subpages;
		}

		$woo_account_page_id = self::get_myaccount_page_id();

		$args = array(
			'post_type'      => 'page',
			'posts_per_page' => - 1,
			'post_parent'    => $woo_account_page_id,
			'orderby'        => 'menu_order title',
			'order'          => 'ASC',
		);

		$account_subpages_query = new WP_Query( $args );

		if ( ! $account_subpages_query->have_posts() ) {
			/** @var array<WP_Post> $subpages */
			return $subpages;
		}

		/** @var array<WP_Post> $subpages */
		$subpages = $account_subpages_query->posts;

		return $subpages;
	}

	/**
	 * Get my account page ID.
	 *
	 * @return int|null
	 */
	public static function get_myaccount_page_id() {
		static $woo_account_page_id = null;

		if ( is_null( $woo_account_page_id ) ) {
			/** @var int|numeric-string $woo_account_page_id */
			$woo_account_page_id = get_option( 'woocommerce_myaccount_page_id' );
		}

		return (int) $woo_account_page_id;
	}

	/**
	 * Refresh permalinks if current post is child of my account page.
	 *
	 * @param int $post_id Post ID.
	 */
	public static function maybe_refresh_permalinks( $post_id ): void {
		if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
			return;
		}

		$woo_account_page_id = self::get_myaccount_page_id();
		$page_parent         = (int) filter_input( INPUT_POST, 'parent_id', FILTER_SANITIZE_NUMBER_INT );

		if ( $woo_account_page_id !== $page_parent ) {
			return;
		}

		flush_rewrite_rules();
	}
}
