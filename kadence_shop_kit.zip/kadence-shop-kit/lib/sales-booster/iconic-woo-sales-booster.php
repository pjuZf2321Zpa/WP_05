<?php
/**
 * Sales Booster Module for Kadence Shop Kit.
 *
 * Based on Iconic Sales Booster for WooCommerce v1.26.0.0
 *
 * @package kadence-shop-kit
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

use KadenceWP\KadenceShopKit\StellarWP\ContainerContract\ContainerInterface;
use KadenceWP\KadenceShopKit\App;

class Iconic_Woo_Sales_Booster {
	/**
	 * Variable to hold default/saved settings.
	 *
	 * @var array|null
	 */
	public $settings = null;

	/**
	 * @var Iconic_WSB_Template
	 */
	public $template;

	/**
	 * The singleton instance of the plugin.
	 *
	 * @var Iconic_Woo_Sales_Booster
	 */
	private static $instance;

	/**
	 * Construct the plugin
	 */
	public function __construct() {
		self::$instance = $this;

		$this->define_constants();
		$this->load_classes();

		// Declare compatibility with High-Performance Order Storage (HPOS).
		add_action(
			'before_woocommerce_init',
			function () {
				if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
					\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
				}
			}
		);
	}

	/**
	 * Instantiate a single instance of our plugin.
	 *
	 * @return Iconic_Woo_Sales_Booster
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Get the DI container.
	 *
	 * @return ContainerInterface
	 */
	public function container() {
		return App::container();
	}

	/**
	 * Load text domain.
	 *
	 * @deprecated 3.0.0
	 *
	 * @return void
	 */
	public function load_text_domain() {
		_deprecated_function( __METHOD__, '3.0.0' );
	}

	/**
	 * Define Constants.
	 */
	private function define_constants() {
		$this->define( 'ICONIC_WSB_FILE', __FILE__ );
		$this->define( 'ICONIC_WSB_PATH', plugin_dir_path( ICONIC_WSB_FILE ) );
		$this->define( 'ICONIC_WSB_URL', plugin_dir_url( ICONIC_WSB_FILE ) );
		$this->define( 'ICONIC_WSB_INC_PATH', ICONIC_WSB_PATH . 'inc/' );
		$this->define( 'ICONIC_WSB_VENDOR_PATH', ICONIC_WSB_INC_PATH . 'vendor/' );
		$this->define( 'ICONIC_WSB_TPL_PATH', ICONIC_WSB_PATH . 'templates/' );
		$this->define( 'ICONIC_WSB_BASENAME', plugin_basename( ICONIC_WSB_FILE ) );
		$this->define( 'ICONIC_WSB_DIRNAME', dirname( ICONIC_WSB_BASENAME ) );
		$this->define( 'ICONIC_WSB_VERSION', KADENCE_WOO_EXTRAS_VERSION );
		$this->define( 'ICONIC_WSB_PLUGIN_PATH_FILE', str_replace( trailingslashit( wp_normalize_path( WP_PLUGIN_DIR ) ), '', wp_normalize_path( ICONIC_WSB_FILE ) ) );
	}

	/**
	 * Define constant if not already set.
	 *
	 * @param string      $name
	 * @param string|bool $value
	 */
	private function define( $name, $value ) {
		if ( ! defined( $name ) ) {
			define( $name, $value );
		}
	}

	/**
	 * Load classes
	 */
	private function load_classes() {
		$this->init_autoloader();

		if ( ! Iconic_WSB_Core_Helpers::is_plugin_active( 'woocommerce/woocommerce.php' ) ) {
			return;
		}

		$this->init_settings();

		$this->template = new Iconic_WSB_Template();

		$this->init_services();
	}

	/**
	 * Init licence class.
	 *
	 * @deprecated 3.0.0
	 *
	 * @return void
	 */
	public function init_license() {
		_deprecated_function( __METHOD__, '3.0.0' );
	}

	/**
	 * Init telemetry class.
	 *
	 * @deprecated 3.0.0
	 *
	 * @return void
	 */
	public function init_telemetry() {
		_deprecated_function( __METHOD__, '3.0.0' );
	}

	/**
	 * Init settings framework
	 */
	private function init_settings() {
		Iconic_WSB_Core_Settings::run(
			array(
				'parent_slug'   => 'kadence-shop-kit-settings',
				'vendor_path'   => ICONIC_WSB_VENDOR_PATH,
				'title'         => function () {
					return __( 'Kadence Shop Kit - Sales Booster', 'kadence-shop-kit' );
				},
				'version'       => KADENCE_WOO_EXTRAS_VERSION,
				'menu_title'    => function () {
					return __( 'Sales Booster', 'kadence-shop-kit' );
				},
				'settings_path' => ICONIC_WSB_INC_PATH . 'admin/settings.php',
				'option_group'  => 'iconic-wsb',
				'docs'          => array(
					'collection'      => 'iconic-sales-booster-for-woocommerce/',
					'troubleshooting' => 'iconic-sales-booster-for-woocommerce/isb-troubleshooting/',
					'getting-started' => 'iconic-sales-booster-for-woocommerce/isb-getting-started/',
				),
				'cross_sells'   => array(
					'iconic-woo-show-single-variations',
					'iconic-woothumbs',
				),
			)
		);
	}

	/**
	 *  Init plugin autoloader
	 */
	private function init_autoloader() {
		require_once ICONIC_WSB_INC_PATH . 'class-core-autoloader.php';

		Iconic_WSB_Core_Autoloader::run(
			array(
				'prefix'   => 'Iconic_WSB_',
				'inc_path' => ICONIC_WSB_INC_PATH,
			)
		);
	}

	/**
	 * Set settings.
	 */
	public function set_settings() {
		$this->settings = Iconic_WSB_Core_Settings::$settings;
	}

	/**
	 * Init plugin services
	 */
	private function init_services() {
		Iconic_WSB_Notifier::run();
		Iconic_WSB_Settings::run();
		Iconic_WSB_Assets::run();
		Iconic_WSB_Cart::run();
		Iconic_WSB_Ajax::run();
		Iconic_WSB_Order_Bump::run();
		Iconic_WSB_Admin_Orders::run();
		Iconic_WSB_Admin_Product_Tab::run();
		Iconic_WSB_Compat_Woo_Attributes_Swatches::run();
		Iconic_WSB_Shortcodes::run();
		Iconic_WSB_Blocks::run();
		Iconic_WSB_Compat_Variation_Swatches_For_WooCommerce::run();
		Iconic_WSB_Compat_Divi::run();
		Iconic_WSB_Compat_WooCommerce_Subscriptions::run();
		Iconic_WSB_Compat_WooCommerce_Ecurring_Gateway::run();
		Iconic_WSB_Compat_WooCommerce_Multilingual::run();
		Iconic_WSB_Bulk_Import_Export::run();
		Iconic_WSB_Compat_WPML::run();
		Iconic_WSB_Compat_YITH_WooCommerce_Added_To_Cart_Popup::run();
		Iconic_WSB_Compat_WooCommerce_Booking::run();
		Iconic_WSB_Product_Block_Editor::run();
		Iconic_WSB_Compat_WooCommerce_Shipping_Tax::run();
	}

	/**
	 * Activation hook.
	 *
	 * @deprecated 3.0.0
	 *
	 * @return void
	 */
	public static function activation_hook() {
		_deprecated_function( __METHOD__, '3.0.0' );

		update_option( 'iconic_wsb_activated', true );
	}
}

global $iconic_wsb_class;
$iconic_wsb_class = Iconic_Woo_Sales_Booster::instance();
