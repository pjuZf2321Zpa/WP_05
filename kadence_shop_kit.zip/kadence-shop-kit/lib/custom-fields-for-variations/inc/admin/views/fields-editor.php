<?php
/**
 * Field editor template.
 *
 * @package Iconic_CFFV
 */

global $post;

$fields = get_post_meta( $post->ID, 'iconic-cffv-field-data', true );
?>

<table class="wp-list-table widefat fixed striped iconic-cffv-fields" style="margin-top: 15px;">

	<thead>
	<tr>
		<th scope="col"></th>
		<th scope="col"><?php esc_html_e( 'Field Order', 'kadence-shop-kit' ); ?></th>
		<th scope="col"><?php esc_html_e( 'Field Label', 'kadence-shop-kit' ); ?></th>
		<th scope="col"><?php esc_html_e( 'Field Type', 'kadence-shop-kit' ); ?></th>
		<th scope="col"><?php esc_html_e( 'Shortcode', 'kadence-shop-kit' ); ?></th>
	</tr>
	</thead>

	<tfoot>
	<tr>
		<td colspan="5">
			<a href="javascript: void(0);" class="button button-primary iconic-cffv-edit-field"><?php esc_html_e( 'Add Field', 'kadence-shop-kit' ); ?></a>
		</td>
	</tr>
	</tfoot>

	<tbody>

	<?php if ( $fields && ! empty( $fields ) ) { ?>

		<?php foreach ( $fields as $i => $field_json ) { ?>

			<?php
			$field_json = stripcslashes( $field_json );
			$field_data = json_decode( $field_json, true );
			$meta_key   = sprintf( 'iconic_cffv_%s_%s', $post->ID, $field_data['id'] );
			?>

			<tr class="iconic-cffv-fields__field" data-index="<?php echo esc_attr( $i ); ?>">
				<td>
					<div class='iconic-cffv-fields__handle'><span class="dashicons dashicons-menu-alt3"></span></div>
				</td>
				<td>
					<strong class="iconic-cffv-fields__field-order"><?php echo esc_html( $i + 1 ); ?></strong>
					<input type="hidden" class="iconic-cffv-field-data" name="iconic-cffv-field-data[]" value="<?php echo filter_var( $field_json, FILTER_SANITIZE_SPECIAL_CHARS ); ?>">
				</td>

				<td class="title column-title has-row-actions page-title">
					<strong><a href="#" class="row-title iconic-cffv-edit-field iconic-cffv-field-label"><?php echo esc_html( $field_data['label'] ); ?></a></strong>
					<div class="row-actions">
						<a href="javascript: void(0);" class="iconic-cffv-edit-field" title="Edit Field">Edit</a> |
						<span class="trash"><a href="javascript: void(0);" class="iconic-cffv-delete-field"><?php esc_html_e( 'Delete Field', 'kadence-shop-kit' ); ?></a></span>
					</div>
				</td>

				<td class="iconic-cffv-field-type"><?php echo esc_html( $field_data['type'] ); ?></td>
				<td class="iconic-cffv-field-shortcode"><input type='text' readonly value='[kt_custom_fields fields="<?php echo esc_html( $meta_key ); ?>"]'/></td>
			</tr>

		<?php } ?>

	<?php } ?>

	</tbody>

</table>
