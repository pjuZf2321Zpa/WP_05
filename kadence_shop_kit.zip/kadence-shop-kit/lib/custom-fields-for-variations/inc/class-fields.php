<?php
/**
 * Fields class.
 *
 * @package Iconic_CFFV
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Iconic_CFFV_Fields.
 *
 * @class    Iconic_CFFV_Fields
 * @version  1.0.0
 * @package  Iconic_CFFV
 */
class Iconic_CFFV_Fields {
	/**
	 * Get product fields data.
	 *
	 * @param int $product_id Product ID.
	 *
	 * @return mixed
	 */
	public static function get_product_fields_data( $product_id ) {
		global $wpdb;

		static $data = array();

		if ( isset( $data[ $product_id ] ) ) {
			return apply_filters( 'iconic_cffv_product_fields_data', $data[ $product_id ], $product_id );
		}

		$data[ $product_id ] = false;

		$meta = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT *
				FROM $wpdb->postmeta
				WHERE post_id = %d
				AND meta_key LIKE %s",
				$product_id,
				'iconic_cffv_%%'
			)
		);

		if ( ! $meta ) {
			return apply_filters( 'iconic_cffv_product_fields_data', $data[ $product_id ], $product_id );
		}

		$meta = self::reorder_meta( $meta );

		$data[ $product_id ] = array();
		$groups              = array();

		foreach ( $meta as $meta_item ) {
			$ids      = self::get_ids_from_meta_key( $meta_item->meta_key );
			$group_id = $ids['group_id'];
			$field_id = $ids['field_id'];

			if ( 'publish' !== get_post_status( $group_id ) ) {
				continue;
			}

			if ( ! isset( $groups[ $group_id ] ) ) {
				$groups[ $group_id ] = Iconic_CFFV::get_variation_field_group_fields( $ids['group_id'] );
			}

			if ( ! isset( $groups[ $group_id ][ $field_id ] ) ) {
				continue;
			}

			// Use combination of both group id and field id to make the key unique.
			$field_key = sprintf( '%s_%s', $group_id, $field_id );

			$data[ $product_id ][ $field_key ] = $groups[ $group_id ][ $field_id ];
			$value                             = maybe_unserialize( $meta_item->meta_value );

			$default_value = isset( $groups[ $group_id ][ $field_id ]['data']['default'] ) ? $groups[ $group_id ][ $field_id ]['data']['default'] : '';

			$data[ $product_id ][ $field_key ]['value'] = empty( $value ) ? $default_value : $value;
		}

		return apply_filters( 'iconic_cffv_product_fields_data', $data[ $product_id ], $product_id );
	}

	/**
	 * Get IDs from meta_key.
	 *
	 * @param string $meta_key Meta key.
	 *
	 * @return array
	 */
	public static function get_ids_from_meta_key( $meta_key ) {
		$meta_key  = str_replace( 'iconic_cffv_', '', $meta_key );
		$key_parts = explode( '_', $meta_key );

		return array(
			'group_id' => (int) array_shift( $key_parts ),
			'field_id' => implode( '_', $key_parts ),
		);
	}

	/**
	 * Get all field keys in correct order.
	 *
	 * @return array
	 */
	public static function get_all_field_order() {
		static $cache;

		if ( isset( $cache ) ) {
			return $cache;
		}

		$field_groups = get_posts(
			array(
				'post_type' => 'cpt_variation_fields',
			)
		);

		$fields_order = array();

		if ( empty( $field_groups ) ) {
			$cache = array();
			return $cache;
		}

		foreach ( $field_groups as $group ) {
			$fields = Iconic_CFFV::get_variation_field_group_fields( $group->ID );
			foreach ( $fields as $field ) {
				$fields_order[] = sprintf( 'iconic_cffv_%d_%s', $group->ID, $field['data']['id'] );
			}
		}

		$cache = $fields_order;
		return $fields_order;
	}

	/**
	 * Reorder meta data based on the user's defined order.
	 *
	 * @param array $meta Meta.
	 *
	 * @return array
	 */
	public static function reorder_meta( $meta ) {
		$field_order = self::get_all_field_order();

		if ( empty( $field_order ) || empty( $meta ) ) {
			return $meta;
		}

		// Create an associative array where keys are meta keys and values are the corresponding meta objects.
		$meta_map = array();
		foreach ( $meta as $meta_item ) {
			$meta_map[ $meta_item->meta_key ] = $meta_item;
		}

		// Sort $meta items based on their order in $field_order array.
		$sorted_meta = array();
		foreach ( $field_order as $field ) {
			if ( isset( $meta_map[ $field ] ) ) {
				$sorted_meta[] = $meta_map[ $field ];
				unset( $meta_map[ $field ] );
			}
		}

		// Append any remaining meta items that are not in $field_order.
		foreach ( $meta_map as $meta_item ) {
			$sorted_meta[] = $meta_item;
		}

		return $sorted_meta;
	}
}
