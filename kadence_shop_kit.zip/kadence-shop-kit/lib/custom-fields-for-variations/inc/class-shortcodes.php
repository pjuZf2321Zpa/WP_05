<?php
/**
 * Shortcodes class.
 *
 * @package Iconic_CFFV
 */

defined( 'ABSPATH' ) || exit;

/**
 * Shortcodes.
 */
class Iconic_CFFV_Shortcodes {
	/**
	 * Run
	 */
	public static function run() {
		add_shortcode( 'iconic-variation-fields', array( __CLASS__, 'output_variation_fields' ) );
		add_shortcode( 'kt_custom_fields', array( __CLASS__, 'output_variation_fields' ) );
		add_filter( 'manage_cpt_variation_fields_posts_columns', array( __CLASS__, 'add_shortcode_column' ) );
		add_action( 'manage_cpt_variation_fields_posts_custom_column', array( __CLASS__, 'shortcode_column' ), 10, 2 );
	}

	/**
	 * Output fields shortcode.
	 *
	 * @param array $args Arguments.
	 */
	public static function output_variation_fields( $args = array() ) {
		global $product;

		$args = shortcode_atts(
			array(
				'id'     => ( $product && is_a( $product, 'WC_Product' ) ) ? $product->get_id() : null,
				'fields' => '[]',
				'group'  => false,
			),
			$args,
			'iconic-variation-fields'
		);

		global $iconic_cffv;

		if ( ! empty( $args['group'] ) ) {
			// If group id is present in the shortcode then fetch and use fields of this group.
			$fields_meta    = $iconic_cffv->get_group_fields_meta_keys( intval( $args['group'] ) );
			$args['fields'] = wp_json_encode( $fields_meta );
		} elseif ( '[]' !== $args['fields'] ) {
			// convert comma seperated fields to array.
			$args['fields'] = explode( ',', $args['fields'] );
			$args['fields'] = array_map( 'trim', $args['fields'] );
			$args['fields'] = wp_json_encode( $args['fields'] );
		}

		ob_start();
		?>
		<div 
			class="iconic-cffv-fields iconic-cffv-fields--shortcode"
			data-iconic-cffv="<?php echo esc_attr( $args['id'] ); ?>"
			data-iconic-fields="<?php echo esc_attr( $args['fields'] ); ?>"
			></div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Add shortcode column.
	 *
	 * @param array $columns Columns.
	 *
	 * @return array
	 */
	public static function add_shortcode_column( $columns ) {
		$columns['iconic_cffv_shortcode'] = __( 'Shortcode', 'kadence-shop-kit' );

		return $columns;
	}

	/**
	 * Display shortcode in the column.
	 *
	 * @param string $column Column name.
	 * @param int    $post_id Post ID.
	 *
	 * @return void
	 */
	public static function shortcode_column( $column, $post_id ) {
		if ( 'iconic_cffv_shortcode' !== $column ) {
			return;
		}

		printf( "<input type='text' size='30' readonly value='[kt_custom_fields group=\"%s\"]'></input>", esc_attr( $post_id ) );
	}
}
