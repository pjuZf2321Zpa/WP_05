<?php return array('dependencies' => array('jquery', 'wp-hooks'), 'version' => '5a3884b21aa76062cb45');
