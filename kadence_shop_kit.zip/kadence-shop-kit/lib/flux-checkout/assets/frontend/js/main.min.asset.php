<?php return array('dependencies' => array('jquery', 'wp-hooks'), 'version' => '7713759c8bd8aeb3c5ca');
