<?php
/**
 * Flux Checkout Module for Kadence Shop Kit.
 *
 * Based on Flux Checkout for WooCommerce by Iconic v2.25.0.0
 *
 * @package kadence-shop-kit
 */

use KadenceWP\KadenceShopKit\StellarWP\ContainerContract\ContainerInterface;
use KadenceWP\KadenceShopKit\App;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Iconic_Flux
 */
class Iconic_Flux_Checkout {
	/**
	 * Settings array.
	 *
	 * @var array
	 */
	public $settings = array();

	/**
	 * Plugin initiated.
	 *
	 * @var bool
	 */
	public $initiated = false;

	/**
	 * The singleton instance of the plugin.
	 *
	 * @var Iconic_Flux_Checkout
	 */
	private static $instance;

	/**
	 * Instantiate a single instance of our plugin.
	 *
	 * @return YourClass
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Get the DI container.
	 *
	 * @return ContainerInterface
	 */
	public function container() {
		return App::container();
	}

	/**
	 * Construct the plugin
	 */
	public function __construct() {
		self::$instance = $this;

		add_action( 'before_woocommerce_init', array( __CLASS__, 'declare_hpos_compatiblity' ) );

		/**
		 * Allows code snippets to conditionally disable Flux checkout.
		 *
		 * @since 2.8.0
		 */
		if ( apply_filters( 'flux_checkout_disabled', false ) ) {
			return;
		}

		$this->define_constants();
		$this->setup_autoloader();

		if ( ! Iconic_Flux_Core_Helpers::is_plugin_active( 'woocommerce/woocommerce.php' ) ) {
			return;
		}

		$this->load_classes();

		add_action( 'init', array( 'Iconic_Flux_Checkout_Elements', 'on_init' ), 10 );
		add_action( 'admin_menu', array( $this, 'add_checkout_elements_menu' ), 21 );

		$this->initiated = true;
	}

	/**
	 * Run on activation.
	 */
	public static function activate() {
		if ( ! get_option( 'iconic_flux_flush_rewrite_rules_flag' ) ) {
			add_option( 'iconic_flux_flush_rewrite_rules_flag', true );
		}

		self::clear_wc_template_cache();
	}

	/**
	 * Deactivate plugin.
	 *
	 * @return void
	 */
	public static function deactivate() {
		flush_rewrite_rules();

		self::clear_wc_template_cache();
	}

	/**
	 * Clear WooCommerce template cache.
	 *
	 * @return void
	 */
	public static function clear_wc_template_cache() {
		if ( function_exists( 'wc_clear_template_cache' ) ) {
			wc_clear_template_cache();
		}
	}

	/**
	 * Define Constants.
	 */
	private function define_constants() {
		$this->define( 'ICONIC_FLUX_FILE', __FILE__ );
		$this->define( 'ICONIC_FLUX_PATH', plugin_dir_path( __FILE__ ) );
		$this->define( 'ICONIC_FLUX_URL', plugin_dir_url( __FILE__ ) );
		$this->define( 'ICONIC_FLUX_INC_PATH', ICONIC_FLUX_PATH . 'inc/' );
		$this->define( 'ICONIC_FLUX_VENDOR_PATH', ICONIC_FLUX_INC_PATH . 'vendor/' );
		$this->define( 'ICONIC_FLUX_TPL_PATH', ICONIC_FLUX_PATH . 'templates/' );
		$this->define( 'ICONIC_FLUX_BASENAME', plugin_basename( __FILE__ ) );
		$this->define( 'ICONIC_FLUX_VERSION', KADENCE_WOO_EXTRAS_VERSION );
		$this->define( 'FLUX_PLUGIN_VERSION', ICONIC_FLUX_VERSION ); // Needed for third party compatibility (IE Sales Booster).
		$this->define( 'ICONIC_FLUX_PLUGIN_PATH_FILE', str_replace( trailingslashit( wp_normalize_path( WP_PLUGIN_DIR ) ), '', wp_normalize_path( ICONIC_FLUX_FILE ) ) );
	}

	/**
	 * Setup autoloader.
	 */
	private function setup_autoloader() {
		require_once ICONIC_FLUX_INC_PATH . 'class-core-autoloader.php';

		Iconic_Flux_Core_Autoloader::run(
			array(
				'prefix'   => 'Iconic_Flux_',
				'inc_path' => ICONIC_FLUX_INC_PATH,
			)
		);
	}

	/**
	 * Define constant if not already set.
	 *
	 * @param string      $name Name.
	 * @param string|bool $value Value.
	 */
	private function define( $name, $value ) {
		if ( ! defined( $name ) ) {
			define( $name, $value );
		}
	}

	/**
	 * Load classes
	 */
	private function load_classes() {
		// @todo Set correct paths.
		// @todo Set correct cross sells.
		Iconic_Flux_Core_Settings::run(
			array(
				'basename'      => ICONIC_FLUX_BASENAME,
				'parent_slug'   => 'kadence-shop-kit-settings',
				'vendor_path'   => ICONIC_FLUX_VENDOR_PATH,
				'title'         => function () {
					return __( 'Kadence Shop Kit - Optimized Checkout', 'kadence-shop-kit' );
				},
				'version'       => KADENCE_WOO_EXTRAS_VERSION,
				'menu_title'    => function () {
					return __( 'Optimized Checkout', 'kadence-shop-kit' );
				},
				'settings_path' => ICONIC_FLUX_INC_PATH . 'admin/settings.php',
				'option_group'  => 'iconic_flux',
				'docs'          => array(
					'collection'      => 'flux-checkout-for-woocommerce/',
					'troubleshooting' => 'flux-checkout-for-woocommerce/flux-user-guides/',
					'getting-started' => 'flux-checkout-for-woocommerce/flux-getting-started/',
				),
			)
		);

		Iconic_Flux_Upgrade::run();
		Iconic_Flux_Core::run();
		Iconic_Flux_Assets::run();
		Iconic_Flux_Cross_Sell::run();
	}

	/**
	 * Add Checkout Elements submenu under ShopKit (kadence-shop-kit-settings).
	 *
	 * @return void
	 */
	public function add_checkout_elements_menu() {
		add_submenu_page(
			'kadence-shop-kit-settings',
			__( 'Checkout Elements', 'kadence-shop-kit' ),
			__( '↳ Checkout Elements', 'kadence-shop-kit' ), // Only shows within the Admin Menu to make it appear like a submenu item for the submenu item.
			'manage_woocommerce',
			'edit.php?post_type=checkout_elements'
		);
	}

	/**
	 * @deprecated 3.0.0
	 * @return void
	 */
	public function init_license() {
		_deprecated_function( __METHOD__, '3.0.0' );
	}

	/**
	 * @deprecated 3.0.0
	 * @return void
	 */
	public function init_telemetry() {
		_deprecated_function( __METHOD__, '3.0.0' );
	}

	/**
	 * Declare compatibility with HPOS/Custom order table feature of WooCommerce.
	 *
	 * @return void
	 */
	public static function declare_hpos_compatiblity() {
		if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
		}
	}
}

$iconic_flux_checkout = Iconic_Flux_Checkout::instance();

if ( $iconic_flux_checkout->initiated ) {
	register_activation_hook( __FILE__, array( $iconic_flux_checkout, 'activate' ) );
	register_deactivation_hook( __FILE__, array( $iconic_flux_checkout, 'deactivate' ) );

	require_once ICONIC_FLUX_PATH . 'inc/compatibility.php';
}
