<?php
/**
 * Class adding compatibility with Bricks theme.
 *
 * @package Iconic_PC
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use Bricks\Database;

/**
 * Bricks compatibility Class
 */
class Iconic_PC_Compat_Bricks {

	/**
	 * Lazy load status.
	 *
	 * @var bool
	 */
	private static $lazy_load_status;

	/**
	 * Init.
	 */
	public static function run() {
		add_action( 'init', array( __CLASS__, 'hooks' ) );
	}

	/**
	 * Disable lazy load for PC images.
	 *
	 * @return void
	 */
	public static function hooks() {
		if ( ! class_exists( 'Bricks\Database' ) ) {
			return;
		}

		add_action( 'iconic_pc_before_display_image', array( __CLASS__, 'disable_lazyload' ), 10 );
		add_action( 'iconic_pc_after_layers', array( __CLASS__, 'maybe_restore_lazyload_status' ), 10 );
	}

	/**
	 * Fix global $product variable.
	 *
	 * @return void
	 */
	public static function disable_lazyload() {
		self::$lazy_load_status = Database::$global_settings['disableLazyLoad'] ?? false;

		Bricks\Database::$global_settings['disableLazyLoad'] = true;
	}

	/**
	 * Fix global $product variable.
	 *
	 * @return void
	 */
	public static function maybe_restore_lazyload_status() {
		Database::$global_settings['disableLazyLoad'] = self::$lazy_load_status;
	}
}
