<?php
/**
 * Image generation related methods.
 *
 * @package Iconic_PC
 */

defined( 'ABSPATH' ) || exit;

/**
 * Iconic_PC_Image class.
 */
class Iconic_PC_Image {

	/**
	 * The image engine. 'gd' or 'imagick'.
	 *
	 * @var string
	 */
	public $engine;

	/**
	 * The output format. Allowed values: 'png' or 'webp'.
	 *
	 * @var string
	 */
	public $output_format;

	/**
	 * Constructor.
	 *
	 * @param string $output_format The output format.
	 * @param string $engine        The image engine. Values: 'gd' or 'imagick'.
	 */
	public function __construct( $output_format, $engine = 'imagick' ) {
		if ( ! in_array( $output_format, array( 'png', 'webp' ), true ) ) {
			$output_format = 'png';
		}

		$this->output_format = $output_format;
		$this->engine        = $engine;
	}

	/**
	 * Generate an image.
	 *
	 * @param array $params The params.
	 * @return resource|false The image resource or false on failure.
	 */
	public function generate_image( $params ) {
		if ( 'gd' === $this->engine ) {
			return $this->generate_image_with_gd( $params );
		} else {
			return $this->generate_image_with_imagick( $params );
		}
	}

	/**
	 * Generate an empty background image.
	 *
	 * @param int $width  The width of the image.
	 * @param int $height The height of the image.
	 * @return resource|false The image resource or false on failure.
	 */
	public function generate_empty_bg_image( $width, $height ) {
		if ( 'gd' === $this->engine ) {
			$image = imagecreatetruecolor( $width, $height );
			imagealphablending( $image, true );
			imagesavealpha( $image, true );
			$trans_colour = imagecolorallocatealpha( $image, 0, 0, 0, 127 );
			imagefill( $image, 0, 0, $trans_colour );
			return $image;
		} else {
			$image = new Imagick();
			$image->newImage( $width, $height, new ImagickPixel( 'transparent' ) );
			$image->setImageFormat( $this->output_format );
			return $image;
		}
	}


	/**
	 * Generate an image with GD.
	 *
	 * @param array $params The params.
	 */
	public function generate_image_with_gd( $params ) {
		// Set up image space.
		$canvas_size   = $this->get_canvas_size( $params );
		$canvas_width  = $canvas_size['width'];
		$canvas_height = $canvas_size['height'];
		$bg            = imagecreatetruecolor( $canvas_width, $canvas_height );

		imagealphablending( $bg, true );
		imagesavealpha( $bg, true );

		$trans_colour = imagecolorallocatealpha( $bg, 0, 0, 0, 127 );
		imagefill( $bg, 0, 0, $trans_colour );

		if ( is_array( $params['images'] ) ) {
			foreach ( $params['images'] as $index => $image_data ) {
				if ( empty( $image_data['path'] ) ) {
					continue;
				}

				$img = $this->create_image( $image_data['path'] );

				if ( ! $img ) {
					continue;
				}

				imagecopyresized( $bg, $img, 0, 0, 0, 0, $canvas_width, $canvas_height, $canvas_width, $canvas_height );
				imagedestroy( $img ); // phpcs:ignore PHPCompatibility.FunctionUse.RemovedFunctions.imagedestroyDeprecated
			}
		}

		return $bg;
	}

	/**
	 * Generate an image with imagick.
	 *
	 * @param array $params The params.
	 */
	public function generate_image_with_imagick( $params ) {
		// Set up image space.
		$canvas_size   = $this->get_canvas_size( $params );
		$canvas_width  = $canvas_size['width'];
		$canvas_height = $canvas_size['height'];

		$bg = new Imagick();

		// Create a transparent canvas.
		$bg->newImage( $canvas_width, $canvas_height, new ImagickPixel( 'transparent' ) );

		// Set the image format.
		$bg->setImageFormat( 'png' );

		if ( is_array( $params['images'] ) ) {
			foreach ( $params['images'] as $index => $image_data ) {
				if ( empty( $image_data['path'] ) ) {
					continue;
				}

				try {
					$img = new Imagick( $image_data['path'] );

					$img->resizeImage( $canvas_width, $canvas_height, Imagick::FILTER_LANCZOS, 1 );
					$bg->compositeImage( $img, Imagick::COMPOSITE_OVER, 0, 0 );

					// Clear the image from memory.
					$img->clear();
				} catch ( ImagickException $e ) {
					continue;
				}
			}
		}

		return $bg;
	}

	/**
	 * Get the canvas size.
	 *
	 * @param array $params The params.
	 * @return array
	 */
	public function get_canvas_size( $params ) {
		// If bg image not set, then get the largest layer's width and height.
		$canvas_width  = 400;
		$canvas_height = 400;

		if ( empty( $params['images']['background']['full'] ) ) {
			foreach ( $params['images'] as $layer ) {
				if ( empty( $layer['full'] ) ) {
					continue;
				}

				$canvas_width  = max( $canvas_width, (int) $layer['full'][1] );
				$canvas_height = max( $canvas_height, (int) $layer['full'][2] );
			}
		} else {
			$canvas_width  = (int) $params['images']['background']['full'][1];
			$canvas_height = (int) $params['images']['background']['full'][2];
		}

		return array(
			'width'  => $canvas_width,
			'height' => $canvas_height,
		);
	}

	/**
	 * Generate a thumbnail.
	 *
	 * @param resource $bg     The source image.
	 * @param array    $params The params.
	 *
	 * @return resource|false  The thumbnail resource or false on failure.
	 */
	public function generate_thumbnail( $bg, $params ) {
		// Resize the image to the thumbnail size.
		$thumb_width   = (int) $params['size']['width'];
		$thumb_height  = (int) $params['size']['height'];
		$canvas_size   = $this->get_canvas_size( $params );
		$canvas_width  = (int) $canvas_size['width'];
		$canvas_height = (int) $canvas_size['height'];
		$thumbnail     = false;

		if ( empty( $thumb_height ) ) {
			$aspect_ratio = $canvas_width / $canvas_height;
			$thumb_height = (int) ( $thumb_width / $aspect_ratio );
		}

		if ( 'gd' === $this->engine ) {
			$thumbnail = imagecreatetruecolor( $thumb_width, $thumb_height );
			imagesavealpha( $thumbnail, true );
			$trans_colour = imagecolorallocatealpha( $thumbnail, 0, 0, 0, 127 );
			imagefill( $thumbnail, 0, 0, $trans_colour );
			imagecopyresampled( $thumbnail, $bg, 0, 0, 0, 0, $thumb_width, $thumb_height, $canvas_width, $canvas_height );
		} else {
			$thumbnail = clone $bg;
			$thumbnail->resizeImage( $thumb_width, $thumb_height, Imagick::FILTER_LANCZOS, 1 );
		}

		return $thumbnail;
	}

	/**
	 * Create an image from a path. Based on the path determine if its a png or webp.
	 *
	 * @param string $path The path to the image.
	 * @return resource|false The image resource or false on failure.
	 */
	public function create_image( $path ) {
		$file_extension = pathinfo( $path, PATHINFO_EXTENSION );

		if ( 'gd' === $this->engine ) {
			if ( 'png' === $file_extension ) {
				$img = imagecreatefrompng( $path );
			} elseif ( 'webp' === $file_extension ) {
				$img = imagecreatefromwebp( $path );
			}
		} else {
			$img = new Imagick( $path );
		}

		return $img;
	}

	/**
	 * Save an image to a path.
	 *
	 * @param resource|GdImage $image The image resource.
	 * @param string           $path The path to save the image to.
	 */
	public function save_image( $image, $path ) {
		if ( 'gd' === $this->engine ) {
			if ( 'png' === $this->output_format ) {
				return imagepng( $image, $path );
			} elseif ( 'webp' === $this->output_format ) {
				return imagewebp( $image, $path );
			}
		} else {
			if ( 'webp' === $this->output_format ) {
				$image->setImageFormat( 'WEBP' );
			} elseif ( 'png' === $this->output_format ) {
				$image->setImageFormat( 'PNG' );
			}

			return $image->writeImage( $path );
		}
	}

	/**
	 * Output an image.
	 *
	 * @param resource|GdImage $image The image resource.
	 */
	public function output_image_to_browser( $image ) {
		header( 'Content-Type: image/' . $this->output_format );

		if ( 'gd' === $this->engine ) {
			imagesavealpha( $image, true );
			if ( 'png' === $this->output_format ) {
				imagepng( $image );
			} elseif ( 'webp' === $this->output_format ) {
				imagewebp( $image );
			}
		} elseif ( 'imagick' === $this->engine ) {
			if ( 'webp' === $this->output_format ) {
				$image->setImageFormat( 'WEBP' );
			} elseif ( 'png' === $this->output_format ) {
				$image->setImageFormat( 'PNG' );
			}

			// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			print $image->getImageBlob();
		}
	}


	/**
	 * Destroy an image.
	 *
	 * @param resource|GdImage $image The image resource.
	 */
	public function destroy_image( $image ) {
		if ( 'gd' === $this->engine ) {
			imagedestroy( $image ); // phpcs:ignore PHPCompatibility.FunctionUse.RemovedFunctions.imagedestroyDeprecated
		} elseif ( 'imagick' === $this->engine ) {
			$image->clear();
		}
	}
}
