<?php
/**
 * Meta toolbar partial.
 *
 * @package Kadence_Woo_Extras
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

$disable_inputs = Iconic_PC_Helpers::maybe_disable_layer_inputs();

if ( ! $disable_inputs ) {
	?>
	<div class="jckpc-meta-toolbar">

		<button disabled="true" type="button" id="jckpc-add-static-layer" class="button jckpc-meta-toolbar__button">
			<?php esc_html_e( 'Add Static Layer', 'kadence-shop-kit' ); ?>
		</button>
		<button type="button" id="jckpc-expand-all-layers" class="button jckpc-meta-toolbar__button">
			<?php esc_html_e( 'Expand All', 'kadence-shop-kit' ); ?>
			<svg width="800px" height="800px" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg">
				<title>expand-vertical-solid</title>
				<g id="Layer_2" data-name="Layer 2">
					<g id="invisible_box" data-name="invisible box">
					<rect width="48" height="48" fill="none"/>
					</g>
					<g id="icons_Q2" data-name="icons Q2">
					<g>
						<path d="M28.6,17.4a1.9,1.9,0,0,0,3-.2,2.1,2.1,0,0,0-.2-2.7l-6-5.9a1.9,1.9,0,0,0-2.8,0l-6,5.9a2.1,2.1,0,0,0-.2,2.7,1.9,1.9,0,0,0,3,.2L22,14.8V33.2l-2.6-2.6a1.9,1.9,0,0,0-3,.2,2.1,2.1,0,0,0,.2,2.7l6,5.9a1.9,1.9,0,0,0,2.8,0l6-5.9a2.1,2.1,0,0,0,.2-2.7,1.9,1.9,0,0,0-3-.2L26,33.2V14.8Z"/>
						<path d="M6,6H42a2,2,0,0,0,0-4H6A2,2,0,0,0,6,6Z"/>
						<path d="M42,42H6a2,2,0,0,0,0,4H42a2,2,0,0,0,0-4Z"/>
					</g>
					</g>
				</g>
			</svg>
		</button>
		<button type="button" id="jckpc-collapse-all-layers" class="button jckpc-meta-toolbar__button">
			<?php esc_html_e( 'Collapse All', 'kadence-shop-kit' ); ?>
			<svg width="800px" height="800px" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg">
				<title>collapse-vertical</title>
				<g id="Layer_2" data-name="Layer 2">
					<g id="invisible_box" data-name="invisible box">
					<rect width="48" height="48" fill="none"/>
					</g>
					<g id="icons_Q2" data-name="icons Q2">
					<g>
						<path d="M22.6,15.4a1.9,1.9,0,0,0,2.8,0l6-5.9a2.1,2.1,0,0,0,.2-2.7,1.9,1.9,0,0,0-3-.2L26,9.2V4a2,2,0,0,0-4,0V9.2L19.4,6.6a1.9,1.9,0,0,0-3,.2,2.1,2.1,0,0,0,.2,2.7Z"/>
						<path d="M25.4,32.6a1.9,1.9,0,0,0-2.8,0l-6,5.9a2.1,2.1,0,0,0-.2,2.7,1.9,1.9,0,0,0,3,.2L22,38.8V44a2,2,0,0,0,4,0V38.8l2.6,2.6a1.9,1.9,0,0,0,3-.2,2.1,2.1,0,0,0-.2-2.7Z"/>
						<path d="M6,22H42a2,2,0,0,0,0-4H6a2,2,0,0,0,0,4Z"/>
						<path d="M42,26H6a2,2,0,0,0,0,4H42a2,2,0,0,0,0-4Z"/>
					</g>
					</g>
				</g>
			</svg>
		</button>

		<div class="jckpc-meta-toolbar__actions">

			<?php
			woocommerce_wp_checkbox(
				array(
					'id'            => 'jckpc_enabled',
					'wrapper_class' => 'jckpc_toggle',
					'label'         => 'Configurator enabled?',
					'description'   => '',
					'value'         => get_post_meta( $post->ID, 'jckpc_enabled', true ),
				)
			);
			?>

			<input type="submit" name="save" id="jckpc-publish" class="button button-primary button-large" value="Update">

		</div>

	</div>
	<?php
}
