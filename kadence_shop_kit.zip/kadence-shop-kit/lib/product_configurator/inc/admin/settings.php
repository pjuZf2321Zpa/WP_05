<?php
/**
 * Admin settings.
 *
 * @package Kadence_Woo_Extras
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

add_filter( 'wpsf_register_settings_iconic_woo_product_configurator', 'iconic_woo_product_configurator_settings' );

/**
 * WooCommerce Product Configurator Settings
 *
 * @param array $wpsf_settings The settings array.
 *
 * @return array
 */
function iconic_woo_product_configurator_settings( $wpsf_settings ) {
	// Tabs.

	$wpsf_settings['tabs'][] = array(
		'id'    => 'general',
		'title' => __( 'General', 'kadence-shop-kit' ),
	);

	// Sections.

	$wpsf_settings['sections'][] = array(
		'tab_id'              => 'dashboard',
		'section_id'          => 'tools',
		'section_title'       => __( 'Tools', 'kadence-shop-kit' ),
		'section_description' => '',
		'section_order'       => 20,
		'fields'              => array(
			array(
				'id'       => 'install_db',
				'title'    => __( 'Install Database Tables', 'kadence-shop-kit' ),
				'subtitle' => __( "If there's an issue with the database tables, you can run this tool to ensure they're all properly installed.", 'kadence-shop-kit' ),
				'type'     => 'custom',
				'default'  => '<button type="submit" name="iconic_pc_install_db" class="button button-secondary">' . __( 'Install Tables', 'kadence-shop-kit' ) . '</button>',
			),
			array(
				'id'       => 'clear_cache',
				'title'    => __( 'Clear Cache', 'kadence-shop-kit' ),
				'subtitle' => __( 'Clean up the temporary images created by Product Configurator.', 'kadence-shop-kit' ),
				'type'     => 'custom',
				'default'  => '<button type="submit" value="clear_cache" name="iconic_pc_clear_cache" class="button button-secondary">' . __( 'Clear Cache', 'kadence-shop-kit' ) . '</button>',
			),
		),
	);

	$wpsf_settings['sections'][] = array(
		'tab_id'              => 'general',
		'section_id'          => 'general',
		'section_title'       => __( 'General Settings', 'kadence-shop-kit' ),
		'section_description' => '',
		'section_order'       => 0,
		'fields'              => array(
			array(
				'id'       => 'output_format',
				'title'    => __( 'Output image format', 'kadence-shop-kit' ),
				'subtitle' => __( 'Select the format of the output image.', 'kadence-shop-kit' ),
				'type'     => 'select',
				'default'  => 'png',
				'choices'  => array(
					'png'  => 'PNG',
					'webp' => 'WebP',
				),
			),
		),
	);

	$wpsf_settings['sections'][] = array(
		'tab_id'              => 'general',
		'section_id'          => 'cache',
		'section_title'       => __( 'Cache Settings', 'kadence-shop-kit' ),
		'section_description' => '',
		'section_order'       => 0,
		'fields'              => array(
			array(
				'id'       => 'enable',
				'title'    => __( 'Enable Image Cache', 'kadence-shop-kit' ),
				'subtitle' => __( "Once added to cart, the customer's final variation image will be cached. Without this, images will be generated dynamically every time, and could slow down your website.", 'kadence-shop-kit' ),
				'type'     => 'checkbox',
				'default'  => 0,
			),
			array(
				'id'      => 'duration',
				'title'   => __( 'Cache Duration (Hours)', 'kadence-shop-kit' ),
				'type'    => 'number',
				'default' => 24,
			),
			array(
				'id'       => 'preload_layers',
				'title'    => __( 'Preload Layer Images', 'kadence-shop-kit' ),
				'subtitle' => __( 'Upon making attribute selections, the layered image will be downloaded and cached in the browser before the image preview is updated, to prevent a white flash while the new image is loading.', 'kadence-shop-kit' ),
				'type'     => 'checkbox',
				'default'  => 0,
			),
		),
	);

	return $wpsf_settings;
}
