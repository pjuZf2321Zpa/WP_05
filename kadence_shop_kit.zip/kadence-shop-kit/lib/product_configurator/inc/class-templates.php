<?php
/**
 * Templates class.
 *
 * @package Kadence_Woo_Extras
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Iconic_PC_Templates.
 *
 * @class    Iconic_PC_Templates
 * @version  1.0.0
 * @since    1.3.1
 * @author   Iconic
 */
class Iconic_PC_Templates {
	/**
	 * Output conditional layer.
	 *
	 * @param string                    $layer_id     The layer ID.
	 * @param array                     $attributes   The attributes array.
	 * @param null|array<string, mixed> $conditionals The conditionals array.
	 * @param null|int                  $condition_id The condition ID.
	 */
	public static function conditional_layer( $layer_id, $attributes, $conditionals = null, $condition_id = null ) {
		if ( is_null( $conditionals ) ) {
			$conditionals              = array();
			$conditionals[ $layer_id ] = array(
				array(
					'rules'  => array(),
					'values' => array(),
				),
			);
		}

		if ( ! isset( $conditionals[ $layer_id ] ) ) {
			return;
		}

		global $jckpc, $post;

		$field_name_prefix = 'jckpc_conditionals[' . $layer_id . ']';
		$current_attribute = str_replace( 'jckpc-', '', $layer_id );
		$layer_data        = isset( $attributes[ $current_attribute ] ) ? $attributes[ $current_attribute ] : null;
		$disable_inputs    = Iconic_PC_Helpers::maybe_disable_layer_inputs();
		/** @var array<int, array{rules: array<int, array{attribute: string, condition: string, value: string}>, values: array<string, mixed>}> $conditional_groups */
		$conditional_groups = $conditionals[ $layer_id ];
		?>

		<?php foreach ( $conditional_groups as $index => $data ) { ?>
			<?php $condition_id = 0 === $index && ! is_null( $condition_id ) ? $condition_id : $index; ?>

			<?php
			if ( empty( $data['rules'] ) ) {
				$data['rules'][] = array(
					'attribute' => '',
					'condition' => '',
					'value'     => '',
				);
			}
			?>

			<div class="iconic-pc-conditional-group">
				<div class="iconic-pc-conditional-group__header">
					<strong><?php echo esc_html( $layer_data['name'] ); ?>: <?php esc_html_e( 'Conditional Group', 'kadence-shop-kit' ); ?> <span class='iconic-pc-conditional-group__header-desc'></span></strong>
					<span class="iconic-pc-conditional-group__toggle"></span>
					<a href="javascript: void(0);" class="iconic-pc-conditional-group__remove"><?php esc_html_e( 'Remove', 'kadence-shop-kit' ); ?></a>
				</div>

				<div class="iconic-pc-conditional-group__content">
					<table class="iconic-pc-conditional-group__rules">
						<thead>
						<tr>
							<td colspan="4">
								<p><?php esc_html_e( 'Use these images when *all* of the following conditions are met:', 'kadence-shop-kit' ); ?></p>
							</td>
						</tr>
						</thead>
						<tbody>
						<?php foreach ( $data['rules'] as $rule_index => $rule ) { ?>
							<tr class="iconic-pc-conditional-group__rule">
								<td>
									<select <?php disabled( $disable_inputs, true ); ?> class="iconic-pc-conditional-group__attribute" name="<?php echo esc_attr( $field_name_prefix . '[' . $condition_id . '][rules][' . $rule_index . '][attribute]' ); ?>" id="">
										<option value=""><?php esc_html_e( 'Attribute', 'kadence-shop-kit' ); ?></option>
										<?php foreach ( $attributes as $attribute_slug => $attribute_data ) { ?>
											<?php
											if ( $attribute_slug === $current_attribute ) {
												continue;
											}
											?>
											<?php $slug = Iconic_PC_Helpers::sanitise_str( $attribute_slug ); ?>
											<option value="<?php echo esc_attr( $slug ); ?>" <?php selected( $slug, $rule['attribute'] ); ?>><?php echo esc_html( $attribute_data['name'] ); ?></option>
										<?php } ?>
									</select>
								</td>
								<td>
									<select <?php disabled( $disable_inputs, true ); ?> class="iconic-pc-conditional-group__condition" name="<?php echo esc_attr( $field_name_prefix . '[' . $condition_id . '][rules][' . $rule_index . '][condition]' ); ?>" id="">
										<option value="is_equal_to" <?php selected( 'is_equal_to', $rule['condition'] ); ?>><?php esc_html_e( 'is equal to', 'kadence-shop-kit' ); ?></option>
										<option value="is_not_equal_to" <?php selected( 'is_not_equal_to', $rule['condition'] ); ?>><?php esc_html_e( 'is not equal to', 'kadence-shop-kit' ); ?></option>
									</select>
								</td>
								<td>
									<select <?php disabled( $disable_inputs, true ); ?> class="iconic-pc-conditional-group__value" name="<?php echo esc_attr( $field_name_prefix . '[' . $condition_id . '][rules][' . $rule_index . '][value]' ); ?>" id="">
										<option value=""><?php esc_html_e( 'Value', 'kadence-shop-kit' ); ?></option>
										<?php foreach ( $attributes as $attribute_slug => $attribute_data ) { ?>
											<?php
											if ( $attribute_slug === $current_attribute ) {
												continue;
											}
											?>
											<optgroup data-slug="<?php echo esc_attr( 'jckpc-' . $attribute_slug ); ?>" label="<?php echo esc_attr( $attribute_data['name'] ); ?>">
												<?php foreach ( $attribute_data['values'] as $value_data ) { ?>
													<option value="<?php echo esc_attr( $value_data['att_val_json'] ); ?>" <?php selected( $value_data['att_val_json'], $rule['value'] ); ?>><?php echo esc_html( $value_data['att_val_name'] ); ?></option>
												<?php } ?>
											</optgroup>
										<?php } ?>
									</select>
								</td>
								<td>
									<a href="" class="iconic-pc-conditional-group__rule-remove"><?php esc_html_e( 'Remove', 'kadence-shop-kit' ); ?></a>
								</td>
							</tr>
						<?php } ?>
						</tbody>
						<tfoot>
						<tr>
							<td colspan="4">
								<button type="button" class="button iconic-pc-conditional-group__add-rule" data-iconic-pc-rule-id="<?php echo esc_attr( (string) count( $data['rules'] ) ); ?>"><?php esc_html_e( 'Add Condition', 'kadence-shop-kit' ); ?></button>
							</td>
						</tr>
						</tfoot>
					</table>

					<table class="widefat fixed iconic-pc-conditional-group__values">
						<thead>
						<tr>
							<th><?php esc_attr_e( 'Image', 'kadence-shop-kit' ); ?></th>
							<th><?php esc_attr_e( 'Value', 'kadence-shop-kit' ); ?></th>
						</tr>
						</thead>
						<tbody>
						<?php
						if ( is_array( $layer_data['values'] ) ) {
							$tr_i = 0;
							foreach ( $layer_data['values'] as $value ) {
								$row_name             = $value['att_val_name'];
								$attribute_value_slug = Iconic_PC_Helpers::sanitise_str( $value['att_val_slug'], $value['att_val_name'] );
								$field_name           = $field_name_prefix . '[' . $condition_id . '][values][' . $attribute_value_slug . ']';

								$field_id = sprintf( '%s_%s_image_condition_%d', $layer_id, Iconic_PC_Helpers::sanitise_str( $value['att_val_slug'] ), $condition_id );

								// Translators: 1: Attribute name, 2: Attribute value name.
								$popup_title       = sprintf( __( 'Set conditional image for when %1$s is %2$s', 'kadence-shop-kit' ), esc_attr( $layer_data['name'] ), esc_attr( $value['att_val_name'] ) );
								$popup_button_text = __( 'Set Image', 'kadence-shop-kit' );
								$button_text       = __( 'Add Image', 'kadence-shop-kit' );
								$classes           = ( 0 === $tr_i % 2 ) ? 'alternate' : '';
								$value             = isset( $data['values'][ $attribute_value_slug ] ) ? $data['values'][ $attribute_value_slug ] : '';

								// phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped
								echo $jckpc->image_upload_row(
									array(
										'row_name'       => $row_name,
										'field_name'     => $field_name,
										'field_id'       => $field_id,
										'selected_image_id' => $value,
										'popup_title'    => $popup_title,
										'popup_button_text' => $popup_button_text,
										'button_text'    => $button_text,
										'classes'        => array( $classes ),
										'show_inventory' => false,
									)
								);
								// phpcs:enable WordPress.Security.EscapeOutput.OutputNotEscaped

								unset( $row_name, $field_name, $field_id, $popup_title, $popup_button_text, $button_text, $classes, $value );

								++$tr_i;
							}
						}
						?>
						</tbody>
					</table>
				</div>
			</div>
		<?php } ?>
		<?php
	}
}