<?php
/**
 * Stubs for third-party code.
 *
 * @package Iconic_PC
 */

// phpcs:disable Universal.Namespaces.DisallowCurlyBraceSyntax.Forbidden, Universal.Namespaces.DisallowDeclarationWithoutName.Forbidden, Universal.Namespaces.OneDeclarationPerFile.MultipleFound, Universal.Files.SeparateFunctionsFromOO.Mixed

namespace {
	/**
	 * Get the element in the current language
	 *
	 * @param int         $element_id                 Use term_id for taxonomies, post_id for posts.
	 * @param string      $element_type               Use post, page, {custom post type name}, nav_menu, nav_menu_item, category, tag, etc.
	 *                                                You can also pass 'any', to let WPML guess the type, but this will only work for posts.
	 * @param bool        $return_original_if_missing Optional, default is FALSE. If set to true it will always return a value (the original value, if translation is missing).
	 * @param string|NULL $language_code              Optional, default is NULL. If missing, it will use the current language.
	 *                                                If set to a language code, it will return a translation for that language code or
	 *                                                the original if the translation is missing and $return_original_if_missing is set to TRUE.
	 *
	 * @return int|NULL
	 * @since 3.2
	 *
	 * @uses  \SitePress::api_hooks
	 */
	function wpml_object_id_filter( $element_id, $element_type = 'post', $return_original_if_missing = false, $language_code = null ) { // phpcs:ignore Squiz.Commenting.FunctionComment.InvalidNoReturn, Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed
		return null;
	}
}

namespace Bricks {

	/**
	 * Bricks Database stub.
	 */
	class Database {
		/**
		 * Global settings.
		 *
		 * @var array
		 */
		public static $global_settings = array();
	}

}
