<?php
/**
 * WDS Settings.
 *
 * @package Iconic_WDS
 */

use Iconic_WDS\Settings;

add_filter( 'wpsf_register_settings_jckwds', 'jckwds_settings' );

/**
 * Delivery Slots Settings
 *
 * @param array $wpsf_settings Settings.
 *
 * @return array
 */
function jckwds_settings( $wpsf_settings ) {
	global $jckwds;

	if ( ! $jckwds || ! function_exists( 'WC' ) ) {
		return $wpsf_settings;
	}

	$date_format = Iconic_WDS_Core_Settings::get_setting_from_db( 'datesettings_datesettings', 'dateformat' );
	$date_format = $date_format ? $date_format : 'dd/mm/yy';

	// Tabs.

	$wpsf_settings['tabs'][] = array(
		'id'    => 'general',
		'title' => __( 'General Settings', 'kadence-shop-kit' ),
	);

	$wpsf_settings['tabs'][] = array(
		'id'    => 'datesettings',
		'title' => __( 'Date Settings', 'kadence-shop-kit' ),
	);

	$wpsf_settings['tabs'][] = array(
		'id'    => 'timesettings',
		'title' => __( 'Time Settings', 'kadence-shop-kit' ),
	);

	$wpsf_settings['tabs'][] = array(
		'id'    => 'holidays',
		'title' => __( 'Holidays', 'kadence-shop-kit' ),
	);

	$wpsf_settings['tabs'][] = array(
		'id'    => 'reservations',
		'title' => __( 'Reservation Table', 'kadence-shop-kit' ),
	);

	$wpsf_settings['tabs'][] = array(
		'id'    => 'advance',
		'title' => __( 'Advanced', 'kadence-shop-kit' ),
	);

	// Sections.

	$wpsf_settings['sections'][] = array(
		'tab_id'              => 'general',
		'section_id'          => 'setup',
		'section_title'       => __( 'General Setup', 'kadence-shop-kit' ),
		'section_description' => '',
		'section_order'       => 0,
		'fields'              => array(
			array(
				'id'       => 'position',
				'title'    => __( 'Checkout Fields Position', 'kadence-shop-kit' ),
				'subtitle' => __( 'Where should the date and time fields show on the checkout page?', 'kadence-shop-kit' ),
				'type'     => 'select',
				'default'  => 'woocommerce_checkout_order_review',
				'choices'  => Settings::get_field_position_choices(),
			),
			array(
				'id'          => 'position_priority',
				'title'       => __( 'Checkout Fields Position Priority', 'kadence-shop-kit' ),
				'subtitle'    => __( 'Enter a number of priority, e.g. 10 is early/before, 50 is late/after', 'kadence-shop-kit' ),
				'type'        => 'number',
				'default'     => '10',
				'placeholder' => '',
			),
			array(
				'id'          => 'display_for_virtual',
				'title'       => __( 'Display Fields Even When Shipping Is Not Required?', 'kadence-shop-kit' ),
				'subtitle'    => __( 'Should we display the date and time fields even if shipping is not required at checkout?', 'kadence-shop-kit' ),
				'type'        => 'checkbox',
				'default'     => 0,
				'placeholder' => '',
			),
			array(
				'id'       => 'max_order_calculation_method',
				'title'    => __( 'Max Orders Calculation Method', 'kadence-shop-kit' ),
				'subtitle' => __( 'Determine maximum orders limit by the number of orders placed or number of products purchased.', 'kadence-shop-kit' ),
				'type'     => 'select',
				'default'  => 'orders',
				'choices'  => Settings::get_max_order_calculation_methods(),
			),
			array(
				'id'       => 'max_orders_exclude_products',
				'title'    => __( 'Exclude Products from Max Order Limit', 'kadence-shop-kit' ),
				'subtitle' => __( 'Add product(s) the Max Orders Calculation will not be applied to.', 'kadence-shop-kit' ),
				'type'     => 'custom',
				'default'  => array(),
				'output'   => Settings::get_products_search_field( 'general_setup', 'max_orders_exclude_products' ),
			),
			array(
				'id'       => 'labels',
				'title'    => __( 'Default Labels', 'kadence-shop-kit' ),
				'subtitle' => __( 'Select which labels to use for the delivery slots checkout fields. You can override these based on the select shipping method below.', 'kadence-shop-kit' ),
				'type'     => 'select',
				'default'  => 'delivery',
				'choices'  => array(
					'delivery'   => __( 'Delivery', 'kadence-shop-kit' ),
					'collection' => __( 'Collection', 'kadence-shop-kit' ),
				),
			),
			array(
				'id'       => 'shipping_methods',
				'title'    => __( 'Shipping Methods', 'kadence-shop-kit' ),
				'subtitle' => __( 'Enable delivery slots for the following shipping methods.', 'kadence-shop-kit' ),
				'type'     => 'custom',
				'default'  => array( 'any' ),
				'output'   => Settings::get_field_labels_by_shipping_method(),
			),
			array(
				'id'       => 'exclude_products',
				'title'    => __( 'Exclude Products', 'kadence-shop-kit' ),
				'subtitle' => __( 'If these products are in the cart, delivery date selection will be disabled.', 'kadence-shop-kit' ),
				'type'     => 'custom',
				'default'  => array(),
				'output'   => Settings::get_products_search_field( 'general_setup', 'exclude_products' ),
			),
			array(
				'id'       => 'exclude_products_condition',
				'title'    => __( 'Exclude Product Condition', 'kadence-shop-kit' ),
				'subtitle' => __( 'Disable delivery date selection when any/all of the excluded products are in the cart.', 'kadence-shop-kit' ),
				'type'     => 'select',
				'choices'  => array(
					'any' => 'Any',
					'all' => 'All',
				),
				'default'  => 'any',
			),
			array(
				'id'          => 'exclude_categories',
				'title'       => __( 'Exclude Categories', 'kadence-shop-kit' ),
				'subtitle'    => __( 'If a product from these categories is in the cart, delivery date selection will be disabled.', 'kadence-shop-kit' ),
				'type'        => 'checkboxes',
				'default'     => '',
				'placeholder' => '',
				'choices'     => Settings::get_category_options(),
			),
			array(
				'id'       => 'exclude_categories_condition',
				'title'    => __( 'Exclude Category Condition', 'kadence-shop-kit' ),
				'subtitle' => __( 'Disable delivery date selection when any/all products in the cart have at least 1 excluded category.', 'kadence-shop-kit' ),
				'type'     => 'select',
				'choices'  => array(
					'any' => 'Any',
					'all' => 'All',
				),
				'default'  => 'any',
			),
		),
	);

	$wpsf_settings['sections'][] = array(
		'tab_id'              => 'general',
		'section_id'          => 'customer',
		'section_title'       => __( 'Customer Time Slot Management', 'kadence-shop-kit' ),
		'section_description' => '',
		'section_order'       => 0,
		'fields'              => array(
			array(
				'id'          => 'display_on_thankyou_page',
				'title'       => __( 'Allow customers to update time slots from the Order Received page', 'kadence-shop-kit' ),
				'subtitle'    => __( 'Adds updatable time slot fields to the Order Received/Thank You page after customers have placed an order.<br><br>Or only adds updatable time slot fields if the customer receives a reminder email. See Reminder Email settings below.', 'kadence-shop-kit' ),
				'type'        => 'select',
				'choices'     => array(
					'always'         => esc_html__( 'Allow always', 'kadence-shop-kit' ),
					'reminders_only' => esc_html__( 'Allow for reminder emails only', 'kadence-shop-kit' ),
				),
				'default'     => 0,
				'placeholder' => '',
			),
			array(
				'id'          => 'display_on_myaccount_order_page',
				'title'       => __( 'Allow customers to update time slots from the My Account Order page.', 'kadence-shop-kit' ),
				'subtitle'    => __( 'Adds updatable time slot fields to the customer’s \'My Account > Orders > View Order\' page.', 'kadence-shop-kit' ),
				'type'        => 'select',
				'choices'     => array(
					'allow' => esc_html__( 'Allow', 'kadence-shop-kit' ),
					'dont'  => esc_html__( "Don't Allow", 'kadence-shop-kit' ),
				),
				'default'     => 'dont',
				'placeholder' => '',
			),
			array(
				'id'       => 'editing_window',
				'title'    => __( 'Time Slot Editing Window', 'kadence-shop-kit' ),
				'subtitle' => __( 'Let customers edit their time slot selection up until X minutes/hours/days before their currently selected timeslot.<br><br>Leave the field empty to allow customers to update their timeslots anytime until the delivery time.', 'kadence-shop-kit' ),
				'type'     => 'custom',
				'default'  => array(
					'number' => '1',
					'unit'   => 'days',
				),
				'output'   => Settings::get_field_timeslot_editing_window(),
			),
			array(
				'id'       => 'charge_fee_difference',
				'title'    => __( 'Charge Fee Difference', 'kadence-shop-kit' ),
				'subtitle' => __( 'Require customers to pay a fee for the difference when the new timeslot\'s fee is more than the previously selected timeslot.', 'kadence-shop-kit' ),
				'type'     => 'checkbox',
				'default'  => '1',
			),
			array(
				'id'       => 'threshold',
				'title'    => __( 'Fee Difference Threshold', 'kadence-shop-kit' ),
				// Translators: The currency.
				'subtitle' => sprintf( __( 'Only prompt the customer to pay for the fee difference if the fee difference exceeds this amount (%s).', 'kadence-shop-kit' ), get_woocommerce_currency() ),
				'type'     => 'number',
				'default'  => '1',
				'show_if'  => array(
					array(
						'field' => 'general_customer_charge_fee_difference',
						'value' => array( '1' ),
					),
				),
			),
		),
	);

	$wpsf_settings['sections'][] = array(
		'tab_id'              => 'general',
		'section_id'          => 'email_reminders',
		'section_title'       => __( 'Reminder Email', 'kadence-shop-kit' ),
		'section_description' => '',
		'section_order'       => 0,
		'fields'              => array(
			array(
				'id'       => 'enable_reminders',
				'title'    => __( 'Enable Reminders', 'kadence-shop-kit' ),
				'subtitle' => __( 'Turn on email reminders for customers who have not selected a delivery date/time during checkout.<br><br>Especially helpful for orders placed with express checkout payment methods like Google Pay, Apple Pay, and PayPal Express checkout.', 'kadence-shop-kit' ),
				'type'     => 'checkbox',
			),
			array(
				'id'       => 'duration',
				'title'    => __( 'Reminder Frequency Duration', 'kadence-shop-kit' ),
				'subtitle' => __( 'Set the frequency for sending automated email reminders to customers.', 'kadence-shop-kit' ),
				'type'     => 'custom',
				'output'   => Settings::get_reminder_duration_fields(),
				'default'  => 12,
			),
			array(
				'id'       => 'max_emails',
				'title'    => __( 'Maximum Number of Reminders', 'kadence-shop-kit' ),
				'subtitle' => __( 'Set the maximum number of email reminders sent to each customer.', 'kadence-shop-kit' ),
				'type'     => 'number',
				'default'  => 3,
			),
			array(
				'id'       => 'email_text',
				'title'    => __( 'Email Text', 'kadence-shop-kit' ),
				'subtitle' => __( 'Customize the content of the email reminder.<br><br>Available placeholders: {SITE_NAME}, {ORDER_ID}, {ORDER_NUMBER}, {ORDER_DATE_TIME}, {CUSTOMER_NAME}, {CUSTOMER_EMAIL}, {CUSTOMER_ADDRESS}, {CUSTOMER_PHONE}, {NOTE}, {CART_ITEMS}, {THANKYOU_URL} ', 'kadence-shop-kit' ),
				'type'     => 'textarea',
				'default'  => "Hello {CUSTOMER_NAME}, thank you for your order.\n\nPlease select the delivery timeslot for your order #{ORDER_ID} by clicking on the URL below.\n\n{THANKYOU_URL}\n\nThanks,\n\n{SITE_NAME}",
			),
		),
	);

	$wpsf_settings['sections'][] = array(
		'tab_id'              => 'datesettings',
		'section_id'          => 'datesettings_setup',
		'section_title'       => __( 'Date Setup', 'kadence-shop-kit' ),
		'section_description' => '',
		'section_order'       => 0,
		'fields'              => array(
			array(
				'id'          => 'mandatory',
				'title'       => __( 'Required', 'kadence-shop-kit' ),
				'subtitle'    => __( 'Is the delivery date a required field at checkout?', 'kadence-shop-kit' ),
				'type'        => 'checkbox',
				'default'     => 1,
				'placeholder' => '',
			),
			array(
				'id'          => 'show_description',
				'title'       => __( 'Show Description?', 'kadence-shop-kit' ),
				'type'        => 'checkbox',
				'default'     => 0,
				'placeholder' => '',
			),
			array(
				'id'          => 'auto_select_first',
				'title'       => __( 'Auto-select first available date?', 'kadence-shop-kit' ),
				'subtitle'    => __( 'The first available date will be automatically selected.', 'kadence-shop-kit' ),
				'type'        => 'checkbox',
				'default'     => 0,
				'placeholder' => '',
			),
			array(
				'id'          => 'uitheme',
				'title'       => __( 'Theme', 'kadence-shop-kit' ),
				'subtitle'    => __( 'Select a theme for the front-end calendar at checkout.', 'kadence-shop-kit' ),
				'type'        => 'select',
				'default'     => 'dark',
				'placeholder' => '',
				'choices'     => array(
					'dark'  => __( 'Dark', 'kadence-shop-kit' ),
					'light' => __( 'Light', 'kadence-shop-kit' ),
					'none'  => __( 'None', 'kadence-shop-kit' ),
				),
			),
		),
	);

	$wpsf_settings['sections'][] = array(
		'tab_id'              => 'datesettings',
		'section_id'          => 'datesettings',
		'section_title'       => __( 'Date Settings', 'kadence-shop-kit' ),
		'section_description' => '',
		'section_order'       => 10,
		'fields'              => array(
			array(
				'id'       => 'days',
				'title'    => __( 'Delivery Days', 'kadence-shop-kit' ),
				'subtitle' => __( 'Which days do you deliver, and how many orders can you accept on any given day? Leave maximum orders blank for "unlimited".', 'kadence-shop-kit' ),
				'type'     => 'custom',
				'default'  => array( 0, 1, 2, 3, 4, 5, 6 ),
				'output'   => Settings::get_delivery_days_fields(),
			),
			array(
				'id'        => 'specific_days',
				'title'     => __( 'Specific Delivery Days', 'kadence-shop-kit' ),
				'subtitle'  => __( 'Enter any specific days you would like to enable for delivery or collection.', 'kadence-shop-kit' ),
				'type'      => 'group',
				'default'   => array(
					array(
						'row_id' => uniqid(),
					),
				),
				'subfields' => array(
					array(
						'id'         => 'date',
						'title'      => __( 'Date', 'kadence-shop-kit' ),
						'type'       => 'date',
						'datepicker' => array(
							'dateFormat' => $date_format,
							'altFormat'  => 'yy-mm-dd',
							'altField'   => '#datesettings_datesettings_specific_days_0_alt_date',
						),
					),
					array(
						'id'    => 'alt_date',
						'title' => __( 'From', 'kadence-shop-kit' ),
						'type'  => 'hidden',
					),
					array(
						'id'          => 'fee',
						// Translators: currency symbol.
						'title'       => sprintf( __( 'Fee (%s)', 'kadence-shop-kit' ), get_woocommerce_currency_symbol() ),
						'subtitle'    => '',
						'type'        => 'number',
						'placeholder' => 'E.g. 3.00',
					),
					array(
						'id'       => 'lockout',
						'title'    => __( 'Maximum Orders', 'kadence-shop-kit' ),
						'subtitle' => __( 'Enter the maximum number of orders allowed for this date.', 'kadence-shop-kit' ),
						'type'     => 'number',
						'default'  => '',
					),
					array(
						'id'      => 'repeat_yearly',
						'title'   => '',
						'desc'    => __( 'Repeat every year?', 'kadence-shop-kit' ),
						'type'    => 'checkbox',
						'default' => '',
					),
					array(
						'id'      => 'bypass_max',
						'title'   => '',
						'desc'    => __( 'Bypass max selectable date setting?', 'kadence-shop-kit' ),
						'type'    => 'checkbox',
						'default' => '',
					),
				),
			),
			array(
				'id'          => 'minmaxmethod',
				'title'       => __( 'Delivery Days Calculation Method', 'kadence-shop-kit' ),
				'subtitle'    => __( 'Calculate minimum, maximum, same day, and next day delivery dates based on all days of the week, selected days only, or weekdays only.', 'kadence-shop-kit' ),
				'type'        => 'select',
				'default'     => 'allowed',
				'placeholder' => '',
				'choices'     => array(
					'allowed'  => 'Selected Days Only',
					'all'      => 'All Days',
					'weekdays' => 'Weekdays Only',
				),
			),
			array(
				'id'          => 'skip_current',
				'title'       => __( 'Skip Current Day if Not a Selected Delivery Day?', 'kadence-shop-kit' ),
				'subtitle'    => __( 'When checked, same day delivery will be classed as the next available delivery day.', 'kadence-shop-kit' ),
				'type'        => 'checkbox',
				'default'     => 0,
				'placeholder' => '',
			),
			array(
				'id'          => 'minimum',
				'title'       => __( 'Lead Time', 'kadence-shop-kit' ),
				'subtitle'    => __( 'Days from now. Enter "0" for same day.', 'kadence-shop-kit' ),
				'type'        => 'text',
				'default'     => '2',
				'placeholder' => '',
			),
			array(
				'id'          => 'maximum',
				'title'       => __( 'Maximum Selectable Date', 'kadence-shop-kit' ),
				'subtitle'    => __( 'Days from now.', 'kadence-shop-kit' ),
				'type'        => 'text',
				'default'     => '14',
				'placeholder' => '',
			),
			array(
				'id'         => 'sameday_cutoff',
				'title'      => __( 'Disable Same Day Delivery if Current Time is After (x)', 'kadence-shop-kit' ),
				'type'       => 'time',
				'timepicker' => array(
					'amPmText' => array(
						__( 'AM', 'kadence-shop-kit' ),
						__( 'PM', 'kadence-shop-kit' ),
					),
				),
			),
			array(
				'id'         => 'nextday_cutoff',
				'title'      => __( 'Disable Next Day Delivery if Current Time is After (x)', 'kadence-shop-kit' ),
				'type'       => 'time',
				'timepicker' => array(
					'amPmText' => array(
						__( 'AM', 'kadence-shop-kit' ),
						__( 'PM', 'kadence-shop-kit' ),
					),
				),
			),
			array(
				'id'          => 'week_limit',
				'title'       => __( 'Only Allow Deliveries Within the Current Week?', 'kadence-shop-kit' ),
				'type'        => 'checkbox',
				'default'     => 0,
				'placeholder' => '',
			),
			array(
				'id'          => 'last_day_of_week',
				'title'       => __( 'Last Day of the Week', 'kadence-shop-kit' ),
				'subtitle'    => '',
				'type'        => 'select',
				'placeholder' => '',
				'choices'     => array(
					'sunday'    => __( 'Sunday', 'kadence-shop-kit' ),
					'monday'    => __( 'Monday', 'kadence-shop-kit' ),
					'tuesday'   => __( 'Tuesday', 'kadence-shop-kit' ),
					'wednesday' => __( 'Wednesday', 'kadence-shop-kit' ),
					'thursday'  => __( 'Thursday', 'kadence-shop-kit' ),
					'friday'    => __( 'Friday', 'kadence-shop-kit' ),
					'saturday'  => __( 'Saturday', 'kadence-shop-kit' ),
				),
				'default'     => 'sunday',
			),
			array(
				'id'          => 'dateformat',
				'title'       => __( 'Date Format', 'kadence-shop-kit' ),
				'subtitle'    => __( 'Available formats can be found <a href="http://api.jqueryui.com/datepicker/#utility-formatDate" target="_blank">here</a>.', 'kadence-shop-kit' ),
				'type'        => 'text',
				'default'     => 'dd/mm/yy',
				'placeholder' => '',
			),
		),
	);

	$wpsf_settings['sections'][] = array(
		'tab_id'              => 'datesettings',
		'section_id'          => 'fees',
		'section_title'       => __( 'Fees', 'kadence-shop-kit' ),
		'section_description' => '',
		'section_order'       => 20,
		'fields'              => array(
			array(
				'id'       => 'days',
				'title'    => sprintf( '%s (%s)', __( 'Days', 'kadence-shop-kit' ), get_woocommerce_currency_symbol() ),
				'subtitle' => __( 'Fees applied to specific days of the week.', 'kadence-shop-kit' ),
				'type'     => 'custom',
				'default'  => array(),
				'output'   => Settings::get_day_fees_fields(),
			),
			array(
				'id'          => 'same_day',
				'title'       => sprintf( '%s (%s)', __( 'Same Day', 'kadence-shop-kit' ), get_woocommerce_currency_symbol() ),
				'subtitle'    => __( 'Fee applied when a same day delivery is selected.', 'kadence-shop-kit' ),
				'type'        => 'number',
				'default'     => '',
				'placeholder' => __( 'E.g. 3.00', 'kadence-shop-kit' ),
			),
			array(
				'id'          => 'next_day',
				'title'       => sprintf( '%s (%s)', __( 'Next Day', 'kadence-shop-kit' ), get_woocommerce_currency_symbol() ),
				'subtitle'    => __( 'Fee applied when a next day delivery is selected.', 'kadence-shop-kit' ),
				'type'        => 'number',
				'default'     => '',
				'placeholder' => __( 'E.g. 3.00', 'kadence-shop-kit' ),
			),
		),
	);

	$wpsf_settings['sections'][] = array(
		'tab_id'              => 'timesettings',
		'section_id'          => 'timesettings_setup',
		'section_title'       => __( 'Time Setup', 'kadence-shop-kit' ),
		'section_description' => '',
		'section_order'       => 0,
		'fields'              => array(
			array(
				'id'          => 'enable',
				'title'       => __( 'Enable Time Slots', 'kadence-shop-kit' ),
				'subtitle'    => __( 'Check this box to enable time slots at checkout.', 'kadence-shop-kit' ),
				'type'        => 'checkbox',
				'default'     => 1,
				'placeholder' => '',
			),
			array(
				'id'          => 'mandatory',
				'title'       => __( 'Required', 'kadence-shop-kit' ),
				'subtitle'    => __( 'Is the time slot a required field at checkout?', 'kadence-shop-kit' ),
				'type'        => 'checkbox',
				'default'     => 1,
				'placeholder' => '',
			),
			array(
				'id'          => 'show_description',
				'title'       => __( 'Show Description?', 'kadence-shop-kit' ),
				'type'        => 'checkbox',
				'default'     => 0,
				'placeholder' => '',
			),
			array(
				'id'          => 'auto_select_first',
				'title'       => __( 'Auto-select first available time slot?', 'kadence-shop-kit' ),
				'subtitle'    => __( 'The first available time slot will be automatically selected.', 'kadence-shop-kit' ),
				'type'        => 'checkbox',
				'default'     => 0,
				'placeholder' => '',
			),
			array(
				'id'          => 'timeformat',
				'title'       => __( 'Time Format', 'kadence-shop-kit' ),
				'subtitle'    => __( 'Select a time format for the frontend.', 'kadence-shop-kit' ),
				'type'        => 'select',
				'default'     => 'H:i A',
				'placeholder' => '',
				'choices'     => array(
					'H:i A' => '13:30 PM',
					'H:i'   => '13:30',
					'h:i A' => '01:30 PM',
				),
			),
		),
	);

	$wpsf_settings['sections'][] = array(
		'tab_id'              => 'timesettings',
		'section_id'          => 'timesettings_asap',
		'section_title'       => __( 'ASAP Delivery', 'kadence-shop-kit' ),
		'section_description' => '',
		'section_order'       => 0,
		'fields'              => array(
			array(
				'id'          => 'enable',
				'title'       => __( 'Enable ASAP Delivery', 'kadence-shop-kit' ),
				'subtitle'    => __( 'Allow your customers to choose ASAP for their selected delivery date, or a time slot.', 'kadence-shop-kit' ),
				'type'        => 'checkbox',
				'default'     => 0,
				'placeholder' => '',
			),
			array(
				'id'       => 'lockout',
				'title'    => __( 'Maximum Orders', 'kadence-shop-kit' ),
				'subtitle' => __( 'Enter the maximum number of orders allowed for the ASAP time slot.', 'kadence-shop-kit' ),
				'type'     => 'number',
				'default'  => '',
			),
			array(
				'id'          => 'fee',
				'title'       => __( 'ASAP Fee', 'kadence-shop-kit' ),
				'subtitle'    => __( 'Fee applied when an ASAP delivery time is selected.', 'kadence-shop-kit' ),
				'type'        => 'number',
				'default'     => '',
				'placeholder' => __( 'E.g. 3.00', 'kadence-shop-kit' ),
			),
			array(
				'id'         => 'cutoff',
				'title'      => __( 'Same Day Cut Off', 'kadence-shop-kit' ),
				'subtitle'   => __( 'Disable same day ASAP delivery slot if current time is after (x).', 'kadence-shop-kit' ),
				'type'       => 'time',
				'timepicker' => array(
					'amPmText' => array(
						__( 'AM', 'kadence-shop-kit' ),
						__( 'PM', 'kadence-shop-kit' ),
					),
				),
			),
		),
	);

	$wpsf_settings['sections']['timesettings'] = array(
		'tab_id'              => 'timesettings',
		'section_id'          => 'timesettings',
		'section_title'       => __( 'Time Slot Configuration', 'kadence-shop-kit' ),
		'section_description' => '',
		'section_order'       => 10,
		'fields'              => array(
			array(
				'id'          => 'calculate_tax',
				'title'       => __( 'Calculate Tax?', 'kadence-shop-kit' ),
				'subtitle'    => __( 'Check this box to calculate tax on time slot fees. If enabled, fees should be entered exclusive of tax.', 'kadence-shop-kit' ),
				'type'        => 'checkbox',
				'default'     => 0,
				'placeholder' => '',
			),
			array(
				'id'          => 'cutoff',
				'title'       => __( 'Allow Bookings Up To (x) Minutes Before Slot', 'kadence-shop-kit' ),
				'subtitle'    => __( 'This option will prevent bookings being made too close to the delivery time. Can be overridden on an individual time slot basis. (Check your timezone in WordPress Settings).', 'kadence-shop-kit' ),
				'type'        => 'text',
				'default'     => '30',
				'placeholder' => '',
			),
			'timeslots' => array(
				'id'        => 'timeslots',
				'title'     => __( 'Time Slots', 'kadence-shop-kit' ),
				'subtitle'  => __( 'Fill the Slot Duration and Slot Frequency fields to dynamically generate slots. Leave them empty to create a single time slot.<br><br>Use "24:00" to represent the end of the day.', 'kadence-shop-kit' ),
				'type'      => 'group',
				'row_title' => __( 'Time Slot', 'kadence-shop-kit' ),
				'format'    => 'table',
				'default'   => array(
					array(
						'row_id'           => uniqid(),
						'duration'         => 30,
						'frequency'        => 30,
						'timefrom'         => '07:00',
						'timeto'           => '10:00',
						'cutoff'           => '',
						'lockout'          => 4,
						'shipping_methods' => array( 'any' ),
						'fee'              => '',
						'days'             => array( 0, 1, 2, 3, 4, 5, 6 ),
					),
					array(
						'row_id'           => uniqid(),
						'duration'         => '',
						'frequency'        => '',
						'timefrom'         => '12:00',
						'timeto'           => '14:00',
						'cutoff'           => '',
						'lockout'          => 2,
						'shipping_methods' => array( 'any' ),
						'fee'              => 5,
						'days'             => array( 1, 5 ),
					),
				),
				'subfields' => array(
					array(
						'id'          => 'duration',
						'title'       => __( 'Slot Duration - (x) Minutes per Slot', 'kadence-shop-kit' ),
						'subtitle'    => '',
						'type'        => 'number',
						'placeholder' => '',
					),
					array(
						'id'          => 'frequency',
						'title'       => __( 'Slot Frequency - Every (x) Minutes', 'kadence-shop-kit' ),
						'subtitle'    => '',
						'type'        => 'number',
						'placeholder' => '',
					),
					array(
						'id'         => 'timefrom',
						'title'      => __( 'From', 'kadence-shop-kit' ),
						'type'       => 'time',
						'timepicker' => array(
							'amPmText' => array(
								__( 'AM', 'kadence-shop-kit' ),
								__( 'PM', 'kadence-shop-kit' ),
							),
						),
					),
					array(
						'id'         => 'timeto',
						'title'      => __( 'To', 'kadence-shop-kit' ),
						'subtitle'   => '24:00 can be used to represent end of the day.',
						'type'       => 'time',
						'timepicker' => array(
							'amPmText' => array(
								__( 'AM', 'kadence-shop-kit' ),
								__( 'PM', 'kadence-shop-kit' ),
							),
						),
					),
					array(
						'id'          => 'cutoff',
						'title'       => __( 'Allow Bookings Up To (x) Minutes Before Slot', 'kadence-shop-kit' ),
						'subtitle'    => '',
						'type'        => 'number',
						'placeholder' => '',
					),
					array(
						'id'       => 'cutoff_based_on',
						'title'    => __( 'Cutoff time based on', 'kadence-shop-kit' ),
						'subtitle' => '',
						'type'     => 'select',
						'choices'  => array(
							'from' => __( 'From time', 'kadence-shop-kit' ),
							'to'   => __( 'To time', 'kadence-shop-kit' ),
						),
						'default'  => 'from',
					),
					array(
						'id'          => 'lockout',
						'title'       => __( 'Maximum Orders per Time Slot', 'kadence-shop-kit' ),
						'subtitle'    => '',
						'type'        => 'number',
						'placeholder' => '',
					),
					'postcodes' => array(
						'id'          => 'postcodes',
						'title'       => __( 'Postcodes', 'kadence-shop-kit' ),
						'type'        => 'text',
						'placeholder' => '',
					),
					array(
						'id'          => 'fee',
						// Translators: currency symbol.
						'title'       => sprintf( __( 'Fee (%s)', 'kadence-shop-kit' ), get_woocommerce_currency_symbol() ),
						'subtitle'    => '',
						'type'        => 'number',
						'placeholder' => 'E.g. 3.00',
					),
					array(
						'id'          => 'days',
						'title'       => __( 'Days', 'kadence-shop-kit' ),
						'subtitle'    => '',
						'type'        => 'checkboxes',
						'placeholder' => '',
						'default'     => array( 0, 1, 2, 3, 4, 5, 6 ),
						'choices'     => Settings::get_time_slot_day_choices(),
					),
				),
			),
		),
	);

	$wpsf_settings['sections'][] = array(
		'tab_id'              => 'holidays',
		'section_id'          => 'holidays',
		'section_title'       => __( 'Holidays', 'kadence-shop-kit' ),
		'section_description' => __( 'Please add any holidays where deliveries should not be made.', 'kadence-shop-kit' ),
		'section_order'       => 0,
		'fields'              => array(
			array(
				'id'        => 'holidays',
				'title'     => __( 'Holidays', 'kadence-shop-kit' ),
				'subtitle'  => __( 'For single days, just enter a date in the "From" field. For ranges, enter a "From" and "To" date. Ranges are up to and including the dates you enter.', 'kadence-shop-kit' ),
				'type'      => 'group',
				'row_title' => __( 'Holiday', 'kadence-shop-kit' ),
				'format'    => 'table',
				'subfields' => array(
					array(
						'id'         => 'date',
						'title'      => __( 'From', 'kadence-shop-kit' ),
						'type'       => 'date',
						'datepicker' => array(
							'dateFormat' => $date_format,
							'altFormat'  => 'dd/mm/yy',
							'altField'   => '#holidays_holidays_holidays_0_alt_date',
						),
					),
					array(
						'id'    => 'alt_date',
						'title' => __( 'From', 'kadence-shop-kit' ),
						'type'  => 'hidden',
					),
					array(
						'id'         => 'date_to',
						'title'      => __( 'To', 'kadence-shop-kit' ),
						'type'       => 'date',
						'datepicker' => array(
							'dateFormat' => $date_format,
							'altFormat'  => 'dd/mm/yy',
							'altField'   => '#holidays_holidays_holidays_0_alt_date_to',
						),
					),
					array(
						'id'    => 'alt_date_to',
						'title' => __( 'to', 'kadence-shop-kit' ),
						'type'  => 'hidden',
					),
					array(
						'id'          => 'shipping_methods',
						'title'       => __( 'Shipping Methods', 'kadence-shop-kit' ),
						'subtitle'    => '',
						'type'        => 'checkboxes',
						'placeholder' => '',
						'choices'     => $jckwds->get_shipping_method_options(),
					),
					array(
						'id'          => 'name',
						'title'       => __( 'Name', 'kadence-shop-kit' ),
						'subtitle'    => '',
						'type'        => 'text',
						'default'     => '',
						'placeholder' => __( 'e.g. Christmas', 'kadence-shop-kit' ),
					),
					array(
						'id'      => 'repeat_yearly',
						'title'   => '',
						'desc'    => __( 'Repeat every year?', 'kadence-shop-kit' ),
						'type'    => 'checkbox',
						'default' => '',
					),
				),
			),
		),
	);

	$wpsf_settings['sections'][] = array(
		'tab_id'              => 'reservations',
		'section_id'          => 'reservations',
		'section_title'       => __( 'Reservations', 'kadence-shop-kit' ),
		'section_description' => __( 'You can insert a reservation table using the shortcode <strong>[kt_ds_reservation_table]</strong>. This allows your customers to reserve a delivery time and date while they shop. <strong>Note:</strong> Time Slots should be enabled if you want to use the reservation table.', 'kadence-shop-kit' ),
		'section_order'       => 0,
		'fields'              => array(
			array(
				'id'          => 'expires',
				'title'       => __( 'Expiration', 'kadence-shop-kit' ),
				'subtitle'    => __( 'Reservations expire after (x) Minutes.', 'kadence-shop-kit' ),
				'type'        => 'text',
				'default'     => '30',
				'placeholder' => '30',
			),
			array(
				'id'          => 'remaining_label_threshold',
				'title'       => __( 'Remaining Label Threshold', 'kadence-shop-kit' ),
				'subtitle'    => __( 'Show "x Remaining" label when available timeslots become less than this threshold. Set -1 to disable.', 'kadence-shop-kit' ),
				'type'        => 'text',
				'default'     => '2',
				'placeholder' => '2',
			),
			array(
				'id'          => 'hide_unavailable_dates',
				'title'       => __( 'Hide Unavailable Dates?', 'kadence-shop-kit' ),
				'subtitle'    => __( 'Check this box to hide any dates if there are no available time slots.', 'kadence-shop-kit' ),
				'type'        => 'checkbox',
				'default'     => 0,
				'placeholder' => '',
			),
			array(
				'id'          => 'redirect_url',
				'title'       => __( 'Redirect URL', 'kadence-shop-kit' ),
				'subtitle'    => __( 'Redirect to this URL after booking a slot.', 'kadence-shop-kit' ),
				'type'        => 'text',
				'default'     => '',
				'placeholder' => 'https://',
			),
			array(
				'id'       => 'highlight_color',
				'title'    => __( 'Highlight Color', 'kadence-shop-kit' ),
				'subtitle' => '',
				'type'     => 'color',
				'default'  => '#96588A',
			),
			array(
				'id'       => 'earliest_slot_color',
				'title'    => __( 'Color for "Earliest Available Slot" label', 'kadence-shop-kit' ),
				'subtitle' => '',
				'type'     => 'color',
				'default'  => '#34A855',
			),
			array(
				'id'       => 'slots_remaining_color',
				'title'    => __( 'Color for "X Slots remaining" label', 'kadence-shop-kit' ),
				'subtitle' => '',
				'type'     => 'color',
				'default'  => '#a9b2ab',
			),
			array(
				'id'       => 'slots_unavailable_color',
				'title'    => __( 'Color for "Slot Unavailable" label', 'kadence-shop-kit' ),
				'subtitle' => '',
				'type'     => 'color',
				'default'  => '#EF5350',
			),
		),
	);

	$wpsf_settings['sections'][] = array(
		'tab_id'              => 'advance',
		'section_id'          => 'importexport',
		'section_title'       => __( 'Import/Export', 'kadence-shop-kit' ),
		'section_description' => '',
		'section_order'       => 0,
		'fields'              => array(
			array(
				'id'       => 'import',
				'title'    => __( 'Import', 'kadence-shop-kit' ),
				'subtitle' => __( 'Import settings', 'kadence-shop-kit' ),
				'type'     => 'import',
			),
			array(
				'id'       => 'export',
				'title'    => __( 'Export', 'kadence-shop-kit' ),
				'subtitle' => __( 'Export settings', 'kadence-shop-kit' ),
				'type'     => 'export',
			),
		),
	);

	if ( class_exists( 'WC_Shipping_Zones' ) ) {
		$wpsf_settings['sections']['timesettings']['fields']['timeslots']['subfields']['postcodes'] = array(
			'id'          => 'shipping_methods',
			'title'       => __( 'Shipping Methods', 'kadence-shop-kit' ),
			'subtitle'    => '',
			'type'        => 'checkboxes',
			'placeholder' => '',
			'choices'     => $jckwds->get_shipping_method_options(),
		);
	}

	return $wpsf_settings;
}
