<?php
/**
 * Single Product Rating
 * @version 3.6.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

global $product;

if ( get_option( 'woocommerce_enable_review_rating' ) === 'no' ) {
	return;
}
if ( ! is_object( $product ) ) {
	return;
}
$kadence_reviews = Kadence_Advanced_Reviews::get_instance();
$rating_count    = count( $kadence_reviews->kt_get_product_reviews( $product->get_id() ) );
$average         = $kadence_reviews->kt_get_average_rating( $product->get_id() );

if ( $rating_count > 0 ) : ?>
	<div class="woocommerce-product-rating">
		<?php // translators: %s is the numeric average star rating value (e.g. 4.5). ?>
		<div class="star-rating" title="<?php printf( esc_html__( 'Rated %s out of 5', 'kadence-shop-kit' ), esc_html( $average ) ); ?>">
			<span style="width:<?php echo( ( $average / 5 ) * 100 ); ?>%">
			<strong class="rating"><?php echo esc_html( $average ); ?></strong>
			<?php
			echo wp_kses_post(
				// translators: %1$s is an opening span tag, %2$s is a closing span tag wrapping the number 5.
				sprintf( __( 'out of %1$s5%2$s', 'kadence-shop-kit' ), '<span>', '</span>' )
			);
			?>
				<?php
				echo wp_kses_post(
					// translators: %s is an HTML span element containing the number of customer ratings.
					sprintf( _n( 'based on %s customer rating', 'based on %s customer ratings', $rating_count, 'kadence-shop-kit' ), '<span class="rating">' . esc_html( (string) $rating_count ) . '</span>' )
				);
				?>
			</span>
		</div>

		<?php if ( comments_open() ) : ?>
			<?php
			echo '<a href="#reviews" class="woocommerce-review-link" rel="nofollow">('
				. wp_kses_post(
					// translators: %s is an HTML span element containing the number of customer reviews.
					sprintf( _n( '%s customer review', '%s customer reviews', $rating_count, 'kadence-shop-kit' ), '<span class="count">' . esc_html( (string) $rating_count ) . '</span>' )
				)
				. ')</a>';
			?>
		<?php endif; ?>
    </div>

<?php endif; ?>
