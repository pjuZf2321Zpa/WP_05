<?php
/**
 * Review Comments Template
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
global $kt_reviews;
?>
<div class="wrap">

	<h2><?php esc_html_e( 'Product reviews', 'kadence-shop-kit' ); ?></h2>

    <?php $product_reviews->views(); ?>

    <form id="kt-reviews" method="get">
        <input type="hidden" name="page" value="<?php echo $_REQUEST['page'] ?>" />
		<?php $product_reviews->search_box( __( 'Search reviews', 'kadence-shop-kit' ), 'kadence-shop-kit' ); ?>
        <?php $product_reviews->display(); ?>
    </form>
</div>