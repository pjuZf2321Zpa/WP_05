<?php
/**
 * This overrides woocommerce.
 *
 * @package Kadence Woo Extras
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use KadenceWP\KadenceShopKit\Utilities\Cast;

/**
 * Class to build out custom product gallery.
 *
 * @category class
 */
class Kadence_Shop_Kit_Product_Gallery {

	/**
	 * Instance of this class
	 *
	 * @var null
	 */
	private static $instance = null;

	/**
	 * Gallery settings.
	 *
	 * @var null
	 */
	private static $gallery_args = null;

	/**
	 * Instance Control
	 */
	public static function get_instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Returns every layout value that renders as a static stacked grid (no Splide slider).
	 *
	 * Use this as the single source of truth wherever code needs to branch on
	 * "is this a stacked layout?" — lazy-load, is_slider, wrapper width, fade-opacity fix, etc.
	 *
	 * @return string[]
	 */
	public static function get_stacked_layouts(): array {
		return array( 'list', 'grid', 'tiles', 'grid-3-col', 'grid-highlighted', 'grid-3-col-highlighted' );
	}

	/**
	 * Returns the full kadence_pg script params array built from plugin settings.
	 *
	 * @since 3.0.0
	 *
	 * @param array<string, mixed> $overrides Key/value pairs to override specific params.
	 *
	 * @return array<string, mixed>
	 */
	public static function get_gallery_script_params( array $overrides = array() ): array {
		$shopkit_settings        = KWE_Options::get_all();
		$has_lightbox            = ( isset( $shopkit_settings['product_gallery_lightbox'] ) ? kt_woo_extras_is_true( $shopkit_settings['product_gallery_lightbox'] ) : true );
		$lightbox_style          = ( isset( $shopkit_settings['ga_lightbox_skin'] ) && 'light' === $shopkit_settings['ga_lightbox_skin'] ? 'kadence-light' : 'kadence-dark' );
		$lightbox_click_anywhere = ( isset( $shopkit_settings['ga_lightbox_click_anywhere'] ) ? kt_woo_extras_is_true( $shopkit_settings['ga_lightbox_click_anywhere'] ) : true );
		$zoom_type               = ! empty( $shopkit_settings['ga_zoom_type'] ) ? $shopkit_settings['ga_zoom_type'] : 'window';
		$video_controls          = ( isset( $shopkit_settings['ga_video_controls'] ) ? kt_woo_extras_is_true( $shopkit_settings['ga_video_controls'] ) : true );
		$video_controls_list     = ( ! empty( $shopkit_settings['ga_video_controls_list'] ) ? array_values( (array) $shopkit_settings['ga_video_controls_list'] ) : array( 'play-large', 'play', 'progress', 'mute', 'volume', 'settings', 'fullscreen' ) );
		$video_loop              = ( isset( $shopkit_settings['ga_video_loop'] ) ? kt_woo_extras_is_true( $shopkit_settings['ga_video_loop'] ) : true );
		$video_autoplay          = ( isset( $shopkit_settings['ga_video_autoplay'] ) ? kt_woo_extras_is_true( $shopkit_settings['ga_video_autoplay'] ) : false );
		$video_poster            = ( isset( $shopkit_settings['ga_video_poster'] ) ? kt_woo_extras_is_true( $shopkit_settings['ga_video_poster'] ) : false );
		$video_lazyload          = ( isset( $shopkit_settings['ga_video_lazyload'] ) ? kt_woo_extras_is_true( $shopkit_settings['ga_video_lazyload'] ) : false );

		$params = array(
			'maintain_gallery'        => Cast::to_string( $shopkit_settings['ga_maintain_gallery'] ?? '0' ),
			'zoom_type'               => $zoom_type,
			'zoom_lens_width'         => Cast::to_int( $shopkit_settings['ga_zoom_lens_width'] ?? 200 ),
			'zoom_lens_height'        => Cast::to_int( $shopkit_settings['ga_zoom_lens_height'] ?? 200 ),
			'zoom_position'           => isset( $shopkit_settings['ga_zoom_position'] ) ? $shopkit_settings['ga_zoom_position'] : 'right',
			'zoom_shape'              => isset( $shopkit_settings['ga_zoom_shape'] ) ? $shopkit_settings['ga_zoom_shape'] : 'circular',
			'plyr_js'                 => KADENCE_WOO_EXTRAS_URL . 'lib/gallery/js/min/plyr.js',
			'plyr_css'                => KADENCE_WOO_EXTRAS_URL . 'lib/gallery/css/plyr.css',
			'ajax_nonce'              => wp_create_nonce( 'kwsv' ),
			'ajax_url'                => admin_url( 'admin-ajax.php' ),
			'lightbox'                => $has_lightbox,
			'lightbox_style'          => $lightbox_style,
			'lightbox_click_anywhere' => $lightbox_click_anywhere,
			'stacked_layouts'         => self::get_stacked_layouts(),
			'video_controls'          => $video_controls,
			'video_controls_list'     => $video_controls_list,
			'video_loop'              => $video_loop,
			'video_autoplay'          => $video_autoplay,
			'video_poster'            => $video_poster,
			'video_lazyload'          => $video_lazyload,
		);

		return array_merge( $params, $overrides );
	}

	/**
	 * Build Gallery.
	 */
	public function __construct() {
		add_filter( 'wc_get_template', array( $this, 'filter_in_product_gallery' ), 20, 5 );
		add_action( 'kadence_shopkit_woocommerce_product_gallery', array( $this, 'render_gallery' ), 10 );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ), 150 );
		add_action( 'init', array( $this, 'remove_theme_filter' ), 20 );
		add_filter( 'cmb2_admin_init', array( $this, 'product_gallery_metaboxes' ), 100 );
		add_filter( 'cmb2_textarea_attributes', array( $this, 'product_gallery_metaboxes_args' ), 10, 4 );
		add_filter( 'woocommerce_get_image_size_single', array( $this, 'product_gallery_sizes' ) );
		add_filter( 'woocommerce_gallery_thumbnail_size', array( $this, 'product_variation_sizes' ) );
		// Add the filter for editing the custom url field.
		add_filter( 'attachment_fields_to_edit', array( $this, 'add_media_link_input' ), null, 2 );
		// Add the filter for saving the custom url field.
		add_filter( 'attachment_fields_to_save', array( $this, 'add_media_link_save' ), null, 2 );
		// Add in thumbnail srcset.
		add_filter( 'woocommerce_available_variation', array( $this, 'add_thumb_srcset' ), 10, 3 );
		// Disable woocommerce core.
		add_action( 'wp', array( $this, 'remove_woocommerce_core_scripts' ), 20 );
		add_filter( 'woocommerce_product_data_tabs', array( $this, 'register_product_data_tab' ) );
		add_action( 'woocommerce_product_data_panels', array( $this, 'render_product_data_panel' ) );
		add_action( 'woocommerce_process_product_meta', array( $this, 'save_product_data_fields' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_scripts' ) );
	}

	/**
	 * Remove WooCommerce Core Gallery Scripts if custom gallery is not disabled.
	 */
	public function remove_woocommerce_core_scripts() {
		if ( ! function_exists( 'is_product' ) || ! is_product() ) {
			return;
		}

		if ( $this->is_gallery_disabled( get_the_ID() ) ) {
			return;
		}

		add_filter( 'woocommerce_single_product_flexslider_enabled', '__return_false' );
		add_filter( 'woocommerce_single_product_photoswipe_enabled', '__return_false' );
		add_filter( 'woocommerce_single_product_zoom_enabled', '__return_false' );
		remove_theme_support( 'wc-product-gallery-slider' );
		remove_theme_support( 'wc-product-gallery-lightbox' );
		remove_theme_support( 'wc-product-gallery-zoom' );
	}

	/**
	 * Enqueue admin scripts for the MP4/WEBM media picker.
	 *
	 * @param string $hook Current admin page hook.
	 */
	public function admin_scripts( string $hook ): void {
		if ( ! in_array( $hook, array( 'post.php', 'post-new.php', 'upload.php' ), true ) ) {
			return;
		}

		if ( in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) {
			$screen = get_current_screen();
			if ( ! $screen || ! in_array( $screen->post_type, array( 'product', 'attachment' ), true ) ) {
				return;
			}
		}

		wp_enqueue_media();

		wp_enqueue_script(
			'kt-gallery-admin',
			KADENCE_WOO_EXTRAS_URL . 'lib/gallery/js/min/kt-gallery-admin-min.js',
			array( 'jquery' ),
			KADENCE_WOO_EXTRAS_VERSION,
			true
		);

		wp_localize_script(
			'kt-gallery-admin',
			'kt_gallery_admin_vars',
			array(
				'text' => array(
					'select_mp4' => __( 'Select MP4/WEBM', 'kadence-shop-kit' ),
					'attach_mp4' => __( 'Attach MP4/WEBM', 'kadence-shop-kit' ),
				),
			)
		);
	}
	/**
	 * Add new image meta video link input.
	 */
	public function add_media_link_input( $form_fields, $post ) {
		$form_fields['kt_woo_product_video'] = array(
			'label' => __( 'Product Video URL (Youtube, Vimeo)', 'kadence-shop-kit' ),
			'helps' => __( 'Used in Product Gallery for Popup Video.', 'kadence-shop-kit' ),
			'input' => 'text',
			'value' => get_post_meta( $post->ID, '_kt_woo_product_video', true ),
		);

		$form_fields['kt_woo_product_video_upload'] = array(
			'tr' => '<th scope="row" class="label">&nbsp;</th>
			<td class="field kt-attach-btn-cell">
			<span class="setting has-description"><a href="#" class="kt-upload-media button-secondary" data-image-id="' . esc_attr( $post->ID ) . '">' . esc_html__( 'Attach MP4/WEBM', 'kadence-shop-kit' ) . '</a></span>
			<p class="description" style="width: 100%; padding-top: 4px;">' . esc_html__( 'Select a locally hosted MP4 or WEBM from the media library.', 'kadence-shop-kit' ) . '</p>
			</td>',
		);

		return $form_fields;
	}
	/**
	 * Add in thumbnail srcset.
	 */
	public function add_thumb_srcset( $args, $variable_class, $variation ) {
		if ( isset( $args['image']['gallery_thumbnail_src'] ) && isset( $args['image']['gallery_thumbnail_src_w'] ) && isset( $args['image']['gallery_thumbnail_src_h'] ) ) {
			if ( ! is_null( self::$gallery_args ) ) {
				$temp_args                                 = self::$gallery_args;
				$args['image']['gallery_thumbnail_src_w']  = $temp_args['thumb_img_width'];
				$args['image']['gallery_thumbnail_src_h']  = $temp_args['thumb_img_height'];
				$temp_thumb                                = kt_woo_get_image_array( $temp_args['thumb_img_width'], $temp_args['thumb_img_height'], true, 'attachment-shop-single', '', $args['image_id'], false, 'thumbnail' );
				$args['image']['gallery_thumbnail_src']    = $temp_thumb['src'];
				$args['image']['gallery_thumbnail_srcset'] = $temp_thumb['src_set'];
			} else {
				$gallery_thumbnail_size                    = array( $args['image']['gallery_thumbnail_src_w'], $args['image']['gallery_thumbnail_src_h'] );
				$args['image']['gallery_thumbnail_srcset'] = function_exists( 'wp_get_attachment_image_srcset' ) ? wp_get_attachment_image_srcset( $args['image_id'], $gallery_thumbnail_size ) : false;
			}
		}
		return $args;
	}
	/**
	 * Save new image meta video link input.
	 */
	public function add_media_link_save( $post, $attachment ) {

		if ( isset( $attachment['kt_woo_product_video'] ) ) {
			update_post_meta( $post['ID'], '_kt_woo_product_video', esc_url_raw( $attachment['kt_woo_product_video'] ) );
		}
		return $post;
	}
	/**
	 * Override the Product image template.
	 *
	 * @param string $template_name Template name.
	 * @param array  $args          Arguments. (default: array).
	 * @param string $template_path Template path. (default: '').
	 * @param string $default_path  Default path. (default: '').
	 */
	public function filter_in_product_gallery( $template, $template_name, $args, $template_path, $default_path ) {
		if ( 'single-product/product-image.php' != $template_name ) {
			return $template;
		}

		if ( get_the_ID() && get_post_meta( get_the_ID(), '_kt_woo_gallery_disable', true ) === 'yes' ) {
			return $template; // Fall back to default WooCommerce gallery.
		}

		return KADENCE_WOO_EXTRAS_PATH . 'lib/gallery/product-image.php';
	}
	/**
	 * This maintains backwards compatibility.
	 */
	public function kt_woo_product_gallery() {
		require_once KADENCE_WOO_EXTRAS_PATH . 'lib/gallery/product-image.php';
	}
	/**
	 * Checks if Theme is Classic.
	 */
	public function theme_is_a_kadence_classic() {
		if ( class_exists( 'Kadence_API_Manager' ) ) {
			return true;
		}
		return false;
	}
	/**
	 * Add in the gallery scripts and styles.
	 */
	public function enqueue_scripts() {
		global $post;

		if ( is_singular( 'product' ) || ( ! empty( $post->post_content ) && strstr( $post->post_content, '[product_page' ) ) ) {
			$shopkit_settings        = KWE_Options::get_all();
			$has_zoom                = ( ! empty( $shopkit_settings['ga_zoom'] ) ? $shopkit_settings['ga_zoom'] : false );
			$has_lightbox            = ( isset( $shopkit_settings['product_gallery_lightbox'] ) ? kt_woo_extras_is_true( $shopkit_settings['product_gallery_lightbox'] ) : true );
			$lightbox_style          = ( isset( $shopkit_settings['ga_lightbox_skin'] ) && 'light' === $shopkit_settings['ga_lightbox_skin'] ? 'kadence-light' : 'kadence-dark' );
			$lightbox_click_anywhere = ( isset( $shopkit_settings['ga_lightbox_click_anywhere'] ) ? kt_woo_extras_is_true( $shopkit_settings['ga_lightbox_click_anywhere'] ) : true );
			$zoom_type               = ! empty( $shopkit_settings['ga_zoom_type'] ) ? $shopkit_settings['ga_zoom_type'] : 'window';
			$depend                  = array( 'kadence-update-splide', 'jquery' );
			if ( $has_zoom ) {
				if ( 'follow' === $zoom_type ) {
					$depend[] = 'kadence-product-gallery-hoverintent';
				}
				$depend[] = 'kadence-product-gallery-zoom';
			}
			if ( $has_lightbox ) {
				$depend[] = 'kadence-glightbox';
			}
			wp_enqueue_style( 'kadence-product-gallery', KADENCE_WOO_EXTRAS_URL . 'lib/gallery/css/kadence-product-gallery.css', false, KADENCE_WOO_EXTRAS_VERSION );
			wp_enqueue_style( 'kadence-kb-splide', KADENCE_WOO_EXTRAS_URL . 'lib/gallery/css/kadence-splide.css', false, KADENCE_WOO_EXTRAS_VERSION );
			wp_register_script( 'kadence-product-gallery-zoom', KADENCE_WOO_EXTRAS_URL . 'lib/gallery/js/min/jquery.imagezoom.min.js', array( 'jquery' ), KADENCE_WOO_EXTRAS_VERSION, true );
			wp_register_script( 'kadence-product-gallery-hoverintent', KADENCE_WOO_EXTRAS_URL . 'lib/gallery/js/min/jquery.hoverIntent.min.js', array( 'jquery' ), KADENCE_WOO_EXTRAS_VERSION, true );
			wp_enqueue_script( 'kadence-update-splide', KADENCE_WOO_EXTRAS_URL . 'lib/gallery/js/splide.min.js', array(), KADENCE_WOO_EXTRAS_VERSION, true );

			// Lightbox.
			wp_register_script( 'kadence-glightbox', KADENCE_WOO_EXTRAS_URL . 'inc/assets/js/glightbox.min.js', array(), KADENCE_WOO_EXTRAS_VERSION, true );
			if ( $has_lightbox ) {
				wp_enqueue_style( 'kadence-glightbox', KADENCE_WOO_EXTRAS_URL . 'inc/assets/css/glightbox.min.css', false, KADENCE_WOO_EXTRAS_VERSION );
			}
			wp_enqueue_script( 'kadence_product_gallery', KADENCE_WOO_EXTRAS_URL . 'lib/gallery/js/kadence-product-gallery.js', $depend, KADENCE_WOO_EXTRAS_VERSION, true );
			wp_localize_script( 'kadence_product_gallery', 'kadence_pg', self::get_gallery_script_params() );
		}
	}
	/**
	 * Remove custom theme filter effecting controls..
	 */
	public function remove_theme_filter() {
		remove_filter( 'woocommerce_get_image_size_single', 'virtue_woo_product_gallery_sizes' );
	}
	/**
	 * Filter Product Image sizes for Woocommerce
	 *
	 * @param array $size the gallery sizes.
	 */
	public function product_gallery_sizes( $size ) {
		$temp_args = array();
		if ( is_null( self::$gallery_args ) ) {
			$shopkit_settings       = KWE_Options::get_all();
			$temp_args['is_custom'] = ( isset( $shopkit_settings['product_gallery_custom_size'] ) && true == $shopkit_settings['product_gallery_custom_size'] ? true : false );
			if ( $temp_args['is_custom'] ) {
				$temp_args['custom_width']  = ( ! empty( $shopkit_settings['ga_image_width'] ) ? $shopkit_settings['ga_image_width'] : 465 );
				$temp_args['ratio']         = ( ! empty( $shopkit_settings['ga_image_ratio'] ) ? $shopkit_settings['ga_image_ratio'] : 'square' );
				$temp_args['layout']        = ( ! empty( $shopkit_settings['ga_slider_layout'] ) ? $shopkit_settings['ga_slider_layout'] : 'above' );
				$temp_args['vlayout']       = ( 'left' === $temp_args['layout'] || 'right' === $temp_args['layout'] ? true : false );
				$temp_args['thumb_columns'] = ( ! empty( $shopkit_settings['ga_thumb_columns'] ) ? $shopkit_settings['ga_thumb_columns'] : 7 );
				$temp_args['thumb_ratio']   = ( ! empty( $shopkit_settings['ga_thumb_image_ratio'] ) ? $shopkit_settings['ga_thumb_image_ratio'] : 'square' );
				$temp_args['width']         = $temp_args['custom_width'];
				if ( 'custom' === $temp_args['ratio'] ) {
					if ( ! empty( $shopkit_settings['ga_image_height'] ) ) {
						$temp_args['height'] = $shopkit_settings['ga_image_height'];
					} elseif ( empty( $temp_args['height'] ) ) {
						$temp_args['height'] = 465;
					}
				} elseif ( 'portrait' === $temp_args['ratio'] ) {
					$temp_args['height'] = floor( $temp_args['width'] * 1.35 );
				} elseif ( 'landscape' === $temp_args['ratio'] ) {
					$temp_args['height'] = floor( $temp_args['width'] / 1.35 );
				} elseif ( 'landscape32' === $temp_args['ratio'] ) {
					$temp_args['height'] = floor( $temp_args['width'] / 1.5 );
				} elseif ( 'landscape169' === $temp_args['ratio'] ) {
					$temp_args['height'] = floor( $temp_args['width'] * 0.5625 );
				} elseif ( 'widelandscape' === $temp_args['ratio'] ) {
					$temp_args['height'] = floor( $temp_args['width'] / 2 );
				} else {
					$temp_args['height'] = $temp_args['width'];
				}
			}
		} else {
			$temp_args = self::$gallery_args;
		}
		if ( $temp_args['is_custom'] && isset( $temp_args['width'] ) && isset( $temp_args['height'] ) ) {
			$size = array(
				'width'  => $temp_args['width'],
				'height' => $temp_args['height'],
				'crop'   => 1,
			);
		}

		return $size;
	}
	/**
	 * Filter Product Image sizes for Woocommerce
	 *
	 * @param array $sizes the gallery sizes.
	 */
	public function product_variation_sizes( $sizes ) {
		$temp_args = array();
		if ( is_null( self::$gallery_args ) ) {
			$shopkit_settings       = KWE_Options::get_all();
			$temp_args['is_custom'] = ( isset( $shopkit_settings['product_gallery_custom_size'] ) && true == $shopkit_settings['product_gallery_custom_size'] ? true : false );
			if ( $temp_args['is_custom'] ) {
				$temp_args['custom_width']  = ( ! empty( $shopkit_settings['ga_image_width'] ) ? $shopkit_settings['ga_image_width'] : 465 );
				$temp_args['ratio']         = ( ! empty( $shopkit_settings['ga_image_ratio'] ) ? $shopkit_settings['ga_image_ratio'] : 'square' );
				$temp_args['layout']        = ( ! empty( $shopkit_settings['ga_slider_layout'] ) ? $shopkit_settings['ga_slider_layout'] : 'above' );
				$temp_args['vlayout']       = ( 'left' === $temp_args['layout'] || 'right' === $temp_args['layout'] ? true : false );
				$temp_args['thumb_columns'] = ( ! empty( $shopkit_settings['ga_thumb_columns'] ) ? $shopkit_settings['ga_thumb_columns'] : 7 );
				$temp_args['thumb_ratio']   = ( ! empty( $shopkit_settings['ga_thumb_image_ratio'] ) ? $shopkit_settings['ga_thumb_image_ratio'] : 'square' );
				$temp_args['width']         = $temp_args['custom_width'];
				if ( 'custom' === $temp_args['ratio'] ) {
					if ( ! empty( $shopkit_settings['ga_image_height'] ) ) {
						$temp_args['height'] = $shopkit_settings['ga_image_height'];
					} elseif ( empty( $temp_args['height'] ) ) {
						$temp_args['height'] = 465;
					}
				} elseif ( 'portrait' === $temp_args['ratio'] ) {
					$temp_args['height'] = floor( $temp_args['width'] * 1.35 );
				} elseif ( 'landscape' === $temp_args['ratio'] ) {
					$temp_args['height'] = floor( $temp_args['width'] / 1.35 );
				} elseif ( 'landscape32' === $temp_args['ratio'] ) {
					$temp_args['height'] = floor( $temp_args['width'] / 1.5 );
				} elseif ( 'landscape169' === $temp_args['ratio'] ) {
					$temp_args['height'] = floor( $temp_args['width'] * 0.5625 );
				} elseif ( 'widelandscape' === $temp_args['ratio'] ) {
					$temp_args['height'] = floor( $temp_args['width'] / 2 );
				} else {
					$temp_args['height'] = $temp_args['width'];
				}
				if ( $temp_args['vlayout'] ) {
					$temp_args['thumb_img_height'] = floor( $temp_args['height'] / $temp_args['thumb_columns'] ) - 2;
					if ( 'portrait' === $temp_args['thumb_ratio'] ) {
						$temp_args['thumb_img_width'] = floor( $temp_args['thumb_img_height'] / 1.35 );
					} elseif ( 'landscape' === $temp_args['thumb_ratio'] ) {
						$temp_args['thumb_img_width'] = floor( $temp_args['thumb_img_height'] * 1.35 );
					} elseif ( 'landscape32' === $temp_args['thumb_ratio'] ) {
						$temp_args['thumb_img_width'] = floor( $temp_args['thumb_img_height'] * 1.5 );
					} elseif ( 'landscape169' === $temp_args['thumb_ratio'] ) {
						$temp_args['thumb_img_width'] = floor( $temp_args['thumb_img_height'] * 1.78 );
					} elseif ( 'widelandscape' === $temp_args['thumb_ratio'] ) {
						$temp_args['thumb_img_width'] = floor( $temp_args['thumb_img_height'] * 2 );
					} elseif ( 'inherit' === $temp_args['thumb_ratio'] ) {
						$temp_args['thumb_img_width']  = 120;
						$temp_args['thumb_img_height'] = null;
					} else {
						$temp_args['thumb_img_width'] = $temp_args['thumb_img_height'];
					}
				} else {
					$temp_args['thumb_img_width'] = floor( $temp_args['width'] / $temp_args['thumb_columns'] );
					if ( 'portrait' === $temp_args['thumb_ratio'] ) {
						$temp_args['thumb_img_height'] = floor( $temp_args['thumb_img_width'] * 1.35 );
					} elseif ( 'landscape' === $temp_args['thumb_ratio'] ) {
						$temp_args['thumb_img_height'] = floor( $temp_args['thumb_img_width'] / 1.35 );
					} elseif ( 'landscape32' === $temp_args['thumb_ratio'] ) {
						$temp_args['thumb_img_height'] = floor( $temp_args['thumb_img_width'] / 1.5 );
					} elseif ( 'landscape169' === $temp_args['thumb_ratio'] ) {
						$temp_args['thumb_img_height'] = floor( $temp_args['thumb_img_width'] * 0.5625 );
					} elseif ( 'inherit' === $temp_args['thumb_ratio'] ) {
						$temp_args['thumb_img_height'] = null;
					} elseif ( 'widelandscape' === $temp_args['thumb_ratio'] ) {
						$temp_args['thumb_img_height'] = floor( $temp_args['thumb_img_width'] / 2 );
					} else {
						$temp_args['thumb_img_height'] = $temp_args['thumb_img_width'];
					}
				}
			} else {
				$single_size                = wc_get_image_size( 'single' );
				$temp_args['ratio']         = ( ! empty( $shopkit_settings['ga_image_ratio'] ) ? $shopkit_settings['ga_image_ratio'] : 'square' );
				$temp_args['layout']        = ( ! empty( $shopkit_settings['ga_slider_layout'] ) ? $shopkit_settings['ga_slider_layout'] : 'above' );
				$temp_args['vlayout']       = ( 'left' === $temp_args['layout'] || 'right' === $temp_args['layout'] ? true : false );
				$temp_args['thumb_columns'] = ( ! empty( $shopkit_settings['ga_thumb_columns'] ) ? $shopkit_settings['ga_thumb_columns'] : 7 );
				$temp_args['thumb_ratio']   = ( ! empty( $shopkit_settings['ga_thumb_image_ratio'] ) ? $shopkit_settings['ga_thumb_image_ratio'] : 'square' );
				if ( $temp_args['vlayout'] ) {
					$temp_args['height']           = ( ! empty( $single_size['height'] ) ? $single_size['height'] : 600 );
					$temp_args['thumb_img_height'] = floor( $temp_args['height'] / $temp_args['thumb_columns'] ) - 2;
					if ( 'portrait' === $temp_args['thumb_ratio'] ) {
						$temp_args['thumb_img_width'] = floor( $temp_args['thumb_img_height'] / 1.35 );
					} elseif ( 'landscape' === $temp_args['thumb_ratio'] ) {
						$temp_args['thumb_img_width'] = floor( $temp_args['thumb_img_height'] * 1.35 );
					} elseif ( 'landscape32' === $temp_args['thumb_ratio'] ) {
						$temp_args['thumb_img_width'] = floor( $temp_args['thumb_img_height'] * 1.5 );
					} elseif ( 'landscape169' === $temp_args['thumb_ratio'] ) {
						$temp_args['thumb_img_width'] = floor( $temp_args['thumb_img_height'] * 1.78 );
					} elseif ( 'widelandscape' === $temp_args['thumb_ratio'] ) {
						$temp_args['thumb_img_width'] = floor( $temp_args['thumb_img_height'] * 2 );
					} elseif ( 'inherit' === $temp_args['thumb_ratio'] ) {
						$temp_args['thumb_img_width']  = 120;
						$temp_args['thumb_img_height'] = null;
					} else {
						$temp_args['thumb_img_width'] = $temp_args['thumb_img_height'];
					}
				} else {
					$temp_args['width']           = ( ! empty( $single_size['width'] ) ? $single_size['width'] : 600 );
					$temp_args['thumb_img_width'] = floor( $temp_args['width'] / $temp_args['thumb_columns'] );
					if ( 'portrait' === $temp_args['thumb_ratio'] ) {
						$temp_args['thumb_img_height'] = floor( $temp_args['thumb_img_width'] * 1.35 );
					} elseif ( 'landscape' === $temp_args['thumb_ratio'] ) {
						$temp_args['thumb_img_height'] = floor( $temp_args['thumb_img_width'] / 1.35 );
					} elseif ( 'landscape32' === $temp_args['thumb_ratio'] ) {
						$temp_args['thumb_img_height'] = floor( $temp_args['thumb_img_width'] / 1.5 );
					} elseif ( 'landscape169' === $temp_args['thumb_ratio'] ) {
						$temp_args['thumb_img_height'] = floor( $temp_args['thumb_img_width'] * 0.5625 );
					} elseif ( 'inherit' === $temp_args['thumb_ratio'] ) {
						$temp_args['thumb_img_height'] = null;
					} elseif ( 'widelandscape' === $temp_args['thumb_ratio'] ) {
						$temp_args['thumb_img_height'] = floor( $temp_args['thumb_img_width'] / 2 );
					} else {
						$temp_args['thumb_img_height'] = $temp_args['thumb_img_width'];
					}
				}
			}
		} else {
			$temp_args = self::$gallery_args;
		}
		if ( ! empty( $temp_args['thumb_img_width'] ) && ! empty( $temp_args['thumb_img_height'] ) ) {
			$sizes = array( $temp_args['thumb_img_width'], $temp_args['thumb_img_height'] );
		}

		return $sizes;
	}
	/**
	 * Add args to metabox settings.
	 */
	public function product_gallery_metaboxes_args( $args, $type_defaults, $field, $types ) {
		if ( '_kt_woo_gallery_shortcode' === $field->args['id'] ) {
			$args['rows'] = 2;
		}
		return $args;
	}
	/**
	 * Add in gallery options for a shortcode override.
	 */
	public function product_gallery_metaboxes() {
		$prefix           = '_kt_woo_';
		$shopkit_settings = KWE_Options::get_all();
		if ( isset( $shopkit_settings['ga_shortcode_option'] ) && true == $shopkit_settings['ga_shortcode_option'] ) {
			$kadence_product_gallery = new_cmb2_box(
				array(
					'id'           => $prefix . 'gallery_override',
					'title'        => __( 'Override product Gallery', 'kadence-shop-kit' ),
					'object_types' => array( 'product' ), // Post type.
					'priority'     => 'low',
					'context'      => 'side',
				)
			);
			$kadence_product_gallery->add_field(
				array(
					'name'    => __( 'Replace Gallery with Shortcode', 'kadence-shop-kit' ),
					'id'      => $prefix . 'gallery_shortcode',
					'type'    => 'textarea_code',
					'rows'    => 4,
					'options' => array(
						'textarea_rows'      => 2,
						'disable_codemirror' => true,
					),
				)
			);
		}
	}
	/**
	 * Determine how to render the gallery.
	 */
	public function render_gallery( $args = array() ) {
		global $product;

		$shopkit_settings = KWE_Options::get_all();
		$shortcode = get_post_meta( get_the_ID(), '_kt_woo_gallery_shortcode', true );
		if ( isset( $shortcode ) && ! empty( $shortcode ) && isset( $shopkit_settings['ga_shortcode_option'] ) && true == $shopkit_settings['ga_shortcode_option'] ) {
			echo '<div class="images woocommerce-product-gallery kad-light-gallery kt-shortcode-gallery"><div class="product_image">';
			echo apply_filters( 'do_shortcode', $shortcode );
			echo '</div></div>';
		} elseif ( ! has_post_thumbnail() ) {
			$wrapper_classes = apply_filters(
				'woocommerce_single_product_image_gallery_classes',
				array(
					'woocommerce-product-gallery',
					'woocommerce-product-gallery--without-images',
					'images',
				)
			);
			echo '<div class="kad-light-gallery ' . esc_attr( implode( ' ', array_map( 'sanitize_html_class', $wrapper_classes ) ) ) . '"><div class="product_image">';
			$inner_wrapper_classname = $product->is_type( 'variable' ) && ! empty( $product->get_available_variations( 'image' ) ) ?
				'woocommerce-product-gallery__image woocommerce-product-gallery__image--placeholder' :
				'woocommerce-product-gallery__image--placeholder';
			$html                    = sprintf( '<div class="%s">', esc_attr( $inner_wrapper_classname ) );
			$html                   .= sprintf( '<img src="%s" alt="%s" class="wp-post-image" />', esc_url( wc_placeholder_img_src( 'woocommerce_single' ) ), esc_html__( 'Awaiting product image', 'kadence-shop-kit' ) );
			$html                   .= '</div>';
			echo apply_filters( 'woocommerce_single_product_image_thumbnail_html', $html, null ); // phpcs:disable WordPress.XSS.EscapeOutput.OutputNotEscaped
			echo '</div></div>';
		} else {
			$this->output_gallery( $args );
		}
	}

	/**
	 * Get Gallery args.
	 *
	 * @param array<string, mixed> $args Array of arguments.
	 *
	 * @return array<string, mixed> Array of arguments.
	 */
	public function get_gallery_args( $args = array() ) {
		if ( is_null( self::$gallery_args ) ) {
			$shopkit_settings = KWE_Options::get_all();

			$defaults = array(
				'custom_width'      => ( ! empty( $shopkit_settings['ga_image_width'] ) ? $shopkit_settings['ga_image_width'] : 465 ),
				'ratio'             => ( ! empty( $shopkit_settings['ga_image_ratio'] ) ? $shopkit_settings['ga_image_ratio'] : 'square' ),
				'layout'            => ( ! empty( $shopkit_settings['ga_slider_layout'] ) ? $shopkit_settings['ga_slider_layout'] : 'above' ),
				'thumb_width'       => ( ! empty( $shopkit_settings['ga_thumb_width'] ) ? $shopkit_settings['ga_thumb_width'] : '20' ),
				'is_custom'         => ( isset( $shopkit_settings['product_gallery_custom_size'] ) ? kt_woo_extras_is_true( $shopkit_settings['product_gallery_custom_size'] ) : false ),
				'transtype'         => ( ! empty( $shopkit_settings['ga_trans_type'] ) && 'true' === $shopkit_settings['ga_trans_type'] ? true : false ),
				'show_caption'      => ( ! empty( $shopkit_settings['ga_show_caption'] ) && 'true' === $shopkit_settings['ga_show_caption'] ? true : false ),
				'autoplay'          => ( ! empty( $shopkit_settings['ga_slider_autoplay'] ) && 'true' === $shopkit_settings['ga_slider_autoplay'] ? true : false ),
				'auto_height'       => ( ! empty( $shopkit_settings['ga_slider_auto_height'] ) && true === $shopkit_settings['ga_slider_auto_height'] ? true : false ),
				'pausetime'         => ( ! empty( $shopkit_settings['ga_slider_pausetime'] ) ? $shopkit_settings['ga_slider_pausetime'] : '7000' ),
				'transtime'         => ( ! empty( $shopkit_settings['ga_slider_transtime'] ) ? $shopkit_settings['ga_slider_transtime'] : '400' ),
				'zoomactive'        => ( ! empty( $shopkit_settings['ga_zoom'] ) ? $shopkit_settings['ga_zoom'] : false ),
				'zoomtype'          => ! empty( $shopkit_settings['ga_zoom_type'] ) ? $shopkit_settings['ga_zoom_type'] : 'window',
				'zoomshape'         => isset( $shopkit_settings['ga_zoom_shape'] ) ? $shopkit_settings['ga_zoom_shape'] : 'circular',
				'zoom_lens_colour'  => Cast::to_string( $shopkit_settings['ga_zoom_lens_colour'] ?? '#000000' ),
				'zoom_lens_opacity' => Cast::to_string( $shopkit_settings['ga_zoom_lens_opacity'] ?? '0.8' ),
				'zoom_lens_width'   => Cast::to_int( $shopkit_settings['ga_zoom_lens_width'] ?? 200 ),
				'zoom_lens_height'  => Cast::to_int( $shopkit_settings['ga_zoom_lens_height'] ?? 200 ),
				'thumb_columns'     => ( ! empty( $shopkit_settings['ga_thumb_columns'] ) ? $shopkit_settings['ga_thumb_columns'] : 7 ),
				'thumb_ratio'       => ( ! empty( $shopkit_settings['ga_thumb_image_ratio'] ) ? $shopkit_settings['ga_thumb_image_ratio'] : 'square' ),
				'arrows'            => ( ! empty( $shopkit_settings['ga_slider_arrows'] ) && 'true' === $shopkit_settings['ga_slider_arrows'] ? true : false ),
				'lightbox'          => ( isset( $shopkit_settings['product_gallery_lightbox'] ) ? kt_woo_extras_is_true( $shopkit_settings['product_gallery_lightbox'] ) : true ),
				'thumb_hover'       => ( isset( $shopkit_settings['ga_thumb_hover'] ) ? kt_woo_extras_is_true( $shopkit_settings['ga_thumb_hover'] ) : true ),
				'thumb_gap'         => 4,
				'loop'              => ( isset( $shopkit_settings['ga_slider_loop'] ) ? (bool) $shopkit_settings['ga_slider_loop'] : true ),
				'maintain_index'    => ( isset( $shopkit_settings['ga_slider_maintain_index'] ) ? (bool) $shopkit_settings['ga_slider_maintain_index'] : false ),
				'swipe_threshold'   => Cast::to_int( $shopkit_settings['ga_slider_swipe_threshold'] ?? 5 ),
				'lazyload'          => ( ! empty( $shopkit_settings['ga_slider_lazyload'] ) ? $shopkit_settings['ga_slider_lazyload'] : 'sequential' ),
				'thumb_trans_speed' => Cast::to_int( $shopkit_settings['ga_thumb_trans_speed'] ?? 250 ),
				'thumb_controls'    => ( isset( $shopkit_settings['ga_thumb_controls'] ) ? (bool) $shopkit_settings['ga_thumb_controls'] : true ),
				'video_poster'      => ( isset( $shopkit_settings['ga_video_poster'] ) ? kt_woo_extras_is_true( $shopkit_settings['ga_video_poster'] ) : false ),
			);
			// Responsive Defaults.
			$defaults['layout_tablet']        = ( ! empty( $shopkit_settings['ga_slider_layout_tablet'] ) ? $shopkit_settings['ga_slider_layout_tablet'] : $defaults['layout'] );
			$defaults['layout_mobile']        = ( ! empty( $shopkit_settings['ga_slider_layout_mobile'] ) ? $shopkit_settings['ga_slider_layout_mobile'] : $defaults['layout_tablet'] );
			$defaults['thumb_width_tablet']   = ( ! empty( $shopkit_settings['ga_thumb_width_tablet'] ) ? $shopkit_settings['ga_thumb_width_tablet'] : $defaults['thumb_width'] );
			$defaults['thumb_width_mobile']   = ( ! empty( $shopkit_settings['ga_thumb_width_mobile'] ) ? $shopkit_settings['ga_thumb_width_mobile'] : $defaults['thumb_width_tablet'] );
			$defaults['thumb_columns_tablet'] = ( ! empty( $shopkit_settings['ga_thumb_columns_tablet'] ) ? $shopkit_settings['ga_thumb_columns_tablet'] : $defaults['thumb_columns'] );
			$defaults['thumb_columns_mobile'] = ( ! empty( $shopkit_settings['ga_thumb_columns_mobile'] ) ? $shopkit_settings['ga_thumb_columns_mobile'] : $defaults['thumb_columns_tablet'] );
			$defaults['thumb_gap_tablet']     = $defaults['thumb_gap'];
			$defaults['thumb_gap_mobile']     = $defaults['thumb_gap'];
			// Generate Final Size Settings.
			$gallery_args = wp_parse_args( $args, $defaults );
			if ( $gallery_args['is_custom'] ) {
				$gallery_args['width'] = $gallery_args['custom_width'];
				if ( 'custom' === $gallery_args['ratio'] ) {
					if ( ! empty( $gallery_args['custom_height'] ) ) {
						$gallery_args['height'] = $gallery_args['custom_height'];
					} elseif ( ! empty( $shopkit_settings['ga_image_height'] ) ) {
						$gallery_args['height'] = $shopkit_settings['ga_image_height'];
					} elseif ( empty( $gallery_args['height'] ) ) {
						$gallery_args['height'] = 465;
					}
				} elseif ( 'portrait' === $gallery_args['ratio'] ) {
					$gallery_args['height'] = floor( $gallery_args['width'] * 1.35 );
				} elseif ( 'landscape' === $gallery_args['ratio'] ) {
					$gallery_args['height'] = floor( $gallery_args['width'] / 1.35 );
				} elseif ( 'landscape32' === $gallery_args['ratio'] ) {
					$gallery_args['height'] = floor( $gallery_args['width'] / 1.5 );
				} elseif ( 'landscape169' === $gallery_args['ratio'] ) {
					$gallery_args['height'] = floor( $gallery_args['width'] * 0.5625 );
				} elseif ( 'widelandscape' === $gallery_args['ratio'] ) {
					$gallery_args['height'] = floor( $gallery_args['width'] / 2 );
				} else {
					$gallery_args['height'] = $gallery_args['width'];
				}
			} else {
				$woo_image_size = apply_filters( 'woocommerce_gallery_image_size', 'woocommerce_single' );
				if ( has_post_thumbnail() ) {
					$woo_img                = wp_get_attachment_image_src( get_post_thumbnail_id(), $woo_image_size );
					$gallery_args['width']  = ( ! empty( $woo_img[1] ) ? $woo_img[1] : '600' );
					$gallery_args['height'] = ( ! empty( $woo_img[2] ) ? $woo_img[2] : '600' );
				} else {
					$gallery_args['width']  = '600';
					$gallery_args['height'] = '600';
				}
			}

			$gallery_args['vlayout'] = ( 'left' === $gallery_args['layout'] || 'right' === $gallery_args['layout'] ? true : false );

			if ( $gallery_args['vlayout'] ) {
				$gallery_args['thumb_img_height'] = floor( $gallery_args['height'] / $gallery_args['thumb_columns'] ) - 2;
				if ( 'portrait' === $gallery_args['thumb_ratio'] ) {
					$gallery_args['thumb_img_width'] = floor( $gallery_args['thumb_img_height'] / 1.35 );
				} elseif ( 'landscape' === $gallery_args['thumb_ratio'] ) {
					$gallery_args['thumb_img_width'] = floor( $gallery_args['thumb_img_height'] * 1.35 );
				} elseif ( 'landscape32' === $gallery_args['thumb_ratio'] ) {
					$gallery_args['thumb_img_width'] = floor( $gallery_args['thumb_img_height'] * 1.5 );
				} elseif ( 'landscape169' === $gallery_args['thumb_ratio'] ) {
					$gallery_args['thumb_img_width'] = floor( $gallery_args['thumb_img_height'] * 1.78 );
				} elseif ( 'widelandscape' === $gallery_args['thumb_ratio'] ) {
					$gallery_args['thumb_img_width'] = floor( $gallery_args['thumb_img_height'] * 2 );
				} elseif ( 'inherit' === $gallery_args['thumb_ratio'] ) {
					$gallery_args['thumb_img_width']  = 120;
					$gallery_args['thumb_img_height'] = null;
				} else {
					$gallery_args['thumb_img_width'] = $gallery_args['thumb_img_height'];
				}
			} else {
				$gallery_args['thumb_img_width'] = floor( $gallery_args['width'] / $gallery_args['thumb_columns'] );
				if ( 'portrait' === $gallery_args['thumb_ratio'] ) {
					$gallery_args['thumb_img_height'] = floor( $gallery_args['thumb_img_width'] * 1.35 );
				} elseif ( 'landscape' === $gallery_args['thumb_ratio'] ) {
					$gallery_args['thumb_img_height'] = floor( $gallery_args['thumb_img_width'] / 1.35 );
				} elseif ( 'landscape32' === $gallery_args['thumb_ratio'] ) {
					$gallery_args['thumb_img_height'] = floor( $gallery_args['thumb_img_width'] / 1.5 );
				} elseif ( 'landscape169' === $gallery_args['thumb_ratio'] ) {
					$gallery_args['thumb_img_height'] = floor( $gallery_args['thumb_img_width'] * 0.5625 );
				} elseif ( 'inherit' === $gallery_args['thumb_ratio'] ) {
					$gallery_args['thumb_img_height'] = null;
				} elseif ( 'widelandscape' === $gallery_args['thumb_ratio'] ) {
					$gallery_args['thumb_img_height'] = floor( $gallery_args['thumb_img_width'] / 2 );
				} else {
					$gallery_args['thumb_img_height'] = $gallery_args['thumb_img_width'];
				}
			}
			if ( 'left' === $gallery_args['layout'] ) {
				$gallery_args['margin']      = 'margin-left:' . esc_attr( $gallery_args['thumb_width'] ) . '%;';
				$gallery_args['thumb_style'] = 'width:' . esc_attr( $gallery_args['thumb_width'] ) . '%;';
			} elseif ( 'right' === $gallery_args['layout'] ) {
				$gallery_args['margin']      = 'margin-right:' . esc_attr( $gallery_args['thumb_width'] ) . '%;';
				$gallery_args['thumb_style'] = 'width:' . esc_attr( $gallery_args['thumb_width'] ) . '%;';
			} else {
				$gallery_args['margin']      = '';
				$gallery_args['thumb_style'] = 'width:auto;';
			}
			self::$gallery_args = $gallery_args;
		}
		return self::$gallery_args;
	}
	/**
	 * Get Render Gallery args.
	 *
	 * @param array<string, mixed> $args Array of arguments.
	 *
	 * @return array<string, int|string|bool|float|null> Array of arguments.
	 */
	public function get_render_gallery_args( $args = array() ) {
		$shopkit_settings = KWE_Options::get_all();

		$defaults = array(
			'custom_width'      => ( ! empty( $shopkit_settings['ga_image_width'] ) ? $shopkit_settings['ga_image_width'] : 465 ),
			'ratio'             => ( ! empty( $shopkit_settings['ga_image_ratio'] ) ? $shopkit_settings['ga_image_ratio'] : 'square' ),
			'layout'            => ( ! empty( $shopkit_settings['ga_slider_layout'] ) ? $shopkit_settings['ga_slider_layout'] : 'above' ),
			'thumb_width'       => ( ! empty( $shopkit_settings['ga_thumb_width'] ) ? $shopkit_settings['ga_thumb_width'] : '20' ),
			'is_custom'         => ( isset( $shopkit_settings['product_gallery_custom_size'] ) ? kt_woo_extras_is_true( $shopkit_settings['product_gallery_custom_size'] ) : false ),
			'transtype'         => ( ! empty( $shopkit_settings['ga_trans_type'] ) && 'true' === $shopkit_settings['ga_trans_type'] ? true : false ),
			'show_caption'      => ( ! empty( $shopkit_settings['ga_show_caption'] ) && 'true' === $shopkit_settings['ga_show_caption'] ? true : false ),
			'autoplay'          => ( ! empty( $shopkit_settings['ga_slider_autoplay'] ) && 'true' === $shopkit_settings['ga_slider_autoplay'] ? true : false ),
			'auto_height'       => ( ! empty( $shopkit_settings['ga_slider_auto_height'] ) && true === $shopkit_settings['ga_slider_auto_height'] ? true : false ),
			'pausetime'         => ( ! empty( $shopkit_settings['ga_slider_pausetime'] ) ? $shopkit_settings['ga_slider_pausetime'] : '7000' ),
			'transtime'         => ( ! empty( $shopkit_settings['ga_slider_transtime'] ) ? $shopkit_settings['ga_slider_transtime'] : '400' ),
			'zoomactive'        => ( ! empty( $shopkit_settings['ga_zoom'] ) ? $shopkit_settings['ga_zoom'] : false ),
			'zoomtype'          => ( ! empty( $shopkit_settings['ga_zoom_type'] ) ? $shopkit_settings['ga_zoom_type'] : 'window' ),
			'zoomshape'         => isset( $shopkit_settings['ga_zoom_shape'] ) ? $shopkit_settings['ga_zoom_shape'] : 'circular',
			'zoom_lens_colour'  => Cast::to_string( $shopkit_settings['ga_zoom_lens_colour'] ?? '#000000' ),
			'zoom_lens_opacity' => Cast::to_string( $shopkit_settings['ga_zoom_lens_opacity'] ?? '0.8' ),
			'zoom_lens_width'   => Cast::to_int( $shopkit_settings['ga_zoom_lens_width'] ?? 200 ),
			'zoom_lens_height'  => Cast::to_int( $shopkit_settings['ga_zoom_lens_height'] ?? 200 ),
			'thumb_columns'     => ( ! empty( $shopkit_settings['ga_thumb_columns'] ) ? $shopkit_settings['ga_thumb_columns'] : 7 ),
			'thumb_ratio'       => ( ! empty( $shopkit_settings['ga_thumb_image_ratio'] ) ? $shopkit_settings['ga_thumb_image_ratio'] : 'square' ),
			'arrows'            => ( ! empty( $shopkit_settings['ga_slider_arrows'] ) && 'true' === $shopkit_settings['ga_slider_arrows'] ? true : false ),
			'pagination'        => ( isset( $shopkit_settings['ga_slider_pagination'] ) ? kt_woo_extras_is_true( $shopkit_settings['ga_slider_pagination'] ) : false ),
			'lightbox'          => ( isset( $shopkit_settings['product_gallery_lightbox'] ) ? kt_woo_extras_is_true( $shopkit_settings['product_gallery_lightbox'] ) : true ),
			'thumb_hover'       => ( isset( $shopkit_settings['ga_thumb_hover'] ) ? kt_woo_extras_is_true( $shopkit_settings['ga_thumb_hover'] ) : false ),
			'thumb_gap'         => Cast::to_int( $shopkit_settings['ga_thumb_spacing'] ?? 4 ),
			'loop'              => ( isset( $shopkit_settings['ga_slider_loop'] ) ? (bool) $shopkit_settings['ga_slider_loop'] : true ),
			'maintain_index'    => ( isset( $shopkit_settings['ga_slider_maintain_index'] ) ? (bool) $shopkit_settings['ga_slider_maintain_index'] : false ),
			'swipe_threshold'   => Cast::to_int( $shopkit_settings['ga_slider_swipe_threshold'] ?? 5 ),
			'lazyload'          => ( ! empty( $shopkit_settings['ga_slider_lazyload'] ) ? $shopkit_settings['ga_slider_lazyload'] : 'sequential' ),
			'thumb_trans_speed' => Cast::to_int( $shopkit_settings['ga_thumb_trans_speed'] ?? 250 ),
			'thumb_controls'    => ( isset( $shopkit_settings['ga_thumb_controls'] ) ? kt_woo_extras_is_true( $shopkit_settings['ga_thumb_controls'] ) : true ),
			'ui_fg_colour'      => Cast::to_string( $shopkit_settings['ga_ui_foreground_colour'] ?? '#ffffff' ),
			'ui_bg_colour'      => Cast::to_string( $shopkit_settings['ga_ui_background_colour'] ?? '#111111' ),
			'icons_hover'       => ( ! empty( $shopkit_settings['ga_icons_hover'] ) ? true : false ),
			'icons_tooltips'    => ( ! empty( $shopkit_settings['ga_icons_tooltips'] ) ? true : false ),
			'video_poster'      => ( isset( $shopkit_settings['ga_video_poster'] ) ? kt_woo_extras_is_true( $shopkit_settings['ga_video_poster'] ) : false ),
		);
		// Responsive Defaults.
		$defaults['layout_tablet']        = ( ! empty( $shopkit_settings['ga_slider_layout_tablet'] ) ? $shopkit_settings['ga_slider_layout_tablet'] : $defaults['layout'] );
		$defaults['layout_mobile']        = ( ! empty( $shopkit_settings['ga_slider_layout_mobile'] ) ? $shopkit_settings['ga_slider_layout_mobile'] : $defaults['layout_tablet'] );
		$defaults['thumb_width_tablet']   = ( ! empty( $shopkit_settings['ga_thumb_width_tablet'] ) ? $shopkit_settings['ga_thumb_width_tablet'] : $defaults['thumb_width'] );
		$defaults['thumb_width_mobile']   = ( ! empty( $shopkit_settings['ga_thumb_width_mobile'] ) ? $shopkit_settings['ga_thumb_width_mobile'] : $defaults['thumb_width_tablet'] );
		$defaults['thumb_columns_tablet'] = ( ! empty( $shopkit_settings['ga_thumb_columns_tablet'] ) ? $shopkit_settings['ga_thumb_columns_tablet'] : $defaults['thumb_columns'] );
		$defaults['thumb_columns_mobile'] = ( ! empty( $shopkit_settings['ga_thumb_columns_mobile'] ) ? $shopkit_settings['ga_thumb_columns_mobile'] : $defaults['thumb_columns_tablet'] );
		$defaults['thumb_gap_tablet']     = $defaults['thumb_gap'];
		$defaults['thumb_gap_mobile']     = $defaults['thumb_gap'];

		// Generate Final Size Settings.
		$gallery_args = wp_parse_args( $args, $defaults );
		if ( $gallery_args['is_custom'] ) {
			$gallery_args['width'] = $gallery_args['custom_width'];
			if ( 'custom' === $gallery_args['ratio'] ) {
				if ( ! empty( $gallery_args['custom_height'] ) ) {
					$gallery_args['height'] = $gallery_args['custom_height'];
				} elseif ( ! empty( $shopkit_settings['ga_image_height'] ) ) {
					$gallery_args['height'] = $shopkit_settings['ga_image_height'];
				} elseif ( empty( $gallery_args['height'] ) ) {
					$gallery_args['height'] = 465;
				}
			} elseif ( 'portrait' === $gallery_args['ratio'] ) {
				$gallery_args['height'] = floor( $gallery_args['width'] * 1.35 );
			} elseif ( 'landscape' === $gallery_args['ratio'] ) {
				$gallery_args['height'] = floor( $gallery_args['width'] / 1.35 );
			} elseif ( 'landscape32' === $gallery_args['ratio'] ) {
				$gallery_args['height'] = floor( $gallery_args['width'] / 1.5 );
			} elseif ( 'landscape169' === $gallery_args['ratio'] ) {
				$gallery_args['height'] = floor( $gallery_args['width'] * 0.5625 );
			} elseif ( 'widelandscape' === $gallery_args['ratio'] ) {
				$gallery_args['height'] = floor( $gallery_args['width'] / 2 );
			} else {
				$gallery_args['height'] = $gallery_args['width'];
			}
		} else {
			$woo_image_size = apply_filters( 'woocommerce_gallery_image_size', 'woocommerce_single' );
			if ( has_post_thumbnail() ) {
				$woo_img                = wp_get_attachment_image_src( get_post_thumbnail_id(), $woo_image_size );
				$gallery_args['width']  = ( ! empty( $woo_img[1] ) ? $woo_img[1] : '600' );
				$gallery_args['height'] = ( ! empty( $woo_img[2] ) ? $woo_img[2] : '600' );
			} else {
				$gallery_args['width']  = '600';
				$gallery_args['height'] = '600';
			}
		}

		$gallery_args['vlayout'] = ( 'left' === $gallery_args['layout'] || 'right' === $gallery_args['layout'] ? true : false );

		if ( $gallery_args['vlayout'] ) {
			$gallery_args['thumb_img_height'] = floor( $gallery_args['height'] / $gallery_args['thumb_columns'] ) - 2;
			if ( 'portrait' === $gallery_args['thumb_ratio'] ) {
				$gallery_args['thumb_img_width'] = floor( $gallery_args['thumb_img_height'] / 1.35 );
			} elseif ( 'landscape' === $gallery_args['thumb_ratio'] ) {
				$gallery_args['thumb_img_width'] = floor( $gallery_args['thumb_img_height'] * 1.35 );
			} elseif ( 'landscape32' === $gallery_args['thumb_ratio'] ) {
				$gallery_args['thumb_img_width'] = floor( $gallery_args['thumb_img_height'] * 1.5 );
			} elseif ( 'landscape169' === $gallery_args['thumb_ratio'] ) {
				$gallery_args['thumb_img_width'] = floor( $gallery_args['thumb_img_height'] * 1.78 );
			} elseif ( 'widelandscape' === $gallery_args['thumb_ratio'] ) {
				$gallery_args['thumb_img_width'] = floor( $gallery_args['thumb_img_height'] * 2 );
			} elseif ( 'inherit' === $gallery_args['thumb_ratio'] ) {
				$gallery_args['thumb_img_width']  = 120;
				$gallery_args['thumb_img_height'] = null;
			} else {
				$gallery_args['thumb_img_width'] = $gallery_args['thumb_img_height'];
			}
		} else {
			$gallery_args['thumb_img_width'] = floor( $gallery_args['width'] / $gallery_args['thumb_columns'] );
			if ( 'portrait' === $gallery_args['thumb_ratio'] ) {
				$gallery_args['thumb_img_height'] = floor( $gallery_args['thumb_img_width'] * 1.35 );
			} elseif ( 'landscape' === $gallery_args['thumb_ratio'] ) {
				$gallery_args['thumb_img_height'] = floor( $gallery_args['thumb_img_width'] / 1.35 );
			} elseif ( 'landscape32' === $gallery_args['thumb_ratio'] ) {
				$gallery_args['thumb_img_height'] = floor( $gallery_args['thumb_img_width'] / 1.5 );
			} elseif ( 'landscape169' === $gallery_args['thumb_ratio'] ) {
				$gallery_args['thumb_img_height'] = floor( $gallery_args['thumb_img_width'] * 0.5625 );
			} elseif ( 'inherit' === $gallery_args['thumb_ratio'] ) {
				$gallery_args['thumb_img_height'] = null;
			} elseif ( 'widelandscape' === $gallery_args['thumb_ratio'] ) {
				$gallery_args['thumb_img_height'] = floor( $gallery_args['thumb_img_width'] / 2 );
			} else {
				$gallery_args['thumb_img_height'] = $gallery_args['thumb_img_width'];
			}
		}
		if ( 'left' === $gallery_args['layout'] ) {
			$gallery_args['margin']      = 'margin-left:' . esc_attr( $gallery_args['thumb_width'] ) . '%;';
			$gallery_args['thumb_style'] = 'width:' . esc_attr( $gallery_args['thumb_width'] ) . '%;';
		} elseif ( 'right' === $gallery_args['layout'] ) {
			$gallery_args['margin']      = 'margin-right:' . esc_attr( $gallery_args['thumb_width'] ) . '%;';
			$gallery_args['thumb_style'] = 'width:' . esc_attr( $gallery_args['thumb_width'] ) . '%;';
		} else {
			$gallery_args['margin']      = '';
			$gallery_args['thumb_style'] = 'width:auto;';
		}
		self::$gallery_args = $gallery_args;
		return $gallery_args;
	}
	/**
	 * Output the Gallery.
	 *
	 * @param array<mixed> $args Array of arguments.
	 *
	 * @return void
	 */
	public function output_gallery( $args = array() ) {
		global $product, $in_quickview;

		$args = $this->get_render_gallery_args( $args );

		if ( has_post_thumbnail() ) {
			$feature_id     = array( get_post_thumbnail_id() );
			$attachment_ids = $product->get_gallery_image_ids();
			$images         = array_merge( $feature_id, $attachment_ids );
			$count          = count( $images );

			if ( empty( $attachment_ids ) ) {
				$args['margin']        = '';
				$args['layout']        = 'above';
				$args['layout_tablet'] = 'above';
				$args['layout_mobile'] = 'above';
				$args['vlayout']       = false;
			}
			$should_lazy = ! in_array( $args['layout'], self::get_stacked_layouts(), true );
			$lazy        = apply_filters( 'kadence_shop_kit_gallery_lazy_load', $should_lazy );
			$is_slider   = true;
			if ( in_array( $args['layout'], self::get_stacked_layouts(), true ) ) {
				$is_slider = false;
				// If layout is stacked, disable arrows and pagination.
				$args['arrows']     = false;
				$args['pagination'] = false;
			}
			$args['thumb_load_columns']    = $args['thumb_columns'];
			$args['thumb_sm_load_columns'] = $args['thumb_columns_mobile'];
			$thumb_sm_max_width            = '';
			$thumb_max_width               = '';
			if ( $count > $args['thumb_columns'] ) {
				$thumb_class = 'kt_thumb_show_arrow';
				$center      = 'true';
			} elseif ( $count === $args['thumb_columns'] ) {
				if ( $args['vlayout'] ) {
					$center      = 'false';
					$thumb_class = 'kt_thumb_show_arrow';
				} else {
					$center      = 'false';
					$thumb_class = 'kt_thumb_hide_arrow';
				}
			} elseif ( $args['vlayout'] ) {
					$center      = 'false';
					$thumb_class = 'kt_thumb_show_arrow';
			} else {
				$thumb_max_width            = floor( ( 100 / (int) $args['thumb_columns'] ) * $count ) . '%';
				$center                     = 'false';
				$args['thumb_load_columns'] = $count;
				$thumb_class                = 'kt_thumb_hide_arrow';
			}
			if ( $count < $args['thumb_columns_mobile'] && ! $args['vlayout'] ) {
				$args['thumb_sm_load_columns'] = $count;
				$thumb_sm_max_width            = floor( ( 100 / (int) $args['thumb_columns_mobile'] ) * $count ) . '%';
			}
			$product_wrapper_width = ( $args['vlayout'] ? 'calc(' . $args['width'] . 'px + ' . $args['thumb_width'] . '% )' : $args['width'] . 'px;' );
			if ( in_array( $args['layout'], [ 'grid', 'tiles', 'grid-highlighted' ], true ) ) {
				$product_wrapper_width = 'calc(' . $args['width'] . 'px * 2 );';
			} elseif ( in_array( $args['layout'], [ 'grid-3-col', 'grid-3-col-highlighted' ], true ) ) {
				$product_wrapper_width = 'calc(' . $args['width'] . 'px * 3 );';
			}
			$css = new Kadence_Woo_CSS();
			if ( 'above' === $args['layout'] ) {
				$css->set_selector( '#pg-thumbnails-' . get_the_ID() . ' .thumb-wrapper' );
				$css->add_property( 'max-width', $thumb_max_width );
			}
			if ( 'above' === $args['layout_mobile'] ) {
				$css->start_media_query( '(max-width: 767px)' );
				$css->set_selector( '#pg-thumbnails-' . get_the_ID() . ' .thumb-wrapper' );
				$css->add_property( 'max-width', $thumb_sm_max_width );
				$css->stop_media_query();
			}

			// fade transition can make some slides invisible, this is not neccessary for these layouts.
			$css->set_selector( '#pg-main-' . get_the_ID() . '.kb-splide.splide--fade > .splide__slider > .splide__track > .splide__list > .splide__slide, #pg-main-' . get_the_ID() . '.kb-splide.splide--fade > .splide__track > .splide__list > .splide__slide' );
			if ( in_array( $args['layout'], self::get_stacked_layouts(), true ) ) {
				$css->add_property( 'opacity', 1 );
			}
			if ( in_array( $args['layout_tablet'], self::get_stacked_layouts(), true ) ) {
				$css->start_media_query( '(max-width: 1024px)' );
				$css->add_property( 'opacity', 1 );
				$css->stop_media_query();
			}
			if ( in_array( $args['layout_mobile'], self::get_stacked_layouts(), true ) ) {
				$css->start_media_query( '(max-width: 767px)' );
				$css->add_property( 'opacity', 1 );
				$css->stop_media_query();
			}
			// Main gallery: arrows transparent bg, icon colour and pagination from fg setting.
			$css->set_selector( '#pg-main-' . get_the_ID() );
			$css->add_property( '--splide-nav-color', (string) $args['ui_fg_colour'] );
			$css->add_property( '--splide-nav-background', 'transparent' );
			$css->add_property( '--splide-nav-border', '2px solid transparent' );
			$css->add_property( '--splide-pagination-background', (string) $args['ui_fg_colour'] );
			$css->add_property( '--kt-gallery-fg', (string) $args['ui_fg_colour'] );
			$css->add_property( '--kt-gallery-bg', (string) $args['ui_bg_colour'] );
			// Thumbnail strip: bg and fg from colour settings.
			$css->set_selector( '#pg-thumbnails-' . get_the_ID() );
			$css->add_property( '--splide-nav-color', (string) $args['ui_fg_colour'] );
			$css->add_property( '--splide-nav-background', (string) $args['ui_bg_colour'] );
			$css->add_property( '--kt-gallery-fg', (string) $args['ui_fg_colour'] );
			$css->add_property( '--kt-gallery-bg', (string) $args['ui_bg_colour'] );
			// Active thumbnail border colour.
			$css->set_selector( '#pg-thumbnails-' . get_the_ID() . '.splide--nav .splide__slide.is-active' );
			$css->add_property( 'outline-color', (string) $args['ui_bg_colour'] );
			if ( $args['zoomactive'] ) {
				$css->set_selector( '.zm-handlerarea' );
				$css->add_property( 'background', (string) $args['zoom_lens_colour'] );
				$css->add_property( 'opacity', (string) $args['zoom_lens_opacity'] );

				if ( 'follow' === $args['zoomtype'] && 'circular' === $args['zoomshape'] ) {
					$radius = max( (int) $args['zoom_lens_width'], (int) $args['zoom_lens_height'] );
					$css->set_selector( '.zm-viewer.shapecircular' );
					$css->add_property( 'border-radius', $radius . 'px' );
				}
			}
			$styles          = $css->css_output();
			$wrapper_classes = apply_filters(
				'woocommerce_single_product_image_gallery_classes',
				array(
					'woocommerce-product-gallery',
					'woocommerce-product-gallery--with-images',
					'images',
				)
			);
			if ( ! empty( $styles ) ) {
				echo '<style>' . $styles . '</style>';
			}
			$slider_class = in_array( $args['layout'], self::get_stacked_layouts(), true ) ? 'ksk-gallery--noslider' : 'ksk-gallery--slider';
			echo '<div class="ksk-gallery kad-light-gallery ' . esc_attr( (string) $slider_class ) . ' kt-layout-' . esc_attr( (string) $args['layout'] ) . ' kt-md-layout-' . esc_attr( (string) $args['layout_tablet'] ) . ' kt-sm-layout-' . esc_attr( (string) $args['layout_mobile'] ) . ' ' . esc_attr( implode( ' ', array_map( 'sanitize_html_class', $wrapper_classes ) ) ) . '">';
			echo '<div class="product_image" style="max-width:' . esc_attr( (string) $product_wrapper_width ) . '">';
			$main_gallery_classes = 'kadence-product-gallery-main kadence-ga-splide-init kb-splide splide';
			if ( $args['icons_hover'] ) {
				$main_gallery_classes .= ' kt-icons-on-hover';
			}
			if ( $args['icons_tooltips'] ) {
				$main_gallery_classes .= ' kt-icons-tooltips';
			}
			echo '<div id="pg-main-' . esc_attr( (string) get_the_ID() ) . '" class="' . esc_attr( $main_gallery_classes ) . '" style="' . esc_attr( (string) $args['margin'] ) . '" data-speed="' . esc_attr( (string) $args['pausetime'] ) . '" data-animation-speed="' . esc_attr( (string) $args['transtime'] ) . '" data-product-id="' . esc_attr( (string) get_the_ID() ) . '" data-vlayout="' . esc_attr( (string) $args['vlayout'] ? 'true' : 'false' ) . '"  data-animation="' . esc_attr( (string) $args['transtype'] ? 'true' : 'false' ) . '" data-auto="' . esc_attr( (string) $args['autoplay'] ? 'true' : 'false' ) . '" data-auto-height="' . esc_attr( (string) $args['auto_height'] ? 'true' : 'false' ) . '" data-arrows="' . esc_attr( $args['arrows'] ? 'true' : 'false' ) . '" data-pagination="' . esc_attr( $args['pagination'] ? 'true' : 'false' ) . '" data-gallery-items="' . esc_attr( (string) $count ) . '" data-zoom-type="' . esc_attr( (string) $args['zoomtype'] ) . '" data-visible-captions="' . esc_attr( $args['show_caption'] ? 'true' : 'false' ) . '" data-zoom-active="' . esc_attr( $args['zoomactive'] ? 'true' : 'false' ) . '" data-thumb-show="' . esc_attr( (string) $args['thumb_columns'] ) . '" data-md-thumb-show="' . esc_attr( (string) $args['thumb_columns_tablet'] ) . '" data-sm-thumb-show="' . esc_attr( (string) $args['thumb_columns_mobile'] ) . '" data-thumbcol="' . esc_attr( (string) $args['thumb_load_columns'] ) . '" data-sm-thumbcol="' . esc_attr( (string) $args['thumb_sm_load_columns'] ) . '" data-layout="' . esc_attr( (string) $args['layout'] ) . '" data-md-layout="' . esc_attr( (string) $args['layout_tablet'] ) . '" data-sm-layout="' . esc_attr( (string) $args['layout_mobile'] ) . '" data-thumb-width="' . esc_attr( (string) $args['thumb_width'] ) . '" data-md-thumb-width="' . esc_attr( (string) $args['thumb_width_tablet'] ) . '" data-sm-thumb-width="' . esc_attr( (string) $args['thumb_width_mobile'] ) . '" data-thumb-gap="' . esc_attr( (string) $args['thumb_gap'] ) . '" data-md-thumb-gap="' . esc_attr( (string) $args['thumb_gap_tablet'] ) . '" data-sm-thumb-gap="' . esc_attr( (string) $args['thumb_gap_mobile'] ) . '" data-thumb-center="' . esc_attr( (string) $center ) . '" data-thumb-hover="' . esc_attr( (string) $args['thumb_hover'] ? 'true' : 'false' ) . '" data-loop="' . esc_attr( $args['loop'] ? 'true' : 'false' ) . '" data-maintain-index="' . esc_attr( $args['maintain_index'] ? 'true' : 'false' ) . '" data-swipe-threshold="' . esc_attr( (string) $args['swipe_threshold'] ) . '" data-lazyload="' . esc_attr( (string) $args['lazyload'] ) . '" data-thumb-trans-speed="' . esc_attr( (string) $args['thumb_trans_speed'] ) . '" data-thumb-controls="' . esc_attr( $args['thumb_controls'] ? 'true' : 'false' ) . '">';
			$number     = 1;
			$thumbnails = array();
			echo '<div class="splide__track"><ul class="splide__list">';
			foreach ( $images as $key => $slide ) :
				$alt = esc_attr( get_post_meta( $slide, '_wp_attachment_image_alt', true ) );
				if ( ! empty( $alt ) ) {
					$alttag = $alt;
				} else {
					$alttag = esc_attr( get_post_field( 'post_title', $slide ) );
				}
				$data_caption = get_post_field( 'post_excerpt', $slide );
				$video        = false;
				if ( ! $args['is_custom'] ) {
					$woo_image_size = apply_filters( 'woocommerce_gallery_image_size', 'woocommerce_single' );
					$woo_img        = wp_get_attachment_image_src( $slide, $woo_image_size );
					if ( $woo_img ) {
						$woo_meta   = wp_get_attachment_metadata( $slide );
						$full_src   = wp_get_attachment_image_src( $slide, 'full' );
						$img_srcset = wp_calculate_image_srcset( array( $woo_img[1], $woo_img[2] ), $woo_img[0], $woo_meta, $slide );
					}
					$img = array(
						'full'        => ! empty( $full_src[0] ) ? esc_url( $full_src[0] ) : '',
						'full_width'  => ! empty( $full_src[1] ) ? $full_src[1] : '',
						'full_height' => ! empty( $full_src[2] ) ? $full_src[2] : '',
						'src'         => ! empty( $woo_img[0] ) ? esc_url( $woo_img[0] ) : '',
						'width'       => ! empty( $woo_img[1] ) ? $woo_img[1] : '',
						'height'      => ! empty( $woo_img[2] ) ? $woo_img[2] : '',
						'alt'         => ! empty( $alttag ) ? $alttag : '',
						'srcset'      => ! empty( $img_srcset ) ? 'srcset="' . esc_attr( $img_srcset ) . '" sizes="(max-width: ' . esc_attr( ! empty( $woo_img[1] ) ? $woo_img[1] : '' ) . 'px) 100vw, ' . esc_attr( ! empty( $woo_img[1] ) ? $woo_img[1] : '' ) . 'px"' : '',
					);
				} else {
					$img = kt_woo_get_image_array( $args['width'], $args['height'], true, 'attachment-shop-single', $alttag, $slide, false, 'woocommerce_single' );
				}
				$image_class_output = 'zoom kt-image-slide kt-no-lightbox';
				if ( 1 === $number ) {
					$image_class_output = 'woocommerce-main-image ' . $image_class_output;
				}
				$img_link   = $img['full'];
				$video_link = get_post_meta( $slide, '_kt_woo_product_video', true );
				if ( ! empty( $video_link ) && $args['lightbox'] ) {
					$img_link            = get_post_meta( $slide, '_kt_woo_product_video', true );
					$image_class_output .= ' kt-woo-video-link';
					$video               = true;
				}
				$thumbnails[ $key ] = array(
					'video' => $video,
					'img'   => kt_woo_get_image_array( $args['thumb_img_width'], $args['thumb_img_height'], true, 'attachment-shop-single', $alttag, $slide, false, 'thumbnail' ),
				);
				$html               = '<li class="splide__slide' . ( 1 === $number ? ' woo-main-slide' : '' ) . '">';
				if ( $args['lightbox'] && ! $in_quickview ) {
					$poster_attr = ( $video && $args['video_poster'] ) ? ' data-poster="' . esc_url( $img['full'] ) . '"' : '';
					$html       .= '<a href="' . esc_url( $img_link ) . '" data-rel="lightbox" itemprop="image" class="' . esc_attr( $image_class_output ) . '" data-description="' . esc_attr( $data_caption ) . '" title="' . esc_attr( get_post_field( 'post_title', $slide ) ) . '"' . $poster_attr . '>';
				}
				if ( $lazy && $is_slider && 1 !== $number ) {
					$html .= '<img width="' . esc_attr( $img['width'] ) . '" style="width: ' . esc_attr( $img['width'] ) . 'px" data-splide-lazy="' . esc_url( $img['src'] ) . '" data-thumb="' . esc_url( $thumbnails[ $key ]['img']['src'] ) . '" class="attachment-shop-single" data-caption="' . esc_attr( $data_caption ) . '" title="' . esc_attr( get_post_field( 'post_title', $slide ) ) . '" data-zoom-image="' . esc_url( $img['full'] ) . '" height="' . esc_attr( $img['height'] ) . '" alt="' . esc_attr( $img['alt'] ) . '" ' . str_replace( 'srcset=', 'data-splide-lazy-srcset=', $img['srcset'] ) . ' />';
				} else {
					$html .= '<img width="' . esc_attr( $img['width'] ) . '" style="width: ' . esc_attr( $img['width'] ) . 'px" data-thumb="' . esc_url( $thumbnails[ $key ]['img']['src'] ) . '" class="attachment-shop-single skip-lazy" data-caption="' . esc_attr( $data_caption ) . '" title="' . esc_attr( get_post_field( 'post_title', $slide ) ) . '" data-zoom-image="' . esc_url( $img['full'] ) . '" height="' . esc_attr( $img['height'] ) . '"' . ( $lazy && 1 !== $number ? ' loading="lazy"' : '' ) . ' src="' . esc_url( $img['src'] ) . '" alt="' . esc_attr( $img['alt'] ) . '" ' . $img['srcset'] . ' />';
				}
				if ( $args['show_caption'] && ! empty( $data_caption ) ) {
					$html .= '<span class="sp-gal-image-caption">' . wp_kses_post( $data_caption ) . '</span>';
				}
				if ( $video ) {
					$html .= '<span class="kt-woo-play-btn">';
					$html .= kadence_woo_extras_get_icon( 'play', '', false, true );
					$html .= '</span>';
				}
				if ( $args['lightbox'] && ! $in_quickview ) {
					$html .= '</a>';
				}
				$html .= '</li>';
				echo apply_filters( 'kadence_single_product_image_main_html', $html, $slide ); // phpcs:disable WordPress.XSS.EscapeOutput.OutputNotEscaped
				++$number;
			endforeach;
			echo '</ul>';
			echo '</div>';
			if ( $args['lightbox'] ) {
				echo '<button class="kt-gallery-fullscreen-btn" aria-label="' . esc_attr__( 'Open fullscreen gallery', 'kadence-shop-kit' ) . '" data-tooltip="' . esc_attr__( 'Fullscreen', 'kadence-shop-kit' ) . '">';
				echo kadence_woo_extras_get_icon( 'expand', '', false, true ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				echo '</button>';
				$video_url = get_post_meta( (int) get_the_ID(), '_kt_woo_gallery_video_url', true );
				if ( ! empty( $video_url ) && is_string( $video_url ) ) {
					echo '<a href="' . esc_url( $video_url ) . '" class="kt-gallery-video-btn" data-rel="lightbox" aria-label="' . esc_attr__( 'Play Product Video', 'kadence-shop-kit' ) . '" data-tooltip="' . esc_attr__( 'Play Video', 'kadence-shop-kit' ) . '">';
					echo kadence_woo_extras_get_icon( 'video', __( 'Play Product Video', 'kadence-shop-kit' ), false, true ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					echo '</a>';
				}
			}
			echo '</div><!-- main -->';
			if ( ! empty( $attachment_ids ) ) {
				echo '<div id="pg-thumbnails-' . esc_attr( get_the_ID() ) . '" class="kadence-product-gallery-thumbnails splide kb-splide ' . esc_attr( $thumb_class ) . '" style="' . esc_attr( $args['thumb_style'] ) . '">';
				echo '<div class="thumb-wrapper splide__slider">';
				echo '<div class="splide__track"><ul class="splide__list">';
				$number = 1;
				foreach ( $images as $key => $slide ) :
					$thumbnail_class = 'kt-woo-gallery-thumbnail splide__slide';
					if ( $thumbnails[ $key ]['video'] ) {
						$thumbnail_class .= ' kt-woo-video-thumb';
					}
					if ( 1 === $number ) {
						$thumbnail_class .= ' woocommerce-main-image-thumb';
					}
					$html  = '<li class="' . esc_attr( $thumbnail_class ) . '">';
					$html .= '<img width="' . esc_attr( $thumbnails[ $key ]['img']['width'] ) . '" height="' . esc_attr( $thumbnails[ $key ]['img']['height'] ) . '" src="' . esc_url( $thumbnails[ $key ]['img']['src'] ) . '" alt="' . esc_attr( $thumbnails[ $key ]['img']['alt'] ) . '" ' . $thumbnails[ $key ]['img']['srcset'] . ' />';
					if ( $thumbnails[ $key ]['video'] ) {
						$html .= '<span class="kt-woo-play-btn">';
						$html .= kadence_woo_extras_get_icon( 'play-circle', '', false, true );
						$html .= '</span>';
					}
					$html .= '</li>';
					echo apply_filters( 'kadence_single_product_image_thumbnail_html', $html, $slide ); // phpcs:disable WordPress.XSS.EscapeOutput.OutputNotEscaped
					++$number;
					endforeach;
					echo '</ul></div>';
					echo '</div>';
				echo '</div><!-- thumbnails -->';
			}
			echo '</div></div>';
			if ( $product->is_type( 'variable' ) || $product->is_type( 'variable-subscription' ) ) {
				do_action( 'kadence_shopkit_variation_gallery', $args );
			}
		}
	}
	/**
	 * Register ShopKit product data tab.
	 *
	 * @param array<string, mixed> $tabs Existing product data tabs.
	 * @return array<string, mixed>
	 */
	public function register_product_data_tab( $tabs ) {
		$tabs['kt_shopkit_gallery'] = array(
			'label'    => __( 'Shop Kit Gallery', 'kadence-shop-kit' ),
			'target'   => 'kt_woo_gallery_options',
			'class'    => array( 'kt_woo_gallery_options_tab' ),
			'priority' => 72,
		);
		return $tabs;
	}

	/**
	 * Render the ShopKit product data panel.
	 */
	public function render_product_data_panel(): void {
		global $post;
		$video_url = get_post_meta( $post->ID, '_kt_woo_gallery_video_url', true );
		?>
		<div id="kt_woo_gallery_options" class="panel woocommerce_options_panel">
			<?php
			woocommerce_wp_checkbox(
				array(
					'id'    => '_kt_woo_gallery_disable',
					'label' => __( 'Disable ShopKit Product Gallery?', 'kadence-shop-kit' ),
				)
			);
			woocommerce_wp_text_input(
				array(
					'id'          => '_kt_woo_gallery_video_url',
					'label'       => __( 'Video URL', 'kadence-shop-kit' ),
					'desc_tip'    => true,
					'description' => __( 'Enter a video URL to display in the lightbox. A video icon will appear on the gallery slider. Most video hosting services are supported.', 'kadence-shop-kit' ),
					'value'       => esc_attr( is_string( $video_url ) ? $video_url : '' ),
				)
			);
			?>
			<p class="form-field">
				<a href="#" class="kt-upload-media button-secondary" data-target="#_kt_woo_gallery_video_url"><?php esc_html_e( 'Attach MP4/WEBM', 'kadence-shop-kit' ); ?></a>
			</p>
		</div>
		<?php
	}

	/**
	 * Save ShopKit product data fields.
	 *
	 * @param int $post_id The product post ID.
	 */
	public function save_product_data_fields( $post_id ): void {
		if ( isset( $_POST['_wpnonce'] ) && ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ), 'update-post_' . $post_id ) ) {
			return;
		}
		$disable = isset( $_POST['_kt_woo_gallery_disable'] ) ? 'yes' : 'no';
		update_post_meta( $post_id, '_kt_woo_gallery_disable', $disable );

		$video_url = isset( $_POST['_kt_woo_gallery_video_url'] ) ? sanitize_url( wp_unslash( $_POST['_kt_woo_gallery_video_url'] ) ) : '';
		update_post_meta( $post_id, '_kt_woo_gallery_video_url', $video_url );
	}

	/**
	 * Check if the gallery is disabled.
	 *
	 * @param int|false $product_id The product ID.
	 * @return bool
	 */
	public function is_gallery_disabled( $product_id ): bool {
		if ( ! $product_id ) {
			return false;
		}
		return get_post_meta( $product_id, '_kt_woo_gallery_disable', true ) === 'yes';
	}
}

$GLOBALS['kt_product_gallery'] = Kadence_Shop_Kit_Product_Gallery::get_instance();
