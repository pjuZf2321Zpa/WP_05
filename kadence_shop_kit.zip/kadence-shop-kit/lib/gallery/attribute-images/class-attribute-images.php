<?php
/**
 * Attribute Images module for Kadence Shop Kit Gallery.
 *
 * Reads attribute-term → image mappings stored in `_iconic_woothumbs_ai` post
 * meta, pre-renders them as Splide-compatible slide HTML, and outputs the result
 * as `window.kadence_attribute_images_data` so the gallery JS can switch images
 * when the customer changes an attribute dropdown.
 *
 * @package Kadence WooCommerce Extras
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Kadence_Attribute_Images
 */
class Kadence_Attribute_Images {

	/**
	 * Singleton instance.
	 *
	 * @var self|null
	 */
	private static $instance = null;

	/**
	 * Instance Control.
	 *
	 * @return self
	 */
	public static function get_instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor — registers hooks.
	 */
	public function __construct() {
		// Output pre-rendered slide data right before the variations form.
		add_action( 'woocommerce_before_variations_form', array( $this, 'output_attribute_images_data' ), 10 );
	}

	/**
	 * Build and output `window.kadence_attribute_images_data` as an inline script.
	 *
	 * Called on `woocommerce_before_variations_form` so `$product` is in scope.
	 * The data shape mirrors `$datathumbs` in the gallery JS:
	 *
	 *   {
	 *     "pa_color": {
	 *       "red":  { "images": ["<li>…</li>", …], "thumbnails": ["<li>…</li>", …] },
	 *       "any":  { … }   // wildcard term
	 *     },
	 *     "all": {
	 *       "all":  { … }   // images shown for every attribute selection
	 *     }
	 *   }
	 *
	 * @return void
	 */
	public function output_attribute_images_data() {
		global $product;

		if ( ! $product || ! $product->is_type( 'variable' ) ) {
			return;
		}

		$product_id      = $product->get_id();
		$attributes_data = get_post_meta( $product_id, '_iconic_woothumbs_ai', true );

		if ( empty( $attributes_data ) || ! is_array( $attributes_data ) ) {
			return;
		}

		if ( ! class_exists( 'Kadence_Shop_Kit_Product_Gallery' ) || ! class_exists( 'Kadence_Variation_Gallery' ) ) {
			return;
		}

		$kskpg = Kadence_Shop_Kit_Product_Gallery::get_instance();
		$args  = $kskpg->get_gallery_args();
		$kvg   = Kadence_Variation_Gallery::get_instance();

		$slides_data = array();

		foreach ( $attributes_data as $attribute_name => $attribute_data ) {
			if ( empty( $attribute_data['terms'] ) || ! is_array( $attribute_data['terms'] ) ) {
				continue;
			}

			$slides_data[ $attribute_name ] = array();

			foreach ( $attribute_data['terms'] as $term_data ) {
				if ( empty( $term_data['term'] ) || empty( $term_data['images'] ) ) {
					continue;
				}

				$term_name = $term_data['term'];

				// Determine the key used for JS lookups.
				if ( 'all' === $attribute_name ) {
					// Special bucket: images shown for every selection.
					$term_key = 'all';
				} elseif ( 'any' === strtolower( $term_name ) ) {
					// Wildcard: shown whenever this attribute has any value selected.
					$term_key = 'any';
				} else {
					// For taxonomy attributes, use the term slug (matches the <select> value).
					// For custom (non-taxonomy) attributes, WooCommerce renders the raw option
					// value directly ( esc_attr( $option ) ), so use the raw term name as the
					// key — do NOT sanitize_title(), which would lowercase it and break matching
					// when the stored value is capitalised (e.g. "Two" stored ≠ "two" in data).
					$term     = get_term_by( 'name', $term_name, $attribute_name );
					$term_key = ( $term && is_a( $term, 'WP_Term' ) ) ? $term->slug : $term_name;
				}

				if ( empty( $term_key ) ) {
					continue;
				}

				$image_ids = array_filter( array_map( 'intval', wp_list_pluck( $term_data['images'], 'id' ) ) );

				if ( empty( $image_ids ) ) {
					continue;
				}

				$slide_array = $kvg->build_slide_array( $image_ids, $args );

				if ( ! empty( $slide_array['images'] ) ) {
					$slides_data[ $attribute_name ][ $term_key ] = $slide_array;
				}
			}

			if ( empty( $slides_data[ $attribute_name ] ) ) {
				unset( $slides_data[ $attribute_name ] );
			}
		}

		if ( empty( $slides_data ) ) {
			return;
		}

		echo '<script>window.kadence_attribute_images_data = ' . wp_json_encode( $slides_data ) . ';</script>' . "\n";
	}
}

Kadence_Attribute_Images::get_instance();
