<?php
/**
 * Attribute Images Admin — Kadence Shop Kit Gallery.
 *
 * Provides the classic WooCommerce product-editor tab and metabox panel for
 * managing per-attribute-term image galleries.  Data is saved to the
 * `_iconic_woothumbs_ai` post meta key to remain backward-compatible with
 * existing product data.
 *
 * @package Kadence WooCommerce Extras
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Kadence_Attribute_Images_Admin
 */
class Kadence_Attribute_Images_Admin {

	/**
	 * Singleton instance.
	 *
	 * @var self|null
	 */
	private static $instance = null;

	/**
	 * Instance Control.
	 *
	 * @return self
	 */
	public static function get_instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor — registers admin hooks.
	 */
	public function __construct() {
		add_filter( 'woocommerce_product_data_tabs', array( $this, 'register_product_tab' ) );
		add_action( 'woocommerce_product_data_panels', array( $this, 'render_product_tab_panel' ) );
		add_action( 'wp_ajax_ksk_get_attribute_terms', array( $this, 'ajax_get_attribute_terms' ) );
		add_action( 'wp_ajax_ksk_save_ai_field_data', array( $this, 'ajax_save_ai_field_data' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_scripts' ) );
	}

	/**
	 * Register the "Attribute Images" tab on the product edit page.
	 *
	 * @param array<string, array<string, mixed>> $tabs Existing product data tabs.
	 * @return array<string, array<string, mixed>>
	 */
	public function register_product_tab( $tabs ) {
		$tabs['ksk_attribute_images'] = array(
			'label'    => __( 'Attribute Images', 'kadence-shop-kit' ),
			'target'   => 'ksk_ai_options',
			'class'    => array( 'ksk_ai_options_tab' ),
			'priority' => 51,
		);
		return $tabs;
	}

	/**
	 * Render the Attribute Images panel HTML inside the product data meta box.
	 *
	 * @return void
	 */
	public function render_product_tab_panel() {
		global $post, $product_object;

		$missing_variations_docs_url = apply_filters(
			'woocommerce_docs_url',
			'https://docs.woocommerce.com/document/variable-product/',
			'product-variations'
		);
		$variations                  = $product_object->get_children();
		$ai_data                     = get_post_meta( $post->ID, '_iconic_woothumbs_ai', true );
		$ai_data                     = $ai_data ? $ai_data : array();
		$product_attributes          = $product_object->get_attributes( 'edit' );
		$variations_notice_style     = $variations ? 'display: none;' : '';
		$ai_data_json                = ! empty( $ai_data ) ? wp_json_encode( $ai_data ) : '';

		$template_path = __DIR__ . '/templates/admin/product-tab-panel.php';

		if ( file_exists( $template_path ) ) {
			include __DIR__ . '/templates/admin/product-tab-panel.php';
		}
	}

	/**
	 * AJAX handler: return attribute terms for a product attribute.
	 *
	 * Used by the admin JS to populate the term <select> inside a row.
	 *
	 * @return void
	 */
	public function ajax_get_attribute_terms() {
		if (
			! isset( $_REQUEST['nonce'] ) ||
			! wp_verify_nonce( sanitize_text_field( wp_unslash( $_REQUEST['nonce'] ) ), 'ksk_ai_nonce' )
		) {
			wp_send_json_error( array( 'msg' => 'Invalid Nonce' ) );
		}

		if ( empty( $_REQUEST['product_id'] ) ) {
			wp_send_json_error( array( 'msg' => 'No product ID supplied' ) );
		}

		if ( empty( $_REQUEST['attribute_name'] ) ) {
			wp_send_json_error( array( 'msg' => 'No attribute name supplied' ) );
		}

		$product_id     = absint( wp_unslash( $_REQUEST['product_id'] ) );
		$product        = wc_get_product( $product_id );
		$attribute_name = urldecode( wp_strip_all_tags( wp_unslash( $_REQUEST['attribute_name'] ) ) );
		$default_terms  = array( 'Any' );

		// Global taxonomy attribute.
		if ( false !== strpos( $attribute_name, 'pa_' ) ) {
			$terms = wc_get_product_terms(
				$product_id,
				$attribute_name,
				array( 'fields' => 'id=>name' )
			);
		} else {
			// Custom product attribute (pipe-separated values stored in meta).
			$attribute_data_raw = $product ? $product->get_attribute( $attribute_name ) : '';
			$attribute_data     = explode( ' | ', $attribute_data_raw );
			$terms              = ! empty( $attribute_data ) ? $attribute_data : array(); // @phpstan-ignore-line
		}

		if ( ! $terms ) {
			wp_send_json_error( array( 'msg' => 'Failed to retrieve terms' ) );
		}

		$encoded_data = wp_json_encode( array_values( array_merge( $default_terms, $terms ) ) );

		if ( $encoded_data ) {
			wp_send_json_success( $encoded_data );
		} else {
			wp_send_json_error();
		}
	}

	/**
	 * AJAX handler: save attribute images field data as post meta.
	 *
	 * The JS collects image IDs per attribute term and POSTs them here.
	 * Data is stored in `_iconic_woothumbs_ai` for backward compatibility.
	 *
	 * @return void
	 */
	public function ajax_save_ai_field_data() {
		if (
			! isset( $_REQUEST['nonce'] ) ||
			! wp_verify_nonce( sanitize_text_field( wp_unslash( $_REQUEST['nonce'] ) ), 'ksk_ai_nonce' )
		) {
			wp_send_json_error( array( 'msg' => 'Invalid Nonce!' ) );
		}

		if ( empty( $_REQUEST['product_id'] ) ) {
			wp_send_json_error( array( 'msg' => 'No product ID supplied!' ) );
		}

		$product_id = absint( wp_unslash( $_REQUEST['product_id'] ) );
		$field_data = ! empty( $_REQUEST['data'] )
			? filter_input( INPUT_POST, 'data', FILTER_DEFAULT, FILTER_REQUIRE_ARRAY )
			: array();

		update_post_meta( $product_id, '_iconic_woothumbs_ai', $field_data );

		wp_send_json_success();
	}

	/**
	 * Enqueue admin scripts and styles on the product edit screen.
	 *
	 * @param string $hook Current admin page hook.
	 *
	 * @return void
	 */
	public function enqueue_admin_scripts( $hook ) {
		if ( ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) {
			return;
		}

		$screen = get_current_screen();
		if ( ! $screen || 'product' !== $screen->post_type ) {
			return;
		}

		wp_enqueue_media();
		wp_enqueue_script( 'selectWoo' );
		wp_enqueue_style( 'select2' );

		wp_enqueue_style(
			'ksk-attribute-images-admin',
			KADENCE_WOO_EXTRAS_URL . 'lib/gallery/attribute-images/css/kadence-attribute-images-admin.css',
			array(),
			KADENCE_WOO_EXTRAS_VERSION
		);

		wp_enqueue_script(
			'ksk-attribute-images-admin',
			KADENCE_WOO_EXTRAS_URL . 'lib/gallery/attribute-images/js/kadence-attribute-images-admin.js',
			array( 'jquery', 'selectWoo' ),
			KADENCE_WOO_EXTRAS_VERSION,
			true
		);

		wp_localize_script(
			'ksk-attribute-images-admin',
			'ksk_ai_vars',
			array(
				'ajaxurl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'ksk_ai_nonce' ),
				'text'    => array(
					'attribute_all_attributes' => __( 'All Attributes', 'kadence-shop-kit' ),
					'all_terms'                => __( 'All Terms', 'kadence-shop-kit' ),
					'click_to_toggle'          => __( 'Click to toggle', 'kadence-shop-kit' ),
					'remove'                   => __( 'Remove', 'kadence-shop-kit' ),
					'add_images'               => __( 'Add Images', 'kadence-shop-kit' ),
					'remove_image'             => __( 'Remove Image', 'kadence-shop-kit' ),
					'attribute'                => __( 'Attribute', 'kadence-shop-kit' ),
					'add'                      => __( 'Add', 'kadence-shop-kit' ),
					'select'                   => __( 'Select', 'kadence-shop-kit' ),
					'filter'                   => __( 'Filter', 'kadence-shop-kit' ),
					'terms'                    => __( 'terms', 'kadence-shop-kit' ),
					'manage_images_for'        => __( 'Manage images for', 'kadence-shop-kit' ),
					'add_to'                   => __( 'Add to', 'kadence-shop-kit' ),
					'sure_remove_images'       => __( 'Are you sure you want to remove these images?', 'kadence-shop-kit' ),
					'sure_cancel_changes'      => __( 'Are you sure you want to cancel your changes?', 'kadence-shop-kit' ),
				),
			)
		);
	}
}

Kadence_Attribute_Images_Admin::get_instance();
