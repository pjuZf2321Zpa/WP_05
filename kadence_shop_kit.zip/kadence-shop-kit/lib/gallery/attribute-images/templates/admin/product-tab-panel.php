<?php
/**
 * Template for the Attribute Images tab panel.
 *
 * Variables provided by Kadence_Attribute_Images_Admin::render_product_tab_panel():
 *
 * @var string|false                        $ai_data_json              JSON-encoded AI data, or false on encode failure.
 * @var string                              $variations_notice_style    Inline style string for the no-variations notice.
 * @var string                              $missing_variations_docs_url URL to the WooCommerce variations docs.
 * @var array<string, WC_Product_Attribute> $product_attributes         Variation attributes keyed by attribute name.
 *
 * @package Kadence WooCommerce Extras
 */

/** @var string|false $ai_data_json */
/** @var string $variations_notice_style */
/** @var string $missing_variations_docs_url */
/** @var array<string, WC_Product_Attribute> $product_attributes */
?>

<div
	id="ksk_ai_options"
	class="panel ksk-ai woocommerce_options_panel"
	data-ai-data="<?php echo esc_attr( $ai_data_json ? $ai_data_json : '{}' ); ?>"
>

	<div
		class="inline notice woocommerce-message ksk-ai__missing-variations-notice"
		style="<?php echo esc_attr( $variations_notice_style ); ?>"
	>
		<p>
			<?php
			echo wp_kses(
				__( 'Before you can add additional images to attributes you need to add some variations on the <strong>Variations</strong> tab.', 'kadence-shop-kit' ),
				array( 'strong' => array() )
			);
			?>
		</p>
		<p>
			<a class="button-primary" href="<?php echo esc_url( $missing_variations_docs_url ); ?>" target="_blank">
				<?php esc_html_e( 'Learn more', 'kadence-shop-kit' ); ?>
			</a>
		</p>
	</div>

	<div class="ksk-ai__toolbar-top">

		<div class="ksk-ai__header-container">
			<span class="ksk-ai__title"><?php esc_html_e( 'Shop Kit', 'kadence-shop-kit' ); ?></span>
			<span class="ksk-ai__subtitle"><?php esc_html_e( 'Attribute Images', 'kadence-shop-kit' ); ?></span>
		</div>

		<div class="ksk-ai__action-container">
			<select id="ksk-ai-action-select" class="ksk-ai__action-select">
				<option value="" disabled><?php esc_html_e( 'Add attribute images...', 'kadence-shop-kit' ); ?></option>
				<option value="all"><?php esc_html_e( 'For all attributes', 'kadence-shop-kit' ); ?></option>
				<?php if ( $product_attributes ) : ?>
					<optgroup label="<?php esc_attr_e( 'For a specific attribute', 'kadence-shop-kit' ); ?>">
						<?php foreach ( $product_attributes as $attribute_name => $attribute_data ) : ?>
							<?php $label = wc_attribute_label( $attribute_data->get_name() ); ?>
							<option
								data-label="<?php echo esc_attr( $label ); ?>"
								value="<?php echo esc_attr( $attribute_name ); ?>"
							>
							<?php
								/* translators: %s: attribute label */
								echo esc_html( sprintf( __( 'Add %s images', 'kadence-shop-kit' ), $label ) );
							?>
							</option>
						<?php endforeach; ?>
					</optgroup>
				<?php endif; ?>
			</select>
			<button disabled id="ksk-ai-action-button" class="button ksk-ai__action-button">
				<?php esc_html_e( 'Add', 'kadence-shop-kit' ); ?>
			</button>
		</div>

		<div id="ksk-ai-search-container" class="ksk-ai__search-container">
			<input
				type="text"
				name="ksk-ai__search-field"
				class="ksk-ai__search-field"
				placeholder="<?php esc_attr_e( 'Filter attribute terms...', 'kadence-shop-kit' ); ?>"
			/>
		</div>

	</div>

	<div class="clear"></div>

	<div
		class="inline notice woocommerce-message ksk-ai__default-state-notice"
		style="<?php echo esc_attr( $variations_notice_style ); ?>"
	>
		<p><?php esc_html_e( 'Select an attribute using the dropdown above to start adding images.', 'kadence-shop-kit' ); ?></p>
	</div>

	<div class="ksk-ai__inner">

		<div id="ksk-ai__section--specific" class="ksk-ai__section ksk-ai__section--specific"></div>

		<div id="ksk-ai__section--all" class="ksk-ai__section ksk-ai__section--all"></div>

		<div class="clear"></div>

		<div id="ksk-ai-toolbar-changes" class="ksk-ai__toolbar-changes">

			<button id="ksk-save-attribute-images" type="button" class="button-primary" disabled="disabled">
				<?php esc_html_e( 'Save changes', 'kadence-shop-kit' ); ?>
			</button>

			<button id="ksk-cancel-attribute-images" type="button" class="button" disabled="disabled">
				<?php esc_html_e( 'Cancel', 'kadence-shop-kit' ); ?>
			</button>

			<div class="ksk-ai__pagenav" style="display: none;">
				<span class="ksk-ai__expand-close">
					(<a href="#" class="expand"><?php esc_html_e( 'Expand All', 'kadence-shop-kit' ); ?></a>
					/
					<a href="#" class="close"><?php esc_html_e( 'Close All', 'kadence-shop-kit' ); ?></a>)
				</span>
			</div>

			<div class="clear"></div>

		</div>

	</div>

</div>
