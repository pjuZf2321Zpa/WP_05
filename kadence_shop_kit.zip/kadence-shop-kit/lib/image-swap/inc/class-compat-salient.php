<?php
/**
 * Compatibility: Salient Theme.
 *
 * @see https://themeforest.net/item/salient-responsive-multipurpose-theme/4363266
 * @package iconic-image-swap
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Salient theme compatibility class.
 */
class Iconic_WIS_Compat_Salient {
	/**
	 * Init.
	 */
	public static function run() {
		$theme = wp_get_theme();

		if ( 'salient' !== $theme->template ) {
			return;
		}

		add_action( 'init', array( __CLASS__, 'fix_duplicated_product_images' ), 20 );
	}

	/**
	 * Fix product images showing duplicated.
	 */
	public static function fix_duplicated_product_images() {
		if ( ! function_exists( 'get_nectar_theme_options' ) ) {
			return;
		}

		$nectar_options       = get_nectar_theme_options();
		$product_style_option = $nectar_options['product_style'] ?? false;

		switch ( $product_style_option ) {
			case 'classic':
				self::remove_salient_actions();
				break;

			case 'text_on_hover':
				self::remove_wis_actions();
				break;

			case 'material':
			case 'minimal':
				self::handle_material_and_minimal_product_styles();
				break;

			default:
				break;
		}
	}

	/**
	 * Remove the Salient actions
	 *
	 * @return void
	 */
	protected static function remove_salient_actions() {
		remove_action( 'woocommerce_before_shop_loop_item_title', 'nectar_product_thumbnail_with_cart' );
		remove_action( 'woocommerce_before_shop_loop_item_title', 'nectar_product_thumbnail_with_cart_alt' );
		remove_action( 'woocommerce_before_shop_loop_item_title', 'nectar_product_thumbnail_material' );
		remove_action( 'woocommerce_before_shop_loop_item_title', 'nectar_product_thumbnail_minimal' );
	}

	/**
	 * Remove Iconic Image Swap for WooCommerce actions
	 *
	 * @return void
	 */
	protected static function remove_wis_actions() {
		global $iconic_woo_image_swap_class;

		remove_action( 'woocommerce_before_shop_loop_item', array( $iconic_woo_image_swap_class, 'template_loop_product_thumbnail' ), 5 );
	}

	/**
	 * Handle the Material and Minimal product styles
	 *
	 * @return void
	 */
	protected static function handle_material_and_minimal_product_styles() {
		add_action( 'wp_print_styles', array( __CLASS__, 'output_css_style_for_material_and_minimal_product_styles' ) );
		add_action( 'wp_print_scripts', array( __CLASS__, 'output_script_for_material_and_minimal_product_styles' ) );
	}

	/**
	 * Output the CSS style to handle Material and Minimal product styles
	 *
	 * @return void
	 */
	public static function output_css_style_for_material_and_minimal_product_styles() {
		if ( ! is_shop() && ! is_product_taxonomy() ) {
			return;
		}

		?>
		<style>
			ul.products li.product .iconic-wis-product-image {
				display: none;
			}

			ul.products li.product .product-wrap .iconic-wis-product-image {
				display: unset;
			}
		</style>
		<?php
	}

	/**
	 * Output the JS script to handle Material and Minimal product styles
	 *
	 * The script copies the images with swap effect added by
	 * WIS to the element added to the Salient theme. This is
	 * necessary because Salient theme doesn't offer a hook to
	 * do that in the server side.
	 *
	 * @return void
	 */
	public static function output_script_for_material_and_minimal_product_styles() {
		if ( ! is_shop() && ! is_product_taxonomy() ) {
			return;
		}

		?>
		<script>
			document.addEventListener('DOMContentLoaded', function() {
				const products = document.querySelectorAll('ul.products li.product');
	
				if (!products) {
					return;
				}
	
				products.forEach(product => {
					const sourceElement = product.querySelector('.iconic-wis-product-image');
					const targetElement = product.querySelector('.product-wrap a');
	
					if (sourceElement && targetElement) {
						const clonedContent = sourceElement.cloneNode(true);
	
						targetElement.replaceWith(clonedContent);
						sourceElement.remove();
					}
				});
			});
		</script>
		<?php
	}
}
