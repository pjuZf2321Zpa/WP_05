<?php
/**
 * Admin Settings.
 *
 * @package iconic-image-swap
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

add_filter( 'wpsf_register_settings_iconic_wis', 'iconic_wis_settings' );

/**
 * Iconic Image Swap for WooCommerce Settings
 *
 * @param array $settings Plugin settings.
 *
 * @return array
 */
function iconic_wis_settings( $settings ) {
	// Tabs.

	$settings['tabs'][] = array(
		'id'    => 'general',
		'title' => __( 'General', 'kadence-shop-kit' ),
	);

	$settings['tabs'][] = array(
		'id'    => 'effects',
		'title' => __( 'Effect Settings', 'kadence-shop-kit' ),
	);

	$settings['tabs'][] = array(
		'id'    => 'compatibility',
		'title' => __( 'Compatibility Settings', 'kadence-shop-kit' ),
	);

	// Sections.

	$settings['sections'][] = array(
		'tab_id'              => 'general',
		'section_id'          => 'display',
		'section_title'       => __( 'Display Settings', 'kadence-shop-kit' ),
		'section_description' => '',
		'section_order'       => 10,
		'fields'              => array(
			array(
				'id'       => 'effect',
				'title'    => __( 'Effect', 'kadence-shop-kit' ),
				'subtitle' => '',
				'type'     => 'select',
				'default'  => 'fade',
				'choices'  => array(
					'fade'       => __( 'Fade on Hover', 'kadence-shop-kit' ),
					'slide'      => __( 'Slide', 'kadence-shop-kit' ),
					'bullets'    => __( 'Bullets', 'kadence-shop-kit' ),
					'thumbnails' => __( 'Thumbnails', 'kadence-shop-kit' ),
					'zoom'       => __( 'Zoom', 'kadence-shop-kit' ),
					'pip'        => __( 'Picture in Picture', 'kadence-shop-kit' ),
					'modal'      => __( 'Modal Gallery', 'kadence-shop-kit' ),
					'enlarge'    => __( 'Enlarge', 'kadence-shop-kit' ),
					'flip'       => __( 'Flip', 'kadence-shop-kit' ),
				),
			),
		),
	);

	$settings['sections'][] = array(
		'tab_id'              => 'general',
		'section_id'          => 'colours',
		'section_title'       => __( 'Colours', 'kadence-shop-kit' ),
		'section_description' => '',
		'section_order'       => 20,
		'fields'              => array(

			array(
				'id'       => 'icons',
				'title'    => __( 'Icon Colours', 'kadence-shop-kit' ),
				'subtitle' => __( 'The colour of any icons used.', 'kadence-shop-kit' ),
				'type'     => 'color',
				'default'  => '#333333',
			),

		),
	);

	$settings['sections'][] = array(
		'tab_id'              => 'effects',
		'section_id'          => 'fade',
		'section_title'       => __( 'Fade Settings', 'kadence-shop-kit' ),
		'section_description' => '',
		'section_order'       => 10,
		'fields'              => array(

			array(
				'id'      => 'transition_speed',
				'title'   => __( 'Transition Speed (ms)', 'kadence-shop-kit' ),
				'type'    => 'number',
				'default' => 300,
			),

		),
	);

	$settings['sections'][] = array(
		'tab_id'              => 'effects',
		'section_id'          => 'slide',
		'section_title'       => __( 'Slide Settings', 'kadence-shop-kit' ),
		'section_description' => '',
		'section_order'       => 20,
		'fields'              => array(
			array(
				'id'      => 'mode',
				'title'   => __( 'Mode', 'kadence-shop-kit' ),
				'type'    => 'select',
				'default' => 'horizontal',
				'choices' => array(
					'horizontal' => __( 'Horizontal', 'kadence-shop-kit' ),
					'vertical'   => __( 'Vertical', 'kadence-shop-kit' ),
				),
			),

			array(
				'id'       => 'image_count',
				'title'    => __( 'Image Count', 'kadence-shop-kit' ),
				'subtitle' => __( 'Enter how many images should be displayed. Use -1 to display all available.', 'kadence-shop-kit' ),
				'type'     => 'number',
				'default'  => - 1,
			),

			array(
				'id'       => 'navigation_icon_style',
				'title'    => __( 'Navigation Icon Style', 'kadence-shop-kit' ),
				'subtitle' => __( 'Choose the icon style for the slider arrows.', 'kadence-shop-kit' ),
				'type'     => 'select',
				'default'  => 'angle',
				'choices'  => array(
					'angle'          => __( 'Angle', 'kadence-shop-kit' ),
					'arrow-circle'   => __( 'Arrow Circle', 'kadence-shop-kit' ),
					'arrow-circle-o' => __( 'Arrow Circle Open', 'kadence-shop-kit' ),
					'arrow'          => __( 'Arrow', 'kadence-shop-kit' ),
					'long-arrow'     => __( 'Long Arrow', 'kadence-shop-kit' ),
					'caret'          => __( 'Caret', 'kadence-shop-kit' ),
					'chevron'        => __( 'Chevron', 'kadence-shop-kit' ),
				),
			),

			array(
				'id'       => 'touch',
				'title'    => __( 'Touch Enabled?', 'kadence-shop-kit' ),
				'subtitle' => __( 'When enabled, images can be swiped on touch devices.', 'kadence-shop-kit' ),
				'type'     => 'select',
				'default'  => 'y',
				'choices'  => array(
					'y' => __( 'Yes', 'kadence-shop-kit' ),
					'n' => __( 'No', 'kadence-shop-kit' ),
				),
			),

			array(
				'id'       => 'transition',
				'title'    => __( 'Transition Effect', 'kadence-shop-kit' ),
				'subtitle' => __( 'When sliding, apply this transition effect.', 'kadence-shop-kit' ),
				'type'     => 'select',
				'default'  => 'shrink_out',
				'choices'  => array(
					'none'       => __( 'None', 'kadence-shop-kit' ),
					'shrink_out' => __( 'Shrink Out', 'kadence-shop-kit' ),
				),
			),

			array(
				'id'      => 'transition_speed',
				'title'   => __( 'Transition Speed (ms)', 'kadence-shop-kit' ),
				'type'    => 'number',
				'default' => 300,
			),

		),
	);

	$settings['sections'][] = array(
		'tab_id'              => 'effects',
		'section_id'          => 'bullets',
		'section_title'       => __( 'Bullets Settings', 'kadence-shop-kit' ),
		'section_description' => '',
		'section_order'       => 30,
		'fields'              => array(

			array(
				'id'      => 'position',
				'title'   => __( 'Bullets Position', 'kadence-shop-kit' ),
				'type'    => 'select',
				'default' => 'horizontal-bottom-center',
				'choices' => array(
					'horizontal-bottom-center' => __( 'Horizontal Bottom Centre', 'kadence-shop-kit' ),
					'horizontal-bottom-left'   => __( 'Horizontal Bottom Left', 'kadence-shop-kit' ),
					'horizontal-bottom-right'  => __( 'Horizontal Bottom Right', 'kadence-shop-kit' ),
					'horizontal-top-center'    => __( 'Horizontal Top Centre', 'kadence-shop-kit' ),
					'horizontal-top-left'      => __( 'Horizontal Top Left', 'kadence-shop-kit' ),
					'horizontal-top-right'     => __( 'Horizontal Top Right', 'kadence-shop-kit' ),
					'vertical-left-center'     => __( 'Vertical Left Centre', 'kadence-shop-kit' ),
					'vertical-left-bottom'     => __( 'Vertical Left Bottom', 'kadence-shop-kit' ),
					'vertical-left-top'        => __( 'Vertical Left Top', 'kadence-shop-kit' ),
					'vertical-right-center'    => __( 'Vertical Right Centre', 'kadence-shop-kit' ),
					'vertical-right-bottom'    => __( 'Vertical Right Bottom', 'kadence-shop-kit' ),
					'vertical-right-top'       => __( 'Vertical Right Top', 'kadence-shop-kit' ),
				),
			),

			array(
				'id'      => 'mode',
				'title'   => __( 'Mode', 'kadence-shop-kit' ),
				'type'    => 'select',
				'default' => 'horizontal',
				'choices' => array(
					'horizontal' => __( 'Horizontal', 'kadence-shop-kit' ),
					'vertical'   => __( 'Vertical', 'kadence-shop-kit' ),
					'fade'       => __( 'Fade', 'kadence-shop-kit' ),
				),
			),

			array(
				'id'       => 'touch',
				'title'    => __( 'Touch Enabled?', 'kadence-shop-kit' ),
				'subtitle' => __( 'When enabled, images can be swiped on touch devices.', 'kadence-shop-kit' ),
				'type'     => 'select',
				'default'  => 'y',
				'choices'  => array(
					'y' => __( 'Yes', 'kadence-shop-kit' ),
					'n' => __( 'No', 'kadence-shop-kit' ),
				),
			),

			array(
				'id'      => 'transition_speed',
				'title'   => __( 'Transition Speed (ms)', 'kadence-shop-kit' ),
				'type'    => 'number',
				'default' => 300,
			),

			array(
				'id'       => 'image_count',
				'title'    => __( 'Image Count', 'kadence-shop-kit' ),
				'subtitle' => __( 'Enter how many images should be displayed. Use -1 to display all available.', 'kadence-shop-kit' ),
				'type'     => 'number',
				'default'  => - 1,
			),

		),
	);

	$settings['sections'][] = array(
		'tab_id'              => 'effects',
		'section_id'          => 'thumbnails',
		'section_title'       => __( 'Thumbnails Settings', 'kadence-shop-kit' ),
		'section_description' => '',
		'section_order'       => 40,
		'fields'              => array(

			array(
				'id'       => 'column_count',
				'title'    => __( 'Column Count', 'kadence-shop-kit' ),
				'subtitle' => __( 'How many images to show in a row.', 'kadence-shop-kit' ),
				'type'     => 'number',
				'default'  => 4,
			),

			array(
				'id'       => 'spacing',
				'title'    => __( 'Spacing (px)', 'kadence-shop-kit' ),
				'subtitle' => __( 'Space between the thumbnails in pixels.', 'kadence-shop-kit' ),
				'type'     => 'number',
				'default'  => 10,
			),

			array(
				'id'       => 'image_count',
				'title'    => __( 'Image Count', 'kadence-shop-kit' ),
				'subtitle' => __( 'Enter how many images should be displayed. Use -1 to display all available.', 'kadence-shop-kit' ),
				'type'     => 'number',
				'default'  => 3,
			),

		),
	);

	$settings['sections'][] = array(
		'tab_id'              => 'effects',
		'section_id'          => 'zoom',
		'section_title'       => __( 'Zoom Settings', 'kadence-shop-kit' ),
		'section_description' => '',
		'section_order'       => 50,
		'fields'              => array(

			array(
				'id'       => 'max',
				'title'    => __( 'Max Zoom', 'kadence-shop-kit' ),
				'subtitle' => __( 'How much should the image be zoomed on hover. For example, "2" will zoom no large than 2x.', 'kadence-shop-kit' ),
				'type'     => 'number',
				'default'  => 2,
			),

		),
	);

	$settings['sections'][] = array(
		'tab_id'              => 'effects',
		'section_id'          => 'pip',
		'section_title'       => __( 'Picture in Picture (PIP) Settings', 'kadence-shop-kit' ),
		'section_description' => '',
		'section_order'       => 60,
		'fields'              => array(

			array(
				'id'      => 'width',
				'title'   => __( 'PIP Width (%)', 'kadence-shop-kit' ),
				'type'    => 'number',
				'default' => 25,
			),

			array(
				'id'      => 'border_color',
				'title'   => __( 'PIP Border Colour', 'kadence-shop-kit' ),
				'type'    => 'color',
				'default' => '#CCCCCC',
			),

			array(
				'id'      => 'position',
				'title'   => __( 'Position', 'kadence-shop-kit' ),
				'type'    => 'select',
				'default' => 'bottom-right',
				'choices' => array(
					'top-left'     => __( 'Top Left', 'kadence-shop-kit' ),
					'top-right'    => __( 'Top Right', 'kadence-shop-kit' ),
					'bottom-left'  => __( 'Bottom Left', 'kadence-shop-kit' ),
					'bottom-right' => __( 'Bottom Right', 'kadence-shop-kit' ),
				),
			),

		),
	);

	$settings['sections'][] = array(
		'tab_id'              => 'effects',
		'section_id'          => 'modal',
		'section_title'       => __( 'Modal Settings', 'kadence-shop-kit' ),
		'section_description' => '',
		'section_order'       => 70,
		'fields'              => array(

			array(
				'id'      => 'icon',
				'title'   => __( 'Icon Style', 'kadence-shop-kit' ),
				'type'    => 'select',
				'default' => 'expand',
				'choices' => array(
					'expand'      => __( 'Expand', 'kadence-shop-kit' ),
					'arrows-alt'  => __( 'Arrows', 'kadence-shop-kit' ),
					'search'      => __( 'Magnifier', 'kadence-shop-kit' ),
					'search-plus' => __( 'Magnifier Plus', 'kadence-shop-kit' ),
					'picture-o'   => __( 'Picture', 'kadence-shop-kit' ),
				),
			),

		),
	);

	$settings['sections'][] = array(
		'tab_id'              => 'effects',
		'section_id'          => 'enlarge',
		'section_title'       => __( 'Enlarge Settings', 'kadence-shop-kit' ),
		'section_description' => '',
		'section_order'       => 80,
		'fields'              => array(

			array(
				'id'      => 'transition_speed',
				'title'   => __( 'Transition Speed (ms)', 'kadence-shop-kit' ),
				'type'    => 'number',
				'default' => 300,
			),

			array(
				'id'      => 'amount',
				'title'   => __( 'Enlarge Amount (%)', 'kadence-shop-kit' ),
				'type'    => 'number',
				'default' => 110,
			),

			array(
				'id'       => 'crop',
				'title'    => __( 'Crop?', 'kadence-shop-kit' ),
				'subtitle' => __( 'When enabled, images will be enlarged inside a cropped container.', 'kadence-shop-kit' ),
				'type'     => 'select',
				'default'  => 'n',
				'choices'  => array(
					'y' => __( 'Yes', 'kadence-shop-kit' ),
					'n' => __( 'No', 'kadence-shop-kit' ),
				),
			),

		),
	);

	$settings['sections'][] = array(
		'tab_id'              => 'effects',
		'section_id'          => 'flip',
		'section_title'       => __( 'Flip Settings', 'kadence-shop-kit' ),
		'section_description' => '',
		'section_order'       => 90,
		'fields'              => array(

			array(
				'id'      => 'transition_speed',
				'title'   => __( 'Transition Speed (ms)', 'kadence-shop-kit' ),
				'type'    => 'number',
				'default' => 300,
			),

		),
	);

	$settings['sections'][] = array(
		'tab_id'              => 'compatibility',
		'section_id'          => 'general',
		'section_title'       => __( 'Compatibility Settings', 'kadence-shop-kit' ),
		'section_description' => '',
		'section_order'       => 10,
		'fields'              => array(
			array(
				'id'       => 'ajax_events',
				'title'    => __( 'AJAX Event Triggers', 'kadence-shop-kit' ),
				'subtitle' => __( 'Add custom JavaScript event triggers e.g. my-ajax-event, one per line, that will force Image Swap to re-initialise after new products load via AJAX.', 'kadence-shop-kit' ),
				'type'     => 'textarea',
			),
		),
	);

	return $settings;
}
