<?php
/**
 * PHP Stan Stubs.
 *
 * @package iconic-image-swap
 */

/**
 * Stub for Iconic_WIS_Core_Freemius_SDK.
 */
class Iconic_WIS_Core_Freemius_SDK {
	/**
	 * Constructor.
	 *
	 * @param array $config The configuration array.
	 */
	public function __construct( $config ) {}
}
