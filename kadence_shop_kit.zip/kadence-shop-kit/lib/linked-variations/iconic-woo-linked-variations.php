<?php
/**
 * Linked Variations Module for Kadence Shop Kit.
 *
 * Based on WooCommerce Linked Variations by Iconic v1.12.0.0
 *
 * @package kadence-shop-kit
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// Prevent conflict with standalone linked variations plugin.
if (
	class_exists( 'Iconic_Woo_Linked_Variations' ) &&
	(
		property_exists( 'Iconic_Woo_Linked_Variations', 'version' ) &&
		version_compare( Iconic_Woo_Linked_Variations::$version, '1.13.0.0', '<' ) // @phpstan-ignore-line -- refers to standalone plugin's class, not the one defined below.
	)
) {
	if ( is_admin() ) {
		add_action(
			'admin_notices',
			function () {
				echo '<div class="notice notice-warning"><p>';
				echo esc_html__( 'The standalone WooCommerce Linked Variations plugin is active. Please deactivate it to use the linked variations module built into Kadence Shop Kit.', 'kadence-shop-kit' );
				echo '</p></div>';
			}
		);
	}
	return;
}

use KadenceWP\KadenceShopKit\StellarWP\ContainerContract\ContainerInterface;
use KadenceWP\KadenceShopKit\App;

/**
 * Iconic_Woo_Linked_Variations class
 */
class Iconic_Woo_Linked_Variations {
	/**
	 * Class prefix
	 *
	 * @since  1.0.0
	 * @var string $class_prefix
	 */
	protected $class_prefix = 'Iconic_WLV_';

	/**
	 * The singleton instance of the plugin.
	 *
	 * @var ?Iconic_Woo_Linked_Variations
	 */
	private static $instance;

	/**
	 * Construct the plugin
	 */
	public function __construct() {
		$this->define_constants();
		$this->load_classes();
		$this->install();

		add_action( 'before_woocommerce_init', array( $this, 'declare_custom_order_tables_compatiblity' ) );
	}

	/**
	 * Instantiate a single instance of our plugin.
	 *
	 * @return Iconic_Woo_Linked_Variations
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Get the DI container.
	 *
	 * @return ContainerInterface
	 */
	public function container() {
		return App::container();
	}

	/**
	 * Load textdomain
	 *
	 * @deprecated 3.0.0
	 *
	 * @return void
	 */
	public function textdomain() {
		_deprecated_function( __METHOD__, '3.0.0' );
	}

	/**
	 * Define Constants.
	 *
	 * @return void
	 */
	private function define_constants() {
		$this->define( 'ICONIC_WLV_FILE', __FILE__ );
		$this->define( 'ICONIC_WLV_PATH', plugin_dir_path( ICONIC_WLV_FILE ) );
		$this->define( 'ICONIC_WLV_URL', plugin_dir_url( ICONIC_WLV_FILE ) );
		$this->define( 'ICONIC_WLV_INC_PATH', ICONIC_WLV_PATH . 'inc/' );
		$this->define( 'ICONIC_WLV_VENDOR_PATH', ICONIC_WLV_INC_PATH . 'vendor/' );
		$this->define( 'ICONIC_WLV_BASENAME', plugin_basename( ICONIC_WLV_FILE ) );
		$this->define( 'ICONIC_WLV_VERSION', KADENCE_WOO_EXTRAS_VERSION );
		$this->define( 'ICONIC_WLV_PLUGIN_PATH_FILE', str_replace( trailingslashit( wp_normalize_path( WP_PLUGIN_DIR ) ), '', wp_normalize_path( ICONIC_WLV_FILE ) ) );
	}

	/**
	 * Define constant if not already set.
	 *
	 * @param string      $name
	 * @param string|bool $value
	 */
	private function define( $name, $value ) {
		if ( ! defined( $name ) ) {
			define( $name, $value );
		}
	}

	/**
	 * Load classes
	 *
	 * @return void
	 */
	private function load_classes() {
		require_once ICONIC_WLV_INC_PATH . 'class-core-autoloader.php';

		Iconic_WLV_Core_Autoloader::run(
			array(
				'prefix'   => 'Iconic_WLV_',
				'inc_path' => ICONIC_WLV_INC_PATH,
			)
		);

		if ( ! Iconic_WLV_Core_Helpers::is_plugin_active( 'woocommerce/woocommerce.php' ) ) {
			return;
		}

		Iconic_WLV_Assets::run();
		Iconic_WLV_Post_Types::run();
		Iconic_WLV_Product::run();
		Iconic_WLV_Api::run();
		Iconic_WLV_Compat_Import::run();
		Iconic_WLV_Compat_WPML::run();
		Iconic_WLV_Shortcodes::run();
		Iconic_WLV_Compat_Weglot::run();

		add_action( 'admin_init', array( 'Iconic_WLV_Export', 'export' ) );
	}

	/**
	 * Init licence class.
	 *
	 * @deprecated 3.0.0
	 *
	 * @return void
	 */
	public function init_license() {
		_deprecated_function( __METHOD__, '3.0.0' );
	}

	/**
	 * Init telemetry class.
	 *
	 * @deprecated 3.0.0
	 *
	 * @return void
	 */
	public function init_telemetry() {
		_deprecated_function( __METHOD__, '3.0.0' );
	}

	/**
	 * Install plugin.
	 */
	private function install() {
		add_action( 'plugins_loaded', array( 'Iconic_WLV_Database', 'install' ) );
	}

	/**
	 * Returns an array of supported taxonomies.
	 */
	public static function get_supported_taxonomies() {
		$hidden_taxonomies = array(
			'product_visibility',
			'product_type',
			'product_shipping_class',
		);

		$taxonomies           = get_object_taxonomies( 'product' );
		$supported_taxonomies = array();

		foreach ( $taxonomies as $taxonomy ) {
			if ( in_array( $taxonomy, $hidden_taxonomies, true ) || 'pa_' === substr( $taxonomy, 0, 3 ) ) {
				continue;
			}

			$supported_taxonomies [] = $taxonomy;
		}

		/**
		 * Returning an array of supported taxonomies for the WooCommerce Linked Variations.
		 *
		 * @since 1.7.0
		 */
		$supported_taxonomies = apply_filters( 'iconic_wlv_supported_taxonomies', $supported_taxonomies );

		$tax_objects = array();
		foreach ( $supported_taxonomies as $taxonomy ) {
			$tax_objects [] = get_taxonomy( $taxonomy );
		}

		return $tax_objects;
	}

	/**
	 * Declare compatiblity with HPOS/Custom order tables feature of WooCommerce.
	 *
	 * @return void
	 */
	public static function declare_custom_order_tables_compatiblity() {
		if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
		}
	}

	/**
	 * Get allowed post status for linked variations.
	 *
	 * @return array
	 */
	public static function get_allowed_post_status() {
		/**
		 * Allowed post statuses for the linked variation products.
		 *
		 * @since 1.7.0
		 */
		return apply_filters( 'iconic_wlv_allowed_post_status', array( 'publish' ) );
	}
}

$iconic_wlv = Iconic_Woo_Linked_Variations::instance();
