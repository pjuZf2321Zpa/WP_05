<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Setup post types.
 */
class Iconic_WLV_Post_Types {
	/**
	 * Run class.
	 */
	public static function run() {
		add_action( 'init', array( __CLASS__, 'add_post_types' ) );
		add_action( 'add_meta_boxes', array( __CLASS__, 'add_meta_boxes' ) );
		add_action( 'save_post_cpt_iconic_wlv', array( __CLASS__, 'save_meta' ) );
		add_action( 'delete_post', array( __CLASS__, 'delete_meta' ) );
		add_filter( 'manage_cpt_iconic_wlv_posts_columns', array( __CLASS__, 'admin_columns' ), 1000 );
		add_action( 'manage_cpt_iconic_wlv_posts_custom_column', array( __CLASS__, 'admin_columns_content' ), 10, 2 );
	}

	/**
	 * Add post types.
	 */
	public static function add_post_types() {
		self::add(
			array(
				'plural'              => __( 'Linked Variations', 'kadence-shop-kit' ),
				'singular'            => __( 'Linked Variations', 'kadence-shop-kit' ),
				'menu_name'           => __( 'Linked Variations', 'kadence-shop-kit' ),
				'key'                 => 'cpt_iconic_wlv',
				'has_archive'         => false,
				'public'              => false,
				'exclude_from_search' => true,
				'supports'            => array( 'title' ),
				'show_in_menu'        => 'edit.php?post_type=product',
				'publicly_queryable'  => false,
			)
		);
	}

	/**
	 * Method: Add
	 *
	 * @since 1.0.0
	 *
	 * @param array $options
	 */
	public static function add( $options ) {
		$defaults = array(
			'plural'              => '',                   // !required
			'singular'            => '',                   // !required
			'key'                 => false,                // !required
			'rewrite_slug'        => false,                // !recommended if has frontend visibility
			'rewrite_with_front'  => false,
			'rewrite_feeds'       => true,
			'rewrite_pages'       => true,
			'menu_icon'           => 'dashicons-admin-post',
			'hierarchical'        => false,
			'supports'            => array( 'title' ),
			'public'              => true,
			'show_ui'             => true,
			'show_in_menu'        => true,
			'show_in_nav_menus'   => true,
			'publicly_queryable'  => true,
			'exclude_from_search' => false,
			'has_archive'         => true,
			'query_var'           => true,
			'can_export'          => true,
			'capability_type'     => 'post',
			'menu_name'           => false,
		);

		$options = wp_parse_args( $options, $defaults );

		if ( $options['key'] ) {
			$labels = array(
				'name'               => $options['plural'],
				'singular_name'      => $options['singular'],
				'add_new'            => _x( 'Add New', 'iconic-advanced-layered-nav', 'kadence-shop-kit' ),
				// translators: %s: singular post type name.
				'add_new_item'       => sprintf( _x( 'Add New %s', 'iconic-advanced-layered-nav', 'kadence-shop-kit' ), $options['singular'] ),
				// translators: %s: singular post type name.
				'edit_item'          => sprintf( _x( 'Edit %s', 'iconic-advanced-layered-nav', 'kadence-shop-kit' ), $options['singular'] ),
				// translators: %s: singular post type name.
				'new_item'           => sprintf( _x( 'New %s', 'iconic-advanced-layered-nav', 'kadence-shop-kit' ), $options['singular'] ),
				// translators: %s: singular post type name.
				'view_item'          => sprintf( _x( 'View %s', 'iconic-advanced-layered-nav', 'kadence-shop-kit' ), $options['singular'] ),
				// translators: %s: plural post type name.
				'search_items'       => sprintf( _x( 'Search %s', 'iconic-advanced-layered-nav', 'kadence-shop-kit' ), $options['plural'] ),
				// translators: %s: plural post type name.
				'not_found'          => sprintf( _x( 'No %s found', 'iconic-advanced-layered-nav', 'kadence-shop-kit' ), strtolower( $options['plural'] ) ),
				// translators: %s: plural post type name.
				'not_found_in_trash' => sprintf( _x( 'No %s found in Trash', 'iconic-advanced-layered-nav', 'kadence-shop-kit' ), strtolower( $options['plural'] ) ),
				// translators: %s: singular post type name.
				'parent_item_colon'  => sprintf( _x( 'Parent %s:', 'iconic-advanced-layered-nav', 'kadence-shop-kit' ), $options['singular'] ),
				'menu_name'          => $options['menu_name'] ? $options['menu_name'] : $options['plural'],
			);

			$args = array(
				'labels'              => $labels,
				'hierarchical'        => $options['hierarchical'],
				'supports'            => $options['supports'],
				'public'              => $options['public'],
				'show_ui'             => $options['show_ui'],
				'show_in_menu'        => $options['show_in_menu'],
				'menu_icon'           => $options['menu_icon'],
				'show_in_nav_menus'   => $options['show_in_nav_menus'],
				'publicly_queryable'  => $options['publicly_queryable'],
				'exclude_from_search' => $options['exclude_from_search'],
				'has_archive'         => $options['has_archive'],
				'query_var'           => $options['query_var'],
				'can_export'          => $options['can_export'],
				'capability_type'     => $options['capability_type'],
				'rewrite'             => false,
				'show_in_rest'        => true,
			);

			if ( $options['rewrite_slug'] ) {
				$args['rewrite'] = array(
					'slug'       => $options['rewrite_slug'],
					'with_front' => $options['rewrite_with_front'],
					'feeds'      => $options['rewrite_feeds'],
					'pages'      => $options['rewrite_pages'],
				);
			}

			register_post_type( $options['key'], $args );
		}
	}

	/**
	 * Modify admin columns.
	 *
	 * @param array $columns
	 *
	 * @return array
	 */
	public static function admin_columns( $columns ) {
		$columns = array(
			'cb'        => $columns['cb'],
			'title'     => $columns['title'],
			'products'  => __( 'Products', 'kadence-shop-kit' ),
			'linked_by' => __( 'Linked by (attributes)', 'kadence-shop-kit' ),
			'date'      => $columns['date'],
		);

		return $columns;
	}

	/**
	 * Add custom column content.
	 *
	 * @param string $column
	 * @param int    $post_id
	 */
	public static function admin_columns_content( $column, $post_id ) {
		if ( in_array( $column, array( 'cb', 'title', 'author', 'date' ) ) ) {
			return;
		}

		$linked_variations_group = new Iconic_WLV_Linked_Variations_Group( $post_id );

		if ( 'products' === $column ) {
			self::print_products_column_content( $linked_variations_group );
			return;
		} elseif ( 'linked_by' === $column ) {
			$attribute_slugs = $linked_variations_group->get_attributes();

			if ( empty( $attribute_slugs ) ) {
				echo '&mdash;';

				return;
			}

			$attributes = array();

			foreach ( $attribute_slugs as $attribute_slug ) {
				$taxonomy = get_taxonomy( $attribute_slug );

				if ( ! $taxonomy ) {
					continue;
				}

				$link = admin_url( 'edit-tags.php?taxonomy=' . $attribute_slug . '&post_type=product' );

				$attributes[] = sprintf( '<a href="%s" target="_blank">%s</a>', esc_attr( $link ), $taxonomy->labels->singular_name );
			}

			echo wp_kses( implode( ', ', $attributes ), Iconic_WLV_Helpers::get_kses_allowed_tags() );

			unset( $attributes );

			return;
		}
	}

	/**
	 * Print product column content.
	 *
	 * @param Iconic_WLV_Linked_Variations_Group $linked_variations_group LV group object.
	 *
	 * @return void
	 */
	public static function print_products_column_content( $linked_variations_group ) {
		if ( empty( $linked_variations_group->meta->link_by ) || 'specific_products' === $linked_variations_group->meta->link_by ) {
			$product_ids = $linked_variations_group->get_product_ids();

			if ( empty( $product_ids ) ) {
				echo '&mdash;';

				return;
			}

			$products = array();

			foreach ( $product_ids as $product_id ) {
				$title = get_the_title( $product_id );
				$link  = admin_url( 'post.php?post=' . $product_id . '&action=edit' );

				$products[] = sprintf( '<a href="%s" target="_blank">%s</a>', esc_attr( $link ), $title );
			}

			echo wp_kses_post( implode( ', ', $products ) );

			unset( $products );
		} else {
			$terms    = $linked_variations_group->select_by_terms;
			$taxonomy = get_taxonomy( $linked_variations_group->meta->link_by );

			if ( empty( $terms ) || empty( $taxonomy ) ) {
				echo '&mdash;';

				return;
			}

			$terms_arr = array();

			foreach ( $terms as $term_id ) {
				$term = get_term( intval( $term_id ) );

				if ( is_wp_error( $term ) ) {
					continue;
				}

				$link        = admin_url( "edit.php?post_type=product&{$term->taxonomy}=$term->slug" );
				$title       = $term->name;
				$terms_arr[] = sprintf( '<a href="%s" target="_blank">%s</a>', esc_attr( $link ), $title );
			}

			echo wp_kses( sprintf( '<strong>%s</strong>: %s', $taxonomy->label, implode( ', ', $terms_arr ) ), Iconic_WLV_Helpers::get_kses_allowed_tags() );
		}
	}

	/**
	 * Add meta boxes.
	 */
	public static function add_meta_boxes() {
		add_meta_box(
			'iconic-wlv-linked-variations-meta',
			esc_html__( 'Linked Variations', 'kadence-shop-kit' ),
			array( __CLASS__, 'linked_variations_meta_box' ),
			'cpt_iconic_wlv',
			'normal',
			'default'
		);
	}

	/**
	 * Linked variations meta box.
	 */
	public static function linked_variations_meta_box() {
		global $post;

		if ( ! $post ) {
			return;
		}

		$linked_variations_group = new Iconic_WLV_Linked_Variations_Group( $post );
		$product_ids             = $linked_variations_group->get_product_ids( true, 'admin' );
		$attributes              = $linked_variations_group->get_attributes();
		$is_show_image           = $linked_variations_group->is_show_image();
		$style                   = $linked_variations_group->get_style();
		$link_by                 = $linked_variations_group->get_link_by();
		$seleced_terms           = $linked_variations_group->get_select_by_terms();
		$attribute_taxonomies    = Iconic_WLV_Helpers::get_attribute_taxonomies( $attributes );
		$link_taxonomies         = Iconic_Woo_Linked_Variations::get_supported_taxonomies();
		?>

		<div class="wlv-admin-form">
			<div class="wlv-admin-form__inners">

				<div class="wlv-form-field">
					<div class="wlv-form-field__left">
						<label for="iconic-wlv-link-by"><?php esc_html_e( 'Select Products by', 'kadence-shop-kit' ); ?></label>
						<span class='wlv-form-field__desc'><?php esc_html_e( 'Select how you want to group your products.', 'kadence-shop-kit' ); ?></span>
					</div>
					<div class="wlv-form-field__right">
						<select id="iconic-wlv-link-by" name="iconic_wlv_product_link_by">
							<option value="specific_products"><?php esc_html_e( 'Specific products', 'kadence-shop-kit' ); ?></option>
							<?php
							foreach ( $link_taxonomies as $taxonomy ) {
								printf( '<option value="%s" %s>%s</option>', esc_attr( $taxonomy->name ), selected( $taxonomy->name, $link_by, false ), esc_html( $taxonomy->label ) );
							}
							?>
						</select>
					</div>
				</div>

				<!-- choose specific products -->
				<div class="wlv-form-field iconic-wlv-selector iconic-wlv-selector--specific_products">
					<div class="wlv-form-field__left">
						<label for="iconic-wlv-link-by"><?php esc_html_e( 'Choose Specific Products', 'kadence-shop-kit' ); ?></label>
						<span class='wlv-form-field__desc'><?php esc_html_e( 'Choose the specific products you want to link.', 'kadence-shop-kit' ); ?></span>
					</div>
					<div class="wlv-form-field__right">
						<select class="wc-product-search" multiple="multiple" style="width: 95%;" id="iconic-wlv-product-ids" name="iconic_wlv_product_ids[]" data-placeholder="<?php esc_attr_e( 'Search for a product&hellip;', 'kadence-shop-kit' ); ?>" data-action="woocommerce_json_search_products">
							<?php
							foreach ( $product_ids as $product_id ) {
								$product = wc_get_product( $product_id );
								if ( is_object( $product ) ) {
									echo '<option value="' . esc_attr( $product_id ) . '"' . selected( true, true, false ) . '>' . wp_kses_post( $product->get_formatted_name() ) . '</option>';
								}
							}
							?>
						</select>
					</div>
				</div>

				<!-- Taxonomies -->
				<?php
				foreach ( $link_taxonomies as $taxonomy ) {
					?>
					<div class="wlv-form-field iconic-wlv-selector iconic-wlv-taxonomy iconic-wlv-selector--<?php echo esc_attr( $taxonomy->name ); ?>">
						<div class="wlv-form-field__left">
							<label for="iconic-wlv-link-by"><?php echo esc_html( $taxonomy->label ); ?></label>
							<span class='wlv-form-field__desc'><?php esc_html_e( 'Create linked variation group by linking products for this taxonomy.', 'kadence-shop-kit' ); ?></span>
							</div>
						<div class="wlv-form-field__right">
							<?php
							Iconic_WLV_Settings::print_taxonomy_dropdown( $taxonomy, $seleced_terms );
							?>
						</div>
					</div>
					<?php
				}
				?>

				<!-- Attributes -->
				<div class="wlv-form-field">
					<div class="wlv-form-field__left">
						<label><?php esc_html_e( 'Linked by (attributes)', 'kadence-shop-kit' ); ?></label>
						<span class='wlv-form-field__desc'><?php esc_html_e( 'Select the attributes that will link your products together.', 'kadence-shop-kit' ); ?></span>
					</div>
					<div class="wlv-form-field__right">
						<?php if ( ! empty( $attribute_taxonomies ) ) { ?>
							<ul id="iconic-wlv-attributes" class="iconic-wlv-attributes">
								<?php foreach ( $attribute_taxonomies as $attribute_name => $attribute_label ) { ?>
									<?php
									$id      = sprintf( 'iconic-wlv-attributes__%s', $attribute_name );
									$checked = in_array( $attribute_name, $attributes );
									?>
									<li class="iconic-wlv-attributes__attribute">
										<input id="<?php echo esc_attr( $id ); ?>" type="checkbox" name="iconic_wlv_attributes[]" value="<?php echo esc_attr( $attribute_name ); ?>" <?php checked( $checked ); ?>>
										<label for="<?php echo esc_attr( $id ); ?>"><?php echo $attribute_label; ?></label>
										<i class="iconic-wlv-attributes__attribute-handle dashicons dashicons-menu" aria-hidden="true"></i>
									</li>
								<?php } ?>
							</ul>
						<?php } else { ?>
							<?php
							// translators: %s: URL to the product attributes admin page.
							printf( wp_kses( __( 'You need to add some <a href="%s">product attributes</a> first.', 'kadence-shop-kit' ), array( 'a' => array( 'href' => array() ) ) ), esc_url( admin_url( 'edit.php?post_type=product&page=product_attributes' ) ) );
							?>
						<?php } ?>
					</div>
				</div>

				<div class="wlv-form-field">
					<div class="wlv-form-field__left">
						<label><?php esc_html_e( 'Show images?', 'kadence-shop-kit' ); ?></label>
						<span class='wlv-form-field__desc'><?php esc_html_e( 'When checked, the options for the first selected attribute will be displayed as product images.', 'kadence-shop-kit' ); ?></span>
					</div>
					<div class="wlv-form-field__right">
						<input type="checkbox" id="iconic-wlv-show-images" name="iconic_wlv_show_images" <?php checked( $is_show_image ); ?>>
					</div>
				</div>

				<div class="wlv-form-field">
					<div class="wlv-form-field__left">
						<label for="iconic-wlv-style"><?php esc_html_e( 'Style', 'kadence-shop-kit' ); ?></label>
						<span class='wlv-form-field__desc'><?php esc_html_e( 'How should the attribute options be displayed?', 'kadence-shop-kit' ); ?></span>
					</div>
					<div class="wlv-form-field__right">
						<select name="iconic_wlv_style" id="iconic-wlv-style">
							<option value="buttons" <?php selected( $style, 'buttons' ); ?>><?php esc_html_e( 'Buttons', 'kadence-shop-kit' ); ?></option>
							<option value="dropdown" <?php selected( $style, 'dropdown' ); ?>><?php esc_html_e( 'Dropdown', 'kadence-shop-kit' ); ?></option>
							<?php
							/**
							 * Admin: Style setting options.
							 *
							 * @since 1.0.0
							 */
							do_action( 'iconic_wlv_meta_box_style_options', $style );
							?>
						</select>
					</div>
				</div>

			</div>
		</div>


		<?php
		wp_nonce_field( 'iconic_wlv_meta_box', 'iconic_wlv_meta_box_nonce' );
	}

	/**
	 * Save meta.
	 *
	 * @param int $post_id Post ID.
	 */
	public static function save_meta( $post_id ) {
		if ( ! isset( $_POST['post_type'] ) || 'cpt_iconic_wlv' !== $_POST['post_type'] || ( ! empty( $_POST['action'] ) && 'inline-save' === $_POST['action'] ) ) {
			return;
		}

		check_admin_referer( 'iconic_wlv_meta_box', 'iconic_wlv_meta_box_nonce' );

		$link_by     = filter_input( INPUT_POST, 'iconic_wlv_product_link_by' );
		$terms       = false;
		$product_ids = filter_input( INPUT_POST, 'iconic_wlv_product_ids', FILTER_DEFAULT, FILTER_REQUIRE_ARRAY );
		$attributes  = filter_input( INPUT_POST, 'iconic_wlv_attributes', FILTER_DEFAULT, FILTER_REQUIRE_ARRAY );
		$show_image  = filter_input( INPUT_POST, 'iconic_wlv_show_images' ) === 'on';
		$style       = filter_input(
			INPUT_POST,
			'iconic_wlv_style',
			FILTER_SANITIZE_FULL_SPECIAL_CHARS,
			array(
				'options' => array(
					'default' => 'buttons',
				),
			)
		);

		if ( empty( $product_ids ) ) {
			$product_ids = array();
		}

		if ( ! empty( $link_by ) && 'specific_products' !== $link_by ) {
			$terms = filter_input( INPUT_POST, 'iconic_wlv_taxonomy_' . $link_by, FILTER_DEFAULT, FILTER_REQUIRE_ARRAY );
		}

		$args = array(
			'link_by'     => $link_by,
			'product_ids' => array_map( 'strval', $product_ids ),
			'attributes'  => $attributes,
			'show_image'  => $show_image,
			'style'       => $style,
		);

		Iconic_WLV_Database::update_linked_variations_meta( $post_id, $args, $terms );
	}

	/**
	 * Delete meta.
	 *
	 * @param int $post_id Post ID.
	 */
	public static function delete_meta( $post_id ) {
		Iconic_WLV_Database::delete_linked_variation_terms( $post_id );
		Iconic_WLV_Database::delete_linked_variations_meta( $post_id );
	}
}
