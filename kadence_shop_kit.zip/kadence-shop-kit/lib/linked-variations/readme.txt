=== WooCommerce Linked Variations ===
Contributors: iconicwp
Requires at least: 4.8
Tested up to: 6.8
Stable tag: trunk