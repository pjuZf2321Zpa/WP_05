<?php
/**
 * Bundled Products Module for Kadence Shop Kit.
 *
 * Based on WooCommerce Bundled Products by Iconic v2.10.1.0
 *
 * @package kadence-shop-kit
 */

use KadenceWP\KadenceShopKit\StellarWP\ContainerContract\ContainerInterface;
use KadenceWP\KadenceShopKit\App;

/**
 * Iconic_Woo_Bundled_Products class
 */
class Iconic_Woo_Bundled_Products {
	/**
	 * Name
	 *
	 * @var string
	 */
	public static $name = 'WooCommerce Bundled Products';

	/**
	 * Slug
	 *
	 * @var string
	 */
	public $slug = 'iconic-woo-bundled-products';

	/**
	 * Product options name
	 *
	 * @var string
	 */
	public $product_options_name;

	/**
	 * Options
	 *
	 * @var array
	 */
	public $options;

	/**
	 * Current product
	 *
	 * @var boolean
	 */
	public $current_product = false;

	/**
	 * Templates
	 *
	 * @var null|Iconic_WBP_Core_Template_Loader
	 */
	public $templates;

	/**
	 * Class prefix
	 *
	 * @since  4.5.0
	 * @var string $class_prefix
	 */
	protected $class_prefix = 'Iconic_WBP_';

	/**
	 * The singleton instance of the plugin.
	 *
	 * @var Iconic_Woo_Bundled_Products
	 */
	private static $instance;

	/**
	 * Construct.
	 */
	public function __construct() {
		self::$instance = $this;
		$this->define_constants();
		$this->set_constants();
		$this->load_classes();

		if ( ! Iconic_WBP_Core_Helpers::is_plugin_active( 'woocommerce/woocommerce.php' ) && ! Iconic_WBP_Core_Helpers::is_plugin_active( 'woocommerce-old/woocommerce.php' ) ) {
			return;
		}

		// Hook up to the init and plugins_loaded actions.
		add_action( 'before_woocommerce_init', array( $this, 'declare_hpos_compatibility' ) );
		add_action( 'plugins_loaded', array( $this, 'plugins_loaded_hook' ) );
		add_action( 'init', array( $this, 'initiate_hook' ) );
		add_action( 'wp', array( $this, 'wp_hook' ) );

		add_filter( 'body_class', array( $this, 'add_woocommerce_classes_when_product_gallery_is_enabled' ), 5 );
	}

	/**
	 * Define Constants.
	 */
	private function define_constants() {
		$this->define( 'ICONIC_WBP_FILE', __FILE__ );
		$this->define( 'ICONIC_WBP_PATH', plugin_dir_path( __FILE__ ) );
		$this->define( 'ICONIC_WBP_URL', plugin_dir_url( __FILE__ ) );
		$this->define( 'ICONIC_WBP_INC_PATH', ICONIC_WBP_PATH . 'inc/' );
		$this->define( 'ICONIC_WBP_VENDOR_PATH', ICONIC_WBP_INC_PATH . 'vendor/' );
		$this->define( 'ICONIC_WBP_BASENAME', plugin_basename( __FILE__ ) );
		$this->define( 'ICONIC_WBP_PLUGIN_PATH_FILE', str_replace( trailingslashit( wp_normalize_path( WP_PLUGIN_DIR ) ), '', wp_normalize_path( ICONIC_WBP_FILE ) ) );
	}

	/**
	 * Define constant if not already set.
	 *
	 * @param string      $name The name.
	 * @param string|bool $value The value.
	 */
	private function define( $name, $value ) {
		if ( ! defined( $name ) ) {
			define( $name, $value );
		}
	}

	/**
	 * Load textdomain.
	 *
	 * @deprecated 3.0.0
	 *
	 * @return void
	 */
	public function textdomain() {
		_deprecated_function( __METHOD__, '3.0.0' );
	}

	/**
	 * Setup Constants for this class.
	 */
	public function set_constants() {
		$this->product_options_name = $this->slug . '_options';
	}

	/**
	 * Load Classes
	 */
	private function load_classes() {
		require_once ICONIC_WBP_INC_PATH . 'class-core-autoloader.php';

		Iconic_WBP_Core_Autoloader::run(
			array(
				'prefix'   => 'Iconic_WBP_',
				'inc_path' => ICONIC_WBP_INC_PATH,
			)
		);

		$this->templates = new Iconic_WBP_Core_Template_Loader( $this->slug, 'iconic-woo-bundled-products', ICONIC_WBP_PATH );

		Iconic_WBP_Shortcodes::run();
		Iconic_WBP_Templates::run();
		Iconic_WBP_Blocks::run();

		add_action( 'init', array( 'Iconic_WBP_Compat_Curcy_WooCommerce_Multi_Currency', 'init' ), 10 );
	}

	/**
	 * Init license class.
	 *
	 * @deprecated 3.0.0
	 *
	 * @return void
	 */
	public function init_license() {
		_deprecated_function( __METHOD__, '3.0.0' );
	}

	/**
	 * Init telemetry class.
	 *
	 * @deprecated 3.0.0
	 *
	 * @return void
	 */
	public function init_telemetry() {
		_deprecated_function( __METHOD__, '3.0.0' );
	}

	/**
	 * Run quite near the start (http://codex.wordpress.org/Plugin_API/Action_Reference).
	 */
	public function plugins_loaded_hook() {
		require_once ICONIC_WBP_PATH . '/inc/class-product-bundled.php';
	}

	/**
	 * Run after the current user is set (http://codex.wordpress.org/Plugin_API/Action_Reference).
	 */
	public function initiate_hook() {
		add_filter( 'product_type_selector', array( $this, 'add_product_type' ) );

		// Run on admin.
		if ( is_admin() ) {
			add_filter( 'woocommerce_product_data_tabs', array( $this, 'edit_product_tabs' ) );
			add_action( 'woocommerce_product_data_panels', array( $this, 'product_tab_content' ) );
			add_action( 'woocommerce_process_product_meta', array( $this, 'process_product_tabs' ), 10, 2 );
		} else {
			// Run on frontend.
			add_action( 'wp_enqueue_scripts', array( $this, 'styles' ) );
			add_action( 'wp_enqueue_scripts', array( $this, 'scripts' ) );
			add_action( 'woocommerce_cart_calculate_fees', array( $this, 'add_discount' ) );
			add_action( 'woocommerce_remove_cart_item', array( $this, 'maybe_remove_discount' ), 10, 2 );
		}
	}

	/**
	 * Run after wp is fully set up and $post is accessible (http://codex.wordpress.org/Plugin_API/Action_Reference)
	 */
	public function wp_hook() {
		if ( ! is_admin() ) {
			$this->add_frontend_hooks();
			$this->process_add_to_cart();
		}
	}

	/**
	 * Add WooCommerce hooks for product page
	 */
	public function add_frontend_hooks() {
		if ( ! is_product() ) {
			return;
		}

		$product = $this->get_current_product();

		if ( ! $product || ! $product->is_type( 'bundled' ) ) {
			return;
		}

		add_action( 'woocommerce_after_single_product_summary', array( $this, 'output_bundled_products' ), 5 );
	}

	/**
	 * Plugin Styles
	 */
	public function styles() {
		if ( ! $this->has_bundled_product() ) {
			return;
		}

		wp_register_style( $this->slug . '_styles', ICONIC_WBP_URL . 'assets/frontend/css/main.min.css', array(), KADENCE_WOO_EXTRAS_VERSION );

		wp_enqueue_style( $this->slug . '_styles' );

		if ( is_product() ) {
			return;
		}

		if ( ! $this->has_shortcode() ) {
			return;
		}

		if ( ! $this->is_product_gallery_enabled() ) {
			return;
		}

		wp_enqueue_style( 'photoswipe' );
		wp_enqueue_style( 'photoswipe-default-skin' );
	}

	/**
	 * Has Bundled Product.
	 *
	 * @param object $post_object Post Object.
	 *
	 * @return boolean Post has bundled product.
	 */
	public function has_bundled_product( $post_object = null ) {
		global $post;

		// If the post object has not been passed, set it vai the global.
		if ( ! is_object( $post_object ) ) {
			$post_object = $post;
		}

		$is_product    = is_product();
		$has_shortcode = $this->has_shortcode( $post_object );

		// Needs to be a product, or have the shortcode.
		if ( ! $is_product &&
			! $has_shortcode &&
			! Iconic_WBP_Blocks::get_single_product_block_product_id( $post )
		) {
			return false;
		}

		// If it is a product, without the shortcode, it needs to be bundled.
		if ( is_product() &&
			! $has_shortcode
		) {
			$product = $this->get_current_product();
			if ( ! $product || ! $product->is_type( 'bundled' ) ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Plugin Scripts
	 */
	public function scripts() {
		if ( ! $this->has_bundled_product() ) {
			return;
		}

		$min = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

		wp_register_script( 'iconic_woo_bundled_products_scripts', ICONIC_WBP_URL . 'assets/frontend/js/main' . $min . '.js', array( 'jquery' ), KADENCE_WOO_EXTRAS_VERSION, true );

		wp_enqueue_script( 'iconic_woo_bundled_products_scripts' );

		if ( is_product() ) {
			return;
		}

		if ( ! $this->has_shortcode() ) {
			return;
		}

		if ( ! $this->is_product_gallery_enabled() ) {
			return;
		}

		if ( current_theme_supports( 'wc-product-gallery-zoom' ) ) {
			wp_enqueue_script( 'zoom' );
		}
		if ( current_theme_supports( 'wc-product-gallery-slider' ) ) {
			wp_enqueue_script( 'flexslider' );
		}
		if ( current_theme_supports( 'wc-product-gallery-lightbox' ) ) {
			wp_enqueue_script( 'photoswipe-ui-default' );
			add_action( 'wp_footer', 'woocommerce_photoswipe' );
		}

		wp_enqueue_script( 'wc-single-product' );
	}

	/**
	 * Add the "Shop the Look" product type to the edit/add product dropdown
	 *
	 * @param array $types Current types of products.
	 */
	public function add_product_type( $types ) {
		$types['bundled'] = __( 'Bundled Product', 'kadence-shop-kit' );

		return $types;
	}

	/**
	 * Edit product tabs
	 *
	 * We're adding and editing the tabs which show when "Shop the Look" is
	 * the product type.
	 *
	 * @param array $tabs All tabs.
	 */
	public function edit_product_tabs( $tabs ) {
		$tabs['shipping']['class'][] = 'hide_if_bundled';

		$tabs['bundled'] = array(
			'label'  => __( 'Bundled Products', 'kadence-shop-kit' ),
			'target' => 'iconic_bundled_product_data',
			'class'  => array( 'show_if_bundled' ),
		);

		return $tabs;
	}

	/**
	 * Product tab content
	 *
	 * Display the tab content for the new tabs we added in edit_product_tabs()
	 */
	public function product_tab_content() {
		global $post, $jckstlData; // phpcs:ignore WordPress.NamingConventions.ValidVariableName.VariableNotSnakeCase

		include_once ICONIC_WBP_PATH . '/inc/product-tab-bundled-data.php';
	}

	/**
	 * Save the new product tab content from product_tab_content()
	 *
	 * @param int $post_id The post ID.
	 */
	public function process_product_tabs( $post_id ) {
		$jckstl_data = array();

		if ( isset( Iconic_WBP_Helpers::get_filtered_input( $this->product_options_name, 'POST', 'array' )['product_ids'] ) ) {
			$jckstl_data['product_ids'] = is_array( Iconic_WBP_Helpers::get_filtered_input( $this->product_options_name, 'POST', 'array' )['product_ids'] ) ? Iconic_WBP_Helpers::get_filtered_input( $this->product_options_name, 'POST', 'array' )['product_ids'] : str_replace( ' ', '', Iconic_WBP_Helpers::get_filtered_input( $this->product_options_name, 'POST', 'array' )['product_ids'] );
		}

		if ( isset( Iconic_WBP_Helpers::get_filtered_input( $this->product_options_name, 'POST', 'array' )['price_display'] ) ) {
			$jckstl_data['price_display'] = Iconic_WBP_Helpers::get_filtered_input( $this->product_options_name, 'POST', 'array' )['price_display'];
		}

		if ( isset( Iconic_WBP_Helpers::get_filtered_input( $this->product_options_name, 'POST', 'array' )['bundle_price'] ) ) {
			$jckstl_data['bundle_price'] = wc_format_decimal( Iconic_WBP_Helpers::get_filtered_input( $this->product_options_name, 'POST', 'array' )['bundle_price'] );
		}

		if ( isset( Iconic_WBP_Helpers::get_filtered_input( $this->product_options_name, 'POST', 'array' )['add_all_to_cart'] ) ) {
			$jckstl_data['add_all_to_cart'] = Iconic_WBP_Helpers::get_filtered_input( $this->product_options_name, 'POST', 'array' )['add_all_to_cart'];
		}

		if ( isset( Iconic_WBP_Helpers::get_filtered_input( $this->product_options_name, 'POST', 'array' )['fixed_discount'] ) ) {
			$fixed_discount = Iconic_WBP_Helpers::get_filtered_input( $this->product_options_name, 'POST', 'array' )['fixed_discount'];

			if ( 'custom' === $jckstl_data['price_display'] && isset( $jckstl_data['bundle_price'] ) && $jckstl_data['bundle_price'] < $fixed_discount ) {
				$fixed_discount = '';
			}

			$jckstl_data['fixed_discount'] = $fixed_discount;
		}

		if ( isset( Iconic_WBP_Helpers::get_filtered_input( $this->product_options_name, 'POST', 'array' )['hide_add_to_cart'] ) ) {
			$jckstl_data['hide_add_to_cart'] = Iconic_WBP_Helpers::get_filtered_input( $this->product_options_name, 'POST', 'array' )['hide_add_to_cart'];
		}

		if ( isset( Iconic_WBP_Helpers::get_filtered_input( $this->product_options_name, 'POST', 'array' )['hide_qty'] ) ) {
			$jckstl_data['hide_qty'] = Iconic_WBP_Helpers::get_filtered_input( $this->product_options_name, 'POST', 'array' )['hide_qty'];
		}

		if ( isset( Iconic_WBP_Helpers::get_filtered_input( $this->product_options_name, 'POST', 'array' )['hide_prices'] ) ) {
			$jckstl_data['hide_prices'] = Iconic_WBP_Helpers::get_filtered_input( $this->product_options_name, 'POST', 'array' )['hide_prices'];
		}

		if ( isset( Iconic_WBP_Helpers::get_filtered_input( $this->product_options_name, 'POST', 'array' )['show_product_gallery'] ) ) {
			$jckstl_data['show_product_gallery'] = Iconic_WBP_Helpers::get_filtered_input( $this->product_options_name, 'POST', 'array' )['show_product_gallery'];
		}

		update_post_meta( $post_id, $this->product_options_name, $jckstl_data );
	}

	/**
	 * Remove the reviews tab for this product type
	 *
	 * @param array $tabs The tabs.
	 * @return array
	 */
	public function remove_reviews_tab( $tabs ) {
		unset( $tabs['reviews'] );

		return $tabs;
	}

	/**
	 * Shop the Look products display
	 *
	 * Loops through all the chosen products and displays them
	 * in the summary section.
	 *
	 * @param int|bool $product_id Product ID.
	 *
	 * phpcs:disable Generic.CodeAnalysis.UnusedFunctionParameter
	 * Function param is used for the template.
	 */
	public function output_bundled_products( $product_id = false ) {
		global $post, $product;

		$this->unset_posted_attributes();

		include $this->templates->locate_template( 'content-bundled-products.php' );
	}
	/** phpcs:enable Generic.CodeAnalysis.UnusedFunctionParameter */

	/**
	 * Frontend: unset posted attributes $_POST
	 */
	public function unset_posted_attributes() {
		Iconic_WBP_Helpers::unset_posted_attributes();
	}

	/**
	 * Allow to remove method for a hook when it's a class method used
	 * and the class doesn't have a variable assigned, but the class name is known
	 *
	 * @param string $hook_name        Name of the WordPress hook.
	 * @param string $class_name       Name of the class where the add_action resides.
	 * @param string $method_name      Name of the method to unhook.
	 * @param int    $priority         The priority of which the above method has in the add_action.
	 */
	public function remove_filters_for_anonymous_class( $hook_name = '', $class_name = '', $method_name = '', $priority = 0 ) {
		global $wp_filter;

		// Take only filters on right hook name and priority.
		if ( ! isset( $wp_filter[ $hook_name ][ $priority ] ) || ! is_array( $wp_filter[ $hook_name ][ $priority ] ) ) {
			return false;
		}

		// Loop on filters registered.
		foreach ( (array) $wp_filter[ $hook_name ][ $priority ] as $unique_id => $filter_array ) {
			// Test if filter is an array ! (always for class/method).
			if ( isset( $filter_array['function'] ) && is_array( $filter_array['function'] ) ) {
				// Test if object is a class, class and method is equal to param !
				if ( is_object( $filter_array['function'][0] ) && get_class( $filter_array['function'][0] ) && get_class( $filter_array['function'][0] ) === $class_name && $filter_array['function'][1] === $method_name ) {
					unset( $wp_filter[ $hook_name ][ $priority ][ $unique_id ] );
				}
			}
		}

		return false;
	}

	/**
	 * Get WooCommerce version number.
	 */
	public function get_woo_version_number() {
		// If get_plugins() isn't available, require it.
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		// Create the plugins folder and file variables.
		$plugin_folder = get_plugins( '/woocommerce' );
		$plugin_file   = 'woocommerce.php';

		// If the plugin version number is set, return it.
		if ( isset( $plugin_folder[ $plugin_file ]['Version'] ) ) {
			return $plugin_folder[ $plugin_file ]['Version'];
		} else {
			// Otherwise return null.
			return null;
		}
	}

	/**
	 * Helper: Is product allowed in look
	 *
	 * @param WC_Product $product The product.
	 *
	 * @return bool
	 */
	public function is_allowed_in_look( $product ) {
		if ( $product->is_type( 'grouped' ) || $product->is_type( 'bundled' ) ) {
			return false;
		}

		if ( ! $product->is_purchasable() || ! $product->is_visible() ) {
			return false;
		}

		return true;
	}

	/**
	 * Helper: Get current product
	 *
	 * @return object|bool
	 */
	public function get_current_product() {
		global $post;

		if ( ! is_product() ) {
			return false;
		}

		if ( false === $this->current_product ) {
			$this->current_product = wc_get_product( $post->ID );
		}

		return $this->current_product;
	}

	/**
	 * Frontend: Process add to cart action
	 */
	public function process_add_to_cart() {
		if ( empty( Iconic_WBP_Helpers::get_filtered_input( 'jckstl-add-all-to-cart', 'POST', 'check' ) ) ) {
			return;
		}

		if ( empty( Iconic_WBP_Helpers::get_filtered_input( 'jckstl-product-data', 'POST', 'check' ) ) ) {
			return;
		}

		$product_json = json_decode( stripslashes( Iconic_WBP_Helpers::get_filtered_input( 'jckstl-product-data', 'POST', 'array' ) ), true );

		if ( ! $product_json || empty( $product_json ) ) {
			wc_add_notice( __( 'Sorry, the products could not be added to the cart.', 'kadence-shop-kit' ), 'error' );

			return;
		}

		$products_added = true;
		$instance_id    = uniqid();
		$cart_keys      = array();

		foreach ( $product_json as $product ) {
			$product_id   = $product['id'];
			$qty          = $product['qty'];
			$variation_id = isset( $product['variation_id'] ) ? $product['variation_id'] : 0;
			$variation    = isset( $product['variation'] ) ? $product['variation'] : array();

			if ( $variation_id > 0 && empty( $variation ) ) {
				wc_add_notice( __( 'Sorry, one of the products could not be added to the cart.', 'kadence-shop-kit' ), 'error' );
				$products_added = false;
				continue;
			}

			$atc = WC()->cart->add_to_cart(
				$product_id,
				$qty,
				$variation_id,
				$variation,
				array(
					'instance_id' => $instance_id,
				)
			);

			if ( $atc ) {
				wc_add_to_cart_message( array( $product_id => $qty ), true );
				$cart_keys[] = $atc;
			}
		}

		if ( $products_added ) {
			$this->set_bundle_session( Iconic_WBP_Helpers::get_filtered_input( 'jckstl-product-id', 'POST' ), $instance_id, $cart_keys );
		}

		if ( 'yes' === get_option( 'woocommerce_cart_redirect_after_add' ) ) {
			wp_safe_redirect( wc_get_cart_url(), 302 );
			exit;
		}
	}

	/**
	 * Set Cookie for Bundled Discount
	 *
	 * @param int   $bundle_id The bundle ID.
	 * @param int   $instance_id The instance ID.
	 * @param array $cart_keys The cart keys.
	 */
	public function set_bundle_session( $bundle_id, $instance_id, $cart_keys = array() ) {
		$bundle = wc_get_product( $bundle_id );

		if ( ! $bundle ) {
			return;
		}

		$bundles  = $this->get_bundle_session();
		$discount = $bundle->get_discount();

		if ( ! $bundle->has_custom_price() && $discount['amount'] <= 0 ) {
			return;
		}

		$amount = - ( $discount['amount'] );

		if ( $bundle->has_custom_price() ) {
			$cart_total_price = $this->get_cart_total_bundle_price( $cart_keys );
			$bundle_price     = $bundle->get_price();
			$amount          += - ( $cart_total_price - $bundle_price );
		}

		if ( $amount >= 0 ) {
			return;
		}

		$bundles[ $instance_id ] = array(
			'id'       => $bundle_id,
			'name'     => get_the_title( $bundle_id ),
			'discount' => $amount,
		);

		WC()->session->set( 'bundles', $bundles );
	}

	/**
	 * Helper: Get total bundle price in cart
	 *
	 * @param array $cart_keys The cart keys.
	 *
	 * @return float
	 */
	public function get_cart_total_bundle_price( $cart_keys ) {
		$total = 0;

		foreach ( $cart_keys as $cart_key ) {
			if ( isset( WC()->cart->cart_contents[ $cart_key ]['line_total'] ) ) {
				// If prices are inclusive of tax then we need to add tax to the total.
				$line_total = wc_prices_include_tax() ? (float) WC()->cart->cart_contents[ $cart_key ]['line_total'] + (float) WC()->cart->cart_contents[ $cart_key ]['line_tax'] : (float) WC()->cart->cart_contents[ $cart_key ]['line_total'];
				$total     += wc_format_decimal( $line_total, wc_get_price_decimals() );
			}
		}

		return $total;
	}

	/**
	 * Get Cookie for Bundled Discount
	 *
	 * @return array
	 */
	public function get_bundle_session() {
		$bundles = WC()->session->get( 'bundles' );

		if ( $bundles ) {
			return $bundles;
		}

		return array();
	}

	/**
	 * Add discount if applicable
	 */
	public function add_discount() {
		$this->remove_unused_bundle_session();
		$bundles = $this->get_bundle_session();

		if ( ! $bundles || empty( $bundles ) ) {
			return;
		}

		foreach ( $bundles as $instace_id => $bundle ) {
			$product = wc_get_product( $bundle['id'] );

			// If prices include tax, we need to get the discount excluding tax.
			if ( wc_prices_include_tax() ) {
				$discount       = abs( $bundle['discount'] );
				$tax_rates      = WC_Tax::get_rates( $product->get_tax_class() );
				$base_tax_rates = WC_Tax::get_base_tax_rates( $product->get_tax_class( 'unfiltered' ) );
				/**
				 * Filter non base location prices.
				 */
				$remove_taxes       = apply_filters( 'woocommerce_adjust_non_base_location_prices', true ) ? WC_Tax::calc_tax( $discount, $base_tax_rates, true ) : WC_Tax::calc_tax( $discount, $tax_rates, true );
				$discount           = $discount - array_sum( $remove_taxes ); // Unrounded since we're dealing with tax inclusive prices. Matches logic in cart-totals class. @see adjust_non_base_location_price.
				$bundle['discount'] = - $discount;
			}

			$this->wc_cart_add_fee( $instace_id, sprintf( '"%s" %s', $bundle['name'], __( 'Discount', 'kadence-shop-kit' ) ), $bundle['discount'] );
		}
	}

	/**
	 * Add fee to cart.
	 *
	 * @param int    $id The id.
	 * @param string $name The name.
	 * @param float  $amount The amount.
	 */
	public function wc_cart_add_fee( $id, $name, $amount ) {
		$fees = WC()->cart->get_fees();

		// Only add each fee once.
		foreach ( $fees as $fee ) {
			if ( $fee->id === $id ) {
				return;
			}
		}

		WC()->cart->fees_api()->add_fee(
			array(
				'name'      => esc_attr( $name ),
				'amount'    => (float) $amount,
				'taxable'   => false,
				'tax_class' => '',
			)
		);
	}

	/**
	 * Maybe remove discount
	 *
	 * Check which product is being removed from the cart,
	 * and if it's aprt of a bundle, remove the discount.
	 *
	 * @param string  $cart_item_key The cart item key.
	 * @param WC_Cart $wc_cart The cart.
	 */
	public function maybe_remove_discount( $cart_item_key, $wc_cart ) {
		if ( ! isset( $wc_cart->cart_contents[ $cart_item_key ]['instance_id'] ) ) {
			return;
		}

		$bundles = $this->get_bundle_session();

		if ( ! $bundles ) {
			return;
		}

		foreach ( $bundles as $instance_id => $bundle ) {
			if ( $wc_cart->cart_contents[ $cart_item_key ]['instance_id'] === $instance_id ) {
				unset( $bundles[ $instance_id ] );
				break;
			}
		}

		WC()->session->set( 'bundles', $bundles );
	}

	/**
	 * Delete the session if the product associated with it has been removed.
	 * This is needed because maybe_remove_discount() seems to sometimes miss it.
	 *
	 * @return void
	 */
	public function remove_unused_bundle_session() {
		$cart               = WC()->cart;
		$all_cart_instances = array();

		foreach ( $cart->cart_contents as $item ) {
			if ( ! isset( $item['instance_id'] ) ) {
				continue;
			}

			$all_cart_instances[] = $item['instance_id'];
		}

		$bundles = $this->get_bundle_session();

		foreach ( $bundles as $instance_id => $bundle ) {
			if ( ! in_array( $instance_id, $all_cart_instances, true ) ) {
				unset( $bundles[ $instance_id ] );
			}
		}

		WC()->session->set( 'bundles', $bundles );
	}

	/**
	 * Declare HPOS compatiblity.
	 *
	 * @since 2.3.4
	 */
	public function declare_hpos_compatibility() {
		if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
		}
	}

	/**
	 * Instantiate a single instance of our plugin.
	 *
	 * @return Iconic_Woo_Bundled_Products
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Get the DI container.
	 *
	 * @return ContainerInterface
	 */
	public function container() {
		return App::container();
	}

	/**
	 * Check if the shortcodes `iconic-woo-bundle` is
	 * added to the post content.
	 *
	 * @param WP_Post|null $post_object The post.
	 * @return boolean
	 */
	protected function has_shortcode( $post_object = null ) {
		global $post;

		if ( is_null( $post_object ) ) {
			$post_object = $post;
		}

		if ( ! is_a( $post_object, 'WP_Post' ) ) {
			return false;
		}

		return (
			has_shortcode( $post_object->post_content, 'iconic-woo-bundle' )
			|| has_shortcode( $post_object->post_content, 'kt_bundle' )
		);
	}

	/**
	 * Check if the option `show_product_gallery` is enabled based on
	 * the shortcodes `iconic-woo-bundle` added to the post content.
	 *
	 * @param WP_Post|null $post_object The post.
	 * @return boolean
	 */
	protected function is_product_gallery_enabled( $post_object = null ) {
		global $post;

		if ( is_null( $post_object ) ) {
			$post_object = $post;
		}

		if ( ! is_a( $post_object, 'WP_Post' ) ) {
			return false;
		}

		$content = $post_object->post_content;

		$pattern = get_shortcode_regex( array( 'iconic-woo-bundle' ) );

		preg_match_all( '/' . $pattern . '/s', $content, $matches );

		$shortcodes_atts = $matches[3] ?? array();

		$is_product_gallery_enabled = false;
		foreach ( $shortcodes_atts as $shortcode_atts ) {
			parse_str( $shortcode_atts, $atts );

			$id = $atts['id'] ?? null;

			if ( ! $id ) {
				continue;
			}

			$product = wc_get_product( $atts['id'] );

			if ( ! $product ) {
				continue;
			}

			if ( ! $product->is_type( 'bundled' ) ) {
				continue;
			}

			if ( empty( $product->options['show_product_gallery'] ) ) {
				continue;
			}

			if ( 'yes' !== $product->options['show_product_gallery'] ) {
				continue;
			}

			$is_product_gallery_enabled = true;
			break;
		}

		return $is_product_gallery_enabled;
	}

	/**
	 * When the option `show_product_gallery` is enabled, it's
	 * necessary to add WooCommerce classes to the body tag
	 * as some CSS rules added by the themes rely on these classes.
	 *
	 * @param string[] $classes An array of body class names.
	 * @return string[]
	 */
	public function add_woocommerce_classes_when_product_gallery_is_enabled( $classes ) {
		if ( is_product() ) {
			return $classes;
		}

		if ( ! $this->has_shortcode() ) {
			return $classes;
		}

		if ( ! $this->is_product_gallery_enabled() ) {
			return;
		}

		$classes[] = 'woocommerce';
		$classes[] = 'single-product';

		return $classes;
	}
}

// Explicit global declaration required because this file is loaded via require
// inside a method (Plugin_Feature::load), not at the top-level scope where it
// would be implicitly global.
global $iconic_woo_bundled_products;
$iconic_woo_bundled_products = Iconic_Woo_Bundled_Products::instance();
