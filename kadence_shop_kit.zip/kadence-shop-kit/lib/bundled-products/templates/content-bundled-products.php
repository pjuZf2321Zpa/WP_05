<?php
/**
 * The template for displaying product content in the content-shop-the-look.php template
 *
 * @param int $product_id Product ID.
 *
 * @package Iconic_Woo_Bundled_Products
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly.

global $product, $iconic_woo_bundled_products, $stl_product;

// Cater for the single product block,
// we pass in the product ID to the
// output_bundled_products call.
if ( isset( $product_id ) ) {
	$product_object = wc_get_product( $product_id );

	if ( $product_object ) {
		$product = $product_object;
	}
}

if ( ! $product->is_type( 'bundled' ) || empty( $product->get_product_ids() ) ) {
	return;
}

$wrapper_classes = array( 'iconic-woo-bundled-products' );
$stl_products    = array_filter( $product->get_products(), array( $iconic_woo_bundled_products, 'is_allowed_in_look' ) );

if ( empty( $stl_products ) ) {
	return;
}

if ( isset( $product->options['hide_add_to_cart'] ) && 'yes' === $product->options['hide_add_to_cart'] ) {
	$wrapper_classes[] = 'iconic-woo-bundled-products--hide-add-to-cart';
}

if ( isset( $product->options['hide_qty'] ) && 'yes' === $product->options['hide_qty'] ) {
	$wrapper_classes[] = 'iconic-woo-bundled-products--hide-qty';
}

if ( isset( $product->options['hide_prices'] ) && 'yes' === $product->options['hide_prices'] ) {
	$wrapper_classes[] = 'iconic-woo-bundled-products--hide-prices';
}
?>

<div 
class="
<?php
echo esc_attr(
	implode(
		' ',
		/**
		* Filter wrapper classes.
		*
		* @param array $wrapper_classes The wrapper classes.
		* @param WC_Product $product The product.
		* @return array New value.
		*/
		apply_filters( 'iconic_wbp_wrapper_classes', $wrapper_classes, $product )
	)
);
?>
	">
	<?php foreach ( $stl_products as $stl_product ) { ?>

		<?php
		$post_object     = get_post( $stl_product->get_id() );
		$GLOBALS['post'] =& $post_object; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
		setup_postdata( $GLOBALS['post'] );
		?>

		<?php
		$classes = array(
			'product',
			'iconic-woo-bundled-product',
			sprintf( 'iconic-woo-bundled-product--%s', $stl_product->get_type() ),
			sprintf( 'product-type-%s', $stl_product->get_type() ),
		);
		?>

		<div 
			class="
			<?php
			echo esc_attr(
				implode(
					' ',
					/**
					* Filter product classes
					*
					* @param string $classes The classes.
					* @param WC_Product $stl_product The product.
					* @param WC_Product $product The product.
					* @return New classes.
					*/
					apply_filters( 'iconic_wbp_product_classes', $classes, $stl_product, $product )
				)
			);
			?>
			"
			data-product-type="<?php echo esc_attr( $stl_product->get_type() ); ?>"
		>
			<?php
				/**
				 * Runs on content product image.
				 */
				do_action( 'iconic_wbp_content_product_image', $stl_product, $product );
			?>

			<div class="iconic-woo-bundled-product__summary">
				<?php
					/**
					 * Runs on content product summary
					 */
					do_action( 'iconic_wbp_content_product_summary', $stl_product, $product );
				?>
			</div>
		</div>

		<?php
	}
	wp_reset_postdata();
	?>

	<?php if ( isset( $product->options['add_all_to_cart'] ) && 'no' !== $product->options['add_all_to_cart'] ) { ?>
		<form action="" method="post" class="jckstl-add-all-to-cart">
			<input type="hidden" name="jckstl-product-data" class="jckstl-add-all-to-cart__product-data">
			<input type="hidden" name="jckstl-product-id" value="<?php echo esc_attr( $product->get_id() ); ?>">
			<button type="submit" name="jckstl-add-all-to-cart" class="jckstl-add-all-to-cart__button button alt"><?php echo wp_kses_post( $product->get_add_all_to_cart_button_text() ); ?></button>

			<?php
				/**
				 * Runs after add all to cart form.
				 *
				 * @param WP_Product $product The product.
				 */
				do_action( 'iconic_wbp_add_all_to_cart_form', $product );
			?>
		</form>
	<?php } ?>
</div>
