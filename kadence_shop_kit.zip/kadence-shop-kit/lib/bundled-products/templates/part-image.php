<?php
/**
 * The template for displaying the image thumbnail in content-shop-the-look.php
 *
 * Override this template by copying it to yourtheme/woocommerce/shop-the-look/image.php
 *
 * @package Iconic_Woo_Bundled_Products
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$show_gallery = 'yes' === ( $product->options['show_product_gallery'] ?? false );
/**
 * Filter whether to show the product gallery.
 *
 * @since 2.10.0
 * @hook iconic_wbp_show_product_gallery
 * @param bool       $show_gallery Whether to show the product gallery.
 * @param WC_Product $bundled_product The bundled product.
 * @param WC_Product $product Product shown in the bundled product.
 */
$show_gallery = apply_filters( 'iconic_wbp_show_product_gallery', $show_gallery, $product, $stl_product );

?>

<div class="iconic-woo-bundled-product__image images">
	<div class="woocommerce-product-gallery__image">
		<?php if ( $show_gallery ) : ?>
			<?php woocommerce_show_product_images(); ?>
		<?php else : ?>
			<?php echo wp_kses_post( $stl_product->get_image( 'shop_catalog' ) ); ?>
		<?php endif; ?>
	</div>
</div>
