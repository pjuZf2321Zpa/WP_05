<?php
/**
 * The template for displaying the description in content-shop-the-look.php
 *
 * @package Iconic_Woo_Bundled_Products
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly.

echo wp_kses_post( apply_filters( 'woocommerce_short_description', Iconic_WBP_Backwards_Compatibility::get_short_description( $stl_product ) ) );
