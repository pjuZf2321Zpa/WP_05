<?php
/**
 * Compatibility with CURCY - WooCommerce Multi Currency plugin.
 *
 * @see https://villatheme.com/extensions/woo-multi-currency/
 * @package Iconic_Woo_Bundled_Products
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * CURCY – WooCommerce Multi Currency compatibility Class.
 *
 * @since 2.8.0
 */
class Iconic_WBP_Compat_Curcy_WooCommerce_Multi_Currency {
	/**
	 * Add action and filters
	 *
	 * @since 2.8.0
	 *
	 * @return void
	 */
	public static function init() {
		if ( ! defined( 'WOOMULTI_CURRENCY_VERSION' ) ) {
			return;
		}

		add_action( 'woocommerce_stl_price', [ __CLASS__, 'maybe_update_price' ], 50, 3 );
	}

	/**
	 * Maybe update price based on the selected currency.
	 *
	 * @param string|int|float $price The bundle price.
	 * @return string|int|float
	 */
	public static function maybe_update_price( $price ) {
		if ( ! function_exists( 'wmc_get_price' ) ) {
			return $price;
		}

		if ( empty( $price ) ) {
			return $price;
		}

		return wmc_get_price( $price );
	}
}
