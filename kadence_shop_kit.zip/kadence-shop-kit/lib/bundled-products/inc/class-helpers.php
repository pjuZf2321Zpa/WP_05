<?php
/**
 * WBP Helper class.
 *
 * @package Iconic_Woo_Bundled_Products
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Iconic_WDS_Helpers.
 *
 * @class    Iconic_WDS_Helpers
 * @version  1.0.0
 */
class Iconic_WBP_Helpers {

	/**
	 * Get filtered input.
	 *
	 * @param string $key         Key.
	 * @param string $http_method The HTTP method used to pass the variables.
	 * @param string $type        String|int|etc.
	 * @param string $nonce_key   Nonce key.
	 * @param string $nonce_value Nonce Value.
	 *
	 * @return array|int|mixed|string
	 */
	public static function get_filtered_input( $key, $http_method = '', $type = 'string', $nonce_key = '', $nonce_value = '' ) {
		if ( $nonce_key ) {
			check_admin_referer( $nonce_key, $nonce_value );
		}

		switch ( strtolower( $http_method ) ) {
			case 'post':
				$http_variables = $_POST;
				break;

			case 'get':
				$http_variables = $_GET;
				break;

			default:
				$http_variables = $_REQUEST;
				break;
		}

		if ( ! array_key_exists( $key, $http_variables ) ) {
			return false;
		}

		if ( 'check' === $type ) {
			$input = true;
		} elseif ( 'string' === $type ) {
			$input = sanitize_text_field( filter_var( wp_unslash( $http_variables[ $key ] ), FILTER_SANITIZE_FULL_SPECIAL_CHARS ) );
		} elseif ( 'int' === $type ) {
			$input = (int) sanitize_text_field( filter_var( wp_unslash( $http_variables[ $key ] ), FILTER_SANITIZE_NUMBER_INT ) );
		} elseif ( 'array' === $type ) {
			$input = $http_variables[ $key ];
		} else {
			$input = filter_var( wp_unslash( $http_variables[ $key ] ) );
		}

		return $input;
	}

	/**
	 * Unset $_REQUEST key.
	 *
	 * @param string $nonce_key   Nonce key.
	 * @param string $nonce_value Nonce Value.
	 * @return void
	 */
	public static function unset_posted_attributes( $nonce_key = '', $nonce_value = '' ) {
		if ( $nonce_key ) {
			check_admin_referer( $nonce_key, $nonce_value );
		}

		if ( ! empty( $_REQUEST ) ) {
			foreach ( $_REQUEST as $key => $value ) {
				if ( strpos( $key, 'attribute_' ) !== false ) {
					unset( $_REQUEST[ $key ] );
				}
			}
		}
	}
}
