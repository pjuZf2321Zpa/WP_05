<?php
/**
 * WC_Product_Bundled class.
 *
 * @package Iconic_Woo_Bundled_Products
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly.

/**
 * Bundled Product Class
 *
 * Bundled product type.
 *
 * @class          WC_Product_Bundled
 * @version        1.0.0
 */

if ( class_exists( 'WC_Product' ) ) :
	/**
	 * WC_Product_Bundled class
	 */
	class WC_Product_Bundled extends WC_Product {
		/**
		 * Bundled Product Ids
		 *
		 * @var array
		 */
		public $product_ids = array();

		/**
		 * Bundled Products
		 *
		 * @var false|array
		 */
		public $products = false;

		/**
		 * Bundled Prices
		 *
		 * @var false|array
		 */
		public $prices = false;

		/**
		 * Bundled min price
		 *
		 * @var int|float
		 */
		public $min_price = 0;

		/**
		 * Bundled max price
		 *
		 * @var int|float
		 */
		public $max_price = 0;

		/**
		 * Product type;
		 *
		 * @var array
		 */
		public $product_type = 'bundled';

		/**

		 * Product ID (block context);
		 *
		 * @var int
		 */
		public $product_id = 0;

		/**
		 * Product specific options
		 *
		 * @var array
		 */
		public $options = array();

		/**
		 * Construct
		 *
		 * @param mixed $product The product.
		 */
		public function __construct( $product = 0 ) {
			global $iconic_woo_bundled_products;

			$product_id       = is_numeric( $product ) ? $product : $product->get_id();
			$this->product_id = $product_id;
			$this->options    = get_post_meta( $product_id, $iconic_woo_bundled_products->product_options_name, true );

			parent::__construct( $product_id );
		}

		/**
		 * Get internal type.
		 *
		 * @return string
		 */
		public function get_type() {
			return 'bundled';
		}

		/**
		 * Helper: Is purchasable
		 *
		 * @return bool
		 */
		public function is_purchasable() {
			return false;
		}

		/**
		 * Helper: Get Bundled IDs
		 */
		public function get_product_ids() {
			global $iconic_woo_bundled_products;

			if ( empty( $this->product_ids ) ) {
				$product_ids = get_post_meta( $this->product_id, $iconic_woo_bundled_products->product_options_name, true );

				if ( ! $product_ids || empty( $product_ids['product_ids'] ) ) {
					return $this->product_ids;
				}

				$product_ids = is_array( $product_ids['product_ids'] ) ? $product_ids['product_ids'] : explode( ',', $product_ids['product_ids'] );

				$this->product_ids = $product_ids;
			}

			return $this->product_ids;
		}

		/**
		 * Helper: Get Bundled products
		 */
		public function get_products() {
			if ( false !== $this->products ) {
				/**
				 * Filter WBP Products.
				 *
				 * @param array $products The products.
				 * @param WC_Product_Bundled $wc_product_bundled The WC_Product_Bundled instance.
				 */
				return apply_filters( 'iconic_wbp_products', $this->products, $this );
			}

			$this->products = array();
			$product_ids    = $this->get_product_ids();

			if ( ! empty( $product_ids ) ) {
				foreach ( $product_ids as $product_id ) {
					$product = wc_get_product( $product_id );

					if ( ! $product ) {
						continue;
					}

					$this->products[] = $product;
				}
			}

			/**
			 * Filter WBP products.
			 *
			 * @param array $products The products.
			 * @param WC_Product_Bundled $wc_product_bundled The WC_Product_Bundled instance.
			 */
			return apply_filters( 'iconic_wbp_products', $this->products, $this );
		}

		/**
		 * Helper: Get price
		 *
		 * @param string $context The context.
		 *
		 * @return int
		 */
		public function get_price( $context = 'view' ) {
			if ( ! isset( $this->options['price_display'] ) ) {
				return false;
			}

			if ( '' === $this->options['price_display'] ) {
				return false;
			}

			if ( 'range' === $this->options['price_display'] ) {
				/**
				 * Filter stl price.
				 */
				return apply_filters( 'woocommerce_stl_price', $this->get_min_price(), $this );
			} elseif ( 'combined' === $this->options['price_display'] ) {
				$prices = $this->get_prices();

				$prices = array_merge( $prices['min'], $prices['single'] );

				/**
				 * Filter stl price.
				 */
				return apply_filters( 'woocommerce_stl_price', array_sum( $prices ), $this );
			} elseif ( $this->has_custom_price() ) {
				/**
				 * Filter stl price.
				 */
				return apply_filters( 'woocommerce_stl_price', $this->options['bundle_price'], $this );
			}

			return false;
		}

		/**
		 * Helper: Has custom price
		 */
		public function has_custom_price() {
			return 'custom' === $this->options['price_display'];
		}

		/**
		 * Get variation price HTML. Prices are not inherited from parents.
		 *
		 * @param float $price The price.
		 * @return string containing the formatted price
		 */
		public function get_price_html( $price = '' ) {
			global $iconic_woo_bundled_products;

			$price = $this->get_price();

			if ( ! $price ) {
				return '';
			}

			if ( 0 === $price ) {
				/**
				 * Filter stl free price HTML.
				 */
				$price = apply_filters( 'woocommerce_stl_free_price_html', __( 'Free!', 'kadence-shop-kit' ), $this );
			} elseif ( 'range' === $this->options['price_display'] ) {
				$price = $this->get_min_price() !== $this->get_max_price() ? sprintf( '%1$s&ndash;%2$s', wc_price( $this->get_min_price() ), wc_price( $this->get_max_price() ) ) : wc_price( $this->get_min_price() );
			} elseif ( 'combined' === $this->options['price_display'] ) {
				$discount = $this->get_discount();

				if ( $discount['amount'] > 0 ) {
					$min_price_discounted = $this->get_min_price() - $discount['amount'];
					$max_price_discounted = $this->get_max_price() - $discount['amount'];

					$price = $this->get_min_price() !== $this->get_max_price() ? sprintf( '<del>%s&ndash;%s</del> <ins>%s&ndash;%s</ins>', wc_price( $this->get_min_price() ), wc_price( $this->get_max_price() ), wc_price( $min_price_discounted ), wc_price( $max_price_discounted ) ) : sprintf( '<del>%s</del> <ins>%s</ins>', wc_price( $this->get_min_price() ), wc_price( $min_price_discounted ) );
				} else {
					$price = $this->get_min_price() !== $this->get_max_price() ? sprintf( '%1$s&ndash;%2$s', wc_price( $this->get_min_price() ), wc_price( $this->get_max_price() ) ) : wc_price( $this->get_min_price() );
				}
			} else {
				/**
				 * Filter stl prict HTML.
				 */
				$price = apply_filters( 'woocommerce_stl_price_html', wc_price( $price ) . $this->get_price_suffix(), $this );
			}

			/**
			 * Filter price HTML.
			 */
			return apply_filters( 'woocommerce_get_price_html', $price, $this );
		}

		/**
		 * Get Prices
		 *
		 * @return array
		 */
		public function get_prices() {
			if ( false === $this->prices ) {
				$prices   = array(
					'min'    => array(),
					'max'    => array(),
					'single' => array(),
				);
				$products = $this->get_products();

				if ( ! empty( $products ) ) {
					foreach ( $products as $stl_product ) {
						if ( $stl_product->is_type( 'variable' ) ) {
							$variation_prices = $stl_product->get_variation_prices();

							if ( empty( $variation_prices['price'] ) ) {
								$prices['single'][] = $stl_product->get_price();
								continue;
							}

							$min_price = current( $variation_prices['price'] );
							$max_price = end( $variation_prices['price'] );

							$prices['min'][] = $min_price;
							$prices['max'][] = $max_price;
						} else {
							$prices['single'][] = $stl_product->get_price();
						}
					}
				}

				$this->prices = $prices;
			}

			return $this->prices;
		}

		/**
		 * Get min price
		 *
		 * @param mixed $type The type.
		 * @return int
		 */
		public function get_min_price( $type = null ) {
			if ( 0 === $this->min_price || ! is_null( $type ) ) {
				$prices = $this->get_prices();

				if ( empty( $prices['min'] ) && empty( $prices['max'] ) && empty( $prices['single'] ) ) {
					return (float) $this->min_price;
				}

				$prices = array_merge( $prices['min'], $prices['single'] );

				$this->min_price = 'combined' === $this->options['price_display'] || 'combined' === $type ? array_sum( $prices ) : min( $prices );
			}

			return (float) $this->min_price;
		}

		/**
		 * Get max price
		 *
		 * @param string|bool $type The type.
		 *
		 * @return int
		 */
		public function get_max_price( $type = null ) {
			if ( 0 === $this->max_price || ! is_null( $type ) ) {
				$prices = $this->get_prices();

				$prices = array_merge( $prices['max'], $prices['single'] );

				if ( 'range' === $this->options['price_display'] || 'range' === $type ) {
					$this->max_price = max( $prices );
				} elseif ( 'combined' === $this->options['price_display'] || 'combined' === $type ) {
					$this->max_price = array_sum( $prices );
				} else {
					$this->max_price = min( $prices );
				}
			}

			return (float) $this->max_price;
		}

		/**
		 * Get discount
		 */
		public function get_discount() {
			$discount = isset( $this->options['fixed_discount'] ) ? $this->options['fixed_discount'] : false;

			if ( ! $discount ) {
				return array(
					'type'      => 'none',
					'amount'    => 0,
					'formatted' => wc_price( 0 ),
				);
			}

			return array(
				'type'      => 'fixed',
				'amount'    => (float) $discount,
				'formatted' => wc_price( $discount ),
			);
		}

		/**
		 * Get add all to cart button text.
		 *
		 * @return string
		 */
		public function get_add_all_to_cart_button_text() {
			$discount = $this->get_discount();
			$up_to    = false;

			if ( $this->has_custom_price() ) {
				$price              = $this->get_price();
				$min_combined_price = $this->get_min_price( 'combined' );
				$max_combined_price = $this->get_max_price( 'combined' );
				$price_discount     = $max_combined_price - $price;
				$up_to              = $max_combined_price > $min_combined_price ? __( 'up to', 'kadence-shop-kit' ) : false;

				$discount['amount'] = $discount['amount'] + $price_discount;
			}

			// translators: %1$s 'up to'; %2$s discount.
			$button_text = $discount['amount'] > 0 ? sprintf( __( 'Add All to Cart &mdash; Save %1$s %2$s', 'kadence-shop-kit' ), $up_to, wc_price( $discount['amount'] ) ) : __( 'Add All to Cart', 'kadence-shop-kit' );

			/**
			 * Filter add all to cart text
			 *
			 * @param string $button_text The text.
			 * @param WC_Product_Bundled $wc_product_bundled The WC_Product_Bundled instance.
			 * @return string New value.
			 */
			return apply_filters( 'iconic_wbp_add_all_to_cart_text', $button_text, $this );
		}
	}
endif;
