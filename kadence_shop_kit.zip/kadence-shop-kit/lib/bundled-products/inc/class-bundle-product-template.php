<?php
/**
 * Bundled Product Template.
 *
 * @package Iconic_Woo_Bundled_Products
 */

use Automattic\WooCommerce\Admin\Features\Features;
use Automattic\WooCommerce\Admin\Features\ProductBlockEditor\ProductTemplates\ProductFormTemplateInterface;
use Automattic\WooCommerce\Internal\Features\ProductBlockEditor\ProductTemplates\AbstractProductFormTemplate;
use Automattic\WooCommerce\Internal\Features\ProductBlockEditor\ProductTemplates\DownloadableProductTrait;

/**
 * Bundled Product Template to be used by Product Block Editor.
 *
 * Most of the code copied from:
 * woocommerce/src/Internal/Features/ProductBlockEditor/ProductTemplates/SimpleProductTemplate.php
 */
class BundledProductTemplate extends AbstractProductFormTemplate implements ProductFormTemplateInterface {
	use DownloadableProductTrait;

	/**
	 * The context name used to identify the editor.
	 */
	const GROUP_IDS = array(
		'GENERAL'         => 'general',
		'ORGANIZATION'    => 'organization',
		'PRICING'         => 'pricing',
		'INVENTORY'       => 'inventory',
		'SHIPPING'        => 'shipping',
		'VARIATIONS'      => 'variations',
		'LINKED_PRODUCTS' => 'linked-products',
	);

	/**
	 * SimpleProductTemplate constructor.
	 */
	public function __construct() {
		$this->add_group_blocks();
		$this->add_general_group_blocks();
		$this->add_organization_group_blocks();
		$this->add_linked_products_group_blocks();
	}

	/**
	 * Get the template ID.
	 */
	public function get_id(): string {
		return 'iconic-bundled-product';
	}

	/**
	 * Get the template title.
	 */
	public function get_title(): string {
		return __( 'Bundled Product Template', 'kadence-shop-kit' );
	}

	/**
	 * Get the template description.
	 */
	public function get_description(): string {
		return __( 'Template for the bundled product form', 'kadence-shop-kit' );
	}

	/**
	 * Adds the group blocks to the template.
	 */
	private function add_group_blocks() {
		$this->add_group(
			array(
				'id'         => $this::GROUP_IDS['GENERAL'],
				'order'      => 10,
				'attributes' => array(
					'title' => __( 'General', 'kadence-shop-kit' ),
				),
			)
		);

		$this->add_group(
			array(
				'id'         => $this::GROUP_IDS['ORGANIZATION'],
				'order'      => 30,
				'attributes' => array(
					'title' => __( 'Organization', 'kadence-shop-kit' ),
				),
			)
		);

		$shipping_hide_conditions = array();
		if ( Features::is_enabled( 'product-grouped' ) ) {
			$shipping_hide_conditions[] = array(
				'expression' => 'editedProduct.type === "grouped"',
			);
		}
		if ( Features::is_enabled( 'product-external-affiliate' ) ) {
			$shipping_hide_conditions[] = array(
				'expression' => 'editedProduct.type === "external"',
			);
		}

		// Linked Products tab.
		if ( Features::is_enabled( 'product-linked' ) ) {
			$this->add_group(
				array(
					'id'         => $this::GROUP_IDS['LINKED_PRODUCTS'],
					'order'      => 70,
					'attributes' => array(
						'title' => __( 'Linked products', 'kadence-shop-kit' ),
					),
				)
			);
		}
	}

	/**
	 * Adds the general group blocks to the template.
	 */
	private function add_general_group_blocks() {
		$general_group = $this->get_group_by_id( $this::GROUP_IDS['GENERAL'] );
		$general_group->add_block(
			array(
				'id'         => 'product_variation_notice_general_tab',
				'blockName'  => 'woocommerce/product-has-variations-notice',
				'order'      => 10,
				'attributes' => array(
					'content'    => __( 'This product has options, such as size or color. You can manage each variation\'s images, downloads, and other details individually.', 'kadence-shop-kit' ),
					'buttonText' => __( 'Go to Variations', 'kadence-shop-kit' ),
					'type'       => 'info',
				),
			)
		);
		// Basic Details Section.
		$basic_details = $general_group->add_section(
			array(
				'id'         => 'basic-details',
				'order'      => 10,
				'attributes' => array(
					'title'       => __( 'Basic details', 'kadence-shop-kit' ),
					'description' => __( 'This info will be displayed on the product page, category pages, social media, and search results.', 'kadence-shop-kit' ),
				),
			)
		);
		$basic_details->add_block(
			array(
				'id'        => 'product-details-section-description',
				'blockName' => 'woocommerce/product-details-section-description',
				'order'     => 10,
			)
		);
		$basic_details->add_block(
			array(
				'id'         => 'product-name',
				'blockName'  => 'woocommerce/product-name-field',
				'order'      => 10,
				'attributes' => array(
					'name'      => 'Product name',
					'autoFocus' => true,
				),
			)
		);

		$basic_details->add_block(
			array(
				'id'         => 'product-summary',
				'blockName'  => 'woocommerce/product-text-area-field',
				'order'      => 20,
				'attributes' => array(
					'label'    => __( 'Summary', 'kadence-shop-kit' ),
					'help'     => __(
						"Summarize this product in 1-2 short sentences. We'll show it at the top of the page.",
						'kadence-shop-kit'
					),
					'property' => 'short_description',
				),
			)
		);

		// Description section.
		$description_section = $general_group->add_section(
			array(
				'id'         => 'product-description-section',
				'order'      => 20,
				'attributes' => array(
					'title'       => __( 'Description', 'kadence-shop-kit' ),
					'description' => __( 'What makes this product unique? What are its most important features? Enrich the product page by adding rich content using blocks.', 'kadence-shop-kit' ),
				),
			)
		);

		$description_field_block = $description_section->add_block(
			array(
				'id'        => 'product-description',
				'blockName' => 'woocommerce/product-description-field',
				'order'     => 10,
			)
		);

		$description_field_block->add_block(
			array(
				'id'         => 'product-description__content',
				'blockName'  => 'woocommerce/product-summary-field',
				'order'      => 10,
				'attributes' => array(
					'helpText' => null,
					'label'    => null,
					'property' => 'description',
				),
			)
		);

		// External/Affiliate section.
		if ( Features::is_enabled( 'product-external-affiliate' ) ) {
			$buy_button_section = $general_group->add_section(
				array(
					'id'             => 'product-buy-button-section',
					'order'          => 30,
					'attributes'     => array(
						'title'       => __( 'Buy button', 'kadence-shop-kit' ),
						'description' => __( 'Add a link and choose a label for the button linked to a product sold elsewhere.', 'kadence-shop-kit' ),
					),
					'hideConditions' => array(
						array(
							'expression' => 'editedProduct.type !== "external"',
						),
					),
				)
			);

			$buy_button_section->add_block(
				array(
					'id'         => 'product-external-url',
					'blockName'  => 'woocommerce/product-text-field',
					'order'      => 10,
					'attributes' => array(
						'property'    => 'external_url',
						'label'       => __( 'Link to the external product', 'kadence-shop-kit' ),
						'placeholder' => __( 'Enter the external URL to the product', 'kadence-shop-kit' ),
						'suffix'      => true,
						'type'        => array(
							'value'   => 'url',
							'message' => __( 'Link to the external product is an invalid URL.', 'kadence-shop-kit' ),
						),
					),
				)
			);

			$button_text_columns = $buy_button_section->add_block(
				array(
					'id'        => 'product-button-text-columns',
					'blockName' => 'core/columns',
					'order'     => 20,
				)
			);

			$button_text_columns->add_block(
				array(
					'id'        => 'product-button-text-column1',
					'blockName' => 'core/column',
					'order'     => 10,
				)
			)->add_block(
				array(
					'id'         => 'product-button-text',
					'blockName'  => 'woocommerce/product-text-field',
					'order'      => 10,
					'attributes' => array(
						'property' => 'button_text',
						'label'    => __( 'Buy button text', 'kadence-shop-kit' ),
					),
				)
			);

			$button_text_columns->add_block(
				array(
					'id'        => 'product-button-text-column2',
					'blockName' => 'core/column',
					'order'     => 20,
				)
			);
		}

		// Product list section.
		if ( Features::is_enabled( 'product-grouped' ) ) {
			$product_list_section = $general_group->add_section(
				array(
					'id'             => 'product-list-section',
					'order'          => 35,
					'attributes'     => array(
						'title'       => __( 'Products in this group', 'kadence-shop-kit' ),
						'description' => __( 'Make a collection of related products, enabling customers to purchase multiple items together.', 'kadence-shop-kit' ),
					),
					'hideConditions' => array(
						array(
							'expression' => 'editedProduct.type !== "grouped"',
						),
					),
				)
			);

			$product_list_section->add_block(
				array(
					'id'         => 'product-list',
					'blockName'  => 'woocommerce/product-list-field',
					'order'      => 10,
					'attributes' => array(
						'property' => 'grouped_products',
					),
				)
			);
		}

		// Images section.
		$images_section = $general_group->add_section(
			array(
				'id'         => 'product-images-section',
				'order'      => 40,
				'attributes' => array(
					'title'       => __( 'Images', 'kadence-shop-kit' ),
					'description' => sprintf(
					/* translators: %1$s: Images guide link opening tag. %2$s: Images guide link closing tag. */
						__( 'Drag images, upload new ones or select files from your library. For best results, use JPEG files that are 1000 by 1000 pixels or larger. %1$sHow to prepare images?%2$s', 'kadence-shop-kit' ),
						'<a href="https://woocommerce.com/posts/how-to-take-professional-product-photos-top-tips" target="_blank" rel="noreferrer">',
						'</a>'
					),
				),
			)
		);
		$images_section->add_block(
			array(
				'id'         => 'product-images',
				'blockName'  => 'woocommerce/product-images-field',
				'order'      => 10,
				'attributes' => array(
					'images'   => array(),
					'property' => 'images',
				),
			)
		);

		// Downloads section.
		$this->add_downloadable_product_blocks( $general_group );
	}

	/**
	 * Adds the organization group blocks to the template.
	 */
	private function add_organization_group_blocks() {
		$organization_group = $this->get_group_by_id( $this::GROUP_IDS['ORGANIZATION'] );
		// Product Catalog Section.
		$product_catalog_section = $organization_group->add_section(
			array(
				'id'         => 'product-catalog-section',
				'order'      => 10,
				'attributes' => array(
					'title'       => __( 'Product catalog', 'kadence-shop-kit' ),
					'description' => __( 'Help customers find this product by assigning it to categories, adding extra details, and managing its visibility in your store and other channels.', 'kadence-shop-kit' ),
				),
			)
		);
		$product_catalog_section->add_block(
			array(
				'id'         => 'product-categories',
				'blockName'  => 'woocommerce/product-taxonomy-field',
				'order'      => 10,
				'attributes' => array(
					'slug'               => 'product_cat',
					'property'           => 'categories',
					'label'              => __( 'Categories', 'kadence-shop-kit' ),
					'createTitle'        => __( 'Create new category', 'kadence-shop-kit' ),
					'dialogNameHelpText' => __( 'Shown to customers on the product page.', 'kadence-shop-kit' ),
					'parentTaxonomyText' => __( 'Parent category', 'kadence-shop-kit' ),
				),
			)
		);
		$product_catalog_section->add_block(
			array(
				'id'         => 'product-tags',
				'blockName'  => 'woocommerce/product-tag-field',
				'attributes' => array(
					'name' => 'tags',
				),
			)
		);
		$product_catalog_section->add_block(
			array(
				'id'         => 'product-catalog-search-visibility',
				'blockName'  => 'woocommerce/product-catalog-visibility-field',
				'order'      => 20,
				'attributes' => array(
					'label'      => __( 'Hide in product catalog', 'kadence-shop-kit' ),
					'visibility' => 'search',
				),
			)
		);
		$product_catalog_section->add_block(
			array(
				'id'         => 'product-catalog-catalog-visibility',
				'blockName'  => 'woocommerce/product-catalog-visibility-field',
				'order'      => 30,
				'attributes' => array(
					'label'      => __( 'Hide from search results', 'kadence-shop-kit' ),
					'visibility' => 'catalog',
				),
			)
		);
		$product_catalog_section->add_block(
			array(
				'id'         => 'product-enable-product-reviews',
				'blockName'  => 'woocommerce/product-checkbox-field',
				'order'      => 40,
				'attributes' => array(
					'label'    => __( 'Enable product reviews', 'kadence-shop-kit' ),
					'property' => 'reviews_allowed',
				),
			)
		);
		$product_catalog_section->add_block(
			array(
				'id'         => 'product-post-password',
				'blockName'  => 'woocommerce/product-password-field',
				'order'      => 50,
				'attributes' => array(
					'label' => __( 'Require a password', 'kadence-shop-kit' ),
				),
			)
		);
		// Attributes section.
		$product_attributes_section = $organization_group->add_section(
			array(
				'id'         => 'product-attributes-section',
				'order'      => 20,
				'attributes' => array(
					'title'       => __( 'Attributes', 'kadence-shop-kit' ),
					'description' => __( 'Use global attributes to allow shoppers to filter and search for this product. Use custom attributes to provide detailed product information.', 'kadence-shop-kit' ),
					'blockGap'    => 'unit-40',
				),
			)
		);
		$product_attributes_section->add_block(
			array(
				'id'        => 'product-attributes',
				'blockName' => 'woocommerce/product-attributes-field',
				'order'     => 10,
			)
		);

		if ( Features::is_enabled( 'product-custom-fields' ) ) {
			$organization_group->add_section(
				array(
					'id'    => 'product-custom-fields-wrapper-section',
					'order' => 30,
				)
			)->add_block(
				array(
					'id'         => 'product-custom-fields-toggle',
					'blockName'  => 'woocommerce/product-custom-fields-toggle-field',
					'order'      => 10,
					'attributes' => array(
						'label' => __( 'Show custom fields', 'kadence-shop-kit' ),
					),
				)
			)->add_block(
				array(
					'id'         => 'product-custom-fields-section',
					'blockName'  => 'woocommerce/product-section',
					'order'      => 10,
					'attributes' => array(
						'blockGap'    => 'unit-30',
						'title'       => __( 'Custom fields', 'kadence-shop-kit' ),
						'description' => sprintf(
							/* translators: %1$s: Custom fields guide link opening tag. %2$s: Custom fields guide link closing tag. */
							__( 'Custom fields can be used in a variety of ways, such as sharing more detailed product information, showing more input fields, or internal inventory organization. %1$sRead more about custom fields%2$s', 'kadence-shop-kit' ),
							'<a href="https://wordpress.org/documentation/article/assign-custom-fields/" target="_blank" rel="noreferrer">',
							'</a>'
						),
					),
				)
			)->add_block(
				array(
					'id'        => 'product-custom-fields',
					'blockName' => 'woocommerce/product-custom-fields',
					'order'     => 10,
				)
			);
		}
	}

	/**
	 * Adds the linked products group blocks to the template.
	 */
	private function add_linked_products_group_blocks() {
		$linked_products_group = $this->get_group_by_id( $this::GROUP_IDS['LINKED_PRODUCTS'] );
		if ( ! isset( $linked_products_group ) ) {
			return;
		}

		$linked_products_group->add_section(
			array(
				'id'         => 'product-linked-upsells-section',
				'order'      => 10,
				'attributes' => array(
					'title'       => __( 'Upsells', 'kadence-shop-kit' ),
					'description' => sprintf(
						/* translators: %1$s: Learn more about linked products. %2$s: Learn more about linked products.*/
						__( 'Upsells are typically products that are extra profitable or better quality or more expensive. Experiment with combinations to boost sales. %1$sLearn more about linked products.%2$s', 'kadence-shop-kit' ),
						'<br /><a href="https://woocommerce.com/document/related-products-up-sells-and-cross-sells/" target="_blank" rel="noreferrer">',
						'</a>'
					),
				),
			)
		)->add_block(
			array(
				'id'         => 'product-linked-upsells',
				'blockName'  => 'woocommerce/product-linked-list-field',
				'order'      => 10,
				'attributes' => array(
					'property'   => 'upsell_ids',
					'emptyState' => array(
						'image'         => 'ShoppingBags',
						'tip'           => __(
							'Tip: Upsells are products that are extra profitable or better quality or more expensive. Experiment with combinations to boost sales.',
							'kadence-shop-kit'
						),
						'isDismissible' => true,
					),
				),
			)
		);

		$linked_products_group->add_section(
			array(
				'id'             => 'product-linked-cross-sells-section',
				'order'          => 20,
				'attributes'     => array(
					'title'       => __( 'Cross-sells', 'kadence-shop-kit' ),
					'description' => sprintf(
						/* translators: %1$s: Learn more about linked products. %2$s: Learn more about linked products.*/
						__( 'By suggesting complementary products in the cart using cross-sells, you can significantly increase the average order value. %1$sLearn more about linked products.%2$s', 'kadence-shop-kit' ),
						'<br /><a href="https://woocommerce.com/document/related-products-up-sells-and-cross-sells/" target="_blank" rel="noreferrer">',
						'</a>'
					),
				),
				'hideConditions' => array(
					array(
						'expression' => 'editedProduct.type === "external" || editedProduct.type === "grouped"',
					),
				),
			)
		)->add_block(
			array(
				'id'         => 'product-linked-cross-sells',
				'blockName'  => 'woocommerce/product-linked-list-field',
				'order'      => 10,
				'attributes' => array(
					'property'   => 'cross_sell_ids',
					'emptyState' => array(
						'image'         => 'CashRegister',
						'tip'           => __(
							'Tip: By suggesting complementary products in the cart using cross-sells, you can significantly increase the average order value.',
							'kadence-shop-kit'
						),
						'isDismissible' => true,
					),
				),
			)
		);
	}
}
