<?php
/**
 * All functions related to Block based Product Editor and Product template.
 *
 * @package Iconic_Woo_Bundled_Products
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use Automattic\WooCommerce\Admin\BlockTemplates\BlockTemplateInterface;
use Automattic\WooCommerce\Admin\Features\ProductBlockEditor\ProductTemplates\ProductFormTemplateInterface;
use Automattic\WooCommerce\Admin\Features\ProductBlockEditor\BlockRegistry;
use Automattic\WooCommerce\Utilities\FeaturesUtil;
use Automattic\WooCommerce\Admin\Features\ProductBlockEditor\ProductTemplate;
use Automattic\WooCommerce\Internal\Features\ProductBlockEditor\ProductTemplates\AbstractProductFormTemplate;
use Automattic\WooCommerce\LayoutTemplates\LayoutTemplateRegistry;

/**
 * Iconic_WBP_Blocks class.
 */
class Iconic_WBP_Blocks {
	/**
	 * Run.
	 */
	public static function run() {
		add_filter( 'render_block_woocommerce/single-product', array( __CLASS__, 'override_single_product_block_render' ), 20, 2 );
		add_filter( 'render_block_woocommerce/product-price', array( __CLASS__, 'override_single_product_price_block_render' ), 20, 2 );

		// Product editor.
		add_action( 'rest_api_init', array( __CLASS__, 'register_layout_templates' ) );
		add_filter( 'woocommerce_product_editor_product_templates', array( __CLASS__, 'assign_bundled_product_template' ) );
		add_filter( 'woocommerce_block_template_register', array( __CLASS__, 'add_blocks_to_product_editor' ), 100 );
		add_filter( 'woocommerce_rest_prepare_product_object', array( __CLASS__, 'add_bundle_data_to_rest_response' ), 10, 3 );
		add_action( 'woocommerce_rest_insert_product_object', array( __CLASS__, 'save_bundle_data' ), 10, 2 );
	}

	/**
	 * Override single product block render.
	 *
	 * @param string $block_content  The block content.
	 * @param array  $block          The full block, including name and attributes.
	 *
	 * @return string
	 */
	public static function override_single_product_block_render( $block_content, $block ) {
		global $iconic_woo_bundled_products;

		if ( is_admin() ) {
			return $block_content;
		}

		if ( empty( $block['attrs']['productId'] ) ) {
			return $block_content;
		}

		ob_start();
		$iconic_woo_bundled_products->output_bundled_products( $block['attrs']['productId'] );
		$wbp_html = ob_get_clean();

		// 6 characters is the length of the closing </div>.
		return substr_replace( $block_content, $wbp_html, strlen( $block_content ) - 6, 0 );
	}

	/**
	 * Override single product price block render.
	 *
	 * @param string $block_content  The block content.
	 * @param array  $block          The full block, including name and attributes.
	 *
	 * @return string
	 */
	public static function override_single_product_price_block_render( $block_content, $block ) {
		global $post;

		if ( is_admin() ) {
			return $block_content;
		}

		if ( empty( $block['attrs']['isDescendentOfSingleProductBlock'] ) ) {
			return $block_content;
		}

		$product_id = self::get_single_product_block_product_id( $post );

		if ( ! $product_id ) {
			return $block_content;
		}

		$block_product = new WC_Product_Bundled( $product_id );

		if ( ! $block_product ) {
			return $block_content;
		}

		return $block_product->get_price_html();
	}

	/**
	 * Extract the product ID from the WC single product block.
	 *
	 * @param WP_Post $post WP_Post object instance.
	 *
	 * @return bool|int
	 */
	public static function get_single_product_block_product_id( $post ) {
		$product_id = false;

		if ( $post && has_block( 'woocommerce/single-product', $post ) ) {
			foreach ( parse_blocks( $post->post_content ) as $block ) {
				if ( 'woocommerce/single-product' === $block['blockName'] &&
					! empty( $block['attrs']['productId'] )
				) {
					$product_id = absint( $block['attrs']['productId'] );
					break;
				}
			}
		}

		return $product_id;
	}

	/**
	 * Register layout template for bundled product.
	 *
	 * @return void
	 */
	public static function register_layout_templates() {
		/*
		 * WooCommerce 11.0 removed the product block editor, taking the template's parent class with it.
		 * What is left of the API are empty shims, so registering against them is pointless as well as fatal.
		 */
		if ( ! class_exists( AbstractProductFormTemplate::class ) ) {
			return;
		}

		require_once ICONIC_WBP_INC_PATH . 'class-bundle-product-template.php';

		$layout_template_registry = wc_get_container()->get( LayoutTemplateRegistry::class );

		if ( ! $layout_template_registry->is_registered( 'iconic-bundled-product' ) ) {
			$layout_template_registry->register(
				'iconic-bundled-product',
				'product-form',
				BundledProductTemplate::class
			);
		}
	}

	/**
	 * Assign bundled product template to Product Editor.
	 *
	 * @param array $templates Templates.
	 *
	 * @return array
	 */
	public static function assign_bundled_product_template( $templates ) {
		$templates[] = new ProductTemplate(
			array(
				'id'                 => 'iconic-bundled-product-template',
				'title'              => __( 'Bundled Products', 'kadence-shop-kit' ),
				'description'        => __( 'Group multiple products together by using a Bundled product.', 'kadence-shop-kit' ),
				'order'              => 10,
				'icon'               => 'box',
				'layout_template_id' => 'iconic-bundled-product',
				'product_data'       => array(
					'type' => 'bundled',
				),
			)
		);

		return $templates;
	}

	/**
	 * Add Bundled data tab and fields to the 'iconic-bundled-product' template.
	 *
	 * @param BlockTemplateInterface $template Template.
	 *
	 * @return template
	 */
	public static function add_blocks_to_product_editor( BlockTemplateInterface $template ) {
		if ( ! $template instanceof ProductFormTemplateInterface || 'iconic-bundled-product' !== $template->get_id() ) {
			return $template;
		}

		$bundle_tab = $template->add_group(
			array(
				'id'         => 'iconic-bundle',
				'order'      => 20,
				'attributes' => array(
					'title' => __( 'Bundle', 'kadence-shop-kit' ),
				),
			)
		);

		// Add a new section.
		$bundle_section = $bundle_tab->add_section(
			array(
				'id'         => 'iconic-wbp',
				'order'      => 10,
				'attributes' => array(
					'title'       => __( 'Bundled Products', 'kadence-shop-kit' ),
					'description' => __( 'Manage bundled product data.', 'kadence-shop-kit' ),
				),
			)
		);

		$bundle_section->add_block(
			array(
				'id'         => 'iconic-wbp-products',
				'order'      => 5,
				'blockName'  => 'woocommerce/product-linked-list-field',
				'attributes' => array(
					'title'       => __( 'Products', 'kadence-shop-kit' ),
					'label'       => __( 'Products', 'kadence-shop-kit' ),
					'description' => __( 'Select products for this bundle group', 'kadence-shop-kit' ),
					'property'    => 'iconic_wbp_product_ids',
					'placeholder' => __( 'Select products to bundle', 'kadence-shop-kit' ),
				),
			)
		);

		$bundle_section->add_block(
			array(
				'id'         => 'iconic-wbp-show-product-gallery',
				'order'      => 5,
				'blockName'  => 'woocommerce/product-select-field',
				'attributes' => array(
					'label'    => __( 'Show product gallery?', 'kadence-shop-kit' ),
					'property' => 'iconic_wbp_show_product_gallery',
					'help'     => '',
					'options'  => array(
						array(
							'value' => 'yes',
							'label' => __( 'Yes', 'kadence-shop-kit' ),
						),
						array(
							'value' => 'no',
							'label' => __( 'No', 'kadence-shop-kit' ),
						),
					),
				),
			)
		);

		$bundle_section->add_block(
			array(
				'id'         => 'iconic-wbp-price-display',
				'blockName'  => 'woocommerce/product-select-field',
				'order'      => 13,
				'attributes' => array(
					'label'    => __( 'Price Display', 'kadence-shop-kit' ),
					'property' => 'iconic_wbp_price_display',
					'help'     => '',
					'options'  => array(
						array(
							'value' => '',
							'label' => __( 'None', 'kadence-shop-kit' ),
						),
						array(
							'value' => 'combined',
							'label' => __( 'Combined', 'kadence-shop-kit' ),
						),
						array(
							'value' => 'range',
							'label' => __( 'Range', 'kadence-shop-kit' ),
						),
						array(
							'value' => 'custom',
							'label' => __( 'Custom', 'kadence-shop-kit' ),
						),
					),
				),
			)
		);

		$bundle_section->add_block(
			array(
				'id'         => 'iconic-wbp-bundle-price',
				'blockName'  => 'woocommerce/product-text-field',
				'order'      => 13,
				'attributes' => array(
					'label'    => __( 'Bundle Price', 'kadence-shop-kit' ),
					'property' => 'iconic_wbp_bundle_price',
					'help'     => __( 'If you selected "Custom" for "Price Display", enter the total price for your bundle here. Note: this is only effective if using "Add All to Cart" button.', 'kadence-shop-kit' ),
					'type'     => array(
						'value' => 'number',
					),
				),
			)
		);

		$bundle_section->add_block(
			array(
				'id'         => 'iconic-wbp-enable-add-all-to-cart',
				'blockName'  => 'woocommerce/product-select-field',
				'order'      => 13,
				'attributes' => array(
					'label'    => __( 'Enable "Add All to Cart"?', 'kadence-shop-kit' ),
					'property' => 'iconic_wbp_add_all_to_cart',
					'help'     => '',
					'options'  => array(
						array(
							'value' => 'yes',
							'label' => __( 'Yes', 'kadence-shop-kit' ),
						),
						array(
							'value' => 'no',
							'label' => __( 'No', 'kadence-shop-kit' ),
						),
					),
				),
			)
		);

		$bundle_section->add_block(
			array(
				'id'         => 'iconic-wbp-hide-individual-cart-btn',
				'blockName'  => 'woocommerce/product-select-field',
				'order'      => 13,
				'attributes' => array(
					'label'    => __( 'Hide Individual "Add to Cart" Buttons?', 'kadence-shop-kit' ),
					'property' => 'iconic_wbp_hide_add_to_cart',
					'help'     => '',
					'options'  => array(
						array(
							'value' => 'yes',
							'label' => __( 'Yes', 'kadence-shop-kit' ),
						),
						array(
							'value' => 'no',
							'label' => __( 'No', 'kadence-shop-kit' ),
						),
					),
				),
			)
		);

		$bundle_section->add_block(
			array(
				'id'         => 'iconic-wbp-hide-individual-qty',
				'blockName'  => 'woocommerce/product-select-field',
				'order'      => 13,
				'attributes' => array(
					'label'    => __( 'Hide Individual Quantity Fields?', 'kadence-shop-kit' ),
					'property' => 'iconic_wbp_hide_qty',
					'help'     => '',
					'options'  => array(
						array(
							'value' => 'yes',
							'label' => __( 'Yes', 'kadence-shop-kit' ),
						),
						array(
							'value' => 'no',
							'label' => __( 'No', 'kadence-shop-kit' ),
						),
					),
				),
			)
		);

		$bundle_section->add_block(
			array(
				'id'         => 'iconic-wbp-hide-individual-prices',
				'blockName'  => 'woocommerce/product-select-field',
				'order'      => 13,
				'attributes' => array(
					'label'    => esc_html__( 'Hide Individual Prices?', 'kadence-shop-kit' ),
					'property' => 'iconic_wbp_hide_prices',
					'help'     => '',
					'options'  => array(
						array(
							'value' => 'yes',
							'label' => esc_html__( 'Yes', 'kadence-shop-kit' ),
						),
						array(
							'value' => 'no',
							'label' => esc_html__( 'No', 'kadence-shop-kit' ),
						),
					),
				),
			)
		);

		$bundle_section->add_block(
			array(
				'id'         => 'iconic-wbp-fixed-discount',
				'blockName'  => 'woocommerce/product-text-field',
				'order'      => 13,
				'attributes' => array(
					'label'    => esc_html__( 'Fixed Discount', 'kadence-shop-kit' ),
					'property' => 'iconic_wbp_fixed_discount',
					'help'     => '',
					'type'     => array(
						'value' => 'number',
					),
				),
			)
		);

		return $template;
	}

	/**
	 * Save bundle data.
	 *
	 * @param WC_product      $product Product.
	 * @param WP_REST_Request $request Request.
	 *
	 * @return void
	 */
	public static function save_bundle_data( $product, WP_REST_Request $request ) {
		if ( ! FeaturesUtil::feature_is_enabled( 'product_block_editor' ) ) {
			return;
		}

		if ( empty( $product ) || ! is_a( $product, 'WC_Product' ) ) {
			return;
		}

		$defaults    = self::get_default_bundle_data();
		$bundle_data = get_post_meta( $product->get_id(), 'iconic-woo-bundled-products_options', true );
		$bundle_data = wp_parse_args( $bundle_data, $defaults );

		$params = array(
			'product_ids'          => $request->get_param( 'iconic_wbp_product_ids' ),
			'show_product_gallery' => $request->get_param( 'iconic_wbp_show_product_gallery' ),
			'bundle_price'         => $request->get_param( 'iconic_wbp_bundle_price' ),
			'price_display'        => $request->get_param( 'iconic_wbp_price_display' ),
			'add_all_to_cart'      => $request->get_param( 'iconic_wbp_add_all_to_cart' ),
			'hide_add_to_cart'     => $request->get_param( 'iconic_wbp_hide_add_to_cart' ),
			'hide_qty'             => $request->get_param( 'iconic_wbp_hide_qty' ),
			'hide_prices'          => $request->get_param( 'iconic_wbp_hide_prices' ),
			'fixed_discount'       => $request->get_param( 'iconic_wbp_fixed_discount' ),
		);

		$data = array();
		foreach ( $params as $key => $value ) {
			if ( array_key_exists( $key, $params ) && null !== $value ) {
				$data[ $key ] = $params[ $key ];
			} else {
				$data[ $key ] = $bundle_data[ $key ];
			}
		}

		update_post_meta( $product->get_id(), 'iconic-woo-bundled-products_options', $data );
	}


	/**
	 * Add bundled product data to the REST API response so it's available to the Product Editor.
	 *
	 * @param WP_REST_Response $response Response.
	 * @param WC_Product       $product  Product.
	 * @param WP_REST_Request  $request  Request.
	 *
	 * @return $response
	 */
	public static function add_bundle_data_to_rest_response( WP_REST_Response $response, WC_Product $product, WP_REST_Request $request ) {
		if ( ! FeaturesUtil::feature_is_enabled( 'product_block_editor' ) ) {
			return $response;
		}

		if ( 'edit' !== $request->get_param( 'context' ) ) {
			return $response;
		}

		if ( $product->get_id() !== $request->get_param( 'id' ) ) {
			return $response;
		}

		$bundle_data = get_post_meta( $product->get_id(), 'iconic-woo-bundled-products_options', true );
		$defaults    = self::get_default_bundle_data();

		foreach ( $defaults as $key => $value ) {
			$response->data[ 'iconic_wbp_' . $key ] = isset( $bundle_data[ $key ] ) ? $bundle_data[ $key ] : $defaults[ $key ];
		}

		return $response;
	}

	/**
	 * Get default data for new bundle.
	 *
	 * @return array
	 */
	public static function get_default_bundle_data() {
		return array(
			'product_ids'      => array(),
			'bundle_price'     => 0,
			'price_display'    => 'combined',
			'add_all_to_cart'  => 'no',
			'hide_add_to_cart' => 'no',
			'hide_qty'         => 'no',
			'hide_prices'      => 'no',
			'fixed_discount'   => 0,
		);
	}
}
