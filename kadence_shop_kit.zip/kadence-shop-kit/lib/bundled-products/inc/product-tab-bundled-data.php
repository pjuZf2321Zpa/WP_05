<?php
/**
 * Product tab bundled data.
 *
 * @package Iconic_Woo_Bundled_Products
 */

?>

<?php $options = get_post_meta( $post->ID, $this->product_options_name, true ); ?>

<div id="iconic_bundled_product_data" class="panel woocommerce_options_panel">

	<div class="options_group">

		<?php

		$fields = array();

		$fields[] = array(
			'type' => 'product_ids',
			'id'   => 'product_ids',
		);

		$fields[] = array(
			'type'        => 'select',
			'id'          => 'show_product_gallery',
			'label'       => __( 'Show product gallery?', 'kadence-shop-kit' ),
			'description' => __( 'By default, bundled products show only the featured product image.', 'kadence-shop-kit' ),
			'desc_tip'    => true,
			'options'     => array(
				'no'  => __( 'No', 'kadence-shop-kit' ),
				'yes' => __( 'Yes', 'kadence-shop-kit' ),
			),
		);

		$fields[] = array(
			'type'        => 'select',
			'id'          => 'price_display',
			'label'       => __( 'Price Display', 'kadence-shop-kit' ),
			'desc_tip'    => true,
			'description' => '',
			'options'     => array(
				''         => __( 'None', 'kadence-shop-kit' ),
				'combined' => __( 'Combined', 'kadence-shop-kit' ),
				'range'    => __( 'Range', 'kadence-shop-kit' ),
				'custom'   => __( 'Custom', 'kadence-shop-kit' ),
			),
		);

		$fields[] = array(
			'type'        => 'text',
			'id'          => 'bundle_price',
			// translators: %s currency symbol.
			'label'       => sprintf( __( 'Bundle Price (%s)', 'kadence-shop-kit' ), get_woocommerce_currency_symbol() ),
			'desc_tip'    => true,
			'description' => __( 'If you selected "Custom" for "Price Display", enter the total price for your bundle here. Note: this is only effective if using "Add All to Cart" button.', 'kadence-shop-kit' ),
			'data_type'   => 'price',
		);

		$fields[] = array(
			'type'    => 'select',
			'id'      => 'add_all_to_cart',
			'label'   => __( 'Enable "Add All to Cart"?', 'kadence-shop-kit' ),
			'options' => array(
				'no'  => __( 'No', 'kadence-shop-kit' ),
				'yes' => __( 'Yes', 'kadence-shop-kit' ),
			),
		);

		$fields[] = array(
			'type'    => 'select',
			'id'      => 'hide_add_to_cart',
			'label'   => __( 'Hide Individual "Add to Cart" Buttons?', 'kadence-shop-kit' ),
			'options' => array(
				'no'  => __( 'No', 'kadence-shop-kit' ),
				'yes' => __( 'Yes', 'kadence-shop-kit' ),
			),
		);

		$fields[] = array(
			'type'    => 'select',
			'id'      => 'hide_qty',
			'label'   => __( 'Hide Individual Quantity Fields?', 'kadence-shop-kit' ),
			'options' => array(
				'no'  => __( 'No', 'kadence-shop-kit' ),
				'yes' => __( 'Yes', 'kadence-shop-kit' ),
			),
		);

		$fields[] = array(
			'type'    => 'select',
			'id'      => 'hide_prices',
			'label'   => __( 'Hide Individual Prices?', 'kadence-shop-kit' ),
			'options' => array(
				'no'  => __( 'No', 'kadence-shop-kit' ),
				'yes' => __( 'Yes', 'kadence-shop-kit' ),
			),
		);

		$fields[] = array(
			'type'        => 'text',
			'id'          => 'fixed_discount',
			// translators: %s currency symbol.
			'label'       => sprintf( __( 'Fixed Discount (%s)', 'kadence-shop-kit' ), get_woocommerce_currency_symbol() ),
			'data_type'   => 'price',
			'desc_tip'    => true,
			// translators: %s currency symbol.
			'description' => sprintf( __( 'Enter an amount in %s to apply a fixed discount when all products are added to the cart.', 'kadence-shop-kit' ), get_woocommerce_currency_symbol() ),
		);

		foreach ( $fields as $field ) {
			$product_id     = sprintf( '%s_%s', $this->product_options_name, $field['id'] );
			$field['name']  = sprintf( '%s[%s]', $this->product_options_name, $field['id'] );
			$field['value'] = isset( $options[ $field['id'] ] ) ? $options[ $field['id'] ] : '';

			if ( 'text' === $field['type'] ) {
				woocommerce_wp_text_input( $field );
			} elseif ( 'select' === $field['type'] ) {
				woocommerce_wp_select( $field );
			} elseif ( 'product_ids' === $field['type'] ) {
				Iconic_WBP_Meta::product_search_feild( $field );
			}
		}
		?>

	</div>

</div>
