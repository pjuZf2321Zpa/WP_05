<?php

namespace KadenceWP\KadenceShopKit;

use KadenceWP\KadenceShopKit\lucatume\DI52\Container as DI52Container;
use KadenceWP\KadenceShopKit\StellarWP\ContainerContract\ContainerInterface;

/**
 * DI container for Kadence Shop Kit.
 *
 * Extends DI52 and implements StellarWP ContainerInterface so Harbor's
 * internal providers receive a type-compatible container instance.
 */
class Container extends DI52Container implements ContainerInterface {
}
