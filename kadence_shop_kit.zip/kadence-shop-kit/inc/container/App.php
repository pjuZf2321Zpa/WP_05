<?php
/**
 * Kadence Shop Kit App service locator class.
 *
 * @since 3.0.0
 *
 * @package KadenceWP\KadenceShopKit
 */

namespace KadenceWP\KadenceShopKit;

use KadenceWP\KadenceShopKit\lucatume\DI52\App as DI52App;

/**
 * Kadence Shop Kit App service locator class.
 *
 * @since 3.0.0
 */
class App extends DI52App {
	/**
	 * A reference to the singleton instance of the DI container
	 * the application uses as Service Locator.
	 *
	 * @since 3.0.0
	 *
	 * @phpstan-ignore-next-line -- type overridden intentionally.
	 * @var Container|null
	 */
	protected static $container;

	/**
	 * Returns the singleton instance of the DI container the application
	 * will use as Service Locator.
	 *
	 * @since 3.0.0
	 *
	 * @return Container The singleton instance of the Container used as Service Locator
	 *                   by the application.
	 */
	public static function container(): Container {
		if ( ! isset( static::$container ) ) {
			static::$container = new Container();
		}

		return static::$container;
	}

	/**
	 * Sets the container instance the Application should use as a Service Locator.
	 *
	 * @since 3.0.0
	 *
	 * @param Container $container A reference to the Container instance the Application
	 *                             should use as a Service Locator.
	 *
	 * @return void
	 */
	public static function set_container( Container $container ) {
		static::$container = $container;
	}
}
