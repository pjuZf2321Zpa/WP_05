<?php
/**
 * Kadence_Woo Extras Settings Class
 *
 * @package Kadence Woo Extras
 */

use KadenceWP\KadenceShopKit\App;
use KadenceWP\KadenceShopKit\Settings\Sub_Sections;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Main Kadence_Woo_Extras_Settings class
 */
class Kadence_Woo_Extras_Settings {
	const OPT_NAME = 'kt_woo_extras';

	/**
	 * Action on init.
	 */
	public function __construct() {
		require_once KADENCE_WOO_EXTRAS_PATH . 'inc/settings/load.php';
		// Need to load this with priority higher then 10 so class is loaded.
		add_action( 'after_setup_theme', array( $this, 'add_sections' ), 20 );
		add_filter( 'kadence_settings_enqueue_sections', array( $this, 'register_dynamic_options' ), 10, 2 );
		add_filter( 'kadence_settings_enqueue_args', array( $this, 'register_license_validation' ), 10, 2 );
	}
	/**
	 * Register settings.
	 *
	 * @param array<mixed> $sections Array of sections.
	 * @param string       $opt_name Option name.
	 *
	 * @return array<mixed> Array of sections.
	 */
	public function register_dynamic_options( $sections, $opt_name ) {
		if ( ! empty( $opt_name ) && 'kt_woo_extras' === $opt_name ) {

			if ( empty( $sections['kt_woo_extra_variation_swatches'] ) || ! is_array( $sections['kt_woo_extra_variation_swatches'] ) ) {
				return $sections;
			}

			if ( ! empty( $sections['kt_woo_extra_variation_swatches']['fields'] ) && is_array( $sections['kt_woo_extra_variation_swatches']['fields'] ) ) {
				foreach ( $sections['kt_woo_extra_variation_swatches']['fields'] as $key => $field ) {
					if ( isset( $field['id'] ) && 'variation_archive_swatches_catalog_attribute' === $field['id'] ) {
						$sections['kt_woo_extra_variation_swatches']['fields'][ $key ]['options'] = $this->get_attribute_terms();
					}
				}
			}
		}
		return $sections;
	}
	/**
	 * Register license validation.
	 *
	 * @param array<mixed> $args     Array of arguments.
	 * @param string       $opt_name Option name.
	 *
	 * @return array<mixed> Array of arguments.
	 */
	public function register_license_validation( $args, $opt_name ) {
		if ( ! empty( $opt_name ) && 'kt_woo_extras' === $opt_name ) {
			$args['licenseActive'] = lw_harbor_is_feature_available( 'kadence-shop-kit' );
			$args['licenseUrl']    = function_exists( 'lw_harbor_get_license_page_url' ) ? lw_harbor_get_license_page_url() : '';
		}
		return $args;
	}
	/**
	 * Add sections to settings.
	 *
	 * @return void
	 */
	public function add_sections() {
		if ( ! class_exists( 'Kadence_Settings_Engine' ) ) {
			return;
		}
		$sub_sections = App::container()->get( Sub_Sections::class );
		if ( ! $sub_sections instanceof Sub_Sections ) {
			return;
		}
		$shopkit_settings = get_option( 'kt_woo_extras' );
		if ( ! is_array( $shopkit_settings ) ) {
			$shopkit_settings = json_decode( $shopkit_settings, true );
		}
		$args            = array(
			'v2'                 => true,
			'opt_name'           => self::OPT_NAME,
			'menu_icon'          => 'dashicons-cart',
			'menu_title'         => __( 'Shop Kit', 'kadence-shop-kit' ),
			'page_title'         => __( 'Kadence Shop Kit', 'kadence-shop-kit' ),
			'page_slug'          => 'kadence-shop-kit-settings',
			'page_permissions'   => 'manage_options',
			'menu_type'          => 'menu',
			'page_parent'        => ( apply_filters( 'kadence_shopkit_network', false ) ? 'settings.php' : 'options-general.php' ),
			'page_priority'      => null,
			'footer_credit'      => '',
			'class'              => '',
			'admin_bar'          => false,
			'admin_bar_priority' => 999,
			'admin_bar_icon'     => '',
			'show_import_export' => false,
			'version'            => KADENCE_WOO_EXTRAS_VERSION,
			'logo'               => KADENCE_WOO_EXTRAS_URL . 'assets/kadence-logo.png',
			'changelog'          => KADENCE_WOO_EXTRAS_PATH . 'changelog.txt',
			'network_admin'      => apply_filters( 'kadence_shopkit_network', false ),
			'database'           => ( apply_filters( 'kadence_shopkit_network', false ) ? 'network' : '' ),
			'license'            => 'hidden-side-panel',
		);
		$args['tabs']    = array(
			'settings' => array(
				'id'    => 'settings',
				'title' => __( 'Settings', 'kadence-shop-kit' ),
			),
		);
		$args['sidebar'] = array(
			'docs'     => array(
				'title'       => __( 'Documentation', 'kadence-shop-kit' ),
				'description' => __( 'Need help? We have a knowledge base full of articles to get you started.', 'kadence-shop-kit' ),
				'link'        => 'https://www.kadencewp.com/help-center/knowledge-base/kadence-shop-kit/',
				'link_text'   => __( 'Browse Docs', 'kadence-shop-kit' ),
			),
			'support'  => array(
				'title'       => __( 'Support', 'kadence-shop-kit' ),
				'description' => __( 'Have a question, we are happy to help! Get in touch with our support team.', 'kadence-shop-kit' ),
				'link'        => 'https://www.kadencewp.com/premium-support-tickets/',
				'link_text'   => __( 'Submit a Ticket', 'kadence-shop-kit' ),
			),
			'facebook' => array(
				'title'       => __( 'Web Creators Community', 'kadence-shop-kit' ),
				'description' => __( 'Join our community of fellow kadence users creating effective websites! Share your site, ask a question and help others.', 'kadence-shop-kit' ),
				'link'        => 'https://www.facebook.com/groups/webcreatorcommunity',
				'link_text'   => __( 'Join our Facebook Group', 'kadence-shop-kit' ),
			),
		);
		Kadence_Settings_Engine::set_args( self::OPT_NAME, $args );
		Kadence_Settings_Engine::set_groups(
			self::OPT_NAME,
			array(
				array(
					'id'    => 'product_display',
					'title' => __( 'Product Display', 'kadence-shop-kit' ),
				),
				array(
					'id'    => 'product_variations',
					'title' => __( 'Product Variations', 'kadence-shop-kit' ),
				),
				array(
					'id'    => 'merchandising',
					'title' => __( 'Merchandising', 'kadence-shop-kit' ),
				),
				array(
					'id'    => 'conversions',
					'title' => __( 'Conversions', 'kadence-shop-kit' ),
				),
				array(
					'id'    => 'cart_checkout',
					'title' => __( 'Cart & Checkout', 'kadence-shop-kit' ),
				),
				array(
					'id'    => 'customer_accounts',
					'title' => __( 'Customer Accounts', 'kadence-shop-kit' ),
				),
			)
		);
		// Product Display — Product Templates.
		Kadence_Settings_Engine::set_section(
			self::OPT_NAME,
			array(
				'id'           => 'kt_woo_extra_product_templates',
				'title'        => __( 'Product Templates', 'kadence-shop-kit' ),
				'desc'         => __( 'Supercharge the WordPress block editor to create dynamic and attractive product layouts with Kadence Shop Kit\'s custom template builder.', 'kadence-shop-kit' ),
				'doc_url'      => 'https://links.stellarwp.com/shopkit-product-templates',
				'group'        => 'product_display',
				'illustration' => KADENCE_WOO_EXTRAS_URL . 'inc/assets/images/template-preview.svg',
				'fields'       => array(
					array(
						'id'      => 'product_templates',
						'type'    => 'switch',
						'class'   => 'ks-large-toggle',
						'title'   => __( 'Enable Product Templates', 'kadence-shop-kit' ),
						'help'    => __( 'This allows you to create custom product templates', 'kadence-shop-kit' ),
						'default' => 0,
					),
					array(
						'id'       => 'product_templates_output_info',
						'type'     => 'info',
						'title'    => __( 'Find product templates under the "Products" menu item in your admin.', 'kadence-shop-kit' ),
						'required' => array( 'product_templates', '=', '1' ),
					),
					array(
						'id'       => 'product_template_notices',
						'type'     => 'switch',
						'title'    => __( 'Add WooCommerce notices to top of single and archive templates?', 'kadence-shop-kit' ),
						'help'     => __( 'You can manually add notices using a block, but if you are using the snackbar style notices, this is a simple way to add them.', 'kadence-shop-kit' ),
						'default'  => 0,
						'required' => array( 'product_templates', '=', '1' ),
					),
				),
			)
		);
		// Product Display — Product Gallery (consolidated from gallery layout, slider, zoom & lightbox, video, variation gallery).
		if ( ! function_exists( 'is_plugin_active' ) ) {
			include_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$woothumbs_basename = defined( 'ICONIC_WOOTHUMBS_PLUGIN_PATH_FILE' )
			? ICONIC_WOOTHUMBS_PLUGIN_PATH_FILE
			: 'iconic-woothumbs/iconic-woothumbs.php';

		$gallery_section = [
			'id'           => 'kt_woo_extra_product_gallery',
			'title'        => __( 'Product Gallery', 'kadence-shop-kit' ),
			'desc'         => __( 'Design dynamic galleries that uniquely connect with customers, no matter what device they\'re using to shop. Customize your look on mobile, tablet, and desktop.', 'kadence-shop-kit' ),
			'doc_url'      => 'https://links.stellarwp.com/shopkit-product-gallery',
			'group'        => 'product_display',
			'illustration' => KADENCE_WOO_EXTRAS_URL . 'inc/assets/images/gallery-preview.svg',
			'fields'       => [
				[
					'id'      => 'product_gallery',
					'type'    => 'switch',
					'class'   => 'ks-large-toggle',
					'title'   => __( 'Enable Product Slider Gallery', 'kadence-shop-kit' ),
					'help'    => __( 'This enhances the WooCommerce product gallery with more features', 'kadence-shop-kit' ),
					'default' => 0,
				],
			],
		];

		if ( is_plugin_active( $woothumbs_basename ) ) {
			$gallery_section['notice'] = '<div class="notice notice-warning inline"><p>'
				. wp_kses(
					sprintf(
						/* translators: 1: opening <strong>, 2: closing </strong> */
						__( '%1$sWooThumbs is active.%2$s While WooThumbs is running, Shop Kit’s Product Gallery settings have no effect. WooThumbs has been merged into Shop Kit and is no longer actively maintained as a standalone product — Shop Kit covers most of its functionality.', 'kadence-shop-kit' ),
						'<strong>',
						'</strong>'
					),
					[ 'strong' => [] ]
				)
				. '</p></div>';
		}

		Kadence_Settings_Engine::set_section( self::OPT_NAME, $gallery_section );
		// Gallery Setup sub-section.
		$sub_sections->set_sub_section(
			self::OPT_NAME,
			'kt_woo_extra_product_gallery',
			array(
				'id'       => 'product_gallery_setup',
				'title'    => __( 'Gallery Setup', 'kadence-shop-kit' ),
				'desc'     => __( 'Choose your gallery layout, image dimensions, and display options. These settings control the overall look and feel of the product gallery.', 'kadence-shop-kit' ),
				'priority' => 10,
				'required' => array( 'product_gallery', '=', '1' ),
				'fields'   => array(
					array(
						'id'         => 'ga_slider_layout_wrap',
						'responsive' => true,
						'desktop'    => array(
							'id'      => 'ga_slider_layout',
							'type'    => 'image_select',
							'title'   => __( 'Choose a gallery type', 'kadence-shop-kit' ),
							'options' => array(
								array(
									'value' => 'above',
									'alt'   => 'Thumbnails Below Image',
									'img'   => KADENCE_WOO_EXTRAS_URL . 'lib/gallery/img/gallery-type-above.png',
								),
								array(
									'value' => 'below',
									'alt'   => 'Thumbnails Above Image',
									'img'   => KADENCE_WOO_EXTRAS_URL . 'lib/gallery/img/gallery-type-below.png',
								),
								array(
									'value' => 'left',
									'alt'   => 'Thumbnails beside slider on the right',
									'img'   => KADENCE_WOO_EXTRAS_URL . 'lib/gallery/img/gallery-type-left.png',
								),
								array(
									'value' => 'right',
									'alt'   => 'Thumbnails beside slider on the left',
									'img'   => KADENCE_WOO_EXTRAS_URL . 'lib/gallery/img/gallery-type-right.png',
								),
								array(
									'value' => 'list',
									'alt'   => 'No Thumbnails, Images in a list.',
									'img'   => KADENCE_WOO_EXTRAS_URL . 'lib/gallery/img/gallery-type-list.png',
								),
								array(
									'value' => 'grid',
									'alt'   => 'Images in a two column grid.',
									'img'   => KADENCE_WOO_EXTRAS_URL . 'lib/gallery/img/gallery-type-grid.png',
								),
								array(
									'value' => 'grid-3-col',
									'alt'   => 'Images in a three column grid.',
									'img'   => KADENCE_WOO_EXTRAS_URL . 'lib/gallery/img/gallery-type-grid-3-col.png',
								),
								array(
									'value' => 'tiles',
									'alt'   => 'Images in a tiles layout.',
									'img'   => KADENCE_WOO_EXTRAS_URL . 'lib/gallery/img/gallery-type-tiles.png',
								),
								array(
									'value' => 'grid-highlighted',
									'alt'   => 'Images in a two column grid, first image full width.',
									'img'   => KADENCE_WOO_EXTRAS_URL . 'lib/gallery/img/gallery-type-grid-highlighted.png',
								),
								array(
									'value' => 'grid-3-col-highlighted',
									'alt'   => 'Images in a three column grid, first image full width.',
									'img'   => KADENCE_WOO_EXTRAS_URL . 'lib/gallery/img/gallery-type-grid-3-col-highlighted.png',
								),
								array(
									'value' => 'slider',
									'alt'   => 'Images in a slider layout, no thumbnails.',
									'img'   => KADENCE_WOO_EXTRAS_URL . 'lib/gallery/img/gallery-type-slider.png',
								),
							),
							'default' => 'above',
						),
						'tablet'     => array(
							'id'      => 'ga_slider_layout_tablet',
							'type'    => 'image_select',
							'title'   => __( 'Choose a gallery type', 'kadence-shop-kit' ),
							'options' => array(
								array(
									'value' => 'above',
									'alt'   => 'Thumbnails Below Image',
									'img'   => KADENCE_WOO_EXTRAS_URL . 'lib/gallery/img/gallery-type-above.png',
								),
								array(
									'value' => 'below',
									'alt'   => 'Thumbnails Above Image',
									'img'   => KADENCE_WOO_EXTRAS_URL . 'lib/gallery/img/gallery-type-above.png',
								),
								array(
									'value' => 'left',
									'alt'   => 'Thumbnails beside slider on the right',
									'img'   => KADENCE_WOO_EXTRAS_URL . 'lib/gallery/img/gallery-type-left.png',
								),
								array(
									'value' => 'right',
									'alt'   => 'Thumbnails beside slider on the left',
									'img'   => KADENCE_WOO_EXTRAS_URL . 'lib/gallery/img/gallery-type-right.png',
								),
								array(
									'value' => 'list',
									'alt'   => 'No Thumbnails, Images in a list.',
									'img'   => KADENCE_WOO_EXTRAS_URL . 'lib/gallery/img/gallery-type-list.png',
								),
								array(
									'value' => 'grid',
									'alt'   => 'Images in a two column grid.',
									'img'   => KADENCE_WOO_EXTRAS_URL . 'lib/gallery/img/gallery-type-grid.png',
								),
								array(
									'value' => 'grid-3-col',
									'alt'   => 'Images in a three column grid.',
									'img'   => KADENCE_WOO_EXTRAS_URL . 'lib/gallery/img/gallery-type-grid-3-col.png',
								),
								array(
									'value' => 'tiles',
									'alt'   => 'Images in a tiles layout.',
									'img'   => KADENCE_WOO_EXTRAS_URL . 'lib/gallery/img/gallery-type-tiles.png',
								),
								array(
									'value' => 'grid-highlighted',
									'alt'   => 'Images in a two column grid, first image full width.',
									'img'   => KADENCE_WOO_EXTRAS_URL . 'lib/gallery/img/gallery-type-grid-highlighted.png',
								),
								array(
									'value' => 'grid-3-col-highlighted',
									'alt'   => 'Images in a three column grid, first image full width.',
									'img'   => KADENCE_WOO_EXTRAS_URL . 'lib/gallery/img/gallery-type-grid-3-col-highlighted.png',
								),
								array(
									'value' => 'slider',
									'alt'   => 'Images in a slider layout, no thumbnails.',
									'img'   => KADENCE_WOO_EXTRAS_URL . 'lib/gallery/img/gallery-type-slider.png',
								),
							),
							'default' => '',
						),
						'mobile'     => array(
							'id'      => 'ga_slider_layout_mobile',
							'type'    => 'image_select',
							'title'   => __( 'Choose a gallery type', 'kadence-shop-kit' ),
							'options' => array(
								array(
									'value' => 'above',
									'alt'   => 'Thumbnails Below Image',
									'img'   => KADENCE_WOO_EXTRAS_URL . '/lib/gallery/img/gallery-type-above.png',
								),
								array(
									'value' => 'below',
									'alt'   => 'Thumbnails Above Image',
									'img'   => KADENCE_WOO_EXTRAS_URL . '/lib/gallery/img/gallery-type-above.png',
								),
								array(
									'value' => 'left',
									'alt'   => 'Thumbnails beside slider on the left',
									'img'   => KADENCE_WOO_EXTRAS_URL . '/lib/gallery/img/gallery-type-left.png',
								),
								array(
									'value' => 'right',
									'alt'   => 'Thumbnails beside slider on the right',
									'img'   => KADENCE_WOO_EXTRAS_URL . '/lib/gallery/img/gallery-type-right.png',
								),
								array(
									'value' => 'list',
									'alt'   => 'No Thumbnails, Images in a list.',
									'img'   => KADENCE_WOO_EXTRAS_URL . 'lib/gallery/img/gallery-type-list.png',
								),
								array(
									'value' => 'grid',
									'alt'   => 'Images in a two column grid.',
									'img'   => KADENCE_WOO_EXTRAS_URL . 'lib/gallery/img/gallery-type-grid.png',
								),
								array(
									'value' => 'grid-3-col',
									'alt'   => 'Images in a three column grid.',
									'img'   => KADENCE_WOO_EXTRAS_URL . 'lib/gallery/img/gallery-type-grid-3-col.png',
								),
								array(
									'value' => 'tiles',
									'alt'   => 'Images in a tiles layout.',
									'img'   => KADENCE_WOO_EXTRAS_URL . 'lib/gallery/img/gallery-type-tiles.png',
								),
								array(
									'value' => 'grid-highlighted',
									'alt'   => 'Images in a two column grid, first image full width.',
									'img'   => KADENCE_WOO_EXTRAS_URL . 'lib/gallery/img/gallery-type-grid-highlighted.png',
								),
								array(
									'value' => 'grid-3-col-highlighted',
									'alt'   => 'Images in a three column grid, first image full width.',
									'img'   => KADENCE_WOO_EXTRAS_URL . 'lib/gallery/img/gallery-type-grid-3-col-highlighted.png',
								),
								array(
									'value' => 'slider',
									'alt'   => 'Images in a slider layout, no thumbnails.',
									'img'   => KADENCE_WOO_EXTRAS_URL . 'lib/gallery/img/gallery-type-slider.png',
								),
							),
							'default' => '',
						),
						'required'   => array( 'product_gallery', '=', '1' ),
					),
					array(
						'id'       => 'product_gallery_custom_size',
						'type'     => 'switch',
						'title'    => __( 'Enable Custom Size for Gallery Images', 'kadence-shop-kit' ),
						'help'     => __( 'This enables options to set custom image sizes for the product gallery.', 'kadence-shop-kit' ),
						'default'  => 0,
						'required' => array( 'product_gallery', '=', '1' ),
					),
					array(
						'id'       => 'ga_image_width',
						'type'     => 'range',
						'title'    => __( 'Product image width', 'kadence-shop-kit' ),
						'default'  => '465',
						'min'      => '200',
						'step'     => '1',
						'max'      => '2000',
						'required' => array(
							array( 'product_gallery', '=', '1' ),
							array( 'product_gallery_custom_size', '=', '1' ),
						),
					),
					array(
						'id'       => 'ga_image_ratio',
						'type'     => 'select',
						'title'    => __( 'Product image ratio', 'kadence-shop-kit' ),
						'options'  => array(
							'square'        => __( 'Square 1:1', 'kadence-shop-kit' ),
							'portrait'      => __( 'Portrait 3:4', 'kadence-shop-kit' ),
							'landscape'     => __( 'Landscape 4:3', 'kadence-shop-kit' ),
							'landscape32'   => __( 'Landscape 3:2', 'kadence-shop-kit' ),
							'landscape169'  => __( 'Landscape 16:9', 'kadence-shop-kit' ),
							'widelandscape' => __( 'Wide Landscape 4:2', 'kadence-shop-kit' ),
							'custom'        => __( 'Custom', 'kadence-shop-kit' ),
						),
						'default'  => 'square',
						'required' => array(
							array( 'product_gallery', '=', '1' ),
							array( 'product_gallery_custom_size', '=', '1' ),
						),
					),
					array(
						'id'         => 'ga_image_height',
						'type'       => 'range',
						'title'      => __( 'Product image Height', 'kadence-shop-kit' ),
						'default'    => '465',
						'min'        => '200',
						'customizer' => false,
						'step'       => '1',
						'max'        => '1200',
						'required'   => array(
							array( 'product_gallery', '=', '1' ),
							array( 'product_gallery_custom_size', '=', '1' ),
							array( 'ga_image_ratio', '=', 'custom' ),
						),
					),
					array(
						'id'       => 'ga_large_image_size',
						'type'     => 'select',
						'title'    => __( 'Large Image Size', 'kadence-shop-kit' ),
						'help'     => __( 'Choose the image size used for hover zoom and the fullscreen lightbox.', 'kadence-shop-kit' ),
						'options'  => array(
							'full'                  => __( 'Full', 'kadence-shop-kit' ),
							'large'                 => __( 'Large', 'kadence-shop-kit' ),
							'medium_large'          => __( 'Medium Large', 'kadence-shop-kit' ),
							'medium'                => __( 'Medium', 'kadence-shop-kit' ),
							'woocommerce_single'    => __( 'WooCommerce Single', 'kadence-shop-kit' ),
							'woocommerce_thumbnail' => __( 'WooCommerce Thumbnail', 'kadence-shop-kit' ),
							'woocommerce_gallery_thumbnail' => __( 'WooCommerce Gallery Thumbnail', 'kadence-shop-kit' ),
						),
						'default'  => 'full',
						'required' => array( 'product_gallery', '=', '1' ),
					),
					array(
						'id'       => 'ga_maintain_gallery',
						'type'     => 'select',
						'title'    => __( 'Use Gallery Images for Variations and Attributes?', 'kadence-shop-kit' ),
						'help'     => __( 'When enabled, the parent variable product image gallery will be added to its product variations and attributes.', 'kadence-shop-kit' ),
						'options'  => array(
							'0' => __( 'No', 'kadence-shop-kit' ),
							'1' => __( 'Yes', 'kadence-shop-kit' ),
							'2' => __( 'Only if variation has no gallery images', 'kadence-shop-kit' ),
						),
						'default'  => '0',
						'required' => array( 'product_gallery', '=', '1' ),
					),
					array(
						'id'       => 'ga_ui_foreground_colour',
						'type'     => 'color',
						'title'    => __( 'UI Foreground Colour', 'kadence-shop-kit' ),
						'help'     => __( 'Choose a colour mainly used as a foreground colour for icons in the gallery. Does not apply to the fullscreen gallery.', 'kadence-shop-kit' ),
						'default'  => '#ffffff',
						'required' => array( 'product_gallery', '=', '1' ),
					),
					array(
						'id'       => 'ga_ui_background_colour',
						'type'     => 'color',
						'title'    => __( 'UI Background Colour', 'kadence-shop-kit' ),
						'help'     => __( 'Choose a colour mainly used as a background colour for icons in the gallery. Does not apply to the fullscreen gallery.', 'kadence-shop-kit' ),
						'default'  => '#111111',
						'required' => array( 'product_gallery', '=', '1' ),
					),
					array(
						'id'       => 'ga_icons_hover',
						'type'     => 'switch',
						'title'    => __( 'Show Icons on Hover?', 'kadence-shop-kit' ),
						'help'     => __( 'When enabled, icons will only be visible when the image is hovered.', 'kadence-shop-kit' ),
						'default'  => 0,
						'required' => array( 'product_gallery', '=', '1' ),
					),
					array(
						'id'       => 'ga_icons_tooltips',
						'type'     => 'switch',
						'title'    => __( 'Show Icon Tooltips?', 'kadence-shop-kit' ),
						'help'     => __( 'When icons are hovered, a tooltip will be displayed.', 'kadence-shop-kit' ),
						'default'  => 0,
						'required' => array( 'product_gallery', '=', '1' ),
					),
					array(
						'id'       => 'ga_shortcode_option',
						'type'     => 'switch',
						'title'    => __( 'Enable meta area for shortcode override', 'kadence-shop-kit' ),
						'help'     => __( 'This adds a metabox area in each product allowing you to override the gallery with a shortcode or html content.', 'kadence-shop-kit' ),
						'default'  => 0,
						'required' => array( 'product_gallery', '=', '1' ),
					),
				),
			)
		);
		// Slider sub-section.
		$sub_sections->set_sub_section(
			self::OPT_NAME,
			'kt_woo_extra_product_gallery',
			array(
				'id'       => 'product_gallery_slider',
				'title'    => __( 'Slider', 'kadence-shop-kit' ),
				'desc'     => __( 'Control how images transition between slides, including speed, autoplay, looping, and swipe behaviour.', 'kadence-shop-kit' ),
				'priority' => 20,
				'required' => array( 'product_gallery', '=', '1' ),
				'fields'   => array(
					array(
						'id'       => 'ga_trans_type',
						'type'     => 'select',
						'title'    => __( 'Slider transition', 'kadence-shop-kit' ),
						'options'  => array(
							'false' => __( 'Slide', 'kadence-shop-kit' ),
							'true'  => __( 'Fade', 'kadence-shop-kit' ),
						),
						'default'  => 'false',
						'required' => array( 'product_gallery', '=', '1' ),
					),
					array(
						'id'       => 'ga_slider_transtime',
						'type'     => 'range',
						'title'    => __( 'Slider transition speed', 'kadence-shop-kit' ),
						'help'     => __( 'How long the transition takes, in milliseconds.', 'kadence-shop-kit' ),
						'default'  => '500',
						'min'      => '100',
						'step'     => '100',
						'max'      => '4000',
						'required' => array( 'product_gallery', '=', '1' ),
					),
					array(
						'id'       => 'ga_slider_autoplay',
						'type'     => 'select',
						'title'    => __( 'Slider auto play', 'kadence-shop-kit' ),
						'options'  => array(
							'false' => __( 'False', 'kadence-shop-kit' ),
							'true'  => __( 'True', 'kadence-shop-kit' ),
						),
						'default'  => 'false',
						'required' => array(
							array( 'product_gallery', '=', '1' ),
							array( 'ga_slider_layout', '!=', 'grid' ),
							array( 'ga_slider_layout', '!=', 'tiles' ),
							array( 'ga_slider_layout', '!=', 'list' ),
							array( 'ga_slider_layout', '!=', 'grid-3-col' ),
							array( 'ga_slider_layout', '!=', 'grid-highlighted' ),
							array( 'ga_slider_layout', '!=', 'grid-3-col-highlighted' ),
						),
					),
					array(
						'id'       => 'ga_slider_pausetime',
						'type'     => 'range',
						'title'    => __( 'Slider pause time', 'kadence-shop-kit' ),
						'help'     => __( 'How long to pause on each slide, in milliseconds.', 'kadence-shop-kit' ),
						'default'  => '7000',
						'min'      => '3000',
						'step'     => '1000',
						'max'      => '12000',
						'required' => array(
							array( 'product_gallery', '=', '1' ),
						),
					),
					array(
						'id'       => 'ga_slider_swipe_threshold',
						'type'     => 'range',
						'title'    => __( 'Main Slider Touch Threshold', 'kadence-shop-kit' ),
						'help'     => __( 'A bigger number means less swipe length is needed to advance the slider.', 'kadence-shop-kit' ),
						'default'  => '5',
						'min'      => '1',
						'step'     => '1',
						'max'      => '20',
						'required' => array(
							array( 'product_gallery', '=', '1' ),
							array( 'ga_slider_layout', '!=', 'grid' ),
							array( 'ga_slider_layout', '!=', 'tiles' ),
							array( 'ga_slider_layout', '!=', 'list' ),
							array( 'ga_slider_layout', '!=', 'grid-3-col' ),
							array( 'ga_slider_layout', '!=', 'grid-highlighted' ),
							array( 'ga_slider_layout', '!=', 'grid-3-col-highlighted' ),
						),
					),
					array(
						'id'       => 'ga_slider_auto_height',
						'title'    => __( 'Adjust height to each photo?', 'kadence-shop-kit' ),
						'type'     => 'switch',
						'default'  => 0,
						'required' => array(
							array( 'product_gallery', '=', '1' ),
							array( 'ga_slider_layout', '!=', 'grid' ),
							array( 'ga_slider_layout', '!=', 'tiles' ),
							array( 'ga_slider_layout', '!=', 'list' ),
							array( 'ga_slider_layout', '!=', 'grid-3-col' ),
							array( 'ga_slider_layout', '!=', 'grid-highlighted' ),
							array( 'ga_slider_layout', '!=', 'grid-3-col-highlighted' ),
							array( 'ga_slider_layout', '!=', 'left' ),
							array( 'ga_slider_layout', '!=', 'right' ),
						),
					),
					array(
						'id'       => 'ga_slider_auto_height_info',
						'title'    => __( 'Warning! Using adjust height with autoplay is not recommended, on mobile devices this will cause your content to move up and down when slides change.', 'kadence-shop-kit' ),
						'type'     => 'info',
						'required' => array(
							array( 'product_gallery', '=', '1' ),
							array( 'ga_slider_auto_height', '=', '1' ),
							array( 'ga_slider_autoplay', '=', 'True' ),
							array( 'ga_slider_layout', '!=', 'grid' ),
							array( 'ga_slider_layout', '!=', 'tiles' ),
							array( 'ga_slider_layout', '!=', 'list' ),
							array( 'ga_slider_layout', '!=', 'grid-3-col' ),
							array( 'ga_slider_layout', '!=', 'grid-highlighted' ),
							array( 'ga_slider_layout', '!=', 'grid-3-col-highlighted' ),
							array( 'ga_slider_layout', '!=', 'left' ),
							array( 'ga_slider_layout', '!=', 'right' ),
						),
					),
					array(
						'id'       => 'ga_slider_loop',
						'type'     => 'switch',
						'title'    => __( 'Enable Infinite Loop?', 'kadence-shop-kit' ),
						'help'     => __( 'When you reach the last image, loop back to the first.', 'kadence-shop-kit' ),
						'default'  => 1,
						'required' => array(
							array( 'product_gallery', '=', '1' ),
							array( 'ga_slider_layout', '!=', 'grid' ),
							array( 'ga_slider_layout', '!=', 'tiles' ),
							array( 'ga_slider_layout', '!=', 'list' ),
							array( 'ga_slider_layout', '!=', 'grid-3-col' ),
							array( 'ga_slider_layout', '!=', 'grid-highlighted' ),
							array( 'ga_slider_layout', '!=', 'grid-3-col-highlighted' ),
						),
					),
					array(
						'id'       => 'ga_slider_maintain_index',
						'type'     => 'switch',
						'title'    => __( 'Maintain Slide Index?', 'kadence-shop-kit' ),
						'help'     => __( 'When enabled, the current slide position is preserved when switching product variations. For example, if the second image is active and you change variation, the second image of the new set will be shown.', 'kadence-shop-kit' ),
						'default'  => 0,
						'required' => array(
							array( 'product_gallery', '=', '1' ),
							array( 'ga_slider_layout', '!=', 'grid' ),
							array( 'ga_slider_layout', '!=', 'tiles' ),
							array( 'ga_slider_layout', '!=', 'list' ),
							array( 'ga_slider_layout', '!=', 'grid-3-col' ),
							array( 'ga_slider_layout', '!=', 'grid-highlighted' ),
							array( 'ga_slider_layout', '!=', 'grid-3-col-highlighted' ),
						),
					),
					array(
						'id'       => 'ga_slider_swipe_threshold',
						'type'     => 'range',
						'title'    => __( 'Main Slider Touch Threshold', 'kadence-shop-kit' ),
						'help'     => __( 'A bigger number means less swipe length is needed to advance the slider.', 'kadence-shop-kit' ),
						'default'  => '5',
						'min'      => '1',
						'step'     => '1',
						'max'      => '20',
						'required' => array(
							array( 'product_gallery', '=', '1' ),
							array( 'ga_slider_layout', '!=', 'grid' ),
							array( 'ga_slider_layout', '!=', 'tiles' ),
							array( 'ga_slider_layout', '!=', 'list' ),
							array( 'ga_slider_layout', '!=', 'grid-3-col' ),
							array( 'ga_slider_layout', '!=', 'grid-highlighted' ),
							array( 'ga_slider_layout', '!=', 'grid-3-col-highlighted' ),
						),
					),
					array(
						'id'       => 'ga_slider_lazyload',
						'type'     => 'select',
						'title'    => __( 'Lazyload Mode', 'kadence-shop-kit' ),
						'help'     => __( 'In Anticipated mode, the next and previous images load before you switch to them. In On Demand mode, images load only when you switch to them. In both modes, the initial gallery and thumbnail images always load right away.', 'kadence-shop-kit' ),
						'options'  => array(
							'anticipated' => __( 'Anticipated', 'kadence-shop-kit' ),
							'ondemand'    => __( 'On Demand', 'kadence-shop-kit' ),
						),
						'default'  => 'anticipated',
						'required' => array(
							array( 'product_gallery', '=', '1' ),
							array( 'ga_slider_layout', '!=', 'grid' ),
							array( 'ga_slider_layout', '!=', 'tiles' ),
							array( 'ga_slider_layout', '!=', 'list' ),
							array( 'ga_slider_layout', '!=', 'grid-3-col' ),
							array( 'ga_slider_layout', '!=', 'grid-highlighted' ),
							array( 'ga_slider_layout', '!=', 'grid-3-col-highlighted' ),
						),
					),
					array(
						'id'       => 'ga_slider_arrows',
						'type'     => 'select',
						'title'    => __( 'Show slide arrows on product image?', 'kadence-shop-kit' ),
						'options'  => array(
							'false' => __( 'False', 'kadence-shop-kit' ),
							'true'  => __( 'True', 'kadence-shop-kit' ),
						),
						'default'  => 'false',
						'required' => array(
							array( 'product_gallery', '=', '1' ),
							array( 'ga_zoom', '!=', '1' ),
							array( 'ga_slider_layout', '!=', 'grid' ),
							array( 'ga_slider_layout', '!=', 'tiles' ),
							array( 'ga_slider_layout', '!=', 'list' ),
							array( 'ga_slider_layout', '!=', 'grid-3-col' ),
							array( 'ga_slider_layout', '!=', 'grid-highlighted' ),
							array( 'ga_slider_layout', '!=', 'grid-3-col-highlighted' ),
						),
					),
				),
			)
		);
		// Thumbnails sub-section.
		$sub_sections->set_sub_section(
			self::OPT_NAME,
			'kt_woo_extra_product_gallery',
			array(
				'id'       => 'product_gallery_thumbnails',
				'title'    => __( 'Thumbnails', 'kadence-shop-kit' ),
				'desc'     => __( 'Configure the thumbnail strip — column count, sizing, spacing, hover selection, and navigation controls.', 'kadence-shop-kit' ),
				'priority' => 30,
				'required' => array( 'product_gallery', '=', '1' ),
				'fields'   => array(
					array(
						'id'       => 'ga_thumb_controls',
						'type'     => 'switch',
						'title'    => __( 'Enable Thumbnail Controls?', 'kadence-shop-kit' ),
						'help'     => __( 'When using sliding thumbnails, show prev/next controls on the thumbnail strip.', 'kadence-shop-kit' ),
						'default'  => 1,
						'required' => array(
							array( 'product_gallery', '=', '1' ),
							array( 'ga_slider_layout', '!=', 'grid' ),
							array( 'ga_slider_layout', '!=', 'tiles' ),
							array( 'ga_slider_layout', '!=', 'list' ),
							array( 'ga_slider_layout', '!=', 'grid-3-col' ),
							array( 'ga_slider_layout', '!=', 'grid-highlighted' ),
							array( 'ga_slider_layout', '!=', 'grid-3-col-highlighted' ),
							array( 'ga_slider_layout', '!=', 'slider' ),
						),
					),
					array(
						'id'       => 'ga_thumb_hover',
						'type'     => 'switch',
						'title'    => __( 'Enable thumbnail hover selection.', 'kadence-shop-kit' ),
						'help'     => __( 'This changes the main image when you hover over a thumbnail image.', 'kadence-shop-kit' ),
						'default'  => 0,
						'required' => array( 'product_gallery', '=', '1' ),
					),
					array(
						'id'         => 'ga_thumb_vertical_width_wrap',
						'responsive' => true,
						'required'   => array(
							array( 'product_gallery', '=', '1' ),
							array( 'ga_slider_layout', '!=', 'above' ),
							array( 'ga_slider_layout', '!=', 'grid' ),
							array( 'ga_slider_layout', '!=', 'tiles' ),
							array( 'ga_slider_layout', '!=', 'list' ),
							array( 'ga_slider_layout', '!=', 'grid-3-col' ),
							array( 'ga_slider_layout', '!=', 'grid-highlighted' ),
							array( 'ga_slider_layout', '!=', 'grid-3-col-highlighted' ),
							array( 'ga_slider_layout', '!=', 'slider' ),
						),
						'desktop'    => array(
							'id'      => 'ga_thumb_width',
							'type'    => 'range',
							'title'   => __( 'Thumbnail Width %', 'kadence-shop-kit' ),
							'default' => '20',
							'min'     => '2',
							'step'    => '1',
							'max'     => '80',
						),
						'tablet'     => array(
							'id'      => 'ga_thumb_width_tablet',
							'type'    => 'range',
							'title'   => __( 'Thumbnail Width %', 'kadence-shop-kit' ),
							'default' => '',
							'min'     => '2',
							'step'    => '1',
							'max'     => '80',
						),
						'mobile'     => array(
							'id'      => 'ga_thumb_width_mobile',
							'type'    => 'range',
							'title'   => __( 'Thumbnail Width %', 'kadence-shop-kit' ),
							'default' => '',
							'min'     => '2',
							'step'    => '1',
							'max'     => '80',
						),
					),
					array(
						'id'         => 'ga_thumb_columns_wrap',
						'responsive' => true,
						'required'   => array(
							array( 'product_gallery', '=', '1' ),
							array( 'ga_slider_layout', '!=', 'grid' ),
							array( 'ga_slider_layout', '!=', 'tiles' ),
							array( 'ga_slider_layout', '!=', 'list' ),
							array( 'ga_slider_layout', '!=', 'grid-3-col' ),
							array( 'ga_slider_layout', '!=', 'grid-highlighted' ),
							array( 'ga_slider_layout', '!=', 'grid-3-col-highlighted' ),
							array( 'ga_slider_layout', '!=', 'slider' ),
						),
						'desktop'    => array(
							'id'      => 'ga_thumb_columns',
							'type'    => 'range',
							'title'   => __( 'Select how many thumbnail columns are visible at a time', 'kadence-shop-kit' ),
							'default' => '6',
							'min'     => '2',
							'step'    => '1',
							'max'     => '10',
						),
						'tablet'     => array(
							'id'      => 'ga_thumb_columns_tablet',
							'type'    => 'range',
							'title'   => __( 'Select how many thumbnail columns are visible at a time', 'kadence-shop-kit' ),
							'default' => '',
							'min'     => '2',
							'step'    => '1',
							'max'     => '10',
						),
						'mobile'     => array(
							'id'      => 'ga_thumb_columns_mobile',
							'type'    => 'range',
							'title'   => __( 'Select how many thumbnail columns are visible at a time', 'kadence-shop-kit' ),
							'default' => '',
							'min'     => '1',
							'step'    => '1',
							'max'     => '10',
						),
					),
					array(
						'id'       => 'ga_thumb_image_ratio',
						'type'     => 'select',
						'title'    => __( 'Product thumbnail image ratio', 'kadence-shop-kit' ),
						'options'  => array(
							'square'        => __( 'Square 1:1', 'kadence-shop-kit' ),
							'portrait'      => __( 'Portrait 3:4', 'kadence-shop-kit' ),
							'landscape'     => __( 'Landscape 4:3', 'kadence-shop-kit' ),
							'landscape32'   => __( 'Landscape 3:2', 'kadence-shop-kit' ),
							'landscape169'  => __( 'Landscape 16:9', 'kadence-shop-kit' ),
							'widelandscape' => __( 'Wide Landscape 4:2', 'kadence-shop-kit' ),
							'inherit'       => __( 'Inherit from image', 'kadence-shop-kit' ),
						),
						'default'  => 'square',
						'required' => array(
							array( 'product_gallery', '=', '1' ),
							array( 'ga_slider_layout', '=', 'above' ),
						),
					),
					array(
						'id'       => 'ga_thumb_trans_speed',
						'type'     => 'range',
						'title'    => __( 'Thumbnail transition speed', 'kadence-shop-kit' ),
						'help'     => __( 'The speed at which the thumbnail navigation scrolls, in milliseconds.', 'kadence-shop-kit' ),
						'default'  => '250',
						'min'      => '100',
						'step'     => '50',
						'max'      => '2000',
						'required' => array(
							array( 'product_gallery', '=', '1' ),
							array( 'ga_slider_layout', '!=', 'grid' ),
							array( 'ga_slider_layout', '!=', 'tiles' ),
							array( 'ga_slider_layout', '!=', 'list' ),
							array( 'ga_slider_layout', '!=', 'grid-3-col' ),
							array( 'ga_slider_layout', '!=', 'grid-highlighted' ),
							array( 'ga_slider_layout', '!=', 'grid-3-col-highlighted' ),
							array( 'ga_slider_layout', '!=', 'slider' ),
						),
					),
					array(
						'id'       => 'ga_thumb_spacing',
						'type'     => 'range',
						'title'    => __( 'Thumbnail spacing (px)', 'kadence-shop-kit' ),
						'help'     => __( 'The gap between each thumbnail image.', 'kadence-shop-kit' ),
						'default'  => '4',
						'min'      => '0',
						'step'     => '1',
						'max'      => '60',
						'required' => array(
							array( 'product_gallery', '=', '1' ),
							array( 'ga_slider_layout', '!=', 'grid' ),
							array( 'ga_slider_layout', '!=', 'tiles' ),
							array( 'ga_slider_layout', '!=', 'list' ),
							array( 'ga_slider_layout', '!=', 'grid-3-col' ),
							array( 'ga_slider_layout', '!=', 'grid-highlighted' ),
							array( 'ga_slider_layout', '!=', 'grid-3-col-highlighted' ),
							array( 'ga_slider_layout', '!=', 'slider' ),
						),
					),
					array(
						'id'       => 'ga_slider_pagination',
						'type'     => 'switch',
						'title'    => __( 'Enable Bullet Pagination?', 'kadence-shop-kit' ),
						'help'     => __( 'When enabled, dot/bullet navigation will be shown below the main slider image.', 'kadence-shop-kit' ),
						'default'  => 0,
						'required' => array(
							array( 'product_gallery', '=', '1' ),
							array( 'ga_slider_layout', '!=', 'grid' ),
							array( 'ga_slider_layout', '!=', 'tiles' ),
							array( 'ga_slider_layout', '!=', 'list' ),
							array( 'ga_slider_layout', '!=', 'grid-3-col' ),
							array( 'ga_slider_layout', '!=', 'grid-highlighted' ),
							array( 'ga_slider_layout', '!=', 'grid-3-col-highlighted' ),
						),
					),
					// Zoom & Lightbox fields.
					array(
						'id'       => 'ga_zoom',
						'type'     => 'switch',
						'title'    => __( 'Enable Product Image Hover Zoom', 'kadence-shop-kit' ),
						'help'     => __( 'This allows you to magnify product images without having to click to a lightbox. Note that slider arrows do not show with zoom on.', 'kadence-shop-kit' ),
						'default'  => 0,
						'required' => array( 'product_gallery', '=', '1' ),
					),
					array(
						'id'       => 'ga_zoom_type',
						'type'     => 'select',
						'title'    => __( 'Zoom type', 'kadence-shop-kit' ),
						'options'  => array(
							'inner'  => __( 'Inner', 'kadence-shop-kit' ),
							'window' => __( 'Outside', 'kadence-shop-kit' ),
							'follow' => __( 'Follow', 'kadence-shop-kit' ),
						),
						'default'  => 'window',
						'required' => array(
							array( 'product_gallery', '=', '1' ),
							array( 'ga_zoom', '=', '1' ),
						),
					),
					array(
						'id'       => 'ga_zoom_lens_width',
						'type'     => 'range',
						'title'    => __( 'Zoom Lens Width (px)', 'kadence-shop-kit' ),
						'min'      => 50,
						'max'      => 600,
						'default'  => 200,
						'required' => array(
							array( 'product_gallery', '=', '1' ),
							array( 'ga_zoom', '=', '1' ),
						),
					),
					array(
						'id'       => 'ga_zoom_lens_height',
						'type'     => 'range',
						'title'    => __( 'Zoom Lens Height (px)', 'kadence-shop-kit' ),
						'min'      => 50,
						'max'      => 600,
						'default'  => 200,
						'required' => array(
							array( 'product_gallery', '=', '1' ),
							array( 'ga_zoom', '=', '1' ),
						),
					),
					array(
						'id'       => 'ga_zoom_position',
						'type'     => 'select',
						'title'    => __( 'Zoom Viewer Position', 'kadence-shop-kit' ),
						'options'  => array(
							'right' => __( 'Right', 'kadence-shop-kit' ),
							'left'  => __( 'Left', 'kadence-shop-kit' ),
						),
						'default'  => 'right',
						'required' => array(
							array( 'product_gallery', '=', '1' ),
							array( 'ga_zoom', '=', '1' ),
						),
					),
					array(
						'id'       => 'ga_zoom_lens_colour',
						'type'     => 'color',
						'title'    => __( 'Zoom Lens Overlay Colour', 'kadence-shop-kit' ),
						'default'  => '#000000',
						'required' => array(
							array( 'product_gallery', '=', '1' ),
							array( 'ga_zoom', '=', '1' ),
						),
					),
					array(
						'id'       => 'ga_zoom_lens_opacity',
						'type'     => 'range',
						'title'    => __( 'Zoom Lens Overlay Opacity', 'kadence-shop-kit' ),
						'min'      => 0,
						'max'      => 1,
						'step'     => 0.05,
						'default'  => 0.8,
						'required' => array(
							array( 'product_gallery', '=', '1' ),
							array( 'ga_zoom', '=', '1' ),
						),
					),
					array(
						'id'       => 'ga_zoom_shape',
						'type'     => 'select',
						'title'    => __( 'Follow Zoom Shape', 'kadence-shop-kit' ),
						'options'  => array(
							'circular' => __( 'Circular', 'kadence-shop-kit' ),
							'square'   => __( 'Square', 'kadence-shop-kit' ),
						),
						'default'  => 'circular',
						'required' => array(
							array( 'product_gallery', '=', '1' ),
							array( 'ga_zoom', '=', '1' ),
						),
					),
				),
			)
		);
		// Lightbox sub-section.
		$sub_sections->set_sub_section(
			self::OPT_NAME,
			'kt_woo_extra_product_gallery',
			array(
				'id'       => 'product_gallery_lightbox',
				'title'    => __( 'Lightbox', 'kadence-shop-kit' ),
				'desc'     => __( 'Enable a fullscreen lightbox so shoppers can view product images in detail, with options for style and caption display.', 'kadence-shop-kit' ),
				'priority' => 50,
				'required' => array( 'product_gallery', '=', '1' ),
				'fields'   => array(
					array(
						'id'       => 'product_gallery_lightbox',
						'type'     => 'switch',
						'title'    => __( 'Enable Lightbox', 'kadence-shop-kit' ),
						'help'     => __( 'This allows users to open a lightbox of your product images on click', 'kadence-shop-kit' ),
						'default'  => 1,
						'required' => array( 'product_gallery', '=', '1' ),
					),
					array(
						'id'       => 'ga_lightbox_click_anywhere',
						'type'     => 'switch',
						'title'    => __( 'Enable Click Anywhere to Open Lightbox', 'kadence-shop-kit' ),
						'help'     => __( 'When enabled, clicking anywhere on the product image opens the lightbox. When disabled, the lightbox can only be opened by clicking on the fullscreen button.', 'kadence-shop-kit' ),
						'default'  => 1,
						'required' => array(
							array( 'product_gallery', '=', '1' ),
							array( 'product_gallery_lightbox', '=', '1' ),
						),
					),
					array(
						'id'       => 'ga_lightbox_skin',
						'type'     => 'select',
						'title'    => __( 'Lightbox Style', 'kadence-shop-kit' ),
						'options'  => array(
							'dark'  => __( 'Dark', 'kadence-shop-kit' ),
							'light' => __( 'Light', 'kadence-shop-kit' ),
						),
						'default'  => 'false',
						'required' => array(
							array( 'product_gallery', '=', '1' ),
							array( 'ga_zoom', '!=', '1' ),
							array( 'ga_slider_layout', '!=', 'grid' ),
							array( 'ga_slider_layout', '!=', 'tiles' ),
							array( 'ga_slider_layout', '!=', 'list' ),
							array( 'ga_slider_layout', '!=', 'grid-3-col' ),
							array( 'ga_slider_layout', '!=', 'grid-highlighted' ),
							array( 'ga_slider_layout', '!=', 'grid-3-col-highlighted' ),
						),
					),
					array(
						'id'       => 'ga_show_caption',
						'type'     => 'select',
						'title'    => __( 'Show Caption overlay on images', 'kadence-shop-kit' ),
						'options'  => array(
							'false' => __( 'False', 'kadence-shop-kit' ),
							'true'  => __( 'True', 'kadence-shop-kit' ),
						),
						'default'  => 'false',
						'required' => array( 'product_gallery', '=', '1' ),
					),
				),
			)
		);
		// Video sub-section.
		$sub_sections->set_sub_section(
			self::OPT_NAME,
			'kt_woo_extra_product_gallery',
			array(
				'id'       => 'product_gallery_video',
				'title'    => __( 'Video', 'kadence-shop-kit' ),
				'desc'     => __( 'Control playback behaviour for product videos — including controls, looping, autoplay, and poster images.', 'kadence-shop-kit' ),
				'priority' => 60,
				'required' => array( 'product_gallery', '=', '1' ),
				'fields'   => array(
					array(
						'id'       => 'ga_video_controls',
						'type'     => 'switch',
						'title'    => __( 'Show Controls?', 'kadence-shop-kit' ),
						'help'     => __( 'When enabled, the video controls will be visible.', 'kadence-shop-kit' ),
						'default'  => 1,
						'required' => array(
							array( 'product_gallery', '=', '1' ),
							array( 'ga_video_controls', '=', '1' ),
						),
					),
					array(
						'id'       => 'ga_video_controls_list',
						'type'     => 'checkboxes',
						'title'    => __( 'Available Controls', 'kadence-shop-kit' ),
						'help'     => __( 'Choose the video controls that should be available to users.', 'kadence-shop-kit' ),
						'options'  => array(
							'play-large' => __( 'Overlay: Play', 'kadence-shop-kit' ),
							'play'       => __( 'Toolbar: Play', 'kadence-shop-kit' ),
							'progress'   => __( 'Toolbar: Progress', 'kadence-shop-kit' ),
							'mute'       => __( 'Toolbar: Mute', 'kadence-shop-kit' ),
							'volume'     => __( 'Toolbar: Volume', 'kadence-shop-kit' ),
							'settings'   => __( 'Toolbar: Settings', 'kadence-shop-kit' ),
							'fullscreen' => __( 'Toolbar: Fullscreen', 'kadence-shop-kit' ),
						),
						'default'  => array( 'play-large', 'play', 'progress', 'mute', 'volume', 'settings', 'fullscreen' ),
						'required' => array(
							array( 'product_gallery', '=', '1' ),
							array( 'ga_video_controls', '=', '1' ),
						),
					),
					array(
						'id'       => 'ga_video_loop',
						'type'     => 'switch',
						'title'    => __( 'Loop?', 'kadence-shop-kit' ),
						'help'     => __( 'When enabled, the video will loop continuously.', 'kadence-shop-kit' ),
						'default'  => 1,
						'required' => array( 'product_gallery', '=', '1' ),
					),
					array(
						'id'       => 'ga_video_autoplay',
						'type'     => 'switch',
						'title'    => __( 'Autoplay?', 'kadence-shop-kit' ),
						'help'     => __( 'When enabled, the video will autoplay once the lightbox opens. Note: autoplay may not work on all devices. Videos will be muted when autoplaying.', 'kadence-shop-kit' ),
						'default'  => 0,
						'required' => array( 'product_gallery', '=', '1' ),
					),
					array(
						'id'       => 'ga_video_poster',
						'type'     => 'switch',
						'title'    => __( 'Enable Poster Images?', 'kadence-shop-kit' ),
						'help'     => __( 'When enabled, gallery images will be used as poster images for both YouTube/Vimeo and MP4/WEBM videos. Uses the size defined in Display Settings > Large Image Size.', 'kadence-shop-kit' ),
						'default'  => 0,
						'required' => array( 'product_gallery', '=', '1' ),
					),
				),
			)
		);
		// Product Display — Image Swap.
		Kadence_Settings_Engine::set_section(
			self::OPT_NAME,
			array(
				'id'           => 'kt_woo_extra_image_swap',
				'title'        => __( 'Image Swap', 'kadence-shop-kit' ),
				'desc'         => __( 'Enhance your WooCommerce catalog images with multiple hover and click effects.', 'kadence-shop-kit' ),
				'doc_url'      => 'https://links.stellarwp.com/shopkit-image-swap',
				'group'        => 'product_display',
				'illustration' => KADENCE_WOO_EXTRAS_URL . 'inc/assets/images/gallery-preview.svg',
				'fields'       => array_merge(
					array(
						array(
							'id'      => 'feature_image_swap',
							'type'    => 'switch',
							'class'   => 'ks-large-toggle',
							'title'   => __( 'Enable Image Swap', 'kadence-shop-kit' ),
							'default' => 0,
						),
					),
					! empty( KWE_Options::get( 'feature_image_swap' ) ) ? array(
						array(
							'id'      => 'image_swap_settings_link',
							'type'    => 'raw',
							'title'   => '',
							'content' => '<a href="' . admin_url( 'admin.php?page=iconic-wis-settings' ) . '">' . esc_html__( 'Image Swap Settings', 'kadence-shop-kit' ) . '</a>',
						),
					) : array(),
				),
			)
		);
		// Product Variations - Variation Swatches.
		$iconic_was_basename = defined( 'ICONIC_WAS_PLUGIN_PATH_FILE' )
			? ICONIC_WAS_PLUGIN_PATH_FILE
			: 'iconic-woo-attribute-swatches/iconic-woo-attribute-swatches.php';

		$variation_swatches_section = array(
			'id'           => 'kt_woo_extra_variation_swatches',
			'group'        => 'product_variations',
			'title'        => __( 'Variation Swatches', 'kadence-shop-kit' ),
			'desc'         => __( 'Display product variations in a way that converts, including color swatches, image swatches, and radio boxes. Set displays on an attribute-by-attribute basis to optimize the best look for each variation.', 'kadence-shop-kit' ),
			'doc_url'      => 'https://links.stellarwp.com/shopkit-variation-swatches',
			'illustration' => KADENCE_WOO_EXTRAS_URL . 'inc/assets/images/swatches-preview.svg',
			'fields'       => array(
				array(
					'id'      => 'variation_swatches',
					'type'    => 'switch',
					'class'   => 'ks-large-toggle',
					'title'   => __( 'Enable swatches control with variations', 'kadence-shop-kit' ),
					'help'    => __( 'This allows you to display images or colors for variation choices.', 'kadence-shop-kit' ),
					'default' => 0,
				),
				array(
					'id'       => 'single_product_swatch_info',
					'type'     => 'title',
					'title'    => __( 'Product Page Settings', 'kadence-shop-kit' ),
					'required' => array( 'variation_swatches', '=', '1' ),
				),
				array(
					'id'       => 'variation_label_placement',
					'type'     => 'select',
					'title'    => __( 'Variation label display', 'kadence-shop-kit' ),
					'help'     => __( 'Control how the variation label is displayed on the product page', 'kadence-shop-kit' ),
					'default'  => ( isset( $shopkit_settings['variation_label'] ) && true === $shopkit_settings['variation_label'] ? 'above' : 'default' ),
					'options'  => array(
						'default' => __( 'Default', 'kadence-shop-kit' ),
						'above'   => __( 'Above the variation', 'kadence-shop-kit' ),
						'hidden'  => __( 'Hidden', 'kadence-shop-kit' ),
					),
					'required' => array( 'variation_swatches', '=', '1' ),
				),
				array(
					'id'       => 'swatches_type',
					'type'     => 'select',
					'title'    => __( 'Choose a default swatch type', 'kadence-shop-kit' ),
					'options'  => array(
						'dropdown'    => __( 'Dropdown Select Box', 'kadence-shop-kit' ),
						'radio_box'   => __( 'Radio Boxes', 'kadence-shop-kit' ),
						'color_image' => __( 'Image and Color swatches', 'kadence-shop-kit' ),
						'taxonomy'    => __( 'Taxonomy defined', 'kadence-shop-kit' ),
					),
					'help'     => __( 'This can be overridden in each product.', 'kadence-shop-kit' ),
					'default'  => 'dropdown',
					'required' => array( 'variation_swatches', '=', '1' ),
				),
				array(
					'id'       => 'swatches_shape',
					'type'     => 'select',
					'title'    => __( 'Choose a default swatch shape', 'kadence-shop-kit' ),
					'options'  => array(
						'square' => __( 'Square', 'kadence-shop-kit' ),
						'round'  => __( 'Round', 'kadence-shop-kit' ),
					),
					'help'     => __( 'This can be overridden per product attribute.', 'kadence-shop-kit' ),
					'default'  => 'square',
					'required' => array( 'variation_swatches', '=', '1' ),
				),
				array(
					'id'       => 'swatches_label',
					'type'     => 'select',
					'title'    => __( 'Choose a default swatch label option', 'kadence-shop-kit' ),
					'help'     => __( 'This can be overridden in each product.', 'kadence-shop-kit' ),
					'options'  => array(
						'false'   => __( 'No label', 'kadence-shop-kit' ),
						'above'   => __( 'Show above', 'kadence-shop-kit' ),
						'below'   => __( 'Show below', 'kadence-shop-kit' ),
						'tooltip' => __( 'Show above on hover', 'kadence-shop-kit' ),
					),
					'default'  => 'false',
					'required' => array( 'variation_swatches', '=', '1' ),
				),
				array(
					'id'       => 'swatches_size',
					'type'     => 'radio_select',
					'title'    => __( 'Choose a default swatch size option', 'kadence-shop-kit' ),
					'help'     => __( 'This can be overridden in each product.', 'kadence-shop-kit' ),
					'options'  => array(
						array(
							'value' => '16',
							'alt'   => __( '16px', 'kadence-shop-kit' ),
							'name'  => __( 'xxs', 'kadence-shop-kit' ),
						),
						array(
							'value' => '30',
							'alt'   => __( '30px', 'kadence-shop-kit' ),
							'name'  => __( 'xs', 'kadence-shop-kit' ),
						),
						array(
							'value' => '40',
							'alt'   => __( '40px', 'kadence-shop-kit' ),
							'name'  => __( 'sm', 'kadence-shop-kit' ),
						),
						array(
							'value' => '50',
							'alt'   => __( '50px', 'kadence-shop-kit' ),
							'name'  => __( 'md', 'kadence-shop-kit' ),
						),
						array(
							'value' => '60',
							'alt'   => __( '60px', 'kadence-shop-kit' ),
							'name'  => __( 'lg', 'kadence-shop-kit' ),
						),
						array(
							'value' => '75',
							'alt'   => __( '75px', 'kadence-shop-kit' ),
							'name'  => __( 'xl', 'kadence-shop-kit' ),
						),
						array(
							'value' => '90',
							'alt'   => __( '90px', 'kadence-shop-kit' ),
							'name'  => __( 'xxl', 'kadence-shop-kit' ),
						),
						array(
							'value' => '120',
							'alt'   => __( '120px', 'kadence-shop-kit' ),
							'name'  => __( '3xl', 'kadence-shop-kit' ),
						),
						array(
							'value' => '150',
							'alt'   => __( '150px', 'kadence-shop-kit' ),
							'name'  => __( '4xl', 'kadence-shop-kit' ),
						),
					),
					'default'  => '50',
					'required' => array( 'variation_swatches', '=', '1' ),
				),
				array(
					'id'       => 'choose_option_text',
					'type'     => 'text',
					'title'    => __( 'Dropdown "Choose an option" text', 'kadence-shop-kit' ),
					'help'     => __( 'Standard: Choose an option', 'kadence-shop-kit' ),
					'required' => array( 'variation_swatches', '=', '1' ),
				),
				array(
					'id'       => 'variation_swatches_accordion',
					'type'     => 'switch',
					'title'    => __( 'Enable accordion mode', 'kadence-shop-kit' ),
					'help'     => __( 'Display product attribute swatches in a collapsible accordion to save space on the product page.', 'kadence-shop-kit' ),
					'default'  => 0,
					'required' => array( 'variation_swatches', '=', '1' ),
				),
				array(
					'id'       => 'archive_product_swatch_info',
					'type'     => 'title',
					'title'    => __( 'Archive Settings', 'kadence-shop-kit' ),
					'required' => array( 'variation_swatches', '=', '1' ),
				),
				array(
					'id'       => 'variation_archive_swatches',
					'type'     => 'switch',
					'title'    => __( 'Enable swatches for Archives', 'kadence-shop-kit' ),
					'help'     => __( 'Display variation swatches with all product loops on shop / archive pages.', 'kadence-shop-kit' ),
					'default'  => 0,
					'required' => array( 'variation_swatches', '=', '1' ),
				),
				array(
					'id'       => 'variation_archive_swatches_quickview',
					'type'     => 'switch',
					'title'    => __( 'Enable swatches for Archives when using quickview', 'kadence-shop-kit' ),
					'help'     => __( 'Disable this if you want to show the variation swatches in quickview, but not the Archive product loops.', 'kadence-shop-kit' ),
					'default'  => 1,
					'required' => array(
						array( 'variation_swatches', '=', '1' ),
						array( 'variation_archive_swatches', '=', '1' ),
						array( 'product_quickview', '=', '1' ),
					),
				),
				array(
					'id'       => 'variation_archive_swatches_mode',
					'type'     => 'select',
					'title'    => __( 'Archive Swatch Mode', 'kadence-shop-kit' ),
					'help'     => __( 'Select how swatches work on shop / archive pages. Catalog Mode will only show one attribute.', 'kadence-shop-kit' ),
					'options'  => array(
						'normal'  => __( 'Normal', 'kadence-shop-kit' ),
						'catalog' => __( 'Catalog Mode', 'kadence-shop-kit' ),
					),
					'default'  => 'normal',
					'required' => array(
						array( 'variation_swatches', '=', '1' ),
						array( 'variation_archive_swatches', '=', '1' ),
					),
				),
				array(
					'id'       => 'variation_archive_swatches_catalog_attribute',
					'type'     => 'select',
					'title'    => __( 'Catalog Attribute', 'kadence-shop-kit' ),
					'help'     => __( 'Select which attribute to show for catalog mode.', 'kadence-shop-kit' ),
					'options'  => array( '' => __( 'First Attribute', 'kadence-shop-kit' ) ),
					'default'  => '',
					'required' => array(
						array( 'variation_swatches', '=', '1' ),
						array( 'variation_archive_swatches', '=', '1' ),
						array( 'variation_archive_swatches_mode', '=', 'catalog' ),
					),
				),
				array(
					'id'       => 'variation_archive_swatches_placement',
					'type'     => 'select',
					'title'    => __( 'Swatch Position', 'kadence-shop-kit' ),
					'help'     => __( 'Select where the swatches display on archives', 'kadence-shop-kit' ),
					'options'  => array(
						'above_title' => __( 'Before Title', 'kadence-shop-kit' ),
						'below_title' => __( 'After Title', 'kadence-shop-kit' ),
						'above_price' => __( 'Before Price', 'kadence-shop-kit' ),
						'below_price' => __( 'After Price', 'kadence-shop-kit' ),
					),
					'default'  => 'below_price',
					'required' => array(
						array( 'variation_swatches', '=', '1' ),
						array( 'variation_archive_swatches', '=', '1' ),
					),
				),
				array(
					'id'       => 'variation_archive_label_placement',
					'type'     => 'select',
					'title'    => __( 'Variation label display', 'kadence-shop-kit' ),
					'help'     => __( 'Control how the variation label is displayed on the product page', 'kadence-shop-kit' ),
					'default'  => 'hidden',
					'options'  => array(
						'default' => __( 'Beside Variation', 'kadence-shop-kit' ),
						'above'   => __( 'Above the variation', 'kadence-shop-kit' ),
						'hidden'  => __( 'Hidden', 'kadence-shop-kit' ),
					),
					'required' => array(
						array( 'variation_swatches', '=', '1' ),
						array( 'variation_archive_swatches', '=', '1' ),
					),
				),
				array(
					'id'       => 'archive_swatches_size',
					'type'     => 'radio_select',
					'title'    => __( 'Choose a default swatch size option', 'kadence-shop-kit' ),
					'help'     => __( 'This can be overridden in each product.', 'kadence-shop-kit' ),
					'options'  => array(
						array(
							'value' => '16',
							'alt'   => __( '16px', 'kadence-shop-kit' ),
							'name'  => __( 'xxs', 'kadence-shop-kit' ),
						),
						array(
							'value' => '30',
							'alt'   => __( '30px', 'kadence-shop-kit' ),
							'name'  => __( 'xs', 'kadence-shop-kit' ),
						),
						array(
							'value' => '40',
							'alt'   => __( '40px', 'kadence-shop-kit' ),
							'name'  => __( 'sm', 'kadence-shop-kit' ),
						),
						array(
							'value' => '50',
							'alt'   => __( '50px', 'kadence-shop-kit' ),
							'name'  => __( 'md', 'kadence-shop-kit' ),
						),
						array(
							'value' => '60',
							'alt'   => __( '60px', 'kadence-shop-kit' ),
							'name'  => __( 'lg', 'kadence-shop-kit' ),
						),
						array(
							'value' => '75',
							'alt'   => __( '75px', 'kadence-shop-kit' ),
							'name'  => __( 'xl', 'kadence-shop-kit' ),
						),
						array(
							'value' => '90',
							'alt'   => __( '90px', 'kadence-shop-kit' ),
							'name'  => __( 'xxl', 'kadence-shop-kit' ),
						),
						array(
							'value' => '120',
							'alt'   => __( '120px', 'kadence-shop-kit' ),
							'name'  => __( '3xl', 'kadence-shop-kit' ),
						),
						array(
							'value' => '150',
							'alt'   => __( '150px', 'kadence-shop-kit' ),
							'name'  => __( '4xl', 'kadence-shop-kit' ),
						),
					),
					'default'  => '30',
					'required' => array(
						array( 'variation_swatches', '=', '1' ),
						array( 'variation_archive_swatches', '=', '1' ),
					),
				),
			),
		);

		if ( is_plugin_active( $iconic_was_basename ) ) {
			$variation_swatches_section['notice'] = '<div class="notice notice-warning inline"><p>'
				. wp_kses(
					sprintf(
						/* translators: 1: opening <strong>, 2: closing </strong> */
						__( '%1$sAttribute Swatches is active.%2$s While Attribute Swatches is running, Shop Kit will take over and its settings will have no effect. Attribute Swatches has been merged into Shop Kit, is no longer maintained as a standalone product, and Shop Kit fully covers its functionality. You can safely deactivate Attribute Swatches.', 'kadence-shop-kit' ),
						'<strong>',
						'</strong>'
					),
					array( 'strong' => array() )
				)
				. '</p></div>';
		}

		Kadence_Settings_Engine::set_section( self::OPT_NAME, $variation_swatches_section );
		// Product Display — Product Reviews.
		Kadence_Settings_Engine::set_section(
			self::OPT_NAME,
			array(
				'id'           => 'kt_woo_extra_product_reviews',
				'title'        => __( 'Product Reviews', 'kadence-shop-kit' ),
				'desc'         => __( 'Create better social proof with improved reviews, add titles, voting capabilities, and order reviews to show the highest-voted reviews first. Plus display a review overview board.', 'kadence-shop-kit' ),
				'doc_url'      => 'https://links.stellarwp.com/shopkit-advanced-reviews',
				'illustration' => KADENCE_WOO_EXTRAS_URL . 'inc/assets/images/review-preview.svg',
				'group'        => 'product_display',
				'fields'       => array(
					array(
						'id'      => 'kt_reviews',
						'type'    => 'switch',
						'class'   => 'ks-large-toggle',
						'title'   => __( 'Enable Advanced Reviews', 'kadence-shop-kit' ),
						'help'    => __( 'This allows you to change the review order as well as have titles and vote on reviews.', 'kadence-shop-kit' ),
						'default' => 0,
					),
					array(
						'id'       => 'kt_reviews_order',
						'type'     => 'select',
						'title'    => __( 'Select Review Order', 'kadence-shop-kit' ),
						'options'  => array(
							'votes_desc' => __( 'Order by most helpful with fallback newest first', 'kadence-shop-kit' ),
							'desc'       => __( 'Newest First', 'kadence-shop-kit' ),
							'asc'        => __( 'Oldest First', 'kadence-shop-kit' ),
						),
						'default'  => 'votes_desc',
						'width'    => 'width:60%',
						'required' => array( 'kt_reviews', '=', '1' ),
					),
					array(
						'id'       => 'kt_review_title',
						'type'     => 'switch',
						'title'    => __( 'Enable Review Titles', 'kadence-shop-kit' ),
						'help'     => __( 'This allows you to have titles for reviews.', 'kadence-shop-kit' ),
						'default'  => 1,
						'required' => array( 'kt_reviews', '=', '1' ),
					),
					array(
						'id'       => 'kt_review_consent',
						'type'     => 'switch',
						'title'    => __( 'Enable Review Consent Checkbox', 'kadence-shop-kit' ),
						'help'     => __( 'This adds a consent to privacy policy checkbox', 'kadence-shop-kit' ),
						'default'  => 0,
						'required' => array( 'kt_reviews', '=', '1' ),
					),
					array(
						'id'       => 'kt_reviews_multi',
						'type'     => 'switch',
						'title'    => __( 'When using polylang or WPML show reviews in every language.', 'kadence-shop-kit' ),
						'default'  => 0,
						'required' => array( 'kt_reviews', '=', '1' ),
					),
					array(
						'id'       => 'kt_review_voting',
						'type'     => 'switch',
						'title'    => __( 'Enable Review Voting', 'kadence-shop-kit' ),
						'help'     => __( 'This allows users to upvote reviews that are more helpful.', 'kadence-shop-kit' ),
						'default'  => 1,
						'required' => array( 'kt_reviews', '=', '1' ),
					),
					array(
						'id'       => 'vote_loggedin_only',
						'type'     => 'switch',
						'title'    => __( 'Voters must be logged in?', 'kadence-shop-kit' ),
						'help'     => __( 'With this turned on only logged in users will be able to vote.', 'kadence-shop-kit' ),
						'default'  => 1,
						'required' => array( 'kt_reviews', '=', '1' ),
					),
					array(
						'id'       => 'kt_review_overview',
						'type'     => 'switch',
						'title'    => __( 'Show Review Overview?', 'kadence-shop-kit' ),
						'help'     => __( 'With this turned on there will be overview of all reviews.', 'kadence-shop-kit' ),
						'default'  => 0,
						'required' => array( 'kt_reviews', '=', '1' ),
					),
					array(
						'id'       => 'kt_review_overview_highlight',
						'type'     => 'color',
						'title'    => __( 'Overview highlight color', 'kadence-shop-kit' ),
						'default'  => '#2d5c88',
						'required' => array( 'kt_reviews', '=', '1' ),
					),
					array(
						'id'       => 'kt_reviews_featured',
						'type'     => 'switch',
						'title'    => __( 'Enabled Featured Reviews', 'kadence-shop-kit' ),
						'help'     => __( 'With this turned on you can set reviews to be featured and show at the top of your list.', 'kadence-shop-kit' ),
						'default'  => 0,
						'required' => array( 'kt_reviews', '=', '1' ),
					),
					array(
						'id'       => 'kt_reviews_limited',
						'type'     => 'switch',
						'title'    => __( 'Enabled Load More for Reviews', 'kadence-shop-kit' ),
						'help'     => __( 'With this turned on reviews will only load the inital amount and a load more button will show.', 'kadence-shop-kit' ),
						'default'  => 0,
						'required' => array( 'kt_reviews', '=', '1' ),
					),
					array(
						'id'       => 'kt_reviews_limited_readmore',
						'type'     => 'text',
						'title'    => __( 'Read More Reviews Button Text', 'kadence-shop-kit' ),
						'help'     => __( 'Default: Read More Reviews', 'kadence-shop-kit' ),
						'required' => array(
							array( 'kt_reviews', '=', '1' ),
							array( 'kt_reviews_limited', '=', '1' ),
						),
					),
					array(
						'id'       => 'kt_reviews_limited_count',
						'type'     => 'range',
						'title'    => __( 'Load more inital and per load amount', 'kadence-shop-kit' ),
						'default'  => '10',
						'min'      => '2',
						'step'     => '1',
						'max'      => '100',
						'required' => array(
							array( 'kt_reviews', '=', '1' ),
							array( 'kt_reviews_limited', '=', '1' ),
						),
					),
					array(
						'id'       => 'kt_review_convert',
						'type'     => 'raw',
						'title'    => __( 'Convert previous reviews to Advanced Reviews', 'kadence-shop-kit' ),
						'help'     => __( 'This will convert all your previous reviews into advanced.', 'kadence-shop-kit' ),
						'content'  => ( isset( $shopkit_settings['kt_reviews'] ) && true === $shopkit_settings['kt_reviews'] ? '<button id="kt-review-convert" class="button-primary kt-review-convert" onClick="KadenceConvertButton();"style="margin:10px 0;">Convert Reviews<span class="spinner-item"></span></button><p class="convert-info"></p>' : '<div id="kadence-convert-info" class="convert-info"><p class="kadence-settings-notice">Save with advanced reviews enabled and reload the page to show the convert button.</p></div>' ),
						'required' => array( 'kt_reviews', '=', '1' ),
					),
				),
			)
		);
		Kadence_Settings_Engine::set_section(
			self::OPT_NAME,
			array(
				'id'           => 'kt_woo_extra_product_brands',
				'title'        => __( 'Product Brands', 'kadence-shop-kit' ),
				'desc'         => __( 'Leverage brand influence on product displays, choosing where to show on archive and single product pages. Show recognizable logos, or just the brand name. Add a filter-by-brands widget to your site.', 'kadence-shop-kit' ),
				'doc_url'      => 'https://links.stellarwp.com/shopkit-product-brands',
				'illustration' => KADENCE_WOO_EXTRAS_URL . 'inc/assets/images/brands-preview.svg',
				'group'        => 'merchandising',
				'fields'       => array(
					array(
						'id'      => 'kt_product_brands_options',
						'type'    => 'switch',
						'class'   => 'ks-large-toggle',
						'title'   => __( 'Enable Product Brands Options', 'kadence-shop-kit' ),
						'help'    => __( 'This adds a new Taxonomy for Products', 'kadence-shop-kit' ),
						'default' => 0,
					),
					array(
						'id'       => 'product_brands_singular',
						'type'     => 'text',
						'title'    => __( 'Singular Custom Name', 'kadence-shop-kit' ),
						'help'     => __( 'Default: Product Brand', 'kadence-shop-kit' ),
						'required' => array( 'kt_product_brands_options', '=', '1' ),
					),
					array(
						'id'       => 'product_brands_plural',
						'type'     => 'text',
						'title'    => __( 'Plural Custom Name', 'kadence-shop-kit' ),
						'help'     => __( 'Default: Product Brands', 'kadence-shop-kit' ),
						'required' => array( 'kt_product_brands_options', '=', '1' ),
					),
					array(
						'id'       => 'product_brands_slug',
						'type'     => 'text',
						'title'    => __( 'URL Custom slug', 'kadence-shop-kit' ),
						'help'     => __( 'Default: product-brands (lowercase, no spaces)', 'kadence-shop-kit' ),
						'required' => array( 'kt_product_brands_options', '=', '1' ),
					),
					array(
						'id'       => 'product_brands_output_info',
						'type'     => 'info',
						'title'    => __( 'Product Brands Single Output settings', 'kadence-shop-kit' ),
						'required' => array( 'kt_product_brands_options', '=', '1' ),
					),
					array(
						'id'       => 'product_brands_single_output',
						'type'     => 'select',
						'title'    => __( 'Single Product Page Output', 'kadence-shop-kit' ),
						'options'  => array(
							'none'            => __( 'None', 'kadence-shop-kit' ),
							'above_title'     => __( 'Above Title', 'kadence-shop-kit' ),
							'above_price'     => __( 'Below Title, Above Price', 'kadence-shop-kit' ),
							'above_excerpt'   => __( 'Below Price, Above Short Description', 'kadence-shop-kit' ),
							'above_addtocart' => __( 'Below Short Description, Above Add to cart', 'kadence-shop-kit' ),
							'above_meta'      => __( 'Below Add to cart, Above meta content', 'kadence-shop-kit' ),
							'below_meta'      => __( 'Below meta content', 'kadence-shop-kit' ),
						),
						'default'  => 'none',
						'required' => array( 'kt_product_brands_options', '=', '1' ),
					),
					array(
						'id'       => 'product_brands_single_output_style',
						'type'     => 'select',
						'title'    => __( 'Show as text or image', 'kadence-shop-kit' ),
						'options'  => array(
							'image' => __( 'Image', 'kadence-shop-kit' ),
							'text'  => __( 'Text', 'kadence-shop-kit' ),
						),
						'default'  => 'image',
						'required' => array( 'kt_product_brands_options', '=', '1' ),
					),
					array(
						'id'       => 'product_brands_single_output_width',
						'title'    => __( 'Single Product Page Brand Image Width', 'kadence-shop-kit' ),
						'type'     => 'range',
						'default'  => '200',
						'min'      => '40',
						'step'     => '2',
						'max'      => '1400',
						'required' => array( 'kt_product_brands_options', '=', '1' ),
					),
					array(
						'id'       => 'product_brands_single_output_cropped',
						'type'     => 'switch',
						'title'    => __( 'Enable to Hard Crop Image', 'kadence-shop-kit' ),
						'help'     => __( 'If enabled you can force a specific height to hard crop to.', 'kadence-shop-kit' ),
						'default'  => 0,
						'required' => array( 'kt_product_brands_options', '=', '1' ),
					),
					array(
						'id'       => 'product_brands_single_output_height',
						'title'    => __( 'Single Product Page Brand Image Height', 'kadence-shop-kit' ),
						'type'     => 'range',
						'default'  => '200',
						'min'      => '40',
						'step'     => '2',
						'max'      => '1400',
						'required' => array(
							array( 'kt_product_brands_options', '=', '1' ),
							array( 'product_brands_single_output_cropped', '=', '1' ),
						),
					),
					array(
						'id'       => 'product_brands_single_link',
						'type'     => 'switch',
						'title'    => __( 'Link Image to Brand Page', 'kadence-shop-kit' ),
						'help'     => __( 'Adds Link to brand archive page from image.', 'kadence-shop-kit' ),
						'default'  => 0,
						'required' => array( 'kt_product_brands_options', '=', '1' ),
					),
					array(
						'id'       => 'product_brands_archive_output_info',
						'type'     => 'info',
						'title'    => __( 'Product Brands Archive Output settings', 'kadence-shop-kit' ),
						'required' => array( 'kt_product_brands_options', '=', '1' ),
					),
					array(
						'id'       => 'product_brands_archive_output',
						'type'     => 'select',
						'title'    => __( 'Archive Page Output', 'kadence-shop-kit' ),
						'options'  => array(
							'none'            => __( 'None', 'kadence-shop-kit' ),
							'above_image'     => __( 'Above image', 'kadence-shop-kit' ),
							'above_title'     => __( 'Below image, Above title', 'kadence-shop-kit' ),
							'above_excerpt'   => __( 'Below title, Above excerpt', 'kadence-shop-kit' ),
							'above_price'     => __( 'Below excerpt, Above price', 'kadence-shop-kit' ),
							'above_addtocart' => __( 'Below price, Above add to cart', 'kadence-shop-kit' ),
							'below_addtocart' => __( 'Below add to cart', 'kadence-shop-kit' ),
						),
						'default'  => 'none',
						'required' => array( 'kt_product_brands_options', '=', '1' ),
					),
					array(
						'id'       => 'product_brands_archive_output_style',
						'type'     => 'select',
						'title'    => __( 'Show as text or image', 'kadence-shop-kit' ),
						'options'  => array(
							'image' => __( 'Image', 'kadence-shop-kit' ),
							'text'  => __( 'Text', 'kadence-shop-kit' ),
						),
						'default'  => 'image',
						'required' => array( 'kt_product_brands_options', '=', '1' ),
					),
					array(
						'id'       => 'product_brands_archive_output_width',
						'title'    => __( 'Archive Page Brand Image Width', 'kadence-shop-kit' ),
						'type'     => 'range',
						'default'  => '200',
						'min'      => '40',
						'step'     => '2',
						'max'      => '1400',
						'required' => array( 'kt_product_brands_options', '=', '1' ),
					),
					array(
						'id'       => 'product_brands_archive_output_cropped',
						'type'     => 'switch',
						'title'    => __( 'Enable to Hard Crop Image', 'kadence-shop-kit' ),
						'help'     => __( 'If enabled you can force a specific height to hard crop to.', 'kadence-shop-kit' ),
						'default'  => 0,
						'required' => array( 'kt_product_brands_options', '=', '1' ),
					),
					array(
						'id'       => 'product_brands_archive_output_height',
						'title'    => __( 'Archive Page Brand Image Height', 'kadence-shop-kit' ),
						'type'     => 'range',
						'default'  => '200',
						'min'      => '40',
						'step'     => '2',
						'max'      => '1400',
						'required' => array(
							array( 'kt_product_brands_options', '=', '1' ),
							array( 'product_brands_archive_output_cropped', '=', '1' ),
						),
					),
					array(
						'id'       => 'product_brands_archive_link',
						'type'     => 'switch',
						'title'    => __( 'Link Image to Brand Page', 'kadence-shop-kit' ),
						'help'     => __( 'Adds Link to brand archive page from image.', 'kadence-shop-kit' ),
						'default'  => 0,
						'required' => array( 'kt_product_brands_options', '=', '1' ),
					),

				),
			)
		);
		Kadence_Settings_Engine::set_section(
			self::OPT_NAME,
			array(
				'id'      => 'kt_woo_extra_product_badges',
				'title'   => __( 'Product Badges', 'kadence-shop-kit' ),
				'desc'    => __( 'Add custom badges to products in your shop and single product pages. Highlight sale items or special categories.', 'kadence-shop-kit' ),
				'doc_url' => 'https://links.stellarwp.com/shopkit-product-badges',
				// 'illustration' => KADENCE_WOO_EXTRAS_URL . 'inc/assets/images/brands-preview.svg',
				'group'   => 'merchandising',
				'fields'  => array(
					array(
						'id'      => 'kt_product_badges_options',
						'type'    => 'switch',
						'class'   => 'ks-large-toggle',
						'title'   => __( 'Enable Product Badges Options', 'kadence-shop-kit' ),
						'help'    => __( 'This adds a new post type to your site.', 'kadence-shop-kit' ),
						'default' => 0,
					),
					array(
						'id'       => 'kt_product_badges_disable_sale_flash',
						'type'     => 'switch',
						'title'    => __( 'Disable Woocommerce Sale Flash', 'kadence-shop-kit' ),
						'help'     => __( 'WooCommerce displays a sale notice on products by default. This notice can overlap with badges. This setting disables the notice where badges may be active.', 'kadence-shop-kit' ),
						'default'  => 0,
						'required' => array( 'kt_product_badges_options', '=', '1' ),
					),
					array(
						'id'       => 'kt_product_badges_info',
						'type'     => 'info',
						'title'    => __( 'Find Badges under the "Products" Menu item in your admin.', 'kadence-shop-kit' ),
						'required' => array( 'kt_product_badges_options', '=', '1' ),
					),
				),
			)
		);
		$iconic_wqv_basename = defined( 'ICONIC_WQV_PLUGIN_PATH_FILE' )
			? ICONIC_WQV_PLUGIN_PATH_FILE
			: 'iconic-woo-quickview/iconic-woo-quickview.php';

		$product_quickview_section = array(
			'id'      => 'kt_woo_extra_product_quickview',
			'title'   => __( 'Product Quickview', 'kadence-shop-kit' ),
			'desc'    => __( 'Let customers quickly preview products on the shop and category pages. (other areas optional)', 'kadence-shop-kit' ),
			'doc_url' => 'https://links.stellarwp.com/shopkit-product-quickview',
			'group'   => 'merchandising',
			'fields'  => array(
				array(
					'id'      => 'product_quickview',
					'type'    => 'switch',
					'class'   => 'ks-large-toggle',
					'title'   => __( 'Enable Product Quickview', 'kadence-shop-kit' ),
					'help'    => __( 'This adds quickview buttons to product listings', 'kadence-shop-kit' ),
					'default' => 0,
				),
				array(
					'id'       => 'product_quickview_in_blocks',
					'type'     => 'switch',
					'title'    => __( 'Quickview Block', 'kadence-shop-kit' ),
					'help'     => __( 'Adds a quickview button block to add quickview in any block content or template such as woocommmerce product collection blocks.', 'kadence-shop-kit' ),
					'default'  => 0,
					'required' => array(
						array( 'product_quickview', '=', '1' ),
					),
				),
				array(
					'id'       => 'product_quickview_auto',
					'type'     => 'switch',
					'title'    => __( 'Automatically insert button', 'kadence-shop-kit' ),
					'help'     => __( 'Quickview will attempt to automatically insert the Quickview button. Disable this if you wish to place quickview buttons yourself via shortcode [kt_quickview_button] or block.', 'kadence-shop-kit' ),
					'default'  => 1,
					'required' => array( 'product_quickview', '=', '1' ),
				),
				array(
					'id'       => 'product_quickview_auto_placement',
					'type'     => 'select',
					'title'    => __( 'Button Placement', 'kadence-shop-kit' ),
					'options'  => array(
						''            => __( 'After Add to Cart', 'kadence-shop-kit' ),
						'before-add'  => __( 'Before add to Cart', 'kadence-shop-kit' ),
						'above-title' => __( 'Above Title', 'kadence-shop-kit' ),
						'below-title' => __( 'Below Title', 'kadence-shop-kit' ),
						'before-item' => __( 'Before Item', 'kadence-shop-kit' ),
						'after-item'  => __( 'After Item', 'kadence-shop-kit' ),
						'above-price' => __( 'Above Price', 'kadence-shop-kit' ),
						'below-price' => __( 'Below Price', 'kadence-shop-kit' ),
					),
					'default'  => '',
					'required' => array(
						array( 'product_quickview', '=', '1' ),
						array( 'product_quickview_auto', '!=', '0' ),
					),
				),
				array(
					'id'       => 'product_quickview_auto_in_single',
					'type'     => 'switch',
					'title'    => __( 'Add quickview to single product pages', 'kadence-shop-kit' ),
					'default'  => 0,
					'required' => array(
						array( 'product_quickview', '=', '1' ),
						array( 'product_quickview_auto', '!=', '0' ),
					),
				),
				array(
					'id'       => 'product_quickview_show_label',
					'type'     => 'switch',
					'title'    => __( 'Quickview Button Show Text', 'kadence-shop-kit' ),
					'default'  => '1',
					'required' => array( 'product_quickview', '=', '1' ),
				),
				array(
					'id'       => 'product_quickview_label',
					'type'     => 'text',
					'title'    => __( 'Quickview Button Text', 'kadence-shop-kit' ),
					'help'     => __( 'Default: Quickview', 'kadence-shop-kit' ),
					'required' => array(
						array( 'product_quickview', '=', '1' ),
						array( 'product_quickview_show_label', '!=', '0' ),
					),
				),
				array(
					'id'       => 'product_quickview_button_icon',
					'type'     => 'switch',
					'title'    => __( 'Add a Button Icon', 'kadence-shop-kit' ),
					'default'  => 0,
					'required' => array( 'product_quickview', '=', '1' ),
				),
				array(
					'id'       => 'product_quickview_button_icon_choice',
					'type'     => 'select',
					'options'  => array(
						'eye'   => __( 'Eye', 'kadence-shop-kit' ),
						'play'  => __( 'Play', 'kadence-shop-kit' ),
						'click' => __( 'Click', 'kadence-shop-kit' ),
					),
					'title'    => __( 'Button Icon', 'kadence-shop-kit' ),
					'default'  => 'eye',
					'required' => array(
						array( 'product_quickview', '=', '1' ),
						array( 'product_quickview_button_icon', '==', '1' ),
					),
				),
				array(
					'id'       => 'product_quickview_button_icon_color',
					'type'     => 'color',
					'title'    => __( 'Button Icon Color', 'kadence-shop-kit' ),
					'default'  => '',
					'required' => array(
						array( 'product_quickview', '=', '1' ),
						array( 'product_quickview_button_icon', '==', '1' ),
					),
				),
				array(
					'id'       => 'product_quickview_button_icon_color_hover',
					'type'     => 'color',
					'title'    => __( 'Button Icon Color Hover', 'kadence-shop-kit' ),
					'default'  => '',
					'required' => array(
						array( 'product_quickview', '=', '1' ),
						array( 'product_quickview_button_icon', '==', '1' ),
					),
				),
				array(
					'id'       => 'product_quickview_content_info',
					'type'     => 'info',
					'title'    => __( 'WARNING! Your quickview button has no text or icon content. It will not be displayed.', 'kadence-shop-kit' ),
					'required' => array(
						array( 'product_quickview', '=', '1' ),
						array( 'product_quickview_show_label', '==', '0' ),
						array( 'product_quickview_button_icon', '==', '0' ),
					),
				),
				array(
					'id'       => 'product_quickview_button_color',
					'type'     => 'color',
					'title'    => __( 'Button Text Color', 'kadence-shop-kit' ),
					'default'  => '',
					'required' => array( 'product_quickview', '=', '1' ),
				),
				array(
					'id'       => 'product_quickview_button_color_hover',
					'type'     => 'color',
					'title'    => __( 'Button Text Color Hover', 'kadence-shop-kit' ),
					'default'  => '',
					'required' => array( 'product_quickview', '=', '1' ),
				),
				array(
					'id'       => 'product_quickview_button_background',
					'type'     => 'color',
					'title'    => __( 'Button Background', 'kadence-shop-kit' ),
					'default'  => '',
					'required' => array( 'product_quickview', '=', '1' ),
				),
				array(
					'id'       => 'product_quickview_button_background_hover',
					'type'     => 'color',
					'title'    => __( 'Button Background Hover', 'kadence-shop-kit' ),
					'default'  => '',
					'required' => array( 'product_quickview', '=', '1' ),
				),
				array(
					'id'       => 'product_quickview_button_border_width',
					'type'     => 'range',
					'title'    => __( 'Button Border Width', 'kadence-shop-kit' ),
					'default'  => '',
					'min'      => '0',
					'step'     => '1',
					'max'      => '50',
					'required' => array( 'product_quickview', '=', '1' ),
				),
				array(
					'id'       => 'product_quickview_button_border_color',
					'type'     => 'color',
					'title'    => __( 'Button Border Color', 'kadence-shop-kit' ),
					'default'  => '',
					'required' => array( 'product_quickview', '=', '1' ),
				),
				array(
					'id'       => 'product_quickview_button_border_color_hover',
					'type'     => 'color',
					'title'    => __( 'Button Border Color Hover', 'kadence-shop-kit' ),
					'default'  => '',
					'required' => array( 'product_quickview', '=', '1' ),
				),
				array(
					'id'       => 'product_quickview_button_border_radius',
					'type'     => 'range',
					'title'    => __( 'Button Border Radius', 'kadence-shop-kit' ),
					'default'  => '',
					'min'      => '0',
					'step'     => '1',
					'max'      => '200',
					'required' => array( 'product_quickview', '=', '1' ),
				),
				array(
					'id'       => 'product_quickview_slides',
					'type'     => 'switch',
					'title'    => __( 'Allow scrolling', 'kadence-shop-kit' ),
					'help'     => __( 'When quickview opens, users can "scroll" with arrows or "swipe" to the next product in the list.', 'kadence-shop-kit' ),
					'default'  => 1,
					'required' => array( 'product_quickview', '=', '1' ),
				),
				array(
					'id'       => 'product_quickview_use_template',
					'type'     => 'switch',
					'title'    => __( 'Use a Woo Template', 'kadence-shop-kit' ),
					'help'     => __( 'Enable Woo Templates to customize the appearance of your quick view, disable to use Shop Kit’s default', 'kadence-shop-kit' ),
					'default'  => 0,
					'required' => array( 'product_quickview', '=', '1' ),
				),
				array(
					'id'       => 'product_quickview_template',
					'type'     => 'select',
					'title'    => __( 'Quickview Template', 'kadence-shop-kit' ),
					'options'  => $this->get_quickview_templates_options(),
					'default'  => '',
					'required' => array(
						array( 'product_quickview', '=', '1' ),
						array( 'product_quickview_use_template', '==', '1' ),
					),
				),
				array(
					'id'       => 'product_quickview_template_info',
					'type'     => 'info',
					'title'    => __( 'Create Woo Templates in the "Products" Menu item in your admin. Select "Quickview" when making the new template.', 'kadence-shop-kit' ),
					'required' => array(
						array( 'product_quickview', '=', '1' ),
						array( 'product_quickview_use_template', '==', '1' ),
					),
				),
			),
		);

		if ( is_plugin_active( $iconic_wqv_basename ) ) {
			$product_quickview_section['notice'] = '<div class="notice notice-warning inline"><p>'
				. wp_kses(
					sprintf(
						/* translators: 1: opening <strong>, 2: closing </strong> */
						__( '%1$sWooCommerce Quickview is active.%2$s Shop Kit includes its own Quickview with equivalent functionality. Having both active will display duplicate Quickview buttons on your storefront. WooCommerce Quickview is no longer maintained as a standalone product. You can safely deactivate WooCommerce Quickview.', 'kadence-shop-kit' ),
						'<strong>',
						'</strong>'
					),
					array( 'strong' => array() )
				)
				. '</p></div>';
		}

		Kadence_Settings_Engine::set_section( self::OPT_NAME, $product_quickview_section );
		Kadence_Settings_Engine::set_section(
			self::OPT_NAME,
			array(
				'id'           => 'kt_woo_extra_affiliate_product_options',
				'title'        => __( 'Affiliate Product Options', 'kadence-shop-kit' ),
				'group'        => 'merchandising',
				'desc'         => __( 'Grow your revenue capabilities by unlocking affiliate sales with the Shop Kit affiliate product options.', 'kadence-shop-kit' ),
				'doc_url'      => 'https://links.stellarwp.com/shopkit-affiliate-product-options',
				'illustration' => KADENCE_WOO_EXTRAS_URL . 'inc/assets/images/affiliate-product-preview.svg',
				'fields'       => array(
					array(
						'id'      => 'kt_affiliate_options',
						'type'    => 'switch',
						'class'   => 'ks-large-toggle',
						'title'   => __( 'Enable Affiliate/External Product Options', 'kadence-shop-kit' ),
						'help'    => __( 'This gives you control to add direct links for product images and archive action buttons.', 'kadence-shop-kit' ),
						'default' => 0,
					),
					array(
						'id'       => 'affiliate_archive_info',
						'type'     => 'info',
						'title'    => __( 'Product Archive Settings', 'kadence-shop-kit' ),
						'required' => array( 'kt_affiliate_options', '=', '1' ),
					),
					array(
						'id'       => 'kt_aa_image_link',
						'type'     => 'switch',
						'title'    => __( 'Enable Affiliate link for Product Images', 'kadence-shop-kit' ),
						'help'     => __( 'This makes the product image link to the affilate instead of the single product page.', 'kadence-shop-kit' ),
						'default'  => 0,
						'required' => array( 'kt_affiliate_options', '=', '1' ),
					),
					array(
						'id'       => 'kt_aa_image_link_target',
						'type'     => 'switch',
						'title'    => __( 'Enable Affiliate Product Image link to opens new browser tab', 'kadence-shop-kit' ),
						'help'     => __( 'This makes the product image link open a new tab.', 'kadence-shop-kit' ),
						'default'  => 1,
						'required' => array( 'kt_aa_image_link', '=', '1' ),
					),
					array(
						'id'       => 'kt_aa_title_link',
						'type'     => 'switch',
						'title'    => __( 'Enable Affiliate link for Product Title', 'kadence-shop-kit' ),
						'help'     => __( 'This makes the product title link to the affilate instead of the single product page.', 'kadence-shop-kit' ),
						'default'  => 0,
						'required' => array( 'kt_aa_image_link', '=', '1' ),
					),
					array(
						'id'       => 'kt_aa_title_link_target',
						'type'     => 'switch',
						'title'    => __( 'Enable Affiliate Product Title link to opens new browser tab', 'kadence-shop-kit' ),
						'help'     => __( 'This makes the product title link open a new tab.', 'kadence-shop-kit' ),
						'default'  => 1,
						'required' => array( 'kt_aa_title_link', '=', '1' ),
					),
					array(
						'id'       => 'kt_aa_action_link_target',
						'type'     => 'switch',
						'title'    => __( 'Enable Affiliate Button link to open new browser tab', 'kadence-shop-kit' ),
						'help'     => __( 'This makes the product button link open a new tab.', 'kadence-shop-kit' ),
						'default'  => 1,
						'required' => array( 'kt_affiliate_options', '=', '1' ),
					),
					array(
						'id'       => 'affiliate_single_info',
						'type'     => 'info',
						'help'     => __( 'Product Single Settings', 'kadence-shop-kit' ),
						'required' => array( 'kt_affiliate_options', '=', '1' ),
					),
					array(
						'id'       => 'kt_single_aa_image_link',
						'type'     => 'switch',
						'title'    => __( 'Enable Affiliate link for Product Images', 'kadence-shop-kit' ),
						'help'     => __( 'This makes the product image link to the affiliate instead of the lightbox.', 'kadence-shop-kit' ),
						'default'  => 0,
						'required' => array( 'kt_affiliate_options', '=', '1' ),
					),
					array(
						'id'       => 'kt_single_aa_image_link_target',
						'type'     => 'switch',
						'title'    => __( 'Enable Affiliate Product Image link to opens new browser tab', 'kadence-shop-kit' ),
						'help'     => __( 'This makes the product image link open a new tab.', 'kadence-shop-kit' ),
						'default'  => 1,
						'required' => array( 'kt_single_aa_image_link', '=', '1' ),
					),
					array(
						'id'       => 'kt_single_aa_action_link_target',
						'type'     => 'switch',
						'title'    => __( 'Enable Affiliate Button link to open new browser tab', 'kadence-shop-kit' ),
						'help'     => __( 'This makes the product button link open a new tab.', 'kadence-shop-kit' ),
						'default'  => 1,
						'required' => array( 'kt_affiliate_options', '=', '1' ),
					),
				),
			)
		);

		Kadence_Settings_Engine::set_section(
			self::OPT_NAME,
			array(
				'id'           => 'kt_woo_extra_add_to_cart_text',
				'title'        => __( 'Add to Cart Text', 'kadence-shop-kit' ),
				'desc'         => __( 'Build unique and creative custom text labels for a more personalized shopping experience. "Add to Cart" easily becomes "Buy Shoes." Take the mystery out of variable products setting specific archives names instead of "select options."', 'kadence-shop-kit' ),
				'doc_url'      => 'https://links.stellarwp.com/shopkit-custom-add-to-cart-text',
				'group'        => 'conversions',
				'illustration' => KADENCE_WOO_EXTRAS_URL . 'inc/assets/images/add-to-cart-preview.svg',
				'fields'       => array(
					array(
						'id'      => 'kt_add_to_cart_text',
						'type'    => 'switch',
						'class'   => 'ks-large-toggle',
						'title'   => __( 'Enable Custom add to cart text', 'kadence-shop-kit' ),
						'help'    => __( 'This allows you to change the text for the add to cart buttons.', 'kadence-shop-kit' ),
						'default' => 0,
					),
					array(
						'id'       => 'add_to_cart_text_info',
						'type'     => 'info',
						'title'    => __( 'Archive Add to Cart', 'kadence-shop-kit' ),
						'required' => array( 'kt_add_to_cart_text', '=', '1' ),
					),
					array(
						'id'       => 'add_to_cart_text',
						'type'     => 'text',
						'title'    => __( 'Simple Product', 'kadence-shop-kit' ),
						'help'     => __( 'Default: Add to cart', 'kadence-shop-kit' ),
						'required' => array( 'kt_add_to_cart_text', '=', '1' ),
					),
					array(
						'id'       => 'variable_add_to_cart_text',
						'type'     => 'text',
						'title'    => __( 'Variable Product', 'kadence-shop-kit' ),
						'help'     => __( 'Default: Select options', 'kadence-shop-kit' ),
						'required' => array( 'kt_add_to_cart_text', '=', '1' ),
					),
					array(
						'id'       => 'grouped_add_to_cart_text',
						'type'     => 'text',
						'title'    => __( 'Grouped Product', 'kadence-shop-kit' ),
						'help'     => __( 'Default: View Products', 'kadence-shop-kit' ),
						'required' => array( 'kt_add_to_cart_text', '=', '1' ),
					),
					array(
						'id'       => 'out_add_to_cart_text',
						'type'     => 'text',
						'title'    => __( 'Out of Stock Product', 'kadence-shop-kit' ),
						'help'     => __( 'Default: Read More', 'kadence-shop-kit' ),
						'required' => array( 'kt_add_to_cart_text', '=', '1' ),
					),
					array(
						'id'       => 'single_add_to_cart_text_info',
						'type'     => 'info',
						'title'    => __( 'Single Add to Cart', 'kadence-shop-kit' ),
						'required' => array( 'kt_add_to_cart_text', '=', '1' ),
					),
					array(
						'id'       => 'single_add_to_cart_text',
						'type'     => 'text',
						'title'    => __( 'All Products', 'kadence-shop-kit' ),
						'help'     => __( 'Default: Add to cart', 'kadence-shop-kit' ),
						'required' => array( 'kt_add_to_cart_text', '=', '1' ),
					),
				),
			)
		);
		Kadence_Settings_Engine::set_section(
			self::OPT_NAME,
			array(
				'id'           => 'kt_woo_extra_variation_options',
				'title'        => __( 'Variation Options', 'kadence-shop-kit' ),
				'desc'         => __( 'Optionally change how your variable products display pricing by showing either the lowest or highest price in the variable product. You can also add text before or after the price, for example "Base Price: $45."', 'kadence-shop-kit' ),
				'doc_url'      => 'https://links.stellarwp.com/shopkit-variation-options',
				'group'        => 'product_variations',
				'illustration' => KADENCE_WOO_EXTRAS_URL . 'inc/assets/images/variation-preview.svg',
				'fields'       => array(
					array(
						'id'      => 'variation_price',
						'type'    => 'select',
						'title'   => __( 'Variation Price Output', 'kadence-shop-kit' ),
						'options' => array(
							'normal'    => __( 'Show Price Range ($lowest - $highest)', 'kadence-shop-kit' ),
							'lowprice'  => __( 'Show lowest price only', 'kadence-shop-kit' ),
							'highprice' => __( 'Show highest price only', 'kadence-shop-kit' ),
						),
						'default' => 'normal',
					),
					array(
						'id'       => 'before_variation_price',
						'type'     => 'text',
						'title'    => __( 'Archive Text Before Variation Price', 'kadence-shop-kit' ),
						'help'     => __( 'Example: From:', 'kadence-shop-kit' ),
						'required' => array( 'variation_price', '!=', 'normal' ),
					),
					array(
						'id'       => 'after_variation_price',
						'type'     => 'text',
						'title'    => __( 'Archive Text After Variation Price', 'kadence-shop-kit' ),
						'help'     => __( 'Example: Base Price', 'kadence-shop-kit' ),
						'required' => array( 'variation_price', '!=', 'normal' ),
					),
				),
			)
		);
		Kadence_Settings_Engine::set_section(
			self::OPT_NAME,
			array(
				'id'      => 'kt_woo_extra_custom_fields_for_variations',
				'title'   => __( 'Custom Fields for Variations', 'kadence-shop-kit' ),
				'desc'    => __( 'Add custom fields to your product variations.', 'kadence-shop-kit' ),
				'doc_url' => 'https://links.stellarwp.com/shopkit-custom-fields-for-variations',
				'group'   => 'product_variations',
				'fields'  => array_merge(
					array(
						array(
							'id'      => 'feature_custom_fields_for_variations',
							'type'    => 'switch',
							'class'   => 'ks-large-toggle',
							'title'   => __( 'Enable Custom Fields for Variations', 'kadence-shop-kit' ),
							'help'    => __( 'Store additional data on each product variation that can be displayed on the product page.', 'kadence-shop-kit' ),
							'default' => 0,
						),
					),
					! empty( KWE_Options::get( 'feature_custom_fields_for_variations' ) ) ? array(
						array(
							'id'      => 'feature_custom_fields_for_variations_link',
							'type'    => 'raw',
							'content' => sprintf(
								// Translators: %s is the URL to the Variation Field Groups management page.
								wp_kses( __( 'You can create and manage variation field groups <a href="%s">here</a>.', 'kadence-shop-kit' ), array( 'a' => array( 'href' => array() ) ) ),
								esc_url( admin_url( 'edit.php?post_type=cpt_variation_fields' ) )
							),
						),
					) : array()
				),
			)
		);
		Kadence_Settings_Engine::set_section(
			self::OPT_NAME,
			array(
				'id'           => 'kt_woo_extra_size_charts',
				'title'        => __( 'Size Charts', 'kadence-shop-kit' ),
				'desc'         => __( 'Simplify sizing decisions with easy-to-build size charts that can be applied to one product or to a whole product category. Add size charts to the product page as a tab, or use a button that opens a modal with your site chart.', 'kadence-shop-kit' ),
				'doc_url'      => 'https://links.stellarwp.com/shopkit-size-charts',
				'group'        => 'product_display',
				'illustration' => KADENCE_WOO_EXTRAS_URL . 'inc/assets/images/size-chart-preview.svg',
				'fields'       => array(
					array(
						'id'      => 'size_charts',
						'type'    => 'switch',
						'class'   => 'ks-large-toggle',
						'title'   => __( 'Enable Size Charts', 'kadence-shop-kit' ),
						'help'    => __( 'This gives you options to add popup size charts to products.', 'kadence-shop-kit' ),
						'default' => 0,
					),
					array(
						'id'       => 'size_charts_output_info',
						'type'     => 'info',
						'title'    => __( 'Find Size Charts under the "Products" menu item in your admin.', 'kadence-shop-kit' ),
						'required' => array( 'size_charts', '=', '1' ),
					),
				),
			)
		);
		Kadence_Settings_Engine::set_section(
			self::OPT_NAME,
			array(
				'id'           => 'kt_woo_extra_global_tabs',
				'title'        => __( 'Global Tabs', 'kadence-shop-kit' ),
				'desc'         => __( 'Build dynamic informational tabs using the WordPress block editor to unlock any kind of global tab layout you desire with Shop Kit\'s custom template builder.', 'kadence-shop-kit' ),
				'doc_url'      => 'https://links.stellarwp.com/shopkit-global-tabs',
				'group'        => 'product_display',
				'illustration' => KADENCE_WOO_EXTRAS_URL . 'inc/assets/images/tabs-preview.svg',
				'fields'       => array(
					array(
						'id'      => 'kt_global_tabs',
						'type'    => 'switch',
						'class'   => 'ks-large-toggle',
						'title'   => __( 'Enable Global Tabs', 'kadence-shop-kit' ),
						'help'    => __( 'This allows you to create tabs and apply them globally to products', 'kadence-shop-kit' ),
						'default' => 0,
					),
					array(
						'id'       => 'global_tabs_output_info',
						'type'     => 'info',
						'title'    => __( 'Find Global Tabs under the "Products" Menu item in your admin.', 'kadence-shop-kit' ),
						'required' => array( 'kt_global_tabs', '=', '1' ),
					),
				),
			)
		);
		Kadence_Settings_Engine::set_section(
			self::OPT_NAME,
			array(
				'id'      => 'kt_woo_extra_wishlists',
				'title'   => __( 'Wishlists', 'kadence-shop-kit' ),
				'desc'    => __( 'Enable wishlists for your customers, allowing them to save and share their favorite products.', 'kadence-shop-kit' ),
				'doc_url' => 'https://iconicwp.com/docs/wishlists-for-woocommerce/',
				'group'   => 'merchandising',
				'fields'  => array_merge(
					array(
						array(
							'id'      => 'feature_wishlists',
							'type'    => 'switch',
							'class'   => 'ks-large-toggle',
							'title'   => __( 'Enable Wishlists', 'kadence-shop-kit' ),
							'help'    => __( 'Let customers save and share their favorite products.', 'kadence-shop-kit' ),
							'default' => 0,
						),
					),
					! empty( KWE_Options::get( 'feature_wishlists' ) ) ? array(
						array(
							'id'      => 'wishlists_settings_link',
							'type'    => 'raw',
							'title'   => '',
							'content' => '<a href="' . esc_url( admin_url( 'admin.php?page=iconic-ww-settings' ) ) . '">' . esc_html__( 'Wishlists Settings', 'kadence-shop-kit' ) . '</a>',
						),
					) : array(),
				),
			)
		);
		Kadence_Settings_Engine::set_section(
			self::OPT_NAME,
			array(
				'id'      => 'kt_woo_extra_linked_variations',
				'title'   => __( 'Linked Variations', 'kadence-shop-kit' ),
				'desc'    => __( 'Link separate products together as visual variations, allowing customers to switch between related products seamlessly.', 'kadence-shop-kit' ),
				'doc_url' => 'https://links.stellarwp.com/shopkit-linked-variations',
				'group'   => 'product_variations',
				'fields'  => array_merge(
					array(
						array(
							'id'      => 'feature_linked_variations',
							'type'    => 'switch',
							'class'   => 'ks-large-toggle',
							'title'   => __( 'Enable Linked Variations', 'kadence-shop-kit' ),
							'help'    => __( 'Link separate products together so customers can switch between them as variations.', 'kadence-shop-kit' ),
							'default' => 0,
						),
					),
					! empty( KWE_Options::get( 'feature_linked_variations' ) ) ? array(
						array(
							'id'      => 'feature_linked_variations_link',
							'type'    => 'raw',
							'content' => sprintf(
								// Translators: %s is the URL to the Linked Variations CPT page.
								wp_kses( __( 'You can create and manage linked variation groups <a href="%s">here</a>.', 'kadence-shop-kit' ), array( 'a' => array( 'href' => array() ) ) ),
								esc_url( admin_url( 'edit.php?post_type=cpt_iconic_wlv' ) )
							),
						),
						array(
							'id'      => 'linked_variations_export',
							'type'    => 'raw',
							'title'   => __( 'Export', 'kadence-shop-kit' ),
							'help'    => __( 'Export the data for your linked variation groups.', 'kadence-shop-kit' ),
							'content' => '<a class="button button-secondary" style="margin-top: 10px;" href="' . esc_url( admin_url( 'admin.php?page=kadence-shop-kit-settings&action=download_csv&_wpnonce=' . wp_create_nonce( 'iconic-wlv-export' ) ) ) . '">' . esc_html__( 'Export Data', 'kadence-shop-kit' ) . '</a>',
						),
					) : array(),
				),
			)
		);
		Kadence_Settings_Engine::set_section(
			self::OPT_NAME,
			array(
				'id'      => 'kt_woo_extra_product_configurator',
				'title'   => __( 'Product Configurator', 'kadence-shop-kit' ),
				'desc'    => __( 'Build a custom product configurator to let customers build their own products step by step.', 'kadence-shop-kit' ),
				'doc_url' => 'https://links.stellarwp.com/shopkit-product-configurator',
				'group'   => 'product_variations',
				'fields'  => array_merge(
					array(
						array(
							'id'      => 'feature_product_configurator',
							'type'    => 'switch',
							'class'   => 'ks-large-toggle',
							'title'   => __( 'Enable Product Configurator', 'kadence-shop-kit' ),
							'help'    => __( 'Let customers configure their own products step by step.', 'kadence-shop-kit' ),
							'default' => 0,
						),
					),
					! empty( KWE_Options::get( 'feature_product_configurator' ) ) ? array(
						array(
							'id'      => 'product_configurator_settings_link',
							'type'    => 'raw',
							'title'   => '',
							'content' => '<a href="' . esc_url( admin_url( 'admin.php?page=iconic-woo-product-configurator-settings' ) ) . '">' . esc_html__( 'Product Configurator Settings', 'kadence-shop-kit' ) . '</a>',
						),
					) : array(),
				),
			)
		);
		Kadence_Settings_Engine::set_section(
			self::OPT_NAME,
			array(
				'id'      => 'kt_woo_extra_show_single_variations',
				'title'   => __( 'Show Single Variations', 'kadence-shop-kit' ),
				'desc'    => __( 'Show WooCommerce product variations as individual products in the shop catalog.', 'kadence-shop-kit' ),
				'doc_url' => 'https://links.stellarwp.com/shopkit-show-single-variations',
				'group'   => 'product_variations',
				'fields'  => array_merge(
					array(
						array(
							'id'      => 'feature_show_single_variations',
							'type'    => 'switch',
							'class'   => 'ks-large-toggle',
							'title'   => __( 'Enable Show Single Variations', 'kadence-shop-kit' ),
							'help'    => __( 'Display product variations as individual products in the shop catalog.', 'kadence-shop-kit' ),
							'default' => 0,
						),
					),
					! empty( KWE_Options::get( 'feature_show_single_variations' ) ) ? array(
						array(
							'id'      => 'show_single_variations_settings_link',
							'type'    => 'raw',
							'title'   => '',
							'content' => '<a href="' . esc_url( admin_url( 'admin.php?page=iconic-wssv-settings' ) ) . '">' . esc_html__( 'Show Single Variations Settings', 'kadence-shop-kit' ) . '</a>',
						),
					) : array(),
				),
			)
		);
		Kadence_Settings_Engine::set_section(
			self::OPT_NAME,
			array(
				'id'      => 'kt_woo_extra_bundled_products',
				'title'   => __( 'Bundled Products', 'kadence-shop-kit' ),
				'desc'    => __( 'Group multiple products together as a bundle, with optional discounts and an "Add All to Cart" button.', 'kadence-shop-kit' ),
				'doc_url' => 'https://links.stellarwp.com/shopkit-bundled-products',
				'group'   => 'merchandising',
				'fields'  => array(
					array(
						'id'      => 'feature_bundled_products',
						'type'    => 'switch',
						'class'   => 'ks-large-toggle',
						'title'   => __( 'Enable Bundled Products', 'kadence-shop-kit' ),
						'help'    => __( 'Group multiple products together as a bundle with optional discounts.', 'kadence-shop-kit' ),
						'default' => 0,
					),
				),
			)
		);
		Kadence_Settings_Engine::set_section(
			self::OPT_NAME,
			array(
				'id'      => 'kt_woo_extra_optimized_checkout',
				'title'   => __( 'Optimized Checkout', 'kadence-shop-kit' ),
				'desc'    => __( 'Optimized multi-step checkout for WooCommerce with a modern, distraction-free experience.', 'kadence-shop-kit' ),
				'doc_url' => 'https://links.stellarwp.com/shopkit-optimized-checkout',
				'group'   => 'cart_checkout',
				'fields'  => array_merge(
					array(
						array(
							'id'      => 'feature_flux_checkout',
							'type'    => 'switch',
							'class'   => 'ks-large-toggle',
							'title'   => __( 'Enable Optimized Checkout', 'kadence-shop-kit' ),
							'help'    => __( 'Replace the default checkout with a modern, distraction-free multi-step experience.', 'kadence-shop-kit' ),
							'default' => 0,
						),
					),
					! empty( KWE_Options::get( 'feature_flux_checkout' ) ) ? array(
						array(
							'id'      => 'flux_checkout_settings_link',
							'type'    => 'raw',
							'title'   => '',
							'content' => '<a href="' . esc_url( admin_url( 'admin.php?page=iconic-flux-settings' ) ) . '">' . esc_html__( 'Optimized Checkout Settings', 'kadence-shop-kit' ) . '</a>',
						),
					) : array(),
				),
			)
		);
		Kadence_Settings_Engine::set_section(
			self::OPT_NAME,
			array(
				'id'      => 'kt_woo_extra_delivery_slots',
				'title'   => __( 'Delivery Slots', 'kadence-shop-kit' ),
				'desc'    => __( 'Allow your customers to select a delivery slot for their order.', 'kadence-shop-kit' ),
				'doc_url' => 'https://links.stellarwp.com/shopkit-delivery-slots',
				'group'   => 'cart_checkout',
				'fields'  => array_merge(
					array(
						array(
							'id'      => 'feature_delivery_slots',
							'type'    => 'switch',
							'class'   => 'ks-large-toggle',
							'title'   => __( 'Enable Delivery Slots', 'kadence-shop-kit' ),
							'help'    => __( 'Let customers choose a delivery date and time slot during checkout.', 'kadence-shop-kit' ),
							'default' => 0,
						),
					),
					! empty( KWE_Options::get( 'feature_delivery_slots' ) ) ? array(
						array(
							'id'      => 'delivery_slots_settings_link',
							'type'    => 'raw',
							'title'   => '',
							'content' => '<a href="' . esc_url( admin_url( 'admin.php?page=jckwds-settings' ) ) . '">' . esc_html__( 'Delivery Slots Settings', 'kadence-shop-kit' ) . '</a>',
						),
					) : array(),
				),
			)
		);
		Kadence_Settings_Engine::set_section(
			self::OPT_NAME,
			array(
				'id'           => 'kt_woo_extra_snackbar_style_notices',
				'title'        => __( 'Snackbar Style Notices', 'kadence-shop-kit' ),
				'desc'         => __( 'Display succinct messages that clear after a short delay to encourage desired shopper behavior or provide helpful yet non-intrusive confirmation notices. Helpful for lightweight yet helpful messages such as add to cart confirmation and more.', 'kadence-shop-kit' ),
				'doc_url'      => 'https://links.stellarwp.com/shopkit-snackbar-notices',
				'group'        => 'conversions',
				'illustration' => KADENCE_WOO_EXTRAS_URL . 'inc/assets/images/snack-bar-preview.svg',
				'fields'       => array(
					array(
						'id'      => 'snackbar_notices',
						'type'    => 'switch',
						'class'   => 'ks-large-toggle',
						'title'   => __( 'Enable Snackbar Style Notices', 'kadence-shop-kit' ),
						'help'    => __( 'This changes the default notice style in woocommerce from a banner in the page content to a fixed slide up that is dismissible. </br>This feature only affects notices in the classic checkout and cart experience. It will not affect notices in the cart or checkout blocks.', 'kadence-shop-kit' ),
						'default' => 0,
					),
					array(
						'id'       => 'snackbar_cart',
						'type'     => 'switch',
						'title'    => __( 'Enable Snackbar Style Notices for Cart Page', 'kadence-shop-kit' ),
						'default'  => 0,
						'required' => array( 'snackbar_notices', '=', '1' ),
					),
					array(
						'id'       => 'snackbar_checkout',
						'type'     => 'switch',
						'title'    => __( 'Enable Snackbar Style Notices for Checkout Page', 'kadence-shop-kit' ),
						'default'  => 0,
						'required' => array( 'snackbar_notices', '=', '1' ),
					),
				),
			)
		);
		Kadence_Settings_Engine::set_section(
			self::OPT_NAME,
			array(
				'id'           => 'kt_woo_extra_conditional_cart_banners',
				'title'        => __( 'Conditional Cart Banners', 'kadence-shop-kit' ),
				'desc'         => __( 'Create custom cart messages that target specific carts based on cart contents, total price, or total weight of items in the cart. Generate personalized upsells specific to the shopper\'s experience, or offer promotions to encourage another product purchase or choosing a product with more value.', 'kadence-shop-kit' ),
				'doc_url'      => 'https://links.stellarwp.com/shopkit-cart-banners',
				'illustration' => KADENCE_WOO_EXTRAS_URL . 'inc/assets/images/cart-banner-preview.svg',
				'group'        => 'conversions',
				'fields'       => array(
					array(
						'id'      => 'kt_cart_notice',
						'type'    => 'switch',
						'class'   => 'ks-large-toggle',
						'title'   => __( 'Enable Cart Banners', 'kadence-shop-kit' ),
						'help'    => __( 'This gives you options to add specialized notices to the cart page to entice with specials and upsell products.', 'kadence-shop-kit' ),
						'default' => 0,
					),
					array(
						'id'       => 'cart_notice_output_info',
						'type'     => 'info',
						'title'    => __( 'Find Cart Banners under the "Woocommerce" Menu item in your admin.', 'kadence-shop-kit' ),
						'required' => array( 'kt_cart_notice', '=', '1' ),
					),
				),
			)
		);
		Kadence_Settings_Engine::set_section(
			self::OPT_NAME,
			array(
				'id'           => 'kt_woo_extra_checkout_coupon_modal',
				'title'        => __( 'Checkout Coupon Modal', 'kadence-shop-kit' ),
				'desc'         => __( 'Add a coupon input field as a link in the order overview and open a modal to input the coupon. This feature is only available for the standard checkout, not the checkout block.', 'kadence-shop-kit' ),
				'doc_url'      => 'https://links.stellarwp.com/shopkit-checkout-coupon-modal',
				'illustration' => KADENCE_WOO_EXTRAS_URL . 'inc/assets/images/coupon-modal-preview.svg',
				'group'        => 'cart_checkout',
				'fields'       => array(
					array(
						'id'      => 'kt_coupon_modal_checkout',
						'type'    => 'switch',
						'class'   => 'ks-large-toggle',
						'title'   => __( 'Enable Coupon Checkout Modal.', 'kadence-shop-kit' ),
						'help'    => __( 'This allows you to display the coupon input field as a link in the order overview and opens a modal to input coupon. Note this only works with standard checkout, not the checkout block.', 'kadence-shop-kit' ),
						'default' => 0,
					),
					array(
						'id'       => 'checkout_coupon_link_placement',
						'type'     => 'select',
						'title'    => __( 'Coupon Modal Link Placement', 'kadence-shop-kit' ),
						'options'  => array(
							'before_review'          => __( 'Before Order Review', 'kadence-shop-kit' ),
							'before_table_total'     => __( 'In Order Review table before total', 'kadence-shop-kit' ),
							'after_table_total'      => __( 'In Order Review table after total', 'kadence-shop-kit' ),
							'between_review_payment' => __( 'Between Order Review and Payment', 'kadence-shop-kit' ),
							'after_payment'          => __( 'After Payment', 'kadence-shop-kit' ),
						),
						'default'  => 'between_review_payment',
						'required' => array( 'kt_coupon_modal_checkout', '=', '1' ),
					),
					array(
						'id'       => 'checkout_coupon_pre',
						'type'     => 'text',
						'title'    => __( 'Pre Modal Link Text', 'kadence-shop-kit' ),
						'help'     => __( 'Standard: Have a promo code?', 'kadence-shop-kit' ),
						'default'  => __( 'Have a promo code?', 'kadence-shop-kit' ),
						'required' => array( 'kt_coupon_modal_checkout', '=', '1' ),
					),
					array(
						'id'       => 'checkout_coupon_link',
						'type'     => 'text',
						'title'    => __( 'Modal Link Text', 'kadence-shop-kit' ),
						'help'     => __( 'Standard: Click here to enter your code.', 'kadence-shop-kit' ),
						'default'  => __( 'Click here to enter your code.', 'kadence-shop-kit' ),
						'required' => array( 'kt_coupon_modal_checkout', '=', '1' ),
					),
					array(
						'id'       => 'checkout_coupon_desc',
						'type'     => 'text',
						'title'    => __( 'Modal Description', 'kadence-shop-kit' ),
						'help'     => __( 'Standard: If you have a promo code, please apply it below.', 'kadence-shop-kit' ),
						'default'  => __( 'If you have a promo code, please apply it below.', 'kadence-shop-kit' ),
						'required' => array( 'kt_coupon_modal_checkout', '=', '1' ),
					),
					array(
						'id'       => 'checkout_coupon_placeholder',
						'type'     => 'text',
						'title'    => __( 'Input Placeholder', 'kadence-shop-kit' ),
						'help'     => __( 'Standard: Promo code', 'kadence-shop-kit' ),
						'default'  => __( 'Promo code', 'kadence-shop-kit' ),
						'required' => array( 'kt_coupon_modal_checkout', '=', '1' ),
					),
					array(
						'id'       => 'checkout_coupon_apply',
						'type'     => 'text',
						'title'    => __( 'Apply Button', 'kadence-shop-kit' ),
						'help'     => __( 'Standard: Apply Code', 'kadence-shop-kit' ),
						'default'  => __( 'Apply Code', 'kadence-shop-kit' ),
						'required' => array( 'kt_coupon_modal_checkout', '=', '1' ),
					),
				),
			)
		);
		Kadence_Settings_Engine::set_section(
			self::OPT_NAME,
			array(
				'id'           => 'kt_woo_extra_custom_checkout_fields',
				'title'        => __( 'Custom Checkout Fields', 'kadence-shop-kit' ),
				'desc'         => __( 'Reduce checkout friction by customizing the checkout to your customers unique needs. Enable and disable checkout fields or create your own fields using the checkout manager. Easily customize your checkout forms and control which fields are added to WooCommerce emails.', 'kadence-shop-kit' ),
				'doc_url'      => 'https://links.stellarwp.com/shopkit-custom-checkout-fields',
				'group'        => 'cart_checkout',
				'illustration' => KADENCE_WOO_EXTRAS_URL . 'inc/assets/images/checkout-preview.svg',
				'fields'       => array(
					array(
						'id'      => 'kt_checkout_editor',
						'type'    => 'switch',
						'class'   => 'ks-large-toggle',
						'title'   => __( 'Enable Checkout Fields Editor', 'kadence-shop-kit' ),
						'help'    => __( 'This gives you total control over your checkout fields and allows you to add custom fields. Note this only works with standard checkout, not the checkout block.', 'kadence-shop-kit' ),
						'default' => 0,
					),
					array(
						'id'       => 'checkout_editor_output_info',
						'type'     => 'info',
						'title'    => __( 'Find the checkout editor under the "Woocommerce" Menu item in your admin.', 'kadence-shop-kit' ),
						'required' => array( 'kt_checkout_editor', '=', '1' ),
					),
				),
			)
		);
		Kadence_Settings_Engine::set_section(
			self::OPT_NAME,
			array(
				'id'      => 'kt_woo_extra_sales_booster',
				'title'   => __( 'Sales Booster', 'kadence-shop-kit' ),
				'desc'    => __( 'Increase your average order value with strategic cross-sells and order bumps.', 'kadence-shop-kit' ),
				'doc_url' => 'https://links.stellarwp.com/shopkit-sales-booster',
				'group'   => 'conversions',
				'fields'  => array_merge(
					array(
						array(
							'id'      => 'feature_sales_booster',
							'type'    => 'switch',
							'class'   => 'ks-large-toggle',
							'title'   => __( 'Enable Sales Booster', 'kadence-shop-kit' ),
							'help'    => __( 'Increase average order value with cross-sells and order bumps.', 'kadence-shop-kit' ),
							'default' => 0,
						),
					),
					! empty( KWE_Options::get( 'feature_sales_booster' ) ) ? array(
						array(
							'id'      => 'sales_booster_settings_link',
							'type'    => 'raw',
							'title'   => '',
							'content' => '<a href="' . esc_url( admin_url( 'admin.php?page=iconic-wsb-settings' ) ) . '">' . esc_html__( 'Sales Booster Settings', 'kadence-shop-kit' ) . '</a>',
						),
					) : array(),
				),
			)
		);
		Kadence_Settings_Engine::set_section(
			self::OPT_NAME,
			array(
				'id'           => 'kt_woo_extra_account_pages',
				'title'        => __( 'Account Pages', 'kadence-shop-kit' ),
				'desc'         => __( 'Add and manage pages in your WooCommerce "My Account" area.', 'kadence-shop-kit' ),
				'doc_url'      => 'https://links.stellarwp.com/shopkit-account-pages',
				'group'        => 'customer_accounts',
				'illustration' => KADENCE_WOO_EXTRAS_URL . 'inc/assets/images/checkout-preview.svg',
				'fields'       => array(
					array(
						'id'      => 'feature_account_pages',
						'type'    => 'switch',
						'class'   => 'ks-large-toggle',
						'title'   => __( 'Enable Account Pages', 'kadence-shop-kit' ),
						'default' => 0,
					),
					array(
						'id'       => 'kt_account_pages_allow_form_tags',
						'type'     => 'switch',
						'class'    => 'ks-large-toggle',
						'title'    => __( 'Allow Form Tags', 'kadence-shop-kit' ),
						'help'     => __( 'Enable this setting to allow form elements in the Account pages, which may be required for certain third-party form plugins like Gravity Forms, Ninja Forms etc. Exercise caution when enabling this setting, as it could potentially introduce security risks if misused. Only enable if you trust the Form plugin author.', 'kadence-shop-kit' ),
						'default'  => 0,
						'required' => array( 'feature_account_pages', '=', '1' ),
					),
				),
			)
		);
		Kadence_Settings_Engine::set_section(
			self::OPT_NAME,
			array(
				'id'           => 'kt_woo_extra_cat_desc',
				'title'        => __( 'Extra Category Description', 'kadence-shop-kit' ),
				'desc'         => __( 'Add an extra description box for each category to allow you to place content below the products on your category page.', 'kadence-shop-kit' ),
				'doc_url'      => 'https://links.stellarwp.com/shopkit-category-description',
				'group'        => 'product_display',
				'illustration' => KADENCE_WOO_EXTRAS_URL . 'inc/assets/images/category-desc-preview.svg',
				'fields'       => array(
					array(
						'id'      => 'kt_extra_cat',
						'type'    => 'switch',
						'class'   => 'ks-large-toggle',
						'title'   => __( 'Enable Extra Category Description Box', 'kadence-shop-kit' ),
						'help'    => __( 'This gives you an extra description box for each category to allow you to place content below the products on your category page.', 'kadence-shop-kit' ),
						'default' => 0,
					),
				),
			)
		);
	}
	/**
	 * Get the attribute terms available.
	 *
	 * @return array
	 */
	public function get_attribute_terms() {
		$attribute_terms = array( '' => __( 'First Attribute', 'kadence-shop-kit' ) );
		if ( ! is_admin() || ! class_exists( 'woocommerce' ) || ! function_exists( 'wc_get_attribute_taxonomies' ) ) {
			return $attribute_terms;
		}
		$attributes = wc_get_attribute_taxonomies();
		if ( ! empty( $attributes ) ) {
			foreach ( $attributes as $attribute ) {
				$attribute_terms[ $attribute->attribute_name ] = $attribute->attribute_label;
			}
		}
		return $attribute_terms;
	}
	/**
	 * Get the attribute terms available.
	 *
	 * @return array
	 */
	public function get_quickview_templates_options() {
		$options_arr = array();

		$args = array(
			'post_type'              => 'kadence_wootemplate',
			'no_found_rows'          => true,
			'update_post_term_cache' => false,
			'post_status'            => 'publish',
			'numberposts'            => 333,
			'order'                  => 'ASC',
			'orderby'                => 'menu_order',
			'suppress_filters'       => false,
			'meta_key'               => '_kad_wootemplate_type',
			'meta_value'             => 'quickview',
		);

		$posts = get_posts( $args );

		if ( $posts ) {
			foreach ( $posts as $the_post ) {
				$title              = $the_post->post_title;
				$id                 = $the_post->ID;
				$options_arr[ $id ] = $title;
			}
		}

		if ( $options_arr ) {
			$options_arr[''] = '-';
			return $options_arr;
		} else {
			return array(
				'' => 'No Quickview templates found',
			);
		}
	}
}
new Kadence_Woo_Extras_Settings();
