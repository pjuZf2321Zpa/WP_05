<?php
/**
 * Uplink ServiceProvider for Kadence Shop Kit.
 *
 * Re-enables Uplink for legacy license-key support. Harbor remains the
 * primary licensing system; Uplink is loaded so existing customers with
 * legacy keys (including pre-uplink iThemes/API-Manager keys) continue to
 * validate and migrate cleanly.
 *
 * @since 3.0.3
 *
 * @package KadenceWP\KadenceShopKit\Uplink
 */

namespace KadenceWP\KadenceShopKit\Uplink;

use KadenceWP\KadenceShopKit\App;
use KadenceWP\KadenceShopKit\lucatume\DI52\ServiceProvider;
use KadenceWP\KadenceShopKit\StellarWP\Uplink\Config;
use KadenceWP\KadenceShopKit\StellarWP\Uplink\Register;
use KadenceWP\KadenceShopKit\StellarWP\Uplink\Uplink;

/**
 * Bootstraps Uplink for the Kadence Shop Kit.
 *
 * @since 3.0.3
 */
class Provider extends ServiceProvider {

	/**
	 * Register bindings in the container.
	 *
	 * @since 3.0.3
	 *
	 * @return void
	 */
	public function register(): void {
		Config::set_container( App::container() );
		Config::set_hook_prefix( Manager::get_plugin_slug() );

		$this->container->singleton( Manager::class );
	}

	/**
	 * Boot the provider: initialise Uplink, register the resource, and wire
	 * the filters / actions that surface the legacy license UI.
	 *
	 * @since 3.0.3
	 *
	 * @return void
	 */
	public function boot(): void {
		Uplink::init();

		$slug = Manager::get_plugin_slug();

		Register::plugin(
			$slug,
			Manager::get_plugin_name(),
			KADENCE_WOO_EXTRAS_VERSION,
			Manager::plugin_basename(),
			Helper::class,
			Helper::class
		);

		add_filter( "stellarwp/uplink/{$slug}/api_get_base_url", $this->container->callback( Manager::class, 'filter_api_base_url' ) );
		add_filter( "stellarwp/uplink/{$slug}/messages/valid_key", $this->container->callback( Manager::class, 'filter_valid_key_message' ) );
		add_filter( "stellarwp/uplink/{$slug}/admin_js_source", $this->container->callback( Manager::class, 'filter_admin_js_source' ) );
		add_filter( "stellarwp/uplink/{$slug}/admin_css_source", $this->container->callback( Manager::class, 'filter_admin_css_source' ) );
		add_filter( "stellarwp/uplink/{$slug}/field-template_path", $this->container->callback( Manager::class, 'filter_field_template_path' ) );
		add_filter( "stellarwp/uplink/{$slug}/license_field_html_render", $this->container->callback( Manager::class, 'get_license_field_html' ), 10, 2 );

		add_action( "stellarwp/uplink/{$slug}/license_field_after_form", $this->container->callback( Manager::class, 'render_harbor_managed_notice' ) );
		add_action( 'network_admin_menu', $this->container->callback( Manager::class, 'create_admin_pages' ), 1 );
		add_action( 'admin_menu', $this->container->callback( Manager::class, 'register_legacy_license_page' ), PHP_INT_MAX );
		add_action( 'network_admin_edit_kadence_license_update_network_options', $this->container->callback( Manager::class, 'update_network_options' ) );
		add_action( 'admin_init', $this->container->callback( Manager::class, 'update_licensing_data' ), 2 );
	}
}
