<?php
/**
 * Marker class registered with Uplink as both the plugin and license class.
 *
 * Uplink requires a class reference for each registered plugin; this stub
 * exists solely to satisfy that contract — it carries no behaviour.
 *
 * @since 3.0.3
 *
 * @package KadenceWP\KadenceShopKit\Uplink
 */

namespace KadenceWP\KadenceShopKit\Uplink;

/**
 * Marker class registered with Uplink as both the plugin and license class.
 */
class Helper {

	/**
	 * @var string Helper data.
	 */
	const DATA = 'ktl_wc_order_mK9Qx2Pv8r4nL_bm_jzTRk86Yd5bm';
}
