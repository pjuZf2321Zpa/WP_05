<?php
/**
 * Behavioural manager for the Kadence Shop Kit Uplink integration.
 *
 * Provider keeps only the hook wiring and Uplink registration calls;
 * everything else — the legacy-license migration, the admin pages,
 * the field rendering, the Harbor bridging filter, and the Uplink
 * update-check teardown — lives here.
 *
 * @since 3.0.3
 *
 * @package KadenceWP\KadenceShopKit\Uplink
 */

namespace KadenceWP\KadenceShopKit\Uplink;

use KadenceWP\KadenceShopKit\StellarWP\Uplink\Config;
use function KadenceWP\KadenceShopKit\StellarWP\Uplink\get_license_field;
use function KadenceWP\KadenceShopKit\StellarWP\Uplink\get_license_key;
use function KadenceWP\KadenceShopKit\StellarWP\Uplink\set_license_key;
use function is_plugin_active_for_network;

/**
 * Holds the Uplink-side behaviour for Kadence Shop Kit.
 *
 * @since 3.0.3
 */
class Manager {
	/**
	 * Uplink-side slug for the registered resource.
	 *
	 * While the legacy plugin slug was 'kadence-woo-extras', Uplink does expect the slug to be 'kadence-shop-kit'.
	 *
	 * @since 3.0.3
	 *
	 * @var string
	 */
	private const PLUGIN_SLUG = 'kadence-shop-kit';

	/**
	 * Display name used when registering the resource with Uplink.
	 *
	 * @since 3.0.3
	 *
	 * @var string
	 */
	private const PLUGIN_NAME = 'Kadence Shop Kit';

	/**
	 * One-time migration flag option key. Once set, the legacy → uplink key
	 * migration is skipped for the lifetime of the install.
	 *
	 * @since 3.0.3
	 *
	 * @var string
	 */
	private const MIGRATION_FLAG_OPTION = 'kadence-shop-kit-license-updated';

	/**
	 * Legacy option name holding pre-uplink API-Manager / iThemes credentials.
	 *
	 * @since 3.0.3
	 *
	 * @var string
	 */
	private const LEGACY_LICENSE_OPTION = 'kt_api_manager_kadence_woo_extras_data';

	/**
	 * Transient key used to back off the iThemes credential exchange after a
	 * failed HTTP call. Prevents hammering kadencewp.com on every admin
	 * request when the exchange is failing transiently.
	 *
	 * @since 3.0.3
	 *
	 * @var string
	 */
	private const ITHEMES_BACKOFF_TRANSIENT = 'kadence-shop-kit-itheme-migration-backoff';

	/**
	 * Accessor for the Uplink resource slug.
	 *
	 * @since 3.0.3
	 *
	 * @return string
	 */
	public static function get_plugin_slug(): string {
		return self::PLUGIN_SLUG;
	}

	/**
	 * Accessor for the display name registered with Uplink.
	 *
	 * @since 3.0.3
	 *
	 * @return string
	 */
	public static function get_plugin_name(): string {
		return self::PLUGIN_NAME;
	}

	/**
	 * Build the canonical plugin basename used by Uplink registration and the
	 * network-active checks.
	 *
	 * @since 3.0.3
	 *
	 * @return string The plugin's basename (e.g. `kadence-shop-kit/kadence-shop-kit.php`).
	 */
	public static function plugin_basename(): string {
		return plugin_basename( trailingslashit( KADENCE_WOO_EXTRAS_PATH ) . 'kadence-shop-kit.php' );
	}

	/**
	 * Override the Uplink API endpoint with the Kadence licensing host.
	 *
	 * @since 3.0.3
	 *
	 * @return string
	 */
	public function filter_api_base_url(): string {
		return 'https://licensing.kadencewp.com';
	}

	/**
	 * Replace Uplink's default "valid key" message with a Kadence-branded one.
	 *
	 * @since 3.0.3
	 *
	 * @return string
	 */
	public function filter_valid_key_message(): string {
		return esc_html__( 'Your license key is valid', 'kadence-shop-kit' );
	}

	/**
	 * Point Uplink at our local admin JS bundle.
	 *
	 * @since 3.0.3
	 *
	 * @return string
	 */
	public function filter_admin_js_source(): string {
		return KADENCE_WOO_EXTRAS_URL . 'inc/Common/Uplink/admin-views/license-admin.js';
	}

	/**
	 * Point Uplink at our local admin CSS bundle.
	 *
	 * @since 3.0.3
	 *
	 * @return string
	 */
	public function filter_admin_css_source(): string {
		return KADENCE_WOO_EXTRAS_URL . 'inc/Common/Uplink/admin-views/license-admin.css';
	}

	/**
	 * Point Uplink at our local license-field template.
	 *
	 * @since 3.0.3
	 *
	 * @return string
	 */
	public function filter_field_template_path(): string {
		return KADENCE_WOO_EXTRAS_PATH . 'inc/Common/Uplink/admin-views/field.php';
	}

	/**
	 * Render Harbor's canonical "legacy licensing" info notice, signalling that
	 * primary license management has moved to the unified Harbor UI.
	 *
	 * Wired to the `stellarwp/uplink/{slug}/license_field_after_form` template
	 * hook so it renders wherever the Uplink license field is shown, and also
	 * invoked manually from `render_network_settings_page()` because that page
	 * builds its form by hand rather than via the Uplink template.
	 *
	 * @since 3.0.3
	 *
	 * @return void
	 */
	public function render_harbor_managed_notice(): void {
		if ( ! function_exists( 'lw_harbor_display_legacy_license_page_notice' ) ) {
			return;
		}

		lw_harbor_display_legacy_license_page_notice( self::get_plugin_name() );
	}

	/**
	 * Register the Legacy Licensing submenu under the Shop Kit top-level menu.
	 *
	 * @since 3.0.3
	 *
	 * @return void
	 */
	public function register_legacy_license_page(): void {
		add_submenu_page(
			'kadence-shop-kit-settings',
			__( 'Legacy Licensing - Kadence Shop Kit', 'kadence-shop-kit' ),
			__( 'Legacy Licensing', 'kadence-shop-kit' ),
			'manage_options',
			'kadence-shop-kit-legacy-licensing',
			[ $this, 'render_legacy_license_page' ]
		);
	}

	/**
	 * Render the Legacy Licensing admin page.
	 *
	 * @since 3.0.3
	 *
	 * @return void
	 */
	public function render_legacy_license_page(): void {
		$is_network_controlled = function_exists( 'is_plugin_active_for_network' )
			&& is_plugin_active_for_network( self::plugin_basename() )
			&& $this->is_network_authorize_enabled();
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Legacy Licensing - Kadence Shop Kit', 'kadence-shop-kit' ); ?></h1>
			<div class="card">
				<p>
					<?php esc_html_e( 'Please enter your legacy Kadence license key here. Customers with a unified Liquid Web license key should visit the "Licensing" link in the Shop Kit menu.', 'kadence-shop-kit' ); ?>
				</p>
				<?php if ( $is_network_controlled ) : ?>
					<p><?php esc_html_e( 'Network License Controlled', 'kadence-shop-kit' ); ?></p>
				<?php else : ?>
					<div class="stellarwp-uplink__license-field">
						<?php get_license_field()->render_single( self::get_plugin_slug(), false ); ?>
					</div>
				<?php endif; ?>
			</div>
		</div>
		<?php
	}

	/**
	 * Build the HTML for the inline license field.
	 *
	 * @since 3.0.3
	 *
	 * @param string              $field Field markup as passed by the upstream filter (replaced wholesale).
	 * @param array<string,mixed> $args  Field arguments supplied by Uplink.
	 *
	 * @return string
	 */
	public function get_license_field_html( string $field, array $args ): string {
		$value        = self::arg_string( $args, 'value' );
		$has_value    = '' !== $value;
		$obfuscated   = $has_value
			? '<input type="text" name="obfuscated-key" disabled value="' . esc_attr( $this->obfuscate_key( $value ) ) . '" class="regular-text stellarwp-uplink__settings-field-obfuscated" />'
			: '';
		$clear_button = $has_value
			? '<button type="submit" class="button button-secondary stellarwp-uplink-license-key-field-clear">' . esc_html__( 'Clear', 'kadence-shop-kit' ) . '</button>'
			: '';

		return sprintf(
			'<div class="%6$s" id="%2$s" data-slug="%2$s" data-plugin="%9$s" data-plugin-slug="%10$s" data-action="%11$s">
					<fieldset class="stellarwp-uplink__settings-group">
						<div class="stellarwp-uplink__settings-group-inline">
						%12$s
						%13$s
						</div>
						<input type="%1$s" name="%3$s" value="%4$s" placeholder="%5$s" class="regular-text stellarwp-uplink__settings-field" />
						%7$s
					</fieldset>
					%8$s
				</div>',
			$has_value ? 'hidden' : 'text',
			esc_attr( self::arg_string( $args, 'path' ) ),
			esc_attr( self::arg_string( $args, 'id' ) ),
			esc_attr( $value ),
			esc_attr__( 'License Key', 'kadence-shop-kit' ),
			esc_attr( self::arg_string( $args, 'html_classes' ) ),
			self::arg_string( $args, 'html' ),
			'<input type="hidden" value="' . esc_attr( wp_create_nonce( 'stellarwp_uplink_group_' ) ) . '" class="wp-nonce" />',
			esc_attr( self::arg_string( $args, 'plugin' ) ),
			esc_attr( self::arg_string( $args, 'plugin_slug' ) ),
			esc_attr( Config::get_hook_prefix_underscored() ),
			$obfuscated,
			$clear_button
		);
	}

	/**
	 * Check whether the install is in network-authorize mode.
	 *
	 * @since 3.0.3
	 *
	 * @return bool
	 */
	public function is_network_authorize_enabled(): bool {
		$network_enabled = ! apply_filters( 'kadence_activation_individual_multisites', true );
		if ( ! $network_enabled && defined( 'KADENCE_ACTIVATION_NETWORK_ENABLED' ) && KADENCE_ACTIVATION_NETWORK_ENABLED ) {
			$network_enabled = true;
		}
		return $network_enabled;
	}

	/**
	 * Build the admin URL of the Legacy Licensing page, picking the network
	 * admin variant when the install is network-licensed (matches the
	 * registration logic in `create_admin_pages()` and `update_network_options()`).
	 *
	 * @since 3.0.3
	 *
	 * @return string
	 */
	public function get_license_page_url(): string {
		if (
			function_exists( 'is_plugin_active_for_network' )
			&& is_plugin_active_for_network( self::plugin_basename() )
			&& $this->is_network_authorize_enabled()
		) {
			return network_admin_url( 'settings.php?page=kadence-shop-kit-legacy-licensing' );
		}

		return admin_url( 'admin.php?page=kadence-shop-kit-legacy-licensing' );
	}

	/**
	 * Save handler for the network-admin license page. Hooked to a custom
	 * `network_admin_edit_*` action because network-admin pages can't use
	 * `options.php` directly.
	 *
	 * @since 3.0.3
	 *
	 * @return void
	 */
	public function update_network_options(): void {
		if ( ! isset( $_REQUEST['option_page'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- nonce is verified immediately below via check_admin_referer().
			return;
		}

		$options_id = sanitize_text_field( wp_unslash( $_REQUEST['option_page'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- nonce is verified immediately below via check_admin_referer().

		check_admin_referer( $options_id . '-options' );

		$license_field = 'stellarwp_uplink_license_key_' . self::get_plugin_slug();
		if ( isset( $_POST[ $license_field ] ) ) {
			$value = trim( sanitize_text_field( wp_unslash( $_POST[ $license_field ] ) ) );
			set_license_key( self::get_plugin_slug(), $value );

			wp_safe_redirect( network_admin_url( 'settings.php?page=kadence-shop-kit-legacy-licensing' ) );
			exit;
		}
	}

	/**
	 * Register the network-admin License page when the install is
	 * network-licensed.
	 *
	 * @since 3.0.3
	 *
	 * @return void
	 */
	public function create_admin_pages(): void {
		if (
			function_exists( 'is_plugin_active_for_network' )
			&& is_plugin_active_for_network( self::plugin_basename() )
			&& $this->is_network_authorize_enabled()
		) {
			add_action(
				'network_admin_menu',
				function () {
					add_submenu_page(
						'settings.php',
						__( 'Legacy Licensing - Kadence Shop Kit', 'kadence-shop-kit' ),
						__( 'Legacy Licensing', 'kadence-shop-kit' ),
						'manage_options',
						'kadence-shop-kit-legacy-licensing',
						[ $this, 'render_network_settings_page' ],
						999
					);
				},
				21
			);
		}
	}

	/**
	 * Obfuscate a license key so the middle characters are masked.
	 *
	 * @since 3.0.3
	 *
	 * @param string $key The license key to obfuscate.
	 *
	 * @return string
	 */
	public function obfuscate_key( string $key ): string {
		$start  = 3;
		$length = mb_strlen( $key ) - $start - 3;
		if ( $length <= 0 ) {
			return $key;
		}
		$mask_string = (string) preg_replace( '/\S/', 'X', $key );
		$mask_string = mb_substr( $mask_string, $start, $length );
		return substr_replace( $key, $mask_string, $start, $length );
	}

	/**
	 * Render the network-admin license settings page.
	 *
	 * @since 3.0.3
	 *
	 * @return void
	 */
	public function render_network_settings_page(): void {
		$slug  = self::get_plugin_slug();
		$field = get_license_field();
		$key   = get_license_key( $slug );
		$group = $field->get_group_name( sanitize_title( $slug ) );

		wp_enqueue_script( sprintf( 'stellarwp-uplink-license-admin-%s', $slug ) );
		wp_enqueue_style( sprintf( 'stellarwp-uplink-license-admin-%s', $slug ) );

		echo '<h3>' . esc_html( self::get_plugin_name() ) . '</h3>';
		echo '<form action="edit.php?action=kadence_license_update_network_options" method="post" id="kadence-license-kadence-' . esc_attr( $slug ) . '">';
		settings_fields( $group );

		$html  = sprintf( '<p class="tooltip description">%s</p>', esc_html__( 'A valid license key is required for support and updates', 'kadence-shop-kit' ) );
		$html .= '<div class="license-test-results"><img src="' . esc_url( admin_url( 'images/wpspin_light.gif' ) ) . '" class="ajax-loading-license" alt="Loading" style="display: none"/>';
		$html .= '<div class="key-validity"></div></div>';

		echo '<div class="stellarwp-uplink__license-field">';
		echo '<label for="stellarwp_uplink_license_key_' . esc_attr( $slug ) . '">' . esc_html__( 'License Key', 'kadence-shop-kit' ) . '</label>';

		$args = [
			'type'         => 'text',
			'path'         => self::plugin_basename(),
			'id'           => 'stellarwp_uplink_license_key_' . $slug,
			'value'        => $key,
			'placeholder'  => esc_attr__( 'License Key', 'kadence-shop-kit' ),
			'html_classes' => 'stellarwp-uplink-license-key-field',
			'html'         => $html,
			'plugin'       => self::plugin_basename(),
			'plugin_slug'  => $slug,
		];
		echo $this->get_license_field_html( '', $args ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- HTML is assembled with escaped values inside get_license_field_html().
		echo '</div>';

		if ( empty( $key ) ) {
			submit_button( esc_html__( 'Save Changes', 'kadence-shop-kit' ) );
		}
		echo '</form>';

		$this->render_harbor_managed_notice();
	}

	/**
	 * Migrate any pre-uplink license data (legacy API-Manager / iThemes keys)
	 * into the Uplink option store.
	 *
	 * The migration flag (`kadence-shop-kit-license-updated`) is set only
	 * when there is nothing to migrate or when a key has been successfully
	 * stored. The iThemes credential exchange requires an HTTP round-trip,
	 * so transient failures (network, timeout, malformed response) leave
	 * the flag unset and back off via a 1-hour transient before the next
	 * attempt.
	 *
	 * @since 3.0.3
	 *
	 * @return void
	 */
	public function update_licensing_data(): void {
		if ( get_option( self::MIGRATION_FLAG_OPTION, false ) ) {
			return;
		}
		if ( ! empty( get_license_key( self::get_plugin_slug() ) ) ) {
			return;
		}

		$license_data = $this->get_deprecated_pro_license_data();

		// No legacy data at all — nothing actionable to migrate.
		if ( ! is_array( $license_data ) ) {
			update_option( self::MIGRATION_FLAG_OPTION, true );
			return;
		}

		$api_key     = isset( $license_data['api_key'] ) && is_string( $license_data['api_key'] ) ? $license_data['api_key'] : '';
		$ithemes_key = isset( $license_data['ithemes_key'] ) && is_string( $license_data['ithemes_key'] ) ? $license_data['ithemes_key'] : '';
		$username    = isset( $license_data['username'] ) && is_string( $license_data['username'] ) ? $license_data['username'] : '';

		// Direct API-Manager key — synchronous, always actionable.
		if ( '' !== $api_key ) {
			set_license_key( self::get_plugin_slug(), $api_key );
			update_option( self::MIGRATION_FLAG_OPTION, true );
			return;
		}

		// iThemes credentials require an HTTP exchange. Back off after failures
		// so we don't hit kadencewp.com on every admin request.
		if ( '' !== $ithemes_key && '' !== $username ) {
			if ( get_transient( self::ITHEMES_BACKOFF_TRANSIENT ) ) {
				return;
			}

			$license_key = $this->get_new_key_for_ithemes_user_data( $username, $ithemes_key );
			if ( is_string( $license_key ) && '' !== $license_key ) {
				set_license_key( self::get_plugin_slug(), $license_key );
				update_option( self::MIGRATION_FLAG_OPTION, true );
				return;
			}

			set_transient( self::ITHEMES_BACKOFF_TRANSIENT, time(), HOUR_IN_SECONDS );
			return;
		}

		// Legacy data exists but no actionable fields — nothing more to do.
		update_option( self::MIGRATION_FLAG_OPTION, true );
	}

	/**
	 * Exchange iThemes-era credentials for a current uplink key.
	 *
	 * @since 3.0.3
	 *
	 * @param string $username The iThemes username.
	 * @param string $key      The iThemes private hash.
	 *
	 * @return string|false The new key, or false on failure.
	 */
	public function get_new_key_for_ithemes_user_data( string $username, string $key ) {
		$site_url = (string) network_home_url( '', 'http' );
		$site_url = (string) preg_replace( '/^https/', 'http', $site_url );
		$site_url = (string) preg_replace( '|/$|', '', $site_url );

		$url = add_query_arg(
			[
				'wc-api'       => 'kadence_itheme_key_update',
				'username'     => $username,
				'private_hash' => $key,
				'site_url'     => $site_url,
			],
			'https://www.kadencewp.com/'
		);

		$response = wp_safe_remote_get( $url, [ 'timeout' => 5 ] );
		if ( is_wp_error( $response ) ) {
			return false;
		}

		$body = wp_remote_retrieve_body( $response );
		if ( ! is_string( $body ) || '' === $body ) {
			return false;
		}

		$new_key = json_decode( trim( $body ), true );
		if ( is_string( $new_key ) && 0 === strpos( $new_key, 'ktm' ) ) {
			return $new_key;
		}
		return false;
	}

	/**
	 * Read pre-uplink license data from the legacy option store.
	 *
	 * @since 3.0.3
	 *
	 * @return array<string,mixed>|false
	 */
	public function get_deprecated_pro_license_data() {
		$data = ( is_multisite() && ! apply_filters( 'kadence_activation_individual_multisites', true ) )
			? get_site_option( self::LEGACY_LICENSE_OPTION )
			: get_option( self::LEGACY_LICENSE_OPTION );

		return is_array( $data ) ? $data : false;
	}

	/**
	 * Pull a string value out of an args bag, returning '' when the key is
	 * missing or not a string. Keeps `get_license_field_html()` type-safe over
	 * the `mixed` values Uplink hands through its filter.
	 *
	 * @since 3.0.3
	 *
	 * @param array<string,mixed> $args The args bag.
	 * @param string              $key  The key to look up.
	 *
	 * @return string
	 */
	private static function arg_string( array $args, string $key ): string {
		return isset( $args[ $key ] ) && is_string( $args[ $key ] ) ? $args[ $key ] : '';
	}
}
