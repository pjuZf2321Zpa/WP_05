<?php
/**
 * Legacy license bridge between Uplink storage and Harbor / Herald.
 *
 * Reads the Uplink-stored legacy key and surfaces it in two places:
 *
 * - Harbor's UI consolidation (`lw-harbor/legacy_licenses`) so legacy notices
 *   attach to the right Feature.
 * - WordPress's plugin update transient, pointing the package URL at Herald's
 *   `/legacy/download` endpoint so the same key authorises the install.
 *
 * @since 3.0.3
 *
 * @package KadenceWP\KadenceShopKit\Harbor
 */

namespace KadenceWP\KadenceShopKit\Harbor;

use KadenceWP\KadenceShopKit\StellarWP\Uplink\Admin\Notice as Uplink_Admin_Notice;
use KadenceWP\KadenceShopKit\Uplink\Manager as Uplink_Manager;
use function KadenceWP\KadenceShopKit\StellarWP\Uplink\get_license_key;
use function KadenceWP\KadenceShopKit\StellarWP\Uplink\get_resource;

/**
 * Bridges the Uplink-stored legacy license into Harbor + Herald.
 *
 * @since 3.0.3
 */
class Legacy_License_Integration {
	/**
	 * Slug Portal/Harbor know this plugin by.
	 *
	 * Doubles as the Herald feature slug used both when surfacing the legacy
	 * key to Harbor's UI (`filter_legacy_licenses`) and when targeting Herald's
	 * `/legacy/download` endpoint for plugin downloads.
	 *
	 * @since 3.0.3
	 *
	 * @var string
	 */
	private const PORTAL_PRODUCT_SLUG = 'kadence-shop-kit';

	/**
	 * Uplink manager instance.
	 *
	 * @since 3.0.3
	 *
	 * @var Uplink_Manager
	 */
	private $uplink_manager;

	/**
	 * Constructor.
	 *
	 * @since 3.0.3
	 *
	 * @param Uplink_Manager $uplink_manager The Uplink manager (license storage + display metadata).
	 */
	public function __construct( Uplink_Manager $uplink_manager ) {
		$this->uplink_manager = $uplink_manager;
	}

	/**
	 * Expose the stored Uplink license to Harbor's legacy-license repository so
	 * the unified UI can surface (and dismiss notices for) the legacy key.
	 *
	 * Uplink doesn't persist an absolute license expiry date — only a status
	 * flag (`valid`, `expired`, etc.) — so `expires_at` is intentionally empty.
	 *
	 * Each appended entry is shaped to match Harbor's `Legacy_License::from_data()`:
	 *
	 *     [
	 *         'key'             => string, // The stored Uplink license key.
	 *         'slug'            => string, // Resource slug (must match the Harbor feature slug).
	 *         'name'            => string, // Human-readable plugin name.
	 *         'product'         => string, // Brand/grouping key — Harbor consolidates notices per product.
	 *         'is_active'       => bool,   // Whether Uplink considers the license valid.
	 *         'use_for_updates' => bool,   // Whether to use the license for updates.
	 *         'page_url'        => string, // Admin URL of the Legacy Licensing page (network-aware).
	 *         'expires_at'      => string, // Always '' — Uplink stores a status flag, not a date.
	 *     ]
	 *
	 * @since 3.0.3
	 *
	 * @param array<int, array<string, mixed>> $licenses Existing legacy-license entries from other instances.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public function filter_legacy_licenses( $licenses ) {
		$legacy_slug = Uplink_Manager::get_plugin_slug();
		$key         = get_license_key( $legacy_slug );

		if (
			'' === $key
			|| ! is_array( $licenses )
		) {
			return $licenses;
		}

		$resource  = get_resource( $legacy_slug );
		$is_active = null !== $resource && $resource->get_license_object()->is_valid();

		$licenses[] = [
			'key'             => $key,
			'slug'            => self::PORTAL_PRODUCT_SLUG,
			'name'            => $this->uplink_manager->get_plugin_name(),
			'product'         => 'kadence',
			'is_active'       => $is_active,
			'use_for_updates' => true,
			'page_url'        => $this->uplink_manager->get_license_page_url(),
			'expires_at'      => '',
		];

		return $licenses;
	}

	/**
	 * Remove the legacy license notices from the Uplink admin notices.
	 *
	 * @since 3.0.3
	 *
	 * @return void
	 */
	public function remove_legacy_license_notices(): void {
		$uplink_slug = Uplink_Manager::get_plugin_slug();

		delete_option( Uplink_Admin_Notice::STORE_KEY );

		add_filter(
			"stellarwp/uplink/{$uplink_slug}/plugin_notices",
			static function () {
				return [];
			}
		);
	}
}
