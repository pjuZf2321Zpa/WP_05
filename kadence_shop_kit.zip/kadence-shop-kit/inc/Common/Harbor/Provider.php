<?php
/**
 * Harbor Service Provider for Kadence Shop Kit.
 *
 * @since 3.0.0
 *
 * @package KadenceWP\KadenceShopKit\Harbor
 */

namespace KadenceWP\KadenceShopKit\Harbor;

use KadenceWP\KadenceShopKit\App;
use KadenceWP\KadenceShopKit\lucatume\DI52\ServiceProvider;
use KadenceWP\KadenceShopKit\LiquidWeb\Harbor\Config;
use KadenceWP\KadenceShopKit\LiquidWeb\Harbor\Harbor;

/**
 * Bootstraps Harbor for the Kadence Shop Kit.
 *
 * @since 3.0.0
 */
class Provider extends ServiceProvider {

	/**
	 * @since 3.0.0
	 *
	 * @return void
	 */
	public function register(): void {
		Config::set_plugin_basename( plugin_basename( trailingslashit( KADENCE_WOO_EXTRAS_PATH ) . 'kadence-shop-kit.php' ) );
		Config::set_container( App::container() );

		$this->container->singleton( Legacy_License_Integration::class );
	}

	/**
	 * @since 3.0.0
	 *
	 * @return void
	 */
	public function boot(): void {
		// Kadence Shop Kit is itself a premium plugin, so always declare a premium plugin exists.
		// Priority 5 to run before a free plugin callback.
		add_filter( 'lw_harbor/premium_plugin_exists', '__return_true', 5 );

		Harbor::init();

		// Register the Licensing submenu under the Kadence Shop Kit top-level menu.
		lw_harbor_register_submenu( 'kadence-shop-kit-settings' );

		add_filter( 'lw-harbor/legacy_licenses', $this->container->callback( Legacy_License_Integration::class, 'filter_legacy_licenses' ) );
		add_action( 'admin_init', $this->container->callback( Legacy_License_Integration::class, 'remove_legacy_license_notices' ) );
	}
}
