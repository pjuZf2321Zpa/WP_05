<?php
/**
 * Main Provider for the Kadence Shop Kit.
 *
 * @since 3.0.0
 *
 * @package KadenceWP\KadenceShopKit
 */

namespace KadenceWP\KadenceShopKit;

use KadenceWP\KadenceShopKit\lucatume\DI52\ServiceProvider;
use KadenceWP\KadenceShopKit\Features;
use KadenceWP\KadenceShopKit\Harbor;
use KadenceWP\KadenceShopKit\Settings;
use KadenceWP\KadenceShopKit\StellarWP\AdminNotices\AdminNotices;
use KadenceWP\KadenceShopKit\Uplink;

/**
 * Main Provider for the Kadence Shop Kit.
 *
 * @since 3.0.0
 */
class Provider extends ServiceProvider {
	/**
	 * Registers the service provider bindings.
	 *
	 * @since 3.0.0
	 *
	 * @return void
	 */
	public function register() {
		$this->container->register( Features\Provider::class );
		$this->container->register( Settings\Provider::class );
		$this->container->register( Harbor\Provider::class );
		$this->container->register( Uplink\Provider::class );
	}

	/**
	 * Boots the service provider.
	 *
	 * @since 3.0.0
	 *
	 * @return void
	 */
	public function boot() {
		AdminNotices::initialize( 'kadence-shop-kit', KADENCE_WOO_EXTRAS_URL . 'vendor/vendor-prefixed/stellarwp/admin-notices' );
	}
}
