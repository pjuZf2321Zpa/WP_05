<?php
/**
 * ServiceProvider for Settings.
 *
 * Handles registering settings-related services.
 *
 * @since 3.0.0
 *
 * @package KadenceWP\KadenceShopKit\Settings
 */

namespace KadenceWP\KadenceShopKit\Settings;

use KadenceWP\KadenceShopKit\lucatume\DI52\ServiceProvider;

/**
 * ServiceProvider for Settings.
 *
 * @since 3.0.0
 */
class Provider extends ServiceProvider {
	/**
	 * Registers bindings in the container.
	 *
	 * @since 3.0.0
	 *
	 * @return void
	 */
	public function register() {
		$this->container->singleton( Sub_Sections::class );
		$this->container->singleton( License_Button::class );
		$this->container->singleton( Section_Notices::class );
	}

	/**
	 * Hooks actions into WordPress after registration.
	 *
	 * @since 3.0.0
	 *
	 * @return void
	 */
	public function boot() {
		add_filter(
			'kadence_settings_enqueue_sections',
			$this->container->callback(
				Sub_Sections::class,
				'attach_sub_sections'
			),
			5,
			2
		);

		add_action(
			'admin_enqueue_scripts',
			$this->container->callback(
				Sub_Sections::class,
				'enqueue_assets'
			)
		);

		add_action(
			'admin_enqueue_scripts',
			$this->container->callback(
				License_Button::class,
				'enqueue_assets'
			)
		);

		add_action(
			'admin_enqueue_scripts',
			$this->container->callback(
				Section_Notices::class,
				'enqueue_assets'
			)
		);
	}
}
