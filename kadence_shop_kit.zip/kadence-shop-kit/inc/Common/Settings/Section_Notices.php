<?php
/**
 * Section notice safety net for Kadence Shop Kit settings.
 *
 * The Kadence Settings framework is manually copy/pasted across Kadence plugins
 * with no class prefixes and a version-registered global loader, so only the
 * highest-version copy is loaded. When another Kadence plugin wins that race,
 * its `build/settings.js` renders our settings page — and older copies of that
 * bundle don't know about the `section.notice` property introduced by Shop Kit,
 * so the coexistence warnings added to Product Gallery, Variation Swatches, and
 * Product QuickView sections silently fail to render.
 *
 * This module runs on top of whichever bundle is loaded, reads the notices that
 * PR #166 registered on the section arrays, and hands them to a small JS helper
 * that DOM-injects them alongside the section header. Shares no state with the
 * shared framework.
 *
 * @package KadenceWP\KadenceShopKit\Settings
 */

namespace KadenceWP\KadenceShopKit\Settings;

use Kadence_Settings_Engine;

/**
 * Ensures Shop Kit section notices always render, regardless of which Kadence
 * plugin's copy of the settings framework is loaded globally.
 *
 * @since 3.0.0
 */
class Section_Notices {

	/**
	 * Enqueue the section-notices JS on the Shop Kit settings screen.
	 *
	 * @since 3.0.0
	 *
	 * @return void
	 */
	public function enqueue_assets(): void {
		if ( ! function_exists( 'get_current_screen' ) ) {
			return;
		}

		$screen = get_current_screen();
		if (
			! $screen
			|| false === strpos( $screen->id, 'kadence-shop-kit' )
		) {
			return;
		}

		$notices = $this->build_notices_map();
		if ( empty( $notices ) ) {
			return;
		}

		$asset_path = KADENCE_WOO_EXTRAS_PATH . 'build/settings-section-notices.asset.php';
		$asset      = file_exists( $asset_path ) ? include $asset_path : [
			'dependencies' => [],
			'version'      => KADENCE_WOO_EXTRAS_VERSION,
		];

		wp_enqueue_script(
			'kadence-shop-kit-section-notices',
			KADENCE_WOO_EXTRAS_URL . 'build/settings-section-notices.js',
			array_merge( [ 'kadence-settings' ], $asset['dependencies'] ),
			$asset['version'],
			true
		);

		wp_localize_script(
			'kadence-shop-kit-section-notices',
			'kadenceShopKitSectionNotices',
			$notices
		);
	}

	/**
	 * Build a map of section title => notice HTML from already-registered sections.
	 *
	 * Reads from `Kadence_Settings_Engine::$sections` so the Iconic-plugin
	 * detection logic in inc/class-kadence-woo-extras-settings.php remains the
	 * single source of truth. Keyed by `long_title` when present, falling back
	 * to `title` — matches what the engine's React bundle renders into
	 * `.section-header`, which is what the JS helper looks up.
	 *
	 * @since 3.0.0
	 *
	 * @return array<string, string>
	 */
	private function build_notices_map(): array {
		$map = [];

		if ( ! class_exists( 'Kadence_Settings_Engine' ) ) {
			return $map;
		}

		foreach ( (array) Kadence_Settings_Engine::$sections as $sections_by_opt ) {
			if ( ! is_array( $sections_by_opt ) ) {
				continue;
			}

			foreach ( $sections_by_opt as $section ) {
				if ( ! is_array( $section ) || empty( $section['notice'] ) ) {
					continue;
				}

				$key = ! empty( $section['long_title'] ) ? $section['long_title'] : ( $section['title'] ?? '' );
				if ( '' === $key ) {
					continue;
				}

				$map[ $key ] = $section['notice'];
			}
		}

		return $map;
	}
}
