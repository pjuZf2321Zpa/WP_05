<?php
/**
 * Sub-sections support for Kadence Shop Kit settings.
 *
 * Adds sub-section functionality on top of the shared Kadence Settings Engine
 * without modifying the shared engine code. Uses the existing
 * `kadence_settings_enqueue_sections` filter to flatten sub-section fields
 * (with heading markers) into parent sections so they render through the
 * shared engine's standard field pipeline.
 *
 * @since 3.0.0
 *
 * @package KadenceWP\KadenceShopKit\Settings
 */

namespace KadenceWP\KadenceShopKit\Settings;

use Kadence_Settings_Engine;

/**
 * Class Sub_Sections
 *
 * @since 3.0.0
 */
class Sub_Sections {

	/**
	 * Sub-sections indexed by opt_name and parent section ID.
	 *
	 * @var array<string, array<string, array<string, array<string, mixed>>>>
	 */
	private $sub_sections = array();

	/**
	 * Register a sub-section under a parent section.
	 *
	 * @since 3.0.0
	 *
	 * @param string               $opt_name          Panel opt_name.
	 * @param string               $parent_section_id ID of the parent section.
	 * @param array<string, mixed> $sub_section        Sub-section data (id, title, desc, fields, priority).
	 *
	 * @return void
	 */
	public function set_sub_section( $opt_name = '', $parent_section_id = '', $sub_section = array() ): void {
		if ( empty( $sub_section ) || '' === $opt_name || '' === $parent_section_id ) {
			return;
		}

		if ( ! class_exists( 'Kadence_Settings_Engine' ) ) {
			return;
		}

		$sub_section['id'] = isset( $sub_section['id'] ) ? $sub_section['id'] : "{$opt_name}_{$parent_section_id}_sub_" . wp_rand( 1, 9999 );

		if ( ! isset( $sub_section['priority'] ) ) {
			$sub_section['priority'] = 10;
		}

		// Register fields with the shared engine under the PARENT section ID
		// so they appear alongside the section's own fields. Each field gets a
		// high priority (base 1000 + sub-section priority * 100 + field index)
		// to ensure sub-section fields render after the section's direct fields.
		if ( isset( $sub_section['fields'] ) && ! empty( $sub_section['fields'] ) && is_array( $sub_section['fields'] ) ) {
			/** @var int $priority */
			$priority      = $sub_section['priority'];
			$base_priority = 1000 + ( $priority * 100 );

			// Register a heading pseudo-field as the first entry.
			$heading_field = array(
				'id'          => $sub_section['id'] . '_heading',
				'type'        => 'sub_section_heading',
				'title'       => isset( $sub_section['title'] ) ? $sub_section['title'] : '',
				'priority'    => $base_priority,
				'sub_section' => $sub_section['id'],
			);

			if ( ! empty( $sub_section['desc'] ) ) {
				$heading_field['help'] = $sub_section['desc'];
			}

			if ( ! empty( $sub_section['required'] ) ) {
				$heading_field['required'] = $sub_section['required'];
			}

			Kadence_Settings_Engine::set_field( $opt_name, $parent_section_id, $heading_field ); // @phpstan-ignore argument.type

			// Register each sub-section field under the parent section.
			$field_index = 1;
			foreach ( $sub_section['fields'] as $field ) {
				if ( ! is_array( $field ) ) {
					continue;
				}
				$field['priority']    = $base_priority + $field_index;
				$field['sub_section'] = $sub_section['id'];
				Kadence_Settings_Engine::set_field( $opt_name, $parent_section_id, $field ); // @phpstan-ignore argument.type
				++$field_index;
			}
		}

		// Store sub-section metadata (without fields) for sidebar nav.
		unset( $sub_section['fields'] );
		$sub_section_id = is_string( $sub_section['id'] ) ? $sub_section['id'] : '';
		$this->sub_sections[ $opt_name ][ $parent_section_id ][ $sub_section_id ] = $sub_section;
	}

	/**
	 * Attach sub-section metadata to sections for the JS sidebar nav.
	 *
	 * Hooked to `kadence_settings_enqueue_sections`.
	 *
	 * @since 3.0.0
	 *
	 * @param array<string, mixed> $sections Constructed sections.
	 * @param string               $opt_name Panel opt_name.
	 *
	 * @return array<string, mixed>
	 */
	public function attach_sub_sections( $sections, $opt_name ) {
		if ( empty( $this->sub_sections[ $opt_name ] ) ) {
			return $sections;
		}

		foreach ( $sections as $section_id => $section ) {
			if ( ! is_array( $section ) || empty( $this->sub_sections[ $opt_name ][ $section_id ] ) ) {
				continue;
			}

			// Sort sub-sections by priority.
			$raw    = $this->sub_sections[ $opt_name ][ $section_id ];
			$sorted = array();
			foreach ( $raw as $sub_id => $sub_section ) {
				$p = is_int( $sub_section['priority'] ) ? $sub_section['priority'] : 10;
				while ( isset( $sorted[ $p ] ) ) {
					++$p;
				}
				$sorted[ $p ] = $sub_section;
			}
			ksort( $sorted );

			$sub_section_list = array();
			foreach ( $sorted as $sub_section ) {
				$sub_section_list[] = array(
					'id'       => $sub_section['id'],
					'title'    => isset( $sub_section['title'] ) ? $sub_section['title'] : '',
					'required' => isset( $sub_section['required'] ) ? $sub_section['required'] : null,
				);
			}

			$section['sub_sections'] = $sub_section_list;
			$sections[ $section_id ] = $section;
		}

		return $sections;
	}

	/**
	 * Enqueue plugin-specific sub-section JS and CSS on the settings page.
	 *
	 * @since 3.0.0
	 *
	 * @return void
	 */
	public function enqueue_assets(): void {
		if ( ! function_exists( 'get_current_screen' ) ) {
			return;
		}

		$screen = get_current_screen();
		if ( ! $screen || false === strpos( $screen->id, 'kadence-shop-kit' ) ) {
			return;
		}

		$asset_path = KADENCE_WOO_EXTRAS_PATH . 'build/settings-sub-sections.asset.php';
		$asset      = file_exists( $asset_path ) ? include $asset_path : array(
			'dependencies' => array(),
			'version'      => KADENCE_WOO_EXTRAS_VERSION,
		);

		wp_enqueue_style(
			'kadence-settings-sub-sections',
			KADENCE_WOO_EXTRAS_URL . 'build/settings-sub-sections.css',
			array( 'kadence-settings' ),
			$asset['version']
		);

		wp_enqueue_script(
			'kadence-settings-sub-sections',
			KADENCE_WOO_EXTRAS_URL . 'build/settings-sub-sections.js',
			array_merge( array( 'kadence-settings', 'wp-hooks', 'wp-element', 'wp-i18n' ), $asset['dependencies'] ),
			$asset['version'],
			true
		);
	}
}
