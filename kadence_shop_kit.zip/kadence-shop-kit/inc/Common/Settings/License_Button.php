<?php
/**
 * License button safety net for Kadence Shop Kit settings.
 *
 * The Kadence Settings framework is manually copy/pasted across Kadence plugins
 * with no class prefixes and a version-registered global loader, so only the
 * highest-version copy is loaded. When another Kadence plugin wins that race,
 * its `build/settings.js` renders our settings page — and its license button
 * may not use `licenseUrl` at all (e.g. Kadence Insights ships a toggle button
 * for an inline Uplink form, leaving the rendered anchor with no href).
 *
 * This module runs on top of whichever bundle is loaded, finds the license
 * button wrapper in the DOM, and rewrites it into an anchor pointing at the
 * Harbor license page. Shares no state with the shared framework.
 *
 * @package KadenceWP\KadenceShopKit\Settings
 */

namespace KadenceWP\KadenceShopKit\Settings;

/**
 * Ensures the Shop Kit settings page license button always links to Harbor,
 * regardless of which Kadence plugin's copy of the settings framework is
 * loaded globally.
 */
class License_Button {

	/**
	 * Enqueue the license-button JS/CSS on the Shop Kit settings screen.
	 *
	 * @return void
	 */
	public function enqueue_assets(): void {
		if ( ! function_exists( 'get_current_screen' ) ) {
			return;
		}

		$screen = get_current_screen();
		if (
			! $screen
			|| false === strpos( $screen->id, 'kadence-shop-kit' )
		) {
			return;
		}

		$asset_path = KADENCE_WOO_EXTRAS_PATH . 'build/settings-license-button.asset.php';
		$asset      = file_exists( $asset_path ) ? include $asset_path : [
			'dependencies' => [],
			'version'      => KADENCE_WOO_EXTRAS_VERSION,
		];

		wp_enqueue_style(
			'kadence-shop-kit-license-button',
			KADENCE_WOO_EXTRAS_URL . 'build/settings-license-button.css',
			[ 'kadence-settings' ],
			$asset['version']
		);

		wp_enqueue_script(
			'kadence-shop-kit-license-button',
			KADENCE_WOO_EXTRAS_URL . 'build/settings-license-button.js',
			array_merge( [ 'kadence-settings' ], $asset['dependencies'] ),
			$asset['version'],
			true
		);

		wp_localize_script(
			'kadence-shop-kit-license-button',
			'kadenceShopKitLicenseButton',
			[
				'licenseUrl'    => function_exists( 'lw_harbor_get_license_page_url' ) ? lw_harbor_get_license_page_url() : '',
				'licenseActive' => function_exists( 'lw_harbor_is_feature_available' ) ? (bool) lw_harbor_is_feature_available( 'kadence-shop-kit' ) : false,
				'label'         => __( 'License', 'kadence-shop-kit' ),
			]
		);
	}
}
