<?php
/**
 * Feature Resolver.
 *
 * Dispatches Feature operations to the appropriate strategy based on the Feature type.
 *
 * @since 3.0.0
 *
 * @package KadenceWP\KadenceShopKit\Features
 */

namespace KadenceWP\KadenceShopKit\Features;

use KadenceWP\KadenceShopKit\Features\Contracts\Feature;
use KadenceWP\KadenceShopKit\Features\Contracts\Feature_Strategy;

/**
 * Feature Resolver.
 *
 * @since 3.0.0
 */
class Feature_Resolver {
	/**
	 * Map of Feature class names to their strategies.
	 *
	 * @since 3.0.0
	 *
	 * @var array<class-string<Feature>, Feature_Strategy>
	 */
	private $strategies = [];

	/**
	 * Register a strategy for a given Feature type.
	 *
	 * @since 3.0.0
	 *
	 * @param class-string<Feature> $feature_class The Feature class name.
	 * @param Feature_Strategy      $strategy      The strategy to handle this Feature type.
	 *
	 * @return void
	 */
	public function register_strategy( $feature_class, Feature_Strategy $strategy ): void {
		$this->strategies[ $feature_class ] = $strategy;
	}

	/**
	 * Load a Feature using its registered strategy.
	 *
	 * @since 3.0.0
	 *
	 * @param Feature $feature The feature to load.
	 *
	 * @return void
	 */
	public function load( Feature $feature ): void {
		$strategy = $this->get_strategy( $feature );

		if ( ! $strategy ) {
			return;
		}

		$strategy->load( $feature );
	}

	/**
	 * Get the strategy registered for a given Feature.
	 *
	 * @since 3.0.0
	 *
	 * @param Feature $feature The feature to look up.
	 *
	 * @return Feature_Strategy|null The strategy, or null if none registered.
	 */
	public function get_strategy( Feature $feature ) {
		$class = get_class( $feature );

		return $this->strategies[ $class ] ?? null;
	}
}
