<?php
/**
 * ServiceProvider for Features.
 *
 * Handles registering all consolidated plugin modules with the same hook configuration.
 *
 * @since 3.0.0
 *
 * @package KadenceWP\KadenceShopKit\Features
 */

namespace KadenceWP\KadenceShopKit\Features;

use KadenceWP\KadenceShopKit\lucatume\DI52\ServiceProvider;
use KadenceWP\KadenceShopKit\StellarWP\AdminNotices\AdminNotice;
use KadenceWP\KadenceShopKit\StellarWP\AdminNotices\AdminNotices;
/**
 * ServiceProvider for Features.
 *
 * @since 3.0.0
 */
class Provider extends ServiceProvider {
	/**
	 * The Plugin Feature Strategy instance.
	 *
	 * @since 3.0.0
	 *
	 * @var Strategies\Plugin_Feature
	 */
	private $plugin_strategy;

	/**
	 * The Feature_Repository instance.
	 *
	 * @since 3.0.0
	 *
	 * @var Feature_Repository
	 */
	private $repository;

	/**
	 * Registers bindings in the container.
	 *
	 * @since 3.0.0
	 *
	 * @return void
	 */
	public function register() {
		$this->container->singleton( Feature_Resolver::class );
		$this->container->singleton( Strategies\Plugin_Feature::class );

		/** @var Feature_Resolver $resolver */
		$resolver = $this->container->get( Feature_Resolver::class );

		/** @var Strategies\Plugin_Feature $plugin_strategy */
		$plugin_strategy = $this->container->get( Strategies\Plugin_Feature::class );

		$this->plugin_strategy = $plugin_strategy;

		$resolver->register_strategy( Models\Plugin_Feature::class, $plugin_strategy );

		$this->repository = Feature_Repository::populate( ...$this->get_feature_definitions() );

		$this->container->singleton( Feature_Repository::class, $this->repository );
	}

	/**
	 * Hooks actions into WordPress after registration.
	 *
	 * @since 3.0.0
	 *
	 * @return void
	 */
	public function boot() {
		add_action(
			'plugins_loaded',
			$this->container->callback(
				self::class,
				'deactivate_legacy_plugins'
			),
			2
		);

		add_action(
			'plugins_loaded',
			$this->container->callback(
				self::class,
				'load_modules'
			),
			3
		);

		add_action(
			'admin_head-plugins.php',
			$this->container->callback(
				self::class,
				'start_notice_buffer'
			)
		);

		add_action(
			'admin_notices',
			$this->container->callback(
				self::class,
				'display_deactivation_notices'
			)
		);
	}

	/**
	 * Loads all enabled features.
	 *
	 * @since 3.0.0
	 *
	 * @return void
	 */
	public function load_modules() {
		foreach ( $this->repository->get_plugin_features() as $feature ) {
			$this->plugin_strategy->load( $feature );
		}
	}

	/**
	 * Deactivates any legacy standalone plugins that have been consolidated.
	 *
	 * @since 3.0.0
	 *
	 * @return void
	 */
	public function deactivate_legacy_plugins() {
		$redirect_destination = false;

		foreach ( $this->repository->get_plugin_features() as $feature ) {
			$result = $this->plugin_strategy->deactivate( $feature );

			if ( $redirect_destination === false && $result !== false ) {
				$redirect_destination = $result;
			}
		}

		if ( is_string( $redirect_destination ) && ! empty( $redirect_destination ) ) {
			wp_safe_redirect( $redirect_destination );
			exit;
		}
	}

	/**
	 * Displays and clears any queued legacy plugin deactivation notices.
	 *
	 * @since 3.0.0
	 *
	 * @return void
	 */
	public function display_deactivation_notices() {
		$notices = Strategies\Plugin_Feature::get_deactivation_notices();

		foreach ( $notices as $feature_id => $message ) {
			$notice = new AdminNotice(
				"kadence-shop-kit-{$feature_id}-deactivation-notice",
				$message
			);

			$notice->urgency( 'error' )
				->autoParagraph( true )
				->dismissible( true );

			AdminNotices::render( $notice );
		}

		Strategies\Plugin_Feature::clear_deactivation_notices();
	}

	/**
	 * Starts output buffering on the plugins page to filter activation error notices.
	 *
	 * @since 3.0.0
	 *
	 * @return void
	 */
	public function start_notice_buffer() {
		ob_start( [ $this, 'filter_notice_markup' ] );
	}

	/**
	 * Filters the plugins page output to replace legacy plugin activation error notices.
	 *
	 * @since 3.0.0
	 *
	 * @param string $markup The page markup.
	 *
	 * @return string The filtered markup.
	 */
	public function filter_notice_markup( $markup ) {
		foreach ( $this->repository->get_plugin_features() as $feature ) {
			$markup = $this->plugin_strategy->set_legacy_plugin_activation_error_notice( $feature, $markup, $feature->legacy_activation_error_message );
		}

		return $markup;
	}

	/**
	 * Returns all Plugin Feature definitions.
	 *
	 * Legacy activation messages are set via closures to defer __() calls until after the 'init'
	 * action, avoiding a _doing_it_wrong notice in WordPress 6.7+.
	 *
	 * @since 3.0.0
	 *
	 * @return Models\Plugin_Feature[]
	 */
	private function get_feature_definitions() {
		$features = [
			[
				'attributes' => [
					'option_key'                      => '',
					'plugin_directory_constant'       => '',
					'plugin_directory_default'        => 'kadence-woo-extras',
					'plugin_file'                     => 'kadence-woo-extras.php',
					'module_path'                     => '',
					'legacy_activation_error_message' => function () {
						return __( 'The old version of Kadence Shop Kit is no longer necessary.', 'kadence-shop-kit' );
					},
				],
			],
			[
				'attributes' => [
					'option_key'                      => 'feature_wishlists',
					'plugin_directory_constant'       => 'ICONIC_WW_PATH',
					'plugin_directory_default'        => 'iconic-woo-wishlists',
					'plugin_file'                     => 'iconic-woo-wishlists.php',
					'module_path'                     => KADENCE_WOO_EXTRAS_PATH . 'lib/wishlists/wishlists.php',
					'legacy_activation_error_message' => function () {
						return __( 'The Wishlists for WooCommerce addon has been merged into Kadence Shop Kit, and it is no longer necessary to be activated.', 'kadence-shop-kit' );
					},
				],
			],
			[
				'attributes' => [
					'option_key'                      => 'feature_account_pages',
					'plugin_directory_constant'       => 'ICONIC_WAP_PATH',
					'plugin_directory_default'        => 'iconic-woo-account-pages',
					'plugin_file'                     => 'iconic-woo-account-pages.php',
					'module_path'                     => KADENCE_WOO_EXTRAS_PATH . 'lib/account-pages/init.php',
					'legacy_activation_error_message' => function () {
						return __( 'The WooCommerce Account Pages addon has been merged into Kadence Shop Kit, and it is no longer necessary to be activated.', 'kadence-shop-kit' );
					},
				],
			],
			[
				'attributes' => [
					'option_key'                      => 'feature_linked_variations',
					'plugin_directory_constant'       => 'ICONIC_WLV_PATH',
					'plugin_directory_default'        => 'iconic-woo-linked-variations',
					'plugin_file'                     => 'iconic-woo-linked-variations.php',
					'module_path'                     => KADENCE_WOO_EXTRAS_PATH . 'lib/linked-variations/iconic-woo-linked-variations.php',
					'legacy_activation_error_message' => function () {
						return __( 'The WooCommerce Linked Variations addon has been merged into Kadence Shop Kit, and it is no longer necessary to be activated.', 'kadence-shop-kit' );
					},
				],
			],
			[
				'attributes' => [
					'option_key'                      => 'feature_delivery_slots',
					'plugin_directory_constant'       => 'ICONIC_WDS_PATH',
					'plugin_directory_default'        => 'iconic-woo-delivery-slots',
					'plugin_file'                     => 'iconic-woo-delivery-slots.php',
					'module_path'                     => KADENCE_WOO_EXTRAS_PATH . 'lib/delivery-slots/iconic-woo-delivery-slots.php',
					'legacy_activation_error_message' => function () {
						return __( 'The WooCommerce Delivery Slots addon has been merged into Kadence Shop Kit, and it is no longer necessary to be activated.', 'kadence-shop-kit' );
					},
				],
			],
			[
				'attributes' => [
					'option_key'                      => 'feature_image_swap',
					'plugin_directory_constant'       => 'ICONIC_WIS_PATH',
					'plugin_directory_default'        => 'iconic-woo-image-swap',
					'plugin_file'                     => 'iconic-woo-image-swap.php',
					'module_path'                     => KADENCE_WOO_EXTRAS_PATH . 'lib/image-swap/iconic-woo-image-swap.php',
					'legacy_activation_error_message' => function () {
						return __( 'The Image Swap for WooCommerce addon has been merged into Kadence Shop Kit, and it is no longer necessary to be activated.', 'kadence-shop-kit' );
					},
				],
			],
			[
				'attributes' => [
					'option_key'                      => 'feature_sales_booster',
					'plugin_directory_constant'       => 'ICONIC_WSB_PATH',
					'plugin_directory_default'        => 'iconic-woo-sales-booster',
					'plugin_file'                     => 'iconic-woo-sales-booster.php',
					'module_path'                     => KADENCE_WOO_EXTRAS_PATH . 'lib/sales-booster/iconic-woo-sales-booster.php',
					'legacy_activation_error_message' => function () {
						return __( 'The Sales Booster for WooCommerce addon has been merged into Kadence Shop Kit, and it is no longer necessary to be activated.', 'kadence-shop-kit' );
					},
				],
			],
			[
				'attributes' => [
					'option_key'                      => 'feature_flux_checkout',
					'plugin_directory_constant'       => 'ICONIC_FLUX_PATH',
					'plugin_directory_default'        => 'flux-checkout',
					'plugin_file'                     => 'flux-checkout.php',
					'module_path'                     => KADENCE_WOO_EXTRAS_PATH . 'lib/flux-checkout/flux-checkout.php',
					'legacy_activation_error_message' => function () {
						return __( 'The Flux Checkout addon has been merged into Kadence Shop Kit, and it is no longer necessary to be activated.', 'kadence-shop-kit' );
					},
				],
			],
			[
				'attributes' => [
					'option_key'                      => 'feature_show_single_variations',
					'plugin_directory_constant'       => 'ICONIC_WSSV_PATH',
					'plugin_directory_default'        => 'iconic-woo-show-single-variations',
					'plugin_file'                     => 'iconic-woo-show-single-variations.php',
					'module_path'                     => KADENCE_WOO_EXTRAS_PATH . 'lib/show-single-variations/iconic-woo-show-single-variations.php',
					'legacy_activation_error_message' => function () {
						return __( 'The WooCommerce Show Single Variations addon has been merged into Kadence Shop Kit, and it is no longer necessary to be activated.', 'kadence-shop-kit' );
					},
				],
			],
			[
				'attributes' => [
					'option_key'                      => 'feature_bundled_products',
					'plugin_directory_constant'       => 'ICONIC_WBP_PATH',
					'plugin_directory_default'        => 'iconic-woo-bundled-products',
					'plugin_file'                     => 'iconic-woo-bundled-products.php',
					'module_path'                     => KADENCE_WOO_EXTRAS_PATH . 'lib/bundled-products/iconic-woo-bundled-products.php',
					'legacy_activation_error_message' => function () {
						return __( 'The WooCommerce Bundled Products addon has been merged into Kadence Shop Kit, and it is no longer necessary to be activated.', 'kadence-shop-kit' );
					},
				],
			],
			[
				'attributes' => [
					'option_key'                      => 'feature_custom_fields_for_variations',
					'plugin_directory_constant'       => 'ICONIC_CFFV_PATH',
					'plugin_directory_default'        => 'iconic-woo-custom-fields-for-variations',
					'plugin_file'                     => 'iconic-woo-custom-fields-for-variations.php',
					'module_path'                     => KADENCE_WOO_EXTRAS_PATH . 'lib/custom-fields-for-variations/iconic-woo-custom-fields-for-variations.php',
					'legacy_activation_error_message' => function () {
						return __( 'The Custom Fields for Variations addon has been merged into Kadence Shop Kit, and it is no longer necessary to be activated.', 'kadence-shop-kit' );
					},
				],

			],
			[
				'attributes' => [
					'option_key'                      => 'feature_product_configurator',
					'plugin_directory_constant'       => 'ICONIC_PC_PATH',
					'plugin_directory_default'        => 'iconic-woo-product-configurator',
					'plugin_file'                     => 'iconic-woo-product-configurator.php',
					'module_path'                     => KADENCE_WOO_EXTRAS_PATH . 'lib/product_configurator/iconic-woo-product-configurator.php',
					'legacy_activation_error_message' => function () {
						return __( 'The WooCommerce Product Configurator addon has been merged into Kadence Shop Kit, and it is no longer necessary to be activated.', 'kadence-shop-kit' );
					},
				],
			],
		];

		return array_map(
			function ( $definition ) {
				$attributes = $definition['attributes'];
				$class      = $attributes['plugin_directory_default'] === 'kadence-woo-extras'
					? Models\Legacy_Plugin_Gate::class
					: Models\Plugin_Feature::class;

				return new $class( $attributes );
			},
			$features
		);
	}
}
