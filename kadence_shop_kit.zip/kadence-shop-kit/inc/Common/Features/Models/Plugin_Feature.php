<?php
/**
 * Plugin Feature model.
 *
 * Value object representing a legacy plugin that has been consolidated
 * into Kadence Shop Kit.
 *
 * @since 3.0.0
 *
 * @package KadenceWP\KadenceShopKit\Features\Models
 */

namespace KadenceWP\KadenceShopKit\Features\Models;

use Closure;
use KadenceWP\KadenceShopKit\Features\Contracts\Feature;
use KadenceWP\KadenceShopKit\StellarWP\Models\Model;
use KadenceWP\KadenceShopKit\Utilities\Cast;
use KWE_Options;

/**
 * Plugin Feature model.
 *
 * @since 3.0.0
 *
 * @property string $option_key                      The key in the kt_woo_extras option that controls whether this feature is enabled.
 * @property string $plugin_directory_constant       The constant name used to detect if the legacy plugin is active.
 * @property string $plugin_directory_default        The default directory name for the legacy plugin.
 * @property string $plugin_file                     The legacy plugin's main file name.
 * @property string $module_path                     The path to the module file to load.
 * @property string $legacy_activation_error_message The message to display when the legacy plugin activation is blocked.
 */
class Plugin_Feature extends Model implements Feature {

	/**
	 * Properties for the Plugin Feature model.
	 *
	 * @since 3.0.0
	 *
	 * @var array<string, string>
	 */
	protected $properties = [
		'option_key'                      => 'string',
		'plugin_directory_constant'       => 'string',
		'plugin_directory_default'        => 'string',
		'plugin_file'                     => 'string',
		'module_path'                     => 'string',
		'legacy_activation_error_message' => Closure::class,
	];

	/**
	 * The identifier used to register this Feature in the repository.
	 *
	 * Plugin_Feature uses the option_key as its identifier.
	 *
	 * @since 3.0.0
	 *
	 * @return string
	 */
	public function get_id(): string {
		return Cast::to_string( $this->option_key );
	}

	/**
	 * Whether the Feature is enabled.
	 *
	 * @since 3.0.0
	 *
	 * @return bool
	 */
	public function is_enabled(): bool {
		$value = KWE_Options::get( $this->option_key );

		return ! empty( $value );
	}

	/**
	 * Determines whether the Legacy Plugin is active.
	 *
	 * @since 3.0.0
	 *
	 * @return bool
	 */
	public function is_legacy_plugin_active(): bool {
		$legacy_plugin_path = $this->get_legacy_plugin_path();

		if ( ! function_exists( 'is_plugin_active' ) ) {
			include_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		return is_plugin_active( $legacy_plugin_path )
			|| is_plugin_active_for_network( $legacy_plugin_path );
	}

	/**
	 * Determines whether the code is already loaded.
	 *
	 * @since 3.0.0
	 *
	 * @return bool
	 */
	public function is_legacy_plugin_loaded(): bool {
		return defined( $this->plugin_directory_constant );
	}

	/**
	 * Returns the Legacy Plugin path, relative to /wp-content/plugins.
	 *
	 * @since 3.0.0
	 *
	 * @return string
	 */
	public function get_legacy_plugin_path(): string {
		$plugin_directory_constant = $this->plugin_directory_constant;
		$plugin_directory_default  = $this->plugin_directory_default;

		return Cast::to_string(
			preg_replace(
				'/^' . preg_quote(
					trailingslashit(
						wp_normalize_path( Cast::to_string( constant( 'WP_PLUGIN_DIR' ) ) )
					),
					'/'
				) . '/',
				'',
				trailingslashit(
					wp_normalize_path(
						defined( $plugin_directory_constant )
							? Cast::to_string( constant( $plugin_directory_constant ) )
							: $plugin_directory_default
					)
				)
			)
		) . $this->plugin_file;
	}

	/**
	 * Get an attribute value by key.
	 *
	 * @param string $key           The attribute key to retrieve.
	 * @param mixed  $default_value Default value returned when the attribute is not set.
	 *
	 * @return mixed
	 */
	public function getAttribute( string $key, $default_value = null ) {
		$this->validatePropertyExists( $key );

		if ( is_callable( $this->attributes[ $key ] ) ) {
			return ( $this->attributes[ $key ] )();
		}

		return $this->attributes[ $key ] ?? $default_value;
	}
}
