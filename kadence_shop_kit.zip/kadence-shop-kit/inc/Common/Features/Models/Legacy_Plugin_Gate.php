<?php
/**
 * Legacy Plugin Gate model.
 *
 * Value object representing the legacy kadence-woo-extras plugin
 * that should be deactivated when the renamed kadence-shop-kit
 * plugin is active.
 *
 * @since 3.0.0
 *
 * @package KadenceWP\KadenceShopKit\Features\Models
 */

namespace KadenceWP\KadenceShopKit\Features\Models;

/**
 * Legacy Plugin Gate model.
 *
 * @since 3.0.0
 */
class Legacy_Plugin_Gate extends Plugin_Feature {
	/**
	 * Stable identifier for the repository.
	 *
	 * Overrides the parent because there is no option_key to derive from.
	 *
	 * @since 3.0.0
	 *
	 * @return string
	 */
	public function get_id(): string {
		return 'legacy_plugin_gate';
	}

	/**
	 * Always enabled — there is no settings toggle for this check.
	 *
	 * @since 3.0.0
	 *
	 * @return bool
	 */
	public function is_enabled(): bool {
		return true;
	}

	/**
	 * Always returns true so the Strategy skips module loading.
	 *
	 * There is no module to load — the new plugin itself is the replacement.
	 *
	 * @since 3.0.0
	 *
	 * @return bool
	 */
	public function is_legacy_plugin_loaded(): bool {
		return true;
	}

	/**
	 * Returns the legacy plugin path relative to /wp-content/plugins.
	 *
	 * Overrides the parent to avoid constant-based resolution, since both
	 * the old and new plugins define KADENCE_WOO_EXTRAS_PATH and the
	 * constant would resolve to the new plugin's directory.
	 *
	 * @since 3.0.0
	 *
	 * @return string
	 */
	public function get_legacy_plugin_path(): string {
		return $this->plugin_directory_default . '/' . $this->plugin_file;
	}
}
