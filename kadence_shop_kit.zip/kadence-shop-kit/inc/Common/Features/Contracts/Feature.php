<?php
/**
 * Contract for Feature models.
 *
 * @since 3.0.0
 *
 * @package KadenceWP\KadenceShopKit\Features\Contracts
 */

namespace KadenceWP\KadenceShopKit\Features\Contracts;

/**
 * Contract for Feature models.
 *
 * @since 3.0.0
 */
interface Feature {
	/**
	 * A unique identifier for this Feature within the repository.
	 *
	 * Implementations that are driven by an option (e.g. Plugin_Feature) should
	 * return the option key; implementations without an option should return any
	 * other stable, unique identifier. Must not be empty.
	 *
	 * @since 3.0.0
	 *
	 * @return string
	 */
	public function get_id(): string;

	/**
	 * Whether the Feature is enabled.
	 *
	 * @since 3.0.0
	 *
	 * @return bool
	 */
	public function is_enabled(): bool;
}
