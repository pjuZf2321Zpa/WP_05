<?php
/**
 * Contract for Feature loading strategies.
 *
 * @since 3.0.0
 *
 * @package KadenceWP\KadenceShopKit\Features\Contracts
 */

namespace KadenceWP\KadenceShopKit\Features\Contracts;

/**
 * Contract for Feature loading strategies.
 *
 * @since 3.0.0
 */
interface Feature_Strategy {
	/**
	 * Load the Feature.
	 *
	 * @since 3.0.0
	 *
	 * @param Feature $feature The feature to load.
	 *
	 * @return void
	 */
	public function load( Feature $feature ): void;
}
