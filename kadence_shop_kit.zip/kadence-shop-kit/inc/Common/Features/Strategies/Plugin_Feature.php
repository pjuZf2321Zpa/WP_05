<?php
/**
 * Strategy for loading Plugin Features.
 *
 * Handles loading consolidated plugin modules and managing legacy plugin deactivation.
 *
 * @since 3.0.0
 *
 * @package KadenceWP\KadenceShopKit\Features\Strategies
 */

namespace KadenceWP\KadenceShopKit\Features\Strategies;

use KadenceWP\KadenceShopKit\Features\Contracts\Feature;
use KadenceWP\KadenceShopKit\Features\Contracts\Feature_Strategy;
use KadenceWP\KadenceShopKit\StellarWP\SuperGlobals\SuperGlobals;
use KadenceWP\KadenceShopKit\Features\Models;

/**
 * Strategy for loading Plugin Features.
 *
 * @since 3.0.0
 */
class Plugin_Feature implements Feature_Strategy {
	/**
	 * Transient key used to queue admin notices for legacy plugins that were auto-deactivated.
	 *
	 * @since 3.0.0
	 *
	 * @var string
	 */
	private const NOTICE_TRANSIENT = 'kadence_shop_kit_legacy_deactivation_notices';

	/**
	 * Load the Feature module if it should be loaded.
	 *
	 * @since 3.0.0
	 *
	 * @param Feature $feature The feature to load.
	 *
	 * @return void
	 */
	public function load( Feature $feature ): void {
		if ( ! $feature instanceof Models\Plugin_Feature ) {
			return;
		}

		if ( $feature->is_legacy_plugin_loaded() ) {
			return;
		}

		$module_path = $feature->module_path;

		if ( ! file_exists( $module_path ) ) {
			return;
		}

		require_once $module_path;
	}

	/**
	 * If a legacy installation of the plugin is found on the site, deactivate it.
	 *
	 * @since 3.0.0
	 *
	 * @param Models\Plugin_Feature $feature The plugin feature to deactivate.
	 *
	 * @return string|false False if no deactivation needed, empty string if deactivated but no redirect,
	 *                      or a URL string for the redirect destination.
	 */
	public function deactivate( Models\Plugin_Feature $feature ) {
		if ( ! $feature->is_legacy_plugin_active() ) {
			return false;
		}

		deactivate_plugins( $feature->get_legacy_plugin_path() );

		$this->queue_deactivation_notice( $feature );

		$referrer = wp_get_referer();

		$redirect_destination = $this->get_redirect( $referrer );

		if ( $redirect_destination === false ) {
			return '';
		}

		return $redirect_destination;
	}

	/**
	 * Updates the legacy plugin activation error notice shown when attempting to activate the legacy plugin
	 * via the WordPress Admin which fails due to a fatal error.
	 *
	 * This accounts for when the Shop Kit Plugin_Feature is enabled and then legacy plugin is attempted to be activated.
	 *
	 * @since 3.0.0
	 *
	 * @param Models\Plugin_Feature $feature The plugin feature.
	 * @param string                $markup  The notice markup.
	 * @param string                $message The legacy activation error message.
	 *
	 * @return string The modified notice markup.
	 */
	public function set_legacy_plugin_activation_error_notice( Models\Plugin_Feature $feature, $markup, $message = '' ) {
		if (
			! is_admin()
			|| ! function_exists( 'get_current_screen' )
		) {
			return $markup;
		}

		$screen = get_current_screen();

		if (
			! $screen
			|| $screen->id !== 'plugins'
		) {
			return $markup;
		}

		$plugin                   = SuperGlobals::get_get_var( 'plugin' );
		$plugin_directory_default = $feature->plugin_directory_default;
		$plugin_file              = $feature->plugin_file;

		/**
		 * We have to check against the default directory here because at this point in execution, the plugin
		 * directory constant could point to the sub-directory of this plugin instead of the actual plugin directory.
		 */
		if (
			! $plugin
			|| $plugin !== "{$plugin_directory_default}/{$plugin_file}"
		) {
			return $markup;
		}

		$error_nonce = SuperGlobals::get_get_var( '_error_nonce' );

		if (
			! is_string( $error_nonce )
			|| ! wp_verify_nonce(
				$error_nonce,
				"plugin-activation-error_{$plugin_directory_default}/{$plugin_file}"
			)
		) {
			return $markup;
		}

		// phpcs:ignore WordPress.WP.I18n.TextDomainMismatch -- We need to use the default WordPress text domain here because we want to override the WordPress default error message.
		$default_message = __( 'Plugin could not be activated because it triggered a <strong>fatal error</strong>.', 'default' );

		$message = ! empty( $message ) ? $message : $feature->legacy_activation_error_message;

		return str_replace( $default_message, $message, $markup );
	}

	/**
	 * Gets the deactivation notices for the legacy plugins.
	 *
	 * @since 3.0.0
	 *
	 * @return array<string, string> The deactivation notices.
	 */
	public static function get_deactivation_notices(): array {
		$notices = get_transient( self::NOTICE_TRANSIENT );

		if ( ! is_array( $notices ) ) {
			return [];
		}

		return $notices;
	}

	/**
	 * Clears the deactivation notices for the legacy plugins.
	 *
	 * @since 3.0.0
	 *
	 * @return void
	 */
	public static function clear_deactivation_notices(): void {
		delete_transient( self::NOTICE_TRANSIENT );
	}

	/**
	 * Given a referrer, determine where they should be redirected to after deactivating the legacy plugin.
	 *
	 * @since 3.0.0
	 *
	 * @param string|false $referrer Referrer. Should match valid output of wp_get_referer().
	 *
	 * @return string|false Redirect destination. Empty string to refresh the page, false when they should not be redirected at all.
	 */
	private function get_redirect( $referrer ) {
		if ( $referrer === false ) {
			return '';
		}

		$redirect_to_plugins_list = [
			admin_url( 'update.php' ), // Updating by uploading a ZIP.
			admin_url( 'update-core.php' ), // Updating via the "Update Plugins" workflow in the WordPress Dashboard.
		];

		/**
		 * Some cases are special and we don't want to redirect.
		 *
		 * Particularly, any time when an update is applied via AJAX (inline updates on the Plugins List page) could
		 * cause the user to be "trapped" until they attempt to navigate away twice unless we specifically ensure these
		 * referrers are not redirected.
		 */
		$never_redirect = [
			admin_url( 'plugins.php' ), // Updating inline or via bulk actions on the Plugins List page.
		];

		if ( $this->check_array_for_referrer( $redirect_to_plugins_list, $referrer ) ) {
			return admin_url( 'plugins.php' );
		}

		if ( $this->check_array_for_referrer( $never_redirect, $referrer ) ) {
			return false;
		}

		return $referrer;
	}

	/**
	 * Checks if a referrer matches any items in the search array.
	 *
	 * @since 3.0.0
	 *
	 * @param array<string> $search_array Array of strings to search for in the referrer.
	 * @param string        $referrer     The referrer to check.
	 *
	 * @return bool True if the referrer matches any item in the search array, false otherwise.
	 */
	private function check_array_for_referrer( $search_array, $referrer ) {
		return ! empty(
			array_filter(
				array_map(
					function ( $current_referrer ) use ( $referrer ) {
						return strpos( $referrer, $current_referrer ) !== false;
					},
					$search_array
				)
			)
		);
	}

	/**
	 * Queues an admin notice announcing that the legacy plugin was auto-deactivated.
	 *
	 * Stored as a transient so the notice survives the request that performed the
	 * deactivation (and any subsequent redirect) and is shown on the next admin page load.
	 *
	 * This accounts for when the legacy plugin is already active and then the related Shop Kit Plugin_Feature is enabled.
	 *
	 * @since 3.0.0
	 *
	 * @param Models\Plugin_Feature $feature The plugin feature that was deactivated.
	 *
	 * @return void
	 */
	private function queue_deactivation_notice( Models\Plugin_Feature $feature ): void {
		$notices = get_transient( self::NOTICE_TRANSIENT );

		if ( ! is_array( $notices ) ) {
			$notices = [];
		}

		$notices[ $feature->get_id() ] = $feature->legacy_activation_error_message;

		set_transient( self::NOTICE_TRANSIENT, $notices, HOUR_IN_SECONDS );
	}
}
