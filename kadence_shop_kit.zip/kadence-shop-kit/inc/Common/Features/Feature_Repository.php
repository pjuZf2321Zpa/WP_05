<?php
/**
 * Feature Repository.
 *
 * In-memory, immutable registry of Feature instances, indexed by identifier,
 * enabling lookups without holding a Feature reference.
 *
 * @since 3.0.0
 *
 * @package KadenceWP\KadenceShopKit\Features
 */

namespace KadenceWP\KadenceShopKit\Features;

use InvalidArgumentException;
use KadenceWP\KadenceShopKit\Features\Contracts\Feature;
use KadenceWP\KadenceShopKit\Features\Models\Plugin_Feature;

/**
 * Feature Repository.
 *
 * @since 3.0.0
 */
class Feature_Repository {
	/**
	 * Registered Feature instances, keyed by id.
	 *
	 * @since 3.0.0
	 *
	 * @var array<string, Feature>
	 */
	private $features;

	/**
	 * @since 3.0.0
	 *
	 * @param array<string, Feature> $features Features keyed by id.
	 */
	private function __construct( array $features ) {
		$this->features = $features;
	}

	/**
	 * Build a populated Feature_Repository from the given Features.
	 *
	 * Features whose get_id() returns an empty string are silently dropped
	 * because they cannot be addressed by id.
	 *
	 * @since 3.0.0
	 *
	 * @param Feature ...$features The Features to populate the repository with.
	 *
	 * @return self
	 */
	public static function populate( Feature ...$features ): self {
		$indexed = [];

		foreach ( $features as $feature ) {
			$id = $feature->get_id();

			if ( $id === '' ) {
				continue;
			}

			$indexed[ $id ] = $feature;
		}

		return new self( $indexed );
	}

	/**
	 * Retrieve a registered Feature by its id.
	 *
	 * @since 3.0.0
	 *
	 * @param string $id The id to look up.
	 *
	 * @return Feature|null The feature, or null if none is registered for the given id.
	 */
	public function get( string $id ): ?Feature {
		return $this->features[ $id ] ?? null;
	}

	/**
	 * Whether a Feature is registered for the given id.
	 *
	 * @since 3.0.0
	 *
	 * @param string $id The id to check.
	 *
	 * @return bool
	 */
	public function has( string $id ): bool {
		return array_key_exists( $id, $this->features );
	}

	/**
	 * Whether the Feature registered for the given id is enabled.
	 *
	 * Throws when no Feature is registered for the given id so that typos
	 * surface immediately rather than being indistinguishable from a disabled
	 * Feature. Callers that need permissive behavior should gate on has().
	 *
	 * @since 3.0.0
	 *
	 * @param string $id The id to check.
	 *
	 * @throws InvalidArgumentException When no Feature is registered for the given id.
	 *
	 * @return bool
	 */
	public function is_enabled( string $id ): bool {
		$feature = $this->get( $id );

		if ( $feature === null ) {
			throw new InvalidArgumentException(
				sprintf( 'No Feature is registered for id "%s".', esc_html( $id ) )
			);
		}

		return $feature->is_enabled();
	}

	/**
	 * Retrieve all registered Feature instances.
	 *
	 * Only Features with a non-empty id are returned; empty-id Features
	 * are rejected at populate() time and therefore never appear here.
	 *
	 * @since 3.0.0
	 *
	 * @return Feature[] The unfiltered list of registered features.
	 */
	public function all(): array {
		return array_values( $this->features );
	}

	/**
	 * Yield every enabled Plugin_Feature in the repository.
	 *
	 * @since 3.0.0
	 *
	 * @return iterable<Plugin_Feature>
	 */
	public function get_plugin_features(): iterable {
		foreach ( $this->features as $feature ) {
			if ( $feature instanceof Plugin_Feature && $feature->is_enabled() ) {
				yield $feature;
			}
		}
	}
}
