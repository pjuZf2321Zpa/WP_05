/*
 * kt variations plugin
 */
var kt_woo_extra_isMobile = {
	Android: function () {
		return navigator.userAgent.match(/Android/i);
	},
	BlackBerry: function () {
		return navigator.userAgent.match(/BlackBerry/i);
	},
	iOS: function () {
		return navigator.userAgent.match(/iPhone|iPad|iPod/i);
	},
	Opera: function () {
		return navigator.userAgent.match(/Opera Mini/i);
	},
	Windows: function () {
		return navigator.userAgent.match(/IEMobile/i);
	},
	any: function () {
		return (
			kt_woo_extra_isMobile.Android() ||
			kt_woo_extra_isMobile.BlackBerry() ||
			kt_woo_extra_isMobile.iOS() ||
			kt_woo_extra_isMobile.Opera() ||
			kt_woo_extra_isMobile.Windows()
		);
	},
};

jQuery(document).ready(function ($) {
	$(".kadence-wp-tips-container").each(function () {
		var $container = $(this);
		var item = $(this).find("#" + $container.attr("aria-describedby"));
		if (item) {
			$(this)
				.on("mouseenter", function (e) {
					item.attr("aria-hidden", "false");
				})
				.on("mouseleave", function (e) {
					item.attr("aria-hidden", "true");
				});
		}
	});
	var select2Enable = typeof $().select2 == "function";

	function init_swatches() {
		$(".variations_form").each(function () {
			var $vform = $(this);
			
			if ($vform.data("kt-swatches-initialized")) {
				return;
			}
			
			$vform.data("kt-swatches-initialized", true);
			var $vform_select = $vform.find(
				".variations td.product_value select"
			);
			var $variations = $vform.find(".single_variation_wrap");
			var $use_ajax = $vform.data("product_variations") === false;
			var $product_variations = $vform.data("product_variations");
			var count_variations = $vform.find(".variations td.value").length;

			$vform.on("click", ".reset_variations", function () {
				$vform
					.find(".kad_radio_variations .selectedValue")
					.removeClass("selectedValue");
				$vform
					.find(".kad_radio_variations label")
					.removeClass("kt_disabled ");
				$vform
					.find('.kad_radio_variations input[type="radio"]:checked')
					.prop("checked", false);
				return false;
			});
			$vform.on("reset_data", function () {
				$vform
					.find(".single_variation_wrap_kad")
					.find(".quantity")
					.hide();
				$vform.find(".single_variation .price").hide();
			});
			$vform.on("click", ".select-option", function (e) {
				e.preventDefault();
			});
			$vform.on(
				"change",
				'.variations input[type="radio"]',
				function (e) {
					var $this = $(this);

					//Get the wrapper select div
					var $option_wrapper = $this.closest(
						".kt-radio-variation-container"
					);

					//Select the option.
					var $wc_select_box = $option_wrapper.find("select").first();

					// Decode entities
					var attr_val = $this.val();
					if (attr_val.indexOf('"') !== -1) {
						var current_attr_val = "value='" + attr_val + "'";
					} else {
						var current_attr_val = 'value="' + attr_val + '"';
					}
					//$wc_select_box.trigger('focusin').children("[value='" + attr_val + "']").prop("selected", "selected").change();
					$wc_select_box.trigger("focusin");
					if (
						$wc_select_box.find("option[" + current_attr_val + "]")
							.length
					) {
						$wc_select_box
							.trigger("focusin")
							.val(attr_val)
							.trigger("change");
					} else {
						$vform.find(".variations select").val("").change();
						$vform
							.find(".kad_radio_variations .selectedValue")
							.removeClass("selectedValue");
						$vform
							.find(".kad_radio_variations label")
							.removeClass("kt_disabled ");
						if (select2Enable) {
							$(".variations .kad-select").select2({
								minimumResultsForSearch: -1,
							});
						}
						$vform
							.find(
								'.kad_radio_variations input[type="radio"]:checked'
							)
							.prop("checked", false);
						$vform.trigger("reset_data");
						// add in the selection
						$vform
							.find(
								'.kad_radio_variations input[type="radio"][' +
									current_attr_val +
									"]"
							)
							.prop("checked", true);
						$wc_select_box
							.trigger("focusin")
							.val(attr_val)
							.trigger("change");
					}
					$vform
						.find(".kad_radio_variations .selectedValue")
						.removeClass("selectedValue");
					$vform
						.find(
							'.kad_radio_variations input[type="radio"]:checked'
						)
						.next()
						.addClass("selectedValue");
				}
			);
			$vform.on("woocommerce_variation_has_changed", function () {
				$(".kad-select").trigger("update");
				if ($use_ajax) {
					if (
						$(window).width() > 790 &&
						!kt_woo_extra_isMobile.any()
					) {
						if (select2Enable) {
							$(".kad-select").select2({
								minimumResultsForSearch: -1,
							});
						}
					}
				}
			});
			// Disable option fields that are unavaiable for current set of attributes
			$vform.on("woocommerce_variation_has_changed", function () {
				if ($use_ajax) {
					return;
				}
				var kt_current_settings = {};
				var variations = [];
				$vform.find(".variations select").each(function () {
					$(this).trigger("focusin");
					$(this)
						.find("option.enabled")
						.each(function () {
							variations.push($(this).val());
						});
				});
				$vform
					.find(".variations .kad_radio_variations")
					.each(function (index, el) {
						var current_attr_radio = $(el);
						var current_attr_name =
							current_attr_radio.data("attribute_name");
						current_attr_radio
							.find("input")
							.removeClass("attached");
						current_attr_radio.find("input").removeClass("enabled");
						current_attr_radio
							.find("label")
							.removeClass("kt_disabled ");

						// Loop through variations
						var i;
						for (i = 0; i < variations.length; ++i) {
							if (variations[i].indexOf('"') !== -1) {
								current_attr_radio
									.find(
										"input[value='" + variations[i] + "']"
									)
									.addClass("attached " + "enabled");
							} else {
								current_attr_radio
									.find(
										'input[value="' + variations[i] + '"]'
									)
									.addClass("attached " + "enabled");
							}
						}
						current_attr_radio
							.find("input:not(.attached)")
							.next()
							.addClass("kt_disabled");
					});
			});

			$variations.on("hide_variation", function () {
				$(this).css("height", "auto");
			});
			// Upon gaining focus
			$vform_select.on("select2-opening", function () {
				if (!$use_ajax) {
					$vform.trigger("woocommerce_variation_select_focusin");
					$vform.trigger("check_variations", [
						$(this).data("attribute_name") || $(this).attr("name"),
						true,
					]);
				}
			});
			$(function () {
				if (typeof wc_add_to_cart_variation_params !== "undefined") {
					$(".variations_form").each(function () {
						$(this)
							.find('.variations input[type="radio"]:checked')
							.change();
					});
				}
			});
		});
	}
	$(document).on("woosq_loaded", function () {
		init_swatches();
	});
	$(window).on("kt_fkcart_quick_view_loaded", function () {
		init_swatches();
	});
	$(".bundle_form .bundle_data").each(function () {
		$(this).on("woocommerce-product-bundle-initialized", function () {
			init_swatches();
		});
	});
	document.addEventListener("kb-query-loaded", function () {
		init_swatches();
	});
	// CheckoutWC's side-cart modal (and other quick views) inject a variations form
	// and call wc_variation_form() — wire its swatches too. Idempotent via the
	// per-form guard in init_swatches().
	$(document.body).on("wc_variation_form", ".variations_form", function () {
		init_swatches();
	});
	init_swatches();

	/**
	 * Setup fees for variation swatches.
	 */
	function setup_variation_fees() {
		$(document.body).on(
			'change',
			'input[name="variation_id"]',
			function () {
				const $field = $(this),
					variation_id = $field.val();

				if (variation_id === '') {
					return;
				}

				const $form = $field.closest('form');

				if ($form.length <= 0) {
					return;
				}

				const fee_values = get_selected_fee_value($form);

				if (!fee_values || fee_values.default === 0) {
					return;
				}

				const update_variation_price = () => {
					const $variation_price = $form.find('.woocommerce-variation-price');
					const $prices = $variation_price.find('.amount');

					if ($prices.length <= 0) {
						return;
					}

					let $suffix = $form.find('.woocommerce-price-suffix'),
						suffix_map = $suffix.length > 0 ? get_suffix_map($suffix) : false,
						suffix_index = 0,
						fee = 0;

					$prices.each(function (index, price) {
						let $price = $(price),
							price_text;

						// If this is a price located in the price suffix, determine
						// if tax is inc or ex, and then select the correct fee.
						if ($price.closest('.woocommerce-price-suffix').length > 0) {
							const suffix_price_type = suffix_map[suffix_index];
							fee = fee_values[suffix_price_type];
							suffix_index++;
						} else {
							fee = fee_values.default;
						}

						// Save price to data attribute so it can be used later. So if the change
						// event is triggered twice on variation_id, we would not add the fees twice.
						if (!$price.data('was-price')) {
							price_text = $price.text();
							$price.data('was-price', price_text);
						} else {
							price_text = $price.data('was-price');
						}

						let price_value = parse_price(price_text),
							new_value = price_value + fee;

						new_value = format_price(new_value);

						$price.html(
							$price.html().toString().replace(
								get_price_regex(),
								new_value
							)
						);
					});
				};

				/**
				 * Adds a delay to wait WooCommerce loads the
				 * content.
				 *
				 * WooCommerce adds a delay of 300 milliseconds to
				 * change the content for accessibility purposes.
				 *
				 * @see https://github.com/woocommerce/woocommerce/pull/54923
				 */
				setTimeout(update_variation_price, 310);
			}
		);
	}

	/**
	 * Get selected fee value from form.
	 */
	function get_selected_fee_value($form) {
		var $fee_data = $form.find('.kt-was-fees');

		if ($fee_data.length <= 0) {
			return false;
		}

		var fees_value = {
			default: 0,
			price_including_tax: 0,
			price_excluding_tax: 0
		};

		try {
			var fee_data = JSON.parse($fee_data.text());
			var attributes = get_attributes_from_form($form);

			$.each(attributes, function (attribute, value) {
				if (typeof fee_data[attribute] === 'undefined' ||
					typeof fee_data[attribute][value] === 'undefined') {
					return;
				}

				fees_value = {
					default: fees_value.default + fee_data[attribute][value].default,
					price_including_tax: fees_value.price_including_tax + fee_data[attribute][value].price_including_tax,
					price_excluding_tax: fees_value.price_excluding_tax + fee_data[attribute][value].price_excluding_tax
				};
			});
		} catch (e) {
			console.error('Error parsing fee data:', e);
			return false;
		}

		return fees_value;
	}

	/**
	 * Get attributes from form.
	 */
	function get_attributes_from_form($form) {
		var attributes = {};
		var data = $form.serializeArray();

		if (data.length <= 0) {
			return attributes;
		}

		$.each(data, function (index, item) {
			if (item.value === '' || !item.name.startsWith('attribute_')) {
				return;
			}

			var name = item.name.replace('attribute_', '');
			attributes[name] = item.value;
		});

		return attributes;
	}

	/**
	 * Determine which type of price appears in the price suffix.
	 *
	 * @param  $suffix
	 * @return {[]}
	 */
	function get_suffix_map($suffix) {
		const map = [];

		if (typeof woocommerce_params === 'undefined' || !woocommerce_params.price_display_suffix) {
			return map;
		}

		const suffix = woocommerce_params.price_display_suffix,
			suffix_split = suffix.split('{');

		$.each(suffix_split, function (index, string) {
			if (-1 !== string.indexOf('price_including_tax')) {
				map.push('price_including_tax');
			} else if (-1 !== string.indexOf('price_excluding_tax')) {
				map.push('price_excluding_tax');
			}
		});

		return map;
	}

	/**
	 * Parse price from formatted string.
	 */
	function parse_price(price_string) {
		// Use accounting.js if available (bundled with WooCommerce)
		if (typeof accounting !== 'undefined' && typeof woocommerce_params !== 'undefined') {
			return accounting.unformat(
				price_string,
				woocommerce_params.currency_format_decimal_sep
			);
		}

		// Fallback: manual parsing
		if (typeof woocommerce_params === 'undefined') {
			return parseFloat(price_string.replace(/[^0-9.-]/g, ''));
		}

		const decimal_sep = woocommerce_params.currency_format_decimal_sep || '.';
		const thousand_sep = woocommerce_params.currency_format_thousand_sep || ',';

		// Remove thousand separators and replace decimal separator with '.'
		const cleaned = price_string
			.replace(new RegExp('\\' + thousand_sep, 'g'), '')
			.replace(new RegExp('\\' + decimal_sep, 'g'), '.');

		// Extract number
		const match = cleaned.match(/[\d.]+/);
		return match ? parseFloat(match[0]) : 0;
	}

	/**
	 * Format price as string.
	 */
	function format_price(price) {
		// Use accounting.js if available (bundled with WooCommerce)
		if (typeof accounting !== 'undefined' && typeof woocommerce_params !== 'undefined') {
			return accounting.formatMoney(price, {
				symbol: '',
				decimal: woocommerce_params.currency_format_decimal_sep,
				thousand: woocommerce_params.currency_format_thousand_sep,
				precision: parseInt(woocommerce_params.currency_format_num_decimals),
				format: ''
			});
		}

		// Fallback: manual formatting
		if (typeof woocommerce_params === 'undefined') {
			return price.toFixed(2);
		}

		const decimal_sep = woocommerce_params.currency_format_decimal_sep || '.';
		const thousand_sep = woocommerce_params.currency_format_thousand_sep || ',';
		const decimals = parseInt(woocommerce_params.currency_format_num_decimals || 2);

		// Round to specified decimals
		const fixed = price.toFixed(decimals);

		// Split into integer and decimal parts
		const parts = fixed.split('.');
		const integer = parts[0];
		const decimal = parts[1];

		// Add thousand separators
		let formatted_integer = integer;
		if (thousand_sep) {
			formatted_integer = integer.replace(/\B(?=(\d{3})+(?!\d))/g, thousand_sep);
		}

		// Combine with decimal separator
		return decimal ? formatted_integer + decimal_sep + decimal : formatted_integer;
	}

	/**
	 * Get regex for matching prices in formatted strings.
	 */
	function get_price_regex() {
		if (typeof woocommerce_params === 'undefined') {
			return /[\d,]+\.?\d*/g;
		}

		const thousand_sep = woocommerce_params.currency_format_thousand_sep || ',';
		const decimal_sep = woocommerce_params.currency_format_decimal_sep || '.';

		const thousand_regex = thousand_sep
			? '\\d{1,3}(\\' + thousand_sep + '\\d{3})*'
			: '(\\d+)';

		return new RegExp(
			thousand_regex + '(\\' + decimal_sep + '\\d+)?',
			'gm'
		);
	}

	// Initialize fees functionality
	setup_variation_fees();

	window.kadence_woo_extras_init_swatches = init_swatches;

	/**
	 * Swatches Accordion (ported from Iconic Attribute Swatches).
	 */
	var kadence_sk_accordion_els = {};

	function kadence_sk_accordion_debounce(func, wait) {
		var timeout;
		return function () {
			var context = this;
			var args = arguments;
			clearTimeout(timeout);
			timeout = setTimeout(function () {
				func.apply(context, args);
			}, wait);
		};
	}

	function kadence_sk_accordion_no_selection_text() {
		return wp.i18n.__("No selection", "kadence-shop-kit");
	}

	function kadence_sk_accordion_get_hidden_elements_height($element) {
		$element.height("auto");
		var height = $element.height();
		$element.height(0);
		return height;
	}

	function kadence_sk_accordion_cache($product) {
		kadence_sk_accordion_els.$product = $product;
		kadence_sk_accordion_els.$table = $product.find("table.variations");
		kadence_sk_accordion_els.$trs = kadence_sk_accordion_els.$table.find(
			">tbody>tr"
		);
		kadence_sk_accordion_els.$td_labels = kadence_sk_accordion_els.$table.find(
			">tbody>tr>.label"
		);
	}

	function kadence_sk_accordion_setup_html() {
		kadence_sk_accordion_els.$td_labels.each(function () {
			var $label = $(this);
			var $row = $label.closest("tr");
			var $variation_wrap = $row.find(".single_variation_wrap");

			if (
				$variation_wrap.length > 0 ||
				$label.find(".kadence-shop-kit-accordion__handle").length > 0
			) {
				return;
			}

			$row.addClass("kadence-shop-kit-accordion__row");
			$label.append(
				"<span class='kadence-shop-kit-accordion__handle'></span>"
			);

			var $label_el = $label.find("label").first();
			if (
				$label_el.length &&
				!$label_el.find(".kadence-shop-kit-accordion__selection").length
			) {
				$label_el.append(
					"<span class='kadence-shop-kit-accordion__selection'>: " +
						kadence_sk_accordion_no_selection_text() +
						"</span>"
				);
			}
		});
	}

	function kadence_sk_accordion_update_selection($select) {
		var $row = $select.closest("tr");
		var $selection = $row
			.find(".label .kadence-shop-kit-accordion__selection")
			.first();

		if (!$selection.length) {
			return;
		}

		var value = $select.val();
		var text = kadence_sk_accordion_no_selection_text();

		if (value) {
			var $selected = $select.find("option:selected");
			if ($selected.length && $selected.text()) {
				text = $selected.text();
			}
		}

		$selection.text(": " + text);
	}

	function kadence_sk_accordion_selection_handler() {
		var $table = kadence_sk_accordion_els.$table;

		$table.on("change", "select", function () {
			kadence_sk_accordion_update_selection($(this));
		});

		$table.find("select").each(function () {
			kadence_sk_accordion_update_selection($(this));
		});

		kadence_sk_accordion_els.$product
			.find(".variations_form")
			.on("reset_data", function () {
				$table.find("select").each(function () {
					kadence_sk_accordion_update_selection($(this));
				});
			});
	}

	function kadence_sk_accordion_click_handler() {
		kadence_sk_accordion_els.$td_labels.on("click", function () {
			var $tr = $(this).parent();
			var $value = $(this).siblings(".value");

			if (!$tr.hasClass("kadence-shop-kit-accordion--active")) {
				var height = kadence_sk_accordion_get_hidden_elements_height(
					$value
				);
				$value.show();
				$value.height(height);
				$tr.addClass("kadence-shop-kit-accordion--active");
				$value.css("overflow", "hidden");
				window.setTimeout(function () {
					$value.css("overflow", "visible");
				}, 150);
			} else {
				$tr.removeClass("kadence-shop-kit-accordion--active");
				$value.css("overflow", "hidden");
				$value.height(0);
				window.setTimeout(function () {
					$value.css("overflow", "visible");
					$value.hide();
				}, 150);
			}
		});
	}

	function kadence_sk_accordion_reset_height() {
		var $active_accordions = $(".kadence-shop-kit-accordion--active");
		if ($active_accordions.length <= 0) {
			return;
		}

		$active_accordions.each(function () {
			var $value = $(this).find("td.value");
			var $children = $value.children();
			var height = 0;

			if ($children.length > 0) {
				$children.each(function () {
					var $child = $(this);
					if (!$child.is(":visible")) {
						return;
					}
					height += $child.outerHeight(true);
				});
			}

			$value.height(height);
		});
	}

	function kadence_sk_accordion_init() {
		var $product = $(".kadence-shop-kit-accordion.product");
		if (!$product.length) {
			return;
		}

		kadence_sk_accordion_cache($product);
		kadence_sk_accordion_setup_html();
		kadence_sk_accordion_click_handler();
		kadence_sk_accordion_selection_handler();

		$(window).on(
			"resize",
			kadence_sk_accordion_debounce(
				kadence_sk_accordion_reset_height,
				250
			)
		);
	}

	kadence_sk_accordion_init();
});
