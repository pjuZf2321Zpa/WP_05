/**
 * Kadence variation swatches
 */
(function ($, window, document, undefined) {
	$.fn.serializeArrayAll = function () {
		var rCRLF = /\r?\n/g;
		return this.map(function () {
			return this.elements ? jQuery.makeArray(this.elements) : this;
		})
			.map(function (i, elem) {
				var val = jQuery(this).val();
				if (val == null) {
					return val == null;
				} else if (this.type == "checkbox" && this.checked == false) {
					return {
						name: this.name,
						value: this.checked ? this.value : "",
					};
				} else {
					return jQuery.isArray(val)
						? jQuery.map(val, function (val, i) {
								return {
									name: elem.name,
									value: val.replace(rCRLF, "\r\n"),
								};
						  })
						: {
								name: elem.name,
								value: val.replace(rCRLF, "\r\n"),
						  };
				}
			})
			.get();
	};
	$(".kadence-wp-tips-container").each(function () {
		var $container = $(this);
		var item = $(this).find("#" + $container.attr("aria-describedby"));
		if (item) {
			$(this)
				.on("mouseenter", function (e) {
					item.attr("aria-hidden", "false");
				})
				.on("mouseleave", function (e) {
					item.attr("aria-hidden", "true");
				});
		}
	});
	function addVariations() {
		$(".kadence_catalog_variations_form:not(.variation-running)").each(
			function () {
				const variationForm = $(this);
				if (!variationForm.hasClass("variation-initialized")) {
					const is_catalog = variationForm.data(
						"variation-catalog-mode"
					);
					const useAjax =
						variationForm.data("product_variations") === false;
					variationForm.on(
						"found_variation",
						function (e, variation) {
							console.log("variation found");
							switchThumbnail(variationForm, variation);
							if (!is_catalog) {
								switchPrice(variationForm, variation);
								switchButton(variationForm, variation);
							}
						}
					);
					variationForm.on("click", ".reset_variations", function () {
						console.log("var form click");
						thumbnailReset(variationForm);
						if (!is_catalog) {
							priceReset(variationForm);
							buttonReset(variationForm);
						}
					});
					variationForm.on(
						"change",
						'.variations input[type="radio"]',
						function (e) {
							console.log("var form change");
							var $this = $(this);

							//Get the wrapper select div
							var $option_wrapper = $this.closest(
								".kt-radio-variation-container"
							);

							//Select the option.
							var $wc_select_box = $option_wrapper
								.find("select")
								.first();

							// Decode entities
							var attr_val = $this.val();
							if (attr_val.indexOf('"') !== -1) {
								var current_attr_val =
									"value='" + attr_val + "'";
							} else {
								var current_attr_val =
									'value="' + attr_val + '"';
							}
							$wc_select_box.trigger("focusin");
							if (
								$wc_select_box.find(
									"option[" + current_attr_val + "]"
								).length
							) {
								$wc_select_box
									.trigger("focusin")
									.val(attr_val)
									.trigger("change");
							} else {
								variationForm
									.find(".variations select")
									.val("")
									.change();
								variationForm
									.find(
										".kad_radio_variations .selectedValue"
									)
									.removeClass("selectedValue");
								variationForm
									.find(".kad_radio_variations label")
									.removeClass("kt_disabled ");
								variationForm
									.find(
										'.kad_radio_variations input[type="radio"]:checked'
									)
									.prop("checked", false);
								variationForm.trigger("reset_data");
								// add in the selection
								variationForm
									.find(
										'.kad_radio_variations input[type="radio"][' +
											current_attr_val +
											"]"
									)
									.prop("checked", true);
								$wc_select_box
									.trigger("focusin")
									.val(attr_val)
									.trigger("change");
							}
							variationForm
								.find(".kad_radio_variations .selectedValue")
								.removeClass("selectedValue");
							variationForm
								.find(
									'.kad_radio_variations input[type="radio"]:checked'
								)
								.next()
								.addClass("selectedValue");
						}
					);
					// Disable option fields that are unavaiable for current set of attributes
					variationForm.on(
						"woocommerce_variation_has_changed",
						function () {
							if (useAjax) {
								return;
							}
							var variations = [];
							variationForm
								.find(".variations select")
								.each(function () {
									$(this).trigger("focusin");
									$(this)
										.find("option.enabled")
										.each(function () {
											variations.push($(this).val());
										});
								});
							variationForm
								.find(".variations .kad_radio_variations")
								.each(function (index, el) {
									var current_attr_radio = $(el);
									current_attr_radio
										.find("input")
										.removeClass("attached");
									current_attr_radio
										.find("input")
										.removeClass("enabled");
									current_attr_radio
										.find("label")
										.removeClass("kt_disabled ");
									// Loop through variations
									var i;
									for (i = 0; i < variations.length; ++i) {
										if (variations[i].indexOf('"') !== -1) {
											current_attr_radio
												.find(
													"input[value='" +
														variations[i] +
														"']"
												)
												.addClass(
													"attached " + "enabled"
												);
										} else {
											current_attr_radio
												.find(
													'input[value="' +
														variations[i] +
														'"]'
												)
												.addClass(
													"attached " + "enabled"
												);
										}
									}
									current_attr_radio
										.find("input:not(.attached)")
										.next()
										.addClass("kt_disabled");
								});
						}
					);
					variationForm.addClass("variation-initialized");
				}
			}
		);
	}
	function setVariationAttr(element, attr, value) {
		if (undefined === element.attr("data-o_" + attr)) {
			element.attr(
				"data-o_" + attr,
				!element.attr(attr) ? "" : element.attr(attr)
			);
		}
		element.attr(attr, value);
	}
	function resetVariationAttr(element, attr) {
		if (undefined !== element.attr("data-o_" + attr)) {
			element.attr(attr, element.attr("data-o_" + attr));
		}
	}
	function switchThumbnail(variationForm, variation) {
		if (!variation) {
			return;
		}
		if (!variation?.image) {
			return;
		}
		const image = variation.image;
		const productImage = variationForm
			.closest("li, .kt-woo-quickview-content")
			.find("img:first");
		if (!productImage) {
			return;
		}
		setVariationAttr(productImage, "src", image.thumb_src);
		setVariationAttr(productImage, "alt", image.alt);
		if (image?.thumb_srcset) {
			setVariationAttr(productImage, "srcset", image.thumb_srcset);
		} else {
			setVariationAttr(productImage, "srcset", "");
		}
	}
	function thumbnailReset(variationForm) {
		const productImage = variationForm
			.closest("li, .kt-woo-quickview-content")
			.find("img:first");
		if (!productImage) {
			return;
		}
		resetVariationAttr(productImage, "src");
		resetVariationAttr(productImage, "alt");
		resetVariationAttr(productImage, "srcset");
	}
	function switchPrice(variationForm, variation) {
		if (!variation) {
			return;
		}
		if (!variation?.price_html) {
			return;
		}
		const productPrice = variationForm
			.closest("li, .kt-woo-quickview-content")
			.find(".price");
		if (!productPrice) {
			return;
		}
		if (
			variationForm
				.closest("li, .kt-woo-quickview-content")
				.find(".ksk-catalog-price").length
		) {
			productPrice.replaceWith(variation.price_html);
		} else {
			productPrice.after(variation.price_html);
			productPrice
				.removeClass("price")
				.addClass("ksk-catalog-price")
				.hide();
		}
	}
	function priceReset(variationForm) {
		const productPrice = variationForm
			.closest("li, .kt-woo-quickview-content")
			.find(".ksk-catalog-price");
		if (!productPrice) {
			return;
		}
		variationForm
			.closest("li, .kt-woo-quickview-content")
			.find(".price")
			.remove();
		productPrice.addClass("price").removeClass("ksk-catalog-price").show();
	}
	function switchButton(variationForm, variation) {
		if (!variation) {
			return;
		}
		const productButton = variationForm
			.closest("li, .kt-woo-quickview-content")
			.find(".ksk_catalog_variations_button");
		if (!productButton) {
			return;
		}
		const data =
			variationForm
				.find(
					'input:not([name="product_id"]):not([type="radio"]):not([type="button"]), input[type="radio"]:checked, select, button, textarea'
				)
				.serializeArrayAll() || 0;
		const finalData = {
			product_id: variation.variation_id,
		};
		$.each(data, function (i, item) {
			if (item?.name) {
				finalData[item.name] = item.value;
			}
		});
		if (productButton.length) {
			productButton
				.contents()
				.filter(function () {
					return this.nodeType === Node.TEXT_NODE;
				})
				.remove();
		}
		if (productButton.length) {
			productButton.prepend(productButton.attr("data-add_to_cart_text"));
		} else {
			productButton.html(productButton.attr("data-add_to_cart_text"));
		}
		productButton.attr("data-variation_id", variation.variation_id);
		productButton.attr("data-selected_variant", JSON.stringify(finalData));
		productButton.removeClass("added");
	}
	function buttonReset(variationForm) {
		const productButton = variationForm
			.closest("li, .kt-woo-quickview-content")
			.find(".ksk_catalog_variations_button");
		if (!productButton) {
			return;
		}
		if (productButton.length) {
			productButton
				.contents()
				.filter(function () {
					return this.nodeType === Node.TEXT_NODE;
				})
				.remove();
		}
		if (productButton.length) {
			productButton.prepend(
				productButton.attr("data-select_options_text")
			);
		} else {
			productButton.html(productButton.attr("data-select_options_text"));
		}
		productButton.attr("data-variation_id", "");
		productButton.attr("data-selected_variant", "");
		productButton.removeClass("added");
	}
	$(document).on(
		"click",
		".ksk_catalog_variations_button:not(.disabled)",
		function (e) {
			const buttonElement = $(this);
			if (!buttonElement.attr("data-variation_id")) {
				return true;
			}
			if (!buttonElement.attr("data-selected_variant")) {
				return true;
			}
			e.preventDefault();
			buttonElement.removeClass("added");
			buttonElement.addClass("loading");

			var data = JSON.parse(buttonElement.attr("data-selected_variant"));
			data["action"] = "ksk_catalog_add_to_cart";
			// Trigger event.
			$(document.body).trigger("adding_to_cart", [buttonElement, data]);

			$.ajax({
				type: "POST",
				url: ksk_catalog_params.ajax_url,
				data: data,
				success: function (response) {
					if (!response) {
						return;
					}

					if (response.error && response.product_url) {
						window.location = response.product_url;
						return;
					}

					// Redirect to cart option
					if (ksk_catalog_params.cart_redirect_after_add === "yes") {
						window.location = ksk_catalog_params.cart_url;
						return;
					}

					// Trigger event so themes can refresh other areas.
					$(document.body).trigger("added_to_cart", [
						response.fragments,
						response.cart_hash,
						buttonElement,
					]);
					buttonElement.removeClass("loading");
					buttonElement.addClass("added");
				},
				error(errorMsg) {
					buttonElement.removeClass("loading");
					console.log(errorMsg);
				},
				dataType: "json",
			});
		}
	);

	$(window).load(function () {
		addVariations();
	});
	document.addEventListener("kb-query-loaded", function () {
		//re-attach woo variation form javascript
		$(".variations_form:not(.variation-initialized)").each(
			function (index) {
				$(this).wc_variation_form();
			}
		);

		addVariations();
	});
	document.addEventListener("kt-quickview-load", function () {
		addVariations();
		//re-attach woo variation form javascript
		$(".kt-woo-quickview-content .variations_form").wc_variation_form();
	});

	window.kadence_woo_extras_init_catalog_swatches = addVariations;
})(jQuery, window, document);

var kt_woo_extra_isMobile = {
	Android: function () {
		return navigator.userAgent.match(/Android/i);
	},
	BlackBerry: function () {
		return navigator.userAgent.match(/BlackBerry/i);
	},
	iOS: function () {
		return navigator.userAgent.match(/iPhone|iPad|iPod/i);
	},
	Opera: function () {
		return navigator.userAgent.match(/Opera Mini/i);
	},
	Windows: function () {
		return navigator.userAgent.match(/IEMobile/i);
	},
	any: function () {
		return (
			kt_woo_extra_isMobile.Android() ||
			kt_woo_extra_isMobile.BlackBerry() ||
			kt_woo_extra_isMobile.iOS() ||
			kt_woo_extra_isMobile.Opera() ||
			kt_woo_extra_isMobile.Windows()
		);
	},
};

jQuery(document).ready(function ($) {
	var select2Enable = typeof $().select2 == "function";
	function init_cat_swatches() {
		$(".kadence_catalog_variations_form").each(function () {
			var $vform = $(this);
			var $vform_select = $vform.find(
				".variations td.product_value select"
			);
			var $variations = $vform.find(".single_variation_wrap");
			var $use_ajax = $vform.data("product_variations") === false;
			var $product_variations = $vform.data("product_variations");
			var count_variations = $vform.find(".variations td.value").length;

			$vform.on(
				"change",
				'.variations input[type="radio"]',
				function (e) {
					var $this = $(this);

					//Get the wrapper select div
					var $option_wrapper = $this.closest(
						".kt-radio-variation-container"
					);

					//Select the option.
					var $wc_select_box = $option_wrapper.find("select").first();

					// Decode entities
					var attr_val = $this.val();
					if (attr_val.indexOf('"') !== -1) {
						var current_attr_val = "value='" + attr_val + "'";
					} else {
						var current_attr_val = 'value="' + attr_val + '"';
					}
					//$wc_select_box.trigger('focusin').children("[value='" + attr_val + "']").prop("selected", "selected").change();
					$wc_select_box.trigger("focusin");
					if (
						$wc_select_box.find("option[" + current_attr_val + "]")
							.length
					) {
						$wc_select_box
							.trigger("focusin")
							.val(attr_val)
							.trigger("change");
					} else {
						$vform.find(".variations select").val("").change();
						$vform
							.find(".kad_radio_variations .selectedValue")
							.removeClass("selectedValue");
						$vform
							.find(".kad_radio_variations label")
							.removeClass("kt_disabled ");
						if (select2Enable) {
							$(".variations .kad-select").select2({
								minimumResultsForSearch: -1,
							});
						}
						$vform
							.find(
								'.kad_radio_variations input[type="radio"]:checked'
							)
							.prop("checked", false);
						$vform.trigger("reset_data");
						// add in the selection
						$vform
							.find(
								'.kad_radio_variations input[type="radio"][' +
									current_attr_val +
									"]"
							)
							.prop("checked", true);
						$wc_select_box
							.trigger("focusin")
							.val(attr_val)
							.trigger("change");
					}
					$vform
						.find(".kad_radio_variations .selectedValue")
						.removeClass("selectedValue");
					$vform
						.find(
							'.kad_radio_variations input[type="radio"]:checked'
						)
						.next()
						.addClass("selectedValue");
				}
			);
			// Support for Classic Theme select2
			if (select2Enable) {
				$vform.on("woocommerce_variation_has_changed", function () {
					if ($use_ajax) {
						if (
							$(window).width() > 790 &&
							!kt_woo_extra_isMobile.any()
						) {
							$(".kad-select").select2({
								minimumResultsForSearch: -1,
							});
						}
					}
				});
			}
			// Disable option fields that are unavaiable for current set of attributes
			$vform.on("woocommerce_variation_has_changed", function () {
				if ($use_ajax) {
					return;
				}
				var kt_current_settings = {};
				var variations = [];
				$vform.find(".variations select").each(function () {
					$(this).trigger("focusin");
					$(this)
						.find("option.enabled")
						.each(function () {
							variations.push($(this).val());
						});
				});
				$vform
					.find(".variations .kad_radio_variations")
					.each(function (index, el) {
						var current_attr_radio = $(el);
						var current_attr_name =
							current_attr_radio.data("attribute_name");
						current_attr_radio
							.find("input")
							.removeClass("attached");
						current_attr_radio.find("input").removeClass("enabled");
						current_attr_radio
							.find("label")
							.removeClass("kt_disabled ");

						// Loop through variations
						var i;
						for (i = 0; i < variations.length; ++i) {
							if (variations[i].indexOf('"') !== -1) {
								current_attr_radio
									.find(
										"input[value='" + variations[i] + "']"
									)
									.addClass("attached " + "enabled");
							} else {
								current_attr_radio
									.find(
										'input[value="' + variations[i] + '"]'
									)
									.addClass("attached " + "enabled");
							}
						}
						current_attr_radio
							.find("input:not(.attached)")
							.next()
							.addClass("kt_disabled");
					});
			});

			$variations.on("hide_variation", function () {
				$(this).css("height", "auto");
			});
			// Upon gaining focus
			$vform_select.on("select2-opening", function () {
				if (!$use_ajax) {
					$vform.trigger("woocommerce_variation_select_focusin");
					$vform.trigger("check_variations", [
						$(this).data("attribute_name") || $(this).attr("name"),
						true,
					]);
				}
			});
			$(function () {
				if (typeof wc_add_to_cart_variation_params !== "undefined") {
					$(".variations_form").each(function () {
						$(this)
							.find('.variations input[type="radio"]:checked')
							.change();
					});
				}
			});
		});
	}
});
