<?php
/**
 * Kadence_Woo Extras Options Class
 *
 * @package Kadence Woo Extras
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Main Kadence_Woo_Extras_Settings class
 */
class KWE_Options {
	const OPT_NAME = 'kt_woo_extras';
	/**
	 * Instance control
	 *
	 * @var null
	 */
	private static $instance = null;

	/**
	 * Cached raw stored values (no defaults applied).
	 *
	 * @var array<string, mixed>|null
	 */
	private static $options = null;

	/**
	 * Cached merged settings (stored values + defaults).
	 *
	 * @var array<string, mixed>|null
	 */
	private static $merged_options = null;

	/**
	 * Cached hardcoded default values.
	 *
	 * @var array<string, mixed>|null
	 */
	private static $default_options = null;

	/**
	 * Instance Control
	 *
	 * @return KWE_Options
	 */
	public static function get_instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}
	/**
	 * Action on init.
	 */
	public function __construct() {
		add_action( 'after_setup_theme', array( $this, 'get_settings_loaded' ), 30 );
		add_filter( 'pre_update_option_' . self::OPT_NAME, array( $this, 'filter_settings' ), 10, 2 );
		add_action( 'update_option_' . self::OPT_NAME, array( __CLASS__, 'clear_stored_values_cache' ), 10, 0 );
		add_action( 'update_site_option_' . self::OPT_NAME, array( __CLASS__, 'clear_stored_values_cache' ), 10, 0 );
	}
	/**
	 * Populate $GLOBALS['kt_woo_extras'] with merged settings.
	 */
	public function get_settings_loaded(): void {
		$GLOBALS[ self::OPT_NAME ] = self::get_all();
	}

	/**
	 * Get a single setting value, merged with defaults.
	 *
	 * @param string $key      Option key.
	 * @param mixed  $fallback Fallback if key is absent from stored values and defaults.
	 * @return mixed
	 */
	public static function get( string $key, $fallback = null ) {
		$all   = self::get_all();
		$value = array_key_exists( $key, $all ) ? $all[ $key ] : $fallback;
		return apply_filters( 'kadence_woo_extras_option_value', $value, $key );
	}

	/**
	 * Get all settings merged with defaults.
	 *
	 * Stored values take precedence over Settings Engine defaults, which take
	 * precedence over hardcoded defaults.
	 *
	 * @return array<string, mixed>
	 */
	public static function get_all(): array {
		if ( is_null( self::$merged_options ) ) {
			$stored = self::get_stored_values();
			if ( ! is_array( $stored ) ) {
				$stored = array();
			}
			$settings_engine_defaults = self::get_default_values();
			if ( ! is_array( $settings_engine_defaults ) ) {
				$settings_engine_defaults = array();
			}
			self::$merged_options = self::parse_args_recursive( $stored, self::parse_args_recursive( $settings_engine_defaults, self::defaults() ) );
		}
		return self::$merged_options;
	}

	/**
	 * Drop cached options after update so get_all() reflects DB.
	 */
	public static function clear_stored_values_cache(): void {
		self::$options        = null;
		self::$merged_options = null;
	}

	/**
	 * @param mixed $new_settings The new option value being saved.
	 * @param mixed $old_settings The previous option value.
	 *
	 * @return mixed
	 */
	public function filter_settings( $new_settings, $old_settings ) {
		if ( ! is_string( $new_settings ) ) {
			return $new_settings;
		}

		if ( ! is_string( $old_settings ) ) {
			$old_settings = '{}';
		}

		try {
			/** @var array<string, mixed> $new */
			$new = (array) json_decode( $new_settings, true, 512, JSON_THROW_ON_ERROR );
			/** @var array<string, mixed> $old */
			$old = (array) json_decode( $old_settings, true, 512, JSON_THROW_ON_ERROR );
		} catch ( JsonException $e ) {
			return $new_settings;
		}

		$new = apply_filters( 'kadence_woo_extras_filter_settings', $new, $old );

		// Merge partial saves with existing stored data to avoid truncating unmodified keys.
		// Defaults are applied on retrieval in get_all(), not stored in the DB.
		$merged = self::parse_args_recursive( $new, $old );

		return wp_json_encode( $merged );
	}

	/**
	 * Get default values from Kadence Settings Engine.
	 *
	 * @return array<string, mixed>
	 */
	private static function get_default_values(): array {
		if ( ! class_exists( 'Kadence_Settings_Engine' ) ) {
			return array();
		}
		$sections = Kadence_Settings_Engine::construct_sections( self::OPT_NAME );
		return Kadence_Settings_Engine::default_values( self::OPT_NAME, $sections );
	}

	/**
	 * Hardcoded fallback defaults not covered by the Settings Engine.
	 *
	 * @return array<string, mixed>
	 */
	private static function defaults(): array {
		if ( is_null( self::$default_options ) ) {
			self::$default_options = apply_filters(
				'kadence_woo_extras_defaults',
				array(
					'content_width' => array(
						'size' => 1290,
						'unit' => 'px',
					),
				)
			);
		}
		return self::$default_options;
	}

	/**
	 * Recursive version of wp_parse_args() for associative arrays.
	 *
	 * Values from $args win over $defaults, but missing sub-keys inside
	 * nested associative arrays are filled in from the defaults so newly
	 * introduced sub-settings are always populated on retrieval without
	 * altering what is stored in the database.
	 *
	 * @param array<string, mixed> $args     Primary values (stored settings).
	 * @param array<string, mixed> $defaults Fallback values.
	 *
	 * @return array<string, mixed>
	 */
	private static function parse_args_recursive( array $args, array $defaults ): array {
		foreach ( $defaults as $key => $default_value ) {
			if ( ! array_key_exists( $key, $args ) ) {
				$args[ $key ] = $default_value;
				continue;
			}

			if ( is_array( $default_value ) && is_array( $args[ $key ] ) ) {
				$args[ $key ] = self::parse_args_recursive( $args[ $key ], $default_value );
			}
		}

		return $args;
	}

	/**
	 * Get raw stored values from the database (no defaults applied).
	 *
	 * @return array<string, mixed>|null
	 */
	private static function get_stored_values(): ?array {
		if ( is_null( self::$options ) ) {
			$stored = ( apply_filters( 'kadence_shopkit_network', false ) ? get_site_option( self::OPT_NAME, array() ) : get_option( self::OPT_NAME, array() ) );
			if ( ! empty( $stored ) && ! is_array( $stored ) ) {
				$decoded = is_scalar( $stored ) ? json_decode( (string) $stored, true ) : null;
				$stored  = is_array( $decoded ) ? $decoded : null;
			}
			if ( ! is_array( $stored ) && ! is_null( $stored ) ) {
				$stored = null;
			}
			self::$options = $stored;
		}
		return self::$options;
	}
}
KWE_Options::get_instance();
