<?php

namespace GiveRecurring\PaymentGatewayModules\Modules\GoCardless\Webhooks;

use GiveGoCardless\DataTransferObjects\GoCardlessWebhookNotification;
use GiveGoCardless\Gateway\GoCardlessGateway;
use Exception;

/**
 * @since 2.14.0
 */
class GoCardlessSubscriptionWebhookNotificationHandler
{
    /**
     * @since 2.14.0
     *
     * @throws Exception
     */
    public function __invoke(GoCardlessWebhookNotification $notification)
    {
        if ($notification->resourceType === 'subscriptions') {
            $this->handleSubscriptionEvent($notification);
        }
    }

    /**
     * @since 2.14.0
     *
     * @throws Exception
     */
    protected function handleSubscriptionEvent(GoCardlessWebhookNotification $notification)
    {
        $isRecurringDonation = isset($notification->links['subscription']);
        if (!$isRecurringDonation){
            return;
        }

        $gatewaySubscriptionId = $notification->links['subscription'];

        $subscription = give()->subscriptions->getByGatewaySubscriptionId($gatewaySubscriptionId);

        if ( ! $subscription) {
            return;
        }

        switch ($notification->action) {
            case 'payment_created':
                if (empty($notification->links['payment'])) {
                    return;
                }

                $gatewayTransactionId = $notification->links['payment'];
                $initialDonation      = $subscription->initialDonation();

                if ($subscription->totalDonations() === 1 && $initialDonation && empty($initialDonation->gatewayTransactionId)) {
                    GoCardlessGateway::webhook()->events->subscriptionFirstDonation(
                        $gatewayTransactionId,
                        __('Subscription First Donation Updated With Transaction ID.', 'give-recurring'),
                        false,
                        false,
                        $gatewaySubscriptionId
                    );
                } else {
                    GoCardlessGateway::webhook()->events->subscriptionRenewalDonation($gatewaySubscriptionId, $gatewayTransactionId);
                }

                break;
            case 'cancelled':
                GoCardlessGateway::webhook()->events->subscriptionCancelled($gatewaySubscriptionId);
                break;
            case 'finished':
                GoCardlessGateway::webhook()->events->subscriptionCompleted($gatewaySubscriptionId);
                break;
        }
    }
}
