<?php

namespace GiveRecurring\PaymentGatewayModules\Modules\Square\Actions;

use Give\Framework\Exceptions\Primitives\Exception;
use Give\Subscriptions\Models\Subscription;
use GiveRecurring\PaymentGatewayModules\Modules\Square\Api\GetSubscription;
use GiveRecurring\PaymentGatewayModules\Modules\Square\Api\UpdateSubscription;
use GiveSquare\Square\Api\Exceptions\ApiRequestException;

/**
 * @see https://developer.squareup.com/reference/square/objects/Subscription
 *
 * @since 2.3.0
 */
class UpdateSquareSubscriptionPaymentMethod
{
    /**
     * @since 2.20.3 Store the card on the Square customer that owns the subscription instead of the donor's customer
     * @since 2.19.1 Forward the buyer verification token to the card being stored
     * @since 2.3.0
     *
     * @param Subscription $subscription      The GiveWP subscription whose Square card is being replaced.
     * @param string       $squareSourceId    Square payment token for the new card.
     * @param string       $verificationToken Buyer verification token, when the card required a challenge.
     *
     * @throws ApiRequestException|Exception
     */
    public function __invoke(Subscription $subscription, string $squareSourceId, string $verificationToken = '')
    {
        $idempotencyKey = uniqid();

        /*
         * Square rejects a card that belongs to a different customer than the subscription's, and the donor's
         * stored customer can differ from it, e.g. when an older version linked the donor to the wrong customer.
         */
        $squareSubscription = (new GetSubscription())((string)$subscription->gatewaySubscriptionId);
        $squareCustomerId = (string)($squareSubscription->customer_id ?? '');

        if ( ! $squareCustomerId) {
            throw new Exception('Square did not return a customer for this subscription.');
        }

        $newCardId = [
            'card_id' => (new GetSquareCardId())(
                $idempotencyKey,
                $squareCustomerId,
                $squareSourceId,
                $verificationToken
            ),
        ];
        $requestData = [
            "subscription" => $newCardId,
        ];

        (new UpdateSubscription())($subscription->gatewaySubscriptionId, $requestData);
    }
}
