<?php

namespace GiveRecurring\PaymentGatewayModules\Modules\Square\Actions;

use Give\Framework\Exceptions\Primitives\Exception;
use GiveRecurring\PaymentGatewayModules\Modules\Square\Api\CreateCard;

/**
 * @see https://developer.squareup.com/docs/cards-api/walkthrough-seller-card
 *
 * @since 2.3.0
 */
class GetSquareCardId
{
    /**
     * @since 2.19.1 Attach the buyer verification token so cards subject to SCA are not declined
     * @since 2.3.0
     *
     * @throws Exception
     */
    public function __invoke(
        string $idempotencyKey,
        string $squareCustomerId,
        string $squareSourceId,
        string $verificationToken = ''
    ): string {
        $requestData = [
            "card" => [
                "customer_id" => $squareCustomerId,
            ],
            "source_id" => $squareSourceId,
            "idempotency_key" => $idempotencyKey,
        ];

        /*
         * Issuers subject to Strong Customer Authentication refuse to store the card unless the token from the
         * donor's challenge is attached.
         */
        if ($verificationToken) {
            $requestData['verification_token'] = $verificationToken;
        }

        return (new CreateCard())($requestData)->id;
    }
}
