<?php

namespace GiveRecurring\PaymentGatewayModules\Modules\Razorpay\Webhooks;

use Give\Donations\Models\DonationNote;
use Give\Donations\ValueObjects\DonationStatus;
use Give\Framework\Support\Facades\ActionScheduler\AsBackgroundJobs;
use Give\Subscriptions\ValueObjects\SubscriptionStatus;

/**
 * @since 2.9.0
 */
class RazorpaySubscriptionWebhookNotificationHandler
{
    /**
     * @since 2.9.0
     *
     * @see https://razorpay.com/docs/webhooks/payloads/subscriptions/
     */
    public function __invoke($webhookNotification)
    {
        switch ($webhookNotification->event) {
            /** @see https://razorpay.com/docs/webhooks/payloads/subscriptions/#subscription-cancelled */
            case 'subscription.cancelled':
                $razorpaySubscriptionId = $webhookNotification->payload->subscription->entity->id;
                $this->setSubscriptionCancelledAsyncEvent($razorpaySubscriptionId);
                break;
            /** @see https://razorpay.com/docs/webhooks/payloads/invoices/#invoice-paid */
            case 'invoice.paid':
                $razorpayPaymentId = $webhookNotification->payload->invoice->entity->payment_id;
                if ( ! give()->donations->getByGatewayTransactionId($razorpayPaymentId)) {
                    $razorpaySubscriptionId = $webhookNotification->payload->invoice->entity->subscription_id;

                    // A donor who authorises the mandate but never gets back from Checkout leaves the
                    // initial donation pending. This first invoice settles that donation; treating it as a
                    // renewal would bank the charge against a new record and strand the original.
                    if ($this->maybeCompletePendingInitialDonation($razorpaySubscriptionId, $razorpayPaymentId)) {
                        break;
                    }

                    $this->setSubscriptionRenewalPaymentAsyncEvent($razorpaySubscriptionId, $razorpayPaymentId);
                }
                break;
        }
    }

    /**
     * Settles a subscription's initial donation from its first invoice.
     *
     * @since 2.20.0
     *
     * @return bool Whether this payment was consumed by the initial donation.
     */
    private function maybeCompletePendingInitialDonation(
        string $gatewaySubscriptionId,
        string $gatewayTransactionId
    ): bool {
        $subscription = give()->subscriptions->getByGatewaySubscriptionId($gatewaySubscriptionId);

        if ( ! $subscription) {
            return false;
        }

        $donation = $subscription->initialDonation();

        if ( ! $donation || ! $donation->status->isPending()) {
            return false;
        }

        $donation->status = DonationStatus::COMPLETE();
        $donation->gatewayTransactionId = $gatewayTransactionId;
        $donation->save();

        $subscription->status = SubscriptionStatus::ACTIVE();
        $subscription->transactionId = $gatewayTransactionId;
        $subscription->save();

        DonationNote::create([
            'donationId' => $donation->id,
            'content' => sprintf(
                __('Transaction Successful. Razorpay Transaction ID: %s. Confirmed by webhook.',
                    'give-recurring'),
                $gatewayTransactionId
            ),
        ]);

        return true;
    }

    /**
     * @since 2.9.0
     */
    public function setSubscriptionRenewalPaymentAsyncEvent(
        string $gatewaySubscriptionId,
        string $gatewayTransactionId
    ) {
        $this->enqueueAsyncAction('givewp_razorpay_event_subscription_renewal_donation',
            [$gatewaySubscriptionId, $gatewayTransactionId]);
    }

    /**
     * @since 2.9.0
     */
    private function setSubscriptionCancelledAsyncEvent(string $gatewaySubscriptionId)
    {
        $this->enqueueAsyncAction('givewp_razorpay_event_subscription_cancelled', [$gatewaySubscriptionId]);
    }

    /**
     * @since 2.9.0
     */
    private function enqueueAsyncAction(string $hook, array $args)
    {
        AsBackgroundJobs::enqueueAsyncAction($hook, $args, 'give-recurring-razorpay');
    }
}
