<?php

namespace GiveRecurring\PaymentGatewayModules\Modules\Razorpay;

use Exception;
use Give\Donations\Models\Donation;
use Give\Donations\Models\DonationNote;
use Give\Donations\ValueObjects\DonationStatus;
use Give\Framework\Http\Response\Types\RedirectResponse;
use Give\Framework\PaymentGateways\Commands\GatewayCommand;
use Give\Framework\PaymentGateways\Contracts\Subscription\SubscriptionDashboardLinkable;
use Give\Framework\PaymentGateways\Exceptions\PaymentGatewayException;
use Give\Framework\PaymentGateways\Log\PaymentGatewayLog;
use Give\Framework\PaymentGateways\SubscriptionModule;
use Give\Subscriptions\Models\Subscription;
use Give\Subscriptions\ValueObjects\SubscriptionStatus;
use GiveRazorpay\Gateway\VerifiesRazorpayReturn;
use GiveRazorpay\Repositories\RazorpayRepository;
use GiveRazorpay\ValueObjects\RazorpayMetaKey;
use GiveRazorpay\ValueObjects\RazorpayRoute;

/**
 * @since 2.9.0
 */
class RazorpayGatewaySubscriptionModule extends SubscriptionModule implements SubscriptionDashboardLinkable
{
    use VerifiesRazorpayReturn;

    /**
     * @since 2.20.0
     * @var array
     */
    public $secureRouteMethods = [
        RazorpayRoute::HANDLE_SUBSCRIPTION_RETURN,
    ];

    /**
     * Creates the Razorpay subscription server-side, once the donation has passed server validation, and
     * hands the Checkout options back to the browser so the donor can authorise it.
     *
     * @since 2.20.0 create the subscription server-side and return the Checkout options to the browser
     * @since 2.9.0
     *
     * @throws Exception
     */
    public function createSubscription(
        Donation $donation,
        Subscription $subscription,
        $gatewayData
    ): GatewayCommand {
        try {
            [$customerId, $razorpaySubscriptionId] = $this->createRazorpaySubscription($donation, $subscription);
        } catch (Exception $e) {
            $this->failSubscription($donation, $subscription, $e->getMessage());

            throw new PaymentGatewayException($e->getMessage());
        }

        $subscription->gatewaySubscriptionId = $razorpaySubscriptionId;
        $subscription->save();

        give(RazorpayRepository::class)->saveCustomerId($donation, $customerId);

        $checkoutOptions = array_merge(
            $this->gateway->getBaseCheckoutOptions($donation),
            [
                'subscription_id' => $razorpaySubscriptionId,
                'currency' => $subscription->amount->getCurrency()->getCode(),
                'callback_url' => $this->gateway->generateSecureGatewayRouteUrl(
                    RazorpayRoute::HANDLE_SUBSCRIPTION_RETURN,
                    $donation->id,
                    [
                        RazorpayRoute::DONATION_ID => $donation->id,
                        RazorpayRoute::SUBSCRIPTION_ID => $subscription->id,
                        RazorpayRoute::SUCCESS_URL => $gatewayData['successUrl'],
                        RazorpayRoute::CANCEL_URL => $gatewayData['cancelUrl'],
                    ]
                ),
            ]
        );

        return $this->gateway->getCheckoutCommand($donation, $checkoutOptions, $gatewayData['cancelUrl']);
    }

    /**
     * Razorpay redirects the donor back here once they have authorised the subscription. Nothing is trusted
     * until the signature has been verified against the merchant secret.
     *
     * @since 2.20.0
     *
     * @throws Exception
     */
    public function handleSubscriptionReturn(array $queryParams): RedirectResponse
    {
        $donation = $this->getRouteDonation($queryParams);
        $subscription = $donation->subscriptionId ? Subscription::find($donation->subscriptionId) : null;

        if ( ! $subscription) {
            throw new PaymentGatewayException(__('Subscription not found.', 'give-recurring'));
        }

        // Razorpay can post here more than once, and a settled donation must not be reopened by a replay.
        if ( ! $donation->status->isPending()) {
            return new RedirectResponse($this->getSafeRedirectUrl(
                $donation->status->isComplete()
                    ? $queryParams[RazorpayRoute::SUCCESS_URL]
                    : $queryParams[RazorpayRoute::CANCEL_URL]
            ));
        }

        try {
            $response = $this->getVerifiedRazorpayReturn($subscription->donationFormId);

            $this->assertRazorpayReturnBelongsTo(
                $response,
                (string)$subscription->gatewaySubscriptionId,
                'razorpay_subscription_id'
            );
        } catch (Exception $e) {
            $this->failSubscription($donation, $subscription, $e->getMessage());

            return new RedirectResponse($this->getSafeRedirectUrl($queryParams[RazorpayRoute::CANCEL_URL]));
        }

        $razorpayPaymentId = $response['razorpay_payment_id'];

        $donation->status = DonationStatus::COMPLETE();
        $donation->gatewayTransactionId = $razorpayPaymentId;
        $donation->save();

        $subscription->status = SubscriptionStatus::ACTIVE();
        $subscription->transactionId = $razorpayPaymentId;
        $subscription->save();

        DonationNote::create([
            'donationId' => $donation->id,
            'content' => sprintf(
                __('Transaction Successful. Razorpay Transaction ID: %s | Razorpay Subscription ID: %s',
                    'give-recurring'),
                $razorpayPaymentId,
                $subscription->gatewaySubscriptionId
            ),
        ]);

        give_update_meta($donation->id, RazorpayMetaKey::DONATION_RESPONSE, $response);
        give_update_meta($donation->id, RazorpayMetaKey::DONOR_PHONE, $donation->phone);

        return new RedirectResponse($this->getSafeRedirectUrl($queryParams[RazorpayRoute::SUCCESS_URL]));
    }

    /**
     * @since 2.9.0
     *
     * @throws Exception
     */
    public function cancelSubscription(Subscription $subscription): bool
    {
        try {
            $cancelled = $this->cancelRazorpaySubscription($subscription);

            if ($cancelled) {
                $subscription->status = SubscriptionStatus::CANCELLED();
                $subscription->save();
            }

            return $cancelled;
        } catch (Exception $e) {
            throw new PaymentGatewayException($e->getMessage());
        }
    }

    /**
     * @since 2.9.0
     */
    public function gatewayDashboardSubscriptionUrl(Subscription $subscription): string
    {
        $base = 'https://dashboard.razorpay.com/app/subscriptions/';

        return esc_url($base . $subscription->gatewaySubscriptionId);
    }

    /**
     * Creates the Razorpay customer, plan and subscription. The whole chain shares one Api instance because
     * the SDK keeps the merchant credentials in static properties.
     *
     * @since 2.20.0
     *
     * @return array{0: string, 1: string} The Razorpay customer id and subscription id.
     *
     * @throws Exception
     */
    protected function createRazorpaySubscription(Donation $donation, Subscription $subscription): array
    {
        try {
            $api = give(RazorpayRepository::class)->getApi($subscription->donationFormId);
            $period = $subscription->period->getValue();

            $customer = $api->customer->create([
                'name' => trim("$donation->firstName $donation->lastName"),
                'email' => $donation->email,
                'contact' => (string)$donation->phone,
                // Reuse the existing Razorpay customer instead of failing when this donor already has one.
                // The API only reads this as a string, and an integer 0 still fails on a returning donor.
                'fail_existing' => '0',
            ]);

            $plan = $api->plan->create(apply_filters('give_razorpay_create_plan_args', [
                'period' => $this->getRazorpayPeriod($period),
                'interval' => $this->getRazorpayInterval($period, $subscription->frequency),
                'item' => [
                    'name' => $donation->formTitle,
                    'description' => __('Donation processed via Give - Donations plugin for WordPress',
                        'give-recurring'),
                    'amount' => $subscription->amount->formatToMinorAmount(),
                    'currency' => $subscription->amount->getCurrency()->getCode(),
                ],
            ]));

            $razorpaySubscription = $api->subscription->create(apply_filters('give_razorpay_subscription_args', [
                'plan_id' => $plan->id,
                'customer_id' => $customer->id,
                'customer_notify' => 0,
                'total_count' => $this->getTotalBillingCycles($subscription),
                'notes' => [
                    'donation_id' => $donation->id,
                    'subscription_id' => $subscription->id,
                ],
            ]));

            return [$customer->id, $razorpaySubscription->id];
        } catch (Exception $e) {
            PaymentGatewayLog::error(
                sprintf('[Razorpay] The subscription creation failed. API response error: %s', $e->getMessage()),
                [
                    'Donation ID' => $donation->id,
                    'Subscription ID' => $subscription->id,
                    'Error' => $e->getMessage(),
                ]
            );

            // The API's own wording describes an integration or account problem the donor can do nothing
            // about, so they are told to try again and the detail is left in the log above.
            throw new PaymentGatewayException(
                __('We could not start your recurring donation with Razorpay. Please try again, and let us know if the problem continues.',
                    'give-recurring')
            );
        }
    }

    /**
     * Razorpay bills quarterly subscriptions as monthly ones on a 3 month interval.
     *
     * @since 2.20.0
     */
    protected function getRazorpayPeriod(string $period): string
    {
        $periods = [
            'day' => 'daily',
            'week' => 'weekly',
            'month' => 'monthly',
            'quarter' => 'monthly',
            'year' => 'yearly',
        ];

        return $periods[$period] ?? $period;
    }

    /**
     * @since 2.20.0
     */
    protected function getRazorpayInterval(string $period, int $frequency): int
    {
        return $period === 'quarter' ? 3 * $frequency : $frequency;
    }

    /**
     * Razorpay requires a finite billing cycle count, so ongoing subscriptions get the most Razorpay will
     * accept for their period.
     *
     * @since 2.20.0
     *
     * @throws Exception
     */
    protected function getTotalBillingCycles(Subscription $subscription): int
    {
        if ($subscription->installments > 0) {
            return $subscription->installments;
        }

        return give(RazorpayRepository::class)->getMaxBillingCyclesForPeriod(
            $subscription->period->getValue(),
            $subscription->frequency
        );
    }

    /**
     * @since 2.20.0
     *
     * @throws Exception
     */
    protected function failSubscription(Donation $donation, Subscription $subscription, string $errorMessage)
    {
        // A subscription that exists at Razorpay keeps charging on its own schedule, so leaving it live
        // against a record we have just given up on bills the donor for something GiveWP treats as dead.
        if ($subscription->gatewaySubscriptionId) {
            try {
                $this->cancelRazorpaySubscription($subscription);
            } catch (Exception $e) {
                PaymentGatewayLog::error(
                    sprintf('[Razorpay] Could not cancel the subscription for a failed donation: %s',
                        $e->getMessage()),
                    [
                        'Donation ID' => $donation->id,
                        'Subscription ID' => $subscription->id,
                        'Razorpay Subscription ID' => $subscription->gatewaySubscriptionId,
                    ]
                );
            }
        }

        $subscription->status = SubscriptionStatus::FAILING();
        $subscription->save();

        $donation->status = DonationStatus::FAILED();
        $donation->save();

        DonationNote::create([
            'donationId' => $donation->id,
            'content' => sprintf(esc_html__('Donation failed. Reason: %s', 'give-recurring'), $errorMessage),
        ]);
    }

    /**
     * @since 2.9.0
     */
    protected function cancelRazorpaySubscription(Subscription $subscription): bool
    {
        // Give_RazorPay_Subscriptions resolves its credentials from $_POST['formId'], which is not set on a
        // gateway route or in the admin, so a per-form account would be cancelled against the global keys.
        give(RazorpayRepository::class)
            ->getApi($subscription->donationFormId)
            ->subscription
            ->fetch($subscription->gatewaySubscriptionId)
            ->cancel();

        return true;
    }
}
