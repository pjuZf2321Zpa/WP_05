<?php

namespace GiveRecurring\PaymentGatewayModules\Modules\PayFast\Webhooks;

use Give\Donations\Models\Donation;
use GivePayFast\Gateway\DataTransferObjects\PayFastWebhookData;
use GivePayFast\Gateway\PayFastGateway;

/**
 * @since 2.19.0
 */
class PayFastSubscriptionITNHandler
{
    /**
     * @since 2.19.0
     */
    public function __invoke(Donation $donation, PayFastWebhookData $payFastWebhookData)
    {
        if ($this->isOneTimeDonation($donation, $payFastWebhookData)) {
            return;
        }

        switch (strtolower($payFastWebhookData->paymentStatus)) {
            case 'complete':
                if ($this->isFirstDonation($donation)) {
                    PayFastGateway::removeScheduleToAbandonPaymentAfterOneHour($donation->id);

                    PayFastGateway::webhook()->events->subscriptionFirstDonation(
                        $payFastWebhookData->transactionId,
                        '',
                        true, // setSubscriptionActive
                        true, // setDonationComplete
                        $payFastWebhookData->gatewaySubscriptionId,
                        $donation->id
                    );
                } else {
                    PayFastGateway::webhook()->events->subscriptionRenewalDonation(
                        $payFastWebhookData->gatewaySubscriptionId,
                        $payFastWebhookData->transactionId
                    );
                }
                break;

            case 'cancelled':
                PayFastGateway::webhook()->events->subscriptionCancelled(
                    $payFastWebhookData->gatewaySubscriptionId
                );
                break;
        }
    }

    /**
     * @since 2.19.0
     */
    private function isOneTimeDonation(Donation $donation, PayFastWebhookData $payFastWebhookData): bool
    {
        return ! $donation->type->isSubscription() || empty($payFastWebhookData->gatewaySubscriptionId);
    }

    /**
     * Returns true when the ITN is for the subscription's first (initial) payment.
     *
     * PayFast always references the initial donation via m_payment_id for every webhook —
     * both first payments and renewals. The distinction is that for a renewal the initial
     * donation is already Complete, whereas for the first payment it is still pending.
     *
     * @since 2.19.0
     */
    private function isFirstDonation(Donation $donation): bool
    {
        $initialDonation = $donation->subscription ? $donation->subscription->initialDonation() : null;

        return $initialDonation
               && $donation->id === $initialDonation->id
               && ! $donation->status->isComplete();
    }
}
