<?php

namespace GiveRecurring\PaymentGateways\PayPalCommerce\PayPalHttpRequests;

use PayPalHttp\HttpRequest;

/**
 * Class CreateProduct
 *
 * This class uses as request to create a product.
 *
 * @since 2.6.0
 */
class CreateProduct extends HttpRequest
{
    /**
     * CreatePlan constructor.
     *
     * @since 2.6.0
     */
    public function __construct(array $headers, array $requestBody)
    {
        parent::__construct('/v1/catalogs/products', 'POST');

        $this->headers = array_merge($this->headers, $headers);
        $this->body = wp_json_encode($requestBody);
    }
}
