<?php

namespace GiveRecurring\PaymentGateways\Stripe\Actions;

use Give\Donations\Models\Donation;
use Give\Donations\Models\DonationNote;
use Give\Framework\Exceptions\Primitives\Exception;
use Give\Framework\PaymentGateways\Log\PaymentGatewayLog;
use Stripe\Customer;
use Stripe\Exception\ApiErrorException;
use Stripe\SetupIntent;

/**
 * Sets the Stripe customer's legacy bank account (default_source) as the customer's default payment method.
 *
 * When a customer has a bank account (ba_) as default_source and no default payment method, Stripe charges the first
 * invoice of a new subscription through the legacy ACH integration. It attaches the bank account as the
 * PaymentIntent's source and leaves setup_future_usage empty, and the Payment Element then rejects the payment.
 * A verified bank account with a mandate can be used as a us_bank_account payment method instead.
 *
 * @see https://docs.stripe.com/payments/ach-direct-debit/migrating-from-charges?integration-path=payment-intent
 *
 * @since 2.20.4
 */
class MigrateLegacyBankAccount
{
    /**
     * @since 2.20.4
     *
     * @param Donation $donation         The initial donation of the subscription being created.
     * @param Customer $customer         The donor's Stripe customer.
     * @param string   $connectAccountId The connected Stripe account ID.
     *
     * @return void
     * @throws Exception
     */
    public function __invoke(Donation $donation, Customer $customer, string $connectAccountId): void
    {
        $bankAccountId = $customer->default_source ?? null;

        if (!is_string($bankAccountId) || strpos($bankAccountId, 'ba_') !== 0) {
            return;
        }

        if (!empty($customer->invoice_settings->default_payment_method)) {
            return;
        }

        $options = ['stripe_account' => $connectAccountId];

        try {
            $setupIntent = SetupIntent::create([
                'customer' => $customer->id,
                'payment_method' => $bankAccountId,
                'payment_method_types' => ['us_bank_account'],
                'mandate_data' => [
                    'customer_acceptance' => [
                        'type' => 'offline',
                        'accepted_at' => time(),
                    ],
                ],
                'confirm' => true,
            ], $options);

            if ($setupIntent->status !== 'succeeded') {
                PaymentGatewayLog::error('Unable to migrate the legacy bank account of the Stripe customer', [
                    'Stripe Customer ID' => $customer->id,
                    'Bank Account ID' => $bankAccountId,
                    'Setup Intent ID' => $setupIntent->id,
                    'Setup Intent Status' => $setupIntent->status,
                ]);

                return;
            }

            Customer::update($customer->id, [
                'invoice_settings' => ['default_payment_method' => $bankAccountId],
            ], $options);
        } catch (ApiErrorException $exception) {
            PaymentGatewayLog::error('Unable to migrate the legacy bank account of the Stripe customer', [
                'Stripe Customer ID' => $customer->id,
                'Bank Account ID' => $bankAccountId,
                'Error' => $exception->getMessage(),
            ]);

            return;
        }

        DonationNote::create([
            'donationId' => $donation->id,
            'content' => sprintf(
                /* translators: 1: Stripe bank account ID, 2: Stripe customer ID */
                esc_html__(
                    'Stripe bank account %1$s is now the default payment method of Stripe customer %2$s.',
                    'give-recurring'
                ),
                $bankAccountId,
                $customer->id
            ),
        ]);
    }
}
