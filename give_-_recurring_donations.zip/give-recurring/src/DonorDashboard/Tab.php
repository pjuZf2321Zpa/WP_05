<?php

namespace GiveRecurring\DonorDashboard;

use Give\DonorDashboards\Tabs\Contracts\Tab as TabAbstract;
use GiveRecurring\DonorDashboard\Routes\CancelSubscriptionRoute;
use GiveRecurring\DonorDashboard\Routes\ManagePausingSubscriptionRoute;
use GiveRecurring\DonorDashboard\Routes\SubscriptionsRoute;
use GiveRecurring\DonorDashboard\Routes\UpdateSubscriptionRoute;

class Tab extends TabAbstract {

	public static function id() {
		return 'recurring-donations';
	}

	public function routes() {
		return [
			SubscriptionsRoute::class,
			CancelSubscriptionRoute::class,
			UpdateSubscriptionRoute::class,
            ManagePausingSubscriptionRoute::class,
		];
	}
}
