=== Give - Recurring Donations ===
Contributors: givewp
Tags: donations, donation, ecommerce, e-commerce, fundraising, fundraiser, paymill, gateway
Requires at least: 6.9
Tested up to: 7.1
Stable tag: 2.20.4
Requires Give: 4.16.0
Requires PHP: 7.4
License: GPLv3
License URI: https://opensource.org/licenses/GPL-3.0

Create powerful subscription based donations with the GiveWP Recurring Donation Add-on.

== Description ==

This plugin requires the GiveWP core plugin activated to function properly. When activated, it adds the ability to accept recurring (subscription) donations to various payment gateways such as PayPal Standard, Stripe, PayPal Pro, and more.

== Installation ==

= Minimum Requirements =

* MySQL version 5.7 or greater
* Some payment gateways require fsockopen support (for IPN access)

= Automatic installation =

Automatic installation is the easiest option as WordPress handles the file transfers itself and you don't need to leave your web browser. To do an automatic install of Give, log in to your WordPress dashboard, navigate to the Plugins menu and click Add New.

In the search field type "Give" and click Search Plugins. Once you have found the plugin you can view details about it such as the the point release, rating and description. Most importantly of course, you can install it by simply clicking "Install Now".

= Manual installation =

The manual installation method involves downloading our donation plugin and uploading it to your server via your favorite FTP application. The WordPress codex contains [instructions on how to do this here](http://codex.wordpress.org/Managing_Plugins#Manual_Plugin_Installation).

= Updating =

Automatic updates should work like a charm; as always though, ensure you backup your site just in case.

== Changelog ==
= [2.20.4] 2026-11-12 =

* Fix - Prevented recurring Stripe Payment Element donations from failing with a `setup_future_usage` error for donors with a bank account saved by the legacy Stripe ACH gateway, by making that bank account the donor's default Stripe payment method before the subscription is created

= [2.20.3] 2026-10-14 =

* Fix - Corrected Square subscription payment method updates to save the new card to the Square customer who owns the subscription, so the update is not rejected by Square

= [2.20.2] 2026-10-01 =

* Fix - Resolved an issue where duplicating a donation form created a duplicate Recurring Donations goal format setting

= [2.20.1] 2026-09-16 =

* Fix - Resolved a fatal error when GoCardless account-level webhooks referenced subscriptions that do not exist in GiveWP

= [2.20.0] 2026-09-02 =

* Enhancement - Updated Razorpay integration to be more secure by always validating on the server first. This will require updating RazorPay to version 3.0.0+
* Fix - Resolved an issue where Razorpay checkout launched before validating required Billing State field

= [2.19.1] 2026-08-20 =

* Fix - Resolved an issue where recurring donations paid with Square failed when the donor's card or bank required additional verification
* Fix - Resolved an issue where paused or failing Stripe subscriptions were not reactivated when resumed in Stripe

= [2.19.0] 2026-06-24 =

* Feature - Added PayFast webhook events handlers

= [2.18.0] 2026-02-11 =

* Fix - Resolved an issue when using multiple Stripe accounts with recurring donations

= [2.17.0] 2026-01-28 =

* New - Added a new admin email for failing subscription notifications

= [2.16.0] 2025-10-01 =

* New - Added recurring donations compatibility with Paystack!

= [2.15.1] 2025-09-23 =

* Fix - Resolved an issue with recurring donation emails

= [2.15.0] 2025-09-10 =

* Enhancement - Added Stripe webhook compatibility with latest 2025-03-31.basi API
* Fix - Resolved an issue with the add renewal button in the legacy subscription details screen

= [2.14.2] 2025-08-20 =

* Fix - Resolved php 8.3 compatibility

= [2.14.1] 2025-07-23 =

* Fix - Resolved WP 6.8 _load_textdomain_just_in_time notice

= [2.14.0] 2025-07-09 =

* New - Added recurring support and visual form builder compatibility for GoCardless
* New - Added support for syncing subscriptions to Stripe Payment Element
* Enhancement - Ensure offline recurring donations are created in a processing status


= [2.13.0] 2025-06-18 =

* New - Added recurring support for offline donations

= [2.12.2] 2025-05-23 =

* Fix - Resolved an issue with recurring donations and option-based forms on GiveWP 4.3.0+

= [2.12.1] 2025-05-21 =

* Enhancement - Updated Stripe meta data to include GiveWP Subscription ID and donor email

= [2.12.0] 2025-04-01 =

* Enhancement - Updated PayPal subscriptions to activate later in the form processing

= [2.11.2] 2025-03-10 =

* Fix - Updated the Stripe webhook to ensure Stripe subscriptions that are not in GiveWP are ignored

= [2.11.1] 2024-12-17 =

* Fix - Remove non-functional plugin settings link from the plugin list page

= [2.11.0] 2024-12-05 =

* New - Added support for recurring donations with our Blink Payment gateway add-on.

= [2.10.0] 2024-10-23 =

* New - Added compatibility with the Give Stripe Premium Add-on version 2.7.0 to support pausing Stripe subscriptions (recurring donations) within the donor dashboard.
* Fix - Resolved an issue where some emails related to subscription status changes were not being sent.

= [2.9.0] 2024-07-17 =

* New - Added recurring compatibility with Razorpay 2.0.0 for use with the visual form builder.

= [2.8.1] 2024-06-05 =

* Fix - Resolved an issue where the Billing Address field was not saved in Stripe.
* Fix - Resolved an issue where receiving a null response from the Square API could result in a fatal error in recent PHP versions.

= [2.8.0] 2024-05-22 =

* New - Added recurring compatibility with Braintree 2.0.0 for use with option based forms and visual form builder forms.

= [2.7.0] 2024-03-27 =

* New - Added recurring compatibility with Mollie 2.0.0 for use with the visual form builder.
* New - Added recurring compatibility with PayFast 3.0.0 for use with the visual form builder.


= [2.6.0] 2024-01-23 =

* Enhancement - Updated PayPal requests to use PayPal client framework to handle expired merchant access tokens

= [2.5.2] 2023-12-20 =

* Fix - Resolved an issue with PayPal Donations where the recurring frequency was not reflecting the donor selection
* Fix - Updated Authorize.net to validate the donation currency before processing subscriptions

= [2.5.1] 2023-10-13 =

* Fix - Resolved subscription details page from failing when using manual donations

= [2.5.0] 2023-09-13 =

* Feature - Added Stripe Payment Element subscription module
* Feature - Enabled recurring by default in new forms created using the visual form builder
* Feature - Added Test Gateway subscription module
* Feature - Added PayPal Standard Gateway subscription module
* Feature - Used the new SubscriptionSynced command class on the Test Gateway and implement a way to display the synced data returned by it in the U
* Feature - Added PayPal Commerce subscription module
* Fix - Created renewals for Authorize and Square gateways with the proper status

= [2.4.3] 2023-08-07 =

* Fix - Update missing transaction ID for renewals already recorded.

= [2.4.3] 2023-06-13 =

* Fix - Action scheduler events are not shown as failed when they run as expected.

= [2.4.2] 2023-05-23 =

* Refactor - Remove Recurring add-ons tab and page from Settings

= [2.4.1] 2023-05-11 =

* Fix - Donors can cancel subscriptions from the donor dashboard without error.
* Fix - Square plan names are invoiced as the donation form title.
* Fix - When the email access option is disabled, donations made by users who are not logged in will be finished without throwing an error.

= [2.4.0] 2023-04-06 =

* Enhancement - A number of improvements for compatibility with the upcoming Donation Form Builder feature plugin release
* Fix - Cleaned up some PHP notices thrown by the PayPal Donations webhooks
* Fix - In the case that canceling a subscription fails, the subscription status is no longer marked as canceled
* Fix - Improved PHP 8.0+ compatibility

= [2.3.1] 2023-03-22 =

* Fix - Donor's email and order description are now recorded properly with Authorize.Net

= [2.3.0] 2023-03-01 =

* New - Now supports Square recurring donations!
* Fix - Added additional security checks to subscription link generation
* Fix - Fixed a typo, no more confusion

= [2.2.0] 2023-01-26 =

* New - Now supports recurring donations for the Authorize.Net gateway!
* New - Subscriptions admin list table is new and improved like the other list tables!

= [2.1.2] 2022-11-22 =

* Fix - Resolved an issue preventing Stripe + Plaid recurring donations from working.
* Fix - Quarterly intervals now work properly for Stripe recurring donations.

= [2.1.1] 2022-11-17 =

* Fix - Syncing subscription works properly with PayPal Standard, PayPal Pro, and Authorize.net
* Fix - Stripe SEPA donations are no longer immediately set to complete until the webhook is received
* Fix - Updating payment information on a subscription no works properly on the legacy manage subscriptions page

= [2.1.0] 2022-10-31 =

* New - Recurring now supports PayFast!!
* Enhancement - Under the hood improvement to how subscriptions and donations are connected - small but mighty
* Fix - Improved compatibility with upcoming WordPress 6.1 release
* Fix - Exporting upcoming renewals once again works properly
* Fix - Resolved an issue causing an error when using Recurring with the Manual Donations add-on

= [2.0.0] 2022-09-13 =

* Enhancement - Complete rebuild of all gateways to use the new Gateway API
* Fix - Resolves a niche issue for Stripe accounts containing existing users
* Fix - Links for viewing the receipt in the legacy Donor Subscription shortcode now work if the Donor Dashboard is enabled
* Fix - Correct Authorize.net status problem which broken {subscription_frequency} email tag

= [1.15.1] 2022-07-11 =

* Fix - Make sure the anonymous donation option works as expected

= [1.15.0] 2022-01-24 =

* Change - Move internal functions to GiveWP to prepare for future updates. Please update to GiveWP 2.19.0 or higher.
* Fix - Only create subscription in Authorize.net if initial payment is successful.
* Fix - Stripe SEPA initial donations are now properly marked as complete by webhook.

= [1.14.1] 2021-12-23 =

* Fix - Correct major breaking change that's waiting for a GiveWP release

= [1.14.0] 2021-12-23 =

* New - Emails can now be defined on a per-form basis!
* New - Under-the-hood support for the new Gateway API

= [1.13.1] 2021-12-13 =

* Fix - Correct namespacing issue causing a donation error.

= [1.13.0] 2021-12-08 =

* New - When used with GiveWP Authorize.net 1.5.0, the first payment of a Subscription is now immediately processed.

= [1.12.7] 2021-11-18 =

* Change - PayPal IPN verification is always in effect for improve security
* Fix - Rogue HTML no longer shows up in the multi-level donation receipt
* Fix - Donor first name is properly set on renewals
* Fix - When setting a form to admin-defined recurrence a proper default is set that makes things work properly
* Fix - Correct the Authorize.net subscription URL
* Fix - Offline pending donations no longer show up in donor history

= [1.12.6] 2021-08-12 =

* Fix - Stripe subscriptions properly honor donor currency
* Fix - Resolve issue where some donors did not see link to manage subscription from Donor Dashboard
* Fix - Canceling Authorize.net subscriptions from Donor Dashboard cancels on Authorize.net
* Fix - Prevent database updates prompt from displaying on a fresh install

= [1.12.5] 2021-07-21 =

* Fix - Activating on a fresh install no longer prompts a database update
* Fix - Updating subscriptions from Donor Dashboard works properly
* Fix - Plaid subscriptions no longer have issues with existing subscriptions

= [1.12.4] 2021-05-25 =

* Fix - Resolved remaining issue with toggling Failed Subscription email notification

= [1.12.3] 2021-05-20 =

* Change - Abandoned subscriptions are now marked as abandoned instead of canceled
* Fix - Syncing subscriptions with the payment gateway has been fixed
* Fix - Subscriptions that used Apple/Google pay now cancel at Stripe when canceled in GiveWP
* Fix - Updating a Stripe subscription amount now supports Currency Switcher
* Fix - Stripe + Plaid no longer throws errors related to card details being passed

= [1.12.2] 2021-04-12 =

* Fix - Send Failed Subscription email now goes to the correct email (the donor's)
* Fix - Logging can no longer cause exceptions to be thrown, because that's ironic

= [1.12.1] 2021-03-31 =

* Fix - Failed subscription email once again triggers correctly
* Fix - Syncing a subscription works again and logs the results

= [1.12.0] 2021-03-23 =

* New - Added support for the new Donor Profile introduced in GiveWP 2.10.0
* New - Now translated in the French language! Merveilleux!
* Fix - The status for renewals is now properly updated by Stripe

= [1.11.6] 2021-02-09 =

* Fix - PayPal Donation subscriptions now works properly with the Fee Recovery add-on

= [1.11.5] 2021-02-01 =

* Fix - The {amount} subscription email tag correctly reflects the latest donation amount

= [1.11.4] 2021-01-14 =

* Fix - Added back the POT file for translations.

= [1.11.3] 2021-01-13 =

* New - Added a filter to Subscriptions table so plugins can add custom columns
* Fix - WordPress 5.6 compatibility improvements
* Fix - PayPal Standard API fields show up again on GiveWP 2.9.0 and later
* Fix - Resolved JavaScript error preventing admins from bulk selecting subscriptions

= [1.11.2] 2020-12-03 =

* Fix - With multiple Stripe accounts, disconnecting one does not affect others
* Fix - Resolved issue with donor creating a new subscription using the same card

= [1.11.1] 2020-11-10 =

* Fix - Resolved an issue when processing subscriptions via Stripe
* Fix - Donors can once again update their credit card and amount for Stripe subscriptions

= [1.11.0] 2020-10-27 =

* New - Add support for the new PayPal Donations gateway
* Changed - BECS Direct Debit Subscriptions remain pending until completed by StripeBECS Direct Debit Subscriptions now remain pending until completed by Stripe

= [1.10.7] 2020-08-24 =

* Fix - Resolved an issue with Quarterly payments incorrectly billing as Monthly for the PayPal Payflow gateway.

= [1.10.6] 2020-07-16 =

* Fix - Resolved an issue with Authorize.net eCheck subscriptions not properly being created due to incorrect parameters passed for interval and length.

= [1.10.5] 2020-07-16 =

* Fix - Renewal donations were displaying incorrect amounts when using the currency formatting of zero decimals and European style separator of decimal `.` for the thousands separator. The donor was charged the correct amount but the formatting displaying in GiveWP was incorrect and could cause confusion within donation receipts.

= [1.10.4] 2020-07-01 =

* Fix - Removed HTML that was visible within PayPal receipts and Stripe charges when using a multi-level recurring donation form.

= [1.10.3] 2020-06-29 =

* Important - This update requires version GiveWP 2.7+ for compatibility. Please ensure you update to the latest version before updating this add-on.
* New - Added compatibility with GiveWP 2.7's new donation Form Template.
* New - Added support for Multiple Stripe Accounts feature found in GiveWP 2.7 and the Stripe add-on 2.2.6+.
* Fix - Prevent silent failures when updating subscription amounts so donors are more informed on an error if it occurs.
* Fix - Donors are now able to update the amount of their subscriptions by visiting the Recurring Donations page directly.
* Fix - Resolved a bug with Razorpay and using "Admin Defined" recurring donation functionality not properly working.
* Fix - When GiveWP is deactivated this add-on will no longer deactivate itself but rather display a notice prompting the admin that it requires the plugin activated to work.

= [1.10.2] 2020-05-07 =

* Fix - Resolved an issue with Stripe subscriptions that were set to cancel after a certain number of renewals not properly cancelling in Stripe if already set to a completed status in the plugin. We also improved the error handling so that the system will log more description about the subscription if an issue occurs.

= [1.10.1] 2020-04-17 =

* Important - In this version we have patched an important security vulnerability. The fix prevents malicious actors from gaining unauthorized access to donor subscriptions where they would then be able to update subscription amounts or cancel the subscription. Please note: no credit card data or information was ever compromised as we never store card sensitive information to your database. Please update immediately and [contact our support](https://givewp.com/support/) if you have any issues or questions.

= [1.10.0] 2020-03-30 =

* New - Added the Stripe payment gateway SEPA Direct Debit as a compatible gateway option to accept recurring donations through. This is a popular payment method in Europe and only requires a single IBAN payment field to process a one time or recurring donation.
* Fix - Resolved an issue with the "Subscription Payment Failed Email" formatting being incorrect for new installs and also a typo contained within the email's default content.

= [1.9.14] 2020-03-17 =

* Fix - The Authorize.net eCheck renewals were recording under the incorrect Authorize.net payment option. Now when eChecks renew they will display properly as coming from the eCheck integration.

= [1.9.13] 2020-03-04 =

* Fix - Resolved an issue with Currency Switcher in wp-admin where the "Subscription Value" would no appear in the default currency, not the currency the donor gave in.
* Fix - An update card error could occur when a donor attempted to update their subscription credit card after previously giving using Stripe. This has been resolved so now subscriptions are properly updated regardless of giving via Google, Apple, or Credit Card payments.

= [1.9.12] 2020-02-20 =

* Fix - Razorpay had an issue which in some circumstances would create two subscription records incorrectly for donors giving through the gateway. This has since been resolved and now only a singular record will display in GiveWP.

= [1.9.11] 2020-02-07 =

* Fix - Resolved an issue with Razorpay incorrectly clearing a donor's session once donated.

= [1.9.10] 2020-01-22 =

* Fix - Resolved an issue with Stripe ACH (via Plaid) not properly cancelling the subscription when a donor elects to unsubscribe from their recurring donation.

= [1.9.9] 2020-01-15 =

* New - Added a "Blank Slate" for the Subscribers screen when no subscriptions are yet created.
* New - Added additional filters for developers to determine who has access to the Sync tool.
* Fix - Resolved an issue with renewal emails not being sent properly due to an incorrect permission check preventing webhooks from triggering the email.

= [1.9.8] 2019-12-18 =

* Fix - Added checks in place to ensure that when a subscription is cancelled or completed that multiple emails are not sent to the donor or admin incorrectly.
* Fix - If using Stripe Checkout 2.0 then it does not support displaying an image within the checkout so we removed code that caused an issue with their API. The error returning from Stripe was "The Stripe Gateway returned an error while creating the Checkout Session" due to the image.
* Fix - Clicking on the "Resend Receipt" option on a renewal would not send the correct email template. Now it sends the "Renewal Receipt Email" template.

= [1.9.7] 2019-12-05 =

* Fix - There was an issue with manually syncing a Stripe subscription that would bring in failed or on-hold payments as renewals incorrectly. This has been fixed so that only invoices marked as paid are brought into GiveWP as renewals.
* Fix - Resolved an invalid capability argument within the `give_subscriber` WP user role. This resolves issues with membership plugins unable to correctly use the role.
* Improvement - Optimized the subscription count query to reduce the number of database queries when viewing certain screens in WP-Admin.

= [1.9.6] 2019-11-15 =

* New - The Razorpay gateway now supports Recurring Donations!
* Fix - Resolved an error with Authorize.net webhooks deactivating improperly when renewals were processed.

= [1.9.5] 2019-10-28 =

* Fix - The "Cancel Subscription" button for the Stripe Checkout gateway  was not properly displaying for donors and admins who had subscribed using that gateway type.

= [1.9.4] 2019-09-19 =

* New - Added support for Stripe's new Checkout 2.0 for recurring donations. Now you can accept recurring payments that support Strong Customer Authentication, Google and Apple Pay, Credit Cards and more!

= [1.9.3] 2019-08-20 =

* Fix - Resolved a Stripe + Plaid recurring issue when certain donation amounts were passed it resulted in a 500 error due to a missing method name. Now all amounts will be properly passed to the Stripe API.
* Fix - Resolved an issue with Stripe properly cancelling recurring subscriptions for some configurations when the webhook is properly set in Stripe's dashboard.
* Fix - Resolved and added additional unit tests to ensure that releases have more reliable automated testing.

= [1.9.2] 2019-07-30 =

* New -  If a donor updates their subscription amount the note that is displayed for the admin in the subscription profile is improved by recording the time and date that the renewal amount was updated.
* Fix - Corrected an issue with Stripe preventing donors from updating their subscription amount properly. Please update to this version or higher if you're using Stripe with Recurring Donations so donors can successfully cancel or update their subscription amounts.

= [1.9.1] 2019-07-12 =

* Fix - Authorize.net recurring donations were not displaying the subscription giving period correctly. For instance, monthly subscriptions were listed incorrectly as "One Time" and weekly subscriptions are listing an empty string for the period. The actual subscriptions themselves were created correctly, but they appeared incorrectly to admins / donors in Recurring version 1.9.0.

= [1.9.0] 2019-07-11 =

* Important - This update requires Give 2.5.0+ and the latest versions of add-ons to work properly. Please perform a site backup and ensure you have activated your license keys to ensure your add-ons update properly before updating.
* New - Added "Quarterly" as a giving option for admins to collect.
* Optimization - The add-on tables are now only registered when the plugin is activated or updated.
* Tweak - An additional check is now in place to see whether the subscription history page is set or not. If it is set then the donor will be able to update the subscription amount via a link in recurring donation receipt.
* Fix - Resolved an issue with native WP comments incorrectly displaying in subscription comments.
* Fix - The Recurring goal formats for donation forms was not properly displaying past 20 subscriptions.
* Fix - The add-on now properly catches and updates payments that return a declined transaction responses from Authorize.net when the initial transaction is batch processed.
* Fix - The add-on now plugin displays dates properly when using a localized date format.
* Fix - Stripe now processes the "Renewal Failure" webhook event and updates the corresponding subscriptions properly.
* Fix - The "Donation Amount" text would incorrectly display when closing a donation form modal window.
* Fix - The recurring integration for Authorize.net was improperly throwing a fatal error when receiving a webhook for a payment that already existed.

= [1.8.13] 2019-04-30 =

* Fix - Resolved an issue with Stripe payment gateway renewal dates not being properly being set when a new renewal is processed via Stripe's new API. The renewal dates for all Stripe gateway offerings will now reflect properly in your subscriptions dashboard within wp-admin.

= [1.8.12] 2019-04-17 =

* Tweak - Adjusted how the Give Core Subscription API endpoint returns results so that amounts are formatted properly and also includes the donation form title and currency code. This is useful for Zapier and other API integrations.

= [1.8.11] 2019-04-03 =

* New - Added manual subscription sync functionality to the Stripe + Plaid gateway.
* New - Added an additional validation method to ensure that a donor attempting to donate recurringly through a non-recurring supported gateway receives a useful message preventing the subscription attempting and receiving an API error or processing as a one-time donation incorrectly.
* Fix - Resolved an issue with webhooks being properly recorded for the Stripe + Plaid gateway.

= [1.8.10] 2019-03-13 =

* Fix - Stripe fix to ensure existing donors who process a recurring donation with a new card or a new donor who use their card first time within the Stripe Checkout modal don't receive a "No Such Source" error.

= [1.8.9] 2019-03-06 =

* Fix - Added additional checks for repeat donors with single and recurring donations to prevent "No Such Source" errors from displaying and preventing donations from that repeat donor. Please update the Stripe add-on the conjunction with this add-on.

= [1.8.8] 2019-03-01 =

* Fix - Resolved the "Source not found" issue for Stripe Recurring using the Checkout modal option.

= [1.8.7] 2019-02-26 =

* Fix - Ensure that new installs properly set the column types for subscription amounts. Previously if a admin installed recurring 1.8.5 - 1.8.6 the column type would have an incorrect decimal number which resulted in incorrect amounts displayed. This update includes an auto-upgrade check to set the column type correctly.

= [1.8.6] 2019-02-22 =

* Fix - Record renewals properly when process through Plaid + Stripe.
* Fix - Added support for date formats with translated strings in them.
* Fix - Ensure that the original payment source for Stripe subscriptions is not updated incorrectly when donating to multiple campaigns.

= [1.8.5] 2019-02-07 =

* New - Added a new email template tag `{subscriptions_link}` that takes donors to their subscription history.
* Fix - Links to subscription details from receipts now will never expire or require a login. This is to improve the donor experience and not require them to confirm their email or login.

= [1.8.4] 2019-01-31 =

* Fix - Adjusted the column types for recurring amounts to resolve decimal amount formatting when using non-US separators.
* Fix - Removed code preventing Mollie annual (yearly) donations because the gateway now supports it.

= [1.8.3] 2018-12-13 =

* New - There is now a new admin email that can be enabled to notify when renewals are successfully processed.
* New - We also added a new admin email to notify when subscriptions have been cancelled.
* Tweak - Improved the donation listing page to be more performant when Recurring Donations is active.
* Fix - Ensure donation renewal frequencies are translatable.
* Fix - We improved the search within the subscriptions listing page within wp-admin to return more accurate results.

= [1.8.2] 2018-11-08 =

* New - Added support for sorting the subscriptions list columns withing WP-Admin.
* Fix - PayPal Pro (Payflow) issue with syncing donations resolved due to incorrect conditional check.
* Fix - Corrected issue with creating subscription tables on WP Multisite installs when activating network wide.
* Fix - Display proper singular and plural donation counts when only one donation is present in WP-Admin donor details.
* Fix - Stripe was incorrectly cancelling subscriptions when the period ends rather than waiting until the lifetime of the subscription was due.

= [1.8.1] 2018-10-04 =

* New - PayPal gateways are now updated to send the invoice prefix to the gateway so you can more easily differentiate between Give donation transactions and other transactions.
* Tweak - Adjusted how Stripe completes recurring donations using theie new API cancel at plan end functionality.
* Tweak - Removed usage of AJAX to speed up updating the recurring text when changing levels.
* Fix - Resolved an issue where the helpful text next to the final donation amount wasn't displaying properly on page load and changing gateways.
* Fix - Resolved amount formatting and position in recurring text when using a comma for your decimal and thousands separator.
* Fix - Corrected a sessions error occuring when donors would access their subscription history page.
* Fix - Important - if you are using PayPal Payments Pro (Payflow) please ensure in PayPal your IPN endpoint points to "https://mywebsite.com/?give-listener=IPN". This ensures that if you are using PayPal Standard alongside Payflow then the IPN will properly work for both endpoints and your renewals will properly be recorded in Give via IPN.
* Fix - PayPal Payments Pro (Payflow) will not incorrectly sync in non-completed renewals when manually syncing.
* Fix - PayPal Payments Pro (Payflow) will not sync "completed" subscriptions to "expired" when manually syncing.

= [1.8.0] 2018-09-06 =

* New - Donors now have the ability to adjust their subscription amounts.
* New - Added the Authorize.net eCheck recurring payment gateway.
* New - Added a "Subscriptions" section to the donor details screen.
* New - You can now customize Recurring email headings directly within the specific emails found at WP-admin > Settings > Emails.
* New - There is a new subscription notes area where the system and users can add notes similar to payments.
* New - Recurring now has it's own meta table for developers to store subscription related metadata.
* New - Provided a way for users to update the transaction ID of a subscription manually.
* New - When a subscription is created at Authorize.net the donor's email addresses is passed with the payment.
* Fix - Stripe 3D Secure payments are now supported for subscriptions.
* Fix - Ensure that two donations are not created whenever a user gives a recurring donation while using PayPal Pro.

= [1.7.2] 2018-07-30 =

* Important - You must be running Give Core 2.2.0+ in order to use this add-on update. Please update Give Core to the latest version prior to completing this update.
* Fix - There is an upgrade routine to correct renewal donations that are not properly associated with the correct payment level.
* Fix - If for some reason the parent transaction ID from the gateway isn't properly recorded you can now edit it manually.

= [1.7.1] 2018-07-05 =

* Fix - Resolved conflict wirenewal donations for recurring donations are not associated with the correct payment levelth Stripe 2.0.6+ causing the Update Payment Method for recurring to have a JS error.
* Fix - Ensure that the word "Donation" doesn't appear incorrectly after the recurring donation checkbox.

= [1.7.0] 2018-06-28 =

* New - Donors now have the ability to adjust the credit card information (within supported gateways) for their subscriptions so that if a card expires or they would like to use a new card they can update it through your website.
* New - Additional emails have been added so that you can send your donors reminders when their subscription is renewing, completing, and cancelling.
* New - The export donation tool will now export subscription related information such as billing period, times, and frequency.
* New - Now you can modify your donation form goals to only account for subscriptions. For example, "$50 per month raised toward a goal of $500 per month".
* New - Added an indication at the bottom donation amount field that the donation they are going to give is recurring to improve the donor's awareness and experience.
* Tweak - Increased the IPN window time for PayPal Pro to account for delays of renewals being sent from PayPal to your website so they can record properly.
* Fix - Resolved an error with Stripe's webhook preventing renewals from being processed properly. Webhooks now process renewals correctly and payments are added again. No more manual syncing is necessary.
* Fix - The "Renewals" payments list screen is now properly accessable from the payments view in wp-admin.
* Fix - The {date} email tag was returning the date of the original subscription payment within the renewal email notification. The email tag now displays the appropriate renewal date.
* Fix - The email access verification text for the subscriptions page displays different content than the donation history page as to not confuse the donor or redirect them to the donor history page.
* Fix - In wp-admin when drag-and-dropping donation form levels the recurring options could be lost.
* Fix - Removed the "#" prefix from the subscriptions ID within the wp-admin subscription list table to better match Give Core.
* Fix - Improved the way recurring fields are displayed within the donation form admin screens on fresh installs to help admins setup their donation forms.
* Fix - Admin UI improvement for the Subscription Information metabox within the payment details screen. If there were many subscriptions the scrolling was getting thrown off.
* Fix - Recurring now prevents donation forms from sending more than 20 metadata keys to Stripe. The limit is 20 and if it goes over that limit an API error would occurr.

= [1.6.1] 2018-05-10 =

* Fix - Resolved Stripe Error with Form Field Manager long labels or meta keys being rejected by Stripe's API. They are now trimmed to the appropriate length before being sent over.
* Fix - Resolved a PHP notice from displaying when deleting a donation.
* Fix - Updated several SQL queries to be using Give 2.0+ paymentmeta table.

= [1.6] 2018-05-02 =

* New - Added the ability for admins to set recurring frequencies much more flexibly. It's now easy to set quarterly, semi-annually, bi-monthly, and many other giving frequencies.
* New - Added the ability to accept recurring donations through Stripe + Plaid (ACH).
* New - Added the ability to accept recurring donations through Stripe's Google and Apple Pay integration.
* New - Exporting donations in Give Core 2.1 now has support to added columns for recurring donation data such as payment type (one time, renewal, subscription).
* New - Stripe now passes meta data to the gateway when a recurring subscription is created.
* New - Added pagination to the [give_subscriptions] shortcode for donors with many subscriptions.
* Fix - Improved caching strategy for subscription based queries.
* Fix - Adding Multiple Shortcodes on same page should not ask for login multiple times.
* Fix - Display frequency tag correctly for PayPal Pro donations.
* Fix - The {subscriptions_completed} email tag should output correct data for one time donations.

= [1.5.7] 2018-02-20 =

* Tweak - The {subscription_frequency} now outputs "one-time" for non-recurring donations rather than nothing.
* Fix - A PHP notice when making a donation would display if you have WP_DEBUG turned on.

= [1.5.6] 2018-02-19 =

* Fix - Custom amounts can now be either recurring or non-recurring based on your giving preference.
* Fix - The "Subscriptions Page" setting was missing in Give's general settings due a change in the previous version. It has now been restored.
* Fix - PHP warning "invalid subscription_id error" while donating and using the {subscription_frequency} email tag.

= [1.5.5] 2018-02-01 =

* Tweak - Improved internationalization of the donor's choice checkbox language string.
* Fix - Improved SQL query structure for DB upgrade having issues on some database environments.
* Fix - PHP notice when clicking on a custom amount level.

= [1.5.4] 2018-01-12 =

* Fix - The update routine supposed to be release in 1.5.3 wasn't properly merged therefore we need this new release to ensure it goes out to everyone as expected.

= [1.5.3] 2018-01-03 =

* Fix - Resolved issue with upgrade routine not displaying and running correctly for older versions updating to the latest version.
* Fix - The {subscription_frequency} now returns the text "One Time" when it's not a recurring donation rather than nothing at all.

= [1.5.2] 2018-01-03 =

* New - There is now a hidden field that can be used by other plugin authers to determine whether the given donation was recurring or not.
* Fix - Currency formatting was incorrect (too many decimal values would show) for the recurring helper text when choosing a recurring level.

= [1.5.1] 2017-12-26 =

* New - Added bulk actions within the subscriptions listing page in wp-admin.
* Fix - An incorrect number of decimals would display if using admin defined recurring donations with the helper text enabled.
* Fix - The wp-admin conditional field logic was incorrect for set donation forms recurring option fields. This would lead to admin confusion when creating new recurring forms and has been resolved.
* Fix - If using admin choice multi-level donations certain non-recurring levels would be incorrectly interpretted as recurring which could cause donor confusion on the receipt page.
* Fix - Stripe would send the subscription cancelled email twice if the donor cancelled the subscription themselves and when the subscription cancelled in the gateway. This has been resolved so that the email will only send once when the subscription is cancelled.
* Fix - When hovering over a subscription report the income was missing a currency symbol.
* Fix - Minor PHP notices when making a subscription donation if using certain version of Give core.
* Tweak - Various updates for the upcoming Give 2.0 release.
* Tweak - Added page title to the "Recurring Donations" page on the wp-admin page listing screen.

= [1.5] 2017-11-21 =

* New - Now you can provide your donors with the option to select their recurring subscription giving frequency. This provides more flexibility to their giving choices and should help increase recurring subscription conversions.
* Fix - Renewals would show incorrectly when filtering on the donations listing page.
* Fix - Multi-level recurring forms with dropdown were not updating the recurring amount description correctly.
* Fix - Conflict with manual donations and 1.4.x of recurring.

= [1.4.2] 2017-11-21 =

* Fix - Resolved issue with PHP 5.2 - 5.4 causing PHP error when the plugin attempts to load.

= [1.4.1] 2017-11-20 =

* Fix - Resolved hook priority issue preventing "Sync" and "Cancel" subscription options from displaying properly in wp-admin.

= [1.4] 2017-11-20 =

* New - You now have the ability to add renewal payments manually to subscriptions within the subscription details screen in wp-admin.
* New - Subscription profile IDs are now linked to the gateway subscription profile for easy access.
* New - Added foundation of PHP unit tests for easier bug detection, increased code coverage, and quality.
* New - Added a filter for PayPal Payflow IPN window timeframe called "give_recurring_payflow_ipn_window_timeframe" and increased the amount of time threshold to better match recurring payments.
* New - Added explanatory text for recurring admin choice forms that appears below levels to make final donation more clear to the donor.
* New - Recurring now adds an API endpoint to the Give core API for developers to work with.
* New - Admins now have the ability to search through the subscription list as well as filter by date and donation form.
* New - Moved the "Subscriptions Page" settings field under Settings > General it is generated by default for new installs. If you haven't set it yet, it's a good idea to set it.
* Tweak - Adjusted code to use GIVE_RECURRING_* constants so developers can flexibly override them for various requirements. Thanks @JJJ
* Tweak - Removed usage of Give core deprecated hooks causing PHP notices when debug is enabled.
* Tweak - Donation History page now has a "recurring" indicator for donors to more easily which donations are recurring compared to non-recurring.
* Tweak - Notices that display are now standardized to use the Give core notices class.
* Tweak - Changed the default option for "Donor's Choice" checkbox to be unchecked by default.
* Tweak - Updated the output for when a donation form is recurring admin defined set donation so that the "Donate Now" button always appears below the main.
* Tweak - Authorize.net now uses webhooks for the main pingback mechanism rather than the unreliable Silent Post URL which is now the fallback.
* Tweak - The Renewal reports  graph now labels data as "Renewals" rather than "Subscriptions".
* Tweak - Improved the settings page layout to be better organized.
* Fix - The dashboard stats widget and other reports not properly count renewal donations amounts and number of donations properly.
* Fix - PayPal Pro Gateway (NVP API) - Request body bug with sending state in place of country causing API issues. Thanks @wesdunn
* Fix - Added security with additional nonces throughout plugin.
* Fix - When a custom recurring amount is donated for a multi-level form, the plugin didn't properly show the "custom" as the label in Donations (admin dashboard), instead it showed the label of the first level of the multi level donation form.
* Fix - A donation form's recurring options were not correctly show/hiding sub-fields on the edit donation form screen within wp-admin.
* Fix - If special characters were sent to PayPal Pro in the PROFILENAME field an error would return. Now the field is sanitized so no special characters should ever be sent to prevent this error.
* Fix - Removed duplicate Give API fields appearing under the user profile.
* Fix - Preventing undimissible JS alert when setting a recurring donations times to 1.
* Fix - Recurring specific email tags were not working in the core donation receipt email.
* Fix - When a renewal donation is added, it is now being properly reflected in the list at Donations > Donors > Total donated in both the number of donations or the total amount donated columns.
* Fix - Renewal donations are now properly displayed when filtering in wp-admin within the donations listing screen.
* Fix - Pagination reliability is now fixed for when you page through the subscriptions list screen under Donations > Subscriptions in wp-admin.
* Fix - The Renewal Donations report now matches the Income report found in Give 1.8+.
* Fix - Issue where some donors couldn't cancel their subscriptions due to being a guest on the site.
* Fix - If you disabled guest donations on a donor's choice recurring form with email access disabled, the registration/login fields would be still toggle, but would be incorrectly required with recurring unchecked.
* Fix - Authorize.net - a renewal would incorreclty be created a day after the first donation for some subscriptions due to a delay with the Silent Post URL.
* Fix - The plugin now will delete all data if the Give core settings is set to delete all data on uninstall.
* Fix - The give_is_form_recurring() would return false positives incorrectly.

= 1.3.1 =
* New - Recurring gateways that add API keys now use Give core's api_key field type to help prevent viewing of API key content.
* Fix - Prevent errors when attempting to activate plugin with an older unsupported Give version or Give is not active at all.
* Various bug fixes and code improvements.

= 1.3 =
* New - Introduced the Subscription Synchronizer tool. Subscription can get out of sync with the gateway for a variety of data. This tool allows you to connect to the specific subscription's gateway and sync the transactions and subscription information so that the data is no longer out of sync.
* New - A new subscriptions column now appears under WP-Admin > Donations > Donors so you can quickly see who is a subscriber and how many subscriptions they have. You can also click on the it to see that donor's specific subscriptions.
* New - is_subscription_valid() method added to Give_Recurring_Gateway().
* Fix - Authorize.net now properly processes the MD5 Hash option via Silent Post URL. This means subscription renewals should come in fine now from the Authorize.net API with this option enabled.
* Fix - PayPal Payments Pro now properly process Instant Payment Notifications from PayPal to accept renewals. Use the synchronizer tool if your current subscriptions are out of date.
* Fix - Renewal emails now have a proper heading for the receipt that is emailed.
* Fix - Don't allow recurring checkboxes to bump to two lines for certain themes like TwentySeventeen.
* Various bug fixes and minor text updates.

= 1.2.3 =
* New - Added functionality to require that Give core be active in order to use the plugin. #301
* Fix - Logs filling with "Error Processing IPN Transaction" incorrectly for non-recurring payments. #293
* Fix - Refactored JS for how the recurring checkbox toggle displays required fields. - https://github.com/impress-org/give-recurring-donations/pull/303
* Fix - Authorize.net Subscription names need to be limited to 50 characters. #298

= 1.2.2 =
* New - Pass the billing address information to Authorize.net about the donor when creating the subscription if present. #271
* New - Better error reporting for Authorize.net. #271
* New - Method to confirm whether the Payflow recurring feature is enabled at the gateway to better ensure the subscription is created successfully. #288
* New - Subscription status indicator icon added to Donations > Subscriptions > Subscription Details page. #132
* Fix - Intermittent issue with the donor's subscription cancel option displaying properly due to an issue with the PayPal Payflow gateway cancel logic. #260
* Fix - Resolved translation strings without textdomains or incorrect text domains for better translations. #275

= 1.2.1 =
* Fix - License activation notice would improperly display even though the license was activated when the admin viewed the Recurring Donations settings tab. #265

= 1.2 =
* New - Support for PayPal Payments Pro (Payflow). #256
* New - Support for the PayPal REST API. #224
* New - The ability to filter subscriptions by status under Donations > Subscriptions
* New - The ability to edit a number of subscription detail fields including profile ID, expiration date, and subscription status
* New - Improved UI for [give_subscriptions] shortcode and also customizable attributes. #143
* New - Filter "give_recurring_multilevel_text_separator" to control multi-level separator between level text and recurring duration text. #142
* New - Added span wrapped tag to recurring language in multi-level buttons for easier styling. #142
* New - Allow the admin to delete or cancel renewal in the subscription details. #204
* New - New form for adding manual renewal payments added to individual subscription details admin page. #205
* New - Stripe now supports refunding and cancelling subscriptions from the donation details screen. #239
* Tweak - Consolidate subscriptions listing column & improved UI in WP-admin under Donations > Subscriptions. #251
* Tweak - Subscription donations are now referred to as "Renewals" for better clarity and easier understanding of the status. #215
* Fix - When Give is opening the donation form in a modal, the "Make this donation recurring" Donor's choice checkbox appears before the button. #253
* Fix - Properly show/hide the "Recurring Opt-in Default" field in the admin when toggling recurring options
* Fix - Incorrect false negative in conditional check for whether a donation form is recurring is_recurring() method
* Fix - Issue with checking if a Transaction payment is a Subscription parent payment which was causing the recurring label to be incorrectly output on the parent payments' transaction. #214
* Fix - Reports filter field not displayed on the Recurring reports sections. #211
* Fix - Reports tooltips not properly formatted. #217
* Fix - Donor details renewal stat incorrect. #245
* Fix - Renewal date incorrectly calculating for certain donation form configurations. #201
* Fix - Multiple Donors Choice Recurring Forms cause first Checkbox to always be selected. #254
* Fix - Require the last name field for Authorize.net - the gateway requires that the last name be passed when creating subscriptions. #262

= 1.1.1 =
* Fix - PHP fatal error for some hosting configurations "Can't use function return value in write context". #192
* New - New link to plugin settings page with new base name constant. #190

= 1.1 =
* New - Don't require a login or registration for subscription donations when email access is enabled. #169
* New - Show a login form for [give_subscriptions] shortcode for non-logged-in users. #163
* New - Donation form option for admins to set whether subscription checkbox is checked or unchecked by default. #162
* Tweak - Provide Statement Descriptor when Creating Stripe Plans. #164
* Tweak - Don't register post status within Recurring; it's already in Core. #174
* UX - Added scrolling capability to subscription parent payments' metabox because it was getting too long for ongoing subscriptions. #130
* Fix - PHP Fatal error when Stripe event is not returned. #176
* Fix - PayPal Pro Gateway message issue "Something has gone wrong, please try again" response . #177
* Fix - Blank notice appears when updating / saving settings in Give. #171

= 1.0.1 =
* Fix - Security fix added to prevent non-subscribers from seeing others subscriptions within the [give_subscriptions] shortcode.

= 1.0 =
* Initial plugin release. Yippee!
