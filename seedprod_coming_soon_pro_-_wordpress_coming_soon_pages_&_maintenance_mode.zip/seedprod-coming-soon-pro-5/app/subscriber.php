<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}



/**
 * Frontend Subscriber Functions
 *
 * Handles email subscription form submissions from visitor-facing pages
 *
 * @package SeedProd
 */

/**
 * Frontend Subscribe Callback Handler
 *
 * Processes email subscription form submissions from visitor-facing pages
 * (coming soon pages, landing pages, etc.)
 *
 * This function is registered via AJAX hooks in routes.php:
 * - wp_ajax_seedprod_pro_subscribe_callback
 * - wp_ajax_nopriv_seedprod_pro_subscribe_callback
 */
function seedprod_pro_subscribe_callback() {
	// Honeypot: the optin form never sends these fields. Respond with success
	// so bots get no feedback, but save nothing.
	foreach ( array( 'message', 'comment', 'website' ) as $seedprod_honeypot ) {
		if ( ! empty( $_POST[ $seedprod_honeypot ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			wp_send_json_success();
		}
	}

	// Per-IP rate limit. Keyed on REMOTE_ADDR, not forwarded headers, so it
	// cannot be reset by spoofing X-Forwarded-For.
	$remote_addr = ! empty( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	$rate_limit  = (int) apply_filters( 'seedprod_subscribe_rate_limit', 10 );
	$rate_key    = 'seedprod_sub_rl_' . md5( $remote_addr );
	$rate_count  = (int) get_transient( $rate_key );
	if ( $rate_count >= $rate_limit ) {
		wp_send_json_success();
	}
	set_transient( $rate_key, $rate_count + 1, 10 * MINUTE_IN_SECONDS );

	// get request data.

	$email = '';
	if ( ! empty( $_POST['email'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$email = sanitize_email( wp_unslash( $_POST['email'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
	}

	if ( empty( $email ) ) {
		wp_send_json_error();
	}

	$page_uuid = '';
	if ( ! empty( $_POST['page_uuid'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$page_uuid = sanitize_text_field( wp_unslash( $_POST['page_uuid'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
	}

	$page_id = '';
	if ( ! empty( $_POST['page_id'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$page_id = absint( $_POST['page_id'] ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
	}

	// When the page has reCAPTCHA enabled the browser submits a
	// g-recaptcha-response token with the form, so a missing token means the
	// rendered form was bypassed. Only enforced for standalone page types:
	// theme templates are not enforced here yet, and requests whose page_id
	// cannot be resolved must keep working (e.g. imported pages whose saved
	// markup still carries the source site's IDs).
	$seedprod_needs_recaptcha = false;
	if ( ! empty( $page_id ) ) {
		$seedprod_template_type = get_post_meta( $page_id, '_seedprod_page_template_type', true );
		if ( in_array( $seedprod_template_type, array( 'cs', 'mm', 'lp', 'p404', 'loginp' ), true ) ) {
			$seedprod_page            = get_post( $page_id );
			$seedprod_page_settings   = ! empty( $seedprod_page->post_content_filtered ) ? json_decode( $seedprod_page->post_content_filtered ) : null;
			$seedprod_needs_recaptcha = ! empty( $seedprod_page_settings->enable_recaptcha );
		}
	}
	if ( $seedprod_needs_recaptcha && empty( $_POST['g-recaptcha-response'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
		wp_send_json_success();
	}

	// The opt-in receipt from api.seedprod.com shows that the API accepted this
	// subscriber and whether it verified a reCAPTCHA token.
	if ( apply_filters( 'seedprod_optin_require_receipt', false ) ) {
		$seedprod_receipt_rc = seedprod_pro_optin_receipt_rc();
		if ( false === $seedprod_receipt_rc || ( 1 !== $seedprod_receipt_rc && ( $seedprod_needs_recaptcha || seedprod_pro_optin_uuid_has_recaptcha( $page_uuid ) ) ) ) {
			wp_send_json_success();
		}
	}

	$name = '';
	if ( ! empty( $_REQUEST['name'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$name = sanitize_text_field( wp_unslash( $_REQUEST['name'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	}

	$fname = '';
	$lname = '';

	if ( ! empty( $name ) ) {
		require_once SEEDPROD_PRO_PLUGIN_PATH . 'app/includes/nameparse.php';
		$name  = seedprod_pro_parse_name( $name );
		$fname = $name['first'];
		$lname = $name['last'];
	}

	$optin_confirmation = 0;
	if ( ! empty( $_REQUEST['optin_confirmation'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$optin_confirmation = 1;
	}

	// Record user in DB if they do not exist.
	global $wpdb;
	$tablename     = $wpdb->prefix . 'csp3_subscribers';
	$sql           = "SELECT * FROM $tablename WHERE email = %s AND page_uuid = %s";
	$safe_sql      = $wpdb->prepare( $sql, $email, $page_uuid ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
	$select_result = $wpdb->get_row( $safe_sql ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared

	if ( empty( $select_result->email ) ) {
		$values        = array(
			'email'         => $email,
			'page_id'       => $page_id,
			'page_uuid'     => $page_uuid,
			'ip'            => seedprod_pro_get_ip(),
			'fname'         => $fname,
			'lname'         => $lname,
			'optin_confirm' => $optin_confirmation,
		);
		$format_values = array(
			'%s',
			'%d',
			'%s',
			'%s',
			'%s',
			'%s',
			'%d',
		);
		$insert_result = $wpdb->insert(
			$tablename,
			$values,
			$format_values
		);
		// run a do_action to allow other to hook into.
		do_action( 'seedprod_add_subscriber', $values );
	}

	wp_send_json_success();
}

/**
 * Verify the opt-in receipt that api.seedprod.com signs for an accepted subscriber.
 *
 * @since 6.20.12
 *
 * @return integer|false 1 when the API verified a reCAPTCHA token, 0 when it did not, false for a missing or invalid receipt.
 */
function seedprod_pro_optin_receipt_rc() {
	// phpcs:disable WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.InputNotValidated -- Public form; the loop checks each field and the signature covers these exact bytes.
	foreach ( array( 'seedprod_receipt', 'seedprod_receipt_rc', 'page_uuid', 'email' ) as $seedprod_field ) {
		if ( ! isset( $_POST[ $seedprod_field ] ) || ! is_string( $_POST[ $seedprod_field ] ) ) {
			return false;
		}
	}
	$rc        = wp_unslash( $_POST['seedprod_receipt_rc'] );
	$page_uuid = wp_unslash( $_POST['page_uuid'] );
	$email     = wp_unslash( $_POST['email'] );
	$signature = base64_decode( strtr( wp_unslash( $_POST['seedprod_receipt'] ), '-_', '+/' ), true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- Signature encoding.
	// phpcs:enable

	$public_key = defined( 'SEEDPROD_OPTIN_PUBLIC_KEY' ) ? SEEDPROD_OPTIN_PUBLIC_KEY : 'BFWHtY0PEk2zpEPuK6kcEuBk7Hp2/+CVkWnzIE6odaI=';
	$public_key = base64_decode( $public_key, true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- Key encoding.
	if ( ( '0' !== $rc && '1' !== $rc ) || ! function_exists( 'sodium_crypto_sign_verify_detached' ) || false === $public_key || 32 !== strlen( $public_key ) || false === $signature || 64 !== strlen( $signature ) ) {
		return false;
	}

	try {
		$valid = sodium_crypto_sign_verify_detached( $signature, "seedprod-optin\n{$page_uuid}\n{$email}\n{$rc}", $public_key );
	} catch ( Exception $e ) {
		$valid = false;
	}

	return $valid ? (int) $rc : false;
}

/**
 * Whether a SeedProd page or template with this page UUID has reCAPTCHA on.
 *
 * @since 6.20.12
 *
 * @param string $page_uuid The page UUID that the form sent.
 * @return boolean
 */
function seedprod_pro_optin_uuid_has_recaptcha( $page_uuid ) {
	if ( '' === $page_uuid ) {
		return false;
	}

	global $wpdb;
	$post_ids = $wpdb->get_col( $wpdb->prepare( "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_seedprod_page_uuid' AND meta_value = %s LIMIT 20", $page_uuid ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- No core API looks up a post by meta value without a full WP_Query.
	foreach ( $post_ids as $post_id ) {
		$post     = get_post( $post_id );
		if ( ! $post || 'trash' === $post->post_status ) {
			continue;
		}
		$settings = ! empty( $post->post_content_filtered ) ? json_decode( $post->post_content_filtered ) : null;
		if ( ! isset( $settings->enable_recaptcha ) ) {
			continue;
		}
		// Match the renderers: standalone pages load the reCAPTCHA script for any
		// truthy value, theme templates only for a literal true.
		$standalone = in_array( get_post_meta( $post_id, '_seedprod_page_template_type', true ), array( 'cs', 'mm', 'lp', 'p404', 'loginp' ), true );
		if ( $standalone ? ! empty( $settings->enable_recaptcha ) : true === $settings->enable_recaptcha ) {
			return true;
		}
	}

	return false;
}


