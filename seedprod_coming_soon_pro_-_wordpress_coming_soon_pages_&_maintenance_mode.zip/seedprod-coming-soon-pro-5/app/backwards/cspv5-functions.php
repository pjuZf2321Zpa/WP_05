<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.Security.NonceVerification, WordPress.Security.ValidatedSanitizedInput, WordPress.WP.I18n.TextDomainMismatch, WordPress.NamingConventions.PrefixAllGlobals, WordPress.DB, WordPress.WP.AlternativeFunctions -- Legacy backward compatibility code for CSPv5.

	//Subscribe Callback
	add_action( 'wp_ajax_seed_cspv5_legacy_subscribe_callback', 'seed_cspv5_legacy_subscribe_callback' );
	add_action( 'wp_ajax_nopriv_seed_cspv5_legacy_subscribe_callback', 'seed_cspv5_legacy_subscribe_callback' );

	//ContactForm Callback
	add_action( 'wp_ajax_seed_cspv5_legacy_contactform_callback', 'seed_cspv5_legacy_contactform_callback' );
	add_action( 'wp_ajax_nopriv_seed_cspv5_legacy_contactform_callback', 'seed_cspv5_legacy_contactform_callback' );


function seedprod_pro_cspv5_remove_ngg_print_scripts() {
	if ( class_exists( 'C_Photocrati_Resource_Manager' ) ) {
		remove_all_actions( 'wp_print_footer_scripts', 1 );
	}
}


		/**
	 * Display the landing page
	 */
function seedprod_pro_cspv5_render_landing_page( $page_id ) {
	// Prevetn Plugins from caching
	// Disable caching plugins. This should take care of:
	//   - W3 Total Cache
	//   - WP Super Cache
	//   - ZenCache (Previously QuickCache)
	if ( ! defined( 'DONOTCACHEPAGE' ) ) {
		define( 'DONOTCACHEPAGE', true );
	}

	if ( ! defined( 'DONOTCDN' ) ) {
		define( 'DONOTCDN', true );
	}

	if ( ! defined( 'DONOTCACHEDB' ) ) {
		define( 'DONOTCACHEDB', true );
	}

	if ( ! defined( 'DONOTMINIFY' ) ) {
		define( 'DONOTMINIFY', true );
	}

	if ( ! defined( 'DONOTCACHEOBJECT' ) ) {
		define( 'DONOTCACHEOBJECT', true );
	}

	global  $seedprod_legacy_lp_path;

	$page_id = $seedprod_legacy_lp_path;

	// Get Page
	global $wpdb;
	$tablename = $wpdb->prefix . 'cspv5_pages';
	$sql       = "SELECT * FROM $tablename WHERE id= %d and deactivate = 0";
	$safe_sql  = $wpdb->prepare( $sql, $page_id );
	$page      = $wpdb->get_row( $safe_sql );
	if ( empty( $page ) ) {
		return false;
	}

	// Check for base64 encoding of settings
	if ( base64_encode( base64_decode( $page->settings, true ) ) === $page->settings ) {
		$settings = unserialize( base64_decode( $page->settings ) );
	} else {
		$settings = unserialize( $page->settings );
	}

	// Check  for languages

		$lang_settings_name = 'seed_cspv5_' . $page_id . '_language';
		$lang_settings      = get_option( $lang_settings_name );
	if ( ! empty( $lang_settings ) ) {
		$lang_settings     = maybe_unserialize( $lang_settings );
		$lang_settings_all = $lang_settings;
		$langs             = array( '0' => $lang_settings['default_lang']['label'] );
		foreach ( $lang_settings as $k => $v ) {
			if ( substr( $k, 0, 5 ) === 'lang_' ) {
				$langs[ $k ] = $v['label'];
			}
		}
	}

		$lang_id = '';
	if ( ! empty( $_GET['lang'] ) ) {
		$lang_id = $_GET['lang'];
	}

		// if(isset($_GET['lang'])){
		//     var_dump($_GET);
		//     die();
		// }

		// Get lang settings
		$lang_settings_name = 'seed_cspv5_' . $page_id . '_language_' . $lang_id;
		$lang_settings      = get_option( $lang_settings_name );
	if ( ! empty( $lang_settings ) ) {
		$lang_settings = maybe_unserialize( $lang_settings );
	}

	if ( ! empty( $lang_id ) && ! empty( $lang_settings ) ) {
		$settings = array_merge( $settings, $lang_settings );
	}

		//If Referrer record it
	if ( isset( $_GET['ref'] ) ) {
		$id = intval( $_GET['ref'], 36 ) - 1000;

		global $wpdb;
		$tablename     = $wpdb->prefix . 'csp3_subscribers';
		$sql           = "UPDATE $tablename SET clicks = clicks + 1 WHERE id = %d";
		$safe_sql      = $wpdb->prepare( $sql, $id );
		$update_result = $wpdb->get_var( $safe_sql );
	}

		// check if 3rd party plugins is enabled
	if ( ! empty( $settings['enable_wp_head_footer'] ) ) {
		add_action( 'wp_enqueue_scripts', 'seed_cspv5_legacy_deregister_frontend_theme_styles', PHP_INT_MAX );
	}

		header( 'HTTP/1.1 200 OK' );
		header( 'Cache-Control: max-age=0, private' );

		// render
		$upload_dir = wp_upload_dir();
	if ( is_multisite() ) {
		$path = $upload_dir['baseurl'] . '/seedprod/' . get_current_blog_id() . '/template-' . $page_id . '/index.php';
	} else {
		$path = $upload_dir['basedir'] . '/seedprod/template-' . $page_id . '/index.php';
	}

	if ( ! empty( $page->html ) ) {
		echo seedprod_pro_strip_vue_render_helpers( $page->html );
	} else {

		if ( file_exists( $path ) ) {
			require_once $path;
		} else {
			require_once SEEDPROD_PRO_PLUGIN_PATH . 'app/backwards/template/index.php';
		}
	}

		exit();
}

	/**
	 * Display the coming soon page
	 */


function seedprod_pro_cspv5_render_comingsoon_page() {

	//var_dump('coming soon');

	// Setting
	$plugin_settings = seed_cspv5_legacy_get_settings();
	extract( $plugin_settings );

	// Ensure extracted variables are not null for PHP 8+ compatibility
	if ( ! isset( $redirect_url ) ) {
		$redirect_url = '';
	}

	// Page Info
	$page_id = 0;
	if ( isset( $_GET['seed_cspv5_preview'] ) ) {
		$page_id = $_GET['seed_cspv5_preview'];
	} else {
		//Get Coming Soon Page Id
		$page_id = get_option( 'seed_cspv5_coming_soon_page_id' );
	}

	// Get Page
	global $wpdb;
	$tablename = $wpdb->prefix . 'cspv5_pages';
	$sql       = "SELECT * FROM $tablename WHERE id= %d";
	$safe_sql  = $wpdb->prepare( $sql, $page_id );
	$page      = $wpdb->get_row( $safe_sql );

	// Check for base64 encoding of settings
	if ( base64_encode( base64_decode( $page->settings, true ) ) === $page->settings ) {
		$settings = unserialize( base64_decode( $page->settings ) );
	} else {
		$settings = unserialize( $page->settings );
	}

	// Check  for languages

	$lang_settings_name = 'seed_cspv5_' . $page_id . '_language';
	$lang_settings      = get_option( $lang_settings_name );
	if ( ! empty( $lang_settings ) ) {
		$lang_settings     = maybe_unserialize( $lang_settings );
		$lang_settings_all = $lang_settings;
		$langs             = array( '0' => $lang_settings['default_lang']['label'] );
		foreach ( $lang_settings as $k => $v ) {
			if ( substr( $k, 0, 5 ) === 'lang_' ) {
				$langs[ $k ] = $v['label'];
			}
		}
	}

	$lang_id = '';
	if ( ! empty( $_GET['lang'] ) ) {
		$lang_id = $_GET['lang'];
	}

	// if(isset($_GET['lang'])){
	//     var_dump($_GET);
	//     die();
	// }

	// Get lang settings
	$lang_settings_name = 'seed_cspv5_' . $page_id . '_language_' . $lang_id;
	$lang_settings      = get_option( $lang_settings_name );
	if ( ! empty( $lang_settings ) ) {
		$lang_settings = maybe_unserialize( $lang_settings );
	}

	if ( ! empty( $lang_id ) && ! empty( $lang_settings ) ) {
		$settings = array_merge( $settings, $lang_settings );
	}

	// if(!isset($status)){
	//     $err =  new WP_Error('error', __("Please enter your settings.", 'seedprod-pro'));
	//     echo $err->get_error_message();
	//     exit();
	// }

	// Check if Preview
	$is_preview = false;
	if ( ( isset( $_GET['seed_cspv5_preview'] ) ) ) {
		//show_admin_bar( false );
		$is_preview = true;
	}

	// Die if preview and redirect mode
	if ( $status == '3' && $is_preview == true ) {
		$status = '1';
	}

	// Countdown Launch
	if ( $is_preview == false ) {
		if ( ! empty( $settings['countdown_date'] ) && ! empty( $settings['enable_countdown'] ) && ! empty( $settings['countdown_launch'] ) ) {
			$date      = new DateTime( $settings['countdown_date'], new DateTimeZone( $settings['countdown_timezone'] ) );
			$timestamp = $date->format( 'U' );
			// var_dump($timestamp);
			// var_dump(time());

			// Launch this biatch
			if ( $timestamp <= time() ) {
				// Email the admin the site has been launched
				$message = __( sprintf( '%s has been launched.', home_url() ), 'seedprod' );
				$result  = wp_mail( get_option( 'admin_email' ), __( sprintf( '%s has been launched.', home_url() ), 'seedprod' ), $message );

				$o = get_option( 'seed_cspv5_settings_content' );
				//var_dump($o);
				$o['status'] = 0;
				update_option( 'seed_cspv5_settings_content', $o );
				return false;
			}
		}
	}

	//If Referrer record it
	if ( isset( $_GET['ref'] ) ) {
		$id = intval( $_GET['ref'], 36 ) - 1000;

		global $wpdb;
		$tablename     = $wpdb->prefix . 'csp3_subscribers';
		$sql           = "UPDATE $tablename SET clicks = clicks + 1 WHERE id = %d";
		$safe_sql      = $wpdb->prepare( $sql, $id );
		$update_result = $wpdb->get_var( $safe_sql );
	}

	// Exit if feed and feedburner is enabled.
	if ( is_feed() && ! empty( $emaillist ) && $emaillist == 'feedburner' ) {
		return false;
	}

	//Bypass code
	if ( empty( $_GET['bypass'] ) ) {
		$_GET['bypass'] = false;
	}

	if ( empty( $alt_bypass ) ) {
		$alt_bypass = false;
	}

	if ( is_multisite() || $alt_bypass ) {

		// Multisite Clientview
		if ( empty( $_GET['bypass'] ) ) {
			$_GET['bypass'] = false;
		}

		if ( $is_preview == false ) {
			//Check for Client View
			if ( isset( $_COOKIE['wp-client-view'] ) && ( ( strtolower( basename( $_SERVER['REQUEST_URI'] ) ) == trim( strtolower( $client_view_url ) ) ) || ( strtolower( $_GET['bypass'] ) == trim( strtolower( $client_view_url ) ) ) ) && ! empty( $client_view_url ) ) {
				if ( ! empty( $_REQUEST['return'] ) ) {
					nocache_headers();
					header( 'Cache-Control: max-age=0, private' );
					wp_safe_redirect( wp_validate_redirect( is_string( $_REQUEST['return'] ) ? wp_unslash( $_REQUEST['return'] ) : '', home_url() ) );
					exit;
				} else {
					nocache_headers();
					header( 'Cache-Control: max-age=0, private' );
					header( 'Location: ' . home_url() . '?' . rand() );
					exit;
				}
			}

			// Don't show Coming Soon Page if client View is active
			$client_view_hash = md5( $client_view_url . get_current_blog_id() );
			if ( isset( $_COOKIE['wp-client-view'] ) && $_COOKIE['wp-client-view'] == $client_view_hash && ! empty( $client_view_url ) ) {
				nocache_headers();
				header( 'Cache-Control: max-age=0, private' );
				return false;
			} else {
				nocache_headers();
				header( 'Cache-Control: max-age=0, private' );
				setcookie(
				'wp-client-view',
				'',
				array(
					'expires'  => time() - 3600,
					'path'     => COOKIEPATH,
					'domain'   => COOKIE_DOMAIN,
					'secure'   => is_ssl(),
					'httponly' => true,
					'samesite' => 'Lax',
				)
			);
			}

			// If Client view is not empty and we are on the client view url set cookie.
			if ( ! empty( $client_view_url ) ) {
				if ( empty( $_GET['bypass'] ) ) {
					$_GET['bypass'] = '';
				}

				if ( ( strtolower( basename( $_SERVER['REQUEST_URI'] ) ) == trim( strtolower( $client_view_url ) ) ) || ( strtolower( $_GET['bypass'] ) == trim( strtolower( $client_view_url ) ) ) ) {
					if ( ! empty( $bypass_expires ) ) {
						$exipres_in = time() + ( 3600 * $bypass_expires );
					} else {
						$exipres_in = time() + 172800;
					}

					setcookie(
						'wp-client-view',
						$client_view_hash,
						array(
							'expires'  => $exipres_in,
							'path'     => COOKIEPATH,
							'domain'   => COOKIE_DOMAIN,
							'secure'   => is_ssl(),
							'httponly' => true,
							'samesite' => 'Lax',
						)
					);

					if ( ! empty( $_REQUEST['return'] ) ) {
						nocache_headers();
						header( 'Cache-Control: max-age=0, private' );
						wp_safe_redirect( wp_validate_redirect( is_string( $_REQUEST['return'] ) ? wp_unslash( $_REQUEST['return'] ) : '', home_url() ) );
						exit;
					} else {
						nocache_headers();
						header( 'Cache-Control: max-age=0, private' );
						header( 'Location: ' . home_url() . '?' . rand() );
						exit;
					}
				}
			}
		}
	} else {

		// ClientView
		if ( ! empty( $client_view_url ) ) {
			if ( empty( $_GET['bypass'] ) ) {
				$_GET['bypass'] = '';
			}

			// If client view url is passed in log user in
			if ( ( strtolower( basename( $_SERVER['REQUEST_URI'] ) ) == trim( strtolower( $client_view_url ) ) ) || ( strtolower( $_GET['bypass'] ) == trim( strtolower( $client_view_url ) ) ) ) {
				if ( ! username_exists( 'seed_cspv5_clientview_' . $client_view_url ) ) {
					$user_id = wp_create_user( 'seed_cspv5_clientview_' . $client_view_url, wp_generate_password() );
					$user    = new WP_User( $user_id );
					$user->set_role( 'none' );
				}

				if ( ! empty( $bypass_expires ) ) {
					global $seed_cspv5_bypass_expires;
					$seed_cspv5_bypass_expires = ( 3600 * $bypass_expires );
				}

				$client_view_hash = md5( $client_view_url . get_current_blog_id() );
				setcookie(
					'wp-client-view',
					$client_view_hash,
					array(
						'expires'  => 0,
						'path'     => COOKIEPATH,
						'domain'   => COOKIE_DOMAIN,
						'secure'   => is_ssl(),
						'httponly' => true,
						'samesite' => 'Lax',
					)
				);

				// Log user in auto
				$username = 'seed_cspv5_clientview_' . $client_view_url;
				if ( ! is_user_logged_in() ) {
					$user    = get_user_by( 'login', $username );
					$user_id = $user->ID;
					wp_set_current_user( $user_id, $username );
					wp_set_auth_cookie( $user_id );
					do_action( 'wp_login', $username, $user );
					update_user_meta( $user_id, 'show_admin_bar_front', false );
				}

				// This doesn't have the intended effect. Using a non-WP function in setcookie() might be the reason why.
				add_filter( 'auth_cookie_expiration', 'seed_cspv5_legacy_change_wp_cookie_logout', 10, 3 );

				if ( ! empty( $_REQUEST['return'] ) ) {
					nocache_headers();
					header( 'Cache-Control: max-age=0, private' );
					wp_safe_redirect( wp_validate_redirect( is_string( $_REQUEST['return'] ) ? wp_unslash( $_REQUEST['return'] ) : '', home_url() ) );
					exit;
				} else {
					nocache_headers();
					header( 'Cache-Control: max-age=0, private' );
					header( 'Location: ' . home_url() . '?' . rand() );
					exit;
				}
			}
		}
	}

	// Check for excluded IP's
	if ( $is_preview == false ) {
		if ( ! empty( $ip_access ) ) {
			$ip          = seed_cspv5_legacy_get_ip();
			$exclude_ips = explode( "\r\n", $ip_access );
			if ( is_array( $exclude_ips ) && in_array( $ip, $exclude_ips ) ) {
				return false;
			}
		}
	}

	if ( $is_preview == false ) {
		if ( ! empty( $include_exclude_options ) && $include_exclude_options == '2' ) {
			if ( substr( $include_url_pattern, 0, 3 ) != '>>>' ) {

				// Check for included pages
				if ( ! empty( $include_url_pattern ) ) {
					//$url = preg_replace('/\?ref=\d*/','',$_SERVER['REQUEST_URI']);
					// TODO lok for when WordPress is in sub folder
					$request_uri = explode( '?', $_SERVER['REQUEST_URI'] );
					$url         = rtrim( ltrim( $request_uri[0], '/' ), '/' );

					$r = array_intersect( explode( '/', $url ), explode( '/', home_url() ) );

					$url = str_replace( $r, '', $url );

					$url = str_replace( '/', '', $url );
					//var_dump($url);

					$include_urls = explode( "\r\n", $include_url_pattern );
					$include_urls = array_filter( $include_urls );
					$include_urls = str_replace( home_url(), '', $include_urls );
					$include_urls = str_replace( '/', '', $include_urls );
					//$include_urls = array_filter($include_urls);
					//var_dump($include_urls);
					//var_dump($url);
					$post_id = '';
					global $post;
					//var_dump($post->ID);
					if ( ! empty( $post->ID ) ) {
						$post_id = $post->ID;
					}

					$show_coming_soon_page = false;

					if ( is_array( $include_urls ) && ( in_array( $url, $include_urls ) || in_array( $post_id, $include_urls ) ) ) {
						$show_coming_soon_page = true;
					}

					// check wildcard urls
					$urls_to_test = $include_urls;
					$urls_to_test = str_replace( home_url(), '', $urls_to_test );
					$url_uri      = $_SERVER['REQUEST_URI'];
					foreach ( $urls_to_test as $url_to_test ) {
						if ( strpos( $url_to_test, '*' ) !== false ) {
							// Wildcard url
							$url_to_test = str_replace( '*', '', $url_to_test );
							if ( strpos( $url_uri, untrailingslashit( $url_to_test ) ) !== false ) {
								$show_coming_soon_page = true;
							}
						}
					}

					if ( $show_coming_soon_page === false ) {
						return false;
					}
				}
			} else {
				// Check for included pages regex
				$include_url_pattern = substr( $include_url_pattern, 3 );
				if ( ! empty( $include_url_pattern ) && @preg_match( "/{$include_url_pattern}/", $_SERVER['REQUEST_URI'] ) == 0 ) {
					return false;
				}
			}
		}

		// Check for excludes pages
		if ( ! empty( $include_exclude_options ) && $include_exclude_options == '3' ) {
			if ( substr( $exclude_url_pattern, 0, 3 ) != '>>>' ) {
				if ( ! empty( $exclude_url_pattern ) ) {
					//$url = preg_replace('/\?ref=\d*/','',$_SERVER['REQUEST_URI']);
					$request_uri = explode( '?', $_SERVER['REQUEST_URI'] );
					$url         = rtrim( ltrim( $request_uri[0], '/' ), '/' );

					$r = array_intersect( explode( '/', $url ), explode( '/', home_url() ) );

					$url = str_replace( $r, '', $url );

					$url = str_replace( '/', '', $url );
					//var_dump($url);

					$exclude_urls = explode( "\r\n", $exclude_url_pattern );
					$exclude_urls = array_filter( $exclude_urls );
					$exclude_urls = str_replace( home_url(), '', $exclude_urls );
					$exclude_urls = str_replace( '/', '', $exclude_urls );
					//$exclude_urls = array_filter($exclude_urls);
					$post_id = '';
					global $post;
					//var_dump($post->ID);
					if ( ! empty( $post->ID ) ) {
						$post_id = $post->ID;
					}

					// check exact urls
					if ( is_array( $exclude_urls ) && ( in_array( $url, $exclude_urls ) || in_array( $post_id, $exclude_urls ) ) ) {
						return false;
					}

					// check wildcard urls
					$urls_to_test = $exclude_urls;
					$urls_to_test = str_replace( home_url(), '', $urls_to_test );
					$url_uri      = $_SERVER['REQUEST_URI'];
					foreach ( $urls_to_test as $url_to_test ) {
						if ( strpos( $url_to_test, '*' ) !== false ) {
							// Wildcard url
							$url_to_test = str_replace( '*', '', $url_to_test );
							if ( strpos( $url_uri, untrailingslashit( $url_to_test ) ) !== false ) {
								return false;
							}
						}
					}

					// Check for affiliateWP
					if ( class_exists( 'Affiliate_WP' ) && ( strpos( $url, 'ref' ) !== false ) ) {
						return false;
					}
				}
			} else {

				// Check for excluded pages
				$exclude_url_pattern = substr( $exclude_url_pattern, 3 );
				if ( ! empty( $exclude_url_pattern ) && @preg_match( "/{$exclude_url_pattern}/", $_SERVER['REQUEST_URI'] ) > 0 ) {
					return false;
				}
			}
		}
	}

	// Only show the Coming Soon Page on the home page
	if ( ! empty( $include_exclude_options ) && $include_exclude_options == '1' && $is_preview == false ) {
		if ( $_SERVER['REQUEST_URI'] == '/' || substr( $_SERVER['REQUEST_URI'], 0, 2 ) == '/?' ) {
		} else {
			return false;
		}
	}

	// Check if redirect url and exclude
	if ( $status == '3' && ! empty( $redirect_url ) ) {
		$r_url = parse_url( $redirect_url );
		if ( $r_url['host'] == $_SERVER['HTTP_HOST'] && $r_url['path'] == $_SERVER['REQUEST_URI'] && $is_preview == false ) {
			return false;
		}
	}

	// Exit if a custom login page
	if ( empty( $disable_default_excluded_urls ) ) {
		if ( preg_match( '/login|admin|dashboard|account/i', seedprod_pro_get_excluded_url_path() ) > 0 && $is_preview == false ) {
			return false;
		}
	}

	//Exit if wysija double opt-in
	if ( isset( $emaillist ) && $emaillist == 'wysija' && preg_match( '/wysija/i', $_SERVER['REQUEST_URI'] ) > 0 && $is_preview == false ) {
		return false;
	}

	if ( isset( $emaillist ) && $emaillist == 'mailpoet' && preg_match( '/mailpoet/i', $_SERVER['REQUEST_URI'] ) > 0 && $is_preview == false ) {
		return false;
	}

	if ( isset( $emaillist ) && $emaillist == 'mymail' && preg_match( '/confirm/i', $_SERVER['REQUEST_URI'] ) > 0 && $is_preview == false ) {
		return false;
	}

	//Limit access by role

	if ( $is_preview === false ) {
		$has_client_view = ! empty( $client_view_url ) && isset( $_COOKIE['wp-client-view'] ) && $_COOKIE['wp-client-view'] === md5( $client_view_url . get_current_blog_id() );
		if ( ! empty( $include_roles ) && ! $has_client_view ) {
			foreach ( $include_roles as $v ) {
				if ( $v == 'anyone' && is_user_logged_in() ) {
					return false;
				}
				if ( current_user_can( $v ) ) {
					return false;
				}
			}
		} elseif ( is_user_logged_in() ) {
			return false;
		}
	}

	// check if 3rd party plugins is enabled
	if ( ! empty( $settings['enable_wp_head_footer'] ) ) {
		//add_action('wp_enqueue_scripts', 'seed_cspv5_deregister_frontend_theme_styles', PHP_INT_MAX);
	}

	// Finally check if we should show the coming soon page.

	// set headers
	if ( $status == '2' && $is_preview == false ) {
		if ( empty( $settings ) ) {
			echo __( 'Please create your Maintenance Page in the plugin settings.', 'seedprod-pro' );
			exit();
		}
		header( 'HTTP/1.1 503 Service Temporarily Unavailable' );
		header( 'Status: 503 Service Temporarily Unavailable' );
		header( 'Retry-After: 86400' ); // retry in a day
		$seed_cspv5_maintenance_file = WP_CONTENT_DIR . '/maintenance.php';
		if ( ! empty( $enable_maintenance_php ) and file_exists( $seed_cspv5_maintenance_file ) ) {
			include_once $seed_cspv5_maintenance_file;
			exit();
		}
	} elseif ( $status == '3' ) {
		if ( ! empty( $redirect_url ) ) {
			wp_redirect( $redirect_url );
			exit;
		} else {
			echo __( 'Please create enter your redirect url in the plugin settings.', 'seedprod-pro' );
			exit();
		}
	} else {
		if ( empty( $settings ) ) {
			echo __( 'Please create your Coming Soon Page in the plugin settings.', 'seedprod-pro' );
			exit();
		}
		header( 'HTTP/1.1 200 OK' );
		header( 'Cache-Control: max-age=0, private' );
	}

	if ( is_feed() ) {
		header( 'Content-Type: text/html; charset=UTF-8' );
	}

	// Prevetn Plugins from caching
	// Disable caching plugins. This should take care of:
	//   - W3 Total Cache
	//   - WP Super Cache
	//   - ZenCache (Previously QuickCache)
	if ( ! defined( 'DONOTCACHEPAGE' ) ) {
		define( 'DONOTCACHEPAGE', true );
	}

	if ( ! defined( 'DONOTCDN' ) ) {
		define( 'DONOTCDN', true );
	}

	if ( ! defined( 'DONOTCACHEDB' ) ) {
		define( 'DONOTCACHEDB', true );
	}

	if ( ! defined( 'DONOTMINIFY' ) ) {
		define( 'DONOTMINIFY', true );
	}

	if ( ! defined( 'DONOTCACHEOBJECT' ) ) {
		define( 'DONOTCACHEOBJECT', true );
	}

	// render
	$upload_dir = wp_upload_dir();
	if ( is_multisite() ) {
		$path = $upload_dir['baseurl'] . '/seedprod/' . get_current_blog_id() . '/template-' . $page_id . '/index.php';
	} else {
		$path = $upload_dir['basedir'] . '/seedprod/template-' . $page_id . '/index.php';
	}

	if ( ! empty( $page->html ) ) {
		echo seedprod_pro_strip_vue_render_helpers( $page->html );
	} else {
		if ( file_exists( $path ) ) {
			require_once $path;
		} else {
			require_once SEEDPROD_PRO_PLUGIN_PATH . 'app/backwards/template/index.php';
		}
	}

	exit();
}



function seed_cspv5_legacy_get_settings() {
	$settings = get_option( 'seed_cspv5_settings_content' );
	return apply_filters( 'seed_cspv5_get_settings', $settings );
}




/**
 * Remove theme's style sheets so they do not conflict with the coming soon page
 */

function seed_cspv5_legacy_deregister_frontend_theme_styles() {
	// remove scripts registered ny the theme so they don't screw up our page's style

	global $wp_styles;
	// list of styles to keep else remove
	$styles = 'admin-bar';
	$d      = explode( '|', $styles );
	$theme  = wp_get_theme();

	//loop styles to see which one's the theme registers
	$remove_these_styles = array( 'admin-bar' );
	foreach ( $wp_styles->registered as $k => $v ) {
		if ( in_array( $k, $wp_styles->queue ) ) {
			// if the src contains the template or stylesheet remove
			if ( strpos( $v->src, $theme->stylesheet ) !== false ) {
				$remove_these_styles[] = $k;
			}
			if ( strpos( $v->src, $theme->template ) !== false ) {
				if ( ! in_array( $k, $remove_these_styles ) ) {
					$remove_these_styles[] = $k;
				}
			}
		}
	}

	foreach ( $wp_styles->queue as $handle ) {
		//echo '<br> '.$handle;
		if ( ! empty( $remove_these_styles ) ) {
			if ( in_array( $handle, $remove_these_styles ) ) {
				wp_dequeue_style( $handle );
				wp_deregister_style( $handle );
				//echo '<br>removed '.$handle;
			}
		}
	}

	add_filter( 'show_admin_bar', '__return_false' );
}




function seed_cspv5_legacy_select_lang( $id, $option_values, $selected = null, $style = null ) {
	echo "<select id='$id' name='$id' class='form-control input-sm' style='{$style}'>";
	if ( ! empty( $option_values ) ) {
		foreach ( $option_values as $k => $v ) {
			if ( is_array( $v ) ) {
				echo '<optgroup label="' . ucwords( $k ) . '">';
				foreach ( $v as $k1 => $v1 ) {
					echo '<option value="' . $k1 . '"' . selected( $selected, $k1, false ) . ">$v1</option>";
				}
				echo '</optgroup>';
			} else {
				if ( ! isset( $options[ $id ] ) ) {
					$options[ $id ] = '';
				}
				$language_name = $v;
				$language_name = explode( '|', $language_name );
				if ( ! empty( $language_name[0] ) ) {
					$v = $language_name[0];
				}
				echo "<option value='$k' " . selected( $selected, $k, false ) . ">$v</option>";
			}
		}
	}
	echo '</select> ';
}


/**
 * Verify the AJAX nonce that the rendered form prints.
 *
 * @param string $action The nonce action.
 * @return bool True when the nonce is valid.
 */
function seedprod_pro_cspv5_legacy_verify_nonce( $action ) {
	$nonce = isset( $_REQUEST['_wpnonce'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['_wpnonce'] ) ) : '';
	return (bool) wp_verify_nonce( $nonce, $action );
}

/**
 * Return the JSONP callback name when it holds identifier characters only.
 *
 * @return string The safe callback name, or an empty string.
 */
function seedprod_pro_cspv5_legacy_jsonp_callback() {
	$callback = isset( $_GET['callback'] ) ? wp_unslash( $_GET['callback'] ) : '';
	if ( ! is_string( $callback ) ) {
		return '';
	}
	return preg_match( '/^[A-Za-z0-9_.]{1,64}$/', $callback ) ? $callback : '';
}

/**
 * Print a JSONP response and stop. The callback name holds identifier characters only, so it is safe to print.
 *
 * @param array    $response    The response data.
 * @param int|null $status_code An HTTP status code to send, or null to leave it at 200.
 * @return void
 */
function seedprod_pro_cspv5_legacy_send_jsonp( $response, $status_code = null ) {
	if ( null !== $status_code ) {
		status_header( (int) $status_code );
	}
	header( 'Content-Type: text/javascript; charset=utf8' );
	echo seedprod_pro_cspv5_legacy_jsonp_callback() . '(' . wp_json_encode( $response ) . ')'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- The callback holds identifier characters only and wp_json_encode escapes the body.
	wp_die( '', '', array( 'response' => null ) );
}

/**
 * Add the request's lang arg to a URL, when the request has one.
 *
 * @param string $url The URL.
 * @return string The URL with the lang arg when the request has one.
 */
function seedprod_pro_cspv5_legacy_with_lang( $url ) {
	$lang = isset( $_REQUEST['lang'] ) && is_string( $_REQUEST['lang'] ) ? sanitize_key( wp_unslash( $_REQUEST['lang'] ) ) : '';
	return '' !== $lang ? add_query_arg( 'lang', $lang, $url ) : $url;
}

/**
 * Build the current page URL on this site's own host, with the request's lang arg.
 *
 * In an AJAX request REQUEST_URI is admin-ajax.php, so use the site home. Outside AJAX,
 * strip the home path from REQUEST_URI first, so a subdirectory install does not double the path.
 *
 * @return string The own-host URL.
 */
function seedprod_pro_cspv5_legacy_current_url() {
	if ( wp_doing_ajax() ) {
		return seedprod_pro_cspv5_legacy_with_lang( home_url( '/' ) );
	}
	$request_uri = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '/';
	$path        = (string) wp_parse_url( $request_uri, PHP_URL_PATH );
	$home_path   = (string) wp_parse_url( home_url(), PHP_URL_PATH );
	if ( '' !== $home_path && '/' !== $home_path && 0 === strpos( $path, $home_path ) ) {
		$path = substr( $path, strlen( $home_path ) );
	}
	return seedprod_pro_cspv5_legacy_with_lang( home_url( '/' . ltrim( $path, '/' ) ) );
}

/**
 * Compare two hosts, treating a leading "www." as the same host.
 *
 * @param string $a The first host.
 * @param string $b The second host.
 * @return bool True when the hosts match.
 */
function seedprod_pro_cspv5_legacy_same_host( $a, $b ) {
	$strip = static function ( $h ) {
		return preg_replace( '/^www\./i', '', (string) $h );
	};
	return 0 === strcasecmp( $strip( $a ), $strip( $b ) );
}

/**
 * Accept only an http or https URL on this site's own host, rebuilt from its scheme, host, port
 * and path. Drop the query and fragment, then add the request's lang arg. Return the current
 * own-host URL for any other URL.
 *
 * @param string $url The candidate URL.
 * @return string The own-host URL.
 */
function seedprod_pro_cspv5_legacy_own_host_url( $url ) {
	$parts  = wp_parse_url( (string) $url );
	$home   = (string) wp_parse_url( home_url(), PHP_URL_HOST );
	$scheme = ! empty( $parts['scheme'] ) ? strtolower( $parts['scheme'] ) : 'http';
	if ( ! in_array( $scheme, array( 'http', 'https' ), true ) || empty( $parts['host'] ) || ! seedprod_pro_cspv5_legacy_same_host( $parts['host'], $home ) ) {
		return seedprod_pro_cspv5_legacy_current_url();
	}
	$port   = ! empty( $parts['port'] ) ? ':' . (int) $parts['port'] : '';
	$path   = ! empty( $parts['path'] ) ? $parts['path'] : '/';
	return seedprod_pro_cspv5_legacy_with_lang( $scheme . '://' . $parts['host'] . $port . $path );
}

/**
 * Load a legacy page row that a renderer serves, so a request cannot choose another row by id.
 *
 * Match the render paths: the Coming Soon renderer serves the active page even when it is
 * deactivated; the landing-page renderer serves a landing page only when it is live and its
 * meta is not 'migrated'.
 *
 * @param mixed $page_id The requested page id.
 * @return object|false The row, or false when no renderer serves it.
 */
function seedprod_pro_cspv5_legacy_resolve_page( $page_id ) {
	global $wpdb;
	$page_id = absint( $page_id );
	if ( empty( $page_id ) ) {
		return false;
	}
	$page = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}cspv5_pages WHERE id = %d", $page_id ) );
	if ( empty( $page ) ) {
		return false;
	}
	if ( $page_id === (int) get_option( 'seed_cspv5_coming_soon_page_id' ) ) {
		return $page;
	}
	if ( 'lp' === $page->type && empty( $page->deactivate ) && 'migrated' !== $page->meta ) {
		return $page;
	}
	return false;
}

/**
 * Normalise the client IP for a rate-limit key. Group an IPv6 address by its /64 prefix.
 *
 * @return string The normalised address.
 */
function seedprod_pro_cspv5_legacy_rate_ip() {
	$ip = ! empty( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	if ( false !== strpos( $ip, ':' ) ) {
		$packed = @inet_pton( $ip ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- inet_pton warns on a malformed address.
		// An IPv4-mapped address (::ffff:a.b.c.d) is an IPv4 client, so key it as IPv4.
		if ( false !== $packed && 16 === strlen( $packed ) && "\0\0\0\0\0\0\0\0\0\0\xff\xff" === substr( $packed, 0, 12 ) ) {
			return inet_ntop( substr( $packed, 12, 4 ) );
		}
		if ( false !== $packed && 16 === strlen( $packed ) ) {
			return 'v6/' . bin2hex( substr( $packed, 0, 8 ) );
		}
	}
	return $ip;
}

/**
 * Per-IP fixed-window rate limit. Return true while the request is within the limit.
 *
 * The window does not restart on each hit, so a steady stream cannot keep it open.
 * Call it only for a request that passed its checks, so a blocked request does not spend the budget.
 *
 * @param string $bucket A name for the limited action.
 * @return bool True when the request is allowed.
 */
function seedprod_pro_cspv5_legacy_rate_ok( $bucket ) {
	$limit  = (int) apply_filters( 'seedprod_pro_cspv5_legacy_rate_limit', 10, $bucket );
	$window = (int) apply_filters( 'seedprod_pro_cspv5_legacy_rate_window', 10 * MINUTE_IN_SECONDS, $bucket );
	$key    = 'sp_cspv5_rl_' . $bucket . '_' . md5( seedprod_pro_cspv5_legacy_rate_ip() );
	$now    = time();
	$state  = get_transient( $key );
	if ( ! is_array( $state ) || empty( $state['reset'] ) || $now > (int) $state['reset'] ) {
		$state = array(
			'count' => 0,
			'reset' => $now + $window,
		);
	}
	if ( $state['count'] >= $limit ) {
		return false;
	}
	++$state['count'];
	set_transient( $key, $state, max( 1, (int) $state['reset'] - $now ) );
	return true;
}

/**
 * Read a subscriber's stored referral stats. Read only, so no row is created.
 *
 * @param int    $page_id The page id.
 * @param string $email   The subscriber email.
 * @return array|null The stats, or null when there is no record.
 */
function seedprod_pro_cspv5_legacy_lookup_stats( $page_id, $email ) {
	global $wpdb;
	$email = sanitize_email( $email );
	if ( empty( $email ) ) {
		return null;
	}
	$row = $wpdb->get_row( $wpdb->prepare( "SELECT id, clicks, conversions FROM {$wpdb->prefix}csp3_subscribers WHERE email = %s AND page_id = %d", $email, absint( $page_id ) ) );
	if ( empty( $row ) ) {
		return null;
	}
	return array(
		'ref'         => base_convert( $row->id + 1000, 10, 36 ),
		'clicks'      => (int) $row->clicks,
		'subscribers' => (int) $row->conversions,
	);
}

	/**
	 * Subscribe User to Mailing List or return an error.
	 */

function seed_cspv5_legacy_subscribe_callback() {
	if ( ! seedprod_pro_cspv5_legacy_verify_nonce( 'seed_cspv5_legacy_subscribe_callback' ) ) {
		seedprod_pro_cspv5_legacy_send_jsonp(
			array(
				'status' => '500',
				'html'   => __( 'Your session expired. Please reload the page and try again.', 'seedprod-pro' ),
			)
		);
	}

	// Initialize a global var to store results in
	global $seed_cspv5_post_result;
	global $errors;
	global $seed_cspv5_legacy_over_limit;
	$errors                       = array();
	$seed_cspv5_legacy_over_limit = false;

	// Get the page id. Accept only the active Coming Soon page or a live landing page.
	$page_id = ! empty( $_REQUEST['page_id'] ) ? absint( $_REQUEST['page_id'] ) : 0;
	$page    = seedprod_pro_cspv5_legacy_resolve_page( $page_id );
	if ( empty( $page ) ) {
		seedprod_pro_cspv5_legacy_send_jsonp(
			array(
				'status' => '400',
				'html'   => '',
			)
		);
	}
	$data['page_id'] = $page_id;

	if ( base64_encode( base64_decode( $page->settings, true ) ) === $page->settings ) {
		$settings = unserialize( base64_decode( $page->settings ) );
	} else {
		$settings = unserialize( $page->settings );
	}

	@extract( $settings );

	// Ensure extracted variables are not null for PHP 8+ compatibility
	if ( ! isset( $redirect_url ) ) {
		$redirect_url = '';
	}

	// A returning-user submit skips the reCAPTCHA, name, opt-in and custom-field checks; the email
	// check always runs. Honor it only when the page enables returning users and a stored record
	// exists for the email (checked below).
	$return_candidate = ! empty( $_REQUEST['comment'] )
		&& ! empty( $rp_return_user )
		&& ( ! empty( $enable_reflink ) || ! empty( $enable_prize_levels ) );
	$is_return_user   = false;
	$cookie_submit    = $return_candidate;
	$return_stats     = null;

	// Get language info
	$lang_id = '';
	if ( ! empty( $_REQUEST['lang'] ) ) {
		$lang_id = $_REQUEST['lang'];
	}

	if ( ! empty( $lang_id ) ) {
		$lang_settings_name = 'seed_cspv5_' . $page_id . '_language_' . $lang_id;
		$lang_settings      = get_option( $lang_settings_name );
		if ( ! empty( $lang_settings ) ) {
			$lang_settings = maybe_unserialize( $lang_settings );
		}
	}

	if ( ! empty( $lang_settings['thankyou_msg'] ) && ! empty( $lang_id ) ) {
		$ty_content = $lang_settings['thankyou_msg'];
	} else {
		$ty_content = $settings['thankyou_msg'];
	}

	if ( ! empty( $lang_settings['txt_stats_referral_url'] ) && ! empty( $lang_id ) ) {
		$txt_stats_referral_url = $lang_settings['txt_stats_referral_url'];
	} else {
		$txt_stats_referral_url = $settings['txt_stats_referral_url'];
	}

	if ( ! empty( $lang_settings['txt_stats_referral_stats'] ) && ! empty( $lang_id ) ) {
		$txt_stats_referral_stats = $lang_settings['txt_stats_referral_stats'];
	} else {
		$txt_stats_referral_stats = $settings['txt_stats_referral_stats'];
	}

	if ( ! empty( $lang_settings['txt_stats_referral_subscribers'] ) && ! empty( $lang_id ) ) {
		$txt_stats_referral_subscribers = $lang_settings['txt_stats_referral_subscribers'];
	} else {
		$txt_stats_referral_subscribers = $settings['txt_stats_referral_subscribers'];
	}

	if ( ! empty( $lang_settings['txt_already_subscribed_msg'] ) && ! empty( $lang_id ) ) {
		$txt_already_subscribed_msg = $lang_settings['txt_already_subscribed_msg'];
	} else {
		$txt_already_subscribed_msg = $settings['txt_already_subscribed_msg'];
	}

	// Get form info
	// Get form settings
	if ( seed_cspv5_legacy_cu( 'fb' ) ) {
		$form_settings_name = 'seed_cspv5_' . $page_id . '_form';
		$form_settings      = get_option( $form_settings_name );
		if ( ! empty( $form_settings ) ) {
			$form_settings = maybe_unserialize( $form_settings );
		}
	}

	// Collect request data
	// Spam check, this will be fined in if spam
	if ( ! empty( $_REQUEST['message'] ) ) {
		return false;
	}

	// Check field values
	$email = '';
	if ( ! empty( $_REQUEST['email'] ) ) {
		$email = sanitize_email( $_REQUEST['email'] );
	}

	// With a stored record, show its stats only. Without one, send an empty 400 reply and save nothing.
	if ( $return_candidate ) {
		$return_stats = seedprod_pro_cspv5_legacy_lookup_stats( $page_id, $email );
		if ( null === $return_stats ) {
			seedprod_pro_cspv5_legacy_send_jsonp(
				array(
					'status' => '400',
					'html'   => '',
				)
			);
		}
		$is_return_user = true;
	}

	$name = '';
	if ( ! empty( $_REQUEST['name'] ) ) {
		$name = sanitize_text_field( $_REQUEST['name'] );
	}

	$optin_confirmation = 0;
	if ( ! empty( $_REQUEST['optin_confirmation'] ) ) {
		$optin_confirmation = 1;
	}

	// Sanitize random fields
	if ( seed_cspv5_legacy_cu( 'fb' ) ) {
		foreach ( $_REQUEST as $k => $v ) {
			if ( substr( $k, 0, 6 ) === 'field_' ) {
				$_REQUEST[ $k ] = sanitize_text_field( $v );
			}
		}
	}

	$bypassed_emaillist = apply_filters( 'seed_cspv5_bypassed_emaillist', array( 'gravityforms', 'ninjaforms', 'formidable' ) );

	// Check it we need to validate recaptcha
	if ( ! in_array( $emaillist, $bypassed_emaillist ) ) {
		if ( ! empty( $enable_recaptcha ) && ! $cookie_submit && ! empty( $recaptcha_site_key ) && ! empty( $recaptcha_secret_key ) ) {
			$response = wp_remote_post(
				'https://www.google.com/recaptcha/api/siteverify',
				array(
					'body' => array(
						'secret'   => $recaptcha_secret_key,
						'response' => isset( $_REQUEST['g-recaptcha-response'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['g-recaptcha-response'] ) ) : '',
					),
				)
			);

			$body = is_wp_error( $response ) ? null : json_decode( wp_remote_retrieve_body( $response ) );

			// Accept the subscribe only when reCAPTCHA confirms success.
			if ( empty( $body ) || empty( $body->success ) ) {
				$seed_cspv5_post_result['status']    = '400';
				$seed_cspv5_post_result['msg']       = 'Invalid Recaptcha';
				$seed_cspv5_post_result['msg_class'] = 'alert-danger';
				$errors[]                            = $seed_cspv5_post_result['msg'];

				$emaillist = '';
			}
		}
	}

	// Check it we need to validate email
	if ( ! in_array( $emaillist, $bypassed_emaillist ) ) {
		if ( is_email( $email ) != $email || empty( $email ) ) {
			$seed_cspv5_post_result['status'] = '400';
			if ( ! empty( $lang_settings['txt_invalid_email_msg'] ) && ! empty( $lang_id ) ) {
				$seed_cspv5_post_result['msg'] = $lang_settings['txt_invalid_email_msg'];
			} else {
				$seed_cspv5_post_result['msg'] = $txt_invalid_email_msg;
			}
			$seed_cspv5_post_result['msg_class'] = 'alert-danger';
			$errors[]                            = $seed_cspv5_post_result['msg'];

			$emaillist = '';
		}
	}

	// Check it we need to validate name
	if ( ! in_array( $emaillist, $bypassed_emaillist ) ) {
		if ( ! empty( $display_name ) ) {
			if ( ! empty( $require_name ) && ! $cookie_submit ) {
				if ( empty( $name ) ) {
					$seed_cspv5_post_result['status'] = '400';
					if ( ! empty( $lang_settings['txt_invalid_name_msg'] ) && ! empty( $lang_id ) ) {
						$seed_cspv5_post_result['msg'] = $lang_settings['txt_invalid_name_msg'];
					} else {
						$seed_cspv5_post_result['msg'] = $txt_invalid_name_msg;
					}
					$seed_cspv5_post_result['msg_class'] = 'alert-danger';
					$errors[]                            = $seed_cspv5_post_result['msg'];

					$emaillist = '';
				}
			}
		}
		// Validate Optin Confirmation
		if ( ! empty( $display_optin_confirm ) ) {
			if ( empty( $optin_confirmation ) && ! $cookie_submit ) {
				$seed_cspv5_post_result['status'] = '400';
				if ( ! empty( $lang_settings['txt_optin_confirmation_required'] ) && ! empty( $lang_id ) ) {
					$seed_cspv5_post_result['msg'] = $lang_settings['txt_optin_confirmation_required'];
				} else {
					$seed_cspv5_post_result['msg'] = $txt_optin_confirmation_required;
				}
				$seed_cspv5_post_result['msg_class'] = 'alert-danger';
				$errors[]                            = $seed_cspv5_post_result['msg'];

				$emaillist = '';
			}
		}

		//Check custom fields for required
		if ( ! empty( $form_settings ) && seed_cspv5_legacy_cu( 'fb' ) ) {
			foreach ( $form_settings as $k => $v ) {
				if ( is_array( $v ) ) {
					if ( substr( $k, 0, 6 ) === 'field_' && $k != 'field_name' ) {
						if ( ! empty( $v['required'] ) && ! empty( $v['visible'] ) && ! $cookie_submit ) {
							if ( empty( $_REQUEST[ $k ] ) ) {
								$seed_cspv5_post_result['status'] = '400';
								// if(!empty($lang_settings['txt_invalid_name_msg']) && !empty($lang_id)){
								//    $seed_cspv5_post_result['msg'] = $lang_settings['txt_invalid_name_msg'];
								// }else{
								$seed_cspv5_post_result['msg'] = $v['label'] . ' Required';
								//}
								$seed_cspv5_post_result['msg_class'] = 'alert-danger';
								$errors[]                            = $seed_cspv5_post_result['msg'];

								$emaillist = '';
							}
						}
					}
				}
			}
		}
	}

	if ( $is_return_user ) {
		// Show the stored stats. Do not call the provider or send mail.
		$emaillist                             = '';
		$seed_cspv5_post_result['status']      = '409';
		$seed_cspv5_post_result['ref']         = $return_stats['ref'];
		$seed_cspv5_post_result['clicks']      = $return_stats['clicks'];
		$seed_cspv5_post_result['subscribers'] = $return_stats['subscribers'];
	} elseif ( ! empty( $emaillist ) && ! seedprod_pro_cspv5_legacy_rate_ok( 'subscribe' ) ) {
		// Over the limit, send no mail. Save to the local database list only. Do not call an
		// external provider, because it can send its own mail; show a visible retry message.
		$seed_cspv5_legacy_over_limit = true;
		if ( 'database' !== $emaillist ) {
			$emaillist                           = '';
			$seed_cspv5_post_result['status']    = '400';
			$seed_cspv5_post_result['msg']       = __( 'Please try again later.', 'seedprod-pro' );
			$seed_cspv5_post_result['msg_class'] = 'alert-danger';
			$errors[]                            = $seed_cspv5_post_result['msg'];
		}
	}

	// Do email list action
	if ( ! empty( $emaillist ) ) {
		$data['settings'] = $settings;
		// Get settings
		$mod = '';
		if ( $emaillist == 'mailchimp' ) {
			$e_settings_name = 'seed_cspv5_' . $page_id . '_' . $emaillist;
			$e_settings      = get_option( $e_settings_name );
			if ( ! empty( $e_settings ) ) {
				$e_settings = maybe_unserialize( $e_settings );
			}
			if ( empty( $e_settings['mailchimp_api_key'] ) || ( ! empty( $e_settings['api_version'] ) && $e_settings['api_version'] == '3' ) ) {
				// Use V3
				$mod = '_v3';
			}
		}
		do_action( 'seed_cspv5_legacy_emaillist_' . $emaillist . $mod, $data );
	}

	$html = '';

	if ( isset( $GLOBALS['wp_embed'] ) ) {
		$ty_content = $GLOBALS['wp_embed']->autoembed( $ty_content );
	}
	$ty_content = do_shortcode( shortcode_unautop( wpautop( convert_chars( wptexturize( $ty_content ) ) ) ) );

	// Return HTML
	if ( '200' == $seed_cspv5_post_result['status'] ) {
		// New Subscriber
		$status = '200';

		$html = $ty_content . $settings['conversion_scripts'];
		if ( ! empty( $settings['enable_reflink'] ) ) {
			$html .= "<br><br><div id='cspio-ref-link'>" . $txt_stats_referral_url . '<br>' . esc_url( seed_cspv5_legacy_ref_link() ) . '</div>';

			if ( ! empty( $settings['enable_prize_levels'] ) && $settings['enable_prize_levels'] == '1' ) {
				// get settings
				// Get form settings
				$prize_settings_name = 'seed_cspv5_' . $page_id . '_prizes';
				$prize_settings      = get_option( $prize_settings_name );
				if ( ! empty( $prize_settings ) ) {
					$prize_settings = maybe_unserialize( $prize_settings );
				}

				$html .= '<table id="cspio-prizes">';
				foreach ( $prize_settings as $k => $v ) {
					if ( strrpos( $k, 'prize_' ) !== false ) {
						if ( ! empty( $v['description'] ) ) {
							$class = '';
							if ( empty( $seed_cspv5_post_result['subscribers'] ) ) {
								$seed_cspv5_post_result['subscribers'] = 0;
							}
							if ( $seed_cspv5_post_result['subscribers'] >= $v['number'] ) {
								$class = 'cspio-reveal';
							}
							$html .= '<tr class="' . $class . '"><td class="cspio-prizes-desc">' . $v['description'] . '</td>';
							if ( $seed_cspv5_post_result['subscribers'] >= $v['number'] ) {
								$html .= '<td class="cspio-prizes-reveal">' . $v['reveal'] . '</td>';
							} else {
								if ( empty( $txt_prize_level_more ) ) {
									$txt_prize_level_more = 'Refer %d more subscribers to claim this.';
								}
								$need  = ( $v['number'] - $seed_cspv5_post_result['subscribers'] );
								$html .= '<td class="cspio-prizes-reveal">' . sprintf( $txt_prize_level_more, $need ) . ' </td>';
							}

							$html .= '</tr>';
						}
					}
				}
				$html .= '</table>';
			}
		}
		// Send Auto responder if setup
		// Get autoresponder settings
		$autoresponder_settings_name = 'seed_cspv5_' . $page_id . '_autoresponder';
		$autoresponder_settings      = get_option( $autoresponder_settings_name );
		if ( ! empty( $autoresponder_settings ) ) {
			if ( ! empty( $autoresponder_settings['autoresponder'] ) && $autoresponder_settings['from_email'] && $autoresponder_settings['subject'] ) {
				$autoresponder_settings = maybe_unserialize( $autoresponder_settings );
				// Send auto responder
				$msg           = $autoresponder_settings['autoresponder'];
				$template_tags = array(
					'{referral_url}' => esc_url( seed_cspv5_legacy_ref_link() ),
				);
				$msg           = strtr( $msg, $template_tags );
				$from_email    = sanitize_text_field( $autoresponder_settings['from_email'] );
				$subject       = sanitize_text_field( $autoresponder_settings['subject'] );

				$headers[] = 'From: ' . $from_email;
				$headers[] = 'Content-Type: text/html; charset=UTF-8';

				if ( empty( $seed_cspv5_legacy_over_limit ) ) {
					$mresult = wp_mail( $email, $subject, $msg, $headers );
				}
			}
		}
	} elseif ( '409' == $seed_cspv5_post_result['status'] ) {
		// Already Subscribed
		$status = '409';

		$html = $txt_already_subscribed_msg;
		if ( ! empty( $settings['enable_reflink'] ) ) {
			// Already Subscribed send Referaral Info
			$html .= "<br><br><div id='cspio-ref-link'>" . $txt_stats_referral_url . '<br>' . esc_url( seed_cspv5_legacy_ref_link() );
			$html .= '</div>';
			$html .= '<br>' . $txt_stats_referral_stats . '<br>' . $txt_stats_referral_subscribers . ': <span class="cspio-subscriber-count">' . $seed_cspv5_post_result['subscribers'] . '</span>';

			if ( ! empty( $settings['enable_prize_levels'] ) && $settings['enable_prize_levels'] == '1' ) {
				// get settings
				// Get form settings
				$prize_settings_name = 'seed_cspv5_' . $page_id . '_prizes';
				$prize_settings      = get_option( $prize_settings_name );
				if ( ! empty( $prize_settings ) ) {
					$prize_settings = maybe_unserialize( $prize_settings );
				}
				unset( $prize_settings['page_id'] );
				unset( $prize_settings['settings_name'] );
				$html .= '<table id="cspio-prizes">';
				foreach ( $prize_settings as $k => $v ) {
					if ( strrpos( $k, 'prize_' ) !== false ) {
						if ( ! empty( $v['description'] ) ) {
							$class = '';
							if ( $seed_cspv5_post_result['subscribers'] >= $v['number'] ) {
								$class = 'cspio-reveal';
							}
							$html .= '<tr class="' . $class . '"><td class="cspio-prizes-desc">' . $v['description'] . '</td>';
							if ( $seed_cspv5_post_result['subscribers'] >= $v['number'] ) {
								$html .= '<td class="cspio-prizes-reveal">' . $v['reveal'] . '</td>';
							} else {
								if ( empty( $txt_prize_level_more ) ) {
									$txt_prize_level_more = 'Refer %d more subscribers to claim this.';
								}
								$need  = ( $v['number'] - $seed_cspv5_post_result['subscribers'] );
								$html .= '<td class="cspio-prizes-reveal">' . sprintf( $txt_prize_level_more, $need ) . ' </td>';
							}

							$html .= '</tr>';
						}
					}
				}
				$html .= '</table>';
			}
		}
	} elseif ( '400' == $seed_cspv5_post_result['status'] ) {
		// Validation Error
		$status = '400';
		$html   = '<div id="cspio-alert" class="alert ' . $seed_cspv5_post_result['msg_class'] . '"><ul>';
		foreach ( $errors as $e ) {
			$html .= '<li>' . $e . '</li>';
		}
		$html .= '</ul></div>';
	} elseif ( '500' == $seed_cspv5_post_result['status'] ) {
		// API Error
		$status = '500';
		$html   = $seed_cspv5_post_result['html'];
	}

	if ( $status != '500' ) {
		$html = '<div id="cspio-thankyoumsg">' . $html . '</div>';
	}

	$content = '';
	if ( $status == '200' || $status == '409' ) {
		ob_start();
		include SEEDPROD_PRO_PLUGIN_PATH . 'app/backwards/template/show_share_buttons_ty.php';
		$content = ob_get_clean();
	}
	// Return jsonp results
	$html = $html . $content;

	seedprod_pro_cspv5_legacy_send_jsonp(
		array(
			'status' => $status,
			'html'   => $html,
		)
	);
}




function seed_cspv5_legacy_extensions() {
	$extensions = array(
		SEEDPROD_PRO_PLUGIN_PATH . 'app/backwards/extentions/mailchimp/mailchimp.php',
		SEEDPROD_PRO_PLUGIN_PATH . 'app/backwards/extentions/mailchimp/mailchimp-v3.php',
		SEEDPROD_PRO_PLUGIN_PATH . 'app/backwards/extentions/convertkit/convertkit.php',
		SEEDPROD_PRO_PLUGIN_PATH . 'app/backwards/extentions/activecampaign/activecampaign.php',
		SEEDPROD_PRO_PLUGIN_PATH . 'app/backwards/extentions/database/database.php',
		SEEDPROD_PRO_PLUGIN_PATH . 'app/backwards/extentions/sendy/sendy.php',
		SEEDPROD_PRO_PLUGIN_PATH . 'app/backwards/extentions/mailpoet/mailpoet.php',
		SEEDPROD_PRO_PLUGIN_PATH . 'app/backwards/extentions/madmimi/madmimi.php',
		SEEDPROD_PRO_PLUGIN_PATH . 'app/backwards/extentions/infusionsoft/infusionsoft.php',
		SEEDPROD_PRO_PLUGIN_PATH . 'app/backwards/extentions/icontact/icontact.php',
		SEEDPROD_PRO_PLUGIN_PATH . 'app/backwards/extentions/htmlwebform/htmlwebform.php',
		SEEDPROD_PRO_PLUGIN_PATH . 'app/backwards/extentions/gravityforms/gravityforms.php',
		SEEDPROD_PRO_PLUGIN_PATH . 'app/backwards/extentions/ninjaforms/ninjaforms.php',
		SEEDPROD_PRO_PLUGIN_PATH . 'app/backwards/extentions/followupemails/followupemails.php',
		SEEDPROD_PRO_PLUGIN_PATH . 'app/backwards/extentions/formidable/formidable.php',
		SEEDPROD_PRO_PLUGIN_PATH . 'app/backwards/extentions/getresponse/getresponse.php',
		SEEDPROD_PRO_PLUGIN_PATH . 'app/backwards/extentions/feedburner/feedburner.php',
		SEEDPROD_PRO_PLUGIN_PATH . 'app/backwards/extentions/constantcontact/constantcontact.php',
		SEEDPROD_PRO_PLUGIN_PATH . 'app/backwards/extentions/campaignmonitor/campaignmonitor.php',
		SEEDPROD_PRO_PLUGIN_PATH . 'app/backwards/extentions/aweber/aweber.php',
		SEEDPROD_PRO_PLUGIN_PATH . 'app/backwards/extentions/drip/drip.php',
		SEEDPROD_PRO_PLUGIN_PATH . 'app/backwards/extentions/mymail/mymail.php',
		SEEDPROD_PRO_PLUGIN_PATH . 'app/backwards/extentions/feedblitz/feedblitz.php',
		SEEDPROD_PRO_PLUGIN_PATH . 'app/backwards/extentions/zapier/zapier.php',
	);

	$active_extensions = apply_filters( 'seed_cspv5_active_extensions', $extensions );

	foreach ( $active_extensions as $i ) {
		require_once $i;
	}
} // END seed_cspv5_extensions()

	seed_cspv5_legacy_extensions();






function seed_cspv5_legacy_cu( $rper = null ) {
	if ( ! empty( $rper ) ) {
		$uper = explode( ',', get_option( 'seed_cspv5_per' ) );
		if ( in_array( $rper, $uper ) ) {
			return true;
		} else {
			return false;
		}
	} else {
		$a = get_option( 'seed_cspv5_a' );
		if ( $a ) {
			return true;
		} else {
			return false;
		}
	}
}



	/**
 *  Get IP
 */
function seed_cspv5_legacy_get_ip() {
	$ip = '';
	if ( ! empty( $_SERVER['REMOTE_ADDR'] ) and strlen( $_SERVER['REMOTE_ADDR'] ) > 6 ) {
		$ip = strip_tags( $_SERVER['REMOTE_ADDR'] );
	}//endif
	if ( ! $ip ) {
		$ip = '127.0.0.1';
	}
	return strip_tags( $ip );
}



/**
 * Build the subscriber referral link as a raw URL on this site's own host.
 *
 * With a ref id, use the Referer, else the href field, and add the ref arg. Without one, use
 * the href field, else the current page. Accept only an own-host http or https URL. Drop its
 * query and add the request's lang arg.
 *
 * @return string The raw referral URL.
 */

function seed_cspv5_legacy_ref_link() {
	global $seed_cspv5_post_result;

	if ( ! empty( $seed_cspv5_post_result['ref'] ) ) {
		$ref_url = ! empty( $_SERVER['HTTP_REFERER'] ) ? wp_unslash( $_SERVER['HTTP_REFERER'] ) : '';
		if ( empty( $ref_url ) && ! empty( $_REQUEST['href'] ) ) {
			$ref_url = wp_unslash( $_REQUEST['href'] );
		}
		// Accept only a URL on this site's own host.
		$ref_url  = seedprod_pro_cspv5_legacy_own_host_url( $ref_url );
		$ref_link = add_query_arg( 'ref', $seed_cspv5_post_result['ref'], $ref_url );
	} elseif ( ! empty( $_REQUEST['href'] ) ) {
		$ref_link = seedprod_pro_cspv5_legacy_own_host_url( wp_unslash( $_REQUEST['href'] ) );
	} else {
		$ref_link = seedprod_pro_cspv5_legacy_current_url();
	}

	return esc_url_raw( $ref_link );
}



add_shortcode( 'seed_bypass_url', 'seed_cspv5_legacy_bypass_url' );

function seed_cspv5_legacy_bypass_url( $atts = array() ) {
	if ( ! current_user_can( 'manage_options' ) ) {
		return '';
	}
	$post = get_post();
	if ( $post instanceof WP_Post && ! user_can( (int) $post->post_author, 'manage_options' ) ) {
		return '';
	}

	$seed_cspv5      = get_option( 'seed_cspv5_settings_content' );
	$client_view_url = is_array( $seed_cspv5 ) && ! empty( $seed_cspv5['client_view_url'] ) ? $seed_cspv5['client_view_url'] : '';
	$request_uri     = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '/';

	$output = esc_url(
		add_query_arg(
			array(
				'bypass' => rawurlencode( $client_view_url ),
				'return' => rawurlencode( $request_uri ),
			),
			home_url( '/' )
		)
	);

	return apply_filters( 'seed_cspv5_bypass_url', $output );
}



add_shortcode( 'seed_bypass_link', 'seed_cspv5_legacy_bypass_link' );

function seed_cspv5_legacy_bypass_link( $atts ) {
	$a = shortcode_atts(
		array(
			'text'  => 'Bypass',
			'class' => '',
		),
		$atts
	);

	$url = seed_cspv5_legacy_bypass_url();
	if ( '' === $url ) {
		return '';
	}

	$output = '<a href="' . esc_url( $url ) . '" class="' . esc_attr( $a['class'] ) . '">' . esc_html( $a['text'] ) . '</a>';

	return apply_filters( 'seed_cspv5_bypass_link', $output );
}


add_shortcode( 'seed_contact_form', 'seed_cspv5_legacy_contact_form' );

function seed_cspv5_legacy_contact_form( $atts ) {
	$a = shortcode_atts(
		array(
			'text' => 'Contact Us',
			'icon' => true,
		),
		$atts
	);

	$icon_code = $a['icon'] ? '<i class="fa fa-envelope "></i>' : '';

	$output = '<a href="javascript:void(0)" onclick="javascript:' . "jQuery('#cspio-cf-modal').modal('show');" . '">' . $icon_code . ' ' . esc_html( $a['text'] ) . '</a>';

	return apply_filters( 'seed_cspv5_contact_', $output );
}


		/**
	 * Send Contact Form or return an error.
	 */
function seed_cspv5_legacy_contactform_callback() {
	// The contact JS alerts the status string, so return a readable message.
	if ( ! seedprod_pro_cspv5_legacy_verify_nonce( 'seed_cspv5_legacy_contactform_callback' ) ) {
		seedprod_pro_cspv5_legacy_send_jsonp(
			array(
				'status' => __( 'Your session expired. Please reload the page and try again.', 'seedprod-pro' ),
				'html'   => '',
			)
		);
	}

	// Get the page id. Accept only the active Coming Soon page or a live landing page.
	$page_id = ! empty( $_REQUEST['page_id'] ) ? absint( $_REQUEST['page_id'] ) : 0;
	$page    = seedprod_pro_cspv5_legacy_resolve_page( $page_id );
	if ( empty( $page ) ) {
		seedprod_pro_cspv5_legacy_send_jsonp(
			array(
				'status' => __( 'The message could not be sent.', 'seedprod-pro' ),
				'html'   => '',
			)
		);
	}
		$data['page_id'] = $page_id;

	if ( base64_encode( base64_decode( $page->settings, true ) ) === $page->settings ) {
		$settings = unserialize( base64_decode( $page->settings ) );
	} else {
		$settings = unserialize( $page->settings );
	}

		// Get language info
		$lang_id = '';
	if ( ! empty( $_REQUEST['lang'] ) ) {
		$lang_id = $_REQUEST['lang'];
	}

	if ( ! empty( $lang_id ) ) {
		$lang_settings_name = 'seed_cspv5_' . $page_id . '_language_' . $lang_id;
		$lang_settings      = get_option( $lang_settings_name );
		if ( ! empty( $lang_settings ) ) {
			$lang_settings = maybe_unserialize( $lang_settings );
		}
	}

	if ( ! empty( $lang_settings['txt_contact_form_error'] ) && ! empty( $lang_id ) ) {
		$settings['txt_contact_form_error'] = $lang_settings['txt_contact_form_error'];
	}

		@extract( $settings );

		// Ensure extracted variables are not null for PHP 8+ compatibility
		if ( ! isset( $redirect_url ) ) {
			$redirect_url = '';
		}

		// The contact JS alerts this string, so it must never be empty.
		if ( empty( $txt_contact_form_error ) ) {
			$txt_contact_form_error = __( 'The message could not be sent.', 'seedprod-pro' );
		}

		$html = '';
	if ( ! empty( $cf_confirmation_msg ) ) {
		$html = $cf_confirmation_msg;
	}

	if ( empty( $enable_cf_form ) ) {
		seedprod_pro_cspv5_legacy_send_jsonp(
			array(
				'status' => $txt_contact_form_error,
				'html'   => $html,
			)
		);
	}

		// Verify reCAPTCHA before the mail. Accept the message only when reCAPTCHA confirms success.
	if ( ! empty( $enable_recaptcha ) && ! empty( $recaptcha_site_key ) && ! empty( $recaptcha_secret_key ) ) {
		$captcha_token = isset( $_REQUEST['g-recaptcha-response'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['g-recaptcha-response'] ) ) : '';
		$response      = wp_remote_post(
			'https://www.google.com/recaptcha/api/siteverify',
			array(
				'body' => array(
					'secret'   => $recaptcha_secret_key,
					'response' => $captcha_token,
				),
			)
		);

		$body = is_wp_error( $response ) ? null : json_decode( wp_remote_retrieve_body( $response ) );
		if ( empty( $body ) || empty( $body->success ) ) {
			seedprod_pro_cspv5_legacy_send_jsonp(
				array(
					'status' => 'Invalid Recaptcha',
					'html'   => $html,
				)
			);
		}
	}

		$email     = sanitize_email( wp_unslash( isset( $_REQUEST['cspio-cf-email'] ) ? $_REQUEST['cspio-cf-email'] : '' ) );
		$msg       = sanitize_textarea_field( wp_unslash( isset( $_REQUEST['cspio-cf-msg'] ) ? $_REQUEST['cspio-cf-msg'] : '' ) );
		$msg       = $email . PHP_EOL . PHP_EOL . $msg;
		$headers[] = 'Reply-To: ' . $email;
	if ( is_email( $email ) && ! empty( $msg ) ) {
		// Rate limit a valid message only, so an invalid email does not spend the budget.
		if ( ! seedprod_pro_cspv5_legacy_rate_ok( 'contact' ) ) {
			seedprod_pro_cspv5_legacy_send_jsonp(
				array(
					'status' => $txt_contact_form_error,
					'html'   => $html,
				)
			);
		}
		if ( empty( $cf_form_emails ) ) {
			$emails = get_option( 'admin_email' );
		} else {
			$emails = $cf_form_emails;
		}
		$mresult = wp_mail( $emails, '[' . home_url() . __( '] New Contact Form Message', 'seedprod' ), $msg, $headers );
		if ( false === $mresult ) {
			// Send HTTP 500 so the contact JS shows its mail-failure message.
			seedprod_pro_cspv5_legacy_send_jsonp(
				array(
					'status' => '500',
					'html'   => $html,
				),
				500
			);
		}
		$status = '200';
	} else {
		$status = $txt_contact_form_error;
	}

		seedprod_pro_cspv5_legacy_send_jsonp(
			array(
				'status' => $status,
				'html'   => $html,
			)
		);
}

/**
 * Update cookie length for bypass url
 */
function seed_cspv5_legacy_change_wp_cookie_logout( $expirein ) {
	global $seed_cspv5_bypass_expires;
	if ( ! empty( $seed_cspv5_bypass_expires ) ) {
		return $seed_cspv5_bypass_expires; // Modify the exire cookie
	} else {
		return $expirein;
	}
}


