<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.WP.I18n.TextDomainMismatch, WordPress.NamingConventions.PrefixAllGlobals -- Legacy backward compatibility code.
if ( ! empty( $settings->enable_cf_form ) ) :
	?>
<div id="cspio-contact-form">
	<?php
	// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Shortcode output handles its own escaping.
	echo do_shortcode( '[seed_contact_form text="' . esc_attr( $settings->txt_contact_us ) . '"]' );
	?>
</div>
<?php endif; ?>
