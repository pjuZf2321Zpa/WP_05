<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.WP.I18n.TextDomainMismatch, WordPress.NamingConventions.PrefixAllGlobals -- Legacy backward compatibility code.
if ( ! empty( $settings->logo ) ) {
	?>
	<img id="cspio-logo" src="<?php echo esc_url( $settings->logo ); ?>">
<?php } ?>
