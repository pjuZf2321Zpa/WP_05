<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.WP.I18n.TextDomainMismatch, WordPress.NamingConventions.PrefixAllGlobals -- Legacy backward compatibility code.
?>
<h1 id="cspio-headline"><?php echo wp_kses_post( $settings->headline ); ?></h1>
