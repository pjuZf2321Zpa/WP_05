<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Get Theme Template Parts
 *
 * @return array Template part names.
 */
function seedprod_pro_get_template_parts() {

	global $wpdb;

	$tablename      = $wpdb->prefix . 'posts';
	$meta_tablename = $wpdb->prefix . 'postmeta';

	$sql  = "SELECT * FROM $tablename p LEFT JOIN $meta_tablename pm ON (pm.post_id = p.ID)";
	$sql .= " WHERE 1 = 1 AND post_type = 'seedprod' AND meta_key = '_seedprod_page_template_type' AND (meta_value = 'part' OR meta_value = 'header' OR meta_value = 'footer')";
	$sql .= " AND  (post_status = 'publish' OR post_status = 'draft') ";

	$landing_parts = $wpdb->get_results( $sql ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared

	return ! empty( $landing_parts ) ? $landing_parts : array();
}
add_action( 'wp_ajax_seedprod_pro_get_template_parts_result', 'seedprod_pro_get_template_parts_result' );


/**
 * Get Theme Template Parts Result
 *
 * @return void
 */
function seedprod_pro_get_template_parts_result() {

	if ( check_ajax_referer( 'seedprod_nonce' ) ) {
		if ( ! current_user_can( apply_filters( 'seedprod_builder_preview_render_capability', 'edit_others_posts' ) ) ) {
			wp_send_json_error();
		}
		$id = absint( filter_input( INPUT_GET, 'parts_id' ) );

		if ( empty( $id ) ) {
			echo '';
			wp_die();
		}

		$post = get_post( $id );
		if ( 'seedprod' === $post->post_type ) {
			$content = $post->post_content;

			// Replace shortcodes that have preview disabled with placeholders.
			if ( ! empty( $post->post_content_filtered ) ) {
				$disabled_shortcodes = seedprod_pro_get_disabled_preview_shortcodes( $post->post_content_filtered );
				foreach ( $disabled_shortcodes as $entry ) {
					$block_id       = $entry['id'];
					$shortcode_text = $entry['shortcode'];
					$placeholder    = '<div class="sp-shortcode-wrapper">'
						. '<pre class="sp-font-sans sp-text-sm sp-font-bold sp-pb-1">'
						. esc_html__( 'Shortcode', 'seedprod-pro' ) . '</pre>'
						. '<div>' . str_replace( array( '[', ']' ), array( '&#91;', '&#93;' ), esc_html( $shortcode_text ) ) . '</div>'
						. '<div class="sp-font-sans sp-text-xs sp-pt-1">'
						. esc_html__( '(This shortcode will be rendered on the live preview.)', 'seedprod-pro' )
						. '</div></div>';

					// Target only the shortcode within its specific block container.
					$block_marker = 'sp-shortcode-block-' . $block_id;
					$block_pos    = strpos( $content, $block_marker );
					if ( false === $block_pos ) {
						continue;
					}
					$shortcode_pos = strpos( $content, $shortcode_text, $block_pos );
					if ( false === $shortcode_pos ) {
						continue;
					}
					$content = substr_replace( $content, $placeholder, $shortcode_pos, strlen( $shortcode_text ) );
				}
			}

			// Do NOT use get_the_content, breaks system.
			echo do_shortcode( $content );
		}
		wp_die();
	}
}


/**
 * Get shortcode strings from blocks that have render_shortcode_preview disabled.
 *
 * @param string $json_settings The post_content_filtered JSON string.
 * @return array List of arrays with 'id' and 'shortcode' keys for blocks with preview disabled.
 */
function seedprod_pro_get_disabled_preview_shortcodes( $json_settings ) {
	$settings = json_decode( $json_settings, true );
	if ( empty( $settings['document']['sections'] ) || ! is_array( $settings['document']['sections'] ) ) {
		return array();
	}

	$disabled = array();
	foreach ( $settings['document']['sections'] as $section ) {
		if ( empty( $section['rows'] ) || ! is_array( $section['rows'] ) ) {
			continue;
		}
		foreach ( $section['rows'] as $row ) {
			if ( empty( $row['cols'] ) || ! is_array( $row['cols'] ) ) {
				continue;
			}
			foreach ( $row['cols'] as $col ) {
				if ( empty( $col['blocks'] ) || ! is_array( $col['blocks'] ) ) {
					continue;
				}
				foreach ( $col['blocks'] as $block ) {
					if (
						isset( $block['type'] ) && 'shortcode' === $block['type']
						&& isset( $block['settings']['render_shortcode_preview'] )
						&& empty( $block['settings']['render_shortcode_preview'] )
						&& ! empty( $block['settings']['shortcode'] )
					) {
						$disabled[] = array(
							'id'        => $block['id'],
							'shortcode' => $block['settings']['shortcode'],
						);
					}
				}
			}
		}
	}

	return $disabled;
}

add_action( 'wp_ajax_seedprod_pro_save_global_template_utility_section', 'seedprod_pro_save_global_template_utility_section' );

/**
 * Save a section as a template part.
 * Creates a new seedprod post with template type 'part'.
 *
 * @return void
 */
function seedprod_pro_save_global_template_utility_section() {
	// Security check.
	if ( ! check_ajax_referer( 'seedprod_nonce', '_wpnonce', false ) ) {
		wp_send_json_error( array( 'error' => __( 'Invalid security token.', 'seedprod-pro' ) ) );
	}

	if ( ! current_user_can( apply_filters( 'seedprod_themetemplate_capability', 'edit_others_posts' ) ) ) {
		wp_send_json_error( array( 'error' => __( 'Permission denied.', 'seedprod-pro' ) ) );
	}

	if ( ! current_user_can( 'unfiltered_html' ) ) {
		wp_send_json_error( array( 'error' => __( 'You need the unfiltered_html capability to save a template part.', 'seedprod-pro' ) ) );
	}

	$name = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
	$code = isset( $_POST['code'] ) ? wp_unslash( $_POST['code'] ) : '';
	$html = isset( $_POST['html'] ) ? wp_unslash( $_POST['html'] ) : '';

	if ( empty( $name ) ) {
		wp_send_json_error( array( 'error' => __( 'Template part name is required.', 'seedprod-pro' ) ) );
	}

	if ( empty( $code ) ) {
		wp_send_json_error( array( 'error' => __( 'Section data is required.', 'seedprod-pro' ) ) );
	}

	// Validate HTML is not empty when provided (required for template parts, optional for dev mode).
	if ( isset( $_POST['html'] ) && empty( $html ) ) {
		wp_send_json_error( array( 'error' => __( 'Section HTML could not be extracted. Please try saving the page first, then try again.', 'seedprod-pro' ) ) );
	}

	// Strip builder UI elements that should never be stored in template part HTML.
	// The .seedprod-modal-mask element (save-as-template-part modal) may still be present
	// in the client-captured HTML due to Vue's CSS transition delay on v-if removal.
	// Even when invisible (opacity: 0 during leave transition), it has position:fixed and
	// covers the full viewport, blocking all interaction when rendered in the builder.
	if ( ! empty( $html ) ) {
		require_once SEEDPROD_PRO_PLUGIN_PATH . 'app/includes/simple_html_dom.php';
		$phtml = seedprod_str_get_html( $html );
		if ( false !== $phtml ) {
			foreach ( $phtml->find( '.seedprod-modal-mask' ) as $modal_el ) {
				$modal_el->outertext = '';
			}
			$html = $phtml->save();
			$phtml->clear();
			unset( $phtml );
		}
	}

	// Load base page settings.
	require_once SEEDPROD_PRO_PLUGIN_PATH . 'resources/data-templates/basic-page.php';
	$settings = json_decode( $seedprod_basic_lpage );

	$settings->is_new      = true;
	$settings->page_type   = 'part';
	$settings->post_title  = $name;
	$settings->post_status = 'publish';
	$settings->template_id = 71; // Blank template.

	// Parse the section data and add to settings.
	$section_data = json_decode( $code );
	if ( $section_data ) {
		$settings->document           = new stdClass();
		$settings->document->sections = array( $section_data );
	}

	$settings_json = wp_json_encode( $settings );

	// Create the template part post.
	// post_content stores the rendered HTML for display.
	// post_content_filtered stores the JSON settings for editing.
	$post_data = array(
		'post_title'            => $name,
		'post_status'           => 'publish',
		'post_type'             => 'seedprod',
		'post_content'          => $html,
		'post_content_filtered' => $settings_json,
		'comment_status'        => 'closed',
		'ping_status'           => 'closed',
		'meta_input'            => array(
			'_seedprod_page'               => true,
			'_seedprod_page_uuid'          => wp_generate_uuid4(),
			'_seedprod_page_template_type' => 'part',
			'_seedprod_is_theme_template'  => true,
		),
	);

	$template_id = wp_insert_post( $post_data, true );

	if ( is_wp_error( $template_id ) ) {
		wp_send_json_error( array( 'error' => $template_id->get_error_message() ) );
	}

	// Reinsert content because wp_insert_post screws up HTML/JSON with quotes.
	// This follows the exact pattern from export-import-theme-functions.php lines 78-96.
	global $wpdb;
	$tablename = $wpdb->prefix . 'posts';
	$sql       = "UPDATE $tablename SET post_content_filtered = %s, post_content = %s WHERE ID = %d";
	$safe_sql  = $wpdb->prepare( $sql, $settings_json, $html, $template_id ); // phpcs:ignore
	$wpdb->query( $safe_sql ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared

	wp_send_json_success(
		array(
			'template_id' => $template_id,
			'name'        => $name,
		)
	);
}

add_action( 'wp_ajax_seedprod_pro_get_template_parts_list', 'seedprod_pro_get_template_parts_list' );

/**
 * Get template parts list as JSON for refreshing the dropdown.
 *
 * @return void
 */
function seedprod_pro_get_template_parts_list() {
	if ( ! check_ajax_referer( 'seedprod_nonce', '_wpnonce', false ) ) {
		wp_send_json_error( __( 'Invalid security token.', 'seedprod-pro' ) );
	}

	if ( ! current_user_can( apply_filters( 'seedprod_builder_preview_render_capability', 'edit_others_posts' ) ) ) {
		wp_send_json_error( __( 'Permission denied.', 'seedprod-pro' ) );
	}

	$template_parts = array();
	$theme_parts    = seedprod_pro_get_template_parts();

	foreach ( $theme_parts as $tpart ) {
		$template_parts[ $tpart->ID ] = $tpart->post_title;
	}

	wp_send_json_success( $template_parts );
}
