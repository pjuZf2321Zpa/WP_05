<?php
/**
 * Render 404 pages.
 *
 * @package SeedProd
 * @subpackage SeedProd/app
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:ignore WordPress.Files.FileName -- Legacy filename retained for compatibility.
// phpcs:ignore Squiz.Commenting.FileComment

/**
 * Handles rendering of custom 404 pages.
 */
class SeedProd_Pro_Render_404 {
	/**
	 * Instance of this class.
	 *
	 * @var      object
	 */
	protected static $instance = null;

	/**
	 * 404 Page Path.
	 *
	 * @var      string
	 */
	private $path = null;

	/**
	 * Constructor setting up default instance of the class.
	 */
	public function __construct() {

		if ( ! seedprod_pro_cu( 'none' ) ) {
			$ts = get_option( 'seedprod_settings' );
			if ( ! empty( $ts ) ) {
				$seedprod_settings = json_decode( $ts, true );
				if ( ! empty( $seedprod_settings ) ) {
					extract( $seedprod_settings ); // phpcs:ignore WordPress.PHP.DontExtract.extract_extract
				}
			} else {
				return;
			}

			// Actions and filters if the landing page is active or being previewed.
			if ( ! empty( $seedprod_settings['enable_404_mode'] ) ) {
				if ( function_exists( 'bp_is_active' ) ) {
					add_action( 'template_redirect', array( &$this, 'render_404_page' ), 9 );
				} else {
					$priority = 10;

					add_action( 'template_redirect', array( &$this, 'render_404_page' ), $priority );
				}
			}
		}
	}

	/**
	 * Return an instance of this class.
	 */
	public static function get_instance() {

		// If the single instance hasn't been set, set it now.
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}



	/**
	 * Display the coming soon/maintenance mode page.
	 */
	public function render_404_page() {
		// Bail if not a 404 page.
		if ( ! is_404() ) {
			return false;
		}

		// Top level settings.
		$ts                = get_option( 'seedprod_settings' );
		$seedprod_settings = json_decode( $ts );

		// Page info.
		$page_id = 0;

		// Get 404 page ID.
		if ( ! empty( $seedprod_settings->enable_404_mode ) ) {
			$page_id = get_option( 'seedprod_404_page_id' );
		} else {
			wp_die( esc_html__( 'Your 404 page needs to be setup.', 'seedprod-pro' ) );
		}

		// Get page.
		global $wpdb;
		$tablename = $wpdb->prefix . 'posts';
		$sql       = "SELECT * FROM $tablename WHERE id= %d";
		$safe_sql  = $wpdb->prepare( $sql, absint( $page_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		$page      = $wpdb->get_row( $safe_sql ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared

		if ( empty( $page ) ) {
			wp_die( 'Please set up your custom 404 page in SeedProd.' );
		}

		$settings = json_decode( $page->post_content_filtered );

		// Redirect mode.
		$enable_redirect_mode = false;
		$redirect_url         = isset( $settings->redirect_url ) ? $settings->redirect_url : '';
		if ( ! empty( $settings->redirect_mode ) ) {
			$enable_redirect_mode = true;
		}
		if ( empty( $redirect_url ) ) {
			$enable_redirect_mode = false;
		}
		if ( ! empty( $enable_redirect_mode ) ) {
			if ( ! empty( $redirect_url ) ) {
				wp_safe_redirect( $redirect_url, 301 );
				exit;
			}
		}

		require_once SEEDPROD_PRO_PLUGIN_PATH . 'resources/views/seedprod-preview.php';

		exit();
	}
}
