<?php
/**
 * Template-type and content-type label map.
 *
 * @package SeedProd
 * @subpackage SeedProd/app/includes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'seedprod_pro_get_template_type_labels' ) ) {
	/**
	 * Return the template-type and content-type label map.
	 *
	 * @since 6.21.0
	 *
	 * @return array<string,string>
	 */
	function seedprod_pro_get_template_type_labels() {
		static $labels = null;

		if ( null !== $labels ) {
			return $labels;
		}

		$labels = array(
			'header'              => __( 'Header', 'seedprod-pro' ),
			'footer'              => __( 'Footer', 'seedprod-pro' ),
			'part'                => __( 'Template Part', 'seedprod-pro' ),
			'sidebar'             => __( 'Sidebar', 'seedprod-pro' ),
			'section'             => __( 'Section', 'seedprod-pro' ),
			'single'              => __( 'Single', 'seedprod-pro' ),
			'archive'             => __( 'Archive Page', 'seedprod-pro' ),
			'single_post'         => __( 'Single Post', 'seedprod-pro' ),
			'single_page'         => __( 'Single Page', 'seedprod-pro' ),
			'single_product'      => __( 'Single Product', 'seedprod-pro' ),
			'archive_product'     => __( 'Product Archive', 'seedprod-pro' ),
			'woocommerce_single'  => __( 'Single Product', 'seedprod-pro' ),
			'woocommerce_archive' => __( 'Product Archive', 'seedprod-pro' ),
			'search'              => __( 'Search Results', 'seedprod-pro' ),
			'author'              => __( 'Author Page', 'seedprod-pro' ),
			'404'                 => __( '404 Page', 'seedprod-pro' ),
			'home'                => __( 'Home Page', 'seedprod-pro' ),
			'blog'                => __( 'Blog Page', 'seedprod-pro' ),
			'css'                 => __( 'Global CSS', 'seedprod-pro' ),
			'lp'                  => __( 'Landing Page', 'seedprod-pro' ),
			'cs'                  => __( 'Coming Soon', 'seedprod-pro' ),
			'mm'                  => __( 'Maintenance', 'seedprod-pro' ),
			'p404'                => __( '404 Page', 'seedprod-pro' ),
			'loginp'              => __( 'Login Page', 'seedprod-pro' ),
			'page'                => __( 'Page', 'seedprod-pro' ),
			'post'                => __( 'Post', 'seedprod-pro' ),
		);

		$filtered = apply_filters( 'seedprod_pro_template_type_labels', $labels );

		if ( is_array( $filtered ) ) {
			$labels = $filtered;
		}

		return $labels;
	}
}

if ( ! function_exists( 'seedprod_pro_resolve_effective_template_type' ) ) {
	/**
	 * Derive a specific template-type slug from theme-template conditions
	 * when the stored type is the generic 'page'. Non-'page' types are
	 * returned unchanged.
	 *
	 * @since 6.21.0
	 *
	 * @param string             $type       Stored template type meta.
	 * @param string|array|object $conditions Conditions JSON, array, or stdClass.
	 * @return string Effective type slug for the canonical label map.
	 */
	function seedprod_pro_resolve_effective_template_type( $type, $conditions ) {
		if ( 'page' !== $type ) {
			return $type;
		}

		if ( is_string( $conditions ) ) {
			$conditions = json_decode( $conditions );
		}

		if ( ! is_array( $conditions ) && ! is_object( $conditions ) ) {
			return $type;
		}

		$map = array(
			'is_single'            => 'single_post',
			'is_singular'          => 'single',
			'is_page'              => 'single_page',
			'is_archive'           => 'archive',
			'is_date'              => 'archive',
			'is_category'          => 'archive',
			'is_tag'               => 'archive',
			'is_tax'               => 'archive',
			'is_post_type_archive' => 'archive',
			'is_home'              => 'blog',
			'is_front_page'        => 'home',
			'is_search'            => 'search',
			'is_404'               => '404',
			'is_author'            => 'author',
			'is_product'           => 'single_product',
			'is_shop'              => 'archive_product',
			'is_product_category'  => 'archive_product',
			'is_product_tag'       => 'archive_product',
		);

		foreach ( (array) $conditions as $condition ) {
			$mode = is_object( $condition ) ? ( isset( $condition->condition ) ? $condition->condition : 'include' ) : ( isset( $condition['condition'] ) ? $condition['condition'] : 'include' );
			if ( 'exclude' === $mode ) {
				continue;
			}
			$tag = is_object( $condition ) ? ( isset( $condition->type ) ? $condition->type : '' ) : ( isset( $condition['type'] ) ? $condition['type'] : '' );
			if ( empty( $tag ) ) {
				continue;
			}
			$tag = strtolower( preg_replace( '/\(.*$/', '', $tag ) );
			if ( isset( $map[ $tag ] ) ) {
				return $map[ $tag ];
			}
		}

		return $type;
	}
}

if ( ! function_exists( 'seedprod_pro_normalize_conditions_json' ) ) {
	/**
	 * Normalize the theme-template conditions meta value to a JSON string.
	 *
	 * External tools can store this meta as an array or object; passing a
	 * non-string into json_decode() is fatal on PHP 8.
	 *
	 * @since 6.21.0
	 *
	 * @param mixed $conditions Raw conditions meta value.
	 * @return string JSON-encoded conditions, or an empty string when the
	 *                value cannot be represented as JSON.
	 */
	function seedprod_pro_normalize_conditions_json( $conditions ) {
		if ( is_string( $conditions ) ) {
			return $conditions;
		}

		if ( is_array( $conditions ) || is_object( $conditions ) ) {
			$encoded = wp_json_encode( $conditions );
			return false === $encoded ? '' : $encoded;
		}

		return '';
	}
}
