<?php
/**
 * SeedProd Abilities API Integration
 *
 * Registers SeedProd capabilities with the WordPress Abilities API (WP 6.9+)
 * for discoverability by automation tools, AI agents, and third-party integrations.
 *
 * @package    SeedProd
 * @subpackage SeedProd/includes
 * @since      6.20.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class SeedProd_Pro_Abilities
 *
 * Handles registration of SeedProd abilities with the WordPress Abilities API.
 */
class SeedProd_Pro_Abilities {

	/**
	 * Initialize the abilities registration.
	 */
	public function __construct() {
		// Registration must stay on these hooks: they only fire on WP 6.9+, so the
		// wp_register_ability*() calls below never run on older WordPress versions.
		add_action( 'wp_abilities_api_categories_init', array( $this, 'register_category' ) );
		add_action( 'wp_abilities_api_init', array( $this, 'register_abilities' ) );
	}

	/**
	 * Register the SeedProd category.
	 */
	public function register_category() {
		wp_register_ability_category(
			'seedprod',
			array(
				'label'       => __( 'SeedProd', 'seedprod-pro' ),
				'description' => __( 'SeedProd page builder and website customization operations.', 'seedprod-pro' ),
			)
		);
	}

	/**
	 * Register all SeedProd abilities.
	 */
	public function register_abilities() {
		$this->register_get_status();
		$this->register_toggle_coming_soon();
		$this->register_toggle_maintenance();
		$this->register_list_pages();
		$this->register_save_page();
		$this->register_get_page();

		
		$this->register_toggle_theme();
		$this->register_get_global_css();
		$this->register_save_global_css();
		$this->register_import_theme();
		$this->register_activate_license();
		
	}

	// -------------------------------------------------------------------------
	// Status
	// -------------------------------------------------------------------------

	/**
	 * Register the get-status ability.
	 */
	private function register_get_status() {
		wp_register_ability(
			'seedprod/get-status',
			array(
				'label'        => __( 'Get SeedProd Status', 'seedprod-pro' ),
				'description'  => __( 'Get the current status of SeedProd including coming soon mode, maintenance mode, theme builder status, and license information.', 'seedprod-pro' ),
				'category'     => 'seedprod',
				'input_schema' => array(
					'type'       => array( 'object', 'null' ),
					// Cast to stdClass so wp_json_encode emits {} not [].
					'properties' => (object) array(),
				),
				'output_schema' => array(
					'type'       => 'object',
					'properties' => array(
						'coming_soon_enabled' => array(
							'type'        => 'boolean',
							'description' => __( 'Whether coming soon mode is enabled.', 'seedprod-pro' ),
						),
						'coming_soon_page_id' => array(
							'type'        => 'integer',
							'description' => __( 'The ID of the coming soon page.', 'seedprod-pro' ),
						),
						'maintenance_enabled' => array(
							'type'        => 'boolean',
							'description' => __( 'Whether maintenance mode is enabled.', 'seedprod-pro' ),
						),
						'maintenance_page_id' => array(
							'type'        => 'integer',
							'description' => __( 'The ID of the maintenance mode page.', 'seedprod-pro' ),
						),
						'login_enabled' => array(
							'type'        => 'boolean',
							'description' => __( 'Whether the custom login mode is enabled (Pro). When on, SeedProd serves the bound login page instead of wp-login.', 'seedprod-pro' ),
						),
						'login_page_id' => array(
							'type'        => 'integer',
							'description' => __( 'The ID of the SeedProd login page (Pro).', 'seedprod-pro' ),
						),
						'404_enabled' => array(
							'type'        => 'boolean',
							'description' => __( 'Whether the custom 404 mode is enabled (Pro). When on, SeedProd serves the bound 404 page instead of the WordPress default.', 'seedprod-pro' ),
						),
						'404_page_id' => array(
							'type'        => 'integer',
							'description' => __( 'The ID of the SeedProd 404 page (Pro).', 'seedprod-pro' ),
						),
						'theme_enabled' => array(
							'type'        => 'boolean',
							'description' => __( 'Whether the SeedProd theme builder is enabled.', 'seedprod-pro' ),
						),
						'license_active' => array(
							'type'        => 'boolean',
							'description' => __( 'Whether a valid license is active.', 'seedprod-pro' ),
						),
						'license_type' => array(
							'type'        => 'string',
							'description' => __( 'The type of license (e.g., Basic, Plus, Pro, Elite).', 'seedprod-pro' ),
						),
						'version' => array(
							'type'        => 'string',
							'description' => __( 'The current SeedProd plugin version.', 'seedprod-pro' ),
						),
						'build' => array(
							'type'        => 'string',
							'description' => __( 'The build type (pro or lite).', 'seedprod-pro' ),
						),
					),
				),
				'execute_callback'    => array( $this, 'execute_get_status' ),
				'permission_callback' => function () {
					return current_user_can( 'manage_options' );
				},
				'meta' => array(
					'show_in_rest' => true,
					'annotations'  => array(
						'readonly'   => true,
						'idempotent' => true,
					),
				),
			)
		);
	}

	/**
	 * Execute the get-status ability.
	 *
	 * @param array $input The input parameters (unused).
	 * @return array The current SeedProd status.
	 */
	public function execute_get_status( $input ) {
		$settings = $this->get_settings();

		$theme_enabled = ! empty( $settings['enable_seedprod_theme'] )
			|| ! empty( get_option( 'seedprod_theme_enabled', false ) );

		return array(
			'coming_soon_enabled'  => ! empty( $settings['enable_coming_soon_mode'] ),
			'coming_soon_page_id'  => absint( get_option( 'seedprod_coming_soon_page_id', 0 ) ),
			'maintenance_enabled'  => ! empty( $settings['enable_maintenance_mode'] ),
			'maintenance_page_id'  => absint( get_option( 'seedprod_maintenance_mode_page_id', 0 ) ),
			'login_enabled'        => ! empty( $settings['enable_login_mode'] ),
			'login_page_id'        => absint( get_option( 'seedprod_login_page_id', 0 ) ),
			'404_enabled'          => ! empty( $settings['enable_404_mode'] ),
			'404_page_id'          => absint( get_option( 'seedprod_404_page_id', 0 ) ),
			'theme_enabled'        => $theme_enabled,
			'license_active'       => (bool) get_option( 'seedprod_a', false ),
			'license_type'         => get_option( 'seedprod_license_name', '' ),
			'version'              => SEEDPROD_PRO_VERSION,
			'build'                => SEEDPROD_PRO_BUILD,
		);
	}

	// -------------------------------------------------------------------------
	// Mode toggles
	// -------------------------------------------------------------------------

	/**
	 * Register the toggle-coming-soon ability.
	 */
	private function register_toggle_coming_soon() {
		wp_register_ability(
			'seedprod/toggle-coming-soon',
			array(
				'label'        => __( 'Toggle Coming Soon Mode', 'seedprod-pro' ),
				'description'  => __( 'Enable or disable the SeedProd coming soon page. When enabled, non-logged-in users see the coming soon page instead of the live site. Automatically disables maintenance mode (they are mutually exclusive).', 'seedprod-pro' ),
				'category'     => 'seedprod',
				'input_schema' => array(
					'type'       => 'object',
					'properties' => array(
						'enabled' => array(
							'type'        => 'boolean',
							'description' => __( 'Whether to enable (true) or disable (false) coming soon mode.', 'seedprod-pro' ),
						),
						'page_id' => array(
							'type'        => 'integer',
							'description' => __( 'Optional. The ID of the SeedProd page to use. If omitted, uses the existing page.', 'seedprod-pro' ),
						),
					),
					'required' => array( 'enabled' ),
				),
				'output_schema' => array(
					'type'       => 'object',
					'properties' => array(
						'success' => array( 'type' => 'boolean' ),
						'enabled' => array( 'type' => 'boolean' ),
						'page_id' => array( 'type' => 'integer' ),
					),
				),
				'execute_callback'    => array( $this, 'execute_toggle_coming_soon' ),
				'permission_callback' => function () {
					return current_user_can( 'manage_options' );
				},
				'meta' => array(
					'show_in_rest' => true,
					'annotations'  => array(
						'idempotent' => true,
					),
				),
			)
		);
	}

	/**
	 * Execute the toggle-coming-soon ability.
	 *
	 * @param array $input The input parameters.
	 * @return array|WP_Error The result or error.
	 */
	public function execute_toggle_coming_soon( $input ) {
		$enabled = isset( $input['enabled'] ) ? (bool) $input['enabled'] : false;
		$page_id = isset( $input['page_id'] ) ? absint( $input['page_id'] ) : null;

		$settings = $this->get_settings();

		if ( $enabled && ! $page_id ) {
			$page_id = absint( get_option( 'seedprod_coming_soon_page_id', 0 ) );
			if ( ! $page_id ) {
				return new WP_Error(
					'seedprod_no_page',
					__( 'No coming soon page exists. Create one with seedprod/save-page first, then pass its ID.', 'seedprod-pro' )
				);
			}
		}

		// Mutually exclusive with maintenance mode.
		if ( $enabled ) {
			$settings['enable_maintenance_mode'] = false;
		}

		$settings['enable_coming_soon_mode'] = $enabled;

		if ( $page_id ) {
			update_option( 'seedprod_coming_soon_page_id', $page_id );
		}

		update_option( 'seedprod_settings', wp_json_encode( $settings ) );

		return array(
			'success' => true,
			'enabled' => $enabled,
			'page_id' => $page_id ? $page_id : absint( get_option( 'seedprod_coming_soon_page_id', 0 ) ),
		);
	}

	/**
	 * Register the toggle-maintenance ability.
	 */
	private function register_toggle_maintenance() {
		wp_register_ability(
			'seedprod/toggle-maintenance',
			array(
				'label'        => __( 'Toggle Maintenance Mode', 'seedprod-pro' ),
				'description'  => __( 'Enable or disable the SeedProd maintenance mode page. When enabled, non-logged-in users see the maintenance page and search engines receive a 503 status code. Automatically disables coming soon mode (they are mutually exclusive).', 'seedprod-pro' ),
				'category'     => 'seedprod',
				'input_schema' => array(
					'type'       => 'object',
					'properties' => array(
						'enabled' => array(
							'type'        => 'boolean',
							'description' => __( 'Whether to enable (true) or disable (false) maintenance mode.', 'seedprod-pro' ),
						),
						'page_id' => array(
							'type'        => 'integer',
							'description' => __( 'Optional. The ID of the SeedProd page to use. If omitted, uses the existing page.', 'seedprod-pro' ),
						),
					),
					'required' => array( 'enabled' ),
				),
				'output_schema' => array(
					'type'       => 'object',
					'properties' => array(
						'success' => array( 'type' => 'boolean' ),
						'enabled' => array( 'type' => 'boolean' ),
						'page_id' => array( 'type' => 'integer' ),
					),
				),
				'execute_callback'    => array( $this, 'execute_toggle_maintenance' ),
				'permission_callback' => function () {
					return current_user_can( 'manage_options' );
				},
				'meta' => array(
					'show_in_rest' => true,
					'annotations'  => array(
						'idempotent' => true,
					),
				),
			)
		);
	}

	/**
	 * Execute the toggle-maintenance ability.
	 *
	 * @param array $input The input parameters.
	 * @return array|WP_Error The result or error.
	 */
	public function execute_toggle_maintenance( $input ) {
		$enabled = isset( $input['enabled'] ) ? (bool) $input['enabled'] : false;
		$page_id = isset( $input['page_id'] ) ? absint( $input['page_id'] ) : null;

		$settings = $this->get_settings();

		if ( $enabled && ! $page_id ) {
			$page_id = absint( get_option( 'seedprod_maintenance_mode_page_id', 0 ) );
			if ( ! $page_id ) {
				return new WP_Error(
					'seedprod_no_page',
					__( 'No maintenance mode page exists. Create one with seedprod/save-page first, then pass its ID.', 'seedprod-pro' )
				);
			}
		}

		// Mutually exclusive with coming soon mode.
		if ( $enabled ) {
			$settings['enable_coming_soon_mode'] = false;
		}

		$settings['enable_maintenance_mode'] = $enabled;

		if ( $page_id ) {
			update_option( 'seedprod_maintenance_mode_page_id', $page_id );
		}

		update_option( 'seedprod_settings', wp_json_encode( $settings ) );

		return array(
			'success' => true,
			'enabled' => $enabled,
			'page_id' => $page_id ? $page_id : absint( get_option( 'seedprod_maintenance_mode_page_id', 0 ) ),
		);
	}

	// -------------------------------------------------------------------------
	// Pages
	// -------------------------------------------------------------------------

	/**
	 * Register the list-pages ability.
	 */
	private function register_list_pages() {
		// strval cast: PHP stores numeric-string keys as ints (e.g. '404' => 404),
		// so array_keys() returns int 404 here. JSON Schema rejects mixed-type
		// enums; coerce back to strings.
		$type_enum   = array_map( 'strval', array_keys( $this->get_save_page_type_map() ) );
		$type_enum[] = 'all';

		wp_register_ability(
			'seedprod/list-pages',
			array(
				'label'        => __( 'List SeedProd Pages', 'seedprod-pro' ),
				'description'  => __( 'Get a list of all SeedProd pages (landing pages, mode pages, and theme templates) with their IDs, titles, types, and status.', 'seedprod-pro' ),
				'category'     => 'seedprod',
				'input_schema' => array(
					'type'       => array( 'object', 'null' ),
					'properties' => array(
						'type' => array(
							'type'        => 'string',
							'enum'        => $type_enum,
							'description' => __( 'Filter by page type. Uses the same long-form values as save-page (landing-page, coming-soon, maintenance, ...). Default: all', 'seedprod-pro' ),
						),
						'status' => array(
							'type'        => 'string',
							'enum'        => array( 'publish', 'draft', 'all' ),
							'description' => __( 'Filter by status. Default: all', 'seedprod-pro' ),
						),
					),
				),
				'output_schema' => array(
					'type'  => 'array',
					'items' => array(
						'type'       => 'object',
						'properties' => array(
							'id'       => array( 'type' => 'integer' ),
							'title'    => array( 'type' => 'string' ),
							'type'     => array( 'type' => 'string' ),
							'status'   => array( 'type' => 'string' ),
							'edit_url' => array( 'type' => 'string' ),
						),
					),
				),
				'execute_callback'    => array( $this, 'execute_list_pages' ),
				'permission_callback' => function () {
					return current_user_can( 'edit_pages' );
				},
				'meta' => array(
					'show_in_rest' => true,
					'annotations'  => array(
						'readonly'   => true,
						'idempotent' => true,
					),
				),
			)
		);
	}

	/**
	 * Execute the list-pages ability.
	 *
	 * @param array $input The input parameters.
	 * @return array The list of pages.
	 */
	public function execute_list_pages( $input ) {
		global $wpdb;

		$type   = isset( $input['type'] ) ? sanitize_text_field( $input['type'] ) : 'all';
		$status = isset( $input['status'] ) ? sanitize_text_field( $input['status'] ) : 'all';

		$meta_table  = $wpdb->prefix . 'postmeta';
		$posts_table = $wpdb->prefix . 'posts';

		$sql = "SELECT p.ID, p.post_title, p.post_status, pm_type.meta_value as page_type
				FROM {$posts_table} p
				LEFT JOIN {$meta_table} pm_uuid ON (pm_uuid.post_id = p.ID AND pm_uuid.meta_key = '_seedprod_page_uuid')
				LEFT JOIN {$meta_table} pm_type ON (pm_type.post_id = p.ID AND pm_type.meta_key = '_seedprod_page_template_type')
				WHERE p.post_status != 'trash'
				AND pm_uuid.meta_value IS NOT NULL
				AND (pm_type.meta_value IS NULL OR pm_type.meta_value != 'css')";

		if ( 'all' !== $status ) {
			$sql .= $wpdb->prepare( ' AND p.post_status = %s', $status );
		}

		if ( 'all' !== $type ) {
			$type_map   = $this->get_save_page_type_map();
			$type_short = isset( $type_map[ $type ] ) ? $type_map[ $type ]['template_type'] : $type;
			$sql       .= $wpdb->prepare( ' AND pm_type.meta_value = %s', $type_short );
		}

		$sql .= ' ORDER BY p.post_date DESC';

		$results = $wpdb->get_results( $sql ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared

		$pages = array();
		foreach ( $results as $row ) {
			$short = $row->page_type ? $row->page_type : 'lp';
			$pages[] = array(
				'id'       => absint( $row->ID ),
				'title'    => $row->post_title,
				'type'     => $this->page_type_long_form( $short ),
				'status'   => $row->post_status,
				'edit_url' => admin_url( 'admin.php?page=seedprod_pro_builder&id=' . absint( $row->ID ) ),
			);
		}

		return $pages;
	}

	/**
	 * Get the supported save-page types.
	 *
	 * @return array<string, array{post_type: string, template_type: string, is_theme: bool}>
	 */
	private function get_save_page_type_map() {
		$type_map = array(
			'landing-page' => array( 'post_type' => 'page',     'template_type' => 'lp', 'is_theme' => false ),
			'coming-soon'  => array( 'post_type' => 'seedprod', 'template_type' => 'cs', 'is_theme' => false ),
			'maintenance'  => array( 'post_type' => 'seedprod', 'template_type' => 'mm', 'is_theme' => false ),
		);

		if ( 'lite' !== SEEDPROD_PRO_BUILD ) {
			$type_map['login']         = array( 'post_type' => 'page',     'template_type' => 'loginp', 'is_theme' => false );
			$type_map['404']           = array( 'post_type' => 'seedprod', 'template_type' => 'p404',   'is_theme' => false );
			$type_map['header']        = array( 'post_type' => 'seedprod', 'template_type' => 'header', 'is_theme' => true );
			$type_map['footer']        = array( 'post_type' => 'seedprod', 'template_type' => 'footer', 'is_theme' => true );
			$type_map['page-template'] = array( 'post_type' => 'seedprod', 'template_type' => 'page',   'is_theme' => true );
			$type_map['part']          = array( 'post_type' => 'seedprod', 'template_type' => 'part',   'is_theme' => true );
		}

		// CAREFUL: PHP stores numeric-string array keys as integers ('404' => …
		// is stored under int 404). There's no way to keep them as strings at the
		// array level; consumers that read keys (array_keys, foreach …as $key)
		// must coerce back to string themselves. See page_type_long_form() and
		// the two type_enum sites in register_save_page / register_list_pages.
		return $type_map;
	}

	/**
	 * Flat list of valid theme-template condition values, sourced from the
	 * builder's own condition picker so the two never drift. Includes the
	 * per-post-type is_singular(<post_type>) values and, when WooCommerce or
	 * EDD are active, their condition groups.
	 *
	 * @return string[] Condition values accepted by save-page.
	 */
	private function get_condition_enum() {
		if ( ! function_exists( 'seedprod_pro_theme_template_conditons' ) ) {
			return array( '_entire_site', 'is_front_page', 'is_home', 'is_page(x)', 'is_single(x)', 'is_404', 'is_archive' );
		}

		$values = array();
		foreach ( seedprod_pro_theme_template_conditons() as $group ) {
			foreach ( (array) $group as $entry ) {
				if ( isset( $entry['value'] ) && '' !== $entry['value'] ) {
					$values[] = (string) $entry['value'];
				}
			}
		}

		return array_values( array_unique( $values ) );
	}

	/**
	 * Map a stored short-form page_type (e.g. "lp", "cs", "page") to the long-form
	 * value used by the save-page input enum (e.g. "landing-page", "coming-soon",
	 * "page-template"). Derived from get_save_page_type_map() so the two stay in
	 * sync; returns the input unchanged when no entry in the current build's map
	 * declares it as a template_type.
	 *
	 * @param string $short The short-form page_type stored on the page.
	 * @return string The long-form value, suitable for use as a save-page input type.
	 */
	private function page_type_long_form( $short ) {
		foreach ( $this->get_save_page_type_map() as $long => $config ) {
			if ( $config['template_type'] === $short ) {
				// (string) cast: PHP stores numeric-string keys as ints, so the
				// '404' map key is yielded as int 404. The output_schema declares
				// 'type' as string; without this cast list-pages 500s with
				// "output[0][type] is not of type string".
				return (string) $long;
			}
		}
		return $short;
	}

	/**
	 * Mapping of short-form mode page type to its activation settings.
	 *
	 * Mirrors app/settings.php $settings_to_update — the plugin runtime reads
	 * the matching flag from seedprod_settings and the matching option for the
	 * page id when serving each mode.
	 *
	 * @return array<string, array{flag: string, option: string}>
	 */
	private function get_mode_activation_map() {
		return array(
			'cs'     => array( 'flag' => 'enable_coming_soon_mode', 'option' => 'seedprod_coming_soon_page_id' ),
			'mm'     => array( 'flag' => 'enable_maintenance_mode', 'option' => 'seedprod_maintenance_mode_page_id' ),
			'loginp' => array( 'flag' => 'enable_login_mode',       'option' => 'seedprod_login_page_id' ),
			'p404'   => array( 'flag' => 'enable_404_mode',         'option' => 'seedprod_404_page_id' ),
		);
	}

	/**
	 * Activate the mode bound to a mode page (coming-soon, maintenance, login,
	 * or 404). Coming-soon and maintenance are mutually exclusive (both signal
	 * "site is offline"); login and 404 are independent of every other mode.
	 *
	 * Used by both the create and update paths of execute_save_page so the
	 * activate=true flag behaves consistently regardless of code path.
	 *
	 * @param int    $page_id          The post ID of the page to activate.
	 * @param string $page_type_short  The page's short-form type (cs|mm|loginp|p404|...).
	 * @param bool   $activate         Whether the caller asked to activate.
	 * @return bool True if a mode was activated, false otherwise.
	 */
	private function maybe_activate_mode( $page_id, $page_type_short, $activate ) {
		if ( ! $activate ) {
			return false;
		}

		$map = $this->get_mode_activation_map();
		if ( ! isset( $map[ $page_type_short ] ) ) {
			return false;
		}

		$entry    = $map[ $page_type_short ];
		$settings = $this->get_settings();
		$settings[ $entry['flag'] ] = true;

		if ( 'cs' === $page_type_short ) {
			$settings['enable_maintenance_mode'] = false;
		} elseif ( 'mm' === $page_type_short ) {
			$settings['enable_coming_soon_mode'] = false;
		}

		update_option( $entry['option'], $page_id );
		update_option( 'seedprod_settings', wp_json_encode( $settings ) );
		return true;
	}

	/**
	 * Register the save-page ability.
	 */
	private function register_save_page() {
		$is_lite  = ( 'lite' === SEEDPROD_PRO_BUILD );
		// strval cast: PHP stores numeric-string keys as ints (e.g. '404' => 404),
		// so array_keys() returns int 404 here. JSON Schema rejects mixed-type
		// enums; coerce back to strings.
		$type_enum = array_map( 'strval', array_keys( $this->get_save_page_type_map() ) );

		$type_description = $is_lite
			? __( 'Page type. Required when creating; ignored when updating an existing page (id is set). landing-page = standard landing page, coming-soon/maintenance = mode pages.', 'seedprod-pro' )
			: __( 'Page type. Required when creating; ignored when updating an existing page (id is set). landing-page = standard landing page, coming-soon/maintenance/login/404 = special mode pages, header/footer/page-template/part = theme templates.', 'seedprod-pro' );

		$description = $is_lite
			? __( 'Create or update a SeedProd page. Lite supports landing pages, coming soon, and maintenance pages. Pass an id to update an existing page, or omit to create a new one.', 'seedprod-pro' )
			: __( 'Create or update any SeedProd page. Handles landing pages, coming soon, maintenance, login, and theme templates (header, footer, page templates, parts). Pass an id to update an existing page, or omit to create a new one.', 'seedprod-pro' );

		wp_register_ability(
			'seedprod/save-page',
			array(
				'label'        => __( 'Save SeedProd Page', 'seedprod-pro' ),
				'description'  => $description,
				'category'     => 'seedprod',
				'input_schema' => array(
					'type'       => 'object',
					'properties' => array(
						'id' => array(
							'type'        => 'integer',
							'description' => __( 'Post ID of an existing page to update. Omit to create a new page.', 'seedprod-pro' ),
						),
						'type' => array(
							'type'        => 'string',
							'enum'        => $type_enum,
							'description' => $type_description,
						),
						'title' => array(
							'type'        => 'string',
							'description' => __( 'Page title. Required when creating.', 'seedprod-pro' ),
						),
						'status' => array(
							'type'        => 'string',
							'enum'        => array( 'publish', 'draft' ),
							'description' => __( 'Post status. Defaults to draft when creating; omit on update to keep the current status.', 'seedprod-pro' ),
						),
						'sections' => array(
							'type'        => 'array',
							'description' => __( 'The page content: an array of section objects following the SeedProd document hierarchy — section > rows[] > cols[] > blocks[]. Every node (section, row, col, block) needs a unique "id". Each block also has a "type", an "elType" of "block", and a "settings" object.', 'seedprod-pro' ),
						),
						'condition' => array(
							'type'        => 'string',
							'enum'        => $this->get_condition_enum(),
							'description' => __( 'Template condition for theme templates. Controls where the template renders. Some values carry their target in the name (is_singular(post) = every post); conditions ending in "(x)" (is_page(x), is_single(x), has_category(x)) target specific content and must be paired with condition_value. Required when creating a header/footer/page-template/part; pass on update to change where an existing theme template renders.', 'seedprod-pro' ),
						),
						'condition_value' => array(
							'type'        => 'string',
							'description' => __( 'Target for a parametric condition (one ending in "(x)", e.g. is_page(x) or is_single(x)): a comma-separated list of page or post IDs or slugs, such as "42", "about,contact", or "42,about". Required when condition is parametric; ignored otherwise.', 'seedprod-pro' ),
						),
						'menu_order' => array(
							'type'        => 'integer',
							'description' => __( 'Theme-template priority. When several templates of the same type match a URL, the highest menu_order wins (first match after sorting high to low). Works on create and update. Default: 0.', 'seedprod-pro' ),
						),
						'activate' => array(
							'type'        => 'boolean',
							'description' => __( 'For coming-soon, maintenance, login, and 404 pages: whether to bind this page as the active mode after saving. Works on both create and update. Coming-soon and maintenance are mutually exclusive (activating one disables the other); login and 404 are independent. Default: false.', 'seedprod-pro' ),
						),
					),
					'required' => array(),
				),
				'output_schema' => array(
					'type'       => 'object',
					'properties' => array(
						'id' => array(
							'type'        => 'integer',
							'description' => __( 'The post ID of the created or updated page.', 'seedprod-pro' ),
						),
						'title' => array(
							'type'        => 'string',
							'description' => __( 'The page title.', 'seedprod-pro' ),
						),
						'type' => array(
							'type'        => 'string',
							'description' => __( 'The page type.', 'seedprod-pro' ),
						),
						'edit_url' => array(
							'type'        => 'string',
							'description' => __( 'URL to edit this page in the SeedProd builder.', 'seedprod-pro' ),
						),
						'activated' => array(
							'type'        => 'boolean',
							'description' => __( 'Whether a mode was activated (for coming-soon/maintenance).', 'seedprod-pro' ),
						),
					),
				),
				'execute_callback'    => array( $this, 'execute_save_page' ),
				'permission_callback' => function () {
					return current_user_can( apply_filters( 'seedprod_lpage_capability', 'edit_others_posts' ) );
				},
				'meta' => array(
					'show_in_rest' => true,
					'annotations'  => array(
						'idempotent'   => false,
						'instructions' => 'Build the page content in the "sections" parameter, following the SeedProd document hierarchy: section > rows[] > cols[] > blocks[], where each block is an object with a "type" and a "settings" object. To learn the exact JSON shape and the block types a page already uses, read an existing SeedProd page with seedprod/get-page using include_sections=true.',
					),
				),
			)
		);
	}

	/**
	 * Execute the save-page ability.
	 *
	 * @param array $input The input parameters.
	 * @return array|WP_Error The result or error.
	 */
	public function execute_save_page( $input ) {
		$id       = isset( $input['id'] ) ? absint( $input['id'] ) : 0;
		$type     = isset( $input['type'] ) ? sanitize_text_field( $input['type'] ) : '';
		$title    = isset( $input['title'] ) ? sanitize_text_field( $input['title'] ) : '';
		// Empty means "not provided": updates keep the current status (a defaulted
		// 'draft' silently unpublished live pages on every edit); creates fall
		// back to draft below.
		$status   = isset( $input['status'] ) ? sanitize_text_field( $input['status'] ) : '';
		$sections = isset( $input['sections'] ) ? $input['sections'] : array();
		$condition       = isset( $input['condition'] ) ? sanitize_text_field( $input['condition'] ) : '';
		$condition_value = isset( $input['condition_value'] ) ? sanitize_text_field( $input['condition_value'] ) : '';
		$activate        = isset( $input['activate'] ) ? (bool) $input['activate'] : false;
		$menu_order      = isset( $input['menu_order'] ) ? intval( $input['menu_order'] ) : null;

		if ( $activate && ! current_user_can( 'manage_options' ) ) {
			return new WP_Error( 'forbidden', __( 'You do not have permission to activate a mode page.', 'seedprod-pro' ), array( 'status' => 403 ) );
		}

		// A parametric condition (type ending in "(x)") with an empty value matches
		// every page or post of its type, so require an explicit target.
		$condition_is_parametric = ( '' !== $condition && false !== strpos( $condition, '(x)' ) );
		if ( $condition_is_parametric && '' === $condition_value ) {
			return new WP_Error(
				'missing_condition_value',
				__( 'condition_value is required for parametric conditions like is_page(x) or is_single(x). Pass a comma-separated list of page or post IDs or slugs.', 'seedprod-pro' ),
				array( 'status' => 400 )
			);
		}

		if ( ! empty( $sections ) ) {
			if ( ! is_array( $sections ) ) {
				return new WP_Error( 'invalid_sections', __( 'sections must be an array of section objects.', 'seedprod-pro' ), array( 'status' => 400 ) );
			}
			$violations = $this->validate_sections( $sections );
			if ( ! empty( $violations ) ) {
				return new WP_Error(
					'invalid_sections',
					__( 'The sections tree is malformed; fix these and retry.', 'seedprod-pro' ) . ' ' . implode( ' | ', $violations ),
					array(
						'status'     => 400,
						'violations' => $violations,
					)
				);
			}
		}

		// --- Update existing page ---
		if ( $id ) {
			$post = get_post( $id );
			if ( ! $post ) {
				return new WP_Error( 'not_found', __( 'Page not found.', 'seedprod-pro' ) );
			}
			if ( 'css' === get_post_meta( $id, '_seedprod_page_template_type', true ) ) {
				return new WP_Error( 'not_seedprod', __( 'Global CSS is not a content page. Use seedprod/get-global-css and seedprod/save-global-css instead.', 'seedprod-pro' ), array( 'status' => 400 ) );
			}
			if ( ( 'seedprod' !== $post->post_type && ! get_post_meta( $id, '_seedprod_page', true ) && ! get_post_meta( $id, '_seedprod_edited_with_seedprod', true ) ) || ! current_user_can( 'edit_post', $id ) ) {
				return new WP_Error( 'forbidden', __( 'You do not have permission to edit this page.', 'seedprod-pro' ), array( 'status' => 403 ) );
			}

			// Saving sections needs unfiltered_html.
			if ( ! empty( $sections ) && ! current_user_can( 'unfiltered_html' ) ) {
				return new WP_Error( 'forbidden', __( 'You need the unfiltered_html capability to save page sections.', 'seedprod-pro' ), array( 'status' => 403 ) );
			}

			// Read existing content_filtered and merge sections into it.
			$existing = json_decode( $post->post_content_filtered, true );
			if ( ! is_array( $existing ) ) {
				$existing = array();
			}

			if ( ! empty( $sections ) ) {
				if ( ! isset( $existing['document'] ) ) {
					$existing['document'] = array();
				}
				$existing['document']['sections'] = $sections;
			}

			if ( $title ) {
				$existing['post_title'] = $title;
				wp_update_post( array( 'ID' => $id, 'post_title' => $title ) );
			}

			if ( $status && $status !== $post->post_status ) {
				wp_update_post( array( 'ID' => $id, 'post_status' => $status ) );
			}

			if ( null !== $menu_order ) {
				wp_update_post( array( 'ID' => $id, 'menu_order' => $menu_order ) );
			}

			if ( '' !== $condition ) {
				if ( 'lite' === SEEDPROD_PRO_BUILD ) {
					return new WP_Error( 'not_supported', __( 'condition is not supported in this version.', 'seedprod-pro' ), array( 'status' => 400 ) );
				}
				if ( ! get_post_meta( $id, '_seedprod_is_theme_template', true ) ) {
					return new WP_Error( 'not_theme_template', __( 'condition can only be changed on theme templates (header, footer, page-template, part).', 'seedprod-pro' ), array( 'status' => 400 ) );
				}
				update_post_meta(
					$id,
					'_seedprod_theme_template_condition',
					wp_json_encode( array( array( 'condition' => 'include', 'type' => $condition, 'value' => $condition_is_parametric ? $condition_value : '' ) ) )
				);
			}

			// Validate JSON before saving.
			$json = wp_json_encode( $existing );
			if ( false === $json || null === $json ) {
				return new WP_Error( 'invalid_json', __( 'Failed to encode page content as JSON. Check that sections contain valid data.', 'seedprod-pro' ) );
			}

			// Write content_filtered via direct SQL to bypass KSES.
			global $wpdb;
			$result = $wpdb->update(
				$wpdb->posts,
				array( 'post_content_filtered' => $json ),
				array( 'ID' => $id ),
				array( '%s' ),
				array( '%d' )
			);

			if ( false === $result ) {
				return new WP_Error( 'db_error', __( 'Failed to update page content.', 'seedprod-pro' ) );
			}

			clean_post_cache( $id );

			if ( get_post_meta( $id, '_seedprod_is_theme_template', true ) ) {
				$this->maybe_create_placeholder_pages( $id );
			}

			// _seedprod_page_template_type post meta is the authoritative source
			// (it's what list-pages reads, and it survives content_filtered drift).
			// Fall back to the JSON page_type, then to "lp", for older rows that
			// didn't seed the meta.
			$meta_type           = get_post_meta( $id, '_seedprod_page_template_type', true );
			$existing_type_short = $meta_type ? $meta_type : ( isset( $existing['page_type'] ) ? $existing['page_type'] : 'lp' );
			$activated           = $this->maybe_activate_mode( $id, $existing_type_short, $activate );

			return array(
				'id'        => $id,
				'title'     => $title ? $title : $post->post_title,
				'type'      => $this->page_type_long_form( $existing_type_short ),
				'edit_url'  => admin_url( 'admin.php?page=seedprod_pro_builder&id=' . $id ),
				'activated' => $activated,
			);
		}

		// --- Create new page ---
		if ( ! $type ) {
			return new WP_Error( 'missing_type', __( 'type is required when creating a new page.', 'seedprod-pro' ) );
		}
		if ( ! $title ) {
			return new WP_Error( 'missing_title', __( 'title is required when creating a new page.', 'seedprod-pro' ) );
		}

		$type_map = $this->get_save_page_type_map();

		if ( ! isset( $type_map[ $type ] ) ) {
			return new WP_Error( 'invalid_type', __( 'Invalid page type for this build.', 'seedprod-pro' ) );
		}

		$config = $type_map[ $type ];

		// Require condition for theme templates.
		if ( $config['is_theme'] && ! $condition ) {
			return new WP_Error( 'missing_condition', __( 'condition is required for theme templates (header, footer, page-template, part).', 'seedprod-pro' ) );
		}

		// Saving sections needs unfiltered_html.
		if ( ! empty( $sections ) && ! current_user_can( 'unfiltered_html' ) ) {
			return new WP_Error( 'forbidden', __( 'You need the unfiltered_html capability to save page sections.', 'seedprod-pro' ), array( 'status' => 403 ) );
		}

		// Build the document.
		$document = $this->build_document( $sections );

		if ( '' === $status ) {
			$status = 'draft';
		}

		// Build the content_filtered JSON wrapper.
		$content = array(
			'page_type'             => $config['template_type'],
			'post_title'            => $title,
			'post_name'             => sanitize_title( $title ),
			'post_status'           => $status,
			'show_header_template'  => true,
			'show_footer_template'  => true,
			'no_conflict_mode'      => false,
			'no_index'              => false,
			'is_new'                => false,
			'template_id'           => 0,
			'document'              => $document,
		);

		// Build meta_input.
		$meta_input = array(
			'_seedprod_page'               => true,
			'_seedprod_page_uuid'          => wp_generate_uuid4(),
			'_seedprod_page_template_type' => $config['template_type'],
		);

		if ( $config['is_theme'] ) {
			$meta_input['_seedprod_is_theme_template'] = true;
			$meta_input['_seedprod_theme_template_condition'] = wp_json_encode(
				array( array( 'condition' => 'include', 'type' => $condition, 'value' => $condition_is_parametric ? $condition_value : '' ) )
			);
		}

		// Insert the post.
		$post_id = wp_insert_post(
			array(
				'post_type'    => $config['post_type'],
				'post_title'   => $title,
				'post_name'    => sanitize_title( $title ),
				'post_status'  => $status,
				'post_content' => '',
				'menu_order'   => null !== $menu_order ? $menu_order : 0,
				'meta_input'   => $meta_input,
			),
			true
		);

		if ( is_wp_error( $post_id ) ) {
			return $post_id;
		}

		// Validate JSON before saving.
		$json = wp_json_encode( $content );
		if ( false === $json || null === $json ) {
			wp_delete_post( $post_id, true );
			return new WP_Error( 'invalid_json', __( 'Failed to encode page content as JSON. Check that sections contain valid data.', 'seedprod-pro' ) );
		}

		// Write content_filtered via direct SQL to bypass KSES.
		global $wpdb;
		$result = $wpdb->update(
			$wpdb->posts,
			array( 'post_content_filtered' => $json ),
			array( 'ID' => $post_id ),
			array( '%s' ),
			array( '%d' )
		);

		if ( false === $result ) {
			wp_delete_post( $post_id, true );
			return new WP_Error( 'db_error', __( 'Failed to save page content.', 'seedprod-pro' ) );
		}

		clean_post_cache( $post_id );

		if ( $config['is_theme'] ) {
			$this->maybe_create_placeholder_pages( $post_id );
		}

		// Activate mode if requested.
		$activated = $this->maybe_activate_mode( $post_id, $config['template_type'], $activate );

		return array(
			'id'        => $post_id,
			'title'     => $title,
			'type'      => $type,
			'edit_url'  => admin_url( 'admin.php?page=seedprod_pro_builder&id=' . $post_id ),
			'activated' => $activated,
		);
	}

	/**
	 * Create published placeholder pages for a published theme template whose
	 * condition is a single include is_page(x), so the targeted URLs resolve.
	 * Best effort: numeric IDs, path-style values, and slugs already used by
	 * a page are skipped, and the caller must be able to publish pages.
	 *
	 * @param integer $post_id Theme template post ID.
	 * @return void
	 */
	private function maybe_create_placeholder_pages( $post_id ) {
		if ( 'publish' !== get_post_status( $post_id ) || ! current_user_can( 'publish_pages' ) ) {
			return;
		}

		$conditions = json_decode( seedprod_pro_normalize_conditions_json( get_post_meta( $post_id, '_seedprod_theme_template_condition', true ) ) );
		if ( ! is_array( $conditions ) || 1 !== count( $conditions ) ) {
			return;
		}

		$condition = $conditions[0];
		if ( ! isset( $condition->condition, $condition->type, $condition->value ) || 'include' !== $condition->condition || 'is_page(x)' !== $condition->type || '' === (string) $condition->value ) {
			return;
		}

		foreach ( array_map( 'trim', explode( ',', (string) $condition->value ) ) as $slug ) {
			if ( '' === $slug || is_numeric( $slug ) || false !== strpos( $slug, '/' ) ) {
				continue;
			}

			// Match by post_name at any depth, like the is_page(x) runtime check.
			$existing = get_posts(
				array(
					'name'        => $slug,
					'post_type'   => 'page',
					'post_status' => array( 'publish', 'future', 'draft', 'pending', 'private' ),
					'numberposts' => 1,
					'fields'      => 'ids',
				)
			);
			if ( ! empty( $existing ) ) {
				continue;
			}

			wp_insert_post(
				array(
					'post_title'   => ucwords( str_replace( array( '-', '_' ), ' ', $slug ) ),
					'post_name'    => $slug,
					'post_content' => __( 'This page was auto-generated as a placeholder page for your SeedProd theme. To manage its contents, visit SeedProd > Website Builder in the WordPress menu.', 'seedprod-pro' ),
					'post_status'  => 'publish',
					'post_type'    => 'page',
				)
			);
		}
	}

	/**
	 * Structurally validate an AI-supplied sections tree before saving.
	 *
	 * @param array $sections The document sections array.
	 * @return string[] Human-readable violations; empty when the tree is valid.
	 */
	private function validate_sections( $sections ) {
		$violations = array();
		$seen_ids   = array();

		$check_id = function ( $node, $path ) use ( &$violations, &$seen_ids ) {
			if ( ! isset( $node['id'] ) || ! is_string( $node['id'] ) || '' === $node['id'] ) {
				$violations[] = $path . ': missing required string "id".';
				return;
			}
			if ( isset( $seen_ids[ $node['id'] ] ) ) {
				$violations[] = sprintf( '%s: duplicate id "%s" (ids must be unique across the page).', $path, $node['id'] );
			}
			$seen_ids[ $node['id'] ] = true;
		};

		foreach ( $sections as $si => $section ) {
			$spath = "sections[{$si}]";
			if ( ! is_array( $section ) ) {
				$violations[] = $spath . ': must be an object.';
				continue;
			}
			$check_id( $section, $spath );
			if ( ! isset( $section['rows'] ) || ! is_array( $section['rows'] ) ) {
				$violations[] = $spath . ': missing "rows" array.';
				continue;
			}
			foreach ( $section['rows'] as $ri => $row ) {
				$rpath = "{$spath}.rows[{$ri}]";
				if ( ! is_array( $row ) ) {
					$violations[] = $rpath . ': must be an object.';
					continue;
				}
				$check_id( $row, $rpath );
				if ( ! isset( $row['cols'] ) || ! is_array( $row['cols'] ) ) {
					$violations[] = $rpath . ': missing "cols" array (the field is "cols", not "columns").';
					continue;
				}
				foreach ( $row['cols'] as $ci => $col ) {
					$cpath = "{$rpath}.cols[{$ci}]";
					if ( ! is_array( $col ) ) {
						$violations[] = $cpath . ': must be an object.';
						continue;
					}
					$check_id( $col, $cpath );
					if ( ! isset( $col['blocks'] ) || ! is_array( $col['blocks'] ) ) {
						$violations[] = $cpath . ': missing "blocks" array.';
						continue;
					}
					foreach ( $col['blocks'] as $bi => $block ) {
						$bpath = "{$cpath}.blocks[{$bi}]";
						if ( ! is_array( $block ) ) {
							$violations[] = $bpath . ': must be an object.';
							continue;
						}
						$check_id( $block, $bpath );
						if ( empty( $block['type'] ) || ! is_string( $block['type'] ) ) {
							$violations[] = $bpath . ': missing required block "type" (e.g. "header", "text").';
						}
						if ( empty( $block['elType'] ) || ! is_string( $block['elType'] ) ) {
							$violations[] = $bpath . ': missing "elType" (blocks use elType "block").';
						}
					}
				}
			}
		}

		if ( count( $violations ) > 50 ) {
			$extra        = count( $violations ) - 50;
			$violations   = array_slice( $violations, 0, 50 );
			$violations[] = sprintf( '...and %d more.', $extra );
		}

		return $violations;
	}

	/**
	 * Build a SeedProd document structure with default settings.
	 *
	 * @param array $sections Optional sections array. If empty, creates a blank document.
	 * @return array The document structure.
	 */
	private function build_document( $sections = array() ) {
		// If sections provided by the AI, use them directly.
		if ( ! empty( $sections ) ) {
			return array(
				'sections' => $sections,
				'settings' => $this->get_default_document_settings(),
			);
		}

		// Build a minimal blank document: one section > one row > one col.
		$col_settings = array(
			'bgStyle'          => 's',
			'paddingTop'       => '40',
			'paddingBottom'    => '40',
			'paddingLeft'      => '20',
			'paddingRight'     => '20',
			'paddingSync'      => false,
			'marginSync'       => false,
			'borderRadiusSync' => true,
			'borderSync'       => true,
			'borderStyle'      => 'solid',
			'hideOnDesktop'    => false,
			'hideOnMobile'     => false,
			'hideOnTablet'     => false,
		);

		$row_settings = array(
			'bgStyle'          => 's',
			'colGutter'        => 0,
			'contentWidth'     => 2,
			'width'            => '1000',
			'paddingTop'       => '0',
			'paddingBottom'    => '0',
			'paddingLeft'      => '0',
			'paddingRight'     => '0',
			'paddingSync'      => true,
			'marginSync'       => false,
			'borderRadiusSync' => true,
			'borderSync'       => true,
			'borderStyle'      => 'solid',
			'hideOnDesktop'    => false,
			'hideOnMobile'     => false,
			'hideOnTablet'     => false,
		);

		$section_settings = array(
			'bgStyle'          => 's',
			'contentWidth'     => 1,
			'width'            => '1000',
			'paddingTop'       => '10',
			'paddingBottom'    => '10',
			'paddingLeft'      => '10',
			'paddingRight'     => '10',
			'paddingSync'      => true,
			'marginSync'       => false,
			'borderRadiusSync' => true,
			'borderSync'       => true,
			'borderStyle'      => 'solid',
			'hideOnDesktop'    => false,
			'hideOnMobile'     => false,
			'hideOnTablet'     => false,
		);

		return array(
			'sections' => array(
				array(
					'id'       => $this->make_uid(),
					'type'     => 'section',
					'rows'     => array(
						array(
							'id'       => $this->make_uid(),
							'type'     => 'row',
							'colType'  => '1-col',
							'cols'     => array(
								array(
									'id'       => $this->make_uid(),
									'type'     => 'col',
									'blocks'   => array(),
									'settings' => $col_settings,
								),
							),
							'settings' => $row_settings,
						),
					),
					'settings' => $section_settings,
				),
			),
			'settings' => $this->get_default_document_settings(),
		);
	}

	/**
	 * Get default document-level settings.
	 *
	 * @return array Default document settings.
	 */
	private function get_default_document_settings() {
		return array(
			'bgStyle'         => 's',
			'bgColor'         => '#FFFFFF',
			'textColor'       => '#333333',
			'headerColor'     => '#111111',
			'buttonColor'     => '#3858E9',
			'textFont'        => 'Roboto',
			'textFontVariant' => '400',
		);
	}

	/**
	 * Generate a 6-character UID matching SeedProd's frontend format.
	 *
	 * @return string A 6-character alphanumeric ID.
	 */
	private function make_uid() {
		$chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
		$id    = $chars[ wp_rand( 0, 25 ) ];
		for ( $i = 0; $i < 5; $i++ ) {
			$id .= $chars[ wp_rand( 0, 35 ) ];
		}
		return $id;
	}

	// -------------------------------------------------------------------------
	// Get page
	// -------------------------------------------------------------------------

	/**
	 * Register the get-page ability.
	 *
	 * Two-tier response: metadata-only by default (cheap, useful for inspection),
	 * full sections JSON when include_sections=true (heavy, for read-then-edit
	 * workflows). The page-content JSON can run to hundreds of KB on complex
	 * pages — opting out by default keeps AI host context windows usable.
	 */
	private function register_get_page() {
		wp_register_ability(
			'seedprod/get-page',
			array(
				'label'        => __( 'Get SeedProd Page', 'seedprod-pro' ),
				'description'  => __( 'Get a single SeedProd page by ID. Returns metadata by default (lightweight); pass include_sections=true to also return the full sections JSON for editing.', 'seedprod-pro' ),
				'category'     => 'seedprod',
				'input_schema' => array(
					'type'       => 'object',
					'properties' => array(
						'id'               => array(
							'type'        => 'integer',
							'description' => __( 'The post ID of the page to retrieve.', 'seedprod-pro' ),
						),
						'include_sections' => array(
							'type'        => 'boolean',
							'description' => __( 'When true, include the full document sections array. Default false returns metadata only — much cheaper for inspection, since sections can be hundreds of KB on complex pages.', 'seedprod-pro' ),
							'default'     => false,
						),
					),
					'required'   => array( 'id' ),
				),
				'output_schema' => array(
					'type'       => 'object',
					'properties' => array(
						'id'            => array( 'type' => 'integer' ),
						'title'         => array( 'type' => 'string' ),
						'type'          => array(
							'type'        => 'string',
							'description' => __( 'Long-form page type (landing-page, coming-soon, ...).', 'seedprod-pro' ),
						),
						'status'        => array( 'type' => 'string' ),
						'slug'          => array( 'type' => 'string' ),
						'condition'     => array(
							'type'        => 'string',
							'description' => __( 'Template routing condition (theme templates only; empty string otherwise).', 'seedprod-pro' ),
						),
						'condition_value' => array(
							'type'        => 'string',
							'description' => __( 'Target value for a parametric condition (comma-separated page or post IDs or slugs); empty string when the condition takes no value.', 'seedprod-pro' ),
						),
						'settings'      => array(
							'type'        => 'object',
							'description' => __( 'Page-level globals (fonts, layout). Populated for landing pages.', 'seedprod-pro' ),
						),
						'section_count' => array( 'type' => 'integer' ),
						'block_count'   => array( 'type' => 'integer' ),
						'activated'     => array(
							'type'        => 'boolean',
							'description' => __( 'True when this page is currently the bound active mode page (coming-soon, maintenance, login, or 404).', 'seedprod-pro' ),
						),
						'last_modified' => array(
							'type'        => 'string',
							'description' => __( 'ISO 8601 last-modified timestamp.', 'seedprod-pro' ),
						),
						'edit_url'      => array( 'type' => 'string' ),
						'sections'      => array(
							// Nullable: null when include_sections=false; array when true (possibly empty if the page has no sections).
							'type'        => array( 'array', 'null' ),
							'description' => __( 'Full document sections array. null when include_sections is false; an array (possibly empty) when true.', 'seedprod-pro' ),
						),
					),
				),
				'execute_callback'    => array( $this, 'execute_get_page' ),
				'permission_callback' => function () {
					return current_user_can( 'edit_pages' );
				},
				'meta'                => array(
					'show_in_rest' => true,
					'annotations'  => array(
						'readonly'     => true,
						'idempotent'   => true,
						'instructions' => 'Pass include_sections=true to retrieve the full document sections array (section > rows[] > cols[] > blocks[]) for read-modify-write edits, then save the modified array back through seedprod/save-page.',
					),
				),
			)
		);
	}

	/**
	 * Execute the get-page ability.
	 *
	 * @param array $input The input parameters.
	 * @return array|WP_Error The page data.
	 */
	public function execute_get_page( $input ) {
		$id               = isset( $input['id'] ) ? absint( $input['id'] ) : 0;
		$include_sections = isset( $input['include_sections'] ) ? (bool) $input['include_sections'] : false;

		if ( ! $id ) {
			return new WP_Error( 'missing_id', __( 'id is required.', 'seedprod-pro' ), array( 'status' => 400 ) );
		}

		$post = get_post( $id );
		if ( ! $post ) {
			return new WP_Error( 'not_found', __( 'Page not found.', 'seedprod-pro' ), array( 'status' => 404 ) );
		}

		// Only return SeedProd-marked pages. execute_save_page sets _seedprod_page
		// on every page we own; without that filter we'd happily hand back
		// arbitrary wp_posts rows by id.
		if ( ! get_post_meta( $id, '_seedprod_page', true ) ) {
			return new WP_Error( 'not_seedprod', __( 'Post is not a SeedProd page.', 'seedprod-pro' ), array( 'status' => 400 ) );
		}

		// Global CSS is a different shape (no sections/rows/cols) and save-page
		// rejects type=css, so keep the page read/write surface symmetric —
		// list-pages hides css rows for the same reason. It has its own
		// abilities: seedprod/get-global-css and seedprod/save-global-css.
		if ( 'css' === get_post_meta( $id, '_seedprod_page_template_type', true ) ) {
			return new WP_Error( 'not_seedprod', __( 'Global CSS is not a content page. Use seedprod/get-global-css and seedprod/save-global-css instead.', 'seedprod-pro' ), array( 'status' => 400 ) );
		}

		$content = json_decode( $post->post_content_filtered, true );
		if ( ! is_array( $content ) ) {
			$content = array();
		}

		$document      = ( isset( $content['document'] ) && is_array( $content['document'] ) ) ? $content['document'] : array();
		$sections      = ( isset( $document['sections'] ) && is_array( $document['sections'] ) ) ? $document['sections'] : array();
		$page_settings = ( isset( $document['settings'] ) && is_array( $document['settings'] ) ) ? $document['settings'] : array();

		// Resolve long-form type. Authoritative source is _seedprod_page_template_type
		// (matches list-pages); fall back to the JSON page_type for older rows.
		$meta_type  = get_post_meta( $id, '_seedprod_page_template_type', true );
		$type_short = $meta_type ? $meta_type : ( isset( $content['page_type'] ) ? $content['page_type'] : 'lp' );

		// Theme template condition: stored as a JSON-encoded array of condition
		// objects. v1 returns the first entry's type — matches the single
		// condition string save-page accepts. If future versions accept
		// multi-rule conditions, return the full array instead.
		$condition       = '';
		$condition_value = '';
		$condition_meta  = seedprod_pro_normalize_conditions_json( get_post_meta( $id, '_seedprod_theme_template_condition', true ) );
		if ( $condition_meta ) {
			$decoded = json_decode( $condition_meta, true );
			if ( is_array( $decoded ) && isset( $decoded[0]['type'] ) ) {
				$condition = (string) $decoded[0]['type'];
			}
			if ( is_array( $decoded ) && isset( $decoded[0]['value'] ) ) {
				$condition_value = (string) $decoded[0]['value'];
			}
		}

		// Walk section > row > col > block to count blocks.
		$block_count = 0;
		foreach ( $sections as $section ) {
			if ( ! isset( $section['rows'] ) || ! is_array( $section['rows'] ) ) {
				continue;
			}
			foreach ( $section['rows'] as $row ) {
				if ( ! isset( $row['cols'] ) || ! is_array( $row['cols'] ) ) {
					continue;
				}
				foreach ( $row['cols'] as $col ) {
					if ( ! isset( $col['blocks'] ) || ! is_array( $col['blocks'] ) ) {
						continue;
					}
					$block_count += count( $col['blocks'] );
				}
			}
		}

		// Is this page currently bound as the active mode page?
		$activated = false;
		$mode_map  = $this->get_mode_activation_map();
		if ( isset( $mode_map[ $type_short ] ) ) {
			$entry     = $mode_map[ $type_short ];
			$settings  = $this->get_settings();
			$bound_id  = (int) get_option( $entry['option'] );
			$activated = ( $bound_id === $id ) && ! empty( $settings[ $entry['flag'] ] );
		}

		return array(
			'id'            => $id,
			'title'         => $post->post_title,
			'type'          => (string) $this->page_type_long_form( $type_short ),
			'status'        => $post->post_status,
			'slug'          => $post->post_name,
			'condition'       => $condition,
			'condition_value' => $condition_value,
			// Cast empty arrays through stdClass so wp_json_encode emits {} not [].
			'settings'      => empty( $page_settings ) ? (object) array() : $page_settings,
			'section_count' => count( $sections ),
			'block_count'   => $block_count,
			'activated'     => $activated,
			'last_modified' => mysql_to_rfc3339( $post->post_modified ),
			'edit_url'      => admin_url( 'admin.php?page=seedprod_pro_builder&id=' . $id ),
			'sections'      => $include_sections ? $sections : null,
		);
	}

	

	// -------------------------------------------------------------------------
	// Theme builder
	// -------------------------------------------------------------------------

	/**
	 * Register the toggle-theme ability (Pro only).
	 */
	private function register_toggle_theme() {
		wp_register_ability(
			'seedprod/toggle-theme',
			array(
				'label'        => __( 'Toggle Theme Builder', 'seedprod-pro' ),
				'description'  => __( 'Enable or disable the SeedProd theme builder. When enabled, SeedProd takes over the entire site theme.', 'seedprod-pro' ),
				'category'     => 'seedprod',
				'input_schema' => array(
					'type'       => 'object',
					'properties' => array(
						'enabled' => array(
							'type'        => 'boolean',
							'description' => __( 'Whether to enable (true) or disable (false) the theme builder.', 'seedprod-pro' ),
						),
					),
					'required' => array( 'enabled' ),
				),
				'output_schema' => array(
					'type'       => 'object',
					'properties' => array(
						'success' => array( 'type' => 'boolean' ),
						'enabled' => array( 'type' => 'boolean' ),
					),
				),
				'execute_callback'    => array( $this, 'execute_toggle_theme' ),
				'permission_callback' => function () {
					return current_user_can( 'manage_options' );
				},
				'meta' => array(
					'show_in_rest' => true,
					'annotations'  => array(
						'idempotent' => true,
					),
				),
			)
		);
	}

	/**
	 * Execute the toggle-theme ability.
	 *
	 * @param array $input The input parameters.
	 * @return array|WP_Error The result or error.
	 */
	public function execute_toggle_theme( $input ) {
		$enabled = isset( $input['enabled'] ) ? (bool) $input['enabled'] : false;

		// Check if theme builder feature is available.
		$theme_builder = seedprod_pro_cu( 'themebuilder' );
		if ( empty( $theme_builder ) ) {
			return new WP_Error(
				'seedprod_feature_unavailable',
				__( 'Theme builder feature is not available with your current license.', 'seedprod-pro' )
			);
		}

		$settings_json = get_option( 'seedprod_settings' );
		$settings      = array();
		if ( ! empty( $settings_json ) ) {
			$decoded = json_decode( $settings_json, true );
			if ( is_array( $decoded ) ) {
				$settings = $decoded;
			}
		}
		$settings['enable_seedprod_theme'] = $enabled;
		update_option( 'seedprod_settings', wp_json_encode( $settings ) );

		// Also update legacy standalone option — frontend rendering reads this directly.
		update_option( 'seedprod_theme_enabled', $enabled );

		if ( $enabled ) {
			$this->ensure_global_css_page();

			$result = $this->create_blog_and_home_pages();
			if ( is_wp_error( $result ) ) {
				return $result;
			}
		}

		return array(
			'success' => true,
			'enabled' => $enabled,
		);
	}

	private function ensure_global_css_page() {
		$global_css_page_id = get_option( 'seedprod_global_css_page_id' );
		if ( ! empty( $global_css_page_id ) ) {
			return;
		}

		$global_css_file = SEEDPROD_PRO_PLUGIN_PATH . 'resources/data-templates/global-css.php';
		if ( ! file_exists( $global_css_file ) ) {
			return;
		}

		require_once $global_css_file;
		if ( ! isset( $seedprod_global_css ) ) {
			return;
		}

		$args = array(
			'comment_status'        => 'closed',
			'ping_status'           => 'closed',
			'post_content_filtered' => $seedprod_global_css,
			'post_status'           => 'publish',
			'post_title'            => __( 'Global CSS', 'seedprod-pro' ),
			'post_type'             => 'seedprod',
			'post_name'             => '',
			'meta_input'            => array(
				'_seedprod_page'               => true,
				'_seedprod_page_uuid'          => wp_generate_uuid4(),
				'_seedprod_page_template_type' => 'css',
				'_seedprod_is_theme_template'  => true,
			),
		);

		$new_id = wp_insert_post( $args, true );
		if ( ! is_wp_error( $new_id ) && ! empty( $new_id ) ) {
			update_option( 'seedprod_global_css_page_id', $new_id );
		}
	}

	/**
	 * Create blog and home pages if they don't exist.
	 *
	 * @return true|WP_Error True on success, WP_Error on failure.
	 */
	private function create_blog_and_home_pages() {
		$front_page = get_page_by_path( 'home' );
		if ( empty( $front_page ) ) {
			$front_page_id = wp_insert_post(
				array(
					'comment_status' => 'close',
					'ping_status'    => 'close',
					'post_author'    => get_current_user_id(),
					'post_title'     => 'Home',
					'post_name'      => 'home',
					'post_status'    => 'publish',
					'post_content'   => '',
					'post_type'      => 'page',
				)
			);

			if ( is_wp_error( $front_page_id ) ) {
				return $front_page_id;
			}

			if ( empty( $front_page_id ) ) {
				return new WP_Error( 'seedprod_page_creation_failed', __( 'Failed to create home page.', 'seedprod-pro' ) );
			}
		} else {
			$front_page_id = $front_page->ID;
		}

		$posts_page = get_page_by_path( 'blog' );
		if ( empty( $posts_page ) ) {
			$posts_page_id = wp_insert_post(
				array(
					'comment_status' => 'close',
					'ping_status'    => 'close',
					'post_author'    => get_current_user_id(),
					'post_title'     => 'Blog',
					'post_name'      => 'blog',
					'post_status'    => 'publish',
					'post_content'   => '',
					'post_type'      => 'page',
				)
			);

			if ( is_wp_error( $posts_page_id ) ) {
				return $posts_page_id;
			}

			if ( empty( $posts_page_id ) ) {
				return new WP_Error( 'seedprod_page_creation_failed', __( 'Failed to create blog page.', 'seedprod-pro' ) );
			}
		} else {
			$posts_page_id = $posts_page->ID;
		}

		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', $front_page_id );
		update_option( 'page_for_posts', $posts_page_id );

		return true;
	}

	/**
	 * Register the get-global-css ability (Pro only).
	 */
	private function register_get_global_css() {
		wp_register_ability(
			'seedprod/get-global-css',
			array(
				'label'        => __( 'Get Global CSS', 'seedprod-pro' ),
				'description'  => __( 'Read the site-wide Global CSS: the custom CSS (WordPress Customizer Additional CSS), the compiled stylesheet, and the structured global style settings (read-only). The custom CSS renders site-wide wherever WordPress outputs wp_head, and is also merged into the SeedProd theme stylesheet.', 'seedprod-pro' ),
				'category'     => 'seedprod',
				'input_schema' => array(
					'type'       => array( 'object', 'null' ),
					'properties' => (object) array(), // Cast to stdClass so wp_json_encode emits {} not [].
				),
				'output_schema' => array(
					'type'       => 'object',
					'properties' => array(
						'page_id'      => array( 'type' => 'integer' ),
						'custom_css'   => array( 'type' => 'string' ),
						'compiled_css' => array( 'type' => 'string' ),
						'css_file_url' => array( 'type' => 'string' ),
						'settings'     => array( 'type' => 'object' ),
						'applies_to'   => array( 'type' => 'string' ),
					),
				),
				'execute_callback'    => array( $this, 'execute_get_global_css' ),
				'permission_callback' => function () {
					return current_user_can( 'edit_pages' );
				},
				'meta' => array(
					'show_in_rest' => true,
					'annotations'  => array(
						'readonly'   => true,
						'idempotent' => true,
					),
				),
			)
		);
	}

	/**
	 * Execute the get-global-css ability.
	 *
	 * @param array $input The input parameters.
	 * @return array|WP_Error The result or error.
	 */
	public function execute_get_global_css( $input ) {
		$page_id = absint( get_option( 'seedprod_global_css_page_id' ) );
		if ( empty( $page_id ) || ! get_post( $page_id ) ) {
			return new WP_Error(
				'seedprod_no_global_css',
				__( 'No Global CSS page exists yet. Enable the theme builder first (seedprod/toggle-theme).', 'seedprod-pro' ),
				array( 'status' => 404 )
			);
		}

		$post     = get_post( $page_id );
		$content  = json_decode( $post->post_content_filtered, true );
		$settings = isset( $content['document']['settings'] ) && is_array( $content['document']['settings'] ) ? $content['document']['settings'] : array();
		unset( $settings['customCss'], $settings['globalHeadCss'], $settings['globalHeadCssBuilder'] );

		$css_file     = trailingslashit( wp_upload_dir()['basedir'] ) . 'seedprod-css/style-global.css';
		$compiled_css = file_exists( $css_file ) ? (string) file_get_contents( $css_file ) : ''; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- local read of the generated stylesheet.

		return array(
			'page_id'      => $page_id,
			'custom_css'   => (string) wp_get_custom_css(),
			'compiled_css' => $compiled_css,
			'css_file_url' => trailingslashit( wp_upload_dir()['baseurl'] ) . 'seedprod-css/style-global.css',
			'settings'     => $settings,
			'applies_to'   => __( 'The custom CSS is stored as WordPress Customizer Additional CSS, so it renders site-wide anywhere WordPress outputs wp_head (including SeedProd landing, coming-soon, maintenance, login and 404 pages) and is also merged into the SeedProd theme stylesheet used by theme templates.', 'seedprod-pro' ),
		);
	}

	/**
	 * Register the save-global-css ability (Pro only).
	 */
	private function register_save_global_css() {
		wp_register_ability(
			'seedprod/save-global-css',
			array(
				'label'        => __( 'Save Global CSS', 'seedprod-pro' ),
				'description'  => __( 'Replace the site-wide custom CSS (stored as WordPress Customizer Additional CSS, the same source the Global CSS builder merges from — so edits persist across builder saves). Renders site-wide wherever WordPress outputs wp_head and is merged into the SeedProd theme stylesheet; the primary lever for site-wide restyling. Full replacement — overwrites any existing Customizer Additional CSS; empty string clears it. Structured global settings (fonts, colors) are builder-only and not writable here.', 'seedprod-pro' ),
				'category'     => 'seedprod',
				'input_schema' => array(
					'type'       => 'object',
					'properties' => array(
						'custom_css' => array(
							'type'        => 'string',
							'description' => __( 'The full custom CSS to apply site-wide. Replaces any previous value (from this ability or the WordPress Customizer Additional CSS field).', 'seedprod-pro' ),
						),
					),
					'required' => array( 'custom_css' ),
				),
				'output_schema' => array(
					'type'       => 'object',
					'properties' => array(
						'success'      => array( 'type' => 'boolean' ),
						'page_id'      => array( 'type' => 'integer' ),
						'css_file_url' => array( 'type' => 'string' ),
					),
				),
				'execute_callback'    => array( $this, 'execute_save_global_css' ),
				'permission_callback' => function () {
					// This writes WordPress Customizer Additional CSS, which core
					// gates at edit_theme_options (the Customizer section) plus raw
					// CSS handling (unfiltered_html). Match that bar — edit_others_posts
					// alone would let an Editor set site-wide CSS they cannot edit in wp-admin.
					return current_user_can( 'edit_theme_options' ) && current_user_can( 'unfiltered_html' );
				},
				'meta' => array(
					'show_in_rest' => true,
					'annotations'  => array(
						'idempotent' => true,
					),
				),
			)
		);
	}

	/**
	 * Execute the save-global-css ability.
	 *
	 * @param array $input The input parameters.
	 * @return array|WP_Error The result or error.
	 */
	public function execute_save_global_css( $input ) {
		if ( empty( seedprod_pro_cu( 'themebuilder' ) ) ) {
			return new WP_Error(
				'seedprod_feature_unavailable',
				__( 'Theme builder feature is not available with your current license.', 'seedprod-pro' )
			);
		}

		if ( ! function_exists( 'seedprod_pro_generate_css_file' ) || ! function_exists( 'seedprod_pro_merge_global_custom_css' ) ) {
			return new WP_Error(
				'seedprod_css_helpers_missing',
				__( 'CSS generation helpers are not loaded.', 'seedprod-pro' )
			);
		}

		// seedprod_pro_generate_css_file() uses request_filesystem_credentials(),
		// which REST requests don't load (admin contexts do).
		if ( ! function_exists( 'request_filesystem_credentials' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}

		$custom_css = isset( $input['custom_css'] ) ? (string) $input['custom_css'] : '';

		$this->ensure_global_css_page();
		$page_id = absint( get_option( 'seedprod_global_css_page_id' ) );
		$post    = $page_id ? get_post( $page_id ) : null;
		if ( empty( $post ) ) {
			return new WP_Error(
				'seedprod_no_global_css',
				__( 'The Global CSS page could not be found or created.', 'seedprod-pro' ),
				array( 'status' => 500 )
			);
		}

		// Regenerate and verify the published stylesheet BEFORE committing the
		// Customizer store, so a failed file write leaves nothing changed
		// (rather than the Customizer being ahead of the served file). The
		// merge uses $custom_css directly, so it does not depend on the store
		// write below. Mirrors a builder save: merge structured globalHeadCss
		// with the custom CSS.
		$settings        = json_decode( $post->post_content_filtered );
		$global_head_css = isset( $settings->document->settings->globalHeadCss ) ? (string) $settings->document->settings->globalHeadCss : '';
		$merged          = seedprod_pro_merge_global_custom_css( $global_head_css, $custom_css );

		$css_file = trailingslashit( wp_upload_dir()['basedir'] ) . 'seedprod-css/style-global.css';
		clearstatcache( true, $css_file );
		$before_mtime = file_exists( $css_file ) ? (int) filemtime( $css_file ) : 0;
		$before_size  = file_exists( $css_file ) ? (int) filesize( $css_file ) : -1;

		// seedprod_pro_generate_css_file() returns silently when WP_Filesystem
		// cannot get credentials, and it strips empty rules / hoists @import, so
		// the on-disk content is not a substring of the input. Verify by change
		// (mtime/size delta) plus non-emptiness when output is expected, rather
		// than matching content.
		seedprod_pro_generate_css_file( $page_id, $merged );
		clearstatcache( true, $css_file );
		$expect_output = '' !== trim( $merged );
		if ( ! file_exists( $css_file ) ) {
			$wrote = false;
		} elseif ( $expect_output ) {
			$wrote = filesize( $css_file ) > 0 && ( 0 === $before_mtime || (int) filemtime( $css_file ) !== $before_mtime || (int) filesize( $css_file ) !== $before_size );
		} else {
			$wrote = true; // nothing to write (fully cleared) is not a failure.
		}
		if ( ! $wrote ) {
			return new WP_Error(
				'seedprod_css_write_failed',
				__( 'The stylesheet file could not be written, so nothing was saved. Check filesystem permissions for wp-content/uploads/seedprod-css/.', 'seedprod-pro' ),
				array( 'status' => 500 )
			);
		}

		// File is written — now commit the durable store the builder re-merges
		// from on every save (see the css branch of seedprod_pro_save_lpage),
		// so a later builder edit re-reads this value instead of dropping it.
		$updated = wp_update_custom_css_post( $custom_css );
		if ( is_wp_error( $updated ) ) {
			return $updated;
		}

		update_post_meta( $page_id, '_seedprod_css', $global_head_css );
		update_post_meta( $page_id, '_seedprod_custom_css', $custom_css );
		// Bump post_modified so the enqueue cache-buster (derived from it) changes.
		global $wpdb;
		$now = current_time( 'mysql' );
		$wpdb->update(
			$wpdb->posts,
			array(
				'post_modified'     => $now,
				'post_modified_gmt' => get_gmt_from_date( $now ),
			),
			array( 'ID' => $page_id ),
			array( '%s', '%s' ),
			array( '%d' )
		);
		clean_post_cache( $page_id );

		return array(
			'success'      => true,
			'page_id'      => $page_id,
			'css_file_url' => trailingslashit( wp_upload_dir()['baseurl'] ) . 'seedprod-css/style-global.css',
		);
	}

	/**
	 * Register the import-theme ability (Pro only).
	 */
	private function register_import_theme() {
		wp_register_ability(
			'seedprod/import-theme',
			array(
				'label'        => __( 'Import Theme', 'seedprod-pro' ),
				'description'  => __( 'Import a complete SeedProd theme from a ZIP file URL. This will import all theme templates and settings.', 'seedprod-pro' ),
				'category'     => 'seedprod',
				'input_schema' => array(
					'type'       => 'object',
					'properties' => array(
						'url' => array(
							'type'        => 'string',
							'format'      => 'uri',
							'description' => __( 'URL of the theme ZIP file to import. Must be a stable public HTTP/HTTPS artifact the WordPress host can fetch directly — S3, GitHub raw, or a static CDN URL. Share links that redirect with auth tokens (Dropbox, Google Drive) or URLs that require cookies typically fail; download such files first and either rehost or serve from the WordPress host.', 'seedprod-pro' ),
						),
					),
					'required' => array( 'url' ),
				),
				'output_schema' => array(
					'type'       => 'object',
					'properties' => array(
						'success' => array( 'type' => 'boolean' ),
						'message' => array( 'type' => 'string' ),
					),
				),
				'execute_callback'    => array( $this, 'execute_import_theme' ),
				'permission_callback' => function () {
					return current_user_can( 'manage_options' );
				},
				'meta' => array(
					'show_in_rest' => true,
					'annotations'  => array(
						'destructive' => true,
					),
				),
			)
		);
	}

	/**
	 * Execute the import-theme ability.
	 *
	 * @param array $input The input parameters.
	 * @return array|WP_Error The result or error.
	 */
	public function execute_import_theme( $input ) {
		$url = isset( $input['url'] ) ? esc_url_raw( $input['url'] ) : '';

		if ( empty( $url ) ) {
			return new WP_Error(
				'seedprod_invalid_url',
				__( 'A valid theme URL is required.', 'seedprod-pro' )
			);
		}

		$response = wp_remote_head( $url );
		if ( is_wp_error( $response ) ) {
			return new WP_Error( 'seedprod_url_error', $response->get_error_message() );
		}

		$response_code = wp_remote_retrieve_response_code( $response );
		if ( 200 !== $response_code ) {
			return new WP_Error(
				'seedprod_url_not_found',
				__( 'The ZIP file does not exist at the provided URL.', 'seedprod-pro' )
			);
		}

		if ( ! function_exists( 'seedprod_pro_import_theme_by_url_cli' ) ) {
			require_once SEEDPROD_PRO_PLUGIN_PATH . 'wp-cli-functions.php';
		}

		$nonce  = wp_create_nonce( 'seedprod_import_theme_by_url' );
		$result = seedprod_pro_import_theme_by_url_cli( $url, $nonce );

		if ( true === $result || ( is_array( $result ) && ! empty( $result['success'] ) ) ) {
			$response = array(
				'success' => true,
				'message' => __( 'Theme imported successfully.', 'seedprod-pro' ),
			);
			if ( is_array( $result ) && ! empty( $result['warnings'] ) ) {
				$response['warnings'] = $result['warnings'];
			}
			return $response;
		}

		if ( is_array( $result ) && isset( $result['error'] ) ) {
			return new WP_Error( 'seedprod_import_error', $result['error'] );
		}

		return new WP_Error(
			'seedprod_import_error',
			is_string( $result ) ? $result : __( 'An unknown error occurred during import.', 'seedprod-pro' )
		);
	}

	/**
	 * Register the activate-license ability (Pro only).
	 */
	private function register_activate_license() {
		wp_register_ability(
			'seedprod/activate-license',
			array(
				'label'        => __( 'Activate License', 'seedprod-pro' ),
				'description'  => __( 'Activate a SeedProd Pro license key. This enables pro features and automatic updates.', 'seedprod-pro' ),
				'category'     => 'seedprod',
				'input_schema' => array(
					'type'       => 'object',
					'properties' => array(
						'license_key' => array(
							'type'        => 'string',
							'description' => __( 'The license key to activate.', 'seedprod-pro' ),
						),
					),
					'required' => array( 'license_key' ),
				),
				'output_schema' => array(
					'type'       => 'object',
					'properties' => array(
						'success'      => array( 'type' => 'boolean' ),
						'license_type' => array( 'type' => 'string' ),
						'message'      => array( 'type' => 'string' ),
					),
				),
				'execute_callback'    => array( $this, 'execute_activate_license' ),
				'permission_callback' => function () {
					return current_user_can( 'manage_options' );
				},
				'meta' => array(
					'show_in_rest' => true,
					'annotations'  => array(
						'idempotent' => true,
					),
				),
			)
		);
	}

	/**
	 * Execute the activate-license ability.
	 *
	 * @param array $input The input parameters.
	 * @return array|WP_Error The result or error.
	 */
	public function execute_activate_license( $input ) {
		$license_key = isset( $input['license_key'] ) ? sanitize_text_field( $input['license_key'] ) : '';

		if ( empty( $license_key ) ) {
			return new WP_Error(
				'seedprod_invalid_key',
				__( 'A license key is required.', 'seedprod-pro' )
			);
		}

		if ( ! function_exists( 'seedprod_pro_save_api_key_cli' ) ) {
			require_once SEEDPROD_PRO_PLUGIN_PATH . 'wp-cli-functions.php';
		}

		$nonce  = wp_create_nonce( 'seedprod_nonce' );
		$result = seedprod_pro_save_api_key_cli( $license_key, $nonce );

		if ( 'true' === $result['status'] ) {
			return array(
				'success'      => true,
				'license_type' => get_option( 'seedprod_license_name', '' ),
				'message'      => $result['msg'],
			);
		}

		return new WP_Error(
			'seedprod_activation_error',
			isset( $result['msg'] ) ? $result['msg'] : __( 'License activation failed.', 'seedprod-pro' )
		);
	}

	

	/**
	 * Get the SeedProd settings as an array.
	 *
	 * @return array The settings array.
	 */
	private function get_settings() {
		$settings = get_option( 'seedprod_settings', array() );

		if ( is_string( $settings ) ) {
			$settings = json_decode( $settings, true );
		}

		if ( ! is_array( $settings ) ) {
			$settings = array();
		}

		return $settings;
	}
}

// Initialize the abilities.
new SeedProd_Pro_Abilities();
